﻿#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock  # pyright: ignore[reportMissingModuleSource]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir


class TestOperatorSupportRecommendation(unittest.TestCase):
    def _write_json(self, path, data):
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        return path

    def _snapshot_with_phase_payloads(self, reports_dir, run_id, shadow_payload, phase_c_payload, phase_d_payload):
        shadow_path = self._write_json(
            os.path.join(reports_dir, 'shadow_run_report_{0}.json'.format(run_id)),
            shadow_payload,
        )
        phase_c_path = self._write_json(
            os.path.join(reports_dir, 'ingest_write_summary_{0}.json'.format(run_id)),
            phase_c_payload,
        )
        phase_d_path = self._write_json(
            os.path.join(reports_dir, 'qa_canonical_summary_{0}.json'.format(run_id)),
            phase_d_payload,
        )
        rows = []
        for code in ('B', 'C', 'D', 'E', 'F'):
            row = {
                'code': code,
                'name': code,
                'status': 'complete',
                'resolved_run_id': run_id,
                'files': [],
                'required_missing': [],
            }
            if code == 'C':
                row['files'] = [phase_c_path]
            elif code == 'D':
                row['files'] = [phase_d_path]
            elif code == 'F':
                row['files'] = [shadow_path]
            rows.append(row)
        return {
            'lab_root': os.path.dirname(reports_dir),
            'reports_dir': reports_dir,
            'run_id': run_id,
            'nearest_complete_run_id': '',
            'phase_rows': rows,
            'diagnostics_state': {},
        }

    def test_compute_operator_support_send_recommendation_prefers_historical_reprocess_for_duplicate_only_dat(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['dat'])
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')
        self.assertIn('re-evaluate historical Phase D rejects', rec.get('summary_line', ''))
        self.assertIn('Phase B DAT manifest did not indicate discovered DAT rows', rec.get('dat_smoke_not_triggered_reason', ''))

    def test_compute_operator_support_send_recommendation_suppresses_historical_when_live_phase_c_failed(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_phase_c_ok': False,
                    'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
                }, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260430-020617-7952eda8',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 814,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 814},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertFalse(rec.get('historical_reprocess_available'))
        self.assertIn('PHASE_C_DB_WRITE_ERROR', rec.get('historical_reprocess_not_triggered_reason', ''))

    def test_compute_operator_support_send_recommendation_uses_phase_d_summary_fallback_when_live_reject_snapshot_empty(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260410-135950-415f1239',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 780,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 780},
                {
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['csv', 'dat', 'docx'],
                    'historical_reject_counts_by_class': {'csv': 10, 'dat': 785, 'docx': 6},
                    'historical_reject_counts_by_version': {'qa_v1': 6, 'qa_v2': 795},
                },
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'dat', 'docx'])
        self.assertIn(
            'Using anchored Phase D summary fallback for historical replay targeting',
            ' '.join(rec.get('action_reason_lines', []))
        )

    def test_compute_operator_support_send_recommendation_uses_phase_d_summary_fallback_when_live_reject_snapshot_unavailable(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260410-135950-415f1239',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 780,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 780},
                {
                    'rows_selected': 0,
                    'qa_pass_count': 0,
                    'qa_reject_count': 0,
                    'qa_policy_version': 'qa_v2',
                    'historical_reprocess_candidate': True,
                    'historical_reprocess_targeted_artifact_classes': ['csv', 'dat', 'docx'],
                    'historical_reject_counts_by_class': {'csv': 10, 'dat': 785, 'docx': 6},
                    'historical_reject_counts_by_version': {'qa_v1': 6, 'qa_v2': 795},
                },
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', None):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'dat', 'docx'])
        self.assertIn(
            'Using anchored Phase D summary fallback for historical replay targeting',
            ' '.join(rec.get('action_reason_lines', []))
        )

    def test_anchored_duplicate_only_historical_recommendation_with_lineage_skew_issue(self):
        """
        Real anchored XP runs: Phase D zero-selection may reference a different Phase C run id than
        shadow phase_run_ids, producing lineage_issues. That must not downgrade to send_bundle when
        duplicate-only + historical rejects still warrant historical_phase_d_reprocess.
        """
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260331-005932-ba25d2aa'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            snapshot['lineage_issues'] = [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=a resolved_phase_c=b',
            ]
            snapshot['diagnostics_state'] = {
                'pipeline_state': 'completed',
                'last_shadow_pipeline_run_id': run_id,
                'active_run_id': '',
            }

            def fake_build(_repo_root, run_id='', **_kwargs):
                return True, '', dict(snapshot)

            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, '_collect_system_health_artifacts', return_value={
                    'lab_root': lab,
                    'reports_dir': reports,
                    'repo_root': repo,
                    'shadow_report_path': '',
                }):
                    with patch.object(cr, '_build_system_health_pack_context', return_value={
                        'pack_scope': 'completed_run',
                        'anchor_run_id': run_id,
                    }):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={
                            'recommendation': 'send_current_run',
                            'score': 80,
                            'label': 'HIGH',
                        }):
                            with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                with patch.object(cr, 'is_pipeline_running', return_value=False):
                                    with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                        'ok': True,
                                        'qa_version': 'qa_v2',
                                        'targeted_artifact_classes': ['dat'],
                                        'reject_counts_by_class': {'dat': 389},
                                        'pending_replay_counts_by_class': {'dat': 389},
                                    }):
                                        rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(str(rec.get('recommendation_anchor_run_id', '')), run_id)

    def test_compute_operator_support_send_recommendation_prefers_dat_smoke_before_historical_reprocess(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 763,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 763},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 389},
                                'pending_replay_counts_by_class': {'dat': 389},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('follow_on_action_kind'), 'historical_phase_d_reprocess')
        self.assertTrue(rec.get('historical_reprocess_available'))
        self.assertTrue(rec.get('dat_smoke_available'))
        self.assertIn('Follow-on after DAT smoke', ' '.join(rec.get('action_reason_lines', [])))

    def test_compute_operator_support_send_recommendation_waits_for_stable_when_pipeline_active(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 10,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 10},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=True):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['dat'],
                                'reject_counts_by_class': {'dat': 10},
                                'pending_replay_counts_by_class': {'dat': 10},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'historical_phase_d_reprocess')
        self.assertEqual(rec.get('best_now_action_kind'), 'wait_for_stable')

    def test_compute_operator_support_send_recommendation_targets_only_affected_classes(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 12,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 12},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': ['csv', 'docx'],
                                'reject_counts_by_class': {'csv': 7, 'docx': 5},
                                'pending_replay_counts_by_class': {'csv': 7, 'docx': 5},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_artifact_classes'), ['csv', 'docx'])

    def test_compute_operator_support_send_recommendation_stays_on_send_bundle_without_historical_rejects(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'send_bundle')
        self.assertEqual(rec.get('best_now_action_kind'), 'send_bundle')

    def test_compute_operator_support_send_recommendation_recommends_phase_d_dat_smoke_when_anchored_not_advanced(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('preferred_when_stable_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('best_now_action_kind'), 'phase_d_dat_smoke')
        self.assertEqual(rec.get('strict_milestone_verdict'), 'Not advanced')
        self.assertEqual(rec.get('action_preview', {}).get('anchor_run_id'), '20260329-171213-1ccb1c51')

    def test_compute_operator_support_send_recommendation_does_not_recommend_dat_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            reports = os.path.join(repo, 'lab', 'reports')
            os.makedirs(reports)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('best_now_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('preferred_when_stable'), 'run_evidence')
        self.assertEqual(rec.get('best_now_send'), 'run_evidence')
        self.assertIn('send anchored run evidence bundle', rec.get('summary_line', '').lower())
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(preview.get('dat_selected_count'), 6)
        self.assertEqual(preview.get('dat_qa_reject_count'), 6)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)

    def test_review_dat_qa_full_block_preview_contains_layer1_when_present_in_phase_d_summary(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            phase_d = {
                'run_id': '20260329-171213-1ccb1c51',
                'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6},
                'layer1_join_debug_generated': True,
                'layer1_top_blocker': 'dat_parse_rejects',
                'layer1_join_debug_pack_path': os.path.join(reports, 'layer1_pack.txt'),
                'layer1_join_debug_summary_path': os.path.join(reports, 'layer1_sum.json'),
                'layer1_join_debug_samples_path': os.path.join(reports, 'layer1_smp.jsonl'),
            }
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                phase_d,
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
        self.assertTrue(preview.get('layer1_join_debug_generated'))
        self.assertEqual(preview.get('layer1_top_blocker'), 'dat_parse_rejects')
        lines = rec.get('action_reason_lines') if isinstance(rec.get('action_reason_lines'), list) else []
        merged = '\n'.join([str(x) for x in lines])
        self.assertIn('Layer 1 join debug', merged)
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')

    def test_review_dat_qa_full_block_suppressed_when_live_phase_c_failed(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({
                    'last_phase_c_ok': False,
                    'last_phase_c_error_code': 'PHASE_C_DB_WRITE_ERROR',
                }, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '')
        self.assertIn('Phase C', skip)

    def test_review_dat_qa_full_block_suppressed_when_live_phase_c_failed_without_error_code(self):
        """Stale diagnostics may omit last_phase_c_error_code — still suppress QA full-block."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as handle:
                json.dump({'last_phase_c_ok': False}, handle)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        skip = str(rec.get('dat_qa_full_block_not_triggered_reason', '') or '')
        self.assertIn('Phase C', skip)
        self.assertIn('error_code', skip.lower())

    def test_compute_operator_support_send_recommendation_replays_live_z_zm_full_block_pattern(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260421-003615-6722364b'
            smoke_anchor = '20260331-022246-3b508c10'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 408,
                    'phase_b_dat_selection_mode': 'configured',
                    'phase_b_dat_selected_root_source_id': 'dat_cfg_0',
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 0,
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 5,
                    'phase_d_dat_canonical_record_count': 0,
                    'post_medisoft_blocked_stage': 'qa',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 0},
                {'run_id': '20260421-003627-6364b919', 'dat_telemetry': {
                    'dat_selected_count': 5,
                    'dat_qa_pass_count': 0,
                    'dat_qa_reject_count': 5,
                    'dat_canonical_record_count': 0,
                }},
            )
            with open(os.path.join(reports, 'qa_reject_samples_{0}.jsonl'.format(run_id)), 'w', encoding='utf-8') as f:
                f.write('{"reject_code":"QA_DAT_PAYER_ANCHOR_MISSING"}\n')
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke_anchor))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('recommended_report_kind'), 'artifact_triage_pack')
        self.assertIn('send anchored run evidence bundle', rec.get('summary_line', '').lower())
        preview = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(preview.get('anchor_run_id'), run_id)
        self.assertEqual(preview.get('dat_selected_count'), 5)
        self.assertEqual(preview.get('dat_qa_reject_count'), 5)
        self.assertEqual(preview.get('dat_canonical_record_count'), 0)
        self.assertTrue(str(preview.get('qa_reject_samples_path', '')).endswith('qa_reject_samples_{0}.jsonl'.format(run_id)))
        self.assertTrue(preview.get('ignored_smoke_mismatch'))
        self.assertFalse(preview.get('smoke_source_accepted'))
        self.assertEqual(preview.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        reason_blob = ' '.join(rec.get('action_reason_lines', []))
        self.assertIn('selected=5, qa_pass=0, qa_reject=5, canonical=0', reason_blob)
        self.assertIn('mismatched smoke on disk will be noted but not trusted', reason_blob)

    def test_compute_operator_support_send_recommendation_uses_completed_smoke_for_truthful_dat_lane_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 390,
                    'phase_c_inserted_count': 390,
                    'phase_c_skipped_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 390, 'rows_skipped_duplicate': 0},
                {'run_id': run_id, 'dat_telemetry': {'dat_selected_count': 0, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 0}},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(run_id))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(run_id))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': run_id,
                    'assessment': 'dat_selected_qa_blocked',
                    'strict_milestone_verdict': 'Partially advanced',
                    'dat_funnel': {
                        'dat_selected_count': 390,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 390,
                        'dat_canonical_record_count': 0,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': run_id,
                    'last_requested_context_run_id': run_id,
                    'last_remediation_issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        self.assertEqual(rec.get('preferred_when_stable'), 'run_evidence')
        self.assertEqual(rec.get('best_now_send'), 'run_evidence')
        self.assertEqual(rec.get('dat_smoke_last_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('smoke_assessment'), 'dat_selected_qa_blocked')
        self.assertEqual(rec.get('action_preview', {}).get('dat_selected_count'), 390)
        self.assertIn('send the anchored run evidence bundle', rec.get('why_summary', '') + ' ' + ' '.join(rec.get('action_reason_lines', [])))
        self.assertIn('Partially advanced', rec.get('why_summary', '') + ' ' + ' '.join(rec.get('action_reason_lines', [])))
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertTrue(prev.get('smoke_source_accepted'))
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'smoke_corroborated')

    def test_compute_operator_support_send_recommendation_qa_full_block_ignores_mismatched_smoke_counters(self):
        """Smoke dat_funnel must not override anchored counts when smoke anchor != anchored run."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            run_id = '20260329-171213-1ccb1c51'
            other_anchor = '20260331-022246-3b508c10'
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                run_id,
                {
                    'run_id': run_id,
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 5,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 6,
                    'post_medisoft_blocked_stage': 'phase_d',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 5, 'rows_skipped_duplicate': 1},
                {'run_id': run_id, 'dat_telemetry': {
                    'dat_selected_count': 6, 'dat_qa_pass_count': 0, 'dat_qa_reject_count': 6,
                }},
            )
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other_anchor))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other_anchor))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('assessment: dat_selected_qa_blocked\n')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'anchor_run_id': other_anchor,
                    'assessment': 'dat_selected_qa_blocked',
                    'dat_funnel': {
                        'dat_selected_count': 999,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 999,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            with open(os.path.join(lab, 'phase_d_dat_smoke_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertEqual(rec.get('recommended_action_kind'), 'review_dat_qa_full_block')
        prev = rec.get('action_preview', {}) if isinstance(rec.get('action_preview', {}), dict) else {}
        self.assertEqual(prev.get('dat_selected_count'), 6)
        self.assertEqual(prev.get('dat_qa_reject_count'), 6)
        self.assertNotEqual(prev.get('dat_selected_count'), 999)
        self.assertTrue(prev.get('ignored_smoke_mismatch'))
        self.assertFalse(prev.get('smoke_source_accepted'))
        self.assertEqual(prev.get('anchored_diagnosis_source'), 'anchored_phase_d_shadow')
        reason_blob = ' '.join(rec.get('action_reason_lines', []))
        self.assertIn('mismatched smoke on disk will be noted but not trusted', reason_blob)
        self.assertNotIn('matching smoke report', reason_blob)

    def test_compute_operator_support_send_recommendation_suppresses_dat_smoke_when_same_target_in_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'run_id': '20260329-171213-1ccb1c51',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_c_inserted_count': 4,
                    'phase_c_skipped_count': 1,
                    'phase_d_dat_selected_count': 0,
                    'post_medisoft_blocked_stage': '',
                    'pipeline_ok': True,
                },
                {'rows_inserted': 4, 'rows_skipped_duplicate': 1},
                {'run_id': '20260329-171213-1ccb1c51', 'dat_telemetry': {'dat_selected_count': 0}},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertNotEqual(rec.get('recommended_action_kind'), 'phase_d_dat_smoke')
        self.assertIn('cooldown', str(rec.get('dat_smoke_not_triggered_reason', '')).lower())

    def test_compute_operator_support_send_recommendation_auto_embeds_qa_drop_issue_without_manual_reply(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:Phase D skipped 13 patient upsert(s).',
                    'last_sent_epoch': 1774577782,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertFalse(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT')
        lou = rec.get('live_operator_unblock', {}) if isinstance(rec.get('live_operator_unblock', {}), dict) else {}
        self.assertFalse(lou.get('reply_required'))
        self.assertTrue(lou.get('deprecation_active'))
        self.assertEqual(lou.get('closure_mode'), 'embedded_auto_closure')
        self.assertIn('embed_issue_code_in_recommendation', lou.get('closure_tasks', []))
        self.assertIn('Operator-reply deprecation active', '\n'.join(rec.get('action_reason_lines', [])))
        step2 = rec.get('step2_run_coherence', {}) if isinstance(rec.get('step2_run_coherence', {}), dict) else {}
        self.assertIn('alignment_note', step2)
        self.assertIn(step2.get('alignment_note'), ('step2_ready', 'missing_required_artifacts_for_step2', 'snapshot_coherence_blocked', 'phase_d_summary_run_id_mismatch'))
        self.assertIn('alignment_ok', step2)

    def test_compute_operator_support_send_recommendation_does_not_override_non_qa_alert_with_telemetry_fallback(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'cloud_health_alert_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'last_issue_key': 'PHASE_F_LOCK_FAIL:Phase F lock acquisition failed.',
                    'last_sent_epoch': 1774577782,
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260329-171213-1ccb1c51',
                    'last_discovery_dat_telemetry': {'dat_manifest_rows_count': 3},
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 0,
                        'post_medisoft_exercised': False,
                        'post_medisoft_blocked_stage': 'phase_d',
                    },
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_20260329-171213-1ccb1c51.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 0,
                }, f)
            snapshot = self._snapshot_with_phase_payloads(
                reports,
                '20260329-171213-1ccb1c51',
                {
                    'phase_c_inserted_count': 0,
                    'phase_c_skipped_count': 3,
                    'phase_d_rows_selected': 0,
                    'phase_d_pass_count': 0,
                    'phase_d_reject_count': 0,
                    'phase_d_qa_policy_version': 'qa_v2',
                },
                {'rows_inserted': 0, 'rows_skipped_duplicate': 3},
                {'rows_selected': 0, 'qa_pass_count': 0, 'qa_reject_count': 0, 'qa_policy_version': 'qa_v2'},
            )
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_artifact_bundle_quality', return_value={'recommendation': 'send_current_run', 'score': 80, 'label': 'HIGH'}):
                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                        with patch.object(cr, 'is_pipeline_running', return_value=False):
                            with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', return_value={
                                'ok': True,
                                'qa_version': 'qa_v2',
                                'targeted_artifact_classes': [],
                                'reject_counts_by_class': {},
                                'pending_replay_counts_by_class': {},
                            }):
                                rec = cr.compute_operator_support_send_recommendation(repo)
        self.assertFalse(rec.get('reply_required_for_unblock'))
        self.assertEqual(rec.get('reply_required_issue_code'), '')



class TestPhaseDHistoricalReprocessWrappers(unittest.TestCase):
    def test_run_phase_d_manual_sets_artifact_class_filter_env(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', '/repo', '/repo/run_qa_canonical.py', [])):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr.subprocess, 'Popen') as mock_popen:
                    ok, msg, _ = cr.run_phase_d_manual('/repo', '/py', {}, artifact_classes=['dat', 'csv'])
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        proc_env = mock_popen.call_args[1].get('env', {})
        self.assertEqual(proc_env.get('MEDICAFE_LAB_DIR'), '/repo/lab')
        self.assertEqual(proc_env.get('MEDICAFE_PHASE_D_ARTIFACT_CLASSES'), 'dat,csv')

    def test_run_historical_phase_d_reprocess_resets_then_launches_filtered_phase_d(self):
        from MediCafe import cloud_readiness as cr
        payload = {
            'ok': True,
            'targeted_artifact_classes': ['dat'],
            'execution_report_path': '/repo/lab/reports/phase_d_historical_reprocess_execution_latest.txt',
        }
        with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', return_value=payload):
            with patch.object(cr, 'resolve_lab_root', return_value='/repo/lab'):
                with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', None)) as mock_run:
                    ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation started', msg)
        self.assertEqual(data.get('execution_report_path'), payload['execution_report_path'])
        mock_run.assert_called_once_with('/repo', '/py', {}, artifact_classes=['dat'])

    def test_run_historical_phase_d_reprocess_loads_helper_from_resolved_script(self):
        from MediCafe import cloud_readiness as cr
        temp_root = tempfile.mkdtemp()
        script_path = os.path.join(temp_root, 'phase_d_historical_reprocess.py')
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(
                'def normalize_artifact_classes(raw):\n'
                '    return list(raw or [])\n'
                'def collect_phase_d_reject_snapshot(lab_root, artifact_classes=None, qa_version=None):\n'
                '    return {"ok": True}\n'
                'def preview_historical_phase_d_reprocess(lab_root, artifact_classes=None, remediation_context_run_id=None):\n'
                '    return {"ok": True, "report_path": "preview.txt"}\n'
                'def execute_historical_phase_d_reprocess(lab_root, artifact_classes=None, remediation_context_run_id=None):\n'
                '    return {"ok": True, "targeted_artifact_classes": ["dat"], "execution_report_path": "execution.txt"}\n'
            )
        with patch.object(cr, '_preview_historical_phase_d_reprocess_impl', None):
            with patch.object(cr, '_execute_historical_phase_d_reprocess_impl', None):
                with patch.object(cr, '_normalize_phase_d_reprocess_classes_impl', None):
                    with patch.object(cr, '_collect_phase_d_reject_snapshot_impl', None):
                        with patch.object(cr, '_resolve_unified_model_script', return_value=(True, '', temp_root, script_path, [])):
                            with patch.object(cr, 'resolve_lab_root', return_value=os.path.join(temp_root, 'lab')):
                                with patch.object(cr, 'run_phase_d_manual', return_value=(True, '', None)) as mock_run:
                                    ok, msg, data = cr.run_historical_phase_d_reprocess('/repo', '/py', {}, artifact_classes=['dat'])
        self.assertTrue(ok)
        self.assertIn('Historical Phase D re-evaluation started', msg)
        self.assertEqual(data.get('execution_report_path'), 'execution.txt')
        mock_run.assert_called_once_with('/repo', '/py', {}, artifact_classes=['dat'])



class TestEmbeddedRecommendationReporting(unittest.TestCase):
    def test_format_recommended_action_lines_includes_reply_required_fields(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': True,
            'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
            'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
        })
        body = '\n'.join(lines)
        self.assertIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_milestone_and_operator_lanes(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'milestone_verdict': 'Not advanced',
            'milestone_reason': 'dat_lane_not_exercised',
            'anchored_milestone_run_id': 'anchor-rid',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Milestone verdict (anchored shadow payload):', body)
        self.assertIn('milestone_verdict=Not advanced', body)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:example', body)

    def test_format_recommended_action_lines_includes_followthrough_predictions(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
            'best_now_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'pipeline_running': True,
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        self.assertIn('operator_primary_report_surface=artifact_triage_pack', body)
        self.assertIn('follow_recommendation_now=defer_until_idle', body)
        self.assertIn('follow_recommendation_when_stable=send_anchored_run_evidence_bundle', body)
    def test_format_recommended_action_lines_auto_ack_syncs_live_unblock_reply_required(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'send_bundle',
            'reply_required_for_unblock': False,
            'reply_required_issue_code': '',
            'reply_required_issue_key': '',
            'live_operator_unblock': {
                'reply_required': True,
                'reply_required_issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
                'reply_required_issue_key': 'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack',
            },
        })
        body = '\n'.join(lines)
        self.assertIn('Operator unblock (live alert / diagnostics):', body)
        self.assertIn(' - reply_required=False', body)
        self.assertNotIn('reply_required_for_unblock=True', body)
        self.assertIn('reply_required_issue_code=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT', body)
        self.assertIn('reply_required_issue_key=PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT:auto-ack', body)

    def test_format_recommended_action_lines_includes_qa_full_block_provenance(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'recommended_report_kind': 'artifact_triage_pack',
            'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
            'action_preview': {
                'anchor_run_id': '20260329-171213-1ccb1c51',
                'anchored_diagnosis_source': 'anchored_phase_d_shadow',
                'smoke_source_accepted': False,
                'ignored_smoke_mismatch': True,
                'smoke_anchor_run_id': 'other-anchor',
                'source_mismatch_note': 'Smoke on disk is not used for displayed counters.',
            },
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        self.assertIn('operator_followthrough=send_anchored_run_evidence_bundle', body)
        self.assertIn('operator_manual_review_required=False', body)
        self.assertIn('QA full-block review provenance:', body)
        self.assertIn('anchored_diagnosis_source=anchored_phase_d_shadow', body)
        self.assertIn('smoke_source_accepted=False', body)
        self.assertIn('ignored_smoke_mismatch=True', body)
        self.assertIn('smoke_anchor_run_id=other-anchor', body)
        self.assertIn('source_mismatch_note=', body)

    def test_format_recommended_action_lines_qa_full_block_overrides_stale_manual_review_flag(self):
        from MediCafe import cloud_readiness_artifact_tools as tools
        lines = tools.format_recommended_action_lines({
            'recommended_action_kind': 'review_dat_qa_full_block',
            'operator_manual_review_required': True,
            'recommended_report_kind': 'artifact_triage_pack',
            'action_preview': {'anchor_run_id': 'rid'},
            'live_operator_unblock': {'reply_required': False},
        })
        body = '\n'.join(lines)
        manual_lines = [ln for ln in lines if 'operator_manual_review_required' in ln]
        self.assertEqual(len(manual_lines), 1)
        self.assertIn('operator_manual_review_required=False', body)

    def test_open_latest_artifact_triage_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'pipeline_run_id': '20260329-171213-1ccb1c51',
                'phase_rows': [
                    {'code': code, 'name': code, 'status': 'complete', 'resolved_run_id': '20260329-171213-1ccb1c51', 'files': [], 'required_missing': []}
                    for code in ('B', 'C', 'D', 'E', 'F')
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {},
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'high',
                'resolution_reason': '',
                'resolution_notes': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                    ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_open_latest_system_health_pack_embeds_recommended_action_block(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'preferred_when_stable_action_kind': 'historical_phase_d_reprocess',
                'best_now_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'latest_phase_c_inserted_count': 0, 'latest_phase_c_skipped_count': 10, 'latest_phase_d_rows_selected': 0, 'latest_phase_d_pass_count': 0, 'latest_phase_d_reject_count': 0, 'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'pack_scope': 'completed_run',
                    'active_run_id': '',
                    'expected_shadow_run_id': '20260329-171213-1ccb1c51',
                    'anchor_state': {},
                    'anchor_report_path': '',
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': '20260329-171213-1ccb1c51'}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': False, 'error': 'no db'}):
                                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                                                    ok, msg, path = cr.open_latest_system_health_pack(repo, lambda _n, default: default)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('recommended_action_kind=historical_phase_d_reprocess', body)
            self.assertIn('historical_reject_counts_by_class=dat:10', body)

    def test_open_latest_system_health_pack_context_mode_skips_guided_patient_preview(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260415-232243-0b19e55a'
            artifacts = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }
            pack_context = {
                'anchor_run_id': run_id,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': run_id,
                'anchor_state': {},
                'anchor_report_path': '',
            }
            snapshot = {
                'ok': True,
                'status': 'ok',
                'db_path': os.path.join(lab, 'unified_model_xp.db'),
                'counts': {'patient': 9},
                'patient_count_effective': 4,
                'qa_reject_count_effective': 1,
                'projection_success_count_effective': 2,
                'projection_reject_count_effective': 0,
                'qa_scope_version': '',
                'projection_scope_version': 'scope-v1',
                'replay_pending_count': 0,
                'orphan_claim_lines': 0,
            }
            progress = []
            with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': run_id}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                        with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(False, 'no eval', {}, {'live_run_id': '', 'live_run_status': ''})):
                                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}):
                                                with patch.object(cr, '_collect_data_plane_snapshot', return_value=snapshot):
                                                    with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                                        with patch.object(cr, '_collect_patient_chain_rows', side_effect=AssertionError('should not collect guided patient rows')) as mock_rows:
                                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                                ok, msg, path = cr.open_latest_system_health_pack(
                                                                    repo,
                                                                    lambda _n, default: default,
                                                                    progress_callback=progress.append,
                                                                    include_guided_patient_preview=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertFalse(mock_rows.called)
            self.assertIn('building DB enrichment overview', progress)
            self.assertIn('building system health runbook', progress)
            self.assertNotIn('sampling guided patient preview', progress)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('guided_patient_options=skipped_context_pack', body)
            self.assertIn('projection_success_count=2', body)

    def test_open_latest_system_health_pack_skips_guided_preview_when_relational_depth_zero(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260430-020617-7952eda8'
            artifacts = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
                'consolidated_message': '',
                'consolidated_ok': True,
            }
            pack_context = {
                'anchor_run_id': run_id,
                'pack_scope': 'completed_run',
                'active_run_id': '',
                'expected_shadow_run_id': run_id,
                'anchor_state': {},
                'anchor_report_path': '',
            }
            snapshot = {
                'ok': True,
                'status': 'WARN',
                'db_path': os.path.join(lab, 'unified_model_xp.db'),
                'counts': {
                    'patient': 5825,
                    'coverage': 0,
                    'encounter': 0,
                    'claim': 0,
                    'claim_line': 0,
                },
                'patient_count_effective': 2803,
                'qa_reject_count_effective': 842,
                'projection_success_count_effective': 19715,
                'projection_reject_count_effective': 0,
                'qa_scope_version': 'qa_v2',
                'projection_scope_version': 'proj_v2',
                'replay_pending_count': 842,
                'orphan_claim_lines': 0,
            }
            progress = []
            with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                with patch.object(cr, '_build_system_health_pack_context', return_value=pack_context):
                    with patch.object(cr, 'get_health_lines', return_value=['health ok']):
                        with patch.object(cr, '_build_system_health_alignment_notes', return_value={'notes': [], 'audit_stale': False, 'expected_shadow_run_id': run_id}):
                            with patch.object(cr, '_build_anchor_run_snapshot_lines', return_value=['Anchored completed-run snapshot:']):
                                with patch.object(cr, '_build_recent_shadow_run_actual_lines', return_value=['Recent shadow runs:']):
                                    with patch.object(cr, '_build_phase_f_lock_context_lines', return_value=[]):
                                        with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(False, 'no eval', {}, {'live_run_id': '', 'live_run_status': ''})):
                                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}):
                                                with patch.object(cr, '_collect_data_plane_snapshot', return_value=snapshot):
                                                    with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=[]):
                                                        with patch.object(cr, '_collect_patient_chain_rows', side_effect=AssertionError('should not collect guided patient rows')) as mock_rows:
                                                            with patch.object(cr, '_build_system_health_pack_runbook', return_value=['What To Do Now:', ' 1) test']):
                                                                ok, msg, path = cr.open_latest_system_health_pack(
                                                                    repo,
                                                                    lambda _n, default: default,
                                                                    progress_callback=progress.append)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertFalse(mock_rows.called)
            self.assertNotIn('sampling guided patient preview', progress)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('guided_patient_options=skipped_relational_depth_zero', body)
            self.assertIn('patient_count=2803', body)

    def test_send_latest_run_evidence_bundle_attaches_context_note_and_reprocess_reports(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            rid = '20260329-171213-1ccb1c51'
            hdr = (
                'Historical Phase D Re-Evaluation Preview\n'
                'generated_at_utc=test\n'
                'remediation_context_run_id={0}\n'.format(rid))
            with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(hdr)
            with open(execution_path, 'w', encoding='utf-8') as f:
                f.write(hdr.replace('Preview', 'Execution'))
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': True,
                'action_preview': {'historical_reject_counts_by_class': {'dat': 10}},
                'action_reason_lines': ['Historical DAT rejects still exist.'],
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn(os.path.basename(context_note), basenames)
            self.assertIn(os.path.basename(preview_path), basenames)
            self.assertIn(os.path.basename(execution_path), basenames)
            self.assertEqual(data.get('context_attachment_path'), context_note)

    def test_send_latest_run_evidence_bundle_attaches_dat_smoke_artifacts_and_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_lab = os.path.join(repo, 'phase_d_dat_smoke_lab')
            smoke_reports = os.path.join(smoke_lab, 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            for path in (triage_path, index_path, delivery_path, context_note):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('x')
            smoke_run = '20260330-000001-smoke'
            smoke_report_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(smoke_run))
            smoke_report_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(smoke_run))
            smoke_shadow_json = os.path.join(smoke_reports, 'shadow_run_report_{0}.json'.format(smoke_run))
            smoke_shadow_txt = os.path.join(smoke_reports, 'shadow_run_report_{0}.txt'.format(smoke_run))
            with open(smoke_report_txt, 'w', encoding='utf-8') as f:
                f.write('smoke txt\n')
            with open(smoke_report_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': smoke_run, 'assessment': 'dat_discovered_not_ingested'}, f)
            with open(smoke_shadow_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': smoke_run}, f)
            with open(smoke_shadow_txt, 'w', encoding='utf-8') as f:
                f.write('shadow txt\n')
            state_path = cr.phase_d_dat_smoke_state_path(repo)
            state_parent = os.path.dirname(state_path)
            if state_parent and not os.path.isdir(state_parent):
                os.makedirs(state_parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': '20260329-171213-1ccb1c51',
                    'last_requested_context_run_id': '20260329-171213-1ccb1c51',
                    'last_remediation_issue_code': '',
                    'last_status': 'completed',
                    'last_report_path': smoke_report_txt,
                    'last_assessment': 'dat_discovered_not_ingested',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'phase_d_dat_smoke',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommended_artifact_classes': ['dat'],
                'action_requires_confirmation': False,
                'dat_smoke_evaluated': True,
                'dat_smoke_available': True,
                'recommendation_anchor_run_id': '20260329-171213-1ccb1c51',
                'action_preview': {
                    'anchor_run_id': '20260329-171213-1ccb1c51',
                    'phase_d_context_run_id': '20260329-171213-1ccb1c51',
                    'smoke_lab_root': smoke_lab,
                    'smoke_reports_dir': smoke_reports,
                    'expected_report_path': os.path.join(smoke_reports, 'phase_d_dat_smoke_report_<smoke_pipeline_run_id>.txt'),
                    'reference_phase_d_summary_path': os.path.join(reports, 'qa_canonical_summary_20260329-171213-1ccb1c51.json'),
                },
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=(context_note, {'pack_scope': 'mixed_scope', 'anchor_run_id': 'other'})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle_smoke.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertIn('phase_d_dat_smoke_state.json', basenames)
            self.assertIn(os.path.basename(smoke_report_txt), basenames)
            self.assertIn(os.path.basename(smoke_report_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_json), basenames)
            self.assertIn(os.path.basename(smoke_shadow_txt), basenames)
            self.assertIn('run_evidence_dat_smoke_note_20260329-171213-1ccb1c51.txt', basenames)

    def test_send_latest_run_evidence_bundle_omits_phase_d_reprocess_when_not_historical_action(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            triage_path = os.path.join(reports, 'artifact_triage_pack_20260329-171213-1ccb1c51.txt')
            index_path = os.path.join(reports, 'run_artifact_index_20260329-171213-1ccb1c51.txt')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            context_note = os.path.join(reports, 'run_evidence_context_note_20260329-171213-1ccb1c51.txt')
            preview_path = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            execution_path = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for path in (triage_path, index_path, delivery_path, context_note, preview_path, execution_path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('stale\n')
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260329-171213-1ccb1c51',
                'nearest_complete_run_id': '',
                'artifact_files': [],
                'context_files': [],
                'phase_rows': [],
            }
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                with patch.object(cr, '_select_evaluation_snapshot_for_recommendation', return_value=(
                        True, '', snapshot, {'live_run_id': snapshot['run_id'], 'live_run_status': 'completed'})):
                    with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                        with patch.object(cr, '_artifact_bundle_quality', return_value={'score': 80, 'label': 'HIGH', 'complete': 5, 'partial': 0, 'missing': 0, 'recommendation': 'send_current_run'}):
                            with patch.object(cr, '_write_artifact_triage_pack', return_value=triage_path):
                                with patch.object(cr, '_write_run_artifact_index', return_value=index_path):
                                    with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                                        with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', {})):
                                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle2.zip') as mock_collect:
                                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                        ok, msg, _data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            basenames = [item[0] for item in mock_collect.call_args[1].get('extra_files', [])]
            self.assertNotIn('phase_d_historical_reprocess_preview_latest.txt', basenames)
            self.assertNotIn('phase_d_historical_reprocess_execution_latest.txt', basenames)



class TestRecommendationAndBundleEdgeCases(unittest.TestCase):
    """Paths that exercise pack context, interrupt attachment rules, and Phase D dedupe."""

    def test_collect_run_evidence_context_attachment_uses_pack_text_anchor_without_second_artifact_scan(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            run_id = '20260415-232243-0b19e55a'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')

            def fake_open_latest_system_health_pack(
                    _repo_root,
                    _env_flag_fn,
                    include_delivery_status=False,
                    progress_callback=None,
                    include_guided_patient_preview=True):
                self.assertFalse(include_guided_patient_preview)
                with open(pack_path, 'w', encoding='utf-8') as f:
                    f.write('System Health Pack\n')
                    f.write(' - recommendation_anchor_run_id={0}\n'.format(run_id))
                return True, '', pack_path

            snapshot = {
                'reports_dir': reports,
                'lab_root': lab,
                'run_id': run_id,
            }
            with patch.object(cr, 'open_latest_system_health_pack', side_effect=fake_open_latest_system_health_pack):
                with patch.object(cr, '_collect_system_health_artifacts', side_effect=AssertionError('should not rescan health artifacts')):
                    path, context = cr._collect_run_evidence_context_attachment(repo, snapshot)
        self.assertEqual(path, pack_path)
        self.assertEqual(context.get('anchor_run_id'), run_id)
        self.assertEqual(context.get('pack_scope'), 'completed_run')

    def test_phase_d_dat_smoke_paths_qa_full_block_mismatch_emits_note_only(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            smoke_reports = os.path.join(repo, 'phase_d_dat_smoke_lab', 'reports')
            os.makedirs(reports)
            os.makedirs(smoke_reports)
            reviewed = '20260329-171213-1ccb1c51'
            other = '20260331-022246-3b508c10'
            smoke_txt = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.txt'.format(other))
            smoke_json = os.path.join(smoke_reports, 'phase_d_dat_smoke_report_{0}.json'.format(other))
            with open(smoke_txt, 'w', encoding='utf-8') as f:
                f.write('x')
            with open(smoke_json, 'w', encoding='utf-8') as f:
                json.dump({'anchor_run_id': other, 'assessment': 'dat_selected_qa_blocked'}, f)
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': smoke_txt,
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertTrue(any('run_evidence_smoke_anchor_mismatch_' in os.path.basename(p) for p in paths))
            self.assertFalse(any(os.path.basename(p).startswith('phase_d_dat_smoke_report') for p in paths))
            note_path = next(p for p in paths if 'run_evidence_smoke_anchor_mismatch_' in os.path.basename(p))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('smoke_state_last_status=completed', body)
            self.assertIn('smoke_state_last_assessment=dat_selected_qa_blocked', body)
            self.assertIn('smoke_report_anchor_mismatch', body)

    def test_phase_d_dat_smoke_paths_qa_full_block_missing_report_still_emits_note(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            reviewed = '20260329-171213-1ccb1c51'
            state_path = os.path.join(lab, 'phase_d_dat_smoke_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_status': 'completed',
                    'last_report_path': '',
                    'last_assessment': 'dat_selected_qa_blocked',
                }, f)
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommendation_anchor_run_id': reviewed,
                'action_preview': {'anchor_run_id': reviewed},
            }
            paths = cr._phase_d_dat_smoke_report_paths_for_run_evidence(repo, lab, rec, reviewed)
            self.assertEqual(len(paths), 1)
            note_path = paths[0]
            self.assertIn('run_evidence_smoke_anchor_mismatch_', os.path.basename(note_path))
            with open(note_path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('last_report_path=-', body)
            self.assertIn('state_last_report_path_missing', body)
            self.assertIn('smoke_report_anchor_run_id_missing', body)

    def test_phase_d_reprocess_paths_for_run_evidence_skips_metadata_mismatch(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D Re-Evaluation\n')
                    f.write('remediation_context_run_id=wrong-run\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_legacy_without_metadata_returns_empty(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            for name in (
                    'phase_d_historical_reprocess_preview_latest.txt',
                    'phase_d_historical_reprocess_execution_latest.txt'):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('legacy pre-upgrade body\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'bundle-b')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_preview_only_missing_execution_returns_empty(self):
        """Preview-only historical reprocess report is surfaced elsewhere, not in run-evidence ZIP rules."""
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            with open(prev, 'w', encoding='utf-8') as f:
                f.write('Historical Phase D Re-Evaluation Preview\nremediation_context_run_id=anchor-z\n')
            rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'recommendation_anchor_run_id': 'anchor-z',
                'historical_reprocess_preview_path': prev,
            }
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, 'anchor-z')
            self.assertEqual(paths, [])

    def test_phase_d_reprocess_paths_attaches_when_preview_execution_agree_and_match_bundle(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'bundle-match-1'
            prev = os.path.join(reports, 'phase_d_historical_reprocess_preview_latest.txt')
            exe = os.path.join(reports, 'phase_d_historical_reprocess_execution_latest.txt')
            for p in (prev, exe):
                with open(p, 'w', encoding='utf-8') as f:
                    f.write('Historical Phase D\nremediation_context_run_id={0}\n'.format(rid))
            rec = {'recommended_action_kind': 'historical_phase_d_reprocess'}
            paths = cr._phase_d_reprocess_report_paths_for_run_evidence(lab, rec, rid)
            self.assertEqual(len(paths), 2)
            self.assertIn(prev, paths)
            self.assertIn(exe, paths)

    def test_latest_interrupt_report_paths_filters_mismatched_bundle_run_id(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as lab:
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            jpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.json')
            with open(jpath, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'run_id': 'run-a'}))
            tpath = os.path.join(reports, 'shadow_pipeline_interrupt_latest.txt')
            with open(tpath, 'w', encoding='utf-8') as f:
                f.write('interrupt txt')
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-b')), 0)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab, bundle_run_id='run-a')), 2)
            self.assertEqual(len(cr._latest_interrupt_report_paths(lab)), 2)

    def test_collect_phase_d_reject_snapshot_dedupes_artifact_ids_across_qa_versions(self):
        from scripts.unified_model.phase_d_historical_reprocess import collect_phase_d_reject_snapshot
        with tempfile.TemporaryDirectory() as lab:
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.execute(
                'CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY, source_type TEXT, payload_json TEXT)')
            conn.execute(
                'CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, qa_version TEXT, status TEXT)')
            conn.execute('CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
            conn.execute('INSERT INTO ingest_artifact VALUES (1, "file_dat", "{}")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v1", "reject")')
            conn.execute('INSERT INTO qa_result VALUES (1, "phase_d", "qa_v2", "reject")')
            conn.commit()
            conn.close()
            snap = collect_phase_d_reject_snapshot(lab, qa_version=None)
            self.assertTrue(snap.get('ok'))
            self.assertEqual(snap.get('targeted_artifact_count'), 1)
            self.assertEqual(snap.get('targeted_artifact_ids'), [1])
            self.assertEqual(snap.get('reject_counts_by_class', {}).get('dat'), 2)

    def test_compute_operator_support_send_recommendation_invokes_selector_with_pack_context(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'shadow_report_path': '',
            }):
                with patch.object(cr, '_build_system_health_pack_context', return_value={
                    'pack_scope': 'mixed_scope',
                    'anchor_run_id': 'anchor-rid',
                }):
                    with patch.object(cr, '_select_evaluation_snapshot_for_recommendation') as mock_sel:
                        mock_sel.return_value = (
                            True,
                            '',
                            {'run_id': 'anchor-rid', 'diagnostics_state': {}, 'lab_root': lab},
                            {
                                'live_run_id': 'live-rid',
                                'recommendation_source_scope': 'anchored_completed_run',
                                'recommendation_anchor_run_id': 'anchor-rid',
                                'fallback_note': '',
                                'newer_live_context_note': '',
                            },
                        )
                        with patch.object(cr, 'compute_operator_support_send_recommendation_core') as mock_core:
                            mock_core.return_value = {'summary_line': 'ok'}
                            cr.compute_operator_support_send_recommendation(repo)
        mock_sel.assert_called_once()
        self.assertEqual(mock_core.call_args[0][1].get('run_id'), 'anchor-rid')
        kwargs = mock_core.call_args[1]
        self.assertEqual(kwargs.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(kwargs.get('recommendation_anchor_run_id'), 'anchor-rid')
        self.assertEqual(kwargs.get('recommendation_live_run_id'), 'live-rid')

    def test_select_evaluation_snapshot_live_run_id_prefers_diagnostics_over_artifact_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            state_path = os.path.join(lab, 'diagnostics_state.json')
            with open(state_path, 'w', encoding='utf-8') as f:
                f.write(json.dumps({'active_run_id': 'run-a', 'last_shadow_pipeline_run_id': ''}))
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', {'run_id': 'run-b'})):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, _msg, _snap, meta = cr._select_evaluation_snapshot_for_recommendation(repo, {})
            self.assertEqual(meta.get('live_run_id'), 'run-a')

    def test_relax_anchor_clears_coherence_block_for_conflicting_live_diagnostics(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other-run',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))

    def test_relax_anchor_clears_lineage_issues_for_handoff_coherence(self):
        """Zero-selection / phase_run_id skew surfaces as lineage_issues; anchor eval must ignore it."""
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        anchor_id = '20260331-005932-ba25d2aa'
        anchor_snap = {
            'run_id': anchor_id,
            'diagnostics_state': {},
            'lineage_issues': [
                'phase_d_zero_selection_phase_c_run_id_mismatch expected_phase_c=old resolved_phase_c=new',
            ],
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(anchor_snap))
        relaxed = cr._relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
        self.assertFalse(art.artifact_snapshot_coherence_blocked(relaxed))
        self.assertEqual(relaxed.get('lineage_issues'), [])

    def test_select_evaluation_snapshot_returns_relaxed_anchor_for_mixed_scope(self):
        from MediCafe import cloud_readiness as cr
        anchor_id = '20260329-171213-1ccb1c51'
        anchor_snap_raw = {
            'run_id': anchor_id,
            'lab_root': '/tmp',
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': 'other',
                'last_shadow_pipeline_run_id': 'zzz',
            },
        }
        latest = {'run_id': 'older-artifact-run', 'diagnostics_state': {}}

        def fake_build(repo_root, run_id=''):
            rid = str(run_id or '').strip()
            if rid == anchor_id:
                return True, '', dict(anchor_snap_raw)
            return True, '', dict(latest)

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            with patch.object(cr, '_build_run_artifact_snapshot', side_effect=fake_build):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    ok, msg, snap, meta = cr._select_evaluation_snapshot_for_recommendation(
                        repo,
                        {'pack_scope': 'mixed_scope', 'anchor_run_id': anchor_id},
                    )
        self.assertTrue(ok)
        self.assertEqual(meta.get('recommendation_source_scope'), 'anchored_completed_run')
        self.assertEqual(snap.get('run_id'), anchor_id)
        self.assertEqual(str(snap.get('diagnostics_state', {}).get('pipeline_state')), 'completed')

    def test_run_phase_d_dat_smoke_returns_already_running_before_spawn(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')
            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=True):
                    with patch.object(cr.subprocess, 'Popen') as mock_popen:
                        ok, msg, meta = cr.run_phase_d_dat_smoke(repo, sys.executable, {})
        self.assertFalse(ok)
        self.assertIn('already running', msg.lower())
        self.assertTrue(bool((meta or {}).get('already_running')))
        mock_popen.assert_not_called()

    def test_run_phase_d_dat_smoke_spawn_failure_transitions_to_failed_without_cooldown(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            script_root = os.path.join(repo, 'scripts')
            script_path = os.path.join(script_root, 'run_phase_d_dat_smoke.py')
            os.makedirs(script_root)
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write('# stub\n')

            state_path = cr.phase_d_dat_smoke_state_path(repo)
            parent = os.path.dirname(state_path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
            with open(state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_requested_anchor_run_id': 'old-anchor',
                    'last_requested_context_run_id': 'old-context',
                    'last_remediation_issue_code': 'OLD_ISSUE',
                    'last_status': 'completed',
                    'cooldown_until_utc': '2999-01-01T00:00:00Z',
                }, f)

            with patch.object(
                    cr,
                    '_resolve_unified_model_script',
                    return_value=(True, '', script_root, script_path, None)):
                with patch.object(cr, 'is_pipeline_running', return_value=False):
                    with patch.object(cr.subprocess, 'Popen', side_effect=RuntimeError('spawn failed')):
                        ok, msg, _meta = cr.run_phase_d_dat_smoke(
                            repo,
                            sys.executable,
                            {},
                            recommendation_anchor_run_id='anchor-new',
                            recommendation_context_run_id='ctx-new',
                            recommendation_issue_code='ISSUE_NEW',
                        )

            self.assertFalse(ok)
            self.assertIn('spawn failed', msg.lower())
            state = cr.read_phase_d_dat_smoke_state(repo)
            self.assertEqual(state.get('last_requested_anchor_run_id'), 'anchor-new')
            self.assertEqual(state.get('last_requested_context_run_id'), 'ctx-new')
            self.assertEqual(state.get('last_remediation_issue_code'), 'ISSUE_NEW')
            self.assertEqual(str(state.get('last_status', '')).lower(), 'failed')
            self.assertEqual(state.get('last_assessment'), 'spawn_failed')
            self.assertEqual(state.get('cooldown_until_utc'), '')
            self.assertTrue(bool(state.get('last_finished_at_utc')))
            self.assertFalse(
                cr._phase_d_dat_smoke_state_suppressed(state, 'anchor-new', 'ctx-new', 'ISSUE_NEW')
            )



class TestPhaseDRemediationOperatorSurfaces(unittest.TestCase):
    """phase_d_remediation formatting and recommendation merge; keeps operator surfaces aligned with phase_d_remediation.py."""

    def test_format_phase_d_remediation_surfaces_emits_stable_tokens(self):
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        rem = {
            'verification_target': 'phase_d_constraint_skips',
            'verification_scope': 'global_phase_d',
            'milestone_exit_ready': False,
            'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
            'status': 'active',
            'context_run_id': 'run-x',
        }
        lines = format_phase_d_remediation_surfaces(rem)
        joined = '\n'.join(lines)
        self.assertIn('phase_d_remediation: verification_target=phase_d_constraint_skips', joined)
        self.assertIn('phase_d_remediation: verification_scope=global_phase_d', joined)
        self.assertIn('phase_d_remediation: milestone_exit_ready=False', joined)
        self.assertIn('phase_d_remediation: issue_code=', joined)
        self.assertIn('phase_d_remediation glossary:', joined)

    def test_format_phase_d_remediation_surfaces_emits_shape_family_counts(self):
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        rem = {
            'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
            'status': 'active',
            'context_run_id': 'run-shapes',
            'confidence_inputs': {
                'invalid_external_id_shape_family_counts': {
                    'wrong_length_short': 3,
                    'blank/placeholder': 1,
                    'non_numeric': 0,
                },
            },
        }
        joined = '\n'.join(format_phase_d_remediation_surfaces(rem))
        self.assertIn(
            'phase_d_remediation: invalid_external_id_shape_families=wrong_length_short:3,blank/placeholder:1',
            joined,
        )
        self.assertNotIn('non_numeric:0', joined)
        self.assertNotIn('3712', joined)

    def test_compute_operator_support_send_recommendation_core_merges_phase_d_remediation(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe.cloud_readiness_artifact_tools import format_phase_d_remediation_surfaces
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(lab)
            rem = {
                'version': 1,
                'issue_code': 'PHASE_D_INVALID_EXTERNAL_ID_SPIKE',
                'status': 'active',
                'context_run_id': 'rid-1',
                'verification_target': 'phase_d_constraint_skips',
                'verification_scope': 'global_phase_d',
                'milestone_exit_ready': False,
            }
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                f.write(json.dumps({'phase_d_remediation': rem}))
            # Positional order: repo_root, evaluation_snapshot, ok_snap, snap_msg, pipeline_running, ...
            out = cr.compute_operator_support_send_recommendation_core(
                repo,
                {'run_id': 'rid-1', 'nearest_complete_run_id': ''},
                ok_snap=False,
                snap_msg='no snapshot',
                pipeline_running=False,
            )
        self.assertEqual(out.get('phase_d_remediation'), rem)
        self.assertFalse(out.get('pipeline_running'))
        self.assertEqual(out.get('pipeline_label'), 'idle')
        expected_extra = format_phase_d_remediation_surfaces(rem)
        why = out.get('why_lines') or []
        for line in expected_extra:
            self.assertIn(line, why)

    def test_build_patient_trace_decision_surfaces_phase_d_remediation_keys(self):
        from MediCafe.cloud_readiness_patient_tools import build_patient_trace_decision
        selected = {
            'missing_fields': [],
            'reason': 'test',
            'claim_count': 1,
            'canonical_count': 1,
            'projection_reject_count': 0,
        }
        trace = {'rows': {'qa_result': [], 'replay_queue': []}}
        pdr = {
            'issue_code': 'PHASE_D_DAT_QA_FULL_BLOCK',
            'status': 'active',
            'context_run_id': 'anchor-rid',
            'verification_target': 'phase_d_dat_lane',
            'verification_scope': 'dat_lane_only',
            'milestone_exit_ready': None,
        }
        diag_state = {'phase_d_remediation': pdr}
        result = build_patient_trace_decision(selected, trace, diag_state)
        d = result.get('diagnostics') if isinstance(result.get('diagnostics'), dict) else {}
        self.assertEqual(d.get('phase_d_remediation_issue_code'), 'PHASE_D_DAT_QA_FULL_BLOCK')
        self.assertEqual(d.get('phase_d_remediation_status'), 'active')
        self.assertEqual(d.get('phase_d_remediation_context_run_id'), 'anchor-rid')
        self.assertEqual(d.get('phase_d_remediation_verification_target'), 'phase_d_dat_lane')
        self.assertEqual(d.get('phase_d_remediation_verification_scope'), 'dat_lane_only')
        self.assertIsNone(d.get('phase_d_remediation_milestone_exit_ready'))

