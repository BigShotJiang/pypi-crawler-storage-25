import setuptools

# Read README.md for long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="HackFlyDrone",  # Replace with your desired PyPI package name (must be unique)
    version="0.0.1",  # Initial version number
    author="tanjianyu",  # Replace with your name
    author_email="tanjianyu@hack-fly.com",  # Replace with your email
    description="可编程无人机",  # Short description
    long_description=long_description, # Use README.md as long description
    packages=setuptools.find_packages(), # Automatically find package directories
    classifiers=[ # Package classifiers
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License", # Ensure this matches your LICENSE file
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6', # Specify compatible Python versions
)
