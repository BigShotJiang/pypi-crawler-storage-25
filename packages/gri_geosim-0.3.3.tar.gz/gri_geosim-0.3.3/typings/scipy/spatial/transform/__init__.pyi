from typing import Self

import numpy as np
from numpy.typing import ArrayLike, NDArray

class Rotation:
    @classmethod
    def identity(cls, num: int | None = None) -> Self: ...
    @classmethod
    def from_quat(
        cls,
        quat: ArrayLike,
        *,
        scalar_first: bool = False,
    ) -> Self: ...
    @classmethod
    def from_matrix(cls, matrix: ArrayLike) -> Self: ...
    @classmethod
    def from_euler(
        cls,
        seq: str,
        angles: ArrayLike,
        degrees: bool = False,
    ) -> Self: ...
    @classmethod
    def from_rotvec(
        cls,
        rotvec: ArrayLike,
        degrees: bool = False,
    ) -> Self: ...
    def as_quat(
        self,
        canonical: bool = False,
        *,
        scalar_first: bool = False,
    ) -> NDArray[np.floating]: ...
    def as_matrix(self) -> NDArray[np.floating]: ...
    def as_euler(
        self,
        seq: str,
        degrees: bool = False,
    ) -> NDArray[np.floating]: ...
    def as_rotvec(
        self,
        degrees: bool = False,
    ) -> NDArray[np.floating]: ...
    def inv(self) -> Self: ...
    def apply(
        self,
        vectors: ArrayLike,
        inverse: bool = False,
    ) -> NDArray[np.floating]: ...
    def __mul__(self, other: Self) -> Self: ...
    def __len__(self) -> int: ...
    @property
    def single(self) -> bool: ...

class Slerp:
    def __init__(self, times: ArrayLike, rotations: Rotation) -> None: ...
    def __call__(self, times: ArrayLike) -> Rotation: ...

__all__ = ["Rotation", "Slerp"]
