# Partial stub for scipy.spatial
