"""TDOA+AOA geolocation solver.

Estimates 3D target position from combined Time Difference of Arrival and
Angle of Arrival measurements using weighted nonlinear least squares with
analytical Jacobians.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from gri_utils.geolocation import default_initial_guess, whitened_least_squares
from gri_utils.observables import aoa_quat_with_gradient, tdoa_with_gradient
from scipy.linalg import block_diag
from scipy.spatial.transform import Rotation

from .aoa_locator import aoa_locator
from .locator_result import NAN_VELOCITY, LocatorResult
from .tdoa_locator import tdoa_locator

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def tdoa_aoa_locator(  # noqa: PLR0913
    tdoa_collector1_xyz: NDArray[np.floating] | Sequence | None = None,
    tdoa_collector2_xyz: NDArray[np.floating] | Sequence | None = None,
    tdoa_measurements: NDArray[np.floating] | Sequence | None = None,
    tdoa_variances: NDArray[np.floating] | Sequence | None = None,
    aoa_collector_xyz: NDArray[np.floating] | Sequence | None = None,
    aoa_rotations: NDArray[np.floating] | Sequence | Rotation | None = None,
    aoa_measurements: NDArray[np.floating] | Sequence | None = None,
    aoa_covariances: NDArray[np.floating] | Sequence | None = None,
    xyz0: NDArray[np.floating] | Sequence | None = None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Geolocate a target from combined TDOA and AOA observations.

    Uses weighted nonlinear least squares with analytical Jacobians to estimate
    the 3D target position from mixed angle-of-arrival and time-difference-of-
    arrival measurements.

    Hybrid geolocation is beneficial when:
    - Neither AOA nor TDOA alone provides sufficient measurements for
      well-conditioned 3D positioning
    - AOA and TDOA have complementary geometric strengths (AOA is typically
      stronger in cross-range, TDOA in range)
    - Combining observables improves dilution of precision (DOP)

    If only AOA or only TDOA measurements are provided, this function delegates
    to the corresponding single-observable locator.

    Note:
        This implementation assumes AOA and TDOA measurement errors are
        uncorrelated (block-diagonal covariance). If AOA and TDOA collectors
        share platforms, there may be position-induced correlations between
        measurement errors that this model does not capture. For such cases,
        consider constructing a full covariance matrix and using
        whitened_least_squares directly.

    Args:
        tdoa_collector1_xyz: First TDOA collector positions in ECEF meters.
            Shape (N_tdoa, 3). None if no TDOA measurements.
        tdoa_collector2_xyz: Second TDOA collector positions in ECEF meters.
            Shape (N_tdoa, 3). None if no TDOA measurements.
        tdoa_measurements: Measured TDOAs in seconds. Shape (N_tdoa,).
            None if no TDOA measurements.
        tdoa_variances: Variance of each TDOA measurement in seconds**2.
            Shape (N_tdoa,). None if no TDOA measurements.
        aoa_collector_xyz: AOA collector positions in ECEF meters.
            Shape (N_aoa, 3). None if no AOA measurements.
        aoa_rotations: AOA collector orientations as quaternions [x, y, z, w]
            (scipy convention, scalar-last). Shape (N_aoa, 4) or scipy Rotation.
            None if no AOA measurements.
        aoa_measurements: Measured AOA direction cosines (X, Y components of
            unit vector in collector's local frame). Shape (N_aoa, 2).
            None if no AOA measurements.
        aoa_covariances: Covariance of each AOA measurement.
            Shape (N_aoa, 2, 2). None if no AOA measurements.
        xyz0: Initial guess for target position in ECEF meters. Shape (3,).
            If None, uses centroid of all collectors clamped to Earth radius.
        **least_squares_kwargs: Additional arguments passed to
            scipy.optimize.least_squares (e.g., bounds, method, ftol, xtol).

    Returns:
        LocatorResult with:
            - position: Estimated target position in ECEF meters. Shape (3,).
            - velocity: NaN values (velocity not estimated). Shape (3,).
            - covariance: 3x3 position covariance matrix in ECEF.
            - chi_squared: Sum of squared whitened residuals.

    Raises:
        ValueError: If no measurements provided.
        ValueError: If AOA inputs are partially specified.
        ValueError: If TDOA inputs are partially specified.
        ValueError: If insufficient observations for 3D positioning.
        LinAlgError: If solution covariance is singular (poor geometry).

    Example:
        >>> import numpy as np
        >>> from scipy.spatial.transform import Rotation
        >>> from gri_utils.geolocation import tdoa_aoa_locator
        >>>
        >>> # Two TDOA pairs
        >>> c1 = np.array([6378137.0, 1000.0, 0.0])
        >>> c2 = np.array([6378137.0, 0.0, 1000.0])
        >>> c3 = np.array([6378137.0, -1000.0, 0.0])
        >>> tdoa_c1 = np.array([c1, c1])
        >>> tdoa_c2 = np.array([c2, c3])
        >>> tdoa_meas = np.array([1e-6, 2e-6])
        >>> tdoa_var = np.full(2, (10e-9)**2)
        >>>
        >>> # One AOA collector
        >>> aoa_xyz = np.array([[6378137.0, 0.0, 0.0]])
        >>> aoa_rot = Rotation.identity(1)
        >>> aoa_meas = np.array([[0.1, 0.2]])
        >>> aoa_cov = np.array([np.eye(2) * 0.001**2])
        >>>
        >>> result = tdoa_aoa_locator(
        ...     tdoa_collector1_xyz=tdoa_c1,
        ...     tdoa_collector2_xyz=tdoa_c2,
        ...     tdoa_measurements=tdoa_meas,
        ...     tdoa_variances=tdoa_var,
        ...     aoa_collector_xyz=aoa_xyz,
        ...     aoa_rotations=aoa_rot,
        ...     aoa_measurements=aoa_meas,
        ...     aoa_covariances=aoa_cov,
        ... )
        >>> print(result.position, result.chi_squared)
    """
    # Determine which measurement types are present
    has_aoa = aoa_measurements is not None
    has_tdoa = tdoa_measurements is not None

    # Validate AOA inputs are all-or-nothing
    aoa_inputs = [
        aoa_collector_xyz,
        aoa_rotations,
        aoa_measurements,
        aoa_covariances,
    ]
    aoa_none_count = sum(x is None for x in aoa_inputs)
    if aoa_none_count not in (0, 4):
        msg = "AOA inputs must be all provided or all None"
        raise ValueError(msg)

    # Validate TDOA inputs are all-or-nothing
    tdoa_inputs = [
        tdoa_collector1_xyz,
        tdoa_collector2_xyz,
        tdoa_measurements,
        tdoa_variances,
    ]
    tdoa_none_count = sum(x is None for x in tdoa_inputs)
    if tdoa_none_count not in (0, 4):
        msg = "TDOA inputs must be all provided or all None"
        raise ValueError(msg)

    # Must have at least one measurement type
    if not has_aoa and not has_tdoa:
        msg = "At least one of AOA or TDOA measurements must be provided"
        raise ValueError(msg)

    # Delegate to single-observable locators if only one type present
    if has_aoa and not has_tdoa:
        return aoa_locator(
            aoa_collector_xyz,  # type: ignore[arg-type]
            aoa_rotations,  # type: ignore[arg-type]
            aoa_measurements,  # type: ignore[arg-type]
            aoa_covariances,  # type: ignore[arg-type]
            xyz0=xyz0,
            **least_squares_kwargs,
        )

    if has_tdoa and not has_aoa:
        return tdoa_locator(
            tdoa_collector1_xyz,  # type: ignore[arg-type]
            tdoa_collector2_xyz,  # type: ignore[arg-type]
            tdoa_measurements,  # type: ignore[arg-type]
            tdoa_variances,  # type: ignore[arg-type]
            xyz0=xyz0,
            **least_squares_kwargs,
        )

    # Both AOA and TDOA present - build hybrid solver
    return _hybrid_solve(
        aoa_collector_xyz,  # type: ignore[arg-type]
        aoa_rotations,  # type: ignore[arg-type]
        aoa_measurements,  # type: ignore[arg-type]
        aoa_covariances,  # type: ignore[arg-type]
        tdoa_collector1_xyz,  # type: ignore[arg-type]
        tdoa_collector2_xyz,  # type: ignore[arg-type]
        tdoa_measurements,  # type: ignore[arg-type]
        tdoa_variances,  # type: ignore[arg-type]
        xyz0,
        **least_squares_kwargs,
    )


def _validate_hybrid_shapes(  # noqa: PLR0913
    n_aoa: int,
    n_tdoa: int,
    aoa_measurements: NDArray[np.floating],
    aoa_covariances: NDArray[np.floating],
    tdoa_collector1_xyz: NDArray[np.floating],
    tdoa_collector2_xyz: NDArray[np.floating],
    tdoa_variances: NDArray[np.floating],
) -> None:
    """Validate array shapes for hybrid locator inputs."""
    if aoa_measurements.shape != (n_aoa, 2):
        msg = f"aoa_measurements shape {aoa_measurements.shape} != ({n_aoa}, 2)"
        raise ValueError(msg)
    if aoa_covariances.shape != (n_aoa, 2, 2):
        msg = f"aoa_covariances shape {aoa_covariances.shape} != ({n_aoa}, 2, 2)"
        raise ValueError(msg)
    if tdoa_collector1_xyz.shape != (n_tdoa, 3):
        msg = f"tdoa_collector1_xyz shape {tdoa_collector1_xyz.shape} != ({n_tdoa}, 3)"
        raise ValueError(msg)
    if tdoa_collector2_xyz.shape != (n_tdoa, 3):
        msg = f"tdoa_collector2_xyz shape {tdoa_collector2_xyz.shape} != ({n_tdoa}, 3)"
        raise ValueError(msg)
    if tdoa_variances.shape != (n_tdoa,):
        msg = f"tdoa_variances shape {tdoa_variances.shape} != ({n_tdoa},)"
        raise ValueError(msg)


def _hybrid_solve(  # noqa: PLR0913
    aoa_collector_xyz: NDArray[np.floating] | Sequence,
    aoa_rotations: NDArray[np.floating] | Sequence | Rotation,
    aoa_measurements: NDArray[np.floating] | Sequence,
    aoa_covariances: NDArray[np.floating] | Sequence,
    tdoa_collector1_xyz: NDArray[np.floating] | Sequence,
    tdoa_collector2_xyz: NDArray[np.floating] | Sequence,
    tdoa_measurements: NDArray[np.floating] | Sequence,
    tdoa_variances: NDArray[np.floating] | Sequence,
    xyz0: NDArray[np.floating] | Sequence | None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Internal hybrid solver for combined AOA+TDOA."""
    # Convert to numpy arrays
    aoa_collector_xyz = np.asarray(aoa_collector_xyz)
    aoa_measurements = np.asarray(aoa_measurements)
    aoa_covariances = np.asarray(aoa_covariances)
    tdoa_collector1_xyz = np.asarray(tdoa_collector1_xyz)
    tdoa_collector2_xyz = np.asarray(tdoa_collector2_xyz)
    tdoa_measurements = np.asarray(tdoa_measurements)
    tdoa_variances = np.asarray(tdoa_variances)

    # Handle Rotation objects
    rotation = (
        aoa_rotations
        if isinstance(aoa_rotations, Rotation)
        else Rotation.from_quat(np.asarray(aoa_rotations))
    )

    n_aoa = aoa_collector_xyz.shape[0]
    n_tdoa = tdoa_measurements.shape[0]

    _validate_hybrid_shapes(
        n_aoa,
        n_tdoa,
        aoa_measurements,
        aoa_covariances,
        tdoa_collector1_xyz,
        tdoa_collector2_xyz,
        tdoa_variances,
    )

    # Validate sufficient observations for 3D positioning
    # Each AOA provides 2 observations (direction cosines), each TDOA provides 1
    total_observations = 2 * n_aoa + n_tdoa
    min_observations = 3
    if total_observations < min_observations:
        msg = (
            f"Need {min_observations}+ observations for 3D positioning, "
            f"got {total_observations} (from {n_aoa} AOA + {n_tdoa} TDOA)"
        )
        raise ValueError(msg)

    # Build block-diagonal covariance matrix
    # Structure: [AOA_0 (2x2), AOA_1 (2x2), ..., TDOA (NxN diagonal)]
    full_covariance = block_diag(*list(aoa_covariances), np.diag(tdoa_variances))
    aoa_measurements_flat = aoa_measurements.ravel()

    def residual_and_jacobian(
        x: NDArray[np.floating],
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute combined residual and Jacobian."""
        # AOA component
        aoa_pred, aoa_jacs = aoa_quat_with_gradient(aoa_collector_xyz, x, rotation)
        aoa_residual = aoa_measurements_flat - aoa_pred.ravel()
        aoa_jacobian = -aoa_jacs.reshape(-1, 3)

        # TDOA component
        tdoa_predicted = np.empty(n_tdoa)
        tdoa_jacobian = np.empty((n_tdoa, 3))
        for i in range(n_tdoa):
            tdoa_predicted[i], tdoa_jacobian[i] = tdoa_with_gradient(
                x,
                tdoa_collector1_xyz[i],
                tdoa_collector2_xyz[i],
            )
        tdoa_residual = tdoa_measurements - tdoa_predicted

        return (
            np.concatenate([aoa_residual, tdoa_residual]),
            np.vstack([aoa_jacobian, -tdoa_jacobian]),
        )

    # Default initial guess from all collectors
    if xyz0 is None:
        all_collectors = np.vstack(
            [aoa_collector_xyz, tdoa_collector1_xyz, tdoa_collector2_xyz],
        )
        initial_guess = default_initial_guess(all_collectors)
    else:
        initial_guess = np.asarray(xyz0)

    position, covariance, chi_squared = whitened_least_squares(
        residual_and_jacobian,
        initial_guess,
        full_covariance,
        **least_squares_kwargs,
    )

    return LocatorResult(position, NAN_VELOCITY, covariance, chi_squared)
