"""Time Difference of Arrival (TDOA) sensor for paired-platform measurements.

A TDOA sensor measures the difference in signal arrival time between two
platforms. This requires a paired platform to be set - the measurement is
the time difference between this sensor's platform and the paired platform.

TDOA = (range1 - range2) / c

where range1 is the distance from emitter to this sensor's platform, and
range2 is the distance from emitter to the paired platform.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from gri_obs import TdoaObs
from gri_utils.observables import get_tdoa

from gri_geosim.atmosphere import compute_differential_atmospheric_delay

from .sensor import Sensor

if TYPE_CHECKING:
    from gri_nsepoch import Time

    from gri_geosim.atmosphere import AtmosphereConfig
    from gri_geosim.emitter import Emitter
    from gri_geosim.platform import Platform

    from .constraints import FovConstraint


class TdoaSensor(Sensor):
    """Time Difference of Arrival sensor for paired-platform measurements.

    Measures the difference in signal arrival time between this sensor's
    platform and a paired platform. Requires set_paired_platform() to be
    called before observations can be made.

    The noise model is Gaussian with a single standard deviation value.

    Attributes:
        tdoa_std_s: Standard deviation of TDOA measurement in seconds.
        paired_platform: The second platform for TDOA computation.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_geosim import Platform
        >>> # Create two ground stations
        >>> ground1 = Platform.stationary(Pos.LLA(38.0, -77.0, 100.0), name="GND1")
        >>> ground2 = Platform.stationary(Pos.LLA(39.0, -76.0, 100.0), name="GND2")
        >>>
        >>> # Create TDOA sensor on first station, paired with second
        >>> tdoa = TdoaSensor(tdoa_std_s=1e-9)  # 1 ns accuracy
        >>> ground1.add_sensor(tdoa)
        >>> tdoa.set_paired_platform(ground2)
    """

    __slots__ = ("_paired_platform", "_tdoa_std_s")

    _TYPE_PREFIX = "TDOA"

    def __init__(
        self,
        sensor_id: str | None = None,
        *,
        tdoa_std_s: float = 1e-9,
        fov: FovConstraint | None = None,
        apply_atmosphere: Literal["auto"] | bool = "auto",
        rng_seed: int | None = None,
    ) -> None:
        """Initialize a TDOA sensor.

        Args:
            sensor_id: Unique identifier for this sensor. If None, an ID
                is auto-generated (e.g., "TDOA-1").
            tdoa_std_s: Standard deviation of TDOA noise in seconds.
                Defaults to 1e-9 s (1 nanosecond).
            fov: Field of view constraint. Defaults to NoFov (no constraint).
            apply_atmosphere: Controls atmospheric correction application.
                - "auto": Apply for ground-to-space paths only (default)
                - True: Always apply if atmosphere config provided
                - False: Never apply atmospheric corrections
            rng_seed: Optional seed for the random number generator.

        Raises:
            ValueError: If tdoa_std_s is not positive.
        """
        super().__init__(
            sensor_id,
            fov=fov,
            apply_atmosphere=apply_atmosphere,
            rng_seed=rng_seed,
        )

        if tdoa_std_s <= 0:
            raise ValueError(f"tdoa_std_s must be positive, got {tdoa_std_s}")

        self._tdoa_std_s = tdoa_std_s
        self._paired_platform: Platform | None = None

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def tdoa_std_s(self) -> float:
        """Standard deviation of TDOA measurement in seconds."""
        return self._tdoa_std_s

    @property
    def tdoa_std_ns(self) -> float:
        """Standard deviation of TDOA measurement in nanoseconds."""
        return self._tdoa_std_s * 1e9

    @property
    def paired_platform(self) -> Platform | None:
        """The paired platform for TDOA computation."""
        return self._paired_platform

    # =========================================================================
    # Configuration
    # =========================================================================

    def set_paired_platform(self, platform: Platform) -> None:
        """Set the paired platform for TDOA computation.

        The TDOA measurement will be the time difference between this
        sensor's platform and the paired platform.

        Args:
            platform: The second platform for TDOA computation.

        Raises:
            ValueError: If platform is the same as the sensor's platform.
        """
        if self._platform is not None and platform is self._platform:
            raise ValueError("Paired platform cannot be the same as sensor's platform")
        self._paired_platform = platform

    # =========================================================================
    # Observation methods
    # =========================================================================

    def can_observe(self, emitter: Emitter, time: Time) -> bool:
        """Check if the sensor can observe the emitter at this time.

        Checks that:
        1. The sensor is attached to a platform
        2. A paired platform has been set
        3. The emitter is within this sensor's field of view

        Note: Does not check if emitter is visible to paired platform.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.

        Returns:
            True if observation is possible.
        """
        if self._platform is None:
            return False
        if self._paired_platform is None:
            return False
        return self.is_in_fov(emitter, time)

    def observe(
        self,
        emitter: Emitter,
        time: Time,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> TdoaObs | None:
        """Generate a TDOA observation of the emitter.

        Computes the time difference of arrival between this sensor's
        platform and the paired platform, optionally adding atmospheric
        effects and Gaussian noise.

        TDOA = (range_to_this - range_to_paired) / c + atmospheric_differential

        Positive value means signal arrives at paired platform first.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.
            add_noise: If True, add Gaussian measurement noise.
            atmosphere: Optional atmospheric configuration for path delay
                corrections. If None, no atmospheric effects are applied.

        Returns:
            A TdoaObs, or None if not observable.
        """
        if not self.can_observe(emitter, time):
            return None

        # Get positions
        platform1_pos = self._platform.position_at(time)  # type: ignore[union-attr]
        platform2_pos = self._paired_platform.position_at(time)  # type: ignore[union-attr]
        emitter_pos = emitter.position_at(time)

        # Compute geometric TDOA using gri-utils
        tdoa = get_tdoa(
            emitter_pos.xyz,
            platform1_pos.xyz,
            platform2_pos.xyz,
        )
        tdoa_value = float(tdoa)

        # Apply atmospheric corrections if configured and appropriate
        # For TDOA, check if either path is ground-to-space
        if atmosphere is not None and (
            atmosphere.enable_tropo or atmosphere.enable_iono
        ):
            path1_applies = self._should_apply_atmosphere(platform1_pos, emitter_pos)
            path2_applies = self._should_apply_atmosphere(platform2_pos, emitter_pos)

            if path1_applies or path2_applies:
                atmo_delay = compute_differential_atmospheric_delay(
                    emitter_pos,
                    platform1_pos,
                    platform2_pos,
                    emitter.frequency_hz,
                    time,
                    atmosphere,
                )
                tdoa_value += atmo_delay

        # Add noise if requested
        if add_noise:
            noise = self._rng.normal(0.0, self._tdoa_std_s)
            tdoa_value += noise

        return TdoaObs(
            time=time,
            value=tdoa_value,
            std_dev=self._tdoa_std_s,
            collector1=platform1_pos,
            collector2=platform2_pos,
            sensor_id=self._sensor_id,
            emitter_id=emitter.name if emitter.name else None,
        )

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        paired = self._paired_platform.name if self._paired_platform else "None"
        return (
            f"TdoaSensor(id='{self._sensor_id}', "
            f"std={self.tdoa_std_ns:.1f}ns, "
            f"paired='{paired}')"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        paired = self._paired_platform.name if self._paired_platform else "unset"
        return (
            f"TDOA Sensor '{self._sensor_id}' "
            f"(std={self.tdoa_std_ns:.1f} ns, paired with {paired})"
        )
