"""Frequency Difference of Arrival (FDOA) sensor for Doppler-based measurements.

An FDOA sensor measures the difference in Doppler shift observed at two
platforms. This requires a paired platform and knowledge of platform
velocities. The measurement is sensitive to the relative motion between
emitter and both platforms.

FDOA = f0/c * ((v_emit - v_coll1) * unit1 - (v_emit - v_coll2) * unit2)

where f0 is the carrier frequency, c is the speed of light, v_emit and v_coll
are velocities, and unit vectors point from emitter to each collector.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from gri_obs import FdoaObs
from gri_utils.observables import get_fdoa

from .sensor import Sensor

if TYPE_CHECKING:
    from gri_nsepoch import Time

    from gri_geosim.atmosphere import AtmosphereConfig
    from gri_geosim.emitter import Emitter
    from gri_geosim.platform import Platform

    from .constraints import FovConstraint


class FdoaSensor(Sensor):
    """Frequency Difference of Arrival sensor for Doppler measurements.

    Measures the difference in Doppler shift between this sensor's
    platform and a paired platform. Requires set_paired_platform() to be
    called before observations can be made.

    The measurement uses the emitter's carrier frequency and accounts
    for both emitter and platform velocities.

    Attributes:
        fdoa_std_hz: Standard deviation of FDOA measurement in Hz.
        paired_platform: The second platform for FDOA computation.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_geosim import Platform
        >>> # Create satellite and ground station
        >>> sat = Platform.from_tle(tle1, tle2, name="SAT")
        >>> ground = Platform.stationary(Pos.LLA(38.0, -77.0, 100.0), name="GND")
        >>>
        >>> # Create FDOA sensor on satellite, paired with ground
        >>> fdoa = FdoaSensor(fdoa_std_hz=0.1)
        >>> sat.add_sensor(fdoa)
        >>> fdoa.set_paired_platform(ground)
    """

    __slots__ = ("_fdoa_std_hz", "_paired_platform")

    _TYPE_PREFIX = "FDOA"

    def __init__(
        self,
        sensor_id: str | None = None,
        *,
        fdoa_std_hz: float = 0.1,
        fov: FovConstraint | None = None,
        apply_atmosphere: Literal["auto"] | bool = "auto",
        rng_seed: int | None = None,
    ) -> None:
        """Initialize an FDOA sensor.

        Args:
            sensor_id: Unique identifier for this sensor. If None, an ID
                is auto-generated (e.g., "FDOA-1").
            fdoa_std_hz: Standard deviation of FDOA noise in Hz.
                Defaults to 0.1 Hz.
            fov: Field of view constraint. Defaults to NoFov (no constraint).
            apply_atmosphere: Controls atmospheric correction application.
                Note: FDOA measures Doppler (velocity effects), not static
                path delays, so atmospheric corrections are not applied
                regardless of this setting. Accepted for API consistency.
            rng_seed: Optional seed for the random number generator.

        Raises:
            ValueError: If fdoa_std_hz is not positive.
        """
        super().__init__(
            sensor_id,
            fov=fov,
            apply_atmosphere=apply_atmosphere,
            rng_seed=rng_seed,
        )

        if fdoa_std_hz <= 0:
            raise ValueError(f"fdoa_std_hz must be positive, got {fdoa_std_hz}")

        self._fdoa_std_hz = fdoa_std_hz
        self._paired_platform: Platform | None = None

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def fdoa_std_hz(self) -> float:
        """Standard deviation of FDOA measurement in Hz."""
        return self._fdoa_std_hz

    @property
    def paired_platform(self) -> Platform | None:
        """The paired platform for FDOA computation."""
        return self._paired_platform

    # =========================================================================
    # Configuration
    # =========================================================================

    def set_paired_platform(self, platform: Platform) -> None:
        """Set the paired platform for FDOA computation.

        The FDOA measurement will be the Doppler difference between this
        sensor's platform and the paired platform.

        Args:
            platform: The second platform for FDOA computation.

        Raises:
            ValueError: If platform is the same as the sensor's platform.
        """
        if self._platform is not None and platform is self._platform:
            raise ValueError("Paired platform cannot be the same as sensor's platform")
        self._paired_platform = platform

    # =========================================================================
    # Observation methods
    # =========================================================================

    def can_observe(self, emitter: Emitter, time: Time) -> bool:
        """Check if the sensor can observe the emitter at this time.

        Checks that:
        1. The sensor is attached to a platform
        2. A paired platform has been set
        3. The emitter is within this sensor's field of view

        Note: Does not check if emitter is visible to paired platform.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.

        Returns:
            True if observation is possible.
        """
        if self._platform is None:
            return False
        if self._paired_platform is None:
            return False
        return self.is_in_fov(emitter, time)

    def observe(
        self,
        emitter: Emitter,
        time: Time,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> FdoaObs | None:
        """Generate an FDOA observation of the emitter.

        Computes the frequency difference of arrival between this sensor's
        platform and the paired platform, optionally adding Gaussian noise.

        The measurement accounts for:
        - Emitter carrier frequency
        - Emitter velocity
        - Both platform velocities

        Note: Atmospheric effects on FDOA (Doppler) are primarily related to
        velocity, not static path delays. The atmosphere parameter is accepted
        for API consistency but currently unused.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.
            add_noise: If True, add Gaussian measurement noise.
            atmosphere: Accepted for API consistency but currently unused.

        Returns:
            An FdoaObs, or None if not observable.
        """
        # Note: atmosphere parameter accepted but unused - FDOA measures
        # Doppler (velocity effects), not static path delays
        _ = atmosphere
        if not self.can_observe(emitter, time):
            return None

        # Get positions and velocities
        platform1_pos = self._platform.position_at(time)  # type: ignore[union-attr]
        platform1_vel = self._platform.velocity_at(time)  # type: ignore[union-attr]
        platform2_pos = self._paired_platform.position_at(time)  # type: ignore[union-attr]
        platform2_vel = self._paired_platform.velocity_at(time)  # type: ignore[union-attr]
        emitter_pos = emitter.position_at(time)
        emitter_vel = emitter.velocity_at(time)

        # Compute FDOA using gri-utils
        fdoa = get_fdoa(
            emit_xyz=emitter_pos.xyz,
            emit_vel=emitter_vel,
            collector1_xyz=platform1_pos.xyz,
            collector2_xyz=platform2_pos.xyz,
            freq_hz=emitter.frequency_hz,
            collector1_vel=platform1_vel,
            collector2_vel=platform2_vel,
        )
        fdoa_value = float(fdoa)

        # Add noise if requested
        if add_noise:
            noise = self._rng.normal(0.0, self._fdoa_std_hz)
            fdoa_value += noise

        return FdoaObs(
            time=time,
            value=fdoa_value,
            std_dev=self._fdoa_std_hz,
            collector1=platform1_pos,
            collector2=platform2_pos,
            collector1_vel=platform1_vel,
            collector2_vel=platform2_vel,
            frequency_hz=emitter.frequency_hz,
            sensor_id=self._sensor_id,
            emitter_id=emitter.name if emitter.name else None,
        )

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        paired = self._paired_platform.name if self._paired_platform else "None"
        return (
            f"FdoaSensor(id='{self._sensor_id}', "
            f"std={self._fdoa_std_hz:.2f}Hz, "
            f"paired='{paired}')"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        paired = self._paired_platform.name if self._paired_platform else "unset"
        return (
            f"FDOA Sensor '{self._sensor_id}' "
            f"(std={self._fdoa_std_hz:.2f} Hz, paired with {paired})"
        )
