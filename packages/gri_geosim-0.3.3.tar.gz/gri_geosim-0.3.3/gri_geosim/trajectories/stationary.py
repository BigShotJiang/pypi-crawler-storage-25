"""Stationary trajectory for fixed-position platforms.

A StationaryTrajectory represents a platform that does not move, such as a
ground station or fixed sensor. Position is constant and velocity is zero.

Implemented as a thin wrapper around LinearTrajectory with a zero-velocity
Vel. Kept as a named type for caller intent clarity ("this is a stationary
platform"), not a semantic distinction.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos, Vel

from .linear import LinearTrajectory

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class StationaryTrajectory:
    """Trajectory for a fixed-position platform (zero velocity).

    Thin wrapper over LinearTrajectory: constructs a Vel from the supplied
    position with zero velocity, then delegates all queries to an underlying
    LinearTrajectory. Kept as a named type for readability at construction
    sites (``StationaryTrajectory(Pos.LLA(...))``).

    Attributes:
        position: The fixed position as a Pos object.

    Example:
        >>> from gri_pos import Pos
        >>> traj = StationaryTrajectory(Pos.LLA(38.0, -77.0, 100.0))
        >>> state = traj.state_at()
        >>> np.allclose(state.vel_xyz, [0, 0, 0])
        True
    """

    __slots__ = ("_linear", "_position")

    def __init__(
        self,
        position: Pos | LLA | XYZ | np.ndarray | Sequence[float],
    ) -> None:
        """Initialize a stationary trajectory at a fixed position.

        Args:
            position: The fixed position. Accepts:
                - Pos object
                - LLA object
                - XYZ object
                - numpy array (interpreted as XYZ meters)
                - Sequence of 3 floats (interpreted as XYZ meters)

        Raises:
            TypeError: If position type is not supported.
        """
        if isinstance(position, Pos):
            self._position = position
        elif isinstance(position, (LLA, XYZ)):
            self._position = Pos(position)
        elif isinstance(position, np.ndarray):
            self._position = Pos.XYZ(position)
        elif hasattr(position, "__len__") and len(position) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
            self._position = Pos.XYZ(*position)
        else:
            raise TypeError(
                f"Unsupported position type: {type(position).__name__}. "
                "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
            )

        # Build a zero-velocity Vel and wrap a LinearTrajectory around it.
        self._linear = LinearTrajectory(Vel(self._position))

    @property
    def position(self) -> Pos:
        """The fixed position of this trajectory."""
        return self._position

    @property
    def epoch_unix_s(self) -> float:
        """Trajectory reference epoch (unused; stationary ignores `dt`)."""
        return self._linear.epoch_unix_s

    def state_at(self, dt: float = 0.0) -> Vel:
        """Return the fixed state (position + zero velocity)."""
        return self._linear.state_at(dt)

    def position_at(self, dt: float = 0.0) -> Pos:
        """Return the fixed position."""
        return self._linear.position_at(dt)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Return the zero velocity vector."""
        return self._linear.velocity_at(dt)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"StationaryTrajectory({self._position})"
