"""Hermite trajectory for interpolated paths through known state vectors.

A HermiteTrajectory represents a platform whose path is defined by discrete
state vectors (position + velocity at known dt values). The state at any dt
is interpolated using cubic Hermite splines, which match both position and
velocity at each knot point.

This is useful for platforms with ephemeris data from an external source
where you need smooth interpolation that respects the velocity information.

Compared to WaypointTrajectory:
- Hermite uses both position AND velocity at knots (higher fidelity)
- Waypoint cubic spline only matches positions (ignores velocity data)
- Hermite is C1-continuous; cubic spline is C2-continuous

Compared to KeplerianTrajectory:
- Hermite is data-driven (no physics assumptions between knots)
- Keplerian is physics-driven (two-body propagation from a single epoch)
- Hermite handles arbitrary motion including perturbed orbits and non-orbital
  paths
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos, Vel
from gri_utils.orbit import hermite_interpolate

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class HermiteTrajectory:
    """Trajectory interpolated from state vectors using cubic Hermite splines.

    Defines a path through a series of (dt, position, velocity) knots. `dt`
    is in seconds relative to `epoch_unix_s`.

    Attributes:
        num_knots: Number of state vector knots.
        start_dt: `dt` of the first knot.
        end_dt: `dt` of the last knot.

    Example:
        >>> from gri_pos import Pos
        >>> import numpy as np
        >>> vel = np.array([100.0, 0.0, 0.0])
        >>> knots = [
        ...     (0.0, Pos.LLA(38.0, -77.0, 400e3), vel),
        ...     (60.0, Pos.LLA(38.5, -76.5, 400e3), vel),
        ...     (120.0, Pos.LLA(39.0, -76.0, 400e3), vel),
        ... ]
        >>> traj = HermiteTrajectory(knots)
        >>> state = traj.state_at(30.0)
    """

    __slots__ = (
        "_epoch_unix_s",
        "_positions_xyz",
        "_times_dt",
        "_velocities_xyz",
    )

    def __init__(
        self,
        knots: Sequence[
            tuple[
                float,
                Pos | LLA | XYZ | NDArray[np.floating] | Sequence[float],
                NDArray[np.floating] | Sequence[float],
            ]
        ],
        *,
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a Hermite trajectory from state vector knots.

        Args:
            knots: List of (dt_s, position, velocity_ecef_ms) tuples. `dt_s`
                is seconds relative to `epoch_unix_s`. Position may be Pos,
                LLA, XYZ, ndarray, or sequence of 3 floats. Velocity is
                [vx, vy, vz] ECEF m/s.
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.

        Raises:
            ValueError: If fewer than 2 knots provided.
            ValueError: If knot dt values are not strictly increasing.
        """
        if len(knots) < 2:  # noqa: PLR2004
            msg = f"At least 2 knots required, got {len(knots)}"
            raise ValueError(msg)

        self._epoch_unix_s = float(epoch_unix_s)

        times_dt = []
        positions_xyz = []
        velocities_xyz = []

        for dt_s, position, velocity in knots:
            times_dt.append(float(dt_s))
            positions_xyz.append(_to_xyz(position))
            velocities_xyz.append(np.asarray(velocity, dtype=np.float64))

        self._times_dt = np.array(times_dt, dtype=np.float64)
        self._positions_xyz = np.array(positions_xyz, dtype=np.float64)
        self._velocities_xyz = np.array(velocities_xyz, dtype=np.float64)

        if not np.all(np.diff(self._times_dt) > 0):
            raise ValueError("Knot times must be strictly increasing")

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._epoch_unix_s

    @property
    def num_knots(self) -> int:
        """Number of state vector knots."""
        return len(self._times_dt)

    @property
    def start_dt(self) -> float:
        """`dt` of the first knot."""
        return float(self._times_dt[0])

    @property
    def end_dt(self) -> float:
        """`dt` of the last knot."""
        return float(self._times_dt[-1])

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get platform position at `dt` seconds from the trajectory epoch."""
        return self.state_at(dt)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get platform ECEF velocity at `dt` seconds from the trajectory epoch."""
        return np.asarray(self.state_at(dt).vel_xyz, dtype=np.float64)

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch."""
        state = hermite_interpolate(
            self._times_dt,
            self._positions_xyz,
            self._velocities_xyz,
            dt,
        )
        if isinstance(state, list):
            raise TypeError("Expected single OrbitState from scalar dt input")

        pos = np.asarray(state.position_eci_m, dtype=np.float64)
        vel = np.asarray(state.velocity_eci_ms, dtype=np.float64)
        return Vel.XYZ(pos[0], pos[1], pos[2], vel[0], vel[1], vel[2])

    def __repr__(self) -> str:
        """Return string representation."""
        return f"HermiteTrajectory({self.num_knots} knots)"


def _to_xyz(
    position: Pos | LLA | XYZ | NDArray[np.floating] | Sequence[float],
) -> NDArray[np.floating]:
    """Convert a position to an XYZ numpy array."""
    if isinstance(position, Pos):
        return np.asarray(position.xyz, dtype=np.float64)
    if isinstance(position, (LLA, XYZ)):
        return np.asarray(Pos(position).xyz, dtype=np.float64)
    if isinstance(position, np.ndarray):
        return np.asarray(position, dtype=np.float64)
    if hasattr(position, "__len__") and len(position) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
        return np.array(position, dtype=np.float64)
    msg = (
        f"Unsupported position type: {type(position).__name__}. "
        "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats."
    )
    raise TypeError(msg)
