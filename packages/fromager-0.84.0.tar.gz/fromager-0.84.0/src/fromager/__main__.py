#!/usr/bin/env python3

import datetime
import logging
import pathlib
import sys

import click

from . import (
    candidate,
    clickext,
    commands,
    context,
    external_commands,
    hooks,
    log,
    overrides,
    packagesettings,
)

logger = logging.getLogger(__name__)

_DEBUG = False

try:
    external_commands.detect_network_isolation()
except Exception as e:
    SUPPORTS_NETWORK_ISOLATION: bool = False
    NETWORK_ISOLATION_ERROR: str | None = str(e)
else:
    SUPPORTS_NETWORK_ISOLATION = True
    NETWORK_ISOLATION_ERROR = None


@click.group()
@click.version_option(
    package_name="fromager",
    prog_name="fromager",
)
@click.option(
    "-v",
    "--verbose",
    default=False,
    is_flag=True,
    help="report more detail to the console",
)
@click.option(
    "--debug",
    default=False,
    is_flag=True,
    help="report full tracebacks to the console",
)
@click.option(
    "--log-file",
    type=clickext.ClickPath(),
    help="save detailed report of actions to file",
)
@click.option(
    "--log-format",
    type=str,
    default="",
    help="python log format instructions, refer to https://docs.python.org/3/library/logging.html#logrecord-attributes for details",
)
@click.option(
    "--error-log-file",
    type=clickext.ClickPath(),
    help="save error messages to a file",
)
@click.option(
    "-O",
    "--output-dir",
    default=pathlib.Path("."),
    type=clickext.ClickPath(),
    help="base directory for sdists-repo, wheels-repo, and work-dir (default: current directory)",
)
@click.option(
    "-o",
    "--sdists-repo",
    default=None,
    type=clickext.ClickPath(),
    hidden=True,
    help="location to manage source distributions (overrides --output-dir)",
)
@click.option(
    "-w",
    "--wheels-repo",
    default=None,
    type=clickext.ClickPath(),
    hidden=True,
    help="location to manage wheel repository (overrides --output-dir)",
)
@click.option(
    "--build-wheel-server-url",
    help="An optional URL for external web server for building wheels, to replace the built-in server. Must be configured to serve the path specified for --wheels-repo.",
)
@click.option(
    "-t",
    "--work-dir",
    default=None,
    type=clickext.ClickPath(),
    hidden=True,
    help="location to manage working files, including builds and logs (overrides --output-dir)",
)
@click.option(
    "-p",
    "--patches-dir",
    default=pathlib.Path("overrides/patches"),
    type=clickext.ClickPath(),
    help="location of files for patching source before building",
)
@click.option(
    "-e",
    "--envs-dir",
    default=pathlib.Path("overrides/envs"),
    type=clickext.ClickPath(),
    help="deprecated: no longer used",
    hidden=True,
    expose_value=False,
)
@click.option(
    "--settings-file",
    default=pathlib.Path("overrides/settings.yaml"),
    type=clickext.ClickPath(),
    help="location of the application settings file",
)
@click.option(
    "--settings-dir",
    default=pathlib.Path("overrides/settings"),
    type=clickext.ClickPath(),
    help="location of per-package settings files",
)
@click.option(
    "-c",
    "--constraints-file",
    "constraints_files",
    multiple=True,
    type=str,
    help=(
        "location of the constraints files. Constraints are merged and "
        "checked for conflicts. Supports local path and remote from https://"
    ),
)
@click.option(
    "--cleanup/--no-cleanup",
    default=True,
    help="control removal of working files when a build completes successfully",
)
@click.option("--variant", default="cpu", help="the build variant name")
@click.option(
    "-j",
    "--jobs",
    type=int,
    default=None,
    help="maximum number of jobs to run in parallel",
)
@click.option(
    "--network-isolation/--no-network-isolation",
    default=SUPPORTS_NETWORK_ISOLATION,
    help="Build sdist and when with network isolation (unshare -cn)",
    show_default=True,
)
@click.option(
    "--min-release-age",
    type=click.IntRange(min=0),
    default=0,
    help="Reject package versions published fewer than this many days ago (0 disables the check).",
)
@click.pass_context
def main(
    ctx: click.Context,
    verbose: bool,
    debug: bool,
    log_file: pathlib.Path,
    log_format: str,
    error_log_file: pathlib.Path,
    output_dir: pathlib.Path,
    sdists_repo: pathlib.Path | None,
    wheels_repo: pathlib.Path | None,
    build_wheel_server_url: str,
    work_dir: pathlib.Path | None,
    patches_dir: pathlib.Path,
    settings_file: pathlib.Path,
    settings_dir: pathlib.Path,
    constraints_files: tuple[str, ...],
    cleanup: bool,
    variant: str,
    jobs: int | None,
    network_isolation: bool,
    min_release_age: int,
) -> None:
    # Save the debug flag so invoke_main() can use it.
    global _DEBUG
    _DEBUG = debug

    # Resolve output directories: explicit per-directory flags take
    # precedence, otherwise derive from --output-dir.
    if not sdists_repo:
        sdists_repo = output_dir / "sdists-repo"
    if not wheels_repo:
        wheels_repo = output_dir / "wheels-repo"
    if not work_dir:
        work_dir = output_dir / "work-dir"

    # Set custom log factory to prepend requirement name.
    logging.setLogRecordFactory(log.FromagerLogRecord)
    # Set the overall logger level to debug and allow the handlers to filter
    # messages at their own level.
    logging.getLogger().setLevel(logging.DEBUG)
    # Configure a stream handler for console messages at the requested verbosity
    # level.
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    log_format = log_format or (log.VERBOSE_LOG_FMT if verbose else log.TERSE_LOG_FMT)
    date_format: str | None = None if verbose else log.TERSE_DATE_FMT
    stream_formatter = logging.Formatter(
        log_format,
        datefmt=date_format,
    )
    stream_handler.setFormatter(stream_formatter)
    logging.getLogger().addHandler(stream_handler)
    # If we're given an error log file, configure a file handler for all error
    # messages to make them easier to find without sifting through the full
    # debug log.
    if error_log_file:
        error_handler = logging.FileHandler(error_log_file)
        error_handler.setLevel(logging.ERROR)
        error_formatter = logging.Formatter(log.VERBOSE_LOG_FMT)
        error_handler.setFormatter(error_formatter)
        logging.getLogger().addHandler(error_handler)
    # If we're given a debug log filename, configure the file handler.
    if log_file:
        # Always log to the file at debug level
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(log.VERBOSE_LOG_FMT)
        file_handler.setFormatter(file_formatter)
        logging.getLogger().addHandler(file_handler)
        logger.info("logging debug information to %s", log_file)
    # Report the error log file after configuring the debug log file so the
    # message is saved to the debug log.
    if error_log_file:
        logger.info("logging errors to %s", error_log_file)

    # if ctx.invoked_subcommand is None
    if ctx.invoked_subcommand is not None:
        cmd = main.commands[str(ctx.invoked_subcommand)]
        do_show = getattr(cmd, "_fromager_show_build_settings", False)
        if do_show:
            logger.info(f"primary settings file: {settings_file}")
            logger.info(f"per-package settings dir: {settings_dir}")
            logger.info(f"variant: {variant}")
            logger.info(f"patches dir: {patches_dir}")
            logger.info(f"maximum concurrent jobs: {jobs}")
            logger.info(f"constraints files: {', '.join(constraints_files)}")
            logger.info(f"network isolation: {network_isolation}")
            if build_wheel_server_url:
                logger.info(f"external build wheel server: {build_wheel_server_url}")
            else:
                logger.info("using internal build wheel server")
            overrides.log_overrides()
            hooks.log_hooks()

    if network_isolation and not SUPPORTS_NETWORK_ISOLATION:
        ctx.fail(f"network isolation is not available: {NETWORK_ISOLATION_ERROR}")

    wkctx = context.WorkContext(
        active_settings=packagesettings.Settings.from_files(
            settings_file=settings_file,
            settings_dir=settings_dir,
            patches_dir=patches_dir,
            variant=variant,
            max_jobs=jobs,
        ),
        constraints_files=constraints_files,
        patches_dir=patches_dir,
        sdists_repo=sdists_repo,
        wheels_repo=wheels_repo,
        wheel_server_url=build_wheel_server_url,
        work_dir=work_dir,
        cleanup=cleanup,
        variant=variant,
        network_isolation=network_isolation,
        max_jobs=jobs,
        settings_dir=settings_dir,
        cooldown=(
            candidate.Cooldown(min_age=datetime.timedelta(days=min_release_age))
            if min_release_age > 0
            else None
        ),
    )
    wkctx.setup()
    ctx.obj = wkctx


for cmd in commands.commands:
    main.add_command(cmd)


def _format_exception(exc: BaseException) -> str:
    if exc.__cause__:
        cause = _format_exception(exc.__cause__)
        return f"{exc} because {cause}"
    return str(exc)


def invoke_main() -> None:
    # Wrapper for the click main command that ensures any exceptions
    # are logged so that build pipeline outputs include the traceback.
    try:
        main(auto_envvar_prefix="FROMAGER")
    except Exception as err:
        logger.debug(
            err,
            exc_info=True,
        )  # log the full traceback details to the debug log file, if any
        logger.error(_format_exception(err))
        if _DEBUG:
            raise
        sys.exit(1)


if __name__ == "__main__":
    invoke_main()
