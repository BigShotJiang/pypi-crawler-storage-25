from django.apps import AppConfig


class KeywordsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'keyta.apps.keywords'
