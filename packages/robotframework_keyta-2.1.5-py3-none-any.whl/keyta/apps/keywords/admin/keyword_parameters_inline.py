from django import forms
from django.forms.utils import ErrorDict, ErrorList
from django.utils.translation import gettext_lazy as _

from adminsortable2.admin import CustomInlineFormSet

from keyta.admin.field_delete_related_instance import DeleteRelatedField
from keyta.admin.base_inline import SortableTabularInline

from ..models import Keyword, KeywordParameter, KeywordCallParameter, KeywordCallParameterSource


class ParameterFormset(CustomInlineFormSet):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.keyword: Keyword = kwargs.get('instance')

    def clean(self):
        if self.keyword.pk:
            for form in self.extra_forms:
                default_value = form.cleaned_data.get('default_value')
                name = form.cleaned_data.get('name')

                if not default_value and self.keyword.in_use > 1:
                    form._errors = ErrorDict()
                    form._errors['default_value'] = ErrorList([
                        _('Beim Hinzufügen eines Parameters darf der Standardwert nicht leer sein.')
                    ])

                if self.keyword.parameters.filter(name=name).exists():
                    form._errors = ErrorDict()
                    form._errors['name'] = ErrorList([
                        _('Ein Parameter mit diesem Namen ist bereits vorhanden.')
                    ])


class ParameterForm(forms.ModelForm):
    def clean_name(self):
        name = self.cleaned_data.get('name')

        if ':' in name:
            raise forms.ValidationError("Doppelpunkt ist im Parameternamen nicht zulässig")

        return name

    def save(self, commit=True):
        instance = super().save(commit)

        orig_name = self.initial.get('name')
        current_name = self.cleaned_data.get('name')

        if orig_name and orig_name != current_name:
            parameter: KeywordParameter = instance
            kw_call_param_sources = KeywordCallParameterSource.objects.filter(kw_param=parameter)

            for kw_call_param in KeywordCallParameter.objects.filter(value_ref__in=kw_call_param_sources):
                kw_call_param.update_arg_name(current_name)

        return instance


class ParametersInline(DeleteRelatedField, SortableTabularInline):
    model = KeywordParameter
    fields = ['position', 'name']
    form = ParameterForm
    formset = ParameterFormset
    extra = 0
    verbose_name = _('Parameter')
    verbose_name_plural = _('Parameters')

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        field = super().formfield_for_dbfield(db_field, request, **kwargs)

        if db_field.name == 'default_value':
            field.label = _('Standardwert (optional)')
            field.widget = forms.TextInput(attrs={
                'style': 'width: 100%'
            })

        if db_field.name == 'name':
            field.widget = forms.TextInput(attrs={
                'style': 'width: 100%',
                'placeholder': _('Name eintragen, anschließend Enter drücken')
            })

        return field

    def get_fields(self, request, obj=None):
        keyword: Keyword = obj

        if keyword and keyword.in_use > 1:
            return self.fields + ['default_value'] + super().get_readonly_fields(request, obj)

        return super().get_fields(request, obj)

    def has_delete_permission(self, request, obj=None):
        keyword: Keyword = obj

        if keyword and keyword.is_action:
            return self.can_change(request.user, 'action')

        if keyword and keyword.is_sequence:
            return self.can_change(request.user, 'sequence') and not keyword.locked

        return super().has_delete_permission(request, obj)
