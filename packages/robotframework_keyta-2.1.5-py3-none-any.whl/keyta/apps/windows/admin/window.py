from django import forms
from django.conf import settings
from django.contrib import admin
from django.forms import ModelMultipleChoiceField
from django.http import HttpRequest, HttpResponseRedirect
from django.urls import reverse
from django.utils.safestring import mark_safe
from django.utils.translation import gettext_lazy as _

from keyta.admin.base_admin import (
    BaseAdmin,
    BaseDocumentationAdmin,
    BaseQuickAddAdmin
)
from keyta.admin.field_documentation import DocumentationField
from keyta.admin.list_filters import SystemListFilter
from keyta.apps.resources.models import Resource
from keyta.apps.systems.models import System
from keyta.forms.baseform import form_with_select
from keyta.widgets import (
    CheckboxSelectMultipleSystems,
    Icon,
    open_link_in_modal,
    url_query_parameters
)

from ..forms import WindowForm
from ..models import (
    Window,
    WindowDocumentation,
    WindowQuickAdd,
    WindowQuickChange
)
from .actions_inline import Actions
from .resources_inline import Resources
from .sequences_inline import Sequences
from .variables_inline import Variables


@admin.register(Window)
class WindowAdmin(DocumentationField, BaseAdmin):
    list_display = ['preview', 'name', 'system_list']
    list_display_links = ['name']
    list_filter = [
        ('systems', SystemListFilter),
    ]
    list_per_page = 10
    search_fields = ['name']
    search_help_text = _('Name')

    preview_icon = Icon(
        settings.FA_ICONS.preview_field,
        styles={'font-size': '18px'},
        title=_('Vorschau')
    )

    @admin.display(description=mark_safe(str(preview_icon)))
    def preview(self, window: Window):
        return open_link_in_modal(
            WindowDocumentation.objects.get(id=window.pk).get_admin_url(),
            str(Icon(settings.FA_ICONS.preview, {'font-size': '18px'}))
        )

    @admin.display(description=_('Systeme'))
    def system_list(self, window: Window):
        return ', '.join(
            window.systems.values_list('name', flat=True)
        )

    fields = ['systems', 'name', 'description']
    form = form_with_select(
        Window,
        'systems',
        _('System hinzufügen'),
        form_class=WindowForm,
        select_many=True
    )
    inlines = [
        Actions,
        Sequences,
        Variables
    ]

    def change_view(self, request: HttpRequest, object_id, form_url="", extra_context=None):
        if '_popup' in request.GET:
            window = WindowQuickChange.objects.get(pk=object_id)
            return HttpResponseRedirect(window.get_admin_url() + '?_popup=1')

        current_app, model, *route = request.resolver_match.route.split('/')
        app = settings.MODEL_TO_APP.get(model)

        if app and app != current_app:
            return HttpResponseRedirect(reverse('admin:%s_%s_change' % (app, model), args=(object_id,)))

        return super().change_view(request, object_id, form_url, extra_context)

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        field = super().formfield_for_dbfield(db_field, request, **kwargs)

        if db_field.name == 'systems':
            field = ModelMultipleChoiceField(
                widget=CheckboxSelectMultipleSystems,
                queryset=field.queryset
            )
            if System.objects.count() == 1:
                field.initial = [System.objects.first()]
            field.label = _('Systeme')

            if window_id := request.resolver_match.kwargs.get('object_id'):
                window = Window.objects.get(id=window_id)
                field.widget.in_use = set(window.keywords.values_list('systems', flat=True))

        return field

    def get_inlines(self, request, obj):
        if not obj:
            return []

        if Resource.objects.count():
            return [Resources] + self.inlines

        return self.inlines

    def get_protected_objects(self, obj):
        window: Window = obj
        return list(window.actions.all()) + list(window.sequences.all()) + list(window.variables.all())

    def has_add_permission(self, request):
        return self.can_add(request.user, 'window')

    def has_change_permission(self, request, obj=None):
        return self.can_change(request.user, 'window')

    def has_delete_permission(self, request, obj=None):
        return self.can_delete(request.user, 'window')


@admin.register(WindowDocumentation)
class WindowDocumentationAdmin(BaseDocumentationAdmin):
    fields = []


@admin.register(WindowQuickAdd)
class WindowQuickAddAdmin(BaseQuickAddAdmin):
    fields = ['systems', 'name']
    form = WindowForm

    def formfield_for_dbfield(self, db_field, request, **kwargs):
        field = super().formfield_for_dbfield(db_field, request, **kwargs)

        if db_field.name == 'systems':
            field.widget = forms.MultipleHiddenInput()

        return field


@admin.register(WindowQuickChange)
class WindowQuickChangeAdmin(WindowAdmin):
    fields = []
    readonly_fields = ['documentation']

    def change_view(self, request, object_id, form_url="", extra_context=None):
        current_app, model, *route = request.resolver_match.route.split('/')
        app = settings.MODEL_TO_APP.get(model)

        if app and app != current_app:
            return HttpResponseRedirect(reverse('admin:%s_%s_change' % (app, model), args=(object_id,)) + '?' + url_query_parameters(request.GET))

        return self.changeform_view(request, object_id, form_url, extra_context or {'title_icon': settings.FA_ICONS.window})

    def get_inlines(self, request, obj):
        if Resource.objects.count():
            return [Resources]

        return []

    def has_delete_permission(self, request, obj=None):
        return False
