"""PyTorch differentiable depth rendering for implicit surfaces.

Requires ``torch`` — install via ``pip install isoray[torch]``.
"""

from isoray.torch.render import TorchRenderResult, render_depth

__all__ = [
    "render_depth",
    "TorchRenderResult",
]
