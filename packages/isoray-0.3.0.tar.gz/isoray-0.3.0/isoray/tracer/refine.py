"""Newton refinement — optional acceleration when gradient is available.

Applied after bisection has isolated a narrow interval containing the root.
Falls back to bisection result if Newton diverges or exits the interval.
"""

from __future__ import annotations

import numpy as np


def _centered_diff_directional(
    f,
    pos: np.ndarray,
    directions: np.ndarray,
    h: float = 1e-7,
) -> np.ndarray:
    """Compute directional derivative g'(t) = df/dt along ray direction.

    Uses 2N batch evaluations (forward and backward along ray).

    Args:
        f: ImplicitFunction — f(pos) -> (val, grad|None).
        pos: (N, 3) current positions on rays.
        directions: (N, 3) ray direction vectors (assumed unit).
        h: finite difference step size.

    Returns:
        g_prime: (N,) directional derivatives.
    """
    pos_fwd = pos + h * directions  # (N, 3)
    pos_bwd = pos - h * directions  # (N, 3)

    all_points = np.concatenate([pos_fwd, pos_bwd], axis=0)  # (2N, 3)
    all_vals, _ = f(all_points)

    N = pos.shape[0]
    v_fwd = all_vals[:N]
    v_bwd = all_vals[N:]
    return (v_fwd - v_bwd) / (2.0 * h)


def newton_refine(
    t: np.ndarray,
    origins: np.ndarray,
    directions: np.ndarray,
    hit: np.ndarray,
    f,
    t_lo: np.ndarray | None = None,
    t_hi: np.ndarray | None = None,
    max_iter: int = 3,
    tol: float = 1e-12,
    h_diff: float = 1e-7,
) -> np.ndarray:
    """Batch Newton refinement of bisection hit t-values.

    Args:
        t: (R,) bisection t values.
        origins: (R, 3) ray origins.
        directions: (R, 3) ray directions.
        hit: (R,) bool mask — only refine where True.
        f: ImplicitFunction — f(pos) -> (val, grad|None).
        t_lo: (R,) optional interval lower bounds from bisection.
        t_hi: (R,) optional interval upper bounds from bisection.
        max_iter: Newton iterations (default 3).
        tol: early exit when max |f(pos)| < tol.
        h_diff: step size for centered difference when gradient is None.

    Returns:
        t_refined: (R,) refined t values. Non-hit entries unchanged.
    """
    hit_idx = np.where(hit)[0]
    if len(hit_idx) == 0 or max_iter <= 0:
        return t.copy()

    # Extract compact arrays for hit rays only
    t_curr = t[hit_idx].copy()
    o = origins[hit_idx]  # (N, 3)
    d = directions[hit_idx]  # (N, 3)

    has_bounds = t_lo is not None and t_hi is not None
    if has_bounds:
        assert t_lo is not None and t_hi is not None
        lo = t_lo[hit_idx]
        hi = t_hi[hit_idx]

    for _ in range(max_iter):
        pos = o + t_curr[:, None] * d  # (N, 3)
        vals, grads = f(pos)

        if grads is not None:
            g_prime = np.sum(grads * d, axis=1)  # (N,)
        else:
            g_prime = _centered_diff_directional(f, pos, d, h=h_diff)

        # Skip update where directional derivative is near-zero
        safe = np.abs(g_prime) > 1e-12

        # Newton step: t_new = t - f(t) / f'(t)
        dt = np.zeros_like(t_curr)
        dt[safe] = vals[safe] / g_prime[safe]
        t_new = t_curr - dt

        # Clamp to bisection interval
        if has_bounds:
            t_new = np.clip(t_new, lo, hi)

        # Divergence check: only accept if |f(t_new)| < |f(t_old)|
        pos_new = o + t_new[:, None] * d
        vals_new, _ = f(pos_new)
        improved = np.abs(vals_new) < np.abs(vals)

        t_curr = np.where(improved & safe, t_new, t_curr)

        # Early exit if converged
        if np.max(np.abs(vals_new[improved & safe])) < tol if np.any(improved & safe) else True:
            break

    # Write back
    result = t.copy()
    result[hit_idx] = t_curr
    return result
