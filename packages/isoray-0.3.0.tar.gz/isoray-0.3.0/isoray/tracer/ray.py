"""Ray batch generation and Ray-AABB intersection."""

from __future__ import annotations

import numpy as np


def ray_aabb_intersect(
    origins: np.ndarray,
    directions: np.ndarray,
    aabb_lo: np.ndarray,
    aabb_hi: np.ndarray,
    t_near_clip: float = 1e-4,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Batch Ray-AABB intersection using the slab method.

    Args:
        origins: (N, 3) ray origins.
        directions: (N, 3) ray directions (assumed normalized).
        aabb_lo: (3,) lower corner of AABB.
        aabb_hi: (3,) upper corner of AABB.
        t_near_clip: minimum t value (avoids self-intersection).

    Returns:
        t_min: (N,) entry t values (valid where hit=True).
        t_max: (N,) exit t values.
        hit: (N,) bool — whether ray intersects AABB.
    """
    inv_dir = 1.0 / np.where(
        np.abs(directions) < 1e-12, np.sign(directions) * 1e-12 + 1e-30, directions
    )

    t1 = (aabb_lo[None, :] - origins) * inv_dir  # (N, 3)
    t2 = (aabb_hi[None, :] - origins) * inv_dir  # (N, 3)

    t_enter = np.minimum(t1, t2)  # (N, 3)
    t_exit = np.maximum(t1, t2)  # (N, 3)

    t_min = np.maximum(t_enter.max(axis=1), t_near_clip)  # (N,)
    t_max = t_exit.min(axis=1)  # (N,)

    hit = t_min < t_max
    return t_min, t_max, hit
