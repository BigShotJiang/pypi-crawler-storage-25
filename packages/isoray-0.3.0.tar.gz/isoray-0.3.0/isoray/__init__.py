"""Iso-Surface Rendering — robust ray casting for arbitrary implicit geometries."""

__version__ = "0.3.0"

from isoray.arithmetic.affine import AffineInclusion
from isoray.arithmetic.interval import (
    GradientInclusion,
    NaturalIntervalInclusion,
    SamplingInclusion,
)
from isoray.geometry.csg import Difference, Intersection, Union
from isoray.geometry.mesh_sdf import MeshSDF
from isoray.geometry.primitives import Sphere, Torus
from isoray.renderer.camera import generate_rays, generate_rays_parallel
from isoray.renderer.image import save_depth_map, save_image
from isoray.renderer.render import RenderResult, render
from isoray.renderer.shader import shade_lambertian
from isoray.tracer.bisection import TraceResult, bisect_trace
from isoray.tracer.ray import ray_aabb_intersect
from isoray.tracer.refine import newton_refine
from isoray.utils import estimate_lipschitz

__all__ = [
    # High-level API
    "render",
    "RenderResult",
    "estimate_lipschitz",
    # Geometry
    "Sphere",
    "Torus",
    "MeshSDF",
    "Union",
    "Intersection",
    "Difference",
    # Arithmetic / Inclusion
    "SamplingInclusion",
    "GradientInclusion",
    "NaturalIntervalInclusion",
    "AffineInclusion",
    # Tracer
    "TraceResult",
    "bisect_trace",
    "ray_aabb_intersect",
    "newton_refine",
    # Renderer
    "generate_rays",
    "generate_rays_parallel",
    "shade_lambertian",
    "save_image",
    "save_depth_map",
]
