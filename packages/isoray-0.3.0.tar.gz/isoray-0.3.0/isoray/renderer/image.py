"""Image output utilities — save rendered images as PNG."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image


def save_image(colors: np.ndarray, path: str | Path, width: int, height: int) -> None:
    """Save a color buffer as a PNG image.

    Args:
        colors: (H*W, 3) float64 in [0, 1].
        path: output file path.
        width, height: image dimensions.
    """
    pixels = (np.clip(colors, 0.0, 1.0) * 255.0).astype(np.uint8)
    pixels = pixels.reshape(height, width, 3)
    img = Image.fromarray(pixels, mode="RGB")
    img.save(str(path))


def save_depth_map(
    t: np.ndarray, hit: np.ndarray, path: str | Path, width: int, height: int
) -> None:
    """Save a depth map as a grayscale PNG.

    Args:
        t: (H*W,) float64 — ray parameter values.
        hit: (H*W,) bool — hit mask.
        path: output file path.
        width, height: image dimensions.
    """
    depth = np.where(hit, t, np.nan)
    valid = depth[np.isfinite(depth)]
    if len(valid) == 0:
        pixels = np.zeros((height, width), dtype=np.uint8)
    else:
        d_min, d_max = valid.min(), valid.max()
        rng = d_max - d_min if d_max > d_min else 1.0
        normalized = np.where(hit, (depth - d_min) / rng, 1.0)
        pixels = (np.clip(1.0 - normalized, 0.0, 1.0) * 255.0).astype(np.uint8)
        pixels = pixels.reshape(height, width)

    img = Image.fromarray(pixels, mode="L")
    img.save(str(path))
