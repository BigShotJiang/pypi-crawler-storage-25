"""Camera models and ray generation — pinhole (perspective) and orthographic (parallel)."""

from __future__ import annotations

import numpy as np


def generate_rays(
    width: int,
    height: int,
    fov_deg: float = 60.0,
    eye: np.ndarray | None = None,
    target: np.ndarray | None = None,
    up: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate rays for a pinhole camera.

    Args:
        width, height: image resolution in pixels.
        fov_deg: vertical field-of-view in degrees.
        eye: (3,) camera position. Default [0, 0, 3].
        target: (3,) look-at point. Default [0, 0, 0].
        up: (3,) world up vector. Default [0, 1, 0].

    Returns:
        origins: (H*W, 3) ray origins (all equal to eye).
        directions: (H*W, 3) normalized ray directions.
    """
    if eye is None:
        eye = np.array([0.0, 0.0, 3.0])
    if target is None:
        target = np.array([0.0, 0.0, 0.0])
    if up is None:
        up = np.array([0.0, 1.0, 0.0])

    eye = np.asarray(eye, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    up = np.asarray(up, dtype=np.float64)

    # Camera basis
    forward = target - eye
    forward = forward / np.linalg.norm(forward)
    right = np.cross(forward, up)
    if np.linalg.norm(right) < 1e-10:
        # forward is parallel to up — pick an alternative up vector
        alt_up = np.array([1.0, 0.0, 0.0])
        right = np.cross(forward, alt_up)
    right = right / np.linalg.norm(right)
    cam_up = np.cross(right, forward)

    # Image plane dimensions
    aspect = width / height
    fov_rad = np.deg2rad(fov_deg)
    half_h = np.tan(fov_rad / 2.0)
    half_w = half_h * aspect

    # Pixel coordinates → normalized device coordinates
    # Pixel center at (i + 0.5, j + 0.5)
    j, i = np.meshgrid(np.arange(width), np.arange(height))
    # i: row (top=0), j: column (left=0)
    u = (2.0 * (j.ravel() + 0.5) / width - 1.0) * half_w  # right
    v = (1.0 - 2.0 * (i.ravel() + 0.5) / height) * half_h  # up (flip y)

    # Ray directions in world space
    directions = u[:, None] * right[None, :] + v[:, None] * cam_up[None, :] + forward[None, :]
    norms = np.linalg.norm(directions, axis=1, keepdims=True)
    directions = directions / norms

    origins = np.broadcast_to(eye, directions.shape).copy()
    return origins, directions


def _camera_basis(
    eye: np.ndarray, target: np.ndarray, up: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute orthonormal camera basis (forward, right, cam_up)."""
    forward = target - eye
    forward = forward / np.linalg.norm(forward)
    right = np.cross(forward, up)
    if np.linalg.norm(right) < 1e-10:
        alt_up = np.array([1.0, 0.0, 0.0])
        right = np.cross(forward, alt_up)
    right = right / np.linalg.norm(right)
    cam_up = np.cross(right, forward)
    return forward, right, cam_up


def generate_rays_parallel(
    width: int,
    height: int,
    extent: float = 1.0,
    eye: np.ndarray | None = None,
    target: np.ndarray | None = None,
    up: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate rays for an orthographic (parallel) camera.

    All rays share the same direction. Origins are distributed on a grid
    perpendicular to the viewing direction.

    Args:
        width, height: image resolution in pixels.
        extent: half-size of the viewing region in world units.
            The camera covers [-extent, extent] along both right and up axes.
        eye: (3,) camera position (center of the image plane). Default [0, 0, 3].
        target: (3,) look-at point. Default [0, 0, 0].
        up: (3,) world up vector. Default [0, 1, 0].

    Returns:
        origins: (H*W, 3) ray origins on the image plane.
        directions: (H*W, 3) ray directions (all identical, normalized).
    """
    if eye is None:
        eye = np.array([0.0, 0.0, 3.0])
    if target is None:
        target = np.array([0.0, 0.0, 0.0])
    if up is None:
        up = np.array([0.0, 1.0, 0.0])

    eye = np.asarray(eye, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    up = np.asarray(up, dtype=np.float64)

    forward, right, cam_up = _camera_basis(eye, target, up)

    aspect = width / height
    half_w = extent * aspect
    half_h = extent

    j, i = np.meshgrid(np.arange(width), np.arange(height))
    u = (2.0 * (j.ravel() + 0.5) / width - 1.0) * half_w
    v = (1.0 - 2.0 * (i.ravel() + 0.5) / height) * half_h

    origins = eye[None, :] + u[:, None] * right[None, :] + v[:, None] * cam_up[None, :]
    directions = np.broadcast_to(forward, origins.shape).copy()
    return origins, directions
