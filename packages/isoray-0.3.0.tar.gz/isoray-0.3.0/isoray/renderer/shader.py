"""Surface shading — normal-based Lambertian lighting."""

from __future__ import annotations

import numpy as np


def shade_lambertian(
    normals: np.ndarray,
    hit: np.ndarray,
    light_dir: np.ndarray | None = None,
    ambient: float = 0.1,
    surface_color: np.ndarray | tuple | list | None = None,
    background: np.ndarray | tuple | list | None = None,
) -> np.ndarray:
    """Simple Lambertian shading.

    Args:
        normals: (N, 3) unit surface normals.
        hit: (N,) bool mask.
        light_dir: (3,) normalized direction TO the light.
            Default: normalized [1, 1, 1].
        ambient: ambient light intensity [0, 1].
        surface_color: (3,) RGB surface color in [0, 1].
            Default: (0.8, 0.5, 0.3) warm orange.
        background: (3,) RGB background color in [0, 1].
            Default: (0.2, 0.2, 0.2) gray.

    Returns:
        colors: (N, 3) RGB in [0, 1]. Non-hit pixels are background.
    """
    if light_dir is None:
        light_dir = np.array([1.0, 1.0, 1.0])
    light_dir = light_dir / np.linalg.norm(light_dir)

    if surface_color is None:
        sc = np.array([0.8, 0.5, 0.3])
    else:
        sc = np.asarray(surface_color, dtype=np.float64)

    if background is None:
        bg = np.array([0.2, 0.2, 0.2])
    else:
        bg = np.asarray(background, dtype=np.float64)

    N = normals.shape[0]
    colors = np.broadcast_to(bg, (N, 3)).copy()

    if not np.any(hit):
        return colors

    n = normals[hit]
    ndotl = np.sum(n * light_dir[None, :], axis=1)
    ndotl = np.maximum(ndotl, 0.0)
    intensity = ambient + (1.0 - ambient) * ndotl
    intensity = np.clip(intensity, 0.0, 1.0)

    colors[hit] = intensity[:, None] * sc[None, :]
    return colors
