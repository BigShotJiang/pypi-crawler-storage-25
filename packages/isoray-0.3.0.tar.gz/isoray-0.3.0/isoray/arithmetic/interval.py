"""Standard Interval Arithmetic — Phase 1 inclusion function engine.

All operations are batch: inputs/outputs are (N,) or (N, K) arrays.
Intervals are represented as (lo, hi) pairs where lo <= hi element-wise.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Basic arithmetic
# ---------------------------------------------------------------------------


def ia_add(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return a_lo + b_lo, a_hi + b_hi


def ia_sub(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return a_lo - b_hi, a_hi - b_lo


def ia_mul(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    p1 = a_lo * b_lo
    p2 = a_lo * b_hi
    p3 = a_hi * b_lo
    p4 = a_hi * b_hi
    lo = np.minimum(np.minimum(p1, p2), np.minimum(p3, p4))
    hi = np.maximum(np.maximum(p1, p2), np.maximum(p3, p4))
    return lo, hi


def ia_div(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Interval division. b must not contain zero."""
    inv_lo = 1.0 / b_hi
    inv_hi = 1.0 / b_lo
    return ia_mul(a_lo, a_hi, inv_lo, inv_hi)


# ---------------------------------------------------------------------------
# Unary operations
# ---------------------------------------------------------------------------


def ia_neg(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return -hi, -lo


def ia_abs(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    abs_lo_val = np.abs(lo)
    abs_hi_val = np.abs(hi)
    contains = (lo <= 0) & (hi >= 0)
    r_lo = np.where(contains, 0.0, np.minimum(abs_lo_val, abs_hi_val))
    r_hi = np.maximum(abs_lo_val, abs_hi_val)
    return r_lo, r_hi


def ia_sqr(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """x^2 over [lo, hi]."""
    lo2 = lo * lo
    hi2 = hi * hi
    # If interval contains 0, minimum is 0
    contains_zero_mask = (lo <= 0) & (hi >= 0)
    r_lo = np.where(contains_zero_mask, 0.0, np.minimum(lo2, hi2))
    r_hi = np.maximum(lo2, hi2)
    return r_lo, r_hi


def ia_sqrt(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    lo_clamped = np.maximum(lo, 0.0)
    return np.sqrt(lo_clamped), np.sqrt(np.maximum(hi, 0.0))


def ia_pow(lo: np.ndarray, hi: np.ndarray, n: int) -> tuple[np.ndarray, np.ndarray]:
    """Integer power x^n over [lo, hi]."""
    if n == 0:
        ones = np.ones_like(lo)
        return ones, ones
    if n == 1:
        return lo.copy(), hi.copy()
    if n == 2:
        return ia_sqr(lo, hi)
    if n % 2 == 0:
        # Even power: result is non-negative
        lo_n = np.abs(lo) ** n
        hi_n = np.abs(hi) ** n
        contains = (lo <= 0) & (hi >= 0)
        r_lo = np.where(contains, 0.0, np.minimum(lo_n, hi_n))
        r_hi = np.maximum(lo_n, hi_n)
        return r_lo, r_hi
    else:
        # Odd power: monotone
        return lo**n, hi**n


# ---------------------------------------------------------------------------
# Transcendental functions
# ---------------------------------------------------------------------------


def ia_exp(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.exp(lo), np.exp(hi)


def ia_log(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    return np.log(np.maximum(lo, 1e-300)), np.log(np.maximum(hi, 1e-300))


def ia_sin(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """sin over [lo, hi]. Handles full-period and critical-point cases."""
    sin_lo = np.sin(lo)
    sin_hi = np.sin(hi)

    width = hi - lo
    # If interval spans >= 2*pi, result is [-1, 1]
    full = width >= 2.0 * np.pi

    # Check if interval contains a maximum (pi/2 + 2*k*pi)
    # Shift so that maxima are at 0 + 2*k*pi
    shifted_max = lo - np.pi / 2.0
    k_lo_max = np.ceil(shifted_max / (2.0 * np.pi))
    next_max = k_lo_max * 2.0 * np.pi + np.pi / 2.0
    has_max = next_max <= hi

    # Check if interval contains a minimum (-pi/2 + 2*k*pi)
    shifted_min = lo + np.pi / 2.0
    k_lo_min = np.ceil(shifted_min / (2.0 * np.pi))
    next_min = k_lo_min * 2.0 * np.pi - np.pi / 2.0
    has_min = next_min <= hi

    r_lo = np.where(full, -1.0, np.where(has_min, -1.0, np.minimum(sin_lo, sin_hi)))
    r_hi = np.where(full, 1.0, np.where(has_max, 1.0, np.maximum(sin_lo, sin_hi)))
    return r_lo, r_hi


def ia_cos(lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """cos over [lo, hi]. cos(x) = sin(x + pi/2)."""
    return ia_sin(lo + np.pi / 2.0, hi + np.pi / 2.0)


# ---------------------------------------------------------------------------
# Comparison / CSG helpers
# ---------------------------------------------------------------------------


def ia_min(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return np.minimum(a_lo, b_lo), np.minimum(a_hi, b_hi)


def ia_max(
    a_lo: np.ndarray, a_hi: np.ndarray, b_lo: np.ndarray, b_hi: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    return np.maximum(a_lo, b_lo), np.maximum(a_hi, b_hi)


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def contains_zero(lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    """Check if each interval contains zero. Returns bool array."""
    return (lo <= 0.0) & (hi >= 0.0)


# ---------------------------------------------------------------------------
# Inclusion function implementations
# ---------------------------------------------------------------------------


class SamplingInclusion:
    """Inclusion function via vertex sampling + Lipschitz bound.

    Works for any ImplicitFunction, including mesh SDF.
    """

    def __init__(self, f, lipschitz: float = 1.0):
        self.f = f
        self.lipschitz = lipschitz

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Evaluate inclusion over N boxes.

        Args:
            lo: (N, 3) lower corners
            hi: (N, 3) upper corners

        Returns:
            (f_lo, f_hi): each (N,) — conservative range of f
        """
        N = lo.shape[0]

        # 8 vertices + center = 9 sample points per box
        mid = (lo + hi) * 0.5
        # Build 8 corners: all combinations of lo/hi per axis
        corners = np.empty((N * 8, 3), dtype=lo.dtype)
        idx = 0
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    corners[idx * N : (idx + 1) * N, 0] = lo[:, 0] if i == 0 else hi[:, 0]
                    corners[idx * N : (idx + 1) * N, 1] = lo[:, 1] if j == 0 else hi[:, 1]
                    corners[idx * N : (idx + 1) * N, 2] = lo[:, 2] if k == 0 else hi[:, 2]
                    idx += 1

        all_points = np.concatenate([corners, mid], axis=0)  # (9N, 3)
        all_vals, _ = self.f(all_points)  # (9N,)

        # Reshape to (9, N) and take min/max over sample axis
        vals = all_vals.reshape(9, N)
        sample_min = vals.min(axis=0)  # (N,)
        sample_max = vals.max(axis=0)  # (N,)

        # Lipschitz margin: L * half-diagonal of box
        diag = np.sqrt(np.sum((hi - lo) ** 2, axis=1))  # (N,)
        margin = self.lipschitz * diag * 0.5

        f_lo = sample_min - margin
        f_hi = sample_max + margin
        return f_lo, f_hi


class GradientInclusion:
    """Inclusion function via gradient-enhanced sampling.

    Three improvements over SamplingInclusion:
    1. Local Lipschitz — use sampled gradient norms instead of global L.
    2. Gradient sign test — zero margin for monotone axes.
    3. Mean Value Form — tighten via f(mid) + grad_range * half_width.

    When the implicit function returns grad=None, gradient is estimated from
    corner values at zero extra cost (finite difference on the 8 existing corners).

    Args:
        f: ImplicitFunction — __call__(pos) -> (val, grad | None).
        lipschitz: Global Lipschitz constant (upper bound guarantee).
        safety_factor: Multiplier on local gradient norm estimate. Higher = safer
            but less tight. Default 1.2 for analytic gradient, automatically
            increased to 1.5 for corner-estimated gradient.
        mode: Which improvements to apply.
            "local_lipschitz" — improvement 1 only.
            "sign_test" — improvements 1 + 2.
            "full" — all three (default).
    """

    def __init__(
        self,
        f,
        lipschitz: float = 1.0,
        safety_factor: float = 1.2,
        mode: str = "full",
    ):
        self.f = f
        self.lipschitz = lipschitz
        self.safety_factor = safety_factor
        self.mode = mode

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Evaluate inclusion over N boxes.

        Args:
            lo: (N, 3) lower corners
            hi: (N, 3) upper corners

        Returns:
            (f_lo, f_hi): each (N,) — conservative range of f
        """
        N = lo.shape[0]

        # --- Sampling (same as SamplingInclusion) ---
        mid = (lo + hi) * 0.5
        corners = np.empty((N * 8, 3), dtype=lo.dtype)
        idx = 0
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    corners[idx * N : (idx + 1) * N, 0] = lo[:, 0] if i == 0 else hi[:, 0]
                    corners[idx * N : (idx + 1) * N, 1] = lo[:, 1] if j == 0 else hi[:, 1]
                    corners[idx * N : (idx + 1) * N, 2] = lo[:, 2] if k == 0 else hi[:, 2]
                    idx += 1

        all_points = np.concatenate([corners, mid], axis=0)  # (9N, 3)
        all_vals, all_grads = self.f(all_points)  # (9N,), (9N, 3) | None

        vals = all_vals.reshape(9, N)
        sample_min = vals.min(axis=0)  # (N,)
        sample_max = vals.max(axis=0)  # (N,)
        half_w = (hi - lo) * 0.5  # (N, 3)

        # --- Determine gradient source ---
        if all_grads is not None:
            # Analytic gradient available — enable tightening
            grad_reshaped = all_grads.reshape(9, N, 3)
            has_analytic_grad = True
        else:
            # No gradient — tightening requires analytic gradient for safety.
            # Corner-estimated gradients give AVERAGE gradients that cannot
            # reliably detect non-monotonicity (e.g., a box straddling a
            # critical point where the average gradient has consistent sign
            # but the pointwise gradient changes sign).
            has_analytic_grad = False

        # === Base bound: global Lipschitz (always the safety guarantee) ===
        diag = np.sqrt(np.sum((hi - lo) ** 2, axis=1))
        base_margin = self.lipschitz * diag * 0.5
        base_lo = sample_min - base_margin
        base_hi = sample_max + base_margin

        if not has_analytic_grad or self.mode == "local_lipschitz":
            return base_lo, base_hi

        f_lo = base_lo.copy()
        f_hi = base_hi.copy()

        # --- Sampling resolution check ---
        # Tightening is only safe when 9 samples adequately capture the
        # function's behaviour in the box. Compare actual sample range to
        # the Lipschitz-predicted maximum range.  If the samples captured
        # only a small fraction of the possible variation, the function
        # oscillates faster than the sampling density can resolve.
        sample_range = sample_max - sample_min  # (N,)
        predicted_range = self.lipschitz * diag  # (N,) max possible variation
        resolution_ratio = sample_range / np.maximum(predicted_range, 1e-12)
        well_resolved = resolution_ratio > 0.1  # (N,) bool

        # === Improvement 1: Gradient sign test (tighten only) ===
        # Only for well-resolved boxes. For monotone axes, the 8 corners
        # already capture the extremes → no margin needed for that axis.
        grad_x = grad_reshaped[:, :, 0]  # (9, N)
        grad_y = grad_reshaped[:, :, 1]
        grad_z = grad_reshaped[:, :, 2]

        mono_x = (grad_x.min(axis=0) > 0) | (grad_x.max(axis=0) < 0)  # (N,)
        mono_y = (grad_y.min(axis=0) > 0) | (grad_y.max(axis=0) < 0)
        mono_z = (grad_z.min(axis=0) > 0) | (grad_z.max(axis=0) < 0)
        # Only trust monotonicity for well-resolved boxes
        mono_x = mono_x & well_resolved
        mono_y = mono_y & well_resolved
        mono_z = mono_z & well_resolved

        non_mono_diag_sq = (
            np.where(mono_x, 0.0, (hi[:, 0] - lo[:, 0]) ** 2)
            + np.where(mono_y, 0.0, (hi[:, 1] - lo[:, 1]) ** 2)
            + np.where(mono_z, 0.0, (hi[:, 2] - lo[:, 2]) ** 2)
        )
        sign_margin = self.lipschitz * np.sqrt(non_mono_diag_sq) * 0.5
        sign_lo = sample_min - sign_margin
        sign_hi = sample_max + sign_margin

        f_lo = np.maximum(f_lo, sign_lo)
        f_hi = np.minimum(f_hi, sign_hi)

        if self.mode == "sign_test":
            return f_lo, f_hi

        # === Improvement 2: Mean Value Form (tighten only) ===
        # f(x) ∈ f(mid) + [grad_lo, grad_hi] · (x - mid)
        # Only applied for well-resolved boxes.
        f_mid = vals[-1]  # center sample, (N,)

        grad_lo_comp = grad_reshaped.min(axis=0)  # (N, 3)
        grad_hi_comp = grad_reshaped.max(axis=0)  # (N, 3)

        max_abs_grad = np.maximum(np.abs(grad_lo_comp), np.abs(grad_hi_comp))  # (N, 3)
        total_spread = (max_abs_grad * half_w).sum(axis=1)  # (N,)

        mv_lo = f_mid - total_spread
        mv_hi = f_mid + total_spread

        # Only tighten well-resolved boxes with MV
        mv_lo = np.where(well_resolved, mv_lo, base_lo)
        mv_hi = np.where(well_resolved, mv_hi, base_hi)

        f_lo = np.maximum(f_lo, mv_lo)
        f_hi = np.minimum(f_hi, mv_hi)

        # Safety: if intersection produced invalid interval, revert to base
        bad = f_lo > f_hi
        f_lo = np.where(bad, base_lo, f_lo)
        f_hi = np.where(bad, base_hi, f_hi)

        return f_lo, f_hi


# ---------------------------------------------------------------------------
# Natural Interval Extension (NIA) — Phase 3
# ---------------------------------------------------------------------------


class NaturalIntervalInclusion:
    """Inclusion function via natural interval extension of analytic formulas.

    Instead of sampling + Lipschitz margin, directly evaluates the implicit
    function's formula using interval arithmetic operations. Tighter than
    SamplingInclusion for known analytic functions (no Lipschitz margin needed).

    Requires a "recipe" function that expresses f in terms of IA operations.
    """

    def __init__(self, recipe, params: dict | None = None):
        self.recipe = recipe
        self.params = params or {}

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        x_lo, y_lo, z_lo = lo[:, 0], lo[:, 1], lo[:, 2]
        x_hi, y_hi, z_hi = hi[:, 0], hi[:, 1], hi[:, 2]
        return self.recipe(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, self.params)


# --- NIA recipe functions ---------------------------------------------------


def sphere_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = (x-cx)² + (y-cy)² + (z-cz)² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    # Shift to center
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    # Square each axis
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    # Sum
    s_lo = x2_lo + y2_lo + z2_lo
    s_hi = x2_hi + y2_hi + z2_hi
    return s_lo - r2, s_hi - r2


def torus_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = (sqrt(x²+y²) - R)² + z² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    R = params["major_radius"]
    r2 = params["minor_radius"] ** 2
    # Shift to center
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    # x² + y²
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    sum_xy_lo = x2_lo + y2_lo
    sum_xy_hi = x2_hi + y2_hi
    # sqrt(x² + y²)
    rho_lo, rho_hi = ia_sqrt(sum_xy_lo, sum_xy_hi)
    # rho - R
    rho_R_lo = rho_lo - R
    rho_R_hi = rho_hi - R
    # (rho - R)²
    rho_R2_lo, rho_R2_hi = ia_sqr(rho_R_lo, rho_R_hi)
    # z²
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    # (rho - R)² + z² - r²
    f_lo = rho_R2_lo + z2_lo - r2
    f_hi = rho_R2_hi + z2_hi - r2
    return f_lo, f_hi


def thin_shell_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = |x²+y²+z² - r²| - ε"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    eps = params["epsilon"]
    dx_lo, dx_hi = x_lo - cx, x_hi - cx
    dy_lo, dy_hi = y_lo - cy, y_hi - cy
    dz_lo, dz_hi = z_lo - cz, z_hi - cz
    x2_lo, x2_hi = ia_sqr(dx_lo, dx_hi)
    y2_lo, y2_hi = ia_sqr(dy_lo, dy_hi)
    z2_lo, z2_hi = ia_sqr(dz_lo, dz_hi)
    g_lo = x2_lo + y2_lo + z2_lo - r2
    g_hi = x2_hi + y2_hi + z2_hi - r2
    abs_lo, abs_hi = ia_abs(g_lo, g_hi)
    return abs_lo - eps, abs_hi - eps


def high_freq_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = sin(ωx)·sin(ωy)·sin(ωz) - c"""
    w = params["omega"]
    c = params["offset"]
    # Scale by omega
    wx_lo, wx_hi = w * x_lo, w * x_hi
    wy_lo, wy_hi = w * y_lo, w * y_hi
    wz_lo, wz_hi = w * z_lo, w * z_hi
    # sin of each
    sx_lo, sx_hi = ia_sin(wx_lo, wx_hi)
    sy_lo, sy_hi = ia_sin(wy_lo, wy_hi)
    sz_lo, sz_hi = ia_sin(wz_lo, wz_hi)
    # sin(ωx) · sin(ωy)
    sxy_lo, sxy_hi = ia_mul(sx_lo, sx_hi, sy_lo, sy_hi)
    # · sin(ωz)
    f_lo, f_hi = ia_mul(sxy_lo, sxy_hi, sz_lo, sz_hi)
    return f_lo - c, f_hi - c


def whitney_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = x² - y²·z"""
    x2_lo, x2_hi = ia_sqr(x_lo, x_hi)
    y2_lo, y2_hi = ia_sqr(y_lo, y_hi)
    y2z_lo, y2z_hi = ia_mul(y2_lo, y2_hi, z_lo, z_hi)
    return ia_sub(x2_lo, x2_hi, y2z_lo, y2z_hi)


def cusp_nia(x_lo, x_hi, y_lo, y_hi, z_lo, z_hi, params):
    """f = x³ - y²"""
    x3_lo, x3_hi = ia_pow(x_lo, x_hi, 3)
    y2_lo, y2_hi = ia_sqr(y_lo, y_hi)
    return ia_sub(x3_lo, x3_hi, y2_lo, y2_hi)
