"""Inclusion function protocol — the contract between arithmetic engines and the tracer."""

from typing import Protocol

import numpy as np


class InclusionFunction(Protocol):
    """Evaluates guaranteed range of an implicit function over axis-aligned boxes.

    Implementations: IntervalInclusion (IA), AffineInclusion (AA/RAA).
    The tracer depends only on this interface, so the arithmetic backend is swappable.
    """

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Compute conservative range of f over each box [lo[i], hi[i]].

        Args:
            lo: (N, 3) float64 — lower corners of N axis-aligned boxes.
            hi: (N, 3) float64 — upper corners of N axis-aligned boxes.

        Returns:
            f_lo: (N,) float64 — guaranteed lower bound of f within each box.
            f_hi: (N,) float64 — guaranteed upper bound of f within each box.

        Guarantee (Inclusion Property):
            For all x such that lo[i] <= x <= hi[i]:
                f_lo[i] <= f(x) <= f_hi[i]
        """
        ...
