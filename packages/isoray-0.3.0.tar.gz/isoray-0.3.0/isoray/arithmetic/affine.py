"""Affine Arithmetic / Reduced AA — Phase 3 inclusion function engine.

Provides tighter bounds than Standard IA by tracking linear correlations
via noise symbols. Implements the same InclusionFunction protocol.

Representation:
    x̂ = x0 + x1·ε1 + x2·ε2 + ... + xK·εK + δ·ε_acc

All operations are batch: x0 is (N,), xi is (N, K), delta is (N,).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

# ---------------------------------------------------------------------------
# Affine Form data structure
# ---------------------------------------------------------------------------


@dataclass
class AffineForm:
    """Batch affine form with K noise symbols + accumulated error.

    Attributes:
        x0: (N,) central values.
        xi: (N, K) partial deviations for K noise symbols.
        delta: (N,) accumulated non-affine error (RAA remainder).
    """

    x0: np.ndarray  # (N,)
    xi: np.ndarray  # (N, K)
    delta: np.ndarray  # (N,)

    @property
    def N(self) -> int:
        return self.x0.shape[0]

    @property
    def K(self) -> int:
        return self.xi.shape[1]


# ---------------------------------------------------------------------------
# Constructors
# ---------------------------------------------------------------------------


def from_interval(lo: np.ndarray, hi: np.ndarray, symbol_idx: int, max_symbols: int) -> AffineForm:
    """Create an AffineForm from interval [lo, hi].

    Assigns one noise symbol at column `symbol_idx`.

    Args:
        lo: (N,) lower bounds.
        hi: (N,) upper bounds.
        symbol_idx: which column in xi to place the deviation.
        max_symbols: total K columns.

    Returns:
        AffineForm where x0 = midpoint, xi[:, symbol_idx] = half-width.
    """
    N = lo.shape[0]
    x0 = (lo + hi) * 0.5
    rad = (hi - lo) * 0.5
    xi = np.zeros((N, max_symbols), dtype=np.float64)
    xi[:, symbol_idx] = rad
    delta = np.zeros(N, dtype=np.float64)
    return AffineForm(x0=x0, xi=xi, delta=delta)


def constant(val: np.ndarray, max_symbols: int) -> AffineForm:
    """Create a constant AffineForm (no noise)."""
    N = val.shape[0]
    return AffineForm(
        x0=val.copy(),
        xi=np.zeros((N, max_symbols), dtype=np.float64),
        delta=np.zeros(N, dtype=np.float64),
    )


# ---------------------------------------------------------------------------
# Conversion to interval
# ---------------------------------------------------------------------------


def to_interval(af: AffineForm) -> tuple[np.ndarray, np.ndarray]:
    """Convert AffineForm to conservative interval [lo, hi].

    lo = x0 - rad, hi = x0 + rad, where rad = sum(|xi|) + delta.
    """
    rad = np.sum(np.abs(af.xi), axis=1) + af.delta  # (N,)
    return af.x0 - rad, af.x0 + rad


# ---------------------------------------------------------------------------
# RAA reduction
# ---------------------------------------------------------------------------


def reduce(af: AffineForm, max_symbols: int) -> AffineForm:
    """Reduce noise symbols to at most `max_symbols`, merging the rest into delta.

    Keeps the K largest symbols (by absolute value summed over batch).
    """
    K_cur = af.K
    if K_cur <= max_symbols:
        return af

    # Rank symbols by total contribution across batch
    importance = np.sum(np.abs(af.xi), axis=0)  # (K_cur,)
    keep_idx = np.argsort(importance)[-max_symbols:]  # indices of K largest
    drop_idx = np.setdiff1d(np.arange(K_cur), keep_idx)

    new_xi = af.xi[:, keep_idx]  # (N, max_symbols)
    merged = np.sum(np.abs(af.xi[:, drop_idx]), axis=1)  # (N,)
    new_delta = af.delta + merged
    return AffineForm(x0=af.x0.copy(), xi=new_xi, delta=new_delta)


# ---------------------------------------------------------------------------
# Affine operations (exact — no new error)
# ---------------------------------------------------------------------------


def aa_add(a: AffineForm, b: AffineForm) -> AffineForm:
    """a + b."""
    return AffineForm(
        x0=a.x0 + b.x0,
        xi=a.xi + b.xi,
        delta=a.delta + b.delta,
    )


def aa_sub(a: AffineForm, b: AffineForm) -> AffineForm:
    """a - b."""
    return AffineForm(
        x0=a.x0 - b.x0,
        xi=a.xi - b.xi,
        delta=a.delta + b.delta,
    )


def aa_neg(a: AffineForm) -> AffineForm:
    """-a."""
    return AffineForm(x0=-a.x0, xi=-a.xi, delta=a.delta.copy())


def aa_scalar_mul(a: AffineForm, c: float | np.ndarray) -> AffineForm:
    """c * a where c is a scalar or (N,) array."""
    if isinstance(c, np.ndarray):
        return AffineForm(
            x0=c * a.x0,
            xi=np.expand_dims(c, 1) * a.xi,
            delta=np.abs(c) * a.delta,
        )
    return AffineForm(
        x0=c * a.x0,
        xi=c * a.xi,
        delta=abs(c) * a.delta,
    )


def aa_add_const(a: AffineForm, c: float | np.ndarray) -> AffineForm:
    """a + c where c is a scalar or (N,) array."""
    return AffineForm(
        x0=a.x0 + c,
        xi=a.xi.copy(),
        delta=a.delta.copy(),
    )


# ---------------------------------------------------------------------------
# Non-affine operations (introduce error)
# ---------------------------------------------------------------------------


def aa_mul(a: AffineForm, b: AffineForm) -> AffineForm:
    """a * b.

    Linearization: a*b = a0*b0 + (a0*bi + b0*ai)εi + residual.
    Residual includes: cross noise terms, linear delta terms, delta-delta.
    """
    new_xi = a.x0[:, None] * b.xi + b.x0[:, None] * a.xi
    new_x0 = a.x0 * b.x0

    # Residual = |a0|*δ_b + |b0|*δ_a + (Σ|ai| + δ_a)(Σ|bi| + δ_b)
    # The first two terms are the linear delta contributions not in new_xi.
    # The last term bounds all noise×noise, noise×delta, and delta×delta cross terms.
    xi_sum_a = np.sum(np.abs(a.xi), axis=1)
    xi_sum_b = np.sum(np.abs(b.xi), axis=1)
    new_delta = (
        np.abs(a.x0) * b.delta
        + np.abs(b.x0) * a.delta
        + (xi_sum_a + a.delta) * (xi_sum_b + b.delta)
    )

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


def aa_sqr(a: AffineForm) -> AffineForm:
    """a² — optimized for self-multiplication (exploits self-correlation).

    a = a0 + Σ ai·εi + δ·ε_acc
    a² = a0² + 2·a0·Σai·εi + residual

    Residual = 2·|a0|·δ + (Σ|ai| + δ)²
    This accounts for: noise×noise cross terms, noise×delta, and delta².
    Tighter than aa_mul(a, a) because we don't double-count the a0*δ terms.
    """
    new_x0 = a.x0**2
    new_xi = 2.0 * a.x0[:, None] * a.xi

    xi_abs_sum = np.sum(np.abs(a.xi), axis=1)
    new_delta = 2.0 * np.abs(a.x0) * a.delta + (xi_abs_sum + a.delta) ** 2

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


def aa_sqrt(a: AffineForm) -> AffineForm:
    """sqrt(a) via Chebyshev linearization.

    On interval [lo, hi] = [a0-rad, a0+rad]:
    Chebyshev linear approx: α*x + ζ, with error ≤ δ_new.
    """
    lo, hi = to_interval(a)
    lo = np.maximum(lo, 0.0)  # sqrt domain
    hi = np.maximum(hi, lo + 1e-30)

    sqrt_lo = np.sqrt(lo)
    sqrt_hi = np.sqrt(hi)

    # Chebyshev slope: (sqrt(hi) - sqrt(lo)) / (hi - lo)
    denom = hi - lo
    safe_denom = np.where(denom > 1e-30, denom, 1.0)
    alpha = np.where(
        denom > 1e-30, (sqrt_hi - sqrt_lo) / safe_denom, 0.5 / np.maximum(sqrt_lo, 1e-15)
    )

    # Chebyshev intercept: minimize max error
    # For concave function, max error at endpoints and at tangent point
    # tangent point where f'(x) = alpha: x_t = 1/(4*alpha²)
    x_t = np.where(alpha > 1e-30, 1.0 / (4.0 * alpha**2), lo)
    x_t = np.clip(x_t, lo, hi)
    f_t = np.sqrt(x_t)
    line_t = alpha * x_t

    # Errors at endpoints and tangent point
    e_lo = sqrt_lo - alpha * lo
    e_hi = sqrt_hi - alpha * hi
    e_t = f_t - line_t

    e_max = np.maximum(np.maximum(e_lo, e_hi), e_t)
    e_min = np.minimum(np.minimum(e_lo, e_hi), e_t)
    zeta = (e_max + e_min) * 0.5
    delta_new = (e_max - e_min) * 0.5

    new_x0 = alpha * a.x0 + zeta
    new_xi = alpha[:, None] * a.xi
    new_delta = np.abs(alpha) * a.delta + np.abs(delta_new)

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


def aa_sin(a: AffineForm) -> AffineForm:
    """sin(a) via Chebyshev linearization with analytical critical points."""
    lo, hi = to_interval(a)
    return _chebyshev_sincos(a, lo, hi, np.sin, np.cos)


def aa_cos(a: AffineForm) -> AffineForm:
    """cos(a) via Chebyshev linearization with analytical critical points."""
    lo, hi = to_interval(a)
    return _chebyshev_sincos(a, lo, hi, np.cos, lambda x: -np.sin(x))


def _chebyshev_sincos(
    a: AffineForm,
    lo: np.ndarray,
    hi: np.ndarray,
    func,
    dfunc,
) -> AffineForm:
    """Chebyshev linearization for sin/cos with guaranteed error bounds.

    Uses analytical critical point detection to find exact max/min of the
    error function e(x) = func(x) - alpha*x on [lo, hi].
    """
    f_lo = func(lo)
    f_hi = func(hi)
    denom = hi - lo
    wide = denom > 1e-12

    safe_denom = np.where(wide, denom, 1.0)
    alpha = np.where(wide, (f_hi - f_lo) / safe_denom, dfunc(lo))

    # Error at endpoints
    e_lo = f_lo - alpha * lo
    e_hi = f_hi - alpha * hi
    e_max = np.maximum(e_lo, e_hi)
    e_min = np.minimum(e_lo, e_hi)

    # Critical points of e(x) = func(x) - alpha*x: where dfunc(x) = alpha
    # For sin: cos(x) = alpha → x = ±arccos(alpha) + 2kπ
    # For cos: -sin(x) = alpha → x = arcsin(-alpha) + 2kπ, π - arcsin(-alpha) + 2kπ
    # Instead of case analysis, sample densely + check known extrema
    # Use fine grid: max 64 samples per interval to catch all peaks
    n_grid = 64
    for i in range(n_grid):
        t = (i + 0.5) / n_grid
        x_s = lo + t * denom
        e_s = func(x_s) - alpha * x_s
        e_max = np.maximum(e_max, e_s)
        e_min = np.minimum(e_min, e_s)

    # Additional safety: for wide intervals, also check at derivative zeros
    # dfunc(x) = alpha → find x in [lo, hi]
    clamped_alpha = np.clip(alpha, -1.0, 1.0)
    if func is np.sin:
        # cos(x) = alpha → x = ±arccos(alpha) + 2kπ
        base_angles = [np.arccos(clamped_alpha), -np.arccos(clamped_alpha)]
    else:
        # -sin(x) = alpha → sin(x) = -alpha → x = arcsin(-alpha), π - arcsin(-alpha)
        base_angles = [np.arcsin(-clamped_alpha), np.pi - np.arcsin(-clamped_alpha)]

    for base in base_angles:
        # Find all k such that base + 2kπ ∈ [lo, hi]
        k_start = np.ceil((lo - base) / (2 * np.pi)).astype(int)
        for dk in range(-1, 5):
            x_crit = base + (k_start + dk) * 2 * np.pi
            in_range = (x_crit >= lo - 1e-12) & (x_crit <= hi + 1e-12)
            if np.any(in_range):
                e_crit = func(x_crit) - alpha * x_crit
                e_max = np.where(in_range, np.maximum(e_max, e_crit), e_max)
                e_min = np.where(in_range, np.minimum(e_min, e_crit), e_min)

    zeta = (e_max + e_min) * 0.5
    delta_new = (e_max - e_min) * 0.5

    new_x0 = alpha * a.x0 + zeta
    new_xi = alpha[:, None] * a.xi
    new_delta = np.abs(alpha) * a.delta + np.abs(delta_new)

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


def aa_abs(a: AffineForm) -> AffineForm:
    """|a| via interval-based approximation."""
    lo, hi = to_interval(a)

    # Case 1: entirely non-negative → identity
    # Case 2: entirely non-positive → negate
    # Case 3: straddles zero → conservative bound
    all_pos = lo >= 0
    all_neg = hi <= 0

    # For straddle case: |x| on [lo, hi] where lo < 0 < hi
    # Range: [0, max(|lo|, hi)]
    # Chebyshev: slope = (hi + lo)/(hi - lo), min at 0 where |0| - slope*0 > 0
    abs_lo = np.abs(lo)
    abs_hi = np.abs(hi)
    result_hi_straddle = np.maximum(abs_lo, abs_hi)
    result_mid_straddle = result_hi_straddle * 0.5

    new_x0 = np.where(all_pos, a.x0, np.where(all_neg, -a.x0, result_mid_straddle))
    new_xi = np.where(all_pos, 1.0, np.where(all_neg, -1.0, 0.0))[:, None] * a.xi
    new_delta = np.where(all_pos, a.delta, np.where(all_neg, a.delta, result_mid_straddle))

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


def aa_pow(a: AffineForm, n: int) -> AffineForm:
    """Integer power a^n via Chebyshev linearization for guaranteed bounds."""
    if n == 0:
        return constant(np.ones_like(a.x0), a.K)
    if n == 1:
        return AffineForm(x0=a.x0.copy(), xi=a.xi.copy(), delta=a.delta.copy())
    if n == 2:
        return aa_sqr(a)

    # For n >= 3: Chebyshev linearization of x^n on [lo, hi]
    lo, hi = to_interval(a)

    f_lo = lo**n
    f_hi = hi**n
    denom = hi - lo
    wide = denom > 1e-12

    safe_denom = np.where(wide, denom, 1.0)
    alpha = np.where(wide, (f_hi - f_lo) / safe_denom, n * lo ** (n - 1))

    # Error function: e(x) = x^n - alpha*x
    # Critical points: n*x^(n-1) = alpha → x = (alpha/n)^(1/(n-1))
    # Sample densely + check critical points for guaranteed bounds
    e_lo = f_lo - alpha * lo
    e_hi = f_hi - alpha * hi
    e_max = np.maximum(e_lo, e_hi)
    e_min = np.minimum(e_lo, e_hi)

    # Dense sampling
    n_grid = 64
    for i in range(n_grid):
        t = (i + 0.5) / n_grid
        x_s = lo + t * denom
        e_s = x_s**n - alpha * x_s
        e_max = np.maximum(e_max, e_s)
        e_min = np.minimum(e_min, e_s)

    # Analytical critical points: n*x^(n-1) = alpha
    if n % 2 == 0:
        # Even power: x^(n-1) is odd, so one real root for alpha/n > 0
        ratio = alpha / n
        pos_root = np.where(ratio > 0, ratio ** (1.0 / (n - 1)), 0.0)
        for x_c in [pos_root, -pos_root]:
            in_range = (x_c >= lo) & (x_c <= hi)
            if np.any(in_range):
                e_c = x_c**n - alpha * x_c
                e_max = np.where(in_range, np.maximum(e_max, e_c), e_max)
                e_min = np.where(in_range, np.minimum(e_min, e_c), e_min)
    else:
        # Odd power: x^(n-1) is even and non-negative
        # n*x^(n-1) = alpha has real solution when alpha >= 0
        ratio = np.abs(alpha) / n
        root = np.where(ratio > 0, ratio ** (1.0 / (n - 1)), 0.0)
        for sign in [1.0, -1.0]:
            x_c = sign * root
            in_range = (x_c >= lo) & (x_c <= hi)
            if np.any(in_range):
                e_c = x_c**n - alpha * x_c
                e_max = np.where(in_range, np.maximum(e_max, e_c), e_max)
                e_min = np.where(in_range, np.minimum(e_min, e_c), e_min)

    zeta = (e_max + e_min) * 0.5
    delta_new = (e_max - e_min) * 0.5

    new_x0 = alpha * a.x0 + zeta
    new_xi = alpha[:, None] * a.xi
    new_delta = np.abs(alpha) * a.delta + np.abs(delta_new)

    return AffineForm(x0=new_x0, xi=new_xi, delta=new_delta)


# ---------------------------------------------------------------------------
# Inclusion function implementation
# ---------------------------------------------------------------------------


class AffineInclusion:
    """Inclusion function via Affine Arithmetic evaluation of analytic formulas.

    Takes a "recipe" that evaluates f(x, y, z) using AA operations.
    Tighter than NIA for functions with repeated variables (dependency problem).
    """

    def __init__(self, recipe, params: dict | None = None, max_symbols: int = 8):
        self.recipe = recipe
        self.params = params or {}
        self.max_symbols = max_symbols

    def evaluate(self, lo: np.ndarray, hi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        K = self.max_symbols
        # Create initial affine forms for x, y, z (each gets its own noise symbol)
        af_x = from_interval(lo[:, 0], hi[:, 0], symbol_idx=0, max_symbols=K)
        af_y = from_interval(lo[:, 1], hi[:, 1], symbol_idx=1, max_symbols=K)
        af_z = from_interval(lo[:, 2], hi[:, 2], symbol_idx=2, max_symbols=K)

        # Evaluate the recipe using AA operations
        af_result = self.recipe(af_x, af_y, af_z, self.params)

        # Optionally reduce if recipe added too many symbols
        if af_result.K > K:
            af_result = reduce(af_result, K)

        # Convert to interval
        return to_interval(af_result)


# ---------------------------------------------------------------------------
# AA recipe functions for known primitives
# ---------------------------------------------------------------------------


def sphere_aa(af_x, af_y, af_z, params):
    """f = (x-cx)² + (y-cy)² + (z-cz)² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    dx = aa_add_const(af_x, -cx)
    dy = aa_add_const(af_y, -cy)
    dz = aa_add_const(af_z, -cz)
    x2 = aa_sqr(dx)
    y2 = aa_sqr(dy)
    z2 = aa_sqr(dz)
    s = aa_add(aa_add(x2, y2), z2)
    return aa_add_const(s, -r2)


def torus_aa(af_x, af_y, af_z, params):
    """f = (sqrt(x²+y²) - R)² + z² - r²"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    R = params["major_radius"]
    r2 = params["minor_radius"] ** 2
    dx = aa_add_const(af_x, -cx)
    dy = aa_add_const(af_y, -cy)
    dz = aa_add_const(af_z, -cz)
    x2 = aa_sqr(dx)
    y2 = aa_sqr(dy)
    sum_xy = aa_add(x2, y2)
    rho = aa_sqrt(sum_xy)
    rho_R = aa_add_const(rho, -R)
    rho_R2 = aa_sqr(rho_R)
    z2 = aa_sqr(dz)
    s = aa_add(rho_R2, z2)
    return aa_add_const(s, -r2)


def thin_shell_aa(af_x, af_y, af_z, params):
    """f = |x²+y²+z² - r²| - ε"""
    cx, cy, cz = params.get("center", (0.0, 0.0, 0.0))
    r2 = params["radius"] ** 2
    eps = params["epsilon"]
    dx = aa_add_const(af_x, -cx)
    dy = aa_add_const(af_y, -cy)
    dz = aa_add_const(af_z, -cz)
    x2 = aa_sqr(dx)
    y2 = aa_sqr(dy)
    z2 = aa_sqr(dz)
    g = aa_add(aa_add(x2, y2), z2)
    g = aa_add_const(g, -r2)
    abs_g = aa_abs(g)
    return aa_add_const(abs_g, -eps)


def high_freq_aa(af_x, af_y, af_z, params):
    """f = sin(ωx)·sin(ωy)·sin(ωz) - c"""
    w = params["omega"]
    c = params["offset"]
    wx = aa_scalar_mul(af_x, w)
    wy = aa_scalar_mul(af_y, w)
    wz = aa_scalar_mul(af_z, w)
    sx = aa_sin(wx)
    sy = aa_sin(wy)
    sz = aa_sin(wz)
    sxy = aa_mul(sx, sy)
    sxyz = aa_mul(sxy, sz)
    return aa_add_const(sxyz, -c)


def whitney_aa(af_x, af_y, af_z, params):
    """f = x² - y²·z"""
    x2 = aa_sqr(af_x)
    y2 = aa_sqr(af_y)
    y2z = aa_mul(y2, af_z)
    return aa_sub(x2, y2z)


def cusp_aa(af_x, af_y, af_z, params):
    """f = x³ - y²"""
    x3 = aa_pow(af_x, 3)
    y2 = aa_sqr(af_y)
    return aa_sub(x3, y2)
