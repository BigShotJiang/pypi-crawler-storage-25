"""Utilities — centered difference normals, Lipschitz estimation, etc."""

from __future__ import annotations

import numpy as np


def centered_difference_normals(f, pos: np.ndarray, h: float = 1e-5) -> np.ndarray:
    """Compute surface normals via centered difference.

    Evaluates 6N points in a single batch call to f.

    Args:
        f: ImplicitFunction — f(pos) -> (val, grad|None).
        pos: (N, 3) surface points.
        h: finite difference step size.

    Returns:
        normals: (N, 3) unit normals.
    """
    N = pos.shape[0]
    offsets = np.array(
        [[h, 0, 0], [-h, 0, 0], [0, h, 0], [0, -h, 0], [0, 0, h], [0, 0, -h]], dtype=pos.dtype
    )  # (6, 3)

    # Build all 6N query points
    all_points = (pos[None, :, :] + offsets[:, None, :]).reshape(6 * N, 3)

    all_vals, _ = f(all_points)

    v = all_vals.reshape(6, N)
    grad_x = (v[0] - v[1]) / (2.0 * h)
    grad_y = (v[2] - v[3]) / (2.0 * h)
    grad_z = (v[4] - v[5]) / (2.0 * h)

    normals = np.stack([grad_x, grad_y, grad_z], axis=1)  # (N, 3)
    norms = np.linalg.norm(normals, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    return normals / norms


def estimate_lipschitz(
    f,
    bounds: tuple[np.ndarray, np.ndarray],
    n_samples: int = 10000,
    safety: float = 1.5,
    h: float = 1e-5,
    rng: np.random.Generator | None = None,
) -> float:
    """Estimate the Lipschitz constant of an implicit function over a bounding box.

    Samples random points in the AABB, computes gradient norms, and returns
    ``max(||grad||) * safety``.  Uses the analytic gradient when available,
    otherwise falls back to centered finite differences.

    Args:
        f: ImplicitFunction — ``f(pos) -> (val, grad | None)``.
        bounds: ``(lo, hi)`` axis-aligned bounding box, each ``(3,)``.
        n_samples: Number of random sample points.
        safety: Multiplier on max gradient norm (>1 to be conservative).
        h: Step size for centered differences (used only when grad is None).
        rng: Optional NumPy random generator for reproducibility.

    Returns:
        Estimated Lipschitz constant (float).
    """
    if rng is None:
        rng = np.random.default_rng()

    lo = np.asarray(bounds[0], dtype=np.float64)
    hi = np.asarray(bounds[1], dtype=np.float64)

    pts = rng.uniform(lo, hi, (n_samples, 3))
    vals, grad = f(pts)

    if grad is not None:
        grad_norms = np.linalg.norm(grad, axis=1)
    else:
        # Centered finite differences — 6N evaluations
        offsets = np.array(
            [[h, 0, 0], [-h, 0, 0], [0, h, 0], [0, -h, 0], [0, 0, h], [0, 0, -h]],
            dtype=np.float64,
        )
        all_points = (pts[None, :, :] + offsets[:, None, :]).reshape(6 * n_samples, 3)
        all_vals, _ = f(all_points)
        v = all_vals.reshape(6, n_samples)
        gx = (v[0] - v[1]) / (2.0 * h)
        gy = (v[2] - v[3]) / (2.0 * h)
        gz = (v[4] - v[5]) / (2.0 * h)
        grad_norms = np.sqrt(gx**2 + gy**2 + gz**2)

    return float(grad_norms.max() * safety)
