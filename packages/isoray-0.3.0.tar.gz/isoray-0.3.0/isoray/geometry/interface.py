"""Implicit function protocol — the contract for geometry definitions."""

from typing import Protocol

import numpy as np


class ImplicitFunction(Protocol):
    """An implicit function f: R^3 -> R whose zero-level-set defines a surface.

    All evaluations are batch: pos is (N, 3), returns are (N,) and (N, 3)|None.
    """

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        """Evaluate the implicit function (and optionally its gradient).

        Args:
            pos: (N, 3) float64 — query points.

        Returns:
            val:  (N,) float64 — function values. Zero = on surface.
            grad: (N, 3) float64 or None — gradient vectors if available.
        """
        ...

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        """Axis-aligned bounding box of the region of interest.

        Returns:
            lo: (3,) float64 — lower corner.
            hi: (3,) float64 — upper corner.
        """
        ...
