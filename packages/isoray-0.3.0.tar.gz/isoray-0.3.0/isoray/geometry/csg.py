"""CSG operations: union, intersection, difference of implicit functions."""

from __future__ import annotations

import numpy as np


class Union:
    """Union of two implicit functions: min(f1, f2)."""

    def __init__(self, f1, f2):
        self.f1 = f1
        self.f2 = f2

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        v1, g1 = self.f1(pos)
        v2, g2 = self.f2(pos)
        mask = v1 <= v2  # where f1 is the min
        val = np.where(mask, v1, v2)
        grad = None
        if g1 is not None and g2 is not None:
            grad = np.where(mask[:, None], g1, g2)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        lo1, hi1 = self.f1.bounds()
        lo2, hi2 = self.f2.bounds()
        return np.minimum(lo1, lo2), np.maximum(hi1, hi2)


class Intersection:
    """Intersection of two implicit functions: max(f1, f2)."""

    def __init__(self, f1, f2):
        self.f1 = f1
        self.f2 = f2

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        v1, g1 = self.f1(pos)
        v2, g2 = self.f2(pos)
        mask = v1 >= v2  # where f1 is the max
        val = np.where(mask, v1, v2)
        grad = None
        if g1 is not None and g2 is not None:
            grad = np.where(mask[:, None], g1, g2)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        lo1, hi1 = self.f1.bounds()
        lo2, hi2 = self.f2.bounds()
        return np.maximum(lo1, lo2), np.minimum(hi1, hi2)


class Difference:
    """Difference: max(f1, -f2)."""

    def __init__(self, f1, f2):
        self.f1 = f1
        self.f2 = f2

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        v1, g1 = self.f1(pos)
        v2, g2 = self.f2(pos)
        neg_v2 = -v2
        mask = v1 >= neg_v2
        val = np.where(mask, v1, neg_v2)
        grad = None
        if g1 is not None and g2 is not None:
            grad = np.where(mask[:, None], g1, -g2)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        lo1, hi1 = self.f1.bounds()
        return lo1, hi1
