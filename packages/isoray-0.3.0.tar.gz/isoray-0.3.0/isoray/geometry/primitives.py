"""Built-in implicit function primitives: sphere, torus, etc."""

from __future__ import annotations

import numpy as np


class Sphere:
    """Sphere: f(p) = |p - center|^2 - radius^2."""

    def __init__(self, center: np.ndarray | None = None, radius: float = 1.0):
        self.center = np.asarray(center if center is not None else [0.0, 0.0, 0.0])
        self.radius = radius

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        d = pos - self.center  # (N, 3)
        val = np.sum(d**2, axis=1) - self.radius**2  # (N,)
        grad = 2.0 * d  # (N, 3)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        r = self.radius
        return self.center - r, self.center + r


class Torus:
    """Torus: f(p) = (sqrt(x^2 + y^2) - R)^2 + z^2 - r^2.

    Major radius R (center of tube to center of torus),
    minor radius r (tube radius).
    """

    def __init__(
        self,
        major_radius: float = 1.0,
        minor_radius: float = 0.3,
        center: np.ndarray | None = None,
    ):
        self.R = major_radius
        self.r = minor_radius
        self.center = np.asarray(center if center is not None else [0.0, 0.0, 0.0])

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        p = pos - self.center
        x, y, z = p[:, 0], p[:, 1], p[:, 2]
        rho = np.sqrt(x**2 + y**2)
        val = (rho - self.R) ** 2 + z**2 - self.r**2

        # Gradient
        # df/dx = 2*(rho - R) * x/rho
        # df/dy = 2*(rho - R) * y/rho
        # df/dz = 2*z
        safe_rho = np.maximum(rho, 1e-12)
        factor = 2.0 * (rho - self.R) / safe_rho
        grad = np.stack([factor * x, factor * y, 2.0 * z], axis=1)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        extent = self.R + self.r
        lo = self.center - np.array([extent, extent, self.r])
        hi = self.center + np.array([extent, extent, self.r])
        return lo, hi


class ThinShell:
    """Thin spherical shell: f(p) = |x²+y²+z² - r²| - epsilon.

    Creates a shell of thickness ~2*epsilon around a sphere of given radius.
    """

    def __init__(
        self, radius: float = 1.0, epsilon: float = 1e-3, center: np.ndarray | None = None
    ):
        self.radius = radius
        self.epsilon = epsilon
        self.center = np.asarray(center if center is not None else [0.0, 0.0, 0.0])

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        d = pos - self.center
        g = np.sum(d**2, axis=1) - self.radius**2  # (N,)
        val = np.abs(g) - self.epsilon
        # Gradient: sign(g) * 2*d (undefined at g=0, but shell surface is at |g|=eps)
        sign_g = np.sign(g)
        grad = sign_g[:, None] * 2.0 * d
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        r = self.radius * 1.1  # slight expansion
        return self.center - r, self.center + r


class HighFrequencySurface:
    """High-frequency trigonometric surface: f(p) = sin(ωx)·sin(ωy)·sin(ωz) - c."""

    def __init__(self, omega: float = 20.0, offset: float = 0.5, extent: float = 1.0):
        self.omega = omega
        self.offset = offset
        self.extent = extent

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        w = self.omega
        x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
        sx, sy, sz = np.sin(w * x), np.sin(w * y), np.sin(w * z)
        cx, cy, cz = np.cos(w * x), np.cos(w * y), np.cos(w * z)
        val = sx * sy * sz - self.offset
        grad = np.stack(
            [
                w * cx * sy * sz,
                w * sx * cy * sz,
                w * sx * sy * cz,
            ],
            axis=1,
        )
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        e = self.extent
        return np.array([-e, -e, -e]), np.array([e, e, e])


class WhitneyUmbrella:
    """Whitney umbrella (self-intersecting): f(p) = x² - y²·z.

    Self-intersects along the z-axis. Pinch point at the origin.
    """

    def __init__(self, extent: float = 1.5):
        self._extent = extent

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
        val = x**2 - y**2 * z
        grad = np.stack([2.0 * x, -2.0 * y * z, -(y**2)], axis=1)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        e = self._extent
        return np.array([-e, -e, -e]), np.array([e, e, e])


class CuspSurface:
    """Cusp surface: f(p) = x³ - y².

    Has a cusp ridge along the z-axis where gradient degenerates.
    """

    def __init__(self, extent: float = 1.5):
        self._extent = extent

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        x, y, z = pos[:, 0], pos[:, 1], pos[:, 2]
        val = x**3 - y**2
        grad = np.stack([3.0 * x**2, -2.0 * y, np.zeros_like(z)], axis=1)
        return val, grad

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        e = self._extent
        return np.array([-e, -e, -e]), np.array([e, e, e])
