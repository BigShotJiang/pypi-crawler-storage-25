"""Mesh SDF — implicit function from triangle mesh via point_cloud_utils.

Requires the ``mesh`` extra: ``pip install isoray[mesh]``
"""

from __future__ import annotations

from pathlib import Path

import numpy as np


def _import_pcu():
    """Lazy-import point_cloud_utils with a clear error on missing install."""
    try:
        import point_cloud_utils as pcu
    except ImportError:
        raise ImportError(
            "point-cloud-utils is required for MeshSDF.\n"
            "Install it with:  pip install isoray[mesh]"
        ) from None
    return pcu


class MeshSDF:
    """Signed distance field from a triangle mesh.

    Uses pcu.signed_distance_to_mesh for batch SDF queries.
    Lipschitz constant is exactly 1 (property of SDF).
    Returns smooth vertex normals interpolated via barycentric coordinates.
    """

    def __init__(self, path: str | Path, padding: float = 0.1):
        pcu = _import_pcu()

        self._path = Path(path)
        self._vertices, self._faces = pcu.load_mesh_vf(str(self._path))
        self._vertices = np.ascontiguousarray(self._vertices, dtype=np.float64)
        self._faces = np.ascontiguousarray(self._faces, dtype=np.int32)
        self._padding = padding

        # Precompute bounds from mesh extents
        v_min = self._vertices.min(axis=0)
        v_max = self._vertices.max(axis=0)
        margin = (v_max - v_min) * self._padding
        self._lo = v_min - margin
        self._hi = v_max + margin

        # Merge duplicate vertices (STL has unshared vertices per face)
        _, unique_idx = np.unique(
            np.round(self._vertices, decimals=6),
            axis=0,
            return_inverse=True,
        )
        n_unique = unique_idx.max() + 1
        v_merged = np.zeros((n_unique, 3), dtype=np.float64)
        np.add.at(v_merged, unique_idx, self._vertices)
        counts = np.bincount(unique_idx, minlength=n_unique)
        v_merged /= counts[:, None]

        self._f_merged = unique_idx[self._faces.ravel()].reshape(-1, 3)

        # Smooth vertex normals on merged mesh
        self._vertex_normals = pcu.estimate_mesh_vertex_normals(
            np.ascontiguousarray(v_merged),
            np.ascontiguousarray(self._f_merged, dtype=np.int32),
            weighting_type="area",
        )

    def __call__(self, pos: np.ndarray) -> tuple[np.ndarray, np.ndarray | None]:
        pcu = _import_pcu()
        pts = np.ascontiguousarray(pos, dtype=np.float64)
        sdf, fid, bc = pcu.signed_distance_to_mesh(
            pts,
            self._vertices,
            self._faces,
        )

        # Interpolate smooth vertex normals at closest points
        face_vi = self._f_merged[fid]  # (N, 3) merged vertex indices
        normals = (
            bc[:, 0:1] * self._vertex_normals[face_vi[:, 0]]
            + bc[:, 1:2] * self._vertex_normals[face_vi[:, 1]]
            + bc[:, 2:3] * self._vertex_normals[face_vi[:, 2]]
        )
        norms = np.linalg.norm(normals, axis=1, keepdims=True)
        normals /= np.maximum(norms, 1e-12)

        # Return normals as None for the inclusion function: these are
        # interpolated vertex normals, NOT the true SDF gradient.  They are
        # close to grad(SDF) on smooth regions but can diverge near sharp
        # edges and thin features.  GradientInclusion's sign test / MV form
        # require an exact gradient to guarantee the inclusion property.
        # Normals are still available via a second call for shading.
        return sdf, None

    def bounds(self) -> tuple[np.ndarray, np.ndarray]:
        return self._lo.copy(), self._hi.copy()

    @property
    def name(self) -> str:
        return self._path.stem
