from typing import List, Optional, cast

from trilogy.constants import logger
from trilogy.core import graph as nx
from trilogy.core.enums import BooleanOperator, Derivation, FunctionType
from trilogy.core.exceptions import AmbiguousRelationshipResolutionException
from trilogy.core.graph import approximation as ax
from trilogy.core.graph_models import (
    ReferenceGraph,
    SearchCriteria,
    concept_to_node,
    prune_sources_for_conditions,
)
from trilogy.core.models.build import (
    BuildConcept,
    BuildConditional,
    BuildDatasource,
    BuildFunction,
    BuildWhereClause,
)
from trilogy.core.models.build_environment import BuildEnvironment
from trilogy.core.processing.condition_utility import (
    condition_implies,
    decompose_condition,
)
from trilogy.core.processing.node_generators.common import (
    reinject_common_join_keys_v2,
)
from trilogy.core.processing.nodes import History, MergeNode, StrategyNode
from trilogy.core.processing.utility import padding
from trilogy.utility import unique

LOGGER_PREFIX = "[GEN_MERGE_NODE]"
AMBIGUITY_CHECK_LIMIT = 20
EGO_RADIUS = 10


def filter_pseudonyms_for_source(
    ds_graph: nx.DiGraph, node: str, pseudonyms: set[tuple[str, str]]
):
    to_remove = set()
    for edge in ds_graph.edges:
        if edge in pseudonyms:
            lengths = {}
            for n in edge:
                try:
                    lengths[n] = nx.shortest_path_length(ds_graph, node, n)
                except nx.NetworkXNoPath:
                    lengths[n] = 999
            to_remove.add(max(lengths, key=lambda x: lengths.get(x, 0)))
    for node in to_remove:
        ds_graph.remove_node(node)


def extract_address(node: str):
    return node.split("~")[1].split("@")[0]


def extract_concept(node: str, env: BuildEnvironment):
    # removing this as part of canonical mapping
    # if node in env.alias_origin_lookup:
    #     return env.alias_origin_lookup[node]
    return env.canonical_concepts[node]


def filter_unique_graphs(graphs: list[list[str]]) -> list[list[str]]:
    unique_graphs: list[set[str]] = []

    # sort graphs from largest to smallest
    graphs.sort(key=lambda x: len(x), reverse=True)
    for graph in graphs:
        if not any(set(graph).issubset(x) for x in unique_graphs):
            unique_graphs.append(set(graph))

    return [list(x) for x in unique_graphs]


def extract_ds_components(
    g: nx.DiGraph, nodelist: list[str], pseudonyms: set[tuple[str, str]]
) -> list[list[str]]:
    graphs = []
    # from trilogy.hooks.graph_hook import GraphHook
    # GraphHook().query_graph_built(g, highlight_nodes=nodelist)
    for node in g.nodes:
        if not node.startswith("ds~"):
            continue
        local = g.copy()
        filter_pseudonyms_for_source(local, node, pseudonyms)
        ds_graph: nx.DiGraph = nx.ego_graph(local, node, radius=EGO_RADIUS).copy()
        graphs.append(
            [extract_address(x) for x in ds_graph.nodes if not str(x).startswith("ds~")]
        )
    # if we had no ego graphs, return all concepts
    if not graphs:
        return [[extract_address(node) for node in nodelist]]
    graphs = filter_unique_graphs(graphs)
    for node in nodelist:
        parsed = extract_address(node)
        if not any(parsed in x for x in graphs):
            graphs.append([parsed])
    return graphs


def determine_induced_minimal_nodes(
    G: ReferenceGraph,
    nodelist: list[str],
    environment: BuildEnvironment,
    filter_downstream: bool,
    accept_partial: bool = False,
    synonyms: dict[str, str] = {},
) -> nx.DiGraph | None:
    # to_undirected already returns a fresh graph with independent rust core
    # and attrs; the extra .copy() is double work.
    H: nx.Graph = nx.to_undirected(G)
    nodelist_set = set(nodelist)

    # Add weights to edges based on target node's derivation type. The
    # default weight is 1 (used by _weight_triples when `weight` key is
    # missing), so we only write to _edge_attrs for the rare BASIC non
    # ATTR_ACCESS case — avoids a per-edge __setitem__ through the layered
    # edge-view API, which dominated this function's cost at ~874k calls
    # per adhoc_perf run.
    g_concepts = G.concepts
    H_edge_attrs = H._edge_attrs  # type: ignore[attr-defined]
    for edge in G.edges():
        target = edge[1]
        target_lookup = g_concepts.get(target)
        if (
            target_lookup is not None
            and target_lookup.derivation == Derivation.BASIC
            and not (
                isinstance(target_lookup.lineage, BuildFunction)
                and target_lookup.lineage.operator == FunctionType.ATTR_ACCESS
            )
        ):
            # H is undirected so the edge key is (min, max) order.
            left, right = edge[0], target
            key = (left, right) if left <= right else (right, left)
            attrs = H_edge_attrs.get(key)
            if attrs is None:
                H_edge_attrs[key] = {"weight": 50}
            else:
                attrs["weight"] = 50

    nodes_to_remove = []
    derivations_to_remove = (
        Derivation.CONSTANT,
        Derivation.AGGREGATE,
        Derivation.FILTER,
    )
    for node, lookup in g_concepts.items():
        # inclusion of aggregates can create ambiguous node relation chains
        # there may be a better way to handle this
        # can be revisited if we need to connect a derived synonym based on an aggregate
        if lookup.derivation in derivations_to_remove:
            nodes_to_remove.append(node)
        # purge a node if we're already looking for all it's parents
        elif filter_downstream and lookup.derivation != Derivation.ROOT:
            nodes_to_remove.append(node)
    if nodes_to_remove:
        # logger.debug(f"Removing nodes {nodes_to_remove} from graph")
        H.remove_nodes_from(nodes_to_remove)
    isolates = list(nx.isolates(H))
    if isolates:
        # logger.debug(f"Removing isolates {isolates} from graph")
        H.remove_nodes_from(isolates)

    zero_out = [x for x in H.nodes if G.out_degree(x) == 0 and x not in nodelist_set]
    while zero_out:
        logger.debug(f"Removing zero out nodes {zero_out} from graph")
        H.remove_nodes_from(zero_out)
        zero_out = [
            x for x in H.nodes if G.out_degree(x) == 0 and x not in nodelist_set
        ]
    try:
        # Use weight attribute for Dijkstra pathfinding
        paths = nx.multi_source_dijkstra_path(H, nodelist, weight="weight")
        # logger.debug(f"Paths found for {nodelist} {paths}")
    except nx.exception.NodeNotFound as e:
        logger.debug(f"Unable to find paths for {nodelist}- {str(e)}")
        return None
    path_removals = list(x for x in H.nodes if x not in paths)
    if path_removals:
        # logger.debug(f"Removing paths {path_removals} from graph")
        H.remove_nodes_from(path_removals)
    # logger.debug(f"Graph after path removal {H.nodes}")
    # steiner_tree/subgraph already return fresh graphs with independent cores.
    sG: nx.Graph = ax.steinertree.steiner_tree(H, nodelist, weight="weight")
    if not sG.nodes:
        logger.debug(f"No Steiner tree found for nodes {nodelist}")
        return None

    logger.debug(f"Steiner tree found for nodes {nodelist} {sG.nodes}")
    final = cast(ReferenceGraph, nx.subgraph(G, sG.nodes))

    final_nodes = set(final.nodes)
    for edge in G.edges:
        if edge[1] in final_nodes and edge[0].startswith("ds~"):
            ds = G.datasources[edge[0]]
            concept = environment.canonical_concepts[extract_address(edge[1])]
            if not accept_partial:
                partial_addresses = {x.address for x in ds.partial_concepts}
                if concept.address in partial_addresses:
                    continue
            final.add_edge(*edge)

    # readd concepts that need to be in the output for proper discovery
    reinject_common_join_keys_v2(G, final, synonyms)

    # all concept nodes must have a parent
    if not all(
        [
            final.in_degree(node) > 0
            for node in final.nodes
            if node.startswith("c~") and node in nodelist
        ]
    ):
        missing = [
            node
            for node in final.nodes
            if node.startswith("c~") and final.in_degree(node) == 0
        ]
        logger.debug(f"Skipping graph for {nodelist} as no in_degree {missing}")
        return None

    if not all([node in final.nodes for node in nodelist]):
        missing = [node for node in nodelist if node not in final.nodes]
        logger.debug(
            f"Skipping graph for initial list {nodelist} as missing nodes {missing} from final graph {final.nodes}"
        )

        return None
    logger.debug(f"Found final graph {final.nodes}")
    return final


def canonicalize_addresses(
    reduced_concept_set: set[str], environment: BuildEnvironment
) -> set[str]:
    """
    Convert a set of concept addresses to their canonical form.
    This is necessary to ensure that we can compare concepts correctly,
    especially when dealing with aliases or pseudonyms.
    """
    return set(
        environment.concepts[x].address if x in environment.concepts else x
        for x in reduced_concept_set
    )


def detect_ambiguity_and_raise(
    all_concepts: list[BuildConcept],
    reduced_concept_sets_raw: list[set[str]],
    environment: BuildEnvironment,
) -> None:
    final_candidates: list[set[str]] = []
    common: set[str] = set()
    # find all values that show up in every join_additions
    reduced_concept_sets = [
        canonicalize_addresses(x, environment) for x in reduced_concept_sets_raw
    ]
    for ja in reduced_concept_sets:
        if not common:
            common = ja
        else:
            common = common.intersection(ja)
        if all(set(ja).issubset(y) for y in reduced_concept_sets):
            final_candidates.append(ja)
    if not final_candidates:
        filtered_paths = [x.difference(common) for x in reduced_concept_sets]
        raise AmbiguousRelationshipResolutionException(
            message=f"Multiple possible concept additions (intermediate join keys) found to resolve {[x.address for x in all_concepts]}, have {' or '.join([str(x) for x in reduced_concept_sets])}. Different paths are is: {filtered_paths}",
            parents=filtered_paths,
        )


def has_synonym(concept: BuildConcept, others: list[list[BuildConcept]]) -> bool:
    return any(
        c.address in concept.pseudonyms or concept.address in c.pseudonyms
        for sublist in others
        for c in sublist
    )


def filter_relevant_subgraphs(
    subgraphs: list[list[BuildConcept]],
) -> list[list[BuildConcept]]:
    return [
        subgraph
        for subgraph in subgraphs
        if len(subgraph) > 1
        or (
            len(subgraph) == 1
            and not has_synonym(subgraph[0], [x for x in subgraphs if x != subgraph])
        )
    ]


def resolve_weak_components(
    all_concepts: List[BuildConcept],
    environment: BuildEnvironment,
    environment_graph: ReferenceGraph,
    filter_downstream: bool = True,
    accept_partial: bool = False,
    search_conditions: BuildWhereClause | None = None,
) -> list[list[BuildConcept]] | None:
    break_flag = False
    found = []
    search_graph = environment_graph.copy()
    prune_sources_for_conditions(
        search_graph,
        (
            SearchCriteria.PARTIAL_INCLUDING_SCOPED
            if accept_partial
            else SearchCriteria.FULL_ONLY
        ),
        conditions=search_conditions,
    )
    reduced_concept_sets: list[set[str]] = []

    count = 0
    node_list = sorted(
        [
            concept_to_node(c.with_default_grain())
            for c in all_concepts
            if "__preql_internal" not in c.address
        ]
    )
    synonyms: dict[str, str] = {}
    for c in all_concepts:
        for x in c.pseudonyms:
            synonyms[x] = c.address
    # from trilogy.hooks.graph_hook import GraphHook
    # GraphHook().query_graph_built(search_graph, highlight_nodes=[concept_to_node(c.with_default_grain()) for c in all_concepts if "__preql_internal" not in c.address])

    # loop through, removing new nodes we find
    # to ensure there are not ambiguous discovery paths
    # (if we did not care about raising ambiguity errors, we could just use the first one)
    while break_flag is not True:
        g: nx.DiGraph | None = None
        count += 1
        if count > AMBIGUITY_CHECK_LIMIT:
            break_flag = True
        try:
            g = determine_induced_minimal_nodes(
                search_graph,
                node_list,
                filter_downstream=filter_downstream,
                accept_partial=accept_partial,
                environment=environment,
                synonyms=synonyms,
            )

            if not g or not g.nodes:
                break_flag = True
                continue
            if not nx.is_weakly_connected(g):
                break_flag = True
                continue
            # from trilogy.hooks.graph_hook import GraphHook
            # GraphHook().query_graph_built(g, highlight_nodes=[concept_to_node(c.with_default_grain()) for c in all_concepts if "__preql_internal" not in c.address])
            all_graph_concepts = [
                extract_concept(extract_address(node), environment)
                for node in g.nodes
                if node.startswith("c~")
            ]
            new = [x for x in all_graph_concepts if x.address not in all_concepts]

            if not new:
                break_flag = True
            # remove our new nodes for the next search path
            for n in new:
                node = concept_to_node(n)
                if node in search_graph:
                    search_graph.remove_node(node)
            # TODO: figure out better place for debugging
            # from trilogy.hooks.graph_hook import GraphHook
            # GraphHook().query_graph_built(g, highlight_nodes=[concept_to_node(c.with_default_grain()) for c in all_concepts if "__preql_internal" not in c.address])
            found.append(g)
            new_addresses = set([x.address for x in new if x.address not in synonyms])
            reduced_concept_sets.append(new_addresses)

        except nx.exception.NetworkXNoPath:
            break_flag = True
        if g and not g.nodes:
            break_flag = True
    if not found:
        return None

    detect_ambiguity_and_raise(all_concepts, reduced_concept_sets, environment)

    # take our first one as the actual graph
    g = found[0]

    subgraphs: list[list[BuildConcept]] = []
    # components = nx.strongly_connected_components(g)
    node_list = [x for x in g.nodes if x.startswith("c~")]
    components = extract_ds_components(g, node_list, environment_graph.pseudonyms)
    logger.debug(f"Extracted components {components} from {node_list}")
    for component in components:
        # we need to take unique again as different addresses may map to the same concept
        sub_component = unique(
            # sorting here is required for reproducibility
            # todo: we should sort in an optimized order
            [extract_concept(x, environment) for x in sorted(component)],
            "address",
        )
        if not sub_component:
            continue
        subgraphs.append(sub_component)
    fgraphs = []
    for subgraph in subgraphs:
        # don't re-enter an unresolvable root when injecting concepts.
        resolvable = [
            x
            for x in subgraph
            if not (
                x.derivation == Derivation.ROOT
                and x.canonical_address
                not in environment.materialized_canonical_concepts
            )
        ]
        if not resolvable:
            logger.info(f"Subgraph {subgraph} is not resolvable, skipping")
            continue
        fgraphs.append(subgraph)
    return fgraphs


def subgraphs_to_merge_node(
    concept_subgraphs: list[list[BuildConcept]],
    depth: int,
    all_concepts: List[BuildConcept],
    environment,
    g,
    source_concepts,
    history,
    conditions,
    output_concepts: List[BuildConcept],
    search_conditions: BuildWhereClause | None = None,
    filter_conditions: BuildWhereClause | None = None,
    enable_early_exit: bool = True,
):

    parents: List[StrategyNode] = []
    logger.info(
        f"{padding(depth)}{LOGGER_PREFIX} fetching subgraphs {[[c.address for c in subgraph] for subgraph in concept_subgraphs]}"
    )
    for graph in concept_subgraphs:
        logger.info(
            f"{padding(depth)}{LOGGER_PREFIX} fetching subgraph {[c.address for c in graph]}"
        )

        subgraph_addrs = {c.address for c in graph}
        applicable_conditions = (
            filter_conditions if filter_conditions is not None else search_conditions
        )
        subgraph_conditions = (
            _conditions_for_subgraph(applicable_conditions, subgraph_addrs)
            if applicable_conditions
            else None
        )
        parent: StrategyNode | None = source_concepts(
            mandatory_list=graph,
            environment=environment,
            g=g,
            depth=depth + 1,
            history=history,
            conditions=subgraph_conditions,
        )
        if not parent:
            logger.info(
                f"{padding(depth)}{LOGGER_PREFIX} Unable to instantiate target subgraph"
            )
            return None
        logger.info(
            f"{padding(depth)}{LOGGER_PREFIX} finished subgraph fetch for {[c.address for c in graph]}, have parent {type(parent)} w/ {[c.address for c in parent.output_concepts]}"
        )
        parents.append(parent)
    input_c = []
    output_c = []
    for x in parents:
        for y in x.usable_outputs:
            input_c.append(y)
            if y in output_concepts:
                output_c.append(y)
            elif any(y.address in c.pseudonyms for c in output_concepts) or any(
                c.address in y.pseudonyms for c in output_concepts
            ):
                output_c.append(y)

    if len(parents) == 1 and enable_early_exit:

        logger.info(
            f"{padding(depth)}{LOGGER_PREFIX} only one parent node, exiting early w/ {[c.address for c in parents[0].output_concepts]}"
        )
        parent = parents[0]
        return parent

    rval = MergeNode(
        input_concepts=unique(input_c, "address"),
        output_concepts=output_concepts,
        environment=environment,
        parents=parents,
        depth=depth,
        # hidden_concepts=[]
        # conditions=conditions,
        # conditions=search_conditions.conditional,
        # preexisting_conditions=search_conditions.conditional,
        # node_joins=[]
    )
    return rval


def _preserved_conditions(
    conditions: BuildWhereClause, environment: BuildEnvironment
) -> BuildWhereClause | None:
    """Return only condition atoms covered by some datasource's complete_where.

    If the full conditions imply a datasource's non_partial_for, the atoms of that
    non_partial_for are "owned" by an exact-match source and should be preserved as
    a WHERE filter rather than flattened into concept projections.
    """
    atoms = decompose_condition(conditions.conditional)
    atom_str_map = {str(a): a for a in atoms}
    preserved = []
    seen: set[str] = set()
    for ds in environment.datasources.values():
        if not isinstance(ds, BuildDatasource) or not ds.non_partial_for:
            continue
        if not condition_implies(
            conditions.conditional, ds.non_partial_for.conditional
        ):
            continue
        for np_atom in decompose_condition(ds.non_partial_for.conditional):
            key = str(np_atom)
            if key in atom_str_map and key not in seen:
                preserved.append(atom_str_map[key])
                seen.add(key)
    if not preserved:
        return None
    cond = preserved[0]
    for a in preserved[1:]:
        cond = BuildConditional(left=cond, right=a, operator=BooleanOperator.AND)
    return BuildWhereClause(conditional=cond)


def _conditions_for_subgraph(
    conditions: BuildWhereClause,
    subgraph_addrs: set[str],
) -> BuildWhereClause | None:
    """Return condition atoms whose concepts are all present in the subgraph."""
    atoms = decompose_condition(conditions.conditional)
    relevant = [
        a
        for a in atoms
        if all(c.address in subgraph_addrs for c in a.concept_arguments)
    ]
    if not relevant:
        return None
    cond = relevant[0]
    for a in relevant[1:]:
        cond = BuildConditional(left=cond, right=a, operator=BooleanOperator.AND)
    return BuildWhereClause(conditional=cond)


def gen_merge_node(
    all_concepts: List[BuildConcept],
    g: ReferenceGraph,
    environment: BuildEnvironment,
    depth: int,
    source_concepts,
    accept_partial: bool = False,
    history: History | None = None,
    conditions: BuildConditional | None = None,
    search_conditions: BuildWhereClause | None = None,
) -> Optional[MergeNode]:

    # we do not actually APPLY these conditions anywhere
    # though we could look at doing that as an optimization
    # it's important to include them so the base discovery loop that was generating
    # the merge node can then add them automatically
    # so we should not return a node with preexisting conditions
    if search_conditions:
        all_search_concepts = unique(
            all_concepts + list(search_conditions.row_arguments), "address"
        )
        # Preserve only atoms that are satisfied by a datasource's complete_where so
        # that partial-datasource exact-match resolution works inside each subgraph.
        # Extra condition concepts are still in all_search_concepts as projections.
        effective_search_conditions = _preserved_conditions(
            search_conditions, environment
        )
    else:
        effective_search_conditions = None
        all_search_concepts = all_concepts
    all_search_concepts = sorted(all_search_concepts, key=lambda x: x.address)
    break_set = set([x.address for x in all_search_concepts])
    for filter_downstream in [True, False]:
        # Skip condition pruning only when conditions are "owned" by a partial datasource;
        # otherwise retain normal pruning so regular WHERE conditions still gate resolution.
        resolved_search_conditions = (
            None if effective_search_conditions is not None else search_conditions
        )
        weak_resolve = resolve_weak_components(
            all_search_concepts,
            environment,
            g,
            filter_downstream=filter_downstream,
            accept_partial=accept_partial,
            search_conditions=resolved_search_conditions,
        )
        if not weak_resolve:
            logger.info(
                f"{padding(depth)}{LOGGER_PREFIX} wasn't able to resolve graph through intermediate concept injection with accept_partial {accept_partial}, filter_downstream {filter_downstream}"
            )
            continue

        log_graph = [[y.address for y in x] for x in weak_resolve]
        logger.info(
            f"{padding(depth)}{LOGGER_PREFIX} Was able to resolve graph through weak component resolution - final graph {log_graph}"
        )
        for flat in log_graph:
            if set(flat) == break_set:
                logger.info(
                    f"{padding(depth)}{LOGGER_PREFIX} expanded concept resolution was identical to search resolution; breaking to avoid recursion error."
                )
                return None
        return subgraphs_to_merge_node(
            weak_resolve,
            depth=depth,
            all_concepts=all_search_concepts,
            environment=environment,
            g=g,
            source_concepts=source_concepts,
            history=history,
            conditions=conditions,
            search_conditions=effective_search_conditions,
            filter_conditions=search_conditions,
            output_concepts=all_concepts,
        )
    return None
