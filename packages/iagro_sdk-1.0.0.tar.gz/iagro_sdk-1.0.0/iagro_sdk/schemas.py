from uuid import UUID
from datetime import datetime
from typing import Generic, List, Optional
from typing import TypeVar

from pydantic import BaseModel
from pydantic import ConfigDict

T = TypeVar("T")


class BaseSchema(BaseModel):
    model_config = ConfigDict(
        extra="ignore",
        arbitrary_types_allowed=True,
        populate_by_name=True,
        from_attributes=True,
    )

class BaseSchemaOut(BaseSchema):
    id: UUID
    created_at: datetime
    updated_at: datetime


class PaginationMeta(BaseModel):
    current_page: int
    per_page: int
    total_items: int
    total_pages: int
    has_next: bool
    has_prev: bool

class PaginatedResponse(BaseModel, Generic[T]):
    data: List[T]
    pagination: PaginationMeta

class Paginator(BaseModel):
    skip: int = 0
    limit: int = 100

class UserDecodedInfo(BaseModel):
    sub: str
    email: Optional[str]
    preferred_username: str
    name: str
    given_name: str
    family_name: str
    roles: List[str]
    permissions: List[str]

class AuthContext(BaseModel):
    user: UserDecodedInfo
    property_ids: Optional[List[UUID]]