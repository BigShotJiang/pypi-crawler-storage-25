from abc import ABC, abstractmethod

from iagro_sdk.enums import RolesEnum, PermissionEnum
from iagro_sdk.schemas import AuthContext


class BasePermission(ABC):
    status_code: int = 403
    detail: str = "Permission denied"

    @abstractmethod
    def has_permission(self, context: AuthContext) -> bool: ...


class HasAnyRole(BasePermission):
    """Verifica se possui alguma das roles requeridas"""
    def __init__(self, *roles: RolesEnum):
        self.roles = roles
        self.detail = f"Required roles: {[role.value for role in roles]}"

    def has_permission(self, context: AuthContext) -> bool:
        return any(role in context.user.roles for role in self.roles)


class HasPermission(BasePermission):
    "Verifica se possui todas as permissões requeridas"
    def __init__(self, *permissions: PermissionEnum):
        self.permissions = permissions
        self.detail = f"Required permissions: {[perm.value for perm in permissions]}"

    def has_permission(self, context: AuthContext) -> bool:
        return all(perm.value in context.user.permissions for perm in self.permissions)


class AnyOf(BasePermission):
    """Passa se qualquer uma das permissões passar (lógica OR)."""

    def __init__(self, *permissions: BasePermission):
        self._permissions = permissions

    @property
    def detail(self) -> str:
        return " or ".join(p.detail for perm in self._permissions)

    def has_permission(self, context: AuthContext) -> bool:
        return any(perm.has_permission(context) for perm in self._permissions)


class AllOf(BasePermission):
    """Passa somente se todas as permissões passarem (lógica AND)."""

    def __init__(self, *permissions: BasePermission):
        self._permissions = permissions

    @property
    def detail(self) -> str:
        return " and ".join(perm.detail for perm in self._permissions)

    def has_permission(self, context: AuthContext) -> bool:
        return all(perm.has_permission(context) for perm in self._permissions)