import uuid
from datetime import datetime
from zoneinfo import ZoneInfo

from pydantic import ConfigDict
from sqlalchemy import TIMESTAMP, text, func, Index
from sqlalchemy.orm import declared_attr
from sqlmodel import SQLModel, Field

UTC = ZoneInfo("UTC")

class BaseModelMixin(SQLModel, table=False):
    id: uuid.UUID = Field(
        default_factory=uuid.uuid4,
        primary_key=True,
        index=True,
    )
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        sa_type=TIMESTAMP(timezone=True), # Type: ignore
        sa_column_kwargs={
            "server_default": text("CURRENT_TIMESTAMP"),
        },
        nullable=False,
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        sa_type=TIMESTAMP(timezone=True), # Type: ignore
        sa_column_kwargs={
            "server_default": text("CURRENT_TIMESTAMP"),
            "onupdate": func.now(),
        },
        nullable=False,
    )

    model_config = ConfigDict(
        extra='forbid',
        arbitrary_types_allowed=True,
        populate_by_name=True,
    )

class BaseModelPropertyAssociated(BaseModelMixin):
    def __init_subclass__(cls, **kwargs):
        """Define o argumentos de tabela base junto aos que vão ser passados nas subclasses"""
        super().__init_subclass__(**kwargs)
        tablename = cls.__dict__.get("__tablename__")
        if tablename:
            base_args = (Index(f"ix_{tablename}_id_property_id", "id", "property_id", unique=True),)
            child_args = cls.__dict__.get("__table_args__", ())
            cls.__table_args__ = base_args + child_args

    property_id: uuid.UUID = Field(..., foreign_key="property.id")