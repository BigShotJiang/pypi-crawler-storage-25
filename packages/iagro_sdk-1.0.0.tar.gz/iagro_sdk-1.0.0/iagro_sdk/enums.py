from enum import Enum


class PermissionEnum(str, Enum):
    READ = "read"
    WRITE = "write"


class RolesEnum(str, Enum):
    PRODUCER = "producer"
    ADMIN = "admin"
