import uuid
from abc import ABC
from iagro_sdk.schemas import AuthContext
from iagro_sdk.enums import RolesEnum


class BaseController(ABC):
    def __init__(self, context: AuthContext):
        self.context = context

    def has_role(self, role: RolesEnum) -> bool:
        return role in self.context.user.roles

    def can_access_property(self, property_id: uuid.UUID) -> bool:
        return property_id in self.context.property_ids