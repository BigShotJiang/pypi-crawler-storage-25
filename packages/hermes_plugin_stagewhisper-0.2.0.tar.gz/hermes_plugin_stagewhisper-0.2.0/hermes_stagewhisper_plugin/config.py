"""Config helpers for the StageWhisper Hermes plugin."""

from __future__ import annotations

import os

_ENV_VARS = [
    "STAGEWHISPER_API_URL",
    "STAGEWHISPER_INTEGRATION_ID",
    "STAGEWHISPER_RELAY_TOKEN",
    "STAGEWHISPER_PLUGIN_SECRET_KEY",
    "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
    "STAGEWHISPER_REASONING_MODEL",
    "OPENAI_API_KEY",
    "OPENAI_BASE_URL",
]


def is_paired() -> bool:
    return all(
        os.getenv(v)
        for v in [
            "STAGEWHISPER_API_URL",
            "STAGEWHISPER_INTEGRATION_ID",
            "STAGEWHISPER_RELAY_TOKEN",
        ]
    )


def is_byo_ready() -> bool:
    return is_paired() and all(
        os.getenv(v)
        for v in [
            "STAGEWHISPER_PLUGIN_SECRET_KEY",
            "STAGEWHISPER_DESKTOP_PUBLIC_KEY",
        ]
    )


def get_api_url() -> str:
    return os.getenv("STAGEWHISPER_API_URL", "http://127.0.0.1:8000")


def get_integration_id() -> str | None:
    return os.getenv("STAGEWHISPER_INTEGRATION_ID")


def get_relay_token() -> str | None:
    return os.getenv("STAGEWHISPER_RELAY_TOKEN")
