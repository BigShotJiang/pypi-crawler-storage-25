"""StageWhisper plugin for Hermes Agent.

Provides:
- Tools: stagewhisper_pair, stagewhisper_relay, stagewhisper_unpair
- CLI:  hermes stagewhisper pair|unpair|status|start|stop|restart
- Auto-start relay on plugin load when configured

Install: pip install hermes-plugin-stagewhisper
(A plugin directory at ~/.hermes/plugins/stagewhisper/)
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def register(ctx) -> None:
    from . import schemas, tools
    from .cli import _handle_command, _setup_argparse
    from .config import is_paired

    ctx.register_tool(
        name="stagewhisper_pair",
        toolset="stagewhisper",
        schema=schemas.STAGEWHISPER_PAIR,
        handler=lambda args, **kw: tools.stagewhisper_pair(
            code=args.get("code", ""),
            label=args.get("label", "StageWhisper"),
            api_url=args.get("api_url"),
        ),
    )

    ctx.register_tool(
        name="stagewhisper_relay",
        toolset="stagewhisper",
        schema=schemas.STAGEWHISPER_RELAY,
        handler=lambda args, **kw: tools.stagewhisper_relay(
            action=args.get("action", "status"),
        ),
    )

    ctx.register_tool(
        name="stagewhisper_unpair",
        toolset="stagewhisper",
        schema=schemas.STAGEWHISPER_UNPAIR,
        handler=lambda args, **kw: tools.stagewhisper_unpair(),
    )

    ctx.register_cli_command(
        name="stagewhisper",
        help="Manage StageWhisper BYO AI relay",
        setup_fn=_setup_argparse,
        handler_fn=_handle_command,
    )

    if is_paired():
        logger.info("StageWhisper is paired — auto-starting relay")
        import asyncio

        from .relay.service import relay_service

        try:
            loop = asyncio.get_event_loop()
            loop.create_task(relay_service.start())
        except RuntimeError:
            pass  # No event loop yet; relay starts on first tool call
