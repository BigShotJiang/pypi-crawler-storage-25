"""Deterministic orchestration engine executing a workflow graph of agents."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
import uuid

from bijux_canon_agent.contracts.agent_contract import (
    AgentErrorSchema,
    AgentInputSchema,
    AgentOutputSchema,
)
from bijux_canon_agent.traces import TraceEntry, TraceRecorder
from bijux_canon_agent.traces.trace import ModelMetadata

from .policy import FailurePolicy

AgentCallable = Callable[[AgentInputSchema], Awaitable[AgentOutputSchema]]


@dataclass
class WorkflowNode:
    """Represents a workflow graph node that executes an agent with retry metadata."""

    name: str
    runner: AgentCallable
    dependencies: list[str] = field(default_factory=list)
    max_retries: int = 2
    abort_on_failure: bool = True


@dataclass
class WorkflowRunState:
    """Tracks per-node outputs, errors, and retry counts for the workflow-graph run."""

    completed: dict[str, AgentOutputSchema] = field(default_factory=dict)
    errors: dict[str, AgentErrorSchema] = field(default_factory=dict)
    attempts: dict[str, int] = field(default_factory=dict)
    aborted: bool = False

    def record_success(self, name: str, output: AgentOutputSchema) -> None:
        self.completed[name] = output
        self.attempts[name] = self.attempts.get(name, 0) + 1

    def record_error(self, name: str, error: AgentErrorSchema) -> None:
        self.errors[name] = error
        self.attempts[name] = self.attempts.get(name, 0) + 1


@dataclass(frozen=True)
class _NodeContext:
    input_schema: AgentInputSchema
    payload: dict[str, Any]


class WorkflowOrchestrator:
    """Simple deterministic orchestrator that executes workflow graph nodes in order."""

    DEFAULT_TRACE_PATH = (
        Path("artifacts") / "bijux-canon-agent" / "workflow-graph" / "run_trace.json"
    )

    def __init__(
        self,
        nodes: Iterable[WorkflowNode],
        trace_path: Path | str = DEFAULT_TRACE_PATH,
        model_metadata: ModelMetadata | None = None,
        failure_policy: FailurePolicy | None = None,
    ) -> None:
        self.nodes = list(nodes)
        self.policy = failure_policy or FailurePolicy.load_default()
        self.trace_recorder = TraceRecorder(
            run_id=str(uuid.uuid4()), path=trace_path, model_metadata=model_metadata
        )

    async def run(self, initial_input: AgentInputSchema) -> WorkflowRunState:
        """Execute the workflow graph nodes in dependency order and record their outcomes."""
        state = WorkflowRunState()
        pending = list(self.nodes)
        context_payload = dict(initial_input.payload)

        while pending:
            executable = self._executable_nodes(pending, state)
            if not executable:
                break
            for node in executable:
                pending.remove(node)
                node_context = self._prepare_context(
                    node, initial_input, state, context_payload
                )
                await self._execute(node, node_context.input_schema, state)
                context_payload = node_context.payload
                if state.aborted:
                    pending.clear()
                    break
        self.trace_recorder.finish(status="aborted" if state.aborted else "completed")
        return state

    def _executable_nodes(
        self, pending: list[WorkflowNode], state: WorkflowRunState
    ) -> list[WorkflowNode]:
        return [node for node in pending if self._dependencies_met(node, state)]

    def _dependencies_met(self, node: WorkflowNode, state: WorkflowRunState) -> bool:
        return all(dep in state.completed for dep in node.dependencies)

    def _prepare_context(
        self,
        node: WorkflowNode,
        initial_input: AgentInputSchema,
        state: WorkflowRunState,
        payload: dict[str, Any],
    ) -> _NodeContext:
        enriched_payload = dict(payload)
        for dep in node.dependencies:
            if dep in state.completed:
                enriched_payload[f"{dep}_output"] = state.completed[dep].model_dump()
        reduced_payload = self._apply_scope_reduction(enriched_payload)
        return _NodeContext(
            input_schema=AgentInputSchema(
                task_goal=initial_input.task_goal,
                payload=reduced_payload,
                context_id=".".join([initial_input.context_id, node.name]),
                metadata={
                    **initial_input.metadata,
                    "node": node.name,
                },
            ),
            payload=reduced_payload,
        )

    def _apply_scope_reduction(self, payload: dict[str, Any]) -> dict[str, Any]:
        reduced = dict(payload)
        for step in self.policy.scope_reduction.steps:
            if step.startswith("drop:"):
                _, key = step.split(":", 1)
                reduced.pop(key, None)
            elif step == "clear_payload":
                reduced = {}
        return reduced

    async def _execute(
        self, node: WorkflowNode, context: AgentInputSchema, state: WorkflowRunState
    ) -> None:
        attempt = 0
        while attempt < node.max_retries:
            attempt += 1
            start_time = datetime.now(UTC)
            try:
                output = await node.runner(context)
            except Exception as exc:  # pragma: no cover
                error = self._error_schema(exc=exc, attempt=attempt, node=node)
                state.record_error(node.name, error)
                self._record_trace_entry(
                    node=node,
                    context=context,
                    trace_entry=self._failure_trace_entry(
                        node=node,
                        context=context,
                        error=error,
                        start_time=start_time,
                        stop_reason=getattr(exc, "stop_reason", None),
                    ),
                )
                if self._should_abort(node=node, error=error):
                    state.aborted = True
                    return
                if attempt >= node.max_retries:
                    break
                await asyncio.sleep(0)
                continue
            state.record_success(node.name, output)
            self._record_trace_entry(
                node=node,
                context=context,
                trace_entry=self._success_trace_entry(
                    node=node,
                    context=context,
                    output=output,
                    start_time=start_time,
                ),
            )
            return
        if not state.aborted and node.abort_on_failure:
            state.aborted = True

    def _success_trace_entry(
        self,
        *,
        node: WorkflowNode,
        context: AgentInputSchema,
        output: AgentOutputSchema,
        start_time: datetime,
    ) -> TraceEntry:
        metadata = output.metadata if isinstance(output, AgentOutputSchema) else {}
        prompt_hash_value = metadata.get(
            "prompt_hash", context.metadata.get("prompt_hash", "")
        )
        return TraceEntry(
            agent_id=node.name,
            node=node.name,
            status="success",
            start_time=start_time,
            end_time=datetime.now(UTC),
            input=context.model_dump(),
            output=output.model_dump(),
            scores=dict(output.scores),
            prompt_hash=prompt_hash_value,
            model_hash=context.metadata.get("model_hash", ""),
        )

    def _failure_trace_entry(
        self,
        *,
        node: WorkflowNode,
        context: AgentInputSchema,
        error: AgentErrorSchema,
        start_time: datetime,
        stop_reason: Any,
    ) -> TraceEntry:
        return TraceEntry(
            agent_id=node.name,
            node=node.name,
            status="failed",
            start_time=start_time,
            end_time=datetime.now(UTC),
            input=context.model_dump(),
            output=None,
            error=error.model_dump(),
            prompt_hash=context.metadata.get("prompt_hash", ""),
            model_hash=context.metadata.get("model_hash", ""),
            scores={},
            stop_reason=stop_reason,
        )

    def _record_trace_entry(
        self,
        *,
        node: WorkflowNode,
        context: AgentInputSchema,
        trace_entry: TraceEntry,
    ) -> None:
        del context
        prev_len = len(self.trace_recorder.trace.entries)
        self.trace_recorder.record_entry(trace_entry)
        if len(self.trace_recorder.trace.entries) == prev_len:
            raise RuntimeError(f"Trace entry missing for {node.name}")

    def _error_schema(
        self, *, exc: Exception, attempt: int, node: WorkflowNode
    ) -> AgentErrorSchema:
        return AgentErrorSchema(
            code=getattr(exc, "code", "EXEC_ERROR"),
            message=str(exc),
            details=getattr(exc, "details", None),
            transient=getattr(exc, "transient", attempt < node.max_retries),
        )

    def _should_abort(self, *, node: WorkflowNode, error: AgentErrorSchema) -> bool:
        return error.code in self.policy.abort.critical_codes or (
            not error.transient and node.abort_on_failure
        )
