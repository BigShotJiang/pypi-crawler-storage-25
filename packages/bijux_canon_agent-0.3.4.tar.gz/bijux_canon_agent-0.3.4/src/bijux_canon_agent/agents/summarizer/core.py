"""Enhanced text summarization agent for Bijux Agent."""

from __future__ import annotations

from collections.abc import Callable
import hashlib
import time
from typing import Any, cast

from bijux_canon_agent.agents.base import BaseAgent
from bijux_canon_agent.llm.llm_runtime import LLMUtils
from bijux_canon_agent.observability.logging import LoggerManager, MetricType

from .inputs import extract_keywords, extract_summarizer_text
from .reporting import (
    build_summarizer_coverage_report,
    build_summarizer_error_result,
    build_summarizer_result,
    build_summarizer_schema,
    get_summarizer_telemetry,
)
from .rules import postprocessing
from .strategy_execution import run_summary_strategy
from .types import (
    SummarizerErrorResult,
    SummarizerResult,
    SummarizerSummary,
    SummaryRunInputs,
)


class SummarizerAgent(BaseAgent):
    """Enhanced summarization agent for a multi-agent system.

    Supports chunking, section-aware summarization, multiple strategies (extractive,
    abstractive, hybrid), iterative revision based on feedback, and audit trails.
    Produces structured summaries with executive summary, key points, actionable
    insights, critical risks, and missing information.
    """

    STRATEGY_EXTRACTIVE = "extractive"
    STRATEGY_ABSTRACTIVE = "abstractive"
    STRATEGY_HYBRID = "hybrid"

    def __init__(
        self,
        config: dict[str, Any],
        logger_manager: LoggerManager,
        pre_hook: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
        post_hook: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]
        | None = None,
    ):
        """Initialize SummarizerAgent with config and logger manager.

        Args:
            config: Dict with settings like max_length, strategy, etc.
            logger_manager: LoggerManager instance for logging.
            pre_hook: Optional function called before summarization.
            post_hook: Optional function called after summarization.
        """
        super().__init__(config, logger_manager)
        self.pre_hook = pre_hook
        self.post_hook = post_hook

        # Load configuration settings
        self.max_length = self.config.get("max_length", 2048)
        self.max_tokens = self.config.get("max_tokens", 512)
        self.backend = self.config.get("backend", "simple")
        self.chunk_size = self.config.get("chunk_size", 1024)
        self.strategy = self.config.get("strategy", self.STRATEGY_HYBRID)
        self.strategy_weights = self.config.get(
            "strategy_weights",
            {self.STRATEGY_EXTRACTIVE: 0.6, self.STRATEGY_ABSTRACTIVE: 0.4},
        )
        self._cache: dict[str, SummarizerResult] | None = (
            {} if self.config.get("enable_cache", True) else None
        )
        self.max_retries = self.config.get("max_retries", 2)
        self.min_keyword_length = self.config.get("min_keyword_length", 3)
        self.top_keywords_count = self.config.get("top_keywords_count", 10)

        # Validate strategy and weights
        if self.strategy not in [
            self.STRATEGY_EXTRACTIVE,
            self.STRATEGY_ABSTRACTIVE,
            self.STRATEGY_HYBRID,
        ]:
            raise ValueError(f"Unsupported strategy: {self.strategy}")
        if self.strategy == self.STRATEGY_HYBRID:
            total_weight = sum(self.strategy_weights.values())
            if abs(total_weight - 1.0) > 0.01:
                raise ValueError(
                    f"Strategy weights must sum to 1 for hybrid strategy, "
                    f"got {total_weight}"
                )

        # Initialize LLM if needed
        self.llm = None
        if self.backend != "simple" and self.strategy in [
            self.STRATEGY_ABSTRACTIVE,
            self.STRATEGY_HYBRID,
        ]:
            self.llm = LLMUtils(self.config)

        self.logger.info(
            "SummarizerAgent initialized",
            extra={
                "context": {
                    "config": {
                        "max_length": self.max_length,
                        "max_tokens": self.max_tokens,
                        "backend": self.backend,
                        "chunk_size": self.chunk_size,
                        "strategy": self.strategy,
                        "strategy_weights": self.strategy_weights,
                        "enable_cache": bool(self._cache),
                        "has_llm": self.llm is not None,
                        "max_retries": self.max_retries,
                        "min_keyword_length": self.min_keyword_length,
                        "top_keywords_count": self.top_keywords_count,
                    }
                }
            },
        )

    def _initialize(self) -> None:
        """Initialize the agent by setting up any necessary resources."""

    def _cleanup(self) -> None:
        """Clean up resources used by the agent."""
        if self._cache is not None:
            self._cache.clear()
            self.logger.debug(
                "Cache cleared during cleanup",
                extra={"context": {"stage": "cleanup"}},
            )

    @property
    def capabilities(self) -> list[str]:
        """List of capabilities this agent supports."""
        return ["summarization"]

    async def _run_payload(
        self, context: dict[str, Any]
    ) -> SummarizerResult | SummarizerErrorResult:
        """Run the summarizer with chunking, section awareness, and error handling.

        Produces a structured summary in the format:
        - Executive Summary (1-2 sentences)
        - Key Points (bulleted)
        - Actionable Insights
        - Critical Risks/Caveats
        - Missing/Unclear Info

        Args:
            context: Input context with text to summarize under 'text' or nested.

        Returns:
            Dict with structured summary and metadata.
        """
        context_id = context.get(
            "context_id", str(hashlib.sha256(str(context).encode()).hexdigest())
        )
        with self.logger.context(agent="SummarizerAgent", context_id=context_id):
            self.logger.info(
                "Starting summarization operation",
                extra={"context": {"stage": "init", "context_id": context_id}},
            )

            # Preprocess context
            if self.pre_hook:
                try:
                    context = self.pre_hook(context)
                    self.logger.debug(
                        "Pre-hook applied successfully",
                        extra={"context": {"stage": "pre_hook"}},
                    )
                    self.logger_manager.log_metric(
                        "pre_hook_success",
                        1,
                        MetricType.COUNTER,
                        tags={"stage": "pre_hook"},
                    )
                except Exception as e:
                    self.logger.error(
                        f"Pre-hook failed: {e!s}",
                        extra={"context": {"stage": "pre_hook", "error": str(e)}},
                    )
                    self.logger_manager.log_metric(
                        "pre_hook_errors",
                        1,
                        MetricType.COUNTER,
                        tags={"stage": "pre_hook"},
                    )
                    return cast(
                        SummarizerErrorResult,
                        await self.execution_kernel.error_result(
                            f"Pre-hook failed: {e!s}", context, "pre_hook"
                        ),
                    )

            # Extract text and task goal
            text = self._extract_text(context)
            if not text:
                self.logger.error(
                    "No valid text provided for summarization",
                    extra={"context": {"stage": "input_validation"}},
                )
                self.logger_manager.log_metric(
                    "input_validation_errors",
                    1,
                    MetricType.COUNTER,
                    tags={"stage": "input_validation"},
                )
                return cast(
                    SummarizerErrorResult,
                    await self.execution_kernel.error_result(
                        "No valid text provided in context",
                        context,
                        "input_validation",
                    ),
                )

            run_inputs = self._build_run_inputs(context=context, text=text)
            cached_result = self._cached_result(run_inputs["cache_key"])
            if cached_result is not None:
                return cached_result

            # Summarize with retry mechanism
            start_time = time.perf_counter()
            summary_attempt = await self._summarize_with_retries(
                context=context,
                run_inputs=run_inputs,
            )
            if isinstance(summary_attempt, dict) and "error" in summary_attempt:
                return summary_attempt
            summary_text, method = summary_attempt
            duration = time.perf_counter() - start_time
            self.logger_manager.log_metric(
                "summarization_duration",
                duration,
                MetricType.HISTOGRAM,
                tags={"stage": "summarization"},
            )

            # Structure the summary
            structured_summary = cast(
                SummarizerSummary,
                postprocessing.format_structured_summary(
                    self,
                    summary_text,
                    run_inputs["text"],
                    run_inputs["keywords"],
                ),
            )

            result: SummarizerResult = cast(
                SummarizerResult,
                build_summarizer_result(
                    structured_summary=structured_summary,
                    method=method,
                    text=run_inputs["text"],
                    backend=self.backend,
                    strategy=self.strategy,
                    chunk_size=self.chunk_size,
                    duration=duration,
                ),
            )

            # Post-hook
            result = await self._apply_post_hook(context=context, result=result)

            # Cache the result
            self._store_cached_result(run_inputs["cache_key"], result)

            self.logger.info(
                "Summarization completed successfully",
                extra={
                    "context": {
                        "stage": "completion",
                        "output_keys": list(result.keys()),
                        "summary_length": sum(
                            len(str(v))
                            for v in result["summary"].values()
                            if isinstance(v, (str, list))
                        ),
                    }
                },
            )
            return cast(SummarizerResult, result)

    @staticmethod
    def _extract_text(context: dict[str, Any]) -> str:
        """Extract text from context, handling both direct and nested cases."""
        return extract_summarizer_text(context)

    def _extract_keywords(self, text: str, task_goal: str) -> list[str]:
        """Extract keywords dynamically from the task goal and text.

        Args:
            text: The input text to analyze.
            task_goal: The task goal string to guide keyword extraction.

        Returns:
            List of keywords relevant to the task.
        """
        return extract_keywords(
            text,
            task_goal,
            min_keyword_length=self.min_keyword_length,
            top_keywords_count=self.top_keywords_count,
            logger=self.logger,
        )

    def _build_run_inputs(
        self, *, context: dict[str, Any], text: str
    ) -> SummaryRunInputs:
        task_goal = context.get("task_goal", "summarize the text")
        keywords = self._extract_keywords(text, task_goal)
        prompt_prefix = self._prompt_prefix(context.get("feedback", ""))
        return {
            "text": text,
            "task_goal": task_goal,
            "keywords": keywords,
            "cache_key": hashlib.sha256((text + task_goal).encode()).hexdigest(),
            "prompt_prefix": prompt_prefix,
        }

    def _cached_result(self, cache_key: str) -> SummarizerResult | None:
        if self._cache is None or cache_key not in self._cache:
            return None
        self.logger.debug(
            "Returning cached summarization result",
            extra={"context": {"cache_key": cache_key}},
        )
        self.logger_manager.log_metric(
            "cache_hits", 1, MetricType.COUNTER, tags={"stage": "cache_check"}
        )
        return cast(SummarizerResult, self._cache[cache_key])

    def _prompt_prefix(self, feedback: Any) -> str:
        if not feedback:
            return ""
        prompt_prefix = (
            f"Previous summary had issues. {feedback}. Please revise accordingly:\n\n"
        )
        self.logger.info(
            "Applying revision instruction",
            extra={
                "context": {
                    "stage": "revision",
                    "retry_instruction": feedback,
                }
            },
        )
        return prompt_prefix

    async def _summarize_with_retries(
        self,
        *,
        context: dict[str, Any],
        run_inputs: SummaryRunInputs,
    ) -> tuple[str, str] | SummarizerErrorResult:
        for attempt in range(self.max_retries + 1):
            try:
                return await self._summarize(
                    run_inputs["text"],
                    run_inputs["prompt_prefix"],
                    run_inputs["task_goal"],
                    run_inputs["keywords"],
                )
            except Exception as e:
                error_result = await self._retryable_summary_error(
                    attempt=attempt,
                    context=context,
                    error=e,
                )
                if error_result is not None:
                    return error_result
        raise RuntimeError("Summarization retry loop exited without a result")

    async def _retryable_summary_error(
        self,
        *,
        attempt: int,
        context: dict[str, Any],
        error: Exception,
    ) -> SummarizerErrorResult | None:
        error_msg = (
            f"Summarization attempt {attempt + 1}/{self.max_retries + 1} "
            f"failed: {error!s}"
        )
        self.logger.error(
            error_msg,
            extra={"context": {"stage": "summarization", "error": str(error)}},
        )
        if attempt != self.max_retries:
            return None
        self.logger_manager.log_metric(
            "summarization_errors",
            1,
            MetricType.COUNTER,
            tags={"stage": "summarization"},
        )
        final_error = (
            f"Summarization failed after {self.max_retries + 1} attempts: {error!s}"
        )
        return cast(
            SummarizerErrorResult,
            await self.execution_kernel.error_result(
                final_error,
                context,
                "summarization",
            ),
        )

    async def _apply_post_hook(
        self,
        *,
        context: dict[str, Any],
        result: SummarizerResult,
    ) -> SummarizerResult:
        if self.post_hook is None:
            return result
        try:
            updated = cast(SummarizerResult, self.post_hook(context, result))
            self.logger.debug(
                "Post-hook applied successfully",
                extra={"context": {"stage": "post_hook"}},
            )
            self.logger_manager.log_metric(
                "post_hook_success",
                1,
                MetricType.COUNTER,
                tags={"stage": "post_hook"},
            )
            return updated
        except Exception as e:
            self.logger.warning(
                f"Post-hook failed: {e!s}",
                extra={"context": {"stage": "post_hook", "error": str(e)}},
            )
            self.logger_manager.log_metric(
                "post_hook_errors",
                1,
                MetricType.COUNTER,
                tags={"stage": "post_hook"},
            )
            result["warnings"].append(f"Post-hook failed: {e!s}")
            return result

    def _store_cached_result(self, cache_key: str, result: SummarizerResult) -> None:
        if self._cache is None:
            return
        self._cache[cache_key] = result
        self.logger_manager.log_metric(
            "cache_stores", 1, MetricType.COUNTER, tags={"stage": "cache_store"}
        )

    async def _summarize(
        self, text: str, prompt_prefix: str, task_goal: str, keywords: list[str]
    ) -> tuple[str, str]:
        """Summarize using the configured strategy with section awareness.

        Args:
            text: Text to summarize.
            prompt_prefix: Optional prompt prefix for revision.
            task_goal: Task goal to guide summarization focus.
            keywords: List of keywords to prioritize relevant content.

        Returns:
            Tuple of (summary text, method used).
        """
        return await run_summary_strategy(
            self,
            text=text,
            prompt_prefix=prompt_prefix,
            task_goal=task_goal,
            keywords=keywords,
        )

    def _revise_payload(
        self, feedback: dict[str, Any], context: dict[str, Any]
    ) -> dict[str, Any]:
        """Adjust summarization settings based on feedback."""
        self.logger.info(
            "Revising summary based on feedback",
            extra={"context": {"feedback": feedback}},
        )

        # Adjust summarization parameters based on feedback
        if isinstance(feedback, dict) and "message" in feedback:
            message = str(feedback["message"]).lower()
            if "too short" in message:
                self.max_length = int(self.max_length * 1.2)
            if "too long" in message:
                self.max_length = int(self.max_length * 0.8)
            if self.strategy == self.STRATEGY_HYBRID and (
                "missing" in message or "incomplete" in message
            ):
                self.strategy_weights[self.STRATEGY_ABSTRACTIVE] += 0.1
                self.strategy_weights[self.STRATEGY_EXTRACTIVE] -= 0.1
                total = sum(self.strategy_weights.values())
                for key in self.strategy_weights:
                    self.strategy_weights[key] /= total

        updated = dict(context)
        updated["feedback"] = feedback.get("message", "")
        return updated

    def error_payload(
        self,
        msg: str,
        context: dict[str, Any],
        stage: str,
        extra: dict[str, Any] | None = None,
    ) -> SummarizerErrorResult:
        """Build a standardized error payload for summarization."""
        _ = extra
        error_result = build_summarizer_error_result(
            msg,
            {**(context or {}), "stage": stage},
            input_length=len(self._extract_text(context)),
            backend=self.backend,
            strategy=self.strategy,
        )
        return cast(SummarizerErrorResult, error_result)

    @classmethod
    def self_report_schema(cls) -> dict[str, Any]:
        """Return the output schema for documentation and validation."""
        return build_summarizer_schema()

    @classmethod
    def coverage_report(cls, context: dict[str, Any] | None = None) -> dict[str, Any]:
        """Describe the parts of the context this agent consumes or modifies."""
        return build_summarizer_coverage_report()

    async def get_telemetry(self) -> dict[str, dict[str, Any]]:
        """Retrieve telemetry metrics."""
        return await get_summarizer_telemetry(
            logger=self.logger,
            logger_manager=self.logger_manager,
        )

    async def shutdown(self) -> None:
        """Shutdown the agent and flush logs."""
        self.logger.info(
            "Shutting down SummarizerAgent",
            extra={"context": {"stage": "shutdown"}},
        )
        self.logger_manager.flush()
        self.logger.info(
            "SummarizerAgent shutdown complete",
            extra={"context": {"stage": "shutdown"}},
        )
        await super().shutdown()
