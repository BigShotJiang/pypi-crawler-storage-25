# git-commit-msg-ai

AI-powered git commit message generator that follows the [Conventional Commits](https://www.conventionalcommits.org/) specification.

## Prerequisites

- Python 3.9+
- An Anthropic API key set as an environment variable:

  ```sh
  export ANTHROPIC_API_KEY=sk-ant-...   # macOS/Linux
  ```

  ```powershell
  [System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', 'sk-ant-...', 'User')   # Windows
  ```

## Installation

```sh
pip install git-commit-msg-ai
```

## Usage

Stage your changes, then run the tool from inside any git repository:

```sh
git add <files>
git-commit-msg-ai
```

The tool will:
1. Read your staged diff
2. Generate a commit message using Claude AI
3. Print the message and prompt you to choose:

```
[a]ccept / [e]dit / [r]eject:
```

- **a** — commits immediately with the generated message
- **e** — opens the message in your `$EDITOR`, lets you modify it, then commits
- **r** — exits without committing

## Commit message format

Generated messages follow the Conventional Commits specification:

```
<type>(<optional scope>): <short subject>

- Bullet explaining why this change was made
- Another reason if applicable
```

For breaking changes, the subject line gets a `!` and a footer is added:

```
feat(api)!: remove deprecated endpoint

- Endpoint was unused and blocking the new auth rollout

BREAKING CHANGE: /v1/legacy is no longer available
```

Supported types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`
