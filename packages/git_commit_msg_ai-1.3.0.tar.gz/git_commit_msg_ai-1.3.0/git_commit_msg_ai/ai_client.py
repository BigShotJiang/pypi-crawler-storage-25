import textwrap
from typing import Final, cast

import anthropic

from git_commit_msg_ai.exceptions import AIError

SYSTEM_PROMPT: Final[str] = textwrap.dedent("""\
    You are a Git commit message generator. Output only the commit message, nothing else. Follow the Conventional Commits specification:
    - First line: <type>(<optional scope>)<!>: <short subject> (50 chars max); append ! before the colon if the commit introduces a breaking change
    - Blank line
    - Bullet-point body explaining WHY the changes were made, not what
    - If there is a breaking change, add a blank line after the body followed by "BREAKING CHANGE: <description of what breaks and why>
    Types: feat, fix, docs, style, refactor, test, chore""")

MODEL: Final[str] = 'claude-haiku-4-5-20251001'
MAX_TOKENS: Final[int] = 1024


def generate_commit_message(diff: str) -> str:
    try:
        anthropic_client = anthropic.Anthropic()

        anthropic_api_response = anthropic_client.messages.create(
            model=MODEL,
            max_tokens=MAX_TOKENS,
            system=SYSTEM_PROMPT,
            messages=[{'role': 'user', 'content': diff}],
        )
    except anthropic.AuthenticationError:
        raise AIError('Anthropic API key is missing or invalid. Set the ANTHROPIC_API_KEY environment variable.')
    except anthropic.RateLimitError:
        raise AIError('Anthropic API rate limit reached. Wait a moment and try again.')
    except anthropic.APIConnectionError:
        raise AIError('Could not reach the Anthropic API. Check your network connection.')
    except anthropic.APIStatusError as error:
        raise AIError(f'Anthropic API returned an error: {error.status_code}.')

    anthropic_api_response_message = anthropic_api_response.content[0]
    commit_message = cast(anthropic.types.TextBlock, anthropic_api_response_message).text.strip()

    return commit_message
