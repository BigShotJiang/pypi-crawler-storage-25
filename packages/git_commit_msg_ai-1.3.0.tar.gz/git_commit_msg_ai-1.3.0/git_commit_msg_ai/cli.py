import sys

from git_commit_msg_ai import ai_client, editor, git_ops
from git_commit_msg_ai.exceptions import GitCommitAIError


def main() -> None:
    try:
        diff = git_ops.get_staged_diff()
        commit_message = ai_client.generate_commit_message(diff)
        print(commit_message)

        print()
        user_selection = input('[a]ccept / [e]dit / [r]eject: ').strip().lower()

        if user_selection == 'a':
            git_ops.commit(commit_message)
        elif user_selection == 'e':
            updated_commit_message = editor.open_in_editor(commit_message)
            git_ops.commit(updated_commit_message)
        elif user_selection == 'r':
            print('User rejected the generated commit message. No commit made.')
        else:
            print('Invalid selection.')
            sys.exit(1)
    except GitCommitAIError as error:
        print(str(error))
        sys.exit(1)
    except (KeyboardInterrupt, EOFError):
        print('Aborted.')
        sys.exit(1)


if __name__ == '__main__':  # pragma: no cover
    main()
