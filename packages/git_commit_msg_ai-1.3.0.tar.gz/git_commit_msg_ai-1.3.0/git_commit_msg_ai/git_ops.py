import subprocess

from git_commit_msg_ai.exceptions import GitError


def get_staged_diff() -> str:
    try:
        staged_diff = subprocess.check_output(['git', 'diff', '--cached']).decode()
    except FileNotFoundError:
        raise GitError('git is not installed or not on PATH.')
    except subprocess.CalledProcessError:
        raise GitError('Failed to get staged diff. Are you inside a git repository?')
    except UnicodeDecodeError:
        raise GitError('Staged diff contains bytes that could not be decoded as UTF-8.')

    if not staged_diff:
        raise GitError('No staged changes found. Stage files with git add before running.')

    return staged_diff


def commit(message: str) -> None:
    try:
        subprocess.run(['git', 'commit', '-m', message], check=True)
    except FileNotFoundError:
        raise GitError('git is not installed or not on PATH.')
    except subprocess.CalledProcessError:
        raise GitError('git commit failed.')
