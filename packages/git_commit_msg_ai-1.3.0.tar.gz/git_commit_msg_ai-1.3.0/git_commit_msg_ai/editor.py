import os
import subprocess
import tempfile

from git_commit_msg_ai.exceptions import EditorError


def open_in_editor(initial_text: str) -> str:
    try:
        with tempfile.NamedTemporaryFile(suffix='.txt', mode='w', delete=False) as temp_file:
            temp_file.write(initial_text)
            temp_file_path = temp_file.name
    except OSError:
        raise EditorError('Could not create a temporary file.')

    editor_command = os.environ.get('EDITOR', 'notepad')

    try:
        try:
            subprocess.run([editor_command, temp_file_path], check=True)
        except FileNotFoundError:
            raise EditorError(f'Editor "{editor_command}" was not found. Set the EDITOR environment variable to a valid editor.')
        except subprocess.CalledProcessError:
            raise EditorError(f'Editor "{editor_command}" exited with an error.')

        try:
            with open(temp_file_path) as temp_file:
                edited_text = temp_file.read().strip()
        except OSError:
            raise EditorError('Could not read the edited commit message from the temporary file.')
    finally:
        os.unlink(temp_file_path)

    return edited_text
