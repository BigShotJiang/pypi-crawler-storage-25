class GitCommitAIError(Exception):
    """Base exception for the application."""


class GitError(GitCommitAIError):
    """Raised when a git operation fails."""


class AIError(GitCommitAIError):
    """Raised when the Anthropic API call fails."""


class EditorError(GitCommitAIError):
    """Raised when opening or reading from the editor fails."""
