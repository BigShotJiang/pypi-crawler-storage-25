from git_commit_msg_ai.exceptions import AIError, EditorError, GitCommitAIError, GitError


def test_git_error_is_subclass_of_base():
    assert issubclass(GitError, GitCommitAIError)


def test_ai_error_is_subclass_of_base():
    assert issubclass(AIError, GitCommitAIError)


def test_editor_error_is_subclass_of_base():
    assert issubclass(EditorError, GitCommitAIError)


def test_git_error_carries_message():
    assert str(GitError('git failed')) == 'git failed'


def test_ai_error_carries_message():
    assert str(AIError('api failed')) == 'api failed'


def test_editor_error_carries_message():
    assert str(EditorError('editor failed')) == 'editor failed'
