import subprocess
from unittest.mock import MagicMock, patch

import pytest

from git_commit_msg_ai.exceptions import GitError
from git_commit_msg_ai.git_ops import commit, get_staged_diff


class TestGetStagedDiff:
    def test_returns_decoded_diff(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.check_output') as mock_check_output:
            mock_check_output.return_value = b'diff content'

            result = get_staged_diff()

        assert result == 'diff content'

    def test_raises_git_error_when_git_not_found(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.check_output') as mock_check_output:
            mock_check_output.side_effect = FileNotFoundError

            with pytest.raises(GitError, match='not installed'):
                get_staged_diff()

    def test_raises_git_error_on_called_process_error(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.check_output') as mock_check_output:
            mock_check_output.side_effect = subprocess.CalledProcessError(1, 'git')

            with pytest.raises(GitError, match='git repository'):
                get_staged_diff()

    def test_raises_git_error_on_unicode_decode_error(self):
        mock_bytes = MagicMock()
        mock_bytes.decode.side_effect = UnicodeDecodeError('utf-8', b'', 0, 1, 'reason')

        with patch('git_commit_msg_ai.git_ops.subprocess.check_output') as mock_check_output:
            mock_check_output.return_value = mock_bytes

            with pytest.raises(GitError, match='UTF-8'):
                get_staged_diff()

    def test_raises_git_error_when_diff_is_empty(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.check_output') as mock_check_output:
            mock_check_output.return_value = b''

            with pytest.raises(GitError, match='No staged changes'):
                get_staged_diff()


class TestCommit:
    def test_calls_subprocess_run_with_correct_args(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.run') as mock_run:
            commit('my message')

        mock_run.assert_called_once_with(['git', 'commit', '-m', 'my message'], check=True)

    def test_raises_git_error_when_git_not_found(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.run') as mock_run:
            mock_run.side_effect = FileNotFoundError

            with pytest.raises(GitError, match='not installed'):
                commit('my message')

    def test_raises_git_error_on_called_process_error(self):
        with patch('git_commit_msg_ai.git_ops.subprocess.run') as mock_run:
            mock_run.side_effect = subprocess.CalledProcessError(1, 'git')

            with pytest.raises(GitError, match='git commit failed'):
                commit('my message')
