import subprocess
from unittest.mock import MagicMock, patch

import pytest

from git_commit_msg_ai.editor import open_in_editor
from git_commit_msg_ai.exceptions import EditorError

TEMP_FILE_PATH = '/tmp/tmpfile.txt'


def _make_named_temporary_file_mock() -> MagicMock:
    mock_temp_file = MagicMock()
    mock_temp_file.name = TEMP_FILE_PATH
    mock_temp_file.__enter__ = MagicMock(return_value=mock_temp_file)
    mock_temp_file.__exit__ = MagicMock(return_value=False)

    return mock_temp_file


def _make_open_mock(text: str) -> MagicMock:
    mock_file = MagicMock()
    mock_file.read.return_value = text
    mock_file.__enter__ = MagicMock(return_value=mock_file)
    mock_file.__exit__ = MagicMock(return_value=False)

    return mock_file


class TestOpenInEditor:
    def test_returns_stripped_edited_text(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run'):
                with patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock('  edited text  ')):
                    with patch('git_commit_msg_ai.editor.os.unlink'):
                        result = open_in_editor('initial text')

        assert result == 'edited text'

    def test_uses_editor_env_var(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run') as mock_run:
                with patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock('text')):
                    with patch('git_commit_msg_ai.editor.os.unlink'):
                        with patch('git_commit_msg_ai.editor.os.environ.get', return_value='vim'):
                            open_in_editor('initial text')

        mock_run.assert_called_once_with(['vim', TEMP_FILE_PATH], check=True)

    def test_falls_back_to_notepad_when_editor_not_set(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run') as mock_run:
                with patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock('text')):
                    with patch('git_commit_msg_ai.editor.os.unlink'):
                        with patch('git_commit_msg_ai.editor.os.environ.get', return_value='notepad'):
                            open_in_editor('initial text')

        mock_run.assert_called_once_with(['notepad', TEMP_FILE_PATH], check=True)

    def test_raises_editor_error_on_temp_file_creation_failure(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', side_effect=OSError):
            with patch('git_commit_msg_ai.editor.os.unlink') as mock_unlink:
                with pytest.raises(EditorError, match='temporary file'):
                    open_in_editor('initial text')

        mock_unlink.assert_not_called()

    def test_raises_editor_error_when_editor_not_found(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run', side_effect=FileNotFoundError):
                with patch('git_commit_msg_ai.editor.os.unlink') as mock_unlink:
                    with patch('git_commit_msg_ai.editor.os.environ.get', return_value='vim'):
                        with pytest.raises(EditorError, match='was not found'):
                            open_in_editor('initial text')

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)

    def test_raises_editor_error_when_editor_exits_with_error(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run', side_effect=subprocess.CalledProcessError(1, 'vim')):
                with patch('git_commit_msg_ai.editor.os.unlink') as mock_unlink:
                    with patch('git_commit_msg_ai.editor.os.environ.get', return_value='vim'):
                        with pytest.raises(EditorError, match='exited with an error'):
                            open_in_editor('initial text')

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)

    def test_raises_editor_error_when_file_read_fails(self):
        with patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()):
            with patch('git_commit_msg_ai.editor.subprocess.run'):
                with patch('git_commit_msg_ai.editor.open', side_effect=OSError):
                    with patch('git_commit_msg_ai.editor.os.unlink') as mock_unlink:
                        with pytest.raises(EditorError, match='Could not read'):
                            open_in_editor('initial text')

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)
