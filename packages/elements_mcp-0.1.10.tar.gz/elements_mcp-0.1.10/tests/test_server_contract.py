import asyncio
import builtins
from pathlib import Path
import re
import sys
import warnings

import pytest

from elements_mcp.server import create_server
from elements_mcp.resources.registry import SkillRegistry


def project_name() -> str:
    pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
    match = re.search(r'(?m)^name\s*=\s*"([^"]+)"', pyproject)
    assert match is not None
    return match.group(1)


def _server_tools() -> dict[str, object]:
    async def list_tools() -> dict[str, object]:
        server = create_server()
        return {tool.name: tool for tool in await server.list_tools()}

    return asyncio.run(list_tools())


def test_create_server_returns_fastmcp_instance() -> None:
    server = create_server()

    assert server.name == "Elements MCP"


def test_create_server_does_not_emit_authlib_jose_deprecation_warning() -> None:
    for module_name in list(sys.modules):
        if module_name == "fastmcp" or module_name.startswith("fastmcp."):
            sys.modules.pop(module_name)

    with warnings.catch_warnings(record=True) as caught_warnings:
        warnings.simplefilter("always")

        server = create_server()

    assert server.name == "Elements MCP"
    assert not any(
        "authlib.jose module is deprecated" in str(caught_warning.message)
        for caught_warning in caught_warnings
    )


def test_create_server_missing_fastmcp_error_recommends_pip(monkeypatch: pytest.MonkeyPatch) -> None:
    original_import = builtins.__import__

    def import_without_fastmcp(name: str, *args: object, **kwargs: object) -> object:
        if name == "fastmcp":
            raise ImportError("No module named fastmcp")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", import_without_fastmcp)

    with pytest.raises(RuntimeError, match=rf"python -m pip install {re.escape(project_name())}"):
        create_server()


def test_server_registers_expected_tools() -> None:
    assert set(_server_tools()) == {
        "get_project_guidance",
        "list_project_skills",
        "read_project_skill",
        "search_project_skills",
        "list_skill_templates",
        "read_skill_template",
    }


def test_server_marks_all_tools_as_read_only_closed_world_operations() -> None:
    for tool in _server_tools().values():
        annotations = tool.annotations

        assert annotations is not None
        assert annotations.readOnlyHint is True
        assert annotations.destructiveHint is False
        assert annotations.idempotentHint is True
        assert annotations.openWorldHint is False


def test_skill_listing_tools_expose_structured_skill_entry_output_schema() -> None:
    tools = _server_tools()

    for tool_name in ("list_project_skills", "search_project_skills"):
        result_schema = tools[tool_name].output_schema["properties"]["result"]
        item_schema = result_schema["items"]

        assert result_schema["type"] == "array"
        assert item_schema["type"] == "object"
        assert item_schema["additionalProperties"] is False
        assert item_schema["required"] == ["name", "summary", "keywords", "templates", "uri"]
        assert set(item_schema["properties"]) == {"name", "summary", "keywords", "templates", "uri"}


def test_get_project_guidance_returns_matching_skill_without_implementation_templates(tmp_path) -> None:
    skill_dir = tmp_path / "ui-table-column-filter"
    templates_dir = skill_dir / "templates"
    templates_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\n"
        "description: Use for UITableColumnFilter table pages.\n"
        "---\n"
        "# UITableColumnFilter\n"
        "Use this skill for table column filter work.\n",
        encoding="utf-8",
    )
    (templates_dir / "standard-table.template.mdx").write_text(
        "# Standard Table Template\n",
        encoding="utf-8",
    )

    async def call_guidance() -> dict[str, object]:
        server = create_server(SkillRegistry(tmp_path))
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "帮我做 table column filter"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance["matched"] is True
    assert [skill["name"] for skill in guidance["skills"]] == ["ui-table-column-filter"]
    assert guidance["skills"][0]["keywords"] == []
    assert "Use this skill for table column filter work." in guidance["guidance"]
    assert "standard-table.template.mdx" not in guidance["guidance"]
    assert "Standard Table Template" not in guidance["guidance"]


def test_get_project_guidance_inlines_only_intake_template_for_gated_skill(tmp_path) -> None:
    skill_dir = tmp_path / "ui-table-column-filter"
    templates_dir = skill_dir / "templates"
    templates_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\n"
        "description: Use for UITableColumnFilter table pages.\n"
        "metadata:\n"
        "  keywords:\n"
        "    - table filter\n"
        "---\n"
        "# UITableColumnFilter\n"
        "## Hard Gates\n"
        "The request-input.template.yaml file is mandatory before implementation.\n",
        encoding="utf-8",
    )
    (templates_dir / "request-input.template.yaml").write_text(
        "table:\n  columns: []\n",
        encoding="utf-8",
    )
    (templates_dir / "standard-table.template.mdx").write_text(
        "# Standard Table Template\n",
        encoding="utf-8",
    )

    async def call_guidance() -> dict[str, object]:
        server = create_server(SkillRegistry(tmp_path))
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "create table filter page"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance["matched"] is True
    assert "request-input.template.yaml" in guidance["guidance"]
    assert "table:\n  columns: []" in guidance["guidance"]
    assert "standard-table.template.mdx" not in guidance["guidance"]
    assert "Standard Table Template" not in guidance["guidance"]


def test_get_project_guidance_matches_mixed_language_table_page_request() -> None:
    async def call_guidance() -> dict[str, object]:
        server = create_server()
        result = await server.call_tool(
            "get_project_guidance",
            {
                "task": "生成一个 table 带 filter sort search，然后是一个独立可访问的页面，右上角带一个 delete button。",
                "max_skills": 5,
            },
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    matched_skill_names = {skill["name"] for skill in guidance["skills"]}
    assert {
        "ui-table-column-filter",
        "page-structure",
        "ui-standard-layout",
        "naming-conventions",
    }.issubset(matched_skill_names)


def test_get_project_guidance_returns_clear_empty_result_when_no_skill_matches(tmp_path) -> None:
    skill_dir = tmp_path / "api-integration"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\n"
        "description: API service guidance.\n"
        "---\n"
        "# API Integration\n",
        encoding="utf-8",
    )

    async def call_guidance() -> dict[str, object]:
        server = create_server(SkillRegistry(tmp_path))
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "生成一个 lvform 页面"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance == {
        "matched": False,
        "query": "生成一个 lvform 页面",
        "skills": [],
        "guidance": (
            "No Elements project skill matched this task. Continue with normal coding behavior. "
            "Do not invent project-specific rules."
        ),
    }


def test_get_project_guidance_does_not_match_packaged_skill_on_body_only_term() -> None:
    async def call_guidance() -> dict[str, object]:
        server = create_server()
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "生成一个 nonexistentwidget 页面"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance["matched"] is False
    assert guidance["skills"] == []


def test_get_project_guidance_matches_packaged_keyword() -> None:
    async def call_guidance() -> dict[str, object]:
        server = create_server()
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "生成一个 LvForm 动态表单"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance["matched"] is True
    assert guidance["skills"][0]["name"] == "dynamic-field-renderer"


def test_get_project_guidance_filters_weak_packaged_matches() -> None:
    async def call_guidance() -> dict[str, object]:
        server = create_server()
        result = await server.call_tool(
            "get_project_guidance",
            {"task": "帮我做 table column filter"},
        )
        return result.structured_content["result"]

    guidance = asyncio.run(call_guidance())

    assert guidance["matched"] is True
    assert [skill["name"] for skill in guidance["skills"]] == [
        "ui-table-column-filter",
        "ui-table-column",
    ]


def test_server_registers_expected_resource_templates_with_metadata() -> None:
    async def list_templates() -> dict[str, object]:
        server = create_server()
        return {template.uri_template: template for template in await server.list_resource_templates()}

    templates = asyncio.run(list_templates())

    assert set(templates) == {
        "elements-skill://{skill_name}/SKILL.md",
        "elements-template://{skill_name}/{template_name}",
    }
    assert templates["elements-skill://{skill_name}/SKILL.md"].description
    assert templates["elements-template://{skill_name}/{template_name}"].description


def test_server_registers_expected_prompt_with_metadata() -> None:
    async def list_prompts() -> dict[str, object]:
        server = create_server()
        return {prompt.name: prompt for prompt in await server.list_prompts()}

    prompts = asyncio.run(list_prompts())

    assert set(prompts) == {"apply_project_skill", "check-i18n", "create-filter-table"}
    assert prompts["apply_project_skill"].description
    assert prompts["check-i18n"].description
    assert prompts["create-filter-table"].description


def test_server_renders_packaged_file_prompt_content() -> None:
    async def render_prompt() -> str:
        server = create_server()
        result = await server.render_prompt("check-i18n")
        return result.messages[0].content.text

    prompt = asyncio.run(render_prompt())

    assert "# /check-i18n" in prompt
    assert "get_project_guidance" in prompt


def test_check_i18n_prompt_accepts_target_path_and_autofix_arguments() -> None:
    async def render_prompt() -> str:
        server = create_server()
        result = await server.render_prompt(
            "check-i18n",
            {"target_path": "src/pages/customer-management", "autofix": "true"},
        )
        return result.messages[0].content.text

    prompt = asyncio.run(render_prompt())

    assert "src/pages/customer-management" in prompt
    assert "autofix requested: yes" in prompt
    assert "get_project_guidance" in prompt


def test_create_filter_table_prompt_accepts_initial_request_argument() -> None:
    async def render_prompt() -> str:
        server = create_server()
        result = await server.render_prompt(
            "create-filter-table",
            {"request": "Create a user audit table with status filters"},
        )
        return result.messages[0].content.text

    prompt = asyncio.run(render_prompt())

    assert "Create a user audit table with status filters" in prompt
    assert "UITableColumnFilter" in prompt
    assert "get_project_guidance" in prompt
