from pathlib import Path


def test_python_install_helper_installs_latest_package_to_fixed_directory() -> None:
    script = Path("scripts/install_elements_mcp.py").read_text(encoding="utf-8")

    assert "def get_install_dir() -> Path:" in script
    assert 'return Path(os.environ.get("SystemDrive", "C:") + r"\\Tools\\elements-mcp")' in script
    assert 'return Path.home() / "Tools" / "elements-mcp"' in script
    assert "install_dir = get_install_dir()" in script
    assert 'venv_dir = install_dir / ".venv"' in script
    assert 'return venv_dir / "Scripts" / "python.exe"' in script
    assert 'return venv_dir / "bin" / "python"' in script
    assert '"pip", "install", "--upgrade", "elements-mcp"' in script
    assert '"pip", "show", "elements-mcp"' in script
    assert "This installer does not accept arguments." in script
    assert "--install-dir" not in script
    assert "--package-name" not in script
    assert "--version" not in script

def test_user_guide_documents_pypi_install_options() -> None:
    guide = Path("docs/install-elements-mcp-user-guide-zh.md").read_text(encoding="utf-8")

    assert "python -m pip install --user --upgrade elements-mcp" in guide
    assert "Windows：`C:\\Tools\\elements-mcp`" in guide
    assert "macOS/Linux：`~/Tools/elements-mcp`" in guide
    assert "C:\\Tools\\elements-mcp\\.venv\\Scripts\\python.exe -m pip install --upgrade elements-mcp" in guide
    assert "~/Tools/elements-mcp/.venv/bin/python -m pip install --upgrade elements-mcp" in guide
    assert "python scripts\\install_elements_mcp.py" in guide
    assert "python scripts/install_elements_mcp.py" in guide
    assert "--install-dir" not in guide
    assert ".\\scripts\\install-elements-mcp.ps1" not in guide


def test_maintainer_guide_uses_project_venv_for_development_and_release() -> None:
    guide = Path("README.zh-CN.md").read_text(encoding="utf-8")

    assert "开发者只使用项目根目录的 `.venv`" in guide
    assert "python -m venv .venv" in guide
    assert '.\\.venv\\Scripts\\python.exe -m pip install -e ".[dev]"' in guide
    assert ".\\.venv\\Scripts\\python.exe -m pytest" in guide
    assert "scripts\\publish-pypi.ps1` 会调用 `.\\.venv\\Scripts\\python.exe`" in guide
    assert "python -m pip install --user --upgrade elements-mcp" not in guide


def test_english_readme_summarizes_install_and_release_paths() -> None:
    readme = Path("README.md").read_text(encoding="utf-8")

    assert "python -m pip install --user --upgrade elements-mcp" in readme
    assert "python scripts\\install_elements_mcp.py" in readme
    assert "Windows: `C:\\Tools\\elements-mcp`" in readme
    assert "macOS/Linux: `~/Tools/elements-mcp`" in readme
    assert "Maintainers should use the project-root `.venv`" in readme
    assert ".\\scripts\\publish-pypi.ps1" in readme
