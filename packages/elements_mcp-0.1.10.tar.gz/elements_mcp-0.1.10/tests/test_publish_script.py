from pathlib import Path
import shutil
import subprocess


def test_publish_script_builds_checked_distributions_before_upload() -> None:
    script = Path("scripts/publish-pypi.ps1").read_text(encoding="utf-8")

    required_steps = [
        "Remove-Item -LiteralPath $distDir -Recurse -Force",
        "& $python -m pytest",
        "& $python -m build",
        "& $python -m twine check",
        "& $python -m twine upload",
    ]

    positions = [script.index(step) for step in required_steps]

    assert positions == sorted(positions)


def test_update_package_metadata_script_syncs_name_and_version(tmp_path: Path) -> None:
    powershell = shutil.which("powershell") or shutil.which("pwsh")
    assert powershell is not None

    old_name = "sample-package"
    new_name = "renamed-package"
    old_version = "1.2.3"
    new_version = "4.5.6"
    old_wheel_name = old_name.replace("-", "_").replace(".", "_")
    new_wheel_name = new_name.replace("-", "_").replace(".", "_")

    project_root = tmp_path
    scripts_dir = project_root / "scripts"
    package_dir = project_root / "src" / "elements_mcp"
    docs_dir = project_root / "docs"
    tests_dir = project_root / "tests"
    scripts_dir.mkdir()
    package_dir.mkdir(parents=True)
    docs_dir.mkdir()
    tests_dir.mkdir()

    shutil.copyfile("scripts/update-package-metadata.ps1", scripts_dir / "update-package-metadata.ps1")
    (project_root / "pyproject.toml").write_text(
        f'[project]\nname = "{old_name}"\nversion = "{old_version}"\n'
        f'[project.scripts]\n{old_name} = "elements_mcp.server:main"\n',
        encoding="utf-8",
    )
    (project_root / "README.md").write_text(
        f"pip install {old_name}=={old_version}\n"
        f"https://pypi.org/project/{old_name}/\n"
        f"dist/{old_wheel_name}-{old_version}-py3-none-any.whl\n"
        "python -m elements_mcp.server\n",
        encoding="utf-8",
    )
    (docs_dir / "mcp-user-guide-zh.md").write_text(
        f"pip show {old_name}\npip install {old_name}=={old_version}\n",
        encoding="utf-8",
    )
    (package_dir / "__init__.py").write_text(
        f'__version__ = version("{old_name}")\n',
        encoding="utf-8",
    )
    (package_dir / "server.py").write_text(
        f'raise RuntimeError("Install with: python -m pip install {old_name}")\n',
        encoding="utf-8",
    )
    (tests_dir / "test_package_metadata.py").write_text(
        f'assert distribution_name == "{old_name}"\n',
        encoding="utf-8",
    )

    subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(scripts_dir / "update-package-metadata.ps1"),
            "-Name",
            new_name,
            "-Version",
            new_version,
        ],
        cwd=project_root,
        check=True,
        capture_output=True,
        text=True,
    )

    pyproject = (project_root / "pyproject.toml").read_text(encoding="utf-8")
    readme = (project_root / "README.md").read_text(encoding="utf-8")

    assert f'name = "{new_name}"' in pyproject
    assert f'version = "{new_version}"' in pyproject
    assert f'{new_name} = "elements_mcp.server:main"' in pyproject
    assert f'version("{new_name}")' in (package_dir / "__init__.py").read_text(encoding="utf-8")
    assert f"pip install {new_name}=={new_version}" in readme
    assert f"https://pypi.org/project/{new_name}/" in readme
    assert f"dist/{new_wheel_name}-{new_version}-py3-none-any.whl" in readme
    assert "python -m elements_mcp.server" in readme
    assert f"pip show {new_name}" in (docs_dir / "mcp-user-guide-zh.md").read_text(encoding="utf-8")
