from __future__ import annotations

from typing import Any

from .prompts import PromptRegistry, register_prompt_handlers
from .resources import SkillRegistry, register_resource_handlers
from .tools import register_tools


def create_server(registry: SkillRegistry | None = None, prompt_registry: PromptRegistry | None = None) -> Any:
    try:
        from fastmcp import FastMCP
    except ImportError as exc:  # pragma: no cover - exercised by runtime environment
        raise RuntimeError("FastMCP is required. Install with: python -m pip install elements-mcp") from exc

    active_registry = registry or SkillRegistry()
    active_prompt_registry = prompt_registry or PromptRegistry()
    mcp = FastMCP(
        "Elements MCP",
        instructions=(
            "Read-only MCP server for shared Elements engineering skills and templates. "
            "Use get_project_guidance with the user's task before coding to discover relevant guidance. "
            "If no guidance matches, continue with normal coding behavior."
        ),
    )

    register_tools(mcp, active_registry)
    register_resource_handlers(mcp, active_registry)
    register_prompt_handlers(mcp, active_registry, active_prompt_registry)

    return mcp


def main() -> None:
    create_server().run()


if __name__ == "__main__":
    main()
