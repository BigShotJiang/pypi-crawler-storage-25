# elements-mcp 工程说明

`elements-mcp` 是一个只读 MCP server，用来把 Elements 项目共用的工程规范、skills 和 templates 打包成 Python 包，供 Codex、GitHub Copilot 等 AI coding agent 读取。

本文面向维护者，说明工程结构、开发验证、发布流程和内容维护规则。使用者安装和客户端配置见 [docs/install-elements-mcp-user-guide-zh.md](docs/install-elements-mcp-user-guide-zh.md)。

## 目标和边界

目标：

- 将多个业务仓库共用的工程规范、领域知识、skills、prompts 和 templates 沉淀为可复用 MCP 内容。
- 通过 PyPI 分发 Python 包，让使用者默认安装最新版本，也允许在需要时固定版本。
- 通过 MCP tools、resources、prompts 暴露 skills/templates 和可复用提示词。
- 保持 server 只读，降低安全风险。

边界：

- 允许列出、搜索、读取包内 skills/templates。
- 不允许写文件、删文件、执行 shell、安装依赖、读取包外路径。
- 后续如果要加入写入型或执行型 tools，需要单独做安全设计。

## 目录结构

```text
elements-mcp/
  README.md
  README.zh-CN.md
  MANIFEST.in
  pyproject.toml
  docs/
    install-elements-mcp-user-guide-zh.md
  scripts/
    install_elements_mcp.py
    publish-pypi.ps1
    pypi-publish.env.example.ps1
    update-package-metadata.ps1
  src/
    elements_mcp/
      __init__.py
      server.py
      tools/
      resources/
        registry.py
        handlers.py
        content/
          skills/
            ui-standard-layout/
            api-integration/
      prompts/
        registry.py
        handlers.py
        content/
  tests/
```

## 关键文件职责

- `pyproject.toml`：Python 包配置，包含包名、版本、依赖、入口命令、package data 和 pytest 配置。
- `MANIFEST.in`：source distribution 内容规则，保留 runtime content，排除 `docs/`。
- `src/elements_mcp/tools/`：MCP Tools 的注册和实现。
- `src/elements_mcp/resources/`：MCP Resources 的注册、skills/templates 索引和包内 resource content。
- `src/elements_mcp/prompts/`：MCP Prompts 的注册、prompt 索引和包内 prompt content。
- `src/elements_mcp/server.py`：FastMCP server 组装层，负责汇总注册 tools、resources、prompts。
- `tests/`：开发和发布前验证，不属于用户运行时依赖。
- `docs/install-elements-mcp-user-guide-zh.md`：使用者安装和客户端接入说明。
- `scripts/install_elements_mcp.py`：跨平台隔离安装辅助脚本，默认安装到固定的 `Tools\elements-mcp` 专用目录，并从 PyPI 安装最新版 `elements-mcp`。
- `scripts/publish-pypi.ps1`：发布脚本，固定使用项目根目录 `.venv` 运行测试、构建、校验和上传。
- `scripts/pypi-publish.env.example.ps1`：PyPI token 本地配置模板。
- `scripts/update-package-metadata.ps1`：维护脚本，用于同步包名和版本号相关文本。

## MCP 契约

Tools:

```text
get_project_guidance(task, max_skills=3)
list_project_skills()
read_project_skill(skill_name)
search_project_skills(query)
list_skill_templates(skill_name)
read_skill_template(skill_name, template_name)
```

Resources:

```text
elements-skill://{skill_name}/SKILL.md
elements-template://{skill_name}/{template_name}
```

Prompts:

```text
apply_project_skill(skill_name, task)
check-i18n
create-filter-table
```

所有 tools 都应标记为只读、非破坏、幂等、closed-world。

推荐让当前工程、IDE 插件或其他 AI host 在用户发起编码请求后，自动先调用 `get_project_guidance(userMessage)`。使用者不需要在输入框里手写 tool 名称。

当返回 `matched=true` 时，调用方把 `guidance` 注入给 AI；当返回 `matched=false` 时，继续正常编码流程，不阻塞用户请求，也不要编造不存在的项目规范。

## 内容维护

新增 skill：

```text
src/elements_mcp/resources/content/skills/
```

新增 skill：

```text
src/elements_mcp/resources/content/skills/<skill-name>/
  SKILL.md
  templates/
    example.template.mdx
```

新增 prompt：

```text
src/elements_mcp/prompts/content/<prompt-name>.prompt.md
```

规则：

- `SKILL.md` 必须存在。
- `templates/` 可选。
- skill、template 文件名使用字母、数字、点、下划线、连字符。
- 不使用空格、中文文件名、路径分隔符或特殊符号。
- 大段可复用示例放到 `templates/*.template.mdx`，不要把单个 `SKILL.md` 写得过长。

## 本地开发

开发者只使用项目根目录的 `.venv` 作为开发、测试和发布环境。不要把开发依赖安装到全局 Python 或 user site-packages。

```powershell
cd C:\Code\elements-mcp
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
```

运行测试：

```powershell
.\.venv\Scripts\python.exe -m pytest
```

运行 server：

```powershell
.\.venv\Scripts\python.exe -m elements_mcp.server
```

验证 registry：

```powershell
.\.venv\Scripts\python.exe -c "from elements_mcp.resources.registry import SkillRegistry; print([skill.name for skill in SkillRegistry().list_skills()])"
```

验证 server：

```powershell
.\.venv\Scripts\python.exe -c "from elements_mcp.server import create_server; print(create_server().name)"
```

## 构建和发布

如果修改了代码或包内 content，发布新包前先更新版本号，并重新构建干净的分发产物。

发布流程同样只使用项目根目录 `.venv`。`scripts\publish-pypi.ps1` 会调用 `.\.venv\Scripts\python.exe`，因此发布前必须先完成本地开发环境初始化，并把构建工具安装到这个 `.venv` 中：

```powershell
.\.venv\Scripts\python.exe -m pip install -U build twine
```

常规发布直接运行一键脚本即可。脚本会自动清理 `dist/`、运行测试、构建分发产物、执行 `twine check`，然后上传：

```powershell
.\scripts\publish-pypi.ps1
```

发布到非默认仓库：

```powershell
.\scripts\publish-pypi.ps1 -Repository <repository-name>
```

预期产物：

```text
dist/elements_mcp-<version>.tar.gz
dist/elements_mcp-<version>-py3-none-any.whl
```

如果需要排查构建或发布问题，可以把脚本中的主要步骤拆开手动执行：

```powershell
Remove-Item -LiteralPath dist -Recurse -Force -ErrorAction SilentlyContinue
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m build
.\.venv\Scripts\python.exe -m twine check dist/*
```

发布新版本时：

1. 修改 `pyproject.toml` 的 `version`。
2. 如有需要，运行 `.\scripts\update-package-metadata.ps1 -Version <version> -WhatIf` 预览版本文本更新，再去掉 `-WhatIf` 执行。
3. 确认 `scripts/pypi-publish.env.ps1` 已配置 PyPI token，其中 `TWINE_USERNAME` 保持为 `__token__`。
4. 运行 `.\scripts\publish-pypi.ps1`，脚本会自动清理旧的 `dist/`、运行测试、构建、`twine check` 并上传到 PyPI。
5. 如果脚本中途失败，先修复失败原因，再重新执行同一条命令。
6. 到 https://pypi.org/project/elements-mcp/ 确认新版本已出现。
7. 在干净虚拟环境中安装验证：

```powershell
python -m venv C:\Temp\elements-mcp-publish-check
C:\Temp\elements-mcp-publish-check\Scripts\python.exe -m pip install elements-mcp==<version>
C:\Temp\elements-mcp-publish-check\Scripts\python.exe -c "from elements_mcp.server import create_server; print(create_server().name)"
```

8. 通知使用者重新执行用户指南中的 PyPI 更新命令。默认升级到最新版本；如需回滚或灰度验证，再临时使用 `elements-mcp==<version>`。

`src/elements_mcp/__init__.py` 的 `__version__` 从安装后的包元数据读取，不需要重复手工维护版本号。

## 文档分工

- `README.md`：英文主入口，面向需要快速了解项目定位和文档入口的读者。
- `README.zh-CN.md`：中文维护者指南，也就是本文，面向负责工程维护、构建和发布的人。
- `docs/install-elements-mcp-user-guide-zh.md`：中文使用者指南，面向需要安装 `elements-mcp`、配置 MCP 客户端和排查连接问题的人。
