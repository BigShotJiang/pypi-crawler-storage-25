"""Tests for slowai.hardware — Jetson SKU detection and DLA gating.

V9 P0: These tests verify that:
1. SKU matching works correctly for all known Jetson models
2. DLA gating raises clear errors on hardware without DLA
3. Detection gracefully handles non-Jetson systems
4. The capability matrix is complete and correct
"""

import pytest
from unittest.mock import patch, MagicMock

from slowai.hardware import (
    JetsonInfo,
    JetsonSKU,
    DLANotAvailableError,
    detect_jetson,
    require_dla,
    format_hardware_report,
    _match_sku,
)


# ---------------------------------------------------------------------------
# SKU matching tests
# ---------------------------------------------------------------------------

class TestSKUMatching:
    """Test that model strings map to the correct SKU."""

    def test_orin_nano_super(self):
        sku = _match_sku("nvidia orin nano super developer kit")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano Super"
        assert sku.dla_cores == 0
        assert sku.series == "orin_nano"

    def test_orin_nano_8gb(self):
        sku = _match_sku("nvidia jetson orin nano 8gb")
        assert sku is not None
        assert sku.dla_cores == 0
        assert sku.series == "orin_nano"

    def test_orin_nano_4gb(self):
        sku = _match_sku("nvidia jetson orin nano 4gb module")
        assert sku is not None
        assert sku.dla_cores == 0
        assert sku.gpu_cores == 512

    def test_orin_nano_generic(self):
        """Unknown Orin Nano variant still gets zero DLA."""
        sku = _match_sku("jetson orin nano something new")
        assert sku is not None
        assert sku.dla_cores == 0

    def test_orin_nx_16gb(self):
        sku = _match_sku("nvidia jetson orin nx 16gb")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "orin_nx"

    def test_orin_nx_8gb(self):
        sku = _match_sku("nvidia jetson orin nx 8gb")
        assert sku is not None
        assert sku.dla_cores == 1  # NX 8GB has only 1 DLA core

    def test_orin_nx_super(self):
        sku = _match_sku("nvidia jetson orin nx super")
        assert sku is not None
        assert sku.dla_cores == 2

    def test_agx_orin_64gb(self):
        sku = _match_sku("nvidia jetson agx orin 64gb developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.unified_memory_gb == 64.0

    def test_agx_orin_32gb(self):
        sku = _match_sku("nvidia jetson agx orin developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "agx_orin"

    def test_agx_xavier(self):
        sku = _match_sku("nvidia jetson agx xavier developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "agx_xavier"

    def test_xavier_nx(self):
        sku = _match_sku("nvidia xavier nx developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "xavier_nx"

    def test_unknown_model_returns_none(self):
        sku = _match_sku("some random desktop computer")
        assert sku is None

    def test_thor(self):
        sku = _match_sku("nvidia jetson thor")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "thor"

    def test_specificity_ordering(self):
        """Orin Nano Super matches before generic Orin Nano."""
        super_sku = _match_sku("orin nano super")
        generic_sku = _match_sku("orin nano developer kit")
        assert super_sku is not None
        assert generic_sku is not None
        assert super_sku.name == "Jetson Orin Nano Super"
        assert super_sku.max_power_watts == 25
        assert generic_sku.max_power_watts == 15  # generic is lower power


# ---------------------------------------------------------------------------
# DLA gating tests — the critical safety gate
# ---------------------------------------------------------------------------

class TestDLAGating:
    """Test that require_dla raises on hardware without DLA."""

    def test_require_dla_on_non_jetson_raises(self):
        hw = JetsonInfo(is_jetson=False)
        with pytest.raises(DLANotAvailableError, match="not a Jetson"):
            require_dla(hw)

    def test_require_dla_on_orin_nano_raises(self):
        """THE critical test — Grok's bug. Orin Nano has no DLA."""
        nano_sku = _match_sku("orin nano super")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Orin Nano Super Developer Kit",
            sku=nano_sku,
        )
        with pytest.raises(DLANotAvailableError, match="not available"):
            require_dla(hw)

    def test_require_dla_on_orin_nano_error_message_is_helpful(self):
        """Error message must name the hardware and suggest alternatives."""
        nano_sku = _match_sku("orin nano super")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Orin Nano Super Developer Kit",
            sku=nano_sku,
        )
        with pytest.raises(DLANotAvailableError) as exc_info:
            require_dla(hw)

        msg = str(exc_info.value)
        assert "Orin Nano" in msg
        assert "DLA cores: 0" in msg
        assert "Orin NX" in msg          # suggests hardware that has DLA
        assert "--precision=fp16" in msg  # suggests GPU-only alternative

    def test_require_dla_on_agx_orin_passes(self):
        """AGX Orin has 2 DLA cores — should not raise."""
        agx_sku = _match_sku("agx orin 32gb")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Jetson AGX Orin Developer Kit",
            sku=agx_sku,
        )
        # Should not raise
        require_dla(hw, dla_core=0)
        require_dla(hw, dla_core=1)

    def test_require_dla_invalid_core_index(self):
        """Requesting core 1 on NX 8GB (1 core) should fail."""
        nx8_sku = _match_sku("orin nx 8gb")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Jetson Orin NX 8GB",
            sku=nx8_sku,
        )
        # Core 0 should work (has 1 DLA core)
        require_dla(hw, dla_core=0)

        # Core 1 should fail
        with pytest.raises(DLANotAvailableError, match="does not exist"):
            require_dla(hw, dla_core=1)

    def test_require_dla_on_unknown_jetson(self):
        """Unknown Jetson with no SKU match should raise (no DLA assumed)."""
        hw = JetsonInfo(
            is_jetson=True,
            model_string="Some Unknown Jetson Board",
            sku=None,
        )
        with pytest.raises(DLANotAvailableError):
            require_dla(hw)


# ---------------------------------------------------------------------------
# JetsonInfo tests
# ---------------------------------------------------------------------------

class TestJetsonInfo:
    """Test the JetsonInfo dataclass and its properties."""

    def test_non_jetson_defaults(self):
        hw = JetsonInfo()
        assert not hw.is_jetson
        assert not hw.has_dla
        assert hw.dla_cores == 0
        assert hw.sku_name == "Not a Jetson"
        assert hw.series == "unknown"

    def test_jetson_with_sku(self):
        sku = _match_sku("orin nano super")
        hw = JetsonInfo(is_jetson=True, model_string="test", sku=sku)
        assert hw.is_jetson
        assert not hw.has_dla
        assert hw.dla_cores == 0
        assert hw.max_power_watts == 25
        assert hw.gpu_cores == 1024

    def test_jetson_without_sku(self):
        hw = JetsonInfo(is_jetson=True, model_string="Mystery Board")
        assert hw.is_jetson
        assert "Unknown Jetson" in hw.sku_name
        assert "Mystery Board" in hw.sku_name

    def test_capability_matrix_non_jetson(self):
        hw = JetsonInfo()
        matrix = hw.capability_matrix()
        assert matrix["is_jetson"] is False
        assert matrix["has_dla"] is False
        assert matrix["dla_cores"] == 0

    def test_capability_matrix_jetson(self):
        sku = _match_sku("agx orin 64gb")
        hw = JetsonInfo(is_jetson=True, model_string="test", sku=sku)
        matrix = hw.capability_matrix()
        assert matrix["is_jetson"] is True
        assert matrix["has_dla"] is True
        assert matrix["dla_cores"] == 2
        assert matrix["unified_memory_gb"] == 64.0
        assert matrix["gpu_cores"] == 2048
        assert matrix["series"] == "agx_orin"


# ---------------------------------------------------------------------------
# Detection tests (mocked filesystem)
# ---------------------------------------------------------------------------

class TestDetectJetson:
    """Test detect_jetson() with mocked filesystem reads."""

    @patch("slowai.hardware._read_device_tree_model")
    def test_detects_orin_nano_super(self, mock_model):
        mock_model.return_value = "NVIDIA Orin Nano Super Developer Kit"
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.sku is not None
        assert hw.sku.name == "Jetson Orin Nano Super"
        assert hw.dla_cores == 0

    @patch("slowai.hardware._read_device_tree_model")
    def test_detects_agx_orin(self, mock_model):
        mock_model.return_value = "NVIDIA Jetson AGX Orin Developer Kit"
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.has_dla
        assert hw.dla_cores == 2

    @patch("slowai.hardware._check_nvpmodel", return_value=False)
    @patch("slowai.hardware._check_tegra_release", return_value=False)
    @patch("slowai.hardware._read_device_tree_compatible", return_value=None)
    @patch("slowai.hardware._read_device_tree_model", return_value=None)
    def test_non_jetson_returns_false(self, *mocks):
        hw = detect_jetson()
        assert not hw.is_jetson
        assert hw.sku is None

    @patch("slowai.hardware._read_device_tree_model", return_value=None)
    @patch("slowai.hardware._read_device_tree_compatible")
    def test_falls_back_to_compatible(self, mock_compat, mock_model):
        mock_compat.return_value = "nvidia,p3768-0000+p3767-0005 nvidia,tegra234"
        hw = detect_jetson()
        assert hw.is_jetson

    @patch("slowai.hardware._read_device_tree_model", return_value=None)
    @patch("slowai.hardware._read_device_tree_compatible", return_value=None)
    @patch("slowai.hardware._check_tegra_release", return_value=True)
    def test_falls_back_to_tegra_release(self, *mocks):
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.sku is None  # can't determine SKU from tegra_release alone


# ---------------------------------------------------------------------------
# Display formatting
# ---------------------------------------------------------------------------

class TestFormatReport:
    """Test the human-readable hardware report."""

    def test_non_jetson_report(self):
        hw = JetsonInfo()
        report = format_hardware_report(hw)
        assert "Desktop / Server" in report
        assert "not a Jetson" in report

    def test_orin_nano_report_warns_no_dla(self):
        sku = _match_sku("orin nano super")
        hw = JetsonInfo(is_jetson=True, model_string="NVIDIA Orin Nano Super", sku=sku)
        report = format_hardware_report(hw)
        assert "DLA cores:       0" in report
        assert "ERROR" in report

    def test_agx_orin_report_shows_dla(self):
        sku = _match_sku("agx orin 32gb")
        hw = JetsonInfo(is_jetson=True, model_string="NVIDIA AGX Orin", sku=sku)
        report = format_hardware_report(hw)
        assert "DLA cores:       2" in report
        assert "SUPPORTED" in report
