"""
slowai.optimize — production TensorRT engine export pipeline.

V7 feature: the thing Grok said is 80% of acquisition readiness.
V8 additions: DLA offloading, INT8 calibration cache generation.
V9 fix: Hardware-aware DLA gating — errors clearly on SKUs without DLA (e.g. Orin Nano).

Instead of just tweaking PyTorch flags in-memory, this module exports
a production-grade TensorRT engine file that ships to the fleet.

Strategy: PyTorch → ONNX → trtexec → .engine
    - Bypasses the broken torch_tensorrt bridge on Jetson
    - Uses trtexec (ships with JetPack, rock-solid)
    - Supports FP32, FP16, INT8 (with calibration)
    - V8: DLA offloading (--dla flag routes layers to Orin's DLA cores)
    - Auto-detects JetPack/CUDA/TensorRT versions
    - Outputs .engine + metadata JSON

Usage:
    slowai optimize model.py --target=trt
    slowai optimize model.py --target=trt --precision=fp16
    slowai optimize model.py --target=trt --precision=int8 --calib=data/
    slowai optimize model.py --target=trt --dla           # V8: DLA offloading
    slowai optimize model.py --target=onnx  # just export ONNX
"""

from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class OptimizeResult:
    """Result of an optimization pipeline run."""
    workload: str
    target: str             # "onnx" | "trt"
    precision: str          # "fp32" | "fp16" | "int8"
    success: bool
    onnx_path: str | None = None
    engine_path: str | None = None
    metadata_path: str | None = None

    # Metrics
    onnx_size_mb: float = 0.0
    engine_size_mb: float = 0.0
    export_time_s: float = 0.0
    build_time_s: float = 0.0

    # V8: DLA offloading
    dla_enabled: bool = False
    dla_core: int = 0

    # Environment
    jetpack_version: str | None = None
    cuda_version: str | None = None
    tensorrt_version: str | None = None
    gpu_name: str | None = None

    error: str | None = None
    warnings: list[str] = field(default_factory=list)


def detect_environment() -> dict:
    """Auto-detect JetPack, CUDA, TensorRT, and GPU info."""
    env = {
        "jetpack_version": None,
        "cuda_version": None,
        "tensorrt_version": None,
        "trtexec_path": None,
        "gpu_name": None,
        "is_jetson": False,
    }

    # CUDA version
    try:
        import torch
        if torch.cuda.is_available():
            env["cuda_version"] = torch.version.cuda
            env["gpu_name"] = torch.cuda.get_device_name(0)
    except Exception:
        pass

    # TensorRT version
    try:
        import tensorrt
        env["tensorrt_version"] = tensorrt.__version__
    except ImportError:
        pass

    # trtexec location
    trtexec = shutil.which("trtexec")
    if trtexec:
        env["trtexec_path"] = trtexec
    else:
        # Common Jetson paths
        for candidate in [
            "/usr/src/tensorrt/bin/trtexec",
            "/usr/local/tensorrt/bin/trtexec",
            os.path.expanduser("~/tensorrt/bin/trtexec"),
        ]:
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                env["trtexec_path"] = candidate
                break

    # JetPack version (Jetson-specific)
    try:
        result = subprocess.run(
            ["cat", "/etc/nv_tegra_release"],
            capture_output=True, text=True, timeout=2,
        )
        if result.returncode == 0:
            env["is_jetson"] = True
            # Parse: # R36 (release), REVISION: 4.3, ...
            line = result.stdout.strip()
            if "R36" in line:
                env["jetpack_version"] = "6.x"
            elif "R35" in line:
                env["jetpack_version"] = "5.x"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Alternative Jetson detection
    if not env["is_jetson"]:
        try:
            result = subprocess.run(
                ["nvpmodel", "-q"], capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                env["is_jetson"] = True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    return env


def export_onnx(
    workload_path: str,
    output_path: str | None = None,
    opset: int = 17,
    dynamic_axes: dict | None = None,
) -> tuple[str, float]:
    """Export a workload's model to ONNX format.

    Looks for a `model` and `sample_input` in the workload module.
    If not found, tries to trace main() for model extraction.

    Returns (onnx_path, export_time_seconds).
    """
    import torch

    p = Path(workload_path).resolve()
    spec = importlib.util.spec_from_file_location(f"_opt_{p.stem}", p)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    # Look for model and sample_input
    model = getattr(module, "model", None)
    sample_input = getattr(module, "sample_input", None)
    input_names = getattr(module, "input_names", ["input"])
    output_names = getattr(module, "output_names", ["output"])

    if model is None:
        raise RuntimeError(
            f"Workload {workload_path} must define a `model` attribute "
            f"(nn.Module) for ONNX export. Example:\n"
            f"  model = resnet50().cuda().eval()\n"
            f"  sample_input = torch.randn(1, 3, 224, 224, device='cuda')"
        )

    if sample_input is None:
        # Try to infer from data attribute
        sample_input = getattr(module, "data", None)
        if sample_input is None:
            raise RuntimeError(
                f"Workload {workload_path} must define `sample_input` "
                f"(a tensor or tuple of tensors) for ONNX export."
            )

    if output_path is None:
        output_path = str(p.with_suffix(".onnx"))

    model.eval()

    t0 = time.perf_counter()
    with torch.no_grad():
        torch.onnx.export(
            model,
            sample_input if isinstance(sample_input, tuple) else (sample_input,),
            output_path,
            opset_version=opset,
            input_names=input_names if isinstance(input_names, list) else [input_names],
            output_names=output_names if isinstance(output_names, list) else [output_names],
            dynamic_axes=dynamic_axes,
            do_constant_folding=True,
        )
    export_time = time.perf_counter() - t0

    return output_path, export_time


def build_tensorrt_engine(
    onnx_path: str,
    output_path: str | None = None,
    precision: str = "fp16",
    workspace_mb: int = 1024,
    trtexec_path: str | None = None,
    calib_cache: str | None = None,
    use_dla: bool = False,
    dla_core: int = 0,
) -> tuple[str, float]:
    """Build a TensorRT engine from an ONNX file using trtexec.

    This is the production path — bypasses torch_tensorrt entirely
    and uses NVIDIA's official trtexec binary that ships with JetPack.

    Args:
        onnx_path: Path to ONNX model.
        output_path: Where to save .engine file.
        precision: "fp32", "fp16", or "int8".
        workspace_mb: Max workspace size in MB.
        trtexec_path: Path to trtexec binary (auto-detected if None).
        calib_cache: Path to INT8 calibration cache (for int8 precision).
        use_dla: V8 — offload compatible layers to DLA cores.
        dla_core: Which DLA core to use (0 or 1 on Orin).

    Returns:
        (engine_path, build_time_seconds).
    """
    if trtexec_path is None:
        trtexec_path = shutil.which("trtexec")
        if trtexec_path is None:
            # Try common Jetson paths
            for candidate in [
                "/usr/src/tensorrt/bin/trtexec",
                "/usr/local/tensorrt/bin/trtexec",
            ]:
                if os.path.isfile(candidate):
                    trtexec_path = candidate
                    break

    if trtexec_path is None:
        raise RuntimeError(
            "trtexec not found. On Jetson: it should be at /usr/src/tensorrt/bin/trtexec. "
            "On desktop: install TensorRT and add trtexec to PATH."
        )

    if output_path is None:
        base = os.path.splitext(onnx_path)[0]
        output_path = f"{base}_{precision}.engine"

    cmd = [
        trtexec_path,
        f"--onnx={onnx_path}",
        f"--saveEngine={output_path}",
        f"--workspace={workspace_mb}",
    ]

    if precision == "fp16":
        cmd.append("--fp16")
    elif precision == "int8":
        cmd.append("--int8")
        if calib_cache:
            cmd.append(f"--calib={calib_cache}")
    # fp32 = default, no flag needed

    # V8: DLA offloading — route compatible layers to Orin's DLA cores
    if use_dla:
        cmd.append(f"--useDLACore={dla_core}")
        cmd.append("--allowGPUFallback")  # layers DLA can't run fall back to GPU

    # Add best mode for optimal kernel selection
    cmd.append("--best")

    t0 = time.perf_counter()
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=600,  # 10 min max for engine build
    )
    build_time = time.perf_counter() - t0

    if result.returncode != 0:
        raise RuntimeError(
            f"trtexec failed (exit {result.returncode}):\n"
            f"stderr: {result.stderr[-500:]}\n"
            f"stdout: {result.stdout[-500:]}"
        )

    if not os.path.exists(output_path):
        raise RuntimeError(f"trtexec completed but engine file not found: {output_path}")

    return output_path, build_time


def optimize(
    workload_path: str,
    target: str = "trt",
    precision: str = "fp16",
    output_dir: str | None = None,
    calib_data: str | None = None,
    use_dla: bool = False,
    dla_core: int = 0,
) -> OptimizeResult:
    """Full optimization pipeline: detect env → ONNX → TensorRT → metadata.

    This is the one-command production deployment path that Grok demanded.

    Args:
        workload_path: Path to workload .py file.
        target: "onnx" (ONNX only) or "trt" (ONNX → TensorRT engine).
        precision: "fp32", "fp16", or "int8".
        output_dir: Directory for output files (default: same as workload).
        calib_data: Path to calibration data for INT8 (required for int8).
        use_dla: V8 — offload to DLA cores (Jetson Orin only).
        dla_core: Which DLA core (0 or 1).

    Returns:
        OptimizeResult with paths, metrics, and environment info.
    """
    result = OptimizeResult(
        workload=workload_path,
        target=target,
        precision=precision,
        success=False,
    )

    # Step 1: Detect environment
    env = detect_environment()
    result.jetpack_version = env["jetpack_version"]
    result.cuda_version = env["cuda_version"]
    result.tensorrt_version = env["tensorrt_version"]
    result.gpu_name = env["gpu_name"]

    if target == "trt" and env["trtexec_path"] is None:
        result.error = (
            "trtexec not found. TensorRT engine export requires trtexec. "
            "On Jetson: comes with JetPack. On desktop: install TensorRT SDK."
        )
        return result

    if precision == "int8" and calib_data is None:
        result.warnings.append(
            "INT8 precision without calibration data — using TensorRT's default "
            "calibration. Provide --calib for production-grade accuracy."
        )

    # V9: Hardware-aware DLA validation (replaces V8's naive is_jetson check)
    if use_dla:
        from slowai.hardware import detect_jetson, require_dla, DLANotAvailableError
        hw = detect_jetson()
        try:
            require_dla(hw, dla_core)
        except DLANotAvailableError as e:
            result.error = str(e)
            result.warnings.append(str(e))
            return result

    result.dla_enabled = use_dla
    result.dla_core = dla_core

    # Determine output directory
    if output_dir is None:
        output_dir = os.path.dirname(os.path.abspath(workload_path))
    os.makedirs(output_dir, exist_ok=True)

    base = os.path.splitext(os.path.basename(workload_path))[0]

    # Step 2: Export to ONNX
    try:
        onnx_path = os.path.join(output_dir, f"{base}.onnx")
        onnx_path, export_time = export_onnx(workload_path, output_path=onnx_path)
        result.onnx_path = onnx_path
        result.export_time_s = export_time
        result.onnx_size_mb = os.path.getsize(onnx_path) / (1024 * 1024)
    except Exception as e:
        result.error = f"ONNX export failed: {e}"
        return result

    if target == "onnx":
        result.success = True
        return result

    # Step 3: Build TensorRT engine
    try:
        engine_path = os.path.join(output_dir, f"{base}_{precision}.engine")
        engine_path, build_time = build_tensorrt_engine(
            onnx_path,
            output_path=engine_path,
            precision=precision,
            trtexec_path=env["trtexec_path"],
            calib_cache=calib_data,
            use_dla=use_dla,
            dla_core=dla_core,
        )
        result.engine_path = engine_path
        result.build_time_s = build_time
        result.engine_size_mb = os.path.getsize(engine_path) / (1024 * 1024)
    except Exception as e:
        result.error = f"TensorRT engine build failed: {e}"
        result.success = False
        # ONNX still succeeded
        return result

    # Step 4: Write metadata JSON
    metadata = {
        "workload": os.path.basename(workload_path),
        "target": target,
        "precision": precision,
        "onnx_path": os.path.basename(onnx_path),
        "engine_path": os.path.basename(engine_path),
        "onnx_size_mb": round(result.onnx_size_mb, 2),
        "engine_size_mb": round(result.engine_size_mb, 2),
        "export_time_s": round(result.export_time_s, 3),
        "build_time_s": round(result.build_time_s, 3),
        "environment": {
            "gpu": env["gpu_name"],
            "cuda": env["cuda_version"],
            "tensorrt": env["tensorrt_version"],
            "jetpack": env["jetpack_version"],
            "is_jetson": env["is_jetson"],
        },
        "dla_enabled": use_dla,
        "dla_core": dla_core if use_dla else None,
        "warnings": result.warnings,
    }

    metadata_path = os.path.join(output_dir, f"{base}_{precision}_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)
    result.metadata_path = metadata_path

    result.success = True
    return result
