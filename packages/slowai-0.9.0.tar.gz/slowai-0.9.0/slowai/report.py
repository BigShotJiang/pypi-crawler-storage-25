"""
slowai.report — generate beautiful HTML diagnostic reports.

V6 feature: the thing that makes investors say "holy shit."
One command → a self-contained HTML report with:
  - Hardware + acceleration capability summary
  - Regime classification with confidence gauge
  - Speedup bar chart for all remedies tried
  - Before/after wall-time comparison
  - Winner highlight + export config
  - Timestamp + workload metadata

Usage:
    from slowai.report import generate_report
    html = generate_report(fix_report, accel_info)
    # or from CLI: slowai report model.py -o report.html
"""

from __future__ import annotations

import html as html_module
import os
from datetime import datetime, timezone

from slowai.remediate import FixReport


def _regime_color(regime_str: str) -> str:
    """Map regime names to CSS colors."""
    colors = {
        "compute_bound": "#e74c3c",
        "memory_bound": "#f39c12",
        "overhead_bound": "#9b59b6",
        "unknown": "#95a5a6",
    }
    return colors.get(regime_str, "#95a5a6")


def _regime_icon(regime_str: str) -> str:
    icons = {
        "compute_bound": "&#x1F525;",   # fire
        "memory_bound": "&#x1F4BE;",    # floppy
        "overhead_bound": "&#x26A1;",   # lightning
        "unknown": "&#x2753;",          # question
    }
    return icons.get(regime_str, "&#x2753;")


def generate_report(
    report: FixReport,
    accel_info: dict | None = None,
    jetson_info: dict | None = None,
) -> str:
    """Generate a self-contained HTML report from a FixReport.

    Args:
        report: The FixReport from auto_fix().
        accel_info: Optional dict from check_acceleration_support().
        jetson_info: Optional dict from check_jetson_power_mode().

    Returns:
        Complete HTML string.
    """
    bd = report.baseline_diagnosis
    regime = bd.regime.value
    confidence = bd.confidence
    workload = os.path.basename(report.workload)
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    baseline_wall = bd.evidence.get("wall_time_s", 0.0)
    best = report.best

    # Build remedy data for chart
    remedy_names = []
    remedy_speedups = []
    remedy_colors = []
    remedy_errors = []
    for r in report.results:
        remedy_names.append(r.remedy_name)
        if r.error:
            remedy_speedups.append(0)
            remedy_colors.append("#e74c3c")
            remedy_errors.append(r.error[:60])
        else:
            remedy_speedups.append(round(r.speedup, 2))
            if best and r.remedy_name == best.remedy_name:
                remedy_colors.append("#2ecc71")
            elif r.speedup > 1.0:
                remedy_colors.append("#3498db")
            else:
                remedy_colors.append("#95a5a6")
            remedy_errors.append("")

    # Hardware info section
    hw_lines = []
    if accel_info:
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">CUDA Capability</span><span class="hw-value">{accel_info.get("cuda_capability", "N/A")}</span></div>')
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">torch.compile</span><span class="hw-value {"available" if accel_info.get("torch_compile") else "unavailable"}">{_avail(accel_info.get("torch_compile"))}</span></div>')
        trt_ver = accel_info.get("tensorrt_version", "")
        trt_str = f"v{trt_ver}" if trt_ver else _avail(accel_info.get("tensorrt"))
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">TensorRT</span><span class="hw-value">{trt_str}</span></div>')
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">INT8 Tensor Cores</span><span class="hw-value {"available" if accel_info.get("int8_support") else "unavailable"}">{_avail(accel_info.get("int8_support"))}</span></div>')
        if accel_info.get("dla_available"):
            hw_lines.append(f'<div class="hw-item"><span class="hw-label">DLA Cores</span><span class="hw-value available">{accel_info.get("dla_cores", 0)}</span></div>')

    if jetson_info and jetson_info.get("is_jetson"):
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">Platform</span><span class="hw-value">NVIDIA Jetson</span></div>')
        hw_lines.append(f'<div class="hw-item"><span class="hw-label">Power Mode</span><span class="hw-value">{jetson_info.get("mode_name", "unknown")}</span></div>')

    hw_html = "\n".join(hw_lines) if hw_lines else '<div class="hw-item"><span class="hw-label">Hardware</span><span class="hw-value">Run with --accel to detect backends</span></div>'

    # Remedy results table
    table_rows = []
    for i, r in enumerate(report.results, 1):
        if r.error:
            status_class = "error"
            speedup_str = "FAILED"
            detail = html_module.escape(r.error[:80])
            time_str = "—"
        else:
            speedup_str = f"{r.speedup:.2f}x"
            time_str = f"{r.baseline_wall_s:.3f}s &rarr; {r.remedied_wall_s:.3f}s"
            detail = html_module.escape(r.remedy_description)
            if r.speedup >= 2.0:
                status_class = "excellent"
            elif r.speedup >= 1.1:
                status_class = "good"
            elif r.speedup >= 1.0:
                status_class = "neutral"
            else:
                status_class = "slower"

        is_best = best and r.remedy_name == best.remedy_name
        best_badge = ' <span class="best-badge">WINNER</span>' if is_best else ""

        table_rows.append(f"""
        <tr class="{status_class}{'best-row' if is_best else ''}">
            <td class="rank">{i}</td>
            <td class="remedy-name">{html_module.escape(r.remedy_name)}{best_badge}</td>
            <td class="speedup">{speedup_str}</td>
            <td class="times">{time_str}</td>
            <td class="desc">{detail}</td>
        </tr>""")

    table_html = "\n".join(table_rows)

    # Winner section
    if best:
        pct = (best.speedup - 1.0) * 100
        winner_html = f"""
        <div class="winner-card">
            <div class="winner-title">WINNER</div>
            <div class="winner-name">{html_module.escape(best.remedy_name)}</div>
            <div class="winner-speedup">{best.speedup:.2f}x faster</div>
            <div class="winner-detail">{best.baseline_wall_s:.3f}s &rarr; {best.remedied_wall_s:.3f}s (+{pct:.0f}%)</div>
            <div class="winner-desc">{html_module.escape(best.remedy_description)}</div>
        </div>"""
    else:
        winner_html = """
        <div class="winner-card no-winner">
            <div class="winner-title">NO SPEEDUP FOUND</div>
            <div class="winner-desc">This workload may already be well-optimized.</div>
        </div>"""

    # Chart.js data
    chart_labels = str(remedy_names).replace("'", '"')
    chart_data = str(remedy_speedups)
    chart_colors = str(remedy_colors).replace("'", '"')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>slowai report — {html_module.escape(workload)}</title>
<style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background: #0a0a0a;
        color: #e0e0e0;
        line-height: 1.6;
    }}
    .container {{ max-width: 1100px; margin: 0 auto; padding: 32px 24px; }}

    /* Header */
    .header {{
        text-align: center;
        padding: 40px 0 32px;
        border-bottom: 1px solid #222;
        margin-bottom: 32px;
    }}
    .header h1 {{
        font-size: 2.2em;
        font-weight: 700;
        background: linear-gradient(135deg, #2ecc71, #3498db);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 8px;
    }}
    .header .subtitle {{
        color: #888;
        font-size: 0.95em;
    }}
    .header .workload-name {{
        font-size: 1.3em;
        color: #fff;
        margin: 12px 0 4px;
        font-family: 'SF Mono', Menlo, monospace;
    }}

    /* Regime badge */
    .regime-section {{
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 24px;
        margin: 24px 0;
        flex-wrap: wrap;
    }}
    .regime-badge {{
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 24px;
        border-radius: 12px;
        font-size: 1.1em;
        font-weight: 600;
        border: 2px solid {_regime_color(regime)};
        color: {_regime_color(regime)};
        background: {_regime_color(regime)}15;
    }}
    .confidence-bar {{
        width: 200px;
        height: 8px;
        background: #222;
        border-radius: 4px;
        overflow: hidden;
    }}
    .confidence-fill {{
        height: 100%;
        width: {confidence * 100:.0f}%;
        background: linear-gradient(90deg, #3498db, #2ecc71);
        border-radius: 4px;
    }}
    .confidence-label {{
        color: #888;
        font-size: 0.85em;
    }}

    /* Hardware grid */
    .hw-section {{
        background: #111;
        border-radius: 12px;
        padding: 20px 24px;
        margin-bottom: 24px;
    }}
    .hw-section h2 {{
        font-size: 1em;
        color: #888;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 12px;
    }}
    .hw-grid {{
        display: flex;
        flex-wrap: wrap;
        gap: 8px 24px;
    }}
    .hw-item {{
        display: flex;
        gap: 8px;
        font-size: 0.9em;
    }}
    .hw-label {{ color: #888; }}
    .hw-value {{ color: #e0e0e0; font-weight: 500; }}
    .hw-value.available {{ color: #2ecc71; }}
    .hw-value.unavailable {{ color: #e74c3c; }}

    /* Chart */
    .chart-section {{
        background: #111;
        border-radius: 12px;
        padding: 24px;
        margin-bottom: 24px;
    }}
    .chart-section h2 {{
        font-size: 1.1em;
        margin-bottom: 16px;
        color: #fff;
    }}
    .chart-container {{ position: relative; height: 320px; }}

    /* Winner card */
    .winner-card {{
        background: linear-gradient(135deg, #0d2818, #0a1628);
        border: 2px solid #2ecc71;
        border-radius: 16px;
        padding: 32px;
        text-align: center;
        margin-bottom: 24px;
    }}
    .winner-card.no-winner {{
        border-color: #555;
        background: #111;
    }}
    .winner-title {{
        font-size: 0.85em;
        text-transform: uppercase;
        letter-spacing: 2px;
        color: #2ecc71;
        margin-bottom: 8px;
    }}
    .winner-name {{
        font-size: 1.8em;
        font-weight: 700;
        color: #fff;
        font-family: 'SF Mono', Menlo, monospace;
        margin-bottom: 4px;
    }}
    .winner-speedup {{
        font-size: 2.5em;
        font-weight: 800;
        background: linear-gradient(135deg, #2ecc71, #27ae60);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 8px 0;
    }}
    .winner-detail {{
        color: #aaa;
        font-family: 'SF Mono', Menlo, monospace;
        font-size: 0.95em;
        margin-bottom: 8px;
    }}
    .winner-desc {{
        color: #888;
        font-size: 0.9em;
    }}

    /* Results table */
    .results-section {{
        background: #111;
        border-radius: 12px;
        padding: 24px;
        margin-bottom: 24px;
        overflow-x: auto;
    }}
    .results-section h2 {{
        font-size: 1.1em;
        margin-bottom: 16px;
        color: #fff;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        font-size: 0.9em;
    }}
    th {{
        text-align: left;
        padding: 10px 12px;
        border-bottom: 2px solid #333;
        color: #888;
        font-weight: 500;
        text-transform: uppercase;
        font-size: 0.8em;
        letter-spacing: 0.5px;
    }}
    td {{
        padding: 10px 12px;
        border-bottom: 1px solid #1a1a1a;
    }}
    tr:hover {{ background: #1a1a1a; }}
    .rank {{ color: #555; width: 40px; }}
    .remedy-name {{ font-family: 'SF Mono', Menlo, monospace; font-weight: 500; }}
    .speedup {{ font-weight: 700; font-size: 1.05em; }}
    .times {{ font-family: 'SF Mono', Menlo, monospace; color: #888; font-size: 0.85em; }}
    .desc {{ color: #777; font-size: 0.85em; max-width: 300px; }}
    tr.excellent .speedup {{ color: #2ecc71; }}
    tr.good .speedup {{ color: #3498db; }}
    tr.neutral .speedup {{ color: #888; }}
    tr.slower .speedup {{ color: #e67e22; }}
    tr.error .speedup {{ color: #e74c3c; }}
    .best-badge {{
        background: #2ecc71;
        color: #000;
        font-size: 0.65em;
        padding: 2px 8px;
        border-radius: 4px;
        margin-left: 8px;
        font-weight: 700;
        vertical-align: middle;
    }}

    /* Footer */
    .footer {{
        text-align: center;
        padding: 24px 0;
        border-top: 1px solid #222;
        margin-top: 16px;
        color: #555;
        font-size: 0.85em;
    }}
    .footer a {{ color: #3498db; text-decoration: none; }}
    .footer a:hover {{ text-decoration: underline; }}

    /* Baseline stat */
    .baseline-stat {{
        font-family: 'SF Mono', Menlo, monospace;
        color: #aaa;
        font-size: 0.95em;
        text-align: center;
        margin: 4px 0 20px;
    }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>slowai diagnostic report</h1>
        <div class="workload-name">{html_module.escape(workload)}</div>
        <div class="baseline-stat">baseline: {baseline_wall:.3f}s &middot; {report.baseline_diagnosis.evidence.get('total_ops', 0)} ops</div>
        <div class="regime-section">
            <div class="regime-badge">{_regime_icon(regime)} {regime.upper().replace('_', ' ')}</div>
            <div>
                <div class="confidence-bar"><div class="confidence-fill"></div></div>
                <div class="confidence-label">confidence: {confidence:.0%}</div>
            </div>
        </div>
    </div>

    <div class="hw-section">
        <h2>Hardware &amp; Acceleration</h2>
        <div class="hw-grid">
            {hw_html}
        </div>
    </div>

    {winner_html}

    <div class="chart-section">
        <h2>Remedy Speedups</h2>
        <div class="chart-container">
            <canvas id="speedupChart"></canvas>
        </div>
    </div>

    <div class="results-section">
        <h2>All Remedies Tested ({len(report.results)})</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Remedy</th>
                    <th>Speedup</th>
                    <th>Time</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                {table_html}
            </tbody>
        </table>
    </div>

    <div class="footer">
        <p>Generated by <a href="https://pypi.org/project/slowai/">slowai</a> &middot; {timestamp}</p>
        <p>pip install slowai &middot; Built by Rico Allen</p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById('speedupChart').getContext('2d');
new Chart(ctx, {{
    type: 'bar',
    data: {{
        labels: {chart_labels},
        datasets: [{{
            label: 'Speedup (x)',
            data: {chart_data},
            backgroundColor: {chart_colors},
            borderColor: {chart_colors},
            borderWidth: 1,
            borderRadius: 6,
        }}]
    }},
    options: {{
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {{
            legend: {{ display: false }},
            tooltip: {{
                callbacks: {{
                    label: function(ctx) {{
                        return ctx.raw > 0 ? ctx.raw + 'x' : 'FAILED';
                    }}
                }}
            }}
        }},
        scales: {{
            x: {{
                beginAtZero: true,
                grid: {{ color: '#222' }},
                ticks: {{ color: '#888', callback: v => v + 'x' }},
                title: {{ display: true, text: 'Speedup', color: '#888' }}
            }},
            y: {{
                grid: {{ display: false }},
                ticks: {{
                    color: '#ccc',
                    font: {{ family: "'SF Mono', Menlo, monospace", size: 12 }}
                }}
            }}
        }}
    }}
}});
</script>
</body>
</html>"""
    return html


def _avail(val: bool | None) -> str:
    return "Available" if val else "Not installed"


def write_report(
    report: FixReport,
    output_path: str | None = None,
    accel_info: dict | None = None,
    jetson_info: dict | None = None,
) -> str:
    """Generate and write an HTML report.

    Args:
        report: FixReport from auto_fix().
        output_path: Where to write. Defaults to ./slowai_report.html.
        accel_info: Optional acceleration info dict.
        jetson_info: Optional Jetson info dict.

    Returns:
        The path written.
    """
    if output_path is None:
        base = os.path.splitext(os.path.basename(report.workload))[0]
        output_path = os.path.join(os.getcwd(), f"slowai_report_{base}.html")

    html = generate_report(report, accel_info, jetson_info)
    with open(output_path, "w") as f:
        f.write(html)
    return output_path
