"""
slowai.export — generate production-ready config from a FixReport.

The --export flag is what turns slowai from "tells you the fix" into
"gives you the code to ship." After auto_fix() finds the winning remedy,
export_config() writes a drop-in Python module that reproduces the exact
PyTorch settings.

Usage in your project:
    import slowai_config
    slowai_config.apply()
    # ... your model code ...

Or as a context manager:
    with slowai_config.optimized():
        model(data)
"""

from __future__ import annotations

import os
import textwrap
from datetime import datetime, timezone

from slowai.remediate import FixReport, RemedyResult


# ---------------------------------------------------------------------------
# Code templates per remedy name
# ---------------------------------------------------------------------------

_SETUP_TEMPLATES: dict[str, str] = {
    "tf32_tensor_cores": textwrap.dedent("""\
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True"""),

    "high_matmul_precision": textwrap.dedent("""\
        torch.set_float32_matmul_precision("high")"""),

    "cudnn_benchmark": textwrap.dedent("""\
        torch.backends.cudnn.benchmark = True"""),

    "channels_last": textwrap.dedent("""\
        torch.backends.cudnn.benchmark = True
        # Note: channels_last memory format should be applied to your model:
        # model = model.to(memory_format=torch.channels_last)
        # data = data.to(memory_format=torch.channels_last)"""),
}

_TEARDOWN_TEMPLATES: dict[str, str] = {
    "tf32_tensor_cores": textwrap.dedent("""\
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False"""),

    "high_matmul_precision": textwrap.dedent("""\
        torch.set_float32_matmul_precision("highest")"""),

    "cudnn_benchmark": textwrap.dedent("""\
        torch.backends.cudnn.benchmark = False"""),

    "channels_last": textwrap.dedent("""\
        torch.backends.cudnn.benchmark = False"""),
}

_CONTEXT_TEMPLATES: dict[str, str] = {
    "bf16_autocast": 'torch.autocast("cuda", dtype=torch.bfloat16)',
    "fp16_autocast": 'torch.autocast("cuda", dtype=torch.float16)',
}

# V5: Transform templates — these compile/transform the main() function.
_TRANSFORM_TEMPLATES: dict[str, str] = {
    "torch_compile": textwrap.dedent("""\
        # torch.compile with inductor backend — fuses ops, eliminates Python overhead.
        # Wrap your inference function (not the model — the full inference loop):
        #   compiled_fn = torch.compile(my_inference_fn, mode="reduce-overhead")
        #   compiled_fn()
        #
        # Or compile the model directly:
        #   model = torch.compile(model, mode="reduce-overhead")
        torch._dynamo.config.suppress_errors = True"""),

    "tensorrt": textwrap.dedent("""\
        # TensorRT via torch.compile — NVIDIA's inference optimizer.
        # Requires: pip install torch-tensorrt
        import torch_tensorrt  # noqa: F401 — registers backend
        torch._dynamo.config.suppress_errors = True
        # Compile your model:
        #   model = torch.compile(model, backend="torch_tensorrt")
        # Or compile your inference function:
        #   compiled_fn = torch.compile(inference_fn, backend="torch_tensorrt")"""),

    "tensorrt_fp16": textwrap.dedent("""\
        # TensorRT with FP16 — maximum throughput on Ampere tensor cores.
        # Requires: pip install torch-tensorrt
        import torch_tensorrt  # noqa: F401
        torch._dynamo.config.suppress_errors = True
        # Compile with FP16 enabled:
        #   model = torch.compile(model, backend="torch_tensorrt",
        #       options={"enabled_precisions": {torch.float16}})"""),

    "int8_dynamic_quant": textwrap.dedent("""\
        # INT8 dynamic quantization — 2-4x speedup on Ampere INT8 tensor cores.
        # Apply to your model before inference:
        #   model = torch.ao.quantization.quantize_dynamic(
        #       model, {torch.nn.Linear, torch.nn.LSTM}, dtype=torch.qint8)"""),
}


def _generate_config(result: RemedyResult, report: FixReport) -> str:
    """Generate the Python source for a slowai_config module."""
    name = result.remedy_name
    desc = result.remedy_description
    speedup = result.speedup
    baseline = result.baseline_wall_s
    after = result.remedied_wall_s
    regime = report.baseline_diagnosis.regime.value
    workload = os.path.basename(report.workload)
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    setup_code = _SETUP_TEMPLATES.get(name, "")
    teardown_code = _TEARDOWN_TEMPLATES.get(name, "")
    context_expr = _CONTEXT_TEMPLATES.get(name, "")
    transform_code = _TRANSFORM_TEMPLATES.get(name, "")

    # Build the apply() function body.
    if transform_code:
        apply_body = transform_code
    elif setup_code:
        apply_body = setup_code
    elif context_expr:
        # For autocast remedies, apply() sets it as default — user wraps their code.
        apply_body = (
            f"global _slowai_ctx\n"
            f"_slowai_ctx = {context_expr}\n"
            f"_slowai_ctx.__enter__()"
        )
    else:
        apply_body = "pass  # No global settings for this remedy."

    # Build the optimized() context manager body.
    if context_expr:
        ctx_body = f"return {context_expr}"
    elif setup_code and teardown_code:
        ctx_body = (
            f"{setup_code}\n"
            f"        try:\n"
            f"            yield\n"
            f"        finally:\n"
            f"            {teardown_code.replace(chr(10), chr(10) + '            ')}"
        )
    else:
        ctx_body = "yield  # No-op context manager."

    # Assemble the full module.
    lines = [
        f'"""',
        f"slowai auto-generated config — {name}",
        f"",
        f"Generated by: slowai fix {workload} --export",
        f"Date: {timestamp}",
        f"Workload: {workload}",
        f"Regime: {regime}",
        f"Remedy: {desc}",
        f"Speedup: {speedup:.2f}x ({baseline:.3f}s -> {after:.3f}s)",
        f"",
        f"Usage:",
        f"    import slowai_config",
        f"    slowai_config.apply()        # Set globally before your code",
        f"    # ... your model code ...",
        f"",
        f"    # Or as a context manager:",
        f"    with slowai_config.optimized():",
        f"        model(data)",
        f'"""',
        f"",
        f"import contextlib",
        f"import torch",
        f"",
        f'REMEDY = "{name}"',
        f'DESCRIPTION = "{desc}"',
        f"SPEEDUP = {speedup:.2f}",
        f"",
        f"_slowai_ctx = None  # holds autocast context if apply() is called",
        f"",
        f"",
        f"def apply():",
        f'    """Apply the winning remedy globally. Call once at startup."""',
    ]

    # Indent apply_body properly.
    for line in apply_body.split("\n"):
        lines.append(f"    {line}" if line.strip() else "")

    lines.extend([
        "",
        "",
        "@contextlib.contextmanager",
        "def optimized():",
        f'    """Context manager that applies the remedy for a block of code."""',
    ])

    if transform_code:
        lines.append(f"    # V5 transform remedies compile the function — use apply() above.")
        lines.append(f"    # For scoped usage, compile your function before the block:")
        lines.append(f"    yield")
    elif context_expr:
        lines.append(f"    with {context_expr}:")
        lines.append(f"        yield")
    elif setup_code and teardown_code:
        for line in setup_code.split("\n"):
            lines.append(f"    {line}")
        lines.append("    try:")
        lines.append("        yield")
        lines.append("    finally:")
        for line in teardown_code.split("\n"):
            lines.append(f"        {line}")
    else:
        lines.append("    yield")

    lines.append("")
    return "\n".join(lines)


def export_config(
    report: FixReport,
    output_path: str | None = None,
) -> str | None:
    """Write a slowai_config.py from a FixReport's winning remedy.

    Args:
        report: The FixReport from auto_fix().
        output_path: Where to write. Defaults to ./slowai_config.py.

    Returns:
        The path written, or None if no winning remedy exists.
    """
    best = report.best
    if best is None:
        return None

    if output_path is None:
        output_path = os.path.join(os.getcwd(), "slowai_config.py")

    source = _generate_config(best, report)

    with open(output_path, "w") as f:
        f.write(source)

    return output_path
