"""Allow running slowai as: python3 -m slowai"""
from slowai.cli import main

if __name__ == "__main__":
    main()
