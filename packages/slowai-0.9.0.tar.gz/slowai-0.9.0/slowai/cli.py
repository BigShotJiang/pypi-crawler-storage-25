"""slowai CLI — V9.

Usage:
    slowai diagnose <workload.py>
    slowai fix <workload.py>
    slowai fix <workload.py> --export              # save winning config
    slowai fix <workload.py> --ci --threshold 2.0  # CI/CD gate
    slowai report <workload.py>                    # HTML diagnostic report
    slowai validate <workload.py>                  # safety validation suite
    slowai validate <workload.py> --strict         # hard gate (any non-SAFE = fail)
    slowai optimize <workload.py> --target=trt     # ONNX → TensorRT engine
    slowai optimize <workload.py> --precision=int8 # INT8 engine
    slowai optimize <workload.py> --dla            # DLA offloading (NX/AGX/Thor)
    slowai scan <directory>                        # batch-scan all workloads
    slowai capabilities                            # show acceleration backends
    slowai power                                   # Jetson power/thermal status
    slowai hardware                                # V9: detect Jetson SKU + capabilities
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import os
import sys


def _diagnosis_to_dict(diag) -> dict:
    """Flatten a Diagnosis into plain dicts/lists for JSON output."""
    d = dataclasses.asdict(diag)
    # Regime is a str Enum — asdict leaves it as the value already,
    # but be defensive in case of subclassing.
    if hasattr(diag.regime, "value"):
        d["regime"] = diag.regime.value
    return d


def _cmd_diagnose(args) -> int:
    # Lazy imports so `slowai --help` works without torch installed.
    from slowai.diagnose import classify
    from slowai.profiler import profile_workload

    try:
        result = profile_workload(args.workload)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except Exception as e:  # noqa: BLE001
        print(f"error: failed to profile workload: {e}", file=sys.stderr)
        return 3

    diag = classify(result)

    if args.json:
        print(json.dumps(_diagnosis_to_dict(diag), indent=2, default=str))
        return 0

    # Human-readable output.
    print(diag.summary())
    print(f"  device: {result.device}")
    print(f"  wall time: {result.wall_time_s:.3f}s")
    print(f"  total ops: {result.total_op_count}")
    if result.op_stats:
        top = result.top_op
        print(f"  top op: {top.name} (x{top.count}, {top.total_us / 1000:.1f} ms total)")
    if diag.evidence:
        print("  evidence:")
        for k, v in diag.evidence.items():
            if isinstance(v, float):
                print(f"    {k}: {v:.3f}")
            else:
                print(f"    {k}: {v}")
    if diag.top_fixes:
        print("  top fixes (cheapest first):")
        for i, fix in enumerate(diag.top_fixes, 1):
            print(f"    {i}. {fix}")
    return 0


def _cmd_fix(args) -> int:
    """The V3 command: diagnose + auto-apply fixes + show before/after speedup."""
    from slowai.remediate import auto_fix

    print(f"slowai fix: profiling baseline for {args.workload} ...")
    try:
        report = auto_fix(args.workload)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except Exception as e:  # noqa: BLE001
        print(f"error: failed to run auto-fix: {e}", file=sys.stderr)
        return 3

    bd = report.baseline_diagnosis

    # --ci mode: compact output, exit code driven by threshold.
    if getattr(args, "ci", False):
        threshold = getattr(args, "threshold", 1.0)
        best = report.best
        passed = best is not None and best.speedup >= threshold

        ci_out = {
            "workload": report.workload,
            "regime": bd.regime.value,
            "baseline_wall_s": bd.evidence.get("wall_time_s", 0.0),
            "best_remedy": best.remedy_name if best else None,
            "best_speedup": best.speedup if best else 0.0,
            "threshold": threshold,
            "passed": passed,
        }
        print(json.dumps(ci_out, indent=2))

        # --export in CI mode too.
        if getattr(args, "export", None) is not None:
            from slowai.export import export_config
            export_path = args.export if args.export != "" else None
            written = export_config(report, output_path=export_path or None)
            if written:
                print(f"Exported: {written}", file=sys.stderr)

        return 0 if passed else 1

    if args.json:
        out = {
            "workload": report.workload,
            "baseline": _diagnosis_to_dict(bd),
            "remedies": [
                {
                    "name": r.remedy_name,
                    "description": r.remedy_description,
                    "baseline_wall_s": r.baseline_wall_s,
                    "remedied_wall_s": r.remedied_wall_s,
                    "speedup": r.speedup,
                    "regime_before": r.regime_before.value,
                    "regime_after": r.regime_after.value,
                    "confidence_after": r.confidence_after,
                    "error": r.error,
                }
                for r in report.results
            ],
            "best": report.best.remedy_name if report.best else None,
        }
        print(json.dumps(out, indent=2, default=str))

        # --export works with --json too.
        if getattr(args, "export", None) is not None:
            from slowai.export import export_config
            export_path = args.export if args.export != "" else None
            written = export_config(report, output_path=export_path or None)
            if written:
                print(f"Exported: {written}", file=sys.stderr)

        return 0

    # Human-readable output.
    print()
    print("=" * 62)
    print(f"  BASELINE: {bd.summary()}")
    print(f"  wall time: {bd.evidence.get('wall_time_s', 0):.3f}s")
    print("=" * 62)

    if not report.results:
        print("\n  No auto-remedies available for this regime.")
        if bd.top_fixes:
            print("  Manual fixes (from `slowai diagnose`):")
            for i, fix in enumerate(bd.top_fixes, 1):
                print(f"    {i}. {fix}")
        return 0

    print(f"\n  Tried {len(report.results)} remedies:\n")

    for i, rr in enumerate(report.results, 1):
        if rr.error:
            status = "FAILED"
            detail = f"     error: {rr.error}"
        else:
            arrow = ">>>" if rr.speedup > 1.05 else "---" if rr.speedup >= 0.95 else "<<<"
            status = f"{rr.speedup:.2f}x"
            detail = (
                f"     {rr.baseline_wall_s:.3f}s {arrow} {rr.remedied_wall_s:.3f}s"
            )

        best_marker = "  ** BEST **" if report.best and rr.remedy_name == report.best.remedy_name else ""
        print(f"  {i}. [{status}] {rr.remedy_name}{best_marker}")
        print(f"     {rr.remedy_description}")
        print(detail)
        if not rr.error:
            print(f"     regime: {rr.regime_after.value} (confidence: {rr.confidence_after:.2f})")
        print()

    best = report.best
    if best:
        pct = (best.speedup - 1.0) * 100
        print("-" * 62)
        print(f"  WINNER: {best.remedy_name}")
        print(f"  {best.baseline_wall_s:.3f}s >>> {best.remedied_wall_s:.3f}s  ({best.speedup:.2f}x, +{pct:.0f}% faster)")
        print(f"  How: {best.remedy_description}")
        print("-" * 62)
    else:
        print("-" * 62)
        print("  No remedy produced a speedup. The workload may already be")
        print("  well-optimized, or the fixes require manual code changes.")
        print("  Run `slowai diagnose` for the full prescription list.")
        print("-" * 62)

    # --export: save winning config as a production-ready Python module.
    if getattr(args, "export", None) is not None:
        from slowai.export import export_config

        export_path = args.export if args.export != "" else None
        written = export_config(report, output_path=export_path or None)
        if written:
            print(f"\n  Exported config: {written}")
            print("  Usage: import slowai_config; slowai_config.apply()")
        else:
            print("\n  No winning remedy to export.")

    return 0


def _cmd_report(args) -> int:
    """V6: Generate a beautiful HTML diagnostic report."""
    from slowai.remediate import auto_fix, check_acceleration_support, check_jetson_power_mode
    from slowai.report import write_report

    print(f"slowai report: profiling {args.workload} ...")
    try:
        report = auto_fix(args.workload)
    except FileNotFoundError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    except Exception as e:  # noqa: BLE001
        print(f"error: failed to profile workload: {e}", file=sys.stderr)
        return 3

    # Gather hardware info
    print("  detecting acceleration backends ...")
    try:
        accel = check_acceleration_support()
    except Exception:
        accel = None
    try:
        jetson = check_jetson_power_mode()
    except Exception:
        jetson = None

    output = getattr(args, "output", None)
    path = write_report(report, output_path=output, accel_info=accel, jetson_info=jetson)

    # Print summary to terminal too
    best = report.best
    bd = report.baseline_diagnosis
    print()
    print("=" * 62)
    print(f"  BASELINE: {bd.summary()}")
    print(f"  wall time: {bd.evidence.get('wall_time_s', 0):.3f}s")
    if best:
        pct = (best.speedup - 1.0) * 100
        print(f"  WINNER: {best.remedy_name} ({best.speedup:.2f}x, +{pct:.0f}%)")
    print(f"  report: {path}")
    print("=" * 62)

    return 0


def _cmd_scan(args) -> int:
    """V6: Batch-scan a directory of workloads."""
    import glob
    from slowai.remediate import auto_fix

    pattern = os.path.join(args.directory, "*.py")
    workloads = sorted(glob.glob(pattern))

    if not workloads:
        print(f"No .py files found in {args.directory}")
        return 1

    print(f"slowai scan: found {len(workloads)} workloads in {args.directory}")
    print()
    print(f"  {'Workload':<35} {'Regime':<18} {'Best Remedy':<25} {'Speedup':>8}")
    print(f"  {'-'*35} {'-'*18} {'-'*25} {'-'*8}")

    results = []
    for wl in workloads:
        name = os.path.basename(wl)
        try:
            report = auto_fix(wl)
            regime = report.baseline_diagnosis.regime.value
            best = report.best
            if best:
                results.append((name, regime, best.remedy_name, best.speedup))
                print(f"  {name:<35} {regime:<18} {best.remedy_name:<25} {best.speedup:>7.2f}x")
            else:
                results.append((name, regime, "—", 0.0))
                print(f"  {name:<35} {regime:<18} {'—':<25} {'—':>8}")
        except Exception as e:
            results.append((name, "ERROR", str(e)[:25], 0.0))
            print(f"  {name:<35} {'ERROR':<18} {str(e)[:25]:<25} {'—':>8}")

    # Summary
    successful = [r for r in results if r[3] > 1.0]
    if successful:
        avg = sum(r[3] for r in successful) / len(successful)
        best_overall = max(successful, key=lambda r: r[3])
        print()
        print(f"  {len(successful)}/{len(results)} workloads improved")
        print(f"  avg speedup: {avg:.2f}x")
        print(f"  best: {best_overall[0]} ({best_overall[2]}, {best_overall[3]:.2f}x)")

    if args.json:
        out = [
            {"workload": r[0], "regime": r[1], "best_remedy": r[2], "speedup": r[3]}
            for r in results
        ]
        print(json.dumps(out, indent=2))

    return 0


def _cmd_validate(args) -> int:
    """V8: Run safety validation suite with hard deployment gates."""
    from slowai.remediate import auto_fix
    from slowai.safety import validate_fix_report

    strict = getattr(args, "strict", False)

    print(f"slowai validate: profiling + safety testing {args.workload} ...")
    if strict:
        print("  MODE: --strict (any non-SAFE grade = hard fail)")
    try:
        fix_report = auto_fix(args.workload)
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        return 3

    atol = getattr(args, "atol", 1e-5)
    rtol = getattr(args, "rtol", 1e-3)

    print(f"  running numerical equivalence tests (atol={atol}, rtol={rtol}) ...")
    safety_report = validate_fix_report(args.workload, fix_report, atol=atol, rtol=rtol)

    # V8: Determine exit code based on mode
    if strict:
        exit_code = safety_report.exit_code_strict
    else:
        exit_code = safety_report.exit_code

    if args.json:
        out = {
            "workload": args.workload,
            "baseline_deterministic": safety_report.baseline_deterministic,
            "all_safe": safety_report.all_safe,
            "flight_ready": safety_report.flight_ready,
            "strict_mode": strict,
            "exit_code": exit_code,
            "scores": [
                {
                    "remedy": s.remedy_name,
                    "grade": s.grade,
                    "max_abs_diff": s.max_abs_diff,
                    "max_rel_diff": s.max_rel_diff,
                    "cosine_similarity": s.cosine_similarity,
                    "deterministic": s.deterministic,
                    "error": s.error,
                }
                for s in safety_report.scores
            ],
        }
        print(json.dumps(out, indent=2))
        return exit_code

    # Human-readable output
    print()
    print("=" * 62)
    print("  slowai V8 — SAFETY VALIDATION REPORT")
    print("=" * 62)
    print()
    print(f"  Baseline deterministic: {'YES' if safety_report.baseline_deterministic else 'NO'}")
    if strict:
        print(f"  Mode: STRICT (hard gate — any non-SAFE blocks deployment)")
    print()

    for s in safety_report.scores:
        print(f"  {s.summary()}")

    print()
    if safety_report.flight_ready:
        print("  FLIGHT READY: All remedies passed with full determinism")
    elif safety_report.all_safe:
        print("  ALL SAFE: Remedies within tolerance (not fully deterministic)")
    else:
        unsafe = [s for s in safety_report.scores if s.grade == "UNSAFE"]
        caution = [s for s in safety_report.scores if s.grade == "CAUTION"]
        if unsafe:
            print(f"  BLOCKED: {len(unsafe)} remedy(s) UNSAFE — DO NOT DEPLOY")
        if caution:
            print(f"  CAUTION: {len(caution)} remedy(s) need review before safety-critical deployment")

    # V8: Exit code explanation
    code_labels = {0: "PASS", 1: "CAUTION", 2: "UNSAFE", 3: "ERROR"}
    print()
    print(f"  Exit code: {exit_code} ({code_labels.get(exit_code, '???')})")
    if strict and exit_code != 0:
        print("  DEPLOYMENT BLOCKED by --strict flag")
    print("=" * 62)

    return exit_code


def _cmd_optimize(args) -> int:
    """V8: Export workload to TensorRT engine via ONNX, with DLA offloading."""
    from slowai.optimize import optimize, detect_environment

    target = getattr(args, "target", "trt")
    precision = getattr(args, "precision", "fp16")
    calib = getattr(args, "calib", None)
    output_dir = getattr(args, "output_dir", None)
    use_dla = getattr(args, "dla", False)
    dla_core = getattr(args, "dla_core", 0)

    dla_str = f" + DLA core {dla_core}" if use_dla else ""
    print(f"slowai optimize: {args.workload} → {target.upper()} ({precision}{dla_str})")

    # Pre-check environment
    env = detect_environment()
    if target == "trt" and env["trtexec_path"] is None:
        print("  ERROR: trtexec not found.", file=sys.stderr)
        print("  On Jetson: it ships with JetPack at /usr/src/tensorrt/bin/trtexec", file=sys.stderr)
        print("  On desktop: install TensorRT SDK and add trtexec to PATH", file=sys.stderr)
        return 2

    print(f"  GPU: {env.get('gpu_name', 'unknown')}")
    print(f"  CUDA: {env.get('cuda_version', 'unknown')}")
    print(f"  TensorRT: {env.get('tensorrt_version', 'unknown')}")
    if env.get("is_jetson"):
        print(f"  JetPack: {env.get('jetpack_version', 'unknown')}")
    if use_dla:
        print(f"  DLA: core {dla_core} (offloading compatible layers)")
    print()

    result = optimize(
        args.workload,
        target=target,
        precision=precision,
        output_dir=output_dir,
        calib_data=calib,
        use_dla=use_dla,
        dla_core=dla_core,
    )

    if not result.success:
        print(f"  FAILED: {result.error}", file=sys.stderr)
        if result.onnx_path:
            print(f"  (ONNX export succeeded: {result.onnx_path})")
        return 1

    # Success output
    print("=" * 62)
    if result.onnx_path:
        print(f"  ONNX: {result.onnx_path} ({result.onnx_size_mb:.1f} MB, {result.export_time_s:.1f}s)")
    if result.engine_path:
        print(f"  ENGINE: {result.engine_path} ({result.engine_size_mb:.1f} MB, {result.build_time_s:.1f}s)")
    if result.metadata_path:
        print(f"  METADATA: {result.metadata_path}")
    if result.warnings:
        for w in result.warnings:
            print(f"  WARNING: {w}")
    print("=" * 62)

    if args.json:
        import dataclasses
        print(json.dumps(dataclasses.asdict(result), indent=2))

    return 0


def _cmd_power(args) -> int:
    """V8: Show Jetson power mode, thermal status, and clock frequencies."""
    from slowai.power import detect_power_state, is_throttling, get_thermal_status

    state = detect_power_state()

    if args.json:
        import dataclasses
        print(json.dumps(dataclasses.asdict(state), indent=2))
        return 0

    print()
    print("=" * 62)
    print("  slowai V8 — POWER & THERMAL STATUS")
    print("=" * 62)
    print()

    if not state.is_system_jetson:
        print("  Not a Jetson device — power management not applicable.")
        print("  (This command is for NVIDIA Jetson Orin/Xavier platforms)")
        print("=" * 62)
        return 0

    print(f"  Power mode: {state.nvpmodel_mode or 'unknown'}")
    print(f"  Jetson clocks: {'ENABLED' if state.jetson_clocks_enabled else 'disabled'}")
    if state.gpu_freq_mhz:
        print(f"  GPU frequency: {state.gpu_freq_mhz} MHz")
    if state.cpu_freq_mhz:
        print(f"  CPU frequency: {state.cpu_freq_mhz} MHz")
    print()

    # Thermal zones
    thermals = get_thermal_status()
    if thermals:
        print("  Thermal zones:")
        for zone, temp in sorted(thermals.items()):
            warn = " << THROTTLING" if temp > 80 else " (warm)" if temp > 65 else ""
            print(f"    {zone}: {temp:.1f}°C{warn}")
    print()

    throttling = is_throttling()
    if throttling:
        print("  WARNING: GPU is thermal throttling!")
        print("  Benchmark results will be unreliable.")
        print("  Consider improving cooling or reducing power mode.")
    else:
        print("  Thermal status: OK (no throttling detected)")

    print()

    # Recommendation
    if state.nvpmodel_mode and "MAXN" not in (state.nvpmodel_mode or "").upper():
        print("  TIP: Run 'sudo nvpmodel -m 0 && sudo jetson_clocks'")
        print("  for maximum performance during benchmarking.")
        print()

    print("=" * 62)
    return 0


def _cmd_capabilities(args) -> int:
    """V8: Show available acceleration backends and hardware capabilities."""
    from slowai.remediate import check_acceleration_support, check_jetson_power_mode

    accel = check_acceleration_support()
    jetson = check_jetson_power_mode()

    if args.json:
        import json as _json
        out = {**accel, **jetson}
        print(_json.dumps(out, indent=2))
        return 0

    print()
    print("=" * 62)
    print("  slowai V8 — acceleration capabilities")
    print("=" * 62)
    print()

    # GPU info
    try:
        import torch
        if torch.cuda.is_available():
            name = torch.cuda.get_device_name(0)
            mem = torch.cuda.get_device_properties(0).total_mem / (1024**3)
            print(f"  GPU: {name}")
            print(f"  VRAM: {mem:.1f} GB")
            print(f"  CUDA capability: {accel['cuda_capability']}")
        else:
            print("  GPU: No CUDA device found")
    except Exception:
        print("  GPU: Could not detect (torch not available)")

    print()

    # Jetson info
    if jetson["is_jetson"]:
        print(f"  Jetson: YES")
        print(f"  Power mode: {jetson.get('mode_name', 'unknown')}")
        maxn = "YES" if jetson.get("maxn") else "NO"
        print(f"  MAXN mode: {maxn}")
        clocks = "YES" if jetson.get("clocks_maxed") else "NO"
        print(f"  Clocks maxed: {clocks}")
    else:
        print(f"  Jetson: NO (desktop/server GPU)")

    print()

    # Acceleration backends
    def _status(available):
        return "AVAILABLE" if available else "not installed"

    print(f"  torch.compile (inductor):  {_status(accel['torch_compile'])}")
    print(f"  TensorRT:                  {_status(accel['tensorrt'])}", end="")
    if accel["tensorrt_version"]:
        print(f"  (v{accel['tensorrt_version']})")
    else:
        print()
    print(f"  torch_tensorrt:            {_status(accel['torch_tensorrt'])}")
    print(f"  INT8 tensor cores:         {_status(accel['int8_support'])}")
    print(f"  DLA (Deep Learning Accel): {_status(accel['dla_available'])}", end="")
    if accel["dla_cores"] > 0:
        print(f"  ({accel['dla_cores']} cores)")
    else:
        print()

    print()

    # Remedy count
    total_remedies = 0
    base_remedies = 5  # TF32, matmul_precision, BF16, FP16, cuDNN, channels_last
    total_remedies = base_remedies + 1  # +channels_last
    if accel["torch_compile"]:
        total_remedies += 1
    if accel["torch_tensorrt"]:
        total_remedies += 2  # tensorrt + tensorrt_fp16
    if accel["int8_support"]:
        total_remedies += 1

    print(f"  Total remedies available: {total_remedies}")
    print()
    print("=" * 62)

    return 0


def _cmd_hardware(args) -> int:
    """V9: Detect Jetson SKU and print hardware capability matrix."""
    from slowai.hardware import detect_jetson, format_hardware_report

    hw = detect_jetson()

    if args.json:
        import json as _json
        print(_json.dumps(hw.capability_matrix(), indent=2))
        return 0

    print(format_hardware_report(hw))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="slowai",
        description="Diagnose and auto-fix PyTorch performance bottlenecks.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # --- slowai diagnose ---
    diag = sub.add_parser(
        "diagnose", help="Profile a workload and classify its regime."
    )
    diag.add_argument("workload", help="Path to the Python script to diagnose.")
    diag.add_argument(
        "--json",
        action="store_true",
        help="Emit the Diagnosis as JSON instead of human-readable text.",
    )
    diag.set_defaults(func=_cmd_diagnose)

    # --- slowai fix ---
    fix = sub.add_parser(
        "fix", help="Auto-apply fixes and show before/after speedup."
    )
    fix.add_argument("workload", help="Path to the Python script to fix.")
    fix.add_argument(
        "--json",
        action="store_true",
        help="Emit the FixReport as JSON instead of human-readable text.",
    )
    fix.add_argument(
        "--export",
        nargs="?",
        const="",
        default=None,
        metavar="PATH",
        help="Save winning remedy as a production-ready slowai_config.py. "
             "Optionally specify output path (default: ./slowai_config.py).",
    )
    fix.add_argument(
        "--ci",
        action="store_true",
        help="CI/CD mode: exit 0 if a remedy meets the threshold, exit 1 if not. "
             "Outputs JSON to stdout for pipeline consumption.",
    )
    fix.add_argument(
        "--threshold",
        type=float,
        default=1.0,
        metavar="X",
        help="Minimum speedup required in --ci mode (default: 1.0). "
             "E.g. --threshold 2.0 means the best remedy must achieve at least 2x.",
    )
    fix.set_defaults(func=_cmd_fix)

    # --- slowai validate ---
    val = sub.add_parser(
        "validate", help="Run safety validation suite (numerical equivalence testing)."
    )
    val.add_argument("workload", help="Path to the Python script to validate.")
    val.add_argument(
        "--atol", type=float, default=1e-5,
        help="Absolute tolerance for SAFE grade (default: 1e-5).",
    )
    val.add_argument(
        "--rtol", type=float, default=1e-3,
        help="Relative tolerance for SAFE grade (default: 1e-3).",
    )
    val.add_argument("--json", action="store_true", help="Emit results as JSON.")
    val.add_argument(
        "--strict",
        action="store_true",
        help="V8: Hard safety gate — exit non-zero on ANY non-SAFE grade. "
             "Use in CI/CD to block deployment of numerically unsafe remedies.",
    )
    val.set_defaults(func=_cmd_validate)

    # --- slowai optimize ---
    opt = sub.add_parser(
        "optimize", help="Export workload to TensorRT engine via ONNX → trtexec."
    )
    opt.add_argument("workload", help="Path to the Python script to optimize.")
    opt.add_argument(
        "--target", choices=["onnx", "trt"], default="trt",
        help="Export target: 'onnx' (ONNX only) or 'trt' (ONNX → TensorRT engine, default).",
    )
    opt.add_argument(
        "--precision", choices=["fp32", "fp16", "int8"], default="fp16",
        help="TensorRT precision: fp32, fp16 (default), or int8.",
    )
    opt.add_argument(
        "--calib", default=None, metavar="PATH",
        help="Calibration data path for INT8 precision.",
    )
    opt.add_argument(
        "--output-dir", default=None, metavar="DIR",
        help="Directory for output files (default: same as workload).",
    )
    opt.add_argument("--json", action="store_true", help="Emit results as JSON.")
    opt.add_argument(
        "--dla",
        action="store_true",
        help="Offload compatible layers to DLA cores (Orin NX/AGX/Thor only). "
             "V9: errors clearly on hardware without DLA (e.g. Orin Nano).",
    )
    opt.add_argument(
        "--dla-core",
        type=int,
        default=0,
        choices=[0, 1],
        help="Which DLA core to use (0 or 1, Orin has 2). Default: 0.",
    )
    opt.set_defaults(func=_cmd_optimize)

    # --- slowai report ---
    rep = sub.add_parser(
        "report", help="Generate an HTML diagnostic report with speedup charts."
    )
    rep.add_argument("workload", help="Path to the Python script to profile.")
    rep.add_argument(
        "-o", "--output",
        default=None,
        metavar="PATH",
        help="Output path for the HTML report (default: ./slowai_report_<workload>.html).",
    )
    rep.set_defaults(func=_cmd_report)

    # --- slowai scan ---
    scn = sub.add_parser(
        "scan", help="Batch-scan all .py workloads in a directory."
    )
    scn.add_argument("directory", help="Directory containing workload .py files.")
    scn.add_argument(
        "--json",
        action="store_true",
        help="Emit scan results as JSON.",
    )
    scn.set_defaults(func=_cmd_scan)

    # --- slowai capabilities ---
    cap = sub.add_parser(
        "capabilities", help="Show available acceleration backends and hardware info."
    )
    cap.add_argument(
        "--json",
        action="store_true",
        help="Emit capabilities as JSON.",
    )
    cap.set_defaults(func=_cmd_capabilities)

    # --- slowai power (V8) ---
    pwr = sub.add_parser(
        "power", help="V8: Show Jetson power mode, thermal status, and clock frequencies."
    )
    pwr.add_argument(
        "--json",
        action="store_true",
        help="Emit power status as JSON.",
    )
    pwr.set_defaults(func=_cmd_power)

    # --- slowai hardware (V9) ---
    hwp = sub.add_parser(
        "hardware", help="V9: Detect Jetson SKU and show hardware capability matrix."
    )
    hwp.add_argument(
        "--json",
        action="store_true",
        help="Emit hardware info as JSON.",
    )
    hwp.set_defaults(func=_cmd_hardware)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
