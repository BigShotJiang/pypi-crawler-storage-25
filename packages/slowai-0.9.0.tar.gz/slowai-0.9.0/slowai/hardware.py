"""
slowai.hardware — Jetson SKU detection and hardware capability matrix.

V9 P0: Grok caught that Orin Nano Super has ZERO DLA cores. The V8 --dla
flag was offering a physically impossible feature on the benchmarking device.
This module fixes that by detecting the exact Jetson SKU and building a
capability matrix so every feature flag is gated on real hardware.

Detection strategy (ordered by reliability):
    1. /proc/device-tree/model  — canonical, present on all Jetson Linux
    2. /proc/device-tree/compatible — fallback, has tegra chip ID
    3. /etc/nv_tegra_release — JetPack release string (R35/R36)
    4. nvpmodel -q — confirms Jetson, gives power mode info

Usage:
    from slowai.hardware import detect_jetson, JetsonInfo
    hw = detect_jetson()
    if hw.has_dla:
        print(f"DLA available: {hw.dla_cores} cores")
    else:
        print(f"{hw.sku_name} does not have DLA hardware")
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path


# ---------------------------------------------------------------------------
# Hardware capability database
# ---------------------------------------------------------------------------
# Sources:
#   - NVIDIA Jetson Orin Module Data Sheet (DA-11060-001)
#   - NVIDIA Jetson Linux Developer Guide (JetPack 6.x)
#   - Grok V8 review (DLA core counts per SKU)
#
# Key: substring that appears in /proc/device-tree/model → capabilities.
# The model string on Jetson Linux is something like:
#   "NVIDIA Orin Nano Developer Kit"
#   "NVIDIA Jetson AGX Orin Developer Kit"
#   "Jetson Orin NX 16GB"

@dataclass(frozen=True)
class JetsonSKU:
    """Static capability record for a Jetson SKU."""
    name: str
    series: str                 # "orin_nano" | "orin_nx" | "agx_orin" | "thor" | "xavier_nx" | "agx_xavier"
    dla_cores: int              # 0, 1, or 2
    max_power_watts: int        # max nvpmodel wattage
    tensor_core_type: str       # "3rd_gen" (Ampere), "4th_gen" (Ada/Orin), etc.
    sm_version: str             # e.g. "8.7" for Orin (Ampere GA10B)
    unified_memory_gb: float    # shared CPU+GPU memory
    gpu_cores: int              # CUDA cores
    notes: str = ""


# Ordered most-specific first so substring matching picks the right SKU.
_KNOWN_SKUS: list[tuple[list[str], JetsonSKU]] = [
    # --- Orin Nano (ZERO DLA) ---
    (
        ["orin nano super", "orin nano 8gb super"],
        JetsonSKU(
            name="Jetson Orin Nano Super",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    (
        ["orin nano 8gb"],
        JetsonSKU(
            name="Jetson Orin Nano 8GB",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=15,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    (
        ["orin nano 4gb"],
        JetsonSKU(
            name="Jetson Orin Nano 4GB",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=10,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=4.0,
            gpu_cores=512,
            notes="No DLA hardware. GPU-only inference. Reduced CUDA cores.",
        ),
    ),
    (
        ["orin nano"],  # catch-all for any other Orin Nano variant
        JetsonSKU(
            name="Jetson Orin Nano (unknown variant)",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=15,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    # --- Orin NX (2 DLA cores) ---
    (
        ["orin nx 16gb"],
        JetsonSKU(
            name="Jetson Orin NX 16GB",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    (
        ["orin nx 8gb"],
        JetsonSKU(
            name="Jetson Orin NX 8GB",
            series="orin_nx",
            dla_cores=1,
            max_power_watts=20,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=768,
        ),
    ),
    (
        ["orin nx super"],
        JetsonSKU(
            name="Jetson Orin NX Super",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    (
        ["orin nx"],  # catch-all
        JetsonSKU(
            name="Jetson Orin NX (unknown variant)",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    # --- AGX Orin (2 DLA cores, big GPU) ---
    (
        ["agx orin 64gb"],
        JetsonSKU(
            name="Jetson AGX Orin 64GB",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=64.0,
            gpu_cores=2048,
        ),
    ),
    (
        ["agx orin 32gb", "agx orin developer kit"],
        JetsonSKU(
            name="Jetson AGX Orin 32GB",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=32.0,
            gpu_cores=1792,
        ),
    ),
    (
        ["agx orin"],  # catch-all
        JetsonSKU(
            name="Jetson AGX Orin (unknown variant)",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=32.0,
            gpu_cores=2048,
        ),
    ),
    # --- Thor (next-gen, 2 DLA cores) ---
    (
        ["thor"],
        JetsonSKU(
            name="Jetson Thor",
            series="thor",
            dla_cores=2,
            max_power_watts=100,
            tensor_core_type="5th_gen",
            sm_version="10.0",
            unified_memory_gb=128.0,
            gpu_cores=16384,
            notes="Next-gen. Specs may change.",
        ),
    ),
    # --- Xavier family (legacy, included for completeness) ---
    (
        ["agx xavier"],
        JetsonSKU(
            name="Jetson AGX Xavier",
            series="agx_xavier",
            dla_cores=2,
            max_power_watts=30,
            tensor_core_type="3rd_gen",
            sm_version="7.2",
            unified_memory_gb=32.0,
            gpu_cores=512,
        ),
    ),
    (
        ["xavier nx"],
        JetsonSKU(
            name="Jetson Xavier NX",
            series="xavier_nx",
            dla_cores=2,
            max_power_watts=20,
            tensor_core_type="3rd_gen",
            sm_version="7.2",
            unified_memory_gb=8.0,
            gpu_cores=384,
        ),
    ),
]


# ---------------------------------------------------------------------------
# Runtime detection result
# ---------------------------------------------------------------------------

@dataclass
class JetsonInfo:
    """Result of runtime hardware detection.

    This is the single source of truth for what the current device can do.
    Other modules (optimize.py, cli.py) should query this instead of
    guessing from is_jetson booleans.
    """
    is_jetson: bool = False
    model_string: str = ""          # raw /proc/device-tree/model content
    sku: JetsonSKU | None = None    # matched SKU from database, or None

    # Convenience accessors (derived from sku)
    @property
    def sku_name(self) -> str:
        if self.sku:
            return self.sku.name
        if self.is_jetson:
            return f"Unknown Jetson ({self.model_string})"
        return "Not a Jetson"

    @property
    def has_dla(self) -> bool:
        return self.sku is not None and self.sku.dla_cores > 0

    @property
    def dla_cores(self) -> int:
        return self.sku.dla_cores if self.sku else 0

    @property
    def series(self) -> str:
        return self.sku.series if self.sku else "unknown"

    @property
    def max_power_watts(self) -> int:
        return self.sku.max_power_watts if self.sku else 0

    @property
    def unified_memory_gb(self) -> float:
        return self.sku.unified_memory_gb if self.sku else 0.0

    @property
    def gpu_cores(self) -> int:
        return self.sku.gpu_cores if self.sku else 0

    def capability_matrix(self) -> dict:
        """Return a flat dict of capabilities for JSON/CLI output."""
        if not self.sku:
            return {
                "is_jetson": self.is_jetson,
                "model_string": self.model_string,
                "sku_name": self.sku_name,
                "dla_cores": 0,
                "has_dla": False,
            }
        return {
            "is_jetson": True,
            "model_string": self.model_string,
            "sku_name": self.sku.name,
            "series": self.sku.series,
            "dla_cores": self.sku.dla_cores,
            "has_dla": self.has_dla,
            "max_power_watts": self.sku.max_power_watts,
            "tensor_core_type": self.sku.tensor_core_type,
            "sm_version": self.sku.sm_version,
            "unified_memory_gb": self.sku.unified_memory_gb,
            "gpu_cores": self.sku.gpu_cores,
            "notes": self.sku.notes,
        }


# ---------------------------------------------------------------------------
# Detection logic
# ---------------------------------------------------------------------------

def _read_device_tree_model() -> str | None:
    """Read /proc/device-tree/model (null-terminated string on Jetson Linux)."""
    try:
        raw = Path("/proc/device-tree/model").read_bytes()
        # Jetson Linux writes a null-terminated string here
        return raw.decode("utf-8", errors="ignore").strip("\x00").strip()
    except (FileNotFoundError, OSError, PermissionError):
        return None


def _read_device_tree_compatible() -> str | None:
    """Read /proc/device-tree/compatible — fallback for chip identification."""
    try:
        raw = Path("/proc/device-tree/compatible").read_bytes()
        return raw.decode("utf-8", errors="ignore").replace("\x00", " ").strip()
    except (FileNotFoundError, OSError, PermissionError):
        return None


def _match_sku(model_lower: str) -> JetsonSKU | None:
    """Match a model string against the known SKU database.

    Iterates most-specific first so "orin nano super" matches before
    the generic "orin nano" catch-all.

    Each keyword phrase can match either as a contiguous substring OR
    as individual words all present in the model string (handles cases
    like "Orin Nano Engineering Reference Developer Kit Super" matching
    the "orin nano super" pattern).
    """
    for keywords_list, sku in _KNOWN_SKUS:
        for keywords in keywords_list:
            # Try contiguous substring first (fast path)
            if keywords in model_lower:
                return sku
            # Fallback: check if all words in the keyword phrase appear
            # anywhere in the model string (handles extra words between)
            words = keywords.split()
            if len(words) > 1 and all(w in model_lower for w in words):
                return sku
    return None


def _check_tegra_release() -> bool:
    """Check /etc/nv_tegra_release to confirm this is a Jetson."""
    try:
        result = subprocess.run(
            ["cat", "/etc/nv_tegra_release"],
            capture_output=True, text=True, timeout=2,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _check_nvpmodel() -> bool:
    """Check if nvpmodel exists — confirms Jetson even without device-tree."""
    try:
        result = subprocess.run(
            ["nvpmodel", "-q"], capture_output=True, text=True, timeout=2,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def detect_jetson() -> JetsonInfo:
    """Detect the current Jetson hardware and return a capability record.

    This is the main entry point. Call it once at startup and pass the
    JetsonInfo to modules that need hardware-aware behavior.

    Returns:
        JetsonInfo with is_jetson=False on non-Jetson systems.
        JetsonInfo with populated sku on recognized Jetson hardware.
        JetsonInfo with is_jetson=True but sku=None on unrecognized Jetson.
    """
    info = JetsonInfo()

    # Strategy 1: /proc/device-tree/model (most reliable)
    model_str = _read_device_tree_model()
    if model_str:
        info.model_string = model_str
        model_lower = model_str.lower()

        # Check if this looks like a Jetson/NVIDIA device
        if "jetson" in model_lower or "orin" in model_lower or "xavier" in model_lower or "nvidia" in model_lower:
            info.is_jetson = True
            info.sku = _match_sku(model_lower)
            return info

    # Strategy 2: /proc/device-tree/compatible (chip ID fallback)
    compat = _read_device_tree_compatible()
    if compat:
        compat_lower = compat.lower()
        if "tegra" in compat_lower or "nvidia" in compat_lower:
            info.is_jetson = True
            info.model_string = compat
            info.sku = _match_sku(compat_lower)
            return info

    # Strategy 3: /etc/nv_tegra_release
    if _check_tegra_release():
        info.is_jetson = True
        info.model_string = "(detected via nv_tegra_release)"
        return info

    # Strategy 4: nvpmodel
    if _check_nvpmodel():
        info.is_jetson = True
        info.model_string = "(detected via nvpmodel)"
        return info

    return info


# ---------------------------------------------------------------------------
# DLA gating — the whole reason this module exists
# ---------------------------------------------------------------------------

class DLANotAvailableError(RuntimeError):
    """Raised when --dla is requested on hardware that has no DLA cores.

    This is not a generic error — it's a specific, actionable message
    that names the hardware and explains what it lacks.
    """
    pass


def require_dla(hw: JetsonInfo, dla_core: int = 0) -> None:
    """Validate that DLA is available on this hardware. Raise if not.

    Call this before passing --useDLACore to trtexec.

    Args:
        hw: JetsonInfo from detect_jetson().
        dla_core: Which DLA core (0 or 1).

    Raises:
        DLANotAvailableError: If hardware has no DLA or core index is invalid.
    """
    if not hw.is_jetson:
        raise DLANotAvailableError(
            "DLA offloading requires NVIDIA Jetson hardware. "
            "This system is not a Jetson device."
        )

    if not hw.has_dla:
        raise DLANotAvailableError(
            f"DLA offloading is not available on {hw.sku_name}.\n"
            f"  Hardware: {hw.model_string}\n"
            f"  DLA cores: 0\n"
            f"\n"
            f"DLA hardware exists on: Orin NX, AGX Orin, and Thor series.\n"
            f"The Orin Nano family does not have DLA cores.\n"
            f"\n"
            f"To run inference on this device, use GPU-only mode:\n"
            f"  slowai optimize model.py --precision=fp16  (no --dla flag)"
        )

    if dla_core >= hw.dla_cores:
        raise DLANotAvailableError(
            f"{hw.sku_name} has {hw.dla_cores} DLA core(s) (index 0..{hw.dla_cores - 1}).\n"
            f"Requested DLA core {dla_core} does not exist.\n"
            f"Use --dla-core=0" + (f" or --dla-core=1" if hw.dla_cores > 1 else "") + "."
        )


# ---------------------------------------------------------------------------
# CLI display helper
# ---------------------------------------------------------------------------

def format_hardware_report(hw: JetsonInfo) -> str:
    """Format a human-readable hardware report for `slowai hardware`."""
    lines = []
    lines.append("=" * 62)
    lines.append("  slowai V9 — HARDWARE DETECTION")
    lines.append("=" * 62)
    lines.append("")

    if not hw.is_jetson:
        lines.append("  Platform: Desktop / Server (not a Jetson)")
        lines.append("  DLA: not applicable")
        lines.append("")
        lines.append("  slowai hardware detection is designed for NVIDIA Jetson.")
        lines.append("  On desktop GPUs, use `slowai capabilities` for backend info.")
        lines.append("")
        lines.append("=" * 62)
        return "\n".join(lines)

    # Jetson detected
    lines.append(f"  Detected: {hw.sku_name}")
    lines.append(f"  Model string: {hw.model_string}")
    lines.append("")

    if hw.sku:
        sku = hw.sku
        lines.append(f"  Series:          {sku.series}")
        lines.append(f"  CUDA cores:      {sku.gpu_cores}")
        lines.append(f"  SM version:      {sku.sm_version}")
        lines.append(f"  Tensor cores:    {sku.tensor_core_type}")
        lines.append(f"  Unified memory:  {sku.unified_memory_gb:.0f} GB")
        lines.append(f"  Max power:       {sku.max_power_watts} W")
        lines.append("")

        # DLA section — the critical part
        if sku.dla_cores > 0:
            lines.append(f"  DLA cores:       {sku.dla_cores}  ✓ --dla flag is SUPPORTED")
        else:
            lines.append(f"  DLA cores:       0  ✗ --dla flag will ERROR on this device")
            lines.append(f"  DLA note:        {sku.notes}")
        lines.append("")

        if sku.notes and sku.dla_cores > 0:
            lines.append(f"  Notes: {sku.notes}")
            lines.append("")
    else:
        lines.append("  SKU: not recognized (Jetson detected but model not in database)")
        lines.append(f"  Raw model: {hw.model_string}")
        lines.append("  DLA: unknown — check /sys/devices/platform/host1x/ for nvdla* nodes")
        lines.append("")

    lines.append("=" * 62)
    return "\n".join(lines)
