"""
slowai.safety — numerical validation suite for precision-critical deployments.

V7 feature: the thing that makes Tesla/SpaceX/NVIDIA say "OK, this is serious."
V8 upgrade: HARD SAFETY GATES — non-zero exit codes that block deployment.

Every remedy that changes precision (bf16, fp16, tf32, int8, tensorrt) risks
silent accuracy degradation. This module catches it BEFORE you ship.

Flow:
    1. Run workload at FP32 baseline, capture output tensors
    2. Run workload with remedy active, capture output tensors
    3. Compare: max absolute diff, max relative diff, cosine similarity
    4. Grade: SAFE / CAUTION / UNSAFE based on user-defined tolerances
    5. Attach SafetyScore to FixReport / HTML report
    6. V8: --strict mode returns non-zero exit on ANY non-SAFE grade

Exit codes (V8 hard gates):
    0 = all SAFE (deploy with confidence)
    1 = CAUTION (review before safety-critical deployment)
    2 = UNSAFE (DO NOT DEPLOY — numerical drift exceeds tolerance)
    3 = ERROR (validation could not complete)

Usage:
    from slowai.safety import validate_remedy, SafetyScore
    score = validate_remedy(workload_path, remedy)
    print(score.grade)  # "SAFE" | "CAUTION" | "UNSAFE"

    # V8: Hard gate — blocks CI/CD on UNSAFE
    report = validate_all(workload_path)
    sys.exit(report.exit_code)  # non-zero blocks deployment
"""

from __future__ import annotations

import importlib.util
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SafetyScore:
    """Numerical safety assessment for a single remedy."""
    remedy_name: str
    grade: str              # "SAFE" | "CAUTION" | "UNSAFE" | "ERROR"
    max_abs_diff: float     # max |baseline - remedied| across all outputs
    max_rel_diff: float     # max |(b-r)/b| across all outputs
    cosine_similarity: float  # min cosine sim across output pairs
    mean_abs_diff: float    # mean absolute difference
    num_outputs: int        # how many output tensors were compared
    deterministic: bool     # did two baseline runs produce identical results?
    latency_std: float      # standard deviation of wall time across runs
    details: dict = field(default_factory=dict)
    error: str | None = None

    @property
    def is_safe(self) -> bool:
        return self.grade == "SAFE"

    @property
    def is_flight_ready(self) -> bool:
        """Would this pass Tesla/SpaceX-grade validation?"""
        return (
            self.grade == "SAFE"
            and self.deterministic
            and self.max_abs_diff < 1e-5
            and self.cosine_similarity > 0.99999
        )

    def summary(self) -> str:
        if self.error:
            return f"[ERROR] {self.remedy_name}: {self.error}"
        icon = {"SAFE": "PASS", "CAUTION": "WARN", "UNSAFE": "FAIL"}.get(self.grade, "???")
        return (
            f"[{icon}] {self.remedy_name}: "
            f"max_abs={self.max_abs_diff:.2e}, "
            f"max_rel={self.max_rel_diff:.2e}, "
            f"cosine={self.cosine_similarity:.8f}, "
            f"deterministic={'YES' if self.deterministic else 'NO'}"
        )


@dataclass
class SafetyReport:
    """Complete safety validation for a workload across all remedies."""
    workload: str
    baseline_deterministic: bool
    scores: list[SafetyScore] = field(default_factory=list)

    @property
    def all_safe(self) -> bool:
        return all(s.is_safe for s in self.scores)

    @property
    def flight_ready(self) -> bool:
        return self.baseline_deterministic and all(s.is_flight_ready for s in self.scores)

    @property
    def worst_score(self) -> SafetyScore | None:
        valid = [s for s in self.scores if s.error is None]
        if not valid:
            return None
        return min(valid, key=lambda s: s.cosine_similarity)

    @property
    def has_unsafe(self) -> bool:
        return any(s.grade == "UNSAFE" for s in self.scores)

    @property
    def has_caution(self) -> bool:
        return any(s.grade == "CAUTION" for s in self.scores)

    @property
    def has_errors(self) -> bool:
        return any(s.grade == "ERROR" for s in self.scores)

    @property
    def exit_code(self) -> int:
        """V8 hard safety gate exit code.

        0 = all SAFE (green light)
        1 = CAUTION present (yellow — review required)
        2 = UNSAFE present (red — DO NOT DEPLOY)
        3 = ERROR (validation failed)
        """
        if self.has_errors:
            return 3
        if self.has_unsafe:
            return 2
        if self.has_caution:
            return 1
        return 0

    @property
    def exit_code_strict(self) -> int:
        """V8 strict mode — anything non-SAFE is a hard fail.

        0 = all SAFE
        1 = anything else (CAUTION, UNSAFE, or ERROR)
        """
        return 0 if self.all_safe and not self.has_errors else 1


def _load_module(path: str):
    """Load a workload module."""
    from pathlib import Path
    p = Path(path).resolve()
    if not p.exists():
        raise FileNotFoundError(f"Workload not found: {path}")
    spec = importlib.util.spec_from_file_location(f"_safety_{p.stem}", p)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _capture_outputs(module, transform_main=None, wrap_context=None) -> tuple[list, float]:
    """Run main() and capture all CUDA tensor outputs via hooks.

    Returns (list of flattened float32 tensors, wall_time).
    """
    import torch

    captured: list[torch.Tensor] = []
    hooks = []

    # Hook into nn.Module.forward to capture outputs
    original_forward = torch.nn.Module.__call__

    def _capturing_call(self, *args, **kwargs):
        result = original_forward(self, *args, **kwargs)
        # Only capture from top-level modules (depth check via call stack)
        if isinstance(result, torch.Tensor) and result.is_cuda:
            captured.append(result.detach().float().cpu())
        elif isinstance(result, (tuple, list)):
            for r in result:
                if isinstance(r, torch.Tensor) and r.is_cuda:
                    captured.append(r.detach().float().cpu())
        return result

    torch.nn.Module.__call__ = _capturing_call

    try:
        # Seed for reproducibility
        torch.manual_seed(42)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(42)

        main_fn = module.main
        if transform_main is not None:
            main_fn = transform_main(main_fn)

        t0 = time.perf_counter()
        if wrap_context is not None:
            with wrap_context():
                main_fn()
        else:
            main_fn()

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        wall = time.perf_counter() - t0

    finally:
        torch.nn.Module.__call__ = original_forward
        for h in hooks:
            h.remove()

    return captured, wall


def _compare_tensors(
    baseline: list,
    remedied: list,
    atol: float = 1e-5,
    rtol: float = 1e-3,
) -> dict:
    """Compare two lists of tensors. Returns comparison metrics."""
    import torch

    if not baseline or not remedied:
        return {
            "max_abs_diff": 0.0,
            "max_rel_diff": 0.0,
            "cosine_similarity": 1.0,
            "mean_abs_diff": 0.0,
            "num_compared": 0,
        }

    # Match by count (take min if different)
    n = min(len(baseline), len(remedied))
    max_abs = 0.0
    max_rel = 0.0
    min_cosine = 1.0
    total_abs = 0.0
    count = 0

    for i in range(n):
        b = baseline[i].flatten().float()
        r = remedied[i].flatten().float()

        # Truncate to same length if needed
        length = min(len(b), len(r))
        b = b[:length]
        r = r[:length]

        if length == 0:
            continue

        # Absolute difference
        abs_diff = (b - r).abs()
        current_max_abs = abs_diff.max().item()
        max_abs = max(max_abs, current_max_abs)
        total_abs += abs_diff.mean().item()

        # Relative difference (avoid div by zero)
        denom = b.abs().clamp(min=1e-8)
        rel_diff = (abs_diff / denom).max().item()
        max_rel = max(max_rel, rel_diff)

        # Cosine similarity
        if b.norm() > 0 and r.norm() > 0:
            cosine = torch.nn.functional.cosine_similarity(
                b.unsqueeze(0), r.unsqueeze(0)
            ).item()
            min_cosine = min(min_cosine, cosine)

        count += 1

    return {
        "max_abs_diff": max_abs,
        "max_rel_diff": max_rel,
        "cosine_similarity": min_cosine if count > 0 else 1.0,
        "mean_abs_diff": total_abs / count if count > 0 else 0.0,
        "num_compared": count,
    }


def _grade(
    max_abs: float,
    max_rel: float,
    cosine: float,
    atol: float = 1e-5,
    rtol: float = 1e-3,
) -> str:
    """Assign a safety grade based on numerical differences."""
    if cosine < 0.99 or max_abs > 1.0:
        return "UNSAFE"
    if cosine < 0.999 or max_abs > atol * 100 or max_rel > rtol * 10:
        return "CAUTION"
    return "SAFE"


def validate_remedy(
    workload_path: str,
    remedy,
    atol: float = 1e-5,
    rtol: float = 1e-3,
    n_runs: int = 3,
) -> SafetyScore:
    """Run a workload with and without a remedy, compare outputs.

    Args:
        workload_path: Path to workload .py file.
        remedy: A Remedy instance from slowai.remediate.
        atol: Absolute tolerance for SAFE grade.
        rtol: Relative tolerance for SAFE grade.
        n_runs: Number of runs for latency stability measurement.

    Returns:
        SafetyScore with grade and metrics.
    """
    import torch

    try:
        module = _load_module(workload_path)
        if not hasattr(module, "main"):
            return SafetyScore(
                remedy_name=remedy.name,
                grade="ERROR",
                max_abs_diff=0, max_rel_diff=0, cosine_similarity=0,
                mean_abs_diff=0, num_outputs=0, deterministic=False,
                latency_std=0, error="No main() function found",
            )

        # Baseline run 1
        baseline1, t_base1 = _capture_outputs(module)

        # Baseline run 2 (determinism check)
        baseline2, t_base2 = _capture_outputs(module)

        det_metrics = _compare_tensors(baseline1, baseline2)
        deterministic = det_metrics["max_abs_diff"] < 1e-10

        # Remedied run
        if remedy.setup:
            remedy.setup()
        try:
            remedied, t_rem = _capture_outputs(
                module,
                transform_main=remedy.transform_main,
                wrap_context=remedy.wrap_main,
            )
        finally:
            if remedy.teardown:
                try:
                    remedy.teardown()
                except Exception:
                    pass

        # Compare baseline vs remedied
        metrics = _compare_tensors(baseline1, remedied, atol=atol, rtol=rtol)

        # Latency stability (multiple runs)
        times = [t_base1, t_base2, t_rem]
        if n_runs > 3:
            for _ in range(n_runs - 3):
                _, t = _capture_outputs(module)
                times.append(t)

        import statistics
        latency_std = statistics.stdev(times) if len(times) > 1 else 0.0

        grade = _grade(
            metrics["max_abs_diff"],
            metrics["max_rel_diff"],
            metrics["cosine_similarity"],
            atol=atol,
            rtol=rtol,
        )

        return SafetyScore(
            remedy_name=remedy.name,
            grade=grade,
            max_abs_diff=metrics["max_abs_diff"],
            max_rel_diff=metrics["max_rel_diff"],
            cosine_similarity=metrics["cosine_similarity"],
            mean_abs_diff=metrics["mean_abs_diff"],
            num_outputs=metrics["num_compared"],
            deterministic=deterministic,
            latency_std=latency_std,
            details={
                "baseline_wall_s": t_base1,
                "remedied_wall_s": t_rem,
                "speedup": t_base1 / t_rem if t_rem > 0 else 0,
                "atol": atol,
                "rtol": rtol,
            },
        )

    except Exception as e:
        return SafetyScore(
            remedy_name=remedy.name,
            grade="ERROR",
            max_abs_diff=0, max_rel_diff=0, cosine_similarity=0,
            mean_abs_diff=0, num_outputs=0, deterministic=False,
            latency_std=0, error=str(e),
        )


def validate_fix_report(
    workload_path: str,
    fix_report,
    atol: float = 1e-5,
    rtol: float = 1e-3,
) -> SafetyReport:
    """Validate all remedies in a FixReport.

    Only validates remedies that produced a speedup (no point validating failures).
    """
    from slowai.remediate import REMEDIES_BY_REGIME, Remedy

    # Build name -> Remedy lookup
    all_remedies = {}
    for regime_remedies in REMEDIES_BY_REGIME.values():
        for r in regime_remedies:
            all_remedies[r.name] = r

    report = SafetyReport(
        workload=workload_path,
        baseline_deterministic=True,  # updated after first validation
    )

    for result in fix_report.results:
        if result.error or result.speedup <= 1.0:
            continue

        remedy = all_remedies.get(result.remedy_name)
        if remedy is None:
            continue

        score = validate_remedy(workload_path, remedy, atol=atol, rtol=rtol)
        report.scores.append(score)

        # Update baseline determinism from first run
        if len(report.scores) == 1:
            report.baseline_deterministic = score.deterministic

    return report
