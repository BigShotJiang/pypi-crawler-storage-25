"""
slowai.power — Jetson power management and thermal awareness.

V8 feature: the thing NVIDIA's M&A team looks for — do you use their silicon properly?

Edge devices care about Performance-per-Watt as much as Latency.
This module detects power mode, thermal throttling, and can auto-set
MAXN mode for benchmarking.

Usage:
    from slowai.power import detect_power_state, is_throttling
    state = detect_power_state()
    if is_throttling():
        print("GPU is thermal throttling — results will be unreliable")
"""

from __future__ import annotations

import subprocess
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class PowerReport:
    """Power and thermal state snapshot for a Jetson device."""

    nvpmodel_mode: str | None = None
    """e.g., "0 - MAXN" or "2 - 15W" or None on non-Jetson systems."""

    jetson_clocks_enabled: bool | None = None
    """True if jetson_clocks service is running, False if disabled, None if unavailable."""

    thermal_zones: dict[str, float] = field(default_factory=dict)
    """Thermal zone name -> temperature in Celsius. e.g., {"thermal_zone0": 45.2}"""

    gpu_freq_mhz: float | None = None
    """Current GPU clock frequency in MHz, or None if unavailable."""

    cpu_freq_mhz: float | None = None
    """Current CPU clock frequency in MHz, or None if unavailable."""

    is_system_jetson: bool = False
    """True if detected as a Jetson system, False otherwise."""

    notes: list[str] = field(default_factory=list)
    """Info/warning messages collected during detection."""

    def summary(self) -> str:
        """One-line human summary of power state."""
        if not self.is_system_jetson:
            return "Not a Jetson device"
        parts = []
        if self.nvpmodel_mode:
            parts.append(f"nvpmodel={self.nvpmodel_mode}")
        if self.jetson_clocks_enabled is not None:
            parts.append(f"jetson_clocks={'ON' if self.jetson_clocks_enabled else 'OFF'}")
        if self.gpu_freq_mhz:
            parts.append(f"GPU={self.gpu_freq_mhz:.0f}MHz")
        if self.cpu_freq_mhz:
            parts.append(f"CPU={self.cpu_freq_mhz:.0f}MHz")
        return ", ".join(parts) if parts else "Unknown Jetson state"


def detect_power_state() -> PowerReport:
    """
    Detect the current Jetson power state: nvpmodel mode, thermal zones, frequencies.

    Returns:
        PowerReport with all available fields filled. On non-Jetson systems,
        returns a report with is_system_jetson=False and sensible defaults.
    """
    report = PowerReport()

    # Check if this is a Jetson system by looking for nvpmodel
    try:
        result = subprocess.run(
            ["which", "nvpmodel"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode != 0:
            report.notes.append("nvpmodel not found; not a Jetson system")
            return report
        report.is_system_jetson = True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        report.notes.append("Could not locate nvpmodel; assuming non-Jetson")
        return report

    # Query nvpmodel mode
    try:
        result = subprocess.run(
            ["nvpmodel", "-q"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode == 0:
            mode_line = result.stdout.strip()
            report.nvpmodel_mode = mode_line
        else:
            report.notes.append(f"nvpmodel -q failed: {result.stderr.strip()}")
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        report.notes.append(f"Failed to query nvpmodel: {e}")

    # Check jetson_clocks status
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "jetson_clocks"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        report.jetson_clocks_enabled = result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        report.notes.append("Could not check jetson_clocks service status")

    # Read thermal zones
    report.thermal_zones = get_thermal_status()

    # Try to read GPU frequency
    try:
        gpu_freq_path = Path("/sys/devices/gpu.0/devfreq/tegra_gpu_emc/cur_freq")
        if gpu_freq_path.exists():
            raw = gpu_freq_path.read_bytes()
            if raw:
                freq_hz = int(raw.decode("utf-8", errors="ignore").strip())
                report.gpu_freq_mhz = freq_hz / 1_000_000  # Hz -> MHz
    except (FileNotFoundError, ValueError, OSError, TypeError, UnicodeDecodeError):
        pass  # Silently ignore if not available

    # Try to read CPU frequency (use first cpu that exists)
    try:
        for cpu_id in range(8):  # Check up to 8 CPUs
            cpu_freq_path = Path(f"/sys/devices/system/cpu/cpu{cpu_id}/cpufreq/scaling_cur_freq")
            if cpu_freq_path.exists():
                raw = cpu_freq_path.read_bytes()
                if raw:
                    freq_khz = int(raw.decode("utf-8", errors="ignore").strip())
                    report.cpu_freq_mhz = freq_khz / 1_000  # kHz -> MHz
                    break
    except (FileNotFoundError, ValueError, OSError, TypeError, UnicodeDecodeError):
        pass  # Silently ignore if not available

    return report


def get_thermal_status() -> dict[str, float]:
    """
    Read thermal zone temperatures from /sys/devices/virtual/thermal/thermal_zone*/temp.

    Returns:
        Dictionary mapping thermal zone names to temperatures in Celsius.
        Empty dict if no zones found or on non-Jetson systems.
    """
    zones = {}
    thermal_base = Path("/sys/devices/virtual/thermal")

    if not thermal_base.exists():
        return zones

    try:
        for zone_dir in sorted(thermal_base.glob("thermal_zone*")):
            if not zone_dir.is_dir():
                continue

            zone_name = zone_dir.name
            temp_file = zone_dir / "temp"

            if not temp_file.exists():
                continue

            try:
                raw_bytes = temp_file.read_bytes()
                if raw_bytes:
                    temp_raw = int(raw_bytes.decode("utf-8", errors="ignore").strip())
                    # Jetson reports in millidegrees Celsius
                    temp_c = temp_raw / 1_000
                    zones[zone_name] = temp_c
            except (ValueError, OSError, TypeError, UnicodeDecodeError):
                pass  # Skip zones that can't be read

    except OSError:
        pass  # Directory permission issues on some systems

    return zones


def is_throttling(threshold_c: float = 80.0) -> bool:
    """
    Check if any thermal zone is above the throttle threshold.

    Args:
        threshold_c: Temperature threshold in Celsius. Default 80°C is typical
                     for Jetson thermal throttling onset.

    Returns:
        True if any thermal zone exceeds the threshold, False otherwise.
        Returns False on non-Jetson systems.
    """
    zones = get_thermal_status()
    if not zones:
        return False
    return any(temp >= threshold_c for temp in zones.values())


def set_max_performance() -> bool:
    """
    Set Jetson to maximum performance mode.

    Runs: sudo nvpmodel -m 0  (MAXN mode)
    Then: sudo jetson_clocks   (lock frequencies to max)

    Returns:
        True if both commands succeeded, False otherwise.
        Note: requires sudo; will fail silently on non-Jetson systems or
              if sudo is not available.
    """
    try:
        # Set MAXN mode (mode 0)
        result = subprocess.run(
            ["sudo", "nvpmodel", "-m", "0"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False

        # Enable jetson_clocks
        result = subprocess.run(
            ["sudo", "jetson_clocks"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0

    except (subprocess.TimeoutExpired, FileNotFoundError, PermissionError):
        return False


def measure_power_efficiency(workload_path: str | Path, remedy: str | None = None) -> dict:
    """
    Run a workload and measure performance-per-watt using tegrastats if available.

    This is a V8 feature placeholder: intelligently selecting which Jetson power mode
    and clock configuration to use for a given workload and remediation strategy.

    Args:
        workload_path: Path to the workload script to execute.
        remedy: Optional description of the remediation applied (e.g., "torch.compile",
                "fp16 conversion"). Used in the returned report.

    Returns:
        Dictionary with keys:
            - "workload": str, path to workload
            - "remedy": str or None, the remedy argument
            - "tegrastats_available": bool, whether tegrastats was found
            - "power_state_before": PowerReport, state before running workload
            - "power_state_after": PowerReport, state after running workload
            - "notes": list[str], info/warning messages

        If tegrastats is unavailable, still measures before/after power state
        but cannot measure actual watts/joules.
    """
    workload_path = Path(workload_path)
    report = {
        "workload": str(workload_path),
        "remedy": remedy,
        "tegrastats_available": False,
        "power_state_before": None,
        "power_state_after": None,
        "notes": [],
    }

    # Check for tegrastats
    try:
        result = subprocess.run(
            ["which", "tegrastats"],
            capture_output=True,
            timeout=2,
        )
        report["tegrastats_available"] = result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Capture power state before
    report["power_state_before"] = detect_power_state()

    # Execute the workload
    if not workload_path.exists():
        report["notes"].append(f"Workload not found: {workload_path}")
        report["power_state_after"] = detect_power_state()
        return report

    try:
        result = subprocess.run(
            ["python", str(workload_path)],
            capture_output=True,
            text=True,
            timeout=300,  # 5 minute timeout for workload
        )
        if result.returncode != 0:
            report["notes"].append(
                f"Workload exited with code {result.returncode}: {result.stderr[:200]}"
            )
    except subprocess.TimeoutExpired:
        report["notes"].append("Workload exceeded 300s timeout")
    except FileNotFoundError:
        report["notes"].append("Python interpreter not found")

    # Capture power state after
    report["power_state_after"] = detect_power_state()

    return report
