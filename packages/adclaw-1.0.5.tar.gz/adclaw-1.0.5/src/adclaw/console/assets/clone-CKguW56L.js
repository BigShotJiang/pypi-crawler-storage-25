import{at as r}from"./index-BE_FG586.js";var a=4;function n(o){return r(o,a)}export{n as c};
