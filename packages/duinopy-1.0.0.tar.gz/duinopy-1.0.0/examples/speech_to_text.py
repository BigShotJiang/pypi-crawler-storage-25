#!/usr/bin/env rye run python

import asyncio

from duino import AsyncDuino
from duino.helpers import Microphone

# gets DUINO_API_KEY from your environment variables
Duino = AsyncDuino()


async def main() -> None:
    print("Recording for the next 10 seconds...")
    recording = await Microphone(timeout=10).record()
    print("Recording complete")
    transcription = await Duino.audio.transcriptions.create(
        model="whisper-1",
        file=recording,
    )

    print(transcription.text)


if __name__ == "__main__":
    asyncio.run(main())
