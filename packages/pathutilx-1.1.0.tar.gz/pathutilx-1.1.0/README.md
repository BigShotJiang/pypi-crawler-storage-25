# pathutilx

`pathutilx` is a small Python package that exposes readable Windows path shortcuts and path-building helpers.

## Examples

```python
from pathutilx import desktop, join

notes = join("notes.txt", base=desktop)
print(notes)
```
```python
import pathutilx as p

program_files = p.program_files
appdata_local = p.appdata.local
desktop = p.desktop
```

## Available helpers

- `build(*parts, base=None)`
- `join(*parts, base=None)`
- `windows_root()`
- common Windows locations like `desktop`, `downloads`, `documents`, `appdata`, and `temp`
