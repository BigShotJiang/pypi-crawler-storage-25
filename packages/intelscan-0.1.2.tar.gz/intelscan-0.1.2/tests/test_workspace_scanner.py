import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from intelscan import workspace_scanner as scanner


class WorkspaceScannerSecurityTests(unittest.TestCase):
    def setUp(self):
        self.workspace_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.workspace_dir.name)

    def tearDown(self):
        self.workspace_dir.cleanup()

    def test_validate_config_rejects_path_escape(self):
        cfg = scanner.Config(output_json="../outside.json")

        with self.assertRaises(ValueError):
            scanner.validate_config(self.root, cfg, watch_interval=1)

    def test_validate_config_rejects_duplicate_outputs(self):
        cfg = scanner.Config(output_json="shared.json", output_md="shared.json")

        with self.assertRaises(ValueError):
            scanner.validate_config(self.root, cfg, watch_interval=1)

    def test_validate_config_requires_positive_watch_interval(self):
        cfg = scanner.Config()

        with self.assertRaises(ValueError):
            scanner.validate_config(self.root, cfg, watch_interval=0)

    def test_validate_config_rejects_negative_max_depth(self):
        cfg = scanner.Config(max_depth=-1)

        with self.assertRaises(ValueError):
            scanner.validate_config(self.root, cfg, watch_interval=1)

    def test_collect_files_skips_symlinked_files(self):
        (self.root / "safe.txt").write_text("safe", encoding="utf-8")

        outside_dir = tempfile.TemporaryDirectory()
        self.addCleanup(outside_dir.cleanup)
        outside_file = Path(outside_dir.name) / "secret.txt"
        outside_file.write_text("secret", encoding="utf-8")

        symlink_path = self.root / "linked.txt"
        try:
            os.symlink(outside_file, symlink_path)
        except (AttributeError, NotImplementedError, OSError):
            self.skipTest("Symlinks are not available in this environment.")

        scan = scanner.collect_files(self.root, scanner.Config())

        self.assertEqual(["safe.txt"], [item["path"] for item in scan["fileInventory"]])

    def test_normalize_output_path_rejects_symlink_escape(self):
        outside_dir = tempfile.TemporaryDirectory()
        self.addCleanup(outside_dir.cleanup)
        outside_file = Path(outside_dir.name) / "outside.json"
        outside_file.write_text("{}", encoding="utf-8")

        symlink_path = self.root / "workspace.json"
        try:
            os.symlink(outside_file, symlink_path)
        except (AttributeError, NotImplementedError, OSError):
            self.skipTest("Symlinks are not available in this environment.")

        with self.assertRaises(ValueError):
            scanner.normalize_output_path(self.root, "workspace.json", "--output-json")

    def test_build_markdown_sanitizes_multiline_git_values(self):
        (self.root / "safe.txt").write_text("safe", encoding="utf-8")
        cfg = scanner.Config()
        scan = scanner.collect_files(self.root, cfg)
        manifest = scanner.build_manifest(self.root, scan, cfg)
        manifest["git"] = {
            "available": True,
            "branch": "main\n## forged heading",
            "headSummary": "abc123\n<script>alert(1)</script>",
            "changedFileCount": 1,
            "statusSummary": "",
            "statusLines": [],
            "error": "",
        }

        markdown = scanner.build_markdown(manifest, cfg)

        self.assertIn("- Branch: `main ## forged heading`", markdown)
        self.assertNotIn("\n## forged heading", markdown)
        self.assertIn("- Head summary: `abc123 <script>alert(1)</script>`", markdown)

    def test_build_manifest_includes_project_structure(self):
        (self.root / "README.md").write_text("# Demo\n", encoding="utf-8")
        (self.root / "pyproject.toml").write_text(
            "\n".join([
                "[project]",
                'name = "demo"',
                'version = "0.1.0"',
                "",
                "[project.scripts]",
                'demo = "intelscan.workspace_scanner:main"',
            ]),
            encoding="utf-8",
        )
        (self.root / "src").mkdir()
        (self.root / "src" / "intelscan").mkdir()
        (self.root / "src" / "intelscan" / "workspace_scanner.py").write_text("def main():\n    pass\n", encoding="utf-8")
        (self.root / "tests").mkdir()
        (self.root / "tests" / "test_workspace_scanner.py").write_text("def test_demo():\n    pass\n", encoding="utf-8")

        cfg = scanner.Config()
        scan = scanner.collect_files(self.root, cfg)
        manifest = scanner.build_manifest(self.root, scan, cfg)

        self.assertEqual(3, manifest["schemaVersion"])
        self.assertIn("projectStructure", manifest)
        self.assertIn("scanSettings", manifest["workspace"])
        self.assertEqual("Python", manifest["projectStructure"]["primaryStack"])
        self.assertEqual("package-oriented", manifest["projectStructure"]["architectureStyle"])
        self.assertEqual("demo", manifest["projectStructure"]["entryPoints"][0]["name"])
        self.assertEqual("src/intelscan/workspace_scanner.py", manifest["projectStructure"]["entryPoints"][0]["path"])
        self.assertIn("README.md", manifest["projectStructure"]["documentation"])
        self.assertIn("tests/test_workspace_scanner.py", manifest["projectStructure"]["tests"])

    def test_build_markdown_includes_project_structure_section(self):
        (self.root / "pyproject.toml").write_text(
            "\n".join([
                "[project]",
                'name = "demo"',
                'version = "0.1.0"',
                "",
                "[project.scripts]",
                'demo = "intelscan.workspace_scanner:main"',
            ]),
            encoding="utf-8",
        )
        (self.root / "src").mkdir()
        (self.root / "src" / "intelscan").mkdir()
        (self.root / "src" / "intelscan" / "workspace_scanner.py").write_text("def main():\n    pass\n", encoding="utf-8")

        cfg = scanner.Config()
        scan = scanner.collect_files(self.root, cfg)
        manifest = scanner.build_manifest(self.root, scan, cfg)

        markdown = scanner.build_markdown(manifest, cfg)

        self.assertIn("## Scan Settings", markdown)
        self.assertIn("- Max depth: `none`", markdown)
        self.assertIn("## Project Structure", markdown)
        self.assertIn("- Architecture summary: Python project with a package-oriented layout.", markdown)
        self.assertIn("Packaging and CLI entry points are configured in `pyproject.toml`.", markdown)
        self.assertIn("- Entry point: `demo` -> `intelscan.workspace_scanner:main` via `src/intelscan/workspace_scanner.py`", markdown)
        self.assertIn("- Component: `src/intelscan/workspace_scanner.py` - workspace scanning and manifest generation", markdown)

    def test_collect_files_respects_gitignore_by_default(self):
        (self.root / ".gitignore").write_text("ignored/\n", encoding="utf-8")
        (self.root / "visible.txt").write_text("visible", encoding="utf-8")
        (self.root / "ignored").mkdir()
        (self.root / "ignored" / "hidden.txt").write_text("hidden", encoding="utf-8")

        ignore_rules, ignore_sources = scanner.load_ignore_rules(self.root)
        cfg = scanner.Config(ignore_rules=ignore_rules, ignore_sources=ignore_sources)
        scan = scanner.collect_files(self.root, cfg)

        self.assertEqual([".gitignore", "visible.txt"], [item["path"] for item in scan["fileInventory"]])
        self.assertEqual([".gitignore"], scan["scanSettings"]["ignoreSources"])

    def test_collect_files_respects_intelscanignore_and_negation(self):
        (self.root / ".intelscanignore").write_text("*.log\n!important.log\n", encoding="utf-8")
        (self.root / "debug.log").write_text("hidden", encoding="utf-8")
        (self.root / "important.log").write_text("keep", encoding="utf-8")
        (self.root / "notes.txt").write_text("keep", encoding="utf-8")

        ignore_rules, ignore_sources = scanner.load_ignore_rules(self.root, include_gitignore=False)
        cfg = scanner.Config(ignore_rules=ignore_rules, ignore_sources=ignore_sources)
        scan = scanner.collect_files(self.root, cfg)

        self.assertEqual(
            [".intelscanignore", "important.log", "notes.txt"],
            [item["path"] for item in scan["fileInventory"]],
        )

    def test_collect_files_respects_max_depth(self):
        (self.root / "README.md").write_text("# Demo\n", encoding="utf-8")
        (self.root / "src").mkdir()
        (self.root / "src" / "top.py").write_text("print('top')\n", encoding="utf-8")
        (self.root / "src" / "pkg").mkdir()
        (self.root / "src" / "pkg" / "nested.py").write_text("print('nested')\n", encoding="utf-8")

        cfg = scanner.Config(max_depth=1)
        scan = scanner.collect_files(self.root, cfg)

        self.assertEqual(["README.md", "src/top.py"], [item["path"] for item in scan["fileInventory"]])
        self.assertEqual(1, scan["scanSettings"]["maxDepth"])

    def test_write_output_creates_only_root_manifest_files(self):
        cfg = scanner.Config()
        scanner.validate_config(self.root, cfg, watch_interval=1)
        scan = scanner.collect_files(self.root, cfg)
        manifest = scanner.build_manifest(self.root, scan, cfg)

        scanner.write_output(self.root, manifest, cfg)

        self.assertTrue((self.root / "workspace.json").is_file())
        self.assertTrue((self.root / "workspacememory.md").is_file())
        self.assertFalse((self.root / "graphify-out").exists())

    def test_write_agents_guide_creates_project_agent_file(self):
        cfg = scanner.Config()

        created = scanner.write_agents_guide(self.root, cfg)

        self.assertTrue(created)
        content = (self.root / "AGENTS.md").read_text(encoding="utf-8")
        self.assertIn("intelscan --root .", content)
        self.assertIn("workspace.json", content)
        self.assertIn("workspacememory.md", content)

    def test_write_agents_guide_does_not_overwrite_existing_file(self):
        agents_path = self.root / "AGENTS.md"
        agents_path.write_text("custom instructions", encoding="utf-8")

        created = scanner.write_agents_guide(self.root, scanner.Config())

        self.assertFalse(created)
        self.assertEqual("custom instructions", agents_path.read_text(encoding="utf-8"))

    def test_write_companion_agent_guides_creates_known_agent_files(self):
        cfg = scanner.Config()

        created_paths = scanner.write_companion_agent_guides(self.root, cfg)

        self.assertEqual(
            [
                self.root / "CLAUDE.md",
                self.root / "GEMINI.md",
                self.root / ".github" / "copilot-instructions.md",
            ],
            created_paths,
        )
        self.assertIn("AGENTS.md", (self.root / "CLAUDE.md").read_text(encoding="utf-8"))
        self.assertIn("workspace.json", (self.root / "GEMINI.md").read_text(encoding="utf-8"))
        self.assertIn("GitHub Copilot", (self.root / ".github" / "copilot-instructions.md").read_text(encoding="utf-8"))

    def test_write_companion_agent_guides_respects_custom_agents_path(self):
        cfg = scanner.Config()

        scanner.write_companion_agent_guides(self.root, cfg, agents_md="docs/AGENTS.md")

        content = (self.root / "CLAUDE.md").read_text(encoding="utf-8")
        self.assertIn("`docs/AGENTS.md`", content)

    def test_write_companion_agent_guides_do_not_overwrite_existing_files(self):
        claude_path = self.root / "CLAUDE.md"
        claude_path.write_text("existing claude instructions", encoding="utf-8")

        created_paths = scanner.write_companion_agent_guides(self.root, scanner.Config())

        self.assertEqual(
            [
                self.root / "GEMINI.md",
                self.root / ".github" / "copilot-instructions.md",
            ],
            created_paths,
        )
        self.assertEqual("existing claude instructions", claude_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
