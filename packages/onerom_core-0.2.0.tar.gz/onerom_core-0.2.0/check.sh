#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

log() {
  echo "[check:onerom_core] $*"
}

if command -v python3 >/dev/null 2>&1; then
  PYTHON=python3
elif command -v python >/dev/null 2>&1; then
  PYTHON=python
else
  echo "[check:onerom_core] python not found" >&2
  exit 1
fi

if command -v uv >/dev/null 2>&1; then
  RUNNER=(uv run --group dev)
  PYTHON_CMD=(uv run --group dev python)
else
  RUNNER=("$PYTHON" -m)
  PYTHON_CMD=("$PYTHON")
fi

log "compileall"
"${PYTHON_CMD[@]}" -m compileall onerom_core >/dev/null

log "ruff"
"${RUNNER[@]}" python -m ruff check onerom_core tests

if [[ -d tests ]]; then
  log "pytest"
  "${RUNNER[@]}" python -m pytest tests -q
else
  log "skip pytest (no tests directory)"
fi

log "OK"
