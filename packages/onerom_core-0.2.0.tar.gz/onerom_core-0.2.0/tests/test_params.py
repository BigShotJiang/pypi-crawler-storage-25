import json
from pathlib import Path

from onerom_core.execution import OneromExecution
from onerom_core.params import build_params


def test_build_params_uses_context_fallback(monkeypatch) -> None:
    monkeypatch.delenv("ONEROM_PARAMETERS", raising=False)
    monkeypatch.setenv(
        "ONEROM_CONTEXT",
        json.dumps({"parameters": {"customer_id": 42, "enabled": True}}),
    )

    params = build_params()

    assert params.customer_id == 42
    assert params.enabled is True
    assert params.as_dict() == {"customer_id": 42, "enabled": True}


def test_execution_writes_metrics_file(monkeypatch, tmp_path: Path) -> None:
    metrics_file = tmp_path / "metrics.json"
    monkeypatch.setenv("ONEROM_EXECUTION_ID", "42")
    monkeypatch.setenv("ONEROM_BOT_NAME", "demo-bot")
    monkeypatch.setenv("ONEROM_RUNNER_ID", "9")
    monkeypatch.setenv("ONEROM_PARAMETERS", json.dumps({"customer_id": 42}))
    monkeypatch.setenv("ONEROM_METRICS_FILE", str(metrics_file))
    monkeypatch.delenv("ONEROM_API_URL", raising=False)
    monkeypatch.delenv("ONEROM_RUNNER_KEY", raising=False)

    execution = OneromExecution()
    execution.add_success_item()
    execution.add_failed_item()
    execution.finish_success()

    assert json.loads(metrics_file.read_text(encoding="utf-8")) == {
        "items_processed": 1,
        "items_failed": 1,
    }
