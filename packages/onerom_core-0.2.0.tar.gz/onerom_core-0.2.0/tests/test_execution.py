import json
import logging
from pathlib import Path

from onerom_core.execution import OneromExecution
from onerom_core.logging_handler import OneromLogHandler


def _setup_execution_env(monkeypatch, metrics_file: Path) -> None:
    monkeypatch.setenv("ONEROM_EXECUTION_ID", "42")
    monkeypatch.setenv("ONEROM_BOT_NAME", "demo-bot")
    monkeypatch.setenv("ONEROM_RUNNER_ID", "9")
    monkeypatch.setenv("ONEROM_PARAMETERS", json.dumps({"customer_id": 42}))
    monkeypatch.setenv("ONEROM_METRICS_FILE", str(metrics_file))
    monkeypatch.delenv("ONEROM_API_URL", raising=False)
    monkeypatch.delenv("ONEROM_RUNNER_KEY", raising=False)


def test_attach_logger_adds_handler_and_disables_propagation(monkeypatch, tmp_path: Path) -> None:
    _setup_execution_env(monkeypatch, tmp_path / "metrics.json")

    execution = OneromExecution()
    logger = logging.getLogger("onerom-core-test")
    logger.handlers.clear()
    logger.propagate = True
    logger.setLevel(logging.NOTSET)

    execution.attach_logger(logger)

    assert any(isinstance(handler, OneromLogHandler) for handler in logger.handlers)
    assert logger.propagate is False
    assert logger.level == logging.DEBUG


def test_report_progress_writes_partial_metrics(monkeypatch, tmp_path: Path) -> None:
    metrics_file = tmp_path / "metrics.json"
    _setup_execution_env(monkeypatch, metrics_file)

    execution = OneromExecution()
    execution.report_progress(3, 10)

    assert json.loads(metrics_file.read_text(encoding="utf-8")) == {
        "items_processed": 3,
        "items_failed": 0,
    }


def test_offline_mode_when_no_execution_id(monkeypatch) -> None:
    """Sem ONEROM_EXECUTION_ID, deve funcionar em modo offline sem RuntimeError."""
    monkeypatch.delenv("ONEROM_EXECUTION_ID", raising=False)
    monkeypatch.delenv("ONEROM_API_URL", raising=False)
    monkeypatch.delenv("ONEROM_RUNNER_KEY", raising=False)
    monkeypatch.delenv("ONEROM_METRICS_FILE", raising=False)

    execution = OneromExecution()

    assert execution._offline is True
    assert execution._client.available is False
    assert execution._client.execution_id is None


def test_offline_mode_lifecycle_does_not_raise(monkeypatch) -> None:
    """Em modo offline, mark_running/finish_success/finish_failed nao lancam excecao."""
    monkeypatch.delenv("ONEROM_EXECUTION_ID", raising=False)
    monkeypatch.delenv("ONEROM_API_URL", raising=False)
    monkeypatch.delenv("ONEROM_RUNNER_KEY", raising=False)
    monkeypatch.delenv("ONEROM_METRICS_FILE", raising=False)

    execution = OneromExecution()
    execution.mark_running()
    execution.add_success_item()
    execution.add_failed_item()
    execution.finish_success()
    execution.finish_failed("erro de teste")


def test_offline_mode_run_wrapper(monkeypatch) -> None:
    """exec.run() funciona normalmente em modo offline."""
    monkeypatch.delenv("ONEROM_EXECUTION_ID", raising=False)
    monkeypatch.delenv("ONEROM_API_URL", raising=False)
    monkeypatch.delenv("ONEROM_RUNNER_KEY", raising=False)
    monkeypatch.delenv("ONEROM_METRICS_FILE", raising=False)

    called = []
    execution = OneromExecution()
    execution.run(lambda: called.append(True))

    assert called == [True]
