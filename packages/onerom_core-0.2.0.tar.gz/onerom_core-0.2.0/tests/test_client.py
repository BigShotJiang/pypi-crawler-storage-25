from onerom_core.client import _normalize_runner_agent_base


def test_normalize_runner_agent_base_accepts_runner_agent_url() -> None:
    assert (
        _normalize_runner_agent_base("http://localhost:8000/api/v1/runner-agent")
        == "http://localhost:8000/api/v1/runner-agent"
    )


def test_normalize_runner_agent_base_accepts_api_root() -> None:
    assert (
        _normalize_runner_agent_base("http://localhost:8000/api/v1")
        == "http://localhost:8000/api/v1/runner-agent"
    )


def test_normalize_runner_agent_base_accepts_host_root() -> None:
    assert (
        _normalize_runner_agent_base("http://localhost:8000")
        == "http://localhost:8000/api/v1/runner-agent"
    )
