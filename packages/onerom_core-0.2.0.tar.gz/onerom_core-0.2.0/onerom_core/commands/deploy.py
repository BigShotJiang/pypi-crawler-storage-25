"""
onerom-core deploy

Empacota o projeto corrente em bot.zip e faz deploy na plataforma ONEROM.
Replica o fluxo do .pipeline/deploy.py sem depender do script por projeto.

Fluxo:
  1. Lê pyproject.toml → nome do bot
  2. Resolve versão: --version > git tag semver no HEAD > auto-incremento
  3. Empacota em dist/bot.zip (ou --zip-path)
  4. Upsert do bot via GET /bots?name= + POST /bots
  5. Upload via POST /bots/{id}/versions (multipart)
  6. Promoção via PUT /bots/{id}/versions/{vid}/current
  7. Exibe sumário
"""

from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any, Optional

_SEMVER_RE = re.compile(r"^v?(\d+\.\d+\.\d+)$")
_EXCLUDES = {".git", "dist", "__pycache__", ".venv", "venv", ".pytest_cache"}


# ── helpers de configuração ────────────────────────────────────────────────

def _load_env() -> tuple[str, str]:
    """
    Carrega ONEROM_API_URL e ONEROM_API_TOKEN.
    Ordem de precedência: variável de ambiente > .env local.
    Aborta com mensagem acionável se alguma estiver ausente.
    """
    try:
        from dotenv import load_dotenv  # python-dotenv (opcional)
        load_dotenv(dotenv_path=Path(".env"), override=False)
    except ImportError:
        _load_dotenv_manual(Path(".env"))

    api_url = os.environ.get("ONEROM_API_URL", "").rstrip("/")
    api_token = os.environ.get("ONEROM_API_TOKEN", "")

    missing = []
    if not api_url:
        missing.append("ONEROM_API_URL")
    if not api_token:
        missing.append("ONEROM_API_TOKEN")

    if missing:
        print(f"[ERRO] Variável(eis) obrigatória(s) ausente(s): {', '.join(missing)}")
        print()
        print("  Crie um arquivo .env na raiz do projeto bot com:")
        print()
        print("    ONEROM_API_URL=https://seu-dominio.com")
        print("    ONEROM_API_TOKEN=seu-token-aqui")
        print()
        print("  O token pode ser obtido em: Painel do tenant → Configurações > API")
        sys.exit(1)

    return api_url, api_token


def _load_dotenv_manual(path: Path) -> None:
    """Parser mínimo de .env quando python-dotenv não está instalado."""
    if not path.exists():
        return
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


# ── leitura do pyproject ───────────────────────────────────────────────────

def _read_bot_name() -> str:
    toml_path = Path("pyproject.toml")
    if not toml_path.exists():
        print("[ERRO] pyproject.toml não encontrado na pasta atual.")
        print("  Execute `onerom-core deploy` dentro da raiz do projeto bot.")
        sys.exit(1)

    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            tomllib = None  # type: ignore[assignment]

    if tomllib is not None:
        with open(toml_path, "rb") as fh:
            data = tomllib.load(fh)
        name = data.get("project", {}).get("name", "")
    else:
        # Fallback: parse manual simples
        name = ""
        with open(toml_path, encoding="utf-8") as fh:
            in_project = False
            for line in fh:
                stripped = line.strip()
                if stripped == "[project]":
                    in_project = True
                    continue
                if in_project and stripped.startswith("["):
                    break
                if in_project and stripped.startswith("name"):
                    _, _, val = stripped.partition("=")
                    name = val.strip().strip('"').strip("'")
                    break

    if not name:
        print("[ERRO] Campo 'name' não encontrado em [project] do pyproject.toml.")
        sys.exit(1)
    return name


# ── resolução de versão ────────────────────────────────────────────────────

def _resolve_version(
    flag_version: Optional[str],
    bot_id: Optional[int],
    api_url: str,
    headers: dict[str, str],
    dry_run: bool,
) -> tuple[str, str]:
    """
    Retorna (versão, estratégia_usada).
    Estratégias: 'flag', 'git-tag', 'auto-increment'.
    """
    if flag_version:
        m = _SEMVER_RE.match(flag_version)
        if not m:
            print(f"[ERRO] Versão inválida: '{flag_version}'. Use o formato X.Y.Z.")
            sys.exit(1)
        return m.group(1), "flag"

    # Tenta git tag no HEAD
    git_version = _git_tag_at_head()
    if git_version:
        return git_version, "git-tag"

    # Auto-incremento: consulta última versão publicada
    if dry_run or bot_id is None:
        return "0.1.0", "auto-increment (novo bot)"

    last = _get_last_published_version(bot_id, api_url, headers)
    if last is None:
        return "0.1.0", "auto-increment (primeiro deploy)"

    parts = last.split(".")
    try:
        major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
        next_version = f"{major}.{minor}.{patch + 1}"
    except (IndexError, ValueError):
        next_version = "0.1.0"

    return next_version, f"auto-increment (anterior: {last})"


def _git_tag_at_head() -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "tag", "--points-at", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return None
        for tag in result.stdout.splitlines():
            m = _SEMVER_RE.match(tag.strip())
            if m:
                return m.group(1)
    except Exception:
        pass
    return None


def _get_last_published_version(bot_id: int, api_url: str, headers: dict[str, str]) -> Optional[str]:
    try:
        import requests
        resp = requests.get(
            f"{api_url}/api/v1/bots/{bot_id}/versions",
            headers=headers,
            timeout=10,
        )
        if resp.status_code == 200:
            versions = resp.json()
            if versions:
                # Ordena pelo campo 'created_at' descendente e pega o primeiro
                versions_sorted = sorted(versions, key=lambda v: v.get("created_at", ""), reverse=True)
                return versions_sorted[0].get("version")
    except Exception:
        pass
    return None


# ── empacotamento ──────────────────────────────────────────────────────────

def _pack_bot(zip_path: Path) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    root = Path(".")
    count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file in root.rglob("*"):
            if not file.is_file():
                continue
            rel = file.relative_to(root)
            parts = rel.parts
            if any(p in _EXCLUDES or p.startswith(".") or p.endswith(".pyc") for p in parts):
                continue
            zf.write(file, rel)
            count += 1

    size_kb = zip_path.stat().st_size / 1024
    print(f"  Empacotado: {zip_path} ({size_kb:.1f} KB, {count} arquivo(s))")


# ── chamadas HTTP ─────────────────────────────────────────────────────────

def _http_error(resp: Any, context: str) -> None:
    body = resp.text[:300] if hasattr(resp, "text") else ""
    print(f"[ERRO] {context}")
    print(f"  Status : {resp.status_code}")
    print(f"  URL    : {resp.url}")
    if body:
        print(f"  Corpo  : {body}")
    sys.exit(1)


def _upsert_bot(bot_name: str, api_url: str, headers: dict[str, str]) -> int:
    import requests

    # Busca bot existente pelo nome
    resp = requests.get(
        f"{api_url}/api/v1/bots/",
        params={"name": bot_name, "limit": 10},
        headers=headers,
        timeout=10,
    )
    if resp.status_code != 200:
        _http_error(resp, "Falha ao listar bots")

    bots = resp.json()
    for b in bots:
        if b.get("name") == bot_name:
            print(f"  Bot encontrado: id={b['id']} name={b['name']}")
            return int(b["id"])

    # Cria novo bot
    resp = requests.post(
        f"{api_url}/api/v1/bots/",
        json={"name": bot_name, "description": f"Bot {bot_name}"},
        headers=headers,
        timeout=10,
    )
    if resp.status_code not in (200, 201):
        _http_error(resp, "Falha ao criar bot")

    bot = resp.json()
    print(f"  Bot criado: id={bot['id']} name={bot['name']}")
    return int(bot["id"])


def _upload_version(
    bot_id: int,
    version: str,
    zip_path: Path,
    api_url: str,
    headers: dict[str, str],
) -> int:
    import requests

    with open(zip_path, "rb") as f:
        resp = requests.post(
            f"{api_url}/api/v1/bots/{bot_id}/versions",
            data={"version": version},
            files={"artifact": (zip_path.name, f, "application/zip")},
            headers=headers,
            timeout=120,
        )

    if resp.status_code not in (200, 201):
        _http_error(resp, "Falha ao fazer upload da versão")

    ver = resp.json()
    print(f"  Versão publicada: id={ver['id']} version={ver['version']}")
    return int(ver["id"])


def _promote_current(bot_id: int, version_id: int, api_url: str, headers: dict[str, str]) -> None:
    import requests

    resp = requests.put(
        f"{api_url}/api/v1/bots/{bot_id}/versions/{version_id}/current",
        headers=headers,
        timeout=10,
    )
    if resp.status_code not in (200, 204):
        _http_error(resp, "Falha ao promover versão como current")

    print(f"  Versão {version_id} promovida como current.")


# ── entry point ────────────────────────────────────────────────────────────

def run_deploy(args: argparse.Namespace) -> int:
    api_url, api_token = _load_env()
    headers = {"Authorization": f"Bearer {api_token}"}
    zip_path = Path(args.zip_path)
    bot_name = _read_bot_name()

    print(f"\n[onerom-core deploy] bot={bot_name}")

    if args.dry_run:
        print("  Modo: --dry-run (nenhuma chamada HTTP será feita)")
        version, strategy = _resolve_version(
            getattr(args, "version", None), None, api_url, headers, dry_run=True
        )
        print(f"  Versão que seria publicada: {version}")
        print(f"  Estratégia de resolução   : {strategy}")
        print(f"  Zip que seria gerado      : {zip_path}")
        print("\n[OK] Dry-run concluído. Configuração válida.")
        return 0

    # 1. Upsert bot
    print("\n→ Verificando bot na plataforma...")
    bot_id = _upsert_bot(bot_name, api_url, headers)

    # 2. Resolve versão (agora com bot_id para auto-increment)
    version, strategy = _resolve_version(
        getattr(args, "version", None), bot_id, api_url, headers, dry_run=False
    )
    print(f"\n→ Versão resolvida: {version} (estratégia: {strategy})")

    # 3. Empacotar
    print("\n→ Empacotando projeto...")
    _pack_bot(zip_path)

    # 4. Upload
    print(f"\n→ Fazendo upload da versão {version}...")
    version_id = _upload_version(bot_id, version, zip_path, api_url, headers)

    # 5. Promover como current
    print("\n→ Promovendo como versão current...")
    _promote_current(bot_id, version_id, api_url, headers)

    # Sumário
    print("\n" + "─" * 50)
    print("[Deploy concluído com sucesso]")
    print(f"  Bot name  : {bot_name}")
    print(f"  Bot ID    : {bot_id}")
    print(f"  Versão    : {version}")
    print(f"  Version ID: {version_id}")
    print("─" * 50 + "\n")

    return 0
