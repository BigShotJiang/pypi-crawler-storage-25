"""
onerom-core init

Baixa o template oficial da plataforma ONEROM e cria a estrutura do projeto.

Fluxo:
  1. Determina nome do projeto (--name ou nome da pasta atual)
  2. Determina diretório de destino
  3. Verifica conflito de pyproject.toml existente
  4. Baixa template_onerom.zip da VPS com barra de progresso
  5. Extrai sem sobrescrever arquivos existentes
  6. Substitui placeholder 'template_onerom' pelo nome do projeto
  7. Exibe próximos passos
"""

from __future__ import annotations

import argparse
import os
import sys
import urllib.request
import zipfile
from pathlib import Path
_DEFAULT_TEMPLATE_PATH = "/downloads/template"
_FALLBACK_TEMPLATE_URL = "https://onerom.app/downloads/template"


def _get_template_url() -> str:
    base = os.environ.get("ONEROM_API_URL", "").rstrip("/")
    if base:
        return f"{base}{_DEFAULT_TEMPLATE_PATH}"
    return _FALLBACK_TEMPLATE_URL


def _load_env_silent() -> None:
    """Carrega .env se disponível, sem obrigar presença das variáveis."""
    try:
        from dotenv import load_dotenv
        load_dotenv(dotenv_path=Path(".env"), override=False)
    except ImportError:
        env_file = Path(".env")
        if not env_file.exists():
            return
        with open(env_file, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value


def _confirm(prompt: str) -> bool:
    try:
        answer = input(f"{prompt} [s/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return answer in ("s", "sim", "y", "yes")


def _download_with_progress(url: str, dest: Path) -> None:
    """Baixa o arquivo exibindo progresso simples."""
    print(f"  Baixando: {url}")

    def _reporthook(block_num: int, block_size: int, total_size: int) -> None:
        downloaded = block_num * block_size
        if total_size > 0:
            pct = min(downloaded / total_size * 100, 100)
            kb_down = downloaded / 1024
            kb_total = total_size / 1024
            print(f"\r  Progresso: {pct:.1f}% ({kb_down:.0f}/{kb_total:.0f} KB)   ", end="", flush=True)
        else:
            kb_down = downloaded / 1024
            print(f"\r  Baixado: {kb_down:.0f} KB   ", end="", flush=True)

    try:
        urllib.request.urlretrieve(url, dest, reporthook=_reporthook)
        print()  # nova linha após progresso
    except Exception as exc:
        print()
        print(f"[ERRO] Falha ao baixar o template: {exc}")
        print(f"  URL tentada: {url}")
        print()
        print("  Verifique se ONEROM_API_URL está correta no .env ou variável de ambiente.")
        sys.exit(1)


def _extract_without_overwrite(zip_path: Path, dest_dir: Path) -> list[str]:
    """
    Extrai o zip para dest_dir sem sobrescrever arquivos existentes.
    Retorna lista de arquivos pulados por conflito.
    """
    skipped: list[str] = []
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            target = dest_dir / member.filename
            if target.exists():
                skipped.append(member.filename)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as out:
                out.write(src.read())
    return skipped


def _replace_placeholder(dest_dir: Path, project_name: str) -> None:
    """Substitui 'template_onerom' pelo nome do projeto em pyproject.toml e README.md."""
    targets = [dest_dir / "pyproject.toml", dest_dir / "README.md"]
    for path in targets:
        if not path.exists():
            continue
        content = path.read_text(encoding="utf-8")
        if "template_onerom" in content:
            path.write_text(content.replace("template_onerom", project_name), encoding="utf-8")
            print(f"  Atualizado: {path.relative_to(dest_dir.parent)}")


def run_init(args: argparse.Namespace) -> int:
    _load_env_silent()

    # Determina nome e destino
    project_name: str = getattr(args, "name", None) or Path.cwd().name
    # Sanitiza: apenas alfanumérico, hífens e underscores
    safe_name = project_name.replace("-", "_")

    if getattr(args, "name", None):
        dest_dir = Path.cwd() / project_name
    else:
        dest_dir = Path.cwd()

    print(f"\n[onerom-core init] projeto={project_name} destino={dest_dir}")

    # Conflito com pyproject.toml existente
    existing_toml = dest_dir / "pyproject.toml"
    if existing_toml.exists():
        print(f"\n  Aviso: pyproject.toml já existe em {dest_dir}")
        if not _confirm("  Deseja sobrescrever os arquivos do template?"):
            print("  Operação cancelada.")
            return 0

    dest_dir.mkdir(parents=True, exist_ok=True)

    # Download
    template_url = _get_template_url()
    tmp_zip = dest_dir / ".onerom_template_download.zip"
    try:
        print()
        _download_with_progress(template_url, tmp_zip)

        # Extração
        print(f"\n  Extraindo template em {dest_dir}...")
        skipped = _extract_without_overwrite(tmp_zip, dest_dir)

        if skipped:
            print("\n  Arquivos não sobrescritos (já existiam):")
            for f in skipped:
                print(f"    • {f}")
    finally:
        if tmp_zip.exists():
            tmp_zip.unlink()

    # Personalização
    print(f"\n  Substituindo placeholder 'template_onerom' → '{safe_name}'...")
    _replace_placeholder(dest_dir, safe_name)

    # Próximos passos
    rel = dest_dir.relative_to(Path.cwd()) if dest_dir != Path.cwd() else Path(".")
    print("\n" + "─" * 50)
    print("[Projeto inicializado com sucesso]")
    print(f"  Diretório : {dest_dir}")
    print()
    print("  Próximos passos:")
    if rel != Path("."):
        print(f"    1. cd {rel}")
        step = 2
    else:
        step = 1
    print(f"    {step}. Crie o arquivo .env com:")
    print()
    print("         ONEROM_API_URL=https://seu-dominio.com")
    print("         ONEROM_API_TOKEN=seu-token-aqui")
    print()
    print(f"    {step+1}. uv sync   (ou pip install -e .)")
    print(f"    {step+2}. Edite entrypoint.py com a lógica do seu bot")
    print(f"    {step+3}. onerom-core deploy")
    print("─" * 50 + "\n")

    return 0
