"""
CLI do SDK ONEROM.

Entry point instalado via pip: `onerom-core`
Subcomandos:
  deploy  — empacota e publica um bot na plataforma
  init    — baixa o template oficial e prepara o projeto local
"""
import argparse
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="onerom-core",
        description="SDK CLI para automações ONEROM",
    )
    subparsers = parser.add_subparsers(dest="command", metavar="<comando>")
    subparsers.required = True

    # ── deploy ─────────────────────────────────────────────────────────────
    deploy_parser = subparsers.add_parser(
        "deploy",
        help="Empacota e publica o bot na plataforma ONEROM",
        description=(
            "Empacota o projeto corrente em bot.zip e faz deploy na plataforma ONEROM.\n\n"
            "Requer .env com ONEROM_API_URL e ONEROM_API_TOKEN na raiz do projeto."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    deploy_parser.add_argument(
        "--version",
        metavar="X.Y.Z",
        help=(
            "Força a versão a ser publicada. "
            "Se omitida, usa git tag no HEAD ou auto-incremento."
        ),
    )
    deploy_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simula o deploy sem fazer chamadas HTTP. Retorna exit 0 se a configuração está correta.",
    )
    deploy_parser.add_argument(
        "--zip-path",
        metavar="CAMINHO",
        default="dist/bot.zip",
        help="Destino do zip gerado (padrão: dist/bot.zip)",
    )

    # ── init ───────────────────────────────────────────────────────────────
    init_parser = subparsers.add_parser(
        "init",
        help="Baixa o template oficial e cria a estrutura do projeto",
        description=(
            "Baixa o template oficial da plataforma ONEROM e descompacta na pasta indicada.\n\n"
            "Usa ONEROM_API_URL como base para o download (ou a URL pública padrão)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    init_parser.add_argument(
        "--name",
        metavar="NOME",
        help=(
            "Nome do projeto. Cria a pasta <NOME>/ no diretório atual. "
            "Se omitido, usa o nome da pasta atual."
        ),
    )

    args = parser.parse_args()

    if args.command == "deploy":
        from onerom_core.commands.deploy import run_deploy
        sys.exit(run_deploy(args))

    if args.command == "init":
        from onerom_core.commands.init import run_init
        sys.exit(run_init(args))
