"""
OneromLogHandler — envia logs estruturados via stdout.

O runner captura stdout linha a linha e envia ao backend.
Este handler nunca faz chamadas HTTP diretamente — apenas escreve JSON no stdout.

Formato esperado pelo runner:
{
    "ts": ISO8601,
    "execution_id": int,
    "runner_id": int,
    "bot": str,
    "source": "bot",
    "level": str,
    "message": str,
    "extra": {...}
}
"""
import json
import logging
import os
from datetime import datetime, timezone


class OneromLogHandler(logging.Handler):
    """
    Handler que escreve logs estruturados como JSON no stdout.

    O runner ONEROM captura cada linha do stdout e, se for JSON valido
    com os campos obrigatorios, reenvia ao backend como log estruturado.

    Nunca lanca excecoes — falha silenciosa para nao impactar o bot.
    """

    def emit(self, record: logging.LogRecord) -> None:
        try:
            entry = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "execution_id": int(os.environ.get("ONEROM_EXECUTION_ID", 0)),
                "runner_id": int(os.environ.get("ONEROM_RUNNER_ID", 0) or 0),
                "bot": os.environ.get("ONEROM_BOT_NAME", ""),
                "source": "bot",
                "level": record.levelname,
                "message": self.format(record),
                "extra": {
                    "logger": record.name,
                    "module": record.module,
                    "line": record.lineno,
                },
            }
            print(json.dumps(entry, ensure_ascii=False), flush=True)
        except Exception:
            pass  # nunca propaga excecao do handler
