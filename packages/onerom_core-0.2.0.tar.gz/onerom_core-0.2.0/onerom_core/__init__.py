"""
onerom-core — SDK oficial para bots ONEROM.

Uso:
    from onerom_core import OneromExecution

    exec = OneromExecution()
    print(exec.params.meu_parametro)
    exec.run(lambda: minha_funcao())
"""
from .execution import OneromExecution
from .logging_handler import OneromLogHandler

__all__ = ["OneromExecution", "OneromLogHandler"]
__version__ = "0.1.2"
