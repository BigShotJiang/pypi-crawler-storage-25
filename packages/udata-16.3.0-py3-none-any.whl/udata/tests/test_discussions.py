from datetime import UTC, datetime

import pytest
from flask import url_for
from werkzeug.test import TestResponse

from udata.core.dataservices.factories import DataserviceFactory
from udata.core.dataset.factories import DatasetFactory
from udata.core.discussions.factories import DiscussionFactory
from udata.core.discussions.metrics import update_discussions_metric  # noqa
from udata.core.discussions.models import Discussion, Message
from udata.core.discussions.notifications import DiscussionStatus
from udata.core.discussions.signals import (
    on_discussion_closed,
    on_discussion_deleted,
    on_new_discussion,
    on_new_discussion_comment,
)
from udata.core.discussions.tasks import (
    notify_discussion_closed,
    notify_new_discussion,
    notify_new_discussion_comment,
)
from udata.core.organization.factories import OrganizationFactory
from udata.core.organization.models import Organization
from udata.core.reports.constants import REASON_AUTO_SPAM
from udata.core.reports.models import Report
from udata.core.reuse.factories import ReuseFactory
from udata.core.spam.signals import on_new_potential_spam
from udata.core.user.factories import AdminFactory, UserFactory
from udata.core.user.models import User
from udata.features.notifications.models import Notification
from udata.models import Dataset, Member
from udata.tests.helpers import capture_mails
from udata.utils import faker

from .api import APITestCase
from .helpers import assert_emit, assert_not_emit


class DiscussionsTest(APITestCase):
    def get_spam_report(self, subject, subject_embed_id=None):
        return Report.objects(
            subject=subject,
            reason=REASON_AUTO_SPAM,
            dismissed_at=None,
            subject_embed_id=subject_embed_id,
        ).first()

    def has_spam_report(self, subject, subject_embed_id=None):
        return self.get_spam_report(subject, subject_embed_id) is not None

    @pytest.mark.options(SPAM_WORDS=["spam"])
    def test_new_discussion(self):
        user = self.login()
        dataset = Dataset.objects.create(title="Test dataset")

        with assert_emit(on_new_discussion):
            response = self.post(
                url_for("api.discussions"),
                {
                    "title": "test title",
                    "comment": "bla bla",
                    "subject": {
                        "class": "Dataset",
                        "id": dataset.id,
                    },
                },
            )
            self.assert201(response)

        dataset.reload()
        self.assertEqual(dataset.get_metrics()["discussions"], 1)

        discussions = Discussion.objects(subject=dataset)
        self.assertEqual(len(discussions), 1)

        discussion = discussions[0]
        self.assertEqual(discussion.user, user)
        self.assertIsNone(discussion.organization)
        self.assertEqual(len(discussion.discussion), 1)
        self.assertIsNotNone(discussion.created)
        self.assertIsNone(discussion.closed)
        self.assertIsNone(discussion.closed_by)
        self.assertEqual(discussion.title, "test title")
        self.assertFalse(self.has_spam_report(discussion))

        message = discussion.discussion[0]
        self.assertEqual(message.content, "bla bla")
        self.assertEqual(message.posted_by, user)
        self.assertIsNotNone(message.posted_on)
        self.assertFalse(self.has_spam_report(discussion, message.id))

    def test_new_discussion_on_behalf_of_org(self):
        user = self.login()
        org1 = OrganizationFactory(editors=[user])
        org2 = OrganizationFactory(editors=[user])
        other_org = OrganizationFactory()
        dataset = DatasetFactory()

        response = self.post(
            url_for("api.discussions"),
            {
                "organization": other_org.id,
                "title": "not allowed",
                "comment": "bla bla",
                "subject": {
                    "class": "Dataset",
                    "id": dataset.id,
                },
            },
        )
        self.assert400(response)

        response = self.post(
            url_for("api.discussions"),
            {
                "organization": org1.id,
                "title": "test title",
                "comment": "bla bla",
                "subject": {
                    "class": "Dataset",
                    "id": dataset.id,
                },
            },
        )
        self.assert201(response)
        assert response.json["organization"]["id"] == str(org1.id)
        assert response.json["user"]["id"] == str(user.id)
        assert response.json["discussion"][0]["posted_by_organization"]["id"] == str(org1.id)
        assert response.json["discussion"][0]["posted_by"]["id"] == str(user.id)

        response = self.post(
            url_for("api.discussion", id=response.json["id"]),
            {"organization": org2.id, "comment": "A comment"},
        )
        self.assert200(response)
        assert response.json["organization"]["id"] == str(org1.id)
        assert response.json["user"]["id"] == str(user.id)
        assert response.json["discussion"][0]["posted_by_organization"]["id"] == str(org1.id)
        assert response.json["discussion"][0]["posted_by"]["id"] == str(user.id)
        assert response.json["discussion"][1]["posted_by_organization"]["id"] == str(org2.id)
        assert response.json["discussion"][1]["posted_by"]["id"] == str(user.id)

        response = self.post(
            url_for("api.discussion", id=response.json["id"]),
            {"organization": other_org.id, "comment": "A comment"},
        )
        self.assert400(response)

    @pytest.mark.options(SPAM_WORDS=["spam"], CDATA_BASE_URL="https://data.gouv.fr")
    def test_spam_in_new_discussion_title(self):
        self.login()
        dataset = Dataset.objects.create(title="Test dataset")

        with assert_not_emit(on_new_discussion):
            discussion_id = None

            def check_signal(kwargs):
                self.assertIsNotNone(discussion_id)
                self.assertIn(
                    f"https://data.gouv.fr/datasets/{dataset.slug}/discussions?discussion_id={discussion_id}",
                    kwargs["message"],
                )

            with assert_emit(on_new_potential_spam, assertions_callback=check_signal):
                response = self.post(
                    url_for("api.discussions"),
                    {
                        "title": "spam and blah",
                        "comment": "bla bla",
                        "subject": {
                            "class": "Dataset",
                            "id": dataset.id,
                        },
                    },
                )
                self.assertStatus(response, 201)
                discussion_id = response.json["id"]

        discussions = Discussion.objects(subject=dataset)
        self.assertEqual(len(discussions), 1)

        discussion = discussions[0]
        self.assertTrue(self.has_spam_report(discussion))
        self.assertFalse(self.has_spam_report(discussion, discussion.discussion[0].id))

        # Check that the Report was created with callbacks
        report = self.get_spam_report(discussion)
        self.assertIsNotNone(report)
        self.assertEqual(report.reason, REASON_AUTO_SPAM)
        self.assertTrue("signal_new" in report.callbacks)

        # Non-admin cannot dismiss the report
        with assert_not_emit(on_new_discussion):
            response = self.patch(
                url_for("api.report", report=report),
                {"dismissed_at": datetime.now(UTC).isoformat()},
            )
            self.assertStatus(response, 403)
            self.assertTrue(self.has_spam_report(discussion.reload()))

        # Admin can list auto-spam reports
        self.login(AdminFactory())
        response = self.get(url_for("api.reports", reason=REASON_AUTO_SPAM, handled=False))
        self.assertStatus(response, 200)
        self.assertEqual(response.json["total"], 1)
        self.assertEqual(response.json["data"][0]["id"], str(report.id))

        # Admin can dismiss the report (mark as not spam) which executes callbacks
        with assert_emit(on_new_discussion):
            response = self.patch(
                url_for("api.report", report=report),
                {"dismissed_at": datetime.now(UTC).isoformat()},
            )
            self.assertStatus(response, 200)
            self.assertFalse(self.has_spam_report(discussion.reload()))

        # Adding a new comment / modifying the not spam discussion
        response = self.post(
            url_for("api.discussion", id=discussion.id), {"comment": "A new normal comment"}
        )
        self.assertStatus(response, 200)
        self.assertFalse(self.has_spam_report(discussion.reload()))

    @pytest.mark.options(SPAM_WORDS=["spam"])
    def test_spam_by_owner(self):
        user = self.login()
        dataset = Dataset.objects.create(title="Test dataset", owner=user)

        with assert_not_emit(on_new_potential_spam):
            response = self.post(
                url_for("api.discussions"),
                {
                    "title": "spam and blah",
                    "comment": "bla bla",
                    "subject": {
                        "class": "Dataset",
                        "id": dataset.id,
                    },
                },
            )
            self.assertStatus(response, 201)

        with assert_not_emit(on_new_potential_spam):
            response = self.post(
                url_for("api.discussion", id=response.json["id"]),
                {"comment": "A comment with spam by owner"},
            )
            self.assertStatus(response, 200)

    @pytest.mark.options(SPAM_WORDS=["spam"])
    def test_spam_in_new_discussion_comment(self):
        self.login()
        dataset = Dataset.objects.create(title="Test dataset")

        with assert_not_emit(on_new_discussion):
            with assert_emit(on_new_potential_spam):
                response = self.post(
                    url_for("api.discussions"),
                    {
                        "title": "title and blah",
                        "comment": "bla bla spam",
                        "subject": {
                            "class": "Dataset",
                            "id": dataset.id,
                        },
                    },
                )
                self.assertStatus(response, 201)

        discussions = Discussion.objects(subject=dataset)
        self.assertEqual(len(discussions), 1)

        discussion = discussions[0]
        # Spam is on the discussion (first comment content is checked at discussion level)
        self.assertTrue(self.has_spam_report(discussion))
        # The message itself doesn't have its own spam report
        self.assertFalse(self.has_spam_report(discussion, discussion.discussion[0].id))

    def test_new_discussion_missing_comment(self):
        self.login()
        dataset = Dataset.objects.create(title="Test dataset")

        response = self.post(
            url_for("api.discussions"),
            {
                "title": "test title",
                "subject": {
                    "class": "Dataset",
                    "id": dataset.id,
                },
            },
        )
        self.assertStatus(response, 400)

    def test_new_discussion_missing_title(self):
        self.login()
        dataset = Dataset.objects.create(title="Test dataset")

        response = self.post(
            url_for("api.discussions"),
            {
                "comment": "bla bla",
                "subject": {
                    "class": "Dataset",
                    "id": dataset.id,
                },
            },
        )
        self.assertStatus(response, 400)

    def test_new_discussion_missing_subject(self):
        self.login()
        response = self.post(
            url_for("api.discussions"), {"title": "test title", "comment": "bla bla"}
        )
        self.assertStatus(response, 400)

    def test_new_discussion_with_extras(self):
        user = self.login()
        dataset = Dataset.objects.create(title="Test dataset", extras={"key": "value"})

        with assert_emit(on_new_discussion):
            response = self.post(
                url_for("api.discussions"),
                {
                    "title": "test title",
                    "comment": "bla bla",
                    "subject": {
                        "class": "Dataset",
                        "id": dataset.id,
                    },
                    "extras": {"key": "value"},
                },
            )
        self.assert201(response)

        discussions = Discussion.objects(subject=dataset)
        self.assertEqual(len(discussions), 1)

        discussion = discussions[0]
        self.assertEqual(discussion.user, user)
        self.assertEqual(len(discussion.discussion), 1)
        self.assertEqual(discussion.title, "test title")
        self.assertEqual(discussion.extras, {"key": "value"})

        message = discussion.discussion[0]
        self.assertEqual(message.content, "bla bla")
        self.assertEqual(message.posted_by, user)
        self.assertIsNotNone(message.posted_on)

    def test_list_discussions(self):
        dataset = Dataset.objects.create(title="Test dataset")
        open_discussions = []
        closed_discussions = []
        for i in range(2):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
            )
            open_discussions.append(discussion)
        for i in range(3):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
                closed=datetime.now(UTC),
                closed_by=user,
            )
            closed_discussions.append(discussion)

        response = self.get(url_for("api.discussions"))
        self.assert200(response)

        self.assertEqual(len(response.json["data"]), len(open_discussions + closed_discussions))

    def test_list_discussions_closed_filter(self):
        dataset = Dataset.objects.create(title="Test dataset")
        open_discussions = []
        closed_discussions = []
        for i in range(2):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
            )
            open_discussions.append(discussion)
        for i in range(3):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
                closed=datetime.now(UTC),
                closed_by=user,
            )
            closed_discussions.append(discussion)

        response = self.get(url_for("api.discussions", closed=True))
        self.assert200(response)
        self.assertEqual(len(response.json["data"]), len(closed_discussions))
        for discussion in response.json["data"]:
            self.assertIsNotNone(discussion["closed"])

    def test_list_discussions_for(self):
        dataset = DatasetFactory()
        discussions = []
        for i in range(3):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
            )
            discussions.append(discussion)
        user = UserFactory()
        message = Message(content=faker.sentence(), posted_by=user)
        Discussion.objects.create(
            subject=DatasetFactory(),
            user=user,
            title="test discussion {}".format(i),
            discussion=[message],
        )

        kwargs = {"for": str(dataset.id)}
        response = self.get(url_for("api.discussions", **kwargs))
        self.assert200(response)

        self.assertEqual(len(response.json["data"]), len(discussions))

    def test_list_discussions_search(self):
        user = self.login()
        dataset = DatasetFactory()

        discussion_a = DiscussionFactory(
            user=user,
            subject=dataset,
            title="discussion a",
            discussion=[
                Message(posted_by=user, content="another message"),
                Message(posted_by=user, content="a message with something"),
            ],
        )
        discussion_b = DiscussionFactory(
            user=user,
            subject=dataset,
            title="something in title",
            discussion=[
                Message(posted_by=user, content="another message"),
                Message(posted_by=user, content="there is a problem"),
            ],
        )
        DiscussionFactory(
            user=user,
            subject=dataset,
            title="discussion c",
            discussion=[
                Message(posted_by=user, content="some text"),
                Message(posted_by=user, content="and another"),
            ],
        )

        response = self.get(url_for("api.discussions", q="something"))
        self.assert200(response)

        self.assertEqual(len(response.json["data"]), 2)
        self.assertEqual(discussion_b.title, response.json["data"][0]["title"])
        self.assertEqual(discussion_a.title, response.json["data"][1]["title"])

    def assertIdIn(self, json_data: dict, id_: str) -> None:
        for item in json_data:
            if item["id"] == id_:
                return
        self.fail(f"id {id_} not in {json_data}")

    def test_list_discussions_org_does_not_exist(self) -> None:
        response: TestResponse = self.get(url_for("api.discussions", org="bad org id"))
        self.assert404(response)

    def test_list_discussions_org(self) -> None:
        organization: Organization = OrganizationFactory()
        user: User = UserFactory()
        _discussion: Discussion = DiscussionFactory(user=user)
        dataset = DatasetFactory(organization=organization)
        dataservice = DataserviceFactory(organization=organization)
        reuse = ReuseFactory(organization=organization)
        discussion_for_dataset: Discussion = DiscussionFactory(subject=dataset, user=user)
        discussion_for_dataservice: Discussion = DiscussionFactory(subject=dataservice, user=user)
        discussion_for_reuse: Discussion = DiscussionFactory(subject=reuse, user=user)

        response: TestResponse = self.get(url_for("api.discussions", org=organization.id))
        self.assert200(response)
        self.assertEqual(len(response.json["data"]), 3)
        self.assertIdIn(response.json["data"], str(discussion_for_dataset.id))
        self.assertIdIn(response.json["data"], str(discussion_for_dataservice.id))
        self.assertIdIn(response.json["data"], str(discussion_for_reuse.id))

    def test_list_discussions_sort(self) -> None:
        user: User = UserFactory()
        dataset = DatasetFactory()

        sorting_keys_dict: dict = {
            "title": ["aaa", "bbb"],
            "created": ["2023-12-12", "2024-01-01"],
            "closed": ["2023-12-12", "2024-01-01"],
        }
        for sorting_key, values in sorting_keys_dict.items():
            discussion1: Discussion = DiscussionFactory(
                subject=dataset, user=user, **{sorting_key: values[0]}
            )
            discussion2: Discussion = DiscussionFactory(
                subject=dataset, user=user, **{sorting_key: values[1]}
            )

            response: TestResponse = self.get(url_for("api.discussions", sort=sorting_key))
            self.assert200(response)
            self.assertEqual(len(response.json["data"]), 2)
            self.assertEqual(response.json["data"][0]["id"], str(discussion1.id))
            self.assertEqual(response.json["data"][1]["id"], str(discussion2.id))

            # Reverse sort
            response: TestResponse = self.get(url_for("api.discussions", sort="-" + sorting_key))
            self.assert200(response)
            self.assertEqual(len(response.json["data"]), 2)
            self.assertEqual(response.json["data"][0]["id"], str(discussion2.id))
            self.assertEqual(response.json["data"][1]["id"], str(discussion1.id))

            # Clean slate
            Discussion.objects.delete()

    def test_list_discussions_user(self):
        dataset = DatasetFactory()
        discussions = []
        for i in range(3):
            user = UserFactory()
            message = Message(content=faker.sentence(), posted_by=user)
            discussion = Discussion.objects.create(
                subject=dataset,
                user=user,
                title="test discussion {}".format(i),
                discussion=[message],
            )
            discussions.append(discussion)
        user = UserFactory()
        message = Message(content=faker.sentence(), posted_by=user)
        Discussion.objects.create(
            subject=DatasetFactory(),
            user=user,
            title="test discussion {}".format(i + 1),
            discussion=[message],
        )

        kwargs = {"user": str(user.id)}
        response = self.get(url_for("api.discussions", **kwargs))
        self.assert200(response)

        self.assertEqual(len(response.json["data"]), 1)
        self.assertEqual(response.json["data"][0]["user"]["id"], str(user.id))

    def test_get_discussion(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )

        response = self.get(url_for("api.discussion", **{"id": discussion.id}))
        self.assert200(response)

        data = response.json

        self.assertEqual(data["subject"]["class"], "Dataset")
        self.assertEqual(data["subject"]["id"], str(dataset.id))
        self.assertEqual(data["user"]["id"], str(user.id))
        self.assertEqual(data["title"], "test discussion")
        self.assertIsNotNone(data["created"])
        self.assertEqual(len(data["discussion"]), 1)
        self.assertEqual(data["discussion"][0]["content"], "bla bla")
        self.assertEqual(data["discussion"][0]["posted_by"]["id"], str(user.id))
        self.assertIsNotNone(data["discussion"][0]["posted_on"])

    @pytest.mark.options(SPAM_WORDS=["spam"])
    def test_add_comment_to_discussion(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.

        poster = self.login()
        with assert_emit(on_new_discussion_comment):
            response = self.post(
                url_for("api.discussion", id=discussion.id), {"comment": "new bla bla"}
            )
        self.assert200(response)

        dataset.reload()
        discussion.reload()
        self.assertEqual(dataset.get_metrics()["discussions"], 1)

        data = response.json

        self.assertEqual(data["subject"]["class"], "Dataset")
        self.assertEqual(data["subject"]["id"], str(dataset.id))
        self.assertEqual(data["user"]["id"], str(user.id))
        self.assertEqual(data["title"], "test discussion")
        self.assertIsNotNone(data["created"])
        self.assertIsNone(data["closed"])
        self.assertIsNone(data["closed_by"])
        self.assertEqual(len(data["discussion"]), 2)
        self.assertEqual(data["discussion"][1]["content"], "new bla bla")
        self.assertEqual(data["discussion"][1]["posted_by"]["id"], str(poster.id))
        self.assertIsNotNone(data["discussion"][1]["posted_on"])
        discussion.reload()
        self.assertFalse(self.has_spam_report(discussion, discussion.discussion[1].id))

    @pytest.mark.options(SPAM_WORDS=["spam"])
    def test_add_spam_comment_to_discussion(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.

        self.login()
        with assert_not_emit(on_new_discussion_comment):

            def check_signal(kwargs):
                self.assertIn(discussion.url_for(), kwargs["message"])

            with assert_emit(on_new_potential_spam, assertions_callback=check_signal):
                response = self.post(
                    url_for("api.discussion", id=discussion.id), {"comment": "spam new bla bla"}
                )
                self.assert200(response)

        discussion.reload()
        spam_message = discussion.discussion[1]
        self.assertFalse(self.has_spam_report(discussion))
        self.assertTrue(self.has_spam_report(discussion, spam_message.id))

        # Check that the Report was created with callbacks on the message
        report = self.get_spam_report(discussion, spam_message.id)
        self.assertIsNotNone(report)
        self.assertEqual(report.reason, REASON_AUTO_SPAM)
        self.assertEqual(report.subject_embed_id, spam_message.id)
        self.assertTrue("signal_comment" in report.callbacks)

        # Admin can list auto-spam reports
        self.login(AdminFactory())
        response = self.get(url_for("api.reports", reason=REASON_AUTO_SPAM, handled=False))
        self.assertStatus(response, 200)
        self.assertEqual(response.json["total"], 1)

        # Admin can dismiss the report (mark as not spam) which executes callbacks
        with assert_emit(on_new_discussion_comment):
            response = self.patch(
                url_for("api.report", report=report),
                {"dismissed_at": datetime.now(UTC).isoformat()},
            )
            self.assertStatus(response, 200)
            discussion.reload()
            self.assertFalse(self.has_spam_report(discussion, spam_message.id))

        response = self.post(
            url_for("api.discussion", id=discussion.id), {"comment": "New comment"}
        )
        self.assert200(response)

        # The spam comment marked as no spam is still a no spam
        discussion.reload()
        self.assertFalse(self.has_spam_report(discussion, spam_message.id))

    def test_close_discussion(self):
        owner = self.login()
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=owner)
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.

        with assert_emit(on_discussion_closed):
            response = self.post(
                url_for("api.discussion", id=discussion.id),
                {"comment": "close bla bla", "close": True},
            )
            self.assert200(response)

        dataset.reload()
        self.assertEqual(dataset.get_metrics()["discussions"], 1)
        self.assertEqual(dataset.get_metrics()["discussions_open"], 0)

        data = response.json

        self.assertEqual(data["subject"]["class"], "Dataset")
        self.assertEqual(data["subject"]["id"], str(dataset.id))
        self.assertEqual(data["user"]["id"], str(user.id))
        self.assertEqual(data["title"], "test discussion")
        self.assertIsNotNone(data["created"])
        self.assertIsNotNone(data["closed"])
        self.assertEqual(data["closed_by"]["id"], str(owner.id))
        self.assertEqual(len(data["discussion"]), 2)
        self.assertEqual(data["discussion"][1]["content"], "close bla bla")
        self.assertEqual(data["discussion"][1]["posted_by"]["id"], str(owner.id))
        self.assertIsNotNone(data["discussion"][1]["posted_on"])

        # Can't add anymore comments
        response = self.post(
            url_for("api.discussion", id=discussion.id), {"comment": "can't comment"}
        )
        self.assert403(response)

    def test_close_discussion_without_message(self):
        owner = self.login()
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=owner)
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )

        with assert_emit(on_discussion_closed):
            response = self.post(
                url_for("api.discussion", id=discussion.id),
                {"close": True},
            )
            self.assert200(response)

    def test_close_discussion_permissions(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.

        self.login()
        response = self.post(
            url_for("api.discussion", id=discussion.id), {"comment": "close bla bla", "close": True}
        )
        self.assert403(response)

        dataset.reload()
        # Metrics unchanged after attempt to close the discussion.
        self.assertEqual(dataset.get_metrics()["discussions"], 1)

    def test_delete_discussion(self):
        owner = self.login(AdminFactory())
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=owner)
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.
        self.assertEqual(Discussion.objects(subject=dataset).count(), 1)

        with assert_emit(on_discussion_deleted):
            response = self.delete(url_for("api.discussion", id=discussion.id))
        self.assertStatus(response, 204)

        dataset.reload()
        self.assertEqual(dataset.get_metrics()["discussions"], 0)
        self.assertEqual(Discussion.objects(subject=dataset).count(), 0)

    def test_discussion_permissions(self):
        admin = AdminFactory()
        subject_owner = UserFactory()
        user1 = UserFactory()
        user2 = UserFactory()
        user3 = UserFactory()
        org = OrganizationFactory(
            members=[Member(user=user1, role="editor"), Member(user=user2, role="editor")]
        )
        dataset = Dataset.objects.create(title="Test dataset", owner=subject_owner)
        message = Message(content="bla bla", posted_by=user1)
        message2 = Message(content="bla bla bla", posted_by=user2)
        message3 = Message(content="bla bla bla", posted_by=user2, posted_by_organization=org)
        discussion = Discussion.objects.create(
            subject=dataset,
            user=user1,
            title="test discussion",
            discussion=[message, message2, message3],
        )

        self.login(admin)
        response = self.get(url_for("api.discussion", id=discussion.id))
        assert response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert response.json["permissions"]["delete"]
        assert response.json["discussion"][0]["permissions"]["edit"]
        assert response.json["discussion"][0]["permissions"]["delete"]
        assert response.json["discussion"][1]["permissions"]["edit"]
        assert response.json["discussion"][1]["permissions"]["delete"]
        assert response.json["discussion"][2]["permissions"]["edit"]
        assert response.json["discussion"][2]["permissions"]["delete"]

        self.login(subject_owner)
        response = self.get(url_for("api.discussion", id=discussion.id))
        assert not response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert not response.json["permissions"]["delete"]
        assert not response.json["discussion"][0]["permissions"]["edit"]
        assert not response.json["discussion"][0]["permissions"]["delete"]
        assert not response.json["discussion"][1]["permissions"]["edit"]
        assert not response.json["discussion"][1]["permissions"]["delete"]
        assert not response.json["discussion"][2]["permissions"]["edit"]
        assert not response.json["discussion"][2]["permissions"]["delete"]

        self.login(user1)
        response = self.get(url_for("api.discussion", id=discussion.id))
        assert response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert response.json["permissions"]["delete"]
        assert response.json["discussion"][0]["permissions"]["edit"]
        assert response.json["discussion"][0]["permissions"]["delete"]
        assert not response.json["discussion"][1]["permissions"]["edit"]
        assert not response.json["discussion"][1]["permissions"]["delete"]
        assert response.json["discussion"][2]["permissions"]["edit"]
        assert response.json["discussion"][2]["permissions"]["delete"]

        self.login(user2)
        response = self.get(url_for("api.discussion", id=discussion.id))
        assert not response.json["permissions"]["edit"]
        assert not response.json["permissions"]["close"]
        assert not response.json["permissions"]["delete"]
        assert not response.json["discussion"][0]["permissions"]["edit"]
        assert not response.json["discussion"][0]["permissions"]["delete"]
        assert response.json["discussion"][1]["permissions"]["edit"]
        assert response.json["discussion"][1]["permissions"]["delete"]
        assert response.json["discussion"][2]["permissions"]["edit"]
        assert response.json["discussion"][2]["permissions"]["delete"]

        self.login(user3)
        response = self.get(url_for("api.discussion", id=discussion.id))
        assert not response.json["permissions"]["edit"]
        assert not response.json["permissions"]["close"]
        assert not response.json["permissions"]["delete"]
        assert not response.json["discussion"][0]["permissions"]["edit"]
        assert not response.json["discussion"][0]["permissions"]["delete"]
        assert not response.json["discussion"][1]["permissions"]["edit"]
        assert not response.json["discussion"][1]["permissions"]["delete"]
        assert not response.json["discussion"][2]["permissions"]["edit"]
        assert not response.json["discussion"][2]["permissions"]["delete"]

        discussion_by_org = Discussion.objects.create(
            subject=dataset,
            user=user2,
            organization=org,
            title="test discussion",
            discussion=[message3],
        )

        self.login(admin)
        response = self.get(url_for("api.discussion", id=discussion_by_org.id))
        assert response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert response.json["permissions"]["delete"]
        assert response.json["discussion"][0]["permissions"]["edit"]
        assert response.json["discussion"][0]["permissions"]["delete"]

        self.login(subject_owner)
        response = self.get(url_for("api.discussion", id=discussion_by_org.id))
        assert not response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert not response.json["permissions"]["delete"]
        assert not response.json["discussion"][0]["permissions"]["edit"]
        assert not response.json["discussion"][0]["permissions"]["delete"]

        self.login(user1)
        response = self.get(url_for("api.discussion", id=discussion_by_org.id))
        assert response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert response.json["permissions"]["delete"]
        assert response.json["discussion"][0]["permissions"]["edit"]
        assert response.json["discussion"][0]["permissions"]["delete"]

        self.login(user2)
        response = self.get(url_for("api.discussion", id=discussion_by_org.id))
        assert response.json["permissions"]["edit"]
        assert response.json["permissions"]["close"]
        assert response.json["permissions"]["delete"]
        assert response.json["discussion"][0]["permissions"]["edit"]
        assert response.json["discussion"][0]["permissions"]["delete"]

        self.login(user3)
        response = self.get(url_for("api.discussion", id=discussion_by_org.id))
        assert not response.json["permissions"]["edit"]
        assert not response.json["permissions"]["close"]
        assert not response.json["permissions"]["delete"]
        assert not response.json["discussion"][0]["permissions"]["edit"]
        assert not response.json["discussion"][0]["permissions"]["delete"]

    def test_edit_discussion_title(self):
        admin = self.login(AdminFactory())
        user1 = UserFactory()
        user2 = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=user1)
        message = Message(content="bla bla", posted_by=user1)
        message2 = Message(content="bla bla bla", posted_by=user2)
        discussion = Discussion.objects.create(
            subject=dataset, user=user1, title="test discussion", discussion=[message, message2]
        )
        self.assertEqual(len(discussion.discussion), 2)

        response = self.put(url_for("api.discussion", id=discussion.id), {"title": "new title"})
        self.assertStatus(response, 200)
        discussion.reload()
        assert discussion.title == "new title"

        self.login(admin)
        response = self.put(
            url_for("api.discussion", id=discussion.id),
            {"title": "edit by admin"},
        )
        self.assertStatus(response, 200)
        discussion.reload()
        assert discussion.title == "edit by admin"

        self.login(user2)
        response = self.put(
            url_for("api.discussion", id=discussion.id),
            {"title": "not allowed"},
        )
        self.assertStatus(response, 403)

    def test_edit_discussion_comment(self):
        admin = self.login(AdminFactory())
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=admin)
        message = Message(content="bla bla", posted_by=user)
        message2 = Message(content="bla bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message, message2]
        )
        self.assertEqual(len(discussion.discussion), 2)

        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=0), {"comment": "new body"}
        )
        self.assertStatus(response, 200)
        discussion.reload()
        assert discussion.discussion[0].content == "new body"

        self.login(admin)
        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=1),
            {"comment": "edit by admin"},
        )
        self.assertStatus(response, 200)
        discussion.reload()
        assert discussion.discussion[1].content == "edit by admin"

        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=3),
            {"comment": "overflow edit"},
        )
        self.assertStatus(response, 404)

        self.login(UserFactory())
        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=0),
            {"comment": "other user"},
        )
        self.assertStatus(response, 403)

    def test_edit_discussion_comment_by_uuid(self):
        admin = self.login(AdminFactory())
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=admin)
        message = Message(content="bla bla", posted_by=user)
        message2 = Message(content="bla bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message, message2]
        )

        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=str(message.id)),
            {"comment": "edited by uuid"},
        )
        self.assertStatus(response, 200)
        discussion.reload()
        self.assertEqual(discussion.discussion[0].content, "edited by uuid")

        response = self.put(
            url_for("api.discussion_comment", id=discussion.id, cidx=str(message2.id)),
            {"comment": "second edited by uuid"},
        )
        self.assertStatus(response, 200)
        discussion.reload()
        self.assertEqual(discussion.discussion[1].content, "second edited by uuid")

        response = self.put(
            url_for(
                "api.discussion_comment",
                id=discussion.id,
                cidx="00000000-0000-0000-0000-000000000000",
            ),
            {"comment": "unknown uuid"},
        )
        self.assertStatus(response, 404)

    def test_delete_discussion_comment(self):
        owner = self.login(AdminFactory())
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=owner)
        message = Message(content="bla bla", posted_by=user)
        message2 = Message(content="bla bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message, message2]
        )
        self.assertEqual(len(discussion.discussion), 2)

        # test first comment deletion
        response = self.delete(url_for("api.discussion_comment", id=discussion.id, cidx=0))
        self.assertStatus(response, 400)

        # test effective deletion
        response = self.delete(url_for("api.discussion_comment", id=discussion.id, cidx=1))
        self.assertStatus(response, 204)
        discussion.reload()
        self.assertEqual(len(discussion.discussion), 1)
        self.assertEqual(discussion.discussion[0].content, "bla bla")

        # delete again to test list overflow
        response = self.delete(url_for("api.discussion_comment", id=discussion.id, cidx=3))
        self.assertStatus(response, 404)

        # delete again to test last comment deletion
        response = self.delete(url_for("api.discussion_comment", id=discussion.id, cidx=0))
        self.assertStatus(response, 400)

    def test_delete_discussion_comment_by_uuid(self):
        owner = self.login(AdminFactory())
        user = UserFactory()
        dataset = Dataset.objects.create(title="Test dataset", owner=owner)
        message = Message(content="bla bla", posted_by=user)
        message2 = Message(content="bla bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message, message2]
        )
        self.assertEqual(len(discussion.discussion), 2)

        # delete first comment by UUID should fail
        response = self.delete(
            url_for("api.discussion_comment", id=discussion.id, cidx=str(message.id))
        )
        self.assertStatus(response, 400)

        # delete second comment by UUID
        response = self.delete(
            url_for("api.discussion_comment", id=discussion.id, cidx=str(message2.id))
        )
        self.assertStatus(response, 204)
        discussion.reload()
        self.assertEqual(len(discussion.discussion), 1)
        self.assertEqual(discussion.discussion[0].content, "bla bla")

        # delete with unknown UUID
        response = self.delete(
            url_for(
                "api.discussion_comment",
                id=discussion.id,
                cidx="00000000-0000-0000-0000-000000000000",
            )
        )
        self.assertStatus(response, 404)

    def test_delete_discussion_permissions(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message]
        )
        on_new_discussion.send(discussion)  # Updating metrics.

        self.login()
        response = self.delete(url_for("api.discussion", id=discussion.id))
        self.assert403(response)

        dataset.reload()
        # Metrics unchanged after attempt to delete the discussion.
        self.assertEqual(dataset.get_metrics()["discussions"], 1)

    def test_delete_discussion_comment_permissions(self):
        dataset = Dataset.objects.create(title="Test dataset")
        user = UserFactory()
        message = Message(content="bla bla", posted_by=user)
        message2 = Message(content="bla bla bla", posted_by=user)
        discussion = Discussion.objects.create(
            subject=dataset, user=user, title="test discussion", discussion=[message, message2]
        )
        self.login()
        response = self.delete(url_for("api.discussion_comment", id=discussion.id, cidx=1))
        self.assert403(response)


class NotifyDiscussionsTest(APITestCase):
    def test_new_discussion_mail(self):
        user = UserFactory()
        owner = UserFactory()
        message = Message(content=faker.sentence(), posted_by=user)
        discussion = Discussion.objects.create(
            subject=DatasetFactory(owner=owner),
            user=user,
            title=faker.sentence(),
            discussion=[message],
        )

        with capture_mails() as mails:
            notify_new_discussion(discussion.id)

        # Should have sent one mail to the owner
        self.assertEqual(len(mails), 1)
        self.assertEqual(mails[0].recipients[0], owner.email)

        # Verify notification was created for the owner
        notifications = Notification.objects(user=owner)
        self.assertEqual(len(notifications), 1)
        self.assertEqual(notifications[0].details.status, DiscussionStatus.NEW_DISCUSSION)

    def test_new_discussion_comment_mail(self):
        owner = UserFactory()
        poster = UserFactory()
        commenter = UserFactory()
        message = Message(content=faker.sentence(), posted_by=poster)
        second_message = Message(content=faker.sentence(), posted_by=owner)
        new_message = Message(content=faker.sentence(), posted_by=commenter)
        discussion = Discussion.objects.create(
            subject=DatasetFactory(owner=owner),
            user=poster,
            title=faker.sentence(),
            discussion=[message, second_message, new_message],
        )

        with capture_mails() as mails:
            notify_new_discussion_comment(discussion.id, message=len(discussion.discussion) - 1)

        # Should have sent one mail to the owner and the other participants
        # and no mail to the commenter. The owner should appear only once in the recipients
        # even if he is in both the discussion and the owner of the dataset.
        expected_recipients = (owner.email, poster.email)
        self.assertEqual(len(mails), len(expected_recipients))
        for mail in mails:
            self.assertIn(mail.recipients[0], expected_recipients)
            self.assertNotIn(commenter.email, mail.recipients)

        # Verify notification was created for the owner
        notifications = Notification.objects(user=owner)
        self.assertEqual(len(notifications), 1)
        self.assertEqual(notifications[0].details.status, DiscussionStatus.NEW_COMMENT)
        self.assertEqual(notifications[0].details.message_id, new_message.id)

    def test_new_discussion_comment_handle_previous_notifications(self):
        owner = UserFactory()
        poster = UserFactory()
        commenter = UserFactory()
        message = Message(content=faker.sentence(), posted_by=poster)
        second_message = Message(content=faker.sentence(), posted_by=owner)
        new_message = Message(content=faker.sentence(), posted_by=commenter)
        discussion = Discussion.objects.create(
            subject=DatasetFactory(owner=owner),
            user=poster,
            title=faker.sentence(),
            discussion=[message, second_message, new_message],
        )

        with capture_mails():
            notify_new_discussion(discussion.id)
            notify_new_discussion_comment(discussion.id, message=len(discussion.discussion) - 1)

        # Verify previous notifications were handled
        notifications = Notification.objects(
            user=commenter, details__status=DiscussionStatus.NEW_DISCUSSION
        )
        for notification in notifications:
            assert notification.handled_at is not None

    def test_closed_discussion_mail(self):
        owner = UserFactory()
        poster = UserFactory()
        commenter = UserFactory()
        message = Message(content=faker.sentence(), posted_by=poster)
        second_message = Message(content=faker.sentence(), posted_by=commenter)
        closing_message = Message(content=faker.sentence(), posted_by=owner)
        discussion = Discussion.objects.create(
            subject=DatasetFactory(owner=owner),
            user=poster,
            title=faker.sentence(),
            discussion=[message, second_message, closing_message],
            closed=datetime.now(UTC),
            closed_by=owner,
        )

        with capture_mails() as mails:
            notify_discussion_closed(discussion.id, message=len(discussion.discussion) - 1)

        # Should have sent one mail to each participant
        # and no mail to the closer
        expected_recipients = (poster.email, commenter.email)
        self.assertEqual(len(mails), len(expected_recipients))
        for mail in mails:
            self.assertIn(mail.recipients[0], expected_recipients)
            self.assertNotIn(owner.email, mail.recipients)

        # Verify notifications were created for the expected recipients
        notifications = Notification.objects(user__in=[poster, commenter])
        assert len(notifications) == len(expected_recipients)
        assert notifications[0].details.status == DiscussionStatus.CLOSED

    def test_new_discussion_closed_handle_previous_notifications(self):
        owner = UserFactory()
        poster = UserFactory()
        commenter = UserFactory()
        message = Message(content=faker.sentence(), posted_by=poster)
        second_message = Message(content=faker.sentence(), posted_by=owner)
        new_message = Message(content=faker.sentence(), posted_by=commenter)
        discussion = Discussion.objects.create(
            subject=DatasetFactory(owner=owner),
            user=poster,
            title=faker.sentence(),
            discussion=[message, second_message, new_message],
        )

        with capture_mails():
            notify_new_discussion(discussion.id)
            notify_new_discussion_comment(discussion.id, message=1)

            # Properly close the discussion to ensure closed_by is set
            discussion.closed = datetime.now(UTC)
            discussion.closed_by = commenter
            discussion.save()

            notify_discussion_closed(discussion.id, message=len(discussion.discussion) - 1)

        # Verify previous notifications (NEW_DISCUSSION and NEW_COMMENT) were handled
        notifications = Notification.objects(
            user=commenter, details__status__ne=DiscussionStatus.CLOSED
        )
        for notification in notifications:
            print(notification)
            assert notification.handled_at is not None
