"""
This module centralize udata-wide RDF helpers and configuration
"""

import logging
import re
from html.parser import HTMLParser
from urllib.parse import quote

import mongoengine
from flask import abort, current_app, request, url_for
from rdflib import BNode, Graph, Literal, URIRef
from rdflib.namespace import (
    DCTERMS,
    FOAF,
    ORG,
    RDF,
    RDFS,
    SKOS,
    XSD,
    Namespace,
    NamespaceManager,
)
from rdflib.resource import Resource as RdfResource
from rdflib.term import _is_valid_uri
from rdflib.util import SUFFIX_FORMAT_MAP
from rdflib.util import guess_format as raw_guess_format

from udata import uris
from udata.core.contact_point.models import ContactPoint
from udata.frontend.markdown import parse_html
from udata.models import Schema
from udata.mongo.errors import FieldValidationError
from udata.tags import slug as slugify_tag

log = logging.getLogger(__name__)

# Extra Namespaces
ADMS = Namespace("http://www.w3.org/ns/adms#")
DCAT = Namespace("http://www.w3.org/ns/dcat#")
DCATAP = Namespace("http://data.europa.eu/r5r/")
HYDRA = Namespace("http://www.w3.org/ns/hydra/core#")
SCHEMA = Namespace("http://schema.org/")
SCV = Namespace("http://purl.org/NET/scovo#")
SPDX = Namespace("http://spdx.org/rdf/terms#")
VCARD = Namespace("http://www.w3.org/2006/vcard/ns#")
FREQ = Namespace("http://purl.org/cld/freq/")
EUFREQ = Namespace("http://publications.europa.eu/resource/authority/frequency/")  # noqa: E501
EUFORMAT = Namespace("http://publications.europa.eu/resource/authority/file-type/")
IANAFORMAT = Namespace("https://www.iana.org/assignments/media-types/")
DCT = DCTERMS  # More common usage
VCARD = Namespace("http://www.w3.org/2006/vcard/ns#")
GEODCAT = Namespace("http://data.europa.eu/930/")

namespace_manager = NamespaceManager(Graph())
namespace_manager.bind("adms", ADMS)
namespace_manager.bind("dcat", DCAT)
namespace_manager.bind("dcatap", DCATAP)
namespace_manager.bind("dct", DCT)
namespace_manager.bind("foaf", FOAF)
namespace_manager.bind("foaf", FOAF)
namespace_manager.bind("hydra", HYDRA)
namespace_manager.bind("rdfs", RDFS)
namespace_manager.bind("scv", SCV)
namespace_manager.bind("skos", SKOS)
namespace_manager.bind("vcard", VCARD)
namespace_manager.bind("xsd", XSD)
namespace_manager.bind("freq", FREQ)

# Support JSON-LD in format detection
FORMAT_MAP = SUFFIX_FORMAT_MAP.copy()
FORMAT_MAP["json"] = "json-ld"
FORMAT_MAP["jsonld"] = "json-ld"
FORMAT_MAP["xml"] = "xml"

# Map serialization formats to MIME types
RDF_MIME_TYPES = {
    "xml": "application/rdf+xml",
    "n3": "text/n3",
    "turtle": "application/x-turtle",
    "nt": "application/n-triples",
    "json-ld": "application/ld+json",
    "trig": "application/trig",
    # Available but not activated
    # 'nquads': 'application/n-quads',
    # 'trix': 'text/xml',
}

# Map accepted MIME types to known formats
ACCEPTED_MIME_TYPES = {
    "application/rdf+xml": "xml",
    "application/xml": "xml",
    "text/n3": "n3",
    "application/x-turtle": "turtle",
    "text/turtle": "turtle",
    "application/n-triples": "nt",
    "application/ld+json": "json-ld",
    "application/json": "json-ld",
    "application/trig": "trig",
    "text/xml": "xml",
    # Available but not activated
    # 'application/n-quads': 'nquads',
    # 'text/xml': 'trix',
}

# Map formats to default used extensions
RDF_EXTENSIONS = {
    "xml": "xml",
    "n3": "n3",
    "turtle": "ttl",
    "nt": "nt",
    "trig": "trig",
    "json-ld": "json",
    # Available but not activated
    # 'nquads': 'nq',
    # 'trix': 'trix',
}

# Includes control characters, unicode surrogate characters and unicode end-of-plane non-characters
ILLEGAL_XML_CHARS = "[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]"

# Map High Value Datasets URIs to keyword categories
EU_HVD_CATEGORIES = {
    "http://data.europa.eu/bna/c_164e0bf5": "Météorologiques",
    "http://data.europa.eu/bna/c_a9135398": "Entreprises et propriété d'entreprises",
    "http://data.europa.eu/bna/c_ac64a52d": "Géospatiales",
    "http://data.europa.eu/bna/c_b79e35eb": "Mobilité",
    "http://data.europa.eu/bna/c_dd313021": "Observation de la terre et environnement",
    "http://data.europa.eu/bna/c_e1da4e07": "Statistiques",
}
HVD_LEGISLATION = "http://data.europa.eu/eli/reg_impl/2023/138/oj"
TAG_TO_EU_HVD_CATEGORIES = {slugify_tag(EU_HVD_CATEGORIES[uri]): uri for uri in EU_HVD_CATEGORIES}

INSPIRE_GEMET_THEME_NAMESPACE = "http://inspire.ec.europa.eu/theme"
INSPIRE_GEMET_SCHEME_URIS = [
    INSPIRE_GEMET_THEME_NAMESPACE,
    "http://www.eionet.europa.eu/gemet/inspire_themes",
]

AGENT_ROLE_TO_RDF_PREDICATE = {
    "contact": DCAT.contactPoint,
    "creator": DCT.creator,
    "publisher": DCT.publisher,
    "rightsHolder": DCT.rightsHolder,
    "custodian": GEODCAT.custodian,
    "distributor": GEODCAT.distributor,
    "originator": GEODCAT.originator,
    "principalInvestigator": GEODCAT.principalInvestigator,
    "processor": GEODCAT.processor,
    "resourceProvider": GEODCAT.resourceProvider,
    "user": GEODCAT.user,
}

# Map rdf contact point entity to role
CONTACT_POINT_ENTITY_TO_ROLE = {
    predicate: role for role, predicate in AGENT_ROLE_TO_RDF_PREDICATE.items()
}


def guess_format(string):
    """Guess format given an extension or a mime-type"""
    if string in ACCEPTED_MIME_TYPES:
        return ACCEPTED_MIME_TYPES[string]
    return raw_guess_format(string, FORMAT_MAP)


def negociate_content(default="json-ld"):
    """Perform a content negociation on the format given the Accept header"""
    mimetype = request.accept_mimetypes.best_match(ACCEPTED_MIME_TYPES.keys())
    return ACCEPTED_MIME_TYPES.get(mimetype, default)


def want_rdf():
    """Check wether client prefer RDF over the default HTML"""
    mimetype = request.accept_mimetypes.best
    return mimetype in ACCEPTED_MIME_TYPES


# JSON-LD context used for udata DCAT representation
CONTEXT = {
    # Namespaces
    "@vocab": "http://www.w3.org/ns/dcat#",
    "dcat": "http://www.w3.org/ns/dcat#",
    "dct": "http://purl.org/dc/terms/",
    "foaf": "http://xmlns.com/foaf/0.1/",
    "org": "http://www.w3.org/ns/org#",
    "rdfs": "http://www.w3.org/2000/01/rdf-schema#",
    "skos": "http://www.w3.org/2004/02/skos/core#",
    "spdx": "http://spdx.org/rdf/terms#",
    "vcard": "http://www.w3.org/2006/vcard/ns#",
    "schema": "http://schema.org/",
    "hydra": "http://www.w3.org/ns/hydra/core#",
    "freq": "http://purl.org/cld/freq/",
    # Aliased field
    "downloadURL": {"@id": "dcat:downloadURL", "@type": "@id"},
    "accessURL": {"@id": "dcat:accessURL", "@type": "@id"},
    "dataset": {"@id": "dcat:dataset", "@type": "@id"},
    "distribution": {"@id": "dcat:distribution", "@type": "@id"},
    "title": "dct:title",
    "description": "dct:description",
    "issued": {"@id": "dct:issued", "@type": "http://www.w3.org/2001/XMLSchema#dateTime"},
    "modified": {"@id": "dct:modified", "@type": "http://www.w3.org/2001/XMLSchema#dateTime"},
    "language": "dct:language",
    "license": "dct:license",
    "rights": "dct:rights",
    "spatial": "dct:spatial",
    "identifier": "dct:identifier",
    "temporal": "dct:temporal",
    "format": "dct:format",
    "accrualPeriodicity": "dct:accrualPeriodicity",
    "homepage": {"@id": "foaf:homepage", "@type": "@id"},
    "publisher": {"@id": "dct:publisher", "@type": "@id"},
    "fn": "vcard:fn",
    "hasEmail": "vcard:email",
    "subOrganizationOf": "org:subOrganizationOf",
    "checksum": "spdx:checksum",
    "algorithm": {"@id": "spdx:algorithm", "@type": "@id"},
    "checksumValue": "spdx:checksumValue",
    "label": "rdfs:label",
    "name": "foaf:name",
    "startDate": "schema:startDate",
    "endDate": "schema:endDate",
    "view": {"@id": "hydra:view", "@type": "@id"},
    "first": {"@id": "hydra:first", "@type": "@id"},
    "last": {"@id": "hydra:last", "@type": "@id"},
    "next": {"@id": "hydra:next", "@type": "@id"},
    "previous": {"@id": "hydra:previous", "@type": "@id"},
    "totalItems": "hydra:totalItems",
}


def serialize_value(value, unwrap: list[URIRef] | None = None):
    """
    If the value is a URIRef or a Literal, return it as a string.
    If the value is a RdfResource:
        - if `unwrap` is set, look for children of the RdfResource in the order they are listed in
          `unwrap`, and return the value of the first matching element (if any),
        - otherwise return the identifier of the RdfResource.
    """
    if isinstance(value, (URIRef, Literal)):
        return value.toPython()
    elif isinstance(value, RdfResource):
        for uriref in unwrap or []:
            if val := rdf_value(value, uriref):
                return val
        return value.identifier.toPython()


def rdf_unique_values(resource, predicate, unwrap: list[URIRef] | None = None) -> set[str]:
    """Returns a set of serialized values for a predicate from a RdfResource"""
    return {
        value
        for info in resource.objects(predicate=predicate)
        if (value := serialize_value(info, unwrap=unwrap))
    }


def rdf_value(obj, predicate, default=None, unwrap: list[URIRef] | None = None):
    """
    Serialize the value for a predicate on a RdfResource,
    expecting one value only or (at most) one per language for Literals.
    """
    value = default_lang_value(obj, predicate)
    return serialize_value(value, unwrap=unwrap) if value else default


def default_lang_value(obj, predicate):
    """
    Return the value with the default language if multiple Literal values exist in different languages.
    """
    candidate_values = list(obj.objects(predicate))
    if not candidate_values:
        return None
    for val in candidate_values:
        if isinstance(val, Literal) and val.language == current_app.config["DEFAULT_LANGUAGE"]:
            return val
    # Defaulting to the first value found
    return candidate_values[0]


class HTMLDetector(HTMLParser):
    def __init__(self, *args, **kwargs):
        HTMLParser.__init__(self, *args, **kwargs)
        self.elements = set()

    def handle_starttag(self, tag, attrs):
        self.elements.add(tag)

    def handle_endtag(self, tag):
        self.elements.add(tag)


def is_html(text):
    parser = HTMLDetector()
    parser.feed(text)
    return bool(parser.elements)


def sanitize_html(text):
    text = text.toPython() if isinstance(text, Literal) else ""
    if is_html(text):
        return parse_html(text)
    else:
        return text.strip()


def url_from_rdf(rdf, prop):
    """
    Try to extract An URL from a resource property.
    It can be expressed in many forms as a URIRef or a Literal
    """
    value = rdf.value(prop)
    if isinstance(value, (URIRef, Literal)):
        return value.toPython()
    elif isinstance(value, RdfResource):
        return value.identifier.toPython()


def theme_labels_from_rdf(rdf):
    """
    Get theme labels to use as keywords.
    Map HVD keywords from known URIs resources if HVD support is activated.
    Map INSPIRE keyword from known themes if INSPIRE support is activated.
    - An INSPIRE dataset is a dataset with a theme INSPIRE encoded with gmd:descriptiveKeywords/gmd:MD_Keywords.
      In DCAT, it is shown as a DCAT.theme with a SKOS.inScheme pointing to to the INSPIRE thesaurus.
      We filter on this thesaurus based on its name (expecting "GEMET - INSPIRE themes, version 1.0") or its uri.
    """
    for theme in rdf.objects(DCAT.theme):
        if isinstance(theme, RdfResource):
            label = rdf_value(theme, SKOS.prefLabel)
            uri = theme.identifier.toPython()
            if current_app.config["HVD_SUPPORT"] and uri in EU_HVD_CATEGORIES:
                # Map label from EU HVD categories
                label = EU_HVD_CATEGORIES[uri]
                # Additionnally yield hvd keyword
                yield "hvd"
            if current_app.config["INSPIRE_SUPPORT"]:
                if uri.startswith(INSPIRE_GEMET_THEME_NAMESPACE):
                    yield "inspire"
                else:
                    # Check if the theme belongs to the GEMET INSPIRE scheme
                    if scheme := theme.value(SKOS.inScheme):
                        scheme_title = (
                            rdf_value(scheme, DCT.title)
                            or rdf_value(scheme, SKOS.prefLabel)
                            or rdf_value(scheme, RDFS.label)
                        )
                        scheme_uri = scheme.identifier.toPython()
                        if (
                            scheme_title
                            and scheme_title.lower() == "gemet - inspire themes, version 1.0"
                        ) or scheme_uri in INSPIRE_GEMET_SCHEME_URIS:
                            yield "inspire"
        else:
            label = theme.toPython()
        if label:
            yield label


def themes_from_rdf(rdf):
    tags = []
    for tag in rdf.objects(DCAT.keyword):
        if isinstance(tag, RdfResource):
            # dcat:keyword should be Literal, not a Resource/URIRef
            log.warning(f"Ignoring dcat:keyword with URI value: {tag.identifier}")
            continue
        tags.append(tag.toPython())
    tags += theme_labels_from_rdf(rdf)
    return list(set(tags))


def contact_point_name(agent_name: str | None, org_name: str | None) -> str:
    if agent_name and org_name:
        return f"{agent_name} ({org_name})"
    return agent_name or org_name or ""


def contact_points_from_rdf(rdf, prop, role, dataset, dryrun=False):
    if not dataset.organization and not dataset.owner:
        return
    for contact_point in rdf.objects(prop):
        # Read contact point information
        if isinstance(contact_point, Literal):
            log.warning(f"Found a `Literal` inside {prop}, `foaf:Agent` or `vcard:Kind` expected.")
            name = contact_point.toPython()
            email = None
            contact_form = None
        elif prop == DCAT.contactPoint:  # Could be split on the type of contact_point instead
            name = contact_point_name(
                rdf_value(contact_point, VCARD.fn),
                rdf_value(contact_point, VCARD["organization-name"]),
            )
            email = (
                rdf_value(contact_point, VCARD.hasEmail)
                or rdf_value(contact_point, VCARD.email)
                or None
            )
            email = email.replace("mailto:", "").strip() if email else None
            contact_form = rdf_value(contact_point, VCARD.hasUrl)
        else:
            contact_point_org = contact_point.value(ORG.memberOf)
            name = contact_point_name(
                rdf_value(contact_point, FOAF.name) or rdf_value(contact_point, SKOS.prefLabel),
                rdf_value(contact_point_org, FOAF.name) if contact_point_org else None,
            )
            email = (
                rdf_value(contact_point, FOAF.mbox)
                or (contact_point_org and rdf_value(contact_point_org, FOAF.mbox))
                or None
            )
            email = email.replace("mailto:", "").strip() if email else None
            contact_form = None

        # Tested at validation time, because it depends on the role
        # if not email and not contact_form:
        #         continue

        # Create of get contact point object
        org_or_owner = {}
        if dataset.organization:
            org_or_owner = {"organization": dataset.organization}
        else:
            org_or_owner = {"owner": dataset.owner}
        try:
            if dryrun:
                # In dryrun mode, only reuse existing contact points, don't create new ones.
                # Mongoengine doesn't allow referencing unsaved documents.
                contact = ContactPoint.objects.filter(
                    name=name, email=email, contact_form=contact_form, role=role, **org_or_owner
                ).first()
                if not contact:
                    continue
            else:
                contact, _ = ContactPoint.objects.get_or_create(
                    name=name, email=email, contact_form=contact_form, role=role, **org_or_owner
                )
        except mongoengine.errors.ValidationError as validation_error:
            log.warning(f"Unable to validate contact point: {validation_error}", exc_info=True)
            continue
        yield contact


def contact_points_to_rdf(contacts, graph=None):
    """
    Map a contact point to a DCAT/RDF graph
    """
    graph = graph or Graph(namespace_manager=namespace_manager)

    for contact in contacts:
        if contact.id:
            id = URIRef(
                url_for(
                    "api.contact_point",
                    contact_point=contact.id,
                    _external=True,
                )
            )
        else:
            id = BNode()

        node = graph.resource(id)
        role = AGENT_ROLE_TO_RDF_PREDICATE.get(contact.role, DCAT.contactPoint)
        # GeoDCAT-AP spec: Only contactPoint is a VCARD.Kind (like in DCAT). Other roles are FOAF.Agent.
        if role == DCAT.contactPoint:
            node.set(RDF.type, VCARD.Kind)
            if contact.name:
                node.set(VCARD.fn, Literal(contact.name))
            if contact.email:
                node.set(VCARD.hasEmail, URIRef(f"mailto:{contact.email}"))
            if contact.contact_form:
                node.set(VCARD.hasUrl, URIRef(contact.contact_form))
        else:
            node.set(RDF.type, FOAF.Agent)
            node.set(FOAF.name, Literal(contact.name))
            if contact.email:
                node.set(FOAF.mbox, URIRef(f"mailto:{contact.email}"))
            if contact.contact_form:
                node.set(FOAF.page, URIRef(contact.contact_form))

        yield node, role


def primary_topic_identifier_from_rdf(graph: Graph, resource: RdfResource):
    """
    Extract the dct:identifier from a primaryTopic of a RdfResource `resource` via an RDF `graph`.
    The primary topic might be identified by a FOAF:isPrimaryTopicOf from the Resource, or by a FOAF:primaryTopic to the Resource.
    In DCAT, the primary topic should be a unique CatalogRecord (if any), but nothing here prevents it to be something else.
    """
    # look for "inner" primaryTopic linking to Dataset via isPrimaryTopicOf
    is_primary_topic_of = graph.value(subject=resource.identifier, predicate=FOAF.isPrimaryTopicOf)
    if is_primary_topic_of:
        return graph.value(is_primary_topic_of, DCT.identifier)
    # look for "outer" primaryTopic linking to Dataset via primaryTopic
    primary_topic = graph.value(predicate=FOAF.primaryTopic, object=resource.identifier)
    if primary_topic:
        return graph.value(primary_topic, DCT.identifier)


def remote_url_from_rdf(rdf: RdfResource, graph: Graph, remote_url_prefix: str | None = None):
    """
    Compute from `remote_url_prefix` if provided and primaryTopic identifier if found.
    Otherwise, use DCAT.landingPage if found and uri validation succeeds.
    In this latter case, use RDF identifier as fallback if uri validation succeeds.
    """
    if remote_url_prefix and (identifier := primary_topic_identifier_from_rdf(graph, rdf)):
        # Some ISO-19115-3 GeoNetwork templates set a codeSpace for the record ID (e.g. the
        # geodata-multilingual.xml template), meaning we have:
        # - mdb:metadataIdentifier/mcc:MD_Identifier/mcc:code = the record ID,
        # - mdb:metadataIdentifier/mcc:MD_Identifier/mcc:codeSpace = "urn:uuid".
        #
        # That codeSpace ends up collapsed in the record dct:identifier. This means dct:identifier
        # differs (by the codeSpace) from the record ID that GeoNetwork uses internally, including
        # for its URLs. So we need to extract the original record ID from dct:identifier to build a
        # valid remote_url.
        #
        # URN parsing rules depend on the namespace of the URN (urn:<namespace>:...), so there is no
        # generic way to extract the codeSpace. Here we only handle the "uuid" namespace (RFC-4122),
        # which is used in the wild by GeoNetwork (e.g. OFB, Sextant, and likely most future
        # ISO-19115-3 catalogs that use the default templates).
        #
        # Note that the datatype == xsd:anyURI test is important. Some *ISO-19139* catalogs are
        # using "urn:...:" prefixes in their gmd:fileIdentifier (e.g. Geo2France), but ISO-19139 has
        # no concept of codeSpace, it's simply a string. So in ISO-19139, what looks like a "prefix"
        # is just an arbitrary part the plain string identifier, with no special meaning.
        uuid_prefix = "urn:uuid:"
        if identifier.datatype == XSD.anyURI and identifier.value.startswith(uuid_prefix):
            offset = len(uuid_prefix)
            identifier = identifier.value[offset:]
        return f"{remote_url_prefix.rstrip('/')}/{identifier}"

    landing_page = url_from_rdf(rdf, DCAT.landingPage)
    uri = rdf.identifier.toPython()
    for candidate in [landing_page, uri]:
        if candidate:
            try:
                uris.validate(candidate)
                return candidate
            except uris.ValidationError:
                pass


def schema_from_rdf(rdf):
    """
    Try to extract a schema from a conformsTo property.
    Currently the "issued" property is not harvest.
    """
    resource = rdf.value(DCT.conformsTo)
    if not resource:
        return None

    schema = Schema()
    if isinstance(resource, (URIRef, Literal)):
        schema.url = resource.toPython()
    elif isinstance(resource, RdfResource):
        # We try to get the schema "correct" URL.
        # 1. The identifier of the DCT.conformsTo
        # 2. The DCT.type inside the DCT.conformsTo (from some example it's the most precise one)
        # (other not currently used RDF.type)
        url = None
        try:
            url = uris.validate(resource.identifier.toPython())
        except uris.ValidationError:
            try:
                type = resource.value(DCT.type)
                if type is not None:
                    url = uris.validate(type.identifier.toPython())
            except uris.ValidationError:
                pass

        if url is None:
            return None

        schema.url = url
        schema.name = resource.value(DCT.title)
    else:
        return None

    try:
        schema.clean()
        return schema
    except FieldValidationError as e:
        log.warning(f"Invalid schema inside RDF {e}")
        return None


def escape_xml_illegal_chars(val, replacement="?"):
    illegal_xml_chars_RE = re.compile(ILLEGAL_XML_CHARS)
    return illegal_xml_chars_RE.sub(replacement, val)


def paginate_catalog(catalog, graph, datasets, _format, rdf_catalog_endpoint, **values):
    if not format:
        raise ValueError("Pagination requires format")
    catalog.add(RDF.type, HYDRA.Collection)
    catalog.set(HYDRA.totalItems, Literal(datasets.total))
    kwargs = {
        "_format": _format,
        "page_size": datasets.page_size,
        "_external": True,
    }
    values.pop("page", None)
    values.pop("page_size", None)
    kwargs.update(values)

    first_url = url_for(rdf_catalog_endpoint, page=1, **kwargs)
    page_url = url_for(rdf_catalog_endpoint, page=datasets.page, **kwargs)
    last_url = url_for(rdf_catalog_endpoint, page=datasets.pages, **kwargs)
    pagination = graph.resource(URIRef(page_url))
    pagination.set(RDF.type, HYDRA.PartialCollectionView)

    pagination.set(HYDRA.first, URIRef(first_url))
    pagination.set(HYDRA.last, URIRef(last_url))
    if datasets.has_next:
        next_url = url_for(rdf_catalog_endpoint, page=datasets.page + 1, **kwargs)
        pagination.set(HYDRA.next, URIRef(next_url))
    if datasets.has_prev:
        prev_url = url_for(rdf_catalog_endpoint, page=datasets.page - 1, **kwargs)
        pagination.set(HYDRA.previous, URIRef(prev_url))

    catalog.set(HYDRA.view, pagination)

    return catalog


def escape_uri_in_graph(graph: Graph) -> Graph:
    """
    Some invalid uri could exist in the graph and they can't be serialized in N3/Turtle.
    We use a urllib.parse.quote to escape these at best for invalid URIRef.
    """
    escaped_graph = Graph()
    for s, p, o in graph:
        try:
            if isinstance(s, URIRef) and not _is_valid_uri(str(s)):
                encoded_uri = quote(str(s), safe=":/?#[]@!$&'()*+,;=")
                s = URIRef(encoded_uri)
            if isinstance(o, URIRef) and not _is_valid_uri(str(o)):
                encoded_uri = quote(str(o), safe=":/?#[]@!$&'()*+,;=")
                o = URIRef(encoded_uri)
            escaped_graph.add((s, p, o))
        except Exception as e:
            log.exception(f"Failing to escape uri on triplet {s} {p} {o} : {e}")
            continue
    return escaped_graph


def graph_response(graph, format):
    """
    Return a proper flask response for a RDF resource given an expected format.
    """
    fmt = guess_format(format)
    if not fmt:
        abort(404)
    headers = {"Content-Type": RDF_MIME_TYPES[fmt]}
    kwargs = {}
    if fmt == "json-ld":
        kwargs["context"] = CONTEXT
    if isinstance(graph, RdfResource):
        graph = graph.graph
    if fmt in ["n3", "nt", "turtle", "trig"]:
        graph = escape_uri_in_graph(graph)
    return escape_xml_illegal_chars(graph.serialize(format=fmt, **kwargs)), 200, headers


def set_harvested_date(obj, rdf_resource, rdf_term, harvest_attr, fallback=None) -> None:
    """
    Add a date to the RDF resource from the harvest metadata if available.
    Use the fallback value for non harvested objects.
    """
    if obj.harvest and (harvest_attr_value := getattr(obj.harvest, harvest_attr)):
        rdf_resource.set(rdf_term, Literal(harvest_attr_value))
    elif not obj.harvest and fallback:
        rdf_resource.set(rdf_term, Literal(fallback))
