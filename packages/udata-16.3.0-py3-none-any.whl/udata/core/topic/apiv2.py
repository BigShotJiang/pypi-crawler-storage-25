import logging

import mongoengine
from flask import abort, request, url_for
from flask_security import current_user

from udata import search
from udata.api import API, api, apiv2, fields
from udata.api_fields import lazy_reference, patch, patch_and_save
from udata.core.discussions.models import Discussion
from udata.core.topic import DEFAULT_PAGE_SIZE
from udata.core.topic.models import Topic, TopicElement
from udata.core.topic.parsers import TopicApiParser, TopicElementsParser
from udata.core.topic.permissions import TopicEditPermission
from udata.core.topic.search import TopicSearch
from udata.mongo.errors import FieldValidationError

apiv2.inherit("ModelReference", api.model_reference)
apiv2.inherit("LazyReference", lazy_reference)
apiv2.inherit("TopicElement (read)", TopicElement.__read_fields__)
apiv2.inherit("TopicElement (write)", TopicElement.__write_fields__)

topic_fields = apiv2.clone(
    "Topic",
    Topic.__read_fields__,
    {
        "elements": fields.Raw(
            attribute=lambda o: {
                "rel": "subsection",
                "href": url_for(
                    "apiv2.topic_elements",
                    topic=o.id,
                    page=1,
                    page_size=DEFAULT_PAGE_SIZE,
                    _external=True,
                ),
                "type": "GET",
                "total": o.elements.count(),
            },
            description="Link to the topic elements",
        ),
    },
)

topic_page_fields = apiv2.model("TopicPage", fields.pager(topic_fields))
topic_search_page_fields = apiv2.model("TopicSearchPage", fields.search_pager(topic_fields))
apiv2.inherit("TopicElementPage", TopicElement.__page_fields__)

topic_input_fields = apiv2.clone(
    "TopicInput",
    Topic.__write_fields__,
    {
        "elements": fields.List(
            fields.Nested(TopicElement.__read_fields__), description="The topic elements"
        ),
    },
)

DEFAULT_SORTING = "-created_at"

log = logging.getLogger(__name__)

ns = apiv2.namespace("topics", "Topics related operations")

topic_parser = TopicApiParser()
elements_parser = TopicElementsParser()

common_doc = {"params": {"topic": "The topic ID"}}


search_parser = TopicSearch.as_request_parser(store_missing=False)


@ns.route("/search/", endpoint="topic_search")
class TopicSearchAPI(API):
    """Topics collection search endpoint (backed by search-service when enabled)."""

    @apiv2.doc("search_topics")
    @apiv2.expect(search_parser)
    @apiv2.marshal_with(topic_search_page_fields)
    def get(self):
        """List or search all topics"""
        args = search_parser.parse_args()
        try:
            return search.query(TopicSearch, **args)
        except NotImplementedError:
            abort(501, "Search endpoint not enabled")
        except RuntimeError:
            abort(500, "Internal search service error")


@ns.route("/", endpoint="topics_list")
class TopicsAPI(API):
    @apiv2.expect(topic_parser.parser)
    @apiv2.marshal_with(topic_page_fields)
    def get(self):
        """List all topics"""
        args = topic_parser.parse()
        topics = Topic.objects.visible_by_user(current_user, mongoengine.Q(private__ne=True))
        topics = topic_parser.parse_filters(topics, args)
        sort = args["sort"] or ("$text_score" if args["q"] else None) or DEFAULT_SORTING
        return topics.order_by(sort).paginate(args["page"], args["page_size"])

    @apiv2.secure
    @apiv2.doc("create_topic")
    @apiv2.expect(topic_input_fields)
    @apiv2.marshal_with(topic_fields)
    @apiv2.response(400, "Validation error")
    def post(self):
        """Create a topic"""
        data = request.json
        if not isinstance(data, dict):
            apiv2.abort(400, "Expected a JSON object")

        # Elements are a reverse relationship (TopicElement → Topic), not a field
        # on Topic itself, so patch() can't handle them. We extract them from the
        # payload and manage them manually after saving the topic.
        # TODO: patch() could support virtual fields for reverse relationships to
        # avoid this manual handling.
        elements_data = data.get("elements")

        topic = patch(Topic(), data)

        if not topic.owner and not topic.organization:
            topic.owner = current_user._get_current_object()

        topic.save()

        if elements_data is not None:
            for element_data in elements_data:
                element = patch(TopicElement(), element_data)
                element.topic = topic
                element.save()

        return topic, 201


@ns.route("/<topic:topic>/", endpoint="topic", doc=common_doc)
@apiv2.response(404, "Topic not found")
class TopicAPI(API):
    @apiv2.doc("get_topic")
    @apiv2.marshal_with(topic_fields)
    def get(self, topic):
        """Get a given topic"""
        return topic

    @apiv2.secure
    @apiv2.doc("update_topic")
    @apiv2.expect(topic_input_fields)
    @apiv2.marshal_with(topic_fields)
    @apiv2.response(400, "Validation error")
    @apiv2.response(403, "Forbidden")
    def put(self, topic):
        """Update a given topic"""
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")

        data = request.json
        if not isinstance(data, dict):
            apiv2.abort(400, "Expected a JSON object")

        elements_data = data.get("elements")

        patch_and_save(topic, data)

        if elements_data is not None:
            TopicElement.objects(topic=topic).delete()
            for element_data in elements_data:
                element = patch(TopicElement(), element_data)
                element.topic = topic
                element.save()

        return topic

    @apiv2.secure
    @apiv2.doc("delete_topic")
    @apiv2.response(204, "Object deleted")
    @apiv2.response(403, "Forbidden")
    def delete(self, topic):
        """Delete a given topic"""
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")
        # Remove discussions linked to the topic
        Discussion.objects(subject=topic).delete()
        topic.delete()
        return "", 204


@ns.route("/<topic:topic>/elements/", endpoint="topic_elements", doc=common_doc)
class TopicElementsAPI(API):
    @apiv2.doc("topic_elements")
    @apiv2.expect(elements_parser.parser)
    @apiv2.marshal_with(TopicElement.__page_fields__)
    def get(self, topic):
        """Get a given topic's elements with pagination."""
        args = elements_parser.parse()
        elements = elements_parser.parse_filters(
            topic.elements,
            args,
        )
        return elements.paginate(args["page"], args["page_size"])

    @apiv2.secure
    @apiv2.doc("topic_elements_create")
    @apiv2.expect([api.model_reference])
    @apiv2.marshal_list_with(TopicElement.__read_fields__)
    @apiv2.response(400, "Expecting a list")
    @apiv2.response(404, "Topic not found")
    @apiv2.response(403, "Forbidden")
    def post(self, topic):
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")

        data = request.json

        if not isinstance(data, list):
            apiv2.abort(400, "Expecting a list")

        errors = []
        elements = []
        for element_data in data:
            try:
                element = patch(TopicElement(), element_data)
                element.topic = topic
                elements.append(element)
            except FieldValidationError as e:
                errors.append({e.field: [str(e)]})

        if errors:
            apiv2.abort(400, errors=errors)

        for element in elements:
            element.save()

        topic.save()

        return elements, 201

    @apiv2.secure
    @apiv2.doc("topic_elements_delete")
    @apiv2.response(404, "Topic not found")
    @apiv2.response(403, "Forbidden")
    def delete(self, topic):
        """Delete all elements from a Topic

        This a workaround for https://github.com/kvesteri/wtforms-json/issues/43
        -> we can't use PUT /api/2/topics/{topic}/ with an empty list of elements
        """
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")

        # TODO: this triggers performance issues on a huge topic (too many tasks, too many activities)
        topic.elements.delete()

        return None, 204


@ns.route(
    "/<topic:topic>/elements/<element_id>/",
    endpoint="topic_element",
    doc={"params": {"topic": "The topic ID", "element": "The element ID"}},
)
class TopicElementAPI(API):
    @apiv2.secure
    @apiv2.response(404, "Topic not found")
    @apiv2.response(404, "Element not found in topic")
    @apiv2.response(204, "Success")
    def delete(self, topic, element_id):
        """Delete a given element from the given topic"""
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")

        element = TopicElement.objects.get_or_404(pk=element_id)
        element.delete()

        return None, 204

    @apiv2.secure
    @apiv2.doc("topic_element_update")
    @apiv2.expect(TopicElement.__write_fields__)
    @apiv2.marshal_with(TopicElement.__read_fields__)
    @apiv2.response(404, "Topic not found")
    @apiv2.response(404, "Element not found in topic")
    @apiv2.response(204, "Success")
    def put(self, topic, element_id):
        """Update a given element from the given topic"""
        if not TopicEditPermission(topic).can():
            apiv2.abort(403, "Forbidden")

        element = TopicElement.objects.get_or_404(pk=element_id)
        patch_and_save(element, request)

        return element
