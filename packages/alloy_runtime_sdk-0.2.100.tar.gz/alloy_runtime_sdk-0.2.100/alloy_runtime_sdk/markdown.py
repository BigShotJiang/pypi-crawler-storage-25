"""Markdown formatting helpers for LLM-readable JSON inputs."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from typing import TypeAlias, cast

JsonPrimitive: TypeAlias = None | bool | int | float | str
JsonValue: TypeAlias = JsonPrimitive | list["JsonValue"] | dict[str, "JsonValue"]


def json_to_markdown(
    data: JsonValue,
    *,
    title: str = "Data",
    use_fences: bool = True,
    use_tables: bool = True,
    title_case_keys: bool = False,
    max_depth: int = 12,
) -> str:
    """Convert a JSON-like value into Markdown optimized for LLM prompt context.

    Args:
        data: JSON-like Python value: dict, list, string, number, boolean, or None.
        title: Top-level Markdown H1 title.
        use_fences: Wrap top-level flat dict records in fenced code blocks.
        use_tables: Render dict values that are lists of dicts as Markdown tables.
        title_case_keys: Convert underscores to spaces and title-case keys in headings
            and key/value labels.
        max_depth: Recursion safety limit. Values below 1 return formatted JSON.

    Returns:
        Markdown text ending with a newline, except for the JSON fallback path.
    """
    if max_depth < 1:
        return json.dumps(data, ensure_ascii=False, indent=2)

    lines = [f"# {title}\n\n"]
    lines.extend(
        _render_value(
            data,
            level=2,
            options=_RenderOptions(use_fences, use_tables, title_case_keys, max_depth),
        )
    )
    return "".join(lines)


class _RenderOptions:
    def __init__(
        self, use_fences: bool, use_tables: bool, title_case_keys: bool, max_depth: int
    ) -> None:
        self.use_fences = use_fences
        self.use_tables = use_tables
        self.title_case_keys = title_case_keys
        self.max_depth = max_depth


def _render_value(
    value: JsonValue, *, level: int, options: _RenderOptions
) -> list[str]:
    if level > options.max_depth:
        return [json.dumps(value, ensure_ascii=False) + "\n"]

    if isinstance(value, dict):
        return _render_mapping(value, level=level, options=options)
    if isinstance(value, list):
        return _render_sequence(value, level=level, options=options)
    return [f"{_format_leaf(value)}\n"]


def _render_mapping(
    mapping: Mapping[str, JsonValue], *, level: int, options: _RenderOptions
) -> list[str]:
    lines: list[str] = []
    heading_marker = "#" * min(level, 6)

    for raw_key, child in mapping.items():
        key = _format_key(raw_key, title_case_keys=options.title_case_keys)

        if isinstance(child, dict) and child:
            _append_heading(lines, f"{heading_marker} {key}\n")
            lines.extend(_render_value(child, level=level + 1, options=options))
        elif isinstance(child, list) and child:
            _append_heading(lines, f"{heading_marker} {key}\n")
            lines.extend(
                _render_non_empty_sequence_value(child, level=level, options=options)
            )
        else:
            lines.append(f"**{key}**: {_format_leaf(child)}\n")

    return lines


def _render_non_empty_sequence_value(
    sequence: Sequence[JsonValue], *, level: int, options: _RenderOptions
) -> list[str]:
    if options.use_tables and _contains_only_mappings(sequence):
        return _render_table(
            cast(Sequence[Mapping[str, JsonValue]], sequence),
            title_case_keys=options.title_case_keys,
        )

    lines: list[str] = []
    for index, item in enumerate(sequence):
        if isinstance(item, dict | list):
            lines.append(f"{'  ' * (level - 1)}- **Item {index}**\n")
            lines.extend(_render_value(item, level=level + 1, options=options))
        else:
            lines.append(f"{'  ' * (level - 1)}- {_format_leaf(item)}\n")
    return lines


def _render_sequence(
    sequence: Sequence[JsonValue], *, level: int, options: _RenderOptions
) -> list[str]:
    lines: list[str] = []
    for index, item in enumerate(sequence):
        if isinstance(item, dict):
            record_id = item.get("id", index)
            _append_heading(lines, f"## Record {_format_leaf(record_id)}\n")
            if options.use_fences:
                lines.append("```\n")
            for raw_key, value in item.items():
                key = _format_key(raw_key, title_case_keys=options.title_case_keys)
                lines.append(f"**{key}**: {_format_leaf(value)}\n")
            if options.use_fences:
                lines.append("```\n\n")
        elif isinstance(item, list):
            lines.append(f"{'  ' * (level - 1)}- **Item {index}**\n")
            lines.extend(_render_value(item, level=level + 1, options=options))
        else:
            lines.append(f"- {_format_leaf(item)}\n")
    return lines


def _render_table(
    rows: Sequence[Mapping[str, JsonValue]], *, title_case_keys: bool
) -> list[str]:
    raw_headers = sorted({key for row in rows for key in row})
    headers = [
        _format_key(header, title_case_keys=title_case_keys) for header in raw_headers
    ]
    lines = [
        "| " + " | ".join(headers) + " |\n",
        "| " + " | ".join(["---"] * len(headers)) + " |\n",
    ]
    for row in rows:
        values = [
            _escape_table_cell(_format_leaf(row.get(header))) for header in raw_headers
        ]
        lines.append("| " + " | ".join(values) + " |\n")
    lines.append("\n")
    return lines


def _contains_only_mappings(sequence: Sequence[JsonValue]) -> bool:
    return all(isinstance(item, dict) for item in sequence)


def _append_heading(lines: list[str], heading: str) -> None:
    if lines and lines[-1] != "\n" and not lines[-1].endswith("\n\n"):
        lines.append("\n")
    lines.append(heading)


def _format_key(key: str, *, title_case_keys: bool) -> str:
    if not title_case_keys:
        return key
    return key.replace("_", " ").title()


def _format_leaf(value: JsonValue) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return f"{value:.4g}"
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False)


def _escape_table_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", "<br>")


__all__ = ["JsonPrimitive", "JsonValue", "json_to_markdown"]
