"""Kafka protocol definitions."""
