"""anycloud MCP server — exposes SDK functionality as MCP tools.

Run via: python -m anycloud.mcp
"""

from __future__ import annotations

import json
import re
import subprocess
import time
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from anycloud.client import Client, _SDK_VERSION
from anycloud.job import Job

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client() -> Client:
    """Return a ready-to-use SDK Client (token resolved automatically)."""
    return Client()


def _find_docs_dir() -> Path:
    """Resolve the docs/ directory."""
    repo_docs = Path(__file__).resolve().parent.parent.parent / "docs"
    if repo_docs.is_dir():
        return repo_docs
    raise FileNotFoundError("Cannot locate docs/ directory")


def _dump(obj: Any) -> str:
    """Serialize to JSON, handling pydantic models."""
    if hasattr(obj, "model_dump"):
        return json.dumps(obj.model_dump(by_alias=True), indent=2, default=str)
    if isinstance(obj, list) and obj and hasattr(obj[0], "model_dump"):
        return json.dumps([d.model_dump(by_alias=True) for d in obj], indent=2, default=str)
    return json.dumps(obj, indent=2, default=str)


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP("anycloud")


# --- Docs resource ---


@mcp.resource("anycloud://docs/{path}")
def read_doc(path: str) -> str:
    """Read an anycloud documentation page."""
    return (_find_docs_dir() / f"{path}.md").read_text()


# --- Catalog tools ---


@mcp.tool()
def list_regions(cloud_provider: str) -> str:
    """List available cloud regions for a provider (AWS, GCP, Azure, Lambda)."""
    return _dump(_client().get_regions(cloud_provider))


@mcp.tool()
def list_vm_types(
    cloud_provider: str,
    region: str,
    accelerator: str | None = None,
) -> str:
    """List available VM types for a provider and region. Use accelerator to filter by GPU (e.g. "H100", "A100", or "*" for all GPUs)."""
    return _dump(_client().get_vm_types(cloud_provider, region, accelerator=accelerator))


@mcp.tool()
def list_zones(region: str) -> str:
    """List available GCP zone suffixes for a region."""
    return _dump(_client().get_zones(region))


@mcp.tool()
def list_regions_for_vm_type(
    vm_type: str,
    cloud_provider: str,
    spot: bool = False,
) -> str:
    """List regions where a VM type is available, sorted by price (US regions first)."""
    return _dump(_client().get_regions_for_vm_type(vm_type, cloud_provider, spot=spot))


@mcp.tool()
def get_pricing(
    vm_type: str,
    cloud_provider: str,
    region: str | None = None,
    spot: bool = False,
) -> str:
    """Get pricing for a VM type across regions (or for a specific region)."""
    return _dump(_client().get_pricing(vm_type, cloud_provider, region=region, spot=spot))


@mcp.tool()
def list_gpus(cloud_provider: str) -> str:
    """List available GPU/accelerator names for a cloud provider."""
    return _dump(_client().get_gpus(cloud_provider))


@mcp.tool()
def list_gpu_counts(gpu_name: str, cloud_provider: str) -> str:
    """Get available GPU counts for an accelerator (e.g. [1, 2, 4, 8])."""
    return _dump(_client().get_gpu_counts(gpu_name, cloud_provider))


# --- Credentials tools ---


@mcp.tool()
def credentials_list() -> str:
    """List saved cloud credentials (secrets redacted)."""
    entries = _client().list_credentials()
    if not entries:
        return "No credentials found. Use credentials_new to add cloud provider credentials."
    return _dump(entries)


@mcp.tool()
def credentials_get(name: str) -> str:
    """Get a single saved credential by name (secrets redacted)."""
    return _dump(_client().get_credential(name))


@mcp.tool()
def credentials_new(
    name: str,
    cloud_provider: str,
    # AWS
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    # GCP
    project_id: str | None = None,
    client_email: str | None = None,
    private_key: str | None = None,
    # Azure
    application_id: str | None = None,
    secret: str | None = None,
    subscription_id: str | None = None,
    directory_id: str | None = None,
    # Lambda
    api_key: str | None = None,
) -> str:
    """Add new cloud provider credentials."""
    # Collect all non-None provider fields and let the API validate
    credential: dict[str, Any] = {"cloudProvider": cloud_provider}
    for key, val in [
        ("accessKeyId", access_key_id),
        ("secretAccessKey", secret_access_key),
        ("projectId", project_id),
        ("clientEmail", client_email),
        ("privateKey", private_key),
        ("applicationId", application_id),
        ("secret", secret),
        ("subscriptionId", subscription_id),
        ("directoryId", directory_id),
        ("apiKey", api_key),
    ]:
        if val is not None:
            credential[key] = val

    _client().save_credential(name, credential)
    return f'Credential "{name}" saved successfully for {cloud_provider}.'


@mcp.tool()
def credentials_delete(name: str) -> str:
    """Delete a saved credential set."""
    _client().delete_credential(name)
    return f'Credential "{name}" deleted successfully.'


def _run_cli(args: list[str]) -> str:
    """Run the anycloud CLI and return combined stdout/stderr. Raises on non-zero exit."""
    try:
        result = subprocess.run(
            ["anycloud", *args],
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
        return (result.stdout or "") + (result.stderr or "")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(e.stderr or e.stdout or str(e)) from e


@mcp.tool()
def credentials_import_aws(
    name: str,
    profile: str = "default",
    overwrite: bool = False,
) -> str:
    """Import AWS credentials from a local AWS CLI profile (~/.aws/credentials).

    Args:
        name: Name to save credentials under.
        profile: AWS CLI profile to read from.
        overwrite: Replace existing credentials with the same name.
    """
    args = ["credentials", "import", "aws", name, "--profile", profile]
    if overwrite:
        args.append("--overwrite")
    return _run_cli(args)


@mcp.tool()
def credentials_import_gcp(
    name: str,
    key_file: str | None = None,
    overwrite: bool = False,
) -> str:
    """Import GCP credentials from a service-account JSON key file or Application Default Credentials.

    Args:
        name: Name to save credentials under.
        key_file: Path to service-account JSON. Defaults to $GOOGLE_APPLICATION_CREDENTIALS or the ADC location.
        overwrite: Replace existing credentials with the same name.
    """
    args = ["credentials", "import", "gcp", name]
    if key_file:
        args += ["--key-file", key_file]
    if overwrite:
        args.append("--overwrite")
    return _run_cli(args)


@mcp.tool()
def credentials_generate_aws(
    name: str,
    profile: str = "default",
    overwrite: bool = False,
) -> str:
    """Provision a new AWS IAM user via the AWS CLI and save its access key.

    Requires the AWS CLI to be installed and authenticated.

    Args:
        name: Name for the credential set (IAM user gets "anycloud-" prefix).
        profile: AWS CLI profile to use for provisioning.
        overwrite: Replace existing credentials with the same name.
    """
    args = ["credentials", "generate", "aws", name, "--profile", profile]
    if overwrite:
        args.append("--overwrite")
    return _run_cli(args)


@mcp.tool()
def credentials_generate_azure(
    name: str,
    subscription: str,
    overwrite: bool = False,
) -> str:
    """Provision a new Azure service principal via the az CLI and save its secret.

    Requires the Azure CLI to be installed and authenticated.

    Args:
        name: Name for the credential set (service principal gets "anycloud-" prefix).
        subscription: Azure subscription ID to scope the service principal to.
        overwrite: Replace existing credentials with the same name.
    """
    args = [
        "credentials", "generate", "azure", name,
        "--subscription", subscription,
    ]
    if overwrite:
        args.append("--overwrite")
    return _run_cli(args)


@mcp.tool()
def credentials_generate_gcp(
    name: str,
    project: str,
    overwrite: bool = False,
) -> str:
    """Provision a new GCP service account via the gcloud CLI and save its key.

    Requires the gcloud CLI to be installed and authenticated.

    Args:
        name: Name for the credential set (service account gets "anycloud-" prefix).
        project: GCP project ID to create the service account in.
        overwrite: Replace existing credentials with the same name.
    """
    args = [
        "credentials", "generate", "gcp", name,
        "--project", project,
    ]
    if overwrite:
        args.append("--overwrite")
    return _run_cli(args)


# --- Deployment tools ---


@mcp.tool()
def submit(
    image: str,
    credentials: str,
    id: str | None = None,
    region: str | None = None,
    vm_type: str | None = None,
    spot: bool | None = None,
    disk_size_gb: int | None = None,
    input_bucket: str | None = None,
    output_bucket: str | None = None,
    input_storage_credentials: str | None = None,
    input_storage_region: str | None = None,
    output_storage_credentials: str | None = None,
    output_storage_region: str | None = None,
    availability_zone: str | None = None,
    env: dict[str, str] | None = None,
    persist: bool = False,
    command: list[str] | None = None,
    gpus: str | None = None,
    memory: str | None = None,
    cpus: str | None = None,
    shm_size: str | None = None,
    ipc: str | None = None,
    runtime: str | None = None,
) -> str:
    """Submit a containerized job to run on cloud infrastructure."""
    client = _client()
    cred = client.get_credential(credentials)

    cloud_config: dict[str, Any] = {"cloudProvider": cred["cloudProvider"]}
    for key, val in [
        ("region", region), ("vmType", vm_type), ("spot", spot),
        ("diskSizeGb", disk_size_gb), ("inputBucket", input_bucket),
        ("outputBucket", output_bucket),
        ("inputStorageRegion", input_storage_region),
        ("outputStorageRegion", output_storage_region),
        ("availabilityZone", availability_zone),
    ]:
        if val is not None:
            cloud_config[key] = val

    docker_fields = [
        ("gpus", gpus), ("memory", memory), ("cpus", cpus),
        ("shmSize", shm_size), ("ipc", ipc), ("runtime", runtime),
    ]
    docker_options = {k: v for k, v in docker_fields if v} or None

    body: dict[str, Any] = {
        "image": image,
        "deploymentType": "job",
        "version": _SDK_VERSION,
        "accessToken": client._access_token,
        "cloudConfig": cloud_config,
        "credentialName": credentials,
    }
    for key, val in [
        ("inputStorageCredentialName", input_storage_credentials),
        ("outputStorageCredentialName", output_storage_credentials),
        ("id", id),
        ("env", env), ("dockerOptions", docker_options), ("command", command),
    ]:
        if val:
            body[key] = val
    if persist:
        body["persist"] = True

    data = client._post("/v1/new", body)
    return f"Job submitted successfully.\nDeployment ID: {data['id']}"


@mcp.tool()
def serve(
    image: str,
    credentials: str,
    id: str | None = None,
    region: str | None = None,
    vm_type: str | None = None,
    disk_size_gb: int | None = None,
    availability_zone: str | None = None,
    env: dict[str, str] | None = None,
    command: list[str] | None = None,
    gpus: str | None = None,
    memory: str | None = None,
    cpus: str | None = None,
    shm_size: str | None = None,
    ipc: str | None = None,
    runtime: str | None = None,
) -> str:
    """Deploy a long-running server accessible at https://<id>.anycloud.sh. The container must listen on port 8088."""
    client = _client()
    cred = client.get_credential(credentials)

    cloud_config: dict[str, Any] = {"cloudProvider": cred["cloudProvider"]}
    for key, val in [
        ("region", region), ("vmType", vm_type),
        ("diskSizeGb", disk_size_gb), ("availabilityZone", availability_zone),
    ]:
        if val is not None:
            cloud_config[key] = val

    docker_fields = [
        ("gpus", gpus), ("memory", memory), ("cpus", cpus),
        ("shmSize", shm_size), ("ipc", ipc), ("runtime", runtime),
    ]
    docker_options = {k: v for k, v in docker_fields if v} or None

    body: dict[str, Any] = {
        "image": image,
        "deploymentType": "server",
        "version": _SDK_VERSION,
        "accessToken": client._access_token,
        "cloudConfig": cloud_config,
        "credentialName": credentials,
    }
    for key, val in [
        ("id", id), ("env", env), ("dockerOptions", docker_options), ("command", command),
    ]:
        if val:
            body[key] = val

    data = client._post("/v1/new", body)
    return f"Server deployed.\nID: {data['id']}\nURL: https://{data['id']}.anycloud.sh"


@mcp.tool(name="list")
def list_deployments(filter: str | None = None, limit: int | None = None) -> str:
    """List all deployments, optionally filtered by id, image, cloud, region, or state (substring match).

    Args:
        filter: Substring filter (case-insensitive).
        limit: Max deployments to return. Omit for last-24h with 200 fallback; pass a positive number to cap.
    """
    deployments = _client().list(limit=limit if limit is not None else 0)

    if filter:
        f = filter.lower()
        deployments = [
            d for d in deployments
            if f in d.id.lower()
            or f in d.image.lower()
            or f in (d.cloud_provider or "").lower()
            or f in (d.region or "").lower()
            or f in d.state.lower()
        ]

    if not deployments:
        return f'No deployments matching "{filter}".' if filter else "No deployments found."

    return _dump(deployments)


@mcp.tool()
def cost(id: str | None = None, period: str = "30d") -> str:
    """Get estimated compute costs. Returns deployment data with pricePerHour and vmDurationMs fields for cost calculation. Use period like "7d", "30d", "90d", or "all"."""
    deployments = _client().list(limit=0)
    now_ms = int(time.time() * 1000)

    if id:
        deployment = next((d for d in deployments if d.id == id), None)
        if not deployment:
            raise ValueError(f'Deployment "{id}" not found.')
        return _dump(deployment)

    if period == "all":
        period_ms: int | None = None
    else:
        m = re.match(r"^(\d+)d$", period)
        if not m:
            raise ValueError(f'Invalid period "{period}". Use "7d", "30d", "90d", or "all".')
        period_ms = int(m.group(1)) * 86_400_000

    window_start = (now_ms - period_ms) if period_ms else 0
    overlapping = [
        d for d in deployments
        if (d.completed_at or now_ms) > window_start and d.started_at < now_ms
    ]
    return _dump(overlapping)


@mcp.tool()
def status(id: str) -> str:
    """Get deployment status, events, and VM details."""
    return _dump(_client()._status(id))


@mcp.tool()
def logs(id: str) -> str:
    """Get container logs for a deployment."""
    output = Job(_client(), id).logs()
    return output or "No logs available yet."


@mcp.tool()
def terminate(id: str) -> str:
    """Terminate a deployment and clean up cloud resources."""
    _client()._terminate(id)
    return f"Deployment {id} termination initiated."


@mcp.tool()
def resubmit(id: str) -> str:
    """Resubmit a failed or completed deployment."""
    _client()._resubmit(id)
    return f"Deployment {id} resubmitted."


@mcp.tool(name="exec")
def exec_command(id: str, command: str, vm_host: bool = False) -> str:
    """Execute a command on a running deployment via SSH.

    Args:
        id: Deployment id.
        command: Shell command to execute.
        vm_host: If True, run on the VM host instead of inside the container.
    """
    return Job(_client(), id).exec(command, vm=vm_host)


# --- Bucket tools ---


@mcp.tool()
def bucket_upload(
    bucket_name: str,
    local_path: str,
    remote_path: str = "",
    credentials: str | None = None,
) -> str:
    """Upload a local file or directory to a cloud bucket.

    The bucket is auto-created if it doesn't exist. Runs directly against
    the provider's storage API using the saved credential — no VM involved.

    Args:
        bucket_name: Name of the bucket.
        local_path: File or directory on the MCP host (``~`` is expanded).
        remote_path: Optional sub-path inside the bucket.
        credentials: Credential name. If omitted, uses the sole saved credential.
    """
    client = Client(credentials=credentials) if credentials else _client()
    client.bucket(bucket_name).upload(local_path, remote_path)
    dest = f"{bucket_name}/{remote_path}" if remote_path else bucket_name
    return f'Uploaded "{local_path}" to "{dest}".'


@mcp.tool()
def bucket_download(
    bucket_name: str,
    local_path: str,
    remote_path: str = "",
    credentials: str | None = None,
) -> str:
    """Download bucket contents to a local path on the MCP host.

    Args:
        bucket_name: Name of the bucket.
        local_path: Destination directory on the MCP host (``~`` is expanded).
        remote_path: Optional sub-path inside the bucket.
        credentials: Credential name. If omitted, uses the sole saved credential.
    """
    client = Client(credentials=credentials) if credentials else _client()
    client.bucket(bucket_name).download(local_path, remote_path)
    src = f"{bucket_name}/{remote_path}" if remote_path else bucket_name
    return f'Downloaded "{src}" to "{local_path}".'


# --- Build tool ---


@mcp.tool()
def build(
    target_image: str,
    base: str = "python:3.11",
    pip_install: list[str] | None = None,
    apt_install: list[str] | None = None,
    env_vars: dict[str, str] | None = None,
    workdir: str | None = None,
    run_commands: list[str] | None = None,
    credentials: str | None = None,
    region: str | None = None,
    vm_type: str | None = None,
    deployment_id: str | None = None,
) -> str:
    """Build a Docker image on a remote VM and push it to a registry.

    Args:
        target_image: Full registry path for the built image (e.g. ``ghcr.io/user/repo:v1``).
        base: Base image for the FROM instruction.
        pip_install: Python packages to pip-install.
        apt_install: Debian packages to apt-install.
        env_vars: ENV variables to bake into the image.
        workdir: WORKDIR inside the image.
        run_commands: Extra RUN commands appended verbatim.
        credentials: Credential name for the build VM.
        region: Override region for the build VM.
        vm_type: Override VM type for the build VM.
        deployment_id: Custom deployment ID for the build job.
    """
    from anycloud.image import Image

    img = Image(base)
    if apt_install:
        img = img.apt_install(*apt_install)
    if pip_install:
        img = img.pip_install(*pip_install)
    if env_vars:
        img = img.env(env_vars)
    if workdir:
        img = img.workdir(workdir)
    if run_commands:
        for cmd in run_commands:
            img = img.run_commands(cmd)

    client = Client(credentials=credentials) if credentials else _client()

    cloud_config = None
    if region or vm_type:
        cc = client._default_cloud_config
        if cc is None:
            raise ValueError(
                "No default cloud config. Pass `credentials` or configure a credential first."
            )
        updates: dict[str, Any] = {}
        if region:
            updates["region"] = region
        if vm_type:
            updates["vm_type"] = vm_type
        cloud_config = cc.model_copy(update=updates)

    job = client.build(
        img,
        target_image,
        cloud_config=cloud_config,
        deployment_id=deployment_id,
    )
    return f"Build started.\nDeployment ID: {job.id}\nTarget: {target_image}"


# --- Upgrade tool ---


@mcp.tool()
def upgrade(version: str | None = None) -> str:
    """Upgrade anycloud CLI and restart the API server."""
    lines: list[str] = []

    try:
        cmd = ["anycloud", "update"] + ([version] if version else [])
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=120)
        lines.append(f"CLI upgraded{f' to {version}' if version else ' to latest stable'}.")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"CLI upgrade failed: {e.stderr or e.stdout or str(e)}") from e

    try:
        subprocess.run(["anycloud", "api", "stop"], capture_output=True, text=True, timeout=30)
    except Exception:
        pass

    try:
        subprocess.run(
            ["anycloud", "api", "start"], check=True, capture_output=True, text=True, timeout=60
        )
        lines.append("API server restarted with new version.")
    except Exception as e:
        lines.append(f'Warning: API restart failed: {e}. Run "anycloud api start" manually.')

    lines += ["", "IMPORTANT: Restart the MCP server to pick up the new CLI version."]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
