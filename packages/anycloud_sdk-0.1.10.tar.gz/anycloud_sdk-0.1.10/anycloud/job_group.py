"""JobGroup — manage a batch of Jobs."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Iterator, Union

from anycloud.errors import JobGroupError
from anycloud.job import Job


JobOrError = Union[Job, Exception]


class JobGroup:
    """A thin wrapper around a list of :class:`Job` instances returned by
    :meth:`Client.submit_many` and :meth:`Function.map`.

    Provides parallel ``wait()`` and ``terminate()`` across the batch.

    Usage::

        jobs = ac.submit_many([
            Submission(image="worker:latest", env={"SHARD": str(i)})
            for i in range(4)
        ])
        jobs.wait()           # blocks until every job finishes
        jobs.terminate()      # kill everything

    With ``return_exceptions=True``, individual entries may be ``Exception``
    instances (one per failed submission, in input order). ``wait``,
    ``terminate``, and ``ids`` skip these entries silently.

    ``JobGroup`` cannot be constructed directly — use ``submit_many`` or
    ``fn.map`` to produce one. This prevents the common trap of submitting
    sequentially in a list comprehension.
    """

    def __init__(self, *_args: Any, **_kwargs: Any):
        raise TypeError(
            "JobGroup cannot be constructed directly. "
            "Use client.submit_many([Submission(...), ...]) or fn.map(...) "
            "to submit jobs in parallel."
        )

    @classmethod
    def _create(cls, items: list[JobOrError]) -> JobGroup:
        """Internal factory — used by Client.submit_many and Function.map."""
        obj = cls.__new__(cls)
        obj._items: list[JobOrError] = list(items)
        return obj

    # ------------------------------------------------------------------
    # Sequence protocol
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._items)

    def __iter__(self) -> Iterator[JobOrError]:
        return iter(self._items)

    def __getitem__(self, index: int) -> JobOrError:
        return self._items[index]

    @property
    def _jobs(self) -> list[Job]:
        return [item for item in self._items if isinstance(item, Job)]

    # ------------------------------------------------------------------
    # Parallel wait
    # ------------------------------------------------------------------

    def wait(
        self,
        *,
        timeout: float | None = None,
        poll_interval: float = 2.0,
        max_workers: int | None = None,
    ) -> JobGroup:
        """Block until every job reaches a terminal state.

        Polls all jobs in parallel using a thread pool. Exception entries
        from a ``return_exceptions=True`` submit are skipped.

        Returns ``self`` if all jobs completed successfully.
        Raises :class:`~anycloud.errors.JobGroupError` if any job failed
        (all jobs are still awaited before the error is raised).

        Args:
            timeout: Per-job timeout in seconds (``None`` = no limit).
            poll_interval: Seconds between status polls per job.
            max_workers: Thread pool size (defaults to number of jobs).
        """
        jobs = self._jobs
        if not jobs:
            return self
        workers = max_workers or len(jobs)
        errors: list[tuple[str, Exception]] = []

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(
                    job.wait, timeout=timeout, poll_interval=poll_interval
                ): job
                for job in jobs
            }
            for future in as_completed(futures):
                job = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    errors.append((job.id, exc))

        if errors:
            raise JobGroupError(errors)
        return self

    # ------------------------------------------------------------------
    # Parallel terminate
    # ------------------------------------------------------------------

    def terminate(self, *, max_workers: int | None = None) -> None:
        """Terminate every job in parallel. Exception entries are skipped."""
        jobs = self._jobs
        if not jobs:
            return
        workers = max_workers or len(jobs)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(lambda j: j.terminate(), jobs))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @property
    def ids(self) -> list[str]:
        """Deployment IDs of successful jobs in the group (skips Exception entries)."""
        return [j.id for j in self._jobs]

    @property
    def errors(self) -> list[tuple[int, Exception]]:
        """``[(input_index, exception), ...]`` for failed entries (return_exceptions=True only)."""
        return [(i, item) for i, item in enumerate(self._items) if isinstance(item, Exception)]

    def __repr__(self) -> str:
        return f"JobGroup({self.ids})"
