"""anycloud Client — submit jobs, manage deployments."""

from __future__ import annotations

import json
import os
import re
from concurrent.futures import ThreadPoolExecutor
from importlib.metadata import version as _pkg_version
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import quote as _url_quote

import httpx

from anycloud.errors import APIError, BatchSubmitError, ConflictError, NotFoundError
from anycloud.job import Job
from anycloud.job_group import JobGroup
from anycloud.types import (
    AWSCredentials,
    AzureCredentials,
    CloudConfig,
    CloudType,
    Deployment,
    GCPCredentials,
    LambdaCredentials,
    StatusResponse,
    Submission,
)

if TYPE_CHECKING:
    from anycloud.storage import Bucket

from anycloud.image import Image

BUILDER_IMAGE = "ghcr.io/anycloud-sh/builder"

_BUILD_DEFAULTS: dict[str, dict[str, str]] | None = None


def _load_build_defaults() -> dict[str, dict[str, str]]:
    global _BUILD_DEFAULTS
    if _BUILD_DEFAULTS is None:
        defaults_path = Path(__file__).parent / "build-defaults.json"
        with open(defaults_path) as f:
            _BUILD_DEFAULTS = json.load(f)
    return _BUILD_DEFAULTS


def _apply_build_defaults(cc: CloudConfig) -> CloudConfig:
    """Return a copy of *cc* with vmType/region filled from build defaults."""
    defaults = _load_build_defaults()
    provider_defaults = defaults.get(cc.cloud_provider.value, {})
    overrides: dict[str, Any] = {}
    if not cc.vm_type and "vmType" in provider_defaults:
        overrides["vm_type"] = provider_defaults["vmType"]
    if not cc.region and "region" in provider_defaults:
        overrides["region"] = provider_defaults["region"]
    if overrides:
        return cc.model_copy(update=overrides)
    return cc


# Use ANYCLOUD_VERSION env var if set (matches CLI/API convention), otherwise
# fall back to installed package version. Strip PEP 440 pre-release suffixes
# (e.g. "5.20.0rc1" → "5.20.0") so the version passes the API's semver validation.
_SDK_VERSION = os.environ.get("ANYCLOUD_VERSION") or re.sub(
    r"(a|b|rc|dev)\d*$", "", _pkg_version("anycloud-sdk")
)

# Map cloudProvider string → (CloudType, credential model)
_CRED_BUILDERS: dict[str, tuple[CloudType, type]] = {
    "AWS": (CloudType.AWS, AWSCredentials),
    "GCP": (CloudType.GCP, GCPCredentials),
    "Azure": (CloudType.Azure, AzureCredentials),
    "Lambda": (CloudType.Lambda, LambdaCredentials),
}


def _resolve_token() -> str:
    """Resolve auth token from ~/.anycloud/.token or GITHUB_TOKEN env var."""
    token_path = Path(os.environ.get("ANYCLOUD_DIR", str(Path.home() / ".anycloud"))) / ".token"
    try:
        token = token_path.read_text().strip()
        if token:
            return token
    except FileNotFoundError:
        pass
    return os.environ.get("GITHUB_TOKEN", "")


def _quote(s: str) -> str:
    """URL-encode a path segment."""
    return _url_quote(s, safe="")


def _build_cloud_config(name: str, cred_data: dict[str, Any]) -> CloudConfig:
    """Build a ``CloudConfig`` from a credential API response."""
    provider = cred_data.get("cloudProvider")
    if provider not in _CRED_BUILDERS:
        raise ValueError(
            f"Unsupported cloudProvider {provider!r} in credential {name!r}. "
            f"Supported: {', '.join(_CRED_BUILDERS)}"
        )
    cloud_type, cred_cls = _CRED_BUILDERS[provider]
    return CloudConfig(
        cloudProvider=cloud_type,
        credentials=cred_cls.model_validate(cred_data),
    )


class Client:
    """anycloud Python client.

    Usage::

        # Simplest — auto-loads credentials from the API
        ac = Client()
        job = ac.submit("train:latest", gpu="h100:8")

        # Multiple credential sets — pick one by name
        ac = Client(credentials="aws-prod")

        # Explicit cloud config (always works)
        ac = Client(cloud_config=CloudConfig(...))

    Args:
        api_url: Base URL of the API server.
            Falls back to ``API_URL`` env var, then ``http://localhost:8080``.
        cloud_config: Default ``CloudConfig`` applied to every ``submit()`` call.
            Can be overridden per-submit via ``submit(cloud_config=...)``.
        credentials: Name of a saved credential set.
            If only one credential exists, it is used automatically.
            Ignored when *cloud_config* is provided.
    """

    def __init__(
        self,
        *,
        api_url: str | None = None,
        cloud_config: CloudConfig | None = None,
        credentials: str | None = None,
    ):
        token = _resolve_token()
        if not token:
            raise ValueError(
                "No authentication token found. Either:\n"
                "  - Run 'anycloud login' (recommended)\n"
                "  - Set the GITHUB_TOKEN environment variable"
            )
        self._access_token = token

        self._base_url = (
            api_url
            or os.environ.get("API_URL")
            or "http://localhost:8080"
        ).rstrip("/")

        self._http = httpx.Client(base_url=self._base_url, timeout=30.0)
        self._credential_name: str | None = None
        self._default_cloud_config = cloud_config or self._auto_load_cloud_config(
            credentials
        )

    # ------------------------------------------------------------------
    # Credential auto-loading
    # ------------------------------------------------------------------

    def _auto_load_cloud_config(self, name: str | None) -> CloudConfig | None:
        """Try to build a default CloudConfig from the API's credential store.

        Returns ``None`` silently when the API is unreachable or no credentials
        exist (the user can still pass ``cloud_config`` per-submit).
        Raises ``ValueError`` if *name* is given but not found.
        """
        try:
            creds = self.list_credentials()
        except Exception:
            if name is not None:
                raise ValueError(
                    f"Could not load credential {name!r}: API is unreachable"
                )
            return None
        if not creds:
            if name is not None:
                raise ValueError(
                    f"Credential {name!r} not found. No credentials saved."
                )
            return None

        if name is not None:
            names = [c["name"] for c in creds]
            if name not in names:
                raise ValueError(
                    f"Credential {name!r} not found. "
                    f"Available: {', '.join(names)}"
                )
            self._credential_name = name
            full = self._get(f"/v1/credentials/{_quote(name)}/full")
            return _build_cloud_config(name, full)

        if len(creds) == 1:
            only_name = creds[0]["name"]
            self._credential_name = only_name
            full = self._get(f"/v1/credentials/{_quote(only_name)}/full")
            return _build_cloud_config(only_name, full)

        # Multiple entries, none selected — don't guess
        return None

    def _resolve_credential(self, name: str) -> CloudConfig:
        """Resolve a credential name to a ``CloudConfig``.

        Raises ``ValueError`` if the credential is not found.
        """
        full = self._get(f"/v1/credentials/{_quote(name)}/full")
        return _build_cloud_config(name, full)

    # ------------------------------------------------------------------
    # Bucket operations
    # ------------------------------------------------------------------

    def bucket(self, name: str) -> Bucket:
        """Get a :class:`Bucket` handle for use with ``submit()`` and
        data transfer.

        The handle is lazy — no cloud calls are made until you call
        ``.upload()`` or ``.download()``.  Output buckets are
        auto-created by the server when passed to ``submit(output=…)``.
        Input buckets are auto-created by ``.upload()`` if they don't
        exist yet.
        """
        from anycloud.storage import Bucket

        return Bucket(name, self._resolve_storage_config())

    def _resolve_storage_config(self) -> CloudConfig:
        if self._default_cloud_config is None:
            raise ValueError(
                "A cloud_config is required for bucket operations. "
                "Pass cloud_config=CloudConfig(...) to Client()."
            )
        return self._default_cloud_config

    # ------------------------------------------------------------------
    # Core: submit
    # ------------------------------------------------------------------

    def submit(
        self,
        image: str | Submission,
        *,
        cloud_config: CloudConfig | None = None,
        gpu: str | None = None,
        env: dict[str, str] | None = None,
        secrets: list[str] | None = None,
        docker_options: dict[str, Any] | None = None,
        command: list[str] | None = None,
        persist: bool | None = None,
        deployment_id: str | None = None,
        image_digest: str | None = None,
        input: Bucket | None = None,
        output: Bucket | None = None,
        credential_name: str | None = None,
    ) -> Job:
        """Submit a job and return a ``Job`` promise.

        Accepts either a Docker image string plus kwargs, or a pre-built
        :class:`Submission` object::

            job = ac.submit("train:latest", gpu="h100:8")        # inline
            job = ac.submit(Submission(image="train:latest", gpu="h100:8"))  # programmatic

        Args:
            image: Docker image reference or a :class:`Submission`.
            cloud_config: ``CloudConfig`` specifying provider, credentials, region, etc.
                Falls back to the default set on ``Client(cloud_config=...)``.
            gpu: GPU type shorthand (e.g. ``"h100:8"``).
            env: Environment variables passed to the container.
            docker_options: Docker runtime options (shmSize, gpus, etc.).
            command: Override container CMD.
            persist: Keep VM alive after job completion.
            deployment_id: Custom deployment ID (auto-generated if omitted).
            image_digest: Docker image digest (e.g. ``"sha256:abc..."``).
            input: A :class:`Bucket` to mount as ``/mnt/input`` (read-only).
            output: A :class:`Bucket` to mount as ``/mnt/output`` (write, synced).

        Returns:
            A ``Job`` handle you can poll or wait on.
        """
        if isinstance(image, Submission):
            set_extras = [
                name for name, val in (
                    ("cloud_config", cloud_config),
                    ("gpu", gpu),
                    ("env", env),
                    ("secrets", secrets),
                    ("docker_options", docker_options),
                    ("command", command),
                    ("persist", persist),
                    ("deployment_id", deployment_id),
                    ("image_digest", image_digest),
                    ("input", input),
                    ("output", output),
                    ("credential_name", credential_name),
                ) if val is not None
            ]
            if set_extras:
                raise TypeError(
                    "Pass either a Submission or kwargs to submit(), not both. "
                    f"Got Submission plus kwargs: {set_extras}"
                )
            return self._submit_one(image)

        return self._submit_one(Submission(
            image=image,
            cloud_config=cloud_config,
            gpu=gpu,
            env=env,
            secrets=secrets,
            docker_options=docker_options,
            command=command,
            persist=bool(persist),
            deployment_id=deployment_id,
            image_digest=image_digest,
            input=input,
            output=output,
            credential_name=credential_name,
        ))

    def submit_many(
        self,
        submissions: list[Submission],
        *,
        max_workers: int | None = None,
        return_exceptions: bool = False,
    ) -> JobGroup:
        """Submit N jobs in parallel and return a :class:`JobGroup`.

        Each ``Submission`` is independently configured — images, GPU,
        env, etc. may all differ across the batch.

        By default, raises :class:`~anycloud.errors.BatchSubmitError` if any
        submission fails; the successful Jobs are still attached to the error
        so the caller can wait on them or terminate them. With
        ``return_exceptions=True``, returns a JobGroup whose entries are
        either ``Job`` (success) or ``Exception`` (failure), in input order.

        Example::

            jobs = ac.submit_many([
                Submission(image="features:latest", output=shared),
                Submission(image="labels:latest",   output=shared),
            ])
            jobs.wait()

        Args:
            submissions: List of :class:`Submission` objects.
            max_workers: Thread pool size (defaults to len(submissions)).
            return_exceptions: If True, never raise on submission failure;
                instead return a JobGroup with mixed ``Job | Exception`` entries.

        Returns:
            A :class:`JobGroup` whose entries match the input order.
        """
        if not submissions:
            return JobGroup._create([])
        workers = max_workers or len(submissions)

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = [pool.submit(self._submit_one, s) for s in submissions]
            results: list = []
            for fut in futures:
                try:
                    results.append(fut.result())
                except Exception as e:
                    results.append(e)

        if not return_exceptions:
            errors = [(i, r) for i, r in enumerate(results) if isinstance(r, Exception)]
            if errors:
                submitted = [r for r in results if isinstance(r, Job)]
                raise BatchSubmitError(submitted=submitted, errors=errors)

        return JobGroup._create(results)

    def _submit_one(self, s: Submission) -> Job:
        """Issue a single submission. Internal — used by submit and submit_many."""
        cloud_config = self._apply_storage(s.cloud_config, s.input, s.output)
        body = self._build_request_body(
            image=s.image,
            gpu=s.gpu,
            env=s.env,
            secrets=s.secrets,
            docker_options=s.docker_options,
            command=s.command,
            persist=s.persist,
            deployment_id=s.deployment_id,
            cloud_config=cloud_config,
            image_digest=s.image_digest,
            credential_name=s.credential_name,
        )
        data = self._submit_raw(body)
        return Job(self, data["id"])

    # ------------------------------------------------------------------
    # Core: serve
    # ------------------------------------------------------------------

    def serve(
        self,
        image: str,
        *,
        cloud_config: CloudConfig | None = None,
        gpu: str | None = None,
        env: dict[str, str] | None = None,
        secrets: list[str] | None = None,
        docker_options: dict[str, Any] | None = None,
        command: list[str] | None = None,
        deployment_id: str | None = None,
        image_digest: str | None = None,
        credential_name: str | None = None,
    ) -> Job:
        """Deploy a long-running server and return a ``Job`` handle.

        The container must listen on port 8088 (set via ``PORT`` env var).
        Once running, the server is accessible at
        ``https://<deployment-id>.anycloud.sh``.

        Args:
            image: Docker image reference (e.g. ``"nginx:latest"``).
            cloud_config: ``CloudConfig`` specifying provider, credentials, region, etc.
                Falls back to the default set on ``Client(cloud_config=...)``.
            gpu: GPU type shorthand (e.g. ``"h100:8"``).
            env: Environment variables passed to the container.
            docker_options: Docker runtime options (shmSize, gpus, etc.).
            command: Override container CMD.
            deployment_id: Custom deployment ID (auto-generated if omitted).
            image_digest: Docker image digest (e.g. ``"sha256:abc..."``).

        Returns:
            A ``Job`` handle. Use ``job.url`` for the HTTPS URL.
        """
        body = self._build_request_body(
            image=image,
            gpu=gpu,
            env=env,
            secrets=secrets,
            docker_options=docker_options,
            command=command,
            persist=False,
            deployment_id=deployment_id,
            cloud_config=cloud_config,
            image_digest=image_digest,
            credential_name=credential_name,
            deployment_type="server",
        )

        data = self._submit_raw(body)
        return Job(self, data["id"])

    # ------------------------------------------------------------------
    # Core: build
    # ------------------------------------------------------------------

    def build(
        self,
        image: Image,
        target_image: str | None = None,
        *,
        cloud_config: CloudConfig | None = None,
        deployment_id: str | None = None,
    ) -> Job:
        """Submit a remote build job. Returns a ``Job`` handle.

        Provisions a VM, builds a Docker image from the provided ``Image``
        definition, and pushes it to the target registry. Uses the conductor's
        builder image with Docker socket mount.

        Args:
            image: An ``Image`` object defining the Dockerfile to build.
            target_image: Full registry path to push the built image
                (e.g. ``"ghcr.io/user/repo:v1"``). Defaults to ``image.ref``
                when the ``Image`` has a repository set.
            cloud_config: ``CloudConfig`` for the build VM.
                Falls back to the default set on ``Client(cloud_config=...)``.
                If no ``vm_type`` is set, build-specific defaults are applied.
            deployment_id: Custom deployment ID (auto-generated if omitted).

        Returns:
            A ``Job`` handle you can poll or wait on.
        """
        target_image = target_image or image.ref
        dockerfile = image.to_dockerfile()

        cc = cloud_config or self._default_cloud_config
        if cc is None:
            raise ValueError(
                "A cloud config is required. Pass cloud_config=CloudConfig(...) "
                "or set a default via Client(cloud_config=...)."
            )
        # Apply build-specific VM defaults if no vmType specified
        if not cc.vm_type:
            cc = _apply_build_defaults(cc)

        return self.submit(
            BUILDER_IMAGE,
            env={
                "DOCKERFILE": dockerfile,
                "TARGET_IMAGE": target_image,
            },
            docker_options={"binds": ["/var/run/docker.sock:/var/run/docker.sock"]},
            cloud_config=cc,
            deployment_id=deployment_id,
        )

    # ------------------------------------------------------------------
    # Deployment management
    # ------------------------------------------------------------------

    def list(self, *, limit: int = 20) -> list[Deployment]:
        """List recent deployments."""
        data = self._post("/v1/list", {
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
            "limit": limit,
        })
        return [Deployment.model_validate(d) for d in data]

    def get(self, deployment_id: str) -> Job:
        """Get a ``Job`` handle for an existing deployment."""
        return Job(self, deployment_id)

    # ------------------------------------------------------------------
    # Internal API calls (used by Job)
    # ------------------------------------------------------------------

    def _submit_raw(self, body: dict[str, Any]) -> dict[str, Any]:
        """POST /v1/new and return the response dict."""
        return self._post("/v1/new", body)

    def _status(self, deployment_id: str, *, verbose: bool = False) -> StatusResponse:
        body: dict[str, Any] = {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        }
        if verbose:
            body["verbose"] = True
        data = self._post("/v1/status", body)
        return StatusResponse.model_validate(data)

    def _terminate(self, deployment_id: str) -> None:
        self._post("/v1/terminate", {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        })

    def _resubmit(self, deployment_id: str) -> None:
        self._post("/v1/resubmit", {
            "id": deployment_id,
            "accessToken": self._access_token,
            "version": _SDK_VERSION,
        })

    # ------------------------------------------------------------------
    # Catalog
    # ------------------------------------------------------------------

    def get_regions(self, cloud_provider: str) -> list[str]:
        """List available cloud regions for a provider."""
        return self._get("/v1/catalog/regions", {"cloudProvider": cloud_provider})

    def get_vm_types(
        self,
        cloud_provider: str,
        region: str,
        *,
        accelerator: str | None = None,
    ) -> list[str]:
        """List available VM types for a provider and region.

        Args:
            cloud_provider: Cloud provider name (AWS, GCP, Azure, Lambda).
            region: Cloud region (e.g. ``"us-east-1"``).
            accelerator: Filter by GPU type (e.g. ``"H100"``, ``"*"`` for all GPUs).
        """
        params: dict[str, str] = {"cloudProvider": cloud_provider, "region": region}
        if accelerator:
            params["accelerator"] = accelerator
        return self._get("/v1/catalog/vm-types", params)

    def get_zones(self, region: str) -> list[str]:
        """List available GCP zone suffixes for a region."""
        return self._get("/v1/catalog/zones", {"region": region})

    def get_regions_for_vm_type(
        self,
        vm_type: str,
        cloud_provider: str,
        *,
        spot: bool = False,
    ) -> list[str]:
        """List regions where a VM type is available, sorted by price."""
        params: dict[str, str] = {"vmType": vm_type, "cloudProvider": cloud_provider}
        if spot:
            params["spot"] = "true"
        return self._get("/v1/catalog/regions-for-vm-type", params)

    def get_pricing(
        self,
        vm_type: str,
        cloud_provider: str,
        *,
        region: str | None = None,
        spot: bool = False,
    ) -> dict[str, Any]:
        """Get pricing for a VM type across regions (or for a specific region)."""
        params: dict[str, str] = {"vmType": vm_type, "cloudProvider": cloud_provider}
        if region:
            params["region"] = region
        if spot:
            params["spot"] = "true"
        return self._get("/v1/catalog/pricing", params)

    def get_gpus(self, cloud_provider: str) -> list[str]:
        """List available GPU/accelerator names for a cloud provider."""
        return self._get("/v1/catalog/gpus", {"cloudProvider": cloud_provider})

    def get_gpu_counts(self, gpu_name: str, cloud_provider: str) -> list[int]:
        """Get available GPU counts for an accelerator (e.g. [1, 2, 4, 8])."""
        return self._get("/v1/catalog/gpu-counts", {"gpuName": gpu_name, "cloudProvider": cloud_provider})

    # ------------------------------------------------------------------
    # Credentials
    # ------------------------------------------------------------------

    def list_credentials(self) -> list[dict[str, str]]:
        """List saved cloud credentials (secrets redacted)."""
        return self._get("/v1/credentials")

    def get_credential(self, name: str) -> dict[str, str]:
        """Get a single credential (secrets redacted)."""
        return self._get(f"/v1/credentials/{_quote(name)}")

    def save_credential(self, name: str, credential: dict[str, Any]) -> dict[str, Any]:
        """Save a cloud credential set.

        Args:
            name: Name for this credential set.
            credential: Credential data including ``cloudProvider`` and
                provider-specific fields (e.g. ``accessKeyId``, ``secretAccessKey``
                for AWS).
        """
        return self._authed_post("/v1/credentials", {"name": name, **credential})

    def delete_credential(self, name: str) -> None:
        """Delete a saved credential set."""
        self._authed_delete(f"/v1/credentials/{_quote(name)}")

    # ------------------------------------------------------------------
    # Secrets
    # ------------------------------------------------------------------

    def list_secrets(self) -> list[dict[str, Any]]:
        """List saved secrets (names and timestamps only — values are never returned)."""
        return self._get("/v1/secrets")

    def create_secret(
        self, name: str, values: dict[str, str]
    ) -> dict[str, Any]:
        """Create or update a named secret.

        Args:
            name: Secret name (letters, digits, underscore, hyphen).
            values: Mapping of env-var name to value. Injected into the
                container at run time when referenced via ``secrets=["name"]``
                on :meth:`submit` or :meth:`serve`.
        """
        return self._authed_post(
            "/v1/secrets", {"name": name, "values": values}
        )

    def delete_secret(self, name: str, *, force: bool = False) -> None:
        """Delete a saved secret.

        Blocked with `ConflictError` when non-terminal deployments reference
        the secret. Pass `force=True` to override.
        """
        path = f"/v1/secrets/{_quote(name)}"
        if force:
            path += "?force=true"
        self._authed_delete(path)

    # ------------------------------------------------------------------
    # HTTP
    # ------------------------------------------------------------------

    @property
    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._access_token}"}

    def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        """GET request with Bearer auth."""
        resp = self._http.get(path, params=params, headers=self._auth_headers)
        if resp.status_code == 404:
            raise NotFoundError(resp.text)
        if resp.status_code >= 400:
            if "not found" in resp.text.lower():
                raise NotFoundError(resp.text)
            raise APIError(resp.status_code, resp.text)
        return resp.json()

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        resp = self._http.post(path, json=body)
        if resp.status_code == 409:
            raise ConflictError(resp.text)
        if resp.status_code == 404:
            raise NotFoundError(resp.text)
        if resp.status_code >= 400:
            # /v1/status returns 400 (not 404) for missing deployments
            if "not found" in resp.text.lower():
                raise NotFoundError(resp.text)
            raise APIError(resp.status_code, resp.text)
        return resp.json()

    def _authed_post(self, path: str, body: dict[str, Any]) -> Any:
        """POST request with Bearer auth (for new-style endpoints)."""
        resp = self._http.post(path, json=body, headers=self._auth_headers)
        if resp.status_code == 409:
            raise ConflictError(resp.text)
        if resp.status_code == 404:
            raise NotFoundError(resp.text)
        if resp.status_code >= 400:
            if "not found" in resp.text.lower():
                raise NotFoundError(resp.text)
            raise APIError(resp.status_code, resp.text)
        return resp.json()

    def _authed_delete(self, path: str) -> Any:
        """DELETE request with Bearer auth."""
        resp = self._http.request("DELETE", path, headers=self._auth_headers)
        if resp.status_code == 404:
            raise NotFoundError(resp.text)
        if resp.status_code == 409:
            raise ConflictError(resp.text)
        if resp.status_code >= 400:
            if "not found" in resp.text.lower():
                raise NotFoundError(resp.text)
            raise APIError(resp.status_code, resp.text)
        if resp.headers.get("content-type", "").startswith("application/json"):
            return resp.json()
        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _apply_storage(
        self,
        cloud_config: CloudConfig | None,
        input: Bucket | None,
        output: Bucket | None,
    ) -> CloudConfig | None:
        """Merge Bucket objects into the cloud config for a submit call."""
        if input is None and output is None:
            return cloud_config

        cc = cloud_config or self._default_cloud_config
        if cc is None:
            raise ValueError(
                "A cloud_config is required when using input/output Bucket. "
                "Pass cloud_config=CloudConfig(...) to Client() or submit()."
            )

        # Validate no conflicts with existing bucket fields
        if input is not None and cc.input_bucket:
            raise ValueError(
                "Cannot set both input=Bucket and cloudConfig.inputBucket. "
                "Use one or the other."
            )
        if output is not None and cc.output_bucket:
            raise ValueError(
                "Cannot set both output=Bucket and cloudConfig.outputBucket. "
                "Use one or the other."
            )

        updates: dict[str, Any] = {}

        if input is not None:
            updates["input_bucket"] = input.name
        if output is not None:
            updates["output_bucket"] = output.name

        # Per-bucket cross-cloud credentials: if a bucket's cloud differs from
        # compute, set its storage credentials independently.
        if input is not None and input.cloud_config.cloud_provider != cc.cloud_provider:
            updates["input_storage_credentials"] = input.cloud_config.credentials
            if input.cloud_config.region:
                updates["input_storage_region"] = input.cloud_config.region

        if output is not None and output.cloud_config.cloud_provider != cc.cloud_provider:
            updates["output_storage_credentials"] = output.cloud_config.credentials
            if output.cloud_config.region:
                updates["output_storage_region"] = output.cloud_config.region

        if updates:
            cc = cc.model_copy(update=updates)
        return cc

    def _build_request_body(
        self,
        *,
        image: str,
        gpu: str | None,
        env: dict[str, str] | None,
        secrets: list[str] | None = None,
        docker_options: dict[str, Any] | None,
        command: list[str] | None,
        persist: bool,
        deployment_id: str | None,
        cloud_config: CloudConfig | None,
        image_digest: str | None = None,
        credential_name: str | None = None,
        deployment_type: str = "job",
    ) -> dict[str, Any]:
        cc = cloud_config or self._default_cloud_config
        if cc is None:
            raise ValueError(
                "A cloud config is required. Either:\n"
                "  - Add credentials via 'anycloud credentials new'\n"
                "  - Pass cloud_config=CloudConfig(...) to submit()\n"
                "  - Pass credentials='name' to Client() to select a saved credential"
            )

        body: dict[str, Any] = {
            "image": image,
            "deploymentType": deployment_type,
            "version": _SDK_VERSION,
            "accessToken": self._access_token,
            "cloudConfig": cc.model_dump(by_alias=True, exclude_none=True),
        }

        # Pass credential name for server-side resolution (avoids round-tripping secrets)
        # When credential_name is explicitly provided (e.g. from Function.submit),
        # always include it. Otherwise fall back to client's default only when
        # no per-call cloud_config was given.
        if credential_name is not None:
            body["credentialName"] = credential_name
        elif self._credential_name is not None and cloud_config is None:
            body["credentialName"] = self._credential_name

        if deployment_id is not None:
            body["id"] = deployment_id
        if env is not None:
            body["env"] = env
        if secrets:
            body["secrets"] = list(secrets)
        if persist:
            body["persist"] = True
        if docker_options is not None:
            body["dockerOptions"] = docker_options
        if command is not None:
            body["command"] = command
        if gpu is not None:
            body["gpuType"] = gpu
        if image_digest is not None:
            body["imageDigest"] = image_digest

        return body

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()
