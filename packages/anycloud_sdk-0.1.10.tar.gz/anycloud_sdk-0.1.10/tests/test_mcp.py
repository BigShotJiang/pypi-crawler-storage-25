"""Tests for MCP slurp tools that subprocess to the anycloud CLI."""

import subprocess
from unittest.mock import patch, MagicMock

import pytest

from anycloud import mcp as mcp_mod
from anycloud.mcp import (
    _run_cli,
    credentials_generate_aws,
    credentials_generate_azure,
    credentials_generate_gcp,
    credentials_import_aws,
    credentials_import_gcp,
)


def _ok(stdout: str = "ok", stderr: str = "") -> MagicMock:
    result = MagicMock()
    result.stdout = stdout
    result.stderr = stderr
    result.returncode = 0
    return result


class TestRunCli:
    def test_returns_combined_stdout_stderr(self):
        with patch.object(subprocess, "run", return_value=_ok("out-body", "err-body")) as run:
            out = _run_cli(["credentials", "list"])
        assert out == "out-bodyerr-body"
        args, kwargs = run.call_args
        assert args[0] == ["anycloud", "credentials", "list"]
        assert kwargs["check"] is True
        assert kwargs["capture_output"] is True
        assert kwargs["text"] is True

    def test_raises_runtime_error_on_failure(self):
        err = subprocess.CalledProcessError(1, ["anycloud"], output="", stderr="boom")
        with patch.object(subprocess, "run", side_effect=err):
            with pytest.raises(RuntimeError, match="boom"):
                _run_cli(["credentials", "list"])

    def test_falls_back_to_stdout_when_stderr_empty(self):
        err = subprocess.CalledProcessError(1, ["anycloud"], output="stdout-msg", stderr="")
        with patch.object(subprocess, "run", side_effect=err):
            with pytest.raises(RuntimeError, match="stdout-msg"):
                _run_cli(["credentials", "list"])


class TestCredentialsImportAws:
    def test_default_profile(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            out = credentials_import_aws("my-aws")
        run.assert_called_once_with(
            ["credentials", "import", "aws", "my-aws", "--profile", "default"]
        )
        assert out == "saved"

    def test_custom_profile_and_overwrite(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            credentials_import_aws("my-aws", profile="work", overwrite=True)
        run.assert_called_once_with(
            [
                "credentials", "import", "aws", "my-aws",
                "--profile", "work", "--overwrite",
            ]
        )


class TestCredentialsImportGcp:
    def test_no_key_file(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            credentials_import_gcp("my-gcp")
        run.assert_called_once_with(["credentials", "import", "gcp", "my-gcp"])

    def test_with_key_file(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            credentials_import_gcp("my-gcp", key_file="/tmp/sa.json")
        run.assert_called_once_with(
            ["credentials", "import", "gcp", "my-gcp", "--key-file", "/tmp/sa.json"]
        )

    def test_overwrite_appended(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            credentials_import_gcp("my-gcp", overwrite=True)
        run.assert_called_once_with(
            ["credentials", "import", "gcp", "my-gcp", "--overwrite"]
        )

    def test_key_file_and_overwrite(self):
        with patch.object(mcp_mod, "_run_cli", return_value="saved") as run:
            credentials_import_gcp("my-gcp", key_file="/tmp/sa.json", overwrite=True)
        run.assert_called_once_with(
            [
                "credentials", "import", "gcp", "my-gcp",
                "--key-file", "/tmp/sa.json", "--overwrite",
            ]
        )


class TestCredentialsGenerateAws:
    def test_default_profile(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_aws("prod-aws")
        run.assert_called_once_with(
            ["credentials", "generate", "aws", "prod-aws", "--profile", "default"]
        )

    def test_custom_profile_and_overwrite(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_aws("prod-aws", profile="work", overwrite=True)
        run.assert_called_once_with(
            [
                "credentials", "generate", "aws", "prod-aws",
                "--profile", "work", "--overwrite",
            ]
        )


class TestCredentialsGenerateAzure:
    def test_requires_subscription(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_azure("prod-azure", subscription="sub-123")
        run.assert_called_once_with(
            [
                "credentials", "generate", "azure", "prod-azure",
                "--subscription", "sub-123",
            ]
        )

    def test_overwrite_appended(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_azure("prod-azure", subscription="sub-123", overwrite=True)
        run.assert_called_once_with(
            [
                "credentials", "generate", "azure", "prod-azure",
                "--subscription", "sub-123", "--overwrite",
            ]
        )


class TestCredentialsGenerateGcp:
    def test_requires_project(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_gcp("prod-gcp", project="proj-123")
        run.assert_called_once_with(
            [
                "credentials", "generate", "gcp", "prod-gcp",
                "--project", "proj-123",
            ]
        )

    def test_overwrite_appended(self):
        with patch.object(mcp_mod, "_run_cli", return_value="created") as run:
            credentials_generate_gcp("prod-gcp", project="proj-123", overwrite=True)
        run.assert_called_once_with(
            [
                "credentials", "generate", "gcp", "prod-gcp",
                "--project", "proj-123", "--overwrite",
            ]
        )


class TestErrorPropagation:
    def test_import_aws_surfaces_cli_failure(self):
        err = subprocess.CalledProcessError(1, ["anycloud"], output="", stderr="profile not found")
        with patch.object(subprocess, "run", side_effect=err):
            with pytest.raises(RuntimeError, match="profile not found"):
                credentials_import_aws("my-aws", profile="missing")
