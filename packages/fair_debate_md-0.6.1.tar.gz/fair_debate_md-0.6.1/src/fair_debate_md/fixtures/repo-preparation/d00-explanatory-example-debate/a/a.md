# ::a1 Explanatory Example Debate v0\.1


::a2 This document contains an example "debate" to describe the platform _Fair Debate_ and demonstrate its main features. ::a3 Hence it is formulated in form of a dialogue.


::a4 Currently you are reading the initial _contribution_ of this debate. ::a5 It has the ::a6 _contribution key_:`a`. ::a7 
Each contribution consists of ::a8 _statements_. ::a9 A statement can be a sentence, a bullet point, a headline etc. ::a10 Contributions are automatically split into statements. ::a11 Each statement has its own key and thus is uniquely referenceable. ::a12 Now, the two main features of ::a13 _Fair Debate_ are:


1. ::a14 Persistent in\-context\-answers.
2. ::a15 Provable integrity of content data.


::a16 To learn more about them, click on the highlighted statements (entries of the list). ::a17 Explanation: ::a18 A highlighted text\-part means: ::a19 This statement has been answered and answers can be unfolded.




---


::a20 Even more detailed information can be found in the answers to this statement.
