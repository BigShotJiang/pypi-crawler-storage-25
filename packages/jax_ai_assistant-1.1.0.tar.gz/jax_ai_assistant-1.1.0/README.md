<div align="center">

```
     ██╗ █████╗ ██╗  ██╗     █████╗ ██╗
     ██║██╔══██╗╚██╗██╔╝    ██╔══██╗██║
     ██║███████║ ╚███╔╝     ███████║██║
██   ██║██╔══██║ ██╔██╗     ██╔══██║██║
╚█████╔╝██║  ██║██╔╝ ██╗    ██║  ██║██║
 ╚════╝ ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝
```

**Jax AI — Assistente especializado em Java Backend**

[![PyPI version](https://img.shields.io/pypi/v/jax-ai?color=orange&label=jax-ai)](https://pypi.org/project/jax-ai/)
[![Python](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Powered by Gemini](https://img.shields.io/badge/powered%20by-Gemini%20AI-blueviolet)](https://aistudio.google.com/)

</div>

---

## O que é o Jax?

O **Jax** é um assistente de IA especializado em **desenvolvimento backend Java**, disponível direto no seu terminal. Ele atua como um desenvolvedor sênior ao seu lado, pronto para ajudar tanto quem está começando quanto quem já tem experiência.

O Jax sabe sobre:

- ☕ **Java** — fundamentos, orientação a objetos, boas práticas
- 🍃 **Spring Boot** — configuração, injeção de dependências, REST APIs
- 🗄️ **JPA / Hibernate** — mapeamento objeto-relacional, queries, transações
- 🔒 **Spring Security** — autenticação, autorização, JWT
- 🧪 **Testes** — JUnit, Mockito, testes de integração
- 📦 **Maven / Gradle** — gerenciamento de dependências e build
- 🏗️ **Arquitetura** — padrões de projeto, clean architecture, microsserviços
- 🗃️ **SQL** — consultas, modelagem de banco de dados

---

## Demonstração

```
     ██╗ █████╗ ██╗  ██╗     █████╗ ██╗
     ...

╭─────────────────────────────────────────╮
│  Java Backend Assistant                 │
╰─────────────────────────────────────────╯

  Diretório de trabalho: C:\bruno_workspace\

Você: Crie um projeto Java que calcula a tabuada de um número informado pelo usuário

╭─ Jet ───────────────────────────────────────────────────────────╮
│                                                                  │
│  Aqui está o projeto completo:                                   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │ // filename: Tabuada.java                               │    │
│  │ import java.util.Scanner;                               │    │
│  │                                                         │    │
│  │ public class Tabuada {                                  │    │
│  │     public static void main(String[] args) {            │    │
│  │         Scanner sc = new Scanner(System.in);            │    │
│  │         System.out.print("Digite um número: ");         │    │
│  │         int n = sc.nextInt();                           │    │
│  │         for (int i = 1; i <= 10; i++) {                 │    │
│  │             System.out.println(n + " x " + i + " = "   │    │
│  │                 + (n * i));                             │    │
│  │         }                                               │    │
│  │     }                                                   │    │
│  │ }                                                       │    │
│  └─────────────────────────────────────────────────────────┘    │
╰──────────────────────────────────────────────────────────────────╯

──────────────── Arquivos criados ────────────────
  ✓ C:\bruno_workspace\Tabuada.java
```

---

## Requisitos

Antes de instalar o Jax, certifique-se de ter:

| Requisito | Versão mínima | Como verificar |
|---|---|---|
| Python | 3.11+ | `python --version` |
| pip | qualquer | `pip --version` |
| Git | qualquer | `git --version` |
| Chave Gemini API | — | [Obter chave gratuita](https://aistudio.google.com/app/apikey) |

> **Windows**: recomenda-se usar o **PowerShell** ou o **Terminal do Windows**.  
> **Linux/Mac**: qualquer terminal funciona.

---

## Instalação — passo a passo

### 1. Instale o Jax via pip

```bash
pip install jax-ai-assistant
```

É só isso. O comando `jax` estará disponível em qualquer lugar do terminal.

---

### 2. Obtenha sua chave de API do Gemini

O Jax usa o **Gemini AI** do Google, que possui uma camada gratuita generosa.

1. Acesse [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Faça login com sua conta Google
3. Clique em **"Create API Key"**
4. Copie a chave gerada

---

### 3. Configure a chave no Jax

```bash
jax config --api-key SUA_CHAVE_AQUI
```

A chave é salva de forma segura em `~/.jax/config.json` na sua máquina e **nunca** é enviada para nenhum servidor além da API do Google.

---

### 4. Abra o Jax

```bash
jax open
```

Pronto! O assistente estará disponível no seu terminal.

---

## Comandos disponíveis

| Comando | Descrição |
|---|---|
| `jax open` | Abre a interface interativa no terminal |
| `jax config --api-key CHAVE` | Configura a chave de API do Gemini |
| `jax config --show` | Exibe a configuração atual |
| `jax uninstall` | Remove o Jax e as configurações do sistema |
| `jax uninstall --keep-config` | Remove o Jax mas mantém a chave salva |
| `jax --version` | Exibe a versão instalada |
| `jax --help` | Exibe a ajuda |

### Comandos dentro do chat

| Comando | Descrição |
|---|---|
| `help` | Exibe a ajuda do chat |
| `clear` | Limpa a tela |
| `exit` | Encerra o Jax |

---

## Criação de arquivos

O Jax consegue criar arquivos `.java`, `.sql`, `.xml`, `.yaml` e outros diretamente no diretório em que você estiver. Para isso, use palavras como `crie`, `gere` ou `implemente` no seu prompt.

```bash
# Navegue até o seu workspace antes de abrir o Jax
cd C:\meu_workspace

jax open
```

Dentro do chat:

```
# Cria um único arquivo na pasta atual
> Crie uma classe Java que implementa uma pilha com array

# Cria uma pasta com o nome do projeto e os arquivos dentro
> Crie um projeto Java de calculadora com as quatro operações

# Cria um script SQL
> Gere um script SQL para criar tabela de clientes com endereço
```

---

## Interface Web (opcional)

O Jax também possui uma interface web acessível pelo navegador. Para usá-la:

```bash
# Na raiz do projeto clonado
uvicorn main:app --reload
```

Acesse: [http://localhost:8000/template/chat](http://localhost:8000/template/chat)

---

## Desinstalação

```bash
# Remove o Jax e suas configurações (chave de API)
jax uninstall

# Remove o Jax mas mantém a chave de API salva
jax uninstall --keep-config
```

---

## Tecnologias utilizadas

| Tecnologia | Uso |
|---|---|
| [Python 3.11+](https://www.python.org/) | Linguagem base |
| [Google Gemini AI](https://aistudio.google.com/) | Modelo de linguagem |
| [Rich](https://github.com/Textualize/rich) | Interface do terminal |
| [FastAPI](https://fastapi.tiangolo.com/) | Interface web |
| [Jinja2](https://jinja.palletsprojects.com/) | Templates HTML |

---

## Licença

Distribuído sob a licença [MIT](LICENSE).

---

<div align="center">
Feito com ☕ por <a href="https://github.com/seu-usuario">Bruno Mota</a>
</div>
