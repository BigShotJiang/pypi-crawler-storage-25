from fastapi import FastAPI
from jax.cli_config import get_api_key
from jax.assistant_routes import assistant_router
from jax.template_routes import template_router

# Garante que a chave está disponível no ambiente ao iniciar via FastAPI
get_api_key()

app = FastAPI(title="Jax AI", version="1.0.0")

app.include_router(assistant_router)
app.include_router(template_router)