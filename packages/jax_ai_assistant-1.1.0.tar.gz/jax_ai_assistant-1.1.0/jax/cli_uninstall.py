import os
import sys
import shutil
import subprocess

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".jax")
console = Console()


def _remove_config_dir() -> bool:
    if os.path.exists(CONFIG_DIR):
        shutil.rmtree(CONFIG_DIR)
        return True
    return False


def _pip_uninstall() -> bool:
    result = subprocess.run(
        [sys.executable, "-m", "pip", "uninstall", "jax-ai", "-y"],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def run_uninstall(keep_config: bool = False):
    console.print()

    config_line = (
        "  [yellow]•[/yellow] Suas configurações em [cyan]~/.jax/[/cyan] (chave de API)\n"
        if not keep_config
        else "  [green]✓[/green] Suas configurações em [cyan]~/.jax/[/cyan] serão [bold]mantidas[/bold]\n"
    )

    console.print(
        Panel(
            "[bold red]Desinstalar o Jax AI[/bold red]\n\n"
            "Esta ação irá remover:\n"
            "  [yellow]•[/yellow] O pacote [cyan]jax-ai[/cyan] e o comando [cyan]jax[/cyan]\n"
            + config_line +
            "\n[dim]Arquivos .java / .sql que você criou não serão afetados.[/dim]",
            border_style="red",
            padding=(1, 2),
        )
    )

    confirmed = Confirm.ask("\n[bold]Deseja continuar com a desinstalação?[/bold]", default=False)
    if not confirmed:
        console.print("\n[dim]Desinstalação cancelada.[/dim]\n")
        return

    console.print()

    # 1. Remove configurações (se aplicável)
    if not keep_config:
        with console.status("[yellow]Removendo configurações...[/yellow]"):
            removed = _remove_config_dir()
        if removed:
            console.print("  [green]✓[/green] Configurações removidas [dim](~/.jax/)[/dim]")
        else:
            console.print("  [dim]– Nenhuma configuração encontrada para remover.[/dim]")
    else:
        console.print("  [green]✓[/green] Configurações mantidas [dim](~/.jax/)[/dim]")

    # 2. Desinstala o pacote via pip
    with console.status("[yellow]Desinstalando pacote via pip...[/yellow]"):
        success = _pip_uninstall()

    if success:
        console.print("  [green]✓[/green] Pacote [cyan]jax-ai[/cyan] removido com sucesso")
    else:
        console.print(
            "  [red]✗[/red] Falha ao remover via pip.\n"
            "  Execute manualmente: [cyan]pip uninstall jax-ai -y[/cyan]"
        )

    console.print()
    console.print(
        Panel(
            "[bold green]Jax AI desinstalado com sucesso![/bold green]\n\n"
            "[dim]Obrigado por usar o Jax. Para reinstalar:\n"
            "pip install jax-ai[/dim]",
            border_style="green",
            padding=(1, 2),
        )
    )
    console.print()