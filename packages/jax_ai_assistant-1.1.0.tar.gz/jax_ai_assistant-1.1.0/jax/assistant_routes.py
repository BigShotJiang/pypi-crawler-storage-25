from fastapi import APIRouter, Query
from jax.assistant_service import ask_assistant as get_assistant_response

assistant_router = APIRouter(prefix="/assistant", tags=["assistant"])


@assistant_router.post("/")
async def assistant_endpoint(prompt: str = Query(...)):
    return get_assistant_response(prompt)