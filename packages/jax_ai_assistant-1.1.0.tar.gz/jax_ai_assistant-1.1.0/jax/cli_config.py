import os
import json
import stat

CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".jax")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")


def _ensure_config_dir():
    if not os.path.exists(CONFIG_DIR):
        os.makedirs(CONFIG_DIR)
        if os.name != "nt":
            os.chmod(CONFIG_DIR, stat.S_IRWXU)


def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(config: dict):
    _ensure_config_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    if os.name != "nt":
        os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)


def set_api_key(api_key: str):
    config = load_config()
    config["gemini_api_key"] = api_key
    save_config(config)
    os.environ["GEMINI_API_KEY"] = api_key


def get_api_key() -> str | None:
    key_from_env = os.environ.get("GEMINI_API_KEY")
    if key_from_env:
        return key_from_env
    config = load_config()
    key_from_file = config.get("gemini_api_key")
    if key_from_file:
        os.environ["GEMINI_API_KEY"] = key_from_file
        return key_from_file
    return None


def show_config():
    config = load_config()
    key = config.get("gemini_api_key", "")
    if key:
        masked = key[:6] + "*" * (len(key) - 10) + key[-4:]
        print(f"  gemini_api_key : {masked}")
        print(f"  config file    : {CONFIG_FILE}")
    else:
        print("  Nenhuma chave configurada.")
        print("  Use: jax config --api-key SUA_CHAVE")