

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="jax",
        description="Jax AI — Assistente especializado em Java Backend",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos:
  jax open                          Abre o chat interativo no terminal
  jax open-web                      Sobe a interface web localmente
  jax config --api-key SUA_CHAVE    Configura sua chave Gemini API
  jax config --show                 Exibe a configuração atual
  jax update                        Atualiza o Jax para a versão mais recente
  jax uninstall                     Remove o Jax do sistema
  jax uninstall --keep-config       Remove mas mantém as configurações
        """,
    )

    parser.add_argument("--version", "-v", action="version", version="jax 1.1.0")

    subparsers = parser.add_subparsers(dest="command", metavar="comando")

    # ── open ──────────────────────────────────────────────────────────────────
    subparsers.add_parser("open", help="Abre a interface interativa do Jax no terminal")

    # ── open-web ──────────────────────────────────────────────────────────────
    open_web_parser = subparsers.add_parser("open-web", help="Sobe a interface web e abre no navegador")
    open_web_parser.add_argument("--host", default="127.0.0.1", help="Host (padrão: 127.0.0.1)")
    open_web_parser.add_argument("--port", default=8000, type=int, help="Porta (padrão: 8000)")

    # ── config ────────────────────────────────────────────────────────────────
    config_parser = subparsers.add_parser("config", help="Gerencia as configurações do Jax")
    config_group = config_parser.add_mutually_exclusive_group(required=True)
    config_group.add_argument("--api-key", metavar="CHAVE", help="Define a chave de API do Gemini")
    config_group.add_argument("--show", action="store_true", help="Exibe as configurações atuais")

    # ── update ────────────────────────────────────────────────────────────────
    subparsers.add_parser("update", help="Atualiza o Jax para a versão mais recente")

    # ── uninstall ─────────────────────────────────────────────────────────────
    uninstall_parser = subparsers.add_parser("uninstall", help="Remove o Jax do sistema")
    uninstall_parser.add_argument(
        "--keep-config",
        action="store_true",
        help="Mantém o arquivo de configuração (~/.jax/config.json)",
    )

    # ── parse ─────────────────────────────────────────────────────────────────
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    # ── roteamento ────────────────────────────────────────────────────────────
    if args.command == "open":
        from jax.cli_chat import run_chat
        run_chat()

    elif args.command == "open-web":
        from jax.cli_web import run_web
        run_web(host=args.host, port=args.port)

    elif args.command == "config":
        from rich.console import Console
        from rich.panel import Panel
        from jax.cli_config import set_api_key, show_config

        console = Console()

        if args.api_key:
            set_api_key(args.api_key)
            console.print(
                Panel(
                    "[bold green]✓ Chave de API configurada com sucesso![/bold green]\n\n"
                    "Agora execute [cyan]jax open[/cyan] para iniciar o assistente.",
                    border_style="green",
                    padding=(1, 2),
                )
            )
        elif args.show:
            console.print(
                Panel("[bold yellow]Configuração atual do Jax[/bold yellow]", border_style="yellow")
            )
            show_config()
            console.print()

    elif args.command == "update":
        from jax.cli_update import run_update
        run_update()

    elif args.command == "uninstall":
        from jax.cli_uninstall import run_uninstall
        run_uninstall(keep_config=args.keep_config)


if __name__ == "__main__":
    main()