import sys
import subprocess
import urllib.request
import urllib.error
import json
from importlib.metadata import version, PackageNotFoundError

from rich.console import Console
from rich.panel import Panel

PACKAGE_NAME = "jax-ai-assistant"
PYPI_API_URL = f"https://pypi.org/pypi/{PACKAGE_NAME}/json"

console = Console()


def _get_installed_version() -> str | None:
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        return None


def _get_latest_version() -> str | None:
    try:
        req = urllib.request.Request(PYPI_API_URL, headers={"User-Agent": "jax-ai-assistant"})
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode())
            return data["info"]["version"]
    except Exception:
        return None


def _parse_version(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except ValueError:
        return (0,)


def check_update_available() -> dict | None:
    current = _get_installed_version()
    latest = _get_latest_version()

    if not current or not latest:
        return None

    if _parse_version(latest) > _parse_version(current):
        return {"current": current, "latest": latest}

    return None


def run_update():
    console.print()

    with console.status("[yellow]Verificando versão mais recente no PyPI...[/yellow]"):
        current = _get_installed_version()
        latest = _get_latest_version()

    if not current:
        console.print(
            Panel(
                "[red]Não foi possível detectar a versão instalada.[/red]\n\n"
                f"Tente manualmente: [cyan]pip install --upgrade {PACKAGE_NAME}[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        return

    if not latest:
        console.print(
            Panel(
                "[yellow]Não foi possível verificar a versão mais recente.[/yellow]\n\n"
                "Verifique sua conexão com a internet e tente novamente.",
                border_style="yellow",
                padding=(1, 2),
            )
        )
        return

    if _parse_version(latest) <= _parse_version(current):
        console.print(
            Panel(
                f"[bold green]✓ Você já está na versão mais recente![/bold green]  "
                f"[dim](v{current})[/dim]",
                border_style="green",
                padding=(1, 2),
            )
        )
        return

    # Há update disponível
    console.print(
        Panel(
            f"[bold yellow]Nova versão disponível: {latest}[/bold yellow]  "
            f"[dim](você tem a {current})[/dim]\n\n"
            "Atualizando agora...",
            border_style="yellow",
            padding=(1, 2),
        )
    )
    console.print()

    with console.status(f"[yellow]Instalando {PACKAGE_NAME} {latest}...[/yellow]"):
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", PACKAGE_NAME],
            capture_output=True,
            text=True,
        )

    if result.returncode == 0:
        console.print(
            Panel(
                f"[bold green]✓ Jax atualizado para a versão {latest} com sucesso![/bold green]\n\n"
                "[dim]Reinicie o terminal e use [cyan]jax open[/cyan] para começar.[/dim]",
                border_style="green",
                padding=(1, 2),
            )
        )
    else:
        console.print(
            Panel(
                "[bold red]✗ Falha ao atualizar.[/bold red]\n\n"
                f"Tente manualmente:\n[cyan]pip install --upgrade {PACKAGE_NAME}[/cyan]\n\n"
                f"[dim]Detalhe: {result.stderr.strip()[-300:]}[/dim]",
                border_style="red",
                padding=(1, 2),
            )
        )

    console.print()