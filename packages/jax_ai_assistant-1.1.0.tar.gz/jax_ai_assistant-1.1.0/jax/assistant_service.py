import os
import logging
import markdown2 as mk
from google import genai
from google.genai import types
from google.genai.errors import ServerError

logger = logging.getLogger(__name__)

MODEL_NAME = "gemini-2.0-flash"
PERSONA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "persona_prompt.txt")


def _load_persona() -> str:
    if not os.path.exists(PERSONA_FILE):
        raise FileNotFoundError(
            f"Arquivo de persona não encontrado: '{PERSONA_FILE}'."
        )
    with open(PERSONA_FILE, "r", encoding="utf-8") as f:
        return f.read()


try:
    persona_prompt = _load_persona()
except FileNotFoundError as e:
    logger.critical(str(e))
    raise


def _get_client() -> genai.Client:
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise EnvironmentError(
            "Chave de API não configurada.\n"
            "Execute: jax config --api-key SUA_CHAVE"
        )
    return genai.Client(api_key=api_key)


# ── FastAPI (stateless) ────────────────────────────────────────────────────────

def ask_assistant(prompt: str) -> dict:
    try:
        client = _get_client()
        full_prompt = f"{persona_prompt}\n\n{prompt}"
        response_ai = client.models.generate_content(model=MODEL_NAME, contents=full_prompt)
        return {"answer": mk.markdown(response_ai.text)}
    except EnvironmentError as e:
        return {"error": str(e)}
    except ServerError as e:
        logger.error("Gemini ServerError: %s", e.message)
        return {"error": f"Erro no servidor de IA: {e.message}"}
    except Exception:
        logger.exception("Erro inesperado.")
        return {"error": "Ocorreu um erro inesperado. Tente novamente."}


# ── CLI (stateful com histórico) ───────────────────────────────────────────────

class JaxCLISession:
    def __init__(self):
        self.client = _get_client()
        self.history: list[types.Content] = []

    def chat(self, user_prompt: str) -> str:
        self.history.append(
            types.Content(role="user", parts=[types.Part(text=user_prompt)])
        )

        # Injeta persona apenas na primeira mensagem
        contents = self.history.copy()
        if len(self.history) == 1:
            contents[0] = types.Content(
                role="user",
                parts=[types.Part(text=f"{persona_prompt}\n\n{user_prompt}")]
            )

        response = self.client.models.generate_content(model=MODEL_NAME, contents=contents)
        response_text = response.text

        self.history.append(
            types.Content(role="model", parts=[types.Part(text=response_text)])
        )
        return response_text