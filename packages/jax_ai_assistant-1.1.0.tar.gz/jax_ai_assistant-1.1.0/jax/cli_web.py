import sys
import time
import threading
import webbrowser
import subprocess

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from jax.cli_config import get_api_key

console = Console()


def _open_browser_delayed(url: str, delay: float = 1.8):
    time.sleep(delay)
    webbrowser.open(url)


def run_web(host: str = "127.0.0.1", port: int = 8000):
    # Verifica chave de API antes de subir o servidor
    api_key = get_api_key()
    if not api_key:
        console.print(
            Panel(
                "[bold red]Chave de API não configurada![/bold red]\n\n"
                "Execute o comando abaixo e tente novamente:\n\n"
                "[cyan]  jax config --api-key SUA_CHAVE_GEMINI[/cyan]\n\n"
                "Obtenha sua chave em: [cyan]https://aistudio.google.com/app/apikey[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        sys.exit(1)

    url = f"http://{host}:{port}/template/chat"

    console.print()
    console.print(
        Panel(
            "[bold yellow]Jax AI — Interface Web[/bold yellow]\n\n"
            f"  Servidor : [cyan]http://{host}:{port}[/cyan]\n"
            f"  Chat     : [cyan]{url}[/cyan]\n\n"
            "  [dim]Use Ctrl+C para encerrar o servidor.[/dim]\n"
            "  [dim]O navegador abrirá automaticamente em instantes...[/dim]",
            border_style="yellow",
            padding=(1, 2),
        )
    )
    console.print(Rule("[dim]uvicorn log[/dim]"))

    # Abre o navegador em background após o servidor subir
    browser_thread = threading.Thread(target=_open_browser_delayed, args=(url,), daemon=True)
    browser_thread.start()

    # Sobe o uvicorn como subprocesso com output em tempo real
    # Usa o main.py do pacote instalado como entry point do FastAPI
    try:
        import jax as jax_pkg
        import os
        # Localiza o main.py relativo ao pacote instalado
        pkg_dir = os.path.dirname(os.path.abspath(jax_pkg.__file__))
        main_path = os.path.join(os.path.dirname(pkg_dir), "main.py")

        if not os.path.exists(main_path):
            # Fallback: tenta importar diretamente pelo módulo
            app_target = "main:app"
        else:
            app_target = "main:app"

        result = subprocess.run(
            [
                sys.executable, "-m", "uvicorn",
                app_target,
                "--host", host,
                "--port", str(port),
                "--reload",
            ],
            # Não captura output — deixa fluir direto no terminal
            # para o usuário ver os logs do uvicorn em tempo real
        )
    except KeyboardInterrupt:
        pass
    except FileNotFoundError:
        console.print(
            Panel(
                "[bold red]uvicorn não encontrado.[/bold red]\n\n"
                "Instale com: [cyan]pip install uvicorn[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        sys.exit(1)

    console.print()
    console.print(Rule("[dim]servidor encerrado[/dim]"))
    console.print()