import os
import re

CREATION_KEYWORDS = [
    "crie", "cria", "gere", "gera", "crie um", "cria um",
    "gere um", "gera um", "crie o", "crie uma", "gere uma",
    "implemente", "implemente um", "implemente uma",
    "monte", "monte um", "monte uma",
    "faça um projeto", "faça uma classe", "faça um arquivo",
    "escreva um", "escreva uma",
    "create", "generate", "implement",
]

SUPPORTED_EXTENSIONS = {
    "java": ".java",
    "sql": ".sql",
    "xml": ".xml",
    "json": ".json",
    "yaml": ".yaml",
    "yml": ".yml",
    "properties": ".properties",
    "gradle": ".gradle",
    "groovy": ".gradle",
    "sh": ".sh",
    "bash": ".sh",
    "dockerfile": "Dockerfile",
    "md": ".md",
}


def is_creation_request(prompt: str) -> bool:
    lower = prompt.lower()
    return any(kw in lower for kw in CREATION_KEYWORDS)


def extract_code_blocks(ai_response: str) -> list[dict]:
    pattern = re.compile(
        r"```(\w+)?\s*(?://\s*filename:\s*([\w./\\-]+))?\n(.*?)```",
        re.DOTALL
    )
    blocks = []
    for match in pattern.finditer(ai_response):
        language = (match.group(1) or "txt").lower()
        filename_hint = match.group(2)
        code = match.group(3).strip()

        if language not in SUPPORTED_EXTENSIONS:
            continue

        extension = SUPPORTED_EXTENSIONS[language]
        filename = filename_hint or _infer_filename(code, language, extension)
        blocks.append({"language": language, "filename": filename, "code": code})

    return blocks


def _infer_filename(code: str, language: str, extension: str) -> str:
    if language == "java":
        match = re.search(r"public\s+(?:class|enum|interface|record)\s+(\w+)", code)
        if match:
            return match.group(1) + extension
    if language == "sql":
        match = re.search(r"(?:CREATE\s+TABLE|INSERT\s+INTO|UPDATE)\s+(\w+)", code, re.IGNORECASE)
        if match:
            return match.group(1).lower() + extension
    return f"output{extension}"


def _extract_project_name(prompt: str, blocks: list[dict]) -> str:
    patterns = [
        r"projeto\s+(?:java\s+)?(?:de\s+|para\s+|sobre\s+)?([a-záéíóúâêîôûãõàèìòùç\w_-]+)",
        r"sistema\s+(?:de\s+|para\s+)?([a-záéíóúâêîôûãõàèìòùç\w_-]+)",
        r"aplicação\s+(?:de\s+|para\s+)?([a-záéíóúâêîôûãõàèìòùç\w_-]+)",
    ]
    for pat in patterns:
        match = re.search(pat, prompt.lower())
        if match:
            name = match.group(1).strip().replace(" ", "_")
            if len(name) > 2:
                return name
    for block in blocks:
        name = block["filename"].rsplit(".", 1)[0]
        if name and name != "output":
            return name.lower()
    return "jax_project"


def create_files(prompt: str, blocks: list[dict], working_dir: str) -> list[str]:
    if not blocks:
        return []

    target_dir = working_dir if len(blocks) == 1 else os.path.join(
        working_dir, _extract_project_name(prompt, blocks)
    )
    os.makedirs(target_dir, exist_ok=True)

    created = []
    for block in blocks:
        filepath = os.path.join(target_dir, block["filename"])
        parent = os.path.dirname(filepath)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(block["code"])
        created.append(filepath)

    return created