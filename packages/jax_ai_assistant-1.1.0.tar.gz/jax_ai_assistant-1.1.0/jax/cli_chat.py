"""Interface interativa do Jax no terminal usando Rich."""

import os
import sys

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule

from jax.cli_config import get_api_key
from jax.cli_file_handler import is_creation_request, extract_code_blocks, create_files

console = Console()

BANNER = """
     ██╗ █████╗ ██╗  ██╗     █████╗ ██╗
     ██║██╔══██╗╚██╗██╔╝    ██╔══██╗██║
     ██║███████║ ╚███╔╝     ███████║██║
██   ██║██╔══██║ ██╔██╗     ██╔══██║██║
╚█████╔╝██║  ██║██╔╝ ██╗    ██║  ██║██║
 ╚════╝ ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝
"""


def _print_banner():
    console.print(f"[bold yellow]{BANNER}[/bold yellow]", justify="center")
    console.print(
        Panel(
            "[bold white]Java Backend Assistant[/bold white]\n"
            "[dim]Especializado em Java, Spring Boot, JPA, REST APIs e muito mais[/dim]",
            border_style="yellow",
            padding=(0, 4),
        ),
        justify="center",
    )
    console.print()


def _print_welcome():
    console.print(
        Panel(
            "[bold white]Jet:[/bold white] Olá! Sou o [bold yellow]Jax[/bold yellow], "
            "seu assistente especializado em [cyan]backend Java[/cyan].\n\n"
            "Posso ajudar com Java, Spring Boot, JPA/Hibernate, REST APIs, testes e muito mais.\n"
            "Use palavras como [cyan]crie[/cyan], [cyan]gere[/cyan] ou [cyan]implemente[/cyan] "
            "para que eu crie arquivos no seu diretório.\n\n"
            "Digite [cyan]help[/cyan] para ver todos os comandos disponíveis.",
            border_style="dim white",
            padding=(1, 2),
        )
    )
    console.print()


def _print_help():
    console.print(
        Panel(
            "[bold yellow]Comandos disponíveis:[/bold yellow]\n\n"
            "  [cyan]help[/cyan]       → Exibe esta ajuda\n"
            "  [cyan]clear[/cyan]      → Limpa a tela\n"
            "  [cyan]exit[/cyan]       → Encerra o Jax\n\n"
            "[bold yellow]Criação de arquivos:[/bold yellow]\n\n"
            "  Use [cyan]crie[/cyan], [cyan]gere[/cyan] ou [cyan]implemente[/cyan] no prompt.\n"
            "  Os arquivos serão criados no diretório atual.\n\n"
            "[bold yellow]Exemplos:[/bold yellow]\n\n"
            "  [dim]> Crie um projeto Java que calcula a tabuada[/dim]\n"
            "  [dim]> Gere um script SQL para criar tabela de usuários[/dim]\n"
            "  [dim]> Explique o que é Spring Boot[/dim]",
            title="[bold yellow]Ajuda[/bold yellow]",
            border_style="yellow",
        )
    )


def _print_response(response_text: str):
    console.print(
        Panel(
            Markdown(response_text, code_theme="monokai"),
            title="[bold yellow]Jet[/bold yellow]",
            title_align="left",
            border_style="yellow",
            padding=(1, 2),
        )
    )
    console.print()


def _print_files_created(created_paths: list[str]):
    console.print(Rule("[bold green]Arquivos criados[/bold green]"))
    for path in created_paths:
        console.print(f"  [bold green]✓[/bold green] [cyan]{os.path.abspath(path)}[/cyan]")
    console.print()


def _handle_builtin(command: str) -> bool:
    cmd = command.strip().lower()
    if cmd in ("exit", "quit", "sair"):
        console.print("\n[bold yellow]Até logo! Bons estudos em Java! ☕[/bold yellow]\n")
        sys.exit(0)
    if cmd == "help":
        _print_help()
        return True
    if cmd == "clear":
        console.clear()
        _print_banner()
        return True
    return False


def run_chat():
    from jax.cli_update import check_update_available

    api_key = get_api_key()
    if not api_key:
        console.print(
            Panel(
                "[bold red]Chave de API não configurada![/bold red]\n\n"
                "Execute o comando abaixo e tente novamente:\n\n"
                "[cyan]  jax config --api-key SUA_CHAVE_GEMINI[/cyan]\n\n"
                "Obtenha sua chave em: [cyan]https://aistudio.google.com/app/apikey[/cyan]",
                border_style="red",
                padding=(1, 2),
            )
        )
        sys.exit(1)

    from jax.assistant_service import JaxCLISession
    from google.genai.errors import ServerError

    _print_banner()

    # Verifica silenciosamente se há nova versão disponível
    update_info = check_update_available()
    if update_info:
        console.print(
            Panel(
                f"[bold yellow]⬆  Nova versão disponível: {update_info['latest']}[/bold yellow]  "
                f"[dim](você tem a {update_info['current']})[/dim]\n\n"
                "Execute [cyan]jax update[/cyan] para atualizar.",
                border_style="yellow",
                padding=(0, 2),
            )
        )
        console.print()

    _print_welcome()

    working_dir = os.getcwd()
    console.print(f"[dim]  Diretório de trabalho: {working_dir}[/dim]\n")

    session = JaxCLISession()

    while True:
        try:
            user_input = Prompt.ask("[bold cyan]Você[/bold cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold yellow]Até logo! Bons estudos em Java! ☕[/bold yellow]\n")
            break

        if not user_input:
            continue

        if _handle_builtin(user_input):
            continue

        with console.status("[bold yellow]Jax está pensando...[/bold yellow]", spinner="dots"):
            try:
                response_text = session.chat(user_input)
            except ServerError as e:
                console.print(f"\n[bold red]Erro no servidor de IA:[/bold red] {e.message}\n")
                continue
            except EnvironmentError as e:
                console.print(f"\n[bold red]{e}[/bold red]\n")
                break
            except Exception as e:
                console.print(f"\n[bold red]Erro inesperado:[/bold red] {e}\n")
                continue

        _print_response(response_text)

        if is_creation_request(user_input):
            blocks = extract_code_blocks(response_text)
            if blocks:
                created = create_files(user_input, blocks, working_dir)
                if created:
                    _print_files_created(created)