"""Tests for the Fixer agent's validation logic."""

from qamigrate.agents.fixer import FixerAgent


class TestFixerValidation:
    """Validation prevents the fixer from accepting LLM output that
    contains prose or mangled code."""

    def setup_method(self) -> None:
        # Do not instantiate the LLM client; we only exercise pure helpers.
        self.fixer = FixerAgent.__new__(FixerAgent)
        from qamigrate.core.parser import get_parser
        self.fixer.parser = get_parser()

    def test_valid_java_passes(self) -> None:
        source = """package com.example;

public class Foo {
    public void bar() {
        System.out.println("hi");
    }
}
"""
        assert self.fixer._is_valid_java(source) is True

    def test_prose_mixed_into_java_is_rejected(self) -> None:
        source = """package com.example;

Add this import at the top of the file:

import org.junit.jupiter.api.BeforeAll;

public class Foo {
    public void bar() {}
}
"""
        assert self.fixer._is_valid_java(source) is False

    def test_unmatched_braces_is_rejected(self) -> None:
        source = """package com.example;

public class Foo {
    public void bar() {
"""
        assert self.fixer._is_valid_java(source) is False

    def test_markdown_fence_strip(self) -> None:
        wrapped = "```java\npublic class Foo {}\n```"
        result = FixerAgent._strip_any_stray_markdown(wrapped)
        assert result == "public class Foo {}"

    def test_markdown_without_language_tag(self) -> None:
        wrapped = "```\npublic class Bar {}\n```"
        result = FixerAgent._strip_any_stray_markdown(wrapped)
        assert result == "public class Bar {}"

    def test_no_markdown_passes_through(self) -> None:
        source = "public class Baz {}"
        assert FixerAgent._strip_any_stray_markdown(source) == source


class TestCoderReindent:
    """Defensive handling of LLM output quirks."""

    def test_literal_backslash_n_is_unescaped(self) -> None:
        """
        When the LLM returns a single-line string with literal '\\n' characters
        (as sometimes happens inside JSON tool_use fields), the reindenter
        should still produce multi-line output.
        """
        from qamigrate.agents.coder import CoderAgent

        # This string contains the two characters: backslash, n (not a real newline)
        single_line = (
            "public LoginPage(Page page) {\\n"
            "    this.page = page;\\n"
            "    this.username = page.locator(\"#u\");\\n"
            "}"
        )
        assert "\n" not in single_line  # sanity
        assert "\\n" in single_line

        lines = CoderAgent._reindent_block(single_line, base_indent=1)
        joined = "\n".join(lines)
        # No literal backslash-n should remain in the output
        assert "\\n" not in joined
        # Should be 4+ lines after reindenting
        assert len(lines) >= 4

    def test_real_newlines_pass_through(self) -> None:
        """Real newline input should not be modified."""
        from qamigrate.agents.coder import CoderAgent

        multi_line = "public void foo() {\n    bar();\n}"
        lines = CoderAgent._reindent_block(multi_line, base_indent=1)
        assert len(lines) == 3


class TestCoderUnescape:
    """LLM tool_use sometimes emits double-escaped chars inside string fields.
    We unescape them at the parse boundary so downstream rendering is clean."""

    def test_unescape_literal_backslash_quote(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        # This is what the user saw: page.locator(\"#user-name\")
        bad = 'page.locator(\\"#user-name\\")'
        assert '\\"' in bad
        result = CoderAgent._unescape_llm_string(bad)
        assert '\\"' not in result
        assert result == 'page.locator("#user-name")'

    def test_clean_string_passes_through(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        clean = 'page.locator("#user-name")'
        assert CoderAgent._unescape_llm_string(clean) == clean

    def test_sanitize_fields_nested(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        raw = {
            "fields": [
                'private final Locator x = page.locator(\\"#a\\");',
                "private final Page page;",
            ],
            "methods": [
                {
                    "name": "foo",
                    "signature": "public void foo()",
                    "implementation": 'public void foo() {\\n    bar(\\"baz\\");\\n}',
                }
            ],
        }
        clean = CoderAgent._sanitize_fields(raw)
        assert '\\"' not in clean["fields"][0]
        assert '"' in clean["fields"][0]
        assert "\n" in clean["methods"][0]["implementation"]
        assert '\\"' not in clean["methods"][0]["implementation"]

    def test_non_string_values_preserved(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        assert CoderAgent._unescape_llm_string(42) == 42
        assert CoderAgent._unescape_llm_string(None) is None
