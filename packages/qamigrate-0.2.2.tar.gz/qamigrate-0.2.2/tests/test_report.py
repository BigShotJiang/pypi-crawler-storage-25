"""Tests for the MigrationReport module."""

import json

from qamigrate.core.report import MigrationRecord, MigrationReport, PatternSummary


def _sample_record(success: bool = True, compiled: bool | None = True) -> MigrationRecord:
    return MigrationRecord(
        source_path="/path/to/LoginPage.java",
        output_path="/path/to/playwright/LoginPage.java",
        success=success,
        duration_seconds=12.3,
        patterns=[
            PatternSummary(pattern_type="FindBy", count=6, migration_strategy="to page.locator()"),
            PatternSummary(pattern_type="WebDriverWait", count=1, migration_strategy="remove"),
        ],
        compilation_attempts=0,
        compiled=compiled,
        original_lines=45,
        generated_lines=38,
        original_code="class Original {}",
        generated_code="class Generated {}",
    )


class TestMigrationRecord:
    def test_confidence_for_compiled_first_try(self) -> None:
        r = _sample_record(success=True, compiled=True)
        r.compilation_attempts = 0
        assert r.confidence == 100

    def test_confidence_for_compiled_after_one_fix(self) -> None:
        r = _sample_record(success=True, compiled=True)
        r.compilation_attempts = 1
        assert r.confidence == 90

    def test_confidence_for_compiled_after_many_fixes(self) -> None:
        r = _sample_record(success=True, compiled=True)
        r.compilation_attempts = 3
        assert r.confidence == 80

    def test_confidence_for_skipped_compilation(self) -> None:
        r = _sample_record(success=True, compiled=None)
        assert r.confidence == 70

    def test_confidence_for_failed_compile_with_output(self) -> None:
        """File exists but didn't compile after max retries: partial value for review."""
        r = _sample_record(success=False, compiled=False)
        r.compilation_attempts = 3
        assert r.confidence == 50

    def test_confidence_for_no_output(self) -> None:
        """Nothing generated: zero value."""
        r = _sample_record(success=False)
        r.output_path = None
        assert r.confidence == 0

    def test_hallucinations_reduce_confidence(self) -> None:
        """Each hallucination subtracts 10 points from the base confidence."""
        from qamigrate.core.report import Hallucination

        r = _sample_record(success=True, compiled=True)
        r.compilation_attempts = 0
        assert r.confidence == 100

        r.hallucinations = [Hallucination(called_method="X.foo()", on_class="X")]
        assert r.confidence == 90

        r.hallucinations = [
            Hallucination(called_method="X.foo()", on_class="X"),
            Hallucination(called_method="X.bar()", on_class="X"),
        ]
        assert r.confidence == 80

    def test_hallucination_penalty_has_floor(self) -> None:
        """Even with many hallucinations, confidence doesn't go below 20."""
        from qamigrate.core.report import Hallucination

        r = _sample_record(success=True, compiled=True)
        r.compilation_attempts = 0
        r.hallucinations = [
            Hallucination(called_method=f"X.m{i}()", on_class="X") for i in range(20)
        ]
        assert r.confidence == 20

    def test_hallucinations_included_in_json(self, tmp_path) -> None:
        from qamigrate.core.report import Hallucination

        report = MigrationReport()
        r = _sample_record(success=True, compiled=True)
        r.hallucinations = [Hallucination(called_method="LoginPage.foo()", on_class="LoginPage")]
        report.add(r)
        report.finish()

        data = json.loads(report.write_json(tmp_path / "report.json").read_text())
        halluc = data["files"][0]["hallucinations"]
        assert len(halluc) == 1
        assert halluc[0]["called_method"] == "LoginPage.foo()"


class TestMigrationReport:
    def test_empty_report(self) -> None:
        report = MigrationReport()
        assert report.total_files == 0
        assert report.success_count == 0
        assert report.total_patterns == 0
        assert report.estimated_hours_saved == 0

    def test_aggregate_metrics(self) -> None:
        report = MigrationReport()
        report.add(_sample_record(success=True))
        report.add(_sample_record(success=False))

        assert report.total_files == 2
        assert report.success_count == 1
        assert report.failed_count == 1
        assert report.total_patterns == 14  # 7 patterns * 2 records

    def test_patterns_by_type_sorted(self) -> None:
        report = MigrationReport()
        report.add(_sample_record())
        patterns = report.patterns_by_type
        # FindBy (6) should come before WebDriverWait (1)
        keys = list(patterns.keys())
        assert keys[0] == "FindBy"

    def test_json_output(self, tmp_path) -> None:
        report = MigrationReport()
        report.add(_sample_record())
        report.finish()

        out = report.write_json(tmp_path / "report.json")
        data = json.loads(out.read_text())

        assert data["metrics"]["total_files"] == 1
        assert data["metrics"]["total_patterns"] == 7
        assert "started_at" in data
        assert "finished_at" in data

    def test_html_output_contains_diff(self, tmp_path) -> None:
        report = MigrationReport()
        record = MigrationRecord(
            source_path="/x/Foo.java",
            output_path="/x/out/Foo.java",
            success=True,
            duration_seconds=1.0,
            patterns=[],
            compiled=True,
            original_code="public class Foo { String a; }",
            generated_code="public class Foo { String a; String b; }",
        )
        report.add(record)

        out = report.write_html(tmp_path / "report.html")
        html = out.read_text()
        # difflib-generated side-by-side table has a 'diff' class
        assert 'class="diff"' in html
        assert "QAMigrate Migration Report" in html

    def test_markdown_output(self, tmp_path) -> None:
        report = MigrationReport()
        report.add(_sample_record())
        report.finish()

        out = report.write_markdown(tmp_path / "report.md")
        md = out.read_text()
        assert "# QAMigrate Migration Report" in md
        assert "| Pattern | Count |" in md
