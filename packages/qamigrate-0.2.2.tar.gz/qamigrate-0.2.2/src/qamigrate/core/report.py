"""
Migration Report.

Tracks what was migrated, how, and with what confidence. Emits HTML, JSON,
and Markdown reports so users can inspect, audit, and share results.
"""

from __future__ import annotations

import difflib
import html
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# -----------------------------
# Data model
# -----------------------------


@dataclass
class PatternSummary:
    """A detected Selenium pattern and how QAMigrate handled it."""

    pattern_type: str
    count: int
    migration_strategy: str


@dataclass
class Hallucination:
    """A call to a method that does not exist on the referenced class."""

    called_method: str
    on_class: str
    similar_to: str | None = None  # closest real method, if we found one


@dataclass
class MigrationRecord:
    """A single file's migration outcome."""

    source_path: str
    output_path: str | None
    success: bool
    duration_seconds: float
    patterns: list[PatternSummary] = field(default_factory=list)
    compilation_attempts: int = 0
    compiled: bool | None = None  # None if compilation was skipped
    original_lines: int = 0
    generated_lines: int = 0
    error: str | None = None
    original_code: str = ""
    generated_code: str = ""
    hallucinations: list[Hallucination] = field(default_factory=list)

    @property
    def confidence(self) -> int:
        """
        Confidence score (0-100): how trustworthy is this generated file?

        Base score comes from whether the file was produced and compiled.
        Hallucinations (calls to non-existent methods on migrated siblings)
        subtract 10 points each, with a floor so we don't overstate failure.

        Base tiers:
        - 100: compiled on first try, zero fixes needed.
        -  90: compiled after 1-2 fix attempts (normal healthy path).
        -  80: compiled but needed 3+ fix attempts (some noise, likely works).
        -  70: generation succeeded, compilation skipped (can't verify).
        -  50: generation succeeded but compilation failed after max retries.
        -  30: generation happened but pipeline crashed partway through.
        -   0: nothing useful produced (no output file).
        """
        base = self._base_confidence()
        if base == 0:
            return 0

        # Penalize hallucinations -- they'll cause compile errors the user
        # has to chase down. Floor at 20 so we don't double-punish files
        # that also failed compilation for other reasons.
        penalty = 10 * len(self.hallucinations)
        if penalty:
            return max(20, base - penalty)
        return base

    def _base_confidence(self) -> int:
        if not self.output_path:
            return 0
        if self.compiled is None and self.success:
            return 70
        if self.compiled is True and self.compilation_attempts == 0:
            return 100
        if self.compiled is True and self.compilation_attempts <= 2:
            return 90
        if self.compiled is True:
            return 80
        if self.success or self.compilation_attempts > 0:
            return 50
        return 30

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["confidence"] = self.confidence
        # Don't bloat JSON with full source -- keep lines only
        d.pop("original_code", None)
        d.pop("generated_code", None)
        return d


@dataclass
class MigrationReport:
    """
    Aggregate report for a migration run.

    Contains per-file MigrationRecord entries plus batch-level metrics.
    """

    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at: str | None = None
    source_language: str = "Java (Selenium)"
    target_language: str = "Java (Playwright)"
    records: list[MigrationRecord] = field(default_factory=list)

    # -------- batch metrics --------

    @property
    def total_files(self) -> int:
        return len(self.records)

    @property
    def success_count(self) -> int:
        return sum(1 for r in self.records if r.success)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.records if not r.success)

    @property
    def compiled_count(self) -> int:
        return sum(1 for r in self.records if r.compiled is True)

    @property
    def total_duration_seconds(self) -> float:
        return sum(r.duration_seconds for r in self.records)

    @property
    def total_patterns(self) -> int:
        return sum(sum(p.count for p in r.patterns) for r in self.records)

    @property
    def patterns_by_type(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for record in self.records:
            for p in record.patterns:
                counts[p.pattern_type] = counts.get(p.pattern_type, 0) + p.count
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    @property
    def average_confidence(self) -> int:
        if not self.records:
            return 0
        return sum(r.confidence for r in self.records) // len(self.records)

    @property
    def estimated_hours_saved(self) -> float:
        """
        Estimate manual migration time saved.

        Only counts patterns from files that were actually migrated (confidence
        >= 70). Failed migrations get zero credit because the user will still
        have to do that file by hand.

        Heuristic: ~15 min of developer time per detected pattern (research +
        rewrite + test). Industry anecdotes for Selenium->Playwright migration
        range from 10-30 min per pattern.
        """
        usable_patterns = sum(
            sum(p.count for p in r.patterns)
            for r in self.records
            if r.confidence >= 70
        )
        return round(usable_patterns * 0.25, 1)

    def finish(self) -> None:
        self.finished_at = datetime.now(timezone.utc).isoformat()

    def add(self, record: MigrationRecord) -> None:
        self.records.append(record)

    # -------- output formats --------

    def to_dict(self) -> dict[str, Any]:
        return {
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "source_language": self.source_language,
            "target_language": self.target_language,
            "metrics": {
                "total_files": self.total_files,
                "success_count": self.success_count,
                "failed_count": self.failed_count,
                "compiled_count": self.compiled_count,
                "total_duration_seconds": round(self.total_duration_seconds, 2),
                "total_patterns": self.total_patterns,
                "patterns_by_type": self.patterns_by_type,
                "average_confidence": self.average_confidence,
                "estimated_hours_saved": self.estimated_hours_saved,
            },
            "files": [r.to_dict() for r in self.records],
        }

    def write_json(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return path

    def write_markdown(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self._render_markdown(), encoding="utf-8")
        return path

    def write_html(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self._render_html(), encoding="utf-8")
        return path

    # -------- rendering --------

    def _render_markdown(self) -> str:
        lines: list[str] = []
        lines.append("# QAMigrate Migration Report")
        lines.append("")
        lines.append(f"**Source -> Target:** {self.source_language} -> {self.target_language}")
        lines.append(f"**Started:** {self.started_at}")
        if self.finished_at:
            lines.append(f"**Finished:** {self.finished_at}")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        lines.append(f"- **Files migrated:** {self.success_count} / {self.total_files}")
        lines.append(f"- **Patterns handled:** {self.total_patterns}")
        lines.append(f"- **Average confidence:** {self.average_confidence}%")
        lines.append(f"- **Time taken:** {self.total_duration_seconds:.1f}s")
        lines.append(f"- **Estimated manual effort saved:** ~{self.estimated_hours_saved} hours")
        lines.append("")

        if self.patterns_by_type:
            lines.append("## Patterns handled")
            lines.append("")
            lines.append("| Pattern | Count |")
            lines.append("|---------|-------|")
            for name, count in self.patterns_by_type.items():
                lines.append(f"| `{name}` | {count} |")
            lines.append("")

        lines.append("## Files")
        lines.append("")
        lines.append("| File | Status | Confidence | Patterns | Hallucinations | Time |")
        lines.append("|------|--------|------------|----------|----------------|------|")
        for r in self.records:
            name = Path(r.source_path).name
            status = "OK" if r.success else "FAIL"
            patterns = sum(p.count for p in r.patterns)
            lines.append(
                f"| `{name}` | {status} | {r.confidence}% | {patterns} | "
                f"{len(r.hallucinations)} | {r.duration_seconds:.1f}s |"
            )
        lines.append("")

        # Hallucinations detail section
        all_halluc = [(r, h) for r in self.records for h in r.hallucinations]
        if all_halluc:
            lines.append("## Potential method hallucinations")
            lines.append("")
            lines.append(
                "These calls on sibling classes do not match any known "
                "migrated method. They will likely cause compile errors."
            )
            lines.append("")
            lines.append("| File | Called | Closest real method |")
            lines.append("|------|--------|---------------------|")
            for r, h in all_halluc:
                name = Path(r.source_path).name
                similar = h.similar_to or "-"
                lines.append(f"| `{name}` | `{h.called_method}` | `{similar}` |")
            lines.append("")

        return "\n".join(lines)

    def _render_html(self) -> str:
        files_html = "\n".join(self._render_file_card(r) for r in self.records)
        patterns_rows = "\n".join(
            f"<tr><td><code>{html.escape(name)}</code></td><td>{count}</td></tr>"
            for name, count in self.patterns_by_type.items()
        )
        fail_class = " fail" if self.failed_count > 0 else ""

        return _HTML_TEMPLATE.format(
            started_at=html.escape(self.started_at),
            finished_at=html.escape(self.finished_at or "in progress"),
            source_lang=html.escape(self.source_language),
            target_lang=html.escape(self.target_language),
            total_files=self.total_files,
            success_count=self.success_count,
            failed_count=self.failed_count,
            fail_class=fail_class,
            total_patterns=self.total_patterns,
            avg_confidence=self.average_confidence,
            total_duration=f"{self.total_duration_seconds:.1f}",
            hours_saved=self.estimated_hours_saved,
            patterns_rows=patterns_rows or "<tr><td colspan=2><em>No patterns detected</em></td></tr>",
            files_html=files_html or "<p><em>No files migrated.</em></p>",
        )

    def _render_file_card(self, record: MigrationRecord) -> str:
        name = html.escape(Path(record.source_path).name)
        status_class = "ok" if record.success else "fail"
        status_text = "Success" if record.success else "Failed"

        patterns_list = "".join(
            f"<li><code>{html.escape(p.pattern_type)}</code> &times; {p.count} "
            f"<span class='note'>{html.escape(p.migration_strategy)}</span></li>"
            for p in record.patterns
        )

        diff_html = ""
        if record.original_code and record.generated_code:
            diff_html = _render_side_by_side_diff(
                record.original_code, record.generated_code
            )

        error_html = ""
        if record.error:
            error_html = f"<div class='error'><strong>Error:</strong> {html.escape(record.error)}</div>"

        compiled_badge = ""
        if record.compiled is True:
            compiled_badge = "<span class='badge ok'>compiled</span>"
        elif record.compiled is False:
            compiled_badge = "<span class='badge fail'>did not compile</span>"
        else:
            compiled_badge = "<span class='badge neutral'>compilation skipped</span>"

        attempts_badge = ""
        if record.compilation_attempts > 0:
            attempts_badge = f"<span class='badge neutral'>{record.compilation_attempts} fix attempt(s)</span>"

        halluc_badge = ""
        halluc_html = ""
        if record.hallucinations:
            halluc_badge = f"<span class='badge fail'>{len(record.hallucinations)} hallucination(s)</span>"
            items = "".join(
                (
                    "<li>"
                    f"<code>{html.escape(h.called_method)}</code>"
                    + (f" &rarr; did you mean <code>{html.escape(h.similar_to)}</code>?"
                       if h.similar_to else "")
                    + "</li>"
                )
                for h in record.hallucinations
            )
            halluc_html = (
                "<h4>Potential hallucinated method calls</h4>"
                "<p class='note'>These sibling-class methods do not exist in the migrated output. "
                "They will likely cause compile errors.</p>"
                f"<ul class='patterns'>{items}</ul>"
            )

        return f"""
<details class="file-card">
  <summary>
    <div class="file-header">
      <div>
        <span class="status {status_class}">{status_text}</span>
        <span class="filename">{name}</span>
      </div>
      <div class="file-meta">
        <span class="confidence">{record.confidence}% confidence</span>
        <span>{record.duration_seconds:.1f}s</span>
        {compiled_badge}
        {attempts_badge}
        {halluc_badge}
      </div>
    </div>
  </summary>
  {error_html}
  <div class="file-body">
    <h4>Patterns handled</h4>
    <ul class="patterns">{patterns_list or '<li><em>None detected</em></li>'}</ul>
    {halluc_html}
    {('<h4>Before &rarr; After</h4>' + diff_html) if diff_html else ''}
  </div>
</details>
"""


def _render_side_by_side_diff(original: str, generated: str) -> str:
    """Render a side-by-side HTML diff using stdlib difflib."""
    differ = difflib.HtmlDiff(wrapcolumn=80, tabsize=4)
    return differ.make_table(
        original.splitlines(),
        generated.splitlines(),
        fromdesc="Original (Selenium)",
        todesc="Generated (Playwright)",
        context=True,
        numlines=3,
    )


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>QAMigrate Migration Report</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    margin: 0;
    background: #0b1020;
    color: #e6eaf2;
    line-height: 1.5;
  }}
  .container {{ max-width: 1100px; margin: 0 auto; padding: 2rem 1.5rem; }}
  h1 {{ margin: 0 0 0.25rem; font-size: 1.75rem; }}
  h2 {{ font-size: 1.15rem; margin: 2rem 0 0.75rem; color: #9db2d8; }}
  h4 {{ margin: 1rem 0 0.5rem; color: #9db2d8; }}
  .sub {{ color: #8a94ad; font-size: 0.95rem; }}

  .metrics {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
    margin-top: 1.5rem;
  }}
  .metric {{
    background: #141a33;
    padding: 1rem 1.25rem;
    border-radius: 8px;
    border: 1px solid #1e2748;
  }}
  .metric .label {{ font-size: 0.8rem; color: #8a94ad; text-transform: uppercase; letter-spacing: 0.05em; }}
  .metric .value {{ font-size: 1.8rem; font-weight: 600; margin-top: 0.25rem; }}
  .metric .value.ok {{ color: #4ade80; }}
  .metric .value.fail {{ color: #f87171; }}

  table {{
    border-collapse: collapse;
    width: 100%;
    background: #141a33;
    border-radius: 8px;
    overflow: hidden;
    border: 1px solid #1e2748;
  }}
  th, td {{ padding: 0.5rem 0.8rem; text-align: left; border-bottom: 1px solid #1e2748; }}
  th {{ background: #1a2142; color: #9db2d8; font-weight: 600; }}
  tr:last-child td {{ border-bottom: none; }}
  code {{ background: #0b1020; padding: 0.15em 0.4em; border-radius: 3px; font-size: 0.9em; }}

  .file-card {{
    background: #141a33;
    border: 1px solid #1e2748;
    border-radius: 8px;
    margin-bottom: 0.75rem;
    overflow: hidden;
  }}
  .file-card[open] {{ border-color: #334186; }}
  .file-card summary {{ cursor: pointer; padding: 1rem 1.25rem; list-style: none; }}
  .file-card summary::-webkit-details-marker {{ display: none; }}
  .file-header {{ display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap; }}
  .filename {{ font-weight: 600; margin-left: 0.5rem; }}
  .status {{
    display: inline-block;
    padding: 0.15em 0.5em;
    border-radius: 4px;
    font-size: 0.8rem;
    font-weight: 600;
  }}
  .status.ok {{ background: rgba(74, 222, 128, 0.2); color: #4ade80; }}
  .status.fail {{ background: rgba(248, 113, 113, 0.2); color: #f87171; }}
  .file-meta {{ display: flex; gap: 0.75rem; font-size: 0.85rem; color: #8a94ad; align-items: center; }}
  .confidence {{ color: #e6eaf2; font-weight: 500; }}
  .badge {{ font-size: 0.75rem; padding: 0.1em 0.5em; border-radius: 3px; }}
  .badge.ok {{ background: rgba(74, 222, 128, 0.15); color: #4ade80; }}
  .badge.fail {{ background: rgba(248, 113, 113, 0.15); color: #f87171; }}
  .badge.neutral {{ background: rgba(154, 178, 216, 0.15); color: #9db2d8; }}
  .file-body {{ padding: 0 1.25rem 1.25rem; border-top: 1px solid #1e2748; }}

  .patterns {{ list-style: none; padding: 0; margin: 0.5rem 0; }}
  .patterns li {{ padding: 0.35rem 0; border-bottom: 1px dashed #1e2748; }}
  .patterns li:last-child {{ border-bottom: none; }}
  .note {{ color: #8a94ad; font-size: 0.9em; margin-left: 0.5em; }}

  .error {{
    background: rgba(248, 113, 113, 0.1);
    border-left: 3px solid #f87171;
    padding: 0.5rem 0.75rem;
    margin: 0 1.25rem 1rem;
    border-radius: 3px;
    color: #fca5a5;
    font-size: 0.9rem;
  }}

  /* difflib table overrides */
  table.diff {{ font-family: "SF Mono", Consolas, Menlo, monospace; font-size: 0.8rem; }}
  table.diff th {{ background: #1a2142; }}
  table.diff td {{ padding: 2px 6px; white-space: pre; border-bottom: none; }}
  .diff_header {{ background: #1a2142 !important; color: #9db2d8 !important; }}
  .diff_next {{ color: #8a94ad; }}
  .diff_add {{ background: rgba(74, 222, 128, 0.18) !important; color: #4ade80; }}
  .diff_chg {{ background: rgba(251, 191, 36, 0.18) !important; color: #fbbf24; }}
  .diff_sub {{ background: rgba(248, 113, 113, 0.18) !important; color: #fca5a5; }}

  footer {{ margin-top: 3rem; color: #8a94ad; font-size: 0.85rem; text-align: center; }}
</style>
</head>
<body>
<div class="container">
  <h1>QAMigrate Migration Report</h1>
  <div class="sub">{source_lang} &rarr; {target_lang}</div>
  <div class="sub">Started: {started_at} &middot; Finished: {finished_at}</div>

  <div class="metrics">
    <div class="metric"><div class="label">Files migrated</div><div class="value ok">{success_count}<span style="font-size: 0.6em; color: #8a94ad;">/{total_files}</span></div></div>
    <div class="metric"><div class="label">Failed</div><div class="value{fail_class}">{failed_count}</div></div>
    <div class="metric"><div class="label">Patterns handled</div><div class="value">{total_patterns}</div></div>
    <div class="metric"><div class="label">Avg confidence</div><div class="value">{avg_confidence}%</div></div>
    <div class="metric"><div class="label">Total time</div><div class="value">{total_duration}s</div></div>
    <div class="metric"><div class="label">Est. hours saved</div><div class="value ok">~{hours_saved}</div></div>
  </div>

  <h2>Patterns handled</h2>
  <table>
    <thead><tr><th>Pattern</th><th>Count</th></tr></thead>
    <tbody>{patterns_rows}</tbody>
  </table>

  <h2>Files</h2>
  {files_html}

  <footer>Generated by <strong>QAMigrate</strong> &middot; <a href="https://github.com/QATonic/QAMigrate" style="color: #9db2d8;">github.com/QATonic/QAMigrate</a></footer>
</div>
</body>
</html>
"""


