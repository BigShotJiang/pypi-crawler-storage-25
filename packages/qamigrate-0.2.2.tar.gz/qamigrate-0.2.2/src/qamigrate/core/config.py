"""Core configuration module for QAMigrate."""

from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load .env file from current directory or project root
load_dotenv()


class PipelineConfig(BaseModel):
    """Pipeline orchestration settings."""

    max_retries: int = Field(default=3, description="Maximum fix attempts before failing")


class ScannerConfig(BaseModel):
    """Configuration for the Scanner Agent."""

    include_patterns: list[str] = Field(default=["**/*.java"])
    exclude_patterns: list[str] = Field(default=["**/target/**", "**/build/**", "**/playwright/**"])
    max_file_size_kb: int = Field(default=500)


class CoderConfig(BaseModel):
    """Configuration for the Coder Agent."""

    model: str = Field(default="claude-sonnet-4-20250514")
    temperature: float = Field(default=0.1)
    max_tokens: int = Field(default=8192)


class CompilerConfig(BaseModel):
    """Configuration for the Compiler Agent."""

    build_tool: str = Field(default="maven")
    timeout_seconds: int = Field(default=120)
    java_version: str = Field(default="17")
    skip: bool = Field(default=False, description="Skip compilation validation (useful when Playwright JARs not available locally)")


class FixerConfig(BaseModel):
    """Configuration for the Fixer Agent."""

    model: str = Field(default="claude-sonnet-4-20250514")
    max_fix_attempts: int = Field(default=3)
    use_rule_based_first: bool = Field(default=True)
    group_similar_errors: bool = Field(default=True)


class LoggingConfig(BaseModel):
    """Configuration for logging."""

    level: str = Field(default="INFO")
    format: str = Field(default="json")
    file: str | None = Field(default=None)


class ArtifactConfig(BaseModel):
    """Configuration for artifact management."""

    output_dir: str = Field(default="./qamigrate-output")
    retention_days: int = Field(default=7)
    compress: bool = Field(default=True)


class QAMigrateConfig(BaseSettings):
    """Complete configuration for QAMigrate."""

    model_config = SettingsConfigDict(
        env_prefix="QAMIGRATE_",
        env_nested_delimiter="__",
    )

    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)
    scanner: ScannerConfig = Field(default_factory=ScannerConfig)
    coder: CoderConfig = Field(default_factory=CoderConfig)
    compiler: CompilerConfig = Field(default_factory=CompilerConfig)
    fixer: FixerConfig = Field(default_factory=FixerConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    artifacts: ArtifactConfig = Field(default_factory=ArtifactConfig)

    # API Keys (loaded from environment)
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")

    @classmethod
    def load(cls, config_path: Path | None = None) -> "QAMigrateConfig":
        """Load configuration from YAML file and environment variables."""
        config_data: dict[str, Any] = {}

        if config_path is None:
            config_path = Path.cwd() / "qamigrate.yaml"

        if config_path.exists():
            with open(config_path) as f:
                config_data = yaml.safe_load(f) or {}

        return cls(**config_data)


def get_config(config_path: Path | None = None) -> QAMigrateConfig:
    """Get configuration instance."""
    return QAMigrateConfig.load(config_path)
