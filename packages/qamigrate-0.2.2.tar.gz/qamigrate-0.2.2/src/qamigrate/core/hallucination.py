"""
Cross-file hallucination detector.

Scans generated Java code for method calls on sibling classes that do not
exist in those classes' public APIs. We flag these as `Hallucination`s so
the user sees them in the report, even if we can't auto-fix them yet.
"""

from __future__ import annotations

import difflib
import re
from typing import Iterable

from qamigrate.core.report import Hallucination


# Matches `variableOrType.methodName(` in Java source.
# Examples that match:  loginPage.getErrorMessage(  page.locator(  Assert.assertTrue(
# This is intentionally loose -- we filter to the interesting targets
# afterwards using the sibling class list.
_METHOD_CALL_RE = re.compile(r"([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)\s*\(")


def _extract_method_names(signatures: list[str]) -> set[str]:
    """Pull just the method names out of a list of Java signatures."""
    names: set[str] = set()
    for sig in signatures:
        # grab the last token before `(`
        match = re.search(r"([A-Za-z_]\w*)\s*\(", sig)
        if match:
            names.add(match.group(1))
    return names


def _find_variables_of_type(source: str, class_name: str) -> set[str]:
    """
    Find local variables / fields in `source` that are declared as `class_name`.
    Returns the set of variable names.

    Only considers declarations where `ClassName` and the variable name appear
    on the same statement (separated by horizontal whitespace only), followed
    by `=`, `;`, `,`, `)`, or `<` (generics). This avoids false positives on
    comments or unrelated text that just happen to contain the class name.
    """
    names: set[str] = set()
    escaped = re.escape(class_name)
    # Same-line declaration: `ClassName varName[=;,)<]`
    # [^\S\n] = "whitespace but not newline" = just spaces/tabs
    pattern = rf"\b{escaped}[^\S\n]+([a-zA-Z_]\w*)\s*[=;,)<]"
    for m in re.finditer(pattern, source):
        names.add(m.group(1))
    return names


def detect_hallucinations(
    generated_code: str,
    sibling_signatures: dict[str, list[str]],
) -> list[Hallucination]:
    """
    Scan `generated_code` for method calls on variables whose types appear in
    `sibling_signatures`, and flag any calls that are not in the known
    signatures for that class.

    This is conservative: we only flag calls on variables we've confidently
    typed. Calls on unknown receivers (like `page.foo()` where `page` has no
    declaration in the file) are ignored -- we can't tell what class that is.
    """
    if not sibling_signatures or not generated_code:
        return []

    results: list[Hallucination] = []

    # For each sibling class, build (variable names that hold it, allowed methods)
    for cls, sigs in sibling_signatures.items():
        var_names = _find_variables_of_type(generated_code, cls)
        if not var_names:
            continue

        allowed_methods = _extract_method_names(sigs)
        if not allowed_methods:
            # If we have no signatures at all, we can't validate -- skip.
            continue

        for match in _METHOD_CALL_RE.finditer(generated_code):
            receiver, called = match.group(1), match.group(2)
            if receiver not in var_names:
                continue
            if called in allowed_methods:
                continue
            # Hallucination candidate: find closest real method for a hint.
            close = difflib.get_close_matches(called, allowed_methods, n=1, cutoff=0.6)
            similar = close[0] if close else None
            results.append(
                Hallucination(
                    called_method=f"{cls}.{called}()",
                    on_class=cls,
                    similar_to=f"{cls}.{similar}()" if similar else None,
                )
            )

    # De-duplicate preserving order
    seen: set[tuple[str, str]] = set()
    unique: list[Hallucination] = []
    for h in results:
        key = (h.on_class, h.called_method)
        if key not in seen:
            seen.add(key)
            unique.append(h)
    return unique
