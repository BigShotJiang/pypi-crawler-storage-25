"""
Fixer Agent.

Applies targeted fixes to generated Playwright Java code when compilation
fails. Two strategies:

1. Rule-based fixes for well-known errors (missing imports, void assignments).
   These are fast, deterministic, and safe.

2. LLM-based fix that returns the whole file via Anthropic tool use. We force
   structured output so the model cannot inject prose into the source. The
   fix is only accepted if it is syntactically valid Java.

The caller (pipeline) is responsible for rejecting the fix if compilation
errors go up after applying it.
"""

import re
from typing import Any

import structlog
from anthropic import Anthropic

from qamigrate.agents.compiler import CompilerError, ErrorType
from qamigrate.core.config import FixerConfig
from qamigrate.core.parser import get_parser

logger = structlog.get_logger(__name__)


# Common Playwright imports for auto-fixing missing-symbol errors
PLAYWRIGHT_IMPORTS: dict[str, str] = {
    "Page": "com.microsoft.playwright.Page",
    "Locator": "com.microsoft.playwright.Locator",
    "Browser": "com.microsoft.playwright.Browser",
    "BrowserContext": "com.microsoft.playwright.BrowserContext",
    "BrowserType": "com.microsoft.playwright.BrowserType",
    "Playwright": "com.microsoft.playwright.Playwright",
    "PlaywrightAssertions": "com.microsoft.playwright.assertions.PlaywrightAssertions",
    "AriaRole": "com.microsoft.playwright.options.AriaRole",
    "SelectOption": "com.microsoft.playwright.options.SelectOption",
    "FileChooser": "com.microsoft.playwright.FileChooser",
    "Dialog": "com.microsoft.playwright.Dialog",
    "Download": "com.microsoft.playwright.Download",
    "Frame": "com.microsoft.playwright.Frame",
    "ElementHandle": "com.microsoft.playwright.ElementHandle",
    "JSHandle": "com.microsoft.playwright.JSHandle",
    "Route": "com.microsoft.playwright.Route",
    "Request": "com.microsoft.playwright.Request",
    "Response": "com.microsoft.playwright.Response",
    "TimeoutError": "com.microsoft.playwright.TimeoutError",
    "PlaywrightException": "com.microsoft.playwright.PlaywrightException",
}


FIXER_SYSTEM_PROMPT = """You are an expert Java developer fixing Playwright test code.

You will be shown Java source code that has compilation errors, plus the exact
error list from javac. Your job is to return the ENTIRE corrected Java file.

## Hard rules

1. Return the complete file, not a patch or diff.
2. Do not invent methods, fields, or classes that were not in the original.
3. Preserve all business logic from the original file.
4. Only change what is necessary to fix the reported errors.
5. Every import must be a real package; prefer com.microsoft.playwright.*
   and org.junit.jupiter.api.*.
6. Every method body must be syntactically complete: matched braces, every
   statement terminated with a semicolon.
7. Never insert explanations, markdown, or comments containing prose that
   isn't valid Java.
8. Output must be compilable Java that parses cleanly.

## Common corrections

- Missing import -> add a proper `import ...;` statement at the top.
- "cannot find symbol" for a method on Locator -> use the correct Playwright
  API (fill, click, textContent, getAttribute, inputValue, selectOption, etc.).
- "void type not allowed here" -> Playwright action methods return void, so
  `String x = locator.click();` is wrong; write `locator.click();` on its own.
- Duplicate method/field -> remove the duplicate, keep the first one.
- Orphan code outside a class -> remove it or move it inside.
- Referenced method does not exist -> remove the reference; do not invent
  new page-object methods.
"""


PLAYWRIGHT_FIX_TOOL = {
    "name": "emit_fixed_java",
    "description": "Return the complete corrected Java source file.",
    "input_schema": {
        "type": "object",
        "required": ["source"],
        "properties": {
            "source": {
                "type": "string",
                "description": "The complete, corrected Java source code for the file.",
            },
            "notes": {
                "type": "string",
                "description": "Brief explanation of the changes made.",
            },
        },
    },
}


class FixerAgent:
    """Applies rule-based and LLM-based fixes to generated Java code."""

    def __init__(self, config: FixerConfig | None = None) -> None:
        self.config = config or FixerConfig()
        self.client = Anthropic()
        self.model = self.config.model
        self.use_rule_based_first = self.config.use_rule_based_first
        self.parser = get_parser()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fix(
        self,
        code: str,
        errors: list[CompilerError],
        retry_count: int = 0,
    ) -> tuple[str, list[str]]:
        """
        Apply fixes for compilation errors.

        Returns:
            Tuple of (possibly-fixed-code, list-of-change-descriptions).
            If all strategies fail, returns the ORIGINAL code unchanged and
            an empty change list -- we never return worse code than we got.
        """
        logger.info(
            "Fixer: attempting to fix code",
            error_count=len(errors),
            retry_count=retry_count,
        )

        changes: list[str] = []
        working_code = code

        # 1) Rule-based fixes first. These are safe: only syntactic
        #    transformations that can't invent new code.
        if self.use_rule_based_first:
            sorted_errors = sorted(errors, key=lambda e: e.line_number, reverse=True)
            for error in sorted_errors:
                new_code, change = self._apply_rule_based_fix(working_code, error)
                if change:
                    working_code = new_code
                    changes.append(change)

        # If rule-based fixes already changed something, return early so the
        # caller can recompile. No sense bothering the LLM if we might have
        # already resolved everything.
        if changes:
            logger.info("Fixer: applied rule-based fixes", count=len(changes))
            return working_code, changes

        # 2) LLM whole-file rewrite with structured output + validation.
        fixed_code, llm_change = self._apply_llm_whole_file_fix(working_code, errors)
        if fixed_code is not None:
            return fixed_code, [llm_change] if llm_change else []

        # Nothing worked. Return the ORIGINAL code so the caller doesn't
        # regress. The pipeline will stop retrying when errors don't decrease.
        logger.warning("Fixer: no fix produced; keeping original code")
        return code, []

    # ------------------------------------------------------------------
    # Rule-based fixes (safe, narrow)
    # ------------------------------------------------------------------

    def _apply_rule_based_fix(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        if error.error_type in (ErrorType.MISSING_IMPORT, ErrorType.MISSING_CLASS):
            return self._fix_missing_import(code, error)
        if error.error_type == ErrorType.TYPE_MISMATCH:
            return self._fix_type_mismatch(code, error)
        if error.error_type == ErrorType.SYNTAX:
            return self._fix_syntax_error(code, error)
        return code, None

    def _fix_missing_import(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        match = re.search(r"symbol.*(?:class|variable)\s+(\w+)", error.message)
        if not match:
            match = re.search(r"package\s+(\S+)\s+does not exist", error.message)
            if match:
                package = match.group(1)
                import_stmt = f"import {package}.*;"
                if import_stmt in code:
                    return code, None
                return self._insert_import(code, import_stmt)
            return code, None

        class_name = match.group(1)
        if class_name not in PLAYWRIGHT_IMPORTS:
            return code, None

        import_stmt = f"import {PLAYWRIGHT_IMPORTS[class_name]};"
        if import_stmt in code:
            return code, None
        return self._insert_import(code, import_stmt)

    def _insert_import(self, code: str, import_stmt: str) -> tuple[str, str | None]:
        lines = code.split("\n")
        insert_index = 0
        for i, line in enumerate(lines):
            if line.startswith("package "):
                insert_index = i + 1
            elif line.startswith("import "):
                insert_index = i + 1
        lines.insert(insert_index, import_stmt)
        return "\n".join(lines), f"Added import: {import_stmt}"

    def _fix_type_mismatch(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        lines = code.split("\n")
        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        # Common: `WebElement x = locator.click();` -- click() is void.
        for void_method in ("click", "fill", "press", "check", "uncheck", "hover"):
            pattern = rf"(\s*).*=\s*(.*\.{void_method}\([^)]*\).*)$"
            match = re.match(pattern, line)
            if match:
                indent = match.group(1)
                call = match.group(2)
                lines[line_idx] = f"{indent}{call}"
                return "\n".join(lines), (
                    f"Removed void assignment at line {error.line_number} "
                    f"({void_method}() returns void)"
                )
        return code, None

    def _fix_syntax_error(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        lines = code.split("\n")
        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        if "';' expected" in error.message:
            stripped = line.rstrip()
            if not stripped.endswith((";", "{", "}")):
                lines[line_idx] = stripped + ";"
                return "\n".join(lines), f"Added missing semicolon at line {error.line_number}"
        return code, None

    # ------------------------------------------------------------------
    # LLM whole-file fix with validation
    # ------------------------------------------------------------------

    def _apply_llm_whole_file_fix(
        self,
        code: str,
        errors: list[CompilerError],
    ) -> tuple[str | None, str | None]:
        """
        Ask the LLM to rewrite the whole file. Validate the output parses as
        Java before accepting.

        Returns:
            (fixed_code, change_description) on success,
            (None, None) if the LLM output was invalid or the call failed.
        """
        if not errors:
            return None, None

        error_listing = "\n".join(
            f"- Line {e.line_number}, col {e.column} [{e.error_type.value}]: {e.message}"
            for e in errors[:20]  # cap to keep prompt bounded
        )

        prompt = f"""Fix the compilation errors in this Playwright Java file.

## Errors from javac
{error_listing}

## Current source
```java
{code}
```

Return the complete corrected file via the `emit_fixed_java` tool. The source
must be valid Java that parses cleanly; do NOT include markdown fences,
explanations, or prose inside the source string."""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=8192,
                system=FIXER_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                tools=[PLAYWRIGHT_FIX_TOOL],
                tool_choice={"type": "tool", "name": "emit_fixed_java"},
            )
        except Exception as e:  # pragma: no cover
            logger.error("Fixer: LLM call failed", error=str(e))
            return None, None

        fixed: str | None = None
        for block in response.content:
            if getattr(block, "type", None) == "tool_use":
                data = block.input  # type: ignore[attr-defined]
                fixed = data.get("source")
                break

        if not fixed or not fixed.strip():
            logger.warning("Fixer: LLM returned no source")
            return None, None

        fixed = self._strip_any_stray_markdown(fixed)

        # VALIDATION: tree-sitter must parse this cleanly. If the LLM snuck
        # prose in, or returned something that isn't Java, reject it.
        if not self._is_valid_java(fixed):
            logger.warning("Fixer: LLM output did not parse as Java; rejecting")
            return None, None

        # Sanity check: output should be the same order-of-magnitude as input.
        # If the model returned 3 lines for a 200-line file, something is off.
        orig_lines = code.count("\n")
        new_lines = fixed.count("\n")
        if new_lines < max(10, orig_lines // 4):
            logger.warning(
                "Fixer: LLM output too short; rejecting",
                orig_lines=orig_lines,
                new_lines=new_lines,
            )
            return None, None

        return fixed, "LLM whole-file rewrite applied"

    @staticmethod
    def _strip_any_stray_markdown(text: str) -> str:
        """Defensive: if the model wrapped the code in ```java ... ``` anyway."""
        text = text.strip()
        if text.startswith("```"):
            # remove opening fence line
            text = text.split("\n", 1)[1] if "\n" in text else ""
            # remove trailing fence
            if text.rstrip().endswith("```"):
                text = text.rstrip()[:-3].rstrip()
        return text

    def _is_valid_java(self, source: str) -> bool:
        """
        Check that the source parses cleanly as Java.

        We use the raw tree-sitter tree here (not the ASTNode wrapper)
        because `has_error` is only exposed on the native Node. Tree-sitter
        is lenient: it still returns a tree for broken input, but it marks
        error spans with `ERROR` nodes, missing tokens, or `has_error=True`
        on the root.
        """
        if not source or not source.strip():
            return False
        try:
            src_bytes = source.encode("utf-8")
            tree = self.parser.parser.parse(src_bytes)
        except Exception:
            return False

        root = tree.root_node
        if root.has_error:
            return False

        # Defensive extra pass: a true Java file should have at least one
        # class_declaration at top level. Prose-polluted output usually
        # ends up as `local_variable_declaration` / `labeled_statement`
        # nodes at the top, not a class.
        top_types = {c.type for c in root.children}
        if "class_declaration" not in top_types and "interface_declaration" not in top_types:
            return False

        return True

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def suggest_fixes(
        self,
        errors: list[CompilerError],
    ) -> list[dict[str, Any]]:
        """Return fix suggestions for an error list, without applying them."""
        suggestions: list[dict[str, Any]] = []
        for error in errors:
            suggestion: dict[str, Any] = {
                "error": error.to_dict(),
                "suggestion": None,
                "confidence": "low",
            }
            if error.error_type == ErrorType.MISSING_IMPORT:
                match = re.search(r"class (\w+)", error.message)
                if match and match.group(1) in PLAYWRIGHT_IMPORTS:
                    suggestion["suggestion"] = f"Add import: {PLAYWRIGHT_IMPORTS[match.group(1)]}"
                    suggestion["confidence"] = "high"
            elif error.error_type == ErrorType.TYPE_MISMATCH:
                suggestion["suggestion"] = (
                    "Playwright action methods (click, fill, press, hover) return void; "
                    "remove any variable assignment from the left side."
                )
                suggestion["confidence"] = "medium"
            elif error.error_type == ErrorType.SYNTAX:
                suggestion["suggestion"] = "Check for missing semicolons or brackets"
                suggestion["confidence"] = "medium"
            suggestions.append(suggestion)
        return suggestions
