from setuptools import setup, find_packages

setup(
    name="shield-python",
    version="0.2.0",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
)
