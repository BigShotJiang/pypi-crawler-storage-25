/*=========================================================================
 *
 *  Copyright NumFOCUS
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *=========================================================================*/

#include "sitkEvent.h"

#define sitkEventToStringCaseMacro(n) \
  case sitk##n##Event:                \
    return (os << #n << "Event")

namespace itk::simple
{

std::ostream &
operator<<(std::ostream & os, const EventEnum k)
{
  switch (k)
  {
    sitkEventToStringCaseMacro(Any);
    sitkEventToStringCaseMacro(Abort);
    sitkEventToStringCaseMacro(Delete);
    sitkEventToStringCaseMacro(End);
    sitkEventToStringCaseMacro(Iteration);
    sitkEventToStringCaseMacro(Progress);
    sitkEventToStringCaseMacro(Start);
    sitkEventToStringCaseMacro(User);
    sitkEventToStringCaseMacro(MultiResolutionIteration);
  }
  return os;
}

} // namespace itk::simple
