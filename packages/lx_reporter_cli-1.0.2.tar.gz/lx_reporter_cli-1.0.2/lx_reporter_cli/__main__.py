#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
支持 python -m lx_reporter_cli 运行方式
"""

from lx_reporter_cli import main

if __name__ == '__main__':
    main()
