#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
安装灵犀埋点CLI
兼容 Python 2.7+ 和 Python 3.x
"""

from __future__ import print_function, unicode_literals

import subprocess
import sys

# 配置信息
LX_CLI_PACKAGE = "lx-reporter-cli"
MIN_NODE_VERSION = "18.0.0"

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

if PY3:
    input_func = input
else:
    input_func = raw_input


def run_command(cmd, capture_output=True):
    """运行 shell 命令并返回结果"""
    try:
        if PY3:
            result = subprocess.run(
                cmd,
                capture_output=capture_output,
                text=True,
                check=False
            )
            return result.returncode, result.stdout, result.stderr
        else:
            if capture_output:
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = proc.communicate()
                return proc.returncode, stdout.decode('utf-8'), stderr.decode('utf-8')
            else:
                returncode = subprocess.call(cmd)
                return returncode, "", ""
    except Exception as e:
        return -1, "", str(e)


def check_node_installed():
    """检查 Node.js 是否已安装"""
    returncode, _, _ = run_command(["node", "--version"])
    return returncode == 0


def get_node_version():
    """获取当前 Node.js 版本"""
    returncode, stdout, _ = run_command(["node", "--version"])
    if returncode == 0:
        return stdout.strip().lstrip("v")
    return None


def version_compare(version1, version2):
    """比较两个版本号"""
    v1_parts = [int(x) for x in version1.split(".")]
    v2_parts = [int(x) for x in version2.split(".")]

    for i in range(max(len(v1_parts), len(v2_parts))):
        v1 = v1_parts[i] if i < len(v1_parts) else 0
        v2 = v2_parts[i] if i < len(v2_parts) else 0
        if v1 < v2:
            return -1
        if v1 > v2:
            return 1
    return 0


def check_node_version_requirement():
    """检查 Node.js 版本是否满足要求"""
    current_version = get_node_version()
    if current_version is None:
        return False, "无法获取 Node.js 版本"

    if version_compare(current_version, MIN_NODE_VERSION) >= 0:
        return True, "Node.js v" + current_version
    else:
        return False, "Node.js v" + current_version + " (需要 >= v" + MIN_NODE_VERSION + ")"


def install_lx_cli():
    """使用 npm 全局安装 lx-reporter-cli"""
    cmd = ["npm", "install", "-g", LX_CLI_PACKAGE]

    try:
        if PY3:
            result = subprocess.run(cmd, check=False)
            return result.returncode == 0
        else:
            returncode = subprocess.call(cmd)
            return returncode == 0
    except Exception as e:
        print("❌ 安装失败: " + str(e))
        return False


def check_lx_installed():
    """
    检查 lx 命令是否已安装
    
    Returns:
        (是否已安装, 版本号)
    """
    returncode, stdout, _ = run_command(["lx", "--version"])
    if returncode == 0:
        version = stdout.strip()
        return True, version
    return False, None


def main():
    # 0. 检查 lx 是否已存在
    lx_installed, lx_version = check_lx_installed()
    if lx_installed:
        print("✅ lx-cli 已安装，版本: " + lx_version)
        return

    # 1. 检查 Node.js
    if not check_node_installed():
        print("❌ 错误: 未检测到 Node.js，请先安装 Node.js")
        print("   最低版本要求: v" + MIN_NODE_VERSION)
        sys.exit(1)

    version_ok, version_info = check_node_version_requirement()
    if not version_ok:
        print("⚠️  " + version_info)
        print("   建议升级到 Node.js v" + MIN_NODE_VERSION + " 或更高版本")

    # 2. 安装 lx-cli
    if not install_lx_cli():
        sys.exit(1)

    # 5. 验证安装
    installed, _ = check_lx_installed()
    if installed:
        print("\n🎉 安装完成！")
    else:
        print("⚠️  安装失败！")
        sys.exit(1)

# 导入时自动执行安装
main()
