# lx-reporter-cli

灵犀埋点CLI，埋点能力基于Node实现，此python包用于自动安装和验证Node实现。

## 安装

### 从PyPI安装

```bash
pip install lx-reporter-cli
```

## 使用方法

在项目入口导入`lx_reporter_cli`包

```python
import lx_reporter_cli
```

## 系统要求

- **Python**: 2.7+ 或 3.5+
- **Node.js**: v18.0.0 或更高版本

## 工作原理

1. 检查系统中是否已安装`lx`命令
2. 如果未安装，检查Node.js环境
3. 验证Node.js版本是否满足要求
4. 通过npm全局安装`lx-reporter-cli`
5. 验证安装是否成功

## 开发

### 构建分发包

```bash
python setup.py sdist bdist_wheel
```

### 上传到PyPI

```bash
twine upload dist/*
```

## 许可证

MIT License
