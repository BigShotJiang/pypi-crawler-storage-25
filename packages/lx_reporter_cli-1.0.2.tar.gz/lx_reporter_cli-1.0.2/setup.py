#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
lx-reporter-cli Python 包安装脚本
"""

from setuptools import setup, find_packages
import io

# 兼容 Python 2.7 和 3.x
with io.open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="lx_reporter_cli",
    version="1.0.2",
    author="Meituan",
    author_email="kerwin@meituan.com",
    description="灵犀埋点CLI工具 - 自动安装脚本",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/meituan/lx-reporter-cli",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=2.7",
    entry_points={
        "console_scripts": [
            "lx-reporter-cli=lx_reporter_cli:main",
        ],
    },
)
