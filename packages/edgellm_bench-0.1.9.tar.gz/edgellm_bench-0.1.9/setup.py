from setuptools import find_packages, setup

setup(
    name="edgellm-bench",
    version="0.1.9",
    author="Ruocheng Jia",
    author_email="ruochengj@nvidia.com",
    description="TensorRT Edge-LLM Benchmark CLI Tool",
    python_requires=">=3.10",
    install_requires=["requests", "tqdm", "beautifulsoup4"],
    packages=find_packages(),
    zip_safe=False,
    platforms="linux",
    entry_points={
        "console_scripts": [
            "edgellm-bench = edgellm_bench.__main__:main",
        ]
    },
)
