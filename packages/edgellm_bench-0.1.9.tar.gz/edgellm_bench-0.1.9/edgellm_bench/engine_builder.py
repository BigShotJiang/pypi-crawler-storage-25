"""Engine builder — wraps the llm_build C++ executable."""

import os
import re
import subprocess
import sys

from .config import get_build_dir
from .utils import find_executable, get_subprocess_env, is_audio_precision, is_eagle_base, is_eagle_draft, is_visual_precision


def _detect_engine_filename(precision: str) -> str:
    """Determine engine filename based on precision string.

    Eagle base models produce 'eagle_base.engine',
    Eagle draft models produce 'eagle_draft.engine',
    standard LLMs produce 'llm.engine'.
    """
    if is_eagle_draft(precision):
        return "eagle_draft.engine"
    if is_eagle_base(precision):
        return "eagle_base.engine"
    return "llm.engine"


def _create_bench_symlinks(engine_dir: str, precision: str | None) -> None:
    """Create symlinks so llm_bench finds eagle engines by expected names.

    llm_bench expects:
      eagle_verify mode   -> llm.engine + config.json
      eagle_draft_* mode  -> eagle_draft.engine + draft_config.json

    llm_build produces:
      --eagleBase  -> eagle_base.engine + base_config.json
      --eagleDraft -> eagle_draft.engine + draft_config.json  (already correct)
    """
    if not precision or not is_eagle_base(precision):
        return

    symlink_map = {
        "llm.engine": "eagle_base.engine",
        "config.json": "base_config.json",
    }
    for link_name, target_name in symlink_map.items():
        link_path = os.path.join(engine_dir, link_name)
        target_path = os.path.join(engine_dir, target_name)
        if os.path.exists(target_path) and not os.path.exists(link_path):
            os.symlink(target_name, link_path)
            print(f"  Symlinked {link_name} -> {target_name}")


def _print_visual_engine_info(engine_subdir: str) -> None:
    """Print visual engine input/output shape info from config.json."""
    import json
    cfg_path = os.path.join(engine_subdir, "config.json")
    if not os.path.isfile(cfg_path):
        return
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
        bc = cfg.get("builder_config", {})
        min_tok = bc.get("min_image_tokens", "?")
        max_tok = bc.get("max_image_tokens", "?")
        img_size = cfg.get("vision_config", {}).get("image_size")
        hidden = cfg.get("text_config", {}).get("hidden_size", "?")
        if isinstance(img_size, list):
            img_str = f"{img_size[0]}x{img_size[1]}"
        elif img_size:
            img_str = f"{img_size}x{img_size}"
        else:
            img_str = "?"
        print(f"  Input: 1x3x{img_str}  Output: [{min_tok}..{max_tok}]x{hidden}  (image_tokens: {min_tok}~{max_tok})")
    except Exception:
        pass


def build_engine(
    onnx_dir: str,
    engine_dir: str,
    build_dir: str = None,
    max_seq_len: int = 4096,
    max_batch_size: int = None,
    max_input_len: int = 2048,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Build a TensorRT engine from ONNX model.

    Args:
        onnx_dir: Directory containing model.onnx and related files.
        engine_dir: Output directory for the built engine.
        build_dir: Build directory containing C++ executables.
        max_seq_len: Maximum sequence length (KV cache capacity).
        max_batch_size: Maximum batch size.
        max_input_len: Maximum input length.
        precision: Precision string (e.g., 'llm-base-fp8-fp16', 'draft-eagle3-fp16-fp16').
        extra_args: Additional command-line arguments for llm_build.

    Returns:
        dict with 'success', 'output', 'error' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    is_visual = is_visual_precision(precision)
    is_audio = is_audio_precision(precision)
    os.makedirs(engine_dir, exist_ok=True)

    # Check if engine already exists (filename / path depends on model type)
    if is_visual:
        # visual_build saves engine to <engineDir>/visual/ subdirectory
        visual_engine_subdir = os.path.join(engine_dir, "visual")
        if os.path.isdir(visual_engine_subdir) and any(
            f.endswith(".engine") for f in os.listdir(visual_engine_subdir)
        ):
            print(f"Visual engine already exists at {visual_engine_subdir}, skipping build.")
            return {"success": True, "output": "Engine already exists", "error": None}
    elif is_audio:
        # audio_build saves engine to <engineDir>/audio/ or <engineDir>/code2wav/ subdirectory
        for audio_subdir_name in ("audio", "code2wav"):
            audio_engine_subdir = os.path.join(engine_dir, audio_subdir_name)
            if os.path.isdir(audio_engine_subdir) and any(
                f.endswith(".engine") for f in os.listdir(audio_engine_subdir)
            ):
                print(f"Audio engine already exists at {audio_engine_subdir}, skipping build.")
                return {"success": True, "output": "Engine already exists", "error": None}
    else:
        engine_filename = _detect_engine_filename(precision) if precision else "llm.engine"
        engine_file = os.path.join(engine_dir, engine_filename)
        if os.path.exists(engine_file):
            print(f"Engine already exists at {engine_file}, skipping build.")
            _create_bench_symlinks(engine_dir, precision)
            return {"success": True, "output": "Engine already exists", "error": None}

    if is_visual:
        executable = find_executable(build_dir, "visual_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
            "--minImageTokens=256",
        ]
    elif is_audio:
        executable = find_executable(build_dir, "audio_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
        ]
    else:
        executable = find_executable(build_dir, "llm_build")
        cmd = [
            executable,
            f"--onnxDir={onnx_dir}",
            f"--engineDir={engine_dir}",
            f"--maxInputLen={max_input_len}",
            f"--maxKVCacheCapacity={max_seq_len}",
        ]
        if max_batch_size is not None:
            cmd.append(f"--maxBatchSize={max_batch_size}")

        # Auto-detect Eagle flags from precision string
        if precision:
            if is_eagle_draft(precision):
                cmd.append("--eagleDraft")
            elif is_eagle_base(precision):
                cmd.append("--eagleBase")

    if extra_args:
        cmd.extend(extra_args)

    log_path = os.path.join(engine_dir, "build.log")
    print(f"Building engine... (log: {log_path})")
    print(f"  cmd: {' '.join(cmd)}")

    try:
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1200)
        output = "".join(output_lines)
        if proc.returncode != 0:
            # Print last 20 lines to terminal on failure
            print(f"Build FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"  {line}")
            exe_name = "visual_build" if is_visual else "audio_build" if is_audio else "llm_build"
            return {
                "success": False,
                "output": output,
                "error": f"{exe_name} exited with code {proc.returncode}",
            }

        # Verify engine files were fully written (scratch filesystems may truncate)
        engine_size_match = re.search(
            r"Loaded engine size:\s*(\d+)\s*MiB", output
        )
        if engine_size_match:
            # We found "Loaded engine size: N MiB" — verify on disk
            expected_mib = int(engine_size_match.group(1))
            for root, _dirs, files in os.walk(engine_dir):
                for f in files:
                    if f.endswith(".engine"):
                        fpath = os.path.join(root, f)
                        actual = os.path.getsize(fpath)
                        actual_mib = actual / (1024 * 1024)
                        # Allow 10% tolerance for MiB rounding
                        if actual_mib < expected_mib * 0.9:
                            return {
                                "success": False,
                                "output": output,
                                "error": (
                                    f"Engine file appears truncated: {fpath} is "
                                    f"{actual_mib:.1f} MiB on disk but build reported "
                                    f"{expected_mib} MiB. This usually indicates a "
                                    f"filesystem I/O error (common on scratch mounts). "
                                    f"Delete the engine and rebuild."
                                ),
                            }
        else:
            # Fallback: check "Engine saved to <path>" and verify file exists & non-empty
            engine_saved_match = re.search(
                r"Engine saved to\s+(\S+)", output
            )
            if engine_saved_match:
                saved_path = engine_saved_match.group(1)
                if os.path.isfile(saved_path):
                    actual = os.path.getsize(saved_path)
                    if actual == 0:
                        return {
                            "success": False,
                            "output": output,
                            "error": (
                                f"Engine file is empty (0 bytes): {saved_path}. "
                                f"This usually indicates a filesystem I/O error "
                                f"(common on scratch mounts). Delete the engine and rebuild."
                            ),
                        }

        # Create symlinks so llm_bench can find the engine files.
        if not is_visual and not is_audio:
            _create_bench_symlinks(engine_dir, precision)

        if is_visual:
            done_path = os.path.join(engine_dir, "visual")
            _print_visual_engine_info(done_path)
        elif is_audio:
            # audio_build creates either audio/ or code2wav/ subdirectory
            for subdir in ("audio", "code2wav"):
                candidate = os.path.join(engine_dir, subdir)
                if os.path.isdir(candidate):
                    done_path = candidate
                    break
            else:
                done_path = engine_dir
        else:
            done_path = engine_dir
        print(f"Build complete: {done_path}")
        return {"success": True, "output": output, "error": None}
    except subprocess.TimeoutExpired:
        proc.kill()
        return {"success": False, "output": "", "error": "Engine build timed out (1200s)"}
    except Exception as e:
        return {"success": False, "output": "", "error": str(e)}
