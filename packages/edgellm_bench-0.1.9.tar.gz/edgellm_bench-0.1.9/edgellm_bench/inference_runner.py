"""Inference runner — wraps llm_inference for end-to-end Eagle decode benchmarking."""

import json
import os
import re
import subprocess
import sys

from .config import get_build_dir
from .utils import EAGLE_ENGINE_FILES, find_executable, get_subprocess_env, is_audio_precision

# 100 MT-Bench-style prompts for benchmarking (covering writing, roleplay,
# reasoning, math, coding, extraction, STEM, humanities, and general knowledge).
MTBENCH_PROMPTS = [
    # --- Writing (1-12) ---
    "Compose an engaging travel blog post about a recent trip to Hawaii, highlighting cultural experiences and must-see attractions.",
    "Draft a professional email seeking your supervisor's feedback on the 'Quarterly Financial Report' you prepared. Ask specifically about the data analysis, presentation style, and the clarity of conclusions drawn. Keep the email short and to the point.",
    "Write a persuasive essay arguing for or against the adoption of a four-day work week. Support your argument with evidence and examples.",
    "Write a descriptive paragraph about a bustling marketplace, incorporating sensory details such as smells, sounds, and visual elements to create an immersive experience for the reader.",
    "Create a short story about a detective solving a mystery in a futuristic city. The story should include a twist ending.",
    "Write a cover letter for a software engineering position at a leading tech company. Highlight relevant skills and experience.",
    "Compose a product review for a new wireless headphone, covering sound quality, comfort, battery life, and value for money.",
    "Write a concise executive summary for a business plan proposing a new mobile health application targeting elderly users.",
    "Draft a formal complaint letter to an airline about a delayed flight and lost luggage. Be specific about dates, flight numbers, and requested compensation.",
    "Write a motivational speech for a high school graduation ceremony. Focus on resilience and embracing change.",
    "Compose a technical blog post explaining the benefits of containerization using Docker for web application deployment.",
    "Write an engaging product description for an eco-friendly water bottle made from recycled ocean plastics.",
    # --- Roleplay (13-24) ---
    "Imagine you are a robot. Explain to a 5-year-old how you work and what you can do.",
    "You are a time traveler from the year 3000. Describe the most significant changes in human society compared to today.",
    "Act as a personal fitness trainer and create a one-week workout plan for a beginner who wants to lose weight and build strength.",
    "You are a medieval knight. Describe your daily routine, including training, meals, and duties at the castle.",
    "Imagine you are an alien visiting Earth for the first time. Write a report to your home planet describing human behavior at a shopping mall.",
    "You are a professional chef. Explain how to make a perfect French omelette, step by step, to someone who has never cooked before.",
    "Act as a career counselor and advise a college student who is torn between pursuing a career in medicine or computer science.",
    "You are a tour guide in ancient Rome. Describe the Colosseum to a group of tourists, including its history, architecture, and events held there.",
    "Imagine you are a deep-sea explorer who just discovered a new species of fish. Write a journal entry describing the discovery.",
    "You are a financial advisor. Explain to a young professional how to start investing with a small amount of money.",
    "Act as a museum curator and describe the significance of the Mona Lisa to a group of visitors.",
    "You are the captain of a spaceship on a mission to Mars. Write a log entry describing the challenges of the first week in space.",
    # --- Reasoning (25-36) ---
    "How do the economic, social, and environmental factors interplay in shaping public policy? Discuss with specific examples.",
    "Analyze the pros and cons of remote work from the perspectives of employees, employers, and society.",
    "If we could travel back in time, what ethical considerations should guide our actions? Discuss at least three scenarios.",
    "Compare and contrast the educational systems of Finland and the United States. What lessons can each learn from the other?",
    "Evaluate the argument: 'Artificial intelligence will create more jobs than it eliminates.' Present both supporting and opposing viewpoints.",
    "A company has a limited budget and must choose between investing in employee training or upgrading its technology infrastructure. What factors should be considered?",
    "Discuss the potential consequences of a universal basic income on labor markets, innovation, and social well-being.",
    "Should social media platforms be responsible for the content posted by their users? Argue both sides.",
    "Explain the trolley problem and discuss how different ethical frameworks would approach it.",
    "Why do some startups succeed while others fail? Identify the top five factors and explain their relative importance.",
    "Discuss the impact of climate change on global food security. What are the most promising solutions?",
    "Is it ethical to use animals for scientific research? Present a balanced analysis of the arguments on both sides.",
    # --- Math (37-48) ---
    "If a train travels at 60 miles per hour for 2.5 hours, then stops for 30 minutes, and then continues at 80 miles per hour for another 1.5 hours, what is the total distance covered by the train?",
    "A store sells apples for $1.50 each and oranges for $2.00 each. If a customer buys a total of 10 fruits for $17.00, how many of each type did they buy?",
    "Calculate the area of a triangle with vertices at coordinates (1, 2), (4, 6), and (7, 2).",
    "A ball is thrown upward with an initial velocity of 20 m/s. Ignoring air resistance and using g = 10 m/s^2, how high will it go and how long until it returns to the ground?",
    "A rectangular garden has a perimeter of 56 meters. If the length is 4 meters more than the width, find the dimensions of the garden.",
    "There are 25 students in a class. Each student shakes hands with every other student exactly once. How many handshakes occur in total?",
    "A car travels from city A to city B at 60 km/h and returns at 40 km/h. What is the average speed for the entire round trip?",
    "Solve the equation: 2x^2 - 5x + 3 = 0. Show your work step by step.",
    "A cylindrical tank with radius 3 meters and height 10 meters is being filled with water at a rate of 2 cubic meters per minute. How long will it take to fill the tank completely?",
    "If the probability of rain on any given day is 0.3, what is the probability that it rains on exactly 2 out of 5 days?",
    "A company's revenue grew from $2 million to $3.2 million over 3 years. What is the compound annual growth rate?",
    "In how many ways can you arrange the letters in the word MISSISSIPPI?",
    # --- Coding (49-62) ---
    "Write a C++ function to find the nth Fibonacci number using dynamic programming.",
    "Write a Python function that takes a list of integers and returns the two numbers that add up to a specific target. Optimize for time complexity.",
    "Implement a binary search algorithm in Python. Include error handling for edge cases.",
    "Write a function in JavaScript that debounces another function, limiting how often it can be called.",
    "Write a Python function to check if a given string is a valid palindrome, considering only alphanumeric characters and ignoring cases.",
    "Implement a simple LRU (Least Recently Used) cache in Python with get and put operations, both in O(1) time.",
    "Write a Python function to merge two sorted linked lists into a single sorted linked list.",
    "Write a SQL query to find the second highest salary from an Employee table. Handle the case where there might be duplicate salaries.",
    "Implement a stack using two queues in Python. Support push, pop, top, and empty operations.",
    "Write a Python function to find the longest common subsequence of two strings using dynamic programming.",
    "Write a recursive Python function to generate all permutations of a given string.",
    "Implement a function in Python that serializes and deserializes a binary tree to and from a string.",
    "Write a Python class implementing a min-heap with insert, extract_min, and peek operations.",
    "Write a Python function that takes a nested dictionary and flattens it into a single-level dictionary with dot-separated keys.",
    # --- Extraction (63-72) ---
    "Given a set of complex equations, extract all unique variable names from each equation. Return the results as a JSON string. Equations: 1) y = (3/4)x^3 - e^(2x) + sin(pi*x) - sqrt(7) 2) 2A - B/(3+C) * sum(googol) = min(googol, key=lambda x: x) 3) E = meli squared",
    "Extract the key dates, names, and events from the following passage and organize them in a table: 'On July 20, 1969, Neil Armstrong and Buzz Aldrin became the first humans to walk on the Moon as part of NASA Apollo 11 mission. Michael Collins orbited above in the command module.'",
    "From the following restaurant review, extract: restaurant name, cuisine type, rating, price range, and main complaints: 'We visited La Maison last Friday for their French cuisine. The ambiance was lovely but our 45-minute wait for appetizers was unacceptable. I would rate it 3 out of 5 stars. Expect to spend around $80 per person.'",
    "Parse the following log entry and extract the timestamp, log level, source module, and error message: '[2024-03-15T14:22:33.456Z] ERROR [auth-service] Failed to validate JWT token: token expired at 2024-03-15T14:00:00Z for user_id=12345'",
    "Extract all the numerical statistics from the following paragraph and present them in a bullet list: 'The global AI market was valued at $136.6 billion in 2022 and is projected to reach $1,811.8 billion by 2030, growing at a CAGR of 38.1%. North America held the largest market share at 36.8%.'",
    "From the following recipe text, extract the ingredients list with quantities: 'To make banana bread, cream together 1/3 cup melted butter with 3/4 cup sugar. Beat in 1 egg, then stir in 1 teaspoon vanilla. Mix in 1 teaspoon baking soda and a pinch of salt. Fold in 1.5 cups all-purpose flour and 3 mashed ripe bananas.'",
    "Identify and list all the programming languages, frameworks, and tools mentioned in this job posting: 'We are looking for a full-stack developer with 3+ years experience in React, TypeScript, and Node.js. Familiarity with PostgreSQL, Redis, Docker, Kubernetes, and AWS is a plus. Experience with GraphQL and CI/CD pipelines using GitHub Actions preferred.'",
    "Extract the sender, recipient, subject, date, and action items from this email: 'From: john@example.com To: team@example.com Date: March 10, 2024 Subject: Q1 Planning Meeting Hi team, Please review the attached Q1 roadmap by Friday. Sarah, can you prepare the budget forecast? Mike, please schedule the client calls for next week. Thanks, John'",
    "From the following text, extract all mentioned countries and their associated facts: 'Japan has the third-largest economy with a GDP of $4.2 trillion. Germany leads European manufacturing with exports worth $1.6 trillion. Brazil is the largest country in South America, covering 8.5 million square kilometers.'",
    "Parse the following address into structured components (street, city, state, zip, country): '1600 Amphitheatre Parkway, Mountain View, CA 94043, United States'",
    # --- STEM (73-86) ---
    "What are the differences between plant-based and animal-based protein sources in terms of nutritional value, environmental impact, and ethical considerations? Provide a balanced comparison.",
    "Explain the process of photosynthesis in a way that a child could understand.",
    "Describe the concept of quantum entanglement and its potential applications in technology.",
    "Explain the difference between machine learning, deep learning, and artificial intelligence. Provide examples of each.",
    "How does CRISPR-Cas9 gene editing work, and what are its potential applications and ethical concerns?",
    "Describe the life cycle of a star, from its formation in a nebula to its eventual death.",
    "Explain how vaccines work at the molecular level, including the role of antigens and antibodies.",
    "What is the difference between nuclear fission and nuclear fusion? Which one powers the sun?",
    "Explain how a transformer neural network architecture works, including the attention mechanism.",
    "Describe the greenhouse effect and explain how human activities contribute to climate change.",
    "How do semiconductors work, and why are they essential for modern electronics?",
    "Explain the concept of entropy in thermodynamics and provide everyday examples.",
    "What are gravitational waves, and how were they first detected?",
    "Explain the difference between TCP and UDP protocols. When would you use each one?",
    # --- Humanities (87-100) ---
    "Discuss the impact of the printing press on European society during the Renaissance.",
    "Compare and contrast the philosophical ideas of Plato and Aristotle on the nature of reality.",
    "Explain the causes and consequences of the French Revolution. How did it reshape European politics?",
    "What role did the Silk Road play in cultural and economic exchange between East and West?",
    "Discuss the significance of Martin Luther King Jr.'s 'I Have a Dream' speech in the context of the American civil rights movement.",
    "How did the Industrial Revolution change the social structure of European societies?",
    "Explain the concept of social contract theory as proposed by Hobbes, Locke, and Rousseau. How do their views differ?",
    "Discuss the cultural and artistic achievements of the Harlem Renaissance.",
    "How has globalization affected indigenous cultures around the world? Provide specific examples.",
    "Discuss the ethical implications of surveillance technology in modern democratic societies.",
    "Compare the governance structures of ancient Athens and ancient Rome. Which elements persist in modern democracies?",
    "Explain the significance of the Rosetta Stone in the field of linguistics and archaeology.",
    "How did World War II influence the development of international institutions like the United Nations?",
    "Discuss the evolution of human rights concepts from the Magna Carta to the Universal Declaration of Human Rights.",
]


def _generate_input_json(
    output_path: str,
    prompts: list | None = None,
    max_generate_length: int = 512,
    batch_size: int = 1,
    temperature: float = 1.0,
    top_p: float = 0.8,
    top_k: int = 50,
) -> str:
    """Generate an input JSON file for llm_inference with MT-Bench prompts."""
    if prompts is None:
        prompts = MTBENCH_PROMPTS

    requests = []
    for prompt in prompts:
        requests.append({
            "messages": [
                {"role": "user", "content": prompt}
            ]
        })

    data = {
        "batch_size": batch_size,
        "temperature": temperature,
        "top_p": top_p,
        "top_k": top_k,
        "max_generate_length": max_generate_length,
        "requests": requests,
    }

    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)

    return output_path


def _generate_vlm_input_json(
    output_path: str,
    image_paths: list[str] | None = None,
    max_generate_length: int = 128,
    batch_size: int = 1,
) -> str:
    """Generate an input JSON file for llm_inference with VLM prompts (image + text).

    If image_paths is None, uses a default image from the project's test data.
    """
    requests = []
    if image_paths:
        for img_path in image_paths:
            requests.append({
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "image", "image": img_path},
                        {"type": "text", "text": "Please describe the image."},
                    ],
                }],
            })
    else:
        # Fallback: text-only (no image available)
        requests.append({
            "messages": [{"role": "user", "content": "Describe the color of the sky."}],
        })

    data = {
        "batch_size": batch_size,
        "temperature": 1.0,
        "top_p": 0.8,
        "top_k": 50,
        "max_generate_length": max_generate_length,
        "requests": requests,
    }

    with open(output_path, "w") as f:
        json.dump(data, f, indent=2)
    return output_path


def _find_test_images(build_dir: str) -> list[str]:
    """Find available test images in the build tree."""
    # Try common image locations relative to the project root
    candidates = [
        os.path.join(build_dir, "..", "examples", "multimodal", "pics"),
        os.path.join(build_dir, "..", "tests", "test_data"),
    ]
    images = []
    for pic_dir in candidates:
        pic_dir = os.path.normpath(pic_dir)
        if os.path.isdir(pic_dir):
            for f in sorted(os.listdir(pic_dir)):
                if f.lower().endswith((".jpeg", ".jpg", ".png")):
                    images.append(os.path.join(pic_dir, f))
    return images


def _parse_multimodal_profile(profile_path: str) -> dict:
    """Parse multimodal metrics from llm_inference profile JSON."""
    with open(profile_path) as f:
        profile = json.load(f)

    metrics = {}

    # Multimodal metrics
    mm = profile.get("multimodal", {})
    if mm:
        metrics["total_runs"] = mm.get("total_runs", 0)
        metrics["total_images"] = mm.get("total_images", 0)
        metrics["total_image_tokens"] = mm.get("total_image_tokens", 0)
        metrics["total_audios"] = mm.get("total_audios", 0)
        metrics["total_audio_tokens"] = mm.get("total_audio_tokens", 0)
        metrics["total_multimodal_tokens"] = mm.get("total_multimodal_tokens", 0)
        metrics["avg_time_per_token_ms"] = mm.get("average_time_per_token_ms", 0.0)

    # Prefill
    prefill = profile.get("prefill", {})
    if prefill:
        metrics["prefill_tokens_per_sec"] = prefill.get("tokens_per_second", 0.0)

    # Generation
    gen = profile.get("generation", {})
    if gen:
        metrics["generation_tokens_per_sec"] = gen.get("tokens_per_second", 0.0)

    # Memory
    if "peak_gpu_memory_mb" in profile:
        metrics["peak_gpu_memory_mb"] = profile["peak_gpu_memory_mb"]

    # Stage timing for multimodal processing
    stages = profile.get("stages", [])
    for stage in stages:
        stage_id = stage.get("stage_id", "")
        avg_ms = stage.get("average_time_per_run_ms", 0.0)
        total_ms = stage.get("total_time_ms", 0.0)
        if "multimodal" in stage_id.lower():
            metrics["multimodal_avg_ms"] = avg_ms
            metrics["multimodal_total_ms"] = total_ms

    return metrics


def _parse_multimodal_stdout(output: str) -> dict:
    """Parse multimodal metrics from llm_inference stdout (fallback)."""
    metrics = {}

    for pattern, key in [
        (r"Total Images:\s*(\d+)", "total_images"),
        (r"Total Image Tokens:\s*(\d+)", "total_image_tokens"),
        (r"Total Audio Clips:\s*(\d+)", "total_audios"),
        (r"Total Audio Tokens:\s*(\d+)", "total_audio_tokens"),
        (r"Total Multimodal Tokens:\s*(\d+)", "total_multimodal_tokens"),
        (r"Average Time per Token:\s*([\d.]+)\s*ms", "avg_time_per_token_ms"),
    ]:
        match = re.search(pattern, output)
        if match:
            val = match.group(1)
            metrics[key] = float(val) if "." in val else int(val)

    # Prefill/decode tokens/sec
    match = re.search(r"=== LLM Prefill ===.*?Tokens/Second:\s*([\d.]+)", output, re.DOTALL)
    if match:
        metrics["prefill_tokens_per_sec"] = float(match.group(1))
    match = re.search(r"=== LLM Generation.*?Tokens/Second:\s*([\d.]+)", output, re.DOTALL)
    if match:
        metrics["generation_tokens_per_sec"] = float(match.group(1))

    return metrics


def run_multimodal_inference(
    llm_engine_dir: str,
    multimodal_engine_dir: str,
    build_dir: str = None,
    warmup: int = 3,
    max_generate_length: int = 128,
    batch_size: int = 1,
    precision: str = None,
    extra_args: list = None,
) -> dict:
    """Run multimodal inference benchmark using llm_inference --multimodalEngineDir.

    Benchmarks visual/audio encoders as part of a full multimodal inference pipeline.
    The profile output includes per-component timing for the multimodal encoder.

    Args:
        llm_engine_dir: Directory containing the LLM engine (llm.engine + config.json).
        multimodal_engine_dir: Directory containing the visual/audio engines
            (with visual/ and/or audio/ subdirectories).
        build_dir: Build directory with C++ executables.
        warmup: Number of warmup runs.
        max_generate_length: Max tokens to generate per request.
        batch_size: Batch size for inference.
        precision: Precision string for labeling (e.g., 'visual-fp8').
        extra_args: Additional arguments for llm_inference.

    Returns:
        dict with 'success', 'output', 'error', 'metrics' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    # Validate LLM engine exists
    required_files = ["llm.engine", "config.json"]
    missing = [f for f in required_files if not os.path.exists(os.path.join(llm_engine_dir, f))]
    if missing:
        return {
            "success": False,
            "output": "",
            "error": (
                f"LLM engine files missing in {llm_engine_dir}: {', '.join(missing)}. "
                "Multimodal benchmark requires a built LLM engine from the same model."
            ),
            "metrics": {},
        }

    # Validate multimodal engine exists
    has_visual = os.path.isdir(os.path.join(multimodal_engine_dir, "visual"))
    has_audio = os.path.isdir(os.path.join(multimodal_engine_dir, "audio"))
    has_code2wav = os.path.isdir(os.path.join(multimodal_engine_dir, "code2wav"))
    if not has_visual and not has_audio and not has_code2wav:
        return {
            "success": False,
            "output": "",
            "error": f"No visual/ or audio/ subdirectory found in {multimodal_engine_dir}.",
            "metrics": {},
        }

    log_dir = multimodal_engine_dir
    if not os.access(log_dir, os.W_OK):
        log_dir = llm_engine_dir
    log_path = os.path.join(log_dir, "bench_multimodal_inference.log")

    try:
        llm_inference = find_executable(build_dir, "llm_inference")

        # Generate input file with test images (for visual) or text (for audio)
        input_file = os.path.join(log_dir, "multimodal_bench_input.json")
        is_audio = is_audio_precision(precision) if precision else False

        if has_visual and not is_audio:
            # VLM: use test images
            images = _find_test_images(build_dir)
            used_images = images[:4] if images else []
            num_inputs = len(used_images)
            input_label = f"{num_inputs} images" if num_inputs else "text-only (no test images found)"
            _generate_vlm_input_json(
                input_file,
                image_paths=used_images or None,
                max_generate_length=max_generate_length,
                batch_size=batch_size,
            )
        else:
            # Audio or fallback: text-only prompts (audio preprocessing is automatic)
            input_prompts = MTBENCH_PROMPTS[:10]
            num_inputs = len(input_prompts)
            input_label = f"{num_inputs} prompts"
            _generate_input_json(
                input_file,
                prompts=input_prompts,
                max_generate_length=max_generate_length,
                batch_size=batch_size,
            )

        output_file = os.path.join(log_dir, "multimodal_infer_output.json")
        profile_file = os.path.join(log_dir, "multimodal_infer_profile.json")

        cmd = [
            llm_inference,
            f"--engineDir={llm_engine_dir}",
            f"--multimodalEngineDir={multimodal_engine_dir}",
            f"--inputFile={input_file}",
            f"--outputFile={output_file}",
            f"--warmup={warmup}",
            "--dumpProfile",
            f"--profileOutputFile={profile_file}",
        ]
        if extra_args:
            cmd.extend(extra_args)

        component = "audio" if is_audio else "visual"
        print(f"\nmultimodal_inference ({component} benchmark via llm_inference):")
        print(f"  LLM Engine: {llm_engine_dir}")
        print(f"  Multimodal Engine: {multimodal_engine_dir}")
        print(f"  Input: {input_label}")
        print(f"  Warmup: {warmup}")

        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1800)
        output = "".join(output_lines)

        if proc.returncode != 0:
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            print(f"  log: {log_path}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_inference exited with code {proc.returncode}",
                "metrics": {},
                "log_path": log_path,
            }

        # Parse metrics
        if os.path.isfile(profile_file):
            metrics = _parse_multimodal_profile(profile_file)
        else:
            metrics = _parse_multimodal_stdout(output)

        # Print summary
        mm_tokens = metrics.get("total_multimodal_tokens",
                                metrics.get("total_image_tokens", 0) + metrics.get("total_audio_tokens", 0))
        mm_avg = metrics.get("avg_time_per_token_ms", "?")
        prefill_tps = metrics.get("prefill_tokens_per_sec", "?")
        gen_tps = metrics.get("generation_tokens_per_sec", "?")
        mem = metrics.get("peak_gpu_memory_mb", "?")

        if metrics.get("total_images", 0) > 0:
            print(f"  Images: {metrics['total_images']}  Image Tokens: {metrics.get('total_image_tokens', '?')}")
        if metrics.get("total_audios", 0) > 0:
            print(f"  Audio Clips: {metrics['total_audios']}  Audio Tokens: {metrics.get('total_audio_tokens', '?')}")
        print(f"  >>> \033[1mMultimodal Avg: {mm_avg} ms/token  |  "
              f"Prefill: {prefill_tps} tok/s  |  Decode: {gen_tps} tok/s\033[0m")
        if mem != "?":
            print(f"  Peak Memory: {mem:.1f} MB")
        print(f"  log: {log_path}")
        print(f"  profile: {profile_file}")

        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "log_path": log_path,
            "profile_path": profile_file,
        }

    except subprocess.TimeoutExpired:
        proc.kill()
        return {
            "success": False,
            "output": "",
            "error": "Multimodal inference timed out (1800s)",
            "metrics": {},
            "log_path": log_path,
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e),
            "metrics": {},
            "log_path": log_path,
        }


def _parse_profile_json(profile_path: str) -> dict:
    """Parse the profile JSON output from llm_inference."""
    with open(profile_path) as f:
        profile = json.load(f)

    metrics = {}

    # Eagle generation metrics
    eagle_gen = profile.get("eagle_generation", {})
    if eagle_gen:
        metrics["total_iterations"] = eagle_gen.get("total_iterations", 0)
        metrics["total_generated_tokens"] = eagle_gen.get("total_generated_tokens", 0)
        metrics["average_tokens_per_run"] = eagle_gen.get("average_tokens_per_run", 0.0)
        metrics["average_acceptance_rate"] = eagle_gen.get("average_acceptance_rate", 0.0)
        metrics["eagle_tokens_per_sec"] = eagle_gen.get(
            "overall_tokens_per_second_excluding_base_prefill", 0.0
        )

    # Prefill metrics
    prefill = profile.get("prefill", {})
    if prefill:
        metrics["prefill_tokens_per_sec"] = prefill.get("tokens_per_second", 0.0)
        metrics["prefill_computed_tokens"] = prefill.get("computed_tokens", 0)
        metrics["prefill_reused_tokens"] = prefill.get("reused_tokens", 0)

    # Standard generation metrics (non-eagle mode)
    gen = profile.get("generation", {})
    if gen:
        metrics["generation_tokens_per_sec"] = gen.get("tokens_per_second", 0.0)
        metrics["generated_tokens"] = gen.get("generated_tokens", 0)

    # Memory
    if "peak_gpu_memory_mb" in profile:
        metrics["peak_gpu_memory_mb"] = profile["peak_gpu_memory_mb"]
    if "peak_unified_memory_mb" in profile:
        metrics["peak_unified_memory_mb"] = profile["peak_unified_memory_mb"]

    # Stage timing (from stages array)
    stages = profile.get("stages", [])
    for stage in stages:
        stage_id = stage.get("stage_id", "")
        avg_ms = stage.get("average_time_per_run_ms", 0.0)
        if "draft_prefill" in stage_id.lower():
            metrics["stage_draft_prefill_ms"] = avg_ms
        elif "construct_draft_tree" in stage_id.lower():
            metrics["stage_construct_tree_ms"] = avg_ms
        elif "base_verification" in stage_id.lower():
            metrics["stage_base_verify_ms"] = avg_ms

    return metrics


def _parse_profile_stdout(output: str) -> dict:
    """Parse performance metrics from llm_inference stdout (fallback)."""
    metrics = {}

    for pattern, key in [
        (r"Total Iterations:\s*(\d+)", "total_iterations"),
        (r"Total Generated Tokens:\s*(\d+)", "total_generated_tokens"),
        (r"Average Acceptance Rate:\s*([\d.]+)", "average_acceptance_rate"),
        (r"Overall Tokens/Second.*?:\s*([\d.]+)", "eagle_tokens_per_sec"),
    ]:
        match = re.search(pattern, output)
        if match:
            val = match.group(1)
            metrics[key] = int(val) if "." not in val else float(val)

    # Prefill tokens/sec
    match = re.search(
        r"=== LLM Prefill ===.*?Tokens/Second:\s*([\d.]+)", output, re.DOTALL
    )
    if match:
        metrics["prefill_tokens_per_sec"] = float(match.group(1))

    # Standard generation tokens/sec
    match = re.search(
        r"=== LLM Generation.*?Tokens/Second:\s*([\d.]+)", output, re.DOTALL
    )
    if match:
        metrics["generation_tokens_per_sec"] = float(match.group(1))

    return metrics


def run_eagle_inference(
    engine_dir: str,
    build_dir: str = None,
    input_file: str = None,
    warmup: int = 3,
    max_generate_length: int = 512,
    batch_size: int = 1,
    extra_args: list = None,
) -> dict:
    """Run end-to-end Eagle inference benchmark using llm_inference.

    Requires both base and draft engines in engine_dir:
      - llm.engine + config.json (base model)
      - eagle_draft.engine + draft_config.json (draft model)

    Returns:
        dict with 'success', 'output', 'error', 'metrics' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    # Validate engine files exist
    missing = [f for f in EAGLE_ENGINE_FILES if not os.path.exists(os.path.join(engine_dir, f))]
    if missing:
        return {
            "success": False,
            "output": "",
            "error": f"Missing engine files in {engine_dir}: {', '.join(missing)}. "
            "Eagle inference requires both base and draft engines in the same directory.",
            "metrics": {},
        }

    # Check engine_dir is writable (we generate input/output/log files there)
    if not os.access(engine_dir, os.W_OK):
        return {
            "success": False,
            "output": "",
            "error": f"Engine directory is not writable: {engine_dir}. "
            "Inference needs to write input, output, profile, and log files there.",
            "metrics": {},
        }

    log_path = os.path.join(engine_dir, "bench_eagle_inference.log")

    try:
        llm_inference = find_executable(build_dir, "llm_inference")

        # Generate input file if not provided
        generated_input = False
        if input_file is None:
            input_file = os.path.join(engine_dir, "mtbench_input.json")
            _generate_input_json(
                input_file,
                max_generate_length=max_generate_length,
                batch_size=batch_size,
            )
            generated_input = True

        output_file = os.path.join(engine_dir, "eagle_infer_output.json")
        profile_file = os.path.join(engine_dir, "eagle_infer_profile.json")

        cmd = [
            llm_inference,
            f"--engineDir={engine_dir}",
            f"--inputFile={input_file}",
            f"--outputFile={output_file}",
            f"--warmup={warmup}",
            "--eagle",
            "--dumpProfile",
            f"--profileOutputFile={profile_file}",
        ]
        if extra_args:
            cmd.extend(extra_args)

        num_prompts = len(MTBENCH_PROMPTS) if generated_input else "?"
        print(f"\neagle_inference (MT-Bench, {num_prompts} prompts):")
        print(f"  Warmup: {warmup}  Max Generate Length: {max_generate_length}")
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1800)
        output = "".join(output_lines)

        if proc.returncode != 0:
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            print(f"  log: {log_path}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_inference exited with code {proc.returncode}",
                "metrics": {},
                "log_path": log_path,
            }

        # Parse metrics — prefer JSON profile, fall back to stdout
        if os.path.isfile(profile_file):
            metrics = _parse_profile_json(profile_file)
        else:
            metrics = _parse_profile_stdout(output)

        # Print clean summary
        acc_rate = metrics.get("average_acceptance_rate", "?")
        eagle_tps = metrics.get("eagle_tokens_per_sec", "?")
        prefill_tps = metrics.get("prefill_tokens_per_sec", "?")
        total_tokens = metrics.get("total_generated_tokens", "?")
        total_iters = metrics.get("total_iterations", "?")
        mem = metrics.get("peak_gpu_memory_mb", metrics.get("peak_unified_memory_mb", "?"))

        print(f"  Total Tokens: {total_tokens}  Iterations: {total_iters}")
        print(f"  Prefill: {prefill_tps} tokens/s")
        if acc_rate != "?":
            print(
                f"  >>> \033[1mAcceptance Rate: {acc_rate:.2f}  |  "
                f"Decode: {eagle_tps:.1f} tokens/s\033[0m"
            )
        else:
            print(f"  >>> \033[1mDecode: {eagle_tps} tokens/s\033[0m")
        if mem != "?":
            print(f"  Peak Memory: {mem:.1f} MB")
        print(f"  log: {log_path}")
        print(f"  profile: {profile_file}")

        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "log_path": log_path,
            "profile_path": profile_file,
        }

    except subprocess.TimeoutExpired:
        proc.kill()
        return {
            "success": False,
            "output": "",
            "error": "Inference timed out (1800s)",
            "metrics": {},
            "log_path": log_path,
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e),
            "metrics": {},
            "log_path": log_path,
        }


def run_standard_inference(
    engine_dir: str,
    build_dir: str = None,
    input_file: str = None,
    warmup: int = 3,
    max_generate_length: int = 512,
    batch_size: int = 1,
    extra_args: list = None,
) -> dict:
    """Run end-to-end standard (non-Eagle) inference benchmark using llm_inference.

    Returns:
        dict with 'success', 'output', 'error', 'metrics' keys.
    """
    if build_dir is None:
        build_dir = get_build_dir()

    # Validate engine files exist
    required_files = ["llm.engine", "config.json"]
    missing = [f for f in required_files if not os.path.exists(os.path.join(engine_dir, f))]
    if missing:
        return {
            "success": False,
            "output": "",
            "error": f"Missing engine files in {engine_dir}: {', '.join(missing)}.",
            "metrics": {},
        }

    # Check engine_dir is writable
    if not os.access(engine_dir, os.W_OK):
        return {
            "success": False,
            "output": "",
            "error": f"Engine directory is not writable: {engine_dir}. "
            "Inference needs to write input, output, profile, and log files there.",
            "metrics": {},
        }

    log_path = os.path.join(engine_dir, "bench_inference.log")

    try:
        llm_inference = find_executable(build_dir, "llm_inference")

        # Generate input file if not provided
        generated_input = False
        if input_file is None:
            input_file = os.path.join(engine_dir, "mtbench_input.json")
            _generate_input_json(
                input_file,
                max_generate_length=max_generate_length,
                batch_size=batch_size,
            )
            generated_input = True

        output_file = os.path.join(engine_dir, "infer_output.json")
        profile_file = os.path.join(engine_dir, "infer_profile.json")

        cmd = [
            llm_inference,
            f"--engineDir={engine_dir}",
            f"--inputFile={input_file}",
            f"--outputFile={output_file}",
            f"--warmup={warmup}",
            "--dumpProfile",
            f"--profileOutputFile={profile_file}",
        ]
        if extra_args:
            cmd.extend(extra_args)

        num_prompts = len(MTBENCH_PROMPTS) if generated_input else "?"
        print(f"\ninference (MT-Bench, {num_prompts} prompts):")
        print(f"  Warmup: {warmup}  Max Generate Length: {max_generate_length}")
        with open(log_path, "w") as log_file:
            log_file.write(f"$ {' '.join(cmd)}\n\n")
            proc = subprocess.Popen(
                cmd,
                env=get_subprocess_env(),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            output_lines = []
            for line in proc.stdout:
                log_file.write(line)
                log_file.flush()
                output_lines.append(line)
            proc.wait(timeout=1800)
        output = "".join(output_lines)

        if proc.returncode != 0:
            print(f"  FAILED (exit code {proc.returncode}). Last lines:")
            for line in output_lines[-20:]:
                sys.stdout.write(f"    {line}")
            print(f"  log: {log_path}")
            return {
                "success": False,
                "output": output,
                "error": f"llm_inference exited with code {proc.returncode}",
                "metrics": {},
                "log_path": log_path,
            }

        if os.path.isfile(profile_file):
            metrics = _parse_profile_json(profile_file)
        else:
            metrics = _parse_profile_stdout(output)

        # Print clean summary
        prefill_tps = metrics.get("prefill_tokens_per_sec", "?")
        gen_tps = metrics.get("generation_tokens_per_sec", "?")
        gen_tokens = metrics.get("generated_tokens", "?")
        mem = metrics.get("peak_gpu_memory_mb", metrics.get("peak_unified_memory_mb", "?"))

        print(f"  Generated Tokens: {gen_tokens}")
        print(f"  >>> \033[1mPrefill: {prefill_tps} tokens/s  |  Decode: {gen_tps} tokens/s\033[0m")
        if mem != "?":
            print(f"  Peak Memory: {mem:.1f} MB")
        print(f"  log: {log_path}")
        print(f"  profile: {profile_file}")

        return {
            "success": True,
            "output": output,
            "error": None,
            "metrics": metrics,
            "log_path": log_path,
            "profile_path": profile_file,
        }

    except subprocess.TimeoutExpired:
        proc.kill()
        return {
            "success": False,
            "output": "",
            "error": "Inference timed out (1800s)",
            "metrics": {},
            "log_path": log_path,
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": str(e),
            "metrics": {},
            "log_path": log_path,
        }
