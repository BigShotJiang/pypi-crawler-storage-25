#!/usr/bin/env python3
from flylight_cli.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
