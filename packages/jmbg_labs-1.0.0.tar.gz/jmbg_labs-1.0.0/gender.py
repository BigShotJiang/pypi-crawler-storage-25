from enum import Enum


class Gender(Enum):
    MALE = "Male"
    FEMALE = "Female"

    def __str__(self) -> str:
        return self.value
