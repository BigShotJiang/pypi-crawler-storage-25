class JmbgError(Exception):
    """
    Exception raised for invalid Serbian unique master citizen number.
    """

    def __init__(
        self,
        message: str = "Invalid Serbian unique master citizen number.",
        *args,
        **kwargs
    ):
        super().__init__(message, *args, **kwargs)
