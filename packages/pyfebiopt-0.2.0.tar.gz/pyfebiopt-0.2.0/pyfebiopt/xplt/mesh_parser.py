"""Mesh parsing helpers for XPLT reader."""

from __future__ import annotations

import struct
from dataclasses import dataclass, field
from os import SEEK_SET

import numpy as np

from pyfebiopt.mesh.mesh import ElementArray, Mesh, NodeArray, SurfaceArray

from .binary_reader import BinaryReader
from .enums import Elem_Type, nodesPerElementClass


def _norm_node_ids(ids: np.ndarray, N: int) -> np.ndarray:
    """Normalize node ids to 0-based contiguous indices.

    Returns:
        np.ndarray: Normalized ids.
    """
    a = np.asarray(ids, dtype=np.int64, order="C")
    if a.size == 0:
        return a
    valid = a >= 0
    if not np.any(valid):
        return a
    vmax = int(a[valid].max())
    if vmax == N:
        a[valid] -= 1
    elif vmax > N:
        raise ValueError(f"node id {vmax} exceeds node count {N}")
    if np.any(a[valid] < 0) or np.any(a[valid] >= N):
        raise ValueError("normalized node ids out of range")
    return a


@dataclass
class MeshParseResult:
    """Container for parsed mesh pieces and lookup maps."""

    mesh: Mesh
    domain_nodes: dict[str, np.ndarray]
    parts_map: dict[str, list[int]] = field(default_factory=dict)
    surfaces_map: dict[str, list[np.ndarray]] = field(default_factory=dict)
    nodesets_map: dict[str, np.ndarray] = field(default_factory=dict)
    part_id2name: dict[int, str] = field(default_factory=dict)
    surf_id2name: dict[int, str] = field(default_factory=dict)
    dom_idx2name: dict[int, str] = field(default_factory=dict)
    surf_idx2name: dict[int, str] = field(default_factory=dict)
    domain_registry: dict[str, DomainInfo] = field(default_factory=dict)


@dataclass(frozen=True)
class DomainInfo:
    """Canonical domain metadata."""

    canonical_key: str
    dom_idx: int
    part_id: int
    elem_type: str
    declared_count: int
    raw_dom_name: str | None = None
    part_name: str | None = None


@dataclass(frozen=True)
class _DomainDraft:
    dom_idx: int
    part_id: int
    elem_type: str
    declared_count: int
    raw_dom_name: str | None


def _decode_name_payload(payload: bytes) -> str:
    r"""Decode FEBio string payloads used in mesh headers.

    FEBio can write string chunks in either of these layouts:

    - ``[int length][raw bytes]`` (``OLeaf<const char*>``)
    - fixed-size ``CHAR64`` buffers padded with ``\\0``

    Returns:
        Decoded text without trailing null bytes.
    """
    if not payload:
        return ""

    if len(payload) >= 4:
        slen = int(struct.unpack("<I", payload[:4])[0])
        rem = payload[4:]
        if 0 <= slen <= len(rem):
            return rem[:slen].decode("utf-8", errors="ignore").split("\x00")[0]

    return payload.decode("utf-8", errors="ignore").split("\x00")[0]


def build_domain_registry(
    drafts: list[_DomainDraft], part_id2name: dict[int, str]
) -> tuple[list[DomainInfo], dict[int, str], dict[str, DomainInfo]]:
    """Build canonical domain names and metadata.

    Policy:

    - Keep explicit, non-empty ``PLT_DOM_NAME`` when available and unique.
    - Fall back to canonical ``<type>_d<dom_idx>`` when name is missing/empty
      or collides.

    Returns:
        Tuple of (ordered entries, dom_idx -> key map, key -> entry map).
    """
    entries: list[DomainInfo] = []
    dom_idx2name: dict[int, str] = {}
    by_key: dict[str, DomainInfo] = {}
    used_keys: set[str] = set()

    def _fallback_key(d: _DomainDraft) -> str:
        et = d.elem_type.lower()
        if et.startswith("elem_"):
            et = et[5:]
        return f"{et}_d{d.dom_idx}"

    for d in drafts:
        preferred = (d.raw_dom_name or "").strip()
        key = preferred if preferred and preferred not in used_keys else _fallback_key(d)
        part_name = part_id2name.get(d.part_id, None)
        info = DomainInfo(
            canonical_key=key,
            dom_idx=d.dom_idx,
            part_id=d.part_id,
            elem_type=d.elem_type,
            declared_count=d.declared_count,
            raw_dom_name=d.raw_dom_name,
            part_name=part_name if part_name else None,
        )
        entries.append(info)
        dom_idx2name[d.dom_idx] = key
        by_key[key] = info
        used_keys.add(key)
    return entries, dom_idx2name, by_key


def parse_mesh(reader: BinaryReader) -> MeshParseResult:
    """Parse mesh blocks and build Mesh plus lookup maps.

    Returns:
        MeshParseResult: Parsed mesh and helper maps.
    """
    mesh_size = reader.search_block("PLT_MESH")
    mesh_start = reader.tell()
    mesh_end = mesh_start + mesh_size if mesh_size > 0 else reader.filesize

    nodes_xyz: np.ndarray | None = None
    conn_list: list[np.ndarray] = []
    etype_list: list[str] = []
    parts_map: dict[str, list[int]] = {}
    surfaces_map: dict[str, list[np.ndarray]] = {}
    nodesets_map: dict[str, np.ndarray] = {}
    part_id2name: dict[int, str] = {}
    surf_id2name: dict[int, str] = {}
    dom_idx2name: dict[int, str] = {}
    surf_idx2name: dict[int, str] = {}
    domain_drafts: list[_DomainDraft] = []
    domain_elem_rows: dict[int, list[int]] = {}

    # nodes
    reader.search_block("PLT_NODE_SECTION")
    reader.search_block("PLT_NODE_HEADER")
    reader.search_block("PLT_NODE_SIZE")
    nodeSize = int(struct.unpack("I", reader.read(4))[0])
    reader.search_block("PLT_NODE_DIM")
    nodeDim = int(struct.unpack("I", reader.read(4))[0])
    reader.search_block("PLT_NODE_COORDS")
    xyz = np.zeros((nodeSize, max(3, nodeDim)), dtype=float)
    for i in range(nodeSize):
        _ = struct.unpack("I", reader.read(4))[0]
        for j in range(nodeDim):
            xyz[i, j] = struct.unpack("f", reader.read(4))[0]
    nodes_xyz = xyz

    # domains
    reader.search_block("PLT_DOMAIN_SECTION")
    dom_ord = 0
    while reader.check_block("PLT_DOMAIN"):
        _ = reader.seek_block("PLT_DOMAIN")
        _ = reader.seek_block("PLT_DOMAIN_HDR")
        _ = reader.seek_block("PLT_DOM_ELEM_TYPE")
        et_num = int(struct.unpack("I", reader.read(4))[0])
        etype = Elem_Type(et_num).name
        nne = nodesPerElementClass[etype]

        _ = reader.seek_block("PLT_DOM_PART_ID")
        part_id_1b = int(struct.unpack("I", reader.read(4))[0])
        part_id = part_id_1b - 1

        _ = reader.seek_block("PLT_DOM_ELEMS")
        declared_count = int(struct.unpack("I", reader.read(4))[0])

        raw_dom_name: str | None = None
        if reader.check_block("PLT_DOM_NAME"):
            nlen = reader.seek_block("PLT_DOM_NAME")
            raw_dom_name = _decode_name_payload(reader.read(nlen))
            part_id2name[part_id] = raw_dom_name

        domain_drafts.append(
            _DomainDraft(
                dom_idx=dom_ord,
                part_id=part_id,
                elem_type=etype,
                declared_count=declared_count,
                raw_dom_name=raw_dom_name,
            )
        )

        _ = reader.seek_block("PLT_DOM_ELEM_LIST")
        rows: list[int] = []
        while reader.check_block("PLT_ELEMENT"):
            sec_sz = reader.seek_block("PLT_ELEMENT")
            payload = reader.read(sec_sz)
            vals = np.frombuffer(payload, dtype=np.int32)
            if vals.size < (nne + 1):
                raise ValueError(
                    f"PLT_ELEMENT too short for {etype} (need {nne + 1}, got {vals.size})"
                )
            nodes_raw = vals[-nne:]
            N = nodes_xyz.shape[0] if nodes_xyz is not None else 0
            nodes0 = _norm_node_ids(nodes_raw, N)
            conn_list.append(nodes0)
            etype_list.append(etype)
            rows.append(len(etype_list) - 1)
        domain_elem_rows[dom_ord] = rows
        dom_ord += 1

    # surfaces
    if reader.search_block("PLT_SURFACE_SECTION") > 0:
        surf_ord = 0
        while reader.check_block("PLT_SURFACE"):
            reader.search_block("PLT_SURFACE")
            reader.search_block("PLT_SURFACE_HDR")
            reader.search_block("PLT_SURFACE_ID")
            sid_1b = int(struct.unpack("I", reader.read(4))[0]) - 1
            reader.search_block("PLT_SURFACE_FACES")
            _ = int(struct.unpack("I", reader.read(4))[0])
            nlen = reader.seek_block("PLT_SURFACE_NAME")
            sname = reader.read(nlen).decode("utf-8", errors="ignore").split("\x00")[-1]
            surf_id2name[sid_1b] = sname
            surf_idx2name[surf_ord] = sname
            surf_ord += 1

            reader.search_block("PLT_SURFACE_MAX_FACET_NODES")
            maxn = int(struct.unpack("I", reader.read(4))[0])

            if reader.check_block("PLT_FACE_LIST"):
                reader.search_block("PLT_FACE_LIST")
                lst: list[np.ndarray] = []
                while reader.check_block("PLT_FACE"):
                    sec_size = reader.search_block("PLT_FACE")
                    cur = reader.tell()
                    _ = int(struct.unpack("I", reader.read(4))[0])
                    reader.skip(4)
                    face = np.zeros(maxn, dtype=np.int64)
                    for j in range(maxn):
                        face[j] = int(struct.unpack("I", reader.read(4))[0])
                    N = nodes_xyz.shape[0] if nodes_xyz is not None else 0
                    lst.append(_norm_node_ids(face, N))
                    reader.seek(cur + sec_size, SEEK_SET)
                surfaces_map[sname] = lst

    # nodesets
    if reader.search_block("PLT_NODESET_SECTION") > 0:
        while reader.check_block("PLT_NODESET"):
            reader.search_block("PLT_NODESET")
            reader.search_block("PLT_NODESET_HDR")
            reader.search_block("PLT_NODESET_ID")
            _ = int(struct.unpack("I", reader.read(4))[0])
            reader.search_block("PLT_NODESET_SIZE")
            nsize = int(struct.unpack("I", reader.read(4))[0])
            nlen = reader.search_block("PLT_NODESET_NAME")
            nname = reader.read(nlen).decode("utf-8", errors="ignore").split("\x00")[-1]
            ids: list[int] = []
            if reader.check_block("PLT_NODESET_LIST"):
                reader.search_block("PLT_NODESET_LIST")
                for _ in range(nsize):
                    ids.append(int(struct.unpack("I", reader.read(4))[0]))
            N = nodes_xyz.shape[0] if nodes_xyz is not None else 0
            nodesets_map[nname] = _norm_node_ids(np.asarray(ids, dtype=np.int64), N)

    # optional part renames
    if reader.search_block("PLT_PARTS_SECTION") > 0:
        while reader.check_block("PLT_PART"):
            reader.search_block("PLT_PART")
            reader.search_block("PLT_PART_ID")
            pid = int(struct.unpack("I", reader.read(4))[0]) - 1
            nlen = reader.search_block("PLT_PART_NAME")
            pname = _decode_name_payload(reader.read(nlen))
            part_id2name[pid] = pname

    domain_entries, dom_idx2name, domain_registry = build_domain_registry(
        domain_drafts, part_id2name
    )
    for entry in domain_entries:
        parts_map[entry.canonical_key] = list(domain_elem_rows.get(entry.dom_idx, []))

    # build Mesh
    nodes = NodeArray(nodes_xyz if nodes_xyz is not None else np.zeros((0, 3), float))
    kmax = max((len(c) for c in conn_list), default=0)
    E = len(conn_list)
    conn = -np.ones((E, kmax), dtype=np.int64)
    nper = np.zeros((E,), dtype=np.int64)
    for i, c in enumerate(conn_list):
        conn[i, : c.size] = c
        nper[i] = c.size
    elements = ElementArray(conn=conn, nper=nper, etype=np.asarray(etype_list, dtype=object))
    parts = {name: np.asarray(idx, dtype=np.int64) for name, idx in parts_map.items()}
    surfaces: dict[str, SurfaceArray] = {}
    for sname, lst in surfaces_map.items():
        if not lst:
            continue
        kk = max(len(a) for a in lst)
        F = len(lst)
        faces = -np.ones((F, kk), dtype=np.int64)
        nps = np.zeros((F,), dtype=np.int64)
        for i, a in enumerate(lst):
            faces[i, : a.size] = a
            nps[i] = a.size
        surfaces[sname] = SurfaceArray(faces=faces, nper=nps)
    nodesets = {name: ids for name, ids in nodesets_map.items()}
    mesh = Mesh(
        nodes=nodes, elements=elements, parts=parts, surfaces=surfaces, nodesets=nodesets
    )

    # domain nodes (unique per part)
    domain_nodes: dict[str, np.ndarray] = {}
    conn = mesh.elements.conn
    nper_e = mesh.elements.nper
    for dname, eids in mesh.parts.items():
        ids_flat: list[int] = []
        for e in np.asarray(eids, dtype=np.int64):
            k = int(nper_e[e])
            if k > 0:
                ids_flat.extend(conn[e, :k].tolist())
        seen: set[int] = set()
        order: list[int] = []
        for i in ids_flat:
            if i not in seen:
                seen.add(i)
                order.append(i)
        domain_nodes[dname] = np.asarray(order, dtype=np.int64)

    result = MeshParseResult(
        mesh=mesh,
        domain_nodes=domain_nodes,
        parts_map=parts_map,
        surfaces_map=surfaces_map,
        nodesets_map=nodesets_map,
        part_id2name=part_id2name,
        surf_id2name=surf_id2name,
        dom_idx2name=dom_idx2name,
        surf_idx2name=surf_idx2name,
        domain_registry=domain_registry,
    )

    # advance to end of mesh block to align for subsequent sections
    reader.seek(mesh_end)
    return result


__all__ = ["DomainInfo", "MeshParseResult", "build_domain_registry", "parse_mesh"]
