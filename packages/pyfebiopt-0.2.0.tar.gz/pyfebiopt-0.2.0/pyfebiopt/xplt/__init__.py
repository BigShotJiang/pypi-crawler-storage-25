"""Public entry to the xplt reader."""

from .xplt import xplt

__all__ = ["xplt"]
