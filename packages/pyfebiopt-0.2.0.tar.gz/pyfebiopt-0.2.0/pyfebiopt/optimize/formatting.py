"""Formatting helpers for optimization reporters."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np
from numpy.typing import NDArray

Array = NDArray[np.float64]


def is_finite_number(value: Any) -> bool:
    """Return True when ``value`` can be represented as a finite float."""
    try:
        return bool(np.isfinite(float(value)))
    except (TypeError, ValueError):
        return False


def format_scientific(value: Any) -> str:
    """Format numeric values for compact optimization logs.

    Returns:
        Scientific-notation text, or ``"nan"`` for non-finite values.
    """
    return f"{float(value):.6e}" if is_finite_number(value) else "nan"


def format_fixed(value: Any) -> str:
    """Format numeric values with six decimal places.

    Returns:
        Fixed-decimal text, or ``"nan"`` for non-finite values.
    """
    return f"{float(value):.6f}" if is_finite_number(value) else "nan"


def format_params_table(
    names: Sequence[str],
    values: Array,
    *,
    optimizer_vec: Array | None = None,
) -> list[str]:
    """Build a parameter table for console output.

    Returns:
        Lines ready to join into a console message.
    """
    names_list = [str(name) for name in names]
    value_vec = np.asarray(values, dtype=float).reshape(-1)
    optimizer_values = (
        np.asarray(optimizer_vec, dtype=float).reshape(-1) if optimizer_vec is not None else None
    )
    name_width = max([len("name"), *(len(name) for name in names_list)])
    lines = ["", "parameters:"]
    if optimizer_values is None:
        lines.append(f"  {'name':<{name_width}}  {'value':>12}")
        for name, value in zip(names_list, value_vec, strict=True):
            lines.append(f"  {name:<{name_width}}  {format_scientific(value):>12}")
    else:
        lines.append(f"  {'name':<{name_width}}  {'value':>12}  {'optimizer':>12}")
        for name, value, optimizer_value in zip(
            names_list, value_vec, optimizer_values, strict=True
        ):
            lines.append(
                f"  {name:<{name_width}}  {format_scientific(value):>12}  "
                f"{format_scientific(optimizer_value):>12}"
            )
    return lines


def format_r2_table(r_squared: Any) -> list[str]:
    """Build an R-squared summary table.

    Returns:
        Lines ready to join into a console message.
    """
    lines = ["", "coeff. of determination:"]
    if not isinstance(r_squared, Mapping) or not r_squared:
        lines.append("  (no data)")
        return lines
    items = sorted(((str(key), value) for key, value in r_squared.items()), key=lambda x: x[0])
    keys = [key for key, _value in items]
    key_width = max([len("series"), *(len(key) for key in keys)])
    lines.append(f"  {'series':<{key_width}}  {'value':>8}")
    for key, value in items:
        lines.append(f"  {key:<{key_width}}  {format_fixed(value):>8}")
    return lines


def normalise_experiments(experiments: Any) -> list[dict[str, Any]]:
    """Normalize case experiment descriptors for display.

    Returns:
        List of mapping-shaped experiment descriptors.
    """
    if not isinstance(experiments, Sequence) or isinstance(experiments, (str, bytes)):
        return []
    normalised: list[dict[str, Any]] = []
    for item in experiments:
        if isinstance(item, Mapping):
            normalised.append(dict(item))
        else:
            normalised.append({"name": str(item), "adapter": None, "grid": None})
    return normalised


def format_grid(grid: Any) -> str:
    """Format a grid policy descriptor.

    Returns:
        Human-readable grid policy text.
    """
    if isinstance(grid, Mapping):
        policy = str(grid.get("policy", "(unknown)"))
        if policy == "fixed_user" and grid.get("size") is not None:
            label = f"{policy} n={grid['size']}"
            if grid.get("min") is not None and grid.get("max") is not None:
                label += (
                    f" range=[{format_scientific(grid.get('min'))}, "
                    f"{format_scientific(grid.get('max'))}]"
                )
            return label
        return policy
    return str(grid or "(unknown)")


__all__ = [
    "format_fixed",
    "format_grid",
    "format_params_table",
    "format_r2_table",
    "format_scientific",
    "is_finite_number",
    "normalise_experiments",
]
