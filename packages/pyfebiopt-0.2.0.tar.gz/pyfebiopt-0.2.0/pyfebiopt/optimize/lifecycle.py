"""Small lifecycle helpers for optimization runs."""

from __future__ import annotations

import signal
from pathlib import Path
from typing import Any, Protocol

from .storage import StorageWorkspace


class LoggerProtocol(Protocol):
    """Minimal logger surface used by lifecycle helpers."""

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None: ...
    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None: ...


class InterruptController:
    """Own SIGINT handling and user confirmation for an optimization run."""

    def __init__(self, logger: LoggerProtocol) -> None:
        """Create an interrupt controller."""
        self.logger = logger
        self._requested = False
        self._previous_handler: Any | None = None

    def __enter__(self) -> InterruptController:
        """Install the temporary SIGINT handler.

        Returns:
            This controller for context-managed checks.
        """
        self.install()
        return self

    def __exit__(self, *_exc_info: object) -> None:
        """Restore the previous SIGINT handler."""
        self.restore()

    def install(self) -> None:
        """Install a handler that defers interruption to evaluation boundaries."""
        try:
            self._previous_handler = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, self._handle_sigint)
        except Exception:
            self._previous_handler = None

    def restore(self) -> None:
        """Restore the signal handler active before installation."""
        try:
            if self._previous_handler is not None:
                signal.signal(signal.SIGINT, self._previous_handler)
        except Exception:
            pass
        self._previous_handler = None
        self._requested = False

    def check(self) -> None:
        """Raise ``KeyboardInterrupt`` when the user confirms a pending interrupt."""
        if not self._requested:
            return
        self._requested = False
        if self._confirm_interrupt():
            raise KeyboardInterrupt
        self.logger.info("Interrupt ignored; continuing optimization.")

    def _handle_sigint(self, signum: int, frame: Any) -> None:
        del signum, frame
        self._requested = True

    def _confirm_interrupt(self) -> bool:
        prompt = "Interrupt received. Abort optimization? [y/N]: "
        try:
            reply = input(prompt)
        except EOFError:
            return True
        return reply.strip().lower() in {"y", "yes"}


class FinalArtifactExporter:
    """Write final series and simulation files after a successful run."""

    def __init__(self, workspace: StorageWorkspace, logger: LoggerProtocol) -> None:
        """Create an exporter bound to a workspace."""
        self.workspace = workspace
        self.logger = logger

    def export(
        self,
        *,
        final_iter_dir: Path,
        series: dict[str, dict[str, Any]],
    ) -> None:
        """Export final user-facing artifacts, logging transport errors."""
        try:
            self.workspace.write_series(series)
        except Exception:
            self.logger.exception("Failed to write series outputs.")
        try:
            self.workspace.export_final_base_files(final_iter_dir)
        except Exception:
            self.logger.exception("Failed to export final simulation outputs.")


__all__ = ["FinalArtifactExporter", "InterruptController"]
