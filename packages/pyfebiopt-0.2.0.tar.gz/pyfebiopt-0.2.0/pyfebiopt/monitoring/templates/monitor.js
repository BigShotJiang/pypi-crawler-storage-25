        const rows = document.getElementById('runRows');
        const detail = document.getElementById('detail');
        const detailJson = document.getElementById('detailJson');
        const detailTitle = document.getElementById('detailTitle');
        const detailSummary = document.getElementById('detailSummary');
        const costChartEl = document.getElementById('costChart');
        const closeDetailBtn = document.getElementById('closeDetail');
        const toggleJsonBtn = document.getElementById('toggleJson');
        const seriesSelect = document.getElementById('seriesSelect');
        const detailLiveBtn = document.getElementById('detailLiveToggle');
        const seriesChartEl = document.getElementById('seriesChart');
        const systemChartEl = document.getElementById('systemChart');
        const diskPiesEl = document.getElementById('diskPies');
        const systemSummaryEl = document.getElementById('systemSummary');
        const diskSummaryEl = document.getElementById('diskSummary');
        const processTableEl = document.getElementById('processTable');
        const processSummaryEl = document.getElementById('processSummary');
        const runsPanel = document.getElementById('runsPanel');
        const toggleSelectionBtn = document.getElementById('toggleSelection');
        const selectionToolbar = document.getElementById('selectionToolbar');
        const selectionCountEl = document.getElementById('selectionCount');
        const bulkDeleteBtn = document.getElementById('bulkDeleteSelected');
        const cancelSelectionBtn = document.getElementById('cancelSelection');
        const maxRunsSelect = document.getElementById('maxRuns');
        const pagePrevBtn = document.getElementById('pagePrev');
        const pageNextBtn = document.getElementById('pageNext');
        const pageIndicator = document.getElementById('pageIndicator');
        let systemPanel = document.getElementById('systemPanel');
        let systemContent = document.getElementById('systemContent');
        let toggleSystemPanelBtn = document.getElementById('toggleSystemPanel');
        let jsonExpanded = false;
        let selectedRunId = null;
        let lastTableHtml = '';
        let currentSeriesData = {};
        let iterationSeriesByIndex = {};
        let latestSeriesIndex = null;
        let lockedIterationIndex = null;
        let currentDetailData = null;
        let selectedRunFingerprint = null;
        let latestSystemSnapshot = null;
        let processTimer = null;
        const selectedRuns = new Set();
        let selectionMode = false;
        let systemPanelCollapsed = false;
        const systemHistory = [];
        const maxSystemPoints = 90;
        const themeStorageKey = 'pyfebiopt-monitor-theme';
        const plotlyConfig = { displayModeBar: false, responsive: true };
        let maxRunsToShow = 50;
        let currentPage = 1;
        let totalPages = 1;
        let totalRuns = 0;
        let costChartTipShown = false;
        let lastCostChartSignature = null;
        let lastSeriesChartSignature = null;
        const themeToggleBtn = document.getElementById('themeToggle');
        function escapeHtml(value) {
          return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
        }
        function formatParameterValue(value) {
          if (typeof value === 'number' && Number.isFinite(value)) {
            return value.toExponential(4);
          }
          const numeric = Number(value);
          if (Number.isFinite(numeric)) {
            return numeric.toExponential(4);
          }
          if (value === undefined || value === null) {
            return '-';
          }
          return escapeHtml(String(value));
        }
            function formatBytes(value) {
              if (typeof value !== 'number' || !Number.isFinite(value)) {
                return '-';
              }
              const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
          let idx = 0;
          let num = value;
          while (num >= 1024 && idx < units.length - 1) {
            num /= 1024;
            idx += 1;
              }
              const precision = num >= 100 || idx === 0 ? 0 : 1;
              return `${num.toFixed(precision)} ${units[idx]}`;
            }
        function formatRunTimestamp(epochSeconds) {
              if (typeof epochSeconds !== 'number' || !Number.isFinite(epochSeconds)) {
                return '-';
              }
              const date = new Date(epochSeconds * 1000);
              if (Number.isNaN(date.getTime())) {
                return '-';
              }
              const hh = String(date.getHours()).padStart(2, '0');
              const mm = String(date.getMinutes()).padStart(2, '0');
              const ss = String(date.getSeconds()).padStart(2, '0');
              const day = String(date.getDate()).padStart(2, '0');
              const month = String(date.getMonth() + 1).padStart(2, '0');
              const year = date.getFullYear();
              return `${hh}:${mm}:${ss} ${day}/${month}/${year}`;
            }
        function runFingerprint(run) {
          if (!run) {
            return null;
          }
          return [
            run.run_id || '',
            run.status || '',
            typeof run.updated_at === 'number' ? run.updated_at : '',
            typeof run.iteration_count === 'number' ? run.iteration_count : '',
            typeof run.last_cost === 'number' ? run.last_cost : '',
          ].join('|');
        }
        function isActiveStatus(status) {
          return status === 'created' || status === 'running';
        }
            function latestThetaSnapshot(data) {
              const iterations = Array.isArray(data?.iterations) ? data.iterations : [];
              for (let i = iterations.length - 1; i >= 0; i -= 1) {
                const entry = iterations[i];
            if (entry && entry.theta && typeof entry.theta === 'object' && Object.keys(entry.theta).length) {
              return entry.theta;
            }
          }
          return null;
        }
        function extractLatestSeries(data) {
          const iterations = Array.isArray(data?.iterations) ? data.iterations : [];
          for (let idx = iterations.length - 1; idx >= 0; idx -= 1) {
            const entry = iterations[idx];
            if (entry && entry.series && typeof entry.series === 'object' && Object.keys(entry.series).length) {
              return entry.series;
            }
          }
          return {};
        }
        function collectIterationSeries(data) {
          const iterations = Array.isArray(data?.iterations) ? data.iterations : [];
          const map = Object.create(null);
          let latestIndex = null;
          iterations.forEach((entry, idx) => {
            if (entry && entry.series && typeof entry.series === 'object' && Object.keys(entry.series).length) {
              map[idx] = entry.series;
              latestIndex = idx;
            }
          });
          return { map, latestIndex: typeof latestIndex === 'number' ? latestIndex : null };
        }
        function getCssColor(name, fallback) {
          const value = getComputedStyle(document.body).getPropertyValue(name);
          return value && value.trim().length ? value.trim() : fallback;
        }
        function chartColors() {
          return {
            bg: getCssColor('--chart-bg', '#10172a'),
            card: getCssColor('--card-bg', '#232c42'),
            text: getCssColor('--chart-axis', '#f5f5f5'),
            grid: getCssColor('--chart-grid', 'rgba(255,255,255,0.08)'),
            zero: getCssColor('--chart-zero', 'rgba(255,255,255,0.18)'),
            muted: getCssColor('--muted-text', 'rgba(255,255,255,0.5)'),
            cpu: getCssColor('--cpu-line', '#8b5cf6'),
            memory: getCssColor('--mem-line', '#34d399'),
            diskUsed: getCssColor('--disk-used', '#fb7185'),
            diskFree: getCssColor('--disk-free', '#2dd4bf'),
          };
        }
        function updateThemeButton() {
          if (!themeToggleBtn) {
            return;
          }
          const isLight = document.body.classList.contains('light');
          themeToggleBtn.textContent = isLight ? 'Dark mode' : 'Light mode';
        }
        function refreshThemeDependentViews() {
          if (currentDetailData) {
            renderDetailPanels(currentDetailData, { refreshJson: false });
          } else {
            renderEmptyPlot(costChartEl, 'Select a run');
            renderEmptyPlot(seriesChartEl, 'Select a run');
          }
          renderSystemUsage();
          renderDiskPies();
        }
        function applyTheme(theme, { skipStorage = false } = {}) {
          const isLight = theme === 'light';
          document.body.classList.toggle('light', isLight);
          if (!skipStorage) {
            try {
              localStorage.setItem(themeStorageKey, isLight ? 'light' : 'dark');
            } catch (err) {
              // ignore storage errors
            }
          }
          updateThemeButton();
          refreshThemeDependentViews();
        }
        (function initTheme() {
          let saved = null;
          try {
            saved = localStorage.getItem(themeStorageKey);
          } catch (err) {
            saved = null;
          }
          applyTheme(saved === 'light' ? 'light' : 'dark', { skipStorage: true });
          if (themeToggleBtn) {
            themeToggleBtn.addEventListener('click', () => {
              const nextTheme = document.body.classList.contains('light') ? 'dark' : 'light';
              applyTheme(nextTheme);
            });
          }
        })();
        function hasPlotly() {
          return typeof Plotly !== 'undefined' && Plotly.react;
        }
        function renderEmptyPlot(container, message, height = 420) {
          if (!container) {
            return;
          }
          if (container === costChartEl) {
            lastCostChartSignature = `empty:${message}:${height}:${document.body.classList.contains('light') ? 'light' : 'dark'}`;
          }
          if (container === seriesChartEl) {
            lastSeriesChartSignature = `empty:${message}:${height}:${document.body.classList.contains('light') ? 'light' : 'dark'}`;
          }
          const colors = chartColors();
          if (!hasPlotly()) {
            container.innerHTML = `<div style="display:flex; align-items:center; justify-content:center; height:100%; color:${colors.muted}; font-size:16px;">${message}</div>`;
            return;
          }
          Plotly.react(
            container,
            [],
            {
              paper_bgcolor: colors.bg,
              plot_bgcolor: colors.bg,
              autosize: true,
              height,
              margin: { l: 0, r: 0, t: 0, b: 0 },
              xaxis: { visible: false },
              yaxis: { visible: false },
              annotations: [
                {
                  text: message,
                  x: 0.5,
                  y: 0.5,
                  xref: 'paper',
                  yref: 'paper',
                  showarrow: false,
                  font: { color: colors.muted, size: 16 },
                },
              ],
            },
            plotlyConfig,
          );
          if (typeof Plotly !== 'undefined' && Plotly.Plots && typeof Plotly.Plots.resize === 'function') {
            Plotly.Plots.resize(container);
          }
        }
        function refreshSelectionStyles() {
          if (!rows) {
            return;
          }
          const rowNodes = rows.querySelectorAll('tr[data-run]');
          rowNodes.forEach((row) => {
            const runId = row.dataset.run;
            const isSelected = runId && selectedRuns.has(runId);
            row.classList.toggle('selected', Boolean(isSelected && selectionMode));
            const toggleBtn = row.querySelector('.row-select');
            if (toggleBtn) {
              const pressed = Boolean(isSelected && selectionMode);
              toggleBtn.classList.toggle('selected', pressed);
              toggleBtn.setAttribute('aria-pressed', pressed ? 'true' : 'false');
            }
          });
        }
        function updateSelectionToolbar() {
          if (runsPanel) {
            runsPanel.classList.toggle('selecting', selectionMode);
          }
          if (selectionToolbar) {
            selectionToolbar.hidden = !selectionMode;
          }
          if (selectionCountEl) {
            selectionCountEl.textContent = `${selectedRuns.size} selected`;
          }
          if (bulkDeleteBtn) {
            bulkDeleteBtn.disabled = !selectionMode || !selectedRuns.size;
          }
          if (toggleSelectionBtn) {
            toggleSelectionBtn.textContent = selectionMode ? 'Done selecting' : 'Select runs';
          }
        }
        function enterSelectionMode() {
          if (selectionMode) {
            return;
          }
          selectionMode = true;
          selectedRuns.clear();
          updateSelectionToolbar();
          refreshSelectionStyles();
        }
        function exitSelectionMode() {
          if (!selectionMode) {
            return;
          }
          selectionMode = false;
          selectedRuns.clear();
          updateSelectionToolbar();
          refreshSelectionStyles();
        }
        function toggleRunSelection(runId) {
          if (!selectionMode || !runId) {
            return;
          }
          if (selectedRuns.has(runId)) {
            selectedRuns.delete(runId);
          } else {
            selectedRuns.add(runId);
          }
          refreshSelectionStyles();
          updateSelectionToolbar();
        }
        function ensureSystemPanelElements() {
          if (!systemPanel) {
            systemPanel = document.getElementById('systemPanel');
          }
          if (!systemContent) {
            systemContent = document.getElementById('systemContent');
          }
          if (!toggleSystemPanelBtn) {
            toggleSystemPanelBtn = document.getElementById('toggleSystemPanel');
          }
        }
        function setSystemPanelCollapsed(collapsed, { skipRender = false } = {}) {
          ensureSystemPanelElements();
          systemPanelCollapsed = Boolean(collapsed);
          if (systemContent) {
            systemContent.hidden = systemPanelCollapsed;
            systemContent.setAttribute('aria-hidden', systemPanelCollapsed ? 'true' : 'false');
          }
          if (systemPanel) {
            systemPanel.classList.toggle('collapsed', systemPanelCollapsed);
          }
          if (toggleSystemPanelBtn) {
            toggleSystemPanelBtn.textContent = systemPanelCollapsed ? 'Expand' : 'Collapse';
            toggleSystemPanelBtn.setAttribute('aria-expanded', systemPanelCollapsed ? 'false' : 'true');
          }
          if (!systemPanelCollapsed && !skipRender) {
            if (hasPlotly() && systemChartEl && Plotly.Plots && typeof Plotly.Plots.resize === 'function') {
              try {
                Plotly.Plots.resize(systemChartEl);
              } catch (err) {
                // ignore resize errors
              }
            }
            renderSystemUsage();
            renderDiskPies();
          }
        }
        function handleSystemPanelToggle(event) {
          if (event) {
            if (typeof event.preventDefault === 'function') {
              event.preventDefault();
            }
            if (typeof event.stopPropagation === 'function') {
              event.stopPropagation();
            }
          }
          setSystemPanelCollapsed(!systemPanelCollapsed);
        }
        function pushSystemHistory(snapshot) {
          if (!snapshot || typeof snapshot.timestamp !== 'number') {
            return;
          }
          systemHistory.push({
            time: new Date(snapshot.timestamp * 1000),
            cpu: typeof snapshot.cpu_percent === 'number' ? snapshot.cpu_percent : null,
            memory:
              snapshot && snapshot.memory && typeof snapshot.memory.percent === 'number'
                ? snapshot.memory.percent
                : null,
          });
          while (systemHistory.length > maxSystemPoints) {
            systemHistory.shift();
          }
        }
        function updateSystemSummary(snapshot) {
          if (!systemSummaryEl) {
            return;
          }
          const cpuText = snapshot && typeof snapshot.cpu_percent === 'number'
            ? `${snapshot.cpu_percent.toFixed(1)}% CPU`
            : 'CPU N/A';
          const memPercent = snapshot && snapshot.memory && typeof snapshot.memory.percent === 'number'
            ? `${snapshot.memory.percent.toFixed(1)}% RAM`
            : 'RAM N/A';
          systemSummaryEl.textContent = `${cpuText} • ${memPercent}`;
        }
        function renderSystemUsage() {
          if (!systemChartEl || systemPanelCollapsed) {
            return;
          }
          if (!systemHistory.length) {
            renderEmptyPlot(systemChartEl, 'Collecting metrics...', 300);
            return;
          }
          if (!hasPlotly()) {
            renderEmptyPlot(systemChartEl, 'Plotly.js not available', 300);
            return;
          }
          const scrollElement = document.scrollingElement || document.documentElement || document.body;
          let prevScrollTop = 0;
          if (scrollElement) {
            prevScrollTop = scrollElement.scrollTop;
          } else if (typeof window !== 'undefined') {
            prevScrollTop = window.scrollY || window.pageYOffset || 0;
          }
          const colors = chartColors();
          const times = systemHistory.map((entry) => entry.time);
          const cpuValues = systemHistory.map((entry) => (typeof entry.cpu === 'number' ? entry.cpu : null));
          const memValues = systemHistory.map((entry) =>
            typeof entry.memory === 'number' ? entry.memory : null,
          );
          const cpuTrace = {
            x: times,
            y: cpuValues,
            name: 'CPU %',
            mode: 'lines',
            line: { color: colors.cpu, width: 3 },
            hovertemplate: 'CPU %{y:.1f}%<extra></extra>',
          };
          const memTrace = {
            x: times,
            y: memValues,
            name: 'RAM %',
            mode: 'lines',
            line: { color: colors.memory, width: 3 },
            hovertemplate: 'RAM %{y:.1f}%<extra></extra>',
          };
          const layout = {
            paper_bgcolor: colors.bg,
            plot_bgcolor: colors.bg,
            autosize: true,
            height: 300,
            margin: { l: 40, r: 8, t: 10, b: 40 },
            xaxis: {
              title: 'Time',
              color: colors.text,
              gridcolor: colors.grid,
              showgrid: false,
            },
            yaxis: {
              title: 'Percent',
              color: colors.text,
              gridcolor: colors.grid,
              zerolinecolor: colors.zero,
              range: [0, 100],
            },
            legend: { orientation: 'h', yanchor: 'bottom', y: 1.02, x: 0, font: { color: colors.text } },
          };
          Plotly.react(systemChartEl, [cpuTrace, memTrace], layout, plotlyConfig);
          if (typeof Plotly !== 'undefined' && Plotly.Plots && typeof Plotly.Plots.resize === 'function') {
            Plotly.Plots.resize(systemChartEl);
          }
          if (scrollElement) {
            scrollElement.scrollTop = prevScrollTop;
          } else if (typeof window !== 'undefined' && typeof window.scrollTo === 'function') {
            window.scrollTo(0, prevScrollTop);
          }
        }
        function renderDiskPies() {
          if (!diskPiesEl) {
            return;
          }
          const disks = latestSystemSnapshot && Array.isArray(latestSystemSnapshot.disks)
            ? latestSystemSnapshot.disks
            : [];
          if (!disks.length) {
            diskPiesEl.innerHTML = '<p style="margin:0; color:var(--muted-text);">No disk data.</p>';
            if (diskSummaryEl) {
              diskSummaryEl.textContent = 'No disks';
            }
            return;
          }
          let totalBytes = 0;
          let freeBytes = 0;
          const diskData = disks.map((disk, idx) => {
            const used = typeof disk.used === 'number' ? disk.used : 0;
            const available = typeof disk.free === 'number' ? disk.free : 0;
            const diskTotal = typeof disk.total === 'number' ? disk.total : used + available;
            totalBytes += diskTotal;
            freeBytes += available;
            return { disk, idx, used, available, diskTotal };
          });
          if (diskSummaryEl) {
            diskSummaryEl.textContent = `${formatBytes(freeBytes)} free / ${formatBytes(totalBytes)}`;
          }
          if (systemPanelCollapsed) {
            return;
          }
          if (hasPlotly()) {
            const prevCharts = diskPiesEl.querySelectorAll('.disk-chart');
            prevCharts.forEach((node) => {
              try {
                Plotly.purge(node);
              } catch (err) {
                // ignore purge errors
              }
            });
          }
          diskPiesEl.innerHTML = '';
          const colors = chartColors();
          const cardBg = colors.card || colors.bg;
          diskData.forEach(({ disk, idx, used, available, diskTotal }) => {
            const card = document.createElement('div');
            card.className = 'disk-pie';
            const heading = document.createElement('h4');
            heading.textContent = disk.mount || disk.device || `Disk ${idx + 1}`;
            card.appendChild(heading);
            const chart = document.createElement('div');
            chart.className = 'disk-chart';
            card.appendChild(chart);
            const percentLabel = typeof disk.percent === 'number' ? disk.percent.toFixed(1) : '0.0';
            const caption = document.createElement('p');
            caption.textContent = `${formatBytes(available)} free of ${formatBytes(diskTotal)} (${percentLabel}% used)`;
            card.appendChild(caption);
            diskPiesEl.appendChild(card);
            if (!hasPlotly()) {
              chart.innerHTML = '<div style="display:flex; height:100%; align-items:center; justify-content:center; color:var(--muted-text); font-size:0.9rem;">Plotly.js not available</div>';
              return;
            }
            const usedValue = used < 0 ? 0 : used;
            const freeValue = available < 0 ? 0 : available;
            const values = usedValue + freeValue > 0 ? [usedValue, freeValue] : [1, 0];
            const annotationText = `${percentLabel}%<br>used`;
            Plotly.react(
              chart,
              [
                {
                  values,
                  labels: ['Used', 'Free'],
                  type: 'pie',
                  hole: 0.65,
                  marker: { colors: [colors.diskUsed, colors.diskFree] },
                  textinfo: 'none',
                  hovertemplate: '%{label}: %{value:.2f} B (%{percent})<extra></extra>',
                },
              ],
              {
                paper_bgcolor: cardBg,
                plot_bgcolor: cardBg,
                height: 160,
                width: 160,
                margin: { l: 6, r: 6, t: 6, b: 6 },
                showlegend: false,
                annotations: [
                  {
                    text: annotationText,
                    x: 0.5,
                    y: 0.5,
                    font: { color: colors.text, size: 13 },
                    showarrow: false,
                    xref: 'paper',
                    yref: 'paper',
                    align: 'center',
                  },
                ],
              },
              plotlyConfig,
            );
          });
        }
        async function loadSystemMetrics(initial = false) {
          if (!systemChartEl && !diskPiesEl) {
            return;
          }
          try {
            const res = await fetch('/api/system/metrics');
            if (!res.ok) {
              if (initial && systemChartEl) {
                renderEmptyPlot(systemChartEl, 'Unable to load metrics', 300);
              }
              return;
            }
            const data = await res.json();
            latestSystemSnapshot = data;
            pushSystemHistory(data);
            updateSystemSummary(data);
            renderSystemUsage();
            renderDiskPies();
          } catch (err) {
            if (initial && systemChartEl) {
              renderEmptyPlot(systemChartEl, 'Unable to load metrics', 300);
            }
            console.error(err);
          }
        }
        if (seriesSelect) {
          seriesSelect.disabled = true;
        }

        async function loadRuns(showLoading = true) {
          if (showLoading && !lastTableHtml) {
            rows.innerHTML = "<tr><td colspan='7'>Loading...</td></tr>";
          }
          if (maxRunsSelect && maxRunsSelect.value) {
            if (maxRunsSelect.value === 'all') {
              maxRunsToShow = Infinity;
            } else {
              const parsed = Number(maxRunsSelect.value);
              maxRunsToShow = Number.isFinite(parsed) ? parsed : 50;
            }
          }
          try {
            const res = await fetch('/api/runs', { cache: 'no-store' });
            const data = await res.json();
            const activeIds = new Set(data.map(run => run.run_id));
            Array.from(selectedRuns).forEach((runId) => {
              if (!activeIds.has(runId)) {
                selectedRuns.delete(runId);
              }
            });
            let html;
            const sorted = [...data].sort((a, b) => {
              const aTime = typeof a.updated_at === 'number' ? a.updated_at : 0;
              const bTime = typeof b.updated_at === 'number' ? b.updated_at : 0;
              if (bTime !== aTime) {
                return bTime - aTime;
              }
              return String(b.run_id || '').localeCompare(String(a.run_id || ''));
            });
            totalRuns = sorted.length;
            if (maxRunsToShow !== Infinity) {
              totalPages = Math.max(1, Math.ceil(totalRuns / maxRunsToShow));
              if (currentPage > totalPages) {
                currentPage = totalPages;
              }
            } else {
              totalPages = 1;
              currentPage = 1;
            }
            const limit = maxRunsToShow === Infinity ? sorted.length : maxRunsToShow;
            const start = maxRunsToShow === Infinity ? 0 : (currentPage - 1) * maxRunsToShow;
            const toRender = sorted.slice(start, start + limit);
            if (!toRender.length) {
              html = "<tr><td colspan='7'>No runs yet</td></tr>";
            } else {
              html = toRender
                .map(run => {
                  const status = run.status || 'unknown';
                  const label = run.label || run.run_id;
                  const last = typeof run.last_cost === 'number' ? run.last_cost.toExponential(3) : '-';
                      const updated = formatRunTimestamp(run.updated_at);
                  const safeLabel = escapeHtml(label);
                  const isSelected = selectedRuns.has(run.run_id);
                  const selectionClass = selectionMode && isSelected ? ' class="selected"' : '';
                  const pressed = selectionMode && isSelected ? 'true' : 'false';
                  return `<tr data-run="${run.run_id}"${selectionClass}>
                    <td class="select-cell">
                      <button type="button" class="row-select${isSelected ? ' selected' : ''}" data-run="${run.run_id}" aria-pressed="${pressed}" aria-label="${isSelected ? 'Deselect' : 'Select'} ${safeLabel}"></button>
                      <span class="sr-only">${isSelected ? 'Selected' : 'Not selected'}</span>
                    </td>
                    <td><a href="#" data-run="${run.run_id}">${safeLabel}</a></td>
                    <td class="status ${status}">${status}</td>
                    <td>${run.iteration_count}</td>
                    <td>${last}</td>
                    <td>${updated}</td>
                    <td><button class="deleteBtn" data-run="${run.run_id}">Delete</button></td>
                  </tr>`;
                })
                .join('');
            }
            if (html !== lastTableHtml) {
              rows.innerHTML = html;
              lastTableHtml = html;
              refreshSelectionStyles();
            }
            updateSelectionToolbar();
            if (selectedRunId) {
              const selectedSummary = data.find(run => run.run_id === selectedRunId);
              if (selectedSummary) {
                const nextFingerprint = runFingerprint(selectedSummary);
                if (nextFingerprint !== selectedRunFingerprint) {
                  selectedRunFingerprint = nextFingerprint;
                  await refreshDetail(selectedRunId, { silent: true });
                }
                if (!isActiveStatus(selectedSummary.status)) {
                  stopProcessPolling();
                }
              } else {
                closeDetail();
              }
            }
            updatePaginationUI();
          } catch (err) {
            console.error(err);
          }
        }

        async function refreshDetail(runId, { silent = false } = {}) {
          if (!silent) {
            detailSummary.innerHTML = "<p style='opacity:0.6;'>Loading...</p>";
            renderEmptyPlot(costChartEl, 'Loading...');
            renderEmptyPlot(seriesChartEl, 'Loading...');
          }
          try {
            const res = await fetch(`/api/runs/${runId}`, { cache: 'no-store' });
            if (!res.ok) {
              throw new Error('Failed to load run details');
            }
            const data = await res.json();
            currentDetailData = data;
            selectedRunFingerprint = runFingerprint({
              run_id: data.run_id,
              status: data.status,
              updated_at: data.updated_at,
              iteration_count: Array.isArray(data.iterations) ? data.iterations.length : 0,
              last_cost: data && data.meta ? data.meta.last_cost : null,
            });
            renderDetailPanels(data);
          } catch (err) {
            console.error(err);
            detailSummary.innerHTML = "<p style='color:#ff6b6b;'>Failed to load run details.</p>";
            renderEmptyPlot(costChartEl, 'Failed to load data');
            renderEmptyPlot(seriesChartEl, 'Failed to load data');
          }
        }

        function renderDetailPanels(data, { refreshJson = true } = {}) {
          if (!data) {
            return;
          }
          detail.hidden = false;
          detailTitle.textContent = data.label || data.run_id || 'Run detail';
          const processPanel = document.getElementById('processPanel');
          const status = data.status || 'unknown';
          if (processPanel) {
            const shouldShow = isActiveStatus(status);
            processPanel.style.display = shouldShow ? '' : 'none';
          }
          if (!isActiveStatus(status)) {
            stopProcessPolling();
          }
          renderSummary(data);
          renderIterations(data);
          const seriesInfo = collectIterationSeries(data);
          iterationSeriesByIndex = seriesInfo.map || {};
          latestSeriesIndex = typeof seriesInfo.latestIndex === 'number' ? seriesInfo.latestIndex : null;
          if (lockedIterationIndex !== null) {
            const ok = applySeriesFromIndex(lockedIterationIndex, { lockMode: 'preserve', silent: true });
            if (!ok && typeof latestSeriesIndex === 'number') {
              applySeriesFromIndex(latestSeriesIndex, { lockMode: 'clear' });
            } else if (!ok) {
              renderSeries(null);
              updateIterationLockUi();
            }
          } else if (typeof latestSeriesIndex === 'number') {
            applySeriesFromIndex(latestSeriesIndex, { lockMode: 'clear' });
          } else {
            renderSeries(null);
            updateIterationLockUi();
          }
          if (detailJson) {
            if (refreshJson) {
              const resetJson = detailJson.textContent === '' || detailJson.textContent === '{}';
              const text = JSON.stringify(data, null, 2);
              if (detailJson.textContent !== text) {
                detailJson.textContent = text;
              }
              if (resetJson) {
                collapseJson();
              } else if (jsonExpanded) {
                detailJson.style.maxHeight = '320px';
                detailJson.style.overflowY = 'auto';
                detailJson.style.visibility = 'visible';
              }
            } else if (jsonExpanded) {
              detailJson.style.maxHeight = '320px';
              detailJson.style.overflowY = 'auto';
              detailJson.style.visibility = 'visible';
            } else {
              detailJson.style.maxHeight = '0';
              detailJson.style.overflowY = 'hidden';
              detailJson.style.visibility = 'hidden';
            }
          }
        }

        function updatePaginationUI() {
          const label = totalPages < 1 ? 'Page 1 / 1' : `Page ${currentPage} / ${totalPages}`;
          if (pageIndicator) {
            pageIndicator.textContent = label;
          }
          if (pagePrevBtn) {
            pagePrevBtn.disabled = currentPage <= 1;
          }
          if (pageNextBtn) {
            pageNextBtn.disabled = currentPage >= totalPages;
          }
        }

        async function showDetail(runId) {
          selectedRunId = runId;
          selectedRunFingerprint = null;
          await refreshDetail(runId);
          if (currentDetailData && isActiveStatus(currentDetailData.status)) {
            startProcessPolling(runId);
          }
        }

        function renderSummary(data) {
          const summary = [];
          const meta = data.meta || {};
          const iterations = Array.isArray(data.iterations) ? data.iterations : [];
          const latestIndex = iterations.length ? iterations.length - 1 : null;
          const lockedIsValid =
            typeof lockedIterationIndex === 'number'
            && lockedIterationIndex >= 0
            && lockedIterationIndex < iterations.length;
          if (!lockedIsValid && lockedIterationIndex !== null) {
            lockedIterationIndex = null;
            updateIterationLockUi();
          }
          const activeIndex = lockedIsValid ? lockedIterationIndex : latestIndex;
          const iteration = typeof activeIndex === 'number' ? iterations[activeIndex] : null;
          if (iteration) {
            const displayIndex = typeof iteration.index === 'number' ? iteration.index : activeIndex;
            const contextLabel = lockedIsValid ? 'locked' : 'latest';
            summary.push({ label: 'Iteration', value: `#${displayIndex} (${contextLabel})` });
          }
          const statusRaw = typeof data.status === 'string' ? data.status : 'unknown';
          const statusLower = statusRaw.toLowerCase();
          const statusSpan = `<span class="status ${statusLower}">${escapeHtml(statusRaw)}</span>`;
          let statusValue = statusSpan;
          const failureReason = typeof meta.failure_reason === 'string' ? meta.failure_reason : null;
          if (statusLower === 'failed' && failureReason) {
            statusValue += `<span class="status-reason">${escapeHtml(failureReason)}</span>`;
          }
          const unknownReason = typeof meta.unknown_reason === 'string' ? meta.unknown_reason : null;
          if (statusLower === 'unknown' && unknownReason) {
            statusValue += `<span class="status-reason">${escapeHtml(unknownReason)}</span>`;
          }
          summary.push({ label: 'Status', value: statusValue });
          const iterationCost = iteration && typeof iteration.cost === 'number' ? iteration.cost : null;
          if (typeof iterationCost === 'number') {
            summary.push({ label: 'Cost', value: iterationCost.toExponential(4) });
          } else if (typeof meta.last_cost === 'number') {
            summary.push({ label: 'Last cost', value: meta.last_cost.toExponential(4) });
          }
          const iterationMetrics =
            iteration && iteration.metrics && typeof iteration.metrics === 'object' ? iteration.metrics : null;
          const iterationRSquared =
            iterationMetrics && iterationMetrics.r_squared && typeof iterationMetrics.r_squared === 'object'
              ? iterationMetrics.r_squared
              : null;
          const metaRSquared = meta.r_squared && typeof meta.r_squared === 'object' ? meta.r_squared : null;
          const rSquaredSource = iterationRSquared || metaRSquared;
          if (rSquaredSource) {
            const rows = Object.entries(rSquaredSource)
              .map(([key, value]) => {
                const safeKey = escapeHtml(key);
                let display = '-';
                if (value !== null && value !== undefined) {
                  const num = Number(value);
                  if (Number.isFinite(num)) {
                    display = num.toFixed(4);
                  }
                }
                return `<div class="param-row"><span>${safeKey}</span><span>${display}</span></div>`;
              });
            if (rows.length) {
              summary.push({ label: 'R²', value: `<div class="param-grid">${rows.join('')}</div>` });
            }
          }
          if (meta.optimizer) {
            let label = meta.optimizer;
            if (typeof meta.optimizer === 'object') {
              const values = Object.values(meta.optimizer);
              if (values.length === 1) {
                label = values[0];
              } else {
                label = JSON.stringify(meta.optimizer);
              }
            }
            const safeLabel = typeof label === 'string' ? escapeHtml(label) : escapeHtml(String(label));
            summary.push({ label: 'Optimizer', value: safeLabel });
          }
          const paramCard = buildParameterCard(data, iteration);
          if (paramCard) {
            summary.push(paramCard);
          }
          detailSummary.innerHTML = summary.map(item => `
            <dl class="summary-card">
              <dt>${item.label}</dt>
              <dd>${item.value}</dd>
            </dl>`).join('') || "<p style='opacity:0.6;'>No summary metadata</p>";
        }

        function refreshSummaryView() {
          if (currentDetailData) {
            renderSummary(currentDetailData);
          }
        }

        function buildParameterCard(data, iterationEntry) {
          if (!data) {
            return null;
          }
          const parameterMeta = data.parameters || {};
          const names = Array.isArray(parameterMeta.names)
            ? parameterMeta.names.filter(name => typeof name === 'string')
            : [];
          const theta0 = Array.isArray(parameterMeta.theta0) ? parameterMeta.theta0 : null;
          const iterationTheta =
            iterationEntry && iterationEntry.theta && typeof iterationEntry.theta === 'object'
              ? iterationEntry.theta
              : null;
          const latestTheta = latestThetaSnapshot(data);
          const thetaSource =
            iterationTheta && Object.keys(iterationTheta).length ? iterationTheta : latestTheta;
          const rows = [];
          const seen = new Set();
          names.forEach((name, idx) => {
            let value;
            if (iterationTheta && Object.prototype.hasOwnProperty.call(iterationTheta, name)) {
              value = iterationTheta[name];
            } else if (thetaSource && Object.prototype.hasOwnProperty.call(thetaSource, name)) {
              value = thetaSource[name];
            } else if (theta0 && theta0[idx] !== undefined) {
              value = theta0[idx];
            }
            if (value !== undefined) {
              rows.push(`<div class="param-row"><span>${escapeHtml(name)}</span><span>${formatParameterValue(value)}</span></div>`);
              seen.add(name);
            }
          });
          if (thetaSource) {
            Object.entries(thetaSource).forEach(([name, value]) => {
              if (typeof name === 'string' && !seen.has(name)) {
                rows.push(`<div class="param-row"><span>${escapeHtml(name)}</span><span>${formatParameterValue(value)}</span></div>`);
              }
            });
          }
        if (rows.length) {
            return { label: 'Parameters', value: `<div class="param-grid">${rows.join('')}</div>` };
          }
          if (names.length) {
            return { label: 'Parameters', value: names.map(escapeHtml).join(', ') };
          }
          return null;
        }

        function renderProcessMessage(message, summary = 'Idle') {
          if (!processTableEl) {
            return;
          }
          processTableEl.innerHTML = `<p class="terminal-empty">${escapeHtml(message)}</p>`;
          if (processSummaryEl) {
            processSummaryEl.textContent = summary;
          }
        }

        function extractFebFilename(cmdline) {
          if (!Array.isArray(cmdline)) {
            return null;
          }
          for (let idx = cmdline.length - 1; idx >= 0; idx -= 1) {
            const part = cmdline[idx];
            if (typeof part !== 'string') {
              continue;
            }
            const trimmed = part.trim();
            if (!trimmed || !trimmed.toLowerCase().endsWith('.feb')) {
              continue;
            }
            const segments = trimmed.split(/[/\\]/);
            const name = segments[segments.length - 1];
            if (name) {
              return name;
            }
          }
          return null;
        }

        function renderProcessState(payload) {
          if (!processTableEl) {
            return;
          }
          if (!payload) {
            renderProcessMessage('Select a run to inspect simulations.', '--');
            return;
          }
          if (payload.supported === false) {
            renderProcessMessage('Process tracking is unavailable on this host.', 'Unavailable');
            return;
          }
          if (!payload.root) {
            renderProcessMessage('This run did not report a storage root; unable to match processes.', 'Unknown');
            return;
          }
          const processes = Array.isArray(payload.processes) ? payload.processes : [];
          if (!processes.length) {
            renderProcessMessage('No FEBio simulations detected right now.', 'Idle');
            return;
          }
          const rows = processes
            .map((proc) => {
              const pid = typeof proc.pid === 'number' ? proc.pid : '-';
              const name = proc.name ? escapeHtml(proc.name) : 'process';
              const status = proc.status ? `<small>${escapeHtml(proc.status)}</small>` : '';
              const febFile = extractFebFilename(proc.cmdline);
              const febCell = febFile ? escapeHtml(febFile) : '—';
              const cmdline = Array.isArray(proc.cmdline) ? proc.cmdline : [];
              const commandRaw = cmdline.length ? cmdline.join(' ') : '';
              const cmd = commandRaw ? escapeHtml(commandRaw) : '—';
              const cmdTitle = commandRaw ? ` title="${escapeHtml(commandRaw)}"` : '';
              const threads =
                typeof proc.omp_threads === 'number' && Number.isFinite(proc.omp_threads)
                  ? proc.omp_threads
                  : null;
              const threadsLabel = threads ? `${threads}` : '—';
              const age = formatProcessAge(proc.started_at);
              return `<div class="terminal-row">
                <span class="terminal-pid">#${pid}</span>
                <span class="terminal-name">${name}${status}</span>
                <span class="terminal-feb">${febCell}</span>
                <span class="terminal-omp">${threadsLabel}</span>
                <span class="terminal-command"${cmdTitle}>${cmd}</span>
                <span class="terminal-age">${age}</span>
              </div>`;
            })
            .join('');
          processTableEl.innerHTML = `
            <div class="terminal-header">
              <span>PID</span>
              <span>Process</span>
              <span>FEB file</span>
              <span>OMP</span>
              <span>Command</span>
              <span>Uptime</span>
            </div>
            ${rows}
          `;
          if (processSummaryEl) {
            processSummaryEl.textContent = `${processes.length} active`;
          }
        }

        function formatProcessAge(startedAt) {
          if (typeof startedAt !== 'number' || !Number.isFinite(startedAt)) {
            return '—';
          }
          const now = Date.now() / 1000;
          const delta = Math.max(0, now - startedAt);
          const hours = Math.floor(delta / 3600);
          const minutes = Math.floor((delta % 3600) / 60);
          const seconds = Math.floor(delta % 60);
          if (hours > 0) {
            return `${hours}h ${String(minutes).padStart(2, '0')}m`;
          }
          if (minutes > 0) {
            return `${minutes}m ${String(seconds).padStart(2, '0')}s`;
          }
          return `${seconds}s`;
        }

        async function loadRunProcesses(runId, { silent = false } = {}) {
          if (!processTableEl || !runId) {
            return;
          }
          if (!silent) {
            renderProcessMessage('Collecting process info...', 'Loading');
          }
          try {
            const res = await fetch(`/api/runs/${runId}/processes`, { cache: 'no-store' });
            if (!res.ok) {
              throw new Error('Failed to load process list');
            }
            const data = await res.json();
            if (runId !== selectedRunId) {
              return;
            }
            renderProcessState(data);
          } catch (err) {
            console.error(err);
            if (!silent) {
              renderProcessMessage('Unable to read process list.', 'Unavailable');
            }
          }
        }

        function startProcessPolling(runId) {
          if (!processTableEl || !runId) {
            return;
          }
          stopProcessPolling();
          loadRunProcesses(runId);
          processTimer = setInterval(() => {
            if (selectedRunId !== runId) {
              stopProcessPolling();
              return;
            }
            loadRunProcesses(runId, { silent: true });
          }, 4000);
        }

        function stopProcessPolling() {
          if (processTimer) {
            clearInterval(processTimer);
            processTimer = null;
          }
        }

        function renderIterations(data) {
          renderCostChart(Array.isArray(data.iterations) ? data.iterations : []);
        }

        function renderCostChart(iterations) {
          if (!costChartEl) {
            return;
          }
          if (!iterations.length) {
            renderEmptyPlot(costChartEl, 'No iteration data');
            return;
          }
          const points = iterations
            .map((it, idx) => {
              const cost = Number(it.cost);
              return Number.isFinite(cost) ? { idx, cost } : null;
            })
            .filter(Boolean);
          if (!points.length) {
            renderEmptyPlot(costChartEl, 'No valid cost values');
            return;
          }
          if (!hasPlotly()) {
            renderEmptyPlot(costChartEl, 'Plotly.js not available');
            return;
          }
          const themeName = document.body.classList.contains('light') ? 'light' : 'dark';
          const signature = JSON.stringify({
            theme: themeName,
            points: points.map(item => [item.idx, item.cost]),
          });
          if (signature === lastCostChartSignature) {
            return;
          }
          lastCostChartSignature = signature;
          const colors = chartColors();
          const tickStep = points.length > 1 ? Math.max(1, Math.ceil(points.length / 10)) : 1;
          const trace = {
            x: points.map(item => item.idx),
            y: points.map(item => item.cost),
            mode: 'lines+markers',
            name: 'Cost',
            marker: { color: '#6ec1ff', size: 6 },
            line: { color: '#6ec1ff', width: 2.5 },
            hovertemplate: 'Iteration %{x}<br>Cost %{y:.4e}<extra></extra>',
          };
          const layout = {
            paper_bgcolor: colors.bg,
            plot_bgcolor: colors.bg,
            autosize: true,
            height: 420,
            margin: { l: 64, r: 28, t: 32, b: 64 },
            font: { color: colors.text },
            xaxis: {
              title: { text: 'Iteration' },
              dtick: tickStep,
              color: colors.text,
              gridcolor: colors.grid,
              zerolinecolor: colors.zero,
            },
            yaxis: {
              title: { text: 'Cost' },
              color: colors.text,
              gridcolor: colors.grid,
              zerolinecolor: colors.zero,
              tickformat: '.2e',
            },
            hovermode: 'closest',
            uirevision: 'cost-chart',
          };
          Plotly.react(costChartEl, [trace], layout, plotlyConfig);
          showCostChartTip();
          attachCostChartEvents();
          if (typeof Plotly !== 'undefined' && Plotly.Plots && typeof Plotly.Plots.resize === 'function') {
            Plotly.Plots.resize(costChartEl);
          }
        }

        function attachCostChartEvents() {
          if (!costChartEl || typeof costChartEl.on !== 'function') {
            return;
          }
          if (costChartEl.__seriesClickHandler) {
            return;
          }
          const handler = async (eventData) => {
            if (!eventData || !eventData.points || !eventData.points.length) {
              return;
            }
            const point = eventData.points[0];
            const idx = typeof point.x === 'number' ? Math.round(point.x) : null;
            if (typeof idx !== 'number') {
              return;
            }
            const success = applySeriesFromIndex(idx, { lockMode: 'lock' });
            if (!success) {
              const loaded = await loadIterationSeries(idx);
              if (loaded) {
                applySeriesFromIndex(idx, { lockMode: 'lock' });
              } else if (seriesChartEl) {
                renderEmptyPlot(seriesChartEl, `No series data for iteration ${idx}`);
              }
            }
          };
          costChartEl.__seriesClickHandler = handler;
          costChartEl.on('plotly_click', handler);
        }

        function showCostChartTip() {
          if (costChartTipShown || !costChartEl || !costChartEl.parentElement) {
            return;
          }
          const host = costChartEl.parentElement;
          const tip = document.createElement('div');
          tip.className = 'chart-tip';
          tip.textContent = 'Click a point to view that iteration';
          host.appendChild(tip);
          costChartTipShown = true;
          setTimeout(() => tip.classList.add('hide'), 3200);
          setTimeout(() => {
            if (tip && tip.parentElement) {
              tip.parentElement.removeChild(tip);
            }
          }, 3600);
        }

        function collapseJson() {
          jsonExpanded = false;
          toggleJsonBtn.textContent = 'Expand';
          detailJson.style.maxHeight = '0';
          detailJson.style.overflowY = 'hidden';
          detailJson.style.visibility = 'hidden';
        }

        function closeDetail() {
          detail.hidden = true;
          detailJson.textContent = '';
          detailSummary.innerHTML = '';
          jsonExpanded = false;
          toggleJsonBtn.textContent = 'Expand';
          detailJson.style.maxHeight = '0';
          detailJson.style.overflowY = 'hidden';
          detailJson.style.visibility = 'hidden';
          stopProcessPolling();
          renderProcessMessage('Select a run to inspect simulations.', '--');
          selectedRunId = null;
          selectedRunFingerprint = null;
          currentSeriesData = {};
          currentDetailData = null;
          if (seriesSelect) {
            seriesSelect.innerHTML = '';
            seriesSelect.disabled = true;
          }
          if (hasPlotly()) {
            if (costChartEl) {
              Plotly.purge(costChartEl);
            }
            if (seriesChartEl) {
              Plotly.purge(seriesChartEl);
            }
          }
          if (seriesChartEl) {
            seriesChartEl.innerHTML = '';
          }
          if (costChartEl) {
            costChartEl.innerHTML = '';
          }
          iterationSeriesByIndex = {};
          latestSeriesIndex = null;
          lockedIterationIndex = null;
          lastCostChartSignature = null;
          lastSeriesChartSignature = null;
          updateIterationLockUi();
        }

        function renderSeries(series) {
          currentSeriesData = series || {};
          if (!seriesSelect || !seriesChartEl) {
            return;
          }
          const keys = Object.keys(currentSeriesData);
          if (!keys.length) {
            seriesSelect.innerHTML = '<option>No data</option>';
            seriesSelect.disabled = true;
            renderEmptyPlot(seriesChartEl, 'No series data');
            return;
          }
          seriesSelect.disabled = false;
          const desiredValue =
            !seriesSelect.value || !currentSeriesData[seriesSelect.value]
              ? keys[0]
              : seriesSelect.value;
          seriesSelect.innerHTML = keys
            .map(key => `<option value="${key}" ${key === desiredValue ? 'selected' : ''}>${key}</option>`)
            .join('');
          seriesSelect.value = desiredValue;
          renderSeriesChart(desiredValue);
        }

        async function loadIterationSeries(index) {
          if (!selectedRunId || typeof index !== 'number') {
            return false;
          }
          try {
            const res = await fetch(`/api/runs/${selectedRunId}/iterations/${index}/series`, { cache: 'no-store' });
            if (!res.ok) {
              return false;
            }
            const series = await res.json();
            if (!series || !Object.keys(series).length) {
              return false;
            }
            iterationSeriesByIndex[index] = series;
            if (currentDetailData && Array.isArray(currentDetailData.iterations)) {
              const entry = currentDetailData.iterations[index];
              if (entry) {
                entry.series = series;
              }
            }
            return true;
          } catch (err) {
            console.error(err);
            return false;
          }
        }

        function renderSeriesChart(key) {
          if (!seriesChartEl) {
            return;
          }
          const dataset = currentSeriesData && key ? currentSeriesData[key] : null;
          if (!dataset) {
            renderEmptyPlot(seriesChartEl, 'No series data');
            return;
          }
          const xRaw = Array.isArray(dataset.x) ? dataset.x : [];
          const expRaw = Array.isArray(dataset.y_exp) ? dataset.y_exp : [];
          const simRaw = Array.isArray(dataset.y_sim) ? dataset.y_sim : [];
          const length = Math.min(xRaw.length, expRaw.length, simRaw.length);
          const points = [];
          for (let i = 0; i < length; i++) {
            const xVal = Number(xRaw[i]);
            const expVal = Number(expRaw[i]);
            const simVal = Number(simRaw[i]);
            if (Number.isFinite(xVal) && Number.isFinite(expVal) && Number.isFinite(simVal)) {
              points.push({ x: xVal, exp: expVal, sim: simVal });
            }
          }
          if (!points.length) {
            renderEmptyPlot(seriesChartEl, 'No series data');
            return;
          }
          if (!hasPlotly()) {
            renderEmptyPlot(seriesChartEl, 'Plotly.js not available');
            return;
          }
          const themeName = document.body.classList.contains('light') ? 'light' : 'dark';
          const signature = JSON.stringify({
            theme: themeName,
            key,
            points: points.map(p => [p.x, p.exp, p.sim]),
          });
          if (signature === lastSeriesChartSignature) {
            return;
          }
          lastSeriesChartSignature = signature;
          const colors = chartColors();
          const traces = [
            {
              x: points.map(p => p.x),
              y: points.map(p => p.exp),
              mode: 'markers',
              name: 'Experimental',
              marker: { color: '#ffb347', size: 7 },
              hovertemplate: 'x %{x}<br>Experimental %{y:.4e}<extra></extra>',
            },
            {
              x: points.map(p => p.x),
              y: points.map(p => p.sim),
              mode: 'lines',
              name: 'Simulation',
              line: { color: '#6ec1ff', width: 3 },
              hovertemplate: 'x %{x}<br>Simulation %{y:.4e}<extra></extra>',
            },
          ];
          const layout = {
            paper_bgcolor: colors.bg,
            plot_bgcolor: colors.bg,
            autosize: true,
            height: 420,
            margin: { l: 64, r: 28, t: 32, b: 64 },
            font: { color: colors.text },
            xaxis: {
              title: { text: 'x' },
              color: colors.text,
              gridcolor: colors.grid,
              zerolinecolor: colors.zero,
            },
            yaxis: {
              title: { text: 'y' },
              color: colors.text,
              gridcolor: colors.grid,
              zerolinecolor: colors.zero,
            },
            legend: {
              orientation: 'h',
              yanchor: 'bottom',
              y: 1.02,
              xanchor: 'left',
              x: 0,
            },
            hovermode: 'closest',
            uirevision: 'series-chart',
          };
          Plotly.react(seriesChartEl, traces, layout, plotlyConfig);
          if (typeof Plotly !== 'undefined' && Plotly.Plots && typeof Plotly.Plots.resize === 'function') {
            Plotly.Plots.resize(seriesChartEl);
          }
        }

        function applySeriesFromIndex(index, { lockMode = 'clear', silent = false } = {}) {
          const hasEntry =
            typeof index === 'number'
            && iterationSeriesByIndex
            && Object.prototype.hasOwnProperty.call(iterationSeriesByIndex, index);
          if (!hasEntry) {
            if (!silent) {
              renderSeries(null);
            }
            lockedIterationIndex = null;
            updateIterationLockUi();
            refreshSummaryView();
            return false;
          }
          const dataset = iterationSeriesByIndex[index];
          if (!dataset || !Object.keys(dataset).length) {
            if (!silent) {
              renderSeries(null);
            }
            lockedIterationIndex = null;
            updateIterationLockUi();
            refreshSummaryView();
            return false;
          }
          if (lockMode === 'lock') {
            lockedIterationIndex = index;
          } else if (lockMode === 'clear') {
            lockedIterationIndex = null;
          }
          renderSeries(dataset);
          updateIterationLockUi();
          refreshSummaryView();
          return true;
        }

        function formatIterationLabel(index) {
          if (typeof index !== 'number') {
            return null;
          }
          if (!currentDetailData || !Array.isArray(currentDetailData.iterations)) {
            return index;
          }
          const entry = currentDetailData.iterations[index];
          if (entry && typeof entry.index === 'number') {
            return entry.index;
          }
          return index;
        }

        function updateIterationLockUi() {
          if (!detailLiveBtn) {
            return;
          }
          if (lockedIterationIndex === null) {
            detailLiveBtn.style.display = 'none';
            detailLiveBtn.textContent = 'Back to latest';
          } else {
            const label = formatIterationLabel(lockedIterationIndex);
            detailLiveBtn.style.display = '';
            detailLiveBtn.textContent = `Back to latest (current: iter ${label ?? lockedIterationIndex})`;
          }
        }

        if (seriesSelect) {
          seriesSelect.addEventListener('change', (event) => {
            renderSeriesChart(event.target.value);
          });
        }
        if (detailLiveBtn) {
          detailLiveBtn.addEventListener('click', () => {
            lockedIterationIndex = null;
            if (typeof latestSeriesIndex === 'number') {
              applySeriesFromIndex(latestSeriesIndex, { lockMode: 'clear' });
            } else {
              renderSeries(null);
              updateIterationLockUi();
              refreshSummaryView();
            }
          });
        }
        document.getElementById('refresh').addEventListener('click', () => loadRuns());
        document.getElementById('deleteAll').addEventListener('click', () => deleteAllRuns());
        closeDetailBtn.addEventListener('click', () => {
          closeDetail();
        });
        toggleJsonBtn.addEventListener('click', () => {
          jsonExpanded = !jsonExpanded;
          if (jsonExpanded) {
            toggleJsonBtn.textContent = 'Collapse';
            detailJson.style.maxHeight = '320px';
            detailJson.style.overflowY = 'auto';
            detailJson.style.visibility = 'visible';
          } else {
            collapseJson();
          }
        });
        ensureSystemPanelElements();
        if (toggleSystemPanelBtn && systemPanel && systemContent) {
          toggleSystemPanelBtn.addEventListener('click', handleSystemPanelToggle);
        }
        document.addEventListener('click', (event) => {
          const target = event && event.target && typeof event.target.closest === 'function'
            ? event.target.closest('#toggleSystemPanel')
            : null;
          if (!target) {
            return;
          }
          handleSystemPanelToggle(event);
        });
        setSystemPanelCollapsed(false, { skipRender: true });
        if (toggleSelectionBtn) {
          toggleSelectionBtn.addEventListener('click', () => {
            if (selectionMode) {
              exitSelectionMode();
            } else {
              enterSelectionMode();
            }
          });
        }
        if (cancelSelectionBtn) {
          cancelSelectionBtn.addEventListener('click', () => {
            exitSelectionMode();
          });
        }
        if (bulkDeleteBtn) {
          bulkDeleteBtn.addEventListener('click', async () => {
            await deleteSelectedRuns();
          });
        }
        if (maxRunsSelect) {
          maxRunsSelect.addEventListener('change', (event) => {
            const value = event.target.value;
            if (value === 'all') {
              maxRunsToShow = Infinity;
            } else {
              const parsed = Number(value);
              maxRunsToShow = Number.isFinite(parsed) ? parsed : 50;
            }
            currentPage = 1;
            loadRuns();
          });
          // Initialize page size from the current select value on load
          const initialValue = maxRunsSelect.value;
          if (initialValue === 'all') {
            maxRunsToShow = Infinity;
          } else {
            const parsedInit = Number(initialValue);
            maxRunsToShow = Number.isFinite(parsedInit) ? parsedInit : 50;
          }
        }
        if (pagePrevBtn) {
          pagePrevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
              currentPage -= 1;
              loadRuns(false);
            }
          });
        }
        if (pageNextBtn) {
          pageNextBtn.addEventListener('click', () => {
            if (currentPage < totalPages) {
              currentPage += 1;
              loadRuns(false);
            }
          });
        }
        updatePaginationUI();
        updateSelectionToolbar();

        async function deleteRun(runId, force = false, skipConfirm = false) {
          if (!skipConfirm) {
            const msg = force
              ? `Force delete run ${runId}? Only use this if the monitor cannot determine its state.`
              : `Delete run ${runId}?`;
            if (!confirm(msg)) {
              return;
            }
          }
          try {
            const endpoint = force ? `/api/runs/${runId}?force=1` : `/api/runs/${runId}`;
            const res = await fetch(endpoint, { method: 'DELETE' });
            if (res.status === 409 && !force) {
              const err = await res.json().catch(() => ({}));
              const confirmForce = confirm(
                `${err.detail || 'Run appears to be active.'}
Force delete ${runId}?`,
              );
              if (confirmForce) {
                await deleteRun(runId, true, true);
              }
              return;
            }
            if (!res.ok) {
              const err = await res.json().catch(() => ({}));
              alert(err.detail || 'Failed to delete run');
              return;
            }
            if (selectedRunId === runId) {
              closeDetail();
            }
            await loadRuns(false);
          } catch (err) {
            alert('Failed to delete run');
            console.error(err);
          }
        }
        async function deleteSelectedRuns() {
          if (!selectionMode || !selectedRuns.size) {
            return;
          }
          const confirmBulk = confirm(`Delete ${selectedRuns.size} run(s)?`);
          if (!confirmBulk) {
            return;
          }
          let previousLabel = null;
          if (bulkDeleteBtn) {
            previousLabel = bulkDeleteBtn.textContent;
            bulkDeleteBtn.disabled = true;
            bulkDeleteBtn.textContent = 'Deleting...';
          }
          const targets = Array.from(selectedRuns);
          for (const runId of targets) {
            try {
              await deleteRun(runId, false, true);
            } catch (err) {
              console.error(`Failed to delete run ${runId}`, err);
            }
          }
          if (bulkDeleteBtn && previousLabel !== null) {
            bulkDeleteBtn.textContent = previousLabel;
            bulkDeleteBtn.disabled = false;
          }
          exitSelectionMode();
          loadRuns();
        }
        async function deleteAllRuns(force = false, skipConfirm = false) {
          if (!skipConfirm) {
            const msg = force
              ? 'Force delete all runs? This will also remove entries still marked as running.'
              : 'Delete all completed runs? This cannot be undone.';
            if (!confirm(msg)) {
              return;
            }
          }
          try {
            const endpoint = force ? '/api/runs?force=1' : '/api/runs';
            const res = await fetch(endpoint, { method: 'DELETE' });
            if (!res.ok) {
              alert('Failed to delete runs');
              return;
            }
            const data = await res.json().catch(() => ({}));
            if (!force && Array.isArray(data.protected) && data.protected.length) {
              const askForce = confirm(
                `Skipped ${data.protected.length} active run(s): ${data.protected.join(', ')}
Force delete them?`,
              );
              if (askForce) {
                await deleteAllRuns(true, true);
              }
            }
            closeDetail();
            await loadRuns(false);
          } catch (err) {
            alert('Failed to delete runs');
            console.error(err);
          }
        }

        rows.addEventListener('click', (event) => {
          const target = event.target;
          if (!target) {
            return;
          }
          const selectBtn = target.closest('.row-select');
          const deleteBtn = target.closest('.deleteBtn');
          const linkTarget = target.closest('a[data-run]');
          const row = target.closest('tr[data-run]');
          const runId =
            (selectBtn && selectBtn.dataset.run) ||
            (deleteBtn && deleteBtn.dataset.run) ||
            (linkTarget && linkTarget.dataset.run) ||
            (row && row.dataset.run);
          if (!runId) {
            return;
          }
          if (selectionMode) {
            event.preventDefault();
            toggleRunSelection(runId);
            return;
          }
          if (deleteBtn) {
            event.preventDefault();
            deleteRun(runId);
            return;
          }
          if (linkTarget) {
            event.preventDefault();
            showDetail(runId);
          }
        });
        loadRuns();
        setInterval(() => loadRuns(false), 4000);
        loadSystemMetrics(true);
        setInterval(() => loadSystemMetrics(false), 5000);
