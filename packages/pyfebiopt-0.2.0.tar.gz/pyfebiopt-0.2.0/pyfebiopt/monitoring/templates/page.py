"""Static asset loader for the monitoring dashboard."""

from __future__ import annotations

from importlib.resources import files

_ASSET_PACKAGE = "pyfebiopt.monitoring.templates"


def read_template_asset(name: str) -> str:
    """Read a dashboard template asset bundled with the package.

    Returns:
        str: Asset text.
    """
    return files(_ASSET_PACKAGE).joinpath(name).read_text(encoding="utf-8")


class MonitorPageTemplate:
    """Render the monitor dashboard HTML shell."""

    @classmethod
    def render(cls) -> str:
        """Return the dashboard HTML page."""
        return read_template_asset("index.html")


__all__ = ["MonitorPageTemplate", "read_template_asset"]
