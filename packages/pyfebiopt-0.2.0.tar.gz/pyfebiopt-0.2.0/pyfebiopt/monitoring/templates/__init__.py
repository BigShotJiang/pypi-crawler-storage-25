"""Dashboard template package for the monitoring web UI."""

from .page import MonitorPageTemplate, read_template_asset

__all__ = ["MonitorPageTemplate", "read_template_asset"]
