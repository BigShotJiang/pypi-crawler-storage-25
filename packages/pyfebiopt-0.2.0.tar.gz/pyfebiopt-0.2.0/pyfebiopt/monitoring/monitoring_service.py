"""Controller that wires together registry, event listener, and system stats."""

from __future__ import annotations

import threading
import time
from collections.abc import Iterable
from pathlib import Path

from .events import EventSocketListener
from .paths import default_registry_path, default_socket_path
from .registry import RunRegistry
from .runstate import OptimizationRun
from .state import StorageInventory
from .system_stats import SystemStatsCollector


class _StaleRunReaper:
    """Mark stale active runs as unknown when no matching process remains."""

    def __init__(
        self,
        registry: RunRegistry,
        stats: SystemStatsCollector,
        *,
        stale_after: float = 180.0,
        interval: float = 30.0,
    ) -> None:
        self.registry = registry
        self.stats = stats
        self.stale_after = max(1.0, float(stale_after))
        self.interval = max(0.5, float(interval))
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start periodic stale-run checks in a background thread."""
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._serve,
            name="StaleRunReaper",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop the periodic stale-run checks."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        self._thread = None

    def sweep_once(self) -> int:
        """Mark stale runs as unknown.

        Returns:
            int: Number of runs transitioned to ``unknown``.
        """
        now = time.time()
        transitioned = 0
        for run in self.registry.list_runs():
            if not self._needs_reap(run, now):
                continue
            if self._has_live_process(run):
                continue
            self.registry.apply_event(
                run.run_id,
                "run_unknown",
                {"reason": (f"monitor: no activity detected for {int(now - run.updated_at)}s")},
                ts=now,
            )
            transitioned += 1
        return transitioned

    def _serve(self) -> None:
        while not self._stop.wait(self.interval):
            self.sweep_once()

    def _needs_reap(self, run: OptimizationRun, now: float) -> bool:
        if run.status not in {"created", "running"}:
            return False
        age = now - float(run.updated_at)
        return age >= self.stale_after

    def _has_live_process(self, run: OptimizationRun) -> bool:
        if not self.stats.process_support:
            return False
        meta = run.meta if isinstance(run.meta, dict) else {}
        roots: list[str] = []
        runtime_root = meta.get("runtime_root")
        storage_root = meta.get("storage_root")
        if runtime_root is not None:
            roots.append(str(runtime_root))
        if storage_root is not None:
            storage_str = str(storage_root)
            if storage_str not in roots:
                roots.append(storage_str)
        for root in roots:
            try:
                if self.stats.collect_processes(root=root):
                    return True
            except Exception:
                continue
        return False


class MonitoringService:
    """Own the monitor registry, event socket listener, and system stats."""

    def __init__(
        self,
        *,
        registry_path: Path | None = None,
        event_socket: Path | None = None,
        storage_roots: Iterable[Path] | None = None,
        poll_interval: float = 5.0,
        stats_collector: SystemStatsCollector | None = None,
        stale_after: float = 180.0,
        stale_interval: float = 30.0,
    ) -> None:
        """Initialize registry, listener config, and stats collector.

        Args:
            registry_path: Optional path for the run registry JSON.
            event_socket: Optional UNIX socket path for event ingestion.
            storage_roots: Optional storage roots to inventory for jobs.
            poll_interval: Seconds between inventory refreshes.
            stats_collector: Custom collector; defaults to ``SystemStatsCollector``.
            stale_after: Seconds before an active run with no process is marked unknown.
            stale_interval: Seconds between stale-run sweeps.
        """
        self.registry = RunRegistry(registry_path or default_registry_path())
        self.event_socket = Path(event_socket or default_socket_path())
        self.inventory = (
            StorageInventory(storage_roots, poll_interval=poll_interval)
            if storage_roots
            else None
        )
        self.stats = stats_collector or SystemStatsCollector()
        self._reaper = _StaleRunReaper(
            self.registry,
            self.stats,
            stale_after=stale_after,
            interval=stale_interval,
        )
        self._listener: EventSocketListener | None = None
        self._lock = threading.Lock()

    def start(self) -> None:
        """Start the event listener if configured and not already running."""
        with self._lock:
            if self._listener is not None:
                return
            listener = EventSocketListener(self.event_socket, self.registry)
            listener.start()
            self._listener = listener
            self._reaper.start()

    def stop(self) -> None:
        """Stop the event listener if it is running."""
        with self._lock:
            listener = self._listener
            self._listener = None
        if listener is not None:
            listener.stop()
        self._reaper.stop()

    @property
    def running(self) -> bool:
        """Return True when the event listener is active."""
        return self._listener is not None


__all__ = ["MonitoringService"]
