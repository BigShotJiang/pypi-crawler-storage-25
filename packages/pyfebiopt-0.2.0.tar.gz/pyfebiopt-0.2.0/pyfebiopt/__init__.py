"""Python tools for FEBio optimization and postprocessing workflows.

The package is organized around three main areas:

``pyfebiopt.xplt``
    Read FEBio ``.xplt`` result files, inspect dictionaries and mesh metadata, and
    slice nodal, element, face, and regional result arrays.

``pyfebiopt.visualization``
    Build PyVista-ready datasets from pyFEBiOpt meshes and attach result arrays for
    postprocessing and figure generation.

``pyfebiopt.optimize``
    Bind SciPy optimizers to FEBio simulations through templates, parameter spaces,
    simulation cases, adapters, storage, reporting, and monitoring.

Common imports:

.. code-block:: python

   from pyfebiopt.xplt import xplt
   from pyfebiopt.visualization import PVBridge
   from pyfebiopt import optimize as opt

For most optimization scripts, start with ``pyfebiopt.optimize`` and use ``xplt``
inside a ``SimulationAdapter`` to read the FEBio output produced at each
iteration. For standalone postprocessing, start with ``xplt`` and optionally pass
``xp.mesh`` to ``PVBridge`` for plotting.
"""

from __future__ import annotations

from pyfebiopt.xplt import xplt

from ._version import __version__

__all__ = ["__version__", "xplt"]
