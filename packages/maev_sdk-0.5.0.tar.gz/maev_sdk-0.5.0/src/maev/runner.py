"""AgentRun context and the maev.run() execution wrapper.

This is the core of the Maev SDK. maev.run(agent) wraps any callable agent
with observability, self-healing (retries, fallbacks, circuit breakers, loop
detection), and self-improving (records outcomes, applies learned strategies).

No proxy. No gateway. All in-process via SDK patching.
"""

from __future__ import annotations

import atexit
import contextvars
import inspect
import sys
import threading
import time
import uuid
from collections import deque
from functools import wraps
from typing import Any, Callable, Deque, Dict, List, Optional

from maev.types import InterventionRecord, RunConfig

# ---------------------------------------------------------------------------
# ContextVar — active AgentRun for the current async task or thread.
#
# ContextVar propagates correctly into asyncio tasks (create_task, gather).
# For OS threads (ThreadPoolExecutor, threading.Thread), we fall back to a
# thread-local so interceptors still find the run even in worker threads.
# ---------------------------------------------------------------------------

_current_run: contextvars.ContextVar[Optional["AgentRun"]] = contextvars.ContextVar(
    "maev_current_run", default=None
)
_thread_local = threading.local()


def get_current_run() -> Optional["AgentRun"]:
    """Return the AgentRun active in the current context, or None.

    Checks ContextVar first (asyncio / main thread), falls back to
    thread-local (OS threads spawned inside the agent).
    """
    run = _current_run.get()
    if run is not None:
        return run
    return getattr(_thread_local, "current_run", None)


def _set_thread_local_run(run: Optional["AgentRun"]) -> None:
    _thread_local.current_run = run


class AgentRun:
    """Execution context for a single maev.run() call."""

    def __init__(self, config: RunConfig) -> None:
        self.run_id = str(uuid.uuid4())
        self.config = config
        self.started_at = time.time()

        # Live counters
        self.cost_accumulated: float = 0.0
        self.call_count: int = 0
        self.interventions_applied: int = 0

        # Loop detection: rolling window of recent prompt hashes
        self.prompt_hashes: Deque[str] = deque(maxlen=20)

        # Buffered records — flushed async at run end
        self._interventions: List[InterventionRecord] = []

        # ContextVar token so we can restore on exit
        self._token: Optional[contextvars.Token] = None

    def __enter__(self) -> "AgentRun":
        self._token = _current_run.set(self)
        _set_thread_local_run(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self._token is not None:
            _current_run.reset(self._token)
        _set_thread_local_run(None)

    def record_intervention(
        self,
        type: str,
        trigger: str,
        strategy: str,
        outcome: str,
        metadata: Optional[Dict[str, Any]] = None,
        latency_ms: int = 0,
    ) -> None:
        """Buffer an intervention record for async flush."""
        self.interventions_applied += 1
        self._interventions.append(
            InterventionRecord(
                run_id=self.run_id,
                org_id="",   # filled in by backend via API key lookup
                type=type,
                trigger=trigger,
                strategy=strategy,
                outcome=outcome,
                latency_ms=latency_ms,
                metadata=metadata or {},
            )
        )

    def add_cost(self, amount: float) -> None:
        self.cost_accumulated += amount

    def increment_calls(self) -> None:
        self.call_count += 1

    @property
    def duration_ms(self) -> int:
        return int((time.time() - self.started_at) * 1000)


def _resolve_config(
    api_key: Optional[str],
    agent_name: Optional[str],
    endpoint: str,
    gateway: "bool | str",
    cost_budget: float,
    max_calls: int,
    max_duration_s: float,
    fallback_models: List[str],
    agent: Any = None,
) -> RunConfig:
    import os
    resolved_key = api_key or os.environ.get("MAEV_API_KEY", "")
    if not resolved_key or not resolved_key.startswith("vl_"):
        raise ValueError(
            "Maev API key required. Pass api_key='vl_xxx' or set the MAEV_API_KEY "
            "environment variable.\nGet your key at https://home.maev.dev/dashboard/settings"
        )
    resolved_name = (
        agent_name
        or os.environ.get("MAEV_AGENT_NAME")
        or (agent and _detect_agent_name(agent))
        or "agent"
    )
    return RunConfig(
        api_key=resolved_key,
        agent_name=resolved_name,
        endpoint=endpoint.rstrip("/"),
        gateway_url=_resolve_gateway_url(gateway),
        cost_budget=cost_budget,
        max_calls=max_calls,
        max_duration_s=max_duration_s,
        fallback_models=fallback_models,
    )


def _resolve_gateway_url(gateway: "bool | str") -> Optional[str]:
    """Normalise the gateway= kwarg to a base URL string, or None."""
    if not gateway:
        return None
    if isinstance(gateway, str):
        return gateway.rstrip("/")
    return "https://gateway.maev.dev"


_last_config: Optional["RunConfig"] = None
_flush_called = False


def flush() -> None:
    """Force delivery of buffered telemetry. Required in serverless environments."""
    global _flush_called  # noqa: PLW0603
    if _flush_called:
        return
    _flush_called = True

    # Force the OTel OTLP exporter to drain
    try:
        from opentelemetry import trace
        provider = trace.get_tracer_provider()
        if hasattr(provider, "force_flush"):
            provider.force_flush(timeout_millis=5000)
    except Exception:  # noqa: BLE001
        pass


def run(
    agent: Any,
    /,
    *args: Any,
    api_key: Optional[str] = None,
    agent_name: Optional[str] = None,
    endpoint: str = "https://home.maev.dev",
    cost_budget: float = 1.0,
    max_calls: int = 50,
    max_duration_s: float = 300.0,
    fallback_models: Optional[List[str]] = None,
    gateway: "bool | str" = False,
    **kwargs: Any,
) -> Any:
    """Wrap an agent callable with observability, self-healing, and self-improving.

    Args:
        gateway: Enable the self-improving proxy gateway.
                 True         → use https://gateway.maev.dev (Maev cloud)
                 "<url>"      → use a custom / self-hosted gateway URL
                 False        → SDK-only mode (default, existing behaviour)
    """
    config = _resolve_config(
        api_key, agent_name, endpoint, gateway, cost_budget, max_calls, max_duration_s,
        fallback_models or [], agent,
    )

    _ensure_initialized(config)
    _patch_all(config, gateway=gateway)

    if not callable(agent) or (not args and not kwargs and _is_agent_object(agent)):
        _patch_agent_object(agent, config)
        return agent

    return _execute(agent, args, kwargs, config)


def _execute(fn: Callable, args: tuple, kwargs: dict, config: RunConfig) -> Any:
    """Execute fn inside an AgentRun context with full protection."""
    from maev.interceptors.circuit import CircuitBrokenError

    agent_run = AgentRun(config)

    with agent_run:
        try:
            if inspect.iscoroutinefunction(fn):
                import asyncio
                result = asyncio.get_event_loop().run_until_complete(
                    _execute_async_inner(fn, args, kwargs)
                )
            else:
                result = fn(*args, **kwargs)
            _flush_run(agent_run, status="completed")
            return result
        except CircuitBrokenError as exc:
            agent_run.record_intervention(
                type="circuit_breaker",
                trigger=str(exc),
                strategy="halt_run",
                outcome="circuit_broken",
            )
            _flush_run(agent_run, status="circuit_broken")
            raise
        except Exception as exc:
            agent_run.record_intervention(
                type="run_error",
                trigger=type(exc).__name__,
                strategy="halt_run",
                outcome="failed",
                metadata={"error": str(exc)[:200]},
            )
            _flush_run(agent_run, status="failed")
            raise


async def _execute_async_inner(fn: Callable, args: tuple, kwargs: dict) -> Any:
    """Run an async agent function — ContextVar already set by _execute."""
    return await fn(*args, **kwargs)


def _is_agent_object(obj: Any) -> bool:
    """Return True if obj looks like an agent framework object."""
    for method in ("kickoff", "invoke", "run", "execute", "chat"):
        if callable(getattr(obj, method, None)):
            return True
    return False


def _patch_agent_object(agent: Any, config: RunConfig) -> None:
    """Wrap ALL execution methods on an agent object in-place.

    Previously used `break` after the first match — this meant CrewAI's
    .kickoff() was never wrapped if .run() matched first. Now we wrap
    every matching method.
    """
    for method_name in ("kickoff", "invoke", "run", "execute", "chat"):
        original = getattr(agent, method_name, None)
        if not callable(original):
            continue
        if getattr(original, "__maev_patched__", False):
            continue

        def _make_wrapper(orig: Callable, cfg: RunConfig) -> Callable:
            if inspect.iscoroutinefunction(orig):
                @wraps(orig)
                async def _async_wrapper(*a, **kw):
                    return await _execute_async(orig, a, kw, cfg)
                _async_wrapper.__maev_patched__ = True  # type: ignore[attr-defined]
                return _async_wrapper
            else:
                @wraps(orig)
                def _sync_wrapper(*a, **kw):
                    return _execute(orig, a, kw, cfg)
                _sync_wrapper.__maev_patched__ = True  # type: ignore[attr-defined]
                return _sync_wrapper

        try:
            setattr(agent, method_name, _make_wrapper(original, config))
        except (AttributeError, TypeError):
            pass


async def _execute_async(fn: Callable, args: tuple, kwargs: dict, config: RunConfig) -> Any:
    """Async version of _execute."""
    from maev.interceptors.circuit import CircuitBrokenError

    agent_run = AgentRun(config)

    with agent_run:
        try:
            result = await fn(*args, **kwargs)
            _flush_run(agent_run, status="completed")
            return result
        except CircuitBrokenError as exc:
            agent_run.record_intervention(
                type="circuit_breaker",
                trigger=str(exc),
                strategy="halt_run",
                outcome="circuit_broken",
            )
            _flush_run(agent_run, status="circuit_broken")
            raise
        except Exception as exc:
            agent_run.record_intervention(
                type="run_error",
                trigger=type(exc).__name__,
                strategy="halt_run",
                outcome="failed",
                metadata={"error": str(exc)[:200]},
            )
            _flush_run(agent_run, status="failed")
            raise


def _flush_run(agent_run: AgentRun, status: str) -> None:
    """Flush run data — use non-daemon thread so it survives fast process exit."""
    t = threading.Thread(
        target=_send_run_data,
        args=(agent_run, status),
        daemon=False,   # non-daemon: completes even if main thread exits
    )
    t.start()
    # Register atexit join so short-lived scripts wait for this flush
    atexit.register(_join_thread, t)


def _join_thread(t: threading.Thread) -> None:
    """Wait up to 5s for a flush thread to complete."""
    try:
        t.join(timeout=5.0)
    except Exception:  # noqa: BLE001
        pass


def _send_run_data(agent_run: AgentRun, status: str) -> None:
    """Send run summary and interventions to the Maev backend."""
    import json
    import urllib.request

    endpoint = agent_run.config.endpoint
    api_key = agent_run.config.api_key

    payload = {
        "run_id": agent_run.run_id,
        "agent_name": agent_run.config.agent_name,
        "status": status,
        "cost_budget": agent_run.config.cost_budget,
        "cost_actual": agent_run.cost_accumulated,
        "call_count": agent_run.call_count,
        "interventions_applied": agent_run.interventions_applied,
        "duration_ms": agent_run.duration_ms,
        "interventions": [
            {
                "type": iv.type,
                "trigger": iv.trigger,
                "strategy": iv.strategy,
                "outcome": iv.outcome,
                "latency_ms": iv.latency_ms,
                "metadata": iv.metadata,
            }
            for iv in agent_run._interventions
        ],
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{endpoint}/api/autopilot/runs",
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
            },
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5.0)
    except Exception as exc:  # noqa: BLE001
        print(f"[maev] Run flush failed (non-fatal): {exc}", file=sys.stderr)


def _detect_agent_name(agent: Any) -> str:
    """Auto-detect a human-readable name from the agent object."""
    cls_name = getattr(type(agent), "__name__", None)
    if cls_name and cls_name not in ("function", "method"):
        return cls_name

    fn_name = getattr(agent, "__name__", None)
    if fn_name:
        return fn_name

    module = getattr(agent, "__module__", None)
    if module and module != "__main__":
        return module.split(".")[-1]

    return "agent"


# ---------------------------------------------------------------------------
# OpenLIT initialization (idempotent)
# ---------------------------------------------------------------------------

_openlit_started = False
_openlit_lock: Any = None


def _ensure_initialized(config: RunConfig) -> None:
    """Start OpenLIT telemetry and fetch strategies if not already running."""
    global _openlit_started, _openlit_lock  # noqa: PLW0603

    if _openlit_lock is None:
        _openlit_lock = threading.Lock()

    with _openlit_lock:
        if _openlit_started:
            return

        try:
            import openlit  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(
                "maev requires 'openlit'. Install with: pip install maev-sdk"
            ) from exc

        session_id = str(uuid.uuid4())

        init_kwargs: dict = {
            "otlp_endpoint": f"{config.endpoint}/api/ingest/otlp",
            "otlp_headers": f"x-api-key={config.api_key}",
            "environment": "production",
            "application_name": config.agent_name,
            "collect_gpu_stats": False,
        }
        # session_id was removed in openlit >=1.34 — pass it only if supported
        if "session_id" in inspect.signature(openlit.init).parameters:
            init_kwargs["session_id"] = session_id
        openlit.init(**init_kwargs)
        _openlit_started = True

        # Kick off background strategy fetch (non-blocking)
        from maev.learning.store import load as _load_strategies
        _load_strategies(config)


# ---------------------------------------------------------------------------
# SDK patching — all providers (idempotent)
# ---------------------------------------------------------------------------

_patches_applied = False
_patch_lock: Any = None


def _patch_all(config: RunConfig, gateway: "bool | str" = False) -> None:
    """Apply all SDK patches (idempotent)."""
    global _patches_applied, _patch_lock  # noqa: PLW0603

    if _patch_lock is None:
        _patch_lock = threading.Lock()

    with _patch_lock:
        if _patches_applied:
            return
        from maev.patches import apply_all
        apply_all(config, gateway=gateway)
        _patches_applied = True
