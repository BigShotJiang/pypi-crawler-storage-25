"""Core types for the Maev SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class RunConfig:
    """Configuration for a maev.run() execution."""

    api_key: str
    agent_name: str
    endpoint: str
    gateway_url: Optional[str] = None
    cost_budget: float = 1.0          # max $ per run before circuit break
    max_calls: int = 50               # max LLM calls per run
    max_duration_s: float = 300.0     # max wall-clock seconds per run
    fallback_models: List[str] = field(default_factory=list)
    enable_learning: bool = True       # record outcomes for strategy learning


@dataclass
class CallRecord:
    """A single LLM call record — the atom of the learning loop."""

    run_id: str
    agent_id: str
    org_id: str
    prompt_hash: str
    prompt_length: int
    model: str
    tool_count: int
    turn_number: int
    status: str                        # "success" | "failed"
    failure_type: Optional[str]
    latency_ms: int
    cost_usd: float
    recovery_strategy: Optional[str]
    recovery_outcome: Optional[str]    # "success" | "failure" | None
    winning_params: Optional[Dict[str, Any]]


@dataclass
class Strategy:
    """A learned recovery strategy for a specific failure pattern."""

    failure_type: str
    model: str
    prompt_length_bucket: str          # "short" | "medium" | "long" | "huge"
    strategy: str                      # e.g. "temp_increase", "model_fallback"
    params: Dict[str, Any]
    win_rate: float
    sample_count: int
    confidence: float
    scope: str                         # "agent" | "org" | "global"


@dataclass
class InterventionRecord:
    """An intervention applied during a run."""

    run_id: str
    org_id: str
    type: str                          # "retry" | "fallback" | "circuit_break" | "loop_break" | "strategy_apply"
    trigger: str                       # what caused it
    strategy: str                      # what was done
    outcome: str                       # "success" | "failure"
    latency_ms: int
    metadata: Dict[str, Any] = field(default_factory=dict)
