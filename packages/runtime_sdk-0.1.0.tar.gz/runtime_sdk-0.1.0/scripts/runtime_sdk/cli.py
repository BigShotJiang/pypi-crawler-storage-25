from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from runtime_sdk.client import RuntimeAPIError, RuntimeClient
from runtime_sdk.config import DEFAULT_BASE_URL, PendingSignup, RuntimeConfig, load_config, save_config


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="runtime")
    parser.add_argument("--base-url", help="Runtime API base URL")

    subparsers = parser.add_subparsers(dest="command", required=True)

    signup = subparsers.add_parser("signup")
    signup.add_argument("email")
    signup.add_argument("--name", required=True)

    verify = subparsers.add_parser("verify")
    verify.add_argument("code")
    verify.add_argument("--flow-id", type=int)

    login = subparsers.add_parser("login")
    login.add_argument("api_key")

    subparsers.add_parser("whoami")
    subparsers.add_parser("logout")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        config = load_config()
        base_url = args.base_url or os.environ.get("RUNTIME_BASE_URL") or config.base_url or DEFAULT_BASE_URL
        config.base_url = base_url

        if args.command == "signup":
            return handle_signup(config, args.email, args.name)
        if args.command == "verify":
            return handle_verify(config, args.code, args.flow_id)
        if args.command == "login":
            return handle_login(config, args.api_key)
        if args.command == "whoami":
            return handle_whoami(config)
        if args.command == "logout":
            return handle_logout(config)
    except RuntimeAPIError as exc:
        return write_json({"success": False, "error": str(exc), "status_code": exc.status_code}, error=True)

    return write_json({"success": False, "error": "unknown command"}, error=True)


def handle_signup(config: RuntimeConfig, email: str, name: str) -> int:
    client = RuntimeClient(base_url=config.base_url)
    result = client.signup(email, name)
    config.pending_signup = PendingSignup(
        flow_id=int(result["flow_id"]),
        email=email,
        expires_at=result.get("expires_at"),
    )
    save_config(config)
    return write_json({"success": True, **result})


def handle_verify(config: RuntimeConfig, code: str, flow_id: int | None) -> int:
    pending = config.pending_signup
    resolved_flow_id = flow_id or (pending.flow_id if pending else None)
    if not resolved_flow_id:
        return write_json(
            {"success": False, "error": "missing flow id; run signup first or pass --flow-id"},
            error=True,
        )

    client = RuntimeClient(base_url=config.base_url)
    result = client.verify(resolved_flow_id, code)
    api_key = result.get("api_key")
    if api_key:
        config.api_key = api_key
    config.pending_signup = None
    save_config(config)
    return write_json({"success": True, **result})


def handle_login(config: RuntimeConfig, api_key: str) -> int:
    config.api_key = api_key
    save_config(config)
    return write_json({"success": True, "message": "api key saved"})


def handle_whoami(config: RuntimeConfig) -> int:
    if not config.api_key:
        return write_json({"success": False, "error": "missing api key; run verify or login first"}, error=True)

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.whoami()
    return write_json({"success": True, **result})


def handle_logout(config: RuntimeConfig) -> int:
    config.api_key = None
    config.pending_signup = None
    save_config(config)
    return write_json({"success": True, "message": "logged out"})


def write_json(payload: dict[str, Any], *, error: bool = False) -> int:
    stream = sys.stderr if error else sys.stdout
    stream.write(json.dumps(payload) + "\n")
    return 1 if error else 0


if __name__ == "__main__":
    raise SystemExit(main())
