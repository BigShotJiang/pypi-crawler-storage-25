from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class RuntimeAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(slots=True)
class RuntimeClient:
    base_url: str
    api_key: str | None = None
    timeout: float = 10.0
    transport: httpx.BaseTransport | None = None

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    def signup(self, email: str, name: str) -> dict[str, Any]:
        return self._request("POST", "/api/auth/start", json={"email": email, "name": name})

    def verify(self, flow_id: int, code: str) -> dict[str, Any]:
        return self._request("POST", "/api/auth/verify", json={"flow_id": flow_id, "code": code})

    def whoami(self) -> dict[str, Any]:
        return self._request("GET", "/api/auth/whoami", auth_required=True)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        auth_required: bool = False,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if auth_required:
            if not self.api_key:
                raise RuntimeAPIError("missing api key")
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            with httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout,
                transport=self.transport,
            ) as client:
                response = client.request(method, path, json=json, headers=headers)
        except httpx.HTTPError as exc:
            raise RuntimeAPIError(f"request failed: {exc}") from exc

        payload = self._decode_response(response)
        if response.is_success:
            return payload

        message = payload.get("error") or payload.get("message") or f"http {response.status_code}"
        raise RuntimeAPIError(str(message), status_code=response.status_code)

    @staticmethod
    def _decode_response(response: httpx.Response) -> dict[str, Any]:
        if not response.content:
            return {}
        try:
            decoded = response.json()
        except ValueError as exc:
            raise RuntimeAPIError("server returned invalid JSON", status_code=response.status_code) from exc

        if not isinstance(decoded, dict):
            raise RuntimeAPIError("server returned non-object JSON", status_code=response.status_code)
        return decoded
