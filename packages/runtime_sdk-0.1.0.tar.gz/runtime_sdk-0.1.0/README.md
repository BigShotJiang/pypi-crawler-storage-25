# runtime-sdk

Python SDK and CLI for Runtime.

## Install

```bash
uv tool install runtime-sdk
```

## Configure

The CLI talks to `http://127.0.0.1:8080` by default. Override it with:

```bash
export RUNTIME_BASE_URL=https://runruntime.dev
```

Or pass `--base-url` per command.

## Usage

```bash
runtime signup you@example.com --name "Your Name"
runtime verify 123456
runtime whoami
runtime logout
```

## Python

```python
from runtime_sdk import RuntimeClient

client = RuntimeClient(base_url="https://runruntime.dev")
result = client.signup("you@example.com", "Your Name")
print(result["flow_id"])
```
