from __future__ import annotations

from typing import TYPE_CHECKING

from deltona.commands.git import (
    git_checkout_default_branch_main,
    git_open_main,
    git_rebase_default_branch_main,
    merge_dependabot_prs_main,
    merge_pre_commit_ci_prs_main,
)
from deltona.git import DependabotMergeError, PreCommitCIMergeError

if TYPE_CHECKING:
    from click.testing import CliRunner
    from pytest_mock import MockerFixture


def test_git_checkout_default_branch_success(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_repo = mocker.patch('deltona.commands.git._get_git_repo')
    mocker.patch('keyring.get_password', return_value='dummy_token')
    mock_get_gh_default_branch = mocker.patch('deltona.commands.git.get_github_default_branch')
    mock_get_gh_default_branch.return_value = 'main'
    mock_checkout = mocker.Mock()
    mock_head = mocker.Mock(checkout=mock_checkout)
    mock_head.name = 'main'
    mock_repo.return_value.heads = [mock_head]

    result = runner.invoke(git_checkout_default_branch_main)
    assert result.exit_code == 0
    mock_get_gh_default_branch.assert_called_once()
    mock_checkout.assert_called_once()


def test_git_checkout_default_branch_no_token(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_repo = mocker.patch('deltona.commands.git._get_git_repo')
    mocker.patch('keyring.get_password', return_value=None)
    mock_get_gh_default_branch = mocker.patch('deltona.commands.git.get_github_default_branch')
    mock_checkout = mocker.Mock()
    mock_head = mocker.Mock(checkout=mock_checkout)
    mock_head.name = 'main'
    mock_repo.return_value.heads = [mock_head]

    result = runner.invoke(git_checkout_default_branch_main)
    assert result.exit_code != 0
    mock_get_gh_default_branch.assert_not_called()
    mock_checkout.assert_not_called()


def test_git_rebase_default_branch_success(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_repo = mocker.patch('deltona.commands.git._get_git_repo')
    mocker.patch('keyring.get_password', return_value='dummy_token')
    mock_get_gh_default_branch = mocker.patch('deltona.commands.git.get_github_default_branch')
    mock_get_gh_default_branch.return_value = 'main'

    result = runner.invoke(git_rebase_default_branch_main, ['--remote'])
    assert result.exit_code == 0
    mock_get_gh_default_branch.assert_called_once()
    mock_repo.return_value.git.rebase.assert_called_once_with('origin/main')


def test_git_rebase_default_branch_no_token(mocker: MockerFixture, runner: CliRunner) -> None:
    mocker.patch('keyring.get_password', return_value=None)
    mock_get_gh_default_branch = mocker.patch('deltona.commands.git.get_github_default_branch')

    result = runner.invoke(git_rebase_default_branch_main)
    assert result.exit_code != 0
    mock_get_gh_default_branch.assert_not_called()


def test_git_open_main(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_open = mocker.patch('deltona.commands.git.webbrowser.open')
    mock_repo = mocker.patch('deltona.commands.git._get_git_repo')
    mock_repo.return_value.remote.return_value.url = 'https://something'

    result = runner.invoke(git_open_main)
    assert result.exit_code == 0
    mock_open.assert_called_once_with('https://something')


def test_git_open_main_convert_ssh(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_open = mocker.patch('deltona.commands.git.webbrowser.open')
    mock_repo = mocker.patch('deltona.commands.git._get_git_repo')
    mock_repo.return_value.remote.return_value.url = 'git@git.whatever.com:something.git'
    result = runner.invoke(git_open_main)
    assert result.exit_code == 0
    mock_open.assert_called_once_with('https://git.whatever.com/something')


def test_merge_dependabot_prs_main(mocker: MockerFixture, runner: CliRunner) -> None:
    failure = DependabotMergeError({'tatsh/alpha': 2, 'tatsh/beta': 1})
    mock_merge = mocker.patch('deltona.commands.git.merge_dependabot_pull_requests',
                              new_callable=mocker.AsyncMock,
                              side_effect=[failure, None])
    mock_sleep = mocker.patch('deltona.commands.git.sleep')
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_dependabot_prs_main)
    assert result.exit_code == 0
    assert mock_merge.call_count == 2
    assert mock_sleep.call_count == 1
    assert 'Repositories with remaining Dependabot pull requests:' in result.output
    assert 'tatsh/alpha: 2 pull request(s)' in result.output
    assert 'tatsh/beta: 1 pull request(s)' in result.output
    assert result.output.index('tatsh/alpha') < result.output.index('tatsh/beta')
    first_kwargs = mock_merge.call_args_list[0].kwargs
    second_kwargs = mock_merge.call_args_list[1].kwargs
    assert first_kwargs['repos'] is None
    assert second_kwargs['repos'] == ('tatsh/alpha', 'tatsh/beta')


def test_merge_dependabot_prs_main_retries_only_remaining_repos(mocker: MockerFixture,
                                                                runner: CliRunner) -> None:
    failure = DependabotMergeError({'tatsh/beta': 1})
    mock_merge = mocker.patch('deltona.commands.git.merge_dependabot_pull_requests',
                              new_callable=mocker.AsyncMock,
                              side_effect=[failure, None])
    mocker.patch('deltona.commands.git.sleep')
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_dependabot_prs_main,
                           ['-r', 'tatsh/alpha', '-r', 'tatsh/beta', '-r', 'tatsh/gamma'])
    assert result.exit_code == 0
    assert mock_merge.call_count == 2
    assert mock_merge.call_args_list[0].kwargs['repos'] == ('tatsh/alpha', 'tatsh/beta',
                                                            'tatsh/gamma')
    assert mock_merge.call_args_list[1].kwargs['repos'] == ('tatsh/beta',)


def test_merge_dependabot_prs_main_forwards_concurrency_options(mocker: MockerFixture,
                                                                runner: CliRunner) -> None:
    mock_merge = mocker.patch('deltona.commands.git.merge_dependabot_pull_requests',
                              new_callable=mocker.AsyncMock,
                              return_value=None)
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_dependabot_prs_main,
                           ['--concurrency', '7', '--max-concurrent-http-requests', '5'])
    assert result.exit_code == 0
    mock_merge.assert_called_once_with(base_url=None,
                                       concurrency=7,
                                       max_concurrent_http_requests=5,
                                       repos=None,
                                       token='dummy_token')


def test_merge_dependabot_prs_main_forwards_repos(mocker: MockerFixture, runner: CliRunner) -> None:
    mock_merge = mocker.patch('deltona.commands.git.merge_dependabot_pull_requests',
                              new_callable=mocker.AsyncMock,
                              return_value=None)
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_dependabot_prs_main, ['--repo', 'mine', '-r', 'tatsh/other'])
    assert result.exit_code == 0
    _, kwargs = mock_merge.call_args
    assert kwargs['repos'] == ('mine', 'tatsh/other')


def test_merge_dependabot_prs_main_no_token(mocker: MockerFixture, runner: CliRunner) -> None:
    mocker.patch('keyring.get_password', return_value=None)
    mock_get_gh_default_branch = mocker.patch('deltona.commands.git.get_github_default_branch')

    result = runner.invoke(merge_dependabot_prs_main)
    assert result.exit_code != 0
    mock_get_gh_default_branch.assert_not_called()


def test_merge_pre_commit_ci_prs_main(mocker: MockerFixture, runner: CliRunner) -> None:
    failure = PreCommitCIMergeError({'tatsh/alpha': 2, 'tatsh/beta': 1})
    mock_merge = mocker.patch('deltona.commands.git.merge_pre_commit_ci_pull_requests',
                              new_callable=mocker.AsyncMock,
                              side_effect=[failure, None])
    mock_sleep = mocker.patch('deltona.commands.git.sleep')
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_pre_commit_ci_prs_main)
    assert result.exit_code == 0
    assert mock_merge.call_count == 2
    assert mock_sleep.call_count == 1
    assert 'Repositories with remaining pre-commit.ci pull requests:' in result.output
    assert 'tatsh/alpha: 2 pull request(s)' in result.output
    assert 'tatsh/beta: 1 pull request(s)' in result.output
    assert mock_merge.call_args_list[0].kwargs['repos'] is None
    assert mock_merge.call_args_list[1].kwargs['repos'] == ('tatsh/alpha', 'tatsh/beta')


def test_merge_pre_commit_ci_prs_main_forwards_repos(mocker: MockerFixture,
                                                     runner: CliRunner) -> None:
    mock_merge = mocker.patch('deltona.commands.git.merge_pre_commit_ci_pull_requests',
                              new_callable=mocker.AsyncMock,
                              return_value=None)
    mocker.patch('keyring.get_password', return_value='dummy_token')

    result = runner.invoke(merge_pre_commit_ci_prs_main, ['--repo', 'mine', '-r', 'tatsh/other'])
    assert result.exit_code == 0
    _, kwargs = mock_merge.call_args
    assert kwargs['repos'] == ('mine', 'tatsh/other')


def test_merge_pre_commit_ci_prs_main_no_token(mocker: MockerFixture, runner: CliRunner) -> None:
    mocker.patch('keyring.get_password', return_value=None)
    result = runner.invoke(merge_pre_commit_ci_prs_main)
    assert result.exit_code != 0
