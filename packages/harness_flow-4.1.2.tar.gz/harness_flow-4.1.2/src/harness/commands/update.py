"""harness update — self-update, reinstall artifacts, and migrate config."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer
from rich.panel import Panel

from harness import __version__
from harness.core.ui import get_ui
from harness.i18n import t


def _get_latest_version() -> str | None:
    """Query PyPI for the latest harness-flow version."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "index", "versions", "harness-flow"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if "harness-flow" in line and "(" in line:
                    return line.split("(")[1].split(")")[0].strip()
    except Exception:
        pass
    return None


def _pip_upgrade() -> bool:
    """Run pip install --upgrade harness-flow."""
    console = get_ui().console
    console.print(f"  [cyber.magenta]▸[/] {t('update.upgrading')}")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "harness-flow"],
        capture_output=True, text=True, timeout=120,
    )
    if result.returncode == 0:
        console.print(f"  [cyber.green]✓[/] {t('update.upgrade_ok')}")
        return True
    console.print(f"  [cyber.fail]✗[/] {t('update.upgrade_fail')}")
    if result.stderr:
        for line in result.stderr.strip().splitlines()[-3:]:
            console.print(f"    [cyber.dim]{line}[/]")
    return False


def _migrate_config(project_root: Path) -> int:
    """Check .agents/config.toml for missing/deprecated keys. Returns count of warnings."""
    config_path = project_root / ".agents" / "config.toml"
    if not config_path.exists():
        return 0

    console = get_ui().console

    try:
        if sys.version_info >= (3, 11):
            import tomllib
        else:
            import tomli as tomllib
        data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    except Exception:
        console.print(f"  [cyber.warn]![/] {t('update.config_parse_error', path=str(config_path))}")
        return 1

    warnings = 0

    recommended_sections = {
        "project": "project name and language",
        "ci": "CI gate command",
        "workflow": "iteration and branch settings",
    }
    for section, desc in recommended_sections.items():
        if section not in data:
            console.print(
                f"  [cyber.dim]ℹ[/] {t('update.config_missing_section', section=section, desc=desc)}"
            )
            warnings += 1

    deprecated: list[tuple[str, str, str]] = []
    for old_key, replacement, since_version in deprecated:
        parts = old_key.split(".")
        section_data = data
        found = True
        for p in parts:
            if isinstance(section_data, dict) and p in section_data:
                section_data = section_data[p]
            else:
                found = False
                break
        if found:
            console.print(
                f"  [cyber.warn]![/] Deprecated key [cyber.cyan]{old_key}[/] "
                f"→ use [cyber.cyan]{replacement}[/] [cyber.dim](since {since_version})[/]"
            )
            warnings += 1

    if warnings == 0:
        console.print(f"  [cyber.green]✓[/] {t('update.config_ok')}")

    return warnings


def run_update(*, check: bool = False, force: bool = False) -> None:
    """Execute the harness update workflow."""
    project_root = Path.cwd()
    ui = get_ui()
    console = ui.console

    console.print()
    console.print(Panel(
        f"  [cyber.label]VERSION[/]  [cyber.cyan]{__version__}[/]",
        title="[cyber.header]HARNESS UPDATE[/]",
        border_style="cyber.border",
        padding=(0, 1),
    ))

    # Step 1: Check for new version
    console.print()
    console.print(f"  [cyber.magenta]▸[/] {t('update.checking')}")
    latest = _get_latest_version()

    upgraded = False
    pypi_unreachable = False

    if latest is None:
        console.print(f"  [cyber.warn]![/] {t('update.check_failed')}")
        pypi_unreachable = True
        if check:
            raise typer.Exit(1)
    elif latest == __version__:
        console.print(f"  [cyber.green]✓[/] {t('update.up_to_date')}")
        if check:
            raise typer.Exit(0)
    else:
        console.print(f"  [cyber.cyan]▸[/] {t('update.new_version', version=latest)}")
        if check:
            raise typer.Exit(0)
        if not _pip_upgrade():
            console.print(f"  [cyber.dim]{t('update.skip_reinstall')}[/]")
            raise typer.Exit(1)
        upgraded = True

    if check:
        raise typer.Exit(0)

    # Step 2: Reinstall agent definitions (only after upgrade or with --force)
    if upgraded or force:
        console.print()
        console.print(f"  [cyber.magenta]▸[/] {t('update.reinstall')}")
        from harness.native.skill_gen import generate_native_artifacts, resolve_native_lang
        resolved_lang = resolve_native_lang(project_root)
        try:
            from harness.core.config import HarnessConfig
            cfg = HarnessConfig.load(project_root)
        except Exception:
            cfg = None
        generate_native_artifacts(project_root, lang=resolved_lang, cfg=cfg, force=True)
    elif pypi_unreachable:
        console.print(
            f"  [cyber.warn]![/] {t('update.skip_reinstall_unreachable')}"
        )
    else:
        console.print(
            f"  [cyber.green]✓[/] {t('update.skip_reinstall_up_to_date')}"
        )

    # Step 3: Config migration (always runs as lightweight health check)
    console.print()
    console.print(f"  [cyber.magenta]▸[/] {t('update.migrate_title')}")
    warning_count = _migrate_config(project_root)

    console.print()
    status = "[cyber.green]✓[/] clean" if warning_count == 0 else f"[cyber.warn]{warning_count}[/] warning(s)"
    console.print(Panel(
        f"  Status: {status}",
        title="[cyber.header]UPDATE COMPLETE[/]",
        border_style="cyber.border",
        padding=(0, 1),
    ))
