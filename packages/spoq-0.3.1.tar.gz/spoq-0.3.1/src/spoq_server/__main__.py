"""Allow running with python -m spoq_server."""

from spoq_server.cli import main

main()
