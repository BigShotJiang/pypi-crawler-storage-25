"""SPOQ — Specialist Orchestrated Queuing for multi-agent AI development.

Provides:
  - MCP server with 24 tools for epic, map, and task management
  - CLI for project initialization, template generation, and server operation
  - Bundled epic_utils and map_utils for standalone use
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("spoq")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
