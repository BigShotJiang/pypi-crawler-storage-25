"""Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: set_speed_mode.py
"""

from __future__ import annotations

_UNSET = object()

from raccoon.step.step_builder import StepBuilder
from raccoon.step.condition import StopCondition
from raccoon.step.annotation import dsl
from .set_speed_mode import SetSpeedMode, _DEFAULT_ACK_TIMEOUT_S


class SetSpeedModeBuilder(StepBuilder):
    """Builder for SetSpeedMode. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._enabled = _UNSET
        self._timeout_s = _DEFAULT_ACK_TIMEOUT_S

    def enabled(self, value: bool):
        self._enabled = value
        return self

    def timeout_s(self, value: float):
        self._timeout_s = value
        return self

    def _build(self):
        kwargs = {}
        if self._enabled is not _UNSET:
            kwargs["enabled"] = self._enabled
        kwargs["timeout_s"] = self._timeout_s
        return SetSpeedMode(**kwargs)


@dsl(tags=["motion", "feature", "speed-mode"])
def set_speed_mode(enabled: bool = _UNSET, timeout_s: float = _DEFAULT_ACK_TIMEOUT_S):
    """
    Enable or disable SpeedMode (BEMF off / on) via an LCM handshake.

    SpeedMode disables the firmware's BEMF closed-loop measurements,
    granting ~10% additional top speed in exchange for cm precision.
    Once SpeedMode is active, every motion that has a distance- or
    angle-based goal will refuse to start — use ``until``-conditions
    (sensors, timeouts, light gates, ...) to terminate motions
    instead. Returning to normal mode restores BEMF and cm accuracy.

    The step publishes the command, waits for the firmware's ACK on
    the retained ``raccoon/feature/bemf_enabled`` channel, and only
    then updates the library's ``SpeedModeContext`` flag. If no ACK
    arrives within the timeout it raises so the program does not
    proceed with library / firmware state out of sync.

    Args:
        enabled: ``True`` to engage SpeedMode (BEMF off, 10% faster, no cm precision); ``False`` to return to normal closed-loop BEMF control.
        timeout_s: Maximum time in seconds to wait for the firmware ACK before raising ``RuntimeError``. Defaults to 0.5 s.

    Returns:
        A SetSpeedModeBuilder (chainable via ``.enabled()``, ``.timeout_s()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import set_speed_mode, drive_forward
        from raccoon.step.sensor import on_black

        set_speed_mode(True)
        drive_forward(speed=1.0).until(on_black(line_sensor))
        set_speed_mode(False)
    """
    b = SetSpeedModeBuilder()
    if enabled is not _UNSET:
        b._enabled = enabled
    b._timeout_s = timeout_s
    return b


__all__ = ['SetSpeedModeBuilder', 'set_speed_mode']
