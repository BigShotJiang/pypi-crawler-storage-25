"""Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: auto_tune.py
"""

from __future__ import annotations

_UNSET = object()

from raccoon.step.step_builder import StepBuilder
from raccoon.step.condition import StopCondition
from raccoon.step.annotation import dsl
from .auto_tune import AutoTuneVelLpf, AutoTuneStaticFriction, AutoTuneFirmwarePid, AutoTuneVelocity, AutoTuneMotion, AutoTune


class AutoTuneVelLpfBuilder(StepBuilder):
    """Builder for AutoTuneVelLpf. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._persist = True

    def persist(self, value: bool):
        self._persist = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["persist"] = self._persist
        return AutoTuneVelLpf(**kwargs)


@dsl(tags=["motion", "calibration", "auto-tune"])
def auto_tune_vel_lpf(persist: bool = True):
    """
    Tune the IIR velocity-filter alpha per motor (Phase 1).

    Collects raw BEMF samples at a steady velocity, replays them through IIR
    low-pass filters with varying alpha, and applies the alpha that minimises
    a weighted noise+lag score. Runs first in the full pipeline because every
    downstream phase relies on the same velocity-feedback filter.

    Args:
        persist: Write tuned ``vel_lpf_alpha`` values to ``raccoon.project.yml``. Default ``True``.

    Returns:
        A AutoTuneVelLpfBuilder (chainable via ``.persist()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune_vel_lpf

        auto_tune_vel_lpf()
    """
    b = AutoTuneVelLpfBuilder()
    b._persist = persist
    return b


class AutoTuneStaticFrictionBuilder(StepBuilder):
    """Builder for AutoTuneStaticFriction. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._persist = True

    def persist(self, value: bool):
        self._persist = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["persist"] = self._persist
        return AutoTuneStaticFriction(**kwargs)


@dsl(tags=["calibration", "auto-tune"])
def auto_tune_static_friction(persist: bool = True):
    """
    Measure per-motor static-friction threshold kS in PWM percent (Phase 2).

    For each drive motor the PWM is swept from a low starting percentage upward
    in both directions. The first PWM level where the median BEMF exceeds a
    motion threshold is recorded as kS.

    Args:
        persist: Reserved for future YAML persistence. Currently logs only.

    Returns:
        A AutoTuneStaticFrictionBuilder (chainable via ``.persist()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune_static_friction

        auto_tune_static_friction()
    """
    b = AutoTuneStaticFrictionBuilder()
    b._persist = persist
    return b


class AutoTuneFirmwarePidBuilder(StepBuilder):
    """Builder for AutoTuneFirmwarePid. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._persist = True
        self._max_bemf_speeds = None
        self._csv_dir = '/tmp/auto_tune'

    def persist(self, value: bool):
        self._persist = value
        return self

    def max_bemf_speeds(self, value: dict[int, int] | None):
        self._max_bemf_speeds = value
        return self

    def csv_dir(self, value: str | None):
        self._csv_dir = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["persist"] = self._persist
        kwargs["max_bemf_speeds"] = self._max_bemf_speeds
        kwargs["csv_dir"] = self._csv_dir
        return AutoTuneFirmwarePid(**kwargs)


@dsl(tags=["calibration", "auto-tune"])
def auto_tune_firmware_pid(persist: bool = True, max_bemf_speeds: dict[int, int] | None = None, csv_dir: str | None = '/tmp/auto_tune'):
    """
    Tune per-motor STM32 MAV-mode velocity PID via BEMF step response (Phase 3).

    For each drive motor: record a BEMF step response, fit a FOPDT plant,
    derive CHR PID gains, push them to the firmware. Gains are accepted only
    when the tuned ISE is strictly smaller than the baseline ISE.

    Args:
        persist: Unused — gains are applied directly to firmware state.
        max_bemf_speeds: Optional ``{port: max_bemf_speed}`` map. If unset, the C++ side runs a brief power sweep to estimate it.
        csv_dir: When set, every step-response sample is dumped to a CSV under this directory (one per motor + phase) plus a summary CSV with the plant fit and gains. Default ``"/tmp/auto_tune"``.

    Returns:
        A AutoTuneFirmwarePidBuilder (chainable via ``.persist()``, ``.max_bemf_speeds()``, ``.csv_dir()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune_firmware_pid

        auto_tune_firmware_pid()
    """
    b = AutoTuneFirmwarePidBuilder()
    b._persist = persist
    b._max_bemf_speeds = max_bemf_speeds
    b._csv_dir = csv_dir
    return b


class AutoTuneVelocityBuilder(StepBuilder):
    """Builder for AutoTuneVelocity. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._axes = None
        self._persist = True

    def axes(self, value: list[str] | None):
        self._axes = value
        return self

    def persist(self, value: bool):
        self._persist = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["axes"] = self._axes
        kwargs["persist"] = self._persist
        return AutoTuneVelocity(**kwargs)


@dsl(tags=["motion", "calibration", "auto-tune"])
def auto_tune_velocity(axes: list[str] | None = None, persist: bool = True):
    """
    Tune velocity controllers via step-response system identification (Phase 6).

    Records a baseline step response, fits a FOPDT plant model, derives CHR
    PID gains, applies them, then re-runs the step response to validate via
    ISE. The accepted gains are pushed to ``drive.set_velocity_control_config``
    immediately by the C++ tuner.

    Prerequisites: Phase 5 (drive characterization) should have run first so
    a max-velocity-per-axis is known. Phase 3 (firmware PID) should also have
    run so the inner loop is stable.

    Args:
        axes: Velocity axes to tune (``"vx"``, ``"vy"``, ``"wz"``). Default auto-detects from kinematics.
        persist: Write accepted gains to ``raccoon.project.yml``. Default ``True``.

    Returns:
        A AutoTuneVelocityBuilder (chainable via ``.axes()``, ``.persist()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune_velocity

        auto_tune_velocity()
        auto_tune_velocity(axes=["vx"])
    """
    b = AutoTuneVelocityBuilder()
    b._axes = axes
    b._persist = persist
    return b


class AutoTuneMotionBuilder(StepBuilder):
    """Builder for AutoTuneMotion. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._axes = None
        self._persist = True

    def axes(self, value: list[str] | None):
        self._axes = value
        return self

    def persist(self, value: bool):
        self._persist = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["axes"] = self._axes
        kwargs["persist"] = self._persist
        return AutoTuneMotion(**kwargs)


@dsl(tags=["motion", "calibration", "auto-tune"])
def auto_tune_motion(axes: list[str] | None = None, persist: bool = True):
    """
    Tune motion PID controllers via iterative real-world optimization (Phase 7).

    Uses Hooke-Jeeves coordinate descent on the distance/heading PID kp & kd
    via real LinearMotion and TurnMotion trials with constraint-aware scoring.

    Prerequisites: velocity controllers tuned (Phase 6) and drive limits
    characterized (Phase 5).

    Args:
        axes: Motion parameters to tune (``"distance"``, ``"lateral"``, ``"heading"``). Default auto-detects from kinematics.
        persist: Write final gains to ``raccoon.project.yml``. Default ``True``.

    Returns:
        A AutoTuneMotionBuilder (chainable via ``.axes()``, ``.persist()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune_motion

        auto_tune_motion()
        auto_tune_motion(axes=["heading"])
    """
    b = AutoTuneMotionBuilder()
    b._axes = axes
    b._persist = persist
    return b


class AutoTuneBuilder(StepBuilder):
    """Builder for AutoTune. Auto-generated — do not edit."""

    def __init__(self):
        super().__init__()
        self._vel_axes = None
        self._characterize_axes = None
        self._motion_axes = None
        self._tune_vel_lpf = True
        self._tune_static_friction = True
        self._tune_firmware_pid = False
        self._tune_encoder_cal = True
        self._tune_characterize = True
        self._tune_velocity = True
        self._tune_motion = True
        self._tune_tolerances = True
        self._characterize_trials = 3
        self._characterize_power_percent = 100
        self._persist = True
        self._step_confirm = True

    def vel_axes(self, value: list[str] | None):
        self._vel_axes = value
        return self

    def characterize_axes(self, value: list[str] | None):
        self._characterize_axes = value
        return self

    def motion_axes(self, value: list[str] | None):
        self._motion_axes = value
        return self

    def tune_vel_lpf(self, value: bool):
        self._tune_vel_lpf = value
        return self

    def tune_static_friction(self, value: bool):
        self._tune_static_friction = value
        return self

    def tune_firmware_pid(self, value: bool):
        self._tune_firmware_pid = value
        return self

    def tune_encoder_cal(self, value: bool):
        self._tune_encoder_cal = value
        return self

    def tune_characterize(self, value: bool):
        self._tune_characterize = value
        return self

    def tune_velocity(self, value: bool):
        self._tune_velocity = value
        return self

    def tune_motion(self, value: bool):
        self._tune_motion = value
        return self

    def tune_tolerances(self, value: bool):
        self._tune_tolerances = value
        return self

    def characterize_trials(self, value: int):
        self._characterize_trials = value
        return self

    def characterize_power_percent(self, value: int):
        self._characterize_power_percent = value
        return self

    def persist(self, value: bool):
        self._persist = value
        return self

    def step_confirm(self, value: bool):
        self._step_confirm = value
        return self

    def _build(self):
        kwargs = {}
        kwargs["vel_axes"] = self._vel_axes
        kwargs["characterize_axes"] = self._characterize_axes
        kwargs["motion_axes"] = self._motion_axes
        kwargs["tune_vel_lpf"] = self._tune_vel_lpf
        kwargs["tune_static_friction"] = self._tune_static_friction
        kwargs["tune_firmware_pid"] = self._tune_firmware_pid
        kwargs["tune_encoder_cal"] = self._tune_encoder_cal
        kwargs["tune_characterize"] = self._tune_characterize
        kwargs["tune_velocity"] = self._tune_velocity
        kwargs["tune_motion"] = self._tune_motion
        kwargs["tune_tolerances"] = self._tune_tolerances
        kwargs["characterize_trials"] = self._characterize_trials
        kwargs["characterize_power_percent"] = self._characterize_power_percent
        kwargs["persist"] = self._persist
        kwargs["step_confirm"] = self._step_confirm
        return AutoTune(**kwargs)


@dsl(tags=["motion", "calibration", "auto-tune"])
def auto_tune(vel_axes: list[str] | None = None, characterize_axes: list[str] | None = None, motion_axes: list[str] | None = None, tune_vel_lpf: bool = True, tune_static_friction: bool = True, tune_firmware_pid: bool = False, tune_encoder_cal: bool = True, tune_characterize: bool = True, tune_velocity: bool = True, tune_motion: bool = True, tune_tolerances: bool = True, characterize_trials: int = 3, characterize_power_percent: int = 100, persist: bool = True, step_confirm: bool = True):
    """
    Run the full auto-tune pipeline.

    Drives the C++ ``AutoTuner`` one phase at a time so UI confirmations can
    pause between phases. Each phase reads its inputs from the live drive /
    motors / motion-config objects and writes back to those same objects, so
    state stays coherent without Python having to shuttle calibration values.

    Phase order (each depends on the previous):

    1. vel_lpf — per-motor IIR alpha for velocity feedback
    2. static_friction — kS per motor
    3. firmware_pid — STM32 MAV-mode inner loop
    4. encoder_cal — ticks_to_rad scaling via IMU ground truth
    5. characterize — physical drive limits
    6. velocity — chassis-axis velocity PID
    7. motion — distance / heading PID
    8. tolerances — derived from motion-trial residuals

    Args:
        vel_axes: Override the auto-detected velocity axis list for Phase 6.
        characterize_axes: Override the auto-detected axis list for Phase 5.
        motion_axes: Override the auto-detected motion-parameter list for Phase 7.
        tune_vel_lpf: Enable Phase 1 (vel LPF alpha). Default ``True``.
        tune_static_friction: Enable Phase 2 (static friction). Default ``True``.
        tune_firmware_pid: Enable Phase 3 (firmware PID). Default ``False``.
        tune_encoder_cal: Enable Phase 4 (encoder calibration). Default ``True``.
        tune_characterize: Enable Phase 5 (drive characterization). Default ``True``.
        tune_velocity: Enable Phase 6 (velocity PID). Default ``True``.
        tune_motion: Enable Phase 7 (motion PID). Default ``True``.
        tune_tolerances: Enable Phase 8 (tolerance derivation). Default ``True``.
        characterize_trials: Number of Phase 5 trials per axis. Default ``3``.
        characterize_power_percent: Raw PWM for Phase 5 trials (1–100). Default ``100``.
        persist: Write phase results to ``raccoon.project.yml``. Default ``True``.
        step_confirm: Pause for a button press before every phase. Default ``True``.

    Returns:
        A AutoTuneBuilder (chainable via ``.vel_axes()``, ``.characterize_axes()``, ``.motion_axes()``, ``.tune_vel_lpf()``, ``.tune_static_friction()``, ``.tune_firmware_pid()``, ``.tune_encoder_cal()``, ``.tune_characterize()``, ``.tune_velocity()``, ``.tune_motion()``, ``.tune_tolerances()``, ``.characterize_trials()``, ``.characterize_power_percent()``, ``.persist()``, ``.step_confirm()``, ``.on_anomaly()``, ``.skip_timing()``).

    Example::

        from raccoon.step.motion import auto_tune

        auto_tune()
    """
    b = AutoTuneBuilder()
    b._vel_axes = vel_axes
    b._characterize_axes = characterize_axes
    b._motion_axes = motion_axes
    b._tune_vel_lpf = tune_vel_lpf
    b._tune_static_friction = tune_static_friction
    b._tune_firmware_pid = tune_firmware_pid
    b._tune_encoder_cal = tune_encoder_cal
    b._tune_characterize = tune_characterize
    b._tune_velocity = tune_velocity
    b._tune_motion = tune_motion
    b._tune_tolerances = tune_tolerances
    b._characterize_trials = characterize_trials
    b._characterize_power_percent = characterize_power_percent
    b._persist = persist
    b._step_confirm = step_confirm
    return b


__all__ = ['AutoTuneVelLpfBuilder', 'auto_tune_vel_lpf', 'AutoTuneStaticFrictionBuilder', 'auto_tune_static_friction', 'AutoTuneFirmwarePidBuilder', 'auto_tune_firmware_pid', 'AutoTuneVelocityBuilder', 'auto_tune_velocity', 'AutoTuneMotionBuilder', 'auto_tune_motion', 'AutoTuneBuilder', 'auto_tune']
