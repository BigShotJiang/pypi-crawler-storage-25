from __future__ import annotations

import asyncio
import contextlib
from asyncio import CancelledError

from .. import Step
from ..annotation import dsl_step
from ..resource import validate_no_overlap


@dsl_step(tags=["control", "concurrent"])
class DoWhileActive(Step):
    """Run a task concurrently with a reference step, cancelling the task when the reference finishes.

    Both steps start executing at the same time. When ``reference_step``
    completes (either normally or via exception), ``task`` is immediately
    cancelled. This is useful for running a background activity (e.g.
    sensor polling, motor oscillation) only for as long as a primary
    action is running.

    If ``task`` finishes before ``reference_step``, the reference step
    continues running until it completes on its own.

    Args:
        reference_step: The primary step whose lifetime controls the task.
            When this step finishes, ``task`` is cancelled.
        task: The secondary step that runs concurrently and is cancelled
            once ``reference_step`` completes.

    Example::

        from raccoon.step.logic import do_while_active, loop_forever

        # Flash an LED while the robot drives forward
        flash_led = loop_forever(
            seq(
                [
                    set_digital(0, True),
                    wait(0.25),
                    set_digital(0, False),
                    wait(0.25),
                ]
            )
        )
        do_while_active(drive_forward(50), flash_led)
    """

    def __init__(self, reference_step: Step, task: Step) -> None:
        super().__init__()
        from ..model import StepProtocol

        if not isinstance(reference_step, StepProtocol):
            msg = f"reference_step must be a Step, got {type(reference_step).__name__}"
            raise TypeError(msg)
        if not isinstance(task, StepProtocol):
            msg = f"task must be a Step, got {type(task).__name__}"
            raise TypeError(msg)
        self.reference_step = reference_step.resolve()
        self.task = task.resolve()

        # Pre-execution resource conflict check
        validate_no_overlap([self.reference_step, self.task], context="DoWhileActive")

    def collected_resources(self) -> frozenset[str]:
        return self.reference_step.collected_resources() | self.task.collected_resources()

    _composite = True

    def _generate_signature(self) -> str:
        return "DoWhileActive()"

    async def _execute_step(self, robot: "GenericRobot") -> None:
        reference_step = asyncio.create_task(self.reference_step.run_step(robot))
        task = asyncio.create_task(self.task.run_step(robot))

        await reference_step
        task.cancel()
        with contextlib.suppress(CancelledError):
            await task
