"""
Wait-for-light screens: calibration (legacy) and auto-detection.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..events import on_button_press, on_change, on_click
from ..screen import UIScreen
from ..widgets import (
    Button,
    Card,
    Center,
    Column,
    Container,
    HintBox,
    Icon,
    LightBulb,
    NumericInput,
    ResultsTable,
    Row,
    SensorGraph,
    SensorValue,
    Spacer,
    Split,
    StatusBadge,
    StatusIcon,
    Text,
    Widget,
)


@dataclass
class WFLMeasureResult:
    """Result from WFLMeasureScreen."""

    value: float


class WFLMeasureScreen(UIScreen[WFLMeasureResult]):
    """
    Measure light on or off state for wait-for-light calibration.

    Shows light bulb visualization and real-time sensor reading.
    Returns sensor value when button is pressed.
    """

    title = "Wait for Light Calibration"

    def __init__(self, port: int, is_on: bool):
        super().__init__()
        self.port = port
        self.is_on = is_on

    def build(self) -> Widget:
        return Split(
            left=[
                StatusBadge(
                    text="LIGHT ON" if self.is_on else "LIGHT OFF",
                    color="amber" if self.is_on else "grey",
                    glow=self.is_on,
                ),
                Spacer(12),
                LightBulb(is_on=self.is_on),
                Spacer(12),
                Text(f"Turn {'ON' if self.is_on else 'OFF'} the lamp", size="large"),
                Spacer(8),
                HintBox("Press button when ready"),
            ],
            right=[
                Card(
                    title="Sensor Value",
                    children=[
                        SensorValue(port=self.port),
                        Spacer(8),
                        SensorGraph(port=self.port),
                    ],
                ),
            ],
            ratio=(4, 3),
        )

    @on_button_press()
    async def on_press(self):
        value = await self.read_sensor(self.port)
        self.close(WFLMeasureResult(value=value))


@dataclass
class WFLConfirmResult:
    """Result from WFLConfirmScreen."""

    confirmed: bool
    light_off: float
    light_on: float

    @property
    def threshold(self) -> float:
        return (self.light_off + self.light_on) / 2


class WFLConfirmScreen(UIScreen[WFLConfirmResult]):
    """
    Confirm wait-for-light calibration values.

    Shows measured values (editable), threshold, and difference.
    User can confirm or retry.
    """

    title = "Wait for Light Calibration"
    _primary_button_id = "confirm"

    def __init__(self, port: int, light_off: float, light_on: float):
        super().__init__()
        self.port = port
        self.light_off = light_off
        self.light_on = light_on

    @property
    def threshold(self) -> float:
        return (self.light_off + self.light_on) / 2

    @property
    def difference(self) -> float:
        return abs(self.light_on - self.light_off)

    @property
    def is_good(self) -> bool:
        return self.difference > 100

    def build(self) -> Widget:
        return Split(
            left=[
                StatusIcon(
                    icon="check" if self.is_good else "warning",
                    color="green" if self.is_good else "orange",
                ),
                Spacer(8),
                Text(
                    "Calibration Complete" if self.is_good else "Low Contrast",
                    size="large",
                ),
                Spacer(16),
                Row(
                    children=[
                        Column(
                            children=[
                                Icon("lightbulb_outline", color="grey"),
                                Text("Light OFF", size="small", muted=True),
                                NumericInput(id="light_off", value=self.light_off),
                            ],
                            spacing=4,
                        ),
                        Column(
                            children=[
                                Icon("lightbulb", color="amber"),
                                Text("Light ON", size="small", muted=True),
                                NumericInput(id="light_on", value=self.light_on),
                            ],
                            spacing=4,
                        ),
                    ],
                    spacing=24,
                ),
            ],
            right=[
                Card(
                    children=[
                        ResultsTable(
                            rows=[
                                ("Threshold", f"{self.threshold:.0f}", "blue"),
                                (
                                    "Difference",
                                    f"{self.difference:.0f}",
                                    "green" if self.is_good else "orange",
                                ),
                            ]
                        ),
                        Spacer(24),
                        Column(
                            children=[
                                Button("retry", "Retry", style="secondary"),
                                Button(
                                    "confirm",
                                    "Confirm",
                                    style="success" if self.is_good else "warning",
                                ),
                            ],
                            spacing=8,
                        ),
                    ]
                ),
            ],
            ratio=(5, 3),
        )

    @on_change("light_off")
    async def on_off_change(self, value: float):
        self.light_off = value
        await self.refresh()

    @on_change("light_on")
    async def on_on_change(self, value: float):
        self.light_on = value
        await self.refresh()

    @on_click("retry")
    async def on_retry(self):
        self.close(
            WFLConfirmResult(
                confirmed=False,
                light_off=self.light_off,
                light_on=self.light_on,
            )
        )

    @on_click("confirm")
    async def on_confirm(self):
        self.close(
            WFLConfirmResult(
                confirmed=True,
                light_off=self.light_off,
                light_on=self.light_on,
            )
        )


# =============================================================================
# Auto-detection screen (Kalman-filtered flank detection)
# =============================================================================


class WFLDetectScreen(UIScreen[None]):
    """
    Status display for automatic wait-for-light detection.

    Shows the current sensor value, Kalman-filtered baseline, trigger
    threshold, and detection status. Supports an interactive test mode
    where the user verifies the lamp would trigger before the system
    is truly armed.

    States:
        WARMING UP — collecting baseline samples
        TEST MODE — detects lamp but will NOT start the mission
        TRIGGERED — lamp detected during test (big confirmation)
        ARMED — fully armed, real trigger starts the mission
        GO! — lamp detected for real, mission starting
    """

    title = "Wait for Light"

    def __init__(self) -> None:
        super().__init__()
        self.status: str = "WARMING UP"
        self.status_color: str = "amber"
        self.raw_value: int = 0
        self.baseline: float = 0.0
        self.threshold: float = 0.0
        self.test_count: int = 0
        self.hint: str = ""
        self.request_test_mode: bool = False
        self.request_reinit: bool = False

    def build(self) -> Widget:
        # Big full-screen TRIGGERED indicator
        if self.status == "TRIGGERED":
            return Center(
                children=[
                    Column(
                        children=[
                            StatusBadge(
                                text="TRIGGERED",
                                color="green",
                                glow=True,
                            ),
                            Spacer(8),
                            Text("Lamp detected!", size="xlarge"),
                            Spacer(12),
                            Text(f"Sensor: {self.raw_value}", size="large"),
                            Spacer(4),
                            Text(f"Baseline: {self.baseline:.0f}", size="large", muted=True),
                            Spacer(4),
                            Text(f"Threshold: {self.threshold:.0f}", size="large"),
                            Spacer(8),
                            Text("Turn off lamp to continue", size="small", muted=True),
                        ],
                        align="center",
                        spacing=0,
                    ),
                ]
            )

        # Big full-screen GO! indicator
        if self.status == "GO!":
            return Container(
                bg_color="#1565C0",
                children=[
                    Text("GO!", size="title", bold=True, align="center", color="white"),
                ],
            )

        # Full-screen ARMED indicator — visible from across the room
        if self.status == "ARMED":
            return Container(
                bg_color="#2E7D32",
                padding=16,
                children=[
                    Text("ARMED", size="title", bold=True, align="center", color="white"),
                    Spacer(12),
                    Text(f"Sensor: {self.raw_value}", size="large", align="center", color="white"),
                    Spacer(8),
                    ResultsTable(
                        rows=[
                            ("Baseline", f"{self.baseline:.0f}", "white"),
                            ("Threshold", f"{self.threshold:.0f}", "white"),
                        ]
                    ),
                    Spacer(12),
                    Row(
                        children=[
                            Button("test", "Back to Test Mode", style="secondary"),
                            Button("reinit", "Reinit Kalman", style="warning"),
                        ],
                        spacing=8,
                    ),
                ],
            )

        children: list[Widget] = [
            StatusBadge(
                text=self.status,
                color=self.status_color,
            ),
            Spacer(16),
            Text(f"Sensor: {self.raw_value}", size="xlarge"),
            Spacer(12),
            Text(f"Baseline: {self.baseline:.0f}", size="large", muted=True),
            Spacer(4),
            Text(f"Threshold: {self.threshold:.0f}", size="large"),
            Spacer(4),
            Text(
                f"Tests: {self.test_count}",
                size="large",
                color="green" if self.test_count > 0 else None,
                muted=self.test_count == 0,
            ),
        ]

        if self.hint:
            children += [Spacer(12), HintBox(self.hint)]

        if self.status != "WARMING UP":
            children += [
                Spacer(16),
                Button("reinit", "Reinit Kalman", style="warning"),
            ]

        return Center(
            children=[
                Column(children=children, align="center", spacing=0),
            ]
        )

    @on_click("test")
    async def on_test(self):
        self.request_test_mode = True

    @on_click("reinit")
    async def on_reinit(self):
        self.request_reinit = True
