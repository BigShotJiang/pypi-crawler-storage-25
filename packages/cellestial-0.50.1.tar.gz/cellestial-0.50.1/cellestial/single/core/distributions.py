from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

from lets_plot import gggrid, ggtb
from lets_plot.plot.core import FeatureSpec, LayerSpec

from cellestial.frames import build_frame
from cellestial.single.core.distribution import boxplot, violin
from cellestial.util import (
    _determine_axis,
    _select_variable_keys,
    _share_axis,
    _share_ticks,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from anndata import AnnData
    from lets_plot.plot.subplots import SupPlotsSpec


def violins(
    data: AnnData,
    keys: Sequence[str],
    *,
    group_by: str | None = None,
    groups: Sequence[str] | str | None = None,
    drop: Sequence[str] | str | None = None,
    mapping: FeatureSpec | None = None,
    axis: Literal[0, 1] | None = None,
    color: str | None = None,
    fill: str | None = None,
    add_keys: Sequence[str] | str | None = None,
    tooltips: Literal["none"] | Sequence[str] | FeatureSpec | None = None,
    geom_fill: str | None = None,
    geom_color: str | None = None,
    point_color: str = "#1f1f1f",
    point_alpha: float = 0.7,
    point_size: float = 0.5,
    point_geom: Literal["jitter", "point", "sina"] = "jitter",
    observations_name: str = "Barcode",
    variables_name: str = "Variable",
    show_points: bool = True,
    interactive: bool = False,
    value_column: str = "value",
    variable_column: str = "variable",
    # multi plot args
    share_axis: bool = False,
    share_ticks: bool = False,
    layers: Sequence[FeatureSpec | LayerSpec] | FeatureSpec | LayerSpec | None = None,
    # grid args
    ncol: int | None = None,
    sharex: str | None = None,
    sharey: str | None = None,
    widths: list | None = None,
    heights: list | None = None,
    hspace: float | None = None,
    vspace: float | None = None,
    fit: bool | None = None,
    align: bool | None = None,
    guides: str = "auto",
    # other kwargs
    point_kwargs: dict[str, Any] | None = None,
    **geom_kwargs,
) -> SupPlotsSpec:
    """
    Violin Plots.

    Parameters
    ----------
    data : AnnData
        The AnnData object of the single cell data.
    keys : list[str] | tuple[str] | Sequence[str]
        The keys to get the values (numerical).
        e.g., ['total_counts', 'pct_counts_in_top_50_genes'] or a list of gene names.
    group_by : str | None, default=None
        Column to group observations on the x-axis.
        If not provided, falls back to `fill`, `color`, or the variable column.
    groups : str | Sequence[str] | None, default=None
        Show only specific groups, keeping rows where `group_by` matches any
        of them. Categorical grouping columns only.
    drop : str | Sequence[str] | None, default=None
        Drop specific groups, filtering out rows where `group_by` matches any
        of them. Categorical grouping columns only.
    mapping : FeatureSpec | None, default=None
        Additional aesthetic mappings for the plot, the result of `aes()`.
    axis : {0,1} | None, default=None
        axis of the data, 0 for observations and 1 for variables.
    color : str | None, default=None
        Color aesthetic to split the violin plot (categorical).
        Shortcut for mapping=aes(color=...)
        e,g., 'cell_type' or 'leiden'.
    fill : str | None, default=None
        Fill aesthetic to split the violin plot (categorical).
        Shortcut for mapping=aes(fill=...)
        e,g., 'cell_type' or 'leiden'.
    add_keys : Sequence[str] | str | None, default=None
        Additional keys to include in the dataframe.
    tooltips: {'none'} | Sequence[str] | FeatureSpec | None, default=None
        Tooltips to show when hovering over the geom.
        Accepts Sequence[str] or result of `layer_tooltips()` for more complex tooltips.
        Use 'none' to disable tooltips.
    geom_fill : str | None, default=None
        Fill color for all violins in the violin plot.
    geom_color : str | None, default=None
        Border color for all violins in the violin plot.
    point_color : str, default='#1f1f1f'
        Color for the points in the violin plot.
    point_alpha : float, default=0.7
        Alpha (transparency) for the points in the violin plot.
    point_size : float, default=0.5
        Size for the points in the violin plot.
    point_geom : {'jitter','point','sina'}, default is 'jitter'
        Geom type of the points, default is geom_jitter.
    trim : bool, default=False
        Whether to trim the violin plot.
    observations_name : str, default='Barcode'
        The name to give to barcode (or index) column in the dataframe.
    variables_name : str, default='Gene'
        The name to give to variable index column in the dataframe.
    show_points : bool, default=True
        Whether to show points.
    interactive : bool, default=False
        Whether to make the plot interactive.
    variable_column : str, default='variable'
        The name of the variable column in the dataframe.
    value_column : str, default='value'
        Additional layers to add to the plot.
        The name of the value column in the dataframe.
    share_ticks : bool, default=True
        Whether to share the labels across all plots.
        If True, only X tick texts on bottom row and Y tick text on left column are shown.
    share_axis : bool, default=False
        Whether to share the axis across all plots.
        If True, only X axis on bottom row and Y axis on left column is shown.
    layers : Sequence[FeatureSpec | LayerSpec] | FeatureSpec | LayerSpec | None, default=None
        Additional layers to add to the plot.
    ncol : int, default=None
        Number of columns in grid. If not specified, shows plots horizontally, in one row.
    sharex, sharey : bool, default=None
        Controls sharing of axis limits between subplots in the grid.
        `all`/True - share limits between all subplots.
        `none`/False - do not share limits between subplots.
        `row` - share limits between subplots in the same row.
        `col` - share limits between subplots in the same column.
    widths : list[float], default=None
        Relative width of each column of grid, left to right.
    heights : list[float], default=None
        Relative height of each row of grid, top-down.
    hspace : float | None, default=None
        Cell horizontal spacing in px.
    vspace : float | None, default=None
        Cell vertical spacing in px.
    fit : bool, default=True
        Whether to stretch each plot to match the aspect ratio of its cell (fit=True),
        or to preserve the original aspect ratio of plots (fit=False).
    align : bool, default=False
        If True, align inner areas (i.e. “geom” bounds) of plots.
        However, cells containing other (sub)grids are not participating
        in the plot “inner areas” layouting.
    guides : str, default='auto'
        Specifies how guides (legends and colorbars) should be treated in the layout.
            - 'collect' collect guides from all subplots, removing duplicates.
            - 'keep' keep guides in their original subplots; do not collect at this level.
            - 'auto' allow guides to be collected if an upper-level layout uses guides='collect';

        otherwise, keep them in subplots.
        Duplicates are identified by comparing visual properties:
        For legends: title, labels, and all aesthetic values (colors, shapes, sizes, etc.).
        For colorbars: title, domain limits, breaks, and color gradient.

        For more information on gggrid parameters:
        https://lets-plot.org/python/pages/api/lets_plot.gggrid.html

    point_kwargs : dict[str, Any] | None, default=None
        Additional parameters for the `geom_point` layer.
        For more information on geom_point parameters, see:
        https://lets-plot.org/python/pages/api/lets_plot.geom_point.html
    **geom_kwargs
        Additional parameters for the `geom_violin` layer.
        For more information on geom_violin parameters, see:
        https://lets-plot.org/python/pages/api/lets_plot.geom_violin.html

    Returns
    -------
    SupPlotsSpec
        Violin Plots.

    Examples
    --------
    Violin Plots.

    .. jupyter-execute::

        import scanpy as sc
        from lets_plot import *

        import cellestial as cl

        data = cl.datasets.pbmc3k(cache_directory="data")

        cl.violins(
            data,
            ["n_genes_by_counts", "HLA-DRA", "log1p_total_counts_mt", "pct_counts_hb"],
            fill="cell_type_lvl1",
            layers=[scale_y_log2()],
            point_size=0.3,
            ncol=2,
        )
    """
    # BUILD: one shared (wide) frame for all keys, instead of rebuilding per key.
    # Axis is resolved once over all keys; mixed-axis key sets raise in `_determine_axis`.
    axis = _determine_axis(data=data, keys=keys) if axis is None else axis
    if isinstance(add_keys, str):
        add_keys = [add_keys]
    variable_keys = _select_variable_keys(data=data, keys=keys)
    variable_keys.extend(_select_variable_keys(data=data, keys=add_keys))
    frame = build_frame(
        data=data,
        variable_keys=variable_keys,
        axis=axis,
        observations_name=observations_name,
        variables_name=variables_name,
    )

    plots = []
    for i, key in enumerate(keys):
        plot = violin(
            data=data,
            key=key,
            frame=frame,
            group_by=group_by,
            groups=groups,
            drop=drop,
            mapping=mapping,
            axis=axis,
            color=color,
            fill=fill,
            add_keys=add_keys,
            tooltips=tooltips,
            geom_fill=geom_fill,
            geom_color=geom_color,
            point_color=point_color,
            point_alpha=point_alpha,
            point_size=point_size,
            point_geom=point_geom,
            observations_name=observations_name,
            variables_name=variables_name,
            show_points=show_points,
            value_column=value_column,
            variable_column=variable_column,
            point_kwargs=point_kwargs,
            **geom_kwargs,
        )
        # handle the layers
        if layers is not None:
            if isinstance(layers, (FeatureSpec, LayerSpec)):
                layers = [layers]
            for layer in layers:
                plot += layer
        if share_ticks:
            plot = _share_ticks(plot, i, keys, ncol)
        if share_axis:
            plot = _share_axis(plot, i, keys, ncol, "axis")
        plots.append(plot)

    dsts = gggrid(
        plots,
        ncol=ncol,  # ty:ignore[invalid-argument-type]
        sharex=sharex,  # ty:ignore[invalid-argument-type]
        sharey=sharey,  # ty:ignore[invalid-argument-type]
        widths=widths,  # ty:ignore[invalid-argument-type]
        heights=heights,  # ty:ignore[invalid-argument-type]
        hspace=hspace,  # ty:ignore[invalid-argument-type]
        vspace=vspace,  # ty:ignore[invalid-argument-type]
        fit=fit,  # ty:ignore[invalid-argument-type]
        align=align,  # ty:ignore[invalid-argument-type]
        guides=guides,
    )

    if interactive:
        dsts += ggtb(size_zoomin=-1)

    return dsts


def boxplots(
    data: AnnData,
    keys: Sequence[str],
    *,
    group_by: str | None = None,
    groups: Sequence[str] | str | None = None,
    drop: Sequence[str] | str | None = None,
    mapping: FeatureSpec | None = None,
    axis: Literal[0, 1] | None = None,
    color: str | None = None,
    fill: str | None = None,
    add_keys: Sequence[str] | str | None = None,
    tooltips: Literal["none"] | Sequence[str] | FeatureSpec | None = None,
    geom_fill: str | None = None,
    geom_color: str | None = None,
    point_color: str = "#1f1f1f",
    point_alpha: float = 0.7,
    point_size: float = 0.5,
    point_geom: Literal["jitter", "point", "sina"] = "jitter",
    observations_name: str = "Barcode",
    variables_name: str = "Variable",
    show_points: bool = True,
    interactive: bool = False,
    value_column: str = "value",
    variable_column: str = "variable",
    # multi plot args
    share_axis: bool = False,
    share_ticks: bool = False,
    layers: Sequence[FeatureSpec | LayerSpec] | FeatureSpec | LayerSpec | None = None,
    # grid args
    ncol: int | None = None,
    sharex: str | None = None,
    sharey: str | None = None,
    widths: list | None = None,
    heights: list | None = None,
    hspace: float | None = None,
    vspace: float | None = None,
    fit: bool | None = None,
    align: bool | None = None,
    guides: str = "auto",
    # other kwargs
    point_kwargs: dict[str, Any] | None = None,
    **geom_kwargs,
) -> SupPlotsSpec:
    """
    Boxplots.

    Parameters
    ----------
    data : AnnData
        The AnnData object of the single cell data.
    keys : list[str] | tuple[str] | Sequence[str]
        The keys to get the values (numerical).
        e.g., ['total_counts', 'pct_counts_in_top_50_genes'] or a list of gene names.
    group_by : str | None, default=None
        Column to group observations on the x-axis.
        If not provided, falls back to `fill`, `color`, or the variable column.
    groups : str | Sequence[str] | None, default=None
        Show only specific groups, keeping rows where `group_by` matches any
        of them. Categorical grouping columns only.
    drop : str | Sequence[str] | None, default=None
        Drop specific groups, filtering out rows where `group_by` matches any
        of them. Categorical grouping columns only.
    mapping : FeatureSpec | None, default=None
        Additional aesthetic mappings for the plot, the result of `aes()`.
    axis : {0,1} | None, default=None
        axis of the data, 0 for observations and 1 for variables.
    color : str | None, default=None
        Color aesthetic to split the boxplot (categorical).
        Shortcut for mapping=aes(color=...)
        e,g., 'cell_type' or 'leiden'.
    fill : str | None, default=None
        Fill aesthetic to split the boxplot (categorical).
        Shortcut for mapping=aes(fill=...)
        e,g., 'cell_type' or 'leiden'.
    add_keys : Sequence[str] | str | None, default=None
        Additional keys to include in the dataframe.
    tooltips: {'none'} | Sequence[str] | FeatureSpec | None, default=None
        Tooltips to show when hovering over the geom.
        Accepts Sequence[str] or result of `layer_tooltips()` for more complex tooltips.
        Use 'none' to disable tooltips.
    geom_fill : str | None, default=None
        Fill color for all boxplots in the boxplot.
    geom_color : str | None, default=None
        Border color for all boxplots in the boxplot.
    point_color : str, default='#1f1f1f'
        Color for the points in the boxplot.
    point_alpha : float, default=0.7
        Alpha (transparency) for the points in the boxplot.
    point_size : float, default=0.5
        Size for the points in the boxplot.
    point_geom : {'jitter','point','sina'}, default is 'jitter'
        Geom type of the points, default is geom_jitter.
    observations_name : str, default='Barcode'
        The name to give to barcode (or index) column in the dataframe.
    variables_name : str, default='Gene'
        The name to give to variable index column in the dataframe.
    show_points : bool, default=True
        Whether to show points.
    interactive : bool, default=False
        Whether to make the plot interactive.
    variable_column : str, default='variable'
        The name of the variable column in the dataframe.
    value_column : str, default='value'
        The name of the value column in the dataframe.
    share_ticks : bool, default=True
        Whether to share the labels across all plots.
        If True, only X tick texts on bottom row and Y tick text on left column are shown.
    share_axis : bool, default=False
        Whether to share the axis across all plots.
        If True, only X axis on bottom row and Y axis on left column is shown.
    layers : Sequence[FeatureSpec | LayerSpec] | FeatureSpec | LayerSpec | None, default=None
        Additional layers to add to the plot.
    ncol : int, default=None
        Number of columns in grid. If not specified, shows plots horizontally, in one row.
    sharex, sharey : bool, default=None
        Controls sharing of axis limits between subplots in the grid.
        `all`/True - share limits between all subplots.
        `none`/False - do not share limits between subplots.
        `row` - share limits between subplots in the same row.
        `col` - share limits between subplots in the same column.
    widths : list[float], default=None
        Relative width of each column of grid, left to right.
    heights : list[float], default=None
        Relative height of each row of grid, top-down.
    hspace : float | None, default=None
        Cell horizontal spacing in px.
    vspace : float | None, default=None
        Cell vertical spacing in px.
    fit : bool, default=True
        Whether to stretch each plot to match the aspect ratio of its cell (fit=True),
        or to preserve the original aspect ratio of plots (fit=False).
    align : bool, default=False
        If True, align inner areas (i.e. “geom” bounds) of plots.
        However, cells containing other (sub)grids are not participating
        in the plot “inner areas” layouting.
    guides : str, default='auto'
        Specifies how guides (legends and colorbars) should be treated in the layout.
            - 'collect' collect guides from all subplots, removing duplicates.
            - 'keep' keep guides in their original subplots; do not collect at this level.
            - 'auto' allow guides to be collected if an upper-level layout uses guides='collect';

        otherwise, keep them in subplots.
        Duplicates are identified by comparing visual properties:
        For legends: title, labels, and all aesthetic values (colors, shapes, sizes, etc.).
        For colorbars: title, domain limits, breaks, and color gradient.

        For more information on gggrid parameters:
        https://lets-plot.org/python/pages/api/lets_plot.gggrid.html

    point_kwargs : dict[str, Any] | None, default=None
        Additional parameters for the `geom_point` layer.
        For more information on geom_point parameters, see:
        https://lets-plot.org/python/pages/api/lets_plot.geom_point.html
    **geom_kwargs
        Additional parameters for the `geom_boxplot` layer.
        For more information on geom_boxplot parameters, see:
        https://lets-plot.org/python/pages/api/lets_plot.geom_boxplot.html

    Returns
    -------
    SupPlotsSpec
        Boxplots.

    Examples
    --------
    Boxplots.

    .. jupyter-execute::

        import scanpy as sc
        from lets_plot import *

        import cellestial as cl

        data = cl.datasets.pbmc3k(cache_directory="data")

        cl.boxplots(
            data,
            ["n_genes_by_counts", "HLA-DRA", "log1p_total_counts_mt", "pct_counts_hb"],
            fill="cell_type_lvl1",
            layers=[scale_y_log2()],
            point_size=0.3,
            ncol=2,
        )
    """
    # BUILD: one shared (wide) frame for all keys, instead of rebuilding per key.
    # Axis is resolved once over all keys; mixed-axis key sets raise in `_determine_axis`.
    axis = _determine_axis(data=data, keys=keys) if axis is None else axis
    if isinstance(add_keys, str):
        add_keys = [add_keys]
    variable_keys = _select_variable_keys(data=data, keys=keys)
    variable_keys.extend(_select_variable_keys(data=data, keys=add_keys))
    frame = build_frame(
        data=data,
        variable_keys=variable_keys,
        axis=axis,
        observations_name=observations_name,
        variables_name=variables_name,
    )

    plots = []
    for i, key in enumerate(keys):
        plot = boxplot(
            data=data,
            key=key,
            frame=frame,
            group_by=group_by,
            groups=groups,
            drop=drop,
            mapping=mapping,
            axis=axis,
            color=color,
            fill=fill,
            add_keys=add_keys,
            tooltips=tooltips,
            geom_fill=geom_fill,
            geom_color=geom_color,
            point_color=point_color,
            point_alpha=point_alpha,
            point_size=point_size,
            point_geom=point_geom,
            observations_name=observations_name,
            variables_name=variables_name,
            show_points=show_points,
            value_column=value_column,
            variable_column=variable_column,
            point_kwargs=point_kwargs,
            **geom_kwargs,
        )
        # handle the layers
        if layers is not None:
            if isinstance(layers, (FeatureSpec, LayerSpec)):
                layers = [layers]
            for layer in layers:
                plot += layer
        if share_ticks:
            plot = _share_ticks(plot, i, keys, ncol)
        if share_axis:
            plot = _share_axis(plot, i, keys, ncol, "axis")

        plots.append(plot)

    dsts = gggrid(
        plots,
        ncol=ncol,  # ty:ignore[invalid-argument-type]
        sharex=sharex,  # ty:ignore[invalid-argument-type]
        sharey=sharey,  # ty:ignore[invalid-argument-type]
        widths=widths,  # ty:ignore[invalid-argument-type]
        heights=heights,  # ty:ignore[invalid-argument-type]
        hspace=hspace,  # ty:ignore[invalid-argument-type]
        vspace=vspace,  # ty:ignore[invalid-argument-type]
        fit=fit,  # ty:ignore[invalid-argument-type]
        align=align,  # ty:ignore[invalid-argument-type]
        guides=guides,
    )

    if interactive:
        dsts += ggtb(size_zoomin=-1)

    return dsts
