"""Semantic Scholar types."""

from __future__ import annotations

from pydantic import BaseModel, Field


class S2Author(BaseModel):
    name: str
    author_id: str | None = Field(None, alias="authorId")
    model_config = {"populate_by_name": True, "extra": "ignore"}


class S2Paper(BaseModel):
    title: str
    abstract: str | None = None
    year: int | None = None
    venue: str | None = None
    publication_venue: dict | None = Field(None, alias="publicationVenue")
    journal: dict | None = None
    authors: list[S2Author] = Field(default_factory=list)
    corpus_id: str | int | None = Field(None, alias="corpusId")
    model_config = {"populate_by_name": True, "extra": "ignore"}

    @property
    def resolved_venue(self) -> str | None:
        if self.venue:
            return self.venue
        if self.publication_venue and self.publication_venue.get("name"):
            return self.publication_venue["name"]
        if self.journal and self.journal.get("name"):
            return self.journal["name"]
        return None

    def citation(self) -> str:
        """Format 'Author et al., Year' citation string."""
        if self.authors:
            first = self.authors[0].name.split()[-1] if self.authors[0].name else "Unknown"
            author_str = f"{first} et al." if len(self.authors) > 1 else first
        else:
            author_str = "Unknown"
        return f"{author_str}, {self.year or 'n.d.'}"

    def s2_url(self) -> str | None:
        """Return Semantic Scholar URL if corpus_id is available."""
        if self.corpus_id:
            return f"https://api.semanticscholar.org/CorpusId:{self.corpus_id}"
        return None

    def s2_link(self, label: str | None = None) -> str:
        """Return a markdown link to Semantic Scholar, or plain label if no corpus_id."""
        display = label or self.title
        url = self.s2_url()
        return f"[{display}]({url})" if url else display
