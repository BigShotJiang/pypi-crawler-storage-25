from .s2 import S2Author, S2Paper

__all__ = [
    "S2Author",
    "S2Paper",
]
