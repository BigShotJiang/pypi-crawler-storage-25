"""Casca command-line tooling."""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from dataclasses import asdict, dataclass

from .core.terminal import get_terminal_size


@dataclass
class DoctorReport:
    python_version: str
    python_executable: str
    platform: str
    term: str
    colorterm: str
    stdin_tty: bool
    stdout_tty: bool
    terminal_width: int
    terminal_height: int
    unicode_ok: bool


def collect_doctor_report() -> DoctorReport:
    width, height = get_terminal_size()
    unicode_ok = True
    try:
        "✓".encode(sys.stdout.encoding or "utf-8")
    except Exception:
        unicode_ok = False

    return DoctorReport(
        python_version=sys.version.split()[0],
        python_executable=sys.executable,
        platform=platform.platform(),
        term=os.environ.get("TERM", ""),
        colorterm=os.environ.get("COLORTERM", ""),
        stdin_tty=bool(getattr(sys.stdin, "isatty", lambda: False)()),
        stdout_tty=bool(getattr(sys.stdout, "isatty", lambda: False)()),
        terminal_width=width,
        terminal_height=height,
        unicode_ok=unicode_ok,
    )


def format_doctor_report(report: DoctorReport) -> str:
    lines = [
        "Casca Doctor",
        f"python:        {report.python_version}",
        f"executable:    {report.python_executable}",
        f"platform:      {report.platform}",
        f"terminal:      TERM={report.term or '(unset)'} COLORTERM={report.colorterm or '(unset)'}",
        f"tty:           stdin={report.stdin_tty} stdout={report.stdout_tty}",
        f"terminal size: {report.terminal_width}x{report.terminal_height}",
        f"unicode:       {report.unicode_ok}",
    ]
    return "\n".join(lines)


def doctor_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="casca-doctor", description="Inspect local Casca runtime capabilities."
    )
    parser.add_argument("--json", action="store_true", help="Emit machine-readable JSON output.")
    args = parser.parse_args(argv)

    report = collect_doctor_report()
    if args.json:
        print(json.dumps(asdict(report), indent=2))
    else:
        print(format_doctor_report(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(doctor_main())
