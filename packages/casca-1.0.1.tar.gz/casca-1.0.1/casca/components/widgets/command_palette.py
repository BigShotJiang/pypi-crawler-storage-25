"""Command palette widget for quick actions."""

from __future__ import annotations

from collections.abc import Callable

from ...core.events import KeyEvent
from ..forms.input import Input
from .container import Container
from .label import Label
from .listview import ListView


class CommandPalette(Container):
    """A compact command palette with filtering and quick execution."""

    tag = "command-palette"

    def __init__(self, commands: list[dict], id: str = "", classes: str = "", **props):
        super().__init__(id=id, classes=classes, **props)
        self.commands = [
            {
                "label": str(cmd.get("label", "")),
                "action": cmd.get("action"),
                "keywords": str(cmd.get("keywords", "")),
            }
            for cmd in commands
        ]
        self.query_input = Input(placeholder="Type command", id=f"{id}_query" if id else "")
        self.results = ListView([], height=6)
        self.is_open = False
        self._result_map: list[int] = []

        if "style" not in self.props:
            self.props["style"] = {}
        self.props["style"].setdefault("flex-direction", "column")

    def open(self):
        self.is_open = True
        self.query_input.clear()
        self._refresh_matches()

    def close(self):
        self.is_open = False

    def toggle(self):
        if self.is_open:
            self.close()
        else:
            self.open()

    def _refresh_matches(self):
        q = self.query_input.value.strip().lower()
        pairs = []
        for idx, cmd in enumerate(self.commands):
            hay = f"{cmd['label']} {cmd['keywords']}".lower()
            if not q or q in hay:
                pairs.append((idx, cmd["label"]))
        self._result_map = [idx for idx, _ in pairs]
        self.results.items = [label for _, label in pairs] or ["(no matches)"]
        self.results.selected_index = 0
        self.results.scroll_offset = 0

    def _run_selected(self):
        if not self._result_map:
            return
        idx = self.results.selected_index
        if idx < 0 or idx >= len(self._result_map):
            return
        cmd = self.commands[self._result_map[idx]]
        action: Callable | None = cmd.get("action")
        if action:
            action()
        self.close()

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        if not self.is_open:
            self.children = []
            self.width = 0
            self.height = 0
            return 0, 0

        self._refresh_matches()
        self.children = [
            Label("Command Palette"),
            self.query_input,
            self.results,
        ]
        self.results.props["height"] = int(self.props.get("results-height", 6))
        self.query_input.props["width"] = int(self.props.get("width", min(50, available_width)))
        return super().calculate_layout(available_width, available_height)

    def handle_input(self, event: KeyEvent) -> bool:
        # Ctrl+P toggles palette.
        if event.key == "\x10":
            self.toggle()
            return True

        if not self.is_open:
            return False

        if event.key == "\x1b":
            self.close()
            return True

        if event.key in ("\r", "\n"):
            self._run_selected()
            return True

        # Route typing to query input first, then sync matches.
        if self.query_input.handle_input(event):
            self._refresh_matches()
            return True

        if self.results.handle_input(event):
            return True

        return super().handle_input(event)
