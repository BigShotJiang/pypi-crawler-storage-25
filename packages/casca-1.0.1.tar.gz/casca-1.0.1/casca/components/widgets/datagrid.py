"""DataGrid skeleton widget with header/row rendering and selection."""

from collections.abc import Callable
from typing import Any

from ...core.events import KeyEvent, Keys, MouseEvent
from ...style.css import get_border_width, get_box_spacing
from .base import WidgetBase


class DataGrid(WidgetBase):
    """A basic tabular widget with row selection and vertical scrolling."""

    tag = "datagrid"

    def __init__(
        self,
        columns: list[str | dict[str, Any]],
        rows: list[list[str]] | None = None,
        selected_row: int = 0,
        show_header: bool = True,
        on_select: Callable[[int, list[str]], None] | None = None,
        id: str = "",
        classes: str = "",
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self._column_defs = self._normalize_column_defs(columns)
        self.columns = [col["name"] for col in self._column_defs]
        self.rows = rows or []
        self.show_header = show_header
        self.selected_row = 0 if not self.rows else max(0, min(selected_row, len(self.rows) - 1))
        self.on_select = on_select
        self.scroll_offset = 0
        self._column_widths: list[int] = []

        if "height" not in self.props:
            self.props["height"] = 8

    def _normalize_column_defs(
        self, columns: list[str | dict[str, Any]] | None
    ) -> list[dict[str, Any]]:
        normalized: list[dict[str, Any]] = []
        for raw_col in columns or [""]:
            if isinstance(raw_col, str):
                name = raw_col
                normalized.append(
                    {
                        "name": name,
                        "width": None,
                        "flex": 1,
                        "min_width": max(3, len(name)),
                    }
                )
                continue

            if isinstance(raw_col, dict):
                name = str(raw_col.get("name", raw_col.get("title", "")))
                raw_width = raw_col.get("width")
                width = int(raw_width) if raw_width is not None else None
                if width is not None:
                    width = max(1, width)

                default_flex = 0 if width is not None else 1
                flex = max(0, int(raw_col.get("flex", default_flex)))

                min_width = max(1, int(raw_col.get("min_width", max(3, len(name)))))
                if width is not None:
                    min_width = min(min_width, width)

                normalized.append(
                    {
                        "name": name,
                        "width": width,
                        "flex": flex,
                        "min_width": min_width,
                    }
                )
                continue

            # Fallback for unexpected values.
            name = str(raw_col)
            normalized.append(
                {
                    "name": name,
                    "width": None,
                    "flex": 1,
                    "min_width": max(3, len(name)),
                }
            )

        return normalized

    def _normalized_rows(self) -> list[list[str]]:
        normalized = []
        target_cols = len(self.columns)
        for row in self.rows:
            values = [str(cell) for cell in row[:target_cols]]
            if len(values) < target_cols:
                values.extend([""] * (target_cols - len(values)))
            normalized.append(values)
        return normalized

    def _visible_data_rows(self) -> int:
        pad_top, _pad_right, pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        inner_rows = max(1, self.height - (pad_top + pad_bottom + 2 * border_width))
        if self.show_header:
            # Header + divider consume two rows.
            return max(1, inner_rows - 2)
        return inner_rows

    def _ensure_visible(self):
        if not self.rows:
            self.selected_row = 0
            self.scroll_offset = 0
            return

        self.selected_row = max(0, min(self.selected_row, len(self.rows) - 1))
        visible = self._visible_data_rows()
        if self.selected_row < self.scroll_offset:
            self.scroll_offset = self.selected_row
        elif self.selected_row >= self.scroll_offset + visible:
            self.scroll_offset = self.selected_row - visible + 1

    def _emit_select(self):
        if self.on_select and self.rows:
            self.on_select(self.selected_row, self.rows[self.selected_row])

    def _build_column_widths(self, inner_width: int):
        normalized_rows = self._normalized_rows()
        separator_space = max(0, len(self._column_defs) - 1) * 3
        row_prefix_space = 2
        cell_space = max(1, inner_width - row_prefix_space - separator_space)

        preferred: list[int] = []
        flex_indices: list[int] = []
        flex_weight_total = 0

        for idx, col in enumerate(self._column_defs):
            fixed = col["width"]
            if fixed is not None:
                preferred.append(int(fixed))
                continue

            # Flexible columns start from content-aware minimum width.
            content_width = len(self.columns[idx])
            for row in normalized_rows:
                content_width = max(content_width, len(row[idx]))

            base = max(int(col["min_width"]), content_width)
            preferred.append(base)
            if col["flex"] > 0:
                flex_indices.append(idx)
                flex_weight_total += int(col["flex"])

        current_total = sum(preferred)
        if current_total < cell_space and flex_indices and flex_weight_total > 0:
            extra = cell_space - current_total
            distributed = 0
            for idx in flex_indices:
                share = (extra * int(self._column_defs[idx]["flex"])) // flex_weight_total
                preferred[idx] += share
                distributed += share

            # Distribute remainder left by integer division.
            rem = extra - distributed
            order = sorted(
                flex_indices,
                key=lambda i: int(self._column_defs[i]["flex"]),
                reverse=True,
            )
            for i in range(rem):
                preferred[order[i % len(order)]] += 1

        if sum(preferred) > cell_space:
            overflow = sum(preferred) - cell_space
            while overflow > 0:
                changed = False
                for idx in sorted(range(len(preferred)), key=lambda i: preferred[i], reverse=True):
                    if overflow <= 0:
                        break
                    if preferred[idx] > 1:
                        preferred[idx] -= 1
                        overflow -= 1
                        changed = True
                if not changed:
                    break

        self._column_widths = [max(1, w) for w in preferred]

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        natural_cols = [
            int(col["width"])
            if col["width"] is not None
            else max(int(col["min_width"]), len(col["name"]))
            for col in self._column_defs
        ]
        natural_inner = 2 + sum(natural_cols) + (len(self.columns) - 1) * 3
        natural_width = natural_inner + pad_left + pad_right + 2 * border_width

        row_count = max(1, min(len(self.rows), 5))
        base_rows = row_count + (2 if self.show_header else 0)
        natural_height = base_rows + pad_top + pad_bottom + 2 * border_width

        self.width = int(self.props.get("width", natural_width))
        self.height = int(self.props.get("height", natural_height))

        inner_width = max(1, self.width - pad_left - pad_right - (2 * border_width))
        self._build_column_widths(inner_width)
        self._ensure_visible()

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def _format_row(self, cells: list[str], is_selected: bool) -> str:
        chunks = []
        for idx, cell in enumerate(cells):
            width = self._column_widths[idx]
            chunks.append(cell[:width].ljust(width))
        row = " | ".join(chunks)
        return ("> " if is_selected else "  ") + row

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)

        inner_width = max(1, self.width - pad_left - pad_right - (2 * border_width))
        cursor_x = self.x + pad_left + border_width + 1
        cursor_y = self.y + pad_top + border_width + 1

        line_offset = 0
        if self.show_header:
            header = self._format_row(self.columns, is_selected=False)
            app.draw_text(cursor_x, cursor_y + line_offset, header[:inner_width])
            line_offset += 1
            app.draw_text(cursor_x, cursor_y + line_offset, ("-" * inner_width)[:inner_width])
            line_offset += 1

        visible = self._visible_data_rows()
        normalized_rows = self._normalized_rows()
        for row_slot in range(visible):
            row_idx = self.scroll_offset + row_slot
            if row_idx < len(normalized_rows):
                line = self._format_row(normalized_rows[row_idx], row_idx == self.selected_row)
            else:
                line = ""
            app.draw_text(cursor_x, cursor_y + line_offset + row_slot, line[:inner_width])

    def handle_input(self, event: KeyEvent) -> bool:
        if self._disabled or not self.rows:
            return False

        if event.key == Keys.UP:
            self.selected_row = max(0, self.selected_row - 1)
            self._ensure_visible()
            self._emit_select()
            return True

        if event.key == Keys.DOWN:
            self.selected_row = min(len(self.rows) - 1, self.selected_row + 1)
            self._ensure_visible()
            self._emit_select()
            return True

        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        if self._disabled:
            return False

        if event.button in (64, 65):
            if event.button == 64:
                self.scroll_offset = max(0, self.scroll_offset - 1)
            else:
                max_offset = max(0, len(self.rows) - self._visible_data_rows())
                self.scroll_offset = min(max_offset, self.scroll_offset + 1)
            return True

        if event.button != 0 or event.pressed:
            return False

        pad_top, _pad_right, _pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        local_y = (event.y - 1) - self.y - pad_top - border_width

        if self.show_header:
            local_y -= 2

        if local_y < 0:
            return False

        row_idx = self.scroll_offset + local_y
        if 0 <= row_idx < len(self.rows):
            self.selected_row = row_idx
            self._ensure_visible()
            self._emit_select()
            return True

        return False
