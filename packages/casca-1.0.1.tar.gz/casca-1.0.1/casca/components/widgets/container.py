"""
Container widget for layout and grouping.
"""

from ...style.css import clamp_dimension, get_border_width, get_box_spacing, parse_size
from .base import WidgetBase


class Container(WidgetBase):
    """
    A generic container for laying out child widgets.

    Supports flex-direction for row/column layouts.
    """

    tag = "container"

    def _child_flex_values(self, child, main_reference: int) -> tuple[float, float, int | None]:
        style = getattr(child, "style", {}) or {}
        grow = float(style.get("flex-grow", 0) or 0)
        shrink = float(style.get("flex-shrink", 1) or 1)
        basis_raw = style.get("flex-basis")

        flex_raw = style.get("flex")
        if flex_raw is not None:
            parts = str(flex_raw).split()
            if len(parts) >= 1:
                try:
                    grow = float(parts[0])
                except ValueError:
                    pass
            if len(parts) >= 2:
                try:
                    shrink = float(parts[1])
                except ValueError:
                    pass
            if len(parts) >= 3 and basis_raw is None:
                basis_raw = parts[2]

        basis = None
        if basis_raw is not None and str(basis_raw).lower() != "auto":
            basis = parse_size(basis_raw, main_reference, 0)

        return max(0.0, grow), max(0.0, shrink), basis

    def _resolve_justify(
        self, justify: str, free_space: int, child_count: int, base_gap: int
    ) -> tuple[int, int]:
        justify = (justify or "start").strip().lower()
        if justify in ("flex-start", "start", "left", "top"):
            return 0, base_gap
        if justify in ("flex-end", "end", "right", "bottom"):
            return max(0, free_space), base_gap
        if justify == "center":
            return max(0, free_space // 2), base_gap

        if child_count <= 1:
            return 0, base_gap

        if justify == "space-between":
            return 0, base_gap + (max(0, free_space) // (child_count - 1))
        if justify == "space-around":
            slot = max(0, free_space) // child_count
            return slot // 2, base_gap + slot
        if justify == "space-evenly":
            slot = max(0, free_space) // (child_count + 1)
            return slot, base_gap + slot

        return 0, base_gap

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout using flow/flex semantics for row and column containers."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")

        # Width priority: Direct property -> Inline style -> Available parent width
        raw_width = self.props.get("width", self.style.get("width", available_width))
        self.width = clamp_dimension(
            raw_width, self.style, "width", available_width, available_width
        )

        raw_height = self.props.get("height", self.style.get("height"))
        explicit_height = raw_height is not None
        if explicit_height:
            self.height = clamp_dimension(
                raw_height, self.style, "height", available_height, available_height
            )
        else:
            self.height = 0

        # Content layout logic
        is_row = self.style.get("flex-direction") == "row"
        gap = parse_size(self.style.get("gap", 0), self.width, 0) or 0

        inner_width = max(0, self.width - (pad_left + pad_right + 2 * border_width))
        if explicit_height:
            inner_height = max(0, self.height - (pad_top + pad_bottom + 2 * border_width))
        else:
            inner_height = max(0, available_height - (pad_top + pad_bottom + 2 * border_width))

        if not self.children:
            self.content_width = 0
            self.content_height = 0
            min_height = pad_top + pad_bottom + border_width * 2
            if not explicit_height:
                self.height = min_height
            return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

        child_meta = []
        for child in self.children:
            cmt, cmr, cmb, cml = get_box_spacing(child.style, "margin")
            grow, shrink, basis = self._child_flex_values(
                child, inner_width if is_row else inner_height
            )
            natural_w, natural_h = child.calculate_layout(inner_width, inner_height)

            natural_main = natural_w if is_row else natural_h
            natural_cross = natural_h if is_row else natural_w

            base_main = natural_main
            if basis is not None:
                # basis represents the content box of the main axis.
                margins_main = (cml + cmr) if is_row else (cmt + cmb)
                base_main = max(0, basis + margins_main)

            child_meta.append(
                {
                    "child": child,
                    "margin": (cmt, cmr, cmb, cml),
                    "grow": grow,
                    "shrink": shrink,
                    "base_main": max(0, int(base_main)),
                    "natural_main": max(0, int(natural_main)),
                    "natural_cross": max(0, int(natural_cross)),
                    "final_main": max(0, int(base_main)),
                    "final_cross": max(0, int(natural_cross)),
                    "outer_w": natural_w,
                    "outer_h": natural_h,
                    "needs_main_enforce": basis is not None or grow > 0 or shrink > 0,
                }
            )

        available_main = inner_width if is_row else inner_height
        total_gap = gap * max(0, len(child_meta) - 1)
        total_base_main = sum(m["base_main"] for m in child_meta)
        free_space = available_main - total_base_main - total_gap

        if free_space > 0:
            total_grow = sum(m["grow"] for m in child_meta)
            if total_grow > 0:
                allocated = 0
                grow_indices = [i for i, m in enumerate(child_meta) if m["grow"] > 0]
                for idx in grow_indices:
                    share = int((free_space * child_meta[idx]["grow"]) / total_grow)
                    child_meta[idx]["final_main"] += share
                    allocated += share
                rem = free_space - allocated
                for i in range(rem):
                    child_meta[grow_indices[i % len(grow_indices)]]["final_main"] += 1
        elif free_space < 0:
            overflow = -free_space
            total_shrink_factor = sum(m["shrink"] * max(1, m["base_main"]) for m in child_meta)
            if total_shrink_factor > 0:
                reduced = 0
                shrink_indices = [i for i, m in enumerate(child_meta) if m["shrink"] > 0]
                for idx in shrink_indices:
                    factor = child_meta[idx]["shrink"] * max(1, child_meta[idx]["base_main"])
                    cut = int((overflow * factor) / total_shrink_factor)
                    child_meta[idx]["final_main"] = max(1, child_meta[idx]["final_main"] - cut)
                    reduced += cut
                rem = overflow - reduced
                for i in range(rem):
                    idx = shrink_indices[i % len(shrink_indices)]
                    if child_meta[idx]["final_main"] > 1:
                        child_meta[idx]["final_main"] -= 1

        vertical_align = str(self.style.get("vertical-align", "")).strip().lower()
        align_items = str(self.style.get("align-items", "start")).strip().lower()
        if is_row and "align-items" not in self.style and vertical_align:
            align_items = vertical_align

        for meta in child_meta:
            child = meta["child"]
            cmt, cmr, cmb, cml = meta["margin"]

            if is_row:
                child_avail_w = max(1, meta["final_main"] - cml - cmr)
                if align_items == "stretch" and explicit_height:
                    child_avail_h = max(1, inner_height - cmt - cmb)
                else:
                    child_avail_h = max(1, inner_height)
            else:
                if align_items == "stretch":
                    child_avail_w = max(1, inner_width - cml - cmr)
                else:
                    child_avail_w = max(1, inner_width)
                child_avail_h = max(1, meta["final_main"] - cmt - cmb)

            child_style = getattr(child, "style", {}) or {}
            explicit_child_width = ("width" in child.props) or ("width" in child_style)
            explicit_child_height = ("height" in child.props) or ("height" in child_style)

            if is_row and meta["needs_main_enforce"] and not explicit_child_width:
                child.props["width"] = child_avail_w
            if (not is_row) and meta["needs_main_enforce"] and not explicit_child_height:
                child.props["height"] = child_avail_h

            # Keep final available sizes for a post-position recalc pass.
            meta["final_avail_w"] = child_avail_w
            meta["final_avail_h"] = child_avail_h

            final_w, final_h = child.calculate_layout(child_avail_w, child_avail_h)
            meta["outer_w"] = final_w
            meta["outer_h"] = final_h
            meta["final_main"] = final_w if is_row else final_h
            meta["final_cross"] = final_h if is_row else final_w

        used_main = sum(m["final_main"] for m in child_meta) + total_gap
        cross_size = max((m["final_cross"] for m in child_meta), default=0)

        if is_row:
            self.content_width = used_main
            self.content_height = cross_size
        else:
            self.content_width = cross_size
            self.content_height = used_main

        if explicit_height:
            cross_available = inner_height if is_row else inner_width
        else:
            cross_available = self.content_height if is_row else self.content_width

        justify = self.style.get("justify-content", "start")
        if (not is_row) and "justify-content" not in self.style and vertical_align:
            justify = vertical_align
        free_main_after_layout = (available_main - used_main) if available_main > used_main else 0
        main_offset, effective_gap = self._resolve_justify(
            justify, free_main_after_layout, len(child_meta), gap
        )

        cursor_main = main_offset
        for idx, meta in enumerate(child_meta):
            child = meta["child"]
            cmt, cmr, cmb, cml = meta["margin"]
            align_self = str(child.style.get("align-self", align_items)).strip().lower()

            free_cross = max(0, cross_available - meta["final_cross"])
            if align_self in ("end", "flex-end", "right", "bottom"):
                cross_offset = free_cross
            elif align_self == "center":
                cross_offset = free_cross // 2
            else:
                cross_offset = 0

            if is_row:
                child.x = self.x + pad_left + border_width + cursor_main + cml
                child.y = self.y + pad_top + border_width + cross_offset + cmt
            else:
                child.x = self.x + pad_left + border_width + cross_offset + cml
                child.y = self.y + pad_top + border_width + cursor_main + cmt

            cursor_main += meta["final_main"]
            if idx < len(child_meta) - 1:
                cursor_main += effective_gap

        # Child subtrees may have been laid out while child.x/child.y were still stale.
        # Recalculate once after final absolute positions are known so first frame is stable.
        for meta in child_meta:
            child = meta["child"]
            child.calculate_layout(meta["final_avail_w"], meta["final_avail_h"])

        # Total height including padding, border and margin
        min_height = pad_top + pad_bottom + border_width * 2

        if not explicit_height:
            raw_content_height = self.content_height + min_height
            self.height = clamp_dimension(
                raw_content_height, self.style, "height", available_height, raw_content_height
            )

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom
