"""
Tooltip widget - Hover tooltip for UI elements.
"""

from typing import Any

from ...core.ansi import RESET
from ...core.events import MouseEvent
from ..widgets.base import WidgetBase


class Tooltip(WidgetBase):
    """
    A tooltip that appears on hover over a target widget.

    Features:
    - Appears on mouse hover
    - Auto-positioning (avoids screen edges)
    - Configurable delay
    - CSS styling support
    - Rich text content support

    Usage:
        # Basic tooltip
        button = Button("Click me")
        tooltip = Tooltip(target=button, text="Click to submit")

        # Tooltip with delay
        tooltip = Tooltip(
            target=my_widget,
            text="This is a helpful tip",
            delay=500  # ms
        )
    """

    tag = "tooltip"

    def __init__(
        self,
        target: WidgetBase | None = None,
        text: str = "",
        delay: int = 300,
        position: str = "bottom",
        **kwargs,
    ):
        """
        Initialize Tooltip.

        Args:
            target: Widget to attach tooltip to
            text: Text to display in tooltip
            delay: Delay in milliseconds before showing
            position: Position relative to target ("top", "bottom", "left", "right")
            **kwargs: Additional style props
        """
        super().__init__(**kwargs)
        self.target = target
        self.text = text
        self.delay = delay
        self.position = position
        self.visible = False
        self._hover_timer = 0
        self._last_hovered = False

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate tooltip layout."""
        padding, border_width = self._get_inner_bounds()

        # Calculate size based on text
        lines = self.text.split("\n")
        max_line_length = max(len(line) for line in lines) if lines else 0

        self.content_width = max_line_length + 2 * (padding + border_width)
        self.content_height = len(lines) + 2 * (padding + border_width)

        # Add border if present
        if self.style.get("border", "none") != "none":
            self.content_width += 2
            self.content_height += 2

        self.width = self.content_width
        self.height = self.content_height

        # Position tooltip relative to target
        if self.target:
            self._position_relative_to_target()

        return self.width, self.height

    def _position_relative_to_target(self) -> None:
        """Position tooltip relative to target widget."""
        if not self.target:
            return

        padding, border_width = self._get_inner_bounds()

        if self.position == "bottom":
            self.x = self.target.x
            self.y = self.target.y + self.target.height
        elif self.position == "top":
            self.x = self.target.x
            self.y = self.target.y - self.height
        elif self.position == "right":
            self.x = self.target.x + self.target.width
            self.y = self.target.y
        elif self.position == "left":
            self.x = self.target.x - self.width
            self.y = self.target.y

    def render_content(self, app: Any) -> None:
        """Render tooltip text."""
        if not self.visible:
            return

        padding, border_width = self._get_inner_bounds()
        x = self.x + padding + border_width
        y = self.y + padding + border_width

        lines = self.text.split("\n")
        for i, line in enumerate(lines):
            app.draw_text(x, y + i, line)

    def render(self, app: Any) -> None:
        """Render tooltip if visible."""
        if not self.visible:
            return

        self.apply_style(app)

        # Background
        if "background" in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width)
            self.apply_style(app)

        # Border
        if self.style.get("border", "none") != "none":
            self._draw_border(app)

        # Content
        self.render_content(app)

        app.write(RESET)

    def handle_mouse(self, event: MouseEvent, app: Any) -> bool:
        """Handle mouse events for hover detection."""
        if not self.target:
            return False

        term_x = event.x - 1
        term_y = event.y - 1

        # Check if hovering over target
        hovered = (
            self.target.x <= term_x < self.target.x + self.target.width
            and self.target.y <= term_y < self.target.y + self.target.height
        )

        if hovered and not self._last_hovered:
            # Start hover timer
            self._hover_timer = self.delay
            self._last_hovered = True
        elif not hovered:
            # Reset hover
            self._hover_timer = 0
            self.visible = False
            self._last_hovered = False

        return False

    def update(self, delta_ms: int) -> None:
        """
        Update tooltip state (call from app update loop).

        Args:
            delta_ms: Time elapsed since last frame in milliseconds
        """
        if self._hover_timer > 0:
            self._hover_timer -= delta_ms
            if self._hover_timer <= 0:
                self.visible = True
                self.calculate_layout(1000, 1000)  # Recalculate position

    def set_text(self, text: str) -> None:
        """Update tooltip text."""
        self.text = text
        if self.visible:
            self.calculate_layout(1000, 1000)

    def set_target(self, target: WidgetBase) -> None:
        """Set the target widget."""
        self.target = target
        if self.visible:
            self._position_relative_to_target()

    def show(self) -> None:
        """Force show the tooltip."""
        self.visible = True
        self._hover_timer = 0

    def hide(self) -> None:
        """Force hide the tooltip."""
        self.visible = False
        self._hover_timer = 0
