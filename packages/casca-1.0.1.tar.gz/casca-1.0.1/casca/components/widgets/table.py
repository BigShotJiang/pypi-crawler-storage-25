"""Table widget with sort/filter/column-size helpers."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from ...core.events import KeyEvent, Keys
from ...style.css import get_border_width, get_box_spacing
from .base import WidgetBase


class Table(WidgetBase):
    """Tabular data widget with basic sorting/filtering and row selection."""

    tag = "table"

    def __init__(
        self,
        columns: list[dict[str, Any] | str],
        rows: list[list[Any]] | None = None,
        selected_row: int = 0,
        on_select: Callable[[int, list[str]], None] | None = None,
        id: str = "",
        classes: str = "",
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.columns = self._normalize_columns(columns)
        self.rows = [[str(cell) for cell in row] for row in (rows or [])]
        self.filtered_rows = list(self.rows)
        self.selected_row = max(0, min(selected_row, max(0, len(self.filtered_rows) - 1)))
        self.scroll_offset = 0
        self.on_select = on_select
        self._column_widths: list[int] = []

        if "height" not in self.props:
            self.props["height"] = 8

    def _normalize_columns(self, columns):
        normalized = []
        for col in columns:
            if isinstance(col, str):
                normalized.append({"name": col, "width": max(5, len(col) + 2)})
            else:
                width = int(col.get("width", max(5, len(str(col.get("name", ""))) + 2)))
                normalized.append({"name": str(col.get("name", "")), "width": max(3, width)})
        return normalized

    def set_filter(self, query: str = ""):
        token = (query or "").strip().lower()
        if not token:
            self.filtered_rows = list(self.rows)
        else:
            self.filtered_rows = [
                row for row in self.rows if token in " ".join(cell.lower() for cell in row)
            ]
        self.selected_row = 0
        self.scroll_offset = 0

    def sort_by(self, column: int | str, reverse: bool = False):
        idx = 0
        if isinstance(column, str):
            for i, col in enumerate(self.columns):
                if col["name"] == column:
                    idx = i
                    break
        else:
            idx = max(0, min(int(column), len(self.columns) - 1))

        self.rows.sort(key=lambda row: row[idx] if idx < len(row) else "", reverse=reverse)
        self.set_filter("")

    def resize_column(self, column: int | str, width: int):
        idx = 0
        if isinstance(column, str):
            for i, col in enumerate(self.columns):
                if col["name"] == column:
                    idx = i
                    break
        else:
            idx = max(0, min(int(column), len(self.columns) - 1))
        self.columns[idx]["width"] = max(3, int(width))

    def _visible_rows(self) -> int:
        pad_top, _pad_right, pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        inner = max(1, self.height - (pad_top + pad_bottom + 2 * border_width))
        return max(1, inner - 2)

    def _ensure_visible(self):
        if not self.filtered_rows:
            self.selected_row = 0
            self.scroll_offset = 0
            return
        self.selected_row = max(0, min(self.selected_row, len(self.filtered_rows) - 1))
        visible = self._visible_rows()
        if self.selected_row < self.scroll_offset:
            self.scroll_offset = self.selected_row
        elif self.selected_row >= self.scroll_offset + visible:
            self.scroll_offset = self.selected_row - visible + 1

    def _emit_select(self):
        if self.on_select and self.filtered_rows:
            self.on_select(self.selected_row, self.filtered_rows[self.selected_row])

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        natural_inner = (
            2 + sum(col["width"] for col in self.columns) + max(0, len(self.columns) - 1) * 3
        )
        natural_width = natural_inner + pad_left + pad_right + 2 * border_width
        self.width = int(self.props.get("width", natural_width))
        self.height = int(self.props.get("height", 8))

        inner_width = max(1, self.width - pad_left - pad_right - 2 * border_width)
        separator_space = max(0, len(self.columns) - 1) * 3
        prefix = 2
        remaining = max(1, inner_width - separator_space - prefix)
        widths = [int(col["width"]) for col in self.columns]
        if sum(widths) > remaining:
            overflow = sum(widths) - remaining
            while overflow > 0:
                changed = False
                for i in sorted(range(len(widths)), key=lambda j: widths[j], reverse=True):
                    if widths[i] > 3:
                        widths[i] -= 1
                        overflow -= 1
                        changed = True
                        if overflow == 0:
                            break
                if not changed:
                    break
        self._column_widths = widths
        self._ensure_visible()
        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def _format_row(self, values: list[str], selected: bool = False) -> str:
        cells = []
        for i, width in enumerate(self._column_widths):
            cell = values[i] if i < len(values) else ""
            cells.append(cell[:width].ljust(width))
        row = " | ".join(cells)
        return ("> " if selected else "  ") + row

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        inner_width = max(1, self.width - pad_left - pad_right - 2 * border_width)
        x = self.x + pad_left + border_width + 1
        y = self.y + pad_top + border_width + 1

        header = self._format_row([col["name"] for col in self.columns], selected=False)
        app.draw_text(x, y, header[:inner_width])
        app.draw_text(x, y + 1, ("-" * inner_width)[:inner_width])

        visible = self._visible_rows()
        for row_slot in range(visible):
            idx = self.scroll_offset + row_slot
            if idx < len(self.filtered_rows):
                line = self._format_row(
                    self.filtered_rows[idx], selected=(idx == self.selected_row)
                )
            else:
                line = ""
            app.draw_text(x, y + 2 + row_slot, line[:inner_width])

    def handle_input(self, event: KeyEvent) -> bool:
        if self._disabled:
            return False

        if event.key == Keys.UP:
            self.selected_row = max(0, self.selected_row - 1)
            self._ensure_visible()
            self._emit_select()
            return True
        if event.key == Keys.DOWN:
            if self.filtered_rows:
                self.selected_row = min(len(self.filtered_rows) - 1, self.selected_row + 1)
            self._ensure_visible()
            self._emit_select()
            return True

        return super().handle_input(event)
