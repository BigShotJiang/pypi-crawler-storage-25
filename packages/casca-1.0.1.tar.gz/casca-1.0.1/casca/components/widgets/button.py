"""
Button Widget Module.

Provides the Button widget for user interaction.
"""

from collections.abc import Callable
from typing import Any

from ...core.events import MouseEvent
from .label import Label


class Button(Label):
    """
    Clickable button that triggers callbacks on interaction.

    Supports keyboard (Enter/Space) and mouse clicks.

    Example:
        ```python
        Button(
            "Click Me",
            on_click=lambda e: print("Clicked!"),
        )
        ```
    """

    tag = "button"

    def __init__(
        self,
        label: str = "",
        id: str = "",
        classes: str = "",
        on_click: Callable[[MouseEvent], None] | None = None,
        **props,
    ) -> None:
        """
        Initialize a Button widget.

        Args:
            label: Button text.
            id: Unique identifier for CSS targeting.
            classes: Space-separated CSS class names.
            on_click: Callback when button is clicked.
            **props: Additional properties.
        """
        super().__init__(text=label, id=id, classes=classes, **props)
        self.on_click = on_click

    def handle_input(self, event: Any) -> bool:
        """
        Handle keyboard input - triggers on Enter or Space.

        Args:
            event: The key event to handle.

        Returns:
            True if the event was consumed.
        """
        if self._disabled:
            return False

        if event.key in ("\r", " "):  # Enter or Space
            if self.on_click:
                self.on_click(event)
                return True
        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        """
        Handle mouse clicks - triggers on press for terminal compatibility.

        Args:
            event: The mouse event to handle.

        Returns:
            True if the event was consumed.
        """
        if self._disabled:
            return False

        if event.button != 0:
            return False

        # Some terminals/modes only emit press events, so trigger on press.
        if event.pressed:
            if self.on_click:
                self.on_click(event)
        # Consume both press/release so ancestors don't treat release as a separate action.
        return True

    def render_content(self, app: Any) -> None:
        """
        Render button text without changing layout width on focus.

        Args:
            app: The application instance for rendering.
        """
        from ...style.css import get_border_width, get_box_spacing

        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)

        for i, line in enumerate(self.lines):
            app.draw_text(
                self.x + pad_left + border_width + 1, self.y + pad_top + border_width + 1 + i, line
            )
