"""Spinner widget for compact activity indication."""

from ...style.css import get_border_width, get_box_spacing
from .base import WidgetBase


class Spinner(WidgetBase):
    """Render an animated frame sequence; advance it manually via tick()."""

    tag = "spinner"

    def __init__(
        self,
        text: str = "",
        frames: list[str] | None = None,
        interval: float = 0.1,
        id: str = "",
        classes: str = "",
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.text = text
        self.frames = frames or ["|", "/", "-", "\\"]
        self.interval = interval
        self.frame_index = 0

    @property
    def current_frame(self) -> str:
        if not self.frames:
            return ""
        return self.frames[self.frame_index % len(self.frames)]

    def tick(self, steps: int = 1):
        if not self.frames:
            return
        self.frame_index = (self.frame_index + steps) % len(self.frames)

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        content = self.current_frame
        if self.text:
            content = f"{content} {self.text}"

        self.width = int(
            self.props.get("width", len(content) + pad_left + pad_right + 2 * border_width)
        )
        self.height = int(self.props.get("height", 1 + pad_top + pad_bottom + 2 * border_width))

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)

        inner_width = max(1, self.width - pad_left - pad_right - (2 * border_width))
        content = self.current_frame
        if self.text:
            content = f"{content} {self.text}"

        app.draw_text(
            self.x + pad_left + border_width + 1,
            self.y + pad_top + border_width + 1,
            content[:inner_width],
        )
