"""
Grid widget - CSS Grid-like layout container.
"""

from typing import Any

from ..widgets.base import WidgetBase


class Grid(WidgetBase):
    """A 2D grid layout container similar to CSS Grid."""

    tag = "grid"

    def __init__(
        self,
        *children,
        columns: str = "1fr",
        rows: str = "auto",
        gap: int = 0,
        row_gap: int | None = None,
        column_gap: int | None = None,
        id: str = "",
        classes: str = "",
        **props,
    ):
        super().__init__(*children, id=id, classes=classes, **props)
        self.columns_def = columns
        self.rows_def = rows
        self.gap = gap
        self.row_gap = row_gap if row_gap is not None else gap
        self.column_gap = column_gap if column_gap is not None else gap
        self.column_tracks: list[int] = []
        self.row_tracks: list[int] = []
        self.column_positions: list[int] = []
        self.row_positions: list[int] = []
        self.grid_children: list[tuple[WidgetBase, dict[str, Any]]] = []
        for child in children:
            self.add(child)

    def add(self, child: WidgetBase, **grid_props: Any) -> None:
        """Add child with grid placement props."""
        self.children.append(child)
        self.grid_children.append((child, grid_props))

    def _parse_tracks(self, definition: str, available: int) -> list[int]:
        """Parse track definition into sizes."""
        if not definition.strip():
            return [available]
        tracks = definition.split()
        sizes = []
        fr_sum = 0
        fixed = 0
        for t in tracks:
            if t.endswith("fr"):
                val = int(t[:-2]) if t[:-2].isdigit() else 1
                sizes.append(("fr", val))
                fr_sum += val
            elif t.endswith("px"):
                val = int(t[:-2])
                sizes.append(("px", val))
                fixed += val
            elif t == "auto":
                sizes.append(("auto", 1))
                fr_sum += 1
            else:
                try:
                    val = int(t)
                    sizes.append(("px", val))
                    fixed += val
                except (ValueError, TypeError):
                    sizes.append(("fr", 1))
                    fr_sum += 1
        remaining = max(0, available - fixed)
        result = []
        for typ, val in sizes:
            if typ == "px":
                result.append(val)
            elif fr_sum > 0:
                result.append(int(remaining * val / fr_sum))
            else:
                result.append(0)
        return result

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate grid layout."""
        padding, border_width = self._get_inner_bounds()
        inner_w = max(0, available_width - 2 * (padding + border_width))
        inner_h = max(0, available_height - 2 * (padding + border_width))

        self.column_tracks = self._parse_tracks(self.columns_def, inner_w)
        self.row_tracks = self._parse_tracks(self.rows_def, inner_h)

        # Calculate positions
        self.column_positions = [0]
        for w in self.column_tracks:
            self.column_positions.append(self.column_positions[-1] + w + self.column_gap)

        self.row_positions = [0]
        for h in self.row_tracks:
            self.row_positions.append(self.row_positions[-1] + h + self.row_gap)

        # Place children
        auto_col = 1
        auto_row = 1
        for child, props in self.grid_children:
            col_start, col_end = self._parse_placement(
                props.get("grid_column", str(auto_col)), len(self.column_tracks)
            )
            row_start, row_end = self._parse_placement(
                props.get("grid_row", str(auto_row)), len(self.row_tracks)
            )

            child.x = self.x + padding + border_width + self.column_positions[col_start - 1]
            child.y = self.y + padding + border_width + self.row_positions[row_start - 1]
            child.width = (
                self.column_positions[col_end]
                - self.column_positions[col_start - 1]
                - self.column_gap
            )
            child.height = (
                self.row_positions[row_end] - self.row_positions[row_start - 1] - self.row_gap
            )

            auto_col = col_end + 1
            if auto_col > len(self.column_tracks):
                auto_col = 1
                auto_row += 1

        self.width = available_width
        self.height = available_height
        return self.width, self.height

    def _parse_placement(self, placement: str, max_tracks: int) -> tuple[int, int]:
        """Parse grid-column or grid-row placement."""
        placement = str(placement).strip()
        if "/" in placement:
            parts = placement.split("/")
            start = int(parts[0].strip())
            end_str = parts[1].strip()
            if "span" in end_str:
                span = int(end_str.replace("span", "").strip())
                end = start + span
            else:
                end = int(end_str)
        else:
            start = int(placement)
            end = start + 1
        return max(1, start), min(end, max_tracks + 1)

    def render_content(self, app: Any) -> None:
        """Render grid children."""
        for child, _ in self.grid_children:
            child.render(app)
