"""
Menu widget - Horizontal menu bar for applications.
"""

from collections.abc import Callable
from typing import Any

from ...core.events import KeyEvent, Keys, MouseEvent
from ..widgets.base import WidgetBase


class MenuItem(WidgetBase):
    """
    A single menu item in a Menu bar.

    Features:
    - Clickable menu item
    - Keyboard navigation support
    - Hover highlighting
    - Disabled state
    """

    tag = "menu-item"

    def __init__(
        self,
        label: str,
        on_click: Callable[[], None] | None = None,
        shortcut: str | None = None,
        **kwargs,
    ):
        """
        Initialize MenuItem.

        Args:
            label: Text to display
            on_click: Callback when item is clicked
            shortcut: Keyboard shortcut (e.g., "Ctrl+S")
            **kwargs: Additional style props
        """
        super().__init__(**kwargs)
        self.label = label
        self.on_click = on_click
        self.shortcut = shortcut
        self._hovered = False

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout for menu item."""
        padding, border_width = self._get_inner_bounds()

        # Menu items have fixed height
        self.height = 1 + 2 * (padding + border_width)

        # Width based on label
        self.width = len(self.label) + 2 * (padding + border_width)
        if self.shortcut:
            self.width += len(self.shortcut) + 2

        return self.width, self.height

    def render_content(self, app: Any) -> None:
        """Render menu item label."""
        padding, border_width = self._get_inner_bounds()
        x = self.x + padding + border_width
        y = self.y + padding + border_width

        # Background for hovered/selected
        if self._hovered or self.focused:
            app.draw_text(x - 1, y, " " * (self.width - 2 * (padding + border_width)))

        # Render label
        app.draw_text(x, y, self.label)

        # Render shortcut
        if self.shortcut:
            shortcut_x = x + len(self.label) + 2
            app.draw_text(shortcut_x, y, self.shortcut)

    def handle_mouse(self, event: MouseEvent, app: Any) -> bool:
        """Handle mouse hover and click."""
        term_x = event.x - 1
        term_y = event.y - 1

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            # Update hover state
            self._hovered = True

            if event.pressed and self.on_click and not self._disabled:
                self.on_click()
                return True

            return True
        else:
            self._hovered = False

        return False

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard events."""
        if self._disabled:
            return False

        if event.key == Keys.ENTER and self.on_click:
            self.on_click()
            return True

        return False


class Menu(WidgetBase):
    """
    Horizontal menu bar for applications.

    Features:
    - Horizontal layout of menu items
    - Keyboard navigation (arrow keys)
    - Mouse hover and click support
    - Disabled state support
    - CSS styling support

    Usage:
        menu = Menu(
            MenuItem("File", on_click=open_file),
            MenuItem("Edit", on_click=edit),
            MenuItem("Help", on_click=show_help),
            id="main-menu"
        )
    """

    tag = "menu"

    def __init__(self, *items: MenuItem, **kwargs):
        """
        Initialize Menu.

        Args:
            *items: MenuItem instances
            **kwargs: Additional style props
        """
        super().__init__(**kwargs)
        for item in items:
            self.children.append(item)

        self.selected_index = 0

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate horizontal layout for menu items."""
        padding, border_width = self._get_inner_bounds()
        margin = int(self.style.get("margin", 0))

        # Menu bar has fixed height
        self.height = 1 + 2 * (padding + border_width)

        # Layout items horizontally
        current_x = padding + border_width
        total_width = 0

        for child in self.children:
            child.x = self.x + current_x
            child.y = self.y + padding + border_width

            child_width, child_height = child.calculate_layout(available_width - current_x, 1)

            current_x += child_width + 1  # 1 space between items
            total_width += child_width + 1

        self.content_width = current_x
        self.width = total_width + 2 * (padding + border_width)

        return self.width + margin * 2, self.height + margin * 2

    def render_content(self, app: Any) -> None:
        """Render menu bar background."""
        # Background fill
        if "background" in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width)

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard navigation."""
        if self._disabled or not self.children:
            return False

        if event.key == Keys.LEFT:
            self.selected_index = max(0, self.selected_index - 1)
            self._focus_selected()
            return True
        elif event.key == Keys.RIGHT:
            self.selected_index = min(len(self.children) - 1, self.selected_index + 1)
            self._focus_selected()
            return True
        elif event.key == Keys.ENTER:
            if self.selected_index < len(self.children):
                item = self.children[self.selected_index]
                if item.on_click:
                    item.on_click()
                    return True

        # Delegate to selected child
        if self.selected_index < len(self.children):
            return self.children[self.selected_index].handle_input(event)

        return False

    def handle_mouse(self, event: MouseEvent, app: Any) -> bool:
        """Handle mouse events."""
        if self._disabled:
            return False

        # Propagate to children
        for child in reversed(self.children):
            if child.handle_mouse(event, app):
                return True

        return False

    def _focus_selected(self) -> None:
        """Update focus to selected item."""
        for i, child in enumerate(self.children):
            child.focused = i == self.selected_index
            child._hovered = i == self.selected_index

    def select_item(self, index: int) -> None:
        """Select menu item by index."""
        if 0 <= index < len(self.children):
            self.selected_index = index
            self._focus_selected()

    def select_item_by_label(self, label: str) -> None:
        """Select menu item by label."""
        for i, child in enumerate(self.children):
            if child.label == label:
                self.select_item(i)
                return
