"""
Casca Widget Base Module.

Provides WidgetBase, an enhanced base widget with common styling and rendering helpers.
"""

from typing import Any

from ...core.ansi import (
    BLINK,
    BOLD,
    FAINT,
    ITALIC,
    RESET,
    REVERSE,
    STRIKETHROUGH,
    UNDERLINE,
    color_from_spec,
)
from ...core.events import KeyEvent, MouseEvent
from ...dom.node import Widget
from ...style.css import get_border_width, get_box_spacing

# Interactive widget tags that can receive focus
_INTERACTIVE_TAGS: set[str] = {
    "input",
    "textarea",
    "checkbox",
    "select",
    "listview",
    "datagrid",
    "radiogroup",
    "treeview",
    "table",
    "command-palette",
    "button",
}


class WidgetBase(Widget):
    """
    Enhanced base widget class with common styling and rendering helpers.

    Extends Widget with:
    - Disabled state management
    - Enhanced border drawing with multiple styles
    - Background fill utilities
    - Consistent event handling with disabled state checks

    All widgets should inherit from this class to get consistent behavior.
    """

    tag: str = "widget_base"

    def __init__(self, *children: Widget, id: str = "", classes: str = "", **props: Any) -> None:
        """
        Initialize a WidgetBase instance.

        Args:
            *children: Child widgets to contain.
            id: Unique identifier for CSS targeting.
            classes: Space-separated CSS class names.
            **props: Additional properties (e.g., width, height, style).
        """
        super().__init__(*children, id=id, classes=classes, **props)

        # Visual state
        self._hovered: bool = False
        self._disabled: bool = False

    @property
    def disabled(self) -> bool:
        """Check if widget is disabled."""
        return self._disabled

    @disabled.setter
    def disabled(self, value: bool) -> None:
        """
        Set disabled state.

        Args:
            value: True to disable, False to enable.
        """
        self._disabled = value
        if value and self.focused:
            self.focused = False

    def apply_style(self, app: Any) -> None:
        """
        Apply the computed style to the terminal output.

        Extends parent apply_style with disabled state styling.

        Args:
            app: The application instance for writing ANSI codes.
        """
        app.write(RESET)
        fg_color = self.style.get("color", "default")
        bg_color = self.style.get("background", "default")

        # Override color for invalid state
        if getattr(self, "invalid", False):
            fg_color = self.style.get("error-color", "bright_red")

        app.write(color_from_spec(fg_color, bg_color))

        # Apply text styling
        if self.style.get("font-weight") == "bold":
            app.write(BOLD)
        if self.style.get("font-style") == "italic":
            app.write(ITALIC)
        decoration = self.style.get("text-decoration", "")
        if "underline" in decoration:
            app.write(UNDERLINE)
        if "line-through" in decoration:
            app.write(STRIKETHROUGH)
        if self.style.get("font-effect") == "blink":
            app.write(BLINK)
        if self.style.get("font-effect") == "reverse":
            app.write(REVERSE)
        if "opacity" in self.style and float(self.style["opacity"]) < 1.0:
            app.write(FAINT)

        # Apply disabled state styling
        if self._disabled:
            app.write(FAINT)

    def _draw_background_fill(self, app: Any, char: str = " ") -> None:
        """
        Draw background fill for the widget.

        Args:
            app: The application instance for rendering.
            char: Character to use for background fill.
        """
        if "background" in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, char * self.width)

    def _draw_border(self, app: Any) -> None:
        """
        Draw border around the widget with styles like solid, rounded, double, ascii.

        Supported border styles:
        - ascii: Basic ASCII characters (+, -, |)
        - solid: Single-line box drawing characters
        - rounded: Rounded corners
        - double: Double-line box drawing characters
        - thick: Bold box drawing characters
        - dashed: Dashed lines

        Args:
            app: The application instance for rendering.
        """
        if self.width <= 0 or self.height <= 0:
            return

        border_type = self.style.get("border", "solid")
        border_color = self.style.get("border-color", self.style.get("color", "default"))

        # Set color for border
        app.write(color_from_spec(border_color, self.style.get("background", "default")))

        # Border character definitions
        # tuple order: top-left, top, top-right, right, bottom-left, bottom, bottom-right, left
        chars: dict[str, tuple[str, ...]] = {
            "ascii": ("+", "-", "+", "|", "+", "-", "+", "|"),
            "solid": ("┌", "─", "┐", "│", "└", "─", "┘", "│"),
            "rounded": ("╭", "─", "╮", "│", "╰", "─", "╯", "│"),
            "double": ("╔", "═", "╗", "║", "╚", "═", "╝", "║"),
            "thick": ("┏", "━", "┓", "┃", "┗", "━", "┛", "┃"),
            "dashed": ("┌", "╌", "┐", "┆", "└", "╌", "┘", "┆"),
        }

        # Fallback to single char if explicitly set or block if unsupported
        c_tl, c_t, c_tr, c_r, c_bl, c_b, c_br, c_l = chars.get(border_type, chars["solid"])

        # Override if border-char is set manually
        custom_char = self.style.get("border-char")
        if custom_char:
            c_tl = c_t = c_tr = c_r = c_br = c_b = c_bl = c_l = custom_char[0]

        # Top border
        top_line = c_tl + (c_t * (self.width - 2)) + (c_tr if self.width > 1 else "")
        app.draw_text(self.x + 1, self.y + 1, top_line[: self.width])

        # Bottom border
        if self.height > 1:
            bottom_line = c_bl + (c_b * (self.width - 2)) + (c_br if self.width > 1 else "")
            app.draw_text(self.x + 1, self.y + self.height, bottom_line[: self.width])

        # Side borders
        for r in range(1, self.height - 1):
            app.draw_text(self.x + 1, self.y + r + 1, c_l)
            if self.width > 1:
                app.draw_text(self.x + self.width, self.y + r + 1, c_r)

        # Reset color back to what widget needs
        self.apply_style(app)

    def _get_inner_bounds(self) -> tuple[int, int]:
        """
        Get the inner content bounds accounting for padding and border.

        Returns:
            Tuple of (padding_size, border_width).
        """
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        padding = max(pad_top, pad_left)
        return padding, border_width

    def handle_input(self, event: KeyEvent) -> bool:
        """
        Handle keyboard input - passes to children by default.

        Returns False immediately if widget is disabled.

        Args:
            event: The key event to handle.

        Returns:
            True if the event was consumed.
        """
        if self._disabled:
            return False

        for child in reversed(self.children):
            if child.handle_input(event):
                return True
        return False

    def handle_mouse(self, event: MouseEvent, app: Any) -> bool:
        """
        Handle mouse input - checks bounds and passes to children.

        Returns False immediately if widget is disabled.

        Args:
            event: The mouse event to handle.
            app: The application instance.

        Returns:
            True if the event was consumed.
        """
        if self._disabled:
            return False

        # Terminal coordinates are 1-based, widget coordinates are 0-based
        # Event coordinates are 1-based terminal coordinates
        # Widget x,y are 0-based but rendered at x+1, y+1 (1-based)
        term_x = event.x - 1
        term_y = event.y - 1

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            # Propagate to children first (highest z-index effectively)
            for child in reversed(self.children):
                if child.handle_mouse(event, app):
                    return True

            # Handle focus for interactive widgets
            if event.pressed and self.tag in _INTERACTIVE_TAGS:
                if app.focused_widget and app.focused_widget != self:
                    app.focused_widget.focused = False
                app.focused_widget = self
                self.focused = True
                if self.id:
                    app.focused_id = self.id

            # Call widget-specific mouse handler
            handled = self.on_mouse(event) or (event.pressed and self.tag in _INTERACTIVE_TAGS)

            # Special case for scroll wheel
            if not handled and event.button in (64, 65):
                return getattr(self, "handle_wheel", lambda e, a: False)(event, app)

            return handled
        return False

    def render(self, app: Any) -> None:
        """
        Standard render pipeline for all widgets.

        Render order:
        1. Apply styles
        2. Draw background
        3. Draw border
        4. Render content
        5. Render children

        Args:
            app: The application instance for rendering.
        """
        self.apply_style(app)

        # Draw background
        self._draw_background_fill(app)
        self.apply_style(app)

        # Draw border if present
        if self.style.get("border", "none") != "none":
            self._draw_border(app)

        # Draw widget-specific content
        self.render_content(app)

        # Draw children
        for child in self.children:
            child.render(app)
            self.apply_style(app)

        app.write(RESET)

    def render_content(self, app: Any) -> None:
        """
        Override to implement specific widget content rendering.

        Args:
            app: The application instance for rendering.
        """
        pass

    def on_mouse(self, event: MouseEvent) -> bool:
        """
        Override for widget-specific mouse handling.

        Args:
            event: The mouse event to handle.

        Returns:
            True if the event was consumed.
        """
        return False
