"""
Label widget for displaying text.
"""

import textwrap

from ...style.css import clamp_dimension, get_border_width, get_box_spacing, parse_size
from .base import WidgetBase


class Label(WidgetBase):
    """
    Displays text with automatic wrapping based on layout boundaries.

    Supports multi-line text using \\n character.
    """

    tag = "label"

    def __init__(self, text: str = "", id: str = "", classes: str = "", **props):
        super().__init__(id=id, classes=classes, **props)
        self.text = text
        self.lines: list[str] = []
        self._layout_warnings: list[str] = []

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate size based on text content, wrapping, and overflow rules."""
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")

        white_space = str(self.style.get("white-space", "normal")).strip().lower()
        overflow_mode = str(self.style.get("text-overflow", "clip")).strip().lower()
        self._layout_warnings = []
        clipped_any = False
        vertically_clipped = False

        spacing_raw = parse_size(self.style.get("letter-spacing", 0), available_width, 0)
        letter_spacing = max(0, int(spacing_raw or 0))

        def _apply_letter_spacing(text: str) -> str:
            if letter_spacing <= 0 or len(text) <= 1:
                return text
            return (" " * letter_spacing).join(text)

        # Calculate available inner width for wrapping.
        inner_width = (
            available_width - mar_left - mar_right - pad_left - pad_right - (border_width * 2)
        )

        w_prop = self.props.get("width") or self.style.get("width")
        explicit_width = w_prop is not None
        if explicit_width:
            resolved_w = clamp_dimension(
                w_prop, self.style, "width", available_width, available_width
            )
            inner_width = resolved_w - pad_left - pad_right - (border_width * 2)

        inner_width = max(0, inner_width)

        def _clip_with_overflow(line: str, width: int) -> str:
            nonlocal clipped_any
            if len(line) <= width:
                return line
            clipped_any = True
            if overflow_mode == "ellipsis" and width > 0:
                if width <= 3:
                    return "." * width
                return line[: width - 3] + "..."
            return line[:width]

        # Parse and wrap text.
        self.lines = []
        raw_lines = self.text.split("\n")
        for raw in raw_lines:
            if inner_width <= 0:
                self.lines.append("")
                continue

            if white_space == "nowrap":
                self.lines.append(_clip_with_overflow(_apply_letter_spacing(raw), inner_width))
                continue

            wrapped = textwrap.wrap(raw, max(1, inner_width))
            if not wrapped:
                self.lines.append("")
                continue

            for chunk in wrapped:
                self.lines.append(_clip_with_overflow(_apply_letter_spacing(chunk), inner_width))

        h_prop = self.props.get("height") or self.style.get("height")
        explicit_height = h_prop is not None
        if explicit_height:
            resolved_h = clamp_dimension(
                h_prop, self.style, "height", available_height, available_height
            )
            max_lines = max(0, resolved_h - pad_top - pad_bottom - (border_width * 2))
            if max_lines == 0:
                self.lines = []
            elif len(self.lines) > max_lines:
                self.lines = self.lines[:max_lines]
                vertically_clipped = True
                if self.lines and overflow_mode == "ellipsis" and inner_width > 0:
                    self.lines[-1] = _clip_with_overflow(self.lines[-1], inner_width)

        if clipped_any:
            self._layout_warnings.append("Text clipped to fit label width")
        if vertically_clipped:
            self._layout_warnings.append("Text clipped to fit label height")

        self.content_height = len(self.lines)
        self.content_width = max([len(line) for line in self.lines] + [0])

        if explicit_width:
            self.width = clamp_dimension(
                w_prop,
                self.style,
                "width",
                available_width,
                self.content_width + pad_left + pad_right + border_width * 2,
            )
        else:
            content_w = self.content_width + pad_left + pad_right + border_width * 2
            self.width = clamp_dimension(content_w, self.style, "width", available_width, content_w)

        if explicit_height:
            self.height = clamp_dimension(
                h_prop,
                self.style,
                "height",
                available_height,
                self.content_height + pad_top + pad_bottom + border_width * 2,
            )
        else:
            content_h = self.content_height + pad_top + pad_bottom + border_width * 2
            self.height = clamp_dimension(
                content_h, self.style, "height", available_height, content_h
            )

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        """Render the text content."""
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)

        for i, line in enumerate(self.lines):
            app.draw_text(
                self.x + pad_left + border_width + 1, self.y + pad_top + border_width + 1 + i, line
            )

    def set_text(self, text: str):
        """Update the label text and trigger layout recalculation."""
        self.text = text
        # Parent should call calculate_layout again

    def get_layout_warnings(self) -> list[str]:
        return list(self._layout_warnings)
