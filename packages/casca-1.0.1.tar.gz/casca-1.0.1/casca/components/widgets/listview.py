"""ListView widget for selectable scrolling lists."""

from collections.abc import Callable

from ...core.events import KeyEvent, MouseEvent
from ...style.css import get_border_width, get_box_spacing
from .base import WidgetBase


class ListView(WidgetBase):
    """A simple list widget with keyboard and mouse selection."""

    tag = "listview"

    def __init__(
        self,
        items: list[str],
        selected_index: int = 0,
        id: str = "",
        classes: str = "",
        on_change: Callable[[str, int], None] | None = None,
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.items = items or [""]
        self.selected_index = max(0, min(selected_index, len(self.items) - 1))
        self.on_change = on_change
        self.scroll_offset = 0

        if "height" not in self.props:
            self.props["height"] = 6

    @property
    def value(self) -> str:
        return self.items[self.selected_index]

    def _emit_change(self):
        if self.on_change:
            self.on_change(self.value, self.selected_index)

    def _visible_rows(self) -> int:
        pad_top, _pad_right, pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        return max(1, self.height - (pad_top + pad_bottom + 2 * border_width))

    def _ensure_visible(self):
        visible = self._visible_rows()
        if self.selected_index < self.scroll_offset:
            self.scroll_offset = self.selected_index
        elif self.selected_index >= self.scroll_offset + visible:
            self.scroll_offset = self.selected_index - visible + 1

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")
        border_width = get_border_width(self.style)

        max_len = max(len(item) for item in self.items)
        min_width = max_len + 3
        self.width = int(
            self.props.get("width", min_width + pad_left + pad_right + 2 * border_width)
        )
        self.height = int(self.props.get("height", 6))

        self._ensure_visible()
        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def render_content(self, app):
        pad_top, pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        inner_width = max(1, self.width - (pad_left + pad_right + 2 * border_width))
        visible = self._visible_rows()

        for row in range(visible):
            idx = self.scroll_offset + row
            if idx >= len(self.items):
                line = ""
            else:
                prefix = "> " if idx == self.selected_index else "  "
                line = f"{prefix}{self.items[idx]}"

            app.draw_text(
                self.x + pad_left + border_width + 1,
                self.y + pad_top + border_width + 1 + row,
                line[:inner_width],
            )

    def handle_input(self, event: KeyEvent) -> bool:
        if self._disabled:
            return False

        if event.key == "\x1b[A":
            self.selected_index = max(0, self.selected_index - 1)
            self._ensure_visible()
            self._emit_change()
            return True

        if event.key == "\x1b[B":
            self.selected_index = min(len(self.items) - 1, self.selected_index + 1)
            self._ensure_visible()
            self._emit_change()
            return True

        return super().handle_input(event)

    def on_mouse(self, event: MouseEvent) -> bool:
        if self._disabled:
            return False

        if event.button in (64, 65):
            if event.button == 64:
                self.scroll_offset = max(0, self.scroll_offset - 1)
            else:
                max_offset = max(0, len(self.items) - self._visible_rows())
                self.scroll_offset = min(max_offset, self.scroll_offset + 1)
            return True

        if event.button != 0 or event.pressed:
            return False

        pad_top, _pad_right, _pad_bottom, _pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        local_row = (event.y - 1) - self.y - pad_top - border_width
        if local_row < 0:
            return False

        idx = self.scroll_offset + local_row
        if 0 <= idx < len(self.items):
            self.selected_index = idx
            self._ensure_visible()
            self._emit_change()
            return True
        return False
