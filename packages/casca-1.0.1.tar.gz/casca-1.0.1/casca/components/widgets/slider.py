"""
Slider widget - Range input for numeric values.
"""

from collections.abc import Callable
from typing import Any

from ...core.events import KeyEvent, Keys, MouseEvent
from ..widgets.base import WidgetBase


class Slider(WidgetBase):
    """
    A horizontal slider for selecting numeric values.

    Features:
    - Horizontal slider with thumb control
    - Keyboard navigation (arrow keys)
    - Mouse drag support
    - Min/max value constraints
    - Step size configuration
    - Value change callback
    - CSS styling support

    Usage:
        ```python
        # Basic slider
        slider = Slider(
            min=0,
            max=100,
            value=50,
            on_change=lambda v: logger.info(f"Value changed to: {v}")
        )

        # Slider with step
        slider = Slider(
            min=0,
            max=10,
            step=0.5,
            value=5.0
        )
        ```
    """

    tag = "slider"

    def __init__(
        self,
        min: float = 0,
        max: float = 100,
        value: float | None = None,
        step: float = 1,
        on_change: Callable[[float], None] | None = None,
        orientation: str = "horizontal",
        **kwargs,
    ):
        """
        Initialize Slider.

        Args:
            min: Minimum value
            max: Maximum value
            value: Initial value (defaults to min)
            step: Step size for increments
            on_change: Callback when value changes
            orientation: "horizontal" or "vertical"
            **kwargs: Additional style props
        """
        super().__init__(**kwargs)
        self.min = min
        self.max = max
        self.value = value if value is not None else min
        self.step = step
        self.on_change = on_change
        self.orientation = orientation
        self._dragging = False

    @property
    def normalized_value(self) -> float:
        """Get normalized value (0.0 to 1.0)."""
        if self.max == self.min:
            return 0.0
        return (self.value - self.min) / (self.max - self.min)

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate slider layout."""
        padding, border_width = self._get_inner_bounds()
        margin = int(self.style.get("margin", 0))

        if self.orientation == "horizontal":
            # Horizontal slider
            self.width = max(10, available_width)
            self.height = 3 + 2 * (padding + border_width)
        else:
            # Vertical slider
            self.width = 3 + 2 * (padding + border_width)
            self.height = max(10, available_height)

        return self.width + margin * 2, self.height + margin * 2

    def render_content(self, app: Any) -> None:
        """Render slider track and thumb."""
        padding, border_width = self._get_inner_bounds()

        if self.orientation == "horizontal":
            self._render_horizontal(app, padding, border_width)
        else:
            self._render_vertical(app, padding, border_width)

    def _render_horizontal(self, app: Any, padding: int, border_width: int) -> None:
        """Render horizontal slider."""
        track_y = self.y + padding + border_width + 1
        track_x_start = self.x + padding + border_width
        track_x_end = self.x + self.width - padding - border_width
        track_length = track_x_end - track_x_start

        # Draw track
        track_char = self.style.get("slider-track", "─")
        app.draw_text(track_x_start, track_y, track_char * track_length)

        # Draw thumb
        thumb_pos = int(self.normalized_value * (track_length - 1))
        thumb_x = track_x_start + thumb_pos
        thumb_char = self.style.get("slider-thumb", "●")

        if self.focused or self._dragging:
            thumb_char = self.style.get("slider-thumb-focused", "◉")

        app.draw_text(thumb_x, track_y, thumb_char)

        # Draw value label if enabled
        if self.style.get("show-value", False):
            value_str = f"{self.value:.1f}"
            value_x = track_x_end - len(value_str)
            app.draw_text(value_x, track_y, value_str)

    def _render_vertical(self, app: Any, padding: int, border_width: int) -> None:
        """Render vertical slider."""
        track_x = self.x + padding + border_width + 1
        track_y_start = self.y + self.height - padding - border_width - 1
        track_y_end = self.y + padding + border_width
        track_length = track_y_start - track_y_end

        # Draw track
        track_char = self.style.get("slider-track", "│")
        for y in range(track_y_end, track_y_start + 1):
            app.draw_text(track_x, y, track_char)

        # Draw thumb
        thumb_pos = int(self.normalized_value * (track_length - 1))
        thumb_y = track_y_start - thumb_pos
        thumb_char = self.style.get("slider-thumb", "●")

        if self.focused or self._dragging:
            thumb_char = self.style.get("slider-thumb-focused", "◉")

        app.draw_text(track_x, thumb_y, thumb_char)

    def _value_from_position(self, x: int, y: int) -> float:
        """Calculate value from mouse position."""
        padding, border_width = self._get_inner_bounds()

        if self.orientation == "horizontal":
            track_x_start = self.x + padding + border_width
            track_x_end = self.x + self.width - padding - border_width
            track_length = max(1, track_x_end - track_x_start)

            pos = max(0, min(x - track_x_start, track_length))
            ratio = pos / track_length
        else:
            track_y_start = self.y + padding + border_width
            track_y_end = self.y + self.height - padding - border_width
            track_length = max(1, track_y_end - track_y_start)

            pos = max(0, min(y - track_y_start, track_length))
            ratio = 1.0 - (pos / track_length)

        # Snap to step
        raw_value = self.min + ratio * (self.max - self.min)
        stepped_value = round(raw_value / self.step) * self.step

        # Clamp to range
        return max(self.min, min(self.max, stepped_value))

    def _set_value(self, new_value: float) -> None:
        """Set value and trigger callback."""
        old_value = self.value
        self.value = new_value

        if self.value != old_value and self.on_change:
            self.on_change(self.value)

    def handle_mouse(self, event: MouseEvent, app: Any) -> bool:
        """Handle mouse events for dragging."""
        term_x = event.x - 1
        term_y = event.y - 1

        # Check bounds
        in_bounds = (
            self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height
        )

        if not in_bounds:
            return False

        if event.pressed:
            # Start dragging
            self._dragging = True
            new_value = self._value_from_position(term_x, term_y)
            self._set_value(new_value)
            return True

        elif event.button == 0 and not event.pressed:
            # Continue or end dragging
            if self._dragging:
                new_value = self._value_from_position(term_x, term_y)
                self._set_value(new_value)
                self._dragging = False
                return True

        return False

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard events."""
        if self._disabled:
            return False

        delta = self.step

        if event.key == Keys.LEFT or event.key == Keys.DOWN:
            self._set_value(self.value - delta)
            return True
        elif event.key == Keys.RIGHT or event.key == Keys.UP:
            self._set_value(self.value + delta)
            return True
        elif event.key == Keys.HOME:
            self._set_value(self.min)
            return True
        elif event.key == Keys.END:
            self._set_value(self.max)
            return True

        return False

    def set_value(self, value: float) -> None:
        """Set value programmatically."""
        clamped = max(self.min, min(self.max, value))
        self._set_value(clamped)

    def set_range(self, min_val: float, max_val: float) -> None:
        """Set min and max range."""
        self.min = min_val
        self.max = max_val
        self.value = max(self.min, min(self.max, self.value))
