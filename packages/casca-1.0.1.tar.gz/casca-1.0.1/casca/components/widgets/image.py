import math
import os
import re
import subprocess

from ...core.ansi import ESC
from ...style.css import get_border_width, get_box_spacing
from .base import WidgetBase

ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


class Image(WidgetBase):
    """
    Displays an image in the terminal using ANSI colors, ASCII, or Braille characters.
    Relies on ImageMagick ('convert' command) being installed on the system.
    """

    tag = "image"

    def __init__(
        self,
        src: str = "",
        id: str = "",
        classes: str = "",
        mode: str = "uni",
        fallback: str = "[Image Load Error]",
        **props,
    ):
        super().__init__(id=id, classes=classes, **props)
        self.src = src
        self.fallback = fallback
        normalized_mode = str(mode or "uni").strip().lower()
        self.mode = (
            normalized_mode if normalized_mode in {"uni", "ascii", "color-ascii", "dots"} else "uni"
        )
        self.lines: list[str] = []
        self._layout_warnings: list[str] = []
        self._raw_cache = None
        self._cache_key = None
        self._line_cache_key = None

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        pad_top, pad_right, pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        mar_top, mar_right, mar_bottom, mar_left = get_box_spacing(self.style, "margin")

        def _to_int_size(value, reference, fallback):
            if value is None:
                return fallback
            if isinstance(value, str) and value.endswith("%"):
                try:
                    return int(reference * (float(value.strip("%")) / 100.0))
                except ValueError:
                    return fallback
            try:
                return int(value)
            except (TypeError, ValueError):
                return fallback

        w_prop = self.props.get("width") or self.style.get("width")
        h_prop = self.props.get("height") or self.style.get("height")

        explicit_width = w_prop is not None
        explicit_height = h_prop is not None

        inner_width = (
            available_width - mar_left - mar_right - pad_left - pad_right - (border_width * 2)
        )
        inner_height = (
            available_height - mar_top - mar_bottom - pad_top - pad_bottom - (border_width * 2)
        )

        if explicit_width:
            inner_width = (
                _to_int_size(w_prop, available_width, available_width)
                - pad_left
                - pad_right
                - (border_width * 2)
            )
        if explicit_height:
            inner_height = (
                _to_int_size(h_prop, available_height, available_height)
                - pad_top
                - pad_bottom
                - (border_width * 2)
            )

        inner_width = max(1, inner_width)
        inner_height = max(1, inner_height)

        self._render_image(inner_width, inner_height)

        self.content_height = len(self.lines)
        self.content_width = max([0] + [len(self._strip_ansi(line)) for line in self.lines])

        if explicit_width:
            self.width = _to_int_size(
                w_prop,
                available_width,
                self.content_width + pad_left + pad_right + border_width * 2,
            )
        else:
            self.width = self.content_width + pad_left + pad_right + border_width * 2

        if explicit_height:
            self.height = _to_int_size(
                h_prop,
                available_height,
                self.content_height + pad_top + pad_bottom + border_width * 2,
            )
        else:
            self.height = self.content_height + pad_top + pad_bottom + border_width * 2

        return self.width + mar_left + mar_right, self.height + mar_top + mar_bottom

    def _strip_ansi(self, text: str) -> str:
        return ANSI_ESCAPE_RE.sub("", text)

    def _prop_or_style(self, name: str, default=None):
        if name in self.props:
            return self.props.get(name)
        return self.style.get(name, default)

    @staticmethod
    def _to_float(value, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _to_bool(value, default: bool = False) -> bool:
        if isinstance(value, bool):
            return value
        if value is None:
            return default
        text = str(value).strip().lower()
        if text in {"1", "true", "yes", "on"}:
            return True
        if text in {"0", "false", "no", "off"}:
            return False
        return default

    def _build_convert_cmd(self, width: int, height: int, fit: str, mode: str) -> list[str]:
        resize = f"{width}x{height}!"
        cmd = ["convert", self.src, "-auto-orient", "-filter", "Lanczos", "-strip"]

        if fit == "contain":
            resize = f"{width}x{height}"
            cmd.extend(
                [
                    "-resize",
                    resize,
                    "-background",
                    "black",
                    "-gravity",
                    "center",
                    "-extent",
                    f"{width}x{height}",
                ]
            )
        elif fit == "cover":
            resize = f"{width}x{height}^"
            cmd.extend(["-resize", resize, "-gravity", "center", "-extent", f"{width}x{height}"])
        else:
            cmd.extend(["-resize", resize])

        if mode == "ascii":
            # Keep luminance conversion simple so output remains close to source.
            cmd.extend(["-colorspace", "Gray"])
        elif mode == "dots":
            cmd.extend(["-colorspace", "Gray"])
        else:
            # Keep color fidelity for uni and color-ascii.
            cmd.extend(["-colorspace", "sRGB"])

        cmd.append("rgb:-")
        return cmd

    @staticmethod
    def _clamp_byte(value: float) -> int:
        return max(0, min(255, int(value)))

    def _apply_tone(self, raw: bytes, brightness: float, contrast: float) -> bytes:
        if not raw:
            return raw
        if brightness == 1.0 and contrast == 1.0:
            return raw

        out = bytearray(len(raw))
        for i, v in enumerate(raw):
            tuned = ((v - 128.0) * contrast + 128.0) * brightness
            out[i] = self._clamp_byte(tuned)
        return bytes(out)

    def _luma_values(self, raw: bytes, w: int, h: int) -> list[float]:
        vals: list[float] = []
        expected = w * h * 3
        if len(raw) < expected:
            raw = raw + (b"\x00" * (expected - len(raw)))
        for i in range(0, expected, 3):
            r, g, b = raw[i], raw[i + 1], raw[i + 2]
            vals.append((0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0)
        return vals

    def _dither_floyd_steinberg(self, luma: list[float], w: int, h: int) -> list[float]:
        out = list(luma)
        for y in range(h):
            for x in range(w):
                idx = y * w + x
                old = out[idx]
                new = 1.0 if old >= 0.5 else 0.0
                err = old - new
                out[idx] = new

                if x + 1 < w:
                    out[idx + 1] += err * (7.0 / 16.0)
                if y + 1 < h:
                    if x > 0:
                        out[idx + w - 1] += err * (3.0 / 16.0)
                    out[idx + w] += err * (5.0 / 16.0)
                    if x + 1 < w:
                        out[idx + w + 1] += err * (1.0 / 16.0)

        for i, value in enumerate(out):
            out[i] = max(0.0, min(1.0, value))
        return out

    def _get_raw_data(self, width: int, height: int, fit: str, mode: str) -> bytes:
        if not self.src or not os.path.isfile(self.src):
            self._layout_warnings.append(f"Image file not found: {self.src}")
            return b""

        cmd = self._build_convert_cmd(width, height, fit, mode)
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                check=False,
                timeout=10,
            )
            if result.returncode != 0:
                self._layout_warnings.append(f"ImageMagick error: {result.stderr.decode().strip()}")
                return b""
            return result.stdout
        except subprocess.TimeoutExpired:
            self._layout_warnings.append("ImageMagick timed out.")
            return b""
        except FileNotFoundError:
            self._layout_warnings.append("ImageMagick 'convert' command not found.")
            return b""

    def _render_image(self, max_width: int, max_height: int):
        self.lines = []
        if not self.src:
            return

        fit = str(self._prop_or_style("fit", "stretch") or "stretch").strip().lower()
        if fit not in {"stretch", "contain", "cover"}:
            fit = "stretch"

        brightness = self._to_float(self._prop_or_style("brightness", 1.0), 1.0)
        contrast = self._to_float(self._prop_or_style("contrast", 1.0), 1.0)
        ascii_chars = str(
            self._prop_or_style("ascii-chars", " .,:;irsXA253hMHGS#9B&@")
            or " .,:;irsXA253hMHGS#9B&@"
        )
        ascii_invert = self._to_bool(self._prop_or_style("ascii-invert", False), False)
        ascii_gamma = max(0.1, self._to_float(self._prop_or_style("ascii-gamma", 1.0), 1.0))
        ascii_dither = self._to_bool(self._prop_or_style("ascii-dither", True), True)
        dots_threshold_bias = self._to_float(self._prop_or_style("dots-threshold-bias", 0.0), 0.0)
        dots_dither = self._to_bool(self._prop_or_style("dots-dither", True), True)

        # Keep output dimensions strictly aligned with requested widget size.
        target_w = max_width
        target_h = max_height

        # Braille uses a 2x4 dot cell, so request a higher pixel grid while
        # preserving the final character width/height in output.
        if self.mode == "dots":
            target_w = max_width * 2
            target_h = max_height * 4

        if target_w < 1:
            target_w = 1
        if target_h < 1:
            target_h = 1

        cache_key = (self.src, target_w, target_h, fit, self.mode)
        line_cache_key = (
            self.src,
            target_w,
            target_h,
            fit,
            self.mode,
            brightness,
            contrast,
            ascii_chars,
            ascii_invert,
            ascii_gamma,
            ascii_dither,
            dots_threshold_bias,
            dots_dither,
        )

        if self._line_cache_key == line_cache_key and self.lines:
            return

        if self._cache_key == cache_key and self._raw_cache is not None:
            raw = self._raw_cache
        else:
            raw = self._get_raw_data(target_w, target_h, fit, self.mode)
            if not raw:
                self.lines = [self.fallback]
                self._line_cache_key = line_cache_key
                return
            self._raw_cache = raw
            self._cache_key = cache_key

        raw = self._apply_tone(raw, brightness=brightness, contrast=contrast)

        # We assume exactly target_w * target_h * 3 bytes returned
        actual_h = (len(raw) // 3) // target_w

        try:
            if self.mode == "dots":
                self._render_dots(raw, target_w, actual_h)
            elif self.mode == "ascii":
                self._render_ascii(raw, target_w, actual_h)
            elif self.mode == "color-ascii":
                self._render_color_ascii(raw, target_w, actual_h)
            else:
                self._render_uni(raw, target_w, actual_h)
            self._line_cache_key = line_cache_key
        except Exception as e:
            self.lines = [f"[Render Error: {e}]"]
            self._line_cache_key = line_cache_key

    @staticmethod
    def _slice_ansi_for_clip(text: str, left_skip: int, visible_width: int) -> str:
        if visible_width <= 0:
            return ""
        if left_skip <= 0 and visible_width >= len(ANSI_ESCAPE_RE.sub("", text)):
            return text

        parts = ANSI_ESCAPE_RE.split(text)
        escapes = ANSI_ESCAPE_RE.findall(text)
        out: list[str] = []
        visible_idx = 0
        remaining = visible_width

        if parts:
            current_esc = ""
            for idx, segment in enumerate(parts):
                if idx > 0:
                    current_esc = escapes[idx - 1]
                if not segment:
                    continue
                for ch in segment:
                    if visible_idx >= left_skip and remaining > 0:
                        if current_esc:
                            out.append(current_esc)
                            current_esc = ""
                        out.append(ch)
                        remaining -= 1
                    visible_idx += 1
                    if remaining <= 0:
                        return "".join(out) + f"{ESC}0m"
        return "".join(out) + (f"{ESC}0m" if out else "")

    def _render_dots(self, raw: bytes, w: int, h: int):
        luma = self._luma_values(raw, w, h)
        avg = sum(luma) / max(1, len(luma))
        threshold = avg * 255.0
        threshold_bias = self._to_float(self._prop_or_style("dots-threshold-bias", 0.0), 0.0)
        threshold = max(0.0, min(255.0, threshold + threshold_bias))
        use_dither = self._to_bool(self._prop_or_style("dots-dither", True), True)

        for y in range(0, h, 4):
            line_str = ""
            for x in range(0, w, 2):

                def is_on(dx: int, dy: int, cx: int = x, cy: int = y) -> bool:
                    px = cx + dx
                    py = cy + dy
                    if px >= w or py >= h:
                        return False
                    lum = luma[py * w + px] * 255.0
                    if use_dither:
                        # Ordered 2x2 Bayer offset adds controlled texture.
                        bayer = ((py & 1) << 1) | (px & 1)
                        offset = (-24.0, 8.0, 24.0, -8.0)[bayer]
                        return (lum + offset) > threshold
                    return lum > threshold

                val = 0
                if is_on(0, 0):
                    val |= 0x1
                if is_on(0, 1):
                    val |= 0x2
                if is_on(0, 2):
                    val |= 0x4
                if is_on(1, 0):
                    val |= 0x8
                if is_on(1, 1):
                    val |= 0x10
                if is_on(1, 2):
                    val |= 0x20
                if is_on(0, 3):
                    val |= 0x40
                if is_on(1, 3):
                    val |= 0x80
                line_str += chr(0x2800 + val)
            self.lines.append(line_str)

    def _render_uni(self, raw: bytes, w: int, h: int):
        for y in range(h):
            line_str = ""
            for x in range(w):
                idx = (y * w + x) * 3
                if idx + 2 >= len(raw):
                    line_str += " "
                    continue
                r, g, b = raw[idx], raw[idx + 1], raw[idx + 2]
                # Background-color spaces look smoother than glyph fills.
                line_str += f"{ESC}48;2;{r};{g};{b}m "
            self.lines.append(line_str + f"{ESC}0m")

    def _render_ascii(self, raw: bytes, w: int, h: int):
        chars = str(
            self._prop_or_style("ascii-chars", " .,:;irsXA253hMHGS#9B&@")
            or " .,:;irsXA253hMHGS#9B&@"
        ).strip()
        if len(chars) < 2:
            chars = " .,:;irsXA253hMHGS#9B&@"

        if self._to_bool(self._prop_or_style("ascii-invert", False), False):
            chars = chars[::-1]

        gamma = max(0.1, self._to_float(self._prop_or_style("ascii-gamma", 1.0), 1.0))
        use_dither = self._to_bool(self._prop_or_style("ascii-dither", True), True)
        luma = self._luma_values(raw, w, h)
        if use_dither:
            luma = self._dither_floyd_steinberg(luma, w, h)

        for y in range(h):
            line_str = ""
            for x in range(w):
                idx = y * w + x
                if idx >= len(luma):
                    line_str += " "
                    continue
                brightness = luma[idx]
                brightness = math.pow(max(0.0, min(1.0, brightness)), gamma)
                char_idx = int(brightness * (len(chars) - 1))
                line_str += chars[char_idx]
            self.lines.append(line_str)

    def _render_color_ascii(self, raw: bytes, w: int, h: int):
        chars = str(
            self._prop_or_style("ascii-chars", " .,:;irsXA253hMHGS#9B&@")
            or " .,:;irsXA253hMHGS#9B&@"
        ).strip()
        if len(chars) < 2:
            chars = " .,:;irsXA253hMHGS#9B&@"

        if self._to_bool(self._prop_or_style("ascii-invert", False), False):
            chars = chars[::-1]

        gamma = max(0.1, self._to_float(self._prop_or_style("ascii-gamma", 1.0), 1.0))
        use_dither = self._to_bool(self._prop_or_style("ascii-dither", True), True)
        luma = self._luma_values(raw, w, h)
        if use_dither:
            luma = self._dither_floyd_steinberg(luma, w, h)

        for y in range(h):
            line_str = ""
            for x in range(w):
                idx = y * w + x
                rgb_idx = idx * 3
                if idx >= len(luma) or rgb_idx + 2 >= len(raw):
                    line_str += " "
                    continue

                brightness = math.pow(max(0.0, min(1.0, luma[idx])), gamma)
                char_idx = int(brightness * (len(chars) - 1))
                ch = chars[char_idx]
                r, g, b = raw[rgb_idx], raw[rgb_idx + 1], raw[rgb_idx + 2]
                line_str += f"{ESC}38;2;{r};{g};{b}m{ch}"

            self.lines.append(line_str + f"{ESC}0m")

    def render_content(self, app):
        pad_top, _pad_right, _pad_bottom, pad_left = get_box_spacing(self.style, "padding")
        border_width = get_border_width(self.style)
        base_x = self.x + pad_left + border_width + 1
        base_y = self.y + pad_top + border_width + 1
        clip_rect = getattr(app, "clip_rect", None)

        for i, line in enumerate(self.lines):
            y = base_y + i
            x = base_x
            out = line

            if clip_rect:
                min_y, max_y, min_x, max_x = clip_rect
                if y < min_y or y >= max_y:
                    continue

                visible_width = max_x - max(min_x, x)
                if visible_width <= 0:
                    continue

                if x < min_x:
                    out = self._slice_ansi_for_clip(out, min_x - x, visible_width)
                    x = min_x
                else:
                    stripped_len = len(self._strip_ansi(out))
                    if x + stripped_len > max_x:
                        out = self._slice_ansi_for_clip(out, 0, visible_width)

                if not out:
                    continue

            app.write(f"{ESC}{y};{x}H")
            app.write(out)
