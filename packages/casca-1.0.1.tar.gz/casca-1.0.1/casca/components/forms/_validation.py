"""Shared validation behavior for form widgets."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

Validator = Callable[[Any], str | bool | None]


class ValidatableField:
    """Mixin for form widgets that expose invalid/error state."""

    validator: Validator | None
    invalid: bool
    error_message: str

    def _init_validation(self, validator: Validator | None = None) -> None:
        """Initialize validation state."""
        self.validator = validator
        self.invalid = False
        self.error_message = ""

    def _sync_invalid_class(self) -> None:
        """Sync invalid state with CSS classes."""
        if not hasattr(self, "classes"):
            return
        if self.invalid and "invalid" not in self.classes:
            self.classes.append("invalid")
        if not self.invalid and "invalid" in self.classes:
            self.classes.remove("invalid")

    def set_error(self, message: str) -> None:
        """Set error state with message."""
        self.invalid = True
        self.error_message = message
        self._sync_invalid_class()

    def clear_error(self) -> None:
        """Clear error state."""
        self.invalid = False
        self.error_message = ""
        self._sync_invalid_class()

    def validate(self, value: Any | None = None) -> bool:
        """
        Validate value using registered validator.

        Args:
            value: Value to validate. Defaults to current value.

        Returns:
            True if valid, False otherwise.
        """
        if not self.validator:
            self.clear_error()
            return True

        result = self.validator(value)
        if result is True or result is None:
            self.clear_error()
            return True
        if result is False:
            self.set_error("Invalid value")
            return False

        message = str(result).strip() or "Invalid value"
        self.set_error(message)
        return False
