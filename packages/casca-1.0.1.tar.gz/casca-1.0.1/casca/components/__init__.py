"""
Casca UI Components

Organized into submodules:
- widgets: Base widgets (Container, Label, Button)
- forms: Form inputs (Checkbox, Input)
- dialogs: Modal dialogs (Overlay, Modal, Dialog, Alert, Confirm, Prompt)
- panels: Panel containers (Card, Header)
- navigation: Navigation components (Tabs, ScrollView)
"""

# Re-export all components for backward compatibility
from .dialogs import (
    Alert,
    Confirm,
    Dialog,
    DialogManager,
    Modal,
    Overlay,
    Prompt,
    show_alert,
    show_confirm,
    show_prompt,
)
from .forms import Checkbox, Input, RadioGroup, Select, TextArea
from .navigation import ScrollView, TabItem, Tabs
from .panels import Card, Header, NotificationCenter, StudioPanel
from .widgets import (
    Button,
    CommandPalette,
    Container,
    DataGrid,
    Image,
    Label,
    ListView,
    ProgressBar,
    Spinner,
    Table,
    TreeView,
    WidgetBase,
)

__all__ = [
    # Widgets
    "WidgetBase",
    "Container",
    "Label",
    "Button",
    "ListView",
    "ProgressBar",
    "Spinner",
    "DataGrid",
    "TreeView",
    "Table",
    "CommandPalette",
    "Image",
    # Forms
    "Checkbox",
    "Input",
    "Select",
    "TextArea",
    "RadioGroup",
    # Dialogs
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
    # Panels
    "Card",
    "Header",
    "NotificationCenter",
    "StudioPanel",
    # Navigation
    "Tabs",
    "TabItem",
    "ScrollView",
]
