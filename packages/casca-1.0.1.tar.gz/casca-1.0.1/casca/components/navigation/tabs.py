"""
Tabs component - tabbed navigation interface.
"""

from collections.abc import Callable

from ..widgets.button import Button
from ..widgets.container import Container


class TabItem(Container):
    """
    Represents a single tab content pane.

    Attributes:
        title: The tab title displayed in the tab bar
    """

    tag = "tab-item"

    def __init__(self, title: str, *children, id: str = "", classes: str = "", **kwargs):
        super().__init__(*children, id=id, classes=classes, **kwargs)
        self.title = title


class Tabs(Container):
    """
    A tabbed interface component for organizing content.

    Features:
    - Horizontal or vertical orientation
    - Active tab tracking
    - onChange callback
    - Dynamic tab management

    Usage:
        ```python
        tabs = Tabs(
            TabItem("Home", Label("Home content")),
            TabItem("Settings", Label("Settings content")),
            on_change=lambda i: logger.info(f"Tab {i} selected")
        )
        ```
    """

    tag = "tabs"

    def __init__(
        self,
        *tabs: TabItem,
        active_index: int = 0,
        orientation: str = "horizontal",
        on_change: Callable[[int], None] | None = None,
        id: str = "",
        classes: str = "",
        **kwargs,
    ):
        """
        Args:
            *tabs: TabItem instances
            active_index: Initially active tab index
            orientation: 'horizontal' (tabs on top) or 'vertical' (tabs on left)
            on_change: Callback when tab changes
        """
        # If vertical orientation, use row layout for sidebar
        if orientation == "vertical":
            if "style" not in kwargs:
                kwargs["style"] = {}
            kwargs["style"]["flex-direction"] = "row"

        super().__init__(id=id, classes=classes, **kwargs)

        self.tabs: list[TabItem] = list(tabs)
        self.active_index = active_index
        self.orientation = orientation
        self.on_change = on_change
        self._header_width = 0

        # Header layout varies based on orientation
        header_direction = "row" if orientation == "horizontal" else "column"
        header_style = {"flex-direction": header_direction, "padding": 0, "margin": 0}

        if orientation == "vertical":
            # Compute width for the sidebar header based on longest title
            max_len = max([len(t.title) for t in self.tabs] + [10])
            self._header_width = max_len + 4
            header_style["width"] = self._header_width

        self.tab_header = Container(classes=f"tab-header {orientation}", style=header_style)
        self.content_area = Container(classes="tab-content", style={"padding": 1})

        self.children = [self.tab_header, self.content_area]
        self._build_tabs()

    def _build_tabs(self):
        """Build the tab header buttons and content area."""
        self.tab_header.children = []
        for i, tab in enumerate(self.tabs):
            btn_class = "tab-btn active" if i == self.active_index else "tab-btn"
            btn = Button(
                f" {tab.title} ",
                classes=btn_class,
                on_click=lambda event, index=i: self.switch_tab(index),
            )

            if "style" not in btn.props:
                btn.props["style"] = {}
            btn.props["style"]["margin"] = 0

            # Horizontal: buttons side-by-side
            if self.orientation == "horizontal":
                btn.props["style"]["width"] = len(tab.title) + 4
            else:
                # Keep vertical tab labels and hit areas visually aligned.
                btn.props["style"]["width"] = self._header_width

            self.tab_header.children.append(btn)

        self.content_area.children = []
        if 0 <= self.active_index < len(self.tabs):
            self.content_area.children.append(self.tabs[self.active_index])

    def switch_tab(self, index: int) -> bool:
        """
        Switch to a different tab.

        Args:
            index: The tab index to switch to

        Returns:
            True if tab was switched
        """
        if index != self.active_index and 0 <= index < len(self.tabs):
            self.active_index = index
            self._build_tabs()

            # Force parent to recalculate layout
            self._layout_dirty = True

            if self.on_change:
                self.on_change(index)
            return True
        return False

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout and handle tab content switching."""
        # Rebuild tabs to ensure content is correct
        self._build_tabs()
        return super().calculate_layout(available_width, available_height)

    def add_tab(self, tab: TabItem):
        """Add a new tab to the end."""
        self.tabs.append(tab)
        self._build_tabs()

    def remove_tab(self, index: int) -> bool:
        """Remove a tab by index."""
        if 0 <= index < len(self.tabs):
            self.tabs.pop(index)
            if self.active_index >= len(self.tabs):
                self.active_index = max(0, len(self.tabs) - 1)
            self._build_tabs()
            return True
        return False

    def get_active_tab(self) -> TabItem | None:
        """Get the currently active tab."""
        if 0 <= self.active_index < len(self.tabs):
            return self.tabs[self.active_index]
        return None
