"""
ScrollView component - scrollable container.
"""

from ...core.ansi import RESET
from ...core.events import KeyEvent, Keys, MouseEvent
from ...style.css import clamp_dimension
from ..widgets.container import Container


class ScrollView(Container):
    """
    A container that clips its children vertically and allows scrolling.

    Features:
    - Vertical scrolling with mouse wheel
    - Keyboard navigation (arrow keys)
    - Visual scrollbar indicator
    - Auto-scroll to bottom option
    - Content clipping

    Usage:
        scroll = ScrollView(
            Label("Line 1"),
            Label("Line 2"),
            # ... many more lines
            height=10
        )
    """

    tag = "scrollview"

    def __init__(self, *args, scroll_to_bottom: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        self.scroll_x = 0
        self.scroll_y = 0
        self.max_scroll = 0
        self.max_scroll_x = 0
        self.props["scroll_to_bottom"] = scroll_to_bottom
        self._last_max = 0

    def _int_prop(self, key: str, default: int) -> int:
        raw = self.props.get(key, self.style.get(key, default))
        try:
            return int(raw)
        except (TypeError, ValueError):
            return default

    def _axis_enabled(self, axis: str) -> bool:
        raw = str(self.style.get(axis, "auto")).strip().lower()
        return raw in ("visible", "auto", "scroll")

    def _viewport_size(self) -> tuple[int, int]:
        padding, border_width = self._get_inner_bounds()
        inner_width = max(0, self.width - 2 * (padding + border_width))
        inner_height = max(0, self.height - 2 * (padding + border_width))
        return inner_width, inner_height

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout and scroll bounds."""
        padding, border_width = self._get_inner_bounds()
        margin = int(self.style.get("margin", 0))

        width_raw = self.props.get("width", self.style.get("width", available_width))
        self.width = clamp_dimension(
            width_raw, self.style, "width", available_width, available_width
        )

        set_height = self.props.get("height") or self.style.get("height")
        if set_height:
            self.height = clamp_dimension(
                set_height, self.style, "height", available_height, available_height
            )
        else:
            self.height = clamp_dimension(
                available_height, self.style, "height", available_height, available_height
            )

        inner_width = max(0, self.width - 2 * (padding + border_width))

        current_y = 0
        max_child_width = 0

        # Calculate children sizes assuming infinite height
        for child in self.children:
            child.x = self.x + padding + border_width
            child.y = self.y + padding + border_width + current_y

            child_w, child_h = child.calculate_layout(inner_width, 9999)
            current_y += child_h
            max_child_width = max(max_child_width, child_w)

        self.content_height = current_y
        self.content_width = max_child_width

        inner_height = max(0, self.height - 2 * (padding + border_width))
        self.max_scroll = max(0, self.content_height - inner_height)
        self.max_scroll_x = max(0, self.content_width - inner_width)

        if not self._axis_enabled("overflow-y"):
            self.max_scroll = 0
            self.scroll_y = 0
        if not self._axis_enabled("overflow-x"):
            self.max_scroll_x = 0
            self.scroll_x = 0

        # Auto-scroll logic
        was_at_bottom = self._last_max > 0 and self.scroll_y >= self._last_max
        is_first_layout = self._last_max == 0

        if self.props.get("scroll_to_bottom"):
            if is_first_layout or was_at_bottom:
                self.scroll_y = self.max_scroll

        self._last_max = self.max_scroll

        # Clamp scroll position
        if self.scroll_y > self.max_scroll:
            self.scroll_y = self.max_scroll
        if self.scroll_y < 0:
            self.scroll_y = 0
        if self.scroll_x > self.max_scroll_x:
            self.scroll_x = self.max_scroll_x
        if self.scroll_x < 0:
            self.scroll_x = 0

        # Apply scroll offset
        sticky_rows = max(0, self._int_prop("sticky-header-rows", 0))
        self._apply_scroll_offset(sticky_rows=sticky_rows)

        return self.width + margin * 2, self.height + margin * 2

    def _apply_scroll_offset(self, sticky_rows: int = 0):
        """Apply scroll offset to all children."""

        def shift(node, offset_x: int, offset_y: int):
            node.x -= offset_x
            node.y -= offset_y
            for c in node.children:
                shift(c, offset_x, offset_y)

        for idx, child in enumerate(self.children):
            offset_y = 0 if idx < sticky_rows else self.scroll_y
            shift(child, self.scroll_x, offset_y)

    def render(self, app):
        """Render with clipping and scrollbar."""
        padding, border_width = self._get_inner_bounds()

        min_y = self.y + padding + border_width + 1
        max_y = min_y + max(0, self.height - 2 * (padding + border_width))
        min_x = self.x + padding + border_width + 1
        max_x = min_x + max(0, self.width - 2 * (padding + border_width))

        prev_clip = getattr(app, "clip_rect", None)
        app.clip_rect = (min_y, max_y, min_x, max_x)

        self.apply_style(app)

        # Background fill
        if "background" in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width, apply_clip=False)
            self.apply_style(app)

        # Border
        if self.style.get("border", "none") != "none":
            self._draw_border(app)

        # Scrollbar
        self._draw_scrollbars(app)

        # Children
        for child in self.children:
            child.render(app)
            self.apply_style(app)

        app.clip_rect = prev_clip
        app.write(RESET)

    def _draw_scrollbars(self, app):
        """Draw visual vertical and horizontal scrollbar indicators."""
        inner_width, inner_height = self._viewport_size()

        if self.max_scroll > 0 and inner_height > 0:
            thumb_size = max(1, int(inner_height * (inner_height / (self.content_height or 1))))
            thumb_pos = int(
                (self.scroll_y / max(1, self.max_scroll)) * max(0, inner_height - thumb_size)
            )
            for i in range(inner_height):
                char = "█" if thumb_pos <= i < thumb_pos + thumb_size else "▒"
                app.draw_text(self.x + self.width, self.y + 1 + i, char, apply_clip=False)

        if self.max_scroll_x > 0 and inner_width > 0:
            thumb_size = max(1, int(inner_width * (inner_width / (self.content_width or 1))))
            thumb_pos = int(
                (self.scroll_x / max(1, self.max_scroll_x)) * max(0, inner_width - thumb_size)
            )
            row = self.y + self.height
            bar = []
            for i in range(inner_width):
                bar.append("█" if thumb_pos <= i < thumb_pos + thumb_size else "▒")
            app.draw_text(self.x + 1, row, "".join(bar), apply_clip=False)

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard scrolling."""
        # Check children first
        if super().handle_input(event):
            return True

        step = max(1, self._int_prop("scroll-step", 1))
        page_default = max(1, self._viewport_size()[1] - 1)
        page_step = max(1, self._int_prop("scroll-page-step", page_default))

        # Arrow key scrolling
        if event.key == Keys.UP:
            if not self._axis_enabled("overflow-y"):
                return False
            self.scroll_y = max(0, self.scroll_y - step)
            return True
        elif event.key == Keys.DOWN:
            if not self._axis_enabled("overflow-y"):
                return False
            self.scroll_y = min(self.max_scroll, self.scroll_y + step)
            return True
        elif event.key == Keys.LEFT:
            if not self._axis_enabled("overflow-x"):
                return False
            self.scroll_x = max(0, self.scroll_x - step)
            return True
        elif event.key == Keys.RIGHT:
            if not self._axis_enabled("overflow-x"):
                return False
            self.scroll_x = min(self.max_scroll_x, self.scroll_x + step)
            return True
        elif event.key == Keys.PAGE_UP:
            if not self._axis_enabled("overflow-y"):
                return False
            self.scroll_y = max(0, self.scroll_y - page_step)
            return True
        elif event.key == Keys.PAGE_DOWN:
            if not self._axis_enabled("overflow-y"):
                return False
            self.scroll_y = min(self.max_scroll, self.scroll_y + page_step)
            return True
        elif event.key == Keys.HOME:
            self.scroll_x = 0
            self.scroll_y = 0
            return True
        elif event.key == Keys.END:
            self.scroll_x = self.max_scroll_x
            self.scroll_y = self.max_scroll
            return True

        return False

    def handle_wheel(self, event: MouseEvent, app) -> bool:
        """Handle mouse wheel scrolling."""
        term_x = event.x - 1
        term_y = event.y - 1
        step = max(1, self._int_prop("wheel-step", self._int_prop("scroll-step", 1)))

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            if event.button == 64:  # Scroll up
                if not self._axis_enabled("overflow-y"):
                    return False
                self.scroll_y = max(0, self.scroll_y - step)
                if app._running:
                    app.request_render()
                return True
            elif event.button == 65:  # Scroll down
                if not self._axis_enabled("overflow-y"):
                    return False
                self.scroll_y = min(self.max_scroll, self.scroll_y + step)
                if app._running:
                    app.request_render()
                return True
            elif event.button == 66:  # Horizontal scroll left (terminal dependent)
                if not self._axis_enabled("overflow-x"):
                    return False
                self.scroll_x = max(0, self.scroll_x - step)
                if app._running:
                    app.request_render()
                return True
            elif event.button == 67:  # Horizontal scroll right (terminal dependent)
                if not self._axis_enabled("overflow-x"):
                    return False
                self.scroll_x = min(self.max_scroll_x, self.scroll_x + step)
                if app._running:
                    app.request_render()
                return True
        return False

    def scroll_to(self, position: int):
        """Scroll to a specific position."""
        self.scroll_y = max(0, min(position, self.max_scroll))

    def scroll_to_top(self):
        """Scroll to the top."""
        self.scroll_y = 0
        self.scroll_x = 0

    def scroll_to_bottom(self):
        """Scroll to the bottom."""
        self.scroll_y = self.max_scroll

    def scroll_to_x(self, position: int):
        """Scroll horizontally to a specific position."""
        self.scroll_x = max(0, min(position, self.max_scroll_x))
