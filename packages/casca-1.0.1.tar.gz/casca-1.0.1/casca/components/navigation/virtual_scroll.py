"""
VirtualScrollView component - optimized scrollable container with virtual scrolling.

Virtual scrolling only renders visible children, dramatically improving performance
for large lists (1000+ items).
"""

from collections.abc import Callable
from typing import Any

from ...core.ansi import RESET
from ...core.events import KeyEvent, Keys, MouseEvent
from ...style.css import clamp_dimension
from ..widgets.base import WidgetBase


class VirtualScrollView(WidgetBase):
    """
    A virtualized scrollable container that only renders visible children.

    Unlike ScrollView which renders all children, VirtualScrollView:
    - Only renders children within the visible viewport
    - Uses item heights to calculate which items to render
    - Supports dynamic item heights via callback
    - Maintains scroll position with virtual content height

    This provides dramatic performance improvements for large lists.

    Features:
    - Virtual rendering (only visible items)
    - Support for 10,000+ items
    - Constant memory usage regardless of total items
    - Smooth scrolling with keyboard and mouse
    - Auto-scroll to bottom option
    - Custom item height support

    Usage:
        # Fixed height items
        scroll = VirtualScrollView(
            item_height=3,  # Each item is 3 rows
            total_items=1000,
            render_fn=lambda idx, app: render_item(idx, app)
        )

        # Variable height items
        def get_height(idx):
            return 3 if idx % 2 == 0 else 5

        scroll = VirtualScrollView(
            item_height_fn=get_height,
            total_items=1000,
            render_fn=lambda idx, app: render_item(idx, app)
        )
    """

    tag = "virtual-scrollview"

    def __init__(
        self,
        total_items: int,
        render_fn: Callable[[int, Any], None],
        item_height: int | None = None,
        item_height_fn: Callable[[int], int] | None = None,
        scroll_to_bottom: bool = False,
        **kwargs,
    ):
        """
        Initialize VirtualScrollView.

        Args:
            total_items: Total number of items in the list
            render_fn: Function to render item at index. Signature: (index, app) -> None
            item_height: Fixed height for all items (if not using item_height_fn)
            item_height_fn: Function to get height of item at index
            scroll_to_bottom: Auto-scroll to bottom on initial layout
            **kwargs: Additional style props
        """
        super().__init__(**kwargs)

        if item_height is None and item_height_fn is None:
            raise ValueError("Must provide either item_height or item_height_fn")

        self.total_items = total_items
        self.render_fn = render_fn
        self.item_height = item_height
        self.item_height_fn = item_height_fn
        self.scroll_to_bottom_flag = scroll_to_bottom

        # Scroll state
        self.scroll_y = 0
        self.max_scroll = 0
        self.content_height = 0

        # Visible range tracking
        self.visible_start_idx = 0
        self.visible_end_idx = 0

        # Cache for item positions
        self._item_positions: list[int] = []
        self._item_heights: list[int] = []
        self._positions_calculated = False

        # Auto-scroll tracking
        self._last_max = 0
        self._first_layout = True

    def _get_item_height(self, idx: int) -> int:
        """Get height of item at index."""
        if self.item_height is not None:
            return self.item_height
        elif self.item_height_fn is not None:
            return self.item_height_fn(idx)
        else:
            return 3  # Default fallback

    def _calculate_item_positions(self) -> None:
        """Calculate cumulative positions for all items."""
        if self._positions_calculated:
            return

        self._item_positions = []
        self._item_heights = []

        current_y = 0
        for i in range(self.total_items):
            self._item_positions.append(current_y)
            height = self._get_item_height(i)
            self._item_heights.append(height)
            current_y += height

        self.content_height = current_y
        self._positions_calculated = True

    def _get_visible_range(self, viewport_height: int) -> tuple[int, int]:
        """
        Calculate which items are visible given viewport height.

        Returns:
            Tuple of (start_index, end_index) for visible items
        """
        if not self._positions_calculated:
            self._calculate_item_positions()

        # Find first visible item
        start_idx = 0
        for i in range(self.total_items):
            item_bottom = self._item_positions[i] + self._item_heights[i]
            if item_bottom > self.scroll_y:
                start_idx = i
                break

        # Find last visible item
        end_idx = self.total_items - 1
        viewport_bottom = self.scroll_y + viewport_height
        for i in range(start_idx, self.total_items):
            if self._item_positions[i] > viewport_bottom:
                end_idx = i - 1
                break

        # If we reached the end without breaking, ensure end_idx is correct
        if self.scroll_y + viewport_height >= self.content_height:
            end_idx = self.total_items - 1

        # Add buffer items for smooth scrolling
        buffer = 2
        start_idx = max(0, start_idx - buffer)
        end_idx = min(self.total_items - 1, end_idx + buffer)

        return start_idx, end_idx

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        """Calculate layout and scroll bounds."""
        padding, border_width = self._get_inner_bounds()
        margin = int(self.style.get("margin", 0))

        # Calculate width
        width_raw = self.props.get("width", self.style.get("width", available_width))
        self.width = clamp_dimension(
            width_raw, self.style, "width", available_width, available_width
        )

        # Calculate height
        set_height = self.props.get("height") or self.style.get("height")
        if set_height:
            self.height = clamp_dimension(
                set_height, self.style, "height", available_height, available_height
            )
        else:
            self.height = clamp_dimension(
                available_height, self.style, "height", available_height, available_height
            )

        # Calculate inner dimensions
        inner_height = max(0, self.height - 2 * (padding + border_width))

        # Calculate item positions if not done
        self._calculate_item_positions()

        # Calculate max scroll
        self.max_scroll = max(0, self.content_height - inner_height)

        # Auto-scroll logic
        if self._first_layout:
            was_at_bottom = self._last_max > 0 and self.scroll_y >= self._last_max

            if self.scroll_to_bottom_flag:
                if was_at_bottom or self._last_max == 0:
                    self.scroll_y = self.max_scroll

            self._first_layout = False
            self._last_max = self.max_scroll

        # Clamp scroll position
        self.scroll_y = max(0, min(self.scroll_y, self.max_scroll))

        # Calculate visible range
        self.visible_start_idx, self.visible_end_idx = self._get_visible_range(inner_height)

        return self.width + margin * 2, self.height + margin * 2

    def render(self, app: Any) -> None:
        """Render only visible items."""
        padding, border_width = self._get_inner_bounds()

        # Set clipping region
        min_y = self.y + padding + border_width + 1
        max_y = min_y + max(0, self.height - 2 * (padding + border_width))
        min_x = self.x + padding + border_width + 1
        max_x = min_x + max(0, self.width - 2 * (padding + border_width))

        prev_clip = getattr(app, "clip_rect", None)
        app.clip_rect = (min_y, max_y, min_x, max_x)

        # Apply styles
        self.apply_style(app)

        # Background fill
        if "background" in self.style:
            for r in range(self.height):
                app.draw_text(self.x + 1, self.y + r + 1, " " * self.width, apply_clip=False)
            self.apply_style(app)

        # Border
        if self.style.get("border", "none") != "none":
            self._draw_border(app)

        # Render only visible items
        base_x = self.x + padding + border_width
        base_y = self.y + padding + border_width

        for idx in range(self.visible_start_idx, self.visible_end_idx + 1):
            if idx >= self.total_items:
                break

            item_y = base_y - self.scroll_y + self._item_positions[idx]
            item_height = self._item_heights[idx]

            # Create a fake widget for rendering
            class _VirtualItem:
                def __init__(self, x, y, width, height, render_fn, item_idx):
                    self.x = x
                    self.y = y
                    self.width = width
                    self.height = height
                    self.children = []
                    self.style = {}
                    self._render_fn = render_fn
                    self._item_idx = item_idx

                def apply_style(self, app):
                    pass

                def render_content(self, app):
                    self._render_fn(self._item_idx, app)

                def render(self, app):
                    self.apply_style(app)
                    self.render_content(app)

            item = _VirtualItem(
                base_x,
                item_y,
                self.width - 2 * (padding + border_width),
                item_height,
                self.render_fn,
                idx,
            )

            # Render the item
            try:
                item.render(app)
            except Exception:
                # Render error placeholder
                app.draw_text(base_x + 1, item_y + 1, f"[Error rendering item {idx}]")

            self.apply_style(app)

        # Scrollbar
        self._draw_scrollbar(app)

        # Reset clipping
        app.clip_rect = prev_clip
        app.write(RESET)

    def _draw_scrollbar(self, app: Any) -> None:
        """Draw visual scrollbar indicator."""
        if self.max_scroll <= 0:
            return

        padding, border_width = self._get_inner_bounds()
        inner_height = max(0, self.height - 2 * (padding + border_width))

        if inner_height <= 0:
            return

        # Calculate thumb size and position
        visible_ratio = inner_height / self.content_height if self.content_height > 0 else 1
        thumb_size = max(1, int(inner_height * visible_ratio))

        scroll_ratio = self.scroll_y / self.max_scroll if self.max_scroll > 0 else 0
        thumb_pos = int(scroll_ratio * (inner_height - thumb_size))

        # Draw scrollbar track and thumb
        scrollbar_x = self.x + self.width
        for i in range(inner_height):
            if thumb_pos <= i < thumb_pos + thumb_size:
                char = "█"  # Thumb
            else:
                char = "▒"  # Track
            app.draw_text(scrollbar_x, self.y + 1 + i, char, apply_clip=False)

    def handle_input(self, event: KeyEvent) -> bool:
        """Handle keyboard scrolling."""
        step = max(1, int(self.props.get("scroll-step", 1)))
        page_step = max(1, int(self.props.get("scroll-page-step", self.height // 2)))

        if event.key == Keys.UP:
            self.scroll_y = max(0, self.scroll_y - step)
            self._update_visible_range()
            return True
        elif event.key == Keys.DOWN:
            self.scroll_y = min(self.max_scroll, self.scroll_y + step)
            self._update_visible_range()
            return True
        elif event.key == Keys.PAGE_UP:
            self.scroll_y = max(0, self.scroll_y - page_step)
            self._update_visible_range()
            return True
        elif event.key == Keys.PAGE_DOWN:
            self.scroll_y = min(self.max_scroll, self.scroll_y + page_step)
            self._update_visible_range()
            return True
        elif event.key == Keys.HOME:
            self.scroll_y = 0
            self._update_visible_range()
            return True
        elif event.key == Keys.END:
            self.scroll_y = self.max_scroll
            self._update_visible_range()
            return True

        return False

    def handle_wheel(self, event: MouseEvent, app: Any) -> bool:
        """Handle mouse wheel scrolling."""
        term_x = event.x - 1
        term_y = event.y - 1
        step = max(1, int(self.props.get("wheel-step", 3)))

        if self.x <= term_x < self.x + self.width and self.y <= term_y < self.y + self.height:
            if event.button == 64:  # Scroll up
                self.scroll_y = max(0, self.scroll_y - step)
                self._update_visible_range()
                if app._running:
                    app.request_render()
                return True
            elif event.button == 65:  # Scroll down
                self.scroll_y = min(self.max_scroll, self.scroll_y + step)
                self._update_visible_range()
                if app._running:
                    app.request_render()
                return True

        return False

    def _update_visible_range(self) -> None:
        """Recalculate visible item range after scroll."""
        padding, border_width = self._get_inner_bounds()
        inner_height = max(0, self.height - 2 * (padding + border_width))
        self.visible_start_idx, self.visible_end_idx = self._get_visible_range(inner_height)

    def scroll_to_item(self, index: int) -> None:
        """Scroll to make item at index visible."""
        if not self._positions_calculated:
            self._calculate_item_positions()

        if index >= self.total_items:
            index = self.total_items - 1

        item_y = self._item_positions[index]
        padding, border_width = self._get_inner_bounds()
        inner_height = max(0, self.height - 2 * (padding + border_width))

        # Scroll to show item
        if item_y < self.scroll_y:
            self.scroll_y = item_y
        elif item_y + self._item_heights[index] > self.scroll_y + inner_height:
            self.scroll_y = item_y + self._item_heights[index] - inner_height

        self._update_visible_range()

    def scroll_to_top(self) -> None:
        """Scroll to the top."""
        self.scroll_y = 0
        self._update_visible_range()

    def scroll_to_bottom(self) -> None:
        """Scroll to the bottom."""
        self.scroll_y = self.max_scroll
        self._update_visible_range()

    def invalidate_cache(self) -> None:
        """Invalidate position cache (use when items change)."""
        self._positions_calculated = False
        self._item_positions = []
        self._item_heights = []
