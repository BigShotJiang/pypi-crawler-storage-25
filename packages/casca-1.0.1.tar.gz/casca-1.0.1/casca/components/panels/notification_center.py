"""Notification center panel backed by App toast history."""

from __future__ import annotations

from ..widgets.container import Container
from ..widgets.label import Label
from .card import Card


class NotificationCenter(Card):
    """A card panel that renders recent toast history from the app instance."""

    tag = "notification-center"

    def __init__(
        self,
        title: str = "Notification Center",
        max_items: int = 8,
        id: str = "",
        classes: str = "",
        **kwargs,
    ):
        self.max_items = max(1, int(max_items))
        self._content = Container(style={"flex-direction": "column"})
        super().__init__(title, self._content, id=id, classes=classes, **kwargs)

    def render(self, app):
        history = app.get_notification_history(limit=self.max_items)
        if not history:
            self._content.children = [Label("No notifications yet.")]
        else:
            lines = []
            for toast in reversed(history):
                lines.append(Label(f"[{toast.level.upper()}] {toast.message}"))
            self._content.children = lines
        super().render(app)
