"""
Card component - styled container panel.
"""

from ..widgets.container import Container
from ..widgets.label import Label


class Card(Container):
    """
    A styled container with a title, designed for grouping related content.

    Visual characteristics:
    - ASCII border by default
    - Title bar at the top
    - Padding for content

    Usage:
        card = Card("My Card",
            Label("Content here"),
            Label("More content")
        )
    """

    tag = "card"

    def __init__(self, title: str, *children, id: str = "", classes: str = "", **kwargs):
        # Insert a Label as the first child to serve as the card title
        title_label = Label(f" {title} ", classes="card-title")
        super().__init__(title_label, *children, id=id, classes=classes, **kwargs)

    def resolve_styles(self, stylesheet: dict):
        """Apply default card styling."""
        super().resolve_styles(stylesheet)

        # Default card styling (can be overridden)
        if "border" not in self.style:
            self.style["border"] = "ascii"
        if "padding" not in self.style:
            self.style["padding"] = 1
