"""Studio inspector panel that renders live App inspection data."""

from __future__ import annotations

from ..widgets.container import Container
from ..widgets.label import Label
from .card import Card


class StudioPanel(Card):
    """Panel variant of Casca Studio for embedding inside app layouts."""

    tag = "studio-panel"

    def __init__(
        self,
        title: str = "Casca Studio",
        max_style_rows: int = 8,
        id: str = "",
        classes: str = "",
        **kwargs,
    ):
        self.max_style_rows = max(1, int(max_style_rows))
        self._content = Container(style={"flex-direction": "column", "gap": 0})
        super().__init__(title, self._content, id=id, classes=classes, **kwargs)

    def render(self, app):
        if not hasattr(app, "get_studio_snapshot"):
            self._content.children = [Label("Studio snapshot API unavailable on app.")]
            return super().render(app)

        snapshot = app.get_studio_snapshot()
        lines = []
        focus_path = snapshot.get("focus_path") or []
        lines.append(Label("Focus path:"))
        lines.append(Label(" > ".join(focus_path) if focus_path else "none"))

        focused = snapshot.get("focused")
        if not focused:
            lines.append(Label("No focused widget"))
            self._content.children = lines
            return super().render(app)

        box = focused["box"]
        margin = focused["margin"]
        padding = focused["padding"]
        border = focused["border"]

        lines.extend(
            [
                Label(f"Widget: {focused['ref']}"),
                Label(f"Box: x={box['x']} y={box['y']} w={box['width']} h={box['height']}"),
                Label(
                    "Margin: "
                    f"t{margin['top']} r{margin['right']} b{margin['bottom']} l{margin['left']}"
                ),
                Label(
                    "Padding: "
                    f"t{padding['top']} r{padding['right']} b{padding['bottom']} l{padding['left']}"
                ),
                Label(f"Border: {border['width']}"),
                Label("Style:"),
            ]
        )

        style = focused.get("computed_style", {})
        for key, value in list(style.items())[: self.max_style_rows]:
            lines.append(Label(f"  {key}: {value}"))

        self._content.children = lines
        # Recalculate panel subtree after replacing dynamic inspector lines.
        self.calculate_layout(self.width, self.height)
        return super().render(app)
