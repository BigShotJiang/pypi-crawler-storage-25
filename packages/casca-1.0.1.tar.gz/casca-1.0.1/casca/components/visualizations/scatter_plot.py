from casca.components.widgets.base import WidgetBase
from casca.core.ansi import color_from_spec


class ScatterPlot(WidgetBase):
    """
    A 2D scatter plot using Braille characters.
    """

    tag = "scatterplot"

    BRAILLE_BASE = 0x2800

    DOT_MATRIX = [[0x1, 0x8], [0x2, 0x10], [0x4, 0x20], [0x40, 0x80]]

    def __init__(
        self,
        points: list[tuple[float, float]] = None,
        x_range: tuple[float, float] = None,
        y_range: tuple[float, float] = None,
        color: str = "cyan",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.points = points or []
        self.x_range = x_range
        self.y_range = y_range
        self.chart_color = color

    def update_points(self, new_points: list[tuple[float, float]]):
        self.points = new_points

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        w = int(self.props.get("width", available_width))
        h = int(self.props.get("height", available_height))
        self.width = w
        self.height = h
        return w, h

    def render_content(self, app):
        pad_top, pad_left = self._get_inner_bounds()
        inner_width = self.width - (pad_left * 2)
        inner_height = self.height - (pad_top * 2)

        if not self.points or inner_height <= 0 or inner_width <= 0:
            return

        x_vals = [p[0] for p in self.points]
        y_vals = [p[1] for p in self.points]

        min_x, max_x = min(x_vals, default=0), max(x_vals, default=1)
        min_y, max_y = min(y_vals, default=0), max(y_vals, default=1)

        if self.x_range:
            min_x, max_x = self.x_range
        if self.y_range:
            min_y, max_y = self.y_range

        rx = max_x - min_x
        ry = max_y - min_y
        if rx == 0:
            rx = 1
        if ry == 0:
            ry = 1

        dots_width = inner_width * 2
        dots_height = inner_height * 4

        grid = [[0 for _ in range(dots_width)] for _ in range(dots_height)]

        for px, py in self.points:
            nx = (px - min_x) / rx
            ny = (py - min_y) / ry

            x_idx = int(nx * (dots_width - 1))
            # Invert Y coordinate
            y_idx = int((1.0 - ny) * (dots_height - 1))

            if 0 <= x_idx < dots_width and 0 <= y_idx < dots_height:
                grid[y_idx][x_idx] = 1

        app.write(color_from_spec(fg=self.chart_color))

        for r in range(inner_height):
            line_chars = []
            for c in range(inner_width):
                char_val = self.BRAILLE_BASE
                for dot_r in range(4):
                    for dot_c in range(2):
                        grid_y = r * 4 + dot_r
                        grid_x = c * 2 + dot_c
                        if grid[grid_y][grid_x] == 1:
                            char_val += self.DOT_MATRIX[dot_r][dot_c]

                char_str = chr(char_val) if char_val != self.BRAILLE_BASE else " "
                line_chars.append(char_str)

            app.draw_text(self.x + pad_left + 1, self.y + pad_top + r + 1, "".join(line_chars))
