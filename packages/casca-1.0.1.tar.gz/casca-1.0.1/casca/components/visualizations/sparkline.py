from casca.components.widgets.base import WidgetBase
from casca.core.ansi import color_from_spec


class Sparkline(WidgetBase):
    tag = "sparkline"

    BRAILLE_BASE = 0x2800

    DOT_MATRIX = [[0x1, 0x8], [0x2, 0x10], [0x4, 0x20], [0x40, 0x80]]

    def __init__(
        self, data: list[float] = None, max_value: float = None, color: str = "cyan", **kwargs
    ):
        super().__init__(**kwargs)
        self.data = data or []
        self._explicit_max = max_value
        self.chart_color = color

    def update_data(self, new_data: list[float]):
        self.data = new_data

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        w = int(self.props.get("width", available_width))
        h = int(self.props.get("height", available_height))
        self.width = w
        self.height = h
        return w, h

    def render_content(self, app):
        pad_top, pad_left = self._get_inner_bounds()
        inner_width = self.width - (pad_left * 2)
        inner_height = self.height - (pad_top * 2)

        if not self.data or inner_height <= 0 or inner_width <= 0:
            return

        max_val = (
            self._explicit_max if self._explicit_max is not None else max(self.data, default=1)
        )
        if self._explicit_max is None:
            min_val = min(self.data, default=0)
        else:
            min_val = min(min(self.data, default=0), 0)
        point_range = max_val - min_val
        if point_range == 0:
            point_range = 1

        dots_width = inner_width * 2
        dots_height = inner_height * 4

        if dots_width == 1:
            points = [self.data[-1]]
        elif len(self.data) == 1:
            points = [self.data[0] for _ in range(dots_width)]
        else:
            # Resample to pixel columns and connect segments for a continuous sparkline.
            points = []
            max_idx = len(self.data) - 1
            for x in range(dots_width):
                t = (x / (dots_width - 1)) * max_idx
                i0 = int(t)
                i1 = min(max_idx, i0 + 1)
                frac = t - i0
                v0 = self.data[i0]
                v1 = self.data[i1]
                points.append(v0 + (v1 - v0) * frac)

        grid = [[0 for _ in range(dots_width)] for _ in range(dots_height)]

        prev_y = None
        for x, val in enumerate(points):
            normalized = (val - min_val) / point_range
            y = int((1.0 - normalized) * (dots_height - 1))
            y = max(0, min(dots_height - 1, y))
            if prev_y is None:
                grid[y][x] = 1
            else:
                start = min(prev_y, y)
                end = max(prev_y, y)
                for yy in range(start, end + 1):
                    grid[yy][x] = 1
            prev_y = y

        app.write(color_from_spec(fg=self.chart_color))

        for r in range(inner_height):
            line_chars = []
            for c in range(inner_width):
                char_val = self.BRAILLE_BASE
                for dot_r in range(4):
                    for dot_c in range(2):
                        grid_y = r * 4 + dot_r
                        grid_x = c * 2 + dot_c
                        if grid_x < len(points) and grid[grid_y][grid_x] == 1:
                            char_val += self.DOT_MATRIX[dot_r][dot_c]

                char_str = chr(char_val) if char_val != self.BRAILLE_BASE else " "
                line_chars.append(char_str)

            app.draw_text(self.x + pad_left + 1, self.y + pad_top + r + 1, "".join(line_chars))
