from casca.components.widgets.base import WidgetBase
from casca.core.ansi import color_from_spec


class Heatmap(WidgetBase):
    """
    A heatmap component for 2D data visualization.
    Uses ANSI background/foreground blocks.
    """

    tag = "heatmap"

    def __init__(
        self,
        data: list[list[float]] = None,
        color_scale: list[str] = None,  # e.g. ["blue", "cyan", "green", "yellow", "red"]
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.data = data or []
        self.color_scale = color_scale or [
            "bright_blue",
            "blue",
            "cyan",
            "green",
            "yellow",
            "red",
            "bright_red",
        ]

    def update_data(self, new_data: list[list[float]]):
        self.data = new_data

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        w = int(self.props.get("width", available_width))
        h = int(self.props.get("height", available_height))
        self.width = w
        self.height = h
        return w, h

    def render_content(self, app):
        pad_top, pad_left = self._get_inner_bounds()
        inner_width = self.width - (pad_left * 2)
        inner_height = self.height - (pad_top * 2)

        if not self.data or inner_height <= 0 or inner_width <= 0:
            return

        all_vals = [val for row in self.data for val in row]
        max_val = max(all_vals) if all_vals else 1
        min_val = min(all_vals) if all_vals else 0
        val_range = max_val - min_val if max_val > min_val else 1

        rows = len(self.data)
        cols = len(self.data[0]) if rows > 0 else 0
        if rows == 0 or cols == 0:
            return

        # Scale source matrix to available draw area.
        for r in range(inner_height):
            src_r = min(rows - 1, int((r / max(1, inner_height - 1)) * (rows - 1)))
            for c in range(inner_width):
                src_c = min(cols - 1, int((c / max(1, inner_width - 1)) * (cols - 1)))
                val = self.data[src_r][src_c]
                normalized = (val - min_val) / val_range

                # Find color index
                idx = int(normalized * (len(self.color_scale) - 1))
                idx = max(0, min(len(self.color_scale) - 1, idx))
                color = self.color_scale[idx]

                app.write(color_from_spec(fg=color))
                app.draw_text(self.x + pad_left + c + 1, self.y + pad_top + r + 1, "█")
