from casca.components.widgets.base import WidgetBase
from casca.core.ansi import color_from_spec


class Gauge(WidgetBase):
    tag = "gauge"

    def __init__(
        self,
        value: float = 0,
        min_value: float = 0,
        max_value: float = 100,
        warning_threshold: float = 70,
        danger_threshold: float = 90,
        label: str = "",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.value = value
        self.min_value = min_value
        self.max_value = max_value
        self.warning_threshold = warning_threshold
        self.danger_threshold = danger_threshold
        self.label = label

    def update_value(self, new_value: float):
        self.value = new_value

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        w = int(self.props.get("width", available_width))
        h = int(self.props.get("height", available_height))
        self.width = w
        self.height = h
        return w, h

    def render_content(self, app):
        pad_top, pad_left = self._get_inner_bounds()
        inner_width = self.width - (pad_left * 2)
        inner_height = self.height - (pad_top * 2)

        if inner_width <= 0 or inner_height <= 0:
            return

        clamped_value = max(self.min_value, min(self.max_value, self.value))
        range_val = self.max_value - self.min_value
        if range_val == 0:
            range_val = 1

        pct = (clamped_value - self.min_value) / range_val

        color = "bright_green"
        if clamped_value >= self.danger_threshold:
            color = "bright_red"
        elif clamped_value >= self.warning_threshold:
            color = "bright_yellow"

        meter_width = inner_width - 8  # reserve space for text like "100.0%"
        if meter_width < 1:
            meter_width = inner_width

        filled_width = int(pct * meter_width)
        empty_width = meter_width - filled_width

        # We write colors exactly to draw parts
        text_pct = f"{pct * 100:>5.1f}%"

        mid_y = inner_height // 2

        if self.label and inner_height > 1:
            label_text = self.label[:inner_width]
            app.write(color_from_spec(fg="default"))
            app.draw_text(
                self.x + pad_left + 1, self.y + pad_top + max(0, mid_y - 1) + 1, label_text
            )

        y_pos = self.y + pad_top + mid_y + 1
        x_pos = self.x + pad_left + 1

        app.write(color_from_spec(fg=color))
        app.draw_text(x_pos, y_pos, "█" * filled_width + "░" * empty_width)

        if inner_width >= meter_width + len(text_pct) + 1:
            app.write(color_from_spec(fg="default"))
            app.draw_text(x_pos + meter_width + 1, y_pos, text_pct)
