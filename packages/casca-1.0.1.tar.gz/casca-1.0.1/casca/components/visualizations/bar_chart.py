from casca.components.widgets.base import WidgetBase
from casca.core.ansi import color_from_spec


class BarChart(WidgetBase):
    tag = "barchart"

    BLOCKS = [" ", " ", "▂", "▃", "▄", "▅", "▆", "▇", "█"]

    def __init__(
        self,
        data: list[float] | dict[str, float] = None,
        max_value: float = None,
        color: str = "cyan",
        show_labels: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.data = data or []
        self._explicit_max = max_value
        self.chart_color = color
        self.show_labels = show_labels

    def update_data(self, new_data: list[float] | dict[str, float]):
        self.data = new_data

    def calculate_layout(self, available_width: int, available_height: int) -> tuple[int, int]:
        # Fill available space if not explicitly specified
        w = int(self.props.get("width", available_width))
        h = int(self.props.get("height", available_height))
        self.width = w
        self.height = h
        return w, h

    def render_content(self, app):
        pad_top, pad_left = self._get_inner_bounds()
        inner_width = self.width - (pad_left * 2)
        inner_height = self.height - (pad_top * 2)

        if inner_height <= 0 or inner_width <= 0 or not self.data:
            return

        if isinstance(self.data, dict):
            items = list(self.data.items())
        else:
            items = [(str(i), val) for i, val in enumerate(self.data)]

        items = items[-inner_width:]
        max_val = (
            self._explicit_max
            if self._explicit_max is not None
            else max((val for _, val in items), default=1)
        )
        if max_val == 0:
            max_val = 1

        chart_height = inner_height - (1 if self.show_labels else 0)

        # Apply color once
        app.write(color_from_spec(fg=self.chart_color))

        for row in range(chart_height - 1, -1, -1):
            line_chars = []
            for _, val in items:
                normalized = (val / max_val) * chart_height
                val_at_row = normalized - row

                if val_at_row >= 1:
                    char_idx = 8
                elif val_at_row <= 0:
                    char_idx = 0
                else:
                    char_idx = int(val_at_row * 8)

                line_chars.append(self.BLOCKS[char_idx])

            line = "".join(line_chars)
            app.draw_text(
                self.x + pad_left + 1, self.y + pad_top + (chart_height - 1 - row) + 1, line
            )

        if self.show_labels and inner_height > 0:
            label_line = "".join((lbl[0] if lbl else " ") for lbl, _ in items)
            app.write(color_from_spec(fg="default"))  # Reset color for labels
            app.draw_text(
                self.x + pad_left + 1, self.y + pad_top + chart_height + 1, label_line[:inner_width]
            )
