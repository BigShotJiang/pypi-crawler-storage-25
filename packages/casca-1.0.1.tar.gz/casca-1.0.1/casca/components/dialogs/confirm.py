"""
Confirm component - confirmation dialog with Yes/No buttons.
"""

from collections.abc import Callable

from ..widgets.button import Button
from .dialog import Dialog


class Confirm(Dialog):
    """
    A confirmation dialog with OK/Cancel or Yes/No buttons.

    Visual characteristics:
    - Red background for warning/caution
    - Two buttons: confirm and cancel
    - Returns boolean result via callback

    Usage:
        ```python
        def on_confirm(result: bool):
            if result:
                logger.info("User confirmed")
            else:
                logger.info("User cancelled")

        confirm = Confirm("Delete?", "Are you sure?", on_confirm=on_confirm)
        dialog_manager.push(confirm)
        ```
    """

    tag = "confirm"

    def __init__(
        self,
        title: str,
        message: str,
        id: str = "",
        classes: str = "",
        on_confirm: Callable[[bool], None] | None = None,
        ok_text: str = "Yes",
        cancel_text: str = "No",
        width: int = 45,
        **props,
    ):
        self.on_confirm = on_confirm

        def handle_confirm(event):
            if self.on_confirm:
                self.on_confirm(True)

        def handle_cancel(event):
            if self.on_confirm:
                self.on_confirm(False)

        confirm_btn = Button(
            ok_text,
            classes="confirm-ok-btn",
            on_click=handle_confirm,
            style={"width": 10, "border": "ascii"},
        )
        cancel_btn = Button(
            cancel_text,
            classes="confirm-cancel-btn",
            on_click=handle_cancel,
            style={"width": 10, "border": "ascii"},
        )

        super().__init__(
            title,
            message,
            confirm_btn,
            cancel_btn,
            id=id,
            classes=classes,
            on_close=lambda: self._handle_close(),
            width=width,
            height=11,
            **props,
        )

    def _handle_close(self):
        """Called when dialog is closed without explicit confirmation."""
        if self.on_confirm:
            self.on_confirm(False)

    def resolve_styles(self, stylesheet: dict):
        """Apply confirm-specific styling."""
        super().resolve_styles(stylesheet)

        # Confirm uses red background for warning
        if "background" not in self.style:
            self.style["background"] = "ansi(88)"
        if "color" not in self.style:
            self.style["color"] = "WHITE"
