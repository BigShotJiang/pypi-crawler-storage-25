"""
Dialog Manager - manages dialog stack and rendering.
"""

from collections.abc import Callable
from typing import Any

from ...core.events import KeyEvent, MouseEvent
from .overlay import Overlay


class DialogManager:
    """
    Manages a stack of dialogs/overlays with proper z-ordering.

    Features:
    - Push/pop dialog stack
    - Render all active dialogs over main content
    - Route input to topmost dialog
    - Convenience methods for common dialogs

    Usage:
        class MyApp(App):
            def __init__(self):
                super().__init__()
                self.dialog_manager = DialogManager()

            def render(self):
                # Render main UI
                self.root.render(self)
                # Render dialogs on top
                self.dialog_manager.render(self)

            def handle_input(self, event):
                # Route to dialogs first
                if self.dialog_manager.handle_input(event):
                    return
                super().handle_input(event)
    """

    def __init__(self):
        self._dialog_stack: list[Overlay] = []

    @property
    def has_dialogs(self) -> bool:
        """Check if any dialogs are active."""
        return len(self._dialog_stack) > 0

    @property
    def current_dialog(self) -> Overlay | None:
        """Get the topmost dialog."""
        return self._dialog_stack[-1] if self._dialog_stack else None

    @property
    def dialog_count(self) -> int:
        """Get the number of active dialogs."""
        return len(self._dialog_stack)

    def push(self, dialog: Overlay):
        """
        Add a dialog to the stack.

        Args:
            dialog: The dialog to display
        """
        self._dialog_stack.append(dialog)

    def pop(self) -> Overlay | None:
        """
        Remove and return the top dialog.

        Returns:
            The removed dialog, or None if stack was empty
        """
        if self._dialog_stack:
            return self._dialog_stack.pop()
        return None

    def remove(self, dialog: Overlay) -> bool:
        """
        Remove a specific dialog from the stack.

        Args:
            dialog: The dialog to remove

        Returns:
            True if dialog was found and removed
        """
        if dialog in self._dialog_stack:
            self._dialog_stack.remove(dialog)
            return True
        return False

    def clear(self):
        """Remove all dialogs from the stack."""
        self._dialog_stack.clear()

    def render(self, app):
        """
        Render all active dialogs.

        Call this after rendering your main UI content.

        Args:
            app: The application instance
        """
        width, height = getattr(app, "_last_size", (80, 24))
        for dialog in self._dialog_stack:
            # Dialogs live outside the normal root tree, so resolve styles/layout here.
            if hasattr(app, "stylesheet"):
                dialog.resolve_styles(app.stylesheet)
            dialog.calculate_layout(width, height)
            dialog.render(app)

    def handle_input(self, event: KeyEvent) -> bool:
        """
        Route keyboard input to the topmost dialog.

        Args:
            event: The key event

        Returns:
            True if the dialog handled the event
        """
        if self._dialog_stack:
            return self._dialog_stack[-1].handle_input(event)
        return False

    def handle_mouse(self, event: MouseEvent, app) -> bool:
        """
        Route mouse events to the topmost dialog.

        Args:
            event: The mouse event
            app: The application instance

        Returns:
            True if the dialog handled the event
        """
        if self._dialog_stack:
            return self._dialog_stack[-1].handle_mouse(event, app)
        return False


# Convenience functions for quick dialog display


def show_alert(
    app: Any,
    title: str,
    message: str,
    on_close: Callable | None = None,
    ok_text: str = "OK",
    width: int = 45,
) -> Any:
    """
    Convenience function to show an alert dialog.

    Args:
        app: Application with dialog_manager attribute
        title: Alert title
        message: Alert message
        on_close: Callback when alert is dismissed
        ok_text: Text for OK button
        width: Dialog width

    Returns:
        The created Alert instance
    """
    from .alert import Alert

    alert = Alert(title, message, on_close=on_close, ok_text=ok_text, width=width)
    if hasattr(app, "dialog_manager"):
        app.dialog_manager.push(alert)
    return alert


def show_confirm(
    app: Any,
    title: str,
    message: str,
    on_confirm: Callable[[bool], None] | None = None,
    ok_text: str = "Yes",
    cancel_text: str = "No",
    width: int = 45,
) -> Any:
    """
    Convenience function to show a confirmation dialog.

    Args:
        app: Application with dialog_manager attribute
        title: Confirm title
        message: Confirm message
        on_confirm: Callback with boolean result
        ok_text: Text for confirm button
        cancel_text: Text for cancel button
        width: Dialog width

    Returns:
        The created Confirm instance
    """
    from .confirm import Confirm

    confirm = Confirm(
        title, message, on_confirm=on_confirm, ok_text=ok_text, cancel_text=cancel_text, width=width
    )
    if hasattr(app, "dialog_manager"):
        app.dialog_manager.push(confirm)
    return confirm


def show_prompt(
    app: Any,
    title: str,
    message: str,
    on_submit: Callable[[str], None] | None = None,
    placeholder: str = "",
    ok_text: str = "OK",
    cancel_text: str = "Cancel",
    width: int = 50,
) -> Any:
    """
    Convenience function to show a prompt dialog.

    Args:
        app: Application with dialog_manager attribute
        title: Prompt title
        message: Prompt message
        on_submit: Callback with entered text
        placeholder: Input placeholder text
        ok_text: Text for OK button
        cancel_text: Text for cancel button
        width: Dialog width

    Returns:
        The created Prompt instance
    """
    from .prompt import Prompt

    prompt = Prompt(
        title,
        message,
        on_submit=on_submit,
        placeholder=placeholder,
        ok_text=ok_text,
        cancel_text=cancel_text,
        width=width,
    )
    if hasattr(app, "dialog_manager"):
        app.dialog_manager.push(prompt)
    return prompt
