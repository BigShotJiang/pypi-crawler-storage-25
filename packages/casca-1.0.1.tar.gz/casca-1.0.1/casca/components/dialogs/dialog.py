"""
Dialog component - standard dialog with buttons.
"""

from collections.abc import Callable

from ..widgets.container import Container
from ..widgets.label import Label
from .modal import Modal


class Dialog(Modal):
    """
    A standard dialog with title, message, and action buttons.

    Extends Modal with:
    - Pre-built message area
    - Button container for actions
    - Standardized layout

    Attributes:
        message: The dialog message text
    """

    tag = "dialog"

    def __init__(
        self,
        title: str,
        message: str,
        *buttons,
        id: str = "",
        classes: str = "",
        on_close: Callable | None = None,
        width: int = 50,
        height: int = 12,
        **props,
    ):
        self.dialog_message = message

        # Create content area with message
        message_label = Label(message, classes="dialog-message", style={"white-space": "normal"})

        # Create button container
        button_container = Container(
            *buttons,
            classes="dialog-buttons",
            style={"flex-direction": "row", "gap": 1, "margin-top": 1},
        )

        super().__init__(
            title,
            message_label,
            button_container,
            id=id,
            classes=classes,
            on_close=on_close,
            width=width,
            height=height,
            **props,
        )

    def resolve_styles(self, stylesheet: dict):
        """Apply default dialog styling."""
        super().resolve_styles(stylesheet)

        # Default dialog styling
        if "color" not in self.style:
            self.style["color"] = "WHITE"
