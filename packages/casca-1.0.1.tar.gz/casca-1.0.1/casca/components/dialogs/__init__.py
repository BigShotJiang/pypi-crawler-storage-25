"""
Dialog and overlay components for Casca.

This module provides modal dialogs, alerts, confirmations, and prompts.

Inheritance Hierarchy:
    WidgetBase (from widgets.base)
        └── Overlay
            └── Modal
                └── Dialog
                    ├── Alert
                    ├── Confirm
                    └── Prompt
"""

from .alert import Alert
from .confirm import Confirm
from .dialog import Dialog
from .manager import DialogManager, show_alert, show_confirm, show_prompt
from .modal import Modal
from .overlay import Overlay
from .prompt import Prompt

__all__ = [
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
]
