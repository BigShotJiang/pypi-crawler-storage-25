"""
Accessibility module for Casca TUI.

Provides accessibility features including:
- Focus management and trapping
- Programmatic focus API
- Screen reader hints
- Configurable keybindings
"""

from collections.abc import Callable
from typing import Any

from ..core.events import KeyEvent
from ..dom.node import Widget


class FocusManager:
    """
    Manages focus traversal and focus trapping for accessibility.

    Features:
    - Programmatic focus API
    - Focus trap for modals
    - Configurable tab order
    - Focus ring styling
    """

    def __init__(self):
        self._focus_order: list[str] = []  # List of widget IDs in tab order
        self._focus_trap: Widget | None = None  # Widget to trap focus within
        self._focus_ring_style: dict[str, Any] = {"border": "solid", "border-color": "cyan"}

    def set_focus_order(self, widget_ids: list[str]) -> None:
        """
        Set the tab order for widgets.

        Args:
            widget_ids: List of widget IDs in desired tab order
        """
        self._focus_order = widget_ids

    def add_to_focus_order(self, widget_id: str, index: int = -1) -> None:
        """
        Add a widget to the focus order.

        Args:
            widget_id: ID of widget to add
            index: Position to insert (-1 for end)
        """
        if widget_id not in self._focus_order:
            if index == -1:
                self._focus_order.append(widget_id)
            else:
                self._focus_order.insert(index, widget_id)

    def remove_from_focus_order(self, widget_id: str) -> None:
        """
        Remove a widget from the focus order.

        Args:
            widget_id: ID of widget to remove
        """
        if widget_id in self._focus_order:
            self._focus_order.remove(widget_id)

    def get_next_focus_id(self, current_id: str | None, reverse: bool = False) -> str | None:
        """
        Get the next widget ID in focus order.

        Args:
            current_id: Current focused widget ID
            reverse: If True, get previous instead of next

        Returns:
            Next widget ID or None if at end
        """
        if not self._focus_order:
            return None

        if current_id is None:
            return self._focus_order[0] if not reverse else self._focus_order[-1]

        try:
            current_index = self._focus_order.index(current_id)
        except ValueError:
            return self._focus_order[0] if not reverse else self._focus_order[-1]

        if reverse:
            next_index = (current_index - 1) % len(self._focus_order)
        else:
            next_index = (current_index + 1) % len(self._focus_order)

        return self._focus_order[next_index]

    def enable_focus_trap(self, container: Widget) -> None:
        """
        Enable focus trap within a container (e.g., modal dialog).

        Args:
            container: Widget to trap focus within
        """
        self._focus_trap = container

    def disable_focus_trap(self) -> None:
        """Disable the current focus trap."""
        self._focus_trap = None

    def is_focus_trapped(self) -> bool:
        """Check if focus trap is active."""
        return self._focus_trap is not None

    def constrain_focus(self, widget: Widget) -> bool:
        """
        Check if a widget is within the focus trap.

        Args:
            widget: Widget to check

        Returns:
            True if focus is allowed, False if trapped
        """
        if not self._focus_trap:
            return True

        return self._is_descendant(widget, self._focus_trap)

    def _is_descendant(self, widget: Widget, ancestor: Widget) -> bool:
        """Check if widget is a descendant of ancestor."""
        current = widget
        while hasattr(current, "parent"):
            current = getattr(current, "parent", None)
            if current is ancestor:
                return True
        return False

    def set_focus_ring_style(self, style: dict[str, Any]) -> None:
        """
        Set the focus ring style.

        Args:
            style: Dictionary of style properties
        """
        self._focus_ring_style = style

    def apply_focus_ring(self, widget: Widget) -> None:
        """
        Apply focus ring styling to a widget.

        Args:
            widget: Widget to apply focus ring to
        """
        if hasattr(widget, "style"):
            widget.style.update(self._focus_ring_style)

    def remove_focus_ring(self, widget: Widget) -> None:
        """
        Remove focus ring styling from a widget.

        Args:
            widget: Widget to remove focus ring from
        """
        if hasattr(widget, "style") and hasattr(widget, "props"):
            # Remove focus ring styles
            for key in self._focus_ring_style:
                if key in widget.style:
                    del widget.style[key]


class AccessibilityManager:
    """
    Central accessibility manager for Casca applications.

    Features:
    - Screen reader hints and announcements
    - Keyboard shortcut configuration
    - High contrast mode support
    - Focus management integration
    """

    def __init__(self):
        self.focus_manager = FocusManager()
        self._screen_reader_queue: list[str] = []
        self._keybindings: dict[str, Callable] = {}
        self._high_contrast: bool = False
        self._verbose_mode: bool = False

    def announce(self, message: str, priority: str = "polite") -> None:
        """
        Announce a message to screen readers.

        Args:
            message: Message to announce
            priority: "polite" or "assertive"
        """
        self._screen_reader_queue.append(message)
        # In a real implementation, this would interface with OS accessibility APIs

    def get_announcements(self) -> list[str]:
        """Get and clear pending announcements."""
        announcements = self._screen_reader_queue.copy()
        self._screen_reader_queue.clear()
        return announcements

    def register_keybinding(self, key: str, handler: Callable[[], None]) -> None:
        """
        Register a custom keyboard shortcut.

        Args:
            key: Key combination (e.g., "Ctrl+S", "F1")
            handler: Callback function to invoke
        """
        self._keybindings[key] = handler

    def unregister_keybinding(self, key: str) -> None:
        """
        Unregister a keyboard shortcut.

        Args:
            key: Key combination to unregister
        """
        if key in self._keybindings:
            del self._keybindings[key]

    def handle_keybinding(self, event: KeyEvent) -> bool:
        """
        Handle a key event and invoke registered keybindings.

        Args:
            event: Key event to handle

        Returns:
            True if a keybinding was triggered
        """
        key_combo = self._event_to_key_combo(event)

        if key_combo in self._keybindings:
            self._keybindings[key_combo]()
            return True

        return False

    def _event_to_key_combo(self, event: KeyEvent) -> str:
        """Convert a KeyEvent to a key combination string."""
        parts = []

        # Check for modifiers (would need to be added to KeyEvent)
        if getattr(event, "ctrl", False):
            parts.append("Ctrl")
        if getattr(event, "alt", False):
            parts.append("Alt")
        if getattr(event, "shift", False):
            parts.append("Shift")

        # Add key
        key_name = event.key
        if len(key_name) == 1 and key_name.isalpha():
            key_name = key_name.upper()
        parts.append(key_name)

        return "+".join(parts)

    def enable_high_contrast(self) -> None:
        """Enable high contrast mode."""
        self._high_contrast = True

    def disable_high_contrast(self) -> None:
        """Disable high contrast mode."""
        self._high_contrast = False

    def is_high_contrast(self) -> bool:
        """Check if high contrast mode is enabled."""
        return self._high_contrast

    def enable_verbose_mode(self) -> None:
        """Enable verbose screen reader mode."""
        self._verbose_mode = True

    def disable_verbose_mode(self) -> None:
        """Disable verbose screen reader mode."""
        self._verbose_mode = False

    def is_verbose(self) -> bool:
        """Check if verbose mode is enabled."""
        return self._verbose_mode

    def get_widget_description(self, widget: Widget) -> str:
        """
        Get a description of a widget for screen readers.

        Args:
            widget: Widget to describe

        Returns:
            Description string
        """
        description = []

        # Widget type
        if hasattr(widget, "tag"):
            description.append(f"{widget.tag}")

        # Widget content/label
        if hasattr(widget, "label") and widget.label:
            description.append(f"'{widget.label}'")

        # Widget state
        if hasattr(widget, "focused") and widget.focused:
            description.append("focused")

        if hasattr(widget, "disabled") and widget.disabled:
            description.append("disabled")

        return " ".join(description)


# Global accessibility instance
_accessibility: AccessibilityManager | None = None


def get_accessibility() -> AccessibilityManager:
    """Get the global accessibility manager."""
    global _accessibility
    if _accessibility is None:
        _accessibility = AccessibilityManager()
    return _accessibility


def set_accessibility(manager: AccessibilityManager) -> None:
    """Set the global accessibility manager."""
    global _accessibility
    _accessibility = manager
