"""
Casca Core Application Module.

Provides the main App class and event loop for TUI applications.
"""

import logging
import os
import select
import signal
import sys
import threading
from collections.abc import Callable
from queue import Empty, Queue
from typing import Any

from ..core.store import Store
from ..dom.node import Widget
from ..style.css import load_css_file, parse_css, validate_stylesheet
from .ansi import CLEAR_SCREEN, RESET, move_cursor
from .app_debug import AppDebugStudioMixin
from .app_focus import AppFocusMixin
from .events import KeyEvent, Keys, MouseEvent, ResizeEvent
from .input_parser import parse_terminal_input_incremental
from .notifications import ToastManager
from .screenshot import capture_frame_screenshot
from .terminal import RawTerminal, get_terminal_size
from .themes import THEMES, apply_theme_tokens

# Type aliases
Callback = Callable[[], None]
TaskCallback = Callable[[Any, Exception | None], None]

# Constants
DEFAULT_FPS = 20
FRAME_TIMEOUT = 1.0 / DEFAULT_FPS
MAX_INPUT_READ = 1024
MAX_CALLBACKS_PER_TICK = 64
MAX_INTERVALS = 100

# Module logger
logger = logging.getLogger(__name__)


class App(AppFocusMixin, AppDebugStudioMixin):
    """
    The main application context and event loop.

    Provides a base class for rendering and handling events.
    Use App as the base class for your TUI applications.

    Example:
        ```python
        class MyApp(App):
            def on_init(self):
                self.root = Container(Label("Hello"))

        if __name__ == "__main__":
            MyApp().run()
        ```
    """

    # Class-level configuration
    css: str = ""
    css_path: str = ""
    theme: str = "default"
    debug: bool = False
    debug_layout: bool = False
    studio_mode: bool = False

    # Screenshot configuration
    screenshot_key: str = Keys.F12
    screenshot_dir: str = ".casca_screenshots"
    screenshot_cell_w: float = 9.0
    screenshot_cell_h: float = 18.0
    screenshot_font_size: float = 14.0
    screenshot_baseline: float = 14.0
    screenshot_shape_rendering: str = "geometricPrecision"
    screenshot_text_rendering: str = "optimizeLegibility"
    screenshot_length_adjust: str = "spacingAndGlyphs"
    screenshot_font_family: str = "'DejaVu Sans Mono','Noto Sans Mono','Liberation Mono',monospace"
    screenshot_force_text_length: bool = False

    def __init__(self) -> None:
        """Initialize the application context."""
        self._running: bool = False
        self._last_size: tuple[int, int] = get_terminal_size()
        self._needs_render: bool = True

        # Buffer to accumulate output before flushing (double buffer concept)
        self._output_buffer: list[str] = []
        self._input_buffer: str = ""
        self._last_frame_output: str = ""

        # DOM Root & Focus State
        self.root: Widget | None = None
        self.theme: str = getattr(self, "theme", "default")
        self.stylesheet: dict[str, Any] = self._load_stylesheet()
        self.focused_widget: Widget | None = None
        self.focused_id: str | None = None
        self._last_error_lines: list[str] = []
        self.toast_manager: ToastManager = ToastManager()
        self.banner_message: str = ""
        self.banner_level: str = "info"

        # Async/task scheduler primitives.
        self._main_thread_callbacks: Queue[Callback] = Queue()
        self._interval_lock: threading.RLock = threading.RLock()
        self._intervals: dict[int, tuple[threading.Event, threading.Thread]] = {}
        self._next_interval_id: int = 1
        self._emitted_debug_warnings: set = set()
        self._studio_visible: bool = bool(getattr(self, "studio_mode", False))
        self.store: Store | None = None
        self._store_unsubscribe: Callable[[], None] | None = None

    def _load_stylesheet(self) -> dict[str, Any]:
        """
        Build stylesheet from optional CSS file + inline css string.

        Returns:
            Dictionary of parsed CSS rules

        Raises:
            FileNotFoundError: If css_path is set but file doesn't exist
            PermissionError: If css_path file can't be read
        """
        css_parts = []
        if self.css_path:
            css_parts.append(load_css_file(self.css_path))
        if self.css:
            css_parts.append(self.css)
        stylesheet = parse_css("\n".join(css_parts))
        theme_tokens = THEMES.get(self.theme, THEMES["default"])
        stylesheet = apply_theme_tokens(stylesheet, theme_tokens)
        if self.debug:
            for warning in validate_stylesheet(stylesheet):
                logger.warning("Style warning: %s", warning)
        return stylesheet

    def set_theme(self, theme_name: str) -> None:
        """
        Switch to a named theme and reload resolved stylesheet tokens.

        Args:
            theme_name: Name of the theme to apply

        Raises:
            ValueError: If theme_name is not found in available themes
        """
        if theme_name not in THEMES:
            available = ", ".join(sorted(THEMES))
            raise ValueError(f"Unknown theme '{theme_name}'. Available: {available}")
        self.theme = theme_name
        self.reload_stylesheet()
        self.invalidate()

    def reload_stylesheet(self) -> None:
        """Reload CSS from file and inline styles at runtime."""
        self.stylesheet = self._load_stylesheet()

    def run(self) -> None:
        """
        Start the event loop.

        This method initializes the terminal, handles input events,
        and runs the main application loop until exit() is called.
        """
        self._running = True
        logger.info("Starting Casca application")

        # Attach to SIGWINCH for resize events in Unix
        try:
            signal.signal(signal.SIGWINCH, self._handle_sigwinch)
        except AttributeError:
            # SIGWINCH is not available on all systems (e.g. Windows)
            logger.debug("SIGWINCH not available on this platform")
            pass

        with RawTerminal():
            # Refresh size in raw mode and paint the first frame immediately.
            self._last_size = get_terminal_size()
            self.request_render()
            self._safe_render_cycle()

            while self._running:
                # Wait for input (0.05s timeout for 20 FPS refresh rate max)
                dr, _, _ = select.select([sys.stdin], [], [], FRAME_TIMEOUT)

                if dr:
                    # Read all available bytes
                    try:
                        data = os.read(sys.stdin.fileno(), MAX_INPUT_READ).decode(
                            "utf-8", errors="replace"
                        )
                    except BlockingIOError:
                        continue
                    except OSError as exc:
                        logger.error("Error reading from stdin: %s", exc)
                        continue

                    if not data:
                        continue

                    mouse_events, key_events, exit_requested, self._input_buffer = (
                        parse_terminal_input_incremental(
                            data,
                            pending=self._input_buffer,
                        )
                    )
                    for mouse_evt in mouse_events:
                        try:
                            self.handle_mouse(mouse_evt)
                        except Exception as exc:
                            logger.exception("Error in handle_mouse: %s", exc)
                            self.on_error(exc, "handle_mouse")

                    if exit_requested:
                        logger.info("Exit requested from terminal")
                        self.exit()

                    for key_evt in key_events:
                        try:
                            self.handle_input(key_evt)
                        except Exception as exc:
                            logger.exception("Error in handle_input: %s", exc)
                            self.on_error(exc, "handle_input")

                    # Request a re-render after handling input events.
                    if self._running:
                        self.request_render()

                # Optionally check if size changed periodically if SIGWINCH failed
                current_size = get_terminal_size()
                if current_size != self._last_size:
                    self._last_size = current_size
                    try:
                        self.handle_resize(ResizeEvent(*current_size))
                    except Exception as exc:
                        logger.exception("Error in handle_resize: %s", exc)
                        self.on_error(exc, "handle_resize")
                    self.request_render()

                # Drain callbacks scheduled by background tasks/timers.
                self._drain_main_thread_callbacks()

                if self._running and self._needs_render:
                    self._safe_render_cycle()

        logger.info("Shutting down Casca application")
        self._clear_all_intervals()

    def exit(self) -> None:
        """
        Signal the application to break out of the event loop.

        This method sets the running flag to False and clears all intervals.
        """
        self._running = False
        self._clear_all_intervals()

    def invalidate(self) -> None:
        """
        Mark UI tree dirty so it gets rebuilt on the next render cycle.

        This clears the root widget, forcing a full rebuild on the next render.
        """
        self.root = None
        self.request_render()

    def request_render(self) -> None:
        """Request a render pass on the next event-loop tick."""
        self._needs_render = True

    def _drain_main_thread_callbacks(self) -> None:
        """
        Run callbacks enqueued by worker threads on the main loop.
        """
        for _ in range(MAX_CALLBACKS_PER_TICK):
            try:
                callback = self._main_thread_callbacks.get_nowait()
            except Empty:
                break

            try:
                callback()
            except Exception as exc:
                logger.exception("Error in main_thread_callback: %s", exc)
                self.on_error(exc, "main_thread_callback")

            self.request_render()

    def _enqueue_main_thread_callback(self, callback: Callback) -> None:
        """Enqueue a callback to be run on the main thread."""
        self._main_thread_callbacks.put(callback)

    def run_task(
        self,
        fn: Callable[[], Any],
        on_done: TaskCallback | None = None,
        name: str | None = None,
        daemon: bool = True,
    ) -> threading.Thread:
        """
        Run fn in a worker thread and optionally call on_done(result, error) on main thread.

        Args:
            fn: Callable with no args executed in a background thread.
            on_done: Optional callback executed on the main thread with signature
                on_done(result, error), where exactly one is non-None.
            name: Optional thread name.
            daemon: Worker thread daemon flag.

        Returns:
            The started threading.Thread instance.
        """

        def worker() -> None:
            result: Any = None
            error: Exception | None = None
            try:
                result = fn()
            except Exception as exc:
                error = exc
                logger.exception("Error in run_task '%s': %s", name or "unnamed", exc)

            if on_done:
                self._enqueue_main_thread_callback(lambda: on_done(result, error))
            elif error:
                self._enqueue_main_thread_callback(lambda: self.on_error(error, "run_task"))
            else:
                self.request_render()

        thread = threading.Thread(target=worker, name=name or "casca-task", daemon=daemon)
        thread.start()
        return thread

    def set_interval(
        self,
        callback: Callback,
        interval_s: float,
        run_immediately: bool = False,
    ) -> int:
        """
        Schedule callback to run periodically on the main thread.

        Args:
            callback: Function to call at each interval.
            interval_s: Interval in seconds (minimum 0.01).
            run_immediately: If True, run callback immediately before starting interval.

        Returns:
            A numeric interval id that can be passed to clear_interval().

        Raises:
            RuntimeError: If maximum number of intervals has been reached.
        """
        interval_s = max(0.01, float(interval_s))
        stop_event = threading.Event()

        with self._interval_lock:
            # Check interval limit
            if len(self._intervals) >= MAX_INTERVALS:
                raise RuntimeError(f"Maximum number of intervals ({MAX_INTERVALS}) reached")

            interval_id = self._next_interval_id
            self._next_interval_id += 1

        def interval_worker() -> None:
            if run_immediately:
                self._enqueue_main_thread_callback(callback)
            while not stop_event.wait(interval_s):
                self._enqueue_main_thread_callback(callback)

        thread = threading.Thread(
            target=interval_worker,
            name=f"casca-interval-{interval_id}",
            daemon=True,
        )

        with self._interval_lock:
            self._intervals[interval_id] = (stop_event, thread)

        thread.start()
        return interval_id

    def clear_interval(self, interval_id: int) -> bool:
        """
        Stop a previously registered periodic callback.

        Args:
            interval_id: The ID returned from set_interval().

        Returns:
            True if the interval was found and stopped, False otherwise.
        """
        with self._interval_lock:
            pair = self._intervals.pop(interval_id, None)
        if not pair:
            return False

        stop_event, _thread = pair
        stop_event.set()
        return True

    def _clear_all_intervals(self) -> None:
        """Stop all registered interval workers."""
        with self._interval_lock:
            items = list(self._intervals.items())
            self._intervals.clear()

        for _interval_id, (stop_event, _thread) in items:
            stop_event.set()

    def set_state(self, rerender: bool = True, **updates: Any) -> None:
        """
        Update app attributes and optionally invalidate the UI.

        Args:
            rerender: If True, invalidate the UI after updating state.
            **updates: Keyword arguments to set as attributes.

        Example:
            self.set_state(counter=counter + 1, status_text="Updated")
        """
        for key, value in updates.items():
            setattr(self, key, value)
        if rerender:
            self.invalidate()

    def set_store(self, store: Store | None, rebuild_on_update: bool = True) -> None:
        """
        Attach a unidirectional store and refresh when state updates.

        Args:
            store: Store instance (or None to detach).
            rebuild_on_update: When True, invalidate the UI tree so build_ui()
                sees latest state on each dispatch. When False, only request
                a render pass without rebuilding the tree.
        """
        if self._store_unsubscribe:
            self._store_unsubscribe()
            self._store_unsubscribe = None

        self.store = store
        if store is None:
            return

        def _on_state_change(_state: dict[str, Any]) -> None:
            if rebuild_on_update:
                self.invalidate()
            else:
                self.request_render()

        if rebuild_on_update:
            self._store_unsubscribe = store.subscribe(_on_state_change)
        else:
            self._store_unsubscribe = store.subscribe(_on_state_change)

    def dispatch(self, action: dict[str, Any]) -> Any:
        """
        Dispatch an action through the attached store.

        Args:
            action: Action dictionary with at least a 'type' key.

        Returns:
            The result of dispatching the action.

        Raises:
            RuntimeError: If no store is attached.
        """
        if self.store is None:
            raise RuntimeError("No store attached. Call set_store(store) first.")
        return self.store.dispatch(action)

    def get_state(self) -> dict[str, Any] | None:
        """
        Return current store state if a store is attached.

        Returns:
            Current state dictionary or None if no store is attached.
        """
        if self.store is None:
            return None
        return self.store.get_state()

    def write(self, text: str) -> None:
        """
        Appends output to the render buffer.

        Args:
            text: Text to append to the buffer.
        """
        self._output_buffer.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip: bool = True) -> None:
        """
        Helper to draw text with optional vertical clipping.

        Args:
            x: X position (1-based terminal column).
            y: Y position (1-based terminal row).
            text: Text to draw.
            apply_clip: If True, apply clipping from clip_rect if set.
        """
        if apply_clip and hasattr(self, "clip_rect") and self.clip_rect:
            min_y, max_y, min_x, max_x = self.clip_rect
            if y < min_y or y >= max_y:
                return
            # horizontal clipping
            if x < min_x:
                text = text[min_x - x :]
                x = min_x
            if x + len(text) > max_x:
                text = text[: max_x - x]
            if not text:
                return
        self.write(move_cursor(x, y))
        self.write(text)

    def flush(self) -> None:
        """Writes the entire render buffer to the stdout in one go to prevent flicker."""
        if self._output_buffer:
            frame = "".join(self._output_buffer)
            self._last_frame_output = frame
            sys.stdout.write(frame)
            sys.stdout.flush()
            self._output_buffer.clear()

    def _capture_screenshot(self) -> bool:
        """
        Persist the most recently rendered ANSI frame to disk.

        Returns:
            True if screenshot was captured successfully, False otherwise.
        """
        if not self._last_frame_output:
            logger.warning("Screenshot capture failed: no rendered frame")
            return False

        out_dir = getattr(self, "screenshot_dir", ".casca_screenshots") or ".casca_screenshots"
        settings = {
            "screenshot_cell_w": getattr(self, "screenshot_cell_w", 9.0),
            "screenshot_cell_h": getattr(self, "screenshot_cell_h", 18.0),
            "screenshot_font_size": getattr(self, "screenshot_font_size", 14.0),
            "screenshot_baseline": getattr(self, "screenshot_baseline", 14.0),
            "screenshot_shape_rendering": getattr(
                self, "screenshot_shape_rendering", "geometricPrecision"
            ),
            "screenshot_text_rendering": getattr(
                self, "screenshot_text_rendering", "optimizeLegibility"
            ),
            "screenshot_length_adjust": getattr(
                self, "screenshot_length_adjust", "spacingAndGlyphs"
            ),
            "screenshot_font_family": getattr(
                self,
                "screenshot_font_family",
                "'DejaVu Sans Mono','Noto Sans Mono','Liberation Mono',monospace",
            ),
            "screenshot_force_text_length": bool(
                getattr(self, "screenshot_force_text_length", False)
            ),
        }
        svg_path = capture_frame_screenshot(
            frame=self._last_frame_output,
            size=self._last_size,
            out_dir=out_dir,
            settings=settings,
        )

        if not svg_path:
            logger.warning("Screenshot capture returned no path")
            return False

        self.set_banner(f"Screenshot saved: {svg_path}", level="info")
        return True

    def _render_cycle(self) -> None:
        """Internal render pass to orchestrate drawing."""
        self.write(CLEAR_SCREEN)
        self.write(move_cursor(1, 1))

        # Call user's render method
        self.render()
        self._render_layout_overlay()
        self._render_studio_overlay()
        self._render_banner()
        self._render_toasts()
        self._render_error_overlay()

        self.write(RESET)
        self.flush()

    def show_toast(self, message: str, level: str = "info", duration: float = 2.0) -> None:
        """
        Show a transient toast message.

        Args:
            message: Toast message text.
            level: Toast level (info, warn, error).
            duration: Duration in seconds before auto-dismiss.
        """
        self.toast_manager.push(message, level=level, duration=duration)
        self.invalidate()

    def get_notification_history(self, limit: int | None = None) -> list[dict[str, Any]]:
        """
        Return toast history entries for notification-center style UIs.

        Args:
            limit: Maximum number of entries to return.

        Returns:
            List of toast history dictionaries.
        """
        return self.toast_manager.history(limit=limit)

    def clear_notification_history(self) -> None:
        """Clear stored notification history entries."""
        self.toast_manager.clear_history()
        self.request_render()

    def set_banner(self, message: str, level: str = "info") -> None:
        """
        Set persistent status banner text.

        Args:
            message: Banner message text.
            level: Banner level (info, warn, error).
        """
        self.banner_message = message
        self.banner_level = level
        self.invalidate()

    def clear_banner(self) -> None:
        """Clear status banner text."""
        self.banner_message = ""
        self.invalidate()

    def _safe_render_cycle(self) -> None:
        """Render cycle with an error boundary."""
        try:
            self._render_cycle()
        except Exception as exc:
            logger.exception("Error in render cycle: %s", exc)
            self.on_error(exc, "render")
            self.write(CLEAR_SCREEN)
            self.write(move_cursor(1, 1))
            self._render_error_overlay()
            self.write(RESET)
            self.flush()
        finally:
            self._needs_render = False

    def _handle_sigwinch(self, signum: int, frame: Any) -> None:
        """
        Unix signal handler for terminal resize.

        Args:
            signum: Signal number.
            frame: Current stack frame.
        """
        size = get_terminal_size()
        self._last_size = size
        self.handle_resize(ResizeEvent(width=size[0], height=size[1]))
        if self._running:
            self.request_render()

    def on_error(self, exc: Exception, context: str) -> None:
        """
        Handle framework/runtime errors.

        Override this in app subclasses for custom behavior.

        Args:
            exc: The exception that occurred.
            context: Context string describing where the error occurred.
        """
        if self.debug:
            import traceback

            header = f"ERROR in {context}: {type(exc).__name__}: {exc}"
            stack = traceback.format_exception(type(exc), exc, exc.__traceback__)
            self._last_error_lines = [header] + [
                line.rstrip() for line in "".join(stack).splitlines()
            ]
            return

        logger.error("%s: %s: %s", context, type(exc).__name__, exc)

    # --- Methods to be overridden by subclasses (User API) ---

    def handle_input(self, event: KeyEvent) -> None:
        """
        Triggered when a key is pressed.

        Args:
            event: The key event to handle.
        """
        if event.key == Keys.F2:
            self._studio_visible = not self._studio_visible
            self.request_render()
            return

        if event.key == getattr(self, "screenshot_key", Keys.F12):
            if not self._capture_screenshot():
                self.set_banner("Screenshot unavailable (no rendered frame yet)", level="warn")
            return

        # By default, press 'q' to quit. Subclasses can override.
        if event.key == "q":
            self.exit()

        if event.key == "\t":
            self.focus_next(reverse=False)
            return
        if event.key == "\x1b[Z":
            self.focus_next(reverse=True)
            return

        # Dialog scope: when dialogs are active, route events there first.
        if hasattr(self, "dialog_manager") and getattr(self.dialog_manager, "has_dialogs", False):
            if self.dialog_manager.handle_input(event):
                return

        # Prioritize focused widget, else try routing through the DOM
        consumed = False
        if self.focused_widget:
            consumed = self.focused_widget.handle_input(event)

        if not consumed and self.root:
            self.root.handle_input(event)

    def handle_mouse(self, event: MouseEvent) -> None:
        """
        Triggered on mouse interaction.

        Args:
            event: The mouse event to handle.
        """
        if hasattr(self, "dialog_manager") and getattr(self.dialog_manager, "has_dialogs", False):
            if self.dialog_manager.handle_mouse(event, self):
                return
        if self.root:
            self.root.handle_mouse(event, self)

    def handle_resize(self, event: ResizeEvent) -> None:
        """
        Triggered when the terminal window changes size.

        Args:
            event: The resize event with new dimensions.
        """
        pass

    def build_ui(self) -> Widget | None:
        """
        Override this to return the root widget tree.

        Returns:
            The root widget for the application UI.
        """
        return None

    def render(self) -> None:
        """
        The main rendering function.
        Rebuilds styling and layout, then renders the full Widget tree.
        """
        if not self.root:
            self.root = self.build_ui()

            # Restore focus after a UI rebuild if an element ID was previously focused
            if self.focused_id:

                def restore_focus(node: Widget) -> None:
                    if node.id == self.focused_id:
                        node.focused = True
                        self.focused_widget = node
                    for c in node.children:
                        restore_focus(c)

                self.focused_widget = None
                restore_focus(self.root)

        if self.root:
            # 1. Resolve CSS
            self.root.resolve_styles(self.stylesheet)
            # 2. Assign root X/Y
            self.root.x = 0
            self.root.y = 0
            # 3. Calculate Layout
            w, h = self._last_size
            self.root.calculate_layout(w, h)
            self._emit_runtime_style_warnings()
            # 4. Render Layout
            self.root.render(self)
        else:
            self.write(f"Casca UI - Press 'q' to exit.\\n Terminal size: {self._last_size}")


def run_app(widget: Widget, css: str = "", css_path: str = "") -> None:
    """
    A convenience wrapper to run a single widget without subclassing App.

    Args:
        widget: The root widget to render.
        css: Optional inline CSS string.
        css_path: Optional path to a CSS file.
    """

    class WrapperApp(App):
        def __init__(self) -> None:
            self.css_path = css_path
            self.css = css
            super().__init__()

        def build_ui(self) -> Widget:
            return widget

    WrapperApp().run()
