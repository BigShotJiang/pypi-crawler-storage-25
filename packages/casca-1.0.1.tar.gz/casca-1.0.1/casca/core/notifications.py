"""Notification primitives for transient toasts and banners."""

from __future__ import annotations

from dataclasses import dataclass
from time import monotonic


@dataclass
class Toast:
    """Toast notification data."""

    message: str
    level: str
    created_at: float
    duration: float


class ToastManager:
    """Manage transient toast notifications with auto-dismiss."""

    def __init__(self) -> None:
        """Initialize toast manager."""
        self._toasts: list[Toast] = []
        self._history: list[Toast] = []

    def push(
        self,
        message: str,
        level: str = "info",
        duration: float = 2.0,
        now: float | None = None,
    ) -> None:
        """
        Push a new toast notification.

        Args:
            message: Toast message text.
            level: Toast level (info, warn, error).
            duration: Duration in seconds before auto-dismiss.
            now: Optional timestamp override.
        """
        timestamp = monotonic() if now is None else now
        toast = Toast(
            message=message, level=level, created_at=timestamp, duration=max(0.1, duration)
        )
        self._toasts.append(toast)
        self._history.append(toast)
        self._history = self._history[-200:]

    def clear(self) -> None:
        """Clear all active toasts."""
        self._toasts.clear()

    def clear_history(self) -> None:
        """Clear toast history."""
        self._history.clear()

    def active(self, now: float | None = None) -> list[Toast]:
        """
        Get active (non-expired) toasts.

        Args:
            now: Optional timestamp override.

        Returns:
            List of active toast objects.
        """
        timestamp = monotonic() if now is None else now
        kept: list[Toast] = []
        for toast in self._toasts:
            if (timestamp - toast.created_at) < toast.duration:
                kept.append(toast)
        self._toasts = kept
        return list(self._toasts)

    def history(self, limit: int | None = None) -> list[Toast]:
        """
        Get toast history.

        Args:
            limit: Maximum number of entries to return.

        Returns:
            List of historical toast objects.
        """
        if limit is None or limit <= 0:
            return list(self._history)
        return list(self._history[-limit:])
