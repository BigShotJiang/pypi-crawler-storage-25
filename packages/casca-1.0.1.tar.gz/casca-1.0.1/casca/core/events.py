from dataclasses import dataclass


class Keys:
    """Canonical key constants used by Casca input parsing."""

    TAB = "\t"
    SHIFT_TAB = "\x1b[Z"
    ENTER = "\r"
    ESCAPE = "\x1b"

    LEFT = "\x1b[D"
    RIGHT = "\x1b[C"
    UP = "\x1b[A"
    DOWN = "\x1b[B"
    HOME = "\x1b[H"
    END = "\x1b[F"
    PAGE_UP = "\x1b[5~"
    PAGE_DOWN = "\x1b[6~"

    F1 = "\x1bOP"
    F2 = "\x1bOQ"
    F3 = "\x1bOR"
    F4 = "\x1bOS"
    F5 = "\x1b[15~"
    F6 = "\x1b[17~"
    F7 = "\x1b[18~"
    F8 = "\x1b[19~"
    F9 = "\x1b[20~"
    F10 = "\x1b[21~"
    F11 = "\x1b[23~"
    F12 = "\x1b[24~"


@dataclass
class KeyEvent:
    key: str
    is_printable: bool


@dataclass
class ResizeEvent:
    width: int
    height: int


@dataclass
class MouseEvent:
    x: int
    y: int
    button: int
    pressed: bool
