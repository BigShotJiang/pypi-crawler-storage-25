"""Theme token definitions and variable resolution helpers."""

from __future__ import annotations

import re

THEMES: dict[str, dict[str, str]] = {
    "default": {
        "primary": "bright_cyan",
        "accent": "bright_magenta",
        "text": "white",
        "muted": "bright_black",
        "surface": "black",
        "success": "bright_green",
        "warning": "bright_yellow",
        "danger": "bright_red",
    },
    "solarized": {
        "primary": "#2aa198",
        "accent": "#b58900",
        "text": "#eee8d5",
        "muted": "#93a1a1",
        "surface": "#002b36",
        "success": "#859900",
        "warning": "#cb4b16",
        "danger": "#dc322f",
    },
    "high-contrast": {
        "primary": "bright_white",
        "accent": "bright_yellow",
        "text": "bright_white",
        "muted": "white",
        "surface": "black",
        "success": "bright_green",
        "warning": "bright_yellow",
        "danger": "bright_red",
    },
}

_VAR_RE = re.compile(r"var\(\s*([\-\w]+)\s*(?:,\s*([^\)]+))?\)")


def resolve_theme_value(value: str, tokens: dict[str, str]) -> str:
    """Resolve CSS-like var(token, fallback) expressions against theme tokens."""
    text = str(value)

    def repl(match: re.Match[str]) -> str:
        token_name = match.group(1).strip()
        if token_name.startswith("--"):
            token_name = token_name[2:]

        if token_name in tokens:
            return tokens[token_name]

        fallback = match.group(2)
        if fallback is not None:
            return fallback.strip()

        return match.group(0)

    return _VAR_RE.sub(repl, text)


def apply_theme_tokens(stylesheet: dict, tokens: dict[str, str]) -> dict:
    """Return a stylesheet copy with all var(...) values resolved."""
    themed = {}
    for selector, rules in stylesheet.items():
        themed_rules = {}
        for key, value in rules.items():
            themed_rules[key] = resolve_theme_value(value, tokens)
        themed[selector] = themed_rules
    return themed
