"""
Casca Logging Configuration.

Provides a centralized logging setup for the Casca framework.
"""

import logging
import sys

# Default log format
DEFAULT_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

# Module logger
logger = logging.getLogger(__name__)

# Track if logging has been configured
_configured = False


def setup_logging(
    level: int = logging.WARNING,
    log_format: str | None = None,
    log_file: str | None = None,
) -> None:
    """
    Configure logging for the Casca framework.

    This should be called once at application startup if you want
    to enable logging output from Casca components.

    Args:
        level: Logging level (default: WARNING).
            Use logging.DEBUG for verbose output.
        log_format: Optional custom log format string.
        log_file: Optional file path to write logs to.
            If None, logs go to stderr.

    Example:
        ```python
        import logging
        from casca import setup_logging

        # Enable debug logging to stderr
        setup_logging(level=logging.DEBUG)

        # Or log to file
        setup_logging(level=logging.INFO, log_file="casca.log")
        ```
    """
    global _configured

    if _configured:
        logger.warning("Logging already configured")
        return

    # Create formatter
    fmt = log_format or DEFAULT_LOG_FORMAT
    formatter = logging.Formatter(fmt)

    # Create handler
    if log_file:
        handler = logging.FileHandler(log_file, encoding="utf-8")
    else:
        handler = logging.StreamHandler(sys.stderr)

    handler.setFormatter(formatter)

    # Configure casca logger
    casca_logger = logging.getLogger("casca")
    casca_logger.setLevel(level)
    casca_logger.addHandler(handler)

    _configured = True
    logger.info("Casca logging configured (level=%s)", logging.getLevelName(level))


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a Casca module.

    Args:
        name: Module name (e.g., "casca.app", "casca.widgets.button").

    Returns:
        Configured logger instance.
    """
    return logging.getLogger(f"casca.{name}")


def enable_debug_logging() -> None:
    """Enable debug-level logging to stderr."""
    setup_logging(level=logging.DEBUG)


def is_configured() -> bool:
    """Check if logging has been configured."""
    return _configured
