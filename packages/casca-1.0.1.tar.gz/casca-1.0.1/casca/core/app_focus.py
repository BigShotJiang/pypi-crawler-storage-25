"""Focus traversal mixin for the App class."""

from __future__ import annotations


class AppFocusMixin:
    """Focus-related helpers extracted from App to keep the core loop compact."""

    def _focus_scope_root(self):
        """Return root node used for focus traversal."""
        if hasattr(self, "dialog_manager") and getattr(self.dialog_manager, "has_dialogs", False):
            current = getattr(self.dialog_manager, "current_dialog", None)
            if current is not None:
                return current
        return self.root

    def _collect_focusable_widgets(self, root_node):
        """Collect focusable widgets in traversal order."""
        focusable = []
        if not root_node:
            return focusable

        stack = [root_node]
        while stack:
            node = stack.pop()
            disabled = getattr(node, "disabled", False) or getattr(node, "_disabled", False)
            if not disabled and getattr(node, "tag", None) in (
                "input",
                "textarea",
                "button",
                "checkbox",
                "select",
                "listview",
                "radiogroup",
                "datagrid",
                "treeview",
                "table",
                "command-palette",
            ):
                focusable.append(node)
            children = list(getattr(node, "children", []))
            stack.extend(reversed(children))
        return focusable

    def _set_focus(self, target):
        """Set focus to target widget, clearing previous focus."""
        if self.focused_widget and self.focused_widget is not target:
            self.focused_widget.focused = False
        self.focused_widget = target
        if target is not None:
            target.focused = True
            if getattr(target, "id", ""):
                self.focused_id = target.id

    def focus_next(self, reverse: bool = False) -> bool:
        """Move focus to next/previous focusable widget."""
        widgets = self._collect_focusable_widgets(self._focus_scope_root())
        if not widgets:
            self._set_focus(None)
            return False

        if self.focused_widget not in widgets:
            target = widgets[-1] if reverse else widgets[0]
            self._set_focus(target)
            return True

        current_index = widgets.index(self.focused_widget)
        step = -1 if reverse else 1
        next_index = (current_index + step) % len(widgets)
        self._set_focus(widgets[next_index])
        return True
