"""Screenshot export helpers for Casca apps.

This module keeps ANSI frame parsing and SVG export logic out of App to
reduce core event-loop complexity.
"""

from __future__ import annotations

import html
import os
import re
from datetime import datetime

ANSI_ESCAPE_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

ANSI_16 = {
    0: (0, 0, 0),
    1: (170, 0, 0),
    2: (0, 170, 0),
    3: (170, 85, 0),
    4: (0, 0, 170),
    5: (170, 0, 170),
    6: (0, 170, 170),
    7: (170, 170, 170),
    8: (85, 85, 85),
    9: (255, 85, 85),
    10: (85, 255, 85),
    11: (255, 255, 85),
    12: (85, 85, 255),
    13: (255, 85, 255),
    14: (85, 255, 255),
    15: (255, 255, 255),
}


def _ansi_256_to_rgb(index: int) -> tuple[int, int, int]:
    """Convert an ANSI 256-color palette index into an RGB tuple."""
    idx = max(0, min(255, int(index)))

    if idx < 16:
        return ANSI_16[idx]

    if idx <= 231:
        cube = idx - 16
        r = cube // 36
        g = (cube % 36) // 6
        b = cube % 6
        levels = [0, 95, 135, 175, 215, 255]
        return (levels[r], levels[g], levels[b])

    gray = 8 + (idx - 232) * 10
    return (gray, gray, gray)


def parse_ansi_frame_to_cells(frame: str, size: tuple[int, int]):
    """Parse a rendered ANSI frame into a terminal-sized cell buffer."""
    cols, rows = size
    default_fg = ANSI_16[15]
    default_bg = (10, 10, 10)

    cells = [
        [{"ch": " ", "fg": default_fg, "bg": default_bg} for _ in range(cols)] for _ in range(rows)
    ]

    x = 1
    y = 1
    fg = default_fg
    bg = default_bg

    i = 0
    n = len(frame)
    while i < n:
        ch = frame[i]
        if ch == "\x1b" and i + 1 < n and frame[i + 1] == "[":
            j = i + 2
            while (
                j < n
                and frame[j]
                not in "@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
            ):
                j += 1
            if j >= n:
                break
            params = frame[i + 2 : j]
            final = frame[j]

            if final in ("H", "f"):
                parts = params.split(";") if params else []
                try:
                    y = max(1, int(parts[0])) if len(parts) >= 1 and parts[0] else 1
                except ValueError:
                    y = 1
                try:
                    x = max(1, int(parts[1])) if len(parts) >= 2 and parts[1] else 1
                except ValueError:
                    x = 1
            elif final == "m":
                codes = []
                if params.strip() == "":
                    codes = [0]
                else:
                    for p in params.split(";"):
                        try:
                            codes.append(int(p))
                        except ValueError:
                            codes.append(0)

                k = 0
                while k < len(codes):
                    c = codes[k]
                    if c == 0:
                        fg = default_fg
                        bg = default_bg
                    elif 30 <= c <= 37:
                        fg = ANSI_16[c - 30]
                    elif 90 <= c <= 97:
                        fg = ANSI_16[8 + (c - 90)]
                    elif 40 <= c <= 47:
                        bg = ANSI_16[c - 40]
                    elif 100 <= c <= 107:
                        bg = ANSI_16[8 + (c - 100)]
                    elif c == 39:
                        fg = default_fg
                    elif c == 49:
                        bg = default_bg
                    elif c in (38, 48):
                        target_is_fg = c == 38
                        mode = codes[k + 1] if (k + 1) < len(codes) else None

                        if mode == 2 and (k + 4) < len(codes):
                            rgb = (
                                max(0, min(255, codes[k + 2])),
                                max(0, min(255, codes[k + 3])),
                                max(0, min(255, codes[k + 4])),
                            )
                            if target_is_fg:
                                fg = rgb
                            else:
                                bg = rgb
                            k += 4
                        elif mode == 5 and (k + 2) < len(codes):
                            rgb = _ansi_256_to_rgb(codes[k + 2])
                            if target_is_fg:
                                fg = rgb
                            else:
                                bg = rgb
                            k += 2
                    k += 1

            i = j + 1
            continue

        if ch == "\n":
            y += 1
            x = 1
            i += 1
            continue

        if ch == "\r":
            x = 1
            i += 1
            continue

        if 1 <= x <= cols and 1 <= y <= rows and ch >= " ":
            cells[y - 1][x - 1] = {"ch": ch, "fg": fg, "bg": bg}
            x += 1
        elif ch >= " ":
            x += 1
        i += 1

    return rows, cols, cells


def _rgb(rgb: tuple[int, int, int]) -> str:
    return f"rgb({rgb[0]},{rgb[1]},{rgb[2]})"


def cells_to_svg(rows: int, cols: int, cells, settings: dict[str, object]) -> tuple[str, int, int]:
    """Render terminal cells as an SVG image."""

    def _positive_number(value, default):
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            return float(default)
        return parsed if parsed > 0 else float(default)

    cell_w = _positive_number(settings.get("screenshot_cell_w", 9), 9)
    cell_h = _positive_number(settings.get("screenshot_cell_h", 18), 18)
    font_size = _positive_number(settings.get("screenshot_font_size", 14), 14)
    baseline = _positive_number(settings.get("screenshot_baseline", font_size), font_size)
    font_family = settings.get(
        "screenshot_font_family",
        "'DejaVu Sans Mono','Noto Sans Mono','Liberation Mono',monospace",
    )
    shape_rendering = settings.get("screenshot_shape_rendering", "geometricPrecision")
    text_rendering = settings.get("screenshot_text_rendering", "optimizeLegibility")
    length_adjust = settings.get("screenshot_length_adjust", "spacingAndGlyphs")
    force_text_length = bool(settings.get("screenshot_force_text_length", False))
    width = max(1, int(round(cols * cell_w)))
    height = max(1, int(round(rows * cell_h)))

    def _span(start_units: float, end_units: float, limit: int) -> tuple[int, int]:
        start_px = int(round(start_units))
        end_px = int(round(end_units))
        start_px = max(0, min(limit, start_px))
        end_px = max(start_px, min(limit, end_px))
        if end_px == start_px and start_px < limit:
            end_px = min(limit, start_px + 1)
        return start_px, end_px

    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" shape-rendering="{shape_rendering}" text-rendering="{text_rendering}">',
        '<rect x="0" y="0" width="100%" height="100%" fill="rgb(10,10,10)"/>',
    ]

    for y in range(rows):
        row_top, row_bottom = _span(y * cell_h, (y + 1) * cell_h, height)
        row_h = max(1, row_bottom - row_top)
        x = 0
        while x < cols:
            bg = cells[y][x]["bg"]
            start = x
            x += 1
            while x < cols and cells[y][x]["bg"] == bg:
                x += 1
            run_left, run_right = _span(start * cell_w, x * cell_w, width)
            run_w = max(1, run_right - run_left)
            out.append(
                f'<rect x="{run_left}" y="{row_top}" width="{run_w}" height="{row_h}" fill="{_rgb(bg)}"/>'
            )

    for y in range(rows):
        x = 0
        while x < cols:
            if cells[y][x]["ch"] == " ":
                x += 1
                continue
            fg = cells[y][x]["fg"]
            start = x
            chars = []
            while x < cols and cells[y][x]["ch"] != " " and cells[y][x]["fg"] == fg:
                chars.append(cells[y][x]["ch"])
                x += 1
            text = html.escape("".join(chars))
            run_left, run_right = _span(start * cell_w, x * cell_w, width)
            tx = run_left
            ty = int(round(y * cell_h + baseline))
            run_w = max(1, run_right - run_left)
            if force_text_length:
                out.append(
                    f'<text x="{tx}" y="{ty}" fill="{_rgb(fg)}" font-family="{font_family}" '
                    f'font-size="{font_size}" xml:space="preserve" font-variant-ligatures="none" '
                    f'textLength="{run_w}" lengthAdjust="{length_adjust}">{text}</text>'
                )
            else:
                out.append(
                    f'<text x="{tx}" y="{ty}" fill="{_rgb(fg)}" font-family="{font_family}" '
                    f'font-size="{font_size}" xml:space="preserve" font-variant-ligatures="none">{text}</text>'
                )

    out.append("</svg>")
    return "\n".join(out), width, height


def capture_frame_screenshot(
    frame: str,
    size: tuple[int, int],
    out_dir: str,
    settings: dict[str, object],
) -> str | None:
    """Write ANSI/TXT/SVG files for a rendered frame and return SVG path."""
    if not frame:
        return None

    os.makedirs(out_dir, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    base = os.path.join(out_dir, f"casca-shot-{stamp}")
    ansi_path = f"{base}.ansi"
    txt_path = f"{base}.txt"
    svg_path = f"{base}.svg"

    with open(ansi_path, "w", encoding="utf-8") as f:
        f.write(frame)

    stripped = ANSI_ESCAPE_RE.sub("", frame)
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(stripped)

    rows, cols, cells = parse_ansi_frame_to_cells(frame, size)
    svg, _svg_w, _svg_h = cells_to_svg(rows, cols, cells, settings)
    with open(svg_path, "w", encoding="utf-8") as f:
        f.write(svg)

    return svg_path
