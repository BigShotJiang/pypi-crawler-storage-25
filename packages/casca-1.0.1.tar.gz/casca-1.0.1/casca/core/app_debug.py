"""Debug, studio, and overlay mixin for the App class."""

from __future__ import annotations

import sys

from ..style.css import get_border_width, get_box_spacing


class AppDebugStudioMixin:
    """Runtime debug overlays and studio inspection helpers."""

    def _render_banner(self):
        """Render a sticky, non-blocking status banner near the bottom line."""
        if not self.banner_message:
            return
        w, h = self._last_size
        text = f"[{self.banner_level.upper()}] {self.banner_message}"[: max(1, w - 1)]
        self.draw_text(1, max(1, h), text, apply_clip=False)

    def _render_toasts(self):
        """Render transient toasts stacked from bottom-right."""
        active_toasts = self.toast_manager.active()
        if not active_toasts:
            return

        w, h = self._last_size
        max_stack = min(3, max(1, h - 2))
        visible = active_toasts[-max_stack:]
        for idx, toast in enumerate(reversed(visible), start=1):
            text = f"[{toast.level.upper()}] {toast.message}"
            clipped = text[: max(1, w - 2)]
            x = max(1, w - len(clipped))
            y = max(1, h - idx)
            self.draw_text(x, y, clipped, apply_clip=False)

    def _render_error_overlay(self):
        """Draw a compact debug overlay when an error is captured."""
        if not self.debug or not self._last_error_lines:
            return

        w, h = self._last_size
        max_lines = max(3, min(8, h - 2))
        lines = self._last_error_lines[:max_lines]

        box_width = max(20, min(w - 2, max(len(line) for line in lines) + 4))
        x = 2
        y = 2

        border = "+" + ("-" * (box_width - 2)) + "+"
        self.draw_text(x, y, border, apply_clip=False)
        for idx, line in enumerate(lines, start=1):
            clipped = line[: box_width - 4]
            padded = clipped + (" " * (box_width - 4 - len(clipped)))
            self.draw_text(x, y + idx, f"|{padded}|", apply_clip=False)
        self.draw_text(x, y + len(lines) + 1, border, apply_clip=False)

    def _iter_nodes_with_parent(self):
        if not self.root:
            return []

        out = []
        stack = [(self.root, None)]
        while stack:
            node, parent = stack.pop()
            out.append((node, parent))
            children = list(getattr(node, "children", []))
            for child in reversed(children):
                stack.append((child, node))
        return out

    def _render_layout_overlay(self):
        if not self.debug_layout or not self.root:
            return

        term_w, term_h = self._last_size
        for node, parent in self._iter_nodes_with_parent():
            w = int(getattr(node, "width", 0) or 0)
            h = int(getattr(node, "height", 0) or 0)
            if w <= 0 or h <= 0:
                continue

            x = int(getattr(node, "x", 0)) + 1
            y = int(getattr(node, "y", 0)) + 1

            if 1 <= y <= term_h:
                top = "+" + ("-" * max(0, w - 2)) + ("+" if w > 1 else "")
                self.draw_text(max(1, x), y, top[: max(1, term_w - x + 1)], apply_clip=False)
            if h > 1 and 1 <= (y + h - 1) <= term_h:
                bottom = "+" + ("-" * max(0, w - 2)) + ("+" if w > 1 else "")
                self.draw_text(
                    max(1, x), y + h - 1, bottom[: max(1, term_w - x + 1)], apply_clip=False
                )

            for row in range(1, h - 1):
                yy = y + row
                if yy < 1 or yy > term_h:
                    continue
                if 1 <= x <= term_w:
                    self.draw_text(x, yy, "|", apply_clip=False)
                if w > 1 and 1 <= (x + w - 1) <= term_w:
                    self.draw_text(x + w - 1, yy, "|", apply_clip=False)

            label = f"{getattr(node, 'tag', '?')} {w}x{h}"
            if 1 <= y <= term_h:
                self.draw_text(max(1, x + 1), y, label[: max(1, term_w - x)], apply_clip=False)

            if parent is not None:
                px = int(getattr(parent, "x", 0))
                py = int(getattr(parent, "y", 0))
                pw = int(getattr(parent, "width", 0) or 0)
                ph = int(getattr(parent, "height", 0) or 0)
                if x - 1 < px or y - 1 < py or (x - 1 + w) > (px + pw) or (y - 1 + h) > (py + ph):
                    self.draw_text(
                        max(1, min(term_w, x)), max(1, min(term_h, y)), "!", apply_clip=False
                    )

    def _emit_runtime_style_warnings(self):
        if not self.debug or not self.root:
            return

        for node, _parent in self._iter_nodes_with_parent():
            getter = getattr(node, "get_layout_warnings", None)
            if not callable(getter):
                continue
            for warning in getter():
                node_ref = f"{getattr(node, 'tag', '?')}#{getattr(node, 'id', '')}".rstrip("#")
                key = f"{node_ref}:{warning}"
                if key in self._emitted_debug_warnings:
                    continue
                self._emitted_debug_warnings.add(key)
                sys.stderr.write(f"[Casca][style-warning] {node_ref}: {warning}\n")

    def _find_path_to_node(self, target):
        if not self.root or target is None:
            return []

        stack = [(self.root, [self.root])]
        while stack:
            node, path = stack.pop()
            if node is target:
                return path
            for child in reversed(list(getattr(node, "children", []))):
                stack.append((child, path + [child]))
        return []

    def _node_ref(self, node):
        if node is None:
            return "none"
        tag = getattr(node, "tag", "?")
        node_id = getattr(node, "id", "")
        classes = getattr(node, "classes", "")
        parts = [tag]
        if node_id:
            parts.append(f"#{node_id}")
        if classes:
            if isinstance(classes, (list, tuple, set)):
                cls = ".".join(str(c) for c in classes if str(c).strip())
            else:
                cls = ".".join([c for c in str(classes).split() if c])
            if cls:
                parts.append(f".{cls}")
        return "".join(parts)

    def get_studio_snapshot(self):
        """Return focused widget inspection data used by Studio tools/panels."""
        node = self.focused_widget
        path_nodes = self._find_path_to_node(node)
        path = [self._node_ref(n) for n in path_nodes]

        snapshot = {
            "focus_path": path,
            "focused": None,
        }
        if node is None:
            return snapshot

        node_style = getattr(node, "style", {}) or {}
        mt, mr, mb, ml = get_box_spacing(node_style, "margin")
        pt, pr, pb, pl = get_box_spacing(node_style, "padding")
        bw = get_border_width(node_style)
        snapshot["focused"] = {
            "ref": self._node_ref(node),
            "tag": getattr(node, "tag", "?"),
            "id": getattr(node, "id", ""),
            "classes": list(getattr(node, "classes", []) or []),
            "box": {
                "x": int(getattr(node, "x", 0) or 0),
                "y": int(getattr(node, "y", 0) or 0),
                "width": int(getattr(node, "width", 0) or 0),
                "height": int(getattr(node, "height", 0) or 0),
            },
            "margin": {"top": mt, "right": mr, "bottom": mb, "left": ml},
            "padding": {"top": pt, "right": pr, "bottom": pb, "left": pl},
            "border": {"width": bw},
            "computed_style": dict(sorted(node_style.items(), key=lambda kv: kv[0])),
        }
        return snapshot

    def _render_studio_overlay(self):
        if not self._studio_visible:
            return

        term_w, term_h = self._last_size
        if term_w < 40 or term_h < 8:
            return

        snapshot = self.get_studio_snapshot()
        node = self.focused_widget
        path = snapshot.get("focus_path") or []
        path_text = " > ".join(path) if path else "none"

        lines = [
            "Casca Studio (F2)",
            f"Focus path: {path_text}",
        ]

        if node is not None:
            focused = snapshot["focused"]
            box = focused["box"]
            lines.append(f"Widget: {focused['ref']}")
            x = box["x"]
            y = box["y"]
            w = box["width"]
            h = box["height"]
            lines.append(f"Box: x={x} y={y} w={w} h={h}")

            margin = focused["margin"]
            padding = focused["padding"]
            bw = focused["border"]["width"]
            mt, mr, mb, ml = margin["top"], margin["right"], margin["bottom"], margin["left"]
            pt, pr, pb, pl = padding["top"], padding["right"], padding["bottom"], padding["left"]
            lines.append(f"Margin: t{mt} r{mr} b{mb} l{ml}")
            lines.append(f"Padding: t{pt} r{pr} b{pb} l{pl}")
            lines.append(f"Border: {bw}")

            style = focused["computed_style"]
            lines.append("Style:")
            for key, value in list(style.items())[:8]:
                lines.append(f"  {key}: {value}")

        box_h = min(term_h - 1, max(8, min(16, len(lines) + 2)))
        box_w = min(term_w - 1, max(42, term_w // 2))
        x0 = max(1, term_w - box_w + 1)
        y0 = 1

        border = "+" + ("-" * max(0, box_w - 2)) + ("+" if box_w > 1 else "")
        self.draw_text(x0, y0, border[:box_w], apply_clip=False)

        content_rows = box_h - 2
        for idx in range(content_rows):
            raw = lines[idx] if idx < len(lines) else ""
            content = raw[: max(0, box_w - 4)]
            content = content + (" " * max(0, box_w - 4 - len(content)))
            self.draw_text(x0, y0 + idx + 1, f"| {content} |"[:box_w], apply_clip=False)

        self.draw_text(x0, y0 + box_h - 1, border[:box_w], apply_clip=False)
