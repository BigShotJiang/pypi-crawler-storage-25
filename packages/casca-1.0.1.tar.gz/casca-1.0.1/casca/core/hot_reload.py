"""
CSS Hot Reload Module.

Provides file watching and automatic UI refresh for CSS changes.
Watchdog is optional - falls back to polling if not installed.

Usage:
    ```python
    from casca.core.hot_reload import enable_hot_reload

    reloader = enable_hot_reload(app, ["styles/"])
    ```
"""

import os
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

# Try to import watchdog, fall back to polling if not available
try:
    from watchdog.events import FileModifiedEvent, FileSystemEventHandler
    from watchdog.observers import Observer

    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    Observer = None  # type: ignore
    FileSystemEventHandler = object  # type: ignore
    FileModifiedEvent = None  # type: ignore


class PollingCSSWatcher:
    """Simple polling-based CSS file watcher (watchdog fallback)."""

    def __init__(self, callback: Callable[[str], None]):
        self.callback = callback
        self._watched_paths: set[str] = set()
        self._last_modified: dict[str, float] = {}
        self._lock = threading.Lock()
        self._running = False
        self._poll_interval = 0.5

    def watch(self, path: str) -> None:
        """Add a path to watch."""
        abs_path = str(Path(path).resolve())
        with self._lock:
            self._watched_paths.add(abs_path)
            if os.path.isfile(abs_path):
                self._last_modified[abs_path] = os.path.getmtime(abs_path)
            elif os.path.isdir(abs_path):
                for css_file in Path(abs_path).rglob("*.css"):
                    self._last_modified[str(css_file)] = css_file.stat().st_mtime

    def _check_for_changes(self) -> list[str]:
        """Check for modified CSS files."""
        changed = []
        with self._lock:
            for path in self._watched_paths:
                if os.path.isfile(path):
                    mtime = os.path.getmtime(path)
                    if mtime > self._last_modified.get(path, 0):
                        changed.append(path)
                        self._last_modified[path] = mtime
                elif os.path.isdir(path):
                    for css_file in Path(path).rglob("*.css"):
                        mtime = css_file.stat().st_mtime
                        if mtime > self._last_modified.get(str(css_file), 0):
                            changed.append(str(css_file))
                            self._last_modified[str(css_file)] = mtime
        return changed

    def start(self) -> None:
        """Start polling."""
        self._running = True

        def poll():
            while self._running:
                changed = self._check_for_changes()
                for path in changed:
                    self.callback(path)
                time.sleep(self._poll_interval)

        thread = threading.Thread(target=poll, daemon=True)
        thread.start()

    def stop(self) -> None:
        """Stop polling."""
        self._running = False


class CSSFileHandler:
    """Handler for CSS file modification events (watchdog)."""

    def __init__(self, callback: Callable[[str], None]):
        self.callback = callback
        self._debounce: dict[str, float] = {}
        self._lock = threading.Lock()

    def on_modified(self, event: Any) -> None:
        """Handle file modification event."""
        if event and hasattr(event, "src_path") and event.src_path.endswith(".css"):
            with self._lock:
                self._debounce[event.src_path] = time.time()

    def get_changed_files(self, debounce_seconds: float = 0.1) -> list[str]:
        """Get files that have changed after debounce period."""
        changed = []
        now = time.time()
        with self._lock:
            for path, mod_time in list(self._debounce.items()):
                if now - mod_time >= debounce_seconds:
                    changed.append(path)
                    del self._debounce[path]
        return changed


class CSSHotReloader:
    """
    Hot reloader for CSS files.

    Watches CSS files for changes and triggers UI refresh.
    Uses watchdog if available, falls back to polling otherwise.

    Attributes:
        app: Casca App instance.
        debounce: Debounce time in seconds.

    Usage:
        ```python
        reloader = CSSHotReloader(app)
        reloader.watch("styles/")
        reloader.watch("theme.css")
        reloader.start()
        ```
    """

    def __init__(self, app: Any, debounce: float = 0.1):
        """
        Initialize the CSS hot reloader.

        Args:
            app: Casca App instance.
            debounce: Debounce time in seconds.
        """
        self.app = app
        self.debounce = debounce
        self._observer: Any | None = None
        self._watched_paths: set[str] = set()
        self._running = False
        self._change_callback: Callable[[list[str]], None] | None = None
        self._use_watchdog = WATCHDOG_AVAILABLE

        if self._use_watchdog:
            self._handler = CSSFileHandler(self._on_css_change)
        else:
            self._watcher = PollingCSSWatcher(self._on_css_change)

    def watch(self, path: str) -> None:
        """
        Add a path to watch for CSS changes.

        Args:
            path: File or directory path to watch.
        """
        abs_path = str(Path(path).resolve())
        self._watched_paths.add(abs_path)

        if self._running:
            self._add_watch(abs_path)

    def _add_watch(self, path: str) -> None:
        """Add watch for a path."""
        if self._use_watchdog and self._observer:
            if os.path.isfile(path):
                self._observer.schedule(self._handler, os.path.dirname(path))
            else:
                self._observer.schedule(self._handler, path, recursive=True)
        elif hasattr(self, "_watcher"):
            self._watcher.watch(path)

    def start(self) -> None:
        """Start watching for CSS changes."""
        if self._running:
            return

        if self._use_watchdog:
            self._observer = Observer()  # type: ignore
            for path in self._watched_paths:
                self._add_watch(path)

            self._observer.start()  # type: ignore
            self._running = True

            # Start change detection thread
            self._detect_thread = threading.Thread(target=self._detect_changes, daemon=True)
            self._detect_thread.start()
        else:
            self._watcher.start()
            self._running = True

    def stop(self) -> None:
        """Stop watching for CSS changes."""
        if not self._running:
            return

        self._running = False
        if self._use_watchdog and self._observer:
            self._observer.stop()  # type: ignore
            self._observer.join()  # type: ignore

    def set_change_callback(self, callback: Callable[[list[str]], None]) -> None:
        """Set callback for CSS changes."""
        self._change_callback = callback

    def _on_css_change(self, path: str) -> None:
        """Handle CSS change notification."""
        logger = None
        try:
            from .logging_config import get_logger

            logger = get_logger("hot_reload")
        except ImportError:
            pass

        if logger:
            logger.debug("CSS file changed: %s", path)

        if self._change_callback:
            self._change_callback([path])
        else:
            # Default: reload app stylesheet
            if hasattr(self.app, "reload_stylesheet"):
                self.app.reload_stylesheet()
            if hasattr(self.app, "invalidate"):
                self.app.invalidate()

    def _detect_changes(self) -> None:
        """Detect and handle CSS changes (watchdog debounce)."""
        while self._running:
            if hasattr(self._handler, "get_changed_files"):
                changed = self._handler.get_changed_files(self.debounce)
                for path in changed:
                    self._on_css_change(path)
            time.sleep(0.05)


def enable_hot_reload(app: Any, paths: list[str], debounce: float = 0.1) -> CSSHotReloader:
    """
    Enable CSS hot reload for an app.

    Args:
        app: Casca App instance.
        paths: List of CSS files/directories to watch.
        debounce: Debounce time in seconds.

    Returns:
        CSSHotReloader instance.

    Example:
        ```python
        from casca import App, enable_hot_reload

        app = MyApp()
        reloader = enable_hot_reload(app, ["styles/"])
        app.run()
        ```
    """
    reloader = CSSHotReloader(app, debounce)
    for path in paths:
        reloader.watch(path)
    reloader.start()
    return reloader
