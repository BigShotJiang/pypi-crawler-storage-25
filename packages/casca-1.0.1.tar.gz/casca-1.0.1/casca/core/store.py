"""
Casca State Management Module.

Provides a lightweight Redux-style store for unidirectional state management.
"""

from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from typing import Any

# Type aliases
Reducer = Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]]
Subscriber = Callable[[dict[str, Any]], None]
Middleware = Callable[
    ["Store", dict[str, Any], Callable[[dict[str, Any]], dict[str, Any]]], dict[str, Any]
]


class Store:
    """
    A lightweight Redux-style store with reducer, subscribe, and dispatch.

    Attributes:
        state: Current state dictionary (read-only, use dispatch to modify).

    Example:
        ```python
        def reducer(state, action):
            if action["type"] == "inc":
                return {**state, "count": state.get("count", 0) + 1}
            return state

        store = Store(reducer, {"count": 0})
        store.dispatch({"type": "inc"})
        print(store.get_state())  # {"count": 1}
        ```
    """

    def __init__(
        self,
        reducer: Reducer,
        initial_state: dict[str, Any] | None = None,
        middlewares: list[Middleware] | None = None,
    ) -> None:
        """
        Initialize the store.

        Args:
            reducer: Function that takes (state, action) and returns new state.
            initial_state: Initial state dictionary.
            middlewares: Optional list of middleware functions.

        Raises:
            TypeError: If reducer is not callable.
        """
        if not callable(reducer):
            raise TypeError("reducer must be callable")

        self._reducer = reducer
        self._state: dict[str, Any] = dict(initial_state or {})
        self._subscribers: list[Subscriber] = []
        self._middlewares: list[Middleware] = list(middlewares or [])

    def get_state(self) -> dict[str, Any]:
        """
        Get a deep copy of the current state.

        Returns:
            Deep copy of current state dictionary.
        """
        return deepcopy(self._state)

    def subscribe(self, callback: Subscriber) -> Callable[[], None]:
        """
        Subscribe to state changes.

        Args:
            callback: Function to call when state changes. Receives new state.

        Returns:
            Unsubscribe function.

        Raises:
            TypeError: If callback is not callable.
        """
        if not callable(callback):
            raise TypeError("subscriber must be callable")
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return unsubscribe

    def dispatch(self, action: dict[str, Any]) -> dict[str, Any]:
        """
        Dispatch an action to update state.

        Args:
            action: Action dictionary with at least a 'type' key.

        Returns:
            New state after applying action.

        Raises:
            TypeError: If action is not a dict.
            ValueError: If action missing 'type' key.
        """
        if not isinstance(action, dict):
            raise TypeError("action must be a dict")
        if "type" not in action:
            raise ValueError("action must include a 'type' key")

        def _reduce(current_action: dict[str, Any]) -> dict[str, Any]:
            next_state = self._reducer(self._state, current_action)
            if not isinstance(next_state, dict):
                raise TypeError("reducer must return a dict state")
            self._state = next_state
            snapshot = self.get_state()
            for callback in list(self._subscribers):
                callback(snapshot)
            return snapshot

        pipeline: Callable[[dict[str, Any]], dict[str, Any]] = _reduce
        for middleware in reversed(self._middlewares):
            next_pipeline = pipeline

            def _wrap(
                mw: Middleware, nxt: Callable[[dict[str, Any]], dict[str, Any]]
            ) -> Callable[[dict[str, Any]], dict[str, Any]]:
                return lambda mw_action: mw(self, mw_action, nxt)

            pipeline = _wrap(middleware, next_pipeline)

        return pipeline(action)


def create_store(
    reducer: Reducer,
    initial_state: dict[str, Any] | None = None,
    middlewares: list[Middleware] | None = None,
) -> Store:
    """
    Create a new store instance.

    Args:
        reducer: Function that takes (state, action) and returns new state.
        initial_state: Initial state dictionary.
        middlewares: Optional list of middleware functions.

    Returns:
        New Store instance.
    """
    return Store(reducer, initial_state=initial_state, middlewares=middlewares)


def combine_reducers(reducers: dict[str, Reducer]) -> Reducer:
    """
    Combine per-key reducers into a single reducer function.

    Args:
        reducers: Dictionary mapping state keys to reducer functions.

    Returns:
        Combined reducer function.

    Example:
        ```python
        root_reducer = combine_reducers({
            "counter": counter_reducer,
            "user": user_reducer,
        })
        ```
    """

    def _combined(state: dict[str, Any] | None, action: dict[str, Any]) -> dict[str, Any]:
        current = dict(state or {})
        out = dict(current)
        for key, reducer in reducers.items():
            prev = current.get(key)
            next_value = reducer(prev, action)
            out[key] = next_value
        return out

    return _combined
