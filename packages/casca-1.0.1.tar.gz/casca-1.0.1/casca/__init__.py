"""
Casca - A Python TUI Framework

A terminal user interface framework built with Python.
"""

# Import all components from organized submodules
from .components import (
    Alert,
    Button,
    Card,
    Checkbox,
    CommandPalette,
    Confirm,
    Container,
    DataGrid,
    Dialog,
    DialogManager,
    Header,
    Image,
    Input,
    Label,
    ListView,
    Modal,
    NotificationCenter,
    Overlay,
    ProgressBar,
    Prompt,
    RadioGroup,
    ScrollView,
    Select,
    Spinner,
    StudioPanel,
    TabItem,
    Table,
    Tabs,
    TextArea,
    TreeView,
    WidgetBase,
    show_alert,
    show_confirm,
    show_prompt,
)
from .core.ansi import CLEAR_SCREEN, RESET, BackColor, Color, color, move_cursor
from .core.app import App, run_app
from .core.events import KeyEvent, Keys, MouseEvent, ResizeEvent
from .core.logging_config import enable_debug_logging, get_logger, setup_logging
from .core.notifications import Toast, ToastManager
from .core.store import Store, combine_reducers, create_store
from .core.terminal import RawTerminal, get_terminal_size
from .core.themes import THEMES
from .dom.node import Widget
from .plugins import (
    create_widget,
    discover_plugins,
    get_widget,
    is_compatible_api_version,
    list_widgets,
    register_widget,
    validate_plugin_api_version,
)
from .style.css import load_css_file, parse_css

__all__ = [
    # Core
    "App",
    "KeyEvent",
    "ResizeEvent",
    "MouseEvent",
    "Keys",
    "RawTerminal",
    "get_terminal_size",
    "color",
    "Color",
    "BackColor",
    "move_cursor",
    "CLEAR_SCREEN",
    "RESET",
    "Toast",
    "ToastManager",
    "Store",
    "create_store",
    "combine_reducers",
    "setup_logging",
    "get_logger",
    "enable_debug_logging",
    # DOM
    "Widget",
    # Widgets
    "WidgetBase",
    "Container",
    "Label",
    "Button",
    "ListView",
    "ProgressBar",
    "Spinner",
    "DataGrid",
    "TreeView",
    "Table",
    "CommandPalette",
    "Image",
    # Forms
    "Checkbox",
    "Input",
    "Select",
    "TextArea",
    "RadioGroup",
    # Panels
    "Card",
    "Header",
    "NotificationCenter",
    "StudioPanel",
    # Navigation
    "ScrollView",
    "Tabs",
    "TabItem",
    # Dialogs
    "Overlay",
    "Modal",
    "Dialog",
    "Alert",
    "Confirm",
    "Prompt",
    "DialogManager",
    "show_alert",
    "show_confirm",
    "show_prompt",
    # CSS
    "parse_css",
    "load_css_file",
    "THEMES",
    "register_widget",
    "get_widget",
    "create_widget",
    "list_widgets",
    "discover_plugins",
    "is_compatible_api_version",
    "validate_plugin_api_version",
    # App runner
    "run_app",
]
