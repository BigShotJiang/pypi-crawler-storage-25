"""Stable plugin and community widget extension API for Casca."""

from .registry import (
    PluginRegistry,
    WidgetRegistration,
    casca_plugins,
    create_widget,
    discover_plugins,
    get_widget,
    is_compatible_api_version,
    list_widgets,
    register_widget,
    validate_plugin_api_version,
)

__all__ = [
    "PluginRegistry",
    "WidgetRegistration",
    "casca_plugins",
    "register_widget",
    "get_widget",
    "create_widget",
    "list_widgets",
    "discover_plugins",
    "is_compatible_api_version",
    "validate_plugin_api_version",
]
