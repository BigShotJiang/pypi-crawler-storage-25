"""Plugin registry used by Casca Studio and community widget packages."""

from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import entry_points
from typing import Any


def _major(version: str) -> int:
    """Extract major version number."""
    return int(str(version).strip().split(".")[0])


def is_compatible_api_version(plugin_api_version: str, registry_api_version: str) -> bool:
    """
    Check if plugin API version is compatible with registry.

    Compatibility rule: plugin major must match registry major.

    Args:
        plugin_api_version: Plugin's API version string.
        registry_api_version: Registry's API version string.

    Returns:
        True if compatible, False otherwise.
    """
    try:
        return _major(plugin_api_version) == _major(registry_api_version)
    except Exception:
        return False


def validate_plugin_api_version(plugin_api_version: str, registry_api_version: str) -> None:
    """
    Validate plugin API version compatibility.

    Args:
        plugin_api_version: Plugin's API version string.
        registry_api_version: Registry's API version string.

    Raises:
        ValueError: If versions are incompatible.
    """
    if not is_compatible_api_version(plugin_api_version, registry_api_version):
        raise ValueError(
            "Incompatible plugin api_version "
            f"'{plugin_api_version}' for Casca plugin API '{registry_api_version}'"
        )


@dataclass(frozen=True)
class WidgetRegistration:
    """Widget registration entry."""

    name: str
    widget_class: type
    source: str = "runtime"


class PluginRegistry:
    """
    Stable registration API for community widgets.

    Supported plugin shapes for entry points in group ``casca.widgets``:
    - widget class object
    - callable(registry) -> None | widget class | dict[name, class]
    - dict[name, class]
    """

    def __init__(self, api_version: str = "1.0") -> None:
        """
        Initialize plugin registry.

        Args:
            api_version: Registry API version.
        """
        self.api_version = str(api_version)
        self._widgets: dict[str, WidgetRegistration] = {}
        self._loaded_entrypoints: set[str] = set()

    def register_widget(
        self,
        name: str,
        widget_class: type,
        *,
        source: str = "runtime",
        replace: bool = False,
        api_version: str | None = None,
    ) -> type:
        """
        Register a widget class.

        Args:
            name: Widget name (must be non-empty).
            widget_class: Widget class to register.
            source: Registration source.
            replace: If True, replace existing registration.
            api_version: Optional API version override.

        Returns:
            The registered widget class.

        Raises:
            ValueError: If name is empty or widget already registered.
            TypeError: If widget_class is not a class.
        """
        key = str(name).strip().lower()
        if not key:
            raise ValueError("Widget name must be non-empty")
        if not isinstance(widget_class, type):
            raise TypeError("widget_class must be a class")

        plugin_api_version = api_version
        if plugin_api_version is None:
            plugin_api_version = getattr(widget_class, "CASCA_API_VERSION", None)
        if plugin_api_version is not None:
            validate_plugin_api_version(str(plugin_api_version), self.api_version)

        if key in self._widgets and not replace:
            raise ValueError(f"Widget '{key}' is already registered")

        self._widgets[key] = WidgetRegistration(name=key, widget_class=widget_class, source=source)
        return widget_class

    def get_widget(self, name: str) -> type | None:
        """
        Get widget class by name.

        Args:
            name: Widget name.

        Returns:
            Widget class or None if not found.
        """
        key = str(name).strip().lower()
        reg = self._widgets.get(key)
        return reg.widget_class if reg else None

    def create_widget(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """
        Create widget instance by name.

        Args:
            name: Widget name.
            *args: Positional arguments for widget constructor.
            **kwargs: Keyword arguments for widget constructor.

        Returns:
            Widget instance.

        Raises:
            KeyError: If widget is not registered.
        """
        widget_class = self.get_widget(name)
        if widget_class is None:
            raise KeyError(f"Widget '{name}' is not registered")
        return widget_class(*args, **kwargs)

    def list_widgets(self) -> list[WidgetRegistration]:
        """
        List all registered widgets.

        Returns:
            List of widget registrations.
        """
        return [self._widgets[key] for key in sorted(self._widgets)]

    def discover_plugins(self, group: str = "casca.widgets") -> list[WidgetRegistration]:
        """
        Discover and load plugins from entry points.

        Args:
            group: Entry point group name.

        Returns:
            List of all registered widgets.
        """
        eps = entry_points()
        selected = eps.select(group=group) if hasattr(eps, "select") else eps.get(group, [])

        for ep in selected:
            ep_key = f"{ep.group}:{ep.name}:{ep.value}"
            if ep_key in self._loaded_entrypoints:
                continue
            obj = ep.load()
            self._consume_plugin_object(ep.name, obj, source=f"entrypoint:{ep.value}")
            self._loaded_entrypoints.add(ep_key)

        return self.list_widgets()

    def _consume_plugin_object(self, ep_name: str, obj: Any, *, source: str) -> None:
        """
        Process a loaded plugin object.

        Args:
            ep_name: Entry point name.
            obj: Loaded plugin object.
            source: Plugin source.

        Raises:
            TypeError: If plugin object type is unsupported.
        """
        plugin_api_version = getattr(obj, "CASCA_API_VERSION", None)
        if isinstance(obj, type):
            self.register_widget(ep_name, obj, source=source, api_version=plugin_api_version)
            return

        if callable(obj):
            result = obj(self)
            if isinstance(result, type):
                self.register_widget(ep_name, result, source=source, api_version=plugin_api_version)
                return
            if isinstance(result, dict):
                for name, cls in result.items():
                    self.register_widget(name, cls, source=source, api_version=plugin_api_version)
                return
            return

        if isinstance(obj, dict):
            for name, cls in obj.items():
                self.register_widget(name, cls, source=source, api_version=plugin_api_version)
            return

        raise TypeError(
            "Unsupported plugin type. Expected class, callable(registry), or dict[name, class]."
        )


# Global plugin registry instance
casca_plugins = PluginRegistry()


def register_widget(
    name: str,
    widget_class: type,
    *,
    source: str = "runtime",
    replace: bool = False,
    api_version: str | None = None,
) -> type:
    """
    Register a widget class globally.

    Args:
        name: Widget name.
        widget_class: Widget class.
        source: Registration source.
        replace: If True, replace existing.
        api_version: Optional API version.

    Returns:
        The registered widget class.
    """
    return casca_plugins.register_widget(
        name,
        widget_class,
        source=source,
        replace=replace,
        api_version=api_version,
    )


def get_widget(name: str) -> type | None:
    """
    Get widget class by name.

    Args:
        name: Widget name.

    Returns:
        Widget class or None.
    """
    return casca_plugins.get_widget(name)


def create_widget(name: str, *args: Any, **kwargs: Any) -> Any:
    """
    Create widget instance by name.

    Args:
        name: Widget name.
        *args: Constructor arguments.
        **kwargs: Constructor keyword arguments.

    Returns:
        Widget instance.
    """
    return casca_plugins.create_widget(name, *args, **kwargs)


def list_widgets() -> list[WidgetRegistration]:
    """
    List all registered widgets.

    Returns:
        List of widget registrations.
    """
    return casca_plugins.list_widgets()


def discover_plugins(group: str = "casca.widgets") -> list[WidgetRegistration]:
    """
    Discover plugins from entry points.

    Args:
        group: Entry point group.

    Returns:
        List of widget registrations.
    """
    return casca_plugins.discover_plugins(group=group)
