"""
Casca CSS Parser and Validator.

Provides CSS parsing, validation, and style resolution for widgets.
"""

import re
from pathlib import Path
from typing import Any

# Known style keys for validation
_KNOWN_STYLE_KEYS: set[str] = {
    "color",
    "background",
    "width",
    "min-width",
    "max-width",
    "height",
    "min-height",
    "max-height",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "border",
    "border-char",
    "border-color",
    "font-weight",
    "font-style",
    "text-decoration",
    "font-effect",
    "opacity",
    "flex-direction",
    "flex",
    "flex-grow",
    "flex-shrink",
    "flex-basis",
    "justify-content",
    "align-items",
    "align-self",
    "gap",
    "white-space",
    "text-overflow",
    "letter-spacing",
    "overflow-x",
    "overflow-y",
    "vertical-align",
    "scroll-step",
    "scroll-page-step",
    "wheel-step",
    "sticky-header-rows",
}

# Dimension keys that support numeric values and percentages
_DIMENSION_KEYS: set[str] = {
    "width",
    "min-width",
    "max-width",
    "height",
    "min-height",
    "max-height",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "gap",
    "scroll-step",
    "scroll-page-step",
    "wheel-step",
    "sticky-header-rows",
}

# Valid overflow values
_OVERFLOW_VALUES: set[str] = {"visible", "hidden", "auto", "scroll"}

# Named CSS colors
_NAMED_COLORS: set[str] = {
    "default",
    "black",
    "red",
    "green",
    "yellow",
    "blue",
    "magenta",
    "cyan",
    "white",
    "bright_black",
    "bright_red",
    "bright_green",
    "bright_yellow",
    "bright_blue",
    "bright_magenta",
    "bright_cyan",
    "bright_white",
}

# Maximum CSS file size (64KB)
MAX_CSS_FILE_SIZE = 64 * 1024


def parse_css(css_string: str) -> dict[str, dict[str, str]]:
    """
    Parse a CSS string into a stylesheet dictionary.

    Supports basic classes (.cls), IDs (#id), and element (tag) selectors.
    Does not support media queries, pseudo-selectors, or combinators.

    Args:
        css_string: CSS string to parse.

    Returns:
        Dictionary mapping selectors to style dictionaries.
        Example: {'.btn': {'color': 'red', 'padding': '1'}}
    """
    stylesheet: dict[str, dict[str, str]] = {}

    # Remove comments
    css_string = re.sub(r"/\*.*?\*/", "", css_string, flags=re.DOTALL)

    # Find all blocks: selector { rules }
    blocks = re.findall(r"([^{]+)\{([^}]+)\}", css_string)

    for selector_group, rules_text in blocks:
        selectors = [s.strip() for s in selector_group.split(",")]

        rules: dict[str, str] = {}
        for rule in rules_text.split(";"):
            rule = rule.strip()
            if not rule:
                continue
            if ":" in rule:
                key, value = rule.split(":", 1)
                key = key.strip()
                value = value.strip()

                # Expand shorthand margin/padding
                if key in ("margin", "padding") and " " in value:
                    parts = value.split()
                    if len(parts) == 4:
                        # top right bottom left
                        rules[f"{key}-top"] = parts[0]
                        rules[f"{key}-right"] = parts[1]
                        rules[f"{key}-bottom"] = parts[2]
                        rules[f"{key}-left"] = parts[3]
                        continue
                    elif len(parts) == 3:
                        # top right/left bottom
                        rules[f"{key}-top"] = parts[0]
                        rules[f"{key}-right"] = parts[1]
                        rules[f"{key}-left"] = parts[1]
                        rules[f"{key}-bottom"] = parts[2]
                        continue
                    elif len(parts) == 2:
                        # top/bottom right/left
                        rules[f"{key}-top"] = parts[0]
                        rules[f"{key}-bottom"] = parts[0]
                        rules[f"{key}-right"] = parts[1]
                        rules[f"{key}-left"] = parts[1]
                        continue

                rules[key] = value

        for selector in selectors:
            if selector not in stylesheet:
                stylesheet[selector] = {}
            stylesheet[selector].update(rules)

    return stylesheet


def load_css_file(path: str) -> str:
    """
    Load CSS text from disk.

    Args:
        path: Path to CSS file (absolute or relative to current directory).

    Returns:
        CSS file contents as string.

    Raises:
        FileNotFoundError: If file doesn't exist.
        PermissionError: If file can't be read.
        ValueError: If file is too large (>64KB).
        OSError: If path is invalid or inaccessible.
    """
    css_path = Path(path).expanduser().resolve()

    # Security: Check file exists and is a file
    if not css_path.exists():
        raise FileNotFoundError(f"CSS file not found: {css_path}")
    if not css_path.is_file():
        raise ValueError(f"Path is not a file: {css_path}")

    # Security: Check file size before reading
    file_size = css_path.stat().st_size
    if file_size > MAX_CSS_FILE_SIZE:
        raise ValueError(f"CSS file too large: {file_size} bytes (max: {MAX_CSS_FILE_SIZE})")

    return css_path.read_text(encoding="utf-8")


def get_style_for_node(
    node_id: str, classes: list[str], tag: str, stylesheet: dict[str, Any]
) -> dict[str, str]:
    """
    Resolve styles for a given node in order of specificity: tag -> class -> id.

    Args:
        node_id: Widget ID.
        classes: List of CSS classes.
        tag: Widget tag name.
        stylesheet: Global stylesheet dictionary.

    Returns:
        Merged style dictionary.
    """
    style: dict[str, str] = {}

    # 1. Tag (lowest specificity)
    if tag in stylesheet:
        style.update(stylesheet[tag])

    # 2. Classes (medium specificity)
    for cls in classes:
        cls_sel = f".{cls}"
        if cls_sel in stylesheet:
            style.update(stylesheet[cls_sel])

    # 3. ID (highest specificity)
    if node_id:
        id_sel = f"#{node_id}"
        if id_sel in stylesheet:
            style.update(stylesheet[id_sel])

    return style


def get_border_width(style: dict[str, Any]) -> int:
    """
    Return normalized border width from style values.

    Args:
        style: Style dictionary.

    Returns:
        Border width (0 or 1).
    """
    border_value = str(style.get("border", "none")).strip().lower()
    if border_value in ("", "none", "0", "false"):
        return 0
    return 1


def parse_size(value: Any, reference: int, fallback: int | None = None) -> int | None:
    """
    Parse a style size value as int (supports percentages).

    Args:
        value: Value to parse (int, float, or string with %).
        reference: Reference size for percentage calculations.
        fallback: Default value if parsing fails.

    Returns:
        Parsed size or fallback.
    """
    if value is None:
        return fallback
    if isinstance(value, str) and value.endswith("%"):
        try:
            return int(reference * (float(value.strip("%")) / 100.0))
        except ValueError:
            return fallback
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


def clamp_dimension(
    raw_value: Any, style: dict[str, Any], axis: str, reference: int, fallback: int
) -> int:
    """
    Resolve width/height with optional min/max constraints.

    Args:
        raw_value: The base width/height value to resolve.
        style: Style dict that may define min/max constraints.
        axis: Either 'width' or 'height'.
        reference: Parent reference size.
        fallback: Size used when value parsing fails.

    Returns:
        Clamped dimension value.
    """
    size = parse_size(raw_value, reference, fallback)
    if size is None:
        size = fallback

    min_key = f"min-{axis}"
    max_key = f"max-{axis}"

    min_size = parse_size(style.get(min_key), reference, None)
    max_size = parse_size(style.get(max_key), reference, None)

    if min_size is not None:
        size = max(size, min_size)
    if max_size is not None:
        size = min(size, max_size)
    return max(0, size)


def get_box_spacing(style: dict[str, Any], key: str) -> tuple[int, int, int, int]:
    """
    Resolve spacing values for top/right/bottom/left.

    Supports base shorthand key (padding, margin) and expanded keys
    (padding-top, margin-left, ...).

    Args:
        style: Style dictionary.
        key: Base key name ('padding' or 'margin').

    Returns:
        Tuple of (top, right, bottom, left) in pixels/characters.
    """
    base = int(style.get(key, 0))
    top = int(style.get(f"{key}-top", base))
    right = int(style.get(f"{key}-right", base))
    bottom = int(style.get(f"{key}-bottom", base))
    left = int(style.get(f"{key}-left", base))
    return top, right, bottom, left


def validate_stylesheet(stylesheet: dict[str, dict[str, str]]) -> list[str]:
    """
    Return dev-mode warnings for unsupported style keys and invalid values.

    Args:
        stylesheet: Stylesheet dictionary to validate.

    Returns:
        List of warning messages.
    """
    warnings: list[str] = []

    for selector, rules in stylesheet.items():
        for key, value in rules.items():
            if key not in _KNOWN_STYLE_KEYS:
                warnings.append(f"Unknown style key '{key}' in selector '{selector}'")
                continue

            if key in ("color", "background", "border-color") and not _is_valid_color_value(value):
                warnings.append(
                    f"Possibly invalid color '{value}' for key '{key}' in selector '{selector}'"
                )

            if key in _DIMENSION_KEYS:
                size_warning = _validate_dimension_value(key, value)
                if size_warning:
                    warnings.append(f"{size_warning} in selector '{selector}'")

            if key in ("overflow-x", "overflow-y"):
                raw = str(value).strip().lower()
                if raw not in _OVERFLOW_VALUES:
                    warnings.append(
                        f"Invalid overflow value '{value}' for key '{key}' in selector '{selector}'"
                    )

            if key == "letter-spacing":
                spacing_warning = _validate_dimension_value(key, value)
                if spacing_warning:
                    warnings.append(f"{spacing_warning} in selector '{selector}'")

    return warnings


def _validate_dimension_value(key: str, value: str) -> str | None:
    """
    Validate a dimension value (numeric or percentage).

    Args:
        key: Style key name.
        value: Value to validate.

    Returns:
        Warning message or None if valid.
    """
    raw = str(value).strip()
    if raw == "":
        return f"Empty value for '{key}'"

    if raw.endswith("%"):
        try:
            pct = float(raw[:-1])
        except ValueError:
            return f"Invalid percentage '{raw}' for '{key}'"

        if pct < 0:
            return f"Negative percentage '{raw}' for '{key}'"
        if key in ("width", "height") and pct > 100:
            return f"Possibly impossible size '{raw}' for '{key}' (>{100}%)"
        return None

    try:
        num = float(raw)
    except ValueError:
        return f"Invalid numeric value '{raw}' for '{key}'"

    if num < 0:
        return f"Negative value '{raw}' for '{key}'"
    return None


def _is_valid_color_value(value: str) -> bool:
    """
    Check if a string is a valid color value.

    Supports:
    - Named colors (red, blue, default, etc.)
    - Hex colors (#RRGGBB)
    - RGB functions (rgb(255, 0, 0))
    - ANSI color indices (ansi(196))

    Args:
        value: Color value string.

    Returns:
        True if valid color, False otherwise.
    """
    raw = str(value).strip().lower()
    if raw in _NAMED_COLORS:
        return True
    if re.match(r"^#([0-9a-f]{6})$", raw):
        return True
    if re.match(r"^rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)$", raw):
        return True
    if re.match(r"^ansi\(\s*\d{1,3}\s*\)$", raw):
        return True
    return False
