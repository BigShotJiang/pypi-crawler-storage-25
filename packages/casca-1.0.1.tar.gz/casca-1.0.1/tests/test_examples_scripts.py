"""Smoke tests ensuring examples stay small and runnable as scripts."""

from __future__ import annotations

import runpy
from pathlib import Path

from casca import App


def _example_files(examples_dir: Path) -> list[str]:
    files = []
    for path in sorted(examples_dir.glob("[0-9][0-9]_*.py")):
        files.append(path.name)
    return files


def test_examples_expose_build_factory_and_build_ui_tree():
    examples_dir = Path(__file__).resolve().parent.parent / "examples"
    examples = _example_files(examples_dir)
    assert examples, "No example scripts found"

    for filename in examples:
        namespace = runpy.run_path(str(examples_dir / filename))
        if "build_example_app" in namespace:
            app = namespace["build_example_app"]()
        else:
            app_classes = [
                obj
                for obj in namespace.values()
                if isinstance(obj, type) and issubclass(obj, App) and obj is not App
            ]
            assert app_classes, f"{filename} must expose build_example_app() or an App subclass"
            app = app_classes[0]()

        root = app.build_ui()

        assert root is not None, f"{filename} returned empty UI tree"
        root.resolve_styles(app.stylesheet)
        width, height = root.calculate_layout(100, 30)
        assert width > 0 and height > 0, f"{filename} produced invalid layout size"
