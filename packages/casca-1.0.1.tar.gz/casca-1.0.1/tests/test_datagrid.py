"""Tests for DataGrid skeleton widget."""

from casca import DataGrid, KeyEvent, MouseEvent
from casca.core.events import Keys


class FakeApp:
    def __init__(self):
        self.draw_calls = []
        self.writes = []

    def write(self, text: str):
        self.writes.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        self.draw_calls.append((x, y, text))


def _grid() -> DataGrid:
    grid = DataGrid(
        columns=["id", "name"],
        rows=[
            ["1", "Alpha"],
            ["2", "Beta"],
            ["3", "Gamma"],
            ["4", "Delta"],
        ],
        width=24,
        height=6,
    )
    grid.resolve_styles({})
    grid.x = 0
    grid.y = 0
    grid.calculate_layout(80, 24)
    return grid


def test_datagrid_keyboard_selection_moves_and_clamps():
    grid = _grid()

    for _ in range(20):
        grid.handle_input(KeyEvent(key=Keys.DOWN, is_printable=False))
    assert grid.selected_row == len(grid.rows) - 1

    for _ in range(20):
        grid.handle_input(KeyEvent(key=Keys.UP, is_printable=False))
    assert grid.selected_row == 0


def test_datagrid_mouse_selects_data_row():
    grid = _grid()

    # y=4 targets first visible data row after header + divider
    handled = grid.on_mouse(MouseEvent(x=1, y=4, button=0, pressed=False))

    assert handled is True
    assert grid.selected_row == 1


def test_datagrid_render_includes_header_and_selected_marker():
    grid = _grid()
    app = FakeApp()
    grid.render(app)

    rendered_lines = [text for _x, _y, text in app.draw_calls]
    assert any("id" in line and "name" in line for line in rendered_lines)
    assert any(line.startswith("> ") for line in rendered_lines)


def test_datagrid_column_sizing_supports_fixed_and_flex():
    grid = DataGrid(
        columns=[
            {"name": "id", "width": 4},
            {"name": "name", "flex": 2},
            {"name": "status", "flex": 1},
        ],
        rows=[["1", "Alpha", "online"]],
        width=36,
        height=6,
    )
    grid.resolve_styles({})
    grid.calculate_layout(80, 24)

    assert grid._column_widths[0] == 4
    assert grid._column_widths[1] > grid._column_widths[2]


def test_datagrid_column_sizing_compresses_when_narrow():
    grid = DataGrid(
        columns=[
            {"name": "identifier", "width": 8},
            {"name": "description", "width": 12},
            {"name": "state", "flex": 1, "min_width": 5},
        ],
        rows=[["1", "A long description", "ok"]],
        width=18,
        height=6,
    )
    grid.resolve_styles({})
    grid.calculate_layout(80, 24)

    assert all(width >= 1 for width in grid._column_widths)
    assert sum(grid._column_widths) <= 18
