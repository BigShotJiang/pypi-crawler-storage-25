"""Tests for Menu and MenuItem widgets."""

import pytest
from casca.components.widgets.menu import Menu, MenuItem
from casca.core.events import KeyEvent, Keys, MouseEvent


class _FakeApp:
    """Fake app for testing."""
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None
        self._running = True
        
    def write(self, text):
        self.writes.append(text)
    
    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))
    
    def request_render(self):
        pass


class TestMenuItemInit:
    """Test MenuItem initialization."""
    
    def test_init_with_label(self):
        """Test MenuItem with just a label."""
        item = MenuItem(label="File")
        
        assert item.label == "File"
        assert item.on_click is None
        assert item.shortcut is None
    
    def test_init_with_callback(self):
        """Test MenuItem with callback."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="Edit", on_click=callback)
        
        assert item.on_click is callback
        item.on_click()
        assert len(callback_called) == 1
    
    def test_init_with_shortcut(self):
        """Test MenuItem with keyboard shortcut."""
        item = MenuItem(label="Save", shortcut="Ctrl+S")
        
        assert item.shortcut == "Ctrl+S"


class TestMenuItemLayout:
    """Test MenuItem layout calculation."""
    
    def test_calculate_layout_basic(self):
        """Test basic layout calculation."""
        item = MenuItem(label="File")
        item.resolve_styles({})
        
        width, height = item.calculate_layout(100, 10)
        
        assert item.height >= 1
        assert item.width >= len("File")
    
    def test_calculate_layout_with_shortcut(self):
        """Test layout with shortcut."""
        item = MenuItem(label="Save", shortcut="Ctrl+S")
        item.resolve_styles({})
        
        width, height = item.calculate_layout(100, 10)
        
        # Width should include label + shortcut + spacing
        assert item.width >= len("Save") + len("Ctrl+S")


class TestMenuItemRender:
    """Test MenuItem rendering."""
    
    def test_render_content(self):
        """Test rendering menu item content."""
        item = MenuItem(label="File")
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        
        app = _FakeApp()
        item.render_content(app)
        
        # Should have drawn the label
        assert len(app.draw_calls) > 0
    
    def test_render_with_shortcut(self):
        """Test rendering with shortcut."""
        item = MenuItem(label="Save", shortcut="Ctrl+S")
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        
        app = _FakeApp()
        item.render_content(app)
        
        # Should have drawn label and shortcut
        assert len(app.draw_calls) > 0


class TestMenuItemMouse:
    """Test MenuItem mouse handling."""
    
    def test_handle_mouse_hover(self):
        """Test mouse hover updates hover state."""
        item = MenuItem(label="File")
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        item.width = 10
        item.height = 3
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=False)
        item.handle_mouse(event, app)
        
        assert item._hovered is True
    
    def test_handle_mouse_click(self):
        """Test mouse click triggers callback."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="File", on_click=callback)
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        item.width = 10
        item.height = 3
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        item.handle_mouse(event, app)
        
        assert len(callback_called) == 1
    
    def test_handle_mouse_outside_bounds(self):
        """Test mouse outside bounds doesn't trigger."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="File", on_click=callback)
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        item.width = 10
        item.height = 3
        
        app = _FakeApp()
        event = MouseEvent(x=50, y=50, button=0, pressed=True)
        item.handle_mouse(event, app)
        
        assert len(callback_called) == 0
    
    def test_handle_mouse_disabled(self):
        """Test disabled item doesn't respond to clicks."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="File", on_click=callback)
        item.disabled = True
        item.resolve_styles({})
        item.calculate_layout(100, 10)
        item.x = 0
        item.y = 0
        item.width = 10
        item.height = 3
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        item.handle_mouse(event, app)
        
        assert len(callback_called) == 0


class TestMenuItemKeyboard:
    """Test MenuItem keyboard handling."""
    
    def test_handle_input_enter(self):
        """Test Enter key triggers callback."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="File", on_click=callback)
        item.resolve_styles({})
        
        event = KeyEvent(key=Keys.ENTER, is_printable=False)
        result = item.handle_input(event)
        
        assert len(callback_called) == 1
        assert result is True
    
    def test_handle_input_disabled(self):
        """Test disabled item doesn't respond to keyboard."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        item = MenuItem(label="File", on_click=callback)
        item.disabled = True
        
        event = KeyEvent(key=Keys.ENTER, is_printable=False)
        item.handle_input(event)
        
        assert len(callback_called) == 0


class TestMenuInit:
    """Test Menu initialization."""
    
    def test_init_with_items(self):
        """Test Menu with menu items."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        
        assert len(menu.children) == 3
        assert menu.selected_index == 0


class TestMenuLayout:
    """Test Menu layout calculation."""
    
    def test_calculate_layout_horizontal(self):
        """Test horizontal layout of menu items."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        menu.resolve_styles({})
        
        width, height = menu.calculate_layout(200, 10)
        
        # Items should be laid out horizontally
        assert menu.height >= 1
        assert width > 0
        
        # Check item positions
        prev_x = menu.children[0].x
        for child in menu.children[1:]:
            assert child.x > prev_x
            prev_x = child.x


class TestMenuKeyboard:
    """Test Menu keyboard handling."""
    
    def test_handle_input_left(self):
        """Test left arrow navigates to previous item."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.selected_index = 1
        
        event = KeyEvent(key=Keys.LEFT, is_printable=False)
        menu.handle_input(event)
        
        assert menu.selected_index == 0
    
    def test_handle_input_right(self):
        """Test right arrow navigates to next item."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.selected_index = 0
        
        event = KeyEvent(key=Keys.RIGHT, is_printable=False)
        menu.handle_input(event)
        
        assert menu.selected_index == 1
    
    def test_handle_input_left_at_start(self):
        """Test left arrow at start stays at start."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.selected_index = 0
        
        event = KeyEvent(key=Keys.LEFT, is_printable=False)
        menu.handle_input(event)
        
        assert menu.selected_index == 0
    
    def test_handle_input_right_at_end(self):
        """Test right arrow at end stays at end."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.selected_index = 1
        
        event = KeyEvent(key=Keys.RIGHT, is_printable=False)
        menu.handle_input(event)
        
        assert menu.selected_index == 1
    
    def test_handle_input_enter(self):
        """Test Enter triggers selected item callback."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        menu = Menu(
            MenuItem("File", on_click=callback),
            MenuItem("Edit")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.selected_index = 0
        
        event = KeyEvent(key=Keys.ENTER, is_printable=False)
        menu.handle_input(event)
        
        assert len(callback_called) == 1
    
    def test_handle_input_disabled(self):
        """Test disabled menu doesn't respond to keyboard."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        menu.disabled = True
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        event = KeyEvent(key=Keys.RIGHT, is_printable=False)
        result = menu.handle_input(event)
        
        assert result is False


class TestMenuSelection:
    """Test menu selection methods."""
    
    def test_select_item(self):
        """Test selecting item by index."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        menu.select_item(2)
        
        assert menu.selected_index == 2
        assert menu.children[2].focused is True
    
    def test_select_item_out_of_bounds(self):
        """Test selecting item with invalid index."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        # Should not raise
        menu.select_item(10)
        menu.select_item(-1)
    
    def test_select_item_by_label(self):
        """Test selecting item by label."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit"),
            MenuItem("Help")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        menu.select_item_by_label("Edit")
        
        assert menu.selected_index == 1
    
    def test_select_item_by_label_not_found(self):
        """Test selecting non-existent label."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        # Should not raise
        menu.select_item_by_label("NonExistent")


class TestMenuMouse:
    """Test Menu mouse handling."""
    
    def test_handle_mouse_propagates_to_children(self):
        """Test mouse events propagate to children."""
        callback_called = []
        
        def callback():
            callback_called.append(True)
        
        menu = Menu(
            MenuItem("File", on_click=callback)
        )
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        menu.children[0].x = 0
        menu.children[0].y = 0
        menu.children[0].width = 10
        menu.children[0].height = 3
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        menu.handle_mouse(event, app)
        
        assert len(callback_called) == 1
    
    def test_handle_mouse_disabled(self):
        """Test disabled menu doesn't respond to mouse."""
        menu = Menu(
            MenuItem("File")
        )
        menu.disabled = True
        menu.resolve_styles({})
        menu.calculate_layout(200, 10)
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        result = menu.handle_mouse(event, app)
        
        assert result is False
