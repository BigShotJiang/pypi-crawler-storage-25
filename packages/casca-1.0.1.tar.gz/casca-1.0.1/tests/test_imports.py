from casca import (
    App,
    Container,
    Label,
    Button,
    Input,
    Checkbox,
    Card,
    Header,
    ProgressBar,
    Spinner,
    DataGrid,
    RadioGroup,
    TreeView,
    Table,
    CommandPalette,
    NotificationCenter,
    StudioPanel,
    register_widget,
    get_widget,
    create_widget,
    list_widgets,
    discover_plugins,
    is_compatible_api_version,
    validate_plugin_api_version,
    Store,
    create_store,
    combine_reducers,
)


def test_core_imports_exist():
    assert App is not None
    assert Container is not None
    assert Label is not None
    assert Button is not None
    assert Input is not None
    assert Checkbox is not None
    assert Card is not None
    assert Header is not None
    assert ProgressBar is not None
    assert Spinner is not None
    assert DataGrid is not None
    assert RadioGroup is not None
    assert TreeView is not None
    assert Table is not None
    assert CommandPalette is not None
    assert NotificationCenter is not None
    assert StudioPanel is not None
    assert register_widget is not None
    assert get_widget is not None
    assert create_widget is not None
    assert list_widgets is not None
    assert discover_plugins is not None
    assert is_compatible_api_version is not None
    assert validate_plugin_api_version is not None
    assert Store is not None
    assert create_store is not None
    assert combine_reducers is not None
