"""
Tests for Casca Logging Configuration.

Tests for the logging setup and configuration.
"""

import pytest
import logging
import io
import sys
from typing import Any, List

from casca.core.logging_config import (
    setup_logging,
    get_logger,
    enable_debug_logging,
    is_configured,
    DEFAULT_LOG_FORMAT,
)


class TestLoggingSetup:
    """Tests for setup_logging function."""

    def setup_method(self) -> None:
        """Reset logging state before each test."""
        # Reset the configured state
        import casca.core.logging_config as config
        config._configured = False
        
        # Remove any casca handlers
        casca_logger = logging.getLogger("casca")
        casca_logger.handlers.clear()
        casca_logger.setLevel(logging.WARNING)

    def test_setup_logging_creates_handler(self) -> None:
        """Test setup_logging creates a handler."""
        setup_logging(level=logging.INFO)
        
        casca_logger = logging.getLogger("casca")
        assert len(casca_logger.handlers) > 0

    def test_setup_logging_sets_level(self) -> None:
        """Test setup_logging sets correct level."""
        setup_logging(level=logging.DEBUG)
        
        casca_logger = logging.getLogger("casca")
        assert casca_logger.level == logging.DEBUG

    def test_setup_logging_default_level(self) -> None:
        """Test setup_logging default level is WARNING."""
        setup_logging()
        
        casca_logger = logging.getLogger("casca")
        assert casca_logger.level == logging.WARNING

    def test_setup_logging_custom_format(self) -> None:
        """Test setup_logging with custom format."""
        custom_format = "%(levelname)s: %(message)s"
        setup_logging(log_format=custom_format)
        
        casca_logger = logging.getLogger("casca")
        handler = casca_logger.handlers[0]
        formatter = handler.formatter
        
        assert formatter._fmt == custom_format  # type: ignore

    def test_setup_logging_file_handler(self, tmp_path: Any) -> None:
        """Test setup_logging with file handler."""
        log_file = tmp_path / "test.log"
        setup_logging(log_file=str(log_file))
        
        assert log_file.exists()

    def test_setup_logging_only_once(self, caplog: pytest.LogCaptureFixture) -> None:
        """Test setup_logging can only be called once."""
        setup_logging(level=logging.INFO)
        
        # Second call should log warning but not raise
        with caplog.at_level(logging.WARNING):
            setup_logging(level=logging.DEBUG)
        
        # Check warning was logged
        assert "already configured" in caplog.text
        
        # Level should still be INFO (first call wins)
        casca_logger = logging.getLogger("casca")
        assert casca_logger.level == logging.INFO

    def test_is_configured_before_setup(self) -> None:
        """Test is_configured returns False before setup."""
        assert is_configured() is False

    def test_is_configured_after_setup(self) -> None:
        """Test is_configured returns True after setup."""
        setup_logging()
        assert is_configured() is True


class TestGetLogger:
    """Tests for get_logger function."""

    def setup_method(self) -> None:
        """Reset logging state."""
        import casca.core.logging_config as config
        config._configured = False
        logging.getLogger("casca").handlers.clear()

    def test_get_logger_returns_logger(self) -> None:
        """Test get_logger returns a logger instance."""
        logger = get_logger("app")
        
        assert isinstance(logger, logging.Logger)

    def test_get_logger_name(self) -> None:
        """Test get_logger creates correctly named logger."""
        logger = get_logger("widgets.button")
        
        assert logger.name == "casca.widgets.button"

    def test_get_logger_inherits_level(self) -> None:
        """Test get_logger inherits casca logger level."""
        setup_logging(level=logging.DEBUG)
        
        logger = get_logger("app")
        assert logger.level == logging.NOTSET  # Inherits from parent


class TestEnableDebugLogging:
    """Tests for enable_debug_logging function."""

    def setup_method(self) -> None:
        """Reset logging state."""
        import casca.core.logging_config as config
        config._configured = False
        logging.getLogger("casca").handlers.clear()

    def test_enable_debug_logging_sets_debug(self) -> None:
        """Test enable_debug_logging sets DEBUG level."""
        enable_debug_logging()
        
        casca_logger = logging.getLogger("casca")
        assert casca_logger.level == logging.DEBUG


class TestLoggingOutput:
    """Tests for actual logging output."""

    def setup_method(self) -> None:
        """Reset logging state."""
        import casca.core.logging_config as config
        config._configured = False
        logging.getLogger("casca").handlers.clear()

    def test_logging_to_stderr(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Test logging outputs to stderr."""
        setup_logging(level=logging.INFO)
        
        logger = get_logger("test")
        logger.info("Test message")
        
        # Flush handlers
        for handler in logging.getLogger("casca").handlers:
            handler.flush()

    def test_logging_with_file(self, tmp_path: Any) -> None:
        """Test logging to file."""
        log_file = tmp_path / "test.log"
        setup_logging(level=logging.INFO, log_file=str(log_file))
        
        logger = get_logger("test")
        logger.info("Test message")
        
        # Wait for file write
        import time
        time.sleep(0.01)
        
        content = log_file.read_text()
        assert "Test message" in content


class TestLogFormat:
    """Tests for log format configuration."""

    def test_default_format_contains_timestamp(self) -> None:
        """Test default format includes timestamp."""
        assert "%(asctime)s" in DEFAULT_LOG_FORMAT

    def test_default_format_contains_level(self) -> None:
        """Test default format includes level."""
        assert "%(levelname)s" in DEFAULT_LOG_FORMAT

    def test_default_format_contains_name(self) -> None:
        """Test default format includes logger name."""
        assert "%(name)s" in DEFAULT_LOG_FORMAT

    def test_default_format_contains_message(self) -> None:
        """Test default format includes message."""
        assert "%(message)s" in DEFAULT_LOG_FORMAT
