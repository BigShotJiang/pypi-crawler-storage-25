"""Targeted tests for App helper methods and rendering utilities."""

from casca import App, Container, Input, Label, RadioGroup, create_store
from casca.core.notifications import Toast
from casca.core.events import KeyEvent, MouseEvent, Keys
from time import monotonic


class _RootSpy(Container):
    def __init__(self):
        super().__init__(Label("x"))
        self.mouse_events = []

    def handle_mouse(self, event, app):
        self.mouse_events.append((event.x, event.y))
        return True


class HelperApp(App):
    css = "#root { color: bright_green; }"

    def build_ui(self):
        return Container(
            Input(id="a"),
            RadioGroup(["x", "y"], id="r"),
            id="root",
        )


def _prepare_app():
    app = HelperApp()
    app.root = app.build_ui()
    app.root.resolve_styles(app.stylesheet)
    app.root.calculate_layout(80, 24)
    return app


def test_draw_text_respects_clip_rect():
    app = App()
    app.clip_rect = (2, 5, 3, 8)

    app.draw_text(1, 1, "abcdef")
    assert app._output_buffer == []

    app.draw_text(1, 3, "abcdef")
    # clipped to x>=3 then max x<8, so "cde"
    joined = "".join(app._output_buffer)
    assert "cde" in joined


def test_focus_helpers_collect_and_cycle_widgets():
    app = _prepare_app()

    widgets = app._collect_focusable_widgets(app.root)
    assert [w.id for w in widgets] == ["a", "r"]

    app.focus_next()
    assert app.focused_id == "a"

    app.focus_next()
    assert app.focused_id == "r"

    app.focus_next(reverse=True)
    assert app.focused_id == "a"


def test_show_toast_and_banner_helpers_set_state():
    app = App()
    app.show_toast("Saved", level="success", duration=1.0)
    assert len(app.toast_manager.active()) == 1

    app.set_banner("Working", level="info")
    assert app.banner_message == "Working"
    app.clear_banner()
    assert app.banner_message == ""


def test_render_banner_and_toasts_write_output(monkeypatch):
    app = App()
    app._last_size = (40, 10)
    calls = []

    def _draw(x, y, text, apply_clip=False):
        calls.append((x, y, text))

    monkeypatch.setattr(app, "draw_text", _draw)
    app.banner_message = "Sync complete"
    app.banner_level = "info"
    app.toast_manager._toasts = [Toast("Saved", "success", monotonic(), 999.0)]

    app._render_banner()
    app._render_toasts()

    assert any("Sync complete" in c[2] for c in calls)
    assert any("Saved" in c[2] for c in calls)


def test_handle_mouse_routes_to_root_widget():
    app = App()
    spy = _RootSpy()
    app.root = spy

    app.handle_mouse(MouseEvent(x=3, y=4, button=0, pressed=True))
    assert spy.mouse_events == [(3, 4)]


def test_handle_mouse_prioritizes_dialog_manager_when_active():
    app = App()
    spy = _RootSpy()
    app.root = spy

    class _DialogManagerStub:
        has_dialogs = True

        def __init__(self):
            self.calls = 0

        def handle_mouse(self, _event, _app):
            self.calls += 1
            return True

    app.dialog_manager = _DialogManagerStub()

    app.handle_mouse(MouseEvent(x=3, y=4, button=0, pressed=True))

    assert app.dialog_manager.calls == 1
    assert spy.mouse_events == []


def test_reload_stylesheet_keeps_css_available():
    app = HelperApp()
    first = app.stylesheet
    app.reload_stylesheet()
    assert app.stylesheet == first


def test_default_handle_input_quits_on_q():
    app = App()
    app._running = True

    app.handle_input(KeyEvent(key="q", is_printable=True))

    assert app._running is False


def test_debug_layout_overlay_draws_when_enabled():
    app = App()
    app.debug_layout = True
    app.root = Container(Label("x"), id="root")
    app.root.resolve_styles({})
    app.root.calculate_layout(20, 8)
    calls = []

    def _draw(x, y, text, apply_clip=False):
        calls.append((x, y, text))

    app.draw_text = _draw
    app._last_size = (20, 8)

    app._render_layout_overlay()

    assert len(calls) > 0
    assert any("container" in c[2] or "label" in c[2] for c in calls)


def test_runtime_style_warnings_collect_from_widgets():
    app = App()
    app.debug = True
    # Force a clipped label warning.
    app.root = Container(Label("very-long-text", style={"width": 4, "white-space": "nowrap", "text-overflow": "ellipsis"}))
    app.root.resolve_styles({})
    app.root.calculate_layout(20, 8)

    app._emit_runtime_style_warnings()
    assert any("Text clipped" in key for key in app._emitted_debug_warnings)


def test_studio_overlay_draws_focus_path_and_box_details():
    app = _prepare_app()
    app._last_size = (100, 30)
    app._studio_visible = True
    app.focus_next()

    calls = []

    def _draw(x, y, text, apply_clip=False):
        calls.append((x, y, text))

    app.draw_text = _draw
    app._render_studio_overlay()

    rendered = "\n".join(c[2] for c in calls)
    assert "Casca Studio" in rendered
    assert "Focus path:" in rendered
    assert "Box:" in rendered
    assert "Style:" in rendered


def test_f2_toggles_studio_overlay_visibility():
    app = App()
    assert app._studio_visible is False

    app.handle_input(KeyEvent(key=Keys.F2, is_printable=False))
    assert app._studio_visible is True

    app.handle_input(KeyEvent(key=Keys.F2, is_printable=False))
    assert app._studio_visible is False


def test_studio_snapshot_contains_focused_widget_details():
    app = _prepare_app()
    app.focus_next()

    snap = app.get_studio_snapshot()

    assert "focus_path" in snap
    assert snap["focused"] is not None
    assert "box" in snap["focused"]
    assert "computed_style" in snap["focused"]


def test_app_store_helpers_dispatch_and_get_state():
    def reducer(state, action):
        state = dict(state or {})
        if action["type"] == "inc":
            state["count"] = state.get("count", 0) + 1
        return state

    app = App()
    store = create_store(reducer, initial_state={"count": 0})
    app.set_store(store)

    out = app.dispatch({"type": "inc"})
    assert out["count"] == 1
    assert app.get_state()["count"] == 1


def test_app_store_updates_invalidate_ui_by_default():
    def reducer(state, action):
        state = dict(state or {})
        if action["type"] == "inc":
            state["count"] = state.get("count", 0) + 1
        return state

    app = App()
    app.root = object()
    store = create_store(reducer, initial_state={"count": 0})
    app.set_store(store)

    app.dispatch({"type": "inc"})

    assert app.root is None
    assert app._needs_render is True


def test_app_store_can_skip_rebuild_and_only_request_render():
    def reducer(state, action):
        state = dict(state or {})
        if action["type"] == "inc":
            state["count"] = state.get("count", 0) + 1
        return state

    app = App()
    sentinel_root = object()
    app.root = sentinel_root
    app._needs_render = False
    store = create_store(reducer, initial_state={"count": 0})
    app.set_store(store, rebuild_on_update=False)

    app.dispatch({"type": "inc"})

    assert app.root is sentinel_root
    assert app._needs_render is True
