"""Tests for Select dropdown widget."""

from casca import KeyEvent, MouseEvent, Select


def test_select_keyboard_navigation_when_expanded():
    sel = Select(["A", "B", "C"], selected_index=0)

    sel.handle_input(KeyEvent(key="\r", is_printable=False))
    assert sel.expanded is True

    sel.handle_input(KeyEvent(key="\x1b[B", is_printable=False))
    assert sel.selected_index == 1

    sel.handle_input(KeyEvent(key="\x1b[A", is_printable=False))
    assert sel.selected_index == 0


def test_select_mouse_click_option_selects_and_closes():
    sel = Select(["A", "B", "C"], selected_index=0)
    sel.resolve_styles({})
    sel.x = 0
    sel.y = 0

    # Expand first.
    sel.expanded = True
    sel.calculate_layout(20, 10)

    # Click release on second option line.
    # local_y calculation targets option index 1 at y=3 (1-based terminal).
    handled = sel.on_mouse(MouseEvent(x=1, y=3, button=0, pressed=False))

    assert handled is True
    assert sel.selected_index == 1
    assert sel.value == "B"
    assert sel.expanded is False
