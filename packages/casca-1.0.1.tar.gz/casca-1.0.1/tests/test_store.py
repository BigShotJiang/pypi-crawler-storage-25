"""Tests for Redux-like store implementation."""

import pytest
from casca.core.store import create_store, combine_reducers, Store


class TestCreateStore:
    """Test store creation."""

    def test_create_store_with_valid_reducer(self):
        """Test creating a store with a valid reducer."""
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {"count": 0})
        
        assert isinstance(store, Store)
        assert store.get_state() == {"count": 0}

    def test_create_store_requires_callable_reducer(self):
        """Test that reducer must be callable."""
        with pytest.raises(TypeError) as exc_info:
            create_store("not_a_function", {})
        
        assert "reducer must be callable" in str(exc_info.value)

    def test_create_store_with_initial_state(self):
        """Test creating a store with initial state."""
        def reducer(state, action):
            return state
        
        initial_state = {"user": "test", "count": 42}
        store = create_store(reducer, initial_state)
        
        assert store.get_state() == initial_state


class TestStoreDispatch:
    """Test action dispatching."""

    def test_dispatch_simple_action(self):
        """Test dispatching a simple action."""
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "inc":
                state["count"] = state.get("count", 0) + 1
            return state
        
        store = create_store(reducer, {"count": 0})
        store.dispatch({"type": "inc"})
        
        assert store.get_state()["count"] == 1

    def test_dispatch_multiple_actions(self):
        """Test dispatching multiple actions."""
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "inc":
                state["count"] = state.get("count", 0) + 1
            elif action.get("type") == "dec":
                state["count"] = state.get("count", 0) - 1
            return state
        
        store = create_store(reducer, {"count": 0})
        store.dispatch({"type": "inc"})
        store.dispatch({"type": "inc"})
        store.dispatch({"type": "dec"})
        
        assert store.get_state()["count"] == 1

    def test_dispatch_with_payload(self):
        """Test dispatching an action with payload."""
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "set":
                state["value"] = action.get("payload")
            return state
        
        store = create_store(reducer, {})
        store.dispatch({"type": "set", "payload": 42})
        
        assert store.get_state()["value"] == 42

    def test_dispatch_returns_action(self):
        """Test that dispatch returns the action."""
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {})
        action = {"type": "test"}
        result = store.dispatch(action)
        
        # Dispatch returns state snapshot, not action
        assert isinstance(result, dict)


class TestStoreSubscribe:
    """Test store subscription."""

    def test_subscribe_calls_listener(self):
        """Test that subscribe calls the listener on dispatch."""
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "inc":
                state["count"] = state.get("count", 0) + 1
            return state
        
        store = create_store(reducer, {"count": 0})
        listener_called = []
        
        def listener(state):
            listener_called.append(state)
        
        store.subscribe(listener)
        store.dispatch({"type": "inc"})
        
        assert len(listener_called) == 1
        assert listener_called[0]["count"] == 1

    def test_subscribe_returns_unsubscribe(self):
        """Test that subscribe returns an unsubscribe function."""
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {})
        listener_called = []
        
        def listener(state):
            listener_called.append(True)
        
        unsubscribe = store.subscribe(listener)
        unsubscribe()
        
        store.dispatch({"type": "test"})
        
        assert len(listener_called) == 0

    def test_multiple_subscribers(self):
        """Test multiple subscribers are all called."""
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {})
        listener1_called = []
        listener2_called = []
        
        def listener1(state):
            listener1_called.append(True)
        
        def listener2(state):
            listener2_called.append(True)
        
        store.subscribe(listener1)
        store.subscribe(listener2)
        
        store.dispatch({"type": "test"})
        
        assert len(listener1_called) == 1
        assert len(listener2_called) == 1

    def test_subscribe_requires_callable(self):
        """Test that listener must be callable."""
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {})
        
        with pytest.raises(TypeError) as exc_info:
            store.subscribe("not_a_function")
        
        assert "subscriber must be callable" in str(exc_info.value)


class TestStoreGetState:
    """Test getting state."""

    def test_get_state_returns_current_state(self):
        """Test getting the current state."""
        def reducer(state, action):
            return state or {"value": 0}
        
        store = create_store(reducer, {"value": 42})
        
        assert store.get_state() == {"value": 42}

    def test_get_state_returns_new_reference(self):
        """Test that get_state returns a new reference."""
        def reducer(state, action):
            return state
        
        store = create_store(reducer, {"value": 42})
        state1 = store.get_state()
        state2 = store.get_state()
        
        # Should be equal but not necessarily same reference
        assert state1 == state2


class TestCombineReducers:
    """Test combining multiple reducers."""

    def test_combine_reducers_basic(self):
        """Test combining multiple reducers."""
        def count_reducer(state, action):
            state = state or 0
            if action.get("type") == "inc":
                return state + 1
            return state
        
        def name_reducer(state, action):
            state = state or "unknown"
            if action.get("type") == "set_name":
                return action.get("payload")
            return state
        
        combined = combine_reducers({
            "count": count_reducer,
            "name": name_reducer
        })
        
        initial_state = {"count": 0, "name": "unknown"}
        result = combined(initial_state, {"type": "inc"})
        
        assert result["count"] == 1
        assert result["name"] == "unknown"

    def test_combine_reducers_multiple_actions(self):
        """Test combined reducers with multiple actions."""
        def count_reducer(state, action):
            state = state or 0
            if action.get("type") == "inc":
                return state + 1
            return state
        
        def name_reducer(state, action):
            state = state or "unknown"
            if action.get("type") == "set_name":
                return action.get("payload")
            return state
        
        combined = combine_reducers({
            "count": count_reducer,
            "name": name_reducer
        })
        
        state = {"count": 0, "name": "unknown"}
        state = combined(state, {"type": "inc"})
        state = combined(state, {"type": "set_name", "payload": "test"})
        
        assert state["count"] == 1
        assert state["name"] == "test"

    def test_combine_reducers_nested(self):
        """Test combining reducers with nested state."""
        def user_reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "set_user":
                state["name"] = action.get("payload")
            return state
        
        def posts_reducer(state, action):
            state = list(state or [])
            if action.get("type") == "add_post":
                state.append(action.get("payload"))
            return state
        
        combined = combine_reducers({
            "user": user_reducer,
            "posts": posts_reducer
        })
        
        initial_state = {
            "user": {"name": "john"},
            "posts": []
        }
        
        result = combined(initial_state, {"type": "set_user", "payload": "jane"})
        
        assert result["user"]["name"] == "jane"
        assert result["posts"] == []


class TestStoreMiddleware:
    """Test store middleware support."""

    def test_middleware_receives_action(self):
        """Test that middleware receives dispatched actions."""
        captured_actions = []
        
        def logger_middleware(store, action, next):
            captured_actions.append(action)
            return next(action)
        
        def reducer(state, action):
            return state
        
        store = Store(reducer, {}, [logger_middleware])
        store.dispatch({"type": "test"})
        
        assert len(captured_actions) == 1
        assert captured_actions[0]["type"] == "test"

    def test_middleware_can_modify_action(self):
        """Test that middleware can modify actions."""
        def timestamp_middleware(store, action, next):
            action["timestamp"] = 12345
            return next(action)
        
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "test":
                state["timestamp"] = action.get("timestamp")
            return state
        
        store = Store(reducer, {}, [timestamp_middleware])
        store.dispatch({"type": "test"})
        
        assert store.get_state()["timestamp"] == 12345
