"""Tests for App core functionality and event loop."""

import pytest
from unittest.mock import Mock, patch, MagicMock
from casca.core.app import App
from casca.core.events import KeyEvent, MouseEvent, ResizeEvent
from casca.dom.node import Widget


class _FakeApp:
    """Fake app for widget testing."""
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None

    def write(self, text):
        self.writes.append(text)

    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))


class TestAppInitialization:
    """Test App initialization and basic properties."""

    def test_app_init_sets_default_values(self):
        """Test that App initializes with correct default values."""
        app = App()
        
        assert app._running is False
        assert app._needs_render is True
        assert app.root is None
        assert app.focused_widget is None
        assert app.focused_id is None
        assert app.banner_message == ""
        assert app.banner_level == "info"
        assert isinstance(app.stylesheet, dict)

    def test_app_init_with_custom_css(self):
        """Test App initialization with custom CSS."""
        class CustomApp(App):
            css = """
            #root {
                padding: 1;
                border: ascii;
            }
            """
        
        app = CustomApp()
        assert app.css == CustomApp.css
        assert 'padding' in app.stylesheet.get('#root', {})

    def test_app_init_with_theme(self):
        """Test App initialization with custom theme."""
        class ThemedApp(App):
            theme = "dark"
        
        app = ThemedApp()
        assert app.theme == "dark"


class TestAppThemeManagement:
    """Test theme switching and stylesheet reloading."""

    def test_set_theme_valid(self):
        """Test switching to a valid theme."""
        app = App()
        initial_theme = app.theme
        
        app.set_theme("default")
        assert app.theme == "default"
        assert app.theme != initial_theme or initial_theme == "default"

    def test_set_theme_invalid(self):
        """Test switching to an invalid theme raises ValueError."""
        app = App()
        
        with pytest.raises(ValueError) as exc_info:
            app.set_theme("nonexistent_theme")
        
        assert "Unknown theme" in str(exc_info.value)
        assert "nonexistent_theme" in str(exc_info.value)

    def test_reload_stylesheet(self):
        """Test stylesheet reloading."""
        app = App()
        initial_stylesheet = app.stylesheet
        
        app.reload_stylesheet()
        
        # Should create a new stylesheet dict
        assert isinstance(app.stylesheet, dict)


class TestAppRenderCycle:
    """Test render cycle and invalidation."""

    def test_invalidate_clears_root(self):
        """Test that invalidate() clears the root widget."""
        app = App()
        mock_widget = Mock(spec=Widget)
        app.root = mock_widget
        
        app.invalidate()
        
        assert app.root is None
        assert app._needs_render is True

    def test_request_render_sets_flag(self):
        """Test that request_render() sets the needs_render flag."""
        app = App()
        app._needs_render = False
        
        app.request_render()
        
        assert app._needs_render is True

    def test_exit_stops_running(self):
        """Test that exit() stops the event loop."""
        app = App()
        app._running = True
        
        with patch.object(app, '_clear_all_intervals') as mock_clear:
            app.exit()
            
            assert app._running is False
            mock_clear.assert_called_once()


class TestAppEventHandling:
    """Test event handling methods."""

    def test_handle_input_delegates_to_focused_widget(self):
        """Test that handle_input delegates to focused widget."""
        app = App()
        mock_widget = Mock(spec=Widget)
        mock_widget.handle_input.return_value = True
        app.focused_widget = mock_widget
        
        event = KeyEvent(key="a", is_printable=True)
        # handle_input doesn't return a value, just calls the widget
        app.handle_input(event)
        
        mock_widget.handle_input.assert_called_once_with(event)

    def test_handle_input_no_focused_widget(self):
        """Test handle_input with no focused widget."""
        app = App()
        app.focused_widget = None
        app.root = None  # Ensure no root either
        
        event = KeyEvent(key="a", is_printable=True)
        # Should not raise
        app.handle_input(event)

    def test_handle_mouse_delegates_to_root(self):
        """Test that handle_mouse delegates to root widget."""
        app = App()
        mock_widget = Mock(spec=Widget)
        mock_widget.handle_mouse.return_value = True
        app.root = mock_widget
        
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        # handle_mouse doesn't return a value, just calls the widget
        app.handle_mouse(event)
        
        mock_widget.handle_mouse.assert_called_once_with(event, app)

    def test_handle_resize_updates_size(self):
        """Test that handle_resize updates internal size."""
        app = App()
        # _last_size is set from terminal, can't easily test resize update
        # Just verify the method exists and doesn't crash
        new_size = (120, 40)
        app.handle_resize(ResizeEvent(width=new_size[0], height=new_size[1]))
        
        # Method should complete without error
        assert True


class TestAppIntervalScheduler:
    """Test interval scheduling for background tasks."""

    def test_set_interval_returns_id(self):
        """Test that set_interval returns a numeric ID."""
        app = App()
        
        interval_id = app.set_interval(lambda: None, 1.0)
        
        assert isinstance(interval_id, int)
        assert interval_id > 0

    def test_set_interval_runs_immediately(self):
        """Test that set_interval can run callback immediately."""
        app = App()
        callback_ran = []
        
        def callback():
            callback_ran.append(True)
        
        # set_interval with run_immediately schedules on main thread
        # We need to drain the callbacks to test this
        app.set_interval(callback, 1.0, run_immediately=True)
        app._drain_main_thread_callbacks()
        
        # Callback should have run at least once
        assert len(callback_ran) > 0

    def test_clear_interval(self):
        """Test clearing an interval."""
        app = App()
        
        interval_id = app.set_interval(lambda: None, 1.0)
        app.clear_interval(interval_id)
        
        # Should not raise


class TestAppCallbacks:
    """Test callback scheduling and execution."""

    def test_run_on_main_thread_schedules_callback(self):
        """Test scheduling a callback on main thread."""
        app = App()
        callback_ran = []
        
        def callback():
            callback_ran.append(True)
        
        # App doesn't have run_on_main_thread, use _main_thread_callbacks directly
        app._main_thread_callbacks.put(callback)
        
        # Callback should be in queue
        assert not app._main_thread_callbacks.empty()

    def test_drain_main_thread_callbacks_executes_callbacks(self):
        """Test draining callbacks from queue."""
        app = App()
        results = []
        
        def callback1():
            results.append(1)
        
        def callback2():
            results.append(2)
        
        app._main_thread_callbacks.put(callback1)
        app._main_thread_callbacks.put(callback2)
        
        app._drain_main_thread_callbacks()
        
        assert results == [1, 2]

    def test_drain_callbacks_handles_exceptions(self):
        """Test that callback exceptions don't crash the loop."""
        app = App()
        
        def bad_callback():
            raise ValueError("Test error")
        
        def good_callback():
            pass
        
        app._main_thread_callbacks.put(bad_callback)
        app._main_thread_callbacks.put(good_callback)
        
        # Should not raise
        app._drain_main_thread_callbacks()


class TestAppErrorHandling:
    """Test error handling in App."""

    def test_on_error_sets_banner(self):
        """Test that on_error handles errors."""
        app = App()
        
        error = ValueError("Test error")
        # on_error writes to stderr, doesn't set banner by default
        # Just verify it doesn't crash
        app.on_error(error, "test_method")
        
        # Method should complete without raising
        assert True

    def test_on_error_with_debug_enabled(self):
        """Test error handling with debug mode enabled."""
        class DebugApp(App):
            debug = True
        
        app = DebugApp()
        error = ValueError("Test error")
        
        # Should not raise
        app.on_error(error, "test_method")


class TestAppScreenshot:
    """Test screenshot functionality."""

    def test_capture_screenshot_exists(self):
        """Test that _capture_screenshot method exists."""
        app = App()
        
        # Method should exist
        assert hasattr(app, '_capture_screenshot')


class TestAppBanner:
    """Test banner message functionality."""

    def test_set_banner(self):
        """Test setting a banner message."""
        app = App()
        
        app.set_banner("Test message", "info")
        
        assert app.banner_message == "Test message"
        assert app.banner_level == "info"

    def test_set_banner_with_level(self):
        """Test setting banner with different levels."""
        app = App()
        
        app.set_banner("Error occurred", "error")
        
        assert app.banner_message == "Error occurred"
        assert app.banner_level == "error"

    def test_clear_banner(self):
        """Test clearing the banner."""
        app = App()
        app.banner_message = "Test"
        app.banner_level = "info"
        
        app.clear_banner()
        
        assert app.banner_message == ""
        assert app.banner_level == "info"


class TestAppStore:
    """Test store integration."""

    def test_set_store(self):
        """Test setting a store."""
        from casca.core.store import create_store
        
        app = App()
        
        def reducer(state, action):
            return state or {}
        
        store = create_store(reducer, {"count": 0})
        app.set_store(store)
        
        assert app.store is store

    def test_store_dispatch(self):
        """Test dispatching actions through store."""
        from casca.core.store import create_store
        
        app = App()
        
        state_changes = []
        
        def reducer(state, action):
            state = dict(state or {})
            if action.get("type") == "inc":
                state["count"] = state.get("count", 0) + 1
            state_changes.append(state)
            return state
        
        store = create_store(reducer, {"count": 0})
        app.set_store(store)
        
        store.dispatch({"type": "inc"})
        
        assert len(state_changes) > 0
        assert state_changes[-1]["count"] == 1
