"""
Tests for Casca Core App Module.

Comprehensive tests for the App class including:
- Initialization
- State management
- Interval management
- Error handling
- Thread safety
"""

import pytest
import threading
from typing import Any, Dict, List
from unittest.mock import Mock, patch, MagicMock

from casca import App, Widget, Container, Label
from casca.core.store import Store, create_store
from casca.core.events import KeyEvent, MouseEvent, ResizeEvent, Keys


class TestAppInitialization:
    """Tests for App initialization."""

    def test_app_init_default_values(self) -> None:
        """Test app initializes with default values."""
        app = App()
        
        assert app._running is False
        assert app.root is None
        assert app.theme == "default"
        assert app.stylesheet is not None
        assert app.focused_widget is None
        assert app.store is None
        assert app.banner_message == ""

    def test_app_init_with_custom_theme(self) -> None:
        """Test app initializes with custom theme."""
        class CustomApp(App):
            theme = "dark"
        
        app = CustomApp()
        assert app.theme == "dark"

    def test_app_init_with_css(self) -> None:
        """Test app initializes with inline CSS."""
        class CustomApp(App):
            css = "#root { color: red; }"
        
        app = CustomApp()
        assert "#root" in app.stylesheet or app.stylesheet  # CSS is parsed


class TestAppStateManagement:
    """Tests for App state management."""

    def test_set_state_updates_attributes(self) -> None:
        """Test set_state updates app attributes."""
        app = App()
        app.counter = 0
        
        app.set_state(counter=1, message="hello")
        
        assert app.counter == 1
        assert app.message == "hello"

    def test_set_state_with_rerender(self) -> None:
        """Test set_state triggers rerender."""
        app = App()
        app.root = Mock()
        
        app.set_state(counter=1, rerender=True)
        
        assert app._needs_render is True

    def test_set_state_without_rerender(self) -> None:
        """Test set_state without rerender."""
        app = App()
        app._needs_render = False
        
        app.set_state(counter=1, rerender=False)
        
        assert app._needs_render is False

    def test_invalidate_clears_root(self) -> None:
        """Test invalidate clears root and requests render."""
        app = App()
        app.root = Mock()
        app._needs_render = False
        
        app.invalidate()
        
        assert app.root is None
        assert app._needs_render is True


class TestAppIntervals:
    """Tests for App interval management."""

    def test_set_interval_returns_id(self) -> None:
        """Test set_interval returns numeric ID."""
        app = App()
        
        interval_id = app.set_interval(lambda: None, 1.0)
        
        assert isinstance(interval_id, int)
        assert interval_id > 0

    def test_set_interval_minimum_interval(self) -> None:
        """Test set_interval enforces minimum interval."""
        app = App()
        
        # Should not raise, should use 0.01 minimum
        interval_id = app.set_interval(lambda: None, 0.001)
        
        assert interval_id > 0

    def test_clear_interval_existing(self) -> None:
        """Test clearing an existing interval."""
        app = App()
        interval_id = app.set_interval(lambda: None, 1.0)
        
        result = app.clear_interval(interval_id)
        
        assert result is True

    def test_clear_interval_nonexistent(self) -> None:
        """Test clearing a non-existent interval."""
        app = App()
        
        result = app.clear_interval(9999)
        
        assert result is False

    def test_set_interval_max_limit(self) -> None:
        """Test set_interval raises at max limit."""
        app = App()
        
        # Create MAX_INTERVALS intervals
        from casca.core.app import MAX_INTERVALS
        for i in range(MAX_INTERVALS):
            app.set_interval(lambda: None, 1.0)
        
        # Next one should raise
        with pytest.raises(RuntimeError, match="Maximum number of intervals"):
            app.set_interval(lambda: None, 1.0)

    def test_clear_all_intervals(self) -> None:
        """Test _clear_all_intervals stops all intervals."""
        app = App()
        
        # Create some intervals
        ids = [app.set_interval(lambda: None, 1.0) for _ in range(3)]
        
        app._clear_all_intervals()
        
        # All should be cleared
        for interval_id in ids:
            assert app.clear_interval(interval_id) is False


class TestAppStore:
    """Tests for App store integration."""

    def test_set_store_attaches_store(self) -> None:
        """Test set_store attaches store."""
        app = App()
        store = create_store(lambda state, action: state or {}, {"count": 0})
        
        app.set_store(store)
        
        assert app.store is not None
        assert app.store.get_state()["count"] == 0

    def test_set_store_detach(self) -> None:
        """Test set_store(None) detaches store."""
        app = App()
        store = create_store(lambda state, action: state or {}, {})
        app.set_store(store)
        
        app.set_store(None)
        
        assert app.store is None

    def test_dispatch_without_store_raises(self) -> None:
        """Test dispatch raises without store."""
        app = App()
        
        with pytest.raises(RuntimeError, match="No store attached"):
            app.dispatch({"type": "test"})

    def test_dispatch_with_store(self) -> None:
        """Test dispatch works with store."""
        app = App()
        
        def reducer(state: Dict[str, Any], action: Dict[str, Any]) -> Dict[str, Any]:
            if action["type"] == "inc":
                return {**state, "count": state.get("count", 0) + 1}
            return state or {}
        
        store = create_store(reducer, {"count": 0})
        app.set_store(store)
        
        app.dispatch({"type": "inc"})
        
        assert app.get_state()["count"] == 1  # type: ignore


class TestAppTheme:
    """Tests for App theme management."""

    def test_set_theme_valid(self) -> None:
        """Test setting a valid theme."""
        app = App()
        
        app.set_theme("solarized")
        
        assert app.theme == "solarized"

    def test_set_theme_invalid(self) -> None:
        """Test setting an invalid theme raises."""
        app = App()
        
        with pytest.raises(ValueError, match="Unknown theme"):
            app.set_theme("nonexistent")

    def test_reload_stylesheet(self) -> None:
        """Test reload_stylesheet updates stylesheet."""
        app = App()
        original_stylesheet = app.stylesheet
        
        app.reload_stylesheet()
        
        assert app.stylesheet is not None
        assert app.stylesheet is not original_stylesheet or app.stylesheet == original_stylesheet


class TestAppHelpers:
    """Tests for App helper methods."""

    def test_show_toast(self) -> None:
        """Test show_toast adds toast."""
        app = App()
        
        app.show_toast("Test message", level="info", duration=2.0)
        
        history = app.get_notification_history()
        assert len(history) > 0

    def test_set_banner(self) -> None:
        """Test set_banner updates banner."""
        app = App()
        
        app.set_banner("Test banner", level="warn")
        
        assert app.banner_message == "Test banner"
        assert app.banner_level == "warn"

    def test_clear_banner(self) -> None:
        """Test clear_banner clears banner."""
        app = App()
        app.set_banner("Test")
        
        app.clear_banner()
        
        assert app.banner_message == ""

    def test_get_state_without_store(self) -> None:
        """Test get_state returns None without store."""
        app = App()
        
        result = app.get_state()
        
        assert result is None


class TestAppEventHandling:
    """Tests for App event handling."""

    def test_handle_resize_default(self) -> None:
        """Test handle_resize does nothing by default."""
        app = App()
        
        # Should not raise
        app.handle_resize(ResizeEvent(80, 24))

    def test_handle_input_f2_toggles_studio(self) -> None:
        """Test handle_input F2 toggles studio mode."""
        app = App()
        app._studio_visible = False
        
        event = KeyEvent(key=Keys.F2, is_printable=False)
        app.handle_input(event)
        
        assert app._studio_visible is True

    def test_handle_input_q_exits(self) -> None:
        """Test handle_input 'q' exits app."""
        app = App()
        app._running = True
        
        event = KeyEvent(key='q', is_printable=True)
        app.handle_input(event)
        
        assert app._running is False

    def test_handle_input_tab_focus(self) -> None:
        """Test handle_input Tab triggers focus_next."""
        app = App()
        
        with patch.object(app, 'focus_next') as mock_focus:
            event = KeyEvent(key='\t', is_printable=False)
            app.handle_input(event)
            
            mock_focus.assert_called_once_with(reverse=False)


class TestAppErrorHandling:
    """Tests for App error handling."""

    def test_on_error_debug_mode(self) -> None:
        """Test on_error captures error in debug mode."""
        class DebugApp(App):
            debug = True
        
        app = DebugApp()
        
        error = ValueError("test error")
        app.on_error(error, "test_context")
        
        assert len(app._last_error_lines) > 0
        assert "test_context" in app._last_error_lines[0]

    def test_on_error_non_debug_mode(self) -> None:
        """Test on_error logs error in non-debug mode."""
        app = App()
        app.debug = False
        
        # Should not raise or store error
        app.on_error(ValueError("test"), "test")
        
        assert len(app._last_error_lines) == 0


class TestAppLayout:
    """Tests for App layout and rendering."""

    def test_build_ui_default(self) -> None:
        """Test build_ui returns None by default."""
        app = App()
        
        result = app.build_ui()
        
        assert result is None

    def test_render_without_root(self) -> None:
        """Test render works without root widget."""
        app = App()
        app.root = None
        
        # Should not raise
        app.render()

    def test_request_render(self) -> None:
        """Test request_render sets flag."""
        app = App()
        app._needs_render = False
        
        app.request_render()
        
        assert app._needs_render is True
