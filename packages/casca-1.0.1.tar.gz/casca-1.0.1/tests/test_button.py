"""Tests for Button widget."""
import pytest
from casca.components.widgets.button import Button
from casca.core.events import KeyEvent, Keys, MouseEvent


class _FakeApp:
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None
    def write(self, text): self.writes.append(text)
    def draw_text(self, x, y, text, **kwargs): self.draw_calls.append((x, y, text))


class TestButtonInit:
    def test_init_with_label(self):
        btn = Button("Click")
        assert btn.label == "Click"
    
    def test_init_with_callback(self):
        called = []
        btn = Button("Click", on_click=lambda: called.append(True))
        assert btn.on_click is not None


class TestButtonLayout:
    def test_calculate_layout(self):
        btn = Button("Test")
        btn.resolve_styles({})
        w, h = btn.calculate_layout(100, 10)
        assert btn.width > 0
        assert btn.height > 0


class TestButtonRender:
    def test_render_content(self):
        btn = Button("Test")
        btn.resolve_styles({})
        btn.calculate_layout(100, 10)
        btn.x = 0
        btn.y = 0
        app = _FakeApp()
        btn.render_content(app)
        assert len(app.draw_calls) > 0


class TestButtonMouse:
    def test_handle_mouse_click(self):
        called = []
        btn = Button("Test", on_click=lambda: called.append(True))
        btn.resolve_styles({})
        btn.calculate_layout(100, 10)
        btn.x = 0
        btn.y = 0
        btn.width = 10
        btn.height = 3
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        btn.handle_mouse(event, app)
        assert len(called) == 1
    
    def test_handle_mouse_disabled(self):
        called = []
        btn = Button("Test", on_click=lambda: called.append(True))
        btn.disabled = True
        btn.resolve_styles({})
        btn.calculate_layout(100, 10)
        btn.x = 0
        btn.y = 0
        btn.width = 10
        btn.height = 3
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=True)
        btn.handle_mouse(event, app)
        assert len(called) == 0


class TestButtonKeyboard:
    def test_handle_input_enter(self):
        called = []
        btn = Button("Test", on_click=lambda: called.append(True))
        btn.resolve_styles({})
        event = KeyEvent(key=Keys.ENTER, is_printable=False)
        btn.handle_input(event)
        assert len(called) == 1
    
    def test_handle_input_space(self):
        called = []
        btn = Button("Test", on_click=lambda: called.append(True))
        btn.resolve_styles({})
        event = KeyEvent(key=Keys.SPACE, is_printable=False)
        btn.handle_input(event)
        assert len(called) == 1
