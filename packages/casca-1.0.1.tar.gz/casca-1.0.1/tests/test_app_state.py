"""Tests for App.set_state helper."""

import threading
import time

from casca import App


def test_set_state_updates_fields_and_invalidates():
    app = App()
    app.root = object()

    app.set_state(count=1, message="ok")

    assert app.count == 1
    assert app.message == "ok"
    assert app.root is None


def test_set_state_can_skip_rerender():
    app = App()
    marker = object()
    app.root = marker

    app.set_state(rerender=False, count=2)

    assert app.count == 2
    assert app.root is marker


def test_run_task_invokes_on_done_on_main_thread_queue():
    app = App()
    done = {}

    def work():
        return 42

    def on_done(result, error):
        done["result"] = result
        done["error"] = error

    app.run_task(work, on_done=on_done)

    # Wait until worker enqueues callback.
    for _ in range(50):
        app._drain_main_thread_callbacks()
        if "result" in done:
            break
        time.sleep(0.01)

    assert done["result"] == 42
    assert done["error"] is None


def test_set_interval_and_clear_interval():
    app = App()
    tick_count = {"count": 0}
    seen = threading.Event()

    def tick():
        tick_count["count"] += 1
        if tick_count["count"] >= 2:
            seen.set()

    interval_id = app.set_interval(tick, 0.01)

    for _ in range(100):
        app._drain_main_thread_callbacks()
        if seen.is_set():
            break
        time.sleep(0.005)

    assert tick_count["count"] >= 2
    assert app.clear_interval(interval_id) is True
    assert app.clear_interval(interval_id) is False
