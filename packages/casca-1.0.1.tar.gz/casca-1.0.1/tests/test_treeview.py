"""Tests for TreeView widget behavior."""

from casca import KeyEvent, TreeView
from casca.core.events import Keys


def _tree():
    tree = TreeView(
        [
            {"label": "root", "children": [{"label": "child1"}, {"label": "child2"}]},
            {"label": "other"},
        ],
        height=6,
    )
    tree.resolve_styles({})
    tree.calculate_layout(40, 10)
    return tree


def test_treeview_expands_on_right_key():
    tree = _tree()

    handled = tree.handle_input(KeyEvent(key=Keys.RIGHT, is_printable=False))

    assert handled is True
    assert len(tree.flat_nodes) > 2


def test_treeview_selection_moves_with_down_key():
    tree = _tree()
    tree.handle_input(KeyEvent(key=Keys.RIGHT, is_printable=False))

    tree.handle_input(KeyEvent(key=Keys.DOWN, is_printable=False))

    assert tree.selected_index == 1
