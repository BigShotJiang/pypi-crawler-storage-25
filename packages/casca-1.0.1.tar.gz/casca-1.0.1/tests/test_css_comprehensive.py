"""
Tests for Casca CSS Parser.

Comprehensive tests for CSS parsing, validation, and style resolution.
"""

import pytest
import tempfile
from pathlib import Path
from typing import Any, Dict

from casca.style.css import (
    parse_css,
    load_css_file,
    get_style_for_node,
    get_border_width,
    parse_size,
    clamp_dimension,
    get_box_spacing,
    validate_stylesheet,
    MAX_CSS_FILE_SIZE,
)


class TestParseCSS:
    """Tests for parse_css function."""

    def test_parse_empty_css(self) -> None:
        """Test parsing empty CSS string."""
        result = parse_css("")
        assert result == {}

    def test_parse_single_rule(self) -> None:
        """Test parsing a single CSS rule."""
        css = "#root { color: red; }"
        result = parse_css(css)
        
        assert "#root" in result
        assert result["#root"]["color"] == "red"

    def test_parse_multiple_rules(self) -> None:
        """Test parsing multiple CSS rules."""
        css = """
        #root { color: red; }
        .btn { padding: 1; }
        """
        result = parse_css(css)
        
        assert "#root" in result
        assert ".btn" in result
        assert result["#root"]["color"] == "red"
        assert result[".btn"]["padding"] == "1"

    def test_parse_multiple_selectors(self) -> None:
        """Test parsing comma-separated selectors."""
        css = ".btn, .link { color: blue; }"
        result = parse_css(css)
        
        assert ".btn" in result
        assert ".link" in result
        assert result[".btn"]["color"] == "blue"
        assert result[".link"]["color"] == "blue"

    def test_parse_multiple_properties(self) -> None:
        """Test parsing multiple properties in one rule."""
        css = "#root { color: red; background: blue; padding: 1; }"
        result = parse_css(css)
        
        assert result["#root"]["color"] == "red"
        assert result["#root"]["background"] == "blue"
        assert result["#root"]["padding"] == "1"

    def test_parse_shorthand_padding_four(self) -> None:
        """Test parsing 4-value padding shorthand."""
        css = "#root { padding: 1 2 3 4; }"
        result = parse_css(css)
        
        assert result["#root"]["padding-top"] == "1"
        assert result["#root"]["padding-right"] == "2"
        assert result["#root"]["padding-bottom"] == "3"
        assert result["#root"]["padding-left"] == "4"

    def test_parse_shorthand_padding_three(self) -> None:
        """Test parsing 3-value padding shorthand."""
        css = "#root { padding: 1 2 3; }"
        result = parse_css(css)
        
        assert result["#root"]["padding-top"] == "1"
        assert result["#root"]["padding-right"] == "2"
        assert result["#root"]["padding-left"] == "2"
        assert result["#root"]["padding-bottom"] == "3"

    def test_parse_shorthand_padding_two(self) -> None:
        """Test parsing 2-value padding shorthand."""
        css = "#root { padding: 1 2; }"
        result = parse_css(css)
        
        assert result["#root"]["padding-top"] == "1"
        assert result["#root"]["padding-bottom"] == "1"
        assert result["#root"]["padding-right"] == "2"
        assert result["#root"]["padding-left"] == "2"

    def test_parse_comments_removed(self) -> None:
        """Test that CSS comments are removed."""
        css = """
        /* This is a comment */
        #root { color: red; }
        /* Another comment */
        """
        result = parse_css(css)
        
        assert "#root" in result
        assert "comment" not in str(result)

    def test_parse_multiline(self) -> None:
        """Test parsing multiline CSS."""
        css = """
        #root {
            color: red;
            background: blue;
            padding: 1;
        }
        """
        result = parse_css(css)
        
        assert result["#root"]["color"] == "red"
        assert result["#root"]["background"] == "blue"
        assert result["#root"]["padding"] == "1"

    def test_parse_tag_selector(self) -> None:
        """Test parsing tag selector."""
        css = "button { color: green; }"
        result = parse_css(css)
        
        assert "button" in result
        assert result["button"]["color"] == "green"


class TestLoadCSSFile:
    """Tests for load_css_file function."""

    def test_load_css_file_exists(self) -> None:
        """Test loading existing CSS file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.css', delete=False) as f:
            f.write("#root { color: red; }")
            f.flush()
            
            result = load_css_file(f.name)
            assert result == "#root { color: red; }"

    def test_load_css_file_not_found(self) -> None:
        """Test loading non-existent file raises."""
        with pytest.raises(FileNotFoundError):
            load_css_file("/nonexistent/path.css")

    def test_load_css_file_too_large(self) -> None:
        """Test loading file larger than limit raises."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.css', delete=False) as f:
            # Write more than MAX_CSS_FILE_SIZE bytes
            f.write("#root { color: red; } " * (MAX_CSS_FILE_SIZE // 20 + 1))
            f.flush()
            
            with pytest.raises(ValueError, match="too large"):
                load_css_file(f.name)

    def test_load_css_file_not_a_file(self) -> None:
        """Test loading directory path raises."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(ValueError, match="not a file"):
                load_css_file(tmpdir)


class TestGetStyleForNode:
    """Tests for get_style_for_node function."""

    def test_style_specificity_tag(self) -> None:
        """Test tag selector has lowest specificity."""
        stylesheet = {
            "button": {"color": "red"},
        }
        result = get_style_for_node("", [], "button", stylesheet)
        
        assert result["color"] == "red"

    def test_style_specificity_class(self) -> None:
        """Test class selector overrides tag."""
        stylesheet = {
            "button": {"color": "red"},
            ".btn": {"color": "blue"},
        }
        result = get_style_for_node("", ["btn"], "button", stylesheet)
        
        assert result["color"] == "blue"

    def test_style_specificity_id(self) -> None:
        """Test ID selector has highest specificity."""
        stylesheet = {
            "button": {"color": "red"},
            ".btn": {"color": "blue"},
            "#submit": {"color": "green"},
        }
        result = get_style_for_node("submit", ["btn"], "button", stylesheet)
        
        assert result["color"] == "green"

    def test_style_merges_properties(self) -> None:
        """Test styles merge correctly."""
        stylesheet = {
            "button": {"color": "red", "padding": "1"},
            ".btn": {"background": "blue"},
        }
        result = get_style_for_node("", ["btn"], "button", stylesheet)
        
        assert result["color"] == "red"
        assert result["padding"] == "1"
        assert result["background"] == "blue"

    def test_style_empty_node(self) -> None:
        """Test styling node with no ID or classes."""
        stylesheet = {"widget": {"color": "red"}}
        result = get_style_for_node("", [], "widget", stylesheet)
        
        assert result["color"] == "red"


class TestGetBorderWidth:
    """Tests for get_border_width function."""

    def test_border_width_none(self) -> None:
        """Test border width is 0 when none."""
        assert get_border_width({"border": "none"}) == 0

    def test_border_width_missing(self) -> None:
        """Test border width is 0 when missing."""
        assert get_border_width({}) == 0

    def test_border_width_present(self) -> None:
        """Test border width is 1 when present."""
        assert get_border_width({"border": "solid"}) == 1
        assert get_border_width({"border": "rounded"}) == 1

    def test_border_width_empty_string(self) -> None:
        """Test border width is 0 for empty string."""
        assert get_border_width({"border": ""}) == 0


class TestParseSize:
    """Tests for parse_size function."""

    def test_parse_size_int(self) -> None:
        """Test parsing integer value."""
        assert parse_size(10, 100) == 10

    def test_parse_size_percentage(self) -> None:
        """Test parsing percentage value."""
        assert parse_size("50%", 100) == 50

    def test_parse_size_none(self) -> None:
        """Test parsing None returns fallback."""
        assert parse_size(None, 100, fallback=5) == 5

    def test_parse_size_invalid(self) -> None:
        """Test parsing invalid returns fallback."""
        assert parse_size("invalid", 100, fallback=5) == 5

    def test_parse_size_percentage_invalid(self) -> None:
        """Test parsing invalid percentage returns fallback."""
        assert parse_size("abc%", 100, fallback=5) == 5


class TestClampDimension:
    """Tests for clamp_dimension function."""

    def test_clamp_no_constraints(self) -> None:
        """Test dimension without constraints."""
        result = clamp_dimension(50, {}, "width", 100, 10)
        assert result == 50

    def test_clamp_min_constraint(self) -> None:
        """Test dimension with min constraint."""
        style = {"min-width": "30"}
        result = clamp_dimension(20, style, "width", 100, 10)
        assert result == 30

    def test_clamp_max_constraint(self) -> None:
        """Test dimension with max constraint."""
        style = {"max-width": "80"}
        result = clamp_dimension(100, style, "width", 100, 10)
        assert result == 80

    def test_clamp_min_and_max(self) -> None:
        """Test dimension with both constraints."""
        style = {"min-width": "30", "max-width": "70"}
        result = clamp_dimension(20, style, "width", 100, 10)
        assert result == 30
        
        result = clamp_dimension(80, style, "width", 100, 10)
        assert result == 70


class TestGetBoxSpacing:
    """Tests for get_box_spacing function."""

    def test_get_box_spacing_base(self) -> None:
        """Test spacing with base value only."""
        style = {"padding": "1"}
        result = get_box_spacing(style, "padding")
        assert result == (1, 1, 1, 1)

    def test_get_box_spacing_expanded(self) -> None:
        """Test spacing with expanded values."""
        style = {
            "padding": "1",
            "padding-top": "2",
            "padding-right": "3",
            "padding-bottom": "4",
            "padding-left": "5",
        }
        result = get_box_spacing(style, "padding")
        assert result == (2, 3, 4, 5)

    def test_get_box_spacing_missing(self) -> None:
        """Test spacing with missing key."""
        result = get_box_spacing({}, "padding")
        assert result == (0, 0, 0, 0)


class TestValidateStylesheet:
    """Tests for validate_stylesheet function."""

    def test_validate_empty_stylesheet(self) -> None:
        """Test validating empty stylesheet."""
        result = validate_stylesheet({})
        assert result == []

    def test_validate_valid_stylesheet(self) -> None:
        """Test validating valid stylesheet."""
        stylesheet = {
            "#root": {"color": "red", "padding": "1"},
        }
        result = validate_stylesheet(stylesheet)
        assert result == []

    def test_validate_unknown_key(self) -> None:
        """Test validating unknown style key."""
        stylesheet = {
            "#root": {"invalid-key": "value"},
        }
        result = validate_stylesheet(stylesheet)
        
        assert len(result) > 0
        assert "Unknown style key" in result[0]

    def test_validate_invalid_color(self) -> None:
        """Test validating invalid color."""
        stylesheet = {
            "#root": {"color": "notacolor"},
        }
        result = validate_stylesheet(stylesheet)
        
        assert len(result) > 0
        assert "invalid color" in result[0]

    def test_validate_negative_dimension(self) -> None:
        """Test validating negative dimension."""
        stylesheet = {
            "#root": {"width": "-10"},
        }
        result = validate_stylesheet(stylesheet)
        
        assert len(result) > 0
        assert "Negative" in result[0]

    def test_validate_invalid_overflow(self) -> None:
        """Test validating invalid overflow value."""
        stylesheet = {
            "#root": {"overflow-x": "invalid"},
        }
        result = validate_stylesheet(stylesheet)
        
        assert len(result) > 0
        assert "Invalid overflow" in result[0]


class TestColorValidation:
    """Tests for color validation."""

    def test_valid_named_colors(self) -> None:
        """Test valid named colors pass validation."""
        stylesheet = {"#root": {"color": "red"}}
        result = validate_stylesheet(stylesheet)
        assert "invalid color" not in str(result)

    def test_valid_hex_color(self) -> None:
        """Test valid hex color passes validation."""
        stylesheet = {"#root": {"color": "#ff0000"}}
        result = validate_stylesheet(stylesheet)
        assert "invalid color" not in str(result)

    def test_valid_rgb_color(self) -> None:
        """Test valid RGB color passes validation."""
        stylesheet = {"#root": {"color": "rgb(255, 0, 0)"}}
        result = validate_stylesheet(stylesheet)
        assert "invalid color" not in str(result)

    def test_valid_ansi_color(self) -> None:
        """Test valid ANSI color passes validation."""
        stylesheet = {"#root": {"color": "ansi(196)"}}
        result = validate_stylesheet(stylesheet)
        assert "invalid color" not in str(result)
