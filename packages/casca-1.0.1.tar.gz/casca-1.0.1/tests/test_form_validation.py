"""Validation hook tests for form widgets."""

from casca import Checkbox, Input, Select, TextArea


def test_input_validation_sets_error_message():
    inp = Input(validator=lambda v: "required" if not v else None)
    inp.validate("")

    assert inp.invalid is True
    assert inp.error_message == "required"


def test_textarea_validation_clears_after_valid_value():
    ta = TextArea(validator=lambda v: "short" if len(v or "") < 3 else None)

    ta.validate("ab")
    assert ta.invalid is True

    ta.set_value("abcd")
    assert ta.invalid is False
    assert ta.error_message == ""


def test_select_validation_runs_on_change_event():
    sel = Select(["A", "B"], validator=lambda v: "pick B" if v != "B" else None)

    sel.selected_index = 0
    sel._emit_change()
    assert sel.invalid is True

    sel.selected_index = 1
    sel._emit_change()
    assert sel.invalid is False


def test_checkbox_validation_marks_invalid_until_checked():
    cb = Checkbox("Agree", checked=False, validator=lambda v: "required" if not v else None)

    cb.validate(cb.checked)
    assert cb.invalid is True

    cb.set_checked(True)
    assert cb.invalid is False
