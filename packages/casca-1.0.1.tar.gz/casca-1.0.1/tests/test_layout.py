"""Layout behavior tests for containers and basic widgets."""

from casca import Container, Label


def _resolve_and_layout(widget, width=80, height=24):
    widget.resolve_styles({})
    return widget.calculate_layout(width, height)


def test_padding_offsets_child_position_in_column_layout():
    child = Label("A")
    root = Container(child, style={"padding": 2})

    _resolve_and_layout(root)

    assert child.x == root.x + 2
    assert child.y == root.y + 2


def test_row_layout_places_children_horizontally():
    left = Label("left")
    right = Label("right")
    root = Container(left, right, style={"flex-direction": "row", "padding": 1})

    _resolve_and_layout(root)

    assert right.x > left.x
    assert right.y == left.y


def test_margin_increases_reported_footprint():
    no_margin = Container(Label("x"), style={"padding": 1})
    with_margin = Container(Label("x"), style={"padding": 1, "margin": 2})

    w1, h1 = _resolve_and_layout(no_margin)
    w2, h2 = _resolve_and_layout(with_margin)

    assert w2 == w1 + 4
    assert h2 == h1 + 4


def test_border_none_does_not_increase_inner_offset():
    child = Label("X")
    root = Container(child, style={"padding": 1, "border": "none"})

    _resolve_and_layout(root)

    assert child.x == root.x + 1
    assert child.y == root.y + 1


def test_per_side_padding_offsets_children():
    child = Label("X")
    root = Container(
        child,
        style={"padding-top": 3, "padding-left": 2, "padding-right": 1, "padding-bottom": 1},
    )

    _resolve_and_layout(root)

    assert child.x == root.x + 2
    assert child.y == root.y + 3


def test_per_side_margin_changes_reported_size():
    base = Container(Label("x"), style={"padding": 1})
    sided = Container(Label("x"), style={"padding": 1, "margin-left": 2, "margin-right": 3, "margin-top": 1, "margin-bottom": 4})

    w1, h1 = _resolve_and_layout(base)
    w2, h2 = _resolve_and_layout(sided)

    assert w2 == w1 + 5
    assert h2 == h1 + 5


def test_row_flex_grow_distributes_free_space():
    left = Container(Label("L"), style={"flex-grow": 1, "flex-basis": 10, "height": 1})
    right = Container(Label("R"), style={"flex-grow": 1, "flex-basis": 10, "height": 1})
    root = Container(
        left,
        right,
        style={"width": 40, "padding": 0, "flex-direction": "row"},
    )

    _resolve_and_layout(root, width=40, height=10)

    assert left.width == 20
    assert right.width == 20
    assert right.x == left.x + left.width


def test_row_gap_adds_spacing_between_children():
    one = Label("A")
    two = Label("B")
    root = Container(one, two, style={"width": 20, "flex-direction": "row", "gap": 3})

    _resolve_and_layout(root, width=20, height=10)

    assert two.x - (one.x + one.width) == 3


def test_justify_content_center_offsets_children_in_row():
    one = Label("AAA")
    two = Label("BBB")
    root = Container(
        one,
        two,
        style={"width": 20, "flex-direction": "row", "justify-content": "center"},
    )

    _resolve_and_layout(root, width=20, height=10)

    # 20 width, total child width is 6, so centered block starts at x=7 (0-based logical).
    assert one.x == 7


def test_align_items_center_in_row_changes_child_y():
    child = Label("X")
    root = Container(
        child,
        style={"width": 20, "height": 9, "flex-direction": "row", "align-items": "center"},
    )

    _resolve_and_layout(root, width=20, height=9)

    # Child height is 1, so centered y should be floor((9-1)/2) = 4.
    assert child.y == 4


def test_row_flex_shrink_reduces_children_when_overflowing():
    first = Container(Label("A"), style={"flex-basis": 8, "flex-shrink": 1, "height": 1})
    second = Container(Label("B"), style={"flex-basis": 8, "flex-shrink": 1, "height": 1})
    root = Container(
        first,
        second,
        style={"width": 10, "flex-direction": "row"},
    )

    _resolve_and_layout(root, width=10, height=10)

    assert first.width + second.width <= 10


def test_vertical_align_centers_children_in_row_without_align_items():
    child = Label("X")
    root = Container(
        child,
        style={"width": 20, "height": 9, "flex-direction": "row", "vertical-align": "center"},
    )

    _resolve_and_layout(root, width=20, height=9)

    assert child.y == 4


def test_vertical_align_centers_column_content_block():
    one = Label("A")
    two = Label("B")
    root = Container(
        one,
        two,
        style={"width": 10, "height": 10, "flex-direction": "column", "vertical-align": "center"},
    )

    _resolve_and_layout(root, width=10, height=10)

    assert one.y == 4
    assert two.y == 5
