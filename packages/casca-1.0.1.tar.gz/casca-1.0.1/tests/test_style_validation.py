"""Tests for stylesheet validation warnings."""

from casca.style.css import parse_css, validate_stylesheet


def test_validate_stylesheet_reports_unknown_key():
    sheet = parse_css(".box { made-up-key: 1; color: bright_green; }")
    warnings = validate_stylesheet(sheet)
    assert any("made-up-key" in warning for warning in warnings)


def test_validate_stylesheet_reports_invalid_color():
    sheet = parse_css(".box { color: not-a-real-color; }")
    warnings = validate_stylesheet(sheet)
    assert any("not-a-real-color" in warning for warning in warnings)


def test_validate_stylesheet_accepts_supported_colors():
    sheet = parse_css(".box { color: #00ff00; background: rgb(10,20,30); }")
    warnings = validate_stylesheet(sheet)
    assert warnings == []


def test_validate_stylesheet_reports_impossible_dimension_values():
    sheet = parse_css(".box { width: 150%; height: -2; gap: nope; }")
    warnings = validate_stylesheet(sheet)

    assert any("Possibly impossible size '150%'" in warning for warning in warnings)
    assert any("Negative value '-2'" in warning for warning in warnings)
    assert any("Invalid numeric value 'nope'" in warning for warning in warnings)


def test_validate_stylesheet_accepts_new_responsive_and_overflow_keys():
    sheet = parse_css(
        ".pane { min-width: 20; max-width: 120; min-height: 5; max-height: 40; overflow-x: auto; overflow-y: hidden; letter-spacing: 1; }"
    )
    warnings = validate_stylesheet(sheet)
    assert warnings == []


def test_validate_stylesheet_reports_invalid_overflow_value():
    sheet = parse_css(".pane { overflow-x: sideways; }")
    warnings = validate_stylesheet(sheet)
    assert any("Invalid overflow value 'sideways'" in warning for warning in warnings)
