"""Tests for toast and banner notification helpers."""

from casca import App, ToastManager


class FakeApp(App):
    def build_ui(self):
        return None


def test_toast_manager_auto_dismisses_by_duration():
    mgr = ToastManager()
    mgr.push("hello", duration=1.0, now=10.0)

    assert len(mgr.active(now=10.5)) == 1
    assert len(mgr.active(now=11.1)) == 0


def test_app_banner_helpers_set_and_clear_message():
    app = FakeApp()

    app.set_banner("Working", level="info")
    assert app.banner_message == "Working"
    assert app.banner_level == "info"

    app.clear_banner()
    assert app.banner_message == ""


def test_app_show_toast_pushes_into_manager():
    app = FakeApp()
    app.show_toast("Saved", level="success", duration=3.0)

    active = app.toast_manager.active()
    assert len(active) == 1
    assert active[0].message == "Saved"
    assert active[0].level == "success"


def test_toast_history_tracks_previous_messages():
    mgr = ToastManager()
    mgr.push("one", level="info", duration=0.1, now=0.0)
    mgr.push("two", level="warn", duration=0.1, now=0.0)

    history = mgr.history()
    assert len(history) == 2
    assert history[-1].message == "two"


def test_app_notification_history_helpers():
    app = FakeApp()
    app.show_toast("A", level="info", duration=0.2)
    app.show_toast("B", level="warn", duration=0.2)

    history = app.get_notification_history()
    assert [h.message for h in history][-2:] == ["A", "B"]

    app.clear_notification_history()
    assert app.get_notification_history() == []
