"""Tests for Slider widget."""

import pytest
from casca.components.widgets.slider import Slider
from casca.core.events import KeyEvent, Keys, MouseEvent


class _FakeApp:
    """Fake app for testing."""
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None
        self._running = True
        
    def write(self, text):
        self.writes.append(text)
    
    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))
    
    def request_render(self):
        pass


class TestSliderInit:
    """Test Slider initialization."""
    
    def test_init_default_values(self):
        """Test Slider with default values."""
        slider = Slider()
        
        assert slider.min == 0
        assert slider.max == 100
        assert slider.value == 0  # defaults to min
        assert slider.step == 1
        assert slider.orientation == "horizontal"
    
    def test_init_custom_values(self):
        """Test Slider with custom values."""
        slider = Slider(
            min=10,
            max=50,
            value=30,
            step=0.5,
            orientation="vertical"
        )
        
        assert slider.min == 10
        assert slider.max == 50
        assert slider.value == 30
        assert slider.step == 0.5
        assert slider.orientation == "vertical"
    
    def test_init_with_callback(self):
        """Test Slider with on_change callback."""
        callback_values = []
        
        def callback(value):
            callback_values.append(value)
        
        slider = Slider(on_change=callback)
        slider._set_value(50)
        
        assert 50 in callback_values


class TestSliderNormalizedValue:
    """Test normalized value property."""
    
    def test_normalized_value_at_min(self):
        """Test normalized value at minimum."""
        slider = Slider(min=0, max=100, value=0)
        
        assert slider.normalized_value == 0.0
    
    def test_normalized_value_at_max(self):
        """Test normalized value at maximum."""
        slider = Slider(min=0, max=100, value=100)
        
        assert slider.normalized_value == 1.0
    
    def test_normalized_value_at_middle(self):
        """Test normalized value at middle."""
        slider = Slider(min=0, max=100, value=50)
        
        assert slider.normalized_value == 0.5
    
    def test_normalized_value_custom_range(self):
        """Test normalized value with custom range."""
        slider = Slider(min=10, max=20, value=15)
        
        assert slider.normalized_value == 0.5
    
    def test_normalized_value_zero_range(self):
        """Test normalized value with zero range."""
        slider = Slider(min=50, max=50, value=50)
        
        assert slider.normalized_value == 0.0


class TestSliderLayout:
    """Test Slider layout calculation."""
    
    def test_calculate_layout_horizontal(self):
        """Test horizontal slider layout."""
        slider = Slider(orientation="horizontal")
        slider.resolve_styles({})
        
        width, height = slider.calculate_layout(100, 10)
        
        assert slider.width >= 10
        assert slider.height >= 3
    
    def test_calculate_layout_vertical(self):
        """Test vertical slider layout."""
        slider = Slider(orientation="vertical")
        slider.resolve_styles({})
        
        width, height = slider.calculate_layout(10, 100)
        
        assert slider.height >= 10
        assert slider.width >= 3


class TestSliderRender:
    """Test Slider rendering."""
    
    def test_render_horizontal(self):
        """Test rendering horizontal slider."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        
        app = _FakeApp()
        slider.render_content(app)
        
        # Should have drawn track and thumb
        assert len(app.draw_calls) > 0
    
    def test_render_vertical(self):
        """Test rendering vertical slider."""
        slider = Slider(min=0, max=100, value=50, orientation="vertical")
        slider.resolve_styles({})
        slider.calculate_layout(10, 100)
        slider.x = 0
        slider.y = 0
        
        app = _FakeApp()
        slider.render_content(app)
        
        # Should have drawn track and thumb
        assert len(app.draw_calls) > 0


class TestSliderValueFromPosition:
    """Test value calculation from position."""
    
    def test_value_from_position_horizontal(self):
        """Test value from horizontal position."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        # Middle position should give middle value
        value = slider._value_from_position(50, 2)
        
        assert 40 <= value <= 60  # Allow some tolerance
    
    def test_value_from_position_vertical(self):
        """Test value from vertical position."""
        slider = Slider(min=0, max=100, value=50, orientation="vertical")
        slider.resolve_styles({})
        slider.calculate_layout(10, 100)
        slider.x = 0
        slider.y = 0
        slider.width = 5
        slider.height = 100
        
        # Middle position should give middle value
        value = slider._value_from_position(2, 50)
        
        assert 40 <= value <= 60  # Allow some tolerance
    
    def test_value_from_position_with_step(self):
        """Test value snaps to step."""
        slider = Slider(min=0, max=100, value=50, step=10, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        value = slider._value_from_position(25, 2)
        
        # Should snap to nearest 10
        assert value % 10 == 0 or abs(value % 10 - 10) < 0.1
    
    def test_value_from_position_clamped(self):
        """Test value is clamped to range."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        # Position beyond bounds
        value1 = slider._value_from_position(-50, 2)
        value2 = slider._value_from_position(200, 2)
        
        assert 0 <= value1 <= 100
        assert 0 <= value2 <= 100


class TestSliderSetValue:
    """Test setting slider value."""
    
    def test_set_value_triggers_callback(self):
        """Test that setting value triggers callback."""
        callback_values = []
        
        def callback(value):
            callback_values.append(value)
        
        slider = Slider(on_change=callback)
        slider._set_value(50)
        
        assert 50 in callback_values
    
    def test_set_value_no_callback(self):
        """Test setting value without callback."""
        slider = Slider()
        
        # Should not raise
        slider._set_value(50)
        assert slider.value == 50
    
    def test_set_value_unchanged(self):
        """Test setting same value doesn't trigger callback."""
        callback_count = [0]
        
        def callback(value):
            callback_count[0] += 1
        
        slider = Slider(value=50, on_change=callback)
        slider._set_value(50)
        
        assert callback_count[0] == 0


class TestSliderMouse:
    """Test Slider mouse handling."""
    
    def test_handle_mouse_press(self):
        """Test mouse press starts dragging."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        app = _FakeApp()
        event = MouseEvent(x=25, y=2, button=0, pressed=True)
        result = slider.handle_mouse(event, app)
        
        assert result is True
        assert slider._dragging is True
    
    def test_handle_mouse_drag(self):
        """Test mouse drag updates value."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        app = _FakeApp()
        
        # Press to start dragging
        press_event = MouseEvent(x=50, y=2, button=0, pressed=True)
        slider.handle_mouse(press_event, app)
        
        # Release to end dragging
        release_event = MouseEvent(x=75, y=2, button=0, pressed=False)
        slider.handle_mouse(release_event, app)
        
        # Value should have changed
        assert slider.value != 50
    
    def test_handle_mouse_outside_bounds(self):
        """Test mouse outside bounds returns False."""
        slider = Slider(min=0, max=100, value=50, orientation="horizontal")
        slider.resolve_styles({})
        slider.calculate_layout(100, 10)
        slider.x = 0
        slider.y = 0
        slider.width = 100
        slider.height = 5
        
        app = _FakeApp()
        event = MouseEvent(x=200, y=200, button=0, pressed=True)
        result = slider.handle_mouse(event, app)
        
        assert result is False


class TestSliderKeyboard:
    """Test Slider keyboard handling."""
    
    def test_handle_input_left_decreases(self):
        """Test left arrow decreases value."""
        slider = Slider(min=0, max=100, value=50, step=1)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.LEFT, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 49
    
    def test_handle_input_right_increases(self):
        """Test right arrow increases value."""
        slider = Slider(min=0, max=100, value=50, step=1)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.RIGHT, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 51
    
    def test_handle_input_down_decreases(self):
        """Test down arrow decreases value."""
        slider = Slider(min=0, max=100, value=50, step=1)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.DOWN, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 49
    
    def test_handle_input_up_increases(self):
        """Test up arrow increases value."""
        slider = Slider(min=0, max=100, value=50, step=1)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.UP, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 51
    
    def test_handle_input_home(self):
        """Test Home key sets to minimum."""
        slider = Slider(min=0, max=100, value=50)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.HOME, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 0
    
    def test_handle_input_end(self):
        """Test End key sets to maximum."""
        slider = Slider(min=0, max=100, value=50)
        slider.resolve_styles({})
        
        event = KeyEvent(key=Keys.END, is_printable=False)
        slider.handle_input(event)
        
        assert slider.value == 100
    
    def test_handle_input_disabled(self):
        """Test disabled slider doesn't respond to keyboard."""
        slider = Slider(min=0, max=100, value=50)
        slider.disabled = True
        
        event = KeyEvent(key=Keys.RIGHT, is_printable=False)
        result = slider.handle_input(event)
        
        assert result is False
        assert slider.value == 50


class TestSliderAPI:
    """Test Slider public API methods."""
    
    def test_set_value(self):
        """Test set_value method."""
        slider = Slider(min=0, max=100, value=50)
        
        slider.set_value(75)
        
        assert slider.value == 75
    
    def test_set_value_clamped(self):
        """Test set_value clamps to range."""
        slider = Slider(min=0, max=100, value=50)
        
        slider.set_value(150)
        assert slider.value == 100
        
        slider.set_value(-50)
        assert slider.value == 0
    
    def test_set_range(self):
        """Test set_range method."""
        slider = Slider(min=0, max=100, value=50)
        
        slider.set_range(10, 90)
        
        assert slider.min == 10
        assert slider.max == 90
        assert slider.value == 50  # Value unchanged if in range
    
    def test_set_range_clamps_value(self):
        """Test set_range clamps current value."""
        slider = Slider(min=0, max=100, value=80)
        
        slider.set_range(0, 50)
        
        assert slider.value == 50  # Clamped to new max
