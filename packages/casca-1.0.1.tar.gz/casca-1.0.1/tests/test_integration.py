"""Integration tests for Casca."""
import pytest
from casca import Container, Label, run_app
from casca.core.app import App
from casca.core.events import KeyEvent, Keys, MouseEvent
from casca.components.widgets.menu import Menu, MenuItem
from casca.components.widgets.slider import Slider
from casca.components.widgets.tooltip import Tooltip
from casca.components.navigation.virtual_scroll import VirtualScrollView
from casca.components.widgets.grid import Grid
from casca.core.accessibility import AccessibilityManager, FocusManager


class _FakeApp(App):
    """Fake app for integration testing."""
    def __init__(self):
        self._running = False
        self._last_size = (80, 24)
        self._needs_render = True
        self._output_buffer = []
        self._input_buffer = ""
        self._last_frame_output = ""
        self.root = None
        self.theme = "default"
        self.stylesheet = {}
        self.focused_widget = None
        self.focused_id = None
        self._last_error_lines = []
        self.toast_manager = None
        self.banner_message = ""
        self.banner_level = "info"
        self._main_thread_callbacks = None
        self._interval_lock = None
        self._intervals = {}
        self._next_interval_id = 1
        self._studio_visible = False
        self.store = None


class TestWidgetIntegration:
    """Test widgets working together."""
    
    def test_menu_with_container(self):
        """Test Menu inside Container."""
        menu = Menu(
            MenuItem("File"),
            MenuItem("Edit")
        )
        container = Container(menu, id="root")
        container.resolve_styles({})
        container.calculate_layout(80, 24)
        
        assert len(container.children) == 1
        assert menu.x >= 0
    
    def test_slider_with_label(self):
        """Test Slider with Label."""
        label = Label("Volume:")
        slider = Slider(min=0, max=100, value=50)
        container = Container(label, slider, id="root")
        container.resolve_styles({})
        container.calculate_layout(80, 24)
        
        assert len(container.children) == 2
    
    def test_grid_with_multiple_widgets(self):
        """Test Grid with various widgets."""
        grid = Grid(columns="1fr 1fr", rows="auto auto")
        grid.add(Label("A"), grid_column="1", grid_row="1")
        grid.add(Label("B"), grid_column="2", grid_row="1")
        grid.add(Slider(), grid_column="1 / span 2", grid_row="2")
        grid.resolve_styles({})
        grid.calculate_layout(80, 24)
        
        assert len(grid.children) == 3


class TestAccessibilityIntegration:
    """Test accessibility features integration."""
    
    def test_focus_manager_with_widgets(self):
        """Test FocusManager with widget focus order."""
        manager = FocusManager()
        manager.set_focus_order(["input1", "input2", "submit"])
        
        next_id = manager.get_next_focus_id(None)
        assert next_id == "input1"
        
        next_id = manager.get_next_focus_id("input1")
        assert next_id == "input2"
    
    def test_accessibility_manager_announcements(self):
        """Test AccessibilityManager with app."""
        manager = AccessibilityManager()
        manager.announce("Test message")
        
        announcements = manager.get_announcements()
        assert "Test message" in announcements


class TestVirtualScrollIntegration:
    """Test VirtualScrollView integration."""
    
    def test_virtual_scroll_with_container(self):
        """Test VirtualScrollView in Container."""
        def render_item(idx, app):
            pass
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=10
        )
        container = Container(scroll, id="root")
        container.resolve_styles({})
        container.calculate_layout(80, 24)
        
        assert len(container.children) == 1


class TestAppIntegration:
    """Test App integration."""
    
    def test_app_with_complex_ui(self):
        """Test App with complex UI tree."""
        app = _FakeApp()
        
        menu = Menu(MenuItem("File"), MenuItem("Edit"))
        content = Container(Label("Content"))
        root = Container(menu, content, id="root")
        
        app.root = root
        root.resolve_styles(app.stylesheet)
        root.calculate_layout(80, 24)
        
        assert app.root is root
        assert len(root.children) == 2
    
    def test_app_event_handling(self):
        """Test App event handling with widgets."""
        app = _FakeApp()
        
        clicked = []
        def on_click():
            clicked.append(True)
        
        button_container = Container(
            Label("Click me"),
            id="button"
        )
        app.root = button_container
        button_container.resolve_styles({})
        button_container.calculate_layout(80, 24)
        
        # Simulate key event
        event = KeyEvent(key="q", is_printable=True)
        # Should not crash
        app.handle_input(event)


class TestThemeIntegration:
    """Test theme integration."""
    
    def test_widget_with_theme_colors(self):
        """Test widgets with theme colors."""
        label = Label("Test", style={"color": "primary"})
        label.resolve_styles({
            "widget": {"color": "white"},
            ".primary": {"color": "blue"}
        })
        
        assert "color" in label.style


class TestLayoutIntegration:
    """Test layout integration."""
    
    def test_nested_containers(self):
        """Test nested Container layouts."""
        inner = Container(Label("Inner"), id="inner")
        outer = Container(inner, id="outer")
        outer.resolve_styles({})
        outer.calculate_layout(80, 24)
        
        assert inner.x >= outer.x
        assert inner.y >= outer.y
    
    def test_mixed_layout_widgets(self):
        """Test mixing different layout widgets."""
        grid = Grid(columns="1fr 1fr")
        grid.add(Label("A"))
        
        container = Container(grid, Slider(), id="root")
        container.resolve_styles({})
        container.calculate_layout(80, 24)
        
        assert len(container.children) == 2
