"""Tests for CommandPalette quick-action widget."""

from casca import CommandPalette
from casca.core.events import KeyEvent


def test_command_palette_toggle_and_filter():
    calls = {"count": 0}

    palette = CommandPalette(
        [
            {"label": "Refresh Metrics", "keywords": "metrics", "action": lambda: calls.__setitem__("count", calls["count"] + 1)},
            {"label": "Open Settings", "keywords": "settings", "action": lambda: None},
        ]
    )
    palette.resolve_styles({})

    # Ctrl+P opens
    assert palette.handle_input(KeyEvent(key="\x10", is_printable=False)) is True
    assert palette.is_open is True

    for ch in "met":
        palette.handle_input(KeyEvent(key=ch, is_printable=True))

    assert palette.results.items[0] == "Refresh Metrics"


def test_command_palette_executes_selected_command_on_enter():
    calls = {"count": 0}

    palette = CommandPalette(
        [{"label": "Run", "keywords": "", "action": lambda: calls.__setitem__("count", calls["count"] + 1)}]
    )
    palette.resolve_styles({})
    palette.open()

    handled = palette.handle_input(KeyEvent(key="\r", is_printable=False))

    assert handled is True
    assert calls["count"] == 1
    assert palette.is_open is False
