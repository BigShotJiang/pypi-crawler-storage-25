"""Tests for casca doctor CLI helpers."""

from casca.cli import collect_doctor_report, format_doctor_report


def test_collect_doctor_report_has_expected_fields():
    report = collect_doctor_report()

    assert report.python_version
    assert report.python_executable
    assert isinstance(report.stdin_tty, bool)
    assert isinstance(report.stdout_tty, bool)
    assert report.terminal_width > 0
    assert report.terminal_height > 0


def test_format_doctor_report_contains_sections():
    report = collect_doctor_report()
    text = format_doctor_report(report)

    assert "Casca Doctor" in text
    assert "python:" in text
    assert "terminal size:" in text
