"""Tests for App task running."""

import threading
from typing import Any, List

import pytest

from casca import App


class TestAppTaskRunning:
    """Tests for App run_task method."""

    def test_run_task_creates_thread(self) -> None:
        """Test run_task creates and starts a thread."""
        app = App()
        executed: List[int] = []

        def task_fn() -> int:
            executed.append(1)
            return 42

        thread = app.run_task(task_fn)

        assert isinstance(thread, threading.Thread)

        # Wait for completion
        thread.join(timeout=1.0)
        assert len(executed) > 0

    def test_run_task_with_on_done(self) -> None:
        """Test run_task schedules on_done callback."""
        app = App()
        callback_scheduled: List[bool] = []

        def task_fn() -> int:
            return 42

        def on_done(result: Any, error: Exception | None) -> None:
            # This gets queued to main thread, not executed immediately
            callback_scheduled.append(True)

        thread = app.run_task(task_fn, on_done=on_done)
        thread.join(timeout=1.0)

        # Thread completed, callback queued (would execute on _drain_main_thread_callbacks)
        assert not thread.is_alive()

    def test_run_task_handles_errors(self) -> None:
        """Test run_task handles errors gracefully."""
        app = App()

        def task_fn() -> None:
            raise ValueError("test error")

        # Should not raise, error goes to on_error
        thread = app.run_task(task_fn)
        thread.join(timeout=1.0)

        assert not thread.is_alive()

    def test_run_task_daemon_flag(self) -> None:
        """Test run_task respects daemon flag."""
        app = App()

        def task_fn() -> int:
            return 1

        thread = app.run_task(task_fn, daemon=True)
        assert thread.daemon is True

        thread2 = app.run_task(task_fn, daemon=False)
        assert thread2.daemon is False

    def test_run_task_custom_name(self) -> None:
        """Test run_task uses custom thread name."""
        app = App()

        def task_fn() -> None:
            pass

        thread = app.run_task(task_fn, name="my-task")
        assert thread.name == "my-task"
