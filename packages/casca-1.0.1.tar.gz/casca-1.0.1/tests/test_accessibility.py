"""Tests for accessibility module."""

import pytest
from casca.core.accessibility import (
    FocusManager,
    AccessibilityManager,
    get_accessibility,
    set_accessibility,
)
from casca.dom.node import Widget


class _FakeWidget(Widget):
    """Fake widget for testing."""
    tag = "fake"
    
    def __init__(self, id: str = ""):
        super().__init__(id=id)


class TestFocusManager:
    """Test FocusManager functionality."""
    
    def test_init(self):
        """Test FocusManager initialization."""
        manager = FocusManager()
        
        assert manager._focus_order == []
        assert manager._focus_trap is None
    
    def test_set_focus_order(self):
        """Test setting focus order."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2", "btn3"])
        
        assert manager._focus_order == ["btn1", "btn2", "btn3"]
    
    def test_add_to_focus_order_end(self):
        """Test adding widget to end of focus order."""
        manager = FocusManager()
        manager.add_to_focus_order("btn1")
        manager.add_to_focus_order("btn2")
        
        assert manager._focus_order == ["btn1", "btn2"]
    
    def test_add_to_focus_order_index(self):
        """Test adding widget at specific index."""
        manager = FocusManager()
        manager.add_to_focus_order("btn1")
        manager.add_to_focus_order("btn3")
        manager.add_to_focus_order("btn2", index=1)
        
        assert manager._focus_order == ["btn1", "btn2", "btn3"]
    
    def test_add_duplicate_to_focus_order(self):
        """Test adding duplicate widget to focus order."""
        manager = FocusManager()
        manager.add_to_focus_order("btn1")
        manager.add_to_focus_order("btn1")
        
        assert manager._focus_order == ["btn1"]
    
    def test_remove_from_focus_order(self):
        """Test removing widget from focus order."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2", "btn3"])
        manager.remove_from_focus_order("btn2")
        
        assert manager._focus_order == ["btn1", "btn3"]
    
    def test_get_next_focus_id_empty(self):
        """Test getting next focus ID with empty order."""
        manager = FocusManager()
        
        result = manager.get_next_focus_id(None)
        
        assert result is None
    
    def test_get_next_focus_id_from_none(self):
        """Test getting next focus ID from None."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2"])
        
        result = manager.get_next_focus_id(None)
        
        assert result == "btn1"
    
    def test_get_next_focus_id_forward(self):
        """Test getting next focus ID moving forward."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2", "btn3"])
        
        result = manager.get_next_focus_id("btn1")
        
        assert result == "btn2"
    
    def test_get_next_focus_id_reverse(self):
        """Test getting next focus ID moving backward."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2", "btn3"])
        
        result = manager.get_next_focus_id("btn2", reverse=True)
        
        assert result == "btn1"
    
    def test_get_next_focus_id_wrap_around(self):
        """Test focus order wraps around."""
        manager = FocusManager()
        manager.set_focus_order(["btn1", "btn2", "btn3"])
        
        result = manager.get_next_focus_id("btn3")
        
        assert result == "btn1"
    
    def test_enable_focus_trap(self):
        """Test enabling focus trap."""
        manager = FocusManager()
        container = _FakeWidget(id="modal")
        
        manager.enable_focus_trap(container)
        
        assert manager.is_focus_trapped() is True
    
    def test_disable_focus_trap(self):
        """Test disabling focus trap."""
        manager = FocusManager()
        container = _FakeWidget(id="modal")
        
        manager.enable_focus_trap(container)
        manager.disable_focus_trap()
        
        assert manager.is_focus_trapped() is False
    
    def test_set_focus_ring_style(self):
        """Test setting focus ring style."""
        manager = FocusManager()
        style = {"border": "double", "border-color": "yellow"}
        
        manager.set_focus_ring_style(style)
        
        assert manager._focus_ring_style == style
    
    def test_apply_focus_ring(self):
        """Test applying focus ring to widget."""
        manager = FocusManager()
        widget = _FakeWidget()
        widget.style = {}
        
        manager.apply_focus_ring(widget)
        
        assert "border" in widget.style
        assert "border-color" in widget.style
    
    def test_remove_focus_ring(self):
        """Test removing focus ring from widget."""
        manager = FocusManager()
        widget = _FakeWidget()
        widget.style = {"border": "solid", "color": "white"}
        manager._focus_ring_style = {"border": "solid"}
        
        manager.remove_focus_ring(widget)
        
        assert "border" not in widget.style
        assert "color" in widget.style


class TestAccessibilityManager:
    """Test AccessibilityManager functionality."""
    
    def test_init(self):
        """Test AccessibilityManager initialization."""
        manager = AccessibilityManager()
        
        assert manager.focus_manager is not None
        assert manager._screen_reader_queue == []
        assert manager._keybindings == {}
        assert manager._high_contrast is False
    
    def test_announce(self):
        """Test announcing message."""
        manager = AccessibilityManager()
        manager.announce("Hello")
        
        announcements = manager.get_announcements()
        
        assert "Hello" in announcements
    
    def test_announce_priority(self):
        """Test announcing with priority."""
        manager = AccessibilityManager()
        manager.announce("Urgent", priority="assertive")
        
        announcements = manager.get_announcements()
        
        assert "Urgent" in announcements
    
    def test_get_announcements_clears(self):
        """Test that getting announcements clears queue."""
        manager = AccessibilityManager()
        manager.announce("First")
        
        manager.get_announcements()
        announcements = manager.get_announcements()
        
        assert announcements == []
    
    def test_register_keybinding(self):
        """Test registering keybinding."""
        manager = AccessibilityManager()
        called = []
        
        def handler():
            called.append(True)
        
        manager.register_keybinding("Ctrl+S", handler)
        
        assert "Ctrl+S" in manager._keybindings
    
    def test_unregister_keybinding(self):
        """Test unregistering keybinding."""
        manager = AccessibilityManager()
        manager.register_keybinding("Ctrl+S", lambda: None)
        manager.unregister_keybinding("Ctrl+S")
        
        assert "Ctrl+S" not in manager._keybindings
    
    def test_handle_keybinding(self):
        """Test handling keybinding."""
        manager = AccessibilityManager()
        called = []
        
        def handler():
            called.append(True)
        
        from casca.core.events import KeyEvent
        manager.register_keybinding("Ctrl+S", handler)
        
        # Note: This test would need proper KeyEvent with modifiers
        # For now, just test registration works
        assert "Ctrl+S" in manager._keybindings
    
    def test_enable_high_contrast(self):
        """Test enabling high contrast mode."""
        manager = AccessibilityManager()
        manager.enable_high_contrast()
        
        assert manager.is_high_contrast() is True
    
    def test_disable_high_contrast(self):
        """Test disabling high contrast mode."""
        manager = AccessibilityManager()
        manager.enable_high_contrast()
        manager.disable_high_contrast()
        
        assert manager.is_high_contrast() is False
    
    def test_enable_verbose_mode(self):
        """Test enabling verbose mode."""
        manager = AccessibilityManager()
        manager.enable_verbose_mode()
        
        assert manager.is_verbose() is True
    
    def test_disable_verbose_mode(self):
        """Test disabling verbose mode."""
        manager = AccessibilityManager()
        manager.enable_verbose_mode()
        manager.disable_verbose_mode()
        
        assert manager.is_verbose() is False
    
    def test_get_widget_description(self):
        """Test getting widget description."""
        manager = AccessibilityManager()
        widget = _FakeWidget(id="test")
        widget.label = "Test Button"
        
        description = manager.get_widget_description(widget)
        
        assert "fake" in description


class TestGlobalAccessibility:
    """Test global accessibility functions."""
    
    def test_get_accessibility_creates_instance(self):
        """Test that get_accessibility creates instance."""
        # Reset global
        import casca.core.accessibility as acc_module
        acc_module._accessibility = None
        
        manager = get_accessibility()
        
        assert manager is not None
        assert isinstance(manager, AccessibilityManager)
    
    def test_get_accessibility_returns_same_instance(self):
        """Test that get_accessibility returns same instance."""
        manager1 = get_accessibility()
        manager2 = get_accessibility()
        
        assert manager1 is manager2
    
    def test_set_accessibility(self):
        """Test setting global accessibility."""
        new_manager = AccessibilityManager()
        set_accessibility(new_manager)
        
        assert get_accessibility() is new_manager
