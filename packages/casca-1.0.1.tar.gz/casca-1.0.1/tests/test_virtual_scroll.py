"""Tests for VirtualScrollView component."""

import pytest
from casca.components.navigation.virtual_scroll import VirtualScrollView


class _FakeApp:
    """Fake app for testing."""
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.clip_rect = None
        self._running = True
        
    def write(self, text):
        self.writes.append(text)
    
    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))
    
    def request_render(self):
        pass


def render_item(idx, app):
    """Simple item renderer for tests."""
    app.draw_text(0, 0, f"Item {idx}")


class TestVirtualScrollViewInit:
    """Test VirtualScrollView initialization."""
    
    def test_init_with_fixed_height(self):
        """Test initialization with fixed item height."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3
        )
        
        assert scroll.total_items == 100
        assert scroll.item_height == 3
        assert scroll.item_height_fn is None
        assert scroll.scroll_y == 0
    
    def test_init_with_height_fn(self):
        """Test initialization with item height function."""
        def height_fn(idx):
            return 3 if idx % 2 == 0 else 5
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height_fn=height_fn
        )
        
        assert scroll.total_items == 100
        assert scroll.item_height is None
        assert scroll.item_height_fn is height_fn
    
    def test_init_requires_height_param(self):
        """Test that either item_height or item_height_fn is required."""
        with pytest.raises(ValueError) as exc_info:
            VirtualScrollView(
                total_items=100,
                render_fn=render_item
            )
        
        assert "item_height or item_height_fn" in str(exc_info.value)
    
    def test_init_with_scroll_to_bottom(self):
        """Test initialization with auto-scroll to bottom."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            scroll_to_bottom=True
        )
        
        assert scroll.scroll_to_bottom_flag is True


class TestVirtualScrollViewItemHeight:
    """Test item height calculation."""
    
    def test_get_item_height_fixed(self):
        """Test getting item height with fixed size."""
        scroll = VirtualScrollView(
            total_items=10,
            render_fn=render_item,
            item_height=5
        )
        
        assert scroll._get_item_height(0) == 5
        assert scroll._get_item_height(5) == 5
        assert scroll._get_item_height(9) == 5
    
    def test_get_item_height_variable(self):
        """Test getting item height with variable sizes."""
        def height_fn(idx):
            return idx + 1
        
        scroll = VirtualScrollView(
            total_items=10,
            render_fn=render_item,
            item_height_fn=height_fn
        )
        
        assert scroll._get_item_height(0) == 1
        assert scroll._get_item_height(1) == 2
        assert scroll._get_item_height(9) == 10


class TestVirtualScrollViewPositions:
    """Test item position calculation."""
    
    def test_calculate_item_positions_fixed(self):
        """Test position calculation with fixed height items."""
        scroll = VirtualScrollView(
            total_items=5,
            render_fn=render_item,
            item_height=3
        )
        
        scroll._calculate_item_positions()
        
        assert scroll._item_positions == [0, 3, 6, 9, 12]
        assert scroll._item_heights == [3, 3, 3, 3, 3]
        assert scroll.content_height == 15
    
    def test_calculate_item_positions_variable(self):
        """Test position calculation with variable height items."""
        def height_fn(idx):
            return idx + 1
        
        scroll = VirtualScrollView(
            total_items=4,
            render_fn=render_item,
            item_height_fn=height_fn
        )
        
        scroll._calculate_item_positions()
        
        # Heights: 1, 2, 3, 4
        # Positions: 0, 1, 3, 6
        assert scroll._item_positions == [0, 1, 3, 6]
        assert scroll._item_heights == [1, 2, 3, 4]
        assert scroll.content_height == 10
    
    def test_calculate_positions_only_once(self):
        """Test that positions are only calculated once."""
        scroll = VirtualScrollView(
            total_items=5,
            render_fn=render_item,
            item_height=3
        )
        
        scroll._calculate_item_positions()
        first_call_positions = scroll._item_positions.copy()
        
        # Modify to detect if recalculated
        scroll._item_positions = [999]
        scroll._calculate_item_positions()
        
        # Should not have recalculated
        assert scroll._item_positions == [999]


class TestVirtualScrollViewVisibleRange:
    """Test visible range calculation."""
    
    def test_get_visible_range_basic(self):
        """Test basic visible range calculation."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3
        )
        
        scroll._calculate_item_positions()
        
        # Viewport shows 10 items (30 pixels)
        start, end = scroll._get_visible_range(30)
        
        assert start >= 0
        assert end < 100
        assert end > start
    
    def test_get_visible_range_at_top(self):
        """Test visible range when scrolled to top."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3
        )
        
        scroll.scroll_y = 0
        scroll._calculate_item_positions()
        
        start, end = scroll._get_visible_range(30)
        
        assert start == 0 or start < 5  # May include buffer
        assert end < 20  # Should show ~10 items plus buffer
    
    def test_get_visible_range_at_bottom(self):
        """Test visible range when scrolled to bottom."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=10  # Set a fixed height
        )
        
        # Need to call calculate_layout to set up max_scroll
        scroll.calculate_layout(50, 50)
        
        # Scroll to bottom
        scroll.scroll_y = scroll.max_scroll
        
        start, end = scroll._get_visible_range(10)  # Use inner height
        
        # Should include last items (with buffer)
        assert end == 99  # Last item should be included
        assert start > 80  # Should be near the end


class TestVirtualScrollViewLayout:
    """Test layout calculation."""
    
    def test_calculate_layout_sets_dimensions(self):
        """Test that layout calculates dimensions correctly."""
        scroll = VirtualScrollView(
            total_items=10,
            render_fn=render_item,
            item_height=3,
            height=10
        )
        
        width, height = scroll.calculate_layout(50, 50)
        
        assert scroll.height == 10
        assert width > 0
        assert height > 0
    
    def test_calculate_layout_sets_max_scroll(self):
        """Test that layout calculates max scroll."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        
        # Content is 300 (100 * 3), viewport is ~20
        # Max scroll should be ~280
        assert scroll.max_scroll > 250
        assert scroll.max_scroll < 300
    
    def test_calculate_layout_auto_scroll_bottom(self):
        """Test auto-scroll to bottom on first layout."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20,
            scroll_to_bottom=True
        )
        
        scroll.calculate_layout(50, 50)
        
        # Should be scrolled to bottom
        assert scroll.scroll_y == scroll.max_scroll


class TestVirtualScrollViewScrolling:
    """Test scrolling functionality."""
    
    def test_scroll_to_top(self):
        """Test scrolling to top."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 100  # Scroll down
        
        scroll.scroll_to_top()
        
        assert scroll.scroll_y == 0
    
    def test_scroll_to_bottom(self):
        """Test scrolling to bottom."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        
        scroll.scroll_to_bottom()
        
        assert scroll.scroll_y == scroll.max_scroll
    
    def test_scroll_to_item(self):
        """Test scrolling to specific item."""
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        
        scroll.scroll_to_item(50)
        
        # Item 50 should be visible
        assert scroll.scroll_y <= 50 * 3
        assert scroll.scroll_y >= 50 * 3 - 20
    
    def test_scroll_clamping(self):
        """Test that scroll is clamped to valid range."""
        scroll = VirtualScrollView(
            total_items=10,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        
        # Try to scroll beyond bounds
        scroll.scroll_y = -100
        scroll.calculate_layout(50, 50)
        assert scroll.scroll_y >= 0
        
        scroll.scroll_y = 1000
        scroll.calculate_layout(50, 50)
        assert scroll.scroll_y <= scroll.max_scroll


class TestVirtualScrollViewKeyboard:
    """Test keyboard event handling."""
    
    def test_handle_input_up(self):
        """Test UP arrow scrolls up."""
        from casca.core.events import KeyEvent, Keys
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 50
        
        event = KeyEvent(key=Keys.UP, is_printable=False)
        result = scroll.handle_input(event)
        
        # Should handle the event
        assert scroll.scroll_y < 50
    
    def test_handle_input_down(self):
        """Test DOWN arrow scrolls down."""
        from casca.core.events import KeyEvent, Keys
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 0
        
        event = KeyEvent(key=Keys.DOWN, is_printable=False)
        scroll.handle_input(event)
        
        assert scroll.scroll_y > 0
    
    def test_handle_input_home(self):
        """Test HOME key scrolls to top."""
        from casca.core.events import KeyEvent, Keys
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 100
        
        event = KeyEvent(key=Keys.HOME, is_printable=False)
        scroll.handle_input(event)
        
        assert scroll.scroll_y == 0
    
    def test_handle_input_end(self):
        """Test END key scrolls to bottom."""
        from casca.core.events import KeyEvent, Keys
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        
        event = KeyEvent(key=Keys.END, is_printable=False)
        scroll.handle_input(event)
        
        assert scroll.scroll_y == scroll.max_scroll


class TestVirtualScrollViewMouse:
    """Test mouse wheel handling."""
    
    def test_handle_wheel_up(self):
        """Test mouse wheel up scrolls up."""
        from casca.core.events import MouseEvent
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 50
        
        app = _FakeApp()
        event = MouseEvent(x=5, y=5, button=64, pressed=True)
        result = scroll.handle_wheel(event, app)
        
        assert result is True
        assert scroll.scroll_y < 50
    
    def test_handle_wheel_down(self):
        """Test mouse wheel down scrolls down."""
        from casca.core.events import MouseEvent
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.scroll_y = 0
        
        app = _FakeApp()
        event = MouseEvent(x=5, y=5, button=65, pressed=True)
        result = scroll.handle_wheel(event, app)
        
        assert result is True
        assert scroll.scroll_y > 0
    
    def test_handle_wheel_outside_bounds(self):
        """Test mouse wheel outside widget bounds."""
        from casca.core.events import MouseEvent
        
        scroll = VirtualScrollView(
            total_items=100,
            render_fn=render_item,
            item_height=3,
            height=20
        )
        
        scroll.calculate_layout(50, 50)
        scroll.x = 0
        scroll.y = 0
        scroll.width = 50
        scroll.height = 20
        
        app = _FakeApp()
        event = MouseEvent(x=100, y=100, button=64, pressed=True)
        result = scroll.handle_wheel(event, app)
        
        assert result is False


class TestVirtualScrollViewInvalidate:
    """Test cache invalidation."""
    
    def test_invalidate_cache(self):
        """Test invalidating position cache."""
        scroll = VirtualScrollView(
            total_items=10,
            render_fn=render_item,
            item_height=3
        )
        
        scroll._calculate_item_positions()
        assert scroll._positions_calculated is True
        
        scroll.invalidate_cache()
        
        assert scroll._positions_calculated is False
        assert scroll._item_positions == []
        assert scroll._item_heights == []
