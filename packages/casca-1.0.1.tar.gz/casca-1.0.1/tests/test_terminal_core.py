"""Tests for terminal handling core functionality."""

import pytest
from unittest.mock import patch, MagicMock
from casca.core.terminal import RawTerminal, get_terminal_size


class TestGetTerminalSize:
    """Test terminal size detection."""

    def test_get_terminal_size_returns_tuple(self):
        """Test that get_terminal_size returns a tuple of (width, height)."""
        size = get_terminal_size()
        
        assert isinstance(size, tuple)
        assert len(size) == 2
        assert isinstance(size[0], int)  # width
        assert isinstance(size[1], int)  # height
        assert size[0] > 0
        assert size[1] > 0

    def test_get_terminal_size_caches_result(self):
        """Test that terminal size is cached."""
        size1 = get_terminal_size()
        size2 = get_terminal_size()
        
        # Should return cached result
        assert size1 == size2


class TestRawTerminal:
    """Test RawTerminal context manager."""

    def test_raw_terminal_enters_raw_mode(self):
        """Test entering raw terminal mode."""
        with patch('casca.core.terminal.termios') as mock_termios:
            mock_fd = MagicMock()
            mock_termios.tcgetattr.return_value = [0] * 7
            
            with RawTerminal():
                # Should have called tcgetattr to save settings
                mock_termios.tcgetattr.assert_called()
                
    def test_raw_terminal_exits_restores_mode(self):
        """Test exiting raw terminal mode restores settings."""
        with patch('casca.core.terminal.termios') as mock_termios:
            mock_fd = MagicMock()
            saved_settings = [0] * 7
            mock_termios.tcgetattr.return_value = saved_settings
            
            with RawTerminal():
                pass
            
            # Should have restored settings on exit
            mock_termios.tcsetattr.assert_called()

    def test_raw_terminal_handles_exception(self):
        """Test that RawTerminal restores settings even on exception."""
        with patch('casca.core.terminal.termios') as mock_termios:
            mock_fd = MagicMock()
            saved_settings = [0] * 7
            mock_termios.tcgetattr.return_value = saved_settings
            
            with pytest.raises(ValueError):
                with RawTerminal():
                    raise ValueError("Test error")
            
            # Should still have restored settings
            mock_termios.tcsetattr.assert_called()


class TestCursorControl:
    """Test cursor visibility control."""

    def test_hide_cursor_returns_ansi_code(self):
        """Test hide_cursor returns ANSI escape code."""
        result = hide_cursor()
        
        assert isinstance(result, str)
        assert len(result) > 0

    def test_show_cursor_returns_ansi_code(self):
        """Test show_cursor returns ANSI escape code."""
        result = show_cursor()
        
        assert isinstance(result, str)
        assert len(result) > 0


class TestTerminalInput:
    """Test terminal input reading."""

    def test_read_char_non_blocking(self):
        """Test reading a character in non-blocking mode."""
        with patch('casca.core.terminal.sys.stdin') as mock_stdin:
            mock_stdin.buffer.read.return_value = b'a'
            
            from casca.core.terminal import read_char
            char = read_char()
            
            assert char == 'a'

    def test_read_char_empty(self):
        """Test reading when no input available."""
        with patch('casca.core.terminal.sys.stdin') as mock_stdin:
            mock_stdin.buffer.read.return_value = b''
            
            from casca.core.terminal import read_char
            char = read_char()
            
            assert char == ''


class TestTerminalOutput:
    """Test terminal output writing."""

    def test_write_to_stdout(self):
        """Test writing to stdout."""
        with patch('casca.core.terminal.sys.stdout') as mock_stdout:
            from casca.core.terminal import write
            
            write("test")
            
            mock_stdout.write.assert_called_once_with("test")

    def test_flush_stdout(self):
        """Test flushing stdout."""
        with patch('casca.core.terminal.sys.stdout') as mock_stdout:
            from casca.core.terminal import flush
            
            flush()
            
            mock_stdout.flush.assert_called_once()


class TestTerminalMode:
    """Test terminal mode settings."""

    def test_enter_raw_mode_sets_flags(self):
        """Test that entering raw mode sets correct flags."""
        with patch('casca.core.terminal.termios') as mock_termios:
            mock_fd = 0
            old_settings = [0o005403, 0o000017, 0o020005, 0o000327, 0o000003, 0o000000]
            mock_termios.tcgetattr.return_value = old_settings
            
            from casca.core.terminal import enter_raw_mode
            new_settings = enter_raw_mode(mock_fd)
            
            # Should have modified settings for raw mode
            assert new_settings != old_settings

    def test_restore_mode_restores_settings(self):
        """Test restoring terminal mode."""
        with patch('casca.core.terminal.termios') as mock_termios:
            mock_fd = 0
            settings = [0] * 7
            
            from casca.core.terminal import restore_mode
            restore_mode(mock_fd, settings)
            
            mock_termios.tcsetattr.assert_called_once()
