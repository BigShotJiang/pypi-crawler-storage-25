"""Golden edge-case layout tests for overflow, nesting, and clipping."""

from casca import Container, Label, ScrollView, TabItem, Tabs


class _ClipAwareFakeApp:
    def __init__(self):
        self.draw_calls = []
        self.writes = []
        self.clip_rect = None

    def write(self, text: str):
        self.writes.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        if apply_clip and self.clip_rect:
            min_y, max_y, min_x, max_x = self.clip_rect
            if y < min_y or y >= max_y:
                return
            if x < min_x:
                text = text[min_x - x :]
                x = min_x
            if x + len(text) > max_x:
                text = text[: max_x - x]
            if not text:
                return
        self.draw_calls.append((x, y, text))


def _layout(widget, width=80, height=24):
    widget.resolve_styles({})
    widget.x = 0
    widget.y = 0
    widget.calculate_layout(width, height)


def test_golden_row_overflow_shrinks_to_fit_parent_width():
    left = Container(Label("left"), style={"flex-basis": 12, "flex-shrink": 1, "height": 1})
    right = Container(Label("right"), style={"flex-basis": 12, "flex-shrink": 1, "height": 1})
    root = Container(left, right, style={"width": 14, "flex-direction": "row", "gap": 1})

    _layout(root, width=14, height=6)

    assert left.width >= 1
    assert right.width >= 1
    assert right.x >= left.x + left.width
    assert right.x + right.width <= root.x + root.width


def test_golden_nested_tabs_render_only_active_nested_content():
    nested = Tabs(
        TabItem("Inner-1", Label("InnerOne")),
        TabItem("Inner-2", Label("InnerTwo")),
        active_index=1,
    )
    outer = Tabs(
        TabItem("Main", nested),
        TabItem("Other", Label("OtherPane")),
        active_index=0,
    )

    _layout(outer, width=60, height=20)
    app = _ClipAwareFakeApp()
    outer.render(app)

    rendered = [text for _x, _y, text in app.draw_calls]
    assert "InnerTwo" in rendered
    assert "InnerOne" not in rendered
    assert "OtherPane" not in rendered


def test_golden_scrollview_clips_rendered_lines_to_viewport():
    scroll = ScrollView(*[Label(f"line{i}") for i in range(10)], width=12, height=4)
    _layout(scroll, width=12, height=8)
    scroll.scroll_y = 3
    scroll.calculate_layout(12, 8)

    app = _ClipAwareFakeApp()
    scroll.render(app)

    # Viewport is height=4, so only y in 1..4 should be visible.
    ys = [y for _x, y, _text in app.draw_calls]
    assert ys
    assert min(ys) >= 1
    assert max(ys) <= 4

    rendered = [text for _x, _y, text in app.draw_calls]
    assert "line0" not in rendered
    assert any(text.startswith("line") for text in rendered)
