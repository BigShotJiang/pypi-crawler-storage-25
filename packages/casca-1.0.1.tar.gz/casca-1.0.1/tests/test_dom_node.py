"""Tests for base DOM Widget behavior."""

from casca.dom.node import Widget
from casca.core.events import KeyEvent, MouseEvent


class _FakeApp:
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None

    def write(self, text):
        self.writes.append(text)

    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))


class _DummyWidget(Widget):
    tag = "button"

    def __init__(self, *children, **kwargs):
        super().__init__(*children, **kwargs)
        self.mouse_calls = 0

    def on_mouse(self, event):
        self.mouse_calls += 1
        return event.button == 0 and not event.pressed


class _InputConsumer(Widget):
    def __init__(self, consume=False, **kwargs):
        super().__init__(**kwargs)
        self.consume = consume

    def handle_input(self, event):
        return self.consume


def test_widget_resolve_styles_merges_inline_over_css():
    w = Widget(id="main", classes="box", style={"color": "blue"})
    sheet = {
        "widget": {"color": "red", "padding": "1"},
        ".box": {"color": "green"},
        "#main": {"margin": "2"},
    }

    w.resolve_styles(sheet)

    assert w.style["color"] == "blue"
    assert w.style["padding"] == "1"
    assert w.style["margin"] == "2"


def test_widget_render_draws_background_border_and_children():
    child = Widget()
    root = Widget(child, style={"background": "black", "border": "ascii"})
    root.resolve_styles({})
    root.width = 4
    root.height = 3
    child.width = 1
    child.height = 1

    app = _FakeApp()
    root.render(app)

    assert len(app.draw_calls) >= 3


def test_widget_handle_input_checks_children_in_reverse_order():
    first = _InputConsumer(consume=False)
    second = _InputConsumer(consume=True)
    root = Widget(first, second)

    handled = root.handle_input(KeyEvent(key="a", is_printable=True))

    assert handled is True


def test_widget_handle_mouse_focuses_interactive_and_calls_on_mouse():
    w = _DummyWidget(id="btn")
    w.x = 0
    w.y = 0
    w.width = 10
    w.height = 2
    app = _FakeApp()

    press_evt = MouseEvent(x=1, y=1, button=0, pressed=True)
    release_evt = MouseEvent(x=1, y=1, button=0, pressed=False)

    assert w.handle_mouse(press_evt, app) is True
    assert app.focused_widget is w
    assert app.focused_id == "btn"

    assert w.handle_mouse(release_evt, app) is True
    assert w.mouse_calls >= 1
