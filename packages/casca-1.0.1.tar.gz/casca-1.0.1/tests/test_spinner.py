"""Tests for Spinner widget."""

from casca import Spinner


class FakeApp:
    def __init__(self):
        self.draw_calls = []
        self.writes = []

    def write(self, text: str):
        self.writes.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        self.draw_calls.append((x, y, text))


def test_spinner_tick_advances_frames():
    spinner = Spinner(frames=["a", "b", "c"])
    assert spinner.current_frame == "a"

    spinner.tick()
    assert spinner.current_frame == "b"

    spinner.tick(steps=2)
    assert spinner.current_frame == "a"


def test_spinner_renders_frame_and_text():
    spinner = Spinner(text="Loading", frames=["*"], width=12)
    spinner.resolve_styles({})
    spinner.x = 0
    spinner.y = 0
    spinner.calculate_layout(80, 24)

    app = FakeApp()
    spinner.render(app)

    assert app.draw_calls == [(1, 1, "* Loading")]
