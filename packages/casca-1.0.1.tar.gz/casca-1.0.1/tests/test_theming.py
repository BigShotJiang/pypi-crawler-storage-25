"""Tests for theme token resolution and runtime theme switching."""

from casca import App
from casca.core.themes import THEMES, apply_theme_tokens, resolve_theme_value


class _ThemeApp(App):
    css = """
    .title { color: var(primary); background: var(surface); }
    .warn { color: var(unknown, bright_red); }
    """


def test_resolve_theme_value_with_fallback():
    tokens = {"primary": "bright_cyan"}
    assert resolve_theme_value("var(primary)", tokens) == "bright_cyan"
    assert resolve_theme_value("var(missing, bright_red)", tokens) == "bright_red"


def test_apply_theme_tokens_to_stylesheet():
    stylesheet = {".x": {"color": "var(primary)", "background": "var(surface)"}}
    themed = apply_theme_tokens(stylesheet, THEMES["default"])

    assert themed[".x"]["color"] == THEMES["default"]["primary"]
    assert themed[".x"]["background"] == THEMES["default"]["surface"]


def test_app_loads_and_switches_named_theme():
    app = _ThemeApp()

    assert app.stylesheet[".title"]["color"] == THEMES["default"]["primary"]

    app.set_theme("solarized")

    assert app.stylesheet[".title"]["color"] == THEMES["solarized"]["primary"]
    assert app.stylesheet[".warn"]["color"] == "bright_red"
