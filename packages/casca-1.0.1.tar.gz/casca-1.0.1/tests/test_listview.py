"""Tests for ListView widget selection and scrolling."""

from casca import KeyEvent, ListView, MouseEvent


def _make_listview():
    lv = ListView([f"Item {i}" for i in range(1, 8)], height=4)
    lv.resolve_styles({})
    lv.x = 0
    lv.y = 0
    lv.calculate_layout(20, 10)
    return lv


def test_listview_keyboard_selection_moves_and_clamps():
    lv = _make_listview()

    for _ in range(20):
        lv.handle_input(KeyEvent(key="\x1b[B", is_printable=False))
    assert lv.selected_index == len(lv.items) - 1

    for _ in range(20):
        lv.handle_input(KeyEvent(key="\x1b[A", is_printable=False))
    assert lv.selected_index == 0


def test_listview_scroll_offset_updates_to_keep_selected_visible():
    lv = _make_listview()

    for _ in range(5):
        lv.handle_input(KeyEvent(key="\x1b[B", is_printable=False))

    assert lv.selected_index == 5
    assert lv.scroll_offset > 0


def test_listview_mouse_selects_row():
    lv = _make_listview()

    handled = lv.on_mouse(MouseEvent(x=1, y=3, button=0, pressed=False))

    assert handled is True
    assert lv.selected_index == 2
