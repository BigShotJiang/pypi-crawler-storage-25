"""Tests for StudioPanel embedded inspector."""

from casca import App, Container, Input, StudioPanel


class _StudioPanelApp(App):
    def build_ui(self):
        return Container(
            Input(id="name", width=30),
            StudioPanel(id="studio", style={"width": 60, "height": 14}),
            style={"flex-direction": "column", "gap": 1, "width": 100, "height": 30},
        )


def test_studio_panel_renders_focus_data_lines():
    app = _StudioPanelApp()
    app.root = app.build_ui()
    app.root.resolve_styles(app.stylesheet)
    app.root.calculate_layout(100, 30)
    app.focus_next()

    calls = []

    def _draw(x, y, text, apply_clip=True):
        calls.append((x, y, text))

    app.draw_text = _draw
    app.root.render(app)

    rendered = "\n".join(t for _x, _y, t in calls)
    assert "Casca Studio" in rendered
    assert "Focus path:" in rendered
    assert "Widget:" in rendered
