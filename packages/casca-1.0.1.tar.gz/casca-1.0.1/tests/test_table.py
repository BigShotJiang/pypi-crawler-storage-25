"""Tests for Table widget behavior."""

from casca import KeyEvent, Table
from casca.core.events import Keys


def _table():
    table = Table(
        columns=["service", "status", "latency"],
        rows=[
            ["api", "ok", "34"],
            ["auth", "warn", "82"],
            ["billing", "ok", "41"],
        ],
        width=36,
        height=6,
    )
    table.resolve_styles({})
    table.calculate_layout(80, 20)
    return table


def test_table_sort_by_column_name():
    table = _table()

    table.sort_by("service", reverse=True)

    assert table.rows[0][0] == "billing"


def test_table_filter_reduces_visible_rows():
    table = _table()

    table.set_filter("warn")

    assert len(table.filtered_rows) == 1
    assert table.filtered_rows[0][0] == "auth"


def test_table_keyboard_selection_moves():
    table = _table()

    handled = table.handle_input(KeyEvent(key=Keys.DOWN, is_printable=False))

    assert handled is True
    assert table.selected_row == 1
