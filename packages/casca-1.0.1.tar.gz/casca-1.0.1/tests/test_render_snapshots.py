"""Snapshot-style rendering tests for core widgets."""

import pytest

from casca import Button, Input, Label, TabItem, Tabs, TextArea


class FakeApp:
    def __init__(self):
        self.draw_calls = []
        self.writes = []

    def write(self, text: str):
        self.writes.append(text)

    def draw_text(self, x: int, y: int, text: str, apply_clip=True):
        self.draw_calls.append((x, y, text))


def _render_widget(widget, width=80, height=24):
    widget.resolve_styles({})
    widget.x = 0
    widget.y = 0
    widget.calculate_layout(width, height)
    app = FakeApp()
    widget.render(app)
    return app.draw_calls


def test_button_render_snapshot():
    button = Button("Save")
    calls = _render_widget(button)

    assert calls == [(1, 1, "Save")]


def test_input_render_snapshot_with_value():
    inp = Input(default_value="abc", width=8)
    calls = _render_widget(inp)

    assert calls == [(1, 1, "abc")]


def test_textarea_render_snapshot_multiline():
    ta = TextArea(default_value="a\nb", width=6, height=4)
    calls = _render_widget(ta)

    assert calls[:2] == [(1, 1, "a"), (1, 2, "b")]


def test_tabs_render_snapshot_header_and_content():
    tabs = Tabs(
        TabItem("One", Label("Pane1")),
        TabItem("Two", Label("Pane2")),
        active_index=0,
    )
    calls = _render_widget(tabs, width=40, height=10)

    rendered_texts = [text for _x, _y, text in calls]
    assert " One" in rendered_texts
    assert " Two" in rendered_texts
    assert "Pane1" in rendered_texts


def test_label_nowrap_ellipsis_snapshot():
    label = Label("abcdefgh", style={"width": 5, "white-space": "nowrap", "text-overflow": "ellipsis"})
    calls = _render_widget(label, width=20, height=5)

    assert calls == [(1, 1, "ab...")]


def test_label_wrap_snapshot():
    label = Label("abcdef", style={"width": 4, "white-space": "normal"})
    calls = _render_widget(label, width=20, height=5)

    assert calls[:2] == [(1, 1, "abcd"), (1, 2, "ef")]


def test_label_letter_spacing_snapshot():
    label = Label("ABC", style={"letter-spacing": 1})
    calls = _render_widget(label, width=20, height=5)

    assert calls == [(1, 1, "A B C")]


@pytest.mark.parametrize("size", [(80, 24), (100, 30), (120, 40)])
def test_button_snapshot_is_stable_across_terminal_sizes(size):
    width, height = size
    calls = _render_widget(Button("Save"), width=width, height=height)

    assert calls == [(1, 1, "Save")]


@pytest.mark.parametrize("size", [(80, 24), (100, 30), (120, 40)])
def test_label_ellipsis_snapshot_is_stable_across_terminal_sizes(size):
    width, height = size
    label = Label("abcdefgh", style={"width": 5, "white-space": "nowrap", "text-overflow": "ellipsis"})
    calls = _render_widget(label, width=width, height=height)

    assert calls == [(1, 1, "ab...")]


@pytest.mark.parametrize("size", [(80, 24), (100, 30), (120, 40)])
def test_tabs_snapshot_keeps_header_and_active_content_across_terminal_sizes(size):
    width, height = size
    tabs = Tabs(
        TabItem("One", Label("Pane1")),
        TabItem("Two", Label("Pane2")),
        active_index=0,
    )
    calls = _render_widget(tabs, width=width, height=height)

    rendered_texts = [text for _x, _y, text in calls]
    assert " One" in rendered_texts
    assert " Two" in rendered_texts
    assert "Pane1" in rendered_texts
    assert "Pane2" not in rendered_texts
