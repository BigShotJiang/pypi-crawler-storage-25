"""Tests for Image widget rendering modes and edge cases."""

import subprocess

from casca.components.widgets.image import Image


def _rgb_bytes(width: int, height: int, fn):
    buf = bytearray()
    for y in range(height):
        for x in range(width):
            r, g, b = fn(x, y)
            buf.extend((r, g, b))
    return bytes(buf)


def test_invalid_mode_falls_back_to_uni():
    img = Image(src="/tmp/does-not-matter.png", mode="wat")
    assert img.mode == "uni"


def test_color_ascii_mode_is_accepted():
    img = Image(src="/tmp/does-not-matter.png", mode="color-ascii")
    assert img.mode == "color-ascii"


def test_build_convert_cmd_fit_variants():
    img = Image(src="/tmp/p.png")

    stretch = img._build_convert_cmd(10, 5, "stretch", "uni")
    contain = img._build_convert_cmd(10, 5, "contain", "ascii")
    cover = img._build_convert_cmd(10, 5, "cover", "color-ascii")

    assert stretch == [
        "convert",
        "/tmp/p.png",
        "-auto-orient",
        "-filter",
        "Lanczos",
        "-strip",
        "-resize",
        "10x5!",
        "-colorspace",
        "sRGB",
        "rgb:-",
    ]
    assert contain == [
        "convert",
        "/tmp/p.png",
        "-auto-orient",
        "-filter",
        "Lanczos",
        "-strip",
        "-resize",
        "10x5",
        "-background",
        "black",
        "-gravity",
        "center",
        "-extent",
        "10x5",
        "-colorspace",
        "Gray",
        "rgb:-",
    ]
    assert cover == [
        "convert",
        "/tmp/p.png",
        "-auto-orient",
        "-filter",
        "Lanczos",
        "-strip",
        "-resize",
        "10x5^",
        "-gravity",
        "center",
        "-extent",
        "10x5",
        "-colorspace",
        "sRGB",
        "rgb:-",
    ]


def test_uni_mode_respects_exact_output_dimensions():
    img = Image(src="/tmp/p.png", mode="uni")
    raw = _rgb_bytes(4, 3, lambda _x, _y: (255, 0, 0))

    img._render_uni(raw, 4, 3)

    assert len(img.lines) == 3
    assert all(len(img._strip_ansi(line)) == 4 for line in img.lines)


def test_ascii_mode_respects_exact_output_dimensions():
    img = Image(src="/tmp/p.png", mode="ascii")
    raw = _rgb_bytes(5, 2, lambda x, _y: (x * 20, x * 20, x * 20))

    img._render_ascii(raw, 5, 2)

    assert len(img.lines) == 2
    assert all(len(line) == 5 for line in img.lines)


def test_dots_mode_respects_output_grid_height_and_width():
    img = Image(src="/tmp/p.png", mode="dots")
    # dots mode uses 2x4 pixels per character. 6x12 px -> 3x3 chars.
    raw = _rgb_bytes(6, 12, lambda _x, _y: (255, 255, 255))

    img._render_dots(raw, 6, 12)

    assert len(img.lines) == 3
    assert all(len(line) == 3 for line in img.lines)


def test_render_image_uses_cache_for_same_dimensions(monkeypatch):
    img = Image(src="/tmp/p.png", mode="ascii")

    calls = {"count": 0}

    def _fake_get_raw(width, height, fit, mode):
        calls["count"] += 1
        assert mode == "ascii"
        return _rgb_bytes(width, height, lambda _x, _y: (128, 128, 128))

    monkeypatch.setattr(img, "_get_raw_data", _fake_get_raw)

    img._render_image(8, 4)
    img._render_image(8, 4)

    assert calls["count"] == 1


def test_render_image_rebuilds_lines_when_brightness_changes(monkeypatch):
    img = Image(src="/tmp/p.png", mode="ascii")

    calls = {"count": 0}

    def _fake_get_raw(width, height, fit, mode):
        calls["count"] += 1
        return _rgb_bytes(width, height, lambda _x, _y: (120, 120, 120))

    monkeypatch.setattr(img, "_get_raw_data", _fake_get_raw)

    img._render_image(8, 4)
    cache_key_1 = img._line_cache_key
    img.props["brightness"] = 1.5
    img._render_image(8, 4)

    assert img._line_cache_key != cache_key_1
    # Raw bytes are still reused because source+size key did not change.
    assert calls["count"] == 1


def test_render_image_rebuilds_lines_when_ascii_ramp_changes(monkeypatch):
    img = Image(src="/tmp/p.png", mode="ascii")

    calls = {"count": 0}

    def _fake_get_raw(width, height, fit, mode):
        calls["count"] += 1
        return _rgb_bytes(width, height, lambda _x, _y: (128, 128, 128))

    monkeypatch.setattr(img, "_get_raw_data", _fake_get_raw)

    img._render_image(6, 2)
    first = img.lines[:]
    img.props["ascii-chars"] = " .#"
    img._render_image(6, 2)

    assert img.lines != first
    assert calls["count"] == 1


def test_render_image_handles_missing_convert(monkeypatch):
    img = Image(src=__file__, mode="ascii")

    def _fail(*_args, **_kwargs):
        raise FileNotFoundError()

    monkeypatch.setattr("casca.components.widgets.image.subprocess.run", _fail)

    img._render_image(8, 4)

    assert img.lines == ["[Image Load Error]"]
    assert any("convert" in warning for warning in img._layout_warnings)


def test_render_image_handles_timeout(monkeypatch):
    img = Image(src=__file__, mode="ascii")

    def _timeout(*_args, **_kwargs):
        raise subprocess.TimeoutExpired(cmd="convert", timeout=10)

    monkeypatch.setattr("casca.components.widgets.image.subprocess.run", _timeout)

    img._render_image(8, 4)

    assert img.lines == ["[Image Load Error]"]
    assert any("timed out" in warning.lower() for warning in img._layout_warnings)


def test_render_image_file_not_found_uses_fallback():
    img = Image(src="/tmp/definitely-missing-casca-image.png", mode="ascii", fallback="[Missing]")

    img._render_image(8, 4)

    assert img.lines == ["[Missing]"]
    assert any("not found" in warning.lower() for warning in img._layout_warnings)


def test_ascii_invert_switches_gradient_direction():
    normal = Image(src="/tmp/p.png", mode="ascii")
    inverted = Image(src="/tmp/p.png", mode="ascii", **{"ascii-invert": True})
    raw = _rgb_bytes(2, 1, lambda x, _y: (0, 0, 0) if x == 0 else (255, 255, 255))

    normal._render_ascii(raw, 2, 1)
    inverted._render_ascii(raw, 2, 1)

    assert normal.lines[0] != inverted.lines[0]


def test_ascii_dither_toggle_changes_output():
    raw = _rgb_bytes(8, 2, lambda x, _y: (x * 32, x * 32, x * 32))
    dithered = Image(src="/tmp/p.png", mode="ascii", **{"ascii-dither": True})
    plain = Image(src="/tmp/p.png", mode="ascii", **{"ascii-dither": False})

    dithered._render_ascii(raw, 8, 2)
    plain._render_ascii(raw, 8, 2)

    assert dithered.lines != plain.lines


def test_uni_uses_bg_colored_spaces():
    img = Image(src="/tmp/p.png", mode="uni")
    raw = _rgb_bytes(1, 1, lambda _x, _y: (10, 20, 30))

    img._render_uni(raw, 1, 1)

    assert "48;2;10;20;30m " in img.lines[0]


def test_color_ascii_has_fg_codes_and_dimensions():
    img = Image(src="/tmp/p.png", mode="color-ascii", **{"ascii-dither": False})
    raw = _rgb_bytes(3, 1, lambda x, _y: (x * 80, 20, 240 - x * 80))

    img._render_color_ascii(raw, 3, 1)

    assert len(img.lines) == 1
    assert len(img._strip_ansi(img.lines[0])) == 3
    assert "38;2;" in img.lines[0]


def test_apply_tone_changes_pixel_values():
    img = Image(src="/tmp/p.png")
    raw = bytes([100, 120, 140])

    adjusted = img._apply_tone(raw, brightness=1.2, contrast=1.1)

    assert adjusted != raw
