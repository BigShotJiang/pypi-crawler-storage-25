"""Tests for Casca plugin registry and extension discovery."""

from casca.plugins.registry import (
    PluginRegistry,
    is_compatible_api_version,
    validate_plugin_api_version,
)


class _WidgetA:
    def __init__(self, text="a"):
        self.text = text


class _WidgetB:
    pass


class _WidgetCompat:
    CASCA_API_VERSION = "1.2"


class _WidgetIncompat:
    CASCA_API_VERSION = "2.0"


class _FakeEP:
    def __init__(self, group, name, value, obj):
        self.group = group
        self.name = name
        self.value = value
        self._obj = obj

    def load(self):
        return self._obj


class _FakeEPCollection:
    def __init__(self, entries):
        self._entries = entries

    def select(self, *, group):
        return [ep for ep in self._entries if ep.group == group]


def test_registry_register_get_create_and_list():
    reg = PluginRegistry()
    reg.register_widget("casca-jsonviewer", _WidgetA, source="test")

    cls = reg.get_widget("casca-jsonviewer")
    assert cls is _WidgetA

    inst = reg.create_widget("casca-jsonviewer", text="ok")
    assert isinstance(inst, _WidgetA)
    assert inst.text == "ok"

    widgets = reg.list_widgets()
    assert len(widgets) == 1
    assert widgets[0].name == "casca-jsonviewer"
    assert widgets[0].source == "test"


def test_registry_duplicate_registration_requires_replace():
    reg = PluginRegistry()
    reg.register_widget("casca-plot", _WidgetA)

    try:
        reg.register_widget("casca-plot", _WidgetB)
        assert False, "Expected duplicate registration to fail"
    except ValueError:
        pass

    reg.register_widget("casca-plot", _WidgetB, replace=True)
    assert reg.get_widget("casca-plot") is _WidgetB


def test_registry_discovery_supports_class_callable_and_dict(monkeypatch):
    reg = PluginRegistry()

    def _plugin_callable(local_reg):
        local_reg.register_widget("casca-markdown", _WidgetB, source="callable")

    eps = _FakeEPCollection(
        [
            _FakeEP("casca.widgets", "casca-plot", "pkg.plot:PlotWidget", _WidgetA),
            _FakeEP("casca.widgets", "setup", "pkg.setup:register", _plugin_callable),
            _FakeEP("casca.widgets", "bundle", "pkg.bundle:widgets", {"casca-jsonviewer": _WidgetA}),
        ]
    )

    monkeypatch.setattr("casca.plugins.registry.entry_points", lambda: eps)

    items = reg.discover_plugins()
    names = [i.name for i in items]

    assert "casca-plot" in names
    assert "casca-markdown" in names
    assert "casca-jsonviewer" in names

    # Discovery should be idempotent.
    items2 = reg.discover_plugins()
    assert len(items2) == len(items)


def test_api_version_compatibility_helpers():
    assert is_compatible_api_version("1.0", "1.5") is True
    assert is_compatible_api_version("2.0", "1.5") is False

    validate_plugin_api_version("1.3", "1.0")
    try:
        validate_plugin_api_version("2.0", "1.0")
        assert False, "Expected incompatible api_version to fail"
    except ValueError:
        pass


def test_registry_rejects_incompatible_widget_api_version():
    reg = PluginRegistry(api_version="1.0")
    reg.register_widget("compat", _WidgetCompat)
    assert reg.get_widget("compat") is _WidgetCompat

    try:
        reg.register_widget("incompat", _WidgetIncompat)
        assert False, "Expected incompatible widget API registration to fail"
    except ValueError:
        pass
