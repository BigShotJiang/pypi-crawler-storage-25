"""Tests for tabs/navigation behaviors."""

from casca import Tabs, TabItem, Label


def test_tabs_switch_updates_active_index_and_content():
    tabs = Tabs(
        TabItem("One", Label("First")),
        TabItem("Two", Label("Second")),
        active_index=0,
    )

    assert tabs.active_index == 0
    assert tabs.get_active_tab().title == "One"

    changed = tabs.switch_tab(1)
    assert changed is True
    assert tabs.active_index == 1
    assert tabs.get_active_tab().title == "Two"


def test_tabs_invalid_switch_is_ignored():
    tabs = Tabs(TabItem("One", Label("First")), active_index=0)

    changed = tabs.switch_tab(9)

    assert changed is False
    assert tabs.active_index == 0


def test_tabs_remove_rebalances_active_index():
    tabs = Tabs(
        TabItem("A", Label("a")),
        TabItem("B", Label("b")),
        active_index=1,
    )

    removed = tabs.remove_tab(1)

    assert removed is True
    assert tabs.active_index == 0
    assert len(tabs.tabs) == 1
