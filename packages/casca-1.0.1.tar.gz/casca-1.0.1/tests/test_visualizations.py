import unittest
from casca.components.visualizations.bar_chart import BarChart
from casca.components.visualizations.sparkline import Sparkline
from casca.components.visualizations.gauge import Gauge

class MockApp:
    def __init__(self):
        self._output = []
    def write(self, s):
        self._output.append(s)
    def draw_text(self, x, y, text):
        self._output.append((x, y, text))

class TestVisualizations(unittest.TestCase):
    def test_bar_chart_render(self):
        app = MockApp()
        chart = BarChart(data=[10, 50, 100], width=20, height=10, style={"padding": "0"})
        chart.calculate_layout(20, 10)
        chart.x = 0
        chart.y = 0
        chart.render_content(app)
        self.assertTrue(len(app._output) > 0)

    def test_sparkline_render(self):
        app = MockApp()
        chart = Sparkline(data=[1, 2, 3, 4, 5], width=20, height=10, style={"padding": "0"})
        chart.calculate_layout(20, 10)
        chart.x = 0
        chart.y = 0
        chart.render_content(app)
        self.assertTrue(len(app._output) > 0)
        drawn_lines = [text for text in app._output if isinstance(text, tuple)]
        self.assertTrue(any(any(ch != " " for ch in line[2]) for line in drawn_lines))

    def test_gauge_render(self):
        app = MockApp()
        gauge = Gauge(value=50, width=20, height=5, style={"padding": "0"})
        gauge.calculate_layout(20, 5)
        gauge.x = 0
        gauge.y = 0
        gauge.render_content(app)
        self.assertTrue(len(app._output) > 0)

if __name__ == "__main__":
    unittest.main()
