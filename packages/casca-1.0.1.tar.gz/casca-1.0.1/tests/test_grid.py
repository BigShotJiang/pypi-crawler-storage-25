"""Tests for Grid widget."""
import pytest
from casca.components.widgets.grid import Grid
from casca.components.widgets.label import Label


class TestGridInit:
    def test_init_default(self):
        grid = Grid()
        assert grid.columns_def == "1fr"
        assert grid.rows_def == "auto"
        assert grid.gap == 0
    
    def test_init_custom(self):
        grid = Grid(columns="1fr 1fr", rows="auto auto", gap=1)
        assert grid.columns_def == "1fr 1fr"
        assert grid.rows_def == "auto auto"
        assert grid.gap == 1
    
    def test_add_child(self):
        grid = Grid()
        label = Label("Test")
        grid.add(label, grid_column="1", grid_row="1")
        assert len(grid.children) == 1
        assert len(grid.grid_children) == 1


class TestGridParseTracks:
    def test_parse_px_tracks(self):
        grid = Grid()
        result = grid._parse_tracks("100px 200px", 500)
        assert result == [100, 200]
    
    def test_parse_fr_tracks(self):
        grid = Grid()
        result = grid._parse_tracks("1fr 1fr", 300)
        assert result == [150, 150]
    
    def test_parse_mixed_tracks(self):
        grid = Grid()
        result = grid._parse_tracks("100px 1fr", 300)
        assert result[0] == 100
        assert result[1] == 200
    
    def test_parse_empty_tracks(self):
        grid = Grid()
        result = grid._parse_tracks("", 300)
        assert result == [300]


class TestGridPlacement:
    def test_parse_simple_placement(self):
        grid = Grid()
        start, end = grid._parse_placement("1", 3)
        assert start == 1
        assert end == 2
    
    def test_parse_span_placement(self):
        grid = Grid()
        start, end = grid._parse_placement("1 / span 2", 3)
        assert start == 1
        assert end == 3
    
    def test_parse_range_placement(self):
        grid = Grid()
        start, end = grid._parse_placement("1 / 3", 3)
        assert start == 1
        assert end == 3


class TestGridLayout:
    def test_calculate_layout_basic(self):
        grid = Grid(columns="1fr 1fr", rows="auto auto")
        grid.resolve_styles({})
        w, h = grid.calculate_layout(200, 100)
        assert grid.width == 200
        assert len(grid.column_tracks) == 2
    
    def test_calculate_layout_with_gap(self):
        grid = Grid(columns="1fr 1fr", gap=2)
        grid.resolve_styles({})
        grid.calculate_layout(200, 100)
        assert grid.column_gap == 2
        assert grid.row_gap == 2


class TestGridIntegration:
    def test_grid_with_labels(self):
        grid = Grid(
            columns="1fr 1fr",
            rows="auto auto",
            gap=1
        )
        grid.add(Label("A"), grid_column="1", grid_row="1")
        grid.add(Label("B"), grid_column="2", grid_row="1")
        grid.resolve_styles({})
        grid.calculate_layout(200, 100)
        
        # Children should be positioned
        assert grid.children[0].x >= 0
        assert grid.children[1].x > grid.children[0].x
