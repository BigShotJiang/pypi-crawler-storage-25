"""Tests for screenshot export helpers."""

from pathlib import Path

from casca.core.screenshot import capture_frame_screenshot


def test_capture_frame_screenshot_writes_ansi_txt_svg(tmp_path: Path):
    out_dir = tmp_path / "shots"
    frame = "\x1b[31mHello\x1b[0m"

    svg_path = capture_frame_screenshot(
        frame=frame,
        size=(20, 5),
        out_dir=str(out_dir),
        settings={},
    )

    assert svg_path is not None
    svg_file = Path(svg_path)
    assert svg_file.exists()
    assert svg_file.suffix == ".svg"

    base = svg_file.with_suffix("")
    ansi_file = base.with_suffix(".ansi")
    txt_file = base.with_suffix(".txt")
    png_file = base.with_suffix(".png")

    assert ansi_file.exists()
    assert txt_file.exists()
    assert not png_file.exists()

    assert "Hello" in txt_file.read_text(encoding="utf-8")
