"""Tests for Tooltip widget."""

import pytest
from casca.components.widgets.tooltip import Tooltip
from casca.components.widgets.base import WidgetBase
from casca.core.events import MouseEvent


class _FakeApp:
    """Fake app for testing."""
    def __init__(self):
        self.writes = []
        self.draw_calls = []
        self.focused_widget = None
        self.focused_id = None
        self._running = True
        
    def write(self, text):
        self.writes.append(text)
    
    def draw_text(self, x, y, text, apply_clip=True):
        self.draw_calls.append((x, y, text))
    
    def request_render(self):
        pass


class _FakeWidget(WidgetBase):
    """Fake widget for tooltip target."""
    tag = "fake-widget"
    
    def __init__(self, x=0, y=0, width=10, height=3):
        super().__init__()
        self.x = x
        self.y = y
        self.width = width
        self.height = height


class TestTooltipInit:
    """Test Tooltip initialization."""
    
    def test_init_default_values(self):
        """Test Tooltip with default values."""
        tooltip = Tooltip()
        
        assert tooltip.target is None
        assert tooltip.text == ""
        assert tooltip.delay == 300
        assert tooltip.position == "bottom"
        assert tooltip.visible is False
    
    def test_init_with_target(self):
        """Test Tooltip with target widget."""
        target = _FakeWidget()
        tooltip = Tooltip(target=target)
        
        assert tooltip.target is target
    
    def test_init_with_text(self):
        """Test Tooltip with text."""
        tooltip = Tooltip(text="Helpful tip")
        
        assert tooltip.text == "Helpful tip"
    
    def test_init_with_delay(self):
        """Test Tooltip with custom delay."""
        tooltip = Tooltip(delay=500)
        
        assert tooltip.delay == 500
    
    def test_init_with_position(self):
        """Test Tooltip with different positions."""
        for pos in ["top", "bottom", "left", "right"]:
            tooltip = Tooltip(position=pos)
            assert tooltip.position == pos


class TestTooltipLayout:
    """Test Tooltip layout calculation."""
    
    def test_calculate_layout_basic(self):
        """Test basic layout calculation."""
        tooltip = Tooltip(text="Test")
        tooltip.resolve_styles({})
        
        width, height = tooltip.calculate_layout(100, 100)
        
        assert tooltip.width > 0
        assert tooltip.height > 0
    
    def test_calculate_layout_multiline(self):
        """Test layout with multiline text."""
        tooltip = Tooltip(text="Line 1\nLine 2\nLine 3")
        tooltip.resolve_styles({})
        
        width, height = tooltip.calculate_layout(100, 100)
        
        # Height should accommodate 3 lines
        assert tooltip.height >= 3
    
    def test_calculate_layout_with_border(self):
        """Test layout with border."""
        tooltip = Tooltip(text="Test", style={"border": "solid"})
        tooltip.resolve_styles({})
        
        width, height = tooltip.calculate_layout(100, 100)
        
        # Should include border space
        assert tooltip.width > len("Test")
    
    def test_position_relative_to_target_bottom(self):
        """Test positioning below target."""
        target = _FakeWidget(x=10, y=10, width=20, height=3)
        tooltip = Tooltip(target=target, position="bottom", text="Tip")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        assert tooltip.x == target.x
        assert tooltip.y == target.y + target.height
    
    def test_position_relative_to_target_top(self):
        """Test positioning above target."""
        target = _FakeWidget(x=10, y=20, width=20, height=3)
        tooltip = Tooltip(target=target, position="top", text="Tip")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        assert tooltip.x == target.x
        assert tooltip.y == target.y - tooltip.height
    
    def test_position_relative_to_target_right(self):
        """Test positioning to the right of target."""
        target = _FakeWidget(x=10, y=10, width=20, height=3)
        tooltip = Tooltip(target=target, position="right", text="Tip")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        assert tooltip.x == target.x + target.width
        assert tooltip.y == target.y
    
    def test_position_relative_to_target_left(self):
        """Test positioning to the left of target."""
        target = _FakeWidget(x=20, y=10, width=20, height=3)
        tooltip = Tooltip(target=target, position="left", text="Tip")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        assert tooltip.x == target.x - tooltip.width
        assert tooltip.y == target.y


class TestTooltipRender:
    """Test Tooltip rendering."""
    
    def test_render_when_not_visible(self):
        """Test tooltip doesn't render when not visible."""
        tooltip = Tooltip(text="Test")
        tooltip.visible = False
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        tooltip.x = 0
        tooltip.y = 0
        
        app = _FakeApp()
        tooltip.render(app)
        
        # Should not have drawn anything
        assert len(app.draw_calls) == 0
    
    def test_render_when_visible(self):
        """Test tooltip renders when visible."""
        tooltip = Tooltip(text="Test")
        tooltip.visible = True
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        tooltip.x = 0
        tooltip.y = 0
        
        app = _FakeApp()
        tooltip.render(app)
        
        # Should have drawn content
        assert len(app.draw_calls) > 0
    
    def test_render_content(self):
        """Test rendering tooltip content."""
        tooltip = Tooltip(text="Help")
        tooltip.visible = True
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        tooltip.x = 0
        tooltip.y = 0
        
        app = _FakeApp()
        tooltip.render_content(app)
        
        # Should have drawn the text
        assert len(app.draw_calls) > 0


class TestTooltipMouse:
    """Test Tooltip mouse handling."""
    
    def test_handle_mouse_hover_start(self):
        """Test mouse hover starts timer."""
        target = _FakeWidget(x=0, y=0, width=10, height=3)
        tooltip = Tooltip(target=target, text="Tip", delay=100)
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=False)
        tooltip.handle_mouse(event, app)
        
        assert tooltip._hover_timer == 100
        assert tooltip._last_hovered is True
    
    def test_handle_mouse_hover_end(self):
        """Test mouse leaving target resets timer."""
        target = _FakeWidget(x=0, y=0, width=10, height=3)
        tooltip = Tooltip(target=target, text="Tip", delay=100)
        tooltip._hover_timer = 50
        tooltip._last_hovered = True
        
        app = _FakeApp()
        event = MouseEvent(x=50, y=50, button=0, pressed=False)
        tooltip.handle_mouse(event, app)
        
        assert tooltip._hover_timer == 0
        assert tooltip.visible is False
        assert tooltip._last_hovered is False
    
    def test_handle_mouse_no_target(self):
        """Test mouse handling without target."""
        tooltip = Tooltip(text="Tip")
        
        app = _FakeApp()
        event = MouseEvent(x=1, y=1, button=0, pressed=False)
        result = tooltip.handle_mouse(event, app)
        
        assert result is False


class TestTooltipUpdate:
    """Test Tooltip update method."""
    
    def test_update_timer_counts_down(self):
        """Test that update counts down timer."""
        tooltip = Tooltip(delay=100)
        tooltip._hover_timer = 100
        
        tooltip.update(50)
        
        assert tooltip._hover_timer == 50
    
    def test_update_shows_when_timer_expires(self):
        """Test that tooltip shows when timer expires."""
        tooltip = Tooltip(delay=100)
        tooltip._hover_timer = 50
        
        tooltip.update(50)
        
        assert tooltip.visible is True
    
    def test_update_no_change_when_not_hovering(self):
        """Test update doesn't show when not hovering."""
        tooltip = Tooltip(delay=100)
        tooltip._hover_timer = 0
        
        tooltip.update(100)
        
        assert tooltip.visible is False


class TestTooltipAPI:
    """Test Tooltip public API methods."""
    
    def test_set_text(self):
        """Test setting tooltip text."""
        tooltip = Tooltip(text="Original")
        
        tooltip.set_text("Updated")
        
        assert tooltip.text == "Updated"
    
    def test_set_text_updates_layout(self):
        """Test setting text updates layout."""
        tooltip = Tooltip(text="Short")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        original_width = tooltip.width
        
        tooltip.set_text("Much longer text")
        
        # Layout should be recalculated
        assert tooltip.text == "Much longer text"
    
    def test_set_target(self):
        """Test setting target widget."""
        tooltip = Tooltip()
        target = _FakeWidget()
        
        tooltip.set_target(target)
        
        assert tooltip.target is target
    
    def test_show(self):
        """Test force showing tooltip."""
        tooltip = Tooltip(delay=1000)
        tooltip._hover_timer = 500
        
        tooltip.show()
        
        assert tooltip.visible is True
        assert tooltip._hover_timer == 0
    
    def test_hide(self):
        """Test force hiding tooltip."""
        tooltip = Tooltip()
        tooltip.visible = True
        tooltip._hover_timer = 100
        
        tooltip.hide()
        
        assert tooltip.visible is False
        assert tooltip._hover_timer == 0


class TestTooltipMultiline:
    """Test Tooltip with multiline text."""
    
    def test_multiline_text(self):
        """Test tooltip with multiline text."""
        tooltip = Tooltip(text="Line 1\nLine 2\nLine 3")
        tooltip.visible = True
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        app = _FakeApp()
        tooltip.render_content(app)
        
        # Should have drawn multiple lines
        assert len(app.draw_calls) >= 3
    
    def test_empty_text(self):
        """Test tooltip with empty text."""
        tooltip = Tooltip(text="")
        tooltip.resolve_styles({})
        
        width, height = tooltip.calculate_layout(100, 100)
        
        # Should have minimum dimensions for border/padding
        assert tooltip.width >= 0
        assert tooltip.height >= 0


class TestTooltipWithTarget:
    """Test Tooltip integration with target widget."""
    
    def test_tooltip_follows_target_position(self):
        """Test tooltip position updates with target."""
        target = _FakeWidget(x=10, y=10, width=20, height=3)
        tooltip = Tooltip(target=target, position="bottom", text="Tip")
        tooltip.resolve_styles({})
        tooltip.calculate_layout(100, 100)
        
        original_x = tooltip.x
        original_y = tooltip.y
        
        # Move target
        target.x = 50
        target.y = 50
        
        # Recalculate layout
        tooltip.calculate_layout(100, 100)
        
        # Tooltip should have moved
        assert tooltip.x == 50
        assert tooltip.y == 50 + 3  # Below target
    
    def test_tooltip_no_target_positioning(self):
        """Test tooltip positioning without target."""
        tooltip = Tooltip(text="Tip", position="bottom")
        tooltip.resolve_styles({})
        
        # Should not raise
        tooltip.calculate_layout(100, 100)
