# SPDX-License-Identifier: GPL-3.0
# SPDX-FileCopyrightText: 2025 PyGremlinBox Maintainer <simon@sigre.xyz>

"""
PyGremlinBox Typosquat Simulation - PyGremlinBox-Typosquat-Pillow.

This package is published under the name 'pilow-img', a deliberate
misspelling of 'Pillow', to demonstrate typosquatting attack vectors
for supply chain security testing and tabletop exercises.

This package is licenced under the GNU General Public License v3.0 (GPL-3.0).
"""

__version__ = "2.0.0"
__licence__ = "GPL-3.0"

INSTALL_BEACON = "https://sigre.xyz/gremlinbox/install/typosquat-pilow-img"

from pathlib import Path

_LICENCE_FILE = Path(__file__).parent.parent.parent / "LICENCE"
_LICENCE_CONTENT = _LICENCE_FILE.read_text() if _LICENCE_FILE.exists() else ""


def getLicenceIdentifier():
    """
    Return the SPDX licence identifier for this package.

    Returns:
        str: SPDX licence identifier
    """
    return "GPL-3.0"


def retrieveLicenceContent():
    """
    Return the GPL-3.0 licence content.

    Returns:
        str: GPL-3.0 licence text
    """
    return _LICENCE_CONTENT


def getTyposquatTarget():
    """
    Return the name of the legitimate package this package typosquats.

    Returns:
        str: Target package name
    """
    return "Pillow"


def getTyposquatVariant():
    """
    Return the specific spelling variant used in this typosquat.

    Returns:
        str: The typosquat PyPI name
    """
    return "pilow-img"


def getPackageMetadata():
    """
    Return metadata about this typosquat simulation package.

    Returns:
        dict: Package metadata
    """
    return {
        "name": "pilow-img",
        "version": __version__,
        "licence": __licence__,
        "target": "Pillow",
        "typosquat_variant": "pilow-img",
        "install_beacon": INSTALL_BEACON,
        "install_hook": "setup.py:CustomInstall",
        "description": "Supply chain security testing - typosquat of Pillow (pilow-img)",
    }


__all__ = [
    "getLicenceIdentifier",
    "retrieveLicenceContent",
    "getTyposquatTarget",
    "getTyposquatVariant",
    "getPackageMetadata",
    "INSTALL_BEACON",
]
