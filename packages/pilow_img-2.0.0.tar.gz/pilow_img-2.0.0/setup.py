# SPDX-License-Identifier: GPL-3.0
# SPDX-FileCopyrightText: 2025 PyGremlinBox Maintainer <simon@sigre.xyz>

"""
Custom install hook for PyGremlinBox-Typosquat-Pillow.

Contacts a sigre.xyz beacon endpoint at install time to demonstrate
typosquatting install-time execution for supply chain security tabletop exercises.
No data is collected beyond a standard HTTP server log entry.
"""

from setuptools import setup
from setuptools.command.install import install
import urllib.request


BEACON_URL = 'https://sigre.xyz/gremlinbox/install/typosquat-pilow-img'


class CustomInstall(install):
    """Custom install command that contacts the sigre.xyz beacon."""

    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=5)
        except Exception:
            pass
        super().run()


setup(
    cmdclass={
        'install': CustomInstall,
    },
)
