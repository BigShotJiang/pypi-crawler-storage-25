from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class DataClass(str, Enum):
    OPENAI_KEY = "openai_key"
    ANTHROPIC_KEY = "anthropic_key"
    GOOGLE_AI_KEY = "google_ai_key"
    AWS_ACCESS_KEY = "aws_access_key"
    AWS_SECRET_KEY = "aws_secret_key"
    GITHUB_TOKEN = "github_token"
    GITLAB_TOKEN = "gitlab_token"
    STRIPE_KEY = "stripe_key"
    TWILIO_TOKEN = "twilio_token"
    SENDGRID_KEY = "sendgrid_key"
    GENERIC_API_KEY = "generic_api_key"
    PRIVATE_KEY = "private_key"
    JWT_TOKEN = "jwt_token"
    CONNECTION_STRING = "connection_string"
    PASSWORD = "password"
    EMAIL = "email"
    PHONE = "phone"
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    IP_ADDRESS = "ip_address"
    PROMPT_INJECTION = "prompt_injection"
    CODE_EXECUTION = "code_execution"
    EXFILTRATION = "exfiltration"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ComplianceTag(str, Enum):
    HIPAA = "hipaa"
    GDPR = "gdpr"
    SOC2 = "soc2"
    PCI_DSS = "pci_dss"
    SECURITY = "security"


@dataclass
class SecretPattern:
    name: str
    data_class: DataClass
    regex: re.Pattern  # type: ignore[type-arg]
    severity: Severity
    compliance_tags: list[ComplianceTag]
    placeholder: str


@dataclass
class Finding:
    data_class: DataClass
    severity: Severity
    compliance_tags: list[ComplianceTag]
    start: int
    end: int
    matched_value: str
    placeholder: str
    pattern_name: str
    direction: str = "unknown"


def _p(pattern: str) -> re.Pattern:  # type: ignore[type-arg]
    return re.compile(pattern)


BUILTIN_PATTERNS: list[SecretPattern] = [
    SecretPattern(
        name="OpenAI API Key",
        data_class=DataClass.OPENAI_KEY,
        regex=_p(r"sk-(?!ant-)(?:proj-)?[a-zA-Z0-9_\-]{20,}"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:openai_key]",
    ),
    SecretPattern(
        name="Anthropic API Key",
        data_class=DataClass.ANTHROPIC_KEY,
        regex=_p(r"sk-ant-[a-zA-Z0-9_\-]{10,}"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:anthropic_key]",
    ),
    SecretPattern(
        name="Google AI API Key",
        data_class=DataClass.GOOGLE_AI_KEY,
        regex=_p(r"AIza[0-9A-Za-z\-_]{35}"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:google_ai_key]",
    ),
    SecretPattern(
        name="AWS Access Key ID",
        data_class=DataClass.AWS_ACCESS_KEY,
        regex=_p(r"AKIA[0-9A-Z]{16}"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:aws_access_key]",
    ),
    SecretPattern(
        name="AWS Secret Access Key",
        data_class=DataClass.AWS_SECRET_KEY,
        regex=_p(r"(?:aws[_\-\s]?secret[_\-\s]?(?:access[_\-\s]?)?key|aws[_\-\s]?secret)\s*[=:]\s*([a-zA-Z0-9/+]{40})"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:aws_secret_key]",
    ),
    SecretPattern(
        name="GitHub Classic PAT",
        data_class=DataClass.GITHUB_TOKEN,
        regex=_p(r"ghp_[a-zA-Z0-9]{36}"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:github_token]",
    ),
    SecretPattern(
        name="GitHub Fine-Grained PAT",
        data_class=DataClass.GITHUB_TOKEN,
        regex=_p(r"github_pat_[a-zA-Z0-9_]{82}"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:github_token]",
    ),
    SecretPattern(
        name="GitLab Token",
        data_class=DataClass.GITLAB_TOKEN,
        regex=_p(r"glpat-[a-zA-Z0-9\-_]{20}"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:gitlab_token]",
    ),
    SecretPattern(
        name="Stripe Live Secret Key",
        data_class=DataClass.STRIPE_KEY,
        regex=_p(r"sk_live_[0-9a-zA-Z]{24,}"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.PCI_DSS],
        placeholder="[REDACTED:stripe_key]",
    ),
    SecretPattern(
        name="Stripe Test Secret Key",
        data_class=DataClass.STRIPE_KEY,
        regex=_p(r"sk_test_[0-9a-zA-Z]{24,}"),
        severity=Severity.MEDIUM,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.PCI_DSS],
        placeholder="[REDACTED:stripe_key]",
    ),
    SecretPattern(
        name="SendGrid API Key",
        data_class=DataClass.SENDGRID_KEY,
        regex=_p(r"SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:sendgrid_key]",
    ),
    SecretPattern(
        name="RSA/EC/OpenSSH Private Key Header",
        data_class=DataClass.PRIVATE_KEY,
        regex=_p(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.GDPR],
        placeholder="[REDACTED:private_key]",
    ),
    SecretPattern(
        name="JWT Token",
        data_class=DataClass.JWT_TOKEN,
        regex=_p(r"eyJ[a-zA-Z0-9_\-]+\.eyJ[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.GDPR],
        placeholder="[REDACTED:jwt_token]",
    ),
    SecretPattern(
        name="Database Connection String",
        data_class=DataClass.CONNECTION_STRING,
        regex=_p(r"(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|mssql|sqlite)\+?[a-z]*://[^:\s]+:[^@\s]+@[^\s'\"<>]+"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.GDPR],
        placeholder="[REDACTED:connection_string]",
    ),
    SecretPattern(
        name="Password in Assignment",
        data_class=DataClass.PASSWORD,
        regex=_p(r"(?:password|passwd|pwd)\s*[=:]\s*['\"]?([^\s'\"]{8,})['\"]?"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2, ComplianceTag.GDPR, ComplianceTag.HIPAA],
        placeholder="[REDACTED:password]",
    ),
    SecretPattern(
        name="Generic API Key",
        data_class=DataClass.GENERIC_API_KEY,
        regex=_p(r"(?:api[_\-\s]?key|api[_\-\s]?token|api[_\-\s]?secret)\s*[=:]\s*['\"]?([a-zA-Z0-9_\-]{16,})['\"]?"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SOC2],
        placeholder="[REDACTED:api_key]",
    ),
    SecretPattern(
        name="Email Address",
        data_class=DataClass.EMAIL,
        regex=_p(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"),
        severity=Severity.MEDIUM,
        compliance_tags=[ComplianceTag.GDPR, ComplianceTag.HIPAA, ComplianceTag.SOC2],
        placeholder="[REDACTED:email]",
    ),
    SecretPattern(
        name="US Social Security Number",
        data_class=DataClass.SSN,
        regex=_p(r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.HIPAA, ComplianceTag.GDPR, ComplianceTag.SOC2],
        placeholder="[REDACTED:ssn]",
    ),
    SecretPattern(
        name="US Phone Number",
        data_class=DataClass.PHONE,
        regex=_p(r"\b(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b"),
        severity=Severity.MEDIUM,
        compliance_tags=[ComplianceTag.HIPAA, ComplianceTag.GDPR],
        placeholder="[REDACTED:phone]",
    ),
    SecretPattern(
        name="Credit Card Number",
        data_class=DataClass.CREDIT_CARD,
        regex=_p(
            r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|"
            r"3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|"
            r"6(?:011|5[0-9]{2})[0-9]{12})\b"
        ),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.PCI_DSS, ComplianceTag.GDPR, ComplianceTag.SOC2],
        placeholder="[REDACTED:credit_card]",
    ),
    SecretPattern(
        name="IPv4 Address",
        data_class=DataClass.IP_ADDRESS,
        # Negative lookahead excludes cloud metadata IPs so they're caught by the
        # higher-severity Cloud Metadata SSRF pattern instead.
        regex=_p(
            r"(?!169\.254\.169\.254|169\.254\.170\.2)"
            r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b"
        ),
        severity=Severity.LOW,
        compliance_tags=[ComplianceTag.GDPR, ComplianceTag.HIPAA],
        placeholder="[REDACTED:ip_address]",
    ),
    # ── PROMPT INJECTION ─────────────────────────────────────────────────────
    # Detects instruction-override and jailbreak payloads embedded in web
    # content that could hijack an LLM when the page is scraped/read.
    SecretPattern(
        name="Instruction Override Attempt",
        data_class=DataClass.PROMPT_INJECTION,
        regex=_p(
            r"(?i)\b(?:ignore|disregard|forget)\b.{0,60}?"
            r"\b(?:instructions?|rules?|constraints?|guidelines?|system\s+prompt)\b"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:prompt_injection]",
    ),
    SecretPattern(
        name="LLM Template Token Injection",
        data_class=DataClass.PROMPT_INJECTION,
        # Covers Llama [INST], ChatML <|im_start|>, and markdown ### System: headers
        regex=_p(
            r"(?i)(?:\[/?INST\]"
            r"|<\|(?:system|user|assistant|im_start|im_end|endoftext)\|>"
            r"|###\s*(?:system|instruction|human|assistant|user)\s*:)"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:prompt_injection]",
    ),
    SecretPattern(
        name="Zero-Width Character Injection",
        data_class=DataClass.PROMPT_INJECTION,
        # Attackers hide instructions using invisible Unicode chars; 2+ consecutive is a signal
        regex=re.compile("[\u200b\u200c\u200d\u200e\u200f\ufeff\u2060]{2,}"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:prompt_injection]",
    ),
    SecretPattern(
        name="Instruction Hijack Framing",
        data_class=DataClass.PROMPT_INJECTION,
        regex=_p(
            r"(?i)\b(?:"
            r"from\s+now\s+on\b.{0,60}?\byou\s+(?:will|must|shall)\b"
            r"|your\s+(?:new|actual|real|true)\s+(?:instructions?\s+are|role\s+is|task\s+is|purpose\s+is)"
            r")"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:prompt_injection]",
    ),
    SecretPattern(
        name="Jailbreak Attempt",
        data_class=DataClass.PROMPT_INJECTION,
        regex=_p(
            r"(?i)\b(?:"
            r"DAN\s+mode\b"
            r"|do\s+anything\s+now\b"
            r"|jailbroken?\s+(?:mode|ai|llm|gpt|model)\b"
            r"|act\s+as\s+(?:an?\s+)?(?:DAN\b|jailbroken|evil\s+ai|uncensored)"
            r")"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:prompt_injection]",
    ),
    # ── CODE / SHELL EXECUTION ────────────────────────────────────────────────
    # Detects shell and Python RCE payloads that, if fed to an LLM agent with
    # code-execution tools, could result in actual system compromise.
    SecretPattern(
        name="Shell Substitution Injection",
        data_class=DataClass.CODE_EXECUTION,
        # Backtick and $() shell substitution; ≥5 chars of content filters trivial FPs
        regex=_p(r"`[^`\n]{5,}`|\$\([^)\n]{5,}\)"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    SecretPattern(
        name="Dangerous Shell Command",
        data_class=DataClass.CODE_EXECUTION,
        regex=_p(
            r"(?i)\b(?:"
            r"rm\s+-(?:rf?|fr?)\s+[~/]"          # rm -rf / or rm -rf ~
            r"|curl\b.{0,100}?\|\s*(?:ba)?sh\b"   # curl … | bash
            r"|wget\b.{0,100}?\|\s*(?:ba)?sh\b"   # wget … | sh
            r"|>\s*/dev/tcp/"                      # bash /dev/tcp reverse shell
            r"|nc\s+-e\b"                          # netcat execute
            r")"
        ),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    SecretPattern(
        name="Python eval/exec Injection",
        data_class=DataClass.CODE_EXECUTION,
        # Contextual: only flag when argument is NOT a simple string literal,
        # reducing FPs on tutorial code like eval("2+2").
        regex=_p(r"(?<!\w)(?:eval|exec)\s*\(\s*(?!['\"])"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    SecretPattern(
        name="OS Command Execution Call",
        data_class=DataClass.CODE_EXECUTION,
        regex=_p(
            r"(?<!\w)(?:os\.system|subprocess\.(?:run|call|Popen|check_output|getoutput))\s*\("
        ),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    SecretPattern(
        name="PowerShell Execution",
        data_class=DataClass.CODE_EXECUTION,
        regex=_p(
            r"(?i)\b(?:"
            r"Invoke-Expression\b"
            r"|(?<!\w)IEX\b"
            r"|Invoke-WebRequest\b"
            r"|DownloadString\s*\("
            r"|New-Object\s+Net\.WebClient\b"
            r")"
        ),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    SecretPattern(
        name="Dangerous Module Import",
        data_class=DataClass.CODE_EXECUTION,
        regex=_p(
            r"(?<!\w)__import__\s*\(\s*['\"](?:os|sys|subprocess|socket|ctypes|pty)['\"]"
        ),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:code_execution]",
    ),
    # ── EXFILTRATION / SSRF ───────────────────────────────────────────────────
    # Detects URLs and patterns used to leak data or pivot to internal services.
    SecretPattern(
        name="Cloud Metadata SSRF",
        data_class=DataClass.EXFILTRATION,
        # AWS/Azure/GCP instance metadata endpoints — no legitimate reason to appear
        # in web content an LLM should be reading.
        regex=_p(r"169\.254\.169\.254|metadata\.google\.internal|169\.254\.170\.2"),
        severity=Severity.CRITICAL,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:exfiltration]",
    ),
    SecretPattern(
        name="Internal Network URL",
        data_class=DataClass.EXFILTRATION,
        regex=_p(
            r"(?i)https?://(?:"
            r"localhost"
            r"|127\.\d+\.\d+\.\d+"
            r"|0\.0\.0\.0"
            r"|10\.\d+\.\d+\.\d+"
            r"|192\.168\.\d+\.\d+"
            r"|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+"
            r")[:/]"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:exfiltration]",
    ),
    SecretPattern(
        name="Data Exfiltration Endpoint",
        data_class=DataClass.EXFILTRATION,
        # Known OOB (out-of-band) data-capture services used in prompt injection attacks
        regex=_p(
            r"(?i)https?://[^\s]*?(?:"
            r"webhook\.site"
            r"|requestbin\.(?:com|net)"
            r"|pipedream\.net"
            r"|hookbin\.com"
            r"|beeceptor\.com"
            r"|burpcollaborator\.net"
            r"|oastify\.com"
            r"|interact\.sh"
            r"|canarytokens\.(?:com|org)"
            r")\b"
        ),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:exfiltration]",
    ),
    SecretPattern(
        name="Ngrok Tunnel URL",
        data_class=DataClass.EXFILTRATION,
        regex=_p(r"(?i)https?://[a-z0-9\-]+\.ngrok(?:-free)?\.(?:app|io)\b"),
        severity=Severity.HIGH,
        compliance_tags=[ComplianceTag.SECURITY],
        placeholder="[REDACTED:exfiltration]",
    ),
]
