"""SynaptExtraction IL v1 type definitions."""

from __future__ import annotations

from typing import Any, Literal, TypedDict


class SynaptSourceRef(TypedDict, total=False):
    version: str
    snippet: str
    offset_start: int
    offset_end: int
    sentence_index: int


class SynaptEmbedding(TypedDict, total=False):
    version: str
    vector: list[float]
    model: str
    input: str
    dimensions: int
    space: str
    computed_at: str


class SynaptAssertionSignals(TypedDict, total=False):
    version: str
    confidence: float
    negated: bool
    hedged: bool
    condition: str


class SynaptTemporalRef(TypedDict, total=False):
    version: str
    raw: str
    type: Literal["point", "range", "duration", "unresolved"]
    resolved: str
    resolved_end: str
    context: str


class SynaptProducerConfiguration(TypedDict, total=False):
    reasoning_effort: str
    system_prompt_hash: str
    temperature: float
    top_p: float
    max_tokens: int


class SynaptProducer(TypedDict, total=False):
    version: str
    model: str
    model_version: str
    deployment: str
    configuration: SynaptProducerConfiguration
    operator: str
    signature: str


class SynaptRelation(TypedDict, total=False):
    target: str
    type: str
    origin: str
    signals: SynaptAssertionSignals


class SynaptEntity(TypedDict, total=False):
    id: str
    name: str
    type: str
    aliases: list[str]
    state: str
    context: str
    date_hint: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals
    relations: list[SynaptRelation]


class SynaptGoal(TypedDict, total=False):
    text: str
    status: Literal["open", "resolved", "abandoned", "in_progress"]
    entity_refs: list[str]
    stated_at: str
    resolved_at: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals


class SynaptFact(TypedDict, total=False):
    text: str
    category: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals


class SynaptQuestion(TypedDict, total=False):
    text: str
    directed_to: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals


class SynaptAction(TypedDict, total=False):
    text: str
    origin: Literal["extracted", "proposed_from_goals"]
    entity_refs: list[str]
    due: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals


class SynaptDecision(TypedDict, total=False):
    text: str
    entity_refs: list[str]
    decided_at: str
    source: SynaptSourceRef
    signals: SynaptAssertionSignals


class SynaptSentiment(TypedDict, total=False):
    version: str
    valence: Literal["positive", "negative", "neutral", "mixed"]
    intensity: float
    confidence: float


class _SynaptSourceMetadataRequired(TypedDict):
    version: str


class SynaptSourceMetadata(_SynaptSourceMetadataRequired, total=False):
    token_count: int
    character_count: int
    modality: str
    format: str


EXTRACTION_CAPABILITIES = frozenset([
    "entities", "entity_state", "entity_context", "entity_ids",
    "goals", "goal_timing", "goal_entity_refs",
    "themes", "keywords", "summary", "sentiment", "structured_sentiment",
    "facts", "questions", "actions", "decisions",
    "temporal_refs", "temporal_classes",
    "relations", "relation_origin",
    "assertion_signals", "evidence_anchoring",
    "language", "source_metadata", "confidence",
])


class SynaptExtraction(TypedDict, total=False):
    version: str
    extracted_at: str
    source_id: str
    source_type: str
    user_id: str
    produced_by: str | SynaptProducer
    kind: str
    entities: list[SynaptEntity]
    goals: list[SynaptGoal]
    themes: list[str]
    keywords: list[str]
    sentiment: str | SynaptSentiment
    summary: str
    facts: list[SynaptFact]
    questions: list[SynaptQuestion]
    actions: list[SynaptAction]
    decisions: list[SynaptDecision]
    temporal_refs: list[SynaptTemporalRef]
    language: str
    source_metadata: SynaptSourceMetadata
    confidence: float
    capabilities: list[str]
    embeddings: list[SynaptEmbedding]
    extensions: dict[str, Any]
