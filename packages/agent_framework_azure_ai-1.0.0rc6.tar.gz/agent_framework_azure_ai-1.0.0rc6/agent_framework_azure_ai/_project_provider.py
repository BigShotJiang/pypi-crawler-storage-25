# Copyright (c) Microsoft. All rights reserved.

from __future__ import annotations

import logging
import sys
from collections.abc import Callable, Mapping, MutableMapping, Sequence
from typing import Any, Generic, cast

from agent_framework import (
    AGENT_FRAMEWORK_USER_AGENT,
    Agent,
    BaseContextProvider,
    FunctionTool,
    MiddlewareTypes,
    normalize_tools,
)
from agent_framework._mcp import MCPTool
from agent_framework._settings import load_settings
from agent_framework._tools import ToolTypes
from azure.ai.projects.aio import AIProjectClient
from azure.ai.projects.models import (
    AgentVersionDetails,
    PromptAgentDefinition,
    PromptAgentDefinitionTextOptions,
)
from azure.ai.projects.models import (
    FunctionTool as AzureFunctionTool,
)

from ._client import AzureAIClient, AzureAIProjectAgentOptions  # pyright: ignore[reportDeprecated]
from ._entra_id_authentication import AzureCredentialTypes
from ._shared import AzureAISettings, create_text_format_config, from_azure_ai_tools, to_azure_ai_tools

if sys.version_info >= (3, 13):
    from typing import TypeVar  # type: ignore # pragma: no cover
    from warnings import deprecated  # type: ignore # pragma: no cover
else:
    from typing_extensions import TypeVar, deprecated  # type: ignore # pragma: no cover
if sys.version_info >= (3, 11):
    from typing import Self, TypedDict  # type: ignore # pragma: no cover
else:
    from typing_extensions import Self, TypedDict  # type: ignore # pragma: no cover


logger = logging.getLogger("agent_framework.azure")


# Type variable for options - allows typed Agent[OptionsT] returns
# Default matches AzureAIClient's default options type
OptionsCoT = TypeVar(
    "OptionsCoT",
    bound=TypedDict,  # type: ignore[valid-type]
    default="AzureAIProjectAgentOptions",
    covariant=True,
)


@deprecated("AzureAIProjectAgentProvider is deprecated. Use FoundryAgent instead.")
class AzureAIProjectAgentProvider(Generic[OptionsCoT]):
    """Deprecated provider for Azure AI Agent Service (Responses API).

    This provider is deprecated. Use ``FoundryAgent`` instead to connect to
    pre-configured agents in Foundry.

    Examples:
        Using with explicit AIProjectClient:

        .. code-block:: python

            from agent_framework.azure import AzureAIProjectAgentProvider
            from azure.ai.projects.aio import AIProjectClient
            from azure.identity.aio import DefaultAzureCredential

            async with AIProjectClient(endpoint, credential) as client:
                provider = AzureAIProjectAgentProvider(client)
                agent = await provider.create_agent(
                    name="MyAgent",
                    model="gpt-4",
                    instructions="You are a helpful assistant.",
                )
                response = await agent.run("Hello!")

        Using with credential and endpoint (auto-creates client):

        .. code-block:: python

            from agent_framework.azure import AzureAIProjectAgentProvider
            from azure.identity.aio import DefaultAzureCredential

            async with AzureAIProjectAgentProvider(credential=credential) as provider:
                agent = await provider.create_agent(
                    name="MyAgent",
                    model="gpt-4",
                    instructions="You are a helpful assistant.",
                )
                response = await agent.run("Hello!")
    """

    def __init__(
        self,
        project_client: AIProjectClient | None = None,
        *,
        project_endpoint: str | None = None,
        model: str | None = None,
        credential: AzureCredentialTypes | None = None,
        allow_preview: bool | None = None,
        env_file_path: str | None = None,
        env_file_encoding: str | None = None,
    ) -> None:
        """Initialize an Azure AI Project Agent Provider.

        Args:
            project_client: An existing AIProjectClient to use. If not provided, one will be created.
            project_endpoint: The Azure AI Project endpoint URL.
                Can also be set via environment variable AZURE_AI_PROJECT_ENDPOINT.
                Ignored when a project_client is passed.
            model: The default model deployment name to use for agent creation.
                Can also be set via environment variable AZURE_AI_MODEL_DEPLOYMENT_NAME.
            credential: Azure credential for authentication. Accepts a TokenCredential,
                AsyncTokenCredential, or a callable token provider.
                Required when project_client is not provided.
            allow_preview: Enables preview opt-in on internally-created ``AIProjectClient``.
            env_file_path: Path to environment file for loading settings.
            env_file_encoding: Encoding of the environment file.

        Raises:
            ValueError: If required parameters are missing or invalid.
        """
        self._settings = load_settings(
            AzureAISettings,
            env_prefix="AZURE_AI_",
            project_endpoint=project_endpoint,
            model_deployment_name=model,
            env_file_path=env_file_path,
            env_file_encoding=env_file_encoding,
        )

        # Track whether we should close client connection
        self._should_close_client = False

        if project_client is None:
            resolved_endpoint = self._settings.get("project_endpoint")
            if not resolved_endpoint:
                raise ValueError(
                    "Azure AI project endpoint is required. Set via 'project_endpoint' parameter "
                    "or 'AZURE_AI_PROJECT_ENDPOINT' environment variable."
                )

            if not credential:
                raise ValueError("Azure credential is required when project_client is not provided.")

            project_client_kwargs: dict[str, Any] = {
                "endpoint": resolved_endpoint,
                "credential": credential,  # type: ignore[arg-type]
                "user_agent": AGENT_FRAMEWORK_USER_AGENT,
            }
            if allow_preview is not None:
                project_client_kwargs["allow_preview"] = allow_preview
            project_client = AIProjectClient(**project_client_kwargs)
            self._should_close_client = True

        self._project_client = project_client

    async def create_agent(
        self,
        name: str,
        model: str | None = None,
        instructions: str | None = None,
        description: str | None = None,
        tools: ToolTypes | Callable[..., Any] | Sequence[ToolTypes | Callable[..., Any]] | None = None,
        default_options: OptionsCoT | None = None,
        middleware: Sequence[MiddlewareTypes] | None = None,
        context_providers: Sequence[BaseContextProvider] | None = None,
    ) -> Agent[OptionsCoT]:
        """Create a new agent on the Azure AI service and return a local Agent wrapper.

        Args:
            name: The name of the agent to create.
            model: The model deployment name to use. Falls back to AZURE_AI_MODEL_DEPLOYMENT_NAME
                environment variable if not provided.
            instructions: Instructions for the agent.
            description: A description of the agent.
            tools: Tools to make available to the agent.
            default_options: A TypedDict containing default chat options for the agent.
                These options are applied to every run unless overridden.
            middleware: List of middleware to intercept agent and function invocations.
            context_providers: Context providers to include during agent invocation.

        Returns:
            Agent: A Agent instance configured with the created agent.

        Raises:
            ValueError: If required parameters are missing.
        """
        # Resolve model from parameter or environment variable
        resolved_model = model or self._settings.get("model_deployment_name")
        if not resolved_model:
            raise ValueError(
                "Model deployment name is required. Provide 'model' parameter "
                "or set 'AZURE_AI_MODEL_DEPLOYMENT_NAME' environment variable."
            )

        # Extract options from default_options if present
        opts: dict[str, Any] = dict(default_options) if default_options else {}
        response_format = opts.get("response_format")
        rai_config = opts.get("rai_config")
        reasoning = opts.get("reasoning")

        args: dict[str, Any] = {"model": resolved_model}

        if instructions:
            args["instructions"] = instructions
        if response_format and isinstance(response_format, (type, dict)):
            args["text"] = PromptAgentDefinitionTextOptions(
                format=create_text_format_config(response_format)  # type: ignore[arg-type]
            )
        if rai_config:
            args["rai_config"] = rai_config
        if reasoning:
            args["reasoning"] = reasoning

        # Normalize tools and separate MCP tools from other tools
        normalized_tools = normalize_tools(tools)
        mcp_tools: list[MCPTool] = []
        non_mcp_tools: list[FunctionTool | MutableMapping[str, Any]] = []

        if normalized_tools:
            for tool in normalized_tools:
                if isinstance(tool, MCPTool):
                    mcp_tools.append(tool)
                elif isinstance(tool, (FunctionTool, MutableMapping)):
                    non_mcp_tools.append(tool)  # type: ignore[reportUnknownArgumentType]

        # Connect MCP tools and discover their functions BEFORE creating the agent
        # This is required because Azure AI Responses API doesn't accept tools at request time
        mcp_discovered_functions: list[FunctionTool] = []
        for mcp_tool in mcp_tools:
            if not mcp_tool.is_connected:
                await mcp_tool.connect()
            mcp_discovered_functions.extend(mcp_tool.functions)

        # Combine non-MCP tools with discovered MCP functions for Azure AI
        all_tools_for_azure: list[FunctionTool | MutableMapping[str, Any]] = list(non_mcp_tools)
        all_tools_for_azure.extend(mcp_discovered_functions)

        if all_tools_for_azure:
            args["tools"] = to_azure_ai_tools(all_tools_for_azure)

        create_version_kwargs: dict[str, Any] = {
            "agent_name": name,
            "definition": PromptAgentDefinition(**args),
            "description": description,
        }

        created_agent = await self._project_client.agents.create_version(**create_version_kwargs)

        return self._to_chat_agent_from_details(
            created_agent,
            normalized_tools,
            default_options=default_options,
            middleware=middleware,
            context_providers=context_providers,
        )

    async def get_agent(
        self,
        *,
        name: str | None = None,
        reference: Mapping[str, str | None] | None = None,
        tools: ToolTypes | Callable[..., Any] | Sequence[ToolTypes | Callable[..., Any]] | None = None,
        default_options: OptionsCoT | None = None,
        middleware: Sequence[MiddlewareTypes] | None = None,
        context_providers: Sequence[BaseContextProvider] | None = None,
    ) -> Agent[OptionsCoT]:
        """Retrieve an existing agent from the Azure AI service and return a local Agent wrapper.

        You must provide either name or reference. Use `as_agent()` if you already have
        AgentVersionDetails and want to avoid an async call.

        Args:
            name: The name of the agent to retrieve (fetches latest version).
            reference: Mapping containing the agent's ``name`` and optionally a specific ``version``.
            tools: Tools to make available to the agent. Required if the agent has function tools.
            default_options: A TypedDict containing default chat options for the agent.
                These options are applied to every run unless overridden.
            middleware: List of middleware to intercept agent and function invocations.
            context_providers: Context providers to include during agent invocation.

        Returns:
            Agent: A Agent instance configured with the retrieved agent.

        Raises:
            ValueError: If no identifier is provided or required tools are missing.
        """
        existing_agent: AgentVersionDetails

        reference_name = str(reference.get("name")) if reference and reference.get("name") else None
        reference_version = str(reference.get("version")) if reference and reference.get("version") else None

        if reference_name and reference_version:
            # Fetch specific version
            existing_agent = await self._project_client.agents.get_version(
                agent_name=reference_name, agent_version=reference_version
            )
        elif agent_name := (reference_name if reference_name else name):
            # Fetch latest version
            details = await self._project_client.agents.get(agent_name=agent_name)
            existing_agent = details.versions.latest
        else:
            raise ValueError("Either name or reference must be provided to get an agent.")

        if not isinstance(existing_agent.definition, PromptAgentDefinition):
            raise ValueError("Agent definition must be PromptAgentDefinition to get a Agent.")

        # Validate that required function tools are provided
        self._validate_function_tools(existing_agent.definition.tools, tools)

        return self._to_chat_agent_from_details(
            existing_agent,
            normalize_tools(tools),
            default_options=default_options,
            middleware=middleware,
            context_providers=context_providers,
        )

    def as_agent(
        self,
        details: AgentVersionDetails,
        tools: ToolTypes | Callable[..., Any] | Sequence[ToolTypes | Callable[..., Any]] | None = None,
        default_options: OptionsCoT | None = None,
        middleware: Sequence[MiddlewareTypes] | None = None,
        context_providers: Sequence[BaseContextProvider] | None = None,
    ) -> Agent[OptionsCoT]:
        """Wrap an SDK agent version object into a Agent without making HTTP calls.

        Use this when you already have an AgentVersionDetails from a previous API call.

        Args:
            details: The AgentVersionDetails to wrap.
            tools: Tools to make available to the agent. Required if the agent has function tools.
            default_options: A TypedDict containing default chat options for the agent.
                These options are applied to every run unless overridden.
            middleware: List of middleware to intercept agent and function invocations.
            context_providers: Context providers to include during agent invocation.

        Returns:
            Agent: A Agent instance configured with the agent version.

        Raises:
            ValueError: If the agent definition is not a PromptAgentDefinition or required tools are missing.
        """
        if not isinstance(details.definition, PromptAgentDefinition):
            raise ValueError("Agent definition must be PromptAgentDefinition to create a Agent.")

        # Validate that required function tools are provided
        self._validate_function_tools(details.definition.tools, tools)

        return self._to_chat_agent_from_details(
            details,
            normalize_tools(tools),
            default_options=default_options,
            middleware=middleware,
            context_providers=context_providers,
        )

    def _to_chat_agent_from_details(
        self,
        details: AgentVersionDetails,
        provided_tools: Sequence[ToolTypes] | None = None,
        default_options: OptionsCoT | None = None,
        middleware: Sequence[MiddlewareTypes] | None = None,
        context_providers: Sequence[BaseContextProvider] | None = None,
    ) -> Agent[OptionsCoT]:
        """Create a Agent from an AgentVersionDetails.

        Args:
            details: The AgentVersionDetails containing the agent definition.
            provided_tools: User-provided tools (including function implementations).
                These are merged with hosted tools from the definition.
            default_options: A TypedDict containing default chat options for the agent.
                These options are applied to every run unless overridden.
            middleware: List of middleware to intercept agent and function invocations.
            context_providers: Context providers to include during agent invocation.
        """
        if not isinstance(details.definition, PromptAgentDefinition):
            raise ValueError("Agent definition must be PromptAgentDefinition to get a Agent.")

        client = AzureAIClient(  # pyright: ignore[reportDeprecated]
            project_client=self._project_client,
            agent_name=details.name,
            agent_version=details.version,
            agent_description=details.description,
            model_deployment_name=details.definition.model,
        )

        # Merge tools: hosted tools from definition + user-provided function tools
        # from_azure_ai_tools converts hosted tools (MCP, code interpreter, file search, web search)
        # but function tools need the actual implementations from provided_tools
        merged_tools = self._merge_tools(details.definition.tools, provided_tools)
        merged_default_options: dict[str, Any] = dict(default_options) if default_options is not None else {}
        merged_default_options.setdefault("model_id", details.definition.model)

        return Agent(  # type: ignore[return-value]
            client=client,
            id=details.id,
            name=details.name,
            description=details.description,
            instructions=details.definition.instructions,
            tools=merged_tools,
            default_options=cast(Any, merged_default_options),
            middleware=middleware,
            context_providers=context_providers,
        )

    def _merge_tools(
        self,
        definition_tools: Sequence[Any] | None,
        provided_tools: Sequence[ToolTypes] | None,
    ) -> list[ToolTypes]:
        """Merge hosted tools from definition with user-provided function tools.

        Args:
            definition_tools: Tools from the agent definition (Azure AI format).
            provided_tools: User-provided tools (Agent Framework format), including function implementations.

        Returns:
            Combined list of tools for the Agent.
        """
        merged: list[ToolTypes] = []

        # Convert hosted tools from definition (MCP, code interpreter, file search, web search)
        # Function tools from the definition are skipped - we use user-provided implementations instead
        hosted_tools = from_azure_ai_tools(definition_tools)
        for hosted_tool in hosted_tools:
            # Skip function tool dicts - they don't have implementations
            if isinstance(hosted_tool, dict) and hosted_tool.get("type") == "function":
                continue
            merged.append(hosted_tool)

        # Add user-provided function tools and MCP tools
        if provided_tools:
            for provided_tool in provided_tools:
                # FunctionTool - has implementation for function calling
                # MCPTool - Agent handles MCP connection and tool discovery at runtime
                if isinstance(provided_tool, (FunctionTool, MCPTool)):
                    merged.append(provided_tool)  # type: ignore[reportUnknownArgumentType]

        return merged

    def _validate_function_tools(
        self,
        agent_tools: Sequence[Any] | None,
        provided_tools: ToolTypes | Callable[..., Any] | Sequence[ToolTypes | Callable[..., Any]] | None,
    ) -> None:
        """Validate that required function tools are provided."""
        # Normalize and validate function tools
        normalized_tools = normalize_tools(provided_tools)
        tool_names = {tool.name for tool in normalized_tools if isinstance(tool, FunctionTool)}

        # If function tools exist in agent definition but were not provided,
        # we need to raise an error, as it won't be possible to invoke the function.
        missing_tools = [
            tool.name
            for tool in (agent_tools or [])
            if isinstance(tool, AzureFunctionTool) and tool.name not in tool_names
        ]

        if missing_tools:
            raise ValueError(
                f"The following prompt agent definition required tools were not provided: {', '.join(missing_tools)}"
            )

    async def __aenter__(self) -> Self:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def close(self) -> None:
        """Close the provider and release resources.

        Only closes the underlying AIProjectClient if it was created by this provider.
        """
        if self._should_close_client:
            await self._project_client.close()
