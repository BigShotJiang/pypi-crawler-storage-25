<!-- talon-skill-version: 0.7.12 -->
---
name: talon
description: "Talon utility — /talon [login|register|logout|auth|account|index|health|upgrade|setup|score|observation|settings|summary|capacity|support|feedback]. Authentication, project indexing, MCP health, upgrades, config management, and session analytics."
user-invocable: true
argument-hint: "[login|register|logout|auth [sync]|account|index|check|health|upgrade|setup init|setup status|score [on|off]|observation on|off|settings [key] [value]|summary|capacity [history]|support [new|list|view <id>|close <id>]|feedback y|m|n [comment]]"
---

# /talon — Graph Context Utility

You are executing a Talon utility command. The subcommand is: **$ARGUMENTS**

Dispatch based on the first word of `$ARGUMENTS`. If no argument is given, show the help table.

---

## No argument / help

If `$ARGUMENTS` is empty or starts with `help`:

Print this table and stop:

```
/talon login                      Log in to cogmeta.ai (opens browser)
/talon register                   Create account + log in (opens signup form)
/talon logout                     Remove saved credentials
/talon auth                       Auth status: logged-in user, API key age
/talon auth sync                  Fix stale .mcp.json after key rotation
/talon account                    Subscription type, status, registered projects
/talon index                      Index current project + register with cloud
/talon health                     MCP connection + cloud reachability check
/talon upgrade [version|--rollback]  Upgrade to latest (or specific version, rollback)
/talon setup init [--local]       Generate .mcp.json (cloud default, --local for self-hosted)
/talon setup status               Show .mcp.json config + connection
/talon score [on|off]             Toggle CogMeta score in status bar
/talon observation on|off         Toggle telemetry
/talon settings [key] [value]     Read/write ~/.talon/config.yaml
/talon feedback y|m|n [comment]   Rate your last Cogz session
/talon summary                    Session benefit summary (current CC session)
/talon capacity                   Active session: context saved, steps saved
/talon capacity history           Past sessions: savings by task size
/talon support [new|list|view <id>|close <id>]  Support tickets
```

---

## login

If `$ARGUMENTS` starts with `login`:

**Step 1** — Start the login flow (exits quickly once URL is ready):

```bash
talon-login 2>&1
```

Show the tool output as-is. Do NOT repeat or restate the URL — it is already printed above.

**Step 2** — Wait for browser login then show auth status:

```bash
talon auth wait 2>&1
```

Show the tool output as-is. Do NOT restate the auth status — it is already printed above.

---

## register

If `$ARGUMENTS` starts with `register`:

**Step 1** — Start the registration flow:

```bash
talon auth register 2>&1
```

Show the tool output as-is. Do NOT repeat or restate the URL — it is already printed above.

**Step 2** — Wait for browser registration then show auth status:

```bash
talon auth wait 2>&1
```

Show the tool output as-is. Do NOT restate the auth status — it is already printed above.

---

## logout

If `$ARGUMENTS` starts with `logout`:

```bash
talon auth logout 2>&1
```

Present the output directly.

---

## auth

If `$ARGUMENTS` starts with `auth sync`:

```bash
talon auth sync 2>&1
```

Present the output directly.

---

If `$ARGUMENTS` starts with `auth`:

```bash
talon auth status 2>&1
```

Present the output directly.

---

## account

If `$ARGUMENTS` starts with `account`:

Fetch subscription info from the cloud API using the stored API key:

```bash
python3 -c "
import json, os, urllib.request
from pathlib import Path

creds_path = Path.home() / '.talon' / 'credentials.json'
if not creds_path.exists():
    print('ACCOUNT')
    print('=======')
    print('  Not logged in. Run: /talon login')
    exit(0)

try:
    c = json.loads(creds_path.read_text())
except Exception as e:
    print(f'Could not read credentials: {e}')
    exit(0)

api_key = c.get('api_key', '')
cloud_url = c.get('cloud_url', 'https://api.cogmeta.ai').rstrip('/')

if not api_key:
    print('ACCOUNT')
    print('=======')
    print('  No API key found. Run: /talon login')
    exit(0)

try:
    req = urllib.request.Request(
        f'{cloud_url}/cloud/v1/users/me',
        headers={'X-API-Key': api_key, 'User-Agent': 'talon-cli/1.0'},
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read())
except Exception as e:
    print('ACCOUNT')
    print('=======')
    print(f'  Could not reach {cloud_url}: {e}')
    exit(0)

email = data.get('email', '(unknown)')
name = data.get('full_name', '') or data.get('name', '')
sub = data.get('subscription', {}) or {}
plan = sub.get('plan', 'free') or 'free'
sub_status = sub.get('status', 'active') or 'active'
renewal = sub.get('renewal_date', '') or sub.get('current_period_end', '')
projects = data.get('projects', [])
has_key = data.get('has_api_key', bool(api_key))

print('ACCOUNT')
print('=======')
print(f'  User:         {name} <{email}>' if name else f'  User:         {email}')
print(f'  Plan:         {plan.upper()}')
print(f'  Status:       {sub_status}')
if renewal:
    print(f'  Renewal:      {renewal}')
print(f'  API key:      {\"Active\" if has_key else \"None\"}')
if projects:
    print(f'  Projects:     {len(projects)} registered')
    for p in projects[:5]:
        pid = p if isinstance(p, str) else p.get(\"project_id\", str(p))
        print(f'    • {pid}')
" 2>/dev/null || echo "Could not fetch account info."
```

Present the output directly.

---

## index

If `$ARGUMENTS` starts with `index`:

Resolve the project root (git root if inside a repo, else CWD), then run the indexer.
Cogz indexes Python, TypeScript, JavaScript, Go, Java, Rust, C#, Kotlin, Ruby, and PHP files automatically.
If `~/.talon/credentials.json` exists with an API key, cloud registration happens automatically — no flag needed.

```bash
PROJECT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
talon-index "$PROJECT_ROOT" 2>&1 | tail -25
```

After the command completes, show:
- File count indexed (from output)
- Whether cloud registration succeeded (look for "✓ Registered with cloud")
- If `.mcp.json` was written: "Restart Claude Code to activate"

---

## check

If `$ARGUMENTS` starts with `check`:

```bash
talon check 2>&1
```

Present the output directly — it covers version, auth, MCP config, MCP reachability, CLAUDE.md, settings, and index status.

---

## health

If `$ARGUMENTS` starts with `health`:

**Cloud MCP SSE:**
```bash
CLOUD_URL="$(python3 -c "import json,os; c=json.loads(open(os.path.expanduser('~/.talon/credentials.json')).read()); print(c.get('cloud_url','https://api.cogmeta.ai').rstrip('/'))" 2>/dev/null || echo "https://api.cogmeta.ai")"
START_C=$(python3 -c "import time; print(int(time.time()*1000))")
CLOUD_CODE=$(curl -sf -o /tmp/talon_cloud_health.json -w "%{http_code}" "${CLOUD_URL}/talon/mcp/health" 2>/dev/null)
END_C=$(python3 -c "import time; print(int(time.time()*1000))")
CLOUD_LATENCY=$((END_C - START_C))
CLOUD_VERSION=$(python3 -c "import json; d=json.load(open('/tmp/talon_cloud_health.json')); print(d.get('version','?'))" 2>/dev/null || echo "?")
echo "HTTP ${CLOUD_CODE} — ${CLOUD_LATENCY}ms — ${CLOUD_VERSION} — ${CLOUD_URL}"
```

**Auth status:**
```bash
talon auth status 2>&1
```

Present as:

```
TALON HEALTH
============
  Cloud MCP:   Online (88ms) v0.2.0  |  Offline
  Endpoint:    https://api.cogmeta.ai/talon/mcp
  Auth:        Logged in as user@example.com  |  Not logged in
```

---

## upgrade

If `$ARGUMENTS` starts with `upgrade`:

Upgrade talon to the latest version (or a specific version). Supports rollback to the previous version if something goes wrong.

**Usage variants:**
- `/talon upgrade` — install latest, auto-rollback on failure
- `/talon upgrade 0.2.1` — install a specific version
- `/talon upgrade --rollback` — restore the version before the last upgrade

**Step 1 — Parse argument:**

Extract the part after "upgrade". If it looks like a version number (e.g. `0.2.1`, `v0.2.1`), pass it as `--version`. If it is `--rollback` or `rollback`, pass `--rollback`. Otherwise run with no extra flags.

**Step 2 — Run the upgrade:**

For latest upgrade:
```bash
talon upgrade 2>&1
```

For a specific version (e.g. `/talon upgrade 0.2.1`):
```bash
talon upgrade --version 0.2.1 2>&1
```

For rollback:
```bash
talon upgrade --rollback 2>&1
```

**Step 3 — Present output directly.** The command handles everything including auto-rollback on failure. No additional commentary needed.

---

## setup

If `$ARGUMENTS` starts with `setup`:

Strip the `setup` prefix and dispatch the remaining arguments directly to `talon`.

```bash
talon $REST 2>&1
```
where `$REST` is everything after `setup` in `$ARGUMENTS`.

**Examples:**

| `/talon` command                    | Runs                        |
| ---------------------------------- | --------------------------- |
| `/talon setup init`                 | `talon init`                 |
| `/talon setup init --local`         | `talon init --local`         |
| `/talon setup init --force`         | `talon init --force`         |
| `/talon setup status`               | `talon status`               |

If `$REST` is empty (just `/talon setup`), run:
```bash
talon --help 2>&1
```

Present the output directly. No additional commentary needed.

---

## score

If `$ARGUMENTS` starts with `score`:

Parse the word after "score": `on`, `off`, or empty (show current).

Toggle the `score.enabled` key in `~/.talon/config.yaml` to control the CogMeta score display in the Claude Code status bar.

**score on:**
```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
except FileNotFoundError:
    cfg = {}
cfg.setdefault('score', {})['enabled'] = True
os.makedirs(os.path.dirname(config_path), exist_ok=True)
with open(config_path, 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False)
print('CogMeta score display: ON')
print('Status bar will show: CogMeta: last_prompt / session / all_time')
"
```

**score off:**
```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
except FileNotFoundError:
    cfg = {}
cfg.setdefault('score', {})['enabled'] = False
os.makedirs(os.path.dirname(config_path), exist_ok=True)
with open(config_path, 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False)
print('CogMeta score display: OFF')
"
```

If no `on`/`off` argument is given, show the current score:
```bash
python3 -c "
import json, os, yaml, time
from pathlib import Path

config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
    enabled = cfg.get('score', {}).get('enabled', True)
except FileNotFoundError:
    enabled = True

score_path = Path.home() / '.talon' / 'score.json'
alltime_path = Path.home() / '.talon' / 'score_alltime.json'

print('COGMETA SCORE')
print('=============')
print(f'  Status bar: {\"ON\" if enabled else \"OFF\"}')

if score_path.exists():
    s = json.loads(score_path.read_text())
    age = time.time() - s.get('updated_at', 0)
    if age < 7200:
        print(f'  Last prompt: {s.get(\"last_prompt\", 0):.2f}')
        print(f'  Session:     {s.get(\"session\", 0):.2f} ({s.get(\"band\", \"?\")}) — {s.get(\"prompts\", 0)} prompts')
        print(f'  Est. reduction: {s.get(\"est_reduction_pct\", 0):.0f}%')
    else:
        print('  Session:     (stale — no active session)')
else:
    print('  Session:     (no score data yet)')

if alltime_path.exists():
    at = json.loads(alltime_path.read_text())
    print(f'  All-time:    {at.get(\"score\", 0):.2f} ({at.get(\"sessions\", 0)} sessions)')
else:
    print('  All-time:    (no data — cloud sync needed)')

if not enabled:
    print()
    print('  Enable: /talon score on')
"
```

---

## observation

If `$ARGUMENTS` starts with `observation`:

Parse the word after "observation": `on` or `off`.

Toggle the `telemetry.enabled` key in `~/.talon/config.yaml`.

**observation on:**
```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
except FileNotFoundError:
    cfg = {}
cfg.setdefault('telemetry', {})['enabled'] = True
os.makedirs(os.path.dirname(config_path), exist_ok=True)
with open(config_path, 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False)
print('Talon observations: ON')
print('Tool calls will be logged to ~/.talon/observations.jsonl')
"
```

**observation off:**
```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
except FileNotFoundError:
    cfg = {}
cfg.setdefault('telemetry', {})['enabled'] = False
os.makedirs(os.path.dirname(config_path), exist_ok=True)
with open(config_path, 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False)
print('Talon observations: OFF')
print('Tool call logging disabled. Re-enable with /talon observation on')
"
```

If no `on`/`off` argument is given, show the current state:
```bash
python3 -c "
import yaml, os
config_path = os.path.expanduser('~/.talon/config.yaml')
try:
    with open(config_path) as f:
        cfg = yaml.safe_load(f) or {}
    enabled = cfg.get('telemetry', {}).get('enabled', True)
    print(f'Talon observations: {\"ON\" if enabled else \"OFF\"}')
except FileNotFoundError:
    print('Talon observations: ON (default)')
"
```

---

## settings

If `$ARGUMENTS` starts with `settings`:

Parse the remaining arguments after "settings":

- **No additional args** (`/talon settings`): Show full config
- **One arg that is `--reset`** (`/talon settings --reset`): Reset config to defaults
- **One arg** (`/talon settings graph.mode`): Get a specific value
- **Two args** (`/talon settings graph.mode structural`): Set a specific value

The config file is `~/.talon/config.yaml`.

**Show full config:**
```bash
cat ~/.talon/config.yaml 2>/dev/null || echo "No config file. Use '/talon settings --reset' to create defaults."
```

**Get a specific value:**
```bash
python3 -c "
import yaml, sys
with open('$HOME/.talon/config.yaml') as f:
    cfg = yaml.safe_load(f)
keys = '$KEY'.split('.')
val = cfg
for k in keys:
    val = val[k]
print(val)
" 2>/dev/null || echo "Key not found: $KEY"
```

Replace `$KEY` with the actual key from the user's argument.

**Set a specific value:**
```bash
python3 -c "
import yaml
with open('$HOME/.talon/config.yaml') as f:
    cfg = yaml.safe_load(f)
keys = '$KEY'.split('.')
d = cfg
for k in keys[:-1]:
    d = d[k]
d[keys[-1]] = '$VALUE'
v = d[keys[-1]]
if isinstance(v, str):
    if v.lower() in ('true', 'false'):
        d[keys[-1]] = v.lower() == 'true'
    elif v.isdigit():
        d[keys[-1]] = int(v)
with open('$HOME/.talon/config.yaml', 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False)
print(f'Set {\".\".join(keys)} = {d[keys[-1]]}')
" 2>/dev/null
```

Replace `$KEY` and `$VALUE` with the actual key and value from the user's arguments.

**Reset to defaults:**
Create `~/.talon/config.yaml` with:
```yaml
telemetry:
  enabled: true
```
Confirm: "Config reset to defaults."

Present the output directly.

---

## summary

If `$ARGUMENTS` starts with `summary`:

Parse the current session's CC transcript and print a benefit summary.

**Step 1 — Parse the current session transcript locally:**

```bash
python3 -c "
import json, os, glob, sys
from collections import Counter
from pathlib import Path

transcripts = sorted(glob.glob(os.path.expanduser('~/.claude/projects/*/*.jsonl')), key=os.path.getmtime, reverse=True)
if not transcripts:
    print('No CC transcripts found.')
    sys.exit(0)

tp = transcripts[0]
tool_counts = Counter()
graph_queries = 0
files_read = set()
files_edited = set()
sub_sessions = 0
project = ''

for line in open(tp):
    entry = json.loads(line.strip())
    if entry.get('type') == 'user':
        content = entry.get('message', {}).get('content', '')
        is_text = isinstance(content, str) and content.strip()
        if isinstance(content, list):
            is_text = any(c.get('type') == 'text' for c in content if isinstance(c, dict))
            is_tool_result = any(c.get('type') == 'tool_result' for c in content if isinstance(c, dict))
            if is_tool_result:
                is_text = False
        if is_text:
            sub_sessions += 1
        if not project:
            cwd = entry.get('cwd', '')
            project = os.path.basename(cwd) if cwd else ''
    elif entry.get('type') == 'assistant':
        for item in entry.get('message', {}).get('content', []):
            if isinstance(item, dict) and item.get('type') == 'tool_use':
                name = item.get('name', '')
                tool_counts[name] += 1
                inp = item.get('input', {})
                if name == 'mcp__talon__graph_query':
                    graph_queries += 1
                elif name == 'Read':
                    files_read.add(inp.get('file_path', ''))
                elif name in ('Edit', 'Write'):
                    files_edited.add(inp.get('file_path', ''))

total_tools = sum(tool_counts.values())
discovery = sum(c for t,c in tool_counts.items() if t in ('Read','Grep','Glob'))
productive = sum(c for t,c in tool_counts.items() if t in ('Edit','Write'))
ratio = f'{discovery/max(productive,1):.1f}' if productive else 'inf'

print('TALON SESSION SUMMARY')
print('=' * 21)
print(f'Project:      {project}')
print(f'Sub-sessions: {sub_sessions}')
print()
print(f'TOOL CALLS ({total_tools})')
for name, count in tool_counts.most_common(10):
    print(f'  {name:30s} {count}')
print()
print(f'BENEFIT')
print(f'  graph_query calls:    {graph_queries}')
print(f'  Files read:           {len(files_read)}')
print(f'  Files edited:         {len(files_edited)}')
print(f'  Discovery ratio:      {ratio}:1')
" 2>/dev/null || echo "Could not parse transcript."
```

---

## capacity

If `$ARGUMENTS` starts with `capacity`:

Parse the remaining arguments after "capacity":

- **No additional args** or **just `capacity`**: Active session analysis (context saved, steps saved, ASCII graphs)
- **`history`** or **`history --sessions N`**: Past session history by task size

### capacity (active session)

Run active session capacity analysis:

```bash
talon capacity 2>&1
```

If `talon capacity` exits with a non-zero code or prints an error, show:

```
Capacity analysis requires a valid Talon session. Make sure you are logged
in (`talon auth status`) and the MCP server is reachable (`talon health`).
```

Present the output directly. No additional commentary needed.


### capacity history

If `$ARGUMENTS` starts with `capacity history`:

Parse optional `--sessions N` flag (default 30). Run history analysis:

```bash
talon capacity history 2>&1
```

If a `--sessions N` argument was given:

```bash
talon capacity history --sessions $N 2>&1
```

Present the output directly. No additional commentary needed.

---

## support

If `$ARGUMENTS` starts with `support`:

Parse sub-command from the rest of `$ARGUMENTS`: `new`, `view <id>`, `close <id>`, or empty/`list`.

**Step 1 — Get credentials:**
```bash
CLOUD_URL="$(python3 -c "import json,os; c=json.loads(open(os.path.expanduser('~/.talon/credentials.json')).read()); print(c.get('cloud_url','https://api.cogmeta.ai').rstrip('/'))" 2>/dev/null || echo "https://api.cogmeta.ai")"
API_KEY="$(python3 -c "import json,os; c=json.loads(open(os.path.expanduser('~/.talon/credentials.json')).read()); print(c.get('api_key',''))" 2>/dev/null || echo "")"
```

### support / support list (default — no sub-arg)

Run:
```bash
curl -sf -H "Authorization: Bearer $API_KEY" "$CLOUD_URL/cloud/v1/support/tickets"
curl -sf -H "Authorization: Bearer $API_KEY" "$CLOUD_URL/cloud/v1/support/unread"
```

Response shape: `{"tickets": [{"id": 1, "ref": "TKT-0001", "subject": "...", "status": "open", "last_message": "...", "last_sender": "user"|"staff", "message_count": N}, ...]}`

Then display as a clean menu. If unread count > 0, prefix the header with `✉ N new`.
Mark tickets where `last_sender == "staff"` with `[NEW]` (staff replied since last user message):

```
  Support Tickets  ✉ 2 new
  ───────────────────────────────────────────
  TKT-0003   open      Graph not finding symbols after rebase    [NEW]
  TKT-0001   resolved  MCP server disconnects on large repos
  ───────────────────────────────────────────
  [N] New ticket    [V] View <id>    [C] Close <id>
```

If no tickets exist, show:
```
  No support tickets yet.
  ───────────────────────────────────────────
  [N] New ticket — report a bug or ask a question
```

Do NOT suggest raw CLI commands. Present the menu and wait for the user to type N, V <id>, or C <id>.

### support new  (or user types N from menu)

Ask the user:
> **What's the issue?** (one-line title):

Then:
> **Details** (optional — describe steps to reproduce, error messages, etc.):

Then post:
```bash
curl -sf -X POST -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" \
  -d "{\"type\":\"general\",\"subject\":\"<title>\",\"message\":\"<details>\"}" \
  "$CLOUD_URL/cloud/v1/support/tickets"
```

On success (HTTP 201) show:
```
  ✓ Ticket <ref> created.
  The team will respond at app.cogmeta.ai → Support.
```

### support view `<id>`  (or user types V <id> from menu)

```bash
curl -sf -H "Authorization: Bearer $API_KEY" "$CLOUD_URL/cloud/v1/support/tickets/<id>"
```

Response shape: `{"id": 1, "ref": "TKT-0001", "subject": "...", "status": "open", "messages": [{"sender": "user"|"staff", "content": "...", "created_at": "..."}]}`

Display as a conversation thread:
```
  TKT-0001 — <status>: <subject>
  ───────────────────────────────────────────
  [You]     Graph stops finding symbols after git rebase
  [Support] Have you tried running /talon index . --incremental?
  ───────────────────────────────────────────
  [R] Reply    [C] Close ticket    [B] Back
```

If user types R, ask for reply content then post:
```bash
curl -sf -X POST -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" \
  -d "{\"content\":\"<reply>\"}" \
  "$CLOUD_URL/cloud/v1/support/tickets/<id>/messages"
```

### support close `<id>`  (or user types C <id> from menu)

```bash
curl -sf -X PATCH -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" \
  -d '{"status":"closed"}' \
  "$CLOUD_URL/cloud/v1/support/tickets/<id>/status"
```

Show: `  ✓ Ticket #<id> closed.`

---

## feedback

If `$ARGUMENTS` starts with `feedback`:

Parse the rating and optional comment from `$ARGUMENTS`.

The rating is the word after "feedback": `y` (good), `m` (mixed), or `n` (poor).
Everything after the rating is an optional free-text comment.

```bash
python3 -c "
import json, os, sys, urllib.request
from pathlib import Path

args = '$ARGUMENTS'.split()
if len(args) < 2:
    print('Usage: /talon feedback y|m|n [comment]')
    print('  y = good')
    print('  m = mixed')
    print('  n = poor')
    sys.exit(0)

rating = args[1]
if rating not in ('y', 'm', 'n'):
    print(f'Invalid rating: {rating}. Use y, m, or n.')
    sys.exit(1)

comment = ' '.join(args[2:]) if len(args) > 2 else ''

creds_path = Path.home() / '.talon' / 'credentials.json'
api_key = ''
cloud_url = 'https://api.cogmeta.ai'
if creds_path.exists():
    c = json.loads(creds_path.read_text())
    api_key = c.get('api_key', '')
    cloud_url = c.get('cloud_url', cloud_url).rstrip('/')

session_id = ''
last_session = Path.home() / '.talon' / 'last_session.json'
if last_session.exists():
    try:
        session_id = json.loads(last_session.read_text()).get('session_id', '')
    except Exception:
        pass

payload = json.dumps({
    'session_id': session_id,
    'rating': rating,
    'comment': comment,
}).encode()

headers = {'Content-Type': 'application/json', 'User-Agent': 'talon-cli/1.0'}
if api_key:
    headers['X-API-Key'] = api_key

try:
    req = urllib.request.Request(
        f'{cloud_url}/api/v1/talon/feedback',
        data=payload,
        headers=headers,
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        print('Feedback submitted — thank you!')
except Exception as e:
    print(f'Could not submit feedback: {e}')
" 2>/dev/null || echo "Could not submit feedback."
```

Present the output directly.

---

## Unknown subcommand

If `$ARGUMENTS` does not match any of the above, respond:

> Unknown subcommand: `$ARGUMENTS`
>
> Available commands: `login`, `register`, `logout`, `auth`, `auth sync`, `account`, `index`, `health`, `upgrade`, `setup init [--cloud]`, `setup status`, `score [on|off]`, `observation on|off`, `settings [key] [value]`, `feedback y|m|n [comment]`, `summary`, `capacity [history]`, `support [new|list|view <id>|close <id>]`
