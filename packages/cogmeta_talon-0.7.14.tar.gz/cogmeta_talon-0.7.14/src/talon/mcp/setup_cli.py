"""CLI entry point for talon command.

Provides onboarding commands for integrating Talon with Claude Code:
- init:      Generate .mcp.json in the project root
- test:      Test MCP server connection and tool availability
- claude-md: Print CLAUDE.md snippet to stdout
- status:    Show current config and connection status

"""

from __future__ import annotations

import argparse
import json
import shutil
import os
import sys
from pathlib import Path

from talon.mcp.setup import (
    TALON_CLOUD_URL,
    DEFAULT_K8S_SSE_URL,
    DEFAULT_LOG_LEVEL,
    MCP_CONFIG_FILENAME,
    detect_project_root,
    generate_agents_md,
    generate_claude_md_snippet,
    generate_mcp_config,
    get_project_status,
    refresh_config,
    test_connection,
    write_mcp_config,
)


_CREDS_PATH = Path.home() / ".talon" / "credentials.json"


# ---------------------------------------------------------------------------
# Subcommand Handlers
# ---------------------------------------------------------------------------


def _fetch_or_create_api_key(cloud_url: str, access_token: str) -> str | None:
    """Generate a new API key via the cloud API.

    API keys are shown only once. This always generates a fresh key (revoking
    any existing ones). Returns the raw key string, or None on failure.
    """
    try:
        import httpx
    except ImportError:
        print("Error: httpx required. Run: pip install httpx", file=sys.stderr)
        return None

    headers = {"Authorization": f"Bearer {access_token}"}
    base = cloud_url.rstrip("/")

    with httpx.Client(timeout=15, follow_redirects=True) as client:
        resp = client.post(f"{base}/cloud/v1/users/me/api-key", headers=headers)
        if resp.status_code not in (200, 201):
            print(f"Error: failed to generate API key: HTTP {resp.status_code} — {resp.text[:200]}", file=sys.stderr)
            return None
        return resp.json().get("api_key")


def _has_talon_server() -> bool:
    """Check if talon-server package is installed (provides talon-local)."""
    import shutil
    return shutil.which("talon-local") is not None


def _cmd_init(args: argparse.Namespace) -> int:
    """Handle 'talon init' -- generate .mcp.json in project root."""
    # Determine project path
    project_path = Path(args.path).resolve() if args.path else Path.cwd().resolve()

    if not project_path.is_dir():
        print(f"Error: {project_path} is not a directory", file=sys.stderr)
        return 1

    # Detect project root if not explicitly specified
    if not args.path:
        detected = detect_project_root(project_path)
        if detected is not None:
            project_path = detected

    local_mode = getattr(args, "local", False)
    has_server = _has_talon_server()

    if local_mode and not has_server:
        print("Error: --local requires the talon-server package.", file=sys.stderr)
        print("  Install: uv pip install talon-server --index-url https://api.cogmeta.ai/simple/", file=sys.stderr)
        return 1

    cloud_mode = not local_mode
    api_key: str | None = None
    cloud_url = getattr(args, "cloud_url", TALON_CLOUD_URL)

    if cloud_mode:
        # Load credentials
        if not _CREDS_PATH.exists():
            print("Error: not logged in. Run: talon auth login", file=sys.stderr)
            return 1
        creds = json.loads(_CREDS_PATH.read_text())
        api_key = creds.get("api_key", "")
        if not api_key:
            print("Error: no API key. Run: talon auth login", file=sys.stderr)
            return 1

        cloud_url = creds.get("cloud_url", cloud_url)

    try:
        config_path = write_mcp_config(
            project_path=project_path,
            log_level=args.log_level,
            force=args.force,
            k8s=args.k8s if local_mode else False,
            sse_url=args.sse_url if local_mode else None,
            project_id=getattr(args, "project_id", None),
            cloud=cloud_mode,
            api_key=api_key,
            cloud_url=cloud_url,
            db_url=getattr(args, "db_url", None) if local_mode else None,
            db_name=getattr(args, "db_name", None) if local_mode else None,
            db_pass=getattr(args, "db_pass", None) if local_mode else None,
        )
    except FileExistsError as e:
        print(f"Error: {e}", file=sys.stderr)
        print(f"Hint: Use --force to overwrite existing {MCP_CONFIG_FILENAME}", file=sys.stderr)
        return 1
    except NotADirectoryError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    print(f"Created {config_path}")

    # Write AGENTS.md with full talon guidance
    agents_md_path = project_path / "AGENTS.md"
    _agents_marker = "# Talon Code Intelligence"
    try:
        agents_content = generate_agents_md()
        if agents_md_path.exists():
            existing_agents = agents_md_path.read_text()
            if _agents_marker not in existing_agents:
                agents_md_path.write_text(agents_content + "\n\n" + existing_agents)
                print(f"Updated {agents_md_path} — prepended Talon guidance")
            else:
                print(f"{agents_md_path} already has Talon guidance")
        else:
            agents_md_path.write_text(agents_content)
            print(f"Created {agents_md_path} — Talon tool guidance")
    except Exception as e:
        print(f"Warning: could not write AGENTS.md: {e}", file=sys.stderr)

    # Prepend tiny ref to top of CLAUDE.md (without deleting existing content)
    claude_md_path = project_path / "CLAUDE.md"
    _claude_marker = "AGENTS.md"
    try:
        snippet = generate_claude_md_snippet()
        if claude_md_path.exists():
            existing = claude_md_path.read_text()
            if _claude_marker not in existing:
                claude_md_path.write_text(snippet + "\n" + existing)
                print(f"Updated {claude_md_path} — added AGENTS.md ref at top")
            else:
                print(f"{claude_md_path} already references AGENTS.md")
        else:
            claude_md_path.write_text(snippet)
            print(f"Created {claude_md_path} — AGENTS.md ref")
    except Exception as e:
        print(f"Warning: could not write CLAUDE.md: {e}", file=sys.stderr)

    print()
    if cloud_mode:
        print(f"Mode: Cloud (cogmeta.ai — {cloud_url})")
        print()
        print("Next steps:")
        print("  1. Start Claude Code in this directory — Talon cloud tools will be available")
    elif args.k8s:
        print(f"Mode: K8s (mcp-proxy → {args.sse_url or DEFAULT_K8S_SSE_URL})")
        print()
        print("Next steps:")
        print("  1. Ensure mcp-proxy is installed:  pip install mcp-proxy")
        print("  2. Start Claude Code in this directory -- Talon tools will be available")
    else:
        graph_loc = "local" if getattr(args, "db_url", None) else "cloud"
        print(f"Mode: Local MCP server (talon-local stdio, {graph_loc} graph DB)")
        if getattr(args, "db_url", None):
            print(f"  Graph DB: {args.db_url}")
        print()

        # Auto-index the project unless --no-index or --k8s
        if not args.no_index:
            source_exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".rb", ".cpp", ".c", ".h"}
            has_source = any(
                f.suffix in source_exts
                for f in project_path.rglob("*")
                if f.is_file() and ".git" not in f.parts
            )
            if not has_source:
                print("New project — no source files to index yet. Run 'talon index' after adding code.")
            else:
                print("Indexing project...")
                import asyncio

                from talon.indexer.cli import index_project
                project_id = project_path.name
                try:
                    asyncio.run(index_project(str(project_path), project_id, hotspots=True))
                    print()
                except Exception as e:
                    print(f"Warning: Auto-indexing failed: {e}", file=sys.stderr)
                    print("You can index manually: talon-index .", file=sys.stderr)
                    print()

        print("Next steps:")
        print("  1. Test the connection:             talon test")
        print("  2. Start Claude Code in this directory -- Talon tools will be available")
    print()
    print(f"Config written to: {config_path}")

    _install_skill()
    _deploy_cc_hook()
    _reinstall_hooks()

    return 0


def _skill_version(text: str) -> str:
    """Extract version from SKILL.md first line: <!-- talon-skill-version: X.Y.Z -->"""
    first = text.splitlines()[0] if text else ""
    if "talon-skill-version:" in first:
        return first.split("talon-skill-version:")[-1].strip(" ->")
    return ""


def _install_skill() -> None:
    """Install/update /talon skill to ~/.claude/skills/talon/SKILL.md.

    Compares the installed version tag against the bundled version and
    overwrites if they differ — so WHL upgrades automatically update the skill.
    """
    import importlib.resources
    skill_dest = Path.home() / ".claude" / "skills" / "talon" / "SKILL.md"
    try:
        ref = importlib.resources.files("talon.skills").joinpath("SKILL.md")
        skill_src = ref.read_text(encoding="utf-8")
    except (ModuleNotFoundError, FileNotFoundError, TypeError):
        return  # not bundled (dev install) — skip silently

    # Check if update needed
    if skill_dest.exists():
        installed_ver = _skill_version(skill_dest.read_text(encoding="utf-8"))
        bundled_ver = _skill_version(skill_src)
        if installed_ver and bundled_ver and installed_ver == bundled_ver:
            return  # up to date

    try:
        skill_dest.parent.mkdir(parents=True, exist_ok=True)
        skill_dest.write_text(skill_src, encoding="utf-8")
        print(f"Installed /talon skill → {skill_dest}")
        print("  Use /talon login, /talon index, /talon health etc. inside Claude Code")
    except Exception as e:
        print(f"Note: could not install /talon skill globally: {e}", file=sys.stderr)


def _cmd_test(args: argparse.Namespace) -> int:
    """Handle 'talon test' -- test MCP server connection."""
    print("Testing Talon MCP server connection...")
    print()

    result = test_connection(timeout=args.timeout)

    # Server on PATH
    if result["server_found"]:
        print(f"  [PASS] talon-local found: {result['server_path']}")
    else:
        print(f"  [FAIL] talon-local not found on PATH")
        print(f"         Install with: pip install talon")
        return 1

    # Server startup
    if result["startup_ok"]:
        print(f"  [PASS] Server started successfully")
    else:
        print(f"  [FAIL] Server failed to start")
        if result["error"]:
            print(f"         {result['error']}")
        return 1

    # Tools listed
    if result["tools_listed"]:
        print(f"  [PASS] Tools listed: {result['tool_count']} tools")
        for name in result["tool_names"]:
            print(f"         - {name}")
    else:
        print(f"  [WARN] Could not verify tool listing")
        if result["error"]:
            print(f"         {result['error']}")

    # Summary
    print()
    if result["server_found"] and result["startup_ok"]:
        print("Connection test PASSED. Claude Code can use Talon tools.")
        return 0
    else:
        print("Connection test FAILED. See errors above.")
        return 1


def _cmd_claude_md(args: argparse.Namespace) -> int:
    """Handle 'talon claude-md' -- print CLAUDE.md snippet."""
    snippet = generate_claude_md_snippet()
    print(snippet, end="")
    return 0


def _cmd_status(args: argparse.Namespace) -> int:
    """Handle 'talon status' -- show current config and connection status."""
    project_path = Path(args.path).resolve() if args.path else Path.cwd().resolve()

    # Auto-detect project root
    if not args.path:
        detected = detect_project_root(project_path)
        if detected is not None:
            project_path = detected

    status = get_project_status(project_path)

    print("Talon Setup Status")
    print("=" * 50)
    print()
    print(f"  Project path:     {status['project_path']}")
    print()

    # Config
    print("  Configuration:")
    if status["config_exists"]:
        if status["config_valid"]:
            print(f"    {MCP_CONFIG_FILENAME}:     FOUND (valid)")
        else:
            print(f"    {MCP_CONFIG_FILENAME}:     FOUND (invalid -- missing talon server entry)")
    else:
        print(f"    {MCP_CONFIG_FILENAME}:     NOT FOUND")
        print(f"    Run:            talon init")
    print()

    # Mode detection
    print("  Mode:")
    if status["config_valid"]:
        config_data = status.get("raw_config", {})
        talon_entry = config_data.get("mcpServers", {}).get("talon", {})
        cmd = talon_entry.get("command", "")
        if "mcp-proxy" in cmd or "talon-proxy-wrapper" in cmd:
            print("    Cloud (mcp-proxy → cogmeta.ai)")
        elif cmd == "talon-local":
            env = talon_entry.get("env", {})
            if env.get("TALON_DB_URL") or env.get("TALON_ARANGO_URL"):
                db_display = env.get("TALON_DB_URL") or env.get("TALON_ARANGO_URL")
                print(f"    Local MCP + local graph ({db_display})")
            else:
                print("    Local MCP + cloud graph")
        else:
            print(f"    Unknown ({cmd})")
    else:
        print("    Not configured")
    print()

    # Server package
    print("  Packages:")
    print(f"    talon:          {__import__('talon').__version__}")
    has_server = _has_talon_server()
    if has_server:
        print(f"    talon-server:   installed (talon-local available)")
    else:
        print(f"    talon-server:   not installed (cloud mode only)")
    print()

    # JSON output if requested
    if args.json:
        print("  Raw status (JSON):")
        print(json.dumps(status, indent=2))

    return 0


def _cmd_refresh(args: argparse.Namespace) -> int:
    """Handle 'talon refresh' -- regenerate .mcp.json from contracts."""
    project_path = Path(args.path).resolve() if args.path else Path.cwd().resolve()

    if not args.path:
        detected = detect_project_root(project_path)
        if detected is not None:
            project_path = detected

    try:
        result = refresh_config(project_path)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        print(f"Hint: Run 'talon init' first to create {MCP_CONFIG_FILENAME}", file=sys.stderr)
        return 1

    if result["changed"]:
        print(f"Refreshed {result['config_path']}")
        print()
        # Show what changed
        old_env = result["old_config"].get("mcpServers", {}).get("talon", {}).get("env", {})
        new_env = result["new_config"].get("mcpServers", {}).get("talon", {}).get("env", {})
        old_args = result["old_config"].get("mcpServers", {}).get("talon", {}).get("args", [])
        new_args = result["new_config"].get("mcpServers", {}).get("talon", {}).get("args", [])
        if old_args != new_args:
            print(f"  args: {old_args} -> {new_args}")
        for k in sorted(set(list(old_env.keys()) + list(new_env.keys()))):
            ov = old_env.get(k)
            nv = new_env.get(k)
            if ov != nv:
                print(f"  {k}: {ov} -> {nv}")
    else:
        print(f"No changes needed. {result['config_path']} is up to date.")

    return 0


# ---------------------------------------------------------------------------
# Argument Parser
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    """Build the argument parser for talon."""
    parser = argparse.ArgumentParser(
        prog="talon",
        description="Set up Talon integration for Claude Code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  talon init                          # Local mode: spawn talon-local via stdio
  talon init --k8s                    # K8s mode: mcp-proxy → SSE endpoint
  talon init --k8s --sse-url http://custom:30089/sse
  talon init --force                  # Overwrite existing .mcp.json
  talon init --db-url http://db:8530      # Custom graph DB URL (local mode)
  talon test                          # Test MCP server connection
  talon claude-md                     # Print CLAUDE.md snippet
  talon status                        # Show current configuration
""",
    )

    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"%(prog)s {__import__('talon').__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- version ---
    subparsers.add_parser(
        "version",
        help="Show talon version",
    )

    # --- init ---
    init_parser = subparsers.add_parser(
        "init",
        help=f"Generate {MCP_CONFIG_FILENAME} for Claude Code",
        description=f"Generate a {MCP_CONFIG_FILENAME} file in the project root that tells Claude Code how to spawn the Talon MCP server.",
    )
    init_parser.add_argument(
        "--path",
        help="Project directory (default: current directory or detected project root)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help=f"Overwrite existing {MCP_CONFIG_FILENAME}",
    )
    init_parser.add_argument(
        "--log-level",
        default=DEFAULT_LOG_LEVEL,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help=f"Server log level (default: {DEFAULT_LOG_LEVEL})",
    )
    init_parser.add_argument(
        "--k8s",
        action="store_true",
        help="Use mcp-proxy to connect to K8s SSE endpoint (no local server)",
    )
    init_parser.add_argument(
        "--sse-url",
        default=None,
        help=f"Custom SSE URL for K8s mode (default: {DEFAULT_K8S_SSE_URL})",
    )
    init_parser.add_argument(
        "--no-index",
        action="store_true",
        help="Skip automatic indexing after init",
    )
    init_parser.add_argument(
        "--project-id",
        default=None,
        help="Override project_id (use when connecting to a server-side indexed project)",
    )
    init_parser.add_argument(
        "--local",
        action="store_true",
        help="Local mode: use talon-local MCP server (requires talon-server package)",
    )
    init_parser.add_argument(
        "--cloud-url",
        default=TALON_CLOUD_URL,
        help=f"Override cloud API URL (default: {TALON_CLOUD_URL})",
    )
    init_parser.add_argument(
        "--db-url",
        default=None,
        help="Graph DB URL for self-hosted local mode (default: uses cloud graph DB)",
    )
    init_parser.add_argument(
        "--db-name",
        default=None,
        help="Graph DB name for self-hosted local mode",
    )
    init_parser.add_argument(
        "--db-pass",
        default=None,
        help="Graph DB password for self-hosted local mode",
    )

    # --- test ---
    test_parser = subparsers.add_parser(
        "test",
        help="Test MCP server connection",
        description="Spawn talon-local and verify it responds to MCP requests with the expected 6 tools.",
    )
    test_parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Timeout in seconds (default: 10)",
    )

    # --- claude-md ---
    subparsers.add_parser(
        "claude-md",
        help="Print CLAUDE.md snippet to stdout",
        description="Output a markdown snippet that explains the 6 Talon MCP tools. Paste this into your project's CLAUDE.md file.",
    )

    # --- status ---
    status_parser = subparsers.add_parser(
        "status",
        help="Show current config and connection status",
        description="Display the current Talon configuration, server availability, and database connection info.",
    )
    status_parser.add_argument(
        "--path",
        help="Project directory (default: current directory or detected project root)",
    )
    status_parser.add_argument(
        "--json",
        action="store_true",
        help="Include raw JSON status output",
    )

    # --- refresh ---
    refresh_parser = subparsers.add_parser(
        "refresh",
        help=f"Refresh {MCP_CONFIG_FILENAME} from current contracts",
        description=f"Regenerate {MCP_CONFIG_FILENAME} tool descriptions while preserving custom env vars.",
    )
    refresh_parser.add_argument(
        "--path",
        help="Project directory (default: current directory or detected project root)",
    )

    # --- pull ---
    pull_parser = subparsers.add_parser(
        "pull",
        help="Clone + configure a server-indexed project",
        description="Fetch project info from cogmeta.ai, clone the repo, and generate .mcp.json — skipping indexing since the graph already exists on the server.",
    )
    pull_parser.add_argument(
        "project_id",
        help="Project ID (shown on the web dashboard after indexing)",
    )
    pull_parser.add_argument(
        "--path",
        default=None,
        help="Clone destination (default: ./<project_id>)",
    )
    pull_parser.add_argument(
        "--db-url",
        default=None,
        help="Graph DB URL for self-hosted local mode",
    )
    pull_parser.add_argument(
        "--db-name",
        default=None,
        help="Graph DB name for self-hosted local mode",
    )
    pull_parser.add_argument(
        "--db-pass",
        default=None,
        help="Graph DB password for self-hosted local mode",
    )
    pull_parser.add_argument(
        "--no-pass",
        action="store_true",
        default=False,
        help="Omit graph DB password from .mcp.json",
    )

    # --- auth ---
    auth_parser = subparsers.add_parser(
        "auth",
        help="Authenticate with cogmeta.ai cloud",
        description="Log in to cogmeta.ai and save your API key for heartbeat reporting.",
    )
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command", metavar="COMMAND")
    def _add_auth0_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--auth0-domain", default="", help="Auth0 domain (default: AUTH0_DOMAIN env var)")
        p.add_argument("--client-id", default="", help="Auth0 client ID (default: AUTH0_CLIENT_ID env var)")
        p.add_argument("--audience", default="", help="Auth0 audience (default: AUTH0_AUDIENCE env var)")

    auth_login_parser = auth_subparsers.add_parser("login", help="Log in to cogmeta.ai (opens browser)")
    auth_login_parser.add_argument("--cloud-url", default=TALON_CLOUD_URL, help=argparse.SUPPRESS)

    auth_register_parser = auth_subparsers.add_parser("register", help="Create account and log in (opens browser signup form)")
    _add_auth0_args(auth_register_parser)

    # auth token — print current access token
    auth_subparsers.add_parser(
        "token",
        help="Print current access token (for scripting)",
    )

    # auth status — show logged-in state
    auth_status_parser = auth_subparsers.add_parser(
        "status",
        help="Show current auth status",
    )
    auth_status_parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show full API key and credentials file path",
    )

    # auth wait
    auth_subparsers.add_parser(
        "wait",
        help="Poll for login completion then show auth status",
    )

    # auth logout
    auth_subparsers.add_parser(
        "logout",
        help="Remove saved credentials",
    )

    # auth sync — re-write .mcp.json with current API key
    auth_subparsers.add_parser(
        "sync",
        help="Re-write .mcp.json with current API key (fixes stale key after web-generated rotation)",
    )

    # --- upgrade ---
    upgrade_parser = subparsers.add_parser(
        "upgrade",
        help="Upgrade talon to the latest (or a specific) version",
        description="Install the latest talon wheel. Saves the current version so you can roll back if needed.",
    )
    upgrade_parser.add_argument(
        "--force",
        action="store_true",
        help="Run upgrade even if already up to date",
    )
    upgrade_parser.add_argument(
        "--version",
        default=None,
        metavar="VERSION",
        help="Install a specific version (e.g. 0.2.1) instead of latest",
    )
    upgrade_parser.add_argument(
        "--rollback",
        action="store_true",
        help="Restore the previous version (reverses the last upgrade)",
    )

    # --- check ---
    check_parser = subparsers.add_parser(
        "check",
        help="Pre-flight check: version, MCP, CLAUDE.md, index",
        description="Validate that talon is fully configured and operational for this project.",
    )
    check_parser.add_argument(
        "--path",
        help="Project directory (default: current directory)",
    )

    return parser


# ---------------------------------------------------------------------------
# Pull command — talon pull <project-id>
# ---------------------------------------------------------------------------


def _cmd_pull(args: argparse.Namespace) -> int:
    """Handle 'talon pull <project-id>' — clone + configure a server-indexed project."""
    try:
        import httpx
    except ImportError:
        print("Error: httpx is required. Run: pip install httpx", file=sys.stderr)
        return 1
    import subprocess

    project_id = args.project_id

    if not _check_session_valid():
        return 1

    # Load credentials
    if not _CREDS_PATH.exists():
        print("Error: not logged in. Run: /talon login", file=sys.stderr)
        return 1

    try:
        creds = json.loads(_CREDS_PATH.read_text())
    except Exception:
        print("Error: credentials file is corrupt. Run: talon auth login", file=sys.stderr)
        return 1
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", "https://cogmeta.ai")

    if not api_key:
        print("Error: no API key in credentials. Run: talon auth login", file=sys.stderr)
        return 1

    # Query cloud API for project info
    print(f"Fetching project info for '{project_id}'...")
    try:
        with httpx.Client(timeout=15, follow_redirects=True) as client:
            resp = client.get(
                f"{cloud_url}/cloud/v1/projects/{project_id}/status",
                headers={"X-API-Key": api_key},
            )
            if resp.status_code == 404:
                print(f"Error: project '{project_id}' not found on {cloud_url}", file=sys.stderr)
                return 1
            if resp.status_code == 401:
                print("Error: authentication failed. Try: talon auth login", file=sys.stderr)
                return 1
            if resp.status_code != 200:
                print(f"Error: API returned HTTP {resp.status_code}", file=sys.stderr)
                return 1

            data = resp.json()
    except httpx.ConnectError:
        print(f"Error: cannot connect to {cloud_url}", file=sys.stderr)
        return 1

    if data.get("status") != "ready":
        print(f"Warning: project status is '{data.get('status')}' (expected 'ready')", file=sys.stderr)
        if data.get("status") in ("pending", "cloning", "indexing"):
            print("The project is still being indexed. Try again shortly.", file=sys.stderr)
            return 1

    git_url = data.get("git_url")
    if not git_url:
        print("Error: no git_url in project data", file=sys.stderr)
        return 1

    # Determine clone target
    clone_dir = Path(args.path).resolve() if args.path else Path.cwd().resolve() / project_id

    if clone_dir.exists() and any(clone_dir.iterdir()):
        print(f"Directory {clone_dir} already exists and is not empty.")
        print(f"Using existing directory. Skipping clone.")
    else:
        # Clone
        print(f"Cloning {git_url} → {clone_dir}")
        try:
            result = subprocess.run(
                ["git", "clone", "--depth", "1", git_url, str(clone_dir)],
                capture_output=True,
                text=True,
                timeout=120,
            )
        except subprocess.TimeoutExpired:
            print("Error: git clone timed out after 2 minutes.", file=sys.stderr)
            return 1
        if result.returncode != 0:
            print(f"Error: git clone failed:\n{result.stderr[:500]}", file=sys.stderr)
            return 1
        print("Clone complete.")

    # Generate .mcp.json with matching project_id (skip indexing — graph already exists)
    print(f"Configuring talon for project_id='{project_id}'...")
    try:
        config_path = write_mcp_config(
            project_path=clone_dir,
            db_url=getattr(args, "db_url", None),
            db_name=getattr(args, "db_name", None),
            db_pass=getattr(args, "db_pass", None) if not args.no_pass else None,
            log_level=DEFAULT_LOG_LEVEL,
            force=True,
            k8s=False,
            sse_url=None,
            project_id=project_id,
        )
    except Exception as e:
        print(f"Error writing config: {e}", file=sys.stderr)
        return 1

    print()
    print(f"Project '{project_id}' is ready!")
    print(f"  Clone:   {clone_dir}")
    print(f"  Config:  {config_path}")
    print(f"  Graph:   {data.get('files_count', '?')} files, {data.get('functions_count', '?')} functions (server-indexed)")
    print()
    print("Next steps:")
    print(f"  cd {clone_dir}")
    print("  Start Claude Code — Talon tools will be available")

    return 0


# ---------------------------------------------------------------------------
# B2: Auth command — talon auth login
# ---------------------------------------------------------------------------


def _cmd_auth(args: argparse.Namespace) -> int:
    """Handle `talon auth` subcommands."""
    if not hasattr(args, "auth_command") or args.auth_command is None:
        print("Usage: talon auth <login|register|token|status|logout>", file=sys.stderr)
        return 1
    if args.auth_command == "login":
        return _cmd_auth_login(args)
    if args.auth_command == "register":
        return _cmd_auth_login(args, signup=True)
    if args.auth_command == "token":
        return _cmd_auth_token()
    if args.auth_command == "status":
        return _cmd_auth_status(verbose=getattr(args, "verbose", False))
    if args.auth_command == "wait":
        return _cmd_auth_wait()
    if args.auth_command == "logout":
        return _cmd_auth_logout()
    if args.auth_command == "sync":
        return _cmd_auth_sync()
    print(f"Unknown auth command: {args.auth_command}", file=sys.stderr)
    return 1


def _cmd_auth_token() -> int:
    """Print the current access token to stdout (for scripting)."""
    if not _CREDS_PATH.exists():
        print("Error: not logged in. Run: talon auth login", file=sys.stderr)
        return 1
    creds = json.loads(_CREDS_PATH.read_text())
    token = creds.get("access_token", "")
    if not token:
        print("Error: no access token saved. Run: talon auth login", file=sys.stderr)
        return 1
    print(token, end="")
    return 0


_RENEWAL_STATE_PATH = Path.home() / ".talon" / "renewal_state.json"
_KEY_TTL_HOURS = 7 * 24     # Must match server API_KEY_TTL_SECONDS (7 days)
_RENEW_THRESHOLD = 0.50     # Renew when 50% of TTL has elapsed (3.5 days)


def _update_mcp_json_key(old_key: str, new_key: str) -> None:
    """Find any .mcp.json files containing old_key and replace with new_key.

    Searches ~/.mcp.json and the current directory .mcp.json. Uses JSON-aware
    patching: parses the file, updates only TALON_API_KEY env values, and
    re-serialises. Falls back to targeted string replace only within known
    JSON value positions. Silently skips on any error — best-effort, non-fatal.
    """
    if not old_key or not new_key:
        return
    candidates = [
        Path.home() / ".mcp.json",
        Path.cwd() / ".mcp.json",
    ]
    for path in candidates:
        try:
            if not path.exists():
                continue
            text = path.read_text()
            if old_key not in text:
                continue
            # JSON-aware: parse, patch the specific env key, re-serialise
            data = json.loads(text)
            changed = False
            for _name, server in data.get("mcpServers", {}).items():
                env = server.get("env", {})
                if env.get("TALON_API_KEY") == old_key:
                    env["TALON_API_KEY"] = new_key
                    changed = True
            if changed:
                tmp = path.parent / f".mcp.json.tmp.{os.getpid()}"
                tmp.write_text(json.dumps(data, indent=2) + "\n")
                tmp.rename(path)
        except Exception:
            pass


def _maybe_renew_api_key(creds: dict) -> bool:
    """Silently renew API key if >= 80% of TTL has elapsed.

    Uses exponential backoff on failure (1m, 2m, 4m, 8m, 16m, cap 60m).
    Returns True if key was renewed.
    """
    import datetime
    import time

    saved_at = creds.get("saved_at", "")
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", TALON_CLOUD_URL)
    if not saved_at or not api_key:
        return False

    # Check if past the renewal threshold
    try:
        saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
        now = datetime.datetime.now(datetime.timezone.utc)
        elapsed = (now - saved).total_seconds()
        ttl_secs = _KEY_TTL_HOURS * 3600
        if elapsed / ttl_secs < _RENEW_THRESHOLD:
            return False  # Not yet time to renew
    except Exception:
        return False

    # Check exponential backoff state
    backoff_secs = 60
    try:
        if _RENEWAL_STATE_PATH.exists():
            state = json.loads(_RENEWAL_STATE_PATH.read_text())
            last_attempt = state.get("last_attempt", 0)
            attempt_count = state.get("attempt_count", 0)
            backoff_secs = min(60 * (2 ** attempt_count), 3600)
            if time.time() - last_attempt < backoff_secs:
                return False  # Still in backoff window
    except Exception:
        pass

    # Attempt renewal
    try:
        import httpx
    except ImportError:
        return False

    base = cloud_url.rstrip("/")
    import os as _os
    _verify = _os.environ.get("TALON_NO_VERIFY", "").lower() not in ("1", "true", "yes")
    try:
        with httpx.Client(timeout=10, follow_redirects=True, verify=_verify) as client:
            resp = client.post(
                f"{base}/cloud/v1/users/me/api-key",
                headers={"Authorization": f"Bearer {api_key}"},
            )
        if resp.status_code in (200, 201):
            new_key = resp.json().get("api_key", "")
            if new_key:
                import time as _time, os as _os2
                old_key = creds.get("api_key", "")
                new_creds = {**creds, "api_key": new_key, "saved_at": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())}
                _tmp_r = _CREDS_PATH.parent / f".credentials.tmp.{_os2.getpid()}"
                _tmp_r.write_text(json.dumps(new_creds, indent=2))
                _tmp_r.chmod(0o600)
                _tmp_r.rename(_CREDS_PATH)
                _RENEWAL_STATE_PATH.write_text(json.dumps({"last_attempt": _time.time(), "attempt_count": 0}))
                _update_mcp_json_key(old_key, new_key)
                return True
    except Exception:
        pass

    # Record failed attempt for backoff
    try:
        import time as _time
        state = {}
        if _RENEWAL_STATE_PATH.exists():
            state = json.loads(_RENEWAL_STATE_PATH.read_text())
        state["last_attempt"] = _time.time()
        state["attempt_count"] = state.get("attempt_count", 0) + 1
        _RENEWAL_STATE_PATH.write_text(json.dumps(state))
    except Exception:
        pass
    return False


def _check_session_valid() -> bool:
    """Return True if credentials exist and are not expired. Prints warning if not."""
    import datetime

    if not _CREDS_PATH.exists():
        print("Not logged in. Run: /talon login", file=sys.stderr)
        return False
    try:
        creds = json.loads(_CREDS_PATH.read_text())
        saved_at = creds.get("saved_at", "")
        if saved_at:
            saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
            now = datetime.datetime.now(datetime.timezone.utc)
            elapsed = (now - saved).total_seconds()
            if elapsed > _KEY_TTL_HOURS * 3600:
                print("Session expired. Run: /talon login", file=sys.stderr)
                return False
    except Exception:
        pass
    return True


def _cmd_auth_wait() -> int:
    """Poll for login completion then show auth status. Called after talon-login."""
    import time

    print("Waiting for browser login...", flush=True)
    for _ in range(60):
        if _CREDS_PATH.exists() or _LOGIN_DONE_FILE.exists():
            break
        time.sleep(1)
    return _cmd_auth_status()


def _cmd_auth_status(verbose: bool = False) -> int:
    """Show current auth status."""
    import datetime

    _KEY_TTL_HOURS = 7 * 24

    print("AUTH STATUS")
    print("===========")

    if not _CREDS_PATH.exists():
        print("  Status:   Not logged in")
        print()
        print("Run: /talon login")
        return 0

    try:
        creds = json.loads(_CREDS_PATH.read_text())
    except Exception:
        print("  Status:   Credentials file is corrupt — run /talon login")
        return 1

    # Silently renew if past 80% TTL — re-read creds if renewed
    if _maybe_renew_api_key(creds):
        try:
            creds = json.loads(_CREDS_PATH.read_text())
        except Exception:
            pass

    email = creds.get("email", "(unknown)")
    name = creds.get("name", "")
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", "https://api.cogmeta.ai")
    saved_at = creds.get("saved_at", "")

    # Key preview
    if api_key and len(api_key) > 12:
        key_preview = api_key[:12] + "..." + api_key[-4:]
    elif api_key:
        key_preview = api_key[:8] + "..."
    else:
        key_preview = "(none)"

    # Age + session life
    age_str = "unknown"
    session_str = "unknown"
    if saved_at:
        try:
            saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
            now = datetime.datetime.now(datetime.timezone.utc)
            delta = now - saved
            days = delta.days
            hours = delta.seconds // 3600
            age_str = f"{days}d {hours}h ago" if days > 0 else f"{hours}h ago"
            expires = saved + datetime.timedelta(hours=_KEY_TTL_HOURS)
            remaining = expires - now
            rem_secs = remaining.total_seconds()
            if rem_secs < 0:
                session_str = "EXPIRED — run /talon login"
            elif rem_secs < 3600:
                session_str = f"expires in {int(rem_secs // 60)}m"
            elif rem_secs < 86400:
                session_str = f"expires in {int(rem_secs // 3600)}h {int((rem_secs % 3600) // 60)}m"
            else:
                rem_days = remaining.days
                session_str = f"{rem_days} days remaining (expires {expires.strftime('%Y-%m-%d')})"
        except Exception:
            age_str = saved_at

    # Live server check — verify key is actually valid in DB
    key_valid: bool | None = None
    if api_key and cloud_url:
        try:
            import httpx as _httpx
            import os as _os
            _verify = _os.environ.get("TALON_NO_VERIFY", "").lower() not in ("1", "true", "yes")
            base = cloud_url.rstrip("/").replace("://app.", "://api.")
            with _httpx.Client(timeout=5, follow_redirects=True, verify=_verify) as _c:
                r = _c.get(
                    f"{base}/cloud/v1/users/me",
                    headers={"X-API-Key": api_key},
                )
            key_valid = r.status_code == 200
        except Exception:
            key_valid = None  # network error — don't alarm user

    user_line = f"{name} <{email}>" if name else email
    print(f"  Status:     Logged in")
    print(f"  User:       {user_line}")
    if verbose:
        print(f"  API key:    {api_key if api_key else '(none)'}")
        print(f"  Saved at:   {saved_at or '(unknown)'}")
        print(f"  Creds file: {_CREDS_PATH}")
    else:
        print(f"  API key:    {key_preview}")
    print(f"  Saved:      {age_str}")
    print(f"  Session:    {session_str}")
    if key_valid is True:
        print(f"  Key check:  OK  (verified with server)")
    elif key_valid is False:
        print(f"  Key check:  INVALID — run: /talon login")
    print(f"  Cloud URL:  {cloud_url}")
    if not api_key:
        print()
        print("  Warning: no API key — run /talon login to refresh")
    return 0


def _cmd_auth_logout() -> int:
    """Remove saved credentials."""
    if _CREDS_PATH.exists():
        _CREDS_PATH.unlink()
        print(f"Credentials removed: {_CREDS_PATH}")
    else:
        print("Not logged in.")
    return 0


def _cmd_auth_sync() -> int:
    """Re-write .mcp.json with the current API key from credentials.json.

    Fixes the case where the user generated a new API key via the web UI and
    the .mcp.json on their machine still has the old (revoked) key.

    If credentials.json itself has a revoked key (e.g. user rotated via web),
    prompts the user to re-run `talon auth login`.
    """
    if not _CREDS_PATH.exists():
        print("Not logged in. Run: talon auth login", file=sys.stderr)
        return 1
    try:
        creds = json.loads(_CREDS_PATH.read_text())
    except Exception as e:
        print(f"Error reading credentials: {e}", file=sys.stderr)
        return 1
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", TALON_CLOUD_URL)
    if not api_key:
        print("No API key in credentials. Run: talon auth login", file=sys.stderr)
        return 1

    # Validate the key is still active before writing it
    try:
        import httpx
        import os as _os
        base = cloud_url.rstrip("/")
        verify = _os.environ.get("TALON_NO_VERIFY", "").lower() not in ("1", "true", "yes")
        resp = httpx.get(
            f"{base}/cloud/v1/users/me",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=8,
            follow_redirects=True,
            verify=verify,
        )
        if resp.status_code == 401:
            print("Your API key has been revoked (e.g. after web key rotation).", file=sys.stderr)
            print("Run: talon auth login  to get a fresh key.", file=sys.stderr)
            return 1
    except Exception:
        pass  # Offline / unreachable — proceed with what we have

    try:
        project_root = detect_project_root() or Path.home()
        config_path = write_mcp_config(
            project_root, cloud=True, cloud_url=cloud_url, api_key=api_key, force=True,
        )
        print(f"✓ .mcp.json updated: {config_path}")
        print("  Restart Claude Code to activate the new API key.")
    except Exception as exc:
        print(f"Could not write .mcp.json: {exc}", file=sys.stderr)
        return 1
    return 0


_LOGIN_URL_FILE = Path.home() / ".talon" / "login_url.txt"
_LOGIN_DONE_FILE = Path.home() / ".talon" / "login_done.txt"

# Bash patterns pre-approved in ~/.claude/settings.json so CC never prompts per command
_CC_ALLOWED_PATTERNS = [
    # All talon CLI entry points (covers talon, talon-login, talon-index, talon, etc.)
    "Bash(talon*)",
    # python3 — covers both one-liners (-c "...") and file invocations (/tmp/script.py)
    "Bash(python3 *)",
    # Transcript + config reads used by /talon status, /talon audit, etc.
    "Bash(ls -t ~/.claude/*)",
    "Bash(ls ~/.talon/*)",
    "Bash(cat ~/.talon/*)",
    "Bash(cat ~/.claude/*)",
    # Health check curl calls
    "Bash(curl -sf *)",
    "Bash(curl -s *)",
    # uv run (used by audit/capacity/autobot commands in SKILL.md)
    "Bash(uv run *)",
    # git commands (used by /talon index, /talon commit, /talon version)
    "Bash(git rev-parse *)",
    "Bash(git diff *)",
    "Bash(git log *)",
    "Bash(git status*)",
    # Compound commands starting with env var assignment (health checks, index)
    "Bash(PROJECT_ROOT=*)",
    "Bash(TALON_API=*)",
    "Bash(TRANSCRIPT=*)",
]

_CC_SETTINGS_PATH = Path.home() / ".claude" / "settings.json"
_CC_HOOKS_DIR = Path.home() / ".claude" / "hooks"
_CC_HOOK_PATH = _CC_HOOKS_DIR / "talon-client.py"

# Stdlib-only hook script — silently auto-renews API key if >= 80% of TTL elapsed.
# No talon import: works regardless of virtualenv the user has active.
_CC_HOOK_SCRIPT = '''\
#!/usr/bin/env python3
"""talon-client.py — UserPromptSubmit hook.

Silently auto-renews talon API key if near expiry and patches .mcp.json.
Stdlib-only. Produces no output (never injects into Claude's context).
"""
import datetime, json, time, urllib.request
from pathlib import Path

_CREDS = Path.home() / ".talon" / "credentials.json"
_STATE = Path.home() / ".talon" / "renewal_state.json"
_TTL_H = 6
_THRESH = 0.80


def _main() -> None:
    if not _CREDS.exists():
        return
    try:
        creds = json.loads(_CREDS.read_text())
    except Exception:
        return

    saved_at = creds.get("saved_at", "")
    api_key = creds.get("api_key", "")
    cloud_url = creds.get("cloud_url", "https://api.cogmeta.ai").rstrip("/")
    if not saved_at or not api_key:
        return

    # Skip if not yet at renewal threshold
    try:
        saved = datetime.datetime.fromisoformat(saved_at.replace("Z", "+00:00"))
        now = datetime.datetime.now(datetime.timezone.utc)
        if (now - saved).total_seconds() / (_TTL_H * 3600) < _THRESH:
            return
    except Exception:
        return

    # Respect exponential backoff
    try:
        if _STATE.exists():
            st = json.loads(_STATE.read_text())
            backoff = min(60 * (2 ** st.get("attempt_count", 0)), 3600)
            if time.time() - st.get("last_attempt", 0) < backoff:
                return
    except Exception:
        pass

    # Attempt renewal via cloud API
    try:
        req = urllib.request.Request(
            f"{cloud_url}/cloud/v1/users/me/api-key",
            method="POST",
            headers={"X-API-Key": api_key},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        new_key = data.get("api_key", "")
        if new_key:
            import os as _os1
            ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            _tmp = _CREDS.parent / f".credentials.tmp.{_os1.getpid()}"
            _tmp.write_text(json.dumps({**creds, "api_key": new_key, "saved_at": ts}, indent=2))
            _tmp.chmod(0o600)
            _tmp.rename(_CREDS)
            _STATE.write_text(json.dumps({"last_attempt": time.time(), "attempt_count": 0}))
            # Patch .mcp.json files — JSON-aware, only update TALON_API_KEY env values
            for p in (Path.home() / ".mcp.json", Path.cwd() / ".mcp.json"):
                try:
                    if p.exists():
                        txt = p.read_text()
                        if api_key not in txt:
                            continue
                        cfg = json.loads(txt)
                        patched = False
                        for _sn, sv in cfg.get("mcpServers", {}).items():
                            env = sv.get("env", {})
                            if env.get("TALON_API_KEY") == api_key:
                                env["TALON_API_KEY"] = new_key
                                patched = True
                        if patched:
                            import os as _os2
                            tmp = p.parent / f".mcp.json.tmp.{_os2.getpid()}"
                            tmp.write_text(json.dumps(cfg, indent=2) + "\n")
                            tmp.rename(p)
                except Exception:
                    pass
            return
    except Exception:
        pass

    # Record failed attempt for backoff
    try:
        st = json.loads(_STATE.read_text()) if _STATE.exists() else {}
        _STATE.write_text(json.dumps({
            "last_attempt": time.time(),
            "attempt_count": st.get("attempt_count", 0) + 1,
        }))
    except Exception:
        pass


_main()
'''


def _deploy_cc_hook() -> None:
    """Write talon-client.py hook to ~/.claude/hooks/ and register in settings.json.

    Idempotent — skips write if script content and settings entry are unchanged.
    Called at login and on every main() invocation.
    """
    try:
        # Write hook script (update if content changed)
        _CC_HOOKS_DIR.mkdir(parents=True, exist_ok=True)
        if not _CC_HOOK_PATH.exists() or _CC_HOOK_PATH.read_text() != _CC_HOOK_SCRIPT:
            _CC_HOOK_PATH.write_text(_CC_HOOK_SCRIPT)
            _CC_HOOK_PATH.chmod(0o755)

        # Register in ~/.claude/settings.json hooks.UserPromptSubmit
        data: dict = {}
        if _CC_SETTINGS_PATH.exists():
            try:
                data = json.loads(_CC_SETTINGS_PATH.read_text())
            except Exception:
                data = {}

        cmd = f"python3 {_CC_HOOK_PATH}"
        hooks = data.setdefault("hooks", {})
        submit_hooks: list = hooks.setdefault("UserPromptSubmit", [])

        # Check if already registered
        already = any(
            any(h.get("command") == cmd for h in rule.get("hooks", []))
            for rule in submit_hooks
        )
        if not already:
            submit_hooks.append({
                "hooks": [{"type": "command", "command": cmd, "timeout": 5}]
            })
            _CC_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            _CC_SETTINGS_PATH.write_text(json.dumps(data, indent=2) + "\n")
    except Exception:
        pass  # non-fatal


_VERSION_CACHE_PATH = Path.home() / ".talon" / "version_cache.json"
_VERSION_CHECK_INTERVAL = 3600  # check at most once per hour


def _check_for_update(silent: bool = True) -> dict | None:
    """Check cloud for a newer wheel version. Returns update info dict or None.

    Hits GET /cloud/v1/version — response: {latest, minimum, critical, changelog}.
    Caches result for 1 hour to avoid hammering the endpoint on every invocation.
    Runs silently by default (never blocks or raises).
    """
    import time

    try:
        # Honour cache
        if _VERSION_CACHE_PATH.exists():
            cache = json.loads(_VERSION_CACHE_PATH.read_text())
            if time.time() - cache.get("checked_at", 0) < _VERSION_CHECK_INTERVAL:
                info = cache.get("info")
                if info and info.get("latest"):
                    from talon import __version__
                    if _version_newer(info["latest"], __version__):
                        return info
                return None

        cloud_url = TALON_CLOUD_URL
        if _CREDS_PATH.exists():
            try:
                cloud_url = json.loads(_CREDS_PATH.read_text()).get("cloud_url", TALON_CLOUD_URL)
            except Exception:
                pass

        import urllib.request
        req = urllib.request.Request(
            f"{cloud_url.rstrip('/')}/cloud/v1/version",
            headers={"User-Agent": f"talon-client/{_get_installed_version()}"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            info = json.loads(resp.read())

        _VERSION_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        _VERSION_CACHE_PATH.write_text(json.dumps({"checked_at": time.time(), "info": info}))

        from talon import __version__
        if _version_newer(info.get("latest", ""), __version__):
            return info
    except Exception:
        pass
    return None


def _get_installed_version() -> str:
    try:
        from talon import __version__
        return __version__
    except Exception:
        return "unknown"


def _version_newer(remote: str, local: str) -> bool:
    """Return True if remote version is strictly newer than local."""
    try:
        def _parse(v: str) -> tuple[int, ...]:
            return tuple(int(x) for x in v.strip().split("."))
        return _parse(remote) > _parse(local)
    except Exception:
        return False


_LAST_VERSION_PATH = Path.home() / ".talon" / "last_version.json"


def _save_last_version(version: str) -> None:
    """Record current version before upgrade so rollback is possible."""
    import time
    try:
        _LAST_VERSION_PATH.parent.mkdir(parents=True, exist_ok=True)
        _LAST_VERSION_PATH.write_text(json.dumps({"version": version, "saved_at": time.time()}))
    except Exception:
        pass


_TALON_INDEX_URL = "https://api.cogmeta.ai/simple/"


def _detect_install_method() -> tuple[bool, list[str]]:
    """Return (is_pipx, base_cmd_prefix) for the current talon installation."""
    import shutil
    import subprocess

    talon_venv = Path.home() / ".talon-venv"
    if (talon_venv / "bin" / "python").exists():
        uv = shutil.which("uv")
        if uv:
            return False, [uv, "pip", "install", "--python", str(talon_venv / "bin" / "python")]
        return False, [str(talon_venv / "bin" / "python"), "-m", "pip", "install"]

    pipx = subprocess.run(["which", "pipx"], capture_output=True, timeout=10).returncode == 0
    if pipx:
        result = subprocess.run(["pipx", "list", "--short"], capture_output=True, text=True, timeout=15)
        if "talon" in result.stdout:
            return True, ["pipx"]
    return False, [sys.executable, "-m", "pip", "install"]


def _install_version(version: str | None, pipx: bool, pip_cmd: list[str]) -> list[str]:
    """Build the install command for a specific or latest version."""
    pkg = f"cogmeta-talon=={version}" if version else "cogmeta-talon"
    if pipx:
        return ["pipx", "install", "--force", pkg, f"--pip-args=--extra-index-url={_TALON_INDEX_URL}"]
    return [*pip_cmd, "--extra-index-url", _TALON_INDEX_URL, "--reinstall", pkg]


def _find_talon_bin() -> Path:
    """Find the talon binary directory — pipx venv or legacy .talon-venv."""
    import shutil
    # Prefer whichever is on PATH right now (works for both pipx and legacy)
    talon_bin = shutil.which("talon-statusline")
    if talon_bin:
        return Path(talon_bin).parent
    # pipx with cogmeta-talon package name
    pipx_cogmeta = Path.home() / ".local" / "share" / "pipx" / "venvs" / "cogmeta-talon" / "bin"
    if pipx_cogmeta.exists():
        return pipx_cogmeta
    # pipx with old talon package name
    pipx_venv = Path.home() / ".local" / "share" / "pipx" / "venvs" / "talon" / "bin"
    if pipx_venv.exists():
        return pipx_venv
    # Legacy manual venv
    legacy = Path.home() / ".talon-venv" / "bin"
    return legacy


def _reinstall_hooks() -> None:
    """Update settings.json to point statusLine + hooks at venv entry points."""
    venv_bin = _find_talon_bin()
    settings_path = Path.home() / ".claude" / "settings.json"
    try:
        settings: dict = {}
        if settings_path.exists():
            settings = json.loads(settings_path.read_text())

        # Fix any stale .talon-venv paths — walk settings tree, not naive string replace
        stale_venv = str(Path.home() / ".talon-venv" / "bin")
        new_venv = str(venv_bin)
        if stale_venv != new_venv:
            def _fix_paths(obj):  # noqa: ANN001
                if isinstance(obj, str) and stale_venv in obj:
                    return obj.replace(stale_venv, new_venv)
                if isinstance(obj, dict):
                    return {k: _fix_paths(v) for k, v in obj.items()}
                if isinstance(obj, list):
                    return [_fix_paths(v) for v in obj]
                return obj
            settings = _fix_paths(settings)

        settings["statusLine"] = {
            "type": "command",
            "command": str(venv_bin / "talon-statusline"),
        }
        hooks = settings.setdefault("hooks", {})
        ups = hooks.setdefault("UserPromptSubmit", [])
        hook_cmd = str(venv_bin / "talon-prompt-hook")
        already = any(
            hook_cmd in h.get("command", "")
            for entry in ups
            for h in entry.get("hooks", [])
        )
        if not already:
            ups.append({
                "matcher": "",
                "hooks": [{"type": "command", "command": hook_cmd, "timeout": 5}],
            })
        _tmp_s = settings_path.parent / f".settings.json.tmp.{os.getpid()}"
        _tmp_s.write_text(json.dumps(settings, indent=2) + "\n")
        _tmp_s.rename(settings_path)
        print("  Updated statusLine + hooks in settings.json")
    except Exception as e:
        print(f"  Warning: could not update settings.json: {e}", file=sys.stderr)

    # Update skill file
    try:
        skill_src = None
        for pyver in ["python3.12", "python3.13", "python3.14", "python3.11"]:
            candidate = venv_bin.parent / "lib" / pyver / "site-packages" / "talon" / "skills" / "SKILL.md"
            if candidate.exists():
                skill_src = candidate
                break
        if skill_src:
            skill_dir = Path.home() / ".claude" / "skills" / "talon"
            skill_dir.mkdir(parents=True, exist_ok=True)
            (skill_dir / "SKILL.md").write_text(skill_src.read_text())
            print("  Updated /talon skill")
    except Exception:
        pass


def _cleanup_stale_venv() -> None:
    """Remove stale .talon-venv symlinks from ~/.local/bin if present.

    When migrating from .talon-venv to pipx, old symlinks in ~/.local/bin
    point to the defunct venv and block pipx from creating its own.
    """
    talon_venv = Path.home() / ".talon-venv"
    local_bin = Path.home() / ".local" / "bin"
    if not talon_venv.exists() and not local_bin.exists():
        return

    stale_bins = [
        "talon", "talon-index", "talon-login", "talon-proxy-wrapper",
        "talon-statusline", "talon-prompt-hook", "talon",
        "talon-local", "talon-server",
    ]
    cleaned = []
    for name in stale_bins:
        link = local_bin / name
        if link.is_symlink():
            target = str(link.resolve())
            if ".talon-venv" in target:
                link.unlink()
                cleaned.append(name)
    if cleaned:
        print(f"  Cleaned {len(cleaned)} stale symlinks from ~/.local/bin")

    if talon_venv.exists():
        import shutil
        shutil.rmtree(talon_venv, ignore_errors=True)
        print("  Removed stale ~/.talon-venv")


def _cmd_upgrade(args: argparse.Namespace) -> int:
    """Handle 'talon upgrade [--version X.Y.Z] [--rollback] [--force]'."""
    import subprocess

    force = getattr(args, "force", False)
    target_version: str | None = getattr(args, "version", None)
    rollback = getattr(args, "rollback", False)

    current = _get_installed_version()

    _cleanup_stale_venv()

    pipx, pip_cmd = _detect_install_method()

    # ── Rollback mode ─────────────────────────────────────────────────────────
    if rollback:
        if not _LAST_VERSION_PATH.exists():
            print("No previous version recorded. Cannot roll back.", file=sys.stderr)
            return 1
        prev = json.loads(_LAST_VERSION_PATH.read_text()).get("version", "")
        if not prev:
            print("No previous version recorded. Cannot roll back.", file=sys.stderr)
            return 1
        if prev == current:
            print(f"Already on {current} — nothing to roll back.")
            return 0
        print(f"Rolling back talon {current} → {prev}")
        target_version = prev

    # ── Version-specified or latest ───────────────────────────────────────────
    if not rollback:
        if target_version:
            # User picked a specific version
            if target_version == current and not force:
                print(f"Already on talon {current}")
                return 0
            print(f"Installing talon {target_version} (current: {current})")
        else:
            _VERSION_CACHE_PATH.unlink(missing_ok=True)
            info = _check_for_update(silent=False)
            if not force and not info:
                print(f"Already up to date (talon {current})")
                return 0
            latest_label = info.get("latest", "latest") if info else "latest"
            changelog = info.get("changelog", "") if info else ""
            print(f"Upgrading talon {current} → {latest_label}")
            if changelog:
                print(f"  {changelog}")

    print()

    # ── Save current version for rollback ─────────────────────────────────────
    _save_last_version(current)

    # ── Run install ────────────────────────────────────────────────────────────
    # target_version is only set when the user explicitly picked a version or rollback;
    # for "latest" upgrades it stays None so _install_version uses the self-hosted wheel.
    cmd = _install_version(target_version, pipx, pip_cmd)
    print(f"Running: {' '.join(cmd)}")
    env = {**os.environ, "UV_SKIP_WHEEL_FILENAME_CHECK": "1"}
    try:
        result = subprocess.run(cmd, env=env, timeout=300)
    except subprocess.TimeoutExpired:
        print("\nInstall timed out after 5 minutes.", file=sys.stderr)
        return 1

    if result.returncode == 0:
        print()
        installed = target_version or "latest"
        print(f"✓ talon {installed} installed")
        _VERSION_CACHE_PATH.unlink(missing_ok=True)
        if rollback:
            _LAST_VERSION_PATH.unlink(missing_ok=True)
        _reinstall_hooks()
        return 0

    # ── Upgrade failed — auto-rollback ────────────────────────────────────────
    print(f"\nUpgrade failed (exit {result.returncode}).", file=sys.stderr)
    if not rollback and _LAST_VERSION_PATH.exists():
        prev = json.loads(_LAST_VERSION_PATH.read_text()).get("version", "")
        if prev and prev != current:
            print(f"Auto-rolling back to talon {prev}...", file=sys.stderr)
            rb_cmd = _install_version(prev, pipx, pip_cmd)
            rb_result = subprocess.run(rb_cmd, capture_output=True, env=env)
            if rb_result.returncode == 0:
                print(f"✓ Rolled back to talon {prev}", file=sys.stderr)
                _LAST_VERSION_PATH.unlink(missing_ok=True)
                _VERSION_CACHE_PATH.unlink(missing_ok=True)
            else:
                print(f"Rollback also failed. To restore manually:", file=sys.stderr)
                print(f"  {'pipx install --force' if pipx else 'pip install'} talon=={prev}", file=sys.stderr)
        else:
            print(f"To retry:  {'pipx upgrade talon' if pipx else 'pip install --upgrade talon'}", file=sys.stderr)
    else:
        print(f"To retry:  {'pipx upgrade talon' if pipx else 'pip install --upgrade talon'}", file=sys.stderr)
    return 1


def _notify_update_if_available() -> None:
    """Print a one-line update notice if a newer version exists. Non-blocking.

    Also warns if current version is below the server-advertised minimum.
    """
    try:
        info = _check_for_update()
        if not info:
            # Even if no update exists, check minimum from cache
            try:
                cached = json.loads(_VERSION_CACHE_PATH.read_text()) if _VERSION_CACHE_PATH.exists() else {}
                cached_info = cached.get("info", {})
                minimum = cached_info.get("minimum", "")
                current = _get_installed_version()
                if minimum and _version_newer(minimum, current):
                    print(f"  ⚠ talon {current} is below minimum supported version {minimum}. Run: talon upgrade")
            except Exception:
                pass
            return
        latest = info.get("latest", "")
        minimum = info.get("minimum", "")
        critical = info.get("critical", False)
        current = _get_installed_version()
        if minimum and _version_newer(minimum, current):
            # Below minimum — stronger warning than a regular update notice
            print(f"  ⚠ talon {current} is unsupported (minimum: {minimum}). Run: talon upgrade")
        elif critical:
            print(f"  ⚠ CRITICAL UPDATE: talon {latest} available (you have {current}). Run: talon upgrade")
        else:
            print(f"  → Update available: talon {latest}  (run: talon upgrade)")
    except Exception:
        pass


def _register_cc_permissions() -> None:
    """Add talon command patterns to ~/.claude/settings.json permissions.allow.

    Runs once at login so the user never sees per-command approval prompts
    for /talon skill commands.
    """
    try:
        data: dict = {}
        if _CC_SETTINGS_PATH.exists():
            try:
                data = json.loads(_CC_SETTINGS_PATH.read_text())
            except Exception:
                data = {}

        perms = data.setdefault("permissions", {})
        allow: list = perms.setdefault("allow", [])

        added = 0
        for pattern in _CC_ALLOWED_PATTERNS:
            if pattern not in allow:
                allow.append(pattern)
                added += 1

        if added:
            _CC_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            _tmp_settings = _CC_SETTINGS_PATH.parent / f".settings.json.tmp.{os.getpid()}"
            _tmp_settings.write_text(json.dumps(data, indent=2) + "\n")
            _tmp_settings.rename(_CC_SETTINGS_PATH)
    except Exception:
        pass  # non-fatal


def _cmd_auth_login(args: argparse.Namespace, signup: bool = False) -> int:
    """Device-code login — opens browser, polls cloud for the API key.

    No localhost server needed.  Works through SSH, containers, WSL,
    corporate firewalls — the CLI only makes outbound HTTPS to the cloud.

    Writes URL to ~/.talon/login_url.txt immediately so the CC skill
    can display it before blocking. Writes ~/.talon/login_done.txt on
    completion so the skill knows when to show the result.
    """
    import secrets
    import ssl
    import time
    import urllib.request
    import webbrowser

    cloud_url = getattr(args, "cloud_url", TALON_CLOUD_URL) or TALON_CLOUD_URL
    base = cloud_url.rstrip("/").replace("://api.", "://app.")

    # Clean stale files
    _LOGIN_URL_FILE.unlink(missing_ok=True)
    _LOGIN_DONE_FILE.unlink(missing_ok=True)

    # ── 1. Generate a device code (256-bit entropy via secrets) ──────────
    cli_id = secrets.token_urlsafe(32)

    # ── 2. Write URL file BEFORE opening browser so skill can read it ─────
    page = "register.html" if signup else "signin.html"
    url = f"{base}/{page}?cli={cli_id}"
    _LOGIN_URL_FILE.write_text(url)

    print(f"\n  Open this URL in your browser to sign in:\n")
    print(f"    {url}\n")
    print("  Waiting for login...", end="", flush=True)

    # Try to open browser automatically (may fail on headless/remote machines)
    try:
        webbrowser.open(url)
    except Exception:
        pass

    # ── 3. Poll for the API key ───────────────────────────────────────────
    poll_url = f"{base}/cloud/v1/auth/cli-poll?cli_id={cli_id}"
    ctx = ssl.create_default_context()
    if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

    data: dict = {}
    deadline = time.monotonic() + 300  # 5 min timeout
    try:
        while time.monotonic() < deadline:
            time.sleep(2)
            try:
                req = urllib.request.Request(poll_url, headers={"User-Agent": "talon-cli/0.7"})
                resp = urllib.request.urlopen(req, timeout=5, context=ctx)
                if resp.status == 200:
                    data = json.loads(resp.read())
                    break
            except urllib.error.HTTPError as e:
                if e.code == 204:
                    continue
                _LOGIN_DONE_FILE.write_text(f"ERROR: poll returned {e.code}")
                return 1
            except Exception:
                continue
        else:
            _LOGIN_DONE_FILE.write_text("ERROR: timed out waiting for login")
            return 1
    except KeyboardInterrupt:
        _LOGIN_DONE_FILE.write_text("ERROR: cancelled")
        return 1

    api_key = data.get("api_key", "")
    if not api_key:
        _LOGIN_DONE_FILE.write_text("ERROR: no API key received")
        return 1

    # ── 4. Save credentials ───────────────────────────────────────────────
    _CREDS_PATH.parent.mkdir(parents=True, exist_ok=True)
    creds = {
        "api_key": api_key,
        "email": data.get("email", ""),
        "name": data.get("name", ""),
        "cloud_url": base,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    _tmp_creds = _CREDS_PATH.parent / f".credentials.tmp.{os.getpid()}"
    _tmp_creds.write_text(json.dumps(creds, indent=2))
    _tmp_creds.chmod(0o600)
    _tmp_creds.rename(_CREDS_PATH)

    # Pre-register talon commands so CC never prompts per-command
    _register_cc_permissions()
    _deploy_cc_hook()

    done_lines = [f"✓ Logged in as: {creds['email'] or '(unknown)'}"]
    try:
        project_root = detect_project_root() or Path.home()
        config_path = write_mcp_config(
            project_root, cloud=True, cloud_url=base, api_key=api_key, force=True,
        )
        done_lines.append(f"✓ .mcp.json written: {config_path}")
        done_lines.append("")
        done_lines.append("Next steps:")
        done_lines.append("  1. Restart Claude Code to activate the MCP connection")
        done_lines.append("  2. Run /talon index from your repo root to index the project")
    except Exception as exc:
        done_lines.append(f"  (Could not write .mcp.json: {exc})")

    _LOGIN_DONE_FILE.write_text("\n".join(done_lines))
    print("\n".join(done_lines), flush=True)
    return 0


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------
# Check command — talon check
# ---------------------------------------------------------------------------


def _cmd_check(args: argparse.Namespace) -> int:
    """Pre-flight check: version, MCP connection, CLAUDE.md, index status."""
    import ssl
    import subprocess
    import urllib.request

    project_path = Path(args.path).resolve() if getattr(args, "path", None) else Path.cwd().resolve()
    passed = 0
    failed = 0
    warnings = 0

    def _ok(msg: str) -> None:
        nonlocal passed
        passed += 1
        print(f"  \033[32m✓\033[0m {msg}")

    def _fail(msg: str, fix: str = "") -> None:
        nonlocal failed
        failed += 1
        print(f"  \033[31m✗\033[0m {msg}")
        if fix:
            print(f"    Fix: {fix}")

    def _warn(msg: str, fix: str = "") -> None:
        nonlocal warnings
        warnings += 1
        print(f"  \033[33m!\033[0m {msg}")
        if fix:
            print(f"    Fix: {fix}")

    # ── 1. Version ────────────────────────────────────────────────────────
    print("\n\033[1;36m==> Version\033[0m")
    current = _get_installed_version()
    _ok(f"talon {current} installed")

    info = _check_for_update(silent=True)
    if info:
        latest = info.get("latest", "?")
        _fail(f"Update available: {current} → {latest}", "talon upgrade")
    else:
        _ok("Up to date")

    # ── 2. Auth ───────────────────────────────────────────────────────────
    print("\n\033[1;36m==> Authentication\033[0m")
    creds_path = Path.home() / ".talon" / "credentials.json"
    api_key = ""
    cloud_url = TALON_CLOUD_URL
    if creds_path.exists():
        try:
            creds = json.loads(creds_path.read_text())
            api_key = creds.get("api_key", "")
            cloud_url = creds.get("cloud_url", TALON_CLOUD_URL)
            if api_key:
                _ok(f"API key: {api_key[:12]}...")
            else:
                _fail("No API key in credentials", "talon auth login")
        except Exception:
            _fail("Corrupt credentials file", "talon auth login")
    else:
        _fail("Not logged in", "talon auth login")

    # ── 3. MCP Config ─────────────────────────────────────────────────────
    print("\n\033[1;36m==> MCP Configuration\033[0m")
    mcp_found = False
    mcp_mode = "unknown"
    for config_file in [
        Path.home() / ".claude.json",
        Path.home() / ".mcp.json",
        project_path / ".mcp.json",
    ]:
        if config_file.exists():
            try:
                d = json.loads(config_file.read_text())
                talon_entry = d.get("mcpServers", {}).get("talon", {})
                if talon_entry:
                    cmd = talon_entry.get("command", "")
                    if "mcp-proxy" in cmd:
                        mcp_mode = "cloud"
                    elif "talon-local" in cmd:
                        mcp_mode = "local"
                    _ok(f"talon MCP configured in {config_file} (mode: {mcp_mode})")
                    mcp_found = True
                    break
            except Exception:
                pass
    if not mcp_found:
        _fail("talon MCP not configured", "talon init")

    # ── 4. MCP Reachability ───────────────────────────────────────────────
    print("\n\033[1;36m==> MCP Server\033[0m")
    if api_key:
        try:
            sse_url = f"{cloud_url.rstrip('/')}/talon/mcp/sse"
            ctx = ssl.create_default_context()
            if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(sse_url, headers={"Accept": "text/event-stream", "X-API-Key": api_key})
            resp = urllib.request.urlopen(req, timeout=5, context=ctx)
            first_line = resp.readline().decode().strip()
            if "endpoint" in first_line or "event" in first_line:
                _ok("Cloud MCP SSE reachable")
            else:
                _warn(f"Unexpected SSE response: {first_line}")
        except Exception as e:
            _fail(f"Cloud MCP unreachable: {e}")
    else:
        _warn("Skipped — no API key")

    # talon-proxy-wrapper (cloud mode bridge)
    proxy_wrapper = shutil.which("talon-proxy-wrapper")
    if proxy_wrapper:
        _ok(f"talon-proxy-wrapper at {proxy_wrapper}")
    else:
        pipx_venv = Path.home() / ".local" / "share" / "pipx" / "venvs" / "talon" / "bin"
        pw = pipx_venv / "talon-proxy-wrapper"
        mp = pipx_venv / "mcp-proxy"
        if pw.exists():
            _ok(f"talon-proxy-wrapper at {pw}")
        elif mp.exists():
            _ok(f"mcp-proxy at {mp}")
        else:
            _warn("talon-proxy-wrapper not on PATH (cloud mode needs it)", "pipx install talon")

    # ── 5. CLAUDE.md + AGENTS.md ─────────────────────────────────────────
    print("\n\033[1;36m==> Project Guidance\033[0m")
    agents_md = project_path / "AGENTS.md"
    claude_md = project_path / "CLAUDE.md"
    if agents_md.exists():
        agents_content = agents_md.read_text()
        if "graph_ask_lite" in agents_content:
            _ok(f"AGENTS.md has talon tool guidance ({agents_md})")
        else:
            _fail("AGENTS.md exists but missing talon tool guidance", "talon init --force")
    else:
        _fail(f"No AGENTS.md at {agents_md}", "talon init")
    if claude_md.exists():
        claude_content = claude_md.read_text()
        if "AGENTS.md" in claude_content:
            _ok(f"CLAUDE.md references AGENTS.md")
        else:
            _warn("CLAUDE.md exists but doesn't reference AGENTS.md", "talon init --force")
    else:
        _warn(f"No CLAUDE.md at {claude_md}", "talon init")

    # ── 6. Settings (statusLine + hooks) ──────────────────────────────────
    print("\n\033[1;36m==> Claude Code Settings\033[0m")
    settings_path = Path.home() / ".claude" / "settings.json"
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
            sl = settings.get("statusLine", {})
            if "talon-statusline" in sl.get("command", ""):
                _ok("statusLine configured")
            else:
                _warn("statusLine not pointing to talon-statusline", "Re-run install or talon upgrade")

            hooks = settings.get("hooks", {})
            ups = hooks.get("UserPromptSubmit", [])
            has_prompt_hook = any(
                "talon-prompt-hook" in h.get("command", "")
                for entry in ups
                for h in entry.get("hooks", [])
            )
            if has_prompt_hook:
                _ok("UserPromptSubmit hook configured")
            else:
                _warn("prompt hook not configured", "Re-run install")
        except Exception:
            _warn("Could not parse settings.json")
    else:
        _warn("No settings.json found")

    # ── 7. Index status ───────────────────────────────────────────────────
    print("\n\033[1;36m==> Project Index\033[0m")
    if api_key:
        try:
            project_id = project_path.name
            url = f"{cloud_url.rstrip('/')}/cloud/v1/projects/{project_id}/status"
            ctx = ssl.create_default_context()
            if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(url, headers={"X-API-Key": api_key})
            resp = urllib.request.urlopen(req, timeout=5, context=ctx)
            data = json.loads(resp.read())
            if data.get("indexed"):
                n_files = data.get("files", 0)
                n_symbols = data.get("symbols", 0)
                _ok(f"Indexed: {n_files} files, {n_symbols} symbols")
            else:
                _warn("Project not indexed on cloud", "talon index")
        except urllib.error.HTTPError as e:
            if e.code == 404:
                _warn("Project not registered on cloud", "talon index")
            else:
                _warn(f"Could not check index: HTTP {e.code}")
        except Exception as e:
            _warn(f"Could not check index: {e}")
    else:
        _warn("Skipped — no API key")

    # ── Summary ───────────────────────────────────────────────────────────
    print()
    total = passed + failed + warnings
    if failed == 0:
        print(f"\033[1;32m  All {passed}/{total} checks passed.\033[0m")
        if warnings:
            print(f"\033[33m  {warnings} warning(s)\033[0m")
    else:
        print(f"\033[1;31m  {failed} check(s) FAILED\033[0m, {passed} passed, {warnings} warning(s)")
    print()

    return 1 if failed > 0 else 0


# ---------------------------------------------------------------------------


def main() -> None:
    """Entry point for talon command."""
    _install_skill()
    _register_cc_permissions()  # idempotent — runs on every invocation, no-op if already set
    _deploy_cc_hook()           # idempotent — deploys renewal hook to ~/.claude/hooks/
    _notify_update_if_available()
    parser = _build_parser()
    args = parser.parse_args()

    if args.command is None:
        print("Talon is installed. Use these commands inside Claude Code:")
        print()
        print("  /talon login     Log in to cogmeta.ai (opens browser)")
        print("  /talon index     Index this project + register with cloud")
        print("  /talon health    Check connection status")
        print("  /talon auth      Show logged-in user and API key")
        print("  /talon upgrade   Upgrade to the latest version")
        print()
        print("Or run:  talon init --cloud  to generate .mcp.json manually")
        sys.exit(0)

    handlers = {
        "version": lambda _: (print(f"talon {__import__('talon').__version__}"), 0)[1],
        "init": _cmd_init,
        "test": _cmd_test,
        "claude-md": _cmd_claude_md,
        "status": _cmd_status,
        "refresh": _cmd_refresh,
        "pull": _cmd_pull,
        "auth": _cmd_auth,
        "upgrade": _cmd_upgrade,
        "check": _cmd_check,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    try:
        exit_code = handler(args)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        exit_code = 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        exit_code = 1

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
