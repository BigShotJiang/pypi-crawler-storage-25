"""Talon setup helper for Claude Code integration.

Generates MCP configurations (.mcp.json) and CLAUDE.md snippets that enable
Claude Code to discover and connect to the Talon MCP server via stdio transport.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_LOG_LEVEL = "WARNING"


def _get_db_defaults() -> tuple[str, str, str]:
    """Get graph DB defaults from settings or environment."""
    try:
        from talon.config.settings import get_settings

        s = get_settings()
        return s.arango_url, s.arango_database, s.arango_password
    except Exception:
        url = os.environ.get("TALON_DB_URL", os.environ.get("TALON_ARANGO_URL", "http://localhost:8530"))
        db = os.environ.get("TALON_DB_NAME", os.environ.get("TALON_ARANGO_DATABASE", "talon"))
        pw = os.environ.get("TALON_DB_PASS", os.environ.get("TALON_ARANGO_PASS", ""))
        return url, db, pw

MCP_CONFIG_FILENAME = ".mcp.json"

PROJECT_MARKERS = (".git", "pyproject.toml", "package.json", "Cargo.toml", "go.mod", "pom.xml")


# ---------------------------------------------------------------------------
# MCP Config Generation
# ---------------------------------------------------------------------------


DEFAULT_K8S_SSE_URL = os.environ.get("TALON_K8S_SSE_URL", "")


TALON_CLOUD_URL = "https://api.cogmeta.ai"


def _resolve_proxy_bin() -> str:
    import shutil
    if shutil.which("mcp-proxy"):
        return "mcp-proxy"
    venv_bin = Path.home() / ".talon-venv" / "bin" / "mcp-proxy"
    if venv_bin.exists():
        return str(venv_bin)
    return "mcp-proxy"


def generate_mcp_config(
    project_path: str | Path,
    log_level: str = DEFAULT_LOG_LEVEL,
    k8s: bool = False,
    sse_url: str | None = None,
    project_id: str | None = None,
    bearer_token: str | None = None,
    cloud: bool = False,
    api_key: str | None = None,
    cloud_url: str = TALON_CLOUD_URL,
    # Local self-hosted DB connection (generic — server handles the backend)
    db_url: str | None = None,
    db_name: str | None = None,
    db_pass: str | None = None,
    # Legacy aliases kept for backward compat
    arango_url: str | None = None,
    arango_database: str | None = None,
    arango_pass: str | None = None,
) -> dict[str, Any]:
    """Generate an MCP config dict suitable for writing to .mcp.json.

    Three modes:
    - **Cloud (default):** Uses ``mcp-proxy`` to bridge stdio to the cloud
      SSE endpoint. No local infra needed.
    - **Local:** Spawns ``talon-local`` as a stdio subprocess. Server handles
      its own database config internally.
    - **K8s:** Uses ``mcp-proxy`` to bridge stdio to a K8s SSE endpoint.

    Returns:
        Dict matching the Claude Code .mcp.json schema.
    """
    if cloud:
        base = cloud_url.rstrip("/")
        sse_endpoint = f"{base}/talon/mcp/sse"
        cloud_config: dict[str, Any] = {
            "mcpServers": {
                "talon": {
                    "command": "talon-proxy-wrapper",
                    "args": [sse_endpoint],
                    "env": {
                        "TALON_CLOUD_URL": cloud_url.rstrip("/"),
                    },
                }
            }
        }
        return cloud_config

    if k8s:
        url = sse_url or DEFAULT_K8S_SSE_URL
        k8s_config: dict[str, Any] = {
            "mcpServers": {
                "talon": {
                    "command": "mcp-proxy",
                    "args": [url],
                }
            }
        }
        if bearer_token:
            k8s_config["mcpServers"]["talon"]["env"] = {
                "TALON_BEARER_TOKEN": bearer_token,
            }
        return k8s_config

    args_list = ["--project-path", str(Path(project_path).resolve())]
    if project_id:
        args_list.extend(["--project-id", project_id])

    config: dict[str, Any] = {
        "mcpServers": {
            "talon": {
                "command": "talon-local",
                "args": args_list,
            }
        }
    }

    # Graph DB config for local/self-hosted MCP server — use generic env vars
    _db_url = db_url or arango_url
    _db_name = db_name or arango_database
    _db_pass = db_pass or arango_pass
    if _db_url or _db_name or _db_pass:
        env: dict[str, str] = {}
        if _db_url:
            env["TALON_DB_URL"] = _db_url
        if _db_name:
            env["TALON_DB_NAME"] = _db_name
        if _db_pass:
            env["TALON_DB_PASS"] = _db_pass
        config["mcpServers"]["talon"]["env"] = env

    return config


def write_mcp_config(
    project_path: str | Path,
    log_level: str = DEFAULT_LOG_LEVEL,
    force: bool = False,
    k8s: bool = False,
    sse_url: str | None = None,
    project_id: str | None = None,
    cloud: bool = False,
    api_key: str | None = None,
    cloud_url: str = TALON_CLOUD_URL,
    db_url: str | None = None,
    db_name: str | None = None,
    db_pass: str | None = None,
    **_kwargs: Any,
) -> Path:
    """Write .mcp.json to the project directory.

    Args:
        project_path: Directory to write .mcp.json into.
        log_level: Log level for server subprocess (local mode only).
        force: If True, overwrite existing .mcp.json.
        k8s: If True, use mcp-proxy to connect to K8s SSE endpoint.
        sse_url: Custom SSE URL for K8s mode.
        cloud: If True, generate cloud-mode config with API key.
        api_key: Talon API key (cloud mode only).
        cloud_url: Talon cloud API URL (cloud mode only).

    Returns:
        Path to the written .mcp.json file.

    Raises:
        FileExistsError: If .mcp.json exists and force is False.
        NotADirectoryError: If project_path is not a directory.
    """
    project_path = Path(project_path).resolve()
    if not project_path.is_dir():
        raise NotADirectoryError(f"Not a directory: {project_path}")

    config_path = project_path / MCP_CONFIG_FILENAME

    if config_path.exists() and not force:
        raise FileExistsError(
            f"{MCP_CONFIG_FILENAME} already exists at {config_path}. "
            f"Use --force to overwrite."
        )

    config = generate_mcp_config(
        project_path=project_path,
        log_level=log_level,
        k8s=k8s,
        sse_url=sse_url,
        project_id=project_id,
        cloud=cloud,
        api_key=api_key,
        cloud_url=cloud_url,
        db_url=db_url,
        db_name=db_name,
        db_pass=db_pass,
    )

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    return config_path


def read_mcp_config(project_path: str | Path) -> dict[str, Any] | None:
    """Read and parse existing .mcp.json from project directory.

    Returns None if the file does not exist.
    """
    config_path = Path(project_path).resolve() / MCP_CONFIG_FILENAME
    if not config_path.exists():
        return None

    with open(config_path) as f:
        return json.load(f)


def refresh_config(project_path: str | Path) -> dict[str, Any]:
    """Refresh an existing .mcp.json by regenerating tool descriptions from contracts.

    Preserves custom env vars and connection settings from the existing config.
    Only updates the tool-description-related fields.

    Args:
        project_path: Directory containing .mcp.json.

    Returns:
        Dict with keys: ``changed`` (bool), ``old_config``, ``new_config``,
        ``config_path`` (str).

    Raises:
        FileNotFoundError: If .mcp.json does not exist.
    """
    project_path = Path(project_path).resolve()
    config_path = project_path / MCP_CONFIG_FILENAME

    if not config_path.exists():
        raise FileNotFoundError(f"No {MCP_CONFIG_FILENAME} found at {config_path}")

    with open(config_path) as f:
        old_config = json.load(f)

    # Get existing talon server config
    talon_entry = old_config.get("mcpServers", {}).get("talon", {})
    is_k8s = talon_entry.get("command") == "mcp-proxy"

    if is_k8s:
        # K8s mode: just regenerate with same SSE URL
        args = talon_entry.get("args", [])
        sse_url = args[0] if args else DEFAULT_K8S_SSE_URL
        new_config = generate_mcp_config(
            project_path=project_path,
            k8s=True,
            sse_url=sse_url,
        )
    else:
        # Local mode: preserve env vars
        env = talon_entry.get("env", {})
        _url, _db, _pass = _get_db_defaults()
        new_config = generate_mcp_config(
            project_path=project_path,
            db_url=env.get("TALON_DB_URL", env.get("TALON_ARANGO_URL", _url)),
            db_name=env.get("TALON_DB_NAME", env.get("TALON_ARANGO_DATABASE", _db)),
            db_pass=env.get("TALON_DB_PASS", env.get("TALON_ARANGO_PASS", _pass)),
            log_level=env.get("TALON_LOG_LEVEL", DEFAULT_LOG_LEVEL),
        )
        # Preserve any custom env vars the user added
        new_env = new_config["mcpServers"]["talon"].get("env", {})
        for k, v in env.items():
            if k not in new_env:
                new_env[k] = v
        new_config["mcpServers"]["talon"]["env"] = new_env

    changed = old_config != new_config
    if changed:
        with open(config_path, "w") as f:
            json.dump(new_config, f, indent=2)
            f.write("\n")

    return {
        "changed": changed,
        "old_config": old_config,
        "new_config": new_config,
        "config_path": str(config_path),
    }


# ---------------------------------------------------------------------------
# CLAUDE.md Snippet Generation
# ---------------------------------------------------------------------------


def generate_claude_md_snippet() -> str:
    """Return a small CLAUDE.md ref line pointing to AGENTS.md."""
    return "@AGENTS.md\n"


def generate_agents_md() -> str:
    """Return full talon GA209 guidance for AGENTS.md."""
    return """\
# Talon Code Intelligence (MCP Tools)

This project has a **structural code graph** (AST-parsed). These tools are
authoritative — do NOT verify their results with Read/Grep/Glob.

## Tools

If a `<system-reminder>` shows talon tools as deferred, call
`ToolSearch(query="select:mcp__talon__graph_ask_lite,mcp__talon__graph_query,mcp__talon__smart_read_batch,mcp__talon__edit_batch")`
once to load schemas, then proceed. After that, never call ToolSearch again.

| Tool                          | Use                                                        |
| ----------------------------- | ---------------------------------------------------------- |
| `mcp__talon__graph_ask_lite`   | One-shot symbol fetch — call FIRST every prompt            |
| `mcp__talon__graph_query`      | Symbol lookup, toc, callers, flow, search, insert          |
| `mcp__talon__smart_read_batch` | Targeted line-range reads (up to 10 targets per call)      |
| `mcp__talon__edit_batch`       | Batch edits with auto-pytest                               |

## graph_ask_lite — Call This FIRST, Every Prompt

**MANDATORY first call** for any coding task. Returns files, symbol bodies,
callers, and edit hints in ONE call. AUTO-GAL may pre-inject context at
prompt start — use it as a head start, but still call graph_ask_lite.

```
mcp__talon__graph_ask_lite(task="add retry logic to the API client", expected_files=["src/api/client.py"])
```

**The bodies returned are byte-for-byte identical to source files.** Use them
directly as `old_string` in edit_batch. Do NOT re-read files already shown.

On P2+, pass files you've been editing as `expected_files` for better accuracy.
Only pass files that already exist — do NOT include new files you plan to create.

## WHY YOU MUST EDIT DIRECTLY FROM graph_ask_lite BODIES

Every smart_read_batch call replays the ENTIRE conversation context (~40K tokens).
If graph_ask_lite already gave you the function body, calling smart_read_batch to
re-read that same file wastes 40K tokens for zero new information.

## locate — Symbol Lookup

```
mcp__talon__graph_query(intent="locate", target="MiddlewareMixin", depth="full")
```

Returns exact file:line + body in ONE call. If it returns "not found", the symbol
**does not exist** — stop searching and start creating.

## smart_read_batch — BATCH OR PAY 5x

**Each smart_read_batch call costs ~40K tokens of context replay.** Before calling,
ask: did graph_ask_lite already give me this body? If yes, DO NOT re-read.

If you genuinely need code that graph_ask_lite did not provide:
1. STOP and list ALL files and line ranges you need
2. Put ALL of them into ONE smart_read_batch call

**Max 2 smart_read_batch calls per prompt.**

## edit_batch — ONE Call Per Prompt

Batch ALL edits (production + test) into a single edit_batch call:

```
mcp__talon__edit_batch(edits=[
    {"file_path": "events.py", "old_string": "...", "new_string": "..."},
    {"file_path": "tests/test_events.py", "old_string": "...", "new_string": "..."}
])
```

**edit_batch OK = done.** Do NOT read files back after edit_batch.

## Workflow — 3 Steps Per Prompt

1. `graph_ask_lite(task="...")` — bodies, symbols, edit hints
2. If you need MORE code that GAL did not provide: **ONE** `smart_read_batch`
3. **ONE** `edit_batch` with ALL changes

**Target: 3 tool calls per prompt. Maximum: 6.**

## Rules

1. **graph_ask_lite bodies ARE the source code.** Re-reading wastes 40K tokens.
2. **BATCH ALL reads into ONE smart_read_batch.** Each unbatched call = 40K wasted.
3. **ONE edit_batch per prompt.** Batch all production + test changes together.
4. **Max 2 smart_read_batch per prompt.** After 2 reads, you have enough — edit.
5. **Do NOT use** Agent, TodoWrite, EnterPlanMode, plain Read, plain Edit, Grep, Glob, or Bash.
6. **"Not found" is final.** Do not search for variants.
7. **Do NOT re-read files after compaction.** Trust session state summaries.
"""


# ---------------------------------------------------------------------------
# Connection Testing
# ---------------------------------------------------------------------------


def find_talon_server() -> str | None:
    """Find the talon-local command on PATH.

    Returns the full path to talon-local, or None if not found.
    """
    return shutil.which("talon-local") or shutil.which("talon-server")


def test_connection(timeout: int = 10) -> dict[str, Any]:
    """Test the Talon MCP server connection.

    Spawns talon-local as a subprocess and verifies it responds to MCP
    initialization and lists the expected 6 tools.

    Args:
        timeout: Maximum seconds to wait for server response.

    Returns:
        Dict with test results including:
        - server_found: bool -- talon-local is on PATH
        - server_path: str | None -- full path to talon-local
        - startup_ok: bool -- server started without error
        - tools_listed: bool -- list_tools returned results
        - tool_count: int -- number of tools returned
        - tool_names: list[str] -- names of available tools
        - error: str | None -- error message if any check failed
    """
    result: dict[str, Any] = {
        "server_found": False,
        "server_path": None,
        "startup_ok": False,
        "tools_listed": False,
        "tool_count": 0,
        "tool_names": [],
        "error": None,
    }

    # Check talon-local is on PATH
    server_path = find_talon_server()
    if server_path is None:
        result["error"] = (
            "talon-local not found on PATH. Install with: pip install talon"
        )
        return result

    result["server_found"] = True
    result["server_path"] = server_path

    # Try spawning the server and sending MCP initialize + list_tools
    try:
        proc = subprocess.Popen(
            [server_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Send MCP initialize request (JSON-RPC)
        init_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "talon", "version": "0.1.0"},
            },
        })

        list_tools_request = json.dumps({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list",
            "params": {},
        })

        # Send both requests separated by newlines
        stdin_payload = init_request + "\n" + list_tools_request + "\n"

        try:
            stdout, stderr = proc.communicate(input=stdin_payload, timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
            result["error"] = f"Server did not respond within {timeout}s"
            return result

        result["startup_ok"] = proc.returncode is None or proc.returncode == 0

        # Parse responses from stdout (one JSON per line)
        if stdout:
            for line in stdout.strip().split("\n"):
                line = line.strip()
                if not line:
                    continue
                try:
                    response = json.loads(line)
                    resp_result = response.get("result", {})

                    # Check for list_tools response
                    if "tools" in resp_result:
                        tools = resp_result["tools"]
                        result["tools_listed"] = True
                        result["tool_count"] = len(tools)
                        result["tool_names"] = [t.get("name", "") for t in tools]
                except json.JSONDecodeError:
                    continue

        if not result["tools_listed"] and stderr:
            result["error"] = f"Server stderr: {stderr[:500]}"

    except FileNotFoundError:
        result["error"] = f"Could not execute: {server_path}"
    except Exception as e:
        result["error"] = f"Connection test failed: {e}"

    return result


# ---------------------------------------------------------------------------
# Project Detection
# ---------------------------------------------------------------------------


def detect_project_root(start_path: str | Path | None = None) -> Path | None:
    """Walk up from start_path looking for a project root marker.

    Looks for .git, pyproject.toml, package.json, Cargo.toml, go.mod, pom.xml.

    Args:
        start_path: Directory to start searching from (default: cwd).

    Returns:
        Path to project root, or None if no marker found.
    """
    if start_path is None:
        start_path = Path.cwd()
    else:
        start_path = Path(start_path).resolve()

    current = start_path
    while True:
        for marker in PROJECT_MARKERS:
            if (current / marker).exists():
                return current

        parent = current.parent
        if parent == current:
            # Reached filesystem root
            return None
        current = parent


def get_project_status(project_path: str | Path) -> dict[str, Any]:
    """Get the current Talon status for a project directory.

    Returns information about:
    - Whether .mcp.json exists and is valid
    - Whether talon-local is on PATH
    - Graph DB connection settings from config (local mode only)
    - Whether the project appears to be indexed

    Args:
        project_path: Path to the project root.

    Returns:
        Dict with status information.
    """
    project_path = Path(project_path).resolve()

    status: dict[str, Any] = {
        "project_path": str(project_path),
        "config_exists": False,
        "config_valid": False,
        "config_path": str(project_path / MCP_CONFIG_FILENAME),
        "server_on_path": find_talon_server() is not None,
        "server_path": find_talon_server(),
        "db_url": None,
        "db_name": None,
        "raw_config": {},
    }

    # Check .mcp.json
    config = read_mcp_config(project_path)
    if config is not None:
        status["config_exists"] = True
        status["raw_config"] = config
        talon_config = config.get("mcpServers", {}).get("talon", {})
        cmd = talon_config.get("command", "")
        if cmd in ("talon-local", "talon-server", "mcp-proxy", "talon-proxy-wrapper"):
            status["config_valid"] = True
            env = talon_config.get("env", {})
            status["db_url"] = env.get("TALON_DB_URL", env.get("TALON_ARANGO_URL"))
            status["db_name"] = env.get("TALON_DB_NAME", env.get("TALON_ARANGO_DATABASE"))

    return status
