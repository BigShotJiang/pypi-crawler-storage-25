# AIfred Toolkit

AI agent tools exposed via CLI and MCP — a microkernel plugin system for composable AI workflows.

## Installation

```bash
pip install aifred-tk
```

## Usage

```bash
# List available tools
aifred-tk --help

# Get help for a specific tool
aifred-tk TOOL_ID --help

# Run a tool
aifred-tk TOOL_ID --option value
```

## Documentation

Full documentation: [aifred-toolkit.readthedocs.io](https://aifred-toolkit.readthedocs.io/)
