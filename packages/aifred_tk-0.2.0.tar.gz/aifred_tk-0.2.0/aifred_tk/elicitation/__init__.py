"""Elicitation utility — ask the human user to pick from a list of choices.

The :func:`elicit_choice` function automatically selects the appropriate
backend depending on the execution context:

* **MCP server mode**: uses FastMCP's native ``ctx.elicit()`` protocol so the
  MCP client (e.g. Claude Code) presents an interactive dialog.
* **CLI / plain-Python mode**: uses either an interactive cursor-key selector
  (via *questionary*) or a printed numbered list, controlled by the
  ``aifred_tk.elicitation.mode`` Dynaconf setting.

Example::

    from aifred_tk.elicitation import Choice, elicit_choice

    result = elicit_choice(
        "Which deployment strategy?",
        [
            Choice("Blue-green", "Zero-downtime swap", "v1 → v2 in parallel"),
            Choice("Rolling", "Incremental pod replacement"),
            Choice("Canary", "Gradual traffic shift"),
        ],
        allow_free_input=True,
    )

    if result.is_free_input:
        print(f"Custom strategy: {result.free_text}")
    else:
        print(f"Selected: {result.selected_label}")
"""

from __future__ import annotations

import sys
from typing import Any

from dynaconf import Dynaconf

from aifred_tk.elicitation._models import Choice, ElicitationResult

__all__ = ["Choice", "ElicitationResult", "elicit_choice"]

_MODE_AUTO = "auto"
_MODE_INTERACTIVE = "interactive"
_MODE_NUMBERED = "numbered"


def _try_get_mcp_context() -> Any | None:
    """Return the active FastMCP context, or ``None`` outside an MCP tool call.

    FastMCP propagates ``ContextVar`` values into ``anyio.to_thread.run_sync``
    worker threads, so this also works from within sync ``Tool.execute()``.

    :return: Active FastMCP context or ``None``.
    :rtype: Any | None
    """
    try:
        from fastmcp.server.dependencies import get_context

        return get_context()
    except Exception:  # noqa: BLE001
        return None


def _resolve_mode(settings: Dynaconf | None) -> str:
    """Resolve the effective elicitor mode from *settings*.

    When mode is ``"auto"`` the choice is made based on whether
    :data:`sys.stdout` is a TTY.

    :param settings: Optional Dynaconf instance; falls back to package
        defaults when ``None``.
    :type settings: Dynaconf | None
    :return: ``"interactive"`` or ``"numbered"``.
    :rtype: str
    """
    if settings is None:
        raw_mode = _MODE_AUTO
    else:
        raw_mode = str(settings.get("AIFRED_TK__ELICITATION__MODE", _MODE_AUTO)).lower()

    if raw_mode == _MODE_AUTO:
        return _MODE_INTERACTIVE if sys.stdout.isatty() else _MODE_NUMBERED
    if raw_mode in (_MODE_INTERACTIVE, _MODE_NUMBERED):
        return raw_mode
    return _MODE_AUTO


def elicit_choice(
    question: str,
    choices: list[Choice],
    *,
    context: str | None = None,
    allow_free_input: bool = False,
    settings: Dynaconf | None = None,
) -> ElicitationResult:
    """Ask the human user to pick from *choices*.

    The backend is selected automatically:

    * If called from within an MCP tool handler, the MCP elicitation protocol
      is used (``ctx.elicit()`` via FastMCP).
    * Otherwise, the terminal elicitor determined by the
      ``aifred_tk.elicitation.mode`` setting is used:

      * ``"interactive"`` (default when stdout is a TTY): arrow-key selector
        rendered by *questionary*.
      * ``"numbered"``: numbered list printed to stdout, answer read from
        stdin.

    :param question: The question to present to the user.
    :type question: str
    :param choices: Ordered list of options.  Must not be empty.
    :type choices: list[Choice]
    :param context: Optional paragraph of context shown above the choices.
    :type context: str | None
    :param allow_free_input: When ``True``, an "Other (specify…)" option is
        appended; selecting it opens a free-text input.
    :type allow_free_input: bool
    :param settings: Dynaconf settings instance used to read
        ``aifred_tk.elicitation.mode``.  Uses auto-detection when ``None``.
    :type settings: Dynaconf | None
    :return: The user's selection.
    :rtype: ElicitationResult
    :raises ValueError: When *choices* is empty.
    :raises ElicitationCancelledError: When the MCP client declines or
        cancels the request (MCP mode only).
    """
    if not choices:
        raise ValueError("choices must not be empty")

    mcp_ctx = _try_get_mcp_context()
    if mcp_ctx is not None:
        from aifred_tk.elicitation._mcp import McpElicitor

        return McpElicitor(mcp_ctx).elicit(question, choices, context, allow_free_input)

    mode = _resolve_mode(settings)
    if mode == _MODE_INTERACTIVE:
        from aifred_tk.elicitation._terminal import InteractiveElicitor

        return InteractiveElicitor().elicit(question, choices, context, allow_free_input)

    from aifred_tk.elicitation._terminal import NumberedElicitor

    return NumberedElicitor().elicit(question, choices, context, allow_free_input)
