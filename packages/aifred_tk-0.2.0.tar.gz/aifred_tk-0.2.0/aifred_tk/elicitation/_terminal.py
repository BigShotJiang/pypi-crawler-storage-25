"""Terminal-based elicitors for CLI and plain-Python contexts."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from aifred_tk.elicitation._models import Choice, ElicitationResult


def _format_choice_label(choice: Choice) -> str:
    """Build a single-line display string for *choice*.

    :param choice: The choice to format.
    :type choice: Choice
    :return: Display string, e.g. ``"label — description (e.g. example)"``.
    :rtype: str
    """
    parts = [choice.label]
    if choice.description:
        parts.append(f"— {choice.description}")
    if choice.example:
        parts.append(f"(e.g. {choice.example})")
    return " ".join(parts)


_FREE_SENTINEL = "__free_input__"


class InteractiveElicitor:
    """Presents choices as an interactive cursor-key selector via *questionary*.

    Requires a TTY; raises :class:`RuntimeError` when stdout is not a terminal.
    """

    def elicit(
        self,
        question: str,
        choices: list[Choice],
        context: str | None,
        allow_free_input: bool,
    ) -> ElicitationResult:
        """Display an interactive selector and return the user's choice.

        :param question: The question to display above the selector.
        :type question: str
        :param choices: Ordered list of selectable options.
        :type choices: list[Choice]
        :param context: Optional context paragraph shown before the selector.
        :type context: str | None
        :param allow_free_input: When ``True`` an "Other (specify…)" option
            is appended and selecting it opens a follow-up text prompt.
        :type allow_free_input: bool
        :return: The user's selection.
        :rtype: ElicitationResult
        """
        import questionary

        from aifred_tk.elicitation._models import ElicitationResult

        if context:
            print(f"\n{context}\n")

        q_choices: list[questionary.Choice | questionary.Separator] = [
            questionary.Choice(title=_format_choice_label(c), value=i)
            for i, c in enumerate(choices)
        ]
        if allow_free_input:
            q_choices.append(questionary.Separator())
            q_choices.append(questionary.Choice(title="Other (specify…)", value=_FREE_SENTINEL))

        raw = questionary.select(question, choices=q_choices).ask()

        if raw == _FREE_SENTINEL:
            text = questionary.text("Enter your response:").ask() or ""
            return ElicitationResult(selected_index=-1, selected_label=None, free_text=text)

        idx: int = int(raw)
        return ElicitationResult(
            selected_index=idx,
            selected_label=choices[idx].label,
            free_text=None,
        )


class NumberedElicitor:
    """Presents choices as a numbered list and reads a number from stdin."""

    def elicit(
        self,
        question: str,
        choices: list[Choice],
        context: str | None,
        allow_free_input: bool,
    ) -> ElicitationResult:
        """Print a numbered menu and return the user's choice.

        Re-prompts until the user enters a valid number.

        :param question: The question to display.
        :type question: str
        :param choices: Ordered list of selectable options.
        :type choices: list[Choice]
        :param context: Optional context paragraph shown before the menu.
        :type context: str | None
        :param allow_free_input: When ``True``, option ``0`` allows free text.
        :type allow_free_input: bool
        :return: The user's selection.
        :rtype: ElicitationResult
        """
        from aifred_tk.elicitation._models import ElicitationResult

        print(f"\n{question}")
        if context:
            print(f"  {context}")
        print()

        for i, c in enumerate(choices, start=1):
            line = f"  {i}. {c.label}"
            if c.description:
                line += f"\n       {c.description}"
            if c.example:
                line += f"\n       e.g. {c.example}"
            print(line)

        if allow_free_input:
            print("  0. Other (specify…)")

        valid_range = set(range(1, len(choices) + 1))
        if allow_free_input:
            valid_range.add(0)

        prompt = f"Enter choice ({', '.join(str(v) for v in sorted(valid_range))}): "

        while True:
            raw = input(prompt).strip()
            try:
                num = int(raw)
            except ValueError:
                print("  Please enter a number from the list.")
                continue
            if num not in valid_range:
                print(f"  Invalid choice. Please enter one of: {sorted(valid_range)}")
                continue
            break

        if num == 0:
            text = input("  Your response: ").strip()
            return ElicitationResult(selected_index=-1, selected_label=None, free_text=text)

        idx = num - 1
        return ElicitationResult(
            selected_index=idx,
            selected_label=choices[idx].label,
            free_text=None,
        )
