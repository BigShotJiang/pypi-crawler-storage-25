"""Data models for the elicitation utility."""

from dataclasses import dataclass


@dataclass
class Choice:
    """A single selectable option presented to the user.

    :param label: Short display text shown in the selector.
    :type label: str
    :param description: Optional explanation of what this choice means.
    :type description: str | None
    :param example: Optional concrete example to clarify the choice.
    :type example: str | None
    """

    label: str
    description: str | None = None
    example: str | None = None


@dataclass
class ElicitationResult:
    """The user's response to an elicitation request.

    :param selected_index: Zero-based index of the chosen option, or ``-1``
        when the user entered free text instead.
    :type selected_index: int
    :param selected_label: The ``label`` of the chosen :class:`Choice`, or
        ``None`` when the user entered free text.
    :type selected_label: str | None
    :param free_text: The text entered by the user when no predefined choice
        was selected; ``None`` otherwise.
    :type free_text: str | None
    """

    selected_index: int
    selected_label: str | None
    free_text: str | None

    @property
    def is_free_input(self) -> bool:
        """Return ``True`` when the user supplied free text rather than picking a choice.

        :return: Whether this result represents free-text input.
        :rtype: bool
        """
        return self.selected_index < 0
