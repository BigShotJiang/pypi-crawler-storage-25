"""Logging layer — loguru-based sink configuration per runtime mode."""
