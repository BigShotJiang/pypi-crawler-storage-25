"""daimyo bugyo plugins exposing aifred-tk tool availability to rule templates."""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

from daimyo.domain.models import MergedScope
from daimyo.domain.protocols import ContextProviderPlugin, FilterProviderPlugin

from aifred_tk.config.settings import create_settings
from aifred_tk.core.interfaces import Tool
from aifred_tk.core.registry import PluginRegistry


@functools.lru_cache(maxsize=1)
def _load_enabled_tools() -> dict[str, Tool]:
    """Load and cache all enabled aifred-tk tools for the current working directory.

    :return: Mapping of tool_id to enabled :class:`~aifred_tk.core.interfaces.Tool` instances.
    :rtype: dict[str, Tool]
    """
    settings = create_settings()
    registry = PluginRegistry(settings)
    registry.load_plugins()
    return registry.get_all_tools()


class AifredContextPlugin(ContextProviderPlugin):
    """daimyo context provider that exposes enabled aifred-tk tools as template variables.

    Provides the ``aifred_tools`` context variable: a mapping of ``tool_id`` to
    a dict containing ``name`` and ``description`` for each enabled tool.

    Example usage in a daimyo rule template::

        {% if "commit" in aifred_tools %}
        Use the aifred-tk commit tool to generate conventional commit messages.
        {% endif %}
    """

    @property
    def name(self) -> str:
        """Unique dot-notation plugin name.

        :return: Plugin name ``aifred.context``.
        :rtype: str
        """
        return "aifred.context"

    @property
    def description(self) -> str:
        """Human-readable description of this plugin.

        :return: Description string.
        :rtype: str
        """
        return "Provides aifred-tk enabled tools as daimyo template context"

    def is_available(self) -> bool:
        """Return True; always available when aifred-tk[bugyo] is installed.

        :return: Always ``True``.
        :rtype: bool
        """
        return True

    def get_context(self, scope: MergedScope) -> dict[str, Any]:
        """Return enabled aifred-tk tools as the ``aifred_tools`` template variable.

        :param scope: The merged daimyo scope being rendered (unused).
        :type scope: MergedScope
        :return: Dict with key ``aifred_tools`` mapping tool_id to tool metadata.
        :rtype: dict[str, Any]
        """
        return {
            "aifred_tools": {
                tool_id: {"name": tool.name, "description": tool.description}
                for tool_id, tool in _load_enabled_tools().items()
            }
        }


class AifredFilterPlugin(FilterProviderPlugin):
    """daimyo filter provider that adds the ``aifred_tool_available`` Jinja2 test.

    Example usage in a daimyo rule template::

        {% if "commit" is aifred_tool_available %}
        Use the aifred-tk commit tool to generate conventional commit messages.
        {% endif %}
    """

    @property
    def name(self) -> str:
        """Unique dot-notation plugin name.

        :return: Plugin name ``aifred.filters``.
        :rtype: str
        """
        return "aifred.filters"

    @property
    def description(self) -> str:
        """Human-readable description of this plugin.

        :return: Description string.
        :rtype: str
        """
        return "Provides aifred_tool_available Jinja2 test for rule templates"

    def is_available(self) -> bool:
        """Return True; always available when aifred-tk[bugyo] is installed.

        :return: Always ``True``.
        :rtype: bool
        """
        return True

    def get_filters(self) -> dict[str, Callable[..., Any]]:
        """Return an empty filter dict; this plugin provides tests only.

        :return: Empty dict.
        :rtype: dict[str, Callable[..., Any]]
        """
        return {}

    def get_tests(self) -> dict[str, Callable[..., Any]]:
        """Return the ``aifred_tool_available`` Jinja2 test.

        The test returns ``True`` when the given tool_id is both installed and
        enabled in the current project's aifred-tk settings.

        :return: Mapping of test name to callable.
        :rtype: dict[str, Callable[..., Any]]
        """
        return {
            "aifred_tool_available": lambda tool_id: tool_id in _load_enabled_tools(),
        }
