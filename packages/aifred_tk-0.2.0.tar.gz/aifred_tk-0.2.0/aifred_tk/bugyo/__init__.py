"""daimyo bugyo plugin package for aifred-tk tool availability context."""
