"""MCP presentation layer — FastMCP server with dynamic tool registration."""
