"""Settings factory using dynaconf with a six-layer merge chain."""

from importlib.resources import files
from pathlib import Path

import platformdirs
from dynaconf import Dynaconf


def _conventional_config_paths() -> list[str]:
    """Return platform-appropriate conventional config search paths.

    Uses :mod:`platformdirs` so paths are correct on Linux, macOS, and Windows.

    :return: List of absolute path strings in ascending priority order.
    :rtype: list[str]
    """
    return [
        str(Path(platformdirs.site_config_dir("aifred-tk")) / "settings.yml"),
        str(Path(platformdirs.user_config_dir("aifred-tk")) / "settings.yml"),
        str(Path.cwd() / ".aifred-tk" / "settings.yml"),
    ]


def create_settings(extra_config_file: Path | None = None) -> Dynaconf:
    """Build a :class:`~dynaconf.Dynaconf` instance with the full merge chain.

    Layers are applied in ascending priority order:

    1. Bundled package defaults (``aifred_tk/default_settings.yml``).
    2. ``<site_config_dir>/aifred-tk/settings.yml``
       (e.g. ``/etc/xdg/aifred-tk/settings.yml`` on Linux).
    3. ``<user_config_dir>/aifred-tk/settings.yml``
       (e.g. ``~/.config/aifred-tk/settings.yml`` on Linux).
    4. ``.aifred-tk/settings.yml`` (current working directory).
    5. *extra_config_file* — path supplied via ``--config`` CLI option.
    6. ``AIFRED_TK_*`` environment variables.

    Missing files in layers 2–5 are silently skipped by dynaconf.
    Platform-specific paths for layers 2–3 are resolved via :mod:`platformdirs`.

    :param extra_config_file: Optional path to an additional settings file
        passed at runtime (e.g., via ``--config``).
    :type extra_config_file: Path | None
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    pkg_defaults = str(files("aifred_tk").joinpath("default_settings.yml"))

    settings_files: list[str] = [pkg_defaults, *_conventional_config_paths()]
    if extra_config_file is not None:
        settings_files.append(str(extra_config_file))

    return Dynaconf(
        envvar_prefix="AIFRED_TK",
        settings_files=settings_files,
        merge_enabled=True,
        load_dotenv=False,
    )
