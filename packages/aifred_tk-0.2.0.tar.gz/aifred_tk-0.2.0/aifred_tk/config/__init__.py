"""Configuration layer — dynaconf-based settings with multi-source merging."""
