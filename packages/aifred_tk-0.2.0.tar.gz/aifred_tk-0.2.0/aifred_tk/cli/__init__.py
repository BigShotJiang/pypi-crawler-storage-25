"""CLI presentation layer — Click-based dynamic command registration."""
