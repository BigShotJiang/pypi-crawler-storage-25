"""Prompt injection detection plugin providing the ``detect_prompt_injection`` tool.

The tool accepts arbitrary text content and submits it to an LLM agent that analyzes
the text for prompt injection attempts, including direct injections, encoded obfuscations,
creative reformulations, and non-English injections. The content is structurally isolated
from the agent's instruction layer via XML markers to prevent the analyzed content from
acting as instructions itself.
"""

from __future__ import annotations

from typing import Any, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, TypeAdapter
from pydantic_ai import Agent

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.llm import LlmConfig, PluginLlmSetting, build_pydantic_ai_model, resolve_llm
from aifred_tk.core.models import ConfigurationError

from ._agent import InjectionDetectionResult, create_prompt_injection_agent

_TOOL_ID = "detect_prompt_injection"
_MAX_CONTENT_CHARS = 50_000


class PromptInjectionArgs(ToolArgs):
    """Arguments accepted by :class:`PromptInjectionTool`.

    :param content: The text content to analyze for prompt injection attempts.
        Maximum 50,000 characters.
    """

    content: str = Field(
        ...,
        max_length=_MAX_CONTENT_CHARS,
        description=(
            f"Text content to analyze for prompt injection attempts. "
            f"Maximum {_MAX_CONTENT_CHARS:,} characters."
        ),
    )


class PromptInjectionTool(Tool):
    """Analyzes text content for prompt injection attempts using an LLM agent.

    The content is wrapped in ``<content_to_analyze>`` XML isolation markers before
    being forwarded to the agent, preventing the analyzed text from acting as
    instructions. Returns a structured verdict and a list of evidence items.
    """

    def __init__(self, agent: Agent[None, InjectionDetectionResult]) -> None:
        """Initialise with a pre-built agent.

        :param agent: PydanticAI agent configured for injection detection.
        :type agent: Agent[None, InjectionDetectionResult]
        """
        self._agent = agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"detect_prompt_injection"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Prompt Injection Detector"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Analyzes arbitrary text content to detect prompt injection attempts. "
            "Covers direct injections ('ignore previous instructions'), encoded injections "
            "(base64, URL encoding, Unicode tricks), creative or poetic reformulations, "
            "and non-English injections via normalization and translation. "
            "Returns a structured verdict: 'no_evidence', 'suspicious', or 'certain', "
            "together with a list of evidence items."
        )

    @property
    def args_schema(self) -> type[PromptInjectionArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`PromptInjectionArgs` class.
        :rtype: type[PromptInjectionArgs]
        """
        return PromptInjectionArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Analyze the provided content for prompt injection attempts.

        Wraps the content in XML isolation markers before forwarding to the agent,
        preventing the analyzed content from influencing agent behavior. Returns a
        structured verdict dict on success or an error dict on failure.

        :param args: Validated :class:`PromptInjectionArgs` instance.
        :type args: ToolArgs
        :return: On success: dict with ``verdict`` (str) and ``evidences`` (list of dicts,
            each with ``description`` and ``confidence`` keys).
            On error: dict with ``status`` = ``"error"`` and ``message`` keys.
        :rtype: dict[str, Any]
        """
        injection_args = cast(PromptInjectionArgs, args)

        user_message = f"<content_to_analyze>\n{injection_args.content}\n</content_to_analyze>"

        logger.debug("Invoking prompt injection detection agent")
        try:
            run_result = self._agent.run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error during prompt injection detection: {}", exc)
            return {"status": "error", "message": f"Agent error: {exc}"}

        result: InjectionDetectionResult = run_result.output
        logger.info("Prompt injection detection complete, verdict: {!r}", result.verdict)

        return {
            "verdict": result.verdict,
            "evidences": [
                {"description": e.description, "confidence": e.confidence} for e in result.evidences
            ],
        }


class PromptInjectionPlugin(Plugin):
    """Plugin that provides the :class:`PromptInjectionTool`."""

    def __init__(self, agent: Agent[None, InjectionDetectionResult]) -> None:
        """Initialise with a pre-built agent.

        :param agent: PydanticAI agent configured for injection detection.
        :type agent: Agent[None, InjectionDetectionResult]
        """
        self._agent = agent

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"prompt_injection"``
        :rtype: str
        """
        return "prompt_injection"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Prompt Injection Detector"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`PromptInjectionTool`.
        :rtype: list[Tool]
        """
        return [PromptInjectionTool(self._agent)]


def create_plugin(settings: Dynaconf) -> PromptInjectionPlugin:
    """Entry point factory for the prompt_injection plugin.

    Reads the ``llms`` registry and the ``tools.detect_prompt_injection.llm`` setting
    from *settings*, resolves the LLM configuration, builds a pydantic-ai Model, and
    constructs the agent once so it is shared across all calls to
    :meth:`PromptInjectionTool.execute`.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`PromptInjectionPlugin` instance.
    :rtype: PromptInjectionPlugin
    :raises ConfigurationError: When the LLM setting is missing or references an unknown name.
    """
    llms_data: dict[str, Any] = dict(settings.get("LLMS", {}) or {})
    llms_registry: dict[str, LlmConfig] = (
        TypeAdapter(dict[str, LlmConfig]).validate_python(llms_data) if llms_data else {}
    )

    llm_raw = settings.get(f"TOOLS__{_TOOL_ID.upper()}__LLM")
    if not llm_raw:
        raise ConfigurationError(
            f"Missing tools.{_TOOL_ID}.llm configuration; "
            "define an LLM reference or inline definition."
        )

    llm_setting: PluginLlmSetting = TypeAdapter(PluginLlmSetting).validate_python(dict(llm_raw))
    llm_config = resolve_llm(llm_setting, llms_registry)
    pydantic_model = build_pydantic_ai_model(llm_config)

    logger.debug(
        "prompt_injection plugin using {} model {!r}",
        llm_config.provider,
        llm_config.model,
    )
    agent = create_prompt_injection_agent(pydantic_model)
    return PromptInjectionPlugin(agent)
