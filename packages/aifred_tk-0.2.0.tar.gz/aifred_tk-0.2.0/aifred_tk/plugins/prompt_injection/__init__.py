"""Prompt injection detection plugin for aifred-tk."""
