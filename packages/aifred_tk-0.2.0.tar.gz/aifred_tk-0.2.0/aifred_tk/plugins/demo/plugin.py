"""Demo plugin providing the ``demo_echo`` tool."""

from typing import Any, cast

from dynaconf import Dynaconf
from pydantic import Field

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs


class DemoEchoArgs(ToolArgs):
    """Arguments accepted by the :class:`DemoEchoTool`.

    :param message: The message to echo.
    :param repeat: How many times to repeat the message.
    """

    message: str = Field(..., description="Message to echo back")
    repeat: int = Field(1, ge=1, description="Number of times to repeat the message")


class DemoEchoTool(Tool):
    """Echoes a message a configurable number of times.

    This tool exists to demonstrate the plugin authoring pattern and to
    validate end-to-end framework behaviour in tests and smoke runs.
    """

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"demo_echo"``
        :rtype: str
        """
        return "demo_echo"

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Demo Echo"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return "Echoes a message back, optionally repeated multiple times."

    @property
    def args_schema(self) -> type[DemoEchoArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`DemoEchoArgs` class.
        :rtype: type[DemoEchoArgs]
        """
        return DemoEchoArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Echo the message and return its length.

        :param args: Validated :class:`DemoEchoArgs` instance.
        :type args: ToolArgs
        :return: Dictionary with ``echo`` (the repeated message) and
            ``length`` (character count of the result).
        :rtype: dict[str, Any]
        """
        echo_args = cast(DemoEchoArgs, args)
        result = echo_args.message * echo_args.repeat
        return {"echo": result, "length": len(result)}


class DemoPlugin(Plugin):
    """Demo plugin that ships a single echo tool.

    Serves as both a functional example and the integration test target
    for the plugin framework.
    """

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"demo"``
        :rtype: str
        """
        return "demo"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Demo Plugin"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`DemoEchoTool`.
        :rtype: list[Tool]
        """
        return [DemoEchoTool()]


def create_plugin(_settings: Dynaconf) -> DemoPlugin:
    """Entry point factory for the demo plugin.

    This function is referenced by the ``aifred_tk.plugins`` entry point
    group in ``pyproject.toml``.

    :param _settings: Active dynaconf settings instance (unused by this plugin
        but required by the factory protocol).
    :type _settings: Dynaconf
    :return: Initialised :class:`DemoPlugin` instance.
    :rtype: DemoPlugin
    """
    return DemoPlugin()
