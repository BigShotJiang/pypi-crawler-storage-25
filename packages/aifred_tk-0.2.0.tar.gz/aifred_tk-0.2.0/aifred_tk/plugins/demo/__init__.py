"""Demo plugin — illustrates the plugin authoring pattern."""
