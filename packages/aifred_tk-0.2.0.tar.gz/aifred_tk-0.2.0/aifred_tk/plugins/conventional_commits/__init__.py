"""Conventional commits plugin — AI-assisted conventional commit message generation."""
