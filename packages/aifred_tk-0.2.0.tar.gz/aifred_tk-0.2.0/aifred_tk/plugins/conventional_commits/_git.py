"""Git helpers for the conventional_commits plugin (backed by GitPython)."""

from __future__ import annotations

from pathlib import Path

import git


def get_staged_diff(repo_path: Path) -> str:
    """Return the output of ``git diff --cached`` for *repo_path*.

    :param repo_path: Path to the git repository root.
    :type repo_path: Path
    :return: Unified diff of all staged changes, or an empty string when nothing is staged.
    :rtype: str
    :raises git.InvalidGitRepositoryError: When *repo_path* is not a git repository.
    :raises git.GitCommandError: When the underlying git command exits non-zero.
    """
    repo = git.Repo(repo_path)
    return str(repo.git.diff("--cached"))


def commit(message: str, repo_path: Path) -> tuple[int, str, str]:
    """Run ``git commit -m <message>`` and return ``(returncode, stdout, stderr)``.

    Does not raise on non-zero exit so the caller can surface the error as structured
    data rather than an exception.

    :param message: The commit message to pass to ``-m``.
    :type message: str
    :param repo_path: Path to the git repository root.
    :type repo_path: Path
    :return: Tuple of (returncode, stdout, stderr).
    :rtype: tuple[int, str, str]
    """
    try:
        repo = git.Repo(repo_path)
        output = repo.git.commit("-m", message)
        return 0, output, ""
    except git.GitCommandError as exc:
        returncode = exc.status if isinstance(exc.status, int) else 1
        return returncode, "", exc.stderr or ""
