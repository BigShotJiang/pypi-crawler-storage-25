"""File analysis plugin for aifred-tk."""
