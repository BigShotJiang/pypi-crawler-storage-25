"""File analysis plugin providing the ``analyze_file`` tool.

The tool reads a file from disk, submits its contents together with a user-supplied
analysis prompt to an LLM agent, and returns the analysis result. Both the analysis
prompt and the file contents are structurally isolated from the agent's instruction
layer to mitigate prompt injection attacks.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, TypeAdapter
from pydantic_ai import Agent

from aifred_tk.core.ignore import AiIgnoreChecker
from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs
from aifred_tk.core.llm import LlmConfig, PluginLlmSetting, build_pydantic_ai_model, resolve_llm
from aifred_tk.core.models import ConfigurationError

from ._agent import create_file_analysis_agent

_TOOL_ID = "analyze_file"
_MAX_FILE_BYTES = 1_048_576


class FileAnalysisArgs(ToolArgs):
    """Arguments accepted by :class:`FileAnalysisTool`.

    :param file_path: Absolute or relative path to the file to analyse.
    :param prompt: Short natural-language description of the desired analysis (max 500 chars).
    :param output_file: Optional path to write the analysis result. When ``None`` the result
        is returned directly to the caller.
    """

    file_path: str = Field(description="Path to the file to analyse.")
    prompt: str = Field(
        max_length=500,
        description=(
            "Short description of the desired analysis "
            "(e.g., 'briefly describe the functions', 'list all organisation names'). "
            "Maximum 10000 characters."
        ),
    )
    output_file: str | None = Field(
        None,
        description="Optional path to write the analysis result. Defaults to returning inline.",
    )


class FileAnalysisTool(Tool):
    """Reads a file and uses an LLM agent to produce an analysis based on a user prompt.

    Both the analysis prompt and the file contents are wrapped in XML-style isolation
    markers before being forwarded to the agent, preventing the file contents from
    acting as instructions (prompt injection).
    """

    def __init__(self, agent: Agent[None, str]) -> None:
        """Initialise with a pre-built agent.

        :param agent: PydanticAI agent configured for file analysis.
        :type agent: Agent[None, str]
        """
        self._agent = agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"analyze_file"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Reads a file and uses an AI agent to analyse its contents based on a short prompt. "
            "Examples: 'briefly describe the code functions', 'list all organisation names'. "
            "The analysis result is returned to the caller or written to an optional output file."
        )

    @property
    def args_schema(self) -> type[FileAnalysisArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`FileAnalysisArgs` class.
        :rtype: type[FileAnalysisArgs]
        """
        return FileAnalysisArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Read the target file and return an LLM-generated analysis.

        Validates the file path and size, reads the contents, then submits both the
        analysis prompt and the file contents to the agent using XML isolation markers
        to prevent prompt injection. If *output_file* is set the result is persisted
        to disk; otherwise it is returned inline.

        :param args: Validated :class:`FileAnalysisArgs` instance.
        :type args: ToolArgs
        :return: Result dict with a ``status`` key: ``"ok"``, ``"written"``, or ``"error"``.
        :rtype: dict[str, Any]
        """
        analysis_args = cast(FileAnalysisArgs, args)
        file_path = Path(analysis_args.file_path)

        if not file_path.exists():
            logger.error("File not found: {}", file_path)
            return {"status": "error", "message": f"File not found: {file_path}"}

        if not file_path.is_file():
            logger.error("Path is not a regular file: {}", file_path)
            return {"status": "error", "message": f"Path is not a regular file: {file_path}"}

        if AiIgnoreChecker.for_path(file_path).is_ignored(file_path):
            logger.warning("File is ignored by .aiignore: {}", file_path)
            return {"status": "error", "message": f"File is ignored by .aiignore: {file_path}"}

        file_size = file_path.stat().st_size
        if file_size > _MAX_FILE_BYTES:
            logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, file_path)
            return {
                "status": "error",
                "message": (
                    f"File exceeds the {_MAX_FILE_BYTES // 1_048_576} MB size limit "
                    f"({file_size} bytes)."
                ),
            }

        try:
            file_content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return {"status": "error", "message": f"Failed to read file: {exc}"}

        user_message = (
            f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
            f"<file_content>\n{file_content}\n</file_content>"
        )

        logger.debug("Invoking file analysis agent for: {}", file_path)
        try:
            run_result = self._agent.run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error while analysing {}: {}", file_path, exc)
            return {"status": "error", "message": f"Agent error: {exc}"}

        analysis: str = run_result.output.strip()
        logger.info("File analysis complete for: {}", file_path)

        if analysis_args.output_file is not None:
            output_path = Path(analysis_args.output_file)
            try:
                output_path.write_text(analysis, encoding="utf-8")
            except OSError as exc:
                logger.error("Failed to write output file {}: {}", output_path, exc)
                return {"status": "error", "message": f"Failed to write output file: {exc}"}
            return {
                "status": "written",
                "output_file": str(output_path),
                "analysis": analysis,
            }

        return {"status": "ok", "analysis": analysis}


class FileAnalysisPlugin(Plugin):
    """Plugin that provides the :class:`FileAnalysisTool`."""

    def __init__(self, agent: Agent[None, str]) -> None:
        """Initialise with a pre-built agent.

        :param agent: PydanticAI agent configured for file analysis.
        :type agent: Agent[None, str]
        """
        self._agent = agent

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"file_analysis"``
        :rtype: str
        """
        return "file_analysis"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`FileAnalysisTool`.
        :rtype: list[Tool]
        """
        return [FileAnalysisTool(self._agent)]


def create_plugin(settings: Dynaconf) -> FileAnalysisPlugin:
    """Entry point factory for the file_analysis plugin.

    Reads the ``llms`` registry and the ``tools.analyze_file.llm`` setting from
    *settings*, resolves the LLM configuration, builds a pydantic-ai Model, and
    constructs the agent once so it is shared across all calls to
    :meth:`FileAnalysisTool.execute`.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`FileAnalysisPlugin` instance.
    :rtype: FileAnalysisPlugin
    :raises ConfigurationError: When the LLM setting is missing or references an unknown name.
    """
    llms_data: dict[str, Any] = dict(settings.get("LLMS", {}) or {})
    llms_registry: dict[str, LlmConfig] = (
        TypeAdapter(dict[str, LlmConfig]).validate_python(llms_data) if llms_data else {}
    )

    llm_raw = settings.get(f"TOOLS__{_TOOL_ID.upper()}__LLM")
    if not llm_raw:
        raise ConfigurationError(
            f"Missing tools.{_TOOL_ID}.llm configuration; "
            "define an LLM reference or inline definition."
        )

    llm_setting: PluginLlmSetting = TypeAdapter(PluginLlmSetting).validate_python(dict(llm_raw))
    llm_config = resolve_llm(llm_setting, llms_registry)
    pydantic_model = build_pydantic_ai_model(llm_config)

    logger.debug(
        "file_analysis plugin using {} model {!r}",
        llm_config.provider,
        llm_config.model,
    )
    agent = create_file_analysis_agent(pydantic_model)
    return FileAnalysisPlugin(agent)
