"""Core LLM configuration models and pydantic-ai model factory.

This package provides:

- Pydantic models for declaring named LLMs in ``aifred_tk.llms`` settings and for
  referencing them (or defining them inline) inside plugin tool configuration.
- :func:`resolve_llm` — resolves a :data:`PluginLlmSetting` (ref or inline) to a concrete
  :data:`LlmConfig`.
- :func:`build_pydantic_ai_model` — converts a :data:`LlmConfig` to a pydantic-ai
  :class:`~pydantic_ai.models.Model` ready for use in an :class:`~pydantic_ai.Agent`.
"""

from ._config import (
    AnthropicLlmConfig,
    LlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
)
from ._factory import build_pydantic_ai_model, resolve_llm

__all__ = [
    "AnthropicLlmConfig",
    "LlmConfig",
    "LlmInlineSetting",
    "LlmRefSetting",
    "OllamaLlmConfig",
    "OpenAICompatLlmConfig",
    "OpenAILlmConfig",
    "PluginLlmSetting",
    "build_pydantic_ai_model",
    "resolve_llm",
]
