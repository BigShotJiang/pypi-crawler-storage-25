"""Utilities for honouring ``.aiignore`` files when accessing files from plugins.

Patterns follow the same ``gitwildmatch`` syntax used by ``.gitignore``.  A
module-level cache keyed by ``(path, mtime)`` ensures that parsed specs are
reused across calls while still picking up any on-disk changes on the very
next invocation.
"""

from __future__ import annotations

from pathlib import Path

import pathspec

_AIIGNORE = ".aiignore"

_cache: dict[Path, tuple[float, pathspec.PathSpec]] = {}


def _load_spec(aiignore_path: Path) -> pathspec.PathSpec:
    """Return a cached or freshly parsed :class:`pathspec.PathSpec` for *aiignore_path*.

    :param aiignore_path: Absolute path to an existing ``.aiignore`` file.
    :type aiignore_path: Path
    :return: Parsed ``PathSpec`` instance.
    :rtype: pathspec.PathSpec
    """
    mtime = aiignore_path.stat().st_mtime
    cached = _cache.get(aiignore_path)
    if cached is not None and cached[0] == mtime:
        return cached[1]
    lines = aiignore_path.read_text(encoding="utf-8").splitlines()
    spec = pathspec.PathSpec.from_lines("gitignore", lines)
    _cache[aiignore_path] = (mtime, spec)
    return spec


class AiIgnoreChecker:
    """Checks whether a filesystem path should be ignored according to ``.aiignore`` files.

    Build an instance via :meth:`for_path` and then call :meth:`is_ignored`.
    Parsed specs are shared through a module-level cache invalidated on mtime
    change, so edits to ``.aiignore`` take effect on the next call without
    requiring an MCP server restart.
    """

    def __init__(self, specs: list[tuple[Path, pathspec.PathSpec]]) -> None:
        """Initialise with a pre-built list of ``(base_dir, spec)`` pairs.

        :param specs: Ordered list of ``(base_directory, PathSpec)`` pairs collected
            from ``.aiignore`` files found along an ancestor chain.
        :type specs: list[tuple[Path, pathspec.PathSpec]]
        """
        self._specs = specs

    @classmethod
    def for_path(cls, path: Path) -> AiIgnoreChecker:
        """Build a checker by scanning ``.aiignore`` files from *path* up to the root.

        Walks from ``path.parent`` (or ``path`` itself if it is a directory) up to the
        filesystem root, loading every ``.aiignore`` it finds.  Non-existent paths are
        handled gracefully — the walk still traverses existing ancestor directories.

        :param path: Path of the file (or directory) to check.  Does not need to exist.
        :type path: Path
        :return: An :class:`AiIgnoreChecker` ready to answer :meth:`is_ignored` queries.
        :rtype: AiIgnoreChecker
        """
        specs: list[tuple[Path, pathspec.PathSpec]] = []
        current = path if path.is_dir() else path.parent
        while True:
            aiignore = current / _AIIGNORE
            if aiignore.is_file():
                specs.append((current, _load_spec(aiignore)))
            parent = current.parent
            if parent == current:
                break
            current = parent
        return cls(specs)

    def is_ignored(self, path: Path) -> bool:
        """Return ``True`` if *path* matches any loaded ``.aiignore`` pattern.

        The check is performed relative to each ``.aiignore`` file's base directory.
        Symlinks are resolved before comparison.

        :param path: Path to test.
        :type path: Path
        :return: ``True`` if the path is ignored, ``False`` otherwise.
        :rtype: bool
        """
        abs_path = path.resolve()
        for base, spec in self._specs:
            try:
                rel = abs_path.relative_to(base)
            except ValueError:
                continue
            if spec.match_file(str(rel)):
                return True
        return False
