"""Shared domain models and custom exceptions for the aifred-tk core."""


class AifredError(Exception):
    """Base exception for all aifred-tk errors."""


class ToolNotFoundError(AifredError, KeyError):
    """Raised when a requested tool ID is not registered or not enabled.

    :param tool_id: The tool identifier that could not be found.
    :type tool_id: str
    """

    def __init__(self, tool_id: str) -> None:
        """Initialise the error with the missing tool identifier.

        :param tool_id: The tool identifier that could not be found.
        :type tool_id: str
        """
        self.tool_id = tool_id
        super().__init__(f"Tool not found or not enabled: {tool_id!r}")


class PluginNotFoundError(AifredError, KeyError):
    """Raised when a requested plugin ID is not registered.

    :param plugin_id: The plugin identifier that could not be found.
    :type plugin_id: str
    """

    def __init__(self, plugin_id: str) -> None:
        """Initialise the error with the missing plugin identifier.

        :param plugin_id: The plugin identifier that could not be found.
        :type plugin_id: str
        """
        self.plugin_id = plugin_id
        super().__init__(f"Plugin not found: {plugin_id!r}")


class ToolExecutionError(AifredError, RuntimeError):
    """Raised when a tool's ``execute`` method raises an unexpected error.

    :param tool_id: The tool identifier that failed.
    :type tool_id: str
    :param cause: The original exception.
    :type cause: Exception
    """

    def __init__(self, tool_id: str, cause: Exception) -> None:
        """Initialise the error with context about which tool failed.

        :param tool_id: The tool identifier that failed.
        :type tool_id: str
        :param cause: The original exception.
        :type cause: Exception
        """
        self.tool_id = tool_id
        self.cause = cause
        super().__init__(f"Tool {tool_id!r} raised an error: {cause}")


class ElicitationCancelledError(AifredError):
    """Raised when an MCP elicitation request is declined or cancelled by the client.

    This exception is only raised in MCP server mode.  Terminal elicitors
    always wait for a valid response and never raise it.
    """


class ConfigurationError(AifredError, ValueError):
    """Raised when a configuration value is invalid or a required entry is missing."""


class PluginLoadError(AifredError, ImportError):
    """Raised when a plugin entry point cannot be loaded.

    :param entry_point_name: The entry point name that failed.
    :type entry_point_name: str
    :param cause: The original exception.
    :type cause: Exception
    """

    def __init__(self, entry_point_name: str, cause: Exception) -> None:
        """Initialise the error with context about which entry point failed.

        :param entry_point_name: The entry point name that failed.
        :type entry_point_name: str
        :param cause: The original exception.
        :type cause: Exception
        """
        self.entry_point_name = entry_point_name
        self.cause = cause
        super().__init__(f"Failed to load plugin {entry_point_name!r}: {cause}")
