"""Abstract base classes defining the Plugin and Tool contracts."""

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel


class ToolArgs(BaseModel):
    """Base class for all tool argument schemas.

    All tool-specific argument models must inherit from this class.
    """


class Tool(ABC):
    """Abstract base for a single executable tool.

    Each tool has a unique identifier, human-readable metadata, a Pydantic
    schema describing its accepted arguments, and an ``execute`` method that
    performs the actual work.
    """

    @property
    @abstractmethod
    def tool_id(self) -> str:
        """Unique snake_case identifier used as the CLI subcommand name.

        :return: Tool identifier string, e.g. ``demo_echo``.
        :rtype: str
        """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable display name for the tool.

        :return: Display name string.
        :rtype: str
        """

    @property
    @abstractmethod
    def description(self) -> str:
        """One-paragraph description used in CLI help text and MCP metadata.

        :return: Description string.
        :rtype: str
        """

    @property
    @abstractmethod
    def args_schema(self) -> type[ToolArgs]:
        """Pydantic model class defining the accepted arguments.

        Returns the *class* (not an instance) so callers can introspect
        ``model_fields`` without instantiation.

        :return: A :class:`ToolArgs` subclass.
        :rtype: type[ToolArgs]
        """

    @abstractmethod
    def execute(self, args: ToolArgs) -> dict[str, Any]:
        """Execute the tool with validated arguments.

        :param args: A validated instance of :attr:`args_schema`.
        :type args: ToolArgs
        :return: Result dictionary serialisable to JSON.
        :rtype: dict[str, Any]
        """


class Plugin(ABC):
    """Abstract base for a plugin that provides one or more tools.

    Plugins are discovered via the ``aifred_tk.plugins`` entry point group.
    Each entry point must point to a factory function with the signature
    ``create_plugin(settings: Dynaconf) -> Plugin``.
    """

    @property
    @abstractmethod
    def plugin_id(self) -> str:
        """Short snake_case identifier used as the config namespace.

        Tool settings are stored under ``tools.<tool_id>`` in the settings
        file; the plugin ID itself is used for plugin-level bookkeeping.

        :return: Plugin identifier string, e.g. ``demo``.
        :rtype: str
        """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """

    @abstractmethod
    def get_tools(self) -> list[Tool]:
        """Return all :class:`Tool` instances provided by this plugin.

        :return: List of tool instances.
        :rtype: list[Tool]
        """
