"""Core application layer — interfaces, models, and the plugin registry."""

from aifred_tk.core.ignore import AiIgnoreChecker

__all__ = ["AiIgnoreChecker"]
