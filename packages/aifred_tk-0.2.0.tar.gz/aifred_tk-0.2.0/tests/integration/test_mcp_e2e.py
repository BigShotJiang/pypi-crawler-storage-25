"""End-to-end MCP integration tests using fastmcp's in-process client."""

import pytest
from fastmcp import Client

from aifred_tk.mcp.server import build_mcp_server


@pytest.fixture()
def mcp_server(mock_entry_points: object, test_settings: object) -> object:
    """Return a configured FastMCP server with the demo plugin loaded.

    :param mock_entry_points: Entry point mock fixture (applied for side-effects).
    :type mock_entry_points: object
    :param test_settings: Dynaconf settings fixture.
    :type test_settings: object
    :return: Configured FastMCP server.
    :rtype: object
    """
    from dynaconf import Dynaconf

    settings: Dynaconf = test_settings  # type: ignore[assignment]
    return build_mcp_server(settings=settings)


class TestMcpEchoTool:
    """MCP end-to-end tests for the demo_echo tool."""

    async def test_tool_list_contains_demo_echo(self, mcp_server: object) -> None:
        """tools/list must include demo_echo."""
        async with Client(mcp_server) as client:  # type: ignore[arg-type]
            tools = await client.list_tools()
            tool_names = [t.name for t in tools]
            assert "demo_echo" in tool_names

    async def test_call_demo_echo_returns_correct_result(self, mcp_server: object) -> None:
        """Calling demo_echo via MCP must return echo and length."""
        async with Client(mcp_server) as client:  # type: ignore[arg-type]
            result = await client.call_tool("demo_echo", {"message": "hello", "repeat": 2})
            assert result is not None

    async def test_call_demo_echo_default_repeat(self, mcp_server: object) -> None:
        """Calling demo_echo without repeat must default to 1."""
        async with Client(mcp_server) as client:  # type: ignore[arg-type]
            result = await client.call_tool("demo_echo", {"message": "hi"})
            assert result is not None
