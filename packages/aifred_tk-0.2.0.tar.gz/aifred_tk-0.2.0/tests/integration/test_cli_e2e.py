"""End-to-end CLI integration tests using Typer's CliRunner."""

import json

import pytest
from typer.testing import CliRunner

from aifred_tk.cli.app import app


@pytest.fixture()
def runner(mock_entry_points: object) -> CliRunner:
    """Return a Typer CliRunner with mocked entry points loaded.

    :param mock_entry_points: Entry point mock fixture (applied for side-effects).
    :type mock_entry_points: object
    :return: Configured CliRunner.
    :rtype: CliRunner
    """
    return CliRunner()


class TestCliEchoTool:
    """End-to-end CLI tests for the demo_echo tool."""

    def test_echo_success(self, runner: CliRunner) -> None:
        """Invoking demo_echo with valid args must print JSON and exit 0."""
        result = runner.invoke(app, ["demo_echo", "--message", "hello"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["echo"] == "hello"
        assert data["length"] == 5

    def test_echo_with_repeat(self, runner: CliRunner) -> None:
        """The --repeat option must multiply the echo output."""
        result = runner.invoke(app, ["demo_echo", "--message", "hi", "--repeat", "3"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["echo"] == "hihihi"
        assert data["length"] == 6

    def test_echo_missing_required_arg_exits_nonzero(self, runner: CliRunner) -> None:
        """Omitting the required --message option must produce a non-zero exit."""
        result = runner.invoke(app, ["demo_echo"])
        assert result.exit_code != 0

    def test_echo_invalid_repeat_exits_nonzero(self, runner: CliRunner) -> None:
        """Passing --repeat 0 must fail validation and exit non-zero."""
        result = runner.invoke(app, ["demo_echo", "--message", "x", "--repeat", "0"])
        assert result.exit_code != 0


class TestCliHelp:
    """Help text and listing behaviour."""

    def test_top_level_help_exits_zero(self, runner: CliRunner) -> None:
        """--help at the top level must exit 0."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_tool_help_exits_zero(self, runner: CliRunner) -> None:
        """--help on a tool subcommand must exit 0."""
        result = runner.invoke(app, ["demo_echo", "--help"])
        assert result.exit_code == 0
        assert "message" in result.output.lower()

    def test_unknown_tool_exits_nonzero(self, runner: CliRunner) -> None:
        """Invoking an unknown tool ID must exit non-zero."""
        result = runner.invoke(app, ["nonexistent_tool_xyz"])
        assert result.exit_code != 0
