"""Unit tests for the conventional_commits git helpers (GitPython-backed)."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import git
import pytest

from aifred_tk.plugins.conventional_commits._git import commit, get_staged_diff


class TestGetStagedDiff:
    """get_staged_diff GitPython behaviour."""

    def test_returns_diff_output(self, tmp_path: Path) -> None:
        """get_staged_diff returns the string returned by repo.git.diff."""
        mock_repo = MagicMock()
        mock_repo.git.diff.return_value = "diff --git a/foo.py ...\n"
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ):
            result = get_staged_diff(tmp_path)
        assert result == "diff --git a/foo.py ...\n"

    def test_returns_empty_string_when_nothing_staged(self, tmp_path: Path) -> None:
        """get_staged_diff returns an empty string when git diff --cached is empty."""
        mock_repo = MagicMock()
        mock_repo.git.diff.return_value = ""
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ):
            result = get_staged_diff(tmp_path)
        assert result == ""

    def test_raises_invalid_git_repository_error(self, tmp_path: Path) -> None:
        """get_staged_diff propagates InvalidGitRepositoryError when not a repo."""
        with (
            patch(
                "aifred_tk.plugins.conventional_commits._git.git.Repo",
                side_effect=git.InvalidGitRepositoryError(str(tmp_path)),
            ),
            pytest.raises(git.InvalidGitRepositoryError),
        ):
            get_staged_diff(tmp_path)

    def test_raises_git_command_error_on_failure(self, tmp_path: Path) -> None:
        """get_staged_diff propagates GitCommandError on git failure."""
        mock_repo = MagicMock()
        mock_repo.git.diff.side_effect = git.GitCommandError("git diff", 128)
        with (
            patch(
                "aifred_tk.plugins.conventional_commits._git.git.Repo",
                return_value=mock_repo,
            ),
            pytest.raises(git.GitCommandError),
        ):
            get_staged_diff(tmp_path)

    def test_passes_repo_path_to_git_repo(self, tmp_path: Path) -> None:
        """get_staged_diff passes repo_path to git.Repo constructor."""
        mock_repo = MagicMock()
        mock_repo.git.diff.return_value = ""
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ) as mock_repo_cls:
            get_staged_diff(tmp_path)
        mock_repo_cls.assert_called_once_with(tmp_path)


class TestCommit:
    """commit() GitPython behaviour."""

    def test_returns_tuple_on_success(self, tmp_path: Path) -> None:
        """commit() returns (0, stdout, '') when git commit succeeds."""
        mock_repo = MagicMock()
        mock_repo.git.commit.return_value = "1 file changed"
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ):
            rc, out, err = commit("feat: add foo", tmp_path)

        assert rc == 0
        assert out == "1 file changed"
        assert err == ""

    def test_returns_nonzero_without_raising(self, tmp_path: Path) -> None:
        """commit() returns (status, '', stderr) without raising on git failure."""
        mock_repo = MagicMock()
        exc = git.GitCommandError("git commit", 1)
        exc.stderr = "nothing to commit"
        mock_repo.git.commit.side_effect = exc
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ):
            rc, _, err = commit("feat: add foo", tmp_path)

        assert rc == 1
        assert err == "nothing to commit"

    def test_passes_message_to_git_commit(self, tmp_path: Path) -> None:
        """commit() passes the message string to repo.git.commit."""
        mock_repo = MagicMock()
        mock_repo.git.commit.return_value = ""
        with patch(
            "aifred_tk.plugins.conventional_commits._git.git.Repo",
            return_value=mock_repo,
        ):
            commit("feat: my message", tmp_path)

        mock_repo.git.commit.assert_called_once_with("-m", "feat: my message")
