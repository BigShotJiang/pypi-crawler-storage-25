"""Unit tests for the PluginRegistry microkernel."""

import pytest
from dynaconf import Dynaconf

from aifred_tk.core.models import PluginNotFoundError, ToolNotFoundError
from aifred_tk.core.registry import PluginRegistry


class TestPluginRegistryLoad:
    """Registry plugin loading and tool enumeration."""

    def test_loads_demo_plugin_via_mocked_entry_points(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """Registry discovers and loads the demo plugin through entry points."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        tools = registry.get_all_tools()
        assert "demo_echo" in tools

    def test_disabled_tool_excluded_from_all_tools(
        self,
        mock_entry_points: object,
        disabled_tool_settings: Dynaconf,
    ) -> None:
        """Disabled tools must not appear in get_all_tools()."""
        registry = PluginRegistry(disabled_tool_settings)
        registry.load_plugins()

        assert "demo_echo" not in registry.get_all_tools()

    def test_broken_entry_point_skipped_gracefully(
        self,
        monkeypatch: pytest.MonkeyPatch,
        test_settings: Dynaconf,
    ) -> None:
        """A plugin that raises on load must be skipped without aborting others."""
        from unittest.mock import MagicMock

        bad_ep: MagicMock = MagicMock()
        bad_ep.name = "broken"
        bad_ep.load.side_effect = ImportError("intentional failure")

        from aifred_tk.plugins.demo.plugin import create_plugin

        good_ep: MagicMock = MagicMock()
        good_ep.name = "demo"
        good_ep.load.return_value = create_plugin

        monkeypatch.setattr(
            "aifred_tk.core.registry.entry_points",
            lambda group: [bad_ep, good_ep] if group == "aifred_tk.plugins" else [],
        )

        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        assert "demo_echo" in registry.get_all_tools()

    def test_load_plugins_idempotent_when_called_twice(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """Calling load_plugins twice should not duplicate tools."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()
        registry.load_plugins()

        tools = registry.get_all_tools()
        assert list(tools.keys()).count("demo_echo") == 1


class TestPluginRegistryGetTool:
    """Registry tool and plugin retrieval."""

    def test_get_tool_returns_correct_tool(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_tool returns the tool when its ID is known and enabled."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        tool = registry.get_tool("demo_echo")
        assert tool.tool_id == "demo_echo"

    def test_get_tool_raises_for_unknown_id(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_tool raises ToolNotFoundError for an unknown tool ID."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        with pytest.raises(ToolNotFoundError):
            registry.get_tool("nonexistent_tool")

    def test_get_plugin_returns_correct_plugin(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_plugin returns the plugin when its ID is known."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        plugin = registry.get_plugin("demo")
        assert plugin.plugin_id == "demo"

    def test_get_plugin_raises_for_unknown_id(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_plugin raises PluginNotFoundError for an unknown plugin ID."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        with pytest.raises(PluginNotFoundError):
            registry.get_plugin("nonexistent_plugin")
