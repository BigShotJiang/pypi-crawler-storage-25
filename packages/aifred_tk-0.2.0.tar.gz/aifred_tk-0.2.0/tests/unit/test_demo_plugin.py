"""Unit tests for the demo plugin."""

from contextlib import nullcontext
from typing import Any

import pytest
from pydantic import ValidationError

from aifred_tk.plugins.demo.plugin import DemoEchoArgs, DemoEchoTool, DemoPlugin


class TestDemoEchoArgs:
    """Pydantic schema validation for DemoEchoArgs."""

    @pytest.mark.parametrize(
        "message, repeat, expected_error",
        [
            ("hello", 1, nullcontext()),
            ("hi", 3, nullcontext()),
            ("", 1, nullcontext()),
            ("x", 0, pytest.raises(ValidationError)),
            ("x", -1, pytest.raises(ValidationError)),
        ],
    )
    def test_validation(
        self,
        message: str,
        repeat: int,
        expected_error: Any,
    ) -> None:
        """DemoEchoArgs validates message and repeat constraints."""
        with expected_error:
            args = DemoEchoArgs(message=message, repeat=repeat)
            assert args.message == message
            assert args.repeat == repeat

    def test_repeat_defaults_to_one(self) -> None:
        """repeat must default to 1 when not provided."""
        args = DemoEchoArgs(message="hello")
        assert args.repeat == 1


class TestDemoEchoTool:
    """Execution behaviour of DemoEchoTool."""

    @pytest.fixture()
    def tool(self) -> DemoEchoTool:
        """Return a fresh DemoEchoTool instance."""
        return DemoEchoTool()

    @pytest.mark.parametrize(
        "message, repeat, expected_echo, expected_length",
        [
            ("hello", 1, "hello", 5),
            ("hi", 3, "hihihi", 6),
            ("", 5, "", 0),
            ("ab", 2, "abab", 4),
        ],
    )
    def test_execute_returns_correct_result(
        self,
        tool: DemoEchoTool,
        message: str,
        repeat: int,
        expected_echo: str,
        expected_length: int,
    ) -> None:
        """execute() returns the expected echo and length values."""
        args = DemoEchoArgs(message=message, repeat=repeat)
        result = tool.execute(args)
        assert result["echo"] == expected_echo
        assert result["length"] == expected_length

    def test_tool_id_is_demo_echo(self, tool: DemoEchoTool) -> None:
        """tool_id must be 'demo_echo'."""
        assert tool.tool_id == "demo_echo"

    def test_args_schema_is_demo_echo_args(self, tool: DemoEchoTool) -> None:
        """args_schema must return the DemoEchoArgs class."""
        assert tool.args_schema is DemoEchoArgs


class TestDemoPlugin:
    """Plugin metadata and tool enumeration for DemoPlugin."""

    @pytest.fixture()
    def plugin(self) -> DemoPlugin:
        """Return a fresh DemoPlugin instance."""
        return DemoPlugin()

    def test_plugin_id_is_demo(self, plugin: DemoPlugin) -> None:
        """plugin_id must be 'demo'."""
        assert plugin.plugin_id == "demo"

    def test_get_tools_returns_one_tool(self, plugin: DemoPlugin) -> None:
        """get_tools must return exactly one tool."""
        tools = plugin.get_tools()
        assert len(tools) == 1

    def test_get_tools_contains_demo_echo(self, plugin: DemoPlugin) -> None:
        """The single tool returned must have tool_id 'demo_echo'."""
        tools = plugin.get_tools()
        assert tools[0].tool_id == "demo_echo"
