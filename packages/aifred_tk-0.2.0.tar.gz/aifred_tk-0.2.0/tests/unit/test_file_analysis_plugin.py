"""Unit tests for the file_analysis plugin."""

from contextlib import nullcontext
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from aifred_tk.core.models import ConfigurationError
from aifred_tk.plugins.file_analysis.plugin import (
    FileAnalysisArgs,
    FileAnalysisPlugin,
    FileAnalysisTool,
    create_plugin,
)


def _make_agent(output: str = "Analysis result.") -> MagicMock:
    run_result = MagicMock()
    run_result.output = output
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    return agent


class TestFileAnalysisArgs:
    """Pydantic schema validation for FileAnalysisArgs."""

    @pytest.mark.parametrize(
        "file_path, prompt, output_file, expected_error",
        [
            ("/tmp/file.txt", "describe functions", None, nullcontext()),
            ("/tmp/file.txt", "describe functions", "/tmp/out.txt", nullcontext()),
            ("/tmp/file.txt", "x" * 500, None, nullcontext()),
            ("/tmp/file.txt", "x" * 501, None, pytest.raises(Exception)),
        ],
    )
    def test_validation(
        self,
        file_path: str,
        prompt: str,
        output_file: str | None,
        expected_error: Any,
    ) -> None:
        """FileAnalysisArgs validates field constraints correctly."""
        with expected_error:
            args = FileAnalysisArgs(file_path=file_path, prompt=prompt, output_file=output_file)
            assert args.file_path == file_path
            assert args.prompt == prompt
            assert args.output_file == output_file

    def test_output_file_defaults_to_none(self) -> None:
        """output_file must default to None when not provided."""
        args = FileAnalysisArgs(file_path="/tmp/f.txt", prompt="describe it")
        assert args.output_file is None

    def test_missing_file_path_raises(self) -> None:
        """file_path is required and raises when missing."""
        with pytest.raises(ValidationError):
            FileAnalysisArgs(prompt="describe it")  # type: ignore[call-arg]

    def test_missing_prompt_raises(self) -> None:
        """prompt is required and raises when missing."""
        with pytest.raises(ValidationError):
            FileAnalysisArgs(file_path="/tmp/f.txt")  # type: ignore[call-arg]


class TestFileAnalysisToolMetadata:
    """Metadata properties of FileAnalysisTool."""

    @pytest.fixture()
    def tool(self) -> FileAnalysisTool:
        """Return a FileAnalysisTool with a mock agent."""
        return FileAnalysisTool(_make_agent())

    def test_tool_id(self, tool: FileAnalysisTool) -> None:
        """tool_id must be 'analyze_file'."""
        assert tool.tool_id == "analyze_file"

    def test_name(self, tool: FileAnalysisTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: FileAnalysisTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: FileAnalysisTool) -> None:
        """args_schema must return FileAnalysisArgs class."""
        assert tool.args_schema is FileAnalysisArgs


class TestFileAnalysisToolExecute:
    """execute() behaviour of FileAnalysisTool."""

    def _make_tool(self, output: str = "Analysis result.") -> FileAnalysisTool:
        return FileAnalysisTool(_make_agent(output))

    def test_file_not_found_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file does not exist."""
        tool = self._make_tool()
        result = tool.execute(
            FileAnalysisArgs(file_path=str(tmp_path / "missing.txt"), prompt="describe it")
        )
        assert result["status"] == "error"
        assert "not found" in result["message"].lower()

    def test_path_is_directory_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the path points to a directory."""
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(tmp_path), prompt="describe it"))
        assert result["status"] == "error"
        assert "not a regular file" in result["message"].lower()

    def test_file_exceeds_size_limit_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file exceeds 1 MB."""
        large_file = tmp_path / "big.txt"
        large_file.write_bytes(b"x" * (1_048_576 + 1))
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(large_file), prompt="describe it"))
        assert result["status"] == "error"
        assert "size limit" in result["message"].lower()

    def test_happy_path_returns_analysis(self, tmp_path: Path) -> None:
        """execute() returns status 'ok' and the analysis text on success."""
        target = tmp_path / "code.py"
        target.write_text("def hello(): pass\n", encoding="utf-8")
        tool = self._make_tool("Defines a hello function.")
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe functions"))
        assert result["status"] == "ok"
        assert result["analysis"] == "Defines a hello function."

    def test_happy_path_with_output_file(self, tmp_path: Path) -> None:
        """execute() writes to output_file and returns status 'written'."""
        target = tmp_path / "code.py"
        target.write_text("def hello(): pass\n", encoding="utf-8")
        out = tmp_path / "result.txt"
        tool = self._make_tool("Defines a hello function.")
        result = tool.execute(
            FileAnalysisArgs(
                file_path=str(target),
                prompt="describe functions",
                output_file=str(out),
            )
        )
        assert result["status"] == "written"
        assert result["analysis"] == "Defines a hello function."
        assert out.read_text(encoding="utf-8") == "Defines a hello function."

    def test_ignored_file_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file is listed in .aiignore."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        assert result["status"] == "error"
        assert "ignored" in result["message"].lower()

    def test_agent_not_called_for_ignored_file(self, tmp_path: Path) -> None:
        """execute() must not invoke the agent when the file is ignored."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        agent = _make_agent()
        tool = FileAnalysisTool(agent)
        tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        agent.run_sync.assert_not_called()

    def test_agent_exception_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the agent raises an exception."""
        target = tmp_path / "code.py"
        target.write_text("content\n", encoding="utf-8")
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool = FileAnalysisTool(agent)
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        assert result["status"] == "error"
        assert "agent error" in result["message"].lower()

    def test_xml_markers_present_in_agent_call(self, tmp_path: Path) -> None:
        """execute() wraps prompt and file content in XML isolation markers."""
        target = tmp_path / "doc.txt"
        target.write_text("secret content\n", encoding="utf-8")
        agent = _make_agent()
        tool = FileAnalysisTool(agent)
        tool.execute(FileAnalysisArgs(file_path=str(target), prompt="list names"))
        call_args = agent.run_sync.call_args[0][0]
        assert "<analysis_request>" in call_args
        assert "</analysis_request>" in call_args
        assert "<file_content>" in call_args
        assert "</file_content>" in call_args
        assert "list names" in call_args
        assert "secret content" in call_args

    def test_output_file_write_failure_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when writing the output file fails."""
        target = tmp_path / "code.py"
        target.write_text("content\n", encoding="utf-8")
        tool = self._make_tool()
        with patch(
            "aifred_tk.plugins.file_analysis.plugin.Path.write_text",
            side_effect=OSError("disk full"),
        ):
            result = tool.execute(
                FileAnalysisArgs(
                    file_path=str(target),
                    prompt="describe it",
                    output_file=str(tmp_path / "out.txt"),
                )
            )
        assert result["status"] == "error"
        assert "output file" in result["message"].lower()


class TestFileAnalysisPlugin:
    """Plugin metadata and tool enumeration for FileAnalysisPlugin."""

    @pytest.fixture()
    def plugin(self) -> FileAnalysisPlugin:
        """Return a FileAnalysisPlugin with a mock agent."""
        return FileAnalysisPlugin(_make_agent())

    def test_plugin_id(self, plugin: FileAnalysisPlugin) -> None:
        """plugin_id must be 'file_analysis'."""
        assert plugin.plugin_id == "file_analysis"

    def test_name(self, plugin: FileAnalysisPlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_one_tool(self, plugin: FileAnalysisPlugin) -> None:
        """get_tools must return exactly one tool."""
        assert len(plugin.get_tools()) == 1

    def test_get_tools_tool_id(self, plugin: FileAnalysisPlugin) -> None:
        """The single tool must have tool_id 'analyze_file'."""
        assert plugin.get_tools()[0].tool_id == "analyze_file"


class TestCreatePlugin:
    """Factory function create_plugin."""

    def _make_settings(self, llm_data: dict[str, Any]) -> MagicMock:
        settings = MagicMock()

        def _get(key: str, default: Any = None) -> Any:
            if key == "LLMS":
                return {}
            if key == "TOOLS__ANALYZE_FILE__LLM":
                return llm_data
            return default

        settings.get.side_effect = _get
        return settings

    def test_creates_plugin_with_ref_setting(self) -> None:
        """create_plugin resolves a ref setting and returns a FileAnalysisPlugin."""
        settings = self._make_settings({"type": "ref", "ref": "my-model"})
        with (
            patch(
                "aifred_tk.plugins.file_analysis.plugin.resolve_llm",
                return_value=MagicMock(provider="openai", model="gpt-4o-mini"),
            ),
            patch(
                "aifred_tk.plugins.file_analysis.plugin.build_pydantic_ai_model",
                return_value=MagicMock(),
            ),
            patch(
                "aifred_tk.plugins.file_analysis.plugin.create_file_analysis_agent",
                return_value=_make_agent(),
            ),
        ):
            plugin = create_plugin(settings)

        assert isinstance(plugin, FileAnalysisPlugin)

    def test_creates_plugin_with_inline_setting(self) -> None:
        """create_plugin accepts an inline LLM definition."""
        settings = self._make_settings(
            {"type": "custom", "provider": "openai", "model": "gpt-4o-mini"}
        )
        with (
            patch(
                "aifred_tk.plugins.file_analysis.plugin.resolve_llm",
                return_value=MagicMock(provider="openai", model="gpt-4o-mini"),
            ),
            patch(
                "aifred_tk.plugins.file_analysis.plugin.build_pydantic_ai_model",
                return_value=MagicMock(),
            ),
            patch(
                "aifred_tk.plugins.file_analysis.plugin.create_file_analysis_agent",
                return_value=_make_agent(),
            ),
        ):
            plugin = create_plugin(settings)

        assert isinstance(plugin, FileAnalysisPlugin)

    def test_raises_when_llm_not_configured(self) -> None:
        """create_plugin raises ConfigurationError when tools.analyze_file.llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        with pytest.raises(ConfigurationError):
            create_plugin(settings)
