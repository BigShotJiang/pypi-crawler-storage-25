"""Unit tests for the logging setup layer."""

from pathlib import Path

import pytest
from dynaconf import Dynaconf

from aifred_tk.logging.setup import setup_logging


def _active_sink_count() -> int:
    """Return the number of active loguru handlers.

    :return: Handler count.
    :rtype: int
    """
    from loguru import logger

    return len(logger._core.handlers)  # type: ignore[attr-defined]


class TestSetupLoggingCliMode:
    """Logging configuration for CLI mode."""

    def test_cli_mode_creates_two_file_sinks(self, test_settings: Dynaconf) -> None:
        """CLI mode must create exactly two file sinks (plain + JSONL)."""
        setup_logging(mode="cli", settings=test_settings, tool_id="test_tool")
        assert _active_sink_count() == 2

    def test_cli_mode_creates_log_files(self, test_settings: Dynaconf) -> None:
        """CLI mode must create .log and .log.jsonl files in the log directory."""
        log_dir = Path(test_settings.aifred_tk.log_dir)
        setup_logging(mode="cli", settings=test_settings, tool_id="mytool")
        log_files = list(log_dir.iterdir())
        names = [f.name for f in log_files]
        assert any("mytool" in n and n.endswith(".log") for n in names)

    def test_cli_mode_does_not_write_to_stderr(
        self, test_settings: Dynaconf, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """CLI mode must not emit any log output to stderr."""
        from loguru import logger

        setup_logging(mode="cli", settings=test_settings, tool_id="silent_test")
        logger.info("this should not appear on stderr")
        captured = capsys.readouterr()
        assert captured.err == ""


class TestSetupLoggingMcpMode:
    """Logging configuration for MCP mode."""

    def test_mcp_mode_creates_three_sinks(self, test_settings: Dynaconf) -> None:
        """MCP mode must create three sinks (plain file, JSONL file, stderr)."""
        setup_logging(mode="mcp", settings=test_settings, tool_id="test_tool")
        assert _active_sink_count() == 3

    def test_each_call_removes_previous_sinks(self, test_settings: Dynaconf) -> None:
        """Calling setup_logging twice must not accumulate sinks."""
        setup_logging(mode="cli", settings=test_settings, tool_id="first")
        first_count = _active_sink_count()
        setup_logging(mode="cli", settings=test_settings, tool_id="second")
        assert _active_sink_count() == first_count

    def test_log_dir_created_if_missing(self, tmp_path: Path) -> None:
        """setup_logging must create the log directory when it does not exist."""
        from importlib.resources import files

        new_dir = tmp_path / "deep" / "nested" / "logs"
        pkg_defaults = str(files("aifred_tk").joinpath("default_settings.yml"))
        cfg = tmp_path / "s.yml"
        cfg.write_text(f"aifred_tk:\n  log_dir: {new_dir}\n  log_level: INFO\n")
        settings = Dynaconf(
            settings_files=[pkg_defaults, str(cfg)],
            merge_enabled=True,
            load_dotenv=False,
        )
        setup_logging(mode="cli", settings=settings, tool_id="t")
        assert new_dir.exists()
