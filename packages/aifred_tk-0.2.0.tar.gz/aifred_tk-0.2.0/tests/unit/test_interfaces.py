"""Unit tests for the Plugin and Tool abstract base classes."""

import pytest

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs


class TestToolAbstractEnforcement:
    """Verify that Tool subclasses must implement all abstract members."""

    def test_incomplete_tool_raises_on_instantiation(self) -> None:
        """Instantiating a Tool without implementing abstracts must raise TypeError."""

        class _IncompleteToolNoToolId(Tool):
            @property
            def name(self) -> str:
                return "incomplete"

            @property
            def description(self) -> str:
                return "missing tool_id and others"

            @property
            def args_schema(self) -> type[ToolArgs]:
                return ToolArgs

            def execute(self, args: ToolArgs) -> dict:  # type: ignore[type-arg]
                return {}

        with pytest.raises(TypeError):
            _IncompleteToolNoToolId()  # type: ignore[abstract]

    def test_complete_tool_instantiates(self) -> None:
        """A fully implemented Tool subclass should instantiate without error."""

        class _CompleteTool(Tool):
            @property
            def tool_id(self) -> str:
                return "test_tool"

            @property
            def name(self) -> str:
                return "Test Tool"

            @property
            def description(self) -> str:
                return "A test tool."

            @property
            def args_schema(self) -> type[ToolArgs]:
                return ToolArgs

            def execute(self, args: ToolArgs) -> dict:  # type: ignore[type-arg]
                return {}

        tool = _CompleteTool()
        assert tool.tool_id == "test_tool"


class TestPluginAbstractEnforcement:
    """Verify that Plugin subclasses must implement all abstract members."""

    def test_incomplete_plugin_raises_on_instantiation(self) -> None:
        """Instantiating a Plugin without plugin_id must raise TypeError."""

        class _IncompletePlugin(Plugin):
            @property
            def name(self) -> str:
                return "incomplete"

            def get_tools(self) -> list[Tool]:
                return []

        with pytest.raises(TypeError):
            _IncompletePlugin()  # type: ignore[abstract]

    def test_complete_plugin_instantiates(self) -> None:
        """A fully implemented Plugin subclass should instantiate without error."""

        class _CompletePlugin(Plugin):
            @property
            def plugin_id(self) -> str:
                return "test_plugin"

            @property
            def name(self) -> str:
                return "Test Plugin"

            def get_tools(self) -> list[Tool]:
                return []

        plugin = _CompletePlugin()
        assert plugin.plugin_id == "test_plugin"
        assert plugin.get_tools() == []
