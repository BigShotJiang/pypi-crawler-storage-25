"""Unit tests for the settings configuration layer."""

import os
from pathlib import Path

import pytest
from dynaconf import Dynaconf

from aifred_tk.config.settings import create_settings


class TestCreateSettings:
    """Settings factory tests for layer precedence and file handling."""

    def test_returns_dynaconf_instance(self) -> None:
        """create_settings must return a Dynaconf instance."""
        settings = create_settings()
        assert isinstance(settings, Dynaconf)

    def test_defaults_provide_log_dir(self) -> None:
        """Default settings must expose aifred_tk.log_dir."""
        settings = create_settings()
        assert hasattr(settings, "aifred_tk")
        assert hasattr(settings.aifred_tk, "log_dir")

    def test_defaults_provide_log_level(self) -> None:
        """Default settings must expose aifred_tk.log_level."""
        settings = create_settings()
        assert settings.aifred_tk.log_level == "INFO"

    def test_extra_config_file_overrides_defaults(self, tmp_path: Path) -> None:
        """A custom config file must override default values."""
        cfg = tmp_path / "custom.yml"
        cfg.write_text("aifred_tk:\n  log_level: DEBUG\n")
        settings = create_settings(extra_config_file=cfg)
        assert settings.aifred_tk.log_level == "DEBUG"

    def test_env_var_overrides_file(self, tmp_path: Path) -> None:
        """Environment variables must take precedence over file settings."""
        cfg = tmp_path / "custom.yml"
        cfg.write_text("aifred_tk:\n  log_level: WARNING\n")

        env_key = "AIFRED_TK_AIFRED_TK__LOG_LEVEL"
        os.environ[env_key] = "CRITICAL"
        try:
            settings = create_settings(extra_config_file=cfg)
            assert settings.aifred_tk.log_level == "CRITICAL"
        finally:
            del os.environ[env_key]

    def test_missing_conventional_files_silently_skipped(self) -> None:
        """Missing system/user/local config files must not raise errors."""
        settings = create_settings()
        assert settings is not None

    def test_tool_enabled_defaults_to_true_when_absent(self) -> None:
        """Tools absent from settings must be treated as enabled by default."""
        settings = create_settings()
        tools_cfg = getattr(settings, "tools", {})
        tool_cfg = getattr(tools_cfg, "totally_unknown_tool_xyz", None)
        assert tool_cfg is None

    @pytest.mark.parametrize(
        "content, expected_level",
        [
            ("aifred_tk:\n  log_level: ERROR\n", "ERROR"),
            ("aifred_tk:\n  log_level: WARNING\n", "WARNING"),
        ],
    )
    def test_log_level_read_from_file(
        self,
        tmp_path: Path,
        content: str,
        expected_level: str,
    ) -> None:
        """Log level is correctly read from various config file values."""
        cfg = tmp_path / "s.yml"
        cfg.write_text(content)
        settings = create_settings(extra_config_file=cfg)
        assert settings.aifred_tk.log_level == expected_level
