"""Unit tests for elicitation data models."""

import pytest

from aifred_tk.core.models import ElicitationCancelledError
from aifred_tk.elicitation import Choice, ElicitationResult, elicit_choice
from aifred_tk.elicitation._models import Choice as ChoiceDirect


class TestChoice:
    def test_label_only(self) -> None:
        c = Choice("Alpha")
        assert c.label == "Alpha"
        assert c.description is None
        assert c.example is None

    def test_all_fields(self) -> None:
        c = Choice("Beta", description="Second option", example="foo")
        assert c.label == "Beta"
        assert c.description == "Second option"
        assert c.example == "foo"

    def test_same_class_via_module(self) -> None:
        assert Choice is ChoiceDirect


class TestElicitationResult:
    def test_is_free_input_false_for_normal_selection(self) -> None:
        r = ElicitationResult(selected_index=0, selected_label="Alpha", free_text=None)
        assert not r.is_free_input

    def test_is_free_input_true_when_index_negative(self) -> None:
        r = ElicitationResult(selected_index=-1, selected_label=None, free_text="custom")
        assert r.is_free_input

    def test_free_text_populated_on_free_input(self) -> None:
        r = ElicitationResult(selected_index=-1, selected_label=None, free_text="my answer")
        assert r.free_text == "my answer"


class TestElicitationCancelledError:
    def test_is_aifred_error(self) -> None:
        from aifred_tk.core.models import AifredError

        err = ElicitationCancelledError("cancelled")
        assert isinstance(err, AifredError)

    def test_message(self) -> None:
        err = ElicitationCancelledError("user cancelled")
        assert "user cancelled" in str(err)


class TestElicitChoiceDispatcher:
    def test_raises_on_empty_choices(self) -> None:
        with pytest.raises(ValueError, match="empty"):
            elicit_choice("Q?", [])

    def test_no_mcp_context_uses_numbered_when_not_tty(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Outside MCP, non-TTY stdout → NumberedElicitor is called."""
        import sys

        monkeypatch.setattr(sys.stdout, "isatty", lambda: False)

        answers = iter(["1"])
        monkeypatch.setattr("builtins.input", lambda _prompt="": next(answers))

        result = elicit_choice("Pick one?", [Choice("Alpha"), Choice("Beta")])
        assert result.selected_index == 0
        assert result.selected_label == "Alpha"

    def test_settings_numbered_mode_forces_numbered(
        self, monkeypatch: pytest.MonkeyPatch, test_settings: object
    ) -> None:
        from dynaconf import Dynaconf

        settings: Dynaconf = test_settings  # type: ignore[assignment]
        # Override elicitation mode to numbered
        monkeypatch.setenv("AIFRED_TK__ELICITATION__MODE", "numbered")

        answers = iter(["2"])
        monkeypatch.setattr("builtins.input", lambda _prompt="": next(answers))

        result = elicit_choice("Pick?", [Choice("A"), Choice("B")], settings=settings)
        assert result.selected_index == 1
        assert result.selected_label == "B"
