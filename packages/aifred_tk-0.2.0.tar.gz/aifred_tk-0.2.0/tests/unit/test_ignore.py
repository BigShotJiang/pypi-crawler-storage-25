"""Unit tests for aifred_tk.core.ignore."""

import time
from pathlib import Path

import pytest

import aifred_tk.core.ignore as ignore_module
from aifred_tk.core.ignore import AiIgnoreChecker


@pytest.fixture(autouse=True)
def clear_cache() -> None:
    """Reset the module-level cache before every test."""
    ignore_module._cache.clear()


class TestAiIgnoreCheckerNoIgnoreFile:
    """Behaviour when no .aiignore exists anywhere in the ancestor chain."""

    def test_not_ignored_when_no_aiignore(self, tmp_path: Path) -> None:
        """is_ignored returns False when there are no .aiignore files."""
        target = tmp_path / "file.txt"
        target.write_text("content\n", encoding="utf-8")
        checker = AiIgnoreChecker.for_path(target)
        assert not checker.is_ignored(target)

    def test_not_ignored_for_nonexistent_file(self, tmp_path: Path) -> None:
        """is_ignored returns False for a path that does not exist."""
        checker = AiIgnoreChecker.for_path(tmp_path / "ghost.txt")
        assert not checker.is_ignored(tmp_path / "ghost.txt")


class TestAiIgnoreCheckerPatternMatching:
    """Pattern matching behaviour."""

    def test_exact_filename_ignored(self, tmp_path: Path) -> None:
        """A file listed by name in .aiignore is ignored."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("shh\n", encoding="utf-8")
        assert AiIgnoreChecker.for_path(target).is_ignored(target)

    def test_non_matching_file_not_ignored(self, tmp_path: Path) -> None:
        """A file that does not match any pattern is not ignored."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "safe.txt"
        target.write_text("ok\n", encoding="utf-8")
        assert not AiIgnoreChecker.for_path(target).is_ignored(target)

    def test_glob_pattern_ignored(self, tmp_path: Path) -> None:
        """Wildcard patterns in .aiignore are honoured."""
        (tmp_path / ".aiignore").write_text("*.key\n", encoding="utf-8")
        target = tmp_path / "private.key"
        target.write_text("key data\n", encoding="utf-8")
        assert AiIgnoreChecker.for_path(target).is_ignored(target)

    def test_parent_aiignore_applies_to_child(self, tmp_path: Path) -> None:
        """.aiignore in a parent directory applies to files in subdirectories."""
        (tmp_path / ".aiignore").write_text("*.secret\n", encoding="utf-8")
        sub = tmp_path / "sub"
        sub.mkdir()
        target = sub / "data.secret"
        target.write_text("private\n", encoding="utf-8")
        assert AiIgnoreChecker.for_path(target).is_ignored(target)

    def test_sibling_aiignore_does_not_apply(self, tmp_path: Path) -> None:
        """.aiignore in a sibling directory does not affect an unrelated path."""
        sibling = tmp_path / "other"
        sibling.mkdir()
        (sibling / ".aiignore").write_text("*.txt\n", encoding="utf-8")
        sub = tmp_path / "mine"
        sub.mkdir()
        target = sub / "notes.txt"
        target.write_text("ok\n", encoding="utf-8")
        assert not AiIgnoreChecker.for_path(target).is_ignored(target)

    def test_negation_pattern_keeps_file(self, tmp_path: Path) -> None:
        """Negation patterns un-ignore a previously matched file."""
        (tmp_path / ".aiignore").write_text("*.log\n!keep.log\n", encoding="utf-8")
        ignored = tmp_path / "debug.log"
        kept = tmp_path / "keep.log"
        ignored.write_text("x\n", encoding="utf-8")
        kept.write_text("y\n", encoding="utf-8")
        assert AiIgnoreChecker.for_path(ignored).is_ignored(ignored)
        assert not AiIgnoreChecker.for_path(kept).is_ignored(kept)

    def test_multiple_aiignore_files_combine(self, tmp_path: Path) -> None:
        """Patterns from multiple .aiignore files in the hierarchy are additive."""
        (tmp_path / ".aiignore").write_text("*.env\n", encoding="utf-8")
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / ".aiignore").write_text("*.key\n", encoding="utf-8")
        env_file = sub / "prod.env"
        key_file = sub / "id.key"
        env_file.write_text("VAR=1\n", encoding="utf-8")
        key_file.write_text("KEY\n", encoding="utf-8")
        assert AiIgnoreChecker.for_path(env_file).is_ignored(env_file)
        assert AiIgnoreChecker.for_path(key_file).is_ignored(key_file)


class TestAiIgnoreCheckerCache:
    """Stat-based cache behaviour."""

    def test_cache_hit_reuses_same_spec_object(self, tmp_path: Path) -> None:
        """Calling for_path twice without modifying .aiignore reuses the same PathSpec."""
        aiignore = tmp_path / ".aiignore"
        aiignore.write_text("*.secret\n", encoding="utf-8")
        target = tmp_path / "x.secret"
        target.write_text("x\n", encoding="utf-8")

        AiIgnoreChecker.for_path(target)
        spec_first = ignore_module._cache[aiignore.resolve()][1]
        AiIgnoreChecker.for_path(target)
        spec_second = ignore_module._cache[aiignore.resolve()][1]

        assert spec_first is spec_second

    def test_cache_invalidated_on_mtime_change(self, tmp_path: Path) -> None:
        """Editing .aiignore is reflected on the next for_path call."""
        aiignore = tmp_path / ".aiignore"
        aiignore.write_text("old_pattern.txt\n", encoding="utf-8")
        target = tmp_path / "new_pattern.txt"
        target.write_text("content\n", encoding="utf-8")

        checker1 = AiIgnoreChecker.for_path(target)
        assert not checker1.is_ignored(target)

        time.sleep(0.01)
        aiignore.write_text("new_pattern.txt\n", encoding="utf-8")
        aiignore_path = aiignore.resolve()
        if aiignore_path in ignore_module._cache:
            cached_mtime = ignore_module._cache[aiignore_path][0]
            actual_mtime = aiignore_path.stat().st_mtime
            if cached_mtime == actual_mtime:
                pytest.skip("Filesystem mtime resolution too coarse for this test")

        checker2 = AiIgnoreChecker.for_path(target)
        assert checker2.is_ignored(target)
