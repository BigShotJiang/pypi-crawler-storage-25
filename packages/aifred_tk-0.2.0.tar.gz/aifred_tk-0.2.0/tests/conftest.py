"""Shared fixtures for the aifred-tk test suite."""

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
from dynaconf import Dynaconf

from aifred_tk.plugins.demo.plugin import create_plugin


def _make_settings(tmp_path: Path, extra: str = "") -> Dynaconf:
    """Write a minimal settings YAML and return a Dynaconf instance.

    :param tmp_path: Temporary directory for the settings file and logs.
    :type tmp_path: Path
    :param extra: Additional YAML content appended to the base config.
    :type extra: str
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    log_dir = tmp_path / "logs"
    log_dir.mkdir(exist_ok=True)

    cfg = tmp_path / "settings.yml"
    cfg.write_text(f"aifred_tk:\n  log_dir: {log_dir}\n  log_level: DEBUG\n{extra}")

    from importlib.resources import files

    pkg_defaults = str(files("aifred_tk").joinpath("default_settings.yml"))
    return Dynaconf(
        settings_files=[pkg_defaults, str(cfg)],
        merge_enabled=True,
        load_dotenv=False,
    )


@pytest.fixture()
def test_settings(tmp_path: Path) -> Dynaconf:
    """Return a minimal Dynaconf settings instance for testing.

    Points ``aifred_tk.log_dir`` at the temporary directory so log files
    do not leak into the working tree during tests.

    :param tmp_path: pytest-provided temporary directory.
    :type tmp_path: Path
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    return _make_settings(tmp_path)


@pytest.fixture()
def mock_entry_points(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    """Patch ``importlib.metadata.entry_points`` to return the demo plugin.

    :param monkeypatch: pytest monkeypatch fixture.
    :type monkeypatch: pytest.MonkeyPatch
    :return: The mock entry point object.
    :rtype: MagicMock
    """
    ep: MagicMock = MagicMock()
    ep.name = "demo"
    ep.load.return_value = create_plugin

    def _fake_entry_points(group: str) -> list[Any]:
        if group == "aifred_tk.plugins":
            return [ep]
        return []

    monkeypatch.setattr(
        "aifred_tk.core.registry.entry_points",
        _fake_entry_points,
    )
    return ep


@pytest.fixture()
def disabled_tool_settings(tmp_path: Path) -> Dynaconf:
    """Return settings with ``demo_echo`` explicitly disabled.

    :param tmp_path: pytest-provided temporary directory.
    :type tmp_path: Path
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    return _make_settings(
        tmp_path,
        extra="tools:\n  demo_echo:\n    enabled: false\n",
    )
