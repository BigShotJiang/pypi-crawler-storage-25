"""Test suite for aifred-tk."""
