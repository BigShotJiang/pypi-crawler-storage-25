# Quick Start

## Full audit

```bash
./manage.py doctor
```

Runs every registered check and prints a rich terminal report. Example tail:

```
╭──────────── Summary ────────────╮
│ 2 critical · 20 warning · 6 info │
╰─────────────────────────────────╯
```

## Target a specific layer

Each check has a short `id`. Combine them with commas:

```bash
./manage.py doctor --section forms,post_smoke,forms_meta
```

## CI mode

Exits with a non-zero status when any finding has severity `error` or
`critical` (configurable via `fail_on`):

```bash
./manage.py doctor --ci
```

## JSON output

For piping into dashboards or artifact storage:

```bash
./manage.py doctor --json | jq '.[] | select(.severity=="critical")'
```

## Skip slow checks

`urls` and `post_smoke` walk every URL pattern and can take a minute on a
300-route project. Skip them for a fast pre-commit sanity run:

```bash
./manage.py doctor --quick
```

## Typical pre-merge CI step

=== "GitHub Actions"

    ```yaml
    - name: django-test-doctor
      run: ./manage.py doctor --ci
    ```

=== "GitLab CI"

    ```yaml
    doctor:
      script: ./manage.py doctor --ci
    ```

## What next

- [Tune the defaults](configuration.md)
- [Write a custom check](../guides/custom-checks.md)
