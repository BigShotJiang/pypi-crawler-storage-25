# Configuration

Every setting lives under `[tool.django-doctor]` (and per-check subtables)
in your project's `pyproject.toml`. The file is discovered by walking up
from the current directory, so you can run `./manage.py doctor` from any
subdirectory.

## Reference

```toml
[tool.django-doctor]
# Which checks to run. "*" = everything registered via entry points.
enabled = ["*"]
# Checks to skip (fnmatch patterns, e.g. ["post_smoke", "security"]).
disabled = []
# Severities that cause --ci to exit 1.
fail_on = ["critical", "error"]
# Per-finding silencers: "<check_id>:<rule>" (fnmatch).
# Example: "forms:forms.blank_init" silences every ModelForm blank-init warning.
ignore = []

[tool.django-doctor.urls]
roles   = ["anonymous", "authenticated", "staff", "superuser"]
methods = ["GET"]
# URL name patterns to skip (fnmatch). Useful for vendor routes you can't fix.
skip    = ["admin:*", "djdt:*", "rp-initiated-logout"]
timeout = 10

[tool.django-doctor.forms]
# Which instantiation scenarios to try on each ModelForm.
scenarios = ["blank", "empty_data"]

[tool.django-doctor.migrations]
# Extra app labels to skip (in addition to the site-packages heuristic).
skip_apps = []
# If true, drift in contrib/third-party apps is reported. Usually noisy.
include_third_party = false

[tool.django-doctor.admin]
# ModelAdmin for these apps is never inspected.
skip_apps = ["admin", "auth", "contenttypes", "sessions"]

[tool.django-doctor.models]
skip_apps = ["admin", "auth", "contenttypes", "sessions", "messages", "sites"]
# These rules emit WARNING instead of INFO when matched.
soft_checks = ["ordering_missing"]

[tool.django-doctor.security]
# Substring match — present in SECRET_KEY → CRITICAL finding.
forbidden_secret_keys = ["django-insecure", "changeme", "secret"]

[tool.django-doctor.post_smoke]
# URL name patterns to skip (fnmatch).
skip = ["legacy:*"]
```

## Ignoring a single finding

`ignore` matches `<check_id>:<rule>` via `fnmatch`. Examples:

```toml
ignore = [
  # Silence all admin list_display findings for the legacy reports app.
  "admin:admin.list_display.missing_field",
  # Silence every finding from a single check.
  "drf:*",
  # Silence the NOT-NULL-without-default warning on a specific form base.
  "forms_meta:forms.cleaned_data.orphan",
]
```

## Skipping a check entirely

```toml
[tool.django-doctor]
disabled = ["post_smoke"]   # skip the slow POST-every-CBV layer
```

## Running only a subset from CLI

```bash
./manage.py doctor --section forms_meta,drf
```

Takes precedence over `enabled` in `pyproject.toml`.

## Next

- [Per-check deep dive](../checks/index.md)
