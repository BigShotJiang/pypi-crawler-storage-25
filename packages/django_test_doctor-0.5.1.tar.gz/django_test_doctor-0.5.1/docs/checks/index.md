# Checks — overview

django-test-doctor ships **ten** checks in 0.5. Each one is a pluggable
class discovered via the `django_doctor.checks` entry point group, so
third-party packages can contribute more.

| ID            | Severity on failure        | Needs DB write | Class of bug caught                               |
|---------------|----------------------------|----------------|----------------------------------------------------|
| `system`      | WARNING → CRITICAL         | no             | Whatever `./manage.py check` already finds         |
| `security`    | WARNING → CRITICAL         | no             | Deployment settings, weak `SECRET_KEY`, `DEBUG`    |
| `models`      | INFO → ERROR               | no             | Missing `__str__`, `SET_NULL` on NOT NULL FK       |
| `migrations`  | WARNING / ERROR            | no             | Unapplied migrations, schema drift                 |
| `admin`       | ERROR                      | no             | Typos in `list_display` / `list_filter` / ordering |
| `forms`       | ERROR (INFO when arg-req)  | no             | `Form.__init__` crashes on blank / empty POST      |
| `forms_meta`  | ERROR                      | no             | Orphan `cleaned_data[x] = …` on NOT NULL column    |
| `drf`         | ERROR (+ INFO)             | no             | Serializer `Meta.fields` ↔ model mismatch          |
| `urls`        | CRITICAL on 5xx            | yes (users)    | GET on any URL returns 5xx                          |
| `post_smoke`  | CRITICAL on 5xx            | yes (savepoint)| POST to `CreateView` / `UpdateView` returns 5xx    |

## Ordering

Checks declare a numeric `order` and run from lowest to highest. The
default order groups cheap static checks first, then instance-free
introspection, then the DB-touching smoke checks. See each check's page
for its specific order number.

## Severity ladder

```
INFO < WARNING < ERROR < CRITICAL
```

`--ci` exits non-zero on findings ≥ `fail_on` (default
`["critical", "error"]`).

## Groups in these docs

- [system & security](system-security.md) — runtime and deployment posture
- [urls & post_smoke](urls-post-smoke.md) — HTTP-level smoke tests
- [forms & forms_meta](forms.md) — form lifecycle (init + clean + save)
- [models & migrations](models-migrations.md) — data-layer hygiene
- [admin](admin.md) — Django admin registrations
- [drf](drf.md) — Django REST framework serializers
