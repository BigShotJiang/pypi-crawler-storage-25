"""django-test-doctor — 360° health check for Django projects."""

__version__ = "0.5.1"

from .finding import Finding, Severity
from .registry import Check, Project

__all__ = ["Check", "Finding", "Project", "Severity", "__version__"]
