"""Load django-doctor config from the host project's pyproject.toml."""

from __future__ import annotations

import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib


DEFAULT_CONFIG: dict = {
    "enabled": ["*"],
    "disabled": [],
    "fail_on": ["critical", "error"],
    "ignore": [],
    "urls": {
        "roles": ["anonymous", "authenticated", "staff", "superuser"],
        "skip": ["admin:*", "djdt:*"],
        "methods": ["GET"],
        "timeout": 10,
    },
    "forms": {
        "scenarios": ["blank", "empty_data"],
    },
    "migrations": {
        "skip_apps": [],
        # Flagging drift in third-party/contrib apps is noise — the user
        # can't fix it. Flip to True to override.
        "include_third_party": False,
    },
    "system": {},
    "admin": {
        "skip_apps": ["admin", "auth", "contenttypes", "sessions"],
    },
    "models": {
        "skip_apps": [
            "admin", "auth", "contenttypes", "sessions", "messages", "sites",
        ],
        "soft_checks": ["ordering_missing"],
    },
    "security": {
        "forbidden_secret_keys": [
            "django-insecure", "changeme", "secret", "your-secret-key",
        ],
    },
}


def load_config(base_dir: str | Path | None = None) -> dict:
    """Merge defaults with `[tool.django-doctor]` from pyproject.toml.

    Walks up from `base_dir` looking for pyproject.toml so users can run
    doctor from any subdirectory inside their project.
    """
    config = _deep_copy(DEFAULT_CONFIG)
    pyproject = _find_pyproject(Path(base_dir or Path.cwd()))
    if pyproject is None:
        return config

    with pyproject.open("rb") as fh:
        data = tomllib.load(fh)
    user_config = data.get("tool", {}).get("django-doctor", {})
    _deep_merge(config, user_config)
    return config


def _find_pyproject(start: Path) -> Path | None:
    current = start.resolve()
    for parent in [current, *current.parents]:
        candidate = parent / "pyproject.toml"
        if candidate.is_file():
            return candidate
    return None


def _deep_copy(source: dict) -> dict:
    out: dict = {}
    for key, value in source.items():
        out[key] = _deep_copy(value) if isinstance(value, dict) else (
            list(value) if isinstance(value, list) else value
        )
    return out


def _deep_merge(target: dict, source: dict) -> None:
    for key, value in source.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value
