"""Auto-generate minimal valid POST payloads from Django forms.

Produces the kind of dict you'd paste into the Django test client:

    from django_doctor.fixtures import make_form_fixture
    data = make_form_fixture(MyModelForm)
    client.post("/my-view/", data)

The generator is deliberately conservative — it returns the *simplest* valid
value for each required field and leaves optional fields out. Callers layer
their own overrides on top when a specific combination is needed.
"""

from __future__ import annotations

import datetime
from typing import Any

from django import forms
from django.db import models


def make_form_fixture(form_cls: type[forms.BaseForm], overrides: dict | None = None) -> dict:
    """Return a minimal dict of form-ready values for every required field."""
    form = form_cls()
    data: dict[str, Any] = {}
    for name, field in form.fields.items():
        if not field.required:
            continue
        try:
            value = _sample_value(field)
        except Exception:
            continue
        if value is _SKIP:
            continue
        data[name] = value
    if overrides:
        data.update(overrides)
    return data


_SKIP = object()


def _sample_value(field: forms.Field) -> Any:
    """Return a value acceptable to ``field.clean()`` for a required field."""
    # ModelChoiceField / ModelMultipleChoiceField — pick real objects.
    if isinstance(field, forms.ModelMultipleChoiceField):
        obj = field.queryset.first()
        return [obj.pk] if obj else _SKIP
    if isinstance(field, forms.ModelChoiceField):
        obj = field.queryset.first()
        return obj.pk if obj else _SKIP

    # Choice fields — pick the first non-empty choice.
    if isinstance(field, (forms.ChoiceField, forms.TypedChoiceField)):
        for value, _label in _iter_choices(field):
            if value in (None, ""):
                continue
            return value
        return _SKIP
    if isinstance(field, forms.MultipleChoiceField):
        for value, _label in _iter_choices(field):
            if value in (None, ""):
                continue
            return [value]
        return _SKIP

    # Numerics.
    if isinstance(field, forms.IntegerField):
        return field.min_value if field.min_value is not None else 1
    if isinstance(field, forms.DecimalField):
        return "0"
    if isinstance(field, forms.FloatField):
        return "0"

    # Booleans.
    if isinstance(field, forms.BooleanField):
        return True
    if isinstance(field, forms.NullBooleanField):
        return True

    # Dates / times.
    if isinstance(field, forms.DateTimeField):
        return datetime.datetime(2026, 1, 1, 0, 0).isoformat(sep=" ")
    if isinstance(field, forms.DateField):
        return "2026-01-01"
    if isinstance(field, forms.TimeField):
        return "00:00"

    # Email / URL / text.
    if isinstance(field, forms.EmailField):
        return "doctor@example.com"
    if isinstance(field, forms.URLField):
        return "https://example.com"
    if isinstance(field, forms.SlugField):
        return "doctor-x"

    # Files — the test client wants a SimpleUploadedFile. Skip to keep the
    # fixture serializable; POST-smoke callers layer their own files on top.
    if isinstance(field, (forms.FileField, forms.ImageField)):
        return _SKIP

    # Fallback for CharField + friends: a short non-empty string within limits.
    max_length = getattr(field, "max_length", None)
    sample = "x"
    if max_length is not None and max_length < len(sample):
        sample = sample[:max_length]
    return sample


def _iter_choices(field):
    """Flatten grouped choices (Django allows nested tuples)."""
    choices = field.choices
    if callable(choices):
        choices = choices()
    for entry in choices:
        value, label = entry
        if isinstance(label, (list, tuple)):
            for sub_value, sub_label in label:
                yield sub_value, sub_label
        else:
            yield value, label


def resolve_required_fields(form_cls: type[forms.BaseForm]) -> list[str]:
    """Names of every required field on this form (handy for reporting)."""
    form = form_cls()
    return [name for name, field in form.fields.items() if field.required]
