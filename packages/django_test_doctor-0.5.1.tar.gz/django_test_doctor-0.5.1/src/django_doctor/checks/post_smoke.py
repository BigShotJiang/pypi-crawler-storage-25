"""POST smoke: auto-generate a fixture, POST it, fail on 5xx.

Closes the gap the ``urls`` check leaves open — it only hits GET, so a
``CreateView`` that 500s only on ``form.save()`` (IntegrityError in a
``post_save`` signal, bad ``__init__``, missing NOT NULL FK, …) flies under
the radar. This check submits each form with a minimal auto-generated
payload and catches the real failure.

Safe by construction: every request runs inside a ``transaction.atomic()`` +
``savepoint_rollback`` so the production database is **not** mutated even
if the view reaches ``.save()``. Run against a dev database anyway.
"""

from __future__ import annotations

import re
from typing import Iterable, Iterator

from django import forms
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import transaction
from django.test import Client
from django.test.utils import override_settings
from django.urls import URLPattern, URLResolver, get_resolver
from django.views.generic.edit import CreateView, UpdateView

from ..finding import Finding, Severity
from ..fixtures import make_form_fixture, resolve_required_fields
from ..registry import Check, Project


_KWARG_PATTERN = re.compile(r"<(?:(\w+):)?(\w+)>")


class PostSmokeCheck(Check):
    id = "post_smoke"
    description = "POST to every CreateView/UpdateView with an auto fixture, fail on 5xx"
    order = 55
    slow = True

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_patterns: list[str] = config.get("skip", [])
        allowed = list(getattr(settings, "ALLOWED_HOSTS", []) or []) + ["testserver", "*"]

        with override_settings(ALLOWED_HOSTS=allowed):
            client = _build_superuser_client()
            if client is None:
                return
            resolver = get_resolver(getattr(settings, "ROOT_URLCONF", None))
            for url_name, route, view_cls in _iter_form_views(resolver):
                if _is_skipped(url_name, skip_patterns):
                    continue
                if _KWARG_PATTERN.search(route):
                    # Needs ids we don't have yet. v0.5 will wire fixtures here.
                    continue
                yield from self._probe(client, url_name, route, view_cls)

    def _probe(self, client, url_name, route, view_cls) -> Iterator[Finding]:
        form_cls = _extract_form_cls(view_cls)
        if form_cls is None:
            return

        try:
            payload = make_form_fixture(form_cls)
        except Exception as exc:  # noqa: BLE001
            yield Finding(
                severity=Severity.WARNING,
                check_id=self.id,
                rule="post_smoke.fixture_error",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=f"Could not build a fixture for {form_cls.__name__}: {exc}",
                fix_hint=(
                    "Simplify form.__init__ or mark the view in "
                    "[tool.django-doctor.post_smoke].skip."
                ),
            )
            return

        required = resolve_required_fields(form_cls)
        missing = [k for k in required if k not in payload]
        if missing:
            yield Finding(
                severity=Severity.INFO,
                check_id=self.id,
                rule="post_smoke.partial_fixture",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=(
                    f"Cannot auto-generate required field(s) {missing!r}; "
                    "POST not attempted."
                ),
                fix_hint=(
                    "Typically a FileField, a ModelChoice with no DB rows, "
                    "or a MultiWidget. Add a tailored fixture in your tests."
                ),
            )
            return

        # Run the POST inside a savepoint and always roll back.
        sid = transaction.savepoint()
        try:
            response = client.post(route, payload, follow=False)
        except Exception as exc:  # noqa: BLE001
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule="post_smoke.exception",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=f"POST raised {type(exc).__name__}: {exc}",
                fix_hint=(
                    "Reproduce with the same payload in a local shell + Client. "
                    "Common causes: unguarded FK access in a post_save signal, "
                    "NOT NULL column missing from the form."
                ),
                extra={"payload_keys": sorted(payload.keys())},
            )
            return
        finally:
            transaction.savepoint_rollback(sid)

        if 500 <= response.status_code < 600:
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule="post_smoke.5xx",
                location=f"{url_name or route} ({view_cls.__name__})",
                message=(
                    f"POST returned HTTP {response.status_code} with "
                    f"auto-generated payload {sorted(payload.keys())!r}."
                ),
                fix_hint=(
                    "The view reaches .save() but something down the stack "
                    "(signal, post_save hook, constraint) raises. Check the "
                    "Django error log on the target instance."
                ),
                extra={"status_code": response.status_code},
            )


def _build_superuser_client():
    """Spin up a transient superuser and log them in via the test client."""
    User = get_user_model()
    try:
        user, _ = User.objects.get_or_create(
            username="doctor_post_smoke",
            defaults={"email": "doctor-post@example.com", "is_staff": True, "is_superuser": True},
        )
        user.is_staff = True
        user.is_superuser = True
        # Some projects have a required `type_utilisateur` enum on their User.
        if hasattr(user, "type_utilisateur"):
            try:
                user.type_utilisateur = type(user).TypeUtilisateur.STAFF
            except (AttributeError, KeyError):
                pass
        user.save()
    except Exception:  # pragma: no cover — test DB might refuse creation
        return None
    client = Client()
    client.force_login(user)
    return client


def _iter_form_views(
    resolver: URLResolver, prefix: str = "/"
) -> Iterator[tuple[str, str, type]]:
    for entry in resolver.url_patterns:
        if isinstance(entry, URLPattern):
            cls = _view_class(entry)
            if cls is None:
                continue
            if not _is_form_view(cls):
                continue
            route = prefix + str(entry.pattern).lstrip("/")
            yield entry.name or "", route, cls
        elif isinstance(entry, URLResolver):
            nested = prefix + str(entry.pattern).lstrip("/")
            yield from _iter_form_views(entry, prefix=nested)


def _view_class(pattern: URLPattern):
    cb = getattr(pattern, "callback", None)
    if cb is None:
        return None
    for attr in ("view_class", "cls"):
        cls = getattr(cb, attr, None)
        if cls is not None:
            return cls
    return None


def _is_form_view(cls) -> bool:
    try:
        return issubclass(cls, (CreateView, UpdateView))
    except TypeError:
        return False


def _extract_form_cls(view_cls):
    """Return the ModelForm class a CBV will instantiate at dispatch time."""
    form_cls = getattr(view_cls, "form_class", None)
    if form_cls is not None:
        return form_cls
    # Fall back to model-based forms via modelform_factory.
    model = getattr(view_cls, "model", None)
    fields = getattr(view_cls, "fields", None)
    if model is None or not fields:
        return None
    from django.forms import modelform_factory

    return modelform_factory(model, fields=fields)


def _is_skipped(url_name: str, patterns: list[str]) -> bool:
    import fnmatch
    return any(fnmatch.fnmatch(url_name, pat) for pat in patterns)
