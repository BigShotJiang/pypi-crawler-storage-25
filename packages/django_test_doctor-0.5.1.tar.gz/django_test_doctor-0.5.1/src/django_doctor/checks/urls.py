"""URL smoke: probe every registered URL under multiple auth roles, fail on 5xx."""

from __future__ import annotations

import fnmatch
import re
from typing import Iterable, Iterator

from django.conf import settings
from django.contrib.auth import get_user_model
from django.test import Client
from django.test.utils import override_settings
from django.urls import URLPattern, URLResolver, get_resolver

from ..finding import Finding, Severity
from ..registry import Check, Project


# Pattern like <int:pk>, <uuid:id>, <slug:slug>
_KWARG_PATTERN = re.compile(r"<(?:(\w+):)?(\w+)>")


class UrlSmokeCheck(Check):
    id = "urls"
    description = "Probe every URL pattern with a Django test Client, fail on 5xx"
    order = 50
    slow = True

    def run(self, project: Project) -> Iterable[Finding]:
        config = self.get_config(project)
        skip_patterns: list[str] = config.get("skip", [])
        methods: list[str] = config.get("methods", ["GET"])
        roles: list[str] = config.get(
            "roles", ["anonymous", "authenticated", "staff", "superuser"]
        )

        # Django's test Client sends Host: testserver; prod settings rarely
        # include that host. Widen ALLOWED_HOSTS just for the duration of the
        # probe so every URL can be reached regardless of the host config.
        allowed = list(getattr(settings, "ALLOWED_HOSTS", []) or []) + ["testserver", "*"]
        with override_settings(ALLOWED_HOSTS=allowed):
            resolver = get_resolver(getattr(settings, "ROOT_URLCONF", None))
            clients = _build_clients(roles)

            for url_name, route in _iter_concrete_urls(resolver):
                if _is_skipped(url_name, skip_patterns) or _has_unresolved_kwargs(route):
                    continue
                for method in methods:
                    for role, client in clients.items():
                        yield from self._probe(client, role, method, url_name, route)

    def _probe(
        self,
        client: Client,
        role: str,
        method: str,
        url_name: str,
        route: str,
    ) -> Iterator[Finding]:
        try:
            response = client.generic(method, route, follow=False)
        except Exception as exc:  # noqa: BLE001
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule=f"urls.{method.lower()}.exception",
                location=f"{url_name or route} ({role})",
                message=f"View raised {type(exc).__name__}: {exc}",
                fix_hint="The view crashed before returning a response — see traceback.",
            )
            return

        if 500 <= response.status_code < 600:
            yield Finding(
                severity=Severity.CRITICAL,
                check_id=self.id,
                rule=f"urls.{method.lower()}.5xx",
                location=f"{url_name or route} ({role})",
                message=f"HTTP {response.status_code} on {method} {route}",
                fix_hint=(
                    "A view returned a server error in the default test client. "
                    "Reproduce locally with `./manage.py shell` + Client()."
                ),
                extra={"status_code": response.status_code, "role": role},
            )


def _iter_concrete_urls(
    resolver: URLResolver,
    prefix: str = "/",
) -> Iterator[tuple[str, str]]:
    for entry in resolver.url_patterns:
        if isinstance(entry, URLPattern):
            route = prefix + str(entry.pattern).lstrip("/")
            yield entry.name or "", route
        elif isinstance(entry, URLResolver):
            nested_prefix = prefix + str(entry.pattern).lstrip("/")
            yield from _iter_concrete_urls(entry, prefix=nested_prefix)


def _has_unresolved_kwargs(route: str) -> bool:
    """Skip URLs needing kwargs — the fixtures layer (v0.2) will generate them."""
    return bool(_KWARG_PATTERN.search(route))


def _is_skipped(url_name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(url_name, pat) for pat in patterns)


def _build_clients(roles: list[str]) -> dict[str, Client]:
    User = get_user_model()
    clients: dict[str, Client] = {}

    if "anonymous" in roles:
        clients["anonymous"] = Client()

    # Creating real users requires a writable DB — which we have inside a
    # test/transactional context. Callers running doctor from `./manage.py`
    # should make sure to point at a dev DB, not prod.
    if "authenticated" in roles:
        user, _ = User.objects.get_or_create(
            username="doctor_user",
            defaults={"email": "doctor@example.com", "is_staff": False},
        )
        client = Client()
        client.force_login(user)
        clients["authenticated"] = client

    if "staff" in roles:
        staff, _ = User.objects.get_or_create(
            username="doctor_staff",
            defaults={"email": "doctor-staff@example.com", "is_staff": True},
        )
        client = Client()
        client.force_login(staff)
        clients["staff"] = client

    if "superuser" in roles:
        su, created = User.objects.get_or_create(
            username="doctor_superuser",
            defaults={"email": "doctor-su@example.com", "is_staff": True, "is_superuser": True},
        )
        if created:
            su.is_superuser = True
            su.is_staff = True
            su.save(update_fields=["is_superuser", "is_staff"])
        client = Client()
        client.force_login(su)
        clients["superuser"] = client

    return clients
