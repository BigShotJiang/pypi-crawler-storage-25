"""The `./manage.py doctor` entry point."""

from __future__ import annotations

import fnmatch
import sys

from django.core.management.base import BaseCommand

from ...config import load_config
from ...finding import Finding, Severity
from ...registry import Check, Project, discover_checks
from ...report import Reporter, to_json


class Command(BaseCommand):
    help = "Run django-doctor — 360° health check for the project."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--section",
            help="Comma-separated check IDs to run (default: all enabled in config).",
        )
        parser.add_argument(
            "--quick",
            action="store_true",
            help="Skip checks marked as slow.",
        )
        parser.add_argument(
            "--ci",
            action="store_true",
            help="Exit with non-zero status when findings match fail_on severities.",
        )
        parser.add_argument(
            "--json",
            action="store_true",
            help="Emit JSON instead of a rich terminal report.",
        )

    def handle(self, *args, **options) -> None:
        config = load_config()
        project = Project(config=config)

        checks = _select_checks(
            discover_checks(),
            enabled=config.get("enabled", ["*"]),
            disabled=config.get("disabled", []),
            requested=options.get("section"),
            quick=options.get("quick", False),
        )

        results: list[tuple[Check, Finding]] = []
        ignore_patterns = config.get("ignore", [])
        for CheckCls in checks:
            instance = CheckCls()
            try:
                for finding in instance.run(project) or ():
                    if _is_ignored(finding, ignore_patterns):
                        continue
                    results.append((instance, finding))
            except Exception as exc:  # noqa: BLE001
                results.append(
                    (
                        instance,
                        Finding(
                            severity=Severity.CRITICAL,
                            check_id=instance.id,
                            rule=f"{instance.id}.internal_error",
                            message=f"Check crashed: {type(exc).__name__}: {exc}",
                            fix_hint="This is a bug in the check itself or a project import.",
                        ),
                    )
                )

        if options.get("json"):
            self.stdout.write(to_json(results))
        else:
            Reporter().render(results)

        if options.get("ci"):
            fail_on = {Severity.from_string(s) for s in config.get("fail_on", [])}
            if any(f.severity in fail_on for _, f in results):
                sys.exit(1)


def _select_checks(
    checks: list[type[Check]],
    *,
    enabled: list[str],
    disabled: list[str],
    requested: str | None,
    quick: bool,
) -> list[type[Check]]:
    requested_ids = (
        {s.strip() for s in requested.split(",") if s.strip()} if requested else None
    )
    selected: list[type[Check]] = []
    for cls in checks:
        if requested_ids is not None and cls.id not in requested_ids:
            continue
        if any(fnmatch.fnmatch(cls.id, pat) for pat in disabled):
            continue
        if "*" not in enabled and not any(fnmatch.fnmatch(cls.id, pat) for pat in enabled):
            continue
        if quick and cls.slow:
            continue
        selected.append(cls)
    return selected


def _is_ignored(finding: Finding, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(finding.ignore_key, pat) for pat in patterns)
