from django.http import HttpResponse
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView

from .forms import GoodForm
from .models import Widget


def healthy(request):
    return HttpResponse("ok")


def boom(request):
    raise RuntimeError("intentional 500 for the URL smoke check")


def needs_login(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=302)
    return HttpResponse("ok")


class WidgetCreateView(CreateView):
    """Healthy CBV — post_smoke should NOT flag it."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"


class BadSaveCreateView(CreateView):
    """CBV whose save() crashes — post_smoke must flag it as critical."""

    model = Widget
    form_class = GoodForm
    template_name = "widget_form.html"
    success_url = "/healthy/"

    def form_valid(self, form):
        # Mimics the hikimatech bug: the view itself is fine but a call
        # downstream (post_save signal, related create, …) raises.
        raise RuntimeError("intentional failure inside form_valid")
