from django.db import models


class Widget(models.Model):
    """Intentionally simple — stands in for a project model in the suite."""

    name = models.CharField(max_length=100)
    # fonction = a free-form CharField that stores a code (no `choices=`).
    # This mirrors Contact.fonction in Altiusone and lets us reproduce the
    # production bug that motivated django-doctor in the first place.
    fonction = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.name


class SilentWidget(models.Model):
    """Missing custom __str__ and Meta.ordering — regression fixture for the
    ``models`` check. Do not add __str__ to this model."""

    name = models.CharField(max_length=100)


class DangerousFK(models.Model):
    """FK with on_delete=SET_NULL but null=False — prod IntegrityError waiting
    to happen. Regression fixture for the ``models`` check."""

    parent = models.ForeignKey(
        Widget, on_delete=models.SET_NULL, null=False, related_name="dangerous"
    )

    def __str__(self) -> str:
        return f"DangerousFK #{self.pk}"

    class Meta:
        ordering = ("pk",)
