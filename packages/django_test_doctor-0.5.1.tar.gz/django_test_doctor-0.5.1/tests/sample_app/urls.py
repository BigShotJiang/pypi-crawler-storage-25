from django.urls import path

from . import views

urlpatterns = [
    path("healthy/", views.healthy, name="healthy"),
    path("boom/", views.boom, name="boom"),
    path("needs-login/", views.needs_login, name="needs-login"),
    # CBVs used by the post_smoke check.
    path("widgets/new/", views.WidgetCreateView.as_view(), name="widget-create"),
    path("widgets/bad/", views.BadSaveCreateView.as_view(), name="widget-bad-create"),
]
