"""Session key constants for auth-related session data."""

SESSION_USER_ID = "user_id"
SESSION_USER_NAME = "user_name"
SESSION_USER_EMAIL = "user_email"
SESSION_USER_PICTURE_URL = "user_picture_url"
SESSION_AUTH_NEXT = "auth_next"
SESSION_OAUTH_STATE = "oauth_state"
SESSION_OAUTH_PROVIDER = "oauth_provider"
SESSION_OAUTH_CODE_VERIFIER = "oauth_code_verifier"
SESSION_PENDING_AUTH_ID = "pending_auth_id"
SESSION_PENDING_AUTH_USER_ID = "pending_auth_user_id"
SESSION_PENDING_AUTH_METHOD = "pending_auth_method"
SESSION_PENDING_AUTH_METHOD_TYPE = "pending_auth_method_type"
SESSION_PENDING_AUTH_STAGE = "pending_auth_stage"
SESSION_PENDING_AUTH_SUBJECT_ID = "pending_auth_subject_id"
SESSION_PENDING_AUTH_EMAIL = "pending_auth_email"
SESSION_PENDING_AUTH_NAME = "pending_auth_name"
SESSION_PENDING_AUTH_EXPIRES_AT = "pending_auth_expires_at"
SESSION_PENDING_AUTH_IS_NEW_USER = "pending_auth_is_new_user"
SESSION_PASSKEY_REGISTRATION_CHALLENGE = "passkey_registration_challenge"
SESSION_PASSKEY_REGISTRATION_USER_ID = "passkey_registration_user_id"
SESSION_PASSKEY_AUTHENTICATION_CHALLENGE = "passkey_authentication_challenge"
SESSION_PASSKEY_AUTHENTICATION_USER_ID = "passkey_authentication_user_id"
SESSION_PASSKEY_AUTHENTICATION_PENDING_AUTH_ID = "passkey_authentication_pending_auth_id"
SESSION_PASSKEY_PRIMARY_AUTH_CHALLENGE = "passkey_primary_auth_challenge"
SESSION_PASSKEY_PRIMARY_AUTH_METHOD = "passkey_primary_auth_method"
SESSION_PASSKEY_PRIMARY_REGISTRATION_CHALLENGE = "passkey_primary_registration_challenge"
SESSION_PASSKEY_PRIMARY_REGISTRATION_METHOD = "passkey_primary_registration_method"
SESSION_PASSKEY_PRIMARY_REGISTRATION_EMAIL = "passkey_primary_registration_email"
SESSION_PASSKEY_PRIMARY_REGISTRATION_NAME = "passkey_primary_registration_name"
SESSION_PASSKEY_PRIMARY_REGISTRATION_USER_HANDLE = "passkey_primary_registration_user_handle"

# Passkey challenge expiry (M4) — stamped by each begin_*, checked by each
# complete_* to reject stale challenges independent of the overall session
# lifetime.
SESSION_PASSKEY_REGISTRATION_EXPIRES_AT = "passkey_registration_expires_at"
SESSION_PASSKEY_AUTHENTICATION_EXPIRES_AT = "passkey_authentication_expires_at"
SESSION_PASSKEY_PRIMARY_AUTH_EXPIRES_AT = "passkey_primary_auth_expires_at"
SESSION_PASSKEY_PRIMARY_REGISTRATION_EXPIRES_AT = "passkey_primary_registration_expires_at"

# Rolling idle-timeout stamp (M7) — stamped at login, refreshed by
# SessionIdleMiddleware on activity, checked on every authenticated
# request.
SESSION_IDLE_LAST_SEEN = "idle_last_seen"

# Deferred OAuth account linking — set while the user awaits an email-link
# challenge to prove control of an existing account's email address.
SESSION_PENDING_LINK_METADATA = "pending_link_metadata"
SESSION_PENDING_LINK_TOKENS = "pending_link_tokens"
SESSION_PENDING_LINK_EMAIL = "pending_link_email"
