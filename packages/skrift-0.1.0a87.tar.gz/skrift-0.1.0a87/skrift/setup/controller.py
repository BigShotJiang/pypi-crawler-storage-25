"""Setup wizard controller for first-time Skrift configuration."""

import asyncio
import base64
import hashlib
import json
import logging
import os
import secrets
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

from typing import Annotated

from litestar import Controller, Request, get, post
from litestar.exceptions import HTTPException
from litestar.params import Parameter
from litestar.response import File, Redirect, Response, Template as TemplateResponse
from litestar.response.sse import ServerSentEvent
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from skrift.auth.session_service import finalize_authenticated_session
from skrift.auth.second_factors.passkey_service import (
    PasskeyRuntimeUnavailableError,
    PasskeyStateError,
    PasskeyVerificationError,
    begin_primary_passkey_registration,
    complete_primary_passkey_registration,
    get_primary_passkey_registration_state,
)
from skrift.auth.second_factors.services import save_passkey_enrollment
from skrift.config import get_auth_method_configs, get_auth_provider_configs
from skrift.db.models.role import Role, user_roles
from skrift.db.models.user import User
from skrift.db.services import setting_service
from skrift.db.services.setting_service import (
    SETUP_COMPLETED_AT_KEY,
    get_setting,
)
from skrift.setup.config_writer import (
    load_config,
    update_auth_config,
    update_database_config,
)
from skrift.forms import verify_csrf
from skrift.forms.core import CSRF_SESSION_KEY
from skrift.setup.providers import DUMMY_PROVIDER_KEY, OAUTH_PROVIDERS, get_all_providers, get_provider_info
from skrift.setup.state import (
    can_connect_to_database,
    can_connect_to_database_url,
    create_setup_engine,
    get_database_url_from_yaml,
    get_first_incomplete_step,
    is_auth_configured,
    is_site_configured,
    is_theme_configured,
    run_migrations_if_needed,
    reset_migrations_flag,
)


@asynccontextmanager
async def get_setup_db_session():
    """Create a database session for setup operations.

    This is used during setup when the SQLAlchemy plugin isn't available.
    """
    db_url = get_database_url_from_yaml()
    if not db_url:
        raise RuntimeError("Database not configured")

    engine = create_setup_engine(db_url)
    async_session = async_sessionmaker(engine, expire_on_commit=False)

    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await engine.dispose()


def _resolve_env_var(value: str) -> str:
    """Resolve environment variable reference if value starts with $."""
    if value.startswith("$"):
        return os.environ.get(value[1:], "")
    return value


def _get_provider_type(key: str, config: dict) -> str:
    """Resolve provider type from raw config dict, falling back to key."""
    return config.get("provider", "") or key


def _get_method_type(key: str, config: dict) -> str:
    """Resolve auth method type from raw config dict, falling back to oauth."""
    return config.get("type", "") or ("dummy" if key == DUMMY_PROVIDER_KEY else "oauth")


def _detect_request_base_url(request: Request) -> str:
    """Infer the current request's base URL."""
    scheme = request.headers.get("x-forwarded-proto", request.url.scheme)
    host = request.headers.get("host", request.url.netloc)
    return f"{scheme}://{host}"


def _get_setup_redirect_base_url(request: Request) -> str:
    """Return the configured setup OAuth base URL, falling back to the request."""
    config = load_config()
    configured = str(config.get("auth", {}).get("redirect_base_url", "")).strip()
    return configured or _detect_request_base_url(request)


def _store_setup_error(request: Request, user_message: str) -> None:
    """Store a user-safe setup error in the session."""
    request.session["setup_error"] = user_message


def _build_candidate_database_url(form_data: dict) -> tuple[dict, str]:
    """Build config write args plus a concrete database URL for validation."""
    db_type = str(form_data.get("db_type", "sqlite"))

    if db_type == "sqlite":
        file_path = str(form_data.get("sqlite_path", "./app.db")).strip() or "./app.db"
        use_env = form_data.get("sqlite_path_env") == "on"
        if use_env:
            resolved_path = os.environ.get(file_path)
            if not resolved_path:
                raise ValueError(f"Environment variable {file_path} is not set")
            return (
                {
                    "db_type": "sqlite",
                    "url": file_path,
                    "use_env_vars": {"url": True},
                },
                f"sqlite+aiosqlite:///{resolved_path}",
            )

        return (
            {
                "db_type": "sqlite",
                "url": file_path,
                "use_env_vars": {"url": False},
            },
            f"sqlite+aiosqlite:///{file_path}",
        )

    use_env_url = form_data.get("pg_url_env") == "on"
    if use_env_url:
        env_var = str(form_data.get("pg_url_envvar", "DATABASE_URL")).strip() or "DATABASE_URL"
        resolved_url = os.environ.get(env_var)
        if not resolved_url:
            raise ValueError(f"Environment variable {env_var} is not set")
        return (
            {
                "db_type": "postgresql",
                "url": env_var,
                "use_env_vars": {"url": True},
            },
            resolved_url,
        )

    host = str(form_data.get("pg_host", "localhost")).strip() or "localhost"
    port = int(form_data.get("pg_port", 5432))
    database = str(form_data.get("pg_database", "skrift")).strip() or "skrift"
    username = str(form_data.get("pg_username", "postgres")).strip() or "postgres"
    password = str(form_data.get("pg_password", ""))

    candidate_url = (
        f"postgresql+asyncpg://{username}:{password}@{host}:{port}/{database}"
    )
    return (
        {
            "db_type": "postgresql",
            "host": host,
            "port": port,
            "database": database,
            "username": username,
            "password": password,
        },
        candidate_url,
    )


def _get_previous_setup_step_path() -> str:
    """Return the previous step before admin creation."""
    return "/setup/theme" if _has_themes() else "/setup/site"


def _has_themes() -> bool:
    """Check if themes are available for the setup wizard."""
    from skrift.lib.theme import themes_available
    return themes_available()


def _total_steps() -> int:
    """Return total number of setup steps (5 with themes, 4 without)."""
    return 5 if _has_themes() else 4


def _admin_step_number() -> int:
    """Return the step number for the admin step."""
    return 5 if _has_themes() else 4


def _theme_step_number() -> int:
    """Return the step number for the theme step (only valid when themes exist)."""
    return 4


async def _finalize_admin_setup(
    db_session: AsyncSession, request: Request, user
) -> None:
    """Sync roles, assign admin role, mark setup complete, and populate session.

    Shared between dummy-login and OAuth callback admin creation flows.
    """
    from skrift.auth import sync_roles_to_database

    await sync_roles_to_database(db_session)

    admin_role = await db_session.scalar(select(Role).where(Role.name == "admin"))
    if admin_role:
        existing = await db_session.execute(
            select(user_roles).where(
                user_roles.c.user_id == user.id,
                user_roles.c.role_id == admin_role.id,
            )
        )
        if not existing.first():
            await db_session.execute(
                user_roles.insert().values(user_id=user.id, role_id=admin_role.id)
            )

    timestamp = datetime.now(UTC).isoformat()
    await setting_service.set_setting(db_session, SETUP_COMPLETED_AT_KEY, timestamp)

    finalize_authenticated_session(request, user)
    request.session["flash"] = "Admin account created successfully!"
    request.session["setup_just_completed"] = True


async def _create_setup_passkey_admin(
    db_session: AsyncSession,
    *,
    method_key: str,
    factor_key: str,
    email: str,
    name: str | None,
    registration_result,
):
    """Create the initial admin user and bind a passkey during setup."""
    existing = await db_session.execute(select(User).where(User.email == email))
    if existing.scalar_one_or_none() is not None:
        raise ValueError("An account with that email already exists")

    user = User(
        email=email,
        name=name,
        picture_url=None,
        last_login_at=datetime.now(UTC),
    )
    db_session.add(user)
    await db_session.flush()

    await save_passkey_enrollment(
        db_session,
        user_id=str(user.id),
        factor_key=factor_key,
        display_name=name,
        credential_id=registration_result.credential_id,
        public_key=registration_result.public_key,
        sign_count=registration_result.sign_count,
        transports=registration_result.transports,
        enrollment_metadata=registration_result.enrollment_metadata,
    )
    return user


class SetupController(Controller):
    """Controller for the setup wizard."""

    path = "/setup"

    async def _check_already_complete(self) -> bool:
        """Defense in depth: check if setup is already complete."""
        try:
            async with get_setup_db_session() as db_session:
                value = await get_setting(db_session, SETUP_COMPLETED_AT_KEY)
                return value is not None
        except Exception:
            logger.exception("Setup completion check failed")
            return False

    @get("/")
    async def index(self, request: Request) -> Redirect:
        """Redirect to welcome page to begin setup."""
        return Redirect(path="/setup/welcome")

    @get("/welcome")
    async def welcome_step(self, request: Request) -> TemplateResponse:
        """Welcome page shown before setup begins."""
        return TemplateResponse("setup/welcome.html")

    @get("/database")
    async def database_step(self, request: Request) -> TemplateResponse | Redirect:
        """Step 1: Database configuration."""
        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)

        # If database is already configured and no errors, go to configuring page
        can_connect, _ = await can_connect_to_database()
        if can_connect and not error:
            return Redirect(path="/setup/configuring")

        # Load current config if exists
        config = load_config()
        db_config = config.get("db", {})
        current_url = db_config.get("url", "")

        # Determine current type
        db_type = "sqlite"
        if "postgresql" in current_url:
            db_type = "postgresql"

        return TemplateResponse(
            "setup/database.html",
            context={
                "flash": flash,
                "error": error,
                "step": 1,
                "total_steps": _total_steps(),
                "db_type": db_type,
                "current_url": current_url,
            },
        )

    @post("/database")
    async def save_database(self, request: Request) -> Redirect:
        """Save database configuration."""
        form_data = await request.form()

        try:
            update_kwargs, candidate_url = _build_candidate_database_url(form_data)

            # Test connection
            can_connect, error = await can_connect_to_database_url(candidate_url)
            if not can_connect:
                logger.warning("Setup database: connection test failed: %s", error)
                _store_setup_error(request, f"Connection failed: {error}")
                return Redirect(path="/setup/database")

            update_database_config(**update_kwargs)

            # Connection successful - redirect to configuring page to run migrations
            request.session["setup_wizard_step"] = "configuring"
            return Redirect(path="/setup/configuring")

        except ValueError as exc:
            _store_setup_error(request, str(exc))
            return Redirect(path="/setup/database")
        except Exception as e:
            logger.exception("Setup database: unexpected error saving config")
            _store_setup_error(
                request,
                "Could not save database settings. Check the server logs and try again.",
            )
            return Redirect(path="/setup/database")

    @get("/restart")
    async def restart_step(self, request: Request) -> Redirect:
        """Legacy restart route - now redirects to auth since restart is no longer required."""
        request.session["setup_wizard_step"] = "auth"
        return Redirect(path="/setup/auth")

    @get("/configuring")
    async def configuring_step(self, request: Request) -> TemplateResponse | Redirect:
        """Database configuration in progress page.

        Shows a loading spinner while migrations run via SSE.
        """
        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)

        # Verify we can connect to the database first
        can_connect, connection_error = await can_connect_to_database()
        if not can_connect:
            request.session["setup_error"] = f"Cannot connect to database: {connection_error}"
            return Redirect(path="/setup/database")

        # Reset migrations flag so they run fresh via SSE
        reset_migrations_flag()

        return TemplateResponse(
            "setup/configuring.html",
            context={
                "flash": flash,
                "error": error,
                "step": 1,
                "total_steps": _total_steps(),
            },
        )

    @get("/configuring/status")
    async def configuring_status(self, request: Request) -> ServerSentEvent:
        """SSE endpoint for database configuration status.

        Streams migration progress and completion status.
        """
        async def generate_status() -> AsyncGenerator[str, None]:
            # Send initial status
            yield json.dumps({
                "status": "running",
                "message": "Testing database connection...",
                "detail": "",
            })

            await asyncio.sleep(0.5)

            # Test connection
            can_connect, connection_error = await can_connect_to_database()
            if not can_connect:
                logger.error("Setup configuring: database connection failed: %s", connection_error)
                yield json.dumps({
                    "status": "error",
                    "message": f"Database connection failed: {connection_error}",
                })
                return

            yield json.dumps({
                "status": "running",
                "message": "Running database migrations...",
                "detail": "This may take a moment",
            })

            await asyncio.sleep(0.3)

            # Run migrations
            success, error = run_migrations_if_needed()

            if not success:
                logger.error("Setup configuring: migration failed: %s", error)
                yield json.dumps({
                    "status": "error",
                    "message": f"Migration failed: {error}",
                })
                return

            yield json.dumps({
                "status": "running",
                "message": "Verifying database schema...",
                "detail": "",
            })

            await asyncio.sleep(0.3)

            # Determine next step
            next_setup_step = await get_first_incomplete_step()
            next_step = next_setup_step.value

            # All done - include next step
            yield json.dumps({
                "status": "complete",
                "message": "Database configured successfully!",
                "next_step": next_step,
            })

        return ServerSentEvent(generate_status())

    @get("/auth")
    async def auth_step(self, request: Request) -> TemplateResponse | Redirect:
        """Step 2: Authentication providers."""
        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)

        # If auth is already configured and no errors, skip to next step
        if is_auth_configured() and not error:
            next_step = await get_first_incomplete_step()
            if next_step.value != "auth":
                request.session["setup_wizard_step"] = next_step.value
                return Redirect(path=f"/setup/{next_step.value}")

        # Get configured auth methods
        config = load_config()
        auth_config = config.get("auth", {})
        configured_methods = get_auth_method_configs(auth_config)
        redirect_base_url = str(auth_config.get("redirect_base_url", "")).strip() or _detect_request_base_url(request)

        # The setup UI bundles all built-in primary auth methods.
        all_methods = get_all_providers()

        return TemplateResponse(
            "setup/auth.html",
            context={
                "flash": flash,
                "error": error,
                "step": 2,
                "total_steps": _total_steps(),
                "redirect_base_url": redirect_base_url,
                "methods": all_methods,
                "configured_methods": configured_methods,
            },
        )

    @post("/auth")
    async def save_auth(self, request: Request) -> Redirect:
        """Save authentication configuration."""
        form_data = await request.form()

        # Get redirect base URL
        redirect_base_url = form_data.get("redirect_base_url", "http://localhost:8000")

        # Parse auth method configurations
        all_methods = get_all_providers()
        methods = {}
        use_env_vars = {}

        for method_key in all_methods.keys():
            enabled = form_data.get(f"{method_key}_enabled") == "on"
            if not enabled:
                continue

            method_info = all_methods[method_key]
            method_type = getattr(method_info, "auth_method_type", "oauth")
            if not isinstance(method_type, str):
                method_type = "oauth"
            method_config = {"type": method_type}
            method_env_vars = {}

            for field in method_info.fields:
                field_key = field["key"]
                value = form_data.get(f"{method_key}_{field_key}", "")
                use_env = form_data.get(f"{method_key}_{field_key}_env") == "on"

                if value or not field.get("optional"):
                    method_config[field_key] = value
                    method_env_vars[field_key] = use_env

            if method_config.get("type") == "passkey":
                method_config["factor_key"] = method_config.get("factor_key", "") or method_key

            if method_config:
                methods[method_key] = method_config
                use_env_vars[method_key] = method_env_vars

        if not methods:
            _store_setup_error(
                request, "Please configure at least one authentication method"
            )
            return Redirect(path="/setup/auth")

        try:
            update_auth_config(
                redirect_base_url=redirect_base_url,
                methods=methods,
                use_env_vars=use_env_vars,
            )

            # Determine next step using smart detection
            next_step = await get_first_incomplete_step()
            request.session["setup_wizard_step"] = next_step.value
            request.session["flash"] = "Authentication configured successfully!"
            return Redirect(path=f"/setup/{next_step.value}")

        except Exception as e:
            logger.exception("Setup auth: unexpected error saving configuration")
            _store_setup_error(
                request,
                "Could not save authentication settings. Check the server logs and try again.",
            )
            return Redirect(path="/setup/auth")

    @get("/site")
    async def site_step(self, request: Request) -> TemplateResponse | Redirect:
        """Step 3: Site settings."""
        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)

        # If site is already configured and no errors, skip to next step
        if await is_site_configured() and not error:
            next_step = await get_first_incomplete_step()
            if next_step.value != "site":
                request.session["setup_wizard_step"] = next_step.value
                return Redirect(path=f"/setup/{next_step.value}")

        return TemplateResponse(
            "setup/site.html",
            context={
                "flash": flash,
                "error": error,
                "step": 3,
                "total_steps": _total_steps(),
                "settings": {
                    "site_name": "",
                    "site_tagline": "",
                    "site_copyright_holder": "",
                    "site_copyright_start_year": datetime.now().year,
                },
            },
        )

    @post("/site")
    async def save_site(self, request: Request) -> Redirect:
        """Save site settings."""
        form_data = await request.form()

        try:
            site_name = form_data.get("site_name", "").strip()
            if not site_name:
                _store_setup_error(request, "Site name is required")
                return Redirect(path="/setup/site")

            site_tagline = form_data.get("site_tagline", "").strip()
            site_copyright_holder = form_data.get("site_copyright_holder", "").strip()
            site_copyright_start_year = form_data.get("site_copyright_start_year", "").strip()

            # Save settings to database using manual session
            async with get_setup_db_session() as db_session:
                await setting_service.set_setting(
                    db_session, setting_service.SITE_NAME_KEY, site_name
                )
                await setting_service.set_setting(
                    db_session, setting_service.SITE_TAGLINE_KEY, site_tagline
                )
                await setting_service.set_setting(
                    db_session, setting_service.SITE_COPYRIGHT_HOLDER_KEY, site_copyright_holder
                )
                await setting_service.set_setting(
                    db_session,
                    setting_service.SITE_COPYRIGHT_START_YEAR_KEY,
                    site_copyright_start_year,
                )

                # Handle optional favicon upload
                favicon_file = form_data.get("favicon")
                if favicon_file and hasattr(favicon_file, "read"):
                    content = await favicon_file.read()
                    if content:
                        from skrift.config import get_settings as get_app_settings
                        from skrift.lib.storage import StorageManager
                        from skrift.db.services.asset_service import upload_asset

                        app_settings = get_app_settings()
                        storage = StorageManager(app_settings.storage)
                        try:
                            asset = await upload_asset(
                                db_session,
                                storage,
                                filename=favicon_file.filename or "favicon",
                                data=content,
                                content_type=favicon_file.content_type or "image/png",
                            )
                            await setting_service.set_setting(
                                db_session, setting_service.SITE_FAVICON_KEY, asset.key
                            )
                        finally:
                            await storage.close()

                # Reload cache
                await setting_service.load_site_settings_cache(db_session)

            # Determine next step using smart detection - should be admin at this point
            next_step = await get_first_incomplete_step()
            request.session["setup_wizard_step"] = next_step.value
            request.session["flash"] = "Site settings saved!"
            return Redirect(path=f"/setup/{next_step.value}")

        except Exception as e:
            logger.exception("Setup site: unexpected error saving settings")
            _store_setup_error(
                request,
                "Could not save site settings. Check the server logs and try again.",
            )
            return Redirect(path="/setup/site")

    @get("/theme")
    async def theme_step(self, request: Request) -> TemplateResponse | Redirect:
        """Step 4: Theme selection (only when themes are available)."""
        from skrift.lib.theme import themes_available, discover_themes

        if not themes_available():
            return Redirect(path="/setup/admin")

        # If theme is already configured and no errors, skip
        if await is_theme_configured() and not request.session.get("setup_error"):
            next_step = await get_first_incomplete_step()
            if next_step.value != "theme":
                request.session["setup_wizard_step"] = next_step.value
                return Redirect(path=f"/setup/{next_step.value}")

        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)
        themes = discover_themes()

        return TemplateResponse(
            "setup/theme.html",
            context={
                "flash": flash,
                "error": error,
                "step": _theme_step_number(),
                "total_steps": _total_steps(),
                "themes": themes,
            },
        )

    @post("/theme")
    async def save_theme(self, request: Request) -> Redirect:
        """Save theme selection."""
        from skrift.lib.theme import get_theme_info

        form_data = await request.form()
        site_theme = form_data.get("site_theme", "").strip()

        # Validate: if non-empty, must be a valid theme
        if site_theme and not get_theme_info(site_theme):
            _store_setup_error(request, f"Unknown theme: {site_theme}")
            return Redirect(path="/setup/theme")

        try:
            async with get_setup_db_session() as db_session:
                await setting_service.set_setting(
                    db_session, setting_service.SITE_THEME_KEY, site_theme
                )
                await setting_service.load_site_settings_cache(db_session)

            next_step = await get_first_incomplete_step()
            request.session["setup_wizard_step"] = next_step.value
            request.session["flash"] = "Theme saved!"
            return Redirect(path=f"/setup/{next_step.value}")

        except Exception as e:
            logger.exception("Setup theme: unexpected error saving selection")
            _store_setup_error(
                request,
                "Could not save theme settings. Check the server logs and try again.",
            )
            return Redirect(path="/setup/theme")

    @get("/theme-screenshot/{name:str}")
    async def theme_screenshot(self, request: Request, name: str) -> "File":
        """Serve a theme's screenshot image."""
        from litestar.response import File
        from skrift.lib.theme import get_theme_info

        info = get_theme_info(name)
        if not info or not info.screenshot:
            raise HTTPException(status_code=404, detail="Screenshot not found")

        return File(path=info.screenshot, media_type="image/png")

    @get("/admin")
    async def admin_step(self, request: Request) -> TemplateResponse:
        """Admin account creation step."""
        flash = request.session.pop("flash", None)
        error = request.session.pop("setup_error", None)

        if not error:
            next_step = await get_first_incomplete_step()
            if next_step.value not in {"admin", "complete"}:
                request.session["setup_wizard_step"] = next_step.value
                return Redirect(path=f"/setup/{next_step.value}")

        # Get configured providers
        config = load_config()
        auth_config = config.get("auth", {})
        configured_methods = get_auth_method_configs(auth_config)

        method_info = {}
        for key, method_config in configured_methods.items():
            method_type = _get_method_type(key, method_config)
            if method_type == "oauth":
                provider_type = _get_provider_type(key, method_config)
                info = OAUTH_PROVIDERS.get(provider_type)
            else:
                info = OAUTH_PROVIDERS.get(method_type)
            if info:
                method_info[key] = info

        return TemplateResponse(
            "setup/admin.html",
            context={
                "flash": flash,
                "error": error,
                "step": _admin_step_number(),
                "total_steps": _total_steps(),
                "methods": method_info,
                "configured_methods": list(configured_methods.keys()),
                "previous_step_path": _get_previous_setup_step_path(),
            },
        )

    @get("/oauth/{provider:str}/login")
    async def setup_oauth_login(self, request: Request, provider: str) -> Redirect | TemplateResponse:
        """Redirect to OAuth provider for setup admin creation."""
        config = load_config()
        auth_config = config.get("auth", {})
        methods_config = get_auth_method_configs(auth_config)
        providers_config = get_auth_provider_configs(auth_config)

        if provider not in methods_config and provider not in providers_config:
            raise HTTPException(status_code=404, detail=f"Provider {provider} not configured")

        method_config = methods_config.get(provider, {})
        if _get_method_type(provider, method_config) == "passkey":
            flash = request.session.pop("flash", None)
            return TemplateResponse(
                "setup/passkey_login.html",
                context={
                    "flash": flash,
                    "step": _admin_step_number(),
                    "total_steps": _total_steps(),
                    "previous_step_path": _get_previous_setup_step_path(),
                    "provider": provider,
                },
            )

        provider_type = _get_provider_type(provider, providers_config.get(provider, {}))
        provider_info = get_provider_info(provider_type)
        if not provider_info:
            raise HTTPException(status_code=404, detail=f"Unknown provider: {provider}")

        # Dummy provider uses a local form instead of OAuth redirect
        if provider == DUMMY_PROVIDER_KEY:
            flash = request.session.pop("flash", None)
            return TemplateResponse(
                "setup/dummy_login.html",
                context={
                    "flash": flash,
                    "step": _admin_step_number(),
                    "total_steps": _total_steps(),
                    "previous_step_path": _get_previous_setup_step_path(),
                },
            )

        provider_config = providers_config[provider]
        client_id = _resolve_env_var(provider_config.get("client_id", ""))

        # Generate CSRF state token
        state = secrets.token_urlsafe(32)
        request.session["oauth_state"] = state
        request.session["oauth_provider"] = provider
        request.session["oauth_setup"] = True

        # Build redirect URI
        redirect_uri = f"{_get_setup_redirect_base_url(request)}/auth/{provider}/callback"

        scopes = provider_config.get("scopes", provider_info.scopes)

        # Get the provider strategy for PKCE + auth params
        from skrift.auth.providers import get_oauth_provider
        oauth_provider = get_oauth_provider(provider, provider_type=provider_type)

        # Generate PKCE for providers that require it
        code_challenge = None
        if oauth_provider.requires_pkce:
            code_verifier = secrets.token_urlsafe(64)[:128]
            request.session["oauth_code_verifier"] = code_verifier
            code_challenge = base64.urlsafe_b64encode(
                hashlib.sha256(code_verifier.encode()).digest()
            ).decode().rstrip("=")

        # Resolve tenant
        tenant = provider_config.get("tenant_id", "common")
        if isinstance(tenant, str) and tenant.startswith("$"):
            tenant = _resolve_env_var(tenant) or "common"

        auth_url = oauth_provider.resolve_url(provider_info.auth_url, tenant)
        params = oauth_provider.build_auth_params(
            client_id=client_id,
            redirect_uri=redirect_uri,
            scopes=scopes,
            state=state,
            code_challenge=code_challenge,
        )

        return Redirect(path=f"{auth_url}?{urlencode(params)}")

    @post("/dummy-login")
    async def setup_dummy_login(self, request: Request) -> Redirect:
        """Process dummy login form during setup to create admin account."""
        config = load_config()
        auth_config = config.get("auth", {})
        providers_config = get_auth_provider_configs(auth_config)

        if DUMMY_PROVIDER_KEY not in providers_config:
            raise HTTPException(status_code=404, detail="Dummy provider not configured")

        form_data = await request.form()
        email = form_data.get("email", "").strip()
        name = form_data.get("name", "").strip()

        if not email:
            request.session["flash"] = "Email is required"
            return Redirect(path=f"/setup/oauth/{DUMMY_PROVIDER_KEY}/login")

        if not name:
            name = email.split("@")[0]

        oauth_id = f"dummy_{hashlib.sha256(email.encode()).hexdigest()[:16]}"
        dummy_metadata = {"id": oauth_id, "email": email, "name": name}

        from skrift.auth.providers import NormalizedUserData
        # Setup is a one-shot admin-creation flow guarded by `validate_no_dummy_auth_in_production`;
        # treat the email as verified so account creation doesn't route through
        # the email challenge (no mailer may be configured yet during setup).
        user_data = NormalizedUserData(
            oauth_id=oauth_id,
            email=email,
            name=name,
            picture_url=None,
            email_verified=True,
        )

        async with get_setup_db_session() as db_session:
            from skrift.auth.oauth_account_service import (
                LoginResult,
                find_or_create_oauth_user,
            )
            resolution = await find_or_create_oauth_user(
                db_session, DUMMY_PROVIDER_KEY, user_data, dummy_metadata
            )
            assert isinstance(resolution, LoginResult)
            await _finalize_admin_setup(db_session, request, resolution.user)

        return Redirect(path="/setup/complete")

    @post("/passkey/{provider:str}/options")
    async def setup_passkey_options(self, request: Request, provider: str) -> Response:
        """Return browser registration options for setup-time passkey admin creation."""
        config = load_config()
        auth_config = config.get("auth", {})
        methods = get_auth_method_configs(auth_config)
        method_config = methods.get(provider, {})
        if _get_method_type(provider, method_config) != "passkey":
            return Response(content={"error": "unsupported_method"}, status_code=400)
        if not await verify_csrf(request):
            return Response(content={"error": "invalid_csrf"}, status_code=400)

        form_data = await request.form()
        email = str(form_data.get("email", "")).strip().lower()
        name = str(form_data.get("name", "")).strip() or None
        if not email:
            return Response(content={"error": "email_required"}, status_code=400)

        class _SettingsAuth:
            redirect_base_url = _get_setup_redirect_base_url(request)

        class _Settings:
            domain = ""
            auth = _SettingsAuth()

        try:
            options = begin_primary_passkey_registration(
                request,
                _Settings(),
                method_key=provider,
                email=email,
                name=name,
            )
        except PasskeyRuntimeUnavailableError as exc:
            return Response(content={"error": str(exc)}, status_code=503)

        return Response(
            content={
                "options": options,
                "csrf_token": request.session.get(CSRF_SESSION_KEY, ""),
            }
        )

    @post("/passkey/{provider:str}/complete")
    async def setup_passkey_complete(
        self,
        request: Request,
        provider: str,
    ) -> Response:
        """Create the initial admin account from a passkey registration during setup."""
        config = load_config()
        auth_config = config.get("auth", {})
        methods = get_auth_method_configs(auth_config)
        method_config = methods.get(provider, {})
        if _get_method_type(provider, method_config) != "passkey":
            return Response(content={"error": "unsupported_method"}, status_code=400)
        if not await verify_csrf(request):
            return Response(content={"error": "invalid_csrf"}, status_code=400)

        signup_state = get_primary_passkey_registration_state(request)
        if signup_state is None or signup_state.method_key != provider:
            return Response(content={"error": "registration_state_missing"}, status_code=400)

        form_data = await request.form()
        credential_raw = str(form_data.get("credential", "")).strip()
        if not credential_raw:
            return Response(content={"error": "credential_required"}, status_code=400)

        try:
            credential = json.loads(credential_raw)
        except json.JSONDecodeError:
            return Response(content={"error": "invalid_credential"}, status_code=400)

        class _SettingsAuth:
            redirect_base_url = _get_setup_redirect_base_url(request)

        class _Settings:
            domain = ""
            auth = _SettingsAuth()

        try:
            registration = complete_primary_passkey_registration(
                request,
                _Settings(),
                method_key=provider,
                credential=credential,
            )
            factor_key = method_config.get("factor_key", "") or provider
            async with get_setup_db_session() as db_session:
                user = await _create_setup_passkey_admin(
                    db_session,
                    method_key=provider,
                    factor_key=factor_key,
                    email=signup_state.email,
                    name=signup_state.name,
                    registration_result=registration,
                )
                await _finalize_admin_setup(db_session, request, user)
        except PasskeyRuntimeUnavailableError as exc:
            return Response(content={"error": str(exc)}, status_code=503)
        except (PasskeyStateError, PasskeyVerificationError, ValueError) as exc:
            return Response(content={"error": str(exc)}, status_code=400)

        return Response(content={"ok": True, "redirect": "/setup/complete"}, status_code=201)

    @get("/complete")
    async def complete(self, request: Request) -> TemplateResponse | Redirect:
        """Setup complete page."""
        # Verify setup is actually complete in database
        if not await self._check_already_complete():
            return Redirect(path="/setup")

        # Clear the session flag if present
        request.session.pop("setup_just_completed", None)

        return TemplateResponse(
            "setup/complete.html",
            context={
                "step": _admin_step_number(),
                "total_steps": _total_steps(),
            },
        )


async def mark_setup_complete(db_session: AsyncSession | None = None) -> None:
    """Mark setup as complete by setting the timestamp.

    Args:
        db_session: Optional database session. If not provided, creates one.
    """
    timestamp = datetime.now(UTC).isoformat()
    if db_session:
        await setting_service.set_setting(db_session, SETUP_COMPLETED_AT_KEY, timestamp)
    else:
        async with get_setup_db_session() as session:
            await setting_service.set_setting(session, SETUP_COMPLETED_AT_KEY, timestamp)


class SetupAuthController(Controller):
    """Auth controller for setup OAuth callbacks.

    This handles OAuth callbacks at /auth/{provider}/callback during setup,
    matching the redirect URI configured in OAuth providers.
    """

    path = "/auth"

    @get("/{provider:str}/callback")
    async def setup_oauth_callback(
        self,
        request: Request,
        provider: str,
        code: str | None = None,
        oauth_state: Annotated[str | None, Parameter(query="state")] = None,
        error: str | None = None,
    ) -> Redirect:
        """Handle OAuth callback during setup."""
        if not request.session.get("oauth_setup"):
            raise HTTPException(status_code=400, detail="Invalid OAuth flow")

        if error:
            _store_setup_error(request, f"OAuth error: {error}")
            return Redirect(path="/setup/admin")

        # Verify CSRF state
        stored_state = request.session.pop("oauth_state", None)
        if not oauth_state or oauth_state != stored_state:
            raise HTTPException(status_code=400, detail="Invalid OAuth state")

        if not code:
            raise HTTPException(status_code=400, detail="Missing authorization code")

        config = load_config()
        auth_config = config.get("auth", {})
        providers_config = get_auth_provider_configs(auth_config)

        if provider not in providers_config:
            raise HTTPException(status_code=404, detail=f"Provider {provider} not configured")

        provider_config = providers_config[provider]
        client_id = _resolve_env_var(provider_config.get("client_id", ""))
        client_secret = _resolve_env_var(provider_config.get("client_secret", ""))

        # Build redirect URI
        redirect_uri = f"{_get_setup_redirect_base_url(request)}/auth/{provider}/callback"

        code_verifier = request.session.pop("oauth_code_verifier", None)

        # Resolve tenant for Microsoft
        tenant = provider_config.get("tenant_id", "common")
        if isinstance(tenant, str) and tenant.startswith("$"):
            tenant = _resolve_env_var(tenant) or "common"

        provider_type = _get_provider_type(provider, providers_config.get(provider, {}))

        from skrift.controllers.auth import _exchange_and_fetch
        try:
            user_data, user_info, tokens = await _exchange_and_fetch(
                provider,
                None,
                code,
                redirect_uri,
                code_verifier,
                client_id=client_id,
                client_secret=client_secret,
                tenant=tenant,
                provider_type=provider_type,
            )
        except HTTPException:
            raise
        except Exception:
            logger.exception("Setup OAuth callback failed for provider '%s'", provider)
            _store_setup_error(
                request,
                "Could not complete authentication. Check the server logs and try again.",
            )
            return Redirect(path="/setup/admin")

        # Create user and mark setup complete
        async with get_setup_db_session() as db_session:
            from skrift.auth.oauth_account_service import (
                EmailVerificationRequired,
                find_or_create_oauth_user,
            )
            resolution = await find_or_create_oauth_user(
                db_session, provider, user_data, user_info, tokens=tokens
            )
            if isinstance(resolution, EmailVerificationRequired):
                # Setup creates the first admin — there should be no existing
                # user to link against. If this fires, setup is likely being
                # re-run against a populated DB; surface a clear error rather
                # than silently falling back.
                _store_setup_error(
                    request,
                    "An account with that email already exists. Log in via the main login page instead.",
                )
                return Redirect(path="/setup/admin")
            await _finalize_admin_setup(db_session, request, resolution.user)

        # Clear setup flag
        request.session.pop("oauth_setup", None)

        return Redirect(path="/setup/complete")
