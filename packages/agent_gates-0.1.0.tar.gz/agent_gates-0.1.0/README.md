# Agent Gates

Quality gates for AI agent output validation.

A framework for validating AI agent outputs with configurable gates. Designed for Claude, GPT, and other LLM-based agents.

## Installation

```bash
pip install agent-gates
```

## Quick Start

```python
from agent_gates import GatePipeline

# Use a preset pipeline
pipeline = GatePipeline.from_preset("standard")
result = pipeline.check("This should work")

if not result.passed:
    print(result.to_markdown())
```

## Presets

| Preset | Description |
|--------|-------------|
| `strict` | All gates as blocking - no hedging, no apologies, no assumptions |
| `standard` | Common gates with sensible defaults |
| `minimal` | Only critical gates (hedging, unverified claims, credentials) |
| `code_review` | Focused on code quality (TODOs, debug prints, magic numbers) |

## Custom Gates

```python
from agent_gates import Gate, GatePipeline

# Create a custom gate
no_emoji = Gate(
    name="no_emoji",
    pattern=r"[\U0001F600-\U0001F64F]",
    action="warn",
    message="Response contains emoji",
    suggestion="Remove emoji for professional output"
)

# Build a custom pipeline
pipeline = GatePipeline("my_pipeline")
pipeline.add_gate(no_emoji)

# Or combine with a preset
pipeline = GatePipeline.from_preset("standard")
pipeline.add_gate(no_emoji)
```

## Gate Types

### Language Gates
- `HEDGING_GATE` - Blocks "should work", "might be", "probably"
- `APOLOGY_GATE` - Blocks "I apologize", "sorry for"
- `SYCOPHANCY_GATE` - Blocks "great question", "you're absolutely right"
- `ASSUMPTION_GATE` - Warns on "I'll assume", "let's assume"

### Verification Gates
- `UNVERIFIED_CLAIM_GATE` - Blocks claims without verification evidence

### Completeness Gates
- `TODO_GATE` - Blocks incomplete work marked as TODO
- `DEFERRAL_GATE` - Blocks "I'll do it later", "for now"

### Security Gates
- `CREDENTIAL_GATE` - Blocks exposed passwords, API keys, tokens

### Code Review Gates
- `MAGIC_NUMBER_GATE` - Info on large numeric literals
- `DEBUG_PRINT_GATE` - Warns on console.log, print()
- `COMMENTED_CODE_GATE` - Info on commented-out code

## API Reference

### Gate

```python
Gate(
    name: str,                    # Unique identifier
    pattern: str = None,          # Regex pattern (match = failure)
    check_fn: Callable = None,    # Custom function (True = failure)
    escape_pattern: str = None,   # Pattern that exempts from check
    action: str = "block",        # "block", "warn", or "info"
    message: str = "",            # Human-readable failure message
    suggestion: str = "",         # How to fix the issue
    category: str = "custom",     # Category for grouping
    enabled: bool = True          # Can be disabled dynamically
)
```

### GatePipeline

```python
pipeline = GatePipeline(name="my_pipeline")
pipeline.add_gate(gate)           # Add a gate
pipeline.remove_gate("name")      # Remove by name
pipeline.disable_gate("name")     # Disable temporarily
pipeline.enable_gate("name")      # Re-enable
result = pipeline.check(text)     # Run all gates
```

### GateResult

```python
result.passed          # bool - True if no blocking failures
result.failures        # list[GateFailure] - blocking issues
result.warnings        # list[GateFailure] - non-blocking issues
result.info            # list[GateFailure] - informational
result.to_markdown()   # Formatted output
result.to_dict()       # Serializable dict
```

## Utility Functions

```python
from agent_gates import quick_check, get_failures

# Boolean check
if quick_check(text, "standard"):
    print("Passed!")

# Get failure messages
failures = get_failures(text, "strict")
for msg in failures:
    print(msg)
```

## Serialization

Pipelines can be serialized for storage or configuration:

```python
# Save
config = pipeline.to_dict()
json.dump(config, open("pipeline.json", "w"))

# Load
config = json.load(open("pipeline.json"))
pipeline = GatePipeline.from_dict(config)
```

## License

MIT
