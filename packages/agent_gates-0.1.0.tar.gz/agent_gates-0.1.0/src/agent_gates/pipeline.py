"""
GatePipeline - Composable pipelines of quality gates.
"""

from typing import TYPE_CHECKING

from .gate import Gate, GateResult, check_gates

if TYPE_CHECKING:
    from .presets import PresetName


class GatePipeline:
    """
    A reusable pipeline of quality gates.

    Pipelines allow you to compose multiple gates and apply them
    as a unit. Gates can be enabled/disabled dynamically.

    Example:
        >>> from agent_gates import GatePipeline, Gate
        >>> pipeline = GatePipeline("my_pipeline")
        >>> pipeline.add_gate(Gate(name="no_bad", pattern=r"bad", message="Found bad"))
        >>> result = pipeline.check("This is bad")
        >>> result.passed
        False
    """

    def __init__(self, name: str, gates: list[Gate] = None):
        """
        Create a new pipeline.

        Args:
            name: Pipeline name for identification
            gates: Initial list of gates (optional)
        """
        self.name = name
        self.gates = gates or []

    def add_gate(self, gate: Gate) -> "GatePipeline":
        """
        Add a gate to the pipeline.

        Args:
            gate: Gate to add

        Returns:
            Self for method chaining
        """
        self.gates.append(gate)
        return self

    def remove_gate(self, name: str) -> "GatePipeline":
        """
        Remove a gate by name.

        Args:
            name: Name of gate to remove

        Returns:
            Self for method chaining
        """
        self.gates = [g for g in self.gates if g.name != name]
        return self

    def disable_gate(self, name: str) -> "GatePipeline":
        """
        Disable a gate by name (keeps it but skips during check).

        Args:
            name: Name of gate to disable

        Returns:
            Self for method chaining
        """
        for g in self.gates:
            if g.name == name:
                g.enabled = False
        return self

    def enable_gate(self, name: str) -> "GatePipeline":
        """
        Enable a previously disabled gate.

        Args:
            name: Name of gate to enable

        Returns:
            Self for method chaining
        """
        for g in self.gates:
            if g.name == name:
                g.enabled = True
        return self

    def check(self, text: str) -> GateResult:
        """
        Run all enabled gates on text.

        Args:
            text: Text to validate

        Returns:
            GateResult with pass/fail status and details
        """
        return check_gates(text, self.gates)

    @classmethod
    def from_preset(cls, preset: "PresetName") -> "GatePipeline":
        """
        Create a pipeline from a preset configuration.

        Available presets:
        - strict: All quality gates enabled as blocking
        - standard: Common gates, some as warnings
        - minimal: Only critical gates
        - code_review: Focused on code quality

        Args:
            preset: Preset name

        Returns:
            Configured GatePipeline

        Example:
            >>> pipeline = GatePipeline.from_preset("strict")
            >>> result = pipeline.check("This should work")
            >>> result.passed
            False
        """
        from .presets import get_preset_gates
        gates = get_preset_gates(preset)
        return cls(name=preset, gates=gates)

    def to_dict(self) -> dict:
        """
        Serialize pipeline to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            "name": self.name,
            "gates": [g.to_dict() for g in self.gates]
        }

    @classmethod
    def from_dict(cls, data: dict) -> "GatePipeline":
        """
        Deserialize pipeline from dictionary.

        Args:
            data: Dictionary with name and gates

        Returns:
            GatePipeline instance
        """
        gates = [Gate.from_dict(g) for g in data.get("gates", [])]
        return cls(name=data.get("name", "custom"), gates=gates)

    def __len__(self) -> int:
        """Return number of gates in pipeline."""
        return len(self.gates)

    def __repr__(self) -> str:
        enabled = sum(1 for g in self.gates if g.enabled)
        return f"GatePipeline(name='{self.name}', gates={len(self.gates)}, enabled={enabled})"
