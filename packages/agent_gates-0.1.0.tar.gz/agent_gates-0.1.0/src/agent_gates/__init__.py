"""
Agent Gates - Quality gates for AI agent output validation.

A framework for validating AI agent outputs with configurable gates.
Designed for Claude, GPT, and other LLM-based agents.

Quick Start:
    >>> from agent_gates import GatePipeline
    >>> pipeline = GatePipeline.from_preset("standard")
    >>> result = pipeline.check("This should work")
    >>> result.passed
    False
    >>> result.failures[0].message
    'Contains hedging language - uncertain claims without verification'

Custom Gates:
    >>> from agent_gates import Gate, GatePipeline
    >>> gate = Gate(
    ...     name="no_emoji",
    ...     pattern=r"[\\U0001F600-\\U0001F64F]",
    ...     message="Contains emoji"
    ... )
    >>> pipeline = GatePipeline("custom").add_gate(gate)
"""

from .gate import (
    Gate,
    GateAction,
    GateCategory,
    GateFailure,
    GateResult,
    check_gates,
)
from .pipeline import GatePipeline
from .presets import (
    PresetName,
    get_preset_gates,
    ALL_GATES,
    HEDGING_GATE,
    APOLOGY_GATE,
    SYCOPHANCY_GATE,
    UNVERIFIED_CLAIM_GATE,
    TODO_GATE,
    DEFERRAL_GATE,
    ASSUMPTION_GATE,
    CREDENTIAL_GATE,
    MAGIC_NUMBER_GATE,
    DEBUG_PRINT_GATE,
    COMMENTED_CODE_GATE,
)

__version__ = "0.1.0"
__all__ = [
    # Core classes
    "Gate",
    "GateAction",
    "GateCategory",
    "GateFailure",
    "GateResult",
    "GatePipeline",
    # Functions
    "check_gates",
    "get_preset_gates",
    "quick_check",
    "get_failures",
    # Presets
    "PresetName",
    "ALL_GATES",
    # Individual gates
    "HEDGING_GATE",
    "APOLOGY_GATE",
    "SYCOPHANCY_GATE",
    "UNVERIFIED_CLAIM_GATE",
    "TODO_GATE",
    "DEFERRAL_GATE",
    "ASSUMPTION_GATE",
    "CREDENTIAL_GATE",
    "MAGIC_NUMBER_GATE",
    "DEBUG_PRINT_GATE",
    "COMMENTED_CODE_GATE",
]


def quick_check(text: str, preset: PresetName = "standard") -> bool:
    """
    Quick boolean check - does text pass the specified preset?

    Args:
        text: Text to check
        preset: Preset name (strict, standard, minimal, code_review)

    Returns:
        True if all gates passed, False otherwise

    Example:
        >>> quick_check("The fix has been verified and works correctly.")
        True
        >>> quick_check("This should work")
        False
    """
    pipeline = GatePipeline.from_preset(preset)
    return pipeline.check(text).passed


def get_failures(text: str, preset: PresetName = "standard") -> list[str]:
    """
    Get list of failure messages for text.

    Args:
        text: Text to check
        preset: Preset name

    Returns:
        List of failure message strings

    Example:
        >>> get_failures("This should work")
        ['no_hedging: Contains hedging language - uncertain claims without verification']
    """
    pipeline = GatePipeline.from_preset(preset)
    result = pipeline.check(text)
    return [f"{f.gate_name}: {f.message}" for f in result.failures]
