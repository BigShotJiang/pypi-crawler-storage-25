"""
Preset gate definitions for common use cases.
"""

import re
from typing import Literal

from .gate import Gate

PresetName = Literal["strict", "standard", "minimal", "code_review"]

# =============================================================================
# Language Quality Gates
# =============================================================================

HEDGING_GATE = Gate(
    name="no_hedging",
    pattern=r"should work|might be|probably|i think|i believe|hopefully|maybe|perhaps|not sure",
    escape_pattern=r"verified|confirmed|tested|works|succeeded",
    action="block",
    message="Contains hedging language - uncertain claims without verification",
    suggestion="Either VERIFY it works or do more research before claiming",
    category="language"
)

APOLOGY_GATE = Gate(
    name="no_apologies",
    pattern=r"i apologize|i'm sorry|sorry for|my apologies|forgive me",
    action="block",
    message="Contains apologetic language",
    suggestion="No apologies needed - just state facts directly",
    category="language"
)

SYCOPHANCY_GATE = Gate(
    name="no_sycophancy",
    pattern=r"great question|excellent question|good question|you're absolutely right|you make a great point",
    action="block",
    message="Contains sycophantic language",
    suggestion="Skip validation - answer the question directly",
    category="language"
)

# =============================================================================
# Verification Gates
# =============================================================================

UNVERIFIED_CLAIM_GATE = Gate(
    name="verified_claims",
    pattern=r"should now|should be.*fixed|try.*now|give.*try|let me know if|hopefully.*works",
    escape_pattern=r"verified|confirmed|tested|output shows|result shows|works correctly",
    action="block",
    message="Claiming completion without showing verification",
    suggestion="Run a test, check output, or use a verification tool before claiming success",
    category="verification"
)

# =============================================================================
# Completeness Gates
# =============================================================================

TODO_GATE = Gate(
    name="no_todos",
    pattern=r"added.*todo|left.*todo|todo.*implement|left.*unfinished",
    action="block",
    message="Creating TODO markers instead of completing work",
    suggestion="Complete the work NOW or explain why it cannot be done",
    category="completeness"
)

DEFERRAL_GATE = Gate(
    name="no_deferral",
    pattern=r"i'll.*later|do.*later|add.*later|fix.*later|for now|temporary|placeholder",
    action="block",
    message="Deferring work instead of completing it",
    suggestion="Complete the work properly NOW",
    category="completeness"
)

# =============================================================================
# Assumption Gates
# =============================================================================

ASSUMPTION_GATE = Gate(
    name="no_assumptions",
    pattern=r"i'll assume|i assume|i'm assuming|let's assume|i'll go ahead|i'll just",
    escape_pattern=r"would you like|do you want|should i|can you clarify|\?",
    action="warn",
    message="Making assumptions instead of asking",
    suggestion="ASK a clarifying question instead of assuming",
    category="language"
)

# =============================================================================
# Security Gates
# =============================================================================

CREDENTIAL_GATE = Gate(
    name="no_credentials",
    pattern=r"password[=:]|api[_-]?key[=:]|secret[=:]|token[=:]|bearer\s+[a-z0-9]",
    action="block",
    message="May contain exposed credentials",
    suggestion="NEVER include credentials in output. Use references or placeholders.",
    category="security"
)

# =============================================================================
# Code Review Gates
# =============================================================================

MAGIC_NUMBER_GATE = Gate(
    name="no_magic_numbers",
    check_fn=lambda text: bool(re.search(r'(?<![a-zA-Z_])[0-9]{4,}(?![0-9])', text) and 'port' not in text.lower()),
    action="info",
    message="Contains potential magic numbers",
    suggestion="Consider using named constants for clarity",
    category="style"
)

DEBUG_PRINT_GATE = Gate(
    name="no_print_debug",
    pattern=r"console\.log|print\s*\(|println|debug\s*\(",
    escape_pattern=r"logging|logger|removed|deleted",
    action="warn",
    message="Contains debug print statements",
    suggestion="Remove debug statements before committing",
    category="style"
)

COMMENTED_CODE_GATE = Gate(
    name="no_commented_code",
    pattern=r"//\s*(if|for|while|function|def|class|return)\s",
    action="info",
    message="Contains commented-out code",
    suggestion="Delete commented code - version control preserves history",
    category="style"
)

# =============================================================================
# Preset Collections
# =============================================================================

def _clone_gate_with_action(gate: Gate, action: str) -> Gate:
    """Create a copy of a gate with a different action."""
    return Gate(
        name=gate.name,
        pattern=gate.pattern,
        check_fn=gate.check_fn,
        escape_pattern=gate.escape_pattern,
        action=action,
        message=gate.message,
        suggestion=gate.suggestion,
        category=gate.category,
        enabled=gate.enabled
    )


def get_preset_gates(preset: PresetName) -> list[Gate]:
    """
    Get a list of gates for a preset.

    Args:
        preset: One of 'strict', 'standard', 'minimal', 'code_review'

    Returns:
        List of Gate objects configured for the preset
    """
    if preset == "strict":
        return [
            HEDGING_GATE,
            APOLOGY_GATE,
            SYCOPHANCY_GATE,
            UNVERIFIED_CLAIM_GATE,
            TODO_GATE,
            DEFERRAL_GATE,
            _clone_gate_with_action(ASSUMPTION_GATE, "block"),
            CREDENTIAL_GATE,
        ]
    elif preset == "standard":
        return [
            HEDGING_GATE,
            APOLOGY_GATE,
            SYCOPHANCY_GATE,
            UNVERIFIED_CLAIM_GATE,
            TODO_GATE,
            DEFERRAL_GATE,
            ASSUMPTION_GATE,
            CREDENTIAL_GATE,
        ]
    elif preset == "minimal":
        return [
            HEDGING_GATE,
            UNVERIFIED_CLAIM_GATE,
            CREDENTIAL_GATE,
        ]
    elif preset == "code_review":
        return [
            TODO_GATE,
            CREDENTIAL_GATE,
            MAGIC_NUMBER_GATE,
            DEBUG_PRINT_GATE,
            COMMENTED_CODE_GATE,
        ]
    else:
        raise ValueError(f"Unknown preset: {preset}. Use: strict, standard, minimal, code_review")


# Export all gates for custom composition
ALL_GATES = [
    HEDGING_GATE,
    APOLOGY_GATE,
    SYCOPHANCY_GATE,
    UNVERIFIED_CLAIM_GATE,
    TODO_GATE,
    DEFERRAL_GATE,
    ASSUMPTION_GATE,
    CREDENTIAL_GATE,
    MAGIC_NUMBER_GATE,
    DEBUG_PRINT_GATE,
    COMMENTED_CODE_GATE,
]
