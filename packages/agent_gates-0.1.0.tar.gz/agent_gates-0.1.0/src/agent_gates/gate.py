"""
Core Gate class and related types for agent output validation.
"""

import re
from dataclasses import dataclass, field, asdict
from typing import Optional, Callable
from enum import Enum


class GateAction(str, Enum):
    """What to do when a gate fails."""
    BLOCK = "block"      # Hard stop - must fix before proceeding
    WARN = "warn"        # Warning - logged but not blocking
    INFO = "info"        # Informational - for metrics only


class GateCategory(str, Enum):
    """Categories of quality gates."""
    LANGUAGE = "language"           # Hedging, uncertainty, apologies
    VERIFICATION = "verification"   # Claims without evidence
    COMPLETENESS = "completeness"   # Incomplete work, TODOs
    SECURITY = "security"           # Credential exposure, injection
    STYLE = "style"                 # Code style, formatting
    SAFETY = "safety"               # Dangerous operations
    CUSTOM = "custom"               # User-defined


@dataclass
class Gate:
    """
    A single quality gate for validating agent output.

    Gates can match text using regex patterns or custom functions.
    When a match is found, the gate fails (returns False from check()).

    Example:
        >>> gate = Gate(
        ...     name="no_hedging",
        ...     pattern=r"should work|might be|probably",
        ...     action="block",
        ...     message="Contains hedging language"
        ... )
        >>> gate.check("This should work")
        False
        >>> gate.check("This has been verified")
        True
    """
    name: str
    pattern: Optional[str] = None        # Regex pattern to match (match = failure)
    check_fn: Optional[Callable[[str], bool]] = None  # Custom check (True = failure)
    escape_pattern: Optional[str] = None  # Pattern that exempts from this gate
    action: str = "block"                 # block, warn, info
    message: str = ""                     # Human-readable failure message
    suggestion: str = ""                  # How to fix
    category: str = "custom"              # Category for grouping
    enabled: bool = True                  # Can be disabled

    def check(self, text: str) -> bool:
        """
        Check if text passes this gate.

        Args:
            text: The text to validate

        Returns:
            True if passed (no issues), False if failed
        """
        if not self.enabled:
            return True

        # Check escape pattern first
        if self.escape_pattern and re.search(self.escape_pattern, text, re.IGNORECASE):
            return True

        # Check pattern
        if self.pattern:
            if re.search(self.pattern, text, re.IGNORECASE):
                return False

        # Check custom function
        if self.check_fn:
            try:
                # check_fn returns True if problem found
                if self.check_fn(text):
                    return False
            except Exception:
                pass  # Silently pass if check fails

        return True

    def to_dict(self) -> dict:
        """Serialize gate to dictionary (excluding check_fn)."""
        return {
            "name": self.name,
            "pattern": self.pattern,
            "escape_pattern": self.escape_pattern,
            "action": self.action,
            "message": self.message,
            "suggestion": self.suggestion,
            "category": self.category,
            "enabled": self.enabled
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Gate":
        """Deserialize gate from dictionary."""
        return cls(
            name=data["name"],
            pattern=data.get("pattern"),
            escape_pattern=data.get("escape_pattern"),
            action=data.get("action", "block"),
            message=data.get("message", ""),
            suggestion=data.get("suggestion", ""),
            category=data.get("category", "custom"),
            enabled=data.get("enabled", True)
        )


@dataclass
class GateFailure:
    """Details of a gate failure."""
    gate_name: str
    category: str
    action: str
    message: str
    suggestion: str
    matched_text: Optional[str] = None


@dataclass
class GateResult:
    """Result of checking gates."""
    passed: bool
    failures: list[GateFailure] = field(default_factory=list)
    warnings: list[GateFailure] = field(default_factory=list)
    info: list[GateFailure] = field(default_factory=list)

    def has_blocks(self) -> bool:
        """Check if there are any blocking failures."""
        return any(f.action == GateAction.BLOCK.value for f in self.failures)

    def to_markdown(self) -> str:
        """Format result as markdown."""
        if self.passed and not self.warnings:
            return "**All quality gates passed.**"

        parts = []

        if self.failures:
            parts.append("## Blocking Issues\n")
            for f in self.failures:
                parts.append(f"### {f.gate_name}")
                parts.append(f"- **Category:** {f.category}")
                parts.append(f"- **Issue:** {f.message}")
                if f.suggestion:
                    parts.append(f"- **Fix:** {f.suggestion}")
                if f.matched_text:
                    parts.append(f"- **Matched:** `{f.matched_text[:50]}...`")
                parts.append("")

        if self.warnings:
            parts.append("## Warnings\n")
            for w in self.warnings:
                parts.append(f"- **{w.gate_name}:** {w.message}")
            parts.append("")

        return "\n".join(parts)

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "passed": self.passed,
            "failures": [asdict(f) for f in self.failures],
            "warnings": [asdict(w) for w in self.warnings],
            "info": [asdict(i) for i in self.info]
        }


def check_gates(text: str, gates: list[Gate]) -> GateResult:
    """
    Check text against a list of gates.

    Args:
        text: The text to check
        gates: List of Gate objects to apply

    Returns:
        GateResult with pass/fail status and details

    Example:
        >>> gates = [Gate(name="test", pattern=r"bad", action="block", message="Found bad")]
        >>> result = check_gates("This is bad", gates)
        >>> result.passed
        False
    """
    if not text or len(text) < 10:
        return GateResult(passed=True)

    failures = []
    warnings = []
    info = []

    for gate in gates:
        if not gate.enabled:
            continue

        if not gate.check(text):
            # Find matched text for context
            matched = None
            if gate.pattern:
                match = re.search(gate.pattern, text, re.IGNORECASE)
                if match:
                    matched = match.group()

            failure = GateFailure(
                gate_name=gate.name,
                category=gate.category,
                action=gate.action,
                message=gate.message,
                suggestion=gate.suggestion,
                matched_text=matched
            )

            if gate.action == GateAction.BLOCK.value:
                failures.append(failure)
            elif gate.action == GateAction.WARN.value:
                warnings.append(failure)
            else:
                info.append(failure)

    return GateResult(
        passed=len(failures) == 0,
        failures=failures,
        warnings=warnings,
        info=info
    )
