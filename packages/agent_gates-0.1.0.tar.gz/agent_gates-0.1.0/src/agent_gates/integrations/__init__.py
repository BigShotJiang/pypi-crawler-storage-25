"""
Integrations with popular AI frameworks.
"""
