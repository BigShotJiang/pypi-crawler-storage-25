"""
Basic usage examples for agent-gates.
"""

from agent_gates import (
    Gate,
    GatePipeline,
    quick_check,
    get_failures,
    HEDGING_GATE,
)


def example_preset_pipeline():
    """Using preset pipelines."""
    print("=== Preset Pipeline ===\n")

    # Create a pipeline from preset
    pipeline = GatePipeline.from_preset("standard")

    # Check some text
    good_text = "The fix has been verified and works correctly."
    bad_text = "This should work, hopefully."

    print(f"Good text: {good_text}")
    print(f"Result: {pipeline.check(good_text).passed}\n")

    print(f"Bad text: {bad_text}")
    result = pipeline.check(bad_text)
    print(f"Result: {result.passed}")
    if not result.passed:
        print("Failures:")
        for f in result.failures:
            print(f"  - {f.gate_name}: {f.message}")


def example_custom_gate():
    """Creating custom gates."""
    print("\n=== Custom Gate ===\n")

    # Create a custom gate
    no_yelling = Gate(
        name="no_yelling",
        pattern=r"[A-Z]{5,}",
        action="warn",
        message="Contains excessive caps (yelling)",
        suggestion="Use normal capitalization",
        category="style"
    )

    pipeline = GatePipeline("custom").add_gate(no_yelling)

    text = "This is IMPORTANT information!"
    result = pipeline.check(text)
    print(f"Text: {text}")
    print(f"Passed: {result.passed}")
    print(f"Warnings: {len(result.warnings)}")


def example_escape_patterns():
    """Using escape patterns to allow exceptions."""
    print("\n=== Escape Patterns ===\n")

    # Hedging gate has escape for verified/confirmed
    print(f"Hedging pattern: {HEDGING_GATE.pattern}")
    print(f"Escape pattern: {HEDGING_GATE.escape_pattern}")

    # This fails - hedging without verification
    print(f"\n'This should work' passes: {HEDGING_GATE.check('This should work')}")

    # This passes - has verification language
    print(f"'This should work, verified' passes: {HEDGING_GATE.check('This should work, verified')}")


def example_quick_check():
    """Using utility functions."""
    print("\n=== Quick Check ===\n")

    texts = [
        "The implementation is complete and tested.",
        "I think this might work.",
        "TODO: implement this later",
    ]

    for text in texts:
        passed = quick_check(text, "minimal")
        print(f"'{text[:40]}...' - {'PASS' if passed else 'FAIL'}")


def example_serialization():
    """Saving and loading pipelines."""
    print("\n=== Serialization ===\n")

    import json

    # Create and configure pipeline
    pipeline = GatePipeline.from_preset("minimal")
    pipeline.add_gate(Gate(
        name="custom_check",
        pattern=r"FIXME",
        message="Contains FIXME marker"
    ))

    # Serialize
    config = pipeline.to_dict()
    print("Serialized config:")
    print(json.dumps(config, indent=2)[:200] + "...")

    # Deserialize
    restored = GatePipeline.from_dict(config)
    print(f"\nRestored pipeline: {restored}")


if __name__ == "__main__":
    example_preset_pipeline()
    example_custom_gate()
    example_escape_patterns()
    example_quick_check()
    example_serialization()
