#!/usr/bin/env bash
# Deploy the ServiceNow MCP HTTP server to AWS ECS Fargate.
#
# Prerequisites:
#   - AWS CLI configured with appropriate permissions
#   - Docker installed
#   - Replace <ACCOUNT_ID> and <REGION> in task-definition.json
#
# Usage:
#   cd deploy
#   chmod +x deploy.sh
#   ./deploy.sh

set -euo pipefail

REGION="${AWS_REGION:-us-east-2}"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REPO_NAME="servicenow-mcp-server"
CLUSTER_NAME="servicenow-mcp"
SERVICE_NAME="servicenow-mcp-server"
IMAGE_URI="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${REPO_NAME}:latest"

echo "Account:  ${ACCOUNT_ID}"
echo "Region:   ${REGION}"
echo "Image:    ${IMAGE_URI}"
echo ""

# 1. Create ECR repository (if it doesn't exist)
echo ">> Creating ECR repository..."
aws ecr describe-repositories --repository-names "${REPO_NAME}" --region "${REGION}" 2>/dev/null || \
  aws ecr create-repository --repository-name "${REPO_NAME}" --region "${REGION}"

# 2. Authenticate Docker to ECR
echo ">> Logging into ECR..."
aws ecr get-login-password --region "${REGION}" | \
  docker login --username AWS --password-stdin "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com"

# 3. Build and push Docker image
echo ">> Building Docker image..."
docker build -t "${REPO_NAME}" ..

echo ">> Tagging and pushing..."
docker tag "${REPO_NAME}:latest" "${IMAGE_URI}"
docker push "${IMAGE_URI}"

# 4. Create CloudWatch log group
echo ">> Creating log group..."
aws logs create-log-group --log-group-name "/ecs/${REPO_NAME}" --region "${REGION}" 2>/dev/null || true

# 5. Create Secrets Manager secret (if it doesn't exist)
echo ">> Checking secrets..."
aws secretsmanager describe-secret --secret-id "servicenow-mcp" --region "${REGION}" 2>/dev/null || \
  echo "WARNING: Create the secret 'servicenow-mcp' in Secrets Manager with keys:"
  echo "  SERVICENOW_INSTANCE_URL, SERVICENOW_USERNAME, SERVICENOW_PASSWORD, MCP_API_KEY"

# 6. Update task definition placeholders and register
echo ">> Registering task definition..."
sed "s/<ACCOUNT_ID>/${ACCOUNT_ID}/g; s/<REGION>/${REGION}/g" task-definition.json > /tmp/task-def.json
aws ecs register-task-definition --cli-input-json file:///tmp/task-def.json --region "${REGION}"

# 7. Create ECS cluster (if it doesn't exist)
echo ">> Creating ECS cluster..."
aws ecs describe-clusters --clusters "${CLUSTER_NAME}" --region "${REGION}" | \
  grep -q ACTIVE || aws ecs create-cluster --cluster-name "${CLUSTER_NAME}" --region "${REGION}"

# 8. Create or update the service
echo ">> Deploying service..."
if aws ecs describe-services --cluster "${CLUSTER_NAME}" --services "${SERVICE_NAME}" --region "${REGION}" 2>/dev/null | grep -q ACTIVE; then
  aws ecs update-service \
    --cluster "${CLUSTER_NAME}" \
    --service "${SERVICE_NAME}" \
    --task-definition "${REPO_NAME}" \
    --force-new-deployment \
    --region "${REGION}"
else
  echo ""
  echo "Service does not exist yet. Create it with:"
  echo ""
  echo "  aws ecs create-service \\"
  echo "    --cluster ${CLUSTER_NAME} \\"
  echo "    --service-name ${SERVICE_NAME} \\"
  echo "    --task-definition ${REPO_NAME} \\"
  echo "    --desired-count 1 \\"
  echo "    --launch-type FARGATE \\"
  echo "    --network-configuration 'awsvpcConfiguration={subnets=[<SUBNET_ID>],securityGroups=[<SG_ID>],assignPublicIp=ENABLED}' \\"
  echo "    --region ${REGION}"
  echo ""
  echo "Replace <SUBNET_ID> and <SG_ID> with your VPC values."
fi

echo ""
echo "Done! The server will be accessible on port 8000."
