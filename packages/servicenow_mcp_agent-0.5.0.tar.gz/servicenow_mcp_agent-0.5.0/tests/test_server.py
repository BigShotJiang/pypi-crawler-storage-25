"""Tests for the ServiceNow MCP server."""

import os
import importlib
import json
from unittest.mock import patch

import httpx
import pytest
import respx

# We need to reload the server module with controlled env vars for each test group.
# The module reads env vars at import time, so we patch before importing.


def _reload_server(**env_overrides):
    """Reload the server module with the given environment variable overrides."""
    env = {
        "SERVICENOW_INSTANCE_URL": "https://test.service-now.com",
        "SERVICENOW_USERNAME": "admin",
        "SERVICENOW_PASSWORD": "password",
        "SERVICENOW_AUTH_METHOD": "basic",
        "SERVICENOW_API_KEY": "",
        "SERVICENOW_OAUTH_TOKEN": "",
        "DOTENV_PATH": "",  # prevent loading any .env file
    }
    env.update(env_overrides)
    with patch.dict(os.environ, env, clear=False):
        import servicenow_mcp_agent.server as srv
        importlib.reload(srv)
        return srv


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

class TestPathResolution:
    def test_pkg_dir_is_package_directory(self):
        srv = _reload_server()
        assert srv._pkg_dir.endswith("servicenow_mcp_agent")

    def test_project_root_is_two_levels_up(self):
        srv = _reload_server()
        assert os.path.basename(srv._project_root) in ("src", "servicenow-mcp-agent")
        # The .env path should be under project root
        assert srv._dotenv_path.endswith(".env")

    def test_dotenv_path_env_var_takes_precedence(self):
        srv = _reload_server(DOTENV_PATH="/custom/path/.env")
        assert srv._dotenv_path == "/custom/path/.env"


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

class TestAuth:
    def test_basic_auth_header(self):
        srv = _reload_server()
        headers = srv._auth_header()
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Basic ")
        assert headers["Content-Type"] == "application/json"

    def test_api_key_auth_header(self):
        srv = _reload_server(
            SERVICENOW_AUTH_METHOD="api_key",
            SERVICENOW_API_KEY="test-key-123",
        )
        headers = srv._auth_header()
        assert headers.get("X-sn-apikey") == "test-key-123"
        assert "Authorization" not in headers

    def test_oauth_auth_header(self):
        srv = _reload_server(
            SERVICENOW_AUTH_METHOD="oauth",
            SERVICENOW_OAUTH_TOKEN="bearer-token-xyz",
        )
        headers = srv._auth_header()
        assert headers["Authorization"] == "Bearer bearer-token-xyz"

    def test_falls_back_to_basic_for_unknown_method(self):
        srv = _reload_server(SERVICENOW_AUTH_METHOD="unknown")
        headers = srv._auth_header()
        assert headers["Authorization"].startswith("Basic ")


# ---------------------------------------------------------------------------
# Credential checking
# ---------------------------------------------------------------------------

class TestCredentialCheck:
    def test_passes_with_valid_basic_creds(self):
        srv = _reload_server()
        assert srv._check_credentials() is None

    def test_fails_without_instance_url(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = srv._check_credentials()
        assert result is not None
        assert "not configured" in result[0].text

    def test_fails_without_username_for_basic(self):
        srv = _reload_server(SERVICENOW_USERNAME="")
        result = srv._check_credentials()
        assert result is not None
        assert "basic" in result[0].text.lower()

    def test_passes_with_api_key(self):
        srv = _reload_server(
            SERVICENOW_AUTH_METHOD="api_key",
            SERVICENOW_API_KEY="key123",
            SERVICENOW_USERNAME="",
        )
        assert srv._check_credentials() is None

    def test_fails_with_api_key_method_but_no_key(self):
        srv = _reload_server(
            SERVICENOW_AUTH_METHOD="api_key",
            SERVICENOW_API_KEY="",
            SERVICENOW_USERNAME="",
        )
        result = srv._check_credentials()
        assert result is not None
        assert "api_key" in result[0].text

    def test_passes_with_oauth_token(self):
        srv = _reload_server(
            SERVICENOW_AUTH_METHOD="oauth",
            SERVICENOW_OAUTH_TOKEN="token",
            SERVICENOW_USERNAME="",
        )
        assert srv._check_credentials() is None

    def test_error_includes_dotenv_path(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = srv._check_credentials()
        assert ".env" in result[0].text


# ---------------------------------------------------------------------------
# Tool handlers (mocked HTTP)
# ---------------------------------------------------------------------------

BASE_URL = "https://test.service-now.com"


@pytest.fixture
def srv():
    return _reload_server()


class TestIncidentHandlers:
    @respx.mock
    @pytest.mark.asyncio
    async def test_create_incident(self, srv):
        respx.post(f"{BASE_URL}/api/now/table/incident").mock(
            return_value=httpx.Response(201, json={
                "result": {
                    "number": "INC0010099",
                    "sys_id": "abc123",
                    "priority": "3",
                    "state": "1",
                }
            })
        )
        result = await srv._create_incident({
            "short_description": "Test incident",
            "description": "This is a test",
            "impact": "3",
            "urgency": "3",
            "category": "Software",
        })
        assert "INC0010099" in result[0].text
        assert "successfully" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_incident(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/incident").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "number": "INC0010001",
                    "short_description": "Test",
                    "description": "Details",
                    "state": "1",
                    "impact": "2",
                    "urgency": "2",
                    "priority": "3",
                    "category": "Software",
                    "assignment_group": "",
                    "assigned_to": "",
                    "sys_created_on": "2025-01-01",
                    "sys_updated_on": "2025-01-02",
                    "resolved_by": "",
                    "resolution_notes": "",
                    "close_code": "",
                }]
            })
        )
        result = await srv._get_incident({"number": "INC0010001"})
        assert "INC0010001" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_incident_not_found(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/incident").mock(
            return_value=httpx.Response(200, json={"result": []})
        )
        result = await srv._get_incident({"number": "INC9999999"})
        assert "No incident found" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_search_incidents(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/incident").mock(
            return_value=httpx.Response(200, json={
                "result": [
                    {"number": "INC0010001", "short_description": "Issue A",
                     "state": "1", "priority": "2", "category": "Software", "assigned_to": ""},
                    {"number": "INC0010002", "short_description": "Issue B",
                     "state": "2", "priority": "3", "category": "Network", "assigned_to": ""},
                ]
            })
        )
        result = await srv._search_incidents({"query": "state=1"})
        assert "2 incident(s)" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_create_incident_api_error(self, srv):
        respx.post(f"{BASE_URL}/api/now/table/incident").mock(
            return_value=httpx.Response(403, text="Forbidden")
        )
        result = await srv._create_incident({
            "short_description": "Test",
            "description": "Test",
            "impact": "3",
            "urgency": "3",
            "category": "Software",
        })
        assert "403" in result[0].text


class TestProblemHandlers:
    @respx.mock
    @pytest.mark.asyncio
    async def test_create_problem(self, srv):
        respx.post(f"{BASE_URL}/api/now/table/problem").mock(
            return_value=httpx.Response(201, json={
                "result": {
                    "number": "PRB0000001",
                    "state": "1",
                }
            })
        )
        result = await srv._create_problem({
            "short_description": "Root cause investigation",
            "description": "Multiple incidents related to DB timeouts",
            "impact": "1",
            "urgency": "1",
        })
        assert "PRB0000001" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_problem(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/problem").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "number": "PRB0000001",
                    "short_description": "DB issue",
                    "description": "Details",
                    "state": "1",
                    "impact": "1",
                    "urgency": "1",
                    "priority": "1",
                    "category": "Database",
                    "assignment_group": "",
                    "assigned_to": "",
                    "cause_notes": "Connection pool exhaustion",
                    "fix_notes": "",
                    "workaround": "Restart service",
                    "known_error": "false",
                    "sys_created_on": "2025-01-01",
                }]
            })
        )
        result = await srv._get_problem({"number": "PRB0000001"})
        assert "PRB0000001" in result[0].text
        assert "Connection pool exhaustion" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_search_problems(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/problem").mock(
            return_value=httpx.Response(200, json={
                "result": [
                    {"number": "PRB0000001", "short_description": "DB issue",
                     "state": "1", "priority": "1", "category": "Database"},
                ]
            })
        )
        result = await srv._search_problems({"query": "state=1"})
        assert "1 problem(s)" in result[0].text


class TestCMDBHandlers:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_ci(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/cmdb_ci").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "name": "web-server-01",
                    "sys_id": "ci123",
                    "sys_class_name": "cmdb_ci_server",
                    "operational_status": "1",
                    "environment": "Production",
                    "category": "Hardware",
                    "subcategory": "Server",
                    "assigned_to": "",
                    "support_group": "Server Team",
                    "location": "US-East",
                    "manufacturer": "Dell",
                    "model_id": "R740",
                    "serial_number": "SN123",
                    "ip_address": "10.0.1.5",
                }]
            })
        )
        result = await srv._get_ci({"name": "web-server-01"})
        assert "web-server-01" in result[0].text
        assert "10.0.1.5" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_ci_not_found(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/cmdb_ci").mock(
            return_value=httpx.Response(200, json={"result": []})
        )
        result = await srv._get_ci({"name": "nonexistent"})
        assert "No CI found" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_search_cis(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/cmdb_ci").mock(
            return_value=httpx.Response(200, json={
                "result": [
                    {"name": "server-01", "sys_class_name": "cmdb_ci_server",
                     "operational_status": "1", "environment": "Production", "ip_address": "10.0.1.1"},
                    {"name": "server-02", "sys_class_name": "cmdb_ci_server",
                     "operational_status": "1", "environment": "Production", "ip_address": "10.0.1.2"},
                ]
            })
        )
        result = await srv._search_cis({"query": "sys_class_name=cmdb_ci_server"})
        assert "2 CI(s)" in result[0].text


class TestSLAHandlers:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_task_sla(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/task_sla").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "sla": "Priority 1 Resolution",
                    "stage": "in_progress",
                    "has_breached": "false",
                    "business_time_left": "3 Hours",
                    "start_time": "2025-01-01 10:00:00",
                    "end_time": "2025-01-01 14:00:00",
                    "task": "INC0010001",
                    "percentage": "50",
                }]
            })
        )
        result = await srv._get_task_sla({"task_number": "INC0010001"})
        assert "Priority 1 Resolution" in result[0].text
        assert "No" in result[0].text  # not breached

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_task_sla_breached(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/task_sla").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "sla": "Priority 1 Resolution",
                    "stage": "breached",
                    "has_breached": "true",
                    "business_time_left": "0",
                    "start_time": "2025-01-01 10:00:00",
                    "end_time": "2025-01-01 14:00:00",
                    "task": "INC0010001",
                    "percentage": "120",
                }]
            })
        )
        result = await srv._get_task_sla({"task_number": "INC0010001"})
        assert "YES" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_task_sla_no_records(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/task_sla").mock(
            return_value=httpx.Response(200, json={"result": []})
        )
        result = await srv._get_task_sla({"task_number": "INC9999999"})
        assert "No SLA records" in result[0].text


class TestApprovalHandlers:
    @respx.mock
    @pytest.mark.asyncio
    async def test_get_approvals(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/sysapproval_approver").mock(
            return_value=httpx.Response(200, json={
                "result": [{
                    "sys_id": "appr123",
                    "approver": "john.doe",
                    "state": "requested",
                    "comments": "",
                    "sys_updated_on": "2025-01-01",
                    "sysapproval": "CHG0000001",
                }]
            })
        )
        result = await srv._get_approvals({"task_number": "CHG0000001"})
        assert "john.doe" in result[0].text
        assert "requested" in result[0].text

    @respx.mock
    @pytest.mark.asyncio
    async def test_update_approval(self, srv):
        respx.patch(f"{BASE_URL}/api/now/table/sysapproval_approver/appr123").mock(
            return_value=httpx.Response(200, json={
                "result": {
                    "sys_id": "appr123",
                    "approver": "john.doe",
                    "state": "approved",
                    "comments": "Looks good",
                }
            })
        )
        result = await srv._update_approval({
            "sys_id": "appr123",
            "state": "approved",
            "comments": "Looks good",
        })
        assert "approved" in result[0].text.lower()

    @respx.mock
    @pytest.mark.asyncio
    async def test_get_approvals_none_found(self, srv):
        respx.get(f"{BASE_URL}/api/now/table/sysapproval_approver").mock(
            return_value=httpx.Response(200, json={"result": []})
        )
        result = await srv._get_approvals({"task_number": "CHG9999999"})
        assert "No approvals found" in result[0].text


class TestCredentialCheckBlocksHandlers:
    """Verify that handlers return the credential error when creds are missing."""

    @pytest.mark.asyncio
    async def test_create_incident_no_creds(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = await srv._create_incident({
            "short_description": "x", "description": "x",
            "impact": "3", "urgency": "3", "category": "Software",
        })
        assert "ERROR" in result[0].text

    @pytest.mark.asyncio
    async def test_get_ci_no_creds(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = await srv._get_ci({"name": "test"})
        assert "ERROR" in result[0].text

    @pytest.mark.asyncio
    async def test_get_task_sla_no_creds(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = await srv._get_task_sla({"task_number": "INC0010001"})
        assert "ERROR" in result[0].text

    @pytest.mark.asyncio
    async def test_get_approvals_no_creds(self):
        srv = _reload_server(SERVICENOW_INSTANCE_URL="")
        result = await srv._get_approvals({"task_number": "CHG0000001"})
        assert "ERROR" in result[0].text


class TestHelperFunctions:
    def test_val_with_string(self):
        srv = _reload_server()
        assert srv._val({"name": "test"}, "name") == "test"

    def test_val_with_dict_display_value(self):
        srv = _reload_server()
        record = {"field": {"display_value": "Display", "value": "raw"}}
        assert srv._val(record, "field") == "Display"

    def test_val_with_dict_value_only(self):
        srv = _reload_server()
        record = {"field": {"value": "raw"}}
        assert srv._val(record, "field") == "raw"

    def test_val_with_missing_field(self):
        srv = _reload_server()
        assert srv._val({}, "missing") == ""

    def test_val_with_empty_string(self):
        srv = _reload_server()
        assert srv._val({"field": ""}, "field") == ""
