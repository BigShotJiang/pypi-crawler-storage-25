"""Seed a ServiceNow developer instance with sample KB articles and Change Requests.

Usage:
    python scripts/seed_sample_data.py

Requires .env to be configured with ServiceNow credentials.
"""

import json
import os
import sys
from base64 import b64encode

import httpx
from dotenv import load_dotenv

load_dotenv()

INSTANCE_URL = os.getenv("SERVICENOW_INSTANCE_URL", "").rstrip("/")
USERNAME = os.getenv("SERVICENOW_USERNAME", "")
PASSWORD = os.getenv("SERVICENOW_PASSWORD", "")


def _headers() -> dict[str, str]:
    token = b64encode(f"{USERNAME}:{PASSWORD}".encode()).decode()
    return {
        "Authorization": f"Basic {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def create_record(table: str, payload: dict) -> dict | None:
    url = f"{INSTANCE_URL}/api/now/table/{table}"
    resp = httpx.post(url, headers=_headers(), json=payload, timeout=30)
    if resp.status_code in (200, 201):
        result = resp.json().get("result", {})
        number = result.get("number", "N/A")
        print(f"  Created {table} {number}")
        return result
    else:
        print(f"  FAILED {table}: HTTP {resp.status_code} -- {resp.text[:200]}")
        return None


# -- Knowledge Base articles --------------------------------------------------

KB_ARTICLES = [
    {
        "short_description": "How to reset your VPN connection",
        "text": (
            "<h2>VPN Connection Reset Guide</h2>"
            "<p><strong>Symptoms:</strong> VPN client fails to connect, times out, "
            "or shows 'authentication failed' errors.</p>"
            "<h3>Steps to resolve:</h3>"
            "<ol>"
            "<li>Close the VPN client completely (check the system tray).</li>"
            "<li>Open a command prompt and run: <code>ipconfig /flushdns</code></li>"
            "<li>Restart the VPN client and try connecting again.</li>"
            "<li>If the issue persists, delete the VPN profile and re-import it from "
            "the IT portal at https://it-portal.example.com/vpn.</li>"
            "<li>If you still cannot connect, ensure your password has not expired "
            "by logging into https://password.example.com.</li>"
            "</ol>"
            "<p><strong>Common cause:</strong> Cached DNS entries or expired certificates.</p>"
        ),
        "workflow_state": "published",
    },
    {
        "short_description": "Password reset and account unlock procedure",
        "text": (
            "<h2>Password Reset & Account Unlock</h2>"
            "<p><strong>Symptoms:</strong> Unable to log in, account locked out, "
            "'invalid credentials' error.</p>"
            "<h3>Self-service password reset:</h3>"
            "<ol>"
            "<li>Go to https://password.example.com.</li>"
            "<li>Click 'Forgot Password' and verify your identity via email or SMS.</li>"
            "<li>Set a new password (minimum 12 characters, must include uppercase, "
            "lowercase, number, and special character).</li>"
            "<li>Wait 5 minutes for the change to propagate, then try logging in.</li>"
            "</ol>"
            "<h3>Account unlock (no password change needed):</h3>"
            "<p>If your account is locked due to too many failed attempts, wait 30 minutes "
            "for the automatic unlock, or contact the Service Desk at ext. 5555.</p>"
            "<p><strong>Note:</strong> Passwords expire every 90 days. Set a calendar reminder.</p>"
        ),
        "workflow_state": "published",
    },
    {
        "short_description": "How to request software installation",
        "text": (
            "<h2>Software Installation Requests</h2>"
            "<p>All software installations must go through the IT Service Catalog.</p>"
            "<h3>Steps:</h3>"
            "<ol>"
            "<li>Open the ServiceNow self-service portal.</li>"
            "<li>Navigate to Service Catalog > Software.</li>"
            "<li>Search for the software you need.</li>"
            "<li>Submit a request with your business justification.</li>"
            "<li>Your manager will receive an approval request.</li>"
            "<li>Once approved, the software will be deployed within 2 business days.</li>"
            "</ol>"
            "<p><strong>Unsupported software:</strong> If the software is not in the catalog, "
            "submit a 'New Software Request' form. The security team will review it "
            "(typical turnaround: 5-10 business days).</p>"
        ),
        "workflow_state": "published",
    },
    {
        "short_description": "Outlook email not syncing on mobile devices",
        "text": (
            "<h2>Outlook Mobile Sync Issues</h2>"
            "<p><strong>Symptoms:</strong> Emails not appearing on phone, "
            "sync errors, or Outlook app crashing.</p>"
            "<h3>Troubleshooting steps:</h3>"
            "<ol>"
            "<li>Ensure your device has an active internet connection.</li>"
            "<li>Force-close the Outlook app and reopen it.</li>"
            "<li>Go to Settings > Accounts > select your work account > 'Reset Account'.</li>"
            "<li>If the issue persists, remove the account and re-add it.</li>"
            "<li>Ensure your device meets the MDM compliance policy: "
            "OS must be within the last 2 major versions, and device encryption must be enabled.</li>"
            "</ol>"
            "<p><strong>Known issue:</strong> Outlook v4.2326 has a sync bug on Android 14. "
            "Update to v4.2330+ from the Play Store.</p>"
        ),
        "workflow_state": "published",
    },
    {
        "short_description": "Printer not working or print jobs stuck in queue",
        "text": (
            "<h2>Printer Troubleshooting</h2>"
            "<p><strong>Symptoms:</strong> Print jobs stuck, printer offline, "
            "or 'driver unavailable' errors.</p>"
            "<h3>Steps to resolve:</h3>"
            "<ol>"
            "<li>Check if the printer is powered on and shows 'Ready' on its display.</li>"
            "<li>On your computer, go to Settings > Printers & Scanners.</li>"
            "<li>Right-click the printer > 'See what's printing' > cancel all stuck jobs.</li>"
            "<li>Restart the Print Spooler service: open Services (services.msc), "
            "find 'Print Spooler', right-click > Restart.</li>"
            "<li>If the printer still shows offline, remove it and re-add it using "
            "the address from the printer label (e.g., \\\\printserver\\floor3-hp).</li>"
            "</ol>"
            "<p><strong>For network printer issues:</strong> Confirm you're on the corporate "
            "network (not guest Wi-Fi). VPN users should ensure split-tunneling is disabled.</p>"
        ),
        "workflow_state": "published",
    },
]

# -- Change Requests ----------------------------------------------------------

CHANGE_REQUESTS = [
    {
        "short_description": "Upgrade production database from PostgreSQL 14 to 16",
        "description": (
            "Planned upgrade of the main production PostgreSQL cluster from version 14.9 "
            "to 16.2. This involves a rolling upgrade with replication failover to minimize "
            "downtime. Estimated maintenance window: 2 hours. Rollback plan: revert to "
            "standby replica running v14.9."
        ),
        "type": "Normal",
        "risk": "High",
        "impact": "1",
    },
    {
        "short_description": "Deploy new SSO integration for HR portal",
        "description": (
            "Deploy SAML-based SSO integration between Okta and the new HR self-service portal. "
            "This will allow employees to access the HR portal using their corporate credentials "
            "without a separate login. Affects all 5,000+ employees. Rollback: disable SSO "
            "flag and revert to local authentication."
        ),
        "type": "Normal",
        "risk": "Moderate",
        "impact": "2",
    },
    {
        "short_description": "Apply Windows security patches - April 2026 cycle",
        "description": (
            "Standard monthly security patching for all Windows servers. Patches include "
            "CVE-2026-1234 (critical RCE) and 12 other moderate-severity fixes. Servers "
            "will be patched in waves: dev (Tuesday), staging (Wednesday), prod (Saturday). "
            "Auto-reboot scheduled after installation."
        ),
        "type": "Standard",
        "risk": "Low",
        "impact": "3",
    },
    {
        "short_description": "Migrate email gateway to new cloud provider",
        "description": (
            "Migrate the corporate email gateway from on-premises Barracuda appliance to "
            "cloud-hosted Proofpoint. MX records will be updated during the maintenance window. "
            "All inbound/outbound email will route through the new gateway. Rollback: revert "
            "MX records to point back to on-premises appliance."
        ),
        "type": "Normal",
        "risk": "High",
        "impact": "1",
    },
    {
        "short_description": "Add firewall rules for new vendor API integration",
        "description": (
            "Open outbound HTTPS (port 443) from the application subnet (10.20.30.0/24) to "
            "vendor API endpoints at api.vendor-example.com (203.0.113.50, 203.0.113.51). "
            "Required for the new supply chain integration going live next month."
        ),
        "type": "Standard",
        "risk": "Low",
        "impact": "3",
    },
]


def main():
    if not INSTANCE_URL or not USERNAME:
        print("ERROR: Set SERVICENOW_INSTANCE_URL, SERVICENOW_USERNAME, and "
              "SERVICENOW_PASSWORD in your .env file.")
        sys.exit(1)

    print(f"Seeding sample data into {INSTANCE_URL}\n")

    print("Creating Knowledge Base articles...")
    for article in KB_ARTICLES:
        create_record("kb_knowledge", article)

    print("\nCreating Change Requests...")
    for change in CHANGE_REQUESTS:
        create_record("change_request", change)

    print("\nDone! Sample data has been created in your ServiceNow instance.")


if __name__ == "__main__":
    main()
