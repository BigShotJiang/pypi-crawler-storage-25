"""HTTP/SSE transport for the ServiceNow MCP server.

Exposes the same tools as the stdio server, but over HTTP so remote
MCP clients (Agentforce, Slack bots, etc.) can connect over the network.

Usage:
    servicenow-mcp-server-http                         # defaults to 0.0.0.0:8000
    servicenow-mcp-server-http --host 127.0.0.1 --port 9000

Environment variables:
    MCP_API_KEY          -- required; clients must send this in the Authorization header
    SERVICENOW_*         -- ServiceNow credentials (same as stdio server)
"""

import argparse
import logging
import os

import uvicorn
from dotenv import load_dotenv
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Mount, Route
from starlette.types import ASGIApp, Receive, Scope, Send

from mcp.server.sse import SseServerTransport

from servicenow_mcp_agent.server import server

load_dotenv(os.getenv("DOTENV_PATH", ".env"))

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger("servicenow-mcp-http")

API_KEY = os.getenv("MCP_API_KEY", "")


class AuthMiddleware:
    """Pure ASGI middleware for API key auth (compatible with SSE streaming)."""

    def __init__(self, app: ASGIApp):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        if path == "/health" or not API_KEY:
            await self.app(scope, receive, send)
            return

        headers = dict(scope.get("headers", []))
        auth = headers.get(b"authorization", b"").decode()
        if auth != f"Bearer {API_KEY}":
            response = JSONResponse({"error": "Unauthorized"}, status_code=401)
            await response(scope, receive, send)
            return

        await self.app(scope, receive, send)


sse_transport = SseServerTransport("/messages/")


async def handle_sse(request: Request) -> Response:
    """GET /sse -- establish SSE stream for server-to-client messages."""
    logger.info("SSE connection from %s", request.client.host if request.client else "unknown")
    async with sse_transport.connect_sse(
        request.scope, request.receive, request._send
    ) as streams:
        await server.run(
            streams[0],
            streams[1],
            server.create_initialization_options(),
        )
    return Response()


async def health(request: Request) -> JSONResponse:
    """GET /health -- health check for load balancers."""
    return JSONResponse({"status": "ok"})


routes = [
    Route("/health", endpoint=health, methods=["GET"]),
    Route("/sse", endpoint=handle_sse, methods=["GET"]),
    Mount("/messages/", app=sse_transport.handle_post_message),
]

app = Starlette(routes=routes)
app = AuthMiddleware(app)


def main_cli():
    parser = argparse.ArgumentParser(description="ServiceNow MCP Server (HTTP/SSE)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Port (default: 8000)")
    args = parser.parse_args()

    logger.info("Starting HTTP/SSE server on %s:%d", args.host, args.port)
    if not API_KEY:
        logger.warning("MCP_API_KEY not set -- server is unauthenticated!")

    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main_cli()
