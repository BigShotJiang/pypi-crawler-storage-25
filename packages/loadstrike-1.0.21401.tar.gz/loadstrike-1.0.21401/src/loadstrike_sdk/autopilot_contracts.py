from __future__ import annotations

import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .contracts import _ContractModelMixin
from .runtime import (
    LoadStrikeResponse,
    LoadStrikeScenario,
    LoadStrikeSimulation,
    LoadStrikeThreshold,
)

TRACE_TO_TEST_AUTOPILOT_FEATURE = "autopilot.trace_to_test"


class LoadStrikeAutopilotReadiness:
    Ready = "Ready"
    RequiresSecrets = "RequiresSecrets"
    RequiresEndpointBinding = "RequiresEndpointBinding"
    RequiresTargetBinding = "RequiresTargetBinding"
    RequiresTrackingSelector = "RequiresTrackingSelector"
    RequiresReview = "RequiresReview"


@dataclass(init=False)
class LoadStrikeAutopilotOptions(_ContractModelMixin):
    ScenarioName: Optional[str] = None
    IncludePreviewReport: bool = False
    AllowedReplayHosts: List[str] = field(default_factory=list)
    BaseUrlRewrite: Optional[str] = None
    TrackingSelector: Optional[str] = None
    SecretBindings: List["LoadStrikeAutopilotSecretBinding"] = field(default_factory=list)
    EndpointBindings: List["LoadStrikeAutopilotEndpointBinding"] = field(default_factory=list)

    def __init__(
        self,
        scenario_name: Optional[str] = None,
        include_preview_report: bool = False,
        allowed_replay_hosts: Optional[List[str]] = None,
        base_url_rewrite: Optional[str] = None,
        tracking_selector: Optional[str] = None,
        secret_bindings: Optional[List[Any]] = None,
        endpoint_bindings: Optional[List[Any]] = None,
        *,
        ScenarioName: Optional[str] = None,
        IncludePreviewReport: Optional[bool] = None,
        AllowedReplayHosts: Optional[List[str]] = None,
        BaseUrlRewrite: Optional[str] = None,
        TrackingSelector: Optional[str] = None,
        SecretBindings: Optional[List[Any]] = None,
        EndpointBindings: Optional[List[Any]] = None,
    ) -> None:
        self.ScenarioName = ScenarioName if ScenarioName is not None else scenario_name
        self.IncludePreviewReport = bool(
            IncludePreviewReport
            if IncludePreviewReport is not None
            else include_preview_report
        )
        self.AllowedReplayHosts = list(
            AllowedReplayHosts
            if AllowedReplayHosts is not None
            else allowed_replay_hosts
            or []
        )
        self.BaseUrlRewrite = BaseUrlRewrite if BaseUrlRewrite is not None else base_url_rewrite
        self.TrackingSelector = TrackingSelector if TrackingSelector is not None else tracking_selector
        self.SecretBindings = [
            _coerce_secret_binding(item)
            for item in (
                SecretBindings
                if SecretBindings is not None
                else secret_bindings
                or []
            )
        ]
        self.EndpointBindings = [
            _coerce_endpoint_binding(item)
            for item in (
                EndpointBindings
                if EndpointBindings is not None
                else endpoint_bindings
                or []
            )
        ]


@dataclass(init=False)
class LoadStrikeAutopilotSecretBinding(_ContractModelMixin):
    Location: str = ""
    ValueFromEnv: str = ""

    def __init__(
        self,
        location: Optional[str] = None,
        value_from_env: Optional[str] = None,
        *,
        Location: Optional[str] = None,
        ValueFromEnv: Optional[str] = None,
    ) -> None:
        self.Location = str(Location if Location is not None else location or "")
        self.ValueFromEnv = str(ValueFromEnv if ValueFromEnv is not None else value_from_env or "")


@dataclass(init=False)
class LoadStrikeAutopilotEndpointBinding(_ContractModelMixin):
    Name: str = ""
    Kind: Optional[str] = None
    Method: Optional[str] = None
    Url: Optional[str] = None

    def __init__(
        self,
        name: Optional[str] = None,
        kind: Optional[str] = None,
        method: Optional[str] = None,
        url: Optional[str] = None,
        *,
        Name: Optional[str] = None,
        Kind: Optional[str] = None,
        Method: Optional[str] = None,
        Url: Optional[str] = None,
    ) -> None:
        self.Name = str(Name if Name is not None else name or "")
        self.Kind = Kind if Kind is not None else kind
        self.Method = Method if Method is not None else method
        self.Url = Url if Url is not None else url


@dataclass(init=False)
class LoadStrikeAutopilotMessageSample(_ContractModelMixin):
    Name: Optional[str] = None
    ContentType: Optional[str] = None
    Headers: Dict[str, str] = field(default_factory=dict)
    Payload: Any = None
    TransportMetadata: Dict[str, str] = field(default_factory=dict)

    def __init__(
        self,
        name: Optional[str] = None,
        content_type: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        payload: Any = None,
        transport_metadata: Optional[Dict[str, str]] = None,
        *,
        Name: Optional[str] = None,
        ContentType: Optional[str] = None,
        Headers: Optional[Dict[str, str]] = None,
        Payload: Any = None,
        TransportMetadata: Optional[Dict[str, str]] = None,
    ) -> None:
        self.Name = Name if Name is not None else name
        self.ContentType = ContentType if ContentType is not None else content_type
        self.Headers = {
            str(key): str(value)
            for key, value in dict(Headers if Headers is not None else headers or {}).items()
        }
        self.Payload = Payload if Payload is not None else payload
        self.TransportMetadata = {
            str(key): str(value)
            for key, value in dict(
                TransportMetadata
                if TransportMetadata is not None
                else transport_metadata
                or {}
            ).items()
        }


@dataclass(init=False)
class LoadStrikeAutopilotRequest(_ContractModelMixin):
    Kind: str = ""
    FilePath: Optional[str] = None
    Content: Optional[str] = None
    SourceMessage: Optional[LoadStrikeAutopilotMessageSample] = None
    DestinationMessage: Optional[LoadStrikeAutopilotMessageSample] = None
    Options: Optional[LoadStrikeAutopilotOptions] = None

    def __init__(
        self,
        kind: Optional[str] = None,
        file_path: Optional[str] = None,
        content: Optional[str] = None,
        source_message: Optional[Any] = None,
        destination_message: Optional[Any] = None,
        options: Optional[Any] = None,
        *,
        Kind: Optional[str] = None,
        FilePath: Optional[str] = None,
        Content: Optional[str] = None,
        SourceMessage: Optional[Any] = None,
        DestinationMessage: Optional[Any] = None,
        Options: Optional[Any] = None,
    ) -> None:
        self.Kind = str(Kind if Kind is not None else kind or "")
        self.FilePath = FilePath if FilePath is not None else file_path
        self.Content = Content if Content is not None else content
        self.SourceMessage = _coerce_message_sample(
            SourceMessage if SourceMessage is not None else source_message
        )
        self.DestinationMessage = _coerce_message_sample(
            DestinationMessage if DestinationMessage is not None else destination_message
        )
        self.Options = _coerce_options(Options if Options is not None else options)


@dataclass
class LoadStrikeAutopilotLoadSimulationSuggestion(_ContractModelMixin):
    Kind: str = "IterationsForConstant"
    Copies: int = 1
    Iterations: int = 1


@dataclass
class LoadStrikeAutopilotScenarioPlan(_ContractModelMixin):
    Name: str = "autopilot-starter"
    WithoutWarmUp: bool = True
    LoadSimulationSuggestions: List[LoadStrikeAutopilotLoadSimulationSuggestion] = field(
        default_factory=list
    )


@dataclass
class LoadStrikeAutopilotEndpoint(_ContractModelMixin):
    Kind: str = ""
    Name: str = ""
    Method: Optional[str] = None
    Url: Optional[str] = None


@dataclass
class LoadStrikeAutopilotTrackingSelectorSuggestion(_ContractModelMixin):
    Expression: str = ""
    Confidence: float = 0.0


@dataclass
class LoadStrikeAutopilotThresholdSuggestion(_ContractModelMixin):
    Kind: str = ""
    Maximum: float = 0.0


@dataclass
class LoadStrikeAutopilotRedaction(_ContractModelMixin):
    Location: str = ""
    Reason: str = ""
    Replacement: str = "[REDACTED]"


@dataclass
class LoadStrikeAutopilotReadinessFailure(_ContractModelMixin):
    Readiness: str = ""
    Reason: str = ""
    RequiredInput: str = ""
    Locations: List[str] = field(default_factory=list)


@dataclass
class LoadStrikeAutopilotPreviewReport(_ContractModelMixin):
    ScenarioName: str = ""
    Readiness: str = ""
    Signals: List[str] = field(default_factory=list)
    Warnings: List[str] = field(default_factory=list)
    ReadinessFailures: List[LoadStrikeAutopilotReadinessFailure] = field(default_factory=list)
    Redactions: List[LoadStrikeAutopilotRedaction] = field(default_factory=list)


@dataclass
class LoadStrikeAutopilotPlan(_ContractModelMixin):
    Version: str = "trace-to-test-autopilot/v1"
    Scenario: LoadStrikeAutopilotScenarioPlan = field(
        default_factory=LoadStrikeAutopilotScenarioPlan
    )
    Endpoints: List[LoadStrikeAutopilotEndpoint] = field(default_factory=list)
    TrackingSelectorSuggestions: List[LoadStrikeAutopilotTrackingSelectorSuggestion] = field(
        default_factory=list
    )
    ThresholdSuggestions: List[LoadStrikeAutopilotThresholdSuggestion] = field(
        default_factory=list
    )
    Redactions: List[LoadStrikeAutopilotRedaction] = field(default_factory=list)
    Warnings: List[str] = field(default_factory=list)
    Confidence: float = 0.0


@dataclass(init=False)
class LoadStrikeAutopilotResult(_ContractModelMixin):
    Readiness: str
    Plan: LoadStrikeAutopilotPlan
    Endpoints: List[LoadStrikeAutopilotEndpoint]
    Redactions: List[LoadStrikeAutopilotRedaction]
    Warnings: List[str]
    ReadinessFailures: List[LoadStrikeAutopilotReadinessFailure]
    PreviewReport: Optional[LoadStrikeAutopilotPreviewReport]
    ObservedLatencyMs: Optional[float]

    def __init__(
        self,
        readiness: str,
        plan: LoadStrikeAutopilotPlan,
        endpoints: List[LoadStrikeAutopilotEndpoint],
        redactions: List[LoadStrikeAutopilotRedaction],
        warnings: List[str],
        readiness_failures: Optional[List[LoadStrikeAutopilotReadinessFailure]] = None,
        *,
        preview_report: Optional[LoadStrikeAutopilotPreviewReport] = None,
        observed_latency_ms: Optional[float] = None,
        http_request: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.Readiness = readiness
        self.Plan = plan
        self.Endpoints = list(endpoints)
        self.Redactions = list(redactions)
        self.Warnings = list(warnings)
        self.ReadinessFailures = list(readiness_failures or [])
        self.PreviewReport = preview_report
        self.ObservedLatencyMs = observed_latency_ms
        self._http_request = dict(http_request or {}) if http_request else None

    @property
    def readiness(self) -> str:
        return self.Readiness

    @property
    def plan(self) -> LoadStrikeAutopilotPlan:
        return self.Plan

    @property
    def endpoints(self) -> List[LoadStrikeAutopilotEndpoint]:
        return list(self.Endpoints)

    @property
    def redactions(self) -> List[LoadStrikeAutopilotRedaction]:
        return list(self.Redactions)

    @property
    def warnings(self) -> List[str]:
        return list(self.Warnings)

    @property
    def readiness_failures(self) -> List[LoadStrikeAutopilotReadinessFailure]:
        return list(self.ReadinessFailures)

    @property
    def preview_report(self) -> Optional[LoadStrikeAutopilotPreviewReport]:
        return self.PreviewReport

    @preview_report.setter
    def preview_report(self, value: Optional[LoadStrikeAutopilotPreviewReport]) -> None:
        self.PreviewReport = value

    @property
    def observed_latency_ms(self) -> Optional[float]:
        return self.ObservedLatencyMs

    def build_scenario(self) -> LoadStrikeScenario:
        if self.Readiness != LoadStrikeAutopilotReadiness.Ready:
            raise RuntimeError(
                "Autopilot result is not ready to build a scenario. "
                f"Current readiness: {self.Readiness}."
            )
        if not self._http_request:
            raise RuntimeError("Autopilot result does not contain a runnable HTTP request.")

        from .autopilot import _resolve_http_request_secrets

        request = _resolve_http_request_secrets(dict(self._http_request))

        def _run(_context: Any) -> Any:
            return _execute_http_replay(request)

        scenario = (
            LoadStrikeScenario.create(self.Plan.Scenario.Name or "autopilot-starter", _run)
            .without_warm_up()
            .with_load_simulations(LoadStrikeSimulation.iterations_for_constant(1, 1))
        )
        thresholds = [_compile_threshold(item) for item in self.Plan.ThresholdSuggestions]
        if thresholds:
            scenario = scenario.with_thresholds(*thresholds)
        return scenario._with_internal_license_features(TRACE_TO_TEST_AUTOPILOT_FEATURE)

    BuildScenario = build_scenario


def _coerce_options(value: Any) -> Optional[LoadStrikeAutopilotOptions]:
    if value is None or isinstance(value, LoadStrikeAutopilotOptions):
        return value
    if isinstance(value, dict):
        return LoadStrikeAutopilotOptions(
            ScenarioName=value.get("ScenarioName", value.get("scenario_name")),
            IncludePreviewReport=value.get(
                "IncludePreviewReport",
                value.get("include_preview_report", False),
            ),
            AllowedReplayHosts=value.get(
                "AllowedReplayHosts",
                value.get("allowed_replay_hosts", []),
            ),
            BaseUrlRewrite=value.get("BaseUrlRewrite", value.get("base_url_rewrite")),
            TrackingSelector=value.get("TrackingSelector", value.get("tracking_selector")),
            SecretBindings=value.get("SecretBindings", value.get("secret_bindings", [])),
            EndpointBindings=value.get("EndpointBindings", value.get("endpoint_bindings", [])),
        )
    return LoadStrikeAutopilotOptions.from_payload(value)


def _coerce_secret_binding(value: Any) -> LoadStrikeAutopilotSecretBinding:
    if isinstance(value, LoadStrikeAutopilotSecretBinding):
        return value
    if isinstance(value, dict):
        return LoadStrikeAutopilotSecretBinding(
            Location=value.get("Location", value.get("location")),
            ValueFromEnv=value.get("ValueFromEnv", value.get("value_from_env", value.get("valueFromEnv"))),
        )
    return LoadStrikeAutopilotSecretBinding.from_payload(value)


def _coerce_endpoint_binding(value: Any) -> LoadStrikeAutopilotEndpointBinding:
    if isinstance(value, LoadStrikeAutopilotEndpointBinding):
        return value
    if isinstance(value, dict):
        return LoadStrikeAutopilotEndpointBinding(
            Name=value.get("Name", value.get("name")),
            Kind=value.get("Kind", value.get("kind")),
            Method=value.get("Method", value.get("method")),
            Url=value.get("Url", value.get("url")),
        )
    return LoadStrikeAutopilotEndpointBinding.from_payload(value)


def _coerce_message_sample(value: Any) -> Optional[LoadStrikeAutopilotMessageSample]:
    if value is None or isinstance(value, LoadStrikeAutopilotMessageSample):
        return value
    if isinstance(value, dict):
        return LoadStrikeAutopilotMessageSample(
            Name=value.get("Name", value.get("name")),
            ContentType=value.get("ContentType", value.get("content_type", value.get("contentType"))),
            Headers=value.get("Headers", value.get("headers", {})),
            Payload=value.get("Payload", value.get("payload")),
            TransportMetadata=value.get(
                "TransportMetadata",
                value.get("transport_metadata", value.get("transportMetadata", {})),
            ),
        )
    return LoadStrikeAutopilotMessageSample.from_payload(value)


def _compile_threshold(suggestion: LoadStrikeAutopilotThresholdSuggestion) -> Dict[str, Any]:
    if suggestion.Kind == "AllFailCount":
        return LoadStrikeThreshold.scenario("AllFailCount", "<=", suggestion.Maximum)
    return LoadStrikeThreshold.scenario(suggestion.Kind, "<=", suggestion.Maximum)


def _execute_http_replay(request: Dict[str, Any]) -> Any:
    method = str(request.get("method") or "GET").upper()
    url = str(request.get("url") or "")
    body = request.get("body")
    data = body.encode("utf-8") if isinstance(body, str) else None
    headers = {
        str(key): str(value)
        for key, value in dict(request.get("headers") or {}).items()
    }
    content_type = str(request.get("content_type") or "")
    if content_type and not any(key.lower() == "content-type" for key in headers):
        headers["content-type"] = content_type

    try:
        replay_request = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method=method,
        )
        with urllib.request.urlopen(replay_request, timeout=30) as response:
            payload = response.read()
            status_code = int(getattr(response, "status", response.getcode()))
            if 200 <= status_code < 400:
                return LoadStrikeResponse.ok(str(status_code), len(payload))
            return LoadStrikeResponse.fail(
                str(status_code),
                f"HTTP replay returned {status_code}.",
                len(payload),
            )
    except urllib.error.HTTPError as error:
        payload = error.read()
        return LoadStrikeResponse.fail(
            str(error.code),
            f"HTTP replay returned {error.code}.",
            len(payload),
        )
    except Exception as exc:  # pragma: no cover - defensive runtime surface
        return LoadStrikeResponse.fail("autopilot_http_error", str(exc))
