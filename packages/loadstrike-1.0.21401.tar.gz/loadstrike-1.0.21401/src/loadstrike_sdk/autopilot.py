from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .autopilot_contracts import (
    LoadStrikeAutopilotEndpointBinding,
    LoadStrikeAutopilotEndpoint,
    LoadStrikeAutopilotLoadSimulationSuggestion,
    LoadStrikeAutopilotMessageSample,
    LoadStrikeAutopilotOptions,
    LoadStrikeAutopilotPlan,
    LoadStrikeAutopilotPreviewReport,
    LoadStrikeAutopilotReadiness,
    LoadStrikeAutopilotReadinessFailure,
    LoadStrikeAutopilotRedaction,
    LoadStrikeAutopilotRequest,
    LoadStrikeAutopilotResult,
    LoadStrikeAutopilotScenarioPlan,
    LoadStrikeAutopilotSecretBinding,
    LoadStrikeAutopilotThresholdSuggestion,
    LoadStrikeAutopilotTrackingSelectorSuggestion,
)

REDACTED = "[REDACTED]"
ENV_MARKER_PREFIX = "${LOADSTRIKE_ENV:"
ENV_MARKER_SUFFIX = "}"
SECRET_KEYS = {
    "authorization",
    "proxy_authorization",
    "proxy-authorization",
    "cookie",
    "set_cookie",
    "set-cookie",
    "x_api_key",
    "x-api-key",
    "token",
    "access_token",
    "refresh_token",
    "password",
    "secret",
    "client_secret",
    "api_key",
    "apikey",
}


class LoadStrikeAutopilot:
    @staticmethod
    def generate(request: Any) -> LoadStrikeAutopilotResult:
        artifact = _load_artifact(request)
        options = artifact["options"]
        result = _infer_result(artifact, options)
        if options.IncludePreviewReport:
            result.PreviewReport = _build_preview_report(result)
        return result

    Generate = generate


def _load_artifact(request: Any) -> Dict[str, Any]:
    if isinstance(request, dict):
        request = LoadStrikeAutopilotRequest(
            Kind=request.get("Kind", request.get("kind")),
            FilePath=request.get("FilePath", request.get("file_path")),
            Content=request.get("Content", request.get("content")),
            SourceMessage=request.get("SourceMessage", request.get("source_message")),
            DestinationMessage=request.get(
                "DestinationMessage",
                request.get("destination_message"),
            ),
            Options=request.get("Options", request.get("options")),
        )
    elif not isinstance(request, LoadStrikeAutopilotRequest):
        request = LoadStrikeAutopilotRequest.from_payload(request)

    kind = (request.Kind or "").strip()
    if not kind:
        raise ValueError("Autopilot kind must be provided.")

    options = request.Options or LoadStrikeAutopilotOptions()
    if _equals_kind(kind, "MessagePair"):
        return {
            "kind": kind,
            "source_message": request.SourceMessage,
            "destination_message": request.DestinationMessage,
            "options": options,
        }

    content = request.Content
    if (content is None or not str(content).strip()) and request.FilePath:
        content = Path(request.FilePath).read_text(encoding="utf-8")
    if content is None or not str(content).strip():
        raise ValueError("Autopilot content or file path must be provided.")

    try:
        root = json.loads(str(content))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Autopilot {kind} artifact is invalid JSON.") from exc

    return {"kind": kind, "root": root, "options": options}


def _infer_result(
    artifact: Dict[str, Any],
    options: LoadStrikeAutopilotOptions,
) -> LoadStrikeAutopilotResult:
    kind = artifact["kind"]
    if _equals_kind(kind, "Har"):
        return _from_har(artifact, options)
    if _equals_kind(kind, "OtelTrace"):
        return _from_otel_trace(artifact, options)
    if _equals_kind(kind, "PlaywrightRecording"):
        return _from_playwright_recording(artifact, options)
    if _equals_kind(kind, "MessagePair"):
        return _from_message_pair(artifact, options)
    raise ValueError(f"Unsupported Autopilot kind '{kind}'.")


def _from_har(
    artifact: Dict[str, Any],
    options: LoadStrikeAutopilotOptions,
) -> LoadStrikeAutopilotResult:
    root = _as_dict(artifact.get("root"))
    entries = _as_list(_as_dict(root.get("log")).get("entries"))
    if not entries:
        return _build_review_result(options, "HAR artifact does not contain any entries.")

    entry = _as_dict(entries[0])
    request = _as_dict(entry.get("request"))
    url = _as_string(request.get("url"))
    if not url:
        return _build_review_result(options, "HAR request does not contain a URL.")

    headers: Dict[str, str] = {}
    for header in _as_list(request.get("headers")):
        item = _as_dict(header)
        name = _as_string(item.get("name"))
        if name:
            headers[name] = _as_string(item.get("value")) or ""

    post_data = _as_dict(request.get("postData"))
    return _build_http_result(
        options,
        method=_as_string(request.get("method")) or "GET",
        url=url,
        headers=headers,
        body=_as_string(post_data.get("text")),
        content_type=_header_value(headers, "content-type") or _as_string(post_data.get("mimeType")),
        observed_latency_ms=_as_number(entry.get("time")),
    )


def _from_otel_trace(
    artifact: Dict[str, Any],
    options: LoadStrikeAutopilotOptions,
) -> LoadStrikeAutopilotResult:
    span = _find_first_span(_as_dict(artifact.get("root")))
    if not span:
        return _build_review_result(
            options,
            "OpenTelemetry artifact does not contain any spans.",
        )

    attributes = _read_otel_attributes(span)
    url = attributes.get("url.full") or attributes.get("http.url")
    if not url:
        return _build_review_result(
            options,
            "OpenTelemetry span does not contain an HTTP URL.",
        )

    headers: Dict[str, str] = {}
    prefix = "http.request.header."
    for key, value in attributes.items():
        if key.lower().startswith(prefix):
            headers[key[len(prefix) :]] = value

    return _build_http_result(
        options,
        method=attributes.get("http.request.method") or attributes.get("http.method") or "GET",
        url=url,
        headers=headers,
        observed_latency_ms=_read_span_duration_ms(span),
    )


def _from_playwright_recording(
    artifact: Dict[str, Any],
    options: LoadStrikeAutopilotOptions,
) -> LoadStrikeAutopilotResult:
    network = _as_list(_as_dict(artifact.get("root")).get("network"))
    if not network:
        return _build_review_result(
            options,
            "Playwright recording does not contain any network entries.",
        )

    entry = _as_dict(network[0])
    url = _as_string(entry.get("url"))
    if not url:
        return _build_review_result(
            options,
            "Playwright network entry does not contain a URL.",
        )

    headers = {
        str(key): str(value)
        for key, value in _as_dict(entry.get("requestHeaders")).items()
    }
    request_body = entry.get("requestBody")
    body = request_body if isinstance(request_body, str) else json.dumps(request_body)
    if request_body is None:
        body = None

    return _build_http_result(
        options,
        method=_as_string(entry.get("method")) or "GET",
        url=url,
        headers=headers,
        body=body,
        content_type=_header_value(headers, "content-type"),
        observed_latency_ms=_as_number(entry.get("durationMs")),
    )


def _from_message_pair(
    artifact: Dict[str, Any],
    options: LoadStrikeAutopilotOptions,
) -> LoadStrikeAutopilotResult:
    source = artifact.get("source_message")
    destination = artifact.get("destination_message")
    if not source or not destination:
        return _build_review_result(
            options,
            "MessagePair input requires both source and destination messages.",
        )

    inferred_selector = _find_shared_header_selector(source.Headers, destination.Headers)
    selector = inferred_selector or (options.TrackingSelector or "").strip() or None
    endpoints, missing_bindings = _apply_endpoint_bindings(
        [
            LoadStrikeAutopilotEndpoint(
                Kind="DelegateStream",
                Name=source.Name or "source",
            ),
            LoadStrikeAutopilotEndpoint(
                Kind="DelegateStream",
                Name=destination.Name or "destination",
            ),
        ],
        options.EndpointBindings,
    )
    failures: List[LoadStrikeAutopilotReadinessFailure] = []
    if not selector:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresTrackingSelector,
                "No stable shared tracking ID was found across the source and destination messages.",
                "TrackingSelector",
            )
        )
    if missing_bindings:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresEndpointBinding,
                "Message pair input requires explicit endpoint binding before it can run.",
                "EndpointBindings",
                missing_bindings,
            )
        )
    if not failures:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresReview,
                "Message pair endpoint bindings were supplied, but automatic runnable scenario generation currently supports HTTP replay artifacts only.",
                "ManualReview",
            )
        )
    readiness = failures[0].Readiness
    return _build_result(
        readiness=readiness,
        options=options,
        endpoints=endpoints,
        tracking_suggestions=[
            LoadStrikeAutopilotTrackingSelectorSuggestion(
                Expression=selector,
                Confidence=0.9 if inferred_selector else 1.0,
            )
        ]
        if selector
        else [],
        threshold_suggestions=_seed_thresholds(None),
        redactions=[],
        warnings=[failure.Reason for failure in failures],
        readiness_failures=failures,
        confidence=0.7,
    )


def _build_http_result(
    options: LoadStrikeAutopilotOptions,
    *,
    method: str,
    url: str,
    headers: Dict[str, str],
    body: Optional[str] = None,
    content_type: Optional[str] = None,
    observed_latency_ms: Optional[float] = None,
) -> LoadStrikeAutopilotResult:
    redactions: List[LoadStrikeAutopilotRedaction] = []
    secret_bindings = _secret_binding_map(options.SecretBindings)
    unresolved_secret_locations: List[str] = []

    def _mark_unresolved(location: str) -> None:
        unresolved_secret_locations.append(location)

    next_headers = _redact_headers(headers, redactions, secret_bindings, _mark_unresolved)
    next_body = _redact_body(body, redactions, secret_bindings, _mark_unresolved)
    next_url = _redact_url(url, redactions, secret_bindings, _mark_unresolved)
    target_url, target_ready, target_warning = _resolve_replay_url(next_url, options)
    selector = _infer_tracking_selector(next_headers, next_body) or (options.TrackingSelector or "").strip() or None

    failures: List[LoadStrikeAutopilotReadinessFailure] = []
    if unresolved_secret_locations:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresSecrets,
                "Secret bindings are required for every redacted header, query parameter, or body field before replay can run.",
                "SecretBindings",
                unresolved_secret_locations,
            )
        )
    if not target_ready:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresTargetBinding,
                target_warning or "Captured target requires explicit replay binding before replay can run.",
                "AllowedReplayHosts|BaseUrlRewrite|EndpointBindings[source-http]",
                ["source-http"],
            )
        )
    if not selector:
        failures.append(
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresTrackingSelector,
                "No stable tracking selector could be inferred from the artifact.",
                "TrackingSelector",
            )
        )

    readiness = (
        LoadStrikeAutopilotReadiness.Ready
        if not failures
        else failures[0].Readiness
    )

    endpoint = LoadStrikeAutopilotEndpoint(
        Kind="Http",
        Name="source-http",
        Method=method.upper(),
        Url=target_url,
    )
    return _build_result(
        readiness=readiness,
        options=options,
        endpoints=[endpoint],
        tracking_suggestions=[
            LoadStrikeAutopilotTrackingSelectorSuggestion(Expression=selector, Confidence=0.9)
        ]
        if selector
        else [],
        threshold_suggestions=_seed_thresholds(observed_latency_ms),
        redactions=redactions,
        warnings=[failure.Reason for failure in failures],
        readiness_failures=failures,
        http_request={
            "method": method.upper(),
            "url": target_url,
            "headers": next_headers,
            "body": next_body,
            "content_type": content_type,
        }
        if readiness == LoadStrikeAutopilotReadiness.Ready
        else None,
        observed_latency_ms=observed_latency_ms,
        confidence=0.9 if readiness == LoadStrikeAutopilotReadiness.Ready else 0.5,
    )


def _build_review_result(
    options: LoadStrikeAutopilotOptions,
    warning: str,
) -> LoadStrikeAutopilotResult:
    return _build_result(
        readiness=LoadStrikeAutopilotReadiness.RequiresReview,
        options=options,
        endpoints=[],
        tracking_suggestions=[],
        threshold_suggestions=_seed_thresholds(None),
        redactions=[],
        warnings=[warning],
        readiness_failures=[
            _readiness_failure(
                LoadStrikeAutopilotReadiness.RequiresReview,
                warning,
                "ManualReview",
            )
        ],
        confidence=0.1,
    )


def _build_result(
    *,
    readiness: str,
    options: LoadStrikeAutopilotOptions,
    endpoints: List[LoadStrikeAutopilotEndpoint],
    tracking_suggestions: List[LoadStrikeAutopilotTrackingSelectorSuggestion],
    threshold_suggestions: List[LoadStrikeAutopilotThresholdSuggestion],
    redactions: List[LoadStrikeAutopilotRedaction],
    warnings: List[str],
    readiness_failures: List[LoadStrikeAutopilotReadinessFailure],
    confidence: float,
    http_request: Optional[Dict[str, Any]] = None,
    observed_latency_ms: Optional[float] = None,
) -> LoadStrikeAutopilotResult:
    scenario_name = (options.ScenarioName or "").strip() or "autopilot-starter"
    plan = LoadStrikeAutopilotPlan(
        Version="trace-to-test-autopilot/v1",
        Scenario=LoadStrikeAutopilotScenarioPlan(
            Name=scenario_name,
            WithoutWarmUp=True,
            LoadSimulationSuggestions=[
                LoadStrikeAutopilotLoadSimulationSuggestion(
                    Kind="IterationsForConstant",
                    Copies=1,
                    Iterations=1,
                )
            ],
        ),
        Endpoints=endpoints,
        TrackingSelectorSuggestions=tracking_suggestions,
        ThresholdSuggestions=threshold_suggestions,
        Redactions=redactions,
        Warnings=warnings,
        Confidence=confidence,
    )
    return LoadStrikeAutopilotResult(
        readiness,
        plan,
        endpoints,
        redactions,
        warnings,
        readiness_failures,
        http_request=http_request,
        observed_latency_ms=observed_latency_ms,
    )


def _build_preview_report(
    result: LoadStrikeAutopilotResult,
) -> LoadStrikeAutopilotPreviewReport:
    return LoadStrikeAutopilotPreviewReport(
        ScenarioName=result.Plan.Scenario.Name,
        Readiness=result.Readiness,
        Redactions=result.Redactions,
        Warnings=result.Warnings,
        ReadinessFailures=result.ReadinessFailures,
        Signals=[
            f"readiness:{result.Readiness}",
            f"endpoints:{len(result.Endpoints)}",
            f"trackingSelectors:{len(result.Plan.TrackingSelectorSuggestions)}",
            f"thresholdSuggestions:{len(result.Plan.ThresholdSuggestions)}",
        ],
    )


def _seed_thresholds(
    observed_latency_ms: Optional[float],
) -> List[LoadStrikeAutopilotThresholdSuggestion]:
    latency_budget = max(100, int(((observed_latency_ms or 100) * 1.5) + 0.9999))
    return [
        LoadStrikeAutopilotThresholdSuggestion(Kind="AllFailCount", Maximum=0),
        LoadStrikeAutopilotThresholdSuggestion(Kind="LatencyP95Ms", Maximum=latency_budget),
        LoadStrikeAutopilotThresholdSuggestion(
            Kind="LatencyP99Ms",
            Maximum=int((latency_budget * 1.25) + 0.9999),
        ),
    ]


def _redact_headers(
    headers: Dict[str, str],
    redactions: List[LoadStrikeAutopilotRedaction],
    bindings: Dict[str, str],
    mark_unresolved: Any,
) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for key, value in headers.items():
        if _is_secret_key(key):
            location = f"header:{key}"
            result[key] = _replacement_for_location(location, bindings, mark_unresolved)
            redactions.append(
                LoadStrikeAutopilotRedaction(
                    Location=location,
                    Reason="secret-like header",
                    Replacement=REDACTED,
                )
            )
        else:
            result[key] = str(value)
    return result


def _redact_url(
    url: str,
    redactions: List[LoadStrikeAutopilotRedaction],
    bindings: Dict[str, str],
    mark_unresolved: Any,
) -> str:
    parsed = urlparse(url)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if not pairs:
        return url

    changed = False
    redacted_pairs: List[Tuple[str, str]] = []
    for key, value in pairs:
        if _is_secret_key(key):
            location = f"query:{key}"
            redacted_pairs.append((key, _replacement_for_location(location, bindings, mark_unresolved)))
            redactions.append(
                LoadStrikeAutopilotRedaction(
                    Location=location,
                    Reason="secret-like query parameter",
                    Replacement=REDACTED,
                )
            )
            changed = True
        else:
            redacted_pairs.append((key, value))
    if not changed:
        return url
    return urlunparse(parsed._replace(query=urlencode(redacted_pairs)))


def _redact_body(
    body: Optional[str],
    redactions: List[LoadStrikeAutopilotRedaction],
    bindings: Dict[str, str],
    mark_unresolved: Any,
) -> Optional[str]:
    if body is None or not body.strip():
        return body
    try:
        value = json.loads(body)
    except json.JSONDecodeError:
        return body

    changed = _redact_json_value(value, "$", redactions, bindings, mark_unresolved)
    return json.dumps(value, separators=(",", ":")) if changed else body


def _redact_json_value(
    value: Any,
    path: str,
    redactions: List[LoadStrikeAutopilotRedaction],
    bindings: Dict[str, str],
    mark_unresolved: Any,
) -> bool:
    changed = False
    if isinstance(value, list):
        for index, item in enumerate(value):
            changed = _redact_json_value(item, f"{path}[{index}]", redactions, bindings, mark_unresolved) or changed
    elif isinstance(value, dict):
        for key in list(value.keys()):
            if _is_secret_key(str(key)):
                location = f"body:{path}.{key}"
                value[key] = _replacement_for_location(location, bindings, mark_unresolved)
                redactions.append(
                    LoadStrikeAutopilotRedaction(
                        Location=location,
                        Reason="secret-like body key",
                        Replacement=REDACTED,
                    )
                )
                changed = True
            else:
                changed = _redact_json_value(value[key], f"{path}.{key}", redactions, bindings, mark_unresolved) or changed
    return changed


def _secret_binding_map(bindings: List[LoadStrikeAutopilotSecretBinding]) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for binding in bindings:
        location = _normalize_binding_location(binding.Location)
        env = (binding.ValueFromEnv or "").strip()
        if location and env:
            result[location] = env
    return result


def _replacement_for_location(location: str, bindings: Dict[str, str], mark_unresolved: Any) -> str:
    env = bindings.get(_normalize_binding_location(location))
    if env:
        return f"{ENV_MARKER_PREFIX}{env}{ENV_MARKER_SUFFIX}"
    mark_unresolved(location)
    return REDACTED


def _readiness_failure(
    readiness: str,
    reason: str,
    required_input: str,
    locations: Optional[List[str]] = None,
) -> LoadStrikeAutopilotReadinessFailure:
    seen = set()
    normalized_locations: List[str] = []
    for location in locations or []:
        normalized = str(location).strip()
        key = normalized.lower()
        if normalized and key not in seen:
            seen.add(key)
            normalized_locations.append(normalized)
    return LoadStrikeAutopilotReadinessFailure(
        Readiness=readiness,
        Reason=reason,
        RequiredInput=required_input,
        Locations=normalized_locations,
    )


def _normalize_binding_location(location: Optional[str]) -> str:
    return (location or "").strip().lower()


def _parse_env_marker(value: str) -> Optional[str]:
    trimmed = value.strip()
    if trimmed.startswith(ENV_MARKER_PREFIX) and trimmed.endswith(ENV_MARKER_SUFFIX):
        env = trimmed[len(ENV_MARKER_PREFIX) : -len(ENV_MARKER_SUFFIX)].strip()
        return env or None
    return None


def _resolve_secret_marker(value: str) -> str:
    env = _parse_env_marker(value)
    if not env:
        return value
    if env not in os.environ:
        raise RuntimeError(f"Autopilot secret environment variable '{env}' is not set.")
    return os.environ[env]


def _resolve_http_request_secrets(request: Dict[str, Any]) -> Dict[str, Any]:
    next_request = dict(request)
    next_request["headers"] = {
        str(key): _resolve_secret_marker(str(value))
        for key, value in dict(request.get("headers") or {}).items()
    }
    next_request["url"] = _resolve_url_secret_markers(str(request.get("url") or ""))
    next_request["body"] = _resolve_body_secret_markers(request.get("body"))
    return next_request


def _resolve_url_secret_markers(raw_url: str) -> str:
    parsed = urlparse(raw_url)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if not pairs:
        return _resolve_secret_marker(raw_url)
    changed = False
    resolved_pairs: List[Tuple[str, str]] = []
    for key, value in pairs:
        resolved = _resolve_secret_marker(value)
        changed = changed or resolved != value
        resolved_pairs.append((key, resolved))
    return urlunparse(parsed._replace(query=urlencode(resolved_pairs))) if changed else raw_url


def _resolve_body_secret_markers(body: Any) -> Any:
    if not isinstance(body, str) or not body.strip():
        return body
    try:
        value = json.loads(body)
    except json.JSONDecodeError:
        return _resolve_secret_marker(body)
    changed = _resolve_json_secret_markers(value)
    return json.dumps(value, separators=(",", ":")) if changed else body


def _resolve_json_secret_markers(value: Any) -> bool:
    changed = False
    if isinstance(value, list):
        for index, item in enumerate(value):
            if isinstance(item, str):
                resolved = _resolve_secret_marker(item)
                if resolved != item:
                    value[index] = resolved
                    changed = True
            else:
                changed = _resolve_json_secret_markers(item) or changed
    elif isinstance(value, dict):
        for key, item in list(value.items()):
            if isinstance(item, str):
                resolved = _resolve_secret_marker(item)
                if resolved != item:
                    value[key] = resolved
                    changed = True
            else:
                changed = _resolve_json_secret_markers(item) or changed
    return changed


def _apply_endpoint_bindings(
    endpoints: List[LoadStrikeAutopilotEndpoint],
    bindings: List[LoadStrikeAutopilotEndpointBinding],
) -> Tuple[List[LoadStrikeAutopilotEndpoint], List[str]]:
    by_name = {
        binding.Name.strip().lower(): binding
        for binding in bindings
        if binding.Name and binding.Name.strip()
    }
    result: List[LoadStrikeAutopilotEndpoint] = []
    missing: List[str] = []
    for endpoint in endpoints:
        binding = by_name.get(endpoint.Name.strip().lower())
        if binding is None:
            missing.append(endpoint.Name)
            result.append(endpoint)
            continue
        result.append(
            LoadStrikeAutopilotEndpoint(
                Kind=(binding.Kind or "").strip() or endpoint.Kind,
                Name=endpoint.Name,
                Method=(binding.Method or "").strip() or endpoint.Method,
                Url=(binding.Url or "").strip() or endpoint.Url,
            )
        )
    return result, missing


def _endpoint_binding_url(bindings: List[LoadStrikeAutopilotEndpointBinding], name: str) -> Optional[str]:
    for binding in bindings:
        if binding.Name.strip().lower() == name.lower() and binding.Url and binding.Url.strip():
            return binding.Url.strip()
    return None


def _resolve_replay_url(
    url: str,
    options: LoadStrikeAutopilotOptions,
) -> Tuple[str, bool, Optional[str]]:
    parsed = urlparse(url)
    endpoint_url = _endpoint_binding_url(options.EndpointBindings, "source-http")
    if endpoint_url:
        return endpoint_url, True, None
    if options.BaseUrlRewrite:
        base = urlparse(options.BaseUrlRewrite)
        if base.scheme and base.netloc:
            rewritten = urlunparse(
                (
                    base.scheme,
                    base.netloc,
                    parsed.path or "/",
                    "",
                    parsed.query,
                    "",
                )
            )
            return rewritten, True, None

    if not parsed.scheme or not parsed.netloc:
        return url, False, "Captured URL is not absolute and requires target binding."

    allowed = {str(host).lower() for host in options.AllowedReplayHosts}
    host = (parsed.hostname or "").lower()
    if _is_loopback_host(host) or host in allowed:
        return url, True, None
    return (
        url,
        False,
        f"Captured host '{host}' requires AllowedReplayHosts or BaseUrlRewrite before replay.",
    )


def _infer_tracking_selector(headers: Dict[str, str], body: Optional[str]) -> Optional[str]:
    for key in ["x-correlation-id", "correlation-id", "traceparent"]:
        if _header_value(headers, key):
            return f"header:{key}"
    if not body:
        return None
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        return None
    if isinstance(parsed, dict) and "orderId" in parsed:
        return "json:$.orderId"
    return None


def _find_shared_header_selector(
    source: Dict[str, str],
    destination: Dict[str, str],
) -> Optional[str]:
    for key, value in source.items():
        if _header_value(destination, key) == value:
            return f"header:{key}"
    return None


def _read_otel_attributes(span: Dict[str, Any]) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for attribute in _as_list(span.get("attributes")):
        item = _as_dict(attribute)
        key = _as_string(item.get("key"))
        if not key:
            continue
        value = _as_dict(item.get("value"))
        result[key] = (
            _as_string(value.get("stringValue"))
            or _as_string(value.get("intValue"))
            or json.dumps(value)
        )
    return result


def _find_first_span(root: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    for resource_span in _as_list(root.get("resourceSpans")):
        for scope_span in _as_list(_as_dict(resource_span).get("scopeSpans")):
            spans = _as_list(_as_dict(scope_span).get("spans"))
            if spans:
                return _as_dict(spans[0])
    return None


def _read_span_duration_ms(span: Dict[str, Any]) -> Optional[float]:
    try:
        start = int(_as_string(span.get("startTimeUnixNano")) or "0")
        end = int(_as_string(span.get("endTimeUnixNano")) or "0")
    except ValueError:
        return None
    if end < start:
        return None
    return float(end - start) / 1_000_000


def _header_value(headers: Dict[str, str], name: str) -> Optional[str]:
    for key, value in headers.items():
        if key.lower() == name.lower():
            return value
    return None


def _is_secret_key(key: str) -> bool:
    lower = key.lower()
    return lower in SECRET_KEYS or lower.replace("-", "_") in SECRET_KEYS


def _is_loopback_host(host: str) -> bool:
    return host in {"localhost", "127.0.0.1", "::1"}


def _equals_kind(actual: str, expected: str) -> bool:
    return actual.lower() == expected.lower()


def _as_dict(value: Any) -> Dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def _as_string(value: Any) -> Optional[str]:
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    return None


def _as_number(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None
