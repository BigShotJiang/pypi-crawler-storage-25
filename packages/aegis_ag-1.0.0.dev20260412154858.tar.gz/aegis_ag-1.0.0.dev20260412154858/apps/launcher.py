"""Shared launcher for editable installs and checkout-backed wrappers."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys
from typing import Final

from apps.cli.__main__ import main as cli_main
from packages.profile import DEFAULT_SOUL_TEXT

DEFAULT_PROFILE_MANIFEST: Final[dict[str, object]] = {
    "profile_id": "profile-local",
    "display_name": "Aegis",
    "mode": "her",
    "preferences": [
        "tone:grounded",
        "memory:durable",
        "identity:aegis",
    ],
    "her_mode": {
        "personality_preset": "companion",
        "personality": [
            "warm",
            "present",
            "grounded",
        ],
        "initiative": "gentle",
        "notes": [
            "protect continuity",
            "carry the durable thread",
        ],
    },
    "enabled_capabilities": [
        "cli.primary",
    ],
}


def _default_install_root() -> Path:
    override = os.environ.get("AEGIS_HOME")
    if override:
        return Path(override).expanduser()
    xdg_data_home = os.environ.get("XDG_DATA_HOME")
    if xdg_data_home:
        return Path(xdg_data_home).expanduser() / "aegis"
    return Path.home() / ".local" / "share" / "aegis"


def _default_state_dir() -> Path:
    override = os.environ.get("AEGIS_STATE_DIR")
    if override:
        return Path(override).expanduser()
    return _default_install_root() / "state"


def _default_profile_dir() -> Path:
    override = os.environ.get("AEGIS_PROFILE_DIR")
    if override:
        return Path(override).expanduser()
    return _default_install_root() / "profile"


def _ensure_profile_bundle(profile_dir: Path) -> None:
    profile_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = profile_dir / "profile.json"
    soul_path = profile_dir / "SOUL.md"
    if not manifest_path.exists():
        manifest_path.write_text(
            json.dumps(DEFAULT_PROFILE_MANIFEST, indent=2) + "\n",
            encoding="utf-8",
        )
    if not soul_path.exists():
        soul_path.write_text(DEFAULT_SOUL_TEXT, encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    state_dir = _default_state_dir()
    profile_dir = _default_profile_dir()
    state_dir.mkdir(parents=True, exist_ok=True)
    _ensure_profile_bundle(profile_dir)
    resolved_argv = list(sys.argv[1:] if argv is None else argv)
    forwarded = [
        "--state-dir",
        str(state_dir),
        "--profile-dir",
        str(profile_dir),
        *resolved_argv,
    ]
    return cli_main(forwarded)


if __name__ == "__main__":
    raise SystemExit(main())
