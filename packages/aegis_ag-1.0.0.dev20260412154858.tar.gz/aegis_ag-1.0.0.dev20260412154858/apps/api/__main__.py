from __future__ import annotations

from argparse import ArgumentParser
from pathlib import Path
from wsgiref.simple_server import make_server

from . import create_app


def main() -> int:
    parser = ArgumentParser(description="Run the Aegis API surface locally.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument(
        "--database",
        default=str(Path(".aegis-api.sqlite3")),
        help="SQLite database path for session state.",
    )
    args = parser.parse_args()

    app = create_app(database_path=Path(args.database))
    with make_server(args.host, args.port, app) as server:
        print(f"Serving Aegis API on http://{args.host}:{args.port}")
        server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
