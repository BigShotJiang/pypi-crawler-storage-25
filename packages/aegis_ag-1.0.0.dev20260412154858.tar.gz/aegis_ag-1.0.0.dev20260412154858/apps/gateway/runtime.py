"""Gateway application bootstrap and real messaging adapter pair."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
import tempfile
from typing import Any
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    load_provider_profile,
    provider_fallback_summary,
    provider_profile_from_payload,
    provider_profile_summary,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore
from packages.capabilities.runtime import (
    CapabilityDescriptor,
    ContextCapability,
    MemoryCapability,
    ModelProviderCapability,
    PlanningCapability,
    TelemetrySinkCapability,
)
from packages.context import ContextRuntime
from packages.contracts.runtime import (
    ContextBundle,
    EventEnvelope,
    ExecutionResult,
    GoalNode,
    MemoryRecord,
    ProfileState,
    SessionState,
)
from packages.gateway_core import (
    FileGatewayIdentityStore,
    FileGatewaySessionStore,
    GatewayCoreDependencies,
    GatewayCoreService,
    GatewayExchange,
    GatewayIdentityRecord,
    GatewayInboundMessage,
    InMemoryGatewayIdentityStore,
    InMemoryGatewaySessionStore,
)
from packages.kernel import KernelDependencies, KernelService, KernelTurnRequest
from packages.memory import MemoryRuntime
from packages.planning import GoalGraph, PlanningDecision, PlanningMode, PlanningService
from packages.profile import DEFAULT_SOUL_TEXT, LoadedProfile, ProfileLoader, build_prompt_contract
from packages.security.runtime import SecurityPolicy
from packages.storage import RuntimeStorageRepository
from packages.voice import VoiceInputRequest, VoiceInputResolution, VoiceTurnResult, build_provider_voice_service

CHAT_BOT_ADAPTER_ID = "messaging.chat-bot"
WEBHOOK_ADAPTER_ID = "messaging.webhook"
TELEGRAM_ADAPTER_ID = "messaging.telegram"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _string_map(payload: Mapping[str, object] | None) -> dict[str, str]:
    if payload is None:
        return {}
    return {str(key): str(value) for key, value in payload.items()}


def _telegram_display_name(payload: Mapping[str, object]) -> str | None:
    first_name = str(payload.get("first_name") or "").strip()
    last_name = str(payload.get("last_name") or "").strip()
    username = str(payload.get("username") or "").strip()
    combined = " ".join(part for part in (first_name, last_name) if part)
    if combined:
        return combined
    if username:
        return f"@{username}"
    return None


def _telegram_attachment_ids(message: Mapping[str, object]) -> tuple[str, ...]:
    attachments: list[str] = []
    photos = message.get("photo")
    if isinstance(photos, list):
        for item in photos:
            if isinstance(item, Mapping) and item.get("file_id") is not None:
                attachments.append(str(item["file_id"]))
    for key in ("document", "audio", "video", "voice", "sticker"):
        value = message.get(key)
        if isinstance(value, Mapping) and value.get("file_id") is not None:
            attachments.append(str(value["file_id"]))
    return tuple(dict.fromkeys(attachments))


def _telegram_delivery_defaults(chat_type: str) -> tuple[bool, bool, bool]:
    if chat_type == "private":
        return True, True, False
    return False, False, True


def _telegram_conversation_id(chat_id: str, thread_id: object | None) -> str:
    if thread_id is None:
        return chat_id
    return f"{chat_id}:{thread_id}"


def _runtime_database_path(state_dir: Path | None) -> Path:
    if state_dir is not None:
        state_dir.mkdir(parents=True, exist_ok=True)
        return state_dir / "gateway-runtime.sqlite3"
    return Path(tempfile.mkdtemp(prefix="aegis-gateway-runtime-")) / "gateway-runtime.sqlite3"


def _default_loaded_profile(profile_id: str) -> LoadedProfile:
    state = ProfileState(
        profile_id=profile_id,
        display_name="Aegis",
        mode="her",
    )
    return LoadedProfile(
        state=state,
        her_mode=None,
        soul_text=DEFAULT_SOUL_TEXT,
        profile_dir="",
        manifest_path=None,
    )


class GatewayTelemetrySink(TelemetrySinkCapability):
    def __init__(self) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.telemetry",
            kind="telemetry_sink",
            version="1.0.0",
            metadata={"description": "In-process telemetry sink for gateway shared-runtime turns."},
        )
        self._events: list[dict[str, Any]] = []

    @property
    def events(self) -> tuple[dict[str, Any], ...]:
        return tuple(self._events)

    def emit(self, event: Mapping[str, Any]) -> None:
        self._events.append(dict(event))


class GatewayMemoryCapability(MemoryCapability):
    def __init__(self, runtime: MemoryRuntime) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.memory",
            kind="memory",
            version="1.0.0",
            metadata={"description": "Shared memory adapter for gateway turns."},
        )
        self.runtime = runtime

    def record(self, memory: MemoryRecord) -> None:
        self.runtime.store.upsert(memory)

    def search(self, session_id: str, query: str) -> tuple[MemoryRecord, ...]:
        result = self.runtime.retrieve(session_id, query)
        return tuple(candidate.record for candidate in result.candidates)


class GatewayContextCapability(ContextCapability):
    def __init__(self, profile: LoadedProfile, *, total_tokens: int = 3072) -> None:
        self.prompt_contract = build_prompt_contract(profile, prompt_mode="full")
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.context",
            kind="context",
            version="1.0.0",
            metadata={"description": "Prompt-contract-aware context adapter for gateway turns."},
        )
        self.runtime = ContextRuntime(
            instruction_refs=self.prompt_contract.instruction_refs,
            total_tokens=total_tokens,
        )

    def assemble(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
    ) -> ContextBundle:
        bundle = self.runtime.assemble(session, goals, memories)
        return replace(
            bundle,
            bundle_id=f"bundle:{session.session_id}:{len(goals)}:{len(memories)}",
            instruction_refs=self.prompt_contract.instruction_refs,
        )


class GatewayPlanningCapability(PlanningCapability):
    def __init__(self, service: PlanningService) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.planning",
            kind="planning",
            version="1.0.0",
            metadata={"description": "Shared planning adapter for gateway turns."},
        )
        self.service = service

    def choose_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        memories: tuple[MemoryRecord, ...] = (),
        mode: PlanningMode = "guided",
        now: datetime | None = None,
    ) -> PlanningDecision:
        return self.service.choose_next_step(
            session=session,
            graph=graph,
            memories=memories,
            mode=mode,
            now=now,
        )


class GatewayPreviewModelProvider(ModelProviderCapability):
    def __init__(self) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="gateway.model.preview",
            kind="model_provider",
            version="1.0.0",
            metadata={"description": "Deterministic conversational fallback for gateway turns."},
        )

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        normalized = prompt.strip()
        lowered = normalized.lower()
        if not normalized:
            summary = "I'm here with you."
        elif "who are you" in lowered:
            summary = "I'm Aegis, your persistent AI, staying with the thread across time."
        elif normalized.endswith("?"):
            summary = f"I’m tracking this with you: {normalized}"
        else:
            summary = f"I’m with you on this: {normalized}"
        return ExecutionResult(
            execution_id=f"gateway.model:{session.session_id}:{uuid4().hex}",
            session_id=session.session_id,
            outcome="ok",
            summary=summary,
            side_effects=("gateway-preview-provider", profile.mode),
        )


class GatewaySurfaceModelProvider(ModelProviderCapability):
    def __init__(
        self,
        *,
        repository: RuntimeStorageRepository,
        fallback: ModelProviderCapability,
        active_provider_profile: AuthProfile | None,
    ) -> None:
        self.surface = SurfaceModelProviderCapability(
            repository=repository,
            fallback=fallback,
            active_provider_profile_id=(
                active_provider_profile.profile_id if active_provider_profile is not None else None
            ),
            active_provider_id=(
                active_provider_profile.provider_id if active_provider_profile is not None else None
            ),
            capability_id="gateway.model.runtime",
            surface_label="gateway",
        )
        self.descriptor = self.surface.descriptor
        self.fallback = fallback

    def describe(self) -> Mapping[str, object]:
        return self.surface.describe()

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        try:
            return self.surface.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        except LookupError:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )


@dataclass(frozen=True, slots=True)
class GatewayApp:
    core: GatewayCoreService
    profile_id: str
    provider_runtime: Mapping[str, object]
    repository: RuntimeStorageRepository
    auth_store: PersistentAuthProfileStore
    memory_runtime: MemoryRuntime
    kernel: KernelService
    telemetry: GatewayTelemetrySink
    model_provider: GatewaySurfaceModelProvider
    workspace_id: str | None = None
    profile_dir: str | None = None
    state_dir: str | None = None
    loaded_profile: LoadedProfile | None = None
    provider_profile: AuthProfile | None = None

    def handle_message(
        self,
        inbound: GatewayInboundMessage,
        *,
        reply_body: str | None = None,
        reply_to_event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, str] | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
    ) -> GatewayExchange:
        route = self.core.route_inbound(
            inbound,
            profile_id=self.profile_id,
            workspace_id=self.workspace_id,
        )
        session = self._ensure_runtime_session(route.session)
        event = self._event_for_inbound(inbound, session_id=session.session_id)
        self.memory_runtime.append_event(event)
        outcome = self.kernel.run(
            KernelTurnRequest(
                event=event,
                prompt=inbound.body,
            )
        )
        refreshed_session = outcome.session
        self.core.dependencies.session_store.save(refreshed_session)
        route = replace(route, session=refreshed_session)
        provider_summary = self.model_provider.describe()
        delivery = self.core.deliver(
            route,
            body=reply_body or outcome.execution.summary,
            reply_to_event_id=reply_to_event_id or inbound.event_id,
            attachments=attachments,
            metadata={
                **dict(metadata or {}),
                "runtime_surface": "gateway.shared-runtime",
                "context_bundle_id": outcome.context.bundle_id,
                "execution_id": outcome.execution.execution_id,
                "provider_id": str(provider_summary.get("provider_id") or "preview"),
            },
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        return GatewayExchange(route=route, delivery=delivery)

    def provider_summary(self) -> Mapping[str, object]:
        return dict(self.model_provider.describe())

    def voice_summary(self) -> Mapping[str, object]:
        return self._build_voice_service().provider_summary()

    def voice_doctor(self) -> Mapping[str, object]:
        if self.loaded_profile is None:
            return {
                "status": "not-ready",
                "checks": (
                    {"check": "profile_bundle", "status": "missing"},
                ),
                "supported_path": "one-shot gateway voice remains subordinate to the text delivery path",
                "non_goals": (
                    "always-on duplex voice",
                    "provider-specific delivery forks in the gateway layer",
                ),
                "provider": self.voice_summary(),
            }
        return self._build_voice_service().doctor(self.loaded_profile)

    def setup_summary(self) -> Mapping[str, object]:
        return {
            "profile_id": self.profile_id,
            "profile_dir": self.profile_dir,
            "state_dir": self.state_dir,
            "workspace_id": self.workspace_id,
            "adapters": {
                "chat_bot": CHAT_BOT_ADAPTER_ID,
                "webhook": WEBHOOK_ADAPTER_ID,
                "telegram": TELEGRAM_ADAPTER_ID,
            },
            "adapter_setup": {
                "chat_bot": {
                    "adapter_id": CHAT_BOT_ADAPTER_ID,
                    "surface": "local-chat",
                    "operator_action": "none",
                },
                "webhook": {
                    "adapter_id": WEBHOOK_ADAPTER_ID,
                    "surface": "generic-webhook",
                    "operator_action": "supply callback_url in inbound payload",
                },
                "telegram": {
                    "adapter_id": TELEGRAM_ADAPTER_ID,
                    "surface": "telegram-bot-api",
                    "operator_action": "configure TELEGRAM_BOT_TOKEN and forward Bot API updates into the gateway",
                    "identity_mapping": "chat.id + from.id (+ message_thread_id when present)",
                    "supported_updates": ("message", "edited_message", "callback_query"),
                    "delivery_defaults": {
                        "private": "allow",
                        "group": "review",
                        "supergroup": "review",
                        "channel": "review",
                    },
                },
            },
            "provider": dict(self.provider_runtime),
            "voice": dict(self.voice_summary()),
        }

    def identity_records(self) -> tuple[GatewayIdentityRecord, ...]:
        return self.core.dependencies.identity_store.list_records()

    def session_records(self) -> tuple[SessionState, ...]:
        return self.core.dependencies.session_store.list_records()

    def memory_records(self, session_id: str | None = None) -> tuple[MemoryRecord, ...]:
        return self.memory_runtime.store.list(session_id=session_id)

    def interrupt_session(
        self,
        session_id: str,
        *,
        interruption_state: str,
        interrupted_at: datetime | None = None,
    ) -> SessionState:
        session = self.core.dependencies.session_store.lookup(session_id)
        if session is None:
            raise KeyError(session_id)
        updated = replace(
            session,
            status="interrupted",
            interruption_state=interruption_state,
            updated_at=interrupted_at or _utc_now(),
        )
        self.core.dependencies.session_store.save(updated)
        self.repository.upsert_session(updated)
        return updated

    def handle_voice_message(
        self,
        inbound: GatewayInboundMessage,
        *,
        audio_bytes: bytes,
        audio_name: str,
        audio_format: str | None = None,
        reply_body: str | None = None,
        reply_to_event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, str] | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> "GatewayVoiceExchange":
        if self.loaded_profile is None:
            raise ValueError("gateway voice mode requires a loaded profile bundle")
        voice_service = self._build_voice_service()
        voice_session = voice_service.open_session(
            self.loaded_profile,
            f"session:{inbound.adapter_id}:{inbound.conversation_id}",
        )
        resolution = voice_service.resolve_input(
            self.loaded_profile,
            voice_session,
            VoiceInputRequest(
                request_id=f"{inbound.event_id}:voice",
                session_id=voice_session.session_id,
                profile_id=self.profile_id,
                source="provider-backed",
                consent_given=consent_given,
                recording_enabled=False,
                metadata={"adapter_id": inbound.adapter_id},
                audio_bytes=audio_bytes,
                audio_format=audio_format,
                audio_name=audio_name,
            ),
        )
        normalized_inbound = GatewayInboundMessage(
            event_id=inbound.event_id,
            adapter_id=inbound.adapter_id,
            conversation_id=inbound.conversation_id,
            external_user_id=inbound.external_user_id,
            body=resolution.transcript or inbound.body,
            display_name=inbound.display_name,
            attachments=inbound.attachments,
            received_at=inbound.received_at,
            metadata={
                **dict(inbound.metadata),
                "voice_input_source": resolution.request.source,
                **{key: value for key, value in resolution.metadata.items() if value},
            },
        )
        exchange = self.handle_message(
            normalized_inbound,
            reply_body=reply_body,
            reply_to_event_id=reply_to_event_id,
            attachments=attachments,
            metadata=metadata,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )
        voice_turn = voice_service.complete_output(
            self.loaded_profile,
            voice_session,
            resolution,
            response_transcript=exchange.delivery.summary,
            voice_output_enabled=voice_output_enabled,
            audio_format=output_audio_format,
        )
        if exchange.delivery.outbound is not None:
            outbound = replace(
                exchange.delivery.outbound,
                metadata={
                    **dict(exchange.delivery.outbound.metadata),
                    **(
                        dict(voice_turn.output.metadata)
                        if voice_turn.output is not None and voice_turn.output.metadata is not None
                        else {}
                    ),
                    "voice_output_mode": voice_turn.output.delivery_mode if voice_turn.output is not None else "text",
                    "voice_output_provider_id": (
                        voice_turn.output.provider_id
                        if voice_turn.output is not None and voice_turn.output.provider_id is not None
                        else ""
                    ),
                },
            )
            exchange = GatewayExchange(
                route=exchange.route,
                delivery=replace(exchange.delivery, outbound=outbound),
            )
        return GatewayVoiceExchange(
            exchange=exchange,
            input_resolution=resolution,
            voice_turn=voice_turn,
        )

    def _build_voice_service(self):
        return build_provider_voice_service(provider_profile=self.provider_profile)

    def _ensure_runtime_session(self, session: SessionState) -> SessionState:
        existing = self.repository.load_session(session.session_id)
        if existing is None:
            resolved = session
        else:
            resolved = replace(
                existing,
                workspace_id=session.workspace_id,
                status=session.status,
                updated_at=session.updated_at,
                interruption_state=session.interruption_state,
            )
        self.repository.upsert_session(resolved)
        return resolved

    def _event_for_inbound(
        self,
        inbound: GatewayInboundMessage,
        *,
        session_id: str,
    ) -> EventEnvelope:
        payload = {
            "message": inbound.body,
            "content": inbound.body,
            "summary": inbound.body,
            "adapter_id": inbound.adapter_id,
            "conversation_id": inbound.conversation_id,
            "external_user_id": inbound.external_user_id,
            "display_name": inbound.display_name or "",
            "attachments": ",".join(inbound.attachments),
            **dict(inbound.metadata),
        }
        return EventEnvelope(
            event_id=f"gateway:{inbound.event_id}",
            event_type="turn.received",
            session_id=session_id,
            source=f"gateway:{inbound.adapter_id}",
            payload=payload,
        )


@dataclass(frozen=True, slots=True)
class GatewayVoiceExchange:
    exchange: GatewayExchange
    input_resolution: VoiceInputResolution
    voice_turn: VoiceTurnResult


@dataclass(frozen=True, slots=True)
class ChatBotMessagingAdapter:
    app: GatewayApp
    adapter_id: str = CHAT_BOT_ADAPTER_ID

    def receive_text(
        self,
        *,
        conversation_id: str,
        external_user_id: str,
        body: str,
        display_name: str | None = None,
        event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, object] | None = None,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
    ) -> GatewayExchange:
        inbound = GatewayInboundMessage(
            event_id=event_id or f"{self.adapter_id}:{conversation_id}:{external_user_id}",
            adapter_id=self.adapter_id,
            conversation_id=conversation_id,
            external_user_id=external_user_id,
            body=body,
            display_name=display_name,
            attachments=attachments,
            metadata=_string_map(metadata),
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            attachments=attachments,
            metadata={
                "channel": "chat-bot",
                **_string_map(metadata),
            },
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )

    def receive_voice(
        self,
        *,
        conversation_id: str,
        external_user_id: str,
        audio_bytes: bytes,
        audio_name: str,
        audio_format: str | None = None,
        display_name: str | None = None,
        event_id: str | None = None,
        attachments: tuple[str, ...] = (),
        metadata: Mapping[str, object] | None = None,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> GatewayVoiceExchange:
        inbound = GatewayInboundMessage(
            event_id=event_id or f"{self.adapter_id}:{conversation_id}:{external_user_id}:voice",
            adapter_id=self.adapter_id,
            conversation_id=conversation_id,
            external_user_id=external_user_id,
            body="voice-input",
            display_name=display_name,
            attachments=attachments,
            metadata=_string_map(metadata),
        )
        return self.app.handle_voice_message(
            inbound,
            audio_bytes=audio_bytes,
            audio_name=audio_name,
            audio_format=audio_format,
            reply_body=reply_body,
            attachments=attachments,
            metadata={
                "channel": "chat-bot",
                **_string_map(metadata),
            },
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
            voice_output_enabled=voice_output_enabled,
            output_audio_format=output_audio_format,
        )


@dataclass(frozen=True, slots=True)
class WebhookMessagingAdapter:
    app: GatewayApp
    adapter_id: str = WEBHOOK_ADAPTER_ID

    def receive_event(
        self,
        payload: Mapping[str, object],
        *,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
    ) -> GatewayExchange:
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("event_id") or payload.get("message_id") or payload["conversation_id"]),
            adapter_id=self.adapter_id,
            conversation_id=str(payload["conversation_id"]),
            external_user_id=str(payload["external_user_id"]),
            body=str(payload["body"]),
            display_name=(
                str(payload["display_name"])
                if payload.get("display_name") is not None
                else None
            ),
            attachments=tuple(str(item) for item in payload.get("attachments", ())),
            metadata={
                "channel": "webhook",
                **_string_map(payload.get("metadata")),
            },
        )
        response_metadata = {
            "channel": "webhook",
            **_string_map(payload.get("metadata")),
        }
        callback_url = payload.get("callback_url")
        if callback_url is not None:
            response_metadata["callback_url"] = str(callback_url)
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_event_id=(
                str(payload["reply_to_event_id"])
                if payload.get("reply_to_event_id") is not None
                else inbound.event_id
            ),
            attachments=inbound.attachments,
            metadata=response_metadata,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
        )

    def receive_voice_event(
        self,
        payload: Mapping[str, object],
        *,
        reply_body: str | None = None,
        target_trusted: bool = True,
        consent_given: bool = True,
        is_external: bool = False,
        voice_output_enabled: bool = False,
        output_audio_format: str = "mp3",
    ) -> GatewayVoiceExchange:
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("event_id") or payload.get("message_id") or payload["conversation_id"]),
            adapter_id=self.adapter_id,
            conversation_id=str(payload["conversation_id"]),
            external_user_id=str(payload["external_user_id"]),
            body="voice-input",
            display_name=(
                str(payload["display_name"])
                if payload.get("display_name") is not None
                else None
            ),
            attachments=tuple(str(item) for item in payload.get("attachments", ())),
            metadata={
                "channel": "webhook",
                **_string_map(payload.get("metadata")),
            },
        )
        response_metadata = {
            "channel": "webhook",
            **_string_map(payload.get("metadata")),
        }
        callback_url = payload.get("callback_url")
        if callback_url is not None:
            response_metadata["callback_url"] = str(callback_url)
        return self.app.handle_voice_message(
            inbound,
            audio_bytes=bytes(payload["audio_bytes"]),
            audio_name=str(payload.get("audio_name") or "voice-input.wav"),
            audio_format=str(payload.get("audio_format")) if payload.get("audio_format") is not None else None,
            reply_body=reply_body,
            reply_to_event_id=(
                str(payload["reply_to_event_id"])
                if payload.get("reply_to_event_id") is not None
                else inbound.event_id
            ),
            attachments=inbound.attachments,
            metadata=response_metadata,
            target_trusted=target_trusted,
            consent_given=consent_given,
            is_external=is_external,
            voice_output_enabled=voice_output_enabled,
            output_audio_format=output_audio_format,
        )


@dataclass(frozen=True, slots=True)
class TelegramMessagingAdapter:
    app: GatewayApp
    adapter_id: str = TELEGRAM_ADAPTER_ID

    def receive_update(
        self,
        payload: Mapping[str, object],
        *,
        reply_body: str | None = None,
        target_trusted: bool | None = None,
        consent_given: bool | None = None,
        is_external: bool | None = None,
    ) -> GatewayExchange:
        update_kind = "message"
        message = payload.get("message")
        callback_data: str | None = None
        if not isinstance(message, Mapping):
            message = payload.get("edited_message")
            if isinstance(message, Mapping):
                update_kind = "edited_message"
        if not isinstance(message, Mapping):
            callback_query = payload.get("callback_query")
            if isinstance(callback_query, Mapping):
                nested_message = callback_query.get("message")
                if isinstance(nested_message, Mapping):
                    message = nested_message
                    update_kind = "callback_query"
                    if callback_query.get("data") is not None:
                        callback_data = str(callback_query["data"])
                    if not isinstance(message.get("from"), Mapping) and isinstance(
                        callback_query.get("from"), Mapping
                    ):
                        message = {
                            **message,
                            "from": callback_query["from"],
                        }
        if not isinstance(message, Mapping):
            raise ValueError("telegram update requires message, edited_message, or callback_query.message")
        chat = message.get("chat")
        sender = message.get("from")
        if not isinstance(chat, Mapping) or not isinstance(sender, Mapping):
            raise ValueError("telegram update requires chat and from payloads")
        chat_id = str(chat["id"])
        chat_type = str(chat.get("type") or "private")
        thread_id = message.get("message_thread_id")
        attachments = _telegram_attachment_ids(message)
        metadata = {
            "channel": "telegram",
            "chat_type": chat_type,
            "update_kind": update_kind,
            "chat_id": chat_id,
        }
        if sender.get("username") is not None:
            metadata["username"] = str(sender["username"])
        if thread_id is not None:
            metadata["message_thread_id"] = str(thread_id)
        if message.get("reply_to_message") is not None:
            metadata["reply_to_message_id"] = str(
                dict(message["reply_to_message"]).get("message_id") or ""
            )
        if callback_data is not None:
            metadata["callback_data"] = callback_data
        target_trusted_default, consent_default, external_default = _telegram_delivery_defaults(chat_type)
        inbound = GatewayInboundMessage(
            event_id=str(payload.get("update_id") or message.get("message_id") or chat["id"]),
            adapter_id=self.adapter_id,
            conversation_id=_telegram_conversation_id(chat_id, thread_id),
            external_user_id=str(sender["id"]),
            body=str(message.get("text") or message.get("caption") or callback_data or "telegram-event"),
            display_name=_telegram_display_name(sender),
            attachments=attachments,
            metadata=metadata,
        )
        return self.app.handle_message(
            inbound,
            reply_body=reply_body,
            reply_to_event_id=metadata.get("reply_to_message_id") or inbound.event_id,
            attachments=attachments,
            metadata={
                **metadata,
                "delivery_surface": "telegram-bot-api",
            },
            target_trusted=target_trusted_default if target_trusted is None else target_trusted,
            consent_given=consent_default if consent_given is None else consent_given,
            is_external=external_default if is_external is None else is_external,
        )


def build_gateway_app(
    *,
    profile_id: str = "profile:default",
    workspace_id: str | None = None,
    provider_profile: Mapping[str, Any] | None = None,
    profile_dir: str | Path | None = None,
    state_dir: str | Path | None = None,
) -> tuple[GatewayApp, ChatBotMessagingAdapter, WebhookMessagingAdapter]:
    resolved_profile_dir = Path(profile_dir) if profile_dir is not None else None
    resolved_state_dir = Path(state_dir) if state_dir is not None else None
    loaded_profile: LoadedProfile | None = None

    if resolved_profile_dir is not None:
        loader = ProfileLoader(resolved_profile_dir)
        loaded_profile = (
            loader.load()
            if profile_id == "profile:default"
            else loader.load(profile_id=profile_id)
        )
        profile_id = loaded_profile.state.profile_id
    else:
        loaded_profile = _default_loaded_profile(profile_id)

    if resolved_state_dir is None:
        identity_store = InMemoryGatewayIdentityStore()
        session_store = InMemoryGatewaySessionStore()
    else:
        identity_store = FileGatewayIdentityStore(
            resolved_state_dir / "gateway-identities.json"
        )
        session_store = FileGatewaySessionStore(
            resolved_state_dir / "gateway-sessions.json"
        )

    telemetry = GatewayTelemetrySink()
    core = GatewayCoreService(
        GatewayCoreDependencies(
            identity_store=identity_store,
            session_store=session_store,
            security_policy=SecurityPolicy.default(),
            default_profile_id=profile_id,
            default_workspace_id=workspace_id,
            telemetry_sink=telemetry,
        )
    )
    runtime_repository = RuntimeStorageRepository(_runtime_database_path(resolved_state_dir))
    runtime_repository.bootstrap()
    runtime_repository.upsert_profile(loaded_profile.state)
    auth_store = PersistentAuthProfileStore(runtime_repository)

    resolved_provider_profile = provider_profile
    loaded_provider_profile: AuthProfile | None = None
    if resolved_provider_profile is None and resolved_profile_dir is not None:
        loaded_provider_profile = load_provider_profile(resolved_profile_dir)
        if loaded_provider_profile is not None:
            provider_runtime = provider_profile_summary(loaded_provider_profile)
        else:
            provider_runtime = provider_fallback_summary()
    elif resolved_provider_profile is None:
        provider_runtime = provider_fallback_summary()
    else:
        loaded_provider_profile = provider_profile_from_payload(resolved_provider_profile)
        provider_runtime = provider_profile_summary(loaded_provider_profile)
    if loaded_provider_profile is not None:
        auth_store.register(loaded_provider_profile)

    preview_model_provider = GatewayPreviewModelProvider()
    model_provider = GatewaySurfaceModelProvider(
        repository=runtime_repository,
        fallback=preview_model_provider,
        active_provider_profile=loaded_provider_profile,
    )
    memory_runtime = MemoryRuntime.from_repository(runtime_repository)
    kernel = KernelService(
        dependencies=KernelDependencies(
            storage=runtime_repository,
            context=GatewayContextCapability(loaded_profile),
            planning=GatewayPlanningCapability(PlanningService()),
            memory=GatewayMemoryCapability(memory_runtime),
            model_provider=model_provider,
            telemetry=telemetry,
        )
    )

    app = GatewayApp(
        core=core,
        profile_id=profile_id,
        workspace_id=workspace_id,
        provider_runtime=provider_runtime,
        repository=runtime_repository,
        auth_store=auth_store,
        memory_runtime=memory_runtime,
        kernel=kernel,
        telemetry=telemetry,
        model_provider=model_provider,
        profile_dir=str(resolved_profile_dir) if resolved_profile_dir is not None else None,
        state_dir=str(resolved_state_dir) if resolved_state_dir is not None else None,
        loaded_profile=loaded_profile,
        provider_profile=loaded_provider_profile,
    )
    return (
        app,
        ChatBotMessagingAdapter(app=app),
        WebhookMessagingAdapter(app=app),
    )
