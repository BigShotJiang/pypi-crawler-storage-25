"""Shared provider runtime wiring for product surfaces.

This module keeps surface-level provider profile parsing, environment-backed
credential lookup, and runtime capability selection in one place so CLI, API,
and gateway do not each keep private copies of the same rules.
"""

from __future__ import annotations

from collections.abc import Mapping
import json
import os
from pathlib import Path
from typing import Any

from packages.auth import (
    AuthProfile,
    PersistentAuthProfileStore,
    ProfileCredentialResolver,
    ProviderCatalog,
    ProviderProfileFactory,
    ProviderProfileInput,
    SecretReference,
    SecretStore,
    profile_from_input,
)
from packages.capabilities.runtime import CapabilityDescriptor, ModelProviderCapability
from packages.contracts.runtime import ContextBundle, ExecutionResult, ProfileState, SessionState
from packages.models import ModelRequest, ProviderRuntimeResolver, build_model_adapter
from packages.storage import RuntimeStorageRepository


def provider_profile_from_payload(payload: Mapping[str, Any]) -> AuthProfile:
    secret_references = tuple(
        secret_reference_from_payload(item)
        for item in payload.get("secret_references", ())
    )
    profile_input = ProviderProfileInput(
        profile_id=str(payload["profile_id"]),
        provider_id=str(payload["provider_id"]),
        secret_references=secret_references,
        priority=int(payload.get("priority", 0)),
        session_pin=str(payload["session_pin"]) if payload.get("session_pin") is not None else None,
        cooldown_until=None,
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )
    provider_id = profile_input.provider_id
    base_url = payload.get("base_url")
    default_model = payload.get("default_model")
    transport_id = payload.get("transport_id")
    auth_method = payload.get("auth_method")
    provider_kind = payload.get("provider_kind")
    extra_headers = payload.get("extra_headers")
    catalog = ProviderCatalog.with_defaults()
    provider_defaults = catalog.get(provider_id)
    if provider_id == "openai-compatible" and (base_url is None or default_model is None):
        raise ValueError("openai-compatible provider profiles require base_url and default_model")
    if any(value is not None for value in (base_url, default_model, transport_id, auth_method, provider_kind, extra_headers)):
        default_profile = None
        if provider_defaults is not None:
            default_profile = ProviderProfileFactory(catalog).from_provider_defaults(
                provider_id,
                profile_id=profile_input.profile_id,
                secret_references=profile_input.secret_references,
                priority=profile_input.priority,
                session_pin=profile_input.session_pin,
                cooldown_until=profile_input.cooldown_until,
                metadata=profile_input.metadata,
            )
        return profile_from_input(
            profile_input,
            base_url=(
                str(base_url)
                if base_url is not None
                else (default_profile.base_url if default_profile is not None else "")
            ),
            default_model=(
                str(default_model)
                if default_model is not None
                else (default_profile.default_model if default_profile is not None else "")
            ),
            transport_id=(
                str(transport_id)
                if transport_id is not None
                else (default_profile.transport_id if default_profile is not None else "openai-compatible")
            ),
            auth_method=(
                str(auth_method)
                if auth_method is not None
                else (default_profile.auth_method if default_profile is not None else "api_key")
            ),
            provider_kind=(
                str(provider_kind)
                if provider_kind is not None
                else (default_profile.provider_kind if default_profile is not None else "custom")
            ),
            extra_headers=(
                {
                    **(dict(default_profile.extra_headers) if default_profile is not None else {}),
                    **{str(key): str(value) for key, value in dict(extra_headers or {}).items()},
                }
            ),
        )
    factory = ProviderProfileFactory(catalog)
    return factory.from_provider_defaults(
        provider_id,
        profile_id=profile_input.profile_id,
        secret_references=profile_input.secret_references,
        priority=profile_input.priority,
        session_pin=profile_input.session_pin,
        cooldown_until=profile_input.cooldown_until,
        metadata=profile_input.metadata,
    )


def secret_reference_from_payload(payload: Mapping[str, Any]) -> SecretReference:
    return SecretReference(
        reference_id=str(payload["reference_id"]),
        provider_id=str(payload["provider_id"]),
        secret_name=str(payload["secret_name"]),
        secret_key=str(payload["secret_key"]),
        source=str(payload.get("source", "workspace")),
        metadata={str(key): str(value) for key, value in dict(payload.get("metadata", {})).items()},
    )


def load_provider_profile(profile_dir: Path) -> AuthProfile | None:
    manifest_path = profile_dir / "profile.json"
    if not manifest_path.exists():
        return None
    with manifest_path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("profile.json must contain a JSON object")
    provider_payload = payload.get("provider_profile")
    if not isinstance(provider_payload, dict):
        return None
    return provider_profile_from_payload(provider_payload)


def provider_profile_summary(profile: AuthProfile) -> dict[str, Any]:
    return {
        "profile_id": profile.profile_id,
        "provider_id": profile.provider_id,
        "transport_id": profile.transport_id,
        "base_url": profile.base_url,
        "default_model": profile.default_model,
        "auth_method": profile.auth_method,
        "provider_kind": profile.provider_kind,
        "extra_headers": dict(profile.extra_headers),
        "secret_reference_ids": tuple(reference.reference_id for reference in profile.secret_references),
        "source": "configured",
    }


def provider_fallback_summary() -> dict[str, Any]:
    return {
        "profile_id": "",
        "provider_id": "preview",
        "transport_id": "preview",
        "base_url": None,
        "default_model": None,
        "auth_method": "preview",
        "provider_kind": "preview",
        "extra_headers": {},
        "secret_reference_ids": (),
        "source": "preview-fallback",
    }


class EnvironmentSecretStore(SecretStore):
    def read(self, reference: SecretReference) -> str:
        candidates = (
            reference.metadata.get("env_var"),
            reference.metadata.get("env"),
            reference.metadata.get("environment_variable"),
            reference.secret_name,
            reference.secret_key,
            reference.reference_id,
        )
        for candidate in candidates:
            if not candidate:
                continue
            normalized = normalize_env_name(candidate)
            value = os.environ.get(normalized)
            if value is not None:
                return value
        raise LookupError(f"missing environment secret for reference: {reference.reference_id}")


class SurfaceModelProviderCapability(ModelProviderCapability):
    def __init__(
        self,
        *,
        repository: RuntimeStorageRepository,
        fallback: ModelProviderCapability,
        credential_resolver: ProfileCredentialResolver | None = None,
        active_provider_profile_id: str | None = None,
        active_provider_id: str | None = None,
        capability_id: str = "surface.model.runtime",
        surface_label: str = "surface",
    ) -> None:
        self.repository = repository
        self.fallback = fallback
        self.credential_resolver = credential_resolver or ProfileCredentialResolver(EnvironmentSecretStore())
        self.active_provider_profile_id = active_provider_profile_id
        self.active_provider_id = active_provider_id
        self.runtime_resolver = ProviderRuntimeResolver.default()
        self.descriptor = CapabilityDescriptor(
            capability_id=capability_id,
            kind="model_provider",
            version="1.0.0",
            metadata={"description": f"{surface_label} model provider runtime wired to persisted provider profiles."},
        )

    def set_active_profile(
        self,
        *,
        provider_profile_id: str | None,
        provider_id: str | None,
    ) -> None:
        self.active_provider_profile_id = provider_profile_id
        self.active_provider_id = provider_id

    def active_profile(self) -> AuthProfile | None:
        if self.active_provider_profile_id is not None:
            profile = self.repository.load_auth_profile(self.active_provider_profile_id)
            if profile is not None:
                return profile
        if self.active_provider_id is not None:
            try:
                return self.repository.select_auth_profile(self.active_provider_id)
            except LookupError:
                return None
        return None

    def describe(self) -> Mapping[str, object]:
        profile = self.active_profile()
        if profile is None:
            return provider_fallback_summary()
        return provider_profile_summary(profile)

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        active_profile = self.active_profile()
        if active_profile is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )

        request = ModelRequest(
            request_id=f"{session.session_id}:model",
            profile_id=profile.profile_id,
            session_id=session.session_id,
            provider_id=active_profile.provider_id,
            model_id=active_profile.default_model or "",
            prompt=prompt,
            context={
                "bundle_id": context.bundle_id,
                "token_budget": str(context.token_budget),
                "instruction_refs": ",".join(context.instruction_refs),
                "goal_ids": ",".join(context.goal_ids),
                "memory_ids": ",".join(context.memory_ids),
                "artifact_ids": ",".join(context.artifact_ids),
                "rendered_prompt": context.rendered_prompt or "",
            },
            metadata={
                "profile_mode": profile.mode,
                "session_status": session.status,
                "provider_profile_id": active_profile.profile_id,
            },
        )

        credentials = self.credential_resolver.resolve(active_profile).as_mapping()
        adapter = build_model_adapter(
            active_profile,
            runtime_resolver=self.runtime_resolver,
            credentials=credentials,
            adapter_id=f"adapter.models.{active_profile.provider_id}.surface",
        )
        if adapter is None:
            return self.fallback.generate(
                profile=profile,
                session=session,
                context=context,
                prompt=prompt,
            )
        result = adapter.generate(request, credentials)
        return ExecutionResult(
            execution_id=result.result_id,
            session_id=session.session_id,
            outcome="ok" if result.failure_kind is None else "failed",
            summary=result.content,
            telemetry_event_ids=(request.request_id,),
            side_effects=(
                f"provider={result.provider_id}",
                f"model={result.model_id}",
                f"transport={result.metadata.get('transport_id', 'unknown')}",
                f"credential_keys={result.metadata.get('credential_keys', 'unknown')}",
            ),
        )

def register_provider_profile(
    repository: RuntimeStorageRepository,
    payload: Mapping[str, Any],
) -> AuthProfile:
    profile = provider_profile_from_payload(payload)
    PersistentAuthProfileStore(repository).register(profile)
    return profile


def normalize_env_name(candidate: str) -> str:
    return candidate.replace("-", "_").replace(".", "_").upper()
