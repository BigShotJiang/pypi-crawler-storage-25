"""Thin operator console wired to the API surface.

The console renders inspection views for sessions, goals, memories, providers,
and policy. It does not own any runtime policy or kernel behavior; it only reads
the public API surface that already landed in `apps/api`.
"""

from __future__ import annotations

from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import parse_qs
import json

from apps.api.runtime import AegisAPIApp, create_app as create_api_app
from packages.contracts import ExecutionResult


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, tuple):
        return ", ".join(_text(item) for item in value)
    if isinstance(value, list):
        return ", ".join(_text(item) for item in value)
    if isinstance(value, Mapping):
        return json.dumps(value, indent=2, sort_keys=True)
    return str(value)


def _lines(value: Any) -> str:
    return escape(_text(value)).replace("\n", "<br>")


def _page(title: str, body: str) -> bytes:
    html = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{escape(title)}</title>
    <style>
      :root {{
        color-scheme: dark;
        --bg: #0b1020;
        --panel: #121a33;
        --panel-alt: #0f1730;
        --line: rgba(255,255,255,0.12);
        --text: #e8ecff;
        --muted: #9aa7d1;
        --accent: #9bd4ff;
        --accent-2: #82ffd0;
      }}
      * {{ box-sizing: border-box; }}
      body {{
        margin: 0;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        background:
          radial-gradient(circle at top left, rgba(155, 212, 255, 0.16), transparent 28%),
          radial-gradient(circle at top right, rgba(130, 255, 208, 0.12), transparent 24%),
          var(--bg);
        color: var(--text);
      }}
      main {{
        max-width: 1180px;
        margin: 0 auto;
        padding: 40px 24px 64px;
      }}
      header {{
        display: flex;
        justify-content: space-between;
        gap: 24px;
        align-items: end;
        margin-bottom: 28px;
      }}
      h1, h2, h3, p {{ margin: 0; }}
      h1 {{
        font-size: 38px;
        line-height: 1.05;
        letter-spacing: -0.03em;
      }}
      .subtle {{ color: var(--muted); max-width: 760px; line-height: 1.6; }}
      .grid {{
        display: grid;
        grid-template-columns: repeat(12, minmax(0, 1fr));
        gap: 16px;
      }}
      .card {{
        background: linear-gradient(180deg, rgba(255,255,255,0.04), transparent), var(--panel);
        border: 1px solid var(--line);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 24px 72px rgba(0,0,0,0.22);
      }}
      .card.alt {{ background: var(--panel-alt); }}
      .span-12 {{ grid-column: span 12; }}
      .span-8 {{ grid-column: span 8; }}
      .span-6 {{ grid-column: span 6; }}
      .span-4 {{ grid-column: span 4; }}
      .span-3 {{ grid-column: span 3; }}
      .span-2 {{ grid-column: span 2; }}
      .eyebrow {{
        color: var(--accent);
        text-transform: uppercase;
        letter-spacing: 0.18em;
        font-size: 11px;
        margin-bottom: 10px;
      }}
      .meta {{
        color: var(--muted);
        font-size: 13px;
        line-height: 1.45;
      }}
      .row {{
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 10px;
      }}
      .pill {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 10px;
        border-radius: 999px;
        background: rgba(255,255,255,0.06);
        color: var(--text);
        border: 1px solid var(--line);
        font-size: 12px;
      }}
      .pill strong {{ color: var(--accent-2); }}
      pre {{
        white-space: pre-wrap;
        margin: 0;
        color: var(--text);
        line-height: 1.5;
        font-size: 13px;
      }}
      a {{ color: var(--accent); text-decoration: none; }}
      a:hover {{ text-decoration: underline; }}
      .section-title {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
      }}
      .list {{
        display: grid;
        gap: 12px;
      }}
      .item {{
        border: 1px solid var(--line);
        background: rgba(255,255,255,0.03);
        border-radius: 14px;
        padding: 14px;
      }}
      .item h3 {{ font-size: 16px; margin-bottom: 6px; }}
      .kv {{
        display: grid;
        gap: 6px;
        font-size: 13px;
      }}
      .kv div {{
        display: flex;
        gap: 10px;
        align-items: baseline;
      }}
      .kv dt {{
        min-width: 140px;
        color: var(--muted);
      }}
      .kv dd {{
        margin: 0;
        color: var(--text);
      }}
      .nav {{
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
      }}
      @media (max-width: 900px) {{
        .span-8, .span-6, .span-4, .span-3, .span-2 {{ grid-column: span 12; }}
        header {{ flex-direction: column; align-items: start; }}
      }}
    </style>
  </head>
  <body>
    <main>
      {body}
    </main>
  </body>
</html>"""
    return html.encode("utf-8")


def _json_response(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")


def _form_data(body: bytes | None) -> dict[str, str]:
    if not body:
        return {}
    parsed = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    return {key: values[0] if values else "" for key, values in parsed.items()}


@dataclass(frozen=True, slots=True)
class ConsoleAppConfig:
    database_path: Path
    instruction_refs: tuple[str, ...] = ("apps/api",)
    total_tokens: int = 2048


class AegisConsoleApp:
    def __init__(self, config: ConsoleAppConfig) -> None:
        self.config = config
        self.api = create_api_app(
            database_path=config.database_path,
            instruction_refs=config.instruction_refs,
            total_tokens=config.total_tokens,
        )

    def _session_summary(self, session_id: str) -> Mapping[str, Any]:
        inspection = self.api.inspect_session(session_id)
        latest_turn = inspection.latest_turn
        outcome = latest_turn.outcome if latest_turn is not None else None
        goals = inspection.goals
        memories = inspection.memories
        providers = tuple(
            (
                descriptor.capability_id,
                descriptor.kind,
                descriptor.version,
                descriptor.metadata,
            )
            for descriptor in (
                self.api.model_provider.descriptor,
                self.api.planning.descriptor,
                self.api.context.descriptor,
                self.api.memory.descriptor,
                self.api.tools.descriptor,
                self.api.delivery.descriptor,
                self.api.telemetry.descriptor,
            )
        )
        policy = {
            "profile_mode": inspection.profile.mode,
            "session_status": inspection.session.status,
            "interruption_state": inspection.session.interruption_state,
            "enabled_capabilities": inspection.profile.enabled_capabilities,
            "tool_catalog": [
                {
                    "tool_id": tool.tool_id,
                    "display_name": tool.display_name,
                    "version": tool.version,
                    "risk_class": tool.side_effects.risk_class,
                    "approval_class": tool.side_effects.approval_class,
                    "writes_state": tool.side_effects.writes_state,
                    "reads_state": tool.side_effects.reads_state,
                    "touches_network": tool.side_effects.touches_network,
                    "touches_secrets": tool.side_effects.touches_secrets,
                }
                for tool in self.api.tool_runtime.list_tools()
            ],
        }
        return {
            "inspection": inspection,
            "outcome": outcome,
            "goals": goals,
            "memories": memories,
            "providers": providers,
            "policy": policy,
        }

    def _landing(self) -> bytes:
        body = """
        <header>
          <div>
            <div class="eyebrow">Operator console</div>
            <h1>Aegis control surface</h1>
          </div>
          <div class="meta">Thin operator surface over the programmatic API.</div>
        </header>
        <section class="grid">
          <article class="card span-8">
            <div class="section-title">
              <h2>Inspect and mutate state</h2>
              <span class="meta">Sessions, goals, memories, providers, policy</span>
            </div>
            <p class="subtle">Open a session route to inspect durable goals and memories, then use the detail pages to edit a goal or correct or delete a memory. The console stays thin and renders the API payloads that already exist.</p>
            <div class="row" style="margin-top:16px;">
              <span class="pill"><strong>/sessions/{session_id}</strong> overview</span>
              <span class="pill"><strong>/sessions/{session_id}/goals</strong> goals</span>
              <span class="pill"><strong>/sessions/{session_id}/memories</strong> memories</span>
              <span class="pill"><strong>/sessions/{session_id}/goals/&lt;id&gt;</strong> goal detail</span>
              <span class="pill"><strong>/sessions/{session_id}/memories/&lt;id&gt;</strong> memory detail</span>
              <span class="pill"><strong>/sessions/{session_id}/providers</strong> providers</span>
              <span class="pill"><strong>/sessions/{session_id}/policy</strong> policy</span>
            </div>
          </article>
          <article class="card span-4 alt">
            <div class="eyebrow">Contract</div>
            <pre>API-backed
thin console
durable state
operator focused</pre>
          </article>
        </section>
        """
        return _page("Aegis Console", body)

    def _goals_page(self, session_id: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        goals = summary["goals"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Goals</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Durable goal graph · revision {escape(str(inspection.goal_graph_revision or "none"))}</div>
        </header>
        <section class="grid">
          <article class="card span-12">
            <div class="section-title"><h2>Goal inventory</h2><span class="meta">{len(goals)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/goals/{escape(goal.goal_id)}">{escape(goal.title)}</a></h3><div class="meta">ID {escape(goal.goal_id)} · {escape(goal.status)} · priority {escape(goal.priority)}</div><div class="meta">Dependencies: {escape(_text(goal.dependencies) or "none")}</div><div class="meta">Evidence: {escape(_text(goal.evidence_refs) or "none")}</div></div>'
                for goal in goals
              ) or '<div class="item"><div class="meta">No durable goals have been recorded yet.</div></div>'}
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Goals · {session_id}", body)

    def _memories_page(self, session_id: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        memories = summary["memories"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Memories</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Durable memory inventory · {inspection.memory_count} active records</div>
        </header>
        <section class="grid">
          <article class="card span-12">
            <div class="section-title"><h2>Memory inventory</h2><span class="meta">{len(memories)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/memories/{escape(memory.memory_id)}">{escape(memory.kind)}</a></h3><div class="meta">ID {escape(memory.memory_id)} · state {escape(str(self.api.inspect_memory(session_id, memory.memory_id)["memory_state"] or "active"))}</div><pre>{escape(memory.content)}</pre></div>'
                for memory in memories
              ) or '<div class="item"><div class="meta">No durable memories have been recorded yet.</div></div>'}
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Memories · {session_id}", body)

    def _goal_page(self, session_id: str, goal_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        goal_info = self.api.inspect_goal(session_id, goal_id)
        goal = goal_info["goal"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Goal</div>
            <h1>{escape(goal.title)}</h1>
          </div>
          <div class="meta">Session {escape(session_id)} · revision {escape(str(goal_info["goal_graph_revision"] or "none"))}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Goal detail</h2><span class="meta">Durable record</span></div>
            <div class="kv">
              <div><dt>Goal ID</dt><dd>{escape(goal.goal_id)}</dd></div>
              <div><dt>Status</dt><dd>{escape(goal.status)}</dd></div>
              <div><dt>Priority</dt><dd>{escape(goal.priority)}</dd></div>
              <div><dt>Owner</dt><dd>{escape(str(goal.owner or "none"))}</dd></div>
              <div><dt>Dependencies</dt><dd>{escape(_text(goal.dependencies) or "none")}</dd></div>
              <div><dt>Evidence</dt><dd>{escape(_text(goal.evidence_refs) or "none")}</dd></div>
              <div><dt>Goal graph</dt><dd>{escape(str(goal_info["goal_graph_revision"] or "none"))}</dd></div>
            </div>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Edit goal</h2><span class="meta">Aligned state mutation</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/goals/{escape(goal_id)}">
              <input type="hidden" name="action" value="edit">
              <div class="kv">
                <div><dt>Title</dt><dd><input name="title" value="{escape(goal.title)}" style="width:100%"></dd></div>
                <div><dt>Status</dt><dd><input name="status" value="{escape(goal.status)}" style="width:100%"></dd></div>
                <div><dt>Priority</dt><dd><input name="priority" value="{escape(goal.priority)}" style="width:100%"></dd></div>
              </div>
              <button type="submit">Save goal</button>
            </form>
            <form method="post" action="/sessions/{escape(session_id)}/goals/{escape(goal_id)}" style="margin-top:12px;">
              <input type="hidden" name="action" value="delete">
              <div class="kv">
                <div><dt>Reason</dt><dd><input name="reason" value="operator deleted goal" style="width:100%"></dd></div>
              </div>
              <button type="submit">Delete goal</button>
            </form>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Session context</h2><span class="meta">{inspection.goal_graph_revision or "no graph"}</span></div>
            <div class="row">
              <span class="pill"><strong>{inspection.session.status}</strong> session</span>
              <span class="pill"><strong>{len(summary["goals"])}</strong> goals</span>
              <span class="pill"><strong>{inspection.memory_count}</strong> memories</span>
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Goal · {goal_id}", body)

    def _memory_page(self, session_id: str, memory_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        memory_info = self.api.inspect_memory(session_id, memory_id)
        memory = memory_info["memory"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Memory</div>
            <h1>{escape(memory.kind)}</h1>
          </div>
          <div class="meta">Session {escape(session_id)} · state {escape(str(memory_info["memory_state"] or "active"))}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Memory detail</h2><span class="meta">Durable record</span></div>
            <div class="kv">
              <div><dt>Memory ID</dt><dd>{escape(memory.memory_id)}</dd></div>
              <div><dt>Kind</dt><dd>{escape(memory.kind)}</dd></div>
              <div><dt>State</dt><dd>{escape(str(memory_info["memory_state"] or "active"))}</dd></div>
              <div><dt>Lineage</dt><dd>{escape(str(memory_info["memory_lineage"] or "none"))}</dd></div>
              <div><dt>Replacement</dt><dd>{escape(str(memory_info["memory_lineage"] or "none"))}</dd></div>
              <div><dt>Goal refs</dt><dd>{escape(_text(memory.goal_refs) or "none")}</dd></div>
            </div>
            <pre style="margin-top:12px;">{escape(memory.content)}</pre>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Correct memory</h2><span class="meta">Aligned state mutation</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/memories/{escape(memory_id)}">
              <input type="hidden" name="action" value="correct">
              <div class="kv">
                <div><dt>Content</dt><dd><textarea name="corrected_content" rows="6" style="width:100%">{escape(memory.content)}</textarea></dd></div>
                <div><dt>Reason</dt><dd><input name="reason" value="operator corrected memory" style="width:100%"></dd></div>
              </div>
              <button type="submit">Save correction</button>
            </form>
            <form method="post" action="/sessions/{escape(session_id)}/memories/{escape(memory_id)}" style="margin-top:12px;">
              <input type="hidden" name="action" value="delete">
              <div class="kv">
                <div><dt>Reason</dt><dd><input name="reason" value="operator deleted memory" style="width:100%"></dd></div>
              </div>
              <button type="submit">Delete memory</button>
            </form>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Session context</h2><span class="meta">{inspection.goal_graph_revision or "no graph"}</span></div>
            <div class="row">
              <span class="pill"><strong>{inspection.session.status}</strong> session</span>
              <span class="pill"><strong>{len(summary["goals"])}</strong> goals</span>
              <span class="pill"><strong>{inspection.memory_count}</strong> active memories</span>
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Memory · {memory_id}", body)

    def _session_page(self, session_id: str, view: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        outcome = summary["outcome"]
        goals = summary["goals"]
        memories = summary["memories"]
        providers = summary["providers"]
        policy = summary["policy"]
        latest_turn = inspection.latest_turn
        stage_lines = ""
        if outcome is not None:
            stage_lines = "".join(
                f"<li><strong>{escape(stage.stage)}</strong>: {escape(stage.detail)}</li>"
                for stage in outcome.stages
            )
        else:
            stage_lines = "<li>No turn has been executed yet.</li>"
        session_body = f"""
        <header>
          <div>
            <div class="eyebrow">Session</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Profile {escape(inspection.profile.profile_id)} · {escape(inspection.session.status)}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Session view</h2><span class="meta">Lifecycle and lineage</span></div>
            <div class="kv">
              <div><dt>Display name</dt><dd>{escape(inspection.profile.display_name)}</dd></div>
              <div><dt>Mode</dt><dd>{escape(inspection.profile.mode)}</dd></div>
              <div><dt>Workspace</dt><dd>{escape(str(inspection.session.workspace_id or "none"))}</dd></div>
              <div><dt>Parent session</dt><dd>{escape(str(inspection.session.parent_session_id or "none"))}</dd></div>
              <div><dt>Lineage depth</dt><dd>{len(inspection.lineage)}</dd></div>
              <div><dt>Telemetry events</dt><dd>{inspection.telemetry_count}</dd></div>
              <div><dt>Memory records</dt><dd>{inspection.memory_count}</dd></div>
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Why the next move was chosen</h2><span class="meta">Kernel rationale</span></div>
            <pre>{escape(outcome.plan.rationale if outcome and outcome.plan else "No plan has been generated yet.")}</pre>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Turn detail</h2><span class="meta">Latest API-backed execution</span></div>
            <div class="grid">
              <div class="card span-4 alt">
                <div class="eyebrow">Request</div>
                <pre>{_lines(latest_turn.request if latest_turn else {})}</pre>
              </div>
              <div class="card span-4 alt">
                <div class="eyebrow">Execution</div>
                <pre>{escape(outcome.execution.summary if outcome is not None else "No execution yet.")}</pre>
              </div>
              <div class="card span-4 alt">
                <div class="eyebrow">Stages</div>
                <ul class="meta">{stage_lines}</ul>
              </div>
            </div>
          </article>
        </section>
        <section class="grid" style="margin-top:16px;">
          <article class="card span-6">
            <div class="section-title"><h2>Goals</h2><span class="meta">{len(goals)} active nodes</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/goals/{escape(goal.goal_id)}">{escape(goal.title)}</a></h3><div class="meta">ID {escape(goal.goal_id)} · {escape(goal.status)} · priority {escape(goal.priority)}</div><div class="meta">Dependencies: {escape(_text(goal.dependencies) or "none")}</div><div class="meta">Evidence: {escape(_text(goal.evidence_refs) or "none")}</div></div>'
                for goal in goals
              ) or '<div class="item"><div class="meta">No goals returned for this session.</div></div>'}
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Memories</h2><span class="meta">{len(memories)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/memories/{escape(memory.memory_id)}">{escape(memory.kind)}</a></h3><div class="meta">ID {escape(memory.memory_id)} · source {escape(str(memory.source_event_id or "none"))}</div><pre>{escape(memory.content)}</pre></div>'
                for memory in memories
              ) or '<div class="item"><div class="meta">No memories returned for this session.</div></div>'}
            </div>
          </article>
        </section>
        <section class="grid" style="margin-top:16px;">
          <article class="card span-6">
            <div class="section-title"><h2>Providers</h2><span class="meta">API descriptors</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3>{escape(capability_id)}</h3><div class="meta">{escape(kind)} · v{escape(version)}</div><pre>{escape(json.dumps(metadata, indent=2, sort_keys=True))}</pre></div>'
                for capability_id, kind, version, metadata in providers
              )}
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Policy</h2><span class="meta">Runtime controls</span></div>
            <div class="kv">
              <div><dt>Profile mode</dt><dd>{escape(policy["profile_mode"])}</dd></div>
              <div><dt>Session status</dt><dd>{escape(policy["session_status"])}</dd></div>
              <div><dt>Interruption state</dt><dd>{escape(str(policy["interruption_state"] or "none"))}</dd></div>
              <div><dt>Enabled capabilities</dt><dd>{escape(_text(policy["enabled_capabilities"]) or "none")}</dd></div>
              <div><dt>Tool catalog</dt><dd>{escape(json.dumps(policy["tool_catalog"], indent=2, sort_keys=True))}</dd></div>
            </div>
          </article>
        </section>
        <section class="card" style="margin-top:16px;">
          <div class="nav">
            <a href="/sessions/{escape(session_id)}">overview</a>
            <a href="/sessions/{escape(session_id)}/goals">goals</a>
            <a href="/sessions/{escape(session_id)}/memories">memories</a>
            <a href="/sessions/{escape(session_id)}/providers">providers</a>
            <a href="/sessions/{escape(session_id)}/policy">policy</a>
          </div>
        </section>
        """
        if view == "goals":
            body = self._goals_page(session_id).decode("utf-8")
        elif view == "memories":
            body = self._memories_page(session_id).decode("utf-8")
        elif view == "providers":
            body = f"<header><div><div class='eyebrow'>Providers</div><h1>{escape(session_id)}</h1></div><div class='meta'>Programmatic capability descriptors</div></header><section class='grid'><article class='card span-12'><div class='list'>{''.join(f'<div class=\"item\"><h3>{escape(capability_id)}</h3><div class=\"meta\">{escape(kind)} · v{escape(version)}</div><pre>{escape(json.dumps(metadata, indent=2, sort_keys=True))}</pre></div>' for capability_id, kind, version, metadata in providers)}</div></article></section>"
        elif view == "policy":
            body = f"<header><div><div class='eyebrow'>Policy</div><h1>{escape(session_id)}</h1></div><div class='meta'>Session and tool governance</div></header><section class='grid'><article class='card span-12'><div class='kv'><div><dt>Profile mode</dt><dd>{escape(policy['profile_mode'])}</dd></div><div><dt>Session status</dt><dd>{escape(policy['session_status'])}</dd></div><div><dt>Interruption state</dt><dd>{escape(str(policy['interruption_state'] or 'none'))}</dd></div><div><dt>Enabled capabilities</dt><dd>{escape(_text(policy['enabled_capabilities']) or 'none')}</dd></div><div><dt>Tool catalog</dt><dd>{escape(json.dumps(policy['tool_catalog'], indent=2, sort_keys=True))}</dd></div></div></article></section>"
        else:
            body = session_body
        return _page(f"Aegis Console · {session_id}", body)

    def dispatch(self, method: str, path: str, body: bytes | None = None) -> tuple[int, Mapping[str, Any] | bytes, tuple[tuple[str, str], ...]]:
        method_upper = method.upper()
        if method_upper == "GET" and path == "/healthz":
            return 200, {"status": "ok", "service": "aegis-console"}, (("content-type", "application/json; charset=utf-8"),)
        if method_upper not in {"GET", "POST"}:
            return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
        if path == "/":
            if method_upper != "GET":
                return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
            return 200, self._landing(), (("content-type", "text/html; charset=utf-8"),)

        parts = tuple(part for part in path.strip("/").split("/") if part)
        if len(parts) < 2 or parts[0] != "sessions":
            return 404, {"error": "not_found"}, (("content-type", "application/json; charset=utf-8"),)

        session_id = parts[1]
        if len(parts) == 2:
            if method_upper != "GET":
                return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
            return 200, self._session_page(session_id, "overview"), (("content-type", "text/html; charset=utf-8"),)

        view = parts[2]
        if len(parts) == 3 and method_upper == "GET":
            if view == "goals":
                return 200, self._goals_page(session_id), (("content-type", "text/html; charset=utf-8"),)
            if view == "memories":
                return 200, self._memories_page(session_id), (("content-type", "text/html; charset=utf-8"),)
            return 200, self._session_page(session_id, view), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 4 and view == "goals":
            goal_id = parts[3]
            if method_upper == "GET":
                return 200, self._goal_page(session_id, goal_id), (("content-type", "text/html; charset=utf-8"),)
            form = _form_data(body)
            if form.get("action", "edit") == "delete":
                self.api.delete_goal(session_id, goal_id, reason=form.get("reason", ""))
                notice = "Goal deleted durably."
            else:
                self.api.update_goal(
                    session_id,
                    goal_id,
                    title=form.get("title"),
                    status=form.get("status"),
                    priority=form.get("priority"),
                    reason=form.get("reason"),
                )
                notice = "Goal updated durably."
            return 200, self._goal_page(session_id, goal_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 4 and view == "memories":
            memory_id = parts[3]
            if method_upper == "GET":
                return 200, self._memory_page(session_id, memory_id), (("content-type", "text/html; charset=utf-8"),)
            form = _form_data(body)
            if form.get("action", "correct") == "delete":
                self.api.delete_memory(session_id, memory_id, reason=form.get("reason", ""))
                notice = "Memory deleted durably."
            else:
                self.api.correct_memory(
                    session_id,
                    memory_id,
                    corrected_content=form.get("corrected_content", ""),
                    reason=form.get("reason", ""),
                )
                notice = "Memory corrected durably."
            return 200, self._memory_page(session_id, memory_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if method_upper == "GET":
            view = parts[2] if len(parts) > 2 else "overview"
            return 200, self._session_page(session_id, view), (("content-type", "text/html; charset=utf-8"),)
        return 404, {"error": "not_found"}, (("content-type", "application/json; charset=utf-8"),)

    def __call__(self, environ: Mapping[str, Any], start_response: Any) -> list[bytes]:
        method = str(environ.get("REQUEST_METHOD", "GET"))
        path = str(environ.get("PATH_INFO", "/"))
        query = parse_qs(str(environ.get("QUERY_STRING", "")))
        if path == "/" and query.get("session_id"):
            session_id = query["session_id"][0]
            response = self._session_page(session_id, "overview")
            start_response("200 OK", [("content-type", "text/html; charset=utf-8")])
            return [response]
        body_stream = environ.get("wsgi.input")
        payload_bytes = body_stream.read() if body_stream is not None else b""
        status_code, payload, headers = self.dispatch(method, path, payload_bytes)
        start_response(f"{status_code} {'OK' if status_code < 400 else 'ERROR'}", list(headers))
        if isinstance(payload, bytes):
            return [payload]
        return [_json_response(payload)]


def create_app(
    *,
    database_path: str | Path,
    instruction_refs: tuple[str, ...] = ("apps/api",),
    total_tokens: int = 2048,
) -> AegisConsoleApp:
    return AegisConsoleApp(
        ConsoleAppConfig(
            database_path=Path(database_path),
            instruction_refs=instruction_refs,
            total_tokens=total_tokens,
        )
    )
