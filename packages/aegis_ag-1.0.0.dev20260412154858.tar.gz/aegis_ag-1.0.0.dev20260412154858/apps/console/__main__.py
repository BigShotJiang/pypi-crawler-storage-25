"""Run the operator console locally."""

from __future__ import annotations

from argparse import ArgumentParser
from pathlib import Path
from wsgiref.simple_server import make_server

from .runtime import create_app


def main() -> None:
    parser = ArgumentParser(description="Run the Aegis operator console.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--database", type=Path, default=Path(".aegis-console.sqlite3"))
    args = parser.parse_args()
    app = create_app(database_path=args.database)
    with make_server(args.host, args.port, app) as server:
        print(f"Serving Aegis console on http://{args.host}:{args.port}")
        server.serve_forever()


if __name__ == "__main__":
    main()
