"""Operator console surface for Aegis."""

from .runtime import AegisConsoleApp, ConsoleAppConfig, create_app

__all__ = ["AegisConsoleApp", "ConsoleAppConfig", "create_app"]
