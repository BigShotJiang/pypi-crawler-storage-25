"""Public inventory of auth package surfaces."""

AUTH_SURFACES = (
    "SecretReference",
    "AuthProfile",
    "ProviderManifest",
    "ProviderCatalog",
    "ProviderProfileFactory",
    "ProviderProfileInput",
    "CredentialBundle",
    "SecretStore",
    "AuthProfileStore",
    "CredentialResolver",
    "InMemorySecretStore",
    "InMemoryAuthProfileStore",
    "PersistentAuthProfileStore",
    "ProfileCredentialResolver",
    "PreviewAuthProviderCapability",
    "profile_from_input",
)
