"""Credential resolution and secret-reference primitives."""

from .inventory import AUTH_SURFACES
from .runtime import (
    AuthProfile,
    AuthProfileStore,
    CredentialBundle,
    CredentialResolver,
    InMemoryAuthProfileStore,
    InMemorySecretStore,
    PersistentAuthProfileStore,
    PreviewAuthProviderCapability,
    ProfileCredentialResolver,
    ProviderCatalog,
    ProviderManifest,
    ProviderProfileFactory,
    ProviderProfileInput,
    profile_from_input,
    SecretReference,
    SecretStore,
)

__all__ = [
    "AUTH_SURFACES",
    "AuthProfile",
    "AuthProfileStore",
    "CredentialBundle",
    "CredentialResolver",
    "InMemoryAuthProfileStore",
    "InMemorySecretStore",
    "PersistentAuthProfileStore",
    "PreviewAuthProviderCapability",
    "ProfileCredentialResolver",
    "ProviderCatalog",
    "ProviderManifest",
    "ProviderProfileFactory",
    "ProviderProfileInput",
    "profile_from_input",
    "SecretReference",
    "SecretStore",
]
