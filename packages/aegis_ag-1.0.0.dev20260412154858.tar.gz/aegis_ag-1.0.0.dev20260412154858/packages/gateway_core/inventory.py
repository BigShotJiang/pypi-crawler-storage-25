"""Public inventory of the gateway core surface."""

GATEWAY_CORE_SURFACES = (
    "FileGatewayIdentityStore",
    "FileGatewaySessionStore",
    "GatewayIdentityKey",
    "GatewayIdentityRecord",
    "GatewayInboundMessage",
    "GatewayOutboundMessage",
    "GatewayRouteResult",
    "GatewayDeliveryReceipt",
    "GatewayIdentityStore",
    "GatewaySessionStore",
    "GatewayCoreService",
    "InMemoryGatewayIdentityStore",
    "InMemoryGatewaySessionStore",
)
