"""Governable companion identity and onboarding surfaces."""

from __future__ import annotations

from dataclasses import dataclass

from .loader import LoadedProfile
from .policy import HerModeSettings, resolve_personality_preset

DEFAULT_SOUL_TEXT = "\n".join(
    (
        "You are Aegis, the user's persistent AI.",
        "Your work is to preserve continuity, recover relevant context, and protect trust across time.",
        "Be grounded, calm, and exact.",
        "Never fake memory, certainty, capability, or identity.",
    )
)


@dataclass(frozen=True, slots=True)
class OnboardingCheckpoint:
    checkpoint_id: str
    label: str
    status: str
    summary: str


@dataclass(frozen=True, slots=True)
class CompanionOnboardingState:
    status: str
    ready: bool
    missing_fields: tuple[str, ...]
    next_step: str
    summary: str
    checkpoints: tuple[OnboardingCheckpoint, ...]


@dataclass(frozen=True, slots=True)
class CompanionIdentityState:
    display_name: str
    mode: str
    soul_text: str
    personality_preset: str
    personality_label: str
    personality_traits: tuple[str, ...]
    personality_summary: str
    relational_stance: str
    initiative: str
    continuity_notes: tuple[str, ...]
    governance_summary: str
    proactive_summary: str
    voice_identity_summary: str


@dataclass(frozen=True, slots=True)
class CompanionGovernanceState:
    identity: CompanionIdentityState
    onboarding: CompanionOnboardingState


def resolved_her_mode(profile: LoadedProfile) -> HerModeSettings:
    if profile.her_mode is not None:
        return profile.her_mode
    preset = resolve_personality_preset(None, mode=profile.state.mode)
    return HerModeSettings(
        personality_preset=preset.preset_id,
        personality=preset.traits,
    )


def soul_text(profile: LoadedProfile) -> str:
    return (profile.soul_text or DEFAULT_SOUL_TEXT).strip()


def build_companion_identity_state(profile: LoadedProfile) -> CompanionIdentityState:
    her_mode = resolved_her_mode(profile)
    preset = resolve_personality_preset(her_mode.personality_preset, mode=profile.state.mode)
    traits = her_mode.personality or preset.traits
    return CompanionIdentityState(
        display_name=profile.state.display_name,
        mode=profile.state.mode,
        soul_text=soul_text(profile),
        personality_preset=preset.preset_id,
        personality_label=preset.label,
        personality_traits=traits,
        personality_summary=preset.summary,
        relational_stance=preset.relational_stance,
        initiative=her_mode.initiative,
        continuity_notes=her_mode.notes,
        governance_summary=her_mode.governance_summary(),
        proactive_summary=her_mode.proactive_summary(),
        voice_identity_summary=her_mode.voice_identity_summary(),
    )


def build_companion_onboarding_state(profile: LoadedProfile) -> CompanionOnboardingState:
    manifest = dict(profile.manifest)
    her_mode_payload = manifest.get("her_mode") if isinstance(manifest.get("her_mode"), dict) else {}
    assert isinstance(her_mode_payload, dict)
    identity = build_companion_identity_state(profile)

    has_explicit_display_name = "display_name" in manifest
    has_custom_soul = profile.soul_text is not None and profile.soul_text.strip() != ""
    has_explicit_personality = any(key in her_mode_payload for key in ("personality_preset", "personality"))
    has_explicit_initiative = "initiative" in her_mode_payload

    checkpoints = (
        OnboardingCheckpoint(
            checkpoint_id="display-name",
            label="Display name",
            status="ready" if has_explicit_display_name else "needs-confirmation",
            summary=(
                f"identity anchored as {identity.display_name}"
                if has_explicit_display_name
                else f"using derived display name {identity.display_name}"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="soul",
            label="SOUL charter",
            status="ready" if has_custom_soul else "needs-confirmation",
            summary=(
                "durable SOUL.md is present"
                if has_custom_soul
                else "still running on the default soul charter"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="personality",
            label="Personality preset",
            status="ready" if has_explicit_personality else "needs-confirmation",
            summary=(
                f"preset {identity.personality_label} is explicitly pinned"
                if has_explicit_personality
                else f"preset {identity.personality_label} is inferred from defaults"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="initiative",
            label="Initiative posture",
            status="ready" if has_explicit_initiative else "needs-confirmation",
            summary=(
                f"initiative is set to {identity.initiative}"
                if has_explicit_initiative
                else f"initiative is falling back to {identity.initiative}"
            ),
        ),
    )
    missing_fields = tuple(
        checkpoint.checkpoint_id for checkpoint in checkpoints if checkpoint.status != "ready"
    )
    ready = not missing_fields
    if ready:
        status = "ready"
        next_step = "identity-governance-ready"
        summary = (
            "SOUL, personality, and initiative are explicitly configured for one "
            "long-lived companion path."
        )
    else:
        status = "needs-onboarding"
        next_step = "confirm soul, personality preset, and initiative before treating the profile as fully onboarded"
        summary = (
            "Companion identity exists, but onboarding is still relying on defaults "
            "for: " + ", ".join(missing_fields)
        )
    return CompanionOnboardingState(
        status=status,
        ready=ready,
        missing_fields=missing_fields,
        next_step=next_step,
        summary=summary,
        checkpoints=checkpoints,
    )


def build_companion_governance_state(profile: LoadedProfile) -> CompanionGovernanceState:
    return CompanionGovernanceState(
        identity=build_companion_identity_state(profile),
        onboarding=build_companion_onboarding_state(profile),
    )
