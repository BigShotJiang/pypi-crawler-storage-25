"""Prompt contract assembly for Aegis identity, SOUL, and runtime posture."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .governance import DEFAULT_SOUL_TEXT, build_companion_identity_state, soul_text
from .loader import LoadedProfile

PromptMode = Literal["full", "minimal"]


@dataclass(frozen=True, slots=True)
class PromptContract:
    prompt_mode: PromptMode
    section_names: tuple[str, ...]
    instruction_refs: tuple[str, ...]


def build_identity_kernel(profile: LoadedProfile) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    return (
        "section:identity-kernel",
        "identity-product=Aegis",
        f"identity-display-name={identity.display_name}",
        "identity-source=profile-state, soul-charter, personality-preset, continuity-governance",
        (
            f"Answer as {identity.display_name} from Aegis. Let the soul charter, personality "
            "settings, and continuity posture below define tone, stance, and identity."
        ),
    )


def build_soul_section(profile: LoadedProfile) -> tuple[str, ...]:
    return (
        "section:soul",
        f"soul-charter={soul_text(profile)}",
    )


def build_personality_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:personality",
        f"personality-preset={identity.personality_preset}",
        f"personality-label={identity.personality_label}",
        f"personality-traits={', '.join(identity.personality_traits) or 'grounded, durable'}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"personality-summary={identity.personality_summary}",
                f"relational-stance={identity.relational_stance}",
            )
        )
    return tuple(lines)


def build_user_snapshot_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    preferences = ", ".join(profile.state.preferences) or "none"
    notes = ", ".join(identity.continuity_notes) or "none"
    lines = [
        "section:user-snapshot",
        f"active-display-name={identity.display_name}",
        f"mode={identity.mode}",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"preferences={preferences}",
                f"initiative={identity.initiative}",
                f"continuity-notes={notes}",
            )
        )
    return tuple(lines)


def build_runtime_contract_section(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> tuple[str, ...]:
    identity = build_companion_identity_state(profile)
    lines = [
        "section:runtime-contract",
        f"prompt-mode={prompt_mode}",
        "Protect continuity, disclose uncertainty, and stay legible.",
        "Open with calm initiative and preserve the thread across time.",
        "Keep one coherent long-lived identity across wake, recovery, chat, and voice surfaces.",
    ]
    if prompt_mode == "full":
        lines.extend(
            (
                f"governance={identity.governance_summary}",
                f"voice-identity={identity.voice_identity_summary}",
            )
        )
    return tuple(lines)


def build_prompt_contract(
    profile: LoadedProfile,
    *,
    prompt_mode: PromptMode = "full",
) -> PromptContract:
    sections: list[tuple[str, tuple[str, ...]]] = [
        ("identity-kernel", build_identity_kernel(profile)),
        ("soul", build_soul_section(profile)),
        ("personality", build_personality_section(profile, prompt_mode=prompt_mode)),
    ]
    if prompt_mode == "full":
        sections.append(("user-snapshot", build_user_snapshot_section(profile, prompt_mode=prompt_mode)))
    sections.append(("runtime-contract", build_runtime_contract_section(profile, prompt_mode=prompt_mode)))
    instruction_refs = tuple(line for _, lines in sections for line in lines)
    return PromptContract(
        prompt_mode=prompt_mode,
        section_names=tuple(name for name, _ in sections),
        instruction_refs=instruction_refs,
    )
