"""Public inventory of the procedural skill surface."""

SKILL_SURFACES = (
    "SkillScope",
    "SkillDependency",
    "SkillDefinition",
    "SkillActivationRecord",
    "SkillManifest",
    "SkillManifestLoadRecord",
    "SkillLoader",
    "SkillCatalog",
    "JsonSkillLoader",
    "InMemorySkillCatalog",
    "SkillRuntime",
)
