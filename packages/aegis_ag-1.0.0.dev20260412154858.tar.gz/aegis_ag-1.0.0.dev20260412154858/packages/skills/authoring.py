"""Helpers for writing Aegis-owned skill packages."""

from __future__ import annotations

import re
from pathlib import Path


_VALID_SEGMENT_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


def write_skill_package(
    root: Path,
    *,
    skill_id: str,
    display_name: str,
    summary: str,
    instruction_text: str,
    category: str | None = None,
    overwrite: bool = False,
    source_kind: str = "aegis-experience",
) -> Path:
    resolved_skill_id = _validated_segment(skill_id, field_name="skill_id")
    resolved_category = _validated_segment(category, field_name="category") if category else None
    resolved_display_name = display_name.strip()
    resolved_summary = " ".join(summary.split())
    resolved_instructions = instruction_text.strip()
    if not resolved_display_name:
        raise ValueError("display_name is required")
    if not resolved_summary:
        raise ValueError("summary is required")
    if not resolved_instructions:
        raise ValueError("instruction_text is required")
    skill_dir = root.expanduser()
    if resolved_category:
        skill_dir = skill_dir / resolved_category
    skill_dir = skill_dir / resolved_skill_id
    skill_dir.mkdir(parents=True, exist_ok=True)
    skill_file = skill_dir / "SKILL.md"
    if skill_file.exists() and not overwrite:
        raise FileExistsError(skill_file)
    skill_file.write_text(
        _render_skill_markdown(
            skill_id=resolved_skill_id,
            display_name=resolved_display_name,
            summary=resolved_summary,
            instruction_text=resolved_instructions,
            source_kind=source_kind,
        ),
        encoding="utf-8",
    )
    return skill_dir


def _validated_segment(value: str | None, *, field_name: str) -> str:
    if value is None:
        raise ValueError(f"{field_name} is required")
    resolved = value.strip().lower()
    if not resolved:
        raise ValueError(f"{field_name} is required")
    if not _VALID_SEGMENT_RE.match(resolved):
        raise ValueError(
            f"{field_name} must use lowercase letters, digits, dots, underscores, or hyphens: {value!r}"
        )
    return resolved


def _render_skill_markdown(
    *,
    skill_id: str,
    display_name: str,
    summary: str,
    instruction_text: str,
    source_kind: str,
) -> str:
    lines = [
        "---",
        f"name: {display_name}",
        f"skill_id: {skill_id}",
        f"description: {summary}",
        "version: 1.0.0",
        f"source_kind: {source_kind}",
        "---",
        "",
        f"# {display_name}",
        "",
        instruction_text.rstrip(),
        "",
    ]
    return "\n".join(lines)
