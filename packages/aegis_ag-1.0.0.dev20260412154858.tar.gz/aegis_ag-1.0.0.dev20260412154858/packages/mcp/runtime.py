"""Minimal MCP registry, discovery, and installed-server management."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
import json
import os
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class McpServerDefinition:
    server_id: str
    display_name: str
    summary: str
    transport: str = "stdio"
    command: str = ""
    args: tuple[str, ...] = ()
    env: Mapping[str, str] = field(default_factory=dict)
    url: str | None = None
    enabled: bool = True
    provenance: str = ""
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class McpDiscoverySource:
    source_id: str
    label: str
    config_path: Path


class InMemoryMcpCatalog:
    def __init__(self) -> None:
        self._servers: dict[str, McpServerDefinition] = {}

    def register(self, definition: McpServerDefinition) -> None:
        self._servers[definition.server_id] = definition

    def get(self, server_id: str) -> McpServerDefinition | None:
        return self._servers.get(server_id)

    def list(self) -> tuple[McpServerDefinition, ...]:
        return tuple(self._servers.values())

    def set_enabled(self, server_id: str, enabled: bool) -> McpServerDefinition:
        definition = self._servers.get(server_id)
        if definition is None:
            raise KeyError(f"mcp server is not registered: {server_id}")
        updated = replace(definition, enabled=enabled)
        self._servers[server_id] = updated
        return updated


class McpRuntime:
    def __init__(self, catalog: InMemoryMcpCatalog | None = None) -> None:
        self._catalog = catalog or InMemoryMcpCatalog()

    @property
    def catalog(self) -> InMemoryMcpCatalog:
        return self._catalog

    def register_server(self, definition: McpServerDefinition) -> None:
        self._catalog.register(definition)

    def describe(self, server_id: str) -> McpServerDefinition | None:
        return self._catalog.get(server_id)

    def list_servers(self) -> tuple[McpServerDefinition, ...]:
        return self._catalog.list()

    def set_enabled(self, server_id: str, enabled: bool) -> McpServerDefinition:
        return self._catalog.set_enabled(server_id, enabled)


class McpRegistry:
    """Search installable MCP templates plus discovered local MCP configs."""

    def __init__(self, sources: tuple[McpDiscoverySource, ...] | None = None) -> None:
        self._sources = sources or default_mcp_discovery_sources()

    @property
    def sources(self) -> tuple[McpDiscoverySource, ...]:
        return self._sources

    def list(self) -> tuple[McpServerDefinition, ...]:
        discovered: dict[str, McpServerDefinition] = {
            server.server_id: server for server in builtin_mcp_registry()
        }
        for source in self._sources:
            for server in _load_mcp_config(source):
                discovered.setdefault(server.server_id, server)
        ordered = tuple(sorted(discovered.values(), key=lambda item: item.display_name.lower()))
        return ordered

    def search(self, query: str, *, limit: int = 12) -> tuple[McpServerDefinition, ...]:
        tokens = tuple(token for token in _normalize_query(query).split() if token)
        if not tokens:
            return self.list()[:limit]
        scored: list[tuple[int, str, McpServerDefinition]] = []
        for server in self.list():
            haystack = " ".join(
                (
                    server.server_id,
                    server.display_name,
                    server.summary,
                    server.command,
                    " ".join(server.args),
                    str(server.metadata.get("categories") or ""),
                )
            ).lower()
            if not all(token in haystack for token in tokens):
                continue
            score = 0
            if _normalize_query(server.server_id) == " ".join(tokens):
                score += 5
            if _normalize_query(server.display_name) == " ".join(tokens):
                score += 4
            if all(token in _normalize_query(server.display_name) for token in tokens):
                score += 2
            scored.append((score, server.server_id, server))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return tuple(item[2] for item in scored[:limit])

    def resolve(self, reference: str) -> McpServerDefinition | None:
        candidate = reference.strip().lower()
        if not candidate:
            return None
        for server in self.list():
            if candidate in {server.server_id.lower(), server.display_name.lower()}:
                return server
        return None


def builtin_mcp_registry() -> tuple[McpServerDefinition, ...]:
    return (
        McpServerDefinition(
            server_id="fetch",
            display_name="Fetch",
            summary="Read and transform remote web pages over HTTP for browser-light content access.",
            command="npx",
            args=("-y", "@modelcontextprotocol/server-fetch"),
            provenance="packages/mcp",
            metadata={"kind": "template", "categories": ("web", "fetch")},
        ),
        McpServerDefinition(
            server_id="filesystem",
            display_name="Filesystem",
            summary="Expose local directories as MCP tools for safe file inspection and edits.",
            command="npx",
            args=("-y", "@modelcontextprotocol/server-filesystem"),
            provenance="packages/mcp",
            metadata={"kind": "template", "categories": ("filesystem", "workspace")},
        ),
        McpServerDefinition(
            server_id="github",
            display_name="GitHub",
            summary="Expose repository, issue, and pull request operations through the GitHub MCP server.",
            command="npx",
            args=("-y", "@modelcontextprotocol/server-github"),
            provenance="packages/mcp",
            metadata={"kind": "template", "categories": ("github", "remote")},
        ),
        McpServerDefinition(
            server_id="playwright",
            display_name="Playwright",
            summary="Drive a real browser through Playwright MCP for interactive page navigation and capture.",
            command="npx",
            args=("-y", "@playwright/mcp"),
            provenance="packages/mcp",
            metadata={"kind": "template", "categories": ("browser", "web")},
        ),
        McpServerDefinition(
            server_id="brave-search",
            display_name="Brave Search",
            summary="Search the public web through the Brave Search MCP server.",
            command="npx",
            args=("-y", "@modelcontextprotocol/server-brave-search"),
            provenance="packages/mcp",
            metadata={"kind": "template", "categories": ("search", "web")},
        ),
    )


def default_mcp_discovery_sources() -> tuple[McpDiscoverySource, ...]:
    configured = os.environ.get("AEGIS_MCP_CONFIG_PATHS", "").strip()
    if configured:
        return tuple(
            McpDiscoverySource(
                source_id=f"custom-{index + 1}",
                label=Path(raw_path).expanduser().name or f"custom-{index + 1}",
                config_path=Path(raw_path).expanduser(),
            )
            for index, raw_path in enumerate(configured.split(os.pathsep))
            if raw_path.strip()
        )

    home = Path.home()
    candidates = (
        McpDiscoverySource("claude", "Claude Desktop", home / ".config" / "claude" / "claude_desktop_config.json"),
        McpDiscoverySource("cursor", "Cursor", home / ".cursor" / "mcp.json"),
        McpDiscoverySource("codex", "Codex", home / ".codex" / "mcp.json"),
        McpDiscoverySource("openclaw", "OpenClaw", home / ".config" / "openclaw" / "mcp.json"),
    )
    return tuple(source for source in candidates if source.config_path.exists())


def mcp_server_from_payload(payload: Mapping[str, Any], *, provenance: str = "") -> McpServerDefinition:
    args_value = payload.get("args", ())
    if isinstance(args_value, str):
        args = (args_value,)
    elif isinstance(args_value, (list, tuple)):
        args = tuple(str(item) for item in args_value)
    else:
        args = ()
    env_payload = payload.get("env", {})
    env = {str(key): str(value) for key, value in env_payload.items()} if isinstance(env_payload, Mapping) else {}
    return McpServerDefinition(
        server_id=str(payload["server_id"]),
        display_name=str(payload.get("display_name") or payload["server_id"]),
        summary=str(payload.get("summary") or ""),
        transport=str(payload.get("transport") or "stdio"),
        command=str(payload.get("command") or ""),
        args=args,
        env=env,
        url=str(payload.get("url")) if payload.get("url") is not None else None,
        enabled=bool(payload.get("enabled", True)),
        provenance=str(payload.get("provenance") or provenance),
        metadata=dict(payload.get("metadata", {})) if isinstance(payload.get("metadata", {}), Mapping) else {},
    )


def mcp_server_payload(definition: McpServerDefinition) -> dict[str, Any]:
    return {
        "server_id": definition.server_id,
        "display_name": definition.display_name,
        "summary": definition.summary,
        "transport": definition.transport,
        "command": definition.command,
        "args": list(definition.args),
        "env": dict(definition.env),
        "url": definition.url,
        "enabled": definition.enabled,
        "provenance": definition.provenance,
        "metadata": dict(definition.metadata),
    }


def _load_mcp_config(source: McpDiscoverySource) -> tuple[McpServerDefinition, ...]:
    try:
        payload = json.loads(source.config_path.read_text(encoding="utf-8"))
    except Exception:
        return ()
    servers_payload = payload.get("mcpServers", {})
    if not isinstance(servers_payload, Mapping):
        return ()
    definitions: list[McpServerDefinition] = []
    for server_id, config in servers_payload.items():
        if not isinstance(config, Mapping):
            continue
        metadata = dict(config.get("metadata", {})) if isinstance(config.get("metadata", {}), Mapping) else {}
        metadata.update({"kind": "discovered", "source_id": source.source_id, "source_label": source.label})
        definition = McpServerDefinition(
            server_id=str(server_id),
            display_name=str(config.get("display_name") or server_id),
            summary=str(config.get("summary") or f"Discovered from {source.label}."),
            transport="streamable-http" if config.get("url") else "stdio",
            command=str(config.get("command") or ""),
            args=tuple(str(item) for item in config.get("args", ())) if isinstance(config.get("args", ()), (list, tuple)) else (),
            env={str(key): str(value) for key, value in config.get("env", {}).items()} if isinstance(config.get("env", {}), Mapping) else {},
            url=str(config.get("url")) if config.get("url") is not None else None,
            provenance=str(source.config_path),
            metadata=metadata,
        )
        definitions.append(definition)
    return tuple(definitions)


def _normalize_query(value: str) -> str:
    return " ".join(value.lower().replace("-", " ").replace("_", " ").split())
