"""Minimal MCP discovery and installed-server registry for Aegis."""

from .runtime import (
    InMemoryMcpCatalog,
    McpDiscoverySource,
    McpRegistry,
    McpRuntime,
    McpServerDefinition,
    builtin_mcp_registry,
    default_mcp_discovery_sources,
    mcp_server_from_payload,
    mcp_server_payload,
)

__all__ = [
    "InMemoryMcpCatalog",
    "McpDiscoverySource",
    "McpRegistry",
    "McpRuntime",
    "McpServerDefinition",
    "builtin_mcp_registry",
    "default_mcp_discovery_sources",
    "mcp_server_from_payload",
    "mcp_server_payload",
]
