"""Layered context assembly, summarization, budgeting, and rendering."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import re
from typing import Any, Mapping, Protocol, runtime_checkable

from packages.capabilities.runtime import CapabilityDescriptor, ContextCapability
from packages.contracts.runtime import ContextBundle, GoalNode, MemoryRecord, SessionState


@dataclass(frozen=True, slots=True)
class ContextLayerBudget:
    layer_name: str
    requested_tokens: int
    allocated_tokens: int
    required: bool = False
    priority: int = 0
    omitted: bool = False
    source_refs: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ContextBudgetRequest:
    layer_name: str
    desired_tokens: int
    minimum_tokens: int = 0
    required: bool = False
    priority: int = 0
    source_refs: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ContextBudgetPlan:
    total_tokens: int
    allocations: tuple[ContextLayerBudget, ...]
    overflow_tokens: int
    omitted_layers: tuple[str, ...] = ()

    @property
    def allocated_tokens(self) -> int:
        return sum(allocation.allocated_tokens for allocation in self.allocations)

    def allocation_for(self, layer_name: str) -> ContextLayerBudget | None:
        for allocation in self.allocations:
            if allocation.layer_name == layer_name:
                return allocation
        return None


@dataclass(frozen=True, slots=True)
class ContextSummaryRequest:
    layer_name: str
    source_refs: tuple[str, ...]
    token_budget: int
    reason: str
    required: bool = False


@dataclass(frozen=True, slots=True)
class ContextRetrievalRequest:
    request_id: str
    layer_name: str
    session_id: str
    query: str
    memory_ids: tuple[str, ...] = ()
    goal_ids: tuple[str, ...] = ()
    token_budget: int = 0
    priority: int = 0
    reason: str = ""


@dataclass(frozen=True, slots=True)
class ContextLayerSnapshot:
    layer_name: str
    source_refs: tuple[str, ...]
    content: tuple[str, ...]
    token_budget: int
    summary: str | None = None


@dataclass(frozen=True, slots=True)
class ContextSourceTrace:
    layer_name: str
    selected_refs: tuple[str, ...]
    reason: str
    omitted_refs: tuple[str, ...] = ()

    def describe(self) -> str:
        selected = ", ".join(self.selected_refs) if self.selected_refs else "none"
        omitted = f" | omitted: {', '.join(self.omitted_refs)}" if self.omitted_refs else ""
        return f"- {self.layer_name}: {self.reason} | selected: {selected}{omitted}"


@dataclass(frozen=True, slots=True)
class ContextAssemblyPlan:
    session_id: str
    profile_id: str
    total_tokens: int
    layers: tuple[ContextLayerSnapshot, ...]
    budgets: ContextBudgetPlan
    summary_requests: tuple[ContextSummaryRequest, ...]
    retrieval_requests: tuple[ContextRetrievalRequest, ...]
    rationale: str = ""
    source_trace: tuple[ContextSourceTrace, ...] = ()


@dataclass(frozen=True, slots=True)
class ContextAssemblyResult:
    bundle: ContextBundle
    plan: ContextAssemblyPlan
    rendered_prompt: str
    summary_by_layer: Mapping[str, str] = field(default_factory=dict)
    retrieved_memory_ids: tuple[str, ...] = ()
    source_trace: tuple[ContextSourceTrace, ...] = ()


def _operational_layer_heading(layer_name: str) -> str:
    labels = {
        "instructions": "instructions (kernel guardrails)",
        "goals": "goals (durable mission)",
        "hot": "hot (live turn)",
        "warm": "warm (continuity memory)",
        "retrieval": "retrieval (cool recall)",
        "tools": "artifacts (runtime steering)",
    }
    return labels.get(layer_name, layer_name)


@runtime_checkable
class SummaryHook(Protocol):
    def summarize(
        self,
        *,
        session: SessionState,
        layer_name: str,
        content: tuple[str, ...],
        token_budget: int,
        reason: str,
    ) -> str:
        """Summarize content for a single context layer."""


@runtime_checkable
class RetrievalScheduler(Protocol):
    def schedule(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        hot_turns: tuple[str, ...] = (),
        token_budget: int,
    ) -> tuple[ContextRetrievalRequest, ...]:
        """Schedule retrieval requests for the current session."""


@runtime_checkable
class BudgetManager(Protocol):
    def allocate(self, total_tokens: int, requests: tuple[ContextBudgetRequest, ...]) -> ContextBudgetPlan:
        """Allocate explicit token budgets to ordered layers."""


@runtime_checkable
class PromptRenderer(Protocol):
    def render(self, plan: ContextAssemblyPlan) -> str:
        """Render a structured prompt bundle."""


@runtime_checkable
class ContextPlanner(Protocol):
    def plan(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        total_tokens: int,
        instruction_refs: tuple[str, ...],
        hot_turns: tuple[str, ...],
        artifacts: tuple[str, ...] = (),
    ) -> ContextAssemblyPlan:
        """Plan layered context from structured runtime state."""


class DeterministicBudgetManager:
    """Allocate context budgets in explicit priority order."""

    def allocate(self, total_tokens: int, requests: tuple[ContextBudgetRequest, ...]) -> ContextBudgetPlan:
        ordered = sorted(
            enumerate(requests),
            key=lambda item: (
                1 if item[1].required else 0,
                item[1].priority,
                -item[0],
            ),
            reverse=True,
        )
        remaining = max(total_tokens, 0)
        allocations: list[ContextLayerBudget] = []
        omitted: list[str] = []
        for _, request in ordered:
            requested = max(request.desired_tokens, request.minimum_tokens)
            if remaining <= 0:
                allocations.append(
                    ContextLayerBudget(
                        layer_name=request.layer_name,
                        requested_tokens=requested,
                        allocated_tokens=0,
                        required=request.required,
                        priority=request.priority,
                        omitted=True,
                        source_refs=request.source_refs,
                    )
                )
                omitted.append(request.layer_name)
                continue
            allocated = min(requested, remaining)
            if request.required and allocated < request.minimum_tokens:
                omitted.append(request.layer_name)
            elif not request.required and allocated < requested:
                omitted.append(request.layer_name)
            allocations.append(
                ContextLayerBudget(
                    layer_name=request.layer_name,
                    requested_tokens=requested,
                    allocated_tokens=allocated,
                    required=request.required,
                    priority=request.priority,
                    omitted=allocated == 0,
                    source_refs=request.source_refs,
                )
            )
            remaining -= allocated
        overflow = max(sum(request.desired_tokens for request in requests) - total_tokens, 0)
        return ContextBudgetPlan(
            total_tokens=total_tokens,
            allocations=tuple(allocations),
            overflow_tokens=overflow,
            omitted_layers=tuple(dict.fromkeys(omitted)),
        )


class DeterministicRetrievalScheduler:
    """Score memories deterministically against session goals."""

    def schedule(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        hot_turns: tuple[str, ...] = (),
        token_budget: int,
    ) -> tuple[ContextRetrievalRequest, ...]:
        scored: list[tuple[int, float, float, MemoryRecord, tuple[str, ...]]] = []
        for memory in memories:
            score, reasons = _context_memory_score(
                memory,
                session=session,
                goals=goals,
                layer_name="retrieval",
                hot_turns=hot_turns,
                return_reasons=True,
            )
            bucket = _retrieval_priority_bucket(memory, session=session, goals=goals, hot_turns=hot_turns)
            recency = memory.created_at.timestamp() if memory.created_at is not None else 0.0
            scored.append((bucket, score, recency, memory, reasons))

        scored.sort(key=lambda item: (-item[0], -item[1], -item[2], item[3].memory_id))
        remaining = max(token_budget, 0)
        requests: list[ContextRetrievalRequest] = []
        for index, (_, _, _, memory, reasons) in enumerate(scored):
            estimated_tokens = _estimate_tokens(memory.content)
            if remaining <= 0:
                break
            selected_tokens = min(estimated_tokens, remaining)
            if selected_tokens <= 0:
                continue
            remaining -= selected_tokens
            requests.append(
                ContextRetrievalRequest(
                    request_id=f"{session.session_id}:retrieval:{index}",
                    layer_name="retrieval",
                    session_id=session.session_id,
                    query=_build_retrieval_query(memory, goals),
                    memory_ids=(memory.memory_id,),
                    goal_ids=memory.goal_refs,
                    token_budget=selected_tokens,
                    priority=max(0, 100 - index * 10),
                    reason=_build_retrieval_reason(memory, goals, reasons),
                )
            )
        return tuple(requests)


class DeterministicSummaryHook:
    """Summarize a layer by compressing content into inspectable bullets."""

    def summarize(
        self,
        *,
        session: SessionState,
        layer_name: str,
        content: tuple[str, ...],
        token_budget: int,
        reason: str,
    ) -> str:
        header = f"{_operational_layer_heading(layer_name)} summary for {session.session_id}"
        body = _truncate_lines(content, token_budget)
        pieces = [header, f"reason: {reason}"]
        pieces.extend(f"- {line}" for line in body)
        if session.interruption_state:
            pieces.append(f"- continuity: {session.interruption_state}")
        return "\n".join(pieces)


class MarkdownPromptRenderer:
    """Render the assembled plan as stable markdown-like text."""

    def render(self, plan: ContextAssemblyPlan) -> str:
        lines: list[str] = []
        lines.append(f"# Context Bundle {plan.session_id}")
        lines.append(f"- profile: {plan.profile_id}")
        lines.append(f"- total tokens: {plan.total_tokens}")
        if plan.rationale:
            lines.append(f"- rationale: {plan.rationale}")
        lines.append("")
        for layer in plan.layers:
            lines.append(f"## {_operational_layer_heading(layer.layer_name)}")
            lines.append(f"- token budget: {layer.token_budget}")
            if layer.source_refs:
                lines.append(f"- refs: {', '.join(layer.source_refs)}")
            if layer.summary:
                lines.append(layer.summary)
            for line in layer.content:
                lines.append(f"- {line}")
            lines.append("")
        if plan.summary_requests:
            lines.append("## Summary Requests")
            for request in plan.summary_requests:
                lines.append(
                    f"- {request.layer_name}: {request.reason} ({request.token_budget} tokens)"
                )
            lines.append("")
        if plan.retrieval_requests:
            lines.append("## Retrieval Requests")
            for request in plan.retrieval_requests:
                lines.append(
                    f"- {request.request_id}: {', '.join(request.memory_ids) or 'none'} | {request.reason}"
                )
            lines.append("")
        if plan.source_trace:
            lines.append("## Source Trace")
            for trace in plan.source_trace:
                lines.append(trace.describe())
            lines.append("")
        return "\n".join(lines).rstrip()


class LayeredContextPlanner:
    """Plan the layered context structure from runtime state."""

    def __init__(
        self,
        budget_manager: BudgetManager | None = None,
        summary_hook: SummaryHook | None = None,
        retrieval_scheduler: RetrievalScheduler | None = None,
    ) -> None:
        self._budget_manager = budget_manager or DeterministicBudgetManager()
        self._summary_hook = summary_hook or DeterministicSummaryHook()
        self._retrieval_scheduler = retrieval_scheduler or DeterministicRetrievalScheduler()

    def plan(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        total_tokens: int,
        instruction_refs: tuple[str, ...],
        hot_turns: tuple[str, ...],
        artifacts: tuple[str, ...] = (),
    ) -> ContextAssemblyPlan:
        requests = self._build_budget_requests(session, goals, memories, instruction_refs, hot_turns, artifacts)
        budgets = self._budget_manager.allocate(total_tokens, requests)
        summary_requests = self._build_summary_requests(session, budgets, goals, memories, hot_turns)
        retrieval_requests = self._retrieval_scheduler.schedule(
            session=session,
            goals=goals,
            memories=memories,
            hot_turns=hot_turns,
            token_budget=max(
                self._retrieval_budget(budgets),
                self._suggest_retrieval_budget(memories),
                max(total_tokens - budgets.allocated_tokens, 0),
            ),
        )
        layers = self._build_layers(
            session=session,
            goals=goals,
            memories=memories,
            instruction_refs=instruction_refs,
            hot_turns=hot_turns,
            artifacts=artifacts,
            budgets=budgets,
            summary_requests=summary_requests,
            retrieval_requests=retrieval_requests,
        )
        source_trace = self._build_source_trace(
            session=session,
            goals=goals,
            memories=memories,
            instruction_refs=instruction_refs,
            hot_turns=hot_turns,
            artifacts=artifacts,
            summary_requests=summary_requests,
            retrieval_requests=retrieval_requests,
        )
        rationale = _plan_rationale(session, goals, memories, budgets)
        return ContextAssemblyPlan(
            session_id=session.session_id,
            profile_id=session.profile_id,
            total_tokens=total_tokens,
            layers=layers,
            budgets=budgets,
            summary_requests=summary_requests,
            retrieval_requests=retrieval_requests,
            rationale=rationale,
            source_trace=source_trace,
        )

    def _build_budget_requests(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        instruction_refs: tuple[str, ...],
        hot_turns: tuple[str, ...],
        artifacts: tuple[str, ...],
    ) -> tuple[ContextBudgetRequest, ...]:
        goal_tokens = max(48, len(goals) * 28)
        hot_tokens = max(64, len(hot_turns) * 18)
        warm_tokens = 48 if memories else 24
        retrieval_tokens = max(96, len(memories) * 12)
        tool_tokens = 32 if artifacts else 0
        requests = (
            ContextBudgetRequest(
                layer_name="instructions",
                desired_tokens=max(32, len(instruction_refs) * 8),
                minimum_tokens=16,
                required=True,
                priority=100,
                source_refs=instruction_refs,
            ),
            ContextBudgetRequest(
                layer_name="goals",
                desired_tokens=goal_tokens,
                minimum_tokens=24,
                required=True,
                priority=90,
                source_refs=tuple(goal.goal_id for goal in goals),
            ),
            ContextBudgetRequest(
                layer_name="hot",
                desired_tokens=hot_tokens,
                minimum_tokens=24,
                required=True,
                priority=80,
                source_refs=tuple(f"turn:{index}" for index, _ in enumerate(hot_turns, start=1)),
            ),
            ContextBudgetRequest(
                layer_name="warm",
                desired_tokens=warm_tokens,
                minimum_tokens=16,
                required=bool(session.parent_session_id or session.interruption_state),
                priority=70,
                source_refs=(session.parent_session_id,) if session.parent_session_id else (),
            ),
            ContextBudgetRequest(
                layer_name="retrieval",
                desired_tokens=retrieval_tokens,
                minimum_tokens=32,
                required=False,
                priority=60,
                source_refs=tuple(memory.memory_id for memory in memories),
            ),
            ContextBudgetRequest(
                layer_name="tools",
                desired_tokens=tool_tokens,
                minimum_tokens=0,
                required=False,
                priority=10,
                source_refs=artifacts,
            ),
        )
        return requests

    def _build_summary_requests(
        self,
        session: SessionState,
        budgets: ContextBudgetPlan,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        hot_turns: tuple[str, ...],
    ) -> tuple[ContextSummaryRequest, ...]:
        requests: list[ContextSummaryRequest] = []
        warm_budget = budgets.allocation_for("warm")
        if warm_budget and (warm_budget.allocated_tokens < warm_budget.requested_tokens or session.interruption_state):
            requests.append(
                ContextSummaryRequest(
                    layer_name="warm",
                    source_refs=tuple(memory.memory_id for memory in memories[-3:]),
                    token_budget=warm_budget.allocated_tokens,
                    reason="compress warm history for continuity recovery",
                    required=True,
                )
            )
        retrieval_budget = budgets.allocation_for("retrieval")
        if retrieval_budget and retrieval_budget.allocated_tokens < retrieval_budget.requested_tokens:
            requests.append(
                ContextSummaryRequest(
                    layer_name="retrieval",
                    source_refs=tuple(memory.memory_id for memory in memories),
                    token_budget=retrieval_budget.allocated_tokens,
                    reason="summarize over-budget retrieval payloads",
                    required=False,
                )
            )
        if goals and not hot_turns:
            requests.append(
                ContextSummaryRequest(
                    layer_name="goals",
                    source_refs=tuple(goal.goal_id for goal in goals),
                    token_budget=budgets.allocation_for("goals").allocated_tokens if budgets.allocation_for("goals") else 0,
                    reason="surface active goals when hot context is absent",
                    required=False,
                )
            )
        return tuple(requests)

    def _retrieval_budget(self, budgets: ContextBudgetPlan) -> int:
        retrieval = budgets.allocation_for("retrieval")
        return retrieval.allocated_tokens if retrieval else 0

    def _suggest_retrieval_budget(self, memories: tuple[MemoryRecord, ...]) -> int:
        if not memories:
            return 0
        return min(128, max(24, len(memories) * 24))

    def _build_layers(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        instruction_refs: tuple[str, ...],
        hot_turns: tuple[str, ...],
        artifacts: tuple[str, ...],
        budgets: ContextBudgetPlan,
        summary_requests: tuple[ContextSummaryRequest, ...],
        retrieval_requests: tuple[ContextRetrievalRequest, ...],
    ) -> tuple[ContextLayerSnapshot, ...]:
        warm_memories = _select_warm_memories(memories, session=session, goals=goals)
        memory_index = {memory.memory_id: memory for memory in memories}
        summary_by_layer = {
            request.layer_name: self._summary_hook.summarize(
                session=session,
                layer_name=request.layer_name,
                content=_summary_content_for_layer(
                    request.layer_name,
                    session,
                    goals,
                    memories,
                    hot_turns,
                    warm_memories=warm_memories,
                    retrieval_requests=retrieval_requests,
                ),
                token_budget=request.token_budget,
                reason=request.reason,
            )
            for request in summary_requests
        }
        layers = (
            ContextLayerSnapshot(
                layer_name="instructions",
                source_refs=instruction_refs,
                content=instruction_refs,
                token_budget=_budget_for(budgets, "instructions"),
            ),
            ContextLayerSnapshot(
                layer_name="goals",
                source_refs=tuple(goal.goal_id for goal in goals),
                content=tuple(_goal_line(goal) for goal in goals) or ("no active goals",),
                token_budget=_budget_for(budgets, "goals"),
                summary=summary_by_layer.get("goals"),
            ),
            ContextLayerSnapshot(
                layer_name="hot",
                source_refs=tuple(f"turn:{index}" for index, _ in enumerate(hot_turns, start=1)),
                content=hot_turns or ("no hot turns",),
                token_budget=_budget_for(budgets, "hot"),
            ),
            ContextLayerSnapshot(
                layer_name="warm",
                source_refs=tuple(memory.memory_id for memory in warm_memories),
                content=tuple(_memory_line(memory) for memory in warm_memories) or ("no warm history",),
                token_budget=_budget_for(budgets, "warm"),
                summary=summary_by_layer.get("warm"),
            ),
            ContextLayerSnapshot(
                layer_name="retrieval",
                source_refs=tuple(
                    dict.fromkeys(memory_id for request in retrieval_requests for memory_id in request.memory_ids)
                ),
                content=_retrieval_lines(retrieval_requests, memory_index) or ("no retrieval",),
                token_budget=_budget_for(budgets, "retrieval"),
                summary=summary_by_layer.get("retrieval"),
            ),
            ContextLayerSnapshot(
                layer_name="tools",
                source_refs=artifacts,
                content=artifacts or ("no tool context",),
                token_budget=_budget_for(budgets, "tools"),
            ),
        )
        return layers

    def _build_source_trace(
        self,
        *,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        instruction_refs: tuple[str, ...],
        hot_turns: tuple[str, ...],
        artifacts: tuple[str, ...],
        summary_requests: tuple[ContextSummaryRequest, ...],
        retrieval_requests: tuple[ContextRetrievalRequest, ...],
    ) -> tuple[ContextSourceTrace, ...]:
        warm_memories = _select_warm_memories(memories, session=session, goals=goals)
        warm_refs = tuple(memory.memory_id for memory in warm_memories)
        retrieved_memory_ids = tuple(
            dict.fromkeys(memory_id for request in retrieval_requests for memory_id in request.memory_ids)
        )
        omitted_retrieval = tuple(memory.memory_id for memory in memories if memory.memory_id not in retrieved_memory_ids)
        omitted_warm = tuple(memory.memory_id for memory in memories if memory.memory_id not in warm_refs)
        return (
            ContextSourceTrace(
                layer_name="instructions",
                selected_refs=instruction_refs,
                reason="repository instructions and runtime guardrails stay in the bundle",
            ),
            ContextSourceTrace(
                layer_name="goals",
                selected_refs=tuple(goal.goal_id for goal in goals),
                reason=_goal_trace_reason(goals),
            ),
            ContextSourceTrace(
                layer_name="hot",
                selected_refs=hot_turns,
                reason=_hot_trace_reason(session, hot_turns),
            ),
            ContextSourceTrace(
                layer_name="warm",
                selected_refs=warm_refs,
                reason=_warm_trace_reason(session, goals, memories, warm_memories, summary_requests),
                omitted_refs=omitted_warm,
            ),
            ContextSourceTrace(
                layer_name="retrieval",
                selected_refs=retrieved_memory_ids,
                reason=_retrieval_trace_reason(retrieval_requests, retrieved_memory_ids, omitted_retrieval),
                omitted_refs=omitted_retrieval,
            ),
            ContextSourceTrace(
                layer_name="tools",
                selected_refs=artifacts,
                reason=_tool_trace_reason(artifacts),
            ),
        )


class ContextRuntime(ContextCapability):
    """Capability adapter for layered context assembly."""

    def __init__(
        self,
        planner: ContextPlanner | None = None,
        renderer: PromptRenderer | None = None,
        instruction_refs: tuple[str, ...] = (),
        total_tokens: int = 2048,
    ) -> None:
        self.descriptor = CapabilityDescriptor(
            capability_id="context.runtime",
            kind="context_assembler",
            version="1.0.0",
            metadata={"description": "Layered context assembly adapter."},
        )
        self._planner = planner or LayeredContextPlanner()
        self._renderer = renderer or MarkdownPromptRenderer()
        self._instruction_refs = instruction_refs
        self._total_tokens = total_tokens

    def plan(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        *,
        hot_turns: tuple[str, ...] = (),
        artifacts: tuple[str, ...] = (),
        total_tokens: int | None = None,
    ) -> ContextAssemblyPlan:
        return self._planner.plan(
            session=session,
            goals=goals,
            memories=memories,
            total_tokens=total_tokens if total_tokens is not None else self._total_tokens,
            instruction_refs=self._instruction_refs,
            hot_turns=hot_turns,
            artifacts=artifacts,
        )

    def assemble(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
    ) -> ContextBundle:
        plan = self.plan(session, goals, memories)
        rendered = self._renderer.render(plan)
        return ContextBundle(
            bundle_id=f"{session.session_id}:context",
            session_id=session.session_id,
            instruction_refs=self._instruction_refs,
            goal_ids=tuple(goal.goal_id for goal in goals),
            memory_ids=tuple(memory.memory_id for memory in memories),
            artifact_ids=(),
            token_budget=plan.total_tokens,
            rendered_prompt=rendered,
        )

    def assemble_detailed(
        self,
        session: SessionState,
        goals: tuple[GoalNode, ...],
        memories: tuple[MemoryRecord, ...],
        *,
        hot_turns: tuple[str, ...] = (),
        artifacts: tuple[str, ...] = (),
        total_tokens: int | None = None,
    ) -> ContextAssemblyResult:
        plan = self.plan(
            session,
            goals,
            memories,
            hot_turns=hot_turns,
            artifacts=artifacts,
            total_tokens=total_tokens,
        )
        rendered = self._renderer.render(plan)
        summary_by_layer = {
            layer.layer_name: layer.summary
            for layer in plan.layers
            if layer.summary is not None
        }
        retrieved_memory_ids = tuple(
            memory_id
            for request in plan.retrieval_requests
            for memory_id in request.memory_ids
        )
        bundle = ContextBundle(
            bundle_id=f"{session.session_id}:context",
            session_id=session.session_id,
            instruction_refs=self._instruction_refs,
            goal_ids=tuple(goal.goal_id for goal in goals),
            memory_ids=tuple(memory.memory_id for memory in memories),
            artifact_ids=artifacts,
            token_budget=plan.total_tokens,
            rendered_prompt=rendered,
        )
        return ContextAssemblyResult(
            bundle=bundle,
            plan=plan,
            rendered_prompt=rendered,
            summary_by_layer=summary_by_layer,
            retrieved_memory_ids=retrieved_memory_ids,
            source_trace=plan.source_trace,
        )


def _budget_for(budgets: ContextBudgetPlan, layer_name: str) -> int:
    allocation = budgets.allocation_for(layer_name)
    return allocation.allocated_tokens if allocation else 0


def _goal_line(goal: GoalNode) -> str:
    dependencies = f" deps={','.join(goal.dependencies)}" if goal.dependencies else ""
    evidence = f" evidence={','.join(goal.evidence_refs)}" if goal.evidence_refs else ""
    return f"{goal.goal_id}: {goal.title} [{goal.status}/{goal.priority}]{dependencies}{evidence}"


def _memory_line(memory: MemoryRecord) -> str:
    refs = f" goals={','.join(memory.goal_refs)}" if memory.goal_refs else ""
    tags = f" tags={','.join(memory.tags)}" if memory.tags else ""
    return f"{memory.memory_id}: {memory.kind} {memory.content}{refs}{tags}"


def _select_warm_memories(
    memories: tuple[MemoryRecord, ...],
    *,
    session: SessionState,
    goals: tuple[GoalNode, ...],
    limit: int = 3,
) -> tuple[MemoryRecord, ...]:
    if not memories:
        return ()
    scored = sorted(
        memories,
        key=lambda memory: (
            -_context_memory_score(memory, session=session, goals=goals, layer_name="warm"),
            -(memory.created_at.timestamp() if memory.created_at is not None else 0.0),
            memory.memory_id,
        ),
    )
    selected = scored[:limit]
    return tuple(
        sorted(
            selected,
            key=lambda memory: (
                memory.created_at.timestamp() if memory.created_at is not None else 0.0,
                memory.memory_id,
            ),
        )
    )


def _warm_memory_refs(memories: tuple[MemoryRecord, ...], *, session: SessionState, goals: tuple[GoalNode, ...]) -> tuple[str, ...]:
    return tuple(memory.memory_id for memory in _select_warm_memories(memories, session=session, goals=goals))


def _goal_trace_reason(goals: tuple[GoalNode, ...]) -> str:
    if not goals:
        return "no durable goals were available"
    selected = ", ".join(f"{goal.goal_id}({goal.status}/{goal.priority})" for goal in goals[:3])
    tail = " ..." if len(goals) > 3 else ""
    return f"durable goals stayed visible: {selected}{tail}"


def _hot_trace_reason(session: SessionState, hot_turns: tuple[str, ...]) -> str:
    if hot_turns:
        return f"{len(hot_turns)} hot turn(s) keep the current exchange in view"
    if session.interruption_state:
        return f"no hot turns were supplied, so recovery leans on {session.interruption_state}"
    return "no hot turns were supplied, so the bundle relies on durable state"


def _warm_trace_reason(
    session: SessionState,
    goals: tuple[GoalNode, ...],
    memories: tuple[MemoryRecord, ...],
    warm_memories: tuple[MemoryRecord, ...],
    summary_requests: tuple[ContextSummaryRequest, ...],
) -> str:
    warm_refs = tuple(memory.memory_id for memory in warm_memories)
    goal_ids = {goal.goal_id for goal in goals}
    goal_linked = tuple(memory.memory_id for memory in warm_memories if goal_ids.intersection(memory.goal_refs))
    corrected = tuple(memory.memory_id for memory in warm_memories if "corrected" in memory.tags)
    if session.interruption_state:
        reason = (
            f"session resumed from {session.interruption_state}; "
            f"{len(warm_refs)} continuity memory record(s) were selected instead of a blind recency slice"
        )
        if goal_linked:
            reason += f"; goal-linked warm refs: {', '.join(goal_linked)}"
        if corrected:
            reason += f"; corrected warm refs: {', '.join(corrected)}"
        return reason
    if summary_requests:
        return "warm memory was compacted with deterministic selection instead of staying as a blind recency slice"
    if warm_refs:
        return f"{len(warm_refs)} warm memory record(s) stayed close based on continuity and goal relevance"
    return "no warm history was available"


def _retrieval_trace_reason(
    retrieval_requests: tuple[ContextRetrievalRequest, ...],
    retrieved_memory_ids: tuple[str, ...],
    omitted_memory_ids: tuple[str, ...],
) -> str:
    if not retrieval_requests:
        return "no retrieval candidates were scheduled"
    reasons = [request.reason for request in retrieval_requests if request.reason]
    reason = "; ".join(dict.fromkeys(reasons[:2])) if reasons else "goal-linked memories were prioritized"
    if omitted_memory_ids:
        reason += f"; {len(omitted_memory_ids)} memory record(s) stayed out of the retrieval slice"
    elif retrieved_memory_ids:
        reason += f"; {len(retrieved_memory_ids)} memory record(s) entered the bundle"
    return reason


def _tool_trace_reason(artifacts: tuple[str, ...]) -> str:
    if artifacts:
        return f"{len(artifacts)} runtime artifact(s) stayed visible for execution context"
    return "no runtime artifacts were needed"


def _build_retrieval_query(memory: MemoryRecord, goals: tuple[GoalNode, ...]) -> str:
    goal_titles = " ".join(goal.title for goal in goals if goal.goal_id in memory.goal_refs)
    query = " ".join(part for part in (memory.kind, memory.content, goal_titles) if part)
    return query[:240]


def _build_retrieval_reason(
    memory: MemoryRecord,
    goals: tuple[GoalNode, ...],
    reasons: tuple[str, ...] = (),
) -> str:
    matched_goals = [goal.goal_id for goal in goals if goal.goal_id in memory.goal_refs]
    pieces: list[str] = []
    if matched_goals:
        pieces.append(f"goal-linked memory for {', '.join(matched_goals)}")
    pieces.extend(reason for reason in reasons if reason not in pieces)
    if not pieces:
        if memory.kind in {"summary", "decision", "lesson"}:
            pieces.append("high-value historical memory")
        else:
            pieces.append("supporting continuity memory")
    return "; ".join(pieces[:3])


def _estimate_tokens(content: str) -> int:
    return max(8, (len(content) // 4) + 1)


def _truncate_lines(content: tuple[str, ...], token_budget: int) -> tuple[str, ...]:
    remaining = max(token_budget, 0)
    lines: list[str] = []
    for line in content:
        if remaining <= 0:
            break
        lines.append(line[:120])
        remaining -= _estimate_tokens(line)
    return tuple(lines) if lines else ("no content",)


def _summary_content_for_layer(
    layer_name: str,
    session: SessionState,
    goals: tuple[GoalNode, ...],
    memories: tuple[MemoryRecord, ...],
    hot_turns: tuple[str, ...],
    *,
    warm_memories: tuple[MemoryRecord, ...],
    retrieval_requests: tuple[ContextRetrievalRequest, ...],
) -> tuple[str, ...]:
    if layer_name == "warm":
        goal_ids = {goal.goal_id for goal in goals}
        warm_refs = tuple(memory.memory_id for memory in warm_memories)
        omitted_refs = tuple(memory.memory_id for memory in memories if memory.memory_id not in warm_refs)
        goal_linked = tuple(
            memory.memory_id for memory in warm_memories if goal_ids.intersection(memory.goal_refs)
        )
        corrected = tuple(memory.memory_id for memory in warm_memories if "corrected" in memory.tags)
        lines: list[str] = []
        if goal_linked:
            lines.append(f"retained goal-linked refs: {', '.join(goal_linked)}")
        if corrected:
            lines.append(f"retained corrected refs: {', '.join(corrected)}")
        if omitted_refs:
            lines.append(f"compacted away: {', '.join(omitted_refs)}")
        if session.interruption_state:
            lines.append(f"interruption: {session.interruption_state}")
        lines.extend(_memory_line(memory) for memory in warm_memories)
        return tuple(lines)
    if layer_name == "retrieval":
        memory_index = {memory.memory_id: memory for memory in memories}
        return _retrieval_lines(retrieval_requests, memory_index)
    if layer_name == "goals":
        return tuple(_goal_line(goal) for goal in goals)
    return hot_turns


def _retrieval_lines(
    retrieval_requests: tuple[ContextRetrievalRequest, ...],
    memory_index: Mapping[str, MemoryRecord],
) -> tuple[str, ...]:
    lines: list[str] = []
    for request in retrieval_requests:
        for memory_id in request.memory_ids:
            memory = memory_index.get(memory_id)
            if memory is None:
                continue
            lines.append(f"{_memory_line(memory)} | why: {request.reason}")
    return tuple(lines)


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[A-Za-z0-9_]+", text.lower()) if token}


def _thematic_tokens(
    session: SessionState,
    goals: tuple[GoalNode, ...],
    hot_turns: tuple[str, ...],
) -> set[str]:
    tokens: set[str] = set()
    for goal in goals:
        tokens.update(_tokenize(goal.goal_id))
        tokens.update(_tokenize(goal.title))
        tokens.update(_tokenize(goal.status))
        tokens.update(_tokenize(goal.priority))
        tokens.update(_tokenize(" ".join(goal.dependencies)))
        tokens.update(_tokenize(" ".join(goal.evidence_refs)))
    tokens.update(_tokenize(" ".join(hot_turns)))
    tokens.update(_continuity_marker_tokens(session))
    return tokens


def _continuity_marker_tokens(session: SessionState) -> set[str]:
    if not session.interruption_state:
        return set()
    return _tokenize(session.interruption_state) | {"resume", "recovery", "continuity", "interruption", "gap"}


def _context_memory_score(
    memory: MemoryRecord,
    *,
    session: SessionState,
    goals: tuple[GoalNode, ...],
    layer_name: str,
    hot_turns: tuple[str, ...] = (),
    return_reasons: bool = False,
) -> float | tuple[float, tuple[str, ...]]:
    goal_ids = {goal.goal_id for goal in goals}
    thematic_tokens = _thematic_tokens(session, goals, hot_turns)
    continuity_markers = _continuity_marker_tokens(session)
    reasons: list[str] = []
    score = 0.0
    if memory.session_id == session.session_id:
        score += 4.0
        reasons.append("current-session memory")
    overlap = goal_ids.intersection(memory.goal_refs)
    score += float(len(overlap)) * 5.0
    if overlap:
        reasons.append(f"goal-linked: {', '.join(sorted(overlap))}")
    kind_bonus = {
        "summary": 3.0,
        "decision": 3.5,
        "lesson": 3.0,
        "semantic": 2.5,
        "procedural": 2.5,
        "artifact": 1.0,
    }
    score += kind_bonus.get(memory.kind, 0.0)
    if memory.kind in {"summary", "decision", "lesson"}:
        reasons.append(f"high-value kind: {memory.kind}")
    elif memory.kind in {"semantic", "procedural"}:
        reasons.append(f"durable kind: {memory.kind}")
    elif memory.kind == "artifact":
        reasons.append("artifact support")
    tags = set(memory.tags)
    if "corrected" in tags:
        score += 2.0
        reasons.append("corrected memory")
    if "consolidated" in tags:
        score += 1.0
        reasons.append("consolidated memory")
    if "filler" in tags:
        score -= 4.0
    if "continuity" in tags or "recovery" in tags:
        score += 1.0
    text_tokens = _tokenize(memory.content) | _tokenize(" ".join(memory.tags))
    thematic_overlap = tuple(sorted(text_tokens & thematic_tokens))
    if thematic_overlap:
        score += float(len(thematic_overlap)) * 1.75
        reasons.append(f"theme overlap: {', '.join(thematic_overlap[:4])}")
    if continuity_markers and (
        continuity_markers.intersection(text_tokens)
        or overlap
        or memory.kind in {"summary", "decision", "lesson", "semantic", "procedural"}
    ):
        score += 2.0
        reasons.append("continuity recovery support")
    if layer_name == "warm" and session.interruption_state:
        score += 1.5
    if memory.created_at is not None:
        score += memory.created_at.timestamp() / 10_000_000
    score += min(len(memory.tags), 4) * 0.001
    reason_tuple = tuple(dict.fromkeys(reasons))
    if return_reasons:
        return score, reason_tuple
    return score


def _retrieval_priority_bucket(
    memory: MemoryRecord,
    *,
    session: SessionState,
    goals: tuple[GoalNode, ...],
    hot_turns: tuple[str, ...],
) -> int:
    goal_ids = {goal.goal_id for goal in goals}
    text_tokens = _tokenize(memory.content) | _tokenize(" ".join(memory.tags))
    if goal_ids.intersection(memory.goal_refs):
        return 3
    if _thematic_tokens(session, goals, hot_turns).intersection(text_tokens):
        return 2
    if memory.session_id == session.session_id and memory.kind in {"summary", "decision", "lesson", "semantic", "procedural"}:
        return 1
    return 0


def _plan_rationale(
    session: SessionState,
    goals: tuple[GoalNode, ...],
    memories: tuple[MemoryRecord, ...],
    budgets: ContextBudgetPlan,
) -> str:
    if session.interruption_state:
        return (
            f"continuity recovery is prioritized because the session resumed from {session.interruption_state}; "
            "warm history is compacted and durable retrieval is reintroduced"
        )
    if len(memories) > 5 and budgets.overflow_tokens > 0:
        return (
            "long-running session overflow pushes the planner to summarize warm history "
            "and schedule goal-linked retrieval"
        )
    if goals:
        return f"active durable goal {goals[0].goal_id} is kept close to the reasoning loop"
    return "stable prompt assembly with explicit budget allocation"
