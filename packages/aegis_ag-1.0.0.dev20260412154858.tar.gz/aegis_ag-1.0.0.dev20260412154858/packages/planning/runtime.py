"""Goal graph planning services for long-horizon decision making.

The planning package stays contract-backed and backend-neutral. It models the
goal graph explicitly, scores candidate next moves in a transparent way, and
emits rationale records that the kernel or telemetry layer can persist.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from typing import Any, ClassVar, Literal, Mapping, cast

from packages.contracts import (
    EventEnvelope,
    GoalNode as ContractGoalNode,
    MemoryRecord,
    PlanDraft,
    PlanStep,
    SessionState,
)

GoalStatus = Literal[
    "proposed",
    "queued",
    "active",
    "blocked",
    "deferred",
    "completed",
    "done",
    "failed",
    "dropped",
]
GoalOwner = Literal["user", "agent", "shared"]
GoalPriority = Literal["low", "medium", "high", "critical"]
TimeSensitivity = Literal["low", "normal", "high", "urgent"]
PlanningMode = Literal["reactive", "guided", "proactive"]
MoveKind = Literal[
    "answer_directly",
    "act_on_task",
    "ask_for_information",
    "update_plan",
    "defer_or_schedule",
]

GOAL_STATUS_ORDER: tuple[GoalStatus, ...] = (
    "proposed",
    "queued",
    "active",
    "blocked",
    "deferred",
    "completed",
    "done",
    "failed",
    "dropped",
)

GOAL_PRIORITY_ORDER: tuple[GoalPriority, ...] = ("low", "medium", "high", "critical")
TIME_SENSITIVITY_ORDER: tuple[TimeSensitivity, ...] = ("low", "normal", "high", "urgent")
PLANNING_MODES: tuple[PlanningMode, ...] = ("reactive", "guided", "proactive")
MOVE_KINDS: tuple[MoveKind, ...] = (
    "answer_directly",
    "act_on_task",
    "ask_for_information",
    "update_plan",
    "defer_or_schedule",
)

_PRIORITY_POINTS: Mapping[GoalPriority, float] = {
    "low": 1.0,
    "medium": 2.0,
    "high": 3.0,
    "critical": 4.0,
}

_STATUS_POINTS: Mapping[GoalStatus, float] = {
    "proposed": 0.8,
    "queued": 1.4,
    "active": 2.2,
    "blocked": 0.3,
    "deferred": 0.1,
    "completed": 0.0,
    "done": 0.0,
    "failed": 0.0,
    "dropped": 0.0,
}

_TIME_SENSITIVITY_POINTS: Mapping[TimeSensitivity, float] = {
    "low": 0.0,
    "normal": 0.3,
    "high": 0.7,
    "urgent": 1.1,
}

_INITIATIVE_CONTINUITY_BONUS: Mapping[str, float] = {
    "quiet": -0.1,
    "gentle": 0.0,
    "steady": 0.15,
    "proactive": 0.35,
    "direct": 0.2,
}


def _now() -> datetime:
    return datetime.now(UTC)


def _parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value)


def _format_delta(delta: timedelta) -> str:
    seconds = int(delta.total_seconds())
    if seconds < 0:
        return f"{abs(seconds)}s overdue"
    minutes, rem_seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m {rem_seconds}s"
    return f"{rem_seconds}s"


def _stringify(values: tuple[str, ...]) -> str:
    return ", ".join(values)


def _normalize_initiative(initiative_hint: str | None) -> str:
    if initiative_hint is None:
        return "gentle"
    normalized = initiative_hint.strip().lower()
    return normalized or "gentle"


def _record_tuple(record: Mapping[str, Any], key: str) -> tuple[str, ...]:
    value = record.get(key)
    if value is None:
        return ()
    if isinstance(value, tuple):
        return tuple(str(item) for item in value)
    if isinstance(value, list):
        return tuple(str(item) for item in value)
    if isinstance(value, str):
        return () if value == "" else (value,)
    return tuple(str(item) for item in value)


def _continuity_note_bonus(notes: tuple[str, ...]) -> float:
    bonus = 0.0
    for note in notes:
        normalized = note.strip().lower()
        if not normalized:
            continue
        if any(token in normalized for token in ("check in", "follow up", "follow-up", "quiet gap", "resume", "reconnect")):
            bonus += 0.12
        elif any(token in normalized for token in ("continuity", "durable", "remember", "reach out")):
            bonus += 0.06
    return min(0.3, round(bonus, 3))


def _continuity_note_factors(notes: tuple[str, ...]) -> tuple[str, ...]:
    factors: list[str] = []
    for note in notes:
        normalized = "-".join(note.strip().lower().split())
        if normalized:
            factors.append(f"continuity-note={normalized[:48]}")
    return tuple(dict.fromkeys(factors))


@dataclass(frozen=True, slots=True)
class GoalGraphNode:
    goal_id: str
    session_id: str
    title: str
    status: GoalStatus
    priority: GoalPriority
    owner: GoalOwner = "agent"
    parent_goal_id: str | None = None
    dependency_refs: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    related_memory_ids: tuple[str, ...] = ()
    deadline: datetime | None = None
    time_sensitivity: TimeSensitivity = "normal"
    review_checkpoint: str | None = None
    revision_id: str | None = None
    updated_at: datetime = field(default_factory=_now)

    def to_contract_goal(self) -> ContractGoalNode:
        return ContractGoalNode(
            goal_id=self.goal_id,
            session_id=self.session_id,
            title=self.title,
            status=self.status,
            priority=self.priority,
            dependencies=self.dependency_refs,
            evidence_refs=self.evidence_refs,
            owner=self.owner,
        )

    def to_record(self) -> dict[str, Any]:
        return {
            "goal_id": self.goal_id,
            "session_id": self.session_id,
            "title": self.title,
            "status": self.status,
            "priority": self.priority,
            "owner": self.owner,
            "parent_goal_id": self.parent_goal_id,
            "dependency_refs": self.dependency_refs,
            "evidence_refs": self.evidence_refs,
            "related_memory_ids": self.related_memory_ids,
            "deadline": self.deadline.isoformat() if self.deadline else None,
            "time_sensitivity": self.time_sensitivity,
            "review_checkpoint": self.review_checkpoint,
            "revision_id": self.revision_id,
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_record(cls, record: Mapping[str, Any]) -> "GoalGraphNode":
        return cls(
            goal_id=str(record["goal_id"]),
            session_id=str(record["session_id"]),
            title=str(record["title"]),
            status=cast(GoalStatus, str(record["status"])),
            priority=cast(GoalPriority, str(record["priority"])),
            owner=cast(GoalOwner, str(record["owner"])) if record.get("owner") is not None else "agent",
            parent_goal_id=str(record["parent_goal_id"]) if record.get("parent_goal_id") is not None else None,
            dependency_refs=_record_tuple(record, "dependency_refs"),
            evidence_refs=_record_tuple(record, "evidence_refs"),
            related_memory_ids=_record_tuple(record, "related_memory_ids"),
            deadline=_parse_datetime(str(record["deadline"])) if record.get("deadline") is not None else None,
            time_sensitivity=cast(TimeSensitivity, str(record.get("time_sensitivity", "normal"))),
            review_checkpoint=str(record["review_checkpoint"]) if record.get("review_checkpoint") is not None else None,
            revision_id=str(record["revision_id"]) if record.get("revision_id") is not None else None,
            updated_at=_parse_datetime(str(record["updated_at"])) if record.get("updated_at") is not None else _now(),
        )

    @classmethod
    def from_contract_goal(
        cls,
        goal: ContractGoalNode,
        *,
        deadline: datetime | None = None,
        time_sensitivity: TimeSensitivity = "normal",
        parent_goal_id: str | None = None,
        related_memory_ids: tuple[str, ...] = (),
        review_checkpoint: str | None = None,
        revision_id: str | None = None,
        updated_at: datetime | None = None,
    ) -> "GoalGraphNode":
        return cls(
            goal_id=goal.goal_id,
            session_id=goal.session_id,
            title=goal.title,
            status=cast(GoalStatus, goal.status),
            priority=cast(GoalPriority, goal.priority),
            owner=goal.owner or "agent",
            parent_goal_id=parent_goal_id,
            dependency_refs=goal.dependencies,
            evidence_refs=goal.evidence_refs,
            related_memory_ids=related_memory_ids,
            deadline=deadline,
            time_sensitivity=time_sensitivity,
            review_checkpoint=review_checkpoint,
            revision_id=revision_id,
            updated_at=_now() if updated_at is None else updated_at,
        )

    def transition(
        self,
        *,
        status: GoalStatus,
        revision_id: str | None = None,
        updated_at: datetime | None = None,
        dependency_refs: tuple[str, ...] | None = None,
        evidence_refs: tuple[str, ...] | None = None,
        related_memory_ids: tuple[str, ...] | None = None,
        review_checkpoint: str | None = None,
    ) -> "GoalGraphNode":
        return replace(
            self,
            status=status,
            revision_id=self.revision_id if revision_id is None else revision_id,
            updated_at=_now() if updated_at is None else updated_at,
            dependency_refs=self.dependency_refs if dependency_refs is None else dependency_refs,
            evidence_refs=self.evidence_refs if evidence_refs is None else evidence_refs,
            related_memory_ids=self.related_memory_ids if related_memory_ids is None else related_memory_ids,
            review_checkpoint=self.review_checkpoint if review_checkpoint is None else review_checkpoint,
        )


@dataclass(frozen=True, slots=True)
class GoalGraph:
    session_id: str
    nodes: tuple[GoalGraphNode, ...] = ()
    root_goal_id: str | None = None
    active_goal_id: str | None = None
    revision_id: str | None = None
    updated_at: datetime = field(default_factory=_now)

    def index(self) -> dict[str, GoalGraphNode]:
        return {node.goal_id: node for node in self.nodes}

    def goal(self, goal_id: str) -> GoalGraphNode | None:
        return self.index().get(goal_id)

    def active_goal(self) -> GoalGraphNode | None:
        if self.active_goal_id is None:
            return None
        return self.goal(self.active_goal_id)

    def status_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for node in self.nodes:
            counts[node.status] = counts.get(node.status, 0) + 1
        return counts

    def ready_goals(self) -> tuple[GoalGraphNode, ...]:
        indexed = self.index()
        return tuple(
            node
            for node in self.nodes
            if node.status in {"proposed", "queued", "active"}
            and _dependencies_satisfied(node, indexed)
        )

    def blocked_goals(self) -> tuple[GoalGraphNode, ...]:
        indexed = self.index()
        return tuple(
            node
            for node in self.nodes
            if node.status == "blocked"
            or (
                node.status not in {"deferred", "completed", "done", "failed", "dropped"}
                and not _dependencies_satisfied(node, indexed)
            )
        )

    def with_nodes(self, nodes: tuple[GoalGraphNode, ...]) -> "GoalGraph":
        return replace(self, nodes=nodes, updated_at=_now())

    def with_goal(self, goal: GoalGraphNode) -> "GoalGraph":
        indexed = self.index()
        nodes = tuple(goal if node.goal_id == goal.goal_id else node for node in self.nodes)
        if goal.goal_id not in indexed:
            nodes = self.nodes + (goal,)
        return replace(self, nodes=nodes, updated_at=_now())

    def transition_goal(
        self,
        goal_id: str,
        *,
        status: GoalStatus,
        revision_id: str | None = None,
        updated_at: datetime | None = None,
        active_goal_id: str | None = None,
        dependency_refs: tuple[str, ...] | None = None,
        evidence_refs: tuple[str, ...] | None = None,
        related_memory_ids: tuple[str, ...] | None = None,
        review_checkpoint: str | None = None,
    ) -> "GoalGraph":
        indexed = self.index()
        goal = indexed.get(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        updated_goal = goal.transition(
            status=status,
            revision_id=revision_id,
            updated_at=updated_at,
            dependency_refs=dependency_refs,
            evidence_refs=evidence_refs,
            related_memory_ids=related_memory_ids,
            review_checkpoint=review_checkpoint,
        )
        updated_nodes = tuple(updated_goal if node.goal_id == goal_id else node for node in self.nodes)
        next_active_goal_id = self.active_goal_id
        if active_goal_id is not None:
            next_active_goal_id = active_goal_id
        elif status == "active":
            next_active_goal_id = goal_id
        elif self.active_goal_id == goal_id and status in {"blocked", "deferred", "completed", "done", "failed", "dropped"}:
            next_active_goal_id = None
        return replace(
            self,
            nodes=updated_nodes,
            active_goal_id=next_active_goal_id,
            revision_id=updated_goal.revision_id if updated_goal.revision_id is not None else self.revision_id,
            updated_at=_now() if updated_at is None else updated_at,
        )

    def to_record(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "root_goal_id": self.root_goal_id,
            "active_goal_id": self.active_goal_id,
            "revision_id": self.revision_id,
            "updated_at": self.updated_at.isoformat(),
            "nodes": tuple(node.to_record() for node in self.nodes),
        }

    @classmethod
    def from_record(cls, record: Mapping[str, Any]) -> "GoalGraph":
        raw_nodes = record.get("nodes") or record.get("goals") or ()
        nodes = tuple(
            node if isinstance(node, GoalGraphNode) else GoalGraphNode.from_record(node)
            for node in raw_nodes
        )
        return cls(
            session_id=str(record["session_id"]),
            nodes=nodes,
            root_goal_id=str(record["root_goal_id"]) if record.get("root_goal_id") is not None else None,
            active_goal_id=str(record["active_goal_id"]) if record.get("active_goal_id") is not None else None,
            revision_id=str(record["revision_id"]) if record.get("revision_id") is not None else None,
            updated_at=_parse_datetime(str(record["updated_at"])) if record.get("updated_at") is not None else _now(),
        )

@dataclass(frozen=True, slots=True)
class TemporalContext:
    resumed: bool
    session_resume_reason: str | None = None
    active_goal_id: str | None = None
    ready_goal_ids: tuple[str, ...] = ()
    blocked_goal_ids: tuple[str, ...] = ()
    recovery_goal_ids: tuple[str, ...] = ()
    blocked_active_goal_id: str | None = None
    overdue_goal_ids: tuple[str, ...] = ()
    due_soon_goal_ids: tuple[str, ...] = ()
    idle_for: timedelta | None = None

    def to_record(self) -> dict[str, Any]:
        return {
            "resumed": self.resumed,
            "session_resume_reason": self.session_resume_reason,
            "active_goal_id": self.active_goal_id,
            "ready_goal_ids": self.ready_goal_ids,
            "blocked_goal_ids": self.blocked_goal_ids,
            "recovery_goal_ids": self.recovery_goal_ids,
            "blocked_active_goal_id": self.blocked_active_goal_id,
            "overdue_goal_ids": self.overdue_goal_ids,
            "due_soon_goal_ids": self.due_soon_goal_ids,
            "idle_for": _format_delta(self.idle_for) if self.idle_for else None,
        }


@dataclass(frozen=True, slots=True)
class ExecutionTracker:
    in_flight_goal_ids: tuple[str, ...] = ()
    blocker_refs: tuple[str, ...] = ()
    retry_goal_ids: tuple[str, ...] = ()
    completion_evidence_refs: tuple[str, ...] = ()

    def to_record(self) -> dict[str, Any]:
        return {
            "in_flight_goal_ids": self.in_flight_goal_ids,
            "blocker_refs": self.blocker_refs,
            "retry_goal_ids": self.retry_goal_ids,
            "completion_evidence_refs": self.completion_evidence_refs,
        }


@dataclass(frozen=True, slots=True)
class CandidateMove:
    move_id: str
    kind: MoveKind
    goal_id: str | None
    title: str
    score: float
    priority_score: float
    status_score: float
    deadline_score: float
    time_sensitivity_score: float
    dependency_score: float
    resume_score: float
    continuity_score: float
    tracker_score: float
    evidence_score: float
    repair_score: float
    rationale: str
    rationale_factors: tuple[str, ...] = ()
    dependency_refs: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    confidence: float = 0.0

    def to_record(self) -> dict[str, Any]:
        return {
            "move_id": self.move_id,
            "kind": self.kind,
            "goal_id": self.goal_id,
            "title": self.title,
            "score": self.score,
            "priority_score": self.priority_score,
            "status_score": self.status_score,
            "deadline_score": self.deadline_score,
            "time_sensitivity_score": self.time_sensitivity_score,
            "dependency_score": self.dependency_score,
            "resume_score": self.resume_score,
            "continuity_score": self.continuity_score,
            "tracker_score": self.tracker_score,
            "evidence_score": self.evidence_score,
            "repair_score": self.repair_score,
            "rationale": self.rationale,
            "rationale_factors": self.rationale_factors,
            "dependency_refs": self.dependency_refs,
            "evidence_refs": self.evidence_refs,
            "confidence": self.confidence,
        }


@dataclass(frozen=True, slots=True)
class PlanningRationale:
    summary: str
    factors: tuple[str, ...]
    candidate_ids: tuple[str, ...]
    selected_move_id: str
    selected_goal_id: str | None
    selected_goal_status: GoalStatus | None
    selected_goal_priority: GoalPriority | None
    progression_action: str
    active_goal_id_before: str | None
    planned_active_goal_id: str | None
    mode: PlanningMode

    def to_record(self) -> dict[str, Any]:
        return {
            "summary": self.summary,
            "factors": self.factors,
            "candidate_ids": self.candidate_ids,
            "selected_move_id": self.selected_move_id,
            "selected_goal_id": self.selected_goal_id,
            "selected_goal_status": self.selected_goal_status,
            "selected_goal_priority": self.selected_goal_priority,
            "progression_action": self.progression_action,
            "active_goal_id_before": self.active_goal_id_before,
            "planned_active_goal_id": self.planned_active_goal_id,
            "mode": self.mode,
        }


@dataclass(frozen=True, slots=True)
class PlanningDecision:
    decision_id: str
    session_id: str
    mode: PlanningMode
    selected_move: CandidateMove
    rationale: PlanningRationale
    candidates: tuple[CandidateMove, ...]
    temporal_context: TemporalContext
    selected_at: datetime = field(default_factory=_now)
    goal_graph_revision: datetime | None = None

    def to_record(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "session_id": self.session_id,
            "mode": self.mode,
            "selected_move": self.selected_move.to_record(),
            "rationale": self.rationale.to_record(),
            "candidates": tuple(candidate.to_record() for candidate in self.candidates),
            "temporal_context": self.temporal_context.to_record(),
            "selected_at": self.selected_at.isoformat(),
            "goal_graph_revision": self.goal_graph_revision.isoformat() if self.goal_graph_revision else None,
        }


def _dependencies_satisfied(goal: GoalGraphNode, indexed: Mapping[str, GoalGraphNode]) -> bool:
    for dependency_id in goal.dependency_refs:
        dependency = indexed.get(dependency_id)
        if dependency is None:
            return False
        if dependency.status not in {"completed", "done", "queued", "active"}:
            return False
    return True


def _deadline_score(deadline: datetime | None, now: datetime) -> float:
    if deadline is None:
        return 0.0
    delta = deadline - now
    hours = delta.total_seconds() / 3600.0
    if hours <= 0:
        return 1.4
    if hours <= 4:
        return 1.1
    if hours <= 24:
        return 0.7
    if hours <= 72:
        return 0.35
    return 0.1


def _staleness_score(goal: GoalGraphNode, temporal: TemporalContext, now: datetime) -> float:
    goal_idle_for = now - goal.updated_at
    if goal_idle_for < timedelta(0):
        goal_idle_for = timedelta(0)
    effective_idle = goal_idle_for
    if temporal.idle_for is not None and temporal.idle_for > effective_idle:
        effective_idle = temporal.idle_for
    if effective_idle < timedelta(hours=12):
        return 0.0
    severe = effective_idle >= timedelta(days=2)
    if goal.goal_id == temporal.active_goal_id and goal.status == "blocked":
        return 0.6 if severe else 0.35
    if goal.goal_id == temporal.active_goal_id:
        return 0.75 if severe else 0.4
    if goal.status == "blocked":
        return 0.45 if severe else 0.2
    if goal.goal_id in temporal.ready_goal_ids:
        return 0.2 if severe else 0.1
    return 0.0


def _continuity_score(goal: GoalGraphNode, graph: GoalGraph, temporal: TemporalContext) -> float:
    active_goal = graph.active_goal()
    if goal.goal_id == graph.active_goal_id:
        return 0.9
    if graph.active_goal_id is not None and goal.parent_goal_id == graph.active_goal_id:
        return 0.45
    if active_goal is not None and active_goal.parent_goal_id is not None and goal.parent_goal_id == active_goal.parent_goal_id:
        return 0.2
    if goal.goal_id == graph.root_goal_id:
        return 0.15
    if graph.root_goal_id is not None and goal.parent_goal_id == graph.root_goal_id:
        return 0.1
    if temporal.resumed and goal.goal_id in temporal.ready_goal_ids:
        return 0.1
    return 0.0


def _blocked_recovery_goal_ids(graph: GoalGraph, ready_goal_ids: tuple[str, ...]) -> tuple[str, ...]:
    active_goal = graph.active_goal()
    if active_goal is None or active_goal.status != "blocked":
        return ()
    ready = set(ready_goal_ids)
    recovery_goal_ids: list[str] = []
    for goal in graph.nodes:
        if goal.goal_id == active_goal.goal_id or goal.goal_id not in ready:
            continue
        if active_goal.parent_goal_id is not None and goal.parent_goal_id == active_goal.parent_goal_id:
            recovery_goal_ids.append(goal.goal_id)
            continue
        if goal.parent_goal_id == active_goal.goal_id:
            recovery_goal_ids.append(goal.goal_id)
            continue
        if graph.root_goal_id is not None and goal.parent_goal_id == graph.root_goal_id:
            recovery_goal_ids.append(goal.goal_id)
    return tuple(dict.fromkeys(recovery_goal_ids))


def _repair_score(goal: GoalGraphNode, temporal: TemporalContext) -> float:
    if temporal.blocked_active_goal_id is None:
        return 0.0
    if goal.goal_id == temporal.blocked_active_goal_id and temporal.recovery_goal_ids:
        return -1.4
    if goal.goal_id in temporal.recovery_goal_ids:
        return 1.2
    if goal.goal_id in temporal.ready_goal_ids:
        return 0.2
    return 0.0


def _kind_for_goal(goal: GoalGraphNode, temporal: TemporalContext, execution_tracker: ExecutionTracker | None) -> MoveKind:
    if goal.status == "blocked" or goal.goal_id in temporal.blocked_goal_ids:
        return "update_plan"
    if goal.status in {"deferred", "completed", "done", "failed", "dropped"}:
        return "defer_or_schedule"
    if goal.goal_id in temporal.overdue_goal_ids:
        return "act_on_task"
    if goal.goal_id in temporal.ready_goal_ids:
        if temporal.resumed and goal.goal_id == temporal.active_goal_id:
            return "act_on_task"
        if goal.status == "active":
            return "act_on_task"
        if execution_tracker and goal.goal_id in execution_tracker.in_flight_goal_ids:
            return "act_on_task"
        return "act_on_task"
    if goal.dependency_refs:
        return "ask_for_information"
    return "defer_or_schedule"


def _rationale_for(
    goal: GoalGraphNode,
    temporal: TemporalContext,
    kind: MoveKind,
    tracker: ExecutionTracker | None,
    *,
    now: datetime,
) -> tuple[str, tuple[str, ...]]:
    factors: list[str] = []
    sentences: list[str] = []

    if temporal.resumed:
        factors.append("session-resumed")
        if temporal.session_resume_reason:
            sentences.append(temporal.session_resume_reason)
        else:
            sentences.append("The session resumed from durable state.")

    if goal.status == "active":
        factors.append("active-goal")
        sentences.append("The active goal is already in progress, so continuing it preserves continuity.")
    elif goal.status == "queued":
        factors.append("queued-goal")
        sentences.append("The goal is queued and ready to be advanced.")
    elif goal.status == "proposed":
        factors.append("proposed-goal")
        sentences.append("The goal is proposed and available for selection.")
    elif goal.status == "blocked":
        factors.append("blocked-goal")
        sentences.append("The goal is blocked, so the planner should surface the blocker or re-plan.")
    elif goal.status == "deferred":
        factors.append("deferred-goal")
        sentences.append("The goal is deferred and should remain durable until a later resume or explicit reactivation.")
    elif goal.status in {"completed", "done"}:
        factors.append("completed-goal")
        sentences.append("The goal is completed and remains durable for inspection and handoff.")

    if temporal.blocked_active_goal_id is not None:
        if goal.goal_id in temporal.recovery_goal_ids:
            factors.append("blocked-goal-recovery")
            sentences.append(
                "The active goal is blocked, so the planner should recover through a ready adjacent goal instead of repeating the blocked step."
            )
        elif goal.goal_id == temporal.blocked_active_goal_id and temporal.recovery_goal_ids:
            factors.append("blocked-goal-suppressed")
            sentences.append(
                "A ready recovery path exists elsewhere in the graph, so the blocked active goal should not be selected again immediately."
            )

    if goal.deadline is not None:
        factors.append("deadline")
        if goal.deadline <= now:
            sentences.append("The deadline has passed, which raises urgency.")
        else:
            sentences.append(f"The deadline is approaching in {_format_delta(goal.deadline - now)}.")

    if goal.dependency_refs:
        factors.append("dependencies")
        if kind == "ask_for_information":
            sentences.append("One or more dependencies are still unresolved.")
        else:
            sentences.append("Its dependencies appear satisfiable from the current graph.")

    if tracker and goal.goal_id in tracker.in_flight_goal_ids:
        factors.append("in-flight")
        sentences.append("The execution tracker shows this goal is still in flight.")

    if goal.evidence_refs:
        factors.append("evidence")
        sentences.append("Durable evidence is attached to the goal, so the next step can stay grounded.")

    staleness_score = _staleness_score(goal, temporal, now)
    if staleness_score > 0:
        if goal.goal_id == temporal.active_goal_id and goal.status == "blocked":
            factors.append("stale-blocked-goal")
            sentences.append("The blocked active goal has sat idle long enough that the planner should force a visible re-plan.")
        elif goal.goal_id == temporal.active_goal_id:
            factors.append("stale-active-goal")
            sentences.append("The active goal has remained idle long enough that the planner should re-engage it explicitly.")
        elif goal.status == "blocked":
            factors.append("stale-blocked-goal")
            sentences.append("The blocked goal has lingered in the graph, so the planner should resolve it instead of letting it silently decay.")
        else:
            factors.append("stale-ready-goal")
            sentences.append("The ready goal has been waiting in durable state and deserves a fresh decision.")

    if not sentences:
        sentences.append("The selected move best balances priority, readiness, and continuity.")

    if kind == "act_on_task":
        sentences.append("The planner advances the work because the durable graph shows a ready goal.")
    elif kind == "update_plan":
        sentences.append("The planner updates the plan instead of advancing because blockers still need attention.")
    elif kind == "defer_or_schedule":
        sentences.append("The planner defers the goal so the wake loop can return to it later without losing state.")
    elif kind == "ask_for_information":
        sentences.append("The planner pauses to gather the missing information before advancing.")

    summary = " ".join(sentences)
    return summary, tuple(dict.fromkeys(factors))


def _progression_action_for(kind: MoveKind) -> str:
    if kind in {"act_on_task", "answer_directly"}:
        return "advance"
    if kind == "update_plan":
        return "replan"
    if kind == "ask_for_information":
        return "gather_information"
    return "defer"


def _planned_progression(
    graph: GoalGraph,
    goal: GoalGraphNode | None,
    kind: MoveKind,
) -> tuple[GoalStatus | None, str | None]:
    if goal is None:
        return None, graph.active_goal_id
    if kind in {"act_on_task", "answer_directly"}:
        return "active", goal.goal_id
    if kind == "defer_or_schedule":
        if goal.status in {"completed", "done"}:
            next_status = goal.status
        else:
            next_status = "deferred"
        next_active_goal_id = None if graph.active_goal_id == goal.goal_id else graph.active_goal_id
        return next_status, next_active_goal_id
    if kind == "update_plan":
        next_active_goal_id = None if graph.active_goal_id == goal.goal_id and goal.status == "blocked" else graph.active_goal_id
        return goal.status, next_active_goal_id
    return goal.status, graph.active_goal_id


def _progression_sentence(
    goal: GoalGraphNode | None,
    *,
    action: str,
    planned_status: GoalStatus | None,
    planned_active_goal_id: str | None,
) -> str:
    if goal is None:
        if action == "defer":
            return "The durable graph defers the goal set and keeps the active slot clear until a later wake cycle."
        return "No durable goal state changed because no actionable goal was selected."
    if action == "advance":
        return f'The durable graph keeps "{goal.title}" active as the next step.'
    if action == "replan":
        return f'The durable graph keeps "{goal.title}" {planned_status or goal.status} until the blocker is cleared.'
    if action == "gather_information":
        return f'The durable graph leaves "{goal.title}" {planned_status or goal.status} until missing information arrives.'
    if planned_active_goal_id is None:
        return f'The durable graph records "{goal.title}" as {planned_status or goal.status} and clears the active slot.'
    return f'The durable graph records "{goal.title}" as {planned_status or goal.status} while preserving active goal {planned_active_goal_id}.'


class TemporalReasoner:
    """Inspect the graph for time pressure and resume signals."""

    resume_gap: timedelta
    due_soon_window: timedelta

    def __init__(
        self,
        *,
        resume_gap: timedelta | None = None,
        due_soon_window: timedelta | None = None,
    ) -> None:
        self.resume_gap = timedelta(hours=6) if resume_gap is None else resume_gap
        self.due_soon_window = timedelta(days=1) if due_soon_window is None else due_soon_window

    def analyze(
        self,
        session: SessionState,
        graph: GoalGraph,
        *,
        now: datetime | None = None,
    ) -> TemporalContext:
        current = _now() if now is None else now
        resumed = session.interruption_state is not None or session.parent_session_id is not None
        session_resume_reason = None
        if resumed:
            session_resume_reason = "The session resumed from a prior collaboration and should continue the durable goal graph."

        ready_goal_ids: list[str] = []
        blocked_goal_ids: list[str] = []
        overdue_goal_ids: list[str] = []
        due_soon_goal_ids: list[str] = []

        indexed = graph.index()
        for goal in graph.nodes:
            dependencies_ready = _dependencies_satisfied(goal, indexed)
            if goal.status in {"proposed", "queued", "active"} and dependencies_ready:
                ready_goal_ids.append(goal.goal_id)
            if goal.status == "blocked" or (
                goal.status not in {"deferred", "completed", "done", "failed", "dropped"}
                and not dependencies_ready
            ):
                blocked_goal_ids.append(goal.goal_id)
            if goal.deadline is not None:
                delta = goal.deadline - current
                if delta <= timedelta(0):
                    overdue_goal_ids.append(goal.goal_id)
                elif delta <= self.due_soon_window:
                    due_soon_goal_ids.append(goal.goal_id)

        idle_for = None
        if session.interruption_state is not None:
            idle_for = current - session.updated_at
            if idle_for < timedelta(0):
                idle_for = None

        ordered_ready_goal_ids = tuple(dict.fromkeys(ready_goal_ids))
        ordered_blocked_goal_ids = tuple(dict.fromkeys(blocked_goal_ids))
        blocked_active_goal_id = graph.active_goal_id if graph.active_goal_id in ordered_blocked_goal_ids else None
        recovery_goal_ids = _blocked_recovery_goal_ids(graph, ordered_ready_goal_ids)

        return TemporalContext(
            resumed=resumed,
            session_resume_reason=session_resume_reason,
            active_goal_id=graph.active_goal_id,
            ready_goal_ids=ordered_ready_goal_ids,
            blocked_goal_ids=ordered_blocked_goal_ids,
            recovery_goal_ids=recovery_goal_ids,
            blocked_active_goal_id=blocked_active_goal_id,
            overdue_goal_ids=tuple(dict.fromkeys(overdue_goal_ids)),
            due_soon_goal_ids=tuple(dict.fromkeys(due_soon_goal_ids)),
            idle_for=idle_for,
        )


class PlanningService:
    """Score goal graph candidates and emit next-step rationale."""

    def __init__(self, reasoner: TemporalReasoner | None = None) -> None:
        self._reasoner = TemporalReasoner() if reasoner is None else reasoner

    def score_candidates(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        mode: PlanningMode = "guided",
        now: datetime | None = None,
    ) -> tuple[CandidateMove, ...]:
        current = _now() if now is None else now
        temporal = self._reasoner.analyze(session, graph, now=current)
        indexed = graph.index()
        candidates: list[CandidateMove] = []
        initiative = _normalize_initiative(initiative_hint)
        continuity_bonus = _INITIATIVE_CONTINUITY_BONUS.get(initiative, 0.0)
        note_bonus = _continuity_note_bonus(continuity_notes)
        note_factors = _continuity_note_factors(continuity_notes)

        for goal in graph.nodes:
            if goal.status in {"completed", "done", "failed", "dropped", "deferred"}:
                continue

            dependencies_ready = _dependencies_satisfied(goal, indexed)
            priority_score = _PRIORITY_POINTS[goal.priority]
            status_score = _STATUS_POINTS[goal.status]
            deadline_score = _deadline_score(goal.deadline, current)
            time_sensitivity_score = _TIME_SENSITIVITY_POINTS[goal.time_sensitivity]
            dependency_score = 0.6 if dependencies_ready else -1.0
            resume_score = 1.0 if temporal.resumed and goal.goal_id == temporal.active_goal_id else 0.0
            continuity_score = _continuity_score(goal, graph, temporal)
            if mode == "proactive" and goal.goal_id == temporal.active_goal_id:
                continuity_score = round(continuity_score + continuity_bonus, 3)
                if note_bonus > 0:
                    continuity_score = round(continuity_score + note_bonus, 3)
            if execution_tracker and goal.goal_id in execution_tracker.in_flight_goal_ids:
                resume_score += 0.7
            tracker_score = 0.5 if execution_tracker and goal.goal_id in execution_tracker.retry_goal_ids else 0.0
            evidence_score = 0.2 * len(goal.evidence_refs) + 0.15 * len(goal.related_memory_ids)
            repair_score = _repair_score(goal, temporal)
            staleness_score = _staleness_score(goal, temporal, current)

            score = (
                priority_score
                + status_score
                + deadline_score
                + time_sensitivity_score
                + dependency_score
                + resume_score
                + continuity_score
                + tracker_score
                + evidence_score
                + repair_score
                + staleness_score
            )

            kind = _kind_for_goal(goal, temporal, execution_tracker)
            rationale, factors = _rationale_for(goal, temporal, kind, execution_tracker, now=current)
            if mode == "proactive" and goal.goal_id == temporal.active_goal_id and note_factors:
                factors = tuple((*factors, *note_factors))
            confidence = min(0.99, max(0.1, 0.2 + (priority_score / 5.0) + max(0.0, deadline_score)))
            if memories:
                confidence = min(0.99, confidence + min(0.1, 0.02 * len(memories)))

            candidates.append(
                CandidateMove(
                    move_id=f"move:{session.session_id}:{goal.goal_id}",
                    kind=kind,
                    goal_id=goal.goal_id,
                    title=goal.title,
                    score=round(score, 3),
                    priority_score=priority_score,
                    status_score=status_score,
                    deadline_score=deadline_score,
                    time_sensitivity_score=time_sensitivity_score,
                    dependency_score=dependency_score,
                    resume_score=resume_score,
                    continuity_score=continuity_score,
                    tracker_score=tracker_score,
                    evidence_score=evidence_score,
                    repair_score=repair_score,
                    rationale=rationale,
                    rationale_factors=factors,
                    dependency_refs=goal.dependency_refs,
                    evidence_refs=goal.evidence_refs,
                    confidence=round(confidence, 3),
                )
            )

        if not candidates:
            candidates.append(
                CandidateMove(
                    move_id=f"move:{session.session_id}:defer",
                    kind="defer_or_schedule",
                    goal_id=None,
                    title="Defer and schedule follow-up",
                    score=0.0,
                    priority_score=0.0,
                    status_score=0.0,
                    deadline_score=0.0,
                    time_sensitivity_score=0.0,
                    dependency_score=0.0,
                    resume_score=0.0,
                    continuity_score=0.0,
                    tracker_score=0.0,
                    evidence_score=0.0,
                    repair_score=0.0,
                    rationale="No actionable goals were available, so the planner should defer and schedule a follow-up.",
                    rationale_factors=(),
                    confidence=0.2,
                )
            )

        return tuple(sorted(candidates, key=lambda candidate: candidate.score, reverse=True))

    def choose_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        mode: PlanningMode = "guided",
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> PlanningDecision:
        current = _now() if now is None else now
        initiative = _normalize_initiative(initiative_hint)
        continuity_bonus = _INITIATIVE_CONTINUITY_BONUS.get(initiative, 0.0)
        candidates = self.score_candidates(
            session=session,
            graph=graph,
            memories=memories,
            execution_tracker=execution_tracker,
            initiative_hint=initiative,
            continuity_notes=continuity_notes,
            mode=mode,
            now=current,
        )
        selected = candidates[0]
        temporal = self._reasoner.analyze(session, graph, now=current)
        selected_goal = graph.goal(selected.goal_id) if selected.goal_id is not None else None
        progression_action = _progression_action_for(selected.kind)
        planned_status, planned_active_goal_id = _planned_progression(graph, selected_goal, selected.kind)
        factors: list[str] = [
            f"mode={mode}",
            f"selected={selected.kind}",
            f"priority={selected.priority_score:.1f}",
            f"status={selected.status_score:.1f}",
            f"candidate-count={len(candidates)}",
        ]
        factors.extend(selected.rationale_factors)
        if temporal.resumed:
            factors.append("resumed-session")
        if selected.resume_score > 0:
            factors.append("resume-weighted")
        if selected.continuity_score > 0:
            factors.append("continuity-weighted")
        if selected_goal is not None and _staleness_score(selected_goal, temporal, current) > 0:
            factors.append("stale-goal-pressure")
        if selected.repair_score > 0:
            factors.append("repair-weighted")
        if mode == "proactive":
            factors.append("wake-loop")
            if temporal.resumed:
                factors.append("proactive-resume")
            factors.append(f"initiative={initiative}")
            factors.extend(_continuity_note_factors(continuity_notes))
            if continuity_bonus != 0:
                factors.append("initiative-weighted")
            if _continuity_note_bonus(continuity_notes) > 0:
                factors.append("continuity-notes-weighted")
        if selected.deadline_score > 0:
            factors.append("deadline-pressure")
        if selected.time_sensitivity_score > 0:
            factors.append("time-sensitive")
        if selected.dependency_score < 0:
            factors.append("dependency-blocked")
        if selected.evidence_refs:
            factors.append("durable-evidence")
        if selected_goal is not None:
            factors.append(f"selected-goal-status={selected_goal.status}")
            factors.append(f"selected-goal-priority={selected_goal.priority}")
        if temporal.blocked_active_goal_id is not None:
            factors.append(f"blocked-active-goal={temporal.blocked_active_goal_id}")
        factors.append(f"progression={progression_action}")
        factors.append(f"planned-active-goal={planned_active_goal_id or '<none>'}")

        rationale = PlanningRationale(
            summary=f"{selected.rationale} {_progression_sentence(selected_goal, action=progression_action, planned_status=planned_status, planned_active_goal_id=planned_active_goal_id)}",
            factors=tuple(dict.fromkeys(factors)),
            candidate_ids=tuple(candidate.move_id for candidate in candidates),
            selected_move_id=selected.move_id,
            selected_goal_id=selected.goal_id,
            selected_goal_status=selected_goal.status if selected_goal is not None else None,
            selected_goal_priority=selected_goal.priority if selected_goal is not None else None,
            progression_action=progression_action,
            active_goal_id_before=graph.active_goal_id,
            planned_active_goal_id=planned_active_goal_id,
            mode=mode,
        )
        return PlanningDecision(
            decision_id=f"decision:{session.session_id}:{selected.goal_id or 'defer'}",
            session_id=session.session_id,
            mode=mode,
            selected_move=selected,
            rationale=rationale,
            candidates=candidates,
            temporal_context=temporal,
            goal_graph_revision=graph.updated_at,
        )

    def wake_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> tuple[PlanningDecision, GoalGraph]:
        decision = self.choose_next_step(
            session=session,
            graph=graph,
            memories=memories,
            execution_tracker=execution_tracker,
            mode="proactive",
            initiative_hint=initiative_hint,
            continuity_notes=continuity_notes,
            now=now,
        )
        return decision, apply_decision_to_goal_graph(graph, decision, updated_at=decision.selected_at)

    def emit_rationale(self, decision: PlanningDecision) -> EventEnvelope:
        payload = {
            "decision_id": decision.decision_id,
            "mode": decision.mode,
            "selected_move_id": decision.selected_move.move_id,
            "selected_goal_id": decision.selected_move.goal_id or "",
            "selected_kind": decision.selected_move.kind,
            "progression_action": decision.rationale.progression_action,
            "planned_active_goal_id": decision.rationale.planned_active_goal_id or "",
            "summary": decision.rationale.summary,
            "factors": _stringify(decision.rationale.factors),
            "candidate_ids": _stringify(decision.rationale.candidate_ids),
            "score": f"{decision.selected_move.score:.3f}",
            "resumed": str(decision.temporal_context.resumed),
        }
        return EventEnvelope(
            event_id=f"event:{decision.decision_id}:rationale",
            event_type="planning.rationale.emitted",
            session_id=decision.session_id,
            source="packages.planning",
            payload=payload,
        )


def build_plan_draft_from_decision(decision: PlanningDecision) -> PlanDraft | None:
    """Convert a planning decision into a thin plan draft."""

    selected_goal_id = decision.selected_move.goal_id
    if selected_goal_id is None:
        return None

    return PlanDraft(
        plan_id=f"plan:{decision.decision_id}",
        goal_id=selected_goal_id,
        session_id=decision.session_id,
        steps=(
            PlanStep(
                step_id=f"step:{decision.decision_id}:1",
                title=decision.selected_move.title,
                rationale=decision.rationale.summary,
                dependency_refs=decision.selected_move.dependency_refs,
            ),
        ),
        rationale=decision.rationale.summary,
    )


def apply_decision_to_goal_graph(
    graph: GoalGraph,
    decision: PlanningDecision,
    *,
    updated_at: datetime | None = None,
) -> GoalGraph:
    """Persist the planning choice back into the durable goal graph."""

    selected_goal_id = decision.selected_move.goal_id
    if selected_goal_id is None:
        return graph

    goal = graph.goal(selected_goal_id)
    if goal is None:
        return graph

    next_status, next_active_goal_id = _planned_progression(graph, goal, decision.selected_move.kind)
    if next_status is None:
        return graph

    timestamp = decision.selected_at if updated_at is None else updated_at
    return graph.transition_goal(
        selected_goal_id,
        status=next_status,
        revision_id=decision.decision_id,
        updated_at=timestamp,
        active_goal_id=next_active_goal_id,
    )


def build_goal_graph(
    *,
    session_id: str,
    goals: tuple[GoalGraphNode, ...],
    root_goal_id: str | None = None,
    active_goal_id: str | None = None,
    revision_id: str | None = None,
    updated_at: datetime | None = None,
) -> GoalGraph:
    return GoalGraph(
        session_id=session_id,
        nodes=goals,
        root_goal_id=root_goal_id,
        active_goal_id=active_goal_id,
        revision_id=revision_id,
        updated_at=_now() if updated_at is None else updated_at,
    )


def normalize_goal_nodes(goals: tuple[ContractGoalNode, ...]) -> tuple[GoalGraphNode, ...]:
    return tuple(GoalGraphNode.from_contract_goal(goal) for goal in goals)
