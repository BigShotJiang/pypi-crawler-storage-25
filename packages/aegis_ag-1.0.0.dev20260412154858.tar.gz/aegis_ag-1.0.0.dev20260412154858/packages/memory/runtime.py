"""Durable memory ledger, extraction, consolidation, retrieval, and governance."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta, timezone
from typing import Mapping, Protocol, runtime_checkable

from packages.contracts.runtime import EventEnvelope, MemoryRecord
from packages.storage import RuntimeStorageRepository, StoredMemoryLedgerEntry, StoredMemoryRecord


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _split_csv(value: str | None) -> tuple[str, ...]:
    if not value:
        return ()
    tokens = [item.strip() for item in value.replace("\n", ",").split(",")]
    return tuple(item for item in tokens if item)


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[A-Za-z0-9_]+", text.lower()) if token}


_CONTINUITY_QUERY_TOKENS = frozenset(
    {
        "continue",
        "continuity",
        "handoff",
        "left",
        "next",
        "pick",
        "resume",
        "resumed",
        "step",
        "where",
    }
)


def _unique(items: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(item for item in items if item))


def _continuity_intent_score(
    record: MemoryRecord,
    *,
    query_tokens: set[str],
) -> tuple[float, tuple[str, ...]]:
    if not (query_tokens & _CONTINUITY_QUERY_TOKENS):
        return 0.0, ()

    reasons: list[str] = []
    score = 0.0
    if record.kind in {"procedural", "semantic", "summary", "decision"}:
        score += 1.75
        reasons.append(f"continuity intent: {record.kind}")
    if record.goal_refs:
        score += 0.4
        reasons.append("goal-linked continuity")
    continuity_tags = {"continuity", "handoff", "recovery", "resume"}
    if continuity_tags & set(record.tags):
        score += 0.35
        reasons.append("continuity tag")
    return score, tuple(reasons)


def _to_stored_ledger_entry(entry: MemoryLedgerEntry) -> StoredMemoryLedgerEntry:
    return StoredMemoryLedgerEntry(
        entry_id=entry.entry_id,
        session_id=entry.session_id,
        event_id=entry.event_id,
        event_type=entry.event_type,
        content=entry.content,
        kind=entry.kind,
        source_event_id=entry.source_event_id,
        goal_refs=entry.goal_refs,
        tags=entry.tags,
        created_at=entry.created_at,
        metadata=dict(entry.metadata),
    )


def _from_stored_ledger_entry(entry: StoredMemoryLedgerEntry) -> MemoryLedgerEntry:
    return MemoryLedgerEntry(
        entry_id=entry.entry_id,
        session_id=entry.session_id,
        event_id=entry.event_id,
        event_type=entry.event_type,
        content=entry.content,
        kind=entry.kind,
        source_event_id=entry.source_event_id,
        goal_refs=entry.goal_refs,
        tags=entry.tags,
        created_at=entry.created_at or _now(),
        metadata=entry.metadata,
    )


def _to_stored_record(record: MemoryRecord) -> StoredMemoryRecord:
    return StoredMemoryRecord(
        memory_id=record.memory_id,
        session_id=record.session_id,
        kind=record.kind,
        content=record.content,
        source_event_id=record.source_event_id,
        goal_refs=record.goal_refs,
        tags=record.tags,
        created_at=record.created_at,
    )


def _from_stored_record(record: StoredMemoryRecord) -> MemoryRecord:
    return MemoryRecord(
        memory_id=record.memory_id,
        session_id=record.session_id,
        kind=record.kind,
        content=record.content,
        source_event_id=record.source_event_id,
        goal_refs=record.goal_refs,
        tags=record.tags,
        created_at=record.created_at,
    )


@dataclass(frozen=True, slots=True)
class MemoryLedgerEntry:
    entry_id: str
    session_id: str
    event_id: str
    event_type: str
    content: str
    kind: str
    source_event_id: str | None = None
    goal_refs: tuple[str, ...] = ()
    tags: tuple[str, ...] = ()
    created_at: datetime = field(default_factory=_now)
    metadata: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class MemoryAppendResult:
    ledger_entry: MemoryLedgerEntry
    extracted_records: tuple[MemoryRecord, ...]


@dataclass(frozen=True, slots=True)
class MemoryRetrievalCandidate:
    record: MemoryRecord
    score: float
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class MemoryRetrievalResult:
    session_id: str
    query: str
    goal_ids: tuple[str, ...]
    candidates: tuple[MemoryRetrievalCandidate, ...]


@dataclass(frozen=True, slots=True)
class MemoryConsolidationResult:
    session_id: str
    input_memory_ids: tuple[str, ...]
    summary_record: MemoryRecord | None
    superseded_memory_ids: tuple[str, ...] = ()
    rationale: str = ""


@dataclass(frozen=True, slots=True)
class MemoryMaintenanceResult:
    session_id: str
    maintained_memory_ids: tuple[str, ...]
    summary_record: MemoryRecord | None
    rationale: str


@dataclass(frozen=True, slots=True)
class MemoryGovernanceDecision:
    action: str
    target_memory_id: str | None
    allowed: bool
    reason: str
    actor: str = "user"
    replacement_memory_id: str | None = None


@dataclass(frozen=True, slots=True)
class MemoryGovernanceEvent:
    entry_id: str
    session_id: str
    action: str
    target_memory_id: str | None
    allowed: bool
    actor: str
    reason: str
    replacement_memory_id: str | None = None
    related_memory_ids: tuple[str, ...] = ()
    created_at: datetime = field(default_factory=_now)


@dataclass(frozen=True, slots=True)
class MemoryGovernancePolicy:
    allow_user_corrections: bool = True
    allow_user_deletions: bool = True
    protected_tags: tuple[str, ...] = ("pinned", "system", "locked")
    minimum_content_length: int = 1
    semantic_kinds: tuple[str, ...] = ("semantic", "procedural", "artifact")


@runtime_checkable
class MemoryLedger(Protocol):
    def append(self, entry: MemoryLedgerEntry) -> None:
        """Append a ledger entry."""

    def list(self, session_id: str | None = None) -> tuple[MemoryLedgerEntry, ...]:
        """List entries, optionally filtered by session."""


@runtime_checkable
class MemoryStore(Protocol):
    def upsert(self, record: MemoryRecord) -> None:
        """Persist a memory record."""

    def get(self, memory_id: str) -> MemoryRecord | None:
        """Return a memory record by id."""

    def list(self, session_id: str | None = None, *, include_inactive: bool = False) -> tuple[MemoryRecord, ...]:
        """List memory records, optionally filtered by session."""

    def mark_consolidated(self, source_ids: tuple[str, ...], summary_id: str) -> None:
        """Mark source records as consolidated into a summary."""

    def mark_superseded(self, source_id: str, replacement_id: str) -> None:
        """Mark a record as superseded by a correction."""

    def mark_deleted(self, memory_id: str) -> None:
        """Mark a record as deleted."""

    def state(self, memory_id: str) -> str | None:
        """Return the current lifecycle state for a record."""

    def lineage(self, memory_id: str) -> str | None:
        """Return the current lineage target for a record, if any."""


@runtime_checkable
class MemoryExtractor(Protocol):
    def extract(self, event: EventEnvelope) -> MemoryAppendResult:
        """Turn a raw event into durable ledger and memory records."""


@runtime_checkable
class MemoryConsolidator(Protocol):
    def consolidate(self, session_id: str, records: tuple[MemoryRecord, ...]) -> MemoryConsolidationResult:
        """Derive a smaller summary memory from raw records."""


@runtime_checkable
class MemoryRetriever(Protocol):
    def retrieve(
        self,
        session_id: str,
        query: str,
        *,
        goal_ids: tuple[str, ...] = (),
        limit: int = 5,
    ) -> MemoryRetrievalResult:
        """Rank memories for a session and query."""


@runtime_checkable
class MemoryGovernance(Protocol):
    def can_record(self, record: MemoryRecord) -> MemoryGovernanceDecision:
        """Check whether a memory record can be stored."""

    def can_consolidate(self, records: tuple[MemoryRecord, ...]) -> MemoryGovernanceDecision:
        """Check whether a consolidation is allowed."""

    def can_correct(
        self,
        original: MemoryRecord,
        corrected_content: str,
        *,
        actor: str,
    ) -> MemoryGovernanceDecision:
        """Check whether a correction is allowed."""

    def can_delete(
        self,
        original: MemoryRecord,
        *,
        actor: str,
        reason: str,
    ) -> MemoryGovernanceDecision:
        """Check whether deletion is allowed."""


class InMemoryMemoryLedger:
    def __init__(self) -> None:
        self._entries: list[MemoryLedgerEntry] = []

    def append(self, entry: MemoryLedgerEntry) -> None:
        self._entries.append(entry)

    def list(self, session_id: str | None = None) -> tuple[MemoryLedgerEntry, ...]:
        entries = self._entries
        if session_id is not None:
            entries = [entry for entry in entries if entry.session_id == session_id]
        return tuple(entries)


class InMemoryMemoryStore:
    def __init__(self) -> None:
        self._records: dict[str, MemoryRecord] = {}
        self._states: dict[str, str] = {}
        self._lineage: dict[str, str] = {}

    def upsert(self, record: MemoryRecord) -> None:
        self._records[record.memory_id] = record
        self._states.setdefault(record.memory_id, "active")

    def get(self, memory_id: str) -> MemoryRecord | None:
        return self._records.get(memory_id)

    def list(self, session_id: str | None = None, *, include_inactive: bool = False) -> tuple[MemoryRecord, ...]:
        records = tuple(self._records.values())
        if session_id is not None:
            records = tuple(record for record in records if record.session_id == session_id)
        if include_inactive:
            return records
        return tuple(record for record in records if self._states.get(record.memory_id, "active") == "active")

    def mark_consolidated(self, source_ids: tuple[str, ...], summary_id: str) -> None:
        for source_id in source_ids:
            self._states[source_id] = "consolidated"
            self._lineage[source_id] = summary_id

    def mark_superseded(self, source_id: str, replacement_id: str) -> None:
        self._states[source_id] = "superseded"
        self._lineage[source_id] = replacement_id

    def mark_deleted(self, memory_id: str) -> None:
        self._states[memory_id] = "deleted"

    def state(self, memory_id: str) -> str | None:
        return self._states.get(memory_id)

    def lineage(self, memory_id: str) -> str | None:
        return self._lineage.get(memory_id)


class SQLiteMemoryLedger:
    def __init__(self, repository: RuntimeStorageRepository) -> None:
        self.repository = repository

    def append(self, entry: MemoryLedgerEntry) -> None:
        self.repository.append_memory_ledger(_to_stored_ledger_entry(entry))

    def list(self, session_id: str | None = None) -> tuple[MemoryLedgerEntry, ...]:
        return tuple(
            _from_stored_ledger_entry(entry) for entry in self.repository.list_memory_ledger(session_id=session_id)
        )


class SQLiteMemoryStore:
    def __init__(self, repository: RuntimeStorageRepository) -> None:
        self.repository = repository

    def upsert(self, record: MemoryRecord) -> None:
        self.repository.upsert_memory_record(_to_stored_record(record))

    def get(self, memory_id: str) -> MemoryRecord | None:
        record = self.repository.load_memory_record(memory_id)
        return _from_stored_record(record) if record is not None else None

    def list(self, session_id: str | None = None, *, include_inactive: bool = False) -> tuple[MemoryRecord, ...]:
        return tuple(
            _from_stored_record(record)
            for record in self.repository.list_memory_records(session_id=session_id, include_inactive=include_inactive)
        )

    def mark_consolidated(self, source_ids: tuple[str, ...], summary_id: str) -> None:
        self.repository.mark_memory_consolidated(source_ids, summary_id)

    def mark_superseded(self, source_id: str, replacement_id: str) -> None:
        self.repository.mark_memory_superseded(source_id, replacement_id)

    def mark_deleted(self, memory_id: str) -> None:
        self.repository.mark_memory_deleted(memory_id)

    def state(self, memory_id: str) -> str | None:
        return self.repository.memory_state(memory_id)

    def lineage(self, memory_id: str) -> str | None:
        return self.repository.memory_lineage(memory_id)


class DefaultMemoryExtractor:
    def __init__(self, *, default_kind: str = "episodic") -> None:
        self.default_kind = default_kind

    def _kind_for_event(self, event: EventEnvelope, payload: Mapping[str, str]) -> str:
        explicit = payload.get("memory_kind") or payload.get("kind")
        if explicit:
            return explicit
        if event.event_type in {"goal_update", "goal_snapshot"}:
            return "semantic"
        if event.event_type in {"procedure", "preference", "skill"}:
            return "procedural"
        if event.event_type in {"artifact", "file", "link"}:
            return "artifact"
        return self.default_kind

    def extract(self, event: EventEnvelope) -> MemoryAppendResult:
        payload = event.payload
        content = payload.get("content") or payload.get("summary") or payload.get("text") or ""
        if not content.strip():
            content = payload.get("note", "")

        goal_refs = _unique(
            _split_csv(payload.get("goal_refs"))
            + _split_csv(payload.get("goal_ref"))
            + _split_csv(payload.get("goal_ids"))
            + _split_csv(payload.get("goal_id"))
        )
        tags = _unique(_split_csv(payload.get("tags")) + _split_csv(payload.get("tag")))
        kind = self._kind_for_event(event, payload)
        ledger_entry = MemoryLedgerEntry(
            entry_id=payload.get("ledger_entry_id", f"{event.event_id}:ledger"),
            session_id=event.session_id,
            event_id=event.event_id,
            event_type=event.event_type,
            content=content,
            kind=kind,
            source_event_id=payload.get("source_event_id", event.event_id),
            goal_refs=goal_refs,
            tags=tags,
            metadata={key: value for key, value in payload.items() if key not in {"content", "summary", "text"}},
        )
        if not content.strip():
            return MemoryAppendResult(ledger_entry=ledger_entry, extracted_records=())

        record = MemoryRecord(
            memory_id=payload.get("memory_id", f"{event.event_id}:memory"),
            session_id=event.session_id,
            kind=kind,
            content=content,
            source_event_id=ledger_entry.source_event_id,
            goal_refs=goal_refs,
            tags=tags,
            created_at=ledger_entry.created_at,
        )
        return MemoryAppendResult(ledger_entry=ledger_entry, extracted_records=(record,))


class DefaultMemoryConsolidator:
    def consolidate(self, session_id: str, records: tuple[MemoryRecord, ...]) -> MemoryConsolidationResult:
        if not records:
            return MemoryConsolidationResult(
                session_id=session_id,
                input_memory_ids=(),
                summary_record=None,
                rationale="no records available for consolidation",
            )

        ordered = sorted(
            records,
            key=lambda record: (
                record.created_at or datetime.min.replace(tzinfo=timezone.utc),
                record.memory_id,
            ),
        )
        if len(ordered) == 1:
            return MemoryConsolidationResult(
                session_id=session_id,
                input_memory_ids=(ordered[0].memory_id,),
                summary_record=None,
                rationale="single record does not require consolidation",
            )

        content_fragments = []
        for record in ordered:
            fragment = record.content.strip().splitlines()[0]
            if fragment not in content_fragments:
                content_fragments.append(fragment)
        content = "; ".join(content_fragments[:3])
        goal_refs = _unique(tuple(ref for record in ordered for ref in record.goal_refs))
        tags = _unique(("consolidated",) + tuple(tag for record in ordered for tag in record.tags))
        kind = "semantic" if any(record.kind != "artifact" for record in ordered) else "artifact"
        digest_source = "|".join(record.memory_id for record in ordered)
        summary_id = "memory.summary." + hashlib.sha256(digest_source.encode("utf-8")).hexdigest()[:12]
        summary = MemoryRecord(
            memory_id=summary_id,
            session_id=session_id,
            kind=kind,
            content=f"Consolidated memory: {content}",
            source_event_id=ordered[-1].source_event_id,
            goal_refs=goal_refs,
            tags=tags,
            created_at=_now(),
        )
        return MemoryConsolidationResult(
            session_id=session_id,
            input_memory_ids=tuple(record.memory_id for record in ordered),
            summary_record=summary,
            superseded_memory_ids=tuple(record.memory_id for record in ordered),
            rationale="consolidated related memories into one durable summary",
        )


class DefaultMemoryRetriever:
    def __init__(self, store: MemoryStore) -> None:
        self.store = store

    def _score(
        self,
        record: MemoryRecord,
        *,
        query_tokens: set[str],
        goal_ids: tuple[str, ...],
    ) -> tuple[float, tuple[str, ...]]:
        reasons: list[str] = []
        score = 0.0
        content_tokens = _tokenize(record.content)
        overlap = sorted(query_tokens & content_tokens)
        if overlap:
            score += float(len(overlap)) * 2.0
            reasons.append(f"query overlap: {','.join(overlap)}")
        tag_tokens = _tokenize(" ".join(record.tags))
        tag_overlap = sorted(query_tokens & tag_tokens)
        if tag_overlap:
            score += float(len(tag_overlap)) * 1.25
            reasons.append(f"tag overlap: {','.join(tag_overlap)}")
        goal_overlap = tuple(goal_id for goal_id in goal_ids if goal_id in record.goal_refs)
        if goal_overlap:
            score += float(len(goal_overlap)) * 3.0
            reasons.append(f"goal overlap: {','.join(goal_overlap)}")
        continuity_score, continuity_reasons = _continuity_intent_score(record, query_tokens=query_tokens)
        if continuity_score > 0:
            score += continuity_score
            reasons.extend(continuity_reasons)
        if record.kind in {"semantic", "procedural"}:
            score += 1.0
            reasons.append(f"durable kind: {record.kind}")
        elif record.kind == "artifact":
            score += 0.5
            reasons.append("artifact support")
        if "corrected" in record.tags:
            score += 1.5
            reasons.append("corrected memory")
        if record.created_at is not None:
            age_seconds = max(0.0, (_now() - record.created_at).total_seconds())
            score += max(0.0, 2.0 - (age_seconds / 86400.0))
            reasons.append("recency boost")
        return score, tuple(reasons)

    def retrieve(
        self,
        session_id: str,
        query: str,
        *,
        goal_ids: tuple[str, ...] = (),
        limit: int = 5,
    ) -> MemoryRetrievalResult:
        query_tokens = _tokenize(query)
        candidates = []
        for record in self.store.list(session_id=session_id):
            score, reasons = self._score(record, query_tokens=query_tokens, goal_ids=goal_ids)
            candidates.append(MemoryRetrievalCandidate(record=record, score=score, reasons=reasons))
        candidates.sort(
            key=lambda item: (
                -item.score,
                -(item.record.created_at.timestamp() if item.record.created_at else 0.0),
                item.record.memory_id,
            )
        )
        return MemoryRetrievalResult(
            session_id=session_id,
            query=query,
            goal_ids=goal_ids,
            candidates=tuple(candidates[:limit]),
        )


class DefaultMemoryGovernance:
    def __init__(self, policy: MemoryGovernancePolicy | None = None) -> None:
        self.policy = policy or MemoryGovernancePolicy()

    def _is_protected(self, record: MemoryRecord) -> bool:
        return any(tag in self.policy.protected_tags for tag in record.tags)

    def can_record(self, record: MemoryRecord) -> MemoryGovernanceDecision:
        if not record.content.strip():
            return MemoryGovernanceDecision("record", record.memory_id, False, "memory content is empty")
        return MemoryGovernanceDecision("record", record.memory_id, True, "memory can be stored")

    def can_consolidate(self, records: tuple[MemoryRecord, ...]) -> MemoryGovernanceDecision:
        if not records:
            return MemoryGovernanceDecision("consolidate", None, False, "no records supplied for consolidation")
        return MemoryGovernanceDecision("consolidate", ",".join(record.memory_id for record in records), True, "consolidation is allowed")

    def can_correct(
        self,
        original: MemoryRecord,
        corrected_content: str,
        *,
        actor: str,
    ) -> MemoryGovernanceDecision:
        if len(corrected_content.strip()) < self.policy.minimum_content_length:
            return MemoryGovernanceDecision("correct", original.memory_id, False, "corrected content is empty", actor=actor)
        if self._is_protected(original) and actor != "system":
            return MemoryGovernanceDecision("correct", original.memory_id, False, "protected memory requires system actor", actor=actor)
        if actor == "user" and not self.policy.allow_user_corrections:
            return MemoryGovernanceDecision("correct", original.memory_id, False, "user corrections are disabled", actor=actor)
        return MemoryGovernanceDecision("correct", original.memory_id, True, "correction is allowed", actor=actor)

    def can_delete(
        self,
        original: MemoryRecord,
        *,
        actor: str,
        reason: str,
    ) -> MemoryGovernanceDecision:
        if self._is_protected(original) and actor != "system":
            return MemoryGovernanceDecision("delete", original.memory_id, False, "protected memory cannot be deleted by this actor", actor=actor)
        if actor == "user" and not self.policy.allow_user_deletions:
            return MemoryGovernanceDecision("delete", original.memory_id, False, "user deletions are disabled", actor=actor)
        if not reason.strip():
            return MemoryGovernanceDecision("delete", original.memory_id, False, "deletion reason is required", actor=actor)
        return MemoryGovernanceDecision("delete", original.memory_id, True, "deletion is allowed", actor=actor)


@dataclass(frozen=True, slots=True)
class MemoryMutationResult:
    decision: MemoryGovernanceDecision
    record: MemoryRecord | None = None


class MemoryRuntime:
    def __init__(
        self,
        *,
        ledger: MemoryLedger | None = None,
        store: MemoryStore | None = None,
        extractor: MemoryExtractor | None = None,
        consolidator: MemoryConsolidator | None = None,
        retriever: MemoryRetriever | None = None,
        governance: MemoryGovernance | None = None,
    ) -> None:
        self.ledger = ledger or InMemoryMemoryLedger()
        self.store = store or InMemoryMemoryStore()
        self.extractor = extractor or DefaultMemoryExtractor()
        self.consolidator = consolidator or DefaultMemoryConsolidator()
        self.retriever = retriever or DefaultMemoryRetriever(self.store)
        self.governance = governance or DefaultMemoryGovernance()

    def _governance_event_entry(
        self,
        session_id: str,
        decision: MemoryGovernanceDecision,
        *,
        target_memory_id: str | None,
        related_memory_ids: tuple[str, ...] = (),
    ) -> MemoryLedgerEntry:
        created_at = _now()
        digest_source = "|".join(
            (
                session_id,
                decision.action,
                target_memory_id or "",
                decision.actor,
                decision.reason,
                decision.replacement_memory_id or "",
                ",".join(related_memory_ids),
                created_at.isoformat(),
            )
        )
        entry_id = "memory.governance." + hashlib.sha256(digest_source.encode("utf-8")).hexdigest()[:16]
        state_tag = "allowed" if decision.allowed else "denied"
        content = f"{decision.action}:{state_tag}:{target_memory_id or 'session'}:{decision.reason}"
        metadata = {
            "action": decision.action,
            "target_memory_id": target_memory_id or "",
            "allowed": "true" if decision.allowed else "false",
            "actor": decision.actor,
            "reason": decision.reason,
            "replacement_memory_id": decision.replacement_memory_id or "",
            "related_memory_ids": ",".join(related_memory_ids),
        }
        return MemoryLedgerEntry(
            entry_id=entry_id,
            session_id=session_id,
            event_id=entry_id,
            event_type="memory_governance",
            content=content,
            kind="governance",
            source_event_id=target_memory_id,
            goal_refs=(),
            tags=("governance", decision.action, state_tag),
            created_at=created_at,
            metadata=metadata,
        )

    def _record_governance_event(
        self,
        session_id: str,
        decision: MemoryGovernanceDecision,
        *,
        target_memory_id: str | None,
        related_memory_ids: tuple[str, ...] = (),
    ) -> None:
        self.ledger.append(
            self._governance_event_entry(
                session_id,
                decision,
                target_memory_id=target_memory_id,
                related_memory_ids=related_memory_ids,
            )
        )

    @classmethod
    def from_repository(
        cls,
        repository: RuntimeStorageRepository,
        *,
        extractor: MemoryExtractor | None = None,
        consolidator: MemoryConsolidator | None = None,
        retriever: MemoryRetriever | None = None,
        governance: MemoryGovernance | None = None,
    ) -> "MemoryRuntime":
        store = SQLiteMemoryStore(repository)
        ledger = SQLiteMemoryLedger(repository)
        return cls(
            ledger=ledger,
            store=store,
            extractor=extractor,
            consolidator=consolidator,
            retriever=retriever,
            governance=governance,
        )

    def append_event(self, event: EventEnvelope) -> MemoryAppendResult:
        result = self.extractor.extract(event)
        self.ledger.append(result.ledger_entry)
        for record in result.extracted_records:
            decision = self.governance.can_record(record)
            if decision.allowed:
                self.store.upsert(record)
        return result

    def consolidate_session(self, session_id: str, memory_ids: tuple[str, ...] = ()) -> MemoryConsolidationResult:
        if memory_ids:
            records = tuple(
                record
                for memory_id in memory_ids
                if (record := self.store.get(memory_id)) is not None
            )
        else:
            records = self.store.list(session_id=session_id)
        decision = self.governance.can_consolidate(records)
        if not decision.allowed:
            self._record_governance_event(
                session_id,
                decision,
                target_memory_id=None,
                related_memory_ids=tuple(record.memory_id for record in records),
            )
            return MemoryConsolidationResult(
                session_id=session_id,
                input_memory_ids=tuple(record.memory_id for record in records),
                summary_record=None,
                rationale=decision.reason,
            )
        result = self.consolidator.consolidate(session_id, records)
        if result.summary_record is not None:
            self.store.upsert(result.summary_record)
            self.store.mark_consolidated(tuple(result.input_memory_ids), result.summary_record.memory_id)
            self._record_governance_event(
                session_id,
                MemoryGovernanceDecision(
                    "consolidate",
                    result.summary_record.memory_id,
                    True,
                    result.rationale or decision.reason,
                    actor=decision.actor,
                    replacement_memory_id=result.summary_record.memory_id,
                ),
                target_memory_id=result.summary_record.memory_id,
                related_memory_ids=tuple(result.input_memory_ids),
            )
        return result

    def retrieve(
        self,
        session_id: str,
        query: str,
        *,
        goal_ids: tuple[str, ...] = (),
        limit: int = 5,
    ) -> MemoryRetrievalResult:
        return self.retriever.retrieve(session_id, query, goal_ids=goal_ids, limit=limit)

    def maintain_session(
        self,
        session_id: str,
        *,
        now: datetime | None = None,
        maximum_ephemeral_age: timedelta = timedelta(hours=6),
    ) -> MemoryMaintenanceResult:
        current = now or _now()
        eligible = tuple(
            record
            for record in self.store.list(session_id=session_id)
            if self._eligible_for_maintenance(record, now=current, maximum_ephemeral_age=maximum_ephemeral_age)
        )
        if len(eligible) < 2:
            return MemoryMaintenanceResult(
                session_id=session_id,
                maintained_memory_ids=tuple(record.memory_id for record in eligible),
                summary_record=None,
                rationale="no aged episodic memories required maintenance",
            )

        result = self.consolidator.consolidate(session_id, eligible)
        if result.summary_record is None:
            return MemoryMaintenanceResult(
                session_id=session_id,
                maintained_memory_ids=tuple(record.memory_id for record in eligible),
                summary_record=None,
                rationale=result.rationale or "maintenance consolidation produced no summary",
            )

        summary = replace(
            result.summary_record,
            tags=_unique(result.summary_record.tags + ("maintenance", "aged")),
        )
        self.store.upsert(summary)
        self.store.mark_consolidated(tuple(result.input_memory_ids), summary.memory_id)
        self._record_governance_event(
            session_id,
            MemoryGovernanceDecision(
                "consolidate",
                summary.memory_id,
                True,
                "aged episodic memories consolidated into a maintained summary",
                actor="system",
                replacement_memory_id=summary.memory_id,
            ),
            target_memory_id=summary.memory_id,
            related_memory_ids=tuple(result.input_memory_ids),
        )
        return MemoryMaintenanceResult(
            session_id=session_id,
            maintained_memory_ids=tuple(result.input_memory_ids),
            summary_record=summary,
            rationale="aged episodic memories were consolidated into a maintained summary",
        )

    def list_governance_events(
        self,
        session_id: str,
        *,
        target_memory_id: str | None = None,
    ) -> tuple[MemoryGovernanceEvent, ...]:
        events: list[MemoryGovernanceEvent] = []
        for entry in self.ledger.list(session_id=session_id):
            if entry.event_type != "memory_governance":
                continue
            action = str(entry.metadata.get("action", ""))
            if not action:
                continue
            event_target = str(entry.metadata.get("target_memory_id", "")) or entry.source_event_id
            if target_memory_id is not None and event_target != target_memory_id:
                related_ids = _split_csv(str(entry.metadata.get("related_memory_ids", "")))
                if target_memory_id not in related_ids:
                    continue
            events.append(
                MemoryGovernanceEvent(
                    entry_id=entry.entry_id,
                    session_id=entry.session_id,
                    action=action,
                    target_memory_id=event_target,
                    allowed=str(entry.metadata.get("allowed", "false")).lower() == "true",
                    actor=str(entry.metadata.get("actor", "user")),
                    reason=str(entry.metadata.get("reason", entry.content)),
                    replacement_memory_id=str(entry.metadata.get("replacement_memory_id", "")) or None,
                    related_memory_ids=_split_csv(str(entry.metadata.get("related_memory_ids", ""))),
                    created_at=entry.created_at,
                )
            )
        return tuple(events)

    def correct_memory(
        self,
        target_memory_id: str,
        corrected_content: str,
        *,
        actor: str = "user",
        reason: str = "",
    ) -> MemoryMutationResult:
        original = self.store.get(target_memory_id)
        if original is None:
            decision = MemoryGovernanceDecision("correct", target_memory_id, False, "target memory not found", actor=actor)
            return MemoryMutationResult(decision=decision)
        decision = self.governance.can_correct(original, corrected_content, actor=actor)
        if not decision.allowed:
            self._record_governance_event(
                original.session_id,
                decision,
                target_memory_id=target_memory_id,
            )
            return MemoryMutationResult(decision=decision)
        protected_tags: tuple[str, ...] = ()
        policy = getattr(self.governance, "policy", None)
        if policy is not None:
            protected_tags = tuple(getattr(policy, "protected_tags", ()))
        preserved_tags = tuple(tag for tag in original.tags if tag not in protected_tags)
        reason_tag = (f"reason:{reason}",) if reason else ()
        corrected = MemoryRecord(
            memory_id=f"{target_memory_id}:corrected",
            session_id=original.session_id,
            kind=original.kind,
            content=corrected_content,
            source_event_id=original.source_event_id,
            goal_refs=original.goal_refs,
            tags=_unique(preserved_tags + ("corrected",) + reason_tag),
            created_at=_now(),
        )
        self.store.upsert(corrected)
        self.store.mark_superseded(target_memory_id, corrected.memory_id)
        applied_decision = MemoryGovernanceDecision(
            "correct",
            target_memory_id,
            True,
            "memory corrected",
            actor=actor,
            replacement_memory_id=corrected.memory_id,
        )
        self._record_governance_event(
            original.session_id,
            applied_decision,
            target_memory_id=target_memory_id,
            related_memory_ids=(corrected.memory_id,),
        )
        return MemoryMutationResult(
            decision=applied_decision,
            record=corrected,
        )

    def delete_memory(
        self,
        target_memory_id: str,
        *,
        actor: str = "user",
        reason: str,
    ) -> MemoryMutationResult:
        original = self.store.get(target_memory_id)
        if original is None:
            decision = MemoryGovernanceDecision("delete", target_memory_id, False, "target memory not found", actor=actor)
            return MemoryMutationResult(decision=decision)
        decision = self.governance.can_delete(original, actor=actor, reason=reason)
        if not decision.allowed:
            self._record_governance_event(
                original.session_id,
                decision,
                target_memory_id=target_memory_id,
            )
            return MemoryMutationResult(decision=decision)
        self.store.mark_deleted(target_memory_id)
        self._record_governance_event(
            original.session_id,
            decision,
            target_memory_id=target_memory_id,
        )
        return MemoryMutationResult(decision=decision)

    def _eligible_for_maintenance(
        self,
        record: MemoryRecord,
        *,
        now: datetime,
        maximum_ephemeral_age: timedelta,
    ) -> bool:
        if record.kind != "episodic":
            return False
        if record.created_at is None:
            return False
        age = now - record.created_at
        if age < maximum_ephemeral_age:
            return False
        if not record.goal_refs:
            return False
        if any(tag in {"pinned", "locked", "system"} for tag in record.tags):
            return False
        return True
