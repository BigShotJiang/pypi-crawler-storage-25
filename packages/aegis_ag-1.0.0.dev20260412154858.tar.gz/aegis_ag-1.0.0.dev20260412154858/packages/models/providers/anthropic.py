"""Anthropic Messages provider adapter.

This module keeps Anthropic-specific request, response, and capability logic
isolated from the generic OpenAI-compatible path. The adapter speaks the native
Messages API shape and the capability bridge converts it into the shared model
provider runtime contract.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping

from packages.capabilities.runtime import CapabilityDescriptor, ModelProviderCapability
from packages.contracts.runtime import ContextBundle, ExecutionResult, ProfileState, SessionState
from packages.models.provider_runtime import ProviderRuntimeResolution
from packages.models.runtime import (
    CredentialSource,
    ModelAdapter,
    ModelAdapterDescriptor,
    ModelEmbeddingResult,
    ModelRequest,
    ModelTextResult,
    ModelUsage,
)
from .identity_contract import build_provider_identity_contract
from .http import JSONHTTPTransport, UrllibJSONHTTPTransport


ANTHROPIC_API_VERSION = "2023-06-01"
ANTHROPIC_ENDPOINT_PATH = "/v1/messages"
ANTHROPIC_REQUEST_FAMILY = "messages"


@dataclass(frozen=True, slots=True)
class AnthropicContentBlock:
    type: str
    text: str
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        return {
            "type": self.type,
            "text": self.text,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class AnthropicMessageTurn:
    role: str
    content: tuple[AnthropicContentBlock, ...]
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        return {
            "role": self.role,
            "content": [block.as_mapping() for block in self.content],
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class AnthropicMessagesRequest:
    request_id: str
    provider_id: str
    transport_id: str
    request_family: str
    model_id: str
    base_url: str | None
    endpoint_path: str
    headers: Mapping[str, str]
    system: str
    messages: tuple[AnthropicMessageTurn, ...]
    max_tokens: int
    temperature: float | None = None
    stop_sequences: tuple[str, ...] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)

    def as_mapping(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "model": self.model_id,
            "max_tokens": self.max_tokens,
            "messages": [turn.as_mapping() for turn in self.messages],
            "metadata": dict(self.metadata),
        }
        if self.system:
            payload["system"] = self.system
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.stop_sequences:
            payload["stop_sequences"] = self.stop_sequences
        return payload


@dataclass(frozen=True, slots=True)
class AnthropicMessagesResponse:
    response_id: str
    request_id: str
    provider_id: str
    transport_id: str
    model_id: str
    stop_reason: str | None
    content: tuple[AnthropicContentBlock, ...]
    usage: ModelUsage = field(default_factory=ModelUsage)
    metadata: Mapping[str, str] = field(default_factory=dict)

    def text(self) -> str:
        return "".join(block.text for block in self.content)

    def as_mapping(self) -> dict[str, object]:
        return {
            "id": self.response_id,
            "type": "message",
            "role": "assistant",
            "content": [block.as_mapping() for block in self.content],
            "model": self.model_id,
            "stop_reason": self.stop_reason,
            "usage": {
                "input_tokens": self.usage.prompt_tokens,
                "output_tokens": self.usage.completion_tokens,
                "total_tokens": self.usage.total_tokens,
            },
            "metadata": dict(self.metadata),
        }


class AnthropicMessagesModelAdapter(ModelAdapter):
    """Native Anthropic Messages adapter."""

    def __init__(
        self,
        *,
        adapter_id: str,
        resolution: ProviderRuntimeResolution,
        credential_source: CredentialSource | None = None,
        http_transport: JSONHTTPTransport | None = None,
        max_tokens: int = 1024,
        temperature: float | None = None,
        anthropic_version: str = ANTHROPIC_API_VERSION,
    ) -> None:
        self.resolution = resolution
        self.credential_source = credential_source
        self.http_transport = http_transport or UrllibJSONHTTPTransport()
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.anthropic_version = anthropic_version
        self.descriptor = ModelAdapterDescriptor(
            adapter_id=adapter_id,
            provider_id=resolution.provider_id,
            model_id=resolution.model_id,
            kind="messages",
            supported_tasks=("generate", "summarize"),
            metadata={
                "provider_id": resolution.provider_id,
                "transport_id": resolution.transport_id,
                "request_family": resolution.request_family,
                "endpoint_path": resolution.endpoint_path,
                "native_api": "anthropic_messages",
            },
        )

    def _credential_keys(self, credentials: Mapping[str, str]) -> str:
        if not credentials:
            return "no-credentials"
        return ",".join(sorted(credentials))

    def _resolve_credentials(self, credentials: Mapping[str, str] | None = None) -> Mapping[str, str]:
        if credentials is not None:
            return credentials
        if self.credential_source is None:
            return {}
        return self.credential_source.resolve(self.resolution.provider_id)

    def build_request(
        self,
        request: ModelRequest,
        credentials: Mapping[str, str] | None = None,
    ) -> AnthropicMessagesRequest:
        resolved_credentials = self._resolve_credentials(credentials)
        credential_keys = self._credential_keys(resolved_credentials)
        system = self._compose_system_prompt(request, credential_keys)
        body_text = self._compose_user_text(request)
        headers = {
            "content-type": "application/json",
            "x-api-key": resolved_credentials.get("api_key", ""),
            "anthropic-version": self.anthropic_version,
        }
        if beta := request.metadata.get("anthropic_beta"):
            headers["anthropic-beta"] = beta
        return AnthropicMessagesRequest(
            request_id=request.request_id,
            provider_id=self.resolution.provider_id,
            transport_id=self.resolution.transport_id,
            request_family=self.resolution.request_family,
            model_id=self.resolution.model_id,
            base_url=self.resolution.base_url,
            endpoint_path=self.resolution.endpoint_path or ANTHROPIC_ENDPOINT_PATH,
            headers=headers,
            system=system,
            messages=(
                AnthropicMessageTurn(
                    role="user",
                    content=(AnthropicContentBlock(type="text", text=body_text),),
                    metadata={
                        "task": request.task,
                    },
                ),
            ),
            max_tokens=self._max_tokens_for(request),
            temperature=self.temperature,
            metadata={
                "bundle_id": request.context.get("bundle_id", ""),
                "profile_id": request.profile_id,
                "session_id": request.session_id,
                "task": request.task,
                "provider_id": self.resolution.provider_id,
                "transport_id": self.resolution.transport_id,
                "credential_keys": credential_keys,
            },
        )

    def parse_response(
        self,
        payload: Mapping[str, Any],
        request: AnthropicMessagesRequest,
    ) -> AnthropicMessagesResponse:
        blocks = tuple(
            AnthropicContentBlock(
                type=str(block.get("type", "text")),
                text=str(block.get("text", "")),
                metadata={
                    key: str(value)
                    for key, value in block.items()
                    if key not in {"type", "text"}
                },
            )
            for block in payload.get("content", [])
        )
        usage_payload = payload.get("usage", {})
        usage = ModelUsage(
            prompt_tokens=int(usage_payload.get("input_tokens", 0)),
            completion_tokens=int(usage_payload.get("output_tokens", 0)),
            total_tokens=int(usage_payload.get("input_tokens", 0)) + int(usage_payload.get("output_tokens", 0)),
        )
        return AnthropicMessagesResponse(
            response_id=str(payload.get("id", f"{request.request_id}:anthropic")),
            request_id=request.request_id,
            provider_id=request.provider_id,
            transport_id=request.transport_id,
            model_id=str(payload.get("model", request.model_id)),
            stop_reason=payload.get("stop_reason"),
            content=blocks,
            usage=usage,
            metadata={
                "request_family": request.request_family,
                "endpoint_path": request.endpoint_path,
                "anthropic_version": self.anthropic_version,
            },
        )

    def generate(self, request: ModelRequest, credentials: Mapping[str, str]) -> ModelTextResult:
        native_request = self.build_request(request, credentials)
        if native_request.base_url is None:
            raise RuntimeError("anthropic provider execution requires a base_url")
        response_payload = self.http_transport.post_json(
            url=self._compose_url(native_request.base_url, native_request.endpoint_path),
            headers=native_request.headers,
            payload=native_request.as_mapping(),
        )
        response = self.parse_response(response_payload.payload, native_request)
        return ModelTextResult(
            result_id=response.response_id,
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=self.resolution.provider_id,
            model_id=self.resolution.model_id,
            task=request.task,
            content=response.text(),
            usage=response.usage,
            metadata={
                "request_family": native_request.request_family,
                "transport_id": native_request.transport_id,
                "endpoint_path": native_request.endpoint_path,
                "stop_reason": response.stop_reason or "unknown",
                "credential_keys": native_request.metadata.get("credential_keys", "unknown"),
                "anthropic_version": self.anthropic_version,
                "status_code": str(response_payload.status_code),
            },
        )

    def summarize(self, request: ModelRequest, credentials: Mapping[str, str]) -> ModelTextResult:
        summary_request = ModelRequest(
            request_id=request.request_id,
            profile_id=request.profile_id,
            session_id=request.session_id,
            provider_id=request.provider_id,
            model_id=request.model_id,
            prompt=request.prompt,
            context=dict(request.context),
            task="summarize",
            metadata=dict(request.metadata),
        )
        result = self.generate(summary_request, credentials)
        return ModelTextResult(
            result_id=result.result_id,
            request_id=result.request_id,
            adapter_id=result.adapter_id,
            provider_id=result.provider_id,
            model_id=result.model_id,
            task="summarize",
            content=result.content,
            usage=result.usage,
            failure_kind=result.failure_kind,
            metadata=dict(result.metadata),
        )

    def embed(self, request: ModelRequest, credentials: Mapping[str, str]) -> ModelEmbeddingResult:
        credential_keys = self._credential_keys(self._resolve_credentials(credentials))
        return ModelEmbeddingResult(
            result_id=f"{request.request_id}:embed",
            request_id=request.request_id,
            adapter_id=self.descriptor.adapter_id,
            provider_id=self.resolution.provider_id,
            model_id=self.resolution.model_id,
            task="embed",
            embeddings=(),
            failure_kind="unsupported",
            metadata={
                "request_family": self.resolution.request_family,
                "transport_id": self.resolution.transport_id,
                "credential_keys": credential_keys,
            },
        )

    def _compose_system_prompt(self, request: ModelRequest, credential_keys: str) -> str:
        del credential_keys
        return build_provider_identity_contract(request)

    def _compose_user_text(self, request: ModelRequest) -> str:
        context_bits: list[str] = []
        for key in ("goal_ids", "memory_ids", "artifact_ids", "mode"):
            value = request.context.get(key)
            if value:
                context_bits.append(f"{key}={value}")
        if request.metadata:
            context_bits.extend(f"{key}={value}" for key, value in sorted(request.metadata.items()))
        prompt = request.prompt.strip() or "acknowledged"
        if context_bits:
            return f"{prompt}\n\ncontext: {'; '.join(context_bits)}"
        return prompt

    def _max_tokens_for(self, request: ModelRequest) -> int:
        token_budget = request.context.get("token_budget")
        if token_budget is not None:
            try:
                budget = int(token_budget)
            except (TypeError, ValueError):
                budget = self.max_tokens
            else:
                budget = max(32, min(self.max_tokens, budget))
            return budget
        return self.max_tokens

    def _compose_url(self, base_url: str, endpoint_path: str) -> str:
        return f"{base_url.rstrip('/')}/{endpoint_path.lstrip('/')}"


class AnthropicMessagesProviderCapability(ModelProviderCapability):
    """Shared runtime bridge for the native Anthropic adapter."""

    def __init__(
        self,
        *,
        adapter: AnthropicMessagesModelAdapter,
        credential_source: CredentialSource | None = None,
        capability_id: str = "model.anthropic.messages",
    ) -> None:
        self.adapter = adapter
        self.credential_source = credential_source or adapter.credential_source
        self.descriptor = CapabilityDescriptor(
            capability_id=capability_id,
            kind="model_provider",
            version="1.0.0",
            metadata={
                "provider_id": adapter.resolution.provider_id,
                "transport_id": adapter.resolution.transport_id,
                "request_family": adapter.resolution.request_family,
                "model_id": adapter.resolution.model_id,
                "adapter_id": adapter.descriptor.adapter_id,
                "native_api": "anthropic_messages",
            },
        )

    def _credentials(self) -> Mapping[str, str]:
        if self.credential_source is None:
            return {}
        return self.credential_source.resolve(self.adapter.resolution.provider_id)

    def generate(
        self,
        *,
        profile: ProfileState,
        session: SessionState,
        context: ContextBundle,
        prompt: str,
    ) -> ExecutionResult:
        request = ModelRequest(
            request_id=f"{session.session_id}:anthropic",
            profile_id=profile.profile_id,
            session_id=session.session_id,
            provider_id=self.adapter.resolution.provider_id,
            model_id=self.adapter.resolution.model_id,
            prompt=prompt,
            context={
                "bundle_id": context.bundle_id,
                "token_budget": str(context.token_budget),
                "instruction_refs": ",".join(context.instruction_refs),
                "goal_ids": ",".join(context.goal_ids),
                "memory_ids": ",".join(context.memory_ids),
                "artifact_ids": ",".join(context.artifact_ids),
                "rendered_prompt": context.rendered_prompt or "",
            },
            metadata={
                "profile_mode": profile.mode,
                "session_status": session.status,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        result = self.adapter.generate(request, self._credentials())
        return ExecutionResult(
            execution_id=result.result_id,
            session_id=session.session_id,
            outcome="ok" if result.failure_kind is None else "failed",
            summary=result.content,
            telemetry_event_ids=(request.request_id,),
            side_effects=(
                f"provider={result.provider_id}",
                f"transport={self.adapter.resolution.transport_id}",
                f"credential_keys={result.metadata.get('credential_keys', 'unknown')}",
            ),
        )
