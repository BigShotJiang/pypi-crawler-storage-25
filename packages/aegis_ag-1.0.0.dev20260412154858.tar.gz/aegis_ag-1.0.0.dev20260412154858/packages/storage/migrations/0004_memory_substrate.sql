CREATE TABLE IF NOT EXISTS memory_ledger_entries (
    entry_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    event_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    content TEXT NOT NULL,
    kind TEXT NOT NULL,
    source_event_id TEXT,
    goal_refs_json TEXT NOT NULL,
    tags_json TEXT NOT NULL,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memories (
    memory_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    content TEXT NOT NULL,
    source_event_id TEXT,
    goal_refs_json TEXT NOT NULL,
    tags_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    lifecycle_state TEXT NOT NULL DEFAULT 'active',
    replacement_memory_id TEXT,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memory_ledger_entries_session_created
    ON memory_ledger_entries(session_id, created_at ASC, entry_id ASC);

CREATE INDEX IF NOT EXISTS idx_memories_session_state_created
    ON memories(session_id, lifecycle_state, created_at ASC, memory_id ASC);

CREATE INDEX IF NOT EXISTS idx_memories_state_created
    ON memories(lifecycle_state, created_at ASC, memory_id ASC);
