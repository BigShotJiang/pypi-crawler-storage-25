CREATE TABLE IF NOT EXISTS goal_graphs (
    session_id TEXT PRIMARY KEY,
    root_goal_id TEXT,
    active_goal_id TEXT,
    revision_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES sessions(session_id)
);

CREATE TABLE IF NOT EXISTS goal_nodes (
    goal_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    goal_order INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL,
    status TEXT NOT NULL,
    priority TEXT NOT NULL,
    owner TEXT,
    parent_goal_id TEXT,
    dependency_refs_json TEXT NOT NULL,
    evidence_refs_json TEXT NOT NULL,
    related_memory_ids_json TEXT NOT NULL,
    deadline TEXT,
    time_sensitivity TEXT NOT NULL,
    review_checkpoint TEXT,
    revision_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES goal_graphs(session_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS goal_lifecycle_events (
    event_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    goal_id TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT NOT NULL,
    reason TEXT,
    revision_id TEXT,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(session_id) REFERENCES goal_graphs(session_id) ON DELETE CASCADE,
    FOREIGN KEY(goal_id) REFERENCES goal_nodes(goal_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_goal_graphs_revision
    ON goal_graphs(session_id, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_goal_nodes_session_order
    ON goal_nodes(session_id, goal_order ASC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_goal_nodes_status
    ON goal_nodes(session_id, status ASC, priority DESC, goal_id ASC);

CREATE INDEX IF NOT EXISTS idx_goal_lifecycle_events_goal
    ON goal_lifecycle_events(goal_id, created_at DESC, event_id ASC);
