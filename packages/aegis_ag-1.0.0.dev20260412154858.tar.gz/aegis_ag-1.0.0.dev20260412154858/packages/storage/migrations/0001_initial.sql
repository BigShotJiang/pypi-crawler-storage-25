CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS profiles (
    profile_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    mode TEXT NOT NULL,
    soul_path TEXT,
    preferences_json TEXT NOT NULL,
    enabled_capabilities_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    workspace_id TEXT,
    status TEXT NOT NULL,
    started_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    parent_session_id TEXT,
    interruption_state TEXT,
    resume_count INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(profile_id) REFERENCES profiles(profile_id)
);

CREATE TABLE IF NOT EXISTS session_lineage (
    parent_session_id TEXT NOT NULL,
    child_session_id TEXT NOT NULL PRIMARY KEY,
    resumed_at TEXT NOT NULL,
    FOREIGN KEY(parent_session_id) REFERENCES sessions(session_id),
    FOREIGN KEY(child_session_id) REFERENCES sessions(session_id)
);

CREATE INDEX IF NOT EXISTS idx_sessions_profile_id ON sessions(profile_id);
CREATE INDEX IF NOT EXISTS idx_sessions_parent_session_id ON sessions(parent_session_id);
CREATE INDEX IF NOT EXISTS idx_session_lineage_parent_session_id ON session_lineage(parent_session_id);
