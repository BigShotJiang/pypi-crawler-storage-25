CREATE TABLE IF NOT EXISTS experiences (
    experience_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    profile_id TEXT NOT NULL,
    workspace_id TEXT,
    run_id TEXT REFERENCES agent_runs(run_id) ON DELETE SET NULL,
    source_event_id TEXT,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT NOT NULL,
    goal_id TEXT,
    tool_call_count INTEGER NOT NULL DEFAULT 0,
    model_turn_count INTEGER NOT NULL DEFAULT 0,
    related_skill_ids_json TEXT NOT NULL DEFAULT '[]',
    produced_artifact_ids_json TEXT NOT NULL DEFAULT '[]',
    tags_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_experiences_session_updated
ON experiences(session_id, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_experiences_profile_status
ON experiences(profile_id, status, updated_at DESC);
