CREATE TABLE IF NOT EXISTS auth_profiles (
    profile_id TEXT PRIMARY KEY,
    provider_id TEXT NOT NULL,
    transport_id TEXT NOT NULL,
    base_url TEXT,
    default_model TEXT,
    auth_method TEXT NOT NULL,
    provider_kind TEXT NOT NULL,
    extra_headers_json TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    session_pin TEXT,
    cooldown_until TEXT,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS auth_secret_references (
    reference_id TEXT PRIMARY KEY,
    profile_id TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    secret_name TEXT NOT NULL,
    secret_key TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'workspace',
    reference_order INTEGER NOT NULL DEFAULT 0,
    metadata_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(profile_id) REFERENCES auth_profiles(profile_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_auth_profiles_provider_priority
    ON auth_profiles(provider_id, priority DESC, profile_id ASC);

CREATE INDEX IF NOT EXISTS idx_auth_secret_references_profile
    ON auth_secret_references(profile_id, reference_order ASC, reference_id ASC);
