"""
### Tribulnation Hitbtc
> An SDK to connect Hitbtc with the Tribulnation ecosystem.

- Details
"""