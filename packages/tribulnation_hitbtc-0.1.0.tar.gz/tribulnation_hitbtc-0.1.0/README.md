# Tribulnation Hitbtc SDK

> An SDK to connect Hitbtc with the Tribulnation ecosystem.

🚧 Under construction.