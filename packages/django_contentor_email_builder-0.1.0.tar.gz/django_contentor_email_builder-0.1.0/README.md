# django-contentor-email-builder

A visual email builder for Django admin, powered by [MailCraft](https://mailcraft.contentor.app).

Add a drag-and-drop email builder to your Django admin with one `pip install`. Select users, compose beautiful emails, and send — all from the admin panel.

## Quick Start

1. Install:

```bash
pip install django-contentor-email-builder
```

2. Add to `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'django_email_builder',
]
```

3. Configure your API key:

```python
EMAIL_BUILDER_API_KEY = 'mc_live_your_key_here'
```

4. Done! Go to Django admin → Users → select users → "Send email with Email Builder".

## Settings

| Setting | Required | Default | Description |
|---------|----------|---------|-------------|
| `EMAIL_BUILDER_API_KEY` | Yes | — | Your MailCraft API key |
| `EMAIL_BUILDER_VARIABLES` | No | `{}` | Map template variables to User attributes |
| `EMAIL_BUILDER_URL` | No | `https://mailcraft.contentor.app` | Builder URL |

### Variable Mapping

Map template variables to Django User model attributes:

```python
EMAIL_BUILDER_VARIABLES = {
    'first_name': 'first_name',
    'last_name': 'last_name',
    'email': 'email',
    # Supports dotted paths for related objects:
    'company': 'profile.company_name',
}
```

Variables are automatically synced to MailCraft on Django startup and become available in the email builder's variable picker.

## How It Works

1. Select users in Django admin's User list
2. Pick "Send email with Email Builder" from the actions dropdown
3. Compose your email in the visual builder (or load a saved template)
4. Click "Send" → review recipients and enter subject line → confirm
5. Each email is personalized with the user's variables and sent via Django's email backend

## Billing

Each personalized email render counts against your MailCraft plan's render quota. Sending to 100 users = 100 renders.

## Requirements

- Django >= 4.2
- A MailCraft account ([sign up](https://mailcraft.contentor.app))
