from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin
from django.http import HttpResponseRedirect
from django.urls import include, path, reverse

User = get_user_model()


@admin.action(description='Send email with Email Builder')
def send_email_with_builder(modeladmin, request, queryset):
    user_ids = list(queryset.values_list('pk', flat=True))
    request.session['email_builder_user_ids'] = user_ids
    return HttpResponseRedirect(reverse('admin:email_builder:builder'))


# Unregister default UserAdmin, re-register with our action
if admin.site.is_registered(User):
    admin.site.unregister(User)


@admin.register(User)
class EmailBuilderUserAdmin(UserAdmin):
    actions = list(UserAdmin.actions or []) + [send_email_with_builder]


# Register our URLs under admin
_original_get_urls = admin.AdminSite.get_urls


def _patched_get_urls(self):
    from django_email_builder import urls as eb_urls
    custom_urls = [
        path('email-builder/', include((eb_urls.urlpatterns, 'email_builder'))),
    ]
    return custom_urls + _original_get_urls(self)


admin.AdminSite.get_urls = _patched_get_urls
