from django.conf import settings
from django.core.exceptions import ImproperlyConfigured


def get_config():
    api_key = getattr(settings, 'EMAIL_BUILDER_API_KEY', None)
    if not api_key:
        raise ImproperlyConfigured(
            'EMAIL_BUILDER_API_KEY is required. Get your API key from https://mailcraft.contentor.app'
        )

    return {
        'api_key': api_key,
        'variables': getattr(settings, 'EMAIL_BUILDER_VARIABLES', {}),
        'builder_url': getattr(settings, 'EMAIL_BUILDER_URL', 'https://mailcraft.contentor.app'),
    }
