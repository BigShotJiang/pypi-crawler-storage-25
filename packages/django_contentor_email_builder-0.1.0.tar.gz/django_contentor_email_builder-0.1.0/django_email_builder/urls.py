from django.urls import path
from django_email_builder import views

app_name = 'email_builder'

urlpatterns = [
    path('builder/', views.builder_view, name='builder'),
    path('confirm/', views.confirm_view, name='confirm'),
    path('send/', views.send_view, name='send'),
]
