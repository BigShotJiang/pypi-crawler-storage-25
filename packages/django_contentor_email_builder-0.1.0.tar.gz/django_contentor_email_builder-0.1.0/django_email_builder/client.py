import json
import logging
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logger = logging.getLogger('django_email_builder')


class MailCraftClient:
    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        url = f'{self.base_url}/api/v1{path}'
        body = json.dumps(data).encode() if data else None
        req = Request(url, data=body, method=method)
        req.add_header('X-API-Key', self.api_key)
        req.add_header('Content-Type', 'application/json')

        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())

    def create_session(self, origin: str) -> dict:
        """POST /api/v1/auth/session — returns {token, expires_at, config}."""
        return self._request('POST', '/auth/session', {'origin': origin})

    def sync_variables(self, variables: list[dict]) -> None:
        """PATCH /api/v1/email/setup — pushes available_variables to org."""
        self._request('PATCH', '/email/setup', {'available_variables': variables})

    def render(self, template_json: dict, variables: dict) -> str:
        """POST /api/v1/render — returns rendered HTML string."""
        result = self._request('POST', '/render', {
            'json_data': template_json,
            'variables': variables,
        })
        return result['html']
