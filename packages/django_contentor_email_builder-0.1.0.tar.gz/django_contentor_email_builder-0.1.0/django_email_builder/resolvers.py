def resolve_variables(user, variables_config: dict) -> dict:
    """
    Resolve EMAIL_BUILDER_VARIABLES config to actual values for a user.

    variables_config: {'first_name': 'first_name', 'company': 'profile.company_name'}
    Returns: {'first_name': 'John', 'company': 'Acme Corp'}
    """
    result = {}
    for var_name, attr_path in variables_config.items():
        value = _resolve_dotted_path(user, attr_path)
        result[var_name] = str(value) if value else ''
    return result


def variables_to_api_format(variables_config: dict) -> list[dict]:
    """
    Convert EMAIL_BUILDER_VARIABLES dict to the MailCraft API format.

    {'first_name': 'first_name'} -> [{'key': 'first_name', 'label': 'First Name', ...}]
    """
    return [
        {
            'key': key,
            'label': key.replace('_', ' ').title(),
            'type': 'text',
            'defaultValue': '',
        }
        for key in variables_config
    ]


def _resolve_dotted_path(obj, path: str):
    """Traverse dotted attribute path. Returns None if any part is missing."""
    parts = path.split('.')
    current = obj
    for part in parts:
        try:
            current = getattr(current, part)
        except AttributeError:
            return None
        if current is None:
            return None
    return current
