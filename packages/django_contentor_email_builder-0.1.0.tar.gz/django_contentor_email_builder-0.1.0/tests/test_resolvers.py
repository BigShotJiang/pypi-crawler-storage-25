from django.test import TestCase
from django.contrib.auth.models import User
from django_email_builder.resolvers import resolve_variables, variables_to_api_format


class ResolveVariablesTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username='john',
            email='john@example.com',
            first_name='John',
            last_name='Doe',
        )

    def test_simple_attributes(self):
        config = {'first_name': 'first_name', 'email': 'email'}
        result = resolve_variables(self.user, config)
        self.assertEqual(result, {'first_name': 'John', 'email': 'john@example.com'})

    def test_missing_attribute_returns_empty(self):
        config = {'company': 'profile.company_name'}
        result = resolve_variables(self.user, config)
        self.assertEqual(result, {'company': ''})

    def test_none_value_returns_empty(self):
        self.user.first_name = ''
        self.user.save()
        config = {'first_name': 'first_name'}
        result = resolve_variables(self.user, config)
        self.assertEqual(result, {'first_name': ''})

    def test_empty_config_returns_empty(self):
        result = resolve_variables(self.user, {})
        self.assertEqual(result, {})


class VariablesToApiFormatTests(TestCase):
    def test_converts_keys_to_api_format(self):
        config = {'first_name': 'first_name', 'company': 'profile.company'}
        result = variables_to_api_format(config)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0], {
            'key': 'first_name',
            'label': 'First Name',
            'type': 'text',
            'defaultValue': '',
        })
        self.assertEqual(result[1]['key'], 'company')
        self.assertEqual(result[1]['label'], 'Company')
