from django.test import TestCase, override_settings
from django.core.exceptions import ImproperlyConfigured


class ConfTests(TestCase):
    @override_settings(EMAIL_BUILDER_API_KEY='mc_live_abc123')
    def test_reads_api_key(self):
        from django_email_builder.conf import get_config
        config = get_config()
        self.assertEqual(config['api_key'], 'mc_live_abc123')

    @override_settings()
    def test_missing_api_key_raises(self):
        from django.conf import settings
        if hasattr(settings, 'EMAIL_BUILDER_API_KEY'):
            delattr(settings, 'EMAIL_BUILDER_API_KEY')
        from django_email_builder.conf import get_config
        with self.assertRaises(ImproperlyConfigured):
            get_config()

    @override_settings(EMAIL_BUILDER_API_KEY='mc_test_abc123')
    def test_default_variables_empty(self):
        from django_email_builder.conf import get_config
        config = get_config()
        self.assertEqual(config['variables'], {})

    @override_settings(
        EMAIL_BUILDER_API_KEY='mc_test_abc123',
        EMAIL_BUILDER_VARIABLES={'first_name': 'first_name', 'company': 'profile.company'},
    )
    def test_reads_variables(self):
        from django_email_builder.conf import get_config
        config = get_config()
        self.assertEqual(config['variables'], {'first_name': 'first_name', 'company': 'profile.company'})

    @override_settings(EMAIL_BUILDER_API_KEY='mc_test_abc123')
    def test_default_builder_url(self):
        from django_email_builder.conf import get_config
        config = get_config()
        self.assertEqual(config['builder_url'], 'https://mailcraft.contentor.app')

    @override_settings(
        EMAIL_BUILDER_API_KEY='mc_test_abc123',
        EMAIL_BUILDER_URL='https://custom.example.com',
    )
    def test_custom_builder_url(self):
        from django_email_builder.conf import get_config
        config = get_config()
        self.assertEqual(config['builder_url'], 'https://custom.example.com')
