import json
from unittest.mock import patch, MagicMock
from django.test import TestCase
from django_email_builder.client import MailCraftClient


def _mock_response(status=200, data=None):
    """Create a mock urllib response."""
    resp = MagicMock()
    resp.status = status
    resp.read.return_value = json.dumps(data or {}).encode()
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


class ClientSessionTests(TestCase):
    @patch('django_email_builder.client.urlopen')
    def test_create_session_returns_token(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(200, {
            'token': 'sess_abc123',
            'expires_at': '2026-01-01T00:00:00Z',
            'config': {},
        })
        client = MailCraftClient('mc_test_key', 'https://example.com')
        result = client.create_session('http://localhost:8000')
        self.assertEqual(result['token'], 'sess_abc123')

        call_args = mock_urlopen.call_args
        request = call_args[0][0]
        self.assertIn('/api/v1/auth/session', request.full_url)
        self.assertEqual(request.get_header('X-api-key'), 'mc_test_key')
        body = json.loads(request.data)
        self.assertEqual(body['origin'], 'http://localhost:8000')


class ClientSyncTests(TestCase):
    @patch('django_email_builder.client.urlopen')
    def test_sync_variables_sends_patch(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(200, {'available_variables': []})
        client = MailCraftClient('mc_test_key', 'https://example.com')
        variables = [{'key': 'first_name', 'label': 'First Name', 'type': 'text', 'defaultValue': ''}]
        client.sync_variables(variables)

        call_args = mock_urlopen.call_args
        request = call_args[0][0]
        self.assertIn('/api/v1/email/setup', request.full_url)
        self.assertEqual(request.method, 'PATCH')
        body = json.loads(request.data)
        self.assertEqual(body['available_variables'], variables)


class ClientRenderTests(TestCase):
    @patch('django_email_builder.client.urlopen')
    def test_render_returns_html(self, mock_urlopen):
        mock_urlopen.return_value = _mock_response(200, {
            'html': '<table>Hello John</table>',
            'warnings': [],
            'variables_used': ['first_name'],
        })
        client = MailCraftClient('mc_test_key', 'https://example.com')
        html = client.render({'version': 1}, {'first_name': 'John'})
        self.assertEqual(html, '<table>Hello John</table>')

        call_args = mock_urlopen.call_args
        request = call_args[0][0]
        body = json.loads(request.data)
        self.assertEqual(body['variables'], {'first_name': 'John'})
        self.assertIn('json_data', body)
