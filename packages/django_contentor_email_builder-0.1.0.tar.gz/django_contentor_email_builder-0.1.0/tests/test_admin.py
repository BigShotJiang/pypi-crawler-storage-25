from unittest.mock import patch, MagicMock
from django.test import TestCase, override_settings
from django.contrib.auth.models import User


@override_settings(EMAIL_BUILDER_API_KEY='mc_test_000000000000000000000000')
class AdminActionTests(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_superuser(
            username='admin', email='admin@test.com', password='admin123'
        )
        self.user1 = User.objects.create_user(username='user1', email='u1@test.com')
        self.user2 = User.objects.create_user(username='user2', email='u2@test.com')

    def test_action_stores_user_ids_in_session(self):
        self.client.force_login(self.admin_user)
        response = self.client.post(
            '/admin/auth/user/',
            {
                'action': 'send_email_with_builder',
                '_selected_action': [str(self.user1.pk), str(self.user2.pk)],
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertIn('email-builder', response.url)


@override_settings(EMAIL_BUILDER_API_KEY='mc_test_000000000000000000000000')
class BuilderViewTests(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_superuser(
            username='admin', email='admin@test.com', password='admin123'
        )

    @patch('django_email_builder.views.MailCraftClient')
    def test_builder_view_requires_staff(self, mock_client_cls):
        response = self.client.get('/admin/email-builder/builder/')
        self.assertIn(response.status_code, [302, 403])

    @patch('django_email_builder.views.MailCraftClient')
    def test_builder_view_renders_iframe(self, mock_client_cls):
        mock_client = MagicMock()
        mock_client.create_session.return_value = {
            'token': 'sess_test123',
            'expires_at': '2026-01-01T00:00:00Z',
            'config': {},
        }
        mock_client_cls.return_value = mock_client
        self.client.force_login(self.admin_user)
        session = self.client.session
        session['email_builder_user_ids'] = [self.admin_user.pk]
        session.save()

        response = self.client.get('/admin/email-builder/builder/')
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'iframe')
        self.assertContains(response, 'sessionToken=sess_test123')
