"""
Configuration management for LLMOps Observability SDK
- Environment loading
- SQS configuration
- Default model resolution
- Size and performance limits
"""
import os
import logging
import tempfile
from typing import Dict, Any
from dotenv import load_dotenv

# Configure logger
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[llmops_observability] %(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# Try to load .env if it exists, but don't require it
# This allows users to set env vars before or after importing the SDK
try:
    load_dotenv()
except Exception:
    pass  # Silently continue if no .env file


# ============================================================
# PROGRAMMATIC CONFIGURATION STORAGE
# ============================================================
# Global configuration storage - allows setting config via code instead of env vars
_CONFIG: Dict[str, Any] = {}


_ENV_VAR_BY_KEY = {
    "project_id": "PROJECT_ID",
    "env": "ENV",
    "aws_sqs_url": "AWS_SQS_URL",
    "aws_region": "AWS_REGION",
    "s3_bucket": "LLMOPS_S3_BUCKET",
}


def _is_unresolved_placeholder(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    token = value.strip()
    return token.startswith("#{") and token.endswith("}")


def _clean_config_value(value: Any) -> Any:
    """Return None for unresolved placeholder strings so defaults can apply."""
    if _is_unresolved_placeholder(value):
        return None
    return value


def set_configuration(**config):
    """
    Set configuration programmatically instead of using environment variables.
    
    Parameters:
        project_id (str): Project identifier
        env (str): Environment name (e.g., "development", "production")
        aws_sqs_url (str): SQS queue URL
        aws_region (str): AWS region (default: "us-east-1")
        aws_profile (str): AWS profile name (optional)
        s3_bucket (str): S3 bucket for large payloads (optional)
    
    Example:
        set_configuration(
            project_id="my-project",
            env="production",
            aws_sqs_url="https://sqs.us-east-1.amazonaws.com/123/my-queue",
            aws_region="us-east-1"
        )
    """
    global _CONFIG
    changed_keys = []
    for key, value in config.items():
        if _CONFIG.get(key) != value:
            _CONFIG[key] = value
            changed_keys.append(key)

    if changed_keys:
        logger.debug(f"Configuration updated programmatically: {changed_keys}")


def get_config_value(key: str, default: Any = None) -> Any:
    """
    Get configuration value from programmatic config first, then fall back to
    the exact supported GenAI environment variables only.
    
    Args:
        key: Configuration key name
        default: Default value if not found
    
    Returns:
        Configuration value or default
    """
    # Check programmatic config first
    if key in _CONFIG:
        configured = _clean_config_value(_CONFIG[key])
        if configured is not None:
            return configured

    env_key = _ENV_VAR_BY_KEY.get(key)
    if env_key:
        env_value = _clean_config_value(os.getenv(env_key))
        if env_value is not None:
            return env_value

    return default


# ============================================================
# SIZE LIMITS & CONSTRAINTS
# ============================================================
# Payload size limits for SQS and compression
# MAX_SQS_SIZE is a conservative pre-base64 compressed-payload ceiling
# to keep the final JSON MessageBody under the 1,048,576 byte SQS limit.
# COMPRESSION_THRESHOLD (1 MB) - compress payload only if > this size

# Serialization limits
MAX_SQS_SIZE = 780_000         # Safe pre-base64 ceiling
COMPRESSION_THRESHOLD = 1_000_000  # 1 MB

# S3 Extended Client Configuration
# When payload exceeds this threshold, automatically store in S3 instead of SQS
# NOTE: Developers don't need to configure these - sensible defaults are provided
# These are intentionally fixed except for the S3 bucket supplied by GenAI apps.
S3_STORAGE_THRESHOLD = 780_000  # Align with safe SQS ceiling
S3_BUCKET = os.getenv("LLMOPS_S3_BUCKET", "llmops-telementry")
S3_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_PREFIX = "LLMOps/backup_traces/compressed_traces"



# ============================================================
# SQS CONFIGURATION & BATCHING
# ============================================================

# Spillover file for failed SQS sends
SPILLOVER_FILE = os.path.join(
    tempfile.gettempdir(), 
    "llmops_observability_spillover_queue.jsonl"
)

# Worker configuration
SQS_WORKER_COUNT = 4        # Number of background worker threads
SQS_BATCH_SIZE = 10         # Flush batch when reaching this count
SQS_BATCH_TIMEOUT = 0.2     # Timeout for queue.get() in seconds
SQS_FLUSH_TIME_THRESHOLD = 0.15  # Time-based flush threshold (every ~1s)
SQS_SHUTDOWN_TIMEOUT = 1.0  # Timeout for worker shutdown
SQS_RETRY_ATTEMPTS = 3      # Number of retry attempts if no MessageId received
SQS_RETRY_DELAY = 0.1       # Delay between retries in seconds
SQS_RETRY_BACKOFF_MULTIPLIER = 2.0
SQS_RETRY_MAX_DELAY = 0.5
SQS_IMMEDIATE_MAX_BLOCK_MS = 250


def get_sqs_config() -> Dict[str, Any]:
    """
    Get SQS configuration from programmatic config or environment variables.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - AWS_SQS_URL: SQS queue URL (required to enable SQS)
        - AWS_REGION: AWS region (default: "us-east-1")

    Programmatic configuration only:
        - aws_profile: optional AWS profile name
    
    Returns:
        Dict with SQS configuration
    """
    return {
        "aws_sqs_url": get_config_value("aws_sqs_url"),
        "aws_profile": get_config_value("aws_profile"),
        "aws_region": get_config_value("aws_region", "us-east-1"),
    }


# ============================================================
# PROJECT & ENVIRONMENT CONFIGURATION
# ============================================================

def get_project_id() -> str:
    """
    Get project ID from programmatic config or environment variables.
    Auto-injected into every span's metadata.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - PROJECT_ID: Project identifier (default: "unknown_project")
    
    Returns:
        str: Project ID
    """
    value = get_config_value("project_id", "unknown_project")
    return str(value).strip() if value else "unknown_project"


def get_environment() -> str:
    """
    Get environment from programmatic config or environment variables.
    Auto-injected into every span's metadata.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - ENV: Environment (e.g., "development", "staging", "uat", "production")
        - Default: "development"
    
    Returns:
        str: Environment name
    """
    value = get_config_value("env", "development")
    return str(value).strip() if value else "development"


def get_trace_context() -> Dict[str, str]:
    """
    Get trace context (project_id and environment) from environment.
    This is injected into all spans automatically.
    
    Returns:
        Dict with project_id and environment
    """
    return {
        "project_id": get_project_id(),
        "environment": get_environment(),
    }


# ============================================================
# MODEL CONFIGURATION
# ============================================================

def get_default_model() -> str:
    """
    Get default model ID for cost calculation.
    
    Resolution order:
        1. MODEL_ID environment variable (if set)
        2. Default: anthropic.claude-3-5-sonnet-20241022-v2:0 (Claude 3.5 Sonnet - most common, cost-effective)
    
    Environment variables:
        - MODEL_ID: Default model ID for cost calculation (e.g., "anthropic.claude-3-sonnet-20240229-v1:0")
    
    Returns:
        str: Default model ID for cost calculation
    """
    # Most popular and cost-effective model as fallback
    DEFAULT_FALLBACK = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    
    model_id = os.getenv("MODEL_ID", DEFAULT_FALLBACK).strip()
    
    if not model_id:
        model_id = DEFAULT_FALLBACK
    
    logger.debug(f"Default model for cost calculation: {model_id}")
    return model_id
