"""
LLM tracking decorator for LLMOps Observability
Simplified version that collects data into SDKTraceData
"""
from __future__ import annotations
import functools
import inspect
import random
import sys
import threading
import time
import uuid
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Union, Callable

from .trace_manager import TraceManager, serialize_value, SpanData, safe_locals, ensure_json_object
from .evaluation import evaluate_response, record_evaluation

logger = logging.getLogger(__name__)
PROMPT_KEYS = ("prompt", "user_context", "user_query", "input", "query", "question", "text", "message")
_DEFAULT_EVALS = ["correctness"]

# Import bedrock instrumentation for auto-capture
try:
    from .bedrock_instrumentation import (
        get_captured_model_data, 
        clear_captured_model_data,
        enable_bedrock_instrumentation,
        is_instrumentation_enabled
    )
    BEDROCK_INSTRUMENTATION_AVAILABLE = True
except ImportError:
    BEDROCK_INSTRUMENTATION_AVAILABLE = False
    get_captured_model_data = None
    clear_captured_model_data = None
    enable_bedrock_instrumentation = None
    is_instrumentation_enabled = None


def _ensure_instrumentation_enabled():
    """Auto-enable Bedrock instrumentation on first use."""
    if BEDROCK_INSTRUMENTATION_AVAILABLE and enable_bedrock_instrumentation and is_instrumentation_enabled:
        if not is_instrumentation_enabled():
            try:
                enable_bedrock_instrumentation()
                logger.debug("Bedrock instrumentation auto-enabled")
            except Exception as e:
                logger.debug(f"Failed to auto-enable Bedrock instrumentation: {e}")


def extract_text(resp: Any) -> str:
    """Extract text from various LLM response formats."""
    if isinstance(resp, str):
        return resp

    if not isinstance(resp, dict):
        return str(resp)

    # Bedrock Converse API
    try:
        return resp["output"]["message"]["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Anthropic Messages API
    try:
        return resp["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Amazon Titan
    try:
        return resp["results"][0]["outputText"]
    except (KeyError, IndexError, TypeError):
        pass

    # Cohere
    try:
        return resp["generation"]
    except (KeyError, TypeError):
        pass

    # AI21
    try:
        return resp["outputs"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Generic text field
    try:
        return resp["text"]
    except (KeyError, TypeError):
        pass

    # OpenAI format
    try:
        return resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        pass

    return str(resp)


def _estimate_tokens(text: Optional[str]) -> int:
    """Approximate tokens when provider doesn't return usage."""
    if not text:
        return 0
    try:
        return max(0, int(len(str(text)) / 4))
    except Exception:
        return 0


def _build_function_params_input(func: Callable, args: tuple, kwargs: Dict[str, Any]) -> Any:
    """
    Build input from function parameters.
    
    If function has single parameter: return just the parameter value
    If function has multiple parameters: return dict with parameter names as keys
    """
    try:
        sig = inspect.signature(func)
        params = sig.parameters
        
        # Skip 'self' for methods
        param_names = [name for name in params.keys() if name != 'self']
        
        # Build mapping of param_name -> value
        param_values = {}
        
        # Map positional args to parameter names
        for i, arg in enumerate(args):
            # Skip 'self' in counting
            param_idx = i if 'self' not in params else i + 1
            if param_idx < len(param_names):
                param_values[param_names[param_idx]] = arg
        
        # Add kwargs
        param_values.update(kwargs)
        
        # Always return as dict with parameter names as keys (don't unwrap single params)
        # This ensures inputs appear as objects in Langfuse, not unwrapped strings
        if len(param_values) >= 1:
            return serialize_value(param_values)
        
        # Empty case
        return None
    except Exception as e:
        logger.debug(f"Error building function params input: {e}")
        return None


def _build_input_data(
    args: tuple,
    kwargs: Dict[str, Any],
    local_vars: Optional[Dict[str, Any]] = None,
    capture_locals_spec: Union[bool, List[str]] = False,
    capture_self_flag: bool = False,
) -> Dict[str, Any]:
    """Build input_data dict with optional capture of locals and self"""
    input_data = {
        "args": serialize_value(args),
        "kwargs": serialize_value(kwargs),
    }
    
    # Capture self if requested
    if capture_self_flag and args and hasattr(args[0], '__dict__'):
        try:
            input_data["self"] = serialize_value(args[0])
        except Exception:
            pass
    
    # Capture local variables if requested
    if capture_locals_spec and local_vars:
        if isinstance(capture_locals_spec, bool) and capture_locals_spec:
            # Capture all locals (except private ones)
            input_data["locals"] = safe_locals(local_vars)
        elif isinstance(capture_locals_spec, list):
            # Capture only specified locals
            input_data["locals"] = {
                k: serialize_value(v) 
                for k, v in local_vars.items() 
                if k in capture_locals_spec
            }
    
    return input_data


def _extract_prompt_from_captured(captured: Optional[Dict[str, Any]]) -> Optional[str]:
    """Extract prompt from Bedrock captured payloads."""
    if not captured:
        return None

    messages = captured.get("messages")
    if messages:
        return str(messages)

    request_body = captured.get("request_body")
    if isinstance(request_body, dict):
        for key in ("prompt", "inputText", "input", "text"):
            if key in request_body and request_body[key] is not None:
                return str(request_body[key])
        if "messages" in request_body and request_body["messages"] is not None:
            return str(request_body["messages"])

    return None


def _extract_prompt_from_locals(args: tuple, kwargs: dict, local_vars: Optional[dict]) -> Optional[str]:
    """Fallback: Extract prompt from function args/kwargs/locals."""
    def _first_text(mapping: Optional[dict]) -> Optional[str]:
        if not mapping:
            return None
        for key in PROMPT_KEYS:
            val = mapping.get(key)
            if isinstance(val, str) and val.strip():
                return val
        return None

    from_kwargs = _first_text(kwargs)
    if from_kwargs:
        return from_kwargs

    if args and isinstance(args[0], str) and args[0].strip():
        return args[0]

    from_locals = _first_text(local_vars)
    if from_locals:
        return from_locals

    return None


def _resolve_custom_value(value: Union[str, Callable], args: tuple, kwargs: dict, result: Any = None, local_vars: Optional[dict] = None) -> Optional[str]:
    """Resolve custom input/output value - can be string, variable name, or callable."""
    if value is None:
        return None
    
    # If it's a callable, call it with context
    if callable(value):
        try:
            return str(value(args, kwargs, result))
        except Exception as e:
            logger.debug(f"Error calling custom value resolver: {e}")
            return None
    
    # If it's a string, check if it's a variable name in local_vars first
    if isinstance(value, str):
        # Try to find it as a variable name in locals
        if local_vars and value in local_vars:
            return str(local_vars[value])
        # Otherwise, treat it as a literal string
        return value
    
    return None


def _usage_from_captured_bedrock() -> Optional[Dict[str, int]]:
    if not (BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data):
        return None

    captured = get_captured_model_data()
    if not captured:
        return None

    usage = _extract_usage_from_bedrock_response_body(captured.get("response_body"))
    if usage:
        return usage
    return _extract_usage_from_bedrock_response_metadata(captured.get("response_metadata"))


def _extract_usage_from_bedrock_response_body(response_body: Any) -> Optional[Dict[str, int]]:
    if not isinstance(response_body, dict):
        return None
    usage_data = response_body.get("usage")
    if not isinstance(usage_data, dict):
        return None
    usage: Dict[str, int] = {}
    if "inputTokens" in usage_data:
        usage["input_tokens"] = usage_data["inputTokens"]
    if "outputTokens" in usage_data:
        usage["output_tokens"] = usage_data["outputTokens"]
    if "totalTokens" in usage_data:
        usage["total_tokens"] = usage_data["totalTokens"]
    return usage or None


def _extract_usage_from_bedrock_response_metadata(response_metadata: Any) -> Optional[Dict[str, int]]:
    if not isinstance(response_metadata, dict):
        return None
    has_input = "input_tokens" in response_metadata
    has_output = "output_tokens" in response_metadata
    if not (has_input or has_output):
        return None
    usage: Dict[str, int] = {}
    if has_input:
        usage["input_tokens"] = response_metadata["input_tokens"]
    if has_output:
        usage["output_tokens"] = response_metadata["output_tokens"]
    if has_input and has_output:
        usage["total_tokens"] = response_metadata["input_tokens"] + response_metadata["output_tokens"]
    return usage


def _usage_from_result_object(result: Any) -> Optional[Dict[str, int]]:
    if not hasattr(result, "usage"):
        return None
    usage_obj = result.usage
    usage: Dict[str, int] = {}
    if hasattr(usage_obj, "prompt_tokens"):
        usage["input_tokens"] = usage_obj.prompt_tokens
    if hasattr(usage_obj, "completion_tokens"):
        usage["output_tokens"] = usage_obj.completion_tokens
    if hasattr(usage_obj, "total_tokens"):
        usage["total_tokens"] = usage_obj.total_tokens
    return usage or None


def _usage_from_result_dict(result: Any) -> Optional[Dict[str, int]]:
    if not isinstance(result, dict) or "usage" not in result:
        return None
    usage_data = result.get("usage")
    if not isinstance(usage_data, dict):
        return None

    usage: Dict[str, int] = {}
    if "inputTokens" in usage_data:
        usage["input_tokens"] = usage_data["inputTokens"]
    if "outputTokens" in usage_data:
        usage["output_tokens"] = usage_data["outputTokens"]
    if "totalTokens" in usage_data:
        usage["total_tokens"] = usage_data["totalTokens"]
    return usage or None


def extract_usage(
    result: Any,
    _legacy_kwargs: Optional[Dict[str, Any]] = None,
    *,
    prompt: Optional[str] = None,
    response_text: Optional[str] = None,
) -> Optional[Dict[str, int]]:
    """Extract token usage from LLM response with fallback estimation."""
    # Backward-compatible positional parameter retained for existing callers.
    _ = _legacy_kwargs
    for extractor in (_usage_from_captured_bedrock, lambda: _usage_from_result_object(result), lambda: _usage_from_result_dict(result)):
        usage = extractor()
        if usage:
            return usage

    # Fallback: estimate tokens from prompt/response text
    inp = _estimate_tokens(prompt)
    out = _estimate_tokens(response_text)
    if inp > 0 or out > 0:
        return {"input_tokens": inp, "output_tokens": out, "total_tokens": inp + out}
    
    return None


def _is_null_like_text(candidate: str) -> bool:
    return not candidate or candidate.lower() in {"none", "null", "undefined"}


def _normalize_model_id_from_iterable(items: Union[tuple, list]) -> Optional[str]:
    prioritized = [items[1]] if len(items) >= 2 else []
    for item in prioritized + list(items):
        candidate = _normalize_model_id(item)
        if candidate:
            return candidate
    return None


def _normalize_model_id(value: Any) -> Optional[str]:
    """Normalize candidate model IDs and ignore empty/null-like values."""
    if value is None:
        return None
    if isinstance(value, (tuple, list)):
        return _normalize_model_id_from_iterable(value)
    candidate = value.strip() if isinstance(value, str) else str(value).strip()
    if _is_null_like_text(candidate):
        return None
    return candidate


def _candidate_from_keys(source: Any, keys: tuple[str, ...]) -> Optional[str]:
    if not isinstance(source, dict):
        return None
    for key in keys:
        candidate = _normalize_model_id(source.get(key))
        if candidate:
            return candidate
    return None


def _model_id_from_contextvars() -> Optional[str]:
    try:
        from contextvars import copy_context

        ctx = copy_context()
        for var in ctx:
            if "bedrock_model_id" in var.name or "model_id" in var.name:
                candidate = _normalize_model_id(var.get())
                if candidate:
                    return candidate
    except Exception:
        return None
    return None


def _model_id_from_bedrock_capture() -> Optional[str]:
    if not (BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data):
        return None
    try:
        captured = get_captured_model_data() or {}
        return _candidate_from_keys(captured, ("model_id", "modelId"))
    except Exception:
        return None


def extract_model_id(result: Any, kwargs: Dict[str, Any]) -> Optional[str]:
    """
    Extract model ID from LLM response or kwargs.
    
    Priority order:
    1. Context variable (if set by application)
    2. Auto-captured from Bedrock instrumentation (if enabled)
    3. Function kwargs (model, modelId, model_id, idx)
    4. Result dict or attributes
    """
    keys = ("model", "modelId", "model_id", "idx")
    for extractor in (
        _model_id_from_contextvars,
        _model_id_from_bedrock_capture,
        lambda: _candidate_from_keys(kwargs, keys),
        lambda: _candidate_from_keys(result, keys),
        lambda: _normalize_model_id(getattr(result, "model", None)),
    ):
        candidate = extractor()
        if candidate:
            return candidate
    return None


def _maybe_enable_trace_hook(func: Callable, capture_locals: Union[bool, List[str]], input_value: Any, output_value: Any):
    captured_locals: Dict[str, Any] = {}
    old_trace = sys.gettrace()

    def trace_hook(frame, event, arg):
        if frame.f_code == func.__code__ and event in ("line", "return", "exception"):
            captured_locals.update(frame.f_locals.copy())
        if old_trace:
            return old_trace(frame, event, arg)
        return trace_hook

    trace_was_set = False
    if input_value or output_value or capture_locals:
        sys.settrace(trace_hook)
        trace_was_set = True
    return captured_locals, old_trace, trace_was_set


def _restore_trace_hook(old_trace: Any, trace_was_set: bool) -> None:
    if trace_was_set:
        sys.settrace(old_trace)


def _resolve_custom_io(
    *,
    args: tuple,
    kwargs: Dict[str, Any],
    result: Any,
    local_vars_for_prompt: Optional[Dict[str, Any]],
    input_value: Optional[Union[str, Callable]],
    output_value: Optional[Union[str, Callable]],
) -> tuple[Any, Any]:
    custom_input = None
    if input_value:
        if callable(input_value):
            try:
                sig = inspect.signature(input_value)
                if len(sig.parameters) >= 3:
                    custom_input = input_value(args, kwargs, result)
                else:
                    custom_input = input_value(args, kwargs)
            except Exception:
                custom_input = input_value(args, kwargs, result)
        else:
            custom_input = _resolve_custom_value(input_value, args, kwargs, result, local_vars_for_prompt)
    custom_output = None
    if output_value:
        custom_output = _resolve_custom_value(output_value, args, kwargs, result, local_vars_for_prompt)
    return custom_input, custom_output


def _metadata_model(metadata: Optional[Dict[str, Any]]) -> Optional[str]:
    if isinstance(metadata, dict):
        return metadata.get("model")
    return None


def _resolve_initial_model_id(
    explicit_model: Optional[str],
    metadata: Optional[Dict[str, Any]],
) -> Optional[str]:
    metadata_model = _metadata_model(metadata)
    if explicit_model or metadata_model:
        model_id = explicit_model or metadata_model
    else:
        model_id = _model_id_from_bedrock_capture() or _model_id_from_contextvars()
    return model_id or TraceManager.get_trace_model_id()


def _resolve_named_params(func: Callable, args: tuple, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    try:
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        return dict(bound.arguments)
    except Exception:
        return kwargs


def _resolve_prompt(
    args: tuple,
    kwargs: Dict[str, Any],
    local_vars_for_prompt: Optional[Dict[str, Any]],
) -> Optional[str]:
    if BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data:
        prompt_from_capture = _extract_prompt_from_captured(get_captured_model_data())
        if prompt_from_capture:
            return prompt_from_capture
    return _extract_prompt_from_locals(args, kwargs, local_vars_for_prompt)


def _extract_llm_data(
    *,
    func: Callable,
    args: tuple,
    kwargs: Dict[str, Any],
    result: Any,
    error: Optional[Exception],
    explicit_model: Optional[str],
    metadata: Optional[Dict[str, Any]],
    local_vars_for_prompt: Optional[Dict[str, Any]],
) -> tuple[Optional[str], Optional[str], Optional[Dict[str, int]], Optional[str]]:
    prompt = None
    response = None
    usage = None
    model_id_final = _resolve_initial_model_id(explicit_model, metadata)

    if error or not result:
        # For agent/streaming spans that return None, try to get the
        # accumulated Bedrock usage from the trace level so that token
        # counts and cost are still reported in Langfuse.
        if not error:
            usage = TraceManager.get_trace_usage()
        return prompt, response, usage, model_id_final

    try:
        response = extract_text(result)
        prompt = _resolve_prompt(args, kwargs, local_vars_for_prompt)
        usage = extract_usage(result, prompt=prompt, response_text=response)
        named_params = _resolve_named_params(func, args, kwargs)
        model_id_final = model_id_final or extract_model_id(result, named_params)
    except Exception:
        pass

    return prompt, response, usage, model_id_final


def _serialize_local_value(value: Any) -> Any:
    try:
        return serialize_value(value)
    except Exception:
        return str(type(value).__name__)


def _locals_keys_to_capture(
    capture_locals: Union[bool, List[str]],
    local_vars_for_prompt: Dict[str, Any],
) -> List[str]:
    if isinstance(capture_locals, list):
        return [key for key in capture_locals if key in local_vars_for_prompt]
    return [key for key in local_vars_for_prompt if not key.startswith("_")]


def _build_locals_metadata(capture_locals: Union[bool, List[str]], local_vars_for_prompt: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not (capture_locals and local_vars_for_prompt):
        return {}
    keys = _locals_keys_to_capture(capture_locals, local_vars_for_prompt)
    return {key: _serialize_local_value(local_vars_for_prompt[key]) for key in keys}


def _merge_result_metadata(final_metadata: Dict[str, Any], result: Any, error: Optional[Exception]) -> None:
    if error or not isinstance(result, dict) or "ResponseMetadata" not in result:
        return
    final_metadata["ResponseMetadata"] = result["ResponseMetadata"]
    if "stopReason" in result:
        final_metadata["stop_reason"] = result["stopReason"]


def _get_bedrock_data() -> Optional[Dict[str, Any]]:
    if not (BEDROCK_INSTRUMENTATION_AVAILABLE and get_captured_model_data):
        return None
    return get_captured_model_data() or {}


def _merge_bedrock_request(final_metadata: Dict[str, Any], bedrock_data: Dict[str, Any]) -> None:
    bedrock_request = bedrock_data.get("bedrock_request")
    if bedrock_request is None:
        return
    final_metadata["bedrock_request"] = bedrock_request
    logger.info("[LLM Wrapper] Added bedrock_request to metadata")


def _merge_bedrock_response(final_metadata: Dict[str, Any], bedrock_data: Dict[str, Any]) -> None:
    bedrock_response = bedrock_data.get("bedrock_response")
    if not isinstance(bedrock_response, dict):
        return
    if "response_metadata" in bedrock_response:
        final_metadata["ResponseMetadata"] = bedrock_response["response_metadata"]
    if bedrock_response.get("stop_reason") is not None:
        final_metadata["stop_reason"] = bedrock_response["stop_reason"]
    if bedrock_response.get("is_continue_invoke") is not None:
        final_metadata["is_continue_invoke"] = bedrock_response["is_continue_invoke"]


def _merge_invoke_model_parameters(final_metadata: Dict[str, Any], bedrock_data: Dict[str, Any]) -> None:
    bedrock_request = bedrock_data.get("bedrock_request")
    if not isinstance(bedrock_request, dict):
        return
    invoke_params = bedrock_request.get("invokeModelParameters")
    if invoke_params is None:
        return
    existing_meta = final_metadata.get("ResponseMetadata")
    if not isinstance(existing_meta, dict):
        existing_meta = {}
    existing_meta["invokeModelParameters"] = invoke_params
    final_metadata["ResponseMetadata"] = existing_meta


def _resolve_model_parameters(bedrock_data: Dict[str, Any]) -> Dict[str, Any]:
    model_parameters: Dict[str, Any] = {}
    bedrock_request = bedrock_data.get("bedrock_request", {}) or {}
    inference_config = bedrock_data.get("inference_config") or bedrock_request.get("inferenceConfig")
    additional_fields = bedrock_data.get("additional_model_request_fields") or bedrock_request.get("additionalModelRequestFields")
    if isinstance(inference_config, dict):
        model_parameters.update(inference_config)
    if isinstance(additional_fields, dict):
        model_parameters.update(additional_fields)
    return model_parameters


def _merge_bedrock_metadata(final_metadata: Dict[str, Any], result: Any, error: Optional[Exception]) -> None:
    _merge_result_metadata(final_metadata, result, error)
    bedrock_data = _get_bedrock_data()
    if bedrock_data is None:
        return
    _merge_bedrock_request(final_metadata, bedrock_data)
    _merge_bedrock_response(final_metadata, bedrock_data)
    _merge_invoke_model_parameters(final_metadata, bedrock_data)
    model_parameters = _resolve_model_parameters(bedrock_data)
    if model_parameters:
        final_metadata["model_parameters"] = serialize_value(model_parameters)
        logger.info("[LLM Wrapper] Added ResponseMetadata to metadata")


def _resolve_output_payload(
    custom_output: Any,
    error: Optional[Exception],
    response: Optional[str],
    result: Any,
    serialize_result_output: bool,
) -> Any:
    """Resolve the output value based on priority: custom > response > serialized result."""
    if custom_output is not None:
        return custom_output
    if not error and response is not None:
        return response
    if not error:
        return serialize_value(result) if serialize_result_output else result
    return None


def _build_span_metadata(
    metadata: Optional[Dict[str, Any]],
    capture_locals: Union[bool, List[str]],
    local_vars_for_prompt: Optional[Dict[str, Any]],
    result: Any,
    error: Optional[Exception],
) -> Dict[str, Any]:
    """Build final metadata with locals and bedrock data."""
    final_metadata = dict(metadata or {})
    locals_metadata = _build_locals_metadata(capture_locals, local_vars_for_prompt)
    if locals_metadata:
        final_metadata["local_variables"] = locals_metadata
    _merge_bedrock_metadata(final_metadata, result, error)
    return final_metadata


@dataclass
class _SpanFinalizeArgs:
    func: Callable
    args: tuple
    kwargs: Dict[str, Any]
    span_name: str
    span_id: str
    parent_span_id: Optional[str]
    start_time: float
    end_time: float
    pending_added: bool
    error: Optional[Exception]
    result: Any
    captured_locals: Dict[str, Any]
    metadata: Optional[Dict[str, Any]]
    capture_locals: Union[bool, List[str]]
    model: Optional[str]
    input_value: Optional[Union[str, Callable]]
    output_value: Optional[Union[str, Callable]]
    serialize_result_output: bool
    span_type: str
    evals: Optional[List[str]] = None
    sample_rate: float = 1.0
    evaluation: bool = False
    evaluation_metadata: Optional[Dict[str, Any]] = None


def _normalize_evals(evals: Optional[List[str]], evaluation: bool) -> List[str]:
    if evals:
        return [value.strip().lower() for value in evals if isinstance(value, str) and value.strip()]
    if evaluation:
        return list(_DEFAULT_EVALS)
    return []


def _validate_sample_rate(sample_rate: float) -> float:
    if isinstance(sample_rate, bool) or not isinstance(sample_rate, (int, float)):
        raise ValueError("sample_rate must be a number between 0.0 and 1.0")
    normalized = float(sample_rate)
    if normalized < 0.0 or normalized > 1.0:
        raise ValueError("sample_rate must be between 0.0 and 1.0")
    return normalized


def _schedule_evaluations_non_blocking(
    *,
    span_name: str,
    span_id: str,
    prompt: Optional[str],
    response: Optional[str],
    evals: List[str],
    evaluation_metadata: Optional[Dict[str, Any]],
) -> None:
    if not evals:
        return

    def _runner() -> None:
        try:
            results = evaluate_response(
                evals=evals,
                prompt=prompt or "",
                response=response or "",
                context={"span_id": span_id, "span_name": span_name},
            )
            for eval_result in results:
                record_evaluation(
                    name=f"{span_name}_evaluation_{eval_result.criterion}",
                    score=eval_result.score,
                    label=eval_result.label,
                    rationale=eval_result.rationale,
                    parent_span_id=span_id,
                    evaluated_span_id=span_id,
                    evaluator_metadata={
                        "source": "track_llm_call",
                        "criterion": eval_result.criterion,
                        **(evaluation_metadata or {}),
                    },
                )
        except Exception as exc:
            logger.debug("Background evaluation failed: %s", exc)

    worker = threading.Thread(target=_runner, daemon=True)
    worker.start()


def _cleanup_span(pending_added: bool) -> None:
    if pending_added:
        TraceManager._decrement_pending()
    if BEDROCK_INSTRUMENTATION_AVAILABLE and clear_captured_model_data:
        # Only clear captured model data when no parent span is still on the
        # stack.  Inner (child) spans should preserve the data so that outer
        # (parent / agent) spans can read it during their own finalization.
        if not TraceManager.get_current_parent_span_id():
            clear_captured_model_data()


def _finalize_llm_span(ctx: _SpanFinalizeArgs) -> None:
    TraceManager.pop_span_context()
    local_vars_for_prompt = ctx.captured_locals if ctx.captured_locals else None
    custom_input, custom_output = _resolve_custom_io(
        args=ctx.args,
        kwargs=ctx.kwargs,
        result=ctx.result,
        local_vars_for_prompt=local_vars_for_prompt,
        input_value=ctx.input_value,
        output_value=ctx.output_value,
    )
    prompt, response, usage, model_id_final = _extract_llm_data(
        func=ctx.func,
        args=ctx.args,
        kwargs=ctx.kwargs,
        result=ctx.result,
        error=ctx.error,
        explicit_model=ctx.model,
        metadata=ctx.metadata,
        local_vars_for_prompt=local_vars_for_prompt,
    )
    params_input = _build_function_params_input(ctx.func, ctx.args, ctx.kwargs)
    input_payload = ensure_json_object(custom_input or params_input, key="input")
    out_value = _resolve_output_payload(
        custom_output,
        ctx.error,
        response,
        ctx.result,
        ctx.serialize_result_output,
    )
    output_payload = ensure_json_object(out_value, key="output")
    final_metadata = _build_span_metadata(
        ctx.metadata,
        ctx.capture_locals,
        local_vars_for_prompt,
        ctx.result,
        ctx.error,
    )
    
    duration_ms = int((ctx.end_time - ctx.start_time) * 1000)
    span_data = SpanData(
        span_id=ctx.span_id,
        span_name=ctx.span_name,
        span_type=ctx.span_type,
        parent_span_id=ctx.parent_span_id,
        start_time=ctx.start_time,
        end_time=ctx.end_time,
        duration_ms=duration_ms,
        input_data=input_payload,
        output_data=output_payload,
        error=str(ctx.error) if ctx.error else None,
        model_id=model_id_final,
        metadata=final_metadata,
        usage=usage,
        prompt=prompt,
        response=response,
        status="error" if ctx.error else "success",
        status_message=str(ctx.error) if ctx.error else None,
    )
    TraceManager.add_span(span_data)

    if not ctx.error:
        eval_list = _normalize_evals(ctx.evals, ctx.evaluation)
        if eval_list and random.random() <= ctx.sample_rate:
            _schedule_evaluations_non_blocking(
                span_name=ctx.span_name,
                span_id=ctx.span_id,
                prompt=prompt,
                response=response,
                evals=eval_list,
                evaluation_metadata=ctx.evaluation_metadata,
            )

    _cleanup_span(ctx.pending_added)


def _run_tracked_sync(func: Callable, args: tuple, kwargs: Dict[str, Any], cfg: Dict[str, Any]) -> Any:
    if not TraceManager.has_active_trace():
        return func(*args, **kwargs)

    pending_added = TraceManager._increment_pending_if_active()
    span_id = uuid.uuid4().hex
    parent_span_id = TraceManager.get_current_parent_span_id()
    start_time = time.time()
    TraceManager.push_span_context(span_id)

    error: Optional[Exception] = None
    result: Any = None
    captured_locals, old_trace, trace_was_set = _maybe_enable_trace_hook(
        func,
        cfg["capture_locals"],
        cfg["input"],
        cfg["output"],
    )
    try:
        result = func(*args, **kwargs)
        return result
    except Exception as exc:
        error = exc
        raise
    finally:
        _restore_trace_hook(old_trace, trace_was_set)
        _finalize_llm_span(
            _SpanFinalizeArgs(
                func=func,
                args=args,
                kwargs=kwargs,
                span_name=cfg["span_name"],
                span_id=span_id,
                parent_span_id=parent_span_id,
                start_time=start_time,
                end_time=time.time(),
                pending_added=pending_added,
                error=error,
                result=result,
                captured_locals=captured_locals,
                metadata=cfg["metadata"],
                capture_locals=cfg["capture_locals"],
                model=cfg["model"],
                input_value=cfg["input"],
                output_value=cfg["output"],
                serialize_result_output=cfg["serialize_sync"],
                span_type=cfg["span_type"],
                evals=cfg.get("evals"),
                sample_rate=cfg.get("sample_rate", 1.0),
                evaluation=cfg.get("evaluation", False),
                evaluation_metadata=cfg.get("evaluation_metadata"),
            )
        )


async def _run_tracked_async(func: Callable, args: tuple, kwargs: Dict[str, Any], cfg: Dict[str, Any]) -> Any:
    if not TraceManager.has_active_trace():
        return await func(*args, **kwargs)

    pending_added = TraceManager._increment_pending_if_active()
    span_id = uuid.uuid4().hex
    parent_span_id = TraceManager.get_current_parent_span_id()
    start_time = time.time()
    TraceManager.push_span_context(span_id)

    error: Optional[Exception] = None
    result: Any = None
    captured_locals, old_trace, trace_was_set = _maybe_enable_trace_hook(
        func,
        cfg["capture_locals"],
        cfg["input"],
        cfg["output"],
    )
    try:
        result = await func(*args, **kwargs)
        return result
    except Exception as exc:
        error = exc
        raise
    finally:
        _restore_trace_hook(old_trace, trace_was_set)
        _finalize_llm_span(
            _SpanFinalizeArgs(
                func=func,
                args=args,
                kwargs=kwargs,
                span_name=cfg["span_name"],
                span_id=span_id,
                parent_span_id=parent_span_id,
                start_time=start_time,
                end_time=time.time(),
                pending_added=pending_added,
                error=error,
                result=result,
                captured_locals=captured_locals,
                metadata=cfg["metadata"],
                capture_locals=cfg["capture_locals"],
                model=cfg["model"],
                input_value=cfg["input"],
                output_value=cfg["output"],
                serialize_result_output=cfg["serialize_async"],
                span_type=cfg["span_type"],
                evals=cfg.get("evals"),
                sample_rate=cfg.get("sample_rate", 1.0),
                evaluation=cfg.get("evaluation", False),
                evaluation_metadata=cfg.get("evaluation_metadata"),
            )
        )


def _create_llm_decorator(
    *,
    name: Optional[str],
    model: Optional[str],
    metadata: Optional[Dict[str, Any]],
    capture_locals: Union[bool, List[str]],
    input: Optional[Union[str, Callable]],
    output: Optional[Union[str, Callable]],
    span_type: str,
    serialize_async: bool,
    serialize_sync: bool,
    evals: Optional[List[str]] = None,
    sample_rate: float = 1.0,
    evaluation: bool = False,
    evaluation_metadata: Optional[Dict[str, Any]] = None,
):
    def decorator(func):
        _ensure_instrumentation_enabled()
        cfg = {
            "span_name": name or func.__name__,
            "model": model,
            "metadata": metadata,
            "capture_locals": capture_locals,
            "input": input,
            "output": output,
            "span_type": span_type,
            "serialize_async": serialize_async,
            "serialize_sync": serialize_sync,
            "evals": evals,
            "sample_rate": sample_rate,
            "evaluation": evaluation,
            "evaluation_metadata": evaluation_metadata,
        }
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await _run_tracked_async(func, args, kwargs, cfg)

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            return _run_tracked_sync(func, args, kwargs, cfg)

        return sync_wrapper

    return decorator


def track_llm_call(
    name: Optional[str] = None,
    *,
    model: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    input: Optional[Union[str, Callable]] = None,
    output: Optional[Union[str, Callable]] = None,
    evals: Optional[List[str]] = None,
    sample_rate: float = 1.0,
    evaluation: bool = False,
    evaluation_metadata: Optional[Dict[str, Any]] = None,
):
    """
    Decorator to track LLM calls.
    
    Usage:
        @track_llm_call()
        def call_llm(prompt):
            return response
            
        @track_llm_call(name="summarize", model="claude-3-sonnet", metadata={"version": "1.0"})
        async def summarize(text):
            return summary
        
        @track_llm_call(capture_locals=True)
        def track_with_locals(prompt, max_tokens):
            # capture_locals=True captures all local variables
            return response
        
        @track_llm_call(input="custom input text", output="custom output text")
        def my_function(prompt):
            return response
        
        @track_llm_call(input=lambda args, kwargs: args[0], output=lambda result: result.get("text"))
        def my_function(prompt):
            return response
    
    Args:
        name: Optional custom name
        model: Optional model ID (will be prioritized over auto-detection)
        metadata: Optional metadata
        capture_locals: Capture function local variables (bool or list of var names)
        input: Optional custom span input (string or callable that extracts from args/kwargs)
        output: Optional custom span output (string or callable that extracts from result)
        evals: Optional evaluation criteria list (for example ["correctness"])
        sample_rate: Sampling probability in [0.0, 1.0] for triggering evaluations
        evaluation: Backward-compatible alias; if True and evals omitted uses ["correctness"]
        evaluation_metadata: Optional metadata added to evaluator spans
    """
    validated_sample_rate = _validate_sample_rate(sample_rate)
    return _create_llm_decorator(
        name=name,
        model=model,
        metadata=metadata,
        capture_locals=capture_locals,
        input=input,
        output=output,
        span_type="generation",
        serialize_async=False,
        serialize_sync=True,
        evals=evals,
        sample_rate=validated_sample_rate,
        evaluation=evaluation,
        evaluation_metadata=evaluation_metadata,
    )


def track_llm_agent(
    name: Optional[str] = None,
    *,
    model: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    input: Optional[Union[str, Callable]] = None,
    output: Optional[Union[str, Callable]] = None,
):
    """
    Decorator to track agentic orchestrator spans.
    
    Similar to @track_llm_call but designed for agent orchestration functions.
    Uses span_type="generation" so that Langfuse calculates cost and tokens.
    
    Args:
        name: Optional custom name
        model: Optional model ID
        metadata: Optional metadata
        capture_locals: Capture function local variables (bool or list of var names)
        input: Optional custom span input (string or callable)
        output: Optional custom span output (string or callable)
    """
    return _create_llm_decorator(
        name=name,
        model=model,
        metadata=metadata,
        capture_locals=capture_locals,
        input=input,
        output=output,
        span_type="generation",
        serialize_async=True,
        serialize_sync=True,
    )


def track_llm_tool(
    name: Optional[str] = None,
    *,
    model: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    input: Optional[Union[str, Callable]] = None,
    output: Optional[Union[str, Callable]] = None,
):
    """
    Decorator to track LLM tool invocations.
    
    Similar to @track_llm_call but sets span_type="tool" for tool execution spans.
    
    Args:
        name: Optional custom name
        model: Optional model ID
        metadata: Optional metadata
        capture_locals: Capture function local variables (bool or list of var names)
        input: Optional custom span input (string or callable)
        output: Optional custom span output (string or callable)
    """
    return _create_llm_decorator(
        name=name,
        model=model,
        metadata=metadata,
        capture_locals=capture_locals,
        input=input,
        output=output,
        span_type="tool",
        serialize_async=True,
        serialize_sync=True,
    )
