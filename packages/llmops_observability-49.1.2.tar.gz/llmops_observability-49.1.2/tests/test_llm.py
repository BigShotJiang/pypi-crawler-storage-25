import asyncio

import pytest

import llmops_observability.llm as llm
from llmops_observability.llm import (
    extract_text,
    extract_usage,
    extract_model_id,
    track_llm_call,
)
from llmops_observability.trace_manager import TraceManager


@pytest.fixture(autouse=True)
def _configure_trace_manager_env_for_llm(monkeypatch):
    """
    Mirror the trace manager tests: make sure start_trace() actually creates
    an active trace by providing minimal SQS / project / env configuration.
    """
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")

    # Reset active trace state before each test
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None


def test_extract_text_handles_multiple_formats():
    assert extract_text("hello") == "hello"
    assert extract_text(123) == "123"

    bedrock = {"output": {"message": {"content": [{"text": "bedrock"}]}}}
    assert extract_text(bedrock) == "bedrock"

    anthropic = {"content": [{"text": "anthropic"}]}
    assert extract_text(anthropic) == "anthropic"

    titan = {"results": [{"outputText": "titan"}]}
    assert extract_text(titan) == "titan"

    cohere = {"generation": "cohere"}
    assert extract_text(cohere) == "cohere"

    ai21 = {"outputs": [{"text": "ai21"}]}
    assert extract_text(ai21) == "ai21"

    generic = {"text": "generic"}
    assert extract_text(generic) == "generic"

    openai = {"choices": [{"message": {"content": "openai"}}]}
    assert extract_text(openai) == "openai"


def test_extract_usage_from_result_usage_object():
    class Usage:
        def __init__(self):
            self.prompt_tokens = 10
            self.completion_tokens = 20
            self.total_tokens = 30

    class Result:
        def __init__(self):
            self.usage = Usage()

    usage = extract_usage(Result(), {})
    assert usage == {"input_tokens": 10, "output_tokens": 20, "total_tokens": 30}


def test_extract_usage_from_bedrock_dict():
    resp = {"usage": {"inputTokens": 5, "outputTokens": 7, "totalTokens": 12}}
    usage = extract_usage(resp, {})
    assert usage == {"input_tokens": 5, "output_tokens": 7, "total_tokens": 12}


def test_extract_usage_fallback_estimate():
    usage = extract_usage({}, {}, prompt="hello", response_text="world")
    assert usage["total_tokens"] >= 0


def test_estimate_tokens_handles_none_and_errors():
    assert llm._estimate_tokens(None) == 0

    class BadStr:
        def __str__(self):
            raise RuntimeError("boom")

    assert llm._estimate_tokens(BadStr()) == 0


def test_build_input_data_captures_locals_list():
    args = (1, 2)
    kwargs = {"k": "v"}
    local_vars = {"keep": 1, "drop": 2, "_private": 3}
    data = llm._build_input_data(args, kwargs, local_vars, capture_locals_spec=["keep"])
    assert data["locals"] == {"keep": 1}


def test_extract_prompt_from_captured_messages_and_request_body():
    messages = [{"role": "user", "content": "hello"}]
    captured = {"messages": messages}
    assert llm._extract_prompt_from_captured(captured) == str(messages)

    captured = {"request_body": {"prompt": "prompt text"}}
    assert llm._extract_prompt_from_captured(captured) == "prompt text"

    captured = {"request_body": {"messages": messages}}
    assert llm._extract_prompt_from_captured(captured) == str(messages)


def test_extract_prompt_from_locals_priority():
    assert llm._extract_prompt_from_locals((), {"prompt": "hi"}, None) == "hi"
    assert llm._extract_prompt_from_locals(("hello",), {}, None) == "hello"
    assert llm._extract_prompt_from_locals((), {}, {"prompt": "local"}) == "local"


def test_resolve_custom_value_handles_errors_and_locals():
    def bad_callable(*_args, **_kwargs):
        raise RuntimeError("boom")

    assert llm._resolve_custom_value(bad_callable, (), {}) is None
    assert llm._resolve_custom_value("literal", (), {}) == "literal"
    assert llm._resolve_custom_value("value", (), {}, None, {"value": 123}) == "123"


def test_extract_usage_prefers_captured_bedrock(monkeypatch):
    captured = {"response_body": {"usage": {"inputTokens": 1, "outputTokens": 2, "totalTokens": 3}}}
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "get_captured_model_data", lambda: captured)
    usage = extract_usage({}, {})
    assert usage == {"input_tokens": 1, "output_tokens": 2, "total_tokens": 3}


def test_extract_model_id_from_captured_bedrock(monkeypatch):
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "get_captured_model_data", lambda: {"model_id": "captured-model"})
    assert extract_model_id({}, {}) == "captured-model"


def test_extract_model_id_from_kwargs_and_result():
    assert extract_model_id({}, {"model": "m1"}) == "m1"
    assert extract_model_id({}, {"modelId": "m2"}) == "m2"

    result = {"model": "m3"}
    assert extract_model_id(result, {}) == "m3"

    class ModelObj:
        def __init__(self):
            self.model = "m4"

    assert extract_model_id(ModelObj(), {}) == "m4"


def test_track_llm_call_without_active_trace_returns_raw_result():
    @track_llm_call()
    def llm_call(prompt: str):
        return {"output": {"message": {"content": [{"text": "resp"}]}}}

    result = llm_call("hi")
    assert result["output"]["message"]["content"][0]["text"] == "resp"
    assert TraceManager._active["spans"] == []


def test_track_llm_call_with_active_trace_sync():
    TraceManager.start_trace(name="llm_trace")

    @track_llm_call(model="test-model", metadata={"m": "v"})
    def llm_call(prompt: str):
        return {
            "output": {"message": {"content": [{"text": "resp"}]}},
            "usage": {"inputTokens": 10, "outputTokens": 20, "totalTokens": 30},
        }

    result = llm_call("hi")
    assert "output" in result
    assert TraceManager._active["spans"]
    span = TraceManager._active["spans"][-1]
    assert span.model_id == "test-model"
    assert span.status == "success"


def test_track_llm_call_capture_self():
    TraceManager.start_trace(name="llm_trace_self")

    class Client:
        def __init__(self, name):
            self.name = name

        @track_llm_call()
        def call(self, prompt: str):
            return {"choices": [{"message": {"content": "ok"}}]}

    client = Client("c1")
    result = client.call("hello")
    assert result["choices"][0]["message"]["content"] == "ok"
    span = TraceManager._active["spans"][-1]
    # New implementation may not explicitly expose 'self' in input_data;
    # just ensure a span was recorded for the method call.
    assert span.span_name == "call"


def test_track_llm_call_with_active_trace_async():
    async def _runner():
        TraceManager.start_trace(name="llm_trace_async")

        @track_llm_call()
        async def async_llm(prompt: str):
            await asyncio.sleep(0)
            return {"choices": [{"message": {"content": "ok"}}]}

        result = await async_llm("hello")
        assert result["choices"][0]["message"]["content"] == "ok"
        assert TraceManager._active["spans"]

    asyncio.run(_runner())


def test_track_llm_call_error_records_span():
    TraceManager.start_trace(name="llm_trace_error")

    @track_llm_call()
    def llm_call(prompt: str):
        raise ValueError("bad")

    try:
        llm_call("hi")
    except ValueError:
        pass

    span = TraceManager._active["spans"][-1]
    assert span.status == "error"


def test_track_llm_call_evals_creates_evaluation_span():
    TraceManager.start_trace(name="llm_eval_trace")

    @track_llm_call(evals=["correctness"], sample_rate=1.0, evaluation_metadata={"judge": "eval-model"})
    def eval_model_call(prompt: str):
        return {"output": {"message": {"content": [{"text": "evaluation output with enough detail"}]}}}

    eval_model_call("evaluate this")
    # Evaluation runs in background by design; keep assertion deterministic.
    for _ in range(20):
        if any(s.span_type == "evaluation" for s in TraceManager._active["spans"]):
            break
        asyncio.run(asyncio.sleep(0.01))
    spans = TraceManager._active["spans"]
    generation_spans = [s for s in spans if s.span_type == "generation"]
    evaluation_spans = [s for s in spans if s.span_type == "evaluation"]

    assert len(generation_spans) == 1
    assert len(evaluation_spans) == 1
    eval_span = evaluation_spans[0]
    assert eval_span.parent_span_id == generation_spans[0].span_id
    assert eval_span.input_data["evaluation"]["score"] > 0.0
    assert eval_span.input_data["evaluation"]["label"] in {"pass", "review", "fail"}
    assert eval_span.metadata["evaluator"]["judge"] == "eval-model"
    assert eval_span.metadata["evaluator"]["criterion"] == "correctness"


def test_track_llm_call_evaluation_alias_supports_backward_compatibility():
    TraceManager.start_trace(name="llm_eval_nested")

    @track_llm_call(evaluation=True)
    def eval_model_call(prompt: str):
        return {"output": {"message": {"content": [{"text": "backward compatibility response text"}]}}}

    eval_model_call("evaluate this")
    for _ in range(20):
        if any(s.span_type == "evaluation" for s in TraceManager._active["spans"]):
            break
        asyncio.run(asyncio.sleep(0.01))
    evaluation_spans = [s for s in TraceManager._active["spans"] if s.span_type == "evaluation"]
    assert len(evaluation_spans) == 1
    assert evaluation_spans[0].metadata["evaluator"]["criterion"] == "correctness"


def test_track_llm_call_evals_respects_sample_rate_zero():
    TraceManager.start_trace(name="llm_eval_skip")

    @track_llm_call(evals=["correctness"], sample_rate=0.0)
    def normal_llm_call(prompt: str):
        return {"output": {"message": {"content": [{"text": "normal response"}]}}}

    normal_llm_call("hello")
    asyncio.run(asyncio.sleep(0.05))
    evaluation_spans = [s for s in TraceManager._active["spans"] if s.span_type == "evaluation"]
    assert evaluation_spans == []


def test_track_llm_call_invalid_sample_rate_raises():
    with pytest.raises(ValueError, match="sample_rate"):
        @track_llm_call(evals=["correctness"], sample_rate=1.5)
        def _bad(prompt: str):
            return {"text": "x"}


# ============================================================
# Additional tests for improved coverage
# ============================================================

def test_extract_text_fallback_to_str_for_unknown_dict():
    """extract_text falls back to str() for unknown dict format."""
    unknown = {"unknown_format": "value"}
    result = extract_text(unknown)
    # Should return string representation since no format matched
    assert "unknown_format" in result


def test_extract_usage_returns_none_for_empty_usage_object():
    """extract_usage returns None when usage object has no attributes."""
    class EmptyUsage:
        pass

    class Result:
        def __init__(self):
            self.usage = EmptyUsage()

    usage = extract_usage(Result(), {})
    assert usage is None


def test_extract_usage_partial_attributes():
    """extract_usage handles usage object with only some attributes."""
    class PartialUsage:
        def __init__(self):
            self.prompt_tokens = 10
            # No completion_tokens or total_tokens

    class Result:
        def __init__(self):
            self.usage = PartialUsage()

    usage = extract_usage(Result(), {})
    assert usage == {"input_tokens": 10}


def test_extract_usage_bedrock_partial_tokens():
    """extract_usage handles Bedrock with only some token fields."""
    resp = {"usage": {"inputTokens": 5}}  # No outputTokens or totalTokens
    usage = extract_usage(resp, {})
    assert usage == {"input_tokens": 5}


def test_extract_usage_returns_none_when_no_usage():
    """extract_usage returns None when no usage info available."""
    usage = extract_usage({}, {})
    assert usage is None


def test_extract_model_id_from_model_id_kwarg():
    """extract_model_id checks model_id kwarg."""
    model = extract_model_id({}, {"model_id": "my-model"})
    assert model == "my-model"


def test_extract_model_id_falls_back_to_idx_kwarg():
    """extract_model_id falls back to idx when model keys are absent."""
    model = extract_model_id({}, {"idx": "us.anthropic.claude-sonnet-4-20250514-v1:0"})
    assert model == "us.anthropic.claude-sonnet-4-20250514-v1:0"


def test_extract_model_id_ignores_empty_model_id_then_uses_idx():
    """extract_model_id should not stop on empty model_id values."""
    model = extract_model_id({}, {"model_id": "", "idx": "us.anthropic.claude-sonnet-4-5-20250929-v1:0"})
    assert model == "us.anthropic.claude-sonnet-4-5-20250929-v1:0"


def test_extract_model_id_normalizes_tuple_model_id():
    """extract_model_id extracts model from tuple-style model_id values."""
    model = extract_model_id({}, {"model_id": ("Foundation Model", "us.anthropic.claude-sonnet-4-20250514-v1:0")})
    assert model == "us.anthropic.claude-sonnet-4-20250514-v1:0"


def test_extract_model_id_from_result_model_id():
    """extract_model_id from result dict with modelId key."""
    result = {"modelId": "result-model-id"}
    model = extract_model_id(result, {})
    assert model == "result-model-id"


def test_extract_model_id_returns_none_when_not_found():
    """extract_model_id returns None when no model info."""
    model = extract_model_id({}, {})
    assert model is None


def test_extract_model_id_from_bedrock_instrumentation(monkeypatch):
    """extract_model_id uses auto-captured Bedrock data."""
    # Mock the bedrock instrumentation functions
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "get_captured_model_data", lambda: {"model_id": "captured-model"})
    
    model = extract_model_id({}, {})
    assert model == "captured-model"


def test_extract_usage_partial_response_metadata(monkeypatch):
    """extract_usage handles partial response_metadata from bedrock."""
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(
        llm,
        "get_captured_model_data",
        lambda: {"response_metadata": {"input_tokens": 10}},  # Only input_tokens
    )

    usage = extract_usage({}, {})
    assert usage == {"input_tokens": 10}


def test_extract_usage_only_output_tokens_in_metadata(monkeypatch):
    """extract_usage handles only output_tokens in response_metadata."""
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(
        llm,
        "get_captured_model_data",
        lambda: {"response_metadata": {"output_tokens": 20}},
    )

    usage = extract_usage({}, {})
    assert usage == {"output_tokens": 20}


def test_track_llm_call_with_custom_input_callable():
    """track_llm_call with custom input callable executes successfully."""
    TraceManager.start_trace(name="custom_input_trace")

    def custom_input_extractor(args, kwargs):
        return f"Custom: {args[0]}"

    @track_llm_call(input=custom_input_extractor)
    def llm_with_custom_input(prompt):
        return {"choices": [{"message": {"content": "response"}}]}

    result = llm_with_custom_input("test prompt")
    assert result["choices"][0]["message"]["content"] == "response"
    # Verify span was created
    span = TraceManager._active["spans"][-1]
    assert span.span_name == "llm_with_custom_input"
    assert span.span_type == "generation"


def test_track_llm_call_with_custom_output_callable():
    """track_llm_call with custom output callable executes successfully."""
    TraceManager.start_trace(name="custom_output_trace")

    def custom_output_extractor(args, kwargs, result):
        return f"Extracted: {result.get('data', 'none')}"

    @track_llm_call(output=custom_output_extractor)
    def llm_with_custom_output():
        return {"data": "result", "choices": [{"message": {"content": "ok"}}]}

    result = llm_with_custom_output()
    assert result["data"] == "result"
    # Verify span was created
    span = TraceManager._active["spans"][-1]
    assert span.span_name == "llm_with_custom_output"
    assert span.span_type == "generation"


def test_track_llm_call_async_captures_locals():
    """track_llm_call async captures local variables."""
    async def _runner():
        TraceManager.start_trace(name="async_locals_trace")

        @track_llm_call(capture_locals=["local_var"])
        async def async_llm_with_locals():
            local_var = "test_value"
            _ = local_var
            await asyncio.sleep(0)
            return {"choices": [{"message": {"content": "response"}}]}

        await async_llm_with_locals()
        span = TraceManager._active["spans"][-1]
        assert span.input_data is not None

    asyncio.run(_runner())


def test_track_llm_call_handles_frame_exception():
    """track_llm_call handles exception when inspecting frame."""
    TraceManager.start_trace(name="frame_error_trace")

    @track_llm_call(capture_locals=True)
    def llm_with_locals():
        return {"choices": [{"message": {"content": "ok"}}]}

    result = llm_with_locals()
    assert result["choices"][0]["message"]["content"] == "ok"


def test_extract_model_id_bedrock_capture_no_model_id(monkeypatch):
    """extract_model_id handles captured data without model_id."""
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "get_captured_model_data", lambda: {"operation": "InvokeModel"})
    
    model = extract_model_id({}, {"model": "fallback-model"})
    assert model == "fallback-model"


def test_build_input_data_capture_locals_true():
    """_build_input_data captures all locals when capture_locals=True."""
    args = ()
    kwargs = {}
    local_vars = {"var1": "value1", "var2": 42, "_private": "skip"}
    
    data = llm._build_input_data(args, kwargs, local_vars, capture_locals_spec=True)
    
    assert "locals" in data
    assert "var1" in data["locals"]
    assert "var2" in data["locals"]
    # Private vars should be filtered by safe_locals


def test_build_input_data_capture_self_no_dict():
    """_build_input_data handles self without __dict__."""
    args = (42,)  # First arg is not an object with __dict__
    kwargs = {}
    
    data = llm._build_input_data(args, kwargs, None, capture_locals_spec=False, capture_self_flag=True)
    
    # Should not crash, and self should not be in data
    assert "self" not in data


def test_build_input_data_capture_self_with_exception(monkeypatch):
    """_build_input_data handles exception during self serialization."""
    from llmops_observability.trace_manager import serialize_value
    
    class BadObj:
        def __init__(self):
            self.value = "test"
    
    # Mock serialize_value to raise an exception
    original_serialize = llm.serialize_value
    def bad_serialize(obj):
        if isinstance(obj, BadObj):
            raise RuntimeError("Cannot serialize")
        return original_serialize(obj)
    
    monkeypatch.setattr(llm, "serialize_value", bad_serialize)
    
    args = (BadObj(),)
    kwargs = {}
    
    # Should not raise, just skip self
    data = llm._build_input_data(args, kwargs, None, capture_locals_spec=False, capture_self_flag=True)
    # self should not be in data because serialization failed
    assert "self" not in data


def test_track_llm_call_extracts_prompt_from_kwargs():
    """track_llm_call extracts prompt from kwargs."""
    TraceManager.start_trace(name="prompt_kwargs_trace")

    @track_llm_call()
    def llm_call(**kwargs):
        return {"text": "response"}

    llm_call(prompt="my prompt here")
    span = TraceManager._active["spans"][-1]
    assert span.prompt == "my prompt here"


def test_track_llm_call_extracts_messages_from_kwargs():
    """track_llm_call extracts messages from kwargs when no prompt."""
    TraceManager.start_trace(name="messages_kwargs_trace")

    @track_llm_call()
    def llm_call(**kwargs):
        return {"text": "response"}

    messages = [{"role": "user", "content": "hello"}]
    llm_call(messages=messages)
    span = TraceManager._active["spans"][-1]
    # prompt is only extracted from known prompt-like fields
    assert span.prompt is None
    # messages are still present in input_data
    assert span.input_data is not None
    assert "messages" in str(span.input_data)


def test_track_llm_call_uses_metadata_model():
    """track_llm_call uses model from metadata if not in direct param."""
    TraceManager.start_trace(name="metadata_model_trace")

    @track_llm_call(metadata={"model": "metadata-model"})
    def llm_call():
        return {"text": "response"}

    llm_call()
    span = TraceManager._active["spans"][-1]
    assert span.model_id == "metadata-model"


def test_track_llm_call_no_usage_triggers_fallback():
    """track_llm_call uses fallback estimation when no usage in response."""
    TraceManager.start_trace(name="fallback_usage_trace")

    @track_llm_call()
    def llm_call(prompt):
        return {"text": "simple response without usage"}

    llm_call("test prompt")
    span = TraceManager._active["spans"][-1]
    # Usage should be estimated based on prompt and response
    assert span.usage is not None
    assert span.usage["total_tokens"] >= 0


def test_track_llm_call_async_error():
    """track_llm_call handles async function errors."""
    async def _runner():
        TraceManager.start_trace(name="async_error_trace")

        @track_llm_call()
        async def async_llm():
            await asyncio.sleep(0)
            raise RuntimeError("async error")

        try:
            await async_llm()
        except RuntimeError:
            pass

        span = TraceManager._active["spans"][-1]
        assert span.status == "error"
        assert "async error" in span.status_message

    asyncio.run(_runner())


def test_track_llm_call_async_without_trace():
    """track_llm_call async returns raw result when no active trace."""
    async def _runner():
        # Clear any active trace
        TraceManager._active["spans"] = []
        TraceManager._active["trace_id"] = None

        @track_llm_call()
        async def async_llm():
            return {"result": "ok"}

        result = await async_llm()
        assert result == {"result": "ok"}

    asyncio.run(_runner())


def test_track_llm_call_clears_bedrock_data(monkeypatch):
    """track_llm_call clears bedrock captured data after use."""
    cleared = {"called": False}
    
    def mock_clear():
        cleared["called"] = True
    
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "clear_captured_model_data", mock_clear)
    monkeypatch.setattr(llm, "get_captured_model_data", lambda: None)
    
    TraceManager.start_trace(name="clear_bedrock_trace")

    @track_llm_call()
    def llm_call():
        return {"text": "response"}

    llm_call()
    assert cleared["called"] is True


def test_ensure_instrumentation_enabled_auto_enables(monkeypatch):
    """_ensure_instrumentation_enabled auto-enables if available."""
    enabled = {"called": False}
    
    def mock_enable():
        enabled["called"] = True
    
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "enable_bedrock_instrumentation", mock_enable)
    monkeypatch.setattr(llm, "is_instrumentation_enabled", lambda: False)
    
    llm._ensure_instrumentation_enabled()
    assert enabled["called"] is True


def test_ensure_instrumentation_skips_if_already_enabled(monkeypatch):
    """_ensure_instrumentation_enabled skips if already enabled."""
    enabled = {"called": False}
    
    def mock_enable():
        enabled["called"] = True
    
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "enable_bedrock_instrumentation", mock_enable)
    monkeypatch.setattr(llm, "is_instrumentation_enabled", lambda: True)
    
    llm._ensure_instrumentation_enabled()
    assert enabled["called"] is False


def test_ensure_instrumentation_handles_exception(monkeypatch):
    """_ensure_instrumentation_enabled handles enable exception gracefully."""
    def mock_enable():
        raise RuntimeError("Failed to enable")
    
    monkeypatch.setattr(llm, "BEDROCK_INSTRUMENTATION_AVAILABLE", True)
    monkeypatch.setattr(llm, "enable_bedrock_instrumentation", mock_enable)
    monkeypatch.setattr(llm, "is_instrumentation_enabled", lambda: False)
    
    # Should not raise
    llm._ensure_instrumentation_enabled()
