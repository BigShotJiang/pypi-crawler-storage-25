This matters more than you think.

Include:

What MUSS is

Installation:

pip install muss

Example:

from muss.datasets import MussDataset
Small demo (important for PyPI users)