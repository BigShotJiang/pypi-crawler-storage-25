import hashlib
import json
from muss.providers.sentinel2_provider import Sentinel2Provider
from muss.providers.sentinel1_provider import Sentinel1Provider
from muss.processing.preprocessing import preprocess
from muss.processing.indices import compute_indices
from muss.tiling.chip_generator import generate_tiles
from muss.storage.cache_manager import CacheManager
# from muss.datasets.muss_dataset import MussDataset
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import random
from tqdm import tqdm

class MussBuilder:
    def __init__(self, config):
        self.config = config
        self.cache = CacheManager(config["cache"].get("dir", "./cache"))
        self.serializable_config = self._make_serializable(config)
        self.providers = {
            "sentinel2": Sentinel2Provider(),
            "sentinel1": Sentinel1Provider(),
        }
    def _make_serializable(self, obj):
        if isinstance(obj, dict):
            return {k: self._make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._make_serializable(v) for v in obj]
        elif hasattr(obj, "isoformat"):  # handles date/datetime
            return obj.isoformat()
        return obj
    def _hash(self, tile):
        key = json.dumps(
            {"config": self.serializable_config, "tile": tile},
            sort_keys=True
        )
        return hashlib.md5(key.encode()).hexdigest()


    def build_index(self):
        return generate_tiles(self.config["data"]["bbox"], self.config["tiling"]["tile_size"])

    def get_tile(self, tile):
        key = self._hash(tile)

        cached = self.cache.get(key)
        if cached is not None:
            return cached

        data = {}

        for modality in tqdm(self.config["data"]["modalities"], desc="Modalities", leave=False):
            provider = self.providers[modality]
            data[modality] = provider.get_data(tile, self.config)
            try:
                data[modality] = provider.get_data(tile, self.config)
            except Exception:
                data[modality] = None
        if any(v is None for v in data.values()):
            print("Skipping tile (missing modality)")
            return
        data = preprocess(data, self.config)
        data = compute_indices(data, self.config["data"].get("indices", []))

        self.cache.set(key, data)
        return data

# CLI entry
