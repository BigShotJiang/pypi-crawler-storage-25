# import os
# import xarray as xr
# import numpy as np


# class CacheManager:
#     def __init__(self, cache_dir):
#         self.cache_dir = cache_dir
#         os.makedirs(cache_dir, exist_ok=True)

#     def _path(self, key):
#         return os.path.join(self.cache_dir, f"{key}.zarr")

#     def get(self, key):
#         path = self._path(key)
#         if os.path.exists(path):
#             return xr.open_zarr(path)
#         return None

#     def set(self, key, ds):
#         import numpy as np

#         ds = ds.copy()

#         # print(ds)
#         # # 🔥 FIX 2: clean each variable
#         # for var in list(ds.data_vars):

#         #     da = ds[var]


#         #     # remove problematic coords
#         #     drop_coords = []
#         #     for c in da.coords:
#         #         if da.coords[c].dtype == object:
#         #             drop_coords.append(c)

#         #     if drop_coords:
#         #         print(f"[CACHE] Dropping coords for {var}: {drop_coords}")
#         #         da = da.drop_vars(drop_coords)

#         #     # ensure numeric dtype
#         #     if not np.issubdtype(da.dtype, np.number):
#         #         da = da.astype("float32")

#         #     ds[var] = da

#         # # 🔥 FIX 3: remove global object variables
#         # for var in list(ds.variables):
#         #     if ds[var].dtype == object:
#         #         print(f"[CACHE] Dropping object variable: {var}")
#         #         ds = ds.drop_vars(var)

#         # 🔥 FIX 4: final safety
#         # ds = ds.reset_coords(drop=True)

#         # save
#         self.cache.set(key, data)
#         # ds.to_zarr(self._path(key), mode="w")

import os
import json
import xarray as xr
import numpy as np

class CacheManager:
    def __init__(self, cache_dir):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    def _path(self, key):
        return os.path.join(self.cache_dir, str(key))

    def _sanitize_attrs(self, attrs):
        """Ensures all attributes are JSON serializable so Zarr doesn't crash."""
        sanitized = {}
        for k, v in attrs.items():
            try:
                # Test if JSON can handle it
                json.dumps(v)
                sanitized[k] = v
            except (TypeError, OverflowError):
                # If it fails (like RasterSpec), convert the object to a string representation
                sanitized[k] = str(v)
        return sanitized

    def _clean_xarray(self, obj):
        """Helper to clean object types and unserializable attributes."""
        if isinstance(obj, xr.Dataset):
            ds = obj.copy()
            
            # 1. Sanitize global attributes
            ds.attrs = self._sanitize_attrs(ds.attrs)

            # 2. Clean variables and their attributes
            for var in list(ds.variables):
                da = ds[var]
                da.attrs = self._sanitize_attrs(da.attrs) # Clean variable-level attrs

                if var in ds.data_vars:
                    # Remove problematic coordinates
                    drop_coords = [c for c in da.coords if da.coords[c].dtype == object]
                    if drop_coords:
                        da = da.drop_vars(drop_coords)
                    # Ensure numeric dtype
                    if not np.issubdtype(da.dtype, np.number):
                        da = da.astype("float32")
                    ds[var] = da

            # 3. Drop global object variables
            for var in list(ds.variables):
                if ds[var].dtype == object:
                    ds = ds.drop_vars(var)
                    
            return ds
            
        elif isinstance(obj, xr.DataArray):
            da = obj.copy()
            
            # Sanitize array attributes
            da.attrs = self._sanitize_attrs(da.attrs)
            
            # Sanitize coordinate attributes
            for coord in da.coords:
                da.coords[coord].attrs = self._sanitize_attrs(da.coords[coord].attrs)

            # Remove problematic coordinates
            drop_coords = [c for c in da.coords if da.coords[c].dtype == object]
            if drop_coords:
                da = da.drop_vars(drop_coords)
                
            # Ensure numeric dtype
            if not np.issubdtype(da.dtype, np.number):
                da = da.astype("float32")
                
            return da

        return obj

    def get(self, key):
        key_dir = self._path(key)
        
        if not os.path.exists(key_dir):
            return None

        cached_data = {}
        for item in os.listdir(key_dir):
            if item.endswith(".zarr"):
                modality = item.replace(".zarr", "")
                modality_path = os.path.join(key_dir, item)
                
                ds = xr.open_zarr(modality_path)
                
                # Unwrap DataArrays if they were wrapped in Datasets
                if "data" in ds.data_vars and len(ds.data_vars) == 1:
                    cached_data[modality] = ds["data"]
                else:
                    cached_data[modality] = ds
                    
        return cached_data if cached_data else None

    def set(self, key, data_dict):
        key_dir = self._path(key)
        os.makedirs(key_dir, exist_ok=True)

        for modality, obj in data_dict.items():
            cleaned_obj = self._clean_xarray(obj)
            modality_path = os.path.join(key_dir, f"{modality}.zarr")
            
            if isinstance(cleaned_obj, xr.DataArray):
                dataset_to_save = cleaned_obj.to_dataset(name="data")
            else:
                dataset_to_save = cleaned_obj
                
            dataset_to_save.to_zarr(modality_path, mode="w",zarr_format=2)