import os
from typing import Optional, Dict, Any

import torch
import xarray as xr
from torch.utils.data import Dataset


class MussDataset(Dataset):
    """
    MUSS Dataset for loading multimodal geospatial tiles from Zarr cache.

    Each sample:
        {
            "image": Tensor (C, H, W),
            "label": Tensor (...)  # optional
        }
    """

    def __init__(
        self,
        cache_dir: str,
        modalities: Optional[list] = None,
        transform: Optional[Any] = None,
        normalize: bool = True,
        include_label: bool = False,
    ):
        """
        Args:
            cache_dir (str): Path to Zarr cache directory
            modalities (list, optional): subset of modalities to load
            transform (callable, optional): transform function
            normalize (bool): apply normalization
            include_label (bool): whether to return labels
        """
        self.cache_dir = cache_dir
        print(os.listdir(cache_dir))
        self.files = sorted([
            os.path.join(cache_dir, f)
            for f in os.listdir(cache_dir)
            # if f.endswith(".zarr")
        ])

        if len(self.files) == 0:
            raise RuntimeError(f"No Zarr files found in {cache_dir}")

        self.modalities = modalities
        self.transform = transform
        self.normalize = normalize
        self.include_label = include_label

    def __len__(self):
        
        return len(self.files)

    def _load_zarr(self, path: str) -> xr.Dataset:
        return xr.open_zarr(path)

    def _to_tensor(self, ds: xr.Dataset) -> torch.Tensor:
        tensors = []

        for var in ds.data_vars:
            if self.modalities and var not in self.modalities:
                continue

            arr = ds[var].values  # (band, y, x)

            # ensure 3D
            if arr.ndim == 2:
                arr = arr[None, ...]

            tensor = torch.from_numpy(arr).float()
            tensors.append(tensor)

        if len(tensors) == 0:
            raise RuntimeError("No valid modalities found in dataset")

        # concatenate along channel dimension
        x = torch.cat(tensors, dim=0)

        return x

    def _normalize(self, x: torch.Tensor) -> torch.Tensor:
        # per-sample normalization
        mean = x.mean()
        std = x.std()

        if std == 0:
            return x

        return (x - mean) / (std + 1e-6)
    def __getitem__(self, idx):
        path = self.files[idx]

        try:
            ds = xr.open_zarr(path)

            if len(ds.data_vars) == 0:
                raise RuntimeError("Empty dataset")

            x = self._to_tensor(ds)
            x = torch.nan_to_num(x)

            if self.normalize:
                x = self._normalize(x)

            return {"image": x}

        except Exception as e:
            print(f"[SKIP] Bad tile: {path} | {e}")

            # 🔁 fallback to another sample
            return self.__getitem__((idx + 1) % len(self))
    # def __getitem__(self, idx: int) -> Dict[str, Any]:
    #     path = self.files[idx]

    #     # load dataset
    #     ds = self._load_zarr(path)

    #     # convert to tensor
    #     x = self._to_tensor(ds)

    #     # handle NaNs
    #     x = torch.nan_to_num(x)

    #     # normalize
    #     if self.normalize:
    #         x = self._normalize(x)

    #     sample = {"image": x}

    #     # optional label
    #     if self.include_label and "label" in ds:
    #         y = torch.from_numpy(ds["label"].values)
    #         sample["label"] = y

    #     # apply transform
    #     if self.transform:
    #         sample = self.transform(sample)

    #     return sample