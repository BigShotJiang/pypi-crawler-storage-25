import os
from typing import Optional, Any

import torch
import xarray as xr
from torch.utils.data import Dataset


class MussDataset(Dataset):
    def __init__(
        self,
        cache_dir: str,
        modalities: Optional[list] = None,
        transform: Optional[Any] = None,
        normalize: bool = True,
    ):
        self.cache_dir = cache_dir

        # ✅ each folder = one tile
        self.tiles = sorted([
            os.path.join(cache_dir, d)
            for d in os.listdir(cache_dir)
            if os.path.isdir(os.path.join(cache_dir, d))
        ])

        if len(self.tiles) == 0:
            raise RuntimeError(f"No tiles found in {cache_dir}")

        self.modalities = modalities
        self.transform = transform
        self.normalize = normalize

    def __len__(self):
        return len(self.tiles)

    def _load_modality(self, tile_path, modality):
        zarr_path = os.path.join(tile_path, f"{modality}.zarr")

        if not os.path.exists(zarr_path):
            return None

        try:
            da = xr.open_zarr(zarr_path)

            # 🔥 important: convert Dataset → DataArray if needed
            if isinstance(da, xr.Dataset):
                da = list(da.data_vars.values())[0]

            return da

        except Exception as e:
            print(f"[WARN] Failed loading {modality}: {e}")
            return None

    def _to_tensor(self, tile_path):
        tensors = []

        # if modalities not specified → load all available
        modalities = self.modalities
        if modalities is None:
            modalities = [
                f.replace(".zarr", "")
                for f in os.listdir(tile_path)
                if f.endswith(".zarr")
            ]

        for modality in modalities:
            da = self._load_modality(tile_path, modality)

            if da is None:
                continue

            arr = da.values  # (band, y, x) OR (y, x)

            if arr.ndim == 2:
                arr = arr[None, ...]

            tensor = torch.from_numpy(arr).float()
            tensors.append(tensor)

        if len(tensors) == 0:
            raise RuntimeError("No valid modalities found in dataset")

        x = torch.cat(tensors, dim=0)
        return x

    def _normalize(self, x):
        mean = x.mean()
        std = x.std()

        if std == 0:
            return x

        return (x - mean) / (std + 1e-6)

    def __getitem__(self, idx):
        tile_path = self.tiles[idx]

        try:
            x = self._to_tensor(tile_path)
            x = torch.nan_to_num(x)

            if self.normalize:
                x = self._normalize(x)

            if self.transform:
                x = self.transform(x)

            return {"image": x}

        except Exception as e:
            print(f"[SKIP] {tile_path}: {e}")
            return self.__getitem__((idx + 1) % len(self))