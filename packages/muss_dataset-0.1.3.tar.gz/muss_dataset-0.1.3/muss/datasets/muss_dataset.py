import os
from typing import Optional, Dict, Any

import torch
import xarray as xr
import numpy as np

from torchgeo.datasets import NonGeoDataset
from torchgeo.datasets.utils import BoundingBox

from muss.builder.muss_builder import MussBuilder
import argparse, yaml
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import random
from tqdm import tqdm

# class MussDataset(NonGeoDataset):
#     """
#     MUSS TorchGeo-compatible Dataset

#     Features:
#     - Spatial indexing (TorchGeo style)
#     - Lazy tile building
#     - Zarr cache integration
#     - Multi-modal stacking (Sentinel-1 + Sentinel-2)
#     """

#     def __init__(
#         self,
#         config_file: str,
#         cache_dir: str = "./cache",
#         modalities: Optional[list] = None,
#         transforms: Optional[Any] = None,
#         normalize: bool = True,
#         mode: str = "lazy",  # "lazy" | "cache-only" | "prebuild"
#     ):
#         super().__init__()
#         print(config_file)
#         with open(config_file, "r") as f:
#             self.config  = yaml.safe_load(f)
#         print(type(self.config))
#         self.cache_dir = cache_dir
#         self.modalities = modalities
#         self.transforms = transforms
#         self.normalize = normalize
#         self.mode = mode

#         # 🔥 Builder
#         self.builder = MussBuilder(self.config )
#         self.cache = self.builder.cache

#         # 🔥 Build tile index
#         self.tiles = self.builder.build_index()

#         # 🔥 TorchGeo spatial index
#         self.index = []

#         for tile in self.tiles:
#             xmin, ymin, xmax, ymax = tile
#             bbox = BoundingBox(
#                 minx=xmin,
#                 maxx=xmax,
#                 miny=ymin,
#                 maxy=ymax,
#                 mint=0,
#                 maxt=1,
#             )
#             self.index.append(bbox)

#         # Optional prebuild
#         if self.mode == "prebuild":
#             for tile in self.tiles:
#                 self._ensure_tile(tile)

#     # ---------------------------------------------------
#     # 🔧 Core logic
#     # ---------------------------------------------------

#     def _tile_to_key(self, tile):
#         return self.builder._tile_to_key(tile)

#     def _ensure_tile(self, tile):
#         key = self._tile_to_key(tile)
#         ds = self.cache.get(key)

#         if ds is not None:
#             return ds

#         if self.mode == "cache-only":
#             raise RuntimeError(f"Tile {key} not in cache")

#         # 🔥 build tile
#         ds = self.builder.get_tile(tile)
#         return ds

#     # ---------------------------------------------------
#     # 🔄 TorchGeo required methods
#     # ---------------------------------------------------

#     def __len__(self):
#         return len(self.tiles)

#     def __getitem__(self, index: BoundingBox) -> Dict[str, torch.Tensor]:
#         """
#         TorchGeo expects a BoundingBox query
#         """

#         tile_path = self.tiles[idx]

#         try:
#             x = self._to_tensor(tile_path)
#             x = torch.nan_to_num(x)
#             x = self._fix_size(x, (256, 256))
#             if self.normalize:
#                 x = self._normalize(x)

#             if self.transform:
#                 x = self.transform(x)
#             # print(x.shape)
#             return {"image": x}

#         except Exception as e:
#             print(f"[SKIP] {tile_path}: {e}")
#             return self.__getitem__((idx + 1) % len(self))

#         # find matching tile
#         for tile, bbox in zip(self.tiles, self.index):
#             if self._intersects(bbox, query):
#                 ds = self._ensure_tile(tile)
#                 x = self._to_tensor(ds)

#                 if self.normalize:
#                     x = self._normalize(x)

#                 sample = {"image": x}

#                 if self.transforms:
#                     sample = self.transforms(sample)

#                 return sample

#         raise IndexError("No tile matches query")

#     # ---------------------------------------------------
#     # 🧠 Helpers
#     # ---------------------------------------------------

#     def _intersects(self, bbox1, bbox2):
#         return not (
#             bbox1.maxx < bbox2.minx
#             or bbox1.minx > bbox2.maxx
#             or bbox1.maxy < bbox2.miny
#             or bbox1.miny > bbox2.maxy
#         )

#     def _load_zarr(self, path):
#         return xr.open_zarr(path)

#     def _to_tensor(self, ds: Dict[str, xr.DataArray]) -> torch.Tensor:
#         """
#         ds format:
#         {
#             "sentinel2": DataArray,
#             "sentinel1": DataArray,
#             "ndvi": DataArray
#         }
#         """
#         tensors = []

#         for name, da in ds.items():
#             if self.modalities and name not in self.modalities:
#                 continue

#             arr = da.values  # (band, y, x) or (y, x)

#             if arr.ndim == 2:
#                 arr = arr[None, ...]

#             tensor = torch.from_numpy(arr).float()
#             tensors.append(tensor)

#         if len(tensors) == 0:
#             raise RuntimeError("No valid modalities found")

#         x = torch.cat(tensors, dim=0)

#         # 🔥 ensure consistent shape (pad if needed)
#         x = self._pad_to_fixed(x, size=256)

#         return x

#     def _pad_to_fixed(self, x, size=224):
#         _, h, w = x.shape

#         pad_h = max(0, size - h)
#         pad_w = max(0, size - w)

#         x = torch.nn.functional.pad(
#             x,
#             (0, pad_w, 0, pad_h),
#             mode="constant",
#             value=0,
#         )

#         return x[:, :size, :size]

#     def _normalize(self, x: torch.Tensor) -> torch.Tensor:
#         mean = x.mean()
#         std = x.std()

#         if std == 0:
#             return x

#         return (x - mean) / (std + 1e-6)


# import os
# from typing import Optional, Any

# import torch
# import xarray as xr
# from torch.utils.data import Dataset
import torch.nn.functional as F


class MussDataset(NonGeoDataset):
    def __init__(
        self,
        config_file: str,
        cache_dir: str = "./cache",
        modalities: Optional[list] = None,
        transform: Optional[Any] = None,
        normalize: bool = True,
        mode: str = "prebuild",  # "lazy" | "cache-only" | "prebuild"
    ):
        with open(config_file, "r") as f:
            self.config  = yaml.safe_load(f)
        self.builder = MussBuilder(self.config)
        self.cache = self.builder.cache

        self.mode=mode

        if self.mode == "cache":
            self.tiles = [
                d for d in os.listdir(cache_dir)
                if os.path.isdir(os.path.join(cache_dir, d))
            ]

        elif self.mode == "lazy":
            self.tiles = self.builder.build_index()

        elif self.mode == "prebuild":
            self.tiles = self.builder.build_index()

            for tile in tqdm(self.tiles):
                self.builder.get_tile(tile)

            self.tiles = [
                d for d in os.listdir(cache_dir)
                if os.path.isdir(os.path.join(cache_dir, d))
            ]
            self.mode="cache"


        # self.tiles = self.builder.build_index()
        # for tile in tqdm(self.tiles, desc="Building tiles"):
        #     self.builder.get_tile(tile)
        # self.cache_dir = cache_dir
        # # ✅ each folder = one tile
        # self.tiles = sorted([
        #     d
        #     for d in os.listdir(cache_dir)
        #     if os.path.isdir(os.path.join(cache_dir, d))
        # ])
        # print(self.tiles)

        # if len(self.tiles) == 0:
        #     raise RuntimeError(f"No tiles found in {cache_dir}")

        self.modalities = modalities
        self.transform = transform
        self.normalize = normalize

    def _tile_to_key(self, tile):
        return self.builder._hash(tile)

    def _ensure_tile(self, tile):
        key = self._tile_to_key(tile)
        ds = self.cache.get(key)

        if ds is not None:
            return ds

        if self.mode == "cache-only":
            raise RuntimeError(f"Tile {key} not in cache")

        # 🔥 build tile
        ds = self.builder.get_tile(tile)
        return ds
    def __len__(self):
        return len(self.tiles)

    def _load_modality(self, tile_path, modality):
        zarr_path = os.path.join(tile_path, f"{modality}.zarr")

        if not os.path.exists(zarr_path):
            return None

        try:
            da = xr.open_zarr(zarr_path)

            # 🔥 important: convert Dataset → DataArray if needed
            if isinstance(da, xr.Dataset):
                da = list(da.data_vars.values())[0]

            return da

        except Exception as e:
            print(f"[WARN] Failed loading {modality}: {e}")
            return None

    # def _to_tensor(self, tile_path):
    #     tensors = []

    #     # if modalities not specified → load all available
    #     modalities = self.modalities
    #     if modalities is None:
    #         modalities = [
    #             f.replace(".zarr", "")
    #             for f in os.listdir(tile_path)
    #             if f.endswith(".zarr")
    #         ]

    #     for modality in modalities:
    #         da = self._load_modality(tile_path, modality)

    #         if da is None:
    #             continue

    #         arr = da.values  # (band, y, x) OR (y, x)

    #         if arr.ndim == 2:
    #             arr = arr[None, ...]

    #         tensor = torch.from_numpy(arr).float()
    #         tensors.append(tensor)

    #     if len(tensors) == 0:
    #         raise RuntimeError("No valid modalities found in dataset")

    #     x = torch.cat(tensors, dim=0)
    #     return x

    def _to_tensor(self, data_dict):
        tensors = []

        for name, da in data_dict.items():

            if self.modalities and name not in self.modalities:
                continue

            if da is None:
                continue

            if isinstance(da, xr.Dataset):
                da = list(da.data_vars.values())[0]

            arr = da.values

            if arr.ndim == 2:
                arr = arr[None, ...]

            tensor = torch.from_numpy(arr).float()
            tensors.append(tensor)

        if len(tensors) == 0:
            raise RuntimeError("No valid modalities found")

        return torch.cat(tensors, dim=0)
    def _normalize(self, x):
        mean = x.mean()
        std = x.std()

        if std == 0:
            return x

        return (x - mean) / (std + 1e-6)
    def _fix_size(self, x, size=(256, 256)):
        _, h, w = x.shape

        target_h, target_w = size

        # crop if too big
        x = x[:, :target_h, :target_w]

        # recompute after crop
        _, h, w = x.shape

        # pad if too small
        pad_h = target_h - h
        pad_w = target_w - w

        if pad_h > 0 or pad_w > 0:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode="constant", value=0)

        return x
    def _pad_to_size(self, x, size=(256, 256)):
        _, h, w = x.shape
        pad_h = size[0] - h
        pad_w = size[1] - w

        if pad_h < 0 or pad_w < 0:
            return x[:, :size[0], :size[1]]

        return F.pad(x, (0, pad_w, 0, pad_h), mode="constant", value=0)

    def __getitem__(self, idx):
        tile_key = self.tiles[idx]

        try:
            data= self.builder.cache.get(tile_key)
            if data is None:
                if self.mode == "cache-only":
                    raise RuntimeError("Tile not in cache")

                data = self.builder.get_tile(tile_key)
            x = self._to_tensor(data)
            x = torch.nan_to_num(x)
            x = self._fix_size(x, (256, 256))
            if self.normalize:
                x = self._normalize(x)

            if self.transform:
                x = self.transform(x)
            # print(x.shape)
            return {"image": x}

        except Exception as e:
            print(f"[SKIP] {tile_key}: {e}")
            return self.__getitem__((idx + 1) % len(self))

def main():
    

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    # with open(args.config) as f:
    #     config = yaml.safe_load(f)

    # builder = MussBuilder(config)
    # tiles = builder.build_index()
    # for tile in tqdm(tiles, desc="Building tiles"):
    #     # print(f"Processing tile ")
    #     builder.get_tile(tile)


    dataset = MussDataset(config_file=r"./muss/configs/config.yaml"
        # cache_dir="/home/crm/pfe-nayera/works/MUSS/muss/cache",
        # modalities=["sentinel2", "sentinel1"],  # optional
        # normalize=True
    )

    loader = DataLoader(
        dataset,
        batch_size=8,
        shuffle=True,
        num_workers=4
    )

    for batch in loader:
        x = batch["image"]
        print(x.shape)  # (B, C, H, W)
        break
    

    print("Shape:", x.shape)

    # pick random band
    band_idx = random.randint(0, x.shape[1] - 1)

    img = x[1][band_idx].numpy()

    plt.imshow(img, cmap="gray")
    plt.title(f"Band {band_idx}")
    plt.colorbar()

    plt.savefig("sample.png")
    plt.close()