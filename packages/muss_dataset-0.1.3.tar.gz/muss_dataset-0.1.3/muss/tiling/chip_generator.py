import geopandas as gpd
from shapely.geometry import box


def generate_tiles(bbox, tile_size):
    xmin, ymin, xmax, ymax = bbox

    tiles = []
    x = xmin

    while x < xmax:
        y = ymin
        while y < ymax:
            geom = box(x, y, x + tile_size, y + tile_size)
            tiles.append(geom.bounds)
            y += tile_size
        x += tile_size

    return tiles