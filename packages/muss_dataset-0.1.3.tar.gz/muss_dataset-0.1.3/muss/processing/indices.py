import numpy as np


def compute_indices(data, indices):
    if "NDVI" in indices and "sentinel2" in data:
        s2 = data["sentinel2"]

        red = s2.sel(band="B04")
        nir = s2.sel(band="B08")

        ndvi = (nir - red) / (nir + red + 1e-6)

        data["ndvi"] = ndvi.expand_dims("band")

    return data