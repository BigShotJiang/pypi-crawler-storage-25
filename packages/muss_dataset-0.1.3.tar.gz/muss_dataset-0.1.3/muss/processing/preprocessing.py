# from muss.processing.temporal import temporal_composite
# import rioxarray 
# from tqdm import tqdm

# def preprocess(data, config):
#     out = {}

#     for k, stack in tqdm(data.items(), desc="Preprocessing", leave=False):
#         # 1. cloud masking
#         print('type stack.', type(stack))
#         if k == "sentinel2":
#             stack = stack  # apply mask if needed

#         # 2. temporal composite
#         # stack = temporal_composite(stack, config.get("temporal", "median"))
#         method = config["processing"]["temporal"]["method"]
#         stack = stack.median(dim="time") if "time" in stack.dims else stack
#         # 3. reprojection
#         stack = stack.rio.write_crs("EPSG:4326").rio.reproject(
#             config.get("crs", "EPSG:3857")
#         )

#         # 4. normalize
#         stack = stack / (stack.max() + 1e-6)

#         out[k] = stack

#     return out
import rioxarray

def preprocess(data, config):
    out = {}

    for k, stack in data.items():

        # print(f"type stack: {type(stack)}, dims: {getattr(stack, 'dims', None)}")

        # ✅ STEP 1: temporal composite FIRST
        if "time" in stack.dims:
            method = config["processing"]["temporal"]["method"]

            if method == "median":
                stack = stack.median(dim="time",skipna=True)
            elif method == "mean":
                stack = stack.mean(dim="time",skipna=True)
            elif method == "max":
                stack = stack.max(dim="time",skipna=True)
        stack = stack.compute()
        # ✅ STEP 2: handle NaNs
        stack = stack.fillna(0)

        # ✅ STEP 3: ensure spatial dims
        stack = stack.rio.set_spatial_dims(x_dim="x", y_dim="y", inplace=False)

        # ✅ STEP 4: reproject (NOW SAFE)
        stack = stack.rio.write_crs("EPSG:4326").rio.reproject(
            config["processing"]["reprojection"]["target_crs"]
        )

        # ✅ STEP 5: normalize
        stack = stack / (stack.max() + 1e-6)

        out[k] = stack

    return out