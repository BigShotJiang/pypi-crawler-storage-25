# def temporal_composite(stack, method="median"):
#     if method == "median":
#         return stack.median(dim="time")
#     elif method == "mean":
#         return stack.mean(dim="time")
#     elif method == "max":
#         return stack.max(dim="time")
#     else:
#         raise ValueError(f"Unknown method {method}")
# import numpy as np

def temporal_composite(stack, method="median"):

    # # 🔥 FIX: handle numpy input
    # if isinstance(stack, np.ndarray):
    #     if method == "median":
    #         return np.median(stack, axis=0)
    #     elif method == "mean":
    #         return np.mean(stack, axis=0)
    #     elif method == "max":
    #         return np.max(stack, axis=0)
    #     return stack

    # normal xarray path
    if method == "median":
        return stack.median(dim="time")
    elif method == "mean":
        return stack.mean(dim="time")
    elif method == "max":
        return stack.max(dim="time")