# import pystac_client
# import planetary_computer
# import stackstac
# import xarray as xr


# class Sentinel2Provider:
#     def __init__(self):
#         self.catalog = pystac_client.Client.open(
#             "https://planetarycomputer.microsoft.com/api/stac/v1"
#         )

#     def search(self, tile, config):
#         xmin, ymin, xmax, ymax = tile

#         search = self.catalog.search(
#             collections=["sentinel-2-l2a"],
#             bbox=[xmin, ymin, xmax, ymax],
#             datetime=f"{config["data"]["time"]['start']}/{config["data"]["time"]['end']}",
#             query={"eo:cloud_cover": {"lt": config.get("max_cloud", 20)}},
#         )

#         items = list(search.get_items())
#         return planetary_computer.sign(items)

#     def get_data(self, tile, config):
#         items = self.search(tile, config)

#         if len(items) == 0:
#             raise RuntimeError("No data found")

#         stack = stackstac.stack(
#             items,
#             assets=["B02", "B03", "B04", "B08"],
#             resolution=config.get("resolution", 10),
#             bounds_latlon=tile,
#         )

#         return stack  # xarray DataArray

import pystac_client
import planetary_computer
import stackstac


class Sentinel2Provider:
    def __init__(self):
        self.catalog = pystac_client.Client.open(
            "https://planetarycomputer.microsoft.com/api/stac/v1"
        )

    def get_data(self, tile, config):
        xmin, ymin, xmax, ymax = tile

        search = self.catalog.search(
            collections=["sentinel-2-l2a"],
            bbox=[xmin, ymin, xmax, ymax],
            datetime=f"{config['data']['time']['start']}/{config['data']['time']['end']}",
            query={"eo:cloud_cover": {"lt": config["provider"]["sentinel2"]["cloud_cover"]}},
        )

        # ✅ correct flow
        search = planetary_computer.sign(search)
        items = []
        for item in list(search):
            try:
                valid = True

                for band in ["B02", "B03", "B04", "B08"]:
                    asset = item.assets.get(band)

                    # ❌ missing asset
                    if asset is None:
                        valid = False
                        break

                    # ❌ missing href
                    if not hasattr(asset, "href") or asset.href is None:
                        valid = False
                        break

                if valid:
                    items.append(item)

            except Exception:
                continue
        
        if len(items) == 0:
            raise RuntimeError("No STAC items found")
        items = items[:1]
        # print(items)

        stack = stackstac.stack(
            items,
            assets=["B02", "B03", "B04", "B08"],
            bounds_latlon=tile,
            resolution=config["data"]["resolution"],
            epsg=4326,
            errors_as_nodata=True, 
            snap_bounds=True,
            # reader_kwargs={"crs": "EPSG:4326"},
        )

        return stack