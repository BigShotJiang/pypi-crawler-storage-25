class BaseProvider:
    def get_data(self, tile, config):
        raise NotImplementedError