# # # import numpy as np
# # # from muss.providers.base_provider import BaseProvider


# # # # class Sentinel1Provider(BaseProvider):
# # # #     def get_data(self, tile, config):
# # # #         return np.random.rand(1, 256, 256)  # SAR mock
# # import pystac_client
# # import planetary_computer
# # import stackstac


# # class Sentinel1Provider:
# #     def __init__(self):
# #         self.catalog = pystac_client.Client.open(
# #             "https://planetarycomputer.microsoft.com/api/stac/v1"
# #         )

# #     def get_data(self, tile, config):
# #         xmin, ymin, xmax, ymax = tile

# #         search = self.catalog.search(
# #             collections=["sentinel-1-grd"],
# #             bbox=[xmin, ymin, xmax, ymax],
# #             datetime=f"{config['data']['time']['start']}/{config['data']['time']['end']}",
# #         )

# #         # ✅ sign STAC request
# #         search = planetary_computer.sign(search)

# #         # ⚠️ MUST convert properly
# #         items = []
# #         for item in list(search):
# #             try:
# #                 valid = True

# #                 for band in ["vv", "vh"]:
# #                     asset = item.assets.get(band)

# #                     # ❌ missing asset
# #                     if asset is None:
# #                         valid = False
# #                         break

# #                     # ❌ missing href
# #                     if not hasattr(asset, "href") or asset.href is None:
# #                         valid = False
# #                         break

# #                 if valid:
# #                     items.append(item)

# #             except Exception:
# #                 continue

# #         if len(items) == 0:
# #             raise RuntimeError("No Sentinel-1 STAC items found")
# #         items = items[:1]
# #         print("",items)
# #         # ✅ stack as xarray
# #         stack = stackstac.stack(
# #             items,
# #             assets=["vv", "vh"],  # ⚠️ lowercase in STAC!
# #             bounds_latlon=tile,
# #             resolution=config["data"]["resolution"],
# #             epsg=4326,
# #             errors_as_nodata=True, 
# #         )

# #         return stack
import pystac_client
import planetary_computer
import stackstac

class Sentinel1Provider:
    def __init__(self):
        self.catalog = pystac_client.Client.open(
            "https://planetarycomputer.microsoft.com/api/stac/v1"
        )

    def get_data(self, tile, config):
        xmin, ymin, xmax, ymax = tile

        # 🔥 FIX: Switch to the RTC collection (orthorectified & map-projected)
        search = self.catalog.search(
            collections=["sentinel-1-rtc"],
            bbox=[xmin, ymin, xmax, ymax],
            datetime=f"{config['data']['time']['start']}/{config['data']['time']['end']}",
        )

        # ✅ sign STAC request
        search = planetary_computer.sign(search)

        items = []
        for item in list(search):
            try:
                valid = True

                for band in ["vv", "vh"]:
                    asset = item.assets.get(band)

                    # ❌ missing asset
                    if asset is None:
                        valid = False
                        break

                    # ❌ missing href
                    if not hasattr(asset, "href") or asset.href is None:
                        valid = False
                        break

                if valid:
                    items.append(item)

            except Exception:
                continue

        if len(items) == 0:
            raise RuntimeError("No Sentinel-1 STAC items found")
            
        items = items[:1]
        
        # ✅ stack as xarray
        stack = stackstac.stack(
            items,
            assets=["vv", "vh"],  
            bounds_latlon=tile,
            resolution=config["data"]["resolution"],
            epsg=4326,
            errors_as_nodata=True, 
            snap_bounds=True 
        )

        return stack