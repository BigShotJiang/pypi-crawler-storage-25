import torch
from torchgeo.datasets import GeoDataset
from muss.builder.muss_builder import MussBuilder


class MUSSDataset(GeoDataset):
    def __init__(self, config):
        super().__init__()
        self.builder = MussBuilder(config)
        self.tiles = self.builder.build_index()

    def __len__(self):
        return len(self.tiles)

    def __getitem__(self, idx):
        tile = self.tiles[idx]
        data = self.builder.get_tile(tile)

        # merge modalities into single tensor
        tensors = []
        for v in data.values():
            tensors.append(torch.tensor(v, dtype=torch.float32))

        image = torch.cat(tensors, dim=0)


    def xarray_to_tensor(ds):
        arrays = []

        for var in ds.data_vars:
            arr = ds[var].values
            if arr.ndim == 2:
                arr = arr[None, ...]
            arrays.append(arr)

        return torch.tensor(
            np.concatenate(arrays, axis=0), dtype=torch.float32
        )

        return {
            "image": image,
            "bbox": torch.tensor(tile),
            "crs": "EPSG:4326",
        }