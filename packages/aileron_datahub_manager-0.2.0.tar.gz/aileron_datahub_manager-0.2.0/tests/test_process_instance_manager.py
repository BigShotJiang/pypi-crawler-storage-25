from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import InvalidEntityError, ProcessInstanceError

JOB_URN = "urn:li:dataJob:(urn:li:dataFlow:(airflow,orders_etl,PROD),transform)"
DS_IN = "urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"
DS_OUT = "urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_daily,PROD)"
DAG_RUN_URN = "urn:li:dataProcessInstance:orders_etl__2024-04-17"
TASK_RUN_URN = "urn:li:dataProcessInstance:orders_etl__2024-04-17__transform"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# make_urn
# ------------------------------------------------------------------

def test_make_urn_format():
    urn = DataHubManager.from_config.__func__ if False else None
    from aileron_datahub_manager.entities.process_instance import ProcessInstanceManager
    urn = ProcessInstanceManager.make_urn("orders_etl__2024-04-17")
    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"


# ------------------------------------------------------------------
# emit_start
# ------------------------------------------------------------------

def test_emit_start_returns_urn(manager):
    """emit_start가 DataProcessInstance URN을 반환해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"
    mock_instance.emit_process_start.assert_called_once()


def test_emit_start_with_job_urn(manager):
    """job_urn 전달 시 DataJobUrn 변환 후 template_urn으로 전달되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            job_urn=JOB_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["template_urn"] is not None
    assert str(call_kwargs["template_urn"]) == JOB_URN


def test_emit_start_with_inlets_outlets(manager):
    """inlets/outlets가 DatasetUrn 객체로 변환되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            inlets=[DS_IN],
            outlets=[DS_OUT],
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert len(call_kwargs["inlets"]) == 1
    assert str(call_kwargs["inlets"][0]) == DS_IN
    assert len(call_kwargs["outlets"]) == 1
    assert str(call_kwargs["outlets"][0]) == DS_OUT


def test_emit_start_with_parent_instance_urn(manager):
    """parent_instance_urn이 DataProcessInstanceUrn 객체로 변환되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            parent_instance_urn=DAG_RUN_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["parent_instance"] is not None
    assert str(call_kwargs["parent_instance"]) == DAG_RUN_URN


def test_emit_start_with_upstream_urns(manager):
    """upstream_urns가 DataProcessInstanceUrn 객체 목록으로 변환되어야 한다."""
    upstream = "urn:li:dataProcessInstance:orders_etl__2024-04-17__extract"
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            upstream_urns=[upstream],
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert len(call_kwargs["upstream_urns"]) == 1
    assert str(call_kwargs["upstream_urns"][0]) == upstream


def test_emit_start_missing_instance_id_raises(manager):
    """instance_id 없으면 InvalidEntityError."""
    with pytest.raises(InvalidEntityError):
        manager.process_instances.emit_start(
            instance_id="",
            orchestrator="airflow",
            cluster="PROD",
        )


def test_emit_start_missing_orchestrator_raises(manager):
    """orchestrator 없으면 InvalidEntityError."""
    with pytest.raises(InvalidEntityError):
        manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="",
            cluster="PROD",
        )


# ------------------------------------------------------------------
# silent 옵션 (emit_start)
# ------------------------------------------------------------------

def test_emit_start_silent_suppresses_exception(manager):
    """silent=True 시 GMS 오류가 발생해도 예외 없이 URN을 반환해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_start.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.emit_start(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            silent=True,
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"


def test_emit_start_silent_false_raises_on_error(manager):
    """silent=False(기본) 시 GMS 오류가 ProcessInstanceError로 raise되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_start.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        with pytest.raises(ProcessInstanceError):
            manager.process_instances.emit_start(
                instance_id="orders_etl__2024-04-17",
                orchestrator="airflow",
                cluster="PROD",
                silent=False,
            )


# ------------------------------------------------------------------
# emit_end
# ------------------------------------------------------------------

def test_emit_end_calls_emit_process_end(manager):
    """emit_end가 emit_process_end를 호출해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
        )

    mock_instance.emit_process_end.assert_called_once()
    call_kwargs = mock_instance.emit_process_end.call_args.kwargs
    from datahub.api.entities.dataprocess.dataprocess_instance import InstanceRunResult
    assert call_kwargs["result"] == InstanceRunResult.SUCCESS


def test_emit_end_invalid_result_raises(manager):
    """잘못된 result 값은 InvalidEntityError를 발생시켜야 한다."""
    with pytest.raises(InvalidEntityError, match="result"):
        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="INVALID_STATUS",
        )


def test_emit_end_all_result_values(manager):
    """SUCCESS / FAILURE / SKIPPED / UP_FOR_RETRY 모두 허용되어야 한다."""
    from datahub.api.entities.dataprocess.dataprocess_instance import InstanceRunResult

    result_map = {
        "SUCCESS": InstanceRunResult.SUCCESS,
        "FAILURE": InstanceRunResult.FAILURE,
        "SKIPPED": InstanceRunResult.SKIPPED,
        "UP_FOR_RETRY": InstanceRunResult.UP_FOR_RETRY,
    }

    for result_str, expected in result_map.items():
        with patch(
            "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
        ) as mock_cls:
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance

            manager.process_instances.emit_end(
                instance_id="orders_etl__2024-04-17",
                orchestrator="airflow",
                cluster="PROD",
                result=result_str,
            )

        call_kwargs = mock_instance.emit_process_end.call_args.kwargs
        assert call_kwargs["result"] == expected, f"{result_str} 매핑 실패"


def test_emit_end_silent_suppresses_exception(manager):
    """silent=True 시 emit_end 오류가 억제되어야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_instance.emit_process_end.side_effect = Exception("GMS down")
        mock_cls.return_value = mock_instance

        # 예외 없이 통과해야 함
        manager.process_instances.emit_end(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            silent=True,
        )


# ------------------------------------------------------------------
# run (start + end 한번에)
# ------------------------------------------------------------------

def test_run_calls_both_emit_start_and_end(manager):
    """run이 emit_process_start와 emit_process_end를 모두 호출해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance

        urn = manager.process_instances.run(
            instance_id="orders_etl__2024-04-17",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
        )

    assert urn == "urn:li:dataProcessInstance:orders_etl__2024-04-17"
    mock_instance.emit_process_start.assert_called_once()
    mock_instance.emit_process_end.assert_called_once()


def test_run_passes_parent_instance_to_start(manager):
    """run이 parent_instance_urn을 emit_start에 전달해야 한다."""
    with patch(
        "aileron_datahub_manager.entities.process_instance.DataProcessInstance"
    ) as mock_cls:
        mock_cls.return_value = MagicMock()

        manager.process_instances.run(
            instance_id="orders_etl__2024-04-17__transform",
            orchestrator="airflow",
            cluster="PROD",
            result="SUCCESS",
            parent_instance_urn=DAG_RUN_URN,
        )

    call_kwargs = mock_cls.call_args.kwargs
    assert call_kwargs["parent_instance"] is not None
    assert str(call_kwargs["parent_instance"]) == DAG_RUN_URN
