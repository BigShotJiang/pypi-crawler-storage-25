# aileron-datahub-manager

Aileron 플랫폼의 여러 마이크로서비스가 공통으로 사용하는 **DataHub Python 클라이언트 SDK**입니다.

---

## 만든 목적

DataHub 메타데이터를 관리하려면 `acryl-datahub` SDK의 저수준 API를 직접 다뤄야 합니다.  
각 마이크로서비스가 이를 개별적으로 구현하면 아래와 같은 문제가 발생합니다.

- **복잡한 URN 조립** — `urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)` 형식을 매번 직접 구성
- **저수준 Aspect 구성** — 스키마, 태그, 소유자, 리니지를 각각 별도 Aspect 객체로 emit
- **반복 코드** — 서버 연결 설정, 인증 토큰 처리를 서비스마다 중복 구현
- **컬럼 레벨 리니지** — 구조가 복잡하여 구현 난이도 높음

`aileron-datahub-manager`는 이러한 복잡성을 **한 곳에서 구현하고 공통 라이브러리로 제공**하여,  
각 마이크로서비스는 간단한 API 호출만으로 DataHub 메타데이터를 등록·관리할 수 있습니다.

---

## 설치

각 마이크로서비스 환경에 `acryl-datahub-hcc-patched`가 사전 설치되어 있어야 합니다.

```bash
pip install aileron-datahub-manager
```

또는 Git 저장소에서 직접 설치:

```bash
pip install git+https://github.com/wansik92/aileron-datahub-manager.git
```

---

## 빠른 시작

### 연결 설정

환경변수를 통해 연결 설정을 주입합니다.

```bash
export DATAHUB_SERVER=http://datahub-gms:8080
export DATAHUB_TOKEN=your_token_here   # 선택
```

```python
from aileron_datahub_manager import DataHubManager

manager = DataHubManager.from_env()
manager.test_connection()
```

또는 코드에서 직접 설정:

```python
from aileron_datahub_manager import DataHubManager
from aileron_datahub_manager.config import DataHubConfig

manager = DataHubManager.from_config(
    DataHubConfig(server="http://datahub-gms:8080", token="your_token")
)
```

---

## 엔티티 고유 키 (Unique Key)

각 엔티티는 아래 필드 조합이 URN(고유 식별자)을 결정합니다. `upsert`는 동일한 키로 호출하면 **업데이트**가 됩니다.

| 엔티티 | 고유 키 필드 | URN 예시 |
|--------|------------|---------|
| **Dataset** | `platform` + `name` + `env` | `urn:li:dataset:(urn:li:dataPlatform:hive,my_db.my_table,PROD)` |
| **DataFlow** | `orchestrator` + `flow_id` + `cluster` | `urn:li:dataFlow:(airflow,orders_etl,PROD)` |
| **DataJob** | `orchestrator` + `flow_id` + `job_id` + `cluster` | `urn:li:dataJob:(urn:li:dataFlow:(airflow,orders_etl,PROD),transform)` |
| **Container** | `platform` + `database` (+ `instance`) | `urn:li:container:{guid}` |
| **Tag** | `name` | `urn:li:tag:pii` |

> 같은 테이블이라도 `env`가 다르면 별개의 엔티티로 등록됩니다.

---

## 주요 기능

### 1. Dataset 관리

```python
# Dataset 등록 / 업데이트
urn = manager.datasets.upsert(
    platform="hive",
    name="my_db.my_table",
    env="PROD",
    display_name="주문 테이블",
    description="일별 주문 집계 테이블",
    schema_fields=[
        ("order_id", "long", "주문 ID"),
        ("amount",   "double", "주문 금액"),
        ("created_at", "timestamp"),
    ],
    owners=["urn:li:corpuser:alice"],
    tags=["finance", "pii"],
    properties={"team": "data-platform"},
)

# 조회 / 존재 확인 / 삭제
dataset = manager.datasets.get(urn)
exists  = manager.datasets.exists(urn)
manager.datasets.delete(urn)
```

### 2. 파이프라인 관리 (DataFlow / DataJob)

DataHub의 파이프라인 계층 구조를 관리합니다.

```
DataFlow (파이프라인 / DAG)
    └── DataJob (태스크 / Step)
```

```python
# DataFlow 등록
flow_urn = manager.pipelines.upsert_flow(
    orchestrator="airflow",
    flow_id="orders_etl",
    cluster="PROD",
    display_name="주문 ETL 파이프라인",
)

# DataJob 등록 (입출력 Dataset 리니지 포함)
job_urn = manager.pipelines.upsert_job(
    orchestrator="airflow",
    flow_id="orders_etl",
    job_id="transform_orders",
    cluster="PROD",
    input_datasets=["urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"],
    output_datasets=["urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_agg,PROD)"],
)
```

### 3. 실행 이력 관리 (DataProcessInstance)

DataJob의 실제 실행 건을 등록합니다.

```
DataFlow → DataJob → DataProcessInstance (실제 실행 건)
```

```python
import time

run_id = f"transform_orders__{int(time.time())}"

# 실행 시작
manager.process_instances.emit_start(
    instance_id=run_id,
    orchestrator="aileron-pipeline",   # 파이프라인 이름 자유롭게
    cluster="PROD",
    job_urn="urn:li:dataJob:(...)",
    inlets=["urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)"],
    outlets=["urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_daily,PROD)"],
    silent=True,
)

# 실행 종료
manager.process_instances.emit_end(
    instance_id=run_id,
    orchestrator="aileron-pipeline",
    cluster="PROD",
    result="SUCCESS",   # SUCCESS / FAILURE / SKIPPED / UP_FOR_RETRY
    silent=True,
)

# DAG run → Task run 계층 구조
dag_run_urn = manager.process_instances.emit_start(
    instance_id="orders_etl__2024-04-17",
    orchestrator="airflow",
    cluster="aileron-mwaa-prod",
    silent=True,
)
manager.process_instances.emit_start(
    instance_id="orders_etl__2024-04-17__transform",
    orchestrator="airflow",
    cluster="aileron-mwaa-prod",
    job_urn="urn:li:dataJob:(...)",
    parent_instance_urn=dag_run_urn,   # DAG run 아래 소속
    silent=True,
)

# 또는 완료된 실행을 한번에 소급 등록
manager.process_instances.run(
    instance_id=run_id,
    orchestrator="aileron-pipeline",
    cluster="PROD",
    result="SUCCESS",
    job_urn="urn:li:dataJob:(...)",
    inlets=[...],
    outlets=[...],
    start_timestamp_millis=1713312000000,
    end_timestamp_millis=1713312600000,
    silent=True,
)
```

### 5. 데이터 리니지

```python
# 테이블 레벨 리니지
manager.lineage.add_dataset_lineage(
    upstream="urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)",
    downstream="urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_agg,PROD)",
)

# 컬럼 레벨 리니지
manager.lineage.add_dataset_lineage(
    upstream="urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)",
    downstream="urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_agg,PROD)",
    column_lineage={
        "urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)": {
            "total_amount": ["price", "quantity"],
        }
    },
)

# 배치 등록
manager.lineage.add_dataset_lineage_batch([
    ("urn:li:dataset:(...,source_a,PROD)", "urn:li:dataset:(...,target,PROD)"),
    ("urn:li:dataset:(...,source_b,PROD)", "urn:li:dataset:(...,target,PROD)"),
])

# 업스트림 / 다운스트림 조회
upstreams   = manager.lineage.get_dataset_upstreams(urn, max_hops=2)
downstreams = manager.lineage.get_dataset_downstreams(urn)
```

### 6. Container 관리

Dataset을 데이터베이스/스키마 단위로 그룹화합니다.

```python
# Database Container 등록
db_urn = manager.containers.upsert_database(
    platform="hive",
    database="my_db",
    description="주문 관련 데이터베이스",
    owners=["urn:li:corpuser:alice"],
)

# Dataset을 Container에 소속시키기
manager.datasets.upsert(
    platform="hive",
    name="my_db.my_table",
    env="PROD",
    parent_container=db_urn,
)
```

### 7. 태그 관리

```python
# 태그 사전 등록
manager.tags.upsert(
    name="pii",
    display_name="PII",
    description="개인식별정보가 포함된 데이터",
    color_hex="#FF0000",
)
```

---

## GMS 장애 격리 (silent 옵션)

GMS가 down되거나 오류가 발생해도 **기존 서비스 로직에 영향을 주지 않으려면** `silent=True`를 사용합니다.
모든 쓰기 작업(`upsert`, `delete`, `add_*`)에 지원됩니다.

```python
# GMS 오류 시 예외 raise (기본 동작)
manager.datasets.upsert(platform="hive", name="db.table", env="PROD")

# GMS 오류 시 WARNING 로그만 남기고 계속 진행
manager.datasets.upsert(platform="hive", name="db.table", env="PROD", silent=True)
manager.lineage.add_dataset_lineage(upstream=..., downstream=..., silent=True)
manager.pipelines.upsert_job(..., silent=True)
```

| 상황 | `silent=False` (기본) | `silent=True` |
|------|----------------------|---------------|
| GMS 정상 | INFO 로그 + 정상 반환 | INFO 로그 + 정상 반환 |
| GMS 오류 | 예외 raise | WARNING 로그 + 정상 반환 |

---

## 환경변수

| 변수명            | 필수 | 설명                                      |
|-----------------|:---:|------------------------------------------|
| `DATAHUB_SERVER` | O   | DataHub GMS 서버 URL (예: `http://datahub-gms:8080`) |
| `DATAHUB_TOKEN`  | -   | 인증 토큰 (인증이 필요한 환경에서 사용)          |

---

## URN 직접 생성

각 매니저는 URN 헬퍼 메서드를 제공합니다.

```python
dataset_urn = manager.datasets.make_urn("hive", "my_db.my_table", env="PROD")
flow_urn    = manager.pipelines.make_flow_urn("airflow", "orders_etl", cluster="PROD")
job_urn     = manager.pipelines.make_job_urn("airflow", "orders_etl", "transform_orders", cluster="PROD")
db_urn      = manager.containers.make_database_urn("hive", "my_db")
```

---

## 예외 처리

```python
from aileron_datahub_manager.exceptions import (
    ConnectionError,       # 서버 연결 실패
    EntityNotFoundError,   # 엔티티 없음
    InvalidEntityError,    # 잘못된 입력값
    LineageError,          # 리니지 등록 실패
)

try:
    manager.datasets.get("urn:li:dataset:(...)")
except EntityNotFoundError as e:
    print(f"엔티티를 찾을 수 없습니다: {e}")
```

---

## 개발

```bash
# 의존성 설치
pip install -e ".[dev]"

# 테스트 실행
pytest
```

---

## 버전

현재 버전: **0.1.9**  
Python 요구사항: `>=3.10`
