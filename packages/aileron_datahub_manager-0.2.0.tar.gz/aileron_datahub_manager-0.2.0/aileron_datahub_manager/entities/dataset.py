from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

from datahub.metadata.urns import DatasetUrn, TagUrn
from datahub.sdk.dataset import Dataset

from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)

# (column_name, native_type) 또는 (column_name, native_type, description)
SchemaFieldTuple = Tuple[str, str] | Tuple[str, str, str]


class DatasetManager:
    """Dataset 엔티티 생성·수정·조회 기능을 제공합니다."""

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # URN 헬퍼
    # ------------------------------------------------------------------

    def make_urn(self, platform: str, name: str, env: str) -> str:
        """DatasetUrn 문자열을 생성합니다.

        Args:
            platform: 플랫폼 이름 (예: hive, snowflake, kafka)
            name:     데이터셋 이름 (예: my_db.my_table)
            env:      환경 (예: PROD, DEV, STAGING)

        Returns:
            urn:li:dataset:(urn:li:dataPlatform:{platform},{name},{env}) 형식의 문자열
        """
        return str(DatasetUrn(platform=platform, name=name, env=env))

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def upsert(
        self,
        platform: str,
        name: str,
        env: str,
        *,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        schema_fields: Optional[List[SchemaFieldTuple]] = None,
        owners: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        properties: Optional[Dict[str, str]] = None,
        parent_container: Optional[str] = None,
        silent: bool = False,
    ) -> str:
        """Dataset을 생성하거나 업데이트합니다.

        Args:
            platform:         데이터 플랫폼 (hive, snowflake, kafka 등)
            name:             데이터셋 전체 이름 (예: db.schema.table)
            env:              환경 (예: PROD, DEV, STAGING)
            display_name:     UI에 표시될 이름
            description:      설명
            schema_fields:    스키마 필드 목록. 각 항목은 (name, type) 또는 (name, type, description)
            owners:           소유자 URN 목록 (예: ["urn:li:corpuser:alice"])
            tags:             태그 목록 (예: ["pii", "finance"])
            properties:       커스텀 속성 key-value
            parent_container: 소속 Container URN (예: database, S3 bucket)
            silent:           True이면 GMS 오류 발생 시 예외를 raise하지 않고 로그만 남김

        Returns:
            생성된 Dataset의 URN 문자열
        """
        if not platform or not name:
            raise InvalidEntityError("platform과 name은 필수입니다.")

        urn = self.make_urn(platform, name, env)

        resolved_tags = (
            [t if t.startswith("urn:li:") else str(TagUrn(name=t)) for t in tags]
            if tags else None
        )

        dataset = Dataset(
            platform=platform,
            name=name,
            env=env,
            display_name=display_name,
            description=description,
            schema=schema_fields,  # type: ignore[arg-type]
            owners=owners,
            tags=resolved_tags,
            custom_properties=properties,
            parent_container=parent_container,
        )

        try:
            self._manager._sdk_client.entities.upsert(dataset)
            logger.info("Dataset upsert 완료: %s", urn)
        except Exception as exc:
            if silent:
                logger.warning("Dataset upsert 실패 (silent=True, 무시됨): %s — %s", urn, exc)
            else:
                raise
        return urn

    def get(self, urn: str) -> Dataset:
        """URN으로 Dataset을 조회합니다.

        Raises:
            EntityNotFoundError: 엔티티가 없을 때
        """
        try:
            entity = self._manager._sdk_client.entities.get(DatasetUrn.from_string(urn))
        except Exception as exc:
            raise EntityNotFoundError(urn) from exc
        if entity is None:
            raise EntityNotFoundError(urn)
        return entity  # type: ignore[return-value]

    def exists(self, urn: str) -> bool:
        """URN에 해당하는 Dataset이 존재하는지 확인합니다."""
        try:
            self.get(urn)
            return True
        except EntityNotFoundError:
            return False

    def delete(self, urn: str, *, hard: bool = False, silent: bool = False) -> None:
        """Dataset을 삭제합니다.

        Args:
            urn:    삭제할 Dataset URN
            hard:   True이면 하드 삭제, False이면 소프트 삭제 (기본값)
            silent: True이면 GMS 오류 발생 시 예외를 raise하지 않고 로그만 남김
        """
        try:
            self._manager._sdk_client.entities.delete(urn, hard=hard)
            logger.info("Dataset 삭제 완료 (hard=%s): %s", hard, urn)
        except Exception as exc:
            if silent:
                logger.warning("Dataset 삭제 실패 (silent=True, 무시됨): %s — %s", urn, exc)
            else:
                raise
