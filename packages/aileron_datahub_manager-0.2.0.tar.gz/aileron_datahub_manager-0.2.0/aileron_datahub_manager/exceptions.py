from __future__ import annotations


class DataHubManagerError(Exception):
    """aileron-datahub 기본 예외."""


class EntityNotFoundError(DataHubManagerError):
    """URN에 해당하는 엔티티를 찾을 수 없을 때."""

    def __init__(self, urn: str) -> None:
        super().__init__(f"엔티티를 찾을 수 없습니다: {urn}")
        self.urn = urn


class EntityAlreadyExistsError(DataHubManagerError):
    """이미 존재하는 엔티티를 중복 생성하려 할 때."""

    def __init__(self, urn: str) -> None:
        super().__init__(f"이미 존재하는 엔티티입니다: {urn}")
        self.urn = urn


class InvalidEntityError(DataHubManagerError):
    """잘못된 엔티티 정의 (필수 필드 누락 등)."""


class LineageError(DataHubManagerError):
    """리니지 등록/조회 실패."""


class ConnectionError(DataHubManagerError):
    """DataHub 서버 연결 실패."""


class ProcessInstanceError(DataHubManagerError):
    """DataProcessInstance 등록 실패."""
