from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Dict, List, Optional

from datahub.metadata.urns import DatasetUrn, DataJobUrn
from datahub.sdk.lineage_client import LineageResult

from aileron_datahub_manager.exceptions import LineageError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)

# { downstream_column: [upstream_columns] }
ColumnLineageMap = Dict[str, List[str]]


class LineageManager:
    """Dataset / DataJob 간 리니지(관계) 등록·조회 기능 제공."""

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # Dataset 리니지
    # ------------------------------------------------------------------

    def add_dataset_lineage(
        self,
        upstream: str,
        downstream: str,
        *,
        column_lineage: Optional[Dict[str, ColumnLineageMap]] = None,
        silent: bool = False,
    ) -> None:
        """두 Dataset 간 리니지를 등록합니다.

        Args:
            upstream:       업스트림 Dataset URN
            downstream:     다운스트림 Dataset URN
            column_lineage: 컬럼 레벨 리니지.
                            { upstream_urn: { downstream_col: [upstream_cols] } }

        Example::

            manager.lineage.add_dataset_lineage(
                upstream="urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)",
                downstream="urn:li:dataset:(urn:li:dataPlatform:hive,dw.orders_agg,PROD)",
                column_lineage={
                    "urn:li:dataset:(urn:li:dataPlatform:hive,raw.orders,PROD)": {
                        "total_amount": ["price", "quantity"],
                    }
                },
            )
        """
        try:
            lineage_client = self._manager._sdk_client.lineage
            if column_lineage:
                for up_urn, col_map in column_lineage.items():
                    lineage_client.add_lineage(
                        upstream=DatasetUrn.from_string(up_urn),
                        downstream=DatasetUrn.from_string(downstream),
                        column_lineage=col_map,
                    )
            else:
                lineage_client.add_lineage(
                    upstream=DatasetUrn.from_string(upstream),
                    downstream=DatasetUrn.from_string(downstream),
                )
            logger.info("Dataset 리니지 등록: %s → %s", upstream, downstream)
        except Exception as exc:
            if silent:
                logger.warning(
                    "Dataset 리니지 등록 실패 (silent=True, 무시됨): %s → %s — %s",
                    upstream, downstream, exc,
                )
            else:
                raise LineageError(
                    f"Dataset 리니지 등록 실패 ({upstream} → {downstream}): {exc}"
                ) from exc

    def add_dataset_lineage_batch(
        self,
        pairs: List[tuple[str, str]],
        *,
        silent: bool = False,
    ) -> None:
        """여러 Dataset 리니지를 한 번에 등록합니다.

        Args:
            pairs:  (upstream_urn, downstream_urn) 튜플 목록
            silent: True이면 GMS 오류 발생 시 예외를 raise하지 않고 로그만 남김
        """
        for upstream, downstream in pairs:
            self.add_dataset_lineage(upstream=upstream, downstream=downstream, silent=silent)

    def get_dataset_upstreams(
        self, urn: str, *, max_hops: int = 1
    ) -> List[LineageResult]:
        """Dataset의 업스트림 리니지를 조회합니다.

        Args:
            urn:      조회할 Dataset URN
            max_hops: 탐색할 최대 홉 수 (기본값 1)

        Returns:
            LineageResult 목록
        """
        results = self._manager._sdk_client.lineage.get_lineage(
            source_urn=DatasetUrn.from_string(urn),
            direction="upstream",
            max_hops=max_hops,
        )
        return results

    def get_dataset_downstreams(
        self, urn: str, *, max_hops: int = 1
    ) -> List[LineageResult]:
        """Dataset의 다운스트림 리니지를 조회합니다."""
        results = self._manager._sdk_client.lineage.get_lineage(
            source_urn=DatasetUrn.from_string(urn),
            direction="downstream",
            max_hops=max_hops,
        )
        return results

    # ------------------------------------------------------------------
    # DataJob 입출력 리니지
    # ------------------------------------------------------------------

    def add_job_io(
        self,
        job_urn: str,
        *,
        input_datasets: Optional[List[str]] = None,
        output_datasets: Optional[List[str]] = None,
        silent: bool = False,
    ) -> None:
        """DataJob의 입출력 Dataset 리니지를 등록합니다.

        Args:
            job_urn:         DataJob URN
            input_datasets:  입력 Dataset URN 목록
            output_datasets: 출력 Dataset URN 목록
            silent:          True이면 GMS 오류 발생 시 예외를 raise하지 않고 로그만 남김
        """
        if not input_datasets and not output_datasets:
            return

        try:
            lineage_client = self._manager._sdk_client.lineage
            lineage_client.add_datajob_lineage(
                datajob=DataJobUrn.from_string(job_urn),
                upstreams=[DatasetUrn.from_string(u) for u in (input_datasets or [])],
                downstreams=[DatasetUrn.from_string(u) for u in (output_datasets or [])],
            )
            logger.info(
                "DataJob 리니지 등록: %s (inputs=%d, outputs=%d)",
                job_urn,
                len(input_datasets or []),
                len(output_datasets or []),
            )
        except Exception as exc:
            if silent:
                logger.warning(
                    "DataJob 리니지 등록 실패 (silent=True, 무시됨): %s — %s", job_urn, exc
                )
            else:
                raise LineageError(
                    f"DataJob 입출력 리니지 등록 실패 ({job_urn}): {exc}"
                ) from exc
