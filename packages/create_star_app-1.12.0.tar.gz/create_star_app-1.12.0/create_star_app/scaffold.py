import subprocess
import shutil
from pathlib import Path
from string import Template

from create_star_app.config import ProjectConfig

NEXT_VERSION = "16.1.6"

# Locate the templates directory shipped with this package.
_TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"

# Files that live outside the server/ directory.
_ROOT_TARGETS = {
    "gitignore.tmpl": ".gitignore",
    "env.tmpl": "server/.env",
    "vscode_tasks.json.tmpl": ".vscode/tasks.json",
    "requirements.txt.tmpl": "server/requirements.txt",
    "pytest.ini.tmpl": "server/pytest.ini",
    "ARCHITECTURE.md.tmpl": "server/ARCHITECTURE.md",
    "DO_NOT_DO.md.tmpl": "server/DO_NOT_DO.md",
    "dumpProdDataToLocalDev.cmd.tmpl": "server/tools/dumpProdDataToLocalDev.cmd",
    "restoreLocalDev.cmd.tmpl": "server/tools/restoreLocalDev.cmd",
    "create_or_update_job.bat.tmpl": "server/tools/create_or_update_job.bat",
    "create_or_update_job.ps1.tmpl": "server/tools/create_or_update_job.ps1",
    "services___init__.py.tmpl": "server/services/__init__.py",
    "services___abstractService.py.tmpl": "server/services/__abstractService.py",
    "services___getIsProductionEnv.py.tmpl": "server/services/__getIsProductionEnv.py",
    "services___request.py.tmpl": "server/services/__request.py",
    "services_AllServices.py.tmpl": "server/services/AllServices.py",
    "services_exampleService.py.tmpl": "server/services/exampleService.py",
    # Next.js client (overlaid on top of create-next-app)
    "client_env.local.tmpl": "client/.env.local",
    "client_layout.tsx.tmpl": "client/app/layout.tsx",
    "client_page.tsx.tmpl": "client/app/page.tsx",
    "client_ServerContext.tsx.tmpl": "client/lib/ServerContext.tsx",
    "client_AuthContext.tsx.tmpl": "client/lib/AuthContext.tsx",
    "client_firebase.ts.tmpl": "client/lib/firebase.ts",
    "client_DevClickToComponent.tsx.tmpl": "client/app/components/DevClickToComponent.tsx",
    "client_RoleGuard.tsx.tmpl": "client/app/components/RoleGuard.tsx",
}


def create_project(config: ProjectConfig) -> None:
    """Scaffold a new project from templates using the given config."""
    base = Path.cwd()
    template_vars = config.to_template_vars()

    # Create target directories.
    dirs = [
        base / "server",
        base / "server" / "schemas",
        base / "server" / "tools",
        base / "server" / "services",
        base / ".vscode",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
        print(f"  [dir]  {d.relative_to(base)}/")

    # Scaffold Next.js client via create-next-app
    client_dir = base / "client"
    if not client_dir.exists():
        print()
        print(f"  Running create-next-app@{NEXT_VERSION}...")
        result = subprocess.run(
            f'echo No | npx create-next-app@{NEXT_VERSION} client '
            '--typescript --tailwind --eslint '
            '--app --no-src-dir --no-import-alias --no-turbopack --use-npm',
            cwd=str(base),
            shell=True,
        )
        if result.returncode != 0:
            print("  Warning: create-next-app failed. Client directory may be incomplete.")
        else:
            print("  Next.js app created successfully.")
            # Update package.json name to project name
            import json
            pkg_path = client_dir / "package.json"
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            pkg["name"] = config.projectName
            pkg_path.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")
            # Create additional directories for our overlay
            for d in ["app/api", "app/schemas", "lib"]:
                (client_dir / d).mkdir(parents=True, exist_ok=True)
            # Install MUI and Firebase dependencies
            print("  Installing MUI and Firebase dependencies...")
            subprocess.run(
                'npm install '
                '@emotion/cache @emotion/react @emotion/styled '
                '@mui/material @mui/icons-material '
                '@mui/x-data-grid @mui/x-date-pickers '
                'dayjs firebase',
                cwd=str(client_dir),
                shell=True,
            )
        print()
    else:
        print(f"  [skip] client/ already exists, skipping create-next-app")

    # Process every .tmpl file found in the templates directory.
    tmpl_files = sorted(_TEMPLATES_DIR.glob("*.tmpl"))
    if not tmpl_files:
        print("  Warning: no .tmpl files found in templates directory.")
        return

    for tmpl_path in tmpl_files:
        tmpl_name = tmpl_path.name                     # e.g. "app.py.tmpl"
        output_name = tmpl_name.removesuffix(".tmpl")   # e.g. "app.py"

        # Determine the output path.
        if tmpl_name in _ROOT_TARGETS:
            rel = Path(_ROOT_TARGETS[tmpl_name])
        else:
            rel = Path("server") / output_name

        dest = base / rel
        dest.parent.mkdir(parents=True, exist_ok=True)

        # Read, substitute, write.
        raw = tmpl_path.read_text(encoding="utf-8")
        rendered = Template(raw).safe_substitute(template_vars)
        dest.write_text(rendered, encoding="utf-8")

        print(f"  [file] {rel}")

    # Ensure project root has .git so AppCreator can find it.
    if not (base / ".git").exists():
        subprocess.run('git init', cwd=str(base), shell=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # Run AppCreator.py to generate app.py, ServerRequests.ts, etc.
    print("  Running AppCreator.py...")
    result = subprocess.run(
        'python AppCreator.py',
        cwd=str(base / "server"),
        shell=True,
    )
    if result.returncode != 0:
        print("  Warning: AppCreator.py failed. Run it manually: cd server && python AppCreator.py")
    else:
        print("  AppCreator.py completed successfully.")
    print()

    print()
    print("Project scaffolded successfully! Next steps:")
    print()
    print("  Backend:")
    print("    1. cd server")
    print("    2. python -m venv venv")
    print("    3. venv\\Scripts\\activate  (Windows)  or  source venv/bin/activate  (Mac/Linux)")
    print("    4. pip install -r requirements.txt")
    print("    5. python app.py")
    print()
    print("  Frontend:")
    print("    1. cd client")
    print("    2. Update lib/firebase.ts with your Firebase config")
    print("    3. npm run dev")
    print()
