# qolab

Classes and functions useful for the quantum optics lab: qolab.

Designed to run experimental hardware and data analysis with python.

The package `qolab` was started in April 2021 by Eugeniy E. Mikhailov
within Quantum Optics Lab (QOLab), which explains it name.

## Internal modules

- atoms: code relevant for atomic system
   - rubbidium: allows to do D1 and D2 lines of Rb spectra calculation
- data: data trace related code. Trace class can have 1d or 2D data with axis descriptions,
  meta information, and plotting. Contain save and load methods.
- feedback: PID related code
- file_utils: utilities to create a uniform file names with automatically incremental indices/file numbers;
  knows how to do data compression, and convert filenames to and from Windows or Unix representations
- gui: utilities to make web guis
- hardware: various hardware classes all inheriting from a basic class, so some configurations
  can be polled, saved, and loaded back to an instrument
    - daq
    - i_server: temperature controller from Newport
    - lockin
    - multimeter
    - power_supply
    - rf_generator
    - scope
    - spectrum_analyzer
    - slm: spacial light modulator
    - vacuum_gauge
- math: helper function to do spectrum analysis, smoothing and noise density calculations
- tableflow: like `make` utility for python data processing. Take data description in a table format and
  calculate set of outcomes *only* if they are missing. Can forcefully recalculate all
- tsdb: time series database logging. Useful class for slow changing settings or measurements which logs
  changes into a database (Prometheus or  Victoria Metrics)
   and can be plotted on the web with for example Grafana gui

## Installation

~~~~
pip install qolab
~~~~

or if you want webgui module working

~~~~
pip install qolab[webgui]
~~~~

## Build instructions

To build a python wheel package and put it in `./dist/` directory, run

~~~~~
flit build
~~~~~

