"""
Provide basic classes to operate Spatial Light Modulators
"""

from .bbb_slm import bbbSLM
from .slm import SLM, fakeSLM, stretch2mat
from .efficient_linalg import hadamard, matDotVec
from .spi import (
    loadSPIresults,
    saveSPIresults,
    reconstructPhysicalImageFromSPIresults,
    spi_hadamard,
)

__all__ = [
    "SLM",
    "fakeSLM",
    "bbbSLM",
    "stretch2mat",
    "loadSPIresults",
    "saveSPIresults",
    "reconstructPhysicalImageFromSPIresults",
    "spi_hadamard",
    "hadamard",
    "matDotVec",
]
