import numpy as np
from qolab.hardware.slm import bbbSLM as SLM
from qolab.hardware.slm import spi_hadamard, saveSPIresults

slm = SLM()
logPxlN = 16
slm.pxlsLogical = np.zeros((logPxlN, logPxlN), dtype=np.uint8)
slm.roi = slm.pxlsPhysical[
    0:320, 0:640
]  # for speed of recovery,  make it divisible by 2 in some power

spi_results = spi_hadamard(slm, method="positiveHalfHadamard")

fname = slm.getNextDataFile(extension="h5")
saveSPIresults(fname, spi_results)

print(f"Data saved to file: {fname}")
