# -*- coding: utf-8 -*-
import threading
##普通全局变量  请求结束后删除
VAR = threading.local()
HEADER = threading.local()
G = threading.local()



