from .common import *
def before_request():
    pass
class index:
    def index():
        return "默认模块"