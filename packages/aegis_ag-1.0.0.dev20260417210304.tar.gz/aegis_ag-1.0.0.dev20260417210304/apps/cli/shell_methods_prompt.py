"""Prompt-inspection helpers extracted from the CLI shell surface."""

from __future__ import annotations

from .runtime_snapshot import load_snapshot_session_context_epoch


def _append_frozen(self) -> None:
    epoch = load_snapshot_session_context_epoch(self.runtime, session_id=self.session_id)
    if epoch is None or not epoch.frozen:
        self._append_entry(
            "notice",
            "Frozen prompt",
            "\n".join(
                [
                    f"session_id: {self.session_id}",
                    "status: pending first turn",
                    "system prompt :: frozen_prefix",
                    "<not frozen yet>",
                    "",
                    "system prompt :: session_snapshot",
                    "<not frozen yet>",
                    "",
                    "user prompt :: base_turn_injections",
                    "<not frozen yet>",
                    "",
                    "system prompt (tool fallback) :: tool_schema",
                    "<not frozen yet>",
                ]
            ),
        )
        return
    lines = [
        f"session_id: {epoch.session_id}",
        f"frozen_at: {epoch.frozen_at.isoformat() if epoch.frozen_at is not None else '<unknown>'}",
        f"thread_focus: {epoch.thread_focus or '<empty>'}",
        f"frozen_skill_count: {epoch.frozen_skill_count}",
        f"frozen_tool_count: {epoch.frozen_tool_count}",
        "frozen_skill_ids:",
        *([f"- {skill_id}" for skill_id in epoch.frozen_skill_ids] or ["<empty>"]),
        "",
        "frozen_tool_ids:",
        *([f"- {tool_id}" for tool_id in epoch.frozen_tool_ids] or ["<empty>"]),
        "",
        "note: only the initial frozen sections are shown below; append-only session history is intentionally omitted.",
        "",
        "system prompt :: frozen_prefix",
        epoch.frozen_prefix or "<empty>",
        "",
        "system prompt :: session_snapshot",
        epoch.session_snapshot or "<empty>",
        "",
        "user prompt :: base_turn_injections",
        epoch.base_turn_injections or "<empty>",
        "",
        "system prompt (tool fallback) :: tool_schema",
        epoch.tool_schema or "<empty>",
    ]
    self._append_entry("notice", "Frozen prompt", "\n".join(lines))
