

=========
Changelog
=========




.. towncrier release notes start

6.20.0 (2026-04-30)
===================

Features
--------

- Add experimental bare bones core-metadata ([PEP 658](https://peps.python.org/pep-0658/), [PEP 714](https://peps.python.org/pep-0714/)) support with ``--enable-core-metadata`` command line option and ``mirror_provides_core_metadata`` mirror index option. Refs #1018

Bug Fixes
---------

- Update replica status when the replica is waiting for new serials using the streaming changelog endpoint.


6.19.3 (2026-04-13)
===================

Bug Fixes
---------

- Fix #1112: Parse simple JSON reply even with wrong content-type in reply if the body seems to contain JSON.

- Return stale project list for mirrors when the lock can't be acquired within the timeout.

- Fix importing of toxresults from devpi-server 6.5.0 to 6.9.0 where the wrong hash was stored.


6.19.2 (2026-03-17)
===================

Bug Fixes
---------

- Preserve log for documentation uploads in export.

- Any missing file on mirrors will be ignored during event processing as is already the case in other places.

- Use short timeout when project list is requested for ``has_project`` call on mirrors instead of the long one used for ``list_projects``. This prevents installers from timing out and retrying several times.

- Fix error handling for proxy requests from replica to primary.

Other Changes
-------------

- Removed limit of reported missing files for devpi-fsck.


6.19.1 (2026-02-09)
===================

Bug Fixes
---------

- Pin setuptools as pyramid still requires pkg_resources.

- Always allow replicas to access deleted releases to get the proper ``410 Gone`` instead of ``403 Forbidden`` when ``devpi-lockdown`` is in use.


6.19.0 (2026-02-06)
===================

Features
--------

- Add ``--autocreate-users`` server option.
  Automatically creates users that don't exist in devpi, but have successfully authenticated via an authentication plugin.
  A typical example of when to enable this would be when authenticating via an LDAP directory.
  Automatically created users do not have passwords, and have no password hash to prevent local authentication.

- Add ``replica-files-in-sync-at``, ``replica-init-queue-finished-at`` and ``replica-metadata-in-sync-at`` to status view, the existing ``replica-in-sync-at`` is now a combination of all three instead of just metadata.

- Warn when an unknown option is found in config file to detect typos. Be aware that some commands don't use all the options, that is why this only warns instead of exiting.

- Add new ``devpiserver_user_created`` hook which can be used to create default indexes or other setup for newly created users.

Bug Fixes
---------

- Fix ``+status`` json encoding errors by making sure the ``FatalResponse.url`` attribute is a string.

- Ignore existing unknown index options from uninstalled plugins when patching other options with ``+=`` and ``-=``.

- Fix removal with ``-=`` of index options with default values from ``devpiserver_indexconfig_defaults`` hooks.

- Fix #1110: a list for the ``listen`` option in a config file stopped working in 6.18.0.

