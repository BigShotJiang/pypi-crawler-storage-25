from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Literal

from ..logging import get_logger
from ..pipeline.heuristic_intent import classify_heuristic_intent


IntentLabel = Literal["benign", "neutral", "suspicious"]


@dataclass
class IntentOutput:
    label: IntentLabel
    score: float


class HeuristicIntentClassifier:
    """L2 intent signal using lightweight heuristics (no torch / sentence-transformers)."""

    def __init__(self) -> None:
        self._logger = get_logger(__name__)
        self._logger.info("Initializing HeuristicIntentClassifier (phrase-based L2)")

    def classify(self, text: str) -> IntentOutput:
        label, score = classify_heuristic_intent(text)
        return IntentOutput(label=label, score=score)


@lru_cache(maxsize=1)
def get_intent_classifier() -> HeuristicIntentClassifier:
    return HeuristicIntentClassifier()
