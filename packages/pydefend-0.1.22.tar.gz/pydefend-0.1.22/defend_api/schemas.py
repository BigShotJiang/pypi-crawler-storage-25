from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field


class ProviderName(str, Enum):
    DEFEND = "defend"
    CLAUDE = "claude"
    OPENAI = "openai"


class GuardAction(str, Enum):
    PASS = "pass"
    FLAG = "flag"
    BLOCK = "block"


class FinalAction(str, Enum):
    PASS = "PASS"
    LOG = "LOG"
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"


class NormalizationDiagnostics(BaseModel):
    raw: str
    normalized: str
    transformations: List[str] = Field(default_factory=list)
    latency_ms: Optional[int] = None


class IntentDecision(str, Enum):
    PASS_ = "PASS"
    CONTINUE = "CONTINUE"


class IntentDiagnostics(BaseModel):
    label: str
    score: float
    decision: IntentDecision
    latency_ms: Optional[int] = None


class RegexDecision(str, Enum):
    BLOCK = "BLOCK"
    FLAG = "FLAG"
    CONTINUE = "CONTINUE"


class RegexMatch(BaseModel):
    name: str
    category: str
    weight: float
    span: Optional[List[int]] = None
    snippet: Optional[str] = None


class RegexDiagnostics(BaseModel):
    score: float
    decision: RegexDecision
    matches: List[RegexMatch] = Field(default_factory=list)
    latency_ms: Optional[int] = None


class SessionDecision(str, Enum):
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"
    CONTINUE = "CONTINUE"


class SessionDiagnostics(BaseModel):
    decision: SessionDecision
    session_score: float
    peak_score: float
    turns: int
    latency_ms: Optional[int] = None


class DefendDiagnostics(BaseModel):
    is_injection: bool
    probability: float
    latency_ms: Optional[int] = None


class LayerDiagnostics(BaseModel):
    normalization: Optional[NormalizationDiagnostics] = None
    intent: Optional[IntentDiagnostics] = None
    regex: Optional[RegexDiagnostics] = None
    session: Optional[SessionDiagnostics] = None
    defend: Optional[DefendDiagnostics] = None


class GuardInputRequest(BaseModel):
    text: str
    session_id: Optional[str] = None


class GuardOutputRequest(BaseModel):
    text: str
    session_id: Optional[str] = None


class GuardResult(BaseModel):
    action: GuardAction
    session_id: str
    score: Optional[float] = None
    modules_triggered: List[str] = Field(default_factory=list)
    latency_ms: int = 0

    @property
    def blocked(self) -> bool:
        return self.action is GuardAction.BLOCK


