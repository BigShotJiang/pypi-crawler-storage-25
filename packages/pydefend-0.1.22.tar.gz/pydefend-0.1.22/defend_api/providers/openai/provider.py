from __future__ import annotations

import json
import time
from typing import Optional

import anyio
from openai import APIStatusError, OpenAI

from ...config import get_defend_config, get_settings
from ..base import BaseProvider, ProviderResult, ProviderUnavailableError
from ...modules.base import BaseModule


EVAL_SYSTEM_PROMPT = """
You are a module-driven security classifier for an LLM application guardrail system.
Analyze the following user input and determine if it violates any configured guard module.

{module_instructions}

- Only return "flag" or "block" when one or more configured modules are triggered.
- If no configured module is triggered, return "pass".
- modules_triggered must only contain configured module names that caused the decision.
- score reflects confidence in the action decision
- reason should be one short sentence
""".strip()


def _build_verdict_tool(allowed_module_names: set[str] | None) -> dict[str, object]:
    modules_items: dict[str, object] = {"type": "string"}
    if allowed_module_names:
        modules_items["enum"] = sorted(allowed_module_names)
    return {
        "type": "function",
        "function": {
            "name": "submit_guardrail_verdict",
            "description": "Submit guardrail decision with module attribution.",
            "parameters": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "action": {"type": "string", "enum": ["pass", "flag", "block"]},
                    "score": {"type": "number", "minimum": 0, "maximum": 1},
                    "reason": {"type": "string"},
                    "modules_triggered": {
                        "type": "array",
                        "items": modules_items,
                        "uniqueItems": True,
                    },
                },
                "required": ["action", "score", "reason", "modules_triggered"],
            },
        },
    }


class OpenAIProvider(BaseProvider):
    name = "openai"
    supports_modules = True

    def __init__(self) -> None:
        # Settings currently unused; keep init lightweight.
        self._client: Optional[OpenAI] = None
        # Default to a cheaper model unless overridden via `defend.config.yaml -> models.openai`.
        self._default_model = "gpt-4o-mini"
        self._api_key_env = "OPENAI_API_KEY"

    async def evaluate(
        self,
        text: str,
        session_id: Optional[str] = None,  # noqa: ARG002
        modules: list[BaseModule] | None = None,
        allowed_module_names: set[str] | None = None,
    ) -> ProviderResult:
        start = time.perf_counter()

        cfg = get_defend_config()
        model = (getattr(cfg, "models", None) and getattr(cfg.models, "openai", None)) or self._default_model

        module_instructions = ""
        if modules:
            fragments = [m.system_prompt() for m in modules]
            module_instructions = "\n\n".join(fragments)
            if allowed_module_names:
                allowed_modules_list = ", ".join(f'"{name}"' for name in sorted(allowed_module_names))
                module_instructions = (
                    f"{module_instructions}\n\n"
                    f"Configured module names (use only these exact names in modules_triggered): "
                    f"[{allowed_modules_list}]"
                )
        prompt_template = EVAL_SYSTEM_PROMPT

        settings = get_settings()
        max_input_tokens = int(getattr(settings, "OPENAI_MAX_INPUT_TOKENS", 0))
        if max_input_tokens > 0:
            # Approximate token cap. If you need exact token truncation, add tiktoken.
            max_chars = max_input_tokens * 4
            if len(text) > max_chars:
                text = text[:max_chars]

        try:
            if self._client is None:
                api_key = getattr(settings, "OPENAI_API_KEY", None)
                self._client = OpenAI(api_key=api_key) if api_key else OpenAI()

            def _call_openai() -> object:
                return self._client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": prompt_template.format(module_instructions=module_instructions)},
                        {"role": "user", "content": text},
                    ],
                    tools=[_build_verdict_tool(allowed_module_names)],
                    tool_choice={"type": "function", "function": {"name": "submit_guardrail_verdict"}},
                    max_tokens=512,
                )

            response = await anyio.to_thread.run_sync(_call_openai)
        except APIStatusError as exc:
            raise ProviderUnavailableError(f"openai API error: {exc}") from exc
        except Exception as exc:  # pragma: no cover - defensive
            raise ProviderUnavailableError(f"openai error: {exc}") from exc

        latency_ms = int((time.perf_counter() - start) * 1000)

        try:
            message = response.choices[0].message
            tool_calls = getattr(message, "tool_calls", None) or []
            if not tool_calls:
                raise ValueError("missing tool call")
            arguments = tool_calls[0].function.arguments
            payload = json.loads(arguments)
        except Exception as exc:  # pragma: no cover - defensive
            raise ProviderUnavailableError(f"openai invalid function arguments: {exc}") from exc

        action = payload.get("action")
        if action not in ("pass", "flag", "block"):
            raise ProviderUnavailableError(f"openai invalid action: {action}")

        score = payload.get("score")
        reason = payload.get("reason")
        raw_modules_triggered = payload.get("modules_triggered") or []
        modules_triggered = []
        if isinstance(raw_modules_triggered, list):
            modules_triggered = [m for m in raw_modules_triggered if isinstance(m, str)]
        if allowed_module_names is not None:
            modules_triggered = [m for m in modules_triggered if m in allowed_module_names]

        if not modules:
            action = "pass"
            reason = "module-driven provider requires configured modules for flag/block"
            modules_triggered = []
        elif action in ("flag", "block") and not modules_triggered:
            action = "pass"
            reason = "module-attributed trigger required for flag/block"

        return ProviderResult(
            action=action,
            provider=self.name,
            score=float(score) if isinstance(score, (int, float)) else None,
            reason=str(reason) if isinstance(reason, str) else None,
            modules_triggered=list(modules_triggered),
            latency_ms=latency_ms,
        )

