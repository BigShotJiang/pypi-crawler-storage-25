from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from ..guard_service import _sanitize_finite, guard_input_local, guard_output_local
from ..schemas import GuardInputRequest, GuardOutputRequest, GuardResult

router = APIRouter(prefix="/guard", tags=["guard"])


@router.post("/input", response_model=GuardResult)
async def guard_input(request: GuardInputRequest) -> JSONResponse:
    result = await guard_input_local(request)
    payload = _sanitize_finite(result.model_dump())
    return JSONResponse(content=payload)


@router.post("/output", response_model=GuardResult)
async def guard_output(request: GuardOutputRequest) -> JSONResponse:
    result = await guard_output_local(request)
    payload = _sanitize_finite(result.model_dump())
    return JSONResponse(content=payload)
