"""In-process guard evaluation (same logic as ``POST /v1/guard/*`` HTTP routes)."""

from __future__ import annotations

import math
import uuid
from typing import Any, Dict, Optional

from fastapi import HTTPException

from .config import DefendConfig, attach_defend_config, detach_defend_config, get_defend_config
from .guard_session import get_guard_session_store
from .modules import build_modules_from_specs
from .pipeline.orchestrator import run_pipeline
from .providers import get_provider
from .providers.base import ProviderUnavailableError
from .schemas import GuardAction, GuardInputRequest, GuardOutputRequest, GuardResult


def _sanitize_finite(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _sanitize_finite(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_finite(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj):
        return 0.0
    return obj


def _map_final_action_to_guard_action(final_action: Any) -> GuardAction:
    value = getattr(final_action, "value", None)
    if value == "BLOCK":
        return GuardAction.BLOCK
    if value == "LOG":
        return GuardAction.FLAG
    return GuardAction.PASS


def _format_output_eval_text(output_text: str, input_context: Optional[Dict[str, Any]]) -> str:
    if not input_context or not input_context.get("text"):
        return output_text
    user_text = str(input_context.get("text", ""))
    return f"ORIGINAL_USER_INPUT:\n{user_text}\n\nLLM_RESPONSE:\n{output_text}"


async def _guard_input_impl(request: GuardInputRequest) -> GuardResult:
    if len(request.text) >= 20_000:
        raise HTTPException(status_code=413, detail="Input text too large")

    session_id = request.session_id or f"def-{uuid.uuid4().hex[:8]}"
    pipeline_result = await run_pipeline(request.text, session_id)
    store = await get_guard_session_store()
    context: Dict[str, Any] = {
        "text": request.text,
        "provider": pipeline_result.decided_by or "defend",
        "score": pipeline_result.score,
    }
    await store.save_input_context(session_id, context)

    action = _map_final_action_to_guard_action(pipeline_result.final_action)

    return GuardResult(
        action=action,
        session_id=session_id,
        score=pipeline_result.score,
        modules_triggered=pipeline_result.modules_triggered or [],
        latency_ms=pipeline_result.latency_ms or 0,
    )


async def guard_input_local(
    request: GuardInputRequest,
    *,
    defend_config: DefendConfig | None = None,
) -> GuardResult:
    """Run the input pipeline and persist session context (same as HTTP ``/guard/input``).

    When ``defend_config`` is set, it becomes the active policy for this call (and nested
    pipeline code) without reading ``defend.config.yaml``.
    """
    if defend_config is not None:
        token = attach_defend_config(defend_config)
        try:
            return await _guard_input_impl(request)
        finally:
            detach_defend_config(token)
    return await _guard_input_impl(request)


async def _guard_output_impl(request: GuardOutputRequest) -> GuardResult:
    config = get_defend_config()
    store = await get_guard_session_store()
    input_context = None

    if getattr(config.guards.output, "enabled", True) is False:
        session_id = request.session_id or f"def-{uuid.uuid4().hex[:8]}"
        return GuardResult(
            action=GuardAction.PASS,
            session_id=session_id,
            score=None,
            modules_triggered=[],
            latency_ms=0,
        )

    if request.session_id:
        input_context = await store.get_input_context(request.session_id)

    provider_name = config.output_provider
    provider = get_provider(provider_name)
    if provider_name.value == "defend" or not provider.supports_modules:
        raise HTTPException(
            status_code=400,
            detail="Output guarding requires an LLM provider (claude or openai).",
        )

    modules = build_modules_from_specs(config.guards.output.modules or [])
    modules = [m for m in modules if m.direction == "output"]
    allowed_module_names = {m.name for m in modules}
    eval_text = _format_output_eval_text(request.text, input_context)

    try:
        provider_result = await provider.evaluate(
            text=eval_text,
            session_id=request.session_id,
            modules=modules,
            allowed_module_names=allowed_module_names,
        )
        action = provider_result.action
        score = provider_result.score
        modules_triggered = provider_result.modules_triggered or []
        latency_ms = provider_result.latency_ms or 0
    except ProviderUnavailableError:
        action = config.guards.output.on_fail
        score = None
        modules_triggered = []
        latency_ms = 0

    session_id = request.session_id or f"def-{uuid.uuid4().hex[:8]}"

    return GuardResult(
        action=action,
        session_id=session_id,
        score=score,
        modules_triggered=modules_triggered,
        latency_ms=latency_ms,
    )


async def guard_output_local(
    request: GuardOutputRequest,
    *,
    defend_config: DefendConfig | None = None,
) -> GuardResult:
    """Run output evaluation (same as HTTP ``/guard/output``)."""
    if defend_config is not None:
        token = attach_defend_config(defend_config)
        try:
            return await _guard_output_impl(request)
        finally:
            detach_defend_config(token)
    return await _guard_output_impl(request)
