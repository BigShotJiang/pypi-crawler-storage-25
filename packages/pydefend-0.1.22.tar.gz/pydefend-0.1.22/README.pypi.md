# Defend (`pydefend`)

AI security guardrails for LLM applications.

- Guards input and output text with configurable modules.
- Preserves multi-turn context with `session_id`.
- Supports local (`defend`) and remote (`claude`/`openai`) evaluation providers.

## Install

```bash
pip install pydefend
```

For local classifier support:

```bash
pip install pydefend[local]
```

## Quick start

Create `defend.config.yaml`:

```yaml
provider: defend

guards:
  input:
    modules: []
  output:
    enabled: true
    modules: []
    on_fail: block
```

Run:

```bash
defend serve
```

Guard input:

```bash
curl -X POST http://localhost:8000/v1/guard/input \
  -H "Content-Type: application/json" \
  -d '{"text":"Hello"}'
```

Guard output:

```bash
curl -X POST http://localhost:8000/v1/guard/output \
  -H "Content-Type: application/json" \
  -d '{"text":"Model output","session_id":"YOUR_SESSION_ID"}'
```

## Documentation

- Full docs: [https://www.pydefend.com/docs](https://www.pydefend.com/docs)
- Source and guides: [https://github.com/Adxzer/defend](https://github.com/Adxzer/defend)
