"""Optional integrations with third-party frameworks (see `defend.integrations.langchain`)."""
