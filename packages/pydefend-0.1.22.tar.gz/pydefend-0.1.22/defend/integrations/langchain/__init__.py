"""LangChain integration: HTTP client and ``AgentMiddleware`` for the Defend guard API."""

from __future__ import annotations

from defend_api.config import DefendConfig, GuardsConfig, GuardsInputConfig, GuardsOutputConfig, ModelsConfig

from .client import DefendApiClient, coerce_defend_config, resolve_base_url, resolve_use_local
from .middleware import DefendAgentState, DefendGuardMiddleware
from .options import DefendGuardOptions, DefendHttpOptions, OnError

__all__ = [
    "DefendAgentState",
    "DefendApiClient",
    "DefendConfig",
    "DefendGuardMiddleware",
    "DefendGuardOptions",
    "DefendHttpOptions",
    "GuardsConfig",
    "GuardsInputConfig",
    "GuardsOutputConfig",
    "ModelsConfig",
    "OnError",
    "coerce_defend_config",
    "resolve_base_url",
    "resolve_use_local",
]
