"""Optional tuning for :class:`~defend.integrations.langchain.middleware.DefendGuardMiddleware`."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Sequence

OnError = Literal["raise", "pass"]


@dataclass(frozen=True, slots=True)
class DefendHttpOptions:
    """HTTP client settings when using a remote Defend API (ignored for in-process guarding)."""

    timeout: float = 30.0
    headers: dict[str, str] | None = None
    use_local: bool | None = None
    """If ``None``, use in-process guarding when no base URL is set; if ``False``, require a URL."""


@dataclass(frozen=True, slots=True)
class DefendGuardOptions:
    """Advanced behavior for :class:`DefendGuardMiddleware`. Omit this to use defaults."""

    http: DefendHttpOptions = field(default_factory=DefendHttpOptions)
    flag_as_block: bool = False
    on_error: OnError = "raise"
    guard_input: bool = True
    guard_output: bool = True
    blocked_input_reply: str = "This message was blocked by Defend input policy."
    blocked_output_reply: str = "This response was blocked by Defend output policy."
    extract_input_text: Callable[[Sequence[Any]], str | None] | None = None
    extract_output_text: Callable[[Sequence[Any]], str | None] | None = None
