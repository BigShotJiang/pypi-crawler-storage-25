from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from typing import Any, cast

from typing_extensions import Annotated

from defend_api.config import DefendConfig
from defend_api.schemas import GuardAction, GuardResult

from .client import DefendApiClient
from .options import DefendGuardOptions

logger = logging.getLogger(__name__)

try:
    from langchain.agents.middleware import AgentMiddleware, AgentState
    from langchain.agents.middleware.types import PrivateStateAttr, hook_config
    from langchain.messages import AIMessage, AnyMessage, HumanMessage
    from langgraph.runtime import Runtime
except ImportError as e:  # pragma: no cover - optional extra
    raise ImportError(
        "Install LangChain support with: pip install pydefend[langchain]"
    ) from e


class DefendAgentState(AgentState[Any]):
    """Agent state extended with a Defend session id for input/output guard pairing."""

    defend_session_id: NotRequired[Annotated[str | None, PrivateStateAttr]]


def _text_from_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
            elif isinstance(block, str):
                parts.append(block)
        return "".join(parts)
    return str(content)


def default_input_text(messages: Sequence[AnyMessage]) -> str | None:
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            return _text_from_message_content(msg.content) or None
    return None


def default_output_text(messages: Sequence[AnyMessage]) -> str | None:
    for msg in reversed(messages):
        if isinstance(msg, AIMessage):
            t = _text_from_message_content(msg.content)
            if t and str(t).strip():
                return t
    return None


def _effective_block(result: GuardResult, *, flag_as_block: bool) -> bool:
    if result.action is GuardAction.BLOCK:
        return True
    if flag_as_block and result.action is GuardAction.FLAG:
        return True
    return False


class DefendGuardMiddleware(AgentMiddleware[DefendAgentState, Any, Any]):
    """LangChain agent middleware that runs Defend input/output guarding.

    Typical usage: ``DefendGuardMiddleware()`` or ``DefendGuardMiddleware(config={...})``.
    Pass ``base_url`` (or set ``DEFEND_API_BASE_URL``) to call a remote API instead of
    in-process guarding.

    For timeouts, auth headers, block messages, or custom text extraction, pass
    :class:`DefendGuardOptions` as ``options``.
    """

    state_schema: type[DefendAgentState] = DefendAgentState

    def __init__(
        self,
        *,
        config: DefendConfig | Mapping[str, Any] | None = None,
        base_url: str | None = None,
        client: DefendApiClient | None = None,
        options: DefendGuardOptions | None = None,
    ) -> None:
        super().__init__()
        opts = options or DefendGuardOptions()
        self._owns_client = client is None
        self._client = client or DefendApiClient(
            config=config,
            base_url=base_url,
            http=opts.http,
        )
        self._flag_as_block = opts.flag_as_block
        self._on_error = opts.on_error
        self._guard_input = opts.guard_input
        self._guard_output = opts.guard_output
        self._blocked_input_reply = opts.blocked_input_reply
        self._blocked_output_reply = opts.blocked_output_reply
        self._extract_input = opts.extract_input_text or default_input_text
        self._extract_output = opts.extract_output_text or default_output_text

    @property
    def client(self) -> DefendApiClient:
        return self._client

    def _handle_error(self, exc: BaseException, phase: str) -> None:
        if self._on_error == "raise":
            raise exc
        logger.warning("Defend guard API error during %s: %s", phase, exc)

    @hook_config(can_jump_to=["end"])
    def before_model(
        self, state: DefendAgentState, runtime: Runtime[Any]
    ) -> dict[str, Any] | None:
        if not self._guard_input:
            return None
        messages = state.get("messages") or []
        text = self._extract_input(cast(Sequence[AnyMessage], messages))
        if not text:
            return None
        prev_sid = state.get("defend_session_id")
        try:
            result = self._client.guard_input(text, session_id=prev_sid)
        except Exception as e:
            self._handle_error(e, "input (sync)")
            return None
        if _effective_block(result, flag_as_block=self._flag_as_block):
            return {
                "messages": [AIMessage(content=self._blocked_input_reply)],
                "jump_to": "end",
            }
        return {"defend_session_id": result.session_id}

    @hook_config(can_jump_to=["end"])
    async def abefore_model(
        self, state: DefendAgentState, runtime: Runtime[Any]
    ) -> dict[str, Any] | None:
        if not self._guard_input:
            return None
        messages = state.get("messages") or []
        text = self._extract_input(cast(Sequence[AnyMessage], messages))
        if not text:
            return None
        prev_sid = state.get("defend_session_id")
        try:
            result = await self._client.aguard_input(text, session_id=prev_sid)
        except Exception as e:
            self._handle_error(e, "input (async)")
            return None
        if _effective_block(result, flag_as_block=self._flag_as_block):
            return {
                "messages": [AIMessage(content=self._blocked_input_reply)],
                "jump_to": "end",
            }
        return {"defend_session_id": result.session_id}

    def after_model(
        self, state: DefendAgentState, runtime: Runtime[Any]
    ) -> dict[str, Any] | None:
        if not self._guard_output:
            return None
        messages = state.get("messages") or []
        if not messages:
            return None
        text = self._extract_output(cast(Sequence[AnyMessage], messages))
        if not text:
            return None
        session_id = state.get("defend_session_id")
        try:
            result = self._client.guard_output(text, session_id=session_id)
        except Exception as e:
            self._handle_error(e, "output (sync)")
            return None
        if not _effective_block(result, flag_as_block=self._flag_as_block):
            return None
        last = messages[-1]
        if not isinstance(last, AIMessage):
            return None
        replacement = AIMessage(content=self._blocked_output_reply)
        rid = getattr(last, "id", None)
        if rid:
            replacement = AIMessage(content=self._blocked_output_reply, id=rid)
        return {"messages": [replacement]}

    async def aafter_model(
        self, state: DefendAgentState, runtime: Runtime[Any]
    ) -> dict[str, Any] | None:
        if not self._guard_output:
            return None
        messages = state.get("messages") or []
        if not messages:
            return None
        text = self._extract_output(cast(Sequence[AnyMessage], messages))
        if not text:
            return None
        session_id = state.get("defend_session_id")
        try:
            result = await self._client.aguard_output(text, session_id=session_id)
        except Exception as e:
            self._handle_error(e, "output (async)")
            return None
        if not _effective_block(result, flag_as_block=self._flag_as_block):
            return None
        last = messages[-1]
        if not isinstance(last, AIMessage):
            return None
        replacement = AIMessage(content=self._blocked_output_reply)
        rid = getattr(last, "id", None)
        if rid:
            replacement = AIMessage(content=self._blocked_output_reply, id=rid)
        return {"messages": [replacement]}
