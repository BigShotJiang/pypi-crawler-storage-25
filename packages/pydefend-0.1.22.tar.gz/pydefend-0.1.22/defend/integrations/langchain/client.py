from __future__ import annotations

import asyncio
import concurrent.futures
import os
from collections.abc import Mapping
from typing import Any, Optional, Union

import httpx

from defend_api.config import DefendConfig
from defend_api.guard_service import guard_input_local, guard_output_local
from defend_api.schemas import GuardInputRequest, GuardOutputRequest, GuardResult

from .options import DefendHttpOptions

DefendConfigInput = Union[DefendConfig, Mapping[str, Any]]


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def resolve_base_url(base_url: str | None) -> str:
    """Return a non-empty HTTP base URL from the argument or ``DEFEND_API_BASE_URL``."""
    raw = (base_url or os.environ.get("DEFEND_API_BASE_URL") or "").strip()
    if not raw:
        msg = (
            "Defend API base URL is required: pass base_url=..., set DEFEND_API_BASE_URL, "
            "or use in-process mode (omit both and do not set use_local=False in http options)."
        )
        raise ValueError(msg)
    return _normalize_base_url(raw)


def resolve_use_local(base_url: str | None, use_local: bool | None) -> bool:
    """Use the in-process pipeline when no HTTP base URL is configured.

    Local mode is the default when neither ``base_url`` nor ``DEFEND_API_BASE_URL`` is set.
    Set ``use_local=False`` in :class:`DefendHttpOptions` to require a remote URL.
    """
    if use_local is True:
        return True
    if use_local is False:
        return False
    if (base_url or "").strip():
        return False
    if (os.environ.get("DEFEND_API_BASE_URL") or "").strip():
        return False
    return True


def coerce_defend_config(config: DefendConfigInput | None) -> DefendConfig:
    """Return a ``DefendConfig`` instance (minimal defaults when ``config`` is None)."""
    if config is None:
        return DefendConfig.minimal()
    if isinstance(config, DefendConfig):
        return config
    return DefendConfig.model_validate(dict(config))


def _run_coro_sync(coro: Any) -> Any:
    """Run an async coroutine from sync code (may use a worker thread if a loop is running)."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    def _runner() -> Any:
        return asyncio.run(coro)

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(_runner).result()


class DefendApiClient:
    """Guard API client: HTTP to a Defend server, or in-process evaluation (no ``defend serve``).

    In **local** mode, pass ``config`` (or omit it to use :meth:`DefendConfig.minimal`) so policy
    is fully defined in Python—no ``defend.config.yaml`` required. Remote HTTP mode uses the
    server’s YAML; do not pass ``config`` in that case.

    Use :class:`DefendHttpOptions` for timeouts, auth headers, or transport overrides.
    """

    def __init__(
        self,
        *,
        config: DefendConfigInput | None = None,
        base_url: str | None = None,
        http: DefendHttpOptions | None = None,
    ) -> None:
        h = http or DefendHttpOptions()
        self._use_local = resolve_use_local(base_url, h.use_local)
        if not self._use_local:
            if config is not None:
                raise ValueError(
                    "config is only used for in-process guarding; omit it when using a remote "
                    "Defend API (base_url / DEFEND_API_BASE_URL)."
                )
            self._base_url = resolve_base_url(base_url)
            self._local_defend_config: DefendConfig | None = None
        else:
            self._base_url = ""
            self._local_defend_config = coerce_defend_config(config)
        self._timeout = h.timeout
        self._headers = dict(h.headers) if h.headers else {}
        self._async_client: httpx.AsyncClient | None = None
        self._sync_client: httpx.Client | None = None

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def use_local(self) -> bool:
        return self._use_local

    @property
    def defend_config(self) -> DefendConfig | None:
        """Active in-process policy, or ``None`` when using HTTP mode."""
        return self._local_defend_config

    def _async(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=self._headers,
                timeout=self._timeout,
            )
        return self._async_client

    def _sync(self) -> httpx.Client:
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self._base_url,
                headers=self._headers,
                timeout=self._timeout,
            )
        return self._sync_client

    async def aclose(self) -> None:
        if self._async_client is not None:
            await self._async_client.aclose()
            self._async_client = None

    def close(self) -> None:
        if self._sync_client is not None:
            self._sync_client.close()
            self._sync_client = None

    async def __aenter__(self) -> DefendApiClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    def __enter__(self) -> DefendApiClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @staticmethod
    def _parse_guard_result(resp: httpx.Response) -> GuardResult:
        resp.raise_for_status()
        return GuardResult.model_validate(resp.json())

    async def aguard_input(self, text: str, session_id: Optional[str] = None) -> GuardResult:
        if self._use_local:
            req = GuardInputRequest(text=text, session_id=session_id)
            assert self._local_defend_config is not None
            return await guard_input_local(req, defend_config=self._local_defend_config)
        payload: dict[str, Any] = {"text": text}
        if session_id is not None:
            payload["session_id"] = session_id
        r = await self._async().post("/v1/guard/input", json=payload)
        return self._parse_guard_result(r)

    async def aguard_output(self, text: str, session_id: Optional[str] = None) -> GuardResult:
        if self._use_local:
            req = GuardOutputRequest(text=text, session_id=session_id)
            assert self._local_defend_config is not None
            return await guard_output_local(req, defend_config=self._local_defend_config)
        payload: dict[str, Any] = {"text": text}
        if session_id is not None:
            payload["session_id"] = session_id
        r = await self._async().post("/v1/guard/output", json=payload)
        return self._parse_guard_result(r)

    def guard_input(self, text: str, session_id: Optional[str] = None) -> GuardResult:
        if self._use_local:
            req = GuardInputRequest(text=text, session_id=session_id)
            assert self._local_defend_config is not None
            return _run_coro_sync(
                guard_input_local(req, defend_config=self._local_defend_config)
            )
        payload: dict[str, Any] = {"text": text}
        if session_id is not None:
            payload["session_id"] = session_id
        r = self._sync().post("/v1/guard/input", json=payload)
        return self._parse_guard_result(r)

    def guard_output(self, text: str, session_id: Optional[str] = None) -> GuardResult:
        if self._use_local:
            req = GuardOutputRequest(text=text, session_id=session_id)
            assert self._local_defend_config is not None
            return _run_coro_sync(
                guard_output_local(req, defend_config=self._local_defend_config)
            )
        payload: dict[str, Any] = {"text": text}
        if session_id is not None:
            payload["session_id"] = session_id
        r = self._sync().post("/v1/guard/output", json=payload)
        return self._parse_guard_result(r)
