#!/usr/bin/env python3
"""
convert.py — CLI entry point for the PDF structured-extraction pipeline.

This script is the main user-facing interface. It accepts one or more PDF files
(or a directory of PDFs), runs the full extraction pipeline, and writes one JSON
file per PDF to the output directory.

Pipeline triggered by this script:
  PDF file(s) → tag_pdf_json() → hierarchical JSON output

Output JSON structure per document:
  {
    "source": "filename.pdf",
    "total_pages": N,
    "total_elements": N,
    "total_images": N,
    "type_summary": {"PARAGRAPH": N, "H1": N, ...},
    "elements": [ ... ]   # heading-tree with children[]
  }

Element ref field format:
  "(pX,lY):(pX,lY)" where p = page number (1-based), l = element index within
  that page (1-based). Example: "(p1,l3):(p6,l2)" means the element starts at
  page 1 element 3, and its last descendant ends at page 6 element 2.

Examples:
    python convert.py contract.pdf
    python convert.py contract.pdf -o result.json
    python convert.py docs/ -o extracted/ -w 8
    python convert.py --pages 1-5 contract.pdf
    python convert.py --catalog
    python convert.py contract.pdf --compare 25
"""

import argparse
import json
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from pdf_tagger.catalog import catalog_as_text
from pdf_tagger.tagger_json import tag_pdf_json

DEFAULT_INPUT = BASE_DIR / "data" / "input" / "digital"
DEFAULT_OUTPUT = BASE_DIR / "data" / "output" / "production"


def process_one(pdf_path: str, out_path: str, img_dir: str, pages: tuple = None, no_images: bool = False, force_mode: str = None) -> dict:
    """Process a single PDF. Routes each page to heuristic or vision pipeline."""
    try:
        stats = tag_pdf_json(pdf_path, out_path, img_dir, pages=pages, no_images=no_images, force_mode=force_mode)
        return {"ok": True, **stats}
    except Exception:
        import traceback
        return {"ok": False, "error": traceback.format_exc()}


def parse_pages(pages_str: str) -> tuple:
    """Parse a page-range string into a sorted tuple of 1-based page numbers.

    Accepts comma-separated ranges and individual page numbers.
    Examples: '1-5' → (1,2,3,4,5), '3' → (3,), '1,3,7-10' → (1,3,7,8,9,10).
    """
    pages = set()
    for part in pages_str.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            pages.update(range(int(a), int(b) + 1))
        else:
            pages.add(int(part))
    return tuple(sorted(pages))


def main():
    parser = argparse.ArgumentParser(
        prog="convert.py",
        description="Extract structured hierarchical JSON from PDF documents.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  python convert.py contract.pdf                    Single PDF → output/contract.json
  python convert.py contract.pdf -o result.json     Single PDF → custom output path
  python convert.py docs/                           All PDFs in folder → output/
  python convert.py docs/ -o extracted/             All PDFs → custom output folder
  python convert.py contract.pdf --pages 1-5        Only pages 1 through 5
  python convert.py contract.pdf --pages 1,3,7-10   Specific pages
  python convert.py contract.pdf --no-images        Skip image extraction
  python convert.py docs/ -w 4                      Use 4 parallel workers
  python convert.py --catalog                       Print element type catalog
  python convert.py contract.pdf --compare 25       Compare table on page 25
  python convert.py contract.pdf --compare all      Compare all tables
        """,
    )
    parser.add_argument(
        "input", nargs="?", default=None,
        help="PDF file or directory of PDFs (default: input/ folder)",
    )
    parser.add_argument(
        "-o", "--output", default=None,
        help="Output JSON file or directory (default: output/)",
    )
    parser.add_argument(
        "-w", "--workers", type=int, default=20,
        help="Number of parallel workers (default: 20)",
    )
    parser.add_argument(
        "--pages", default=None,
        help="Page range to extract, e.g. '1-5', '3', '1,3,7-10' (default: all)",
    )
    parser.add_argument(
        "--no-images", action="store_true",
        help="Skip image extraction",
    )
    parser.add_argument(
        "--catalog", action="store_true",
        help="Print the element type catalog and exit",
    )
    parser.add_argument(
        "--pretty", action="store_true", default=True,
        help="Pretty-print JSON with indentation (default: yes)",
    )
    parser.add_argument(
        "--compact", action="store_true",
        help="Compact JSON output (no indentation)",
    )
    parser.add_argument(
        "--compare", default=None, metavar="PAGE",
        help="Generate table round-trip comparison PNGs. Use page number or 'all'.",
    )

    parser.add_argument(
        "--force-vision", action="store_true",
        help="Force vision pipeline (YOLO+OCR+TexTAR) for all pages",
    )
    parser.add_argument(
        "--force-heuristic", action="store_true",
        help="Force heuristic pipeline for all pages (ignore scan detection)",
    )

    args = parser.parse_args()

    # Determine force mode
    force_mode = None
    if args.force_vision:
        force_mode = "vision"
    elif args.force_heuristic:
        force_mode = "heuristic"

    # --compare: table round-trip comparison
    if args.compare and args.input:
        from pdf_tagger.table_compare import generate_comparison, generate_all_comparisons
        pdf_path = str(Path(args.input).resolve())
        out_dir = str(Path(args.output).resolve()) if args.output else str(BASE_DIR / "data" / "output" / "table_comparisons")
        if args.compare.lower() == "all":
            print(f"Generating table comparisons for all pages...")
            paths = generate_all_comparisons(pdf_path, out_dir)
            print(f"\n{len(paths)} comparison(s) → {out_dir}/")
        else:
            page = int(args.compare)
            print(f"Generating table comparisons for page {page}...")
            generate_comparison(pdf_path, page, out_dir)
        return

    # --catalog: print and exit
    if args.catalog:
        print(catalog_as_text())
        return

    # Parse pages
    pages = parse_pages(args.pages) if args.pages else None

    # Resolve input
    if args.input:
        target = Path(args.input).resolve()
        if target.is_file() and target.suffix.lower() == ".pdf":
            pdfs = [target]
            base_dir = target.parent
            is_single = True
        elif target.is_dir():
            pdfs = sorted(target.rglob("*.pdf"))
            base_dir = target
            is_single = False
        else:
            parser.error(f"'{args.input}' is not a PDF file or directory")
    else:
        input_dir = DEFAULT_INPUT
        if not input_dir.exists():
            parser.error(
                "No input specified. Usage:\n"
                "  python scripts/convert.py document.pdf\n"
                "  python scripts/convert.py folder/\n"
                f"  Or place PDFs in {input_dir}"
            )
        pdfs = sorted(input_dir.rglob("*.pdf"))
        base_dir = input_dir
        is_single = False

    if not pdfs:
        parser.error("No PDF files found")

    # Resolve output
    if args.output:
        out_path = Path(args.output).resolve()
        if is_single and out_path.suffix == ".json":
            # Single file → specific JSON output
            output_dir = out_path.parent
            output_json = out_path
        else:
            output_dir = out_path
            output_json = None
    else:
        output_dir = DEFAULT_OUTPUT
        output_json = None

    images_dir = output_dir / "images"
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save catalog
    (output_dir / "CATALOG.txt").write_text(catalog_as_text(), encoding="utf-8")

    n = len(pdfs)
    workers = min(args.workers, n)
    page_info = f", pages {args.pages}" if args.pages else ""
    print(f"Processing {n} PDF(s){page_info} ({workers} workers)\n")

    t0 = time.time()
    futures = {}

    with ProcessPoolExecutor(max_workers=workers) as pool:
        for pdf_path in pdfs:
            try:
                rel = str(pdf_path.relative_to(base_dir))
            except ValueError:
                rel = pdf_path.name

            if output_json and is_single:
                o = str(output_json)
            else:
                o = str(output_dir / Path(rel).with_suffix(".json"))

            img_sub = images_dir / Path(rel).parent / pdf_path.stem

            fut = pool.submit(process_one, str(pdf_path), o, str(img_sub), pages, args.no_images, force_mode)
            futures[fut] = (rel, o)

        ok_count = 0
        fail_count = 0
        for fut in as_completed(futures):
            rel, out_file = futures[fut]
            result = fut.result()
            if result["ok"]:
                ok_count += 1
                p = result["pages"]
                e = result["elements"]
                i = result["images"]
                print(f"  OK  {rel}  ({p} pages, {e} elements, {i} images)")
            else:
                fail_count += 1
                print(f"  FAIL  {rel}")
                print(f"        {result['error'][:300]}")

    elapsed = time.time() - t0
    print(f"\nDone in {elapsed:.1f}s — {ok_count} OK, {fail_count} failed")

    if is_single and output_json:
        print(f"Output: {output_json}")
    else:
        print(f"Output: {output_dir}/")


if __name__ == "__main__":
    main()
