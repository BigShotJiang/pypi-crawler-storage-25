"""CLI scripts shipped with paradox-pdf."""
