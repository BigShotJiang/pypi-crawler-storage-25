"""
PDF Element Tagger — Classify every element in a PDF with a type ID.

For each page:
  1. Extract images → save to images/ directory, tag as IMAGE/SIGNATURE_IMG/LOGO
  2. Detect tables → tag with TABLE (rows×cols dimensions)
  3. Detect strikethrough text → tag as AMENDMENT_DEL
  4. Classify remaining text lines by pattern matching

Output: tagged text file with [ID:CODE] prefix on every element.
"""

from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pdf_grid.extractor import render_page_to_text
from pdf_tagger.catalog import CATALOG, get_code


# ── Regex patterns for element classification ──

# Headings
RE_TITLE_ALLCAPS = re.compile(
    r"^[A-Z][A-Z\s\-:,&'\"()]{15,}$"
)
RE_H1 = re.compile(
    r"^(?:"
    r"(?:ARTICLE|SECTION|PART|CHAPTER)\s+\d+|"
    r"\d{1,3}\.\s+[A-Z]|"
    r"[IVXLC]+\.\s+[A-Z]"
    r")",
    re.IGNORECASE,
)
RE_H2 = re.compile(r"^\s{0,8}[a-z]\.\s+\S")
RE_H3 = re.compile(r"^\s{0,16}(?:i{1,4}|iv|vi{0,3})\.\s+\S", re.IGNORECASE)
RE_H4 = re.compile(r"^\s{0,24}\([a-zA-Z0-9]{1,3}\)\s+\S")

# Lists
RE_LIST_NUM = re.compile(r"^\s{0,20}\d{1,3}[.)]\s+\S")
RE_LIST_ALPHA = re.compile(r"^\s{4,20}[a-z][.)]\s+\S")
RE_LIST_ROMAN = re.compile(r"^\s{8,24}(?:i{1,4}|iv|vi{0,3})[.)]\s+\S", re.IGNORECASE)
RE_LIST_PAREN = re.compile(r"^\s{0,24}\(\d{1,3}\)\s+\S")
RE_LIST_BULLET = re.compile(r"^\s{0,20}[\u2022\-\*\u25CF\u25CB\u25AA]\s+\S")

# Meta
RE_DOC_ID = re.compile(r"(?:DocuSign|Envelope\s*ID|Document\s*ID)\s*[:=]", re.IGNORECASE)
RE_FILE_PATH = re.compile(r"^[A-Z]:\\|^/[a-z]+/|^\d{8,}\.\w{2,4}")
RE_PAGE_NUM = re.compile(r"^\s*\d{1,4}\s*$")
RE_VERSION = re.compile(r"reformat|revision|version|draft", re.IGNORECASE)

# Special sections
RE_EXHIBIT = re.compile(r"^\s*EXHIBIT\s+[\"']?[A-Z0-9]", re.IGNORECASE)
RE_APPENDIX = re.compile(r"^\s*APPENDIX\s+[A-Z0-9]", re.IGNORECASE)
RE_SCHEDULE = re.compile(r"^\s*SCHEDULE\s+[A-Z0-9]", re.IGNORECASE)
RE_SIDELETTER = re.compile(r"^\s*SIDELETTER", re.IGNORECASE)
RE_ATTACHMENT = re.compile(r"^\s*ATTACHMENT\s+[A-Z0-9]", re.IGNORECASE)

# Signature
RE_SIGNATURE_LINE = re.compile(r"_{5,}|By:\s*_|Date:\s*_")
RE_PARTY_ID = re.compile(r"^\s*FOR\s+THE\s+", re.IGNORECASE)
RE_WITNESS = re.compile(r"^\s*WITNESS", re.IGNORECASE)

# Notation
RE_PROPOSAL = re.compile(r"\((?:WGA|Union|AMPTP|Company)\s+Proposal\s+No\.", re.IGNORECASE)
RE_BRACKET_INSERT = re.compile(r"\[insert\s", re.IGNORECASE)
RE_ASTERISK = re.compile(r"^\s*\*{3,}\s*$")
RE_SECTION_BREAK = re.compile(r"^\s*[-=_]{10,}\s*$")

# Preamble
RE_PREAMBLE = re.compile(
    r"(?:This\s+(?:Memorandum|Agreement)|entered\s+into\s+between|WHEREAS)", re.IGNORECASE
)
RE_EFFECTIVE = re.compile(r"effective\s+(?:as\s+of|date|on)", re.IGNORECASE)

# Definition
RE_DEFINITION = re.compile(r"""['"]\w+['"]\s+(?:means|shall mean|is defined|refers to)""", re.IGNORECASE)

# Cross-reference
RE_CROSS_REF = re.compile(
    r"(?:See|see|Refer to|as (?:set forth|provided|described) in)\s+(?:Section|Article|Paragraph|Exhibit|Appendix)",
    re.IGNORECASE,
)

# Footnote
RE_FOOTNOTE_CONTENT = re.compile(r"^\s*\d{1,2}[.)]\s+\S")  # at bottom of page context

# Quote block
RE_QUOTE_BLOCK = re.compile(r'^\s{10,}["\u201C]')

# Confidential
RE_CONFIDENTIAL = re.compile(r"CONFIDENTIAL|PRIVILEGED|NOT FOR DISTRIBUTION", re.IGNORECASE)

# TOC entry
RE_TOC = re.compile(r"^\s*.{5,60}\s*\.{3,}\s*\d{1,4}\s*$")

# Formula
RE_FORMULA = re.compile(r"[=×÷\+\-]\s*(?:\d|[A-Z][a-z]+\s+[×÷=])", re.IGNORECASE)

# Rate schedule line
RE_RATE = re.compile(r"\$[\d,]+(?:\.\d{2})?\s+(?:per|for|plus)", re.IGNORECASE)


# ── Merging constants (used by tag_page and tagger_json) ──

ANCHOR_TYPES = {
    1,    # TITLE
    2,    # SUBTITLE
    12,   # QUOTE_BLOCK
    13,   # DEFINITION
    50,   # CROSS_REF
    90,   # PREAMBLE
    91,   # RECITAL
    92,   # EFFECTIVE_DATE
    93,   # CONFIDENTIAL
}
FLOW_TYPES = {
    10,   # PARAGRAPH
    11,   # CONTINUATION
}
MERGEABLE_TYPES = ANCHOR_TYPES | FLOW_TYPES


def _detect_underline_spans(page) -> List[Tuple[float, float, float, float, str]]:
    """
    Detect underlined text by finding thin horizontal lines at the bottom edge
    of word bboxes.
    Returns list of (x0, y0, x1, y1, underlined_text).
    """
    results = []
    try:
        drawings = page.get_drawings()
    except Exception:
        return results

    underline_lines = []
    for d in drawings:
        rect = d.get("rect")
        if rect is None:
            continue
        rx0, ry0, rx1, ry1 = (
            float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1),
        )
        dx = abs(rx1 - rx0)
        dy = abs(ry1 - ry0)
        if dy <= 2.0 and dx >= 5.0:
            underline_lines.append((min(rx0, rx1), (ry0 + ry1) / 2, max(rx0, rx1)))

    if not underline_lines:
        return results

    words = page.get_text("words") or []
    for ul_x0, ul_y, ul_x1 in underline_lines:
        underlined_words = []
        for w in words:
            if not (isinstance(w, (list, tuple)) and len(w) >= 5):
                continue
            wx0, wy0, wx1, wy1, wt = (
                float(w[0]), float(w[1]), float(w[2]), float(w[3]), str(w[4]),
            )
            word_h = wy1 - wy0
            # Underline: line sits at the bottom 20% of text or just below
            if (
                ul_y >= wy1 - word_h * 0.2
                and ul_y <= wy1 + word_h * 0.3
                and ul_x0 >= wx0 - 2
                and ul_x1 <= wx1 + 2
            ):
                underlined_words.append((wx0, wt))
        if underlined_words:
            underlined_words.sort(key=lambda z: z[0])
            text = " ".join(t for _, t in underlined_words)
            results.append((ul_x0, ul_y - 6, ul_x1, ul_y + 6, text))
    return results


def _detect_strikethrough_spans(page) -> List[Tuple[float, float, float, float, str]]:
    """
    Detect strikethrough text by finding thin horizontal lines that cross through
    text vertically centered on word bboxes.
    Returns list of (x0, y0, x1, y1, struck_text).
    """
    results = []
    try:
        drawings = page.get_drawings()
    except Exception:
        return results

    # Collect thin horizontal lines using rect-based detection (deduplicates
    # filled rectangles that would otherwise emit two "l" items per drawing).
    strike_lines = []
    for d in drawings:
        rect = d.get("rect")
        if rect is None:
            continue
        rx0, ry0, rx1, ry1 = (
            float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1),
        )
        dx = abs(rx1 - rx0)
        dy = abs(ry1 - ry0)
        # Strikethrough: horizontal line, at least 5pt long, very thin
        if dy <= 2.0 and dx >= 5.0:
            strike_lines.append((min(rx0, rx1), (ry0 + ry1) / 2, max(rx0, rx1)))

    if not strike_lines:
        return results

    words = page.get_text("words") or []
    for sl_x0, sl_y, sl_x1 in strike_lines:
        struck_words = []
        for w in words:
            if not (isinstance(w, (list, tuple)) and len(w) >= 5):
                continue
            wx0, wy0, wx1, wy1, wt = float(w[0]), float(w[1]), float(w[2]), float(w[3]), str(w[4])
            word_mid_y = (wy0 + wy1) / 2
            word_h = wy1 - wy0
            # Line must cross through the middle quarter of the word
            # (strikethroughs sit ~0.1-0.2x height from center; underlines sit ~0.45x)
            if (
                abs(sl_y - word_mid_y) < word_h * 0.25
                and sl_y < wy1  # line must be within text bbox, not below it
                and wx0 >= sl_x0 - 2
                and wx1 <= sl_x1 + 2
            ):
                struck_words.append((wx0, wt))
        if struck_words:
            struck_words.sort(key=lambda z: z[0])
            text = " ".join(t for _, t in struck_words)
            results.append((sl_x0, sl_y - 6, sl_x1, sl_y + 6, text))
    return results


def _extract_images(page, page_idx: int, images_dir: Path, pdf_name: str) -> List[dict]:
    """Extract images from page, save to images_dir, return metadata."""
    extracted = []
    try:
        image_list = page.get_images(full=True)
    except Exception:
        return extracted

    for img_idx, img_info in enumerate(image_list):
        xref = img_info[0]
        try:
            pix = fitz.Pixmap(page.parent, xref)
            if pix.n > 4:  # CMYK
                pix = fitz.Pixmap(fitz.csRGB, pix)

            w, h = pix.width, pix.height
            # Skip tiny images (likely bullets or decorations)
            if w < 15 or h < 15:
                pix = None
                continue

            # Determine type by aspect ratio and size
            if w < 200 and h < 80:
                type_id = 102  # LOGO
            elif 50 < w < 400 and 20 < h < 100:
                type_id = 101  # SIGNATURE_IMG
            else:
                type_id = 100  # IMAGE

            # Save image
            img_name = f"{pdf_name}_p{page_idx+1}_img{img_idx+1}.png"
            img_path = images_dir / img_name
            pix.save(str(img_path))

            # Get position on page
            img_rects = page.get_image_rects(xref)
            rect = img_rects[0] if img_rects else fitz.Rect(0, 0, w, h)

            extracted.append({
                "type_id": type_id,
                "file": img_name,
                "width": w,
                "height": h,
                "y_pos": float(rect.y0) if img_rects else 0,
                "rect": f"({rect.x0:.0f},{rect.y0:.0f},{rect.x1:.0f},{rect.y1:.0f})" if img_rects else "",
            })
            pix = None
        except Exception as e:
            logger.debug("Image extraction failed xref=%d: %s", xref, e)

    return extracted


def classify_line(text: str, page_y_ratio: float, prev_type: Optional[int]) -> int:
    """
    Classify a single text line into an element type ID.
    page_y_ratio: 0.0 = top of page, 1.0 = bottom of page.
    """
    stripped = text.strip()
    if not stripped:
        return 62  # BLANK_LINE

    # ── Meta (headers/footers) ──
    if RE_DOC_ID.search(stripped):
        return 43  # DOC_ID
    if RE_FILE_PATH.match(stripped):
        return 124  # FILE_PATH
    if RE_ASTERISK.match(stripped):
        return 122  # ASTERISK_BREAK
    if RE_SECTION_BREAK.match(stripped):
        return 63  # HORIZONTAL_RULE
    if RE_CONFIDENTIAL.search(stripped):
        return 93  # CONFIDENTIAL

    # Page number (alone on line, near top or bottom)
    if RE_PAGE_NUM.match(stripped) and (page_y_ratio < 0.08 or page_y_ratio > 0.92):
        return 42  # PAGE_NUMBER

    # Version marks
    if RE_VERSION.search(stripped) and len(stripped) < 80 and page_y_ratio < 0.15:
        return 45  # VERSION_MARK

    # File paths in footer area
    if page_y_ratio > 0.88 and (RE_FILE_PATH.match(stripped) or re.match(r"^\d{8,}", stripped)):
        return 41  # PAGE_FOOTER

    # ── Navigation labels ──
    if RE_EXHIBIT.match(stripped):
        return 72  # EXHIBIT_LABEL
    if RE_APPENDIX.match(stripped):
        return 71  # APPENDIX_LABEL
    if RE_SCHEDULE.match(stripped):
        return 73  # SCHEDULE_LABEL
    if RE_SIDELETTER.match(stripped):
        return 74  # SIDELETTER_LABEL
    if RE_ATTACHMENT.match(stripped):
        return 75  # ATTACHMENT_LABEL

    # ── Signature area ──
    if RE_SIGNATURE_LINE.search(stripped):
        return 81  # SIGNATURE_LINE
    if RE_PARTY_ID.match(stripped):
        return 82  # PARTY_ID
    if RE_WITNESS.match(stripped):
        return 84  # WITNESS

    # ── Notation ──
    if RE_PROPOSAL.search(stripped) and len(stripped) < 60:
        return 120  # PROPOSAL_NUM
    if RE_BRACKET_INSERT.search(stripped):
        return 121  # BRACKET_INSERT

    # ── TOC ──
    if RE_TOC.match(stripped):
        return 70  # TOC_ENTRY

    # ── Title (all caps, long) ──
    if RE_TITLE_ALLCAPS.match(stripped) and len(stripped) > 20:
        # Distinguish title vs H1
        if page_y_ratio < 0.35 and prev_type in (None, 61, 62, 42, 43, 45):
            return 1  # TITLE
        return 3  # H1

    # ── Headings ──
    if RE_H1.match(stripped):
        return 3  # H1
    if RE_H2.match(stripped) and len(stripped) < 200:
        return 4  # H2
    if RE_H3.match(stripped):
        return 5  # H3
    if RE_H4.match(stripped):
        return 6  # H4

    # ── Lists ──
    if RE_LIST_BULLET.match(text):
        return 24  # LIST_BULLET
    if RE_LIST_PAREN.match(text):
        return 23  # LIST_PAREN
    if RE_LIST_ROMAN.match(text):
        return 22  # LIST_ROMAN
    if RE_LIST_ALPHA.match(text):
        return 21  # LIST_ALPHA
    if RE_LIST_NUM.match(text):
        return 20  # LIST_NUM

    # ── Special body ──
    if RE_DEFINITION.search(stripped):
        return 13  # DEFINITION
    if RE_PREAMBLE.search(stripped) and page_y_ratio < 0.5:
        return 90  # PREAMBLE
    if RE_EFFECTIVE.search(stripped) and len(stripped) < 150:
        return 92  # EFFECTIVE_DATE
    if RE_CROSS_REF.search(stripped):
        return 50  # CROSS_REF
    if RE_QUOTE_BLOCK.match(text):
        return 12  # QUOTE_BLOCK
    if RE_FORMULA.search(stripped):
        return 113  # FORMULA
    if RE_RATE.search(stripped):
        return 112  # RATE_SCHEDULE

    # ── Default: paragraph or continuation ──
    indent = len(text) - len(text.lstrip())
    if indent > 20 and prev_type == 10:
        return 11  # CONTINUATION
    return 10  # PARAGRAPH


# NOTE: tag_pdf() and tag_page() (legacy plain-text [ID:CODE] pipeline) removed.
# Use pdf_tagger.tagger_json.tag_pdf_json for the JSON pipeline.
