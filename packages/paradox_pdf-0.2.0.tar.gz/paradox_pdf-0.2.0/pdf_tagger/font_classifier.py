"""
font_classifier.py — Font-aware text extraction and element classification.

This module is responsible for turning raw PyMuPDF span/line data into typed
element dicts. It operates in two stages:

Stage 1 — Extraction (lines → blocks):
  _extract_lines() reads every text span on the page via page.get_text("dict"),
  preserves visual indentation by converting x0 position to leading spaces, and
  merges fragments at the same vertical position into single TextLine objects.
  group_lines_into_blocks() then groups consecutive TextLines into TextBlock
  objects using font changes, vertical gaps, and indentation patterns.

Stage 2 — Classification (block → type_id integer):
  classify_block() maps each TextBlock to a catalog type_id using a priority
  ladder of heuristics:
    1. Page-level metadata   (DOC_ID, PAGE_NUMBER, version, file paths)
    2. Font-based titles     (bold + centered + large → TITLE/SUBTITLE)
    3. Long flowing text     (line_count >= 3 or chars > 200 → PARAGRAPH)
    4. Navigation labels     (EXHIBIT, APPENDIX, SCHEDULE, etc.)
    5. Signature blocks
    6. Proposal/bracket notations
    7. TOC entries           (dot-leader pattern → TOC_ENTRY)
    8. Headings by font      (bold + size_rank → H1/H2)
    9. Content patterns      (bullets, definitions, cross-references, rates)
   10. Default               → PARAGRAPH

  Font properties (size rank, bold, centered, allcaps) take priority over
  regex patterns for structural elements such as headings and titles.

Heading hierarchy emitted by this module:
  TITLE (type_id 1, depth 0) > SUBTITLE (2, 1) > H1 (3, 2) > H2 (4, 3)
  Higher-level headings (H3/H4) are assigned by tagger_json if needed.

Table regions must be excluded before calling extract_text_blocks() to prevent
table cell text from being classified as standalone paragraphs.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")


@dataclass
class SpanInfo:
    """Per-span decoration data preserved from a single PyMuPDF span."""
    text: str
    x0: float
    x1: float
    y0: float
    y1: float
    is_bold: bool
    is_italic: bool
    is_underline_font: bool   # underline from font flags (decorative, not geometric)
    is_superscript: bool
    is_monospace: bool


@dataclass
class TextLine:
    """A single line of text with font metadata and position."""
    text: str
    y0: float
    y1: float
    x0: float         # left edge = indentation
    x1: float
    font_size: float
    is_bold: bool
    is_italic: bool
    is_underline: bool
    spans: List["SpanInfo"]


@dataclass
class TextBlock:
    """A group of lines forming a logical block (paragraph, heading, etc.)."""
    text: str          # full text (lines joined with \n)
    y0: float
    y1: float
    x0: float          # minimum x0 (base margin)
    x1: float
    font_size: float
    is_bold: bool
    is_italic: bool
    is_centered: bool
    is_allcaps: bool
    indent: float      # indent of first line relative to base margin (pts)
    line_count: int
    spans: List["SpanInfo"]


# ═══════════════════════════════════════════════════════════════════
#  LINE EXTRACTION
# ═══════════════════════════════════════════════════════════════════

def _x0_to_spaces(x0: float, page_left: float, char_width: float = 7.0) -> str:
    """Convert x0 position to leading spaces for visual indentation."""
    n = max(0, round((x0 - page_left) / char_width))
    return " " * n


def _extract_lines(page, excluded_bboxes: List[Tuple] = None) -> List[TextLine]:
    """
    Extract individual text lines with font metadata from a PyMuPDF page.
    Text preserves visual indentation as leading spaces (x0 → spaces).
    """
    excluded = excluded_bboxes or []
    data = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)
    page_left = page.rect.x0  # left edge of page
    lines: List[TextLine] = []

    for block in data.get("blocks", []):
        if block["type"] != 0:
            continue
        if _overlaps_any(block["bbox"], excluded):
            continue

        for line in block.get("lines", []):
            lbox = line["bbox"]
            parts = []
            max_size = 0.0
            bold_n = 0
            italic_n = 0
            underline_n = 0
            total_n = 0
            span_infos: List[SpanInfo] = []

            for span in line.get("spans", []):
                text = span["text"]
                parts.append(text)
                n = len(text.strip())
                total_n += n
                max_size = max(max_size, span["size"])

                flags = span.get("flags", 0)
                font = span.get("font", "")
                sp_bold = bool(flags & (1 << 4)) or "bold" in font.lower()
                sp_italic = bool(flags & (1 << 1))
                sp_underline = bool(flags & (1 << 3))
                sp_superscript = bool(flags & (1 << 0))
                # monospace: detect by font name (Courier, *Mono*, Consolas, etc.)
                _fl = font.lower()
                sp_monospace = ("mono" in _fl or "courier" in _fl or "consolas" in _fl)

                if sp_bold:
                    bold_n += n
                if sp_italic:
                    italic_n += n
                if sp_underline:
                    underline_n += n

                sbox = span.get("bbox", lbox)
                span_infos.append(SpanInfo(
                    text=text,
                    x0=float(sbox[0]), x1=float(sbox[2]),
                    y0=float(sbox[1]), y1=float(sbox[3]),
                    is_bold=sp_bold,
                    is_italic=sp_italic,
                    is_underline_font=sp_underline,
                    is_superscript=sp_superscript,
                    is_monospace=sp_monospace,
                ))

            full = "".join(parts).strip()
            if not full:
                continue

            # Compute char_width from font size (~0.6 ratio)
            cw = max_size * 0.55 if max_size > 0 else 7.0
            indent_spaces = _x0_to_spaces(lbox[0], page_left, cw)
            indented_text = indent_spaces + full

            lines.append(TextLine(
                text=indented_text,
                y0=lbox[1], y1=lbox[3],
                x0=lbox[0], x1=lbox[2],
                font_size=max_size,
                is_bold=(bold_n > total_n * 0.5) if total_n else False,
                is_italic=(italic_n > total_n * 0.5) if total_n else False,
                is_underline=(underline_n > total_n * 0.5) if total_n else False,
                spans=span_infos,
            ))

    # Merge lines at the same vertical position (same visual line split by PyMuPDF)
    if len(lines) > 1:
        merged = [lines[0]]
        for ln in lines[1:]:
            prev = merged[-1]
            if abs(ln.y0 - prev.y0) < 2.0:  # same visual line
                # Concatenate text with spacing
                gap_chars = max(1, round((ln.x0 - prev.x1) / (prev.font_size * 0.55 if prev.font_size > 0 else 7.0)))
                prev.text = prev.text + " " * gap_chars + ln.text.lstrip()
                prev.x1 = ln.x1
                prev.y1 = max(prev.y1, ln.y1)
                prev.spans.extend(ln.spans)
            else:
                merged.append(ln)
        lines = merged

    return lines


# ═══════════════════════════════════════════════════════════════════
#  LINE → BLOCK GROUPING (indent-aware)
# ═══════════════════════════════════════════════════════════════════

def group_lines_into_blocks(
    lines: List[TextLine],
    page_width: float,
    base_margin: float = 0,
) -> List[TextBlock]:
    """
    Group lines into logical blocks using indentation and font changes.

    Rules:
      - Bold line (different from previous) starts new block
      - Indented first line (x0 > base_margin + threshold) followed by
        flush lines = one paragraph
      - Gap > 1.5 * line_height between lines = new block
      - Font size change = new block
    """
    if not lines:
        return []

    # Detect base margin (most common x0)
    if base_margin <= 0:
        x0_values = [round(l.x0) for l in lines]
        if x0_values:
            from collections import Counter
            base_margin = Counter(x0_values).most_common(1)[0][0]

    INDENT_THRESHOLD = 20  # pts: first-line indent detection

    blocks: List[TextBlock] = []
    buf: List[TextLine] = [lines[0]]

    def flush_buf():
        if not buf:
            return
        # Build block from buffer
        texts = [l.text for l in buf]
        min_x0 = min(l.x0 for l in buf)
        first_indent = buf[0].x0 - base_margin

        # Centering: check if lines are centered
        is_centered = all(
            abs((page_width - l.x1) - l.x0) < 40 and l.x0 > 50
            for l in buf
        )

        full_text = "\n".join(texts)
        alpha = sum(1 for c in full_text if c.isalpha())
        upper = sum(1 for c in full_text if c.isupper())
        is_allcaps = (upper > alpha * 0.7) if alpha > 5 else False

        all_spans: List[SpanInfo] = [s for l in buf for s in l.spans]

        blocks.append(TextBlock(
            text=full_text,
            y0=buf[0].y0, y1=buf[-1].y1,
            x0=min_x0, x1=max(l.x1 for l in buf),
            font_size=max(l.font_size for l in buf),
            is_bold=buf[0].is_bold,
            is_italic=buf[0].is_italic,
            is_centered=is_centered,
            is_allcaps=is_allcaps,
            indent=max(0, first_indent),
            line_count=len(buf),
            spans=all_spans,
        ))

    for i in range(1, len(lines)):
        prev = lines[i - 1]
        curr = lines[i]

        # Compute gap
        gap = curr.y0 - prev.y1
        line_height = prev.y1 - prev.y0

        # Font change (bold/size) = always new block
        font_changed = (
            curr.is_bold != prev.is_bold
            or abs(curr.font_size - prev.font_size) > 1.0
        )

        # Large vertical gap = new block
        large_gap = gap > line_height * 1.2

        # Indented line after flush lines = new paragraph
        curr_indented = curr.x0 > base_margin + INDENT_THRESHOLD
        prev_flush = prev.x0 < base_margin + INDENT_THRESHOLD

        # Standalone numbered item (e.g., "2.", "8.") = new block
        # Prevents TOC entry numbers from merging with previous entry
        is_numbered_start = bool(RE_NUMBERED_ITEM.match(curr.text.strip()))

        starts_new = font_changed or large_gap or is_numbered_start or (curr_indented and prev_flush and not buf[0].is_bold)

        if starts_new:
            flush_buf()
            buf = [curr]
        else:
            buf.append(curr)

    flush_buf()
    return blocks


def extract_text_blocks(page, excluded_bboxes: List[Tuple] = None) -> List[TextBlock]:
    """
    Extract all text blocks from a page, excluding table regions.

    Combines _extract_lines() and group_lines_into_blocks() into a single
    public call. Blocks in excluded_bboxes (table areas) are suppressed so
    that table cell text is not classified as regular paragraph content.

    Args:
        page:            PyMuPDF page object.
        excluded_bboxes: List of (x0, y0, x1, y1) rectangles to skip.

    Returns:
        List of TextBlock objects ordered top-to-bottom on the page.
    """
    excluded = excluded_bboxes or []
    lines = _extract_lines(page, excluded)
    if not lines:
        return []
    return group_lines_into_blocks(lines, page.rect.width)


def _overlaps_any(bbox, excluded) -> bool:
    bx0, by0, bx1, by1 = bbox
    for ex0, ey0, ex1, ey1 in excluded:
        ix0, iy0 = max(bx0, ex0), max(by0, ey0)
        ix1, iy1 = min(bx1, ex1), min(by1, ey1)
        if ix1 > ix0 and iy1 > iy0:
            inter = (ix1 - ix0) * (iy1 - iy0)
            area = max(1, (bx1 - bx0) * (by1 - by0))
            if inter / area > 0.3:
                return True
    return False


# ═══════════════════════════════════════════════════════════════════
#  CLASSIFICATION
# ═══════════════════════════════════════════════════════════════════

RE_DOT_LEADER = re.compile(r'^(.+?)\s*\.[\s.]{3,}\s*(\d{1,4})\s*$')
RE_TOC_HEADER = re.compile(r'^table\s+of\s+contents?$', re.IGNORECASE)
RE_DOC_ID = re.compile(r"(?:DocuSign|Envelope\s*ID|Document\s*ID)\s*[:=]", re.IGNORECASE)
RE_FILE_PATH = re.compile(r"^[A-Z]:\\|^/[a-z]+/|^\d{8,}\.\w{2,4}")
RE_PAGE_NUM_BARE = re.compile(r"^\s*-?\s*\d{1,4}\s*-?\s*$")
RE_SIGNATURE_LINE = re.compile(r"_{5,}|By:\s*_|Date:\s*_")
RE_PARTY_ID = re.compile(r"^\s*FOR\s+THE\s+", re.IGNORECASE)
RE_PREAMBLE = re.compile(
    r"(?:This\s+(?:Memorandum|Agreement)|entered\s+into\s+between|WHEREAS)", re.IGNORECASE
)
RE_EFFECTIVE = re.compile(r"effective\s+(?:as\s+of|date|on)", re.IGNORECASE)
RE_DEFINITION = re.compile(r"""['"]\w+['"]\s+(?:means|shall mean|is defined)""", re.IGNORECASE)
RE_CROSS_REF = re.compile(
    r"(?:See|Refer to|as (?:set forth|provided|described) in)\s+(?:Section|Article|Exhibit)",
    re.IGNORECASE,
)
RE_EXHIBIT = re.compile(r"^\s*EXHIBIT\s+[\"']?[A-Z0-9]", re.IGNORECASE)
RE_APPENDIX = re.compile(r"^\s*APPENDIX\s+[A-Z0-9]", re.IGNORECASE)
RE_SCHEDULE = re.compile(r"^\s*SCHEDULE\s+[A-Z0-9]", re.IGNORECASE)
RE_SIDELETTER = re.compile(r"^\s*SIDELETTER", re.IGNORECASE)
RE_ATTACHMENT = re.compile(r"^\s*ATTACHMENT\s+[A-Z0-9]", re.IGNORECASE)
RE_CONFIDENTIAL = re.compile(r"CONFIDENTIAL|PRIVILEGED|NOT FOR DISTRIBUTION", re.IGNORECASE)
RE_LIST_BULLET = re.compile(r"^\s{0,20}[\u2022\-\*\u25CF\u25CB\u25AA]\s+\S")
RE_H1_PATTERN = re.compile(r"^(?:ARTICLE|SECTION|PART|CHAPTER)\s+\d+", re.IGNORECASE)
RE_SECTION_BREAK = re.compile(r"^\s*[-=_]{10,}\s*$")
RE_ASTERISK = re.compile(r"^\s*\*{3,}\s*$")
RE_QUOTE_BLOCK = re.compile(r'^\s{10,}["\u201C]')
RE_NUMBERED_ITEM = re.compile(r'^\s*\d{1,3}\.?\s*$')  # standalone "2.", "8.", "12"
RE_RATE = re.compile(r"\$[\d,]+(?:\.\d{2})?\s+(?:per|for|plus)", re.IGNORECASE)
RE_VERSION = re.compile(r"reformat|revision|version|draft", re.IGNORECASE)
RE_WITNESS = re.compile(r"^\s*WITNESS", re.IGNORECASE)
RE_PROPOSAL = re.compile(r"\((?:WGA|Union|AMPTP|Company)\s+Proposal", re.IGNORECASE)
RE_BRACKET_INSERT = re.compile(r"\[insert\s", re.IGNORECASE)


def classify_block(
    block: TextBlock,
    page_height: float,
    font_sizes: List[float],
    prev_type: Optional[int],
) -> int:
    """
    Classify a TextBlock into a catalog type_id integer.

    Uses a priority ladder: font/position signals are checked before regex
    patterns so that bold headings are not misclassified as paragraphs.

    Args:
        block:       The TextBlock to classify.
        page_height: Full height of the page in PDF points (used to compute
                     y_ratio — vertical position as fraction of page height).
        font_sizes:  Sorted list of all distinct font sizes on the page,
                     used to compute size_rank (relative prominence).
        prev_type:   type_id of the previously classified block on this page,
                     used as context for ambiguous cases (e.g. allcaps titles
                     near the top of the page).

    Returns:
        Catalog type_id integer (e.g. 1=TITLE, 3=H1, 10=PARAGRAPH, 70=TOC_ENTRY).
    """
    text = block.text
    # Strip leading spaces per line for classification (indentation is in x0)
    stripped_lines = [ln.strip() for ln in text.split("\n")]
    stripped = "\n".join(stripped_lines).strip()
    first_line = stripped_lines[0] if stripped_lines else ""
    content_len = sum(len(ln) for ln in stripped_lines)
    y_ratio = block.y0 / page_height if page_height > 0 else 0.5
    size_rank = _font_size_rank(block.font_size, font_sizes)
    is_short = content_len < 80 and block.line_count <= 2
    is_long_flowing = block.line_count >= 3 or content_len > 200

    # ═══ PRIORITY 1: Page-level metadata ═══

    if RE_DOC_ID.search(stripped):
        return 43

    if RE_PAGE_NUM_BARE.match(stripped) and is_short and (y_ratio < 0.10 or y_ratio > 0.85):
        return 42  # PAGE_NUMBER

    if RE_VERSION.search(stripped) and is_short and y_ratio < 0.15:
        return 45

    if y_ratio > 0.88 and RE_FILE_PATH.match(stripped):
        return 41

    if RE_FILE_PATH.match(stripped) and is_short:
        return 124

    if RE_ASTERISK.match(stripped):
        return 122
    if RE_SECTION_BREAK.match(stripped):
        return 63
    if RE_CONFIDENTIAL.search(stripped) and is_short:
        return 93

    # ═══ PRIORITY 2: Font-based titles ═══

    if block.is_bold and block.is_centered and size_rank >= 0.5 and y_ratio < 0.5:
        if RE_TOC_HEADER.match(stripped):
            return 2  # SUBTITLE
        return 1  # TITLE

    # ═══ PRIORITY 3: Long flowing text = PARAGRAPH ═══

    if is_long_flowing and not block.is_bold:
        if RE_PREAMBLE.search(first_line) and y_ratio < 0.5:
            return 10
        if RE_DEFINITION.search(stripped):
            return 13
        return 10

    # ═══ PRIORITY 4: Navigation labels ═══

    if RE_EXHIBIT.match(stripped):
        return 72
    if RE_APPENDIX.match(stripped):
        return 71
    if RE_SCHEDULE.match(stripped):
        return 73
    if RE_SIDELETTER.match(stripped):
        return 74
    if RE_ATTACHMENT.match(stripped):
        return 75

    # ═══ PRIORITY 5: Signature ═══

    if RE_SIGNATURE_LINE.search(stripped):
        return 81
    if RE_PARTY_ID.match(stripped):
        return 82
    if RE_WITNESS.match(stripped):
        return 84

    # ═══ PRIORITY 6: Notation ═══

    if RE_PROPOSAL.search(stripped) and is_short:
        return 120
    if RE_BRACKET_INSERT.search(stripped):
        return 121

    # ═══ PRIORITY 7: TOC entries ═══

    if RE_DOT_LEADER.match(first_line):
        return 70

    # ═══ PRIORITY 8: Headings by font ═══

    if block.is_bold:
        if RE_H1_PATTERN.match(stripped):
            return 3
        if block.is_allcaps and len(stripped) > 10:
            return 3
        if size_rank >= 0.5:
            return 3
        return 4  # H2

    if block.is_allcaps and size_rank >= 0.5 and len(stripped) > 15:
        if y_ratio < 0.35 and prev_type in (None, 61, 62, 42, 43, 45):
            return 1
        return 3

    # ═══ PRIORITY 9: Content-based (short text) ═══

    if RE_LIST_BULLET.match(text) and is_short:
        return 24
    if RE_DEFINITION.search(stripped) and is_short:
        return 13
    if RE_PREAMBLE.search(stripped) and y_ratio < 0.5 and is_short:
        return 10
    if RE_EFFECTIVE.search(stripped) and is_short:
        return 92
    if RE_CROSS_REF.search(stripped):
        return 50
    if RE_RATE.search(stripped) and is_short:
        return 112

    # ═══ DEFAULT ═══

    return 10


def _font_size_rank(size: float, all_sizes: List[float]) -> float:
    if not all_sizes or len(all_sizes) == 1:
        return 0.5
    idx = 0
    for i, s in enumerate(all_sizes):
        if size >= s:
            idx = i
    return idx / (len(all_sizes) - 1)


def get_page_font_sizes(page, excluded_bboxes=None) -> List[float]:
    """Return sorted list of distinct font sizes used on the page (excluding table regions)."""
    excluded = excluded_bboxes or []
    sizes = set()
    data = page.get_text("dict")
    for block in data.get("blocks", []):
        if block["type"] != 0:
            continue
        if _overlaps_any(block["bbox"], excluded):
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                if span["text"].strip():
                    sizes.add(round(span["size"], 1))
    return sorted(sizes)
