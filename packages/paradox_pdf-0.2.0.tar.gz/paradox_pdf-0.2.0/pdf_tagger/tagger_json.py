"""
tagger_json.py — Main pipeline orchestrator for PDF-to-JSON extraction.

This module is the core of the extraction pipeline. It coordinates text
extraction, font-based classification, section-tree construction, and all
post-processing steps, then writes the final JSON output.

Full pipeline (per document):
  1. PyMuPDF text extraction   — font_classifier.extract_text_blocks()
  2. Font-based classification — font_classifier.classify_block()
  3. Table extraction          — line_tables.detect_table_bboxes() +
                                 line_tables.extract_table_structured()
  4. Image & strikethrough extraction
  5. Per-page element merging  — consecutive same-type blocks merged
  6. Cross-page section tree   — _build_section_tree() nests elements under
                                 their parent heading using HEADING_DEPTH
  7. Post-processing passes    — applied to the whole tree:
       a. TOC table detection  — TABLE with a "Page" column → TOC object
       b. TOC heading grouping — runs of dot-leader entries → TOC object
       c. List grouping        — consecutive LIST_* items → LIST block
       d. Amendment grouping   — consecutive AMENDMENT_DEL → one block
       e. Condensation         — drop type_id/category; split multiline text
       f. Paragraph merging    — consecutive PARAGRAPH siblings joined
  8. Ref annotation            — _add_refs() assigns "ref" to every element

Heading hierarchy (used to build the section tree):
  TITLE (depth 0) > SUBTITLE (1) > H1 (2) > H2 (3) > H3 (4) > H4 (5)
  Navigation labels (EXHIBIT, APPENDIX, etc.) are treated as depth 0.

Ref field format:
  "(pX,lY):(pX,lY)" where p = page number (1-based), l = element index
  within that page. For heading elements the ref spans from the heading
  itself to its last descendant. Example: "(p1,l3):(p6,l2)".

Compact cell format (TABLE elements):
  Normal cell:  {"p": [row, col], "t": "text"}
  Merged cell:  {"p": [row, col, rowspan, colspan], "t": "text"}
  The "shape" field holds [n_rows, n_cols] — total grid dimensions.
"""

from __future__ import annotations

import csv
import json
import logging
import re
from io import StringIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pdf_tagger.catalog import CATALOG, get_code
from pdf_tagger.font_classifier import (
    TextBlock,
    extract_text_blocks,
    classify_block,
    get_page_font_sizes,
)
from pdf_tagger.tagger import (
    classify_line,
    _detect_strikethrough_spans,
    _detect_underline_spans,
    _extract_images,
    ANCHOR_TYPES,
    FLOW_TYPES,
    MERGEABLE_TYPES,
)

# ── Heading hierarchy ──
HEADING_DEPTH = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5}
NAV_LABELS = {71, 72, 73, 74, 75}

# ── List type mapping ──
LIST_STYLES = {
    20: "numbered",    # LIST_NUM
    21: "alpha",       # LIST_ALPHA
    22: "roman",       # LIST_ROMAN
    23: "paren",       # LIST_PAREN
    24: "bullet",      # LIST_BULLET
    25: "nested",      # LIST_NESTED
}

# ── TOC detection ──
RE_DOT_LEADER = re.compile(r'^(.+?)\s*\.[\s.]{3,}\s*(\d{1,4})\s*$')
RE_DOTS_ONLY = re.compile(r'^[\s.]+(\d{1,4})(?:[\s.]+(\d{1,4}))*[\s.]*$')


# ═══════════════════════════════════════════════════════════════════
#  TABLE PARSING
# ═══════════════════════════════════════════════════════════════════

def _parse_csv_line(line: str) -> List[str]:
    try:
        reader = csv.reader(StringIO(line))
        return [c.strip() for c in next(reader)]
    except Exception:
        return [c.strip() for c in line.split(",")]


def _parse_table_lines(raw_lines: List[str]) -> Optional[Dict[str, Any]]:
    """Parse raw table lines into structured dict. Returns None if not a real table."""
    if not raw_lines:
        return None
    first = raw_lines[0].strip()
    is_grid = first.startswith("+") or first.startswith("|")
    return _parse_grid_table(raw_lines) if is_grid else _parse_csv_table(raw_lines)


def _parse_grid_table(lines: List[str]) -> Optional[Dict[str, Any]]:
    data_rows: List[List[str]] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("+") and set(stripped) <= {"+", "-", "=", " "}:
            continue
        if stripped.startswith("|"):
            cells = [c.strip() for c in stripped.split("|")[1:-1]]
            data_rows.append(cells)
    if not data_rows:
        return None
    headers = data_rows[0]
    data = data_rows[1:] if len(data_rows) > 1 else []
    n_cols = len(headers)
    if n_cols <= 1:
        return None
    return {"headers": headers, "data": data}


def _parse_csv_table(lines: List[str]) -> Optional[Dict[str, Any]]:
    rows = [_parse_csv_line(l) for l in lines if l.strip()]
    if not rows:
        return None
    n_cols = max(len(r) for r in rows)
    if n_cols <= 1:
        return None
    headers = rows[0]
    data = rows[1:] if len(rows) > 1 else []
    for r in data:
        while len(r) < n_cols:
            r.append("")
    return {"headers": headers, "data": data}


# ═══════════════════════════════════════════════════════════════════
#  ELEMENT CONSTRUCTION
# ═══════════════════════════════════════════════════════════════════

def _make_element(
    type_id: int,
    text: str = "",
    marks: Optional[List[str]] = None,
    **extra: Any,
) -> Dict[str, Any]:
    entry = CATALOG.get(type_id, {})
    elem: Dict[str, Any] = {
        "type_id": type_id,
        "type": entry.get("code", "UNKNOWN"),
        "marks": marks if marks is not None else [],
    }
    if text:
        elem["text"] = text
    elem.update(extra)
    return elem


def _compute_marks_and_text(
    block: Any,
    strike_regions: List[Tuple[float, float, float, float]],
    underline_regions: List[Tuple[float, float, float, float]],
) -> Tuple[str, List[str]]:
    """
    Build decorated text and marks list from a TextBlock's span data.

    Applies inline markers around text based on span-level decorations:
      ~~text~~  — STRIKETHROUGH (geometric)
      ++text++  — UNDERLINE (geometric or font flag)
      **text**  — BOLD (font flag)
      *text*    — ITALIC (font flag)
      ^text^    — SUPERSCRIPT (font flag)
      `text`    — MONOSPACE (font flag)

    Returns (decorated_text, sorted_marks_list).
    """
    marks_set: set = set()

    def _span_geometric(
        sx0: float, sy0: float, sx1: float, sy1: float
    ) -> Tuple[bool, bool]:
        span_mid = (sy0 + sy1) / 2
        span_h = max(sy1 - sy0, 1.0)
        v_tol = span_h * 1.5
        struck = any(
            abs(span_mid - (ry0 + ry1) / 2) < v_tol and rx0 < sx1 + 4 and rx1 > sx0 - 4
            for rx0, ry0, rx1, ry1 in strike_regions
        )
        underlined = any(
            abs(span_mid - (ry0 + ry1) / 2) < v_tol and rx0 < sx1 + 4 and rx1 > sx0 - 4
            for rx0, ry0, rx1, ry1 in underline_regions
        )
        return struck, underlined

    parts: List[str] = []
    for span in getattr(block, "spans", []):
        t = span.text
        if not t:
            continue

        struck, underlined = _span_geometric(span.x0, span.y0, span.x1, span.y1)

        if span.is_bold:
            marks_set.add("BOLD")
        if span.is_italic:
            marks_set.add("ITALIC")
        if span.is_superscript:
            marks_set.add("SUPERSCRIPT")
        if span.is_monospace:
            marks_set.add("MONOSPACE")
        if span.is_underline_font and not underlined:
            marks_set.add("UNDERLINE")
        if struck:
            marks_set.add("STRIKETHROUGH")
        if underlined:
            marks_set.add("UNDERLINE")

        if t.strip():
            if span.is_superscript:
                t = f"^{t}^"
            if span.is_monospace:
                t = f"`{t}`"
            if struck:
                t = f"~~{t}~~"
            elif underlined or span.is_underline_font:
                t = f"++{t}++"
            if span.is_bold and span.is_italic:
                t = f"***{t}***"
            elif span.is_bold:
                t = f"**{t}**"
            elif span.is_italic:
                t = f"*{t}*"

        parts.append(t)

    text = "".join(parts).strip()
    if not text:
        text = block.text.strip()

    return text, sorted(marks_set)


_MARK_PATTERNS = [
    ("STRIKETHROUGH", r"~~.+?~~"),
    ("UNDERLINE",     r"\+\+.+?\+\+"),
    ("BOLD",          r"\*\*\*?.+?\*\*\*?"),
    ("ITALIC",        r"(?<!\*)\*(?!\*).*?(?<!\*)\*(?!\*)"),
    ("SUPERSCRIPT",   r"\^.+?\^"),
    ("MONOSPACE",     r"`[^`]+`"),
]


def _sync_marks_from_text(elem: Dict) -> None:
    """Ensure 'marks' reflects the inline markers actually present in text."""
    text = elem.get("text", "")
    if isinstance(text, list):
        text = " ".join(text)
    if not isinstance(text, str) or not text:
        return
    current = set(elem.get("marks") or [])
    for mark, pattern in _MARK_PATTERNS:
        if re.search(pattern, text):
            current.add(mark)
    elem["marks"] = sorted(current)


def _make_table_element(table_lines: List[str]) -> Optional[Dict[str, Any]]:
    parsed = _parse_table_lines(table_lines)
    if parsed is None:
        return None
    elem = _make_element(30)
    elem.update(parsed)
    elem.pop("text", None)
    return elem


def _make_image_element(img: dict) -> Dict[str, Any]:
    rect_str = img.get("rect", "")
    rect = None
    m = re.match(r"\(([.\d]+),([.\d]+),([.\d]+),([.\d]+)\)", rect_str)
    if m:
        rect = [round(float(m.group(i))) for i in range(1, 5)]
    return _make_element(
        img["type_id"],
        src=img["file"],
        width=img["width"],
        height=img["height"],
        rect=rect,
    )


# ═══════════════════════════════════════════════════════════════════
#  SECTION TREE
# ═══════════════════════════════════════════════════════════════════

def _build_section_tree(flat_elements: List[Dict]) -> List[Dict]:
    root: Dict[str, Any] = {"_depth": -1, "children": []}
    stack = [root]

    for elem in flat_elements:
        tid = elem.get("type_id")
        depth = HEADING_DEPTH.get(tid)
        if tid in NAV_LABELS:
            depth = 0

        if depth is not None:
            while len(stack) > 1 and stack[-1].get("_depth", -1) >= depth:
                stack.pop()
            elem["_depth"] = depth
            elem["children"] = []
            stack[-1]["children"].append(elem)
            stack.append(elem)
        else:
            stack[-1]["children"].append(elem)

    _strip_internal(root)
    return root.get("children", [])


def _strip_internal(node: Dict):
    node.pop("_depth", None)
    for child in node.get("children", []):
        _strip_internal(child)
    if "children" in node and not node["children"]:
        del node["children"]


# ═══════════════════════════════════════════════════════════════════
#  POST-PROCESSING PIPELINE
# ═══════════════════════════════════════════════════════════════════

def _is_toc_text(text: str) -> bool:
    """Check if text is a TOC entry (title followed by dot leaders and page number)."""
    return bool(RE_DOT_LEADER.match(text))


def _parse_toc_text(text: str) -> Optional[Dict]:
    """Extract {title, page} from a dot-leader line."""
    m = RE_DOT_LEADER.match(text)
    if m:
        title = m.group(1).strip()
        # Clean leading numbering for consistency
        return {"title": title, "page": int(m.group(2))}
    return None


def _clean_dot_leaders(text: str) -> str:
    """Strip dot-leader sequences from text."""
    return re.sub(r'\s*(?:\.\s*){3,}\s*', ' ', text).strip()


def _extract_page_numbers(text: str) -> List[int]:
    """Extract page numbers from a dots-only cell like '. . . 19 . . . 33'."""
    m = RE_DOTS_ONLY.match(text)
    if m:
        return [int(x) for x in re.findall(r'\d+', text)]
    return []


def _split_concatenated_toc_items(cell_text: str, page_numbers: List[int]) -> List[Dict]:
    """
    Split concatenated TOC items like:
    '1. Studio Minimum ... 2. Classification ...'
    with corresponding page numbers [19, 33].
    """
    # Try splitting by numbered pattern
    parts = re.split(r'(?:^|\s)(?=\d+\.\s+)', cell_text.strip())
    parts = [p.strip() for p in parts if p.strip()]

    entries = []
    for i, part in enumerate(parts):
        title = _clean_dot_leaders(part)
        # Remove section markers like §II.
        title = re.sub(r'^§\w+\.\s*', '', title).strip()
        if not title:
            continue
        entry = {"title": title}
        if i < len(page_numbers):
            entry["page"] = page_numbers[i]
        entries.append(entry)

    return entries


def _postprocess_toc_table(elem: Dict) -> Optional[Dict]:
    """
    If a TABLE looks like a TOC (headers contain 'page'), convert it
    to a TOC object with structured entries.
    """
    # Support both old format (headers/data) and new format (cells)
    cells = elem.get("cells", [])
    headers = elem.get("headers", [])
    data = elem.get("data", [])

    # Convert new cells format to headers/data for TOC detection
    if cells and isinstance(cells, list) and isinstance(cells[0], dict) and not headers:
        shape = elem.get("shape", [0, 0])
        n_rows, n_cols = shape
        if n_rows < 2 or n_cols < 1:
            return None
        # Build rows from cells
        grid = [[""] * n_cols for _ in range(n_rows)]
        for cell in cells:
            p = cell.get("p", [0, 0])
            r, c = p[0], p[1]
            if 0 <= r < n_rows and 0 <= c < n_cols:
                grid[r][c] = cell.get("t", "")
        headers = grid[0]
        data = grid[1:]

    # Detect TOC table: has a "Page" column
    page_col = None
    title_col = None
    for i, h in enumerate(headers):
        hl = h.lower().strip()
        if hl in ("page", "pg", "pg."):
            page_col = i
        elif hl in ("paragraph", "section", "article", "item", "topic", ""):
            title_col = i

    if page_col is None:
        return None

    if title_col is None:
        title_col = 0 if page_col != 0 else 1

    entries = []
    for row in data:
        title_text = row[title_col] if title_col < len(row) else ""
        page_text = row[page_col] if page_col < len(row) else ""

        # Page column might contain multiple pages separated by dots
        page_nums = _extract_page_numbers(page_text)
        if not page_nums:
            # Try to extract single number
            nums = re.findall(r'\d+', page_text)
            page_nums = [int(n) for n in nums]

        # Title column might contain multiple concatenated items
        if len(page_nums) > 1 or re.search(r'\d+\.\s+\S', title_text):
            sub_entries = _split_concatenated_toc_items(title_text, page_nums)
            if sub_entries:
                entries.extend(sub_entries)
                continue

        title = _clean_dot_leaders(title_text)
        if title:
            entry = {"title": title}
            if page_nums:
                entry["page"] = page_nums[0]
            entries.append(entry)

    if entries:
        return {"type": "TOC", "entries": entries}
    return None


def _postprocess_tables(elements: List[Dict]) -> List[Dict]:
    """Clean tables: detect TOC tables, strip dot leaders from cells."""
    result = []
    for elem in elements:
        if elem.get("type") == "TABLE":
            # Try converting to TOC
            toc = _postprocess_toc_table(elem)
            if toc:
                result.append(toc)
                continue
            # Clean dot leaders from cells (new structured format)
            cells = elem.get("cells", [])
            if isinstance(cells, list):
                for cell in cells:
                    if isinstance(cell, dict):
                        txt = cell.get("t", "")
                        if re.search(r'\.[\s.]{3,}', txt):
                            cell["t"] = _clean_dot_leaders(txt)
            # Legacy format fallback
            for row in elem.get("data", []):
                for j, cell in enumerate(row):
                    if isinstance(cell, str) and re.search(r'\.[\s.]{3,}', cell):
                        row[j] = _clean_dot_leaders(cell)
            result.append(elem)
        else:
            if "children" in elem:
                elem["children"] = _postprocess_tables(elem["children"])
            result.append(elem)
    return result


def _clean_toc_entry_text(text: str) -> str:
    """Remove trailing standalone numbers (e.g., '\\n2.' or '\\n12') from TOC entry text."""
    # Remove trailing lines that are just a number (leftover from next entry)
    cleaned = re.sub(r'\n\s*\d{1,3}\.?\s*$', '', text)
    return cleaned.strip()


def _is_toc_candidate(elem: Dict) -> bool:
    """Check if element is a TOC entry — by type or by dot-leader text."""
    if elem.get("type") == "TOC_ENTRY":
        return True
    if elem.get("type") in ("H1", "H2", "H3", "H4"):
        text = _clean_toc_entry_text(elem.get("text", ""))
        return _is_toc_text(text)
    return False


RE_STANDALONE_NUM = re.compile(r'^\d{1,3}\.?\s*$')


def _is_toc_number(elem: Dict) -> bool:
    """Check if element is a standalone number like '1.', '2.', '12'."""
    return bool(RE_STANDALONE_NUM.match(elem.get("text", "").strip()))


def _group_toc_headings(elements: List[Dict]) -> List[Dict]:
    """
    Detect consecutive TOC entries (by type or dot-leader pattern)
    and group them into a single {"type": "TOC", "entries": [...]}.

    Handles interleaved patterns like:
      PARAGRAPH "1." → TOC_ENTRY "Scope..." → PARAGRAPH "2." → TOC_ENTRY "Recognition..."
    by absorbing standalone numbers and merging them with the following entry.
    """
    result = []
    toc_buf: List[Dict] = []

    def flush_toc():
        nonlocal toc_buf
        if not toc_buf:
            return
        # Filter: only keep actual TOC entries (skip standalone numbers already merged)
        entries = []
        pending_num = None
        for e in toc_buf:
            text = _clean_toc_entry_text(e.get("text", ""))
            if RE_STANDALONE_NUM.match(text.strip()):
                pending_num = text.strip()
                continue
            parsed = _parse_toc_text(text)
            if parsed:
                if pending_num:
                    parsed["title"] = pending_num + " " + parsed["title"]
                    pending_num = None
                entries.append(parsed)
            else:
                title = _clean_dot_leaders(text)
                if title:
                    if pending_num:
                        title = pending_num + " " + title
                        pending_num = None
                    entries.append({"title": title})

        if len(entries) >= 2:
            result.append({"type": "TOC", "entries": entries})
        elif entries:
            # Single entry — keep as flat element
            result.append({"type": "TOC", "entries": entries})
        else:
            result.extend(toc_buf)
        toc_buf = []

    for elem in elements:
        if _is_toc_candidate(elem):
            # Absorb children that are also TOC entries or numbers
            children = elem.get("children", [])
            if children:
                non_toc_children = []
                for child in children:
                    child_text = _clean_toc_entry_text(child.get("text", ""))
                    if (_is_toc_text(child_text)
                            or child.get("type") == "TOC_ENTRY"
                            or _is_toc_number(child)):
                        toc_buf.append(child)
                    else:
                        non_toc_children.append(child)
                if non_toc_children:
                    elem["children"] = non_toc_children
                else:
                    elem.pop("children", None)
            toc_buf.append(elem)
        elif _is_toc_number(elem) and toc_buf:
            # Standalone number following TOC entries — absorb it
            toc_buf.append(elem)
        else:
            flush_toc()
            if "children" in elem:
                elem["children"] = _group_toc_headings(elem["children"])
            # Also check: if this elem has children that are mostly TOC, group them
            if "children" in elem:
                elem["children"] = _group_mixed_toc_children(elem["children"])
            result.append(elem)

    flush_toc()
    return result


def _group_mixed_toc_children(children: List[Dict]) -> List[Dict]:
    """
    Within a heading's children, group runs of TOC_ENTRY + standalone numbers
    into TOC objects. Handles interleaved number/entry patterns.
    """
    result = []
    toc_buf: List[Dict] = []

    def flush():
        nonlocal toc_buf
        if not toc_buf:
            return
        entries = []
        pending_num = None
        for e in toc_buf:
            text = _clean_toc_entry_text(e.get("text", ""))
            if RE_STANDALONE_NUM.match(text.strip()):
                pending_num = text.strip()
                continue
            parsed = _parse_toc_text(text)
            if parsed:
                if pending_num:
                    parsed["title"] = pending_num + " " + parsed["title"]
                    pending_num = None
                entries.append(parsed)
            else:
                title = _clean_dot_leaders(text)
                if title:
                    if pending_num:
                        title = pending_num + " " + title
                        pending_num = None
                    entries.append({"title": title})

        if len(entries) >= 2:
            result.append({"type": "TOC", "entries": entries})
        else:
            result.extend(toc_buf)
        toc_buf = []

    for elem in children:
        is_entry = elem.get("type") == "TOC_ENTRY" or (
            _is_toc_text(_clean_toc_entry_text(elem.get("text", "")))
        )
        is_num = _is_toc_number(elem)

        if is_entry or is_num:
            toc_buf.append(elem)
        else:
            flush()
            result.append(elem)

    flush()
    return result


def _group_consecutive_lists(elements: List[Dict]) -> List[Dict]:
    """Group consecutive list items of the same style into a single LIST block."""
    result = []
    list_buf: List[str] = []
    list_style: Optional[str] = None

    def flush_list():
        nonlocal list_buf, list_style
        if len(list_buf) >= 2:
            result.append({"type": "LIST", "style": list_style, "items": list_buf})
        elif list_buf:
            # Single item — keep as-is but simplified
            result.append({"type": "LIST", "style": list_style, "items": list_buf})
        list_buf = []
        list_style = None

    for elem in elements:
        tid = elem.get("type_id")
        style = LIST_STYLES.get(tid)

        if style:
            if list_style == style:
                list_buf.append(elem.get("text", ""))
            else:
                flush_list()
                list_style = style
                list_buf.append(elem.get("text", ""))
        else:
            flush_list()
            if "children" in elem:
                elem["children"] = _group_consecutive_lists(elem["children"])
            result.append(elem)

    flush_list()
    return result


def _group_consecutive_amendments(elements: List[Dict]) -> List[Dict]:
    """Group consecutive AMENDMENT_DEL into a single block with lines[]."""
    result = []
    del_buf: List[str] = []

    def flush_del():
        nonlocal del_buf
        if len(del_buf) >= 2:
            result.append({"type": "AMENDMENT_DEL", "marks": ["STRIKETHROUGH"], "lines": del_buf})
        elif del_buf:
            result.append({"type": "AMENDMENT_DEL", "marks": ["STRIKETHROUGH"], "text": del_buf[0]})
        del_buf = []

    for elem in elements:
        if elem.get("type") == "AMENDMENT_DEL":
            del_buf.append(elem.get("text", ""))
        else:
            flush_del()
            if "children" in elem:
                elem["children"] = _group_consecutive_amendments(elem["children"])
            result.append(elem)

    flush_del()
    return result


def _condense_tree(elements: List[Dict]) -> List[Dict]:
    """
    Final pass: remove internal fields, condense tables.

    Tables become:
      {"type": "TABLE", "shape": [rows, cols], "data": [[h1,h2],[r1c1,r1c2],...]}
      - shape = [total_rows_including_header, cols]
      - data[0] = headers, data[1:] = rows
      - Empty columns stripped
      - No separate headers/format/rows/cols/cells fields
    """
    result = []
    for elem in elements:
        # Drop internal fields
        elem.pop("type_id", None)
        elem.pop("category", None)
        elem.pop("_bbox", None)
        elem.pop("_source", None)

        if elem.get("type") == "TABLE":
            elem.pop("format", None)
            elem.pop("rows", None)
            elem.pop("cols", None)

            # New compact format: cells with "p" and "t"
            if "cells" in elem and isinstance(elem["cells"], list) and elem["cells"] and isinstance(elem["cells"][0], dict) and "p" in elem["cells"][0]:
                # Already in compact format — keep as-is
                pass
            else:
                # Legacy format: headers + data rows → convert to compact cells
                headers = elem.pop("headers", [])
                data_rows = elem.pop("data", [])
                all_rows = [headers] + data_rows if headers else data_rows
                n_cols = max((len(r) for r in all_rows), default=0)
                for r in all_rows:
                    while len(r) < n_cols:
                        r.append("")
                cells = []
                for ri, row in enumerate(all_rows):
                    for ci, cell_text in enumerate(row):
                        if cell_text.strip():
                            cells.append({"p": [ri, ci], "t": cell_text})
                elem["cells"] = cells
                elem["shape"] = [len(all_rows), n_cols]

        # Condense images: rect as array, drop redundant fields
        if elem.get("type") in ("IMAGE", "SIGNATURE_IMG", "LOGO", "STAMP", "CHART"):
            # Already using [x0,y0,x1,y1] array format
            pass

        # Ensure every element has a marks field (TOC/LIST are built outside _make_element)
        if "marks" not in elem:
            elem["marks"] = []

        # Multi-line text → array of lines (much more readable in JSON)
        text = elem.get("text")
        if isinstance(text, str) and "\n" in text:
            elem["text"] = text.split("\n")

        # Sync marks with inline markers actually present in text
        _sync_marks_from_text(elem)

        # Recurse into children
        if "children" in elem:
            elem["children"] = _condense_tree(elem["children"])
        result.append(elem)
    return result


def _append_text(elem: Dict, new_text):
    """Append text lines to an element's text field."""
    prev_text = elem.get("text", "")
    if isinstance(new_text, list):
        lines = new_text
    else:
        lines = [new_text]
    if isinstance(prev_text, list):
        prev_text.extend(lines)
    elif prev_text:
        elem["text"] = [prev_text] + lines
    else:
        elem["text"] = lines


def _update_ref_end(elem: Dict, other: Dict):
    """Extend elem's ref to cover other's ref end."""
    prev_ref = elem.get("ref", "")
    curr_ref = other.get("ref", "")
    if prev_ref and curr_ref:
        start = prev_ref.split(":")[0]
        end = curr_ref.split(":")[-1]
        elem["ref"] = f"{start}:{end}"


def _merge_consecutive_paragraphs(elements: List[Dict]) -> List[Dict]:
    """Merge consecutive PARAGRAPH siblings into one element.
    PAGE_NUMBER between paragraphs becomes an inline marker [--- page N ---]."""
    result = []
    for elem in elements:
        if "children" in elem:
            elem["children"] = _merge_consecutive_paragraphs(elem["children"])

        etype = elem.get("type")

        # PAGE_NUMBER between paragraphs: absorb into previous paragraph as inline marker
        if (etype == "PAGE_NUMBER"
                and result
                and result[-1].get("type") == "PARAGRAPH"
                and "children" not in result[-1]):
            page_text = elem.get("text", "").strip().strip("-").strip()
            _append_text(result[-1], f"[--- page {page_text} ---]")
            _update_ref_end(result[-1], elem)
            continue

        # Consecutive PARAGRAPHs: merge
        if (etype == "PARAGRAPH"
                and result
                and result[-1].get("type") == "PARAGRAPH"
                and "children" not in elem
                and "children" not in result[-1]):
            _append_text(result[-1], elem.get("text", ""))
            _update_ref_end(result[-1], elem)
            continue

        result.append(elem)
    return result


def _bbox_iou(a: Tuple[float, float, float, float],
              b: Tuple[float, float, float, float]) -> float:
    """IoU between two (x0, y0, x1, y1) bboxes."""
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0 = max(ax0, bx0); iy0 = max(ay0, by0)
    ix1 = min(ax1, bx1); iy1 = min(ay1, by1)
    iw = max(0.0, ix1 - ix0); ih = max(0.0, iy1 - iy0)
    inter = iw * ih
    a_area = max(0.0, ax1 - ax0) * max(0.0, ay1 - ay0)
    b_area = max(0.0, bx1 - bx0) * max(0.0, by1 - by0)
    u = a_area + b_area - inter
    return inter / u if u > 0 else 0.0


def _table_quality_score(elem: Dict) -> float:
    """Heuristic quality for a TABLE element: reward non-empty cells,
    penalize absurd merge ratios. Higher is better."""
    cells = elem.get("cells") or []
    shape = elem.get("shape") or [0, 0]
    total = max(1, int(shape[0]) * int(shape[1]))
    n_cells = len(cells)
    n_non_empty = 0
    n_merged = 0
    for c in cells:
        t = (c.get("t") or "").strip() if isinstance(c, dict) else ""
        if t:
            n_non_empty += 1
        p = c.get("p") if isinstance(c, dict) else None
        if isinstance(p, (list, tuple)) and len(p) == 4:
            if (p[2] or 1) > 1 or (p[3] or 1) > 1:
                n_merged += 1
    fill = n_non_empty / total
    merge_ratio = n_merged / max(1, n_cells)
    # Source priority: vectorial > vision_table (TATR) > hdbscan
    src = elem.get("_source", "")
    from pdf_tagger.config import get_config as _get_config
    _vb = _get_config().src_bonus_vectorial
    src_bonus = {"vectorial": _vb, "vision_table": _vb * 0.33, "hdbscan_fullpage": 0.0}.get(src, 0.0)
    penalty = 2.0 * max(0.0, merge_ratio - 0.4)  # only penalize beyond 40%
    return fill * 1.0 + src_bonus - penalty


def _dedupe_tables(events: List[Tuple[float, Dict]],
                   iou_threshold: float = 0.5) -> List[Tuple[float, Dict]]:
    """Suppress duplicate TABLE events (same region detected by multiple
    pipelines: vectorial + vision + HDBSCAN). Keep the highest-quality one.

    Non-table events are passed through untouched.
    """
    tables = [(i, y, e) for i, (y, e) in enumerate(events) if e.get("type_id") == 30 and e.get("_bbox")]
    if len(tables) < 2:
        return events

    # Greedy grouping by IoU
    suppressed: set = set()
    for i in range(len(tables)):
        if tables[i][0] in suppressed:
            continue
        for j in range(i + 1, len(tables)):
            if tables[j][0] in suppressed:
                continue
            iou = _bbox_iou(tables[i][2]["_bbox"], tables[j][2]["_bbox"])
            if iou >= iou_threshold:
                si = _table_quality_score(tables[i][2])
                sj = _table_quality_score(tables[j][2])
                if sj > si:
                    suppressed.add(tables[i][0])
                    break
                else:
                    suppressed.add(tables[j][0])

    if not suppressed:
        return events
    logger.info("Table dedup: suppressed %d duplicate(s) of %d", len(suppressed), len(tables))
    return [ev for k, ev in enumerate(events) if k not in suppressed]


def _postprocess_page(elements: List[Dict]) -> List[Dict]:
    """Run the full post-processing pipeline on a page's element tree."""
    elements = _postprocess_tables(elements)
    elements = _group_toc_headings(elements)
    elements = _group_consecutive_lists(elements)
    elements = _group_consecutive_amendments(elements)
    elements = _condense_tree(elements)
    elements = _merge_consecutive_paragraphs(elements)
    return elements


# ═══════════════════════════════════════════════════════════════════
#  PAGE PROCESSING
# ═══════════════════════════════════════════════════════════════════

def tag_page_json(
    page,
    page_idx: int,
    page_count: int,
    images_dir: Path,
    pdf_name: str,
    no_images: bool = False,
    force_mode: str = None,
) -> List[Dict]:
    """
    Extract and classify all elements on a single PDF page.

    Processing order per page:
      1. Images extracted and positioned by y-coordinate.
      2. Strikethrough spans detected via drawing analysis.
      3. Table bboxes detected (vector lines); each table extracted as
         structured cells with colspan/rowspan via extract_table_structured().
      4. Text blocks extracted (excluding table regions) and classified by
         classify_block() using font metadata and content patterns.
      5. All events (text, tables, images, strikethroughs) merged by y-position.
      6. Consecutive same-type blocks merged where appropriate (e.g. paragraphs).

    Returns a flat list of element dicts (section tree not yet built). Each
    element carries internal "_page" and "_line" fields consumed by _add_refs()
    and _build_section_tree() in the document-level step.

    Args:
        page:       PyMuPDF page object.
        page_idx:   0-based page index.
        page_count: Total page count (used for context).
        images_dir: Directory where extracted images are saved.
        pdf_name:   PDF stem name (used for image filenames).
        no_images:  If True, skip image extraction.
    """
    page_height = page.rect.height or 800

    # 1. Extract images
    image_events: List[Tuple[float, Dict]] = []
    if not no_images:
        images = _extract_images(page, page_idx, images_dir, pdf_name)
        for img in images:
            image_events.append((img["y_pos"], _make_image_element(img)))

    # 2. Detect strikethrough
    strikes = _detect_strikethrough_spans(page)
    strike_events: List[Tuple[float, Dict]] = []
    strike_regions: List[Tuple[float, float, float, float]] = []
    for sx0, sy0, sx1, sy1, stxt in strikes:
        elem = _make_element(15, text=stxt, marks=["STRIKETHROUGH"])
        strike_events.append(((sy0 + sy1) / 2, elem))
        strike_regions.append((sx0, sy0, sx1, sy1))

    # 2b. Detect underlines (for inline marks)
    underlines = _detect_underline_spans(page)
    underline_regions: List[Tuple[float, float, float, float]] = [
        (ux0, uy0, ux1, uy1) for ux0, uy0, ux1, uy1, _ in underlines
    ]

    # 3. Extract tables: vector grid + OpenCV span detection
    from pdf_grid.line_tables import detect_table_bboxes, extract_table_structured
    table_events: List[Tuple[float, Dict]] = []

    try:
        table_bboxes_found = detect_table_bboxes(page)
    except Exception:
        table_bboxes_found = []

    for bb in table_bboxes_found:
        table_dicts = extract_table_structured(page, bb)
        for td in table_dicts:
            cells = td.get("cells", [])
            if not cells:
                continue
            elem = _make_element(30)
            elem.pop("text", None)
            elem["shape"] = td["shape"]
            elem["cells"] = cells
            elem["_bbox"] = tuple(float(v) for v in bb[:4])  # for NMS dedup
            elem["_source"] = "vectorial"
            table_events.append((bb[1], elem))

    # 4. Detect if page is scanned → route to appropriate pipeline
    from pdf_tagger.scan_detector import is_page_scanned

    _scanned = is_page_scanned(page)
    if force_mode == "heuristic":
        _scanned = False
    elif force_mode == "vision":
        _scanned = True

    text_events: List[Tuple[float, Dict]] = []

    if not _scanned:
        # ═══ DIGITAL PATH: v2 heuristic (full marks from font flags) ═══

        try:
            table_bboxes = detect_table_bboxes(page)
        except Exception:
            table_bboxes = []

        text_blocks = extract_text_blocks(page, excluded_bboxes=table_bboxes)
        font_sizes = get_page_font_sizes(page, excluded_bboxes=table_bboxes)
        prev_type = None

        for block in text_blocks:
            block_mid_y = (block.y0 + block.y1) / 2
            block_h = block.y1 - block.y0

            overlapping_strikes = [
                r for r in strike_regions
                if abs(block_mid_y - (r[1] + r[3]) / 2) < block_h
            ]
            overlapping_underlines = [
                r for r in underline_regions
                if abs(block_mid_y - (r[1] + r[3]) / 2) < block_h
            ]
            has_strike = bool(overlapping_strikes)
            has_underline = bool(overlapping_underlines)

            if has_strike and not has_underline:
                total_span_chars = sum(len(s.text.strip()) for s in block.spans)
                if total_span_chars == 0:
                    continue
                strike_chars = sum(
                    len(s.text.strip())
                    for s in block.spans
                    if any(
                        abs((s.y0 + s.y1) / 2 - (r[1] + r[3]) / 2) < max(s.y1 - s.y0, 1.0)
                        and r[0] <= s.x1 + 2
                        and r[2] >= s.x0 - 2
                        for r in overlapping_strikes
                    )
                )
                strike_coverage = strike_chars / total_span_chars
                if strike_coverage > 0.85:
                    candidate_type = classify_block(block, page_height, font_sizes, prev_type)
                    if candidate_type in (1, 2, 3, 4, 5, 6):
                        decorated_text, marks = _compute_marks_and_text(
                            block, strike_regions, underline_regions
                        )
                        elem = _make_element(candidate_type, text=decorated_text, marks=marks)
                        text_events.append((block.y0, elem))
                        prev_type = candidate_type
                    continue

            decorated_text, marks = _compute_marks_and_text(block, strike_regions, underline_regions)
            type_id = classify_block(block, page_height, font_sizes, prev_type)
            elem = _make_element(type_id, text=decorated_text, marks=marks)
            text_events.append((block.y0, elem))
            prev_type = type_id

    else:
        # ═══ SCANNED PATH: YOLO + OCR + TexTAR marks ═══

        try:
            from pdf_tagger.vision_layout import process_scanned_page
            from pdf_tagger.marks_vision import get_marks_detector
            marks_detector = get_marks_detector()
        except Exception as e:
            logger.warning("Vision pipeline unavailable: %s — falling back to heuristic", e)
            marks_detector = None

        if marks_detector is not None:
            try:
                scanned_elements = process_scanned_page(
                    page, page_idx, page_count, marks_detector
                )
                for se in scanned_elements:
                    extra: Dict[str, Any] = {}
                    if se["type_id"] == 30:  # TABLE from table_vision
                        if "shape" in se:
                            extra["shape"] = se["shape"]
                        if "cells" in se:
                            extra["cells"] = se["cells"]
                    elem = _make_element(
                        se["type_id"],
                        text=se.get("decorated_text", se.get("text", "")),
                        marks=se.get("marks", []),
                        **extra,
                    )
                    # Attach bbox + source for table dedup (NMS)
                    if se["type_id"] == 30 and "bbox" in se:
                        elem["_bbox"] = tuple(float(v) for v in se["bbox"])
                        elem["_source"] = se.get("source", "vision")
                    text_events.append((se["y0"], elem))
            except Exception as e:
                logger.warning("Scanned page processing failed: %s", e)
        else:
            # Fallback: treat as digital even though scan detected
            try:
                table_bboxes = detect_table_bboxes(page)
            except Exception:
                table_bboxes = []
            text_blocks = extract_text_blocks(page, excluded_bboxes=table_bboxes)
            font_sizes = get_page_font_sizes(page, excluded_bboxes=table_bboxes)
            prev_type = None
            for block in text_blocks:
                decorated_text, marks = _compute_marks_and_text(
                    block, strike_regions, underline_regions
                )
                type_id = classify_block(block, page_height, font_sizes, prev_type)
                elem = _make_element(type_id, text=decorated_text, marks=marks)
                text_events.append((block.y0, elem))
                prev_type = type_id

    # 8. Merge all events by y-position
    all_events = text_events + table_events + image_events + strike_events
    # Dedupe duplicate TABLE detections (vectorial + vision + HDBSCAN on same region)
    from pdf_tagger.config import get_config as _get_config
    all_events = _dedupe_tables(all_events, iou_threshold=_get_config().dedup_iou_threshold)
    all_events.sort(key=lambda z: z[0])

    # 9. Final merge: consecutive paragraphs with same type
    merged: List[Dict] = []
    prev_elem: Optional[Dict] = None

    def _flush():
        nonlocal prev_elem
        if prev_elem is not None:
            merged.append(prev_elem)
            prev_elem = None

    for _, elem in all_events:
        tid = elem.get("type_id")

        # Tables, images always standalone
        if elem.get("headers") is not None or tid in (100, 101, 102, 103, 104):
            _flush()
            merged.append(elem)
            continue

        # Same paragraph type merges (but not into titles/subtitles)
        if tid == 10 and prev_elem and prev_elem.get("type_id") == 10:
            prev_elem["text"] += "\n" + elem.get("text", "")
            continue

        # Flow absorbed by anchor — but NOT into TITLE/SUBTITLE
        # (titles should stand alone; paragraphs become children via tree builder)
        prev_tid = prev_elem.get("type_id") if prev_elem else None
        if (tid in FLOW_TYPES and prev_tid in ANCHOR_TYPES
                and prev_tid not in (1, 2)):  # exclude TITLE, SUBTITLE
            prev_elem["text"] += "\n" + elem.get("text", "")
            continue

        _flush()
        if tid in MERGEABLE_TYPES:
            prev_elem = elem
        else:
            merged.append(elem)

    _flush()

    # Annotate each element with page number and line index
    page_num = page_idx + 1
    for i, elem in enumerate(merged):
        elem["_page"] = page_num
        elem["_line"] = i + 1

    return merged


# ═══════════════════════════════════════════════════════════════════
#  DOCUMENT PROCESSING
# ═══════════════════════════════════════════════════════════════════

def _compute_ref(elem: Dict) -> str:
    """Compute ref string from _page/_line annotations: 'p1:1-p3:45'."""
    p_start = elem.get("_page", 1)
    l_start = elem.get("_line", 1)
    p_end = p_start
    l_end = l_start

    def _extend(nodes):
        nonlocal p_end, l_end
        for n in nodes:
            np = n.get("_page", p_start)
            nl = n.get("_line", l_start)
            if np > p_end or (np == p_end and nl > l_end):
                p_end, l_end = np, nl
            _extend(n.get("children", []))
    _extend(elem.get("children", []))

    return f"(p{p_start},l{l_start}):(p{p_end},l{l_end})"


def _add_refs(elements: List[Dict]):
    """Add ref key and remove internal _page/_line from all elements recursively."""
    for elem in elements:
        elem["ref"] = _compute_ref(elem)
        elem.pop("_page", None)
        elem.pop("_line", None)
        if "children" in elem:
            _add_refs(elem["children"])


def tag_pdf_json(pdf_path: str, output_path: str, images_dir: str, pages: tuple = None, no_images: bool = False, force_mode: str = None) -> dict:
    """Extract all elements from a PDF and write a hierarchical JSON file.

    Entry point called by convert.py (and directly in tests). Runs the full
    pipeline: per-page extraction → section tree → post-processing → JSON.

    Output JSON keys:
      "source"         — original PDF filename
      "total_pages"    — page count in the document
      "total_elements" — total element count (including list/TOC sub-items)
      "total_images"   — number of extracted image files
      "type_summary"   — dict mapping element type code → count
      "elements"       — list of top-level elements, each possibly with
                         "children" (heading subtree) and a "ref" field

    Args:
        pdf_path:    Path to the input PDF file.
        output_path: Destination path for the output JSON file.
        images_dir:  Directory where extracted images (PNG) are saved.
        pages:       Optional tuple of 1-based page numbers to restrict
                     extraction. If None, all pages are processed.
        no_images:   If True, skip image extraction entirely.

    Returns:
        Stats dict: {"pages": N, "elements": N, "type_counts": {...}, "images": N}
    """
    pdf_path = Path(pdf_path)
    output_path = Path(output_path)
    images_dir = Path(images_dir)
    images_dir.mkdir(parents=True, exist_ok=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    pdf_name = pdf_path.stem

    doc = fitz.open(str(pdf_path))
    try:
        page_count = doc.page_count
        all_elements: List[Dict] = []

        page_indices = range(page_count)
        if pages:
            page_indices = [p - 1 for p in pages if 1 <= p <= page_count]

        for i in page_indices:
            page = doc.load_page(i)
            page_elems = tag_page_json(page, i, page_count, images_dir, pdf_name, no_images=no_images, force_mode=force_mode)
            all_elements.extend(page_elems)

        # Build section tree across entire document
        tree = _build_section_tree(all_elements)

        # Post-process
        tree = _postprocess_page(tree)

        # Add ref annotations and remove internal fields
        _add_refs(tree)

        # Compute stats
        type_counts: Dict[str, int] = {}
        total_elements = 0

        def _count(nodes: List[Dict]):
            nonlocal total_elements
            for node in nodes:
                t = node.get("type", "")
                if t:
                    type_counts[t] = type_counts.get(t, 0) + 1
                    total_elements += 1
                _count(node.get("children", []))
                items = node.get("items", [])
                if items and t == "LIST":
                    total_elements += len(items) - 1
                lines = node.get("lines", [])
                if lines and t == "AMENDMENT_DEL":
                    total_elements += len(lines) - 1
                entries = node.get("entries", [])
                if entries and t == "TOC":
                    total_elements += len(entries) - 1

        _count(tree)

        document = {
            "source": pdf_path.name,
            "total_pages": page_count,
            "total_elements": total_elements,
            "total_images": len(list(images_dir.glob(f"{pdf_name}_*.png"))),
            "type_summary": type_counts,
            "elements": tree,
        }

        output_path.write_text(
            json.dumps(document, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        return {
            "pages": page_count,
            "elements": total_elements,
            "type_counts": type_counts,
            "images": document["total_images"],
        }
    finally:
        doc.close()
