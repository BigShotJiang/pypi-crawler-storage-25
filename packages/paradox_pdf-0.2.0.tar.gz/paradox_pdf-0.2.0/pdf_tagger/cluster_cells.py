"""
cluster_cells.py — HDBSCAN-based borderless table cell inference.

Stage 3 of the pdf-robust pipeline.  Infers table row/column structure
from the geometric distribution of OCR word bounding boxes rather than
from their text content, making it robust to:

  - Page warping / phone-camera distortion (variable y-shifts)
  - Unknown table types (no keyword-header matching required)
  - Multi-DPI documents (no fixed-pixel epsilon to tune)

Algorithm (§3 of docs/research/07_clustering_cells.md):
  1. Filter low-confidence / empty words.
  2. Run 1-D HDBSCAN on word centre-y  → row clusters.
  3. Split rows into table regions by large vertical gaps.
  4. Per region: run 1-D HDBSCAN on centre-x → column clusters.
  5. Build (row, col) → [words] grid; assign noise words to nearest cluster.
  6. Detect merged cells by geometric width heuristic.
  7. Accept region as table when fill_rate ≥ 0.40, cols ≥ 2, rows ≥ 3.

Requires:
    scikit-learn >= 1.3   (sklearn.cluster.HDBSCAN)
    scipy                 (gaussian_kde, find_peaks)
    numpy
"""
from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.signal import find_peaks
from scipy.stats import gaussian_kde
from sklearn.cluster import HDBSCAN

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Data classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Word:
    x0: float
    y0: float
    x1: float
    y1: float
    text: str
    conf: float = 100.0

    @property
    def cx(self) -> float:
        return (self.x0 + self.x1) / 2.0

    @property
    def cy(self) -> float:
        return (self.y0 + self.y1) / 2.0

    @property
    def width(self) -> float:
        return self.x1 - self.x0


@dataclass
class Cell:
    row: int
    col: int
    text: str
    col_span: int = 1
    row_span: int = 1


@dataclass
class Table:
    n_rows: int
    n_cols: int
    cells: List[Cell] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
#  Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _cluster_1d(values: np.ndarray, min_cluster_size: int = 2) -> np.ndarray:
    """Run HDBSCAN on a 1-D coordinate array; return integer cluster labels."""
    if len(values) < 2:
        return np.zeros(len(values), dtype=int)
    model = HDBSCAN(
        min_cluster_size=min_cluster_size,
        min_samples=1,
        metric="euclidean",
        cluster_selection_method="eom",
    )
    return model.fit_predict(values.reshape(-1, 1))


def _sorted_cluster_map(values: np.ndarray, labels: np.ndarray) -> Dict[int, int]:
    """Map raw HDBSCAN labels → positional indices sorted by median coordinate.

    E.g. the cluster whose median is smallest gets index 0.
    Noise label (-1) is excluded.
    """
    unique = [lb for lb in set(labels) if lb != -1]
    medians = {lb: float(np.median(values[labels == lb])) for lb in unique}
    ordered = sorted(unique, key=lambda lb: medians[lb])
    return {raw: idx for idx, raw in enumerate(ordered)}


def _cluster_medians(values: np.ndarray, labels: np.ndarray,
                     label_map: Dict[int, int]) -> Dict[int, float]:
    """Return {positional_idx: median_coordinate} for each valid cluster."""
    return {
        idx: float(np.median(values[labels == raw]))
        for raw, idx in label_map.items()
    }


def _nearest(value: float, medians: Dict[int, float]) -> int:
    """Return the positional index whose median is closest to *value*."""
    return min(medians, key=lambda k: abs(medians[k] - value))


def _kde_col_count(cx: np.ndarray, page_width: float) -> int:
    """Estimate column count from KDE peak detection on x-positions."""
    if len(cx) < 4:
        return len(cx)
    try:
        kde = gaussian_kde(cx, bw_method="scott")
        x_grid = np.linspace(0.0, page_width, 2000)
        density = kde(x_grid)
        peaks, _ = find_peaks(density, prominence=density.max() * 0.05)
        return max(1, len(peaks))
    except Exception:
        return 1


def _detect_merged_cells(
    grid: Dict[Tuple[int, int], List[Word]],
    col_medians: Dict[int, float],
    n_cols: int,
) -> Dict[Tuple[int, int], int]:
    """Return {(row, col): col_span} for cells that span > 1 column.

    Heuristic: a cell is merged when its word bounding-box width exceeds
    1.6× the median column pitch and the adjacent column(s) are empty.
    The 1.6 threshold gives ~10 % margin below a 2-column merge
    (1 pitch + 1 gap ≈ 1.8×).
    """
    if len(col_medians) < 2:
        return {}

    pitches = [
        col_medians[c + 1] - col_medians[c]
        for c in range(n_cols - 1)
        if c in col_medians and c + 1 in col_medians
    ]
    if not pitches:
        return {}

    median_pitch = float(np.median(pitches))
    spans: Dict[Tuple[int, int], int] = {}

    for (r, c), words in grid.items():
        if not words:
            continue
        cx_min = min(w.cx for w in words)
        cx_max = max(w.cx for w in words)
        w_max = max(w.width for w in words)
        cell_w = (cx_max - cx_min) + w_max
        if cell_w > 1.6 * median_pitch:
            raw_span = max(1, round(cell_w / median_pitch))
            span = 1
            for s in range(1, raw_span):
                if grid.get((r, c + s)):
                    break
                span = s + 1
            if span > 1:
                spans[(r, c)] = span

    return spans


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def infer_table_cells(
    words: List[Word],
    page_width: float = 595.0,
    min_conf: float = 30.0,
    large_gap_factor: float = 2.0,
    min_fill_rate: float = 0.40,
    min_cols: int = 2,
    min_rows: int = 3,
) -> List[Table]:
    """Infer borderless table structure from OCR word bounding boxes.

    Args:
        words:            OCR words with bbox (x0,y0,x1,y1), text, conf.
        page_width:       Page width in the same unit as word coordinates.
                          Used only for the KDE x-grid; does not need to
                          be pixel-exact.
        min_conf:         Minimum OCR confidence; words below this are dropped.
        large_gap_factor: Multiple of median row height that triggers a new
                          table region (vertical gap segmentation).
        min_fill_rate:    Minimum fraction of (row, col) slots that must be
                          non-empty for a region to be accepted as a table.
        min_cols:         Minimum number of columns required.
        min_rows:         Minimum number of rows required.

    Returns:
        List of Table objects (may be empty if no valid table is found).
    """
    # ── 1. Filter ─────────────────────────────────────────────────────────────
    words = [w for w in words if w.conf >= min_conf and w.text.strip()]
    if len(words) < min_rows * min_cols:
        return []

    cy_arr = np.array([w.cy for w in words])
    cx_arr = np.array([w.cx for w in words])

    # ── 2. Row clustering ─────────────────────────────────────────────────────
    row_labels_raw = _cluster_1d(cy_arr, min_cluster_size=2)
    row_map = _sorted_cluster_map(cy_arr, row_labels_raw)

    if not row_map:
        # All words are noise — fall back to single-row assumption
        row_map = {0: 0}

    row_medians = _cluster_medians(cy_arr, row_labels_raw, row_map)
    n_rows_total = len(row_medians)

    if n_rows_total < min_rows:
        return []

    # Assign every word a row index (noise words go to nearest row)
    row_indices = np.array([
        row_map[lb] if lb != -1 else _nearest(cy_arr[i], row_medians)
        for i, lb in enumerate(row_labels_raw)
    ])

    # ── 3. Table region segmentation by vertical gap ──────────────────────────
    row_ys = [row_medians[r] for r in range(n_rows_total)]
    gaps = [row_ys[r + 1] - row_ys[r] for r in range(n_rows_total - 1)]

    median_row_h = float(np.median([w.y1 - w.y0 for w in words]))
    gap_ref = float(np.median(gaps)) if gaps else median_row_h
    threshold = large_gap_factor * max(median_row_h, gap_ref)

    # Build contiguous row-index groups
    regions: List[List[int]] = []
    current: List[int] = [0]
    for r in range(n_rows_total - 1):
        if gaps[r] > threshold:
            regions.append(current)
            current = []
        current.append(r + 1)
    regions.append(current)

    tables: List[Table] = []

    for region_rows in regions:
        if len(region_rows) < min_rows:
            continue

        mask = np.isin(row_indices, region_rows)
        words_r: List[Word] = [w for w, m in zip(words, mask) if m]
        cx_r = cx_arr[mask]
        row_idx_r = row_indices[mask]

        if len(words_r) < min_rows * min_cols:
            continue

        # ── 4. Column clustering ──────────────────────────────────────────────
        _kde_col_count(cx_r, page_width)   # informational only for now
        min_cs = max(2, len(region_rows) // 3)
        col_labels_raw = _cluster_1d(cx_r, min_cluster_size=min_cs)
        col_map = _sorted_cluster_map(cx_r, col_labels_raw)
        n_cols = len(col_map) if col_map else 1

        if n_cols < min_cols:
            continue

        col_meds = _cluster_medians(cx_r, col_labels_raw, col_map)

        # ── 5. Assign words to (row, col) cells ───────────────────────────────
        grid: Dict[Tuple[int, int], List[Word]] = defaultdict(list)
        for w, cl, ri in zip(words_r, col_labels_raw, row_idx_r):
            local_ri = region_rows.index(ri)
            ci = col_map[cl] if cl != -1 else _nearest(w.cx, col_meds)
            grid[(local_ri, ci)].append(w)

        n_rows = len(region_rows)

        # ── 5b. Merge sub-rows into visual rows ─────────────────────────────
        # A table cell can contain multiple OCR lines (e.g. "$801.36" on line 1
        # and "($100.17)" on line 2, both belonging to the same cell R4C1).
        # HDBSCAN treats each OCR line as a separate row. We merge consecutive
        # rows whose y-gap is small enough to be sub-lines of the same visual
        # row. The key insight: merge when gap < cell_height_threshold, even if
        # columns overlap (multi-line cells DO share columns across sub-rows).
        local_row_ys = {}
        for (r, c), wds in grid.items():
            if r not in local_row_ys:
                local_row_ys[r] = []
            for w in wds:
                local_row_ys[r].append((w.y0 + w.y1) / 2)
        local_row_medians = {r: float(np.median(ys)) for r, ys in local_row_ys.items() if ys}

        sorted_rows = sorted(local_row_medians.keys())
        if len(sorted_rows) < 2:
            pass  # nothing to merge
        else:
            # Compute all inter-row gaps
            all_gaps = []
            for i in range(len(sorted_rows) - 1):
                g = local_row_medians[sorted_rows[i + 1]] - local_row_medians[sorted_rows[i]]
                all_gaps.append(g)

            if all_gaps:
                # Bimodal gap distribution: small gaps = sub-lines within a cell,
                # large gaps = actual row boundaries. Use Otsu-like threshold
                # weighted toward small gaps (0.7 small + 0.3 large).
                sorted_gaps = sorted(all_gaps)
                mid = len(sorted_gaps) // 2
                small_half = sorted_gaps[:max(1, mid)]
                large_half = sorted_gaps[mid:]
                from pdf_tagger.config import get_config
                _cfg = get_config()
                merge_threshold = (np.median(small_half) * _cfg.otsu_weight_small
                                   + np.median(large_half) * _cfg.otsu_weight_large)

                # Safety guard: never merge rows whose gap exceeds the median
                # word height. A sub-line gap (e.g. multi-line cell) is always
                # smaller than the line height; real row boundaries are larger.
                all_word_heights = [w.y1 - w.y0 for wds in grid.values() for w in wds if w.y1 > w.y0]
                if all_word_heights:
                    median_wh = float(np.median(all_word_heights))
                    merge_threshold = min(merge_threshold, median_wh * _cfg.word_height_guard)

                # Build merge groups
                merge_map: Dict[int, int] = {}
                canonical = sorted_rows[0]
                merge_map[canonical] = canonical
                for i in range(len(sorted_rows) - 1):
                    r_curr = sorted_rows[i + 1]
                    gap = all_gaps[i]
                    if gap <= merge_threshold:
                        merge_map[r_curr] = canonical
                    else:
                        canonical = r_curr
                        merge_map[r_curr] = canonical

                # Rebuild grid with merged rows
                if len(set(merge_map.values())) < n_rows:
                    new_grid: Dict[Tuple[int, int], List[Word]] = defaultdict(list)
                    for (r, c), wds in grid.items():
                        new_r = merge_map.get(r, r)
                        new_grid[(new_r, c)].extend(wds)
                    grid = new_grid
                    unique_rows = sorted(set(merge_map.values()))
                    reindex = {old: new for new, old in enumerate(unique_rows)}
                    grid = {(reindex[r], c): wds for (r, c), wds in grid.items()}
                    n_rows = len(unique_rows)
                    logger.debug("Sub-row merge (Otsu): %d → %d rows (threshold=%.1f)",
                                 len(region_rows), n_rows, merge_threshold)
        filled = sum(1 for v in grid.values() if v)
        fill_rate = filled / max(1, n_rows * n_cols)
        if fill_rate < min_fill_rate:
            logger.debug(
                "Region skipped: fill_rate=%.2f < %.2f (rows=%d cols=%d)",
                fill_rate, min_fill_rate, n_rows, n_cols,
            )
            continue

        # ── 6. Merged-cell detection (colspan + rowspan) ─────────────────────
        spans = _detect_merged_cells(grid, col_meds, n_cols)

        # Rowspan: if cell (r,c) has text and cells below it are empty,
        # extend rowspan downward.
        row_spans: Dict[Tuple[int, int], int] = {}
        for r in range(n_rows):
            for c in range(n_cols):
                if not grid.get((r, c)):
                    continue
                rs = 1
                for r2 in range(r + 1, n_rows):
                    if grid.get((r2, c)):
                        break
                    rs += 1
                if rs > 1:
                    row_spans[(r, c)] = rs

        # Colspan: if cell (r,c) has text and cells to its right are empty,
        # extend colspan (supplements the width-based detection above).
        for r in range(n_rows):
            for c in range(n_cols):
                if not grid.get((r, c)):
                    continue
                if (r, c) in spans and spans[(r, c)] > 1:
                    continue  # already detected by width heuristic
                cs = 1
                for c2 in range(c + 1, n_cols):
                    if grid.get((r, c2)):
                        break
                    cs += 1
                if cs > 1:
                    spans[(r, c)] = cs

        # ── 7. Build Table output ──────────────────────────────────────────────
        cells: List[Cell] = []
        for (r, c), wds in grid.items():
            # Group words into sub-lines by y, then join with \n
            wds_sorted = sorted(wds, key=lambda x: (x.cy, x.cx))
            lines: List[List[Word]] = []
            for wd in wds_sorted:
                if lines and abs(wd.cy - lines[-1][-1].cy) < median_row_h * 0.6:
                    lines[-1].append(wd)
                else:
                    lines.append([wd])
            text = "\n".join(
                " ".join(w.text for w in sorted(line, key=lambda x: x.cx))
                for line in lines
            ).strip()
            cells.append(Cell(
                row=r,
                col=c,
                text=text,
                col_span=spans.get((r, c), 1),
            ))

        tables.append(Table(n_rows=n_rows, n_cols=n_cols, cells=cells))
        logger.debug(
            "Table accepted: rows=%d cols=%d fill=%.2f merged=%d",
            n_rows, n_cols, fill_rate, len(spans),
        )

    return tables


def tables_to_vision_format(tables: List[Table]) -> Optional[Dict]:
    """Convert the first accepted Table to the dict format used by table_vision.py.

    Returns:
        {"shape": [rows, cols], "cells": [{"p": [r,c], "t": text}],
         "merged": int, "method": "hdbscan"}
        or None if *tables* is empty.
    """
    if not tables:
        return None

    table = tables[0]
    cells_out = []
    for cell in sorted(table.cells, key=lambda c: (c.row, c.col)):
        if cell.col_span > 1 or cell.row_span > 1:
            p = [cell.row, cell.col, cell.row_span, cell.col_span]
        else:
            p = [cell.row, cell.col]
        cells_out.append({"p": p, "t": cell.text})

    merged = sum(1 for c in table.cells if c.col_span > 1 or c.row_span > 1)
    return {
        "shape": [table.n_rows, table.n_cols],
        "cells": cells_out,
        "merged": merged,
        "method": "hdbscan",
    }


def infer_from_word_bboxes(
    word_bboxes: List[Tuple],
    word_texts: List[str],
    img_w: int,
    img_h: int,
    word_confs: Optional[List[float]] = None,
) -> Optional[Dict]:
    """Convenience wrapper: build Word objects from raw bbox/text lists.

    This is the interface called from table_vision.py.

    Args:
        word_bboxes:  List of (x0, y0, x1, y1) in image pixel coordinates.
        word_texts:   Parallel list of text strings.
        img_w:        Image width (pixels) — used as page_width for KDE.
        img_h:        Image height (pixels) — unused except for logging.
        word_confs:   Optional per-word confidence in [0, 100]. Defaults
                      to 100 for all words when absent.

    Returns:
        Vision-format dict or None.
    """
    if not word_bboxes or not word_texts:
        return None

    confs = word_confs if word_confs else [100.0] * len(word_bboxes)
    words = [
        Word(x0=b[0], y0=b[1], x1=b[2], y1=b[3], text=t, conf=c)
        for b, t, c in zip(word_bboxes, word_texts, confs)
        if len(b) >= 4
    ]

    tables = infer_table_cells(words, page_width=float(img_w))
    return tables_to_vision_format(tables)
