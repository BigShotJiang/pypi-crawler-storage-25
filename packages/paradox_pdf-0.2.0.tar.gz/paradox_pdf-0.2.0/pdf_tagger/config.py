"""
Centralized pipeline configuration.

All thresholds and magic numbers live here instead of being scattered
across 9+ modules. Modules import ``get_config()`` and read the values
they need.  Callers can override values programmatically or via
environment variables prefixed with ``PDF_`` (upper-snake-case of the
field name, e.g. ``PDF_RENDER_DPI=300``).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, fields
from typing import Tuple


@dataclass
class PipelineConfig:
    # ── Scan detection ────────────────────────────────────────────────
    scan_text_threshold: int = 50
    """Characters below which a page is considered scanned."""

    # ── CV tables (border-missing detection) ──────────────────────────
    cv_border_missing_threshold: float = 0.35
    """Pixel coverage below which a grid border is declared missing."""

    # ── Line tables (vector grid detection) ───────────────────────────
    jaccard_threshold: float = 0.60
    """Fuzzy Jaccard for grouping row-bands."""
    h_coverage_threshold: float = 0.60
    """Min horizontal line coverage to accept a y-grid line."""
    v_coverage_threshold: float = 0.35
    """Min vertical line coverage (lower because of rowspans)."""

    # ── Borderless tables ─────────────────────────────────────────────
    line_y_tolerance: float = 3.0
    """Y-tolerance for grouping words into lines."""
    anchor_cluster_tolerance: float = 10.0
    """X-tolerance for clustering column anchors."""

    # ── YOLO + Vision layout ──────────────────────────────────────────
    yolo_confidence: float = 0.2
    """Min YOLO detection confidence."""
    nms_iou_threshold: float = 0.5
    """IoU threshold for YOLO NMS."""
    render_dpi: int = 200
    """DPI for rendering PDF pages to images."""
    ocr_min_confidence: float = 0.3
    """Min OCR word confidence to keep."""

    # ── Table vision (Table Transformer) ──────────────────────────────
    tt_thresholds: Tuple[float, ...] = (0.4, 0.5)
    """Table Transformer confidence thresholds (run at each)."""
    tt_col_tolerance: int = 2
    """Column count tolerance between CV and TT."""
    tt_row_tolerance: int = 3
    """Row count tolerance between CV and TT."""

    # ── Cluster cells (HDBSCAN) ───────────────────────────────────────
    hdbscan_min_fill_rate: float = 0.40
    """Min fraction of non-empty cells to accept a table."""
    hdbscan_min_cols: int = 2
    hdbscan_min_rows: int = 3
    hdbscan_large_gap_factor: float = 2.0
    """Multiple of median row height that splits table regions."""
    merged_cell_width_ratio: float = 1.6
    """Cell wider than this × column pitch → colspan merge."""
    otsu_weight_small: float = 0.7
    """Otsu sub-row merge: weight for small-gap half."""
    otsu_weight_large: float = 0.3
    """Otsu sub-row merge: weight for large-gap half."""
    word_height_guard: float = 0.8
    """Safety cap: merge threshold ≤ median_word_height × this."""

    # ── Table dedup / scoring ─────────────────────────────────────────
    dedup_iou_threshold: float = 0.5
    """IoU threshold for suppressing duplicate TABLE elements."""
    merge_penalty_factor: float = 1.5
    """Linear penalty multiplier for merge_ratio in table scoring."""
    src_bonus_vectorial: float = 0.3
    """Quality bonus for tables from the vectorial pipeline."""

    # ── Marks vision (TexTAR) ─────────────────────────────────────────
    textar_crop_h: int = 128
    textar_crop_w: int = 96
    superscript_height_ratio: float = 0.65
    """Word bbox height < this × median → superscript."""
    strikethrough_cv_coverage: float = 0.3
    """Horizontal line coverage to flag strikethrough (OpenCV)."""


# ── Singleton ─────────────────────────────────────────────────────────

_instance: PipelineConfig | None = None


def get_config() -> PipelineConfig:
    """Return the global PipelineConfig, creating it on first call.

    Environment variables with prefix ``PDF_`` override defaults.
    Example: ``PDF_RENDER_DPI=300`` sets ``render_dpi`` to 300.
    """
    global _instance
    if _instance is not None:
        return _instance

    cfg = PipelineConfig()

    # Apply env-var overrides
    for f in fields(cfg):
        env_key = f"PDF_{f.name.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is not None:
            try:
                if f.type in ("int", int):
                    setattr(cfg, f.name, int(env_val))
                elif f.type in ("float", float):
                    setattr(cfg, f.name, float(env_val))
                else:
                    setattr(cfg, f.name, env_val)
            except (ValueError, TypeError):
                pass  # ignore bad env values silently

    _instance = cfg
    return cfg


def reset_config() -> None:
    """Reset singleton (useful for tests)."""
    global _instance
    _instance = None
