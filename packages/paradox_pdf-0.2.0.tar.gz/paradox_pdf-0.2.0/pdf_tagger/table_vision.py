"""
table_vision.py — Hybrid table structure extraction from scanned images.

Uses ALL available methods simultaneously and combines their results:

  1. OpenCV (adaptive threshold) → detects grid lines where they exist
  2. Table Transformer → detects rows/columns/spanning even without borders
  3. PaddleOCR word positions → validates structure + fills cell text

Strategy: Table Transformer provides the skeleton (row/column layout),
OpenCV refines merged cell detection (border presence/absence),
PaddleOCR validates by checking words actually exist in detected cells.

Input: cropped table image (from YOLO DocLayout "table" region)
Output: {"shape": [rows, cols], "cells": [{"p": [r,c], "t": "text"}]}
        Same format as the heuristic pipeline.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

_tt_model = None
_tt_processor = None


def _get_table_transformer():
    global _tt_model, _tt_processor
    if _tt_model is not None:
        return _tt_model, _tt_processor
    import torch
    from transformers import AutoModelForObjectDetection, AutoImageProcessor
    _tt_processor = AutoImageProcessor.from_pretrained(
        "microsoft/table-transformer-structure-recognition-v1.1-all",
        size={"shortest_edge": 800, "longest_edge": 1333},
    )
    _tt_model = AutoModelForObjectDetection.from_pretrained(
        "microsoft/table-transformer-structure-recognition-v1.1-all"
    )
    _tt_model.eval()
    logger.info("Table Transformer loaded")
    return _tt_model, _tt_processor


# ═══════════════════════════════════════════════════════════════
#  DESKEW
# ═══════════════════════════════════════════════════════════════

def deskew(img: np.ndarray, max_angle: float = 5.0) -> np.ndarray:
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, 100,
                            minLineLength=img.shape[1]//8, maxLineGap=10)
    if lines is None:
        return img
    angles = [np.degrees(np.arctan2(l[0][3]-l[0][1], l[0][2]-l[0][0]))
              for l in lines if abs(np.degrees(np.arctan2(l[0][3]-l[0][1], l[0][2]-l[0][0]))) < max_angle]
    if not angles:
        return img
    angle = np.median(angles)
    if abs(angle) < 0.15:
        return img
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1.0)
    return cv2.warpAffine(img, M, (w, h), borderValue=(255, 255, 255))


def rectify_perspective(img: np.ndarray) -> np.ndarray:
    """
    Detect table outer border and rectify perspective distortion.
    Finds the largest rectangular contour and warps to rectangle.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
    h, w = gray.shape[:2]
    
    # Edge detection
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 30, 100)
    
    # Dilate to connect edge fragments
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    edges = cv2.dilate(edges, kernel, iterations=2)
    
    # Find contours
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return img
    
    # Find largest contour by area
    largest = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest)
    
    # Must be at least 30% of image area
    if area < h * w * 0.3:
        return img
    
    # Approximate to polygon
    peri = cv2.arcLength(largest, True)
    approx = cv2.approxPolyDP(largest, 0.02 * peri, True)
    
    # Need exactly 4 corners for perspective transform
    if len(approx) != 4:
        # Try with more tolerance
        approx = cv2.approxPolyDP(largest, 0.05 * peri, True)
        if len(approx) != 4:
            return img
    
    # Order points: top-left, top-right, bottom-right, bottom-left
    pts = approx.reshape(4, 2).astype(np.float32)
    rect = _order_points(pts)
    
    # Compute output dimensions
    widthA = np.linalg.norm(rect[0] - rect[1])
    widthB = np.linalg.norm(rect[2] - rect[3])
    maxW = int(max(widthA, widthB))
    
    heightA = np.linalg.norm(rect[0] - rect[3])
    heightB = np.linalg.norm(rect[1] - rect[2])
    maxH = int(max(heightA, heightB))
    
    if maxW < 50 or maxH < 50:
        return img
    
    # Check if significant perspective distortion exists
    # If corners are already nearly rectangular, skip
    ideal = np.float32([[0,0],[maxW,0],[maxW,maxH],[0,maxH]])
    diff = np.mean(np.abs(rect - np.float32([[0,0],[w,0],[w,h],[0,h]])))
    if diff < min(w, h) * 0.02:
        return img  # Already rectangular enough
    
    dst = np.float32([[0,0],[maxW,0],[maxW,maxH],[0,maxH]])
    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(img, M, (maxW, maxH), borderValue=(255,255,255))
    
    return warped


def _order_points(pts):
    """Order 4 points as: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype=np.float32)
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # top-left has smallest sum
    rect[2] = pts[np.argmax(s)]  # bottom-right has largest sum
    d = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(d)]  # top-right has smallest difference
    rect[3] = pts[np.argmax(d)]  # bottom-left has largest difference
    return rect



# ═══════════════════════════════════════════════════════════════
#  OPENCV: detect grid lines
# ═══════════════════════════════════════════════════════════════

def _opencv_detect_lines(img: np.ndarray):
    """Detect lines using bilateral filter + multi-threshold voting + morphology."""
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
    h, w = gray.shape[:2]

    # Bilateral filter: removes noise while preserving edges (key for wrinkled paper)
    filtered = cv2.bilateralFilter(gray, 9, 75, 75)

    # Multi-threshold voting: combine 3 methods for robustness
    t1 = cv2.adaptiveThreshold(filtered, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                cv2.THRESH_BINARY_INV, 15, 10)
    _, t2 = cv2.threshold(filtered, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    t3 = cv2.adaptiveThreshold(filtered, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                cv2.THRESH_BINARY_INV, 21, 12)
    
    # Vote: pixel is foreground if at least 2 of 3 agree
    thresh = ((t1.astype(int) + t2.astype(int) + t3.astype(int)) >= 510).astype(np.uint8) * 255

    # Use wider kernels to catch slightly curved lines (wrinkled paper)
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(30, w // 10), 2))
    horiz = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, h_kernel)
    # Clean up with thinner kernel
    h_kernel_thin = cv2.getStructuringElement(cv2.MORPH_RECT, (max(30, w // 12), 1))
    horiz = cv2.morphologyEx(horiz, cv2.MORPH_CLOSE, h_kernel_thin)

    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, max(30, h // 10)))
    vert = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, v_kernel)
    v_kernel_thin = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(30, h // 12)))
    vert = cv2.morphologyEx(vert, cv2.MORPH_CLOSE, v_kernel_thin)

    return horiz, vert


def _find_line_positions(projection: np.ndarray, threshold: float) -> List[int]:
    positions = []
    in_line = False
    start = 0
    for i in range(len(projection)):
        if projection[i] > threshold:
            if not in_line:
                start = i
                in_line = True
        else:
            if in_line:
                positions.append((start + i) // 2)
                in_line = False
    if in_line:
        positions.append((start + len(projection) - 1) // 2)
    return positions


def _opencv_grid(img: np.ndarray) -> Optional[Dict]:
    """Extract grid positions from OpenCV line detection."""
    horiz, vert = _opencv_detect_lines(img)
    h, w = img.shape[:2]

    ys = _find_line_positions(np.sum(horiz, axis=1).astype(float), w * 0.12)
    # For vertical lines: require they span a significant portion of the table height
    # AND touch near the top and bottom (real borders go full height)
    xs_raw = _find_line_positions(np.sum(vert, axis=0).astype(float), h * 0.06)
    xs = []
    for x in xs_raw:
        # Check if this vertical line reaches near top and bottom
        col_strip = vert[:, max(0, x-3):min(w, x+4)]
        if col_strip.size == 0:
            continue
        col_proj = np.max(col_strip, axis=1)
        # Find first and last non-zero pixel
        nonzero = np.nonzero(col_proj > 0)[0]
        if len(nonzero) == 0:
            continue
        top_reach = nonzero[0]
        bot_reach = nonzero[-1]
        span_ratio = (bot_reach - top_reach) / max(1, h)
        # Real border: spans >40% of table height AND reaches within 20% of top/bottom
        touches_top = top_reach < h * 0.25
        touches_bot = bot_reach > h * 0.75
        if span_ratio > 0.40 and (touches_top or touches_bot):
            xs.append(x)

    min_gap = max(8, min(h, w) // 40)
    ys = _filter_close(ys, min_gap)
    xs = _filter_close(xs, min_gap)

    nr, nc = len(ys) - 1, len(xs) - 1
    if nr < 2 or nc < 2:
        return None

    return {"xs": xs, "ys": ys, "nr": nr, "nc": nc, "horiz": horiz, "vert": vert}


# ═══════════════════════════════════════════════════════════════
#  TABLE TRANSFORMER: detect rows/columns/spanning
# ═══════════════════════════════════════════════════════════════

def _tt_detect(img: np.ndarray, threshold: float = 0.5) -> Optional[Dict]:
    """Run Table Transformer to get row/column/spanning bounding boxes."""
    try:
        import torch
        from PIL import Image

        model, processor = _get_table_transformer()
        img_pil = Image.fromarray(img)

        inputs = processor(images=img_pil, return_tensors="pt")
        with torch.no_grad():
            outputs = model(**inputs)

        target = torch.tensor([img_pil.size[::-1]])
        res = processor.post_process_object_detection(outputs, threshold=threshold, target_sizes=target)[0]

        rows, cols, spanning = [], [], []
        for s, lid, box in zip(res["scores"], res["labels"], res["boxes"]):
            label = model.config.id2label[lid.item()]
            entry = {"score": s.item(), "bbox": [round(x.item(), 1) for x in box]}
            if label == "table row":
                rows.append(entry)
            elif label == "table column":
                cols.append(entry)
            elif label == "table spanning cell":
                spanning.append(entry)

        rows = _nms_1d(rows, "y")
        cols = _nms_1d(cols, "x")

        if len(rows) < 2 or len(cols) < 1:
            return None

        return {"rows": rows, "cols": cols, "spanning": spanning}
    except Exception as e:
        logger.debug("Table Transformer failed: %s", e)
        return None


# ═══════════════════════════════════════════════════════════════
#  HYBRID: combine OpenCV grid + TT structure
# ═══════════════════════════════════════════════════════════════

def _build_grid_from_tt(tt_result: Dict, img_h: int, img_w: int) -> Dict:
    """Convert Table Transformer row/col bboxes into grid positions."""
    rows = tt_result["rows"]
    cols = tt_result["cols"]

    # Row boundaries: use midpoints between consecutive rows
    row_mids = sorted([(r["bbox"][1] + r["bbox"][3]) / 2 for r in rows])
    ys = [0]
    for i in range(len(row_mids) - 1):
        ys.append(int((row_mids[i] + row_mids[i + 1]) / 2))
    ys.append(img_h)

    # Column boundaries
    col_mids = sorted([(c["bbox"][0] + c["bbox"][2]) / 2 for c in cols])
    xs = [0]
    for i in range(len(col_mids) - 1):
        xs.append(int((col_mids[i] + col_mids[i + 1]) / 2))
    xs.append(img_w)

    return {"xs": xs, "ys": ys, "nr": len(ys) - 1, "nc": len(xs) - 1}


def _detect_merged_opencv(horiz, vert, xs, ys, nr, nc, img_h, img_w):
    """Use OpenCV border masks to detect which borders are missing → merged cells."""
    h_missing = [[False] * nc for _ in range(nr - 1)]
    v_missing = [[False] * (nc - 1) for _ in range(nr)]

    for r in range(nr - 1):
        y_px = ys[r + 1]
        for c in range(nc):
            cx0, cx1 = xs[c] + 3, xs[c + 1] - 3
            if cx1 <= cx0:
                continue
            region = horiz[max(0, y_px-4):min(img_h, y_px+5), cx0:cx1]
            h_missing[r][c] = np.sum(region > 0) / max(1, region.size) < 0.20

    for c in range(nc - 1):
        x_px = xs[c + 1]
        for r in range(nr):
            ry0, ry1 = ys[r] + 3, ys[r + 1] - 3
            if ry1 <= ry0:
                continue
            region = vert[ry0:ry1, max(0, x_px-4):min(img_w, x_px+5)]
            v_missing[r][c] = np.sum(region > 0) / max(1, region.size) < 0.20

    return h_missing, v_missing


def _detect_merged_tt(tt_result: Dict, grid: Dict):
    """Use Table Transformer spanning cell detections to mark merged cells."""
    xs, ys = grid["xs"], grid["ys"]
    nr, nc = grid["nr"], grid["nc"]

    span_map = [[False] * nc for _ in range(nr)]
    spans = []

    for sp in tt_result.get("spanning", []):
        sb = sp["bbox"]
        r_start = r_end = c_start = c_end = -1

        for ri in range(nr):
            mid_y = (ys[ri] + ys[ri + 1]) / 2
            if sb[1] <= mid_y <= sb[3]:
                if r_start == -1:
                    r_start = ri
                r_end = ri

        for ci in range(nc):
            mid_x = (xs[ci] + xs[ci + 1]) / 2
            if sb[0] <= mid_x <= sb[2]:
                if c_start == -1:
                    c_start = ci
                c_end = ci

        if r_start >= 0 and c_start >= 0:
            rs = r_end - r_start + 1
            cs = c_end - c_start + 1
            if rs > 1 or cs > 1:
                spans.append((r_start, c_start, rs, cs))
                for rr in range(r_start, r_end + 1):
                    for cc in range(c_start, c_end + 1):
                        span_map[rr][cc] = True

    return span_map, spans


def _build_cells(grid: Dict, h_missing, v_missing, tt_spans, tt_span_map):
    """Build cells combining OpenCV border analysis + TT spanning detection."""
    xs, ys = grid["xs"], grid["ys"]
    nr, nc = grid["nr"], grid["nc"]

    consumed = [[False] * nc for _ in range(nr)]
    cells = []

    # First: add TT-detected spanning cells (high confidence)
    for r_start, c_start, rs, cs in tt_spans:
        for rr in range(r_start, min(r_start + rs, nr)):
            for cc in range(c_start, min(c_start + cs, nc)):
                consumed[rr][cc] = True
        bbox = (xs[c_start], ys[r_start],
                xs[min(c_start + cs, nc)], ys[min(r_start + rs, nr)])
        cells.append({"p": [r_start, c_start, rs, cs], "t": "", "_bbox": bbox})

    # Then: process remaining cells with OpenCV border analysis
    for r in range(nr):
        for c in range(nc):
            if consumed[r][c]:
                continue

            # Expand using OpenCV missing borders
            cs = 1
            while c + cs < nc and not consumed[r][c + cs]:
                if c + cs - 1 < len(v_missing[r]) and v_missing[r][c + cs - 1]:
                    cs += 1
                else:
                    break

            rs = 1
            while r + rs < nr:
                all_missing = True
                for cc in range(c, min(c + cs, nc)):
                    if consumed[r + rs - 1 + 1][cc] if r + rs < nr else True:
                        pass
                    if r + rs - 1 < len(h_missing):
                        if not h_missing[r + rs - 1][cc]:
                            all_missing = False
                            break
                    else:
                        all_missing = False
                        break
                if all_missing and not any(consumed[r + rs][cc] for cc in range(c, min(c + cs, nc))):
                    rs += 1
                else:
                    break

            for rr in range(r, r + rs):
                for cc in range(c, c + cs):
                    consumed[rr][cc] = True

            bbox = (xs[c], ys[r], xs[min(c + cs, nc)], ys[min(r + rs, nr)])
            pos = [r, c] if (rs == 1 and cs == 1) else [r, c, rs, cs]
            cells.append({"p": pos, "t": "", "_bbox": bbox})

    cells.sort(key=lambda c: (c["p"][0], c["p"][1]))
    return cells


# ═══════════════════════════════════════════════════════════════
#  PUBLIC API
# ═══════════════════════════════════════════════════════════════

def extract_table_from_image(
    img: np.ndarray,
    ocr_fn=None,
    word_bboxes: List[Tuple] = None,
    word_texts: List[str] = None,
) -> Optional[Dict]:
    """
    Extract table structure from a cropped table image.

    Uses ALL methods simultaneously and combines results:
      - Table Transformer for row/column skeleton (especially borderless)
      - OpenCV for precise border/merged cell detection
      - Word positions for validation + text filling

    Args:
        img: RGB numpy array of the table region
        ocr_fn: function(crop_img) -> text for cell OCR
        word_bboxes: pre-extracted word bounding boxes
        word_texts: pre-extracted word texts

    Returns:
        {"shape": [rows, cols], "cells": [{"p": [r,c], "t": "text"}]}
    """
    h, w = img.shape[:2]
    if h < 20 or w < 20:
        return None

    # Step 0: Deskew + Perspective rectification
    img = deskew(img)
    img = rectify_perspective(img)

    # Step 1: Run OpenCV line detection
    horiz, vert = _opencv_detect_lines(img)
    cv_grid = _opencv_grid(img)

    # Step 2: Run Table Transformer at two thresholds for robustness
    tt_shapes = []
    tt_result = None
    from pdf_tagger.config import get_config as _get_config
    _cfg = _get_config()
    for tt_thresh in _cfg.tt_thresholds:
        tt = _tt_detect(img, threshold=tt_thresh)
        if tt and len(tt["rows"]) >= 2 and len(tt["cols"]) >= 2:
            grid_tt = _build_grid_from_tt(tt, h, w)
            tt_shapes.append([grid_tt["nr"], grid_tt["nc"]])
            if tt_result is None:
                tt_result = tt  # Keep the first (lower threshold) for spanning

    # Step 3: TT-primary strategy with CV validation
    # TT understands table structure semantically (rows/columns) even in degraded images
    # CV is more precise for column detection (vertical lines)
    cv_valid = cv_grid and cv_grid["nr"] >= 2 and cv_grid["nc"] >= 2
    tt_valid = len(tt_shapes) > 0

    # Helper: score a column hypothesis by OCR word projection consistency.
    # Given the column grid xs (image px), assign each word's x-center to a
    # column and compute mean normalized std of x-centers per column. Lower
    # std means columns are well-defined (words group tightly). Also rewards
    # higher fill ratio (cols with ≥1 word).
    def _score_col_hypothesis(xs_grid, words_bb):
        if not xs_grid or len(xs_grid) < 2 or not words_bb:
            return 0.0
        n_cols_h = len(xs_grid) - 1
        buckets = [[] for _ in range(n_cols_h)]
        total_w = max(1.0, float(xs_grid[-1] - xs_grid[0]))
        for (x0, y0, x1, y1) in words_bb:
            cx = 0.5 * (x0 + x1)
            # Find column index
            idx = -1
            for k in range(n_cols_h):
                if xs_grid[k] <= cx <= xs_grid[k + 1]:
                    idx = k
                    break
            if idx >= 0:
                buckets[idx].append(cx)
        filled = sum(1 for b in buckets if b)
        if filled == 0:
            return 0.0
        # Mean dispersion per column (normalized by column width)
        import numpy as _np
        disps = []
        for k, b in enumerate(buckets):
            if len(b) >= 2:
                w_col = max(1.0, float(xs_grid[k + 1] - xs_grid[k]))
                disps.append(float(_np.std(b)) / w_col)
        mean_disp = float(_np.mean(disps)) if disps else 0.3
        fill_ratio = filled / n_cols_h
        # Score: high fill, low dispersion. Penalize cols hypothesized but empty.
        return fill_ratio * 1.0 - mean_disp * 0.6

    # Determine best row/col counts
    if tt_valid and cv_valid:
        import numpy as np
        tt_rows = int(np.mean([s[0] for s in tt_shapes]))
        tt_cols = int(np.mean([s[1] for s in tt_shapes]))

        # If we have OCR word bboxes, arbitrate CV vs TT by projection consistency
        use_cv = None
        best_cols = None
        if word_bboxes and len(word_bboxes) >= 4 and cv_grid["nc"] != tt_cols:
            cv_score = _score_col_hypothesis(cv_grid["xs"], word_bboxes)
            tt_grid_for_score = _build_grid_from_tt(tt_result, h, w) if tt_result else None
            tt_score = _score_col_hypothesis(tt_grid_for_score["xs"], word_bboxes) if tt_grid_for_score else 0.0
            if cv_score >= tt_score:
                best_cols = cv_grid["nc"]
                use_cv_cols = True
            else:
                best_cols = tt_cols
                use_cv_cols = False
        else:
            # Original heuristic: trust CV if close to TT (±2), else take min
            if abs(cv_grid["nc"] - tt_cols) <= _cfg.tt_col_tolerance:
                best_cols = cv_grid["nc"]
                use_cv_cols = True
            else:
                best_cols = min(cv_grid["nc"], tt_cols)
                use_cv_cols = (best_cols == cv_grid["nc"])

        # Rows: if CV and TT agree (±3), use CV; else use TT
        if abs(cv_grid["nr"] - tt_rows) <= _cfg.tt_row_tolerance:
            best_rows = cv_grid["nr"]
            use_cv_rows = True
        else:
            best_rows = tt_rows
            use_cv_rows = False

        use_cv = use_cv_cols and use_cv_rows
    elif tt_valid:
        import numpy as np
        best_rows = int(np.mean([s[0] for s in tt_shapes]))
        best_cols = int(np.mean([s[1] for s in tt_shapes]))
        use_cv = False
    elif cv_valid:
        best_rows = cv_grid["nr"]
        best_cols = cv_grid["nc"]
        use_cv = True
    else:
        use_cv = False

    if use_cv:
        # OpenCV found a valid grid — use it (more precise for bordered tables)
        grid = cv_grid
        method = "opencv"

        # But also get TT spanning cells for extra merge detection
        tt_spans = []
        tt_span_map = [[False] * grid["nc"] for _ in range(grid["nr"])]
        if tt_result:
            tt_span_map_raw, tt_spans_raw = _detect_merged_tt(tt_result, grid)
            # Only use TT spans that make sense within the OpenCV grid
            for r, c, rs, cs in tt_spans_raw:
                if r + rs <= grid["nr"] and c + cs <= grid["nc"]:
                    tt_spans.append((r, c, rs, cs))
                    for rr in range(r, r + rs):
                        for cc in range(c, c + cs):
                            tt_span_map[rr][cc] = True

        # OpenCV border analysis for merged cells
        h_missing, v_missing = _detect_merged_opencv(
            horiz, vert, grid["xs"], grid["ys"],
            grid["nr"], grid["nc"], h, w
        )

    elif tt_valid:
        # No OpenCV grid but TT found structure (borderless table)
        grid = _build_grid_from_tt(tt_result, h, w)
        method = "table_transformer"

        tt_span_map, tt_spans = _detect_merged_tt(tt_result, grid)
        # No OpenCV borders for borderless table
        h_missing = [[True] * grid["nc"] for _ in range(grid["nr"] - 1)]
        v_missing = [[True] * (grid["nc"] - 1) for _ in range(grid["nr"])]

    elif word_bboxes and word_texts and len(word_bboxes) >= 4:
        # Last resort: word clustering
        from pdf_grid.geometry import cluster
        y_centers = [(b[1]+b[3])/2 for b in word_bboxes]
        x_starts = [b[0] for b in word_bboxes]
        y_clust = cluster(y_centers, tol=max(5, h*0.02))
        x_clust = cluster(x_starts, tol=max(10, w*0.03))
        nr, nc = len(y_clust), len(x_clust)
        if nr < 2 or nc < 2:
            return None

        cells = []
        for r, yc in enumerate(y_clust):
            for c, xc in enumerate(x_clust):
                words = [word_texts[i] for i, (bx0,by0,bx1,by1) in enumerate(word_bboxes)
                         if abs((by0+by1)/2 - yc) < h*0.025 and abs(bx0 - xc) < w*0.04]
                text = " ".join(words)
                if text.strip():
                    cells.append({"p": [r, c], "t": text})
        return {"shape": [nr, nc], "cells": cells, "merged": 0, "method": "word_clustering"}
    else:
        return None

    # Step 4: Build cells
    cells = _build_cells(grid, h_missing, v_missing, tt_spans, tt_span_map)
    n_merged = sum(1 for c in cells if len(c["p"]) == 4)

    # Step 5: Fill cell text via OCR
    if ocr_fn:
        for cell in cells:
            bbox = cell.pop("_bbox", None)
            if bbox is None:
                continue
            x0, y0, x1, y1 = [max(0, int(v) + 2) for v in bbox[:2]] + [int(v) - 2 for v in bbox[2:]]
            x1 = min(w, x1)
            y1 = min(h, y1)
            if x1 > x0 and y1 > y0:
                try:
                    cell["t"] = ocr_fn(img[y0:y1, x0:x1]).strip()
                except Exception:
                    cell["t"] = ""
            else:
                cell["t"] = ""
    else:
        for cell in cells:
            cell.pop("_bbox", None)

    return {"shape": [grid["nr"], grid["nc"]], "cells": cells, "merged": n_merged, "method": method}


# ═══════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════

def _filter_close(positions: List[int], min_gap: int) -> List[int]:
    if len(positions) < 2:
        return positions
    result = [positions[0]]
    for p in positions[1:]:
        if p - result[-1] >= min_gap:
            result.append(p)
    return result


def _nms_1d(items: List[Dict], axis: str, iou_threshold: float = 0.5) -> List[Dict]:
    items.sort(key=lambda x: x["score"], reverse=True)
    keep = []
    for item in items:
        b = item["bbox"]
        start, end = (b[1], b[3]) if axis == "y" else (b[0], b[2])
        overlap = False
        for kept in keep:
            kb = kept["bbox"]
            ks, ke = (kb[1], kb[3]) if axis == "y" else (kb[0], kb[2])
            inter = max(0, min(end, ke) - max(start, ks))
            union = max(1, (end-start) + (ke-ks) - inter)
            if inter / union > iou_threshold:
                overlap = True
                break
        if not overlap:
            keep.append(item)
    keep.sort(key=lambda x: x["bbox"][1 if axis == "y" else 0])
    return keep
