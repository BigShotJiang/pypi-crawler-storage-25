"""PDF Tagger — Classify every element in a PDF with a type ID."""
