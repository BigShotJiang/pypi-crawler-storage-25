"""
scan_detector.py — Per-page detection of scanned vs digital PDF pages.

A page is considered "scanned" (image-only) when PyMuPDF cannot extract
meaningful embedded text from it. This happens when the page content is
a raster image rather than vector text objects.

Used by the unified pipeline to route each page to the correct extractor:
  - Digital pages → v2 heuristic (PyMuPDF font flags → marks)
  - Scanned pages → vision pipeline (YOLO + PaddleOCR + TexTAR → marks)
"""

from __future__ import annotations

from pdf_tagger.config import get_config


def is_page_scanned(page, threshold: int = None) -> bool:
    """
    Check if a PDF page is scanned (image-only) vs digital (embedded text).

    Heuristic: if PyMuPDF extracts fewer than `threshold` characters of text,
    the page is likely a scanned image with no embedded text layer.

    Args:
        page: PyMuPDF page object.
        threshold: minimum character count to consider the page digital.

    Returns:
        True if the page appears to be scanned (image-only).
    """
    if threshold is None:
        threshold = get_config().scan_text_threshold
    text = page.get_text("text").strip()
    return len(text) < threshold
