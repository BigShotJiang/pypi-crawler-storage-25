"""
camscanner.py — Robust document image correction pipeline.

Combines techniques from:
- andrewdcampbell/OpenCV-Document-Scanner (MORPH_CLOSE, LSD dual strategy, angle validation)
- sraddhanjali/Automated-Perspective-Correction (convex hull intersections)
- AdityaPai2398/CamScanner-In-Python (compact pipeline)
- Custom curve rectification for warped/curved paper

Pipeline:
  1. Deskew: detect text/line angle via Hough, rotate to horizontal
  2. Perspective: MORPH_CLOSE → multi-threshold Canny → contour quad detection
     → robust corner ordering → warp to rectangle
  3. Curve rectify: detect curved h-lines → remap to straight lines

Usage:
    from pdf_tagger.camscanner import correct_document
    corrected = correct_document(img_np)
"""
from __future__ import annotations
import logging
import math
import numpy as np
import cv2
from scipy.spatial import distance as dist

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
#  CORNER ORDERING — Euclidean distance method (robust to rotation)
# ═══════════════════════════════════════════════════════════════

def _order_points(pts: np.ndarray) -> np.ndarray:
    """Order 4 points as [top-left, top-right, bottom-right, bottom-left].
    Uses Euclidean distance disambiguation — more robust than sum/diff for
    rotated documents."""
    pts = np.array(pts, dtype="float32")
    x_sorted = pts[np.argsort(pts[:, 0]), :]
    left_most = x_sorted[:2, :]
    right_most = x_sorted[2:, :]
    left_most = left_most[np.argsort(left_most[:, 1]), :]
    tl, bl = left_most
    D = dist.cdist(tl[np.newaxis], right_most, "euclidean")[0]
    br, tr = right_most[np.argsort(D)[::-1], :]
    return np.array([tl, tr, br, bl], dtype="float32")


# ═══════════════════════════════════════════════════════════════
#  ANGLE VALIDATION — reject degenerate quadrilaterals
# ═══════════════════════════════════════════════════════════════

def _interior_angle(p1, vertex, p3) -> float:
    v1 = np.array(p1) - np.array(vertex)
    v2 = np.array(p3) - np.array(vertex)
    cos_val = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-8)
    return math.degrees(math.acos(np.clip(cos_val, -1.0, 1.0)))


def _angle_range(quad: np.ndarray) -> float:
    """Range of interior angles. Good rectangles ≈ 0°, degenerate > 40°."""
    tl, tr, br, bl = quad
    angles = [
        _interior_angle(bl, tl, tr),
        _interior_angle(tl, tr, br),
        _interior_angle(tr, br, bl),
        _interior_angle(br, bl, tl),
    ]
    return float(np.ptp(angles))


def _is_valid_quad(approx, img_w, img_h, min_area_ratio=0.08, max_angle=40.0):
    if len(approx) != 4:
        return False
    area = cv2.contourArea(approx)
    if area < img_w * img_h * min_area_ratio:
        return False
    pts = _order_points(approx.reshape(4, 2).astype("float32"))
    if _angle_range(pts) >= max_angle:
        return False
    return True


# ═══════════════════════════════════════════════════════════════
#  Step 1: DESKEW
# ═══════════════════════════════════════════════════════════════

def _deskew(img: np.ndarray, max_angle: float = 15.0) -> tuple[np.ndarray, float]:
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80,
                            minLineLength=gray.shape[1] // 8, maxLineGap=10)
    if lines is None:
        return img, 0.0
    angles = []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        if abs(x2 - x1) < 15:
            continue
        angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
        if abs(angle) < max_angle:
            angles.append(angle)
    if not angles:
        return img, 0.0
    median_angle = float(np.median(angles))
    if abs(median_angle) < 0.3:
        return img, 0.0
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), -median_angle, 1.0)
    return cv2.warpAffine(img, M, (w, h), borderValue=(255, 255, 255)), median_angle


# ═══════════════════════════════════════════════════════════════
#  Step 2: PERSPECTIVE CORRECTION (improved)
# ═══════════════════════════════════════════════════════════════

def _perspective_correct(img: np.ndarray) -> tuple[np.ndarray, bool]:
    """Detect document/table quad and warp to rectangle.
    Uses MORPH_CLOSE + multi-threshold Canny + angle validation.
    Returns (original, False) if no valid quad found (graceful degradation)."""
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY) if len(img.shape) == 3 else img

    # Blur + MORPH_CLOSE to seal broken edges
    blurred = cv2.GaussianBlur(gray, (7, 7), 0)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
    closed = cv2.morphologyEx(blurred, cv2.MORPH_CLOSE, kernel)

    # Multi-threshold Canny — collect all valid quads
    candidates = []
    for lo, hi in [(0, 84), (30, 100), (50, 150), (75, 200)]:
        edges = cv2.Canny(closed, lo, hi)
        edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=2)

        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]

        for cnt in contours:
            for eps_factor in (0.02, 0.04, 0.06):
                peri = cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, eps_factor * peri, True)
                if _is_valid_quad(approx, w, h):
                    candidates.append(approx)
                    break

    if not candidates:
        return img, False

    # Pick the quad with largest area
    best = max(candidates, key=cv2.contourArea)
    pts = _order_points(best.reshape(4, 2).astype("float32"))
    tl, tr, br, bl = pts

    # Compute output size from actual side lengths (no destructive crop)
    new_w = int(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl)))
    new_h = int(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr)))
    if new_w < 100 or new_h < 100:
        return img, False

    # Sanity: if the detected quad covers almost the whole image, skip
    # (perspective correction would be minimal and could introduce artifacts)
    quad_area = cv2.contourArea(best)
    if quad_area > h * w * 0.90:
        return img, False

    dst = np.float32([[0, 0], [new_w, 0], [new_w, new_h], [0, new_h]])
    M = cv2.getPerspectiveTransform(pts, dst)
    warped = cv2.warpPerspective(img, M, (new_w, new_h), borderValue=(255, 255, 255))
    return warped, True


# ═══════════════════════════════════════════════════════════════
#  Step 3: CURVE RECTIFICATION
# ═══════════════════════════════════════════════════════════════

def _detect_curved_hlines(gray: np.ndarray):
    h, w = gray.shape
    binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY_INV, 25, 10)
    hm = np.zeros_like(binary)
    for kw in [w // 4, w // 6, w // 10]:
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(20, kw), 1))
        hm = cv2.bitwise_or(hm, cv2.morphologyEx(binary, cv2.MORPH_OPEN, k))
    contours, _ = cv2.findContours(hm, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    curves = []
    for cnt in contours:
        pts = cnt.reshape(-1, 2)
        if pts[:, 0].ptp() < w * 0.15 or pts[:, 1].ptp() > h * 0.15:
            continue
        sorted_pts = pts[pts[:, 0].argsort()]
        step = max(1, len(sorted_pts) // 50)
        curve = sorted_pts[::step]
        curves.append((float(np.median(curve[:, 1])), curve))
    curves.sort(key=lambda c: c[0])
    filtered = []
    for my, curve in curves:
        if filtered and abs(my - filtered[-1][0]) < 12:
            if len(curve) > len(filtered[-1][1]):
                filtered[-1] = (my, curve)
        else:
            filtered.append((my, curve))
    return filtered


def _rectify_curves(img: np.ndarray, curves) -> np.ndarray:
    if len(curves) < 2:
        return img
    h, w = img.shape[:2]
    map_x = np.tile(np.arange(w, dtype=np.float32), (h, 1))
    map_y = np.tile(np.arange(h, dtype=np.float32).reshape(-1, 1), (1, w))
    curve_funcs = []
    for median_y, pts in curves:
        xs, ys = pts[:, 0].astype(float), pts[:, 1].astype(float)
        order = np.argsort(xs)
        xs, ys = xs[order], ys[order]
        _, idx = np.unique(xs, return_index=True)
        xs, ys = xs[idx], ys[idx]
        if len(xs) < 2:
            continue
        y_full = np.interp(np.arange(w, dtype=float), xs, ys, left=ys[0], right=ys[-1])
        curve_funcs.append((median_y, y_full - median_y))
    if len(curve_funcs) < 2:
        return img
    curve_ys = np.array([cf[0] for cf in curve_funcs])
    for y in range(h):
        ai = np.searchsorted(curve_ys, y, side='right') - 1
        bi = ai + 1
        if ai < 0:
            disp = curve_funcs[0][1]
        elif bi >= len(curve_funcs):
            disp = curve_funcs[-1][1]
        else:
            t = (y - curve_funcs[ai][0]) / max(1, curve_funcs[bi][0] - curve_funcs[ai][0])
            disp = curve_funcs[ai][1] * (1 - t) + curve_funcs[bi][1] * t
        map_y[y, :] = y + disp
    return cv2.remap(img, map_x, map_y, cv2.INTER_LINEAR,
                     borderMode=cv2.BORDER_CONSTANT, borderValue=(255, 255, 255))


# ═══════════════════════════════════════════════════════════════
#  PUBLIC API
# ═══════════════════════════════════════════════════════════════

def correct_document(img: np.ndarray, max_deskew: float = 15.0,
                     skip_perspective: bool = False) -> np.ndarray:
    """Full CamScanner-style correction: deskew → perspective → curve rectify."""
    # Step 1: Deskew
    corrected, angle = _deskew(img, max_deskew)

    # Step 2: Perspective (skip if flag set — useful when it crops content)
    if not skip_perspective:
        corrected, _ = _perspective_correct(corrected)

    # Step 3: Curve rectify
    gray = cv2.cvtColor(corrected, cv2.COLOR_RGB2GRAY) if len(corrected.shape) == 3 else corrected
    curves = _detect_curved_hlines(gray)
    if len(curves) >= 2:
        corrected = _rectify_curves(corrected, curves)

    return corrected


def correct_document_steps(img: np.ndarray, max_deskew: float = 15.0) -> list:
    """Returns list of (label, image) for each correction step — for visualization."""
    steps = [("0. ORIGINAL", img.copy())]

    # Deskew
    deskewed, angle = _deskew(img, max_deskew)
    steps.append((f"1. DESKEW ({angle:.1f}°)", deskewed.copy()))

    # Perspective
    perspective, did = _perspective_correct(deskewed)
    steps.append((f"2. PERSPECTIVE ({'applied' if did else 'skipped'})", perspective.copy()))

    # Curve detect
    gray = cv2.cvtColor(perspective, cv2.COLOR_RGB2GRAY) if len(perspective.shape) == 3 else perspective
    curves = _detect_curved_hlines(gray)
    viz = perspective.copy()
    for _, pts in curves:
        for i in range(len(pts) - 1):
            cv2.line(viz, tuple(pts[i]), tuple(pts[i + 1]), (0, 255, 0), 2)
    steps.append((f"3a. CURVES ({len(curves)})", viz))

    # Rectify
    rectified = _rectify_curves(perspective, curves) if len(curves) >= 2 else perspective
    steps.append(("3b. RECTIFIED", rectified.copy()))

    return steps
