"""
table_compare.py — Table round-trip comparison: PDF → JSON → PNG reconstruction.

This module provides a visual quality-assurance tool for the table extraction
pipeline. For each table detected on a page it produces a side-by-side PNG image
showing:

  TOP    — the original table clipped from the PDF (rendered at 200 dpi)
  BOTTOM — the table reconstructed from the extracted JSON cell data

The reconstruction is drawn with Pillow using the compact cell format:
  Normal cell:  {"p": [row, col], "t": "text"}
  Merged cell:  {"p": [row, col, rowspan, colspan], "t": "text"}
The "shape" field [n_rows, n_cols] defines the grid dimensions.

Merged cells are highlighted in light blue; the first row (header) has a grey
background. This makes it easy to spot missing or incorrectly merged cells.

Usage (standalone):
    python -m pdf_tagger.table_compare input/file.pdf 25
    python -m pdf_tagger.table_compare input/file.pdf 25 -o /tmp/comparisons

Usage (from convert.py):
    python convert.py input/file.pdf --compare 25
    python convert.py input/file.pdf --compare all
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    raise RuntimeError("Pillow is required.")

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pdf_grid.line_tables import detect_table_bboxes, extract_table_structured


def _parse_cell(cell: Dict) -> Tuple[int, int, int, int, str]:
    """Parse compact cell: p=[r,c] or p=[r,c,rs,cs], t=text."""
    p = cell["p"]
    r, c = p[0], p[1]
    rs = p[2] if len(p) >= 4 else 1
    cs = p[3] if len(p) >= 4 else 1
    return r, c, rs, cs, cell.get("t", "")


def _get_font(size: int = 10):
    """Try to load DejaVu font, fallback to default."""
    try:
        return ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size
        )
    except Exception:
        return ImageFont.load_default()


def _wrap_text(text: str, font, max_width: int = 180) -> List[str]:
    """Word-wrap text to fit within max_width pixels."""
    if not text:
        return [""]
    words = text.replace("\n", " ").split()
    lines = []
    current = ""
    dummy = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    for word in words:
        test = (current + " " + word).strip()
        if dummy.textlength(test, font=font) > max_width and current:
            lines.append(current)
            current = word
        else:
            current = test
    if current:
        lines.append(current)
    return lines or [""]


def render_table_from_json(
    table_data: Dict[str, Any], cell_padding: int = 6
) -> Image.Image:
    """
    Reconstruct a table as a PNG image from structured JSON cell data.

    Args:
        table_data: {"cells": [...], "shape": [rows, cols]}
        cell_padding: padding inside each cell in pixels

    Returns:
        PIL Image of the reconstructed table
    """
    cells = table_data.get("cells", [])
    n_rows, n_cols = table_data.get("shape", [0, 0])
    if not cells or n_rows == 0 or n_cols == 0:
        return Image.new("RGB", (200, 50), "white")

    font = _get_font(10)
    dummy = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    line_h = 14

    # Measure to compute column widths and row heights
    col_widths = [50] * n_cols
    row_heights = [22] * n_rows

    for cell in cells:
        r, c, rs, cs, text = _parse_cell(cell)
        lines = _wrap_text(text, font, max_width=180)
        max_w = max(dummy.textlength(ln, font=font) for ln in lines) if lines else 0
        text_h = len(lines) * line_h

        w_per_col = (max_w + cell_padding * 2) / cs
        for cc in range(c, min(c + cs, n_cols)):
            col_widths[cc] = max(col_widths[cc], int(w_per_col))

        h_per_row = (text_h + cell_padding * 2) / rs
        for rr in range(r, min(r + rs, n_rows)):
            row_heights[rr] = max(row_heights[rr], int(h_per_row))

    for i in range(n_cols):
        col_widths[i] = min(col_widths[i], 220)

    # Build position arrays
    col_x = [0]
    for w in col_widths:
        col_x.append(col_x[-1] + w)
    row_y = [0]
    for h in row_heights:
        row_y.append(row_y[-1] + h)

    # Draw
    img = Image.new("RGB", (col_x[-1] + 1, row_y[-1] + 1), "white")
    draw = ImageDraw.Draw(img)

    # Grid lines
    for r in range(n_rows + 1):
        y = row_y[min(r, len(row_y) - 1)]
        draw.line([(0, y), (col_x[-1], y)], fill="gray", width=1)
    for c in range(n_cols + 1):
        x = col_x[min(c, len(col_x) - 1)]
        draw.line([(x, 0), (x, row_y[-1])], fill="gray", width=1)

    # Cell content
    for cell in cells:
        r, c, rs, cs, text = _parse_cell(cell)
        x0 = col_x[c]
        y0 = row_y[r]
        x1 = col_x[min(c + cs, n_cols)]
        y1 = row_y[min(r + rs, n_rows)]

        # Background for merged cells / header
        if rs > 1 or cs > 1:
            draw.rectangle([x0 + 1, y0 + 1, x1 - 1, y1 - 1], fill="#e8f0ff")
        elif r == 0:
            draw.rectangle([x0 + 1, y0 + 1, x1 - 1, y1 - 1], fill="#f0f0f0")

        # Borders for merged cells
        if rs > 1 or cs > 1:
            draw.rectangle([x0, y0, x1, y1], outline="black", width=1)

        # Text
        lines = _wrap_text(text, font, max_width=x1 - x0 - cell_padding * 2)
        ty = y0 + cell_padding
        for ln in lines:
            draw.text((x0 + cell_padding, ty), ln, fill="black", font=font)
            ty += line_h

    return img


def generate_comparison(
    pdf_path: str,
    page_num: int,
    output_dir: str = "/tmp/table_roundtrip",
) -> List[str]:
    """
    Generate a round-trip comparison PNG for every table on one page.

    For each detected table the function saves a PNG named
    "<pdf_stem>_p<N>_t<i>_comparison.png" in output_dir.

    Args:
        pdf_path:   Path to the source PDF.
        page_num:   1-based page number to process.
        output_dir: Directory where comparison PNGs are written.

    Returns:
        List of absolute paths to the generated PNG files (may be empty
        if no tables were found on the page).
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(pdf_path)
    page = doc.load_page(page_num - 1)
    pdf_name = Path(pdf_path).stem
    generated = []

    bboxes = detect_table_bboxes(page)
    if not bboxes:
        print(f"No tables found on page {page_num}")
        doc.close()
        return generated

    label_font = _get_font(12)

    for i, bb in enumerate(bboxes):
        x0, y0, x1, y1 = bb

        # 1. Original from PDF
        clip = fitz.Rect(x0 - 5, y0 - 5, x1 + 5, y1 + 5)
        pix = page.get_pixmap(dpi=200, clip=clip)
        gt_data = pix.tobytes("png")
        gt_img = Image.open(__import__("io").BytesIO(gt_data))

        # 2. Extract structured cells
        table_dicts = extract_table_structured(page, bb)
        if not table_dicts:
            continue
        td = table_dicts[0]

        cells_info = f"{len(td['cells'])} cells, shape={td['shape']}"
        merged = sum(1 for c in td["cells"] if len(c["p"]) == 4)
        if merged:
            cells_info += f", {merged} merged"
        print(f"  [t{i+1}] {cells_info}")

        # 3. Reconstruct
        recon_img = render_table_from_json(td)

        # 4. Vertical comparison
        scale_w = gt_img.width / max(1, recon_img.width)
        recon_resized = recon_img.resize(
            (gt_img.width, int(recon_img.height * scale_w)), Image.LANCZOS,
        )
        gap = 10
        label_h = 20
        combined_h = label_h + gt_img.height + gap + label_h + recon_resized.height
        combined = Image.new("RGB", (gt_img.width, combined_h), "white")
        d = ImageDraw.Draw(combined)
        d.text((5, 2), "ORIGINAL (PDF)", fill="blue", font=label_font)
        combined.paste(gt_img, (0, label_h))
        d.text(
            (5, label_h + gt_img.height + gap - label_h + 2),
            "RECONSTRUCTED (JSON)",
            fill="red",
            font=label_font,
        )
        combined.paste(recon_resized, (0, label_h + gt_img.height + gap + label_h))

        compare_path = out / f"{pdf_name}_p{page_num}_t{i+1}_comparison.png"
        combined.save(str(compare_path))
        print(f"       → {compare_path}")
        generated.append(str(compare_path))

    doc.close()
    return generated


def generate_all_comparisons(
    pdf_path: str,
    output_dir: str = "/tmp/table_roundtrip",
) -> List[str]:
    """
    Generate round-trip comparison PNGs for every page that contains tables.

    Scans all pages in the document, calls generate_comparison() for each
    page where detect_table_bboxes() finds at least one table.

    Args:
        pdf_path:   Path to the source PDF.
        output_dir: Directory where comparison PNGs are written.

    Returns:
        List of absolute paths to all generated PNG files across all pages.
    """
    doc = fitz.open(pdf_path)
    generated = []
    for i in range(doc.page_count):
        page = doc.load_page(i)
        try:
            bboxes = detect_table_bboxes(page)
        except Exception:
            bboxes = []
        if bboxes:
            doc.close()
            paths = generate_comparison(pdf_path, i + 1, output_dir)
            generated.extend(paths)
            doc = fitz.open(pdf_path)
    doc.close()
    return generated


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Table round-trip comparison: PDF → JSON → PNG",
    )
    parser.add_argument("pdf", help="PDF file path")
    parser.add_argument(
        "page", nargs="?", type=int, default=None,
        help="Page number (1-based). If omitted, processes all pages with tables.",
    )
    parser.add_argument(
        "-o", "--output", default="/tmp/table_roundtrip",
        help="Output directory for comparison PNGs",
    )
    args = parser.parse_args()

    if args.page:
        generate_comparison(args.pdf, args.page, args.output)
    else:
        print(f"Scanning all pages in {args.pdf}...")
        paths = generate_all_comparisons(args.pdf, args.output)
        print(f"\n{len(paths)} comparison(s) generated in {args.output}/")
