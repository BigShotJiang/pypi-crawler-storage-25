"""
Vision-based document layout detection + OCR pipeline.

Pipeline:
  1. DocLayout-YOLO detects visual regions (title, plain text, table, figure, etc.)
  2. NMS removes overlapping detections
  3. For each region: extract text via PyMuPDF (digital) or RapidOCR/PaddleOCR (scanned)
  4. Preserve indentation from OCR bbox x-positions
  5. Heuristic classifier refines YOLO labels using text content + font metadata

Works on both digital PDFs (embedded text) and scanned PDFs (image-only).

OCR backend: RapidOCR (ONNX) by default; set USE_PADDLE=1 to fall back to PaddleOCR.
"""

from __future__ import annotations

import io
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")

try:
    from PIL import Image
except ImportError:
    raise RuntimeError("Pillow is required.")

import numpy as np

# ── Lazy singletons ──
_yolo_model = None
_ocr_engine = None


def _get_yolo():
    """Lazy-load DocLayout-YOLO model."""
    global _yolo_model
    if _yolo_model is not None:
        return _yolo_model
    from doclayout_yolo import YOLOv10
    from huggingface_hub import hf_hub_download
    model_path = hf_hub_download(
        repo_id="juliozhao/DocLayout-YOLO-DocStructBench",
        filename="doclayout_yolo_docstructbench_imgsz1024.pt",
    )
    _yolo_model = YOLOv10(model_path)
    return _yolo_model


def _get_ocr():
    """Lazy-load PaddleOCR engine."""
    global _ocr_engine
    if _ocr_engine is not None:
        return _ocr_engine
    # Fix numpy 2.0 incompatibility with imgaug (used by PaddleOCR)
    import numpy as _np
    if not hasattr(_np, 'sctypes'):
        _np.sctypes = {
            "float": [_np.float16, _np.float32, _np.float64],
            "int": [_np.int8, _np.int16, _np.int32, _np.int64],
            "uint": [_np.uint8, _np.uint16, _np.uint32, _np.uint64],
            "complex": [_np.complex64, _np.complex128],
        }
    from paddleocr import PaddleOCR
    _ocr_engine = PaddleOCR(use_angle_cls=True, lang='en', show_log=False)
    return _ocr_engine


# ── Data structures ──

@dataclass
class LayoutRegion:
    """A detected layout region from YOLO + text from PyMuPDF/OCR."""
    label: str              # YOLO label: "title", "plain text", "table", etc.
    confidence: float
    bbox: Tuple[float, float, float, float]  # (x0, y0, x1, y1) in PDF points
    bbox_px: Tuple[int, int, int, int]       # (x0, y0, x1, y1) in image pixels
    text: str = ""
    lines: List[Tuple[float, str]] = field(default_factory=list)  # (x_offset, text)
    is_bold: bool = False
    is_centered: bool = False
    font_size: float = 0.0
    text_source: str = ""   # "pymupdf" or "ocr"


# ── YOLO detection ──

def _page_to_image(page, dpi: int = 200) -> Tuple[np.ndarray, float]:
    """Render PDF page to numpy array. Returns (img_np, scale)."""
    pix = page.get_pixmap(dpi=dpi)
    img = Image.open(io.BytesIO(pix.tobytes("png")))
    scale = 72.0 / dpi
    return np.array(img), scale


def detect_regions(page, conf: float = None, dpi: int = None) -> Tuple[List[LayoutRegion], np.ndarray, float]:
    """
    Run DocLayout-YOLO on a PDF page.
    Returns (regions, page_image_np, scale).
    """
    from pdf_tagger.config import get_config
    _cfg = get_config()
    if conf is None:
        conf = _cfg.yolo_confidence
    if dpi is None:
        dpi = _cfg.render_dpi
    import torch
    yolo = _get_yolo()
    img_np, scale = _page_to_image(page, dpi=dpi)
    device = "cuda:0" if torch.cuda.is_available() else "cpu"
    results = yolo.predict(img_np, imgsz=1024, conf=conf, device=device, verbose=False)

    regions: List[LayoutRegion] = []
    for r in results:
        for box, cls_id, confidence in zip(r.boxes.xyxy, r.boxes.cls, r.boxes.conf):
            px = [int(v) for v in box.tolist()]
            label = r.names[int(cls_id)]
            regions.append(LayoutRegion(
                label=label,
                confidence=float(confidence),
                bbox=(px[0] * scale, px[1] * scale, px[2] * scale, px[3] * scale),
                bbox_px=tuple(px),
            ))

    regions = _nms(regions, iou_threshold=_cfg.nms_iou_threshold)
    regions.sort(key=lambda r: r.bbox[1])
    return regions, img_np, scale


def _nms(regions: List[LayoutRegion], iou_threshold: float = 0.5) -> List[LayoutRegion]:
    """Non-maximum suppression."""
    if not regions:
        return regions
    regions.sort(key=lambda r: r.confidence, reverse=True)
    keep = []
    for region in regions:
        duplicate = False
        for kept in keep:
            if _iou(region.bbox, kept.bbox) > iou_threshold:
                duplicate = True
                break
        if not duplicate:
            keep.append(region)
    return keep


def _iou(a: Tuple, b: Tuple) -> float:
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    if ix1 <= ix0 or iy1 <= iy0:
        return 0.0
    inter = (ix1 - ix0) * (iy1 - iy0)
    union = (ax1 - ax0) * (ay1 - ay0) + (bx1 - bx0) * (by1 - by0) - inter
    return inter / max(1, union)


# ── Text extraction ──

def _is_page_scanned(page) -> bool:
    """Check if page has minimal embedded text (likely scanned)."""
    text = page.get_text("text").strip()
    return len(text) < 50


def extract_text_pymupdf(page, region: LayoutRegion, page_left: float) -> bool:
    """
    Extract text from a region using PyMuPDF embedded text.
    Returns True if text was found.
    Preserves indentation as leading spaces.
    """
    rx0, ry0, rx1, ry1 = region.bbox
    clip = fitz.Rect(rx0, ry0, rx1, ry1)

    data = page.get_text("dict", clip=clip, flags=fitz.TEXT_PRESERVE_WHITESPACE)
    lines_with_x: List[Tuple[float, float, str, float, bool]] = []

    for block in data.get("blocks", []):
        if block["type"] != 0:
            continue
        for line in block.get("lines", []):
            lbox = line["bbox"]
            parts = []
            max_size = 0.0
            bold_n = 0
            total_n = 0
            for span in line.get("spans", []):
                txt = span["text"]
                parts.append(txt)
                n = len(txt.strip())
                total_n += n
                max_size = max(max_size, span["size"])
                flags = span.get("flags", 0)
                font = span.get("font", "")
                if bool(flags & (1 << 4)) or "bold" in font.lower():
                    bold_n += n

            full = "".join(parts).strip()
            if not full:
                continue
            is_bold = (bold_n > total_n * 0.5) if total_n else False
            lines_with_x.append((lbox[0], lbox[1], full, max_size, is_bold))

    if not lines_with_x:
        return False

    # Sort by y
    lines_with_x.sort(key=lambda t: t[1])

    # Font info from first line
    region.font_size = lines_with_x[0][3]
    region.is_bold = lines_with_x[0][4]

    # Convert x0 to leading spaces
    char_width = region.font_size * 0.55 if region.font_size > 0 else 7.0
    text_lines = []
    for x0, y0, text, fsize, bold in lines_with_x:
        n_spaces = max(0, round((x0 - page_left) / char_width))
        indented = " " * n_spaces + text
        text_lines.append(indented)
        region.lines.append((x0, text))

    region.text = "\n".join(text_lines)
    region.text_source = "pymupdf"

    # Check centering
    page_width = page.rect.width
    if lines_with_x:
        region.is_centered = all(
            abs((page_width - lbox_x1) - x0) < 40 and x0 > 50
            for x0, _, _, _, _ in lines_with_x
            for lbox_x1 in [page_width - x0]  # approximate
        )

    return True


def extract_text_ocr(img_np: np.ndarray, region: LayoutRegion, page_width_px: int) -> bool:
    """
    Extract text from a region using PaddleOCR.
    Returns True if text was found.
    Preserves indentation from OCR bbox positions.
    """
    ocr = _get_ocr()
    x0, y0, x1, y1 = region.bbox_px
    crop = img_np[y0:y1, x0:x1]

    if crop.size == 0 or crop.shape[0] < 5 or crop.shape[1] < 5:
        return False

    result = ocr.ocr(crop, cls=True)
    if not result or not result[0]:
        return False

    # Extract lines with x-position
    ocr_lines: List[Tuple[float, float, str]] = []
    for line in result[0]:
        bbox_ocr, (text, score) = line
        if score < 0.3 or not text.strip():
            continue
        line_x = bbox_ocr[0][0]  # top-left x within crop
        line_y = bbox_ocr[0][1]
        ocr_lines.append((line_x, line_y, text.strip()))

    if not ocr_lines:
        return False

    # Sort by y position
    ocr_lines.sort(key=lambda t: t[1])

    # Find leftmost x as base margin within crop
    min_x = min(lx for lx, _, _ in ocr_lines)

    # Estimate char width from average line
    avg_chars = sum(len(t) for _, _, t in ocr_lines) / len(ocr_lines)
    crop_width = x1 - x0
    char_width_px = max(5, crop_width / max(1, avg_chars + 10))

    # Region indent relative to page
    region_indent_chars = max(0, round(region.bbox_px[0] / char_width_px / 2))

    text_lines = []
    for lx, ly, text in ocr_lines:
        # Indent within the region
        n_spaces = max(0, round((lx - min_x) / char_width_px))
        indented = " " * (region_indent_chars + n_spaces) + text
        text_lines.append(indented)
        region.lines.append((lx + region.bbox_px[0], text))

    region.text = "\n".join(text_lines)
    region.text_source = "ocr"

    # For OCR, trust YOLO label for bold/centered hints
    if region.label == "title":
        region.is_bold = True
        region.is_centered = True
    region.font_size = 12.0  # default estimate for OCR

    return True


# ── Classification (heuristic on top of YOLO) ──

def classify_regions(
    regions: List[LayoutRegion],
    page_height: float,
    font_sizes: List[float],
) -> List[LayoutRegion]:
    """
    Classify regions using full heuristic classifier on extracted text.
    YOLO provides region boundaries only; heuristic decides the type.
    """
    from pdf_tagger.font_classifier import TextBlock, classify_block

    prev_type = None
    for region in regions:
        stripped = region.text.strip()
        if not stripped:
            continue
        # Figure: always IMAGE, skip heuristic
        if region.label == "figure":
            region._type_id = 100
            continue

        stripped_lines = [ln.strip() for ln in stripped.split("\n")]
        content = "\n".join(stripped_lines)
        content_len = sum(len(ln) for ln in stripped_lines)
        alpha = sum(1 for c in content if c.isalpha())
        upper = sum(1 for c in content if c.isupper())

        # Build TextBlock for heuristic classifier
        block = TextBlock(
            text=region.text,
            y0=region.bbox[1],
            y1=region.bbox[3],
            x0=region.bbox[0],
            x1=region.bbox[2],
            font_size=region.font_size if region.font_size > 0 else 12.0,
            is_bold=region.is_bold,
            is_italic=False,
            is_centered=region.is_centered,
            is_allcaps=(upper > alpha * 0.7) if alpha > 5 else False,
            indent=max(0, region.bbox[0] - 72),
            line_count=len(stripped_lines),
            spans=[],
        )

        # Full heuristic classification
        type_id = classify_block(block, page_height, font_sizes, prev_type)

        # YOLO "table" refinement: trust heuristic for specific types,
        # only keep TABLE if text is substantial (avoids table fragments)
        if region.label == "table":
            has_tab_chars = '\t' in stripped or '|' in stripped
            if type_id == 10 and (len(stripped_lines) >= 7 or (len(stripped_lines) >= 4 and has_tab_chars)):
                type_id = 30  # Substantial multi-line → TABLE
            elif type_id == 10 and content_len > 300:
                type_id = 30  # Very long content → TABLE
            # else: short/fragmented → keep heuristic type

        # YOLO "title" boost: promote only very short bold text
        elif region.label == "title" and type_id == 10:
            if content_len < 60 and len(stripped_lines) <= 2:
                if region.is_bold and region.is_centered:
                    type_id = 1  # TITLE — bold, centered, very short
                elif region.is_bold:
                    type_id = 3  # H1 — bold, short

        region._type_id = type_id
        prev_type = type_id

    return regions


# ── Post-classification: split multi-line regions ──

# Stricter dot-leader: require at least 5 consecutive dots/spaces
_RE_DOT_LEADER_STRICT = re.compile(r'^(.{3,}?)\s*\.[\s.]{5,}\s*(\d{1,4})\s*$')
_RE_UNDERSCORE_LINE = re.compile(r'^\s*_{5,}\s*$')
_RE_SIGNATURE_PATTERN = re.compile(r'_{5,}|By:\s*_|Date:\s*_')

def _split_multiline_regions(elements: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Split multi-line PARAGRAPH elements that contain:
    1. TOC entries (dot-leaders) grouped by YOLO into one region
    2. Signature lines (underscores) merged with adjacent text
    """
    result = []
    for elem in elements:
        type_id = elem["type_id"]
        text = elem.get("text", "")

        # Only split PARAGRAPHs with multiple lines
        if type_id != 10:
            result.append(elem)
            continue

        lines = [ln for ln in text.split("\n") if ln.strip()]
        if len(lines) < 2:
            result.append(elem)
            continue

        # --- Split 1: Underscore/signature lines mixed with text ---
        underscore_count = sum(1 for ln in lines if _RE_UNDERSCORE_LINE.match(ln))
        if underscore_count >= 2 and underscore_count >= len(lines) * 0.3:
            y0 = elem["y0"]
            line_height = 12.0
            for i, ln in enumerate(lines):
                if _RE_UNDERSCORE_LINE.match(ln):
                    sub_type = 81  # SIGNATURE_LINE
                else:
                    sub_type = 10  # PARAGRAPH
                result.append({
                    "type_id": sub_type,
                    "text": ln,
                    "y0": y0 + i * line_height,
                })
            continue

        # --- Split 2: TOC entries (dot-leaders) ---
        if len(lines) >= 3:
            toc_count = sum(1 for ln in lines if _RE_DOT_LEADER_STRICT.match(ln.strip()))
            if toc_count >= 3 and toc_count >= len(lines) * 0.5:
                y0 = elem["y0"]
                line_height = 12.0
                for i, ln in enumerate(lines):
                    sub_type = 70 if _RE_DOT_LEADER_STRICT.match(ln.strip()) else 10
                    result.append({
                        "type_id": sub_type,
                        "text": ln,
                        "y0": y0 + i * line_height,
                    })
                continue

        result.append(elem)

    return result


# ── Gap filling ──

def _fill_gaps(page, regions: List[LayoutRegion], page_left: float) -> List[LayoutRegion]:
    """
    Find text in areas not covered by any YOLO region.
    Catches elements YOLO misses: HORIZONTAL_RULE, SIGNATURE_LINE, etc.
    Only works on digital PDFs (uses PyMuPDF).
    """
    page_rect = page.rect
    if not regions:
        return regions

    # Sort by y position
    sorted_regions = sorted(regions, key=lambda r: r.bbox[1])

    # Find vertical gaps between regions
    gaps: List[Tuple[float, float]] = []
    prev_bottom = page_rect.y0
    for r in sorted_regions:
        if r.bbox[1] > prev_bottom + 5:  # at least 5pt gap
            gaps.append((prev_bottom, r.bbox[1]))
        prev_bottom = max(prev_bottom, r.bbox[3])
    # Gap after last region
    if page_rect.y1 > prev_bottom + 5:
        gaps.append((prev_bottom, page_rect.y1))

    # Extract text from gaps
    new_regions = []
    for gap_top, gap_bottom in gaps:
        clip = fitz.Rect(page_rect.x0, gap_top, page_rect.x1, gap_bottom)
        text = page.get_text("text", clip=clip).strip()
        if not text or len(text) < 3:
            continue

        gap_region = LayoutRegion(
            label="gap_fill",
            confidence=0.0,
            bbox=(page_rect.x0, gap_top, page_rect.x1, gap_bottom),
            bbox_px=(0, 0, 0, 0),
        )
        extract_text_pymupdf(page, gap_region, page_left)
        if gap_region.text.strip():
            new_regions.append(gap_region)

    return regions + new_regions


# ── Public API ──

def process_page_vision(
    page,
    page_idx: int,
    page_count: int,
    dpi: int = 200,
) -> List[Dict[str, Any]]:
    """
    Full vision pipeline for one page.
    Returns flat list of dicts with type_id, text, y0.

    Digital pages: uses heuristic text grouping (extract_text_blocks + classify_block)
    for identical precision, augmented with YOLO-detected figures/tables.
    Scanned pages: YOLO regions + OCR + heuristic classification.
    """
    from pdf_tagger.font_classifier import (
        extract_text_blocks, classify_block, get_page_font_sizes,
    )

    page_height = page.rect.height or 800
    page_left = page.rect.x0
    is_scanned = _is_page_scanned(page)

    # 1. YOLO detect regions (always — needed for figures/tables/scanned)
    regions, img_np, scale = detect_regions(page, conf=0.2, dpi=dpi)

    elements: List[Dict[str, Any]] = []

    if not is_scanned:
        # ── Digital page: heuristic text grouping + YOLO augmentation ──

        # Get table bboxes to exclude from text extraction
        from pdf_grid.line_tables import detect_table_bboxes
        try:
            table_bboxes = detect_table_bboxes(page)
        except Exception:
            table_bboxes = []

        # Extract and classify text blocks using heuristic pipeline
        font_sizes = get_page_font_sizes(page, excluded_bboxes=table_bboxes)
        text_blocks = extract_text_blocks(page, excluded_bboxes=table_bboxes)

        prev_type = None
        for block in text_blocks:
            type_id = classify_block(block, page_height, font_sizes, prev_type)
            elements.append({
                "type_id": type_id,
                "text": block.text,
                "y0": block.y0,
            })
            prev_type = type_id

        # YOLO augmentation: add figures that heuristic missed
        # (tables are handled by pdf_grid in tagger_json.py, so skip YOLO tables)
        covered_y = [(e["y0"], e["y0"] + 20) for e in elements]

        for region in regions:
            ry = region.bbox[1]
            if region.label == "figure":
                already_covered = any(abs(ry - cy) < 30 for cy, _ in covered_y)
                if not already_covered:
                    elements.append({
                        "type_id": 100,  # IMAGE
                        "text": "",
                        "y0": ry,
                    })
                    covered_y.append((ry, ry + 20))

    else:
        # ── Scanned page: YOLO regions + OCR + heuristic classification ──

        # Extract text via OCR for each region
        for region in regions:
            if region.label == "figure":
                continue
            extract_text_ocr(img_np, region, img_np.shape[1])

        # Fill gaps (digital text that PyMuPDF can still extract)
        regions = _fill_gaps(page, regions, page_left)

        # Classify with heuristic
        font_sizes = []  # No reliable font sizes on scanned pages
        regions = classify_regions(regions, page_height, font_sizes)

        # Demote excess TITLEs
        is_edge_page = page_idx < max(1, page_count * 0.1) or page_idx >= page_count * 0.9
        max_font = max((r.font_size for r in regions if r.font_size > 0), default=12.0)
        title_regions = [r for r in regions if getattr(r, '_type_id', 10) == 1]

        for r in title_regions:
            has_biggest_font = r.font_size >= max_font * 0.95 and r.font_size > 14
            if not is_edge_page and not has_biggest_font:
                r._type_id = 3  # H1

        remaining_titles = [r for r in regions if getattr(r, '_type_id', 10) == 1]
        if len(remaining_titles) > 2:
            for r in remaining_titles[2:]:
                r._type_id = 3  # H1

        # Build elements from classified regions
        for region in regions:
            if not region.text.strip() or region.label == "figure":
                continue
            type_id = getattr(region, '_type_id', 10)
            elements.append({
                "type_id": type_id,
                "text": region.text,
                "y0": region.bbox[1],
            })

        # Split multi-line regions (TOC/signatures grouped by YOLO)
        elements = _split_multiline_regions(elements)

    elements.sort(key=lambda e: e["y0"])
    return elements


def process_scanned_page(
    page,
    page_idx: int,
    page_count: int,
    marks_detector=None,
    dpi: int = 200,
) -> List[Dict[str, Any]]:
    """
    Vision pipeline for scanned pages with marks detection.

    Uses YOLO + OCR + TexTAR to produce elements with marks + decorated text,
    compatible with the v2 heuristic output format.

    Returns flat list of dicts: {type_id, text, decorated_text, marks, y0}
    """
    from pdf_tagger.font_classifier import get_page_font_sizes

    page_height = page.rect.height or 800
    page_left = page.rect.x0

    # 1. YOLO detect regions
    regions, img_np, scale = detect_regions(page, conf=0.2, dpi=dpi)

    # 2a. Structured table extraction for table regions (vision_layout was OCR-only before)
    _extract_table_structures(regions, img_np)

    # 2b. Extract text via OCR for each non-table region (tables got structured extraction)
    for region in regions:
        if region.label == "figure":
            continue
        if getattr(region, "_table_struct", None) is not None:
            continue
        extract_text_ocr(img_np, region, img_np.shape[1])

    # 3. Fill gaps
    regions = _fill_gaps(page, regions, page_left)

    # 4. Classify with heuristic
    font_sizes = []
    regions = classify_regions(regions, page_height, font_sizes)

    # 5. Demote excess TITLEs
    is_edge_page = page_idx < max(1, page_count * 0.1) or page_idx >= page_count * 0.9
    max_font = max((r.font_size for r in regions if r.font_size > 0), default=12.0)
    title_regions = [r for r in regions if getattr(r, '_type_id', 10) == 1]
    for r in title_regions:
        has_biggest_font = r.font_size >= max_font * 0.95 and r.font_size > 14
        if not is_edge_page and not has_biggest_font:
            r._type_id = 3
    remaining_titles = [r for r in regions if getattr(r, '_type_id', 10) == 1]
    if len(remaining_titles) > 2:
        for r in remaining_titles[2:]:
            r._type_id = 3

    # 6. Build elements with marks from TexTAR
    elements: List[Dict[str, Any]] = []

    for region in regions:
        ts = getattr(region, "_table_struct", None)
        if ts is not None:
            elem = {
                "type_id": 30,  # TABLE
                "shape": ts["shape"],
                "cells": ts["cells"],
                "decorated_text": "",
                "marks": [],
                "y0": region.bbox[1],
                "bbox": tuple(float(v) for v in region.bbox),
                "source": ts.get("method", "vision_table"),
            }
            elements.append(elem)
            continue

        if not region.text.strip() or region.label == "figure":
            continue
        type_id = getattr(region, '_type_id', 10)

        # Get marks via TexTAR if detector available and region has OCR lines
        marks: List[str] = []
        decorated_text = region.text

        if marks_detector and region.lines:
            try:
                from pdf_tagger.marks_vision import build_decorated_text

                # Build word bboxes from region lines (pixel coords)
                word_bboxes = []
                word_texts = []
                for x_offset, text in region.lines:
                    # Approximate pixel coords from PDF coords
                    px_scale = dpi / 72.0
                    wx0 = x_offset * px_scale
                    wy0 = region.bbox[1] * px_scale
                    wx1 = wx0 + len(text) * 7 * px_scale  # rough estimate
                    wy1 = wy0 + 14 * px_scale
                    for word in text.split():
                        word_bboxes.append((wx0, wy0, wx1, wy1))
                        word_texts.append(word)
                        wx0 = wx1 + 5

                if word_bboxes:
                    word_marks = marks_detector.predict_marks(img_np, word_bboxes, word_texts)
                    decorated_text, marks = build_decorated_text(word_marks)
            except Exception as e:
                logger.debug("TexTAR marks failed for region: %s", e)

        elements.append({
            "type_id": type_id,
            "text": region.text,
            "decorated_text": decorated_text,
            "marks": marks,
            "y0": region.bbox[1],
        })

    # 7. HDBSCAN full-page fallback: if NO table was detected by YOLO+TT,
    #    OCR the entire page and cluster words to find tables.
    has_tables = any(e.get("type_id") == 30 for e in elements)
    if not has_tables and img_np is not None:
        try:
            from pdf_tagger.cluster_cells import infer_from_word_bboxes

            # Use RapidOCR (ONNX) for full-page OCR — more robust to distortion
            # than PaddleOCR on warped/curved phone photos
            from rapidocr_onnxruntime import RapidOCR as _RapidOCR
            _rapid = _RapidOCR()
            ocr_result, _ = _rapid(img_np)
            bboxes, texts, confs = [], [], []
            if ocr_result:
                for polygon, text, score in ocr_result:
                    if score < 0.3 or not text.strip():
                        continue
                    xs = [p[0] for p in polygon]
                    ys = [p[1] for p in polygon]
                    bboxes.append((min(xs), min(ys), max(xs), max(ys)))
                    texts.append(text.strip())
                    confs.append(score * 100)
            if len(bboxes) >= 6:
                h_img, w_img = img_np.shape[:2]
                cluster_result = infer_from_word_bboxes(bboxes, texts, w_img, h_img, confs)
                if cluster_result and cluster_result.get("cells"):
                    scale = page_height / h_img if h_img > 0 else 1.0
                    table_y0 = min(b[1] for b in bboxes) * scale
                    table_x0 = min(b[0] for b in bboxes) * scale
                    table_y1 = max(b[3] for b in bboxes) * scale
                    table_x1 = max(b[2] for b in bboxes) * scale
                    elements.append({
                        "type_id": 30,
                        "shape": cluster_result["shape"],
                        "cells": cluster_result["cells"],
                        "decorated_text": "",
                        "marks": [],
                        "y0": table_y0,
                        "bbox": (table_x0, table_y0, table_x1, table_y1),
                        "source": "hdbscan_fullpage",
                    })
                    logger.info("HDBSCAN full-page fallback found table: shape=%s", cluster_result["shape"])
        except Exception as e:
            logger.debug("HDBSCAN full-page fallback failed: %s", e)

    # 8. Split multi-line regions
    elements = _split_multiline_regions(elements)
    elements.sort(key=lambda e: e["y0"])
    return elements


def _extract_table_structures(regions, img_np):
    """Run table_vision.extract_table_from_image on YOLO 'table' regions.

    Populates region._table_struct = {"shape": [rows, cols], "cells": [...]} on success.
    Silently falls back to OCR-only if Table Transformer weights unavailable.
    """
    # Must load PaddleOCR BEFORE Table Transformer — loading Paddle after
    # transformers native libs causes a segfault in paddle.fluid.core on Linux.
    try:
        _get_ocr()
    except Exception as e:
        logger.debug("PaddleOCR unavailable, table cell OCR disabled: %s", e)

    try:
        from pdf_tagger.table_vision import extract_table_from_image
    except Exception as e:
        logger.debug("table_vision unavailable: %s", e)
        return

    def _ocr_fn(crop):
        try:
            ocr = _get_ocr()
            result = ocr.ocr(crop, cls=True)
            if result and result[0]:
                return " ".join(t for _, (t, s) in result[0] if s > 0.3)
        except Exception:
            pass
        return ""

    def _ocr_words(crop):
        """OCR a crop and return (bboxes, texts, confs) for HDBSCAN clustering.
        Uses RapidOCR (ONNX) — more robust to distortion than PaddleOCR."""
        try:
            from rapidocr_onnxruntime import RapidOCR as _RapidOCR
            _rapid = _RapidOCR()
            result, _ = _rapid(crop)
            if not result:
                return [], [], []
            bboxes, texts, confs = [], [], []
            for polygon, text, score in result:
                if score < 0.3 or not text.strip():
                    continue
                xs = [p[0] for p in polygon]
                ys = [p[1] for p in polygon]
                bboxes.append((min(xs), min(ys), max(xs), max(ys)))
                texts.append(text.strip())
                confs.append(score * 100)
            return bboxes, texts, confs
        except Exception:
            return [], [], []

    def _score_struct(result, n_words):
        """Quality score for a table structure dict. Higher is better.

        - Rewards fill_rate (non-empty cells / total grid slots).
        - Penalizes high merge_ratio beyond 40%.
        - Rewards shape compatibility with word count (prefers shapes where
          total_cells is roughly in line with n_words; avoids tiny shapes
          hiding words and oversized shapes with many empties).
        """
        if not result:
            return -1.0
        shape = result.get("shape") or [0, 0]
        cells = result.get("cells") or []
        nr, nc = int(shape[0]), int(shape[1])
        total = max(1, nr * nc)
        if nr < 2 or nc < 2:
            return -0.5
        n_non_empty = sum(
            1 for c in cells
            if isinstance(c, dict) and (c.get("t") or "").strip()
        )
        n_merged = sum(
            1 for c in cells
            if isinstance(c, dict) and isinstance(c.get("p"), (list, tuple))
            and len(c["p"]) == 4 and ((c["p"][2] or 1) > 1 or (c["p"][3] or 1) > 1)
        )
        fill = n_non_empty / total
        merge_ratio = n_merged / max(1, len(cells))
        # Linear penalty from 0: any merge is slightly suspicious; many merges
        # are very suspicious. Previously only penalized above 0.4 which let
        # over-segmented grids (HDBSCAN w/ 15 merges) score high.
        from pdf_tagger.config import get_config
        merge_penalty = merge_ratio * get_config().merge_penalty_factor
        # Word-count compatibility: shapes whose non-empty cells are close to
        # n_words are more likely to be correct. If HDBSCAN invents columns,
        # n_non_empty stays ~= n_words but total >> n_words → fill drops.
        # So fill already captures this implicitly. Add small bonus for shapes
        # where n_non_empty / n_words is in [0.6, 1.2] (no word lost, few dups).
        bonus = 0.0
        if n_words > 0:
            ratio = n_non_empty / n_words
            if 0.6 <= ratio <= 1.2:
                bonus = 0.2
        return fill + bonus - merge_penalty

    for region in regions:
        if region.label != "table":
            continue
        x0, y0, x1, y1 = region.bbox_px
        crop = img_np[y0:y1, x0:x1]
        if crop.size == 0:
            continue

        # Run BOTH strategies and pick the higher-scoring result.
        # HDBSCAN is warp-invariant but can mis-cluster columns; TATR+OpenCV
        # handles bordered tables well but over-detects merges. Scoring
        # (fill_rate, merge_ratio, word-count compatibility) picks the winner.
        candidates = []

        bboxes, texts, confs = _ocr_words(crop)
        n_words = len(bboxes)

        if n_words >= 4:
            try:
                from pdf_tagger.cluster_cells import infer_from_word_bboxes
                cluster_result = infer_from_word_bboxes(
                    bboxes, texts, crop.shape[1], crop.shape[0], confs
                )
                if cluster_result and cluster_result.get("cells"):
                    cluster_result["method"] = cluster_result.get("method", "hdbscan")
                    s = _score_struct(cluster_result, n_words)
                    candidates.append((s, cluster_result))
                    logger.debug("HDBSCAN score=%.3f shape=%s", s, cluster_result.get("shape"))
            except Exception as e:
                logger.debug("HDBSCAN clustering failed: %s", e)

        try:
            tt_result = extract_table_from_image(
                crop, ocr_fn=_ocr_fn,
                word_bboxes=bboxes if bboxes else None,
                word_texts=texts if texts else None,
            )
            if tt_result and tt_result.get("cells"):
                tt_result["method"] = tt_result.get("method", "vision_table")
                s = _score_struct(tt_result, n_words)
                candidates.append((s, tt_result))
                logger.debug("TATR score=%.3f shape=%s", s, tt_result.get("shape"))
        except Exception as e:
            logger.debug("extract_table_from_image failed: %s", e)

        if candidates:
            candidates.sort(key=lambda x: x[0], reverse=True)
            best_score, best = candidates[0]
            logger.info("Table struct winner: %s shape=%s score=%.3f (n_words=%d, candidates=%d)",
                        best.get("method"), best.get("shape"), best_score, n_words, len(candidates))
            region._table_struct = best
