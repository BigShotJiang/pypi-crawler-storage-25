"""
marks_vision.py — Text style detection for scanned pages.

Uses TexTAR (ICDAR 2025) for bold/italic/underline detection from word crops,
plus OpenCV heuristics for strikethrough and superscript.

Pipeline:
  1. PaddleOCR provides word bounding boxes + text
  2. Each word is cropped from the page image (resized to 96×128)
  3. TexTAR classifies: T1 (normal/bold/italic/bold+italic), T2 (normal/underline/strikeout)
  4. OpenCV detects strikethrough (horizontal lines through text center)
  5. Superscript detected by bbox height ratio vs line median

Produces marks compatible with the v2 heuristic format:
  BOLD, ITALIC, UNDERLINE, STRIKETHROUGH, SUPERSCRIPT, MONOSPACE
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import cv2
import numpy as np

from pdf_tagger.config import get_config

logger = logging.getLogger(__name__)

try:
    import torch
except ImportError:
    torch = None

_detector_singleton: Optional["TexTARMarksDetector"] = None


def get_marks_detector() -> "TexTARMarksDetector":
    """Lazy singleton — model loaded only when first scanned page is encountered."""
    global _detector_singleton
    if _detector_singleton is None:
        _detector_singleton = TexTARMarksDetector()
    return _detector_singleton


class TexTARMarksDetector:
    """Wrapper around TexTAR model for per-word style classification."""

    SEQUENCE_SIZE = 125
    CROP_H, CROP_W = get_config().textar_crop_h, get_config().textar_crop_w
    T1_LABELS = ["NORMAL", "BOLD", "ITALIC", "BOLD+ITALIC"]
    T2_LABELS = ["NORMAL", "UNDERLINE", "STRIKEOUT", "U+S"]

    def __init__(self, weights_path: str = None):
        if torch is None:
            raise RuntimeError("PyTorch is required for TexTAR marks detection.")

        if weights_path is None:
            candidates = [
                Path(__file__).resolve().parent.parent / "models" / "textar-trained.pt",
                Path(os.environ.get("TEXTAR_WEIGHTS_PATH", "")) if os.environ.get("TEXTAR_WEIGHTS_PATH") else None,
            ]
            for c in candidates:
                if c and c.exists():
                    weights_path = str(c)
                    break

        if not weights_path or not Path(weights_path).exists():
            raise FileNotFoundError(
                "TexTAR weights not found. Place textar-trained.pt in models/ "
                "or set TEXTAR_WEIGHTS_PATH environment variable."
            )

        self.model = self._load_model(weights_path)
        logger.info("TexTAR model loaded from %s", weights_path)

    def _load_model(self, weights_path: str):
        """Load TexTAR architecture and trained weights."""
        import sys
        # Add textar_model to path for imports
        model_dir = str(Path(__file__).resolve().parent / "textar_model")
        if model_dir not in sys.path:
            sys.path.insert(0, model_dir)

        from textar import model as textar_model_factory
        import copy

        model = copy.deepcopy(textar_model_factory)
        ckpt = torch.load(weights_path, map_location="cpu", weights_only=False)
        if "model_state_dict" in ckpt:
            model.load_state_dict(ckpt["model_state_dict"], strict=False)
        else:
            model.load_state_dict(ckpt, strict=False)
        model.eval()
        model.cpu()
        model.freqs = model.freqs.cpu()
        return model

    def predict_marks(
        self,
        page_image: np.ndarray,
        word_bboxes: List[Tuple[float, float, float, float]],
        word_texts: List[str],
    ) -> List[Dict[str, Any]]:
        """
        Classify text style for each word in a page image.

        Args:
            page_image: RGB numpy array of the rendered page
            word_bboxes: list of (x0, y0, x1, y1) in pixel coordinates
            word_texts: list of OCR'd text for each word

        Returns:
            list of {"text": str, "marks": set, "bbox": tuple} per word
        """
        if not word_bboxes:
            return []

        img_h, img_w = page_image.shape[:2]
        crops = []
        coords = []

        for x0, y0, x1, y1 in word_bboxes:
            # Crop with padding
            pad = 3
            cx0 = max(0, int(x0) - pad)
            cy0 = max(0, int(y0) - pad)
            cx1 = min(img_w, int(x1) + pad)
            cy1 = min(img_h, int(y1) + pad)

            crop = page_image[cy0:cy1, cx0:cx1]
            if crop.shape[0] < 3 or crop.shape[1] < 3:
                # Too small — white placeholder
                crop = np.ones((self.CROP_H, self.CROP_W, 3), dtype=np.uint8) * 255

            # Resize to model input size
            crop_resized = cv2.resize(crop, (self.CROP_W, self.CROP_H))
            crop_tensor = torch.from_numpy(crop_resized).permute(2, 0, 1).float() / 255.0
            crops.append(crop_tensor)

            # Normalized coordinates
            coords.append([
                (x0 + x1) / 2.0 / max(img_w, 1),
                (y0 + y1) / 2.0 / max(img_h, 1),
            ])

        # Process in batches of SEQUENCE_SIZE
        results = []
        for batch_start in range(0, len(crops), self.SEQUENCE_SIZE):
            batch_crops = crops[batch_start:batch_start + self.SEQUENCE_SIZE]
            batch_coords = coords[batch_start:batch_start + self.SEQUENCE_SIZE]

            # Pad to SEQUENCE_SIZE
            while len(batch_crops) < self.SEQUENCE_SIZE:
                batch_crops.append(torch.ones(3, self.CROP_H, self.CROP_W))
                batch_coords.append([0.0, 0.0])

            inp = torch.stack(batch_crops).unsqueeze(0)
            crd = torch.tensor(batch_coords).unsqueeze(0)

            with torch.no_grad():
                out = self.model(inp, {"coods": crd})  # [125, 8]

            t1_logits = out[:, :4]
            t2_logits = out[:, 4:]
            t1_preds = torch.argmax(t1_logits, dim=1).tolist()
            t2_preds = torch.argmax(t2_logits, dim=1).tolist()

            # Map predictions to marks
            actual_count = min(self.SEQUENCE_SIZE, len(crops) - batch_start)
            for i in range(actual_count):
                idx = batch_start + i
                marks = set()

                t1 = self.T1_LABELS[t1_preds[i]]
                if t1 == "BOLD":
                    marks.add("BOLD")
                elif t1 == "ITALIC":
                    marks.add("ITALIC")
                elif t1 == "BOLD+ITALIC":
                    marks.add("BOLD")
                    marks.add("ITALIC")

                t2 = self.T2_LABELS[t2_preds[i]]
                if t2 == "UNDERLINE" or t2 == "U+S":
                    marks.add("UNDERLINE")
                if t2 == "STRIKEOUT" or t2 == "U+S":
                    marks.add("STRIKETHROUGH")

                results.append({
                    "text": word_texts[idx] if idx < len(word_texts) else "",
                    "marks": marks,
                    "bbox": word_bboxes[idx] if idx < len(word_bboxes) else (0, 0, 0, 0),
                })

        # Detect superscript by bbox height comparison
        _detect_superscript(results, word_bboxes)

        # Detect strikethrough via OpenCV (fallback for TexTAR's weakness)
        _detect_strikethrough_cv(results, page_image, word_bboxes)

        return results


def _detect_superscript(
    results: List[Dict], bboxes: List[Tuple[float, float, float, float]]
) -> None:
    """Mark words as SUPERSCRIPT if significantly smaller and elevated."""
    if len(bboxes) < 3:
        return

    heights = [b[3] - b[1] for b in bboxes if (b[3] - b[1]) > 3]
    if not heights:
        return
    median_h = sorted(heights)[len(heights) // 2]

    for i, (x0, y0, x1, y1) in enumerate(bboxes):
        if i >= len(results):
            break
        h = y1 - y0
        if h < median_h * get_config().superscript_height_ratio and h > 2:
            results[i]["marks"].add("SUPERSCRIPT")


def _detect_strikethrough_cv(
    results: List[Dict],
    page_image: np.ndarray,
    bboxes: List[Tuple[float, float, float, float]],
) -> None:
    """Detect strikethrough using OpenCV horizontal line detection."""
    if not bboxes or page_image.size == 0:
        return

    gray = cv2.cvtColor(page_image, cv2.COLOR_RGB2GRAY) if len(page_image.shape) == 3 else page_image
    _, thresh = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY_INV)

    # Detect long horizontal lines
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(30, page_image.shape[1] // 30), 1))
    horiz = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, h_kernel)

    for i, (x0, y0, x1, y1) in enumerate(bboxes):
        if i >= len(results):
            break
        # Check for horizontal line through the middle of the word
        mid_y = int((y0 + y1) / 2)
        y_start = max(0, mid_y - 3)
        y_end = min(page_image.shape[0], mid_y + 4)
        ix0, ix1 = max(0, int(x0)), min(page_image.shape[1], int(x1))

        if ix1 <= ix0 or y_end <= y_start:
            continue

        region = horiz[y_start:y_end, ix0:ix1]
        coverage = np.sum(region > 0) / max(1, region.size)
        if coverage > get_config().strikethrough_cv_coverage:
            results[i]["marks"].add("STRIKETHROUGH")


def build_decorated_text(words_with_marks: List[Dict]) -> Tuple[str, List[str]]:
    """
    Build decorated text with inline markers from per-word marks.

    Produces the same syntax as _compute_marks_and_text() in the heuristic:
      **bold**, *italic*, ***bold+italic***, ~~strike~~, ++underline++,
      ^superscript^, `monospace`

    Returns (decorated_text, sorted_marks_list).
    """
    all_marks: Set[str] = set()
    parts = []

    for wm in words_with_marks:
        t = wm["text"]
        marks = wm["marks"]
        all_marks.update(marks)

        if not t.strip():
            parts.append(t)
            continue

        # Apply inline markers (same order as v2 heuristic)
        if "SUPERSCRIPT" in marks:
            t = f"^{t}^"
        if "MONOSPACE" in marks:
            t = f"`{t}`"
        if "STRIKETHROUGH" in marks:
            t = f"~~{t}~~"
        elif "UNDERLINE" in marks:
            t = f"++{t}++"

        if "BOLD" in marks and "ITALIC" in marks:
            t = f"***{t}***"
        elif "BOLD" in marks:
            t = f"**{t}**"
        elif "ITALIC" in marks:
            t = f"*{t}*"

        parts.append(t)

    decorated = " ".join(parts)
    return decorated, sorted(all_marks)
