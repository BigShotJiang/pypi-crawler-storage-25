"""
Element Type Catalog — Every structural element in a PDF document.
Each element has: id, code, category, description.
"""

CATALOG = {
    # ── TITLES & HEADINGS ──
    1:  {"code": "TITLE",           "cat": "heading",    "desc": "Document main title"},
    2:  {"code": "SUBTITLE",        "cat": "heading",    "desc": "Document subtitle or secondary title"},
    3:  {"code": "H1",              "cat": "heading",    "desc": "Section heading level 1 (e.g. ARTICLE 1, Section 1)"},
    4:  {"code": "H2",              "cat": "heading",    "desc": "Section heading level 2 (e.g. 1.A, a.)"},
    5:  {"code": "H3",              "cat": "heading",    "desc": "Section heading level 3 (e.g. (1), i.)"},
    6:  {"code": "H4",              "cat": "heading",    "desc": "Section heading level 4 (e.g. (a), (A), 1))"},

    # ── BODY TEXT ──
    10: {"code": "PARAGRAPH",       "cat": "body",       "desc": "Regular paragraph text"},
    11: {"code": "CONTINUATION",    "cat": "body",       "desc": "Continuation of previous paragraph (wrapped line)"},
    12: {"code": "QUOTE_BLOCK",     "cat": "body",       "desc": "Indented quoted block or contract language in quotes"},
    13: {"code": "DEFINITION",      "cat": "body",       "desc": "Defined term with explanation ('X' means...)"},
    14: {"code": "AMENDMENT_ADD",    "cat": "body",       "desc": "Added text (underlined in amendment)"},
    15: {"code": "AMENDMENT_DEL",    "cat": "body",       "desc": "Deleted text (strikethrough in amendment)"},
    16: {"code": "INSTRUCTION",     "cat": "body",       "desc": "Drafter instruction (e.g. 'Make conforming changes')"},

    # ── LISTS ──
    20: {"code": "LIST_NUM",        "cat": "list",       "desc": "Numbered list item (1., 2., 3.)"},
    21: {"code": "LIST_ALPHA",      "cat": "list",       "desc": "Lettered list item (a., b., c.)"},
    22: {"code": "LIST_ROMAN",      "cat": "list",       "desc": "Roman numeral list item (i., ii., iii.)"},
    23: {"code": "LIST_PAREN",      "cat": "list",       "desc": "Parenthetical list item ((1), (a), (A))"},
    24: {"code": "LIST_BULLET",     "cat": "list",       "desc": "Bullet point item (•, -, *)"},
    25: {"code": "LIST_NESTED",     "cat": "list",       "desc": "Deeply nested list item (multi-level indent)"},

    # ── TABLES ──
    30: {"code": "TABLE",           "cat": "table",      "desc": "Table (with dimensions rows×cols)"},
    31: {"code": "TABLE_HEADER",    "cat": "table",      "desc": "Table header row"},
    32: {"code": "TABLE_ROW",       "cat": "table",      "desc": "Table data row"},
    33: {"code": "TABLE_CAPTION",   "cat": "table",      "desc": "Table caption or title above/below table"},

    # ── HEADERS & FOOTERS ──
    40: {"code": "PAGE_HEADER",     "cat": "meta",       "desc": "Page header (running header, doc ID)"},
    41: {"code": "PAGE_FOOTER",     "cat": "meta",       "desc": "Page footer (file path, doc number)"},
    42: {"code": "PAGE_NUMBER",     "cat": "meta",       "desc": "Page number"},
    43: {"code": "DOC_ID",          "cat": "meta",       "desc": "Document identifier (DocuSign ID, envelope ID)"},
    44: {"code": "WATERMARK",       "cat": "meta",       "desc": "Watermark or stamp text"},
    45: {"code": "VERSION_MARK",    "cat": "meta",       "desc": "Version/reformat indicator"},

    # ── REFERENCES ──
    50: {"code": "CROSS_REF",       "cat": "reference",  "desc": "Internal cross-reference (See Section X)"},
    51: {"code": "FOOTNOTE_REF",    "cat": "reference",  "desc": "Footnote reference marker in text"},
    52: {"code": "FOOTNOTE",        "cat": "reference",  "desc": "Footnote content at bottom of page"},
    53: {"code": "ENDNOTE",         "cat": "reference",  "desc": "Endnote content"},
    54: {"code": "LEGAL_CITE",      "cat": "reference",  "desc": "Legal citation or statutory reference"},

    # ── STRUCTURAL ──
    60: {"code": "SECTION_BREAK",   "cat": "structure",  "desc": "Section divider (*** or horizontal rule)"},
    61: {"code": "PAGE_BREAK",      "cat": "structure",  "desc": "Page break marker"},
    62: {"code": "BLANK_LINE",      "cat": "structure",  "desc": "Intentional blank line / whitespace separator"},
    63: {"code": "HORIZONTAL_RULE", "cat": "structure",  "desc": "Horizontal line/rule divider"},

    # ── SPECIAL SECTIONS ──
    70: {"code": "TOC_ENTRY",       "cat": "navigation", "desc": "Table of contents entry"},
    71: {"code": "APPENDIX_LABEL",  "cat": "navigation", "desc": "Appendix header (APPENDIX A)"},
    72: {"code": "EXHIBIT_LABEL",   "cat": "navigation", "desc": "Exhibit header (EXHIBIT 'A')"},
    73: {"code": "SCHEDULE_LABEL",  "cat": "navigation", "desc": "Schedule header (Schedule A)"},
    74: {"code": "SIDELETTER_LABEL","cat": "navigation", "desc": "Sideletter header"},
    75: {"code": "ATTACHMENT_LABEL","cat": "navigation", "desc": "Attachment header"},

    # ── SIGNATURE & AUTHENTICATION ──
    80: {"code": "SIGNATURE_BLOCK", "cat": "signature",  "desc": "Signature block (name, title, date line)"},
    81: {"code": "SIGNATURE_LINE",  "cat": "signature",  "desc": "Signature line (underscores for signing)"},
    82: {"code": "PARTY_ID",        "cat": "signature",  "desc": "Party identification block (FOR THE ...)"},
    83: {"code": "DATE_LINE",       "cat": "signature",  "desc": "Date line in signature area"},
    84: {"code": "WITNESS",         "cat": "signature",  "desc": "Witness/attestation text (WITNESSETH)"},

    # ── PREAMBLE & OPENING ──
    90: {"code": "PREAMBLE",        "cat": "opening",    "desc": "Opening preamble (This agreement is entered into...)"},
    91: {"code": "RECITAL",         "cat": "opening",    "desc": "Recital/whereas clause"},
    92: {"code": "EFFECTIVE_DATE",  "cat": "opening",    "desc": "Effective date declaration"},
    93: {"code": "CONFIDENTIAL",    "cat": "opening",    "desc": "Confidentiality notice"},

    # ── IMAGES ──
    100: {"code": "IMAGE",          "cat": "media",      "desc": "Embedded image (logo, chart, scan)"},
    101: {"code": "SIGNATURE_IMG",  "cat": "media",      "desc": "Signature image"},
    102: {"code": "LOGO",           "cat": "media",      "desc": "Company/organization logo"},
    103: {"code": "STAMP",          "cat": "media",      "desc": "Official stamp or seal image"},
    104: {"code": "CHART",          "cat": "media",      "desc": "Chart or diagram image"},

    # ── ENTITY LISTS ──
    110: {"code": "ENTITY_LIST",    "cat": "data",       "desc": "List of company/entity names"},
    111: {"code": "ADDRESS_BLOCK",  "cat": "data",       "desc": "Address block"},
    112: {"code": "RATE_SCHEDULE",  "cat": "data",       "desc": "Compensation/rate schedule"},
    113: {"code": "FORMULA",        "cat": "data",       "desc": "Mathematical formula or calculation"},

    # ── SPECIAL NOTATION ──
    120: {"code": "PROPOSAL_NUM",   "cat": "notation",   "desc": "Negotiation proposal number"},
    121: {"code": "BRACKET_INSERT", "cat": "notation",   "desc": "Placeholder insertion [insert date...]"},
    122: {"code": "ASTERISK_BREAK", "cat": "notation",   "desc": "Asterisk separator (*** or ****)"},
    123: {"code": "ELLIPSIS",       "cat": "notation",   "desc": "Ellipsis indicating omitted text"},
    124: {"code": "FILE_PATH",      "cat": "notation",   "desc": "File system path notation"},
}


def get_code(type_id: int) -> str:
    return CATALOG.get(type_id, {}).get("code", "UNKNOWN")


def get_desc(type_id: int) -> str:
    return CATALOG.get(type_id, {}).get("desc", "Unknown element")


def catalog_as_text() -> str:
    lines = ["# PDF Element Type Catalog", ""]
    lines.append(f"{'ID':>4}  {'Code':<20}  {'Category':<12}  Description")
    lines.append("-" * 90)
    for tid in sorted(CATALOG.keys()):
        e = CATALOG[tid]
        lines.append(f"{tid:>4}  {e['code']:<20}  {e['cat']:<12}  {e['desc']}")
    return "\n".join(lines) + "\n"
