"""
Geometry utilities for detecting table structures from PDF vector drawings.

Provides clustering and coverage analysis for PDF document layout detection,
particularly for identifying table boundaries and grid structures.
"""

from __future__ import annotations

import statistics
from typing import List, Tuple


def cluster(values: List[float], tol: float) -> List[float]:
    """
    Cluster 1D values where consecutive points within tolerance belong to the same group.

    Groups nearby values together and returns the median point of each cluster.
    Useful for identifying aligned rows/columns in tables.

    Args:
        values: List of 1D coordinate values (e.g., x-positions or y-positions)
        tol: Tolerance threshold for grouping nearby values

    Returns:
        List of median values, one per cluster
    """
    if not values:
        return []
    values = sorted(values)
    groups: List[List[float]] = []
    cur: List[float] = [values[0]]
    for v in values[1:]:
        if abs(v - cur[-1]) <= tol:
            cur.append(v)
        else:
            groups.append(cur)
            cur = [v]
    groups.append(cur)
    return [float(statistics.median(g)) for g in groups]


def union_coverage(intervals: List[Tuple[float, float]]) -> float:
    """
    Calculate the total union length of 1D intervals.

    Merges overlapping intervals and returns the sum of their lengths.
    Useful for determining table grid line coverage.

    Args:
        intervals: List of (start, end) tuples representing 1D intervals

    Returns:
        Total length covered by the union of all intervals
    """
    if not intervals:
        return 0.0
    intervals = sorted(
        (min(a, b), max(a, b)) for a, b in intervals if max(a, b) > min(a, b)
    )
    if not intervals:
        return 0.0
    covered = 0.0
    cur0, cur1 = intervals[0]
    for a, b in intervals[1:]:
        if a <= cur1:
            cur1 = max(cur1, b)
        else:
            covered += cur1 - cur0
            cur0, cur1 = a, b
    covered += cur1 - cur0
    return float(covered)
