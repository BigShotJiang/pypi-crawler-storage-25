"""
Render non-table text while preserving basic layout via word x-positions.
"""

from __future__ import annotations

import statistics
from typing import List, Sequence, Tuple

from pdf_grid.types import BBox, Word


def render_text_events_outside_tables(
    page, table_bboxes: Sequence[BBox]
) -> List[Tuple[float, str]]:
    """
    Return events (y, text_with_newline) for words that are outside any table bbox.
    """
    words_raw = page.get_text("words") or []
    outside: List[Word] = []
    for w in words_raw:
        if not (isinstance(w, (list, tuple)) and len(w) >= 5):
            continue
        x0, y0, x1, y1, t = (
            float(w[0]),
            float(w[1]),
            float(w[2]),
            float(w[3]),
            str(w[4]),
        )
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        in_table = any(
            (bb[0] - 1) <= cx <= (bb[2] + 1) and (bb[1] - 1) <= cy <= (bb[3] + 1)
            for bb in table_bboxes
        )
        if not in_table:
            outside.append((x0, y0, x1, y1, t))

    outside.sort(key=lambda z: (z[1], z[0]))
    if not outside:
        return []

    char_widths: List[float] = []
    for x0, _y0, x1, _y1, t in outside:
        tt = (t or "").strip()
        if not tt:
            continue
        w = max(0.0, float(x1) - float(x0))
        cw = w / max(1, len(tt))
        if 0.5 <= cw <= 20:
            char_widths.append(cw)
    avg_cw = statistics.median(char_widths) if char_widths else 5.0
    avg_cw = max(2.0, min(10.0, float(avg_cw)))

    min_x = min(w[0] for w in outside)

    lines: List[Tuple[float, List[Word]]] = []
    cur_words: List[Word] = []
    cur_y: float | None = None
    for w in outside:
        y = w[1]
        if cur_y is None or abs(y - cur_y) <= 3.0:
            cur_words.append(w)
            cur_y = y if cur_y is None else (cur_y * 0.7 + y * 0.3)
        else:
            lines.append((float(cur_y), cur_words))
            cur_words = [w]
            cur_y = y
    if cur_words and cur_y is not None:
        lines.append((float(cur_y), cur_words))

    events: List[Tuple[float, str]] = []
    for y, ws in lines:
        ws_sorted = sorted(ws, key=lambda z: z[0])
        parts: List[str] = []
        prev_x1 = None
        for x0, _y0, x1, _y1, t in ws_sorted:
            tt = (t or "").strip()
            if not tt:
                continue
            if prev_x1 is None:
                indent = int(max(0.0, (x0 - min_x)) / avg_cw)
                parts.append(" " * min(indent, 80) + tt)
            else:
                gap = max(0.0, x0 - float(prev_x1))
                spaces = int(round(gap / avg_cw))
                if spaces <= 0 and gap > avg_cw * 0.5:
                    spaces = 1
                parts.append(" " * min(spaces, 40) + tt)
            prev_x1 = x1
        line_txt = "".join(parts).rstrip()
        if line_txt:
            events.append((y, line_txt + "\n"))

    events.sort(key=lambda z: z[0])
    return events
