"""
Table rendering utilities for LLM-friendly output formats.

Provides CSV and ASCII grid rendering:
- Strict/regular tables → CSV format (comma-separated values)
- Flexible tables (merged/rowspan cells) → ASCII grid format with borders

This improves LLM understanding of table structure vs. simple CSV export.
"""

from __future__ import annotations

import csv
import re
from io import StringIO
from typing import List, Tuple


def _trim_trailing_empty_cols(rows: List[List[str]]) -> List[List[str]]:
    if not rows:
        return rows
    n_cols = max(len(r) for r in rows)
    norm: List[List[str]] = []
    for r in rows:
        rr = list(r)
        if len(rr) < n_cols:
            rr.extend([""] * (n_cols - len(rr)))
        norm.append(rr)
    last = -1
    for j in range(n_cols):
        if any((r[j] or "").strip() for r in norm):
            last = j
    if last < 0:
        return [[c for c in r if (c or "").strip()] for r in rows]
    return [r[: last + 1] for r in norm]


def render_csv(rows: List[List[str]]) -> str:
    """
    Render table rows as CSV format.

    Args:
        rows: List of rows, each row is a list of cell strings

    Returns:
        CSV-formatted string
    """
    rows = _trim_trailing_empty_cols(rows)
    buf = StringIO()
    w = csv.writer(buf)
    for r in rows:
        w.writerow([c if c is not None else "" for c in r])
    return buf.getvalue().rstrip() + "\n"


def render_ascii_grid(rows: List[List[str]], header: bool = True) -> str:
    """
    Render table rows as ASCII grid with borders using '+', '-', and '|' characters.

    Includes visual rowspan heuristic: if header contains 'Sub-Limit' and
    two consecutive rows appear to be (Policy Limit) + (amount) pair, blank the
    internal horizontal border for that column to visually represent merged cells.

    Args:
        rows: List of rows, each row is a list of cell strings
        header: If True, first row is treated as header with '=' separator line

    Returns:
        ASCII grid-formatted string
    """
    if not rows:
        return ""
    n_cols = max(len(r) for r in rows)
    for r in rows:
        if len(r) < n_cols:
            r.extend([""] * (n_cols - len(r)))

    widths = [0] * n_cols
    for r in rows:
        for i, cell in enumerate(r):
            widths[i] = max(widths[i], len(cell or ""))

    blank_cols_by_boundary: List[set[int]] = [set() for _ in range(len(rows) - 1)]
    if header and rows:
        hdr = [(c or "").strip().lower() for c in rows[0]]
        sub_cols = [i for i, c in enumerate(hdr) if re.search(r"\bsub[- ]?limit\b", c)]

        def is_policy_limit(s: str) -> bool:
            s = (s or "").lower()
            return ("policy" in s and "limit" in s) or ("limit" in s)

        def is_amount(s: str) -> bool:
            s = s or ""
            return ("NT$" in s) or bool(re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", s))

        for i in range(1, len(rows) - 1):
            for c in sub_cols:
                a = (rows[i][c] or "").strip()
                b = (rows[i + 1][c] or "").strip()
                if (
                    a
                    and b
                    and (
                        (is_policy_limit(a) and is_amount(b))
                        or (is_policy_limit(b) and is_amount(a))
                    )
                ):
                    blank_cols_by_boundary[i].add(c)

    def border(ch: str = "-", blank_cols: set[int] | None = None) -> str:
        segs: List[str] = []
        for i, w in enumerate(widths):
            if blank_cols and i in blank_cols:
                segs.append(" " * (w + 2))
            else:
                segs.append(ch * (w + 2))
        return "+" + "+".join(segs) + "+\n"

    def fmt_row(r: List[str]) -> str:
        parts: List[str] = []
        for i, cell in enumerate(r):
            c = cell or ""
            parts.append(" " + c.ljust(widths[i]) + " ")
        return "|" + "|".join(parts) + "|\n"

    out: List[str] = []
    out.append(border("-"))
    if header and len(rows) >= 1:
        out.append(fmt_row(rows[0]))
        out.append(border("="))
        for idx, r in enumerate(rows[1:], start=1):
            out.append(fmt_row(r))
            blank = (
                blank_cols_by_boundary[idx]
                if idx < len(blank_cols_by_boundary)
                else None
            )
            out.append(border("-", blank_cols=blank))
    else:
        for idx, r in enumerate(rows):
            out.append(fmt_row(r))
            blank = (
                blank_cols_by_boundary[idx]
                if idx < len(blank_cols_by_boundary)
                else None
            )
            out.append(border("-", blank_cols=blank))

    return "".join(out).rstrip() + "\n"


def is_flexible_table(rows: List[List[str]], header: bool) -> bool:
    """
    Detect if table contains merged or rowspan cells (flexible layout).

    Heuristic: checks for common rowspan patterns in 'Sub-Limit' column
    where (Policy Limit) is followed by (amount) without repeated column headers.

    Returns True if flexible format detected, otherwise False (strict grid).
    """
    if not rows or len(rows) < 3:
        return False
    n_cols = max(len(r) for r in rows)
    norm: List[List[str]] = []
    for r in rows:
        rr = list(r)
        if len(rr) < n_cols:
            rr.extend([""] * (n_cols - len(rr)))
        norm.append(rr)

    sub_cols: List[int] = []
    if header:
        hdr = [(c or "").strip().lower() for c in norm[0]]
        for i, c in enumerate(hdr):
            if re.search(r"\bsub[- ]?limit\b", c):
                sub_cols.append(i)
    if not sub_cols:
        return False

    def is_policy_limit(s: str) -> bool:
        s = (s or "").lower()
        return ("policy" in s and "limit" in s) or ("limit" in s)

    def is_amount(s: str) -> bool:
        s = s or ""
        return ("NT$" in s) or bool(re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", s))

    start = 1 if header else 0
    for i in range(start, len(norm) - 1):
        for c in sub_cols:
            a = (norm[i][c] or "").strip()
            b = (norm[i + 1][c] or "").strip()
            if (
                a
                and b
                and (
                    (is_policy_limit(a) and is_amount(b))
                    or (is_policy_limit(b) and is_amount(a))
                )
            ):
                return True
    return False


def render_table_auto(rows: List[List[str]], header: bool) -> Tuple[str, str]:
    """
    Auto-detect best table format and render accordingly.

    Format selection:
    - Flexible tables (with merged/rowspan cells) → ASCII grid
    - Strict tables (rectangular grid) → CSV

    Returns:
        Tuple of (rendered_text, format_name) where format_name is "grid" or "csv"
    """
    if is_flexible_table(rows, header=header):
        return render_ascii_grid(rows, header=header), "grid"
    return render_csv(rows), "csv"
