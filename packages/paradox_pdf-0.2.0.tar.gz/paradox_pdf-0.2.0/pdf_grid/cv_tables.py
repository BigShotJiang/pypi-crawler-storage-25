"""
cv_tables.py — OpenCV-based confirmation of missing internal table borders.

Role in the pipeline:
  This module is called after the vector pipeline (line_tables.py) has already
  determined the table bounding box and the grid coordinates (xs, ys). Its sole
  job is to answer: "for each internal grid line, is the border actually present
  in the rendered image?"  That answer drives colspan/rowspan detection.

Why OpenCV instead of vectors alone:
  Some PDFs draw merged cells by simply omitting the internal border segment.
  Vector data may be fragmented or rounded in ways that make a missing border
  look like a short gap. Rendering the table region at high DPI and applying
  morphological line-detection gives a reliable pixel-level confirmation.

Algorithm:
  1. Render the table clip at `dpi` (default 300) using PyMuPDF.
  2. Convert to grayscale and threshold (dark pixels = ink).
  3. Apply morphological OPEN with a long horizontal kernel → horiz_mask.
     Apply morphological OPEN with a tall vertical kernel   → vert_mask.
  4. For each internal horizontal grid line (between rows r and r+1):
       For each column c, measure pixel coverage of horiz_mask in that band.
       If coverage < 20% → border is MISSING (h_missing[r][c] = True).
  5. Repeat for internal vertical grid lines to fill v_missing[r][c].

Output convention:
  h_missing[r][c] = True  → the horizontal border BELOW row r at column c
                             is absent → cell at (r,c) spans into row r+1.
  v_missing[r][c] = True  → the vertical border to the RIGHT of column c at
                             row r is absent → cell at (r,c) spans into col c+1.

This module does NOT extract text; text placement is handled by line_tables.py.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import cv2
import numpy as np

from pdf_tagger.config import get_config

try:
    import fitz
except ImportError:
    raise RuntimeError("PyMuPDF (fitz) is required.")

from pdf_grid.geometry import cluster


def detect_missing_borders(
    page, bbox: Tuple[float, ...],
    grid_xs: List[float], grid_ys: List[float],
    dpi: int = 200,
) -> Tuple[List[List[bool]], List[List[bool]]]:
    """
    Detect which internal borders are missing using OpenCV.

    Args:
        page: PyMuPDF page
        bbox: table bounding box (x0, y0, x1, y1) in PDF points
        grid_xs: column boundary x-coordinates (from vector pipeline)
        grid_ys: row boundary y-coordinates (from vector pipeline)
        dpi: render resolution

    Returns:
        (h_missing, v_missing) where:
        - h_missing[r][c] = True if horizontal border is MISSING below row r at column c
        - v_missing[r][c] = True if vertical border is MISSING to the right of column c at row r
    """
    x0, y0, x1, y1 = bbox
    n_rows = len(grid_ys) - 1
    n_cols = len(grid_xs) - 1

    if n_rows < 1 or n_cols < 1:
        return [], []

    scale = dpi / 72.0

    # Render table region
    clip = fitz.Rect(x0, y0, x1, y1)
    pix = page.get_pixmap(dpi=dpi, clip=clip)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
    if pix.n == 4:
        gray = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
    elif pix.n == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    img_h, img_w = gray.shape[:2]
    if img_h < 10 or img_w < 10:
        return [[False] * n_cols for _ in range(n_rows - 1)], \
               [[False] * (n_cols - 1) for _ in range(n_rows)]

    _, thresh = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY_INV)

    # Detect horizontal lines (long enough to be real borders)
    h_kernel_len = max(15, img_w // 25)
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_len, 1))
    horiz_mask = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, h_kernel)

    # Detect vertical lines
    v_kernel_len = max(15, img_h // 25)
    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_len))
    vert_mask = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, v_kernel)

    # Check horizontal borders: for each internal y-line, at each column
    h_missing = [[False] * n_cols for _ in range(n_rows - 1)]
    for r in range(n_rows - 1):
        y_pdf = grid_ys[r + 1]
        y_px = int((y_pdf - y0) * scale)
        y_start = max(0, y_px - 4)
        y_end = min(img_h, y_px + 5)
        if y_end <= y_start:
            continue

        for c in range(n_cols):
            cx0_px = int((grid_xs[c] - x0) * scale)
            cx1_px = int((grid_xs[c + 1] - x0) * scale)
            cx0_px = max(0, cx0_px + 3)  # skip border pixels
            cx1_px = min(img_w, cx1_px - 3)
            if cx1_px <= cx0_px:
                continue

            region = horiz_mask[y_start:y_end, cx0_px:cx1_px]
            coverage = np.sum(region > 0) / max(1, region.size)
            h_missing[r][c] = coverage < get_config().cv_border_missing_threshold

    # Check vertical borders: for each internal x-line, at each row
    v_missing = [[False] * (n_cols - 1) for _ in range(n_rows)]
    for c in range(n_cols - 1):
        x_pdf = grid_xs[c + 1]
        x_px = int((x_pdf - x0) * scale)
        x_start = max(0, x_px - 4)
        x_end = min(img_w, x_px + 5)
        if x_end <= x_start:
            continue

        for r in range(n_rows):
            ry0_px = int((grid_ys[r] - y0) * scale)
            ry1_px = int((grid_ys[r + 1] - y0) * scale)
            ry0_px = max(0, ry0_px + 3)
            ry1_px = min(img_h, ry1_px - 3)
            if ry1_px <= ry0_px:
                continue

            region = vert_mask[ry0_px:ry1_px, x_start:x_end]
            coverage = np.sum(region > 0) / max(1, region.size)
            v_missing[r][c] = coverage < get_config().cv_border_missing_threshold

    return h_missing, v_missing
