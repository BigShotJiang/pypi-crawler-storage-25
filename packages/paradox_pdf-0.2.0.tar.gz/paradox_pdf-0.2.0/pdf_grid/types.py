"""
Shared type definitions for PDF grid and table extraction.

This module provides type definitions for the PDF grid extraction package,
which extracts "LLM-friendly" formatted tables from PDFs using ONLY native PDF data
(PyMuPDF words + vector drawings). No OCR or LLM-based vision models required.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

Word = Tuple[float, float, float, float, str]  # x0, y0, x1, y1, text
BBox = Tuple[float, float, float, float]  # x0, y0, x1, y1


@dataclass(frozen=True)
class PageRenderResult:
    page_index: int
    page_count: int
    text: str
    tables_detected: int
