"""
extractor.py — Plain-text page extraction with LLM-friendly table formatting.

Role in the pipeline:
  This module provides a separate, lighter output path that produces flat text
  rather than structured JSON. It is useful for feeding document content to
  language models that expect a readable text stream with tables as inline
  formatted blocks rather than nested JSON.

  It does NOT use the font-based classifier or the section-tree builder.
  Instead it combines raw text layout with formatted table blocks.

Processing per page (render_page_to_text):
  1. Borderless tables detected first via word-alignment heuristics.
  2. Vector-bordered tables detected via line_tables.detect_table_bboxes().
     Tables overlapping with borderless tables are skipped to avoid duplicates.
  3. Each table rendered as CSV or ASCII-grid via render_table_auto().
  4. Non-table text extracted while respecting the table bounding boxes
     (text inside table regions is excluded from the text stream).
  5. All text and table blocks sorted by y-coordinate and concatenated.

Output format per page:
  PAGE N/TOTAL
  <text with tables inline as CSV/grid blocks>

If table_markers=True, tables are wrapped:
  <<TABLE_START format=csv>>
  ...CSV content...
  <<TABLE_END>>

Public API:
  render_pdf_to_single_text_from_path(pdf_path, table_markers=False)
  render_pdf_to_single_text_from_bytes(file_bytes, table_markers=False)

Uses ONLY PyMuPDF vector data — no OCR, no ML models required.
"""

from __future__ import annotations

from typing import List, Tuple

from pdf_grid.borderless_tables import detect_borderless_table_segments_from_words
from pdf_grid.line_tables import detect_table_bboxes, render_tables_from_bbox
from pdf_grid.renderers import render_table_auto
from pdf_grid.text_layout import render_text_events_outside_tables
from pdf_grid.types import BBox, Word

try:
    import fitz  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeError("PyMuPDF (fitz) is required for pdf_grid extractor.") from e


def render_page_to_text(page, *, table_markers: bool = False) -> Tuple[str, int]:
    """
    Render a single PDF page into a text string with tables as inline formatted blocks.

    Detects and formats two types of tables in priority order:
      1. Borderless tables — detected via column-alignment heuristics on word positions.
      2. Vector-bordered tables — detected via drawn line/rectangle segments.
         (Skipped if they overlap with an already-detected borderless table.)

    Non-table text is extracted preserving relative layout, with table regions
    excluded so their content is not duplicated.

    All content (text + tables) is sorted by vertical position on the page
    before being concatenated, preserving reading order.

    Args:
        page:          PyMuPDF page object.
        table_markers: If True, each table block is wrapped with
                       <<TABLE_START format=csv|grid>> ... <<TABLE_END>>.

    Returns:
        Tuple of (page_text, tables_count) where page_text is the full
        rendered page content and tables_count is the number of tables found.
    """
    tables_count = 0

    table_events: List[Tuple[float, str]] = []
    accepted_bboxes: List[BBox] = []

    # Detect borderless tables using strict heuristics to avoid false positives.
    borderless_segments = detect_borderless_table_segments_from_words(
        page, excluded_bboxes=[]
    )
    borderless_bboxes: List[BBox] = []
    if borderless_segments:
        words_raw = page.get_text("words") or []
        words: List[Word] = []
        for w in words_raw:
            if isinstance(w, (list, tuple)) and len(w) >= 5:
                words.append(
                    (float(w[0]), float(w[1]), float(w[2]), float(w[3]), str(w[4]))
                )

        for y0, y1, rows in borderless_segments:
            if len(rows) < 3 or len(rows[0]) < 2:
                continue
            in_seg = [
                wd for wd in words if (y0 - 2) <= ((wd[1] + wd[3]) / 2.0) <= (y1 + 2)
            ]
            if in_seg:
                x0 = min(wd[0] for wd in in_seg)
                x1 = max(wd[2] for wd in in_seg)
                borderless_bboxes.append((float(x0), float(y0), float(x1), float(y1)))

            tables_count += 1
            header = True
            rendered, fmt = render_table_auto(rows, header=header)
            if table_markers:
                table_events.append(
                    (
                        y0 + 0.005,
                        f"<<TABLE_START format={fmt}>>\n{rendered}\n<<TABLE_END>>\n",
                    )
                )
            else:
                table_events.append((y0 + 0.005, rendered + "\n"))

    def overlaps_any_borderless(bb: BBox) -> bool:
        bx0, by0, bx1, by1 = bb
        b_area = max(1.0, (bx1 - bx0) * (by1 - by0))
        for ox0, oy0, ox1, oy1 in borderless_bboxes:
            ix0 = max(bx0, ox0)
            iy0 = max(by0, oy0)
            ix1 = min(bx1, ox1)
            iy1 = min(by1, oy1)
            if ix1 <= ix0 or iy1 <= iy0:
                continue
            inter = (ix1 - ix0) * (iy1 - iy0)
            if (inter / b_area) >= 0.30:
                return True
        return False

    # Detect and render line-based tables (skip those overlapping with borderless tables)
    bboxes_all = detect_table_bboxes(page)
    for bb in bboxes_all:
        if overlaps_any_borderless(bb):
            continue
        blocks = render_tables_from_bbox(page, bb)
        if blocks:
            accepted_bboxes.append(bb)
            for i, block in enumerate(blocks):
                if not block.strip():
                    continue
                tables_count += 1
                fmt = "grid" if block.lstrip().startswith("+") else "csv"
                if table_markers:
                    table_events.append(
                        (
                            bb[1] + i * 0.01,
                            f"<<TABLE_START format={fmt}>>\n{block}\n<<TABLE_END>>\n",
                        )
                    )
                else:
                    table_events.append((bb[1] + i * 0.01, block + "\n"))

    # Extract non-table text maintaining layout
    text_events = render_text_events_outside_tables(
        page, accepted_bboxes + borderless_bboxes
    )

    # Merge all events (text + tables) and sort by vertical position (y-coordinate)
    events: List[Tuple[float, str]] = []
    events.extend(text_events)
    events.extend(table_events)
    events.sort(key=lambda z: z[0])
    full = "".join(t for _y, t in events).rstrip() + "\n"
    return full, tables_count


def render_pdf_to_single_text_from_path(
    pdf_path: str, *, table_markers: bool = False
) -> str:
    """
    Render a complete PDF into a single text string, reading from a file path.

    Iterates all pages, prepends a "PAGE N/TOTAL" marker before each page's
    content, and concatenates everything into one string.

    Args:
        pdf_path:      Path to the PDF file on disk.
        table_markers: If True, wrap each table with <<TABLE_START format=...>>
                       and <<TABLE_END>> markers.

    Returns:
        Full document text ending with a single newline.
    """
    doc = fitz.open(pdf_path)
    try:
        pages = doc.page_count
        out: List[str] = []
        for i in range(pages):
            page = doc.load_page(i)
            page_text, _tables = render_page_to_text(page, table_markers=table_markers)
            out.append(f"PAGE {i+1}/{pages}\n")
            out.append(page_text)
            out.append("\n")
        return "".join(out).rstrip() + "\n"
    finally:
        doc.close()


def render_pdf_to_single_text_from_bytes(
    file_bytes: bytes, *, table_markers: bool = False
) -> str:
    """
    Render a complete PDF into a single text string, reading from bytes in memory.

    Identical to render_pdf_to_single_text_from_path() but accepts raw PDF
    bytes instead of a file path. Useful for in-process pipelines where the
    PDF is already loaded in memory (e.g. web uploads, stream processing).

    Args:
        file_bytes:    PDF content as bytes.
        table_markers: If True, wrap each table with <<TABLE_START format=...>>
                       and <<TABLE_END>> markers.

    Returns:
        Full document text ending with a single newline.
    """
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    try:
        pages = doc.page_count
        out: List[str] = []
        for i in range(pages):
            page = doc.load_page(i)
            page_text, _tables = render_page_to_text(page, table_markers=table_markers)
            out.append(f"PAGE {i+1}/{pages}\n")
            out.append(page_text)
            out.append("\n")
        return "".join(out).rstrip() + "\n"
    finally:
        doc.close()
