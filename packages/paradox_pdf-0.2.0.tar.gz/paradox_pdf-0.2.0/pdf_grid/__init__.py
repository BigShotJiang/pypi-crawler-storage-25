"""
PDF Grid Extractor — Standalone module for PDF text extraction with layout preservation.

Extracts text from PDFs preserving original structure:
- Tables with borders → detected via vector line analysis → rendered as CSV or ASCII grid
- Borderless tables → detected via word alignment heuristics → rendered as CSV or ASCII grid
- Free text → preserves x/y word positions (columns, indentation)

Dependencies: PyMuPDF (fitz)

Public API:
    render_pdf_to_single_text_from_path(pdf_path, table_markers=False) -> str
    render_pdf_to_single_text_from_bytes(file_bytes, table_markers=False) -> str
"""

from pdf_grid.extractor import (
    render_pdf_to_single_text_from_path,
    render_pdf_to_single_text_from_bytes,
    render_page_to_text,
)

__all__ = [
    "render_pdf_to_single_text_from_path",
    "render_pdf_to_single_text_from_bytes",
    "render_page_to_text",
]
