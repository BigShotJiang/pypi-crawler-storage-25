"""
Detection of borderless tables (no drawn grid lines) using word alignment heuristics.

This complements the line-based detector and is intentionally strict to avoid false positives.
"""

from __future__ import annotations

import os
import re
import statistics
from typing import Dict, List, Sequence, Tuple

from pdf_grid.geometry import cluster
from pdf_grid.types import BBox, Word
from pdf_tagger.config import get_config


def detect_borderless_table_segments_from_words(
    page, excluded_bboxes: Sequence[BBox]
) -> List[Tuple[float, float, List[List[str]]]]:
    """
    Detect borderless tables by column alignment (no drawn grid lines).
    Returns list of (y0, y1, rows).
    """
    words_raw = page.get_text("words") or []
    words: List[Word] = []
    for w in words_raw:
        if not (isinstance(w, (list, tuple)) and len(w) >= 5):
            continue
        x0, y0, x1, y1, t = (
            float(w[0]),
            float(w[1]),
            float(w[2]),
            float(w[3]),
            str(w[4]),
        )
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        in_excluded = any(
            (bb[0] - 1) <= cx <= (bb[2] + 1) and (bb[1] - 1) <= cy <= (bb[3] + 1)
            for bb in excluded_bboxes
        )
        if not in_excluded:
            words.append((x0, y0, x1, y1, t))

    if not words:
        return []

    cfg = get_config()

    # Group into lines by y
    words.sort(key=lambda z: (z[1], z[0]))
    lines: List[Tuple[float, float, List[Tuple[float, str]]]] = []
    cur: List[Tuple[float, str]] = []
    cur_y: float | None = None
    cur_y1: float = 0.0
    for x0, y0, _x1, y1, t in words:
        if cur_y is None or abs(y0 - cur_y) <= cfg.line_y_tolerance:
            cur.append((x0, t))
            cur_y = y0 if cur_y is None else (cur_y * 0.7 + y0 * 0.3)
            cur_y1 = max(cur_y1, y1)
        else:
            lines.append((float(cur_y), float(cur_y1), sorted(cur, key=lambda p: p[0])))
            cur = [(x0, t)]
            cur_y = y0
            cur_y1 = y1
    if cur and cur_y is not None:
        lines.append((float(cur_y), float(cur_y1), sorted(cur, key=lambda p: p[0])))

    if os.getenv("PDF_GRID_DEBUG") == "1":
        for y, _y1, toks in lines:
            txt = re.sub(r"\s+", " ", " ".join(t for _x, t in toks)).strip()
            if re.search(r"\b(?:AP\d+|F\d+[A-Z]?)\b", txt) and re.search(
                r"\bNo\b", txt
            ):
                print(f"[PDF_GRID_DEBUG] candidate borderless header y={y:.2f}: {txt}")

    def anchors_for_segment(
        seg_lines: Sequence[Tuple[float, float, List[Tuple[float, str]]]]
    ) -> List[float]:
        xs: List[float] = []
        for _y, _y1, toks in seg_lines:
            xs.extend([x for x, _t in toks])
        xs_c = cluster(xs, tol=cfg.anchor_cluster_tolerance)
        xs_c = sorted(xs_c)
        keep: List[float] = []
        for a in xs_c:
            cnt = 0
            for _y, _y1, toks in seg_lines:
                if any(abs(x - a) <= cfg.anchor_cluster_tolerance for x, _t in toks):
                    cnt += 1
            if cnt / max(1, len(seg_lines)) >= 0.5:
                keep.append(a)
        return keep

    def line_to_cells_by_ranges(
        toks: List[Tuple[float, str]], anchors: List[float], bounds: List[float]
    ) -> List[str]:
        if not anchors:
            return [" ".join(t for _x, t in toks).strip()]
        anchors = sorted(anchors)
        cols: List[List[Tuple[float, str]]] = [[] for _ in anchors]
        for x, t in toks:
            j = 0
            while j < len(bounds) and x > bounds[j]:
                j += 1
            cols[j].append((x, t))
        out: List[str] = []
        for cell in cols:
            cell_sorted = " ".join(
                t for _x, t in sorted(cell, key=lambda p: p[0])
            ).strip()
            out.append(cell_sorted)
        while out and out[-1] == "":
            out.pop()
        return out

    def line_to_cells(toks: List[Tuple[float, str]], anchors: List[float]) -> List[str]:
        if not anchors:
            return [" ".join(t for _x, t in toks).strip()]
        cells: List[List[Tuple[float, str]]] = [[] for _ in anchors]
        for x, t in toks:
            j = min(range(len(anchors)), key=lambda k: abs(x - anchors[k]))
            cells[j].append((x, t))
        out: List[str] = []
        for cell in cells:
            cell_sorted = " ".join(
                t for _x, t in sorted(cell, key=lambda p: p[0])
            ).strip()
            out.append(cell_sorted)
        while out and out[-1] == "":
            out.pop()
        return out

    # ---- Summary: ITEM / DESCRIPTION / CLAIM (NT$) ----
    def looks_like_header_summary(toks: List[Tuple[float, str]]) -> bool:
        txt = " ".join(t for _x, t in toks)
        if re.search(r"\bITEM\b", txt, re.I) and re.search(
            r"\bDESCRIPTION\b", txt, re.I
        ):
            if re.search(r"\bCLAIM\b", txt, re.I) or re.search(r"\bNT\$\b", txt, re.I):
                return True
        return False

    segments: List[Tuple[float, float, List[List[str]]]] = []
    accepted_ranges: List[Tuple[float, float]] = []

    def overlaps_accepted(y0: float, y1: float) -> bool:
        for a0, a1 in accepted_ranges:
            inter = max(0.0, min(y1, a1) - max(y0, a0))
            if inter <= 0.0:
                continue
            smaller = max(1.0, min(y1 - y0, a1 - a0))
            if (inter / smaller) >= 0.30:
                return True
        return False

    def accept_segment(y0: float, y1: float, rows: List[List[str]]) -> None:
        if overlaps_accepted(y0, y1):
            return
        segments.append((float(y0), float(y1), rows))
        accepted_ranges.append((float(y0), float(y1)))

    for i in range(len(lines) - 2):
        y0, _y1, toks0 = lines[i]
        if overlaps_accepted(y0, y0):
            continue
        if not looks_like_header_summary(toks0):
            continue

        def join_toks(toks: List[Tuple[float, str]]) -> str:
            return " ".join(t for _x, t in toks).strip()

        header_row = ["ITEM", "DESCRIPTION", "CLAIM(NT$)"]
        rows: List[List[str]] = [header_row]
        j = i + 1
        last_y = y0
        while j < len(lines):
            y, y1, toks = lines[j]
            txt = join_toks(toks)
            if not txt:
                break
            if re.search(r"\bDescription\b", txt, re.I) and re.search(
                r"\bNT\$\b", txt, re.I
            ):
                break
            if re.match(r"^\d+\.\s+[A-Z][A-Z\s]+$", txt) and not re.search(
                r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", txt
            ):
                break
            m_item = re.match(r"^(\d+(?:\.\d+)*\.?)\s+(.*)$", txt)
            m_total = re.match(r"^(TOTAL(?:\s+PD)?:)\s*(.*)$", txt, flags=re.I)
            if not (m_item or m_total):
                break

            amount = ""
            for _x, t in reversed(toks):
                if re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", t) or re.fullmatch(
                    r"\d{6,}", t
                ):
                    amount = t.strip()
                    break

            if m_item:
                item = m_item.group(1).strip()
                rest = m_item.group(2).strip()
                if amount and rest.endswith(amount):
                    rest = rest[: -len(amount)].rstrip()
                rows.append([item, rest, amount])
            else:
                item = m_total.group(1).strip().upper()
                rest = (m_total.group(2) or "").strip()
                if amount and rest.endswith(amount):
                    rest = rest[: -len(amount)].rstrip()
                rows.append([item, rest, amount])

            last_y = y1
            j += 1

        if len(rows) >= 4:
            accept_segment(float(y0), float(last_y), rows)

    # ---- Financial: Insurers / PolicyNumbers / %age / Payment/Reserve ----
    def _norm_header_text(toks: List[Tuple[float, str]]) -> str:
        return (
            re.sub(r"\s+", " ", " ".join((t or "") for _x, t in toks)).strip().lower()
        )

    def looks_like_header_financial(toks: List[Tuple[float, str]]) -> bool:
        txt = _norm_header_text(toks)
        if not re.search(r"\binsurers?\b", txt):
            return False
        if not (re.search(r"\bpolicy\s*numbers?\b", txt) or "policynumbers" in txt):
            return False
        if not (re.search(r"%age\b", txt) or "%" in txt or "percentage" in txt):
            return False
        if ("payment" in txt and "account" in txt) or "paymentonaccount" in txt:
            return True
        if "reserve" in txt:
            return True
        return False

    def financial_header_type(toks: List[Tuple[float, str]]) -> str:
        txt = _norm_header_text(toks)
        if ("payment" in txt and "account" in txt) or "paymentonaccount" in txt:
            return "apportionment"
        return "reserve"

    def anchors_from_financial_header(
        toks: List[Tuple[float, str]], kind: str
    ) -> List[float]:
        pos: Dict[str, float] = {}
        for x, t in toks:
            tt = (t or "").strip().lower()
            if not tt:
                continue
            if tt in ("insurers", "insurer"):
                pos["insurers"] = float(x)
            elif tt in ("policynumbers", "policy", "numbers"):
                pos.setdefault("policy", float(x))
            elif tt.startswith("%") or tt in ("%age", "percentage"):
                pos["pct"] = float(x)
            elif tt in ("paymentonaccount", "payment", "account"):
                pos.setdefault("pay", float(x))
            elif "reserve" in tt:
                pos.setdefault("reserve1", float(x))
                if "reserve1" in pos and abs(pos["reserve1"] - float(x)) > 8.0:
                    pos["reserve2"] = float(x)

        anchors: List[float] = []
        if "insurers" in pos:
            anchors.append(pos["insurers"])
        if "policy" in pos:
            anchors.append(pos["policy"])
        if "pct" in pos:
            anchors.append(pos["pct"])
        if kind == "apportionment":
            if "pay" in pos:
                anchors.append(pos["pay"])
        else:
            if "reserve1" in pos:
                anchors.append(pos["reserve1"])
            if "reserve2" in pos:
                anchors.append(pos["reserve2"])

        anchors = sorted(set(cluster(anchors, tol=12.0)))
        if len(anchors) < (4 if kind == "apportionment" else 5):
            xs = sorted(set(float(x) for x, _t in toks))
            anchors = sorted(set(cluster(xs[:6], tol=12.0)))
        return anchors

    def looks_like_data_row_financial(toks: List[Tuple[float, str]]) -> bool:
        if not toks:
            return False
        txt = " ".join(t for _x, t in toks).strip()
        if not txt:
            return False
        if re.search(r"\btotal\b", txt, re.I):
            return True
        if not (
            re.search(r"\d+(?:\.\d+)?\s*%", txt) or re.search(r"\d+(?:\.\d+)?%$", txt)
        ):
            return False
        if "NT$" not in txt and not re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", txt):
            return False
        return True

    def financial_header_row(kind: str) -> List[str]:
        if kind == "apportionment":
            return ["Insurers", "PolicyNumbers", "%age", "PaymentOnAccount"]
        return [
            "Insurers",
            "PolicyNumbers",
            "%age",
            "Reserve(netofDed)",
            "Reserve(netofSIR)",
        ]

    for i in range(len(lines) - 2):
        y0, _y1, toks0 = lines[i]
        if overlaps_accepted(y0, y0):
            continue
        if not looks_like_header_financial(toks0):
            continue
        kind = financial_header_type(toks0)
        anchors = anchors_from_financial_header(toks0, kind=kind)
        if len(anchors) < (4 if kind == "apportionment" else 5):
            continue
        bounds = [(a + b) / 2.0 for a, b in zip(anchors, anchors[1:])]

        rows: List[List[str]] = [financial_header_row(kind)]
        j = i + 1
        last_y = y0
        policy_re = re.compile(r"\b\d{3,6}-[0-9A-Za-z]{2,}(?:-[0-9A-Za-z]{2,})*\b")

        def normalize_insurer_policy(row: List[str]) -> List[str]:
            if len(row) < 2:
                return row
            c1 = (row[0] or "").strip()
            c2 = (row[1] or "").strip()
            m = policy_re.search(c2)
            if m and m.start() > 0:
                prefix = c2[: m.start()].strip()
                policy = c2[m.start() :].strip()
                if prefix:
                    c1 = (c1 + " " + prefix).strip()
                row[0] = c1
                row[1] = policy
            return row

        while j < len(lines):
            y, y1, toks = lines[j]
            txt = " ".join(t for _x, t in toks).strip()
            if not txt:
                break
            if re.fullmatch(r"[A-Z][A-Z\s\-]{5,}", txt) and not re.search(
                r"NT\$|%|\d", txt
            ):
                break
            if not looks_like_data_row_financial(toks):
                break
            row = line_to_cells_by_ranges(toks, anchors, bounds)
            row = normalize_insurer_policy(row)
            rows.append(row)
            last_y = y1
            j += 1

        if len(rows) >= 4:
            accept_segment(float(y0), float(last_y), rows)

    # ---- Simple 2-column: Description / NT$ ----
    def looks_like_header_desc_amount(toks: List[Tuple[float, str]]) -> bool:
        txt = _norm_header_text(toks)
        if "description" not in txt:
            return False
        if "nt$" not in txt and "nt $" not in txt:
            return False
        return True

    def anchors_from_desc_amount_header(toks: List[Tuple[float, str]]) -> List[float]:
        x_desc = None
        x_amt = None
        for x, t in toks:
            tt = (t or "").strip()
            if re.fullmatch(r"Description", tt, flags=re.I):
                x_desc = float(x)
            if re.fullmatch(r"NT\$", tt, flags=re.I) or tt.upper() == "NT$":
                x_amt = float(x)
        if x_desc is None and toks:
            x_desc = float(min(x for x, _t in toks))
        if x_amt is None and toks:
            x_amt = float(max(x for x, _t in toks))
        if x_desc is None or x_amt is None:
            return []
        if x_amt <= x_desc + 10.0:
            return []
        return sorted(set(cluster([x_desc, x_amt], tol=12.0)))

    def looks_like_data_row_desc_amount(toks: List[Tuple[float, str]]) -> bool:
        if not toks:
            return False
        txt = " ".join(t for _x, t in toks).strip()
        if not txt:
            return False
        if not re.search(r"\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b", txt) and not re.search(
            r"\b\d{6,}\b", txt
        ):
            return False
        if not re.search(r"[A-Za-z]", txt):
            return False
        return True

    for i in range(len(lines) - 2):
        y0, _y1, toks0 = lines[i]
        if overlaps_accepted(y0, y0):
            continue
        if not looks_like_header_desc_amount(toks0):
            continue
        anchors = anchors_from_desc_amount_header(toks0)
        if len(anchors) != 2:
            continue
        bounds = [(anchors[0] + anchors[1]) / 2.0]
        rows: List[List[str]] = [["Description", "NT$"]]
        j = i + 1
        last_y = y0
        while j < len(lines):
            y, y1, toks = lines[j]
            txt = " ".join(t for _x, t in toks).strip()
            if not txt:
                break
            if re.fullmatch(r"\d{1,3}", txt):
                break
            if re.fullmatch(r"[A-Z][A-Z\s\-]{6,}", txt) and not re.search(r"\d", txt):
                break
            if not looks_like_data_row_desc_amount(toks):
                break
            row = line_to_cells_by_ranges(toks, anchors, bounds)
            rows.append(row)
            last_y = y1
            j += 1
        if len(rows) >= 3:
            accept_segment(float(y0), float(last_y), rows)

    # ---- Generic matrix: No + (IDM/Item/Type) + many AP*/F* ----
    def looks_like_header_matrix_generic(toks: List[Tuple[float, str]]) -> bool:
        txt = " ".join(t for _x, t in toks)
        if not re.search(r"\bNo\b", txt):
            return False
        if not re.search(r"\b(IDM|Item|Type)\b", txt, re.I):
            return False
        fab_cols = re.findall(r"\b(?:AP\d+|F\d+[A-Z]?)\b", txt)
        return len(set(fab_cols)) >= 6

    def looks_like_data_row_matrix_generic(toks: List[Tuple[float, str]]) -> bool:
        if not toks:
            return False
        txt = " ".join(t for _x, t in toks).strip()
        if not txt:
            return False
        first = next((t for _x, t in toks if t.strip()), "")
        if not re.fullmatch(r"\d{1,3}", first.strip()):
            return False
        xs = sum(1 for _x, t in toks if (t or "").strip().lower() == "x")
        return xs >= 1

    def anchors_from_generic_matrix_header(
        toks: List[Tuple[float, str]],
        data_lines: Sequence[List[Tuple[float, str]]],
    ) -> Tuple[List[float], List[float]]:
        anchors: List[float] = []
        no_hdr_x = None
        idm_hdr_x = None
        for x, t in toks:
            tt = (t or "").strip()
            if not tt:
                continue
            if re.fullmatch(r"No\.?", tt, flags=re.I):
                anchors.append(float(x))
                no_hdr_x = float(x)
            elif re.fullmatch(r"(IDM|Item|Type)", tt, flags=re.I):
                anchors.append(float(x))
                idm_hdr_x = float(x)
            elif re.fullmatch(r"(AP\d+|F\d+[A-Z]?)", tt, flags=re.I):
                anchors.append(float(x))
        anchors = sorted(set(cluster(anchors, tol=8.0)))
        if len(anchors) < 6:
            return [], []

        no_xs: List[float] = []
        desc_xs: List[float] = []
        for toks_line in data_lines:
            if not toks_line:
                continue
            first = next((t for _x, t in toks_line if t.strip()), "")
            if re.fullmatch(r"\d{1,3}", first.strip()):
                no_xs.append(float(toks_line[0][0]))
                for x, t in toks_line[1:]:
                    tt = (t or "").strip()
                    if not tt:
                        continue
                    if re.fullmatch(r"\d{1,3}", tt):
                        continue
                    if tt.lower() == "x":
                        continue
                    desc_xs.append(float(x))
                    break

        no_anchor = statistics.median(no_xs) if no_xs else no_hdr_x
        desc_anchor = statistics.median(desc_xs) if desc_xs else idm_hdr_x

        bounds: List[float] = []
        if no_anchor is not None and desc_anchor is not None:
            bounds.append((float(no_anchor) + float(desc_anchor)) / 2.0)
        else:
            bounds.append((anchors[0] + anchors[1]) / 2.0)
        for a, b in zip(anchors[1:], anchors[2:]):
            bounds.append((a + b) / 2.0)
        if len(bounds) != (len(anchors) - 1):
            bounds = [(a + b) / 2.0 for a, b in zip(anchors, anchors[1:])]
        return anchors, bounds

    def looks_like_non_table_sentence(toks: List[Tuple[float, str]]) -> bool:
        txt = " ".join(t for _x, t in toks)
        if (
            len(txt) >= 140
            and "." in txt
            and sum(1 for _x, t in toks if t.strip().lower() == "x") == 0
        ):
            return True
        return False

    for i in range(len(lines) - 3):
        y0, _y1, toks0 = lines[i]
        if overlaps_accepted(y0, y0):
            continue
        if not looks_like_header_matrix_generic(toks0):
            continue
        data_lines: List[List[Tuple[float, str]]] = []
        for k in range(i + 1, min(len(lines), i + 20)):
            toks_k = lines[k][2]
            if looks_like_data_row_matrix_generic(toks_k):
                data_lines.append(toks_k)
            elif data_lines:
                break
        anchors, bounds = anchors_from_generic_matrix_header(
            toks0, data_lines=data_lines
        )
        if not anchors or not bounds:
            continue
        hdr = line_to_cells_by_ranges(toks0, anchors, bounds)

        rows = [hdr]
        j = i + 1
        last_y = y0
        x_hits = 0
        while j < len(lines):
            y, y1, toks = lines[j]
            txt = " ".join(t for _x, t in toks).strip()
            if not txt:
                break
            if looks_like_non_table_sentence(toks):
                break
            if not looks_like_data_row_matrix_generic(toks):
                break
            row = line_to_cells_by_ranges(toks, anchors, bounds)
            if any((c or "").strip().lower() == "x" for c in row):
                x_hits += 1
            rows.append(row)
            last_y = y1
            if len(rows) >= 40:
                break
            j += 1

        if len(rows) >= 4 and (x_hits / max(1, len(rows) - 1)) >= 0.5:
            accept_segment(float(y0), float(last_y), rows)

    # ---- Fallback generic segmentation (kept strict to avoid false positives) ----
    def looks_like_header_matrix(toks: List[Tuple[float, str]]) -> bool:
        txt = " ".join(t for _x, t in toks)
        if not re.search(r"\bDamage\s*Type\b", txt, re.I):
            return False
        if not re.search(r"\bNo\b", txt):
            return False
        return bool(re.search(r"\bAP\d+\b", txt) or re.search(r"\bF\d+[A-Z]?\b", txt))

    def looks_like_data_row_matrix(toks: List[Tuple[float, str]]) -> bool:
        if not toks:
            return False
        first = next((t for _x, t in toks if t.strip()), "")
        if not re.fullmatch(r"\d{1,3}", first.strip()):
            return False
        xs = sum(1 for _x, t in toks if t.strip().lower() == "x")
        return xs >= 1

    def looks_like_data_row_summary(toks: List[Tuple[float, str]]) -> bool:
        if not toks:
            return False
        first = next((t for _x, t in toks if t.strip()), "")
        if not re.fullmatch(r"\d+(?:\.\d+)*\.?", first.strip()):
            return False
        txt = " ".join(t for _x, t in toks)
        return bool(re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", txt))

    def anchors_from_summary_header(toks: List[Tuple[float, str]]) -> List[float]:
        candidates: List[float] = []
        for x, t in toks:
            tt = (t or "").strip()
            if re.fullmatch(r"ITEM", tt, flags=re.I):
                candidates.append(float(x))
            elif re.fullmatch(r"DESCRIPTION", tt, flags=re.I):
                candidates.append(float(x))
            elif re.fullmatch(r"CLAIM", tt, flags=re.I) or re.fullmatch(
                r"NT\$", tt, flags=re.I
            ):
                candidates.append(float(x))
        if len(candidates) < 3:
            xs = sorted(set(float(x) for x, _t in toks))
            candidates = xs[:3]
        return sorted(set(cluster(candidates, tol=12.0)))

    def anchors_from_matrix_header(
        toks: List[Tuple[float, str]],
        seg_lines: Sequence[Tuple[float, float, List[Tuple[float, str]]]],
    ) -> Tuple[List[float], List[float]]:
        labels = ["No", "Damage", "Type"]
        pos: Dict[str, float] = {}
        for x, t in toks:
            tt = (t or "").strip()
            if tt in labels:
                pos[tt] = float(x)
            if re.fullmatch(r"(AP\d+|F\d+[A-Z]?)", tt):
                pos[tt] = float(x)

        ap2_x = pos.get("AP2")
        type_x = pos.get("Type")

        no_xs: List[float] = []
        dmg_xs: List[float] = []
        for _y, _y1, toks_line in seg_lines[1:]:
            if not toks_line:
                continue
            first = next((t for _x, t in toks_line if t.strip()), "")
            if re.fullmatch(r"\d{1,3}", first.strip()):
                no_xs.append(float(toks_line[0][0]))
            for x, t in toks_line:
                tt = (t or "").strip()
                if tt == "" or re.fullmatch(r"\d{1,3}", tt) or tt.lower() == "x":
                    continue
                if ap2_x is not None and float(x) >= (float(ap2_x) - 10.0):
                    continue
                dmg_xs.append(float(x))
                break

        no_anchor = statistics.median(no_xs) if no_xs else pos.get("No")
        dmg_anchor = (
            statistics.median(dmg_xs) if dmg_xs else pos.get("Damage", pos.get("Type"))
        )

        anchors: List[float] = []
        if no_anchor is not None:
            anchors.append(float(no_anchor))
        if dmg_anchor is not None:
            anchors.append(float(dmg_anchor))
        for k, v in pos.items():
            if re.fullmatch(r"(AP\d+|F\d+[A-Z]?)", k):
                anchors.append(float(v))
        anchors = sorted(set(cluster(anchors, tol=8.0)))
        if len(anchors) < 6:
            xs = sorted(set(float(x) for x, _t in toks))
            anchors = xs[:14]
        anchors = sorted(set(cluster(anchors, tol=8.0)))

        bounds: List[float] = []
        if len(anchors) >= 2:
            bounds.append((anchors[0] + anchors[1]) / 2.0)
        if ap2_x is not None and type_x is not None:
            bounds.append((float(type_x) + float(ap2_x)) / 2.0)
        elif len(anchors) >= 3:
            bounds.append((anchors[1] + anchors[2]) / 2.0)
        while len(bounds) < (len(anchors) - 1):
            i = len(bounds)
            if i + 1 < len(anchors):
                bounds.append((anchors[i] + anchors[i + 1]) / 2.0)
            else:
                break
        return anchors, bounds

    i = 0
    while i < len(lines) - 2:
        toks0 = lines[i][2]
        y0_line = float(lines[i][0])
        if overlaps_accepted(y0_line, y0_line):
            i += 1
            continue
        header_mode = (
            "matrix"
            if looks_like_header_matrix(toks0)
            else ("summary" if looks_like_header_summary(toks0) else "")
        )
        if not (
            header_mode
            or looks_like_data_row_matrix(toks0)
            or looks_like_data_row_summary(toks0)
        ):
            i += 1
            continue
        j = i
        seg: List[Tuple[float, float, List[Tuple[float, str]]]] = []
        while j < len(lines):
            toks = lines[j][2]
            if len(toks) < 2:
                break
            if looks_like_non_table_sentence(toks):
                break
            if not (
                looks_like_header_matrix(toks)
                or looks_like_header_summary(toks)
                or looks_like_data_row_matrix(toks)
                or looks_like_data_row_summary(toks)
            ):
                break
            seg.append(lines[j])
            if len(seg) >= 30:
                break
            j += 1

        if len(seg) < 3:
            i += 1
            continue

        header_ok_matrix = looks_like_header_matrix(seg[0][2])
        header_ok_summary = looks_like_header_summary(seg[0][2])
        if header_ok_matrix:
            anchors, bounds = anchors_from_matrix_header(seg[0][2], seg)
        elif header_ok_summary:
            anchors = anchors_from_summary_header(seg[0][2])
            bounds = []
        else:
            anchors = anchors_for_segment(seg)
            bounds = []

        min_anchors = 6 if header_ok_matrix else 3 if header_ok_summary else 6
        if len(anchors) < min_anchors:
            i += 1
            continue

        if header_ok_matrix:
            rows_all = [line_to_cells_by_ranges(t[2], anchors, bounds) for t in seg]
        else:
            rows_all = [line_to_cells(t[2], anchors) for t in seg]

        keep_rows: List[List[str]] = []
        rownum_hits = 0
        x_hits = 0
        amount_hits = 0
        for idx_line, r in enumerate(rows_all):
            cov = sum(1 for c in r if c) / max(1, len(anchors))
            if r and re.fullmatch(r"\d{1,3}", (r[0] or "").strip()):
                rownum_hits += 1
            if any((c or "").strip().lower() == "x" for c in r):
                x_hits += 1
            if any(re.search(r"\d{1,3}(?:,\d{3})+(?:\.\d+)?", (c or "")) for c in r):
                amount_hits += 1
            if (
                cov >= 0.55
                or looks_like_header_matrix(seg[idx_line][2])
                or looks_like_header_summary(seg[idx_line][2])
                or looks_like_data_row_matrix(seg[idx_line][2])
                or looks_like_data_row_summary(seg[idx_line][2])
            ):
                keep_rows.append(r)

        if len(keep_rows) < 4:
            i += 1
            continue

        rownum_ratio = rownum_hits / max(1, len(keep_rows))
        x_ratio = x_hits / max(1, len(keep_rows))
        amount_ratio = amount_hits / max(1, len(keep_rows))
        if header_ok_matrix:
            if rownum_ratio < 0.50 or x_ratio < 0.15:
                i += 1
                continue
        elif header_ok_summary:
            if amount_ratio < 0.40:
                i += 1
                continue
        else:
            i += 1
            continue

        y0 = float(seg[0][0])
        y1 = float(seg[min(len(keep_rows) - 1, len(seg) - 1)][1])
        accept_segment(y0, y1, keep_rows)
        i = j + 1

    return segments
