"""CLI entry point — re-exports the existing scripts.convert.main()."""
from scripts.convert import main

__all__ = ["main"]


if __name__ == "__main__":
    main()
