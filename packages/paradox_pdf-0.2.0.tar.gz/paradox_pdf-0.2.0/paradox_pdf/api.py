"""High-level public API.

Wraps the internal ``pdf_tagger.tagger_json.tag_pdf_json`` (which writes JSON
files) so callers can use Paradox as an in-memory library:

    import paradox_pdf as pdx
    doc = pdx.extract("file.pdf")            # returns dict
    doc = pdx.extract("file.pdf", output="out.json")  # also writes file
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from dataclasses import replace
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Union

from pdf_tagger.tagger_json import tag_pdf_json

from .config import PipelineConfig, get_config

PathLike = Union[str, os.PathLike]


def _apply_config(cfg: Optional[PipelineConfig]) -> None:
    """Copy fields from ``cfg`` onto the singleton so internal modules see them."""
    if cfg is None:
        return
    singleton = get_config()
    for f in cfg.__dataclass_fields__:  # type: ignore[attr-defined]
        setattr(singleton, f, getattr(cfg, f))


def extract(
    pdf_path: PathLike,
    *,
    pages: Optional[Sequence[int]] = None,
    no_images: bool = False,
    force_mode: Optional[str] = None,
    output: Optional[PathLike] = None,
    images_dir: Optional[PathLike] = None,
    config: Optional[PipelineConfig] = None,
) -> Dict[str, Any]:
    """Run the full extraction pipeline and return the JSON document as a dict.

    Args:
        pdf_path: Path to the input PDF.
        pages: Optional 1-based page numbers to restrict extraction.
        no_images: If True, skip image extraction (faster, no PNGs written).
        force_mode: ``"heuristic"`` to force the digital pipeline, ``"vision"``
            to force the vision pipeline, ``None`` (default) to auto-route.
        output: Optional path; if given, the JSON is also written there.
        images_dir: Directory where extracted PNGs are written. If ``None`` and
            ``no_images=False``, a temp directory is used and removed afterwards.
            If ``output`` is given but ``images_dir`` is not, defaults to
            ``<output_parent>/<pdf_stem>_images/``.
        config: Optional :class:`PipelineConfig` overriding pipeline thresholds.

    Returns:
        Dict with keys ``source``, ``total_pages``, ``total_elements``,
        ``total_images``, ``type_summary``, ``elements``.

    Raises:
        FileNotFoundError: if ``pdf_path`` does not exist.
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.is_file():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    _apply_config(config)

    cleanup_output = False
    cleanup_images = False

    if output is None:
        fd, tmp_json = tempfile.mkstemp(suffix=".json", prefix="paradox_")
        os.close(fd)
        output_path = Path(tmp_json)
        cleanup_output = True
    else:
        output_path = Path(output)
        output_path.parent.mkdir(parents=True, exist_ok=True)

    if images_dir is None:
        if no_images or cleanup_output:
            images_path = Path(tempfile.mkdtemp(prefix="paradox_imgs_"))
            cleanup_images = True
        else:
            images_path = output_path.parent / f"{pdf_path.stem}_images"
    else:
        images_path = Path(images_dir)
    images_path.mkdir(parents=True, exist_ok=True)

    pages_tuple = tuple(int(p) for p in pages) if pages else None

    try:
        tag_pdf_json(
            str(pdf_path),
            str(output_path),
            str(images_path),
            pages=pages_tuple,
            no_images=no_images,
            force_mode=force_mode,
        )
        with open(output_path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    finally:
        if cleanup_output:
            try:
                output_path.unlink()
            except OSError:
                pass
        if cleanup_images:
            shutil.rmtree(images_path, ignore_errors=True)


def extract_pages(
    pdf_path: PathLike,
    pages: Sequence[int],
    **kwargs: Any,
) -> Dict[str, Any]:
    """Convenience wrapper of :func:`extract` for a subset of pages."""
    return extract(pdf_path, pages=pages, **kwargs)


def extract_to_file(
    pdf_path: PathLike,
    output: PathLike,
    images_dir: Optional[PathLike] = None,
    *,
    pages: Optional[Sequence[int]] = None,
    no_images: bool = False,
    force_mode: Optional[str] = None,
    config: Optional[PipelineConfig] = None,
) -> Dict[str, Any]:
    """Run extraction and persist the JSON + images to disk.

    Returns the same dict as :func:`extract`. Image files are written to
    ``images_dir`` (defaults to ``<output_parent>/<pdf_stem>_images/``).
    """
    return extract(
        pdf_path,
        output=output,
        images_dir=images_dir,
        pages=pages,
        no_images=no_images,
        force_mode=force_mode,
        config=config,
    )


def _walk(nodes: List[Dict[str, Any]], visit) -> None:
    for node in nodes:
        if not isinstance(node, dict):
            continue
        visit(node)
        for key in ("children", "items", "entries", "lines"):
            children = node.get(key)
            if children:
                _walk(children, visit)


def extract_text(pdf_path: PathLike, **kwargs: Any) -> str:
    """Convenience: return only the concatenated plain text of the document."""
    kwargs.setdefault("no_images", True)
    doc = extract(pdf_path, **kwargs)
    parts: List[str] = []

    def visit(node: Dict[str, Any]) -> None:
        text = node.get("text") or ""
        if text:
            parts.append(text)

    _walk(doc.get("elements", []), visit)
    return "\n".join(parts)


def extract_tables(pdf_path: PathLike, **kwargs: Any) -> List[Dict[str, Any]]:
    """Convenience: return a flat list of every TABLE element in the document."""
    kwargs.setdefault("no_images", True)
    doc = extract(pdf_path, **kwargs)
    tables: List[Dict[str, Any]] = []

    def visit(node: Dict[str, Any]) -> None:
        if node.get("type") == "TABLE":
            tables.append(node)

    _walk(doc.get("elements", []), visit)
    return tables


__all__ = [
    "extract",
    "extract_pages",
    "extract_to_file",
    "extract_text",
    "extract_tables",
]
