"""paradox-pdf — structured text extraction for digital and scanned PDFs.

Quick start:

    import paradox_pdf as pdx

    # Get the full hierarchical JSON in memory
    doc = pdx.extract("contract.pdf")
    print(doc["total_pages"], len(doc["elements"]))

    # Only certain pages
    doc = pdx.extract("contract.pdf", pages=[1, 2, 5])

    # Plain text
    text = pdx.extract_text("contract.pdf")

    # Just the tables
    tables = pdx.extract_tables("contract.pdf")

    # Configure thresholds
    cfg = pdx.PipelineConfig(render_dpi=300, scan_text_threshold=80)
    doc = pdx.extract("contract.pdf", config=cfg)

    # Write to disk (and also get the dict back)
    doc = pdx.extract("contract.pdf", output="out.json", images_dir="imgs/")
"""

from .api import (
    extract,
    extract_pages,
    extract_text,
    extract_tables,
    extract_to_file,
)
from .config import PipelineConfig, get_config, reset_config

__version__ = "0.2.0"

__all__ = [
    "extract",
    "extract_pages",
    "extract_text",
    "extract_tables",
    "extract_to_file",
    "PipelineConfig",
    "get_config",
    "reset_config",
    "__version__",
]
