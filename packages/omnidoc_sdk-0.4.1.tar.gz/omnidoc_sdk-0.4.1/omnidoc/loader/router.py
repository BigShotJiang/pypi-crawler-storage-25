# omnidoc/loader/router.py
from pathlib import Path
from omnidoc.loader.types import DocumentType

# Compound / alias extension mappings that can't be derived from a single suffix
_COMPOUND: dict[str, DocumentType] = {
    ".tar.gz":  DocumentType.TAR,
    ".tar.bz2": DocumentType.TAR,
    ".tar.xz":  DocumentType.TAR,
    ".tar.zst": DocumentType.TAR,
}

# Explicit aliases: maps lowercase ext (without dot) → DocumentType
# Used when the enum value differs from the extension string (e.g. "7z" → SEVENZ)
_ALIASES: dict[str, DocumentType] = {
    "7z":   DocumentType.SEVENZ,
    "tif":  DocumentType.TIFF,
    "htm":  DocumentType.HTML,
    "yml":  DocumentType.YAML,
    "heif": DocumentType.HEIC,
    "xls":  DocumentType.XLSX,
    "rst":  DocumentType.MD,      # treat reStructuredText as markdown-like
    "go":   DocumentType.PY,      # treat Go as generic code
    "js":   DocumentType.PY,
    "ts":   DocumentType.PY,
    "cpp":  DocumentType.PY,
    "c":    DocumentType.PY,
    "rs":   DocumentType.PY,
    "java": DocumentType.JAVA,
    "wav":  DocumentType.MP3,
    "m4a":  DocumentType.MP3,
    "mov":  DocumentType.MP4,
    "avi":  DocumentType.MP4,
    "mkv":  DocumentType.MP4,
    "bmp":  DocumentType.PNG,
    "gif":  DocumentType.PNG,
    "svg":  DocumentType.SVG,
}


def detect_document_type(path: str) -> DocumentType:
    lower = path.lower()

    # Check compound extensions first (.tar.gz etc.)
    for compound, doc_type in _COMPOUND.items():
        if lower.endswith(compound):
            return doc_type

    ext = Path(path).suffix.lower().lstrip(".")

    # Check explicit aliases
    if ext in _ALIASES:
        return _ALIASES[ext]

    # Try direct enum match
    try:
        return DocumentType(ext)
    except ValueError:
        return DocumentType.UNKNOWN
