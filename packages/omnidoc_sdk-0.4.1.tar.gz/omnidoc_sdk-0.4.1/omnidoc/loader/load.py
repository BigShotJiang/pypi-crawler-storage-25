# omnidoc/loader/load.py
import logging
import os

from omnidoc.loader.router import detect_document_type
from omnidoc.loader.types import DocumentType
from omnidoc.pdf.pipeline import extract_pdf

logger = logging.getLogger(__name__)


def load_document(path: str, *, config=None, **pdf_options):
    """
    Universal document loader — detects type by extension, routes to the
    correct extractor, and returns a Document object.

    For RAG chunking, pipe the returned Document into omnidoc-rag.

    Parameters
    ----------
    path:        Path to the document file.
    config:      Optional OmnidocConfig; uses default when None.
    **pdf_options: Extra kwargs forwarded to extract_pdf() for PDF files
                   (enable_layout, enable_cloud_ocr, enable_pii_masking, …).
    """
    if not isinstance(path, str) or not path.strip():
        raise ValueError("path must be a non-empty string")

    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")

    if not os.path.isfile(path):
        raise ValueError(f"Path is not a file: {path}")

    from omnidoc.config import default_config
    cfg = config if config is not None else default_config

    file_size = os.path.getsize(path)
    if file_size > cfg.max_file_bytes:
        raise ValueError(
            f"File size {file_size / 1024 / 1024:.1f} MB exceeds limit "
            f"{cfg.max_file_mb} MB for '{path}'"
        )

    logger.info("load_document: path='%s' size=%.1fKB", path, file_size / 1024)

    doc_type = detect_document_type(path)
    logger.debug("load_document: detected type=%s", doc_type)

    if doc_type == DocumentType.PDF:
        return extract_pdf(path, config=cfg, **pdf_options)

    return _load_non_pdf(path, doc_type)


# ------------------------------------------------------------------
# Extractor dispatch
# ------------------------------------------------------------------

def _load_non_pdf(path: str, doc_type: DocumentType):
    """Lazy extractor resolution — imports only the required dependency."""

    # ── Plain text ────────────────────────────────────────────────────
    if doc_type == DocumentType.TXT:
        from omnidoc.extractors.text.extractor import TextExtractor
        return TextExtractor().extract(path)

    # ── Markdown / RST ───────────────────────────────────────────────
    if doc_type == DocumentType.MD:
        from omnidoc.extractors.markdown.extractor import MarkdownExtractor
        return MarkdownExtractor().extract(path)

    # ── Office documents ─────────────────────────────────────────────
    if doc_type == DocumentType.DOCX:
        from omnidoc.extractors.office.docx import DocxExtractor
        return DocxExtractor().extract(path)

    if doc_type in (DocumentType.XLSX, DocumentType.XLS,
                    DocumentType.CSV, DocumentType.TSV):
        from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor
        return SpreadsheetExtractor().extract(path)

    if doc_type == DocumentType.PPTX:
        from omnidoc.extractors.office.pptx import PPTXExtractor
        return PPTXExtractor().extract(path)

    # ── OpenDocument (LibreOffice) ────────────────────────────────────
    if doc_type in (DocumentType.ODT, DocumentType.ODS, DocumentType.ODP):
        from omnidoc.extractors.openoffice.extractor import OpenDocumentExtractor
        return OpenDocumentExtractor().extract(path)

    # ── Images ───────────────────────────────────────────────────────
    if doc_type in (
        DocumentType.PNG, DocumentType.JPG, DocumentType.JPEG,
        DocumentType.TIFF, DocumentType.TIF, DocumentType.WEBP,
        DocumentType.HEIC, DocumentType.HEIF,
        DocumentType.BMP, DocumentType.GIF,
    ):
        from omnidoc.extractors.image.extractor import ImageExtractor
        return ImageExtractor().extract(path)

    # ── SVG ───────────────────────────────────────────────────────────
    if doc_type == DocumentType.SVG:
        from omnidoc.extractors.web.html_extractor import HTMLExtractor
        return HTMLExtractor().extract(path)

    # ── Structured data ───────────────────────────────────────────────
    if doc_type == DocumentType.JSON:
        from omnidoc.extractors.structured.json_xml import JSONExtractor
        return JSONExtractor().extract(path)

    if doc_type == DocumentType.XML:
        from omnidoc.extractors.structured.json_xml import XMLExtractor
        return XMLExtractor().extract(path)

    if doc_type in (DocumentType.YAML, DocumentType.YML):
        from omnidoc.extractors.structured.yaml_extractor import YAMLExtractor
        return YAMLExtractor().extract(path)

    # ── Web ───────────────────────────────────────────────────────────
    if doc_type in (DocumentType.HTML, DocumentType.HTM):
        from omnidoc.extractors.web.html_extractor import HTMLExtractor
        return HTMLExtractor().extract(path)

    # ── EPUB ─────────────────────────────────────────────────────────
    if doc_type == DocumentType.EPUB:
        from omnidoc.extractors.ebook.epub_extractor import EPUBExtractor
        return EPUBExtractor().extract(path)

    # ── Email ─────────────────────────────────────────────────────────
    if doc_type == DocumentType.EML:
        from omnidoc.extractors.email.eml_extractor import EMLExtractor
        return EMLExtractor().extract(path)

    if doc_type == DocumentType.MSG:
        from omnidoc.extractors.email.msg_extractor import MSGExtractor
        return MSGExtractor().extract(path)

    # ── RTF ───────────────────────────────────────────────────────────
    if doc_type == DocumentType.RTF:
        from omnidoc.extractors.legacy.rtf_extractor import RTFExtractor
        return RTFExtractor().extract(path)

    # ── Notebooks ─────────────────────────────────────────────────────
    if doc_type == DocumentType.IPYNB:
        from omnidoc.extractors.notebook.extractor import NotebookExtractor
        return NotebookExtractor().extract(path)

    # ── Source code ───────────────────────────────────────────────────
    if doc_type in (
        DocumentType.PY, DocumentType.JAVA,
        DocumentType.JS, DocumentType.TS,
        DocumentType.GO, DocumentType.CPP, DocumentType.C,
        DocumentType.RS,
    ):
        from omnidoc.extractors.code.extractor import CodeExtractor
        return CodeExtractor().extract(path)

    # ── Archives ──────────────────────────────────────────────────────
    if doc_type in (DocumentType.ZIP, DocumentType.TAR,
                    DocumentType.GZ, DocumentType.SEVENZ):
        from omnidoc.extractors.archive.extractor import ArchiveExtractor
        return ArchiveExtractor().extract(path)

    # ── Multimedia ────────────────────────────────────────────────────
    if doc_type in (
        DocumentType.MP3, DocumentType.MP4,
        DocumentType.WAV, DocumentType.M4A,
        DocumentType.MOV, DocumentType.AVI, DocumentType.MKV,
    ):
        from omnidoc.extractors.media.extractor import MediaExtractor
        return MediaExtractor().extract(path)

    raise ValueError(
        f"Unsupported document type '{doc_type.value}' for '{path}'. "
        "Check that the file extension is correct or use a raw extractor directly."
    )
