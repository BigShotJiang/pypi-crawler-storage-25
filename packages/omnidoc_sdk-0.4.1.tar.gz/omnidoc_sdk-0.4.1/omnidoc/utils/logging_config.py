"""
omnidoc/utils/logging_config.py
--------------------------------
Structured logging setup for the OmniDoc SDK.

Call `configure_logging()` once at application start-up.
If the calling application already configures its own logging, just
import the `get_logger()` helper — it returns a child logger under the
"omnidoc" namespace so the host app's handlers pick it up automatically.

Usage
-----
    # Application entry point (e.g. FastAPI lifespan, Lambda handler):
    from omnidoc.utils.logging_config import configure_logging
    configure_logging(level="INFO", json=True)

    # Inside SDK modules — use module-level loggers:
    import logging
    logger = logging.getLogger(__name__)
"""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Optional

# Root logger for the entire SDK — all module loggers are children of this.
_SDK_ROOT = "omnidoc"


# ------------------------------------------------------------------
# JSON formatter
# ------------------------------------------------------------------

class _JsonFormatter(logging.Formatter):
    """
    Emits one JSON object per log record.

    Structured fields:
        ts       Unix timestamp (float)
        level    Log level name
        logger   Logger name
        msg      Formatted message
        exc      Exception info (if present)
    """

    def format(self, record: logging.LogRecord) -> str:
        payload: dict = {
            "ts": record.created,
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

def configure_logging(
    level: str = "WARNING",
    json: bool = False,
    stream=None,
) -> None:
    """
    Configure the SDK's root logger.

    Parameters
    ----------
    level:   Python log level name (DEBUG / INFO / WARNING / ERROR / CRITICAL).
    json:    When True, emit JSON-structured log lines (useful in cloud / k8s).
    stream:  Output stream; defaults to sys.stderr.
    """
    numeric = getattr(logging, level.upper(), None)
    if not isinstance(numeric, int):
        raise ValueError(f"Invalid log level: {level!r}")

    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setLevel(numeric)

    if json:
        handler.setFormatter(_JsonFormatter())
    else:
        fmt = "%(asctime)s %(levelname)-8s %(name)s — %(message)s"
        handler.setFormatter(logging.Formatter(fmt, datefmt="%Y-%m-%dT%H:%M:%S"))

    sdk_logger = logging.getLogger(_SDK_ROOT)
    sdk_logger.setLevel(numeric)

    # Avoid duplicate handlers if called more than once (e.g. in tests)
    sdk_logger.handlers.clear()
    sdk_logger.addHandler(handler)
    sdk_logger.propagate = False


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Return a child logger under the SDK namespace.

    Prefer `logging.getLogger(__name__)` inside SDK modules so the full
    dotted path is preserved. Use `get_logger()` from outside the SDK.
    """
    if name:
        return logging.getLogger(f"{_SDK_ROOT}.{name}")
    return logging.getLogger(_SDK_ROOT)
