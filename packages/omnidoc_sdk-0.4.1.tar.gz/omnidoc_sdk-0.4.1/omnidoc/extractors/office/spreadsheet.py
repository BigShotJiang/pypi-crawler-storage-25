# omnidoc/extractors/office/spreadsheet.py
import logging
import os
from typing import Dict, List

import pandas as pd

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)

# CSV encodings tried in order before giving up
_CSV_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class SpreadsheetExtractor(BaseExtractor):
    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Spreadsheet not found: {path}")

        try:
            sheets = self._read(path)
        except Exception as exc:
            raise ValueError(f"Failed to parse spreadsheet '{path}': {exc}") from exc

        tables: List[Table] = []
        sections: List[Section] = []
        raw_parts: List[str] = []

        for page_num, (sheet_name, df) in enumerate(sheets.items(), start=1):
            # Sanitise column names — pandas may return ints for unnamed cols
            df.columns = [str(c) for c in df.columns]

            tables.append(Table(
                page=page_num,
                headers=list(df.columns),
                rows=df.fillna("").astype(str).values.tolist(),
            ))

            sheet_text = f"[Sheet: {sheet_name}]\n{df.to_string(index=False)}"
            sections.append(Section(page=page_num, text=sheet_text))
            raw_parts.append(sheet_text)

            logger.debug(
                "SpreadsheetExtractor: sheet '%s' (page %d) — %d rows × %d cols from '%s'",
                sheet_name, page_num, len(df), len(df.columns), path,
            )

        raw_text = "\n\n".join(raw_parts)
        sheet_names = list(sheets.keys())

        return Document(
            metadata={
                "file": path,
                "type": "spreadsheet",
                "pages": len(sheets),
                "sheets": sheet_names,
            },
            sections=sections,
            tables=tables,
            raw_text=raw_text,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _read(self, path: str) -> Dict[str, "pd.DataFrame"]:
        lower = path.lower()
        if lower.endswith(".xlsx") or lower.endswith(".xls"):
            # sheet_name=None returns all sheets as {name: DataFrame}
            return pd.read_excel(path, sheet_name=None)

        # TSV — tab-separated values
        if lower.endswith(".tsv"):
            for enc in _CSV_ENCODINGS:
                try:
                    return {"Sheet1": pd.read_csv(path, sep="\t", encoding=enc)}
                except (UnicodeDecodeError, LookupError):
                    continue
            return {"Sheet1": pd.read_csv(path, sep="\t", encoding="utf-8", encoding_errors="replace")}

        # CSV (default) — try multiple encodings
        for enc in _CSV_ENCODINGS:
            try:
                return {"Sheet1": pd.read_csv(path, encoding=enc)}
            except (UnicodeDecodeError, LookupError):
                continue

        # Last resort: replace bad bytes
        return {"Sheet1": pd.read_csv(path, encoding="utf-8", encoding_errors="replace")}
