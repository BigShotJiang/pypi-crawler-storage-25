import logging
import os
from typing import List, Optional

from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)


class PPTXExtractor:
    """
    Production-grade PPTX extractor.

    Guarantees:
    - Slide-aware sections
    - Safe title placeholder detection (no AttributeError on missing title)
    - Safe empty-table handling
    - RAG semantic chunk compatibility
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"PPTXExtractor: file not found: {path}")

        try:
            from pptx import Presentation
        except ImportError as exc:
            raise ImportError(
                "PPTX support requires python-pptx.\n"
                "Install with: pip install 'omnidoc-sdk[office]'"
            ) from exc

        try:
            prs = Presentation(path)
        except Exception as exc:
            raise ValueError(
                f"PPTXExtractor: cannot open '{path}': {exc}"
            ) from exc

        sections: List[Section] = []
        tables: List[Table] = []
        page = 0

        for slide in prs.slides:
            page += 1
            slide_lines: List[str] = []
            slide_title: Optional[str] = None

            # Resolve title shape safely — title may not exist on every slide
            title_shape = None
            try:
                title_shape = slide.shapes.title
            except Exception:
                pass

            for shape in slide.shapes:
                # ------ Tables ------
                if shape.has_table:
                    try:
                        rows: List[List[str]] = []
                        for row in shape.table.rows:
                            rows.append([_safe_cell(cell) for cell in row.cells])
                        if rows:
                            tables.append(Table(
                                page=page,
                                headers=rows[0],
                                rows=rows[1:] if len(rows) > 1 else [],
                            ))
                    except Exception as exc:
                        logger.warning("PPTXExtractor: skipping table on slide %d: %s", page, exc)

                # ------ Text ------
                if not shape.has_text_frame:
                    continue

                try:
                    text = (shape.text or "").strip()
                except Exception:
                    continue

                if not text:
                    continue

                # Is this the title shape? Use identity check, not equality
                if title_shape is not None and shape is title_shape:
                    slide_title = text
                else:
                    slide_lines.append(text)

            if slide_title:
                sections.append(Section(page=page, text=slide_title))
            if slide_lines:
                sections.append(Section(page=page, text="\n".join(slide_lines)))

        raw_text = "\n\n".join(s.text for s in sections)
        logger.debug(
            "PPTXExtractor: %d slides, %d sections, %d tables from '%s'",
            page, len(sections), len(tables), path,
        )

        return Document(
            metadata={"file": path, "pages": page, "type": "pptx"},
            sections=sections,
            tables=tables,
            raw_text=raw_text,
        )


def _safe_cell(cell) -> str:
    try:
        return (cell.text or "").strip()
    except Exception:
        return ""
