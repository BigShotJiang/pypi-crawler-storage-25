import logging
import os

from omnidoc.core.document import Document, Section, Table

logger = logging.getLogger(__name__)

# Encodings tried in order; last entry always succeeds (errors='replace')
_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class TextExtractor:
    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Text file not found: {path}")

        text = self._read_with_fallback(path)

        sections = [Section(page=1, text=text)]

        logger.debug("TextExtractor: read %d chars from '%s'", len(text), path)

        return Document(
            metadata={"file": path, "pages": 1, "type": "text"},
            sections=sections,
            tables=[],
            raw_text=text,
        )

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _read_with_fallback(self, path: str) -> str:
        raw = open(path, "rb").read()

        # Try known encodings first (fast path)
        for enc in _ENCODINGS:
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue

        # chardet auto-detection (optional dependency)
        try:
            import chardet
            detected = chardet.detect(raw).get("encoding") or "utf-8"
            return raw.decode(detected, errors="replace")
        except ImportError:
            pass

        # Absolute fallback — never crashes
        logger.warning("TextExtractor: could not detect encoding for '%s'; replacing bad bytes", path)
        return raw.decode("utf-8", errors="replace")
