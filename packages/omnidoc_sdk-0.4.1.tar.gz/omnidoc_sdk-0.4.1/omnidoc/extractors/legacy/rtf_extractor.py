# omnidoc/extractors/legacy/rtf_extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)

_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]


class RTFExtractor(BaseExtractor):
    """
    Extract plain text from RTF files via the striprtf library.

    striprtf handles all RTF control words and unicode escape sequences,
    returning clean paragraph-separated plain text.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"RTFExtractor: file not found: {path}")

        try:
            from striprtf.striprtf import rtf_to_text
        except ImportError as exc:
            raise ImportError(
                "RTF support requires striprtf.\n"
                "Install with: pip install 'omnidoc-sdk[legacy]'"
            ) from exc

        raw_rtf = _read_rtf(path)
        try:
            text = rtf_to_text(raw_rtf)
        except Exception as exc:
            raise ValueError(f"RTFExtractor: failed to parse '{path}': {exc}") from exc

        text = text.strip()
        paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
        sections: List[Section] = [Section(page=1, text=p) for p in paragraphs]

        if not sections:
            sections = [Section(page=1, text="")]

        raw = "\n\n".join(s.text for s in sections)
        logger.debug("RTFExtractor: extracted %d paragraphs from '%s'", len(sections), path)
        return Document(
            metadata={"file": path, "type": "rtf", "pages": 1},
            sections=sections,
            tables=[],
            raw_text=raw,
        )


def _read_rtf(path: str) -> str:
    for enc in _ENCODINGS:
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()
