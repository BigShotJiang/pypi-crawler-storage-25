# omnidoc/extractors/email/msg_extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class MSGExtractor(BaseExtractor):
    """
    Extract text from Outlook .msg files via the extract-msg library.

    Extracts sender, recipients, subject, body (plain-text preferred,
    HTML as fallback), and lists attachment filenames in metadata.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"MSGExtractor: file not found: {path}")

        try:
            import extract_msg
        except ImportError as exc:
            raise ImportError(
                "MSG support requires extract-msg.\n"
                "Install with: pip install 'omnidoc-sdk[email]'"
            ) from exc

        with extract_msg.openMsg(path) as msg:
            subject = msg.subject or ""
            sender = msg.sender or ""
            to = msg.to or ""
            date = str(msg.date) if msg.date else ""
            body = msg.body or ""
            html_body = getattr(msg, "htmlBody", None) or b""

            attachments: List[str] = []
            for att in msg.attachments:
                name = getattr(att, "longFilename", None) or getattr(att, "shortFilename", None) or "attachment"
                attachments.append(name)

        if not body and html_body:
            body = _strip_html(html_body if isinstance(html_body, str) else html_body.decode("utf-8", errors="replace"))

        sections: List[Section] = []
        header_block = "\n".join(filter(None, [
            f"From: {sender}" if sender else "",
            f"To: {to}" if to else "",
            f"Subject: {subject}" if subject else "",
            f"Date: {date}" if date else "",
        ]))
        if header_block:
            sections.append(Section(page=1, text=header_block))
        if body:
            sections.append(Section(page=1, text=body.strip()))

        raw_text = "\n\n".join(s.text for s in sections)
        metadata: dict = {
            "file": path,
            "type": "msg",
            "pages": 1,
            "subject": subject,
            "from": sender,
            "to": to,
            "date": date,
        }
        if attachments:
            metadata["attachments"] = attachments

        logger.debug("MSGExtractor: extracted '%s'", path)
        return Document(metadata=metadata, sections=sections, tables=[], raw_text=raw_text)


def _strip_html(html: str) -> str:
    try:
        from bs4 import BeautifulSoup
        return BeautifulSoup(html, "html.parser").get_text(separator="\n", strip=True)
    except ImportError:
        import re
        return re.sub(r"<[^>]+>", " ", html).strip()
