# omnidoc/extractors/image/extractor.py
import logging
import os
from typing import Optional

import pytesseract
from PIL import Image, UnidentifiedImageError

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section
from omnidoc.ocr.tesseract import _ocr_timeout

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 60

# Extensions handled by this extractor (checked at dispatch)
SUPPORTED_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".tiff", ".tif",
    ".webp", ".heic", ".heif", ".bmp", ".gif",
}


class ImageExtractor(BaseExtractor):
    """
    Extract text from images via Tesseract OCR.

    Parameters
    ----------
    timeout: Per-image OCR timeout in seconds. 0 = unlimited.
    lang:    Tesseract language code(s), e.g. "eng", "eng+fra".
    """

    def __init__(self, timeout: int = _DEFAULT_TIMEOUT, lang: Optional[str] = None) -> None:
        self._timeout = timeout
        self._lang = lang

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"ImageExtractor: file not found: {path}")

        # Register HEIC/HEIF support if pillow-heif is installed
        _register_heif()

        try:
            img = Image.open(path)
            img.verify()                    # detect truncated / corrupt files
            img = Image.open(path)          # reopen after verify (verify closes the file)
        except UnidentifiedImageError as exc:
            raise ValueError(f"ImageExtractor: unrecognised image format '{path}'") from exc
        except Exception as exc:
            raise ValueError(f"ImageExtractor: cannot open image '{path}': {exc}") from exc

        # Normalise colour mode — Tesseract works best with RGB or L
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")

        logger.debug("ImageExtractor: OCR on '%s' (%s %dx%d)", path, img.mode, *img.size)

        kwargs = {"lang": self._lang} if self._lang else {}
        try:
            with _ocr_timeout(self._timeout):
                text = pytesseract.image_to_string(img, **kwargs)
        except TimeoutError:
            logger.warning("ImageExtractor: OCR timed out after %ds for '%s'", self._timeout, path)
            text = ""
        except Exception as exc:
            logger.warning("ImageExtractor: OCR failed for '%s': %s", path, exc)
            text = ""

        text = text.strip()
        return Document(
            metadata={"file": path, "type": "image", "pages": 1},
            sections=[Section(page=1, text=text)],
            tables=[],
            raw_text=text,
        )


def _register_heif() -> None:
    """Optionally register HEIC/HEIF support via pillow-heif."""
    try:
        from pillow_heif import register_heif_opener
        register_heif_opener()
    except ImportError:
        pass
