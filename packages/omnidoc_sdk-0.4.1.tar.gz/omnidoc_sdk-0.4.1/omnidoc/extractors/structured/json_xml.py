# omnidoc/extractors/structured/json_xml.py
import json
import logging
import os
import xml.etree.ElementTree as ET
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class JSONExtractor(BaseExtractor):
    """Extract structured JSON documents into a Document."""

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"JSONExtractor: file not found: {path}")

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"JSONExtractor: malformed JSON in '{path}' at line {exc.lineno}: {exc.msg}"
            ) from exc
        except UnicodeDecodeError as exc:
            raise ValueError(
                f"JSONExtractor: encoding error reading '{path}': {exc}"
            ) from exc

        text = json.dumps(data, indent=2, ensure_ascii=False)
        logger.debug("JSONExtractor: parsed %d top-level keys from '%s'", len(data) if isinstance(data, dict) else len(data) if isinstance(data, list) else 1, path)

        return Document(
            metadata={"file": path, "type": "json", "pages": 1},
            sections=[Section(page=1, text=text)],
            tables=[],
            raw_text=text,
        )


class XMLExtractor(BaseExtractor):
    """Extract XML documents, preserving all text node content."""

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"XMLExtractor: file not found: {path}")

        try:
            tree = ET.parse(path)
        except ET.ParseError as exc:
            raise ValueError(
                f"XMLExtractor: malformed XML in '{path}': {exc}"
            ) from exc
        except Exception as exc:
            raise ValueError(
                f"XMLExtractor: cannot parse '{path}': {exc}"
            ) from exc

        root = tree.getroot()
        lines = _flatten_xml(root)
        text = "\n".join(lines).strip()

        logger.debug("XMLExtractor: extracted %d lines from '%s'", len(lines), path)

        return Document(
            metadata={"file": path, "type": "xml", "pages": 1},
            sections=[Section(page=1, text=text)],
            tables=[],
            raw_text=text,
        )


# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------

def _flatten_xml(elem: ET.Element, depth: int = 0) -> List[str]:
    """Recursively extract tag names AND text content from an XML element."""
    lines: List[str] = []
    indent = "  " * depth
    tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag  # strip namespace

    # Opening tag with attributes
    attrs = " ".join(f'{k}="{v}"' for k, v in elem.attrib.items())
    open_tag = f"<{tag} {attrs}>" if attrs else f"<{tag}>"
    lines.append(f"{indent}{open_tag}")

    # Inline text content (the actual data we care about for RAG)
    if elem.text and elem.text.strip():
        lines.append(f"{indent}  {elem.text.strip()}")

    # Children
    for child in elem:
        lines.extend(_flatten_xml(child, depth + 1))
        # Tail text (text between end-tag of child and start-tag of next sibling)
        if child.tail and child.tail.strip():
            lines.append(f"{indent}  {child.tail.strip()}")

    return lines
