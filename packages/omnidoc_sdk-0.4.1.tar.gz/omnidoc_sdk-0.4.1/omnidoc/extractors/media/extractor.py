# omnidoc/extractors/media/extractor.py
import logging
import os
import tempfile
from typing import List, Optional

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)

# Extensions this extractor handles
SUPPORTED_EXTENSIONS = {".mp3", ".mp4", ".wav", ".m4a", ".mov", ".avi", ".mkv"}


class MediaExtractor(BaseExtractor):
    """
    Transcribe audio/video files to text using OpenAI Whisper (local model).

    Parameters
    ----------
    model:    Whisper model size — "tiny", "base", "small", "medium", "large".
              Defaults to "base" (good quality, runs on CPU in reasonable time).
    language: BCP-47 language code hint, e.g. "en". None = auto-detect.
    device:   "cpu" or "cuda". None = auto (cuda if available, else cpu).
    """

    def __init__(
        self,
        model: str = "base",
        language: Optional[str] = None,
        device: Optional[str] = None,
    ) -> None:
        self._model_name = model
        self._language = language
        self._device = device
        self._model = None  # loaded lazily

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"MediaExtractor: file not found: {path}")

        ext = os.path.splitext(path)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"MediaExtractor: unsupported extension '{ext}'. "
                f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
            )

        whisper = _import_whisper()
        model = self._load_model(whisper)

        audio_path = _ensure_audio(path, ext)
        cleanup = audio_path != path  # True when we created a temp wav

        try:
            transcribe_kwargs: dict = {}
            if self._language:
                transcribe_kwargs["language"] = self._language

            logger.debug("MediaExtractor: transcribing '%s' with model '%s'", path, self._model_name)
            result = model.transcribe(audio_path, **transcribe_kwargs)
        finally:
            if cleanup and os.path.exists(audio_path):
                os.unlink(audio_path)

        full_text: str = result.get("text", "").strip()
        segments = result.get("segments", [])

        sections: List[Section] = []
        if segments:
            for seg in segments:
                seg_text = seg.get("text", "").strip()
                if seg_text:
                    sections.append(Section(page=1, text=seg_text))
        else:
            if full_text:
                sections = [Section(page=1, text=full_text)]

        if not sections:
            sections = [Section(page=1, text="")]

        detected_language = result.get("language", "")
        metadata: dict = {
            "file": path,
            "type": "media",
            "pages": 1,
            "whisper_model": self._model_name,
        }
        if detected_language:
            metadata["language"] = detected_language

        logger.debug(
            "MediaExtractor: transcribed %d segments from '%s'", len(sections), path
        )
        return Document(
            metadata=metadata,
            sections=sections,
            tables=[],
            raw_text=full_text,
        )

    def _load_model(self, whisper):
        if self._model is None:
            kwargs = {}
            if self._device:
                kwargs["device"] = self._device
            self._model = whisper.load_model(self._model_name, **kwargs)
        return self._model


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _import_whisper():
    try:
        import whisper
        return whisper
    except ImportError as exc:
        raise ImportError(
            "Media transcription requires openai-whisper.\n"
            "Install with: pip install 'omnidoc-sdk[media]'"
        ) from exc


def _ensure_audio(path: str, ext: str) -> str:
    """
    For video files or formats that Whisper may not read directly,
    extract/convert to a temporary WAV using ffmpeg-python.
    Returns the path to use (may be the original or a temp file).
    """
    # Whisper natively supports mp3, mp4, wav, m4a, flac, ogg, webm
    # For avi/mkv/mov we convert to wav via ffmpeg for reliability
    if ext in {".avi", ".mkv", ".mov"}:
        try:
            import ffmpeg
            tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            tmp.close()
            (
                ffmpeg
                .input(path)
                .output(tmp.name, acodec="pcm_s16le", ac=1, ar="16000")
                .overwrite_output()
                .run(quiet=True)
            )
            return tmp.name
        except Exception as exc:
            logger.warning(
                "MediaExtractor: ffmpeg conversion failed (%s), passing raw path to Whisper", exc
            )
    return path
