# omnidoc/extractors/archive/extractor.py
import logging
import os
import shutil
import tarfile
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, List

from omnidoc.extractors.base import BaseExtractor

logger = logging.getLogger(__name__)

# 512 MB per archive member — prevent zip/tar-bomb extraction
_MAX_MEMBER_BYTES = 512 * 1024 * 1024


class ArchiveExtractor(BaseExtractor):
    """
    Extract ZIP, TAR (+ .tar.gz / .tar.bz2 / .tar.xz), and 7-Zip archives.

    Returns {"type": "archive", "files": [list of extracted absolute paths]}.
    All formats enforce path-traversal and member-size guards.
    """

    def extract(self, path: str) -> Dict[str, object]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Archive not found: {path}")

        lower = path.lower()
        tmp_dir = tempfile.mkdtemp(prefix="omnidoc_archive_")
        try:
            if lower.endswith(".7z"):
                extracted = self._extract_7z(path, tmp_dir)
            elif (lower.endswith(".tar") or lower.endswith(".tar.gz")
                  or lower.endswith(".tar.bz2") or lower.endswith(".tar.xz")
                  or lower.endswith(".tgz") or lower.endswith(".tbz2")):
                extracted = self._extract_tar(path, tmp_dir)
            else:
                if not zipfile.is_zipfile(path):
                    raise ValueError(f"File is not a valid ZIP archive: {path}")
                extracted = self._extract_zip(path, tmp_dir)

            logger.debug("ArchiveExtractor: extracted %d files from '%s'", len(extracted), path)
            return {"type": "archive", "files": extracted}
        except Exception:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise

    # ------------------------------------------------------------------
    # ZIP
    # ------------------------------------------------------------------

    def _extract_zip(self, zip_path: str, dest: str) -> List[str]:
        dest_path = Path(dest).resolve()
        extracted: List[str] = []

        with zipfile.ZipFile(zip_path) as zf:
            for member in zf.infolist():
                target = (dest_path / member.filename).resolve()
                if not str(target).startswith(str(dest_path) + os.sep):
                    logger.warning("Skipping path-traversal ZIP member: '%s'", member.filename)
                    continue
                if member.file_size > _MAX_MEMBER_BYTES:
                    logger.warning("Skipping oversized ZIP member '%s' (%d bytes)", member.filename, member.file_size)
                    continue
                zf.extract(member, dest)
                if not member.is_dir():
                    extracted.append(str(target))
        return extracted

    # ------------------------------------------------------------------
    # TAR (.tar, .tar.gz, .tar.bz2, .tar.xz)
    # ------------------------------------------------------------------

    def _extract_tar(self, tar_path: str, dest: str) -> List[str]:
        dest_path = Path(dest).resolve()
        extracted: List[str] = []

        if not tarfile.is_tarfile(tar_path):
            raise ValueError(f"File is not a valid TAR archive: {tar_path}")

        with tarfile.open(tar_path, "r:*") as tf:
            for member in tf.getmembers():
                # Path traversal guard
                target = (dest_path / member.name).resolve()
                if not str(target).startswith(str(dest_path) + os.sep):
                    logger.warning("Skipping path-traversal TAR member: '%s'", member.name)
                    continue
                # Size guard
                if member.size > _MAX_MEMBER_BYTES:
                    logger.warning("Skipping oversized TAR member '%s' (%d bytes)", member.name, member.size)
                    continue
                try:
                    tf.extract(member, dest, set_attrs=False)
                    if member.isfile():
                        extracted.append(str(target))
                except Exception as exc:
                    logger.warning("TAR extract failed for '%s': %s", member.name, exc)
        return extracted

    # ------------------------------------------------------------------
    # 7-Zip
    # ------------------------------------------------------------------

    def _extract_7z(self, archive_path: str, dest: str) -> List[str]:
        try:
            import py7zr
        except ImportError as exc:
            raise ImportError(
                "7-Zip support requires py7zr.\n"
                "Install with: pip install 'omnidoc-sdk[archive]'"
            ) from exc

        dest_path = Path(dest).resolve()
        extracted: List[str] = []

        with py7zr.SevenZipFile(archive_path, mode="r") as sz:
            for fname, bio in (sz.read() or {}).items():
                target = (dest_path / fname).resolve()
                if not str(target).startswith(str(dest_path) + os.sep):
                    logger.warning("Skipping path-traversal 7z member: '%s'", fname)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                data = bio.read() if bio else b""
                if len(data) > _MAX_MEMBER_BYTES:
                    logger.warning("Skipping oversized 7z member '%s' (%d bytes)", fname, len(data))
                    continue
                target.write_bytes(data)
                extracted.append(str(target))

        return extracted
