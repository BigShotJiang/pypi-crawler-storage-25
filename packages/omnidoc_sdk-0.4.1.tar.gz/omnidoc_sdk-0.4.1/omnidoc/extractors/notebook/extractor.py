# omnidoc/extractors/notebook/extractor.py
import logging
import os
from typing import List

from omnidoc.extractors.base import BaseExtractor
from omnidoc.core.document import Document, Section

logger = logging.getLogger(__name__)


class NotebookExtractor(BaseExtractor):
    """
    Extract content from Jupyter Notebook (.ipynb) files via nbformat.

    Each cell becomes a Section. Cell type is embedded as a prefix so the
    extractor distinguishes markdown prose from code and output.
    Execution outputs (stream, display_data, execute_result) are included.
    """

    def extract(self, path: str) -> Document:
        if not os.path.exists(path):
            raise FileNotFoundError(f"NotebookExtractor: file not found: {path}")

        try:
            import nbformat
        except ImportError as exc:
            raise ImportError(
                "Notebook support requires nbformat.\n"
                "Install with: pip install 'omnidoc-sdk[code]'"
            ) from exc

        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            nb = nbformat.read(fh, as_version=4)

        kernel = nb.metadata.get("kernelspec", {}).get("display_name", "")
        language = nb.metadata.get("kernelspec", {}).get("language", "")

        sections: List[Section] = []

        for idx, cell in enumerate(nb.cells, start=1):
            cell_type = cell.cell_type  # "markdown", "code", "raw"
            source = cell.source.strip()

            if not source:
                continue

            if cell_type == "markdown":
                sections.append(Section(page=idx, text=source))
            elif cell_type == "code":
                lines = [f"```{language}" if language else "```", source, "```"]
                cell_text = "\n".join(lines)
                # Append outputs
                for output in cell.get("outputs", []):
                    out_text = _extract_output(output)
                    if out_text:
                        cell_text += "\n# Output:\n" + out_text
                sections.append(Section(page=idx, text=cell_text))
            elif cell_type == "raw":
                sections.append(Section(page=idx, text=source))

        if not sections:
            sections = [Section(page=1, text="")]

        raw = "\n\n".join(s.text for s in sections)
        metadata: dict = {"file": path, "type": "ipynb", "pages": len(nb.cells)}
        if kernel:
            metadata["kernel"] = kernel
        if language:
            metadata["language"] = language

        logger.debug(
            "NotebookExtractor: %d cells (%d sections) from '%s'",
            len(nb.cells), len(sections), path,
        )
        return Document(metadata=metadata, sections=sections, tables=[], raw_text=raw)


def _extract_output(output) -> str:
    output_type = output.get("output_type", "")
    if output_type == "stream":
        return "".join(output.get("text", []))
    if output_type in ("display_data", "execute_result"):
        data = output.get("data", {})
        return data.get("text/plain", "")
    if output_type == "error":
        return f"{output.get('ename', '')}: {output.get('evalue', '')}"
    return ""
