"""
omnidoc/config.py
-----------------
Enterprise-grade runtime configuration for the OmniDoc SDK.

All settings can be overridden by environment variables so that
12-factor apps, containers, and CI pipelines work without code changes.

Environment variables (all optional):
    OMNIDOC_MAX_FILE_MB          Max file size accepted (default: 500)
    OMNIDOC_OCR_TIMEOUT          Seconds before an OCR API call times out (default: 120)
    OMNIDOC_MAX_RETRIES          Retry attempts for transient errors (default: 3)
    OMNIDOC_RETRY_BACKOFF        Base delay (seconds) between retries (default: 1.0)
    OMNIDOC_LOG_LEVEL            Python logging level name (default: WARNING)
    OMNIDOC_ENABLE_PII_MASKING   "1" / "true" to enable by default (default: 0)
    OMNIDOC_PDF_DPI              DPI used when rasterising PDF pages (default: 200)
    OMNIDOC_MAX_CHUNK_TOKENS     Default maximum tokens per semantic chunk (default: 300)
    OMNIDOC_AWS_REGION           AWS region for Textract (default: us-east-1)

Usage
-----
    from omnidoc.config import OmnidocConfig

    # Zero-config: reads from environment
    cfg = OmnidocConfig()

    # Explicit overrides (e.g. in tests):
    cfg = OmnidocConfig(max_file_mb=50, ocr_timeout=30)

    # Pass into pipeline:
    doc = extract_pdf(path, config=cfg)
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


def _env_int(key: str, default: int) -> int:
    val = os.getenv(key)
    if val is None:
        return default
    try:
        return int(val)
    except ValueError:
        logger.warning("Invalid value for %s=%r; using default %d", key, val, default)
        return default


def _env_float(key: str, default: float) -> float:
    val = os.getenv(key)
    if val is None:
        return default
    try:
        return float(val)
    except ValueError:
        logger.warning("Invalid value for %s=%r; using default %f", key, val, default)
        return default


def _env_bool(key: str, default: bool = False) -> bool:
    val = os.getenv(key, "").strip().lower()
    if not val:
        return default
    return val in ("1", "true", "yes", "on")


def _env_str(key: str, default: str) -> str:
    return os.getenv(key, default)


@dataclass
class OmnidocConfig:
    """
    Centralised, validated runtime configuration.

    All parameters have safe defaults. Construct once and pass around —
    never rely on module-level globals.
    """

    # ------------------------------------------------------------------ #
    # I/O limits
    # ------------------------------------------------------------------ #
    max_file_mb: int = field(
        default_factory=lambda: _env_int("OMNIDOC_MAX_FILE_MB", 500)
    )
    """Maximum input file size in megabytes.  Requests above this are rejected
    before any parsing to prevent OOM on oversized inputs."""

    # ------------------------------------------------------------------ #
    # OCR / cloud API settings
    # ------------------------------------------------------------------ #
    ocr_timeout: int = field(
        default_factory=lambda: _env_int("OMNIDOC_OCR_TIMEOUT", 120)
    )
    """Seconds allowed for a single OCR API call before it is aborted."""

    max_retries: int = field(
        default_factory=lambda: _env_int("OMNIDOC_MAX_RETRIES", 3)
    )
    """How many times a transient OCR/API failure is retried (1 = no retry)."""

    retry_backoff: float = field(
        default_factory=lambda: _env_float("OMNIDOC_RETRY_BACKOFF", 1.0)
    )
    """Base delay in seconds before the first retry (doubles each attempt)."""

    aws_region: str = field(
        default_factory=lambda: _env_str("OMNIDOC_AWS_REGION", "us-east-1")
    )
    """AWS region used for Textract / S3 calls."""

    # ------------------------------------------------------------------ #
    # PDF rendering
    # ------------------------------------------------------------------ #
    pdf_dpi: int = field(
        default_factory=lambda: _env_int("OMNIDOC_PDF_DPI", 200)
    )
    """DPI for rasterising PDF pages.  250–300 gives better OCR quality at
    the cost of higher memory; 150 is faster for large documents."""

    # ------------------------------------------------------------------ #
    # Chunking
    # ------------------------------------------------------------------ #
    max_chunk_tokens: int = field(
        default_factory=lambda: _env_int("OMNIDOC_MAX_CHUNK_TOKENS", 300)
    )
    """Default maximum tokens per semantic chunk before splitting."""

    # ------------------------------------------------------------------ #
    # Privacy
    # ------------------------------------------------------------------ #
    enable_pii_masking: bool = field(
        default_factory=lambda: _env_bool("OMNIDOC_ENABLE_PII_MASKING", False)
    )
    """Whether PII masking is applied automatically to every document."""

    # ------------------------------------------------------------------ #
    # Logging
    # ------------------------------------------------------------------ #
    log_level: str = field(
        default_factory=lambda: _env_str("OMNIDOC_LOG_LEVEL", "WARNING")
    )
    """Python logging level name (DEBUG / INFO / WARNING / ERROR / CRITICAL)."""

    # ------------------------------------------------------------------ #
    # post-init validation
    # ------------------------------------------------------------------ #
    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        errors = []

        if self.max_file_mb < 1:
            errors.append(f"max_file_mb must be >= 1, got {self.max_file_mb}")
        if self.ocr_timeout < 1:
            errors.append(f"ocr_timeout must be >= 1, got {self.ocr_timeout}")
        if self.max_retries < 1:
            errors.append(f"max_retries must be >= 1, got {self.max_retries}")
        if self.retry_backoff < 0:
            errors.append(f"retry_backoff must be >= 0, got {self.retry_backoff}")
        if self.pdf_dpi < 72:
            errors.append(f"pdf_dpi must be >= 72, got {self.pdf_dpi}")
        if self.max_chunk_tokens < 50:
            errors.append(f"max_chunk_tokens must be >= 50, got {self.max_chunk_tokens}")
        if self.log_level.upper() not in (
            "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"
        ):
            errors.append(f"log_level '{self.log_level}' is not a valid Python log level")

        if errors:
            raise ValueError("OmnidocConfig validation failed:\n" + "\n".join(f"  - {e}" for e in errors))

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    @property
    def max_file_bytes(self) -> int:
        return self.max_file_mb * 1024 * 1024

    def __repr__(self) -> str:
        return (
            f"OmnidocConfig("
            f"max_file_mb={self.max_file_mb}, "
            f"pdf_dpi={self.pdf_dpi}, "
            f"ocr_timeout={self.ocr_timeout}s, "
            f"max_retries={self.max_retries}, "
            f"pii={self.enable_pii_masking}, "
            f"log_level={self.log_level})"
        )


# Module-level default — import and use directly for zero-config setups
default_config = OmnidocConfig()
