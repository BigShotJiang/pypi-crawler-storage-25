"""Tests for OmnidocConfig — env-var override, validation, defaults."""
import os
import pytest


class TestOmnidocConfig:
    def test_default_construction(self):
        from omnidoc.config import OmnidocConfig
        cfg = OmnidocConfig()
        assert cfg.max_file_mb > 0
        assert cfg.pdf_dpi >= 72
        assert cfg.ocr_timeout > 0
        assert cfg.max_retries >= 1

    def test_explicit_overrides(self):
        from omnidoc.config import OmnidocConfig
        cfg = OmnidocConfig(max_file_mb=50, pdf_dpi=150, ocr_timeout=30, max_retries=2)
        assert cfg.max_file_mb == 50
        assert cfg.pdf_dpi == 150
        assert cfg.ocr_timeout == 30
        assert cfg.max_retries == 2

    def test_max_file_bytes_property(self):
        from omnidoc.config import OmnidocConfig
        cfg = OmnidocConfig(max_file_mb=10)
        assert cfg.max_file_bytes == 10 * 1024 * 1024

    def test_invalid_dpi_raises(self):
        from omnidoc.config import OmnidocConfig
        with pytest.raises(ValueError, match="pdf_dpi"):
            OmnidocConfig(pdf_dpi=10)

    def test_invalid_retries_raises(self):
        from omnidoc.config import OmnidocConfig
        with pytest.raises(ValueError, match="max_retries"):
            OmnidocConfig(max_retries=0)

    def test_invalid_log_level_raises(self):
        from omnidoc.config import OmnidocConfig
        with pytest.raises(ValueError, match="log_level"):
            OmnidocConfig(log_level="VERBOSE")

    def test_env_var_override(self, monkeypatch):
        monkeypatch.setenv("OMNIDOC_MAX_FILE_MB", "42")
        monkeypatch.setenv("OMNIDOC_PDF_DPI", "120")

        # Force re-construction (env vars read at init time)
        from omnidoc import config as cfg_module
        import importlib
        importlib.reload(cfg_module)
        from omnidoc.config import OmnidocConfig
        cfg = OmnidocConfig()
        assert cfg.max_file_mb == 42
        assert cfg.pdf_dpi == 120

    def test_repr_contains_key_fields(self):
        from omnidoc.config import OmnidocConfig
        r = repr(OmnidocConfig())
        assert "max_file_mb" in r
        assert "pdf_dpi" in r


class TestRetryUtility:
    def test_no_retry_on_success(self):
        from omnidoc.utils.retry import with_retry

        call_count = 0

        @with_retry(max_attempts=3)
        def succeed():
            nonlocal call_count
            call_count += 1
            return "ok"

        result = succeed()
        assert result == "ok"
        assert call_count == 1

    def test_retries_on_transient_error(self):
        from omnidoc.utils.retry import with_retry

        call_count = 0

        @with_retry(max_attempts=3, base_delay=0.01, exceptions=(OSError,))
        def flaky():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise OSError("transient")
            return "recovered"

        result = flaky()
        assert result == "recovered"
        assert call_count == 3

    def test_raises_after_all_attempts_exhausted(self):
        from omnidoc.utils.retry import with_retry

        @with_retry(max_attempts=2, base_delay=0.01, exceptions=(OSError,))
        def always_fails():
            raise OSError("permanent")

        with pytest.raises(OSError, match="permanent"):
            always_fails()

    def test_non_retryable_exception_propagates_immediately(self):
        from omnidoc.utils.retry import with_retry

        call_count = 0

        @with_retry(max_attempts=5, base_delay=0.01, exceptions=(OSError,))
        def wrong_error():
            nonlocal call_count
            call_count += 1
            raise ValueError("not retryable")

        with pytest.raises(ValueError):
            wrong_error()
        assert call_count == 1   # must NOT retry non-listed exception
