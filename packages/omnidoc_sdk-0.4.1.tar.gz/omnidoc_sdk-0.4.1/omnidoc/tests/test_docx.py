"""Tests for DocxExtractor (.docx)."""
import os
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")
DOCX_PATH = os.path.join(DATA, "sample.docx")

pytestmark = pytest.mark.skipif(
    not os.path.exists(DOCX_PATH),
    reason="sample.docx not present in test data",
)


# ---------------------------------------------------------------------------
# Happy-path
# ---------------------------------------------------------------------------

def test_docx_basic():
    from omnidoc.extractors.office.docx import DocxExtractor
    doc = DocxExtractor().extract(DOCX_PATH)

    assert doc is not None
    assert doc.metadata["type"] == "docx"
    assert isinstance(doc.raw_text, str)
    assert len(doc.raw_text) > 0


def test_docx_has_sections():
    from omnidoc.extractors.office.docx import DocxExtractor
    doc = DocxExtractor().extract(DOCX_PATH)

    assert len(doc.sections) >= 1
    for sec in doc.sections:
        assert isinstance(sec.text, str)
        assert sec.page >= 1


def test_docx_tables_are_valid():
    from omnidoc.extractors.office.docx import DocxExtractor
    doc = DocxExtractor().extract(DOCX_PATH)

    for tbl in doc.tables:
        assert isinstance(tbl.headers, list)
        assert isinstance(tbl.rows, list)
        # All cells must be strings
        for cell in tbl.headers:
            assert isinstance(cell, str)
        for row in tbl.rows:
            for cell in row:
                assert isinstance(cell, str)


def test_docx_via_loader():
    from omnidoc.loader.load import load_document
    doc = load_document(DOCX_PATH)

    assert len(doc.chunks) > 0
    for chunk in doc.chunks:
        assert "text" in chunk
        assert "confidence" in chunk


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------

def test_docx_missing_file_raises():
    from omnidoc.extractors.office.docx import DocxExtractor
    with pytest.raises(FileNotFoundError):
        DocxExtractor().extract("/nonexistent/document.docx")


def test_docx_corrupt_raises():
    import tempfile
    from omnidoc.extractors.office.docx import DocxExtractor

    with tempfile.NamedTemporaryFile(suffix=".docx", delete=False, mode="wb") as f:
        f.write(b"this is not a valid docx file binary content xyz")
        path = f.name

    try:
        with pytest.raises((ValueError, Exception)):
            DocxExtractor().extract(path)
    finally:
        os.unlink(path)
