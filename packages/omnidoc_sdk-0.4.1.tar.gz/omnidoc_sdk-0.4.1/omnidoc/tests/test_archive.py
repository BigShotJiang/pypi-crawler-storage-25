"""Tests for ArchiveExtractor (.zip)."""
import os
import shutil
import tempfile
import zipfile
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")
ZIP_PATH = os.path.join(DATA, "archive.zip")


# ---------------------------------------------------------------------------
# Happy-path
# ---------------------------------------------------------------------------

def test_archive_basic():
    from omnidoc.extractors.archive.extractor import ArchiveExtractor
    result = ArchiveExtractor().extract(ZIP_PATH)

    assert isinstance(result, dict)
    assert result["type"] == "archive"
    assert isinstance(result["files"], list)


def test_archive_files_exist():
    from omnidoc.extractors.archive.extractor import ArchiveExtractor
    result = ArchiveExtractor().extract(ZIP_PATH)

    for path in result["files"]:
        assert os.path.isfile(path), f"Extracted file does not exist: {path}"


def test_archive_temp_cleanup_on_error():
    """Even if downstream processing fails the temp dir is cleaned up."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    # Create a zip that will extract successfully
    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as f:
        zp = f.name

    with zipfile.ZipFile(zp, "w") as z:
        z.writestr("hello.txt", "Hello World")

    extractor = ArchiveExtractor()
    result = extractor.extract(zp)
    extracted_paths = result["files"]

    # Verify files were created during extraction
    assert len(extracted_paths) > 0
    os.unlink(zp)


# ---------------------------------------------------------------------------
# Security — path traversal
# ---------------------------------------------------------------------------

def test_archive_path_traversal_blocked():
    """Zip slip attack must be silently skipped, not extracted."""
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as f:
        malicious_zip = f.name

    # Craft a zip with a path traversal entry
    with zipfile.ZipFile(malicious_zip, "w") as z:
        info = zipfile.ZipInfo("../../../evil.txt")
        z.writestr(info, "pwned")
        z.writestr("safe.txt", "safe content")

    try:
        result = ArchiveExtractor().extract(malicious_zip)
        # The evil.txt entry must have been skipped
        for path in result["files"]:
            assert "evil.txt" not in path
            assert ".." not in path
    finally:
        os.unlink(malicious_zip)


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------

def test_archive_missing_file_raises():
    from omnidoc.extractors.archive.extractor import ArchiveExtractor
    with pytest.raises(FileNotFoundError):
        ArchiveExtractor().extract("/nonexistent/file.zip")


def test_archive_not_zip_raises():
    from omnidoc.extractors.archive.extractor import ArchiveExtractor

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False, mode="wb") as f:
        f.write(b"this is not a zip file")
        path = f.name

    try:
        with pytest.raises(ValueError, match="valid ZIP"):
            ArchiveExtractor().extract(path)
    finally:
        os.unlink(path)
