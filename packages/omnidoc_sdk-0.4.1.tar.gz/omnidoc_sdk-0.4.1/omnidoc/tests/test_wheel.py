"""Smoke tests — verify package structure and public API surface."""
import pkgutil
import pytest


def test_all_expected_submodules_present():
    import omnidoc
    modules = {m.name for m in pkgutil.iter_modules(omnidoc.__path__)}
    required = {"pdf", "cli", "adapters", "core", "extractors", "loader",
                "ocr", "utils", "layout", "postprocess"}
    missing = required - modules
    assert not missing, f"Missing submodules: {missing}"


def test_public_api_importable():
    from omnidoc.pdf.pipeline import extract_pdf
    from omnidoc.loader.load import load_document
    from omnidoc.config import OmnidocConfig
    from omnidoc.utils.retry import with_retry
    from omnidoc.utils.logging_config import configure_logging
    from omnidoc.utils.serialize import document_to_json, document_to_toon
    from omnidoc.core.document import Document, Section, Table
    from omnidoc.ocr.tesseract import TesseractOCR


def test_all_extractors_importable():
    from omnidoc.extractors.text.extractor import TextExtractor
    from omnidoc.extractors.office.docx import DocxExtractor
    from omnidoc.extractors.office.pptx import PPTXExtractor
    from omnidoc.extractors.office.spreadsheet import SpreadsheetExtractor
    from omnidoc.extractors.structured.json_xml import JSONExtractor, XMLExtractor
    from omnidoc.extractors.archive.extractor import ArchiveExtractor
    from omnidoc.extractors.image.extractor import ImageExtractor
    from omnidoc.extractors.markdown.extractor import MarkdownExtractor


def test_ocr_engines_importable():
    from omnidoc.ocr.base import OCREngine
    from omnidoc.ocr.tesseract import TesseractOCR
    # Cloud engines — only import the class, don't instantiate (needs credentials)
    from omnidoc.ocr.aws_textract import TextractOCR
    from omnidoc.ocr.azure_form_recognizer import AzureFormRecognizer


def test_adapters_importable():
    pytest.importorskip("langchain")
    from omnidoc.adapters.langchain import to_langchain

    pytest.importorskip("llama_index")
    from omnidoc.adapters.llamaindex import to_llamaindex


def test_document_dataclass_fields():
    from omnidoc.core.document import Document, Section, Table
    sec = Section(page=1, text="test")
    tbl = Table(page=1, headers=["A", "B"], rows=[["1", "2"]])
    doc = Document(
        metadata={"file": "x.pdf"},
        sections=[sec],
        tables=[tbl],
        raw_text="test",
    )
    assert doc.sections[0].page == 1
    assert doc.tables[0].headers == ["A", "B"]
    assert doc.chunks == []   # RAG chunking lives in omnidoc-rag
