"""Tests for TextExtractor (.txt)."""
import os
import tempfile
import pytest

DATA = os.path.join(os.path.dirname(__file__), "data")


# ---------------------------------------------------------------------------
# Happy-path
# ---------------------------------------------------------------------------

def test_text_basic():
    from omnidoc.extractors.text.extractor import TextExtractor
    doc = TextExtractor().extract(os.path.join(DATA, "sample.txt"))

    assert doc is not None
    assert isinstance(doc.raw_text, str)
    assert len(doc.raw_text) > 10
    assert len(doc.sections) >= 1
    assert doc.sections[0].page == 1
    assert doc.metadata["type"] == "text"


def test_text_chunks_present():
    from omnidoc.loader.load import load_document
    doc = load_document(os.path.join(DATA, "sample.txt"))

    assert hasattr(doc, "chunks")
    assert len(doc.chunks) > 0

    for chunk in doc.chunks:
        assert "text" in chunk
        assert "intent" in chunk
        assert "confidence" in chunk
        assert isinstance(chunk["confidence"], float)
        assert 0.0 < chunk["confidence"] <= 1.0


def test_text_empty_tables():
    from omnidoc.extractors.text.extractor import TextExtractor
    doc = TextExtractor().extract(os.path.join(DATA, "sample.txt"))
    assert doc.tables == []


# ---------------------------------------------------------------------------
# Encoding fallback
# ---------------------------------------------------------------------------

def test_text_latin1_encoding():
    """TextExtractor must not crash on latin-1 encoded files."""
    from omnidoc.extractors.text.extractor import TextExtractor

    with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
        f.write("Ren\xe9 Caf\xe9 \xa9 2024".encode("latin-1"))
        path = f.name

    try:
        doc = TextExtractor().extract(path)
        assert len(doc.raw_text) > 0
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------

def test_text_missing_file():
    from omnidoc.extractors.text.extractor import TextExtractor
    with pytest.raises(FileNotFoundError):
        TextExtractor().extract("/nonexistent/path/file.txt")
