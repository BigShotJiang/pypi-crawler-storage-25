"""
omnidoc/pdf/ocr_tables.py
-------------------------
Detect and extract tables from rasterised PDF pages using OpenCV
line detection + Tesseract OCR.

Returns an empty list on any failure so callers never crash.
"""
import logging
from typing import List

logger = logging.getLogger(__name__)

# Minimum area (px²) to consider a contour a real table cell
_MIN_TABLE_AREA = 500


def extract_ocr_tables(image) -> List[List[str]]:
    """
    Detect table regions in a PIL image and OCR each region.

    Parameters
    ----------
    image: PIL.Image — a single rasterised page.

    Returns
    -------
    List of row-lists (each row is a list of strings), one entry per
    detected table region. Returns [] if nothing found or on any error.
    """
    try:
        import cv2
        import numpy as np
        import pytesseract
    except ImportError as exc:
        logger.debug("extract_ocr_tables: required library not installed (%s) — skipping", exc)
        return []

    try:
        img_array = np.array(image.convert("RGB"))
        gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
    except Exception as exc:
        logger.warning("extract_ocr_tables: image conversion failed: %s", exc)
        return []

    try:
        thresh = cv2.adaptiveThreshold(
            gray, 255,
            cv2.ADAPTIVE_THRESH_MEAN_C,
            cv2.THRESH_BINARY_INV, 15, 10,
        )

        h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 1))
        v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 40))

        horizontal = cv2.morphologyEx(thresh.copy(), cv2.MORPH_OPEN, h_kernel)
        vertical   = cv2.morphologyEx(thresh.copy(), cv2.MORPH_OPEN, v_kernel)

        table_mask = cv2.add(horizontal, vertical)
        contours, _ = cv2.findContours(
            table_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
    except Exception as exc:
        logger.warning("extract_ocr_tables: OpenCV pipeline failed: %s", exc)
        return []

    tables: List[List[str]] = []

    for cnt in contours:
        try:
            x, y, w, h = cv2.boundingRect(cnt)

            if w * h < _MIN_TABLE_AREA:
                continue

            # Crop from the original PIL image (not the numpy array)
            roi = image.crop((x, y, x + w, y + h))
            text = pytesseract.image_to_string(roi, config="--psm 6")
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            if lines:
                tables.append(lines)
        except Exception as exc:
            logger.warning("extract_ocr_tables: skipping table region: %s", exc)

    logger.debug("extract_ocr_tables: detected %d table regions", len(tables))
    return tables
