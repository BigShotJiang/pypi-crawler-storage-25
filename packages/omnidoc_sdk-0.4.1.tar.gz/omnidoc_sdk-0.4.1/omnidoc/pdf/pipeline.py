# omnidoc/pdf/pipeline.py
# -------------------------------------------------
# Suppress noisy third-party loggers at import time.
# Use OMNIDOC_LOG_LEVEL=DEBUG to restore them.
# -------------------------------------------------
import logging
import os
import warnings
from typing import Any, Dict, Optional, Union

warnings.filterwarnings("ignore")
for _noisy in ("pdfminer", "pdfplumber", "pypdf", "PIL"):
    logging.getLogger(_noisy).setLevel(logging.CRITICAL)

from omnidoc.pdf.detector import is_scanned_pdf
from omnidoc.pdf.text import extract_text
from omnidoc.pdf.tables import extract_tables
from omnidoc.pdf.ocr_tables import extract_ocr_tables
from omnidoc.pdf.normalize import build_document

from omnidoc.ocr.base import OCREngine
from omnidoc.ocr.tesseract import TesseractOCR

from omnidoc.utils.text import clean_text
from omnidoc.layout.ordering import order_blocks
from omnidoc.layout.utils import text_blocks_only

logger = logging.getLogger(__name__)

_VALID_OUTPUT_FORMATS = frozenset({"document", "json", "toon"})


def extract_pdf(
    path: str,
    *,
    ocr_engine: Optional[OCREngine] = None,
    enable_layout: bool = True,
    enable_pii_masking: bool = False,
    enable_cloud_ocr: bool = False,
    enable_vlm: bool = False,
    output_format: str = "document",   # document | json | toon
    config=None,                        # Optional[OmnidocConfig]
) -> Union[Dict[str, Any], object]:
    """
    Enterprise-grade PDF extraction pipeline.

    Returns a Document object (default), a RAG-ready JSON dict, or TOON format.
    For RAG chunking, pipe the Document into omnidoc-rag.

    Parameters
    ----------
    path:               Absolute or relative path to a PDF file.
    ocr_engine:         Custom OCR engine; auto-selected when None.
    enable_layout:      Use layout ML for reading-order detection.
    enable_pii_masking: Redact PII from raw_text (requires [privacy] extra).
    enable_cloud_ocr:   Use AWS Textract for scanned PDFs.
    enable_vlm:         Use Donut VLM for scanned PDFs.
    output_format:      "document" | "json" | "toon"
    config:             OmnidocConfig instance; uses default_config when None.
    """
    from omnidoc.config import OmnidocConfig, default_config
    cfg: OmnidocConfig = config if config is not None else default_config

    # ------------------------------------------------------------------
    # Input validation
    # ------------------------------------------------------------------
    if not isinstance(path, str) or not path.strip():
        raise ValueError("path must be a non-empty string")

    if not os.path.exists(path):
        raise FileNotFoundError(f"PDF not found: {path}")

    if not os.path.isfile(path):
        raise ValueError(f"Path is not a file: {path}")

    file_size = os.path.getsize(path)
    if file_size > cfg.max_file_bytes:
        raise ValueError(
            f"File size {file_size / 1024 / 1024:.1f} MB exceeds limit "
            f"{cfg.max_file_mb} MB for '{path}'"
        )

    if output_format not in _VALID_OUTPUT_FORMATS:
        raise ValueError(
            f"Invalid output_format '{output_format}'. "
            f"Expected one of: {sorted(_VALID_OUTPUT_FORMATS)}"
        )

    logger.info(
        "extract_pdf: starting — path='%s' size=%.1fKB layout=%s cloud_ocr=%s vlm=%s",
        path, file_size / 1024, enable_layout, enable_cloud_ocr, enable_vlm,
    )

    sections: list = []
    tables: list = []

    # ------------------------------------------------------------------
    # Scan detection
    # ------------------------------------------------------------------
    try:
        scanned = is_scanned_pdf(path)
    except Exception as exc:
        logger.warning("extract_pdf: scan detection failed (%s); assuming digital", exc)
        scanned = False

    logger.debug("extract_pdf: scanned=%s", scanned)

    # ------------------------------------------------------------------
    # OCR routing
    # ------------------------------------------------------------------
    if scanned and enable_cloud_ocr:
        from omnidoc.ocr.aws_textract import TextractOCR
        ocr_engine = TextractOCR(region=cfg.aws_region, timeout=cfg.ocr_timeout)
    else:
        ocr_engine = ocr_engine or TesseractOCR()

    # ==================================================================
    # 1. DIGITAL PDF — SIMPLE (no layout)
    # ==================================================================
    if not scanned and not enable_layout:
        logger.debug("extract_pdf: branch=digital_simple")
        try:
            for sec in extract_text(path):
                sections.append({"page": sec["page"], "text": clean_text(sec["text"])})
            tables = extract_tables(path)
        except Exception as exc:
            logger.error("extract_pdf: text/table extraction failed: %s", exc, exc_info=True)
            raise

    # ==================================================================
    # 2. DIGITAL PDF — LAYOUT AWARE
    # ==================================================================
    elif not scanned and enable_layout:
        logger.debug("extract_pdf: branch=digital_layout dpi=%d", cfg.pdf_dpi)
        try:
            from pdf2image import convert_from_path
            from omnidoc.layout.detector import detect_layout
            import pytesseract

            images = convert_from_path(path, dpi=cfg.pdf_dpi)
            for i, image in enumerate(images):
                text = ""
                try:
                    blocks = detect_layout(image)
                    if blocks:
                        blocks = order_blocks(text_blocks_only(blocks))
                        text = "\n".join(b.text for b in blocks)
                except Exception as exc:
                    logger.warning("extract_pdf: layout failed on page %d: %s", i + 1, exc)

                if not text.strip():
                    text = pytesseract.image_to_string(image)

                sections.append({"page": i + 1, "text": clean_text(text)})

                try:
                    ocr_tables = extract_ocr_tables(image)
                    if ocr_tables:
                        tables.append({"page": i + 1, "rows": ocr_tables})
                except Exception as exc:
                    logger.warning("extract_pdf: OCR table failed on page %d: %s", i + 1, exc)

        except Exception as exc:
            logger.error("extract_pdf: layout pipeline failed: %s", exc, exc_info=True)
            raise

    # ==================================================================
    # 3. SCANNED / FLATTENED PDF
    # ==================================================================
    else:
        logger.debug("extract_pdf: branch=scanned")
        try:
            import pytesseract
            from omnidoc.layout.detector import detect_layout

            for page in ocr_engine.extract(path):
                text = page.get("text", "")

                if enable_vlm and "image" in page:
                    try:
                        from omnidoc.layout.donut import DonutExtractor
                        text = DonutExtractor().extract(page["image"])
                    except Exception as exc:
                        logger.warning("extract_pdf: VLM failed on page %s: %s", page.get("page"), exc)

                elif enable_layout and "image" in page:
                    try:
                        blocks = detect_layout(page["image"])
                        if blocks:
                            blocks = order_blocks(text_blocks_only(blocks))
                            text = "\n".join(b.text for b in blocks)
                        else:
                            text = pytesseract.image_to_string(page["image"])
                        ocr_tables = extract_ocr_tables(page["image"])
                        if ocr_tables:
                            tables.append({"page": page["page"], "rows": ocr_tables})
                    except Exception as exc:
                        logger.warning("extract_pdf: scanned layout failed on page %s: %s", page.get("page"), exc)

                sections.append({"page": page["page"], "text": clean_text(text)})

        except Exception as exc:
            logger.error("extract_pdf: scanned pipeline failed: %s", exc, exc_info=True)
            raise

    # ==================================================================
    # BUILD DOCUMENT
    # ==================================================================
    doc = build_document(path, sections, tables)
    doc.metadata.update({
        "source_type": "pdf",
        "pipeline": "pdf",
        "scanned": scanned,
    })

    # Slide → report normalization
    from omnidoc.postprocess.slide_normalizer import normalize_slide_sections
    doc.sections = normalize_slide_sections(doc.sections)
    doc.raw_text = "\n\n".join(sec.text for sec in doc.sections)

    # PII masking (optional)
    if enable_pii_masking or cfg.enable_pii_masking:
        try:
            from omnidoc.privacy.pii import mask_pii
            doc.raw_text = mask_pii(doc.raw_text)
        except Exception as exc:
            logger.error("extract_pdf: PII masking failed: %s", exc, exc_info=True)
            raise

    logger.info(
        "extract_pdf: done — %d sections, %d tables",
        len(doc.sections), len(doc.tables),
    )

    # Output format
    from omnidoc.utils.serialize import document_to_json, document_to_toon
    if output_format == "json":
        return document_to_json(doc)
    if output_format == "toon":
        return document_to_toon(doc)
    return doc
