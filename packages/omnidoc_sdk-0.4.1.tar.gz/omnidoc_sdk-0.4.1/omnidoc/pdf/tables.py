import logging
from typing import List

from omnidoc.core.document import Table

logger = logging.getLogger(__name__)


def extract_tables(path: str) -> List[Table]:
    """
    Extract tables from a digital PDF using camelot.

    Returns an empty list (never raises) if camelot is not installed,
    the PDF has no lattice tables, or extraction fails for any reason.
    """
    try:
        import camelot
    except ImportError:
        logger.debug("extract_tables: camelot not installed — skipping table extraction")
        return []

    try:
        raw_tables = camelot.read_pdf(path, pages="all", flavor="lattice")
    except Exception as exc:
        logger.warning("extract_tables: camelot failed on '%s': %s", path, exc)
        return []

    result: List[Table] = []

    for t in raw_tables:
        try:
            df = t.df
            if df.empty or len(df) < 1:
                continue

            headers = df.iloc[0].astype(str).tolist()
            rows = df.iloc[1:].astype(str).values.tolist() if len(df) > 1 else []

            result.append(Table(
                page=t.page,
                headers=headers,
                rows=rows,
            ))
        except Exception as exc:
            logger.warning("extract_tables: skipping malformed table in '%s': %s", path, exc)

    logger.debug("extract_tables: found %d tables in '%s'", len(result), path)
    return result
