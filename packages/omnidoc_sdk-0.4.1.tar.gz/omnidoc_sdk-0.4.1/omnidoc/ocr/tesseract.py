import logging
import os
import signal
import sys
from contextlib import contextmanager
from typing import Any, Dict, List, Optional

import pytesseract
from pdf2image import convert_from_path

from omnidoc.ocr.base import OCREngine

logger = logging.getLogger(__name__)

# Default per-page OCR timeout (seconds).  Override via TesseractOCR(timeout=N).
_DEFAULT_TIMEOUT = 60


@contextmanager
def _ocr_timeout(seconds: int):
    """SIGALRM-based timeout for blocking pytesseract calls (Unix only)."""
    if sys.platform == "win32" or seconds <= 0:
        yield
        return

    def _handler(signum, frame):
        raise TimeoutError(f"Tesseract OCR timed out after {seconds}s")

    old = signal.signal(signal.SIGALRM, _handler)
    signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)


class TesseractOCR(OCREngine):
    """
    Local OCR engine using Tesseract.

    Parameters
    ----------
    dpi:        Rasterisation resolution (higher = better quality, more memory).
    timeout:    Per-page OCR timeout in seconds. 0 = unlimited.
    lang:       Tesseract language code(s), e.g. "eng", "eng+fra".
    """

    def __init__(
        self,
        dpi: int = 200,
        timeout: int = _DEFAULT_TIMEOUT,
        lang: Optional[str] = None,
    ) -> None:
        self._dpi = dpi
        self._timeout = timeout
        self._lang = lang

    def extract(self, file_path: str) -> List[Dict[str, Any]]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"TesseractOCR: file not found: {file_path}")

        logger.info("TesseractOCR: rasterising '%s' at %d DPI", file_path, self._dpi)

        try:
            images = convert_from_path(file_path, dpi=self._dpi)
        except Exception as exc:
            raise RuntimeError(
                f"TesseractOCR: failed to rasterise '{file_path}': {exc}"
            ) from exc

        results: List[Dict[str, Any]] = []

        for i, image in enumerate(images):
            page_num = i + 1
            text = self._ocr_page(image, page_num)
            results.append({"page": page_num, "text": text, "image": image})

        logger.debug("TesseractOCR: completed %d pages for '%s'", len(results), file_path)
        return results

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------

    def _ocr_page(self, image, page_num: int) -> str:
        kwargs = {"lang": self._lang} if self._lang else {}
        try:
            with _ocr_timeout(self._timeout):
                return pytesseract.image_to_string(image, **kwargs)
        except TimeoutError:
            logger.warning(
                "TesseractOCR: page %d timed out after %ds — returning empty text",
                page_num,
                self._timeout,
            )
            return ""
        except Exception as exc:
            logger.warning(
                "TesseractOCR: page %d OCR failed (%s) — returning empty text",
                page_num,
                exc,
            )
            return ""
