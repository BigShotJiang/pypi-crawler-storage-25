import logging
import os
from typing import Any, Dict, List, Optional

import boto3
from botocore.config import Config as BotocoreConfig

from omnidoc.ocr.base import OCREngine
from omnidoc.utils.retry import with_retry

logger = logging.getLogger(__name__)

# Textract-specific transient errors worth retrying
try:
    from botocore.exceptions import ClientError as _BotoClientError
    _TRANSIENT_AWS = (
        _BotoClientError,
        ConnectionError,
        TimeoutError,
        OSError,
    )
except ImportError:
    _TRANSIENT_AWS = (ConnectionError, TimeoutError, OSError)  # type: ignore


class TextractOCR(OCREngine):
    """
    AWS Textract OCR engine with:
    - Configurable timeout and region
    - Exponential-backoff retry on transient errors
    - Defensive file-size and existence checks
    - Per-page confidence aggregation
    """

    # Textract synchronous API limit: 10 MB
    _MAX_SYNC_BYTES = 10 * 1024 * 1024

    def __init__(
        self,
        region: str = "us-east-1",
        timeout: int = 120,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
    ) -> None:
        boto_cfg = BotocoreConfig(
            connect_timeout=timeout,
            read_timeout=timeout,
            retries={"max_attempts": 1},   # We manage retries ourselves
        )

        self.client = boto3.client(
            "textract",
            region_name=region,
            config=boto_cfg,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )
        self._max_retries = max_retries
        self._retry_backoff = retry_backoff

        logger.debug("TextractOCR: initialised region=%s timeout=%ds", region, timeout)

    def extract(self, file_path: str) -> List[Dict[str, Any]]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"TextractOCR: file not found: {file_path}")

        file_size = os.path.getsize(file_path)
        if file_size > self._MAX_SYNC_BYTES:
            raise ValueError(
                f"TextractOCR: file size {file_size / 1024 / 1024:.1f} MB exceeds "
                f"synchronous API limit of 10 MB for '{file_path}'. "
                "Use the asynchronous StartDocumentAnalysis API for larger files."
            )

        with open(file_path, "rb") as fh:
            document_bytes = fh.read()

        logger.info("TextractOCR: calling AnalyzeDocument for '%s'", file_path)
        response = self._call_textract(document_bytes)

        return self._parse_response(response)

    # ------------------------------------------------------------------
    # private helpers
    # ------------------------------------------------------------------

    def _call_textract(self, document_bytes: bytes) -> Dict[str, Any]:
        """Call Textract with retry/backoff."""

        @with_retry(
            max_attempts=self._max_retries,
            base_delay=self._retry_backoff,
            exceptions=_TRANSIENT_AWS,
        )
        def _inner() -> Dict[str, Any]:
            return self.client.analyze_document(
                Document={"Bytes": document_bytes},
                FeatureTypes=["TABLES", "FORMS"],
            )

        return _inner()

    @staticmethod
    def _parse_response(response: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert Textract blocks into per-page dicts."""
        pages: Dict[int, List[str]] = {}
        page_confidences: Dict[int, List[float]] = {}

        for block in response.get("Blocks", []):
            page_num: int = block.get("Page", 1)
            confidence: Optional[float] = block.get("Confidence")

            if block["BlockType"] == "LINE":
                pages.setdefault(page_num, []).append(block.get("Text", ""))

            if confidence is not None:
                page_confidences.setdefault(page_num, []).append(confidence)

        results: List[Dict[str, Any]] = []
        for page_num in sorted(pages):
            lines = pages[page_num]
            confidences = page_confidences.get(page_num, [])
            avg_conf = round(sum(confidences) / len(confidences), 2) if confidences else 0.0

            results.append({
                "page": page_num,
                "text": "\n".join(lines),
                "confidence": avg_conf,
            })

        logger.debug("TextractOCR: parsed %d pages from response", len(results))
        return results
