"""
omnidoc/ocr/azure_form_recognizer.py
--------------------------------------
Azure AI Document Intelligence (formerly Form Recognizer) OCR engine.

Requires the cloud-ocr extra:
    pip install "omnidoc-sdk[cloud-ocr]"

Environment variables (all optional — can be passed as constructor args):
    AZURE_FORM_ENDPOINT   e.g. https://my-resource.cognitiveservices.azure.com/
    AZURE_FORM_KEY        32-character API key

Usage
-----
    from omnidoc.ocr.azure_form_recognizer import AzureFormRecognizer

    ocr = AzureFormRecognizer(
        endpoint=os.environ["AZURE_FORM_ENDPOINT"],
        api_key=os.environ["AZURE_FORM_KEY"],
        timeout=120,
        max_retries=3,
    )
    pages = ocr.extract("scanned_document.pdf")

    for page in pages:
        print(page["page"], page["text"][:200])
"""

import logging
import os
from typing import Any, Dict, List, Optional

from omnidoc.ocr.base import OCREngine
from omnidoc.utils.retry import with_retry

logger = logging.getLogger(__name__)

# Azure transient error types — populated lazily so import never hard-fails
_TRANSIENT: tuple = (ConnectionError, TimeoutError, OSError)


def _get_transient_exceptions() -> tuple:
    """Lazily include Azure SDK exceptions if available."""
    global _TRANSIENT
    try:
        from azure.core.exceptions import ServiceRequestError, ServiceResponseError
        _TRANSIENT = (ServiceRequestError, ServiceResponseError, ConnectionError, TimeoutError, OSError)
    except ImportError:
        pass
    return _TRANSIENT


class AzureFormRecognizer(OCREngine):
    """
    Azure AI Document Intelligence OCR engine.

    Parameters
    ----------
    endpoint:    Azure resource endpoint URL.
                 Falls back to AZURE_FORM_ENDPOINT env var.
    api_key:     API key for key-based auth.
                 Falls back to AZURE_FORM_KEY env var.
    timeout:     Request timeout in seconds (default: 120).
    max_retries: Retry attempts on transient errors (default: 3).
    retry_backoff: Base delay between retries in seconds (default: 1.0).
    model_id:    Azure model to use (default: "prebuilt-read" for general OCR).
                 Use "prebuilt-layout" for tables + layout, "prebuilt-invoice" etc.
    """

    def __init__(
        self,
        endpoint: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: int = 120,
        max_retries: int = 3,
        retry_backoff: float = 1.0,
        model_id: str = "prebuilt-read",
    ) -> None:
        self._endpoint = endpoint or os.getenv("AZURE_FORM_ENDPOINT", "")
        self._api_key = api_key or os.getenv("AZURE_FORM_KEY", "")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_backoff = retry_backoff
        self._model_id = model_id

        if not self._endpoint:
            raise ValueError(
                "AzureFormRecognizer: endpoint is required. "
                "Pass endpoint= or set AZURE_FORM_ENDPOINT."
            )
        if not self._api_key:
            raise ValueError(
                "AzureFormRecognizer: api_key is required. "
                "Pass api_key= or set AZURE_FORM_KEY."
            )

        self._client = self._build_client()
        logger.debug(
            "AzureFormRecognizer: initialised endpoint=%s model=%s timeout=%ds",
            self._endpoint,
            self._model_id,
            self._timeout,
        )

    def extract(self, file_path: str) -> List[Dict[str, Any]]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"AzureFormRecognizer: file not found: {file_path}")

        logger.info(
            "AzureFormRecognizer: analysing '%s' with model '%s'",
            file_path,
            self._model_id,
        )

        with open(file_path, "rb") as fh:
            document_bytes = fh.read()

        result = self._analyse(document_bytes)
        pages = self._parse_result(result)

        logger.debug(
            "AzureFormRecognizer: extracted %d pages from '%s'",
            len(pages),
            file_path,
        )
        return pages

    # ------------------------------------------------------------------
    # private helpers
    # ------------------------------------------------------------------

    def _build_client(self):
        try:
            from azure.ai.formrecognizer import DocumentAnalysisClient
            from azure.core.credentials import AzureKeyCredential
        except ImportError as exc:
            raise ImportError(
                "Azure Form Recognizer support requires the cloud-ocr extra.\n"
                "Install with: pip install 'omnidoc-sdk[cloud-ocr]'"
            ) from exc

        from azure.ai.formrecognizer import DocumentAnalysisClient
        from azure.core.credentials import AzureKeyCredential

        return DocumentAnalysisClient(
            endpoint=self._endpoint.rstrip("/"),
            credential=AzureKeyCredential(self._api_key),
        )

    def _analyse(self, document_bytes: bytes) -> Any:
        """Submit document to Azure and wait for result, with retry."""

        @with_retry(
            max_attempts=self._max_retries,
            base_delay=self._retry_backoff,
            exceptions=_get_transient_exceptions(),
        )
        def _inner() -> Any:
            poller = self._client.begin_analyze_document(
                self._model_id,
                document=document_bytes,
            )
            return poller.result()

        return _inner()

    @staticmethod
    def _parse_result(result: Any) -> List[Dict[str, Any]]:
        """Convert Azure result object into per-page dicts."""
        pages: List[Dict[str, Any]] = []

        if not result or not hasattr(result, "pages"):
            return pages

        for azure_page in result.pages:
            page_num: int = getattr(azure_page, "page_number", 1)
            lines = getattr(azure_page, "lines", []) or []

            texts = []
            confidences = []

            for line in lines:
                content = getattr(line, "content", "") or ""
                if content.strip():
                    texts.append(content)
                # Azure lines may carry word-level confidence
                for word in getattr(line, "words", []) or []:
                    conf = getattr(word, "confidence", None)
                    if conf is not None:
                        confidences.append(float(conf))

            avg_conf = round(sum(confidences) / len(confidences), 3) if confidences else 0.0

            pages.append({
                "page": page_num,
                "text": "\n".join(texts),
                "confidence": avg_conf,
            })

        return pages
