"""
OmniDoc SDK — Enterprise document extraction.

Converts any file (PDF, DOCX, XLSX, HTML, EPUB, EML, images, code, audio/video, …)
into a clean Document object ready for downstream processing.

For RAG chunking and streaming pipelines, install:
    pip install omnidoc-rag

Quick start:
    from omnidoc.loader.load import load_document
    doc = load_document("report.pdf")
    print(doc.raw_text)
"""

__all__ = ["extract_pdf", "load_document"]


def extract_pdf(*args, **kwargs):
    from omnidoc.pdf.pipeline import extract_pdf as _fn
    return _fn(*args, **kwargs)


def load_document(*args, **kwargs):
    from omnidoc.loader.load import load_document as _fn
    return _fn(*args, **kwargs)
