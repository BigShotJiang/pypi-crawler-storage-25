def 打印(内容,结尾符='\n',开始符='',间隔符=' '):
    try:
        print(开始符,end='')
        print(内容,end=结尾符,sep=间隔符)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 重复输出(内容='',限制次数=1,结尾符='\n',开始符='',间隔符=' '):
    try:
        cishu = 限制次数
        while True:
            cishu = cishu - 1
            if cishu == -1:
                break
            print(开始符,end='')
            print(内容,end=结尾符,sep=间隔符)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 阶乘(数字):
    try:
        for i in range(数字-1):
            数字 = 数字 * (i+1)
        print(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 次方算法(数字,次方数):
    try:
        原数字 = 数字
        for i in range(次方数-1):
            数字 = 数字 * 原数字
        print(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 开根号(次方根,数字):
    try:
        结果 = 数字 ** (1/次方根)
        打印(结果)
        return 结果
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 苏醒玩家(大小=(800,800),颜色=(0,0,0),名称=''):
    try:
        import pygame
        import random
        import math
        pygame.init()
        pygame.display.set_caption(名称)
        screen=pygame.display.set_mode(大小)
        screen.fill(颜色)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转八进制(数字):
    try:
        return oct(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转十六进制(数字):
    try:
        return hex(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 加密(原文, 密钥=123):
    try:
        密文 = []
        for 字符 in 原文:
            数字 = ord(字符)
            新数字 = (数字 * 密钥 + 7) % 65536
            密文.append(str(新数字))
        return "%".join(密文)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 解密(密文, 密钥=123):
    try:
        结果 = []
        for 段 in 密文.split("%"):
            if not 段:
                continue
            数字 = int(段)
            原数字 = (数字 - 7) * pow(密钥, -1, 65536) % 65536
            结果.append(chr(原数字))
        return "".join(结果)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 苏醒乌龟(别名='乌龟',颜色='白'):
    try:
        乌打初 = 'turtle'
        模块 = __import__(乌打初)
        screen = 模块.Screen()
        if 颜色 == '红':
            模块.bgcolor('red')
        if 颜色 == '橙':
            模块.bgcolor('orange')
        if 颜色 == '黄':
            模块.bgcolor('yellow')
        if 颜色 == '绿':
            模块.bgcolor('green')
        if 颜色 == '青':
            模块.bgcolor('cyan')
        if 颜色 == '蓝':
            模块.bgcolor('blue')
        if 颜色 == '紫':
            模块.bgcolor('purple')
        if 颜色 == '白':
            模块.bgcolor('white')
        if 颜色 == '灰':
            模块.bgcolor('grey')
        if 颜色 == '黑':
            模块.bgcolor('black')
        if 颜色 == '粉':
            模块.bgcolor('pink')
        class 我的乌龟:
            def __init__(self):
                self._y = 模块.Turtle()
                self._y.shape('turtle')
            def 前进(self,距离):
                try:
                    self._y.forward(距离)
                except:
                    print('错误')
            def 左转(self,角度):
                try:
                    self._y.lt(角度)
                except:
                    print('错误')
            def 右转(self,角度):
                try:
                    self._y.rt(角度)
                except:
                    print('错误')
            def 后退(self,距离):
                try:
                    self._y.bk(距离)
                except:
                    print('错误')
            def 粗细(self,粗细):
                try:
                    self._y.pensize(粗细)
                except:
                    print('错误')
            def 抬笔(self):
                try:
                    self._y.penup()
                except:
                    print('错误')
            def 落笔(self):
                try:
                    self._y.pendown()
                except:
                    print('错误')
            def 画圆(self,半径,度数=360,段数=None):
                try:
                    self._y.circle(半径,extent=度数,steps=段数)
                except:
                    print('错误')
            def 画点(self,大小,颜色):
                try:
                    if 颜色 == '红':
                        self._y.dot(大小,'red')
                    if 颜色 == '橙':
                        self._y.dot(大小,'orange')
                    if 颜色 == '黄':
                        self._y.dot(大小,'yellow')
                    if 颜色 == '绿':
                        self._y.dot(大小,'green')
                    if 颜色 == '青':
                        self._y.dot(大小,'cyan')
                    if 颜色 == '蓝':
                        self._y.dot(大小,'blue')
                    if 颜色 == '紫':
                        self._y.dot(大小,'purple')
                    if 颜色 == '白':
                        self._y.dot(大小,'white')
                    if 颜色 == '灰':
                        self._y.dot(大小,'grey')
                    if 颜色 == '黑':
                        self._y.dot(大小,'black')
                    if 颜色 == '粉':
                        self._y.dot(大小,'pink')
                except:
                    print('错误')
            def 隐藏(self):
                try:
                    self._y.ht()
                except:
                    print('错误')
            def 显示(self):
                try:
                    self._y.st()
                except:
                    print('错误')
            def 方向设定(self,方向):
                try:
                    self._y.seth(方向)
                except:
                    print('错误')
            def 画板保持展示状态(self):
                try:
                    self._y.done()
                except:
                    print('错误')
            def 开始填充(self):
                try:
                    self._y.begin_fill()
                except:
                    print('错误')
            def 结束填充(self):
                try:
                    self._y.end_fill()
                except:
                    print('错误')
            def 变成初始状态(self):
                try:
                    self._y.home()
                except:
                    print('错误')
            def 移动到(self,横向,竖向):
                try:
                    self._y.goto(横向,竖向)
                except:
                    print('错误')
            def 背景颜色(颜色):
                try:
                    if 颜色 == '红':
                        self._y.bgcolor('red')
                    if 颜色 == '橙':
                        self._y.bgcolor('orange')
                    if 颜色 == '黄':
                        self._y.bgcolor('yellow')
                    if 颜色 == '绿':
                        self._y.bgcolor('green')
                    if 颜色 == '青':
                        self._y.bgcolor('cyan')
                    if 颜色 == '蓝':
                        self._y.bgcolor('blue')
                    if 颜色 == '紫':
                        self._y.bgcolor('purple')
                    if 颜色 == '白':
                        self._y.bgcolor('white')
                    if 颜色 == '灰':
                        self._y.bgcolor('grey')
                    if 颜色 == '黑':
                        self._y.bgcolor('black')
                    if 颜色 == '粉':
                        self._y.bgcolor('pink')
                except:
                    print('错误')
            def 速度(self,强度):
                if 强度 < 10 and 强度 > 0:
                    self._y.speed(强度)
                elif 强度 == 10:
                    self._y.speed(0)
                else:
                    print('错误')
            def 颜色(self,颜色):
                try:
                    if 颜色 == '红':
                        self._y.color('red')
                    if 颜色 == '橙':
                        self._y.color('orange')
                    if 颜色 == '黄':
                        self._y.color('yellow')
                    if 颜色 == '绿':
                        self._y.color('green')
                    if 颜色 == '青':
                        self._y.color('cyan')
                    if 颜色 == '蓝':
                        self._y.color('blue')
                    if 颜色 == '紫':
                        self._y.color('purple')
                    if 颜色 == '白':
                        self._y.color('white')
                    if 颜色 == '灰':
                        self._y.color('grey')
                    if 颜色 == '黑':
                        self._y.color('black')
                    if 颜色 == '粉':
                        self._y.color('pink')
                except Exception as e:
                    print(f"BurtTRAVER 错误：{e}")
        乌龟 = 我的乌龟()
        globals()[别名] = 乌龟
        globals()['乌龟'] = 乌龟
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 综合(可迭代对象):
    try:
        x=0
        for i in args:
            x+=i
        return x
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 重复数字(开始,结束,间隔=1):
    try:
        return range(开始,结束,间隔)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
篱笆 = '╳'
链条 = '┇'
左上角 = '╭'
右上角 = '╮'
横线 = '━'
左下角 = '╰' 
右下角 = '╯'
竖线 = '┃'
苹果图标 = ''
上 = '⬆'
下 = '⬇'
左 = '⬅'
右 = '➡'
def 求助():
    print("""BurtTRAVER 0.1.0 全部函数 & 变量一览表
【一、输出函数】
打印(内容,结尾符='\n',开始符='',间隔符=' ')
重复输出(内容='',限制次数=1,结尾符='\n',开始符='',间隔符=' ')
【二、数学函数】
除法(被除数,除数) --->输出列表，第一个是商，第二个是余数，如果没有余数就是能整除。
阶乘(数字)   说明：「5的阶乘：5✖4✖3✖2✖1」
次方算法(数字,次方数)
开根号(次方根,数字)
平方根(数字)
幂运算(数字,幂次)  说明：「3的2幂次就是3✖3，2的6幂次就是2✖2✖2✖2✖2✖2」
绝对值(数字=1)
综合(可迭代对象)
取模(被除数,除数) --->取到余数
重复数字(开始,结束,间隔=1)
【三、判断与转换】
长度(内容)
是否全部为真(可迭代对象=None)
是否全部为假(可迭代对象=None)
判断真假(对象)
最小值(可迭代对象)
最大值(可迭代对象)
转二进制(数字)
转八进制(数字)
转百分数(数字)
转十六进制(数字)
【四、加密解密】
加密(原文, 密钥=123)
解密(密文, 密钥=123)
【五、画图 & 游戏相关】
苏醒玩家(大小=(800,800),颜色=(0,0,0),名称='')
苏醒乌龟(别名='乌龟',颜色='白')
【六、中文编程系统】
求助() --->给出所有功能
翻译(代码文本)
运行(文件路径='我的代码.txt')
运行代码(代码)
【七、全局符号变量】
篱笆,链条,左上角,右上角,横线,左下角,右下角,竖线
苹果图标,上,下,左,右
关键字库 (中文→英文关键词)
【其他】
关键字：'针对':'for','在':'in',
'定义函数':'def','返回':'return',
'如果':'if','否则':'else','要不然':'elif',
'试一试':'try','报错':'except',
'没报错':'else','无论如何':'finally'
⚠提示⚠：关键字库只能在「运行代码(代码)」和「运行(文件路径='我的代码.txt')」里面运行，请见解！""")
关键字库 = {'针对':'for','在':'in','定义函数':'def',
        '返回':'return','如果':'if',
        '否则':'else','要不然':'elif',
        '试一试':'try','报错':'except',
        '没报错':'else','无论如何':'finally'
        }
def 平方根(数字):
    try:
        return pow(数字,0.5)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 幂运算(数字,幂次):
    try:
        return pow(数字,幂次)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 长度(内容):
    try:
        return len(内容)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 绝对值(数字=1):
    try:
        return abs(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 是否全部为真(可迭代对象=None):
    try:
        if 可迭代对象==None:
            return None
        return all(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 判断真假(对象):
    try:
        if bool(对象) == False:
            return '否'
        elif bool(对象) == True:
            return '是'
        else:
            return '不确定'
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转二进制(数字):
    try:
        return bin(数字)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 是否全部为假(可迭代对象=None):
    if 可迭代对象==None:
        return None
    return not any(可迭代对象)
def 翻译(代码文本):
    try:
        for 中文, 英文 in 关键字库.items():
            代码文本 = 代码文本.replace(中文, 英文)
        return 代码文本
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 运行(文件路径="我的代码.txt"):
    try:
        with open(文件路径, "r", encoding="utf-8") as f:
            代码文本 = f.read()
        翻译后 = 翻译(代码文本)
        exec(翻译后)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 运行代码(代码):
    try:
        local_vars = {}
        exec(代码, globals(), local_vars)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 取模(被除数,除数):
    try:
        return 被除数%除数
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 转百分数(数字):
    try:
        return str(int(数字*100))+'%'
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 除法(被除数,除数):
    try:
        if list(divmod(被除数,除数))[1]==0:
            return int(list(divmod(被除数,除数))[0])
        else:
            return list(divmod(被除数,除数))
    except ZeroDivisionError:
        print('BurTTRAVER错误：除数不能为0。')
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 最大值(可迭代对象):
    try:
        return max(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
def 最小值(可迭代对象):
    try:
        return min(可迭代对象)
    except Exception as e:
        print(f"BurtTRAVER 错误：{e}")
