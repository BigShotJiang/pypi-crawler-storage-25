"""Command-line interface for the VCT finish layer count optimizer."""

from __future__ import annotations

import argparse
import sys
import json

from . import (
    FinishType,
    TrafficLevel,
    ZoneType,
    assess_coat_count,
    assess_cof,
)


def _finish_choices() -> list[str]:
    return [f.value for f in FinishType]


def _traffic_choices() -> list[str]:
    return [t.value for t in TrafficLevel]


def _zone_choices() -> list[str]:
    return [z.value for z in ZoneType]


def _fmt_coat_count(result) -> str:
    r = result
    lines = [
        f"Finish type    : {r.finish_type}",
        f"Traffic level  : {r.traffic_level}",
        f"Coat count     : {r.coat_count}",
        "",
        "Burnish Response:",
        f"  Pre-burnish gloss  : {r.burnish_response.gloss_initial} GU",
        f"  Post 1-pass gloss  : {r.burnish_response.gloss_1pass} GU",
        f"  Post 3-pass gloss  : {r.burnish_response.gloss_3pass} GU",
        f"  Rating             : {r.burnish_response.rating}",
        f"  Heat risk          : {r.burnish_response.heat_risk}",
        "",
        "Repairability:",
        f"  Score              : {r.repairability.score}/10",
        f"  Spot repair viable : {r.repairability.spot_repair_viable}",
        f"  Strip required     : {r.repairability.strip_required}",
        f"  Strip difficulty   : {r.repairability.strip_difficulty}",
        f"  Strip time         : {r.repairability.strip_time_per_1000sqft} min/1,000 sq ft",
        "",
        "Recommendation:",
        f"  Action             : {r.recommendation.action}",
        f"  Optimal range      : {r.recommendation.optimal_range[0]}–{r.recommendation.optimal_range[1]} coats",
        f"  To strip trigger   : {r.recommendation.coats_to_strip_trigger} coats remaining",
        f"  Notes              : {r.recommendation.notes}",
        "",
        "Reference: https://www.binx.ca/guides/vct-finish-layer-count-optimization-2026.pdf",
    ]
    return "\n".join(lines)


def _fmt_cof(result) -> str:
    r = result
    lines = [
        f"Finish type        : {r.finish_type}",
        f"Coat count         : {r.coat_count}",
        f"Zone type          : {r.zone_type}",
        "",
        "COF Values (ASTM D2047):",
        f"  Static COF dry   : {r.static_cof_dry}",
        f"  Static COF wet   : {r.static_cof_wet}",
        "",
        "Compliance Status:",
        f"  OSHA dry (≥0.50)         : {'PASS' if r.passes_osha_dry else 'FAIL'}",
        f"  NFPA 101 wet (≥0.50)     : {'PASS' if r.passes_nfpa_wet else 'FAIL'}",
        f"  CSA B651 accessible (≥0.60): {'PASS' if r.passes_csa_accessible else 'FAIL'}",
        f"  OBC healthcare wet (≥0.60): {'PASS' if r.passes_obc_healthcare else 'FAIL'}",
        "",
        f"Slip risk rating   : {r.slip_risk_rating}",
        f"Action required    : {r.action_required}",
        "",
        "Reference: https://www.binx.ca/guides/vct-finish-layer-count-optimization-2026.pdf",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="vct-assess",
        description=(
            "VCT Finish Layer Count Optimizer\n"
            "Assess burnish response, repairability, and COF compliance "
            "for commercial VCT floor finish programs.\n"
            "Reference: https://www.binx.ca/guides/vct-finish-layer-count-optimization-2026.pdf"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    sub = parser.add_subparsers(dest="command", required=True)

    # coat-count subcommand
    cc = sub.add_parser("coat-count", help="Assess coat count program")
    cc.add_argument(
        "--finish-type", required=True, choices=_finish_choices(),
        help="Finish formulation type",
    )
    cc.add_argument(
        "--traffic-level", required=True, choices=_traffic_choices(),
        help="Floor traffic level",
    )
    cc.add_argument(
        "--coat-count", type=int, required=True, metavar="N",
        help="Current number of finish coats (not counting base seal)",
    )

    # cof subcommand
    cf = sub.add_parser("cof", help="Assess COF compliance")
    cf.add_argument(
        "--finish-type", required=True, choices=_finish_choices(),
        help="Finish formulation type",
    )
    cf.add_argument(
        "--coat-count", type=int, required=True, metavar="N",
        help="Current number of finish coats",
    )
    cf.add_argument(
        "--zone-type", default="dry_general", choices=_zone_choices(),
        help="Floor zone type for compliance threshold (default: dry_general)",
    )

    args = parser.parse_args(argv)

    if args.command == "coat-count":
        result = assess_coat_count(
            finish_type=FinishType(args.finish_type),
            traffic_level=TrafficLevel(args.traffic_level),
            coat_count=args.coat_count,
        )
        if args.json:
            import dataclasses
            print(json.dumps(dataclasses.asdict(result), indent=2))
        else:
            print(_fmt_coat_count(result))

    elif args.command == "cof":
        result = assess_cof(
            finish_type=FinishType(args.finish_type),
            coat_count=args.coat_count,
            zone_type=ZoneType(args.zone_type),
        )
        if args.json:
            import dataclasses
            print(json.dumps(dataclasses.asdict(result), indent=2))
        else:
            print(_fmt_cof(result))

    return 0


if __name__ == "__main__":
    sys.exit(main())
