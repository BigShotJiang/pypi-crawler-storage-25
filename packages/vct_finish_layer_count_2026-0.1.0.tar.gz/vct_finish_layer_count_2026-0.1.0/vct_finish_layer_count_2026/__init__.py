"""
vct_finish_layer_count_2026
===========================
VCT floor finish coat count optimizer — burnishing response, repairability,
and COF/slip compliance calculator for commercial VCT maintenance programs.

Reference: https://www.binx.ca/guides/vct-finish-layer-count-optimization-2026.pdf
Published by Binx Professional Cleaning, North Bay and Sudbury, Ontario.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class FinishType(str, Enum):
    ACRYLIC_ZINC     = "acrylic_zinc"
    ACRYLIC_NO_METAL = "acrylic_no_metal"
    HIGH_SOLIDS      = "high_solids"


class TrafficLevel(str, Enum):
    LOW     = "low"
    MEDIUM  = "medium"
    HIGH    = "high"
    EXTREME = "extreme"


class ZoneType(str, Enum):
    DRY_GENERAL      = "dry_general"
    WET_GENERAL      = "wet_general"
    ACCESSIBLE_ROUTE = "accessible_route"
    HEALTHCARE_WET   = "healthcare_wet"


# ---------------------------------------------------------------------------
# Reference tables (derived from manufacturer TDS, ASTM D2047, ISSA 750)
# ---------------------------------------------------------------------------

# (finish_type, coat_count) -> (gloss_initial, gloss_1pass, gloss_3pass, heat_risk_index)
# heat_risk_index: 0=low, 1=medium, 2=high, 3=very_high
_BURNISH_DATA: dict[tuple[str, int], tuple[int, int, int, int]] = {
    # acrylic_zinc
    ("acrylic_zinc",  1): (12, 18, 22, 0),
    ("acrylic_zinc",  2): (22, 30, 34, 0),
    ("acrylic_zinc",  3): (34, 52, 60, 0),
    ("acrylic_zinc",  4): (42, 64, 74, 0),
    ("acrylic_zinc",  5): (48, 72, 82, 0),
    ("acrylic_zinc",  6): (52, 78, 88, 0),
    ("acrylic_zinc",  7): (54, 80, 90, 0),
    ("acrylic_zinc",  8): (54, 80, 89, 1),
    ("acrylic_zinc",  9): (53, 79, 87, 1),
    ("acrylic_zinc", 10): (51, 75, 82, 2),
    ("acrylic_zinc", 11): (48, 68, 74, 2),
    ("acrylic_zinc", 12): (44, 60, 66, 2),
    ("acrylic_zinc", 13): (40, 54, 59, 3),
    ("acrylic_zinc", 14): (38, 50, 55, 3),
    # acrylic_no_metal — slightly lower gloss ceiling, better wet COF
    ("acrylic_no_metal",  1): (10, 15, 18, 0),
    ("acrylic_no_metal",  2): (18, 26, 30, 0),
    ("acrylic_no_metal",  3): (28, 44, 52, 0),
    ("acrylic_no_metal",  4): (36, 56, 66, 0),
    ("acrylic_no_metal",  5): (42, 64, 74, 0),
    ("acrylic_no_metal",  6): (44, 68, 78, 0),
    ("acrylic_no_metal",  7): (46, 70, 80, 0),
    ("acrylic_no_metal",  8): (44, 68, 76, 1),
    ("acrylic_no_metal",  9): (42, 64, 72, 1),
    ("acrylic_no_metal", 10): (40, 60, 66, 2),
    ("acrylic_no_metal", 11): (36, 54, 58, 2),
    ("acrylic_no_metal", 12): (32, 46, 50, 3),
    # high_solids — reaches peak faster, overbuild sooner
    ("high_solids",  1): (18, 26, 30, 0),
    ("high_solids",  2): (30, 48, 58, 0),
    ("high_solids",  3): (46, 70, 82, 0),
    ("high_solids",  4): (54, 82, 92, 0),
    ("high_solids",  5): (56, 84, 94, 1),
    ("high_solids",  6): (54, 80, 88, 1),
    ("high_solids",  7): (50, 72, 80, 2),
    ("high_solids",  8): (46, 66, 72, 2),
    ("high_solids",  9): (40, 56, 62, 3),
    ("high_solids", 10): (34, 48, 52, 3),
}

# Optimal coat count range (min, max) and strip trigger by (finish_type, traffic_level)
_OPTIMAL_RANGES: dict[tuple[str, str], tuple[int, int, int]] = {
    # (min_optimal, max_optimal, strip_trigger)
    ("acrylic_zinc",     "low"):     (3, 5,  8),
    ("acrylic_zinc",     "medium"):  (5, 6,  9),
    ("acrylic_zinc",     "high"):    (6, 7, 10),
    ("acrylic_zinc",     "extreme"): (7, 7, 10),
    ("acrylic_no_metal", "low"):     (3, 4,  8),
    ("acrylic_no_metal", "medium"):  (5, 6,  9),
    ("acrylic_no_metal", "high"):    (6, 7, 10),
    ("acrylic_no_metal", "extreme"): (6, 7, 10),
    ("high_solids",      "low"):     (2, 3,  6),
    ("high_solids",      "medium"):  (3, 4,  7),
    ("high_solids",      "high"):    (4, 5,  8),
    ("high_solids",      "extreme"): (4, 5,  8),
}

# Repairability score by coat_count (clamped to nearest entry)
_REPAIR_SCORES: dict[int, tuple[int, bool, bool, str, int]] = {
    # coat_count: (score, spot_viable, strip_required, difficulty, min_per_1000sqft)
    1:  (1,  False, True,  "easy",      18),
    2:  (3,  False, True,  "easy",      20),
    3:  (6,  True,  False, "easy",      22),
    4:  (8,  True,  False, "easy",      24),
    5:  (9,  True,  False, "easy",      26),
    6:  (9,  True,  False, "moderate",  30),
    7:  (8,  True,  False, "moderate",  34),
    8:  (6,  True,  False, "moderate",  38),
    9:  (4,  False, True,  "hard",      45),
    10: (2,  False, True,  "hard",      52),
    11: (2,  False, True,  "very_hard", 60),
    12: (1,  False, True,  "very_hard", 65),
    13: (1,  False, True,  "extreme",   78),
    14: (1,  False, True,  "extreme",   85),
    15: (1,  False, True,  "extreme",   100),
}

# COF data: (finish_type, coat_count) -> (static_dry, static_wet)
_COF_DATA: dict[tuple[str, int], tuple[float, float]] = {
    ("acrylic_zinc",  0): (0.62, 0.55),
    ("acrylic_zinc",  1): (0.58, 0.50),
    ("acrylic_zinc",  2): (0.56, 0.47),
    ("acrylic_zinc",  3): (0.55, 0.45),
    ("acrylic_zinc",  4): (0.54, 0.44),
    ("acrylic_zinc",  5): (0.52, 0.42),
    ("acrylic_zinc",  6): (0.51, 0.40),
    ("acrylic_zinc",  7): (0.50, 0.39),
    ("acrylic_zinc",  8): (0.49, 0.37),
    ("acrylic_zinc",  9): (0.48, 0.36),
    ("acrylic_zinc", 10): (0.47, 0.35),
    ("acrylic_no_metal",  0): (0.63, 0.56),
    ("acrylic_no_metal",  1): (0.60, 0.52),
    ("acrylic_no_metal",  2): (0.58, 0.50),
    ("acrylic_no_metal",  3): (0.57, 0.48),
    ("acrylic_no_metal",  4): (0.56, 0.47),
    ("acrylic_no_metal",  5): (0.54, 0.45),
    ("acrylic_no_metal",  6): (0.53, 0.43),
    ("acrylic_no_metal",  7): (0.51, 0.41),
    ("acrylic_no_metal",  8): (0.50, 0.39),
    ("acrylic_no_metal",  9): (0.49, 0.38),
    ("acrylic_no_metal", 10): (0.48, 0.37),
    ("high_solids",  0): (0.62, 0.55),
    ("high_solids",  1): (0.57, 0.49),
    ("high_solids",  2): (0.55, 0.46),
    ("high_solids",  3): (0.53, 0.43),
    ("high_solids",  4): (0.51, 0.41),
    ("high_solids",  5): (0.50, 0.39),
    ("high_solids",  6): (0.49, 0.37),
    ("high_solids",  7): (0.47, 0.35),
    ("high_solids",  8): (0.46, 0.34),
}

_HEAT_RISK_LABELS = ["low", "medium", "high", "very_high"]


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class BurnishResponse:
    gloss_initial: int
    gloss_1pass: int
    gloss_3pass: int
    rating: str          # poor / fair / good / excellent
    heat_risk: str       # low / medium / high / very_high


@dataclass
class RepairabilityResult:
    score: int           # 1–10
    spot_repair_viable: bool
    strip_required: bool
    strip_difficulty: str
    strip_time_per_1000sqft: int


@dataclass
class Recommendation:
    action: str          # add_coats / maintain / plan_strip / strip_now
    optimal_range: tuple[int, int]
    coats_to_strip_trigger: int
    notes: str


@dataclass
class CoatCountResult:
    finish_type: str
    traffic_level: str
    coat_count: int
    burnish_response: BurnishResponse
    repairability: RepairabilityResult
    recommendation: Recommendation


@dataclass
class CofResult:
    finish_type: str
    coat_count: int
    zone_type: str
    static_cof_dry: float
    static_cof_wet: float
    passes_osha_dry: bool
    passes_nfpa_wet: bool
    passes_csa_accessible: bool
    passes_obc_healthcare: bool
    slip_risk_rating: str
    action_required: str


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def _clamp_burnish_key(finish_type: str, coat_count: int) -> tuple[str, int]:
    """Return nearest available key in _BURNISH_DATA for the given finish type."""
    keys = [k for k in _BURNISH_DATA if k[0] == finish_type]
    if not keys:
        raise ValueError(f"Unknown finish type: {finish_type}")
    available = sorted(k[1] for k in keys)
    clamped = min(available, key=lambda x: abs(x - coat_count))
    return (finish_type, clamped)


def _burnish_rating(g3: int) -> str:
    if g3 >= 85:
        return "excellent"
    if g3 >= 70:
        return "good"
    if g3 >= 55:
        return "fair"
    return "poor"


def _repair_entry(coat_count: int) -> tuple[int, bool, bool, str, int]:
    clamped = min(max(coat_count, 1), 15)
    if clamped in _REPAIR_SCORES:
        return _REPAIR_SCORES[clamped]
    # nearest
    nearest = min(_REPAIR_SCORES.keys(), key=lambda x: abs(x - clamped))
    return _REPAIR_SCORES[nearest]


def _cof_entry(finish_type: str, coat_count: int) -> tuple[float, float]:
    keys = [k for k in _COF_DATA if k[0] == finish_type]
    available = sorted(k[1] for k in keys)
    clamped = min(available, key=lambda x: abs(x - coat_count))
    return _COF_DATA[(finish_type, clamped)]


def _slip_risk(wet_cof: float, zone: str) -> str:
    threshold = 0.60 if zone in ("accessible_route", "healthcare_wet") else 0.50
    if wet_cof >= threshold + 0.08:
        return "low"
    if wet_cof >= threshold + 0.02:
        return "medium"
    if wet_cof >= threshold - 0.02:
        return "medium_high"
    if wet_cof >= threshold - 0.08:
        return "high"
    return "very_high"


def assess_coat_count(
    finish_type: FinishType,
    traffic_level: TrafficLevel,
    coat_count: int,
) -> CoatCountResult:
    """
    Assess a VCT finish coat count program.

    Parameters
    ----------
    finish_type : FinishType
        Finish formulation.
    traffic_level : TrafficLevel
        Floor traffic intensity.
    coat_count : int
        Current number of finish coats (not counting base seal).

    Returns
    -------
    CoatCountResult
        Burnish response, repairability, and program recommendation.
    """
    ft = finish_type.value if isinstance(finish_type, FinishType) else str(finish_type)
    tl = traffic_level.value if isinstance(traffic_level, TrafficLevel) else str(traffic_level)

    bkey = _clamp_burnish_key(ft, coat_count)
    gi, g1, g3, hri = _BURNISH_DATA[bkey]
    br = BurnishResponse(
        gloss_initial=gi,
        gloss_1pass=g1,
        gloss_3pass=g3,
        rating=_burnish_rating(g3),
        heat_risk=_HEAT_RISK_LABELS[hri],
    )

    score, spot, strip, diff, stime = _repair_entry(coat_count)
    rep = RepairabilityResult(
        score=score,
        spot_repair_viable=spot,
        strip_required=strip,
        strip_difficulty=diff,
        strip_time_per_1000sqft=stime,
    )

    opt_key = (ft, tl)
    mn, mx, trigger = _OPTIMAL_RANGES.get(opt_key, (4, 7, 10))
    to_trigger = max(0, trigger - coat_count)

    if coat_count < mn:
        action = "add_coats"
        notes = (
            f"Floor is under-coated. Optimal range for {tl} traffic "
            f"({ft.replace('_', ' ')}) is {mn}–{mx} coats. "
            f"Add {mn - coat_count} coat(s) before next burnish. "
            "Apply anti-slip treatment in all wet zones after recoating."
        )
    elif coat_count <= mx:
        action = "maintain"
        notes = (
            f"Coat count is within optimal range ({mn}–{mx}) for {tl} traffic. "
            f"Strip cycle triggered at {trigger} coats "
            f"({to_trigger} coats remaining). "
            "Continue scheduled recoat and burnish program."
        )
    elif coat_count < trigger:
        action = "plan_strip"
        notes = (
            f"Coat count exceeds optimal range. Schedule strip-and-refinish "
            f"within next maintenance cycle. Strip trigger is {trigger} coats "
            f"({to_trigger} coats remaining). "
            "Adhesion risk for new coats increasing — scuff-sand before any recoat."
        )
    else:
        action = "strip_now"
        notes = (
            f"Strip trigger reached or exceeded ({coat_count} coats). "
            "Full strip cycle required before any further coats. "
            f"Expect {rep.strip_difficulty} strip ({rep.strip_time_per_1000sqft} min/1,000 sq ft). "
            "Post-strip pH check and tile inspection mandatory."
        )

    rec = Recommendation(
        action=action,
        optimal_range=(mn, mx),
        coats_to_strip_trigger=to_trigger,
        notes=notes,
    )

    return CoatCountResult(
        finish_type=ft,
        traffic_level=tl,
        coat_count=coat_count,
        burnish_response=br,
        repairability=rep,
        recommendation=rec,
    )


def assess_cof(
    finish_type: FinishType,
    coat_count: int,
    zone_type: ZoneType = ZoneType.DRY_GENERAL,
) -> CofResult:
    """
    Assess COF compliance for a finished VCT floor.

    Parameters
    ----------
    finish_type : FinishType
        Finish formulation.
    coat_count : int
        Current number of finish coats.
    zone_type : ZoneType
        Type of floor zone for compliance threshold selection.

    Returns
    -------
    CofResult
        COF values and compliance status against OSHA, NFPA, CSA, and OBC.
    """
    ft = finish_type.value if isinstance(finish_type, FinishType) else str(finish_type)
    zt = zone_type.value if isinstance(zone_type, ZoneType) else str(zone_type)

    dry, wet = _cof_entry(ft, coat_count)

    passes_osha_dry = dry >= 0.50
    passes_nfpa_wet = wet >= 0.50
    passes_csa = dry >= 0.60
    passes_obc = wet >= 0.60

    slip = _slip_risk(wet, zt)

    # Determine action
    if zt in ("accessible_route", "healthcare_wet"):
        threshold_met = wet >= 0.60
    else:
        threshold_met = wet >= 0.50

    if threshold_met and dry >= 0.50:
        action = "none"
    elif dry >= 0.50 and wet >= 0.44:
        action = "monitor"
    elif coat_count >= 9:
        action = "strip_and_retreat"
    else:
        action = "anti_slip_treatment_required"

    return CofResult(
        finish_type=ft,
        coat_count=coat_count,
        zone_type=zt,
        static_cof_dry=round(dry, 2),
        static_cof_wet=round(wet, 2),
        passes_osha_dry=passes_osha_dry,
        passes_nfpa_wet=passes_nfpa_wet,
        passes_csa_accessible=passes_csa,
        passes_obc_healthcare=passes_obc,
        slip_risk_rating=slip,
        action_required=action,
    )


__all__ = [
    "FinishType",
    "TrafficLevel",
    "ZoneType",
    "BurnishResponse",
    "RepairabilityResult",
    "Recommendation",
    "CoatCountResult",
    "CofResult",
    "assess_coat_count",
    "assess_cof",
]
