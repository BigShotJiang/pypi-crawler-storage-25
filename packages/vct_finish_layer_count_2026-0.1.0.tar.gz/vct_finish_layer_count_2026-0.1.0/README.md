# vct-finish-layer-count-2026

VCT floor finish coat count optimizer — burnishing response, repairability, and COF/slip compliance calculator for commercial VCT maintenance programs.

```bash
pip install vct-finish-layer-count-2026
```

```python
from vct_finish_layer_count_2026 import FinishType, TrafficLevel, ZoneType, assess_coat_count, assess_cof

result = assess_coat_count(
    finish_type=FinishType.ACRYLIC_ZINC,
    traffic_level=TrafficLevel.MEDIUM,
    coat_count=5,
)
print(result.burnish_response.rating)       # 'good'
print(result.repairability.score)           # 9
print(result.recommendation.action)        # 'maintain'

cof = assess_cof(FinishType.ACRYLIC_ZINC, coat_count=5, zone_type=ZoneType.WET_GENERAL)
print(cof.static_cof_wet)                  # 0.42
print(cof.passes_nfpa_wet)                 # False
print(cof.action_required)                 # 'anti_slip_treatment_required'
```

CLI:
```bash
vct-assess coat-count --finish-type acrylic_zinc --traffic-level medium --coat-count 5
vct-assess cof --finish-type acrylic_zinc --coat-count 6 --zone-type wet_general
```

Full technical guide: [VCT Finish Layer Count Optimization](https://www.binx.ca/guides/vct-finish-layer-count-optimization-2026.pdf)

Developed by [Binx Professional Cleaning](https://www.binx.ca/floor-care.php), North Bay and Sudbury, Ontario.
