# Kriya — Python SDK

Official Python client for [**Kriya**](https://kriya.insightsbyomkar.com) — the Insights by Omkar astrology API. **109+ v1 endpoints** across Western, Vedic, Hellenistic, Jaimini, KP, and electional traditions. Computed from first principles on a home-grown VSOP87D + ELP2000 + DOPRI8 engine.

**Zero runtime dependencies.** Uses Python stdlib `urllib.request`. Works on Python 3.9+.

## Install

```bash
pip install kriya-astrology
```

## Quick start

```python
from kriya_astrology import KriyaAstrologyClient

client = KriyaAstrologyClient(api_key="sk_live_...")

chart = client.chart_natal({
    "datetime": "1990-06-15T12:00:00Z",
    "latitude": 19.076,
    "longitude": 72.8777,
})
print(chart["bodies"])

# Ask-chart grounded in the actual ephemeris:
answer = client.ask_chart({
    "natal": {
        "datetime": "1990-06-15T12:00:00Z",
        "latitude": 19.076,
        "longitude": 72.8777,
    },
    "question": "What is the dominant theme of this chart?",
    "tradition": "vedic",
})
print(answer["answer"])
```

## Errors

Errors are raised as `KriyaAstrologyError` with `status`, `body`, and `request_id` attributes for correlation with server logs.

```python
from kriya_astrology import KriyaAstrologyError

try:
    client.chart_natal({...})
except KriyaAstrologyError as err:
    print(f"API {err.status} (request {err.request_id}):", err.body)
    raise
```

## Generated from OpenAPI

This SDK is regenerated from the [Kriya OpenAPI 3.1 spec](https://kriya.insightsbyomkar.com/openapi.json) on every API release. Endpoint coverage tracks the server automatically.

## Related

- **[Kriya API docs](https://kriya.insightsbyomkar.com/docs/api)** — interactive Scalar explorer
- **[Pricing](https://kriya.insightsbyomkar.com/pricing)** — Developer (free) / Studio ($49/mo) / Scale (custom)
- **[TypeScript SDK](https://www.npmjs.com/package/kriya-astrology)** — `npm install kriya-astrology`
- **[Go SDK](https://github.com/omkarjaliparthi/kriya-go)** — `go get github.com/omkarjaliparthi/kriya-go`

## License

MIT — see [LICENSE](./LICENSE).
