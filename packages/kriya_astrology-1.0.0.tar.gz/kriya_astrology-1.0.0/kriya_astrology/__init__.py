"""kriya-astrology — Python client for Kriya, the Insights by Omkar astrology API."""

from .client import KriyaAstrologyClient, KriyaAstrologyError, VERSION

__all__ = ["KriyaAstrologyClient", "KriyaAstrologyError", "VERSION"]
