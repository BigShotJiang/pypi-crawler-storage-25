"""Auto-generated from OpenAPI spec. Do not edit manually.
Regenerate with: npm run generate-sdk-python

Engine version at generation time: 9.8.6
"""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

VERSION = "1.0.0"
DEFAULT_BASE_URL = "https://api.insightsbyomkar.com/api/v1"


class KriyaAstrologyError(Exception):
    """Raised when the API returns a non-2xx status.

    Attributes:
        status: HTTP status code.
        body: Parsed JSON body (or None).
        request_id: x-request-id echoed from the server (or None).
    """

    def __init__(
        self,
        message: str,
        status: int,
        body: Any = None,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.body = body
        self.request_id = request_id


class KriyaAstrologyClient:
    """Kriya — thin Python client for the Insights by Omkar astrology API.

    Example:
        client = KriyaAstrologyClient(api_key="sk_live_...")
        chart = client.chart_natal({
            "datetime": "1990-06-15T12:00:00Z",
            "latitude": 19.076,
            "longitude": 72.8777,
        })
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout_seconds: float = 30.0,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    def _call(self, method: str, route: str, body: Optional[dict] = None) -> Any:
        url = self.base_url + route
        headers = {"x-api-key": self.api_key}
        data: Optional[bytes] = None
        if body is not None:
            headers["content-type"] = "application/json"
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url, method=method, headers=headers, data=data)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                text = resp.read().decode("utf-8")
                return json.loads(text) if text else None
        except urllib.error.HTTPError as e:
            request_id = e.headers.get("x-request-id") if e.headers else None
            try:
                parsed = json.loads(e.read().decode("utf-8"))
            except Exception:
                parsed = None
            message = f"Request failed with status {e.code}"
            if isinstance(parsed, dict):
                err = parsed.get("error")
                if isinstance(err, dict) and err.get("message"):
                    message = err["message"]
            raise KriyaAstrologyError(message, e.code, parsed, request_id) from e
        except urllib.error.URLError as e:
            raise KriyaAstrologyError(
                f"Network error: {e.reason}", 0, None, None,
            ) from e

    def accuracy(self) -> Any:
        """Live ephemeris-accuracy report. For each of ~20 reference dates spanning 1900–2050, recomputes the body's ecliptic longitude now and diffs against the published Meeus / Horizons value. Returns per-body summary + per-anchor deltas + the ephemeris-claims snapshot. Unauthenticated. Cached 15 min."""
        return self._call("GET", "/accuracy")

    def antiscia(self, body: dict) -> Any:
        """Solstitial mirror points (antiscia) and equinoctial mirror points (contra-antiscia), plus contacts between natal positions and antiscia within orb."""
        return self._call("POST", "/antiscia", body)

    def ashtakavarga(self, body: dict) -> Any:
        """Parashara prastara + sarvashtakavarga bindus."""
        return self._call("POST", "/ashtakavarga", body)

    def ask(self, body: dict) -> Any:
        """Ask a question through the lens of the best-matched astrological method."""
        return self._call("POST", "/ask", body)

    def ask_chart(self, body: dict) -> Any:
        """Claude-grounded natural-language Q&A over a natal chart. The LLM is constrained to reason only from a structured facts block derived from the ephemeris and to cite each placement its answer relies on — no hallucinated signs. Accepts `locale` (en/hi/es/pt) to localise the narrative while keeping technical terms (sign/nakshatra/planet names) in canonical English so citations stay verifiable. Multi-turn: pass `priorMessages: [{role, content}]` from previous turns (max 20 entries, 4000 chars each) — the engine is STATELESS, clients keep their own history. When ANTHROPIC_API_KEY is unset, a deterministic stub answer is returned so integrations work without the model. Tradition defaults to Vedic."""
        return self._call("POST", "/ask-chart", body)

    def aspect_events(self, body: dict) -> Any:
        """All exact aspect moments (conjunction / sextile / square / trine / opposition) between two bodies in a date range. Each event carries the exact JD/datetime, the aspect kind, the signed separation at exact aspect, both longitudes, the relative angular speed at exact (lonA' − lonB' in deg/day, signed), and an `applying` flag (true when bodyA is gaining on bodyB at exact — natural-forward formation; false on retrograde reversals). Range cap: 50 years for outer pairs, 10 years if Moon is involved."""
        return self._call("POST", "/aspect-events", body)

    def aspects(self, body: dict) -> Any:
        """Detect aspects between arbitrary ecliptic longitudes."""
        return self._call("POST", "/aspects", body)

    def asteroids(self, body: dict) -> Any:
        """Geocentric ecliptic positions for Ceres, Pallas, Juno, Vesta, Chiron, Pholus, Nessus, Eris, Haumea, Makemake, Sedna, Quaoar."""
        return self._call("POST", "/asteroids", body)

    def asteroids_extended(self, body: dict) -> Any:
        """Extended minor-planet catalog — 10 astrologically-popular asteroids beyond the core 5: Lilith (#1181), Psyche, Eros, Sappho, Hygiea, Astraea, Hebe, Iris, Flora, Metis. Approximate (~1° over ±200y of J2000)."""
        return self._call("POST", "/asteroids/extended", body)

    def astrocartography(self, body: dict) -> Any:
        """Astro*Carto*Graphy (Jim Lewis). For each classical body, returns the geographic longitude where it is on the MC and IC, plus polyline samples of the ASC and DSC horizon curves — ready to render directly on a world map."""
        return self._call("POST", "/astrocartography", body)

    def bodies_extended(self, body: dict) -> Any:
        """Extended body catalog — TNO dwarfs (Eris, Sedna, Haumea, Makemake, Quaoar), centaurs (Pholus, Nessus), Lilith trio."""
        return self._call("POST", "/bodies/extended", body)

    def calibrate(self, body: dict) -> Any:
        """Calibration — score astrological methods against real life events."""
        return self._call("POST", "/calibrate", body)

    def chara_karakas(self, body: dict) -> Any:
        """Jaimini chara (movable) karakas — Atmakaraka through Gnatikaraka."""
        return self._call("POST", "/chara-karakas", body)

    def chart_batch(self, body: dict) -> Any:
        """Compute up to 25 natal charts in a single request. Lite shape (bodies, houses, aspects — no pattern/shape enrichment). Per-item failure is contained: `results[]` carries `{ index, status: 'ok'|'error' }` aligned to input order. One rate-limit hit for the whole call."""
        return self._call("POST", "/chart/batch", body)

    def chart_extended(self, body: dict) -> Any:
        """Extended natal chart with nodes, Lilith, Arabic Lots, Vertex, midpoints."""
        return self._call("POST", "/chart/extended", body)

    def chart_mean_node(self, body: dict) -> Any:
        """Mean lunar node position."""
        return self._call("POST", "/chart/mean-node", body)

    def chart_natal(self, body: dict) -> Any:
        """Full natal chart (bodies, houses, aspects). Optional `fixedStars` block adds the bright stars conjunct any body in a single round-trip."""
        return self._call("POST", "/chart/natal", body)

    def chart_vedic_wheel(self, body: dict) -> Any:
        """SVG or JSON rendering of a North/South Indian kundli."""
        return self._call("POST", "/chart/vedic-wheel", body)

    def chart_wheel(self, body: dict) -> Any:
        """SVG or JSON rendering of a Western round wheel."""
        return self._call("POST", "/chart/wheel", body)

    def compatibility(self, body: dict) -> Any:
        """Compatibility report — synastry + composite + scored summary."""
        return self._call("POST", "/compatibility", body)

    def compatibility_narrative(self, body: dict) -> Any:
        """Unified relationship reading composing composite chart (midpoint method) + synastry cross-aspects between two natal charts into a 3-paragraph narrative focused on Sun/Moon/Mars/Venus/ASC/MC contacts."""
        return self._call("POST", "/compatibility/narrative", body)

    def composite(self, body: dict) -> Any:
        """Composite chart (midpoint method) for two people."""
        return self._call("POST", "/composite", body)

    def composite_davison(self, body: dict) -> Any:
        """Davison relationship chart (midpoint in time and space)."""
        return self._call("POST", "/composite/davison", body)

    def critic_critique(self, body: dict) -> Any:
        """Evaluate a rendered image against a rubric + reference set. Returns per-axis scores (0-10), weighted total, ordered failings, narrative. Scope: critic:v1:use (metered / billable)."""
        return self._call("POST", "/critic/critique", body)

    def critic_references(self) -> Any:
        """List reference sets (great-dane, etc.) and their compatible rubrics."""
        return self._call("GET", "/critic/references")

    def critic_references_id(self) -> Any:
        """Fetch a reference set's full metadata, licenses, and landmark specs."""
        return self._call("GET", "/critic/references/{id}")

    def critic_rubrics(self) -> Any:
        """List available critic rubrics (character-figure, ambient-effect)."""
        return self._call("GET", "/critic/rubrics")

    def critic_rubrics_id(self) -> Any:
        """Fetch a rubric's full definition (axes, weights, anchors, framing)."""
        return self._call("GET", "/critic/rubrics/{id}")

    def daily(self, body: dict) -> Any:
        """Daily report — Moon phase, panchanga, muhurta, top transits."""
        return self._call("POST", "/daily", body)

    def daily_forecast(self, body: dict) -> Any:
        """Daily forecast — sky paragraph (Sun sign, Moon sign, Moon nakshatra, Arabic Manzil) plus, when natal is supplied, Navatara classification vs birth Moon, active Vimshottari Mahadasha, and transit events within ±36 hours. Returns a flowing narrative + raw data."""
        return self._call("POST", "/daily-forecast", body)

    def dashas(self, body: dict) -> Any:
        """Vimshottari, Yogini, or Ashtottari dasha periods."""
        return self._call("POST", "/dashas", body)

    def declinations(self, body: dict) -> Any:
        """Declinations of all bodies plus parallel / contraparallel aspects."""
        return self._call("POST", "/declinations", body)

    def degrees_analyze(self, body: dict) -> Any:
        """Degree-theory analysis: critical degrees, Via Combusta, Gandanta, exaltation/fall degrees."""
        return self._call("POST", "/degrees/analyze", body)

    def dignities(self, body: dict) -> Any:
        """Essential dignities + Lilly scores for all traditional planets."""
        return self._call("POST", "/dignities", body)

    def directions_primary(self, body: dict) -> Any:
        """Primary directions."""
        return self._call("POST", "/directions/primary", body)

    def draconic(self, body: dict) -> Any:
        """Draconic zodiac — every longitude shifted so the Moon's North Node sits at 0° Aries."""
        return self._call("POST", "/draconic", body)

    def eclipses(self, body: dict) -> Any:
        """Solar + lunar eclipses in a date range."""
        return self._call("POST", "/eclipses", body)

    def eclipses_prenatal(self, body: dict) -> Any:
        """Prenatal eclipses — the solar + lunar eclipses immediately before birth."""
        return self._call("POST", "/eclipses/prenatal", body)

    def events(self, body: dict) -> Any:
        """Events stream — dasha transitions, returns, eclipses, stations in a range."""
        return self._call("POST", "/events", body)

    def fixed_stars(self, body: dict) -> Any:
        """Fixed star positions at a given epoch, with precession drift."""
        return self._call("POST", "/fixed-stars", body)

    def gauquelin(self, body: dict) -> Any:
        """Gauquelin 36 equal-time diurnal sectors with G1–G4 power-zone classification (cadent-after-angle slots Michel Gauquelin found statistically significant for professional eminence)."""
        return self._call("POST", "/gauquelin", body)

    def geocode(self, body: dict) -> Any:
        """Location autocomplete with timezone inference."""
        return self._call("POST", "/geocode", body)

    def harmonic(self, body: dict) -> Any:
        """Harmonic chart (Nth harmonic — multiply longitudes by N, mod 360)."""
        return self._call("POST", "/harmonic", body)

    def health(self) -> Any:
        """Liveness + self-check. Returns 200 when the ephemeris drift check passes, 503 when it fails. Unauthenticated — safe for uptime monitors and load balancers."""
        return self._call("GET", "/health")

    def heliacal(self, body: dict) -> Any:
        """Heliacal rising/setting event scan. Returns every date in [startDatetime, endDatetime] where the Sun-body elongation crosses ±thresholdDeg for Moon, Mercury, Venus, Mars, Jupiter, Saturn. Default threshold 10° (classical arcus visionis)."""
        return self._call("POST", "/heliacal", body)

    def heliocentric(self, body: dict) -> Any:
        """Heliocentric ecliptic positions for Mercury through Pluto."""
        return self._call("POST", "/heliocentric", body)

    def horary(self, body: dict) -> Any:
        """Horary astrology (William Lilly tradition) with Vedic Prashna companion. Returns question chart (Regiomontanus houses), considerations against judgment (Lilly's 7+ strictures), significators for querent + quesited, perfection analysis (applying aspect, translation/collection of light, prohibition), and a verdict. Prashna section returns Prashna Lagna, Moon nakshatra, and planetary hour ruler."""
        return self._call("POST", "/horary", body)

    def houses(self, body: dict) -> Any:
        """House cusps + angles for a moment and location."""
        return self._call("POST", "/houses", body)

    def ingress(self, body: dict) -> Any:
        """The four cardinal solar ingresses (Aries / Cancer / Libra / Capricorn) for a year, each cast as a full natal-style chart for the given location. Classical mundane astrology — Aries is the year chart; the others mark each quarter."""
        return self._call("POST", "/ingress", body)

    def jaimini_arudhas(self, body: dict) -> Any:
        """Arudha padas A1–A12 including Upapada (marriage indicator)."""
        return self._call("POST", "/jaimini/arudhas", body)

    def jaimini_aspects(self, body: dict) -> Any:
        """Rashi Drishti — Jaimini sign-based aspects."""
        return self._call("POST", "/jaimini/aspects", body)

    def jaimini_chara_dasha(self, body: dict) -> Any:
        """Chara Dasha — Jaimini sign-based life-period system."""
        return self._call("POST", "/jaimini/chara-dasha", body)

    def jaimini_narayana_dasha(self, body: dict) -> Any:
        """Narayana (Padakrama) Dasha — Jaimini sign-based dasha for major life events. Starting sign by ASC modality, direction by start-sign parity, period = count to lord minus 1 (or 12 if lord co-located)."""
        return self._call("POST", "/jaimini/narayana-dasha", body)

    def jobs(self) -> Any:
        """List recent async jobs owned by the caller (newest first)."""
        return self._call("GET", "/jobs")

    def jobs(self, body: dict) -> Any:
        """Create an async job. Returns 202 + jobId immediately; poll GET /jobs/{jobId} for status."""
        return self._call("POST", "/jobs", body)

    def jobs_jobid(self) -> Any:
        """Poll a job. Returns status + progress; the `result` field appears only once status=completed."""
        return self._call("GET", "/jobs/{jobId}")

    def keys_me(self) -> Any:
        """Metadata for the calling key plus sibling keys owned by the same user."""
        return self._call("GET", "/keys/me")

    def keys_rotate(self, body: dict) -> Any:
        """Rotate the calling key. Mints a new token with identical owner/plan/scopes and revokes the current one. The new token is shown exactly once."""
        return self._call("POST", "/keys/rotate", body)

    def kp_sublords(self, body: dict) -> Any:
        """KP sub-lord table — each cusp's sign lord, star lord, and sub lord."""
        return self._call("POST", "/kp-sublords", body)

    def kp_cuspal_interlinks(self, body: dict) -> Any:
        """Cuspal interlinks — promises / neutral / denies judgement per cusp."""
        return self._call("POST", "/kp/cuspal-interlinks", body)

    def kp_ruling_planets(self, body: dict) -> Any:
        """7-source ruling planets for horary analysis."""
        return self._call("POST", "/kp/ruling-planets", body)

    def kp_significators(self, body: dict) -> Any:
        """4-rank significator chain per house."""
        return self._call("POST", "/kp/significators", body)

    def lots(self, body: dict) -> Any:
        """All Hellenistic Lots + Arabic Parts (Fortune, Spirit, Eros, Necessity, Courage, Victory, Nemesis, Marriage, Children, Father, Mother, Siblings, Fame, Commerce, Sickness, Captivity). Sect-aware."""
        return self._call("POST", "/lots", body)

    def lunar_mansions(self, body: dict) -> Any:
        """Arabic 28 Manzil lunar mansions — current Moon and Sun mansion, full catalog."""
        return self._call("POST", "/lunar-mansions", body)

    def lunation(self, body: dict) -> Any:
        """Current lunar phase + elongation, nearest prior/next New Moon and Full Moon, and prior-New-Moon chart positions."""
        return self._call("POST", "/lunation", body)

    def midpoints(self, body: dict) -> Any:
        """Every 2-body midpoint plus 22.5°-dial activations (Ebertin cosmobiology)."""
        return self._call("POST", "/midpoints", body)

    def muhurta(self, body: dict) -> Any:
        """Muhurta scoring — 5-component auspiciousness for a chosen moment."""
        return self._call("POST", "/muhurta", body)

    def parans(self, body: dict) -> Any:
        """Bernadette Brady fixed-star parans. Finds latitudes where a star and a planet are simultaneously on their respective angles (rise/MC/set/IC) within an LST tolerance."""
        return self._call("POST", "/parans", body)

    def pattern_events(self, body: dict) -> Any:
        """Find moments when ≥3 bodies form a multi-aspect configuration in a date range. Patterns: grand-trine (3 mutual trines), t-square (opposition + 2 squares to apex), yod (sextile + 2 quincunxes to apex), grand-cross (2 oppositions + 4 squares). Exhaustive over the supplied bodies — every triple (or quad) is scanned. Each event reports the moment of tightest configuration with `kind`, `bodies` (ordered: opposition pair + apex for t-square / yod), `maxOrbDeg` (widest contributing aspect orb at exact), and ISO datetime. Body cap 10. Range cap: 50 years outer-only, 5 years if Moon is involved. `maxOrbDeg` filter (default 1°) controls how strict 'exact' must be."""
        return self._call("POST", "/pattern-events", body)

    def planetary_hours(self, body: dict) -> Any:
        """Chaldean 24-hour planetary day — which planet rules each hour."""
        return self._call("POST", "/planetary-hours", body)

    def planetary_nodes(self, body: dict) -> Any:
        """Mean heliocentric ascending nodes for all 8 planets."""
        return self._call("POST", "/planetary-nodes", body)

    def positions(self, body: dict) -> Any:
        """Geocentric ecliptic positions for one or more bodies."""
        return self._call("POST", "/positions", body)

    def profections(self, body: dict) -> Any:
        """Annual and monthly profections with time-lord."""
        return self._call("POST", "/profections", body)

    def progressions(self, body: dict) -> Any:
        """Secondary progressions (day-for-a-year) for a natal chart."""
        return self._call("POST", "/progressions", body)

    def progressions_tertiary(self, body: dict) -> Any:
        """Tertiary progressions (day-for-a-month)."""
        return self._call("POST", "/progressions/tertiary", body)

    def reading_natal(self, body: dict) -> Any:
        """Structured natal reading — 6 topics with original interpretive content."""
        return self._call("POST", "/reading/natal", body)

    def reading_summary(self, body: dict) -> Any:
        """Whole-chart-in-one-paragraph composer — Sun sign + Moon sign + Ascendant archetypal triad, sidereal Moon nakshatra with pada/lord, and active Vimshottari Mahadasha with birth-to-now transition narrative. Ideal for notifications, widgets, or quick-look social sharing."""
        return self._call("POST", "/reading/summary", body)

    def reading_transit(self, body: dict) -> Any:
        """Structured transit reading for a given moment."""
        return self._call("POST", "/reading/transit", body)

    def reading_vedic(self, body: dict) -> Any:
        """Vedic natal reading centered on the Moon. Returns flowing interpretive paragraphs: nakshatra voice (27 original nakshatra entries with deity, symbol, shakti, and lived meaning) + current Vimshottari Mahadasha + Antardasha narrative. Lahiri ayanamsa by default."""
        return self._call("POST", "/reading/vedic", body)

    def relocation(self, body: dict) -> Any:
        """Relocated chart — same birth moment, different location."""
        return self._call("POST", "/relocation", body)

    def returns_lunar(self, body: dict) -> Any:
        """Lunar return chart — exact moment Moon returns to natal longitude."""
        return self._call("POST", "/returns/lunar", body)

    def returns_solar(self, body: dict) -> Any:
        """Solar return chart — exact moment Sun returns to natal longitude."""
        return self._call("POST", "/returns/solar", body)

    def sensitive_points(self, body: dict) -> Any:
        """Vertex, Anti-Vertex, and East Point (Equatorial Ascendant)."""
        return self._call("POST", "/sensitive-points", body)

    def shadbala(self, body: dict) -> Any:
        """Six-fold planetary strength analysis."""
        return self._call("POST", "/shadbala", body)

    def sign_ingresses(self, body: dict) -> Any:
        """All tropical-sign-boundary crossings for a body in a date range. Each ingress carries fromSign, toSign, boundaryDeg, and direction (prograde/retrograde — Mercury Rx in particular often back-crosses a boundary). Body parameter accepts the full integrated catalog. Range cap 20 years."""
        return self._call("POST", "/sign-ingresses", body)

    def stars_list(self, body: dict) -> Any:
        """Enumerate the fixed-star catalog (158 stars) with J2000 positions and interpretations."""
        return self._call("POST", "/stars/list", body)

    def stations(self, body: dict) -> Any:
        """All retrograde-station moments for a body in a date range — the moments longitude rate crosses zero. `direction` is the motion direction immediately AFTER the station (`retrograde` = body just stationed retrograde, `direct` = body just stationed direct). Range cap 50 years. Sun and Moon return empty arrays (they don't retrograde geocentrically)."""
        return self._call("POST", "/stations", body)

    def sun_rise_set(self, body: dict) -> Any:
        """Sunrise, sunset, and solar transit for a location."""
        return self._call("POST", "/sun-rise-set", body)

    def synastry(self, body: dict) -> Any:
        """Synastry aspects between two people's natal charts."""
        return self._call("POST", "/synastry", body)

    def transits(self, body: dict) -> Any:
        """Current or future transit aspects to a natal chart."""
        return self._call("POST", "/transits", body)

    def transits_batch(self, body: dict) -> Any:
        """Compute up to 25 transit charts (each one natal × transit moment) in a single request. Same per-item failure semantics as /chart/batch. One rate-limit hit for the whole call."""
        return self._call("POST", "/transits/batch", body)

    def transits_scan(self, body: dict) -> Any:
        """Scan a date range for exact transits. Returns every moment when the selected transiting bodies form the selected aspects to natal planets, ASC, or MC. Defaults to outer planets (Jupiter→Pluto) and all five Ptolemaic aspects. Pass `?stream=true` to receive results as an SSE stream — one frame per transiting body (`{type:"body",body,hits}`), bracketed by `{type:"start",...}` and `{type:"done",totalHits}`."""
        return self._call("POST", "/transits/scan", body)

    def true_node(self, body: dict) -> Any:
        """True lunar node position (osculating)."""
        return self._call("POST", "/true-node", body)

    def uranian(self, body: dict) -> Any:
        """Uranian / Hamburg School — 8 hypothetical trans-Neptunian bodies (Cupido, Hades, Zeus, Kronos, Apollon, Admetos, Vulkanus, Poseidon) from Witte-Sieggruen orbital elements, plus all classical anchors mapped onto the 90° dial with midpoint-activation detection."""
        return self._call("POST", "/uranian", body)

    def usage_me(self) -> Any:
        """Consumption for the calling API key. Bearer-authed. JWT keys only — static and open-mode return 403."""
        return self._call("GET", "/usage/me")

    def vedic_bhava_chalit(self, body: dict) -> Any:
        """Bhava chalit chart — Vedic house placements using real cusps (Placidus/Porphyry) instead of whole-sign, with rashi-vs-bhava shift detection."""
        return self._call("POST", "/vedic/bhava-chalit", body)

    def vedic_chart(self, body: dict) -> Any:
        """Full Vedic natal chart with sidereal positions, nakshatras, and vargas."""
        return self._call("POST", "/vedic/chart", body)

    def vedic_graha_drishti(self, body: dict) -> Any:
        """Parashari Vedic planetary aspects (Graha Drishti). Every planet aspects the 7th house from itself; Mars also 4th/8th, Jupiter 5th/9th, Saturn 3rd/10th, Rahu/Ketu 5th/9th. Returns per-planet aspect list + planet-to-planet matrix."""
        return self._call("POST", "/vedic/graha-drishti", body)

    def vedic_navatara(self, body: dict) -> Any:
        """Navatara — 9-star classification of nakshatras relative to the Janma (birth Moon) nakshatra. Returns the full 27-row table plus, if `now` is provided, the transit Moon's current classification."""
        return self._call("POST", "/vedic/navatara", body)

    def vedic_panchanga(self, body: dict) -> Any:
        """Panchanga (five limbs): tithi, karana, yoga, nakshatra, vara."""
        return self._call("POST", "/vedic/panchanga", body)

    def vedic_sade_sati(self, body: dict) -> Any:
        """Sade Sati (Saturn's 7.5-year transit over natal Moon)."""
        return self._call("POST", "/vedic/sade-sati", body)

    def vedic_tajika_synastry(self, body: dict) -> Any:
        """Tajika aspects between two persons' Varshaphala (annual return) charts. Useful for relationship assessment at a specific shared year (career, marriage, joint ventures). Supports different ages per person via `ageYearsB`."""
        return self._call("POST", "/vedic/tajika-synastry", body)

    def vedic_vargas(self, body: dict) -> Any:
        """All 16 divisional charts (Shodashavarga) — D1, D2, D3, D4, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45, D60 — with per-planet placements."""
        return self._call("POST", "/vedic/vargas", body)

    def vedic_varshaphala(self, body: dict) -> Any:
        """Vedic annual return (Varshaphala / Tajika): sidereal solar return chart + Muntha + Year Lord (Varshesha) + Mudda dasha + Patyayini dasha + Tajika aspects & yogas + 30 Sahams."""
        return self._call("POST", "/vedic/varshaphala", body)

    def voc_moon(self, body: dict) -> Any:
        """Void-of-course Moon — period when the Moon makes no major aspect before sign change."""
        return self._call("POST", "/voc-moon", body)

    def webhooks(self) -> Any:
        """List all webhook subscriptions owned by the caller. Bearer-authed. JWT keys with ownedBy required."""
        return self._call("GET", "/webhooks")

    def webhooks(self, body: dict) -> Any:
        """Create a webhook subscription. Plaintext secret returned ONCE — save it before closing the response."""
        return self._call("POST", "/webhooks", body)

    def webhooks_subid(self) -> Any:
        """Fetch a single subscription (secret not returned)."""
        return self._call("GET", "/webhooks/{subId}")

    def yogas(self, body: dict) -> Any:
        """Detect classical yogas (Gaja Kesari, Pancha Mahapurusha, etc.)."""
        return self._call("POST", "/yogas", body)

    def zodiacal_releasing(self, body: dict) -> Any:
        """Zodiacal Releasing — L1→L4 fractal periods from any Lot."""
        return self._call("POST", "/zodiacal-releasing", body)

