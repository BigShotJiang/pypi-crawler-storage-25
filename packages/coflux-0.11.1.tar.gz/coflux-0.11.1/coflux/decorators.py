"""Decorators for defining Coflux tasks and workflows."""

from __future__ import annotations

import datetime as dt
import typing as t

from .target import Cache, Defer, Retries, Target

P = t.ParamSpec("P")
T = t.TypeVar("T")


class _TargetDecorator(t.Protocol):
    """Decorator protocol that unwraps ``Coroutine`` for async functions.

    Overloading on ``__call__`` (rather than on the factory function)
    lets the type checker pick the right overload based on the decorated
    function's return type — which is visible at application time, but
    not at the factory call.
    """

    @t.overload
    def __call__(
        self, fn: t.Callable[P, t.Coroutine[t.Any, t.Any, T]]
    ) -> Target[P, T]: ...

    @t.overload
    def __call__(self, fn: t.Callable[P, T]) -> Target[P, T]: ...


def task(
    *,
    name: str | None = None,
    wait: bool | t.Iterable[str] | str = False,
    cache: bool | float | dt.timedelta | Cache = False,
    retries: int | bool | Retries = 0,
    recurrent: bool = False,
    defer: bool | Defer = False,
    delay: float | dt.timedelta = 0,
    memo: bool | t.Iterable[str] = False,
    requires: dict[str, str | bool | list[str]] | None = None,
    timeout: float | dt.timedelta = 0,
) -> _TargetDecorator:
    """Decorator for defining a task.

    For ``async def`` functions, the coroutine is run to completion by
    the executor; the task's return type is the coroutine's resolved
    value (not the coroutine itself).
    """

    def decorator(fn):
        return Target(
            fn,
            "task",
            name=name,
            wait=wait,
            cache=cache,
            retries=retries,
            recurrent=recurrent,
            defer=defer,
            delay=delay,
            memo=memo,
            requires=requires,
            timeout=timeout,
        )

    return decorator  # type: ignore[return-value]


def workflow(
    *,
    name: str | None = None,
    wait: bool | t.Iterable[str] | str = False,
    cache: bool | float | dt.timedelta | Cache = False,
    retries: int | bool | Retries = 0,
    recurrent: bool = False,
    defer: bool | Defer = False,
    delay: float | dt.timedelta = 0,
    memo: bool = False,
    requires: dict[str, str | bool | list[str]] | None = None,
    timeout: float | dt.timedelta = 0,
) -> _TargetDecorator:
    """Decorator for defining a workflow.

    For ``async def`` functions, the coroutine is run to completion by
    the executor; the workflow's return type is the coroutine's resolved
    value (not the coroutine itself).
    """

    def decorator(fn):
        return Target(
            fn,
            "workflow",
            name=name,
            wait=wait,
            cache=cache,
            retries=retries,
            recurrent=recurrent,
            defer=defer,
            delay=delay,
            memo=memo,
            requires=requires,
            timeout=timeout,
        )

    return decorator  # type: ignore[return-value]


def stub(
    module: str,
    *,
    name: str | None = None,
    type: t.Literal["workflow", "task"] = "task",
    wait: bool | t.Iterable[str] | str = False,
    cache: bool | float | dt.timedelta | Cache = False,
    retries: int | bool | Retries = 0,
    recurrent: bool = False,
    defer: bool | Defer = False,
    delay: float | dt.timedelta = 0,
    memo: bool | t.Iterable[str] = False,
) -> _TargetDecorator:
    """Decorator for defining a stub (external reference)."""

    def decorator(fn):
        return Target(
            fn,
            type,
            module=module,
            name=name,
            wait=wait,
            cache=cache,
            retries=retries,
            recurrent=recurrent,
            defer=defer,
            delay=delay,
            memo=memo,
            is_stub=True,
        )

    return decorator  # type: ignore[return-value]
