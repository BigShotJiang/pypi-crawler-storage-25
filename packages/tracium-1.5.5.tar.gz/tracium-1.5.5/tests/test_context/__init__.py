"""
Tests for context management.
"""
