from pathlib import Path

from metalens_sim_toolkit.cst_workflow_helpers import (
    build_frequency_monitors,
    resolve_output_cst_path,
)


def test_build_frequency_monitors_count_and_types():
    monitors = build_frequency_monitors(
        frequency_thz=500.0,
        enable_e_field=True,
        enable_h_field=False,
        enable_farfield=True,
        enable_powerflow=False,
    )

    assert len(monitors) == 2
    assert monitors[0].field_type == "Efield"
    assert monitors[1].field_type == "Farfield"


def test_resolve_output_cst_path_no_timestamp_when_disabled(tmp_path: Path):
    p = tmp_path / "model.cst"
    out = resolve_output_cst_path(p, use_timestamp_if_exists=False)
    assert out == p


def test_resolve_output_cst_path_timestamp_when_exists(tmp_path: Path):
    p = tmp_path / "model.cst"
    p.touch()
    out = resolve_output_cst_path(p, use_timestamp_if_exists=True)
    assert out != p
    assert out.suffix == ".cst"
    assert out.name.startswith("model_")
