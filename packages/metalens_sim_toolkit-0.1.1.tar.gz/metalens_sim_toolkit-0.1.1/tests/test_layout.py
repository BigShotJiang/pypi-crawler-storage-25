import numpy as np
import pytest

from metalens_sim_toolkit.layout import infer_unit_cells_xy, optimized_p_to_cst_cylinder_table


def test_optimized_p_to_cst_cylinder_table_shape():
    p = np.array([[1e-9, 0.0], [2e-9, 3e-9]])
    df = optimized_p_to_cst_cylinder_table(
        p=p,
        pitch_m=300e-9,
        length_unit="nm",
        drop_nonpositive=True,
    )

    assert list(df.columns) == ["x", "y", "radius", "row", "col"]
    assert len(df) == 3


def test_optimized_p_to_cst_cylinder_table_quarter_no_axes():
    p = np.ones((4, 4), dtype=float) * 1e-9
    df = optimized_p_to_cst_cylinder_table(
        p=p,
        pitch_m=1.0,
        length_unit="m",
        quarter=True,
        include_symmetry_axes=False,
    )

    assert (df["x"] > 0).all()
    assert (df["y"] > 0).all()


def test_infer_unit_cells_xy_3d_param_slice():
    p = np.zeros((7, 9, 2), dtype=float)
    nx, ny = infer_unit_cells_xy(p, param_index=1)
    assert (nx, ny) == (9, 7)


def test_infer_unit_cells_xy_4d_batch_and_param():
    p = np.zeros((3, 5, 8, 4), dtype=float)
    nx, ny = infer_unit_cells_xy(p, batch_index=2, param_index=3)
    assert (nx, ny) == (8, 5)


def test_infer_unit_cells_xy_param_oob_raises():
    p = np.zeros((5, 8, 1), dtype=float)
    with pytest.raises(ValueError, match="param_index"):
        infer_unit_cells_xy(p, param_index=1)
