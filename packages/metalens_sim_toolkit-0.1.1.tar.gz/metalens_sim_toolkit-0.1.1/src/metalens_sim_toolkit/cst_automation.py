"""CST Studio Suite metasurface automation.

This module provides a CST-focused geometry workflow similar to the existing
COMSOL helpers, but scoped to model construction (e.g. cylinders/brick).
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
import platform
import shutil
import sys
import threading
import time
from typing import Callable, Mapping, Optional, Sequence

import numpy as np
import pandas as pd


from .layout import optimized_p_to_cst_cylinder_table


ScalarExpr = int | float | str


@dataclass
class CstSessionConfig:
    """Session controls for CST DesignEnvironment."""

    attach_to_existing: bool = False
    auto_accept_education_dialog: bool = True
    education_dialog_timeout_s: float = 90.0


@dataclass
class CstMetasurfaceConfig:
    """Geometry defaults for CST model build."""

    component: str = "component1"
    material: str = "Vacuum"
    length_unit: str = "mm"
    frequency_unit: str = "THz"
    time_unit: str = "ns"
    pillar_height: ScalarExpr = 1.315
    z_base: ScalarExpr = 0.0
    shape_prefix: str = "cyl"


@dataclass
class CstMaterialConfig:
    """Optional user-defined material entry."""

    name: str
    epsilon: ScalarExpr = 1.0
    mu: ScalarExpr = 1.0
    tan_d: ScalarExpr = 0.0
    kappa: ScalarExpr = 0.0
    color_rgb: tuple[float, float, float] = (0.8, 0.8, 0.8)


@dataclass
class CstAirboxConfig:
    """Optional air-box and port settings."""

    enabled: bool = False
    name: str = "blk_air"
    material: str = "Vacuum"
    margin_xy: ScalarExpr = "ms_air_margin"
    above: ScalarExpr = "ms_air_above"
    below: ScalarExpr = "ms_air_below"
    create_z_ports: bool = False
    port_modes: int = 1


@dataclass
class CstSimulationConfig:
    """Optional simulation setup and solve controls."""

    enabled: bool = False
    solver_domain: str = "frequency"
    solver_type: Optional[str] = None
    boundary_condition: tuple[str, str, str, str, str, str] = (
        "expanded open",
        "expanded open",
        "expanded open",
        "expanded open",
        "expanded open",
        "expanded open",
    )
    symmetry_plane: tuple[str, str, str] = ("none", "none", "none")
    boundary_apply_in_all_directions: bool = False
    boundary_space: tuple[ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr] = (
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    )
    background_type: Optional[str] = None
    background_epsilon: Optional[ScalarExpr] = None
    background_mu: Optional[ScalarExpr] = None
    background_kappa: Optional[ScalarExpr] = None
    background_tan_d: Optional[ScalarExpr] = None
    background_apply_in_all_directions: bool = False
    background_extra_vba: tuple[str, ...] = ()
    plane_wave_cfg: Optional["CstPlaneWaveConfig"] = None
    auto_symmetry_from_plane_wave: bool = False
    symmetry_plane_on_min_boundaries: bool = False
    frequency_start: Optional[float] = None
    frequency_stop: Optional[float] = None
    wavelength_start_m: Optional[float] = None
    wavelength_stop_m: Optional[float] = None
    monitors: tuple["CstMonitorConfig", ...] = ()
    fd_tet_order: str = "First"
    fd_mesh_adaptation: bool = False
    compute_yz_matrices: bool = False
    run_solver: bool = False


@dataclass
class CstField2DPlaneExportConfig:
    """Configuration for one 3D-field export onto a 2D plane (HDF5)."""

    enabled: bool = True
    tree_path: str = r"2D/3D Results\E-Field\e-field (f=500) [1]"
    output_name: Optional[str | Path] = None
    normal_axis: str = "z"
    plane_coordinate: ScalarExpr = 0.0
    step: ScalarExpr = 0.0
    component: str = "Abs"
    visualization_plot_type: str = "contour"
    visualization_scale: str = "max"
    export_coordinates_in_meter: bool = False
    extra_vba: tuple[str, ...] = ()


@dataclass
class CstResultExportConfig:
    """Optional post-solve result export (1D CSV and/or 2D-plane HDF5 fields)."""

    enabled: bool = False
    tree_paths: list[str] = field(
        default_factory=lambda: [
            r"1D Results\S-Parameters\S1,1",
            r"1D Results\S-Parameters\S2,1",
            r"1D Results\S-Parameters\S1,2",
            r"1D Results\S-Parameters\S2,2",
        ]
    )
    output_dir: Optional[str | Path] = None
    field_2d_plane_exports: tuple[CstField2DPlaneExportConfig, ...] = ()
    defer_until_solver_run: bool = False


@dataclass
class CstPlaneWaveConfig:
    """Optional plane-wave setup.

    Two source modes are supported:
    - ``floquet``: periodic/unit-cell excitation via ``With FloquetPort``.
    - ``source``: full-model excitation via ``With PlaneWave``.
    """

    enabled: bool = False
    source_mode: str = "floquet"
    theta_deg: ScalarExpr = 0.0
    phi_deg: ScalarExpr = 0.0
    polarization: str = "linear_x"
    linear_polarization_angle_deg: ScalarExpr = 0.0
    polarization_independent_of_scan_angle_phi: bool = False
    sort_code: str = "+beta/pw"
    customized_list_flag: bool = False
    number_of_modes_considered: int = 2
    distance_to_reference_plane: ScalarExpr = 0.0
    port_at_zmin: bool = True
    port_at_zmax: bool = True
    use_circular_polarization: Optional[bool] = None
    normal_vector: tuple[ScalarExpr, ScalarExpr, ScalarExpr] = (0.0, 0.0, 1.0)
    e_vector: tuple[ScalarExpr, ScalarExpr, ScalarExpr] = (1.0, 0.0, 0.0)
    source_polarization: str = "Linear"
    reference_frequency: Optional[ScalarExpr] = None
    phase_difference_deg: ScalarExpr = -90.0
    circular_direction: str = "Left"
    axial_ratio: ScalarExpr = 0.0
    user_decoupling_plane: bool = False


@dataclass
class CstMonitorConfig:
    """Frequency-domain monitor definition."""

    name: str
    field_type: str
    monitor_value: ScalarExpr
    domain: str = "Frequency"
    value_property: str = "MonitorValue"
    dimension: Optional[str] = "Volume"
    use_subvolume: Optional[bool] = False
    coordinates: Optional[str] = None
    subvolume: Optional[tuple[ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr]] = None
    subvolume_offset: Optional[tuple[ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr]] = None
    extra_vba: tuple[str, ...] = ()


class _SingleLineStepProgress:
    """Single-line terminal progress helper for CST automation."""

    def __init__(
        self,
        *,
        total_steps: int,
        enabled: bool,
        bar_width: int = 28,
    ):
        self.enabled = bool(enabled)
        self.total_steps = max(int(total_steps), 1)
        self.bar_width = max(int(bar_width), 10)
        self.completed_steps = 0
        self.current_step_name = ""
        self.current_step_index = 0
        self.current_step_fraction = 0.0
        self.detail = ""
        self._last_line_len = 0

    def begin_step(self, name: str, detail: Optional[str] = None):
        self.current_step_name = str(name)
        self.current_step_index = min(self.completed_steps + 1, self.total_steps)
        self.current_step_fraction = 0.0
        self.detail = "" if detail is None else str(detail)
        self._render()

    def update_step(self, fraction: float, detail: Optional[str] = None):
        if detail is not None:
            self.detail = str(detail)
        self.current_step_fraction = min(max(float(fraction), 0.0), 1.0)
        self._render()

    def complete_step(self, detail: Optional[str] = None):
        if detail is not None:
            self.detail = str(detail)
        self.current_step_fraction = 1.0
        self.completed_steps = min(self.completed_steps + 1, self.total_steps)
        self._render()
        self.current_step_fraction = 0.0

    def close(self):
        if not self.enabled:
            return
        if self._last_line_len > 0:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._last_line_len = 0

    def _render(self):
        if not self.enabled:
            return

        completed_float = min(
            float(self.completed_steps) + float(self.current_step_fraction),
            float(self.total_steps),
        )
        progress = completed_float / float(self.total_steps)
        filled = int(round(progress * self.bar_width))
        filled = min(max(filled, 0), self.bar_width)
        bar = ("#" * filled) + ("-" * (self.bar_width - filled))

        current_label = self.current_step_name or "idle"
        remaining_steps = max(self.total_steps - self.current_step_index, 0)
        line = (
            f"[{bar}] {progress * 100.0:6.2f}% "
            f"current step {self.current_step_index}/{self.total_steps}: {current_label} "
            f"| remaining steps: {remaining_steps}"
        )
        if self.detail:
            line += f" | {self.detail}"

        pad = " " * max(self._last_line_len - len(line), 0)
        sys.stdout.write(f"\r{line}{pad}")
        sys.stdout.flush()
        self._last_line_len = len(line)


def _build_full_automation_step_names(
    *,
    has_materials: bool,
    has_airbox: bool,
    has_simulation: bool,
    will_run_solver: bool,
    will_export_results: bool,
) -> list[str]:
    steps = [
        "prepare geometry table",
        "connect to CST",
        "load or create project",
        "set CST units",
    ]
    if has_materials:
        steps.append("define materials")
    steps.extend(
        (
            "set project parameters",
            "build cylinders",
        )
    )
    if has_airbox:
        steps.append("create airbox/ports")
    if has_simulation:
        steps.append("setup simulation")
    steps.append("save project")
    if will_run_solver:
        steps.append("run solver")
        steps.append("save solved project")
    if will_export_results:
        steps.append("export results")
    return steps


def _require_cst_interface():
    try:
        import cst.interface as cst_interface
    except ImportError as exc:
        raise ImportError(
            "The `cst` Python package (from CST Studio Suite) is required for CST automation."
        ) from exc
    return cst_interface


def _call_first(obj, method_names: Sequence[str], *args, **kwargs):
    for name in method_names:
        method = getattr(obj, name, None)
        if callable(method):
            return method(*args, **kwargs)
    raise AttributeError(
        f"None of the methods {list(method_names)} were found on object type {type(obj)!r}."
    )


def _auto_accept_cst_education_dialog(timeout_s: float = 90.0, poll_s: float = 0.2) -> bool:
    """Best-effort Windows UI helper to accept CST Education popup automatically."""
    if platform.system().lower() != "windows":
        return False

    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return False

    user32 = ctypes.windll.user32
    BM_CLICK = 0x00F5
    WM_COMMAND = 0x0111
    WM_KEYDOWN = 0x0100
    WM_KEYUP = 0x0101
    VK_RETURN = 0x0D
    VK_SPACE = 0x20
    keywords = (
        "education version",
        "non-commercial use only",
        "non commercial use only",
        "for non-commercial use only",
        "educational",
        "student version",
    )

    def _window_text(hwnd) -> str:
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return ""
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        return buffer.value

    def _window_size(hwnd) -> tuple[int, int]:
        rect = wintypes.RECT()
        if user32.GetWindowRect(hwnd, ctypes.byref(rect)) == 0:
            return (0, 0)
        return (int(rect.right - rect.left), int(rect.bottom - rect.top))

    def _child_texts(hwnd) -> list[str]:
        texts: list[str] = []
        enum_child_cb = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

        def _enum_child(child_hwnd, _):
            txt = _window_text(child_hwnd).strip()
            if txt:
                texts.append(txt)
            return True

        user32.EnumChildWindows(hwnd, enum_child_cb(_enum_child), 0)
        return texts

    def _click_ok(hwnd) -> bool:
        clicked = False
        enum_child_cb = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        button_candidates = {"ok", "&ok", "yes", "&yes", "continue", "&continue", "accept", "&accept"}

        def _enum_child(child_hwnd, _):
            nonlocal clicked
            txt = _window_text(child_hwnd).strip().lower()
            if txt in button_candidates:
                user32.SendMessageW(child_hwnd, BM_CLICK, 0, 0)
                clicked = True
                return False
            return True

        user32.EnumChildWindows(hwnd, enum_child_cb(_enum_child), 0)
        if clicked:
            return True

        # Fallback path for custom/Qt dialogs.
        # 1) standard dialog OK command
        user32.PostMessageW(hwnd, WM_COMMAND, 1, 0)  # IDOK=1
        # 2) keyboard fallback
        user32.SetForegroundWindow(hwnd)
        user32.PostMessageW(hwnd, WM_KEYDOWN, VK_RETURN, 0)
        user32.PostMessageW(hwnd, WM_KEYUP, VK_RETURN, 0)
        user32.PostMessageW(hwnd, WM_KEYDOWN, VK_SPACE, 0)
        user32.PostMessageW(hwnd, WM_KEYUP, VK_SPACE, 0)
        return True

    deadline = time.time() + max(float(timeout_s), 0.0)
    enum_window_cb = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    while time.time() < deadline:
        accepted = False

        def _enum_window(hwnd, _):
            nonlocal accepted
            if not user32.IsWindowVisible(hwnd):
                return True
            title = _window_text(hwnd).strip().lower()
            text_blob = " ".join([title, *_child_texts(hwnd)]).lower()
            width, height = _window_size(hwnd)
            looks_like_small_cst_dialog = (
                "cst studio suite" in title and 100 <= width <= 900 and 60 <= height <= 500
            )
            if any(key in text_blob for key in keywords) or looks_like_small_cst_dialog:
                accepted = _click_ok(hwnd)
                return False
            return True

        user32.EnumWindows(enum_window_cb(_enum_window), 0)
        if accepted:
            return True
        time.sleep(max(float(poll_s), 0.05))

    return False


def connect_cst(session_cfg: Optional[CstSessionConfig] = None):
    session_cfg = session_cfg or CstSessionConfig()
    cst_interface = _require_cst_interface()

    watcher = None
    if session_cfg.auto_accept_education_dialog:
        watcher = threading.Thread(
            target=_auto_accept_cst_education_dialog,
            args=(float(session_cfg.education_dialog_timeout_s),),
            daemon=True,
        )
        watcher.start()

    if session_cfg.attach_to_existing:
        for class_method in ("connect_to_any_or_new", "connect_to_any"):
            fn = getattr(cst_interface.DesignEnvironment, class_method, None)
            if callable(fn):
                de = fn()
                if watcher is not None:
                    watcher.join(timeout=0.5)
                return de

    de = cst_interface.DesignEnvironment()
    if watcher is not None:
        watcher.join(timeout=0.5)
    return de


def load_or_create_cst_project(design_environment, template_cst: Optional[str | Path] = None):
    if template_cst:
        path = str(Path(template_cst).expanduser().resolve())
        return _call_first(
            design_environment,
            ("open_project", "openFile", "open_mws"),
            path,
        )

    return _call_first(
        design_environment,
        ("new_mws", "new_project", "new_microwave_studio_project"),
    )


def _format_number(value: float) -> str:
    return f"{float(value):.12g}"


def _is_numeric(value) -> bool:
    return isinstance(value, (int, float, np.integer, np.floating))


def _format_expr(value: ScalarExpr) -> str:
    if _is_numeric(value):
        return _format_number(float(value))
    return str(value)


def _escape_vba_string(value: str) -> str:
    return str(value).replace('"', '""')


def _to_vba_bool(value: bool) -> str:
    return "TRUE" if bool(value) else "FALSE"


def _try_parse_scalar_expr_to_float(value: ScalarExpr) -> Optional[float]:
    if _is_numeric(value):
        return float(value)
    text = str(value).strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _normalize_plane_wave_polarization_name(name: str) -> str:
    token = str(name).strip().lower()
    aliases = {
        "x": "linear_x",
        "linear_x": "linear_x",
        "x-pol": "linear_x",
        "x_pol": "linear_x",
        "y": "linear_y",
        "linear_y": "linear_y",
        "y-pol": "linear_y",
        "y_pol": "linear_y",
        "linear": "linear_angle",
        "linear_angle": "linear_angle",
        "custom": "linear_angle",
        "circular": "circular",
        "rhcp": "circular",
        "lhcp": "circular",
    }
    return aliases.get(token, token)


def _normalize_plane_wave_source_mode(mode: str) -> str:
    token = str(mode).strip().lower()
    aliases = {
        "floquet": "floquet",
        "port": "floquet",
        "unitcell": "floquet",
        "unit_cell": "floquet",
        "unit-cell": "floquet",
        "source": "source",
        "plane_wave": "source",
        "plane wave": "source",
        "planewave": "source",
        "full_model": "source",
        "full-model": "source",
    }
    return aliases.get(token, token)


def _normalize_source_polarization_name(name: str) -> str:
    token = str(name).strip().lower()
    aliases = {
        "linear": "linear",
        "lin": "linear",
        "circular": "circular",
        "circ": "circular",
    }
    return aliases.get(token, token)


def _format_xyz_vector(
    values: tuple[ScalarExpr, ScalarExpr, ScalarExpr],
    *,
    field_name: str,
) -> tuple[str, str, str]:
    if len(values) != 3:
        raise ValueError(f"{field_name} must contain exactly 3 entries: (x, y, z).")
    return tuple(_escape_vba_string(_format_expr(v)) for v in values)


def _infer_symmetry_plane_from_plane_wave(
    plane_wave_cfg: CstPlaneWaveConfig,
    *,
    angle_tol_deg: float = 1.0e-9,
) -> Optional[tuple[str, str, str]]:
    theta = _try_parse_scalar_expr_to_float(plane_wave_cfg.theta_deg)
    if theta is not None:
        theta_normalized = abs(((theta + 180.0) % 360.0) - 180.0)
        if theta_normalized > angle_tol_deg:
            return None

    pol_mode = _normalize_plane_wave_polarization_name(plane_wave_cfg.polarization)
    if pol_mode == "linear_x":
        return ("electric", "magnetic", "none")
    if pol_mode == "linear_y":
        return ("magnetic", "electric", "none")
    if pol_mode == "linear_angle":
        angle = _try_parse_scalar_expr_to_float(plane_wave_cfg.linear_polarization_angle_deg)
        if angle is None:
            return None
        folded = abs(angle) % 180.0
        if min(abs(folded - 0.0), abs(folded - 180.0)) <= angle_tol_deg:
            return ("electric", "magnetic", "none")
        if abs(folded - 90.0) <= angle_tol_deg:
            return ("magnetic", "electric", "none")

    source_mode = _normalize_plane_wave_source_mode(plane_wave_cfg.source_mode)
    source_pol = _normalize_source_polarization_name(plane_wave_cfg.source_polarization)
    if source_mode == "source" and source_pol == "linear":
        ex = _try_parse_scalar_expr_to_float(plane_wave_cfg.e_vector[0])
        ey = _try_parse_scalar_expr_to_float(plane_wave_cfg.e_vector[1])
        ez = _try_parse_scalar_expr_to_float(plane_wave_cfg.e_vector[2])
        if ex is not None and ey is not None and ez is not None:
            if abs(ez) > angle_tol_deg:
                return None
            if abs(ex) > angle_tol_deg and abs(ey) <= angle_tol_deg:
                return ("electric", "magnetic", "none")
            if abs(ey) > angle_tol_deg and abs(ex) <= angle_tol_deg:
                return ("magnetic", "electric", "none")
    return None


def _build_floquet_plane_wave_vba(plane_wave_cfg: CstPlaneWaveConfig) -> str:
    if not (plane_wave_cfg.port_at_zmin or plane_wave_cfg.port_at_zmax):
        raise ValueError("At least one Floquet port must be enabled (zmin or zmax).")

    pol_mode = _normalize_plane_wave_polarization_name(plane_wave_cfg.polarization)
    if plane_wave_cfg.use_circular_polarization is None:
        use_circular = pol_mode == "circular"
    else:
        use_circular = bool(plane_wave_cfg.use_circular_polarization)

    if pol_mode == "linear_y":
        polarization_angle: ScalarExpr = 90.0
    elif pol_mode == "linear_angle":
        polarization_angle = plane_wave_cfg.linear_polarization_angle_deg
    else:
        polarization_angle = 0.0

    lines = [
        "With FloquetPort",
        "    .Reset",
        f'    .SetDialogTheta "{_escape_vba_string(_format_expr(plane_wave_cfg.theta_deg))}"',
        f'    .SetDialogPhi "{_escape_vba_string(_format_expr(plane_wave_cfg.phi_deg))}"',
        (
            "    .SetPolarizationIndependentOfScanAnglePhi "
            f'"{_escape_vba_string(_format_expr(polarization_angle))}", '
            f'"{_to_vba_bool(plane_wave_cfg.polarization_independent_of_scan_angle_phi)}"'
        ),
        f'    .SetSortCode "{_escape_vba_string(plane_wave_cfg.sort_code)}"',
        f'    .SetCustomizedListFlag "{_to_vba_bool(plane_wave_cfg.customized_list_flag)}"',
    ]

    for port_name, enabled in (("Zmin", plane_wave_cfg.port_at_zmin), ("Zmax", plane_wave_cfg.port_at_zmax)):
        if not enabled:
            continue
        lines.extend(
            (
                f'    .Port "{port_name}"',
                f'    .SetNumberOfModesConsidered "{int(plane_wave_cfg.number_of_modes_considered)}"',
                (
                    "    .SetDistanceToReferencePlane "
                    f'"{_escape_vba_string(_format_expr(plane_wave_cfg.distance_to_reference_plane))}"'
                ),
                f'    .SetUseCircularPolarization "{_to_vba_bool(use_circular)}"',
            )
        )

    lines.append("End With")
    return "\n".join(lines)


def _build_plane_wave_source_vba(
    plane_wave_cfg: CstPlaneWaveConfig,
    *,
    default_reference_frequency: Optional[ScalarExpr] = None,
) -> str:
    normal_x, normal_y, normal_z = _format_xyz_vector(
        plane_wave_cfg.normal_vector,
        field_name="normal_vector",
    )
    e_x, e_y, e_z = _format_xyz_vector(
        plane_wave_cfg.e_vector,
        field_name="e_vector",
    )
    reference_frequency = plane_wave_cfg.reference_frequency
    if reference_frequency is None:
        reference_frequency = default_reference_frequency
    if reference_frequency is None:
        raise ValueError(
            "Plane-wave source mode requires reference_frequency, or a "
            "default_reference_frequency passed by setup."
        )

    lines = [
        "With PlaneWave",
        "    .Reset",
        f'    .Normal "{normal_x}", "{normal_y}", "{normal_z}"',
        f'    .EVector "{e_x}", "{e_y}", "{e_z}"',
        f'    .Polarization "{_escape_vba_string(plane_wave_cfg.source_polarization)}"',
        f'    .ReferenceFrequency "{_escape_vba_string(_format_expr(reference_frequency))}"',
        f'    .PhaseDifference "{_escape_vba_string(_format_expr(plane_wave_cfg.phase_difference_deg))}"',
        f'    .CircularDirection "{_escape_vba_string(plane_wave_cfg.circular_direction)}"',
        f'    .AxialRatio "{_escape_vba_string(_format_expr(plane_wave_cfg.axial_ratio))}"',
        f'    .SetUserDecouplingPlane "{_to_vba_bool(plane_wave_cfg.user_decoupling_plane)}"',
        "    .Store",
        "End With",
    ]
    return "\n".join(lines)


def _build_plane_wave_vba(
    plane_wave_cfg: CstPlaneWaveConfig,
    *,
    default_reference_frequency: Optional[ScalarExpr] = None,
) -> str:
    source_mode = _normalize_plane_wave_source_mode(plane_wave_cfg.source_mode)
    if source_mode == "floquet":
        return _build_floquet_plane_wave_vba(plane_wave_cfg)
    if source_mode == "source":
        return _build_plane_wave_source_vba(
            plane_wave_cfg,
            default_reference_frequency=default_reference_frequency,
        )
    raise ValueError(
        f"Unsupported plane-wave source_mode '{plane_wave_cfg.source_mode}'. "
        "Use 'floquet' or 'source'."
    )


def _normalize_monitor_value_property(name: str) -> str:
    token = str(name).strip().lower()
    aliases = {
        "monitorvalue": "MonitorValue",
        "monitor_value": "MonitorValue",
        "value": "MonitorValue",
        "frequency": "Frequency",
    }
    if token in aliases:
        return aliases[token]
    raise ValueError(
        f"Unsupported monitor value_property '{name}'. "
        "Use 'MonitorValue' or 'Frequency'."
    )


def _format_xyz6_values(
    values: tuple[ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr],
    *,
    field_name: str,
) -> tuple[str, str, str, str, str, str]:
    if len(values) != 6:
        raise ValueError(f"{field_name} must contain exactly 6 entries.")
    return tuple(_escape_vba_string(_format_expr(v)) for v in values)


def _build_monitor_vba(monitor: CstMonitorConfig) -> str:
    value_property = _normalize_monitor_value_property(monitor.value_property)
    lines = [
        "With Monitor",
        "    .Reset",
        f'    .Name "{_escape_vba_string(monitor.name)}"',
    ]
    if monitor.dimension is not None:
        lines.append(f'    .Dimension "{_escape_vba_string(monitor.dimension)}"')
    if monitor.domain is not None:
        lines.append(f'    .Domain "{_escape_vba_string(monitor.domain)}"')
    lines.append(f'    .FieldType "{_escape_vba_string(monitor.field_type)}"')
    lines.append(
        f'    .{value_property} "{_escape_vba_string(_format_expr(monitor.monitor_value))}"'
    )
    if monitor.use_subvolume is not None:
        lines.append(f'    .UseSubvolume "{_to_vba_bool(monitor.use_subvolume)}"')
    if monitor.coordinates is not None:
        lines.append(f'    .Coordinates "{_escape_vba_string(monitor.coordinates)}"')
    if monitor.subvolume is not None:
        x0, x1, y0, y1, z0, z1 = _format_xyz6_values(
            monitor.subvolume,
            field_name="subvolume",
        )
        lines.append(f'    .SetSubvolume "{x0}", "{x1}", "{y0}", "{y1}", "{z0}", "{z1}"')
    if monitor.subvolume_offset is not None:
        x0, x1, y0, y1, z0, z1 = _format_xyz6_values(
            monitor.subvolume_offset,
            field_name="subvolume_offset",
        )
        lines.append(
            f'    .SetSubvolumeOffset "{x0}", "{x1}", "{y0}", "{y1}", "{z0}", "{z1}"'
        )
    for cmd in monitor.extra_vba:
        normalized = str(cmd).strip()
        if not normalized:
            continue
        if not normalized.startswith("."):
            normalized = f".{normalized}"
        lines.append(f"    {normalized}")
    lines.append("    .Create")
    lines.append("End With")
    return "\n".join(lines)


def _get_history_writer(project) -> Callable[[str, str], None]:
    model3d = getattr(project, "model3d", None)
    add_to_history = getattr(model3d, "add_to_history", None) if model3d is not None else None
    if callable(add_to_history):
        return add_to_history

    add_to_history = getattr(project, "add_to_history", None)
    if callable(add_to_history):
        return add_to_history

    schematic = getattr(project, "schematic", None)
    exec_vba = getattr(schematic, "execute_vba_code", None) if schematic is not None else None
    if callable(exec_vba):

        def _writer(_label: str, vba_body: str):
            wrapped = "\n".join(("Sub Main()", vba_body, "End Sub"))
            exec_vba(wrapped)

        return _writer

    raise AttributeError(
        "Unable to find a CST history writer. Expected one of: "
        "`project.model3d.add_to_history`, `project.add_to_history`, "
        "or `project.schematic.execute_vba_code`."
    )


def _add_to_history(project, label: str, vba_body: str):
    writer = _get_history_writer(project)
    writer(label, vba_body)


def _build_units_vba(length_unit: str, frequency_unit: str, time_unit: str) -> str:
    return "\n".join(
        (
            "With Units",
            f'    .Geometry "{_escape_vba_string(length_unit)}"',
            f'    .Frequency "{_escape_vba_string(frequency_unit)}"',
            f'    .Time "{_escape_vba_string(time_unit)}"',
            "End With",
        )
    )


def _build_brick_vba(
    *,
    name: str,
    component: str,
    material: str,
    x_range: tuple[ScalarExpr, ScalarExpr],
    y_range: tuple[ScalarExpr, ScalarExpr],
    z_range: tuple[ScalarExpr, ScalarExpr],
) -> str:
    x0, x1 = x_range
    y0, y1 = y_range
    z0, z1 = z_range
    return "\n".join(
        (
            "With Brick",
            "    .Reset",
            f'    .Name "{_escape_vba_string(name)}"',
            f'    .Component "{_escape_vba_string(component)}"',
            f'    .Material "{_escape_vba_string(material)}"',
            f'    .Xrange "{_escape_vba_string(_format_expr(x0))}", "{_escape_vba_string(_format_expr(x1))}"',
            f'    .Yrange "{_escape_vba_string(_format_expr(y0))}", "{_escape_vba_string(_format_expr(y1))}"',
            f'    .Zrange "{_escape_vba_string(_format_expr(z0))}", "{_escape_vba_string(_format_expr(z1))}"',
            "    .Create",
            "End With",
        )
    )


def _build_cylinder_vba(
    *,
    name: str,
    component: str,
    material: str,
    center: tuple[ScalarExpr, ScalarExpr, ScalarExpr],
    radius: ScalarExpr,
    z_range: tuple[ScalarExpr, ScalarExpr],
    axis: str = "z",
) -> str:
    axis = str(axis).strip().lower()
    if axis not in {"x", "y", "z"}:
        raise ValueError("axis must be one of {'x', 'y', 'z'}.")

    x0, y0, z0 = center
    zmin, zmax = z_range
    return "\n".join(
        (
            "With Cylinder",
            "    .Reset",
            f'    .Name "{_escape_vba_string(name)}"',
            f'    .Component "{_escape_vba_string(component)}"',
            f'    .Material "{_escape_vba_string(material)}"',
            f'    .Axis "{axis}"',
            f'    .Xcenter "{_escape_vba_string(_format_expr(x0))}"',
            f'    .Ycenter "{_escape_vba_string(_format_expr(y0))}"',
            f'    .Zcenter "{_escape_vba_string(_format_expr(z0))}"',
            f'    .OuterRadius "{_escape_vba_string(_format_expr(radius))}"',
            '    .InnerRadius "0"',
            f'    .Zrange "{_escape_vba_string(_format_expr(zmin))}", "{_escape_vba_string(_format_expr(zmax))}"',
            "    .Segments \"0\"",
            "    .Create",
            "End With",
        )
    )


def _build_solid_subtract_vba(*, target: str, tool: str) -> str:
    return (
        f'Solid.Subtract "{_escape_vba_string(target)}", '
        f'"{_escape_vba_string(tool)}"'
    )


def _build_material_vba(material: CstMaterialConfig) -> str:
    r, g, b = material.color_rgb
    return "\n".join(
        (
            "With Material",
            "    .Reset",
            f'    .Name "{_escape_vba_string(material.name)}"',
            '    .Folder ""',
            '    .Type "Normal"',
            f'    .Epsilon "{_escape_vba_string(_format_expr(material.epsilon))}"',
            f'    .Mue "{_escape_vba_string(_format_expr(material.mu))}"',
            f'    .Kappa "{_escape_vba_string(_format_expr(material.kappa))}"',
            f'    .TanD "{_escape_vba_string(_format_expr(material.tan_d))}"',
            f'    .Colour "{_format_number(r)}", "{_format_number(g)}", "{_format_number(b)}"',
            "    .Create",
            "End With",
        )
    )


def _build_boundary_condition_vba(
    boundary_condition: tuple[str, str, str, str, str, str],
    symmetry_plane: tuple[str, str, str] = ("none", "none", "none"),
    apply_in_all_directions: bool = False,
) -> str:
    if len(symmetry_plane) != 3:
        raise ValueError("symmetry_plane must contain exactly 3 entries: (x, y, z).")

    xmin, xmax, ymin, ymax, zmin, zmax = boundary_condition
    x_sym, y_sym, z_sym = symmetry_plane
    return "\n".join(
        (
            "With Boundary",
            f'    .Xmin "{_escape_vba_string(xmin)}"',
            f'    .Xmax "{_escape_vba_string(xmax)}"',
            f'    .Ymin "{_escape_vba_string(ymin)}"',
            f'    .Ymax "{_escape_vba_string(ymax)}"',
            f'    .Zmin "{_escape_vba_string(zmin)}"',
            f'    .Zmax "{_escape_vba_string(zmax)}"',
            f'    .Xsymmetry "{_escape_vba_string(x_sym)}"',
            f'    .Ysymmetry "{_escape_vba_string(y_sym)}"',
            f'    .Zsymmetry "{_escape_vba_string(z_sym)}"',
            f'    .ApplyInAllDirections "{_to_vba_bool(apply_in_all_directions)}"',
            "End With",
        )
    )


def _build_boundary_space_vba(
    boundary_space: tuple[ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr, ScalarExpr],
    *,
    background_type: Optional[str] = None,
    background_epsilon: Optional[ScalarExpr] = None,
    background_mu: Optional[ScalarExpr] = None,
    background_kappa: Optional[ScalarExpr] = None,
    background_tan_d: Optional[ScalarExpr] = None,
    apply_in_all_directions: bool = False,
    extra_vba: Sequence[str] = (),
) -> str:
    xmin, xmax, ymin, ymax, zmin, zmax = boundary_space
    lines = [
        "With Background",
        "    .ResetBackground",
        f'    .XminSpace "{_escape_vba_string(_format_expr(xmin))}"',
        f'    .XmaxSpace "{_escape_vba_string(_format_expr(xmax))}"',
        f'    .YminSpace "{_escape_vba_string(_format_expr(ymin))}"',
        f'    .YmaxSpace "{_escape_vba_string(_format_expr(ymax))}"',
        f'    .ZminSpace "{_escape_vba_string(_format_expr(zmin))}"',
        f'    .ZmaxSpace "{_escape_vba_string(_format_expr(zmax))}"',
    ]

    if background_type is not None:
        lines.append(f'    .Type "{_escape_vba_string(background_type)}"')
    if background_epsilon is not None:
        lines.append(f'    .Epsilon "{_escape_vba_string(_format_expr(background_epsilon))}"')
    if background_mu is not None:
        lines.append(f'    .Mue "{_escape_vba_string(_format_expr(background_mu))}"')
    if background_kappa is not None:
        lines.append(f'    .Kappa "{_escape_vba_string(_format_expr(background_kappa))}"')
    if background_tan_d is not None:
        lines.append(f'    .TanD "{_escape_vba_string(_format_expr(background_tan_d))}"')
    for cmd in extra_vba:
        normalized = str(cmd).strip()
        if not normalized:
            continue
        if not normalized.startswith("."):
            normalized = f".{normalized}"
        lines.append(f"    {normalized}")

    lines.append(f'    .ApplyInAllDirections "{_to_vba_bool(apply_in_all_directions)}"')
    lines.append("End With")
    return "\n".join(lines)


def _build_waveguide_port_vba(
    *,
    port_number: int,
    orientation: str,
    xrange: tuple[ScalarExpr, ScalarExpr],
    yrange: tuple[ScalarExpr, ScalarExpr],
    zrange: tuple[ScalarExpr, ScalarExpr],
    modes: int = 1,
) -> str:
    return "\n".join(
        (
            "With Port",
            "    .Reset",
            f'    .PortNumber "{int(port_number)}"',
            f'    .NumberOfModes "{int(modes)}"',
            '    .Coordinates "Free"',
            f'    .Orientation "{_escape_vba_string(orientation)}"',
            '    .PortOnBound "True"',
            f'    .Xrange "{_escape_vba_string(_format_expr(xrange[0]))}", "{_escape_vba_string(_format_expr(xrange[1]))}"',
            f'    .Yrange "{_escape_vba_string(_format_expr(yrange[0]))}", "{_escape_vba_string(_format_expr(yrange[1]))}"',
            f'    .Zrange "{_escape_vba_string(_format_expr(zrange[0]))}", "{_escape_vba_string(_format_expr(zrange[1]))}"',
            "    .Create",
            "End With",
        )
    )


def _frequency_scale_to_hz(frequency_unit: str) -> float:
    unit = str(frequency_unit).strip().lower()
    scales = {
        "hz": 1.0,
        "khz": 1e3,
        "mhz": 1e6,
        "ghz": 1e9,
        "thz": 1e12,
        "phz": 1e15,
    }
    if unit not in scales:
        raise ValueError(f"Unsupported frequency unit '{frequency_unit}'.")
    return scales[unit]


def _wavelength_m_to_frequency_unit_value(wavelength_m: float, frequency_unit: str) -> float:
    c0 = 299_792_458.0
    return (c0 / float(wavelength_m)) / _frequency_scale_to_hz(frequency_unit)


def _sanitize_result_filename(tree_path: str) -> str:
    bad = '<>:"/\\|?*'
    name = str(tree_path).strip().replace(" ", "_")
    for ch in bad:
        name = name.replace(ch, "_")
    return name


def _normalize_2d_plane_axis(axis: str) -> str:
    token = str(axis).strip().lower()
    aliases = {
        "x": "x",
        "y": "y",
        "z": "z",
    }
    if token in aliases:
        return aliases[token]
    raise ValueError(
        f"Unsupported normal_axis '{axis}'. Use one of: x, y, z."
    )


def _normalize_field_component(component: str) -> str:
    token = str(component).strip().lower()
    aliases = {
        "x": "X",
        "y": "Y",
        "z": "Z",
        "abs": "Abs",
        "magnitude": "Abs",
        "normal": "Normal",
        "tangential": "Tangential",
    }
    if token in aliases:
        return aliases[token]
    raise ValueError(
        f"Unsupported field component '{component}'. "
        "Use one of: X, Y, Z, Abs, Normal, Tangential."
    )


def _normalize_scalar_plot_type(plot_type: str) -> str:
    token = str(plot_type).strip().lower()
    aliases = {
        "contour": "contour",
        "surface": "surface",
    }
    if token in aliases:
        return aliases[token]
    raise ValueError(
        f"Unsupported visualization_plot_type '{plot_type}'. "
        "Use 'contour' or 'surface'."
    )


def _normalize_scalar_plot_scale(scale: str) -> bool:
    token = str(scale).strip().lower()
    aliases = {
        "max": True,
        "maximum": True,
        "amplitude": True,
        "absolute": True,
        "abs": True,
        "actual": False,
        "none": False,
        "current": False,
    }
    if token in aliases:
        return aliases[token]
    raise ValueError(
        f"Unsupported visualization_scale '{scale}'. "
        "Use 'max' or 'actual'."
    )


def _resolve_2d3d_field_tree_path(tree_path: str, component: Optional[str]) -> str:
    path = str(tree_path).strip()
    if not path:
        raise ValueError("tree_path must not be empty for 2D-plane field export.")

    root = "2D/3D Results"
    lower_path = path.lower()
    if lower_path.startswith("2d/3d results"):
        suffix = path[len(root):]
    elif lower_path.startswith(r"2d\3d results"):
        suffix = path[len(r"2D\3D Results"):]
    else:
        suffix = path.lstrip("\\/")
    suffix = suffix.replace("/", "\\")
    if suffix and not suffix.startswith("\\"):
        suffix = "\\" + suffix
    path = root + suffix

    known_components = {"x", "y", "z", "abs", "normal", "tangential"}
    parts = path.split("\\")
    if not parts:
        raise ValueError("tree_path must not be empty for 2D-plane field export.")

    if component is None:
        return path

    if parts[-1].strip().lower() in known_components:
        parts[-1] = component
    else:
        parts.append(component)
    return "\\".join(parts)


def _build_vba_scalar_expr(value: ScalarExpr) -> str:
    expr = _format_expr(value)
    parsed = _try_parse_scalar_expr_to_float(value)
    if parsed is not None:
        return _format_number(parsed)
    return f'Evaluate("{_escape_vba_string(expr)}")'


def _build_field_2d_plane_export_vba(
    export_cfg: CstField2DPlaneExportConfig,
    output_path: Path,
) -> tuple[str, str]:
    normal_axis = _normalize_2d_plane_axis(export_cfg.normal_axis)
    component = _normalize_field_component(export_cfg.component)
    tree_path = _resolve_2d3d_field_tree_path(export_cfg.tree_path, component)
    plot_type = _normalize_scalar_plot_type(export_cfg.visualization_plot_type)
    use_plot_amplitude = _normalize_scalar_plot_scale(export_cfg.visualization_scale)

    normals = {
        "x": (1.0, 0.0, 0.0),
        "y": (0.0, 1.0, 0.0),
        "z": (0.0, 0.0, 1.0),
    }
    nx, ny, nz = normals[normal_axis]
    coordinate_expr = _build_vba_scalar_expr(export_cfg.plane_coordinate)

    lines = [
        f'SelectTreeItem "{_escape_vba_string(tree_path)}"',
        "Plot3DPlotsOn2DPlane True",
        f'VectorPlot2D.PlaneNormal "{normal_axis}"',
        f'ScalarPlot2D.PlaneNormal "{normal_axis}"',
        f"VectorPlot2D.PlaneCoordinate {coordinate_expr}",
        f"ScalarPlot2D.PlaneCoordinate {coordinate_expr}",
        f'ScalarPlot2D.Type("{_escape_vba_string(plot_type)}")',
        f"ScalarPlot2D.PlotAmplitude({'True' if use_plot_amplitude else 'False'})",
        "With ASCIIExport",
        "    .Reset",
        (
            "    .DefinePlane("
            f"{_format_number(nx)}, {_format_number(ny)}, {_format_number(nz)}, {coordinate_expr})"
        ),
        '    .SetfileType "hdf5"',
        f'    .FileName "{_escape_vba_string(str(output_path))}"',
        '    .Mode ("Plane")',
        '    .Mode ("FixedWidth")',
    ]

    step_val = _try_parse_scalar_expr_to_float(export_cfg.step)
    if step_val is None or abs(float(step_val)) > 0.0:
        lines.append(f"    .Step ({_build_vba_scalar_expr(export_cfg.step)})")

    lines.append(
        "    .ExportCoordinatesInMeter "
        f"{'True' if export_cfg.export_coordinates_in_meter else 'False'}"
    )
    for cmd in export_cfg.extra_vba:
        normalized = str(cmd).strip()
        if not normalized:
            continue
        if not normalized.startswith("."):
            normalized = f".{normalized}"
        lines.append(f"    {normalized}")

    lines.extend(
        (
            "    .Execute",
            "End With",
        )
    )
    return tree_path, "\n".join(lines)


def _resolve_2d_plane_export_output_path(
    *,
    base_dir: Path,
    tree_path: str,
    output_name: Optional[str | Path],
) -> Path:
    if output_name is not None:
        out = Path(output_name)
        if not out.is_absolute():
            out = base_dir / out
    else:
        out = base_dir / f"{_sanitize_result_filename(tree_path)}.h5"

    if out.suffix.lower() not in {".h5", ".hdf5"}:
        out = out.with_suffix(".h5")
    return out


def _resolve_solver_type(sim_cfg: CstSimulationConfig) -> str:
    if sim_cfg.solver_type:
        return str(sim_cfg.solver_type)

    domain = str(sim_cfg.solver_domain).strip().lower()
    if domain in {"f", "freq", "frequency", "frequency-domain", "frequency domain"}:
        return "HF Frequency Domain"
    if domain in {"t", "time", "time-domain", "time domain", "td"}:
        return "HF Time Domain"
    raise ValueError(
        f"Unsupported solver_domain '{sim_cfg.solver_domain}'. "
        "Use 'frequency' or 'time', or set solver_type explicitly."
    )


def set_cst_units(project, cfg: Optional[CstMetasurfaceConfig] = None):
    cfg = cfg or CstMetasurfaceConfig()
    _add_to_history(
        project,
        "Set Units",
        _build_units_vba(cfg.length_unit, cfg.frequency_unit, cfg.time_unit),
    )


def set_cst_parameter(project, name: str, value: ScalarExpr):
    """Set one CST project parameter (visible in Parameter List)."""
    expr = _escape_vba_string(_format_expr(value))
    vba = f'StoreParameter "{_escape_vba_string(name)}", "{expr}"'
    _add_to_history(project, f"Set Parameter {name}", vba)


def set_cst_parameters(
    project,
    parameters: Mapping[str, ScalarExpr],
    rebuild_after: bool = False,
):
    """Set multiple CST project parameters in one history operation."""
    if not parameters:
        return

    lines = []
    for name, value in parameters.items():
        expr = _escape_vba_string(_format_expr(value))
        lines.append(f'StoreParameter "{_escape_vba_string(name)}", "{expr}"')
    if rebuild_after:
        lines.append("Rebuild")

    _add_to_history(project, "Set Parameters", "\n".join(lines))


def define_cst_material(project, material_cfg: CstMaterialConfig):
    """Create/update one material definition in CST."""
    _add_to_history(
        project,
        f"Define Material {material_cfg.name}",
        _build_material_vba(material_cfg),
    )


def define_cst_materials(project, material_cfgs: Sequence[CstMaterialConfig]):
    """Create/update multiple material definitions in CST."""
    for cfg in material_cfgs:
        define_cst_material(project, cfg)


def setup_cst_simulation(
    project,
    geom_cfg: CstMetasurfaceConfig,
    sim_cfg: Optional[CstSimulationConfig] = None,
):
    """Apply boundary/solver/frequency settings using CST history commands."""
    sim_cfg = sim_cfg or CstSimulationConfig()
    if not sim_cfg.enabled:
        return

    solver_type = _resolve_solver_type(sim_cfg)
    f_start = sim_cfg.frequency_start
    f_stop = sim_cfg.frequency_stop
    if f_start is None or f_stop is None:
        if sim_cfg.wavelength_start_m is not None and sim_cfg.wavelength_stop_m is not None:
            f0 = _wavelength_m_to_frequency_unit_value(sim_cfg.wavelength_start_m, geom_cfg.frequency_unit)
            f1 = _wavelength_m_to_frequency_unit_value(sim_cfg.wavelength_stop_m, geom_cfg.frequency_unit)
            f_start, f_stop = (min(f0, f1), max(f0, f1))

    if f_start is None or f_stop is None:
        raise ValueError(
            "Simulation frequency range is undefined. Provide either "
            "(frequency_start, frequency_stop) or (wavelength_start_m, wavelength_stop_m)."
        )

    effective_symmetry_plane = sim_cfg.symmetry_plane
    if (
        sim_cfg.auto_symmetry_from_plane_wave
        and sim_cfg.plane_wave_cfg is not None
        and sim_cfg.plane_wave_cfg.enabled
    ):
        inferred = _infer_symmetry_plane_from_plane_wave(sim_cfg.plane_wave_cfg)
        if inferred is not None:
            effective_symmetry_plane = inferred

    effective_boundary_condition = list(sim_cfg.boundary_condition)
    effective_symmetry_for_macro = effective_symmetry_plane
    if sim_cfg.symmetry_plane_on_min_boundaries:
        x_sym, y_sym, z_sym = effective_symmetry_plane
        if str(x_sym).strip().lower() != "none":
            effective_boundary_condition[0] = str(x_sym)
        if str(y_sym).strip().lower() != "none":
            effective_boundary_condition[2] = str(y_sym)
        if str(z_sym).strip().lower() != "none":
            effective_boundary_condition[4] = str(z_sym)
        effective_symmetry_for_macro = ("none", "none", "none")

    _add_to_history(
        project,
        "Set Boundary Conditions",
        _build_boundary_condition_vba(
            tuple(effective_boundary_condition),
            symmetry_plane=effective_symmetry_for_macro,
            apply_in_all_directions=sim_cfg.boundary_apply_in_all_directions,
        ),
    )
    _add_to_history(
        project,
        "Set Boundary Spaces",
        _build_boundary_space_vba(
            sim_cfg.boundary_space,
            background_type=sim_cfg.background_type,
            background_epsilon=sim_cfg.background_epsilon,
            background_mu=sim_cfg.background_mu,
            background_kappa=sim_cfg.background_kappa,
            background_tan_d=sim_cfg.background_tan_d,
            apply_in_all_directions=sim_cfg.background_apply_in_all_directions,
            extra_vba=sim_cfg.background_extra_vba,
        ),
    )
    _add_to_history(
        project,
        "Set Solver Type",
        f'ChangeSolverType "{_escape_vba_string(solver_type)}"',
    )
    _add_to_history(
        project,
        "Set Frequency Range",
        f'Solver.FrequencyRange "{_format_number(float(f_start))}", "{_format_number(float(f_stop))}"',
    )

    if sim_cfg.plane_wave_cfg is not None and sim_cfg.plane_wave_cfg.enabled:
        reference_frequency_default = 0.5 * (float(f_start) + float(f_stop))
        _add_to_history(
            project,
            "Setup Plane Wave",
            _build_plane_wave_vba(
                sim_cfg.plane_wave_cfg,
                default_reference_frequency=reference_frequency_default,
            ),
        )

    for monitor in sim_cfg.monitors:
        _add_to_history(
            project,
            f"Define Monitor: {monitor.name}",
            _build_monitor_vba(monitor),
        )

    if "frequency domain" in solver_type.lower():
        _add_to_history(
            project,
            "FDSolver Tet Order",
            f'FDSolver.OrderTet "{_escape_vba_string(sim_cfg.fd_tet_order)}"',
        )
        _add_to_history(
            project,
            "FDSolver Mesh Adaptation",
            f'FDSolver.MeshAdaptionTet "{str(bool(sim_cfg.fd_mesh_adaptation)).upper()}"',
        )

    if sim_cfg.compute_yz_matrices:
        _add_to_history(
            project,
            "PostProcess YZ Matrices",
            'PostProcess1D.ActivateOperation "yz-matrices", "TRUE"',
        )


def run_cst_solver(project):
    """Run CST solver if available from model3d API; fallback to VBA command."""
    model3d = getattr(project, "model3d", None)
    run_solver = getattr(model3d, "run_solver", None) if model3d is not None else None
    if callable(run_solver):
        run_solver()
        return
    _add_to_history(project, "Run Solver", "Solver.Start")


def extract_cst_1d_results(
    cst_path: str | Path,
    export_cfg: Optional[CstResultExportConfig] = None,
):
    """Extract 1D results from a saved .cst project and optionally export CSVs."""
    export_cfg = export_cfg or CstResultExportConfig()
    if not export_cfg.enabled:
        return {}

    try:
        import cst.results as cst_results
    except ImportError as exc:
        raise ImportError("cst.results is required for CST 1D result extraction.") from exc

    project_path = Path(cst_path).expanduser().resolve()
    pf = cst_results.ProjectFile(str(project_path), allow_interactive=True)
    model_3d = pf.get_3d()
    available = set(model_3d.get_tree_items())

    output_dir = (
        Path(export_cfg.output_dir).expanduser().resolve()
        if export_cfg.output_dir is not None
        else project_path.with_suffix("")
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    exported = {}
    for tree_path in export_cfg.tree_paths:
        if tree_path not in available:
            continue
        item = model_3d.get_result_item(tree_path)
        data = item.get_data()
        if not data:
            continue
        x_vals = np.asarray([pt[0] for pt in data], dtype=float)
        y_vals = np.asarray([pt[1] for pt in data])

        df = pd.DataFrame({"x": x_vals})
        if np.iscomplexobj(y_vals):
            df["y_real"] = np.real(y_vals)
            df["y_imag"] = np.imag(y_vals)
            df["y_abs"] = np.abs(y_vals)
            df["y_phase_rad"] = np.angle(y_vals)
        else:
            df["y"] = y_vals.astype(float)

        csv_path = output_dir / f"{_sanitize_result_filename(tree_path)}.csv"
        df.to_csv(csv_path, index=False)
        exported[tree_path] = str(csv_path)

    return exported


def export_cst_2d_plane_fields(
    project,
    cst_path: str | Path,
    export_cfg: Optional[CstResultExportConfig] = None,
):
    """Export configured 3D field results on 2D planes to HDF5."""
    export_cfg = export_cfg or CstResultExportConfig()
    if not export_cfg.enabled or not export_cfg.field_2d_plane_exports:
        return {}

    project_path = Path(cst_path).expanduser().resolve()
    output_dir = (
        Path(export_cfg.output_dir).expanduser().resolve()
        if export_cfg.output_dir is not None
        else project_path.with_suffix("")
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    exported = {}
    for index, cfg in enumerate(export_cfg.field_2d_plane_exports, start=1):
        if not cfg.enabled:
            continue

        component = _normalize_field_component(cfg.component)
        resolved_tree_path = _resolve_2d3d_field_tree_path(cfg.tree_path, component)
        output_path = _resolve_2d_plane_export_output_path(
            base_dir=output_dir,
            tree_path=resolved_tree_path,
            output_name=cfg.output_name,
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)

        resolved_tree_path, vba = _build_field_2d_plane_export_vba(cfg, output_path)
        _add_to_history(
            project,
            f"Export 2D Plane Field: {index}",
            vba,
        )
        exported[resolved_tree_path] = str(output_path)

    return exported


def export_cst_results_from_saved_project(
    cst_path: str | Path,
    export_cfg: Optional[CstResultExportConfig] = None,
    *,
    session_cfg: Optional[CstSessionConfig] = None,
    close_design_environment: bool = True,
):
    """Export configured results from an already solved/saved CST project."""
    export_cfg = export_cfg or CstResultExportConfig()
    if not export_cfg.enabled:
        return {}

    exported = {}
    if export_cfg.tree_paths:
        exported.update(extract_cst_1d_results(cst_path, export_cfg))

    if export_cfg.field_2d_plane_exports:
        env = None
        try:
            env = connect_cst(session_cfg or CstSessionConfig())
            project = load_or_create_cst_project(env, template_cst=cst_path)
            exported.update(export_cst_2d_plane_fields(project, cst_path, export_cfg))
        finally:
            if close_design_environment:
                close_fn = getattr(env, "close", None) if env is not None else None
                if callable(close_fn):
                    close_fn()

    return exported


def cst_add_brick(
    project,
    name: str,
    x_range: tuple[ScalarExpr, ScalarExpr],
    y_range: tuple[ScalarExpr, ScalarExpr],
    z_range: tuple[ScalarExpr, ScalarExpr],
    cfg: Optional[CstMetasurfaceConfig] = None,
    component: Optional[str] = None,
    material: Optional[str] = None,
):
    cfg = cfg or CstMetasurfaceConfig()
    component = component or cfg.component
    material = material or cfg.material
    vba = _build_brick_vba(
        name=name,
        component=component,
        material=material,
        x_range=(x_range[0], x_range[1]),
        y_range=(y_range[0], y_range[1]),
        z_range=(z_range[0], z_range[1]),
    )
    _add_to_history(project, f"Create Brick {name}", vba)


def cst_add_cylinder(
    project,
    name: str,
    center: tuple[ScalarExpr, ScalarExpr, ScalarExpr],
    radius: ScalarExpr,
    z_range: tuple[ScalarExpr, ScalarExpr],
    cfg: Optional[CstMetasurfaceConfig] = None,
    component: Optional[str] = None,
    material: Optional[str] = None,
    axis: str = "z",
):
    cfg = cfg or CstMetasurfaceConfig()
    component = component or cfg.component
    material = material or cfg.material

    if _is_numeric(radius):
        radius = float(radius)
        if radius <= 0.0:
            raise ValueError("radius must be > 0.")

    cx, cy, cz = center
    zmin, zmax = z_range
    vba = _build_cylinder_vba(
        name=name,
        component=component,
        material=material,
        center=(cx, cy, cz),
        radius=radius,
        z_range=(zmin, zmax),
        axis=axis,
    )
    _add_to_history(project, f"Create Cylinder {name}", vba)


def _build_cylinders_from_dataframe(
    project,
    data: pd.DataFrame,
    cfg: CstMetasurfaceConfig,
    *,
    radius_col: str,
    x_col: str,
    y_col: str,
    drop_nonpositive: bool,
    verbose: bool,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    progress_interval: int = 200,
    quarter: bool = False,
    include_symmetry_axes: bool = True,
    strict_delete_outside_symmetry: bool = False,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
    skipped_records: Optional[list[dict[str, float | int]]] = None,
) -> int:
    for required in (radius_col, x_col, y_col):
        if required not in data.columns:
            raise ValueError(f"Missing column '{required}' in input table.")

    zmin: ScalarExpr = cfg.z_base
    if _is_numeric(cfg.z_base) and _is_numeric(cfg.pillar_height):
        zmax: ScalarExpr = float(cfg.z_base) + float(cfg.pillar_height)
    else:
        zmax = f"({_format_expr(cfg.z_base)})+({_format_expr(cfg.pillar_height)})"
    created = 0
    source_rod_number = 0
    radius_values = data[radius_col].to_numpy(dtype=float)
    min_radius_value = None if min_radius is None else float(min_radius)
    if min_radius_value is not None and min_radius_value < 0.0:
        raise ValueError("min_radius must be >= 0.")

    include_mask = np.ones(len(radius_values), dtype=bool)
    if drop_nonpositive:
        include_mask &= radius_values > 0.0
    if min_radius_value is not None:
        include_mask &= radius_values >= min_radius_value
    total_cylinders = int(np.count_nonzero(include_mask))

    skipped_rows: list[dict[str, float | int]] = []
    update_every = max(int(progress_interval), 1)
    clip_tolerance = 1.0e-12
    clip_component = "__symmetry_clip_tmp"
    clip_counter = 0
    clip_helpers_used = False

    if progress_callback is not None:
        progress_callback(0, total_cylinders)

    for index, row in data.iterrows():
        radius = float(row[radius_col])
        if drop_nonpositive and radius <= 0.0:
            continue

        source_rod_number += 1
        name = f"{cfg.shape_prefix}_{source_rod_number}"
        if min_radius_value is not None and radius < min_radius_value:
            skipped_rows.append(
                {
                    "rod_number": int(source_rod_number),
                    "table_index": int(index),
                    "radius": float(radius),
                }
            )
            continue

        x_center = float(row[x_col])
        y_center = float(row[y_col])
        cst_add_cylinder(
            project=project,
            name=name,
            center=(x_center, y_center, zmin),
            radius=radius,
            z_range=(zmin, zmax),
            cfg=cfg,
            axis="z",
        )

        if quarter and include_symmetry_axes and strict_delete_outside_symmetry:
            target = f"{cfg.component}:{name}"
            x_min = x_center - radius
            y_min = y_center - radius
            x_max = x_center + radius
            y_max = y_center + radius

            if x_min < -clip_tolerance:
                cutter_name = f"clip_negx_{clip_counter}"
                clip_counter += 1
                clip_helpers_used = True
                cst_add_brick(
                    project=project,
                    name=cutter_name,
                    x_range=(x_min, 0.0),
                    y_range=(y_min, y_max),
                    z_range=(zmin, zmax),
                    cfg=cfg,
                    component=clip_component,
                )
                _add_to_history(
                    project,
                    f"Clip Outside Symmetry X {name}",
                    _build_solid_subtract_vba(
                        target=target,
                        tool=f"{clip_component}:{cutter_name}",
                    ),
                )

            if y_min < -clip_tolerance:
                cutter_name = f"clip_negy_{clip_counter}"
                clip_counter += 1
                clip_helpers_used = True
                cst_add_brick(
                    project=project,
                    name=cutter_name,
                    x_range=(max(x_min, 0.0), x_max),
                    y_range=(y_min, 0.0),
                    z_range=(zmin, zmax),
                    cfg=cfg,
                    component=clip_component,
                )
                _add_to_history(
                    project,
                    f"Clip Outside Symmetry Y {name}",
                    _build_solid_subtract_vba(
                        target=target,
                        tool=f"{clip_component}:{cutter_name}",
                    ),
                )

        created += 1
        if progress_callback is not None:
            if created == total_cylinders or created % update_every == 0:
                progress_callback(created, total_cylinders)
        if verbose:
            print(index)

    if clip_helpers_used:
        _add_to_history(
            project,
            "Delete Symmetry Clip Helpers",
            f'Component.Delete "{_escape_vba_string(clip_component)}"',
        )

    if skipped_records is not None:
        skipped_records.extend(skipped_rows)

    if skip_log_path is not None:
        log_file = Path(skip_log_path).expanduser().resolve()
        log_file.parent.mkdir(parents=True, exist_ok=True)
        unit_label = str(cfg.length_unit)
        with log_file.open("w", encoding="utf-8") as f:
            if min_radius_value is None:
                f.write("# No min_radius threshold provided.\n")
            else:
                f.write(
                    f"# Skipped rods with radius < {min_radius_value:.12g} {unit_label}\n"
                )
            f.write("rod_number,table_index,radius\n")
            for item in skipped_rows:
                radius_text = f"{float(item['radius']):.12g}"
                f.write(
                    f"{int(item['rod_number'])},{int(item['table_index'])},{radius_text}\n"
                )

    if progress_callback is not None and created != total_cylinders:
        progress_callback(created, total_cylinders)

    return created


def _infer_layout_bounds_from_dataframe(
    data: pd.DataFrame,
    *,
    x_col: str = "x",
    y_col: str = "y",
    radius_col: str = "radius",
) -> dict[str, float]:
    for required in (x_col, y_col, radius_col):
        if required not in data.columns:
            raise ValueError(f"Missing column '{required}' in input table.")

    xmin = float((data[x_col] - data[radius_col]).min())
    xmax = float((data[x_col] + data[radius_col]).max())
    ymin = float((data[y_col] - data[radius_col]).min())
    ymax = float((data[y_col] + data[radius_col]).max())
    return {"xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax}


def create_cst_airbox_and_ports(
    project,
    geom_cfg: CstMetasurfaceConfig,
    airbox_cfg: Optional[CstAirboxConfig] = None,
):
    """Create optional airbox and optional z-ports using parameter expressions."""
    airbox_cfg = airbox_cfg or CstAirboxConfig()
    if not airbox_cfg.enabled:
        return

    x_min = f"(ms_core_xmin)-({_format_expr(airbox_cfg.margin_xy)})"
    x_max = f"(ms_core_xmax)+({_format_expr(airbox_cfg.margin_xy)})"
    y_min = f"(ms_core_ymin)-({_format_expr(airbox_cfg.margin_xy)})"
    y_max = f"(ms_core_ymax)+({_format_expr(airbox_cfg.margin_xy)})"
    z_min = f"({_format_expr(geom_cfg.z_base)})-({_format_expr(airbox_cfg.below)})"
    z_max = (
        f"({_format_expr(geom_cfg.z_base)})+({_format_expr(geom_cfg.pillar_height)})"
        f"+({_format_expr(airbox_cfg.above)})"
    )

    cst_add_brick(
        project=project,
        name=airbox_cfg.name,
        x_range=(x_min, x_max),
        y_range=(y_min, y_max),
        z_range=(z_min, z_max),
        cfg=geom_cfg,
        material=airbox_cfg.material,
    )

    if not airbox_cfg.create_z_ports:
        return

    _add_to_history(
        project,
        "Create Port 1",
        _build_waveguide_port_vba(
            port_number=1,
            orientation="zmin",
            xrange=(x_min, x_max),
            yrange=(y_min, y_max),
            zrange=(z_min, z_min),
            modes=airbox_cfg.port_modes,
        ),
    )
    _add_to_history(
        project,
        "Create Port 2",
        _build_waveguide_port_vba(
            port_number=2,
            orientation="zmax",
            xrange=(x_min, x_max),
            yrange=(y_min, y_max),
            zrange=(z_max, z_max),
            modes=airbox_cfg.port_modes,
        ),
    )


def build_cst_cylinders(
    project,
    csv_path: str | Path,
    cfg: Optional[CstMetasurfaceConfig] = None,
    radius_col: str = "radius",
    x_col: str = "x",
    y_col: str = "y",
    set_units_first: bool = True,
    drop_nonpositive: bool = True,
    verbose: bool = False,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
) -> int:
    """Build CST cylinders from a CSV containing x/y/radius columns."""
    cfg = cfg or CstMetasurfaceConfig()

    if set_units_first:
        set_cst_units(project, cfg)

    data = pd.read_csv(str(Path(csv_path).expanduser().resolve()))
    return _build_cylinders_from_dataframe(
        project=project,
        data=data,
        cfg=cfg,
        radius_col=radius_col,
        x_col=x_col,
        y_col=y_col,
        drop_nonpositive=drop_nonpositive,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=verbose,
        quarter=False,
        include_symmetry_axes=True,
        strict_delete_outside_symmetry=False,
    )


def build_cst_cylinders_from_array(
    project,
    radii: np.ndarray,
    pitch: float,
    cfg: Optional[CstMetasurfaceConfig] = None,
    set_units_first: bool = True,
    drop_nonpositive: bool = True,
    verbose: bool = False,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
) -> int:
    """Build CST cylinders from a 2D radius array."""
    cfg = cfg or CstMetasurfaceConfig()
    arr = np.asarray(radii, dtype=float)
    if arr.ndim == 3 and arr.shape[-1] == 1:
        arr = arr[..., 0]
    if arr.ndim != 2:
        raise ValueError("radii must be 2D [Ny, Nx] or [Ny, Nx, 1].")

    ny, nx = arr.shape
    xs = (np.arange(nx) - nx / 2.0 + 0.5) * float(pitch)
    ys = (np.arange(ny) - ny / 2.0 + 0.5) * float(pitch)

    rows = []
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            rows.append((x, y, float(arr[iy, ix])))

    data = pd.DataFrame(rows, columns=["x", "y", "radius"])
    if set_units_first:
        set_cst_units(project, cfg)
    return _build_cylinders_from_dataframe(
        project=project,
        data=data,
        cfg=cfg,
        radius_col="radius",
        x_col="x",
        y_col="y",
        drop_nonpositive=drop_nonpositive,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=verbose,
        quarter=False,
        include_symmetry_axes=True,
        strict_delete_outside_symmetry=False,
    )


def build_cst_cylinders_from_optimized_p(
    project,
    p,
    pitch_m: float,
    cfg: Optional[CstMetasurfaceConfig] = None,
    batch_index: int = 0,
    param_index: int = 0,
    drop_nonpositive: bool = True,
    quarter: bool = False,
    include_symmetry_axes: bool = True,
    strict_delete_outside_symmetry: bool = True,
    set_units_first: bool = True,
    verbose: bool = False,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
) -> int:
    """Build CST cylinders directly from reverse-lookup output ``p``."""
    cfg = cfg or CstMetasurfaceConfig()
    data = optimized_p_to_cst_cylinder_table(
        p=p,
        pitch_m=float(pitch_m),
        length_unit=cfg.length_unit,
        batch_index=batch_index,
        param_index=param_index,
        drop_nonpositive=drop_nonpositive,
        quarter=quarter,
        include_symmetry_axes=include_symmetry_axes,
    )
    if set_units_first:
        set_cst_units(project, cfg)
    return _build_cylinders_from_dataframe(
        project=project,
        data=data,
        cfg=cfg,
        radius_col="radius",
        x_col="x",
        y_col="y",
        drop_nonpositive=drop_nonpositive,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=verbose,
        quarter=quarter,
        include_symmetry_axes=include_symmetry_axes,
        strict_delete_outside_symmetry=strict_delete_outside_symmetry,
    )


def save_cst_project(project, output_cst: str | Path, overwrite: bool = True):
    out = Path(output_cst).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    sidecar_dir = out.with_suffix("")

    if overwrite:
        if out.exists():
            out.unlink()
        if sidecar_dir.exists() and sidecar_dir.is_dir():
            shutil.rmtree(sidecar_dir, ignore_errors=True)

    for method_name in ("save_as", "saveAs", "saveFile"):
        method = getattr(project, method_name, None)
        if callable(method):
            method(str(out))
            return str(out)

    save_method = getattr(project, "save", None)
    if callable(save_method):
        try:
            save_method(str(out))
        except TypeError:
            save_method()
        return str(out)

    raise AttributeError(
        "Unable to save CST project. Expected one of: "
        "`save_as`, `saveAs`, `saveFile`, or `save`."
    )


def automate_cst_from_csv(
    csv_path: str | Path,
    output_cst: str | Path,
    session_cfg: Optional[CstSessionConfig] = None,
    sim_cfg: Optional[CstMetasurfaceConfig] = None,
    template_cst: Optional[str | Path] = None,
    parameters: Optional[Mapping[str, ScalarExpr]] = None,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
):
    """Create/update a CST project and populate cylinders from CSV."""
    session_cfg = session_cfg or CstSessionConfig()
    sim_cfg = sim_cfg or CstMetasurfaceConfig()

    env = connect_cst(session_cfg)
    project = load_or_create_cst_project(env, template_cst=template_cst)
    if parameters:
        set_cst_parameters(project, parameters)
    build_cst_cylinders(
        project=project,
        csv_path=csv_path,
        cfg=sim_cfg,
        set_units_first=True,
        drop_nonpositive=True,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=False,
    )
    return save_cst_project(project, output_cst)


def automate_cst_from_array(
    radii: np.ndarray,
    pitch: float,
    output_cst: str | Path,
    session_cfg: Optional[CstSessionConfig] = None,
    sim_cfg: Optional[CstMetasurfaceConfig] = None,
    template_cst: Optional[str | Path] = None,
    parameters: Optional[Mapping[str, ScalarExpr]] = None,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
):
    """Create/update a CST project and populate cylinders from a 2D array."""
    session_cfg = session_cfg or CstSessionConfig()
    sim_cfg = sim_cfg or CstMetasurfaceConfig()

    env = connect_cst(session_cfg)
    project = load_or_create_cst_project(env, template_cst=template_cst)
    if parameters:
        set_cst_parameters(project, parameters)
    build_cst_cylinders_from_array(
        project=project,
        radii=radii,
        pitch=float(pitch),
        cfg=sim_cfg,
        set_units_first=True,
        drop_nonpositive=True,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=False,
    )
    return save_cst_project(project, output_cst)


def automate_cst_from_optimized_p(
    p,
    pitch_m: float,
    output_cst: str | Path,
    session_cfg: Optional[CstSessionConfig] = None,
    sim_cfg: Optional[CstMetasurfaceConfig] = None,
    template_cst: Optional[str | Path] = None,
    parameters: Optional[Mapping[str, ScalarExpr]] = None,
    batch_index: int = 0,
    param_index: int = 0,
    drop_nonpositive: bool = True,
    quarter: bool = False,
    include_symmetry_axes: bool = True,
    strict_delete_outside_symmetry: bool = True,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
):
    """Create/update a CST project and populate cylinders from optimized ``p``."""
    session_cfg = session_cfg or CstSessionConfig()
    sim_cfg = sim_cfg or CstMetasurfaceConfig()

    env = connect_cst(session_cfg)
    project = load_or_create_cst_project(env, template_cst=template_cst)
    if parameters:
        set_cst_parameters(project, parameters)
    build_cst_cylinders_from_optimized_p(
        project=project,
        p=p,
        pitch_m=float(pitch_m),
        cfg=sim_cfg,
        batch_index=batch_index,
        param_index=param_index,
        drop_nonpositive=drop_nonpositive,
        quarter=quarter,
        include_symmetry_axes=include_symmetry_axes,
        strict_delete_outside_symmetry=strict_delete_outside_symmetry,
        set_units_first=True,
        min_radius=min_radius,
        skip_log_path=skip_log_path,
        verbose=False,
    )
    return save_cst_project(project, output_cst)


def automate_cst_full_from_optimized_p(
    p,
    pitch_m: float,
    output_cst: str | Path,
    session_cfg: Optional[CstSessionConfig] = None,
    geom_cfg: Optional[CstMetasurfaceConfig] = None,
    template_cst: Optional[str | Path] = None,
    parameters: Optional[Mapping[str, ScalarExpr]] = None,
    material_cfgs: Optional[Sequence[CstMaterialConfig]] = None,
    airbox_cfg: Optional[CstAirboxConfig] = None,
    sim_cfg: Optional[CstSimulationConfig] = None,
    result_export_cfg: Optional[CstResultExportConfig] = None,
    batch_index: int = 0,
    param_index: int = 0,
    drop_nonpositive: bool = True,
    quarter: bool = False,
    include_symmetry_axes: bool = True,
    strict_delete_outside_symmetry: bool = True,
    close_design_environment: bool = True,
    show_progress: bool = False,
    progress_bar_width: int = 28,
    progress_interval: int = 200,
    min_radius: Optional[float] = None,
    skip_log_path: Optional[str | Path] = None,
):
    """Full CST automation from optimized ``p`` with optional simulation and export."""
    session_cfg = session_cfg or CstSessionConfig()
    geom_cfg = geom_cfg or CstMetasurfaceConfig()
    airbox_cfg = airbox_cfg or CstAirboxConfig()
    sim_cfg = sim_cfg or CstSimulationConfig()
    result_export_cfg = result_export_cfg or CstResultExportConfig()
    step_names = _build_full_automation_step_names(
        has_materials=bool(material_cfgs),
        has_airbox=bool(airbox_cfg.enabled),
        has_simulation=bool(sim_cfg.enabled),
        will_run_solver=bool(sim_cfg.enabled and sim_cfg.run_solver),
        will_export_results=bool(result_export_cfg.enabled),
    )
    progress = _SingleLineStepProgress(
        total_steps=len(step_names),
        enabled=show_progress,
        bar_width=progress_bar_width,
    )

    env = None
    try:
        step_idx = 0
        progress.begin_step(step_names[step_idx])
        table = optimized_p_to_cst_cylinder_table(
            p=p,
            pitch_m=float(pitch_m),
            length_unit=geom_cfg.length_unit,
            batch_index=batch_index,
            param_index=param_index,
            drop_nonpositive=drop_nonpositive,
            quarter=quarter,
            include_symmetry_axes=include_symmetry_axes,
        )
        table_detail = f"table rows: {len(table)}"
        if quarter:
            axis_mode = "on" if include_symmetry_axes else "off"
            table_detail += f" | quarter: true | include_axes: {axis_mode}"
        progress.complete_step(detail=table_detail)
        step_idx += 1

        progress.begin_step(step_names[step_idx])
        env = connect_cst(session_cfg)
        progress.complete_step()
        step_idx += 1

        progress.begin_step(step_names[step_idx])
        project = load_or_create_cst_project(env, template_cst=template_cst)
        progress.complete_step()
        step_idx += 1

        progress.begin_step(step_names[step_idx])
        set_cst_units(project, geom_cfg)
        progress.complete_step()
        step_idx += 1
        if material_cfgs:
            progress.begin_step(step_names[step_idx])
            define_cst_materials(project, material_cfgs)
            progress.complete_step(detail=f"materials: {len(material_cfgs)}")
            step_idx += 1

        progress.begin_step(step_names[step_idx])
        bounds = _infer_layout_bounds_from_dataframe(table)
        if quarter and include_symmetry_axes and strict_delete_outside_symmetry:
            bounds["xmin"] = 0.0
            bounds["ymin"] = 0.0
        merged_parameters = dict(parameters or {})
        merged_parameters.update(
            {
                "ms_core_xmin": bounds["xmin"],
                "ms_core_xmax": bounds["xmax"],
                "ms_core_ymin": bounds["ymin"],
                "ms_core_ymax": bounds["ymax"],
            }
        )
        if _is_numeric(geom_cfg.pillar_height) and "ms_h" not in merged_parameters:
            merged_parameters["ms_h"] = geom_cfg.pillar_height
        if _is_numeric(geom_cfg.z_base) and "ms_z0" not in merged_parameters:
            merged_parameters["ms_z0"] = geom_cfg.z_base
        if airbox_cfg.enabled:
            if _is_numeric(airbox_cfg.margin_xy) and "ms_air_margin" not in merged_parameters:
                merged_parameters["ms_air_margin"] = airbox_cfg.margin_xy
            if _is_numeric(airbox_cfg.above) and "ms_air_above" not in merged_parameters:
                merged_parameters["ms_air_above"] = airbox_cfg.above
            if _is_numeric(airbox_cfg.below) and "ms_air_below" not in merged_parameters:
                merged_parameters["ms_air_below"] = airbox_cfg.below
        set_cst_parameters(project, merged_parameters)
        progress.complete_step(detail=f"parameters: {len(merged_parameters)}")
        step_idx += 1

        progress.begin_step(step_names[step_idx])
        skipped_rows: list[dict[str, float | int]] = []

        def _on_cylinder_progress(created_count: int, total_count: int):
            if total_count <= 0:
                progress.update_step(1.0, detail="cylinders: 0/0")
                return
            fraction = float(created_count) / float(total_count)
            progress.update_step(
                fraction,
                detail=f"cylinders: {created_count}/{total_count}",
            )

        created = _build_cylinders_from_dataframe(
            project=project,
            data=table,
            cfg=geom_cfg,
            radius_col="radius",
            x_col="x",
            y_col="y",
            drop_nonpositive=drop_nonpositive,
            verbose=False,
            progress_callback=_on_cylinder_progress if show_progress else None,
            progress_interval=progress_interval,
            quarter=quarter,
            include_symmetry_axes=include_symmetry_axes,
            strict_delete_outside_symmetry=strict_delete_outside_symmetry,
            min_radius=min_radius,
            skip_log_path=skip_log_path,
            skipped_records=skipped_rows,
        )
        progress.complete_step(detail=f"created cylinders: {created}")
        step_idx += 1

        if airbox_cfg.enabled:
            progress.begin_step(step_names[step_idx])
            create_cst_airbox_and_ports(project, geom_cfg, airbox_cfg)
            progress.complete_step()
            step_idx += 1

        sim_cfg_effective = sim_cfg
        if (
            quarter
            and include_symmetry_axes
            and strict_delete_outside_symmetry
            and not sim_cfg.symmetry_plane_on_min_boundaries
        ):
            sim_cfg_effective = replace(sim_cfg, symmetry_plane_on_min_boundaries=True)

        if sim_cfg.enabled:
            progress.begin_step(step_names[step_idx])
            setup_cst_simulation(project, geom_cfg, sim_cfg_effective)
            progress.complete_step()
            step_idx += 1

        progress.begin_step(step_names[step_idx])
        saved = save_cst_project(project, output_cst)
        progress.complete_step(detail=f"saved: {Path(saved).name}")
        step_idx += 1

        if sim_cfg.enabled and sim_cfg.run_solver:
            progress.begin_step(step_names[step_idx])
            run_cst_solver(project)
            progress.complete_step()
            step_idx += 1

            progress.begin_step(step_names[step_idx])
            saved = save_cst_project(project, output_cst)
            progress.complete_step(detail=f"saved: {Path(saved).name}")
            step_idx += 1

        exported = {}
        if result_export_cfg.enabled:
            progress.begin_step(step_names[step_idx])
            defer_exports = bool(
                result_export_cfg.defer_until_solver_run
                and not (sim_cfg.enabled and sim_cfg.run_solver)
            )
            if defer_exports:
                progress.complete_step(detail="deferred (solver not run in this workflow)")
            else:
                if result_export_cfg.tree_paths:
                    exported.update(extract_cst_1d_results(saved, result_export_cfg))
                if result_export_cfg.field_2d_plane_exports:
                    exported.update(export_cst_2d_plane_fields(project, saved, result_export_cfg))
                progress.complete_step(detail=f"exported files: {len(exported)}")

        return {
            "saved_cst": saved,
            "created_cylinders": int(created),
            "skipped_cylinders": int(len(skipped_rows)),
            "skip_log_path": (
                str(Path(skip_log_path).expanduser().resolve())
                if skip_log_path is not None
                else None
            ),
            "exported_results": exported,
            "deferred_result_exports": bool(
                result_export_cfg.enabled
                and result_export_cfg.defer_until_solver_run
                and not (sim_cfg.enabled and sim_cfg.run_solver)
            ),
        }
    finally:
        if close_design_environment:
            close_fn = getattr(env, "close", None) if env is not None else None
            if callable(close_fn):
                close_fn()
        progress.close()





