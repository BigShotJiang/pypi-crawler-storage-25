"""Helpers for building CST script workflows."""

from __future__ import annotations

import time
from pathlib import Path

from .cst_automation import CstMonitorConfig
from .layout import infer_unit_cells_xy


def build_frequency_monitors(
    *,
    frequency_thz: float,
    enable_e_field: bool,
    enable_h_field: bool,
    enable_farfield: bool,
    enable_powerflow: bool,
) -> tuple[CstMonitorConfig, ...]:
    """Build frequency-domain monitor configs from feature toggles."""
    monitors: list[CstMonitorConfig] = []
    if enable_e_field:
        monitors.append(
            CstMonitorConfig(
                name=f"e-field (f={frequency_thz:g})",
                field_type="Efield",
                monitor_value=frequency_thz,
                domain="Frequency",
                value_property="MonitorValue",
                dimension="Volume",
                use_subvolume=False,
            )
        )
    if enable_h_field:
        monitors.append(
            CstMonitorConfig(
                name=f"h-field (f={frequency_thz:g})",
                field_type="Hfield",
                monitor_value=frequency_thz,
                domain="Frequency",
                value_property="MonitorValue",
                dimension="Volume",
                use_subvolume=False,
            )
        )
    if enable_farfield:
        monitors.append(
            CstMonitorConfig(
                name=f"farfield (f={frequency_thz:g})",
                field_type="Farfield",
                monitor_value=frequency_thz,
                domain="Frequency",
                value_property="MonitorValue",
                dimension=None,
                use_subvolume=None,
            )
        )
    if enable_powerflow:
        monitors.append(
            CstMonitorConfig(
                name=f"power-flow (f={frequency_thz:g})",
                field_type="Powerflow",
                monitor_value=frequency_thz,
                domain="Frequency",
                value_property="MonitorValue",
                dimension="Volume",
                use_subvolume=False,
            )
        )
    return tuple(monitors)


def resolve_output_cst_path(path: Path, use_timestamp_if_exists: bool) -> Path:
    """Return output CST path, optionally appending a timestamp on collisions."""
    if not use_timestamp_if_exists:
        return path
    if path.exists() or path.with_suffix("").exists():
        return path.with_name(f"{path.stem}_{int(time.time())}{path.suffix}")
    return path
