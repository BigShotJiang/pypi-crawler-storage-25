"""COMSOL metasurface automation.

This module is the single COMSOL integration point for metasurface geometry
build, simulation setup, solve, export, and save.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import tempfile
from typing import Optional

import numpy as np
import pandas as pd


from .layout import optimized_p_to_comsol_cylinder_table


@dataclass
class ComsolSessionConfig:
    host: str = "localhost"
    port: int = 2036
    version: Optional[str] = None
    enable_classkit: bool = False


@dataclass
class MetasurfaceConfig:
    # COMSOL tree tags, don't change unless you know what you're doing or want to customise for a template.
    component: str = "comp1"  # COMSOL component tag
    geometry: str = "geom1"  # COMSOL geometry tag
    work_plane: str = "wp1"  # Work-plane tag where circles are drawn

    # Length/geometry controls
    length_unit: str = "mm"  # Display and parameter unit used in geometry expressions
    pillar_height: float = 1.315  # Rod extrusion height

    # Optional substrate
    enable_substrate: bool = False
    substrate_thickness: float = 0.694  # Substrate thickness
    substrate_size_x: float = 12.45  # Substrate size in x
    substrate_size_y: float = 24.9  # Substrate size in y

    # Core footprint used by air/PML (if None, inferred from input layout)
    core_size_x: Optional[float] = None
    core_size_y: Optional[float] = None

    # Air region controls
    enable_air_box: bool = True
    air_side_margin: float = 1.0  # Air padding on x/y around core footprint
    air_above_thickness: float = 1.0  # Extra air thickness above rods

    # PML region controls
    enable_pml: bool = True
    pml_thickness: float = 0.5  # Side-wall PML thickness in x/y

    # Mesh and spectral controls
    mesh_level: int = 5  # COMSOL automatic mesh size level
    wavelength_range: bool = True  # True: sweep, False: single wavelength
    wavelength_start: float = 2.3  # Sweep start wavelength [m]
    wavelength_stop: float = 2.7  # Sweep stop wavelength [m]
    wavelength_step: float = 0.01  # Sweep step wavelength [m]
    wavelength: float = 2.5  # Single wavelength [m] when wavelength_range=False


def _require_mph():
    try:
        import mph
    except ImportError as exc:
        raise ImportError("The `mph` package is required for COMSOL automation.") from exc
    return mph


def connect_comsol(session_cfg: Optional[ComsolSessionConfig] = None):
    session_cfg = session_cfg or ComsolSessionConfig()
    mph = _require_mph()

    if not session_cfg.enable_classkit:
        mph.option("classkit", False)

    kwargs = {"host": session_cfg.host, "port": session_cfg.port}
    if session_cfg.version:
        kwargs["version"] = session_cfg.version
    return mph.Client(**kwargs)


def load_or_create_model(client, template_mph: Optional[str | Path] = None, model_label: str = "metasurface_automation"):
    if template_mph:
        return client.load(str(Path(template_mph).expanduser().resolve()))
    return client.create(model_label)


def _ensure_component_geometry(model, cfg: MetasurfaceConfig):
    model1 = model.java

    try:
        model1.component().create(cfg.component, True)
    except Exception:
        pass

    try:
        model1.component(cfg.component).geom().create(cfg.geometry, 3)
    except Exception:
        pass

    try:
        model1.component(cfg.component).geom(cfg.geometry).lengthUnit(cfg.length_unit)
    except Exception:
        pass

    return model1


def _ensure_work_plane(model, cfg: MetasurfaceConfig):
    model1 = _ensure_component_geometry(model, cfg)
    geom = model1.component(cfg.component).geom(cfg.geometry)
    try:
        geom.feature().create(cfg.work_plane, "WorkPlane")
    except Exception:
        pass
    try:
        geom.feature(cfg.work_plane).set("quickplane", "xy")
    except Exception:
        pass
    return model1

def _set_param(param, name: str, expr: str, desc: str):
        """Set COMSOL parameter value and description with API compatibility fallback."""
        try:
            # Preferred COMSOL Java overload: set(name, expr, description)
            param.set(name, expr, desc)
            return
        except Exception:
            pass
        try:
            # Fallback: set value then description explicitly.
            param.set(name, expr)
            param.descr(name, desc)
            return
        except Exception:
            pass
        # Last resort: value only.
        param.set(name, expr)


def set_model_parameters(model, cfg: Optional[MetasurfaceConfig] = None):
    """Populate COMSOL global parameters used by geometry and study setup.

    Parameter descriptions:
    - ``ms_pillar_h``: pillar (rod) extrusion height.
    - ``ms_sub_t``: substrate thickness.
    - ``ms_sub_lx`` / ``ms_sub_ly``: substrate size in x / y.
    - ``ms_core_lx`` / ``ms_core_ly``: active metasurface footprint used by air and PML sizing.
    - ``ms_air_margin``: air padding in x/y around core.
    - ``ms_air_above``: air extension above pillars.
    - ``ms_air_lx`` / ``ms_air_ly`` / ``ms_air_lz``: air-box dimensions.
    - ``ms_air_cz``: air-box centre z coordinate.
    - ``ms_pml_t``: side-wall PML thickness.
    - ``ms_pml_lx`` / ``ms_pml_ly`` / ``ms_pml_lz``: PML envelope dimensions.
    - ``ms_wavelength``: single simulation wavelength (when no sweep).
    - ``ms_wl_start`` / ``ms_wl_stop`` / ``ms_wl_step``: wavelength sweep settings.
    """
    cfg = cfg or MetasurfaceConfig()
    model1 = model.java
    unit = cfg.length_unit
    param = model1.param()

    # ms_pillar_h: rod height
    _set_param(param, "ms_pillar_h", f"{cfg.pillar_height}[{unit}]", "Pillar (rod) extrusion height")
    if cfg.enable_substrate:
        # ms_sub_t / ms_sub_lx / ms_sub_ly: substrate thickness and footprint
        _set_param(param, "ms_sub_t", f"{cfg.substrate_thickness}[{unit}]", "Substrate thickness")
        _set_param(param, "ms_sub_lx", f"{cfg.substrate_size_x}[{unit}]", "Substrate size in x")
        _set_param(param, "ms_sub_ly", f"{cfg.substrate_size_y}[{unit}]", "Substrate size in y")
    if cfg.core_size_x is not None and cfg.core_size_y is not None:
        # ms_core_lx / ms_core_ly: explicit active footprint parameters take precedence over substrate-derived or inferred sizes.
        _set_param(param, "ms_core_lx", f"{cfg.core_size_x}[{unit}]", "Active metasurface footprint in x")
        _set_param(param, "ms_core_ly", f"{cfg.core_size_y}[{unit}]", "Active metasurface footprint in y")
    elif cfg.enable_substrate:
        # ms_core_lx / ms_core_ly derived from substrate when substrate is enabled
        _set_param(param, "ms_core_lx", "ms_sub_lx", "Active metasurface footprint in x (from substrate)")
        _set_param(param, "ms_core_ly", "ms_sub_ly", "Active metasurface footprint in y (from substrate)")
    else:
        # No-substrate fallback; automation paths overwrite from input footprint.
        _set_param(param, "ms_core_lx", f"0[{unit}]", "Active metasurface footprint in x (placeholder; inferred later)")
        _set_param(param, "ms_core_ly", f"0[{unit}]", "Active metasurface footprint in y (placeholder; inferred later)")

    # Air region parameters
    if cfg.enable_air_box:
        # ms_air_margin / ms_air_above: user air-box controls
        _set_param(param, "ms_air_margin", f"{cfg.air_side_margin}[{unit}]", "Air padding in x/y around core")
        _set_param(param, "ms_air_above", f"{cfg.air_above_thickness}[{unit}]", "Air extension above pillars")

        # ms_air_lx / ms_air_ly / ms_air_lz: derived air-box size
        _set_param(param, "ms_air_lx", "ms_core_lx+2*ms_air_margin", "Air-box size in x")
        _set_param(param, "ms_air_ly", "ms_core_ly+2*ms_air_margin", "Air-box size in y")
        _set_param(param, "ms_air_lz", "ms_pillar_h+ms_air_above", "Air-box size in z")
        # ms_air_cz: centre of air box in z
        _set_param(param, "ms_air_cz", "0.5*ms_air_lz", "Air-box centre z coordinate")

    # PML region parameters
    if cfg.enable_pml:
        # ms_pml_t: PML side thickness
        _set_param(param, "ms_pml_t", f"{cfg.pml_thickness}[{unit}]", "Side-wall PML thickness")
        # ms_pml_lx / ms_pml_ly: PML envelope in x/y
        _set_param(param, "ms_pml_lx", "ms_air_lx+2*ms_pml_t", "PML envelope size in x")
        _set_param(param, "ms_pml_ly", "ms_air_ly+2*ms_pml_t", "PML envelope size in y")
        # ms_pml_lz: same z-span as air (side walls only; top/bottom exposed)
        _set_param(param, "ms_pml_lz", "ms_air_lz", "PML envelope size in z")

    if not cfg.wavelength_range:
        # ms_wavelength: single wavelength solve
        _set_param(param, "ms_wavelength", f"{cfg.wavelength}[m]", "Single solve wavelength")
    else:
        # ms_wl_start / ms_wl_stop / ms_wl_step: wavelength sweep controls
        _set_param(param, "ms_wl_start", f"{cfg.wavelength_start}[m]", "Wavelength sweep start")
        _set_param(param, "ms_wl_stop", f"{cfg.wavelength_stop}[m]", "Wavelength sweep stop")
        _set_param(param, "ms_wl_step", f"{cfg.wavelength_step}[m]", "Wavelength sweep step")


def _unit_scale_from_m(length_unit: str) -> float:
    unit = str(length_unit).strip().lower()
    scales = {"m": 1.0, "mm": 1e3, "um": 1e6, "nm": 1e9}
    if unit not in scales:
        raise ValueError(f"Unsupported length_unit '{length_unit}'.")
    return scales[unit]


def _set_core_size_parameters(model, cfg: MetasurfaceConfig, core_lx: float, core_ly: float):
    unit = cfg.length_unit
    _set_param(model.java.param(), "ms_core_lx", f"{core_lx}[{unit}]", "Active metasurface footprint in x")
    _set_param(model.java.param(), "ms_core_ly", f"{core_ly}[{unit}]", "Active metasurface footprint in y")


def _infer_core_size_from_csv(csv_path: str | Path):
    data = pd.read_csv(str(Path(csv_path).expanduser().resolve()))
    for col in ("x", "y", "radius"):
        if col not in data.columns:
            raise ValueError(f"CSV must include '{col}' to infer core size.")
    min_x = float((data["x"] - data["radius"]).min())
    max_x = float((data["x"] + data["radius"]).max())
    min_y = float((data["y"] - data["radius"]).min())
    max_y = float((data["y"] + data["radius"]).max())
    return max_x - min_x, max_y - min_y


def _infer_core_size_from_array_shape(arr2d: np.ndarray, pitch: float):
    ny, nx = arr2d.shape
    return float(nx) * float(pitch), float(ny) * float(pitch)


def clear_workplane_circles(model, cfg: MetasurfaceConfig):
    model1 = _ensure_work_plane(model, cfg)
    wp_geom = model1.component(cfg.component).geom(cfg.geometry).feature(cfg.work_plane).geom()
    try:
        for tag in list(wp_geom.feature().tags()):
            if str(tag).startswith("c_"):
                wp_geom.feature(tag).remove()
    except Exception:
        pass


def build_cylinders(
    model,
    csv_path: str | Path,
    cfg: Optional[MetasurfaceConfig] = None,
    radius_col: str = "radius",
    x_col: str = "x",
    y_col: str = "y",
    clear_existing: bool = True,
    verbose: bool = True,
):
    """Build circles in COMSOL work plane from a CSV.

    Modeled after:
    model1.component("comp1").geom("geom1").feature("wp1").geom().create("c_i", "Circle")
    ... set('r', row['radius']) and set('pos', (row['x'], row['y']))
    """
    cfg = cfg or MetasurfaceConfig()
    model1 = _ensure_work_plane(model, cfg)
    data = pd.read_csv(str(Path(csv_path).expanduser().resolve()))

    for required in (radius_col, x_col, y_col):
        if required not in data.columns:
            raise ValueError(f"Missing column '{required}' in {csv_path}.")

    if clear_existing:
        clear_workplane_circles(model, cfg)

    wp_geom = model1.component(cfg.component).geom(cfg.geometry).feature(cfg.work_plane).geom()

    for index, row in data.iterrows():
        tag = f"c_{index + 1}"
        wp_geom.create(tag, "Circle")
        wp_geom.feature(tag).set("r", float(row[radius_col]))
        wp_geom.feature(tag).set("pos", [float(row[x_col]), float(row[y_col])])
        if verbose:
            print(index)

    # Mirrors your snippet: build geometry after creating circles.
    try:
        model.build("Geometry 1")
    except Exception:
        model1.component(cfg.component).geom(cfg.geometry).run()


def build_cylinders_from_array(
    model,
    radii: np.ndarray,
    pitch: float,
    cfg: Optional[MetasurfaceConfig] = None,
    clear_existing: bool = True,
    verbose: bool = False,
):
    cfg = cfg or MetasurfaceConfig()
    arr = np.asarray(radii, dtype=float)
    if arr.ndim == 3 and arr.shape[-1] == 1:
        arr = arr[..., 0]
    if arr.ndim != 2:
        raise ValueError("radii must be 2D [Ny, Nx] or [Ny, Nx, 1].")

    ny, nx = arr.shape
    xs = (np.arange(nx) - nx / 2 + 0.5) * float(pitch)
    ys = (np.arange(ny) - ny / 2 + 0.5) * float(pitch)

    rows = []
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            r = float(arr[iy, ix])
            if r > 0:
                rows.append((x, y, r))

    df = pd.DataFrame(rows, columns=["x", "y", "radius"])
    with tempfile.TemporaryDirectory(prefix="dflat_comsol_") as tmp_dir:
        tmp_csv = Path(tmp_dir) / "cylinders_from_array.csv"
        df.to_csv(tmp_csv, index=False)
        build_cylinders(
            model=model,
            csv_path=tmp_csv,
            cfg=cfg,
            clear_existing=clear_existing,
            verbose=verbose,
        )


def build_cylinders_from_optimized_p(
    model,
    p,
    pitch_m: float,
    cfg: Optional[MetasurfaceConfig] = None,
    batch_index: int = 0,
    param_index: int = 0,
    drop_nonpositive: bool = True,
    clear_existing: bool = True,
    verbose: bool = False,
):
    """Build work-plane circles from optimised ``p`` without manual CSV handling.

    This uses a temporary CSV under a temporary directory and deletes it automatically.
    """
    cfg = cfg or MetasurfaceConfig()
    with tempfile.TemporaryDirectory(prefix="dflat_comsol_") as tmp_dir:
        tmp_csv = Path(tmp_dir) / "cylinders_from_p.csv"
        optimized_p_to_comsol_cylinder_table(
            p=p,
            pitch_m=float(pitch_m),
            length_unit=cfg.length_unit,
            batch_index=batch_index,
            param_index=param_index,
            drop_nonpositive=drop_nonpositive,
            csv_path=tmp_csv,
        )
        build_cylinders(
            model=model,
            csv_path=tmp_csv,
            cfg=cfg,
            clear_existing=clear_existing,
            verbose=verbose,
        )


def create_substrate(model, cfg: Optional[MetasurfaceConfig] = None, tag: str = "blk_sub"):
    cfg = cfg or MetasurfaceConfig()
    model1 = _ensure_component_geometry(model, cfg)
    geom = model1.component(cfg.component).geom(cfg.geometry)

    try:
        geom.feature().remove(tag)
    except Exception:
        pass

    geom.feature().create(tag, "Block")
    geom.feature(tag).set("size", ["ms_sub_lx", "ms_sub_ly", "ms_sub_t"])
    geom.feature(tag).set("base", "center")
    geom.feature(tag).set("pos", ["0", "0", "-ms_sub_t"])
    geom.run(tag)


def extrude_workplane(model, cfg: Optional[MetasurfaceConfig] = None, tag: str = "ext1"):
    cfg = cfg or MetasurfaceConfig()
    model1 = _ensure_component_geometry(model, cfg)
    geom = model1.component(cfg.component).geom(cfg.geometry)

    try:
        geom.feature().remove(tag)
    except Exception:
        pass

    geom.feature().create(tag, "Extrude")
    try:
        geom.feature(tag).selection("input").set(cfg.work_plane)
    except Exception:
        pass
    geom.feature(tag).set("distance", ["ms_pillar_h"])
    geom.run(tag)


def create_air_and_pml_blocks(model, cfg: Optional[MetasurfaceConfig] = None):
    """Create an air block around rods and side-wall PML blocks."""
    cfg = cfg or MetasurfaceConfig()
    model1 = _ensure_component_geometry(model, cfg)
    geom = model1.component(cfg.component).geom(cfg.geometry)

    if cfg.enable_pml:
        try:
            geom.feature().remove("dif_pml")
        except Exception:
            pass
        try:
            geom.feature().remove("blk_pml")
        except Exception:
            pass

        # Keep compatibility with previous tags.
        try:
            geom.feature().remove("blk_pml_xn")
        except Exception:
            pass
        try:
            geom.feature().remove("blk_pml_xp")
        except Exception:
            pass
        try:
            geom.feature().remove("blk_pml_yn")
        except Exception:
            pass
        try:
            geom.feature().remove("blk_pml_yp")
        except Exception:
            pass
        try:
            geom.feature().remove("uni_pml")
        except Exception:
            pass

    if cfg.enable_air_box:
        try:
            geom.feature().remove("blk_air")
        except Exception:
            pass
        geom.feature().create("blk_air", "Block")
        geom.feature("blk_air").set("size", ["ms_air_lx", "ms_air_ly", "ms_air_lz"])
        geom.feature("blk_air").set("base", "center")
        geom.feature("blk_air").set("pos", ["0", "0", "ms_air_cz"])
        geom.feature("blk_air").set("selresult", True)

    if cfg.enable_pml:
        # Four side PML blocks; top/bottom remain open.
        geom.feature().create("blk_pml_xn", "Block")
        geom.feature("blk_pml_xn").set("size", ["ms_pml_t", "ms_pml_ly", "ms_air_lz"])
        geom.feature("blk_pml_xn").set("base", "center")
        geom.feature("blk_pml_xn").set("pos", ["-0.5*(ms_air_lx+ms_pml_t)", "0", "ms_air_cz"])

        geom.feature().create("blk_pml_xp", "Block")
        geom.feature("blk_pml_xp").set("size", ["ms_pml_t", "ms_pml_ly", "ms_air_lz"])
        geom.feature("blk_pml_xp").set("base", "center")
        geom.feature("blk_pml_xp").set("pos", ["0.5*(ms_air_lx+ms_pml_t)", "0", "ms_air_cz"])

        geom.feature().create("blk_pml_yn", "Block")
        geom.feature("blk_pml_yn").set("size", ["ms_air_lx", "ms_pml_t", "ms_air_lz"])
        geom.feature("blk_pml_yn").set("base", "center")
        geom.feature("blk_pml_yn").set("pos", ["0", "-0.5*(ms_air_ly+ms_pml_t)", "ms_air_cz"])

        geom.feature().create("blk_pml_yp", "Block")
        geom.feature("blk_pml_yp").set("size", ["ms_air_lx", "ms_pml_t", "ms_air_lz"])
        geom.feature("blk_pml_yp").set("base", "center")
        geom.feature("blk_pml_yp").set("pos", ["0", "0.5*(ms_air_ly+ms_pml_t)", "ms_air_cz"])

        # Merge side blocks into one PML domain selection, without using Difference.
        geom.feature().create("uni_pml", "Union")
        geom.feature("uni_pml").selection("input").set(
            ["blk_pml_xn", "blk_pml_xp", "blk_pml_yn", "blk_pml_yp"]
        )
        geom.feature("uni_pml").set("selresult", True)
        try:
            geom.feature("uni_pml").set("intbnd", False)
        except Exception:
            pass

    # Rebuild complete geometry to update resulting domains and named selections.
    try:
        model.build("Geometry 1")
    except Exception:
        geom.run()


def setup_materials(model, cfg: Optional[MetasurfaceConfig] = None):
    """Create and assign air material to the air-block domain selection."""
    cfg = cfg or MetasurfaceConfig()
    model1 = model.java
    comp = model1.component(cfg.component)

    if not cfg.enable_air_box:
        return

    try:
        comp.material().create("mat_air", "Common")
    except Exception:
        pass

    try:
        mat_air = comp.material("mat_air")
        mat_air.label("Air")
        # Explicitly define air-like properties.
        mat_air.propertyGroup("def").set("relpermittivity", ["1", "1", "1"])
        mat_air.propertyGroup("def").set("relpermeability", ["1", "1", "1"])
        mat_air.propertyGroup("def").set("electricconductivity", ["0", "0", "0"])
    except Exception:
        pass

    # Use the geometry feature domain selection from blk_air.
    try:
        comp.material("mat_air").selection().named(f"{cfg.geometry}_blk_air_dom")
    except Exception:
        pass


def setup_pml(model, cfg: Optional[MetasurfaceConfig] = None):
    """Attach COMSOL PML definition to the geometry-generated PML shell domain."""
    cfg = cfg or MetasurfaceConfig()
    if not cfg.enable_pml:
        return

    model1 = model.java
    comp = model1.component(cfg.component)

    try:
        comp.coordSystem().remove("pml1")
    except Exception:
        pass

    try:
        comp.coordSystem().create("pml1", "PML")
        # Auto-generated selection from side-wall PML union domains.
        comp.coordSystem("pml1").selection().named(f"{cfg.geometry}_uni_pml_dom")
    except Exception:
        # Leave model usable even if a template-specific selection mapping differs.
        pass


def setup_ewfd_study(model, cfg: Optional[MetasurfaceConfig] = None):
    cfg = cfg or MetasurfaceConfig()
    model1 = model.java
    comp = model1.component(cfg.component)

    try:
        comp.physics().create("ewfd", "ElectromagneticWavesFrequencyDomain", cfg.geometry)
    except Exception:
        pass
    try:
        comp.physics("ewfd").selection().all()
    except Exception:
        pass

    try:
        comp.mesh().create("mesh1")
    except Exception:
        pass
    try:
        comp.mesh("mesh1").autoMeshSize(int(cfg.mesh_level))
        comp.mesh("mesh1").run()
    except Exception:
        pass

    try:
        model1.study().create("std1")
    except Exception:
        pass
    try:
        model1.study("std1").create("wave", "Wavelength")
    except Exception:
        pass
    try:
        wave = model1.study("std1").feature("wave")
        wave.set(
            "plist",
            "range(ms_wl_start,ms_wl_step,ms_wl_stop)",
        )
        wave.setSolveFor("/physics/ewfd", True)
    except Exception:
        pass
    setup_pml(model, cfg)


def solve_model(model):
    model1 = model.java
    try:
        model1.study("std1").createAutoSequences("all")
    except Exception:
        pass
    try:
        model1.sol("sol1").runAll()
    except Exception:
        model.solve("std1")


def export_field_csv(model, csv_path: str | Path, expr: str = "ewfd.normE"):
    model1 = model.java
    out = Path(csv_path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    try:
        model1.result().export().create("data1", "Data")
    except Exception:
        pass

    data = model1.result().export("data1")
    data.set("expr", [expr])
    data.set("filename", str(out))
    data.run()


def save_model(model, output_mph: str | Path):
    out = Path(output_mph).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    model.save(str(out), format="Comsol")
    return str(out)


def automate_from_csv(
    csv_path: str | Path,
    output_mph: str | Path,
    session_cfg: Optional[ComsolSessionConfig] = None,
    sim_cfg: Optional[MetasurfaceConfig] = None,
    template_mph: Optional[str | Path] = None,
    export_csv: Optional[str | Path] = None,
):
    session_cfg = session_cfg or ComsolSessionConfig()
    sim_cfg = sim_cfg or MetasurfaceConfig()

    client = connect_comsol(session_cfg)
    model = load_or_create_model(client, template_mph=template_mph)
    set_model_parameters(model, sim_cfg)
    if not sim_cfg.enable_substrate and sim_cfg.core_size_x is None:
        core_lx, core_ly = _infer_core_size_from_csv(csv_path)
        _set_core_size_parameters(model, sim_cfg, core_lx, core_ly)

    create_air_and_pml_blocks(model, sim_cfg)
    if sim_cfg.enable_substrate:
        create_substrate(model, sim_cfg)
    build_cylinders(model, csv_path, cfg=sim_cfg, clear_existing=True, verbose=True)
    extrude_workplane(model, sim_cfg)
    setup_materials(model, sim_cfg)
    setup_ewfd_study(model, sim_cfg)
    solve_model(model)

    if export_csv:
        export_field_csv(model, export_csv)

    return save_model(model, output_mph)


def automate_from_array(
    radii: np.ndarray,
    pitch: float,
    output_mph: str | Path,
    session_cfg: Optional[ComsolSessionConfig] = None,
    sim_cfg: Optional[MetasurfaceConfig] = None,
    template_mph: Optional[str | Path] = None,
    export_csv: Optional[str | Path] = None,
):
    session_cfg = session_cfg or ComsolSessionConfig()
    sim_cfg = sim_cfg or MetasurfaceConfig()

    client = connect_comsol(session_cfg)
    model = load_or_create_model(client, template_mph=template_mph)
    set_model_parameters(model, sim_cfg)
    if not sim_cfg.enable_substrate and (sim_cfg.core_size_x is None or sim_cfg.core_size_y is None):
        arr = np.asarray(radii)
        if arr.ndim == 3 and arr.shape[-1] == 1:
            arr = arr[..., 0]
        core_lx, core_ly = _infer_core_size_from_array_shape(arr, pitch)
        _set_core_size_parameters(model, sim_cfg, core_lx, core_ly)

    create_air_and_pml_blocks(model, sim_cfg)
    if sim_cfg.enable_substrate:
        create_substrate(model, sim_cfg)
    build_cylinders_from_array(model, radii=radii, pitch=pitch, cfg=sim_cfg)
    extrude_workplane(model, sim_cfg)
    setup_materials(model, sim_cfg)
    setup_ewfd_study(model, sim_cfg)
    solve_model(model)

    if export_csv:
        export_field_csv(model, export_csv)

    return save_model(model, output_mph)


def automate_from_optimized_p(
    p,
    pitch_m: float,
    output_mph: str | Path,
    session_cfg: Optional[ComsolSessionConfig] = None,
    sim_cfg: Optional[MetasurfaceConfig] = None,
    template_mph: Optional[str | Path] = None,
    export_csv: Optional[str | Path] = None,
    batch_index: int = 0,
    param_index: int = 0,
    drop_nonpositive: bool = True,
):
    """Run full COMSOL automation directly from optimised reverse-lookup output ``p``."""
    session_cfg = session_cfg or ComsolSessionConfig()
    sim_cfg = sim_cfg or MetasurfaceConfig()

    client = connect_comsol(session_cfg)
    model = load_or_create_model(client, template_mph=template_mph)
    set_model_parameters(model, sim_cfg)
    if not sim_cfg.enable_substrate and sim_cfg.core_size_x is None:
        arr = np.asarray(p)
        if arr.ndim == 4:
            arr = arr[batch_index]
        if arr.ndim == 3:
            arr = arr[..., param_index]
        if arr.ndim != 2:
            raise ValueError("Expected p with shape [B,H,W,D], [H,W,D], or [H,W].")
        pitch_u = float(pitch_m) * _unit_scale_from_m(sim_cfg.length_unit)
        core_lx, core_ly = _infer_core_size_from_array_shape(arr, pitch_u)
        _set_core_size_parameters(model, sim_cfg, core_lx, core_ly)

    create_air_and_pml_blocks(model, sim_cfg)
    build_cylinders_from_optimized_p(
        model=model,
        p=p,
        pitch_m=float(pitch_m),
        cfg=sim_cfg,
        batch_index=batch_index,
        param_index=param_index,
        drop_nonpositive=drop_nonpositive,
        clear_existing=True,
        verbose=False,
    )
    extrude_workplane(model, sim_cfg)
    setup_materials(model, sim_cfg)
    setup_ewfd_study(model, sim_cfg)
    solve_model(model)

    if export_csv:
        export_field_csv(model, export_csv)

    return save_model(model, output_mph)

"""COMSOL automation for metasurface design, with multiple input modes and flexible configuration.
WIP and subject to change. NOT IMPLEMENTED AS A STABLE PUBLIC API YET. Intended for internal use and experimentation.


def _build_cli() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="COMSOL metasurface automation")
    p.add_argument("--csv", default=None, help="Cylinder table CSV with x,y,radius columns.")
    p.add_argument("--radii-npy", default=None, help="2D radii array.")
    p.add_argument("--p-npy", default=None, help="Optimised p array [B,H,W,D], [H,W,D], or [H,W].")
    p.add_argument("--pitch", type=float, default=1.2, help="Pitch for --radii-npy mode.")
    p.add_argument("--pitch-m", type=float, default=None, help="Pitch in metres for --p-npy mode.")
    p.add_argument("--output-mph", required=True)
    p.add_argument("--template-mph", default=None)
    p.add_argument("--export-csv", default=None)

    p.add_argument("--host", default="localhost")
    p.add_argument("--port", type=int, default=11451)
    p.add_argument("--version", default=None)

    p.add_argument("--length-unit", default="mm")
    p.add_argument("--pillar-height", type=float, default=1.315)
    p.add_argument("--substrate-thickness", type=float, default=0.694)
    p.add_argument("--substrate-size-x", type=float, default=12.45)
    p.add_argument("--substrate-size-y", type=float, default=24.9)
    p.add_argument("--core-size-x", type=float, default=None)
    p.add_argument("--core-size-y", type=float, default=None)
    p.add_argument("--enable-substrate", action="store_true")
    p.add_argument("--disable-air-box", action="store_true")
    p.add_argument("--air-side-margin", type=float, default=1.0)
    p.add_argument("--air-above-thickness", type=float, default=1.0)
    p.add_argument("--disable-pml", action="store_true")
    p.add_argument("--pml-thickness", type=float, default=0.5)

    p.add_argument("--mesh-level", type=int, default=5)
    p.add_argument("--wavelength-start", type=float, default=2.3)
    p.add_argument("--wavelength-stop", type=float, default=2.7)
    p.add_argument("--wavelength-step", type=float, default=0.01)
    return p


def main():
    args = _build_cli().parse_args()

    provided_inputs = [bool(args.csv), bool(args.radii_npy), bool(args.p_npy)]
    if sum(provided_inputs) != 1:
        raise ValueError("Provide exactly one input: --csv, --radii-npy, or --p-npy")

    session_cfg = ComsolSessionConfig(
        host=args.host,
        port=args.port,
        version=args.version,
    )

    sim_cfg = MetasurfaceConfig(
        length_unit=args.length_unit,
        pillar_height=args.pillar_height,
        enable_substrate=args.enable_substrate,
        substrate_thickness=args.substrate_thickness,
        substrate_size_x=args.substrate_size_x,
        substrate_size_y=args.substrate_size_y,
        core_size_x=args.core_size_x,
        core_size_y=args.core_size_y,
        enable_air_box=not args.disable_air_box,
        air_side_margin=args.air_side_margin,
        air_above_thickness=args.air_above_thickness,
        enable_pml=not args.disable_pml,
        pml_thickness=args.pml_thickness,
        mesh_level=args.mesh_level,
        wavelength_start=args.wavelength_start,
        wavelength_stop=args.wavelength_stop,
        wavelength_step=args.wavelength_step,
    )

    if args.csv:
        saved = automate_from_csv(
            csv_path=args.csv,
            output_mph=args.output_mph,
            session_cfg=session_cfg,
            sim_cfg=sim_cfg,
            template_mph=args.template_mph,
            export_csv=args.export_csv,
        )
    elif args.radii_npy:
        radii = np.load(Path(args.radii_npy).expanduser().resolve())
        saved = automate_from_array(
            radii=radii,
            pitch=args.pitch,
            output_mph=args.output_mph,
            session_cfg=session_cfg,
            sim_cfg=sim_cfg,
            template_mph=args.template_mph,
            export_csv=args.export_csv,
        )
    else:
        if args.pitch_m is None:
            raise ValueError("--pitch-m is required when using --p-npy")
        p_arr = np.load(Path(args.p_npy).expanduser().resolve())
        saved = automate_from_optimized_p(
            p=p_arr,
            pitch_m=args.pitch_m,
            output_mph=args.output_mph,
            session_cfg=session_cfg,
            sim_cfg=sim_cfg,
            template_mph=args.template_mph,
            export_csv=args.export_csv,
        )

    print(f"Saved COMSOL model: {saved}")


if __name__ == "__main__":
    main()

"""





