"""Layout conversion helpers shared by COMSOL and CST automation."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def _as_numpy_array(p):
    """Convert array-like or tensor-like input to a NumPy array."""
    if hasattr(p, "detach") and callable(p.detach):
        p = p.detach()
    if hasattr(p, "cpu") and callable(p.cpu):
        p = p.cpu()
    if hasattr(p, "numpy") and callable(p.numpy):
        p = p.numpy()
    return np.asarray(p)


def infer_unit_cells_xy(
    p_array,
    batch_index: int = 0,
    param_index: int = 0,
) -> tuple[int, int]:
    """Infer (nx, ny) from p shaped as [B,H,W,D] / [H,W,D] / [H,W]."""
    arr = _as_numpy_array(p_array)
    if arr.ndim == 4:
        arr = arr[batch_index]
    if arr.ndim == 3:
        if param_index >= arr.shape[-1]:
            raise ValueError(
                f"param_index={param_index} out of bounds for last dimension {arr.shape[-1]}."
            )
        arr = arr[..., param_index]
    if arr.ndim != 2:
        raise ValueError("Expected p with shape [B,H,W,D], [H,W,D], or [H,W].")
    ny, nx = arr.shape
    return int(nx), int(ny)


def _infer_unit_cells_xy(
    p_array,
    batch_index: int = 0,
    param_index: int = 0,
) -> tuple[int, int]:
    """Backward-compatible alias for infer_unit_cells_xy."""
    return infer_unit_cells_xy(
        p_array=p_array,
        batch_index=batch_index,
        param_index=param_index,
    )


def _length_unit_scale_from_m(length_unit: str) -> float:
    """Return scale factor to convert meters to the requested length unit."""
    unit = str(length_unit).strip().lower()
    scales = {
        "m": 1.0,
        "mm": 1e3,
        "um": 1e6,
        "nm": 1e9,
    }
    if unit not in scales:
        raise ValueError(
            f"Unsupported length_unit '{length_unit}'. Use one of: {list(scales.keys())}."
        )
    return scales[unit]


def optimized_p_to_comsol_cylinder_table(
    p,
    pitch_m,
    length_unit="mm",
    batch_index=0,
    param_index=0,
    drop_nonpositive=True,
    quarter=False,
    include_symmetry_axes=True,
    csv_path=None,
):
    """Convert optimized metasurface parameters into COMSOL cylinder-table format."""
    arr = _as_numpy_array(p)

    if arr.ndim == 4:
        arr = arr[batch_index]

    if arr.ndim == 3:
        if param_index >= arr.shape[-1]:
            raise ValueError(
                f"param_index={param_index} out of bounds for last dimension {arr.shape[-1]}."
            )
        arr = arr[..., param_index]
    elif arr.ndim != 2:
        raise ValueError("Expected p with shape [B,H,W,D], [H,W,D], or [H,W].")

    arr = np.asarray(arr, dtype=float)
    ny, nx = arr.shape

    scale = _length_unit_scale_from_m(length_unit)
    pitch_u = float(pitch_m) * scale
    radius_u = arr * scale

    xs = (np.arange(nx) - nx / 2.0 + 0.5) * pitch_u
    ys = (np.arange(ny) - ny / 2.0 + 0.5) * pitch_u

    rows = []
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            r = float(radius_u[iy, ix])
            if drop_nonpositive and r <= 0.0:
                continue
            if quarter:
                if include_symmetry_axes:
                    if x < 0.0 or y < 0.0:
                        continue
                else:
                    if x <= 0.0 or y <= 0.0:
                        continue
            rows.append((x, y, r, iy, ix))

    df = pd.DataFrame(rows, columns=["x", "y", "radius", "row", "col"])

    if csv_path is not None:
        csv_target = Path(csv_path)
        csv_target.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(csv_target, index=False)

    return df


def optimized_p_to_cst_cylinder_table(
    p,
    pitch_m,
    length_unit="mm",
    batch_index=0,
    param_index=0,
    drop_nonpositive=True,
    quarter=False,
    include_symmetry_axes=True,
    csv_path=None,
):
    """Convert optimized metasurface parameters into CST cylinder-table format."""
    return optimized_p_to_comsol_cylinder_table(
        p=p,
        pitch_m=pitch_m,
        length_unit=length_unit,
        batch_index=batch_index,
        param_index=param_index,
        drop_nonpositive=drop_nonpositive,
        quarter=quarter,
        include_symmetry_axes=include_symmetry_axes,
        csv_path=csv_path,
    )


def optimized_p_to_quarter_with_symmetry(
    p,
    pitch_m,
    length_unit="mm",
    batch_index=0,
    param_index=0,
    symmetry_x="pec",
    symmetry_y="pmc",
    include_symmetry_axes=True,
    drop_nonpositive=True,
    csv_path=None,
):
    """Prepare quarter-lens cylinder data and symmetry metadata."""
    df = optimized_p_to_comsol_cylinder_table(
        p=p,
        pitch_m=pitch_m,
        length_unit=length_unit,
        batch_index=batch_index,
        param_index=param_index,
        drop_nonpositive=drop_nonpositive,
        quarter=True,
        include_symmetry_axes=include_symmetry_axes,
        csv_path=csv_path,
    )
    symmetry = {
        "x_plane": {"type": str(symmetry_x).lower(), "axis": "x", "location": 0.0},
        "y_plane": {"type": str(symmetry_y).lower(), "axis": "y", "location": 0.0},
    }
    return df, symmetry
