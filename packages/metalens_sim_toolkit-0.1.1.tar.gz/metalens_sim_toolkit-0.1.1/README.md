# metalens-sim-toolkit

Standalone CST and COMSOL automation helpers extracted from D-Flat.

## What is included

- `metalens_sim_toolkit.cst_automation`
- `metalens_sim_toolkit.comsol_automation`
- shared layout conversion helpers (`optimized_p_to_*_cylinder_table`)

## Quick start (uv)

```bash
uv sync
uv run python -c "import metalens_sim_toolkit.cst_automation as c; print(hasattr(c, 'automate_cst_full_from_optimized_p'))"
```

## COMSOL CLI

```bash
uv run metalens-comsol-auto --help
```

## Publishing with uv

Build:

```bash
uv build
```

Publish to PyPI:

```bash
uv publish --token <PYPI_TOKEN>
```

## Create a new git repo from this folder

```bash
git init
git add .
git commit -m "Initial metalens-sim-toolkit package"
```

