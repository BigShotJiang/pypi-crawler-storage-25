from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    pass
