# InstantAPI Python SDK

The official Python SDK for [InstantAPI](https://instantapis.net) — AI-powered text processing in a single API call.

## Installation

```bash
pip install instantapi-sdk
```

## Quick Start

```python
from instantapi import InstantAPI

api = InstantAPI("your-api-key")

# Summarize text
result = api.summarize("Your long article text here...")
print(result["summary"])
```

## Authentication

Sign up at [instantapis.net](https://instantapis.net) to get your API key, then pass it when creating the client:

```python
api = InstantAPI("your-api-key")
```

The key is sent via the `Authorization: Bearer` header on every request.

## Methods

### `summarize(text, length="medium")`

Summarize a block of text.

```python
result = api.summarize(
    "Artificial intelligence has transformed industries across the globe...",
    length="short",   # "short", "medium", or "long"
)
print(result["summary"])
```

### `extract(text, fields=None)`

Extract structured data from unstructured text.

```python
result = api.extract(
    "John Smith, john@example.com, joined on 2024-01-15",
    fields=["name", "email", "date"],
)
print(result)
# {"name": "John Smith", "email": "john@example.com", "date": "2024-01-15"}
```

When `fields` is omitted the API auto-detects relevant fields.

### `analyze(text)`

Perform comprehensive text analysis (themes, entities, tone).

```python
result = api.analyze("The quarterly earnings exceeded expectations...")
print(result["themes"])
print(result["entities"])
```

### `translate(text, target_language)`

Translate text into any language.

```python
result = api.translate("Hello, world!", target_language="es")
print(result["translation"])  # "Hola, mundo!"
```

### `sentiment(text)`

Analyze text sentiment.

```python
result = api.sentiment("I absolutely love this product!")
print(result["sentiment"])   # "positive"
print(result["confidence"])  # 0.97
```

### `code(prompt, language=None)`

Generate code from a natural-language description.

```python
result = api.code(
    "Sort a list of dicts by the 'age' key",
    language="python",
)
print(result["code"])
```

## Error Handling

The SDK raises typed exceptions so you can handle specific failure modes:

```python
from instantapi import (
    InstantAPI,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    InstantAPIError,
)

api = InstantAPI("your-api-key")

try:
    result = api.summarize("Some text...")
except AuthenticationError:
    print("Invalid API key. Check your credentials.")
except InsufficientCreditsError:
    print("Out of credits. Top up at https://instantapis.net.")
except RateLimitError:
    print("Too many requests. Please slow down.")
except InstantAPIError as e:
    print(f"API error [{e.status_code}]: {e.message}")
```

| Exception                 | HTTP Status | When                          |
|---------------------------|-------------|-------------------------------|
| `AuthenticationError`     | 401         | Invalid or missing API key    |
| `InsufficientCreditsError`| 402         | Account has no credits left   |
| `RateLimitError`          | 429         | Too many requests             |
| `InstantAPIError`         | Any         | Base class for all API errors |

## Advanced Configuration

```python
# Custom base URL (e.g., for self-hosted instances)
api = InstantAPI("your-api-key", base_url="https://my-instance.example.com")

# Custom timeout (default is 30 seconds)
api = InstantAPI("your-api-key", timeout=60)
```

## Full Documentation

For complete API reference, guides, and examples visit **[https://instantapis.net/docs](https://instantapis.net/docs)**.

## License

MIT
