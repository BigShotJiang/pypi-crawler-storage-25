"""Custom exceptions for the InstantAPI SDK."""


class InstantAPIError(Exception):
    """Base exception for all InstantAPI errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API response, if available.
        response: Raw response object, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: int = None,
        response=None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)

    def __str__(self) -> str:
        if self.status_code:
            return f"[{self.status_code}] {self.message}"
        return self.message


class AuthenticationError(InstantAPIError):
    """Raised when the API key is invalid or missing (HTTP 401)."""

    def __init__(self, message: str = "Invalid or missing API key.", response=None) -> None:
        super().__init__(message=message, status_code=401, response=response)


class InsufficientCreditsError(InstantAPIError):
    """Raised when the account has insufficient credits (HTTP 402)."""

    def __init__(
        self,
        message: str = "Insufficient credits. Please top up your account at https://instantapis.net.",
        response=None,
    ) -> None:
        super().__init__(message=message, status_code=402, response=response)


class RateLimitError(InstantAPIError):
    """Raised when the API rate limit has been exceeded (HTTP 429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded. Please slow down your requests.",
        response=None,
    ) -> None:
        super().__init__(message=message, status_code=429, response=response)
