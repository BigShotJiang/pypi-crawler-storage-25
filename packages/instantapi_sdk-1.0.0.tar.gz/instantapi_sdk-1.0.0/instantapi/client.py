"""Main client module for the InstantAPI SDK."""

from typing import Any, Dict, List, Optional

import requests

from .exceptions import (
    AuthenticationError,
    InstantAPIError,
    InsufficientCreditsError,
    RateLimitError,
)


class InstantAPI:
    """Official Python client for the InstantAPI service.

    Provides methods for text summarization, data extraction, content analysis,
    translation, sentiment analysis, code generation, and batch processing.

    Example::

        from instantapi import InstantAPI

        api = InstantAPI("ia_live_your_key")
        result = api.summarize("Long article text here...")
        print(result["data"])

    Args:
        api_key: Your InstantAPI key (starts with ``ia_live_``).
        base_url: API base URL. Override for testing or self-hosted instances.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://instantapis.net",
        timeout: int = 30,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must be a non-empty string.")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _request(self, task: str, input_text: str, options: Optional[Dict] = None) -> Dict:
        """Send a request to the InstantAPI generate endpoint.

        Args:
            task: The task to perform (e.g. ``"summarize"``).
            input_text: The text input to process.
            options: Optional task-specific parameters.

        Returns:
            Parsed JSON response as a dictionary.

        Raises:
            AuthenticationError: If the API key is invalid (401).
            InsufficientCreditsError: If credits are exhausted (402).
            RateLimitError: If rate limits are exceeded (429).
            InstantAPIError: For any other API or network error.
        """
        url = f"{self.base_url}/api/v1/generate"
        body: Dict[str, Any] = {"task": task, "input": input_text}
        if options:
            body["options"] = options

        return self._do_request(url, body)

    def _do_request(self, url: str, body: Dict) -> Dict:
        """Execute an HTTP POST and handle errors."""
        try:
            response = self._session.post(url, json=body, timeout=self.timeout)
        except requests.ConnectionError as exc:
            raise InstantAPIError(f"Connection error: {exc}") from exc
        except requests.Timeout as exc:
            raise InstantAPIError(f"Request timed out after {self.timeout}s.") from exc
        except requests.RequestException as exc:
            raise InstantAPIError(f"Request failed: {exc}") from exc

        if response.status_code == 401:
            raise AuthenticationError(response=response)
        if response.status_code == 402:
            raise InsufficientCreditsError(response=response)
        if response.status_code == 429:
            raise RateLimitError(response=response)
        if not response.ok:
            try:
                detail = response.json().get("error", response.text)
            except ValueError:
                detail = response.text
            raise InstantAPIError(
                message=f"API error: {detail}",
                status_code=response.status_code,
                response=response,
            )

        return response.json()

    # ------------------------------------------------------------------
    # Public API methods — Single tasks
    # ------------------------------------------------------------------

    def summarize(self, text: str, length: str = "medium") -> Dict:
        """Summarize a block of text.

        Args:
            text: The text to summarize.
            length: Desired summary length — ``"short"``, ``"medium"``,
                or ``"long"``. Defaults to ``"medium"``.

        Example::

            result = api.summarize("Long article...", length="short")
            print(result["data"]["summary"])
        """
        return self._request("summarize", text, {"length": length})

    def extract(self, text: str, fields: Optional[List[str]] = None) -> Dict:
        """Extract structured data from unstructured text.

        Args:
            text: The text to extract information from.
            fields: Optional list of field names to extract.

        Example::

            result = api.extract(
                "John Smith, john@example.com",
                fields=["name", "email"],
            )
            print(result["data"])
        """
        options: Dict[str, Any] = {}
        if fields is not None:
            options["fields"] = fields
        return self._request("extract", text, options or None)

    def analyze(self, text: str) -> Dict:
        """Analyze content for insights, themes, and patterns.

        Args:
            text: The text to analyze.

        Example::

            result = api.analyze("The quarterly earnings exceeded ...")
            print(result["data"])
        """
        return self._request("analyze", text)

    def translate(self, text: str, target_language: str) -> Dict:
        """Translate text into a target language.

        Args:
            text: The text to translate.
            target_language: Target language name or ISO code.

        Example::

            result = api.translate("Hello, world!", target_language="es")
            print(result["data"])
        """
        return self._request("translate", text, {"targetLanguage": target_language})

    def sentiment(self, text: str) -> Dict:
        """Analyze the sentiment of the given text.

        Args:
            text: The text to evaluate.

        Example::

            result = api.sentiment("I absolutely love this product!")
            print(result["data"]["sentiment"])  # "positive"
        """
        return self._request("sentiment", text)

    def code(self, prompt: str, language: Optional[str] = None) -> Dict:
        """Generate code from a natural-language prompt.

        Args:
            prompt: Description of the code to generate.
            language: Optional target programming language.

        Example::

            result = api.code("Sort a list by age", language="python")
            print(result["data"]["code"])
        """
        options: Dict[str, Any] = {}
        if language is not None:
            options["language"] = language
        return self._request("code", prompt, options or None)

    # ------------------------------------------------------------------
    # Batch API
    # ------------------------------------------------------------------

    def batch(self, tasks: List[Dict[str, Any]]) -> Dict:
        """Process multiple tasks in a single request.

        Args:
            tasks: A list of task dicts, each with ``task``, ``input``,
                and optionally ``id`` and ``options`` keys. Max 20 tasks.

        Returns:
            A dict with ``results`` (list) and ``summary`` (total/succeeded/failed).

        Example::

            result = api.batch([
                {"task": "summarize", "input": "Long article..."},
                {"task": "sentiment", "input": "I love this!"},
                {"task": "extract", "input": "John at john@example.com",
                 "options": {"fields": ["name", "email"]}},
            ])
            for r in result["data"]["results"]:
                print(r["id"], r["success"], r["data"])
        """
        url = f"{self.base_url}/api/v1/batch"
        return self._do_request(url, {"tasks": tasks})
