"""InstantAPI SDK — Official Python client for InstantAPI.

Quick start::

    from instantapi import InstantAPI

    api = InstantAPI("your-api-key")
    result = api.summarize("Some long text...")
    print(result)
"""

from .client import InstantAPI
from .exceptions import (
    AuthenticationError,
    InstantAPIError,
    InsufficientCreditsError,
    RateLimitError,
)

__version__ = "1.0.0"

__all__ = [
    "InstantAPI",
    "InstantAPIError",
    "AuthenticationError",
    "InsufficientCreditsError",
    "RateLimitError",
]
