"""Setup script for the InstantAPI SDK."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="instantapi-sdk",
    version="1.0.0",
    author="InstantAPI",
    author_email="support@instantapis.net",
    description="Official Python SDK for InstantAPI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://instantapis.net",
    project_urls={
        "Documentation": "https://instantapis.net/docs",
        "Source": "https://github.com/instantapi/instantapi-python",
        "Bug Tracker": "https://github.com/instantapi/instantapi-python/issues",
    },
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
    ],
    python_requires=">=3.7",
    keywords=["ai", "api", "nlp", "summarize", "translate", "sentiment"],
    license="MIT",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
