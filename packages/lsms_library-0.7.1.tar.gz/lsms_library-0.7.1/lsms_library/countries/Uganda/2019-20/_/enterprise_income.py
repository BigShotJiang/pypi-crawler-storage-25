from lsms_library.local_tools import to_parquet, get_dataframe
#!/usr/bin/env python3
import numpy as np
import pandas as pd

fn = '../Data/HH/gsec12_2.dta'
hhid = 'hhid'
d = dict(revenue = 'h12q10',
         wagebill = 'h12q12',
         materials = 'h12q13',
         otherexpense = 'h12q14')

df = get_dataframe(fn)

enterprise_income = df.groupby(hhid)[list(d.values())].sum() # Sum over enterprises
enterprise_income.index.name = 'j'

enterprise_income = enterprise_income.rename(columns={v:k for k,v in d.items()})

enterprise_income['profits'] = np.maximum(enterprise_income['revenue'] - enterprise_income[['wagebill','materials','otherexpense']].sum(axis=1),0)
enterprise_income['losses'] = -np.minimum(enterprise_income['revenue'] - enterprise_income[['wagebill','materials','otherexpense']].sum(axis=1),0)

to_parquet(enterprise_income, 'enterprise_income.parquet')
