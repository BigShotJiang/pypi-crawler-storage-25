#!/usr/bin/env python

from calendar import month
import sys
sys.path.append('../../../_/')
from lsms_library.local_tools import to_parquet, get_dataframe
import pandas as pd
from datetime import datetime


#shock dataset
df = get_dataframe('../Data/sect9_hh_w4.dta')
df = df[df['s9q01'] == '1. YES'] #filter for valid entry 

shocks = pd.DataFrame({"j": df.household_id.values.tolist(),
                    "Shock":df.shock_type.values.tolist(), 
                    "AffectedIncome":df.s9q03a.values.tolist(), 
                    "AffectedAssets":df.s9q03b.values.tolist(), 
                    "AffectedProduction":df.s9q03c.values.tolist(), 
                    "AffectedConsumption":df.s9q03e.values.tolist(), 
                    "AffectedFoodStock":df.s9q03d.values.tolist(), 
                    "HowCoped0":df.s9q04_1.values.tolist(),
                    "HowCoped1":df.s9q04_2.values.tolist(),
                    "HowCoped2":df.s9q04_3.values.tolist(),
                    })

#converting data types 
for col in ["AffectedIncome",  "AffectedAssets",  "AffectedProduction", "AffectedConsumption", "AffectedFoodStock"]:
    shocks[col] = shocks[col].map({"2. DECREASED": True,"1. INCREASED": False, "3. DID NOT CHANGE": False})
    shocks[col] = shocks[col].fillna(False).astype('boolean')
shocks = shocks.astype({'Shock': 'category',
                        "HowCoped0": 'category',
                        "HowCoped1": 'category',
                        "HowCoped2": 'category'
                        }) 

shocks.insert(1, 't', '2018-19')
shocks = shocks.set_index(['j','t','Shock'])

to_parquet(shocks,'shocks.parquet')
