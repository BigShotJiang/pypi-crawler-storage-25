#!/usr/bin/env python
from lsms_library.local_tools import to_parquet, get_dataframe
import sys
import numpy as np
import pandas as pd
import json

C = []

lbls = json.load(open('../../_/nonfood_items.json'))

#########################
# Harvest
files = {'2013Q1':['Nigeria/2012-13/Data/sect11a_harvestw2.csv',
                   'Nigeria/2012-13/Data/sect11b_harvestw2.csv',
                   'Nigeria/2012-13/Data/sect11c_harvestw2.csv',
                   'Nigeria/2012-13/Data/sect11d_harvestw2.csv',
                   'Nigeria/2012-13/Data/sect11e_harvestw2.csv'],
         '2012Q3':['Nigeria/2012-13/Data/sect8a_plantingw2.csv',
                   'Nigeria/2012-13/Data/sect8b_plantingw2.csv',
                   'Nigeria/2012-13/Data/sect8c_plantingw2.csv',
                   'Nigeria/2012-13/Data/sect8d_plantingw2.csv',
                   'Nigeria/2012-13/Data/sect8e_plantingw2.csv']}

vars={'hhid': 'j',
      'zone': 'm',
      'item_cd' : 'i',
      's8q2': 'value',
      's8q4': 'value',
      's8q6': 'value',
      's8q8': 'value',
      's8q10': 'value',
      's11aq2': 'value',  # Has your household consumed [XX] in the past 7 days. 
      's11bq4': 'value',  # Has your household consumed [XX] in the past month.
      's11cq6': 'value',  # Has your household consumed [XX] in the past month.
      's11dq8': 'value',  # Has your household consumed [XX] in the past month.
      's11eq10': 'value',  # Has your household consumed [XX] in the past month.
      'sector': 'rural',  # 1=Urban; 2=Rural
      't':'t'
      }

for t in files.keys():
    for fn in files[t]:
        df = get_dataframe(fn)
        df = df.rename(columns=vars)

        df['t'] = t
        df = df.replace({'i':{int(k):v for k,v in lbls[t].items()}})

        df = df[list(set(vars.values()))]
        C.append(df)

###################

x = pd.concat(C,axis=0)


x['m'] = x['m'].replace({1:'North central',
                         2:'North east',
                         3:'North west',
                         4:'South east',
                         5:'South south',
                         6:'South west'})


x = x.drop_duplicates()

x['j'] = x['j'].astype(int).astype(str)

x = x.set_index(['j','t','m','i'])

x = x['value'].unstack('i')

to_parquet(x, 'nonfood_expenditures.parquet',compression='gzip')
