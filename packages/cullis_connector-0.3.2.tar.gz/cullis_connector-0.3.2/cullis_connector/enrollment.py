"""Device-code enrollment flow — Connector side of Phase 2 (#64).

Mirror of the server API in ``mcp_proxy.enrollment``:

1. Generate EC P-256 keypair locally (private key never leaves the machine).
2. ``POST /v1/enrollment/start`` with pubkey + self-declared identity.
3. Print the ``enroll_url`` to stderr — the user shares it with the admin
   (or opens it themselves for future HTML form flavour) so the admin can
   verify the request in the dashboard.
4. Poll ``GET /v1/enrollment/{session_id}/status`` at the interval the
   server suggested; stop on terminal states (approved / rejected /
   expired).
5. On ``approved``: persist cert + metadata via the identity store, return
   the new :class:`IdentityBundle` to the caller.
"""
from __future__ import annotations

import logging
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import os
import secrets

import bcrypt
import httpx
from cryptography import x509

from cullis_connector.identity import (
    IdentityBundle,
    generate_keypair,
    public_key_to_pem,
    save_identity,
)
from cullis_connector.identity.store import IdentityMetadata, load_identity


_API_KEY_PREFIX = "sk_local_"


def _generate_api_key() -> str:
    """Mirror of mcp_proxy.auth.api_key.generate_api_key — same format
    (``sk_local_<label>_<32-hex>``) so the server accepts the resulting hash
    with its existing ``verify_api_key`` helper."""
    label = os.environ.get("HOSTNAME", "connector").replace(" ", "-")[:32]
    return f"{_API_KEY_PREFIX}{label}_{secrets.token_hex(16)}"


def _bcrypt_hash(raw: str) -> str:
    return bcrypt.hashpw(raw.encode(), bcrypt.gensalt()).decode()

_log = logging.getLogger("cullis_connector.enrollment")


class EnrollmentFailed(Exception):
    """Raised for any non-success terminal outcome of the flow."""


@dataclass
class RequesterInfo:
    name: str
    email: str
    reason: str | None = None
    device_info: str | None = None


def enroll(
    *,
    site_url: str,
    config_dir: Path,
    requester: RequesterInfo,
    verify_tls: bool = True,
    request_timeout_s: float = 10.0,
    max_wait_s: int = 30 * 60,
    poll_sink=sys.stderr,
) -> IdentityBundle:
    """Full device-code enrollment, blocking until admin decides or TTL expires.

    Parameters
    ----------
    site_url:
        Base URL of the Cullis Site (e.g. ``https://cullis.acme.local:9443``).
    config_dir:
        Where to persist the resulting identity (``<config_dir>/identity/``).
    requester:
        Self-declared identity — the admin is the authority that decides
        agent_id, capabilities, and groups. Stored for audit only.
    poll_sink:
        Stream for human-readable progress output. Defaults to stderr so
        it never pollutes an MCP stdio transport when the caller also
        happens to be a server process.
    """
    site_url = site_url.rstrip("/")
    private_key = generate_keypair()
    pubkey_pem = public_key_to_pem(private_key.public_key()).decode()

    # Generate an X-API-Key locally. The raw key never leaves this process
    # until we persist it to disk post-approval. The server receives only
    # the bcrypt hash and copies it into internal_agents.api_key_hash on
    # approve() so /v1/egress/* auth works from day one.
    api_key_raw = _generate_api_key()
    api_key_hash = _bcrypt_hash(api_key_raw)

    # F-B-11 Phase 3d (#181) — generate the DPoP keypair locally, submit
    # the public JWK at start, persist the private half alongside the
    # identity on approval. The server computes its RFC 7638 thumbprint
    # and stores it on ``internal_agents.dpop_jkt`` (#207) so every
    # proof the SDK later signs is pinned to this specific keypair.
    from cullis_sdk.dpop import DpopKey
    dpop_key = DpopKey.generate()
    dpop_public_jwk = dpop_key.public_jwk

    start_resp = _start(
        site_url=site_url,
        pubkey_pem=pubkey_pem,
        requester=requester,
        api_key_hash=api_key_hash,
        dpop_jwk=dpop_public_jwk,
        verify_tls=verify_tls,
        timeout_s=request_timeout_s,
    )
    session_id = start_resp["session_id"]
    enroll_url = start_resp["enroll_url"]
    poll_interval_s = int(start_resp.get("poll_interval_s", 5))

    print(
        "Cullis enrollment started.\n"
        f"  Share this URL with your admin: {enroll_url}\n"
        "  Waiting for admin decision (will poll until approved, rejected, "
        f"or the session expires at {start_resp.get('expires_at', 'n/a')}).",
        file=poll_sink,
        flush=True,
    )

    record = _poll_until_resolved(
        site_url=site_url,
        session_id=session_id,
        poll_interval_s=poll_interval_s,
        max_wait_s=max_wait_s,
        verify_tls=verify_tls,
        timeout_s=request_timeout_s,
        poll_sink=poll_sink,
    )

    status = record.get("status")
    if status == "rejected":
        raise EnrollmentFailed(
            f"Admin rejected the enrollment: "
            f"{record.get('rejection_reason') or '(no reason given)'}"
        )
    if status == "expired":
        raise EnrollmentFailed("Enrollment session expired before admin decided.")
    if status != "approved":
        raise EnrollmentFailed(f"Unexpected enrollment status '{status}'")

    cert_pem = record.get("cert_pem")
    if not cert_pem:
        raise EnrollmentFailed("Approved enrollment is missing cert_pem — server bug?")

    agent_id = str(record.get("agent_id") or "")
    capabilities = list(record.get("capabilities") or [])

    metadata = IdentityMetadata(
        agent_id=agent_id,
        capabilities=capabilities,
        site_url=site_url,
        issued_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )
    save_identity(
        config_dir=config_dir,
        cert_pem=cert_pem,
        private_key=private_key,
        ca_chain_pem=None,  # Phase 2c will fetch the CA chain from the Site.
        metadata=metadata,
        api_key=api_key_raw,
        dpop_private_jwk=dpop_key.private_jwk(),
    )

    print(
        f"✓ Enrollment approved. Agent ID assigned: {agent_id}",
        file=poll_sink,
        flush=True,
    )

    return load_identity(config_dir)


# ── Internals ────────────────────────────────────────────────────────────


def _start(
    *,
    site_url: str,
    pubkey_pem: str,
    requester: RequesterInfo,
    api_key_hash: str | None,
    verify_tls: bool,
    timeout_s: float,
    dpop_jwk: dict | None = None,
) -> dict[str, Any]:
    body = {
        "pubkey_pem": pubkey_pem,
        "requester_name": requester.name,
        "requester_email": requester.email,
    }
    if requester.reason:
        body["reason"] = requester.reason
    if requester.device_info:
        body["device_info"] = requester.device_info
    if api_key_hash:
        body["api_key_hash"] = api_key_hash
    # F-B-11 Phase 3d — include the public DPoP JWK so Mastio can
    # compute + store its thumbprint on approve (wire added in #207).
    if dpop_jwk is not None:
        body["dpop_jwk"] = dpop_jwk

    try:
        response = httpx.post(
            f"{site_url}/v1/enrollment/start",
            json=body,
            verify=verify_tls,
            timeout=timeout_s,
        )
    except httpx.HTTPError as exc:
        raise EnrollmentFailed(f"Could not reach Site at {site_url}: {exc}") from exc

    if response.status_code != 201:
        raise EnrollmentFailed(
            f"Site rejected enrollment start (HTTP {response.status_code}): "
            f"{response.text[:300]}"
        )
    return response.json()


def _poll_until_resolved(
    *,
    site_url: str,
    session_id: str,
    poll_interval_s: int,
    max_wait_s: int,
    verify_tls: bool,
    timeout_s: float,
    poll_sink,
) -> dict[str, Any]:
    deadline = time.monotonic() + max_wait_s
    poll_url = f"{site_url}/v1/enrollment/{session_id}/status"
    last_printed = 0.0

    while True:
        try:
            response = httpx.get(poll_url, verify=verify_tls, timeout=timeout_s)
        except httpx.HTTPError as exc:
            _log.warning("poll transient error", extra={"err": str(exc)})
            if time.monotonic() >= deadline:
                raise EnrollmentFailed(
                    f"Giving up polling after {max_wait_s}s: {exc}"
                ) from exc
            time.sleep(poll_interval_s)
            continue

        if response.status_code == 404:
            raise EnrollmentFailed(
                "Enrollment session no longer exists — may have been expired "
                "and purged."
            )
        if response.status_code != 200:
            raise EnrollmentFailed(
                f"Site returned HTTP {response.status_code} during poll: "
                f"{response.text[:300]}"
            )

        record = response.json()
        if record.get("status") != "pending":
            return record

        now = time.monotonic()
        if now - last_printed > 60:
            waited = int(max_wait_s - (deadline - now))
            print(
                f"  … still waiting for admin decision ({waited}s elapsed)",
                file=poll_sink,
                flush=True,
            )
            last_printed = now

        if now >= deadline:
            raise EnrollmentFailed(
                f"Gave up after {max_wait_s}s without a decision — try again."
            )
        time.sleep(poll_interval_s)


def cert_fingerprint(cert: x509.Certificate) -> str:
    """SHA-256 of the cert DER, 64-char hex. Used for operator verification."""
    import hashlib
    return hashlib.sha256(cert.public_bytes(encoding=_DER)).hexdigest()


# local alias to avoid a circular-looking import in the helper above
from cryptography.hazmat.primitives.serialization import Encoding as _SerializationEncoding
_DER = _SerializationEncoding.DER
