# tests/test_types.py

from typing import get_args, get_origin

from runi.types import Entries, Entry


def test_types_exist():
    assert Entry is str

    assert get_origin(Entries) is list
    assert get_args(Entries) == (str,)
