# tests/test_config.py

from pathlib import Path

from runi.config import get_config_dir, get_config_file, load_config


def test_config_paths():
    config_dir = get_config_dir()
    config_file = get_config_file()

    assert isinstance(config_dir, Path)
    assert isinstance(config_file, Path)


def test_load_config_creates_file():
    config = load_config()

    assert isinstance(config, dict)

    config_file = get_config_file()
    assert config_file.exists()
