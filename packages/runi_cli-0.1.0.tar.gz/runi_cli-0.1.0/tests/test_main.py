# tests/test_main.py


import sys

from runi.__main__ import main


def test_main_entrypoint(monkeypatch):
    monkeypatch.setattr(sys, "argv", ["runi", "--help"])

    try:
        main()
    except SystemExit:
        pass  # argparse exits
