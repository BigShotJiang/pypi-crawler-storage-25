# tests/test_cli_args.py

from runi.cli_args import parse_args


def test_parse_harvest():
    args = parse_args(["harvest"])
    assert args.command == "harvest"


def test_parse_search():
    args = parse_args(["search", "git"])
    assert args.command == "search"
    assert args.keyword == "git"
