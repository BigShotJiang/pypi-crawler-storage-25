# tests/core/test_integration.py

from pathlib import Path

from runi.core.harvest import harvest_entries
from runi.core.search import search_entries
from runi.core.transform import transform_entries


def test_full_pipeline(tmp_path: Path):
    file = tmp_path / "command.txt"
    file.write_text("[git] rebase -i\n[git] commit\n")

    entries = harvest_entries(tmp_path, ["command.txt"])
    entries = transform_entries(entries)
    entries = search_entries(entries, "git")

    assert len(entries) == 2
