# tests/core/test_files.py

from pathlib import Path

from runi.core.files import find_files, read_lines


def test_find_files(tmp_path: Path):
    (tmp_path / "a.txt").write_text("hello")
    (tmp_path / "b.txt").write_text("world")

    files = find_files(tmp_path, "*.txt")

    assert len(files) == 2


def test_read_lines(tmp_path: Path):
    file = tmp_path / "a.txt"
    file.write_text("line1\n\nline2\n")

    lines = read_lines([file])

    assert lines == ["line1", "line2"]


def test_find_files_no_match(tmp_path: Path):
    files = find_files(tmp_path, "*.txt")
    assert files == []
