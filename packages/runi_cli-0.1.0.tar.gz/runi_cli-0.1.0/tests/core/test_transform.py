# tests/core/test_transform.py

from runi.core.transform import transform_entries


def test_transform_deduplicate_and_sort():
    entries = ["b", "a", "A", "b"]

    result = transform_entries(entries)

    assert result == ["a", "A", "b"] or result == ["A", "a", "b"]
