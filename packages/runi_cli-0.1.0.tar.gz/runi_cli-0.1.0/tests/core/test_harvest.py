# tests/core/test_harvest.py

from pathlib import Path

from runi.core.harvest import harvest_entries


def test_harvest_entries(tmp_path: Path):
    file = tmp_path / "command.txt"
    file.write_text("a\nb\n")

    entries = harvest_entries(tmp_path, ["command.txt"])

    assert entries == ["a", "b"]
