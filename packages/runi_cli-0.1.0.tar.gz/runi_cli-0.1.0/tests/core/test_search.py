# tests/core/test_search.py

from runi.core.search import search_entries


def test_search_basic():
    entries = ["git commit", "docker run"]

    result = search_entries(entries, "git")

    assert result == ["git commit"]


def test_search_multi_word():
    entries = [
        "ruff format src",
        "ruff check .",
        "format src",
    ]

    result = search_entries(entries, "ruff src")

    assert "ruff format src" in result
    assert "ruff check ." not in result


def test_search_with_tags():
    entries = [
        "[git] rebase -i",
        "[docker] run",
    ]

    result = search_entries(entries, "git")

    assert "[git] rebase -i" in result


def test_search_ranking():
    entries = [
        "git rebase",
        "rebase -i HEAD~3",
    ]

    result = search_entries(entries, "rebase")

    # higher relevance should come first
    assert result[0] in entries
