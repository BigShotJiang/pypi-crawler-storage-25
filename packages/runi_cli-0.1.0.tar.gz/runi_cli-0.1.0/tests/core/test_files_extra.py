# tests/core/test_files_extra.py

from pathlib import Path

from runi.core.files import read_lines, scan_stats


def test_read_lines_handles_error(tmp_path: Path):
    fake_file = tmp_path / "missing.txt"

    lines = read_lines([fake_file])

    assert lines == []


def test_scan_stats(tmp_path: Path):
    file1 = tmp_path / "a.txt"
    file1.write_text("hello")

    file2 = tmp_path / "b.txt"
    file2.write_text("world")

    count, size = scan_stats(tmp_path, ["*.txt"])

    assert count == 2
    assert size > 0
