# tests/core/test_printer.py

from runi.core.printer import strip_tags


def test_strip_single_tag():
    assert strip_tags("[git] commit") == "commit"


def test_strip_multiple_tags():
    assert strip_tags("[git][advanced] rebase") == "rebase"


def test_strip_no_tag():
    assert strip_tags("hello") == "hello"


def test_strip_broken_tag():
    assert strip_tags("[git rebase") == "[git rebase"


def test_strip_edge_case_empty():
    assert strip_tags("") == ""
