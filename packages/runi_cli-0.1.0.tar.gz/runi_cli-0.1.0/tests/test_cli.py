# tests/test_cli.py

import sys
from pathlib import Path

from runi.cli import main


def run_cli(args):
    old_argv = sys.argv
    sys.argv = ["runi", *args]

    try:
        main()
    finally:
        sys.argv = old_argv


def test_cli_harvest(tmp_path: Path, monkeypatch):
    file = tmp_path / "command.txt"
    file.write_text("hello\nworld\n")

    monkeypatch.chdir(tmp_path)

    run_cli(["harvest"])


def test_cli_search(tmp_path: Path, monkeypatch):
    file = tmp_path / "command.txt"
    file.write_text("git commit\nruff format\n")

    monkeypatch.chdir(tmp_path)

    run_cli(["git"])  # shortcut mode


def test_cli_doctor(monkeypatch, tmp_path: Path):
    monkeypatch.chdir(tmp_path)

    run_cli(["doctor"])
