# runi

> Search what you keep. Run what you need.

**runi** turns your plain text into a fast, searchable command palette.

It scans your files, extracts useful lines, and helps you recall them instantly in your terminal.

## Why runi?

You probably have useful commands scattered across:

- command.txt
- notes
- random files
- past solutions you don’t want to lose

You _could_ search everything with tools like ripgrep.

But that often means:

- too much noise
- irrelevant results
- repeating the same search effort

**runi** takes a different approach:

> It searches only what you intentionally keep.

## Concept

- your files = knowledge source
- runi = clean, curated index
- fzf = interactive selection

Together:

```bash
runi | fzf
```

→ becomes your personal command palette.

## Installation

Using uv:

```bash
uv tool install runi-cli
```

Or locally:

```bash
uv sync
```

## Usage

### Show all entries

```bash
runi harvest
```

### Search

```bash
runi search git
```

### Shortcut

```bash
runi git
```

## Recommended workflow

Use runi together with fzf.

Add this to your shell config:

```bash
rf() {
  local cmd
  cmd=$(runi "$@" | fzf --query "$*" --height 40% --border)

  if [[ -n "$cmd" ]]; then
    print -z "$cmd"
  fi
}
```

Now you can:

```bash
rf
rf git
rf ruff src
```

→ select with arrows

→ inserted into your prompt

→ edit if needed

→ press Enter to run

## Configuration

On first run, **runi** creates:

```text
~/.config/runi/config.toml
```

Example:

```toml
# Root directory to scan
root = "/Users/yourname/Data"

# File patterns (glob supported)
pattern = ["command.txt", "*.md"]
```

### Supported patterns

- exact filename:
  - "command.txt"

- glob:
  - "\*.txt"
  - "\*.md"

- multiple:
  - ["command.txt", "thought.txt"]

## Doctor

Show configuration and scan info:

```bash
runi doctor
```

## When to use runi

**runi** is useful if you:

- use the terminal frequently
- have commands you repeat but forget
- keep notes in plain text
- prefer simple tools over heavy systems

## Positioning

- ripgrep → search everything
- runi → search what matters

> runi is a curated command recall tool, not a general search engine.

## Philosophy

- plain text first
- minimal and composable
- works well with existing tools
- no heavy abstraction

## Summary

**runi** turns scattered text into a usable, fast command memory.

## Future ideas

- tagging
- ranking by usage
- deeper fzf integration

## License

MIT
