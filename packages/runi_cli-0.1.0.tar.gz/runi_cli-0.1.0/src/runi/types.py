# src/runi/types.py

from typing import List

Entry = str
Entries = List[str]
