# src/runi/cli_args.py

import argparse


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Harvest and search knowledge from plain text"
    )

    subparsers = parser.add_subparsers(dest="command")

    # harvest
    subparsers.add_parser("harvest", help="Collect all entries")

    # search
    search_parser = subparsers.add_parser("search", help="Search entries")
    search_parser.add_argument("keyword", help="Keyword to search")

    # doctor
    subparsers.add_parser("doctor", help="Show diagnostic information")

    return parser.parse_args(argv)
