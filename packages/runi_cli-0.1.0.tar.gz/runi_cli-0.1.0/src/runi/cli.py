# src/runi/cli.py

import sys
from pathlib import Path

from .cli_args import parse_args
from .config import get_config_file, get_patterns, load_config
from .core.files import scan_stats
from .core.harvest import harvest_entries
from .core.printer import print_entries
from .core.search import search_entries
from .core.transform import transform_entries
from .version import get_version


def format_size(bytes_size: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} TB"


def estimate_time(total_size_bytes: int) -> float:
    # assume ~100 MB/sec read speed (very rough)
    return total_size_bytes / (100 * 1024 * 1024)


def main() -> None:

    argv = sys.argv[1:]

    if "--version" in argv:
        print(f"runi {get_version()}")
        return

    KNOWN_COMMANDS = {"harvest", "search", "doctor"}

    # shortcut handling
    if argv and argv[0] not in KNOWN_COMMANDS and not argv[0].startswith("-"):
        argv = ["search", *argv]

    args = parse_args(argv)

    # doctor
    if args.command == "doctor":
        config_path = get_config_file()
        config = load_config()

        root = Path(config.get("root", "."))
        patterns = get_patterns(config)

        print(f"Config file: {config_path}")
        print(f"\nRoot: {root}")
        print(f"Pattern: {patterns}")

        # stats
        file_count, total_size = scan_stats(root, patterns)

        print(f"\nFiles matched: {file_count}")
        print(f"Total size: {format_size(total_size)}")

        est = estimate_time(total_size)
        print(f"Estimated read time: ~{est:.2f}s")

        print("\nNote: Large patterns (e.g. '*.txt') may impact performance.")

        if total_size > 200 * 1024 * 1024:
            print("\n⚠️ Large dataset detected. Consider narrowing your pattern.")

        return

    # load config
    config = load_config()
    root = Path(config.get("root", "."))

    config = load_config()
    root = Path(config.get("root", "."))
    patterns = get_patterns(config)

    # pipeline
    entries = harvest_entries(root, patterns)
    entries = transform_entries(entries)

    if args.command == "search":
        entries = search_entries(entries, args.keyword)

    print_entries(entries)
