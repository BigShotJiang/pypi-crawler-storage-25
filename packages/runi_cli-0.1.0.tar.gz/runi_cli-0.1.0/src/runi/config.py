# src/runi/config.py

import shutil
from importlib import resources
from pathlib import Path

import tomllib
from platformdirs import user_config_dir

APP_NAME = "runi"


def get_config_dir() -> Path:
    return Path(user_config_dir(APP_NAME))


def get_config_file() -> Path:
    return get_config_dir() / "config.toml"


def ensure_config() -> Path:
    config_dir = get_config_dir()
    config_file = get_config_file()

    if not config_file.exists():
        config_dir.mkdir(parents=True, exist_ok=True)

        default = resources.files("runi").joinpath("config_default.toml")
        shutil.copy(default, config_file)

        print(f"""
runi config created.

Please edit:

{config_file}
""")

    return config_file


def load_config() -> dict:
    config_file = ensure_config()

    with open(config_file, "rb") as f:
        return tomllib.load(f)


def get_patterns(config: dict) -> list[str]:
    pattern = config.get("pattern", "command.txt")

    if isinstance(pattern, str):
        return [pattern]

    if isinstance(pattern, list):
        return pattern

    raise ValueError("pattern must be string or list of strings")
