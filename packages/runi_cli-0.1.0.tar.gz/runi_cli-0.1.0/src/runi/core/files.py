# src/runi/core/files.py

from pathlib import Path
from typing import List


def find_files(root: Path, pattern: str) -> List[Path]:
    """Recursively find files matching pattern."""
    return list(root.rglob(pattern))


def read_lines(files: List[Path]) -> List[str]:
    """Read non-empty lines from files."""
    entries: List[str] = []

    for file in files:
        try:
            with file.open("r", encoding="utf-8") as f:
                for line in f:
                    clean = line.strip()
                    if clean:
                        entries.append(clean)
        except Exception as e:
            print(f"⚠️ Failed to read {file}: {e}")

    return entries


def scan_stats(root, patterns):
    files = []

    for pattern in patterns:
        files.extend(root.rglob(pattern))

    # optional: deduplicate
    files = list(set(files))

    total_size = 0

    for f in files:
        try:
            total_size += f.stat().st_size
        except Exception:
            pass

    return len(files), total_size
