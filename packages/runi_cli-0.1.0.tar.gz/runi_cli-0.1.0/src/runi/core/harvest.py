# src/runi/core/harvest.py

from pathlib import Path
from typing import List

from .files import find_files, read_lines


def harvest_entries(root: Path, patterns: List[str]) -> List[str]:
    all_files = []

    for pattern in patterns:
        files = find_files(root, pattern)
        all_files.extend(files)

    return read_lines(all_files)
