# src/runi/core/search.py

from typing import List, Tuple


def extract_tags(entry: str) -> Tuple[List[str], str]:
    tags = []
    remaining = entry.strip()

    while remaining.startswith("["):
        end = remaining.find("]")
        if end == -1:
            break
        tag = remaining[1:end]
        tags.append(tag)
        remaining = remaining[end + 1 :].strip()

    return tags, remaining


def search_entries(entries, keyword):
    if not keyword:
        return entries

    terms = keyword.lower().split()
    scored = []

    for e in entries:
        tags, text = extract_tags(e)
        combined = (text + " " + " ".join(tags)).lower()

        if all(term in combined for term in terms):
            score = 0

            for term in terms:
                if term in text.lower():
                    score += 10

                if text.lower().startswith(term):
                    score += 20

                if term in [t.lower() for t in tags]:
                    score += 15

            scored.append((score, e))

    # sort by score DESC
    scored.sort(key=lambda x: x[0], reverse=True)

    return [e for _, e in scored]
