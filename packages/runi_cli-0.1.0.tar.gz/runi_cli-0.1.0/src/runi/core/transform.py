# src/runi/core/transform.py

from typing import List


def transform_entries(entries: List[str]) -> List[str]:
    """Deduplicate and sort (case-insensitive)."""
    return sorted(set(entries), key=str.lower)
