# src/runi/core/printer.py

from typing import List


def strip_tags(entry: str) -> str:
    remaining = entry.strip()

    while remaining.startswith("["):
        end = remaining.find("]")
        if end == -1:
            break
        remaining = remaining[end + 1 :].strip()

    return remaining


def print_entries(entries: List[str]) -> None:
    for e in entries:
        print(strip_tags(e))
