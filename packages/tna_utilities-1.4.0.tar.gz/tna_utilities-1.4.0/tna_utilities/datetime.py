import datetime
import math
from typing import Optional, Union

"""
See https://design-system.nationalarchives.gov.uk/content/dates-and-times/
for more details on how dates and times should be presented within services
from The National Archives.
"""


def get_date_from_string(date_string: str) -> datetime.datetime:  # noqa: C901
    """
    Parses a date string into a datetime object.
    """

    if not date_string:
        raise ValueError("Empty string cannot be parsed as date")

    normalised_date_string = date_string.replace("Z", "+00:00")

    try:
        return datetime.datetime.fromisoformat(normalised_date_string)
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(
            normalised_date_string, "%Y-%m-%dT%H:%M:%S.%f+00:00"
        )
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(
            normalised_date_string, "%Y-%m-%dT%H:%M:%S+00:00"
        )
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(normalised_date_string, "%Y-%m-%dT%H:%M:%S%z")
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(normalised_date_string, "%Y-%m-%d")
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(normalised_date_string, "%Y-%m")
    except ValueError:
        pass

    try:
        return datetime.datetime.strptime(normalised_date_string, "%Y")
    except ValueError:
        pass

    raise ValueError(f"Unable to parse date from string: {date_string}")


def _format_day(date: datetime.date) -> str:
    return str(date.day)


def _format_month_index(date: datetime.date) -> int:
    return date.month


def pretty_date(
    date: Union[str, datetime.date],
    show_day: bool = False,
) -> str:
    """
    Formats a date into the format used by The National Archives.

    date: A date or datetime object or the date string in either YYYY-MM-DD, YYYY-MM, or YYYY format.

    If show_day is True, includes the day of the week.
    """

    if not date:
        raise ValueError("No date provided")

    if isinstance(date, datetime.date):
        if show_day:
            return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y')}"
        return f"{_format_day(date)} {date.strftime('%B %Y')}"

    try:
        date = datetime.datetime.strptime(date, "%Y-%m-%d")
        if show_day:
            return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y')}"
        return f"{_format_day(date)} {date.strftime('%B %Y')}"
    except ValueError:
        pass

    try:
        date = datetime.datetime.strptime(date, "%Y-%m")
        return date.strftime("%B %Y")
    except ValueError:
        pass

    try:
        date = datetime.datetime.strptime(date, "%Y")
        return date.strftime("%Y")
    except ValueError:
        pass

    date = get_date_from_string(date)
    if show_day:
        return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y')}"
    return f"{_format_day(date)} {date.strftime('%B %Y')}"


def pretty_datetime(
    date: Union[str, datetime.datetime],
    show_day: bool = False,
    show_seconds: bool = False,
) -> str:
    """
    Formats a date and time into the format used by The National Archives.
    """

    if not date:
        raise ValueError("No date provided")

    if isinstance(date, datetime.datetime):
        if show_day:
            if show_seconds:
                return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y, %H:%M:%S')}"
            return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y, %H:%M')}"
        if show_seconds:
            return f"{_format_day(date)} {date.strftime('%B %Y, %H:%M:%S')}"
        return f"{_format_day(date)} {date.strftime('%B %Y, %H:%M')}"

    if isinstance(date, datetime.date):
        raise TypeError("Date object provided, datetime object expected")

    date = get_date_from_string(date)
    if show_day:
        if show_seconds:
            return f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y, %H:%M:%S')}"
        return (
            f"{date.strftime('%A')} {_format_day(date)} {date.strftime('%B %Y, %H:%M')}"
        )
    if show_seconds:
        return f"{_format_day(date)} {date.strftime('%B %Y, %H:%M:%S')}"
    return f"{_format_day(date)} {date.strftime('%B %Y, %H:%M')}"


def pretty_date_range(  # noqa: C901
    date_from: Optional[Union[str, datetime.date]],
    date_to: Optional[Union[str, datetime.date]],
    omit_days: bool = False,
    lowercase_first: bool = False,
) -> str:
    """
    Formats a date range into the format used by The National Archives.
    """

    if isinstance(date_from, datetime.date):
        pass
    elif isinstance(date_from, str):
        try:
            date_from = get_date_from_string(date_from)
        except ValueError:
            date_from = None

    if isinstance(date_to, datetime.date):
        pass
    elif isinstance(date_to, str):
        try:
            date_to = get_date_from_string(date_to)
        except ValueError:
            date_to = None

    if not date_from and not date_to:
        raise ValueError("No dates provided")

    if date_from and date_to:
        if date_from > date_to:
            raise ValueError("From date is after to date")

        date_to_string = (
            date_to.strftime("%B %Y")
            if omit_days
            else f"{_format_day(date_to)} {date_to.strftime('%B %Y')}"
        )
        if (
            date_from.day == 1
            and date_from.month == 1
            and date_to.day == 31
            and date_to.month == 12
        ):
            if date_from.year == date_to.year:
                return str(date_from.year)

            return f"{date_from.year} to {date_to.year}"

        if date_from.year == date_to.year:
            if date_from.month == date_to.month:
                if date_from.day == date_to.day:
                    return (
                        date_from.strftime("%B %Y")
                        if omit_days
                        else f"{_format_day(date_from)} {date_from.strftime('%B %Y')}"
                    )

                if omit_days:
                    return date_to_string
                return f"{_format_day(date_from)} to {date_to_string}"

            if omit_days:
                return f"{date_from.strftime('%B')} to {date_to_string}"
            return f"{_format_day(date_from)} {date_from.strftime('%B')} to {date_to_string}"

        if omit_days:
            return f"{date_from.strftime('%B %Y')} to {date_to_string}"
        return f"{_format_day(date_from)} {date_from.strftime('%B %Y')} to {date_to_string}"

    if date_from:
        start = "from" if lowercase_first else "From"
        if omit_days:
            return f"{start} {date_from.strftime('%B %Y')}"
        return f"{start} {_format_day(date_from)} {date_from.strftime('%B %Y')}"

    if date_to:
        start = "now to" if lowercase_first else "Now to"
        if omit_days:
            return f"{start} {date_to.strftime('%B %Y')}"
        return f"{start} {_format_day(date_to)} {date_to.strftime('%B %Y')}"

    return ""


def pretty_datetime_range(  # noqa: C901
    date_from: Optional[Union[str, datetime.date, datetime.datetime]],
    date_to: Optional[Union[str, datetime.date, datetime.datetime]],
    lowercase_first: bool = False,
    hide_date_if_single_day: bool = False,
    show_seconds: bool = False,
) -> str:
    """
    Formats a date/time range into the format used by The National Archives.
    """

    if isinstance(date_from, datetime.datetime):
        pass
    elif isinstance(date_from, datetime.date):
        raise TypeError("From date object provided, datetime object expected")
    elif isinstance(date_from, str):
        try:
            date_from = get_date_from_string(date_from)
        except ValueError:
            date_from = None

    if isinstance(date_to, datetime.datetime):
        pass
    elif isinstance(date_to, datetime.date):
        raise TypeError("To date object provided, datetime object expected")
    elif isinstance(date_to, str):
        try:
            date_to = get_date_from_string(date_to)
        except ValueError:
            date_to = None

    if not date_from and not date_to:
        raise ValueError("No dates provided")

    if date_from and date_to:
        if date_from > date_to:
            raise ValueError("From date is after to date")

        if (
            date_from.year == date_to.year
            and date_from.month == date_to.month
            and date_from.day == date_to.day
        ):
            if date_from.hour != date_to.hour or date_from.minute != date_to.minute:
                if hide_date_if_single_day:
                    if show_seconds:
                        return f"{date_from.strftime('%H:%M:%S')} to {date_to.strftime('%H:%M:%S')}"
                    return (
                        f"{date_from.strftime('%H:%M')} to {date_to.strftime('%H:%M')}"
                    )

                if show_seconds:
                    return (
                        f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M:%S')}"
                        f" to {date_to.strftime('%H:%M:%S')}"
                    )
                return (
                    f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M')}"
                    f" to {date_to.strftime('%H:%M')}"
                )

            if hide_date_if_single_day:
                if show_seconds:
                    return f"{date_from.strftime('%H:%M:%S')}"
                return f"{date_from.strftime('%H:%M')}"

            if show_seconds:
                return (
                    f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M:%S')}"
                )
            return f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M')}"

        if show_seconds:
            return (
                f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M:%S')}"
                f" to {_format_day(date_to)} {date_to.strftime('%B %Y, %H:%M:%S')}"
            )
        return (
            f"{_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M')}"
            f" to {_format_day(date_to)} {date_to.strftime('%B %Y, %H:%M')}"
        )

    if date_from:
        start = "from" if lowercase_first else "From"
        if show_seconds:
            return f"{start} {_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M:%S')}"
        return f"{start} {_format_day(date_from)} {date_from.strftime('%B %Y, %H:%M')}"

    if date_to:
        start = "now to" if lowercase_first else "Now to"
        if show_seconds:
            return (
                f"{start} {_format_day(date_to)} {date_to.strftime('%B %Y, %H:%M:%S')}"
            )
        return f"{start} {_format_day(date_to)} {date_to.strftime('%B %Y, %H:%M')}"

    return ""


def pretty_age(
    date: datetime.datetime, just_now_seconds: int = 5, lowercase_first: bool = False
) -> str:
    if not date:
        raise ValueError("Date must be provided")

    now = datetime.datetime.now().replace(microsecond=0)

    if isinstance(date, datetime.datetime):
        if date.tzinfo is not None:
            now = datetime.datetime.now(tz=date.tzinfo).replace(microsecond=0)
        date = date.replace(microsecond=0)
    else:
        date = datetime.datetime.combine(date, datetime.time.min)

    future = now < date
    delta = date - now if future else now - date
    days = delta.days
    seconds = delta.seconds

    if future:
        prefix = "in " if lowercase_first else "In "
        suffix = ""
    else:
        prefix = ""
        suffix = " ago"

    if days > 365:
        years = days // 365
        return f"{prefix}{years} year{'s' if years != 1 else ''}{suffix}"
    elif days > 30:
        months = days // 30
        return f"{prefix}{months} month{'s' if months != 1 else ''}{suffix}"
    elif days > 0:
        return f"{prefix}{days} day{'s' if days != 1 else ''}{suffix}"
    elif seconds >= 3600:
        hours = seconds // 3600
        return f"{prefix}{hours} hour{'s' if hours != 1 else ''}{suffix}"
    elif seconds >= 60:
        minutes = seconds // 60
        return f"{prefix}{minutes} minute{'s' if minutes != 1 else ''}{suffix}"
    elif seconds > just_now_seconds or future:
        return f"{prefix}{seconds} second{'s' if seconds != 1 else ''}{suffix}"
    else:
        return "just now" if lowercase_first else "Just now"


def is_today_or_future(date: Union[datetime.date, datetime.datetime]) -> bool:
    """
    Determines if the given date string represents today or a future date.
    """

    if not date:
        raise ValueError("No date provided")

    if isinstance(date, datetime.datetime):
        date = date.date()

    today = datetime.datetime.now().date()
    return today <= date


def is_today_in_date_range(
    date_from: Union[datetime.date, datetime.datetime],
    date_to: Union[datetime.date, datetime.datetime],
) -> bool:
    """
    Determines if today's date falls within the given date range.
    """

    if not date_from or not date_to:
        raise ValueError("Both from and to dates must be provided")

    if isinstance(date_from, datetime.datetime):
        date_from = date_from.date()

    if isinstance(date_to, datetime.datetime):
        date_to = date_to.date()

    today = datetime.datetime.now().date()
    return date_from <= today <= date_to


def group_by_year_and_month(
    items: list[dict], date_key: str, reverse: bool = False
) -> list[dict]:  # noqa: C901
    """
    Groups a list of items by year and month based on a date key in each item.
    """

    grouped = []

    for item in items:
        if item_date := item.get(date_key):
            if isinstance(item_date, (datetime.datetime, datetime.date)):
                item_datetime = item_date
            else:
                try:
                    item_datetime = get_date_from_string(item_date)
                except ValueError:
                    continue

            if item_datetime:
                month = item_datetime.strftime("%B")
                month_index = _format_month_index(item_datetime)
                year = item_datetime.strftime("%Y")
                year_index = int(year)
                existing_year_index = next(
                    (i for i, d in enumerate(grouped) if d["index"] == year_index), None
                )
                if existing_year_index is None:
                    grouped.append(
                        {
                            "heading": year,
                            "index": year_index,
                            "items": [
                                {
                                    "heading": month,
                                    "index": month_index,
                                    "items": [item],
                                }
                            ],
                        }
                    )
                else:
                    existing_month_index = next(
                        (
                            i
                            for i, m in enumerate(grouped[existing_year_index]["items"])
                            if m["index"] == month_index
                        ),
                        None,
                    )
                    if existing_month_index is None:
                        grouped[existing_year_index]["items"].append(
                            {
                                "heading": month,
                                "index": month_index,
                                "items": [item],
                            }
                        )
                    else:
                        grouped[existing_year_index]["items"][existing_month_index][
                            "items"
                        ].append(item)

    for year_group in grouped:
        year_group["items"].sort(key=lambda x: x["index"], reverse=reverse)
        for month_group in year_group["items"]:
            month_group["items"].sort(
                key=lambda x: (
                    (
                        x.get(date_key)
                        if isinstance(
                            x.get(date_key), (datetime.date, datetime.datetime)
                        )
                        else (
                            get_date_from_string(x.get(date_key))
                            if x.get(date_key) is not None
                            else (
                                datetime.datetime.max
                                if reverse
                                else datetime.datetime.min
                            )
                        )
                    )
                    if isinstance(x.get(date_key), (datetime.date, datetime.datetime))
                    else (
                        (
                            get_date_from_string(x.get(date_key))
                            if x.get(date_key) is not None
                            else (
                                datetime.datetime.max
                                if reverse
                                else datetime.datetime.min
                            )
                        )
                        if isinstance(x.get(date_key), str)
                        else (
                            datetime.datetime.max if reverse else datetime.datetime.min
                        )
                    )
                ),
                reverse=reverse,
            )
    grouped.sort(key=lambda x: x["index"], reverse=reverse)

    return grouped


def seconds_to_iso_8601_duration(total_seconds: int) -> str:
    """
    Converts a total number of seconds into an ISO 8601 duration string.
    """

    if not total_seconds:
        return "PT0S"

    if total_seconds < 0:
        raise ValueError("Total seconds cannot be negative")

    hours = math.floor(total_seconds / 3600)
    minutes = math.floor((total_seconds - (hours * 3600)) / 60)
    seconds = total_seconds - (hours * 3600) - (minutes * 60)
    if hours:
        return f"PT{hours}H{minutes}M{seconds}S"

    if minutes:
        return f"PT{minutes}M{seconds}S"

    return f"PT{seconds}S"


def seconds_to_duration(total_seconds: int, simplify: bool = False) -> str:
    """
    Converts a total number of seconds into a human-readable duration string.
    """

    if not total_seconds:
        return "00s" if simplify else "00h 00m 00s"

    if total_seconds < 0:
        raise ValueError("Total seconds cannot be negative")

    hours = math.floor(total_seconds / 3600)
    minutes = math.floor((total_seconds - (hours * 3600)) / 60)
    seconds = total_seconds - (hours * 3600) - (minutes * 60)

    hours_string = f"{str(hours).rjust(2, '0')}h"
    minutes_string = f"{str(minutes).rjust(2, '0')}m"
    seconds_string = f"{str(seconds).rjust(2, '0')}s"

    return_values = []
    if simplify:
        if hours:
            return_values.append(hours_string)
            return_values.append(minutes_string)
        elif minutes:
            return_values.append(minutes_string)
    else:
        return_values.append(hours_string)
        return_values.append(minutes_string)
    return_values.append(seconds_string)

    return " ".join(return_values)


def rfc_822_date_format(date: Union[datetime.date, datetime.datetime]) -> str:
    """
    Formats a date into RFC 822 format.
    """

    if not date:
        raise ValueError("No date provided")

    return f"{date.strftime('%a')}, {_format_day(date)} {date.strftime('%b %Y %H:%M:%S GMT')}"
