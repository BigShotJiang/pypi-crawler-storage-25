"""Module registry: ``@register(category, name)`` / ``get(category, name)``."""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeAlias, TypeVar

import torch.nn as nn

ModuleType = TypeVar("ModuleType", bound=nn.Module)
Registry: TypeAlias = dict[str, dict[str, type[nn.Module]]]

_REGISTRIES: Registry = {}


def _category_registry(category: str) -> dict[str, type[nn.Module]]:
    registry = _REGISTRIES.get(category)
    if registry is None:
        registry = {}
        _REGISTRIES[category] = registry
    return registry


def register(category: str, name: str) -> Callable[[type[ModuleType]], type[ModuleType]]:
    """Class decorator that registers *cls* under *category*/*name*."""
    def decorator(cls: type[ModuleType]) -> type[ModuleType]:
        registry = _category_registry(category)
        if name in registry:
            raise ValueError(f"'{name}' already registered in '{category}'")
        registry[name] = cls
        return cls
    return decorator


def get(category: str, name: str) -> type[nn.Module]:
    if category not in _REGISTRIES:
        raise KeyError(f"Category '{category}' not found. Available: {list(_REGISTRIES)}")
    registry = _REGISTRIES[category]
    if name not in registry:
        raise KeyError(f"Module '{name}' not found in '{category}'. Available: {list(registry)}")
    return registry[name]


def list_modules(category: str | None = None) -> dict[str, list[str]]:
    if category is not None:
        return {category: list(_REGISTRIES.get(category, {}))}
    return {cat: list(modules) for cat, modules in _REGISTRIES.items()}
