"""Adapter modules for multilingual training."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .registry import register


@register("adapter", "language_conditioned")
class LanguageConditionedAdapter(nn.Module):
    """Bottleneck with language-gated scaling. Initialized as identity (scale=0)."""

    def __init__(self, d_model: int, bottleneck: int = 128) -> None:
        super().__init__()
        self.down = nn.Linear(d_model, bottleneck, bias=False)
        self.up = nn.Linear(bottleneck, d_model, bias=False)
        self.gate = nn.Linear(d_model, bottleneck)
        self.scale = nn.Parameter(torch.zeros(1))

    def forward(self, x: torch.Tensor, lang_embed: torch.Tensor) -> torch.Tensor:
        hidden = F.silu(self.down(x))
        gate_signal = torch.sigmoid(self.gate(lang_embed)).unsqueeze(1)
        hidden = hidden * gate_signal
        return x + self.up(hidden) * self.scale


@register("adapter", "bottleneck")
class BottleneckAdapter(nn.Module):
    """Plain bottleneck adapter without language gating."""

    def __init__(self, d_model: int, bottleneck: int = 128) -> None:
        super().__init__()
        self.down = nn.Linear(d_model, bottleneck, bias=False)
        self.up = nn.Linear(bottleneck, d_model, bias=False)
        self.scale = nn.Parameter(torch.zeros(1))

    def forward(self, x: torch.Tensor, lang_embed: torch.Tensor | None = None) -> torch.Tensor:
        hidden = F.silu(self.down(x))
        return x + self.up(hidden) * self.scale


@register("adapter", "none")
class NoAdapter(nn.Module):
    def __init__(self, d_model: int, bottleneck: int = 128) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor, lang_embed: torch.Tensor | None = None) -> torch.Tensor:
        return x
