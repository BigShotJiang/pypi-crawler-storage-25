"""Rotary Position Embeddings — RoPE (Su et al., 2021)."""

from __future__ import annotations

from typing import cast

import torch
import torch.nn as nn

from .registry import register

ROPE_THETA = 10000.0


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_emb(
    x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor,
) -> torch.Tensor:
    """Apply RoPE to tensor of shape ``(batch, heads, seq_len, head_dim)``."""
    cos = torch.cat([cos, cos], dim=-1).unsqueeze(0).unsqueeze(0)
    sin = torch.cat([sin, sin], dim=-1).unsqueeze(0).unsqueeze(0)
    return x * cos + rotate_half(x) * sin


@register("position", "rope")
class RotaryEmbedding(nn.Module):
    def __init__(self, head_dim: int, max_positions: int = 512) -> None:
        super().__init__()
        del max_positions
        steps = torch.arange(head_dim // 2, dtype=torch.float32) * 2.0
        inv_freq = 1.0 / (ROPE_THETA ** (steps / head_dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, seq_len: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        inv_freq = cast(torch.Tensor, self.inv_freq)
        positions = torch.arange(seq_len, device=device).to(inv_freq.dtype)
        freqs = torch.outer(positions, inv_freq)
        return freqs.cos(), freqs.sin()
