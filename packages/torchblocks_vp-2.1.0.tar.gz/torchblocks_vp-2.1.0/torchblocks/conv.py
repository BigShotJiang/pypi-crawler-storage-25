"""Conformer-style depthwise conv1d for local n-gram features."""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .registry import register


@register("conv", "local")
class LocalConvModule(nn.Module):
    """Depthwise separable conv1d placed between self-attention and FFN in the encoder."""

    def __init__(
        self,
        d_model: int,
        kernel_size: int = 7,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.depthwise_conv = nn.Conv1d(
            d_model, d_model, kernel_size,
            padding=kernel_size // 2,
            groups=d_model,
            bias=False,
        )
        self.pointwise = nn.Linear(d_model, d_model, bias=False)
        self.norm = nn.BatchNorm1d(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        hidden = self.depthwise_conv(x.transpose(1, 2))
        hidden = self.norm(hidden)
        hidden = F.silu(hidden)
        hidden = hidden.transpose(1, 2)
        return self.dropout(self.pointwise(hidden))


@register("conv", "none")
class NoConv(nn.Module):
    def __init__(self, d_model: int, kernel_size: int = 7, dropout: float = 0.1) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.zeros_like(x)
