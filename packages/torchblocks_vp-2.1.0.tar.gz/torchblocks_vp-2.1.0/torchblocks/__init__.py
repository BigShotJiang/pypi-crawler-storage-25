"""Reusable Transformer building blocks with plugin registry."""

from types import ModuleType

from . import adapter as _adapter
from . import attention as _attention
from . import conv as _conv
from . import feedforward as _feedforward
from . import norm as _norm
from . import position as _position

from .registry import get, list_modules, register

_REGISTERED_MODULES: tuple[ModuleType, ...] = (
    _adapter,
    _attention,
    _conv,
    _feedforward,
    _norm,
    _position,
)

__all__: list[str] = [
    "get",
    "list_modules",
    "register",
]

__version__: str = "2.1.0"
