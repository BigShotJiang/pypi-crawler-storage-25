

class DeerError(Exception):
    pass
