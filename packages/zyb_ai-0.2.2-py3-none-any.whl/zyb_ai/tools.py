import re
import io
import platform
import numpy as np
from PIL import Image, ImageFont, ImageSequence


def check_image(img, is_crop=False):
    buffer = io.BytesIO()
    try:
        with Image.open(img) as im:
            if im.format.lower() not in ['jpg', 'jpeg', 'png']:
                raise ValueError("图片格式错误，请修改后重试~")
            if is_crop:
                im = im.convert('RGB')
                w, h = im.size
                if max(w, h) > 2000:
                    if w > h:
                        ratio = 2000 / w
                    else:
                        ratio = 2000 / h
                    im = im.resize((int(w * ratio), int(h * ratio)), Image.Resampling.LANCZOS)
                im.save(buffer, 'JPEG', optimize=True, quality=85)
            else:
                im.save(buffer, format='PNG')
    except Exception as e:
        raise ValueError("图片格式错误，请修改后重试~", str(e))
    return buffer.getvalue()


check_filename_re = re.compile(r'^[\u4e00-\u9fa5A-Za-z0-9_\-\(\)]+$')


def check_filename(name):
    if not isinstance(name, str) or not name.strip():
        return False
    if not check_filename_re.fullmatch(name):
        return False
    return True


def square_crop(img):
    """矩形裁剪"""
    if isinstance(img, str):
        new_img = Image.open(img).convert('RGBA')
    else:
        new_img = img.convert('RGBA')
    w, h = new_img.size
    side = min(w, h)
    if w != h:
        left = (w - side) // 2
        top = 0
        right = left + side
        bottom = top + side
        new_img = new_img.crop((left, top, right, bottom))
    return new_img


def circle_crop(img, gradient=10, method='multiply'):
    """圆形裁剪"""
    new_img = square_crop(img)
    diameter = new_img.width
    radius = diameter // 2

    # 转换为numpy数组
    img_array = np.array(new_img, dtype=np.float32) / 255.0

    # 创建坐标网格
    y, x = np.ogrid[:diameter, :diameter]
    center = diameter // 2
    distance = np.sqrt((x - center) ** 2 + (y - center) ** 2)

    # 创建圆形渐变蒙版
    circle_mask = np.zeros((diameter, diameter), dtype=np.float32)

    # 内部完全显示的区域
    inner_radius = radius - gradient
    inner_mask = distance <= inner_radius
    circle_mask[inner_mask] = 1.0

    # 边缘渐变区域
    edge_mask = (distance > inner_radius) & (distance <= radius)
    edge_dist = distance[edge_mask]

    # 计算渐变值
    edge_alpha = 1.0 - (edge_dist - inner_radius) / gradient
    circle_mask[edge_mask] = edge_alpha

    # 获取原图的alpha通道
    original_alpha = img_array[:, :, 3]
    # 根据选择的方法计算新alpha
    if method == 'multiply':
        # 乘法混合：新alpha = 原alpha × 圆形蒙版
        new_alpha = original_alpha * circle_mask

    elif method == 'min':
        # 取最小值：新alpha = min(原alpha, 圆形蒙版)
        new_alpha = np.minimum(original_alpha, circle_mask)

    elif method == 'smart':
        # 智能混合：考虑原alpha的强度调整混合
        # 对高透明度区域更敏感
        alpha_strength = np.clip(original_alpha * 1.2, 0, 1)  # 稍微增强原alpha的影响
        new_alpha = original_alpha * (alpha_strength + circle_mask * (1 - alpha_strength))

    else:
        new_alpha = original_alpha * circle_mask

    # 应用新alpha通道
    img_array[:, :, 3] = new_alpha

    # 转换回PIL Image
    img_array = (img_array * 255).astype(np.uint8)
    return Image.fromarray(img_array, 'RGBA')


def more_frames_crop(img, ext=None, shape="circle"):
    if shape not in ['circle', 'rect']:
        raise ValueError("形状参数值错误")
    if isinstance(img, str):
        im = Image.open(img)
        ext = im.format.lower()
    else:
        im = img
    frames = []
    if ext == "gif":
        if shape == "circle":
            func = circle_crop
        else:
            func = square_crop
        for frame in ImageSequence.Iterator(im):
            frames.append(func(frame))
    elif ext == "webp":
        if shape == "circle":
            func = circle_crop
        else:
            func = square_crop
        frame = im.copy()
        framed = func(frame)
        frames.append(framed.convert('P'))
        if im.is_animated:
            for i in range(1, im.n_frames):
                im.seek(i)
                frame = im.copy()
                frames.append(func(frame))
    return frames


def get_platform_font(size=30):
    try:
        system = platform.system()
        if system == "Windows":
            font = ImageFont.truetype("simhei.ttf", size)
        elif system == "Darwin":  # macOS
            font = ImageFont.truetype("/System/Library/Fonts/PingFang.ttc", size)
        else:  # Linux
            font = ImageFont.truetype("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc", size)
    except Exception as e:
        font = ImageFont.load_default()
    return font

