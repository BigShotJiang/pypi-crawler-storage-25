import os
import math
import time
import numpy as np
from PIL import Image, ImageOps, ImageEnhance, ImageFilter, ImageDraw, ImageSequence, ImageColor
from .tools import check_image, circle_crop, square_crop, get_platform_font, more_frames_crop


def img_fisheye(img, dst='./', strength=1.5):
    """鱼眼风格"""
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    if not isinstance(strength, (int, float)):
        raise TypeError("鱼眼效果参数类型错误")
    if strength < 0:
        strength = 0
    if strength > 10:
        strength = 10

    image = Image.open(img)
    width, height = image.size
    center_x = width / 2
    center_y = height / 2
    np_image = np.array(image)
    output_image = np.zeros_like(np_image)

    for y in range(height):
        for x in range(width):
            dx = x - center_x
            dy = y - center_y
            distance = math.sqrt(dx ** 2 + dy ** 2)
            radius = distance / min(center_x, center_y)
            new_x, new_y = center_x, center_y
            if radius > 0:
                theta = math.atan2(dy, dx)
                r_new = radius ** strength
                new_x = center_x + r_new * math.cos(theta) * center_x
                new_y = center_y + r_new * math.sin(theta) * center_y

            if 0 <= new_x < width and 0 <= new_y < height:
                output_image[int(y), int(x)] = np_image[int(new_y), int(new_x)]
    output_pil_image = Image.fromarray(output_image)
    name = 'fisheye_' + str(int(time.time() * 1000)) + '.png'
    output_pil_image.save(os.path.join(dst, name))
    return name


def img_popart(img, dst='./'):
    """波普艺术风格"""
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    image = Image.open(img)
    base_colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
    pop_art_images = []

    for base_color in base_colors:
        color_image = ImageOps.colorize(image.convert("L"), black="black", white=base_color)
        pop_art_images.append(color_image)

    final_image = Image.new('RGB', (image.width * 2, image.height * 2))
    final_image.paste(pop_art_images[0], (0, 0))
    final_image.paste(pop_art_images[1], (image.width, 0))
    final_image.paste(pop_art_images[2], (0, image.height))
    final_image.paste(pop_art_images[3], (image.width, image.height))
    name = 'popart_' + str(int(time.time() * 1000)) + '.png'
    final_image.save(os.path.join(dst, name))
    return name


class ZybImageStyle:

    @staticmethod
    def add_noise(im, noise_level=5):
        """
        为图像添加噪声
        """
        np_image = np.array(im)
        noise = np.random.randint(-noise_level, noise_level, np_image.shape, dtype='int16')
        noisy_image = np.clip(np_image + noise, 0, 255).astype('uint8')
        return Image.fromarray(noisy_image)

    @staticmethod
    def add_vignette(im, vignette_scale=0.75):
        """
        为图像添加渐晕效果
        """
        width, height = im.size
        max_distance = np.sqrt((width / 2) ** 2 + (height / 2) ** 2)
        vignette = Image.new('L', (width, height))

        for y in range(height):
            for x in range(width):
                distance_to_center = np.sqrt((x - width / 2) ** 2 + (y - height / 2) ** 2)
                intensity = int((1 - (distance_to_center / max_distance) ** vignette_scale) * 255)
                vignette.putpixel((x, y), intensity)

        return Image.composite(im, ImageOps.colorize(vignette, 'black', 'white'), vignette)

    @staticmethod
    def add_sepia(im):
        """增加褐色"""
        width, height = im.size
        sepia_image = Image.new('RGB', (width, height))

        for y in range(height):
            for x in range(width):
                r, g, b = im.getpixel((x, y))
                tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                sepia_image.putpixel((x, y), (min(tr, 255), min(tg, 255), min(tb, 255)))
        return sepia_image

    def old_photo_effect(self, image, dst):
        """复古风格"""
        # 1. 转换为灰度图并添加棕褐色调
        gray_image = image.convert('L')
        sepia_image = self.add_sepia(gray_image.convert('RGB'))

        # 2. 添加噪声
        noisy_image = self.add_noise(sepia_image, noise_level=20)

        # 3. 添加渐晕效果
        vignette_image = self.add_vignette(noisy_image)

        # 4. 高斯模糊
        blurred_image = vignette_image.filter(ImageFilter.GaussianBlur(radius=1))

        blurred_image.save(dst)

    def film_filter(self, image, dst):
        """胶片风格"""
        # 1. 调整颜色平衡（添加轻微的黄色和青色色调）
        r, g, b = image.split()
        r = r.point(lambda i: min(255, i * 1.2))
        g = g.point(lambda i: min(255, i * 1.1))
        b = b.point(lambda i: min(255, i * 0.9))
        image = Image.merge('RGB', (r, g, b))

        # 2. 增强对比度和亮度
        image = ImageEnhance.Contrast(image).enhance(1.3)
        image = ImageEnhance.Brightness(image).enhance(1.1)

        # 3. 添加噪声
        noisy_image = self.add_noise(image, noise_level=10)

        # 4. 添加渐晕效果
        final_image = self.add_vignette(noisy_image, vignette_scale=2.0)

        # 保存最终结果
        final_image.save(dst)


def img_transfer(img, style, dst='./'):
    if not isinstance(style, int) or not 0 < style < 3:
        raise ValueError("style非指定范围内的风格")
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    check_image(img)
    if not os.path.exists(img):
        raise ValueError("输入的图片不存在")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    im = Image.open(img).convert('RGB')
    image_style = ZybImageStyle()
    image_name = os.path.split(img)[-1].split('.')[0] + '_transfer_' + str(int(time.time() * 1000)) + '.png'
    dst = os.path.join(dst, image_name)
    if style == 1:
        image_style.old_photo_effect(im, dst)
    elif style == 2:
        image_style.film_filter(im, dst)
    return image_name


def create_badge(img, style=2, dst='./'):
    if not isinstance(style, int) or not 0 < style < 9:
        raise ValueError("style非指定范围内的徽章类型")
    if not isinstance(img, str):
        raise TypeError("图片名称类型错误")
    try:
        im = Image.open(img)
        speed = im.info.get("duration", 100)
    except Exception as e:
        raise ValueError("不支持输入的图片格式")
    ext = im.format.lower()
    if ext not in ['png', 'jpg', 'jpeg', 'gif', 'webp']:
        raise ValueError("输入的图片格式不支持")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    # 图片百分比
    ratio = 0.9
    if style in [1, 7]:
        ratio = 0.96

    bg_pic = {
        1: 'type-1-b.png',
        2: 'type-2-b.png',
        3: 'type-2-b.png',
        4: 'type-4-b.png',
        5: 'type-5-b.png',
        6: 'type-1-b.png',
        7: 'type-4-b.png',
        8: 'type-8-b.png'
    }

    frames = []
    # 图片裁剪
    if style == 8:
        if ext in ["gif", "webp"]:
            frames.extend(more_frames_crop(im, ext=ext, shape='rect'))
        else:
            frames.append(square_crop(im))
    else:
        if ext in ["gif", "webp"]:
            frames.extend(more_frames_crop(im, ext=ext, shape='circle'))
        else:
            frames.append(circle_crop(im))
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    # 徽章前景图与背景图路劲
    base_dir = os.path.dirname(os.path.abspath(__file__))
    bg_filename = os.path.join(base_dir, 'assets/badge/', bg_pic[style])
    fg_filename = os.path.join(base_dir, 'assets/badge/', f'type-{style}-f.png')
    bg_im = Image.open(bg_filename).convert('RGBA')
    fg_im = Image.open(fg_filename).convert('RGBA')

    n_w = int(fg_im.width * ratio)
    n_h = int(fg_im.height * ratio)

    badges = []
    for frame in frames:
        # 调整主体图片大小
        resized_img = frame.resize((n_w, n_h), Image.Resampling.LANCZOS).convert('RGBA')

        # 创建与前景图片大小相同的画布
        result = Image.new('RGBA', fg_im.size, (255, 255, 255, 0))

        # 计算背景图相对前景图中心偏移量
        dx = (fg_im.width - bg_im.width) // 2
        dy = (fg_im.height - bg_im.height) // 2
        # 粘贴背景图
        result.paste(bg_im, (dx, dy), bg_im)

        # 计算主体图相对前景图中心偏移量
        dx = (fg_im.width - resized_img.width) // 2
        dy = (fg_im.height - resized_img.height) // 2
        # 粘贴主体图
        temp = Image.new('RGBA', fg_im.size, (255, 255, 255, 0))
        temp.paste(resized_img, (dx, dy), resized_img)

        # 使用alpha_composite函数合并主体图片
        result = Image.alpha_composite(result, temp)

        # 使用alpha_composite函数合并前景图片
        result = Image.alpha_composite(result, fg_im)

        badges.append(result)
    if len(frames) > 1:
        image_name = 'badge_' + str(int(time.time() * 1000)) + '.gif'
        filename = os.path.join(dst, image_name)
        badges[0].save(
            filename,
            save_all=True,
            append_images=badges[1:],
            duration=speed,
            loop=0,
            optimize=True
        )
    else:
        image_name = 'badge_' + str(int(time.time() * 1000)) + '.png'
        filename = os.path.join(dst, image_name)
        badges[0].save(filename)
    return image_name


def create_meme(images, text, color, size, pos=1, dst='./', speed=100):
    def crop_rect(_im, _size):
        _w, _h = _size
        r = _w / _h
        if _im.width / im.height > r:
            left = 0
            right = im.width
            top = 0
            bottom = int(im.width / r)
        else:
            nw = im.height * r
            left = (im.width - nw) // 2
            right = left + nw
            top = 0
            bottom = im.height
        return im.crop((left, top, right, bottom))

    def draw_text_with_stroke(_draw, _pos, _text, _font, fill, stroke_fill="black", stroke_width=2):
        """
        绘制带描边的文字
        """
        draw = ImageDraw.Draw(_draw)
        _x, _y = _pos
        # 八方向偏移绘制描边
        for dx in range(-stroke_width, stroke_width + 1):
            for dy in range(-stroke_width, stroke_width + 1):
                if dx != 0 or dy != 0:  # 跳过中心点
                    draw.text((x + dx, y + dy), text, font=font, fill=stroke_fill)
        draw.text((x, y), text, font=font, fill=fill)

    def convert_p(_im):
        if _im.mode == "RGBA":
            return resized_frame.convert('RGB').convert("P")
        else:
            return resized_frame.convert("P")

    if not isinstance(images, (list, tuple)):
        images = [images]
    if not isinstance(text, str):
        raise TypeError("表情包文字参数值类型错误。")
    if isinstance(color, (list, tuple)):
        if len(color) < 3 or len(color) > 4:
            raise TypeError("颜色参数RGB或RGBA值错误。")
    elif isinstance(color, str):
        try:
            color = ImageColor.getcolor(color, "RGBA")
        except Exception as e:
            raise TypeError("颜色参数字符串值错误。")
    else:
        raise TypeError("颜色参数值类型错误。")
    if not isinstance(size, int) or size < 0:
        raise TypeError("文字大小参数值类型错误。")
    if pos not in [1, 2, 3]:
        raise ValueError("文字位置参数值错误。")
    if not isinstance(speed, (float, int)):
        raise TypeError("播放速度参数值类型错误。")
    if not os.path.exists(dst):
        try:
            os.makedirs(dst)
        except Exception as e:
            raise ValueError("路径错误，创建文件失败")
    frames = []
    base_size = None
    align = 0, 0
    font = get_platform_font(size)
    for img in images:
        try:
            im = Image.open(img)
        except Exception as e:
            # 不支持文件不处理
            continue
        ext = im.format.lower()
        if ext not in ['png', 'jpg', 'jpeg', 'gif', 'webp']:
            continue
        if base_size is None:
            w, h = im.size
            base_size = w, h
            if w >= h > 720:
                base_size = 720, int(720/w * h)
            elif w <= h < 240:
                base_size = 240, int(240/w * h)
            elif h > w > 720:
                base_size = int(720/h * w), 720
            elif h < w < 240:
                base_size = int(240/h * w), 240

            txt_layer = Image.new('RGBA', base_size, (255, 255, 255, 0))
            bbox = ImageDraw.Draw(txt_layer).textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            w, h = base_size
            x = w // 2 - text_width//2
            if pos == 1:
                y = 20
            elif pos == 2:
                y = h // 2 - text_height // 2
            else:
                y = h - 20 - text_height
            align = x, y

        if ext == "gif":
            for frame in ImageSequence.Iterator(im):
                resized_frame = crop_rect(frame, base_size).resize(base_size).convert('RGBA')
                draw_text_with_stroke(resized_frame, align, text, font, fill=color)
                frames.append(convert_p(resized_frame))
        elif ext == "webp":
            frame = im.copy()
            resized_frame = crop_rect(frame, base_size).resize(base_size).convert('RGBA')
            draw_text_with_stroke(resized_frame, align, text, font, fill=color)
            frames.append(convert_p(resized_frame))
            if im.is_animated:
                for i in range(1, im.n_frames):
                    im.seek(i)
                    frame = im.copy()
                    resized_frame = crop_rect(frame, base_size).resize(base_size).convert('RGBA')
                    draw_text_with_stroke(resized_frame, align, text, font, fill=color)
                    frames.append(convert_p(resized_frame))
        else:
            resized_frame = crop_rect(im, base_size).resize(base_size).convert('RGBA')
            draw_text_with_stroke(resized_frame, align, text, font, fill=color)
            frames.append(convert_p(resized_frame))

    if len(frames) < 1:
        raise ValueError("生成表情包失败，请检查图片文件是否存在或格式错误。")
    image_name = 'meme_' + str(int(time.time() * 1000)) + '.gif'
    filename = os.path.join(dst, image_name)
    # 保存为GIF
    frames[0].save(
        filename,
        save_all=True,
        append_images=frames[1:],
        duration=speed,
        loop=0,
        optimize=True
    )
    return image_name
