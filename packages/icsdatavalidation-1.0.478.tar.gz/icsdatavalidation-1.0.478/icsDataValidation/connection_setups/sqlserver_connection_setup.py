import os

#########################################################################################
#########################################################################################

def load_sqlserver_credentials(system_configs:dict,system_selection:str)->dict:

    system_config = system_configs[system_selection]

    sqlserver_params = {
        "Server"    : system_config["SERVER"],
        "Database"  : system_config["DATABASE"],
        "User"      : system_config.get("USER"),
        "Password"  : os.getenv(system_config["PASSWORD_NAME"]) if system_config.get("PASSWORD_NAME") else None,
        "Driver"    : system_config["DRIVER"],
        "Port"      : system_config.get("PORT"),
        "Encrypt"   : system_config.get("Encrypt"),
        "TrustServerCertificate"   : system_config.get("TrustServerCertificate"),
        "TrustedConnection"        : system_config.get("TrustedConnection", False),
    }

    return sqlserver_params
