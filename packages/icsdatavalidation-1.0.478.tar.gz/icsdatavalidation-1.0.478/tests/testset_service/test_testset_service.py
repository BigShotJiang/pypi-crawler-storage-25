import pytest

from icsDataValidation.services.testset_service import TestsetService


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

EMPTY_BLACKLIST = {
    "BLACKLIST_DATABASES_SRC": [],
    "BLACKLIST_SCHEMAS_SRC": [],
    "BLACKLIST_OBJECTS_SRC": [],
    "BLACKLIST_DATABASES_TRGT": [],
    "BLACKLIST_SCHEMAS_TRGT": [],
    "BLACKLIST_OBJECTS_TRGT": [],
}

FULL_MAPPING = {
    "OBJECT_MAPPING": [
        {
            "src_object_identifier": "DB1.SCHEMA1.TBL_SRC",
            "src_object_type": "table",
            "trgt_object_identifier": "DB1.SCHEMA1.TBL_TRGT",
            "trgt_object_type": "table",
        }
    ],
    "DATABASE_MAPPING": [
        {"src_database_name": "DB_SRC", "trgt_database_name": "DB_TRGT"}
    ],
    "SCHEMA_MAPPING": [
        {"src_schema_identifier": "DB1.SCHEMA_SRC", "trgt_schema_name": "SCHEMA_TRGT"}
    ],
    "SCHEMA_REPLACE_MAPPING": [
        {"src_replace_value": "SRC", "trgt_replace_value": "TRGT"}
    ],
    "OBJECTNAME_REPLACE_MAPPING": [
        {"src_replace_value": "EINS", "trgt_replace_value": "ONE"}
    ],
}


def make_service(mapping=None, blacklist=None):
    return TestsetService(
        testset_mapping=mapping if mapping is not None else FULL_MAPPING,
        testset_blacklist=blacklist if blacklist is not None else EMPTY_BLACKLIST,
    )


# ---------------------------------------------------------------------------
# handle_database_mapping
# ---------------------------------------------------------------------------

class TestHandleDatabaseMapping:

    @pytest.mark.parametrize("src,expected", [
        ("DB_SRC", "DB_TRGT"),       # mapped
        ("db_src", "DB_TRGT"),       # case-insensitive input
        ("DB_OTHER", "DB_OTHER"),    # not in mapping -> returns upper-case src
    ])
    def test_mapping(self, src, expected):
        service = make_service()
        assert service.handle_database_mapping(src) == expected

    def test_no_mapping_config(self):
        service = make_service(mapping={
            "OBJECT_MAPPING": [],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        })
        assert service.handle_database_mapping("DB_SRC") == "DB_SRC"

    def test_returns_uppercase(self):
        service = make_service(mapping={"DATABASE_MAPPING": [], "OBJECT_MAPPING": [], "SCHEMA_MAPPING": [], "OBJECTNAME_REPLACE_MAPPING": []})
        assert service.handle_database_mapping("lowercase_db") == "LOWERCASE_DB"


# ---------------------------------------------------------------------------
# handle_schema_mapping
# ---------------------------------------------------------------------------

class TestHandleSchemaMapping:

    @pytest.mark.parametrize("src_schema,src_db,expected_schema,expected_found", [
        ("SCHEMA_SRC", "DB1", "SCHEMA_TRGT", True),     # exact match
        ("schema_src", "db1", "SCHEMA_TRGT", True),     # case-insensitive
        ("SCHEMA_OTHER", "DB1", "SCHEMA_OTHER", False), # no match
        ("SCHEMA_SRC", "DB2", "SCHEMA_SRC", False),     # wrong database
    ])
    def test_mapping(self, src_schema, src_db, expected_schema, expected_found):
        service = make_service()
        result_schema, found = service.handle_schema_mapping(src_schema, src_db)
        assert result_schema == expected_schema
        assert found == expected_found

    def test_returns_uppercase(self):
        service = make_service()
        result, _ = service.handle_schema_mapping("no_match_schema", "DB1")
        assert result == "NO_MATCH_SCHEMA"


# ---------------------------------------------------------------------------
# handle_schema_replace_mapping
# ---------------------------------------------------------------------------

class TestHandleSchemaReplaceMapping:

    @pytest.mark.parametrize("src_schema,expected", [
        ("MY_SRC_SCHEMA", "MY_TRGT_SCHEMA"),   # replacement applied
        ("my_src_schema", "MY_TRGT_SCHEMA"),   # case-insensitive
        ("NO_MATCH_SCHEMA", "NO_MATCH_SCHEMA"),# no replacement token -> unchanged
    ])
    def test_replace(self, src_schema, expected):
        service = make_service()
        assert service.handle_schema_replace_mapping(src_schema) == expected

    def test_no_replace_mapping_config(self):
        service = make_service(mapping={"OBJECT_MAPPING": [], "DATABASE_MAPPING": [], "SCHEMA_MAPPING": [], "OBJECTNAME_REPLACE_MAPPING": []})
        assert service.handle_schema_replace_mapping("MY_SCHEMA") == "MY_SCHEMA"


# ---------------------------------------------------------------------------
# handle_blacklist
# ---------------------------------------------------------------------------

class TestHandleBlacklist:

    def _objects(self, identifiers, obj_type="table"):
        return [{"object_identifier": i, "object_type": obj_type} for i in identifiers]

    def test_blacklist_object(self):
        blacklist = {**EMPTY_BLACKLIST, "BLACKLIST_OBJECTS_SRC": ["DB1.SCHEMA1.TBL_BAD"]}
        service = make_service(blacklist=blacklist)
        objects = self._objects(["DB1.SCHEMA1.TBL_OK", "DB1.SCHEMA1.TBL_BAD"])
        result = service.handle_blacklist(objects, "SRC")
        ids = [o["object_identifier"] for o in result]
        assert "DB1.SCHEMA1.TBL_BAD" not in ids
        assert "DB1.SCHEMA1.TBL_OK" in ids

    def test_blacklist_schema(self):
        blacklist = {**EMPTY_BLACKLIST, "BLACKLIST_SCHEMAS_SRC": ["DB1.SCHEMA_BAD"]}
        service = make_service(blacklist=blacklist)
        objects = self._objects(["DB1.SCHEMA_BAD.TBL1", "DB1.SCHEMA_OK.TBL2"])
        result = service.handle_blacklist(objects, "SRC")
        ids = [o["object_identifier"] for o in result]
        assert "DB1.SCHEMA_BAD.TBL1" not in ids
        assert "DB1.SCHEMA_OK.TBL2" in ids

    def test_blacklist_database(self):
        blacklist = {**EMPTY_BLACKLIST, "BLACKLIST_DATABASES_SRC": ["DB_BAD"]}
        service = make_service(blacklist=blacklist)
        objects = self._objects(["DB_BAD.SCHEMA1.TBL1", "DB_OK.SCHEMA1.TBL2"])
        result = service.handle_blacklist(objects, "SRC")
        ids = [o["object_identifier"] for o in result]
        assert "DB_BAD.SCHEMA1.TBL1" not in ids
        assert "DB_OK.SCHEMA1.TBL2" in ids

    def test_empty_blacklist(self):
        service = make_service()
        objects = self._objects(["DB1.SCHEMA1.TBL1", "DB1.SCHEMA1.TBL2"])
        result = service.handle_blacklist(objects, "SRC")
        assert len(result) == 2

    def test_trgt_blacklist(self):
        blacklist = {**EMPTY_BLACKLIST, "BLACKLIST_OBJECTS_TRGT": ["DB1.SCHEMA1.TBL_BAD"]}
        service = make_service(blacklist=blacklist)
        objects = self._objects(["DB1.SCHEMA1.TBL_BAD", "DB1.SCHEMA1.TBL_OK"])
        result = service.handle_blacklist(objects, "TRGT")
        ids = [o["object_identifier"] for o in result]
        assert "DB1.SCHEMA1.TBL_BAD" not in ids


# ---------------------------------------------------------------------------
# map_objects
# ---------------------------------------------------------------------------

class TestMapObjects:

    def _obj(self, identifier, obj_type="table"):
        return {"object_identifier": identifier, "object_type": obj_type}

    def test_identical_lists_returns_empty_mapped(self):
        service = make_service()
        src = [self._obj("DB1.SCHEMA1.TBL1")]
        trgt = [self._obj("DB1.SCHEMA1.TBL1")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert mapped == []
        assert src_minus == []
        assert trgt_minus == []
        assert remaining == []
        assert all_matching is True

    def test_object_mapping_1to1(self):
        mapping = {
            "OBJECT_MAPPING": [
                {
                    "src_object_identifier": "DB1.SCHEMA1.TBL_SRC",
                    "src_object_type": "table",
                    "trgt_object_identifier": "DB1.SCHEMA1.TBL_TRGT",
                    "trgt_object_type": "table",
                }
            ],
            "DATABASE_MAPPING": [],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB1.SCHEMA1.TBL_SRC")]
        trgt = [self._obj("DB1.SCHEMA1.TBL_TRGT")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert mapped[0]["src_object_identifier"] == "DB1.SCHEMA1.TBL_SRC"
        assert mapped[0]["trgt_object_identifier"] == "DB1.SCHEMA1.TBL_TRGT"
        assert remaining == []

    def test_database_mapping(self):
        mapping = {
            "OBJECT_MAPPING": [],
            "DATABASE_MAPPING": [{"src_database_name": "DB_SRC", "trgt_database_name": "DB_TRGT"}],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB_SRC.SCHEMA1.TBL1")]
        trgt = [self._obj("DB_TRGT.SCHEMA1.TBL1")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert mapped[0]["trgt_object_identifier"] == "DB_TRGT.SCHEMA1.TBL1"
        assert remaining == []

    def test_objectname_replace_mapping(self):
        mapping = {
            "OBJECT_MAPPING": [],
            "DATABASE_MAPPING": [],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [{"src_replace_value": "EINS", "trgt_replace_value": "ONE"}],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB1.SCHEMA1.TBL_EINS")]
        trgt = [self._obj("DB1.SCHEMA1.TBL_ONE")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert mapped[0]["trgt_object_identifier"] == "DB1.SCHEMA1.TBL_ONE"
        assert remaining == []

    def test_no_mapping_found_goes_to_remaining(self):
        mapping = {
            "OBJECT_MAPPING": [],
            "DATABASE_MAPPING": [],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB1.SCHEMA1.TBL_ONLY_SRC")]
        trgt = [self._obj("DB1.SCHEMA1.TBL_ONLY_TRGT")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert len(remaining) == 1
        assert remaining[0]["src_object_identifier"] == "DB1.SCHEMA1.TBL_ONLY_SRC"
        assert all_matching is False

    def test_view_object_mapping(self):
        mapping = {
            "OBJECT_MAPPING": [],
            "DATABASE_MAPPING": [{"src_database_name": "DB_SRC", "trgt_database_name": "DB_TRGT"}],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB_SRC.SCHEMA1.VW1", obj_type="view")]
        trgt = [self._obj("DB_TRGT.SCHEMA1.VW1", obj_type="view")]
        mapped, _, _, remaining, _ = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert mapped[0]["src_object_type"] == "view"
        assert remaining == []

    def test_objectname_replace_mapping_combined_with_database_and_schema_mapping(self):
        mapping = {
            "OBJECT_MAPPING": [],
            "DATABASE_MAPPING": [{"src_database_name": "DB_SRC", "trgt_database_name": "DB_TRGT"}],
            "SCHEMA_MAPPING": [{"src_schema_identifier": "DB_SRC.SCHEMA_SRC", "trgt_schema_name": "SCHEMA_TRGT"}],
            "OBJECTNAME_REPLACE_MAPPING": [{"src_replace_value": "EINS", "trgt_replace_value": "ONE"}],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB_SRC.SCHEMA_SRC.TBL_EINS")]
        trgt = [self._obj("DB_TRGT.SCHEMA_TRGT.TBL_ONE")]
        mapped, src_minus, trgt_minus, remaining, all_matching = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert mapped[0]["src_object_identifier"] == "DB_SRC.SCHEMA_SRC.TBL_EINS"
        assert mapped[0]["trgt_object_identifier"] == "DB_TRGT.SCHEMA_TRGT.TBL_ONE"
        assert remaining == []
        assert all_matching is True

    def test_case_insensitive_object_mapping(self):
        mapping = {
            "OBJECT_MAPPING": [
                {
                    "src_object_identifier": "db1.schema1.tbl_src",
                    "src_object_type": "table",
                    "trgt_object_identifier": "db1.schema1.tbl_trgt",
                    "trgt_object_type": "table",
                }
            ],
            "DATABASE_MAPPING": [],
            "SCHEMA_MAPPING": [],
            "OBJECTNAME_REPLACE_MAPPING": [],
        }
        service = make_service(mapping=mapping)
        src = [self._obj("DB1.SCHEMA1.TBL_SRC")]
        trgt = [self._obj("DB1.SCHEMA1.TBL_TRGT")]
        mapped, _, _, remaining, _ = service.map_objects(src, trgt)
        assert len(mapped) == 1
        assert remaining == []


# ---------------------------------------------------------------------------
# get_intersection_objects_trgt_src
# ---------------------------------------------------------------------------

class TestGetIntersectionObjects:

    def _obj(self, identifier, obj_type="table"):
        return {"object_identifier": identifier, "object_type": obj_type}

    def test_direct_intersection(self):
        src = [self._obj("DB1.S1.TBL1"), self._obj("DB1.S1.TBL2")]
        trgt = [self._obj("DB1.S1.TBL1"), self._obj("DB1.S1.TBL3")]
        result = TestsetService.get_intersection_objects_trgt_src(src, trgt, [])
        ids = [r["src_object_identifier"] for r in result]
        assert "DB1.S1.TBL1" in ids
        assert "DB1.S1.TBL2" not in ids

    def test_mapped_objects_included(self):
        src = [self._obj("DB1.S1.TBL_SRC")]
        trgt = [self._obj("DB1.S1.TBL_TRGT")]
        mapped = [{"src_object_identifier": "DB1.S1.TBL_SRC", "src_object_type": "table",
                   "trgt_object_identifier": "DB1.S1.TBL_TRGT", "trgt_object_type": "table"}]
        result = TestsetService.get_intersection_objects_trgt_src(src, trgt, mapped)
        src_ids = [r["src_object_identifier"] for r in result]
        assert "DB1.S1.TBL_SRC" in src_ids

    def test_empty_lists(self):
        result = TestsetService.get_intersection_objects_trgt_src([], [], [])
        assert result == []
