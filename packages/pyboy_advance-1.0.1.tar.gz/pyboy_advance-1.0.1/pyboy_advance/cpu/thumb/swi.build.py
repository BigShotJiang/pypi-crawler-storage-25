def thumb_software_interrupt(cpu: CPU, instr: int):
    """Execute a THUMB.17 instruction (software interrupt)"""
    cpu.interrupt(ExceptionVector.ExceptionVector_SWI)