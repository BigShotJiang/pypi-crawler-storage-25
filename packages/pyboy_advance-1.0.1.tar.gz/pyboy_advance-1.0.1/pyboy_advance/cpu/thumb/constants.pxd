cpdef enum ThumbALUOpcode:
    ThumbALUOpcode_AND = 0
    ThumbALUOpcode_EOR = 1
    ThumbALUOpcode_LSL = 2
    ThumbALUOpcode_LSR = 3
    ThumbALUOpcode_ASR = 4
    ThumbALUOpcode_ADC = 5
    ThumbALUOpcode_SBC = 6
    ThumbALUOpcode_ROR = 7
    ThumbALUOpcode_TST = 8
    NEG = 9
    ThumbALUOpcode_CMP = 10
    ThumbALUOpcode_CMN = 11
    ThumbALUOpcode_ORR = 12
    MUL = 13
    ThumbALUOpcode_BIC = 14
    ThumbALUOpcode_MVN = 15

