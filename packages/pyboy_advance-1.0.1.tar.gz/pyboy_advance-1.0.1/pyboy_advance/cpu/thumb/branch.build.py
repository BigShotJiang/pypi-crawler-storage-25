def thumb_unconditional_branch(cpu: CPU, instr: int):
    """Execute a THUMB.18 instruction (unconditional branch)"""
    offset = extend_sign_12(get_bits(instr, 0, 10) << 1)
    cpu.regs.set_pc(add_32(cpu.regs.get_pc(), offset))
    cpu.flush_pipeline()

def thumb_conditional_branch(cpu: CPU, instr: int):
    """Execute a THUMB.16 instruction (conditional branch)"""
    condition = get_bits(instr, 8, 11)
    offset = extend_sign_8(get_bits(instr, 0, 7)) * 2
    if cpu.check_condition(condition):
        cpu.regs.set_pc(add_32(cpu.regs.get_pc(), offset))
        cpu.flush_pipeline()
    else:
        cpu.advance_pc_thumb()
        cpu.next_fetch_access = MemoryAccess.SEQUENTIAL

def thumb_long_branch_with_link(cpu: CPU, instr: int):
    """
    Execute a THUMB.19 instruction (long branch with link).

    Long Branch with Link is a 32-bit instruction split across two 16-bit THUMB opcodes.
    Bit 11 determines whether the opcode is the first one or the second one.
    """
    is_first_opcode = not get_bit(instr, 11)
    if is_first_opcode:
        address_upper_bits = extend_sign_23(get_bits(instr, 0, 10) << 12)
        cpu.regs.set_lr(add_32(cpu.regs.get_pc(), address_upper_bits))
        cpu.advance_pc_thumb()
        cpu.next_fetch_access = MemoryAccess.SEQUENTIAL
    else:
        address_lower_bits = get_bits(instr, 0, 10) << 1
        pc = add_32(cpu.regs.get_pc(), -2)
        cpu.regs.set_pc(add_32(cpu.regs.get_lr(), address_lower_bits))
        cpu.regs.set_lr(pc | 1)
        cpu.flush_pipeline()