THUMB_PATTERNS: list[InstrPattern] = [InstrPattern(255, 223, thumb_software_interrupt), InstrPattern(248, 224, thumb_unconditional_branch), InstrPattern(240, 208, thumb_conditional_branch), InstrPattern(240, 240, thumb_long_branch_with_link), InstrPattern(240, 192, thumb_multiple_load_store), InstrPattern(246, 180, thumb_push_pop_registers), InstrPattern(255, 176, thumb_add_offset_to_stack_pointer), InstrPattern(240, 160, thumb_get_address), InstrPattern(240, 144, thumb_sp_relative_load_store), InstrPattern(240, 128, thumb_load_store_halfword), InstrPattern(224, 96, thumb_load_store_immediate_offset), InstrPattern(242, 80, thumb_load_store_register_offset), InstrPattern(242, 82, thumb_load_store_sign_extended), InstrPattern(248, 72, thumb_pc_relative_load), InstrPattern(252, 68, thumb_high_reg_branch_exchange), InstrPattern(252, 64, thumb_alu), InstrPattern(224, 32, thumb_move_compare_add_subtract), InstrPattern(248, 24, thumb_add_subtract), InstrPattern(224, 0, thumb_move_shifted_register)]

def fill_thumb_lut():
    for opcode in range(2 ** 8):
        for pattern in THUMB_PATTERNS:
            if opcode & pattern.mask == pattern.value:
                THUMB_LUT[opcode] = pattern.handler
                break
fill_thumb_lut()

def thumb_decoder(instr: int) -> InstrHandler:
    instruction_handler = THUMB_LUT[instr >> 8]
    return instruction_handler