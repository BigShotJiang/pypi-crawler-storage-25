from enum import IntEnum

class ThumbALUOpcode(IntEnum):
    AND = 0
    EOR = 1
    LSL = 2
    LSR = 3
    ASR = 4
    ADC = 5
    SBC = 6
    ROR = 7
    TST = 8
    NEG = 9
    CMP = 10
    CMN = 11
    ORR = 12
    MUL = 13
    BIC = 14
    MVN = 15