from enum import IntEnum

class CPUState(IntEnum):
    ARM = 0
    THUMB = 1

class CPUMode(IntEnum):
    USER = 16
    FIQ = 17
    IRQ = 18
    SWI = 19
    ABORT = 23
    UNDEFINED = 27
    SYSTEM = 31

class Condition(IntEnum):
    EQ = 0
    NE = 1
    HS = 2
    LO = 3
    MI = 4
    PL = 5
    VS = 6
    VC = 7
    HI = 8
    LS = 9
    GE = 10
    LT = 11
    GT = 12
    LE = 13
    AL = 14
    NV = 15

class ShiftType(IntEnum):
    LSL = 0
    LSR = 1
    ASR = 2
    ROR = 3

class ExceptionVector(IntEnum):
    RESET = 0
    UNDEFINED_INSTRUCTION = 4
    SWI = 8
    PREFETCH_ABORT = 12
    DATA_ABORT = 16
    ADDRESS_EXCEEDS_26_BITS = 20
    IRQ = 24
    FIQ = 28

class BankIndex(IntEnum):
    BANK_SYSTEM_USER = 0
    BANK_FIQ = 1
    BANK_IRQ = 2
    BANK_SWI = 3
    BANK_ABORT = 4
    BANK_UNDEFINED = 5
ARM_PC_INCREMENT = 4
THUMB_PC_INCREMENT = 2