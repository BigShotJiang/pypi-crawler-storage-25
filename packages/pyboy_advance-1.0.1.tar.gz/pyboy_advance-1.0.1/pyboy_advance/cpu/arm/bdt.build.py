def arm_block_data_transfer(cpu: CPU, instr: int):
    """Execute a Block Data Transfer instruction (LDM, STM)"""
    pre_post_bit = get_bit(instr, 24)
    up_down_bit = get_bit(instr, 23)
    psr_and_force_user_bit = get_bit(instr, 22)
    write_back_bit = get_bit(instr, 21)
    load_store_bit = get_bit(instr, 20)
    base_reg = get_bits(instr, 16, 19)
    reg_list = get_bits(instr, 0, 15)
    reg_list_count = 0
    for reg in range(16):
        reg_list_count += get_bit(reg_list, reg)
    if reg_list_count == 0:
        reg_list = set_bit(reg_list, cpu.regs.PC, True)
        reg_list_count = 16
    pc_in_reg_list = get_bit(reg_list, cpu.regs.PC)
    base = cpu.regs.get(base_reg)
    if up_down_bit:
        final_address = add_32(base, reg_list_count * 4)
    else:
        final_address = add_32(base, reg_list_count * -4)
        base = final_address
        pre_post_bit = not pre_post_bit
    original_mode = cpu.regs.cpsr.get_mode()
    if psr_and_force_user_bit and (not (pc_in_reg_list and load_store_bit)):
        cpu.switch_mode(CPUMode.USER)
    cpu.advance_pc_arm()
    cpu.next_fetch_access = MemoryAccess.NON_SEQUENTIAL
    first = True
    access_type = MemoryAccess.NON_SEQUENTIAL
    for reg in range(16):
        if get_bit(reg_list, reg):
            if pre_post_bit:
                base = add_32(base, 4)
            if load_store_bit:
                if first and write_back_bit:
                    first = False
                    cpu.regs.set(base_reg, final_address)
                cpu.regs.set(reg, cpu.memory.read_32(base, access_type))
            else:
                cpu.memory.write_32(base, cpu.regs.get(reg), access_type)
                if first and write_back_bit:
                    first = False
                    cpu.regs.set(base_reg, final_address)
            if not pre_post_bit:
                base = add_32(base, 4)
            access_type = MemoryAccess.SEQUENTIAL
    if pc_in_reg_list and load_store_bit:
        if psr_and_force_user_bit:
            spsr_reg = cpu.regs.spsr.reg
            spsr_mode = cpu.regs.spsr.get_mode()
            cpu.switch_mode(spsr_mode)
            cpu.regs.cpsr.reg = spsr_reg
        cpu.flush_pipeline()
    elif psr_and_force_user_bit:
        cpu.switch_mode(original_mode)
    if load_store_bit:
        cpu.scheduler.idle(1)