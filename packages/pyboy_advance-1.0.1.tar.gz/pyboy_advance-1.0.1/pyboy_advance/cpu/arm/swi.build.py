def arm_software_interrupt(cpu: CPU, instr: int):
    """Execute a Software Interrupt instruction (SWI)"""
    cpu.interrupt(ExceptionVector.ExceptionVector_SWI)