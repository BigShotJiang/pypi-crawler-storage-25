def arm_branch(cpu: CPU, instr: int):
    """Execute a Branch or Branch and Link instruction"""
    offset = extend_sign_24(instr & 16777215) * 4
    link_flag = get_bit(instr, 24)
    if link_flag:
        cpu.regs.set_lr(add_32(cpu.regs.get_pc(), -4))
    cpu.regs.set_pc(add_32(cpu.regs.get_pc(), offset))
    cpu.flush_pipeline()

def arm_branch_exchange(cpu: CPU, instr: int):
    """Execute a Branch and Exchange instruction"""
    address = cpu.regs.get(instr & 15)
    cpu.regs.set_pc(address & ~1)
    cpu.regs.cpsr.set_state(get_bit(address, 0))
    cpu.flush_pipeline()