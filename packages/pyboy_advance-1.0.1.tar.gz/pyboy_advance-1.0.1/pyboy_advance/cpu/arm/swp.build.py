def arm_single_data_swap(cpu: CPU, instr: int):
    """Executes a Single Data Swap instruction (SWP)"""
    base_reg = get_bits(instr, 16, 19)
    dst_reg = get_bits(instr, 12, 15)
    src_reg = get_bits(instr, 0, 3)
    byte_word_bit = get_bit(instr, 22)
    if byte_word_bit:
        temp = cpu.memory.read_8(cpu.regs.get(base_reg), MemoryAccess.NON_SEQUENTIAL)
        cpu.memory.write_8(cpu.regs.get(base_reg), cpu.regs.get(src_reg), MemoryAccess.NON_SEQUENTIAL)
        cpu.regs.set(dst_reg, temp)
    else:
        temp = cpu.memory.read_32_ror(cpu.regs.get(base_reg), MemoryAccess.NON_SEQUENTIAL)
        cpu.memory.write_32(cpu.regs.get(base_reg), cpu.regs.get(src_reg), MemoryAccess.NON_SEQUENTIAL)
        cpu.regs.set(dst_reg, temp)
    cpu.scheduler.idle(1)
    cpu.advance_pc_arm()
    cpu.next_fetch_access = MemoryAccess.NON_SEQUENTIAL