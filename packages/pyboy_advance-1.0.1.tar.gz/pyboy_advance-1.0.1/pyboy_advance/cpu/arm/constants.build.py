from enum import IntEnum

class ALUOpcode(IntEnum):
    AND = 0
    EOR = 1
    SUB = 2
    RSB = 3
    ADD = 4
    ADC = 5
    SBC = 6
    RSC = 7
    TST = 8
    TEQ = 9
    CMP = 10
    CMN = 11
    ORR = 12
    MOV = 13
    BIC = 14
    MVN = 15

class DataTransferOpcode(IntEnum):
    STRH = 1
    LDRD = 2
    STRD = 3
    LDRH = 1
    LDRSB = 2
    LDRSH = 3

class MultiplyLongOpcode(IntEnum):
    UMULL = 0
    UMLAL = 1
    SMULL = 2
    SMLAL = 3