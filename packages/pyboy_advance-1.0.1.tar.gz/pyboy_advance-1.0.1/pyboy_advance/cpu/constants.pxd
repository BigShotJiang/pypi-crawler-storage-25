cpdef enum CPUState:
    ARM = 0
    THUMB = 1

cpdef enum CPUMode:
    USER = 16
    FIQ = 17
    IRQ = 18
    SWI = 19
    ABORT = 23
    UNDEFINED = 27
    SYSTEM = 31

cpdef enum Condition:
    EQ = 0
    NE = 1
    HS = 2
    LO = 3
    MI = 4
    PL = 5
    VS = 6
    VC = 7
    HI = 8
    LS = 9
    GE = 10
    LT = 11
    GT = 12
    LE = 13
    AL = 14
    NV = 15

cpdef enum ShiftType:
    LSL = 0
    LSR = 1
    ASR = 2
    ROR = 3

cpdef enum ExceptionVector:
    RESET = 0
    UNDEFINED_INSTRUCTION = 4
    ExceptionVector_SWI = 8
    PREFETCH_ABORT = 12
    DATA_ABORT = 16
    ADDRESS_EXCEEDS_26_BITS = 20
    ExceptionVector_IRQ = 24
    ExceptionVector_FIQ = 28

cpdef enum BankIndex:
    BANK_SYSTEM_USER = 0
    BANK_FIQ = 1
    BANK_IRQ = 2
    BANK_SWI = 3
    BANK_ABORT = 4
    BANK_UNDEFINED = 5

cdef enum:
    ARM_PC_INCREMENT = 4
    THUMB_PC_INCREMENT = 2

