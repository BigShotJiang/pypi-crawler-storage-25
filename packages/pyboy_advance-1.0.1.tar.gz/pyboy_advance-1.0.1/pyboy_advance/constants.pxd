cpdef enum Interrupt:
    VBLANK = 1
    HBLANK = 2
    VCOUNT = 4
    TIMER_0 = 8
    TIMER_1 = 16
    TIMER_2 = 32
    TIMER_3 = 64
    SERIAL = 128
    DMA_0 = 256
    DMA_1 = 512
    DMA_2 = 1024
    DMA_3 = 2048
    KEYPAD = 4096
    GAMEPAK = 8192
    ALL = 16383

cpdef enum PowerDownMode:
    NONE = 0
    HALT = 1
    STOP = 2

cpdef enum EventTrigger:
    IMMEDIATELY = 0
    EventTrigger_VBLANK = 1
    EventTrigger_HBLANK = 2

cpdef enum Key:
    BUTTON_A = 1
    BUTTON_B = 2
    BUTTON_SELECT = 4
    BUTTON_START = 8
    DPAD_RIGHT = 16
    DPAD_LEFT = 32
    DPAD_UP = 64
    DPAD_DOWN = 128
    SHOULDER_RIGHT = 256
    SHOULDER_LEFT = 512

cdef enum:
    CLOCK_SPEED_HZ = 16777216
    NANOSECONDS_PER_SECOND = 1000000000

