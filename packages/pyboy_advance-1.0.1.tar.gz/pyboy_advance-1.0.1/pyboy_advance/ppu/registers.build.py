class DisplayControlRegister:

    def __init__(self):
        self.reg = 0

    def get_video_mode(self) -> VideoMode | int:
        return get_bits(self.reg, 0, 2)

    def get_page_select(self) -> bint:
        return get_bit(self.reg, 4)

    def get_hblank_interval_free(self) -> bint:
        return get_bit(self.reg, 5)

    def get_obj_vram_dimension(self) -> bint:
        return get_bit(self.reg, 6)

    def get_force_blank(self) -> bint:
        return get_bit(self.reg, 7)

    def display_bg(self, bg_num: int) -> bint:
        return get_bit(self.reg, 8 + bg_num)

    def get_display_obj(self) -> bint:
        return get_bit(self.reg, 12)

    def display_window(self, window: WindowIndex) -> bint:
        return get_bit(self.reg, 13 + window)

class DisplayStatusRegister:

    def __init__(self):
        self.reg = 0

    def get_vblank_status(self) -> bint:
        return get_bit(self.reg, 0)

    def set_vblank_status(self, value: bint):
        self.reg = set_bit(self.reg, 0, value)

    def get_hblank_status(self) -> bint:
        return get_bit(self.reg, 1)

    def set_hblank_status(self, value: bint):
        self.reg = set_bit(self.reg, 1, value)

    def get_vcount_trigger_status(self) -> bint:
        return get_bit(self.reg, 2)

    def set_vcount_trigger_status(self, value: bint):
        self.reg = set_bit(self.reg, 2, value)

    def get_vblank_irq(self) -> bint:
        return get_bit(self.reg, 3)

    def set_vblank_irq(self, value: bint):
        self.reg = set_bit(self.reg, 3, value)

    def get_hblank_irq(self) -> bint:
        return get_bit(self.reg, 4)

    def set_hblank_irq(self, value: bint):
        self.reg = set_bit(self.reg, 4, value)

    def get_vcount_irq(self) -> bint:
        return get_bit(self.reg, 5)

    def set_vcount_irq(self, value: bint):
        self.reg = set_bit(self.reg, 5, value)

    def get_vcount_trigger_value(self) -> int:
        return get_bits(self.reg, 8, 15)

    def set_vcount_trigger_value(self, value: int):
        self.reg = self.reg & 255 | value << 8

class BackgroundControlRegister:

    def __init__(self):
        self.reg = 0

    def get_priority(self) -> int:
        return get_bits(self.reg, 0, 1)

    def get_tile_set_block(self) -> int:
        return get_bits(self.reg, 2, 3)

    def get_mosaic(self) -> bint:
        return get_bit(self.reg, 6)

    def get_colour_256(self) -> bint:
        return get_bit(self.reg, 7)

    def get_tile_map_block(self) -> int:
        return get_bits(self.reg, 8, 12)

    def get_wraparound(self) -> bint:
        return get_bit(self.reg, 13)

    def get_size(self) -> int:
        return get_bits(self.reg, 14, 15)

class WindowControlRegister:

    def __init__(self):
        self.reg = 0

    def display_layer(self, layer_type: LayerType) -> bint:
        return get_bit(self.reg, layer_type)

    def get_enable_blending(self) -> bint:
        return get_bit(self.reg, 5)

class BlendControlRegister:

    def __init__(self):
        self.reg = 0

    def blend_source(self, layer_type: LayerType | int) -> bint:
        return get_bit(self.reg, layer_type)

    def blend_target(self, layer_type: LayerType | int) -> bint:
        return get_bit(self.reg, 8 + layer_type)

    def get_blend_mode(self) -> BlendMode | int:
        return get_bits(self.reg, 6, 7)

class BlendAlphaRegister:

    def __init__(self):
        self.reg = 0

    def get_coefficient_source(self) -> int:
        return get_bits(self.reg, 0, 4)

    def get_coefficient_target(self) -> int:
        return get_bits(self.reg, 8, 12)

class BlendBrightnessRegister:

    def __init__(self):
        self.reg = 0

    def get_brightness(self) -> int:
        return get_bits(self.reg, 0, 4)