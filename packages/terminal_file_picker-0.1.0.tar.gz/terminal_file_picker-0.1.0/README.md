# ⚡ Terminal File Picker + Inline Editor

A two-stage terminal tool: search your codebase, pick a file, edit it — all without leaving the terminal.

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
python cli.py
```

## Usage Flow

1. Enter your project root directory (or `.` for current)
2. A TUI opens — type to filter files instantly
3. Press `Enter` in the search box to move focus to the list
4. Use `↑ ↓` to navigate, `Enter` to select a file
5. Press `Esc` to quit without selecting
6. After selection, choose **overwrite** or **append** mode
7. Type your content line by line
8. Type `:done` on a new line to save

## Keyboard Shortcuts (TUI)

| Key    | Action                  |
|--------|-------------------------|
| Type   | Filter files            |
| Enter  | Confirm search / Select |
| ↑ ↓   | Navigate list           |
| Esc    | Quit without selecting  |

## Excluded Directories

`.git`, `node_modules`, `dist`, `.venv`, `__pycache__`, `.idea`, `.mypy_cache`

