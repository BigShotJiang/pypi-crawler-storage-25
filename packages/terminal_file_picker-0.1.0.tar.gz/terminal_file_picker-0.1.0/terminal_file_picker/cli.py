from __future__ import annotations

import os
import sys
from pathlib import Path

from textual.app import App, ComposeResult
from textual.widgets import Input, ListView, ListItem, Label
from textual.binding import Binding
from textual import on


# ─────────────────────────────────────────────
# Directories to exclude during file indexing
# ─────────────────────────────────────────────
EXCLUDED_DIRS = {".git", "node_modules", "dist", ".venv", "__pycache__", ".idea", ".mypy_cache"}


# ─────────────────────────────────────────────
# File Picker TUI (Textual App)
# ─────────────────────────────────────────────
class FilePicker(App):
    CSS = """
    Screen {
        align: center middle;
        background: $surface;
    }

    #container {
        width: 80%;
        height: 85%;
        border: round $primary;
        background: $panel;
        padding: 1 2;
    }

    #title {
        text-align: center;
        color: $accent;
        text-style: bold;
        margin-bottom: 1;
    }

    #search {
        margin-bottom: 1;
        border: solid $primary;
    }

    #results {
        height: 1fr;
        border: solid $primary-darken-2;
        background: $surface;
    }

    #hint {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "quit_no_select", "Quit"),
    ]

    def __init__(self, root: Path) -> None:
        super().__init__()
        self.root = root
        self.all_files: list[str] = []
        self.selected_file: str | None = None

    def compose(self) -> ComposeResult:
        from textual.containers import Container
        with Container(id="container"):
            yield Label("⚡ Terminal File Picker", id="title")
            yield Input(placeholder="Search files...", id="search")
            yield ListView(id="results")
            yield Label("↑↓ Navigate  Enter Select  Esc Quit", id="hint")

    def on_mount(self) -> None:
        self.all_files = self._index_files()
        self._populate_list(self.all_files[:200])
        self.query_one("#search", Input).focus()

    def _index_files(self) -> list[str]:
        files: list[str] = []
        root_str = str(self.root)
        for dirpath, dirnames, filenames in os.walk(root_str):
            # Prune excluded directories in-place
            dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIRS]
            for filename in filenames:
                full_path = os.path.join(dirpath, filename)
                rel_path = os.path.relpath(full_path, root_str)
                files.append(rel_path)
        files.sort()
        return files

    def _populate_list(self, paths: list[str]) -> None:
        lv = self.query_one("#results", ListView)
        lv.clear()
        for path in paths:
            item = ListItem(Label(path))
            item._file_path = path          # store path directly on the item
            lv.append(item)

    @on(Input.Changed, "#search")
    def on_search_changed(self, event: Input.Changed) -> None:
        query = event.value.strip().lower()
        if not query:
            matches = self.all_files[:200]
        else:
            matches = [
                f for f in self.all_files
                if query in f.lower()
            ][:200]
        self._populate_list(matches)

    @on(Input.Submitted, "#search")
    def on_search_submitted(self, event: Input.Submitted) -> None:
        # Move focus to the list when Enter is pressed in search
        lv = self.query_one("#results", ListView)
        lv.focus()

    @on(ListView.Selected, "#results")
    def on_file_selected(self, event: ListView.Selected) -> None:
        file_path = getattr(event.item, "_file_path", None)
        if file_path:
            self.selected_file = str(self.root / file_path)
            self.exit()

    def action_quit_no_select(self) -> None:
        self.exit()


# ─────────────────────────────────────────────
# Editor (CLI Mode)
# ─────────────────────────────────────────────
def editor(file_path: str) -> None:
    path = Path(file_path)

    print()
    print("=" * 50)
    print("  EDIT MODE")
    print(f"  FILE: {file_path}")
    print("=" * 50)
    print()

    # Ask for mode
    while True:
        print("Select mode:")
        print("  1) Overwrite file")
        print("  2) Append to file")
        choice = input("Enter choice [1/2]: ").strip()
        if choice in ("1", "2"):
            break
        print("  ⚠  Invalid choice. Please enter 1 or 2.\n")

    mode = "w" if choice == "1" else "a"

    # Safety confirmation for overwrite
    if mode == "w" and path.exists():
        confirm = input(f"\n⚠  '{path.name}' already exists. Overwrite? [y/N]: ").strip().lower()
        if confirm != "y":
            print("  Cancelled. No changes made.")
            return

    # Multiline input
    print()
    print("─" * 50)
    print("  Type your content line by line.")
    print("  Enter  :done  on a new line to save and exit.")
    print("─" * 50)
    print()

    lines: list[str] = []
    try:
        while True:
            line = input()
            if line == ":done":
                break
            lines.append(line)
    except (EOFError, KeyboardInterrupt):
        print("\n  Interrupted. No changes made.")
        return

    content = "\n".join(lines)
    if lines:
        content += "\n"

    # Ensure directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    # Write file
    with open(path, mode, encoding="utf-8") as f:
        f.write(content)

    action = "overwritten" if mode == "w" else "appended"
    print()
    print(f"  ✅  File {action} successfully: {file_path}")
    print()


# ─────────────────────────────────────────────
# Main Entrypoint
# ─────────────────────────────────────────────
def main() -> None:
    print()
    print("  ⚡ Terminal File Picker + Editor")
    print()

    # Ask for root directory
    raw = input("Root directory [. for current]: ").strip()
    if not raw:
        raw = "."

    root = Path(raw).expanduser().resolve()

    if not root.exists():
        print(f"  ❌  Directory not found: {root}")
        sys.exit(1)

    if not root.is_dir():
        print(f"  ❌  Not a directory: {root}")
        sys.exit(1)

    print(f"\n  Scanning: {root}\n")

    # Launch Textual TUI
    app = FilePicker(root=root)
    app.run()

    selected = app.selected_file

    if not selected:
        print("\n  No file selected. Exiting.")
        sys.exit(0)

    while True:
        # Launch editor
        editor(selected)

        print()
        cont = input("  Pick another file? [y/N]: ").strip().lower()
        if cont != "y":
            print("  Goodbye! 👋\n")
            break

        # Re-launch picker
        app = FilePicker(root=root)
        app.run()
        selected = app.selected_file

        if not selected:
            print("\n  No file selected. Exiting.")
            break


if __name__ == "__main__":
    main()
