"""Typed exceptions for the HeroBrain SDK.

Hierarchy mirrors mem0's exception design with HTTP-status-aware factory.
"""

from __future__ import annotations
from typing import Any, Dict, Optional


class HeroBrainError(Exception):
    """Base exception for all HeroBrain API errors."""

    def __init__(
        self,
        message: str,
        status: int = 0,
        body: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.body = body


class HeroBrainAuthError(HeroBrainError):
    """401 / 403 — invalid or missing credentials."""


class HeroBrainNotFoundError(HeroBrainError):
    """404 — resource does not exist."""


class HeroBrainValidationError(HeroBrainError):
    """400 — bad request / validation failure."""


class HeroBrainRateLimitError(HeroBrainError):
    """429 — rate or usage limit exceeded."""

    def __init__(self, message: str, status: int = 429, body: Optional[Any] = None, retry_after: Optional[int] = None):
        super().__init__(message, status, body)
        self.retry_after = retry_after


_STATUS_MAP: Dict[int, type] = {
    400: HeroBrainValidationError,
    401: HeroBrainAuthError,
    403: HeroBrainAuthError,
    404: HeroBrainNotFoundError,
    429: HeroBrainRateLimitError,
}


def exception_from_response(status: int, text: str, body: Optional[Any] = None) -> HeroBrainError:
    cls = _STATUS_MAP.get(status, HeroBrainError)
    msg = text or f"Request failed with status {status}"
    if isinstance(body, dict) and "error" in body:
        msg = str(body["error"])
    return cls(msg, status, body)
