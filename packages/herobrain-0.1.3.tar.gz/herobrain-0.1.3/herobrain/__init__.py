"""HeroBrain — AI memory for every app."""

from herobrain.client import HeroBrainMemory, AsyncHeroBrainMemory
from herobrain.exceptions import (
    HeroBrainError,
    HeroBrainAuthError,
    HeroBrainNotFoundError,
    HeroBrainRateLimitError,
    HeroBrainValidationError,
)

__version__ = "0.1.1"
VERSION = __version__

__all__ = [
    "HeroBrainMemory",
    "AsyncHeroBrainMemory",
    "HeroBrainError",
    "HeroBrainAuthError",
    "HeroBrainNotFoundError",
    "HeroBrainRateLimitError",
    "HeroBrainValidationError",
]
