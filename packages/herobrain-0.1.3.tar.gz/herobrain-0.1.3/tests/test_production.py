"""Comprehensive production test for the HeroBrain Python SDK.

Exercises every public method against the live API.
"""

import os
import time
import json
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from herobrain import HeroBrainMemory, HeroBrainError, HeroBrainNotFoundError

API_KEY = os.environ.get("HEROBRAIN_API_KEY", "")
BASE = os.environ.get("HEROBRAIN_URL", "https://herobrain.app")

if not API_KEY:
    print("ERROR: Set HEROBRAIN_API_KEY environment variable")
    sys.exit(1)

passed = 0
failed = 0
errors = []

def test(name, fn):
    global passed, failed
    try:
        fn()
        print(f"  PASS  {name}")
        passed += 1
    except Exception as e:
        print(f"  FAIL  {name}: {e}")
        failed += 1
        errors.append((name, str(e)))

m = HeroBrainMemory(api_key=API_KEY, base_url=BASE)

# ── Health ──────────────────────────────────────────────────
print("=== Health ===")
def t_health():
    h = m.health()
    assert h["status"] == "healthy", f"expected healthy, got {h['status']}"
    assert h["services"]["postgres"] is True
    assert h["services"]["qdrant"] is True
    assert h["services"]["redis"] is True
test("health check", t_health)

# ── Memory CRUD ─────────────────────────────────────────────
print("\n=== Memory CRUD ===")
created_id = None

def t_add():
    global created_id
    ts = int(time.time())
    results = m.add(
        f"SDK test {ts}: python developer who uses neovim and tmux",
        type="preference",
        importance=0.9,
        agent_id="sdk-test-agent",
        session_id="sdk-test-session",
        run_id="sdk-test-run",
    )
    assert len(results) >= 1, f"expected >=1 memory, got {len(results)}"
    created_id = results[0]["id"]
    assert results[0]["content"], "content should not be empty"
test("add memory (with scoping)", t_add)

def t_add_ttl():
    import uuid
    uid = uuid.uuid4().hex[:8]
    results = m.add(
        f"Expiring memo {uid}: the kangaroo jumped over the xylophone at sunset",
        expires_at="2026-04-05T00:00:00Z",
        agent_id="sdk-test-agent",
    )
    assert len(results) >= 1, f"expected >=1 memory, got {len(results)}: {results}"
test("add memory (with TTL)", t_add_ttl)

def t_add_async():
    results = m.add("Async SDK test: background task", async_mode=True)
    assert len(results) == 1
    assert results[0].get("status") == "accepted"
test("add memory (async 202)", t_add_async)

def t_get():
    mem = m.get(created_id)
    assert mem["id"] == created_id
    assert "content" in mem
    assert mem.get("agentId") == "sdk-test-agent"
    assert mem.get("sessionId") == "sdk-test-session"
    assert mem.get("runId") == "sdk-test-run"
test("get memory by ID", t_get)

def t_update():
    mem = m.update(created_id, content="Updated: senior python dev using neovim + tmux")
    assert "neovim" in mem["content"].lower() or "tmux" in mem["content"].lower()
test("update memory", t_update)

def t_history():
    hist = m.history(created_id)
    assert len(hist) >= 2, f"expected >=2 history entries (ADD+UPDATE), got {len(hist)}"
    actions = [h["action"] for h in hist]
    assert "ADD" in actions
    assert "UPDATE" in actions
test("memory history", t_history)

def t_delete():
    m.delete(created_id)
test("delete memory", t_delete)

def t_verify_deleted():
    try:
        m.get(created_id)
        raise AssertionError("expected 404 after delete")
    except HeroBrainNotFoundError:
        pass
    except HeroBrainError as e:
        if e.status != 404:
            raise
test("verify deleted (404)", t_verify_deleted)

# ── Search ──────────────────────────────────────────────────
print("\n=== Search ===")

def t_search():
    results = m.search("python neovim", limit=5)
    assert isinstance(results, list)
test("search (unscoped)", t_search)

def t_search_scoped():
    results = m.search("neovim", agent_id="sdk-test-agent", limit=5)
    assert isinstance(results, list)
test("search (agent_id scoped)", t_search_scoped)

def t_search_empty():
    results = m.search("neovim", agent_id="nonexistent-agent-xyz", limit=5)
    assert len(results) == 0, f"expected 0 results for nonexistent agent, got {len(results)}"
test("search (wrong agent_id = 0 results)", t_search_empty)

# ── List ────────────────────────────────────────────────────
print("\n=== List ===")

def t_list():
    mems = m.list(limit=5)
    assert isinstance(mems, list)
    assert len(mems) > 0, "expected at least 1 memory in the tenant"
test("list memories", t_list)

def t_list_scoped():
    mems = m.list(agent_id="sdk-test-agent", limit=5)
    assert isinstance(mems, list)
test("list (agent_id filter)", t_list_scoped)

def t_list_type():
    mems = m.list(type="preference", limit=5)
    assert isinstance(mems, list)
    for mem in mems:
        assert mem["type"] == "preference", f"expected preference, got {mem['type']}"
test("list (type filter)", t_list_type)

# ── Chat ────────────────────────────────────────────────────
print("\n=== Chat ===")

def t_chat():
    resp = m.chat("What programming tools do I use?")
    assert "response" in resp, f"missing 'response' key: {list(resp.keys())}"
    assert len(resp["response"]) > 10, "response too short"
    conv_id = resp.get("conversation_id") or resp.get("conversationId")
    assert conv_id, "missing conversation_id"
test("chat (non-streaming)", t_chat)

def t_chat_stream():
    chunks = list(m.chat_stream("Tell me a one-sentence fact about memory."))
    assert len(chunks) > 0, "expected at least 1 SSE chunk"
    has_text = any(c.get("type") == "text" for c in chunks)
    assert has_text, f"no text chunks found, types: {[c.get('type') for c in chunks]}"
test("chat (SSE streaming)", t_chat_stream)

# ── Conversations ───────────────────────────────────────────
print("\n=== Conversations ===")

def t_conversations_list():
    convs = m.conversations(limit=5)
    assert isinstance(convs, list)
    assert len(convs) > 0
test("list conversations", t_conversations_list)

def t_conversation_get():
    convs = m.conversations(limit=1)
    if convs:
        detail = m.conversation(convs[0]["id"])
        assert "messages" in detail
test("get conversation detail", t_conversation_get)

# ── Graph ───────────────────────────────────────────────────
print("\n=== Graph ===")

def t_graph_search():
    results = m.graph_search("python developer", limit=5)
    assert isinstance(results, list)
test("graph search", t_graph_search)

def t_graph_all():
    results = m.graph(limit=10)
    assert isinstance(results, list)
test("graph list all", t_graph_all)

# ── API Keys ────────────────────────────────────────────────
print("\n=== API Keys ===")
test_key_id = None

def t_create_key():
    global test_key_id
    resp = m.create_key(name="sdk-test-key")
    assert "key" in resp, f"missing 'key': {list(resp.keys())}"
    assert resp["key"].startswith("hb_")
    test_key_id = resp["id"]
test("create API key", t_create_key)

def t_list_keys():
    keys = m.keys()
    assert isinstance(keys, list)
    assert len(keys) >= 2, f"expected >=2 keys (default + test), got {len(keys)}"
test("list API keys", t_list_keys)

def t_revoke_key():
    m.revoke_key(test_key_id)
    keys = m.keys()
    ids = [k["id"] for k in keys]
    assert test_key_id not in ids, "key should be revoked"
test("revoke API key", t_revoke_key)

# ── Stats ───────────────────────────────────────────────────
print("\n=== Stats ===")

def t_stats():
    s = m.stats()
    assert "memoryCount" in s
    assert isinstance(s["memoryCount"], int)
test("stats", t_stats)

# ── Billing ─────────────────────────────────────────────────
print("\n=== Billing ===")

def t_usage():
    u = m.usage()
    assert "plan" in u
    assert "memories" in u
    assert "searches" in u
test("usage", t_usage)

def t_plans():
    p = m.plans()
    assert "plans" in p
    names = [plan["name"] for plan in p["plans"]]
    assert "Free" in names
test("plans", t_plans)

# ── Error handling ──────────────────────────────────────────
print("\n=== Error Handling ===")

def t_404():
    try:
        m.get("00000000-0000-0000-0000-000000000000")
        raise AssertionError("expected error")
    except HeroBrainError as e:
        assert e.status == 404, f"expected 404, got {e.status}"
test("404 raises HeroBrainError", t_404)

def t_bad_auth():
    bad = HeroBrainMemory(api_key="hb_live_invalid_key_xxxxx", base_url=BASE)
    try:
        bad.health()  # health doesn't need auth
        bad.list()     # this needs auth
        raise AssertionError("expected auth error")
    except HeroBrainError as e:
        assert e.status in (401, 403), f"expected 401/403, got {e.status}"
    finally:
        bad.close()
test("bad auth raises HeroBrainAuthError", t_bad_auth)

m.close()

# ── Summary ─────────────────────────────────────────────────
print(f"\n{'='*50}")
print(f"RESULTS: {passed} passed, {failed} failed out of {passed+failed} tests")
if errors:
    print("\nFailed tests:")
    for name, err in errors:
        print(f"  - {name}: {err}")
print(f"{'='*50}")
sys.exit(1 if failed else 0)
