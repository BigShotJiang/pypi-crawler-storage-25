"""Tests for gri-terrain package."""
