"""Tests for GeoTiffSource.

Test data: Downsampled Copernicus tile covering lat 39-40, lon -105 to -104
(Colorado, Denver area). 120x120 pixels, ~1km resolution.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from gri_terrain.sources.geotiff import GeoTiffSource

# Path to test data directory
TEST_DATA_DIR = Path(__file__).parent.parent / "data" / "geotiff"

# Test tile file (downsampled from GLO-30)
TEST_TILE = TEST_DATA_DIR / "test_tile_N39_W105.tif"


@pytest.fixture
def geotiff_source_dir() -> GeoTiffSource:
    """Create GeoTiffSource pointing to test data directory."""
    return GeoTiffSource(TEST_DATA_DIR)


@pytest.fixture
def geotiff_source_file() -> GeoTiffSource:
    """Create GeoTiffSource pointing to single test file."""
    return GeoTiffSource(TEST_TILE)


def test_init_creates_source_from_valid_directory() -> None:
    """GeoTiffSource initializes successfully with valid directory."""
    source = GeoTiffSource(TEST_DATA_DIR)
    assert source._path == TEST_DATA_DIR
    assert "GeoTIFF" in source.name


def test_init_creates_source_from_valid_file() -> None:
    """GeoTiffSource initializes successfully with valid GeoTIFF file."""
    source = GeoTiffSource(TEST_TILE)
    assert source._path == TEST_TILE
    assert "GeoTIFF" in source.name


def test_init_raises_for_nonexistent_file() -> None:
    """GeoTiffSource raises FileNotFoundError for nonexistent .tif file."""
    with pytest.raises(FileNotFoundError):
        GeoTiffSource("/nonexistent/path/file.tif")


def test_init_creates_directory_if_not_exists(tmp_path: Path) -> None:
    """GeoTiffSource creates directory if path doesn't exist (directory mode)."""
    new_dir = tmp_path / "new_geotiff_dir"
    source = GeoTiffSource(new_dir)
    assert new_dir.exists()
    assert source._path == new_dir


def test_get_altitude_returns_reasonable_elevation_for_denver(
    geotiff_source_dir: GeoTiffSource,
) -> None:
    """Get altitude for Denver returns value near 1600m (Mile High City)."""
    lat = np.array([39.7392])
    lon = np.array([-104.9903])

    alt = geotiff_source_dir.get_altitude(lat, lon)

    # Denver is ~1609m; allow tolerance for interpolation differences
    assert alt.shape == (1,)
    assert 1400 < alt[0] < 1800


def test_get_altitude_returns_nan_for_uncovered_location(
    geotiff_source_dir: GeoTiffSource,
) -> None:
    """Points outside GeoTIFF coverage return NaN."""
    # New York - not in our test data
    lat = np.array([40.7])
    lon = np.array([-74.0])

    alt = geotiff_source_dir.get_altitude(lat, lon)

    assert np.isnan(alt[0])


def test_get_altitude_handles_multiple_points(
    geotiff_source_dir: GeoTiffSource,
) -> None:
    """Get altitude works for multiple points in same tile."""
    lats = np.array([39.2, 39.5, 39.8])
    lons = np.array([-104.8, -104.5, -104.2])

    alts = geotiff_source_dir.get_altitude(lats, lons)

    assert alts.shape == (3,)
    assert all(~np.isnan(alts))
    # Colorado elevations should be 1000-4000m
    assert all(1000 < alt < 4000 for alt in alts)


@pytest.mark.parametrize("interpolation", ["nearest", "bilinear", "bicubic"])
def test_get_altitude_supports_interpolation_methods(
    geotiff_source_dir: GeoTiffSource,
    interpolation: str,
) -> None:
    """All interpolation methods return valid elevations."""
    lat = np.array([39.5])
    lon = np.array([-104.5])

    alt = geotiff_source_dir.get_altitude(lat, lon, interpolation=interpolation)

    assert ~np.isnan(alt[0])
    assert 1000 < alt[0] < 4000


def test_get_altitude_invalid_interpolation_raises(
    geotiff_source_dir: GeoTiffSource,
) -> None:
    """Invalid interpolation method raises ValueError."""
    lat = np.array([39.5])
    lon = np.array([-104.5])

    with pytest.raises(ValueError, match="interpolation must be"):
        geotiff_source_dir.get_altitude(lat, lon, interpolation="invalid")


def test_single_file_mode_works(geotiff_source_file: GeoTiffSource) -> None:
    """GeoTiffSource works when initialized with single file."""
    lat = np.array([39.7392])
    lon = np.array([-104.9903])

    alt = geotiff_source_file.get_altitude(lat, lon)

    assert alt.shape == (1,)
    assert 1400 < alt[0] < 1800


def test_name_property_shows_file_count(geotiff_source_dir: GeoTiffSource) -> None:
    """Name property shows number of indexed files."""
    name = geotiff_source_dir.name
    assert "GeoTIFF" in name
    assert "1 files" in name


def test_clear_cache_removes_cached_tiles(geotiff_source_dir: GeoTiffSource) -> None:
    """clear_cache() removes all cached tile data."""
    # Load a tile into cache
    lat = np.array([39.5])
    lon = np.array([-104.5])
    geotiff_source_dir.get_altitude(lat, lon)

    assert geotiff_source_dir._cache_bytes > 0

    geotiff_source_dir.clear_cache()

    assert geotiff_source_dir._cache_bytes == 0
    assert len(geotiff_source_dir._tile_cache) == 0
