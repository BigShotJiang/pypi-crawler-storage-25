"""Tests for Copernicus DEM source.

Uses mocked downloads to avoid network calls, with test data from the
test/data/geotiff/ directory containing a downsampled Copernicus tile.
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import patch

import numpy as np
import pytest

from gri_terrain.sources import CopernicusSource

if TYPE_CHECKING:
    from collections.abc import Callable, Generator

# Path to test data directory with downsampled Copernicus tile
TEST_DATA_DIR = Path(__file__).parent.parent / "data" / "geotiff"

# Test tile file (N39 W105 - Denver area, downsampled to 120x120)
TEST_TILE = TEST_DATA_DIR / "test_tile_N39_W105.tif"


def _mock_download(
    test_tile: Path,
) -> Callable[[CopernicusSource, str, Path], None]:
    """Create a mock _download_tile that copies from test data."""

    def _download_tile(_self: CopernicusSource, _url: str, tile_path: Path) -> None:
        # Copy test tile to the requested path
        shutil.copy(test_tile, tile_path)

    return _download_tile


@pytest.fixture
def copernicus_source(tmp_path: Path) -> Generator[CopernicusSource]:
    """Create CopernicusSource with mocked download using temp cache."""
    with patch.object(
        CopernicusSource,
        "_download_tile",
        _mock_download(TEST_TILE),
    ):
        source = CopernicusSource(resolution="30m", cache_dir=tmp_path / "cache")
        yield source


def test_invalid_resolution_raises(tmp_path: Path) -> None:
    """Invalid resolution raises ValueError."""
    with pytest.raises(ValueError, match="resolution must be"):
        CopernicusSource(resolution="10m", cache_dir=tmp_path)


def test_name_property(tmp_path: Path) -> None:
    """Name property returns appropriate string."""
    source_30 = CopernicusSource(resolution="30m", cache_dir=tmp_path / "glo30")
    source_90 = CopernicusSource(resolution="90m", cache_dir=tmp_path / "glo90")

    assert source_30.name == "Copernicus GLO-30"
    assert source_90.name == "Copernicus GLO-90"


def test_get_altitude_returns_reasonable_elevation_for_denver(
    copernicus_source: CopernicusSource,
) -> None:
    """Get altitude for Denver returns value near 1600m."""
    lat = np.array([39.7392])
    lon = np.array([-104.9903])

    alt = copernicus_source.get_altitude(lat, lon)

    # Denver is ~1609m
    assert alt.shape == (1,)
    assert 1400 < alt[0] < 1800


def test_get_altitude_handles_multiple_points(
    copernicus_source: CopernicusSource,
) -> None:
    """Get altitude works for multiple points in same tile."""
    lats = np.array([39.2, 39.5, 39.8])
    lons = np.array([-104.8, -104.5, -104.2])

    alts = copernicus_source.get_altitude(lats, lons)

    assert alts.shape == (3,)
    assert all(~np.isnan(alts))
    # Colorado elevations should be 1000-4000m
    assert all(1000 < alt < 4000 for alt in alts)


@pytest.mark.parametrize("interpolation", ["nearest", "bilinear", "bicubic"])
def test_get_altitude_supports_interpolation_methods(
    copernicus_source: CopernicusSource,
    interpolation: str,
) -> None:
    """All interpolation methods return valid elevations."""
    lat = np.array([39.5])
    lon = np.array([-104.5])

    alt = copernicus_source.get_altitude(lat, lon, interpolation=interpolation)

    assert ~np.isnan(alt[0])
    assert 1000 < alt[0] < 4000


def test_tile_cached_after_download(tmp_path: Path) -> None:
    """Downloaded tile is cached to disk."""
    cache_dir = tmp_path / "cache"

    with patch.object(
        CopernicusSource,
        "_download_tile",
        _mock_download(TEST_TILE),
    ):
        source = CopernicusSource(resolution="30m", cache_dir=cache_dir)

        # Query triggers download
        lat = np.array([39.5])
        lon = np.array([-104.5])
        source.get_altitude(lat, lon)

    # Check that a tile file exists in cache
    cached_files = list(cache_dir.glob("*.tif"))
    assert len(cached_files) == 1


def test_uses_cached_tile_on_second_query(tmp_path: Path) -> None:
    """Second query uses cached tile without re-downloading."""
    cache_dir = tmp_path / "cache"
    download_count = 0

    def counting_download(
        _self: CopernicusSource,
        _url: str,
        tile_path: Path,
    ) -> None:
        nonlocal download_count
        download_count += 1
        shutil.copy(TEST_TILE, tile_path)

    with patch.object(CopernicusSource, "_download_tile", counting_download):
        source = CopernicusSource(resolution="30m", cache_dir=cache_dir)

        lat = np.array([39.5])
        lon = np.array([-104.5])

        # First query downloads
        source.get_altitude(lat, lon)
        assert download_count == 1

        # Clear memory cache to force disk lookup
        source.clear_cache()

        # Second query should use disk cache
        source.get_altitude(lat, lon)
        assert download_count == 1  # No new download
