"""Tests for terrain source implementations."""
