"""Tests for DTEDSource using real DTED Level 0 data.

Test data: w105/n39.dt0 covering lat 39-40, lon -105 to -104 (Colorado, Denver area).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from gri_terrain.sources.dted import DTEDSource

# Path to test data directory (in test/data, not test/sources/data)
TEST_DATA_DIR = Path(__file__).parent.parent / "data" / "dted"


@pytest.fixture
def dted_source() -> DTEDSource:
    """Create DTEDSource pointing to test data."""
    return DTEDSource(TEST_DATA_DIR)


def test_init_creates_source_from_valid_directory() -> None:
    """DTEDSource initializes successfully with valid DTED directory."""
    source = DTEDSource(TEST_DATA_DIR)
    assert source._path == TEST_DATA_DIR
    assert source.name == "DTED"


def test_init_raises_for_nonexistent_path() -> None:
    """DTEDSource raises FileNotFoundError for nonexistent path."""
    with pytest.raises(FileNotFoundError):
        DTEDSource("/nonexistent/path")


def test_get_altitude_returns_reasonable_elevation_for_denver(
    dted_source: DTEDSource,
) -> None:
    """Get altitude for Denver returns value near 1600m (Mile High City)."""
    lat = np.array([39.7392])
    lon = np.array([-104.9903])

    alt = dted_source.get_altitude(lat, lon)

    # Denver is ~1609m; DTED Level 0 is coarse so allow wide tolerance
    assert alt.shape == (1,)
    assert 1100 < alt[0] < 2100


def test_get_altitude_returns_nan_for_uncovered_location(
    dted_source: DTEDSource,
) -> None:
    """Points outside DTED coverage return NaN."""
    # New York - not in our test data
    lat = np.array([40.7])
    lon = np.array([-74.0])

    alt = dted_source.get_altitude(lat, lon)

    assert np.isnan(alt[0])


def test_get_altitude_handles_multiple_points(dted_source: DTEDSource) -> None:
    """Get altitude works for multiple points in same tile."""
    lats = np.array([39.2, 39.5, 39.8])
    lons = np.array([-104.8, -104.5, -104.2])

    alts = dted_source.get_altitude(lats, lons)

    assert alts.shape == (3,)
    assert all(~np.isnan(alts))
    # Colorado elevations should be 1000-4000m
    assert all(1000 < alt < 4000 for alt in alts)


@pytest.mark.parametrize("interpolation", ["nearest", "bilinear", "bicubic"])
def test_get_altitude_supports_interpolation_methods(
    dted_source: DTEDSource,
    interpolation: str,
) -> None:
    """All interpolation methods return valid elevations."""
    lat = np.array([39.5])
    lon = np.array([-104.5])

    alt = dted_source.get_altitude(lat, lon, interpolation=interpolation)

    assert ~np.isnan(alt[0])
    assert 1000 < alt[0] < 4000
