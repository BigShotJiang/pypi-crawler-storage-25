#!/usr/bin/env python3
"""Download Copernicus DEM data (GLO-30 and/or GLO-90) from AWS S3.

This script downloads Cloud Optimized GeoTIFF tiles from the Copernicus DEM
datasets hosted on AWS S3. No AWS account is required.

Usage:
    python download_copernicus.py --dataset glo30 --output-dir ./data/copernicus
    python download_copernicus.py --dataset glo90 --output-dir ./data/copernicus
    python download_copernicus.py --dataset both --output-dir ./data/copernicus

The script supports:
    - Resumable downloads (skips existing files)
    - Parallel downloads for speed
    - Progress reporting
    - Optional bounding box filtering (e.g., for Colorado only)
"""

import argparse
import logging
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import NamedTuple

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# AWS S3 bucket URLs (public, no auth required)
COPERNICUS_30M_BASE = "https://copernicus-dem-30m.s3.amazonaws.com"
COPERNICUS_90M_BASE = "https://copernicus-dem-90m.s3.amazonaws.com"


class BoundingBox(NamedTuple):
    """Geographic bounding box in degrees."""

    min_lat: float
    max_lat: float
    min_lon: float
    max_lon: float


# Predefined bounding boxes for common regions
REGIONS: dict[str, BoundingBox] = {
    "colorado": BoundingBox(37, 41, -109, -102),
    "conus": BoundingBox(24, 50, -125, -66),
    "world": BoundingBox(-90, 90, -180, 180),
}


def fetch_tile_list(base_url: str) -> list[str]:
    """Fetch the list of available tiles from the S3 bucket.

    Args:
        base_url: Base URL of the Copernicus S3 bucket.

    Returns:
        List of tile names (directory prefixes).
    """
    tile_list_url = f"{base_url}/tileList.txt"
    logger.info("Fetching tile list from %s", tile_list_url)

    with urllib.request.urlopen(tile_list_url, timeout=30) as response:  # noqa: S310
        content = response.read().decode("utf-8")

    tiles = [line.strip() for line in content.splitlines() if line.strip()]
    logger.info("Found %d tiles", len(tiles))
    return tiles


def parse_tile_coords(tile_name: str) -> tuple[float, float]:
    """Parse latitude and longitude from a Copernicus tile name.

    Tile names follow the pattern:
        Copernicus_DSM_COG_{10|30}_{N|S}{lat}_00_{E|W}{lon}_00_DEM

    Args:
        tile_name: The tile directory name.

    Returns:
        Tuple of (latitude, longitude) of the tile's southwest corner.
    """
    # Example: Copernicus_DSM_COG_10_N39_00_W106_00_DEM
    parts = tile_name.split("_")

    # Find lat/lon parts (N/S followed by number, E/W followed by number)
    lat_part = parts[4]  # e.g., "N39"
    lon_part = parts[6]  # e.g., "W106"

    lat_sign = 1 if lat_part[0] == "N" else -1
    lat = lat_sign * int(lat_part[1:])

    lon_sign = 1 if lon_part[0] == "E" else -1
    lon = lon_sign * int(lon_part[1:])

    return lat, lon


def filter_tiles_by_bbox(
    tiles: list[str],
    bbox: BoundingBox | None,
) -> list[str]:
    """Filter tiles to only those within a bounding box.

    Args:
        tiles: List of tile names.
        bbox: Bounding box to filter by, or None for all tiles.

    Returns:
        Filtered list of tile names.
    """
    if bbox is None:
        return tiles

    filtered = []
    for tile in tiles:
        try:
            lat, lon = parse_tile_coords(tile)
            # Tile covers [lat, lat+1) x [lon, lon+1)
            if (
                lat >= bbox.min_lat - 1
                and lat <= bbox.max_lat
                and lon >= bbox.min_lon - 1
                and lon <= bbox.max_lon
            ):
                filtered.append(tile)
        except (IndexError, ValueError) as e:
            logger.warning("Could not parse tile name %s: %s", tile, e)

    logger.info(
        "Filtered to %d tiles within bbox (lat: %s to %s, lon: %s to %s)",
        len(filtered),
        bbox.min_lat,
        bbox.max_lat,
        bbox.min_lon,
        bbox.max_lon,
    )
    return filtered


def download_tile(
    tile_name: str,
    base_url: str,
    output_dir: Path,
    *,
    overwrite: bool = False,
) -> tuple[str, bool, str]:
    """Download a single tile.

    Args:
        tile_name: Name of the tile (directory prefix).
        base_url: Base URL of the S3 bucket.
        output_dir: Local directory to save files.
        overwrite: If True, re-download existing files.

    Returns:
        Tuple of (tile_name, success, message).
    """
    # Construct the full URL and local path
    tif_filename = f"{tile_name}.tif"
    url = f"{base_url}/{tile_name}/{tif_filename}"
    local_path = output_dir / tif_filename

    # Skip if already exists
    if local_path.exists() and not overwrite:
        return tile_name, True, "skipped (exists)"

    try:
        # Create a request with a reasonable timeout
        request = urllib.request.Request(url)  # noqa: S310
        with urllib.request.urlopen(request, timeout=120) as response:  # noqa: S310
            content = response.read()

        # Write to file
        local_path.parent.mkdir(parents=True, exist_ok=True)
        local_path.write_bytes(content)

    except OSError as e:
        return tile_name, False, f"failed: {e}"

    else:
        size_mb = len(content) / (1024 * 1024)
        return tile_name, True, f"downloaded ({size_mb:.1f} MB)"


def download_dataset(
    dataset: str,
    output_dir: Path,
    bbox: BoundingBox | None = None,
    max_workers: int = 8,
    *,
    overwrite: bool = False,
) -> tuple[int, int]:
    """Download a Copernicus DEM dataset.

    Args:
        dataset: Either "glo30" or "glo90".
        output_dir: Base output directory.
        bbox: Optional bounding box to filter tiles.
        max_workers: Number of parallel download threads.
        overwrite: If True, re-download existing files.

    Returns:
        Tuple of (successful_count, failed_count).
    """
    if dataset == "glo30":
        base_url = COPERNICUS_30M_BASE
        subdir = "glo30"
    elif dataset == "glo90":
        base_url = COPERNICUS_90M_BASE
        subdir = "glo90"
    else:
        raise ValueError(f"Unknown dataset: {dataset}")

    # Create output directory
    dataset_dir = output_dir / subdir
    dataset_dir.mkdir(parents=True, exist_ok=True)

    # Fetch and filter tile list
    tiles = fetch_tile_list(base_url)
    tiles = filter_tiles_by_bbox(tiles, bbox)

    if not tiles:
        logger.warning("No tiles to download")
        return 0, 0

    logger.info(
        "Starting download of %d tiles to %s (workers: %d)",
        len(tiles),
        dataset_dir,
        max_workers,
    )

    successful = 0
    failed = 0
    failed_tiles = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(
                download_tile,
                tile,
                base_url,
                dataset_dir,
                overwrite=overwrite,
            ): tile
            for tile in tiles
        }

        for i, future in enumerate(as_completed(futures), 1):
            tile_name, success, message = future.result()
            if success:
                successful += 1
                if "downloaded" in message:
                    logger.info("[%d/%d] %s: %s", i, len(tiles), tile_name, message)
            else:
                failed += 1
                failed_tiles.append(tile_name)
                logger.error("[%d/%d] %s: %s", i, len(tiles), tile_name, message)

            # Progress update every 100 tiles
            if i % 100 == 0:
                logger.info(
                    "Progress: %d/%d (%.1f%%)",
                    i,
                    len(tiles),
                    100 * i / len(tiles),
                )

    logger.info(
        "Download complete: %d successful, %d failed",
        successful,
        failed,
    )

    if failed_tiles:
        failed_file = dataset_dir / "failed_tiles.txt"
        failed_file.write_text("\n".join(failed_tiles))
        logger.info("Failed tiles written to %s", failed_file)

    return successful, failed


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Download Copernicus DEM data from AWS S3",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Download all GLO-30 data worldwide (~170-280 GB)
    python download_copernicus.py --dataset glo30 --output-dir ./data/copernicus

    # Download GLO-90 for Colorado only
    python download_copernicus.py --dataset glo90 --output-dir ./data --region colorado

    # Download both datasets with custom bounding box
    python download_copernicus.py --dataset both --output-dir ./data \\
        --bbox 37 41 -109 -102

Available regions: colorado, conus, world
        """,
    )

    parser.add_argument(
        "--dataset",
        choices=["glo30", "glo90", "both"],
        required=True,
        help="Dataset to download",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="Output directory for downloaded files",
    )
    parser.add_argument(
        "--region",
        choices=list(REGIONS.keys()),
        help="Predefined region to download",
    )
    parser.add_argument(
        "--bbox",
        type=float,
        nargs=4,
        metavar=("MIN_LAT", "MAX_LAT", "MIN_LON", "MAX_LON"),
        help="Custom bounding box (overrides --region)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=8,
        help="Number of parallel download threads (default: 8)",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Re-download existing files",
    )

    args = parser.parse_args()

    # Determine bounding box
    bbox: BoundingBox | None = None
    if args.bbox:
        bbox = BoundingBox(*args.bbox)
    elif args.region:
        bbox = REGIONS[args.region]

    # Download requested datasets
    datasets = ["glo30", "glo90"] if args.dataset == "both" else [args.dataset]

    total_success = 0
    total_failed = 0

    for dataset in datasets:
        logger.info("=" * 60)
        logger.info("Downloading %s dataset", dataset.upper())
        logger.info("=" * 60)

        success, failed = download_dataset(
            dataset=dataset,
            output_dir=args.output_dir,
            bbox=bbox,
            max_workers=args.workers,
            overwrite=args.overwrite,
        )
        total_success += success
        total_failed += failed

    logger.info("=" * 60)
    logger.info(
        "All downloads complete: %d successful, %d failed",
        total_success,
        total_failed,
    )

    return 0 if total_failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
