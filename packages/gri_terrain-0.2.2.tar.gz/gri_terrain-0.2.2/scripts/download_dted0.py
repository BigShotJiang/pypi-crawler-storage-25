#!/usr/bin/env python3
"""Download DTED Level 0 data from GitHub mirror.

This script downloads the complete DTED Level 0 global dataset from the
airsoftnorge/DTED0-World GitHub repository. The dataset is approximately
200-400 MB compressed.

DTED Level 0 has ~900m (30 arc-second) resolution and covers most of the
world's land areas.

Usage:
    python download_dted0.py --output-dir ./data/dted0

The script will:
    1. Download the repository as a ZIP file
    2. Extract the .dt0 files organized by longitude directories
    3. Optionally reorganize into standard DTED directory structure
"""

import argparse
import io
import logging
import sys
import urllib.request
import zipfile
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# GitHub repository URL
DTED0_REPO_ZIP = (
    "https://codeload.github.com/airsoftnorge/DTED0-World/zip/refs/heads/main"
)


def download_with_progress(url: str, desc: str = "Downloading") -> bytes:
    """Download a file with progress reporting.

    Args:
        url: URL to download.
        desc: Description for progress messages.

    Returns:
        Downloaded content as bytes.
    """
    logger.info("%s from %s", desc, url)

    request = urllib.request.Request(url)  # noqa: S310
    request.add_header("User-Agent", "gri-terrain/1.0")

    with urllib.request.urlopen(request, timeout=300) as response:  # noqa: S310
        # Try to get content length for progress
        total_size = response.headers.get("Content-Length")
        if total_size:
            total_size = int(total_size)
            logger.info("Total size: %.1f MB", total_size / (1024 * 1024))

        # Download in chunks
        chunks = []
        downloaded = 0
        chunk_size = 1024 * 1024  # 1 MB chunks

        while True:
            chunk = response.read(chunk_size)
            if not chunk:
                break
            chunks.append(chunk)
            downloaded += len(chunk)

            if total_size:
                pct = 100 * downloaded / total_size
                logger.info(
                    "Progress: %.1f MB / %.1f MB (%.1f%%)",
                    downloaded / (1024 * 1024),
                    total_size / (1024 * 1024),
                    pct,
                )
            else:
                logger.info("Downloaded: %.1f MB", downloaded / (1024 * 1024))

    content = b"".join(chunks)
    logger.info(
        "Download complete: %.1f MB",
        len(content) / (1024 * 1024),
    )
    return content


MIN_DTED_PATH_PARTS = 3  # Expected path format: DTED0-World-main/e000/n00.dt0


def extract_dted_files(
    zip_content: bytes,
    output_dir: Path,
    *,
    organize: bool = True,
) -> int:
    """Extract DTED files from the downloaded ZIP.

    Args:
        zip_content: ZIP file content as bytes.
        output_dir: Directory to extract files to.
        organize: If True, organize into standard DTED structure.

    Returns:
        Number of .dt0 files extracted.
    """
    logger.info("Extracting DTED files to %s", output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    with zipfile.ZipFile(io.BytesIO(zip_content)) as zf:
        # List all files
        all_files = zf.namelist()
        dt0_files = [f for f in all_files if f.endswith(".dt0")]
        logger.info("Found %d .dt0 files in archive", len(dt0_files))

        for filepath in dt0_files:
            # Extract file info
            # Path format: DTED0-World-main/e000/n00.dt0
            parts = Path(filepath).parts

            if len(parts) < MIN_DTED_PATH_PARTS:
                continue

            lon_dir = parts[-2]  # e.g., "e000" or "w001"
            filename = parts[-1]  # e.g., "n00.dt0"

            # Standard DTED structure: dted/e000/n00.dt0, or flat structure
            dest_dir = output_dir / lon_dir if organize else output_dir

            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_path = dest_dir / filename

            # Extract file
            with zf.open(filepath) as src:
                content = src.read()
                dest_path.write_bytes(content)

            count += 1

            if count % 500 == 0:
                logger.info("Extracted %d files...", count)

    logger.info("Extraction complete: %d .dt0 files", count)
    return count


def verify_extraction(output_dir: Path) -> dict[str, int]:
    """Verify the extracted DTED files.

    Args:
        output_dir: Directory containing extracted files.

    Returns:
        Dictionary with verification statistics.
    """
    stats = {
        "total_files": 0,
        "total_size_bytes": 0,
        "lon_dirs": 0,
        "min_size": float("inf"),
        "max_size": 0,
    }

    lon_dirs = [d for d in output_dir.iterdir() if d.is_dir()]
    stats["lon_dirs"] = len(lon_dirs)

    for lon_dir in lon_dirs:
        for dt0_file in lon_dir.glob("*.dt0"):
            size = dt0_file.stat().st_size
            stats["total_files"] += 1
            stats["total_size_bytes"] += size
            stats["min_size"] = min(stats["min_size"], size)
            stats["max_size"] = max(stats["max_size"], size)

    if stats["min_size"] == float("inf"):
        stats["min_size"] = 0

    return stats


def main() -> int:
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Download DTED Level 0 global data from GitHub",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Download to default location
    python download_dted0.py --output-dir ./data/dted0

    # Download without organizing into subdirectories
    python download_dted0.py --output-dir ./data/dted0 --flat

Notes:
    - Download size is approximately 200-400 MB (compressed)
    - Extracted size is approximately 300-500 MB
    - Data source: github.com/airsoftnorge/DTED0-World
        """,
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="Output directory for DTED files",
    )
    parser.add_argument(
        "--flat",
        action="store_true",
        help="Extract all files to a single directory (no subdirs)",
    )
    parser.add_argument(
        "--keep-zip",
        action="store_true",
        help="Keep the downloaded ZIP file",
    )

    args = parser.parse_args()

    try:
        # Download the ZIP file
        logger.info("=" * 60)
        logger.info("Downloading DTED Level 0 data")
        logger.info("=" * 60)

        zip_content = download_with_progress(
            DTED0_REPO_ZIP,
            "Downloading DTED0-World repository",
        )

        # Optionally save the ZIP
        if args.keep_zip:
            zip_path = args.output_dir.parent / "dted0-world.zip"
            zip_path.parent.mkdir(parents=True, exist_ok=True)
            zip_path.write_bytes(zip_content)
            logger.info("ZIP saved to %s", zip_path)

        # Extract files
        logger.info("=" * 60)
        logger.info("Extracting DTED files")
        logger.info("=" * 60)

        count = extract_dted_files(
            zip_content,
            args.output_dir,
            organize=not args.flat,
        )

        # Verify extraction
        logger.info("=" * 60)
        logger.info("Verifying extraction")
        logger.info("=" * 60)

        stats = verify_extraction(args.output_dir)

        logger.info("Verification results:")
        logger.info("  Total files: %d", stats["total_files"])
        logger.info(
            "  Total size: %.1f MB",
            stats["total_size_bytes"] / (1024 * 1024),
        )
        logger.info("  Longitude directories: %d", stats["lon_dirs"])
        logger.info(
            "  File size range: %.1f KB - %.1f KB",
            stats["min_size"] / 1024,
            stats["max_size"] / 1024,
        )

        if stats["total_files"] != count:
            logger.error(
                "Verification mismatch: expected %d, found %d",
                count,
                stats["total_files"],
            )
            return 1

    except Exception:
        logger.exception("Download failed")
        return 1

    else:
        logger.info("All files verified successfully")
        return 0


if __name__ == "__main__":
    sys.exit(main())
