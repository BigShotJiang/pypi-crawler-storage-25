"""Ray-terrain intersection algorithm.

Finds the first intersection point between a ray and terrain surface.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np
from gri_utils.constants import ER_M, PR_M
from gri_utils.conversion import xyz_to_aer, xyz_to_lla
from gri_utils.distance import slant_range

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from gri_terrain.sources import TerrainSource

_log = logging.getLogger(__name__)

# Conservative maximum terrain altitude on Earth (meters above geoid)
# Mount Everest is ~8849m, this provides margin for any elevation model
MAX_TERRAIN_ALT_M = 9000.0

# Conservative minimum terrain altitude on Earth (meters above geoid)
# Dead Sea shore is ~-430m, this provides margin for any depression
MIN_TERRAIN_ALT_M = -500.0

# Minimum norm for direction vector to be considered valid
_MIN_DIRECTION_NORM = 1e-12

# Algorithm constants (not user-configurable)
_MIN_STEP_M = 1.0  # Minimum step size for fine marching
_REFINEMENT_TOLERANCE_M = 1.0  # Binary search tolerance
_MAX_TERRAIN_SLOPE = 1.0  # tan(45 degrees), max assumed terrain slope

# Approximate meters per degree (for tile boundary calculations)
_METERS_PER_DEG_LAT = 111_320.0
_METERS_PER_DEG_LON_EQUATOR = 111_320.0


def _slope_skip_dist(clearance: float, elevation_rad: float) -> float:
    """Compute safe skip distance based on 45-degree max terrain slope.

    Given current clearance above terrain and ray elevation angle, compute
    how far along the ray we can skip before potentially hitting terrain
    that rises at 45 degrees from the current terrain point.

    Args:
        clearance: Current altitude minus terrain altitude (meters).
        elevation_rad: Ray elevation angle in radians (negative = descending).

    Returns:
        Safe skip distance in meters along the ray direction.
    """
    if clearance <= 0:
        return _MIN_STEP_M

    # For descending ray (el < 0):
    # - Ray drops by sin(-el) per meter of travel
    # - Terrain can rise by cos(-el) * tan(45) = cos(-el) per meter horizontal
    # - Horizontal travel per meter along ray is cos(-el)
    # So terrain rises by cos(-el) per meter along ray
    # We intersect when: clearance = travel * (sin(-el) + cos(-el))
    sin_el = np.sin(-elevation_rad)
    cos_el = np.cos(-elevation_rad)

    # Avoid division by zero for horizontal rays
    denominator = sin_el + cos_el * _MAX_TERRAIN_SLOPE
    if denominator < _MIN_DIRECTION_NORM:
        # Nearly horizontal or ascending - use large skip based on clearance
        return clearance / _MAX_TERRAIN_SLOPE

    return clearance / denominator


def _axis_exit_dist(
    pos: float,
    rate: float,
    bound_min: float,
    bound_max: float,
) -> float:
    """Compute distance to exit an axis-aligned boundary."""
    if rate > _MIN_DIRECTION_NORM:
        return (bound_max - pos) / rate
    if rate < -_MIN_DIRECTION_NORM:
        return (bound_min - pos) / rate
    return float("inf")


def _tile_exit_dist(
    lla: tuple[float, float, float],
    dlla_per_m: tuple[float, float, float],
    tile_key: tuple[int, int],
    tile_alt_max: float,
) -> float:
    """Compute distance to exit current tile bounding box.

    Args:
        lla: Current position as (lat, lon, alt).
        dlla_per_m: Rate of LLA change per meter as (dlat, dlon, dalt).
        tile_key: Tile southwest corner as (lat_tile, lon_tile).
        tile_alt_max: Maximum terrain altitude in this tile (meters).

    Returns:
        Distance in meters to exit the tile.
    """
    lat, lon, alt = lla
    dlat, dlon, dalt = dlla_per_m
    tile_lat, tile_lon = tile_key

    d_lat = _axis_exit_dist(lat, dlat, float(tile_lat), float(tile_lat + 1))
    d_lon = _axis_exit_dist(lon, dlon, float(tile_lon), float(tile_lon + 1))

    # Distance to tile's max altitude (only if descending toward it)
    if dalt < -_MIN_DIRECTION_NORM and alt > tile_alt_max:
        d_alt = (tile_alt_max - alt) / dalt
    else:
        d_alt = float("inf")

    return max(_MIN_STEP_M, min(d_lat, d_lon, d_alt))


def ray_terrain(
    terrain: TerrainSource,
    origin_xyz: NDArray[np.floating],
    direction_xyz: NDArray[np.floating],
    *,
    altitude_epsilon_m: float = 0.0,
) -> NDArray[np.floating] | None:
    """Find the first intersection of a ray with terrain.

    Uses adaptive step sizes based on clearance above terrain. When far from
    terrain, takes large steps (up to 500m). When close, takes smaller steps
    (down to 1m) to avoid missing narrow peaks at low grazing angles.

    Step size formula: step = clearance / max_slope (clamped to 1-500m)

    This ensures terrain rising at 45 degrees cannot be "stepped over".

    Args:
        terrain: TerrainSource providing elevation lookups.
        origin_xyz: Ray origin in ECEF coordinates (meters). Shape (3,).
        direction_xyz: Ray direction vector (will be normalized). Shape (3,).
        altitude_epsilon_m: Offset above terrain surface to find intersection.
            0.0 = bare terrain (default).
            10.0 = find where ray passes within 10m of terrain.
            Useful for vegetation canopy, safety margins, or sensor footprints.

    Returns:
        ECEF coordinates of first intersection point (meters), shape (3,),
        or None if no intersection found.

    """
    origin_xyz = np.asarray(origin_xyz, dtype=np.float64)
    direction_xyz = np.asarray(direction_xyz, dtype=np.float64)

    # Normalize direction
    dir_norm = np.linalg.norm(direction_xyz)
    if dir_norm < _MIN_DIRECTION_NORM:
        _log.warning("Ray direction vector is near-zero, cannot compute intersection")
        return None
    direction_xyz = direction_xyz / dir_norm

    start_dist = _get_start_dist(origin_xyz, direction_xyz)
    if start_dist is None:
        return None

    # Adaptive ray march
    return _march(terrain, origin_xyz, direction_xyz, start_dist, altitude_epsilon_m)


def _ellipsoid_position(
    xyz: NDArray[np.floating],
    altitude: float,
) -> float:
    """Check position relative to WGS84 ellipsoid at given altitude.

    Uses the ellipsoid equation: (x/a)^2 + (y/a)^2 + (z/b)^2 = 1
    where a = ER_M + altitude, b = PR_M + altitude.

    Args:
        xyz: ECEF coordinates in meters, shape (3,).
        altitude: Altitude offset from WGS84 surface in meters.

    Returns:
        Value > 1.0 means point is above the altitude surface.
        Value < 1.0 means point is below the altitude surface.
        Value == 1.0 means point is exactly on the surface.
    """
    a = ER_M + altitude
    b = PR_M + altitude
    x, y, z = xyz
    return (x**2 + y**2) / a**2 + z**2 / b**2


def _is_descending(
    origin_xyz: NDArray[np.floating],
    direction_xyz: NDArray[np.floating],
) -> bool:
    """Check if ray is descending (moving toward Earth center).

    Uses radial approximation: ray is descending if direction has negative
    component along the radial (outward) direction from Earth center.

    Args:
        origin_xyz: Ray origin in ECEF coordinates, shape (3,).
        direction_xyz: Normalized ray direction vector, shape (3,).

    Returns:
        True if ray is descending, False if ascending.
    """
    radial = origin_xyz / np.linalg.norm(origin_xyz)
    return float(np.dot(direction_xyz, radial)) < 0


def _get_start_dist(
    origin_xyz: NDArray[np.floating],
    direction_xyz: NDArray[np.floating],
) -> float | None:
    """Compute starting distance along ray for terrain intersection search.

    Determines where to begin ray marching based on the origin's position
    relative to the terrain altitude band (MIN_TERRAIN_ALT_M to MAX_TERRAIN_ALT_M).

    If origin is within the band, starts at distance 0. If outside, calculates
    the slant range to skip ahead to where the ray enters the band. Returns
    None for rays that cannot intersect terrain (e.g., above ceiling and
    ascending, or below floor and descending).

    Args:
        origin_xyz: Ray origin in ECEF coordinates (meters), shape (3,).
        direction_xyz: Normalized ray direction vector, shape (3,).

    Returns:
        Distance along ray to start marching (meters), or None if no
        intersection is possible.

    """
    # Check position relative to terrain altitude band using ellipsoid equation
    # Value > 1 means above surface, < 1 means below
    above_ceiling = _ellipsoid_position(origin_xyz, MAX_TERRAIN_ALT_M) > 1.0
    below_floor = _ellipsoid_position(origin_xyz, MIN_TERRAIN_ALT_M) < 1.0

    if not above_ceiling and not below_floor:
        return 0.0

    is_descending = _is_descending(origin_xyz, direction_xyz)
    if above_ceiling and not is_descending:
        return None  # Above ceiling and ascending
    if below_floor and is_descending:
        return None  # Below floor and descending

    # Fast skip to terrain altitude band if starting outside it
    target_alt_m = MAX_TERRAIN_ALT_M if above_ceiling else MIN_TERRAIN_ALT_M
    aer = xyz_to_aer(origin_xyz, direction_xyz)
    az, el = float(aer[0]), float(aer[1])

    start_dist = slant_range(origin_xyz, az, el, target_alt_m)
    return start_dist if start_dist is not None else 0.0


def _march(
    terrain: TerrainSource,
    origin_xyz: NDArray[np.floating],
    direction_xyz: NDArray[np.floating],
    start_dist: float,
    altitude_epsilon_m: float,
) -> NDArray[np.floating] | None:
    """Ray marching with tile skip and slope-based skip optimization.

    Uses two skip strategies to minimize terrain lookups:
    1. Tile skip: When above tile's max altitude, skip to tile boundary
    2. Slope skip: Skip based on 45-degree max terrain slope assumption
    """
    curr_dist = start_dist

    # Compute ray direction in LLA space (approximate, for skip calculations)
    # Sample two points to get dLLA/dm
    p1 = origin_xyz + direction_xyz * curr_dist
    p2 = origin_xyz + direction_xyz * (curr_dist + 1000.0)
    lla1 = xyz_to_lla(p1)
    lla2 = xyz_to_lla(p2)
    dlla_per_m = (
        (lla2[0] - lla1[0]) / 1000.0,
        (lla2[1] - lla1[1]) / 1000.0,
        (lla2[2] - lla1[2]) / 1000.0,
    )
    elevation_rad = np.arcsin(-dlla_per_m[2]) if abs(dlla_per_m[2]) < 1.0 else 0.0

    # Initialize state - compute actual above/below from first terrain check
    curr_lla = lla1
    curr_alt = float(curr_lla[2])
    lat, lon = float(curr_lla[0]), float(curr_lla[1])
    terrain_alt = _get_terrain_alt(terrain, lat, lon) + altitude_epsilon_m
    clearance = curr_alt - terrain_alt
    prev_above = clearance > 0
    prev_dist = curr_dist
    prev_alt = curr_alt

    for _ in range(1_000_000):
        lat, lon = float(curr_lla[0]), float(curr_lla[1])

        # Handle NaN coordinates (can happen at extreme distances)
        if np.isnan(lat) or np.isnan(lon):
            return None

        # Get terrain altitude
        terrain_alt = _get_terrain_alt(terrain, lat, lon) + altitude_epsilon_m
        clearance = curr_alt - terrain_alt
        curr_above = clearance > 0

        # Check for crossing (but not on first iteration where prev == curr)
        if curr_dist > prev_dist and curr_above != prev_above:
            return _refine(
                terrain,
                origin_xyz,
                direction_xyz,
                prev_dist,
                curr_dist,
                altitude_epsilon_m,
                low_above=prev_above,
            )

        # Check termination: exited terrain band and moving away from it
        # Only terminate if we've moved past where terrain could possibly be
        going_up = curr_alt > prev_alt if curr_dist > prev_dist else dlla_per_m[2] > 0
        if curr_alt > MAX_TERRAIN_ALT_M and going_up:
            return None
        if curr_alt < MIN_TERRAIN_ALT_M and not going_up:
            return None

        # Compute skip distance
        tile = terrain.get_tile_at(lat, lon)
        tile_key = (int(np.floor(lat)), int(np.floor(lon)))

        if tile is not None and curr_alt > tile.alt_max + altitude_epsilon_m:
            # Above tile's max terrain - skip to tile boundary or alt_max
            step = _tile_exit_dist(
                (lat, lon, curr_alt),
                dlla_per_m,
                tile_key,
                tile.alt_max + altitude_epsilon_m,
            )
        else:
            # Use slope-based skip
            step = _slope_skip_dist(clearance, elevation_rad)

        # Advance
        prev_dist = curr_dist
        prev_alt = curr_alt
        prev_above = curr_above
        curr_dist += step

        curr_point = origin_xyz + direction_xyz * curr_dist
        curr_lla = xyz_to_lla(curr_point)
        curr_alt = float(curr_lla[2])

    _log.warning("Ray march exceeded max iterations")
    return None


def _get_terrain_alt(
    terrain: TerrainSource,
    lat: float,
    lon: float,
    interpolation: str = "nearest",
) -> float:
    """Get terrain altitude, treating NaN as sea level (0m)."""
    alt = terrain.get_altitude(
        np.array([lat]),
        np.array([lon]),
        interpolation=interpolation,
    )[0]
    return 0.0 if np.isnan(alt) else float(alt)


def _refine(  # noqa: PLR0913
    terrain: TerrainSource,
    origin_xyz: NDArray[np.floating],
    direction_xyz: NDArray[np.floating],
    low_dist: float,
    high_dist: float,
    altitude_epsilon_m: float,
    *,
    low_above: bool,
) -> NDArray[np.floating]:
    """Refine intersection using binary search with bicubic interpolation."""
    while high_dist - low_dist > _REFINEMENT_TOLERANCE_M:
        mid_dist = (low_dist + high_dist) / 2
        mid_point = origin_xyz + direction_xyz * mid_dist
        mid_lla = xyz_to_lla(mid_point)

        mid_terrain_alt = (
            _get_terrain_alt(terrain, mid_lla[0], mid_lla[1], interpolation="bicubic")
            + altitude_epsilon_m
        )
        mid_above = mid_lla[2] > mid_terrain_alt

        if mid_above == low_above:
            low_dist = mid_dist
        else:
            high_dist = mid_dist

    final_dist = (low_dist + high_dist) / 2
    return origin_xyz + direction_xyz * final_dist
