"""Geometric intersection utilities for terrain data.

This module provides functions for computing intersections between geometric
primitives and terrain surfaces.

Example:
    >>> from gri_terrain import CopernicusSource
    >>> from gri_terrain.intersect import ray_terrain
    >>> source = CopernicusSource()
    >>> origin = np.array([4000000.0, 3000000.0, 5000000.0])  # ECEF meters
    >>> direction = np.array([-0.5, -0.4, -0.7])  # pointing roughly toward Earth
    >>> direction = direction / np.linalg.norm(direction)
    >>> hit = ray_terrain(source, origin, direction)

"""

from gri_terrain.intersect.ray import ray_terrain

__all__ = [
    "ray_terrain",
]
