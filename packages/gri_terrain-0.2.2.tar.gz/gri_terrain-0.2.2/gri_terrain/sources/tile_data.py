"""Tile data container for cached terrain elevation data."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


class TileData:
    """Container for cached terrain tile data.

    Stores elevation data along with metadata needed for coordinate conversion
    and cache management. Multiple cache keys can reference the same TileData
    object when a single file covers multiple 1x1 degree cells.

    Attributes:
        data: 2D elevation array with NaN for void/nodata values. Shape is
            determined by resolution and coverage area.
        resolution_deg: Grid spacing in degrees (e.g., 1/3600 for 1 arc-second).
        lats: List of integer latitude tiles this data covers. First element
            is the southern edge (origin latitude).
        lons: List of integer longitude tiles this data covers. First element
            is the western edge (origin longitude).
        alt_min: Minimum elevation in meters (computed at creation, ignoring NaN).
        alt_max: Maximum elevation in meters (computed at creation, ignoring NaN).

    Example:
        A 1x1 degree DTED tile at N39 W105:
            TileData(data=arr, resolution_deg=1/3600, lats=[39], lons=[-105])

        A 2x2 degree GeoTIFF covering N39-41 W105-103:
            TileData(data=arr, resolution_deg=1/1200, lats=[39, 40], lons=[-105, -104])

    """

    __slots__ = ("alt_max", "alt_min", "data", "lats", "lons", "resolution_deg")

    def __init__(
        self,
        data: NDArray[np.floating],
        resolution_deg: float,
        lats: list[int],
        lons: list[int],
    ) -> None:
        """Initialize tile data with elevation array and metadata."""
        self.data = data
        self.resolution_deg = resolution_deg
        self.lats = lats
        self.lons = lons
        # Compute and cache altitude bounds once at creation
        self.alt_min = float(np.nanmin(data))
        self.alt_max = float(np.nanmax(data))

    @property
    def origin_lat(self) -> int:
        """Southern edge latitude (minimum latitude)."""
        return self.lats[0]

    @property
    def origin_lon(self) -> int:
        """Western edge longitude (minimum longitude)."""
        return self.lons[0]

    def cache_keys(self) -> list[tuple[int, int]]:
        """Return all (lat, lon) cache keys this tile covers.

        Returns:
            List of (lat, lon) tuples for all 1x1 degree cells covered.

        """
        return [(lat, lon) for lat in self.lats for lon in self.lons]

    @property
    def nbytes(self) -> int:
        """Memory size of the elevation data array in bytes."""
        return self.data.nbytes
