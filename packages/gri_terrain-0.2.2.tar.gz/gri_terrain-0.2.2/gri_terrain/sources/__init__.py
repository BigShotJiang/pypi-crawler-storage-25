"""Terrain data source implementations.

This subpackage contains implementations for various terrain data formats and services:

- TerrainSource: Abstract base class defining the source interface
- DTEDSource: Digital Terrain Elevation Data files
- GeoTiffSource: Local GeoTIFF and Cloud Optimized GeoTIFF files
- CopernicusSource: Copernicus DEM (GLO-30/GLO-90) via AWS S3

"""

from gri_terrain.sources.copernicus import CopernicusResolution, CopernicusSource
from gri_terrain.sources.dted import DTEDSource
from gri_terrain.sources.geotiff import GeoTiffSource
from gri_terrain.sources.terrain import TerrainSource

__all__ = [
    "CopernicusResolution",
    "CopernicusSource",
    "DTEDSource",
    "GeoTiffSource",
    "TerrainSource",
]
