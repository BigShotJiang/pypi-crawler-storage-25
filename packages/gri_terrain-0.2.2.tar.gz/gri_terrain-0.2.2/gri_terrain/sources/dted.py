"""DTED (Digital Terrain Elevation Data) source implementation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import ClassVar

import dted
import dted.errors
import numpy as np
from gri_utils import config

from gri_terrain.sources.terrain import TerrainSource
from gri_terrain.sources.tile_data import TileData

_log = logging.getLogger(__name__)


class DTEDSource(TerrainSource):
    """Terrain source for DTED format files.

    Supports DTED Level 0 (~1km), Level 1 (~100m), and Level 2 (~30m) data.
    Uses the `dted` package for file parsing.

    DTED files are organized by 1x1 degree tiles in a directory structure:
    - {lon_dir}/{lat_file}.dt{level}
    - Example: w105/n39.dt0 (lon -105, lat 39, level 0)

    Args:
        path: Path to DTED data directory containing lon subdirectories.
            If None, uses config value from gri-terrain.dted.data_dir.
        level: DTED level (0, 1, or 2). If None, auto-detect from files.

    Example:
        >>> source = DTEDSource("/data/dted")
        >>> alt = source.get_altitude(np.array([40.0]), np.array([-105.0]))

    """

    # Resolution in meters for each DTED level
    _LEVEL_RESOLUTION: ClassVar[dict[int, float]] = {
        0: 900.0,  # ~30 arc-seconds = ~900m at equator
        1: 90.0,  # ~3 arc-seconds = ~90m at equator
        2: 30.0,  # ~1 arc-second = ~30m at equator
    }

    # Resolution in degrees for each DTED level
    _LEVEL_RESOLUTION_DEG: ClassVar[dict[int, float]] = {
        0: 30.0 / 3600.0,  # 30 arc-seconds
        1: 3.0 / 3600.0,  # 3 arc-seconds
        2: 1.0 / 3600.0,  # 1 arc-second
    }

    def __init__(
        self,
        path: str | Path | None = None,
        level: int | None = None,
    ) -> None:
        """Initialize DTED source with data path."""
        super().__init__()

        # Resolve path from config if not provided
        if path is None:
            path = config.get_path("gri-terrain.dted.data_dir")
            if path is None:
                msg = (
                    "path not provided and gri-terrain.dted.data_dir not "
                    "configured in ~/.config/gri/config.toml"
                )
                raise ValueError(msg)

        self._path = Path(path)
        self._level = level

        if not self._path.exists():
            msg = f"DTED path does not exist: {self._path}"
            raise FileNotFoundError(msg)

        # Create TileSet to manage all tiles in the directory
        self._tileset = dted.TileSet(str(self._path))

    def _load_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Load tile data from DTED file.

        Args:
            lat_tile: Integer latitude of tile's southwest corner.
            lon_tile: Integer longitude of tile's southwest corner.

        Returns:
            TileData with elevation array and metadata, or None if no coverage.

        """
        # Try to get tile from TileSet
        try:
            tile = self._tileset.get_tile(dted.LatLon(lat_tile + 0.5, lon_tile + 0.5))
            if tile is None:
                return None

            # Load data into memory
            tile.load_data()

            # Get tile metadata
            lat_interval_deg = tile.dsi.latitude_interval / 3600.0
            lon_interval_deg = tile.dsi.longitude_interval / 3600.0
            resolution_deg = (lat_interval_deg + lon_interval_deg) / 2

            # Convert data to float and handle void values.
            # The dted library stores data as (lon_idx, lat_idx) matching
            # the DTED file's column-major layout.  Transpose to (lat, lon)
            # so that row index corresponds to latitude as TerrainSource
            # expects.
            data = tile.data.astype(np.float64).T
            void_value = -32767
            data[data == void_value] = np.nan

            return TileData(
                data=data,
                resolution_deg=resolution_deg,
                lats=[lat_tile],
                lons=[lon_tile],
            )

        except (KeyError, ValueError, dted.errors.NoElevationDataError):
            return None

    @property
    def name(self) -> str:
        """Return source name."""
        level_str = f" Level {self._level}" if self._level is not None else ""
        return f"DTED{level_str}"
