"""Abstract base class for terrain data sources."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections import OrderedDict
from typing import TYPE_CHECKING, Literal

import numpy as np
from gri_utils import config
from scipy import ndimage

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from gri_terrain.sources.tile_data import TileData

_log = logging.getLogger(__name__)

_INTERPOLATION_ORDER: dict[str, Literal[0, 1, 3]] = {
    "nearest": 0,
    "bilinear": 1,
    "bicubic": 3,
}

# Module default for memory cache size
_DEFAULT_MAX_MEMORY_CACHE_MB = 500.0


class TerrainSource(ABC):
    """Abstract base class for terrain elevation data sources.

    Implementations must provide elevation lookup for given coordinates. Sources
    should return NaN for locations outside their coverage area rather than raising
    exceptions.

    Subclasses should implement `_load_tile()` to load data from their specific
    format. The base class handles caching, coordinate conversion, and interpolation.

    Args:
        max_memory_cache_mb: Maximum memory for tile cache in megabytes.
            If None, uses config value or default (500 MB).
            Set to 0 for unlimited cache (not recommended for large regions).

    """

    def __init__(self, max_memory_cache_mb: float | None = None) -> None:
        """Initialize terrain source with empty tile cache."""
        if max_memory_cache_mb is None:
            max_memory_cache_mb = float(
                config.get(
                    "gri-terrain.max_memory_cache_mb",
                    _DEFAULT_MAX_MEMORY_CACHE_MB,
                ),
            )
        self._max_cache_bytes = int(max_memory_cache_mb * 1024 * 1024)
        self._cache_bytes = 0
        # OrderedDict for LRU eviction - most recently used at end
        # Cache: (lat, lon) -> TileData or None (checked, no coverage)
        self._tile_cache: OrderedDict[tuple[int, int], TileData | None] = OrderedDict()

    def get_altitude(
        self,
        lat: NDArray[np.floating],
        lon: NDArray[np.floating],
        *,
        interpolation: str = "bicubic",
    ) -> NDArray[np.floating]:
        """Get terrain elevation at specified coordinates.

        Args:
            lat: Latitudes in decimal degrees, WGS84. Shape (N,).
            lon: Longitudes in decimal degrees, WGS84. Shape (N,).
            interpolation: Interpolation method ("nearest", "bilinear", "bicubic").

        Returns:
            Elevations in meters. Shape (N,).
            NaN for locations outside coverage area.

        """
        if interpolation not in _INTERPOLATION_ORDER:
            msg = (
                f"interpolation must be 'nearest', 'bilinear', or 'bicubic', "
                f"got '{interpolation}'"
            )
            raise ValueError(msg)

        lat = np.atleast_1d(np.asarray(lat, dtype=np.float64))
        lon = np.atleast_1d(np.asarray(lon, dtype=np.float64))

        if lat.shape != lon.shape:
            msg = f"lat and lon must have same shape, got {lat.shape} and {lon.shape}"
            raise ValueError(msg)

        result = np.full(lat.shape, np.nan, dtype=np.float64)

        # Determine which tiles we need
        lat_tiles = np.floor(lat).astype(int)
        lon_tiles = np.floor(lon).astype(int)
        unique_tiles = set(zip(lat_tiles, lon_tiles, strict=False))

        # Process each tile
        for lat_tile, lon_tile in unique_tiles:
            # Find points in this tile
            mask = (lat_tiles == lat_tile) & (lon_tiles == lon_tile)
            if not np.any(mask):
                continue

            # Get tile data (from cache or load)
            tile_data = self._get_tile(lat_tile, lon_tile)
            if tile_data is None:
                continue

            # Calculate fractional row/col coordinates
            tile_lats = lat[mask]
            tile_lons = lon[mask]
            rows = (tile_lats - tile_data.origin_lat) / tile_data.resolution_deg
            cols = (tile_lons - tile_data.origin_lon) / tile_data.resolution_deg

            # Interpolate
            result[mask] = self._interpolate(
                tile_data.data,
                rows,
                cols,
                interpolation,
            )

        return result

    def _get_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Get tile data for given coordinates, using cache.

        Args:
            lat_tile: Integer latitude of tile's southwest corner.
            lon_tile: Integer longitude of tile's southwest corner.

        Returns:
            TileData if available, None if no coverage.

        """
        key = (lat_tile, lon_tile)

        if key in self._tile_cache:
            # Move to end for LRU
            self._tile_cache.move_to_end(key)
            return self._tile_cache[key]

        # Load tile and cache it
        tile_data = self._load_tile(lat_tile, lon_tile)

        if tile_data is None:
            # No coverage - cache the miss (no memory cost)
            self._tile_cache[key] = None
        else:
            # Evict old tiles if needed before adding new one
            self._evict_if_needed(tile_data.nbytes)

            # Cache under all keys this tile covers
            for cache_key in tile_data.cache_keys():
                self._tile_cache[cache_key] = tile_data

            # Only count memory once per unique tile
            self._cache_bytes += tile_data.nbytes

        return tile_data

    def _evict_if_needed(self, needed_bytes: int) -> None:
        """Evict oldest tiles from cache to make room for new tile.

        Args:
            needed_bytes: Size of tile being added.

        """
        if self._max_cache_bytes == 0:
            return  # Unlimited cache

        target_size = self._max_cache_bytes - needed_bytes

        while self._cache_bytes > target_size and self._tile_cache:
            # Get oldest entry (first in OrderedDict)
            oldest_key, oldest_tile = next(iter(self._tile_cache.items()))

            if oldest_tile is None:
                # Just a cached miss, remove it
                del self._tile_cache[oldest_key]
                continue

            # Remove all keys pointing to this tile
            tile_bytes = oldest_tile.nbytes
            keys_to_remove = list(oldest_tile.cache_keys())
            for cache_key in keys_to_remove:
                self._tile_cache.pop(cache_key, None)

            self._cache_bytes -= tile_bytes
            _log.debug(
                "Evicted tile at (%d, %d) from memory cache (%.1f MB)",
                oldest_key[0],
                oldest_key[1],
                tile_bytes / 1e6,
            )

    @abstractmethod
    def _load_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Load tile data from source.

        Subclasses implement this to load data from their specific format.
        The returned TileData should have nodata values converted to NaN.

        Args:
            lat_tile: Integer latitude of tile's southwest corner.
            lon_tile: Integer longitude of tile's southwest corner.

        Returns:
            TileData with elevation array and metadata, or None if no coverage.

        """

    def get_tile_at(self, lat: float, lon: float) -> TileData | None:
        """Get tile data covering a specific coordinate.

        This provides access to the underlying tile for advanced use cases
        like ray-terrain intersection optimization.

        Args:
            lat: Latitude in decimal degrees.
            lon: Longitude in decimal degrees.

        Returns:
            TileData if available, None if no coverage at this location.

        """
        lat_tile = int(np.floor(lat))
        lon_tile = int(np.floor(lon))
        return self._get_tile(lat_tile, lon_tile)

    def clear_cache(self) -> None:
        """Clear all cached tile data."""
        self._tile_cache.clear()
        self._cache_bytes = 0

    def clear_tile(self, lat_tile: int, lon_tile: int) -> None:
        """Clear cached data for a specific tile.

        If the tile is part of a multi-degree file, all related cache entries
        are cleared.

        Args:
            lat_tile: Integer latitude of tile.
            lon_tile: Integer longitude of tile.

        """
        key = (lat_tile, lon_tile)
        tile_data = self._tile_cache.get(key)

        if tile_data is None:
            # Just remove this single key (might be a cached miss)
            self._tile_cache.pop(key, None)
        else:
            # Remove all keys that point to this tile
            self._cache_bytes -= tile_data.nbytes
            for cache_key in tile_data.cache_keys():
                self._tile_cache.pop(cache_key, None)

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this terrain source."""

    def precache_region(
        self,
        lat_min: float,
        lat_max: float,
        lon_min: float,
        lon_max: float,
    ) -> int:
        """Load tiles for a region into memory cache.

        Pre-loads all tiles covering the specified bounding box. Useful for
        ensuring fast lookups in a known operating area.

        Args:
            lat_min: Southern latitude bound in decimal degrees.
            lat_max: Northern latitude bound in decimal degrees.
            lon_min: Western longitude bound in decimal degrees.
            lon_max: Eastern longitude bound in decimal degrees.

        Returns:
            Number of tiles loaded (excludes tiles with no coverage).

        Raises:
            MemoryError: If the region requires more memory than max_memory_cache_mb.

        """
        # Calculate tile range
        lat_tile_min = int(np.floor(lat_min))
        lat_tile_max = int(np.floor(lat_max))
        lon_tile_min = int(np.floor(lon_min))
        lon_tile_max = int(np.floor(lon_max))

        tiles_needed = [
            (lat, lon)
            for lat in range(lat_tile_min, lat_tile_max + 1)
            for lon in range(lon_tile_min, lon_tile_max + 1)
        ]

        # Check if region fits in cache (if limit is set)
        if self._max_cache_bytes > 0:
            # Estimate based on first tile (assume uniform size)
            sample_tile = self._load_tile(tiles_needed[0][0], tiles_needed[0][1])
            if sample_tile is not None:
                estimated_bytes = sample_tile.nbytes * len(tiles_needed)
                if estimated_bytes > self._max_cache_bytes:
                    msg = (
                        f"Region requires ~{estimated_bytes / 1e6:.0f} MB but cache "
                        f"limit is {self._max_cache_bytes / 1e6:.0f} MB. "
                        f"Increase max_memory_cache_mb or reduce region size."
                    )
                    raise MemoryError(msg)

        # Load all tiles
        loaded = 0
        for lat_tile, lon_tile in tiles_needed:
            tile_data = self._get_tile(lat_tile, lon_tile)
            if tile_data is not None:
                loaded += 1

        _log.info(
            "Precached %d tiles for region (%.1f, %.1f) to (%.1f, %.1f)",
            loaded,
            lat_min,
            lon_min,
            lat_max,
            lon_max,
        )
        return loaded

    def _interpolate(
        self,
        data: NDArray[np.floating],
        rows: NDArray[np.floating],
        cols: NDArray[np.floating],
        interpolation: str,
    ) -> NDArray[np.floating]:
        """Interpolate values from a 2D grid at fractional row/col coordinates.

        Args:
            data: 2D elevation array with NaN for void/nodata values.
            rows: Row (y) pixel coordinates.
            cols: Column (x) pixel coordinates.
            interpolation: Interpolation method ("nearest", "bilinear", "bicubic").

        Returns:
            Interpolated elevation values.

        """
        coords = [rows, cols]
        return ndimage.map_coordinates(
            data,
            coords,
            order=_INTERPOLATION_ORDER[interpolation],
            mode="nearest",
            cval=float("nan"),
        )
