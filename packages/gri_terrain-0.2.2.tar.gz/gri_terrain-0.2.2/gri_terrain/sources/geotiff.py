"""GeoTIFF terrain source implementation."""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np
import rasterio
from gri_utils import config

from gri_terrain.sources.terrain import TerrainSource
from gri_terrain.sources.tile_data import TileData

_log = logging.getLogger(__name__)

# Small epsilon to handle exact boundary cases (e.g., bounds.top = 37.0 should not
# include tile 37, only tile 36)
_BOUNDS_EPSILON = 1e-9


def _tile_range(min_bound: float, max_bound: float) -> range:
    """Compute integer tile range from floating-point bounds.

    Tiles are indexed by their southwest corner. A tile at index N covers the
    half-open interval [N, N+1). When max_bound falls exactly on a tile boundary,
    that tile is excluded (it would have zero coverage).

    Args:
        min_bound: Minimum coordinate (south or west edge).
        max_bound: Maximum coordinate (north or east edge).

    Returns:
        Range of tile indices covered by the bounds.

    """
    tile_min = int(np.floor(min_bound))
    # Subtract epsilon before floor to exclude tiles where max_bound is exactly
    # on their boundary (zero coverage)
    tile_max = int(np.floor(max_bound - _BOUNDS_EPSILON))
    return range(tile_min, tile_max + 1)


class GeoTiffSource(TerrainSource):
    """Terrain source for GeoTIFF and Cloud Optimized GeoTIFF (COG) files.

    Supports local GeoTIFF files containing elevation data. Uses rasterio for
    efficient reading, including partial reads from COG files.

    The source maintains a spatial index mapping (lat, lon) tile coordinates
    to file paths. The index is rebuilt when files are added or removed.

    Args:
        path: Path to GeoTIFF file or directory containing GeoTIFF files.
            If None, uses config value from gri-terrain.geotiff.data_dir.
            If a directory, all .tif/.tiff files will be indexed.
        glob_pattern: Glob pattern for finding files in directory (default "*.tif").

    Example:
        >>> source = GeoTiffSource("/data/dem/region.tif")
        >>> alt = source.get_altitude(np.array([40.0]), np.array([-105.0]))

    """

    def __init__(
        self,
        path: str | Path | None = None,
        glob_pattern: str = "*.tif",
    ) -> None:
        """Initialize GeoTIFF source."""
        super().__init__()

        # Resolve path from config if not provided
        if path is None:
            path = config.get_path("gri-terrain.geotiff.data_dir")
            if path is None:
                msg = (
                    "path not provided and gri-terrain.geotiff.data_dir not "
                    "configured in ~/.config/gri/config.toml"
                )
                raise ValueError(msg)

        self._path = Path(path)
        self._glob_pattern = glob_pattern

        # Spatial index: (lat_tile, lon_tile) -> Path
        self._path_index: dict[tuple[int, int], Path] = {}
        self._index_dirty = True

        # Ensure path exists (for directory mode, allow empty initially)
        if not self._path.exists():
            if self._path.suffix in (".tif", ".tiff"):
                # Single file mode - must exist
                msg = f"GeoTIFF file does not exist: {self._path}"
                raise FileNotFoundError(msg)
            # Directory mode - create it
            self._path.mkdir(parents=True, exist_ok=True)

    def _rebuild_index(self) -> None:
        """Rebuild spatial index from files in path.

        Maps each 1x1 degree cell to the file that covers it.
        """
        self._path_index.clear()

        if self._path.is_file():
            files = [self._path]
        else:
            files = list(self._path.glob(self._glob_pattern))
            # Also try .tiff extension
            tiff_pattern = self._glob_pattern.replace(".tif", ".tiff")
            if tiff_pattern != self._glob_pattern:
                files.extend(self._path.glob(tiff_pattern))

        for filepath in files:
            try:
                with rasterio.open(filepath) as src:
                    bounds = src.bounds
                    lat_range = _tile_range(bounds.bottom, bounds.top)
                    lon_range = _tile_range(bounds.left, bounds.right)

                    for lat_tile in lat_range:
                        for lon_tile in lon_range:
                            key = (lat_tile, lon_tile)
                            if key not in self._path_index:
                                self._path_index[key] = filepath
            except rasterio.RasterioIOError as e:
                _log.warning("Failed to read bounds from %s: %s", filepath, e)

        self._index_dirty = False
        _log.debug(
            "Rebuilt GeoTIFF index: %d cells from %d files",
            len(self._path_index),
            len(files),
        )

    def mark_dirty(self) -> None:
        """Mark the spatial index as needing rebuild.

        Call this after adding or removing files from the directory.
        """
        self._index_dirty = True

    def _load_tile(self, lat_tile: int, lon_tile: int) -> TileData | None:
        """Load tile data from GeoTIFF file.

        Args:
            lat_tile: Integer latitude of tile's southwest corner.
            lon_tile: Integer longitude of tile's southwest corner.

        Returns:
            TileData with elevation array and metadata, or None if no coverage.

        """
        # Rebuild index if needed
        if self._index_dirty:
            self._rebuild_index()

        # Look up file for this cell
        filepath = self._path_index.get((lat_tile, lon_tile))
        if filepath is None:
            return None

        try:
            with rasterio.open(filepath) as src:
                # Read the elevation data (band 1)
                data = src.read(1).astype(np.float64)
                bounds = src.bounds
                nodata = src.nodata

                # Convert nodata to NaN
                if nodata is not None:
                    data[data == nodata] = np.nan

                lat_range = _tile_range(bounds.bottom, bounds.top)
                lon_range = _tile_range(bounds.left, bounds.right)

                # Calculate resolution in degrees
                x_res, y_res = src.res
                resolution_deg = (abs(x_res) + abs(y_res)) / 2

                return TileData(
                    data=data,
                    resolution_deg=resolution_deg,
                    lats=list(lat_range),
                    lons=list(lon_range),
                )
        except rasterio.RasterioIOError as e:
            _log.warning("Failed to read from %s: %s", filepath, e)
            return None

    @property
    def name(self) -> str:
        """Return source name."""
        if self._index_dirty:
            self._rebuild_index()
        n_files = len(set(self._path_index.values()))
        return f"GeoTIFF ({n_files} files)"
