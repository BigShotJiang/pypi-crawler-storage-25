"""ASGI middleware for trust-gating requests using AgentScore."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from starlette.requests import Request
from starlette.responses import JSONResponse

from agentscore_gate.client import GateClient, PaymentRequiredError
from agentscore_gate.sessions import CreateSessionOnMissing, try_create_session_denial_reason
from agentscore_gate.types import AgentIdentity, DenialReason, Network

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.types import ASGIApp, Receive, Scope, Send

DEFAULT_ADDRESS_HEADER = "x-wallet-address"
DEFAULT_TOKEN_HEADER = "x-operator-token"
GATE_STATE_KEY = "__agentscore_gate"

__all__ = [
    "AgentScoreGate",
    "CreateSessionOnMissing",
    "capture_wallet",
]


def _default_extract_identity(request: Request) -> AgentIdentity | None:
    token = request.headers.get(DEFAULT_TOKEN_HEADER)
    addr = request.headers.get(DEFAULT_ADDRESS_HEADER)
    identity = AgentIdentity()
    if token and len(token) > 0:
        identity.operator_token = token
    if addr and len(addr) > 0:
        identity.address = addr
    if identity.operator_token or identity.address:
        return identity
    return None


async def _default_on_denied(_request: Request, reason: DenialReason) -> JSONResponse:
    body: dict[str, Any] = {"error": reason.code}
    if reason.decision is not None:
        body["decision"] = reason.decision
    if reason.reasons:
        body["reasons"] = reason.reasons
    if reason.verify_url:
        body["verify_url"] = reason.verify_url
    if reason.session_id:
        body["session_id"] = reason.session_id
    if reason.poll_secret:
        body["poll_secret"] = reason.poll_secret
    if reason.poll_url:
        body["poll_url"] = reason.poll_url
    if reason.agent_instructions:
        body["agent_instructions"] = reason.agent_instructions
    if reason.extra:
        body.update(reason.extra)
    return JSONResponse(body, status_code=403)


class AgentScoreGate:
    """ASGI middleware that gates requests based on AgentScore wallet reputation.

    Usage with Starlette / FastAPI::

        app.add_middleware(
            AgentScoreGate,
            api_key="ask_...",
            require_kyc=True,
        )
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        api_key: str,
        require_kyc: bool | None = None,
        require_sanctions_clear: bool | None = None,
        min_age: int | None = None,
        blocked_jurisdictions: list[str] | None = None,
        allowed_jurisdictions: list[str] | None = None,
        fail_open: bool = False,
        cache_seconds: int = 300,
        base_url: str = "https://api.agentscore.sh",
        chain: str | None = None,
        user_agent: str | None = None,
        extract_identity: Callable[[Request], AgentIdentity | None] | None = None,
        extract_chain: Callable[[Request], str | None] | None = None,
        on_denied: Callable[[Request, DenialReason], Awaitable[JSONResponse]] | None = None,
        create_session_on_missing: CreateSessionOnMissing | None = None,
    ) -> None:
        self.app = app
        self._client = GateClient(
            api_key=api_key,
            require_kyc=require_kyc,
            require_sanctions_clear=require_sanctions_clear,
            min_age=min_age,
            blocked_jurisdictions=blocked_jurisdictions,
            allowed_jurisdictions=allowed_jurisdictions,
            fail_open=fail_open,
            cache_seconds=cache_seconds,
            base_url=base_url,
            chain=chain,
            user_agent=user_agent,
        )
        self._extract_identity = extract_identity or _default_extract_identity
        self._extract_chain = extract_chain
        self._on_denied = on_denied or _default_on_denied
        self._create_session_on_missing = create_session_on_missing

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """ASGI entry point."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive, send)

        identity = self._extract_identity(request)
        # Stash state for capture_wallet() helper to read after the handler runs.
        scope.setdefault("state", {})
        scope["state"][GATE_STATE_KEY] = {
            "client": self._client,
            "operator_token": identity.operator_token if identity else None,
        }
        if not identity:
            if self._client.fail_open:
                await self.app(scope, receive, send)
                return

            if self._create_session_on_missing:
                session_reason = await try_create_session_denial_reason(
                    self._create_session_on_missing,
                    self._client.user_agent,
                    request,
                )
                if session_reason is not None:
                    response = await self._on_denied(request, session_reason)
                    await response(scope, receive, send)
                    return

            reason = DenialReason(code="missing_identity")
            response = await self._on_denied(request, reason)
            await response(scope, receive, send)
            return

        try:
            chain_override = self._extract_chain(request) if self._extract_chain else None
            result = await self._client.acheck_identity(identity, chain_override)

            if result.allow:
                scope["state"] = {**scope.get("state", {}), "agentscore": result.raw}
                await self.app(scope, receive, send)
                return

            reason = DenialReason(
                code="wallet_not_trusted",
                decision=result.decision,
                reasons=result.reasons,
                verify_url=result.verify_url,
            )
            response = await self._on_denied(request, reason)
            await response(scope, receive, send)
        except PaymentRequiredError:
            if self._client.fail_open:
                await self.app(scope, receive, send)
                return
            reason = DenialReason(code="payment_required")
            response = await self._on_denied(request, reason)
            await response(scope, receive, send)
        except Exception:
            if self._client.fail_open:
                await self.app(scope, receive, send)
                return
            reason = DenialReason(code="api_error")
            response = await self._on_denied(request, reason)
            await response(scope, receive, send)


async def capture_wallet(
    request: Request,
    wallet_address: str,
    network: Network,
    idempotency_key: str | None = None,
) -> None:
    """Report a wallet that paid under the operator_token the ASGI gate extracted on this request.

    Fire-and-forget: no-ops silently if the gate didn't run, the request was wallet-authenticated
    (no operator_token to associate), or the API call fails. Use the payment intent id / tx hash
    as ``idempotency_key`` so agent retries of the same payment don't inflate transaction_count.

    Usage (FastAPI)::

        @app.post("/purchase")
        async def purchase(request: Request):
            # ... run payment, recover signer wallet from the payload ...
            await capture_wallet(request, signer, "evm", idempotency_key=payment_intent_id)
            return {"ok": True}
    """
    state = request.scope.get("state", {}).get(GATE_STATE_KEY)
    if not state or not state.get("operator_token"):
        return
    await state["client"].acapture_wallet(
        state["operator_token"],
        wallet_address,
        network,
        idempotency_key=idempotency_key,
    )
