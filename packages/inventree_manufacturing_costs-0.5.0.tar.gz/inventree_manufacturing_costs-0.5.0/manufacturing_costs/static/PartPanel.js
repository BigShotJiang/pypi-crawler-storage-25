import { n as createReactComponent, m as checkPluginVersion, u as useQuery, b as apiUrl, I as IconInfoCircle, A as ApiEndpoints, R as RowEditAction, c as RowDuplicateAction, d as RowDeleteAction, o as RowViewAction, p as formatDecimal, f as formatCurrencyValue, Y as YesNoButton, e as RowActions, g as IconExclamationCircle, h as ActionButton, i as IconFileUpload, j as AddItemButton, S as SearchInput, k as IconRefresh, l as IconFileDownload, q as qr } from "./assets/index-BRkHMwZw.js";
var ModelType = /* @__PURE__ */ ((ModelType2) => {
  ModelType2["part"] = "part";
  ModelType2["supplierpart"] = "supplierpart";
  ModelType2["manufacturerpart"] = "manufacturerpart";
  ModelType2["partcategory"] = "partcategory";
  ModelType2["parttesttemplate"] = "parttesttemplate";
  ModelType2["projectcode"] = "projectcode";
  ModelType2["stockitem"] = "stockitem";
  ModelType2["stocklocation"] = "stocklocation";
  ModelType2["stocklocationtype"] = "stocklocationtype";
  ModelType2["stockhistory"] = "stockhistory";
  ModelType2["build"] = "build";
  ModelType2["buildline"] = "buildline";
  ModelType2["builditem"] = "builditem";
  ModelType2["company"] = "company";
  ModelType2["parameter"] = "parameter";
  ModelType2["parametertemplate"] = "parametertemplate";
  ModelType2["purchaseorder"] = "purchaseorder";
  ModelType2["purchaseorderlineitem"] = "purchaseorderlineitem";
  ModelType2["salesorder"] = "salesorder";
  ModelType2["salesordershipment"] = "salesordershipment";
  ModelType2["returnorder"] = "returnorder";
  ModelType2["returnorderlineitem"] = "returnorderlineitem";
  ModelType2["importsession"] = "importsession";
  ModelType2["address"] = "address";
  ModelType2["contact"] = "contact";
  ModelType2["owner"] = "owner";
  ModelType2["user"] = "user";
  ModelType2["group"] = "group";
  ModelType2["reporttemplate"] = "reporttemplate";
  ModelType2["labeltemplate"] = "labeltemplate";
  ModelType2["pluginconfig"] = "pluginconfig";
  ModelType2["contenttype"] = "contenttype";
  ModelType2["selectionlist"] = "selectionlist";
  ModelType2["error"] = "error";
  return ModelType2;
})(ModelType || {});
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode = [["path", { "d": "M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0", "key": "svg-0" }], ["path", { "d": "M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2", "key": "svg-1" }]];
const IconUser = createReactComponent("outline", "user", "User", __iconNode);
const ActionIcon = window["MantineCore"].ActionIcon;
const Alert = window["MantineCore"].Alert;
const Button = window["MantineCore"].Button;
const Group = window["MantineCore"].Group;
const HoverCard = window["MantineCore"].HoverCard;
const Stack = window["MantineCore"].Stack;
const Text = window["MantineCore"].Text;
const Tooltip = window["MantineCore"].Tooltip;
const useCallback = window["React"].useCallback;
const useEffect = window["React"].useEffect;
const useMemo = window["React"].useMemo;
const useState = window["React"].useState;
function RenderRate({ instance }) {
  if (!instance) {
    return "-";
  }
  return /* @__PURE__ */ React.createElement(Group, { gap: "xs", justify: "space-between" }, /* @__PURE__ */ React.createElement(Text, null, instance.name), /* @__PURE__ */ React.createElement(Group, { gap: "xs", justify: "right" }, /* @__PURE__ */ React.createElement(Text, { size: "xs" }, instance.description), instance.units && /* @__PURE__ */ React.createElement(Text, { size: "xs" }, "[", instance.units, "]")));
}
function ManufacturingCostsPanel({
  context
}) {
  const partId = useMemo(() => {
    return context.model == ModelType.part ? context.id || null : null;
  }, [context.model, context.id]);
  const [searchTerm, setSearchTerm] = useState("");
  const RATE_URL = "/plugin/manufacturing-costs/rate/";
  const COST_URL = "/plugin/manufacturing-costs/cost/";
  const EXPORT_URL = "/plugin/manufacturing-costs/cost/export/";
  const dataQuery = useQuery(
    {
      queryKey: ["manufacturing-cost", partId, searchTerm],
      queryFn: async () => {
        var _a;
        const url = `${COST_URL}`;
        return ((_a = context.api) == null ? void 0 : _a.get(url, {
          params: {
            part: partId,
            search: searchTerm
          }
        }).then((response) => response.data).catch(() => [])) ?? [];
      }
    },
    context.queryClient
  );
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [selectedRate, setSelectedRate] = useState(null);
  useEffect(() => {
    setSelectedRate((selectedRecord == null ? void 0 : selectedRecord.rate) || null);
  }, [selectedRecord]);
  const processFormData = (data) => {
    if (data.rate) {
      data.unit_cost = null;
    }
    return data;
  };
  const costFields = useMemo(() => {
    return {
      part: {
        value: partId,
        disabled: true
      },
      description: {},
      rate: {
        api_url: apiUrl(RATE_URL),
        modelRenderer: RenderRate,
        preFieldContent: /* @__PURE__ */ React.createElement(
          Alert,
          {
            color: "blue",
            icon: /* @__PURE__ */ React.createElement(IconInfoCircle, null),
            title: "Manufacturing Rate"
          },
          "If a rate is selected, the unit cost will be calculated based on the rate price and quantity."
        ),
        onValueChange(value) {
          setSelectedRate(value || null);
        }
      },
      unit_cost: {
        onValueChange() {
          setSelectedRate(null);
        },
        disabled: !!selectedRate
      },
      unit_cost_currency: {
        disabled: !!selectedRate
      },
      amount: {},
      amortization: {},
      notes: {},
      inherited: {},
      active: {}
    };
  }, [selectedRate]);
  const createCostForm = context.forms.create({
    url: apiUrl(COST_URL),
    title: "Add Manufacturing Cost",
    fields: costFields,
    successMessage: "Cost created",
    onFormSuccess: () => {
      dataQuery.refetch();
    },
    processFormData
  });
  const duplicateCostForm = context.forms.create({
    url: apiUrl(COST_URL),
    title: "Add Manufacturing Cost",
    fields: costFields,
    successMessage: "Cost created",
    initialData: selectedRecord,
    onFormSuccess: () => {
      dataQuery.refetch();
    },
    processFormData
  });
  const editCostForm = context.forms.edit({
    url: apiUrl(COST_URL, selectedRecord == null ? void 0 : selectedRecord.pk),
    title: "Edit Manufacturing Cost",
    fields: costFields,
    successMessage: "Cost updated",
    onFormSuccess: () => {
      dataQuery.refetch();
    },
    processFormData
  });
  const deleteCostForm = context.forms.delete({
    url: apiUrl(COST_URL, selectedRecord == null ? void 0 : selectedRecord.pk),
    title: "Delete Manufacturing Cost",
    successMessage: "Cost deleted",
    onFormSuccess: () => {
      dataQuery.refetch();
    }
  });
  const importCostsForm = context.forms.create({
    url: apiUrl(ApiEndpoints.import_session_list),
    title: "Import Manufacturing Costs",
    fields: {
      data_file: {},
      model_type: {
        value: "manufacturingcost",
        hidden: true
      },
      update_records: {},
      field_overrides: {
        hidden: true,
        value: {
          part: partId || void 0
        }
      }
    },
    onFormSuccess: (response) => {
      var _a, _b;
      const sessionId = response.pk;
      (_b = (_a = context.importer) == null ? void 0 : _a.open) == null ? void 0 : _b.call(_a, sessionId, {
        onClose: () => {
          dataQuery.refetch();
        },
        fields: {
          rate: {
            api_url: apiUrl(RATE_URL),
            modelRenderer: RenderRate
          }
        }
      });
    }
  });
  const exportDataForm = context.forms.create({
    url: apiUrl(EXPORT_URL),
    method: "GET",
    title: "Export Manufacturing Costs",
    fetchInitialData: false,
    ignorePermissionCheck: true,
    submitText: "Export",
    fields: {
      part: {
        field_type: "integer",
        value: partId,
        hidden: true
      },
      export_format: {
        label: "Export Format",
        description: "Select the format for data export",
        field_type: "choice",
        choices: [
          { display_name: "CSV", value: "csv" },
          { display_name: "XLS", value: "xls" },
          { display_name: "XLSX", value: "xlsx" }
        ],
        default: "csv"
      },
      include_subassemblies: {
        field_type: "boolean",
        label: "Include Sub-assemblies",
        description: "Include manufacturing costs from sub-assemblies for this part",
        default: true
      }
    },
    onFormSuccess: (data) => {
      if (data.complete && data.output) {
        window.open(data.output, "_blank");
      }
    }
  });
  const rowActions = useCallback(
    (record) => {
      const partPk = context.instance.pk;
      return [
        RowEditAction({
          onClick: () => {
            setSelectedRecord(record);
            editCostForm == null ? void 0 : editCostForm.open();
          },
          hidden: record.part != partPk
        }),
        RowDuplicateAction({
          onClick: () => {
            setSelectedRecord(record);
            duplicateCostForm == null ? void 0 : duplicateCostForm.open();
          }
        }),
        RowDeleteAction({
          onClick: () => {
            setSelectedRecord(record);
            deleteCostForm == null ? void 0 : deleteCostForm.open();
          },
          hidden: record.part != partPk
        }),
        RowViewAction({
          // onClick: (event: any) => {
          //   const url = getDetailUrl(ModelType.part, record.part);
          //   navigateToLink(url, context.navigate, event);
          // },
          hidden: record.part == partPk,
          title: "View Part",
          modelType: ModelType.part,
          modelId: Number.parseInt(record.part) || -1,
          navigate: context.navigate
        })
      ];
    },
    [context.instance]
  );
  const tableColumns = useMemo(() => {
    return [
      {
        accessor: "part",
        title: "Part",
        render: (record) => {
          var _a;
          return (_a = record.part_detail) == null ? void 0 : _a.full_name;
        }
      },
      {
        accessor: "part_detail.IPN",
        title: "IPN"
      },
      {
        accessor: "description",
        title: "Description"
      },
      {
        accessor: "quantity",
        title: "Quantity",
        render: (record) => /* @__PURE__ */ React.createElement(Text, null, record.amount)
      },
      {
        accessor: "amortization",
        title: "Amortization",
        format: (value) => formatDecimal(value)
      },
      {
        accessor: "rate",
        title: "Rate",
        render: (record) => {
          const rate = record.rate_detail;
          let unit_cost = "";
          if (rate) {
            unit_cost = formatCurrencyValue(rate.price, {
              currency: rate.price_currency
            });
          } else {
            unit_cost = formatCurrencyValue(record.unit_cost, {
              currency: record.unit_cost_currency
            });
          }
          return /* @__PURE__ */ React.createElement(Group, { justify: "space-between", gap: "sm" }, /* @__PURE__ */ React.createElement(Text, null, unit_cost), rate && /* @__PURE__ */ React.createElement(HoverCard, null, /* @__PURE__ */ React.createElement(HoverCard.Target, null, /* @__PURE__ */ React.createElement(ActionIcon, { variant: "transparent", size: "sm" }, /* @__PURE__ */ React.createElement(IconInfoCircle, null))), /* @__PURE__ */ React.createElement(HoverCard.Dropdown, null, /* @__PURE__ */ React.createElement(RenderRate, { instance: rate }))));
        }
      },
      {
        accessor: "cost",
        title: "Unit Cost",
        render: (record) => {
          var _a, _b;
          const quantity = (record.quantity || 0) / (record.amortization || 1);
          const price = ((_a = record.rate_detail) == null ? void 0 : _a.price) || record.unit_cost || 0;
          const currency = ((_b = record.rate_detail) == null ? void 0 : _b.price_currency) || record.unit_cost_currency;
          return formatCurrencyValue(price, {
            currency,
            multiplier: quantity
          });
        }
      },
      {
        accessor: "notes",
        title: "Notes"
      },
      {
        accessor: "inherited",
        title: "Inherited",
        render: (record) => /* @__PURE__ */ React.createElement(YesNoButton, { value: record.inherited })
      },
      {
        accessor: "active",
        title: "Active",
        render: (record) => /* @__PURE__ */ React.createElement(YesNoButton, { value: record.active })
      },
      {
        accessor: "updated",
        title: "Updated",
        render: (record) => {
          return /* @__PURE__ */ React.createElement(Group, { justify: "space-between" }, /* @__PURE__ */ React.createElement(Text, { size: "sm" }, record.updated), record.updated_by_detail && /* @__PURE__ */ React.createElement(HoverCard, { position: "bottom-end" }, /* @__PURE__ */ React.createElement(HoverCard.Target, null, /* @__PURE__ */ React.createElement(ActionIcon, { variant: "transparent", size: "sm" }, /* @__PURE__ */ React.createElement(IconUser, null))), /* @__PURE__ */ React.createElement(HoverCard.Dropdown, null, context.renderInstance({
            model: ModelType.user,
            instance: record.updated_by_detail
          }))));
        }
      },
      {
        accessor: "---",
        title: " ",
        width: 50,
        resizable: false,
        sortable: false,
        render: (record, index) => /* @__PURE__ */ React.createElement(RowActions, { actions: rowActions(record), index })
      }
    ];
  }, [dataQuery.data]);
  return /* @__PURE__ */ React.createElement(React.Fragment, null, createCostForm.modal, duplicateCostForm.modal, editCostForm.modal, deleteCostForm.modal, importCostsForm.modal, exportDataForm.modal, /* @__PURE__ */ React.createElement(Stack, { gap: "xs" }, /* @__PURE__ */ React.createElement(
    Alert,
    {
      color: "blue",
      icon: /* @__PURE__ */ React.createElement(IconInfoCircle, null),
      title: "Manufacturing Costs"
    },
    "Additional manufacturing costs associated with this assembly."
  ), dataQuery.isError && /* @__PURE__ */ React.createElement(
    Alert,
    {
      color: "red",
      title: "Error Fetching Data",
      icon: /* @__PURE__ */ React.createElement(IconExclamationCircle, null)
    },
    dataQuery.error instanceof Error ? dataQuery.error.message : "An error occurred while fetching data from the server."
  ), /* @__PURE__ */ React.createElement(Group, { justify: "space-between" }, /* @__PURE__ */ React.createElement(Group, { gap: "xs" }, /* @__PURE__ */ React.createElement(
    ActionButton,
    {
      tooltip: "Import from file",
      tooltipAlignment: "top-start",
      onClick: () => {
        importCostsForm.open();
      },
      icon: /* @__PURE__ */ React.createElement(IconFileUpload, null)
    }
  ), /* @__PURE__ */ React.createElement(
    AddItemButton,
    {
      tooltip: "Add new cost",
      tooltipAlignment: "top-start",
      onClick: () => {
        setSelectedRate(null);
        createCostForm.open();
      }
    }
  )), /* @__PURE__ */ React.createElement(Group, { gap: "xs" }, /* @__PURE__ */ React.createElement(
    SearchInput,
    {
      searchCallback: (value) => {
        setSearchTerm(value);
      }
    }
  ), /* @__PURE__ */ React.createElement(Tooltip, { label: "Refresh data", position: "top-end" }, /* @__PURE__ */ React.createElement(
    ActionIcon,
    {
      variant: "transparent",
      onClick: () => {
        dataQuery.refetch();
      }
    },
    /* @__PURE__ */ React.createElement(IconRefresh, null)
  )), /* @__PURE__ */ React.createElement(
    Button,
    {
      leftSection: /* @__PURE__ */ React.createElement(IconFileDownload, null),
      onClick: () => exportDataForm.open()
    },
    "Export"
  ))), /* @__PURE__ */ React.createElement(
    qr,
    {
      minHeight: 250,
      withTableBorder: true,
      withColumnBorders: true,
      idAccessor: "pk",
      noRecordsText: "No manufacturing costs found",
      fetching: dataQuery.isFetching || dataQuery.isLoading,
      columns: tableColumns,
      records: dataQuery.data || [],
      pinLastColumn: true
    }
  )));
}
function renderPartPanel(context) {
  checkPluginVersion(context);
  return /* @__PURE__ */ React.createElement(ManufacturingCostsPanel, { context });
}
export {
  renderPartPanel
};
//# sourceMappingURL=PartPanel.js.map
