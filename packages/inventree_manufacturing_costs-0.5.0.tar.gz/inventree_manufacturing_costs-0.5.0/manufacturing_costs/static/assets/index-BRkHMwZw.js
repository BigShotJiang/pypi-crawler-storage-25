var __typeError = (msg) => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _focused, _cleanup, _setup, _a, _provider, _providerCalled, _b, _online, _cleanup2, _setup2, _c, _client, _currentQuery, _currentQueryInitialState, _currentResult, _currentResultState, _currentResultOptions, _currentThenable, _selectError, _selectFn, _selectResult, _lastQueryWithDefinedData, _staleTimeoutId, _refetchIntervalId, _currentRefetchInterval, _trackedProps, _QueryObserver_instances, executeFetch_fn, updateStaleTimeout_fn, computeRefetchInterval_fn, updateRefetchInterval_fn, updateTimers_fn, clearStaleTimeout_fn, clearRefetchInterval_fn, updateQuery_fn, notify_fn, _d, _focused2, _cleanup3, _setup3, _e, _online2, _cleanup4, _setup4, _f, _client2, _currentQuery2, _currentQueryInitialState2, _currentResult2, _currentResultState2, _currentResultOptions2, _currentThenable2, _selectError2, _selectFn2, _selectResult2, _lastQueryWithDefinedData2, _staleTimeoutId2, _refetchIntervalId2, _currentRefetchInterval2, _trackedProps2, _QueryObserver_instances2, executeFetch_fn2, updateStaleTimeout_fn2, computeRefetchInterval_fn2, updateRefetchInterval_fn2, updateTimers_fn2, clearStaleTimeout_fn2, clearRefetchInterval_fn2, updateQuery_fn2, notify_fn2, _g;
const INVENTREE_PLUGIN_VERSION = "0.10.1";
var ApiEndpoints = /* @__PURE__ */ ((ApiEndpoints2) => {
  ApiEndpoints2["api_server_info"] = "";
  ApiEndpoints2["user_list"] = "user/";
  ApiEndpoints2["user_set_password"] = "user/:id/set-password/";
  ApiEndpoints2["user_me"] = "user/me/";
  ApiEndpoints2["user_profile"] = "user/profile/";
  ApiEndpoints2["user_roles"] = "user/roles/";
  ApiEndpoints2["user_token"] = "user/token/";
  ApiEndpoints2["user_tokens"] = "user/tokens/";
  ApiEndpoints2["user_simple_login"] = "email/generate/";
  ApiEndpoints2["auth_base"] = "/auth/";
  ApiEndpoints2["user_reset"] = "auth/v1/auth/password/request";
  ApiEndpoints2["user_reset_set"] = "auth/v1/auth/password/reset";
  ApiEndpoints2["auth_pwd_change"] = "auth/v1/account/password/change";
  ApiEndpoints2["auth_login"] = "auth/v1/auth/login";
  ApiEndpoints2["auth_login_2fa"] = "auth/v1/auth/2fa/authenticate";
  ApiEndpoints2["auth_session"] = "auth/v1/auth/session";
  ApiEndpoints2["auth_signup"] = "auth/v1/auth/signup";
  ApiEndpoints2["auth_authenticators"] = "auth/v1/account/authenticators";
  ApiEndpoints2["auth_recovery"] = "auth/v1/account/authenticators/recovery-codes";
  ApiEndpoints2["auth_mfa_reauthenticate"] = "auth/v1/auth/2fa/reauthenticate";
  ApiEndpoints2["auth_totp"] = "auth/v1/account/authenticators/totp";
  ApiEndpoints2["auth_trust"] = "auth/v1/auth/2fa/trust";
  ApiEndpoints2["auth_webauthn"] = "auth/v1/account/authenticators/webauthn";
  ApiEndpoints2["auth_webauthn_login"] = "auth/v1/auth/webauthn/authenticate";
  ApiEndpoints2["auth_reauthenticate"] = "auth/v1/auth/reauthenticate";
  ApiEndpoints2["auth_email"] = "auth/v1/account/email";
  ApiEndpoints2["auth_email_verify"] = "auth/v1/auth/email/verify";
  ApiEndpoints2["auth_providers"] = "auth/v1/account/providers";
  ApiEndpoints2["auth_provider_redirect"] = "auth/v1/auth/provider/redirect";
  ApiEndpoints2["auth_config"] = "auth/v1/config";
  ApiEndpoints2["currency_list"] = "currency/exchange/";
  ApiEndpoints2["currency_refresh"] = "currency/refresh/";
  ApiEndpoints2["all_units"] = "units/all/";
  ApiEndpoints2["task_overview"] = "background-task/";
  ApiEndpoints2["task_pending_list"] = "background-task/pending/";
  ApiEndpoints2["task_scheduled_list"] = "background-task/scheduled/";
  ApiEndpoints2["task_failed_list"] = "background-task/failed/";
  ApiEndpoints2["api_search"] = "search/";
  ApiEndpoints2["settings_global_list"] = "settings/global/";
  ApiEndpoints2["settings_user_list"] = "settings/user/";
  ApiEndpoints2["news"] = "news/";
  ApiEndpoints2["global_status"] = "generic/status/";
  ApiEndpoints2["custom_state_list"] = "generic/status/custom/";
  ApiEndpoints2["version"] = "version/";
  ApiEndpoints2["license"] = "license/";
  ApiEndpoints2["group_list"] = "user/group/";
  ApiEndpoints2["owner_list"] = "user/owner/";
  ApiEndpoints2["ruleset_list"] = "user/ruleset/";
  ApiEndpoints2["content_type_list"] = "contenttype/";
  ApiEndpoints2["icons"] = "icons/";
  ApiEndpoints2["selectionlist_list"] = "selection/";
  ApiEndpoints2["selectionlist_detail"] = "selection/:id/";
  ApiEndpoints2["barcode"] = "barcode/";
  ApiEndpoints2["barcode_history"] = "barcode/history/";
  ApiEndpoints2["barcode_link"] = "barcode/link/";
  ApiEndpoints2["barcode_unlink"] = "barcode/unlink/";
  ApiEndpoints2["barcode_generate"] = "barcode/generate/";
  ApiEndpoints2["data_output"] = "data-output/";
  ApiEndpoints2["import_session_list"] = "importer/session/";
  ApiEndpoints2["import_session_accept_fields"] = "importer/session/:id/accept_fields/";
  ApiEndpoints2["import_session_accept_rows"] = "importer/session/:id/accept_rows/";
  ApiEndpoints2["import_session_column_mapping_list"] = "importer/column-mapping/";
  ApiEndpoints2["import_session_row_list"] = "importer/row/";
  ApiEndpoints2["notifications_list"] = "notifications/";
  ApiEndpoints2["notifications_readall"] = "notifications/readall/";
  ApiEndpoints2["build_order_list"] = "build/";
  ApiEndpoints2["build_order_issue"] = "build/:id/issue/";
  ApiEndpoints2["build_order_cancel"] = "build/:id/cancel/";
  ApiEndpoints2["build_order_hold"] = "build/:id/hold/";
  ApiEndpoints2["build_order_complete"] = "build/:id/finish/";
  ApiEndpoints2["build_output_complete"] = "build/:id/complete/";
  ApiEndpoints2["build_output_create"] = "build/:id/create-output/";
  ApiEndpoints2["build_output_scrap"] = "build/:id/scrap-outputs/";
  ApiEndpoints2["build_output_delete"] = "build/:id/delete-outputs/";
  ApiEndpoints2["build_order_auto_allocate"] = "build/:id/auto-allocate/";
  ApiEndpoints2["build_order_allocate"] = "build/:id/allocate/";
  ApiEndpoints2["build_order_consume"] = "build/:id/consume/";
  ApiEndpoints2["build_order_deallocate"] = "build/:id/unallocate/";
  ApiEndpoints2["build_line_list"] = "build/line/";
  ApiEndpoints2["build_item_list"] = "build/item/";
  ApiEndpoints2["bom_list"] = "bom/";
  ApiEndpoints2["bom_item_validate"] = "bom/:id/validate/";
  ApiEndpoints2["bom_validate"] = "part/:id/bom-validate/";
  ApiEndpoints2["bom_substitute_list"] = "bom/substitute/";
  ApiEndpoints2["part_list"] = "part/";
  ApiEndpoints2["part_thumbs_list"] = "part/thumbs/";
  ApiEndpoints2["part_pricing"] = "part/:id/pricing/";
  ApiEndpoints2["part_requirements"] = "part/:id/requirements/";
  ApiEndpoints2["part_serial_numbers"] = "part/:id/serial-numbers/";
  ApiEndpoints2["part_scheduling"] = "part/:id/scheduling/";
  ApiEndpoints2["part_pricing_internal"] = "part/internal-price/";
  ApiEndpoints2["part_pricing_sale"] = "part/sale-price/";
  ApiEndpoints2["part_stocktake_list"] = "part/stocktake/";
  ApiEndpoints2["part_stocktake_generate"] = "part/stocktake/generate/";
  ApiEndpoints2["category_list"] = "part/category/";
  ApiEndpoints2["category_tree"] = "part/category/tree/";
  ApiEndpoints2["category_parameter_list"] = "part/category/parameters/";
  ApiEndpoints2["related_part_list"] = "part/related/";
  ApiEndpoints2["part_test_template_list"] = "part/test-template/";
  ApiEndpoints2["company_list"] = "company/";
  ApiEndpoints2["contact_list"] = "company/contact/";
  ApiEndpoints2["address_list"] = "company/address/";
  ApiEndpoints2["supplier_part_list"] = "company/part/";
  ApiEndpoints2["supplier_part_pricing_list"] = "company/price-break/";
  ApiEndpoints2["manufacturer_part_list"] = "company/part/manufacturer/";
  ApiEndpoints2["stock_location_list"] = "stock/location/";
  ApiEndpoints2["stock_location_type_list"] = "stock/location-type/";
  ApiEndpoints2["stock_location_tree"] = "stock/location/tree/";
  ApiEndpoints2["stock_item_list"] = "stock/";
  ApiEndpoints2["stock_tracking_list"] = "stock/track/";
  ApiEndpoints2["stock_test_result_list"] = "stock/test/";
  ApiEndpoints2["stock_transfer"] = "stock/transfer/";
  ApiEndpoints2["stock_remove"] = "stock/remove/";
  ApiEndpoints2["stock_return"] = "stock/return/";
  ApiEndpoints2["stock_add"] = "stock/add/";
  ApiEndpoints2["stock_count"] = "stock/count/";
  ApiEndpoints2["stock_change_status"] = "stock/change_status/";
  ApiEndpoints2["stock_merge"] = "stock/merge/";
  ApiEndpoints2["stock_assign"] = "stock/assign/";
  ApiEndpoints2["stock_status"] = "stock/status/";
  ApiEndpoints2["stock_install"] = "stock/:id/install/";
  ApiEndpoints2["stock_uninstall"] = "stock/:id/uninstall/";
  ApiEndpoints2["stock_serialize"] = "stock/:id/serialize/";
  ApiEndpoints2["stock_serial_info"] = "stock/:id/serial-numbers/";
  ApiEndpoints2["generate_batch_code"] = "generate/batch-code/";
  ApiEndpoints2["generate_serial_number"] = "generate/serial-number/";
  ApiEndpoints2["purchase_order_list"] = "order/po/";
  ApiEndpoints2["purchase_order_issue"] = "order/po/:id/issue/";
  ApiEndpoints2["purchase_order_hold"] = "order/po/:id/hold/";
  ApiEndpoints2["purchase_order_cancel"] = "order/po/:id/cancel/";
  ApiEndpoints2["purchase_order_complete"] = "order/po/:id/complete/";
  ApiEndpoints2["purchase_order_line_list"] = "order/po-line/";
  ApiEndpoints2["purchase_order_extra_line_list"] = "order/po-extra-line/";
  ApiEndpoints2["purchase_order_receive"] = "order/po/:id/receive/";
  ApiEndpoints2["sales_order_list"] = "order/so/";
  ApiEndpoints2["sales_order_issue"] = "order/so/:id/issue/";
  ApiEndpoints2["sales_order_hold"] = "order/so/:id/hold/";
  ApiEndpoints2["sales_order_cancel"] = "order/so/:id/cancel/";
  ApiEndpoints2["sales_order_ship"] = "order/so/:id/ship/";
  ApiEndpoints2["sales_order_complete"] = "order/so/:id/complete/";
  ApiEndpoints2["sales_order_allocate"] = "order/so/:id/allocate/";
  ApiEndpoints2["sales_order_allocate_serials"] = "order/so/:id/allocate-serials/";
  ApiEndpoints2["sales_order_line_list"] = "order/so-line/";
  ApiEndpoints2["sales_order_extra_line_list"] = "order/so-extra-line/";
  ApiEndpoints2["sales_order_allocation_list"] = "order/so-allocation/";
  ApiEndpoints2["sales_order_shipment_list"] = "order/so/shipment/";
  ApiEndpoints2["sales_order_shipment_complete"] = "order/so/shipment/:id/ship/";
  ApiEndpoints2["return_order_list"] = "order/ro/";
  ApiEndpoints2["return_order_issue"] = "order/ro/:id/issue/";
  ApiEndpoints2["return_order_hold"] = "order/ro/:id/hold/";
  ApiEndpoints2["return_order_cancel"] = "order/ro/:id/cancel/";
  ApiEndpoints2["return_order_complete"] = "order/ro/:id/complete/";
  ApiEndpoints2["return_order_receive"] = "order/ro/:id/receive/";
  ApiEndpoints2["return_order_line_list"] = "order/ro-line/";
  ApiEndpoints2["return_order_extra_line_list"] = "order/ro-extra-line/";
  ApiEndpoints2["label_list"] = "label/template/";
  ApiEndpoints2["label_print"] = "label/print/";
  ApiEndpoints2["report_list"] = "report/template/";
  ApiEndpoints2["report_print"] = "report/print/";
  ApiEndpoints2["report_snippet"] = "report/snippet/";
  ApiEndpoints2["report_asset"] = "report/asset/";
  ApiEndpoints2["plugin_list"] = "plugins/";
  ApiEndpoints2["plugin_setting_list"] = "plugins/:plugin/settings/";
  ApiEndpoints2["plugin_user_setting_list"] = "plugins/:plugin/user-settings/";
  ApiEndpoints2["plugin_registry_status"] = "plugins/status/";
  ApiEndpoints2["plugin_install"] = "plugins/install/";
  ApiEndpoints2["plugin_reload"] = "plugins/reload/";
  ApiEndpoints2["plugin_activate"] = "plugins/:key/activate/";
  ApiEndpoints2["plugin_uninstall"] = "plugins/:key/uninstall/";
  ApiEndpoints2["plugin_admin"] = "plugins/:key/admin/";
  ApiEndpoints2["plugin_ui_features_list"] = "plugins/ui/features/:feature_type/";
  ApiEndpoints2["plugin_locate_item"] = "locate/";
  ApiEndpoints2["plugin_supplier_list"] = "supplier/list/";
  ApiEndpoints2["plugin_supplier_search"] = "supplier/search/";
  ApiEndpoints2["plugin_supplier_import"] = "supplier/import/";
  ApiEndpoints2["machine_types_list"] = "machine/types/";
  ApiEndpoints2["machine_driver_list"] = "machine/drivers/";
  ApiEndpoints2["machine_registry_status"] = "machine/status/";
  ApiEndpoints2["machine_list"] = "machine/";
  ApiEndpoints2["machine_restart"] = "machine/:machine/restart/";
  ApiEndpoints2["machine_setting_list"] = "machine/:machine/settings/";
  ApiEndpoints2["machine_setting_detail"] = "machine/:machine/settings/:config_type/";
  ApiEndpoints2["attachment_list"] = "attachment/";
  ApiEndpoints2["error_report_list"] = "error-report/";
  ApiEndpoints2["project_code_list"] = "project-code/";
  ApiEndpoints2["custom_unit_list"] = "units/";
  ApiEndpoints2["notes_image_upload"] = "notes-image-upload/";
  ApiEndpoints2["email_list"] = "admin/email/";
  ApiEndpoints2["email_test"] = "admin/email/test/";
  ApiEndpoints2["config_list"] = "admin/config/";
  ApiEndpoints2["parameter_list"] = "parameter/";
  ApiEndpoints2["parameter_template_list"] = "parameter/template/";
  ApiEndpoints2["system_internal_trace_end"] = "system-internal/observability/end";
  return ApiEndpoints2;
})(ApiEndpoints || {});
window["LinguiCore"].i18n;
function apiPrefix() {
  return "/api/";
}
function apiUrl(endpoint, pk, pathParams) {
  let _url = endpoint;
  if (!_url.startsWith("/")) {
    _url = apiPrefix() + _url;
  }
  if (_url && pk) {
    if (_url.indexOf(":id") >= 0) {
      _url = _url.replace(":id", `${pk}`);
    } else {
      _url += `${pk}/`;
    }
  }
  return _url;
}
const _i18n$4 = window["LinguiCore"].i18n;
const ModelInformationDict = {
  part: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "vgP+9p"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "pmRbKZ"
      }
    ),
    url_overview: "/part/category/index/parts",
    url_detail: "/part/:pk/",
    api_endpoint: ApiEndpoints.part_list,
    admin_url: "/part/part/",
    supports_barcode: true,
    icon: "part"
  },
  parameter: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "T/87By"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "F18WP3"
      }
    ),
    api_endpoint: ApiEndpoints.parameter_list,
    icon: "list_details"
  },
  parametertemplate: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "+nwoLk"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "ciZG57"
      }
    ),
    api_endpoint: ApiEndpoints.parameter_template_list,
    admin_url: "/common/parametertemplate/",
    icon: "list"
  },
  parttesttemplate: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "75lDy5"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "KevMsQ"
      }
    ),
    url_detail: "/parttesttemplate/:pk/",
    api_endpoint: ApiEndpoints.part_test_template_list,
    icon: "test"
  },
  supplierpart: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "nne72x"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "FcNRrt"
      }
    ),
    url_overview: "/purchasing/index/supplier-parts",
    url_detail: "/purchasing/supplier-part/:pk/",
    api_endpoint: ApiEndpoints.supplier_part_list,
    admin_url: "/company/supplierpart/",
    supports_barcode: true,
    icon: "supplier_part"
  },
  manufacturerpart: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "bisS0I"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "d0fBfb"
      }
    ),
    url_overview: "/purchasing/index/manufacturer-parts",
    url_detail: "/purchasing/manufacturer-part/:pk/",
    api_endpoint: ApiEndpoints.manufacturer_part_list,
    admin_url: "/company/manufacturerpart/",
    supports_barcode: true,
    icon: "manufacturers"
  },
  partcategory: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "QXANxH"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "2GkbLI"
      }
    ),
    url_overview: "/part/category/parts/subcategories",
    url_detail: "/part/category/:pk/",
    api_endpoint: ApiEndpoints.category_list,
    admin_url: "/part/partcategory/",
    icon: "category"
  },
  stockitem: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "igx8Og"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "Jbck4N"
      }
    ),
    url_overview: "/stock/location/index/stock-items",
    url_detail: "/stock/item/:pk/",
    api_endpoint: ApiEndpoints.stock_item_list,
    admin_url: "/stock/stockitem/",
    supports_barcode: true,
    icon: "stock"
  },
  stocklocation: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "adXdas"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "1eBWAw"
      }
    ),
    url_overview: "/stock/location",
    url_detail: "/stock/location/:pk/",
    api_endpoint: ApiEndpoints.stock_location_list,
    admin_url: "/stock/stocklocation/",
    supports_barcode: true,
    icon: "location"
  },
  stocklocationtype: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "DjwC2f"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "vkPSyZ"
      }
    ),
    api_endpoint: ApiEndpoints.stock_location_type_list,
    icon: "location"
  },
  stockhistory: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "cE4TWF"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "rewkgt"
      }
    ),
    api_endpoint: ApiEndpoints.stock_tracking_list,
    icon: "history"
  },
  build: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "iSiFYa"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "3400Lv"
      }
    ),
    url_overview: "/manufacturing/index/buildorders/",
    url_detail: "/manufacturing/build-order/:pk/",
    api_endpoint: ApiEndpoints.build_order_list,
    admin_url: "/build/build/",
    supports_barcode: true,
    icon: "build_order"
  },
  buildline: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "9TLpo1"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "CRYIQ0"
      }
    ),
    url_overview: "/build/line",
    url_detail: "/build/line/:pk/",
    api_endpoint: ApiEndpoints.build_line_list,
    icon: "build_order"
  },
  builditem: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "LN2ON5"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "A7FuwR"
      }
    ),
    api_endpoint: ApiEndpoints.build_item_list,
    icon: "build_order"
  },
  company: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "7i8j3G"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "s2QZS6"
      }
    ),
    url_detail: "/company/:pk/",
    api_endpoint: ApiEndpoints.company_list,
    admin_url: "/company/company/",
    icon: "building"
  },
  projectcode: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "Sdfr6G"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "AklCpf"
      }
    ),
    url_detail: "/project-code/:pk/",
    api_endpoint: ApiEndpoints.project_code_list,
    icon: "list_details"
  },
  purchaseorder: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "KxySMG"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "85Yvr2"
      }
    ),
    url_overview: "/purchasing/index/purchaseorders",
    url_detail: "/purchasing/purchase-order/:pk/",
    api_endpoint: ApiEndpoints.purchase_order_list,
    admin_url: "/order/purchaseorder/",
    supports_barcode: true,
    icon: "purchase_orders"
  },
  purchaseorderlineitem: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "Enr0Pf"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "MXjnQS"
      }
    ),
    api_endpoint: ApiEndpoints.purchase_order_line_list,
    icon: "purchase_orders"
  },
  salesorder: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "LozYBo"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "B1TL+X"
      }
    ),
    url_overview: "/sales/index/salesorders",
    url_detail: "/sales/sales-order/:pk/",
    api_endpoint: ApiEndpoints.sales_order_list,
    admin_url: "/order/salesorder/",
    supports_barcode: true,
    icon: "sales_orders"
  },
  salesordershipment: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "qGSobR"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "D/EkfS"
      }
    ),
    url_overview: "/sales/index/shipments",
    url_detail: "/sales/shipment/:pk/",
    api_endpoint: ApiEndpoints.sales_order_shipment_list,
    supports_barcode: true,
    icon: "shipment"
  },
  returnorder: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "Z6ve1w"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "LlTg8M"
      }
    ),
    url_overview: "/sales/index/returnorders",
    url_detail: "/sales/return-order/:pk/",
    api_endpoint: ApiEndpoints.return_order_list,
    admin_url: "/order/returnorder/",
    supports_barcode: true,
    icon: "return_orders"
  },
  returnorderlineitem: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "Frsz7D"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "4dCpFa"
      }
    ),
    api_endpoint: ApiEndpoints.return_order_line_list,
    icon: "return_orders"
  },
  address: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "Du6bPw"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "bYmAV1"
      }
    ),
    url_detail: "/address/:pk/",
    api_endpoint: ApiEndpoints.address_list,
    icon: "address"
  },
  contact: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "jfC/xh"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "gVfVfe"
      }
    ),
    url_detail: "/contact/:pk/",
    api_endpoint: ApiEndpoints.contact_list,
    icon: "group"
  },
  owner: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "LtI9AS"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "CYRJEX"
      }
    ),
    url_detail: "/owner/:pk/",
    api_endpoint: ApiEndpoints.owner_list,
    icon: "group"
  },
  user: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "7PzzBU"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "Sxm8rQ"
      }
    ),
    url_detail: "/core/user/:pk/",
    api_endpoint: ApiEndpoints.user_list,
    icon: "user"
  },
  group: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "L8fEEm"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "zhrjek"
      }
    ),
    url_detail: "/core/group/:pk/",
    api_endpoint: ApiEndpoints.group_list,
    admin_url: "/auth/group/",
    icon: "group"
  },
  importsession: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "e5WBGh"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "1dn8uK"
      }
    ),
    url_overview: "/settings/admin/import",
    url_detail: "/import/:pk/",
    api_endpoint: ApiEndpoints.import_session_list,
    icon: "import"
  },
  labeltemplate: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "aKf3M5"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "0qHiFS"
      }
    ),
    url_overview: "/settings/admin/labels",
    url_detail: "/settings/admin/labels/:pk/",
    api_endpoint: ApiEndpoints.label_list,
    icon: "labels"
  },
  reporttemplate: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "F/A+39"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "SX006I"
      }
    ),
    url_overview: "/settings/admin/reports",
    url_detail: "/settings/admin/reports/:pk/",
    api_endpoint: ApiEndpoints.report_list,
    icon: "reports"
  },
  pluginconfig: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "BFm1Jm"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "7ybWp/"
      }
    ),
    url_overview: "/settings/admin/plugin",
    url_detail: "/settings/admin/plugin/:pk/",
    api_endpoint: ApiEndpoints.plugin_list,
    icon: "plugin"
  },
  contenttype: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "f9cDxV"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "F7Jcuy"
      }
    ),
    api_endpoint: ApiEndpoints.content_type_list,
    icon: "list_details"
  },
  selectionlist: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "ifEZiy"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "2q2/qs"
      }
    ),
    url_overview: "/settings/admin/part-parameters",
    api_endpoint: ApiEndpoints.selectionlist_list,
    icon: "list_details"
  },
  error: {
    label: () => _i18n$4._(
      /*i18n*/
      {
        id: "SlfejT"
      }
    ),
    label_multiple: () => _i18n$4._(
      /*i18n*/
      {
        id: "UirGxE"
      }
    ),
    api_endpoint: ApiEndpoints.error_report_list,
    url_overview: "/settings/admin/errors",
    url_detail: "/settings/admin/errors/:pk/",
    icon: "exclamation"
  }
};
function cancelEvent(event) {
  var _a2;
  event == null ? void 0 : event.preventDefault();
  event == null ? void 0 : event.stopPropagation();
  (_a2 = event == null ? void 0 : event.nativeEvent) == null ? void 0 : _a2.stopImmediatePropagation();
}
const getBaseUrl = () => {
  var _a2;
  return ((_a2 = window.INVENTREE_SETTINGS) == null ? void 0 : _a2.base_url) || "web";
};
function getDetailUrl(model, pk, absolute) {
  const modelInfo = ModelInformationDict[model];
  if (pk === void 0 || pk === null) {
    return "";
  }
  if (!!pk && modelInfo && modelInfo.url_detail) {
    const url = modelInfo.url_detail.replace(":pk", pk.toString());
    getBaseUrl();
    {
      return url;
    }
  }
  console.error(`No detail URL found for model ${model} <${pk}>`);
  return "";
}
const navigateToLink = (link, navigate, event) => {
  cancelEvent(event);
  const base = `/${getBaseUrl()}`;
  if (eventModified(event)) {
    let url = link;
    if (link.startsWith("/") && !link.startsWith(base)) {
      url = `${base}${link}`;
    }
    window.open(url, "_blank");
  } else {
    let url = link;
    if (link.startsWith(base)) {
      url = link.replace(base, "");
    }
    navigate(url);
  }
};
const eventModified = (event) => {
  return (event == null ? void 0 : event.ctrlKey) || (event == null ? void 0 : event.shiftKey) || (event == null ? void 0 : event.metaKey);
};
function checkPluginVersion(context) {
  var _a2;
  const systemVersion = ((_a2 = context == null ? void 0 : context.version) == null ? void 0 : _a2.inventree) || "";
  if (INVENTREE_PLUGIN_VERSION != systemVersion) {
    console.info(`Plugin version mismatch! Expected version ${INVENTREE_PLUGIN_VERSION}, got ${systemVersion}`);
  }
}
function formatDecimal(value, options = {}) {
  const locale = options.locale || navigator.language || "en-US";
  if (value === null || value === void 0) {
    return value;
  }
  try {
    const formatter = new Intl.NumberFormat(locale, {
      style: "decimal",
      maximumFractionDigits: options.digits ?? 6,
      minimumFractionDigits: options.minDigits ?? 0
    });
    return formatter.format(value);
  } catch (e) {
    console.error("Error formatting decimal:", e);
    return value;
  }
}
function formatCurrencyValue(value, options = {}) {
  if (value == null || value == void 0) {
    return null;
  }
  value = Number.parseFloat(value.toString());
  if (Number.isNaN(value) || !Number.isFinite(value)) {
    return null;
  }
  value *= options.multiplier ?? 1;
  const locale = options.locale || navigator.language || "en-US";
  const minDigits = options.minDigits ?? 0;
  const maxDigits = options.digits ?? 6;
  try {
    const formatter = new Intl.NumberFormat(locale, {
      style: "currency",
      currency: options.currency || "USD",
      maximumFractionDigits: Math.max(minDigits, maxDigits),
      minimumFractionDigits: Math.min(minDigits, maxDigits)
    });
    return formatter.format(value);
  } catch (e) {
    console.error("Error formatting currency:", e);
    return value;
  }
}
var jsxRuntime$1 = { exports: {} };
var reactJsxRuntime_production$1 = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReactJsxRuntime_production$1;
function requireReactJsxRuntime_production$1() {
  if (hasRequiredReactJsxRuntime_production$1) return reactJsxRuntime_production$1;
  hasRequiredReactJsxRuntime_production$1 = 1;
  var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
  function jsxProd(type, config, maybeKey) {
    var key = null;
    void 0 !== maybeKey && (key = "" + maybeKey);
    void 0 !== config.key && (key = "" + config.key);
    if ("key" in config) {
      maybeKey = {};
      for (var propName in config)
        "key" !== propName && (maybeKey[propName] = config[propName]);
    } else maybeKey = config;
    config = maybeKey.ref;
    return {
      $$typeof: REACT_ELEMENT_TYPE,
      type,
      key,
      ref: void 0 !== config ? config : null,
      props: maybeKey
    };
  }
  reactJsxRuntime_production$1.Fragment = REACT_FRAGMENT_TYPE;
  reactJsxRuntime_production$1.jsx = jsxProd;
  reactJsxRuntime_production$1.jsxs = jsxProd;
  return reactJsxRuntime_production$1;
}
var hasRequiredJsxRuntime$1;
function requireJsxRuntime$1() {
  if (hasRequiredJsxRuntime$1) return jsxRuntime$1.exports;
  hasRequiredJsxRuntime$1 = 1;
  {
    jsxRuntime$1.exports = requireReactJsxRuntime_production$1();
  }
  return jsxRuntime$1.exports;
}
var jsxRuntimeExports$1 = requireJsxRuntime$1();
function isTrue(value) {
  if (value === true) {
    return true;
  }
  if (value === false) {
    return false;
  }
  const s = String(value).trim().toLowerCase();
  return ["true", "yes", "1", "on", "t", "y"].includes(s);
}
function identifierString(value) {
  value = value || "-";
  return value.toLowerCase().replace(/[^a-z0-9]/g, "-");
}
const ActionIcon$1 = window["MantineCore"].ActionIcon;
const Group$1 = window["MantineCore"].Group;
const Tooltip$1 = window["MantineCore"].Tooltip;
function ActionButton(props) {
  const hidden = props.hidden ?? false;
  return !hidden && /* @__PURE__ */ jsxRuntimeExports$1.jsx(Tooltip$1, { disabled: !props.tooltip && !props.text, label: props.tooltip ?? props.text, position: props.tooltipAlignment ?? "left", children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(ActionIcon$1, { disabled: props.disabled, p: 17, radius: props.radius ?? "xs", color: props.color, size: props.size, "aria-label": `action-button-${identifierString(props.tooltip ?? props.text ?? "")}`, onClick: (event) => {
    props.onClick(event);
  }, variant: props.variant ?? "transparent", children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(Group$1, { gap: "xs", wrap: "nowrap", children: props.icon }) }, `action-icon-${props.tooltip ?? props.text}`) }, `tooltip-${props.tooltip ?? props.text}`);
}
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
var defaultAttributes$1 = {
  outline: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  },
  filled: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    stroke: "none"
  }
};
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const forwardRef$1 = window["React"].forwardRef;
const createElement$1 = window["React"].createElement;
const createReactComponent$1 = (type, iconName, iconNamePascal, iconNode) => {
  const Component = forwardRef$1(
    ({ color = "currentColor", size = 24, stroke = 2, title, className, children, ...rest }, ref) => createElement$1(
      "svg",
      {
        ref,
        ...defaultAttributes$1[type],
        width: size,
        height: size,
        className: [`tabler-icon`, `tabler-icon-${iconName}`, className].join(" "),
        ...{
          strokeWidth: stroke,
          stroke: color
        },
        ...rest
      },
      [
        title && createElement$1("title", { key: "svg-title" }, title),
        ...iconNode.map(([tag, attrs]) => createElement$1(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    )
  );
  Component.displayName = `${iconNamePascal}`;
  return Component;
};
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$e = [["path", { "d": "M12 5l0 14", "key": "svg-0" }], ["path", { "d": "M5 12l14 0", "key": "svg-1" }]];
const IconPlus = createReactComponent$1("outline", "plus", "Plus", __iconNode$e);
function AddItemButton(props) {
  return /* @__PURE__ */ jsxRuntimeExports$1.jsx(ActionButton, { ...props, color: "green", icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconPlus, {}) });
}
window["MantineCore"].ActionIcon;
window["MantineCore"].Menu;
window["MantineCore"].Tooltip;
const Group = window["MantineCore"].Group;
const Progress = window["MantineCore"].Progress;
const Stack = window["MantineCore"].Stack;
const Text = window["MantineCore"].Text;
const useMemo$4 = window["React"].useMemo;
function ProgressBar(props) {
  const progress = useMemo$4(() => {
    const maximum = props.maximum ?? 100;
    const value = Math.max(props.value, 0);
    if (maximum == 0) {
      return 0;
    }
    return value / maximum * 100;
  }, [props]);
  return /* @__PURE__ */ jsxRuntimeExports$1.jsxs(Stack, { gap: 2, style: {
    flexGrow: 1,
    minWidth: "100px"
  }, children: [
    props.progressLabel && /* @__PURE__ */ jsxRuntimeExports$1.jsxs(Group, { gap: "xs", justify: "center", children: [
      /* @__PURE__ */ jsxRuntimeExports$1.jsxs(Text, { ta: "center", size: "xs", children: [
        formatDecimal(props.value),
        " / ",
        formatDecimal(props.maximum)
      ] }),
      props.units && /* @__PURE__ */ jsxRuntimeExports$1.jsxs(Text, { size: "xs", children: [
        "[",
        props.units,
        "]"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports$1.jsx(Progress, { value: progress, color: progress < 100 ? "orange" : progress > 100 ? "blue" : "green", size: props.size ?? "md", radius: "sm", animated: props.animated })
  ] });
}
const _i18n$3 = window["LinguiCore"].i18n;
const Badge = window["MantineCore"].Badge;
window["MantineCore"].Skeleton;
function PassFailButton({
  value,
  passText,
  failText,
  passColor,
  failColor
}) {
  const v2 = isTrue(value);
  const pass = passText ?? _i18n$3._(
    /*i18n*/
    {
      id: "wFwgKk"
    }
  );
  const fail = failText ?? _i18n$3._(
    /*i18n*/
    {
      id: "qcloGZ"
    }
  );
  const pColor = passColor ?? "green";
  const fColor = failColor ?? "red";
  return /* @__PURE__ */ jsxRuntimeExports$1.jsx(Badge, { color: v2 ? pColor : fColor, variant: "filled", radius: "lg", size: "sm", style: {
    maxWidth: "50px"
  }, children: v2 ? pass : fail });
}
function YesNoButton({
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports$1.jsx(PassFailButton, { value, passText: _i18n$3._(
    /*i18n*/
    {
      id: "l75CjT"
    }
  ), failText: _i18n$3._(
    /*i18n*/
    {
      id: "1UzENP"
    }
  ), failColor: "orange.6" });
}
const useState$8 = window["React"].useState;
const useRef$5 = window["React"].useRef;
const useCallback$4 = window["React"].useCallback;
const useEffect$b = window["React"].useEffect;
function useDebouncedValue(value, wait, options = { leading: false }) {
  const [_value, setValue] = useState$8(value);
  const mountedRef = useRef$5(false);
  const timeoutRef = useRef$5(null);
  const cooldownRef = useRef$5(false);
  const cancel = useCallback$4(() => window.clearTimeout(timeoutRef.current), []);
  useEffect$b(() => {
    if (mountedRef.current) {
      if (!cooldownRef.current && options.leading) {
        cooldownRef.current = true;
        setValue(value);
      } else {
        cancel();
        timeoutRef.current = window.setTimeout(() => {
          cooldownRef.current = false;
          setValue(value);
        }, wait);
      }
    }
  }, [value, options.leading, wait]);
  useEffect$b(() => {
    mountedRef.current = true;
    return cancel;
  }, []);
  return [_value, cancel];
}
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$d = [["path", { "d": "M3 10a7 7 0 1 0 14 0a7 7 0 1 0 -14 0", "key": "svg-0" }], ["path", { "d": "M21 21l-6 -6", "key": "svg-1" }]];
const IconSearch = createReactComponent$1("outline", "search", "Search", __iconNode$d);
const _i18n$2 = window["LinguiCore"].i18n;
const CloseButton = window["MantineCore"].CloseButton;
const TextInput = window["MantineCore"].TextInput;
const useEffect$a = window["React"].useEffect;
const useState$7 = window["React"].useState;
function SearchInput({
  disabled,
  debounce,
  placeholder,
  searchCallback
}) {
  const [value, setValue] = useState$7("");
  const [searchText] = useDebouncedValue(value, debounce ?? 500);
  useEffect$a(() => {
    searchCallback(searchText);
  }, [searchText]);
  return /* @__PURE__ */ jsxRuntimeExports$1.jsx(TextInput, { value, disabled, "aria-label": "table-search-input", leftSection: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconSearch, {}), placeholder: placeholder ?? _i18n$2._(
    /*i18n*/
    {
      id: "A1taO8"
    }
  ), onChange: (event) => setValue(event.target.value), rightSection: value.length > 0 ? /* @__PURE__ */ jsxRuntimeExports$1.jsx(CloseButton, { size: "xs", onClick: () => {
    setValue("");
    searchCallback("");
  } }) : null });
}
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$c = [["path", { "d": "M4 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "key": "svg-0" }], ["path", { "d": "M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "key": "svg-1" }], ["path", { "d": "M18 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "key": "svg-2" }]];
const IconDots = createReactComponent$1("outline", "dots", "Dots", __iconNode$c);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$b = [["path", { "d": "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M10 10l4 4m0 -4l-4 4", "key": "svg-1" }]];
createReactComponent$1("outline", "circle-x", "CircleX", __iconNode$b);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$a = [["path", { "d": "M4 7l16 0", "key": "svg-0" }], ["path", { "d": "M10 11l0 6", "key": "svg-1" }], ["path", { "d": "M14 11l0 6", "key": "svg-2" }], ["path", { "d": "M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12", "key": "svg-3" }], ["path", { "d": "M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3", "key": "svg-4" }]];
const IconTrash = createReactComponent$1("outline", "trash", "Trash", __iconNode$a);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$9 = [["path", { "d": "M7 9.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667l0 -8.666", "key": "svg-0" }], ["path", { "d": "M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1", "key": "svg-1" }]];
const IconCopy = createReactComponent$1("outline", "copy", "Copy", __iconNode$9);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$8 = [["path", { "d": "M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1", "key": "svg-0" }], ["path", { "d": "M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415", "key": "svg-1" }], ["path", { "d": "M16 5l3 3", "key": "svg-2" }]];
const IconEdit = createReactComponent$1("outline", "edit", "Edit", __iconNode$8);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$7 = [["path", { "d": "M5 12l14 0", "key": "svg-0" }], ["path", { "d": "M13 18l6 -6", "key": "svg-1" }], ["path", { "d": "M13 6l6 6", "key": "svg-2" }]];
const IconArrowRight = createReactComponent$1("outline", "arrow-right", "ArrowRight", __iconNode$7);
const _i18n$1 = window["LinguiCore"].i18n;
const ActionIcon = window["MantineCore"].ActionIcon;
const Menu = window["MantineCore"].Menu;
const Tooltip = window["MantineCore"].Tooltip;
const useMemo$3 = window["React"].useMemo;
const useState$6 = window["React"].useState;
function RowViewAction(props) {
  return {
    ...props,
    color: void 0,
    icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconArrowRight, {}),
    onClick: (event) => {
      const url = getDetailUrl(props.modelType, props.modelId);
      navigateToLink(url, props.navigate, event);
    }
  };
}
function RowDuplicateAction(props) {
  return {
    ...props,
    title: _i18n$1._(
      /*i18n*/
      {
        id: "euc6Ns"
      }
    ),
    color: "green",
    icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconCopy, {})
  };
}
function RowEditAction(props) {
  return {
    ...props,
    title: _i18n$1._(
      /*i18n*/
      {
        id: "ePK91l"
      }
    ),
    color: "blue",
    icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconEdit, {})
  };
}
function RowDeleteAction(props) {
  return {
    ...props,
    title: _i18n$1._(
      /*i18n*/
      {
        id: "cnGeoo"
      }
    ),
    color: "red",
    icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconTrash, {})
  };
}
function RowActions({
  title,
  actions,
  disabled = false,
  index
}) {
  function openMenu(event) {
    cancelEvent(event);
    setOpened(!opened);
  }
  const [opened, setOpened] = useState$6(false);
  const visibleActions = useMemo$3(() => {
    return actions.filter((action) => !action.hidden);
  }, [actions]);
  function RowActionIcon(action) {
    return /* @__PURE__ */ jsxRuntimeExports$1.jsx(Tooltip, { withinPortal: true, label: action.tooltip ?? action.title, position: "left", children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(Menu.Item, { color: action.color, leftSection: action.icon, onClick: (event) => {
      var _a2;
      cancelEvent(event);
      (_a2 = action.onClick) == null ? void 0 : _a2.call(action, event);
      setOpened(false);
    }, disabled: action.disabled || false, children: action.title }) }, action.title);
  }
  return visibleActions.length > 0 && /* @__PURE__ */ jsxRuntimeExports$1.jsxs(Menu, { withinPortal: true, disabled, position: "bottom-end", opened, onChange: setOpened, children: [
    /* @__PURE__ */ jsxRuntimeExports$1.jsx(Menu.Target, { children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(Tooltip, { withinPortal: true, label: title || _i18n$1._(
      /*i18n*/
      {
        id: "7L01XJ"
      }
    ), children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(ActionIcon, { "aria-label": `row-action-menu-${index ?? ""}`, onClick: openMenu, disabled, variant: "subtle", color: "gray", children: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconDots, {}) }, `row-action-menu-${index ?? ""}`) }) }),
    /* @__PURE__ */ jsxRuntimeExports$1.jsx(Menu.Dropdown, { children: visibleActions.map((action) => /* @__PURE__ */ jsxRuntimeExports$1.jsx(RowActionIcon, { ...action }, action.title)) })
  ] });
}
var Subscribable$1 = class Subscribable {
  constructor() {
    this.listeners = /* @__PURE__ */ new Set();
    this.subscribe = this.subscribe.bind(this);
  }
  subscribe(listener) {
    this.listeners.add(listener);
    this.onSubscribe();
    return () => {
      this.listeners.delete(listener);
      this.onUnsubscribe();
    };
  }
  hasListeners() {
    return this.listeners.size > 0;
  }
  onSubscribe() {
  }
  onUnsubscribe() {
  }
};
var FocusManager$1 = (_a = class extends Subscribable$1 {
  constructor() {
    super();
    __privateAdd(this, _focused);
    __privateAdd(this, _cleanup);
    __privateAdd(this, _setup);
    __privateSet(this, _setup, (onFocus) => {
      if (typeof window !== "undefined" && window.addEventListener) {
        const listener = () => onFocus();
        window.addEventListener("visibilitychange", listener, false);
        return () => {
          window.removeEventListener("visibilitychange", listener);
        };
      }
      return;
    });
  }
  onSubscribe() {
    if (!__privateGet(this, _cleanup)) {
      this.setEventListener(__privateGet(this, _setup));
    }
  }
  onUnsubscribe() {
    var _a2;
    if (!this.hasListeners()) {
      (_a2 = __privateGet(this, _cleanup)) == null ? void 0 : _a2.call(this);
      __privateSet(this, _cleanup, void 0);
    }
  }
  setEventListener(setup) {
    var _a2;
    __privateSet(this, _setup, setup);
    (_a2 = __privateGet(this, _cleanup)) == null ? void 0 : _a2.call(this);
    __privateSet(this, _cleanup, setup((focused) => {
      if (typeof focused === "boolean") {
        this.setFocused(focused);
      } else {
        this.onFocus();
      }
    }));
  }
  setFocused(focused) {
    const changed = __privateGet(this, _focused) !== focused;
    if (changed) {
      __privateSet(this, _focused, focused);
      this.onFocus();
    }
  }
  onFocus() {
    const isFocused = this.isFocused();
    this.listeners.forEach((listener) => {
      listener(isFocused);
    });
  }
  isFocused() {
    var _a2;
    if (typeof __privateGet(this, _focused) === "boolean") {
      return __privateGet(this, _focused);
    }
    return ((_a2 = globalThis.document) == null ? void 0 : _a2.visibilityState) !== "hidden";
  }
}, _focused = new WeakMap(), _cleanup = new WeakMap(), _setup = new WeakMap(), _a);
var focusManager$1 = new FocusManager$1();
var isServer$1 = typeof window === "undefined" || "Deno" in globalThis;
function noop$1() {
}
function isValidTimeout$1(value) {
  return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale$1(updatedAt, staleTime) {
  return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveStaleTime$1(staleTime, query) {
  return typeof staleTime === "function" ? staleTime(query) : staleTime;
}
function resolveEnabled$1(enabled, query) {
  return typeof enabled === "function" ? enabled(query) : enabled;
}
var hasOwn$1 = Object.prototype.hasOwnProperty;
function replaceEqualDeep$1(a, b, depth = 0) {
  if (a === b) {
    return a;
  }
  if (depth > 500) return b;
  const array = isPlainArray$1(a) && isPlainArray$1(b);
  if (!array && !(isPlainObject$1(a) && isPlainObject$1(b))) return b;
  const aItems = array ? a : Object.keys(a);
  const aSize = aItems.length;
  const bItems = array ? b : Object.keys(b);
  const bSize = bItems.length;
  const copy = array ? new Array(bSize) : {};
  let equalItems = 0;
  for (let i = 0; i < bSize; i++) {
    const key = array ? i : bItems[i];
    const aItem = a[key];
    const bItem = b[key];
    if (aItem === bItem) {
      copy[key] = aItem;
      if (array ? i < aSize : hasOwn$1.call(a, key)) equalItems++;
      continue;
    }
    if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
      copy[key] = bItem;
      continue;
    }
    const v2 = replaceEqualDeep$1(aItem, bItem, depth + 1);
    copy[key] = v2;
    if (v2 === aItem) equalItems++;
  }
  return aSize === bSize && equalItems === aSize ? a : copy;
}
function shallowEqualObjects$1(a, b) {
  if (!b || Object.keys(a).length !== Object.keys(b).length) {
    return false;
  }
  for (const key in a) {
    if (a[key] !== b[key]) {
      return false;
    }
  }
  return true;
}
function isPlainArray$1(value) {
  return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject$1(o) {
  if (!hasObjectPrototype$1(o)) {
    return false;
  }
  const ctor = o.constructor;
  if (ctor === void 0) {
    return true;
  }
  const prot = ctor.prototype;
  if (!hasObjectPrototype$1(prot)) {
    return false;
  }
  if (!prot.hasOwnProperty("isPrototypeOf")) {
    return false;
  }
  if (Object.getPrototypeOf(o) !== Object.prototype) {
    return false;
  }
  return true;
}
function hasObjectPrototype$1(o) {
  return Object.prototype.toString.call(o) === "[object Object]";
}
function replaceData$1(prevData, data, options) {
  if (typeof options.structuralSharing === "function") {
    return options.structuralSharing(prevData, data);
  } else if (options.structuralSharing !== false) {
    return replaceEqualDeep$1(prevData, data);
  }
  return data;
}
function shouldThrowError$1(throwOnError, params) {
  if (typeof throwOnError === "function") {
    return throwOnError(...params);
  }
  return !!throwOnError;
}
var environmentManager = /* @__PURE__ */ (() => {
  let isServerFn = () => isServer$1;
  return {
    /**
     * Returns whether the current runtime should be treated as a server environment.
     */
    isServer() {
      return isServerFn();
    },
    /**
     * Overrides the server check globally.
     */
    setIsServer(isServerValue) {
      isServerFn = isServerValue;
    }
  };
})();
var defaultTimeoutProvider = {
  // We need the wrapper function syntax below instead of direct references to
  // global setTimeout etc.
  //
  // BAD: `setTimeout: setTimeout`
  // GOOD: `setTimeout: (cb, delay) => setTimeout(cb, delay)`
  //
  // If we use direct references here, then anything that wants to spy on or
  // replace the global setTimeout (like tests) won't work since we'll already
  // have a hard reference to the original implementation at the time when this
  // file was imported.
  setTimeout: (callback, delay) => setTimeout(callback, delay),
  clearTimeout: (timeoutId) => clearTimeout(timeoutId),
  setInterval: (callback, delay) => setInterval(callback, delay),
  clearInterval: (intervalId) => clearInterval(intervalId)
};
var TimeoutManager = (_b = class {
  constructor() {
    // We cannot have TimeoutManager<T> as we must instantiate it with a concrete
    // type at app boot; and if we leave that type, then any new timer provider
    // would need to support the default provider's concrete timer ID, which is
    // infeasible across environments.
    //
    // We settle for type safety for the TimeoutProvider type, and accept that
    // this class is unsafe internally to allow for extension.
    __privateAdd(this, _provider, defaultTimeoutProvider);
    __privateAdd(this, _providerCalled, false);
  }
  setTimeoutProvider(provider) {
    __privateSet(this, _provider, provider);
  }
  setTimeout(callback, delay) {
    return __privateGet(this, _provider).setTimeout(callback, delay);
  }
  clearTimeout(timeoutId) {
    __privateGet(this, _provider).clearTimeout(timeoutId);
  }
  setInterval(callback, delay) {
    return __privateGet(this, _provider).setInterval(callback, delay);
  }
  clearInterval(intervalId) {
    __privateGet(this, _provider).clearInterval(intervalId);
  }
}, _provider = new WeakMap(), _providerCalled = new WeakMap(), _b);
var timeoutManager = new TimeoutManager();
function systemSetTimeoutZero(callback) {
  setTimeout(callback, 0);
}
var defaultScheduler$1 = systemSetTimeoutZero;
function createNotifyManager$1() {
  let queue = [];
  let transactions = 0;
  let notifyFn = (callback) => {
    callback();
  };
  let batchNotifyFn = (callback) => {
    callback();
  };
  let scheduleFn = defaultScheduler$1;
  const schedule = (callback) => {
    if (transactions) {
      queue.push(callback);
    } else {
      scheduleFn(() => {
        notifyFn(callback);
      });
    }
  };
  const flush = () => {
    const originalQueue = queue;
    queue = [];
    if (originalQueue.length) {
      scheduleFn(() => {
        batchNotifyFn(() => {
          originalQueue.forEach((callback) => {
            notifyFn(callback);
          });
        });
      });
    }
  };
  return {
    batch: (callback) => {
      let result;
      transactions++;
      try {
        result = callback();
      } finally {
        transactions--;
        if (!transactions) {
          flush();
        }
      }
      return result;
    },
    /**
     * All calls to the wrapped function will be batched.
     */
    batchCalls: (callback) => {
      return (...args) => {
        schedule(() => {
          callback(...args);
        });
      };
    },
    schedule,
    /**
     * Use this method to set a custom notify function.
     * This can be used to for example wrap notifications with `React.act` while running tests.
     */
    setNotifyFunction: (fn) => {
      notifyFn = fn;
    },
    /**
     * Use this method to set a custom function to batch notifications together into a single tick.
     * By default React Query will use the batch function provided by ReactDOM or React Native.
     */
    setBatchNotifyFunction: (fn) => {
      batchNotifyFn = fn;
    },
    setScheduler: (fn) => {
      scheduleFn = fn;
    }
  };
}
var notifyManager$1 = createNotifyManager$1();
var OnlineManager$1 = (_c = class extends Subscribable$1 {
  constructor() {
    super();
    __privateAdd(this, _online, true);
    __privateAdd(this, _cleanup2);
    __privateAdd(this, _setup2);
    __privateSet(this, _setup2, (onOnline) => {
      if (typeof window !== "undefined" && window.addEventListener) {
        const onlineListener = () => onOnline(true);
        const offlineListener = () => onOnline(false);
        window.addEventListener("online", onlineListener, false);
        window.addEventListener("offline", offlineListener, false);
        return () => {
          window.removeEventListener("online", onlineListener);
          window.removeEventListener("offline", offlineListener);
        };
      }
      return;
    });
  }
  onSubscribe() {
    if (!__privateGet(this, _cleanup2)) {
      this.setEventListener(__privateGet(this, _setup2));
    }
  }
  onUnsubscribe() {
    var _a2;
    if (!this.hasListeners()) {
      (_a2 = __privateGet(this, _cleanup2)) == null ? void 0 : _a2.call(this);
      __privateSet(this, _cleanup2, void 0);
    }
  }
  setEventListener(setup) {
    var _a2;
    __privateSet(this, _setup2, setup);
    (_a2 = __privateGet(this, _cleanup2)) == null ? void 0 : _a2.call(this);
    __privateSet(this, _cleanup2, setup(this.setOnline.bind(this)));
  }
  setOnline(online) {
    const changed = __privateGet(this, _online) !== online;
    if (changed) {
      __privateSet(this, _online, online);
      this.listeners.forEach((listener) => {
        listener(online);
      });
    }
  }
  isOnline() {
    return __privateGet(this, _online);
  }
}, _online = new WeakMap(), _cleanup2 = new WeakMap(), _setup2 = new WeakMap(), _c);
var onlineManager$1 = new OnlineManager$1();
function canFetch$1(networkMode) {
  return (networkMode ?? "online") === "online" ? onlineManager$1.isOnline() : true;
}
function fetchState$1(data, options) {
  return {
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchStatus: canFetch$1(options.networkMode) ? "fetching" : "paused",
    ...data === void 0 && {
      error: null,
      status: "pending"
    }
  };
}
function pendingThenable$1() {
  let resolve;
  let reject;
  const thenable = new Promise((_resolve, _reject) => {
    resolve = _resolve;
    reject = _reject;
  });
  thenable.status = "pending";
  thenable.catch(() => {
  });
  function finalize(data) {
    Object.assign(thenable, data);
    delete thenable.resolve;
    delete thenable.reject;
  }
  thenable.resolve = (value) => {
    finalize({
      status: "fulfilled",
      value
    });
    resolve(value);
  };
  thenable.reject = (reason) => {
    finalize({
      status: "rejected",
      reason
    });
    reject(reason);
  };
  return thenable;
}
var QueryObserver$1 = (_d = class extends Subscribable$1 {
  constructor(client, options) {
    super();
    __privateAdd(this, _QueryObserver_instances);
    __privateAdd(this, _client);
    __privateAdd(this, _currentQuery);
    __privateAdd(this, _currentQueryInitialState);
    __privateAdd(this, _currentResult);
    __privateAdd(this, _currentResultState);
    __privateAdd(this, _currentResultOptions);
    __privateAdd(this, _currentThenable);
    __privateAdd(this, _selectError);
    __privateAdd(this, _selectFn);
    __privateAdd(this, _selectResult);
    // This property keeps track of the last query with defined data.
    // It will be used to pass the previous data and query to the placeholder function between renders.
    __privateAdd(this, _lastQueryWithDefinedData);
    __privateAdd(this, _staleTimeoutId);
    __privateAdd(this, _refetchIntervalId);
    __privateAdd(this, _currentRefetchInterval);
    __privateAdd(this, _trackedProps, /* @__PURE__ */ new Set());
    this.options = options;
    __privateSet(this, _client, client);
    __privateSet(this, _selectError, null);
    __privateSet(this, _currentThenable, pendingThenable$1());
    this.bindMethods();
    this.setOptions(options);
  }
  bindMethods() {
    this.refetch = this.refetch.bind(this);
  }
  onSubscribe() {
    if (this.listeners.size === 1) {
      __privateGet(this, _currentQuery).addObserver(this);
      if (shouldFetchOnMount$1(__privateGet(this, _currentQuery), this.options)) {
        __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
      } else {
        this.updateResult();
      }
      __privateMethod(this, _QueryObserver_instances, updateTimers_fn).call(this);
    }
  }
  onUnsubscribe() {
    if (!this.hasListeners()) {
      this.destroy();
    }
  }
  shouldFetchOnReconnect() {
    return shouldFetchOn$1(
      __privateGet(this, _currentQuery),
      this.options,
      this.options.refetchOnReconnect
    );
  }
  shouldFetchOnWindowFocus() {
    return shouldFetchOn$1(
      __privateGet(this, _currentQuery),
      this.options,
      this.options.refetchOnWindowFocus
    );
  }
  destroy() {
    this.listeners = /* @__PURE__ */ new Set();
    __privateMethod(this, _QueryObserver_instances, clearStaleTimeout_fn).call(this);
    __privateMethod(this, _QueryObserver_instances, clearRefetchInterval_fn).call(this);
    __privateGet(this, _currentQuery).removeObserver(this);
  }
  setOptions(options) {
    const prevOptions = this.options;
    const prevQuery = __privateGet(this, _currentQuery);
    this.options = __privateGet(this, _client).defaultQueryOptions(options);
    if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveEnabled$1(this.options.enabled, __privateGet(this, _currentQuery)) !== "boolean") {
      throw new Error(
        "Expected enabled to be a boolean or a callback that returns a boolean"
      );
    }
    __privateMethod(this, _QueryObserver_instances, updateQuery_fn).call(this);
    __privateGet(this, _currentQuery).setOptions(this.options);
    if (prevOptions._defaulted && !shallowEqualObjects$1(this.options, prevOptions)) {
      __privateGet(this, _client).getQueryCache().notify({
        type: "observerOptionsUpdated",
        query: __privateGet(this, _currentQuery),
        observer: this
      });
    }
    const mounted = this.hasListeners();
    if (mounted && shouldFetchOptionally$1(
      __privateGet(this, _currentQuery),
      prevQuery,
      this.options,
      prevOptions
    )) {
      __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
    }
    this.updateResult();
    if (mounted && (__privateGet(this, _currentQuery) !== prevQuery || resolveEnabled$1(this.options.enabled, __privateGet(this, _currentQuery)) !== resolveEnabled$1(prevOptions.enabled, __privateGet(this, _currentQuery)) || resolveStaleTime$1(this.options.staleTime, __privateGet(this, _currentQuery)) !== resolveStaleTime$1(prevOptions.staleTime, __privateGet(this, _currentQuery)))) {
      __privateMethod(this, _QueryObserver_instances, updateStaleTimeout_fn).call(this);
    }
    const nextRefetchInterval = __privateMethod(this, _QueryObserver_instances, computeRefetchInterval_fn).call(this);
    if (mounted && (__privateGet(this, _currentQuery) !== prevQuery || resolveEnabled$1(this.options.enabled, __privateGet(this, _currentQuery)) !== resolveEnabled$1(prevOptions.enabled, __privateGet(this, _currentQuery)) || nextRefetchInterval !== __privateGet(this, _currentRefetchInterval))) {
      __privateMethod(this, _QueryObserver_instances, updateRefetchInterval_fn).call(this, nextRefetchInterval);
    }
  }
  getOptimisticResult(options) {
    const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), options);
    const result = this.createResult(query, options);
    if (shouldAssignObserverCurrentProperties$1(this, result)) {
      __privateSet(this, _currentResult, result);
      __privateSet(this, _currentResultOptions, this.options);
      __privateSet(this, _currentResultState, __privateGet(this, _currentQuery).state);
    }
    return result;
  }
  getCurrentResult() {
    return __privateGet(this, _currentResult);
  }
  trackResult(result, onPropTracked) {
    return new Proxy(result, {
      get: (target, key) => {
        this.trackProp(key);
        onPropTracked == null ? void 0 : onPropTracked(key);
        if (key === "promise") {
          this.trackProp("data");
          if (!this.options.experimental_prefetchInRender && __privateGet(this, _currentThenable).status === "pending") {
            __privateGet(this, _currentThenable).reject(
              new Error(
                "experimental_prefetchInRender feature flag is not enabled"
              )
            );
          }
        }
        return Reflect.get(target, key);
      }
    });
  }
  trackProp(key) {
    __privateGet(this, _trackedProps).add(key);
  }
  getCurrentQuery() {
    return __privateGet(this, _currentQuery);
  }
  refetch({ ...options } = {}) {
    return this.fetch({
      ...options
    });
  }
  fetchOptimistic(options) {
    const defaultedOptions = __privateGet(this, _client).defaultQueryOptions(options);
    const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), defaultedOptions);
    return query.fetch().then(() => this.createResult(query, defaultedOptions));
  }
  fetch(fetchOptions) {
    return __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this, {
      ...fetchOptions,
      cancelRefetch: fetchOptions.cancelRefetch ?? true
    }).then(() => {
      this.updateResult();
      return __privateGet(this, _currentResult);
    });
  }
  createResult(query, options) {
    var _a2;
    const prevQuery = __privateGet(this, _currentQuery);
    const prevOptions = this.options;
    const prevResult = __privateGet(this, _currentResult);
    const prevResultState = __privateGet(this, _currentResultState);
    const prevResultOptions = __privateGet(this, _currentResultOptions);
    const queryChange = query !== prevQuery;
    const queryInitialState = queryChange ? query.state : __privateGet(this, _currentQueryInitialState);
    const { state } = query;
    let newState = { ...state };
    let isPlaceholderData = false;
    let data;
    if (options._optimisticResults) {
      const mounted = this.hasListeners();
      const fetchOnMount = !mounted && shouldFetchOnMount$1(query, options);
      const fetchOptionally = mounted && shouldFetchOptionally$1(query, prevQuery, options, prevOptions);
      if (fetchOnMount || fetchOptionally) {
        newState = {
          ...newState,
          ...fetchState$1(state.data, query.options)
        };
      }
      if (options._optimisticResults === "isRestoring") {
        newState.fetchStatus = "idle";
      }
    }
    let { error, errorUpdatedAt, status } = newState;
    data = newState.data;
    let skipSelect = false;
    if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
      let placeholderData;
      if ((prevResult == null ? void 0 : prevResult.isPlaceholderData) && options.placeholderData === (prevResultOptions == null ? void 0 : prevResultOptions.placeholderData)) {
        placeholderData = prevResult.data;
        skipSelect = true;
      } else {
        placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(
          (_a2 = __privateGet(this, _lastQueryWithDefinedData)) == null ? void 0 : _a2.state.data,
          __privateGet(this, _lastQueryWithDefinedData)
        ) : options.placeholderData;
      }
      if (placeholderData !== void 0) {
        status = "success";
        data = replaceData$1(
          prevResult == null ? void 0 : prevResult.data,
          placeholderData,
          options
        );
        isPlaceholderData = true;
      }
    }
    if (options.select && data !== void 0 && !skipSelect) {
      if (prevResult && data === (prevResultState == null ? void 0 : prevResultState.data) && options.select === __privateGet(this, _selectFn)) {
        data = __privateGet(this, _selectResult);
      } else {
        try {
          __privateSet(this, _selectFn, options.select);
          data = options.select(data);
          data = replaceData$1(prevResult == null ? void 0 : prevResult.data, data, options);
          __privateSet(this, _selectResult, data);
          __privateSet(this, _selectError, null);
        } catch (selectError) {
          __privateSet(this, _selectError, selectError);
        }
      }
    }
    if (__privateGet(this, _selectError)) {
      error = __privateGet(this, _selectError);
      data = __privateGet(this, _selectResult);
      errorUpdatedAt = Date.now();
      status = "error";
    }
    const isFetching = newState.fetchStatus === "fetching";
    const isPending = status === "pending";
    const isError = status === "error";
    const isLoading = isPending && isFetching;
    const hasData = data !== void 0;
    const result = {
      status,
      fetchStatus: newState.fetchStatus,
      isPending,
      isSuccess: status === "success",
      isError,
      isInitialLoading: isLoading,
      isLoading,
      data,
      dataUpdatedAt: newState.dataUpdatedAt,
      error,
      errorUpdatedAt,
      failureCount: newState.fetchFailureCount,
      failureReason: newState.fetchFailureReason,
      errorUpdateCount: newState.errorUpdateCount,
      isFetched: query.isFetched(),
      isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
      isFetching,
      isRefetching: isFetching && !isPending,
      isLoadingError: isError && !hasData,
      isPaused: newState.fetchStatus === "paused",
      isPlaceholderData,
      isRefetchError: isError && hasData,
      isStale: isStale$1(query, options),
      refetch: this.refetch,
      promise: __privateGet(this, _currentThenable),
      isEnabled: resolveEnabled$1(options.enabled, query) !== false
    };
    const nextResult = result;
    if (this.options.experimental_prefetchInRender) {
      const hasResultData = nextResult.data !== void 0;
      const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
      const finalizeThenableIfPossible = (thenable) => {
        if (isErrorWithoutData) {
          thenable.reject(nextResult.error);
        } else if (hasResultData) {
          thenable.resolve(nextResult.data);
        }
      };
      const recreateThenable = () => {
        const pending = __privateSet(this, _currentThenable, nextResult.promise = pendingThenable$1());
        finalizeThenableIfPossible(pending);
      };
      const prevThenable = __privateGet(this, _currentThenable);
      switch (prevThenable.status) {
        case "pending":
          if (query.queryHash === prevQuery.queryHash) {
            finalizeThenableIfPossible(prevThenable);
          }
          break;
        case "fulfilled":
          if (isErrorWithoutData || nextResult.data !== prevThenable.value) {
            recreateThenable();
          }
          break;
        case "rejected":
          if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) {
            recreateThenable();
          }
          break;
      }
    }
    return nextResult;
  }
  updateResult() {
    const prevResult = __privateGet(this, _currentResult);
    const nextResult = this.createResult(__privateGet(this, _currentQuery), this.options);
    __privateSet(this, _currentResultState, __privateGet(this, _currentQuery).state);
    __privateSet(this, _currentResultOptions, this.options);
    if (__privateGet(this, _currentResultState).data !== void 0) {
      __privateSet(this, _lastQueryWithDefinedData, __privateGet(this, _currentQuery));
    }
    if (shallowEqualObjects$1(nextResult, prevResult)) {
      return;
    }
    __privateSet(this, _currentResult, nextResult);
    const shouldNotifyListeners = () => {
      if (!prevResult) {
        return true;
      }
      const { notifyOnChangeProps } = this.options;
      const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
      if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !__privateGet(this, _trackedProps).size) {
        return true;
      }
      const includedProps = new Set(
        notifyOnChangePropsValue ?? __privateGet(this, _trackedProps)
      );
      if (this.options.throwOnError) {
        includedProps.add("error");
      }
      return Object.keys(__privateGet(this, _currentResult)).some((key) => {
        const typedKey = key;
        const changed = __privateGet(this, _currentResult)[typedKey] !== prevResult[typedKey];
        return changed && includedProps.has(typedKey);
      });
    };
    __privateMethod(this, _QueryObserver_instances, notify_fn).call(this, { listeners: shouldNotifyListeners() });
  }
  onQueryUpdate() {
    this.updateResult();
    if (this.hasListeners()) {
      __privateMethod(this, _QueryObserver_instances, updateTimers_fn).call(this);
    }
  }
}, _client = new WeakMap(), _currentQuery = new WeakMap(), _currentQueryInitialState = new WeakMap(), _currentResult = new WeakMap(), _currentResultState = new WeakMap(), _currentResultOptions = new WeakMap(), _currentThenable = new WeakMap(), _selectError = new WeakMap(), _selectFn = new WeakMap(), _selectResult = new WeakMap(), _lastQueryWithDefinedData = new WeakMap(), _staleTimeoutId = new WeakMap(), _refetchIntervalId = new WeakMap(), _currentRefetchInterval = new WeakMap(), _trackedProps = new WeakMap(), _QueryObserver_instances = new WeakSet(), executeFetch_fn = function(fetchOptions) {
  __privateMethod(this, _QueryObserver_instances, updateQuery_fn).call(this);
  let promise = __privateGet(this, _currentQuery).fetch(
    this.options,
    fetchOptions
  );
  if (!(fetchOptions == null ? void 0 : fetchOptions.throwOnError)) {
    promise = promise.catch(noop$1);
  }
  return promise;
}, updateStaleTimeout_fn = function() {
  __privateMethod(this, _QueryObserver_instances, clearStaleTimeout_fn).call(this);
  const staleTime = resolveStaleTime$1(
    this.options.staleTime,
    __privateGet(this, _currentQuery)
  );
  if (environmentManager.isServer() || __privateGet(this, _currentResult).isStale || !isValidTimeout$1(staleTime)) {
    return;
  }
  const time = timeUntilStale$1(__privateGet(this, _currentResult).dataUpdatedAt, staleTime);
  const timeout = time + 1;
  __privateSet(this, _staleTimeoutId, timeoutManager.setTimeout(() => {
    if (!__privateGet(this, _currentResult).isStale) {
      this.updateResult();
    }
  }, timeout));
}, computeRefetchInterval_fn = function() {
  return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(__privateGet(this, _currentQuery)) : this.options.refetchInterval) ?? false;
}, updateRefetchInterval_fn = function(nextInterval) {
  __privateMethod(this, _QueryObserver_instances, clearRefetchInterval_fn).call(this);
  __privateSet(this, _currentRefetchInterval, nextInterval);
  if (environmentManager.isServer() || resolveEnabled$1(this.options.enabled, __privateGet(this, _currentQuery)) === false || !isValidTimeout$1(__privateGet(this, _currentRefetchInterval)) || __privateGet(this, _currentRefetchInterval) === 0) {
    return;
  }
  __privateSet(this, _refetchIntervalId, timeoutManager.setInterval(() => {
    if (this.options.refetchIntervalInBackground || focusManager$1.isFocused()) {
      __privateMethod(this, _QueryObserver_instances, executeFetch_fn).call(this);
    }
  }, __privateGet(this, _currentRefetchInterval)));
}, updateTimers_fn = function() {
  __privateMethod(this, _QueryObserver_instances, updateStaleTimeout_fn).call(this);
  __privateMethod(this, _QueryObserver_instances, updateRefetchInterval_fn).call(this, __privateMethod(this, _QueryObserver_instances, computeRefetchInterval_fn).call(this));
}, clearStaleTimeout_fn = function() {
  if (__privateGet(this, _staleTimeoutId)) {
    timeoutManager.clearTimeout(__privateGet(this, _staleTimeoutId));
    __privateSet(this, _staleTimeoutId, void 0);
  }
}, clearRefetchInterval_fn = function() {
  if (__privateGet(this, _refetchIntervalId)) {
    timeoutManager.clearInterval(__privateGet(this, _refetchIntervalId));
    __privateSet(this, _refetchIntervalId, void 0);
  }
}, updateQuery_fn = function() {
  const query = __privateGet(this, _client).getQueryCache().build(__privateGet(this, _client), this.options);
  if (query === __privateGet(this, _currentQuery)) {
    return;
  }
  const prevQuery = __privateGet(this, _currentQuery);
  __privateSet(this, _currentQuery, query);
  __privateSet(this, _currentQueryInitialState, query.state);
  if (this.hasListeners()) {
    prevQuery == null ? void 0 : prevQuery.removeObserver(this);
    query.addObserver(this);
  }
}, notify_fn = function(notifyOptions) {
  notifyManager$1.batch(() => {
    if (notifyOptions.listeners) {
      this.listeners.forEach((listener) => {
        listener(__privateGet(this, _currentResult));
      });
    }
    __privateGet(this, _client).getQueryCache().notify({
      query: __privateGet(this, _currentQuery),
      type: "observerResultsUpdated"
    });
  });
}, _d);
function shouldLoadOnMount$1(query, options) {
  return resolveEnabled$1(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && options.retryOnMount === false);
}
function shouldFetchOnMount$1(query, options) {
  return shouldLoadOnMount$1(query, options) || query.state.data !== void 0 && shouldFetchOn$1(query, options, options.refetchOnMount);
}
function shouldFetchOn$1(query, options, field) {
  if (resolveEnabled$1(options.enabled, query) !== false && resolveStaleTime$1(options.staleTime, query) !== "static") {
    const value = typeof field === "function" ? field(query) : field;
    return value === "always" || value !== false && isStale$1(query, options);
  }
  return false;
}
function shouldFetchOptionally$1(query, prevQuery, options, prevOptions) {
  return (query !== prevQuery || resolveEnabled$1(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale$1(query, options);
}
function isStale$1(query, options) {
  return resolveEnabled$1(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime$1(options.staleTime, query));
}
function shouldAssignObserverCurrentProperties$1(observer, optimisticResult) {
  if (!shallowEqualObjects$1(observer.getCurrentResult(), optimisticResult)) {
    return true;
  }
  return false;
}
const React$9 = window["React"];
var QueryClientContext$1 = React$9.createContext(
  void 0
);
var useQueryClient$1 = (queryClient) => {
  const client = React$9.useContext(QueryClientContext$1);
  if (queryClient) {
    return queryClient;
  }
  if (!client) {
    throw new Error("No QueryClient set, use QueryClientProvider to set one");
  }
  return client;
};
const React$8 = window["React"];
function createValue$1() {
  let isReset = false;
  return {
    clearReset: () => {
      isReset = false;
    },
    reset: () => {
      isReset = true;
    },
    isReset: () => {
      return isReset;
    }
  };
}
var QueryErrorResetBoundaryContext$1 = React$8.createContext(createValue$1());
var useQueryErrorResetBoundary$1 = () => React$8.useContext(QueryErrorResetBoundaryContext$1);
const React$7 = window["React"];
var ensurePreventErrorBoundaryRetry$1 = (options, errorResetBoundary, query) => {
  const throwOnError = (query == null ? void 0 : query.state.error) && typeof options.throwOnError === "function" ? shouldThrowError$1(options.throwOnError, [query.state.error, query]) : options.throwOnError;
  if (options.suspense || options.experimental_prefetchInRender || throwOnError) {
    if (!errorResetBoundary.isReset()) {
      options.retryOnMount = false;
    }
  }
};
var useClearResetErrorBoundary$1 = (errorResetBoundary) => {
  React$7.useEffect(() => {
    errorResetBoundary.clearReset();
  }, [errorResetBoundary]);
};
var getHasError$1 = ({
  result,
  errorResetBoundary,
  throwOnError,
  query,
  suspense
}) => {
  return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError$1(throwOnError, [result.error, query]));
};
const React$6 = window["React"];
var IsRestoringContext$1 = React$6.createContext(false);
var useIsRestoring$1 = () => React$6.useContext(IsRestoringContext$1);
IsRestoringContext$1.Provider;
var ensureSuspenseTimers$1 = (defaultedOptions) => {
  if (defaultedOptions.suspense) {
    const MIN_SUSPENSE_TIME_MS = 1e3;
    const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
    const originalStaleTime = defaultedOptions.staleTime;
    defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
    if (typeof defaultedOptions.gcTime === "number") {
      defaultedOptions.gcTime = Math.max(
        defaultedOptions.gcTime,
        MIN_SUSPENSE_TIME_MS
      );
    }
  }
};
var willFetch$1 = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
var shouldSuspend$1 = (defaultedOptions, result) => (defaultedOptions == null ? void 0 : defaultedOptions.suspense) && result.isPending;
var fetchOptimistic$1 = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
  errorResetBoundary.clearReset();
});
const React$5 = window["React"];
function useBaseQuery$1(options, Observer, queryClient) {
  var _a2, _b2, _c2, _d2;
  const isRestoring = useIsRestoring$1();
  const errorResetBoundary = useQueryErrorResetBoundary$1();
  const client = useQueryClient$1(queryClient);
  const defaultedOptions = client.defaultQueryOptions(options);
  (_b2 = (_a2 = client.getDefaultOptions().queries) == null ? void 0 : _a2._experimental_beforeQuery) == null ? void 0 : _b2.call(
    _a2,
    defaultedOptions
  );
  const query = client.getQueryCache().get(defaultedOptions.queryHash);
  defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
  ensureSuspenseTimers$1(defaultedOptions);
  ensurePreventErrorBoundaryRetry$1(defaultedOptions, errorResetBoundary, query);
  useClearResetErrorBoundary$1(errorResetBoundary);
  const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
  const [observer] = React$5.useState(
    () => new Observer(
      client,
      defaultedOptions
    )
  );
  const result = observer.getOptimisticResult(defaultedOptions);
  const shouldSubscribe = !isRestoring && options.subscribed !== false;
  React$5.useSyncExternalStore(
    React$5.useCallback(
      (onStoreChange) => {
        const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager$1.batchCalls(onStoreChange)) : noop$1;
        observer.updateResult();
        return unsubscribe;
      },
      [observer, shouldSubscribe]
    ),
    () => observer.getCurrentResult(),
    () => observer.getCurrentResult()
  );
  React$5.useEffect(() => {
    observer.setOptions(defaultedOptions);
  }, [defaultedOptions, observer]);
  if (shouldSuspend$1(defaultedOptions, result)) {
    throw fetchOptimistic$1(defaultedOptions, observer, errorResetBoundary);
  }
  if (getHasError$1({
    result,
    errorResetBoundary,
    throwOnError: defaultedOptions.throwOnError,
    query,
    suspense: defaultedOptions.suspense
  })) {
    throw result.error;
  }
  (_d2 = (_c2 = client.getDefaultOptions().queries) == null ? void 0 : _c2._experimental_afterQuery) == null ? void 0 : _d2.call(
    _c2,
    defaultedOptions,
    result
  );
  if (defaultedOptions.experimental_prefetchInRender && !environmentManager.isServer() && willFetch$1(result, isRestoring)) {
    const promise = isNewCacheEntry ? (
      // Fetch immediately on render in order to ensure `.promise` is resolved even if the component is unmounted
      fetchOptimistic$1(defaultedOptions, observer, errorResetBoundary)
    ) : (
      // subscribe to the "cache promise" so that we can finalize the currentThenable once data comes in
      query == null ? void 0 : query.promise
    );
    promise == null ? void 0 : promise.catch(noop$1).finally(() => {
      observer.updateResult();
    });
  }
  return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
function useQuery$1(options, queryClient) {
  return useBaseQuery$1(options, QueryObserver$1, queryClient);
}
const useState$5 = window["React"].useState;
const useEffect$9 = window["React"].useEffect;
function useDocumentVisibility() {
  const [documentVisibility, setDocumentVisibility] = useState$5("visible");
  useEffect$9(() => {
    setDocumentVisibility(document.visibilityState);
    const listener = () => setDocumentVisibility(document.visibilityState);
    document.addEventListener("visibilitychange", listener);
    return () => document.removeEventListener("visibilitychange", listener);
  }, []);
  return documentVisibility;
}
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$6 = [["path", { "d": "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M12 9v4", "key": "svg-1" }], ["path", { "d": "M12 16v.01", "key": "svg-2" }]];
const IconExclamationCircle$1 = createReactComponent$1("outline", "exclamation-circle", "ExclamationCircle", __iconNode$6);
/**
 * @license @tabler/icons-react v3.40.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$5 = [["path", { "d": "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M9 12l2 2l4 -4", "key": "svg-1" }]];
const IconCircleCheck = createReactComponent$1("outline", "circle-check", "CircleCheck", __iconNode$5);
const _i18n = window["LinguiCore"].i18n;
const notifications = window["MantineNotifications"].notifications;
const showNotification = window["MantineNotifications"].showNotification;
const useEffect$8 = window["React"].useEffect;
const useState$4 = window["React"].useState;
function useMonitorDataOutput(props) {
  const visibility = useDocumentVisibility();
  const [loading, setLoading] = useState$4(false);
  useEffect$8(() => {
    if (!!props.id) {
      setLoading(true);
      showNotification({
        id: `data-output-${props.id}`,
        title: props.title,
        loading: true,
        autoClose: false,
        withCloseButton: false,
        message: /* @__PURE__ */ jsxRuntimeExports$1.jsx(ProgressBar, { size: "lg", value: 0, progressLabel: true })
      });
    } else setLoading(false);
  }, [props.id, props.title]);
  useQuery$1({
    enabled: !!props.id && loading && visibility === "visible",
    refetchInterval: 500,
    queryKey: ["data-output", props.id, props.title],
    queryFn: () => props.api.get(apiUrl(ApiEndpoints.data_output, props.id)).then((response) => {
      var _a2;
      const data = (response == null ? void 0 : response.data) ?? {};
      if (!!data.errors || !!data.error) {
        setLoading(false);
        const error = (data == null ? void 0 : data.error) ?? ((_a2 = data == null ? void 0 : data.errors) == null ? void 0 : _a2.error) ?? _i18n._(
          /*i18n*/
          {
            id: "gzjOvt"
          }
        );
        notifications.update({
          id: `data-output-${props.id}`,
          loading: false,
          icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconExclamationCircle$1, {}),
          autoClose: 2500,
          title: props.title,
          message: error,
          color: "red"
        });
      } else if (data.complete) {
        setLoading(false);
        notifications.update({
          id: `data-output-${props.id}`,
          loading: false,
          autoClose: 2500,
          title: props.title,
          message: _i18n._(
            /*i18n*/
            {
              id: "TCOQbo"
            }
          ),
          color: "green",
          icon: /* @__PURE__ */ jsxRuntimeExports$1.jsx(IconCircleCheck, {})
        });
        if (data.output) {
          const url = data.output;
          const base = props.hostname ?? window.location.origin;
          const downloadUrl = new URL(url, base);
          window.open(downloadUrl.toString(), "_blank");
        }
      } else {
        notifications.update({
          id: `data-output-${props.id}`,
          loading: true,
          autoClose: false,
          withCloseButton: false,
          message: /* @__PURE__ */ jsxRuntimeExports$1.jsx(ProgressBar, { size: "lg", maximum: data.total, value: data.progress, progressLabel: data.total > 0, animated: true })
        });
      }
      return data;
    }).catch((error) => {
      console.error("Error in useMonitorDataOutput:", error);
      setLoading(false);
      notifications.update({
        id: `data-output-${props.id}`,
        loading: false,
        autoClose: 2500,
        title: props.title,
        message: error.message || _i18n._(
          /*i18n*/
          {
            id: "gzjOvt"
          }
        ),
        color: "red"
      });
      return {};
    })
  }, props.queryClient);
}
window["MantineNotifications"].notifications;
window["MantineNotifications"].showNotification;
window["React"].useEffect;
window["React"].useState;
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
var defaultAttributes = {
  outline: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  },
  filled: {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    stroke: "none"
  }
};
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const forwardRef = window["React"].forwardRef;
const createElement = window["React"].createElement;
const createReactComponent = (type, iconName, iconNamePascal, iconNode) => {
  const Component = forwardRef(
    ({ color = "currentColor", size = 24, stroke = 2, title, className, children, ...rest }, ref) => createElement(
      "svg",
      {
        ref,
        ...defaultAttributes[type],
        width: size,
        height: size,
        className: [`tabler-icon`, `tabler-icon-${iconName}`, className].join(" "),
        ...{
          strokeWidth: stroke,
          stroke: color
        },
        ...rest
      },
      [
        title && createElement("title", { key: "svg-title" }, title),
        ...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
        ...Array.isArray(children) ? children : [children]
      ]
    )
  );
  Component.displayName = `${iconNamePascal}`;
  return Component;
};
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$4 = [["path", { "d": "M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0", "key": "svg-0" }], ["path", { "d": "M12 9v4", "key": "svg-1" }], ["path", { "d": "M12 16v.01", "key": "svg-2" }]];
const IconExclamationCircle = createReactComponent("outline", "exclamation-circle", "ExclamationCircle", __iconNode$4);
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$3 = [["path", { "d": "M14 3v4a1 1 0 0 0 1 1h4", "key": "svg-0" }], ["path", { "d": "M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z", "key": "svg-1" }], ["path", { "d": "M12 17v-6", "key": "svg-2" }], ["path", { "d": "M9.5 14.5l2.5 2.5l2.5 -2.5", "key": "svg-3" }]];
const IconFileDownload = createReactComponent("outline", "file-download", "FileDownload", __iconNode$3);
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$2 = [["path", { "d": "M14 3v4a1 1 0 0 0 1 1h4", "key": "svg-0" }], ["path", { "d": "M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z", "key": "svg-1" }], ["path", { "d": "M12 11v6", "key": "svg-2" }], ["path", { "d": "M9.5 13.5l2.5 -2.5l2.5 2.5", "key": "svg-3" }]];
const IconFileUpload = createReactComponent("outline", "file-upload", "FileUpload", __iconNode$2);
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$1 = [["path", { "d": "M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0", "key": "svg-0" }], ["path", { "d": "M12 9h.01", "key": "svg-1" }], ["path", { "d": "M11 12h1v4h1", "key": "svg-2" }]];
const IconInfoCircle = createReactComponent("outline", "info-circle", "InfoCircle", __iconNode$1);
/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode = [["path", { "d": "M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4", "key": "svg-0" }], ["path", { "d": "M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4", "key": "svg-1" }]];
const IconRefresh = createReactComponent("outline", "refresh", "Refresh", __iconNode);
var Subscribable2 = class {
  constructor() {
    this.listeners = /* @__PURE__ */ new Set();
    this.subscribe = this.subscribe.bind(this);
  }
  subscribe(listener) {
    this.listeners.add(listener);
    this.onSubscribe();
    return () => {
      this.listeners.delete(listener);
      this.onUnsubscribe();
    };
  }
  hasListeners() {
    return this.listeners.size > 0;
  }
  onSubscribe() {
  }
  onUnsubscribe() {
  }
};
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {
}
function isValidTimeout(value) {
  return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
  return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveStaleTime(staleTime, query) {
  return typeof staleTime === "function" ? staleTime(query) : staleTime;
}
function resolveEnabled(enabled, query) {
  return typeof enabled === "function" ? enabled(query) : enabled;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b) {
  if (a === b) {
    return a;
  }
  const array = isPlainArray(a) && isPlainArray(b);
  if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
  const aItems = array ? a : Object.keys(a);
  const aSize = aItems.length;
  const bItems = array ? b : Object.keys(b);
  const bSize = bItems.length;
  const copy = array ? new Array(bSize) : {};
  let equalItems = 0;
  for (let i = 0; i < bSize; i++) {
    const key = array ? i : bItems[i];
    const aItem = a[key];
    const bItem = b[key];
    if (aItem === bItem) {
      copy[key] = aItem;
      if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
      continue;
    }
    if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
      copy[key] = bItem;
      continue;
    }
    const v2 = replaceEqualDeep(aItem, bItem);
    copy[key] = v2;
    if (v2 === aItem) equalItems++;
  }
  return aSize === bSize && equalItems === aSize ? a : copy;
}
function shallowEqualObjects(a, b) {
  if (!b || Object.keys(a).length !== Object.keys(b).length) {
    return false;
  }
  for (const key in a) {
    if (a[key] !== b[key]) {
      return false;
    }
  }
  return true;
}
function isPlainArray(value) {
  return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
  if (!hasObjectPrototype(o)) {
    return false;
  }
  const ctor = o.constructor;
  if (ctor === void 0) {
    return true;
  }
  const prot = ctor.prototype;
  if (!hasObjectPrototype(prot)) {
    return false;
  }
  if (!prot.hasOwnProperty("isPrototypeOf")) {
    return false;
  }
  if (Object.getPrototypeOf(o) !== Object.prototype) {
    return false;
  }
  return true;
}
function hasObjectPrototype(o) {
  return Object.prototype.toString.call(o) === "[object Object]";
}
function replaceData(prevData, data, options) {
  if (typeof options.structuralSharing === "function") {
    return options.structuralSharing(prevData, data);
  } else if (options.structuralSharing !== false) {
    return replaceEqualDeep(prevData, data);
  }
  return data;
}
function shouldThrowError(throwOnError, params) {
  if (typeof throwOnError === "function") {
    return throwOnError(...params);
  }
  return !!throwOnError;
}
var FocusManager = (_e = class extends Subscribable2 {
  constructor() {
    super();
    __privateAdd(this, _focused2);
    __privateAdd(this, _cleanup3);
    __privateAdd(this, _setup3);
    __privateSet(this, _setup3, (onFocus) => {
      if (!isServer && window.addEventListener) {
        const listener = () => onFocus();
        window.addEventListener("visibilitychange", listener, false);
        return () => {
          window.removeEventListener("visibilitychange", listener);
        };
      }
      return;
    });
  }
  onSubscribe() {
    if (!__privateGet(this, _cleanup3)) {
      this.setEventListener(__privateGet(this, _setup3));
    }
  }
  onUnsubscribe() {
    var _a2;
    if (!this.hasListeners()) {
      (_a2 = __privateGet(this, _cleanup3)) == null ? void 0 : _a2.call(this);
      __privateSet(this, _cleanup3, void 0);
    }
  }
  setEventListener(setup) {
    var _a2;
    __privateSet(this, _setup3, setup);
    (_a2 = __privateGet(this, _cleanup3)) == null ? void 0 : _a2.call(this);
    __privateSet(this, _cleanup3, setup((focused) => {
      if (typeof focused === "boolean") {
        this.setFocused(focused);
      } else {
        this.onFocus();
      }
    }));
  }
  setFocused(focused) {
    const changed = __privateGet(this, _focused2) !== focused;
    if (changed) {
      __privateSet(this, _focused2, focused);
      this.onFocus();
    }
  }
  onFocus() {
    const isFocused = this.isFocused();
    this.listeners.forEach((listener) => {
      listener(isFocused);
    });
  }
  isFocused() {
    var _a2;
    if (typeof __privateGet(this, _focused2) === "boolean") {
      return __privateGet(this, _focused2);
    }
    return ((_a2 = globalThis.document) == null ? void 0 : _a2.visibilityState) !== "hidden";
  }
}, _focused2 = new WeakMap(), _cleanup3 = new WeakMap(), _setup3 = new WeakMap(), _e);
var focusManager = new FocusManager();
var OnlineManager = (_f = class extends Subscribable2 {
  constructor() {
    super();
    __privateAdd(this, _online2, true);
    __privateAdd(this, _cleanup4);
    __privateAdd(this, _setup4);
    __privateSet(this, _setup4, (onOnline) => {
      if (!isServer && window.addEventListener) {
        const onlineListener = () => onOnline(true);
        const offlineListener = () => onOnline(false);
        window.addEventListener("online", onlineListener, false);
        window.addEventListener("offline", offlineListener, false);
        return () => {
          window.removeEventListener("online", onlineListener);
          window.removeEventListener("offline", offlineListener);
        };
      }
      return;
    });
  }
  onSubscribe() {
    if (!__privateGet(this, _cleanup4)) {
      this.setEventListener(__privateGet(this, _setup4));
    }
  }
  onUnsubscribe() {
    var _a2;
    if (!this.hasListeners()) {
      (_a2 = __privateGet(this, _cleanup4)) == null ? void 0 : _a2.call(this);
      __privateSet(this, _cleanup4, void 0);
    }
  }
  setEventListener(setup) {
    var _a2;
    __privateSet(this, _setup4, setup);
    (_a2 = __privateGet(this, _cleanup4)) == null ? void 0 : _a2.call(this);
    __privateSet(this, _cleanup4, setup(this.setOnline.bind(this)));
  }
  setOnline(online) {
    const changed = __privateGet(this, _online2) !== online;
    if (changed) {
      __privateSet(this, _online2, online);
      this.listeners.forEach((listener) => {
        listener(online);
      });
    }
  }
  isOnline() {
    return __privateGet(this, _online2);
  }
}, _online2 = new WeakMap(), _cleanup4 = new WeakMap(), _setup4 = new WeakMap(), _f);
var onlineManager = new OnlineManager();
function pendingThenable() {
  let resolve;
  let reject;
  const thenable = new Promise((_resolve, _reject) => {
    resolve = _resolve;
    reject = _reject;
  });
  thenable.status = "pending";
  thenable.catch(() => {
  });
  function finalize(data) {
    Object.assign(thenable, data);
    delete thenable.resolve;
    delete thenable.reject;
  }
  thenable.resolve = (value) => {
    finalize({
      status: "fulfilled",
      value
    });
    resolve(value);
  };
  thenable.reject = (reason) => {
    finalize({
      status: "rejected",
      reason
    });
    reject(reason);
  };
  return thenable;
}
function canFetch(networkMode) {
  return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
var defaultScheduler = (cb) => setTimeout(cb, 0);
function createNotifyManager() {
  let queue = [];
  let transactions = 0;
  let notifyFn = (callback) => {
    callback();
  };
  let batchNotifyFn = (callback) => {
    callback();
  };
  let scheduleFn = defaultScheduler;
  const schedule = (callback) => {
    if (transactions) {
      queue.push(callback);
    } else {
      scheduleFn(() => {
        notifyFn(callback);
      });
    }
  };
  const flush = () => {
    const originalQueue = queue;
    queue = [];
    if (originalQueue.length) {
      scheduleFn(() => {
        batchNotifyFn(() => {
          originalQueue.forEach((callback) => {
            notifyFn(callback);
          });
        });
      });
    }
  };
  return {
    batch: (callback) => {
      let result;
      transactions++;
      try {
        result = callback();
      } finally {
        transactions--;
        if (!transactions) {
          flush();
        }
      }
      return result;
    },
    /**
     * All calls to the wrapped function will be batched.
     */
    batchCalls: (callback) => {
      return (...args) => {
        schedule(() => {
          callback(...args);
        });
      };
    },
    schedule,
    /**
     * Use this method to set a custom notify function.
     * This can be used to for example wrap notifications with `React.act` while running tests.
     */
    setNotifyFunction: (fn) => {
      notifyFn = fn;
    },
    /**
     * Use this method to set a custom function to batch notifications together into a single tick.
     * By default React Query will use the batch function provided by ReactDOM or React Native.
     */
    setBatchNotifyFunction: (fn) => {
      batchNotifyFn = fn;
    },
    setScheduler: (fn) => {
      scheduleFn = fn;
    }
  };
}
var notifyManager = createNotifyManager();
function fetchState(data, options) {
  return {
    fetchFailureCount: 0,
    fetchFailureReason: null,
    fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
    ...data === void 0 && {
      error: null,
      status: "pending"
    }
  };
}
var QueryObserver = (_g = class extends Subscribable2 {
  constructor(client, options) {
    super();
    __privateAdd(this, _QueryObserver_instances2);
    __privateAdd(this, _client2);
    __privateAdd(this, _currentQuery2);
    __privateAdd(this, _currentQueryInitialState2);
    __privateAdd(this, _currentResult2);
    __privateAdd(this, _currentResultState2);
    __privateAdd(this, _currentResultOptions2);
    __privateAdd(this, _currentThenable2);
    __privateAdd(this, _selectError2);
    __privateAdd(this, _selectFn2);
    __privateAdd(this, _selectResult2);
    // This property keeps track of the last query with defined data.
    // It will be used to pass the previous data and query to the placeholder function between renders.
    __privateAdd(this, _lastQueryWithDefinedData2);
    __privateAdd(this, _staleTimeoutId2);
    __privateAdd(this, _refetchIntervalId2);
    __privateAdd(this, _currentRefetchInterval2);
    __privateAdd(this, _trackedProps2, /* @__PURE__ */ new Set());
    this.options = options;
    __privateSet(this, _client2, client);
    __privateSet(this, _selectError2, null);
    __privateSet(this, _currentThenable2, pendingThenable());
    this.bindMethods();
    this.setOptions(options);
  }
  bindMethods() {
    this.refetch = this.refetch.bind(this);
  }
  onSubscribe() {
    if (this.listeners.size === 1) {
      __privateGet(this, _currentQuery2).addObserver(this);
      if (shouldFetchOnMount(__privateGet(this, _currentQuery2), this.options)) {
        __privateMethod(this, _QueryObserver_instances2, executeFetch_fn2).call(this);
      } else {
        this.updateResult();
      }
      __privateMethod(this, _QueryObserver_instances2, updateTimers_fn2).call(this);
    }
  }
  onUnsubscribe() {
    if (!this.hasListeners()) {
      this.destroy();
    }
  }
  shouldFetchOnReconnect() {
    return shouldFetchOn(
      __privateGet(this, _currentQuery2),
      this.options,
      this.options.refetchOnReconnect
    );
  }
  shouldFetchOnWindowFocus() {
    return shouldFetchOn(
      __privateGet(this, _currentQuery2),
      this.options,
      this.options.refetchOnWindowFocus
    );
  }
  destroy() {
    this.listeners = /* @__PURE__ */ new Set();
    __privateMethod(this, _QueryObserver_instances2, clearStaleTimeout_fn2).call(this);
    __privateMethod(this, _QueryObserver_instances2, clearRefetchInterval_fn2).call(this);
    __privateGet(this, _currentQuery2).removeObserver(this);
  }
  setOptions(options) {
    const prevOptions = this.options;
    const prevQuery = __privateGet(this, _currentQuery2);
    this.options = __privateGet(this, _client2).defaultQueryOptions(options);
    if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveEnabled(this.options.enabled, __privateGet(this, _currentQuery2)) !== "boolean") {
      throw new Error(
        "Expected enabled to be a boolean or a callback that returns a boolean"
      );
    }
    __privateMethod(this, _QueryObserver_instances2, updateQuery_fn2).call(this);
    __privateGet(this, _currentQuery2).setOptions(this.options);
    if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) {
      __privateGet(this, _client2).getQueryCache().notify({
        type: "observerOptionsUpdated",
        query: __privateGet(this, _currentQuery2),
        observer: this
      });
    }
    const mounted = this.hasListeners();
    if (mounted && shouldFetchOptionally(
      __privateGet(this, _currentQuery2),
      prevQuery,
      this.options,
      prevOptions
    )) {
      __privateMethod(this, _QueryObserver_instances2, executeFetch_fn2).call(this);
    }
    this.updateResult();
    if (mounted && (__privateGet(this, _currentQuery2) !== prevQuery || resolveEnabled(this.options.enabled, __privateGet(this, _currentQuery2)) !== resolveEnabled(prevOptions.enabled, __privateGet(this, _currentQuery2)) || resolveStaleTime(this.options.staleTime, __privateGet(this, _currentQuery2)) !== resolveStaleTime(prevOptions.staleTime, __privateGet(this, _currentQuery2)))) {
      __privateMethod(this, _QueryObserver_instances2, updateStaleTimeout_fn2).call(this);
    }
    const nextRefetchInterval = __privateMethod(this, _QueryObserver_instances2, computeRefetchInterval_fn2).call(this);
    if (mounted && (__privateGet(this, _currentQuery2) !== prevQuery || resolveEnabled(this.options.enabled, __privateGet(this, _currentQuery2)) !== resolveEnabled(prevOptions.enabled, __privateGet(this, _currentQuery2)) || nextRefetchInterval !== __privateGet(this, _currentRefetchInterval2))) {
      __privateMethod(this, _QueryObserver_instances2, updateRefetchInterval_fn2).call(this, nextRefetchInterval);
    }
  }
  getOptimisticResult(options) {
    const query = __privateGet(this, _client2).getQueryCache().build(__privateGet(this, _client2), options);
    const result = this.createResult(query, options);
    if (shouldAssignObserverCurrentProperties(this, result)) {
      __privateSet(this, _currentResult2, result);
      __privateSet(this, _currentResultOptions2, this.options);
      __privateSet(this, _currentResultState2, __privateGet(this, _currentQuery2).state);
    }
    return result;
  }
  getCurrentResult() {
    return __privateGet(this, _currentResult2);
  }
  trackResult(result, onPropTracked) {
    return new Proxy(result, {
      get: (target, key) => {
        this.trackProp(key);
        onPropTracked == null ? void 0 : onPropTracked(key);
        if (key === "promise" && !this.options.experimental_prefetchInRender && __privateGet(this, _currentThenable2).status === "pending") {
          __privateGet(this, _currentThenable2).reject(
            new Error(
              "experimental_prefetchInRender feature flag is not enabled"
            )
          );
        }
        return Reflect.get(target, key);
      }
    });
  }
  trackProp(key) {
    __privateGet(this, _trackedProps2).add(key);
  }
  getCurrentQuery() {
    return __privateGet(this, _currentQuery2);
  }
  refetch({ ...options } = {}) {
    return this.fetch({
      ...options
    });
  }
  fetchOptimistic(options) {
    const defaultedOptions = __privateGet(this, _client2).defaultQueryOptions(options);
    const query = __privateGet(this, _client2).getQueryCache().build(__privateGet(this, _client2), defaultedOptions);
    return query.fetch().then(() => this.createResult(query, defaultedOptions));
  }
  fetch(fetchOptions) {
    return __privateMethod(this, _QueryObserver_instances2, executeFetch_fn2).call(this, {
      ...fetchOptions,
      cancelRefetch: fetchOptions.cancelRefetch ?? true
    }).then(() => {
      this.updateResult();
      return __privateGet(this, _currentResult2);
    });
  }
  createResult(query, options) {
    var _a2;
    const prevQuery = __privateGet(this, _currentQuery2);
    const prevOptions = this.options;
    const prevResult = __privateGet(this, _currentResult2);
    const prevResultState = __privateGet(this, _currentResultState2);
    const prevResultOptions = __privateGet(this, _currentResultOptions2);
    const queryChange = query !== prevQuery;
    const queryInitialState = queryChange ? query.state : __privateGet(this, _currentQueryInitialState2);
    const { state } = query;
    let newState = { ...state };
    let isPlaceholderData = false;
    let data;
    if (options._optimisticResults) {
      const mounted = this.hasListeners();
      const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
      const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
      if (fetchOnMount || fetchOptionally) {
        newState = {
          ...newState,
          ...fetchState(state.data, query.options)
        };
      }
      if (options._optimisticResults === "isRestoring") {
        newState.fetchStatus = "idle";
      }
    }
    let { error, errorUpdatedAt, status } = newState;
    data = newState.data;
    let skipSelect = false;
    if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
      let placeholderData;
      if ((prevResult == null ? void 0 : prevResult.isPlaceholderData) && options.placeholderData === (prevResultOptions == null ? void 0 : prevResultOptions.placeholderData)) {
        placeholderData = prevResult.data;
        skipSelect = true;
      } else {
        placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(
          (_a2 = __privateGet(this, _lastQueryWithDefinedData2)) == null ? void 0 : _a2.state.data,
          __privateGet(this, _lastQueryWithDefinedData2)
        ) : options.placeholderData;
      }
      if (placeholderData !== void 0) {
        status = "success";
        data = replaceData(
          prevResult == null ? void 0 : prevResult.data,
          placeholderData,
          options
        );
        isPlaceholderData = true;
      }
    }
    if (options.select && data !== void 0 && !skipSelect) {
      if (prevResult && data === (prevResultState == null ? void 0 : prevResultState.data) && options.select === __privateGet(this, _selectFn2)) {
        data = __privateGet(this, _selectResult2);
      } else {
        try {
          __privateSet(this, _selectFn2, options.select);
          data = options.select(data);
          data = replaceData(prevResult == null ? void 0 : prevResult.data, data, options);
          __privateSet(this, _selectResult2, data);
          __privateSet(this, _selectError2, null);
        } catch (selectError) {
          __privateSet(this, _selectError2, selectError);
        }
      }
    }
    if (__privateGet(this, _selectError2)) {
      error = __privateGet(this, _selectError2);
      data = __privateGet(this, _selectResult2);
      errorUpdatedAt = Date.now();
      status = "error";
    }
    const isFetching = newState.fetchStatus === "fetching";
    const isPending = status === "pending";
    const isError = status === "error";
    const isLoading = isPending && isFetching;
    const hasData = data !== void 0;
    const result = {
      status,
      fetchStatus: newState.fetchStatus,
      isPending,
      isSuccess: status === "success",
      isError,
      isInitialLoading: isLoading,
      isLoading,
      data,
      dataUpdatedAt: newState.dataUpdatedAt,
      error,
      errorUpdatedAt,
      failureCount: newState.fetchFailureCount,
      failureReason: newState.fetchFailureReason,
      errorUpdateCount: newState.errorUpdateCount,
      isFetched: newState.dataUpdateCount > 0 || newState.errorUpdateCount > 0,
      isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
      isFetching,
      isRefetching: isFetching && !isPending,
      isLoadingError: isError && !hasData,
      isPaused: newState.fetchStatus === "paused",
      isPlaceholderData,
      isRefetchError: isError && hasData,
      isStale: isStale(query, options),
      refetch: this.refetch,
      promise: __privateGet(this, _currentThenable2),
      isEnabled: resolveEnabled(options.enabled, query) !== false
    };
    const nextResult = result;
    if (this.options.experimental_prefetchInRender) {
      const finalizeThenableIfPossible = (thenable) => {
        if (nextResult.status === "error") {
          thenable.reject(nextResult.error);
        } else if (nextResult.data !== void 0) {
          thenable.resolve(nextResult.data);
        }
      };
      const recreateThenable = () => {
        const pending = __privateSet(this, _currentThenable2, nextResult.promise = pendingThenable());
        finalizeThenableIfPossible(pending);
      };
      const prevThenable = __privateGet(this, _currentThenable2);
      switch (prevThenable.status) {
        case "pending":
          if (query.queryHash === prevQuery.queryHash) {
            finalizeThenableIfPossible(prevThenable);
          }
          break;
        case "fulfilled":
          if (nextResult.status === "error" || nextResult.data !== prevThenable.value) {
            recreateThenable();
          }
          break;
        case "rejected":
          if (nextResult.status !== "error" || nextResult.error !== prevThenable.reason) {
            recreateThenable();
          }
          break;
      }
    }
    return nextResult;
  }
  updateResult() {
    const prevResult = __privateGet(this, _currentResult2);
    const nextResult = this.createResult(__privateGet(this, _currentQuery2), this.options);
    __privateSet(this, _currentResultState2, __privateGet(this, _currentQuery2).state);
    __privateSet(this, _currentResultOptions2, this.options);
    if (__privateGet(this, _currentResultState2).data !== void 0) {
      __privateSet(this, _lastQueryWithDefinedData2, __privateGet(this, _currentQuery2));
    }
    if (shallowEqualObjects(nextResult, prevResult)) {
      return;
    }
    __privateSet(this, _currentResult2, nextResult);
    const shouldNotifyListeners = () => {
      if (!prevResult) {
        return true;
      }
      const { notifyOnChangeProps } = this.options;
      const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
      if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !__privateGet(this, _trackedProps2).size) {
        return true;
      }
      const includedProps = new Set(
        notifyOnChangePropsValue ?? __privateGet(this, _trackedProps2)
      );
      if (this.options.throwOnError) {
        includedProps.add("error");
      }
      return Object.keys(__privateGet(this, _currentResult2)).some((key) => {
        const typedKey = key;
        const changed = __privateGet(this, _currentResult2)[typedKey] !== prevResult[typedKey];
        return changed && includedProps.has(typedKey);
      });
    };
    __privateMethod(this, _QueryObserver_instances2, notify_fn2).call(this, { listeners: shouldNotifyListeners() });
  }
  onQueryUpdate() {
    this.updateResult();
    if (this.hasListeners()) {
      __privateMethod(this, _QueryObserver_instances2, updateTimers_fn2).call(this);
    }
  }
}, _client2 = new WeakMap(), _currentQuery2 = new WeakMap(), _currentQueryInitialState2 = new WeakMap(), _currentResult2 = new WeakMap(), _currentResultState2 = new WeakMap(), _currentResultOptions2 = new WeakMap(), _currentThenable2 = new WeakMap(), _selectError2 = new WeakMap(), _selectFn2 = new WeakMap(), _selectResult2 = new WeakMap(), _lastQueryWithDefinedData2 = new WeakMap(), _staleTimeoutId2 = new WeakMap(), _refetchIntervalId2 = new WeakMap(), _currentRefetchInterval2 = new WeakMap(), _trackedProps2 = new WeakMap(), _QueryObserver_instances2 = new WeakSet(), executeFetch_fn2 = function(fetchOptions) {
  __privateMethod(this, _QueryObserver_instances2, updateQuery_fn2).call(this);
  let promise = __privateGet(this, _currentQuery2).fetch(
    this.options,
    fetchOptions
  );
  if (!(fetchOptions == null ? void 0 : fetchOptions.throwOnError)) {
    promise = promise.catch(noop);
  }
  return promise;
}, updateStaleTimeout_fn2 = function() {
  __privateMethod(this, _QueryObserver_instances2, clearStaleTimeout_fn2).call(this);
  const staleTime = resolveStaleTime(
    this.options.staleTime,
    __privateGet(this, _currentQuery2)
  );
  if (isServer || __privateGet(this, _currentResult2).isStale || !isValidTimeout(staleTime)) {
    return;
  }
  const time = timeUntilStale(__privateGet(this, _currentResult2).dataUpdatedAt, staleTime);
  const timeout = time + 1;
  __privateSet(this, _staleTimeoutId2, setTimeout(() => {
    if (!__privateGet(this, _currentResult2).isStale) {
      this.updateResult();
    }
  }, timeout));
}, computeRefetchInterval_fn2 = function() {
  return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval(__privateGet(this, _currentQuery2)) : this.options.refetchInterval) ?? false;
}, updateRefetchInterval_fn2 = function(nextInterval) {
  __privateMethod(this, _QueryObserver_instances2, clearRefetchInterval_fn2).call(this);
  __privateSet(this, _currentRefetchInterval2, nextInterval);
  if (isServer || resolveEnabled(this.options.enabled, __privateGet(this, _currentQuery2)) === false || !isValidTimeout(__privateGet(this, _currentRefetchInterval2)) || __privateGet(this, _currentRefetchInterval2) === 0) {
    return;
  }
  __privateSet(this, _refetchIntervalId2, setInterval(() => {
    if (this.options.refetchIntervalInBackground || focusManager.isFocused()) {
      __privateMethod(this, _QueryObserver_instances2, executeFetch_fn2).call(this);
    }
  }, __privateGet(this, _currentRefetchInterval2)));
}, updateTimers_fn2 = function() {
  __privateMethod(this, _QueryObserver_instances2, updateStaleTimeout_fn2).call(this);
  __privateMethod(this, _QueryObserver_instances2, updateRefetchInterval_fn2).call(this, __privateMethod(this, _QueryObserver_instances2, computeRefetchInterval_fn2).call(this));
}, clearStaleTimeout_fn2 = function() {
  if (__privateGet(this, _staleTimeoutId2)) {
    clearTimeout(__privateGet(this, _staleTimeoutId2));
    __privateSet(this, _staleTimeoutId2, void 0);
  }
}, clearRefetchInterval_fn2 = function() {
  if (__privateGet(this, _refetchIntervalId2)) {
    clearInterval(__privateGet(this, _refetchIntervalId2));
    __privateSet(this, _refetchIntervalId2, void 0);
  }
}, updateQuery_fn2 = function() {
  const query = __privateGet(this, _client2).getQueryCache().build(__privateGet(this, _client2), this.options);
  if (query === __privateGet(this, _currentQuery2)) {
    return;
  }
  const prevQuery = __privateGet(this, _currentQuery2);
  __privateSet(this, _currentQuery2, query);
  __privateSet(this, _currentQueryInitialState2, query.state);
  if (this.hasListeners()) {
    prevQuery == null ? void 0 : prevQuery.removeObserver(this);
    query.addObserver(this);
  }
}, notify_fn2 = function(notifyOptions) {
  notifyManager.batch(() => {
    if (notifyOptions.listeners) {
      this.listeners.forEach((listener) => {
        listener(__privateGet(this, _currentResult2));
      });
    }
    __privateGet(this, _client2).getQueryCache().notify({
      query: __privateGet(this, _currentQuery2),
      type: "observerResultsUpdated"
    });
  });
}, _g);
function shouldLoadOnMount(query, options) {
  return resolveEnabled(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && options.retryOnMount === false);
}
function shouldFetchOnMount(query, options) {
  return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
  if (resolveEnabled(options.enabled, query) !== false && resolveStaleTime(options.staleTime, query) !== "static") {
    const value = typeof field === "function" ? field(query) : field;
    return value === "always" || value !== false && isStale(query, options);
  }
  return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
  return (query !== prevQuery || resolveEnabled(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
  return resolveEnabled(options.enabled, query) !== false && query.isStaleByTime(resolveStaleTime(options.staleTime, query));
}
function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
  if (!shallowEqualObjects(observer.getCurrentResult(), optimisticResult)) {
    return true;
  }
  return false;
}
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var hasRequiredReactJsxRuntime_production;
function requireReactJsxRuntime_production() {
  if (hasRequiredReactJsxRuntime_production) return reactJsxRuntime_production;
  hasRequiredReactJsxRuntime_production = 1;
  var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
  function jsxProd(type, config, maybeKey) {
    var key = null;
    void 0 !== maybeKey && (key = "" + maybeKey);
    void 0 !== config.key && (key = "" + config.key);
    if ("key" in config) {
      maybeKey = {};
      for (var propName in config)
        "key" !== propName && (maybeKey[propName] = config[propName]);
    } else maybeKey = config;
    config = maybeKey.ref;
    return {
      $$typeof: REACT_ELEMENT_TYPE,
      type,
      key,
      ref: void 0 !== config ? config : null,
      props: maybeKey
    };
  }
  reactJsxRuntime_production.Fragment = REACT_FRAGMENT_TYPE;
  reactJsxRuntime_production.jsx = jsxProd;
  reactJsxRuntime_production.jsxs = jsxProd;
  return reactJsxRuntime_production;
}
var hasRequiredJsxRuntime;
function requireJsxRuntime() {
  if (hasRequiredJsxRuntime) return jsxRuntime.exports;
  hasRequiredJsxRuntime = 1;
  {
    jsxRuntime.exports = requireReactJsxRuntime_production();
  }
  return jsxRuntime.exports;
}
var jsxRuntimeExports = requireJsxRuntime();
const React$4 = window["React"];
var QueryClientContext = React$4.createContext(
  void 0
);
var useQueryClient = (queryClient) => {
  const client = React$4.useContext(QueryClientContext);
  if (queryClient) {
    return queryClient;
  }
  if (!client) {
    throw new Error("No QueryClient set, use QueryClientProvider to set one");
  }
  return client;
};
const React$3 = window["React"];
var IsRestoringContext = React$3.createContext(false);
var useIsRestoring = () => React$3.useContext(IsRestoringContext);
IsRestoringContext.Provider;
const React$2 = window["React"];
function createValue() {
  let isReset = false;
  return {
    clearReset: () => {
      isReset = false;
    },
    reset: () => {
      isReset = true;
    },
    isReset: () => {
      return isReset;
    }
  };
}
var QueryErrorResetBoundaryContext = React$2.createContext(createValue());
var useQueryErrorResetBoundary = () => React$2.useContext(QueryErrorResetBoundaryContext);
const React$1 = window["React"];
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary) => {
  if (options.suspense || options.throwOnError || options.experimental_prefetchInRender) {
    if (!errorResetBoundary.isReset()) {
      options.retryOnMount = false;
    }
  }
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
  React$1.useEffect(() => {
    errorResetBoundary.clearReset();
  }, [errorResetBoundary]);
};
var getHasError = ({
  result,
  errorResetBoundary,
  throwOnError,
  query,
  suspense
}) => {
  return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
var ensureSuspenseTimers = (defaultedOptions) => {
  if (defaultedOptions.suspense) {
    const MIN_SUSPENSE_TIME_MS = 1e3;
    const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
    const originalStaleTime = defaultedOptions.staleTime;
    defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
    if (typeof defaultedOptions.gcTime === "number") {
      defaultedOptions.gcTime = Math.max(
        defaultedOptions.gcTime,
        MIN_SUSPENSE_TIME_MS
      );
    }
  }
};
var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
var shouldSuspend = (defaultedOptions, result) => (defaultedOptions == null ? void 0 : defaultedOptions.suspense) && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
  errorResetBoundary.clearReset();
});
const React = window["React"];
function useBaseQuery(options, Observer, queryClient) {
  var _a2, _b2, _c2, _d2, _e2;
  const isRestoring = useIsRestoring();
  const errorResetBoundary = useQueryErrorResetBoundary();
  const client = useQueryClient(queryClient);
  const defaultedOptions = client.defaultQueryOptions(options);
  (_b2 = (_a2 = client.getDefaultOptions().queries) == null ? void 0 : _a2._experimental_beforeQuery) == null ? void 0 : _b2.call(
    _a2,
    defaultedOptions
  );
  defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
  ensureSuspenseTimers(defaultedOptions);
  ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary);
  useClearResetErrorBoundary(errorResetBoundary);
  const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
  const [observer] = React.useState(
    () => new Observer(
      client,
      defaultedOptions
    )
  );
  const result = observer.getOptimisticResult(defaultedOptions);
  const shouldSubscribe = !isRestoring && options.subscribed !== false;
  React.useSyncExternalStore(
    React.useCallback(
      (onStoreChange) => {
        const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
        observer.updateResult();
        return unsubscribe;
      },
      [observer, shouldSubscribe]
    ),
    () => observer.getCurrentResult(),
    () => observer.getCurrentResult()
  );
  React.useEffect(() => {
    observer.setOptions(defaultedOptions);
  }, [defaultedOptions, observer]);
  if (shouldSuspend(defaultedOptions, result)) {
    throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
  }
  if (getHasError({
    result,
    errorResetBoundary,
    throwOnError: defaultedOptions.throwOnError,
    query: client.getQueryCache().get(defaultedOptions.queryHash),
    suspense: defaultedOptions.suspense
  })) {
    throw result.error;
  }
  (_d2 = (_c2 = client.getDefaultOptions().queries) == null ? void 0 : _c2._experimental_afterQuery) == null ? void 0 : _d2.call(
    _c2,
    defaultedOptions,
    result
  );
  if (defaultedOptions.experimental_prefetchInRender && !isServer && willFetch(result, isRestoring)) {
    const promise = isNewCacheEntry ? (
      // Fetch immediately on render in order to ensure `.promise` is resolved even if the component is unmounted
      fetchOptimistic(defaultedOptions, observer, errorResetBoundary)
    ) : (
      // subscribe to the "cache promise" so that we can finalize the currentThenable once data comes in
      (_e2 = client.getQueryCache().get(defaultedOptions.queryHash)) == null ? void 0 : _e2.promise
    );
    promise == null ? void 0 : promise.catch(noop).finally(() => {
      observer.updateResult();
    });
  }
  return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
function useQuery(options, queryClient) {
  return useBaseQuery(options, QueryObserver, queryClient);
}
const useRef$4 = window["React"].useRef;
const useEffect$7 = window["React"].useEffect;
const useMemo$2 = window["React"].useMemo;
function useCallbackRef(callback) {
  const callbackRef = useRef$4(callback);
  useEffect$7(() => {
    callbackRef.current = callback;
  });
  return useMemo$2(() => ((...args) => {
    var _a2;
    return (_a2 = callbackRef.current) == null ? void 0 : _a2.call(callbackRef, ...args);
  }), []);
}
const useRef$3 = window["React"].useRef;
const useMemo$1 = window["React"].useMemo;
const useEffect$6 = window["React"].useEffect;
function useDebouncedCallback(callback, options) {
  const { delay, flushOnUnmount, leading } = { delay: options, flushOnUnmount: false, leading: false };
  const handleCallback = useCallbackRef(callback);
  const debounceTimerRef = useRef$3(0);
  const lastCallback = useMemo$1(() => {
    const currentCallback = Object.assign(
      (...args) => {
        window.clearTimeout(debounceTimerRef.current);
        const isFirstCall = currentCallback._isFirstCall;
        currentCallback._isFirstCall = false;
        function clearTimeoutAndLeadingRef() {
          window.clearTimeout(debounceTimerRef.current);
          debounceTimerRef.current = 0;
          currentCallback._isFirstCall = true;
        }
        if (leading && isFirstCall) {
          handleCallback(...args);
          const resetLeadingState = () => {
            clearTimeoutAndLeadingRef();
          };
          const flush2 = () => {
            if (debounceTimerRef.current !== 0) {
              clearTimeoutAndLeadingRef();
              handleCallback(...args);
            }
          };
          const cancel2 = () => {
            clearTimeoutAndLeadingRef();
          };
          currentCallback.flush = flush2;
          currentCallback.cancel = cancel2;
          debounceTimerRef.current = window.setTimeout(resetLeadingState, delay);
          return;
        }
        if (leading && !isFirstCall) {
          const flush2 = () => {
            if (debounceTimerRef.current !== 0) {
              clearTimeoutAndLeadingRef();
              handleCallback(...args);
            }
          };
          const cancel2 = () => {
            clearTimeoutAndLeadingRef();
          };
          currentCallback.flush = flush2;
          currentCallback.cancel = cancel2;
          const resetLeadingState = () => {
            clearTimeoutAndLeadingRef();
          };
          debounceTimerRef.current = window.setTimeout(resetLeadingState, delay);
          return;
        }
        const flush = () => {
          if (debounceTimerRef.current !== 0) {
            clearTimeoutAndLeadingRef();
            handleCallback(...args);
          }
        };
        const cancel = () => {
          clearTimeoutAndLeadingRef();
        };
        currentCallback.flush = flush;
        currentCallback.cancel = cancel;
        debounceTimerRef.current = window.setTimeout(flush, delay);
      },
      {
        flush: () => {
        },
        cancel: () => {
        },
        _isFirstCall: true
      }
    );
    return currentCallback;
  }, [handleCallback, delay, leading]);
  useEffect$6(
    () => () => {
      if (flushOnUnmount) {
        lastCallback.flush();
      } else {
        lastCallback.cancel();
      }
    },
    [lastCallback, flushOnUnmount]
  );
  return lastCallback;
}
const useRef$2 = window["React"].useRef;
const useEffect$5 = window["React"].useEffect;
const DEFAULT_EVENTS = ["mousedown", "touchstart"];
function useClickOutside(callback, events, nodes) {
  const ref = useRef$2(null);
  const eventsList = DEFAULT_EVENTS;
  useEffect$5(() => {
    const listener = (event) => {
      const { target } = event ?? {};
      if (Array.isArray(nodes)) {
        const shouldIgnore = !document.body.contains(target) && (target == null ? void 0 : target.tagName) !== "HTML";
        const shouldTrigger = nodes.every((node) => !!node && !event.composedPath().includes(node));
        shouldTrigger && !shouldIgnore && callback(event);
      } else if (ref.current && !ref.current.contains(target)) {
        callback(event);
      }
    };
    eventsList.forEach((fn) => document.addEventListener(fn, listener));
    return () => {
      eventsList.forEach((fn) => document.removeEventListener(fn, listener));
    };
  }, [ref, callback, nodes]);
  return ref;
}
const useState$3 = window["React"].useState;
const useEffect$4 = window["React"].useEffect;
function attachMediaListener(query, callback) {
  try {
    query.addEventListener("change", callback);
    return () => query.removeEventListener("change", callback);
  } catch (e) {
    query.addListener(callback);
    return () => query.removeListener(callback);
  }
}
function getInitialValue(query, initialValue) {
  if (typeof window !== "undefined" && "matchMedia" in window) {
    return window.matchMedia(query).matches;
  }
  return false;
}
function useMediaQuery(query, initialValue, { getInitialValueInEffect } = {
  getInitialValueInEffect: true
}) {
  const [matches, setMatches] = useState$3(
    getInitialValueInEffect ? initialValue : getInitialValue(query)
  );
  useEffect$4(() => {
    try {
      const mediaQuery = window.matchMedia(query);
      setMatches(mediaQuery.matches);
      return attachMediaListener(mediaQuery, (event) => setMatches(event.matches));
    } catch (e) {
      return void 0;
    }
  }, [query]);
  return matches || false;
}
const useEffect$3 = window["React"].useEffect;
function useWindowEvent(type, listener, options) {
  useEffect$3(() => {
    window.addEventListener(type, listener, options);
    return () => window.removeEventListener(type, listener, options);
  }, [type, listener]);
}
const useCallback$3 = window["React"].useCallback;
const useState$2 = window["React"].useState;
const useEffect$2 = window["React"].useEffect;
function serializeJSON(value, hookName = "use-local-storage") {
  try {
    return JSON.stringify(value);
  } catch (error) {
    throw new Error(`@mantine/hooks ${hookName}: Failed to serialize the value`);
  }
}
function deserializeJSON(value) {
  try {
    return value && JSON.parse(value);
  } catch {
    return value;
  }
}
function createStorageHandler(type) {
  const getItem = (key) => {
    try {
      return window[type].getItem(key);
    } catch (error) {
      console.warn("use-local-storage: Failed to get value from storage, localStorage is blocked");
      return null;
    }
  };
  const setItem = (key, value) => {
    try {
      window[type].setItem(key, value);
    } catch (error) {
      console.warn("use-local-storage: Failed to set value to storage, localStorage is blocked");
    }
  };
  const removeItem = (key) => {
    try {
      window[type].removeItem(key);
    } catch (error) {
      console.warn(
        "use-local-storage: Failed to remove value from storage, localStorage is blocked"
      );
    }
  };
  return { getItem, setItem, removeItem };
}
function createStorage(type, hookName) {
  const eventName = "mantine-local-storage";
  const { getItem, setItem, removeItem } = createStorageHandler(type);
  return function useStorage({
    key,
    defaultValue,
    getInitialValueInEffect = true,
    sync = true,
    deserialize = deserializeJSON,
    serialize = (value) => serializeJSON(value, hookName)
  }) {
    const readStorageValue = useCallback$3(
      (skipStorage) => {
        let storageBlockedOrSkipped;
        try {
          storageBlockedOrSkipped = typeof window === "undefined" || !(type in window) || window[type] === null || !!skipStorage;
        } catch (_e2) {
          storageBlockedOrSkipped = true;
        }
        if (storageBlockedOrSkipped) {
          return defaultValue;
        }
        const storageValue = getItem(key);
        return storageValue !== null ? deserialize(storageValue) : defaultValue;
      },
      [key, defaultValue]
    );
    const [value, setValue] = useState$2(readStorageValue(getInitialValueInEffect));
    const setStorageValue = useCallback$3(
      (val) => {
        if (val instanceof Function) {
          setValue((current) => {
            const result = val(current);
            setItem(key, serialize(result));
            queueMicrotask(() => {
              window.dispatchEvent(
                new CustomEvent(eventName, { detail: { key, value: val(current) } })
              );
            });
            return result;
          });
        } else {
          setItem(key, serialize(val));
          window.dispatchEvent(new CustomEvent(eventName, { detail: { key, value: val } }));
          setValue(val);
        }
      },
      [key]
    );
    const removeStorageValue = useCallback$3(() => {
      removeItem(key);
      setValue(defaultValue);
      window.dispatchEvent(new CustomEvent(eventName, { detail: { key, value: defaultValue } }));
    }, [key, defaultValue]);
    useWindowEvent("storage", (event) => {
      if (sync) {
        if (event.storageArea === window[type] && event.key === key) {
          setValue(deserialize(event.newValue ?? void 0));
        }
      }
    });
    useWindowEvent(eventName, (event) => {
      if (sync) {
        if (event.detail.key === key) {
          setValue(event.detail.value);
        }
      }
    });
    useEffect$2(() => {
      if (defaultValue !== void 0 && value === void 0) {
        setStorageValue(defaultValue);
      }
    }, [defaultValue, value, setStorageValue]);
    useEffect$2(() => {
      const val = readStorageValue();
      val !== void 0 && setStorageValue(val);
    }, [key]);
    return [value === void 0 ? defaultValue : value, setStorageValue, removeStorageValue];
  };
}
function useLocalStorage(props) {
  return createStorage("localStorage", "use-local-storage")(props);
}
const useCallback$2 = window["React"].useCallback;
function assignRef(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (typeof ref === "object" && ref !== null && "current" in ref) {
    ref.current = value;
  }
}
function mergeRefs(...refs) {
  const cleanupMap = /* @__PURE__ */ new Map();
  return (node) => {
    refs.forEach((ref) => {
      const cleanup = assignRef(ref, node);
      if (cleanup) {
        cleanupMap.set(ref, cleanup);
      }
    });
    if (cleanupMap.size > 0) {
      return () => {
        refs.forEach((ref) => {
          const cleanup = cleanupMap.get(ref);
          if (cleanup && typeof cleanup === "function") {
            cleanup();
          } else {
            assignRef(ref, null);
          }
        });
        cleanupMap.clear();
      };
    }
  };
}
function useMergedRef(...refs) {
  return useCallback$2(mergeRefs(...refs), refs);
}
const useRef$1 = window["React"].useRef;
const useState$1 = window["React"].useState;
const useMemo = window["React"].useMemo;
const useEffect$1 = window["React"].useEffect;
const defaultState = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  top: 0,
  left: 0,
  bottom: 0,
  right: 0
};
function useResizeObserver(options) {
  const frameID = useRef$1(0);
  const ref = useRef$1(null);
  const [rect, setRect] = useState$1(defaultState);
  const observer = useMemo(
    () => typeof window !== "undefined" ? new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) {
        cancelAnimationFrame(frameID.current);
        frameID.current = requestAnimationFrame(() => {
          var _a2, _b2;
          if (ref.current) {
            const boxSize = ((_a2 = entry.borderBoxSize) == null ? void 0 : _a2[0]) || ((_b2 = entry.contentBoxSize) == null ? void 0 : _b2[0]);
            if (boxSize) {
              const width = boxSize.inlineSize;
              const height = boxSize.blockSize;
              setRect({
                width,
                height,
                x: entry.contentRect.x,
                y: entry.contentRect.y,
                top: entry.contentRect.top,
                left: entry.contentRect.left,
                bottom: entry.contentRect.bottom,
                right: entry.contentRect.right
              });
            } else {
              setRect(entry.contentRect);
            }
          }
        });
      }
    }) : null,
    []
  );
  useEffect$1(() => {
    if (ref.current) {
      observer == null ? void 0 : observer.observe(ref.current, options);
    }
    return () => {
      observer == null ? void 0 : observer.disconnect();
      if (frameID.current) {
        cancelAnimationFrame(frameID.current);
      }
    };
  }, [ref.current]);
  return [ref, rect];
}
const useState = window["React"].useState;
const useCallback$1 = window["React"].useCallback;
function useDisclosure(initialState = false, options = {}) {
  const [opened, setOpened] = useState(initialState);
  const open = useCallback$1(() => {
    setOpened((isOpened) => {
      var _a2;
      if (!isOpened) {
        (_a2 = options.onOpen) == null ? void 0 : _a2.call(options);
        return true;
      }
      return isOpened;
    });
  }, [options.onOpen]);
  const close = useCallback$1(() => {
    setOpened((isOpened) => {
      var _a2;
      if (isOpened) {
        (_a2 = options.onClose) == null ? void 0 : _a2.call(options);
        return false;
      }
      return isOpened;
    });
  }, [options.onClose]);
  const toggle = useCallback$1(() => {
    opened ? close() : open();
  }, [close, open, opened]);
  return [opened, { open, close, toggle }];
}
const useRef = window["React"].useRef;
const useCallback = window["React"].useCallback;
const useEffect = window["React"].useEffect;
function useTimeout(callback, delay, options = { autoInvoke: false }) {
  const timeoutRef = useRef(null);
  const start = useCallback(
    (...args) => {
      if (!timeoutRef.current) {
        timeoutRef.current = window.setTimeout(() => {
          callback(args);
          timeoutRef.current = null;
        }, delay);
      }
    },
    [delay]
  );
  const clear = useCallback(() => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);
  useEffect(() => {
    if (options.autoInvoke) {
      start();
    }
    return clear;
  }, [clear, start]);
  return { start, clear };
}
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
const Kr = window["MantineCore"].Box;
const Jr = window["MantineCore"].Table;
const ke = window["React"].useCallback;
const Yr = window["React"].useMemo;
const Ke = window["React"].useState;
const kt = window["React"].useState;
const $a = window["MantineCore"].createSafeContext;
var [Mt, de] = $a("useDataTableColumnsContext must be used within DataTableColumnProvider");
var at = (e) => {
  let { children: t, columnsOrder: o, setColumnsOrder: n, columnsToggle: a, setColumnsToggle: r2, resetColumnsOrder: l, resetColumnsToggle: i, setColumnWidth: s, resetColumnsWidth: d } = e, [m, b] = kt(""), [p, T] = kt("");
  return jsxRuntimeExports.jsx(Mt, { value: { sourceColumn: m, setSourceColumn: b, targetColumn: p, setTargetColumn: T, columnsToggle: a, setColumnsToggle: r2, swapColumns: () => {
    if (!o || !n || !m || !p) return;
    let x = o.indexOf(m), D = o.indexOf(p);
    if (x !== -1 && D !== -1) {
      let S = o.splice(x, 1)[0];
      o.splice(D, 0, S), n([...o]);
    }
  }, resetColumnsOrder: l, resetColumnsToggle: i, setColumnWidth: s, resetColumnsWidth: d }, children: t });
};
function Nt() {
  return jsxRuntimeExports.jsx("tr", { className: "mantine-datatable-empty-row", children: jsxRuntimeExports.jsx("td", {}) });
}
const Za = window["MantineCore"].Center;
const Ya = window["MantineCore"].Text;
function Lt() {
  return jsxRuntimeExports.jsxs("svg", { width: "24", height: "24", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M12.983 8.978c3.955 -.182 7.017 -1.446 7.017 -2.978c0 -1.657 -3.582 -3 -8 -3c-1.661 0 -3.204 .19 -4.483 .515m-2.783 1.228c-.471 .382 -.734 .808 -.734 1.257c0 1.22 1.944 2.271 4.734 2.74" }), jsxRuntimeExports.jsx("path", { d: "M4 6v6c0 1.657 3.582 3 8 3c.986 0 1.93 -.067 2.802 -.19m3.187 -.82c1.251 -.53 2.011 -1.228 2.011 -1.99v-6" }), jsxRuntimeExports.jsx("path", { d: "M4 12v6c0 1.657 3.582 3 8 3c3.217 0 5.991 -.712 7.261 -1.74m.739 -3.26v-4" }), jsxRuntimeExports.jsx("path", { d: "M3 3l18 18" })] });
}
function Ht({ icon: e, text: t, pt: o, pb: n, active: a, children: r2 }) {
  return jsxRuntimeExports.jsx(Za, { pt: o, pb: n, className: "mantine-datatable-empty-state", "data-active": a || void 0, children: r2 || jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [e || jsxRuntimeExports.jsx("div", { className: "mantine-datatable-empty-state-icon", children: jsxRuntimeExports.jsx(Lt, {}) }), jsxRuntimeExports.jsx(Ya, { component: "div", size: "sm", c: "dimmed", children: t })] }) });
}
const wn = window["MantineCore"].TableTfoot;
const Sn = window["MantineCore"].TableTr;
const Pn = window["MantineCore"].rem;
const vn = window["React"].forwardRef;
const gn = window["MantineCore"].TableTh;
const en = window["React"].useMemo;
var It = ({ key: e, columns: t = [], getInitialValueInEffect: o = true }) => {
  function n(c, y) {
    let f = [];
    return c.forEach((u) => {
      y.find((w) => w.accessor === u) && f.push(u);
    }), y.forEach((u) => {
      f.includes(u.accessor) || f.push(u.accessor);
    }), f;
  }
  function a(c, y) {
    let f = [];
    return c.forEach((u) => {
      y.find((w) => w.accessor === u.accessor) && f.push(u);
    }), y.forEach((u) => {
      f.find((w) => w.accessor === u.accessor) || f.push({ accessor: u.accessor, defaultToggle: u.defaultToggle || true, toggleable: u.toggleable, toggled: u.defaultToggle === void 0 ? true : u.defaultToggle });
    }), f;
  }
  function r2(c, y) {
    let f = [];
    return c.forEach((u) => {
      let w = Object.keys(u)[0];
      y.find((h) => h.accessor === w) && f.push(u);
    }), y.forEach((u) => {
      let w = u.accessor;
      if (!f.find((h) => Object.keys(h)[0] === w)) {
        let h = {};
        h[w] = "", f.push(h);
      }
    }), f;
  }
  function l() {
    let [c, y] = useLocalStorage({ key: e ? `${e}-columns-order` : "", defaultValue: e ? d : void 0, getInitialValueInEffect: o });
    function f(h) {
      e && y(h);
    }
    if (!e) return [c, f];
    let u = n(c, t), w = JSON.stringify(c);
    return JSON.stringify(u) !== w && f(u), [u, f];
  }
  function i() {
    let [c, y] = useLocalStorage({ key: e ? `${e}-columns-toggle` : "", defaultValue: e ? b : void 0, getInitialValueInEffect: o });
    function f(h) {
      e && y(h);
    }
    if (!e) return [c, f];
    let u = a(c, t), w = JSON.stringify(c);
    return JSON.stringify(u) !== w && f(u), [a(c, t), f];
  }
  function s() {
    let [c, y] = useLocalStorage({ key: e ? `${e}-columns-width` : "", defaultValue: e ? m : void 0, getInitialValueInEffect: o });
    function f(h) {
      e && y(h);
    }
    if (!e) return [c, f];
    let u = r2(c, t), w = JSON.stringify(c);
    return JSON.stringify(u) !== w && f(u), [r2(c, t), f];
  }
  let d = t && t.map((c) => c.accessor) || [], m = t && t.map((c) => ({ [c.accessor]: c.width ?? "initial" })) || [], b = t && t.map((c) => ({ accessor: c.accessor, defaultToggle: c.defaultToggle || true, toggleable: c.toggleable, toggled: c.defaultToggle === void 0 ? true : c.defaultToggle })), [p, T] = l(), [g, x] = i(), [D, S] = s(), R = () => T(d), P = () => {
    x(b);
  }, M = () => S(m);
  return { effectiveColumns: en(() => p ? p.map((f) => t.find((u) => u.accessor === f)).map((f) => {
    var _a2;
    return { ...f, hidden: (f == null ? void 0 : f.hidden) || !((_a2 = g.find((u) => u.accessor === (f == null ? void 0 : f.accessor))) == null ? void 0 : _a2.toggled) };
  }).map((f) => {
    var _a2;
    return { ...f, width: (_a2 = D.find((u) => u[f == null ? void 0 : f.accessor])) == null ? void 0 : _a2[f == null ? void 0 : f.accessor] };
  }) : t, [t, p, g, D]), setColumnsOrder: T, columnsOrder: p, resetColumnsOrder: R, columnsToggle: g, setColumnsToggle: x, resetColumnsToggle: P, columnsWidth: D, setColumnsWidth: S, setColumnWidth: (c, y) => {
    let f = D.map((u) => u[c] ? { [c]: y } : u);
    S(f);
  }, resetColumnsWidth: M };
};
function ne() {
  var _a2;
  let [e] = useResizeObserver(), { width: t, height: o } = ((_a2 = e.current) == null ? void 0 : _a2.getBoundingClientRect()) || { width: 0, height: 0 };
  return { ref: e, width: t, height: o };
}
const on = window["React"].useEffect;
const an = window["React"].useLayoutEffect;
var Ot = typeof window < "u" ? an : on;
const nn = window["React"].useEffect;
const rn = window["React"].useState;
function Wt(e) {
  let [t, o] = rn(null), n = (e == null ? void 0 : e.join(":")) || "";
  return nn(() => {
    o(null);
  }, [n]), { lastSelectionChangeIndex: t, setLastSelectionChangeIndex: o };
}
const ln = window["React"].useEffect;
const sn = window["React"].useRef;
const dn = window["React"].useState;
function cn(e, t) {
  let o = () => {
    t(e.map((a) => a.matches));
  }, n = e.map((a) => {
    try {
      return a.addEventListener("change", o), () => a.removeEventListener("change", o);
    } catch {
      return a.addListener(o), () => a.removeListener(o);
    }
  });
  return () => {
    n.forEach((a) => a());
  };
}
function un(e, t) {
  return t || (typeof window < "u" && "matchMedia" in window ? e.map((o) => window.matchMedia(o).matches) : e.map(() => false));
}
function At(e, t, { getInitialValueInEffect: o } = { getInitialValueInEffect: true }) {
  let [n, a] = dn(o ? t : un(e, t)), r2 = sn(null);
  return ln(() => {
    if ("matchMedia" in window) return r2.current = e.map((l) => window.matchMedia(l)), a(r2.current.map((l) => l.matches)), cn(r2.current, (l) => {
      a(l);
    });
  }, [e]), n;
}
const mn = window["MantineCore"].useMantineTheme;
const zt = window["React"].useMemo;
function Vt(e) {
  let t = mn(), o = zt(() => e.map((a) => (typeof a == "function" ? a(t) : a) ?? ""), [e, t]), n = zt(() => e.map(() => true), [e]);
  return At(o, n);
}
const pn = window["MantineCore"].useMantineTheme;
function K(e) {
  let t = pn(), o = typeof e == "function" ? e(t) : e;
  return useMediaQuery(o || "", true);
}
const bn = window["React"].useState;
function ce(e) {
  let t = e.replace(/([a-z\d])([A-Z]+)/g, "$1 $2").replace(/\W|_/g, " ").trim().toLowerCase();
  return `${t.charAt(0).toUpperCase()}${t.slice(1)}`;
}
function _t(e, t, o) {
  return e.filter((n) => !t.map(o).includes(o(n)));
}
function We(e, t) {
  return e.filter((o, n, a) => n === a.findIndex((r2) => t(o) === t(r2)));
}
function rt(e, t) {
  return t ? t.match(/([^[.\]])+/g).reduce((n, a) => n && n[a], e) : void 0;
}
function E(e, t) {
  return typeof t == "string" ? rt(e, t) : t(e);
}
function Ft({ rowExpansion: e, records: t, idAccessor: o }) {
  let n = [];
  if (e && t) {
    let { trigger: i, allowMultiple: s, initiallyExpanded: d } = e;
    t && i === "always" ? n = t.map((m) => E(m, o)) : d && (n = t.filter((m, b) => d({ record: m, index: b })).map((m) => E(m, o)), s || (n = [n[0]]));
  }
  let a, r2, l = bn(n);
  if (e) {
    let { expandable: i, trigger: s, allowMultiple: d, collapseProps: m, content: b } = e;
    e.expanded ? { recordIds: a, onRecordIdsChange: r2 } = e.expanded : [a, r2] = l;
    let p = (T) => r2 == null ? void 0 : r2(a.filter((g) => g !== E(T, o)));
    return { expandOnClick: s !== "always" && s !== "never", isRowExpanded: (T) => s === "always" ? true : a.includes(E(T, o)), isExpandable: ({ record: T, index: g }) => i ? i({ record: T, index: g }) : true, expandRow: (T) => {
      let g = E(T, o);
      r2 == null ? void 0 : r2(d ? [...a, g] : [g]);
    }, collapseRow: p, collapseProps: m, content: ({ record: T, index: g }) => () => b({ record: T, index: g, collapse: () => p(T) }) };
  }
}
const Tn = window["React"].useEffect;
const Gt = window["React"].useState;
function Xt(e, t) {
  let [o, n] = Gt(e), [a, r2] = Gt(e), l = useTimeout(() => n(true), 0), i = useTimeout(() => r2(false), t || 200);
  return Tn(() => {
    e ? (i.clear(), r2(true), l.start()) : (l.clear(), n(false), i.start());
  }, [l, i, e]), { expanded: o, visible: a };
}
var ue = "mantine-datatable-nowrap", me = "mantine-datatable-ellipsis", B = "mantine-datatable-pointer-cursor", Ae = "mantine-datatable-context-menu-cursor", Qt = "mantine-datatable-text-selection-disabled", J = "mantine-datatable-text-align-left", Z = "mantine-datatable-text-align-center", Y = "mantine-datatable-text-align-right";
function Ut({ className: e, style: t, visibleMediaQuery: o, title: n, noWrap: a, ellipsis: r2, textAlign: l, width: i }) {
  return K(o) ? jsxRuntimeExports.jsx(gn, { className: clsx({ [ue]: a || r2, [me]: r2, [J]: l === "left", [Z]: l === "center", [Y]: l === "right" }, e), style: [{ width: i, minWidth: i, maxWidth: i }, t], children: n }) : null;
}
const Dn = window["MantineCore"].TableTh;
function $t({ shadowVisible: e }) {
  return jsxRuntimeExports.jsx(Dn, { className: "mantine-datatable-footer-selector-placeholder-cell", "data-shadow-visible": e || void 0 });
}
var Kt = vn(function({ className: t, style: o, columns: n, defaultColumnProps: a, selectionVisible: r2, selectorCellShadowVisible: l, scrollDiff: i }, s) {
  let d = i < 0;
  return jsxRuntimeExports.jsx(wn, { ref: s, className: clsx("mantine-datatable-footer", t), style: [{ position: d ? "relative" : "sticky", bottom: Pn(d ? i : 0) }, o], children: jsxRuntimeExports.jsxs(Sn, { children: [r2 && jsxRuntimeExports.jsx($t, { shadowVisible: l }), n.map(({ hidden: m, ...b }) => {
    if (m) return null;
    let { accessor: p, visibleMediaQuery: T, textAlign: g, width: x, footer: D, footerClassName: S, footerStyle: R, noWrap: P, ellipsis: M } = { ...a, ...b };
    return jsxRuntimeExports.jsx(Ut, { className: S, style: R, visibleMediaQuery: T, textAlign: g, width: x, title: D, noWrap: P, ellipsis: M }, p);
  })] }) });
});
const rr = window["MantineCore"].Checkbox;
const lr = window["MantineCore"].Group;
const ir = window["MantineCore"].Popover;
const sr = window["MantineCore"].PopoverDropdown;
const dr = window["MantineCore"].PopoverTarget;
const cr = window["MantineCore"].Stack;
const ur = window["MantineCore"].TableThead;
const mo = window["MantineCore"].TableTr;
const pr = window["React"].forwardRef;
const fr = window["React"].useState;
const Mn = window["MantineCore"].TableTh;
const Jt = window["React"].useMemo;
function Zt({ group: { id: e, columns: t, title: o, textAlign: n, className: a, style: r2 } }) {
  let l = Jt(() => t.map(({ visibleMediaQuery: d }) => d), [t]), i = Vt(l), s = Jt(() => t.filter(({ hidden: d }, m) => !d && (i == null ? void 0 : i[m])).length, [t, i]);
  return s > 0 ? jsxRuntimeExports.jsx(Mn, { colSpan: s, className: clsx("mantine-datatable-column-group-header-cell", { [J]: n === "left", [Z]: n === "center", [Y]: n === "right" }, a), style: r2, children: o ?? ce(e) }) : null;
}
const io = window["MantineCore"].ActionIcon;
const Kn = window["MantineCore"].Box;
const Fe = window["MantineCore"].Center;
const Jn = window["MantineCore"].Flex;
const Zn = window["MantineCore"].Group;
const Yn = window["MantineCore"].TableTh;
const qn = window["React"].useRef;
const jn = window["React"].useState;
const Hn = window["MantineCore"].ActionIcon;
const In = window["MantineCore"].Popover;
const On = window["MantineCore"].PopoverDropdown;
const Wn = window["MantineCore"].PopoverTarget;
function qt() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M4 4h16v2.172a2 2 0 0 1 -.586 1.414l-4.414 4.414v7l-6 2v-8.5l-4.48 -4.928a2 2 0 0 1 -.52 -1.345v-2.227z" })] });
}
function eo() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M20 3h-16a1 1 0 0 0 -1 1v2.227l.008 .223a3 3 0 0 0 .772 1.795l4.22 4.641v8.114a1 1 0 0 0 1.316 .949l6 -2l.108 -.043a1 1 0 0 0 .576 -.906v-6.586l4.121 -4.12a3 3 0 0 0 .879 -2.123v-2.171a1 1 0 0 0 -1 -1z", strokeWidth: "0", fill: "currentColor" })] });
}
function to({ children: e, isActive: t, filterPopoverProps: o }) {
  let [n, { close: a, toggle: r2 }] = useDisclosure(false), l = t ? eo : qt, i = useClickOutside(a);
  return jsxRuntimeExports.jsxs(In, { withArrow: true, shadow: "md", opened: n, onClose: a, trapFocus: true, ...o, children: [jsxRuntimeExports.jsx(Wn, { children: jsxRuntimeExports.jsx(Hn, { className: "mantine-datatable-header-cell-filter-action-icon", "data-active": t || void 0, size: "sm", variant: "default", onClick: (s) => {
    s.preventDefault(), r2();
  }, onKeyDown: (s) => s.stopPropagation(), children: jsxRuntimeExports.jsx(l, {}) }) }), jsxRuntimeExports.jsx(On, { ref: i, onClick: (s) => s.stopPropagation(), onKeyDown: (s) => s.stopPropagation(), children: typeof e == "function" ? e({ close: a }) : e })] });
}
const _n = window["MantineCore"].rem;
const Fn = window["React"].useRef;
const Bn = window["React"].useState;
var oo = (e) => {
  let { accessor: t, columnRef: o } = e, n = Fn(null), [a, r2] = Bn(0), { setColumnWidth: l } = de(), i = (b) => {
    b.preventDefault(), b.stopPropagation(), document.addEventListener("mousemove", s), document.addEventListener("mouseup", d), document.body.style.cursor = "col-resize";
  }, s = (b) => {
    if (!o.current) return;
    let p = b.clientX - o.current.getBoundingClientRect().right, g = `${o.current.getBoundingClientRect().width + p}px`;
    o.current.style.width = g, l(t, o.current.style.width), r2(-p);
  }, d = () => {
    o.current && (document.removeEventListener("mousemove", s), document.removeEventListener("mouseup", d), document.body.style.cursor = "initial", l(t, o.current.style.width), r2(0));
  };
  return jsxRuntimeExports.jsx("div", { ref: n, onClick: (b) => b.stopPropagation(), onMouseDown: i, onDoubleClick: () => {
    o.current && (o.current.style.maxWidth = "initial", o.current.style.minWidth = "initial", o.current.style.width = "initial", l(t, "initial"));
  }, className: "mantine-datatable-header-resizable-handle", style: { right: _n(a) } });
};
function ao() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M12 5l0 14" }), jsxRuntimeExports.jsx("path", { d: "M16 9l-4 -4" }), jsxRuntimeExports.jsx("path", { d: "M8 9l4 -4" })] });
}
function no() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M8 7l4 -4l4 4" }), jsxRuntimeExports.jsx("path", { d: "M8 17l4 4l4 -4" }), jsxRuntimeExports.jsx("path", { d: "M12 3l0 18" })] });
}
function ro() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M9 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" }), jsxRuntimeExports.jsx("path", { d: "M9 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" }), jsxRuntimeExports.jsx("path", { d: "M9 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" }), jsxRuntimeExports.jsx("path", { d: "M15 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" }), jsxRuntimeExports.jsx("path", { d: "M15 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" }), jsxRuntimeExports.jsx("path", { d: "M15 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" })] });
}
function lo() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M18 6l-12 12" }), jsxRuntimeExports.jsx("path", { d: "M6 6l12 12" })] });
}
function so({ className: e, style: t, accessor: o, visibleMediaQuery: n, title: a, sortable: r2, draggable: l, toggleable: i, resizable: s, sortIcons: d, textAlign: m, width: b, sortStatus: p, onSortStatusChange: T, filter: g, filterPopoverProps: x, filtering: D, sortKey: S }) {
  let { setSourceColumn: R, setTargetColumn: P, swapColumns: M, setColumnsToggle: N } = de(), [A, c] = jn(false), y = qn(null);
  if (!K(n)) return null;
  let f = a ?? ce(o), u = typeof f == "string" ? f : void 0, w = r2 && T ? (k) => {
    (k == null ? void 0 : k.defaultPrevented) || T({ sortKey: S, columnAccessor: o, direction: (p == null ? void 0 : p.columnAccessor) === o ? p.direction === "asc" ? "desc" : "asc" : (p == null ? void 0 : p.direction) ?? "asc" });
  } : void 0, h = (k) => {
    k.stopPropagation(), R(o), c(false);
  }, L = (k) => {
    k.preventDefault(), P(o), c(true);
  }, I = () => {
    P(o), c(false), M();
  }, z = () => {
    c(true);
  }, Q = () => {
    c(false);
  }, F = (k) => {
    k.stopPropagation(), N((U) => U.map((G) => G.accessor === o ? { ...G, toggled: false } : G));
  };
  return jsxRuntimeExports.jsxs(Yn, { className: clsx({ "mantine-datatable-header-cell-sortable": r2, "mantine-datatable-header-cell-toggleable": i, "mantine-datatable-header-cell-resizable": s }, e), style: [{ width: b, ...s ? { minWidth: "1px" } : { minWidth: b, maxWidth: b } }, t], role: r2 ? "button" : void 0, tabIndex: r2 ? 0 : void 0, onClick: w, onKeyDown: (k) => k.key === "Enter" && (w == null ? void 0 : w()), ref: y, children: [jsxRuntimeExports.jsxs(Zn, { className: "mantine-datatable-header-cell-sortable-group", justify: "space-between", wrap: "nowrap", children: [jsxRuntimeExports.jsxs(Jn, { align: "center", w: "100%", className: clsx({ "mantine-datatable-header-cell-draggable": l, "mantine-datatable-header-cell-drag-over": A }), draggable: l, onDragStart: l ? h : void 0, onDragEnter: l ? z : void 0, onDragOver: l ? L : void 0, onDrop: l ? I : void 0, onDragLeave: l ? Q : void 0, children: [l ? jsxRuntimeExports.jsx(Fe, { role: "img", "aria-label": "Drag column", children: jsxRuntimeExports.jsx(io, { className: "mantine-datatable-header-cell-draggable-action-icon", variant: "subtle", size: "xs", onClick: (k) => {
    k.stopPropagation();
  }, children: jsxRuntimeExports.jsx(ro, {}) }) }) : null, jsxRuntimeExports.jsx(Kn, { className: clsx("mantine-datatable-header-cell-sortable-text", { [J]: m === "left", [Z]: m === "center", [Y]: m === "right" }, ue, me), title: u, children: f })] }), i ? jsxRuntimeExports.jsx(Fe, { className: "mantine-datatable-header-cell-toggleable-icon", role: "img", "aria-label": "Toggle column", children: jsxRuntimeExports.jsx(io, { size: "xs", variant: "light", onClick: F, children: jsxRuntimeExports.jsx(lo, {}) }) }) : null, r2 || (p == null ? void 0 : p.columnAccessor) === o ? jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: (p == null ? void 0 : p.columnAccessor) === o ? jsxRuntimeExports.jsx(Fe, { className: clsx("mantine-datatable-header-cell-sortable-icon", { "mantine-datatable-header-cell-sortable-icon-reversed": p.direction === "desc" }), role: "img", "aria-label": `Sorted ${p.direction === "desc" ? "descending" : "ascending"}`, children: (d == null ? void 0 : d.sorted) || jsxRuntimeExports.jsx(ao, {}) }) : jsxRuntimeExports.jsx(Fe, { className: "mantine-datatable-header-cell-sortable-unsorted-icon", role: "img", "aria-label": "Not sorted", children: (d == null ? void 0 : d.unsorted) || jsxRuntimeExports.jsx(no, {}) }) }) : null, g ? jsxRuntimeExports.jsx(to, { filterPopoverProps: x, isActive: !!D, children: g }) : null] }), s ? jsxRuntimeExports.jsx(oo, { accessor: o, columnRef: y }) : null] });
}
const tr = window["MantineCore"].Checkbox;
const or = window["MantineCore"].TableTh;
const nr = window["React"].forwardRef;
var uo = nr(function({ className: t, style: o, trigger: n, shadowVisible: a, checked: r2, indeterminate: l, checkboxProps: i, onChange: s, rowSpan: d }, m) {
  let b = !i.disabled;
  return jsxRuntimeExports.jsx(or, { ref: m, className: clsx("mantine-datatable-header-selector-cell", { [B]: n === "cell" && b }, t), style: o, rowSpan: d, "data-shadow-visible": a || void 0, onClick: n === "cell" && b ? s : void 0, children: jsxRuntimeExports.jsx(tr, { classNames: b ? { input: B } : void 0, checked: r2, indeterminate: l, onChange: s, ...i, disabled: !(s || i.onChange) || i.disabled }) });
});
var po = pr(function({ selectionColumnHeaderRef: t, className: o, style: n, sortStatus: a, sortIcons: r2, onSortStatusChange: l, columns: i, defaultColumnProps: s, groups: d, selectionTrigger: m, selectionVisible: b, selectionChecked: p, selectionIndeterminate: T, onSelectionChange: g, selectionCheckboxProps: x, selectorCellShadowVisible: D, selectionColumnClassName: S, selectionColumnStyle: R }, P) {
  let M = b ? jsxRuntimeExports.jsx(uo, { ref: t, className: S, style: R, trigger: m, shadowVisible: D, checked: p, indeterminate: T, checkboxProps: x, onChange: g, rowSpan: d ? 2 : void 0 }) : null, { columnsToggle: N, setColumnsToggle: A } = de(), [c, y] = fr(false), f = i.some((h) => h.toggleable), u = f ? Object.fromEntries(i.map(({ accessor: h, title: L }) => [h, L ?? ce(String(h))])) : void 0, w = jsxRuntimeExports.jsxs(ur, { className: clsx("mantine-datatable-header", o), style: n, ref: P, onContextMenu: f ? (h) => {
    h.preventDefault(), y((L) => !L);
  } : void 0, children: [d && jsxRuntimeExports.jsxs(mo, { children: [M, d.map((h) => jsxRuntimeExports.jsx(Zt, { group: h }, h.id))] }), jsxRuntimeExports.jsxs(mo, { children: [!d && M, i.map(({ hidden: h, ...L }, I) => {
    if (h) return null;
    let { accessor: z, visibleMediaQuery: Q, textAlign: F, width: k, title: U, sortable: G, draggable: pe, toggleable: fe, resizable: be, titleClassName: Te, titleStyle: ge, filter: j, filterPopoverProps: he, filtering: Ce, sortKey: X } = { ...s, ...L };
    return jsxRuntimeExports.jsx(so, { accessor: z, className: Te, style: ge, visibleMediaQuery: Q, textAlign: F, width: k, title: U, sortable: G, draggable: pe, toggleable: fe, resizable: be && I < i.length - 1, sortStatus: a, sortIcons: r2, sortKey: X, onSortStatusChange: l, filter: j, filterPopoverProps: he, filtering: Ce }, z);
  })] })] });
  return f ? jsxRuntimeExports.jsxs(ir, { position: "bottom", withArrow: true, shadow: "md", opened: c, onChange: y, children: [jsxRuntimeExports.jsx(dr, { children: w }), jsxRuntimeExports.jsx(sr, { children: jsxRuntimeExports.jsx(cr, { children: N.filter((h) => h.toggleable).map((h) => jsxRuntimeExports.jsx(lr, { children: jsxRuntimeExports.jsx(rr, { classNames: { label: "mantine-datatable-header-column-toggle-checkbox-label" }, size: "xs", label: u[h.accessor], checked: h.toggled, onChange: (L) => {
    A(N.map((I) => I.accessor === h.accessor ? { ...I, toggled: L.currentTarget.checked } : I));
  } }) }, h.accessor)) }) })] }) : w;
});
const br = window["MantineCore"].Center;
const Tr = window["MantineCore"].Loader;
function bo({ pt: e, pb: t, fetching: o, customContent: n, backgroundBlur: a, size: r2, type: l, color: i }) {
  return jsxRuntimeExports.jsx(br, { pt: e, pb: t, className: clsx("mantine-datatable-loader", { "mantine-datatable-loader-fetching": o }), style: [{ backdropFilter: a ? `blur(${a}px)` : void 0 }], children: o && (n || jsxRuntimeExports.jsx(Tr, { size: r2, type: l, color: i })) });
}
const Rr = window["MantineCore"].Box;
const Mr = window["MantineCore"].Pagination;
const kr = window["MantineCore"].Text;
const Er = window["MantineCore"].rem;
const Nr = window["React"].forwardRef;
const Dr = window["MantineCore"].Button;
const yr = window["MantineCore"].Group;
const wr = window["MantineCore"].Menu;
const Sr = window["MantineCore"].MenuDropdown;
const Pr = window["MantineCore"].MenuItem;
const xr = window["MantineCore"].MenuTarget;
const Co = window["MantineCore"].Text;
const Re = window["MantineCore"].rem;
const hr = window["MantineCore"].parseThemeColor;
function v(e, t, o) {
  return e ? hr({ color: typeof e == "object" ? e[o] : e, theme: t }).value : void 0;
}
function To({ theme: e, c: t, backgroundColor: o, borderColor: n, rowBorderColor: a, stripedColor: r2, highlightOnHoverColor: l }) {
  return { "--mantine-datatable-color-light": v(t, e, "light"), "--mantine-datatable-color-dark": v(t, e, "dark"), "--mantine-datatable-background-color-light": v(o, e, "light"), "--mantine-datatable-background-color-dark": v(o, e, "dark"), "--mantine-datatable-border-color-light": v(n, e, "light"), "--mantine-datatable-border-color-dark": v(n, e, "dark"), "--mantine-datatable-row-border-color-light": v(a, e, "light"), "--mantine-datatable-row-border-color-dark": v(a, e, "dark"), "--mantine-datatable-striped-color-light": v(r2, e, "light"), "--mantine-datatable-striped-color-dark": v(r2, e, "dark"), "--mantine-datatable-highlight-on-hover-color-light": v(l, e, "light"), "--mantine-datatable-highlight-on-hover-color-dark": v(l, e, "dark") };
}
function Xe({ theme: e, paginationActiveTextColor: t, paginationActiveBackgroundColor: o }) {
  return { "--mantine-datatable-pagination-active-text-color-light": v(t, e, "light"), "--mantine-datatable-pagination-active-text-color-dark": v(t, e, "dark"), "--mantine-datatable-pagination-active-background-color-light": v(o, e, "light"), "--mantine-datatable-pagination-active-background-color-dark": v(o, e, "dark") };
}
function go({ theme: e, color: t, backgroundColor: o }) {
  return { "--mantine-datatable-row-color-light": v(t, e, "light"), "--mantine-datatable-row-color-dark": v(t, e, "dark"), "--mantine-datatable-row-background-color-light": v(o, e, "light"), "--mantine-datatable-row-background-color-dark": v(o, e, "dark") };
}
function ho() {
  return jsxRuntimeExports.jsxs("svg", { width: "14", height: "14", viewBox: "0 0 24 24", strokeWidth: "2", stroke: "currentColor", fill: "none", strokeLinecap: "round", strokeLinejoin: "round", children: [jsxRuntimeExports.jsx("path", { stroke: "none", d: "M0 0h24v24H0z", fill: "none" }), jsxRuntimeExports.jsx("path", { d: "M8 9l4 -4l4 4" }), jsxRuntimeExports.jsx("path", { d: "M16 15l-4 4l-4 -4" })] });
}
var Do = { xs: Re(22), sm: Re(26), md: Re(32), lg: Re(38), xl: Re(44) };
function wo({ size: e, label: t, values: o, value: n, activeTextColor: a, activeBackgroundColor: r2, onChange: l }) {
  return jsxRuntimeExports.jsxs(yr, { gap: "xs", children: [jsxRuntimeExports.jsx(Co, { component: "div", size: e, children: t }), jsxRuntimeExports.jsxs(wr, { withinPortal: true, withArrow: true, classNames: { arrow: "mantine-datatable-page-size-selector-menu-arrow" }, children: [jsxRuntimeExports.jsx(xr, { children: jsxRuntimeExports.jsx(Dr, { size: e, variant: "default", classNames: { section: "mantine-datatable-page-size-selector-button-icon" }, rightSection: jsxRuntimeExports.jsx(ho, {}), style: [{ fontWeight: "normal" }, (i) => ({ height: Do[e], paddingLeft: i.spacing[e], paddingRight: i.spacing[e] })], children: n }) }), jsxRuntimeExports.jsx(Sr, { children: o.map((i) => {
    let s = i === n;
    return jsxRuntimeExports.jsx(Pr, { className: clsx({ "mantine-datatable-page-size-selector-active": s }), style: [{ height: Do[e] }, s && (a || r2) ? (d) => Xe({ theme: d, paginationActiveTextColor: a, paginationActiveBackgroundColor: r2 }) : void 0], disabled: s, onClick: () => l(i), children: jsxRuntimeExports.jsx(Co, { component: "div", size: e, children: i }) }, i);
  }) })] })] });
}
var Po = Nr(function({ className: t, style: o, fetching: n, page: a, onPageChange: r2, paginationWithEdges: l, paginationWithControls: i, paginationActiveTextColor: s, paginationActiveBackgroundColor: d, paginationSize: m, loadingText: b, noRecordsText: p, paginationText: T, totalRecords: g, recordsPerPage: x, onRecordsPerPageChange: D, recordsPerPageLabel: S, recordsPerPageOptions: R, recordsLength: P, horizontalSpacing: M, paginationWrapBreakpoint: N, getPaginationControlProps: A }, c) {
  let y;
  if (g) {
    let u = (a - 1) * x + 1, w = u + (P || 0) - 1;
    y = T({ from: u, to: w, totalRecords: g });
  } else y = n ? b : p;
  let f = K(({ breakpoints: u }) => `(min-width: ${typeof N == "number" ? `${Er(N)}rem` : u[N] || N})`);
  return jsxRuntimeExports.jsxs(Rr, { ref: c, px: M ?? "xs", py: "xs", className: clsx("mantine-datatable-pagination", t), style: [{ flexDirection: f ? "row" : "column" }, o], children: [jsxRuntimeExports.jsx(kr, { component: "div", className: "mantine-datatable-pagination-text", size: m, children: y }), R && jsxRuntimeExports.jsx(wo, { activeTextColor: s, activeBackgroundColor: d, size: m, label: S, values: R, value: x, onChange: D }), jsxRuntimeExports.jsx(Mr, { classNames: { root: clsx("mantine-datatable-pagination-pages", { "mantine-datatable-pagination-pages-fetching": n || !P }), control: "mantine-datatable-pagination-pages-control" }, style: s || d ? (u) => Xe({ theme: u, paginationActiveTextColor: s, paginationActiveBackgroundColor: d }) : void 0, withEdges: l, withControls: i, value: a, onChange: r2, size: m, total: Math.ceil(g / x), getControlProps: A })] });
});
const Gr = window["MantineCore"].TableTr;
const Hr = window["MantineCore"].TableTd;
function xo({ className: e, style: t, visibleMediaQuery: o, record: n, index: a, onClick: r2, onDoubleClick: l, onContextMenu: i, noWrap: s, ellipsis: d, textAlign: m, width: b, accessor: p, render: T, defaultRender: g, customCellAttributes: x }) {
  return K(o) ? jsxRuntimeExports.jsx(Hr, { className: clsx({ [ue]: s || d, [me]: d, [B]: r2 || l, [Ae]: i, [J]: m === "left", [Z]: m === "center", [Y]: m === "right" }, e), style: [{ width: b, minWidth: b, maxWidth: b }, t], onClick: r2, onDoubleClick: l, onContextMenu: i, ...x == null ? void 0 : x(n, a), children: T ? T(n, a) : g ? g(n, a, p) : rt(n, p) }) : null;
}
const Wr = window["MantineCore"].Collapse;
const Ar = window["MantineCore"].TableTd;
const vo = window["MantineCore"].TableTr;
function Ro({ open: e, colSpan: t, content: o, collapseProps: n }) {
  let { expanded: a, visible: r2 } = Xt(e, n == null ? void 0 : n.transitionDuration);
  return r2 ? jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [jsxRuntimeExports.jsx(vo, {}), jsxRuntimeExports.jsx(vo, { children: jsxRuntimeExports.jsx(Ar, { className: "mantine-datatable-row-expansion-cell", colSpan: t, children: jsxRuntimeExports.jsx(Wr, { in: a, ...n, children: jsxRuntimeExports.jsx("div", { className: "mantine-datatable-row-expansion-cell-content", children: o() }) }) }) })] }) : null;
}
const _r = window["MantineCore"].Checkbox;
const Fr = window["MantineCore"].TableTd;
function ko({ className: e, style: t, record: o, index: n, trigger: a, onChange: r2, withRightShadow: l, checkboxProps: i, getCheckboxProps: s, ...d }) {
  let m = { ...i, ...s(o, n) }, b = !d.disabled && !m.disabled, p = (T) => {
    T.stopPropagation(), a === "cell" && b && (r2 == null ? void 0 : r2(T));
  };
  return jsxRuntimeExports.jsx(Fr, { className: clsx("mantine-datatable-row-selector-cell", { [B]: a === "cell" && b }, e), style: t, "data-shadow-visible": l || void 0, onClick: p, children: jsxRuntimeExports.jsx(_r, { classNames: b ? { input: B } : void 0, onChange: r2, ...d, ...m }) });
}
function Lo({ record: e, index: t, columns: o, defaultColumnProps: n, defaultColumnRender: a, selectionTrigger: r2, selectionVisible: l, selectionChecked: i, onSelectionChange: s, isRecordSelectable: d, selectionCheckboxProps: m, getSelectionCheckboxProps: b, onClick: p, onDoubleClick: T, onContextMenu: g, onCellClick: x, onCellDoubleClick: D, onCellContextMenu: S, expansion: R, customAttributes: P, color: M, backgroundColor: N, className: A, style: c, selectorCellShadowVisible: y, selectionColumnClassName: f, selectionColumnStyle: u, rowFactory: w }) {
  let h = jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [l && jsxRuntimeExports.jsx(ko, { className: f, style: u, record: e, index: t, trigger: r2, withRightShadow: y, checked: i, disabled: !s || (d ? !d(e, t) : false), onChange: s, checkboxProps: m, getCheckboxProps: b }), o.map(({ hidden: z, hiddenContent: Q, ...F }, k) => {
    if (z || Q) return null;
    let { accessor: U, visibleMediaQuery: G, textAlign: pe, noWrap: fe, ellipsis: be, width: Te, render: ge, cellsClassName: j, cellsStyle: he, customCellAttributes: Ce } = { ...n, ...F };
    return jsxRuntimeExports.jsx(xo, { className: typeof j == "function" ? j(e, t) : j, style: he == null ? void 0 : he(e, t), visibleMediaQuery: G, record: e, index: t, onClick: x ? (X) => x({ event: X, record: e, index: t, column: F, columnIndex: k }) : void 0, onDoubleClick: D ? (X) => D({ event: X, record: e, index: t, column: F, columnIndex: k }) : void 0, onContextMenu: S ? (X) => S({ event: X, record: e, index: t, column: F, columnIndex: k }) : void 0, accessor: U, textAlign: pe, noWrap: fe, ellipsis: be, width: Te, render: ge, defaultRender: a, customCellAttributes: Ce }, U);
  })] }), L = R && jsxRuntimeExports.jsx(Ro, { colSpan: o.filter(({ hidden: z }) => !z).length + (l ? 1 : 0), open: R.isRowExpanded(e), content: R.content({ record: e, index: t }), collapseProps: R.collapseProps }), I = Qr({ record: e, index: t, selectionChecked: i, onClick: p, onDoubleClick: T, onContextMenu: g, expansion: R, customAttributes: P, color: M, backgroundColor: N, className: A, style: c });
  return w ? w({ record: e, index: t, rowProps: I, children: h, expandedElement: L }) : jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [jsxRuntimeExports.jsx(Gr, { ...I, children: h }), L] });
}
function Qr({ record: e, index: t, selectionChecked: o, onClick: n, onDoubleClick: a, onContextMenu: r2, expansion: l, customAttributes: i, color: s, backgroundColor: d, className: m, style: b }) {
  return { className: clsx("mantine-datatable-row", { [B]: n || a || (l == null ? void 0 : l.isExpandable({ record: e, index: t })) && (l == null ? void 0 : l.expandOnClick) }, { [Ae]: r2 }, typeof m == "function" ? m(e, t) : m), "data-selected": o || void 0, onClick: (p) => {
    if (l) {
      let { isExpandable: T, isRowExpanded: g, expandOnClick: x, expandRow: D, collapseRow: S } = l;
      T({ record: e, index: t }) && x && (g(e) ? S(e) : D(e));
    }
    n == null ? void 0 : n({ event: p, record: e, index: t });
  }, onDoubleClick: a ? (p) => a({ event: p, record: e, index: t }) : void 0, onContextMenu: r2 ? (p) => r2({ event: p, record: e, index: t }) : void 0, style: [s || d ? (p) => {
    let T = s == null ? void 0 : s(e, t), g = d == null ? void 0 : d(e, t);
    return go({ theme: p, color: T, backgroundColor: g });
  } : void 0, b == null ? void 0 : b(e, t)], ...(i == null ? void 0 : i(e, t)) ?? {} };
}
const Ho = window["MantineCore"].Box;
const Ur = window["MantineCore"].ScrollArea;
const Io = window["MantineCore"].rem;
function Oo({ topShadowVisible: e, leftShadowVisible: t, leftShadowBehind: o, rightShadowVisible: n, rightShadowBehind: a, bottomShadowVisible: r2, headerHeight: l, footerHeight: i, onScrollPositionChange: s, children: d, viewportRef: m, scrollAreaProps: b }) {
  return jsxRuntimeExports.jsxs(Ur, { ...b, viewportRef: m, classNames: { root: "mantine-datatable-scroll-area", scrollbar: "mantine-datatable-scroll-area-scrollbar", thumb: "mantine-datatable-scroll-area-thumb", corner: "mantine-datatable-scroll-area-corner" }, onScrollPositionChange: s, children: [d, jsxRuntimeExports.jsx(Ho, { className: clsx("mantine-datatable-scroll-area-shadow", "mantine-datatable-scroll-area-top-shadow", { "mantine-datatable-scroll-area-shadow-visible": e }), style: { top: l ? Io(l) : 0 } }), jsxRuntimeExports.jsx("div", { className: clsx("mantine-datatable-scroll-area-shadow", "mantine-datatable-scroll-area-left-shadow", { "mantine-datatable-scroll-area-shadow-visible": t, "mantine-datatable-scroll-area-shadow-behind": o }) }), jsxRuntimeExports.jsx("div", { className: clsx("mantine-datatable-scroll-area-shadow", "mantine-datatable-scroll-area-right-shadow", { "mantine-datatable-scroll-area-shadow-visible": n, "mantine-datatable-scroll-area-shadow-behind": a }) }), jsxRuntimeExports.jsx(Ho, { className: clsx("mantine-datatable-scroll-area-shadow", "mantine-datatable-scroll-area-bottom-shadow", { "mantine-datatable-scroll-area-shadow-visible": r2 }), style: { bottom: i ? Io(i + 1) : 0 } })] });
}
function qr({ withTableBorder: e, borderRadius: t, textSelectionDisabled: o, height: n = "100%", minHeight: a, maxHeight: r2, shadow: l, verticalAlign: i = "center", fetching: s, columns: d, storeColumnsKey: m, groups: b, pinFirstColumn: p, pinLastColumn: T, defaultColumnProps: g, defaultColumnRender: x, idAccessor: D = "id", records: S, selectionTrigger: R = "checkbox", selectedRecords: P, onSelectedRecordsChange: M, selectionColumnClassName: N, selectionColumnStyle: A, isRecordSelectable: c, selectionCheckboxProps: y, allRecordsSelectionCheckboxProps: f = { "aria-label": "Select all records" }, getRecordSelectionCheckboxProps: u = (O, ee) => ({ "aria-label": `Select record ${ee + 1}` }), sortStatus: w, sortIcons: h, onSortStatusChange: L, horizontalSpacing: I, page: z, onPageChange: Q, totalRecords: F, recordsPerPage: k, onRecordsPerPageChange: U, recordsPerPageOptions: G, recordsPerPageLabel: pe = "Records per page", paginationWithEdges: fe, paginationWithControls: be, paginationActiveTextColor: Te, paginationActiveBackgroundColor: ge, paginationSize: j = "sm", paginationText: he = ({ from: O, to: ee, totalRecords: te }) => `${O} - ${ee} / ${te}`, paginationWrapBreakpoint: Ce = "sm", getPaginationControlProps: X = (O) => O === "previous" ? { "aria-label": "Previous page" } : O === "next" ? { "aria-label": "Next page" } : {}, loaderBackgroundBlur: _o, customLoader: Fo, loaderSize: Bo, loaderType: Go, loaderColor: Xo, loadingText: Qo = "...", emptyState: Uo, noRecordsText: ut = "No records", noRecordsIcon: $o, highlightOnHover: Ko, striped: Jo, noHeader: Zo, onRowClick: Yo, onRowDoubleClick: qo, onRowContextMenu: jo, onCellClick: ea, onCellDoubleClick: ta, onCellContextMenu: oa, onScroll: mt, onScrollToTop: pt, onScrollToBottom: ft, onScrollToLeft: bt, onScrollToRight: Tt, c: aa, backgroundColor: na, borderColor: ra, rowBorderColor: la, stripedColor: ia, highlightOnHoverColor: sa, rowColor: da, rowBackgroundColor: ca, rowExpansion: ua, rowClassName: ma, rowStyle: pa, customRowAttributes: fa, scrollViewportRef: ba, scrollAreaProps: Ta, tableRef: ga, bodyRef: ha, m: Ca, my: Da, mx: ya, mt: wa, mb: Sa, ml: Pa, mr: xa, className: va, classNames: De, style: Ra, styles: ye, rowFactory: Ma, tableWrapper: Je, ...gt }) {
  let { ref: O, width: ee, height: te } = ne(), we = Yr(() => (b == null ? void 0 : b.flatMap((C) => C.columns)) ?? d, [d, b]), ht = It({ key: m, columns: we }), { ref: ka, height: Ze } = ne(), { ref: Ea, width: Ye, height: Se } = ne(), { ref: Na, height: La } = ne(), { ref: Ha, height: Ct } = ne(), { ref: Ia, width: Oa } = ne(), Wa = useMergedRef(Ea, ga), Aa = useMergedRef(O, ba), [qe, Dt] = Ke(true), [je, yt] = Ke(true), [Pe, wt] = Ke(true), [Ee, St] = Ke(true), za = Ft({ rowExpansion: ua, records: S, idAccessor: D }), et = ke(() => {
    var _a3, _b2;
    let C = ((_a3 = O.current) == null ? void 0 : _a3.scrollTop) ?? 0, $ = ((_b2 = O.current) == null ? void 0 : _b2.scrollLeft) ?? 0;
    if (s || Se <= te) Dt(true), yt(true);
    else {
      let V = C === 0, _ = Se - C - te < 1;
      Dt(V), yt(_), V && V !== qe && (pt == null ? void 0 : pt()), _ && _ !== je && (ft == null ? void 0 : ft());
    }
    if (s || Ye === ee) wt(true), St(true);
    else {
      let V = $ === 0, _ = Ye - $ - ee < 1;
      wt(V), St(_), V && V !== Pe && (bt == null ? void 0 : bt()), _ && _ !== Ee && (Tt == null ? void 0 : Tt());
    }
  }, [s, ft, bt, Tt, pt, te, O, ee, je, Pe, Ee, qe, Se, Ye]);
  Ot(et, [et]);
  let Pt = useDebouncedCallback(et, 50), Va = ke((C) => {
    mt == null ? void 0 : mt(C), Pt();
  }, [Pt, mt]), _a2 = ke((C) => {
    var _a3;
    (_a3 = O.current) == null ? void 0 : _a3.scrollTo({ top: 0, left: 0 }), Q(C);
  }, [Q, O]), Ne = S == null ? void 0 : S.length, xt = S == null ? void 0 : S.map((C) => E(C, D)), ie = !!P, xe = P == null ? void 0 : P.map((C) => E(C, D)), vt = xt !== void 0 && xe !== void 0 && xe.length > 0, tt = c ? S == null ? void 0 : S.filter(c) : S, Le = tt == null ? void 0 : tt.map((C) => E(C, D)), He = vt && Le.every((C) => xe.includes(C)), Fa = vt && Le.some((C) => xe.includes(C)), Ba = ke(() => {
    P && M && M(He ? P.filter((C) => !Le.includes(E(C, D))) : We([...P, ...tt], (C) => E(C, D)));
  }, [He, D, M, Le, tt, P]), { lastSelectionChangeIndex: Ie, setLastSelectionChangeIndex: Ga } = Wt(xt), ot = ie && !Pe && !p, Xa = { m: Ca, my: Da, mx: ya, mt: wa, mb: Sa, ml: Pa, mr: xa }, Qa = ke(({ children: C }) => Je ? Je({ children: C }) : C, [Je]);
  return jsxRuntimeExports.jsx(at, { ...ht, children: jsxRuntimeExports.jsxs(Kr, { ...Xa, className: clsx("mantine-datatable", { "mantine-datatable-with-border": e }, va, De == null ? void 0 : De.root), style: [(C) => ({ ...To({ theme: C, c: aa, backgroundColor: na, borderColor: ra, rowBorderColor: la, stripedColor: ia, highlightOnHoverColor: sa }), borderRadius: C.radius[t] || t, boxShadow: C.shadows[l] || l, height: n, minHeight: a, maxHeight: r2 }), Ra, ye == null ? void 0 : ye.root, { position: "relative" }], children: [jsxRuntimeExports.jsx(Oo, { viewportRef: Aa, topShadowVisible: !qe, leftShadowVisible: !Pe, leftShadowBehind: ie || !!p, rightShadowVisible: !Ee, rightShadowBehind: T, bottomShadowVisible: !je, headerHeight: Ze, footerHeight: La, onScrollPositionChange: Va, scrollAreaProps: Ta, children: jsxRuntimeExports.jsx(Qa, { children: jsxRuntimeExports.jsxs(Jr, { ref: Wa, horizontalSpacing: I, className: clsx("mantine-datatable-table", { [Qt]: o, "mantine-datatable-vertical-align-top": i === "top", "mantine-datatable-vertical-align-bottom": i === "bottom", "mantine-datatable-last-row-border-bottom-visible": gt.withRowBorders && Se < te, "mantine-datatable-pin-last-column": T, "mantine-datatable-pin-last-column-scrolled": !Ee && T, "mantine-datatable-selection-column-visible": ie, "mantine-datatable-pin-first-column": p, "mantine-datatable-pin-first-column-scrolled": !Pe && p }, De == null ? void 0 : De.table), style: { ...ye == null ? void 0 : ye.table, "--mantine-datatable-selection-column-width": `${Oa}px` }, "data-striped": Ne && Jo || void 0, "data-highlight-on-hover": Ko || void 0, ...gt, children: [Zo ? null : jsxRuntimeExports.jsx(at, { ...ht, children: jsxRuntimeExports.jsx(po, { ref: ka, selectionColumnHeaderRef: Ia, className: De == null ? void 0 : De.header, style: ye == null ? void 0 : ye.header, columns: we, defaultColumnProps: g, groups: b, sortStatus: w, sortIcons: h, onSortStatusChange: L, selectionTrigger: R, selectionVisible: ie, selectionChecked: He, selectionIndeterminate: Fa && !He, onSelectionChange: Ba, selectionCheckboxProps: { ...y, ...f }, selectorCellShadowVisible: ot, selectionColumnClassName: N, selectionColumnStyle: A }) }), jsxRuntimeExports.jsx("tbody", { ref: ha, children: Ne ? S.map((C, $) => {
    let V = E(C, D), _ = (xe == null ? void 0 : xe.includes(V)) || false, Rt;
    return M && P && (Rt = (Ua) => {
      if (Ua.nativeEvent.shiftKey && Ie !== null) {
        let se = S.filter($ > Ie ? (oe, ae) => ae >= Ie && ae <= $ && (c ? c(oe, ae) : true) : (oe, ae) => ae >= $ && ae <= Ie && (c ? c(oe, ae) : true));
        M(_ ? _t(P, se, (oe) => E(oe, D)) : We([...P, ...se], (oe) => E(oe, D)));
      } else M(_ ? P.filter((se) => E(se, D) !== V) : We([...P, C], (se) => E(se, D)));
      Ga($);
    }), jsxRuntimeExports.jsx(Lo, { record: C, index: $, columns: we, defaultColumnProps: g, defaultColumnRender: x, selectionTrigger: R, selectionVisible: ie, selectionChecked: _, onSelectionChange: Rt, isRecordSelectable: c, selectionCheckboxProps: y, getSelectionCheckboxProps: u, onClick: Yo, onDoubleClick: qo, onCellClick: ea, onCellDoubleClick: ta, onContextMenu: jo, onCellContextMenu: oa, expansion: za, color: da, backgroundColor: ca, className: ma, style: pa, customAttributes: fa, selectorCellShadowVisible: ot, selectionColumnClassName: N, selectionColumnStyle: A, idAccessor: D, rowFactory: Ma }, V);
  }) : jsxRuntimeExports.jsx(Nt, {}) }), we.some(({ footer: C }) => C) && jsxRuntimeExports.jsx(Kt, { ref: Na, className: De == null ? void 0 : De.footer, style: ye == null ? void 0 : ye.footer, columns: we, defaultColumnProps: g, selectionVisible: ie, selectorCellShadowVisible: ot, scrollDiff: Se - te })] }) }) }), z && jsxRuntimeExports.jsx(Po, { ref: Ha, className: De == null ? void 0 : De.pagination, style: ye == null ? void 0 : ye.pagination, horizontalSpacing: I, fetching: s, page: z, onPageChange: _a2, totalRecords: F, recordsPerPage: k, onRecordsPerPageChange: U, recordsPerPageOptions: G, recordsPerPageLabel: pe, paginationWithEdges: fe, paginationWithControls: be, paginationActiveTextColor: Te, paginationActiveBackgroundColor: ge, paginationSize: j, paginationText: he, paginationWrapBreakpoint: Ce, getPaginationControlProps: X, noRecordsText: ut, loadingText: Qo, recordsLength: Ne }), jsxRuntimeExports.jsx(bo, { pt: Ze, pb: Ct, fetching: s, backgroundBlur: _o, customContent: Fo, size: Bo, type: Go, color: Xo }), jsxRuntimeExports.jsx(Ht, { pt: Ze, pb: Ct, icon: $o, text: ut, active: !s && !Ne, children: Uo })] }) });
}
const jr = window["MantineCore"].TableTr;
const tl = window["React"].forwardRef;
const ol = window["React"].useEffect;
const al = window["React"].useRef;
var Vo = tl(function({ children: e, isDragging: t, ...o }, n) {
  let a = al(null), r2 = useMergedRef(a, n);
  return ol(() => {
    if (!a.current || !t) return;
    let d = a.current.parentElement.parentElement.children[0].children[0];
    for (let m = 0; m < d.children.length; m++) {
      let p = d.children[m].getBoundingClientRect(), T = a.current.children[m];
      T.style.height = p.height + "px", T.style.width = p.width + "px", T.style.minWidth = p.width + "px", T.style.maxWidth = p.width + "px";
    }
  }, [t, e]), jsxRuntimeExports.jsx(jr, { "data-is-dragging": t, ref: r2, ...o, children: e });
});
Vo.displayName = "DataTableDraggableRow";
export {
  ApiEndpoints as A,
  IconInfoCircle as I,
  RowEditAction as R,
  SearchInput as S,
  YesNoButton as Y,
  useMonitorDataOutput as a,
  apiUrl as b,
  RowDuplicateAction as c,
  RowDeleteAction as d,
  RowActions as e,
  formatCurrencyValue as f,
  IconExclamationCircle as g,
  ActionButton as h,
  IconFileUpload as i,
  AddItemButton as j,
  IconRefresh as k,
  IconFileDownload as l,
  checkPluginVersion as m,
  createReactComponent as n,
  RowViewAction as o,
  formatDecimal as p,
  qr as q,
  useQuery as u
};
//# sourceMappingURL=index-BRkHMwZw.js.map
