
# DevPulse

  

> Real-time terminal dashboard for developers.

  

DevPulse is a modern terminal-based system monitor built for developers.

Track CPU, RAM, disk usage, network activity, running processes, and live Git repository activity directly from your terminal.

  

Built with Python, Rich, Typer, SQLAlchemy, and psutil.

  

---

  

## Preview

  

![DevPulse GIF](assets/demo.gif)

  



  

---

  

## Features

  

* Real-time system monitoring

* Live CPU / RAM / Disk metrics

* GPU usage support (NVIDIA)

* Network upload/download tracking

* Running process monitor

* Git repository activity panel

* Terminal dashboard UI powered by Rich

* Historical analytics tracking

* SQLite-based lightweight logging

  

---

  

## Installation

  

### Install from PyPI

  

```bash

pip  install  devpulse

```

### Clone Repository

  

```bash

git  clone  https://github.com/eyeblech/DevPulse.git

cd  DevPulse

```

  

### Create Virtual Environment

  

```bash

python  -m  venv  venv

source  venv/bin/activate

```

  

### Install Dependencies

  

```bash

pip  install  -r  requirements.txt

```

  

---

  

## Usage

  

### Launch Live Dashboard

  

```bash

devpulse  live

```

  

### Show Analytics

  

```bash

devpulse  stats

```

  

### Run Diagnostics

  

```bash

devpulse  doctor

```

  

### Show Version

  

```bash

devpulse  version

```

  




  
  

## Tech Stack

  

* Python

* Rich

* Typer

* psutil

* SQLAlchemy

* SQLite

  

  

## Why I Built This

  

I wanted a terminal dashboard that combined:

  

* system monitoring

* developer workflow visibility

* git awareness

* lightweight analytics

  

into a single modern TUI experience.

  

DevPulse started as a learning project and evolved into a polished developer utility focused on Linux workflows.

  

---

  
  

## Screenshots

  

### Live Dashboard

  

![Dashboard](assets/dashboard.png)

  

### Analytics

  

![Analytics](assets/stats.png)



  



  

## Contributing

  

Pull requests, issues, and feature suggestions are welcome.

  

If you find a bug or want to improve DevPulse, feel free to open an issue.

  

  

## License

  

MIT License

  


  

## Author

  

EyeBlech
