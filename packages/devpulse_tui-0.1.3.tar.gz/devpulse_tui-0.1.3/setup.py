from setuptools import setup, find_packages

setup(
    name="devpulse-tui",
    version="0.1.3",
    author="eyeblech",
    description="Real-time terminal dashboard for developers",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "rich",
        "typer",
        "psutil",
        "sqlalchemy",
        "readchar",
    ],
    entry_points={
        "console_scripts": [
            "devpulse=devpulse.main:app",
        ]
    },
    python_requires=">=3.9",
)