import typer

from devpulse.live import run_live_dashboard
from devpulse.stats import show_stats
from devpulse.doctor import run_doctor
app = typer.Typer(no_args_is_help=True)


@app.command()
def live():
    """Launch live dashboard"""
    run_live_dashboard()


@app.command()
def version():
    print("DevPulse v0.1")

@app.command()
def stats():
    """Show DevPulse analytics"""
    show_stats()

@app.command()
def doctor():
    """Run DevPulse diagnostics"""
    run_doctor()

if __name__ == "__main__":
    app()