import os
import subprocess
from pathlib import Path
from datetime import datetime
from git import Repo


def find_git_repo():
    current = Path.cwd()

    for parent in [current] + list(current.parents):
        if (parent / ".git").exists():
            return parent

    return None


def get_git_info():
    try:
        repo = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL
        ).decode().strip().split("/")[-1]

        branch = subprocess.check_output(
            ["git", "branch", "--show-current"],
            stderr=subprocess.DEVNULL
        ).decode().strip()

        status_output = subprocess.check_output(
            ["git", "status", "--short"],
            stderr=subprocess.DEVNULL
        ).decode().splitlines()

        commit_msg = subprocess.check_output(
            ["git", "log", "-1", "--pretty=%s"],
            stderr=subprocess.DEVNULL
        ).decode().strip()

        author = subprocess.check_output(
            ["git", "log", "-1", "--pretty=%an"],
            stderr=subprocess.DEVNULL
        ).decode().strip()

        commit_age = subprocess.check_output(
            ["git", "log", "-1", "--pretty=%cr"],
            stderr=subprocess.DEVNULL
        ).decode().strip()

        insertions = 0
        deletions = 0
        untracked = 0

        for line in status_output:
            if line.startswith("??"):
                untracked += 1

        diff_stats = subprocess.check_output(
            ["git", "diff", "--shortstat"],
            stderr=subprocess.DEVNULL
        ).decode().strip()

        if "insertion" in diff_stats:
            insertions = diff_stats.split("insertion")[0].split()[-1]

        if "deletion" in diff_stats:
            deletions = diff_stats.split("deletion")[0].split()[-1]

        return {
            "repo": repo,
            "branch": branch,
            "status": "DIRTY" if status_output else "CLEAN",
            "untracked": str(untracked),
            "insertions": f"+{insertions}",
            "deletions": f"-{deletions}",
            "author": author,
            "commit_age": commit_age,
            "last_commit": commit_msg,
            "files_changed": str(len(status_output))
        }

    except Exception:
        return {
            "repo": "Unknown",
            "branch": "Unknown",
            "status": "Unknown",
            "untracked": "0",
            "insertions": "0",
            "deletions": "0",
            "author": "Unknown",
            "commit_age": "Unknown",
            "last_commit": "Unknown",
            "files_changed": "0"
        }

def get_shell():
    return os.environ.get("SHELL", "Unknown")


def get_terminal():
    return os.environ.get("TERM", "Unknown")


def get_current_directory():
    return str(Path.cwd())

def get_last_commit():
    repo_path = find_git_repo()

    if not repo_path:
        return "No Repo"

    try:
        repo = Repo(repo_path)

        commit = repo.head.commit.message.strip()

        return commit[:40]

    except Exception:
        return "Unknown"


def get_changed_files_count():
    repo_path = find_git_repo()

    if not repo_path:
        return 0

    try:
        repo = Repo(repo_path)

        changed_files = repo.index.diff(None)

        return len(changed_files)

    except Exception:
        return 0


def get_repo_status():
    repo_path = find_git_repo()

    if not repo_path:
        return "NO REPO"

    try:
        repo = Repo(repo_path)

        return "DIRTY" if repo.is_dirty() else "CLEAN"

    except Exception:
        return "UNKNOWN"


def get_untracked_files_count():
    repo_path = find_git_repo()

    if not repo_path:
        return 0

    try:
        repo = Repo(repo_path)

        return len(repo.untracked_files)

    except Exception:
        return 0


def get_insertions_deletions():
    repo_path = find_git_repo()

    if not repo_path:
        return 0, 0

    try:
        repo = Repo(repo_path)

        diff = repo.git.diff("--shortstat")

        insertions = 0
        deletions = 0

        import re

        insert_match = re.search(r'(\d+) insertion', diff)
        delete_match = re.search(r'(\d+) deletion', diff)

        if insert_match:
            insertions = int(insert_match.group(1))

        if delete_match:
            deletions = int(delete_match.group(1))

        return insertions, deletions

    except Exception:
        return 0, 0


def get_last_commit_author():
    repo_path = find_git_repo()

    if not repo_path:
        return "Unknown"

    try:
        repo = Repo(repo_path)

        return repo.head.commit.author.name

    except Exception:
        return "Unknown"


def get_last_commit_age():
    repo_path = find_git_repo()

    if not repo_path:
        return "Unknown"

    try:
        repo = Repo(repo_path)

        commit_time = datetime.fromtimestamp(
            repo.head.commit.committed_date
        )

        delta = datetime.now() - commit_time

        hours = delta.seconds // 3600

        if delta.days > 0:
            return f"{delta.days}d ago"

        return f"{hours}h ago"

    except Exception:
        return "Unknown"