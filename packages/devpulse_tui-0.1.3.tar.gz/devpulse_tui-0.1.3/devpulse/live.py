import os
import time
import socket
import platform
import psutil
import subprocess
import readchar
import sys
import select
import termios
import tty
from devpulse.database import log_system_stats
from devpulse.devinfo import (
    get_git_info,
    get_shell,
    get_terminal,
    get_current_directory,
    get_last_commit,
    get_changed_files_count,
    get_repo_status,
    get_untracked_files_count,
    get_insertions_deletions,
    get_last_commit_author,
    get_last_commit_age,
)
from rich.panel import Panel
from rich.table import Table
from rich.layout import Layout
from rich.live import Live
from rich.columns import Columns
from rich.text import Text
from rich.align import Align

try:
    from py3nvml.py3nvml import (
        nvmlInit,
        nvmlDeviceGetHandleByIndex,
        nvmlDeviceGetUtilizationRates,
        nvmlDeviceGetMemoryInfo,
    )

    nvmlInit()
    NVIDIA_AVAILABLE = True

except Exception:
    NVIDIA_AVAILABLE = False


previous_net = psutil.net_io_counters()


_last_bytes_sent = 0
_last_bytes_recv = 0
_last_time = time.time()


def get_network_speed():
    global _last_bytes_sent
    global _last_bytes_recv
    global _last_time

    current = psutil.net_io_counters()

    now = time.time()

    time_diff = now - _last_time

    upload_speed = (
        (current.bytes_sent - _last_bytes_sent)
        * 8
        / time_diff
    )

    download_speed = (
        (current.bytes_recv - _last_bytes_recv)
        * 8
        / time_diff
    )

    _last_bytes_sent = current.bytes_sent
    _last_bytes_recv = current.bytes_recv
    _last_time = now

    return upload_speed, download_speed

def get_gpu_stats():
    if not NVIDIA_AVAILABLE:
        return "N/A", "N/A"

    try:
        handle = nvmlDeviceGetHandleByIndex(0)

        utilization = nvmlDeviceGetUtilizationRates(handle)
        memory = nvmlDeviceGetMemoryInfo(handle)

        gpu_percent = utilization.gpu
        mem_percent = round((memory.used / memory.total) * 100)

        return f"{gpu_percent}%", f"{mem_percent}%"

    except Exception:
        return "Error", "Error"



def format_bits(bits):
    if bits >= 1_000_000:
        return f"{bits / 1_000_000:.2f} Mbps"

    if bits >= 1_000:
        return f"{bits / 1_000:.2f} Kbps"

    return f"{bits:.0f} bps"

def run_git(command):
    try:
        result = subprocess.check_output(
            command,
            shell=True,
            stderr=subprocess.DEVNULL
        )
        return result.decode().strip()
    except:
        return "N/A"


def build_system_table():
    upload, download = get_network_speed()
    git_info = get_git_info()
    cpu_percent = psutil.cpu_percent()
    ram_percent = psutil.virtual_memory().percent
    disk_percent = psutil.disk_usage('/').percent
    gpu_usage, gpu_mem = get_gpu_stats()
    log_system_stats(
        cpu=cpu_percent,
        ram=ram_percent,
        disk=disk_percent,
        gpu=gpu_usage,
        upload=upload,
        download=download,
        repo=git_info["repo"],
        branch=git_info["branch"],
    )
    
    table = Table(
        expand=True,
        show_edge=False,
        pad_edge=False
    )

    table.add_column(
        "Metric",
        style="cyan",
        width=18
    )

    table.add_column(
        "Value",
        style="green",
        overflow="fold"
    )

    table.add_row("Hostname", socket.gethostname())
    table.add_row("OS", platform.system())
    table.add_row("Kernel", platform.release())

    table.add_row(
        "Git Repo",
        git_info["repo"]
    )

    table.add_row(
        "Git Branch",
        git_info["branch"]
    )

    table.add_row(
        "Shell",
        get_shell()
    )

    table.add_row(
        "Terminal",
        get_terminal()
    )
    table.add_row(
        "Directory",
        get_current_directory()[:40]
    )

    table.add_row(
        "CPU Usage",
        f"{cpu_percent}%"
    )

    table.add_row(
        "RAM Usage",
        f"{ram_percent}%"
    )

    table.add_row(
        "Disk Usage",
        f"{disk_percent}%"
    )

    table.add_row(
        "GPU Usage",
        gpu_usage
    )

    table.add_row(
        "GPU Memory",
        gpu_mem
    )

    table.add_row(
        "Upload",
        format_bits(upload)
    )

    table.add_row(
        "Download",
        format_bits(download)
    )

    return table


def build_cpu_table():
    table = Table(expand=True)

    table.add_column("Core")
    table.add_column("Usage")

    for i, percent in enumerate(psutil.cpu_percent(percpu=True)):
        bar = "█" * int(percent / 5)

        table.add_row(
            f"CPU {i}",
            f"{bar} {percent}%"
        )

    return table


def build_process_table():
    table = Table(expand=True)

    table.add_column("PID", style="magenta")
    table.add_column("Name", style="cyan")
    table.add_column("CPU %", style="green")

    processes = []

    for proc in psutil.process_iter(
        ['pid', 'name', 'cpu_percent']
    ):
        try:
            processes.append(proc.info)
        except Exception:
            pass

    processes = sorted(
        processes,
        key=lambda p: p['cpu_percent'],
        reverse=True
    )[:18]

    for proc in processes:
        table.add_row(
            str(proc['pid']),
            str(proc['name']),
            str(proc['cpu_percent'])
        )

    return table


def build_header():
    text = Text(
        " DEVPULSE ",
        style="bold black on cyan"
    )

    return Panel(
        Align.center(text),
        border_style="cyan"
    )

def build_footer():
    footer_text = Text()

    footer_text.append("[Q] Quit", style="bold cyan")
    footer_text.append("   ")
    footer_text.append("[R] Refresh", style="bold green")
    footer_text.append("   ")
    footer_text.append("DevPulse v0.1", style="bold magenta")

    return Panel(
        Align.center(footer_text),
        border_style="cyan"
    )


def build_git_activity_table():
    git_table = Table(expand=True)

    git_table.add_column("Field", style="cyan", no_wrap=True)
    git_table.add_column("Value", style="green")

    repo = run_git(
        "git rev-parse --show-toplevel"
    ).split("/")[-1]

    branch = run_git(
        "git branch --show-current"
    )

    last_commit = run_git(
        "git log -1 --pretty=%s"
    )

    author = run_git(
        "git log -1 --pretty=%an"
    )

    commit_age = run_git(
        "git log -1 --pretty=%cr"
    )

    status = run_git(
        "git status --short"
    )

    changed_files = (
        len(status.splitlines())
        if status and status != "N/A"
        else 0
    )

    untracked = len([
        x for x in status.splitlines()
        if x.startswith("??")
    ]) if status and status != "N/A" else 0

    insertions = run_git(
        "git diff --shortstat | grep -o '[0-9]* insertion' | awk '{print $1}'"
    )

    deletions = run_git(
        "git diff --shortstat | grep -o '[0-9]* deletion' | awk '{print $1}'"
    )

    git_table.add_row(
        "Status",
        "DIRTY" if changed_files else "CLEAN"
    )

    git_table.add_row("Repository", repo)
    git_table.add_row("Branch", branch)
    git_table.add_row("Author", author)
    git_table.add_row("Commit Age", commit_age)
    git_table.add_row("Last Commit", last_commit[:40])
    git_table.add_row("Files Changed", str(changed_files))
    git_table.add_row("Untracked", str(untracked))
    git_table.add_row("Insertions", f"+{insertions or 0}")
    git_table.add_row("Deletions", f"-{deletions or 0}")

    return git_table

def build_dashboard():
    layout = Layout()

    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="main", ratio=1),
        Layout(name="footer", size=3)
    )

    layout["main"].split_row(
        Layout(name="left", ratio=1),
        Layout(name="right", ratio=1)
    )

    layout["left"].split_column(
        Layout(name="system", ratio=3),
        Layout(name="network", ratio=2),
        Layout(name="cpu", ratio=4)
    )

    layout["right"].split_column(
        Layout(name="processes", ratio=5),
        Layout(name="git", ratio=4)
    )

    layout["header"].update(build_header())
    layout["footer"].update(build_footer())

    layout["system"].update(
        Panel(
            build_system_table(),
            title="System",
            border_style="green"
        )
    )

    layout["right"]["git"].update(
        build_git_panel()
    )

    layout["network"].update(
        build_network_panel()
    )

    layout["cpu"].update(
        Panel(
            build_cpu_table(),
            title="CPU Cores",
            border_style="yellow"
        )
    )

    layout["right"]["processes"].update(
        Panel(
            build_process_table(),
            title="Top Processes",
            border_style="magenta"
        )
    )
    layout["git"].update(
        Panel(
            build_git_activity_table(),
            title="Git Activity",
            border_style="bright_blue"
        )
    )

    return layout

def key_pressed():
    dr, _, _ = select.select([sys.stdin], [], [], 0)
    return dr != []

def run_live_dashboard():
    psutil.cpu_percent(interval=None)

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    try:
        tty.setcbreak(fd)

        with Live(
            build_dashboard(),
            refresh_per_second=2,
            screen=True,
        ) as live:

            while True:
                live.update(build_dashboard())

                if key_pressed():
                    key = sys.stdin.read(1)

                    if key.lower() == "q":
                        break

                    elif key.lower() == "r":
                        live.update(build_dashboard())

                time.sleep(0.5)

    finally:
        termios.tcsetattr(
            fd,
            termios.TCSADRAIN,
            old_settings
        )

def build_git_panel():
    git_info = get_git_info()
    insertions, deletions = get_insertions_deletions()
    table = Table(expand=True)

    table.add_column("Field", style="cyan")
    table.add_column("Value", style="green")
    
    table.add_row(
        "Status",
        get_repo_status()
    )

    table.add_row(
        "Untracked",
        str(get_untracked_files_count())
    )

    table.add_row(
        "Insertions",
        f"+{insertions}"
    )

    table.add_row(
        "Deletions",
        f"-{deletions}"
    )

    table.add_row(
        "Author",
        get_last_commit_author()
    )

    table.add_row(
        "Commit Age",
        get_last_commit_age()
    )

    table.add_row(
        "Repository",
        git_info["repo"]
    )

    table.add_row(
        "Branch",
        git_info["branch"]
    )

    table.add_row(
        "Last Commit",
        get_last_commit()
    )

    table.add_row(
        "Files Changed",
        str(get_changed_files_count())
    )
    
    return Panel(
        table,
        title="Git Activity",
        border_style="blue"
    )

def build_network_panel():
    net_io = psutil.net_io_counters()

    upload, download = get_network_speed()

    table = Table(expand=True)

    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row(
        "Upload Speed",
        f"{upload:.2f} KB/s"
    )

    table.add_row(
        "Download Speed",
        f"{download:.2f} KB/s"
    )

    table.add_row(
        "Total Sent",
        f"{net_io.bytes_sent / (1024**3):.2f} GB"
    )

    table.add_row(
        "Total Received",
        f"{net_io.bytes_recv / (1024**3):.2f} GB"
    )

    return Panel(
        table,
        title="Network",
        border_style="magenta"
    )

