from sqlalchemy import func

from rich.console import Console
from rich.table import Table

from devpulse.database import (
    SessionLocal,
    SystemStat,
)


console = Console()


def show_stats():
    session = SessionLocal()

    total_rows = session.query(SystemStat).count()

    avg_cpu = session.query(
        func.avg(SystemStat.cpu)
    ).scalar()

    avg_ram = session.query(
        func.avg(SystemStat.ram)
    ).scalar()

    peak_cpu = session.query(
        func.max(SystemStat.cpu)
    ).scalar()

    peak_ram = session.query(
        func.max(SystemStat.ram)
    ).scalar()

    top_repo = (
        session.query(
            SystemStat.repo,
            func.count(SystemStat.repo)
        )
        .group_by(SystemStat.repo)
        .order_by(func.count(SystemStat.repo).desc())
        .first()
    )

    table = Table(title="DevPulse Analytics")

    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row(
        "Rows Logged",
        str(total_rows)
    )

    table.add_row(
        "Average CPU",
        f"{avg_cpu:.2f}%"
    )

    table.add_row(
        "Average RAM",
        f"{avg_ram:.2f}%"
    )

    table.add_row(
        "Peak CPU",
        f"{peak_cpu:.2f}%"
    )

    table.add_row(
        "Peak RAM",
        f"{peak_ram:.2f}%"
    )

    if top_repo:
        table.add_row(
            "Top Repo",
            top_repo[0]
        )

    console.print(table)

    session.close()