import os
import sqlite3
import importlib.util

from rich.console import Console
from rich.table import Table


console = Console()


def check_package(package_name):
    return importlib.util.find_spec(package_name) is not None


def run_doctor():
    table = Table(title="DevPulse Doctor")

    table.add_column("Check", style="cyan")
    table.add_column("Status", style="green")

    # Database check
    db_exists = os.path.exists("devpulse.db")

    table.add_row(
        "SQLite Database",
        "OK" if db_exists else "MISSING"
    )

    # SQLite readable
    try:
        conn = sqlite3.connect("devpulse.db")
        conn.execute("SELECT 1")
        conn.close()

        table.add_row(
            "Database Access",
            "OK"
        )

    except Exception:
        table.add_row(
            "Database Access",
            "FAILED"
        )

    # Dependencies
    dependencies = [
        "psutil",
        "rich",
        "sqlalchemy",
        "git",
    ]

    for dep in dependencies:
        installed = check_package(dep)

        table.add_row(
            f"Dependency: {dep}",
            "OK" if installed else "MISSING"
        )

    # NVIDIA support
    nvidia_available = check_package("py3nvml")

    table.add_row(
        "NVIDIA Support",
        "ENABLED" if nvidia_available else "DISABLED"
    )

    console.print(table)