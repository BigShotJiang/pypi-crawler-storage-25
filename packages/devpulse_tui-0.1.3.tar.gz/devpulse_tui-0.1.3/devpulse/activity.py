import subprocess
import time


CODING_KEYWORDS = [
    "code",
    "nvim",
    "vim",
    "pycharm",
    "idea",
    "terminal",
    "konsole",
    "kitty",
    "github",
]


session_start = time.time()


def get_active_window():
    try:
        window_name = subprocess.check_output(
            ["xdotool", "getactivewindow", "getwindowname"],
            text=True
        ).strip()

        return window_name

    except Exception:
        return "Unknown"


def is_coding(window_name):
    window_name = window_name.lower()

    return any(
        keyword in window_name
        for keyword in CODING_KEYWORDS
    )


def get_session_duration():
    seconds = int(time.time() - session_start)

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60

    return f"{hours:02}:{minutes:02}:{secs:02}"