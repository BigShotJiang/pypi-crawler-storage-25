# plain-support changelog

## [0.34.0](https://github.com/dropseed/plain/releases/plain-support@0.34.0) (2026-03-28)

### What's changed

- Replaced `CharField` with `TextField` in models and migration files to match plain-postgres 0.90.0 ([5062ee4dd1fd](https://github.com/dropseed/plain/commit/5062ee4dd1fd))

### Upgrade instructions

- Requires `plain-postgres>=0.90.0`
- Replace `CharField` with `TextField` in migration files that reference this package's models

## [0.33.1](https://github.com/dropseed/plain/releases/plain-support@0.33.1) (2026-03-27)

### What's changed

- Updated form field references from `CharField` to `TextField` in README example ([4e29f5d6cade](https://github.com/dropseed/plain/commit/4e29f5d6cade))

### Upgrade instructions

- Requires `plain>=0.129.0`. No other changes required.

## [0.33.0](https://github.com/dropseed/plain/releases/plain-support@0.33.0) (2026-03-25)

### What's changed

- Added explicit `Index` on `SupportFormEntry.user` FK field — replaces the old auto-created index from `db_index=True`. Migration drops the orphan auto-index and creates the new named index. ([061b97f5d538](https://github.com/dropseed/plain/commit/061b97f5d538))

### Upgrade instructions

- Requires `plain-postgres>=0.89.0`. Run `uv run plain postgres migrate`.

## [0.32.1](https://github.com/dropseed/plain/releases/plain-support@0.32.1) (2026-03-25)

### What's changed

- Renamed indexes to use readable `{table}_{column}_idx` naming convention, replacing the old truncated hash-based names. Includes a migration with `RenameIndex` operations (instant `ALTER INDEX RENAME`, no locks). ([74aa8b76aa40](https://github.com/dropseed/plain/commit/74aa8b76aa40))

### Upgrade instructions

- Run `plain migrate` to apply the index rename migration. This is an instant metadata-only operation with no performance impact.

## [0.32.0](https://github.com/dropseed/plain/releases/plain-support@0.32.0) (2026-03-12)

### What's changed

- Updated all imports from `plain.models` to `plain.postgres` in forms, models, migrations, and README.
- Updated `pyproject.toml` dependency from `plain.models` to `plain.postgres`.

### Upgrade instructions

- Update imports: `from plain.models` to `from plain.postgres`, `from plain import models` to `from plain import postgres`.
- Update dependency declarations: `plain.models` to `plain.postgres` in `pyproject.toml`.

## [0.31.6](https://github.com/dropseed/plain/releases/plain-support@0.31.6) (2026-03-11)

### What's changed

- Added `allow_external=True` to the support JS asset redirect, since it may resolve to a CDN URL when `ASSETS_CDN_URL` is configured ([5edfb2bedf90](https://github.com/dropseed/plain/commit/5edfb2bedf90))

### Upgrade instructions

- Requires `plain>=0.123.0`. No other changes required.

## [0.31.5](https://github.com/dropseed/plain/releases/plain-support@0.31.5) (2026-02-26)

### What's changed

- Added type annotation to `SUPPORT_FORMS` setting so it can be set via environment variables ([37e8a58ca9b5](https://github.com/dropseed/plain/commit/37e8a58ca9b5))

### Upgrade instructions

- No changes required.

## [0.31.4](https://github.com/dropseed/plain/releases/plain-support@0.31.4) (2026-02-26)

### What's changed

- Auto-formatted JavaScript assets and config files with updated linter configuration ([028bb95c3ae3](https://github.com/dropseed/plain/commit/028bb95c3ae3))

### Upgrade instructions

- No changes required.

## [0.31.3](https://github.com/dropseed/plain/releases/plain-support@0.31.3) (2026-02-04)

### What's changed

- Added `__all__` export to `models` module for explicit public API boundaries ([f26a63a5c941](https://github.com/dropseed/plain/commit/f26a63a5c941))

### Upgrade instructions

- No changes required.

## [0.31.2](https://github.com/dropseed/plain/releases/plain-support@0.31.2) (2026-01-28)

### What's changed

- Added Settings section to README ([803fee1ad5](https://github.com/dropseed/plain/commit/803fee1ad5))

### Upgrade instructions

- No changes required.

## [0.31.1](https://github.com/dropseed/plain/releases/plain-support@0.31.1) (2026-01-22)

### What's changed

- Migration now uses `settings.AUTH_USER_MODEL` instead of hardcoded `"users.user"`, enabling support for projects with custom user models ([76e28f6](https://github.com/dropseed/plain/commit/76e28f6))

### Upgrade instructions

- No changes required

## [0.31.0](https://github.com/dropseed/plain/releases/plain-support@0.31.0) (2026-01-15)

### What's changed

- Internal type annotation cleanup for iframe X-Frame-Options handling ([cbf27e7](https://github.com/dropseed/plain/commit/cbf27e7))

### Upgrade instructions

- No changes required

## [0.30.0](https://github.com/dropseed/plain/releases/plain-support@0.30.0) (2026-01-15)

### What's changed

- Added description to the Support admin viewset for the admin redesign ([0fc4dd3](https://github.com/dropseed/plain/commit/0fc4dd3))

### Upgrade instructions

- No changes required

## [0.29.0](https://github.com/dropseed/plain/releases/plain-support@0.29.0) (2026-01-13)

### What's changed

- Improved README documentation with better structure, table of contents, and clearer examples ([da37a78](https://github.com/dropseed/plain/commit/da37a78))

### Upgrade instructions

- No changes required

## [0.28.0](https://github.com/dropseed/plain/releases/plain-support@0.28.0) (2026-01-13)

### What's changed

- Updated to use `RedirectResponse` instead of `ResponseRedirect` following the framework-wide response class renaming ([fad5bf2](https://github.com/dropseed/plain/commit/fad5bf2))

### Upgrade instructions

- No changes required

## [0.27.1](https://github.com/dropseed/plain/releases/plain-support@0.27.1) (2025-12-22)

### What's changed

- Internal type annotation cleanup ([539a706](https://github.com/dropseed/plain/commit/539a706))

### Upgrade instructions

- No changes required

## [0.27.0](https://github.com/dropseed/plain/releases/plain-support@0.27.0) (2025-11-24)

### What's changed

- `SupportFormView` now inherits from `AuthView` instead of using `AuthViewMixin` for improved type checking ([569afd6](https://github.com/dropseed/plain/commit/569afd6))

### Upgrade instructions

- No changes required

## [0.26.0](https://github.com/dropseed/plain/releases/plain-support@0.26.0) (2025-11-21)

### What's changed

- `ForeignKey` has been renamed to `ForeignKeyField` for consistency with other field types ([8010204](https://github.com/dropseed/plain/commit/8010204))

### Upgrade instructions

- No changes required

## [0.25.1](https://github.com/dropseed/plain/releases/plain-support@0.25.1) (2025-11-17)

### What's changed

- QuerySet type annotations no longer use `ClassVar`, reverting to simpler type annotations ([1c624ff](https://github.com/dropseed/plain/commit/1c624ff))

### Upgrade instructions

- No changes required

## [0.25.0](https://github.com/dropseed/plain/releases/plain-support@0.25.0) (2025-11-14)

### What's changed

- Foreign key fields no longer use `related_name` parameter, requiring explicit reverse queries instead ([a4b6309](https://github.com/dropseed/plain/commit/a4b6309))

### Upgrade instructions

- If you were accessing support form entries via `user.support_form_entries`, replace it with explicit queries like `SupportFormEntry.query.filter(user=user)`

## [0.24.0](https://github.com/dropseed/plain/releases/plain-support@0.24.0) (2025-11-13)

### What's changed

- QuerySet type annotations now use `ClassVar` for improved type checking and IDE support ([c3b00a6](https://github.com/dropseed/plain/commit/c3b00a6))

### Upgrade instructions

- No changes required

## [0.23.0](https://github.com/dropseed/plain/releases/plain-support@0.23.0) (2025-11-13)

### What's changed

- Model field definitions now use type stubs with explicit type annotations for improved IDE support and type checking ([c8f40fc](https://github.com/dropseed/plain/commit/c8f40fc))

### Upgrade instructions

- No changes required

## [0.22.0](https://github.com/dropseed/plain/releases/plain-support@0.22.0) (2025-11-12)

### What's changed

- Improved type checking compatibility with added type ignore comments for ORM patterns ([f4dbcef](https://github.com/dropseed/plain/commit/f4dbcef))

### Upgrade instructions

- No changes required

## [0.21.2](https://github.com/dropseed/plain/releases/plain-support@0.21.2) (2025-11-03)

### What's changed

- Iframe JavaScript now includes CSP nonce for improved Content Security Policy compatibility ([7b8f8d2](https://github.com/dropseed/plain/commit/7b8f8d2fe4))

### Upgrade instructions

- No changes required

## [0.21.1](https://github.com/dropseed/plain/releases/plain-support@0.21.1) (2025-10-31)

### What's changed

- Added BSD-3-Clause license file and declaration to package metadata ([8477355](https://github.com/dropseed/plain/commit/8477355e65))

### Upgrade instructions

- No changes required

## [0.21.0](https://github.com/dropseed/plain/releases/plain-support@0.21.0) (2025-10-29)

### What's changed

- Updated iframe view to use `None` instead of empty string to remove `X-Frame-Options` header, aligning with new response header handling ([5199383](https://github.com/dropseed/plain/commit/5199383128))

### Upgrade instructions

- No changes required

## [0.20.0](https://github.com/dropseed/plain/releases/plain-support@0.20.0) (2025-10-07)

### What's changed

- Model configuration now uses `model_options` descriptor instead of `class Meta` ([17a378d](https://github.com/dropseed/plain/commit/17a378dcfb), [73ba469](https://github.com/dropseed/plain/commit/73ba469ba0))

### Upgrade instructions

- No changes required

## [0.19.1](https://github.com/dropseed/plain/releases/plain-support@0.19.1) (2025-10-06)

### What's changed

- Added type annotations throughout the package for improved IDE support and type checking ([c87ca27](https://github.com/dropseed/plain/commit/c87ca27ed2))

### Upgrade instructions

- No changes required

## [0.19.0](https://github.com/dropseed/plain/releases/plain-support@0.19.0) (2025-10-02)

### What's changed

- `SupportFormView` now uses `AuthViewMixin` for better authentication handling and accesses user via `self.user` instead of `self.request.user` ([154ee10](https://github.com/dropseed/plain/commit/154ee10375))

### Upgrade instructions

- If you have custom support views that inherit from `SupportFormView` and access `self.request.user` directly, update them to use `self.user` instead

## [0.18.0](https://github.com/dropseed/plain/releases/plain-support@0.18.0) (2025-09-26)

### What's changed

- Removed unused `uuid` field from `SupportFormEntry` model ([331ce37](https://github.com/dropseed/plain/commit/331ce37992))

### Upgrade instructions

- No changes required

## [0.17.0](https://github.com/dropseed/plain/releases/plain-support@0.17.0) (2025-09-12)

### What's changed

- Model managers have been renamed from `.objects` to `.query` throughout the codebase ([037a239](https://github.com/dropseed/plain/commit/037a239ef4))
- Python 3.13 is now the minimum required version ([d86e307](https://github.com/dropseed/plain/commit/d86e307efb))

### Upgrade instructions

- Replace any usage of `.objects` with `.query` when working with Plain models (e.g., `SupportFormEntry.objects.all()` becomes `SupportFormEntry.query.all()`)

## [0.16.0](https://github.com/dropseed/plain/releases/plain-support@0.16.0) (2025-08-22)

### What's changed

- Admin interface navigation icon is now properly positioned on the section when sections are present ([5a6479ac79](https://github.com/dropseed/plain/commit/5a6479ac79))
- Improved iframe embed error state handling with better timeout logic and race condition prevention ([6bb1567a25](https://github.com/dropseed/plain/commit/6bb1567a25))

### Upgrade instructions

- No changes required

## [0.15.0](https://github.com/dropseed/plain/releases/plain-support@0.15.0) (2025-08-19)

### What's changed

- Support forms now use Plain's new CSRF protection with `Sec-Fetch-Site` headers instead of CSRF tokens ([955150800c](https://github.com/dropseed/plain/commit/955150800c))
- `SupportIFrameView` no longer inherits from `CsrfExemptViewMixin`, using path-based CSRF exemption instead ([2a50a9154e](https://github.com/dropseed/plain/commit/2a50a9154e))
- Comprehensive README documentation updates with better structure, examples, and installation instructions ([4ebecd1856](https://github.com/dropseed/plain/commit/4ebecd1856))

### Upgrade instructions

- No changes required

## [0.14.1](https://github.com/dropseed/plain/releases/plain-support@0.14.1) (2025-07-23)

### What's changed

- Admin interface now displays a headset icon for the Support navigation section ([9e9f8b0e2c](https://github.com/dropseed/plain/commit/9e9f8b0e2c))

### Upgrade instructions

- No changes required

## [0.14.0](https://github.com/dropseed/plain/releases/plain-support@0.14.0) (2025-07-22)

### What's changed

- Database models now use the new `PrimaryKeyField` instead of `BigAutoField` for primary keys ([4b8fa6aef1](https://github.com/dropseed/plain/commit/4b8fa6aef1))

### Upgrade instructions

- No changes required

## [0.13.0](https://github.com/dropseed/plain/releases/plain-support@0.13.0) (2025-07-18)

### What's changed

- Migrations have been restarted and consolidated into a single initial migration file ([484f1b6e93](https://github.com/dropseed/plain/commit/484f1b6e93))

### Upgrade instructions

- Run `plain migrate --prune plainsupport` to update your migration history and remove references to the old migration files

## [0.12.3](https://github.com/dropseed/plain/releases/plain-support@0.12.3) (2025-06-24)

### What's changed

- No user-facing changes. Internal cleanup of CHANGELOG formatting and linting (e1f5dd3, 9a1963d, 82710c3).

### Upgrade instructions

- No changes required
