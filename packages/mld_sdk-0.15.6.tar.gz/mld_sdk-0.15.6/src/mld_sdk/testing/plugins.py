"""Helpers for building mock ``AnalysisPlugin`` instances in tests."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Optional

from mld_sdk.models import PluginCapabilities, PluginMetadata, PluginType
from mld_sdk.plugin import (
    AnalysisPlugin,
    HealthStatus,
    LifecycleHookResult,
    PluginHealth,
)

if TYPE_CHECKING:
    from fastapi import APIRouter, FastAPI


RouteBuilder = Callable[["APIRouter"], None]
BeforeSaveHook = Callable[[int, dict[str, Any]], LifecycleHookResult]
AfterSaveHook = Callable[[int, dict[str, Any]], None]
StatusChangeHook = Callable[[int, str, str], None]


def make_test_plugin(
    *,
    name: str = "test-plugin",
    version: str = "0.0.1",
    routes_prefix: str = "/test-plugin",
    plugin_type: PluginType = PluginType.ANALYSIS,
    analysis_type: str = "test",
    capabilities: PluginCapabilities | None = None,
    route_builder: Optional[RouteBuilder] = None,
    sub_prefix: str = "",
    before_save: Optional[BeforeSaveHook] = None,
    after_save: Optional[AfterSaveHook] = None,
    status_change: Optional[StatusChangeHook] = None,
    health_status: HealthStatus | str = HealthStatus.HEALTHY,
    health_message: Optional[str] = None,
) -> type[AnalysisPlugin]:
    """Build a minimal ``AnalysisPlugin`` subclass for tests.

    All parameters are keyword-only so test authors can set only the
    pieces they care about.  The returned class must be instantiated
    (``Plugin = make_test_plugin(...); plugin = Plugin()``).

    ``route_builder`` receives an :class:`fastapi.APIRouter` and may
    attach endpoints.  ``sub_prefix`` becomes the second element of the
    tuple returned by :meth:`get_routers`, matching real-plugin
    conventions: ``(router, sub_prefix)`` -> mounts at
    ``/api{routes_prefix}{sub_prefix}``.

    Lifecycle hooks install the matching
    ``on_before_experiment_save`` / ``on_after_experiment_save`` /
    ``on_experiment_status_change`` overrides.

    ``health_status`` becomes the value reported by
    :meth:`check_health`; ``health_message`` is attached on the
    returned :class:`PluginHealth`.
    """
    _status = HealthStatus(health_status) if isinstance(health_status, str) else health_status
    _caps = capabilities or PluginCapabilities(
        requires_database=True,
        requires_experiments=True,
    )

    class _TestPlugin(AnalysisPlugin):
        @property
        def metadata(self) -> PluginMetadata:
            return PluginMetadata(
                name=name,
                version=version,
                description=f"test plugin {name}",
                analysis_type=analysis_type,
                routes_prefix=routes_prefix,
                plugin_type=plugin_type,
                capabilities=_caps,
            )

        def get_routers(self) -> list[tuple[APIRouter, str]]:
            from fastapi import APIRouter

            router = APIRouter()
            if route_builder is not None:
                route_builder(router)
            return [(router, sub_prefix)]

        async def initialize(self, context=None) -> None:
            self._context = context

        async def shutdown(self) -> None:
            pass

        async def check_health(self) -> PluginHealth:
            return PluginHealth(status=_status, message=health_message)

        async def on_before_experiment_save(
            self, experiment_id: int, data: dict[str, Any]
        ) -> LifecycleHookResult:
            if before_save is None:
                return LifecycleHookResult(success=True)
            return before_save(experiment_id, data)

        async def on_after_experiment_save(
            self, experiment_id: int, data: dict[str, Any]
        ) -> None:
            if after_save is not None:
                after_save(experiment_id, data)

        async def on_experiment_status_change(
            self, experiment_id: int, old_status: str, new_status: str
        ) -> None:
            if status_change is not None:
                status_change(experiment_id, old_status, new_status)

    _TestPlugin.__name__ = f"Test_{name.replace('-', '_')}"
    return _TestPlugin


def build_test_app(
    plugin_or_cls: type[AnalysisPlugin] | AnalysisPlugin,
    *,
    cors: bool = False,
) -> FastAPI:
    """Return a real ``FastAPI`` app backed by :func:`create_standalone_app`.

    Small wrapper that exists so test authors have a single named entry
    point and don't have to remember to pass ``cors=False`` — the
    default in standalone mode is ``True`` which spams logs during
    tests.
    """
    from mld_sdk.app import create_standalone_app

    return create_standalone_app(plugin_or_cls, cors=cors)
