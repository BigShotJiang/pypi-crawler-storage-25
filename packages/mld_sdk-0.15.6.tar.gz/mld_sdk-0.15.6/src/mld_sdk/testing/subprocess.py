"""Helpers for writing standalone plugin scripts that tests can spawn."""

from __future__ import annotations

import textwrap
from pathlib import Path


def write_standalone_plugin_module(
    tmp_path: Path,
    *,
    module_name: str = "dummy_plugin",
    routes_prefix: str = "/dummy",
    exit_immediately: bool = False,
    startup_sleep_seconds: float = 0.0,
) -> tuple[Path, str]:
    """Write a minimal uvicorn-compatible ASGI factory module under ``tmp_path``.

    Returns ``(parent_dir_on_pythonpath, factory_target)`` suitable for
    ``SubprocessManager.start_plugin(factory_target=..., venv_python=...)``
    once the parent dir is on ``PYTHONPATH``.

    The generated module exposes a ``create_standalone_app`` factory
    that builds a :class:`fastapi.FastAPI` app with the following
    endpoints:

    * ``GET /api{routes_prefix}/health`` — returns ``{"status": "ok"}``
    * ``GET /api{routes_prefix}/echo`` — returns the auth / internal-token
      headers the platform proxy is expected to forward, so proxy tests
      can assert end-to-end injection.

    Parameters
    ----------
    tmp_path:
        A writable directory (e.g. pytest's ``tmp_path`` fixture).
    module_name:
        The Python module filename (without ``.py``).  Tests import it
        as ``plugin_pkg.<module_name>``.
    routes_prefix:
        Plugin route prefix, like ``/drp``.  No leading double slashes.
    exit_immediately:
        When True, the generated module raises ``SystemExit`` at import
        time.  Used to verify ``SubprocessManager`` surfaces startup
        failures.
    startup_sleep_seconds:
        Delay in seconds before the FastAPI app is returned.  Useful for
        simulating slow boots.
    """
    pkg_dir = tmp_path / "plugin_pkg"
    pkg_dir.mkdir(exist_ok=True)
    (pkg_dir / "__init__.py").write_text("")

    if exit_immediately:
        body = "raise SystemExit('intentional immediate exit')\n"
    else:
        body = textwrap.dedent(
            f"""
            import time
            from fastapi import FastAPI, Request

            def create_standalone_app():
                if {startup_sleep_seconds!r}:
                    time.sleep({startup_sleep_seconds!r})
                app = FastAPI()

                @app.get("/api{routes_prefix}/health")
                async def _health():
                    return {{"status": "ok"}}

                @app.get("/api{routes_prefix}/echo")
                async def _echo(request: Request):
                    return {{
                        "user_id": request.headers.get("x-mld-user-id"),
                        "username": request.headers.get("x-mld-username"),
                        "user_role": request.headers.get("x-mld-user-role"),
                        "internal_token": request.headers.get(
                            "x-mld-internal-token"
                        ),
                        "authorization": request.headers.get("authorization"),
                    }}

                return app
            """
        )

    (pkg_dir / f"{module_name}.py").write_text(body)
    factory_target = f"plugin_pkg.{module_name}:create_standalone_app"
    return pkg_dir.parent, factory_target
