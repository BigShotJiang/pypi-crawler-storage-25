"""Tests for the ``mld_sdk.testing`` helpers.

Plugin authors rely on these helpers to test their plugins against a
mocked platform.  If the helpers silently break, every downstream
plugin test suite drifts with them, so the SDK exercises them here.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from mld_sdk.models import PluginType
from mld_sdk.plugin import HealthStatus, LifecycleHookResult
from mld_sdk.testing import (
    RecordingContext,
    build_test_app,
    make_test_plugin,
    write_standalone_plugin_module,
)


# ---------------------------------------------------------------------------
# make_test_plugin
# ---------------------------------------------------------------------------


class TestMakeTestPlugin:
    def test_default_metadata(self):
        Plugin = make_test_plugin()
        plugin = Plugin()
        meta = plugin.metadata
        assert meta.name == "test-plugin"
        assert meta.routes_prefix == "/test-plugin"
        assert meta.plugin_type == PluginType.ANALYSIS

    def test_routes_builder_attaches_endpoints(self):
        def _build(router):
            @router.get("/ping")
            async def ping():
                return {"pong": True}

        Plugin = make_test_plugin(
            name="pong", routes_prefix="/pong", route_builder=_build
        )
        plugin = Plugin()
        routers = plugin.get_routers()
        assert len(routers) == 1
        router, sub_prefix = routers[0]
        assert sub_prefix == ""
        # Router should expose one GET /ping endpoint
        paths = [r.path for r in router.routes]
        assert "/ping" in paths

    @pytest.mark.asyncio
    async def test_health_status_override(self):
        Plugin = make_test_plugin(
            health_status="degraded", health_message="slow disk"
        )
        plugin = Plugin()
        health = await plugin.check_health()
        assert health.status == HealthStatus.DEGRADED
        assert health.message == "slow disk"

    @pytest.mark.asyncio
    async def test_before_save_hook_receives_payload(self):
        received: list = []

        def _before(eid, data):
            received.append((eid, data))
            return LifecycleHookResult(success=True)

        Plugin = make_test_plugin(before_save=_before)
        plugin = Plugin()
        result = await plugin.on_before_experiment_save(99, {"x": 1})
        assert result.success is True
        assert received == [(99, {"x": 1})]

    @pytest.mark.asyncio
    async def test_after_save_and_status_hooks_fire(self):
        after_received: list = []
        status_received: list = []

        Plugin = make_test_plugin(
            after_save=lambda eid, data: after_received.append((eid, data)),
            status_change=lambda eid, old, new: status_received.append(
                (eid, old, new)
            ),
        )
        plugin = Plugin()
        await plugin.on_after_experiment_save(1, {"a": 2})
        await plugin.on_experiment_status_change(1, "planned", "ongoing")
        assert after_received == [(1, {"a": 2})]
        assert status_received == [(1, "planned", "ongoing")]


# ---------------------------------------------------------------------------
# build_test_app
# ---------------------------------------------------------------------------


class TestBuildTestApp:
    def test_mounts_routes_at_api_prefix(self):
        def _build(router):
            @router.get("/hello")
            async def hello():
                return {"ok": True}

        Plugin = make_test_plugin(
            name="greeter",
            routes_prefix="/greeter",
            route_builder=_build,
            sub_prefix="",
        )
        app = build_test_app(Plugin)
        with TestClient(app) as client:
            resp = client.get("/api/greeter/hello")
            assert resp.status_code == 200
            assert resp.json() == {"ok": True}

    def test_sub_prefix_nests_correctly(self):
        def _build(router):
            @router.get("/units")
            async def units():
                return []

        Plugin = make_test_plugin(
            name="labs",
            routes_prefix="/labs",
            sub_prefix="/inventory",
            route_builder=_build,
        )
        app = build_test_app(Plugin)
        with TestClient(app) as client:
            resp = client.get("/api/labs/inventory/units")
            assert resp.status_code == 200


# ---------------------------------------------------------------------------
# write_standalone_plugin_module
# ---------------------------------------------------------------------------


class TestWriteStandalonePluginModule:
    def test_generates_importable_factory(self, tmp_path):
        pkg_parent, factory = write_standalone_plugin_module(
            tmp_path, routes_prefix="/xyz"
        )
        assert factory == "plugin_pkg.dummy_plugin:create_standalone_app"

        import sys

        sys.path.insert(0, str(pkg_parent))
        try:
            mod = __import__(
                "plugin_pkg.dummy_plugin", fromlist=["create_standalone_app"]
            )
            app = mod.create_standalone_app()
            with TestClient(app) as client:
                resp = client.get("/api/xyz/health")
                assert resp.status_code == 200
                assert resp.json() == {"status": "ok"}
        finally:
            sys.path.remove(str(pkg_parent))
            sys.modules.pop("plugin_pkg.dummy_plugin", None)
            sys.modules.pop("plugin_pkg", None)

    def test_echo_endpoint_reflects_headers(self, tmp_path):
        pkg_parent, _ = write_standalone_plugin_module(
            tmp_path, routes_prefix="/xyz"
        )
        import sys

        sys.path.insert(0, str(pkg_parent))
        try:
            mod = __import__(
                "plugin_pkg.dummy_plugin", fromlist=["create_standalone_app"]
            )
            app = mod.create_standalone_app()
            with TestClient(app) as client:
                resp = client.get(
                    "/api/xyz/echo",
                    headers={
                        "X-MLD-User-Id": "5",
                        "X-MLD-Username": "alice",
                        "X-MLD-User-Role": "admin",
                        "X-MLD-Internal-Token": "deadbeef",
                    },
                )
                assert resp.status_code == 200
                data = resp.json()
                assert data["user_id"] == "5"
                assert data["username"] == "alice"
                assert data["user_role"] == "admin"
                assert data["internal_token"] == "deadbeef"
        finally:
            sys.path.remove(str(pkg_parent))
            sys.modules.pop("plugin_pkg.dummy_plugin", None)
            sys.modules.pop("plugin_pkg", None)

    def test_exit_immediately_raises_at_import(self, tmp_path):
        pkg_parent, _ = write_standalone_plugin_module(
            tmp_path, exit_immediately=True
        )
        import sys

        sys.path.insert(0, str(pkg_parent))
        try:
            with pytest.raises(SystemExit):
                __import__(
                    "plugin_pkg.dummy_plugin",
                    fromlist=["create_standalone_app"],
                )
        finally:
            sys.path.remove(str(pkg_parent))
            sys.modules.pop("plugin_pkg.dummy_plugin", None)
            sys.modules.pop("plugin_pkg", None)


# ---------------------------------------------------------------------------
# RecordingContext
# ---------------------------------------------------------------------------


class TestRecordingContext:
    @pytest.mark.asyncio
    async def test_design_data_roundtrip(self):
        Plugin = make_test_plugin(name="design")
        plugin = Plugin()
        ctx = RecordingContext()
        await plugin.initialize(ctx)

        saved = await plugin.save_design(
            experiment_id=42,
            data={"threshold": 0.5, "items": [1, 2, 3]},
        )
        assert saved is not None
        assert saved.experiment_id == 42
        assert saved.data["threshold"] == 0.5

        loaded = await plugin.load_design(42)
        assert loaded is not None
        assert loaded.data == {"threshold": 0.5, "items": [1, 2, 3]}

    @pytest.mark.asyncio
    async def test_analysis_results_are_per_plugin_and_listed(self):
        Plugin = make_test_plugin(name="analysis-a")
        OtherPlugin = make_test_plugin(name="analysis-b")
        a = Plugin()
        b = OtherPlugin()
        ctx = RecordingContext()
        await a.initialize(ctx)
        await b.initialize(ctx)

        await a.save_analysis(7, {"score": 1.0})
        await b.save_analysis(7, {"score": 2.0})

        loaded_a = await a.load_analysis(7)
        loaded_b = await b.load_analysis(7)
        assert loaded_a.result == {"score": 1.0}
        assert loaded_b.result == {"score": 2.0}

        all_for_exp = await ctx.get_plugin_data_repository().get_analysis_results(7)
        assert {r.plugin_id for r in all_for_exp} == {"analysis-a", "analysis-b"}

    @pytest.mark.asyncio
    async def test_delete_design_and_analysis(self):
        Plugin = make_test_plugin(name="delete-test")
        plugin = Plugin()
        await plugin.initialize(RecordingContext())

        await plugin.save_design(1, {"x": 1})
        await plugin.save_analysis(1, {"y": 2})

        assert await plugin.delete_design(1) is True
        assert await plugin.load_design(1) is None
        assert await plugin.delete_analysis(1) is True
        assert await plugin.load_analysis(1) is None

    def test_current_user_getter_and_setter(self):
        ctx = RecordingContext(user={"username": "alice"})
        assert ctx.is_authenticated
        assert ctx.get_current_user() == {"username": "alice"}

        ctx.set_current_user(None)
        assert ctx.is_authenticated is False
