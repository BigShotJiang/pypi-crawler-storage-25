"""测试 fixtures。"""
