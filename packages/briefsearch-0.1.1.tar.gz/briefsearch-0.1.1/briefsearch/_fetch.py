from __future__ import annotations

import asyncio
import logging

import httpx
import trafilatura

from ._models import SearchResult

logger = logging.getLogger(__name__)

_DEFAULT_FETCH_TIMEOUT = 5.0


async def fetch_content(
    result: SearchResult,
    *,
    client: httpx.AsyncClient | None = None,
    timeout: float = _DEFAULT_FETCH_TIMEOUT,
) -> None:
    """Fetch full article text for a SearchResult in-place. Never raises.

    If `client` is provided it is used directly (caller owns its lifecycle).
    Otherwise a short-lived client is created with the given `timeout`.
    """
    try:
        if client is not None:
            response = await client.get(result.url)
        else:
            async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as c:
                response = await c.get(result.url)

        response.raise_for_status()
        html = response.text

        extracted = await asyncio.to_thread(
            trafilatura.extract,
            html,
            include_comments=False,
            include_tables=False,
        )
        if extracted:
            result.content = extracted
            result.fetch_error = None
        else:
            result.content = None
            result.fetch_error = "trafilatura returned no content"
    except Exception as exc:
        logger.warning("Failed to fetch %s: %s", result.url, exc)
        result.content = None
        result.fetch_error = str(exc)


async def fetch_contents(
    results: list[SearchResult],
    top_n: int,
    timeout: float = _DEFAULT_FETCH_TIMEOUT,
) -> None:
    """Fetch content for the first `top_n` results in parallel, sharing one client."""
    targets = results[:top_n]
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        await asyncio.gather(*(fetch_content(r, client=client) for r in targets))
