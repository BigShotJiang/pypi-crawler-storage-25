from __future__ import annotations

import asyncio
import logging

from duckduckgo_search import DDGS

from ._fetch import fetch_contents
from ._models import SearchResult

logger = logging.getLogger(__name__)


async def search(
    query: str,
    *,
    max_results: int = 5,
    fetch_content: bool = False,
    fetch_top_n: int = 1,
    fetch_timeout: float = 5.0,
) -> list[SearchResult]:
    """Search DuckDuckGo and optionally fetch full article text.

    Returns an empty list (never raises) if DDG fails or returns nothing.
    """
    try:
        raw: list[dict] = await asyncio.to_thread(_ddg_search, query, max_results)
    except Exception as exc:
        logger.warning("DDG search failed for %r: %s", query, exc)
        return []

    if not raw:
        logger.info("DDG returned no results for %r", query)
        return []

    results = [
        SearchResult(
            title=r.get("title") or "",
            url=r.get("href") or "",
            snippet=r.get("body") or "",
        )
        for r in raw
    ]

    if fetch_content and fetch_top_n > 0:
        await fetch_contents(results, top_n=fetch_top_n, timeout=fetch_timeout)

    return results


def _ddg_search(query: str, max_results: int) -> list[dict]:
    with DDGS() as ddgs:
        return list(ddgs.text(query, max_results=max_results))


async def search_many(
    queries: list[str],
    *,
    max_results: int = 5,
    fetch_content: bool = False,
    fetch_top_n: int = 1,
    fetch_timeout: float = 5.0,
    timeout: float = 10.0,
) -> dict[str, list[SearchResult]]:
    """Run multiple queries in parallel, each bounded by `timeout` seconds."""

    async def _bounded(query: str) -> tuple[str, list[SearchResult]]:
        try:
            results = await asyncio.wait_for(
                search(
                    query,
                    max_results=max_results,
                    fetch_content=fetch_content,
                    fetch_top_n=fetch_top_n,
                    fetch_timeout=fetch_timeout,
                ),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("Query timed out after %.1fs: %r", timeout, query)
            results = []
        return query, results

    pairs = await asyncio.gather(*(_bounded(q) for q in queries))
    return dict(pairs)
