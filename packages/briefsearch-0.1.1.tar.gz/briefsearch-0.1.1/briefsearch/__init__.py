"""briefsearch - Async DDG search with LLM-ready output."""

from ._markdown import results_to_markdown
from ._models import SearchResult
from ._search import search, search_many

__all__ = ["search", "search_many", "SearchResult", "results_to_markdown"]
