from __future__ import annotations

from ._models import SearchResult


def results_to_markdown(query: str, results: list[SearchResult]) -> str:
    lines: list[str] = [f"**Query:** {query}"]
    for r in results:
        line = f"- [{r.title}]({r.url}): {r.snippet}"
        lines.append(line)
        if r.content:
            preview = r.content[:300]
            lines.append(f"  {preview}")
    return "\n".join(lines)
