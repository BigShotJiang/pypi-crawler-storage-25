"""Tests for _markdown.py — results_to_markdown."""
from __future__ import annotations

import pytest

from briefsearch import SearchResult, results_to_markdown


def _make_result(
    title: str = "Title",
    url: str = "https://example.com",
    snippet: str = "A snippet.",
    content: str | None = None,
) -> SearchResult:
    return SearchResult(title=title, url=url, snippet=snippet, content=content)


def test_markdown_starts_with_query():
    results = [_make_result()]
    md = results_to_markdown("my query", results)
    assert md.startswith("**Query:** my query")


def test_markdown_contains_title_url_snippet():
    r = _make_result(title="Tauri v2", url="https://tauri.app", snippet="Great release.")
    md = results_to_markdown("tauri", [r])
    assert "[Tauri v2](https://tauri.app)" in md
    assert "Great release." in md


def test_markdown_no_content_preview_when_none():
    r = _make_result(content=None)
    md = results_to_markdown("q", [r])
    # Should not have an indented preview line beyond the bullet
    lines = md.splitlines()
    bullet_lines = [l for l in lines if l.startswith("- ")]
    assert len(bullet_lines) == 1
    # No extra content line
    assert len(lines) == 2  # header + 1 bullet


def test_markdown_content_preview_first_300_chars():
    long_content = "x" * 500
    r = _make_result(content=long_content)
    md = results_to_markdown("q", [r])
    assert "x" * 300 in md
    assert "x" * 301 not in md


def test_markdown_content_preview_indented():
    r = _make_result(content="Short content.")
    md = results_to_markdown("q", [r])
    lines = md.splitlines()
    content_line = lines[-1]
    assert content_line.startswith("  ")


def test_markdown_multiple_results():
    results = [
        _make_result(title="A", url="https://a.com", snippet="Snippet A."),
        _make_result(title="B", url="https://b.com", snippet="Snippet B."),
        _make_result(title="C", url="https://c.com", snippet="Snippet C."),
    ]
    md = results_to_markdown("multi", results)
    assert "[A](https://a.com)" in md
    assert "[B](https://b.com)" in md
    assert "[C](https://c.com)" in md


def test_markdown_empty_results():
    md = results_to_markdown("empty", [])
    assert md == "**Query:** empty"


def test_markdown_content_short_not_truncated():
    r = _make_result(content="Short.")
    md = results_to_markdown("q", [r])
    assert "Short." in md


def test_markdown_mixed_content_and_no_content():
    results = [
        _make_result(title="With", url="https://a.com", snippet="s", content="Full text here."),
        _make_result(title="Without", url="https://b.com", snippet="s2", content=None),
    ]
    md = results_to_markdown("q", results)
    assert "Full text here." in md
    lines = md.splitlines()
    # header + bullet1 + content_preview + bullet2 = 4 lines
    assert len(lines) == 4
