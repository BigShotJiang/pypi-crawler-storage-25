"""Tests for _search.py — DDG wrapper."""
from __future__ import annotations

from unittest.mock import AsyncMock, patch

from briefsearch import SearchResult, search, search_many


_FAKE_DDG_RESULTS = [
    {"title": "Tauri v2", "href": "https://tauri.app/blog/tauri-2", "body": "Tauri 2.0 released."},
    {"title": "Tauri GitHub", "href": "https://github.com/tauri-apps/tauri", "body": "Build smaller apps."},
]


def _make_ddgs_patch(return_value=_FAKE_DDG_RESULTS):
    """Patch _ddg_search (the sync helper) via asyncio.to_thread."""
    return patch(
        "briefsearch._search._ddg_search",
        return_value=return_value,
    )


async def test_search_returns_search_results():
    with _make_ddgs_patch():
        results = await search("Tauri framework news", max_results=2)

    assert len(results) == 2
    assert all(isinstance(r, SearchResult) for r in results)


async def test_search_result_fields():
    with _make_ddgs_patch():
        results = await search("Tauri framework news", max_results=2)

    first = results[0]
    assert first.title == "Tauri v2"
    assert first.url == "https://tauri.app/blog/tauri-2"
    assert first.snippet == "Tauri 2.0 released."
    assert first.content is None
    assert first.fetch_error is None


async def test_search_empty_ddg_returns_empty_list():
    with _make_ddgs_patch(return_value=[]):
        results = await search("nothing here")

    assert results == []


async def test_search_ddg_exception_returns_empty_list():
    with patch("briefsearch._search._ddg_search", side_effect=Exception("network error")):
        results = await search("bad query")

    assert results == []


async def test_search_no_fetch_content_by_default():
    with _make_ddgs_patch():
        results = await search("Tauri framework news", max_results=2)

    assert all(r.content is None for r in results)


async def test_search_fetch_content_calls_fetch():
    with _make_ddgs_patch():
        with patch("briefsearch._search.fetch_contents", new_callable=AsyncMock) as mock_fetch:
            results = await search(
                "Tauri framework news",
                max_results=2,
                fetch_content=True,
                fetch_top_n=1,
            )

    mock_fetch.assert_awaited_once()
    call_kwargs = mock_fetch.call_args
    assert call_kwargs.kwargs["top_n"] == 1


async def test_search_fetch_content_false_skips_fetch():
    with _make_ddgs_patch():
        with patch("briefsearch._search.fetch_contents", new_callable=AsyncMock) as mock_fetch:
            await search("Tauri framework news", max_results=2, fetch_content=False)

    mock_fetch.assert_not_awaited()


async def test_search_many_returns_dict():
    with _make_ddgs_patch():
        result = await search_many(["query one", "query two"], max_results=2)

    assert isinstance(result, dict)
    assert set(result.keys()) == {"query one", "query two"}
    assert all(isinstance(v, list) for v in result.values())


async def test_search_many_parallel_results():
    with _make_ddgs_patch():
        result = await search_many(["query one", "query two"], max_results=2)

    assert len(result["query one"]) == 2
    assert len(result["query two"]) == 2


async def test_search_many_timeout_returns_empty_for_timed_out_query():
    import asyncio

    async def _slow_search(*args, **kwargs):
        await asyncio.sleep(10)
        return []

    with patch("briefsearch._search.search", side_effect=_slow_search):
        result = await search_many(["slow query"], max_results=2, timeout=0.05)

    assert result["slow query"] == []
