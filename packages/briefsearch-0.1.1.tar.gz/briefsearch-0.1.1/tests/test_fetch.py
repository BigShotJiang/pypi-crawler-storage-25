"""Tests for _fetch.py — httpx + trafilatura fetch."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import respx
import httpx

from briefsearch import SearchResult
from briefsearch._fetch import fetch_content, fetch_contents


_HTML = "<html><body><article>Hello world article text.</article></body></html>"
_EXTRACTED = "Hello world article text."


async def test_fetch_content_sets_content_on_success():
    result = SearchResult(title="T", url="https://example.com/article", snippet="s")

    with respx.mock:
        respx.get("https://example.com/article").mock(
            return_value=httpx.Response(200, text=_HTML)
        )
        with patch("trafilatura.extract", return_value=_EXTRACTED):
            await fetch_content(result)

    assert result.content == _EXTRACTED
    assert result.fetch_error is None


async def test_fetch_content_sets_fetch_error_on_http_error():
    result = SearchResult(title="T", url="https://example.com/404", snippet="s")

    with respx.mock:
        respx.get("https://example.com/404").mock(
            return_value=httpx.Response(404)
        )
        await fetch_content(result)

    assert result.content is None
    assert result.fetch_error is not None


async def test_fetch_content_sets_fetch_error_on_network_error():
    result = SearchResult(title="T", url="https://example.com/err", snippet="s")

    with respx.mock:
        respx.get("https://example.com/err").mock(side_effect=httpx.ConnectError("refused"))
        await fetch_content(result)

    assert result.content is None
    assert "refused" in result.fetch_error


async def test_fetch_content_trafilatura_returns_none():
    result = SearchResult(title="T", url="https://example.com/empty", snippet="s")

    with respx.mock:
        respx.get("https://example.com/empty").mock(
            return_value=httpx.Response(200, text="<html></html>")
        )
        with patch("trafilatura.extract", return_value=None):
            await fetch_content(result)

    assert result.content is None
    assert result.fetch_error == "trafilatura returned no content"


async def test_fetch_content_never_raises():
    result = SearchResult(title="T", url="https://example.com/crash", snippet="s")

    with respx.mock:
        respx.get("https://example.com/crash").mock(side_effect=RuntimeError("boom"))
        # Should not raise
        await fetch_content(result)

    assert result.fetch_error is not None


async def test_fetch_content_calls_trafilatura_with_correct_kwargs():
    result = SearchResult(title="T", url="https://example.com/a", snippet="s")

    with respx.mock:
        respx.get("https://example.com/a").mock(
            return_value=httpx.Response(200, text=_HTML)
        )
        with patch("trafilatura.extract", return_value="text") as mock_extract:
            await fetch_content(result)

    mock_extract.assert_called_once_with(
        _HTML,
        include_comments=False,
        include_tables=False,
    )


async def test_fetch_contents_only_fetches_top_n():
    results = [
        SearchResult(title="A", url="https://a.com", snippet="a"),
        SearchResult(title="B", url="https://b.com", snippet="b"),
        SearchResult(title="C", url="https://c.com", snippet="c"),
    ]

    fetch_calls: list[str] = []

    async def _mock_fetch(r: SearchResult, *, client=None, timeout: float = 5.0) -> None:
        fetch_calls.append(r.url)
        r.content = "text"

    with patch("briefsearch._fetch.fetch_content", side_effect=_mock_fetch):
        await fetch_contents(results, top_n=2)

    assert fetch_calls == ["https://a.com", "https://b.com"]
    assert results[2].content is None


async def test_fetch_content_respects_timeout():
    """Timeout parameter is forwarded to httpx.AsyncClient constructor."""
    result = SearchResult(title="T", url="https://example.com/slow", snippet="s")

    mock_client = AsyncMock()
    mock_client.get.side_effect = httpx.TimeoutException("slow")

    mock_async_client = MagicMock()
    mock_async_client.return_value.__aenter__ = AsyncMock(return_value=mock_client)
    mock_async_client.return_value.__aexit__ = AsyncMock(return_value=None)

    with patch("httpx.AsyncClient", mock_async_client):
        await fetch_content(result, timeout=3.0)

    mock_async_client.assert_called_once_with(timeout=3.0, follow_redirects=True)
    assert result.fetch_error is not None
