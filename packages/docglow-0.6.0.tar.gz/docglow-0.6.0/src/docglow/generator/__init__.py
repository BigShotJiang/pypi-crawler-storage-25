"""Static site generator."""
