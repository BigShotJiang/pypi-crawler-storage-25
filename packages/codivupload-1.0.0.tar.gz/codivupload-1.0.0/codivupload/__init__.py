"""CodivUpload Python SDK — Publish to 9 social media platforms."""

from .client import CodivUpload
from .errors import CodivUploadError

__version__ = "1.0.0"
__all__ = ["CodivUpload", "CodivUploadError"]
