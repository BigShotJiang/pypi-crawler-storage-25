"""CodivUpload Python SDK client."""

from __future__ import annotations

from typing import Any

import httpx

from .errors import CodivUploadError


class _Resource:
    """Base class for API resources."""

    def __init__(self, client: httpx.Client):
        self._client = client

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        resp = self._client.request(method, path, **kwargs)
        data = resp.json()
        if not resp.is_success:
            raise CodivUploadError(
                message=data.get("error", f"HTTP {resp.status_code}"),
                status=resp.status_code,
                code=data.get("code"),
            )
        return data


class Posts(_Resource):
    """Manage social media posts."""

    def create(self, **params: Any) -> dict:
        """Create and publish a post to 1-9 platforms.

        Args:
            platforms: List of platform slugs (tiktok, instagram, youtube, etc.)
            description: Post caption / body text
            profile_name: Target profile username
            media_urls: CDN URLs for media files
            scheduled_date: UTC ISO 8601 datetime for scheduled delivery
            post_type: Content type (post, reel, story, short)
            title: Post title (YouTube video title, Pinterest pin title)
            first_comment: Auto-comment after publishing (Instagram, YouTube)
            **kwargs: Platform-specific overrides (tiktok_privacy_level, youtube_type, etc.)
        """
        return self._request("POST", "/posts", json=params)

    def schedule(self, **params: Any) -> dict:
        """Schedule a post for future delivery. Same as create() with scheduled_date."""
        if "scheduled_date" not in params:
            raise ValueError("scheduled_date is required for schedule()")
        return self.create(**params)

    def list(self, **params: Any) -> dict:
        """List posts with optional filters.

        Args:
            status: Filter by status (draft, scheduled, publishing, completed, failed)
            profile_name: Filter by profile
            limit: Results per page (max 100, default 20)
            offset: Pagination offset
        """
        return self._request("GET", "/posts", params=params)

    def get(self, post_id: str) -> dict:
        """Get a single post by ID."""
        return self._request("GET", f"/posts/{post_id}")

    def update(self, post_id: str, **params: Any) -> dict:
        """Update a post."""
        return self._request("PUT", f"/posts/{post_id}", json=params)

    def delete(self, post_id: str) -> dict:
        """Delete a post."""
        return self._request("DELETE", f"/posts/{post_id}")


class Profiles(_Resource):
    """Manage social media profiles."""

    def list(self) -> dict:
        """List all profiles in your workspace."""
        return self._request("GET", "/agency/profiles")

    def create(self, username: str, profile_name: str | None = None) -> dict:
        """Create a new profile.

        Args:
            username: Unique username for the profile (min 3 chars)
            profile_name: Display name
        """
        body: dict[str, Any] = {"username": username}
        if profile_name:
            body["profile_name"] = profile_name
        return self._request("POST", "/agency/profiles", json=body)

    def delete(self, profile_id: str) -> dict:
        """Delete a profile by ID."""
        return self._request("DELETE", f"/agency/profiles/{profile_id}")


class Media(_Resource):
    """Manage media assets."""

    def upload(self, file_url: str, profile_name: str | None = None) -> dict:
        """Upload a media file to CDN.

        Args:
            file_url: Public URL of the file to upload
            profile_name: Associate media with a profile
        """
        body: dict[str, Any] = {"media_url": file_url}
        if profile_name:
            body["profile_name"] = profile_name
        return self._request("POST", "/upload-media", json=body)

    def list(self) -> dict:
        """List uploaded media assets."""
        return self._request("GET", "/agency/media")

    def get(self, media_id: str) -> dict:
        """Get a specific media asset."""
        return self._request("GET", f"/agency/media/{media_id}")

    def delete(self, media_id: str) -> dict:
        """Delete a media asset."""
        return self._request("DELETE", f"/agency/media/{media_id}")


class Broadcasts(_Resource):
    """Manage YouTube live stream broadcasts."""

    def list(self) -> dict:
        """List broadcasts."""
        return self._request("GET", "/integrations/youtube/broadcasts")

    def create(self, **params: Any) -> dict:
        """Start a new 24/7 YouTube live stream.

        Args:
            profile_name: Profile with YouTube connected
            title: Stream title
            media_url: Video file URL to loop
            description: Stream description
            privacy_status: public, unlisted, or private
            start_time: Scheduled start (ISO 8601). Omit for immediate.
            playlist_id: CodivUpload playlist UUID to loop
            is_loop: Loop indefinitely (default True)
        """
        return self._request("POST", "/integrations/youtube/broadcasts", json=params)

    def stop(self, broadcast_id: str) -> dict:
        """Stop a running broadcast."""
        return self._request("POST", f"/integrations/youtube/broadcasts/{broadcast_id}/stop")


class Playlists(_Resource):
    """Manage playlists."""

    def list(self) -> dict:
        """List playlists."""
        return self._request("GET", "/agency/playlists")

    def get(self, playlist_id: str) -> dict:
        """Get a specific playlist."""
        return self._request("GET", f"/agency/playlists/{playlist_id}")

    def create(self, **params: Any) -> dict:
        """Create a playlist."""
        return self._request("POST", "/agency/playlists", json=params)


class CodivUpload:
    """CodivUpload API client.

    Usage::

        from codivupload import CodivUpload

        codiv = CodivUpload("cdv_your_api_key")

        # Publish
        post = codiv.posts.create(
            platforms=["tiktok", "instagram"],
            description="Hello world!",
            media_urls=["https://cdn.example.com/video.mp4"],
            profile_name="my_brand",
        )

        # Schedule
        codiv.posts.schedule(
            platforms=["youtube"],
            description="Tomorrow's video",
            scheduled_date="2026-04-05T14:00:00Z",
            profile_name="my_brand",
        )

        # List
        posts = codiv.posts.list(status="completed", limit=20)

        # Profiles
        profiles = codiv.profiles.list()
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.codivupload.com/v1",
        timeout: float = 30.0,
    ):
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self.posts = Posts(self._client)
        self.profiles = Profiles(self._client)
        self.media = Media(self._client)
        self.broadcasts = Broadcasts(self._client)
        self.playlists = Playlists(self._client)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "CodivUpload":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
