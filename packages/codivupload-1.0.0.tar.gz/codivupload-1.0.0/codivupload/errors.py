"""CodivUpload error classes."""


class CodivUploadError(Exception):
    """Base error for CodivUpload API responses."""

    def __init__(self, message: str, status: int | None = None, code: str | None = None):
        super().__init__(message)
        self.status = status
        self.code = code

    def __repr__(self) -> str:
        return f"CodivUploadError(message={self.args[0]!r}, status={self.status}, code={self.code})"
