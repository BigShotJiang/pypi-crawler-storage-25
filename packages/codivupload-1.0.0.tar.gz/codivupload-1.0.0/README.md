# codivupload

Official Python SDK for [CodivUpload](https://codivupload.com) — publish, schedule, and manage social media posts across 9 platforms.

## Install

```bash
pip install codivupload
```

## Quick Start

```python
from codivupload import CodivUpload

codiv = CodivUpload("cdv_your_api_key")

# Publish to TikTok and Instagram
post = codiv.posts.create(
    platforms=["tiktok", "instagram"],
    description="New product launch! 🚀",
    media_urls=["https://cdn.example.com/video.mp4"],
    profile_name="my_brand",
)

print(post["id"])      # "post_k8m2v9x1"
print(post["status"])  # "publishing"
```

## Posts

```python
# Create / publish immediately
post = codiv.posts.create(
    platforms=["tiktok", "instagram", "youtube"],
    description="Check this out!",
    media_urls=["https://cdn.example.com/video.mp4"],
    profile_name="my_brand",
)

# Schedule for later
scheduled = codiv.posts.schedule(
    platforms=["youtube", "linkedin"],
    description="Big announcement!",
    scheduled_date="2026-04-05T14:00:00Z",
    profile_name="my_brand",
)

# List posts
posts = codiv.posts.list(status="completed", limit=20)

# Get single post
post = codiv.posts.get("post_k8m2v9x1")

# Update
codiv.posts.update("post_k8m2v9x1", description="Updated caption")

# Delete
codiv.posts.delete("post_k8m2v9x1")
```

## Profiles

```python
# List all profiles
result = codiv.profiles.list()
for p in result["profiles"]:
    print(f"{p['profile_name']} (@{p['username']})")

# Create a new profile
profile = codiv.profiles.create("new_client", profile_name="New Client Inc.")

# Delete
codiv.profiles.delete("profile-uuid")
```

## Media

```python
# Upload to CDN
media = codiv.media.upload("https://example.com/video.mp4", profile_name="my_brand")
print(media["url"])  # CDN URL

# Use in a post
codiv.posts.create(
    platforms=["tiktok"],
    description="Uploaded via Python SDK!",
    media_urls=[media["url"]],
    profile_name="my_brand",
)

# List / get / delete
assets = codiv.media.list()
asset = codiv.media.get("media-uuid")
codiv.media.delete("media-uuid")
```

## Live Streaming (YouTube 24/7)

```python
# Start immediately
stream = codiv.broadcasts.create(
    profile_name="my_channel",
    title="Lo-fi Coding Radio 24/7 🎵",
    media_url="https://cdn.example.com/lofi-mix.mp4",
    is_loop=True,
)

# Schedule for later
codiv.broadcasts.create(
    profile_name="my_channel",
    title="Friday Jazz",
    media_url="https://cdn.example.com/jazz.mp4",
    start_time="2026-04-04T22:00:00Z",
    is_loop=True,
)

# List / stop
broadcasts = codiv.broadcasts.list()
codiv.broadcasts.stop("broadcast-uuid")
```

## Platform-Specific Overrides

```python
codiv.posts.create(
    platforms=["tiktok", "instagram", "youtube", "linkedin", "x"],
    description="Product launch!",
    media_urls=["https://cdn.example.com/launch.mp4"],
    profile_name="my_brand",
    # TikTok
    tiktok_privacy_level="public",
    tiktok_disable_duet=False,
    tiktok_brand_content_toggle=True,
    # Instagram
    instagram_media_type="REELS",
    instagram_location_id="123456789",
    instagram_alt_text="Product demo video",
    # YouTube
    youtube_type="video",
    youtube_privacy_status="public",
    youtube_category_id="28",
    youtube_tags=["product", "launch", "2026"],
    # LinkedIn
    linkedin_visibility="PUBLIC",
    # X
    x_reply_settings="following",
)
```

## Error Handling

```python
from codivupload import CodivUpload, CodivUploadError

codiv = CodivUpload("cdv_your_api_key")

try:
    codiv.posts.create(platforms=["tiktok"], description="Hello!")
except CodivUploadError as e:
    print(e)           # "Rate limit exceeded"
    print(e.status)    # 429
    print(e.code)      # "RATE_LIMITED"
```

## Context Manager

```python
with CodivUpload("cdv_your_api_key") as codiv:
    codiv.posts.create(platforms=["instagram"], description="Hello!")
# Connection automatically closed
```

## Configuration

```python
# Default (production)
codiv = CodivUpload("cdv_...")

# Custom base URL (local dev)
codiv = CodivUpload("cdv_...", base_url="http://localhost:3000/api/v1")

# Custom timeout
codiv = CodivUpload("cdv_...", timeout=60.0)
```

## Supported Platforms

TikTok, Instagram, YouTube, Facebook, LinkedIn, X (Twitter), Threads, Pinterest, Bluesky

## Links

- [CodivUpload](https://codivupload.com)
- [API Documentation](https://docs.codivupload.com)
- [API Reference](https://api.codivupload.com)
- [TypeScript SDK](https://www.npmjs.com/package/codivupload)
- [MCP Server](https://www.npmjs.com/package/codivupload-mcp)
- [GitHub](https://github.com/Codivion/codivupload-python)

## License

MIT — Codivion LLC
