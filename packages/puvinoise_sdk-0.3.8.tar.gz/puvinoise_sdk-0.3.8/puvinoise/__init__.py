"""
Puvinoise - Independent OpenTelemetry SDK for AI agents
Supports Anthropic Claude, OpenAI, Ollama, and other LLM providers.
"""

__version__ = "0.3.8"

from puvinoise.bootstrap import (
    bootstrap,
    build_resource,
    build_resource_attributes,
    init,
    shutdown,
    force_flush,
    is_initialized,
    start_agent_control_worker,
    get_control_worker,
    start_agent_config_poller,
    get_agent_config_poller,
    ensure_control_worker_started,
    control_worker_auto_started,
)
from puvinoise.control_loop import (
    start_control_loop,
    stop_control_loop,
    control_loop_started,
    sdk_control_loop_enabled,
    get_control_lifecycle_state,
    is_agent_paused,
    get_runtime_config_snapshot,
    wait_if_control_paused,
    check_allowed_to_run,
    ControlLifecycleState,
)
from puvinoise.runtime_metadata import get_runtime_metadata, collect_runtime_metadata, ensure_runtime_metadata_env
from puvinoise.sdk_mode import sdk_telemetry_only
from puvinoise.tracer import run_with_trace, start_trace, record_context
from puvinoise.trace_context import TraceContext
from puvinoise.observe import observe_agent
from puvinoise.agent_lifecycle import (
    agent_start,
    agent_step,
    tool_call,
    tool_result,
    reasoning_complete,
    task_complete,
)
from puvinoise.agent_wrapper import wrapAgent
from puvinoise.agent_decorator import agent
from puvinoise.client import PuviClient, ScenarioTraceHandle
from puvinoise.sidecar_manager import (
    start_sidecar,
    stop_sidecar,
    sidecar_status,
    SidecarManager,
    SidecarProcess,
    SidecarError,
    SidecarNotFound,
    SidecarStartupError,
    SidecarUnsupportedPlatform,
    detect_os as detect_sidecar_os,
    detect_arch as detect_sidecar_arch,
    resolve_binary as resolve_sidecar_binary,
)
from puvinoise.telemetry_buffer import (
    ReliableTelemetryBuffer,
    get_decision_buffer,
    set_decision_buffer,
    init_decision_buffer_from_env,
)
from puvinoise.routing import init_routing, get_version as get_routed_version
from puvinoise.config_loader import load_platform_config, get_loaded_config
from puvinoise.hooks import (
    # Anthropic
    instrument_anthropic_call,
    instrument_anthropic_stream,
    # OpenAI
    instrument_openai_call,
    instrument_openai_stream,
    # Generic / Ollama
    instrument_llm_call,
    # Agent internals
    instrument_memory_operation,
    instrument_tool_call,
    # Span utilities
    add_span_attribute,
    add_span_event,
    enable_auto_instrumentation,
)
from puvinoise.spans import (
    span,
    SpanKind,
    SpanRecord,
    emit_tool_call_spans,
)
from puvinoise.framework_detection import (
    detect_frameworks,
    detect_framework_details,
    detect_all as detect_all_frameworks,
    get_primary_framework,
    get_runtime_primary_framework,
    effective_detection_mode,
    framework_metadata_for_registration,
    sync_framework_env_from_runtime,
    reset_detection_cache,
)
from puvinoise.framework_usage import (
    record_framework_usage,
    get_framework_usage_counts,
    reset_framework_usage,
)
from puvinoise.framework_instrumentation import (
    apply_instrumentation as apply_framework_instrumentation,
    record_behavior_event,
    classify_behavior_pattern,
    get_patched_targets as get_framework_patched_targets,
    get_behavior_buffer,
    get_behavior_snapshot,
    signal_behavior_workflow_complete,
    behavior_classifier_has_run,
)
from puvinoise.agent_runtime import (
    AgentControlWorker,
    ControlCommand,
    DEFAULT_POLL_INTERVAL_SEC,
    start as start_agent_runtime,
    BareProcessBackend,
    DockerBackend,
    SystemdBackend,
    auto_backend,
    chain_hooks,
    telemetry_flush_hooks,
)
from puvinoise.decision_telemetry import (
    record_intent_classification,
    record_tool_candidates,
    record_reasoning_checkpoint,
    record_decision_confidence,
    record_tool_selection,
    record_tool_selection_reasoning,
    record_agent_state_transition,
    record_llm_reasoning_finished,
    record_plan_step,
    record_tool_decision_checkpoint,
    record_retry_checkpoint,
    record_fallback_checkpoint,
    record_retrieval_ranking,
    record_tool_execution_result,
    record_failure,
    set_trace_outcome,
    set_retry_attempt,
    record_outcome,
    record_task_completed,
    record_guardrail_triggered,
    flush_decision_events,
    get_dropped_event_count,
    get_telemetry_stats,
    recordIntentClassification,
    recordToolCandidates,
    recordReasoningCheckpoint,
    recordToolSelection,
    recordDecisionConfidence,
    recordAgentStateTransition,
    recordTaskCompleted,
)

__all__ = [
    "__version__",
    # Bootstrap & lifecycle
    "bootstrap",
    "build_resource",
    "build_resource_attributes",
    "init",
    "shutdown",
    "force_flush",
    "is_initialized",
    "start_agent_control_worker",
    "get_control_worker",
    "start_agent_config_poller",
    "get_agent_config_poller",
    "ensure_control_worker_started",
    "control_worker_auto_started",
    "start_control_loop",
    "stop_control_loop",
    "control_loop_started",
    "sdk_control_loop_enabled",
    "get_control_lifecycle_state",
    "is_agent_paused",
    "get_runtime_config_snapshot",
    "wait_if_control_paused",
    "check_allowed_to_run",
    "ControlLifecycleState",
    "start_agent_runtime",
    "get_runtime_metadata",
    "collect_runtime_metadata",
    "ensure_runtime_metadata_env",
    "sdk_telemetry_only",

    # Core tracing
    "run_with_trace",
    "start_trace",
    "record_context",
    "TraceContext",
    "observe_agent",

    # Auto-instrumentation (lifecycle + wrapAgent)
    "agent_start",
    "agent_step",
    "tool_call",
    "tool_result",
    "reasoning_complete",
    "task_complete",
    "wrapAgent",
    "agent",
    "PuviClient",
    "ScenarioTraceHandle",

    # Reliable telemetry (buffer, retry, persistence)
    "ReliableTelemetryBuffer",
    "get_decision_buffer",
    "set_decision_buffer",
    "init_decision_buffer_from_env",

    # Anthropic hooks
    "instrument_anthropic_call",
    "instrument_anthropic_stream",

    # OpenAI hooks
    "instrument_openai_call",
    "instrument_openai_stream",

    # Generic / Ollama hooks
    "instrument_llm_call",

    # Agent internals
    "instrument_memory_operation",
    "instrument_tool_call",

    # Span utilities
    "add_span_attribute",
    "add_span_event",
    "enable_auto_instrumentation",

    # Custom span system
    "span",
    "SpanKind",
    "SpanRecord",
    "emit_tool_call_spans",

    # Decision telemetry (agent decision-stage instrumentation)
    "record_intent_classification",
    "record_tool_candidates",
    "record_reasoning_checkpoint",
    "record_decision_confidence",
    "record_tool_selection",
    "record_tool_selection_reasoning",
    "record_agent_state_transition",
    "record_llm_reasoning_finished",
    "record_plan_step",
    "record_tool_decision_checkpoint",
    "record_retry_checkpoint",
    "record_fallback_checkpoint",
    "record_retrieval_ranking",
    "record_tool_execution_result",
    "record_failure",
    "set_trace_outcome",
    "set_retry_attempt",
    "record_outcome",
    "record_task_completed",
    "record_guardrail_triggered",
    "flush_decision_events",
    "get_dropped_event_count",
    "get_telemetry_stats",
    "recordIntentClassification",
    "recordToolCandidates",
    "recordReasoningCheckpoint",
    "recordToolSelection",
    "recordDecisionConfidence",
    "recordAgentStateTransition",
    "recordTaskCompleted",

    # Framework detection & instrumentation
    "detect_frameworks",
    "detect_framework_details",
    "detect_all_frameworks",
    "get_primary_framework",
    "get_runtime_primary_framework",
    "effective_detection_mode",
    "framework_metadata_for_registration",
    "sync_framework_env_from_runtime",
    "reset_detection_cache",
    "record_framework_usage",
    "get_framework_usage_counts",
    "reset_framework_usage",
    "apply_framework_instrumentation",
    "record_behavior_event",
    "classify_behavior_pattern",
    "get_framework_patched_targets",
    "get_behavior_buffer",
    "get_behavior_snapshot",
    "signal_behavior_workflow_complete",
    "behavior_classifier_has_run",

    # Remote agent control (polling worker + handlers + lifecycle backends)
    "AgentControlWorker",
    "ControlCommand",
    "DEFAULT_POLL_INTERVAL_SEC",
    "BareProcessBackend",
    "DockerBackend",
    "SystemdBackend",
    "auto_backend",
    "chain_hooks",
    "telemetry_flush_hooks",
    # Routing
    "init_routing",
    "get_routed_version",
    # Config loader
    "load_platform_config",
    "get_loaded_config",
]

try:
    ensure_control_worker_started()
except Exception:
    pass