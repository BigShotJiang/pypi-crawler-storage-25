"""
cli/puvinoise_run.py
─────────────────────
Phase E — `puvinoise run <command>` implementation.

This is the primary developer entrypoint. It is imported lazily from
cli/puvinoise.py so the main CLI stays fast to start.

Design goals (see Phase E spec):
  1. No file-based injection — we do NOT modify the user's source tree.
  2. env_id is required — if PUVINOISE_ENV_ID is not set AND no sidecar
     state file exists, we refuse to run and tell the user what to do.
  3. SDK presence is injected process-wide via sitecustomize.py, so the SDK
     auto-registers before user code runs its first line.
  4. The wrapped process inherits a clean env; we only add what we need.
  5. Exit code + signals are proxied transparently.

Fix 2 — Sitecustomize chaining:
  The generated sitecustomize.py first scans sys.path for any existing
  sitecustomize (at child-process startup time) and exec()s it before
  doing the PUVINoise injection. This prevents collision with user/framework
  sitecustomize files (e.g. pytest, coverage.py, virtualenvs).

Fix 4 — CLI argument handling:
  cmd_run() merges args._unknown_args (set by main() via parse_known_args)
  into the command list so arbitrary user flags pass through transparently.

Fix 5 — env_id source logging:
  _resolve_env_id_with_source() returns (env_id, source_label) and
  run_command() prints the resolved source so developers know where it came from.

Usage:
    puvinoise run python app.py
    puvinoise run --env-id prod-123 --agent-name billing-agent python app.py
    puvinoise run --dry-run python app.py       # print what would run, don't exec
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# ─── Fix 2: sitecustomize chain header ────────────────────────────────────────
# Injected at the TOP of the generated sitecustomize.py.
# At child-process startup, this scans the *real* sys.path for an existing
# sitecustomize and exec()s it before PUVINoise init runs.  The scan is
# performed at runtime (inside the child), not here, so it sees the child's
# actual sys.path regardless of what the parent process had.
_SITECUSTOMIZE_CHAIN_HEADER = """\
# puvinoise run — sitecustomize chaining (Fix 2)
# Execute any existing sitecustomize.py from the *real* sys.path first,
# so we do not accidentally suppress user or framework sitecustomize hooks
# (e.g. pytest-cov, virtualenvs, editable installs).
import sys as _sc_sys
import os as _sc_os

_sc_this_dir = _sc_os.path.dirname(_sc_os.path.abspath(__file__))
for _sc_entry in list(_sc_sys.path):
    if _sc_entry == _sc_this_dir:
        continue
    _sc_candidate = _sc_os.path.join(_sc_entry, "sitecustomize.py")
    if _sc_os.path.isfile(_sc_candidate):
        try:
            with open(_sc_candidate, "r", encoding="utf-8") as _sc_fh:
                exec(compile(_sc_fh.read(), _sc_candidate, "exec"), {})  # noqa: S102
        except Exception as _sc_exc:
            _sc_sys.stderr.write(
                f"[puvinoise-run] warning: chained sitecustomize raised: {_sc_exc}\\n"
            )
        break
del _sc_sys, _sc_os, _sc_this_dir
# ── end chaining ──────────────────────────────────────────────────────────────

"""

PRELOAD_SNIPPET = """\
# puvinoise run — auto-generated preload
# Initializes the PUVINoise SDK before user code executes so the agent
# auto-registers and telemetry hooks are in place.
import os as _os
import sys as _sys

try:
    import puvinoise as _puvi
    _agent_name = (
        _os.environ.get("PUVINOISE_AGENT_NAME")
        or _os.environ.get("PUVINOISE_AGENT_ID")
        or "puvinoise-run-agent"
    )
    _api_key = (_os.environ.get("PUVINOISE_API_KEY") or "").strip()
    _base = (_os.environ.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")
    if _api_key and _base:
        _puvi.init(
            api_key=_api_key,
            agent_name=_agent_name,
        )
        _sys.stderr.write("[puvinoise-run] SDK initialized; agent auto-registering\\n")
    else:
        _sys.stderr.write(
            "[puvinoise-run] WARNING: PUVINOISE_API_KEY or PUVINOISE_BASE_URL "
            "not set — SDK init skipped\\n"
        )
except Exception as _e:
    _sys.stderr.write(f"[puvinoise-run] SDK init failed (non-fatal): {_e}\\n")
"""

# ─────────────────────────────────────────────────────────────────────────────
# Fix 5: env_id resolution with source transparency
# ─────────────────────────────────────────────────────────────────────────────

_ENV_ID_KEYS = ("PUVINOISE_ENV_ID", "PUVINOISE_ENVIRONMENT_ID")
_STATE_FILES  = (".puvinoise_env.json", ".puvinoise_bind_state.json")


def _resolve_env_id_with_source(explicit: Optional[str]) -> Tuple[str, str]:
    """
    Resolve env_id from (in priority order):
      1. explicit CLI --env-id flag
      2. environment variables
      3. sidecar state files in cwd and parent dirs (up to 3 levels)

    Returns (env_id, source_label) where source_label is a human-readable
    string like "cli:--env-id", "env_var:PUVINOISE_ENV_ID", or
    "sidecar_file:.puvinoise_env.json".
    """
    if explicit and explicit.strip():
        return explicit.strip(), "cli:--env-id"

    for k in _ENV_ID_KEYS:
        v = os.environ.get(k, "").strip()
        if v:
            return v, f"env_var:{k}"

    cwd = Path.cwd()
    for name in _STATE_FILES:
        for parent in [cwd] + list(cwd.parents)[:3]:
            p = parent / name
            if p.exists():
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    env_id = data.get("env_id")
                    if env_id:
                        return str(env_id).strip(), f"sidecar_file:{name}"
                except Exception:  # noqa: BLE001
                    pass

    return "", "not_found"


# Keep the old name as an alias so existing callers inside this module compile.
def _resolve_env_id_from_cli_or_env(explicit: Optional[str]) -> str:
    env_id, _ = _resolve_env_id_with_source(explicit)
    return env_id


_SIDECAR_JSON_NAMES = (".puvinoise_bind_state.json", ".puvinoise_env.json")


def _shell_nonempty(*keys: str) -> bool:
    return any(os.environ.get(k, "").strip() for k in keys)


def _parse_dotenv_file(path: Path) -> Dict[str, str]:
    """KEY=VAL lines; supports optional `export ` prefix and quoted values."""
    out: Dict[str, str] = {}
    if not path.is_file():
        return out
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError:
        return out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        k, _, rest = line.partition("=")
        k = k.strip()
        if not k:
            continue
        val = rest.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ("\"", "'"):
            val = val[1:-1]
        out[k] = val
    return out


def _find_dotenv_path() -> Optional[Path]:
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        p = parent / ".env"
        if p.is_file():
            return p
    return None


def _load_first_sidecar_json_state() -> Tuple[Dict[str, object], Optional[Path]]:
    """
    Same discovery order as agent_autoregister._load_sidecar_state (no import),
    so bootstrap works even if autoregister is not importable.

    CWD and parents only — no /tmp (avoids stale handoff from other sessions;
    run `puvinoise run` from the bound agent directory).
    """
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        for name in _SIDECAR_JSON_NAMES:
            p = parent / name
            if not p.is_file():
                continue
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
            except Exception:  # noqa: BLE001
                continue
            if isinstance(data, dict) and data:
                return data, p
        if len(parent.parts) <= 1 or str(parent) in ("/", "C:\\"):
            break
    return {}, None


def _compose_bootstrap_extra_env() -> Tuple[Dict[str, str], str]:
    """
    Build env vars for the child process without modifying the user's shell.

    Precedence: existing process environment wins. Then merge, in order:
      1) project `.env` (cwd → parents)
      2) sidecar JSON (``.puvinoise_bind_state.json`` / ``.puvinoise_env.json``),
         which may set ``PUVINOISE_BASE_URL`` and ``PUVINOISE_AGENT_ID`` from
         ``base_url`` and ``agent_id`` only (credentials stay in ``.env``).

    This matches the minimal sidecar contract so `puvinoise run` works after
    bind when ``.env`` has ``PUVINOISE_API_KEY``.
    """
    extra: Dict[str, str] = {}
    labels: List[str] = []

    dotenv_path = _find_dotenv_path()
    dotmap = _parse_dotenv_file(dotenv_path) if dotenv_path else {}
    for k, v in dotmap.items():
        if not (v or "").strip():
            continue
        if os.environ.get(k, "").strip():
            continue
        extra[k] = str(v).strip()
    if dotenv_path:
        labels.append(str(dotenv_path))

    state, sidecar_path = _load_first_sidecar_json_state()
    if state:
        base = (state.get("base_url") or "").strip()
        if base and not _shell_nonempty("PUVINOISE_BASE_URL"):
            extra["PUVINOISE_BASE_URL"] = base.rstrip("/")
        aid = (state.get("agent_id") or "").strip()
        if aid and not _shell_nonempty("PUVINOISE_AGENT_ID"):
            extra["PUVINOISE_AGENT_ID"] = aid
        if sidecar_path:
            labels.append(str(sidecar_path))

    summary = " · ".join(labels) if labels else ""
    return extra, summary


def _build_sitecustomize(tmpdir: Path) -> Path:
    """
    Write a sitecustomize.py to a scratch dir, then prepend that dir to
    PYTHONPATH in the child process.  CPython auto-imports sitecustomize at
    interpreter startup, so the SDK initializes BEFORE user code runs.

    The generated file first chains any existing sitecustomize (Fix 2), then
    runs the PUVINoise init snippet.
    """
    site = tmpdir / "sitecustomize.py"
    site.write_text(_SITECUSTOMIZE_CHAIN_HEADER + PRELOAD_SNIPPET, encoding="utf-8")
    return site


def _build_child_env(
    *,
    env_id: str,
    agent_name: Optional[str],
    tmpdir: Path,
    extra_env: Optional[Dict[str, str]] = None,
) -> Dict[str, str]:
    env = os.environ.copy()
    env["PUVINOISE_ENV_ID"] = env_id
    if agent_name:
        env["PUVINOISE_AGENT_NAME"] = agent_name
    # Mark this process as SDK-instrumented so the sidecar bootstrap path
    # downgrades gracefully if it ever runs alongside.
    env["PUVINOISE_RUNTIME_DRIVEN"] = "1"
    env["PUVINOISE_AUTOREGISTER"] = env.get("PUVINOISE_AUTOREGISTER", "1")

    # sitecustomize injection — prepend scratch dir to PYTHONPATH so the
    # interpreter loads our hook before user packages.
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (
        f"{tmpdir}{os.pathsep}{existing_pp}" if existing_pp else str(tmpdir)
    )
    if extra_env:
        for k, v in extra_env.items():
            env[k] = str(v)
    return env


def run_command(
    command: List[str],
    *,
    env_id: Optional[str] = None,
    agent_name: Optional[str] = None,
    dry_run: bool = False,
    strict: bool = True,
) -> int:
    """
    Execute <command> as a PUVINoise-instrumented process.

    Returns the child process's exit code (or 1 on precondition failure).
    """
    if not command:
        print("puvinoise run: no command provided", file=sys.stderr)
        return 2

    # Fix 5: resolve with source transparency
    resolved_env_id, env_id_source = _resolve_env_id_with_source(env_id)
    if not resolved_env_id:
        print(
            "puvinoise run: env_id is missing.\n"
            "  Either pass --env-id <id>, or set PUVINOISE_ENV_ID, or run the\n"
            "  bind-sidecar first so it writes .puvinoise_env.json in this directory.\n"
            "  Phase D: agent registration without an environment is not permitted.",
            file=sys.stderr,
        )
        return 1 if strict else 0

    # Fix 5: print resolved source so the developer knows where it came from.
    print(
        f"[puvinoise-run] env_id resolved  (source={env_id_source})",
        file=sys.stderr,
    )

    handoff_env, bootstrap_sources = _compose_bootstrap_extra_env()
    if bootstrap_sources and any(
        k in handoff_env
        for k in (
            "PUVINOISE_BASE_URL",
            "PUVINOISE_API_KEY",
            "PUVINOISE_AGENT_ID",
        )
    ):
        print(
            f"[puvinoise-run] bootstrap env (no export needed): {bootstrap_sources}",
            file=sys.stderr,
        )

    # Resolve the command's executable — respect PATH but give a clear error.
    exe = command[0]
    if not os.path.isabs(exe) and os.sep not in exe:
        found = shutil.which(exe)
        # macOS/Homebrew often expose `python3` but not `python` on PATH.
        if not found and exe == "python":
            found = shutil.which("python3")
            if found:
                print(
                    f"[puvinoise-run] `{exe}` not on PATH — using {found}",
                    file=sys.stderr,
                )
        if not found:
            hint = ""
            if exe in ("python", "python3"):
                hint = f"\n  Hint: install Python or use `puvinoise run python3 ...` / full path to the interpreter."
            print(
                f"puvinoise run: command not found on PATH: {exe}{hint}",
                file=sys.stderr,
            )
            return 127
        command = [found] + list(command[1:])

    # Create a short-lived scratch dir for the sitecustomize hook.
    tmpdir_obj = tempfile.TemporaryDirectory(prefix="puvinoise-run-")
    tmpdir = Path(tmpdir_obj.name)
    try:
        _build_sitecustomize(tmpdir)
        child_env = _build_child_env(
            env_id=resolved_env_id,
            agent_name=agent_name,
            tmpdir=tmpdir,
            extra_env=handoff_env or None,
        )

        if dry_run:
            print("puvinoise run — DRY RUN")
            print(f"  command       : {' '.join(shlex.quote(c) for c in command)}")
            print(f"  env_id        : {resolved_env_id}  [{env_id_source}]")
            print(f"  agent_name    : {agent_name or '(inherited)'}")
            print(f"  sitecustomize : {tmpdir / 'sitecustomize.py'}")
            print(f"  PYTHONPATH    : {child_env['PYTHONPATH']}")
            if handoff_env:
                print(f"  bootstrap keys: {', '.join(sorted(handoff_env.keys()))}")
            return 0

        # subprocess.run proxies stdin/stdout/stderr + exit code transparently.
        try:
            result = subprocess.run(command, env=child_env, check=False)
            return result.returncode
        except KeyboardInterrupt:
            return 130
    finally:
        try:
            tmpdir_obj.cleanup()
        except Exception:  # noqa: BLE001
            pass


def cmd_run(args) -> int:
    """argparse entry point for `puvinoise run`."""
    command = list(args.command or [])
    # Drop the leading '--' that argparse.REMAINDER may preserve.
    if command and command[0] == "--":
        command = command[1:]

    # Fix 4: merge unknown args captured by parse_known_args() in main()
    # so arbitrary user flags (e.g. `puvinoise run --foo python app.py`) are
    # passed through to the subprocess rather than raising an argparse error.
    unknown = getattr(args, "_unknown_args", None)
    if unknown:
        command = list(unknown) + command

    return run_command(
        command,
        env_id=getattr(args, "env_id", None),
        agent_name=getattr(args, "agent_name", None),
        dry_run=getattr(args, "dry_run", False),
        strict=not getattr(args, "no_strict", False),
    )


def register_subparser(sub) -> None:
    """Attach the `run` subcommand to the top-level CLI parser."""
    run_p = sub.add_parser(
        "run",
        help="Run a command inside the PUVINoise SDK runtime (auto-register + telemetry)",
        description=(
            "Run <command> as an instrumented agent. The SDK auto-registers with the "
            "control plane before user code executes. Requires PUVINOISE_ENV_ID to be "
            "set (or the bind-sidecar's .puvinoise_env.json to be present)."
        ),
    )
    run_p.add_argument("--env-id", dest="env_id", default=None, help="Environment id (overrides PUVINOISE_ENV_ID)")
    run_p.add_argument("--agent-name", dest="agent_name", default=None, help="Agent name override")
    run_p.add_argument("--dry-run", dest="dry_run", action="store_true", help="Print what would run and exit 0")
    run_p.add_argument("--no-strict", dest="no_strict", action="store_true", help="Don't fail when env_id is missing")
    run_p.add_argument("command", nargs=subparser_remainder(), help="Command to run (prefix with -- for flag safety)")
    run_p.set_defaults(func=cmd_run)


def subparser_remainder():
    """argparse.REMAINDER constant — isolated so the module imports cleanly."""
    import argparse
    return argparse.REMAINDER
