"""
PUVINoise Sidecar Manager
=========================

Cross-platform launcher for the PUVINoise sidecar binary.

Design goals
------------
1. Never rely on PATH. The sidecar binary ships inside the installed SDK at a
   well-known location: ``<sdk_install_dir>/bin/{os}/{arch}/puvinoise-sidecar[.exe]``.
2. Work identically on Windows (PowerShell / CMD), macOS and Linux – including
   inside virtualenvs, Docker containers, and minimal CI images.
3. Fail loudly with actionable error messages; never fail silently.
4. Optional zero-config auto-download fallback when the binary is missing for
   the current OS/arch (e.g. a user installed the pure-Python wheel that did
   not bundle every platform's binary).
5. Treat the sidecar as a supervised long-running child process with clean
   shutdown semantics.

Public API
----------
    from puvinoise import start_sidecar, stop_sidecar, SidecarManager

    # Zero-config: SDK resolves binary, validates, starts, supervises
    proc = start_sidecar()

    # Later, on application shutdown
    stop_sidecar()

This module has no hard dependency on the rest of the SDK, so it can be used
standalone in bootstrap scripts or Docker entrypoints.
"""
from __future__ import annotations

import atexit
import hashlib
import logging
import os
import platform
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

log = logging.getLogger("puvinoise.sidecar")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SIDECAR_BINARY_NAME = "puvinoise-sidecar"

# Base URL used by the optional auto-download fallback. In production this
# would point at a signed CDN; kept as an env-overridable constant so that
# enterprise customers can mirror binaries internally (air-gapped installs).
DEFAULT_DOWNLOAD_BASE_URL = os.environ.get(
    "PUVI_SIDECAR_DOWNLOAD_BASE",
    "https://cdn.puvilabs.com/puvinoise/sidecar",
)

# Connection timeout for the fallback download, in seconds.
DOWNLOAD_TIMEOUT_SECS = 60

# How long to wait (seconds) for the sidecar to confirm it started before we
# assume it crashed.
STARTUP_GRACE_SECS = 5.0

# Interval for the background supervisor health-check thread.
SUPERVISOR_POLL_SECS = 2.0


# ---------------------------------------------------------------------------
# OS / arch detection
# ---------------------------------------------------------------------------

class OSFamily:
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"


def detect_os() -> str:
    """Return one of OSFamily.WINDOWS / MACOS / LINUX.

    Raises SidecarUnsupportedPlatform for anything else (e.g. AIX, FreeBSD).
    """
    sysname = platform.system().lower()
    if sysname.startswith("win") or os.name == "nt":
        return OSFamily.WINDOWS
    if sysname == "darwin":
        return OSFamily.MACOS
    if sysname == "linux":
        return OSFamily.LINUX
    raise SidecarUnsupportedPlatform(
        f"PUVINoise sidecar does not currently ship a binary for platform "
        f"'{sysname}'. Supported: Windows, macOS, Linux."
    )


def detect_arch() -> str:
    """Return a normalised CPU arch string: ``amd64`` | ``arm64``.

    We normalise aggressively because Python's ``platform.machine()`` returns
    different strings across OSes (``x86_64`` on Linux/macOS vs ``AMD64`` on
    Windows) for the same underlying architecture.
    """
    m = (platform.machine() or "").lower()
    if m in ("x86_64", "amd64", "x64"):
        return "amd64"
    if m in ("arm64", "aarch64"):
        return "arm64"
    # Fallback: return the raw value so the error later is informative, rather
    # than silently picking the wrong binary.
    return m or "unknown"


def executable_suffix(os_family: str) -> str:
    return ".exe" if os_family == OSFamily.WINDOWS else ""


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class SidecarError(RuntimeError):
    """Base class for sidecar-related errors."""


class SidecarNotFound(SidecarError):
    """Raised when no binary can be resolved for the current OS/arch."""


class SidecarUnsupportedPlatform(SidecarError):
    """Raised when the host OS is not in the supported matrix."""


class SidecarStartupError(SidecarError):
    """Raised when the sidecar process failed to stay alive during the grace period."""


# ---------------------------------------------------------------------------
# Binary resolution
# ---------------------------------------------------------------------------

def sdk_install_dir() -> Path:
    """Directory containing the ``puvinoise`` package (this file's parent)."""
    return Path(__file__).resolve().parent


def _candidate_binary_paths(os_family: str, arch: str) -> List[Path]:
    """Return an ordered list of locations to probe for the sidecar binary.

    Resolution order (first match wins):

      1. ``PUVI_SIDECAR_BIN``              — explicit override, absolute path to an executable.
      2. ``<sdk_install_dir>/bin/{os}/{arch}/puvinoise-sidecar[.exe]``
      3. ``<sdk_install_dir>/bin/{os}/puvinoise-sidecar[.exe]``   (legacy, arch-agnostic)
      4. User-local cache dir used by the auto-download fallback:
         ``~/.puvinoise/sidecar/{os}/{arch}/puvinoise-sidecar[.exe]``

    PATH is *deliberately* not consulted.
    """
    override = os.environ.get("PUVI_SIDECAR_BIN")
    candidates: List[Path] = []
    if override:
        candidates.append(Path(override).expanduser().resolve())

    suffix = executable_suffix(os_family)
    filename = f"{SIDECAR_BINARY_NAME}{suffix}"

    base = sdk_install_dir() / "bin"
    candidates.append(base / os_family / arch / filename)
    candidates.append(base / os_family / filename)

    cache = _user_cache_dir() / os_family / arch / filename
    candidates.append(cache)

    return candidates


def _user_cache_dir() -> Path:
    """Per-user cache for auto-downloaded binaries."""
    if os.name == "nt":
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
        return Path(root) / "puvinoise" / "sidecar"
    return Path(os.path.expanduser("~")) / ".puvinoise" / "sidecar"


def resolve_binary(
    os_family: Optional[str] = None,
    arch: Optional[str] = None,
    auto_download: bool = True,
) -> Path:
    """Locate the sidecar binary for the current platform.

    Parameters
    ----------
    os_family, arch : optional overrides, mainly for tests / cross-inspection.
    auto_download   : if True and no binary is found anywhere, attempt a
                      one-shot download into the per-user cache dir before
                      giving up.

    Raises
    ------
    SidecarNotFound : when nothing resolves (with a detailed message listing
                      every path that was probed).
    """
    os_family = os_family or detect_os()
    arch = arch or detect_arch()

    probed: List[Path] = _candidate_binary_paths(os_family, arch)
    for path in probed:
        if path.is_file():
            log.debug("sidecar binary resolved: %s", path)
            return path

    if auto_download:
        try:
            downloaded = _download_binary(os_family, arch)
            if downloaded and downloaded.is_file():
                return downloaded
        except Exception as exc:  # pragma: no cover - network path
            log.warning("sidecar auto-download failed: %s", exc)

    pretty = "\n  - ".join(str(p) for p in probed)
    raise SidecarNotFound(
        f"Sidecar not found for {os_family}/{arch}. Please run the install "
        f"step (e.g. `python -m puvinoise install-sidecar`) or set the "
        f"PUVI_SIDECAR_BIN environment variable to an explicit path.\n"
        f"Paths probed:\n  - {pretty}"
    )


# ---------------------------------------------------------------------------
# Auto-download fallback (optional, best-effort)
# ---------------------------------------------------------------------------

def _download_binary(os_family: str, arch: str) -> Optional[Path]:
    """Download the sidecar binary for this platform into the user cache dir.

    This is intentionally simple: a single HTTPS GET, atomic rename, and a
    chmod on Unix. Enterprises can point PUVI_SIDECAR_DOWNLOAD_BASE at an
    internal mirror. The download is a no-op if the destination already exists.
    """
    suffix = executable_suffix(os_family)
    filename = f"{SIDECAR_BINARY_NAME}{suffix}"
    url = f"{DEFAULT_DOWNLOAD_BASE_URL}/{os_family}/{arch}/{filename}"

    dest_dir = _user_cache_dir() / os_family / arch
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / filename
    if dest.is_file():
        return dest

    log.info("downloading sidecar binary: %s → %s", url, dest)

    # Stream to a temp file in the same dir, then atomically rename.
    tmp_fd, tmp_path = tempfile.mkstemp(prefix=".puvi-dl-", dir=str(dest_dir))
    os.close(tmp_fd)
    tmp = Path(tmp_path)
    try:
        with urllib.request.urlopen(url, timeout=DOWNLOAD_TIMEOUT_SECS) as resp:
            if getattr(resp, "status", 200) >= 400:
                raise SidecarError(f"download returned HTTP {resp.status}")
            with open(tmp, "wb") as fh:
                shutil.copyfileobj(resp, fh)
        _ensure_executable(tmp, os_family)
        os.replace(tmp, dest)
        log.info("sidecar binary cached at %s", dest)
        return dest
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def _ensure_executable(path: Path, os_family: str) -> None:
    """On Unix, set the executable bit. No-op on Windows (uses .exe suffix)."""
    if os_family == OSFamily.WINDOWS:
        return
    try:
        st = path.stat()
        path.chmod(st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except OSError as exc:
        raise SidecarError(
            f"Could not mark sidecar binary executable ({path}): {exc}"
        ) from exc


# ---------------------------------------------------------------------------
# Process manager
# ---------------------------------------------------------------------------

@dataclass
class SidecarProcess:
    """Handle returned by ``start_sidecar``. Kept deliberately small."""
    pid: int
    binary: Path
    os_family: str
    arch: str
    popen: subprocess.Popen
    started_at: float = field(default_factory=time.time)

    @property
    def is_running(self) -> bool:
        return self.popen.poll() is None


class SidecarManager:
    """Singleton-style supervisor for a single sidecar child process.

    Most users should call the module-level :func:`start_sidecar` /
    :func:`stop_sidecar` helpers; they wrap a shared ``SidecarManager``
    instance so multiple ``start_sidecar()`` calls from different code paths
    are idempotent.
    """

    _instance_lock = threading.Lock()
    _instance: "Optional[SidecarManager]" = None

    def __init__(self) -> None:
        self._proc: Optional[SidecarProcess] = None
        self._lock = threading.Lock()
        self._supervisor: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._restart_count = 0
        self._max_restarts = int(os.environ.get("PUVI_SIDECAR_MAX_RESTARTS", "3"))

    # -- singleton -----------------------------------------------------

    @classmethod
    def instance(cls) -> "SidecarManager":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls()
                atexit.register(cls._instance.stop)
            return cls._instance

    # -- public API ----------------------------------------------------

    def start(
        self,
        args: Optional[Sequence[str]] = None,
        env: Optional[Mapping[str, str]] = None,
        cwd: Optional[os.PathLike] = None,
        auto_download: bool = True,
        supervise: bool = True,
    ) -> SidecarProcess:
        """Start the sidecar. Idempotent: returns the existing handle if it's
        still running.
        """
        with self._lock:
            if self._proc and self._proc.is_running:
                log.debug("sidecar already running (pid=%s)", self._proc.pid)
                return self._proc

            os_family = detect_os()
            arch = detect_arch()
            binary = resolve_binary(os_family, arch, auto_download=auto_download)
            _ensure_executable(binary, os_family)

            full_args: List[str] = [str(binary), *(args or [])]
            merged_env = self._merge_env(env)

            log.info(
                "starting PUVINoise sidecar: binary=%s os=%s arch=%s args=%s",
                binary, os_family, arch, full_args[1:],
            )

            popen = self._spawn(full_args, merged_env, cwd, os_family)

            # Grace period: catch immediate crashes so callers get a clear
            # error instead of a silent zombie.
            exited = popen.poll()
            deadline = time.time() + STARTUP_GRACE_SECS
            while exited is None and time.time() < deadline:
                time.sleep(0.1)
                exited = popen.poll()
            if exited is not None and exited != 0:
                raise SidecarStartupError(
                    f"Sidecar exited immediately with code {exited}. "
                    f"Binary: {binary}. Check sidecar logs (stderr)."
                )

            proc = SidecarProcess(
                pid=popen.pid,
                binary=binary,
                os_family=os_family,
                arch=arch,
                popen=popen,
            )
            self._proc = proc

            if supervise and self._supervisor is None:
                self._stop_flag.clear()
                self._supervisor = threading.Thread(
                    target=self._supervise_loop,
                    name="puvi-sidecar-supervisor",
                    daemon=True,
                )
                self._supervisor.start()

            return proc

    def stop(self, timeout: float = 10.0) -> None:
        """Request a graceful shutdown; escalate to kill after ``timeout``."""
        with self._lock:
            self._stop_flag.set()
            proc = self._proc
            self._proc = None

        if not proc or not proc.is_running:
            return

        log.info("stopping sidecar (pid=%s)", proc.pid)
        try:
            if proc.os_family == OSFamily.WINDOWS:
                # CTRL_BREAK is the only signal deliverable to a child started
                # with CREATE_NEW_PROCESS_GROUP. Falls back to terminate().
                try:
                    proc.popen.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
                except Exception:
                    proc.popen.terminate()
            else:
                proc.popen.terminate()
            try:
                proc.popen.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                log.warning("sidecar did not exit in %ss — killing (pid=%s)", timeout, proc.pid)
                proc.popen.kill()
                proc.popen.wait(timeout=5)
        except Exception as exc:
            log.warning("error stopping sidecar: %s", exc)

    @property
    def current(self) -> Optional[SidecarProcess]:
        return self._proc

    # -- internals -----------------------------------------------------

    @staticmethod
    def _merge_env(extra: Optional[Mapping[str, str]]) -> Dict[str, str]:
        env = os.environ.copy()
        if extra:
            env.update({k: str(v) for k, v in extra.items()})
        # Hint to the sidecar that it was launched by the SDK manager.
        env.setdefault("PUVI_SIDECAR_LAUNCHED_BY", "sdk")
        return env

    @staticmethod
    def _spawn(
        args: List[str],
        env: Dict[str, str],
        cwd: Optional[os.PathLike],
        os_family: str,
    ) -> subprocess.Popen:
        """OS-aware Popen wrapper.

        Key Windows specifics:
          * ``shell=False`` always — we never want cmd.exe to re-interpret args.
          * ``CREATE_NEW_PROCESS_GROUP`` so we can later send CTRL_BREAK_EVENT
            for graceful shutdown without killing the parent console.
          * No ``close_fds`` on Windows (it's the default and conflicts with
            stdio redirection on older Python).

        On Unix:
          * ``start_new_session=True`` so ``Ctrl-C`` in the parent TTY does
            not automatically kill the sidecar; we control its lifetime
            explicitly via ``stop()``.
        """
        popen_kwargs: Dict[str, object] = dict(
            args=args,
            env=env,
            cwd=str(cwd) if cwd else None,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            shell=False,
        )
        if os_family == OSFamily.WINDOWS:
            creationflags = 0
            # CREATE_NEW_PROCESS_GROUP = 0x00000200
            creationflags |= 0x00000200
            popen_kwargs["creationflags"] = creationflags
        else:
            popen_kwargs["start_new_session"] = True

        try:
            return subprocess.Popen(**popen_kwargs)  # type: ignore[arg-type]
        except FileNotFoundError as exc:
            raise SidecarNotFound(
                f"Sidecar binary not executable at {args[0]} ({exc}). "
                f"If you are on Windows, ensure the .exe suffix is present; "
                f"on Unix, ensure the executable bit is set."
            ) from exc
        except PermissionError as exc:
            raise SidecarError(
                f"Permission denied launching sidecar at {args[0]}: {exc}. "
                f"On Unix run: chmod +x '{args[0]}'."
            ) from exc

    def _supervise_loop(self) -> None:
        """Background thread: if the sidecar dies unexpectedly, restart up to
        ``PUVI_SIDECAR_MAX_RESTARTS`` times with exponential backoff.
        """
        backoff = 1.0
        while not self._stop_flag.is_set():
            time.sleep(SUPERVISOR_POLL_SECS)
            proc = self._proc
            if not proc:
                continue
            if proc.is_running:
                backoff = 1.0  # healthy → reset backoff
                continue
            # crashed
            exit_code = proc.popen.returncode
            log.warning(
                "sidecar exited unexpectedly (pid=%s, code=%s); restart %d/%d",
                proc.pid, exit_code, self._restart_count + 1, self._max_restarts,
            )
            if self._restart_count >= self._max_restarts:
                log.error(
                    "sidecar restart budget exhausted (%d); giving up",
                    self._max_restarts,
                )
                return
            self._restart_count += 1
            time.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
            try:
                with self._lock:
                    self._proc = None
                self.start(supervise=False)  # avoid nesting supervisors
            except SidecarError as exc:
                log.error("sidecar restart failed: %s", exc)
                return


# ---------------------------------------------------------------------------
# Module-level convenience API
# ---------------------------------------------------------------------------

def start_sidecar(
    *args: str,
    env: Optional[Mapping[str, str]] = None,
    cwd: Optional[os.PathLike] = None,
    auto_download: bool = True,
    supervise: bool = True,
) -> SidecarProcess:
    """Start (or return the already-running) PUVINoise sidecar.

    Example
    -------
    >>> from puvinoise import start_sidecar
    >>> start_sidecar()
    """
    return SidecarManager.instance().start(
        args=list(args) if args else None,
        env=env,
        cwd=cwd,
        auto_download=auto_download,
        supervise=supervise,
    )


def stop_sidecar(timeout: float = 10.0) -> None:
    """Gracefully stop the sidecar (no-op if nothing is running)."""
    SidecarManager.instance().stop(timeout=timeout)


def sidecar_status() -> Dict[str, object]:
    """Lightweight status dict, safe to expose from health endpoints."""
    mgr = SidecarManager.instance()
    proc = mgr.current
    return {
        "running": bool(proc and proc.is_running),
        "pid": proc.pid if proc else None,
        "binary": str(proc.binary) if proc else None,
        "os": proc.os_family if proc else detect_os(),
        "arch": proc.arch if proc else detect_arch(),
        "uptime_secs": (time.time() - proc.started_at) if proc else 0.0,
    }


__all__ = [
    "OSFamily",
    "SidecarError",
    "SidecarNotFound",
    "SidecarUnsupportedPlatform",
    "SidecarStartupError",
    "SidecarProcess",
    "SidecarManager",
    "detect_os",
    "detect_arch",
    "resolve_binary",
    "start_sidecar",
    "stop_sidecar",
    "sidecar_status",
]
