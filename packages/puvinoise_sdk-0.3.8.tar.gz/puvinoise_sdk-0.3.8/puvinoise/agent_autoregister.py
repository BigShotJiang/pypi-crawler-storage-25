"""
agent-sdk/puvinoise/agent_autoregister.py
──────────────────────────────────────────
Phase E — Runtime Instrumentation Layer  (hardened for production)

SDK-driven auto-registration.

Responsibilities
----------------
1. Read env_id (from environment variable or a sidecar-written state file).
2. Collect runtime metadata: sdk_version, runtime, entrypoint, pid, host.
3. POST /api/agent-register with proof-of-SDK markers.
4. Emit a visible error on failure; exit if PUVINOISE_STRICT=1 (Fix 6).
5. Provide an in-process heartbeat loop (opt-in, daemon thread).

Hardening fixes (production-readiness pass)
-------------------------------------------
Fix 1 – Double-registration guard
    _REGISTERED_IN_PROCESS prevents a second registration attempt within
    the same OS process, even when puvinoise.init() is called multiple times
    (e.g. once by `puvinoise run` sitecustomize and once by user code).

Fix 3 – Heartbeat lifecycle safety
    atexit.register(stop_heartbeat_loop) is called exactly once so the
    heartbeat daemon is always cleaned up on interpreter exit, even in
    long-lived processes such as Jupyter notebooks.

Fix 5 – env_id resolution transparency
    resolve_env_id_with_source() returns both the value and the source
    (env_var / sidecar_state_file). Both the CLI wrapper and this module
    emit "[puvinoise] Using env_id=... (source: ...)" to stderr.

Fix 6 – Fail loudly on registration errors
    Failures are always printed to stderr with a clear, actionable message.
    By default execution continues (fail-open) to protect host agent processes.
    Setting PUVINOISE_STRICT=1 turns failures into hard errors (raises / exits).

Fix 7 – Single initialisation path flagging
    _INIT_MODE is set to "cli" when PUVINOISE_RUNTIME_DRIVEN=1 (injected by
    `puvinoise run`) and "manual" otherwise. CLI-driven mode triggers stricter
    duplicate-registration enforcement.

Contract with Phase D backend
-----------------------------
The backend enforces:
    env_id REQUIRED                → 400 ENV_ID_REQUIRED
    runtime_metadata.sdk_version   → required (unless runtime starts with "bind-")
    runtime_metadata.runtime       → required
    environment.bootstrapStatus    → must be BOOTSTRAPPED (else 403)

This module always sends proof-of-SDK markers so callers pass both gates.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import platform
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from puvinoise.env_resolve import (
    env_var,
    get_api_key,
    get_agent_id,
    get_agent_name,
    get_base_url,
)

logger = logging.getLogger("puvinoise.autoregister")

# ─── Constants ────────────────────────────────────────────────────────────────

AUTOREGISTER_CONTRACT_VERSION = "1.0"

# File name PUVINoise writes/reads to the agent directory.
PUVINOISE_AGENT_YAML_FILENAME = "puvinoise-agent.yaml"

# Last known contract tier for this process (set after successful registration).
_CONTRACT_TIER: str = "unknown"

ENV_ID_KEYS: Tuple[str, ...] = (
    "PUVINOISE_ENV_ID",
    "PUVINOISE_ENVIRONMENT_ID",
)

STATE_FILE_BASENAMES: Tuple[str, ...] = (
    ".puvinoise_bind_state.json",
    ".puvinoise_env.json",
)


# ─── Process-level state (Fix 1, 3, 7) ───────────────────────────────────────

# Fix 1: Set to True after the first successful (or attempted) registration so
# that subsequent init() calls from user code do not fire a second POST.
_REGISTERED_IN_PROCESS: bool = False

# Fix 7: "cli"  → process was started by `puvinoise run` (PUVINOISE_RUNTIME_DRIVEN=1)
#         "manual" → user called puvinoise.init() directly
_INIT_MODE: str = "unknown"

# Fix 3: Ensure atexit is registered at most once per process.
_ATEXIT_REGISTERED: bool = False


# ─── Exceptions ───────────────────────────────────────────────────────────────

class AutoRegisterError(RuntimeError):
    """Raised by the strict API when registration fails."""


class EnvIdMissingError(AutoRegisterError):
    """env_id could not be resolved from env vars or state files."""


class BackendRejectedError(AutoRegisterError):
    """Backend returned a non-2xx response (gate failure, validation, etc.)."""
    def __init__(self, status: int, code: Optional[str], body: Any):
        super().__init__(f"backend rejected registration: HTTP {status} code={code!r}")
        self.status = status
        self.code = code
        self.body = body


# ─── Internal helpers ─────────────────────────────────────────────────────────

def _first_nonempty_env(keys: Tuple[str, ...]) -> str:
    for k in keys:
        v = os.environ.get(k, "")
        if v and v.strip():
            return v.strip()
    return ""


def _read_state_file(path: Path) -> Dict[str, Any]:
    try:
        if not path.exists():
            return {}
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.debug("autoregister: failed to read state file %s: %s", path, exc)
        return {}


def _load_sidecar_state() -> Dict[str, Any]:
    """
    Load the bind-sidecar state file, if any.
    Search: CWD → up to 3 parent dirs → /tmp.  First non-empty file wins.
    """
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        for name in STATE_FILE_BASENAMES:
            p = parent / name
            if p.exists():
                state = _read_state_file(p)
                if state:
                    return state
        if len(parent.parts) <= 1 or str(parent) in ("/", "C:\\"):
            break
    import tempfile
    tmp = Path(tempfile.gettempdir()) / "puvi_bind_state.json"
    if tmp.exists():
        state = _read_state_file(tmp)
        if state:
            return state
    return {}


def _should_fail_loudly() -> bool:
    """
    Fix 6: Return True when the environment opts into hard-fail mode.
    PUVINOISE_STRICT=1 → raise/exit on any registration failure.
    Default is False (fail-open) to protect host agent processes.
    """
    return os.environ.get("PUVINOISE_STRICT", "").strip() in ("1", "true", "yes")


def _print_registration_failure(code: str, detail: str) -> None:
    """
    Fix 6: Always emit a visible, actionable error to stderr.
    Does NOT exit by itself — callers decide whether to raise based on
    _should_fail_loudly() or raise_on_error.
    """
    sys.stderr.write(
        f"\n[puvinoise] ✗ Agent registration FAILED  (code={code})\n"
        f"  {detail}\n"
        f"  • To skip registration entirely:  set PUVINOISE_AUTOREGISTER=0\n"
        f"  • To treat this as a fatal error: set PUVINOISE_STRICT=1\n"
        f"  • Docs: https://docs.puvinoise.ai/sdk/autoregister\n\n"
    )
    sys.stderr.flush()


# ─── Public resolution API (Fix 5) ────────────────────────────────────────────

def resolve_env_id_with_source() -> Tuple[str, str]:
    """
    Fix 5: Resolve the environment id AND return a human-readable source label.

    Returns (env_id, source) where source is one of:
      "env_var:<VAR_NAME>"       — found in an environment variable
      "sidecar_state_file:<path>" — found in a sidecar-written state file
      "not_found"                — nothing available

    Callers should log / print this so developers know exactly where
    env_id came from.
    """
    for k in ENV_ID_KEYS:
        v = os.environ.get(k, "").strip()
        if v:
            return v, f"env_var:{k}"
    # State file fallback
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        for name in STATE_FILE_BASENAMES:
            p = parent / name
            if p.exists():
                state = _read_state_file(p)
                val = state.get("env_id")
                if val:
                    return str(val).strip(), f"sidecar_state_file:{p}"
        if len(parent.parts) <= 1 or str(parent) in ("/", "C:\\"):
            break
    import tempfile
    tmp = Path(tempfile.gettempdir()) / "puvi_bind_state.json"
    if tmp.exists():
        state = _read_state_file(tmp)
        val = state.get("env_id")
        if val:
            return str(val).strip(), f"sidecar_state_file:{tmp}"
    return "", "not_found"


def resolve_env_id() -> str:
    """Convenience wrapper — returns only the env_id string."""
    env_id, _ = resolve_env_id_with_source()
    return env_id


def resolve_platform_url() -> str:
    url = get_base_url()
    if url:
        return url.rstrip("/")
    state = _load_sidecar_state()
    val = state.get("base_url")
    return str(val).rstrip("/") if val else ""


def resolve_api_key() -> str:
    """Agent API key comes only from ``PUVINOISE_API_KEY`` (e.g. project ``.env``)."""
    return get_api_key()


def _canonical_agent_id_for_registration(explicit: Optional[str]) -> str:
    """Only ``agt_*`` ids are sent as ``agentId`` — avoids creating duplicate agents from display names."""
    raw = (explicit or get_agent_id() or "").strip()
    if raw.startswith("agt_"):
        return raw
    return ""


def _persist_canonical_agent_id(agent_id: str) -> None:
    """
    Merge canonical id into the nearest ``.puvinoise_env.json`` (cwd → parents), or create one
    when env_id + base_url are known so the next ``puvinoise run`` reuses the same agent.
    """
    aid = (agent_id or "").strip()
    if not aid.startswith("agt_"):
        return
    env_id = (os.environ.get("PUVINOISE_ENV_ID") or "").strip()
    base = (os.environ.get("PUVINOISE_BASE_URL") or "").strip().rstrip("/")

    def _write(path: Path) -> None:
        try:
            data: Dict[str, Any] = {}
            if path.is_file():
                try:
                    raw = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(raw, dict):
                        data = raw
                except Exception:  # noqa: BLE001
                    data = {}
            data["agent_id"] = aid
            if env_id:
                data["env_id"] = env_id
            if base:
                data["base_url"] = base
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            try:
                os.chmod(path, 0o600)
            except Exception:  # noqa: BLE001
                pass
        except Exception as exc:  # noqa: BLE001
            logger.debug("autoregister: could not persist agent_id to %s: %s", path, exc)

    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        p = parent / ".puvinoise_env.json"
        if p.is_file():
            _write(p)
            return
        if len(parent.parts) <= 1 or str(parent) in ("/", "C:\\"):
            break
    if env_id and base:
        _write(cwd / ".puvinoise_env.json")


# ─── Contract YAML helpers ────────────────────────────────────────────────────

def _find_contract_yaml_path() -> Optional[Path]:
    """
    Search cwd → parent dirs for puvinoise-agent.yaml.
    Returns the Path if found, or None.
    """
    cwd = Path.cwd()
    for parent in [cwd] + list(cwd.parents):
        p = parent / PUVINOISE_AGENT_YAML_FILENAME
        if p.exists():
            return p
        if len(parent.parts) <= 1 or str(parent) in ("/", "C:\\"):
            break
    return None


def _load_contract_from_file() -> Optional[Dict[str, Any]]:
    """
    Load puvinoise-agent.yaml from the agent directory and return a minimal
    contract dict suitable for the registration payload.

    Only the inferrable + policy fields are extracted:
      intentType, trustBoundary, allowedTools, outOfScope, fallbackStrategy.

    Returns None if the file is not found or cannot be parsed.
    """
    yaml_path = _find_contract_yaml_path()
    if yaml_path is None:
        return None
    try:
        content = yaml_path.read_text(encoding="utf-8")
        # Minimal YAML parser for the subset of fields we need
        # (avoids a hard dependency on PyYAML at init time)
        contract: Dict[str, Any] = {}
        capability = _parse_yaml_section(content, "capability")
        safety = _parse_yaml_section(content, "safety")

        if capability:
            it = capability.get("intent_type")
            tb = capability.get("trust_boundary")
            tools = capability.get("allowed_tools")
            if it:
                contract["intentType"] = it
            if tb:
                contract["trustBoundary"] = tb
            if isinstance(tools, list):
                contract["allowedTools"] = [str(t).strip('"\'') for t in tools if t]
        if safety:
            oos = safety.get("out_of_scope")
            fs = safety.get("fallback_strategy")
            if isinstance(oos, list) and oos:
                contract["outOfScope"] = [str(s).strip('"\'') for s in oos if s]
            if fs and str(fs).strip():
                contract["fallbackStrategy"] = str(fs).strip('"\'')

        return contract if contract else None
    except Exception as exc:  # noqa: BLE001
        logger.debug("autoregister: failed to load %s: %s", yaml_path, exc)
        return None


def _parse_yaml_section(content: str, section: str) -> Dict[str, Any]:
    """
    Ultra-minimal single-level YAML section parser.
    Handles:  key: value  and  - "value" list items inside a named block.
    NOT a general YAML parser — only for known puvinoise-agent.yaml structure.
    """
    lines = content.splitlines()
    in_section = False
    result: Dict[str, Any] = {}
    current_list_key: Optional[str] = None

    for line in lines:
        stripped = line.rstrip()
        # Detect section header (zero-indent key)
        if stripped.startswith(f"{section}:"):
            in_section = True
            continue
        # Exit section on next zero-indent key
        if in_section and stripped and stripped[0] not in (" ", "\t", "#", "-") and ":" in stripped:
            break
        if not in_section:
            continue
        # Skip comments
        if stripped.lstrip().startswith("#"):
            continue
        # List item
        if stripped.lstrip().startswith("- "):
            if current_list_key:
                val = stripped.lstrip()[2:].strip().strip('"\'')
                if val:
                    result.setdefault(current_list_key, []).append(val)
            continue
        # key: value pair (indented)
        if ":" in stripped:
            indent = len(stripped) - len(stripped.lstrip())
            if indent > 0:
                key, _, value = stripped.lstrip().partition(":")
                key = key.strip()
                value = value.strip().strip('"\'')
                if value:
                    result[key] = value
                    current_list_key = None
                else:
                    # Possible list coming next
                    current_list_key = key
    return result


def _write_contract_file(content: str, target_path: Optional[str] = None) -> bool:
    """
    Write the puvinoise-agent.yaml content to the agent directory.

    Called when PUVINoise sends a WRITE_CONTRACT_FILE control command.
    Writes to:
      1. target_path if explicitly provided
      2. Existing puvinoise-agent.yaml location (if already present)
      3. CWD/puvinoise-agent.yaml (fallback)

    Returns True on success, False on failure.
    """
    try:
        if target_path:
            dest = Path(target_path)
        else:
            existing = _find_contract_yaml_path()
            dest = existing if existing else (Path.cwd() / PUVINOISE_AGENT_YAML_FILENAME)

        dest.write_text(content, encoding="utf-8")
        try:
            os.chmod(dest, 0o644)
        except Exception:  # noqa: BLE001
            pass
        logger.info("autoregister: contract YAML written to %s", dest)
        sys.stderr.write(f"[puvinoise] ✓ Contract file written: {dest}\n")
        sys.stderr.flush()
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("autoregister: failed to write contract YAML: %s", exc)
        return False


def handle_write_contract_command(command: Dict[str, Any]) -> bool:
    """
    Handle a WRITE_CONTRACT_FILE control command from the PUVINoise platform.

    Expected command shape:
      {
        "commandType": "WRITE_CONTRACT_FILE",
        "payload": {
          "content":     "<yaml string>",
          "target_path": "<optional absolute path>"
        }
      }

    Returns True if the file was written successfully.
    """
    payload = command.get("payload") or {}
    content = payload.get("content", "")
    target  = payload.get("target_path") or None

    if not content:
        logger.warning("autoregister: WRITE_CONTRACT_FILE command missing content")
        return False

    return _write_contract_file(content, target)


def get_contract_tier() -> str:
    """Return the last-known contract tier for this agent process."""
    return _CONTRACT_TIER


# ─── Runtime metadata ─────────────────────────────────────────────────────────

def _detect_sdk_version() -> str:
    v = env_var("PUVINOISE_SDK_VERSION")
    if v:
        return v
    try:
        from importlib.metadata import version  # type: ignore
        return str(version("puvinoise-sdk"))
    except Exception:  # noqa: BLE001
        pass
    try:
        import puvinoise  # noqa: WPS433
        v = getattr(puvinoise, "__version__", None)
        if v:
            return str(v)
    except Exception:  # noqa: BLE001
        pass
    return "unknown"


def _detect_runtime() -> str:
    return f"python-{platform.python_version()}"


def _detect_entrypoint() -> str:
    try:
        if sys.argv and sys.argv[0]:
            return os.path.basename(sys.argv[0])
    except Exception:  # noqa: BLE001
        pass
    try:
        import __main__  # type: ignore
        f = getattr(__main__, "__file__", None)
        if f:
            return os.path.basename(str(f))
    except Exception:  # noqa: BLE001
        pass
    return "python"


def collect_runtime_metadata(extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build the runtime_metadata dict the backend expects. Always includes
    sdk_version and runtime (the proof-of-SDK markers enforced in Phase D)."""
    meta: Dict[str, Any] = {
        "sdk_language": "python",
        "sdk_version": _detect_sdk_version(),
        "runtime": _detect_runtime(),
        "entrypoint": _detect_entrypoint(),
        "pid": os.getpid(),
        "host": socket.gethostname(),
        "contract_version": AUTOREGISTER_CONTRACT_VERSION,
        # Fix 7: advertise init mode so the backend can distinguish CLI vs manual
        "init_mode": _INIT_MODE,
    }
    for meta_key, env_key in (
        ("deploy_env", "PUVINOISE_DEPLOY_ENV"),
        ("deploy_version", "PUVINOISE_DEPLOY_VERSION"),
        ("region", "PUVINOISE_REGION"),
        ("instance_id", "PUVINOISE_INSTANCE_ID"),
        ("agent_name", "PUVINOISE_AGENT_NAME"),
        ("framework", "PUVINOISE_FRAMEWORK"),
        ("detection_mode", "PUVINOISE_DETECTION_MODE"),
        ("behavior_classification", "PUVINOISE_BEHAVIOR_CLASSIFICATION"),
        ("behavior_confidence", "PUVINOISE_BEHAVIOR_CONFIDENCE"),
    ):
        v = env_var(env_key)
        if v:
            meta[meta_key] = v
    if extra and isinstance(extra, dict):
        for k, v in extra.items():
            if v is not None:
                meta[k] = v
    return meta


# ─── HTTP helper ──────────────────────────────────────────────────────────────

def _post_json(
    url: str,
    payload: Dict[str, Any],
    bearer: Optional[str] = None,
    timeout: int = 15,
) -> Tuple[int, Dict[str, Any]]:
    """Minimal urllib POST — returns (status, json body). Never raises on HTTP
    errors; the caller decides whether to treat them as fatal."""
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
        req.add_header("X-Api-Key", bearer)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            body = json.loads(raw) if raw.strip() else {}
            return resp.getcode(), body
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""
        try:
            body = json.loads(raw) if raw.strip() else {}
        except Exception:  # noqa: BLE001
            body = {"error": raw}
        return e.code, body
    except urllib.error.URLError as e:
        return 0, {"error": f"network error: {e.reason}"}


# ─── Public registration API ──────────────────────────────────────────────────

def register_agent(
    *,
    agent_name: Optional[str] = None,
    agent_id: Optional[str] = None,
    env_id: Optional[str] = None,
    platform_url: Optional[str] = None,
    api_key: Optional[str] = None,
    runtime_metadata_extra: Optional[Dict[str, Any]] = None,
    contract: Optional[Dict[str, Any]] = None,
    timeout: int = 15,
) -> Dict[str, Any]:
    """
    STRICT registration: raises AutoRegisterError on any failure.
    Returns the server's JSON response on success.
    Does NOT check _REGISTERED_IN_PROCESS — that guard is in auto_register_from_env().
    """
    env_id = (env_id or resolve_env_id()).strip()
    if not env_id:
        raise EnvIdMissingError(
            "env_id is missing. Set PUVINOISE_ENV_ID in the agent environment, "
            "or run the bind-sidecar so it writes .puvinoise_env.json (env_id). "
            "Phase D: agent registration without an environment is not permitted."
        )

    platform_url = (platform_url or resolve_platform_url()).strip().rstrip("/")
    if not platform_url:
        raise AutoRegisterError(
            "platform_url is missing. Set PUVINOISE_BASE_URL to the control-plane origin "
            "(e.g. https://app.example.com)."
        )

    api_key = (api_key or resolve_api_key()).strip()
    if not api_key:
        raise AutoRegisterError(
            "api_key is missing. Set PUVINOISE_API_KEY in the agent environment "
            "(for example in the project .env). The minimal .puvinoise_env.json does not store credentials."
        )

    name = (agent_name or get_agent_name() or "").strip()
    if not name:
        raise AutoRegisterError(
            "agent_name is missing. Pass agent_name=... to puvinoise.init() or set PUVINOISE_AGENT_NAME."
        )

    try:
        from puvinoise.framework_detection import sync_framework_env_from_runtime

        sync_framework_env_from_runtime()
    except Exception:  # noqa: BLE001
        pass

    runtime_metadata = collect_runtime_metadata(runtime_metadata_extra)
    runtime_metadata["env_id"] = env_id

    payload: Dict[str, Any] = {
        "agentName": name,
        "env_id": env_id,
        "runtime_metadata": runtime_metadata,
        "framework": env_var("PUVINOISE_FRAMEWORK") or "sdk-auto",
        "environment": runtime_metadata.get("deploy_env") or None,
        "version": runtime_metadata.get("deploy_version") or None,
    }
    cid = _canonical_agent_id_for_registration(agent_id)
    if cid:
        payload["agentId"] = cid

    # Attach contract if provided explicitly, or try loading from puvinoise-agent.yaml
    effective_contract = contract
    if effective_contract is None:
        effective_contract = _load_contract_from_file()
    if effective_contract:
        payload["contract"] = effective_contract

    payload = {k: v for k, v in payload.items() if v is not None}

    url = f"{platform_url}/api/agent-register"
    status, body = _post_json(url, payload, bearer=api_key, timeout=timeout)

    if 200 <= status < 300:
        global _CONTRACT_TIER
        returned = ""
        if isinstance(body, dict):
            ag = body.get("agent")
            if isinstance(ag, dict):
                returned = str(ag.get("agentId") or ag.get("agent_id") or "").strip()
                # Surface contract tier so the SDK can log and expose it
                _CONTRACT_TIER = str(ag.get("contractTier") or "unknown")
        if returned.startswith("agt_"):
            os.environ["PUVINOISE_AGENT_ID"] = returned
            _persist_canonical_agent_id(returned)

        # Log contract tier to stderr so developers see it at startup
        tier_label = {
            "unknown":    "⚠️  unknown  — PUVINoise is learning this agent",
            "incomplete": "🔍 incomplete — contract partially inferred, monitoring active",
            "defined":    "✅ defined   — full contract active, all intelligence enabled",
        }.get(_CONTRACT_TIER, _CONTRACT_TIER)
        sys.stderr.write(f"[puvinoise] Contract tier: {tier_label}\n")
        sys.stderr.flush()

        logger.info("autoregister: agent=%s env_id=%s contractTier=%s → OK (%s)", name, env_id, _CONTRACT_TIER, status)
        return body

    code = None
    if isinstance(body, dict):
        code = body.get("code")
    raise BackendRejectedError(status=status, code=code, body=body)


def auto_register_from_env(
    *,
    agent_name: Optional[str] = None,
    agent_id: Optional[str] = None,
    runtime_metadata_extra: Optional[Dict[str, Any]] = None,
    contract: Optional[Dict[str, Any]] = None,
    timeout: int = 15,
    raise_on_error: bool = False,
) -> Optional[Dict[str, Any]]:
    """
    LENIENT entrypoint called from puvinoise.init().

    Hardening fixes applied here:
      Fix 1: Guard against duplicate registrations in the same process.
      Fix 5: Log exactly where env_id was resolved from.
      Fix 6: Emit a visible error on every failure; respect PUVINOISE_STRICT=1.
      Fix 7: Set _INIT_MODE based on PUVINOISE_RUNTIME_DRIVEN.

    Opt-out: PUVINOISE_AUTOREGISTER=0 → no-op.
    Hard-fail: PUVINOISE_STRICT=1 → raises on any failure.
    """
    global _REGISTERED_IN_PROCESS, _INIT_MODE

    # Fix 1: Process-level duplicate guard.
    # When `puvinoise run` injects the SDK via sitecustomize AND the user's
    # code also calls puvinoise.init(), the second call is a no-op.
    if _REGISTERED_IN_PROCESS:
        logger.debug(
            "autoregister: already registered in this process — skipping duplicate call "
            "(init_mode=%s)", _INIT_MODE
        )
        return None

    # Fix 7: Record init mode for metadata and diagnostics.
    is_cli_driven = os.environ.get("PUVINOISE_RUNTIME_DRIVEN", "").strip() in ("1", "true", "yes")
    _INIT_MODE = "cli" if is_cli_driven else "manual"

    # Opt-out check.
    opt = os.environ.get("PUVINOISE_AUTOREGISTER", "1").strip()
    if opt in ("0", "false", "no"):
        logger.info("autoregister: disabled via PUVINOISE_AUTOREGISTER=0")
        return None

    # Fix 5: Resolve and log env_id source before any network call.
    env_id_val, env_id_source = resolve_env_id_with_source()
    if env_id_val:
        _log_env_id_source(env_id_val, env_id_source)

    try:
        result = register_agent(
            agent_name=agent_name,
            agent_id=agent_id,
            runtime_metadata_extra=runtime_metadata_extra,
            contract=contract,
            timeout=timeout,
        )
        # Fix 1: Mark this process as registered so subsequent calls skip.
        _REGISTERED_IN_PROCESS = True
        return result

    except EnvIdMissingError as exc:
        _print_registration_failure("ENV_ID_MISSING", str(exc))
        logger.warning("autoregister: env_id missing — %s", exc)
        if raise_on_error or _should_fail_loudly():
            raise
        return None

    except BackendRejectedError as exc:
        _print_registration_failure(
            exc.code or "BACKEND_REJECTED",
            f"HTTP {exc.status} — {exc.body}",
        )
        logger.warning(
            "autoregister: backend rejected registration (HTTP %s code=%r): %s",
            exc.status, exc.code, exc.body,
        )
        if raise_on_error or _should_fail_loudly():
            raise
        return None

    except Exception as exc:  # noqa: BLE001
        _print_registration_failure("UNEXPECTED", str(exc))
        logger.warning("autoregister: unexpected failure: %s", exc)
        if raise_on_error or _should_fail_loudly():
            raise
        return None


def _log_env_id_source(env_id: str, source: str) -> None:
    """Fix 5: Emit env_id source to both the logger and stderr for visibility."""
    msg = f"[puvinoise] Using env_id={env_id} (source: {source})"
    logger.info("autoregister: %s", msg)
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()


# ─── Heartbeat loop (Fix 3) ───────────────────────────────────────────────────

_heartbeat_thread: Optional[threading.Thread] = None
_heartbeat_stop = threading.Event()


def _poll_control_plane_if_embedded() -> None:
    """
    When PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT=1, the control worker does not use its own thread;
    run one GET /api/agent-control cycle after each heartbeat POST.
    """
    v = os.environ.get("PUVINOISE_CONTROL_POLL_VIA_HEARTBEAT", "").strip().lower()
    if v not in ("1", "true", "yes", "on"):
        return
    try:
        from puvinoise.bootstrap import get_control_worker
    except Exception:
        return
    w = get_control_worker()
    if w is None:
        return
    poll_once = getattr(w, "poll_once", None)
    if callable(poll_once):
        poll_once()


def _heartbeat_once(platform_url: str, api_key: str, agent_id: str) -> Tuple[int, Dict[str, Any]]:
    url = f"{platform_url.rstrip('/')}/api/agent-heartbeat"
    try:
        from puvinoise.framework_detection import sync_framework_env_from_runtime

        sync_framework_env_from_runtime()
    except Exception:  # noqa: BLE001
        pass
    payload: Dict[str, Any] = {
        "agentId": agent_id,
        "timestamp": int(time.time()),
        "source": "sdk-autoregister",
        "pid": os.getpid(),
    }
    hb_behavior = os.environ.get("PUVINOISE_HEARTBEAT_BEHAVIOR", "1").strip().lower() not in (
        "0",
        "false",
        "no",
    )
    bc = env_var("PUVINOISE_BEHAVIOR_CLASSIFICATION")
    bf = env_var("PUVINOISE_BEHAVIOR_CONFIDENCE")
    if hb_behavior and bc and bc != "unknown":
        payload["behavior_classification"] = bc
        payload["behavior_confidence"] = bf or "low"
    return _post_json(url, payload, bearer=api_key, timeout=10)


def start_heartbeat_loop(
    *,
    agent_id: Optional[str] = None,
    interval_seconds: int = 15,
) -> bool:
    """
    Start a background heartbeat thread.

    Fix 3 hardening:
      • Singleton: a second call while the thread is alive is a no-op.
      • atexit.register(stop_heartbeat_loop) is registered exactly once per
        process so the loop is always cleaned up at interpreter shutdown, even
        in long-lived processes (notebooks, daemons).
    """
    global _heartbeat_thread, _ATEXIT_REGISTERED

    # Singleton guard.
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        logger.debug("autoregister: heartbeat already running — ignoring duplicate start")
        return True

    platform_url = resolve_platform_url()
    api_key = resolve_api_key()
    aid = (agent_id or get_agent_id() or get_agent_name()).strip()
    if not platform_url or not api_key or not aid:
        logger.info(
            "autoregister: heartbeat not started — missing platform_url/api_key/agent_id"
        )
        return False

    def _loop() -> None:
        while not _heartbeat_stop.wait(interval_seconds):
            try:
                _heartbeat_once(platform_url, api_key, aid)
            except Exception as exc:  # noqa: BLE001
                logger.debug("autoregister: heartbeat failed (non-fatal): %s", exc)
            try:
                _poll_control_plane_if_embedded()
            except Exception as exc:  # noqa: BLE001
                logger.debug("autoregister: control poll (heartbeat-driven) failed (non-fatal): %s", exc)

    _heartbeat_stop.clear()
    t = threading.Thread(
        target=_loop,
        name="puvi-autoregister-heartbeat",
        daemon=True,
    )
    t.start()
    _heartbeat_thread = t
    logger.info("autoregister: heartbeat loop started (interval=%ss)", interval_seconds)

    # Fix 3: Register atexit cleanup exactly once.
    if not _ATEXIT_REGISTERED:
        atexit.register(stop_heartbeat_loop)
        _ATEXIT_REGISTERED = True
        logger.debug("autoregister: atexit cleanup registered")

    return True


def stop_heartbeat_loop() -> None:
    """Signal the heartbeat loop to exit. Safe to call if no loop is running."""
    _heartbeat_stop.set()


__all__ = [
    "AUTOREGISTER_CONTRACT_VERSION",
    "PUVINOISE_AGENT_YAML_FILENAME",
    "AutoRegisterError",
    "EnvIdMissingError",
    "BackendRejectedError",
    "resolve_env_id",
    "resolve_env_id_with_source",
    "resolve_platform_url",
    "resolve_api_key",
    "collect_runtime_metadata",
    "register_agent",
    "auto_register_from_env",
    "start_heartbeat_loop",
    "stop_heartbeat_loop",
    # Contract helpers
    "handle_write_contract_command",
    "get_contract_tier",
    "_load_contract_from_file",
    "_write_contract_file",
    # Process-state (read-only by external callers)
    "_REGISTERED_IN_PROCESS",
    "_INIT_MODE",
    "_CONTRACT_TIER",
]
