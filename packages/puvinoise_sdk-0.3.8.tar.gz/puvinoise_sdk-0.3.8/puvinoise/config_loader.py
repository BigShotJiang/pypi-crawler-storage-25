"""
PUVINoise config_loader — replaces manually managed .env files.

Fetches the authoritative bootstrap config from the PUVINoise platform
and applies it to os.environ before bootstrap() / init() runs.

IMPORTANT — two version fields the platform manages separately:
  agentDeployVersion → applied to PUVINOISE_DEPLOY_VERSION
                       this is YOUR agent's code version (e.g. "1.4.0")
                       changes every time you deploy a new agent version
  sdkVersion         → NEVER set by this loader
                       the PUVINoise SDK reads its own version from package
                       metadata automatically (puvinoise.__version__)
                       you never need to set this manually

Minimal usage:
    from puvinoise.config_loader import load_platform_config
    load_platform_config(
        api_key="your-agent-access-key",
        agent_id="your-agent-name",
        platform_url="https://your-puvinoise-platform.com",
    )
    import puvinoise
    puvinoise.init()

On rollback: the platform returns the previousAgentDeployVersion as the
active agentDeployVersion. PUVINOISE_DEPLOY_VERSION is set to the rolled-back
version automatically. A warning is logged.
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Optional

logger = logging.getLogger(__name__)

_loaded_config: Optional[dict] = None
_load_attempted: bool = False
_loaded_at: Optional[float] = None


def load_platform_config(
    api_key: Optional[str] = None,
    agent_id: Optional[str] = None,
    platform_url: Optional[str] = None,
    timeout_s: int = 10,
    fail_silently: bool = True,
) -> dict:
  """
  Fetch bootstrap config from PUVINoise and apply to os.environ.

  Parameters
  ----------
  api_key      : Agent access key. Falls back to PUVINOISE_API_KEY.
  agent_id     : Agent name. Falls back to PUVINOISE_AGENT_NAME.
  platform_url : PUVINoise platform base URL. Falls back to PUVINOISE_BASE_URL.
  timeout_s    : HTTP timeout. Default 10s.
  fail_silently: If True, log warning and continue on fetch failure (recommended).
                 If False, raise RuntimeError on failure.
  """
  global _loaded_config, _load_attempted
  # Simple TTL so long-lived agents can refresh config periodically without restart.
  ttl_s = int(os.environ.get("PUVINOISE_CONFIG_TTL_SECONDS", "300") or "300")
  now = time.time()
  global _loaded_at
  if _loaded_config is not None and _loaded_at is not None and now - _loaded_at < ttl_s:
    return _loaded_config
  _load_attempted = True

  resolved_key = (api_key or os.environ.get("PUVINOISE_API_KEY", "")).strip()
  resolved_agent_id = (agent_id or os.environ.get("PUVINOISE_AGENT_NAME", "")).strip()
  resolved_url = (
    platform_url
    or os.environ.get("PUVINOISE_BASE_URL", "")
  ).strip().rstrip("/")

  if not all([resolved_key, resolved_agent_id, resolved_url]):
    msg = "load_platform_config: api_key, agent_id, and platform_url are required."
    if fail_silently:
      logger.warning(msg + " Falling back to existing environment variables.")
      return {}
    raise ValueError(msg)

  headers = {
    "X-Api-Key": resolved_key,
    "X-Organization-Id": (
      os.environ.get("PUVINOISE_ORGANIZATION_ID")
      or os.environ.get("PUVINOISE_TENANTID", "")
    ),
    "X-Project-Id": os.environ.get("PUVINOISE_PROJECT_ID", ""),
    "X-Environment": (
      os.environ.get("PUVINOISE_ENVIRONMENT")
      or os.environ.get("PUVINOISE_DEPLOY_ENV", "")
    ),
    "X-PUVI-Agent-Id": resolved_agent_id,
    "Content-Type": "application/json",
    "User-Agent": f"puvinoise-config-loader/{_get_sdk_version()}",
  }
  query = urllib.parse.urlencode({"agentId": resolved_agent_id})
  candidate_urls = [
    f"{resolved_url}/api/agent/config?{query}",
    f"{resolved_url}/api/agent-config/{urllib.parse.quote(resolved_agent_id, safe='')}",
  ]

  try:
    t0 = time.time()
    config = None
    last_error = None
    selected_url = candidate_urls[0]
    for candidate in candidate_urls:
      req = urllib.request.Request(candidate, headers=headers)
      try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
          config = json.loads(resp.read().decode("utf-8"))
          selected_url = candidate
          break
      except urllib.error.HTTPError as exc:
        last_error = exc
        # New servers expose /api/agent/config; older servers may only have /api/agent-config/:id.
        if exc.code == 404:
          continue
        raise
    if config is None:
      raise last_error or RuntimeError("No config endpoint available")
    logger.info(
      "PUVINoise config loaded in %.0fms | endpoint=%s agent=%s env=%s "
      "agent_deploy_version=%s sdk_version=%s deployment_status=%s",
      (time.time() - t0) * 1000,
      selected_url,
      resolved_agent_id,
      config.get("environment"),
      config.get("agentDeployVersion"),  # agent code version
      config.get("sdkVersion"),  # puvinoise sdk version (informational only)
      config.get("deploymentStatus"),
    )
  except Exception as exc:
    msg = (
      "load_platform_config: fetch failed from "
      f"{candidate_urls[0]} (and legacy fallback): {exc}"
    )
    if fail_silently:
      logger.warning(msg + " — using existing environment variables.")
      return {}
    raise RuntimeError(msg) from exc

  _apply_to_env(resolved_key, resolved_agent_id, resolved_url, config)
  _loaded_config = config
  _loaded_at = now
  return config


def _apply_to_env(api_key: str, agent_id: str, platform_url: str, config: dict) -> None:
  """
  Apply platform config to os.environ.

  Fields applied:
    PUVINOISE_API_KEY                 — agent access key
    PUVINOISE_AGENT_NAME                — agent name
    PUVINOISE_BASE_URL                  — platform base URL
    PUVINOISE_TENANTID                       — tenant ID
    DEPLOYMENT_ENV                           — environment slug
    PUVINOISE_DEPLOY_VERSION                      — AGENT deploy version (not SDK version)

  Fields intentionally NOT set:
    PUVINOISE_SDK_VERSION / puvinoise.sdk.version — SDK reads its own version
                                               from package metadata automatically.
                                               Never set this from external config.
  """

  def _set(key: str, value: str) -> None:
    if value is None:
      return
    v = str(value).strip()
    if not v:
      return
    os.environ[key] = v

  _set("PUVINOISE_API_KEY", api_key)
  _set("PUVINOISE_AGENT_NAME", agent_id)
  _pb = config.get("platformBaseUrl", platform_url)
  if _pb:
    _u = str(_pb).strip().rstrip("/")
    if _u.endswith("/v1/traces"):
      _u = _u[: -len("/v1/traces")].rstrip("/")
    _set("PUVINOISE_BASE_URL", _u)

  tenant_id = config.get("tenantId", "")
  if tenant_id and tenant_id.lower() != "your-tenant-id":
    _set("PUVINOISE_TENANTID", tenant_id)

  environment = config.get("environmentSlug") or config.get("environment", "")
  if environment:
    _set("DEPLOYMENT_ENV", environment)

  # PUVINOISE_DEPLOY_VERSION = agent deploy version (your agent code, e.g. "1.4.0")
  # On rollback: platform already returns previousAgentDeployVersion as
  # agentDeployVersion — so this always sets the correct active version.
  agent_deploy_version = config.get("agentDeployVersion", "")
  if agent_deploy_version:
    _set("PUVINOISE_DEPLOY_VERSION", agent_deploy_version)

  # Log deployment state warnings
  status = config.get("deploymentStatus", "")
  if status == "rolled_back":
    logger.warning(
      "PUVINoise: agent '%s' is in ROLLED_BACK state. "
      "Active agent deploy version: %s (was: %s). "
      "Check the PUVINoise dashboard.",
      agent_id,
      agent_deploy_version or "unknown",
      config.get("previousAgentDeployVersion", "unknown"),
    )
  elif status == "idle":
    logger.info(
      "PUVINoise: agent '%s' has no active deployment. "
      "Telemetry will be collected but PUVINOISE_DEPLOY_VERSION is unset.",
      agent_id,
    )


def get_loaded_config() -> Optional[dict]:
  return _loaded_config


def reset_for_testing() -> None:
  global _loaded_config, _load_attempted, _loaded_at
  _loaded_config = None
  _load_attempted = False
  _loaded_at = None


def _get_sdk_version() -> str:
  try:
    from puvinoise import __version__

    return str(__version__)
  except Exception:
    return "0.0.0"

