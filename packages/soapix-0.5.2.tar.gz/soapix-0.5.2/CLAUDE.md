# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Run all tests with coverage
pytest --cov=soapix --cov-report=term-missing

# Run a single test file
pytest tests/test_xml_builder.py

# Run a single test by name
pytest tests/test_xml_builder.py::test_function_name -k "keyword"

# Type checking
mypy soapix

# Lint / format
ruff check soapix
ruff format soapix

# Build package
make build

# CLI usage
python -m soapix generate <wsdl_url> [-o output.py]
```

## Architecture

Soapix is a SOAP client library with a layered pipeline. Data flows top-down through these layers:

```
SoapClient / AsyncSoapClient   (client.py)
    ↓  fetch operation metadata
WsdlParser + WsdlDocument      (wsdl/)
    ↓  build envelope
SoapBuilder                    (xml/builder.py)
    ↓  HTTP POST
Transport / AsyncTransport     (transport.py)
    ↓  parse response
SoapResponseParser             (xml/parser.py)
    ↓  optional cache
MemoryCache / FileCache        (cache.py)
```

**WSDL layer** (`wsdl/`): `WsdlParser` loads a WSDL URL/file, resolves `xs:import`/`xs:include` chains via `ImportResolver`, and produces a `WsdlDocument` (operations, types, services). `namespace.py` provides tolerant namespace matching (ignores trailing slashes, case, fragments).

**XML layer** (`xml/`): `SoapBuilder` serializes Python dicts → SOAP envelopes (document/literal and RPC/literal styles). `SoapResponseParser` deserializes responses → Python dicts and raises `SoapFaultError` on SOAP faults.

**Client layer** (`client.py`): Uses a `_ServiceProxy` so callers write `client.service.OperationName(**kwargs)`. The proxy calls `_call()` internally. `AsyncSoapClient` mirrors `SoapClient` using `async/await` and an async context manager.

**Auxiliary services** (not in the call path):
- `docs/` — renders operation docs to terminal, Markdown, or HTML
- `codegen/` — generates a typed Python dataclass client from WSDL
- `playground/` — local HTTP server + embedded HTML/JS UI for interactive testing; runs on `localhost:8765`

## Key Design Decisions

**Tolerant by default.** Missing required fields are serialized as `xsi:nil` instead of raising an error. Pass `strict=True` to get `SerializationError` on missing required fields.

**Namespace matching is fuzzy.** `normalize_namespace()` strips trailing slashes and ignores case/fragments so real-world WSDL files that deviate slightly from spec still work.

**Shared cache.** A module-level `MemoryCache` (TTL 300s, max 64 entries) is reused across client instances. Pass a `FileCache` for persistent caching across processes.

**Retry strategy.** Transport retries on 5xx responses that are not SOAP faults, and on connection/timeout errors. 4xx, SSL errors, and actual SOAP faults are not retried.

## Exception Hierarchy

```
SoapixError
├── WsdlParseError
│   ├── WsdlNotFoundError
│   └── WsdlImportError
├── SoapCallError
│   ├── SoapFaultError    ← SOAP fault from server
│   ├── HttpError
│   └── TimeoutError
└── SerializationError
```

## Tests

Tests live in `tests/` with 35 WSDL fixtures in `tests/fixtures/`. pytest-httpx is used to mock HTTP calls in transport and parser tests. The async mode is set to `auto` in pytest config.
