from __future__ import annotations

import enum

from fastapi import HTTPException, status


class EnterpriseRole(str, enum.Enum):
    platform_admin = "PlatformAdmin"
    tenant_admin = "TenantAdmin"
    qa_manager = "QA Manager"
    qa_test_lead = "QA Test Lead"
    qa_engineer = "QA Engineer"


class Resource(str, enum.Enum):
    projects = "Projects"
    workspaces = "Workspaces"
    user_stories = "User Stories"
    test_cases = "Test Cases"
    test_scripts = "Test Scripts"
    execute_tests = "Execute Tests"
    metrics_dashboards = "Metrics and Dashboards"
    user_management = "User Management"
    tenant_management = "Tenant Management"


class Action(str, enum.Enum):
    create = "create"
    read = "read"
    update = "update"
    delete = "delete"
    execute = "execute"
    manage = "manage"


CRUD = {Action.create, Action.read, Action.update, Action.delete}


ROLE_CAPABILITY_MATRIX: dict[EnterpriseRole, dict[Resource, set[Action]]] = {
    EnterpriseRole.platform_admin: {
        resource: set(CRUD | {Action.execute, Action.manage}) for resource in Resource
    },
    EnterpriseRole.tenant_admin: {
        Resource.projects: set(CRUD),
        Resource.workspaces: set(CRUD),
        Resource.user_stories: set(CRUD),
        Resource.test_cases: set(CRUD),
        Resource.test_scripts: set(CRUD),
        Resource.execute_tests: {Action.read, Action.execute},
        Resource.metrics_dashboards: {Action.read, Action.manage},
        Resource.user_management: {Action.read, Action.manage},
        Resource.tenant_management: {Action.read, Action.manage},
    },
    EnterpriseRole.qa_manager: {
        Resource.projects: set(CRUD),
        Resource.workspaces: set(CRUD),
        Resource.user_stories: set(CRUD),
        Resource.test_cases: set(CRUD),
        Resource.test_scripts: set(CRUD),
        Resource.execute_tests: {Action.read, Action.execute},
        Resource.metrics_dashboards: {Action.read, Action.manage},
        Resource.user_management: {Action.read},
        Resource.tenant_management: {Action.read},
    },
    EnterpriseRole.qa_test_lead: {
        Resource.projects: {Action.create, Action.read, Action.update},
        Resource.workspaces: {Action.create, Action.read, Action.update},
        Resource.user_stories: set(CRUD),
        Resource.test_cases: set(CRUD),
        Resource.test_scripts: set(CRUD),
        Resource.execute_tests: {Action.read, Action.execute},
        Resource.metrics_dashboards: {Action.read},
        Resource.user_management: set(),
        Resource.tenant_management: set(),
    },
    EnterpriseRole.qa_engineer: {
        Resource.projects: {Action.read},
        Resource.workspaces: {Action.read},
        Resource.user_stories: {Action.create, Action.read, Action.update},
        Resource.test_cases: {Action.create, Action.read, Action.update},
        Resource.test_scripts: {Action.create, Action.read, Action.update},
        Resource.execute_tests: {Action.read, Action.execute},
        Resource.metrics_dashboards: {Action.read},
        Resource.user_management: set(),
        Resource.tenant_management: set(),
    },
}


def get_user_enterprise_role(current_user) -> EnterpriseRole:
    raw_role = getattr(current_user, "enterprise_role", None) or EnterpriseRole.qa_engineer.value
    try:
        return EnterpriseRole(raw_role)
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=f"Unknown enterprise role: {raw_role}") from exc


def can(role: EnterpriseRole, resource: Resource, action: Action) -> bool:
    return action in ROLE_CAPABILITY_MATRIX.get(role, {}).get(resource, set())


def ensure_capability(current_user, resource: Resource, action: Action) -> None:
    role = get_user_enterprise_role(current_user)
    if not can(role, resource, action):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Enterprise role '{role.value}' cannot {action.value} on {resource.value}",
        )


def list_capabilities(role: EnterpriseRole) -> dict[str, list[str]]:
    role_caps = ROLE_CAPABILITY_MATRIX.get(role, {})
    return {resource.value: sorted(action.value for action in actions) for resource, actions in role_caps.items()}
