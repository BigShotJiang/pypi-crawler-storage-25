from collections.abc import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.database import get_db
from app.services import auth as auth_service
from app.services import api_key as api_key_service

security = HTTPBearer()
optional_security = HTTPBearer(auto_error=False)


def _resolve_user_or_api_key_identity(token: str, db: Session):
    # First try to verify as JWT token.
    token_data = auth_service.verify_token(token, token_type="access")
    if token_data:
        user = auth_service.get_user_by_id(db, token_data.user_id)
        if user and user.is_active:
            return user

    # Then try key_id:key_secret API key format.
    if ":" in token:
        key_id, key_secret = token.split(":", 1)
        api_key = api_key_service.verify_api_key(db, key_id, key_secret)
        if api_key:
            user = auth_service.get_user_by_id(db, api_key.user_id)
            if user and user.is_active:
                user._api_key = api_key
                return user

    return None


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    """
    Dependency to extract and validate the current user from JWT token.
    
    Usage in route:
        @router.get("/protected")
        def protected_route(current_user = Depends(get_current_user)):
            return {"user_id": current_user.id}
    """
    token = credentials.credentials
    token_data = auth_service.verify_token(token, token_type="access")

    if not token_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired access token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = auth_service.get_user_by_id(db, token_data.user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    return user


def get_current_user_or_api_key(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    """
    Dependency to support both JWT and API key authentication.
    
    - JWT token: standard access token
    - API key: key_id:key_secret format or just the full secret
    
    Usage in route:
        @router.get("/protected")
        def protected_route(current_user = Depends(get_current_user_or_api_key)):
            return {"user_id": current_user.id}
    """
    token = credentials.credentials
    user = _resolve_user_or_api_key_identity(token, db)
    if user is not None:
        return user
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_optional_current_user_or_api_key(
    credentials: HTTPAuthorizationCredentials | None = Depends(optional_security),
    db: Session = Depends(get_db),
):
    if credentials is None:
        return None

    user = _resolve_user_or_api_key_identity(credentials.credentials, db)
    if user is not None:
        return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )


def require_auth_with_scopes(required_scopes: set[str] | None = None) -> Callable:
    required_scopes = required_scopes or set()

    def _dependency(current_user=Depends(get_current_user_or_api_key)):
        api_key = getattr(current_user, "_api_key", None)
        if api_key is not None:
            granted_scopes = set(api_key.scopes or [])
            if not required_scopes.issubset(granted_scopes):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="API key does not have required scopes",
                )
        return current_user

    return _dependency


def require_optional_auth_with_scopes(required_scopes: set[str] | None = None) -> Callable:
    required_scopes = required_scopes or set()

    def _dependency(current_user=Depends(get_optional_current_user_or_api_key)):
        if current_user is None:
            return None

        api_key = getattr(current_user, "_api_key", None)
        if api_key is not None:
            granted_scopes = set(api_key.scopes or [])
            if not required_scopes.issubset(granted_scopes):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="API key does not have required scopes",
                )
        return current_user

    return _dependency
