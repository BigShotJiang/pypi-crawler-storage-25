import secrets
import string
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy.orm import Session
from passlib.context import CryptContext

from app.models.api_key import APIKey
from app.models.user import User

# Secret hashing context
# Prefer pbkdf2_sha256 for compatibility; keep bcrypt for legacy verification.
secret_context = CryptContext(schemes=["pbkdf2_sha256", "bcrypt"], deprecated="auto")


def generate_api_key_secret(prefix: str) -> tuple[str, str]:
    """Generate an API key secret with prefix.
    
    Returns:
        Tuple of (full_key, prefix)
        full_key: The complete key that will be shown to the user once (e.g., sg_prefix_secret)
        prefix: The prefix part that will be shown in responses
    """
    # Generate random suffix
    alphabet = string.ascii_letters + string.digits
    suffix = "".join(secrets.choice(alphabet) for _ in range(32))
    
    full_key = f"{prefix}_{suffix}"
    return full_key, prefix


def hash_api_key_secret(secret: str) -> str:
    """Hash an API key secret using the configured secure default scheme."""
    return secret_context.hash(secret)


def verify_api_key_secret(plain_secret: str, hashed_secret: str) -> bool:
    """Verify a plain API key secret against a hashed secret."""
    return secret_context.verify(plain_secret, hashed_secret)


def create_api_key(
    db: Session,
    user_id: int,
    name: str,
    scopes: list[str],
    expires_at: Optional[datetime] = None,
) -> tuple[APIKey, str]:
    """Create a new API key.
    
    Returns:
        Tuple of (api_key_record, full_secret)
        The full secret should be shown to the user only once
    """
    # Generate prefix (e.g., sg_12ab)
    prefix = f"sg_{secrets.token_hex(2)}"
    
    # Generate full secret
    full_secret, _ = generate_api_key_secret(prefix)
    
    # Hash the secret for storage
    hashed_secret = hash_api_key_secret(full_secret)
    
    # Create API key record
    api_key = APIKey(
        user_id=user_id,
        name=name,
        prefix=prefix,
        hashed_secret=hashed_secret,
        scopes=scopes,
        expires_at=expires_at,
    )
    
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    
    return api_key, full_secret


def verify_api_key(db: Session, key_id: str, key_secret: str) -> Optional[APIKey]:
    """Verify an API key (by prefix and secret).
    
    Args:
        key_id: The key ID or prefix
        key_secret: The full secret (e.g., sg_12ab_suffix)
    
    Returns:
        The APIKey record if valid, None otherwise
    """
    try:
        key_id_int = int(key_id)
        api_key = db.query(APIKey).filter(APIKey.id == key_id_int).first()
    except (ValueError, TypeError):
        # Try to query by prefix
        api_key = db.query(APIKey).filter(APIKey.prefix == key_id).first()
    
    if not api_key:
        return None
    
    # Check if active
    if not api_key.is_active:
        return None
    
    # Check expiration (handle both aware and naive datetimes defensively)
    if api_key.expires_at:
        expires_at = api_key.expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)
        if expires_at < datetime.now(timezone.utc):
            return None
    
    # Verify secret
    if not verify_api_key_secret(key_secret, api_key.hashed_secret):
        return None
    
    # Update last_used_at
    api_key.last_used_at = datetime.now(timezone.utc)
    db.commit()
    
    return api_key


def get_api_key_by_id(db: Session, api_key_id: int) -> Optional[APIKey]:
    """Get an API key by ID."""
    return db.query(APIKey).filter(APIKey.id == api_key_id).first()


def get_user_api_keys(db: Session, user_id: int) -> list[APIKey]:
    """Get all API keys for a user."""
    return db.query(APIKey).filter(APIKey.user_id == user_id).all()


def update_api_key(
    db: Session,
    api_key_id: int,
    name: Optional[str] = None,
    scopes: Optional[list[str]] = None,
    expires_at: Optional[datetime] = None,
) -> Optional[APIKey]:
    """Update an API key."""
    api_key = get_api_key_by_id(db, api_key_id)
    if not api_key:
        return None
    
    if name is not None:
        api_key.name = name
    if scopes is not None:
        api_key.scopes = scopes
    if expires_at is not None:
        api_key.expires_at = expires_at
    
    db.commit()
    db.refresh(api_key)
    return api_key


def revoke_api_key(db: Session, api_key_id: int) -> Optional[APIKey]:
    """Revoke (deactivate) an API key."""
    api_key = get_api_key_by_id(db, api_key_id)
    if not api_key:
        return None
    
    api_key.is_active = False
    db.commit()
    db.refresh(api_key)
    return api_key


def delete_api_key(db: Session, api_key_id: int) -> bool:
    """Delete an API key."""
    api_key = get_api_key_by_id(db, api_key_id)
    if not api_key:
        return False
    
    db.delete(api_key)
    db.commit()
    return True
