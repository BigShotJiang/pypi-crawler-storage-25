"""
Redis-backed per-user/API-key rate limiter with in-memory fallback.

Usage (FastAPI dependency):
    @router.post("/run")
    def my_endpoint(
        _=Depends(per_user_rate_limit(max_requests=20, window_seconds=60, scope="execution:run")),
        current_user=Depends(require_auth_with_scopes({"execution:write"})),
    ):
        ...
"""

import logging
import threading
import time
from typing import Callable

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session

from app.cache import cache as _redis_cache
from app.config import settings
from app.database import get_db

logger = logging.getLogger(__name__)

optional_security = HTTPBearer(auto_error=False)

# In-memory fallback store: key -> (count, window_reset_at)
_IN_MEMORY_BUCKETS: dict[str, tuple[int, float]] = {}
_IN_MEMORY_LOCK = threading.Lock()


def _client_ip(request: Request) -> str:
    forwarded_for = request.headers.get("x-forwarded-for", "")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _redis_rate_check(key: str, max_requests: int, window_seconds: int) -> tuple[bool, int, int]:
    """Sliding fixed-window counter via Redis INCR + EXPIRE. Returns (allowed, remaining, retry_after)."""
    try:
        if not _redis_cache.is_available():
            raise RuntimeError("Redis unavailable")

        rc = _redis_cache.redis_client
        count = rc.incr(key)
        if count == 1:
            rc.expire(key, window_seconds)
        ttl = rc.ttl(key)
        if ttl < 0:
            rc.expire(key, window_seconds)
            ttl = window_seconds
        remaining = max(0, max_requests - int(count))
        return int(count) <= max_requests, remaining, int(ttl)
    except Exception as exc:
        logger.debug("Redis rate limit unavailable, falling back to in-memory: %s", exc)
        return _memory_rate_check(key, max_requests, window_seconds)


def _memory_rate_check(key: str, max_requests: int, window_seconds: int) -> tuple[bool, int, int]:
    """Thread-safe fixed-window counter in process memory."""
    now = time.monotonic()
    with _IN_MEMORY_LOCK:
        count, reset_at = _IN_MEMORY_BUCKETS.get(key, (0, now + window_seconds))
        if reset_at <= now:
            count = 0
            reset_at = now + window_seconds
        count += 1
        _IN_MEMORY_BUCKETS[key] = (count, reset_at)
    remaining = max(0, max_requests - count)
    retry_after = max(0, int(reset_at - now))
    return count <= max_requests, remaining, retry_after


def per_user_rate_limit(
    max_requests: int,
    window_seconds: int,
    scope: str = "",
) -> Callable:
    """
    FastAPI dependency factory for per-user/API-key rate limiting.

    Identity resolution order:
    1. Authenticated user ID from a valid JWT bearer token
    2. API key ID from a valid API key bearer token
    3. Client IP address when the endpoint is unauthenticated or anonymous

    The ``scope`` argument acts as the rate-limit bucket label — use it to group
    endpoints into the same limit bucket (e.g. "auth:login") or leave it empty
    to scope per endpoint path.
    """

    def _resolve_identity(request: Request, credentials, db: Session | None) -> str:
        user = getattr(request.state, "rate_limit_user", None)
        token = getattr(credentials, "credentials", None)
        if user is None and token and db is not None and not hasattr(db, "dependency"):
            from app.services.auth_dependencies import _resolve_user_or_api_key_identity

            user = _resolve_user_or_api_key_identity(token, db)

        if user is not None:
            api_key = getattr(user, "_api_key", None)
            api_key_id = getattr(api_key, "id", None)
            # Validate api_key_id is a real integer (not a mock object in tests)
            if api_key_id is not None and isinstance(api_key_id, int):
                return f"k:{api_key_id}"

            user_id = getattr(user, "id", None)
            if user_id is not None and isinstance(user_id, int):
                return f"u:{user_id}"

        return f"ip:{_client_ip(request)}"

    def _dependency(
        request: Request,
        credentials=Depends(optional_security),
        db: Session = Depends(get_db),
    ) -> None:
        identity = _resolve_identity(request, credentials, db)
        bucket = scope or request.url.path
        key = f"ratelimit:{identity}:{bucket}"
        allowed, remaining, retry_after = _redis_rate_check(key, max_requests, window_seconds)

        rate_limit_headers = getattr(request.state, "rate_limit_headers", None)
        if rate_limit_headers is None:
            rate_limit_headers = {}
            request.state.rate_limit_headers = rate_limit_headers

        rate_limit_headers.update(
            {
                "X-RateLimit-Limit": str(max_requests),
                "X-RateLimit-Remaining": str(remaining),
                "X-RateLimit-Window": str(window_seconds),
            }
        )

        if not allowed:
            logger.info(
                "rate_limit_exceeded identity=%s scope=%s path=%s",
                identity,
                bucket,
                request.url.path,
            )
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Rate limit exceeded. Please slow down.",
                headers={
                    "X-RateLimit-Limit": str(max_requests),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Window": str(window_seconds),
                    "Retry-After": str(retry_after),
                },
            )

    return _dependency
