"""
Celery tasks for long-running operations.

These tasks are executed by Celery workers and should not block the API.
Examples: Script generation, test execution, file processing, etc.
"""

from datetime import datetime, timedelta, timezone
import logging

try:
    from celery import shared_task
except ModuleNotFoundError:  # pragma: no cover - fallback for test environments without celery installed
    from types import SimpleNamespace

    class _TaskWrapper:
        def __init__(self, func, *, bind: bool = False, max_retries: int | None = None):
            self._func = func
            self.bind = bind
            self.max_retries = max_retries if max_retries is not None else 0

        def _self_proxy(self):
            return SimpleNamespace(
                request=SimpleNamespace(retries=0),
                max_retries=self.max_retries,
                retry=self._retry,
            )

        def _retry(self, exc=None, **kwargs):
            if exc is not None:
                raise exc
            raise RuntimeError("Celery retry requested")

        def run(self, *args, **kwargs):
            if self.bind:
                return self._func(self._self_proxy(), *args, **kwargs)
            return self._func(*args, **kwargs)

        def delay(self, *args, **kwargs):
            return SimpleNamespace(id="stub-task", result=None)

        def apply(self, args=None, kwargs=None):
            args = args or ()
            kwargs = kwargs or {}
            return SimpleNamespace(result=self.run(*args, **kwargs))

        def __call__(self, *args, **kwargs):
            return self.run(*args, **kwargs)

    def shared_task(*decorator_args, **decorator_kwargs):
        def decorator(func):
            wrapper = _TaskWrapper(
                func,
                bind=bool(decorator_kwargs.get("bind", False)),
                max_retries=decorator_kwargs.get("max_retries"),
            )
            wrapper.__name__ = getattr(func, "__name__", "task")
            wrapper.__doc__ = getattr(func, "__doc__", None)
            return wrapper

        if decorator_args and callable(decorator_args[0]) and len(decorator_args) == 1 and not decorator_kwargs:
            return decorator(decorator_args[0])
        return decorator
from app.config import settings
from app.database import SessionLocal
from app.models.execution_job import ExecutionJob, ExecutionJobStatus, can_transition
from app.models.script_run import ScriptRun

logger = logging.getLogger(__name__)


def _retry_countdown(retries: int) -> int:
    return min(300, 5 ** (retries + 1))


def _log_dead_letter(task_name: str, entity_id: int, exc: Exception) -> None:
    logger.error("dead_letter task=%s entity_id=%s error=%s", task_name, entity_id, exc)


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def process_script_generation_job(
    self,
    script_id: int,
    project_id: int,
    test_case_id: int,
    request_data: dict,
):
    """Queue-backed script generation worker task."""
    try:
        from app.routers.scripts import _run_generation

        _run_generation(script_id, project_id, test_case_id, request_data)
        return {"status": "completed", "script_id": script_id}
    except Exception as exc:
        if self.request.retries >= self.max_retries:
            _log_dead_letter("process_script_generation_job", script_id, exc)
            raise
        raise self.retry(exc=exc, countdown=_retry_countdown(self.request.retries))


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def process_bulk_generation_job(self, bulk_job_id: int, request_data: dict):
    """Queue-backed bulk generation worker task."""
    try:
        from app.routers.bulk_jobs import _run_bulk_generation
        from app.schemas.bulk_job import BulkGenerateRequest

        _run_bulk_generation(bulk_job_id, BulkGenerateRequest.model_validate(request_data))
        return {"status": "completed", "bulk_job_id": bulk_job_id}
    except Exception as exc:
        if self.request.retries >= self.max_retries:
            _log_dead_letter("process_bulk_generation_job", bulk_job_id, exc)
            raise
        raise self.retry(exc=exc, countdown=_retry_countdown(self.request.retries))


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def process_bulk_execution_job(self, bulk_job_id: int, request_data: dict):
    """Queue-backed bulk execution worker task."""
    try:
        from app.routers.bulk_jobs import _run_bulk_execution
        from app.schemas.bulk_job import BulkRunRequest

        _run_bulk_execution(bulk_job_id, BulkRunRequest.model_validate(request_data))
        return {"status": "completed", "bulk_job_id": bulk_job_id}
    except Exception as exc:
        if self.request.retries >= self.max_retries:
            _log_dead_letter("process_bulk_execution_job", bulk_job_id, exc)
            raise
        raise self.retry(exc=exc, countdown=_retry_countdown(self.request.retries))


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def generate_test_script(self, test_case_id: int, project_id: int):
    """
    Async task to generate a test script from a test case.
    
    Args:
        test_case_id: ID of the test case to generate script from
        project_id: ID of the project context
    
    Returns:
        dict with script_id and generation_status
    """
    db = SessionLocal()
    try:
        # TODO: Implement actual script generation logic
        # This would call the LLM service, update the database, etc.
        logger.info(f"Generating script for test case {test_case_id} in project {project_id}")
        
        # Example result structure
        return {
            "status": "success",
            "test_case_id": test_case_id,
            "script_id": None,  # Will be populated after generation
        }
    except Exception as exc:
        logger.error(f"Error generating script: {exc}")
        if self.request.retries >= self.max_retries:
            _log_dead_letter("generate_test_script", test_case_id, exc)
            raise
        raise self.retry(exc=exc, countdown=_retry_countdown(self.request.retries))
    finally:
        db.close()


def _sync_execution_job_state(
    db,
    execution_job_id: int | None,
    status: ExecutionJobStatus,
    *,
    result_payload: dict | None = None,
    error_message: str | None = None,
):
    if execution_job_id is None:
        return

    job = db.query(ExecutionJob).filter(ExecutionJob.id == execution_job_id).first()
    if not job or not can_transition(job.status, status):
        return

    now = datetime.now(timezone.utc)
    job.status = status
    if status == ExecutionJobStatus.running and job.started_at is None:
        job.started_at = now
    if status in {ExecutionJobStatus.completed, ExecutionJobStatus.failed}:
        if job.started_at is None:
            job.started_at = now
        job.completed_at = now
    if status == ExecutionJobStatus.cancelled:
        job.cancelled_at = now
    if result_payload is not None:
        job.result_payload = result_payload
    if error_message is not None:
        job.error_message = error_message
    db.commit()


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def execute_script(self, script_id: int, execution_env: dict | None = None, execution_job_id: int | None = None):
    """
    Async task to execute a test script (Playwright/Selenium).
    
    Args:
        script_id: ID of the script to execute
        execution_env: Environment variables and configuration for execution
    
    Returns:
        dict with execution_id, status, duration, and logs
    """
    db = SessionLocal()
    try:
        execution_env = execution_env or {}
        logger.info(f"Executing script {script_id} with env: {execution_env}")
        _sync_execution_job_state(db, execution_job_id, ExecutionJobStatus.running)
        
        # TODO: Implement actual script execution logic
        # This would:
        # 1. Load the script from database
        # 2. Set up execution environment
        # 3. Run Playwright/Selenium
        # 4. Capture results and logs
        # 5. Store execution record in database
        
        result = {
            "status": "success",
            "script_id": script_id,
            "execution_id": None,  # Will be populated after execution
            "duration_seconds": 0,
        }
        _sync_execution_job_state(
            db,
            execution_job_id,
            ExecutionJobStatus.completed,
            result_payload=result,
        )
        return result
    except Exception as exc:
        logger.error(f"Error executing script: {exc}")
        _sync_execution_job_state(
            db,
            execution_job_id,
            ExecutionJobStatus.failed,
            error_message=str(exc),
        )
        if self.request.retries >= self.max_retries:
            _log_dead_letter("execute_script", script_id, exc)
            raise
        raise self.retry(exc=exc, countdown=_retry_countdown(self.request.retries))
    finally:
        db.close()


@shared_task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def bulk_job_processor(self, bulk_job_id: int):
    """
    Async task to process a bulk job (multiple scripts/executions).
    
    Args:
        bulk_job_id: ID of the bulk job to process
    
    Returns:
        dict with job_id, total_tasks, completed_tasks, status
    """
    db = SessionLocal()
    try:
        logger.info(f"Processing bulk job {bulk_job_id}")
        
        # TODO: Implement bulk job processing
        # This would iterate through test cases/scripts and spawn subtasks
        
        return {
            "status": "completed",
            "bulk_job_id": bulk_job_id,
            "total_tasks": 0,
            "completed_tasks": 0,
        }
    except Exception as exc:
        logger.error(f"Error processing bulk job: {exc}")
        if self.request.retries >= self.max_retries:
            _log_dead_letter("bulk_job_processor", bulk_job_id, exc)
            raise
        raise self.retry(exc=exc, countdown=min(300, 10 ** (self.request.retries + 1)))
    finally:
        db.close()


@shared_task
def cleanup_old_artifacts(days: int = 30):
    """
    Periodic task to clean up old execution artifacts and logs.
    
    Args:
        days: Number of days to keep artifacts (default: 30)
    
    Returns:
        dict with cleanup_status and count of removed items
    """
    db = SessionLocal()
    try:
        retention_days = max(1, int(days))
        if not hasattr(db, "query"):
            logger.warning("Skipping artifact cleanup because session does not support query operations")
            return {
                "status": "completed",
                "removed_count": 0,
                "removed_script_runs": 0,
                "removed_execution_jobs": 0,
                "retention_days": retention_days,
            }

        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        logger.info("Cleaning up artifacts older than %s days", retention_days)

        removed_script_runs = (
            db.query(ScriptRun)
            .filter(ScriptRun.created_at < cutoff)
            .delete(synchronize_session=False)
        )
        removed_execution_jobs = (
            db.query(ExecutionJob)
            .filter(
                ExecutionJob.updated_at < cutoff,
                ExecutionJob.status.in_(
                    [
                        ExecutionJobStatus.completed,
                        ExecutionJobStatus.failed,
                        ExecutionJobStatus.cancelled,
                    ]
                ),
            )
            .delete(synchronize_session=False)
        )
        db.commit()

        return {
            "status": "completed",
            "removed_count": int(removed_script_runs + removed_execution_jobs),
            "removed_script_runs": int(removed_script_runs),
            "removed_execution_jobs": int(removed_execution_jobs),
            "retention_days": retention_days,
        }
    finally:
        db.close()
