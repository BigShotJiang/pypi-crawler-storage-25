from datetime import datetime
from pydantic import BaseModel, Field

from app.models.test_case import TestCaseFormat


class TestCaseCreate(BaseModel):
    title: str = Field(..., max_length=512)
    format: TestCaseFormat = TestCaseFormat.step_based
    content: str = Field(..., description="Full test case text (steps or BDD scenarios)")
    preconditions: str | None = None
    test_data_hints: str | None = None


class TestCaseUpdate(BaseModel):
    title: str | None = Field(None, max_length=512)
    format: TestCaseFormat | None = None
    content: str | None = None
    preconditions: str | None = None
    test_data_hints: str | None = None


class TestCaseResponse(BaseModel):
    id: int
    project_id: int
    title: str
    format: TestCaseFormat
    content: str
    preconditions: str | None
    test_data_hints: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
