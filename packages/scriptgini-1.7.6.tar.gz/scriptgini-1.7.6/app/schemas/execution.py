from datetime import datetime

from pydantic import BaseModel, Field

from app.models.execution_job import ExecutionJobStatus


class ExecutionRunRequest(BaseModel):
    script_id: int = Field(..., gt=0)
    execution_env: dict[str, str] = Field(default_factory=dict)


class ExecutionJobResponse(BaseModel):
    id: int
    project_id: int
    script_id: int
    test_case_id: int
    created_by_user_id: int
    status: ExecutionJobStatus
    idempotency_key: str | None
    celery_task_id: str | None
    request_payload: dict
    result_payload: dict | None
    error_message: str | None
    started_at: datetime | None
    completed_at: datetime | None
    cancelled_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
