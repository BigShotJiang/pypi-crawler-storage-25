from datetime import datetime

from pydantic import BaseModel

from app.models.membership import Role


class ProjectMemberUpsertRequest(BaseModel):
    role: Role
    is_active: bool = True


class ProjectMemberResponse(BaseModel):
    id: int
    project_id: int
    user_id: int
    role: Role
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
