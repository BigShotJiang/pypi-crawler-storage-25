from datetime import datetime

from pydantic import BaseModel, ConfigDict


class RecentFailureResponse(BaseModel):
    run_id: int
    script_id: int
    test_case_id: int
    test_case_title: str | None = None
    exit_code: int
    duration_seconds: float
    stderr_excerpt: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class RunAnalyticsResponse(BaseModel):
    project_id: int
    total_runs: int
    success_runs: int
    failed_runs: int
    timed_out_runs: int
    success_rate: float
    average_duration_seconds: float
    recent_failures: list[RecentFailureResponse]


class TrendPointResponse(BaseModel):
    bucket: str
    total_runs: int
    success_rate: float
    average_duration_seconds: float


class TrendsResponse(BaseModel):
    project_id: int | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    points: list[TrendPointResponse]


class FlakinessItemResponse(BaseModel):
    script_id: int
    test_case_id: int
    total_runs: int
    failed_runs: int
    flakiness_score: float
    confidence_score: float
    last_failure_at: datetime | None = None


class FlakinessResponse(BaseModel):
    project_id: int | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    min_runs: int
    items: list[FlakinessItemResponse]


class CoverageTestCaseItem(BaseModel):
    test_case_id: int
    title: str
    format: str
    has_script: bool
    has_run: bool
    last_run_success: bool | None = None


class CoverageModuleItem(BaseModel):
    module: str
    total_cases: int
    scripted_cases: int
    executed_cases: int
    passed_cases: int
    coverage_rate: float
    execution_rate: float
    test_cases: list[CoverageTestCaseItem]


class CoverageResponse(BaseModel):
    project_id: int | None = None
    total_cases: int
    scripted_cases: int
    executed_cases: int
    passed_cases: int
    overall_coverage_rate: float
    overall_execution_rate: float
    modules: list[CoverageModuleItem]
