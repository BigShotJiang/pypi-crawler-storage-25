from datetime import datetime

from pydantic import BaseModel, Field

from app.config import settings
from app.llm.provider import LLMProvider
from app.models.bulk_job import BulkJobKind, BulkJobStatus, BulkJobItemStatus
from app.models.project import TestFramework


class BulkGenerateRequest(BaseModel):
    llm_provider: LLMProvider = settings.DEFAULT_LLM_PROVIDER
    llm_model: str | None = Field(None, description="Override the default model for the chosen provider")
    framework: TestFramework | None = Field(None, description="Override the project's default framework")
    test_case_ids: list[int] | None = Field(None, description="Optional subset of test case IDs to process")


class BulkRunRequest(BaseModel):
    test_case_ids: list[int] | None = Field(None, description="Optional subset of test case IDs to process")


class BulkJobItemResponse(BaseModel):
    id: int
    job_id: int
    test_case_id: int
    script_id: int | None
    status: BulkJobItemStatus
    message: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class BulkJobResponse(BaseModel):
    id: int
    project_id: int
    kind: BulkJobKind
    status: BulkJobStatus
    total_items: int
    completed_items: int
    failed_items: int
    skipped_items: int
    created_at: datetime
    updated_at: datetime
    items: list[BulkJobItemResponse] = []

    model_config = {"from_attributes": True}
