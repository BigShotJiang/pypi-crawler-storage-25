from datetime import datetime

from pydantic import BaseModel


class WorkspaceCreate(BaseModel):
    name: str
    description: str | None = None
    organization_id: int | None = None


class WorkspaceUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    organization_id: int | None = None


class WorkspaceResponse(BaseModel):
    id: int
    organization_id: int | None
    name: str
    description: str | None
    created_by_user_id: int | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
