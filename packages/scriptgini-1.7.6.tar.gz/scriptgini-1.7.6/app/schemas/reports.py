from datetime import datetime

from pydantic import BaseModel

from app.models.execution_job import ExecutionJobStatus


class ExecutionReportResponse(BaseModel):
    execution_id: int
    project_id: int
    script_id: int
    test_case_id: int
    status: ExecutionJobStatus
    duration_seconds: float
    started_at: datetime | None = None
    completed_at: datetime | None = None
    cancelled_at: datetime | None = None
    error_message: str | None = None


class ExecutionLogsResponse(BaseModel):
    execution_id: int
    stdout: str
    stderr: str


class ArtifactItemResponse(BaseModel):
    id: str
    type: str
    filename: str
    content_type: str
    size_bytes: int
    created_at: datetime | None = None


class ArtifactListResponse(BaseModel):
    execution_id: int
    retention_days: int
    artifacts: list[ArtifactItemResponse]
