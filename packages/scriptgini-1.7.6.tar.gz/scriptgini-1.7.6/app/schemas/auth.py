from pydantic import BaseModel, EmailStr
from datetime import datetime

from app.models.user import EnterpriseRole


class UserRegisterRequest(BaseModel):
    email: EmailStr
    password: str

    model_config = {"json_schema_extra": {"example": {"email": "user@example.com", "password": "SecurePass123!"}}}


class UserLoginRequest(BaseModel):
    email: EmailStr
    password: str

    model_config = {"json_schema_extra": {"example": {"email": "user@example.com", "password": "SecurePass123!"}}}


class UserResponse(BaseModel):
    id: int
    email: str
    enterprise_role: EnterpriseRole
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class TokenData(BaseModel):
    user_id: int
    email: str
    token_type: str  # 'access' or 'refresh'


class UserRoleUpdateRequest(BaseModel):
    enterprise_role: EnterpriseRole
