from datetime import datetime

from pydantic import BaseModel, ConfigDict

from app.models.script_revision import RevisionChangeType


class ScriptRevisionResponse(BaseModel):
    id: int
    script_id: int
    project_id: int
    test_case_id: int
    revision_number: int
    script_content: str
    change_type: RevisionChangeType
    change_summary: str | None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ScriptVersionHistoryResponse(BaseModel):
    script_id: int
    total_revisions: int
    revisions: list[ScriptRevisionResponse]


class ScriptDiffResponse(BaseModel):
    script_id: int
    from_revision: int
    to_revision: int
    from_content: str
    to_content: str
    diff_lines: list[str]


class RefactorScriptRequest(BaseModel):
    error_log: str
    llm_provider: str | None = None
    llm_model: str | None = None


class RefactorScriptResponse(BaseModel):
    script_id: int
    revision_id: int
    revision_number: int
    script_content: str
    change_summary: str
