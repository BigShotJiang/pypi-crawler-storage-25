from datetime import datetime
from pydantic import BaseModel, Field

from app.models.generated_script import ScriptStatus
from app.models.project import TestFramework
from app.models.script_run import ScriptRunStatus
from app.config import settings
from app.llm.provider import LLMProvider


class GenerateScriptRequest(BaseModel):
    llm_provider: LLMProvider = settings.DEFAULT_LLM_PROVIDER
    llm_model: str | None = Field(None, description="Override the default model for the chosen provider")
    framework: TestFramework | None = Field(
        None, description="Override the project's default framework"
    )


class GeneratedScriptResponse(BaseModel):
    id: int
    project_id: int
    test_case_id: int
    framework: str
    llm_provider: str
    llm_model: str
    script_content: str | None
    status: ScriptStatus
    error_message: str | None
    token_usage: int | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ScriptRunResponse(BaseModel):
    id: int
    script_id: int
    project_id: int
    test_case_id: int
    status: ScriptRunStatus
    success: bool
    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float
    command: str
    created_at: datetime

    model_config = {"from_attributes": True}
