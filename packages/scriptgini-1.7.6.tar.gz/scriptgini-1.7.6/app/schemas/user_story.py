from datetime import datetime

from pydantic import BaseModel

from app.models.user_story import UserStoryStatus


class UserStoryCreate(BaseModel):
    title: str
    description: str | None = None
    acceptance_criteria: str | None = None
    workspace_id: int | None = None
    status: UserStoryStatus = UserStoryStatus.draft


class UserStoryUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    acceptance_criteria: str | None = None
    workspace_id: int | None = None
    status: UserStoryStatus | None = None


class UserStoryResponse(BaseModel):
    id: int
    project_id: int
    workspace_id: int | None
    title: str
    description: str | None
    acceptance_criteria: str | None
    status: UserStoryStatus
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}
