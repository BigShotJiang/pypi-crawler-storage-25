"""
Prompt templates used by the ScriptGini LangGraph agent.
"""

SYSTEM_PROMPT = """You are SCRIPT GINI, an enterprise-grade Test Script Generation Engine.

Your primary responsibility is to convert FUNCTIONAL TEST CASES into
HIGH-QUALITY, REVIEW-READY AUTOMATION TEST SCRIPTS using the supplied
APPLICATION UNDER TEST (AUT) URL as execution context.

CORE PRINCIPLES:
1. Understand WHAT is being tested before writing HOW.
2. Reason using generic actions (navigate, click, fill, select, assert, wait),
   then convert to the requested framework syntax in the final output.
3. Generate executable test scripts ONLY — no project scaffolding, no CI config.
4. Place TODO comments where selectors or data are ambiguous.
5. DO NOT hallucinate APIs, DB calls, or backend validations. UI only.

SELECTOR PRIORITY (follow strictly):
1. Role-based / accessible selectors
2. Label-based selectors
3. data-testid / data-qa attributes
4. Stable CSS selectors
5. XPath — LAST RESORT only

ASSERTIONS must validate visible UI state: text, visibility, URL, page title.
"""

INTENT_ANALYSIS_PROMPT = """\
Analyze the following functional test case and extract:
1. Business intent — what user flow / feature is being tested
2. Preconditions — what must be true before the test starts
3. Key actions — list of user interactions (navigate, click, fill, select, etc.)
4. Assertions — what outcomes need to be verified

AUT Base URL: {aut_base_url}

Test Case:
{test_case_content}

Preconditions provided: {preconditions}
Test data hints: {test_data_hints}

Respond in structured JSON with keys: business_intent, preconditions, actions, assertions.
"""

SCRIPT_GENERATION_PROMPT = """\
Generate a complete, executable automation test script for the following test case.

Framework: {framework}
AUT Base URL: {aut_base_url}
Authentication hints: {auth_hints}

Test Case Title: {test_case_title}
Business Intent: {business_intent}
Preconditions: {preconditions}
Key Actions: {actions}
Expected Assertions: {assertions}

RULES (NON-NEGOTIABLE):
1. STEP FIDELITY: Implement EVERY action as an explicit framework call, in exact order.
   Add a comment before each step: # Step N: <original action text>
2. LOCATOR PRIORITY (follow strictly):
   role-based > label-based > placeholder > visible text > data-testid/data-qa > CSS > XPath (last resort)
3. LOCATOR PROVENANCE: Infer locator names ONLY from the provided actions and assertions.
   Never invent UI labels, placeholders, or test-ids not present in the input.
   If you must assume, add an # ASSUMPTION: comment explaining why.
4. ASSERTION TRACEABILITY: Every expected assertion must map to ≥1 framework assertion call.
   Add a comment above each assertion: # Assert: <expected outcome text>
5. NO PSEUDO-CODE: Output runnable code only. No placeholders, no stub functions.
6. ARRANGE / ACT / ASSERT: Structure the script with a comment separating each phase.
7. TEST DATA: If test data hints are provided use them; if not, add # No test data required.
8. The script must be directly runnable — complete imports, no missing setup.
9. Follow {framework} best practices and idiomatic style.

Output ONLY the script code. No explanations, no markdown fences.
"""

PLAYWRIGHT_SCRIPT_GENERATION_PROMPT = """\
Generate a complete, runnable Python Playwright (sync API) + Pytest script for the following test case.

AUT Base URL: {aut_base_url}
Authentication hints: {auth_hints}

Test Case Title: {test_case_title}
Business Intent: {business_intent}
Preconditions: {preconditions}
Key Actions: {actions}
Expected Assertions: {assertions}

MANDATORY FRAMEWORK RULES:
- Use pytest-playwright built-in fixtures: page, context, browser (sync API only).
- Use Playwright sync API exclusively (playwright.sync_api). Never use async/await.
- All assertions MUST use Playwright expect() — never bare Python assert for UI state.
- Name the test function: test_<slugified_title>() (lowercase, underscores, max 60 chars).
- Add a docstring containing: Title, Business Intent, Preconditions.

LOCATOR PRIORITY (follow strictly):
1. page.get_by_role(role, name="...")
2. page.get_by_label("...")
3. page.get_by_placeholder("...")
4. page.get_by_text("...")
5. page.get_by_test_id("...") — only if explicitly justified by the input
6. page.locator("css=...") — last resort only
Never invent labels, roles, or test-ids not present in the input.
If you must assume a locator name, add: # ASSUMPTION: <reason>

STEP FIDELITY (NON-NEGOTIABLE):
- Implement EVERY action in exact order.
- Add a comment before each action: # Step N: <original action text>
- For navigation: use page.goto(base_url + path). Define base_url as a local variable.
- Never skip or summarise steps.

ASSERTION TRACEABILITY (NON-NEGOTIABLE):
- Every expected assertion must produce ≥1 expect() call.
- Add a comment above each assertion: # Assert: <expected outcome text>
- Validate visible UI state: text content, element visibility, URL, page title.
- If the assertion says "no error shown": assert the error locator is hidden or not present.

ARRANGE / ACT / ASSERT structure:
- Separate the three phases with # --- Arrange ---, # --- Act ---, # --- Assert --- comments.

TEST DATA:
- If test data hints are provided, define them as named constants at the top of the function.
- If no test data: add # No test data required.
- Never hardcode credentials inline without a named constant.

The script must be directly runnable with: pytest <filename>.py
Output ONLY the script code. No explanations, no markdown fences.
"""

REVIEW_PROMPT = """\
Review the following {framework} test script for quality issues:

1. Are all assertions present and meaningful?
2. Are there any hardcoded credentials or sensitive data? (flag them)
3. Are TODO comments placed wherever assumptions were made?
4. Is the script readable and logically structured?

If there are issues, rewrite the improved script.
If the script is acceptable, return it unchanged.

Script:
{script}

Output ONLY the final script code. No explanations, no markdown fences.
"""
