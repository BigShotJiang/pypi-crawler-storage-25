import os

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # App
    APP_NAME: str = "ScriptGini"
    DEBUG: bool = False
    CORS_ALLOWED_ORIGINS: str = "http://localhost:3000,http://127.0.0.1:3000"
    RATE_LIMIT_REQUESTS: int = 120
    RATE_LIMIT_WINDOW_SECONDS: int = 60
    RATE_LIMIT_EXEMPT_PATHS: str = "/health,/docs,/redoc,/openapi.json,/static"
    SECURITY_AUDIT_LOG_ENABLED: bool = True

    # Database (PostgreSQL)
    # Format: postgresql://user:password@host:port/dbname
    DATABASE_URL: str = "postgresql://scriptgini:scriptgini@localhost:5433/scriptgini_db"
    DATABASE_ECHO: bool = False  # Set to True to log SQL queries

    # Redis (Task Queue & Caching)
    REDIS_URL: str = "redis://localhost:6379/0"
    REDIS_CACHE_TTL_SECONDS: int = 3600  # 1 hour default cache TTL

    # Celery Task Queue
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"  # Different DB for task queue
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"  # Different DB for results
    CELERY_TASK_TIMEOUT: int = 600  # 10 minutes default task timeout
    CELERY_TASK_HARD_TIMEOUT: int = 660
    CELERY_MAX_RETRIES: int = 3
    JWT_SECRET_KEY: str = "your-secret-key-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Default LLM provider
    DEFAULT_LLM_PROVIDER: Literal["openai", "ollama", "openrouter", "gemini", "bedrock"] = "openai"
    LLM_REQUEST_TIMEOUT_SECONDS: float = 45.0
    SCRIPT_GENERATION_TIMEOUT_SECONDS: int = 180
    PLAYWRIGHT_RUN_HEADED: bool = True
    SCRIPT_EXECUTION_TIMEOUT_SECONDS: int = 300
    ARTIFACT_RETENTION_DAYS: int = 30
    EXECUTION_ENV_ALLOWED_KEYS: str = "PATH,SYSTEMROOT,TEMP,TMP,HOME,USERPROFILE,PYTHONPATH,PYTHONHOME,PYTHONIOENCODING"
    EXECUTION_ENV_ALLOWED_PREFIXES: str = "PLAYWRIGHT_"
    SKIP_REVIEW_FOR_OLLAMA: bool = True
    USE_LLM_INTENT_ANALYSIS: bool = True

    # Automatic Git export
    AUTO_EXPORT_GIT_ENABLED: bool = False
    AUTO_EXPORT_GIT_REPO_URL: str = ""
    AUTO_EXPORT_GIT_BRANCH: str = "main"
    AUTO_EXPORT_GIT_LOCAL_PATH: str = "~/.scriptgini/scriptgini-sandbox"
    AUTO_EXPORT_GIT_USER_NAME: str = "ScriptGini"
    AUTO_EXPORT_GIT_USER_EMAIL: str = "scriptgini@local"

    # OpenAI
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"

    # Ollama
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "llama3"
    OLLAMA_NUM_PREDICT: int = 700
    OLLAMA_REQUEST_TIMEOUT_SECONDS: float = 180.0
    OLLAMA_TIMEOUT_RETRIES: int = 1

    # OpenRouter
    OPENROUTER_API_KEY: str = ""
    OPENROUTER_MODEL: str = "openai/gpt-4o"
    OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"

    # Google Gemini
    GOOGLE_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.5-flash"

    # AWS Bedrock
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION_NAME: str = "us-east-1"
    BEDROCK_MODEL_ID: str = "anthropic.claude-3-5-sonnet-20241022-v2:0"

    @staticmethod
    def _split_csv(value: str) -> list[str]:
        return [entry.strip() for entry in value.split(",") if entry.strip()]

    @property
    def cors_allowed_origins_list(self) -> list[str]:
        return self._split_csv(self.CORS_ALLOWED_ORIGINS)

    @property
    def rate_limit_exempt_paths_list(self) -> list[str]:
        return self._split_csv(self.RATE_LIMIT_EXEMPT_PATHS)

    @property
    def execution_env_allowed_keys_set(self) -> set[str]:
        return set(self._split_csv(self.EXECUTION_ENV_ALLOWED_KEYS))

    @property
    def execution_env_allowed_prefixes_tuple(self) -> tuple[str, ...]:
        return tuple(self._split_csv(self.EXECUTION_ENV_ALLOWED_PREFIXES))


_STABLE_OPENAPI_EXPORT = os.getenv("SCRIPTGINI_OPENAPI_STABLE_EXPORT") == "1"
_ENV_FILE = None if _STABLE_OPENAPI_EXPORT else ".env"

settings = Settings(_env_file=_ENV_FILE)
