from fastapi import APIRouter, Depends, HTTPException

from app.services.auth_dependencies import get_current_user
from app.services.enterprise_rbac import EnterpriseRole, get_user_enterprise_role, list_capabilities

router = APIRouter(prefix="/rbac", tags=["Enterprise RBAC"])


@router.get("/me")
def my_role_and_capabilities(current_user=Depends(get_current_user)):
    role = get_user_enterprise_role(current_user)
    return {
        "role": role.value,
        "capabilities": list_capabilities(role),
    }


@router.get("/capabilities/{role_name}")
def capabilities_for_role(role_name: str):
    try:
        role = EnterpriseRole(role_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"Unknown role: {role_name}") from exc
    return {
        "role": role.value,
        "capabilities": list_capabilities(role),
    }
