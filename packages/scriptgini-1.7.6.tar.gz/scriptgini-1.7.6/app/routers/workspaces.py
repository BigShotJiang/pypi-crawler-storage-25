from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.workspace import Workspace
from app.schemas.workspace import WorkspaceCreate, WorkspaceResponse, WorkspaceUpdate
from app.services.auth_dependencies import get_current_user
from app.services.enterprise_rbac import Action, Resource, ensure_capability

router = APIRouter(prefix="/workspaces", tags=["Workspaces"])


@router.post("", response_model=WorkspaceResponse, status_code=status.HTTP_201_CREATED)
def create_workspace(
    payload: WorkspaceCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.workspaces, Action.create)
    row = Workspace(
        name=payload.name,
        description=payload.description,
        organization_id=payload.organization_id,
        created_by_user_id=current_user.id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("", response_model=list[WorkspaceResponse])
def list_workspaces(
    skip: int = 0,
    limit: int = 100,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.workspaces, Action.read)
    return db.query(Workspace).offset(skip).limit(limit).all()


@router.get("/{workspace_id}", response_model=WorkspaceResponse)
def get_workspace(
    workspace_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.workspaces, Action.read)
    row = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return row


@router.patch("/{workspace_id}", response_model=WorkspaceResponse)
def update_workspace(
    workspace_id: int,
    payload: WorkspaceUpdate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.workspaces, Action.update)
    row = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Workspace not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(row, field, value)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/{workspace_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_workspace(
    workspace_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.workspaces, Action.delete)
    row = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Workspace not found")
    db.delete(row)
    db.commit()
    return None
