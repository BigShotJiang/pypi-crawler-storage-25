import base64
from datetime import datetime, timezone
from io import BytesIO

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models.execution_job import ExecutionJob
from app.schemas.reports import ArtifactItemResponse, ArtifactListResponse, ExecutionLogsResponse, ExecutionReportResponse
from app.services import rbac as rbac_service
from app.services.auth_dependencies import require_auth_with_scopes

router = APIRouter(prefix="/reports", tags=["Reports"])


def _ensure_project_access(db: Session, project_id: int, user_id: int) -> None:
    rbac_service.ensure_project_exists(db, project_id)
    existing_members = rbac_service.list_project_members(db, project_id)
    if not existing_members:
        return

    membership = rbac_service.get_user_project_membership(db, project_id, user_id)
    if membership is None or membership.role not in rbac_service.READ_ROLES:
        raise HTTPException(status_code=403, detail="Insufficient project role")


def _get_execution_or_404(execution_id: int, db: Session) -> ExecutionJob:
    job = db.query(ExecutionJob).filter(ExecutionJob.id == execution_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Execution job not found")
    return job


def _result_payload(job: ExecutionJob) -> dict:
    return job.result_payload if isinstance(job.result_payload, dict) else {}


def _artifact_items(job: ExecutionJob) -> list[ArtifactItemResponse]:
    payload = _result_payload(job)
    raw_artifacts = payload.get("artifacts")
    if not isinstance(raw_artifacts, list):
        return []

    items: list[ArtifactItemResponse] = []
    for idx, raw in enumerate(raw_artifacts, start=1):
        if not isinstance(raw, dict):
            continue
        artifact_id = str(raw.get("id") or idx)
        filename = str(raw.get("filename") or f"artifact-{artifact_id}.bin")
        artifact_type = str(raw.get("type") or "generic")
        content_type = str(raw.get("content_type") or "application/octet-stream")
        content = raw.get("content")
        size_bytes = len(content.encode("utf-8")) if isinstance(content, str) else int(raw.get("size_bytes") or 0)
        items.append(
            ArtifactItemResponse(
                id=artifact_id,
                type=artifact_type,
                filename=filename,
                content_type=content_type,
                size_bytes=size_bytes,
                created_at=job.completed_at,
            )
        )
    return items


@router.get("/{execution_id}", response_model=ExecutionReportResponse)
def get_execution_report(
    execution_id: int,
    current_user=Depends(require_auth_with_scopes({"execution:read"})),
    db: Session = Depends(get_db),
):
    job = _get_execution_or_404(execution_id, db)
    _ensure_project_access(db, job.project_id, current_user.id)

    duration_seconds = 0.0
    if job.started_at and job.completed_at:
        duration_seconds = max(0.0, (job.completed_at - job.started_at).total_seconds())
    elif job.started_at:
        now = datetime.now(timezone.utc)
        if job.started_at.tzinfo is None:
            now = now.replace(tzinfo=None)
        duration_seconds = max(0.0, (now - job.started_at).total_seconds())

    payload = _result_payload(job)
    duration_seconds = float(payload.get("duration_seconds") or duration_seconds)

    return ExecutionReportResponse(
        execution_id=job.id,
        project_id=job.project_id,
        script_id=job.script_id,
        test_case_id=job.test_case_id,
        status=job.status,
        duration_seconds=duration_seconds,
        started_at=job.started_at,
        completed_at=job.completed_at,
        cancelled_at=job.cancelled_at,
        error_message=job.error_message,
    )


@router.get("/{execution_id}/logs", response_model=ExecutionLogsResponse)
def get_execution_logs(
    execution_id: int,
    current_user=Depends(require_auth_with_scopes({"execution:read"})),
    db: Session = Depends(get_db),
):
    job = _get_execution_or_404(execution_id, db)
    _ensure_project_access(db, job.project_id, current_user.id)

    payload = _result_payload(job)
    stdout = payload.get("stdout")
    stderr = payload.get("stderr")

    if not isinstance(stdout, str):
        stdout = ""
    if not isinstance(stderr, str):
        stderr = ""

    return ExecutionLogsResponse(execution_id=job.id, stdout=stdout, stderr=stderr)


@router.get("/{execution_id}/artifacts", response_model=ArtifactListResponse)
def list_execution_artifacts(
    execution_id: int,
    current_user=Depends(require_auth_with_scopes({"execution:read"})),
    db: Session = Depends(get_db),
):
    job = _get_execution_or_404(execution_id, db)
    _ensure_project_access(db, job.project_id, current_user.id)

    items = _artifact_items(job)
    return ArtifactListResponse(
        execution_id=job.id,
        retention_days=max(1, settings.ARTIFACT_RETENTION_DAYS),
        artifacts=items,
    )


@router.get("/{execution_id}/download/{artifact_id}")
def download_execution_artifact(
    execution_id: int,
    artifact_id: str,
    current_user=Depends(require_auth_with_scopes({"execution:read"})),
    db: Session = Depends(get_db),
):
    job = _get_execution_or_404(execution_id, db)
    _ensure_project_access(db, job.project_id, current_user.id)

    payload = _result_payload(job)
    raw_artifacts = payload.get("artifacts")
    if not isinstance(raw_artifacts, list):
        raise HTTPException(status_code=404, detail="Artifact not found")

    selected: dict | None = None
    for idx, raw in enumerate(raw_artifacts, start=1):
        if not isinstance(raw, dict):
            continue
        current_id = str(raw.get("id") or idx)
        if current_id == artifact_id:
            selected = raw
            break

    if selected is None:
        raise HTTPException(status_code=404, detail="Artifact not found")

    content = selected.get("content")
    if not isinstance(content, str):
        raise HTTPException(status_code=404, detail="Artifact content unavailable")

    encoding = str(selected.get("encoding") or "utf-8").lower()
    if encoding == "base64":
        try:
            raw_bytes = base64.b64decode(content, validate=True)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Invalid artifact encoding") from exc
    else:
        raw_bytes = content.encode("utf-8")

    filename = str(selected.get("filename") or f"artifact-{artifact_id}.bin")
    content_type = str(selected.get("content_type") or "application/octet-stream")

    response = StreamingResponse(BytesIO(raw_bytes), media_type=content_type)
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response
