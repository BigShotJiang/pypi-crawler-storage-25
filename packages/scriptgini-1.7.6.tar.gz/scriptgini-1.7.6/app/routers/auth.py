from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.auth import (
    UserRegisterRequest,
    UserLoginRequest,
    UserResponse,
    TokenResponse,
    RefreshTokenRequest,
    UserRoleUpdateRequest,
)
from app.services import auth as auth_service
from app.services.rate_limit import per_user_rate_limit
from app.services.auth_dependencies import get_current_user
from app.services.enterprise_rbac import Action, Resource, ensure_capability
from app.models.user import User

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(
    request: UserRegisterRequest,
    _rl=Depends(per_user_rate_limit(max_requests=5, window_seconds=60, scope="auth:register")),
    db: Session = Depends(get_db),
):
    """Register a new user.
    
    - **email**: User's email address
    - **password**: User's password (must be strong)
    """
    # Check if user already exists
    existing_user = auth_service.get_user_by_email(db, request.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered",
        )

    # Create new user
    user = auth_service.create_user(db, request.email, request.password)
    return user


@router.post("/login", response_model=TokenResponse)
def login(
    request: UserLoginRequest,
    _rl=Depends(per_user_rate_limit(max_requests=10, window_seconds=60, scope="auth:login")),
    db: Session = Depends(get_db),
):
    """Authenticate user and return access and refresh tokens.
    
    - **email**: User's email address
    - **password**: User's password
    """
    # Authenticate user
    user = auth_service.authenticate_user(db, request.email, request.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )

    # Create tokens
    access_token = auth_service.create_access_token(user.id, user.email)
    refresh_token = auth_service.create_refresh_token(user.id, user.email)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=60 * 30,  # 30 minutes in seconds
    )


@router.post("/refresh", response_model=TokenResponse)
def refresh_token(
    request: RefreshTokenRequest,
    _rl=Depends(per_user_rate_limit(max_requests=20, window_seconds=60, scope="auth:refresh")),
    db: Session = Depends(get_db),
):
    """Refresh access token using refresh token.
    
    - **refresh_token**: The refresh token from login response
    """
    # Verify refresh token
    token_data = auth_service.verify_token(request.refresh_token, token_type="refresh")
    if not token_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Verify user still exists and is active
    user = auth_service.get_user_by_id(db, token_data.user_id)
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Create new access and refresh tokens
    access_token = auth_service.create_access_token(user.id, user.email)
    new_refresh_token = auth_service.create_refresh_token(user.id, user.email)

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh_token,
        expires_in=60 * 30,  # 30 minutes in seconds
    )


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    _rl=Depends(per_user_rate_limit(max_requests=20, window_seconds=60, scope="auth:logout")),
):
    """Logout user (client-side token removal).
    
    This endpoint can be used to signal logout intent.
    Actual logout is handled client-side by removing the stored tokens.
    """
    # In a production system with token blacklisting,
    # we would add the token to a blacklist here
    return None


@router.get("/users", response_model=list[UserResponse])
def list_users(
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_management, Action.read)
    return db.query(User).order_by(User.id.asc()).all()


@router.patch("/users/{user_id}/role", response_model=UserResponse)
def update_user_role(
    user_id: int,
    payload: UserRoleUpdateRequest,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_management, Action.manage)
    user = auth_service.get_user_by_id(db, user_id)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    user.enterprise_role = payload.enterprise_role
    db.commit()
    db.refresh(user)
    return user
