from datetime import date, datetime, time, timezone

from sqlalchemy import case, func
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends, HTTPException

from app.database import get_db
from app.models.project import Project
from app.models.script_run import ScriptRun, ScriptRunStatus
from app.models.test_case import TestCase
from app.models.generated_script import GeneratedScript
from app.schemas.analytics import (
    CoverageModuleItem,
    CoverageResponse,
    CoverageTestCaseItem,
    FlakinessItemResponse,
    FlakinessResponse,
    RecentFailureResponse,
    RunAnalyticsResponse,
    TrendPointResponse,
    TrendsResponse,
)
from app.services import rbac as rbac_service
from app.services.auth_dependencies import require_optional_auth_with_scopes

router = APIRouter(prefix="/projects/{project_id}/analytics", tags=["Run Analytics"])
insights_router = APIRouter(prefix="/analytics", tags=["Run Analytics"])


@router.get("/runs", response_model=RunAnalyticsResponse)
def get_run_analytics(
    project_id: int,
    current_user=Depends(require_optional_auth_with_scopes({"analytics:read"})),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))

    aggregate = (
        db.query(
            func.count(ScriptRun.id),
            func.sum(case((ScriptRun.success.is_(True), 1), else_=0)),
            func.sum(case((ScriptRun.status == ScriptRunStatus.failed, 1), else_=0)),
            func.sum(case((ScriptRun.status == ScriptRunStatus.timed_out, 1), else_=0)),
            func.avg(ScriptRun.duration_seconds),
        )
        .filter(ScriptRun.project_id == project_id)
        .one()
    )

    total_runs = int(aggregate[0] or 0)
    success_runs = int(aggregate[1] or 0)
    failed_runs = int(aggregate[2] or 0)
    timed_out_runs = int(aggregate[3] or 0)
    avg_duration = float(aggregate[4] or 0.0)

    failed_items = (
        db.query(ScriptRun, TestCase.title)
        .outerjoin(TestCase, TestCase.id == ScriptRun.test_case_id)
        .filter(ScriptRun.project_id == project_id)
        .filter(ScriptRun.success.is_(False))
        .order_by(ScriptRun.created_at.desc(), ScriptRun.id.desc())
        .limit(10)
        .all()
    )

    recent_failures = [
        RecentFailureResponse(
            run_id=run.id,
            script_id=run.script_id,
            test_case_id=run.test_case_id,
            test_case_title=tc_title,
            exit_code=run.exit_code,
            duration_seconds=run.duration_seconds,
            stderr_excerpt=(run.stderr or "")[:240],
            created_at=run.created_at,
        )
        for run, tc_title in failed_items
    ]

    success_rate = round((success_runs / total_runs) * 100, 2) if total_runs else 0.0

    return RunAnalyticsResponse(
        project_id=project_id,
        total_runs=total_runs,
        success_runs=success_runs,
        failed_runs=failed_runs,
        timed_out_runs=timed_out_runs,
        success_rate=success_rate,
        average_duration_seconds=round(avg_duration, 2),
        recent_failures=recent_failures,
    )


def _resolve_datetime_range(start_date: date | None, end_date: date | None) -> tuple[datetime | None, datetime | None]:
    start_dt = datetime.combine(start_date, time.min, tzinfo=timezone.utc) if start_date else None
    end_dt = datetime.combine(end_date, time.max, tzinfo=timezone.utc) if end_date else None
    return start_dt, end_dt


@insights_router.get("/trends", response_model=TrendsResponse)
def get_trends(
    project_id: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    current_user=Depends(require_optional_auth_with_scopes({"analytics:read"})),
    db: Session = Depends(get_db),
):
    if project_id is not None:
        project = db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))

    start_dt, end_dt = _resolve_datetime_range(start_date, end_date)
    bucket_expr = func.date(ScriptRun.created_at)
    query = (
        db.query(
            bucket_expr.label("bucket"),
            func.count(ScriptRun.id).label("total_runs"),
            func.sum(case((ScriptRun.success.is_(True), 1), else_=0)).label("success_runs"),
            func.avg(ScriptRun.duration_seconds).label("avg_duration"),
        )
        .group_by(bucket_expr)
        .order_by(bucket_expr.asc())
    )

    if project_id is not None:
        query = query.filter(ScriptRun.project_id == project_id)
    if start_dt is not None:
        query = query.filter(ScriptRun.created_at >= start_dt)
    if end_dt is not None:
        query = query.filter(ScriptRun.created_at <= end_dt)

    points: list[TrendPointResponse] = []
    for row in query.all():
        total_runs = int(row.total_runs or 0)
        success_runs = int(row.success_runs or 0)
        success_rate = round((success_runs / total_runs) * 100, 2) if total_runs else 0.0
        points.append(
            TrendPointResponse(
                bucket=str(row.bucket),
                total_runs=total_runs,
                success_rate=success_rate,
                average_duration_seconds=round(float(row.avg_duration or 0.0), 2),
            )
        )

    return TrendsResponse(project_id=project_id, start_date=start_dt, end_date=end_dt, points=points)


@insights_router.get("/flakiness", response_model=FlakinessResponse)
def get_flakiness(
    project_id: int | None = None,
    start_date: date | None = None,
    end_date: date | None = None,
    min_runs: int = 3,
    current_user=Depends(require_optional_auth_with_scopes({"analytics:read"})),
    db: Session = Depends(get_db),
):
    if project_id is not None:
        project = db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))

    min_runs = max(1, min_runs)
    start_dt, end_dt = _resolve_datetime_range(start_date, end_date)

    query = db.query(
        ScriptRun.script_id.label("script_id"),
        ScriptRun.test_case_id.label("test_case_id"),
        func.count(ScriptRun.id).label("total_runs"),
        func.sum(case((ScriptRun.success.is_(False), 1), else_=0)).label("failed_runs"),
        func.max(case((ScriptRun.success.is_(False), ScriptRun.created_at), else_=None)).label("last_failure_at"),
    ).group_by(ScriptRun.script_id, ScriptRun.test_case_id)

    if project_id is not None:
        query = query.filter(ScriptRun.project_id == project_id)
    if start_dt is not None:
        query = query.filter(ScriptRun.created_at >= start_dt)
    if end_dt is not None:
        query = query.filter(ScriptRun.created_at <= end_dt)

    rows = query.having(func.count(ScriptRun.id) >= min_runs).all()
    items: list[FlakinessItemResponse] = []
    for row in rows:
        total_runs = int(row.total_runs or 0)
        failed_runs = int(row.failed_runs or 0)
        flakiness_score = round((failed_runs / total_runs) * 100, 2) if total_runs else 0.0
        confidence_score = round(min(1.0, total_runs / 10.0) * 100, 2)
        items.append(
            FlakinessItemResponse(
                script_id=int(row.script_id),
                test_case_id=int(row.test_case_id),
                total_runs=total_runs,
                failed_runs=failed_runs,
                flakiness_score=flakiness_score,
                confidence_score=confidence_score,
                last_failure_at=row.last_failure_at,
            )
        )

    items.sort(key=lambda item: (-item.flakiness_score, -item.confidence_score, -item.total_runs))
    return FlakinessResponse(
        project_id=project_id,
        start_date=start_dt,
        end_date=end_dt,
        min_runs=min_runs,
        items=items,
    )


@insights_router.get("/coverage", response_model=CoverageResponse)
def get_coverage(
    project_id: int | None = None,
    current_user=Depends(require_optional_auth_with_scopes({"analytics:read"})),
    db: Session = Depends(get_db),
):
    """Map test cases to scripted/executed/passed state, grouped by project module (derived from test case title prefix)."""
    if project_id is not None:
        project = db.query(Project).filter(Project.id == project_id).first()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))

    tc_query = db.query(TestCase)
    if project_id is not None:
        tc_query = tc_query.filter(TestCase.project_id == project_id)
    test_cases = tc_query.all()

    # Collect latest script per test_case_id
    script_query = db.query(GeneratedScript).order_by(GeneratedScript.test_case_id, GeneratedScript.id.desc())
    if project_id is not None:
        script_query = script_query.filter(GeneratedScript.project_id == project_id)
    scripted_by_tc: dict[int, GeneratedScript] = {}
    for gs in script_query.all():
        if gs.test_case_id not in scripted_by_tc:
            scripted_by_tc[gs.test_case_id] = gs

    # Collect latest run per test_case_id
    run_query = db.query(ScriptRun).order_by(ScriptRun.test_case_id, ScriptRun.id.desc())
    if project_id is not None:
        run_query = run_query.filter(ScriptRun.project_id == project_id)
    run_by_tc: dict[int, ScriptRun] = {}
    for sr in run_query.all():
        if sr.test_case_id not in run_by_tc:
            run_by_tc[sr.test_case_id] = sr

    # Group by module (first word of title or "General")
    modules_map: dict[str, list[CoverageTestCaseItem]] = {}
    for tc in test_cases:
        parts = tc.title.split()
        module = parts[0] if parts else "General"

        has_script = tc.id in scripted_by_tc
        has_run = tc.id in run_by_tc
        last_run_success: bool | None = None
        if has_run:
            last_run_success = run_by_tc[tc.id].success

        item = CoverageTestCaseItem(
            test_case_id=tc.id,
            title=tc.title,
            format=tc.format.value,
            has_script=has_script,
            has_run=has_run,
            last_run_success=last_run_success,
        )
        modules_map.setdefault(module, []).append(item)

    module_items: list[CoverageModuleItem] = []
    for module_name, cases in sorted(modules_map.items()):
        total = len(cases)
        scripted = sum(1 for c in cases if c.has_script)
        executed = sum(1 for c in cases if c.has_run)
        passed = sum(1 for c in cases if c.last_run_success is True)
        module_items.append(
            CoverageModuleItem(
                module=module_name,
                total_cases=total,
                scripted_cases=scripted,
                executed_cases=executed,
                passed_cases=passed,
                coverage_rate=round(scripted / total * 100, 2) if total else 0.0,
                execution_rate=round(executed / total * 100, 2) if total else 0.0,
                test_cases=cases,
            )
        )

    total_cases = len(test_cases)
    scripted_cases = sum(1 for tc in test_cases if tc.id in scripted_by_tc)
    executed_cases = sum(1 for tc in test_cases if tc.id in run_by_tc)
    passed_cases = sum(1 for tc in test_cases if run_by_tc.get(tc.id) and run_by_tc[tc.id].success)

    return CoverageResponse(
        project_id=project_id,
        total_cases=total_cases,
        scripted_cases=scripted_cases,
        executed_cases=executed_cases,
        passed_cases=passed_cases,
        overall_coverage_rate=round(scripted_cases / total_cases * 100, 2) if total_cases else 0.0,
        overall_execution_rate=round(executed_cases / total_cases * 100, 2) if total_cases else 0.0,
        modules=module_items,
    )
