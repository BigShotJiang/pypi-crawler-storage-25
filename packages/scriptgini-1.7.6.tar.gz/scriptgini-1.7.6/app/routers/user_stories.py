from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.project import Project
from app.models.user_story import UserStory
from app.schemas.user_story import UserStoryCreate, UserStoryResponse, UserStoryUpdate
from app.services.auth_dependencies import get_current_user
from app.services.enterprise_rbac import Action, Resource, ensure_capability

router = APIRouter(prefix="/projects/{project_id}/user-stories", tags=["User Stories"])


def _get_project_or_404(project_id: int, db: Session) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.post("/", response_model=UserStoryResponse, status_code=status.HTTP_201_CREATED)
def create_user_story(
    project_id: int,
    payload: UserStoryCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_stories, Action.create)
    _get_project_or_404(project_id, db)
    row = UserStory(project_id=project_id, **payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/", response_model=list[UserStoryResponse])
def list_user_stories(
    project_id: int,
    skip: int = 0,
    limit: int = 100,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_stories, Action.read)
    _get_project_or_404(project_id, db)
    return db.query(UserStory).filter(UserStory.project_id == project_id).offset(skip).limit(limit).all()


@router.get("/{story_id}", response_model=UserStoryResponse)
def get_user_story(
    project_id: int,
    story_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_stories, Action.read)
    _get_project_or_404(project_id, db)
    row = db.query(UserStory).filter(UserStory.project_id == project_id, UserStory.id == story_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="User story not found")
    return row


@router.patch("/{story_id}", response_model=UserStoryResponse)
def update_user_story(
    project_id: int,
    story_id: int,
    payload: UserStoryUpdate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_stories, Action.update)
    _get_project_or_404(project_id, db)
    row = db.query(UserStory).filter(UserStory.project_id == project_id, UserStory.id == story_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="User story not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(row, field, value)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/{story_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_user_story(
    project_id: int,
    story_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    ensure_capability(current_user, Resource.user_stories, Action.delete)
    _get_project_or_404(project_id, db)
    row = db.query(UserStory).filter(UserStory.project_id == project_id, UserStory.id == story_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="User story not found")
    db.delete(row)
    db.commit()
    return None
