from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.project import Project
from app.schemas.membership import ProjectMemberResponse, ProjectMemberUpsertRequest
from app.schemas.project import ProjectCreate, ProjectUpdate, ProjectResponse
from app.services import rbac as rbac_service
from app.services.auth_dependencies import require_auth_with_scopes, require_optional_auth_with_scopes

router = APIRouter(prefix="/projects", tags=["Projects"])


def _ensure_project_manager(db: Session, project_id: int, user_id: int) -> None:
    rbac_service.ensure_project_manager_access(db, project_id, user_id)


@router.post("/", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
def create_project(
    payload: ProjectCreate,
    current_user=Depends(require_optional_auth_with_scopes({"projects:write"})),
    db: Session = Depends(get_db),
):
    project = Project(**payload.model_dump())
    db.add(project)
    db.commit()
    db.refresh(project)

    # Auto-bootstrap project owner membership for authenticated creators.
    if current_user is not None:
        rbac_service.upsert_project_member(
            db=db,
            project_id=project.id,
            user_id=current_user.id,
            role=rbac_service.Role.owner,
            is_active=True,
        )

    return project


@router.get("/", response_model=list[ProjectResponse])
def list_projects(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    return db.query(Project).offset(skip).limit(limit).all()


@router.get("/{project_id}", response_model=ProjectResponse)
def get_project(
    project_id: int,
    current_user=Depends(require_optional_auth_with_scopes({"projects:read"})),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))
    return project


@router.patch("/{project_id}", response_model=ProjectResponse)
def update_project(
    project_id: int,
    payload: ProjectUpdate,
    current_user=Depends(require_optional_auth_with_scopes({"projects:write"})),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    rbac_service.ensure_project_manager_access(db, project_id, getattr(current_user, "id", None))
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(project, field, value)
    db.commit()
    db.refresh(project)
    return project


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project(
    project_id: int,
    current_user=Depends(require_optional_auth_with_scopes({"projects:write"})),
    db: Session = Depends(get_db),
):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    rbac_service.ensure_project_manager_access(db, project_id, getattr(current_user, "id", None))
    db.delete(project)
    db.commit()


@router.get("/{project_id}/members", response_model=list[ProjectMemberResponse])
def list_project_members(
    project_id: int,
    current_user=Depends(require_auth_with_scopes({"members:read"})),
    db: Session = Depends(get_db),
):
    rbac_service.ensure_project_read_access(db, project_id, current_user.id)
    return rbac_service.list_project_members(db, project_id)


@router.put("/{project_id}/members/{user_id}", response_model=ProjectMemberResponse)
def upsert_project_member(
    project_id: int,
    user_id: int,
    payload: ProjectMemberUpsertRequest,
    current_user=Depends(require_auth_with_scopes({"members:write"})),
    db: Session = Depends(get_db),
):
    rbac_service.ensure_project_exists(db, project_id)
    _ensure_project_manager(db, project_id, current_user.id)

    return rbac_service.upsert_project_member(
        db=db,
        project_id=project_id,
        user_id=user_id,
        role=payload.role,
        is_active=payload.is_active,
    )


@router.delete("/{project_id}/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_project_member(
    project_id: int,
    user_id: int,
    current_user=Depends(require_auth_with_scopes({"members:write"})),
    db: Session = Depends(get_db),
):
    rbac_service.ensure_project_exists(db, project_id)
    _ensure_project_manager(db, project_id, current_user.id)

    if not rbac_service.remove_project_member(db, project_id, user_id):
        raise HTTPException(status_code=404, detail="Project member not found")

    return None
