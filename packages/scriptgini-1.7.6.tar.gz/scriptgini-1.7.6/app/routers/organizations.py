from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas.organization import OrganizationCreate, OrganizationResponse
from app.services.auth_dependencies import require_auth_with_scopes
from app.services import rbac as rbac_service

router = APIRouter(prefix="/organizations", tags=["Organizations"])


@router.post("", response_model=OrganizationResponse, status_code=status.HTTP_201_CREATED)
def create_organization(
    payload: OrganizationCreate,
    current_user=Depends(require_auth_with_scopes({"org:write"})),
    db: Session = Depends(get_db),
):
    try:
        return rbac_service.create_organization(
            db=db,
            user_id=current_user.id,
            name=payload.name,
            description=payload.description,
        )
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(status_code=400, detail="Organization already exists") from exc


@router.get("", response_model=list[OrganizationResponse])
def list_organizations(
    current_user=Depends(require_auth_with_scopes({"org:read"})),
    db: Session = Depends(get_db),
):
    return rbac_service.list_user_organizations(db, current_user.id)
