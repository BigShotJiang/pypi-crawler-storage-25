import logging
import subprocess
import sys

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.agents.script_gini_agent import run_agent
from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobItemStatus, BulkJobKind, BulkJobStatus
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.models.project import Project
from app.models.script_run import ScriptRunStatus
from app.models.test_case import TestCase
from app.schemas.bulk_job import BulkGenerateRequest, BulkJobResponse, BulkRunRequest
from app.tasks import process_bulk_execution_job, process_bulk_generation_job
from app.routers.scripts import (
    _create_script_run,
    _get_project_or_404,
    _run_python_script,
)
from app.services import rbac as rbac_service
from app.services.auth_dependencies import require_optional_auth_with_scopes
from app.services.rate_limit import per_user_rate_limit

router = APIRouter(prefix="/projects/{project_id}/scripts", tags=["Bulk Jobs"])
logger = logging.getLogger(__name__)


def _get_bulk_job_or_404(project_id: int, job_id: int, db: Session) -> BulkJob:
    job = db.query(BulkJob).filter(BulkJob.id == job_id, BulkJob.project_id == project_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Bulk job not found")
    return job


def _refresh_job_counts(job: BulkJob, db: Session) -> None:
    items = db.query(BulkJobItem).filter(BulkJobItem.job_id == job.id).all()
    job.total_items = len(items)
    job.completed_items = sum(1 for i in items if i.status == BulkJobItemStatus.completed)
    job.failed_items = sum(1 for i in items if i.status == BulkJobItemStatus.failed)
    job.skipped_items = sum(1 for i in items if i.status == BulkJobItemStatus.skipped)


def _serialize_bulk_job(job: BulkJob, db: Session) -> BulkJobResponse:
    items = (
        db.query(BulkJobItem)
        .filter(BulkJobItem.job_id == job.id)
        .order_by(BulkJobItem.created_at.asc(), BulkJobItem.id.asc())
        .all()
    )
    payload = BulkJobResponse.model_validate(job)
    payload.items = items
    return payload


def _resolve_test_cases(project_id: int, ids: list[int] | None, db: Session) -> list[TestCase]:
    query = db.query(TestCase).filter(TestCase.project_id == project_id)
    if ids:
        query = query.filter(TestCase.id.in_(ids))
    return query.order_by(TestCase.id.asc()).all()


def _run_bulk_generation(job_id: int, request: BulkGenerateRequest):
    from app.database import SessionLocal

    db = SessionLocal()
    try:
        job = db.query(BulkJob).filter(BulkJob.id == job_id).first()
        if not job:
            return
        job.status = BulkJobStatus.running
        db.commit()

        project = db.query(Project).filter(Project.id == job.project_id).first()
        if not project:
            job.status = BulkJobStatus.failed
            db.commit()
            return

        items = db.query(BulkJobItem).filter(BulkJobItem.job_id == job.id).order_by(BulkJobItem.id.asc()).all()
        framework = (request.framework or project.default_framework).value

        for item in items:
            tc = db.query(TestCase).filter(TestCase.id == item.test_case_id, TestCase.project_id == job.project_id).first()
            if not tc:
                item.status = BulkJobItemStatus.skipped
                item.message = "Test case not found"
                db.commit()
                continue

            item.status = BulkJobItemStatus.running
            db.commit()

            script_record = GeneratedScript(
                project_id=job.project_id,
                test_case_id=tc.id,
                framework=framework,
                llm_provider=request.llm_provider,
                llm_model=request.llm_model or "",
                status=ScriptStatus.generating,
            )
            db.add(script_record)
            db.commit()
            db.refresh(script_record)

            try:
                result = run_agent(
                    test_case_title=tc.title,
                    test_case_content=tc.content,
                    preconditions=tc.preconditions or "",
                    test_data_hints=tc.test_data_hints or "",
                    aut_base_url=project.aut_base_url,
                    framework=framework,
                    auth_hints=project.auth_hints or "",
                    llm_provider=request.llm_provider,
                    llm_model=request.llm_model,
                )
                script_record.script_content = result.get("script")
                script_record.error_message = result.get("error")
                script_record.token_usage = result.get("token_usage")
                script_record.status = ScriptStatus.failed if result.get("error") else ScriptStatus.completed
                item.status = BulkJobItemStatus.failed if result.get("error") else BulkJobItemStatus.completed
                item.message = result.get("error")
            except Exception as exc:
                logger.exception("Bulk generate failed for test_case_id=%s", tc.id)
                script_record.status = ScriptStatus.failed
                script_record.error_message = str(exc)
                item.status = BulkJobItemStatus.failed
                item.message = str(exc)

            item.script_id = script_record.id
            db.commit()

        _refresh_job_counts(job, db)
        job.status = BulkJobStatus.failed if job.failed_items > 0 else BulkJobStatus.completed
        db.commit()
    finally:
        db.close()


def _run_bulk_execution(job_id: int, request: BulkRunRequest):
    from app.database import SessionLocal

    db = SessionLocal()
    try:
        job = db.query(BulkJob).filter(BulkJob.id == job_id).first()
        if not job:
            return
        job.status = BulkJobStatus.running
        db.commit()

        items = db.query(BulkJobItem).filter(BulkJobItem.job_id == job.id).order_by(BulkJobItem.id.asc()).all()
        for item in items:
            item.status = BulkJobItemStatus.running
            db.commit()

            latest_script = (
                db.query(GeneratedScript)
                .filter(
                    GeneratedScript.project_id == job.project_id,
                    GeneratedScript.test_case_id == item.test_case_id,
                    GeneratedScript.status == ScriptStatus.completed,
                )
                .order_by(GeneratedScript.created_at.desc(), GeneratedScript.id.desc())
                .first()
            )
            if not latest_script:
                item.status = BulkJobItemStatus.skipped
                item.message = "No completed script available"
                db.commit()
                continue

            item.script_id = latest_script.id
            if latest_script.framework != "playwright_python":
                item.status = BulkJobItemStatus.skipped
                item.message = "Only playwright_python scripts can be executed"
                db.commit()
                continue

            try:
                run_result = _run_python_script(latest_script.script_content or "")
                status = ScriptRunStatus.completed if run_result["success"] else ScriptRunStatus.failed
                _create_script_run(db, latest_script, run_result, status)
                item.status = BulkJobItemStatus.completed if run_result["success"] else BulkJobItemStatus.failed
                item.message = None if run_result["success"] else "Scenario run failed"
            except ValueError as exc:
                run_result = {
                    "success": False,
                    "exit_code": 2,
                    "stdout": "",
                    "stderr": str(exc),
                    "duration_seconds": 0.0,
                    "command": f"{sys.executable} generated_scenario.py",
                }
                _create_script_run(db, latest_script, run_result, ScriptRunStatus.failed)
                item.status = BulkJobItemStatus.failed
                item.message = str(exc)
            except subprocess.TimeoutExpired as exc:
                run_result = {
                    "success": False,
                    "exit_code": 124,
                    "stdout": exc.stdout or "",
                    "stderr": (exc.stderr or "") + f"\nScript execution timed out after {exc.timeout} seconds",
                    "duration_seconds": float(exc.timeout),
                    "command": f"{sys.executable} generated_scenario.py",
                }
                _create_script_run(db, latest_script, run_result, ScriptRunStatus.timed_out)
                item.status = BulkJobItemStatus.failed
                item.message = f"Timed out after {exc.timeout} seconds"

            db.commit()

        _refresh_job_counts(job, db)
        job.status = BulkJobStatus.failed if job.failed_items > 0 else BulkJobStatus.completed
        db.commit()
    finally:
        db.close()


@router.post("/bulk-generate", response_model=BulkJobResponse, status_code=status.HTTP_202_ACCEPTED)
def bulk_generate_scripts(
    project_id: int,
    payload: BulkGenerateRequest,
    _rl=Depends(per_user_rate_limit(max_requests=10, window_seconds=60, scope="bulk:generate")),
    current_user=Depends(require_optional_auth_with_scopes({"bulk-jobs:write"})),
    db: Session = Depends(get_db),
):
    _get_project_or_404(project_id, db)
    rbac_service.ensure_project_manager_access(db, project_id, getattr(current_user, "id", None))
    test_cases = _resolve_test_cases(project_id, payload.test_case_ids, db)
    if not test_cases:
        raise HTTPException(status_code=400, detail="No test cases found for bulk generation")

    job = BulkJob(project_id=project_id, kind=BulkJobKind.generate, status=BulkJobStatus.pending)
    db.add(job)
    db.commit()
    db.refresh(job)

    for tc in test_cases:
        db.add(BulkJobItem(job_id=job.id, test_case_id=tc.id, status=BulkJobItemStatus.pending))
    db.commit()

    _refresh_job_counts(job, db)
    db.commit()

    try:
        process_bulk_generation_job.delay(job.id, payload.model_dump())
    except Exception as exc:
        logger.exception("Failed to enqueue bulk generation job_id=%s", job.id)
        job.status = BulkJobStatus.failed
        db.commit()
        raise HTTPException(status_code=503, detail="Failed to enqueue bulk generation") from exc

    return _serialize_bulk_job(job, db)


@router.post("/bulk-run", response_model=BulkJobResponse, status_code=status.HTTP_202_ACCEPTED)
def bulk_run_scripts(
    project_id: int,
    payload: BulkRunRequest,
    _rl=Depends(per_user_rate_limit(max_requests=10, window_seconds=60, scope="bulk:run")),
    current_user=Depends(require_optional_auth_with_scopes({"bulk-jobs:write"})),
    db: Session = Depends(get_db),
):
    _get_project_or_404(project_id, db)
    rbac_service.ensure_project_manager_access(db, project_id, getattr(current_user, "id", None))
    test_cases = _resolve_test_cases(project_id, payload.test_case_ids, db)
    if not test_cases:
        raise HTTPException(status_code=400, detail="No test cases found for bulk run")

    job = BulkJob(project_id=project_id, kind=BulkJobKind.run, status=BulkJobStatus.pending)
    db.add(job)
    db.commit()
    db.refresh(job)

    for tc in test_cases:
        db.add(BulkJobItem(job_id=job.id, test_case_id=tc.id, status=BulkJobItemStatus.pending))
    db.commit()

    _refresh_job_counts(job, db)
    db.commit()

    try:
        process_bulk_execution_job.delay(job.id, payload.model_dump())
    except Exception as exc:
        logger.exception("Failed to enqueue bulk run job_id=%s", job.id)
        job.status = BulkJobStatus.failed
        db.commit()
        raise HTTPException(status_code=503, detail="Failed to enqueue bulk run") from exc

    return _serialize_bulk_job(job, db)


@router.get("/bulk-jobs/{job_id}", response_model=BulkJobResponse)
def get_bulk_job(
    project_id: int,
    job_id: int,
    current_user=Depends(require_optional_auth_with_scopes({"bulk-jobs:read"})),
    db: Session = Depends(get_db),
):
    _get_project_or_404(project_id, db)
    rbac_service.ensure_project_read_access(db, project_id, getattr(current_user, "id", None))
    job = _get_bulk_job_or_404(project_id, job_id, db)
    return _serialize_bulk_job(job, db)
