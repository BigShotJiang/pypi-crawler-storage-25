from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.project import Project
from app.models.test_case import TestCase, TestCaseFormat

router = APIRouter(prefix="/demo", tags=["Demo"])

_DEMO_PROJECT_NAME = "Demo Retail Checkout"
_DEMO_AUT_BASE_URL = "https://demo.retail-checkout.local"

_DEMO_TEST_CASES = [
    {
        "title": "TC-001 Successful Login",
        "format": TestCaseFormat.step_based,
        "content": (
            "Step 1: Navigate to /login\n"
            "Step 2: Enter valid username and password\n"
            "Step 3: Click Login\n"
            "Expected: User is redirected to /dashboard"
        ),
        "preconditions": "Valid user account exists",
        "test_data_hints": "username=demo.user, password=Demo@123",
    },
    {
        "title": "TC-002 Add Product To Cart",
        "format": TestCaseFormat.step_based,
        "content": (
            "Step 1: Navigate to /products\n"
            "Step 2: Open a product detail page\n"
            "Step 3: Click Add to Cart\n"
            "Expected: Cart badge count increases by 1"
        ),
        "preconditions": "User is logged in",
        "test_data_hints": "product=Basic Tee",
    },
    {
        "title": "TC-003 Checkout Confirmation",
        "format": TestCaseFormat.bdd,
        "content": (
            "Given a logged-in user with items in cart\n"
            "When the user completes checkout with valid payment details\n"
            "Then an order confirmation message is displayed"
        ),
        "preconditions": "At least one item is present in cart",
        "test_data_hints": "payment_method=card",
    },
]


@router.post("/load", status_code=status.HTTP_201_CREATED)
def load_demo_project(db: Session = Depends(get_db)):
    existing = db.query(Project).filter(Project.name == _DEMO_PROJECT_NAME).first()
    if existing:
        existing_count = db.query(TestCase).filter(TestCase.project_id == existing.id).count()
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "created": False,
                "project_id": existing.id,
                "project_name": existing.name,
                "test_case_count": existing_count,
            },
        )

    project = Project(
        name=_DEMO_PROJECT_NAME,
        aut_base_url=_DEMO_AUT_BASE_URL,
        auth_hints="Use demo credentials on /login when needed.",
    )
    db.add(project)
    db.commit()
    db.refresh(project)

    for item in _DEMO_TEST_CASES:
        db.add(TestCase(project_id=project.id, **item))
    db.commit()

    return {
        "created": True,
        "project_id": project.id,
        "project_name": project.name,
        "test_case_count": len(_DEMO_TEST_CASES),
    }
