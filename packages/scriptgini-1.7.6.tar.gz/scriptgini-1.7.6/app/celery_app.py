try:
    from celery import Celery
except ModuleNotFoundError:  # pragma: no cover - fallback for test environments without celery installed
    from types import SimpleNamespace

    class _TaskWrapper:
        def __init__(self, func, *, bind: bool = False, max_retries: int | None = None):
            self._func = func
            self.bind = bind
            self.max_retries = max_retries if max_retries is not None else 0

        def _self_proxy(self):
            return SimpleNamespace(
                request=SimpleNamespace(retries=0),
                max_retries=self.max_retries,
                retry=self._retry,
            )

        def _retry(self, exc=None, **kwargs):
            if exc is not None:
                raise exc
            raise RuntimeError("Celery retry requested")

        def run(self, *args, **kwargs):
            if self.bind:
                return self._func(self._self_proxy(), *args, **kwargs)
            return self._func(*args, **kwargs)

        def delay(self, *args, **kwargs):
            return SimpleNamespace(id="stub-task", result=None)

        def apply(self, args=None, kwargs=None):
            args = args or ()
            kwargs = kwargs or {}
            return SimpleNamespace(result=self.run(*args, **kwargs))

        def __call__(self, *args, **kwargs):
            return self.run(*args, **kwargs)

    class Celery:  # type: ignore[override]
        def __init__(self, *args, **kwargs):
            self.conf = self._Conf()
            self.control = SimpleNamespace(revoke=lambda *a, **k: None)
            self.AsyncResult = lambda task_id: SimpleNamespace(id=task_id, state="PENDING", result=None, info=None)

        class _Conf:
            def update(self, *args, **kwargs):
                for mapping in args:
                    if isinstance(mapping, dict):
                        for key, value in mapping.items():
                            setattr(self, key, value)
                for key, value in kwargs.items():
                    setattr(self, key, value)
                return None

        def task(self, *decorator_args, **decorator_kwargs):
            def decorator(func):
                wrapper = _TaskWrapper(
                    func,
                    bind=bool(decorator_kwargs.get("bind", False)),
                    max_retries=decorator_kwargs.get("max_retries"),
                )
                wrapper.__name__ = getattr(func, "__name__", "task")
                wrapper.__doc__ = getattr(func, "__doc__", None)
                return wrapper

            if decorator_args and callable(decorator_args[0]) and len(decorator_args) == 1 and not decorator_kwargs:
                return decorator(decorator_args[0])
            return decorator
from app.config import settings

# Initialize Celery app
celery_app = Celery(
    settings.APP_NAME,
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

# Configure Celery
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=settings.CELERY_TASK_HARD_TIMEOUT,
    task_soft_time_limit=settings.CELERY_TASK_TIMEOUT,
    worker_prefetch_multiplier=4,
    worker_max_tasks_per_child=1000,
)


@celery_app.task(bind=True, max_retries=settings.CELERY_MAX_RETRIES)
def debug_task(self):
    """Test task to verify Celery is working."""
    print(f"Request: {self.request!r}")
    return "Celery is working!"
