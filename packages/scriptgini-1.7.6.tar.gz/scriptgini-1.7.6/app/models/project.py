import enum
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, Enum as SAEnum, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class TestFramework(str, enum.Enum):
    playwright_python = "playwright_python"
    selenium_python = "selenium_python"
    uft_vbscript = "uft_vbscript"
    cypress_js = "cypress_js"


class SelectorPreference(str, enum.Enum):
    role = "role"
    label = "label"
    testid = "testid"
    css = "css"
    xpath = "xpath"


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    organization_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id"), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    aut_base_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    default_framework: Mapped[TestFramework] = mapped_column(
        SAEnum(TestFramework), default=TestFramework.playwright_python, nullable=False
    )
    selector_preference: Mapped[SelectorPreference] = mapped_column(
        SAEnum(SelectorPreference), default=SelectorPreference.role, nullable=False
    )
    auth_hints: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

