import enum
from datetime import datetime, timezone

from sqlalchemy import String, Text, DateTime, ForeignKey, Enum as SAEnum, Integer
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class RevisionChangeType(str, enum.Enum):
    generated = "generated"
    refactored = "refactored"
    rolled_back = "rolled_back"


class ScriptRevision(Base):
    __tablename__ = "script_revisions"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    script_id: Mapped[int] = mapped_column(
        ForeignKey("generated_scripts.id", ondelete="CASCADE"), nullable=False, index=True
    )
    project_id: Mapped[int] = mapped_column(
        ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    test_case_id: Mapped[int] = mapped_column(
        ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False, index=True
    )
    revision_number: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    script_content: Mapped[str] = mapped_column(Text, nullable=False)
    change_type: Mapped[RevisionChangeType] = mapped_column(
        SAEnum(RevisionChangeType), default=RevisionChangeType.generated, nullable=False
    )
    change_summary: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
