from datetime import datetime, timezone
import enum

from sqlalchemy import String, Boolean, DateTime, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class EnterpriseRole(str, enum.Enum):
    platform_admin = "PlatformAdmin"
    tenant_admin = "TenantAdmin"
    qa_manager = "QA Manager"
    qa_test_lead = "QA Test Lead"
    qa_engineer = "QA Engineer"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    enterprise_role: Mapped[EnterpriseRole] = mapped_column(
        SAEnum(
            EnterpriseRole,
            values_callable=lambda enum_cls: [member.value for member in enum_cls],
            name="enterpriserole",
        ),
        default=EnterpriseRole.qa_engineer,
        nullable=False,
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    # Relationships
    api_keys: Mapped[list["APIKey"]] = relationship("APIKey", back_populates="user", cascade="all, delete-orphan")


# Avoid circular imports - this will be set up in api_key.py
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from app.models.api_key import APIKey

# Ensure APIKey is registered with SQLAlchemy's class registry at runtime.
# Without this import, User(api_keys relationship) can fail during mapper
# configuration when creating/registering a new user.
from app.models.api_key import APIKey  # noqa: F401
