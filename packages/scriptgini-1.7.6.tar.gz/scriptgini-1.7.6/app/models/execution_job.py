import enum
from datetime import datetime, timezone

from sqlalchemy import DateTime, Enum as SAEnum, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class ExecutionJobStatus(str, enum.Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


_ALLOWED_TRANSITIONS: dict[ExecutionJobStatus, set[ExecutionJobStatus]] = {
    ExecutionJobStatus.pending: {
        ExecutionJobStatus.running,
        ExecutionJobStatus.completed,
        ExecutionJobStatus.failed,
        ExecutionJobStatus.cancelled,
    },
    ExecutionJobStatus.running: {
        ExecutionJobStatus.completed,
        ExecutionJobStatus.failed,
        ExecutionJobStatus.cancelled,
    },
    ExecutionJobStatus.completed: set(),
    ExecutionJobStatus.failed: set(),
    ExecutionJobStatus.cancelled: set(),
}


class ExecutionJob(Base):
    __tablename__ = "execution_jobs"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    script_id: Mapped[int] = mapped_column(ForeignKey("generated_scripts.id", ondelete="CASCADE"), nullable=False, index=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id", ondelete="CASCADE"), nullable=False, index=True)
    created_by_user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    status: Mapped[ExecutionJobStatus] = mapped_column(
        SAEnum(ExecutionJobStatus), nullable=False, default=ExecutionJobStatus.pending
    )
    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True, unique=True, index=True)
    celery_task_id: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    request_payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    result_payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )


def can_transition(current: ExecutionJobStatus, new_status: ExecutionJobStatus) -> bool:
    if current == new_status:
        return True
    return new_status in _ALLOWED_TRANSITIONS[current]
