"""
LLM Provider Factory for ScriptGini.

Supports: OpenAI, Ollama (local), OpenRouter, Google Gemini, AWS Bedrock.
Each provider returns a LangChain BaseChatModel so the agent layer is
provider-agnostic.
"""
from __future__ import annotations

import hashlib
import logging
from typing import Literal

from langchain_core.language_models import BaseChatModel

from app.config import settings

LLMProvider = Literal["openai", "ollama", "openrouter", "gemini", "bedrock"]
logger = logging.getLogger(__name__)


def _mask_secret(secret: str) -> str:
    value = (secret or "").strip()
    if not value:
        return "<missing>"
    if len(value) <= 8:
        return "****"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
    return f"{value[:4]}...{value[-4:]}(len={len(value)},sha256={digest})"


def _provider_secret(provider: LLMProvider) -> tuple[str | None, str]:
    if provider == "openai":
        return "OPENAI_API_KEY", settings.OPENAI_API_KEY
    if provider == "openrouter":
        return "OPENROUTER_API_KEY", settings.OPENROUTER_API_KEY
    if provider == "gemini":
        return "GOOGLE_API_KEY", settings.GOOGLE_API_KEY
    return None, ""


def _default_model_for_provider(provider: LLMProvider) -> str:
    if provider == "openai":
        return settings.OPENAI_MODEL
    if provider == "ollama":
        return settings.OLLAMA_MODEL
    if provider == "openrouter":
        return settings.OPENROUTER_MODEL
    if provider == "gemini":
        return settings.GEMINI_MODEL
    return settings.BEDROCK_MODEL_ID


def get_llm_diagnostics(provider: LLMProvider | None = None, model: str | None = None) -> dict[str, str | bool]:
    resolved_provider: LLMProvider = provider or settings.DEFAULT_LLM_PROVIDER
    resolved_model = model or _default_model_for_provider(resolved_provider)
    secret_env, secret_value = _provider_secret(resolved_provider)
    has_secret = bool(secret_value.strip()) if secret_env else True
    return {
        "provider": resolved_provider,
        "model": resolved_model,
        "api_key_env": secret_env or "<not-required>",
        "api_key_present": has_secret,
        "api_key_masked": _mask_secret(secret_value) if secret_env else "<not-required>",
    }


def get_llm(
    provider: LLMProvider | None = None,
    *,
    model: str | None = None,
    temperature: float = 0.1,
) -> BaseChatModel:
    """
    Return a LangChain chat model for the requested provider.

    Args:
        provider: One of 'openai', 'ollama', 'openrouter', 'gemini', 'bedrock'.
                  Defaults to settings.DEFAULT_LLM_PROVIDER.
        model:    Override the model name. Falls back to per-provider default.
        temperature: Sampling temperature (low value keeps output deterministic).
    """
    provider = provider or settings.DEFAULT_LLM_PROVIDER
    diagnostics = get_llm_diagnostics(provider, model)
    logger.info(
        "LLM pick: provider=%s model=%s api_key_env=%s api_key_present=%s api_key=%s",
        diagnostics["provider"],
        diagnostics["model"],
        diagnostics["api_key_env"],
        diagnostics["api_key_present"],
        diagnostics["api_key_masked"],
    )

    if provider == "openai":
        return _openai(model or settings.OPENAI_MODEL, temperature)
    if provider == "ollama":
        return _ollama(model or settings.OLLAMA_MODEL, temperature)
    if provider == "openrouter":
        return _openrouter(model or settings.OPENROUTER_MODEL, temperature)
    if provider == "gemini":
        return _gemini(model or settings.GEMINI_MODEL, temperature)
    if provider == "bedrock":
        return _bedrock(model or settings.BEDROCK_MODEL_ID, temperature)

    raise ValueError(f"Unknown LLM provider: {provider!r}")


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

def _openai(model: str, temperature: float) -> BaseChatModel:
    from langchain_openai import ChatOpenAI

    kwargs = {
        "model": model,
        "temperature": temperature,
        "timeout": settings.LLM_REQUEST_TIMEOUT_SECONDS,
    }
    if settings.OPENAI_API_KEY.strip():
        kwargs["api_key"] = settings.OPENAI_API_KEY

    return ChatOpenAI(
        **kwargs,
    )


def _ollama(model: str, temperature: float) -> BaseChatModel:
    from langchain_ollama import ChatOllama

    timeout_seconds = settings.OLLAMA_REQUEST_TIMEOUT_SECONDS
    return ChatOllama(
        model=model,
        temperature=temperature,
        base_url=settings.OLLAMA_BASE_URL,
        num_predict=settings.OLLAMA_NUM_PREDICT,
        sync_client_kwargs={"timeout": timeout_seconds},
        async_client_kwargs={"timeout": timeout_seconds},
    )


def _openrouter(model: str, temperature: float) -> BaseChatModel:
    # OpenRouter exposes an OpenAI-compatible API endpoint.
    from langchain_openai import ChatOpenAI

    kwargs = {
        "model": model,
        "temperature": temperature,
        "base_url": settings.OPENROUTER_BASE_URL,
        "timeout": settings.LLM_REQUEST_TIMEOUT_SECONDS,
        "default_headers": {
            "HTTP-Referer": "https://scriptgini.local",
            "X-Title": "ScriptGini",
        },
    }
    if settings.OPENROUTER_API_KEY.strip():
        kwargs["api_key"] = settings.OPENROUTER_API_KEY

    return ChatOpenAI(
        **kwargs,
    )


def _gemini(model: str, temperature: float) -> BaseChatModel:
    from langchain_google_genai import ChatGoogleGenerativeAI

    normalized_model = model.removeprefix("models/")

    kwargs = {
        "model": normalized_model,
        "temperature": temperature,
    }
    if settings.GOOGLE_API_KEY.strip():
        kwargs["google_api_key"] = settings.GOOGLE_API_KEY

    return ChatGoogleGenerativeAI(**kwargs)


def _bedrock(model: str, temperature: float) -> BaseChatModel:
    import boto3
    from langchain_aws import ChatBedrock

    boto_session = boto3.Session(
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID or None,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY or None,
        region_name=settings.AWS_REGION_NAME,
    )
    return ChatBedrock(
        model_id=model,
        client=boto_session.client("bedrock-runtime"),
        model_kwargs={"temperature": temperature},
    )
