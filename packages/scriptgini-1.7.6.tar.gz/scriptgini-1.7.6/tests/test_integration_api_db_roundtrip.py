"""Integration tests for API <-> database persistence round trips.

These tests avoid mocking service/database behavior and validate that writes done
through API endpoints are actually persisted and retrievable.
"""

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
import pytest

# Ensure models are imported so tables are registered on Base.metadata.
import app.models.api_key  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.organization  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_revision  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app
from app.models.project import Project
from app.models.user import User

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


def test_register_user_persists_and_can_login(client: TestClient):
    email = "int_user_roundtrip@test.com"
    password = "TestPassword123!"

    register_resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password},
    )
    assert register_resp.status_code == 201
    user_id = register_resp.json()["id"]

    # Validate persistence directly at DB level.
    db = TestingSessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        assert user is not None
        assert user.email == email
        assert user.is_active is True
    finally:
        db.close()

    # Validate round-trip via API by logging in with persisted credentials.
    login_resp = client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    assert login_resp.status_code == 200
    body = login_resp.json()
    assert body.get("access_token")
    assert body.get("refresh_token")


def test_register_duplicate_email_rejected_and_db_count_unchanged(client: TestClient):
    email = "int_dup_roundtrip@test.com"
    password = "TestPassword123!"

    first = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert first.status_code == 201

    db = TestingSessionLocal()
    try:
        before_count = db.query(User).filter(User.email == email).count()
        assert before_count == 1
    finally:
        db.close()

    second = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert second.status_code == 400

    db = TestingSessionLocal()
    try:
        after_count = db.query(User).filter(User.email == email).count()
        assert after_count == 1
    finally:
        db.close()


def test_project_create_get_delete_roundtrip_persists(client: TestClient):
    create_resp = client.post(
        "/api/v1/projects/",
        json={
            "name": "Integration Roundtrip Project",
            "aut_base_url": "https://example.com",
            "default_framework": "playwright_python",
            "selector_preference": "role",
        },
    )
    assert create_resp.status_code == 201
    project = create_resp.json()
    project_id = project["id"]

    # Validate DB persistence.
    db = TestingSessionLocal()
    try:
        row = db.query(Project).filter(Project.id == project_id).first()
        assert row is not None
        assert row.name == "Integration Roundtrip Project"
        assert row.aut_base_url == "https://example.com"
    finally:
        db.close()

    # Validate API read-back of the same record.
    get_resp = client.get(f"/api/v1/projects/{project_id}")
    assert get_resp.status_code == 200
    assert get_resp.json()["id"] == project_id
    assert get_resp.json()["name"] == "Integration Roundtrip Project"

    # Delete and ensure both API and DB no longer contain the record.
    delete_resp = client.delete(f"/api/v1/projects/{project_id}")
    assert delete_resp.status_code == 204

    db = TestingSessionLocal()
    try:
        deleted = db.query(Project).filter(Project.id == project_id).first()
        assert deleted is None
    finally:
        db.close()

    get_after_delete = client.get(f"/api/v1/projects/{project_id}")
    assert get_after_delete.status_code == 404
