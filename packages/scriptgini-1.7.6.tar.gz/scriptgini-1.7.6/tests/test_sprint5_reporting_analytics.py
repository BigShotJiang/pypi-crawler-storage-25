from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.api_key  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401
from app import tasks

from app.database import Base, get_db
from app.main import app as fastapi_app
from app.models.execution_job import ExecutionJob, ExecutionJobStatus
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.models.membership import ProjectMembership, Role
from app.models.script_run import ScriptRun, ScriptRunStatus

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app)


def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> tuple[int, dict[str, str]]:
    register_resp = client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password},
    )
    assert register_resp.status_code == 201
    user_id = register_resp.json()["id"]

    login_resp = client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password},
    )
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]
    return user_id, {"Authorization": f"Bearer {token}"}


def _create_scoped_api_key(client: TestClient, owner_headers: dict[str, str], scopes: list[str]) -> dict[str, str]:
    resp = client.post(
        "/api/v1/auth/api-keys",
        headers=owner_headers,
        json={"name": "Reporting Key", "scopes": scopes},
    )
    assert resp.status_code == 201
    key = resp.json()
    return {"Authorization": f"Bearer {key['id']}:{key['secret_key']}"}


def _create_project_with_script(
    client: TestClient,
    owner_id: int,
    owner_headers: dict[str, str],
) -> tuple[int, int, int]:
    project_resp = client.post(
        "/api/v1/projects/",
        headers=owner_headers,
        json={"name": "Reporting Project", "aut_base_url": "https://example.com"},
    )
    assert project_resp.status_code == 201
    project_id = project_resp.json()["id"]

    db = TestingSessionLocal()
    tc_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        headers=owner_headers,
        json={"title": "TC-Report", "format": "step_based", "content": "Step 1"},
    )
    assert tc_resp.status_code == 201
    tc_id = tc_resp.json()["id"]

    script = GeneratedScript(
        project_id=project_id,
        test_case_id=tc_id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    script_id = script.id
    db.close()
    return project_id, tc_id, script_id


def test_reports_endpoints_return_summary_logs_artifacts_and_download(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-owner@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])

    db = TestingSessionLocal()
    now = datetime.now(timezone.utc)
    job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={
            "duration_seconds": 12.5,
            "stdout": "all good",
            "stderr": "",
            "artifacts": [
                {
                    "id": "artifact-1",
                    "type": "log",
                    "filename": "execution.log",
                    "content_type": "text/plain",
                    "content": "log-line-1\nlog-line-2",
                }
            ],
        },
        started_at=now - timedelta(seconds=13),
        completed_at=now,
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    execution_id = job.id
    db.close()

    summary_resp = client.get(f"/api/v1/reports/{execution_id}", headers=key_headers)
    assert summary_resp.status_code == 200
    assert summary_resp.json()["execution_id"] == execution_id
    assert summary_resp.json()["duration_seconds"] == 12.5

    logs_resp = client.get(f"/api/v1/reports/{execution_id}/logs", headers=key_headers)
    assert logs_resp.status_code == 200
    assert logs_resp.json()["stdout"] == "all good"

    artifacts_resp = client.get(f"/api/v1/reports/{execution_id}/artifacts", headers=key_headers)
    assert artifacts_resp.status_code == 200
    artifacts = artifacts_resp.json()["artifacts"]
    assert len(artifacts) == 1
    assert artifacts[0]["id"] == "artifact-1"

    download_resp = client.get(f"/api/v1/reports/{execution_id}/download/artifact-1", headers=key_headers)
    assert download_resp.status_code == 200
    assert download_resp.text == "log-line-1\nlog-line-2"
    assert "attachment; filename=\"execution.log\"" in download_resp.headers.get("content-disposition", "")


def test_reports_download_404_for_missing_artifact(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-missing@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])

    db = TestingSessionLocal()
    job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"artifacts": []},
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    execution_id = job.id
    db.close()

    resp = client.get(f"/api/v1/reports/{execution_id}/download/not-there", headers=key_headers)
    assert resp.status_code == 404


def test_analytics_trends_returns_bucketed_series(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-trends@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    now = datetime.now(timezone.utc)
    db.add_all(
        [
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.completed,
                success=True,
                exit_code=0,
                stdout="ok",
                stderr="",
                duration_seconds=1.0,
                command="python x.py",
                created_at=now - timedelta(days=1),
            ),
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.failed,
                success=False,
                exit_code=1,
                stdout="",
                stderr="boom",
                duration_seconds=2.0,
                command="python x.py",
                created_at=now,
            ),
        ]
    )
    db.commit()
    db.close()

    resp = client.get(f"/api/v1/analytics/trends?project_id={project_id}", headers=owner_headers)
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["project_id"] == project_id
    assert len(payload["points"]) >= 2
    assert all("bucket" in item for item in payload["points"])


def test_analytics_flakiness_ranks_by_failure_rate(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-flaky@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    now = datetime.now(timezone.utc)

    db.add_all(
        [
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.failed,
                success=False,
                exit_code=1,
                stdout="",
                stderr="fail-1",
                duration_seconds=3.0,
                command="python x.py",
                created_at=now - timedelta(hours=3),
            ),
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.completed,
                success=True,
                exit_code=0,
                stdout="ok",
                stderr="",
                duration_seconds=1.0,
                command="python x.py",
                created_at=now - timedelta(hours=2),
            ),
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.failed,
                success=False,
                exit_code=1,
                stdout="",
                stderr="fail-2",
                duration_seconds=2.0,
                command="python x.py",
                created_at=now - timedelta(hours=1),
            ),
        ]
    )
    db.commit()
    db.close()

    resp = client.get(f"/api/v1/analytics/flakiness?project_id={project_id}&min_runs=3", headers=owner_headers)
    assert resp.status_code == 200
    payload = resp.json()
    assert payload["project_id"] == project_id
    assert payload["min_runs"] == 3
    assert len(payload["items"]) == 1
    top = payload["items"][0]
    assert top["script_id"] == script_id
    assert top["failed_runs"] == 2
    assert top["total_runs"] == 3
    assert top["flakiness_score"] == pytest.approx(66.67, abs=0.01)


def test_reports_not_found_and_no_membership_access(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-open-access@example.com")
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])

    project_resp = client.post(
        "/api/v1/projects/",
        json={"name": "No Membership Project", "aut_base_url": "https://example.com"},
    )
    assert project_resp.status_code == 201
    project_id = project_resp.json()["id"]

    tc_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        json={"title": "TC-No-Membership", "format": "step_based", "content": "Step 1"},
    )
    assert tc_resp.status_code == 201
    tc_id = tc_resp.json()["id"]

    db = TestingSessionLocal()
    script = GeneratedScript(
        project_id=project_id,
        test_case_id=tc_id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content="print('ok')",
    )
    db.add(script)
    db.commit()
    db.refresh(script)

    job = ExecutionJob(
        project_id=project_id,
        script_id=script.id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.running,
        request_payload={"script_id": script.id, "execution_env": {}},
        result_payload="not-a-dict",
        started_at=datetime.now(timezone.utc) - timedelta(seconds=2),
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    execution_id = job.id
    db.close()

    missing_resp = client.get("/api/v1/reports/999999", headers=key_headers)
    assert missing_resp.status_code == 404

    open_access_resp = client.get(f"/api/v1/reports/{execution_id}", headers=key_headers)
    assert open_access_resp.status_code == 200
    assert open_access_resp.json()["duration_seconds"] >= 0


def test_reports_access_denied_and_payload_fallbacks(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-owner-denied@example.com")
    outsider_id, outsider_headers = _register_and_login(client, "sprint5-outsider@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    owner_key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])
    outsider_key_headers = _create_scoped_api_key(client, outsider_headers, ["execution:read"])

    db = TestingSessionLocal()
    db.add(ProjectMembership(project_id=project_id, user_id=outsider_id, role=Role.viewer, is_active=False))
    job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"stdout": 123, "stderr": None, "artifacts": ["ignore", {"content": "x"}]},
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    execution_id = job.id
    db.close()

    denied_resp = client.get(f"/api/v1/reports/{execution_id}", headers=outsider_key_headers)
    assert denied_resp.status_code == 403

    logs_resp = client.get(f"/api/v1/reports/{execution_id}/logs", headers=owner_key_headers)
    assert logs_resp.status_code == 200
    assert logs_resp.json()["stdout"] == ""
    assert logs_resp.json()["stderr"] == ""

    artifacts_resp = client.get(f"/api/v1/reports/{execution_id}/artifacts", headers=owner_key_headers)
    assert artifacts_resp.status_code == 200
    assert len(artifacts_resp.json()["artifacts"]) == 1


def test_reports_download_branches_non_list_missing_content_and_invalid_base64(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-download-branches@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])

    db = TestingSessionLocal()
    non_list_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"artifacts": "not-a-list"},
    )
    missing_content_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"artifacts": [{"id": "a1", "content": None}]},
    )
    invalid_b64_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"artifacts": [{"id": "a2", "content": "@@@", "encoding": "base64"}]},
    )
    valid_b64_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={
            "artifacts": [
                {
                    "id": "a3",
                    "content": "aGVsbG8=",
                    "encoding": "base64",
                    "filename": "a3.txt",
                    "content_type": "text/plain",
                }
            ]
        },
    )
    db.add_all([non_list_job, missing_content_job, invalid_b64_job, valid_b64_job])
    db.commit()
    db.refresh(non_list_job)
    db.refresh(missing_content_job)
    db.refresh(invalid_b64_job)
    db.refresh(valid_b64_job)
    db.close()

    resp_non_list = client.get(f"/api/v1/reports/{non_list_job.id}/download/a1", headers=key_headers)
    assert resp_non_list.status_code == 404

    resp_missing_content = client.get(f"/api/v1/reports/{missing_content_job.id}/download/a1", headers=key_headers)
    assert resp_missing_content.status_code == 404

    resp_invalid_b64 = client.get(f"/api/v1/reports/{invalid_b64_job.id}/download/a2", headers=key_headers)
    assert resp_invalid_b64.status_code == 400

    resp_valid_b64 = client.get(f"/api/v1/reports/{valid_b64_job.id}/download/a3", headers=key_headers)
    assert resp_valid_b64.status_code == 200
    assert resp_valid_b64.text == "hello"


def test_analytics_trends_and_flakiness_not_found_and_date_filters(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-analytics-filters@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    now = datetime.now(timezone.utc)
    db.add_all(
        [
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.completed,
                success=True,
                exit_code=0,
                stdout="ok",
                stderr="",
                duration_seconds=1.0,
                command="python x.py",
                created_at=now - timedelta(days=3),
            ),
            ScriptRun(
                script_id=script_id,
                project_id=project_id,
                test_case_id=tc_id,
                status=ScriptRunStatus.failed,
                success=False,
                exit_code=1,
                stdout="",
                stderr="boom",
                duration_seconds=2.0,
                command="python x.py",
                created_at=now - timedelta(days=1),
            ),
        ]
    )
    db.commit()
    db.close()

    missing_trends = client.get("/api/v1/analytics/trends?project_id=999999")
    assert missing_trends.status_code == 404

    missing_flaky = client.get("/api/v1/analytics/flakiness?project_id=999999")
    assert missing_flaky.status_code == 404

    start_str = (now - timedelta(days=2)).date().isoformat()
    end_str = now.date().isoformat()
    trends = client.get(
        f"/api/v1/analytics/trends?project_id={project_id}&start_date={start_str}&end_date={end_str}",
        headers=owner_headers,
    )
    assert trends.status_code == 200
    assert len(trends.json()["points"]) == 1

    flakiness = client.get(
        f"/api/v1/analytics/flakiness?project_id={project_id}&start_date={start_str}&end_date={end_str}&min_runs=0",
        headers=owner_headers,
    )
    assert flakiness.status_code == 200
    assert flakiness.json()["min_runs"] == 1


def test_reports_artifact_non_list_and_download_skips_non_dict(client: TestClient):
    owner_id, owner_headers = _register_and_login(client, "sprint5-branch-lastmile@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)
    key_headers = _create_scoped_api_key(client, owner_headers, ["execution:read"])

    db = TestingSessionLocal()
    non_list_artifacts_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={"artifacts": "oops"},
    )
    mixed_download_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        result_payload={
            "artifacts": [
                "skip-me",
                {"id": "final", "content": "done", "filename": "final.txt", "content_type": "text/plain"},
            ]
        },
    )
    db.add_all([non_list_artifacts_job, mixed_download_job])
    db.commit()
    db.refresh(non_list_artifacts_job)
    db.refresh(mixed_download_job)
    db.close()

    artifacts_resp = client.get(f"/api/v1/reports/{non_list_artifacts_job.id}/artifacts", headers=key_headers)
    assert artifacts_resp.status_code == 200
    assert artifacts_resp.json()["artifacts"] == []

    download_resp = client.get(f"/api/v1/reports/{mixed_download_job.id}/download/final", headers=key_headers)
    assert download_resp.status_code == 200
    assert download_resp.text == "done"


def test_cleanup_old_artifacts_real_session_branch(client: TestClient, monkeypatch):
    owner_id, owner_headers = _register_and_login(client, "sprint5-cleanup@example.com")
    project_id, tc_id, script_id = _create_project_with_script(client, owner_id, owner_headers)

    db = TestingSessionLocal()
    now = datetime.now(timezone.utc)
    old_run = ScriptRun(
        script_id=script_id,
        project_id=project_id,
        test_case_id=tc_id,
        status=ScriptRunStatus.failed,
        success=False,
        exit_code=1,
        stdout="",
        stderr="old",
        duration_seconds=1.0,
        command="python x.py",
        created_at=now - timedelta(days=10),
    )
    fresh_run = ScriptRun(
        script_id=script_id,
        project_id=project_id,
        test_case_id=tc_id,
        status=ScriptRunStatus.completed,
        success=True,
        exit_code=0,
        stdout="ok",
        stderr="",
        duration_seconds=1.0,
        command="python x.py",
        created_at=now,
    )
    old_completed_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.completed,
        request_payload={"script_id": script_id, "execution_env": {}},
        updated_at=now - timedelta(days=10),
    )
    old_running_job = ExecutionJob(
        project_id=project_id,
        script_id=script_id,
        test_case_id=tc_id,
        created_by_user_id=owner_id,
        status=ExecutionJobStatus.running,
        request_payload={"script_id": script_id, "execution_env": {}},
        updated_at=now - timedelta(days=10),
    )
    db.add_all([old_run, fresh_run, old_completed_job, old_running_job])
    db.commit()
    db.close()

    monkeypatch.setattr(tasks, "SessionLocal", TestingSessionLocal)
    cleanup = tasks.cleanup_old_artifacts.run(7)

    assert cleanup["status"] == "completed"
    assert cleanup["removed_script_runs"] >= 1
    assert cleanup["removed_execution_jobs"] >= 1
    assert cleanup["removed_count"] >= 2

    verify_db = TestingSessionLocal()
    remaining_runs = verify_db.query(ScriptRun).all()
    remaining_jobs = verify_db.query(ExecutionJob).all()
    verify_db.close()

    assert len(remaining_runs) == 1
    assert remaining_runs[0].stderr == ""
    assert len(remaining_jobs) == 1
    assert remaining_jobs[0].status == ExecutionJobStatus.running
