"""Opt-in PostgreSQL integration tests.

These tests are intentionally skipped by default and are meant for true API -> DB
round-trip validation against a real PostgreSQL test database.

How to run (PowerShell):
    $env:RUN_POSTGRES_INTEGRATION_TESTS="1"
    $env:INTEGRATION_DATABASE_URL="postgresql://scriptgini:scriptgini@localhost:5433/scriptgini_test_db"
    python -m pytest tests/test_integration_postgres_optin.py -q
"""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import time
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError
from sqlalchemy.engine.url import make_url
from sqlalchemy.orm import sessionmaker

# Ensure all tables are registered on Base.metadata.
import app.models.api_key  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.organization  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_revision  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401
import app.models.workspace  # noqa: F401
import app.models.user_story  # noqa: F401

from app.config import settings
from app.database import Base, get_db
from app.main import app as fastapi_app
from app.models.project import Project
from app.models.user import EnterpriseRole, User


pytestmark = [
    pytest.mark.integration,
    pytest.mark.postgres_integration,
]


def _is_enabled() -> bool:
    return os.getenv("RUN_POSTGRES_INTEGRATION_TESTS", "").strip().lower() in {"1", "true", "yes", "on"}


def _integration_db_url() -> str:
    return os.getenv("INTEGRATION_DATABASE_URL", "").strip() or settings.DATABASE_URL


def _validate_test_db_url(db_url: str) -> None:
    """Refuse to run destructive setup on non-test database names."""
    parsed = make_url(db_url)
    db_name = (parsed.database or "").lower()
    if "test" not in db_name:
        raise RuntimeError(
            "Refusing to run PostgreSQL integration tests against non-test DB. "
            "Set INTEGRATION_DATABASE_URL to a dedicated test database (name should contain 'test')."
        )


def _can_connect(db_url: str) -> bool:
    engine = create_engine(db_url, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        return True
    except OperationalError:
        return False
    finally:
        engine.dispose()


def _can_connect_server(db_url: str) -> bool:
    admin_url = _admin_db_url(db_url)
    engine = create_engine(admin_url, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        return True
    except OperationalError:
        return False
    finally:
        engine.dispose()


def _admin_db_url(db_url: str) -> str:
    parsed = make_url(db_url)
    admin_db = "postgres"
    # Keep credentials intact; str(URL) masks password as ***.
    return parsed.set(database=admin_db).render_as_string(hide_password=False)


def _ensure_database_exists(db_url: str) -> None:
    parsed = make_url(db_url)
    target_db = parsed.database
    if not target_db:
        raise RuntimeError("Integration database URL must include a database name")

    admin_engine = create_engine(_admin_db_url(db_url), pool_pre_ping=True)
    try:
        with admin_engine.connect().execution_options(isolation_level="AUTOCOMMIT") as conn:
            exists = conn.exec_driver_sql(
                "SELECT 1 FROM pg_database WHERE datname = %s",
                (target_db,),
            ).scalar()
            if not exists:
                # Quote database identifier defensively.
                escaped_db = target_db.replace('"', '""')
                conn.exec_driver_sql(f'CREATE DATABASE "{escaped_db}"')
    except OperationalError as exc:
        raise RuntimeError(f"could not connect to PostgreSQL admin database to ensure test DB exists: {exc}") from exc
    finally:
        admin_engine.dispose()


def _run_compose_command(compose_file: Path, args: list[str]) -> subprocess.CompletedProcess[str]:
    # Try modern plugin first, then legacy binary for compatibility.
    candidates = [
        ["docker", "compose", "-f", str(compose_file), *args],
        ["docker-compose", "-f", str(compose_file), *args],
    ]
    last_error: str | None = None
    for command in candidates:
        try:
            result = subprocess.run(command, capture_output=True, text=True, check=False)
        except OSError as exc:
            last_error = str(exc)
            continue
        if result.returncode == 0:
            return result
        last_error = result.stderr.strip() or result.stdout.strip()
    raise RuntimeError(last_error or "Failed to run docker compose command")


def _ensure_postgres_via_compose(db_url: str) -> tuple[bool, str | None]:
    """Attempt to bring up postgres container and wait for DB readiness.

    Returns:
        (started, error_message)
    """
    compose_file = Path(__file__).parent.parent / "docker-compose.yml"
    if not compose_file.exists():
        return False, f"docker-compose file not found at {compose_file}"

    try:
        _run_compose_command(compose_file, ["up", "-d", "postgres"])
    except RuntimeError as exc:
        return False, f"failed to start postgres via docker compose: {exc}"

    timeout_seconds = int(os.getenv("POSTGRES_INTEGRATION_STARTUP_TIMEOUT_SECONDS", "180"))
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _can_connect_server(db_url):
            return True, None
        time.sleep(2)
    return True, f"postgres did not become reachable within {timeout_seconds} seconds"


def _maybe_stop_compose_postgres() -> None:
    compose_file = Path(__file__).parent.parent / "docker-compose.yml"
    if not compose_file.exists():
        return
    _run_compose_command(compose_file, ["stop", "postgres"])


@pytest.fixture(scope="module")
def pg_engine():
    if not _is_enabled():
        pytest.skip("PostgreSQL integration tests are opt-in. Set RUN_POSTGRES_INTEGRATION_TESTS=1 to run.")

    db_url = _integration_db_url()
    _validate_test_db_url(db_url)

    started_by_fixture = False
    if not _can_connect_server(db_url):
        started_by_fixture, startup_error = _ensure_postgres_via_compose(db_url)
        if startup_error:
            pytest.skip(
                "PostgreSQL integration tests require a reachable PostgreSQL server for "
                f"{db_url}. Auto-start via docker compose failed: {startup_error}"
            )

    try:
        _ensure_database_exists(db_url)
    except RuntimeError as exc:
        pytest.skip(
            "PostgreSQL integration tests require a reachable test database at "
            f"{db_url}. Could not create/verify test database: {exc}"
        )

    if not _can_connect(db_url):
        pytest.skip(
            "PostgreSQL integration tests require a reachable test database at "
            f"{db_url}. Server is up but database is still unreachable."
        )

    engine = create_engine(db_url, pool_pre_ping=True)

    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    try:
        yield engine
    finally:
        Base.metadata.drop_all(bind=engine)
        engine.dispose()
        keep_running = os.getenv("POSTGRES_INTEGRATION_KEEP_CONTAINERS", "").strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        if started_by_fixture and not keep_running:
            try:
                _maybe_stop_compose_postgres()
            except RuntimeError:
                # Do not fail tests during cleanup if container stop command fails.
                pass


@pytest.fixture(scope="module")
def testing_session_local(pg_engine):
    return sessionmaker(autocommit=False, autoflush=False, bind=pg_engine)


@pytest.fixture(autouse=True)
def override_app_db(testing_session_local):
    def _override_get_db():
        db = testing_session_local()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = _override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


def test_user_register_login_roundtrip_persists_in_postgres(client, testing_session_local):
    email = "pg_int_user_roundtrip@test.com"
    password = "TestPassword123!"

    register_resp = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert register_resp.status_code == 201, register_resp.text
    user_id = register_resp.json()["id"]

    db = testing_session_local()
    try:
        row = db.query(User).filter(User.id == user_id).first()
        assert row is not None
        assert row.email == email
    finally:
        db.close()

    login_resp = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login_resp.status_code == 200, login_resp.text
    assert login_resp.json().get("access_token")


def test_project_create_get_delete_roundtrip_persists_in_postgres(client, testing_session_local):
    create_resp = client.post(
        "/api/v1/projects/",
        json={
            "name": "PG Integration Roundtrip",
            "aut_base_url": "https://example.com",
            "default_framework": "playwright_python",
            "selector_preference": "role",
        },
    )
    assert create_resp.status_code == 201, create_resp.text
    project_id = create_resp.json()["id"]

    db = testing_session_local()
    try:
        row = db.query(Project).filter(Project.id == project_id).first()
        assert row is not None
        assert row.name == "PG Integration Roundtrip"
    finally:
        db.close()

    get_resp = client.get(f"/api/v1/projects/{project_id}")
    assert get_resp.status_code == 200
    assert get_resp.json()["id"] == project_id

    delete_resp = client.delete(f"/api/v1/projects/{project_id}")
    assert delete_resp.status_code == 204

    db = testing_session_local()
    try:
        deleted = db.query(Project).filter(Project.id == project_id).first()
        assert deleted is None
    finally:
        db.close()

    get_after_delete = client.get(f"/api/v1/projects/{project_id}")
    assert get_after_delete.status_code == 404


def test_project_role_capability_matrix_integration(client):
    """Create users across roles and verify capabilities on a shared project."""

    def _register_and_login(email_prefix: str) -> tuple[int, dict[str, str]]:
        email = f"{email_prefix}_{uuid4().hex[:8]}@test.com"
        password = "TestPassword123!"
        register_resp = client.post("/api/v1/auth/register", json={"email": email, "password": password})
        assert register_resp.status_code == 201, register_resp.text
        user_id = register_resp.json()["id"]

        login_resp = client.post("/api/v1/auth/login", json={"email": email, "password": password})
        assert login_resp.status_code == 200, login_resp.text
        token = login_resp.json()["access_token"]
        return user_id, {"Authorization": f"Bearer {token}"}

    owner_id, owner_headers = _register_and_login("owner")
    admin_id, admin_headers = _register_and_login("admin")
    member_id, member_headers = _register_and_login("member")
    viewer_id, viewer_headers = _register_and_login("viewer")

    create_project_resp = client.post(
        "/api/v1/projects/",
        json={
            "name": "RBAC Integration Matrix",
            "aut_base_url": "https://example.com",
            "default_framework": "playwright_python",
            "selector_preference": "role",
        },
        headers=owner_headers,
    )
    assert create_project_resp.status_code == 201, create_project_resp.text
    project_id = create_project_resp.json()["id"]

    assign_role_payloads = [
        (admin_id, {"role": "admin", "is_active": True}),
        (member_id, {"role": "member", "is_active": True}),
        (viewer_id, {"role": "viewer", "is_active": True}),
    ]
    for user_id, payload in assign_role_payloads:
        upsert_resp = client.put(
            f"/api/v1/projects/{project_id}/members/{user_id}",
            json=payload,
            headers=owner_headers,
        )
        assert upsert_resp.status_code == 200, upsert_resp.text

    cases = [
        ("owner", owner_headers, True),
        ("admin", admin_headers, True),
        ("member", member_headers, False),
        ("viewer", viewer_headers, False),
    ]

    for role_name, headers, can_manage in cases:
        get_resp = client.get(f"/api/v1/projects/{project_id}", headers=headers)
        assert get_resp.status_code == 200, f"{role_name} should have read access: {get_resp.text}"

        members_resp = client.get(f"/api/v1/projects/{project_id}/members", headers=headers)
        assert members_resp.status_code == 200, f"{role_name} should list members: {members_resp.text}"

        patch_resp = client.patch(
            f"/api/v1/projects/{project_id}",
            json={"auth_hints": f"updated-by-{role_name}"},
            headers=headers,
        )
        expected_patch_status = 200 if can_manage else 403
        assert (
            patch_resp.status_code == expected_patch_status
        ), f"{role_name} patch expected {expected_patch_status}, got {patch_resp.status_code}: {patch_resp.text}"

        put_resp = client.put(
            f"/api/v1/projects/{project_id}/members/{viewer_id}",
            json={"role": "viewer", "is_active": True},
            headers=headers,
        )
        expected_put_status = 200 if can_manage else 403
        assert (
            put_resp.status_code == expected_put_status
        ), f"{role_name} member upsert expected {expected_put_status}, got {put_resp.status_code}: {put_resp.text}"


class TestEnterpriseRolesIntegration:
    """Enterprise RBAC lifecycle integration tests against PostgreSQL."""

    @staticmethod
    def _register_and_login(client, email_prefix: str) -> tuple[int, dict[str, str]]:
        email = f"{email_prefix}_{uuid4().hex[:8]}@test.com"
        password = "TestPassword123!"
        register_resp = client.post("/api/v1/auth/register", json={"email": email, "password": password})
        assert register_resp.status_code == 201, register_resp.text
        user_id = register_resp.json()["id"]

        login_resp = client.post("/api/v1/auth/login", json={"email": email, "password": password})
        assert login_resp.status_code == 200, login_resp.text
        token = login_resp.json()["access_token"]
        return user_id, {"Authorization": f"Bearer {token}"}

    def test_enterprise_roles_capabilities_integration(self, client, testing_session_local):
        """Validate PlatformAdmin/TenantAdmin/QA roles across key CRUD resources."""

        platform_admin_id, platform_headers = self._register_and_login(client, "platform_admin")
        tenant_admin_id, tenant_headers = self._register_and_login(client, "tenant_admin")
        qa_manager_id, qa_manager_headers = self._register_and_login(client, "qa_manager")
        qa_test_lead_id, qa_test_lead_headers = self._register_and_login(client, "qa_test_lead")
        qa_engineer_id, qa_engineer_headers = self._register_and_login(client, "qa_engineer")

        me_resp = client.get("/api/v1/rbac/me", headers=qa_engineer_headers)
        assert me_resp.status_code == 200, me_resp.text
        assert me_resp.json()["role"] == "QA Engineer"

        invalid_role_resp = client.get("/api/v1/rbac/capabilities/NotARole", headers=platform_headers)
        assert invalid_role_resp.status_code == 400

        db = testing_session_local()
        try:
            user = db.query(User).filter(User.id == platform_admin_id).first()
            assert user is not None
            user.enterprise_role = EnterpriseRole.platform_admin
            db.commit()
        finally:
            db.close()

        role_updates = [
            (tenant_admin_id, "TenantAdmin"),
            (qa_manager_id, "QA Manager"),
            (qa_test_lead_id, "QA Test Lead"),
            (qa_engineer_id, "QA Engineer"),
        ]
        for user_id, role_name in role_updates:
            role_resp = client.patch(
                f"/api/v1/auth/users/{user_id}/role",
                headers=platform_headers,
                json={"enterprise_role": role_name},
            )
            assert role_resp.status_code == 200, role_resp.text
            assert role_resp.json()["enterprise_role"] == role_name

        for role_name in ["PlatformAdmin", "TenantAdmin", "QA Manager", "QA Test Lead", "QA Engineer"]:
            cap_resp = client.get(f"/api/v1/rbac/capabilities/{role_name}", headers=platform_headers)
            assert cap_resp.status_code == 200, cap_resp.text
            caps = cap_resp.json()["capabilities"]
            assert "Execute Tests" in caps
            assert "Metrics and Dashboards" in caps
            assert "User Management" in caps
            assert "Tenant Management" in caps

        users_read_forbidden = client.get("/api/v1/auth/users", headers=qa_engineer_headers)
        assert users_read_forbidden.status_code == 403

        users_read_allowed = client.get("/api/v1/auth/users", headers=platform_headers)
        assert users_read_allowed.status_code == 200, users_read_allowed.text
        assert any(row["id"] == platform_admin_id for row in users_read_allowed.json())

        role_update_missing = client.patch(
            "/api/v1/auth/users/999999/role",
            headers=platform_headers,
            json={"enterprise_role": "QA Engineer"},
        )
        assert role_update_missing.status_code == 404

        role_update_forbidden = client.patch(
            f"/api/v1/auth/users/{qa_test_lead_id}/role",
            headers=qa_engineer_headers,
            json={"enterprise_role": "QA Test Lead"},
        )
        assert role_update_forbidden.status_code == 403

        role_update_allowed = client.patch(
            f"/api/v1/auth/users/{qa_test_lead_id}/role",
            headers=platform_headers,
            json={"enterprise_role": "QA Test Lead"},
        )
        assert role_update_allowed.status_code == 200, role_update_allowed.text

        project_resp = client.post(
            "/api/v1/projects/",
            json={
                "name": "Enterprise Roles Project",
                "aut_base_url": "https://example.com",
                "default_framework": "playwright_python",
                "selector_preference": "role",
            },
            headers=platform_headers,
        )
        assert project_resp.status_code == 201, project_resp.text
        project_id = project_resp.json()["id"]

        workspace_resp = client.post(
            "/api/v1/workspaces",
            json={"name": "QA Workspace", "description": "Primary QA Workspace"},
            headers=qa_manager_headers,
        )
        assert workspace_resp.status_code == 201, workspace_resp.text
        workspace_id = workspace_resp.json()["id"]

        workspaces_list = client.get("/api/v1/workspaces", headers=qa_engineer_headers)
        assert workspaces_list.status_code == 200, workspaces_list.text

        workspace_get = client.get(f"/api/v1/workspaces/{workspace_id}", headers=qa_engineer_headers)
        assert workspace_get.status_code == 200, workspace_get.text

        workspace_update_forbidden = client.patch(
            f"/api/v1/workspaces/{workspace_id}",
            headers=qa_engineer_headers,
            json={"description": "Should be denied"},
        )
        assert workspace_update_forbidden.status_code == 403

        workspace_update_allowed = client.patch(
            f"/api/v1/workspaces/{workspace_id}",
            headers=tenant_headers,
            json={"description": "Updated workspace"},
        )
        assert workspace_update_allowed.status_code == 200, workspace_update_allowed.text

        workspace_update_missing = client.patch(
            "/api/v1/workspaces/999999",
            headers=tenant_headers,
            json={"description": "missing"},
        )
        assert workspace_update_missing.status_code == 404

        workspace_missing_get = client.get("/api/v1/workspaces/999999", headers=platform_headers)
        assert workspace_missing_get.status_code == 404

        story_resp = client.post(
            f"/api/v1/projects/{project_id}/user-stories/",
            json={
                "title": "Story 1",
                "description": "As a user, I need login",
                "acceptance_criteria": "Valid credentials should succeed",
                "workspace_id": workspace_id,
            },
            headers=qa_engineer_headers,
        )
        assert story_resp.status_code == 201, story_resp.text
        story_id = story_resp.json()["id"]

        story_list = client.get(f"/api/v1/projects/{project_id}/user-stories/", headers=qa_engineer_headers)
        assert story_list.status_code == 200, story_list.text

        story_get = client.get(f"/api/v1/projects/{project_id}/user-stories/{story_id}", headers=qa_engineer_headers)
        assert story_get.status_code == 200, story_get.text

        story_update = client.patch(
            f"/api/v1/projects/{project_id}/user-stories/{story_id}",
            headers=qa_engineer_headers,
            json={"status": "ready"},
        )
        assert story_update.status_code == 200, story_update.text

        story_update_missing = client.patch(
            f"/api/v1/projects/{project_id}/user-stories/999999",
            headers=platform_headers,
            json={"status": "done"},
        )
        assert story_update_missing.status_code == 404

        story_missing_get = client.get(f"/api/v1/projects/{project_id}/user-stories/999999", headers=platform_headers)
        assert story_missing_get.status_code == 404

        story_missing_delete = client.delete(
            f"/api/v1/projects/{project_id}/user-stories/999999",
            headers=platform_headers,
        )
        assert story_missing_delete.status_code == 404

        tc_resp = client.post(
            f"/api/v1/projects/{project_id}/test-cases/",
            json={
                "title": "TC-ENT-001",
                "format": "step_based",
                "content": "Step 1: Login",
                "preconditions": "User exists",
            },
            headers=platform_headers,
        )
        assert tc_resp.status_code == 201, tc_resp.text

        denied_workspace_delete = client.delete(f"/api/v1/workspaces/{workspace_id}", headers=qa_engineer_headers)
        assert denied_workspace_delete.status_code == 403

        cleanup_story = client.delete(
            f"/api/v1/projects/{project_id}/user-stories/{story_id}",
            headers=tenant_headers,
        )
        assert cleanup_story.status_code == 204, cleanup_story.text

        story_delete_forbidden = client.delete(
            f"/api/v1/projects/{project_id}/user-stories/{story_id}",
            headers=qa_engineer_headers,
        )
        assert story_delete_forbidden.status_code == 403

        allowed_workspace_delete = client.delete(f"/api/v1/workspaces/{workspace_id}", headers=tenant_headers)
        assert allowed_workspace_delete.status_code == 204, allowed_workspace_delete.text

        workspace_delete_missing = client.delete("/api/v1/workspaces/999999", headers=platform_headers)
        assert workspace_delete_missing.status_code == 404
