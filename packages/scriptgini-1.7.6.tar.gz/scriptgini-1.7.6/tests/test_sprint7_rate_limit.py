"""Sprint 7 tests: per-user/API-key rate limiting, analytics indexes (migration), OpenAPI scope docs."""
import asyncio
from unittest.mock import patch, MagicMock
from types import SimpleNamespace

import pytest
from fastapi import Depends, Request, Response
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.api_key  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_revision  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app
from app.services.rate_limit import (
    _client_ip,
    _memory_rate_check,
    _redis_rate_check,
    per_user_rate_limit,
)

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> tuple[int, dict]:
    r = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert r.status_code == 201, r.text
    user_id = r.json()["id"]
    login = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]
    return user_id, {"Authorization": f"Bearer {token}"}


# ---------------------------------------------------------------------------
# Unit tests for rate_limit.py helpers
# ---------------------------------------------------------------------------

class TestClientIPExtraction:
    def test_uses_forwarded_for_header(self):
        req = MagicMock()
        req.headers = {"x-forwarded-for": "10.0.0.1, 10.0.0.2"}
        req.client = MagicMock(host="192.168.1.1")
        assert _client_ip(req) == "10.0.0.1"

    def test_falls_back_to_client_host(self):
        req = MagicMock()
        req.headers = {}
        req.client = MagicMock(host="192.168.1.1")
        assert _client_ip(req) == "192.168.1.1"

    def test_returns_unknown_when_no_client(self):
        req = MagicMock()
        req.headers = {}
        req.client = None
        assert _client_ip(req) == "unknown"


class TestMemoryRateCheck:
    def test_first_request_is_allowed(self):
        allowed, remaining, retry_after = _memory_rate_check("test:key:unit1", 5, 60)
        assert allowed is True
        assert remaining == 4

    def test_at_limit_is_allowed(self):
        key = "test:key:unit2"
        for _ in range(4):
            _memory_rate_check(key, 5, 60)
        allowed, remaining, _ = _memory_rate_check(key, 5, 60)
        assert allowed is True
        assert remaining == 0

    def test_over_limit_is_blocked(self):
        key = "test:key:unit3"
        for _ in range(5):
            _memory_rate_check(key, 5, 60)
        allowed, _, retry_after = _memory_rate_check(key, 5, 60)
        assert allowed is False
        assert retry_after >= 0

    def test_window_resets_after_expiry(self):
        import time
        key = "test:key:unit4"
        from app.services import rate_limit as rl_module

        # Insert an expired bucket directly
        expired_at = time.monotonic() - 1  # already expired
        rl_module._IN_MEMORY_BUCKETS[key] = (999, expired_at)

        allowed, remaining, _ = _memory_rate_check(key, 5, 60)
        assert allowed is True
        assert remaining == 4  # reset to 1 request used, 4 remaining


class TestRedisRateCheckFallback:
    def test_falls_back_to_memory_when_redis_unavailable(self):
        """_redis_rate_check must fall back to in-memory when Redis is down."""
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = False
            allowed, remaining, _ = _redis_rate_check("fallback:key", 10, 60)
        assert allowed is True
        assert remaining <= 10

    def test_falls_back_to_memory_on_redis_exception(self):
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = True
            mock_cache.redis_client.incr.side_effect = Exception("connection refused")
            allowed, remaining, _ = _redis_rate_check("fallback:key2", 10, 60)
        assert allowed is True


class TestPerUserRateLimitDependency:
    def test_returns_callable(self):
        dep = per_user_rate_limit(10, 60, "test:scope")
        assert callable(dep)

    def test_allows_request_within_limit(self):
        """Dependency should not raise for a single request."""
        dep = per_user_rate_limit(100, 60, "unit:scope")
        req = MagicMock()
        req.headers = {}
        req.client = MagicMock(host="127.0.0.1")
        req.url.path = "/test"
        req.state = SimpleNamespace()
        # Should not raise
        dep(req, None, None)

    def test_blocks_request_over_limit(self):
        """Dependency must raise HTTP 429 when limit exceeded."""
        from fastapi import HTTPException
        dep = per_user_rate_limit(1, 3600, "unit:block_scope")
        req = MagicMock()
        req.headers = {}
        req.client = MagicMock(host="1.2.3.4")
        req.url.path = "/test"
        req.state = SimpleNamespace(rate_limit_user=None)

        # First request — allowed
        dep(req, None, None)
        # Second request — blocked (limit=1)
        with pytest.raises(HTTPException) as exc_info:
            dep(req, None, None)
        assert exc_info.value.status_code == 429

    def test_uses_user_identity_over_ip(self):
        """When request.state.rate_limit_user is set, key should use user ID."""
        from app.services import rate_limit as rl_module

        dep = per_user_rate_limit(5, 60, "unit:user_scope")
        req = MagicMock()
        req.headers = {}
        req.client = MagicMock(host="9.9.9.9")
        req.url.path = "/test"
        user = MagicMock()
        user.id = 42
        req.state = SimpleNamespace(rate_limit_user=user)

        captured_keys = []
        original_check = rl_module._memory_rate_check

        def capturing_check(key, max_r, window):
            captured_keys.append(key)
            return original_check(key, max_r, window)

        with patch.object(rl_module, "_memory_rate_check", side_effect=capturing_check):
            with patch.object(rl_module, "_redis_rate_check", side_effect=lambda k, m, w: capturing_check(k, m, w)):
                dep(req, None, None)

        assert any("u:42" in k for k in captured_keys), f"Expected user identity in key, got: {captured_keys}"

    def test_uses_api_key_identity_over_ip(self):
        """When a bearer API key resolves successfully, the key should use API key ID."""
        from app.services import rate_limit as rl_module

        dep = per_user_rate_limit(5, 60, "unit:api_key_scope")
        req = MagicMock()
        req.headers = {"authorization": "Bearer sg_abcd:secret"}
        req.client = MagicMock(host="8.8.8.8")
        req.url.path = "/test"
        req.state = SimpleNamespace()

        resolved_user = SimpleNamespace(id=42, _api_key=SimpleNamespace(id=99))
        credentials = SimpleNamespace(credentials="sg_abcd:secret")
        db = object()

        captured_keys = []
        original_check = rl_module._memory_rate_check

        def capturing_check(key, max_r, window):
            captured_keys.append(key)
            return original_check(key, max_r, window)

        with patch("app.services.auth_dependencies._resolve_user_or_api_key_identity", return_value=resolved_user):
            with patch.object(rl_module, "_memory_rate_check", side_effect=capturing_check):
                with patch.object(rl_module, "_redis_rate_check", side_effect=lambda k, m, w: capturing_check(k, m, w)):
                    dep(req, credentials, db)

        assert any("k:99" in k for k in captured_keys), f"Expected API key identity in key, got: {captured_keys}"


# ---------------------------------------------------------------------------
# Integration tests: rate-limit headers on real HTTP responses
# ---------------------------------------------------------------------------

class TestRateLimitHeaders:
    def test_successful_login_has_ratelimit_headers(self, client: TestClient):
        # Pre-register the user
        client.post("/api/v1/auth/register", json={"email": "rl_hdr@test.com", "password": "TestPassword123!"})
        resp = client.post(
            "/api/v1/auth/login",
            json={"email": "rl_hdr@test.com", "password": "TestPassword123!"},
        )
        assert resp.status_code == 200
        # Global middleware adds X-RateLimit-Limit; per-user adds X-RateLimit-Remaining / Window
        assert "x-ratelimit-limit" in resp.headers or "X-RateLimit-Limit" in resp.headers
        assert "x-ratelimit-window" in resp.headers or "X-RateLimit-Window" in resp.headers

    def test_request_id_header_always_present(self, client: TestClient):
        resp = client.get("/api/v1/projects/")
        assert "x-request-id" in resp.headers or "X-Request-ID" in resp.headers

    def test_register_returns_201_under_limit(self, client: TestClient):
        resp = client.post(
            "/api/v1/auth/register",
            json={"email": "rl_reg_ok@test.com", "password": "TestPassword123!"},
        )
        assert resp.status_code == 201


class TestRateLimitEnforcedOnLogin:
    def test_login_rate_limit_enforced(self, client: TestClient):
        """Exceeding the login rate limit should return 429."""
        email = "rl_login@test.com"
        client.post("/api/v1/auth/register", json={"email": email, "password": "TestPassword123!"})

        # Simulate the memory rate-check returning "blocked" so the login dep enforces 429
        from app.services import rate_limit as rl_module
        original_redis_check = rl_module._redis_rate_check

        call_count = 0

        def mock_rate_check(key, max_requests, window_seconds):
            nonlocal call_count
            call_count += 1
            if "auth:login" in key and call_count > 1:
                return False, 0, 30  # blocked
            return True, max_requests - call_count, 60

        with patch.object(rl_module, "_redis_rate_check", side_effect=mock_rate_check):
            resp1 = client.post("/api/v1/auth/login", json={"email": email, "password": "TestPassword123!"})
            resp2 = client.post("/api/v1/auth/login", json={"email": email, "password": "TestPassword123!"})

        assert resp1.status_code == 200
        assert resp2.status_code == 429
        assert resp2.headers.get("X-RateLimit-Limit") == "10"
        assert resp2.headers.get("X-RateLimit-Remaining") == "0"
        assert resp2.headers.get("X-RateLimit-Window") == "60"
        assert resp2.headers.get("Retry-After") is not None


class TestRateLimitEnforcedOnRegister:
    def test_register_rate_limit_enforced(self, client: TestClient):
        """Exceeding the register rate limit should return 429."""
        from app.services import rate_limit as rl_module

        call_count = 0

        def mock_rate_check(key, max_requests, window_seconds):
            nonlocal call_count
            call_count += 1
            if "auth:register" in key and call_count > 1:
                return False, 0, 30  # blocked
            return True, max_requests - 1, 60

        with patch.object(rl_module, "_redis_rate_check", side_effect=mock_rate_check):
            resp1 = client.post("/api/v1/auth/register", json={"email": "rl_r1@test.com", "password": "TestPassword123!"})
            resp2 = client.post("/api/v1/auth/register", json={"email": "rl_r2@test.com", "password": "TestPassword123!"})

        assert resp1.status_code == 201
        assert resp2.status_code == 429
        assert resp2.headers.get("X-RateLimit-Limit") == "5"
        assert resp2.headers.get("X-RateLimit-Remaining") == "0"
        assert resp2.headers.get("X-RateLimit-Window") == "60"


class TestAuthMiddlewareFallbackHeaders:
    def test_login_path_sets_auth_fallback_headers_when_dependency_headers_missing(self):
        from app import main as main_module

        scope = {
            "type": "http",
            "method": "POST",
            "path": "/api/v1/auth/login",
            "headers": [],
            "query_string": b"",
            "client": ("testclient", 50000),
            "scheme": "http",
            "server": ("testserver", 80),
            "http_version": "1.1",
        }
        request = Request(scope)

        async def call_next(_request):
            return Response(status_code=200)

        response = asyncio.run(main_module.apply_security_controls(request, call_next))
        assert response.status_code == 200
        assert response.headers.get("X-RateLimit-Limit") == "10"
        assert response.headers.get("X-RateLimit-Window") == "60"
        assert response.headers.get("X-RateLimit-Remaining") == "9"

    def test_unknown_auth_path_does_not_emit_auth_fallback_limit_headers(self):
        from app import main as main_module

        scope = {
            "type": "http",
            "method": "GET",
            "path": "/api/v1/auth/unknown",
            "headers": [],
            "query_string": b"",
            "client": ("testclient", 50001),
            "scheme": "http",
            "server": ("testserver", 80),
            "http_version": "1.1",
        }
        request = Request(scope)

        async def call_next(_request):
            return Response(status_code=404)

        response = asyncio.run(main_module.apply_security_controls(request, call_next))
        assert response.status_code == 404
        assert "X-RateLimit-Limit" not in response.headers
        assert "X-RateLimit-Window" not in response.headers
        assert "X-RateLimit-Remaining" not in response.headers


# ---------------------------------------------------------------------------
# OpenAPI contract: scopes documented in /openapi.json
# ---------------------------------------------------------------------------

class TestOpenAPIContract:
    def test_openapi_description_documents_scopes(self, client: TestClient):
        resp = client.get("/openapi.json")
        assert resp.status_code == 200
        schema = resp.json()
        description = schema.get("info", {}).get("description", "")
        # Confirm the scope table is present
        assert "scripts:write" in description
        assert "execution:write" in description
        assert "analytics:read" in description
        assert "bulk-jobs:write" in description

    def test_openapi_description_documents_rate_limits(self, client: TestClient):
        resp = client.get("/openapi.json")
        assert resp.status_code == 200
        description = resp.json()["info"]["description"]
        assert "X-RateLimit-Limit" in description
        assert "Retry-After" in description

    def test_openapi_description_has_ci_cd_example(self, client: TestClient):
        resp = client.get("/openapi.json")
        assert resp.status_code == 200
        description = resp.json()["info"]["description"]
        assert "CI/CD" in description or "ci-pipeline" in description

    def test_openapi_auth_tag_present(self, client: TestClient):
        resp = client.get("/openapi.json")
        assert resp.status_code == 200
        tags = [t["name"] for t in resp.json().get("tags", [])]
        paths = resp.json().get("paths", {})
        # auth endpoints should be reachable
        assert any("/auth" in p for p in paths)


# ---------------------------------------------------------------------------
# Alembic migration: analytics indexes migration file is valid Python
# ---------------------------------------------------------------------------

class TestAnalyticsMigration:
    def test_migration_module_imports_cleanly(self):
        import importlib.util
        import pathlib

        migration_path = pathlib.Path(__file__).parent.parent / "alembic" / "versions" / "i2j3k4l5m6n7_add_analytics_indexes.py"
        assert migration_path.exists(), f"Migration file not found: {migration_path}"

        spec = importlib.util.spec_from_file_location("analytics_migration", migration_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        assert mod.revision == "i2j3k4l5m6n7"
        assert mod.down_revision == "h1i2j3k4l5m6"

    def test_migration_upgrade_creates_three_indexes(self):
        """Verify upgrade() calls op.create_index exactly 3 times."""
        import importlib.util
        import pathlib
        from unittest.mock import patch, call

        migration_path = pathlib.Path(__file__).parent.parent / "alembic" / "versions" / "i2j3k4l5m6n7_add_analytics_indexes.py"
        spec = importlib.util.spec_from_file_location("analytics_migration2", migration_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        with patch("alembic.op.create_index") as mock_create, \
             patch("alembic.op.drop_index"):
            mod.upgrade()

        assert mock_create.call_count == 3
        index_names = [c.args[0] for c in mock_create.call_args_list]
        assert "ix_script_runs_project_created_at" in index_names
        assert "ix_script_runs_script_tc_project_created" in index_names
        assert "ix_script_runs_project_success" in index_names

    def test_migration_downgrade_drops_three_indexes(self):
        import importlib.util
        import pathlib
        from unittest.mock import patch

        migration_path = pathlib.Path(__file__).parent.parent / "alembic" / "versions" / "i2j3k4l5m6n7_add_analytics_indexes.py"
        spec = importlib.util.spec_from_file_location("analytics_migration3", migration_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        with patch("alembic.op.create_index"), \
             patch("alembic.op.drop_index") as mock_drop:
            mod.downgrade()

        assert mock_drop.call_count == 3


# ---------------------------------------------------------------------------
# Redis happy-path tests (covers rate_limit.py lines 45-52)
# ---------------------------------------------------------------------------

class TestRedisRateCheckSuccess:
    """Exercise the Redis-available code path in _redis_rate_check."""

    def test_first_request_calls_expire_and_returns_allowed(self):
        """count==1 → expire() called; ttl >= 0 → returns (True, remaining, ttl)."""
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = True
            rc = MagicMock()
            rc.incr.return_value = 1
            rc.ttl.return_value = 60
            mock_cache.redis_client = rc

            allowed, remaining, ttl_out = _redis_rate_check("redis:happy:1", 5, 60)

        assert allowed is True
        assert remaining == 4
        assert ttl_out == 60
        rc.expire.assert_called_with("redis:happy:1", 60)

    def test_negative_ttl_triggers_re_expire(self):
        """When ttl < 0 (key has no expiry), expire() is called again and ttl is set to window."""
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = True
            rc = MagicMock()
            rc.incr.return_value = 2
            rc.ttl.return_value = -1  # missing TTL — triggers lines 47-49
            mock_cache.redis_client = rc

            allowed, remaining, ttl_out = _redis_rate_check("redis:happy:2", 5, 60)

        assert allowed is True
        assert remaining == 3
        assert ttl_out == 60  # must use window_seconds as fallback

    def test_over_limit_returns_blocked(self):
        """count > max_requests → allowed is False, remaining is 0."""
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = True
            rc = MagicMock()
            rc.incr.return_value = 6
            rc.ttl.return_value = 30
            mock_cache.redis_client = rc

            allowed, remaining, _ = _redis_rate_check("redis:happy:3", 5, 60)

        assert allowed is False
        assert remaining == 0

    def test_subsequent_request_skips_initial_expire(self):
        """count > 1 → the `if count == 1` branch is skipped; ttl path still covered."""
        with patch("app.services.rate_limit._redis_cache") as mock_cache:
            mock_cache.is_available.return_value = True
            rc = MagicMock()
            rc.incr.return_value = 3
            rc.ttl.return_value = 45
            mock_cache.redis_client = rc

            allowed, remaining, ttl_out = _redis_rate_check("redis:happy:4", 5, 60)

        assert allowed is True
        assert remaining == 2
        assert ttl_out == 45


# ---------------------------------------------------------------------------
# main.py _check_rate_limit window-reset branch (lines 62-63)
# ---------------------------------------------------------------------------

class TestMainCheckRateLimitWindowReset:
    """Exercise the expired-window reset branch inside app.main._check_rate_limit."""

    def test_expired_window_resets_count(self):
        """When reset_at <= now, count is zeroed and a fresh window opens (lines 62-63)."""
        import time
        from app.main import _check_rate_limit, _RATE_LIMIT_BUCKETS

        key = "main:rl:reset_branch"
        # Plant an entry whose window already expired
        _RATE_LIMIT_BUCKETS[key] = (999, time.time() - 1)

        now = time.time()
        allowed, remaining, retry_after = _check_rate_limit(key, now)

        # After reset, count == 1, so request must be allowed
        assert allowed is True
        # remaining == max_requests - 1 (≥ 0)
        assert remaining >= 0
