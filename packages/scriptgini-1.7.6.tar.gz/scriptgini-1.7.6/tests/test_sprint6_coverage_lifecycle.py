"""Sprint 6 tests: coverage analytics, script refactor/version-history/diff/rollback, error envelope."""
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.api_key  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_revision  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app
from app.models.generated_script import GeneratedScript, ScriptStatus
from app.models.membership import ProjectMembership, Role
from app.models.script_revision import ScriptRevision, RevisionChangeType
from app.models.script_run import ScriptRun, ScriptRunStatus

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> tuple[int, dict]:
    register = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert register.status_code == 201
    user_id = register.json()["id"]
    login = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200
    token = login.json()["access_token"]
    return user_id, {"Authorization": f"Bearer {token}"}


def _create_project_and_tc(client: TestClient, owner_id: int, title: str = "Login Test") -> tuple[int, int]:
    proj = client.post("/api/v1/projects/", json={"name": "Sprint6Project", "aut_base_url": "https://example.com"})
    assert proj.status_code == 201
    project_id = proj.json()["id"]

    tc = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        json={"title": title, "format": "step_based", "content": "Step 1: Open login page"},
    )
    assert tc.status_code == 201
    tc_id = tc.json()["id"]
    return project_id, tc_id


def _add_script(project_id: int, tc_id: int, content: str = "print('hello')") -> int:
    db = TestingSessionLocal()
    script = GeneratedScript(
        project_id=project_id,
        test_case_id=tc_id,
        framework="playwright_python",
        llm_provider="openai",
        llm_model="gpt-4o",
        status=ScriptStatus.completed,
        script_content=content,
    )
    db.add(script)
    db.commit()
    db.refresh(script)
    script_id = script.id
    db.close()
    return script_id


def _add_revision(script_id: int, project_id: int, tc_id: int, content: str, num: int, change_type: RevisionChangeType) -> int:
    db = TestingSessionLocal()
    rev = ScriptRevision(
        script_id=script_id,
        project_id=project_id,
        test_case_id=tc_id,
        revision_number=num,
        script_content=content,
        change_type=change_type,
        change_summary=f"Revision {num}",
    )
    db.add(rev)
    db.commit()
    db.refresh(rev)
    rev_id = rev.id
    db.close()
    return rev_id


def _add_run(project_id: int, tc_id: int, script_id: int, success: bool) -> None:
    db = TestingSessionLocal()
    run = ScriptRun(
        script_id=script_id,
        project_id=project_id,
        test_case_id=tc_id,
        status=ScriptRunStatus.completed if success else ScriptRunStatus.failed,
        success=success,
        exit_code=0 if success else 1,
        stdout="ok" if success else "",
        stderr="" if success else "err",
        duration_seconds=1.0,
        command="python script.py",
    )
    db.add(run)
    db.commit()
    db.close()


# ===========================================================================
# Coverage analytics
# ===========================================================================

class TestCoverageAnalytics:
    def test_coverage_no_data(self, client):
        resp = client.get("/api/v1/analytics/coverage")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_cases"] == 0
        assert data["modules"] == []

    def test_coverage_project_not_found(self, client):
        resp = client.get("/api/v1/analytics/coverage?project_id=9999")
        assert resp.status_code == 404

    def test_coverage_with_scripted_and_run(self, client):
        user_id, headers = _register_and_login(client, "cov@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id, "Login Page")
        script_id = _add_script(project_id, tc_id, "print('v1')")
        _add_run(project_id, tc_id, script_id, success=True)

        resp = client.get(f"/api/v1/analytics/coverage?project_id={project_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_cases"] == 1
        assert data["scripted_cases"] == 1
        assert data["executed_cases"] == 1
        assert data["passed_cases"] == 1
        assert data["overall_coverage_rate"] == 100.0
        assert data["overall_execution_rate"] == 100.0
        assert len(data["modules"]) == 1
        module = data["modules"][0]
        assert module["module"] == "Login"  # first word of "Login Page"
        assert module["total_cases"] == 1

    def test_coverage_unscripted_case(self, client):
        user_id, headers = _register_and_login(client, "cov2@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id, "Checkout Flow")

        resp = client.get(f"/api/v1/analytics/coverage?project_id={project_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["scripted_cases"] == 0
        assert data["executed_cases"] == 0
        assert data["overall_coverage_rate"] == 0.0
        tc_item = data["modules"][0]["test_cases"][0]
        assert tc_item["has_script"] is False
        assert tc_item["has_run"] is False
        assert tc_item["last_run_success"] is None

    def test_coverage_global_no_project_filter(self, client):
        user_id, headers = _register_and_login(client, "cov3@test.com")
        _create_project_and_tc(client, user_id, "Global TC")

        resp = client.get("/api/v1/analytics/coverage")
        assert resp.status_code == 200
        data = resp.json()
        assert data["project_id"] is None
        assert data["total_cases"] >= 1


# ===========================================================================
# Script version history
# ===========================================================================

class TestScriptVersionHistory:
    def test_version_history_empty(self, client):
        user_id, _ = _register_and_login(client, "vh1@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history"
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_revisions"] == 0
        assert data["revisions"] == []

    def test_version_history_with_revisions(self, client):
        user_id, _ = _register_and_login(client, "vh2@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id)
        _add_revision(script_id, project_id, tc_id, "print('v1')", 1, RevisionChangeType.generated)
        _add_revision(script_id, project_id, tc_id, "print('v2')", 2, RevisionChangeType.refactored)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history"
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_revisions"] == 2
        assert data["revisions"][0]["revision_number"] == 1
        assert data["revisions"][1]["revision_number"] == 2
        assert data["revisions"][1]["change_type"] == "refactored"

    def test_version_history_script_not_found(self, client):
        user_id, _ = _register_and_login(client, "vh3@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/9999/version-history"
        )
        assert resp.status_code == 404


# ===========================================================================
# Script diff
# ===========================================================================

class TestScriptDiff:
    def test_diff_first_revision(self, client):
        user_id, _ = _register_and_login(client, "diff1@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('v1')")
        rev_id = _add_revision(script_id, project_id, tc_id, "print('v1')", 1, RevisionChangeType.generated)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history/{rev_id}/diff"
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["from_revision"] == 0  # no prior revision
        assert data["to_revision"] == 1
        assert data["from_content"] == ""
        assert "v1" in data["to_content"]

    def test_diff_second_revision(self, client):
        user_id, _ = _register_and_login(client, "diff2@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id)
        _add_revision(script_id, project_id, tc_id, "print('v1')", 1, RevisionChangeType.generated)
        rev2_id = _add_revision(script_id, project_id, tc_id, "print('v2')", 2, RevisionChangeType.refactored)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history/{rev2_id}/diff"
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["from_revision"] == 1
        assert data["to_revision"] == 2
        assert len(data["diff_lines"]) > 0

    def test_diff_revision_not_found(self, client):
        user_id, _ = _register_and_login(client, "diff3@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id)

        resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history/9999/diff"
        )
        assert resp.status_code == 404


# ===========================================================================
# Script rollback
# ===========================================================================

class TestScriptRollback:
    def test_rollback_to_revision(self, client):
        user_id, _ = _register_and_login(client, "rb1@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('current')")
        rev_id = _add_revision(script_id, project_id, tc_id, "print('original')", 1, RevisionChangeType.generated)

        resp = client.post(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/rollback/{rev_id}"
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["script_content"] == "print('original')"
        assert data["status"] == "completed"

    def test_rollback_records_rolled_back_revision(self, client):
        user_id, _ = _register_and_login(client, "rb2@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('current')")
        rev_id = _add_revision(script_id, project_id, tc_id, "print('old')", 1, RevisionChangeType.generated)

        client.post(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/rollback/{rev_id}"
        )

        history_resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history"
        )
        assert history_resp.status_code == 200
        revisions = history_resp.json()["revisions"]
        change_types = [r["change_type"] for r in revisions]
        assert "rolled_back" in change_types

    def test_rollback_revision_not_found(self, client):
        user_id, _ = _register_and_login(client, "rb3@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id)

        resp = client.post(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/rollback/9999"
        )
        assert resp.status_code == 404


# ===========================================================================
# Script refactor (mocked LLM)
# ===========================================================================

class TestScriptRefactor:
    def test_refactor_success(self, client):
        user_id, _ = _register_and_login(client, "ref1@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('broken')")

        mock_result = {"script": "print('fixed')", "error": None, "token_usage": 50}
        with patch("app.routers.scripts._run_agent_with_deadline", return_value=mock_result):
            resp = client.post(
                f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
                json={"error_log": "NameError: name 'x' is not defined"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["script_content"] == "print('fixed')"
        assert data["revision_number"] == 1
        assert "NameError" in data["change_summary"]

    def test_refactor_no_content(self, client):
        user_id, _ = _register_and_login(client, "ref2@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)

        db = TestingSessionLocal()
        script = GeneratedScript(
            project_id=project_id,
            test_case_id=tc_id,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.pending,
            script_content=None,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        empty_script_id = script.id
        db.close()

        resp = client.post(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{empty_script_id}/refactor",
            json={"error_log": "some error"},
        )
        assert resp.status_code == 400

    def test_refactor_script_not_found(self, client):
        user_id, _ = _register_and_login(client, "ref3@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)

        resp = client.post(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/9999/refactor",
            json={"error_log": "some error"},
        )
        assert resp.status_code == 404

    def test_refactor_saves_revision(self, client):
        user_id, _ = _register_and_login(client, "ref4@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('broken')")

        mock_result = {"script": "print('healed')", "error": None, "token_usage": 40}
        with patch("app.routers.scripts._run_agent_with_deadline", return_value=mock_result):
            client.post(
                f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
                json={"error_log": "AttributeError: missing attr"},
            )

        history_resp = client.get(
            f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history"
        )
        data = history_resp.json()
        assert data["total_revisions"] == 1
        assert data["revisions"][0]["change_type"] == "refactored"

    def test_refactor_timeout_returns_504(self, client):
        user_id, _ = _register_and_login(client, "ref5@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('broken')")

        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=TimeoutError("agent timed out")):
            resp = client.post(
                f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
                json={"error_log": "Timeout while running"},
            )

        assert resp.status_code == 504
        assert "agent timed out" in resp.json()["error"]["message"]

    def test_refactor_agent_exception_returns_500(self, client):
        user_id, _ = _register_and_login(client, "ref6@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('broken')")

        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=RuntimeError("provider down")):
            resp = client.post(
                f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
                json={"error_log": "Runtime failed"},
            )

        assert resp.status_code == 500
        assert "Refactor agent failed: provider down" in resp.json()["error"]["message"]

    def test_refactor_result_error_without_script_returns_500(self, client):
        user_id, _ = _register_and_login(client, "ref7@test.com")
        project_id, tc_id = _create_project_and_tc(client, user_id)
        script_id = _add_script(project_id, tc_id, "print('broken')")

        mock_result = {"script": None, "error": "healing failed", "token_usage": 5}
        with patch("app.routers.scripts._run_agent_with_deadline", return_value=mock_result):
            resp = client.post(
                f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
                json={"error_log": "Traceback..."},
            )

        assert resp.status_code == 500
        assert "Refactor failed: healing failed" in resp.json()["error"]["message"]


# ===========================================================================
# Standardized error envelope
# ===========================================================================

class TestErrorEnvelope:
    def test_404_returns_error_envelope(self, client):
        resp = client.get("/api/v1/projects/999999/test-cases/")
        assert resp.status_code == 404
        body = resp.json()
        assert "error" in body
        err = body["error"]
        assert err["code"] == "not_found"
        assert "request_id" in err

    def test_422_returns_error_envelope(self, client):
        # Send an invalid payload to an endpoint that expects proper JSON
        resp = client.post("/api/v1/projects/", json={"not_a_field": True})
        assert resp.status_code == 422
        body = resp.json()
        assert "error" in body
        err = body["error"]
        assert err["code"] == "validation_error"
        assert "errors" in err["context"]
        assert "request_id" in err

    def test_request_id_propagated_in_header(self, client):
        resp = client.get("/api/v1/projects/999999/test-cases/", headers={"X-Request-ID": "test-req-123"})
        assert resp.headers.get("X-Request-ID") == "test-req-123"
