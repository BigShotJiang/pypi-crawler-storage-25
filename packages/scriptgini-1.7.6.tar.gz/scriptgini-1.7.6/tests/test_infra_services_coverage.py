import types
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
import jwt
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.user  # noqa: F401
import app.models.api_key  # noqa: F401
from app.database import Base
from app.models.api_key import APIKey
from app.models.user import User


class DummyRedis:
    def __init__(self):
        self.store = {}
        self.expiry = {}

    def ping(self):
        return True

    def setex(self, key, ttl, value):
        self.store[key] = value
        self.expiry[key] = ttl
        return True

    def get(self, key):
        return self.store.get(key)

    def delete(self, *keys):
        deleted = 0
        for key in keys:
            if key in self.store:
                deleted += 1
                del self.store[key]
                self.expiry.pop(key, None)
        return deleted

    def keys(self, pattern):
        if pattern == "*":
            return list(self.store.keys())
        if pattern.endswith("*"):
            prefix = pattern[:-1]
            return [k for k in self.store if k.startswith(prefix)]
        return [k for k in self.store if k == pattern]

    def incrby(self, key, amount):
        current = int(self.store.get(key, 0))
        current += amount
        self.store[key] = str(current)
        return current

    def ttl(self, key):
        if key not in self.store:
            return -2
        return self.expiry.get(key, -1)


@pytest.fixture
def db_session():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine, autocommit=False, autoflush=False)
    Base.metadata.create_all(bind=engine)
    db = Session()
    try:
        yield db
    finally:
        db.close()
        Base.metadata.drop_all(bind=engine)
        engine.dispose()


def _make_user(db, email="u@example.com", active=True):
    user = User(email=email, hashed_password="hash", is_active=active)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def _make_api_key(db, user_id, prefix="sg_abcd", secret_hash="secret_hash", **kwargs):
    api_key = APIKey(
        user_id=user_id,
        name=kwargs.get("name", "Key"),
        prefix=prefix,
        hashed_secret=secret_hash,
        scopes=kwargs.get("scopes", ["read"]),
        is_active=kwargs.get("is_active", True),
        expires_at=kwargs.get("expires_at"),
    )
    db.add(api_key)
    db.commit()
    db.refresh(api_key)
    return api_key


def test_cache_set_get_delete_increment_and_ttl(monkeypatch):
    from app.cache import RedisCache

    dummy = DummyRedis()
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: dummy)
    cache = RedisCache("redis://localhost:6379/0")

    assert cache.set("k1", "value", ttl=33) is True
    assert cache.get("k1") == "value"

    assert cache.set("k2", {"a": 1}, ttl=40) is True
    assert cache.get("k2") == {"a": 1}

    assert cache.increment("counter", 2) == 2
    assert cache.get_ttl("k1") == 33
    assert cache.delete("k1") is True
    assert cache.get("k1", default="x") == "x"


def test_cache_clear_pattern_and_decorator(monkeypatch):
    from app.cache import RedisCache

    dummy = DummyRedis()
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: dummy)
    cache = RedisCache("redis://localhost:6379/0")

    cache.set("user:1", "a", ttl=10)
    cache.set("user:2", "b", ttl=10)
    cache.set("other:1", "c", ttl=10)
    assert cache.clear_pattern("user:*") == 2

    calls = {"count": 0}

    @cache.cached(ttl=20)
    def expensive(x):
        calls["count"] += 1
        return {"v": x}

    assert expensive(9) == {"v": 9}
    assert expensive(9) == {"v": 9}
    assert calls["count"] == 1


def test_cache_clear_pattern_no_matches(monkeypatch):
    from app.cache import RedisCache

    dummy = DummyRedis()
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: dummy)
    cache = RedisCache("redis://localhost:6379/0")

    cache.set("alpha:1", "a", ttl=10)
    assert cache.clear_pattern("user:*") == 0


def test_cache_decorator_cache_hit_logs_debug(monkeypatch):
    from app.cache import RedisCache, logger

    dummy = DummyRedis()
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: dummy)
    cache = RedisCache("redis://localhost:6379/0")

    logged = {"called": False}
    monkeypatch.setattr(logger, "debug", lambda *a, **k: logged.update(called=True))

    @cache.cached(ttl=20)
    def cached_func(x):
        return {"v": x}

    cached_func(7)
    cached_func(7)
    assert logged["called"] is True


def test_cache_unavailable_and_error_paths(monkeypatch):
    from app.cache import RedisCache

    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("no redis")))
    cache = RedisCache("redis://bad")

    assert cache.is_available() is False
    assert cache.set("k", "v") is False
    assert cache.get("k", default="d") == "d"
    assert cache.delete("k") is False
    assert cache.clear_pattern("*") == 0
    assert cache.increment("c") is None
    assert cache.get_ttl("k") is None


def test_cache_runtime_exceptions(monkeypatch):
    from app.cache import RedisCache

    dummy = DummyRedis()
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: dummy)
    cache = RedisCache("redis://localhost")

    def boom(*args, **kwargs):
        raise RuntimeError("boom")

    monkeypatch.setattr(cache.redis_client, "setex", boom)
    assert cache.set("k", "v") is False

    monkeypatch.setattr(cache.redis_client, "get", boom)
    assert cache.get("k", default=1) == 1

    monkeypatch.setattr(cache.redis_client, "delete", boom)
    assert cache.delete("k") is False

    monkeypatch.setattr(cache.redis_client, "keys", boom)
    assert cache.clear_pattern("*") == 0

    monkeypatch.setattr(cache.redis_client, "incrby", boom)
    assert cache.increment("k") is None

    monkeypatch.setattr(cache.redis_client, "ttl", boom)
    assert cache.get_ttl("k") is None


def test_celery_app_configuration_and_debug_task(capsys):
    from app.celery_app import celery_app, debug_task
    from app.config import settings

    assert celery_app.conf.task_serializer == "json"
    assert celery_app.conf.result_serializer == "json"
    assert celery_app.conf.enable_utc is True
    assert celery_app.conf.task_time_limit == settings.CELERY_TASK_HARD_TIMEOUT
    assert celery_app.conf.task_soft_time_limit == settings.CELERY_TASK_TIMEOUT

    result = debug_task.apply().result
    out = capsys.readouterr().out
    assert result == "Celery is working!"


def test_tasks_success_paths(monkeypatch):
    from app import tasks

    closed = {"count": 0}

    class DummySession:
        def close(self):
            closed["count"] += 1

    monkeypatch.setattr(tasks, "SessionLocal", lambda: DummySession())

    generated = tasks.generate_test_script.run(1, 2)
    executed = tasks.execute_script.run(10, {"HEADLESS": "1"})
    bulk = tasks.bulk_job_processor.run(99)
    cleanup = tasks.cleanup_old_artifacts(7)

    assert generated["status"] == "success"
    assert executed["status"] == "success"
    assert bulk["status"] == "completed"
    assert cleanup["status"] == "completed"
    assert closed["count"] == 4


def test_tasks_retry_paths(monkeypatch):
    from app import tasks

    closed = {"count": 0}

    class DummySession:
        def close(self):
            closed["count"] += 1

    monkeypatch.setattr(tasks, "SessionLocal", lambda: DummySession())
    monkeypatch.setattr(tasks.logger, "info", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))

    with pytest.raises(Exception):
        tasks.generate_test_script.run(1, 2)

    with pytest.raises(Exception):
        tasks.execute_script.run(1, {})

    with pytest.raises(Exception):
        tasks.bulk_job_processor.run(1)

    assert closed["count"] == 3


def test_queue_task_wrappers_success(monkeypatch):
    from app import tasks

    monkeypatch.setattr("app.routers.scripts._run_generation", lambda *a, **k: None)
    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_generation", lambda *a, **k: None)
    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_execution", lambda *a, **k: None)

    generated = tasks.process_script_generation_job.run(11, 1, 2, {"llm_provider": "openai"})
    bulk_gen = tasks.process_bulk_generation_job.run(22, {"llm_provider": "openai"})
    bulk_run = tasks.process_bulk_execution_job.run(33, {})

    assert generated["status"] == "completed"
    assert bulk_gen["status"] == "completed"
    assert bulk_run["status"] == "completed"


def test_queue_task_wrappers_retry_and_dead_letter(monkeypatch):
    from app import tasks

    monkeypatch.setattr("app.routers.scripts._run_generation", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    monkeypatch.setattr(tasks, "_log_dead_letter", lambda *a, **k: None)

    with pytest.raises(Exception):
        tasks.process_script_generation_job.run(11, 1, 2, {"llm_provider": "openai"})


def test_retry_countdown_helper():
    from app.tasks import _retry_countdown

    assert _retry_countdown(0) == 5
    assert _retry_countdown(1) == 25
    assert _retry_countdown(4) == 300


def test_tasks_dead_letter_branches(monkeypatch):
    from app import tasks

    dead_letters = []
    monkeypatch.setattr(tasks, "_log_dead_letter", lambda *a, **k: dead_letters.append((a, k)))

    # Wrapper task dead-letter branches (retries >= max_retries)
    monkeypatch.setattr("app.routers.scripts._run_generation", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("gboom")))
    original = tasks.process_script_generation_job.max_retries
    tasks.process_script_generation_job.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.process_script_generation_job.run(1, 1, 1, {"llm_provider": "openai"})
    tasks.process_script_generation_job.max_retries = original

    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_generation", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("bgboom")))
    original = tasks.process_bulk_generation_job.max_retries
    tasks.process_bulk_generation_job.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.process_bulk_generation_job.run(2, {"llm_provider": "openai"})
    tasks.process_bulk_generation_job.max_retries = original

    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_execution", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("beboom")))
    original = tasks.process_bulk_execution_job.max_retries
    tasks.process_bulk_execution_job.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.process_bulk_execution_job.run(3, {})
    tasks.process_bulk_execution_job.max_retries = original

    # Legacy task dead-letter branches
    closed = {"count": 0}

    class DummySession:
        def close(self):
            closed["count"] += 1

    monkeypatch.setattr(tasks, "SessionLocal", lambda: DummySession())
    monkeypatch.setattr(tasks.logger, "info", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))

    original = tasks.generate_test_script.max_retries
    tasks.generate_test_script.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.generate_test_script.run(1, 2)
    tasks.generate_test_script.max_retries = original

    original = tasks.execute_script.max_retries
    tasks.execute_script.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.execute_script.run(1, {})
    tasks.execute_script.max_retries = original

    original = tasks.bulk_job_processor.max_retries
    tasks.bulk_job_processor.max_retries = 0
    with pytest.raises(RuntimeError):
        tasks.bulk_job_processor.run(1)
    tasks.bulk_job_processor.max_retries = original

    assert closed["count"] == 3
    assert len(dead_letters) >= 6


def test_log_dead_letter_emits_logger(monkeypatch):
    from app import tasks

    called = {"ok": False}
    monkeypatch.setattr(tasks.logger, "error", lambda *a, **k: called.update(ok=True))
    tasks._log_dead_letter("task", 1, RuntimeError("x"))
    assert called["ok"] is True


def test_bulk_wrapper_retry_paths(monkeypatch):
    from app import tasks

    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_generation", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("bg boom")))
    monkeypatch.setattr("app.routers.bulk_jobs._run_bulk_execution", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("be boom")))

    with pytest.raises(Exception):
        tasks.process_bulk_generation_job.run(10, {"llm_provider": "openai"})

    with pytest.raises(Exception):
        tasks.process_bulk_execution_job.run(11, {})


def test_auth_dependencies_paths(monkeypatch):
    from app.services import auth_dependencies as deps

    creds = SimpleNamespace(credentials="token")
    db = object()

    monkeypatch.setattr(deps.auth_service, "verify_token", lambda *a, **k: None)
    with pytest.raises(HTTPException) as e1:
        deps.get_current_user(creds, db)
    assert e1.value.status_code == 401

    token_data = SimpleNamespace(user_id=1)
    monkeypatch.setattr(deps.auth_service, "verify_token", lambda *a, **k: token_data)
    monkeypatch.setattr(deps.auth_service, "get_user_by_id", lambda *a, **k: None)
    with pytest.raises(HTTPException) as e2:
        deps.get_current_user(creds, db)
    assert e2.value.status_code == 401

    inactive_user = SimpleNamespace(is_active=False)
    monkeypatch.setattr(deps.auth_service, "get_user_by_id", lambda *a, **k: inactive_user)
    with pytest.raises(HTTPException) as e3:
        deps.get_current_user(creds, db)
    assert e3.value.status_code == 403

    active_user = SimpleNamespace(is_active=True)
    monkeypatch.setattr(deps.auth_service, "get_user_by_id", lambda *a, **k: active_user)
    assert deps.get_current_user(creds, db) is active_user


def test_auth_dependencies_or_api_key_paths(monkeypatch):
    from app.services import auth_dependencies as deps

    db = object()

    # JWT path success
    creds_jwt = SimpleNamespace(credentials="jwt_token")
    jwt_data = SimpleNamespace(user_id=9)
    jwt_user = SimpleNamespace(is_active=True)
    monkeypatch.setattr(deps.auth_service, "verify_token", lambda *a, **k: jwt_data)
    monkeypatch.setattr(deps.auth_service, "get_user_by_id", lambda *a, **k: jwt_user)
    assert deps.get_current_user_or_api_key(creds_jwt, db) is jwt_user

    # API key path success
    creds_key = SimpleNamespace(credentials="sg_abcd:secret")
    api_key_obj = SimpleNamespace(user_id=21)
    key_user = SimpleNamespace(is_active=True)

    monkeypatch.setattr(deps.auth_service, "verify_token", lambda *a, **k: None)
    monkeypatch.setattr(deps.api_key_service, "verify_api_key", lambda *a, **k: api_key_obj)
    monkeypatch.setattr(deps.auth_service, "get_user_by_id", lambda *a, **k: key_user)

    result = deps.get_current_user_or_api_key(creds_key, db)
    assert result is key_user
    assert getattr(result, "_api_key") is api_key_obj

    # Failure path
    monkeypatch.setattr(deps.api_key_service, "verify_api_key", lambda *a, **k: None)
    with pytest.raises(HTTPException) as e:
        deps.get_current_user_or_api_key(creds_key, db)
    assert e.value.status_code == 401


def test_auth_dependencies_optional_current_user_invalid_credentials(monkeypatch):
    from app.services import auth_dependencies as deps

    db = object()
    creds = SimpleNamespace(credentials="invalid_key_format")

    monkeypatch.setattr(deps.auth_service, "verify_token", lambda *a, **k: None)

    with pytest.raises(HTTPException) as exc:
        deps.get_optional_current_user_or_api_key(creds, db)

    assert exc.value.status_code == 401


def test_require_optional_auth_with_scopes_rejects_insufficient_api_key_scopes():
    from app.services import auth_dependencies as deps

    api_key_user = SimpleNamespace(_api_key=SimpleNamespace(scopes=["scripts:read"]))
    dependency = deps.require_optional_auth_with_scopes({"scripts:write"})

    with pytest.raises(HTTPException) as exc:
        dependency(api_key_user)

    assert exc.value.status_code == 403


def test_api_key_service_verify_and_crud_paths(db_session, monkeypatch):
    from app.services import api_key as svc

    user = _make_user(db_session, email="api@example.com", active=True)

    # hash/verify helpers
    hashed = svc.hash_api_key_secret("sg_abcd_secret")
    assert svc.verify_api_key_secret("sg_abcd_secret", hashed) is True
    assert svc.verify_api_key_secret("wrong", hashed) is False

    # create + verify by prefix
    api_key, full_secret = svc.create_api_key(db_session, user.id, "Primary", ["read"]) 
    verified = svc.verify_api_key(db_session, api_key.prefix, full_secret)
    assert verified is not None
    assert verified.last_used_at is not None

    # verify by id path
    verified_by_id = svc.verify_api_key(db_session, str(api_key.id), full_secret)
    assert verified_by_id is not None

    # not found path
    assert svc.verify_api_key(db_session, "does_not_exist", full_secret) is None

    # inactive path
    api_key.is_active = False
    db_session.commit()
    assert svc.verify_api_key(db_session, api_key.prefix, full_secret) is None

    # expired path
    api_key.is_active = True
    api_key.expires_at = datetime.now(timezone.utc) - timedelta(days=1)
    db_session.commit()
    assert svc.verify_api_key(db_session, api_key.prefix, full_secret) is None

    # wrong secret path
    api_key.expires_at = None
    db_session.commit()
    assert svc.verify_api_key(db_session, api_key.prefix, "wrong_secret") is None

    # query helpers and CRUD not-found paths
    all_keys = svc.get_user_api_keys(db_session, user.id)
    assert len(all_keys) >= 1
    assert svc.update_api_key(db_session, 99999, name="x") is None
    assert svc.revoke_api_key(db_session, 99999) is None
    assert svc.delete_api_key(db_session, 99999) is False

    # CRUD success paths
    updated = svc.update_api_key(db_session, api_key.id, name="Updated", scopes=["read", "write"])
    assert updated is not None
    assert updated.name == "Updated"
    assert updated.scopes == ["read", "write"]

    revoked = svc.revoke_api_key(db_session, api_key.id)
    assert revoked is not None
    assert revoked.is_active is False

    # make active and test delete success
    revoked.is_active = True
    db_session.commit()
    assert svc.delete_api_key(db_session, api_key.id) is True
    assert svc.get_api_key_by_id(db_session, api_key.id) is None


def test_api_key_service_update_with_expires_at_branch(db_session):
    from app.services import api_key as svc

    user = _make_user(db_session, email="expiry@example.com", active=True)
    api_key, _ = svc.create_api_key(db_session, user.id, "Expirable", ["read"])

    expires = datetime.now(timezone.utc) + timedelta(days=7)
    updated = svc.update_api_key(db_session, api_key.id, expires_at=expires)
    assert updated is not None
    assert updated.expires_at is not None


def test_auth_verify_token_exception_branches(monkeypatch):
    from app.services import auth as auth_service

    monkeypatch.setattr(auth_service.jwt, "decode", lambda *a, **k: (_ for _ in ()).throw(jwt.ExpiredSignatureError("expired")))
    assert auth_service.verify_token("token") is None

    monkeypatch.setattr(auth_service.jwt, "decode", lambda *a, **k: (_ for _ in ()).throw(jwt.InvalidTokenError("invalid")))
    assert auth_service.verify_token("token") is None


def test_auth_verify_token_invalid_payload_guard(monkeypatch):
    from app.services import auth as auth_service

    monkeypatch.setattr(
        auth_service.jwt,
        "decode",
        lambda *a, **k: {"user_id": 1, "token_type": "access"},
    )
    assert auth_service.verify_token("token", token_type="access") is None
