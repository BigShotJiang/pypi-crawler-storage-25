from unittest.mock import MagicMock


class _PingRedis:
    def __init__(self):
        self.ping_called = False

    def ping(self):
        self.ping_called = True
        return True


def test_cache_init_success_path_when_redis_enabled(monkeypatch):
    from app.cache import RedisCache

    redis_client = _PingRedis()
    monkeypatch.delenv("SCRIPTGINI_DISABLE_REDIS_INIT", raising=False)
    monkeypatch.setattr("app.cache.redis.from_url", lambda *a, **k: redis_client)

    cache = RedisCache("redis://localhost:6379/0")

    assert cache.is_available() is True
    assert cache.redis_client is redis_client
    assert redis_client.ping_called is True


def test_cache_init_is_skipped_when_disable_env_is_set(monkeypatch):
    from app.cache import RedisCache

    monkeypatch.setenv("SCRIPTGINI_DISABLE_REDIS_INIT", "1")

    cache = RedisCache("redis://localhost:6379/0")

    assert cache.is_available() is False
    assert cache.redis_client is None


def test_provider_secret_openai_branch_is_reachable():
    from app.llm import provider as p

    env_name, value = p._provider_secret("openai")

    assert env_name == "OPENAI_API_KEY"
    assert isinstance(value, str)


def test_openai_factory_includes_api_key_when_present(monkeypatch):
    from app.llm import provider as p

    mock_cls = MagicMock()
    monkeypatch.setattr(p.settings, "OPENAI_API_KEY", "sk-openai-1234")
    monkeypatch.setattr(p.settings, "LLM_REQUEST_TIMEOUT_SECONDS", 91)

    with monkeypatch.context() as m:
        m.setitem(__import__("sys").modules, "langchain_openai", MagicMock(ChatOpenAI=mock_cls))
        p._openai("gpt-4o", 0.25)

    kwargs = mock_cls.call_args.kwargs
    assert kwargs["api_key"] == "sk-openai-1234"
    assert kwargs["model"] == "gpt-4o"
    assert kwargs["temperature"] == 0.25
    assert kwargs["timeout"] == 91


def test_openrouter_factory_includes_api_key_when_present(monkeypatch):
    from app.llm import provider as p

    mock_cls = MagicMock()
    monkeypatch.setattr(p.settings, "OPENROUTER_API_KEY", "sk-openrouter-5678")

    with monkeypatch.context() as m:
        m.setitem(__import__("sys").modules, "langchain_openai", MagicMock(ChatOpenAI=mock_cls))
        p._openrouter("openai/gpt-4o", 0.15)

    kwargs = mock_cls.call_args.kwargs
    assert kwargs["api_key"] == "sk-openrouter-5678"
    assert kwargs["model"] == "openai/gpt-4o"


def test_gemini_factory_includes_api_key_when_present(monkeypatch):
    from app.llm import provider as p

    mock_cls = MagicMock()
    monkeypatch.setattr(p.settings, "GOOGLE_API_KEY", "google-key-9999")

    with monkeypatch.context() as m:
        m.setitem(__import__("sys").modules, "langchain_google_genai", MagicMock(ChatGoogleGenerativeAI=mock_cls))
        p._gemini("models/gemini-1.5-pro", 0.05)

    kwargs = mock_cls.call_args.kwargs
    assert kwargs["google_api_key"] == "google-key-9999"
    assert kwargs["model"] == "gemini-1.5-pro"
