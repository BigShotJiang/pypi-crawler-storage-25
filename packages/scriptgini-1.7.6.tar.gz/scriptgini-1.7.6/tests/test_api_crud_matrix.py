"""API CRUD matrix tests for persisted objects.

These tests validate that major persisted objects are manipulated through API
endpoints (create/read/update/delete where supported).
"""

from __future__ import annotations

from types import SimpleNamespace
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.api_key  # noqa: F401
import app.models.bulk_job  # noqa: F401
import app.models.execution_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.organization  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_revision  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401
import app.models.workspace  # noqa: F401
import app.models.user_story  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app
from app.models.generated_script import GeneratedScript, ScriptStatus

TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client():
    return TestClient(fastapi_app, raise_server_exceptions=False)


def _new_email(prefix: str) -> str:
    return f"{prefix}-{uuid4().hex[:8]}@example.com"


def _register_and_login(client: TestClient, email: str | None = None, password: str = "TestPassword123!") -> dict:
    user_email = email or _new_email("user")
    reg = client.post("/api/v1/auth/register", json={"email": user_email, "password": password})
    assert reg.status_code == 201, reg.text

    login = client.post("/api/v1/auth/login", json={"email": user_email, "password": password})
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]

    return {
        "email": user_email,
        "password": password,
        "token": token,
        "headers": {"Authorization": f"Bearer {token}"},
        "user_id": reg.json()["id"],
        "refresh_token": login.json()["refresh_token"],
    }


def _create_project(client: TestClient, headers: dict[str, str], name: str = "CRUD Project") -> int:
    resp = client.post(
        "/api/v1/projects/",
        headers=headers,
        json={
            "name": name,
            "aut_base_url": "https://example.com",
            "default_framework": "playwright_python",
            "selector_preference": "role",
        },
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["id"]


def _create_test_case(client: TestClient, headers: dict[str, str], project_id: int, title: str = "TC CRUD") -> int:
    resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        headers=headers,
        json={
            "title": title,
            "format": "step_based",
            "content": "Step 1: Open app\nStep 2: Validate behavior",
            "preconditions": "User exists",
            "test_data_hints": "none",
            "tags": ["crud"],
            "priority": "high",
        },
    )
    assert resp.status_code == 201, resp.text
    return resp.json()["id"]


def _mark_script_completed(script_id: int, script_content: str = "print('ok')") -> None:
    db = TestingSessionLocal()
    try:
        row = db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        assert row is not None
        row.script_content = script_content
        row.status = ScriptStatus.completed
        db.commit()
    finally:
        db.close()


def test_users_api_keys_and_organizations_crud_via_api(client: TestClient):
    identity = _register_and_login(client)
    headers = identity["headers"]

    refresh_resp = client.post("/api/v1/auth/refresh", json={"refresh_token": identity["refresh_token"]})
    assert refresh_resp.status_code == 200, refresh_resp.text
    assert "access_token" in refresh_resp.json()

    logout_resp = client.post("/api/v1/auth/logout")
    assert logout_resp.status_code == 204

    create_key = client.post(
        "/api/v1/auth/api-keys",
        headers=headers,
        json={
            "name": "Primary Key",
            "scopes": [
                "projects:read",
                "projects:write",
                "test-cases:read",
                "test-cases:write",
                "scripts:read",
                "scripts:write",
                "bulk-jobs:read",
                "bulk-jobs:write",
                "analytics:read",
                "execution:read",
                "execution:write",
                "org:read",
                "org:write",
                "members:read",
                "members:write",
            ],
        },
    )
    assert create_key.status_code == 201, create_key.text
    key_payload = create_key.json()
    key_id = key_payload["id"]
    assert key_payload["secret_key"]

    list_keys = client.get("/api/v1/auth/api-keys", headers=headers)
    assert list_keys.status_code == 200
    assert any(k["id"] == key_id for k in list_keys.json())

    get_key = client.get(f"/api/v1/auth/api-keys/{key_id}", headers=headers)
    assert get_key.status_code == 200
    assert get_key.json()["id"] == key_id

    update_key = client.put(
        f"/api/v1/auth/api-keys/{key_id}",
        headers=headers,
        json={"name": "Primary Key Updated", "scopes": ["projects:read"]},
    )
    assert update_key.status_code == 200, update_key.text
    assert update_key.json()["name"] == "Primary Key Updated"

    delete_key = client.delete(f"/api/v1/auth/api-keys/{key_id}", headers=headers)
    assert delete_key.status_code == 204, delete_key.text

    get_deleted_key = client.get(f"/api/v1/auth/api-keys/{key_id}", headers=headers)
    assert get_deleted_key.status_code == 200
    assert get_deleted_key.json()["is_active"] is False

    create_org = client.post(
        "/api/v1/organizations",
        headers=headers,
        json={"name": f"Org-{uuid4().hex[:8]}", "description": "CRUD org"},
    )
    assert create_org.status_code == 201, create_org.text

    list_orgs = client.get("/api/v1/organizations", headers=headers)
    assert list_orgs.status_code == 200
    assert any(org["id"] == create_org.json()["id"] for org in list_orgs.json())


def test_projects_memberships_and_test_cases_crud_via_api(client: TestClient):
    owner = _register_and_login(client, email=_new_email("owner"))
    member = _register_and_login(client, email=_new_email("member"))
    owner_headers = owner["headers"]

    project_id = _create_project(client, owner_headers, name="Matrix Project")

    list_projects = client.get("/api/v1/projects/", headers=owner_headers)
    assert list_projects.status_code == 200
    assert any(p["id"] == project_id for p in list_projects.json())

    get_project = client.get(f"/api/v1/projects/{project_id}", headers=owner_headers)
    assert get_project.status_code == 200

    patch_project = client.patch(
        f"/api/v1/projects/{project_id}",
        headers=owner_headers,
        json={"name": "Matrix Project Updated"},
    )
    assert patch_project.status_code == 200
    assert patch_project.json()["name"] == "Matrix Project Updated"

    put_member = client.put(
        f"/api/v1/projects/{project_id}/members/{member['user_id']}",
        headers=owner_headers,
        json={"role": "member", "is_active": True},
    )
    assert put_member.status_code == 200, put_member.text

    list_members = client.get(f"/api/v1/projects/{project_id}/members", headers=owner_headers)
    assert list_members.status_code == 200
    assert any(m["user_id"] == member["user_id"] for m in list_members.json())

    delete_member = client.delete(f"/api/v1/projects/{project_id}/members/{member['user_id']}", headers=owner_headers)
    assert delete_member.status_code == 204, delete_member.text

    tc_id = _create_test_case(client, owner_headers, project_id, title="TC Matrix CRUD")

    list_tcs = client.get(f"/api/v1/projects/{project_id}/test-cases/", headers=owner_headers)
    assert list_tcs.status_code == 200
    assert any(tc["id"] == tc_id for tc in list_tcs.json())

    get_tc = client.get(f"/api/v1/projects/{project_id}/test-cases/{tc_id}", headers=owner_headers)
    assert get_tc.status_code == 200

    patch_tc = client.patch(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}",
        headers=owner_headers,
        json={"title": "TC Matrix CRUD Updated"},
    )
    assert patch_tc.status_code == 200
    assert patch_tc.json()["title"] == "TC Matrix CRUD Updated"

    delete_tc = client.delete(f"/api/v1/projects/{project_id}/test-cases/{tc_id}", headers=owner_headers)
    assert delete_tc.status_code == 204

    get_deleted_tc = client.get(f"/api/v1/projects/{project_id}/test-cases/{tc_id}", headers=owner_headers)
    assert get_deleted_tc.status_code == 404

    delete_project = client.delete(f"/api/v1/projects/{project_id}", headers=owner_headers)
    assert delete_project.status_code == 204

    get_deleted_project = client.get(f"/api/v1/projects/{project_id}", headers=owner_headers)
    assert get_deleted_project.status_code == 404


def test_scripts_bulk_execution_reports_and_metrics_via_api(client: TestClient, monkeypatch: pytest.MonkeyPatch):
    owner = _register_and_login(client, email=_new_email("runner"))
    headers = owner["headers"]

    project_id = _create_project(client, headers, name="Matrix Script Project")
    tc_id = _create_test_case(client, headers, project_id, title="Checkout happy path")

    monkeypatch.setattr(
        "app.routers.scripts.process_script_generation_job",
        SimpleNamespace(delay=lambda *a, **k: None),
    )

    generated = client.post(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/generate",
        headers=headers,
        json={"llm_provider": "openai", "framework": "playwright_python"},
    )
    assert generated.status_code == 202, generated.text
    script_id = generated.json()["id"]

    list_scripts = client.get(f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/", headers=headers)
    assert list_scripts.status_code == 200
    assert any(s["id"] == script_id for s in list_scripts.json())

    get_script = client.get(f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}", headers=headers)
    assert get_script.status_code == 200

    _mark_script_completed(script_id, script_content="print('first version')")
    monkeypatch.setattr(
        "app.routers.scripts.run_agent",
        lambda **kwargs: {"script": "print('refactored version')", "error": None, "token_usage": 5},
    )

    refactor_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
        headers=headers,
        json={"error_log": "NameError: missing variable", "llm_provider": "openai"},
    )
    assert refactor_resp.status_code == 200, refactor_resp.text
    revision_id = refactor_resp.json()["revision_id"]

    history_resp = client.get(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history",
        headers=headers,
    )
    assert history_resp.status_code == 200
    assert history_resp.json()["total_revisions"] >= 1

    diff_resp = client.get(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history/{revision_id}/diff",
        headers=headers,
    )
    assert diff_resp.status_code == 200

    rollback_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/rollback/{revision_id}",
        headers=headers,
    )
    assert rollback_resp.status_code == 200

    _mark_script_completed(script_id, script_content="print('run ok')")
    run_resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/run",
        headers=headers,
    )
    assert run_resp.status_code == 200, run_resp.text
    assert run_resp.json()["success"] is True

    script_runs_resp = client.get(
        f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/runs",
        headers=headers,
    )
    assert script_runs_resp.status_code == 200
    assert len(script_runs_resp.json()) >= 1

    monkeypatch.setattr(
        "app.routers.bulk_jobs.process_bulk_generation_job",
        SimpleNamespace(delay=lambda *a, **k: None),
    )
    bulk_generate = client.post(
        f"/api/v1/projects/{project_id}/scripts/bulk-generate",
        headers=headers,
        json={"llm_provider": "openai", "test_case_ids": [tc_id]},
    )
    assert bulk_generate.status_code == 202, bulk_generate.text
    bulk_job_id = bulk_generate.json()["id"]

    get_bulk_job = client.get(f"/api/v1/projects/{project_id}/scripts/bulk-jobs/{bulk_job_id}", headers=headers)
    assert get_bulk_job.status_code == 200
    assert get_bulk_job.json()["id"] == bulk_job_id

    monkeypatch.setattr("app.routers.execution._enqueue_execution_task", lambda *a, **k: "task-matrix")

    create_execution = client.post(
        "/api/v1/execution/run",
        headers=headers,
        json={"script_id": script_id, "execution_env": {"SUITE": "matrix"}},
    )
    assert create_execution.status_code == 202, create_execution.text
    execution_id = create_execution.json()["id"]

    class _SuccessState:
        state = "SUCCESS"

        result = {
            "duration_seconds": 0.12,
            "stdout": "ok",
            "stderr": "",
            "artifacts": [
                {
                    "id": "a1",
                    "filename": "log.txt",
                    "type": "log",
                    "content_type": "text/plain",
                    "content": "hello",
                    "encoding": "utf-8",
                }
            ],
        }

    monkeypatch.setattr("app.routers.execution.celery_app.AsyncResult", lambda _task_id: _SuccessState())

    execution_status = client.get(f"/api/v1/execution/status/{execution_id}", headers=headers)
    assert execution_status.status_code == 200
    assert execution_status.json()["status"] == "completed"

    report_resp = client.get(f"/api/v1/reports/{execution_id}", headers=headers)
    assert report_resp.status_code == 200

    logs_resp = client.get(f"/api/v1/reports/{execution_id}/logs", headers=headers)
    assert logs_resp.status_code == 200
    assert logs_resp.json()["stdout"] == "ok"

    artifacts_resp = client.get(f"/api/v1/reports/{execution_id}/artifacts", headers=headers)
    assert artifacts_resp.status_code == 200
    assert len(artifacts_resp.json()["artifacts"]) == 1

    download_resp = client.get(f"/api/v1/reports/{execution_id}/download/a1", headers=headers)
    assert download_resp.status_code == 200

    analytics_runs = client.get(f"/api/v1/projects/{project_id}/analytics/runs", headers=headers)
    assert analytics_runs.status_code == 200

    analytics_trends = client.get(f"/api/v1/analytics/trends?project_id={project_id}", headers=headers)
    assert analytics_trends.status_code == 200

    analytics_flakiness = client.get(f"/api/v1/analytics/flakiness?project_id={project_id}&min_runs=1", headers=headers)
    assert analytics_flakiness.status_code == 200

    analytics_coverage = client.get(f"/api/v1/analytics/coverage?project_id={project_id}", headers=headers)
    assert analytics_coverage.status_code == 200

    delete_script = client.delete(f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}", headers=headers)
    assert delete_script.status_code == 204

    missing_script = client.get(f"/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}", headers=headers)
    assert missing_script.status_code == 404
