import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning, module="pkg_resources")
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import re
from sklearn.decomposition import PCA
from scipy.stats import f_oneway, shapiro, kruskal
from scipy.optimize import brentq
from glycowork.motif.graph import subgraph_isomorphism


_network_cache = {}


def find_compositional_pairs_from_network(glycan_sequences, motif_rules, verbose=False, prefix=""):
  """Identify substrate-product pairs using glycowork's biosynthetic network.
  More robust than string matching since it respects biosynthetic relationships.
  Network is cached based on glycan sequences to avoid expensive reconstruction.
  Returns: {'substrates': [indices that decrease], 'products': [indices that increase],
            'unpaired_up': [unpaired increasing], 'unpaired_down': [unpaired decreasing]}"""
  from glycowork.network.biosynthesis import construct_network
  
  # Early return for empty motif_rules to avoid UnboundLocalError
  if not motif_rules:
    return {'substrates': [], 'products': [], 'unpaired_up': [], 'unpaired_down': []}
  
  cache_key = tuple(glycan_sequences)
  if cache_key not in _network_cache:
    try:
      network = construct_network(glycan_sequences)
      _network_cache[cache_key] = network
      if verbose:
        print(f"  {prefix}Constructed and cached network with {len(network.nodes())} nodes, {len(network.edges())} edges")
    except Exception as e:
      if verbose:
        print(f"  {prefix}Warning: construct_network failed ({e}), falling back to string matching")
      _network_cache[cache_key] = None
      return None
  else:
    network = _network_cache[cache_key]
    if network is None:
      return None
    if verbose:
      print(f"  {prefix}Using cached network with {len(network.nodes())} nodes, {len(network.edges())} edges")
  real_nodes = [node for node in network.nodes() if network.nodes[node].get('virtual', 0) == 0]
  substrates, products = [], []
  for motif, direction in motif_rules.items():
    is_loss = direction.lower() in ["down", "downregulate", "decrease"]
    is_gain = direction.lower() in ["up", "upregulate", "increase"]
    for u, v, data in network.edges(data=True):
      edge_label = data.get('diffs', '')
      if motif in edge_label and u in real_nodes and v in real_nodes:
        try:
          u_idx = glycan_sequences.index(u)
          v_idx = glycan_sequences.index(v)
          if is_loss:
            substrates.append(v_idx)
            products.append(u_idx)
          elif is_gain:
            substrates.append(u_idx)
            products.append(v_idx)
          if verbose:
            direction_str = "↓" if is_loss else "↑"
            print(f"  {prefix}network pair: [{u_idx}] {u} ↔ [{v_idx}] {v} (edge: {edge_label}, {motif} {direction_str})")
        except ValueError:
          pass
  paired_set = set(substrates) | set(products)
  unpaired_up, unpaired_down = [], []
  for motif, direction in motif_rules.items():
      is_loss = direction.lower() in ["down", "downregulate", "decrease"]
      is_gain = direction.lower() in ["up", "upregulate", "increase"]
      for idx, seq in enumerate(glycan_sequences):
          if idx not in paired_set and subgraph_isomorphism(seq, motif):
              if is_loss:
                  unpaired_down.append(idx)
              elif is_gain:
                  unpaired_up.append(idx)
  return {'substrates': substrates, 'products': products, 'unpaired_up': unpaired_up, 'unpaired_down': unpaired_down}


def identify_motif_counterpart(glycan_sequence, motif="Neu5Ac"):
    """Remove terminal motif and its linkage to get product.
    Returns the product structure or None if motif not found."""
    if not subgraph_isomorphism(glycan_sequence, motif):
        return None
    patterns = [
        rf'{motif}\([a-z0-9\-]+\)',  # Neu5Ac(a2-3), Neu5Ac(a2-6), etc.
        rf'{motif}'  # Bare motif
    ]
    for pattern in patterns:
        desialylated = re.sub(pattern, '', glycan_sequence)
        desialylated = desialylated.strip()
        if desialylated and desialylated != glycan_sequence:
            return desialylated
    return None


def find_compositional_pairs(glycan_sequences, motif_rules, verbose=False, prefix=""):
    """Identify substrate-product pairs for compositional batch/bio effects.
    Tries network-based approach first (robust), falls back to string matching if needed.
    Returns: {'substrates': [indices], 'products': [indices], 'unpaired_up': [indices], 'unpaired_down': [indices]}"""
    network_result = find_compositional_pairs_from_network(glycan_sequences, motif_rules, verbose=verbose, prefix=prefix)
    if network_result is not None:
      return network_result
    if verbose:
      print(f"  {prefix}Using string-matching fallback")
    substrates, products, unpaired_up, unpaired_down = [], [], [], []
    for motif, direction in motif_rules.items():
        motif_dir = direction.lower()
        is_loss = motif_dir in ["down", "downregulate", "decrease"]
        is_gain = motif_dir in ["up", "upregulate", "increase"]
        for idx, seq in enumerate(glycan_sequences):
            if subgraph_isomorphism(seq, motif):
                if is_loss:
                    product_seq = identify_motif_counterpart(seq, motif)
                    if product_seq:
                        try:
                            product_idx = glycan_sequences.index(product_seq)
                            substrates.append(idx)
                            products.append(product_idx)
                            if verbose:
                                print(f"  {prefix}string pair: [{idx}] {seq} → [{product_idx}] {product_seq}")
                        except ValueError:
                            unpaired_down.append(idx)
                            if verbose:
                                print(f"  {prefix} unpaired (down): [{idx}] {seq} (product not in list)")
                    else:
                        unpaired_down.append(idx)
                elif is_gain:
                    unpaired_up.append(idx)
    return {'substrates': substrates, 'products': products, 'unpaired_up': unpaired_up, 'unpaired_down': unpaired_down}


def parse_simulation_config(config):
    """Parse complete simulation configuration from YAML.
    Handles all config transformations including batch_effect_direction expansion.
    Args:
        config: Raw dict from yaml.safe_load()
    Returns:
        dict: Parsed config ready for simulate() or correction pipeline
    """
    parsed = {}
    # Direct copy simple parameters
    simple_params = [
        'data_source', 'data_file', 'n_glycans', 'n_H', 'n_U',
        'bio_strength', 'k_dir', 'variance_ratio', 'use_real_effect_sizes',
        'differential_mask', 'column_prefix', 'n_batches',
        'kappa_mu', 'var_b', 'winsorize_percentile', 'baseline_method',
        'u_dict', 'random_seeds', 'output_dir', 'verbose', 'save_csv', 'show_pca_plots',
        'missing_fraction', 'mnar_bias'
    ]
    for key in simple_params:
        if key in config:
            parsed[key] = config[key]
    # Parse batch_effect_direction (complex nested structure)
    if 'batch_effect_direction' in config:
        bed_config = config['batch_effect_direction']
        # Get default parameters
        affected_fraction = config.get('affected_fraction', (0.05, 0.30))
        positive_prob = config.get('positive_prob', 0.6)
        overlap_prob = config.get('overlap_prob', 0.5)
        manual_config, auto_params = _parse_batch_effect_direction(
            bed_config, affected_fraction, positive_prob, overlap_prob
        )
        # Store parsed version - pipeline.py will use this
        parsed['batch_effect_direction'] = manual_config
        parsed['affected_fraction'] = auto_params['affected_fraction']
        parsed['positive_prob'] = auto_params['positive_prob']
        parsed['overlap_prob'] = auto_params['overlap_prob']
    else:
        # Use defaults from config or function defaults
        parsed['affected_fraction'] = config.get('affected_fraction', (0.05, 0.30))
        parsed['positive_prob'] = config.get('positive_prob', 0.6)
        parsed['overlap_prob'] = config.get('overlap_prob', 0.5)
    return parsed


def _parse_batch_effect_direction(bed_config, affected_fraction, positive_prob, overlap_prob):
    """Internal helper to parse batch_effect_direction nested structure.
    Expands string keys like "1-50", "3,8,12" to individual indices.
    Returns:
        tuple: (manual_config or None, auto_params dict)
    """
    manual_config = None
    auto_params = {
        'affected_fraction': affected_fraction,
        'positive_prob': positive_prob,
        'overlap_prob': overlap_prob
    }
    if not bed_config or not isinstance(bed_config, dict):
        return manual_config, auto_params
    mode = bed_config.get('mode', 'auto')
    if mode == 'manual':
        raw_manual = bed_config.get('manual', {})
        if raw_manual:
            manual_config = {}
            for batch_id, effects in raw_manual.items():
                batch_id_int = int(batch_id)
                manual_config[batch_id_int] = {}
                for key, direction in effects.items():
                    if isinstance(key, str):
                        if '-' in key and ',' not in key:
                            start, end = map(int, key.split('-'))
                            for idx in range(start, end + 1):
                                manual_config[batch_id_int][idx] = int(direction)
                        elif ',' in key:
                            for idx in map(int, key.split(',')):
                                manual_config[batch_id_int][idx] = int(direction)
                        else:
                            manual_config[batch_id_int][int(key)] = int(direction)
                    else:
                        manual_config[batch_id_int][int(key)] = int(direction)
    # Extract auto parameters if provided
    auto_config = bed_config.get('auto', {})
    if auto_config:
        auto_params['affected_fraction'] = auto_config.get('affected_fraction', affected_fraction)
        auto_params['positive_prob'] = auto_config.get('positive_prob', positive_prob)
        auto_params['overlap_prob'] = auto_config.get('overlap_prob', overlap_prob)
    return manual_config, auto_params


def load_data_from_glycowork(data_file):
    if os.path.exists(data_file):
        return pd.read_csv(data_file)
    # Try loading from glycowork internal datasets
    try:
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=DeprecationWarning, module="pkg_resources")
            import pkg_resources
            glycowork_path = pkg_resources.resource_filename('glycowork', 'glycan_data')
        # Add .csv extension if not present
        dataset_name = data_file if data_file.endswith('.csv') else f"{data_file}.csv"
        full_path = os.path.join(glycowork_path, dataset_name)
        if os.path.exists(full_path):
            return pd.read_csv(full_path)
    except Exception:
        pass
    # If all fails, try as regular path (will raise clear error message)
    return pd.read_csv(data_file)

def clr(x, eps=1e-6):
    """Centered log-ratio transformation for compositional data.
    Parameters:
    -----------
    x : array-like
        Compositional data. Can be 1D (single sample) or 2D (samples x features).
    eps : float
        Small value to replace zeros (default 1e-6).
    Returns:
    --------
    clr_transformed : np.ndarray
        CLR-transformed data with same shape as input.
    """
    x = np.asarray(x, dtype=float)
    # Handle zeros by replacing with small epsilon
    x_safe = np.where(x <= 0, eps, x)
    # Standard CLR: log(x) - geometric_mean(log(x))
    log_x = np.log(x_safe)
    if x.ndim == 1:
        # Single sample: subtract mean across all features
        geom_mean_log = np.mean(log_x)
        return log_x - geom_mean_log
    else:
        # Multiple samples: subtract mean across features for each sample (axis=1)
        geom_mean_log = np.mean(log_x, axis=1, keepdims=True)
        return log_x - geom_mean_log


def invclr(z, to_percent=True, eps=1e-6):
    z = np.asarray(z, dtype=float)
    z = z - np.mean(z)               # Center to ensure proper simplex
    z = z - np.max(z)                # Numerical stability
    x = np.exp(z)
    x = np.maximum(x, eps)           # Prevent zeros
    x = x / np.sum(x)                # Normalize to 1
    if to_percent:
        x *= 100
    return x


# Plot PCA for clean and simulated data
def plot_pca(data, #DataFrame (features x samples)
             bio_groups=None, # dict or None, e.g. {'healthy': ['healthy_1', 'healthy_2'], 'unhealthy': ['unhealthy_1']}
             batch_groups=None,
             title="PCA",
             save_path=None):
    pca = PCA(n_components=2)
    pca_result = pca.fit_transform(data.T)
    sample_names = data.columns.tolist()

    # Helper function to get bio/batch labels for annotation
    def get_bio_label(sample_name):
        if bio_groups:
            for i, (group_name, cols) in enumerate(bio_groups.items()):  # 0-based
                if sample_name in cols:
                    return f"Bio-{i}"
        return ""

    def get_batch_label(sample_name):
        if batch_groups:
            for batch_id, cols in batch_groups.items():
                if sample_name in cols:
                    return f"BE-{batch_id}"
        return ""

    # Setup subplots
    n_plots = sum([bio_groups is not None, batch_groups is not None])
    if n_plots == 0:
        return
    fig, axes = plt.subplots(1, n_plots, figsize=(6*n_plots, 5))
    axes = [axes] if n_plots == 1 else axes
    plot_idx = 0
    # Plot biological groups (with batch annotations)
    if bio_groups is not None:
        bio_colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
        for i, (group_name, cols) in enumerate(bio_groups.items()):
            indices = [sample_names.index(c) for c in cols if c in sample_names]
            axes[plot_idx].scatter(pca_result[indices, 0], pca_result[indices, 1],
                                  c=bio_colors[i % len(bio_colors)], label=group_name, alpha=0.7, s=50)
            # Add batch annotations on bio-colored plot
            for idx in indices:
                batch_label = get_batch_label(sample_names[idx])
                if batch_label:
                    axes[plot_idx].annotate(batch_label, (pca_result[idx, 0], pca_result[idx, 1]),
                                          xytext=(2, 2), textcoords='offset points', fontsize=8, alpha=0.7)
        axes[plot_idx].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})')
        axes[plot_idx].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%})')
        axes[plot_idx].set_title(f'{title}\n(colored by bio-groups)')
        axes[plot_idx].legend()
        axes[plot_idx].grid(alpha=0.3)
        plot_idx += 1
    # Plot batch groups (with bio annotations)
    if batch_groups is not None:
        batch_colors = ['#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#FF6B35']
        for i, (batch_id, cols) in enumerate(sorted(batch_groups.items())):
            indices = [sample_names.index(c) for c in cols if c in sample_names]
            axes[plot_idx].scatter(pca_result[indices, 0], pca_result[indices, 1],
                                  c=batch_colors[i % len(batch_colors)], label=f'Batch {batch_id}', alpha=0.7, s=50)
            # Add bio annotations on batch-colored plot
            for idx in indices:
                bio_label = get_bio_label(sample_names[idx])
                if bio_label:
                    axes[plot_idx].annotate(bio_label, (pca_result[idx, 0], pca_result[idx, 1]),
                                          xytext=(2, 2), textcoords='offset points', fontsize=8, alpha=0.7)
        axes[plot_idx].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})')
        axes[plot_idx].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%})')
        axes[plot_idx].set_title(f'{title}\n(colored by batches)')
        axes[plot_idx].legend()
        axes[plot_idx].grid(alpha=0.3)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()


def _compute_pca_and_stats(data):
    """Compute PCA and return PC, variance explained, and normality test result."""
    X = np.asarray(data).T
    pca = PCA(n_components=min(5, X.shape[0]-1))
    pc = pca.fit_transform(X)
    var_explained = pca.explained_variance_ratio_[:2].sum()
    total_samples = len(pc[:, 0])
    # Normality test (only for n >= 30)
    norm_p = shapiro(pc[:, 0])[1] if total_samples >= 30 else 0.0
    return pc, var_explained, total_samples, norm_p, X


def _evaluate_bio_effect_details(pc, bio_labels, test_used, ss_total, total_samples, verbose=False):
    """Calculate bio effect with centroid_distance and strength assessment."""
    bio_cat = pd.Categorical(bio_labels)
    pc1_by_bio = [pc[bio_cat==g, 0] for g in bio_cat.categories]
    # Statistical test
    if test_used == "Kruskal-Wallis":
        f_bio, p_bio = kruskal(*pc1_by_bio)
    else:
        f_bio, p_bio = f_oneway(*pc1_by_bio)
    # Effect size (eta²)
    if test_used == "ANOVA":
        ss_bio_between = sum([len(group) * (np.mean(group) - np.mean(pc[:, 0]))**2
                             for group in pc1_by_bio])
        bio_eta = ss_bio_between / ss_total if ss_total > 0 else 0
    else:
        bio_eta = (f_bio - len(bio_cat.categories) + 1) / (total_samples - len(bio_cat.categories) + 1)
        bio_eta = max(0, min(1, bio_eta))
    # Centroid distance
    centroids = [pc[bio_cat==b, :2].mean(axis=0) for b in bio_cat.categories]
    centroid_dist = np.linalg.norm(centroids[0] - centroids[1]) if len(centroids) == 2 else 0
    # Strength assessment
    if p_bio >= 0.05:
        strength = "ABSENT"
        strength_desc = f"No significant signal (p={p_bio:.3e} >= 0.05)"
    elif bio_eta < 0.06:
        strength = "WEAK"
        strength_desc = f"Small effect (eta²={bio_eta:.1%} < 6%)"
    elif bio_eta < 0.14:
        strength = "MODERATE"
        strength_desc = f"Medium effect (6% =< eta²={bio_eta:.1%} < 14%)"
    else:
        strength = "STRONG"
        strength_desc = f"Large effect (eta²={bio_eta:.1%} >= 14%)"
    if verbose:
        print(f"Biological effect on PC1: F={f_bio:.2f}, p={p_bio:.3e}")
        print(f"Biological effect size (eta²): {bio_eta:.1%}")
        print(f"Centroid distance (PC1-2): {centroid_dist:.2f}")
        print(f"Signal strength: {strength} - {strength_desc}")
    return {
        'f_statistic': float(f_bio),
        'p_value': float(p_bio),
        'effect_size_eta2': float(bio_eta),
        'centroid_distance': float(centroid_dist),
        'strength': strength,
        'strength_description': strength_desc
    }


def pvca_variance_decomposition(data, batch_labels, bio_labels, n_components=10):
  X = np.asarray(data).T
  pca = PCA(n_components=min(n_components, X.shape[0]-1, X.shape[1]))
  pc_scores = pca.fit_transform(X)
  variance_explained = pca.explained_variance_ratio_
  batch_variance = 0
  bio_variance = 0
  residual_variance = 0
  for i in range(pc_scores.shape[1]):
    pc = pc_scores[:, i]
    weight = variance_explained[i]
    ss_total = np.sum((pc - np.mean(pc))**2)
    if ss_total < 1e-10:
      continue
    batch_means = np.array([np.mean(pc[batch_labels == b]) for b in np.unique(batch_labels)])
    batch_counts = np.array([np.sum(batch_labels == b) for b in np.unique(batch_labels)])
    ss_batch = np.sum(batch_counts * (batch_means - np.mean(pc))**2)
    bio_means = np.array([np.mean(pc[bio_labels == b]) for b in np.unique(bio_labels)])
    bio_counts = np.array([np.sum(bio_labels == b) for b in np.unique(bio_labels)])
    ss_bio = np.sum(bio_counts * (bio_means - np.mean(pc))**2)
    ss_residual = max(0, ss_total - ss_batch - ss_bio)
    batch_variance += (ss_batch / ss_total) * weight
    bio_variance += (ss_bio / ss_total) * weight
    residual_variance += (ss_residual / ss_total) * weight
  total = batch_variance + bio_variance + residual_variance
  if total < 1e-10:
    return {'batch_variance_pct': 0.0, 'bio_variance_pct': 0.0, 'residual_variance_pct': 0.0}
  return {
    'batch_variance_pct': (batch_variance / total) * 100,
    'bio_variance_pct': (bio_variance / total) * 100,
    'residual_variance_pct': (residual_variance / total) * 100
  }


def check_batch_effect(data, batch_labels, bio_groups=None, verbose=True):
  pc, var_explained, total_samples, norm_p, X = _compute_pca_and_stats(data)
  # Handle both bio_groups (dict) and bio_labels (array) inputs
  if bio_groups is not None:
    if isinstance(bio_groups, dict):
      # Convert bio_groups dict to bio_labels array
      bio_labels = np.zeros(len(data.columns), dtype=int)
      for group_id, (group_name, cols) in enumerate(bio_groups.items()):
        for col in cols:
          if col in data.columns:
            col_idx = data.columns.get_loc(col)
            bio_labels[col_idx] = group_id
      bio_groups_dict = bio_groups
    else:
      # Already bio_labels array, keep it
      bio_labels = bio_groups
      bio_groups_dict = None
  else:
    bio_labels = None
    bio_groups_dict = None
  # PVCA as primary metric
  if bio_labels is not None:
    pvca_results = pvca_variance_decomposition(data, batch_labels, bio_labels, n_components=10)
    batch_var_pct = pvca_results['batch_variance_pct']
    bio_var_pct = pvca_results['bio_variance_pct']
    residual_var_pct = pvca_results['residual_variance_pct']
    if verbose:
      print(f"PC1-10 explain {var_explained:.1%} variance")
      print(f"\nPVCA Variance Decomposition (across {min(10, X.shape[1])} PCs):")
      print(f"  Batch:     {batch_var_pct:.1f}%")
      print(f"  Biological: {bio_var_pct:.1f}%")
      print(f"  Residual:   {residual_var_pct:.1f}%")
    # Severity classification based on PVCA
    if batch_var_pct < 5:
      severity = "NONE"
      severity_description = f"Negligible batch effect (batch explains {batch_var_pct:.1f}% of variance)"
    elif batch_var_pct < bio_var_pct:
      if batch_var_pct < 10:
        severity = "GOOD"
        severity_description = f"Biological signal dominates (bio {bio_var_pct:.1f}% vs batch {batch_var_pct:.1f}%)"
      else:
        severity = "MILD"
        severity_description = f"Minor batch effect present but biology dominates (bio {bio_var_pct:.1f}% vs batch {batch_var_pct:.1f}%)"
    else:
      if batch_var_pct > 30:
        severity = "CRITICAL"
        severity_description = f"Severe batch effect overwhelms signal (batch {batch_var_pct:.1f}% vs bio {bio_var_pct:.1f}%)"
      elif batch_var_pct > 20:
        severity = "MODERATE"
        severity_description = f"Substantial batch effect (batch {batch_var_pct:.1f}% vs bio {bio_var_pct:.1f}%)"
      else:
        severity = "WARNING"
        severity_description = f"Batch effect exceeds biological signal (batch {batch_var_pct:.1f}% vs bio {bio_var_pct:.1f}%)"
    if verbose:
      print(f"\nOverall Quality: {severity} - {severity_description}")
  # PC1 analysis as secondary/confirmatory metric
  batch_cat = pd.Categorical(batch_labels)
  pc1_by_batch = [pc[batch_cat==b, 0] for b in batch_cat.categories]
  if total_samples < 30 or norm_p < 0.05:
    f_stat, p_val = kruskal(*pc1_by_batch)
    test_used = "Kruskal-Wallis"
  else:
    f_stat, p_val = f_oneway(*pc1_by_batch)
    test_used = "ANOVA"
  ss_total = np.var(pc[:, 0]) * (len(pc[:, 0]) - 1)
  if test_used == "ANOVA":
    ss_between = sum([len(group) * (np.mean(group) - np.mean(pc[:, 0]))**2 for group in pc1_by_batch])
    batch_eta = ss_between / ss_total if ss_total > 0 else 0
  else:
    batch_eta = (f_stat - len(batch_cat.categories) + 1) / (total_samples - len(batch_cat.categories) + 1)
    batch_eta = max(0, min(1, batch_eta))
  if verbose:
    print(f"\nPC1 Analysis (confirmatory):")
    print(f"  Batch effect on PC1: F={f_stat:.2f}, p={p_val:.3e} ({test_used})")
    print(f"  Batch effect size (η²): {batch_eta:.1%}")
  results = {
    'pca_variance_explained': float(var_explained),
    'batch_effect': {
      'f_statistic': float(f_stat),
      'p_value': float(p_val),
      'test_used': test_used,
      'effect_size_eta2': float(batch_eta)
    }
  }
  if bio_labels is not None:
    bio_effect = _evaluate_bio_effect_details(pc, bio_labels, test_used, ss_total, total_samples, verbose)
    results['bio_effect'] = bio_effect
    results['pvca'] = pvca_results
    results['overall_quality'] = {
      'severity': severity,
      'severity_description': severity_description,
      'decision_basis': 'PVCA variance decomposition'
    }
    batch_dummies = pd.get_dummies(batch_labels).values
    var_batch = np.array([np.corrcoef(X[:, i], batch_dummies.T)[0, 1:].max()**2 for i in range(X.shape[1])])
    median_var_batch = float(np.median(var_batch))
    results['overall_quality']['median_variance_explained_by_batch'] = median_var_batch
    if verbose:
      print(f"  Median variance explained by batch across features: {median_var_batch:.1%}")
    return results, pc, var_batch
  else:
    batch_dummies = pd.get_dummies(batch_labels).values
    var_batch = np.array([np.corrcoef(X[:, i], batch_dummies.T)[0, 1:].max()**2 for i in range(X.shape[1])])
    median_var_batch = float(np.median(var_batch))
    results['median_variance_explained_by_batch'] = median_var_batch
    if verbose:
      print(f"Median variance explained by batch across features: {median_var_batch:.1%}")
    return results, pc, var_batch


def check_bio_effect(data_clr, bio_labels, stage_name="", verbose=True):
    pc, var_explained, total_samples, norm_p, _ = _compute_pca_and_stats(data_clr)
    # Choose test
    if total_samples < 30 or norm_p < 0.05:
        test_used = "Kruskal-Wallis"
    else:
        test_used = "ANOVA"
    ss_total = np.var(pc[:, 0]) * (len(pc[:, 0]) - 1)
    # Verbose header
    if verbose and stage_name:
        print(f"\n[{stage_name.upper()}]")
    if verbose:
        print(f"PC1-2 explain {var_explained:.1%} variance")
    # Evaluate bio effect with full details
    bio_effect = _evaluate_bio_effect_details(pc, bio_labels, test_used, ss_total, total_samples, verbose)
    return {
        'pca_variance_explained': float(var_explained),
        'bio_effect': bio_effect
    }, pc


def apply_mnar_missingness(Y_compositional, missing_fraction=0.0, mnar_bias=1.0, seed=42, verbose=True):
    """Apply missing-not-at-random (MNAR) pattern to compositional data.
    Low-intensity glycans have higher probability of being missing.
    Parameters:
    -----------
    Y_compositional : np.ndarray or pd.DataFrame
        Compositional data (samples x glycans), values in percentage or proportions
    missing_fraction : float
        Target fraction of missing values (0.0 to 1.0)
    mnar_bias : float
        Intensity bias parameter. Higher values = stronger bias toward low intensity.
        Typical range: 0.5 (weak) to 5.0 (very strong). Default 1.0.
    seed : int
        Random seed for reproducibility
    verbose : bool
        Print diagnostics
    Returns:
    --------
    Y_missing : pd.DataFrame or np.ndarray
        Data with NaN for missing values
    Y_missing_clr : pd.DataFrame or np.ndarray
        CLR-transformed data (imputed before CLR)
    missing_mask : np.ndarray
        Boolean mask (True = missing)
    diagnostics : dict
        Missingness statistics
    """
    if missing_fraction <= 0:
        if verbose:
            print("Missingness disabled (missing_fraction=0)")
        Y_clr = clr(Y_compositional.values.T if isinstance(Y_compositional, pd.DataFrame) else Y_compositional.T).T
        if isinstance(Y_compositional, pd.DataFrame):
            Y_clr = pd.DataFrame(Y_clr, index=Y_compositional.index, columns=Y_compositional.columns)
        return Y_compositional, Y_clr, np.zeros(Y_compositional.shape, dtype=bool), {}
    rng = np.random.default_rng(seed)
    is_df = isinstance(Y_compositional, pd.DataFrame)
    Y = Y_compositional.values if is_df else Y_compositional
    n_samples, n_glycans = Y.shape
    missing_mask = np.zeros_like(Y, dtype=bool)
    # MNAR missingness via logistic in log-abundance space.
    # For each sample i, the per-glycan missing probability is:
    #   p(missing | x_ij) = 1 / (1 + exp(a_i + b * log(x_ij)))
    # where b = mnar_bias controls the steepness of the intensity-detection
    # relationship, and a_i is a per-sample intercept solved numerically so
    # that mean_j(p_ij) = missing_fraction exactly.
    for i in range(n_samples):
        log_x = np.log(np.maximum(Y[i, :], 1e-10))
        # Find a_i such that mean(1 / (1 + exp(a + b*log_x))) = missing_fraction.
        def mean_missing(a):
            return np.mean(1.0 / (1.0 + np.exp(a + mnar_bias * log_x))) - missing_fraction
        # Bracket: large negative a → all missing (mean≈1), large positive → none missing (mean≈0)
        try:
            a_i = brentq(mean_missing, -50, 50, xtol = 1e-6)
        except ValueError:
            # Fallback if target is outside achievable range for this sample
            a_i = 0.0
        prob_missing = 1.0 / (1.0 + np.exp(a_i + mnar_bias * log_x))
        missing_mask[i, :] = rng.random(n_glycans) < prob_missing
    # Apply missingness
    Y_missing = Y.copy().astype(float)
    Y_missing[missing_mask] = np.nan
    # Compute CLR with imputation
    Y_for_clr = Y.copy()
    Y_for_clr[missing_mask] = 1e-6
    Y_missing_clr = clr(Y_for_clr.T).T
    # Diagnostics
    intensity_bins = [0, 0.01, 0.1, 1.0, np.inf]
    bin_labels = ['<0.01%', '0.01-0.1%', '0.1-1%', '>1%']
    missing_by_intensity = {}
    for b_idx in range(len(intensity_bins)-1):
        mask = (Y >= intensity_bins[b_idx]) & (Y < intensity_bins[b_idx+1])
        if np.sum(mask) > 0:
            missing_rate = np.sum(missing_mask & mask) / np.sum(mask)
            missing_by_intensity[bin_labels[b_idx]] = float(missing_rate)
    per_sample_missing = np.sum(missing_mask, axis=1)
    diagnostics = {
        'total_missing': int(np.sum(missing_mask)),
        'missing_fraction_actual': float(np.sum(missing_mask) / Y.size),
        'missing_fraction_target': float(missing_fraction),
        'per_sample_missing': per_sample_missing.tolist(),
        'missing_rate_by_intensity': missing_by_intensity,
        'mnar_bias': float(mnar_bias)
    }
    if verbose:
        print(f"\n{'='*60}")
        print(f"MNAR MISSINGNESS APPLIED")
        print(f"{'='*60}")
        print(f"Target fraction: {missing_fraction:.1%}")
        print(f"Actual fraction: {diagnostics['missing_fraction_actual']:.1%}")
        print(f"Total missing: {diagnostics['total_missing']}/{Y.size}")
        print(f"MNAR bias: {mnar_bias}")
        print(f"\nMissing rate by intensity:")
        for bin_label, rate in missing_by_intensity.items():
            print(f"  {bin_label:>12}: {rate:.1%}")
        print(f"{'='*60}\n")
    if is_df:
        Y_missing = pd.DataFrame(Y_missing, index=Y_compositional.index, columns=Y_compositional.columns)
        Y_missing_clr = pd.DataFrame(Y_missing_clr, index=Y_compositional.index, columns=Y_compositional.columns)
    return Y_missing, Y_missing_clr, missing_mask, diagnostics
