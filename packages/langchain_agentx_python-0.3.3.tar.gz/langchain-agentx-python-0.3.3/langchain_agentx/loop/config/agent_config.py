"""agent_config.py — Agent config 构建助手

职责：
    构建 `agent.invoke/ainvoke/astream*` 所需的 config 字典。
    只负责 LangGraph 配置参数（如 recursion_limit）。

Note:
    - run_id 由 HookGraphWiring/TraceLifecycleCollector 注入，不需要手动配置
    - session_id 在 create_loop_agent 时配置，不在此处
"""

from __future__ import annotations

from typing import Any


def merge_run_config(
    graph: Any,
    caller: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """合并 graph 绑定的 recursion_limit 与调用方 config。

    与 ``create_loop_agent(max_steps=...)`` 经 ``compute_recursion_limit`` 写入 graph 的上限对齐；
    ``caller`` 中的同名字段可覆盖。
    """
    bound_raw = getattr(graph, "config", None)
    bound: dict[str, Any] = bound_raw if isinstance(bound_raw, dict) else {}
    limit = bound.get("recursion_limit", 9_999)
    merged = build_agent_config(recursion_limit=limit)
    if caller:
        merged.update(caller)
    return merged


def build_agent_config(
    *,
    recursion_limit: int = 9_999,
    **kwargs: Any,
) -> dict[str, Any]:
    """构建 Agent 运行配置（LangGraph 配置参数）。

    Args:
        recursion_limit: 运行递归上限（默认 9999）。
        **kwargs: 其他 LangGraph config 参数（如 metadata, configurable 等）。

    Returns:
        可直接传给 `agent.invoke(..., config=...)` 的配置字典。

    Example:
        >>> # 使用默认配置
        >>> config = build_agent_config()
        >>> result = agent.invoke({"messages": [...]}, config=config)

        >>> # 自定义 recursion_limit
        >>> config = build_agent_config(recursion_limit=5000)
        >>> result = agent.invoke({"messages": [...]}, config=config)

        >>> # 添加其他 LangGraph 配置
        >>> config = build_agent_config(
        ...     recursion_limit=5000,
        ...     metadata={"user_id": "123"},
        ... )
        >>> result = agent.invoke({"messages": [...]}, config=config)

    Note:
        - run_id 由 HookGraphWiring/TraceLifecycleCollector 在每次调用时自动注入
        - session_id 已在 create_loop_agent 时配置
        - 如果不需要自定义配置，可以直接调用 agent.invoke() 不传 config
    """
    config: dict[str, Any] = {
        "recursion_limit": recursion_limit,
    }

    # 合并其他参数
    if kwargs:
        config.update(kwargs)

    return config


__all__ = ["build_agent_config", "merge_run_config"]



