"""
Loop model 调用重试器。

职责：
- 以 OOP 方式编排重试循环与等待策略
- 产出对用户可见的重试事件（scheduled/heartbeat）
- 复用默认异常分类（retry_on）
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Awaitable, Callable, Generic, Literal, Protocol, TypeVar

from .retry_events import ModelRetryEvent
from .retry_policy import RetryDelayPolicy, RetryHeartbeatPolicy

T = TypeVar("T")
RetryScope = Literal["foreground", "background"]


@dataclass(slots=True)
class RetryContext:
    scope: RetryScope = "foreground"


def default_retry_on(exc: Exception) -> bool:
    """判断异常是否应该重试。排除用户取消；覆盖常见限流/连接/服务端错误。"""
    if isinstance(exc, (KeyboardInterrupt, SystemExit)):
        return False
    try:
        if isinstance(exc, asyncio.CancelledError):
            return False
    except Exception:
        return False

    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    if isinstance(status, int) and status in (429, 500, 502, 503, 504, 529):
        return True

    try:
        from openai import APIConnectionError, InternalServerError, RateLimitError

        if isinstance(exc, (RateLimitError, APIConnectionError, InternalServerError)):
            return True
    except ImportError:
        pass

    try:
        import httpx

        if isinstance(exc, (httpx.ConnectError, httpx.TimeoutException, httpx.RemoteProtocolError)):
            return True
    except ImportError:
        pass

    return False


def _extract_status_code(exc: Exception) -> int | None:
    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    return status if isinstance(status, int) else None


class AuthRecoveryHandler(Protocol):
    def recover(self, exc: Exception) -> bool: ...

    async def arecover(self, exc: Exception) -> bool: ...


@dataclass(slots=True)
class RetryClassifier:
    retry_on: Callable[[Exception], bool]
    allow_background_529_retry: bool = False
    has_auth_recovery_handler: bool = False

    def should_retry(self, exc: Exception, ctx: RetryContext) -> bool:
        status = _extract_status_code(exc)
        if status == 529 and ctx.scope == "background" and not self.allow_background_529_retry:
            return False
        if status in (401, 403):
            return self.has_auth_recovery_handler
        if status in (408, 409):
            return True
        return self.retry_on(exc)

    def should_attempt_auth_recovery(self, exc: Exception) -> bool:
        return _extract_status_code(exc) in (401, 403)


@dataclass(slots=True)
class ModelRetryConfig:
    max_retries: int = 10
    initial_delay: float = 2.0
    backoff_factor: float = 2.0
    max_delay: float = 60.0
    jitter: bool = True
    heartbeat_threshold_seconds: float = 30.0
    heartbeat_interval_seconds: float = 30.0
    retry_on: Callable[[Exception], bool] = default_retry_on
    allow_background_529_retry: bool = False
    auth_recovery_handler: AuthRecoveryHandler | None = None
    # Fallback 机制：连续 N 次 429/529 后触发 fallback
    max_consecutive_rate_limit: int = 3
    fallback_model: Any | None = None


@dataclass(slots=True)
class RetryExecutionResult(Generic[T]):
    value: T
    events: list[ModelRetryEvent]


@dataclass(slots=True)
class ModelCallRetrier:
    config: ModelRetryConfig

    def invoke(
        self,
        fn: Callable[[], T],
        *,
        context: RetryContext | None = None,
    ) -> RetryExecutionResult[T]:
        events: list[ModelRetryEvent] = []
        delay_policy = self._delay_policy()
        hb_policy = self._heartbeat_policy()
        classifier = self._classifier()
        ctx = context or RetryContext()
        attempt = 0
        auth_recovery_attempted = False
        while True:
            try:
                return RetryExecutionResult(value=fn(), events=events)
            except Exception as exc:
                if (not auth_recovery_attempted) and self._recover_auth_sync(exc, classifier):
                    auth_recovery_attempted = True
                    continue
                if attempt >= self.config.max_retries or not classifier.should_retry(exc, ctx):
                    raise
                self._sleep_before_next(
                    attempt=attempt,
                    exc=exc,
                    events=events,
                    delay_policy=delay_policy,
                    heartbeat_policy=hb_policy,
                )
                auth_recovery_attempted = False
                attempt += 1

    async def ainvoke(
        self,
        fn: Callable[[], Awaitable[T]],
        *,
        context: RetryContext | None = None,
    ) -> RetryExecutionResult[T]:
        events: list[ModelRetryEvent] = []
        delay_policy = self._delay_policy()
        hb_policy = self._heartbeat_policy()
        classifier = self._classifier()
        ctx = context or RetryContext()
        attempt = 0
        auth_recovery_attempted = False
        while True:
            try:
                return RetryExecutionResult(value=await fn(), events=events)
            except Exception as exc:
                if (not auth_recovery_attempted) and await self._recover_auth_async(exc, classifier):
                    auth_recovery_attempted = True
                    continue
                if attempt >= self.config.max_retries or not classifier.should_retry(exc, ctx):
                    raise
                await self._asleep_before_next(
                    attempt=attempt,
                    exc=exc,
                    events=events,
                    delay_policy=delay_policy,
                    heartbeat_policy=hb_policy,
                )
                auth_recovery_attempted = False
                attempt += 1

    def _sleep_before_next(
        self,
        *,
        attempt: int,
        exc: Exception,
        events: list[ModelRetryEvent],
        delay_policy: RetryDelayPolicy,
        heartbeat_policy: RetryHeartbeatPolicy,
    ) -> None:
        import time

        delay = delay_policy.compute_delay_seconds(attempt=attempt, exc=exc)
        self._record_wait_events(
            events=events,
            attempt=attempt,
            exc=exc,
            delay_seconds=delay,
            heartbeat_policy=heartbeat_policy,
        )
        time.sleep(delay)

    async def _asleep_before_next(
        self,
        *,
        attempt: int,
        exc: Exception,
        events: list[ModelRetryEvent],
        delay_policy: RetryDelayPolicy,
        heartbeat_policy: RetryHeartbeatPolicy,
    ) -> None:
        delay = delay_policy.compute_delay_seconds(attempt=attempt, exc=exc)
        self._record_wait_events(
            events=events,
            attempt=attempt,
            exc=exc,
            delay_seconds=delay,
            heartbeat_policy=heartbeat_policy,
        )
        await asyncio.sleep(delay)

    def _record_wait_events(
        self,
        *,
        events: list[ModelRetryEvent],
        attempt: int,
        exc: Exception,
        delay_seconds: float,
        heartbeat_policy: RetryHeartbeatPolicy,
    ) -> None:
        total_ms = max(0, int(delay_seconds * 1000))
        attempt_no = attempt + 1
        events.append(
            ModelRetryEvent(
                event_type="scheduled",
                retry_in_ms=total_ms,
                attempt=attempt_no,
                max_retries=self.config.max_retries,
                error_type=type(exc).__name__,
                error_message=str(exc),
            )
        )
        if not heartbeat_policy.should_emit_heartbeat(delay_seconds):
            return

        interval_ms = max(1000, int(heartbeat_policy.interval_seconds * 1000))
        remaining = total_ms - interval_ms
        while remaining > 0:
            events.append(
                ModelRetryEvent(
                    event_type="heartbeat",
                    retry_in_ms=remaining,
                    attempt=attempt_no,
                    max_retries=self.config.max_retries,
                    error_type=type(exc).__name__,
                    error_message=str(exc),
                )
            )
            remaining -= interval_ms

    def _delay_policy(self) -> RetryDelayPolicy:
        return RetryDelayPolicy(
            initial_delay=self.config.initial_delay,
            backoff_factor=self.config.backoff_factor,
            max_delay=self.config.max_delay,
            jitter=self.config.jitter,
        )

    def _heartbeat_policy(self) -> RetryHeartbeatPolicy:
        return RetryHeartbeatPolicy(
            threshold_seconds=self.config.heartbeat_threshold_seconds,
            interval_seconds=self.config.heartbeat_interval_seconds,
        )

    def _classifier(self) -> RetryClassifier:
        return RetryClassifier(
            retry_on=self.config.retry_on,
            allow_background_529_retry=self.config.allow_background_529_retry,
            has_auth_recovery_handler=self.config.auth_recovery_handler is not None,
        )

    def _recover_auth_sync(self, exc: Exception, classifier: RetryClassifier) -> bool:
        handler = self.config.auth_recovery_handler
        if handler is None or not classifier.should_attempt_auth_recovery(exc):
            return False
        try:
            return bool(handler.recover(exc))
        except Exception:
            return False

    async def _recover_auth_async(self, exc: Exception, classifier: RetryClassifier) -> bool:
        handler = self.config.auth_recovery_handler
        if handler is None or not classifier.should_attempt_auth_recovery(exc):
            return False
        try:
            return bool(await handler.arecover(exc))
        except Exception:
            return False


__all__ = [
    "ModelRetryConfig",
    "ModelCallRetrier",
    "RetryContext",
    "RetryClassifier",
    "AuthRecoveryHandler",
    "RetryExecutionResult",
    "default_retry_on",
]
