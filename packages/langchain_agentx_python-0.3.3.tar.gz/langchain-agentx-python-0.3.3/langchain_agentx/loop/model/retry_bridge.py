"""
模型重试事件处理。

职责：
- 将 retrier 产出的事件记录到日志
- 不再写入 messages state，避免污染 LLM 上下文
- 事件通过 trace/observability 通道对外暴露（由外部系统订阅）

重要变更：
  旧版本将重试事件转为 SystemMessage 写入 state，导致：
  - LLM 上下文被大量重试提示污染
  - _strip_system_messages_from_state 需要额外处理这些消息

  新版本仅记录日志和返回事件数据，由外部系统（如 trace 包）决定如何展示。
"""

from __future__ import annotations

import logging
from typing import Iterable

from .retry_events import ModelRetryEvent

logger = logging.getLogger(__name__)


def _format_retry_event_message(event: ModelRetryEvent) -> str:
    """格式化重试事件为可读字符串。"""
    seconds = max(0, int(round(event.retry_in_ms / 1000)))
    if event.event_type == "heartbeat":
        prefix = "Retry still pending"
    else:
        prefix = "Retry scheduled"
    return (
        f"[{prefix}] in {seconds}s "
        f"(attempt {event.attempt}/{event.max_retries}) "
        f"{event.error_type}: {event.error_message}"
    )


def emit_retry_events(events: Iterable[ModelRetryEvent]) -> None:
    """
    发出重试事件（记录日志 + 返回原始事件数据）。

    不再返回 Command，避免重试事件写入 messages state。
    外部系统可通过 observability/trace 通道订阅这些事件。

    Args:
        events: 重试事件列表
    """
    for event in events:
        msg = _format_retry_event_message(event)
        logger.info("[ModelRetry] %s", msg)


__all__ = ["emit_retry_events", "_format_retry_event_message"]
