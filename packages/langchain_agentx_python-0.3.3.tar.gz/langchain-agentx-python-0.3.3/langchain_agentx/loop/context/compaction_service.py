"""
主循环 **上下文治理** 对 Graph 的 **门面服务**（唯一推荐接入点）。

与 Claude Code 对齐：
- 内部编排 CC 五段（`ContextPipeline` + `stages/*`），与 `query.ts` 中 `messagesForQuery` 顺序一致；
- `factory` 中 `prune_and_compress` 节点应调用 `default_loop_context_compaction().run(...)`，而非散落模块函数。

设计要点：
- `LoopContextCompaction` 构造注入 `ContextPipeline`，便于单测替换阶段序列；
- `default_loop_context_compaction()` 返回进程内单例，避免每轮重复装配。

注意：
- 不修改 `should_end` / `finish_reason` 等 exit 字段；只产出 `messages` 增量补丁。
- `arun` 方法为 async 版本，支持进度回调（供 /compact 命令使用）。
"""

from __future__ import annotations

from typing import Any, Dict, Mapping

from .pipeline import ContextPipeline
from .settings import CompactionSettings
from .types import CompactProgressCallback, ContextCompactionContext


class LoopContextCompaction:
    """对 LangGraph state 执行 CC 五段上下文流水线。"""

    def __init__(self, pipeline: ContextPipeline) -> None:
        self._pipeline = pipeline

    @classmethod
    def with_default_pipeline(
        cls,
        *,
        settings: CompactionSettings | None = None,
    ) -> LoopContextCompaction:
        """使用 CC 默认五段顺序装配管道。"""
        return cls(ContextPipeline.with_default_stages(settings=settings))

    def run(self, state: Mapping[str, Any], model: Any | None = None) -> Dict[str, Any]:
        """返回 `Command(update=...)` 可用的补丁（常见为 ``{}`` 或 ``{"messages": ...}``）。"""
        ctx = ContextCompactionContext.from_state(state, model)
        return self._pipeline.run(state, ctx)

    async def arun(
        self,
        state: Mapping[str, Any],
        model: Any | None = None,
        progress_callback: CompactProgressCallback = None,
    ) -> Dict[str, Any]:
        """Async 版本（供 /compact 命令使用），支持进度回调。

        参数：
            state: LangGraph state
            model: 可选的 LLM model（供 autocompact 使用）
            progress_callback: 进度回调函数，接收 CompactProgress 对象

        返回:
            与 run() 相同的补丁格式
        """
        ctx = ContextCompactionContext.from_state(state, model)
        ctx.progress_callback = progress_callback
        return await self._pipeline.arun(state, ctx)


_default_loop_context_compaction: LoopContextCompaction | None = None


def default_loop_context_compaction() -> LoopContextCompaction:
    """进程内单例门面（`factory` 节点调用）。"""
    global _default_loop_context_compaction
    if _default_loop_context_compaction is None:
        _default_loop_context_compaction = LoopContextCompaction.with_default_pipeline()
    return _default_loop_context_compaction


__all__ = [
    "LoopContextCompaction",
    "default_loop_context_compaction",
]
