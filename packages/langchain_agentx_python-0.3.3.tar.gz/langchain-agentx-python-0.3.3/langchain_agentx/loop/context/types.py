"""
上下文压缩流水线的共享类型（ContextCompactionContext、StageResult 等）。

与 Claude Code 对齐：
- `ContextCompactionContext` 承载 `query.ts` 中传入 `deps.microcompact` / `deps.autocompact` 的
  同类信息（model、snip 释放 token 累计、query_source 递归防护等），随阶段演进补齐。

设计要点：
- 使用 dataclass，避免裸 dict 魔法键；
- 不依赖 LangGraph；不修改 should_end / finish_reason。

注意：
- `TokenWarningState` 供 `blocking_guard` 与 `compaction_pipeline_meta` 观测对齐 CC token 告警语义。
- `CompactProgress` 用于 /compact 进度条回调，CLI 通过 progress_callback 接收进度更新。
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

TokenWarningLevel = Literal["ok", "warn", "block_compact_llm", "block_main_model"]


@dataclass
class CompactionConfig:
    """各阶段阈值与开关占位；后续与环境变量 / feature flag 对齐 CC。"""

    # 预留：如 AUTOCOMPACT_BUFFER_TOKENS 等价项
    pass


@dataclass
class ContextCompactionContext:
    """单轮 `prune_and_compress` 节点执行时的流水线上下文。"""

    model: Any | None = None
    snip_tokens_freed_carry: int = 0
    query_source: str | None = None
    config: CompactionConfig = field(default_factory=CompactionConfig)
    progress_callback: CompactProgressCallback = None

    @classmethod
    def from_state(
        cls, state: Mapping[str, Any], model: Any | None
    ) -> ContextCompactionContext:
        return cls(
            model=model,
            query_source=state.get("query_source")
            if isinstance(state.get("query_source"), str)
            else None,
        )


@dataclass(frozen=True)
class StageResult:
    """单阶段输出；messages 为下一阶段输入。"""

    messages: list[Any]  # list[BaseMessage]，避免循环导入写 Any
    tokens_freed: int = 0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TokenWarningState:
    """启发式 token 体积告警（对齐 CC `calculateTokenWarningState` 一档语义）。"""

    estimated_tokens: int
    warn_threshold_tokens: int
    block_compact_llm_threshold_tokens: int
    block_main_model_threshold_tokens: int
    level: TokenWarningLevel


@dataclass(frozen=True)
class CompactProgress:
    """压缩进度通知（供 CLI 进度条消费）。

    属性：
        stage: 当前阶段名（tool_result_budget / snip / microcompact / collapse / autocompact / done）
        stage_index: 0-based 阶段序号
        total_stages: 总阶段数（默认 5）
        percent: 0-100 整体进度百分比
        detail: 可选描述（如 "generating summary..."）
    """

    stage: str
    stage_index: int
    total_stages: int
    percent: int
    detail: str | None = None


CompactProgressCallback = Callable[[CompactProgress], None] | None


__all__ = [
    "CompactionConfig",
    "CompactProgress",
    "CompactProgressCallback",
    "ContextCompactionContext",
    "StageResult",
    "TokenWarningLevel",
    "TokenWarningState",
]
