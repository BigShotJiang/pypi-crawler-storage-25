"""
主循环上下文治理的 **策略与提示词**（单一配置对象，便于替换与单测）。

与 Claude Code 对齐：
- 数值与 `OPENCODE_*` 环境变量覆盖语义、会话摘要模板与 CC `messagesForQuery` 后续各阶段读取的阈值/提示一致方向；
- 各 `CompactionStage` 实现应通过 `get_active_compaction_settings()` 读取，避免散落魔法数。

设计要点：
- `CompactionSettings` 为 `frozen` 值对象；可变绑定为模块级 `active_compaction_settings`，单测可 `set_active_compaction_settings(...)` 整体替换。

注意：
- 不依赖 LangGraph；与 `tool_runtime` 单条截断分工见设计文档。
- 紧凑化提示词函数（如 `get_compact_prompt`）在 **`loop/prompt/compact.py`**，不在本模块再导出。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet

from ..prompt.compact import AutocompactLlmPromptKind


@dataclass(frozen=True)
class CompactionSettings:
    """CC 对齐上下文治理的默认策略（提示词 + 数值阈值）。"""

    num_chars_per_token: int = 4
    prune_protect_tokens: int = 40_000
    prune_minimum_tokens: int = 20_000
    prune_protected_tools: FrozenSet[str] = field(default_factory=lambda: frozenset({"skill"}))
    default_max_context_tokens: int = 120_000
    default_compress_trigger_fraction: float = 0.8
    default_compress_keep_recent_messages: int = 8
    # --- autocompact LLM 提示词（对齐 `compact.ts` + `prompt.ts`）---
    # 摘要插在保留 tail 之前 → 默认 `partial_up_to`；全量折叠无尾窗时用 `full`；与 CC partial pivot「from」一致时用 `partial_from`。
    autocompact_llm_prompt_kind: AutocompactLlmPromptKind = "partial_up_to"
    # 追加到 CC 模板末尾的 Additional Instructions（对齐 hook merge 的 customInstructions）。
    compact_custom_instructions: str | None = None
    # 非 None 时跳过 builder，整段作为 compact 调用的指令（单测 / 完全自定义）。
    autocompact_llm_instructions_override: str | None = None
    # 兼容旧字段：未设置 override 时若此字段非空则优先于 builder（避免破坏只传 compaction_system_prompt 的调用方）。
    compaction_system_prompt: str | None = None
    # --- tool_result_budget（对齐 applyToolResultBudget：单条结果软上限）---
    tool_result_max_chars_per_message: int = 48_000
    tool_result_budget_suffix: str = field(
        default="\n\n[... truncated by tool_result_budget ...]"
    )
    # --- snip_compact（对齐 snip：尾部保留 + 历史大块截断）---
    snip_preserve_tail_messages: int = 10
    snip_max_tool_content_chars: int = 12_288
    snip_suffix: str = field(default="\n\n[... snipped by snip_compact ...]")
    # --- microcompact（轻量规范化；递归压缩时跳过）---
    microcompact_skip_query_sources: FrozenSet[str] = field(
        default_factory=lambda: frozenset({"compact"})
    )
    # --- context_collapse（重复 tool 结果治理）---
    collapse_dedupe_consecutive_same_tool_call_id: bool = True
    # --- autocompact（阈值触发；产品与 CC 对齐默认走 LLM 摘要，无 model 时回退 prune）---
    autocompact_skip_query_sources: FrozenSet[str] = field(
        default_factory=lambda: frozenset({"compact"})
    )
    autocompact_use_llm_when_available: bool = True
    autocompact_llm_excerpt_chars_per_message: int = 20_000
    # --- snip carry → autocompact 阈值放宽（对齐 CC snipTokensFreed 计入阈值）---
    # True：将本流水线已累计的 `snip_tokens_freed_carry` 加到触发阈值上，避免 snip 已释放后仍立刻 autocompact。
    autocompact_snip_carry_threshold_slack: bool = True
    # --- blocking / token 告警（对齐 CC calculateTokenWarningState 分档）---
    compaction_token_warn_fraction: float = 0.85
    compaction_block_compact_llm_fraction: float = 0.98
    # 达到或超过视为「主上下文已顶满」，建议由调用方拦主模型（本守卫 `should_block`）。
    compaction_block_main_model_fraction: float = 1.0
    # True：`model` 节点在 `invoke` 前若 `should_block` 命中则不再调主模型，写入合成 AIMessage 并结束。
    enable_main_model_context_token_block: bool = True
    # --- tool transcript guard（对齐 CC `ensureToolResultPairing`：发往 LLM 前修复 tool 配对）---
    # True：在绑定模型 `invoke/ainvoke` 前对 `messages` 做确定性修复（跨 assistant 去重 tool_call_id、
    # 去重连续 ToolMessage、补 synthetic 等），降低提供商 400 与会话卡死风险；不依赖提示词。
    enable_tool_transcript_repair_before_llm: bool = True
    # --- SystemMessage 单一来源兜底（对齐 CC normalizeMessagesForAPI）---
    # True：在 LLM 调用前剥离 state["messages"] 中所有 SystemMessage，避免 OpenAI 兼容 API 400 错误。
    enable_system_message_sanitizer: bool = True
    # True：剥离时输出内容预览（最多 3 条），便于排查违规来源。
    enable_system_message_content_preview: bool = True
    # --- 观测：写入 state.compaction_pipeline_meta（需 LoopAgentStateFields 含该键）---
    emit_compaction_pipeline_meta: bool = True


active_compaction_settings: CompactionSettings = CompactionSettings()


def get_active_compaction_settings() -> CompactionSettings:
    """返回当前生效的策略（默认即模块级 `active_compaction_settings`）。"""
    return active_compaction_settings


def set_active_compaction_settings(settings: CompactionSettings) -> None:
    """替换全局策略（单测或进程级配置用）。"""
    global active_compaction_settings
    active_compaction_settings = settings


__all__ = [
    "AutocompactLlmPromptKind",
    "CompactionSettings",
    "active_compaction_settings",
    "get_active_compaction_settings",
    "set_active_compaction_settings",
]
