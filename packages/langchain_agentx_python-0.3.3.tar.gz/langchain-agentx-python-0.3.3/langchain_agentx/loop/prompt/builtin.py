"""内置 SystemPromptSection 工厂函数。

提供框架级常用 section，供 create_loop_agent 与容器层组合使用。

设计原则：
- 每个工厂函数返回一个 SystemPromptSection
- volatile=False 的 section 在 session 内只计算一次（环境信息、语言偏好等）
- volatile=True 的 section 每轮重算（当前时间、动态工具列表等）
- 所有文本内容写在代码中（暂不引入 templates/ 目录）
"""

from __future__ import annotations

import platform
from datetime import datetime
from typing import TYPE_CHECKING

from .sections import SystemPromptSection, section, volatile_section

if TYPE_CHECKING:
    from typing import Any


def env_section(workspace_cfg: Any) -> SystemPromptSection:
    """环境信息 section（session 级缓存）。

    工作目录取自 ``AgentWorkspaceConfig.workspace_root``（见 ``session_context.env_section``）。
    """
    from .session_context import env_section as _env_section

    return _env_section(workspace_cfg)


def language_section(lang: str = "en") -> SystemPromptSection:
    """语言偏好 section（session 级缓存）。

    Args:
        lang: 语言代码（"en" / "zh" / "ja" 等）
    """

    def compute() -> str | None:
        if lang == "en":
            return None  # 默认英文，不注入额外提示
        if lang == "zh":
            return "# Language\nRespond in Simplified Chinese (简体中文) unless the user explicitly requests another language."
        if lang == "ja":
            return "# Language\nRespond in Japanese (日本語) unless the user explicitly requests another language."
        # 其他语言可按需扩展
        return f"# Language\nRespond in {lang} unless the user explicitly requests another language."

    return section(name="language", compute=compute)


def time_section() -> SystemPromptSection:
    """当前时间 section（volatile，每轮重算）。

    用于需要时间感知的场景（如日志分析、时间敏感任务）。
    """

    def compute() -> str:
        now = datetime.now()
        return f"""# Current Time
Current date and time: {now.strftime('%Y-%m-%d %H:%M:%S')}"""

    return volatile_section(
        name="current_time",
        compute=compute,
        reason="时间每轮变化，不能缓存",
    )


def token_budget_section(limit: int) -> SystemPromptSection:
    """Token 预算提示 section（session 级缓存）。

    Args:
        limit: Token 预算上限
    """

    def compute() -> str:
        return f"""# Token Budget
You have a token budget of approximately {limit:,} tokens for this conversation. Be concise and efficient in your responses."""

    return section(name="token_budget", compute=compute)


def git_safety_section() -> SystemPromptSection:
    """Git 安全红线 section（session 级缓存）。

    说明：
    - 该 section 仅提供规则文本，不负责决定是否注入。
    - 是否启用由调用方在 dynamic_sections 装配阶段决定（例如编码模式下启用）。
    """

    def compute() -> str:
        return """# Git Safety Protocol
When using git-related commands, follow these safety constraints:
- NEVER update git config unless the user explicitly requests it.
- NEVER run destructive commands (e.g. push --force, reset --hard, checkout --, restore ., clean -f, branch -D) unless the user explicitly requests them.
- NEVER skip hooks or signing checks (--no-verify, --no-gpg-sign, etc.) unless the user explicitly requests it.
- NEVER force-push to main/master; warn the user if they request it.
- Prefer creating a new commit instead of amending. If pre-commit hooks fail, fix issues and create a new commit rather than amending a previous commit.
- Prefer safer alternatives before destructive operations."""

    return section(name="git_safety", compute=compute)


def tool_routing_guard_section() -> SystemPromptSection:
    """系统级工具路由护栏 section（session 级缓存）。

    作用：对 Bash 工具描述中的“专用工具优先”规则做冗余强化（defense in depth）。
    """

    def compute() -> str:
        return """# Dedicated Tool Routing (Critical)
Do NOT use bash when a relevant dedicated tool is available.
Using dedicated tools improves user reviewability and execution safety.

- To read files, use read_file instead of cat/head/tail.
- To search file content, use grep instead of grep/rg via bash.
- To search files by pattern, use glob instead of find/ls.
- Reserve bash primarily for terminal operations that require shell execution (e.g., git/gh/system commands)."""

    return section(name="tool_routing_guard", compute=compute)


def actions_safety_section() -> SystemPromptSection:
    """高风险操作确认与可逆性优先 section（session 级缓存）。"""

    def compute() -> str:
        return """# Executing Actions With Care
Carefully consider reversibility and blast radius before acting.

- Prefer local and reversible actions by default.
- For risky or hard-to-reverse actions, confirm with the user before proceeding.
- Do not use destructive commands as shortcuts when blocked; diagnose root causes first.
- If you encounter unexpected state, investigate before deleting or overwriting."""

    return section(name="actions_safety", compute=compute)


def failure_diagnosis_section() -> SystemPromptSection:
    """失败诊断优先 section（session 级缓存）。"""

    def compute() -> str:
        return """# Failure Diagnosis
If an approach fails, diagnose why before switching tactics.

- Read the error and verify assumptions.
- Do not blindly retry the exact same failing action.
- Prefer a focused fix over broad destructive workarounds."""

    return section(name="failure_diagnosis", compute=compute)


def task_execution_baseline_section() -> SystemPromptSection:
    """任务执行基线 section（session 级缓存）。"""

    def compute() -> str:
        return """# Task Execution Baseline
- Understand first: read relevant files and existing patterns before changing code.
- Keep scope tight: avoid adding features or abstractions beyond the request.
- Report outcomes faithfully: if checks fail, say they fail; if not run, say not run."""

    return section(name="task_execution_baseline", compute=compute)


def get_coding_sections() -> list[SystemPromptSection]:
    """编码场景推荐 section 组合（仅返回列表，是否注入由调用方决定）。"""
    return [
        tool_routing_guard_section(),
        git_safety_section(),
        actions_safety_section(),
        failure_diagnosis_section(),
        task_execution_baseline_section(),
    ]


def tools_summary_section(tools: list[Any]) -> SystemPromptSection:
    """工具列表摘要 section（volatile，工具可能动态变化）。

    Args:
        tools: 当前可用的工具列表
    """

    def compute() -> str:
        tool_names = [getattr(t, "name", str(t)) for t in tools]
        return f"""# Available Tools
You have access to the following tools: {', '.join(tool_names)}"""

    return volatile_section(
        name="tools_summary",
        compute=compute,
        reason="工具列表可能在 session 中动态变化（Skill 激活/MCP 加载）",
    )


__all__ = [
    "actions_safety_section",
    "env_section",
    "failure_diagnosis_section",
    "get_coding_sections",
    "git_safety_section",
    "language_section",
    "task_execution_baseline_section",
    "time_section",
    "token_budget_section",
    "tool_routing_guard_section",
    "tools_summary_section",
]
