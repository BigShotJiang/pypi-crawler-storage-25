"""session_context.py — 会话级默认上下文 SystemPromptSection（date / env / git 快照）。

职责：
    为 create_loop_agent 提供与 CC 对齐的默认 session 上下文段；工作目录取自 AgentWorkspaceConfig。

链路位置：
    LoopGraphBuilder._prepare_compile_context → get_default_session_context_sections()。

当前裁剪范围：
    git 快照为可选（默认关）；子代理不注入 git 段。
"""

from __future__ import annotations

import os
import platform
import subprocess
from datetime import date
from pathlib import Path
from typing import TYPE_CHECKING

from .sections import SystemPromptSection, section

if TYPE_CHECKING:
    from langchain_agentx.workspace import AgentWorkspaceConfig

_GIT_STATUS_MAX_CHARS = 2000
_ENABLE_GIT_SNAPSHOT_ENV = "LANGCHAIN_AGENTX_ENABLE_GIT_SNAPSHOT"


def local_iso_date() -> str:
    """本地时区 ISO 日期（YYYY-MM-DD），对齐 CC getLocalISODate。"""
    override = os.environ.get("LANGCHAIN_AGENTX_OVERRIDE_DATE")
    if override:
        return override.strip()
    return date.today().isoformat()


def resolve_enable_git_snapshot(explicit: bool | None = None) -> bool:
    if explicit is not None:
        return bool(explicit)
    return os.environ.get(_ENABLE_GIT_SNAPSHOT_ENV, "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def date_section() -> SystemPromptSection:
    """当前日期（session 级缓存，对齐 CC currentDate 文案）。"""

    def compute() -> str:
        return f"Today's date is {local_iso_date()}."

    return section(name="session_date", compute=compute)


def env_section(workspace_cfg: AgentWorkspaceConfig) -> SystemPromptSection:
    """环境信息（session 级缓存）；工作目录使用 workspace_cfg.workspace_root。"""

    working_dir = str(Path(workspace_cfg.workspace_root).resolve())
    is_git = _is_git_repository(Path(workspace_cfg.workspace_root))

    def compute() -> str:
        return (
            "# Environment\n"
            "You have been invoked in the following environment:\n"
            f" - Primary working directory: {working_dir}\n"
            f" - Is a git repository: {'Yes' if is_git else 'No'}\n"
            f" - Platform: {platform.system().lower()}\n"
            f" - OS Version: {platform.platform()}\n"
            f" - Python: {platform.python_version()}"
        )

    return section(name="env_info", compute=compute)


def git_snapshot_section(workspace_root: Path) -> SystemPromptSection:
    """Git 仓库启动快照（session 级缓存，对齐 CC getGitStatus）。"""

    root = workspace_root.resolve()

    def compute() -> str | None:
        return collect_git_snapshot_text(root)

    return section(name="git_snapshot", compute=compute)


def get_default_session_context_sections(
    workspace_cfg: AgentWorkspaceConfig,
    *,
    container_type: str | None = None,
    is_subagent: bool = False,
    enable_git_snapshot: bool | None = None,
) -> list[SystemPromptSection]:
    """按容器类型装配默认 session 上下文段（Loop 层单一装配入口）。"""
    del container_type  # 预留：后续可按 workflow_task / sdk 等细分策略
    sections: list[SystemPromptSection] = [
        date_section(),
        env_section(workspace_cfg),
    ]
    if not is_subagent and resolve_enable_git_snapshot(enable_git_snapshot):
        sections.append(git_snapshot_section(Path(workspace_cfg.workspace_root)))
    return sections


def collect_git_snapshot_text(workspace_root: Path) -> str | None:
    """收集 git 快照文本；非 git 仓库或命令失败时返回 None。"""
    root = workspace_root.resolve()
    if not _is_git_repository(root):
        return None
    branch = _git_output(["rev-parse", "--abbrev-ref", "HEAD"], root) or "unknown"
    main_branch = _resolve_default_branch(root)
    status = _git_output(["--no-optional-locks", "status", "--short"], root) or ""
    log = _git_output(["--no-optional-locks", "log", "--oneline", "-n", "5"], root) or ""
    user_name = _git_output(["config", "user.name"], root)

    truncated_status = status
    if len(status) > _GIT_STATUS_MAX_CHARS:
        truncated_status = (
            status[:_GIT_STATUS_MAX_CHARS]
            + '\n... (truncated because it exceeds 2k characters. If you need more '
            'information, run "git status" using BashTool)'
        )

    lines = [
        "This is the git status at the start of the conversation. Note that this status "
        "is a snapshot in time, and will not update during the conversation.",
        f"Current branch: {branch}",
        f"Main branch (you will usually use this for PRs): {main_branch}",
    ]
    if user_name:
        lines.append(f"Git user: {user_name}")
    lines.append(f"Status:\n{truncated_status or '(clean)'}")
    lines.append(f"Recent commits:\n{log}")
    return "\n\n".join(lines)


def _is_git_repository(workspace_root: Path) -> bool:
    return (workspace_root / ".git").exists()


def _resolve_default_branch(workspace_root: Path) -> str:
    origin_head = _git_output(["symbolic-ref", "refs/remotes/origin/HEAD"], workspace_root)
    if origin_head:
        prefix = "refs/remotes/origin/"
        if origin_head.startswith(prefix):
            return origin_head[len(prefix) :]
        return origin_head
    for candidate in ("main", "master"):
        if _git_output(["rev-parse", "--verify", f"refs/heads/{candidate}"], workspace_root):
            return candidate
    return "main"


def _git_output(args: list[str], cwd: Path) -> str | None:
    try:
        completed = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if completed.returncode != 0:
        return None
    return completed.stdout.strip() or None


__all__ = [
    "collect_git_snapshot_text",
    "date_section",
    "env_section",
    "get_default_session_context_sections",
    "git_snapshot_section",
    "local_iso_date",
    "resolve_enable_git_snapshot",
]
