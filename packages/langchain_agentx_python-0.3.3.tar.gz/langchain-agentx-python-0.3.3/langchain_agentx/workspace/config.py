"""
workspace/config.py — AgentWorkspace 路径配置模型

职责：
    提供 `workspace_root + agent_home` 的派生目录视图（skills/worktrees/tasks/data/db），
    作为跨模块目录语义的数据模型。

在整体链路中的位置：
    AgentWorkspaceResolver.resolve()
      -> AgentWorkspaceConfig
      -> 各入口按属性读取目标路径。

当前裁剪范围：
    仅路径派生，不做校验与副作用创建。
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import TYPE_CHECKING, Optional

from .path_key_normalizer import normalize_path_key

if TYPE_CHECKING:
    from .capabilities import NodeWorkspaceOverrides, WorkspaceDefaults


def _sanitize_agent_type(agent_type: str) -> str:
    """安全化 agent_type，避免路径注入；键串先 NFC 与 session_id 同策略。"""
    normalized = normalize_path_key(str(agent_type or "").strip())
    normalized = normalized.replace(":", "-")
    normalized = re.sub(r"[/\\]", "-", normalized)
    normalized = normalized.replace("..", "-")
    normalized = normalized.replace("\x00", "")
    normalized = normalized.strip("-").strip()
    if not normalized:
        raise ValueError(f"agent_type {agent_type!r} sanitizes to empty string")
    return normalized


def _normalize_memory_scope(scope: str) -> str:
    """单路径段 scope（project/user/local 等）做 NFC，并拒绝路径分隔与穿越片段。"""
    s = normalize_path_key(str(scope or "").strip())
    if not s:
        raise ValueError("scope cannot be empty")
    if re.search(r"[/\\]", s) or ".." in s:
        raise ValueError(f"invalid scope for agent_memory_dir: {scope!r}")
    return s


@dataclass(frozen=True)
class AgentWorkspaceConfig:
    workspace_root: Path
    agent_home: str = ".langchain_agentx"
    plugins_enabled: bool = True
    workspace_trust_accepted: bool = False
    _defaults: Optional["WorkspaceDefaults"] = field(default=None, repr=False, compare=False)
    _overrides: Optional["NodeWorkspaceOverrides"] = field(default=None, repr=False, compare=False)

    @property
    def agent_home_dir(self) -> Path:
        return (self.workspace_root / self.agent_home).resolve()

    @property
    def skills_dir(self) -> Path:
        if self._overrides is not None and self._overrides.skills_dir is not None:
            return Path(self._overrides.skills_dir)
        if self._defaults is not None and self._defaults.default_skills_dir is not None:
            return Path(self._defaults.default_skills_dir)
        return self.agent_home_dir / "skills"

    @property
    def agents_dir(self) -> Path:
        """用户自定义 Agent 定义目录（Markdown 文件）。
        AgentDefinitionLoader 从此目录加载 SubagentConfig（*.md）。
        """
        if self._overrides is not None and self._overrides.agents_dir is not None:
            return Path(self._overrides.agents_dir)
        if self._defaults is not None and self._defaults.default_agents_dir is not None:
            return Path(self._defaults.default_agents_dir)
        return self.agent_home_dir / "agents"

    @property
    def worktrees_dir(self) -> Path:
        return self.agent_home_dir / "worktrees"

    @property
    def tasks_dir(self) -> Path:
        return self.agent_home_dir / "tasks"

    @property
    def data_dir(self) -> Path:
        return self.agent_home_dir / "data"

    @property
    def db_dir(self) -> Path:
        return self.data_dir / "db"

    @property
    def traces_db_path(self) -> Path:
        """DEPRECATED (2026-05-12)：trace 存储属 A 档，应从
        ``RuntimeCapabilities.trace_collector`` 读取；保留 shim 供迁移期使用。"""
        warnings.warn(
            "AgentWorkspaceConfig.traces_db_path 是 A 档资源，未来将移除。"
            "请从 RuntimeCapabilities.trace_collector 读取。",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.db_dir / "traces.db"

    @property
    def task_runtime_db_path(self) -> Path:
        """DEPRECATED (2026-05-12)：task_runtime 属 A 档。"""
        warnings.warn(
            "AgentWorkspaceConfig.task_runtime_db_path 是 A 档资源，未来将移除。"
            "请从 RuntimeCapabilities.task_runtime 获取相关路径。",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.db_dir / "task_runtime.db"

    @property
    def evaluation_db_path(self) -> Path:
        """DEPRECATED (2026-05-12)：评估存储属 A 档。"""
        warnings.warn(
            "AgentWorkspaceConfig.evaluation_db_path 是 A 档资源，未来将移除。",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.db_dir / "evaluation.db"

    @property
    def memory_dir(self) -> Path:
        if self._overrides is not None and self._overrides.memory_dir is not None:
            return Path(self._overrides.memory_dir)
        if self._defaults is not None and self._defaults.default_memory_dir is not None:
            return Path(self._defaults.default_memory_dir)
        return self.agent_home_dir / "memory"

    @property
    def memory_entrypoint(self) -> Path:
        return self.memory_dir / "MEMORY.md"

    @property
    def sessions_dir(self) -> Path:
        if self._overrides is not None and self._overrides.sessions_dir is not None:
            return Path(self._overrides.sessions_dir)
        if self._defaults is not None and self._defaults.default_sessions_dir is not None:
            return Path(self._defaults.default_sessions_dir)
        return self.agent_home_dir / "sessions"

    @property
    def transcripts_dir(self) -> Path:
        return self.agent_home_dir / "transcripts"

    @property
    def workspace_config_path(self) -> Path:
        return self.agent_home_dir / "workspace_config.json"

    @property
    def tool_runtime_config_path(self) -> Path:
        """工具运行时本地特性开关 JSON（如 UserMessageTool v2 Phase 2）。"""
        return self.agent_home_dir / "tool_runtime_config.json"

    @property
    def plugins_dir(self) -> Path:
        return self.agent_home_dir / "plugins"

    @property
    def plugin_config_path(self) -> Path:
        return self.agent_home_dir / "plugin_config.json"

    @property
    def plugin_cache_dir(self) -> Path:
        return self.agent_home_dir / "plugin_cache"

    def session_memory_path(self, session_id: str) -> Path:
        sid = normalize_path_key(str(session_id).strip())
        if not sid:
            raise ValueError("session_id cannot be empty")
        return self.sessions_dir / f"{sid}.md"

    @property
    def session_memory_config_dir(self) -> Path:
        return self.agent_home_dir / "session-memory" / "config"

    def agent_memory_dir(self, agent_type: str, scope: str = "project") -> Path:
        sanitized = _sanitize_agent_type(agent_type)
        sc = _normalize_memory_scope(scope)
        return self.memory_dir / "agents" / sanitized / sc

    def agent_memory_entrypoint(self, agent_type: str, scope: str = "project") -> Path:
        return self.agent_memory_dir(agent_type, scope) / "MEMORY.md"
