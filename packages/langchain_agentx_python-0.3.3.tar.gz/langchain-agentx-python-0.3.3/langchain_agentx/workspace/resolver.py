"""
workspace/resolver.py — AgentWorkspace 配置解析协作者

职责：
    按统一优先级解析 workspace_root 与 agent_home，并产出
    AgentWorkspaceConfig，作为全局目录语义单一来源。

在整体链路中的位置：
    各入口（tool_runtime / task_runtime / loop / observability）
      -> resolve_agent_workspace_config()
      -> AgentWorkspaceResolver.resolve()

当前裁剪范围：
    解析与校验；不直接做业务目录写入。
"""

from __future__ import annotations

import os
from pathlib import Path

from .capabilities import NodeWorkspaceOverrides, WorkspaceDefaults
from .config import AgentWorkspaceConfig
from .validators import AgentWorkspacePathValidator

DEFAULT_AGENT_HOME = ".langchain_agentx"
ENV_AGENT_HOME = "LANGCHAIN_AGENTX_AGENT_HOME"
ENV_WORKSPACE_ROOT = "LANGCHAIN_AGENTX_WORKSPACE_ROOT"


def resolve_workspace_root_path(
    workspace_root: str | Path | None = None,
    *,
    env_workspace_root: str = ENV_WORKSPACE_ROOT,
) -> Path:
    """解析 workspace 根路径，与 ``AgentWorkspaceResolver.resolve`` 内默认链一致。

    优先级：显式 ``workspace_root`` → 环境变量 ``LANGCHAIN_AGENTX_WORKSPACE_ROOT`` → ``os.getcwd()``，
    再 ``expanduser().resolve()``。供 ``RuntimeCapabilities.build``、``BaseWorkflow`` 等与
    ``resolve_agent_workspace_config`` 对齐，避免各入口分叉。
    """
    root_raw = workspace_root or os.getenv(env_workspace_root) or os.getcwd()
    return Path(root_raw).expanduser().resolve()


def resolve_agent_home_string(
    agent_home: str | None = None,
    *,
    default_agent_home: str = DEFAULT_AGENT_HOME,
    env_agent_home: str = ENV_AGENT_HOME,
    path_validator: AgentWorkspacePathValidator | None = None,
) -> str:
    """解析 agent_home 字符串，与 ``AgentWorkspaceResolver.resolve`` 内默认链一致。"""
    pv = path_validator or AgentWorkspacePathValidator()
    home_raw = (
        agent_home
        if agent_home is not None
        else os.getenv(env_agent_home, default_agent_home)
    )
    return pv.validate_agent_home(home_raw)


class AgentWorkspaceResolver:
    """Agent workspace 配置解析器。

    与 RuntimeCapabilities 协作：
        - A 档（trace / profiles / task_runtime）由 RuntimeCapabilities 提供
        - B 档默认目录（skills/sessions/memory）通过 ``defaults`` 注入
        - C 档节点级覆盖通过 ``overrides`` 注入；越界抛 WorkspaceBoundaryError

    优先级：overrides > defaults > 路径派生兜底。B/C 档目标路径通过
    ``resolve_skills_dir/resolve_sessions_dir/resolve_memory_dir`` 静态方法
    合并，仍由调用方自行拼装具体消费（保持解析与消费分离）。
    """

    def __init__(
        self,
        *,
        default_agent_home: str = DEFAULT_AGENT_HOME,
        env_agent_home: str = ENV_AGENT_HOME,
        env_workspace_root: str = ENV_WORKSPACE_ROOT,
        path_validator: AgentWorkspacePathValidator | None = None,
    ) -> None:
        self._default_agent_home = default_agent_home
        self._env_agent_home = env_agent_home
        self._env_workspace_root = env_workspace_root
        self._path_validator = path_validator or AgentWorkspacePathValidator()

    def resolve(
        self,
        *,
        workspace_root: str | Path | None = None,
        agent_home: str | None = None,
        defaults: WorkspaceDefaults | None = None,
        overrides: NodeWorkspaceOverrides | None = None,
    ) -> AgentWorkspaceConfig:
        root = resolve_workspace_root_path(
            workspace_root,
            env_workspace_root=self._env_workspace_root,
        )
        home = resolve_agent_home_string(
            agent_home,
            default_agent_home=self._default_agent_home,
            env_agent_home=self._env_agent_home,
            path_validator=self._path_validator,
        )
        if overrides is not None:
            overrides.validate(root)
        cfg = AgentWorkspaceConfig(
            workspace_root=root,
            agent_home=home,
            _defaults=defaults,
            _overrides=overrides,
        )
        self._path_validator.ensure_within_workspace(cfg.workspace_root, cfg.agent_home_dir)
        return cfg

    @staticmethod
    def resolve_skills_dir(
        cfg: AgentWorkspaceConfig,
        *,
        defaults: WorkspaceDefaults | None = None,
        overrides: NodeWorkspaceOverrides | None = None,
    ) -> Path:
        if overrides is not None and overrides.skills_dir is not None:
            return Path(overrides.skills_dir)
        if defaults is not None and defaults.default_skills_dir is not None:
            return Path(defaults.default_skills_dir)
        return cfg.skills_dir

    @staticmethod
    def resolve_sessions_dir(
        cfg: AgentWorkspaceConfig,
        *,
        defaults: WorkspaceDefaults | None = None,
        overrides: NodeWorkspaceOverrides | None = None,
    ) -> Path:
        if overrides is not None and overrides.sessions_dir is not None:
            return Path(overrides.sessions_dir)
        if defaults is not None and defaults.default_sessions_dir is not None:
            return Path(defaults.default_sessions_dir)
        return cfg.sessions_dir

    @staticmethod
    def resolve_memory_dir(
        cfg: AgentWorkspaceConfig,
        *,
        defaults: WorkspaceDefaults | None = None,
        overrides: NodeWorkspaceOverrides | None = None,
    ) -> Path:
        if overrides is not None and overrides.memory_dir is not None:
            return Path(overrides.memory_dir)
        if defaults is not None and defaults.default_memory_dir is not None:
            return Path(defaults.default_memory_dir)
        return cfg.memory_dir


_DEFAULT_RESOLVER = AgentWorkspaceResolver()


def resolve_agent_workspace_config(
    *,
    workspace_root: str | Path | None = None,
    agent_home: str | None = None,
    defaults: WorkspaceDefaults | None = None,
    overrides: NodeWorkspaceOverrides | None = None,
) -> AgentWorkspaceConfig:
    """兼容入口：调用默认 AgentWorkspaceResolver。"""
    return _DEFAULT_RESOLVER.resolve(
        workspace_root=workspace_root,
        agent_home=agent_home,
        defaults=defaults,
        overrides=overrides,
    )
