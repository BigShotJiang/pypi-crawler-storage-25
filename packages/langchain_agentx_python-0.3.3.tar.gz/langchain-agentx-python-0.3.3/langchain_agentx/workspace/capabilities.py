"""
workspace/capabilities.py — RuntimeCapabilities 单例与分档协作者

职责：
    提供 Workflow/进程级单例 ``RuntimeCapabilities``，封装 A 档（全局共享资源：
    profiles / trace_collector / task_runtime）与 B 档（默认目录：
    skills/sessions/memory）。与节点级 ``AgentWorkspaceConfig``（B+C 档）正交，
    由 Workflow/Session 构造期装配并单向注入到下游。

在整体链路中的位置：
    Workflow/AgentSession 构造
      -> RuntimeCapabilitiesBuilder.build() / RuntimeCapabilities.build()
      -> AgentNode.build(capabilities=..., workspace_config=...)
      -> create_loop_agent / CompiledLoopAgent

当前裁剪范围：
    - A 档：model_profile_registry / trace_collector / task_runtime
    - B 档：WorkspaceDefaults（default_skills_dir / default_sessions_dir / default_memory_dir）
    - Overrides：NodeWorkspaceOverrides（skills_dir / sessions_dir / memory_dir + validate）
    - provider 凭证管理暂沿用原 provider 模块，后续另迁
    - 不承载目录副作用创建；trace_collector 失败降级不写磁盘，仅发 hook 告警
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from langchain_agentx.provider.model_profile import ModelProfileRegistry

logger = logging.getLogger(__name__)


class WorkspaceBoundaryError(ValueError):
    """节点 overrides 路径越出 workspace_root 时抛出。"""


class AgentHomeMismatchError(ValueError):
    """节点 ``agent_home`` 与 ``RuntimeCapabilities.primary_agent_home`` 不一致时抛出。"""


def assert_agent_home_matches_capabilities(
    capabilities: "RuntimeCapabilities",
    agent_home: str,
) -> None:
    """编排层校验：全局 primary 与各节点 ``agent_home`` 须为同一字符串（架构 A05）。"""
    if capabilities.primary_agent_home != agent_home:
        raise AgentHomeMismatchError(
            f"agent_home mismatch: RuntimeCapabilities.primary_agent_home="
            f"{capabilities.primary_agent_home!r}, node agent_home={agent_home!r}"
        )


@dataclass(frozen=True)
class NodeWorkspaceOverrides:
    """节点级目录覆盖：影响单个节点，越界时抛 WorkspaceBoundaryError。"""

    skills_dir: Optional[Path] = None
    agents_dir: Optional[Path] = None
    sessions_dir: Optional[Path] = None
    memory_dir: Optional[Path] = None

    def validate(self, workspace_root: Path) -> None:
        """确保覆盖路径在 workspace 范围内；越界则抛 WorkspaceBoundaryError。"""
        base = workspace_root.resolve()
        for name, path in (
            ("skills_dir", self.skills_dir),
            ("agents_dir", self.agents_dir),
            ("sessions_dir", self.sessions_dir),
            ("memory_dir", self.memory_dir),
        ):
            if path is None:
                continue
            resolved = Path(path).resolve()
            if not str(resolved).startswith(str(base)):
                raise WorkspaceBoundaryError(
                    f"Node override {name}={path} is outside workspace_root={workspace_root}"
                )


@dataclass(frozen=True)
class WorkspaceDefaults:
    """B 档默认值容器：节点未覆盖时使用。"""

    default_skills_dir: Optional[Path] = None
    default_agents_dir: Optional[Path] = None
    default_sessions_dir: Optional[Path] = None
    default_memory_dir: Optional[Path] = None


class _TraceCollectorFactory:
    """trace_collector 构造 + 失败降级的小协作者。

    将"构造 / retry / 降级 / hook 告警"聚合为一个职责，避免 capabilities.build
    变成过程式堆叠。失败降级为 ``TraceCollector(store=None)``（内存空操作）。
    """

    _RETRYABLE_ERRORS: tuple[type[BaseException], ...] = (ConnectionError, TimeoutError)

    def __init__(
        self,
        *,
        primary_home_dir: Path,
        hook_registry: Any | None = None,
        store_builder: Optional[Callable[[Path], Any]] = None,
    ) -> None:
        self._primary_home_dir = primary_home_dir
        self._hook_registry = hook_registry
        self._store_builder = store_builder

    def build(self) -> Any:
        from langchain_agentx.observability.trace import TraceCollector

        try:
            return self._build_once()
        except self._RETRYABLE_ERRORS as e:
            logger.warning("TraceCollector 构造失败（retryable），重试: %s", e)
            try:
                return self._build_once()
            except self._RETRYABLE_ERRORS as e2:
                logger.error(
                    "TraceCollector 重试后仍失败，降级为 NullTraceCollector: %s", e2
                )
                self._emit_failed_hook(reason=str(e2))
                return TraceCollector(store=None)
        except Exception as e:  # noqa: BLE001 — 非 retryable 直接降级
            logger.error(
                "TraceCollector 构造失败（%s），降级为 NullTraceCollector: %s",
                type(e).__name__,
                e,
            )
            self._emit_failed_hook(reason=f"{type(e).__name__}: {e}")
            return TraceCollector(store=None)

    def _build_once(self) -> Any:
        from langchain_agentx.observability.trace import (
            SqliteTraceStore,
            TraceCollector,
        )

        if self._store_builder is not None:
            store = self._store_builder(self._primary_home_dir)
        else:
            db_file = self._primary_home_dir / "data" / "db" / "traces.db"
            db_file.parent.mkdir(parents=True, exist_ok=True)
            store = SqliteTraceStore(db_path=str(db_file))
        return TraceCollector(store=store)

    def _emit_failed_hook(self, *, reason: str) -> None:
        if self._hook_registry is None:
            return
        emit = getattr(self._hook_registry, "emit", None)
        if callable(emit):
            try:
                emit({"event": "trace_collector_failed", "reason": reason})
            except Exception:  # noqa: BLE001 — hook 告警失败不应影响主流程
                logger.exception("trace_collector_failed hook 派发失败")


@dataclass(frozen=True)
class RuntimeCapabilities:
    """
    Workflow/进程级单例：A 档资源 + B 档默认值。

    frozen=True 保证单例对象不可变；需要动态行为（例如 trace_collector 重连）
    时应在 collector 内部维护状态，而不是替换 capabilities。
    """

    primary_workspace_root: Path
    primary_agent_home: str
    model_profile_registry: ModelProfileRegistry
    trace_collector: Any
    task_runtime: Optional[Any] = None
    defaults: WorkspaceDefaults = field(default_factory=WorkspaceDefaults)

    @classmethod
    def build(
        cls,
        *,
        primary_workspace_root: Path,
        primary_agent_home: str = ".langchain_agentx",
        task_runtime: Optional[Any] = None,
        defaults: Optional[WorkspaceDefaults] = None,
        hook_registry: Any | None = None,
        profile_registry_loader: Optional[Callable[[Path], ModelProfileRegistry]] = None,
        trace_store_builder: Optional[Callable[[Path], Any]] = None,
    ) -> "RuntimeCapabilities":
        """构造 RuntimeCapabilities 单例。

        Args:
            primary_workspace_root: 全局 workspace 根路径（经 ``resolve_workspace_root_path`` 规范化后与 resolver 一致）。
            primary_agent_home: 全局 agent_home 子目录名（经 ``resolve_agent_home_string`` 校验）。
            task_runtime: 可选任务运行时（A 档）。
            defaults: B 档默认值；缺省时按 ``primary_home_dir/{skills|sessions|memory}`` 派生。
            hook_registry: 可选 hook 注册表，用于 trace_collector 失败告警。
            profile_registry_loader: 注入点，便于测试 mock ``ModelProfileRegistry.from_files``。
            trace_store_builder: 注入点，便于测试替换 store 构造。
        """
        from .resolver import resolve_agent_home_string, resolve_workspace_root_path

        resolved_root = resolve_workspace_root_path(primary_workspace_root)
        resolved_home = resolve_agent_home_string(primary_agent_home)
        primary_home_dir = (resolved_root / resolved_home).resolve()
        loader = profile_registry_loader or (
            lambda home: ModelProfileRegistry.from_files(agent_home_dir=home)
        )
        registry = loader(primary_home_dir)
        collector = _TraceCollectorFactory(
            primary_home_dir=primary_home_dir,
            hook_registry=hook_registry,
            store_builder=trace_store_builder,
        ).build()
        effective_defaults = defaults or WorkspaceDefaults(
            default_skills_dir=primary_home_dir / "skills",
            default_agents_dir=primary_home_dir / "agents",
            default_sessions_dir=primary_home_dir / "sessions",
            default_memory_dir=primary_home_dir / "memory",
        )
        return cls(
            primary_workspace_root=resolved_root,
            primary_agent_home=resolved_home,
            model_profile_registry=registry,
            trace_collector=collector,
            task_runtime=task_runtime,
            defaults=effective_defaults,
        )


__all__ = [
    "AgentHomeMismatchError",
    "NodeWorkspaceOverrides",
    "RuntimeCapabilities",
    "WorkspaceBoundaryError",
    "WorkspaceDefaults",
    "assert_agent_home_matches_capabilities",
]
