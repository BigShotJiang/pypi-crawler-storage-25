"""
runtime 框架端到端冒烟测试（smoke_test_runtime.py）

用途：
    快速验证 runtime 框架的完整执行路径，无需完整环境，
    可直接 `python smoke_test_runtime.py` 运行（不依赖 pytest）。

覆盖场景：
    1. 正常工具流转（EchoTool 10 步 pipeline）
    2. adapter.envelope_to_tool_output 输出格式
    3. validate_input 失败 → error envelope 短路
    4. check_permissions deny → blocked envelope 短路
    5. ToolOutputManager 超限截断 + overflow_file
    6. registry + DefaultPolicyEngine 无路径字段放行
    7. StateBridge record_read / has_been_read / append_audit
"""

from __future__ import annotations

import os
import sys
import tempfile
import types
import pathlib
import importlib.util

# ---------------------------------------------------------------------------
# 绕过顶层 langchain_agentx/__init__.py（该文件依赖尚未安装的包）
# 手动注册父包 stub，直接加载 runtime 子模块
# ---------------------------------------------------------------------------

def _stub_pkg(name: str, path_hint: str) -> None:
    m = types.ModuleType(name)
    m.__path__ = [path_hint]
    m.__package__ = name
    sys.modules[name] = m


# 本文件位于 langchain_agentx/tool_runtime/，parents[2] = 仓库根（含 langchain_agentx 包目录）
_ROOT = pathlib.Path(__file__).resolve().parents[2]

_stub_pkg("langchain_agentx",         str(_ROOT / "langchain_agentx"))
_stub_pkg("langchain_agentx.tool_runtime", str(_ROOT / "langchain_agentx/tool_runtime"))


def _load_module(sub: str) -> None:
    mod_name = f"langchain_agentx.tool_runtime.{sub}"
    path = _ROOT / "langchain_agentx/tool_runtime" / f"{sub}.py"
    spec = importlib.util.spec_from_file_location(mod_name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)


for _sub in [
    "models",
    "errors",
    "base",
    "policy",
    "session_store",
    "state_bridge",
    "pipeline",
    "adapter",
    "registry",
]:
    _load_module(_sub)

# ---------------------------------------------------------------------------
# 导入
# ---------------------------------------------------------------------------

from langchain_agentx.tool_runtime.models       import ToolExecutionContext, ToolResultEnvelope, ValidationResult, AuthorizationDecision  # noqa: E402
from langchain_agentx.tool_runtime.base         import RuntimeTool                # noqa: E402
from langchain_agentx.tool_runtime.pipeline     import ToolExecutorPipeline       # noqa: E402
from langchain_agentx.tool_runtime.adapter      import LangChainAdapter           # noqa: E402
from langchain_agentx.tool_runtime.registry     import RuntimeToolRegistry        # noqa: E402
from langchain_agentx.tool_runtime.policy       import ToolPolicyConfig, DefaultPolicyEngine  # noqa: E402
from langchain_agentx.tool_runtime.session_store import AgentSessionStore  # noqa: E402
from langchain_agentx.tool_runtime.state_bridge import ToolStateBridge            # noqa: E402
from pydantic import BaseModel                                                      # noqa: E402

# ---------------------------------------------------------------------------
# 最小工具定义（所有测试共用）
# ---------------------------------------------------------------------------

class EchoInput(BaseModel):
    message: str


class EchoTool(RuntimeTool):
    name        = "echo"
    description = "回显输入消息"
    input_model = EchoInput
    is_read_only = True

    def invoke(self, data, ctx):
        return data["message"]

    def present(self, data, result, ctx):
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=f"Echo: {result}",
            payload=result,
        )


# ---------------------------------------------------------------------------
# 辅助
# ---------------------------------------------------------------------------

def _make_ctx(state=None) -> ToolExecutionContext:
    return ToolExecutionContext(
        tool_name="echo",
        tool_call_id="call_001",
        input_args={"message": "hello"},
        state=state if state is not None else {},
        session_store=AgentSessionStore("smoke"),
    )


def _pass(label: str) -> None:
    print(f"  ✅ {label}")


def _section(title: str) -> None:
    print(f"\n=== {title} ===")


# ---------------------------------------------------------------------------
# Smoke tests
# ---------------------------------------------------------------------------

def test_normal_flow() -> None:
    _section("Test 1: 正常工具流转")
    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    env = pipeline.run(tool=EchoTool(), raw_input={"message": "hello runtime"}, ctx=ctx)
    assert env.status == "ok", f"got {env.status}"
    assert "hello runtime" in env.summary
    _pass(f"status=ok, summary={env.summary!r}")


def test_adapter_output() -> None:
    _section("Test 2: adapter.envelope_to_tool_output")
    pipeline = ToolExecutorPipeline()
    adapter = LangChainAdapter()
    ctx = _make_ctx()
    env = pipeline.run(tool=EchoTool(), raw_input={"message": "hello"}, ctx=ctx)
    output = adapter.envelope_to_tool_output(env)
    assert "hello" in output
    _pass(f"output={output!r}")


def test_validate_input_short_circuit() -> None:
    _section("Test 3: validate_input 失败 → error 短路")

    class StrictEcho(EchoTool):
        name = "strict_echo"
        def validate_input(self, data, ctx):
            if len(data["message"]) > 5:
                return ValidationResult(ok=False, message="message too long")
            return ValidationResult(ok=True)

    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    env = pipeline.run(tool=StrictEcho(), raw_input={"message": "too long message"}, ctx=ctx)
    assert env.status == "error"
    assert "too long" in env.summary
    _pass(f"status=error, summary={env.summary!r}")


def test_check_permissions_blocked() -> None:
    _section("Test 4: check_permissions deny → blocked 短路")

    class DeniedEcho(EchoTool):
        name = "denied_echo"
        def check_permissions(self, data, ctx):
            return AuthorizationDecision(behavior="deny", message="not allowed here")

    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    env = pipeline.run(tool=DeniedEcho(), raw_input={"message": "hi"}, ctx=ctx)
    assert env.status == "blocked"
    assert "not allowed" in env.summary
    _pass(f"status=blocked, summary={env.summary!r}")


def test_output_manager_truncation() -> None:
    _section("Test 5: ToolOutputManager 超限截断")

    class TinyEcho(EchoTool):
        name = "tiny_echo"
        max_result_size_chars = 5

    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    env = pipeline.run(tool=TinyEcho(), raw_input={"message": "hello runtime 1234"}, ctx=ctx)
    assert env.truncated is True
    assert env.overflow_file is not None
    assert os.path.exists(env.overflow_file)
    _pass(f"truncated=True, overflow_file={env.overflow_file}")


def test_registry_and_policy_no_path_field() -> None:
    _section("Test 6: registry + DefaultPolicyEngine（无路径字段 → allow）")
    tmpdir = tempfile.mkdtemp()
    policy = DefaultPolicyEngine(
        ToolPolicyConfig(read_roots=[tmpdir], write_roots=[tmpdir])
    )
    pipeline = ToolExecutorPipeline()
    adapter = LangChainAdapter()
    registry = RuntimeToolRegistry(pipeline=pipeline, adapter=adapter)
    registry.register(EchoTool(policy=policy))

    assert "echo" in registry
    lc_tools = registry.to_langchain_tools()
    assert len(lc_tools) == 1
    assert lc_tools[0].name == "echo"

    ctx = _make_ctx()
    env = pipeline.run(tool=registry.get("echo"), raw_input={"message": "ok"}, ctx=ctx)
    assert env.status == "ok"
    _pass("registry.register + to_langchain_tools OK, policy allow (no path field)")


def test_state_bridge() -> None:
    _section("Test 7: ToolStateBridge record_read / has_been_read / append_audit")
    bridge = ToolStateBridge()
    state = {}
    ctx = ToolExecutionContext(
        tool_name="echo",
        tool_call_id="c1",
        input_args={},
        state=state,
        session_store=AgentSessionStore("smoke-bridge"),
    )

    _td = pathlib.Path(tempfile.gettempdir())
    foo = str(_td / "langchain_agentx_smoke" / "foo.txt")
    bar = str(_td / "langchain_agentx_smoke" / "bar.txt")
    bridge.record_read(ctx, foo, line_start=1, line_end=10)
    assert bridge.has_been_read(ctx, foo)
    assert not bridge.has_been_read(ctx, bar)

    bridge.append_audit(ctx, {"tool": "echo", "ts": 9999})
    log = bridge.get_audit_log(ctx)
    assert len(log) == 1
    assert log[0]["tool"] == "echo"
    _pass("record_read / has_been_read / audit OK")


def test_exception_captured_as_error_envelope() -> None:
    _section("Test 8: invoke 抛异常 → pipeline 捕获为 error envelope")

    class BrokenEcho(EchoTool):
        name = "broken_echo"
        def invoke(self, data, ctx):
            raise ValueError("something went wrong")

    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    env = pipeline.run(tool=BrokenEcho(), raw_input={"message": "hi"}, ctx=ctx)
    assert env.status == "error"
    assert "went wrong" in env.summary
    assert env.meta is not None and "traceback" in env.meta
    _pass(f"status=error, summary={env.summary!r}, traceback in meta")


def test_schema_parse_failure() -> None:
    _section("Test 9: Pydantic schema 解析失败 → error 短路")
    pipeline = ToolExecutorPipeline()
    ctx = _make_ctx()
    # 传入错误类型（缺少必填 message 字段）
    env = pipeline.run(tool=EchoTool(), raw_input={}, ctx=ctx)
    assert env.status == "error"
    assert "schema" in env.summary.lower() or "message" in env.summary.lower()
    _pass(f"status=error on missing field: {env.summary!r}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    tests = [
        test_normal_flow,
        test_adapter_output,
        test_validate_input_short_circuit,
        test_check_permissions_blocked,
        test_output_manager_truncation,
        test_registry_and_policy_no_path_field,
        test_state_bridge,
        test_exception_captured_as_error_envelope,
        test_schema_parse_failure,
    ]
    failed = []
    for fn in tests:
        try:
            fn()
        except Exception as exc:
            print(f"  ❌ FAILED: {exc}")
            failed.append(fn.__name__)

    print()
    if failed:
        print(f"❌ {len(failed)} test(s) failed: {failed}")
        sys.exit(1)
    else:
        print(f"✅ All {len(tests)} smoke tests passed")
