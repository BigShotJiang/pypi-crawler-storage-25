"""
runtime/policy.py — 工具权限策略引擎

职责：
    提供可复用的最小策略层，将工具本地校验（validate_input）与
    全局权限治理（check_permissions）分开。PolicyEngine 作为可注入
    的策略对象，由 RuntimeTool.__init__ 接收，在 check_permissions
    默认实现中委托调用。

    DefaultPolicyEngine 实现 v1.5 范围：
        - read_roots / write_roots 读写分离路径限制
        - deny_globs 用户自定义禁止模式匹配
        - ask_globs 需要人工确认的敏感路径模式（headless 时降级为 deny）
        - enable_builtin_deny 内置危险路径黑名单（.env/.ssh/*.key 等）
        - read_only_mode 全局只读
        - allow / deny / ask 三种决策

    决策优先级（严格顺序）：
        [1] read_only_mode + is_destructive → deny
        [2] enable_builtin_deny → 内置黑名单 → deny
        [3] deny_globs 命中 → deny
        [4] ask_globs 命中 → ask（headless 模式下由 pipeline 降级为 deny）
        [5] 读写分权：is_read_only → read_roots；否则 → write_roots
        [6] 通过 → allow

与 CC 对比：
    CC 的权限系统分三层：
        Layer 1: 每个工具的 checkPermissions()
        Layer 2: hasPermissionsToUseToolInner() 全局引擎
                 alwaysDenyRules → alwaysAskRules → alwaysAllowRules → PermissionMode
        Layer 3: HITL race（User UI + Hooks + Classifier + Bridge）
    本框架 v1.5 实现 Layer 1 + Layer 2 完整版：
        - deny_globs + BUILTIN_DENY_GLOBS 对应 CC alwaysDenyRules
        - ask_globs 对应 CC alwaysAskRules（需人工确认路径）
        - read_roots / write_roots 对应 CC allWorkingDirectories
        - headless 模式 ask → deny 对应 CC shouldAvoidPermissionPrompts
        - HITL 交互（Layer 3 完整 race）延期到 v2

    详细设计见 docs/design-docs/tool-runtime/tool-permission-system.md
"""

from __future__ import annotations

import fnmatch
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .models import AuthorizationDecision, ToolExecutionContext
from .permission_context import get_active_auto_approved_tools

if TYPE_CHECKING:
    from langchain_agentx.workspace.capabilities import RuntimeCapabilities


# ---------------------------------------------------------------------------
# ToolPolicyConfig
# ---------------------------------------------------------------------------

@dataclass
class ToolPolicyConfig:
    """
    工具策略配置。

    read_roots:         允许读操作的路径根列表（read/glob/grep 等只读工具）。
                        空列表 = 不限制（开发模式）。
    write_roots:        允许写操作的路径根列表（write/edit/bash 等写工具）。
                        通常是 read_roots 的子集。空列表 = 不限制（开发模式）。
    deny_globs:         硬拒绝的 glob 模式列表，优先级高于 roots 检查。
                        对应 CC alwaysDenyRules。
                        示例：["**/secrets/**", "**/*.prod.env"]
    ask_globs:          需要人工确认的敏感路径 glob 模式列表。
                        对应 CC alwaysAskRules。
                        headless 模式下自动降级为 deny；交互模式下触发 HITL。
                        示例：["**/config/**", "**/.claude/**"]
    read_only_mode:     全局只读模式，is_destructive=True 的工具直接拒绝。
    enable_builtin_deny: 启用内置危险路径保护（.env/.ssh/*.key/credentials 等）。
                        生产环境建议保持 True。
    """

    read_roots: list[str] = field(default_factory=list)
    write_roots: list[str] = field(default_factory=list)
    deny_globs: list[str] = field(default_factory=list)
    ask_globs: list[str] = field(default_factory=list)
    read_only_mode: bool = False
    enable_builtin_deny: bool = True

    def with_infrastructure_paths(
        self,
        capabilities: "RuntimeCapabilities",
    ) -> "ToolPolicyConfig":
        """追加基础设施写路径（memory_dir、sessions_dir）到 read/write_roots。

        用于 workflow 场景：节点 workspace_root 与全局 agent_home_dir 不同时，
        agent 需要写 memory/session 文件，这些路径必须在 write_roots 内。
        """
        home_dir = (capabilities.primary_workspace_root / capabilities.primary_agent_home).resolve()
        defaults = capabilities.defaults
        infra_paths = [
            str(defaults.default_memory_dir or (home_dir / "memory")),
            str(defaults.default_sessions_dir or (home_dir / "sessions")),
        ]

        new_read = list(self.read_roots)
        new_write = list(self.write_roots)
        for p in infra_paths:
            if p not in new_read:
                new_read.append(p)
            if p not in new_write:
                new_write.append(p)

        return ToolPolicyConfig(
            read_roots=new_read,
            write_roots=new_write,
            deny_globs=self.deny_globs,
            ask_globs=self.ask_globs,
            read_only_mode=self.read_only_mode,
            enable_builtin_deny=self.enable_builtin_deny,
        )


# ---------------------------------------------------------------------------
# PolicyEngine 抽象基类
# ---------------------------------------------------------------------------

class PolicyEngine(ABC):
    """
    权限策略引擎抽象基类。

    由 RuntimeTool.check_permissions() 默认实现委托调用。
    子类实现 authorize() / aauthorize() 提供具体策略决策。
    """

    @abstractmethod
    def authorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """同步授权决策。"""
        ...

    async def aauthorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        """
        异步授权决策，默认委托同步 authorize()。
        有真正异步需求（如远程策略服务）的子类可覆盖。
        """
        return self.authorize(tool_name=tool_name, input_data=input_data, ctx=ctx)


# ---------------------------------------------------------------------------
# DefaultPolicyEngine — v1 实现
# ---------------------------------------------------------------------------

class DefaultPolicyEngine(PolicyEngine):
    """
    v1.5 默认策略引擎。

    决策优先级（严格顺序）：
        [1] read_only_mode + is_destructive → deny      最高优先级
        [2] enable_builtin_deny → BUILTIN_DENY_GLOBS → deny
        [3] deny_globs 命中 → deny
        [4] ask_globs 命中 → ask（headless 时 pipeline 降级为 deny）
        [5] 读写分权：
              is_read_only=True  → 检查 read_roots
              is_read_only=False → 检查 write_roots
              roots 为空列表 → 跳过，视为不限制
        [6] 通过 → allow

    对应 CC：
        [1] ~ read_only_mode（全局禁止写操作）
        [2][3] ~ alwaysDenyRules（固定拒绝）
        [4] ~ alwaysAskRules（需确认）
        [5] ~ allWorkingDirectories（访问空间限制）

    工具读写标志来源：
        从 ctx.tool_flags["is_read_only"] / ctx.tool_flags["is_destructive"] 读取。
        由 LangChainAdapter.build_tool_execution_context() 在构造 ctx 时注入。

    路径提取规则：
        从 input_data 中按优先级查找路径字段：file_path > path > pattern
        找不到路径字段时跳过路径相关检查（直接 allow）。

    路径校验：
        使用 realpath 双检（对 path 和 root 均做 realpath），
        防路径遍历（../）、符号链接绕过、前缀误匹配。
    """

    # 按优先级尝试的路径字段名
    _PATH_FIELDS = ("file_path", "path", "pattern")

    # 内置危险路径黑名单，对应 CC 的危险目录/文件检查
    BUILTIN_DENY_GLOBS: list[str] = [
        # 环境变量 / 配置
        "**/.env", "**/.env.*", "**/*.env",
        # SSH 密钥
        "**/id_rsa", "**/id_rsa.pub", "**/id_ed25519", "**/id_ed25519.pub",
        "**/.ssh/**",
        # 证书与密钥文件
        "**/*.pem", "**/*.key", "**/*.p12", "**/*.pfx",
        # 云服务凭证
        "**/.aws/credentials", "**/.aws/config",
        "**/.gcp/**", "**/service-account*.json",
        # 密码/密钥目录
        "**/secrets/**", "**/.secrets/**", "**/credentials/**",
    ]

    def __init__(self, config: ToolPolicyConfig) -> None:
        self._config = config
        self._read_roots = [os.path.realpath(r) for r in config.read_roots]
        self._write_roots = [os.path.realpath(r) for r in config.write_roots]

    def authorize(
        self,
        *,
        tool_name: str,
        input_data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        tool_flags = ctx.tool_flags if hasattr(ctx, "tool_flags") else {}
        is_destructive = tool_flags.get("is_destructive", False)
        is_read_only_tool = tool_flags.get("is_read_only", True)
        active_auto_approved_tools = get_active_auto_approved_tools(
            getattr(ctx, "session_store", None)
        )
        active_auto_approved_tools_lower = {
            name.lower() for name in active_auto_approved_tools
        }

        # [1] 全局只读模式：拒绝破坏性工具
        if self._config.read_only_mode and is_destructive:
            return self._with_decision_source(
                AuthorizationDecision(
                behavior="deny",
                message="Operation not permitted: agent is in read-only mode.",
                policy_id="read_only_mode",
                ),
                matched_rule="read_only_mode",
            )

        # Bash 工具按“命令字符串”做规则匹配，不参与路径 roots 校验。
        # 对齐 docs/design-docs/tool-design/bash-tool.md 的 v2 方案。
        if tool_name == "bash":
            command = input_data.get("command")
            if not isinstance(command, str) or not command.strip():
                return AuthorizationDecision(behavior="allow")

            deny_result = self._check_deny_globs(command)
            if deny_result is not None:
                return self._with_decision_source(
                    deny_result,
                    matched_rule=deny_result.policy_id,
                )

            ask_result = self._check_ask_globs(command)
            if ask_result is not None:
                return self._with_decision_source(
                    ask_result,
                    matched_rule=ask_result.policy_id,
                )

            return self._with_decision_source(
                AuthorizationDecision(behavior="allow"),
                matched_rule="default_allow",
            )

        # 提取并规范化路径字段
        path = self._extract_path(input_data)
        if path is None:
            return self._with_decision_source(
                AuthorizationDecision(behavior="allow"),
                matched_rule="no_path_field",
            )

        real_path = os.path.realpath(os.path.expanduser(path))

        # [2] 用户自定义 deny_globs
        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return self._with_decision_source(
                deny_result,
                matched_rule=deny_result.policy_id,
            )

        # [3] 内置危险路径黑名单
        if self._config.enable_builtin_deny:
            for pattern in self.BUILTIN_DENY_GLOBS:
                if fnmatch.fnmatch(real_path, pattern):
                    return self._with_decision_source(
                        AuthorizationDecision(
                            behavior="deny",
                            message="Permission denied: access to this path is not allowed.",
                            policy_id="builtin_deny",
                        ),
                        matched_rule="builtin_deny",
                    )

        # [4] ask_globs：敏感路径需要人工确认
        # headless 模式下 pipeline 会将 ask 自动降级为 deny；交互模式触发 HITL
        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            if tool_name.lower() in active_auto_approved_tools_lower:
                decision = AuthorizationDecision(
                    behavior="allow",
                    policy_id="skill_auto_approved_bypass_ask",
                    metadata={
                        "tool_name": tool_name,
                        "source": "skill_allowed_tools",
                        "decision_trace": [
                            {
                                "stage": "ask_globs",
                                "matched": True,
                                "decision": "allow",
                                "reason": "skill_auto_approved_bypass_ask",
                                "tool_name": tool_name,
                                "active_auto_approved_tools": sorted(active_auto_approved_tools),
                            }
                        ],
                    },
                )
                return self._with_decision_source(
                    decision,
                    matched_rule="skill_auto_approved_bypass_ask",
                )
            return self._with_decision_source(
                ask_result,
                matched_rule=ask_result.policy_id,
            )

        # [5] 读写分权根目录检查
        roots = self._read_roots if is_read_only_tool else self._write_roots
        if roots:
            if not any(self._within_root(real_path, r) for r in roots):
                return self._with_decision_source(
                    AuthorizationDecision(
                        behavior="deny",
                        message="Permission denied: path is outside the allowed workspace.",
                        policy_id="read_roots" if is_read_only_tool else "write_roots",
                    ),
                    matched_rule="read_roots" if is_read_only_tool else "write_roots",
                )

        return self._with_decision_source(
            AuthorizationDecision(behavior="allow"),
            matched_rule="default_allow",
        )

    def authorize_path(
        self,
        path: str,
        *,
        is_write: bool,
    ) -> AuthorizationDecision:
        """
        对单个文件系统路径做授权。

        供 BashRuntimeTool v2 的路径安全层调用，避免 bash 因 command-string
        特殊分支而跳过 read_roots / write_roots / builtin deny 检查。
        """
        real_path = os.path.realpath(os.path.expanduser(path))

        if self._config.read_only_mode and is_write:
            return self._with_decision_source(
                AuthorizationDecision(
                behavior="deny",
                message="Operation not permitted: agent is in read-only mode.",
                policy_id="read_only_mode",
                ),
                matched_rule="read_only_mode",
            )

        deny_result = self._check_deny_globs(real_path)
        if deny_result is not None:
            return self._with_decision_source(
                deny_result,
                matched_rule=deny_result.policy_id,
            )

        if self._config.enable_builtin_deny:
            for pattern in self.BUILTIN_DENY_GLOBS:
                if fnmatch.fnmatch(real_path, pattern):
                    return self._with_decision_source(
                        AuthorizationDecision(
                        behavior="deny",
                        message="Permission denied: access to this path is not allowed.",
                        policy_id="builtin_deny",
                        ),
                        matched_rule="builtin_deny",
                    )

        ask_result = self._check_ask_globs(real_path)
        if ask_result is not None:
            return self._with_decision_source(
                ask_result,
                matched_rule=ask_result.policy_id,
            )

        roots = self._write_roots if is_write else self._read_roots
        if roots:
            if not any(self._within_root(real_path, root) for root in roots):
                return self._with_decision_source(
                    AuthorizationDecision(
                        behavior="deny",
                        message="Permission denied: path is outside the allowed workspace.",
                        policy_id="write_roots" if is_write else "read_roots",
                    ),
                    matched_rule="write_roots" if is_write else "read_roots",
                )

        return self._with_decision_source(
            AuthorizationDecision(behavior="allow"),
            matched_rule="default_allow",
        )

    # ---- 内部辅助 ----

    def _extract_path(self, input_data: dict[str, Any]) -> str | None:
        for field_name in self._PATH_FIELDS:
            val = input_data.get(field_name)
            if isinstance(val, str) and val:
                return val
        return None

    def _check_deny_globs(self, real_path: str) -> AuthorizationDecision | None:
        for glob_pattern in self._config.deny_globs:
            if fnmatch.fnmatch(real_path, glob_pattern):
                return AuthorizationDecision(
                    behavior="deny",
                    message="Permission denied: path matches a restricted pattern.",
                    policy_id=f"deny_glob:{glob_pattern}",
                )
        return None

    @staticmethod
    def _with_decision_source(
        decision: AuthorizationDecision,
        *,
        matched_rule: str | None,
    ) -> AuthorizationDecision:
        meta = dict(decision.metadata or {})
        meta.setdefault("rule_source", "default_policy_engine")
        if matched_rule is not None:
            meta.setdefault("matched_rule", matched_rule)
        decision.metadata = meta
        return decision

    def _check_ask_globs(self, real_path: str) -> AuthorizationDecision | None:
        """
        检查路径是否命中 ask_globs（需要人工确认的敏感路径）。
        命中时返回 behavior="ask"，由 pipeline 根据 headless 标志决定后续处理：
            headless=True  → pipeline 自动降级为 deny
            headless=False → pipeline 抛出 PermissionAskInterrupt
        """
        for glob_pattern in self._config.ask_globs:
            if fnmatch.fnmatch(real_path, glob_pattern):
                return AuthorizationDecision(
                    behavior="ask",
                    ask_prompt=(
                        f"Tool wants to access a sensitive path: {real_path}\n"
                        f"(matched pattern: {glob_pattern})\n"
                        f"Allow this operation?"
                    ),
                    policy_id=f"ask_glob:{glob_pattern}",
                )
        return None

    @staticmethod
    def _within_root(path: str, root: str) -> bool:
        """
        判断 path 是否在 root 目录内。
        root 已在 __init__ 中 realpath，path 在调用前已 realpath，
        使用 os.sep 边界确保不会前缀误匹配（如 /proj 不会匹配 /proj_evil）。
        """
        return path == root or path.startswith(root.rstrip(os.sep) + os.sep)
