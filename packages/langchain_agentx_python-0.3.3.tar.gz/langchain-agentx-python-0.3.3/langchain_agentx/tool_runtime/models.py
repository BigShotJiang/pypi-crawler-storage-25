"""
runtime/models.py — 工具运行时框架核心数据模型

职责：
    定义框架内部所有稳定的数据契约（Named Spec），包括：
    - ToolExecutionContext：运行时归一化上下文，隔离 LangGraph 底层依赖
    - ToolResultEnvelope：工具执行统一内部结果协议，分离模型可见输出与内部数据
    - ValidationResult：输入语义校验结果（失败时告知模型，模型可修正重试）
    - AuthorizationDecision：权限授权决策（失败时策略拒绝，不可绕过）
    - ToolErrorInfo / ToolHint / ToolArtifact：辅助结构

与 CC 对比：
    CC Tool.ts 中 ToolUseContext 是一个大而全的上下文对象，包含 abortController、
    readFileState、getAppState、messages 等大量 UI/应用层字段。
    本框架的 ToolExecutionContext 只保留框架稳定依赖的最小字段集，
    UI/应用层依赖由 LangChainAdapter 在边界处消费，不透传到工具内部。
    ``session_store``（AgentSessionStore）为会话级工具态后端，供 ToolStateBridge 等读写。
    协作取消：``cancel_event`` 对应 CC ``AbortSignal``（由上层 ``set()`` 终止 ripgrep 等子进程）。

    CC 的 ValidationResult / PermissionResult 是 TypeScript union type。
    本框架用 dataclass 实现等价语义，保持 Python 风格。
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, MutableMapping


from .session_store import AgentSessionStore


# ---------------------------------------------------------------------------
# ToolExecutionContext
# ---------------------------------------------------------------------------

@dataclass
class ToolExecutionContext:
    """
    运行时归一化上下文。

    由 LangChainAdapter.build_tool_execution_context() 从 RunnableConfig 构造，
    隔离 LangGraph / RunnableConfig 等底层依赖，工具内部只依赖此对象。

    字段来源：
        tool_name       — RuntimeTool.name
        tool_call_id    — RunnableConfig.configurable["tool_call_id"]
        input_args      — 归一化后的输入 dict
        state           — LangGraph state 引用（工具可读写）
        now_ts          — pipeline 入口时间戳
        thread_id       — RunnableConfig.configurable.get("thread_id")
        run_id          — RunnableConfig.configurable.get("run_id")
        actor           — 当前版本固定 "agent"
        tool_flags      — 工具行为标志（由 LangChainAdapter 从 RuntimeTool 类属性注入）
                          {"is_read_only": bool, "is_destructive": bool}
                          PolicyEngine 从此处读取读写属性，不污染 input_data。

    父 loop 控制面（由 LangChainAdapter 从 RunnableConfig.configurable["loop_config"] 填充，工具层只读）：
        model           — 父 loop 当前模型，子代理继承的 SSOT；对应 CC options.mainLoopModel
                          来源：AgentLoopConfig.model
        available_tools — 父工具池视图，子代理工具池组装的基础；对应 CC options.tools
                          来源：AgentLoopConfig.available_tools
        agent_id        — 当前 agent ID，用于日志与追踪；对应 CC agentId
                          来源：state["agent_id"]
        agent_depth     — 嵌套深度，防止无限递归；对应 CC queryTracking.depth
                          来源：state["agent_depth"]
    """

    tool_name: str
    tool_call_id: str | None
    input_args: dict[str, Any]
    state: MutableMapping[str, Any]
    now_ts: float = field(default_factory=time.time)
    thread_id: str | None = None
    run_id: str | None = None
    session_id: str | None = None
    conversation_session_id: str | None = None
    actor: Literal["agent", "human", "system"] = "agent"
    session_store: AgentSessionStore | None = field(default=None)
    tool_loader: Any | None = None
    tool_registry: Any | None = None
    tool_flags: dict[str, Any] = field(default_factory=dict)
    """
    工具行为标志，由 LangChainAdapter.build_tool_execution_context() 注入。
    标准键：
        is_read_only    — 对应 RuntimeTool.is_read_only
        is_destructive  — 对应 RuntimeTool.is_destructive
    PolicyEngine.authorize() 从此处读取，避免污染 input_data。
    """
    # 父 loop 控制面
    model: Any | None = None
    available_tools: list[Any] = field(default_factory=list)
    agent_id: str | None = None
    agent_depth: int = 0
    workspace_root: str | None = None
    agent_home: str = ".langchain_agentx"
    cwd: str | None = None  # 工具执行时的路径基准（CC 对照：getCwd()）
    trace_enabled: bool = True
    cancel_event: threading.Event | None = None
    """可选；由 ``RunnableConfig.configurable[\"cancel_event\"]`` 注入。set 后 Grep/Glob 应中断 rg。"""
    tool_config_path: str | None = None
    """可选；`LangChainAdapter` 由 workspace 解析的 `tool_runtime_config.json` 绝对路径（UserMessage v2+）。"""
    channels: set[str] | None = None
    """可选；当前激活渠道（如 ``{"cli"}`` / ``{"discord"}``），供 AskUserQuestion 等工具禁用无 TUI 场景。"""
    trace_collector: Any | None = None
    """可选；来自 graph state / configurable 的 `TraceCollector`，供 pipeline 发 `user_message_send`。"""
    trace_emit_session_id: str | None = None
    """可选；`emit_event(session_id=...)` 用，与 Trace 会话键（常为 `_run_id`）对齐。"""
    question_preview_format: Literal["markdown", "html"] | None = None
    """
    可选；宿主经 ``RunnableConfig.configurable["question_preview_format"]`` 注入，
    取值为 ``markdown`` 或 ``html``，供 AskUserQuestion v3 对 ``preview`` 做 HTML 校验门控。
    """
    capabilities: Any | None = None
    """可选；RuntimeCapabilities 实例，供子 Agent 继承全局 model_profile_registry。"""
    network_access_allowed: bool = True
    """为 False 时 WebSearch 等外网工具应在 check_permissions 中 deny。"""
    tool_progress_callback: Any | None = None
    """
    可选；``RunnableConfig.configurable["tool_progress_callback"]`` 或 AgentLoopConfig 注入。
    签名为 ``(event: ProgressEvent) -> None``（具体类型由工具包定义，避免 runtime 循环依赖）。
    """


# ---------------------------------------------------------------------------
# 辅助结构
# ---------------------------------------------------------------------------

@dataclass
class ToolErrorInfo:
    """工具执行错误细节，附在 ToolResultEnvelope.error 上。"""

    message: str
    code: str | None = None
    exception_type: str | None = None
    traceback: str | None = None


@dataclass
class ToolHint:
    """
    下一步操作提示，面向模型。

    例如：ReadRuntimeTool 在文件被截断时提示模型用更大的 offset 继续读取。
    suggested_action 可携带建议的工具调用参数，提高模型遵从率。
    """

    message: str
    suggested_action: dict[str, Any] | None = None


@dataclass
class ToolArtifact:
    """
    工具产出的文件 / 媒体引用。

    对应 CC 的 content_and_artifact response_format，
    模块 5 起可用于承载 Bash 图片输出等结构化媒体结果。
    """

    uri: str
    media_type: str
    description: str | None = None


@dataclass
class ToolContentBlock:
    """
    结构化结果块（P1 协议升级）。

    type:
        - text: 普通文本
        - image: 图片（结合 artifact uri）
        - status: 状态信息（task/sandbox）
        - reference: 大输出文件引用
    """

    type: Literal["text", "image", "status", "reference"]
    text: str | None = None
    uri: str | None = None
    media_type: str | None = None
    meta: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# ToolResultEnvelope
# ---------------------------------------------------------------------------

@dataclass
class ToolResultEnvelope:
    """
    工具运行时统一内部结果协议。

    框架内部始终使用此结构传递工具执行结果。
    LangChainAdapter.envelope_to_tool_output() 负责将其映射为
    LangChain ToolMessage.content 字符串，meta 默认不进入模型上下文。

    字段说明：
        status          — ok / blocked / error
        tool_name       — 工具名
        summary         — 面向模型的简短结论（必须进入模型上下文）
        payload         — 主体数据（经映射后进入模型）
        artifacts       — 文件/媒体引用（v1 预留，默认 None）
        hints           — 下一步提示（进入模型）
        meta            — 审计/性能信息（不进入模型）
        error           — 错误细节（error 场景必须填写）
        truncated       — 输出是否被 ToolOutputManager 截断
        overflow_file   — 超大输出的持久化文件路径（截断时填写，告知模型）
    """

    status: Literal["ok", "blocked", "error"]
    tool_name: str
    summary: str
    payload: dict[str, Any] | str | None = None
    blocks: list[ToolContentBlock] | None = None
    artifacts: list[ToolArtifact] | None = None
    hints: list[ToolHint] | None = None
    meta: dict[str, Any] | None = None
    error: ToolErrorInfo | None = None
    truncated: bool = False
    overflow_file: str | None = None


# ---------------------------------------------------------------------------
# ValidationResult
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """
    输入语义校验结果，由 RuntimeTool.validate_input() 返回。

    ok=False 时，pipeline 短路并生成 status="error" 的 envelope。
    模型会收到 message，可据此修正输入后重试。

    与 CC 对比：
        CC validateInput 返回 ValidationResult = { result: "success" } | { result: "error", message }
        本框架等价语义，额外增加 code（稳定错误码）和 normalized_input（校验阶段回写归一化输入）。
    """

    ok: bool
    message: str | None = None
    code: str | None = None
    normalized_input: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# AuthorizationDecision
# ---------------------------------------------------------------------------

@dataclass
class AuthorizationDecision:
    """
    权限授权决策，由 RuntimeTool.check_permissions() 返回。

    behavior 语义：
        "allow"  — 放行，继续执行
        "deny"   — 策略拒绝，pipeline 短路返回 status="blocked" envelope，不可绕过
        "ask"    — 需要人工确认（HITL）：
                   · headless 模式（ToolRuntimeLoader(headless=True)）：pipeline 自动降级为 deny
                   · 交互模式：pipeline 抛出 PermissionAskInterrupt，
                     由 LangGraph checkpointer + HumanInTheLoopMiddleware 处理

    ask_prompt: 展示给用户的确认提示文本（headless 时忽略）。
    updated_input: 策略层在授权时回写修正后的输入（如路径规范化），
                   对应 CC PermissionAllowDecision.updatedInput。
    metadata: 可选结构化扩展（如 bash 攻防 rule_code、审计快照），便于观测与 UI 对齐 CC。

    与 CC 对比：
        CC checkPermissions 返回 PermissionResult，包含 allow / ask / deny / passthrough。
        本框架 v1.5 实现 allow / deny / ask 三种行为：
            - headless=True 时 ask → deny（对应 CC shouldAvoidPermissionPrompts）
            - headless=False 时 ask → PermissionAskInterrupt（对应 CC HITL race）
    """

    behavior: Literal["allow", "deny", "ask"]
    message: str | None = None
    policy_id: str | None = None
    updated_input: dict[str, Any] | None = None
    ask_prompt: str | None = None
    metadata: dict[str, Any] | None = None
