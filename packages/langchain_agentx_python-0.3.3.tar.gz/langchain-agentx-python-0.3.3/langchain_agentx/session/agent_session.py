"""
session/agent_session.py — 进程级 Session 生命周期容器。

职责：
    负责触发进程级 SESSION_START/SESSION_END，封装多次 loop invoke，并维护跨 loop 状态。

链路位置：
    作为 Agent Loop 外层容器供 CLI/应用复用，对应 A01/A03 约定的 LoopContainer 协议。

当前裁剪范围：
    当前实现覆盖最小生命周期与 active_files 累积；memory manager 通过注入方式可选接入。
"""

from __future__ import annotations

import inspect
import logging
import time
from uuid import uuid4
from typing import Any, AsyncIterator, Callable

from langchain_core.messages import HumanMessage
from langgraph.graph.state import CompiledStateGraph

from ..command import CommandContext, CommandDispatcher, CommandRegistry
from ..command.builtin import (
    make_clear_command,
    make_compact_command,
    make_memory_command,
    make_reload_plugins_command,
)
from ..loop.config import merge_run_config
from ..loop.context.compaction_service import default_loop_context_compaction
from ..loop.context.message_utils import total_estimated_tokens_for_messages
from ..loop.hook.types import HookContext, HookEvent
from ..memory.memdir.agent_memory import drain_pending_agent_memory_extraction
from ..memory.memdir.extractor import drain_pending_extraction
from ..plugin.loader import PluginLoader
from ..plugin.registries import AgentRegistry, CommandRegistry as PluginCommandRegistry, SkillRegistry
from ..plugin.types import PluginLoadResult
from ..loop.subagent.transcript import SubagentTranscriptStore
from ..workspace import RuntimeCapabilities
from ..workspace.config import AgentWorkspaceConfig

logger = logging.getLogger(__name__)


class AgentSession:
    """进程级 session 容器。"""

    def __init__(
        self,
        graph: CompiledStateGraph | None,
        session_id: str,
        workspace_cfg: AgentWorkspaceConfig,
        hook_engine: Any,
        *,
        graph_factory: Callable[..., CompiledStateGraph] | None = None,
        plugin_loader: PluginLoader | None = None,
        transcript_writer: SubagentTranscriptStore | None = None,
        container_type: str = "interactive",
        enable_trace: bool = True,
        capabilities: RuntimeCapabilities | None = None,
    ) -> None:
        self._graph = graph
        self._graph_factory = graph_factory
        self._session_id = session_id
        self._workspace_cfg = workspace_cfg
        self._hook_engine = hook_engine
        self._active_files: list[str] = []
        self._messages: list[Any] = []
        self._container_type = container_type
        self._enable_trace = enable_trace
        self._transcript_writer = transcript_writer
        self._last_transcript_uuid: str | None = None
        self._session_memory_manager: Any | None = None
        self._capabilities = capabilities or RuntimeCapabilities.build(
            primary_workspace_root=workspace_cfg.workspace_root,
            primary_agent_home=workspace_cfg.agent_home,
        )
        self._skill_registry = SkillRegistry()
        self._command_registry = PluginCommandRegistry()
        self._agent_registry = AgentRegistry()
        self._runtime_command_registry = CommandRegistry()
        self._register_builtin_commands()
        self._dispatcher = CommandDispatcher(
            self._runtime_command_registry,
            plugin_command_registry=self._command_registry,
        )
        self._plugin_loader: PluginLoader | None
        if not workspace_cfg.plugins_enabled:
            self._plugin_loader = None
        else:
            self._plugin_loader = plugin_loader or PluginLoader(
                workspace_config=workspace_cfg,
                hook_engine=hook_engine,
                skill_registry=self._skill_registry,
                command_registry=self._command_registry,
                agent_registry=self._agent_registry,
            )

    async def __aenter__(self) -> "AgentSession":
        if self._graph is None:
            self._graph = self._build_graph()
        if self._plugin_loader is not None:
            load_result = await self._plugin_loader.load_all(container_type="interactive")
            load_result.log_errors(logger)
        await self._execute_hook(HookEvent.SESSION_START)
        return self

    async def __aexit__(self, *_) -> None:
        if self._session_memory_manager is not None:
            await self._session_memory_manager.drain(timeout=30.0)
        await drain_pending_extraction(timeout_ms=60_000)
        await drain_pending_agent_memory_extraction(timeout_ms=60_000)
        await self._execute_hook(HookEvent.SESSION_END)
        if self._plugin_loader is not None:
            await self._plugin_loader.unload_all()

    async def run_loop(self, user_input: str) -> dict[str, Any]:
        if self._graph is None:
            raise RuntimeError("AgentSession graph is not initialized")
        appended_message = HumanMessage(content=user_input)
        self._messages.append(appended_message)
        baseline_count = len(self._messages)
        run_config = merge_run_config(self._graph, None)
        try:
            result = await self._graph.ainvoke(
                {
                    "messages": list(self._messages),
                    "_session_id": self._session_id,
                },
                config=run_config,
            )
        except Exception:
            # 回滚本轮 append，避免异常路径重复累积 user 消息。
            if self._messages and self._messages[-1] is appended_message:
                self._messages.pop()
            raise
        if isinstance(result, dict) and isinstance(result.get("messages"), list):
            new_messages = list(result["messages"])
            self._messages = new_messages
            self._append_transcript_message(appended_message)
            for message in new_messages[baseline_count:]:
                self._append_transcript_message(message)
        self._active_files.extend(self._extract_accessed_files(result))
        return dict(result)

    async def stream_loop_events(
        self,
        user_input: str,
        *,
        config: dict[str, Any] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        流式执行一轮 loop，复用 AgentSession 的消息上下文。

        说明：
            该方法用于需要 astream_events 的场景（如 SSE），执行完成后会尝试
            从 on_chain_end(LangGraph) 事件回填消息列表，保持与 run_loop 一致的上下文累积语义。
        """
        if self._graph is None:
            raise RuntimeError("AgentSession graph is not initialized")
        appended_message = HumanMessage(content=user_input)
        self._messages.append(appended_message)
        baseline_count = len(self._messages)
        output_messages: list[Any] | None = None
        run_config = merge_run_config(self._graph, config)
        try:
            async for event in self._graph.astream_events(
                {
                    "messages": list(self._messages),
                    "_session_id": self._session_id,
                },
                config=run_config,
                version="v2",
            ):
                if event.get("event") == "on_chain_end" and event.get("name") == "LangGraph":
                    data = event.get("data", {}) or {}
                    output = data.get("output")
                    if isinstance(output, dict) and isinstance(output.get("messages"), list):
                        output_messages = list(output["messages"])
                yield event
        except Exception:
            if self._messages and self._messages[-1] is appended_message:
                self._messages.pop()
            raise
        if output_messages is not None:
            self._messages = output_messages
            self._append_transcript_message(appended_message)
            for message in output_messages[baseline_count:]:
                self._append_transcript_message(message)

    @property
    def active_files(self) -> list[str]:
        return list(self._active_files)

    @property
    def dispatcher(self) -> CommandDispatcher:
        return self._dispatcher

    def clear_context(self) -> None:
        self._messages.clear()

    async def compact_context(
        self, *, progress_callback: Any = None
    ) -> tuple[int, int]:
        """压缩会话上下文，可选传入进度回调。

        参数:
            progress_callback: 可选的进度回调函数，接收 CompactProgress 对象

        返回:
            (before_tokens, after_tokens) 元组
        """
        before_tokens = total_estimated_tokens_for_messages(self._messages, num_chars_per_token=4)
        # 注意：model=None 表示不使用 LLM 摘要，仅走 prune 路径
        # 如果需要 LLM 摘要，调用方需要通过其他方式提供 model
        patch = await default_loop_context_compaction().arun(
            {"messages": self._messages},
            model=None,
            progress_callback=progress_callback,
        )
        if isinstance(patch.get("messages"), list):
            self._messages = list(patch["messages"])
        after_tokens = total_estimated_tokens_for_messages(self._messages, num_chars_per_token=4)
        if self._transcript_writer is not None:
            self._append_compact_boundary(before_tokens=before_tokens, after_tokens=after_tokens)
        return before_tokens, after_tokens

    async def reload_plugins(self) -> PluginLoadResult:
        if self._plugin_loader is None:
            return PluginLoadResult(enabled=[], errors=[])
        result = await self._plugin_loader.reload(container_type=self._container_type)
        result.log_errors(logger)
        return result

    def get_memory_summary(self, sub_cmd: str = "show") -> str:
        memory_path = self._workspace_cfg.session_memory_path(self._session_id)
        if sub_cmd == "clear":
            if memory_path.exists():
                memory_path.unlink()
            return "记忆已清除"
        if not memory_path.exists():
            return "（暂无记忆摘要）"
        content = memory_path.read_text(encoding="utf-8").strip()
        return content or "（暂无记忆摘要）"

    def _build_context(self) -> CommandContext:
        return CommandContext(
            session_id=self._session_id,
            session=self,
            workspace_cfg=self._workspace_cfg,
            hook_engine=self._hook_engine,
            plugin_loader=self._plugin_loader,
            extra={"container_type": self._container_type},
        )

    async def dispatch_command(self, user_input: str):
        return await self._dispatcher.dispatch(user_input, self._build_context())

    def list_commands(self) -> list[dict[str, object]]:
        return self._runtime_command_registry.list_for_help()

    async def _execute_hook(self, event: HookEvent) -> None:
        ctx = HookContext(event=event, state={}, session_id=self._session_id)
        # HookEngine 当前主接口是 execute；若未来扩展 execute_async，优先兼容新接口。
        execute_async = getattr(self._hook_engine, "execute_async", None)
        if callable(execute_async):
            async_out = execute_async(ctx)
            if inspect.isawaitable(async_out):
                await async_out
            # 一旦存在 execute_async，就不再回落执行 execute，避免双执行歧义。
            return
        execute = getattr(self._hook_engine, "execute", None)
        if not callable(execute):
            return
        out = execute(ctx)
        if inspect.isawaitable(out):
            await out

    @staticmethod
    def _extract_accessed_files(result: Any) -> list[str]:
        if not isinstance(result, dict):
            return []
        files = result.get("_accessed_files")
        if not isinstance(files, list):
            return []
        return [item for item in files if isinstance(item, str)]

    def _build_graph(self) -> CompiledStateGraph:
        if self._graph_factory is None:
            raise RuntimeError("AgentSession requires either graph or graph_factory")
        getter = lambda: list(self._active_files)
        return self._graph_factory(
            active_files_getter=getter,
            container_type=self._container_type,
            enable_trace=self._enable_trace,
            capabilities=self._capabilities,
        )

    def _append_transcript_message(self, message: Any) -> None:
        if self._transcript_writer is None:
            return
        record = self._serialize_message_for_transcript(message)
        self._append_transcript_record(record)

    def _append_compact_boundary(self, *, before_tokens: int, after_tokens: int) -> None:
        record = {
            "type": "compact_boundary",
            "summary": f"compacted context {before_tokens}->{after_tokens}",
        }
        self._append_transcript_record(record)

    def _append_transcript_record(self, payload: dict[str, Any]) -> None:
        if self._transcript_writer is None:
            return
        uuid = str(uuid4())
        record = {
            **payload,
            "uuid": uuid,
            "logical_parent_uuid": self._last_transcript_uuid,
            "ts": time.time(),
        }
        self._last_transcript_uuid = uuid
        self._transcript_writer.append_message(self._session_id, record)

    @staticmethod
    def _serialize_message_for_transcript(message: Any) -> dict[str, Any]:
        role = getattr(message, "type", type(message).__name__.lower())
        content = getattr(message, "content", "")
        if isinstance(content, list):
            normalized_content: Any = [str(item) for item in content]
        elif isinstance(content, str):
            normalized_content = content
        else:
            normalized_content = str(content)
        return {"type": str(role), "role": str(role), "content": normalized_content}

    def _register_builtin_commands(self) -> None:
        self._runtime_command_registry.register(make_clear_command())
        self._runtime_command_registry.register(make_compact_command())
        self._runtime_command_registry.register(make_memory_command())
        self._runtime_command_registry.register(make_reload_plugins_command())


__all__ = ["AgentSession"]
