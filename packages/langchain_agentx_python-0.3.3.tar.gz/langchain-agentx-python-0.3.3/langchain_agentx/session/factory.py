"""
session/factory.py — AgentSession 入口工厂。

职责：
    统一组装 AgentSession 所需的 graph_factory、workspace 配置与 session 级 hook_engine。

链路位置：
    作为上层应用（CLI/示例）创建 AgentSession 的便捷入口，底层仍复用 create_loop_agent。

当前裁剪范围：
    仅覆盖 session 级基础参数透传，不包含应用层交互循环。
"""

from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any
from uuid import uuid4

from langchain_core.language_models.chat_models import BaseChatModel

from ..loop.graph.factory import create_loop_agent
from ..loop.hook import HookEngine, HooksConfigSnapshot, HookRegistry, WorkspaceTrustChecker
from ..loop.subagent.transcript import SubagentTranscriptStore
from ..workspace import resolve_agent_workspace_config
from .agent_session import AgentSession


def create_agent_session(
    model: str | BaseChatModel,
    *,
    session_id: str | None = None,
    workspace_root: str | Path | None = None,
    agent_home: str | None = None,
    hooks: HookRegistry | None = None,
    hook_engine: Any | None = None,
    workspace_trust_prompter: Any | None = None,
    transcript_writer: SubagentTranscriptStore | None = None,
    container_type: str = "interactive",
    enable_trace: bool = True,
    **loop_kwargs: Any,
) -> AgentSession:
    """创建默认走 graph_factory 注入路径的 AgentSession。

    ``workspace_root`` / ``agent_home`` 为 ``None`` 时与 ``resolve_agent_workspace_config`` 默认链一致
    （环境变量 ``LANGCHAIN_AGENTX_*`` 与产品默认 ``.langchain_agentx``）。
    """
    resolved_session_id = session_id or f"session-{uuid4().hex}"
    workspace_cfg = resolve_agent_workspace_config(
        workspace_root=workspace_root,
        agent_home=agent_home,
    )
    workspace_trust_accepted = _resolve_workspace_trust_accepted(
        workspace_cfg=workspace_cfg,
        workspace_trust_prompter=workspace_trust_prompter,
    )
    workspace_cfg = replace(
        workspace_cfg,
        workspace_trust_accepted=workspace_trust_accepted,
    )
    if hook_engine is None:
        snapshot = hooks.build_snapshot() if hooks is not None else HooksConfigSnapshot()
        hook_engine = HookEngine(
            snapshot,
            trust_checker=WorkspaceTrustChecker(
                headless=_is_headless_container(container_type),
                workspace_trust_accepted=workspace_cfg.workspace_trust_accepted,
            ),
        )

    def _graph_factory(
        active_files_getter: Any = None,
        container_type: str = container_type,
        capabilities: Any = None,
        **_ignored: Any,
    ):
        return create_loop_agent(
            model,
            session_id=resolved_session_id,
            workspace_root=workspace_cfg.workspace_root,
            agent_home=workspace_cfg.agent_home,
            workspace_trust_accepted=workspace_cfg.workspace_trust_accepted,
            hooks=hooks,
            active_files_getter=active_files_getter,
            container_type=container_type,
            enable_trace=enable_trace,
            capabilities=capabilities,
            **loop_kwargs,
        )

    return AgentSession(
        graph=None,
        graph_factory=_graph_factory,
        session_id=resolved_session_id,
        workspace_cfg=workspace_cfg,
        hook_engine=hook_engine,
        transcript_writer=transcript_writer,
        container_type=container_type,
        enable_trace=enable_trace,
    )


__all__ = ["create_agent_session"]


def _resolve_workspace_trust_accepted(
    *,
    workspace_cfg,
    workspace_trust_prompter: Any | None,
) -> bool:
    persisted = _read_workspace_trust_flag(workspace_cfg)
    if persisted:
        return True
    if workspace_cfg.workspace_trust_accepted:
        return True
    if workspace_trust_prompter is None:
        return False
    accepted = bool(workspace_trust_prompter(workspace_cfg))
    if accepted:
        _write_workspace_trust_flag(workspace_cfg, accepted=True)
    return accepted


def _workspace_config_json_path(workspace_cfg) -> Path:
    return workspace_cfg.workspace_config_path


def _read_workspace_trust_flag(workspace_cfg) -> bool:
    path = _workspace_config_json_path(workspace_cfg)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return False
    return bool(data.get("workspace_trust_accepted"))


def _write_workspace_trust_flag(workspace_cfg, *, accepted: bool) -> None:
    path = _workspace_config_json_path(workspace_cfg)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"workspace_trust_accepted": bool(accepted)}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _is_headless_container(container_type: str) -> bool:
    return container_type in {"background", "batch", "worker", "sdk"}
