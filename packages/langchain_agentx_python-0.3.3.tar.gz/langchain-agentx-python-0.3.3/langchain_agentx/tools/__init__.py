"""
内置工具包（见 `docs/design-docs/tool-runtime/langchain-tool-runtime-framework.md`）。

工具体系实现状态：
    P1（已完成）：ReadRuntimeTool — 文本/图片/PDF/Notebook 读取
    P2（已完成）：GrepRuntimeTool / GlobRuntimeTool — 只读搜索工具
    P3（进行中）：WriteRuntimeTool；EditRuntimeTool — Phase 6 单测 + ``tools/`` 回归已跑通（需 ToolStateBridge + 先 Read）
    P4（已完成）：BashRuntimeTool
    P1 用户交互（已完成）：UserMessageTool — 用户可见消息（CC BriefTool）
"""

from .agent import AgentRuntimeTool
from .bash import BashRuntimeTool
from .glob import GlobRuntimeTool
from .grep import GrepRuntimeTool
from .read import ReadRuntimeTool
from .skill import SkillRuntimeTool
from .edit import BatchEditRuntimeTool, EditRuntimeTool
from .user_message import UserMessageTool
from .write import WriteRuntimeTool

__all__ = [
    "ReadRuntimeTool",
    "AgentRuntimeTool",
    "BashRuntimeTool",
    "GlobRuntimeTool",
    "GrepRuntimeTool",
    "SkillRuntimeTool",
    "WriteRuntimeTool",
    "EditRuntimeTool",
    "BatchEditRuntimeTool",
    "UserMessageTool",
]

