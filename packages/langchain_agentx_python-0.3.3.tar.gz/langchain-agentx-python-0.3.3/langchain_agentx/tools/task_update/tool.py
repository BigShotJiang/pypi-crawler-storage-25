"""TaskUpdateRuntimeTool — 任务更新工具。

职责：
    提供任务状态、详情、依赖关系的更新能力。

与 CC 对齐：
    - 状态流转：pending → in_progress → completed
    - 删除任务：status=deleted
    - 依赖管理：addBlocks/addBlockedBy
    - 元数据合并：metadata 字段
    - 任务完成时执行 hooks

链路位置：
    Agent Loop → TaskUpdateRuntimeTool → TaskStoreSync（task_runtime.tasklist）→ 文件系统
"""

from __future__ import annotations

from typing import Any, Optional

from langchain_agentx.loop.hook.registry import HookRegistry, TaskCompletedHook
from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.workspace import AgentWorkspaceConfig

from .hooks import execute_task_completed_hooks
from .models import StatusChange, TaskUpdateInput, TaskUpdateOutput
from .prompt import DESCRIPTION, TOOL_NAME
from langchain_agentx.task_runtime.tasklist import (
    TaskStoreSync,
    TaskUpdate as TaskUpdateModel,
    TaskUpdateStatus,
)


# 状态流转规则表（合法转换）
# from \ to | pending | in_progress | completed | deleted
# -----------|--------|------------|----------|--------
# pending    | ✅     | ✅         | ✅       | ✅
# in_progress| ✅     | ✅         | ✅       | ✅
# completed  | ✅     | ❌         | ✅       | ✅
# deleted    | ❌     | ❌         | ❌       | ❌

_ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "pending": {"pending", "in_progress", "completed", "deleted"},
    "in_progress": {"pending", "in_progress", "completed", "deleted"},
    "completed": {"pending", "completed", "deleted"},  # completed → in_progress 禁止
    "deleted": set(),  # deleted 不能转换到任何状态
}


class TaskUpdateRuntimeTool(RuntimeTool):
    """任务更新工具。

    提供任务状态、详情、依赖关系的更新能力，配合 TaskCreate/TaskGet
    实现完整的工作流管理。
    """

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = TaskUpdateInput
    is_read_only: bool = False
    is_concurrency_safe: bool = True  # 文件锁保证并发安全

    def __init__(self, config: Optional[AgentWorkspaceConfig] = None) -> None:
        """初始化工具。

        Args:
            config: 工作区配置，为 None 时使用默认配置
        """
        super().__init__()
        self._store = TaskStoreSync(config=config)

    def validate_input(self, data: TaskUpdateInput) -> ValidationResult:
        """校验输入。

        校验规则：
        - taskId 非空
        - 至少提供一个更新字段
        - status 只能是合法值
        """
        errors: list[str] = []

        if not data.task_id.strip():
            errors.append("task_id cannot be empty")

        # 检查是否至少有一个更新字段
        has_update = any([
            data.subject is not None,
            data.description is not None,
            data.active_form is not None,
            data.status is not None,
            data.owner is not None,
            data.add_blocks is not None,
            data.add_blocked_by is not None,
            data.metadata is not None,
        ])

        if not has_update:
            errors.append("At least one field must be provided for update")

        if errors:
            return ValidationResult(ok=False, message="\n".join(errors))
        return ValidationResult(ok=True)

    def is_enabled(self, ctx: ToolExecutionContext) -> bool:
        """检查工具是否可用。

        工具始终可用（tasks_dir 由 workspace 配置保证存在）
        """
        return True

    def invoke(self, data: TaskUpdateInput, ctx: ToolExecutionContext) -> TaskUpdateOutput:
        """执行更新任务。

        Args:
            data: 输入参数
            ctx: 执行上下文

        Returns:
            TaskUpdateOutput: 更新结果
        """
        # 获取现有任务
        existing_task = self._store.get_task(data.task_id)
        if existing_task is None:
            return TaskUpdateOutput(
                success=False,
                task_id=data.task_id,
                updated_fields=[],
                error="Task not found",
            )

        updated_fields: list[str] = []
        updates_dict: dict[str, Any] = {}
        status_change: StatusChange | None = None

        # 收集基本字段更新
        if data.subject is not None and data.subject != existing_task.subject:
            updates_dict["subject"] = data.subject
            updated_fields.append("subject")

        if data.description is not None and data.description != existing_task.description:
            updates_dict["description"] = data.description
            updated_fields.append("description")

        if data.active_form is not None and data.active_form != existing_task.active_form:
            updates_dict["active_form"] = data.active_form
            updated_fields.append("activeForm")

        if data.owner is not None and data.owner != existing_task.owner:
            updates_dict["owner"] = data.owner
            updated_fields.append("owner")

        # 元数据合并
        # 语义：{} = 不修改，{key: value} = 新增或覆盖，{key: None} = 删除
        if data.metadata is not None:
            # TaskStore.update_task() 处理 None 值删除逻辑，直接传递
            updates_dict["metadata"] = data.metadata
            updated_fields.append("metadata")

        # 状态更新（特殊处理）
        if data.status is not None:
            if data.status == "deleted":
                # 删除任务
                deleted = self._store.delete_task(data.task_id)
                return TaskUpdateOutput(
                    success=deleted,
                    task_id=data.task_id,
                    updated_fields=["deleted"] if deleted else [],
                    error=None if deleted else "Failed to delete task",
                    status_change=StatusChange(
                        from_status=existing_task.status,
                        to_status="deleted",
                    ) if deleted else None,
                )

            if data.status != existing_task.status:
                # 验证状态流转合法性
                current_status = existing_task.status
                allowed = _ALLOWED_TRANSITIONS.get(current_status, set())
                if data.status not in allowed:
                    return TaskUpdateOutput(
                        success=False,
                        task_id=data.task_id,
                        updated_fields=[],
                        error=f"Invalid status transition: {current_status} → {data.status}",
                    )

                # 标记完成时执行 hooks
                if data.status == "completed":
                    blocking_errors = execute_task_completed_hooks(
                        task_id=data.task_id,
                        subject=existing_task.subject,
                        description=existing_task.description,
                        agent_id=ctx.agent_id,
                    )

                    if blocking_errors:
                        return TaskUpdateOutput(
                            success=False,
                            task_id=data.task_id,
                            updated_fields=[],
                            error="\n".join(blocking_errors),
                        )

                updates_dict["status"] = data.status
                updated_fields.append("status")
                status_change = StatusChange(
                    from_status=existing_task.status,
                    to_status=data.status,
                )

        # 执行更新
        if updates_dict:
            self._store.update_task(data.task_id, TaskUpdateModel(**updates_dict))

        # 依赖管理：addBlocks
        if data.add_blocks:
            existing_blocks = existing_task.blocks or []
            new_blocks = [bid for bid in data.add_blocks if bid not in existing_blocks]
            actually_added = 0
            for block_id in new_blocks:
                # 验证目标任务存在（CC 行为：静默跳过不存在的任务）
                if self._store.task_exists(block_id):
                    self._store.block_task(data.task_id, block_id)
                    actually_added += 1
            if actually_added > 0:
                updated_fields.append("blocks")

        # 依赖管理：addBlockedBy
        if data.add_blocked_by:
            existing_blocked_by = existing_task.blocked_by or []
            new_blocked_by = [bid for bid in data.add_blocked_by if bid not in existing_blocked_by]
            actually_added = 0
            for blocker_id in new_blocked_by:
                # 验证目标任务存在（CC 行为：静默跳过不存在的任务）
                if self._store.task_exists(blocker_id):
                    self._store.block_task(blocker_id, data.task_id)
                    actually_added += 1
            if actually_added > 0:
                updated_fields.append("blockedBy")

        return TaskUpdateOutput(
            success=True,
            task_id=data.task_id,
            updated_fields=updated_fields,
            error=None,
            status_change=status_change,
        )

    def present(self, result: TaskUpdateOutput, ctx: ToolExecutionContext) -> ToolResultEnvelope:
        """格式化输出。

        CC 对齐要点：
        - 错误场景不作为 error 返回（避免 sibling cancellation）
        - 完成时添加额外提示（与 CC 一致）
        """
        if not result.success:
            # CC 行为：错误作为 content 返回，不触发 sibling cancellation
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=result.error or f"Task #{result.task_id} not found",
                payload={
                    "success": False,
                    "task_id": result.task_id,
                    "error": result.error,
                },
            )

        # 构建可读摘要
        lines = [f"Updated task #{result.task_id} {', '.join(result.updated_fields)}"]

        if result.status_change:
            lines.append(f"Status: {result.status_change.from_status} → {result.status_change.to_status}")

            # CC 对齐：任务完成时添加提示
            if result.status_change.to_status == "completed":
                lines.append("")
                lines.append("Task completed. Call TaskList now to find your next available task or see if your work unblocked others.")

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary="\n".join(lines),
            payload={
                "success": True,
                "task_id": result.task_id,
                "updated_fields": result.updated_fields,
                "status_change": result.status_change.model_dump() if result.status_change else None,
            },
        )
