"""task_update/hooks.py — taskCompleted hooks 执行器

职责：
    在任务标记为 completed 之前，同步执行 HookRegistry 注册的 TaskCompletedHook，
    收集阻塞性错误字符串并返回给工具层（不写入任务 JSON）。

链路位置：
    TaskUpdateRuntimeTool.invoke() → execute_task_completed_hooks() → HookRegistry

当前裁剪范围：
    - 仅 taskCompleted；不实现 taskCreated 等其它 CC hooks 编排（由 TaskCreate 侧负责）
"""

from typing import Callable

from langchain_agentx.loop.hook.registry import TaskCompletedHook


def execute_task_completed_hooks(
    task_id: str,
    subject: str,
    description: str,
    agent_id: str | None = None,
) -> list[str]:
    """执行任务完成 hooks。

    v1 实现：
    - 遍历所有注册的 hooks
    - 收集阻塞性错误
    - 返回错误列表

    Args:
        task_id: 完成的任务 ID
        subject: 任务标题
        description: 任务描述
        agent_id: 当前 agent ID

    Returns:
        list[str]: 阻塞性错误列表（空表示无错误）
    """
    from langchain_agentx.loop.hook.registry import HookRegistry

    blocking_errors: list[str] = []

    # 获取注册的 hooks（HookRegistry 提供）
    for hook in HookRegistry.get_task_completed_hooks():
        try:
            error = hook(task_id, subject, description, agent_id)
            if error:
                blocking_errors.append(error)
        except Exception as e:
            blocking_errors.append(f"Hook execution failed: {e}")

    return blocking_errors
