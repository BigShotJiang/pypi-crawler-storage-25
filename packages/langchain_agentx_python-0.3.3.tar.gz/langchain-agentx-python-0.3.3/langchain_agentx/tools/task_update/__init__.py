"""TaskUpdateRuntimeTool — 任务更新工具。

提供任务状态、详情、依赖关系的更新能力，配合 TaskCreate/TaskGet
实现完整的工作流管理。
"""

from .tool import TaskUpdateRuntimeTool

__all__ = ["TaskUpdateRuntimeTool"]
