"""TaskUpdate 工具输入输出模型。"""

from pydantic import BaseModel, Field

from langchain_agentx.task_runtime.tasklist import (
    MAX_ACTIVE_FORM_LENGTH,
    MAX_DESCRIPTION_LENGTH,
    MAX_SUBJECT_LENGTH,
    TaskUpdateStatus,
)


class TaskUpdateInput(BaseModel):
    """TaskUpdate 工具输入。"""

    task_id: str = Field(
        description="The ID of the task to update",
        examples=["1", "2", "42"],
    )
    subject: str | None = Field(
        None,
        description="New subject for the task",
        max_length=MAX_SUBJECT_LENGTH,
    )
    description: str | None = Field(
        None,
        description="New description for the task",
        max_length=MAX_DESCRIPTION_LENGTH,
    )
    active_form: str | None = Field(
        None,
        description="Present continuous form shown in spinner when in_progress",
        max_length=MAX_ACTIVE_FORM_LENGTH,
    )
    status: TaskUpdateStatus | None = Field(
        None,
        description="New status for the task",
    )
    owner: str | None = Field(
        None,
        description="New owner for the task",
    )
    add_blocks: list[str] | None = Field(
        None,
        description="Task IDs that this task blocks",
    )
    add_blocked_by: list[str] | None = Field(
        None,
        description="Task IDs that block this task",
    )
    metadata: dict[str, object] | None = Field(
        None,
        description="Metadata keys to merge into the task. Set a key to null to delete it.",
    )


class StatusChange(BaseModel):
    """状态变更记录。"""

    from_status: str
    to_status: str


class TaskUpdateOutput(BaseModel):
    """TaskUpdate 工具输出。"""

    success: bool
    task_id: str
    updated_fields: list[str]
    error: str | None = None
    status_change: StatusChange | None = None
