"""
tools/agent/limits.py — AgentTool 配额常量 + 动态后台目录解析

职责：集中管理 Agent 工具输出上限、嵌套深度与后台任务目录（动态解析），不承载执行逻辑。
在整体链路中的位置：tool.py 的 check_permissions()/invoke() 读取这些阈值，后台路径在
调用期由 resolve_background_output_dir(capabilities, runtime_ctx) 按需解析。
CC 对照：src/tools/AgentTool/AgentTool.tsx 的 maxResultSizeChars=100_000 与深度防护语义。
当前裁剪范围：移除 import-time 的 resolve_agent_workspace_config()，切换为函数式 API；
保留 __getattr__ 兼容旧常量 BACKGROUND_OUTPUT_DIR。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from langchain_agentx.workspace import AgentWorkspaceConfig, RuntimeCapabilities

MAX_OUTPUT_CHARS: int = int(
    os.getenv("LANGCHAIN_AGENTX_AGENT_TOOL_MAX_OUTPUT_CHARS", "100000")
)
MAX_AGENT_DEPTH: int = int(os.getenv("LANGCHAIN_AGENTX_AGENT_TOOL_MAX_DEPTH", "3"))

_ENV_BACKGROUND_OUTPUT_DIR = "LANGCHAIN_AGENTX_AGENT_TOOL_BACKGROUND_OUTPUT_DIR"


def resolve_background_output_dir(
    capabilities: "RuntimeCapabilities | None" = None,
    runtime_ctx: "AgentWorkspaceConfig | None" = None,
) -> Path:
    """解析后台任务输出目录。

    优先级：环境变量 > runtime_ctx.tasks_dir > resolve_agent_workspace_config().tasks_dir。

    Args:
        capabilities: 保留接口以便将来接入 A 档 task_runtime.tasks_dir；当前未消费。
        runtime_ctx: 节点级 AgentWorkspaceConfig；存在时取 tasks_dir。
    """
    env_value = os.getenv(_ENV_BACKGROUND_OUTPUT_DIR)
    if env_value:
        return Path(os.path.expanduser(env_value))
    if runtime_ctx is not None:
        return Path(runtime_ctx.tasks_dir)
    from langchain_agentx.workspace import resolve_agent_workspace_config

    return Path(resolve_agent_workspace_config().tasks_dir)


def __getattr__(name: str) -> Any:
    """向后兼容：读取 ``BACKGROUND_OUTPUT_DIR`` 时延迟解析一次（设计 R3）。"""
    if name == "BACKGROUND_OUTPUT_DIR":
        return str(resolve_background_output_dir())
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "MAX_AGENT_DEPTH",
    "MAX_OUTPUT_CHARS",
    "resolve_background_output_dir",
]
