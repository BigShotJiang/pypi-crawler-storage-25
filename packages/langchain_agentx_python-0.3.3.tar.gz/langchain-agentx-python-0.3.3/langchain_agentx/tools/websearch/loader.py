"""
tools/websearch/loader.py — 将 WebSearchRuntimeTool 注册到 ToolRuntimeLoader

职责：
    按 Tavily → SearXNG 优先级选择 SearchBackend；均不可用时静默跳过（不抛异常）。

链路位置：
    ToolRuntimeLoader.register_default_tools → websearch.register(loader)。

当前裁剪范围：
    SearXNG 在 Phase 5-e 前始终不可用；仅 Tavily 环境变量就绪时注册。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_agentx.tools.websearch.backend import (
    SearchBackend,
    SearXNGSearchBackend,
    TavilySearchBackend,
)
from langchain_agentx.tools.websearch.tool import WebSearchRuntimeTool

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.loader import ToolRuntimeLoader


def _select_backend() -> SearchBackend | None:
    b = TavilySearchBackend.from_env()
    if b is not None:
        return b
    return SearXNGSearchBackend.from_env()


def register(loader: ToolRuntimeLoader) -> None:
    """若任一搜索后端可用则注册 ``WebSearch`` 工具，否则 no-op。"""
    backend = _select_backend()
    if backend is None:
        return
    loader.register(WebSearchRuntimeTool(backend=backend))


def is_enabled() -> bool:
    """与 CC WebSearchTool.isEnabled 语义对齐的进程级门控：任一副本可用即 True。"""
    return TavilySearchBackend.is_available() or SearXNGSearchBackend.is_available()


__all__ = ["register", "is_enabled", "_select_backend"]
