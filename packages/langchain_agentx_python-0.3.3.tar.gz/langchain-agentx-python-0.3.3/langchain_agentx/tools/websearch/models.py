"""
tools/websearch/models.py — WebSearch 输入/输出 Pydantic 模型

职责：
    WebSearchToolInput / SearchHit / WebSearchToolOutput 及域名互斥与格式校验，
    与 CC WebSearchTool 输入 schema 对齐并扩展 max_results。

链路位置：
    WebSearchRuntimeTool.input_model / output_model；TavilySearchBackend 映射为 SearchHit。

当前裁剪范围：
    不含多查询批量结构（由 limits.MAX_SEARCHES_PER_CALL 在工具层预留）。
"""

from __future__ import annotations

import re

from pydantic import BaseModel, Field, field_validator, model_validator

from langchain_agentx.tools.websearch.limits import get_max_results_per_search

# ASCII 主机名：至少一段标签 + TLD；与常见搜索过滤参数一致。
_DOMAIN_RE = re.compile(
    r"^(?=.{1,253}\Z)(?!-)(?:[A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63}\Z",
    re.IGNORECASE,
)


def _is_valid_domain(d: str) -> bool:
    s = d.strip()
    if not s:
        return False
    if s.endswith("."):
        s = s[:-1]
    if ".." in s or "/" in s or ":" in s or " " in s:
        return False
    return bool(_DOMAIN_RE.match(s))


class SearchHit(BaseModel):
    """单条搜索结果。"""

    title: str = Field(description="结果标题")
    url: str = Field(description="结果 URL")
    snippet: str = Field(default="", description="摘要/片段")


class WebSearchToolInput(BaseModel):
    """与 CC inputSchema 对齐：query + allowed_domains / blocked_domains；扩展 max_results。"""

    query: str = Field(min_length=1, description="搜索查询字符串")
    allowed_domains: list[str] | None = Field(
        default=None, description="仅保留这些域名的结果（与 blocked_domains 互斥）"
    )
    blocked_domains: list[str] | None = Field(
        default=None, description="排除这些域名的结果（与 allowed_domains 互斥）"
    )
    max_results: int | None = Field(
        default=None,
        description="返回条数上限；默认使用 limits.get_max_results_per_search()",
    )

    @field_validator("query")
    @classmethod
    def strip_query(cls, v: str) -> str:
        return v.strip()

    @field_validator("allowed_domains", "blocked_domains")
    @classmethod
    def normalize_domain_lists(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        out = [str(x).strip().lower() for x in v if str(x).strip()]
        return out or None

    @model_validator(mode="after")
    def mutual_exclusive_domains(self) -> WebSearchToolInput:
        a = self.allowed_domains
        b = self.blocked_domains
        if a and b:
            raise ValueError("allowed_domains and blocked_domains are mutually exclusive")
        for group, name in ((a, "allowed_domains"), (b, "blocked_domains")):
            if not group:
                continue
            for d in group:
                if not _is_valid_domain(d):
                    raise ValueError(f"Invalid domain in {name}: {d!r}")
        return self

    @model_validator(mode="after")
    def clamp_max_results(self) -> WebSearchToolInput:
        cap = get_max_results_per_search()
        if self.max_results is None:
            self.max_results = cap
        else:
            self.max_results = max(1, min(int(self.max_results), cap))
        return self


class WebSearchToolOutput(BaseModel):
    """结构化执行结果（invoke → present）。"""

    query: str
    results: list[SearchHit]
    total_hits: int = Field(description="过滤后命中条数（通常等于 len(results)）")
    duration_ms: float
    search_engine: str = Field(description="后端标识，如 tavily / searxng")

    @classmethod
    def from_hits(
        cls,
        *,
        query: str,
        hits: list[SearchHit],
        duration_ms: float,
        search_engine: str,
    ) -> WebSearchToolOutput:
        return cls(
            query=query,
            results=hits,
            total_hits=len(hits),
            duration_ms=duration_ms,
            search_engine=search_engine,
        )


__all__ = [
    "SearchHit",
    "WebSearchToolInput",
    "WebSearchToolOutput",
    "_is_valid_domain",
]
