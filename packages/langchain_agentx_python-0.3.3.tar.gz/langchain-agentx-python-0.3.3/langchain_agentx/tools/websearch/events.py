"""
tools/websearch/events.py — WebSearch 进度事件（UI / 观测对齐 CC WebSearchProgress）

职责：
    定义 SEARCH_QUERY_UPDATE / SEARCH_RESULTS_RECEIVED / SEARCH_ERROR 及 ProgressEvent 载荷，
    供 WebSearchRuntimeTool 在 invoke 中经 progress_callback 上报。

链路位置：
    WebSearchRuntimeTool.invoke → 宿主 progress_callback（可选，来自 ctx 或测试注入）。

当前裁剪范围：
    仅数据结构；不含与 LangGraph 事件总线的自动桥接（由调用方接线）。
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class ProgressEventType(str, Enum):
    """对齐 CC UI.tsx：query_update / search_results_received；扩展 SEARCH_ERROR。"""

    SEARCH_QUERY_UPDATE = "search_query_update"
    SEARCH_RESULTS_RECEIVED = "search_results_received"
    SEARCH_ERROR = "search_error"


class ProgressEvent(BaseModel):
    """单次进度通知。"""

    type: ProgressEventType
    tool_name: str = Field(description="RuntimeTool.name，如 WebSearch")
    data: dict[str, Any] = Field(
        description=(
            "事件载荷：SEARCH_QUERY_UPDATE 含 query, search_id；"
            "SEARCH_RESULTS_RECEIVED 含 result_count, search_id；"
            "SEARCH_ERROR 含 message, code?, search_id?"
        )
    )
    timestamp: float = Field(default_factory=time.time)


# ---- data 结构规范（文档/类型提示用，运行时以 dict 传递）----
SearchQueryUpdateData = dict[str, Any]  # query, search_id
SearchResultsReceivedData = dict[str, Any]  # result_count, search_id, optional total_hits
SearchErrorData = dict[str, Any]  # message, code?, search_id?

__all__ = [
    "ProgressEventType",
    "ProgressEvent",
    "SearchQueryUpdateData",
    "SearchResultsReceivedData",
    "SearchErrorData",
]
