"""
tools/websearch/limits.py — WebSearch 工具运行时限制（环境变量可覆盖）

职责：
    集中定义超时、单次结果上限、每调用搜索次数、查询最短长度、输出字符上限等常量；
    供 backend / RuntimeTool 读取，避免魔法数散落。

链路位置：
    ToolRuntime WebSearch 子系统；由 models/backend/tool 引用。

当前裁剪范围：
    仅进程级静态配置；不含按 workspace 的 JSON 策略覆盖（后续可扩展）。
"""

from __future__ import annotations

import os


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def get_timeout_sec() -> float:
    """HTTP 搜索请求超时秒数。环境变量 WEBSEARCH_TOOL_TIMEOUT_SEC。"""
    return _env_float("WEBSEARCH_TOOL_TIMEOUT_SEC", 30.0)


def get_max_searches_per_call() -> int:
    """单次工具调用允许的最大搜索次数（预留多查询场景）。WEBSEARCH_TOOL_MAX_SEARCHES。"""
    v = _env_int("WEBSEARCH_TOOL_MAX_SEARCHES", 5)
    return max(1, v)


def get_max_results_per_search() -> int:
    """单次搜索返回条数上限。WEBSEARCH_TOOL_MAX_RESULTS。"""
    v = _env_int("WEBSEARCH_TOOL_MAX_RESULTS", 10)
    return max(1, min(v, 50))


def get_min_query_length() -> int:
    """查询字符串最短字符数。WEBSEARCH_TOOL_MIN_QUERY_LENGTH。"""
    v = _env_int("WEBSEARCH_TOOL_MIN_QUERY_LENGTH", 2)
    return max(1, v)


# 与 CC WebSearchTool.maxResultSizeChars 对齐（见 CC WebSearchTool.ts）
DEFAULT_MAX_RESULT_CHARS: int = 100_000
