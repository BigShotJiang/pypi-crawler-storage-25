"""
tools/websearch/tool.py — WebSearchRuntimeTool

职责：
    RuntimeTool 生命周期：normalize / validate / permissions / invoke / present；
    通过 Tavily 等 SearchBackend 执行外网搜索，并可选上报 ProgressEvent。

链路位置：
    ToolRuntimeLoader.register(WebSearchRuntimeTool(...))；默认由 websearch.loader 装配。

当前裁剪范围：
    单次单 query；不含 CC 服务端 web_search_20250305 块解析与 max_uses 计数器状态。
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.tools.websearch.backend import (
    SearchBackend,
    SearchBackendError,
)
from langchain_agentx.tools.websearch.events import ProgressEvent, ProgressEventType
from langchain_agentx.tools.websearch.limits import (
    DEFAULT_MAX_RESULT_CHARS,
    get_min_query_length,
)
from langchain_agentx.tools.websearch.models import WebSearchToolInput, WebSearchToolOutput
from langchain_agentx.tools.websearch.prompt import DESCRIPTION, TOOL_NAME, get_sources_reminder

# 权限层：禁止将搜索范围刻意限制到常见 SSRF/内网解析目标（与 CC 安全意图对齐）。
_SENSITIVE_SCOPE_DOMAINS: frozenset[str] = frozenset(
    {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
        "::1",
        "metadata.google.internal",
        "metadata.google.internal.",
    }
)


def _emit(
    ctx: ToolExecutionContext,
    ev: ProgressEvent,
) -> None:
    cb = ctx.tool_progress_callback
    if cb is None or not callable(cb):
        return
    try:
        cb(ev)
    except Exception:
        return


class WebSearchRuntimeTool(RuntimeTool):
    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = WebSearchToolInput
    output_model = WebSearchToolOutput
    is_read_only: bool = True
    is_concurrency_safe: bool = True
    never_truncate: bool = False
    max_result_size_chars: int = DEFAULT_MAX_RESULT_CHARS

    def __init__(
        self,
        backend: SearchBackend,
        *,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        search_id: str | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._backend = backend
        self._fixed_search_id = search_id

    def normalize_input(
        self, raw: dict[str, Any], ctx: ToolExecutionContext
    ) -> dict[str, Any]:
        data = dict(raw)
        q = data.get("query")
        if isinstance(q, str):
            data["query"] = q.strip()
        return data

    def validate_input(
        self, data: dict[str, Any], ctx: ToolExecutionContext
    ) -> ValidationResult:
        q = str(data.get("query") or "").strip()
        if not q:
            return ValidationResult(
                ok=False,
                message="Search query cannot be empty",
                code="EMPTY_QUERY",
            )
        min_len = get_min_query_length()
        if len(q) < min_len:
            return ValidationResult(
                ok=False,
                message=f"Query must be at least {min_len} characters",
                code="QUERY_TOO_SHORT",
            )
        return ValidationResult(ok=True)

    def _domains_policy_deny(self, data: dict[str, Any]) -> str | None:
        """若返回非空字符串则表示 deny 原因。"""
        for key in ("allowed_domains", "blocked_domains"):
            doms = data.get(key)
            if not isinstance(doms, list):
                continue
            for d in doms:
                if not isinstance(d, str):
                    continue
                low = d.strip().lower().rstrip(".")
                if low in _SENSITIVE_SCOPE_DOMAINS:
                    return f"Domain '{d}' cannot be used in {key} (sensitive scope)"
        return None

    def check_permissions(
        self, data: dict[str, Any], ctx: ToolExecutionContext
    ) -> AuthorizationDecision:
        if not ctx.network_access_allowed:
            return AuthorizationDecision(
                behavior="deny",
                message="Web search is disabled (network_access_allowed=False)",
            )
        if not type(self._backend).is_available():
            return AuthorizationDecision(
                behavior="deny",
                message="Search backend is not configured or no longer available",
            )
        deny_reason = self._domains_policy_deny(data)
        if deny_reason:
            return AuthorizationDecision(behavior="deny", message=deny_reason)
        return super().check_permissions(data, ctx)

    def invoke(self, data: dict[str, Any], ctx: ToolExecutionContext) -> WebSearchToolOutput:
        parsed = WebSearchToolInput.model_validate(data)
        search_id = self._fixed_search_id or str(uuid.uuid4())

        _emit(
            ctx,
            ProgressEvent(
                type=ProgressEventType.SEARCH_QUERY_UPDATE,
                tool_name=self.name,
                data={"query": parsed.query, "search_id": search_id},
            ),
        )

        t0 = time.perf_counter()
        try:
            hits = self._backend.search(
                query=parsed.query,
                max_results=int(parsed.max_results or 10),
                allowed_domains=parsed.allowed_domains,
                blocked_domains=parsed.blocked_domains,
            )
        except SearchBackendError as e:
            _emit(
                ctx,
                ProgressEvent(
                    type=ProgressEventType.SEARCH_ERROR,
                    tool_name=self.name,
                    data={
                        "message": str(e),
                        "code": e.code,
                        "search_id": search_id,
                    },
                ),
            )
            raise
        except TimeoutError as e:
            _emit(
                ctx,
                ProgressEvent(
                    type=ProgressEventType.SEARCH_ERROR,
                    tool_name=self.name,
                    data={"message": "Search timed out", "code": "timeout", "search_id": search_id},
                ),
            )
            raise SearchBackendError("Search timed out", code="timeout") from e
        duration_ms = (time.perf_counter() - t0) * 1000.0

        _emit(
            ctx,
            ProgressEvent(
                type=ProgressEventType.SEARCH_RESULTS_RECEIVED,
                tool_name=self.name,
                data={
                    "result_count": len(hits),
                    "search_id": search_id,
                },
            ),
        )

        return WebSearchToolOutput.from_hits(
            query=parsed.query,
            hits=hits,
            duration_ms=duration_ms,
            search_engine=self._backend.engine_id(),
        )

    def present(
        self, data: dict[str, Any], result: Any, ctx: ToolExecutionContext
    ) -> ToolResultEnvelope:
        if not isinstance(result, WebSearchToolOutput):
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=str(result),
                payload={"raw": str(result)},
            )

        r = result
        lines: list[str] = [
            f"Query: {r.query}",
            f"Engine: {r.search_engine} · {r.total_hits} hit(s) · {r.duration_ms:.1f} ms",
            "",
        ]
        for i, h in enumerate(r.results, 1):
            title = h.title or h.url
            lines.append(f"{i}. [{title}]({h.url})")
            if h.snippet:
                lines.append(f"   {h.snippet}")
            lines.append("")
        body = "\n".join(lines).strip() + get_sources_reminder()

        summary = f"Web search returned {r.total_hits} result(s) for {r.query!r}"
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload={"markdown": body, "output": r.model_dump()},
            meta={
                "duration_ms": round(r.duration_ms, 2),
                "search_engine": r.search_engine,
                "total_hits": r.total_hits,
            },
        )


__all__ = ["WebSearchRuntimeTool"]
