"""
tools/websearch/backend.py — 搜索后端抽象与 Tavily 实现（SearXNG 预留）

职责：
    SearchBackend 定义 is_available / from_env / search 契约；
    TavilySearchBackend 使用 stdlib urllib 调用 https://api.tavily.com/search；
    SearXNGSearchBackend 仅占位（Phase 5-e）。

链路位置：
    WebSearchRuntimeTool 注入后端；loader 通过 from_env 选择实例。

当前裁剪范围：
    SearXNG 未实现 search；不含代理自动探测与重试退避。
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urlparse

from langchain_agentx.tools.websearch.limits import get_timeout_sec
from langchain_agentx.tools.websearch.models import SearchHit


class SearchBackendError(Exception):
    """搜索后端可恢复/不可恢复错误统一类型。"""

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


class SearchBackend(ABC):
    """搜索后端抽象。"""

    @classmethod
    @abstractmethod
    def is_available(cls) -> bool:
        """当前进程环境下该后端是否可实例化并成功调用。"""

    @classmethod
    def from_env(cls) -> SearchBackend | None:
        """从环境变量构造实例；不可用时返回 None。"""
        if not cls.is_available():
            return None
        return cls()  # type: ignore[misc]

    @abstractmethod
    def engine_id(self) -> str:
        """稳定短标识，写入 WebSearchToolOutput.search_engine。"""

    @abstractmethod
    def search(
        self,
        *,
        query: str,
        max_results: int,
        allowed_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
    ) -> list[SearchHit]:
        """执行搜索并返回命中列表（已按域名规则过滤）。"""


def _domain_from_url(url: str) -> str | None:
    try:
        host = urlparse(url).hostname
        if not host:
            return None
        return host.lower().lstrip("www.")
    except Exception:
        return None


def _filter_hits(
    hits: list[SearchHit],
    *,
    allowed_domains: list[str] | None,
    blocked_domains: list[str] | None,
) -> list[SearchHit]:
    allow = {d.lower().lstrip("www.") for d in (allowed_domains or [])}
    block = {d.lower().lstrip("www.") for d in (blocked_domains or [])}
    out: list[SearchHit] = []
    for h in hits:
        d = _domain_from_url(h.url)
        if d is None:
            continue
        if allow and d not in allow and not any(d.endswith("." + a) for a in allow):
            continue
        if block and (d in block or any(d.endswith("." + b) for b in block)):
            continue
        out.append(h)
    return out


class TavilySearchBackend(SearchBackend):
    """Tavily Search API（需 TAVILY_API_KEY）。"""

    TAVILY_URL = "https://api.tavily.com/search"

    def __init__(self, *, api_key: str, timeout_sec: float | None = None) -> None:
        self._api_key = api_key.strip()
        self._timeout = float(timeout_sec if timeout_sec is not None else get_timeout_sec())

    @classmethod
    def is_available(cls) -> bool:
        return bool(os.environ.get("TAVILY_API_KEY", "").strip())

    @classmethod
    def from_env(cls) -> TavilySearchBackend | None:
        key = os.environ.get("TAVILY_API_KEY", "").strip()
        if not key:
            return None
        return cls(api_key=key)

    def engine_id(self) -> str:
        return "tavily"

    def search(
        self,
        *,
        query: str,
        max_results: int,
        allowed_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
    ) -> list[SearchHit]:
        body: dict[str, Any] = {
            "api_key": self._api_key,
            "query": query,
            "max_results": max_results,
            "include_answer": False,
        }
        if allowed_domains:
            body["include_domains"] = list(allowed_domains)

        raw = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.TAVILY_URL,
            data=raw,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except TimeoutError as e:
            raise SearchBackendError("Tavily request timed out", code="timeout") from e
        except urllib.error.HTTPError as e:
            text = e.read().decode("utf-8", errors="replace") if e.fp else ""
            raise SearchBackendError(
                f"Tavily HTTP {e.code}: {text[:500]}",
                code=f"http_{e.code}",
            ) from e
        except urllib.error.URLError as e:
            raise SearchBackendError(f"Tavily network error: {e.reason!s}", code="network") from e
        except json.JSONDecodeError as e:
            raise SearchBackendError("Tavily returned invalid JSON", code="invalid_json") from e

        results = payload.get("results")
        if not isinstance(results, list):
            raise SearchBackendError("Tavily response missing 'results' list", code="invalid_shape")

        hits: list[SearchHit] = []
        for item in results[:max_results]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or "").strip()
            url = str(item.get("url") or "").strip()
            if not url:
                continue
            snippet = str(item.get("content") or item.get("snippet") or "").strip()
            hits.append(SearchHit(title=title or url, url=url, snippet=snippet))

        hits = _filter_hits(hits, allowed_domains=allowed_domains, blocked_domains=blocked_domains)
        return hits[:max_results]


class SearXNGSearchBackend(SearchBackend):
    """SearXNG JSON API（需 SEARXNG_URL，例如 https://search.example.com）。"""

    def __init__(self, *, base_url: str, timeout_sec: float | None = None) -> None:
        self._base = base_url.strip().rstrip("/")
        self._timeout = float(timeout_sec if timeout_sec is not None else get_timeout_sec())

    @classmethod
    def is_available(cls) -> bool:
        return bool(os.environ.get("SEARXNG_URL", "").strip())

    @classmethod
    def from_env(cls) -> SearXNGSearchBackend | None:
        raw = os.environ.get("SEARXNG_URL", "").strip()
        if not raw:
            return None
        return cls(base_url=raw)

    def engine_id(self) -> str:
        return "searxng"

    def search(
        self,
        *,
        query: str,
        max_results: int,
        allowed_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
    ) -> list[SearchHit]:
        params = urllib.parse.urlencode({"q": query, "format": "json"})
        url = f"{self._base}/search?{params}"
        req = urllib.request.Request(url, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except TimeoutError as e:
            raise SearchBackendError("SearXNG request timed out", code="timeout") from e
        except urllib.error.HTTPError as e:
            text = e.read().decode("utf-8", errors="replace") if e.fp else ""
            raise SearchBackendError(
                f"SearXNG HTTP {e.code}: {text[:500]}",
                code=f"http_{e.code}",
            ) from e
        except urllib.error.URLError as e:
            raise SearchBackendError(f"SearXNG network error: {e.reason!s}", code="network") from e
        except json.JSONDecodeError as e:
            raise SearchBackendError("SearXNG returned invalid JSON", code="invalid_json") from e

        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            raise SearchBackendError("SearXNG response missing 'results' list", code="invalid_shape")

        hits: list[SearchHit] = []
        for item in raw_results[: max_results * 2]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or "").strip()
            url_s = str(item.get("url") or "").strip()
            if not url_s:
                continue
            snippet = str(item.get("content") or item.get("snippet") or "").strip()
            hits.append(SearchHit(title=title or url_s, url=url_s, snippet=snippet))

        hits = _filter_hits(hits, allowed_domains=allowed_domains, blocked_domains=blocked_domains)
        return hits[:max_results]


__all__ = [
    "SearchBackend",
    "SearchBackendError",
    "TavilySearchBackend",
    "SearXNGSearchBackend",
]
