"""
tools/websearch/prompt.py — WebSearch 工具名、描述与来源提醒（迁移自 CC）

职责：
    提供 TOOL_NAME、DESCRIPTION（含当前年月）、SOURCES_REMINDER；
    CC 原文描述「单次 API 内自动搜索」为服务端工具语义，本处改为客户端 Tavily/SearXNG 调用说明。

链路位置：
    WebSearchRuntimeTool 类属性 description；present() 追加 SOURCES_REMINDER。

当前裁剪范围：
    不含按模型 locale 动态切换语言（与 CC getLocalMonthYear 对齐仅年月）。
"""

from __future__ import annotations

from datetime import datetime

# CC: WEB_SEARCH_TOOL_NAME = 'WebSearch'（prompt.ts）
TOOL_NAME: str = "WebSearch"


def _current_month_year() -> str:
    """对齐 CC getLocalMonthYear：当前本地「月 年」。"""
    return datetime.now().strftime("%B %Y")


def get_sources_reminder() -> str:
    """CC CRITICAL REQUIREMENT：回答末尾必须带 Sources 区块（markdown 链接）。"""
    return (
        "\n\n---\n"
        "**Sources (mandatory in your final answer):** list relevant URLs under a "
        "`Sources:` heading as markdown links `[Title](URL)`."
    )


def build_description() -> str:
    """
    基于 CC getWebSearchPrompt() 改写：
    - 保留「实时信息 / 超出知识截止 / 年月」等约束；
    - 标明搜索由本机通过配置的搜索 API（Tavily 等）发起，而非模型内嵌服务端工具。
    """
    current_month_year = _current_month_year()
    return f"""Search the public web for up-to-date information via a configured search API (for example Tavily).

Use this tool when the user needs recent facts, documentation, release notes, or anything likely beyond the model's training cutoff.

Important:
- Searches are executed by the agent runtime (client-side HTTP), not as a hidden model-internal server tool.
- Results are returned as structured hits (title, URL, snippet) and should be summarized faithfully.
- Domain filtering: you may restrict results with `allowed_domains` OR `blocked_domains`, never both.

IMPORTANT — use the correct year in queries:
- The current month is {current_month_year}. Use this year when searching for recent docs or current events.
- Example: for "latest React docs", include the current year in the query, not the previous year.

{get_sources_reminder()}
"""


# 模型可见工具描述（StructuredTool.description）；与 CC 的 getWebSearchPrompt 信息密度对齐。
DESCRIPTION: str = build_description()

__all__ = [
    "TOOL_NAME",
    "DESCRIPTION",
    "build_description",
    "get_sources_reminder",
]
