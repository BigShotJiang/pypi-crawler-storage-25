"""
task_get/prompt.py — TaskGet 工具的提示词

职责：
    提供 TaskGetRuntimeTool 的工具名称和描述提示词

链路位置：
    ToolRuntime.name / ToolRuntime.description → LLM 工具调用

当前裁剪范围：
    - v1: 完整迁移 CC 提示词
    - 仅调整工具名称引用

CC 源码：
    - C:/git_code/claude-code-main-ghuntley-03-31/src/tools/TaskGetTool/prompt.ts
"""

TOOL_NAME = "TaskGet"

DESCRIPTION = "Get a task by ID from the task list"

PROMPT = """Use this tool to retrieve a task by its ID from the task list.

## When to Use This Tool

- When you need the full description and context before starting work on a task
- To understand task dependencies (what it blocks, what blocks it)
- After being assigned a task, to get complete requirements

## Output

Returns full task details:
- **subject**: Task title
- **description**: Detailed requirements and context
- **status**: 'pending', 'in_progress', or 'completed'
- **blocks**: Tasks waiting on this one to complete
- **blockedBy**: Tasks that must complete before this one can start

## Tips

- After fetching a task, verify its blockedBy list is empty before beginning work.
- Use TaskList to see all tasks in summary form.
"""
