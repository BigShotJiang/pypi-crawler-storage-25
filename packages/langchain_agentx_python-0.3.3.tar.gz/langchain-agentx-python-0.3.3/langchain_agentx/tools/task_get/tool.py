"""
task_get/tool.py — TaskGetRuntimeTool 工具实现

职责：
    按 ID 检索任务详情，返回完整任务信息或 None

链路位置：
    ToolExecutorPipeline → validate_input → check_permissions → invoke → present

当前裁剪范围：
    - v1: 基础的按 ID 获取功能
    - 不包含批量获取、分页等高级功能

CC 源码：
    - C:/git_code/claude-code-main-ghuntley-03-31/src/tools/TaskGetTool/TaskGetTool.ts
"""

from pathlib import Path
from typing import Any, Literal, Optional

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.workspace import AgentWorkspaceConfig

from .models import TaskGetInput, TaskGetOutput, TaskDetails
from .prompt import TOOL_NAME, DESCRIPTION
from langchain_agentx.task_runtime.tasklist import TaskStoreSync


class TaskGetRuntimeTool(RuntimeTool):
    """任务获取工具（按 ID 检索）"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = TaskGetInput
    is_read_only: bool = True
    is_concurrency_safe: bool = True

    def __init__(self, config: Optional[AgentWorkspaceConfig] = None) -> None:
        super().__init__()
        self._store = TaskStoreSync(config=config)

    def validate_input(self, data: TaskGetInput) -> ValidationResult:
        """校验输入

        taskId 基本校验：
        - 非空
        - 格式合理（纯数字或字母数字组合）
        """
        errors = []

        if not data.task_id.strip():
            errors.append("task_id cannot be empty")

        # 可选：验证 taskId 格式（CC 使用数字 ID）
        if data.task_id.strip() and not data.task_id.strip().isalnum():
            errors.append("task_id must be alphanumeric")

        if errors:
            return ValidationResult(ok=False, message="\n".join(errors))
        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: TaskGetInput,
        ctx: ToolExecutionContext,
        authz: AuthorizationDecision,
    ) -> None:
        """权限检查

        只读操作，默认允许。
        """
        # 只读操作，无需特殊权限检查
        pass

    def is_enabled(self, ctx: ToolExecutionContext) -> bool:
        """检查工具是否可用

        工具始终可用（tasks_dir 由 workspace 配置保证存在）。
        """
        return True

    def invoke(self, data: TaskGetInput, ctx: ToolExecutionContext) -> TaskGetOutput:
        """执行获取任务"""
        task = self._store.get_task(data.task_id)

        if task is None:
            return TaskGetOutput(task=None)

        return TaskGetOutput(
            task=TaskDetails(
                id=task.id,
                subject=task.subject,
                description=task.description,
                status=task.status,
                blocks=task.blocks or [],
                blockedBy=task.blocked_by or [],
            )
        )

    def present(self, result: TaskGetOutput, ctx: ToolExecutionContext) -> ToolResultEnvelope:
        """格式化输出"""
        if result.task is None:
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary="Task not found",
                payload={"task": None},
            )

        # 构建可读摘要
        lines = [
            f"Task #{result.task.id}: {result.task.subject}",
            f"Status: {result.task.status}",
            f"Description: {result.task.description}",
        ]

        blocked_by = result.task.blockedBy or []
        if blocked_by:
            lines.append(f"Blocked by: {', '.join(f'#{id}' for id in blocked_by)}")
        blocks = result.task.blocks or []
        if blocks:
            lines.append(f"Blocks: {', '.join(f'#{id}' for id in blocks)}")

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary="\n".join(lines),
            payload={
                "task_id": result.task.id,
                "subject": result.task.subject,
                "status": result.task.status,
                "description": result.task.description,
                "blocks": blocks,
                "blockedBy": blocked_by,
            },
        )
