"""
task_get — TaskGetRuntimeTool 工具模块

提供按 ID 检索任务详情的功能。
"""

from .tool import TaskGetRuntimeTool

__all__ = ["TaskGetRuntimeTool"]
