"""
task_get/models.py — TaskGet 工具的数据模型

职责：
    定义 TaskGetRuntimeTool 的输入输出 Pydantic 模型

链路位置：
    ToolExecutorPipeline → normalize_input → validate_input → invoke → present

当前裁剪范围：
    - v1: 基础的 TaskGetInput/Output 模型
    - 不包含分页、过滤等高级查询功能
"""

from pydantic import BaseModel, Field
from typing import Literal


class TaskGetInput(BaseModel):
    """TaskGet 工具输入"""
    task_id: str = Field(
        description="The ID of the task to retrieve",
        examples=["1", "2", "42"],
    )


class TaskDetails(BaseModel):
    """任务详情（完整）"""
    id: str
    subject: str
    description: str
    status: Literal["pending", "in_progress", "completed"]
    blocks: list[str] = []
    blockedBy: list[str] = []


class TaskGetOutput(BaseModel):
    """TaskGet 工具输出"""
    task: TaskDetails | None
