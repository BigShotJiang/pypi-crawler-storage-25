"""
tools/webfetch/preapproved.py — WebFetch 预批准域名列表

职责：
    维护 CC WebFetchTool/preapproved.ts 对等的预批准主机集合；
    提供 is_preapproved_host / is_preapproved_url（精确主机 + 路径前缀，如 github.com/anthropics）。

链路位置：
    WebFetchRuntimeTool.check_permissions 与摘要策略（预批准域名宽松引用）。

裁剪范围：
    列表从 CC 迁移；未提供通过环境变量扩展域名（计划 R5，v2）。
"""

from __future__ import annotations

from urllib.parse import urlparse

# 与 CC PREAPPROVED_HOSTS 对齐（GET-only 文档类域名例外列表）
_PREAPPROVED_RAW: frozenset[str] = frozenset(
    {
        "platform.claude.com",
        "code.claude.com",
        "modelcontextprotocol.io",
        "github.com/anthropics",
        "agentskills.io",
        "docs.python.org",
        "en.cppreference.com",
        "docs.oracle.com",
        "learn.microsoft.com",
        "developer.mozilla.org",
        "go.dev",
        "pkg.go.dev",
        "www.php.net",
        "docs.swift.org",
        "kotlinlang.org",
        "ruby-doc.org",
        "doc.rust-lang.org",
        "www.typescriptlang.org",
        "react.dev",
        "angular.io",
        "vuejs.org",
        "nextjs.org",
        "expressjs.com",
        "nodejs.org",
        "bun.sh",
        "jquery.com",
        "getbootstrap.com",
        "tailwindcss.com",
        "d3js.org",
        "threejs.org",
        "redux.js.org",
        "webpack.js.org",
        "jestjs.io",
        "reactrouter.com",
        "docs.djangoproject.com",
        "flask.palletsprojects.com",
        "fastapi.tiangolo.com",
        "pandas.pydata.org",
        "numpy.org",
        "www.tensorflow.org",
        "pytorch.org",
        "scikit-learn.org",
        "matplotlib.org",
        "requests.readthedocs.io",
        "jupyter.org",
        "laravel.com",
        "symfony.com",
        "wordpress.org",
        "docs.spring.io",
        "hibernate.org",
        "tomcat.apache.org",
        "gradle.org",
        "maven.apache.org",
        "asp.net",
        "dotnet.microsoft.com",
        "nuget.org",
        "blazor.net",
        "reactnative.dev",
        "docs.flutter.dev",
        "developer.apple.com",
        "developer.android.com",
        "keras.io",
        "spark.apache.org",
        "huggingface.co",
        "www.kaggle.com",
        "www.mongodb.com",
        "redis.io",
        "www.postgresql.org",
        "dev.mysql.com",
        "www.sqlite.org",
        "graphql.org",
        "prisma.io",
        "docs.aws.amazon.com",
        "cloud.google.com",
        "kubernetes.io",
        "www.docker.com",
        "www.terraform.io",
        "www.ansible.com",
        "vercel.com/docs",
        "docs.netlify.com",
        "devcenter.heroku.com",
        "cypress.io",
        "selenium.dev",
        "docs.unity.com",
        "docs.unrealengine.com",
        "git-scm.com",
        "nginx.org",
        "httpd.apache.org",
    }
)


def _split_entries() -> tuple[frozenset[str], dict[str, tuple[str, ...]]]:
    host_only: set[str] = set()
    path_prefixes: dict[str, list[str]] = {}
    for entry in _PREAPPROVED_RAW:
        if "/" in entry:
            host, path = entry.split("/", 1)
            path = "/" + path
            path_prefixes.setdefault(host, []).append(path)
        else:
            host_only.add(entry)
    frozen_prefixes = {h: tuple(p) for h, p in path_prefixes.items()}
    return frozenset(host_only), frozen_prefixes


_HOSTNAME_ONLY, _PATH_PREFIXES = _split_entries()


def is_preapproved_host(hostname: str, pathname: str) -> bool:
    """与 CC isPreapprovedHost 对齐：整站主机名或路径前缀匹配。"""
    if hostname in _HOSTNAME_ONLY:
        return True
    prefixes = _PATH_PREFIXES.get(hostname)
    if not prefixes:
        return False
    path = pathname or "/"
    if not path.startswith("/"):
        path = "/" + path
    for p in prefixes:
        if path == p or path.startswith(p + "/"):
            return True
    return False


def is_preapproved_url(url: str) -> bool:
    """解析 URL 后调用 is_preapproved_host。"""
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    pathname = parsed.path or "/"
    return is_preapproved_host(host, pathname)
