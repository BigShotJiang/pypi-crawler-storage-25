"""
tools/webfetch/loader.py — 将 WebFetchRuntimeTool 注册到 ToolRuntimeLoader

职责：
    无额外环境门控时注册 WebFetch（HTTP 客户端由运行时解析）；失败静默 no-op。

链路位置：
    ToolRuntimeLoader.register_default_tools → webfetch.register(loader)。

裁剪范围：
    不含按 workspace 关闭 WebFetch 的细粒度策略（由 PolicyEngine + network_access_allowed 承担）。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_agentx.tools.webfetch.tool import WebFetchRuntimeTool

if TYPE_CHECKING:
    from langchain_agentx.tool_runtime.loader import ToolRuntimeLoader


def register(loader: ToolRuntimeLoader) -> None:
    """注册 ``WebFetch`` 工具。"""
    loader.register(WebFetchRuntimeTool())


def is_enabled() -> bool:
    """进程级门控：默认可用（依赖系统网络与策略）。"""
    return True


__all__ = ["register", "is_enabled"]
