"""
tools/webfetch/prompt.py — WebFetch 工具描述与摘要提示词

职责：
    暴露 TOOL_NAME、DESCRIPTION（自 CC prompt.ts 迁移）及 build_summary_prompt，
    供 WebFetchRuntimeTool 与轻量摘要模型构造用户消息。

链路位置：
    tool.py 注册 StructuredTool；invoke 阶段调用摘要模型前组装 prompt。

裁剪范围：
    与 CC makeSecondaryModelPrompt 语义对齐；未接入「优先 MCP web fetch」的运行时分支文案。
"""

from __future__ import annotations

TOOL_NAME = "WebFetch"

# 自 CC src/tools/WebFetchTool/prompt.ts DESCRIPTION 迁移（未改字句）
DESCRIPTION = """
- Fetches content from a specified URL and processes it using an AI model
- Takes a URL and a prompt as input
- Fetches the URL content, converts HTML to markdown
- Processes the content with the prompt using a small, fast model
- Returns the model's response about the content
- Use this tool when you need to retrieve and analyze web content

Usage notes:
  - IMPORTANT: If an MCP-provided web fetch tool is available, prefer using that tool instead of this one, as it may have fewer restrictions.
  - The URL must be a fully-formed valid URL
  - HTTP URLs will be automatically upgraded to HTTPS
  - The prompt should describe what information you want to extract from the page
  - This tool is read-only and does not modify any files
  - Results may be summarized if the content is very large
  - Includes a self-cleaning 15-minute cache for faster responses when repeatedly accessing the same URL
  - When a URL redirects to a different host, the tool will inform you and provide the redirect URL in a special format. You should then make a new WebFetch request with the redirect URL to fetch the content.
  - For GitHub URLs, prefer using the gh CLI via Bash instead (e.g., gh pr view, gh issue view, gh api).
""".strip()


def build_summary_prompt(*, is_preapproved: bool, content: str, user_prompt: str) -> str:
    """
    构造送入摘要模型的完整提示（对齐 CC makeSecondaryModelPrompt）。

    Args:
        is_preapproved: 是否命中预批准域名（决定引用长度与法律声明等约束）。
        content: 已转 Markdown（或截断后）的页面正文。
        user_prompt: 用户 / Agent 传入的提取意图说明。
    """
    if is_preapproved:
        guidelines = (
            "Provide a concise response based on the content above. Include relevant details, "
            "code examples, and documentation excerpts as needed."
        )
    else:
        guidelines = """Provide a concise response based only on the content above. In your response:
 - Enforce a strict 125-character maximum for quotes from any source document. Open Source Software is ok as long as we respect the license.
 - Use quotation marks for exact language from articles; any language outside of the quotation should never be word-for-word the same.
 - You are not a lawyer and never comment on the legality of your own prompts and responses.
 - Never produce or reproduce exact song lyrics."""

    return f"""
Web page content:
---
{content}
---

{user_prompt}

{guidelines}
""".strip()
