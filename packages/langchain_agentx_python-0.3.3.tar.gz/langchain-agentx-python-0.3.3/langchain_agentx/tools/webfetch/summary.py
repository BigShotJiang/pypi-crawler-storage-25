"""
tools/webfetch/summary.py — 默认摘要模型包装

职责：
    将 LangChain BaseChatModel 包装为 WebFetchRuntimeTool 所需的 ``Callable[[str], str]``。

链路位置：
    宿主构造 ``WebFetchRuntimeTool(summary_model_fn=default_summary_model_fn(llm))``。

裁剪范围：
    不含自动重试/超时（由调用方 LLM 配置或外层中间件承担）。
"""

from __future__ import annotations

from collections.abc import Callable

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage

from langchain_agentx.tools.webfetch.tool import SummaryModelFn


def default_summary_model_fn(llm: BaseChatModel) -> SummaryModelFn:
    """返回接收 ``build_summary_prompt`` 全文、输出摘要字符串的函数。"""

    def _fn(full_prompt: str) -> str:
        msg = llm.invoke([HumanMessage(content=full_prompt)])
        c = msg.content
        return c if isinstance(c, str) else str(c)

    return _fn


__all__ = ["default_summary_model_fn"]
