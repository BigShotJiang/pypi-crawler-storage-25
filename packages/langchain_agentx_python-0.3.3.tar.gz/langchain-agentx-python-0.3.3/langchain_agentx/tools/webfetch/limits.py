"""
tools/webfetch/limits.py — WebFetchRuntimeTool 资源与缓存上限

职责：
    定义抓取超时、URL/正文长度、重定向次数、LRU 缓存 TTL 与容量等常量；
    全部支持环境变量覆盖（WEBFETCH_TOOL_*），便于测试与部署调参。

链路位置：
    被 webfetch/models.py（校验 URL 长度）、后续 FetchBackend / CacheManager 读取。

裁剪范围：
    v1 不含 CC 的 DOMAIN_CHECK_TIMEOUT_MS（外部域名预检 v2 计划）。
"""

from __future__ import annotations

import os

_FETCH_TIMEOUT_DEFAULT = "60"
_MAX_URL_LEN_DEFAULT = "2000"
_MAX_HTTP_CONTENT_DEFAULT = str(10 * 1024 * 1024)
_MAX_MARKDOWN_DEFAULT = str(100_000)
_MAX_REDIRECTS_DEFAULT = "10"
_CACHE_TTL_DEFAULT = "900"
_CACHE_MAX_BYTES_DEFAULT = str(50 * 1024 * 1024)


def _int_env(name: str, default: str) -> int:
    raw = os.getenv(name, default)
    try:
        return int(raw)
    except ValueError:
        return int(default)


FETCH_TIMEOUT_SEC = _int_env("WEBFETCH_TOOL_FETCH_TIMEOUT_SEC", _FETCH_TIMEOUT_DEFAULT)
"""HTTP 单次请求超时（秒），对齐 CC FETCH_TIMEOUT_MS = 60_000。"""

MAX_URL_LENGTH = _int_env("WEBFETCH_TOOL_MAX_URL_LENGTH", _MAX_URL_LEN_DEFAULT)
"""URL 最大字符长度。"""

MAX_HTTP_CONTENT_LENGTH = _int_env(
    "WEBFETCH_TOOL_MAX_HTTP_CONTENT_LENGTH",
    _MAX_HTTP_CONTENT_DEFAULT,
)
"""下载正文上限（字节），默认 10MB。"""

MAX_MARKDOWN_LENGTH = _int_env(
    "WEBFETCH_TOOL_MAX_MARKDOWN_LENGTH",
    _MAX_MARKDOWN_DEFAULT,
)
"""转 Markdown 后参与摘要前的截断点（字符）。"""

MAX_REDIRECTS = _int_env("WEBFETCH_TOOL_MAX_REDIRECTS", _MAX_REDIRECTS_DEFAULT)
"""同域重定向最大跟随次数。"""

CACHE_TTL_SEC = _int_env("WEBFETCH_TOOL_CACHE_TTL_SEC", _CACHE_TTL_DEFAULT)
"""URL 缓存 TTL（秒），默认 15 分钟。"""

CACHE_MAX_SIZE_BYTES = _int_env(
    "WEBFETCH_TOOL_CACHE_MAX_SIZE_BYTES",
    _CACHE_MAX_BYTES_DEFAULT,
)
"""URL 缓存总容量上限（字节），默认 50MB。"""
