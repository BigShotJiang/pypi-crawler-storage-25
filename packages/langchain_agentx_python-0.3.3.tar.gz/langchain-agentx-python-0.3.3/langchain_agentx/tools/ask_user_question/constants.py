"""
tools/ask_user_question/constants.py — v3 长度与 present 截断常量

职责：
    集中定义 preview / 用户注释 / present 摘要上限，供校验与 present 共用。

链路位置：
    models.Field、QuestionValidator / HtmlPreviewValidator、AskUserQuestionTool.present。

当前裁剪范围：
    数值对齐设计文档 §4.5 / §3.8.5；若与 CC 产品统一后仅改此处与单测。
"""

from __future__ import annotations

# validate_input：工具入参 preview 片段（HTML 或 Markdown 原文）
MAX_TOOL_PREVIEW_CHARS: int = 8192

# validate_input：annotations.userNote
MAX_USER_NOTE_CHARS: int = 4096

# validate_input：annotations.selectedPreviewSnapshot（宿主回灌）
MAX_PREVIEW_SNAPSHOT_CHARS: int = 8192

# present()：每段 preview / snapshot 写入模型可见文本时的默认截断
PRESENT_PREVIEW_SNIPPET_MAX: int = 500
