"""
tools/ask_user_question/html_preview.py — HTML preview 片段校验（v3）

职责：
    在 ``question_preview_format == html`` 时对 ``QuestionOption.preview`` 做 fail-fast 校验；
    对齐设计 §3.8.4（保守白名单 + 危险属性/协议拒绝），非完整 XSS 防护。

链路位置：
    AskUserQuestionTool.validate_input 在结构校验通过后调用。

当前裁剪范围：
    与 CC ``validateHtmlPreview`` 逐行对齐留待 Phase 对照；当前实现覆盖常见注入面与标签子集。
"""

from __future__ import annotations

import re
from html.parser import HTMLParser

from langchain_agentx.tool_runtime.models import ValidationResult


class HtmlPreviewValidator:
    """HTML preview 片段校验（OOP 单类）。"""

    _ALLOWED_TAGS: frozenset[str] = frozenset(
        {
            "p",
            "br",
            "b",
            "strong",
            "i",
            "em",
            "code",
            "pre",
            "span",
            "div",
            "ul",
            "ol",
            "li",
            "a",
            "h1",
            "h2",
            "h3",
            "h4",
            "blockquote",
        }
    )

    _BAN_SUBSTRINGS: tuple[str, ...] = (
        "<script",
        "</script",
        "<iframe",
        "javascript:",
        "data:text/html",
        "vbscript:",
    )

    def validate(self, html: str) -> ValidationResult:
        if not html or not html.strip():
            return ValidationResult(ok=True)
        lowered = html.lower()
        for bad in self._BAN_SUBSTRINGS:
            if bad in lowered:
                return ValidationResult(
                    ok=False,
                    message=f"HTML preview contains forbidden pattern: {bad!r}",
                    code="ILLEGAL_HTML_PREVIEW",
                )
        if re.search(r"\son[a-z]+\s*=", lowered):
            return ValidationResult(
                ok=False,
                message="HTML preview contains inline event handler attributes",
                code="ILLEGAL_HTML_PREVIEW",
            )
        try:
            parser = _PreviewHTMLParser(self._ALLOWED_TAGS)
            parser.feed(html)
            parser.close()
        except _PreviewHTMLReject as e:
            return ValidationResult(
                ok=False,
                message=str(e),
                code="ILLEGAL_HTML_PREVIEW",
            )
        except Exception as e:  # pragma: no cover - defensive
            return ValidationResult(
                ok=False,
                message=f"HTML preview parse error: {e}",
                code="ILLEGAL_HTML_PREVIEW",
            )
        return ValidationResult(ok=True)


class _PreviewHTMLReject(Exception):
    """内部：禁止的标签或属性。"""


class _PreviewHTMLParser(HTMLParser):
    def __init__(self, allowed: frozenset[str]) -> None:
        super().__init__(convert_charrefs=True)
        self._allowed = allowed

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        t = tag.lower()
        if t not in self._allowed:
            raise _PreviewHTMLReject(f"disallowed tag: {tag}")
        for name, value in attrs:
            nl = name.lower()
            if nl.startswith("on"):
                raise _PreviewHTMLReject(f"disallowed attribute: {name}")
            if nl == "style":
                v = (value or "").lower()
                if "javascript" in v or "expression" in v:
                    raise _PreviewHTMLReject("disallowed style content")
            if nl == "href" and value:
                v2 = value.strip().lower()
                if v2.startswith("javascript:") or v2.startswith("vbscript:"):
                    raise _PreviewHTMLReject("disallowed href protocol")

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
