"""
tools/ask_user_question/validators.py — QuestionValidator

职责：
    封装单题与整卷语义校验（问号、选项数、label 唯一、multiSelect v2 约束等）。

链路位置：
    AskUserQuestionTool.validate_input 委托本类。

当前裁剪范围：
    含 preview 长度（dict 路径，与 Pydantic max_length 双保险）；HTML 规则在 HtmlPreviewValidator（v3）。

"""

from __future__ import annotations

from typing import Any

from langchain_agentx.tool_runtime.models import ValidationResult

from .constants import MAX_TOOL_PREVIEW_CHARS


class QuestionValidator:
    """单题校验（OOP 协作者）。"""

    def validate_question(self, question: dict[str, Any], *, index: int) -> ValidationResult:
        if "question" not in question:
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: missing 'question' field",
                code="MISSING_QUESTION_FIELD",
            )
        question_text = question["question"]
        if not isinstance(question_text, str) or not question_text.endswith("?"):
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: '{question_text}' must end with '?'",
                code="QUESTION_NO_QUESTION_MARK",
            )

        header = question.get("header", "")
        if not isinstance(header, str) or not header.strip():
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: 'header' is required",
                code="MISSING_HEADER",
            )
        if len(header) > 12:
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: header must be at most 12 characters",
                code="HEADER_TOO_LONG",
            )

        options = question.get("options", [])
        if not isinstance(options, list) or not (2 <= len(options) <= 4):
            return ValidationResult(
                ok=False,
                message=(
                    f"Question at index {index}: must have 2-4 options, "
                    f"got {len(options) if isinstance(options, list) else 'invalid'}"
                ),
                code="INVALID_OPTION_COUNT",
            )

        labels: list[str] = []
        for opt in options:
            if not isinstance(opt, dict):
                return ValidationResult(
                    ok=False,
                    message=f"Question at index {index}: each option must be an object",
                    code="INVALID_OPTION_SHAPE",
                )
            lab = opt.get("label", "")
            if not isinstance(lab, str) or not lab.strip():
                return ValidationResult(
                    ok=False,
                    message=f"Question at index {index}: each option needs non-empty label",
                    code="MISSING_OPTION_LABEL",
                )
            labels.append(lab)
            pv = opt.get("preview", None)
            if pv is not None:
                if not isinstance(pv, str):
                    return ValidationResult(
                        ok=False,
                        message=f"Question at index {index}: preview must be a string or null",
                        code="INVALID_PREVIEW_TYPE",
                    )
                if len(pv) > MAX_TOOL_PREVIEW_CHARS:
                    return ValidationResult(
                        ok=False,
                        message=(
                            f"Question at index {index}: preview exceeds "
                            f"{MAX_TOOL_PREVIEW_CHARS} characters"
                        ),
                        code="PREVIEW_TOO_LONG",
                    )
        if len(labels) != len(set(labels)):
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: option labels must be unique",
                code="DUPLICATE_OPTION_LABEL",
            )

        desc_ok = True
        for opt in options:
            d = opt.get("description", None)
            if not isinstance(d, str) or not d.strip():
                desc_ok = False
                break
        if not desc_ok:
            return ValidationResult(
                ok=False,
                message=f"Question at index {index}: each option needs non-empty description",
                code="MISSING_OPTION_DESCRIPTION",
            )

        return ValidationResult(ok=True)

    def validate_questions_payload(self, data: dict[str, Any]) -> ValidationResult:
        """整卷：数量、题目文本唯一、逐题校验。"""
        questions = data.get("questions", [])
        if not isinstance(questions, list):
            return ValidationResult(
                ok=False,
                message="questions must be a list",
                code="INVALID_QUESTIONS_TYPE",
            )
        if not (1 <= len(questions) <= 4):
            return ValidationResult(
                ok=False,
                message=f"Must have 1-4 questions, got {len(questions)}.",
                code="INVALID_QUESTION_COUNT",
            )

        question_texts = [q.get("question", "") for q in questions if isinstance(q, dict)]
        if len(question_texts) != len(set(question_texts)):
            return ValidationResult(
                ok=False,
                message="Question texts must be unique.",
                code="DUPLICATE_QUESTION_TEXT",
            )

        for i, q in enumerate(questions):
            if not isinstance(q, dict):
                return ValidationResult(
                    ok=False,
                    message=f"Question at index {i}: must be an object",
                    code="INVALID_QUESTION_SHAPE",
                )
            per = self.validate_question(q, index=i)
            if not per.ok:
                return per

        return ValidationResult(ok=True)
