"""
tools/ask_user_question/models.py — AskUserQuestion 输入 / 输出 Pydantic 模型

职责：
    定义 questions / answers / annotations 结构；与 CC zod schema 及设计文档 §7.1 对齐。

链路位置：
    AskUserQuestionTool.input_model / output_model / invoke 返回值。

当前裁剪范围：
    v3：QuestionAnnotation、preview 字段；annotations 字段名与 CC 校对见设计 §3.8.3。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .constants import (
    MAX_PREVIEW_SNAPSHOT_CHARS,
    MAX_TOOL_PREVIEW_CHARS,
    MAX_USER_NOTE_CHARS,
    PRESENT_PREVIEW_SNIPPET_MAX,
)


class QuestionOption(BaseModel):
    """单个选项（CC QuestionOption）。"""

    label: str = Field(
        ...,
        description="The display text for this option (1-5 words).",
    )
    description: str = Field(
        ...,
        description="Explanation of what this option means.",
    )
    preview: str | None = Field(
        None,
        description="Optional rich snippet (Markdown or HTML); format from ToolExecutionContext.",
        max_length=MAX_TOOL_PREVIEW_CHARS,
    )


class QuestionAnnotation(BaseModel):
    """v3：单题用户注释（键为题干文本）。"""

    userNote: str | None = Field(
        None,
        max_length=MAX_USER_NOTE_CHARS,
        description="Free-form user note for this question.",
    )
    selectedPreviewSnapshot: str | None = Field(
        None,
        max_length=MAX_PREVIEW_SNAPSHOT_CHARS,
        description="Host-provided preview snapshot (prefer plain text / sanitized).",
    )


class Question(BaseModel):
    """单题（CC Question）。"""

    question: str = Field(
        ...,
        description='The complete question to ask the user (should end with "?").',
    )
    header: str = Field(
        ...,
        max_length=12,
        description="Very short label displayed as a chip/tag (max 12 chars).",
    )
    options: list[QuestionOption] = Field(
        ...,
        min_length=2,
        max_length=4,
    )
    multiSelect: bool = Field(
        default=False,
        description="True when multiple options may be selected (comma-separated answers).",
    )


class AskUserQuestionInput(BaseModel):
    """工具输入。"""

    questions: list[Question] = Field(..., min_length=1, max_length=4)
    answers: dict[str, str] = Field(
        default_factory=dict,
        description="User answers keyed by question text (CC permission flow).",
    )
    annotations: dict[str, QuestionAnnotation] = Field(
        default_factory=dict,
        description="Optional v3; keys must match question texts in this batch.",
    )


class AskUserQuestionOutput(BaseModel):
    """工具成功输出。"""

    questions: list[Question]
    answers: dict[str, str]
    annotations: dict[str, QuestionAnnotation] = Field(default_factory=dict)

    def model_dump_for_present(self) -> dict[str, Any]:
        """present() 使用的扁平 dict。"""
        return {
            "questions": [q.model_dump() for q in self.questions],
            "answers": dict(self.answers),
            "annotations": {k: v.model_dump() for k, v in self.annotations.items()},
        }


__all__ = [
    "AskUserQuestionInput",
    "AskUserQuestionOutput",
    "Question",
    "QuestionAnnotation",
    "QuestionOption",
]
