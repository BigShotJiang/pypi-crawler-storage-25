"""
tools/ask_user_question/prompt.py — AskUserQuestion 工具文案

职责：
    从 CC ``prompt.ts`` 迁移面向模型的 DESCRIPTION / 扩展 PROMPT（与 CC 一致）。

链路位置：
    AskUserQuestionTool.description；StructuredTool 暴露给 LLM。

当前裁剪范围：
    含 v3 ``DESCRIPTION_V3_APPEND``；与 CC 原文 diff 见 PR / 设计 §3.7.3。
"""

from __future__ import annotations

# CC: ASK_USER_QUESTION_TOOL_NAME
TOOL_NAME = "AskUserQuestion"

# CC prompt.ts DESCRIPTION（原文）
DESCRIPTION = (
    "Asks the user multiple choice questions to gather information, clarify ambiguity, "
    "understand preferences, make decisions or offer them choices."
)

# CC ASK_USER_QUESTION_TOOL_PROMPT；${EXIT_PLAN_MODE_TOOL_NAME} → ExitPlanMode（CC constants.ts）
ASK_USER_QUESTION_TOOL_PROMPT = """Use this tool when you need to ask the user questions during execution. This allows you to:
1. Gather user preferences or requirements
2. Clarify ambiguous instructions
3. Get decisions on implementation choices as you work
4. Offer choices to the user about what direction to take.

Usage notes:
- Users will always be able to select "Other" to provide custom text input
- Use multiSelect: true to allow multiple answers to be selected for a question
- If you recommend a specific option, make that the first option in the list and add "(Recommended)" at the end of the label

Plan mode note: In plan mode, use this tool to clarify requirements or choose between approaches BEFORE finalizing your plan. Do NOT use this tool to ask "Is my plan ready?" or "Should I proceed?" - use ExitPlanMode for plan approval. IMPORTANT: Do not reference "the plan" in your questions (e.g., "Do you have feedback about the plan?", "Does the plan look good?") because the user cannot see the plan in the UI until you call ExitPlanMode. If you need plan approval, use ExitPlanMode instead.
"""

# v3 SDK：追加到 DESCRIPTION 段落后（英文；不写并排 UI；设计 §3.7.3）
DESCRIPTION_V3_APPEND = """Preview / format (SDK v3):
- Each QuestionOption may include an optional `preview` string: a short rich snippet (Markdown or HTML) for the host UI. Do not put secrets in `preview`.
- Whether `preview` is interpreted as Markdown or HTML is determined by the host via `ToolExecutionContext.question_preview_format` (not repeated in tool args). When the host selects HTML, invalid HTML in any `preview` causes validation to fail for the entire tool call.
- Optional `annotations` (keyed by exact question text) may be supplied together with `answers` on the second hop; keys must be a subset of the asked questions. Structure is `{ userNote?: string, selectedPreviewSnapshot?: string }` per question (field names are stable in this SDK; confirm against CC when migrating).
"""
