"""
tools/ask_user_question — AskUserQuestionTool 包

职责：
    导出 AskUserQuestionTool；与 CC AskUserQuestion 对齐（v1+v2 能力合入本包）。

链路位置：
    ToolRuntimeLoader.register_default_tools。

当前裁剪范围：
    无独立 runtime_config；annotations / HTML preview 未实现（v3）。
"""

from __future__ import annotations

from .tool import AskUserQuestionTool

__all__ = ["AskUserQuestionTool"]
