"""
task_list/tool.py — TaskListRuntimeTool

职责：
    列出当前任务列表中的任务摘要；读路径仅经 TaskStoreSync.list_tasks

链路位置：
    ToolExecutorPipeline → validate_input → check_permissions → invoke → present

当前裁剪范围：
    - v1：无 staleness 附加文案；blockedBy 仅保留未完成的阻塞项

CC 源码：
    - C:/git_code/claude-code-main-ghuntley-03-31/src/tools/TaskListTool/TaskListTool.ts
"""

from __future__ import annotations

from typing import Optional

from langchain_agentx.task_runtime.tasklist import Task, TaskFilters, TaskStoreSync
from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.workspace import AgentWorkspaceConfig

from .models import (
    TaskListFiltersInput,
    TaskListInput,
    TaskListOutput,
    TaskSummary,
)
from .prompt import DESCRIPTION, TOOL_NAME


class TaskListRuntimeTool(RuntimeTool):
    """任务列表工具（摘要视图）。"""

    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = TaskListInput
    is_read_only: bool = True
    is_concurrency_safe: bool = True

    def __init__(self, config: Optional[AgentWorkspaceConfig] = None) -> None:
        super().__init__()
        self._store = TaskStoreSync(config=config)

    @staticmethod
    def _to_dataclass_filters(data: TaskListInput) -> TaskFilters:
        if data.filters is None:
            return TaskFilters()
        f: TaskListFiltersInput = data.filters
        return TaskFilters(
            status=f.status,
            owner=f.owner,
            exclude_internal=f.exclude_internal,
        )

    @staticmethod
    def _open_blockers(store: TaskStoreSync, task: Task) -> list[str]:
        """blockedBy 中仅保留「仍存在且未完成」的阻塞项。"""
        out: list[str] = []
        for bid in task.blocked_by:
            blocker = store.get_task(bid)
            if blocker is not None and blocker.status != "completed":
                out.append(bid)
        return out

    def validate_input(self, data: TaskListInput) -> ValidationResult:
        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: TaskListInput,
        ctx: ToolExecutionContext,
        authz: AuthorizationDecision,
    ) -> None:
        pass

    def is_enabled(self, ctx: ToolExecutionContext) -> bool:
        return True

    def invoke(self, data: TaskListInput, ctx: ToolExecutionContext) -> TaskListOutput:
        filters = self._to_dataclass_filters(data)
        count_filters = TaskFilters(
            status=filters.status,
            owner=filters.owner,
            exclude_internal=False,
        )
        all_for_total = self._store.list_tasks(count_filters)
        total_count = len(all_for_total)
        tasks = self._store.list_tasks(filters)
        summaries = [
            TaskSummary(
                id=t.id,
                subject=t.subject,
                status=t.status,
                owner=t.owner,
                blockedBy=self._open_blockers(self._store, t),
            )
            for t in tasks
        ]
        return TaskListOutput(
            tasks=summaries,
            total_count=total_count,
            filtered_count=len(summaries),
        )

    def present(self, result: TaskListOutput, ctx: ToolExecutionContext) -> ToolResultEnvelope:
        lines: list[str] = [
            f"Tasks: {result.filtered_count} shown (same status/owner scope incl. internal: {result.total_count})",
        ]
        for t in result.tasks:
            extra = []
            if t.owner:
                extra.append(f"owner={t.owner}")
            if t.blockedBy:
                extra.append(f"blockedBy={','.join('#' + x for x in t.blockedBy)}")
            suffix = f" ({'; '.join(extra)})" if extra else ""
            lines.append(f"#{t.id} [{t.status}] {t.subject}{suffix}")

        payload_tasks = [
            {
                "id": t.id,
                "subject": t.subject,
                "status": t.status,
                "owner": t.owner,
                "blockedBy": t.blockedBy,
            }
            for t in result.tasks
        ]
        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary="\n".join(lines),
            payload={
                "tasks": payload_tasks,
                "total_count": result.total_count,
                "filtered_count": result.filtered_count,
            },
        )
