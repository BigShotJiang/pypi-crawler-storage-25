"""
task_list/models.py — TaskList 工具 IO 模型

职责：
    定义 TaskListRuntimeTool 的 Pydantic 输入输出（摘要列表视图）

链路位置：
    ToolExecutorPipeline → validate_input → invoke → present

当前裁剪范围：
    - v1：可选 filters 映射到 task_runtime.tasklist.TaskFilters
    - 不含 staleness 文案（设计中的可选项，后续迭代）
"""

from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class TaskListFiltersInput(BaseModel):
    """与 TaskFilters 对齐的可选过滤（工具输入侧）。"""

    status: Optional[Literal["pending", "in_progress", "completed"]] = Field(
        default=None,
        description="Only include tasks in this status",
    )
    owner: Optional[str] = Field(
        default=None,
        description="Only include tasks with this owner",
    )
    exclude_internal: bool = Field(
        default=True,
        description="Exclude tasks with metadata._internal=true",
    )


class TaskListInput(BaseModel):
    """TaskList 工具输入。"""

    filters: Optional[TaskListFiltersInput] = Field(
        default=None,
        description="Optional filters; default lists non-internal tasks",
    )


class TaskSummary(BaseModel):
    """列表视图任务摘要（与 tasklist-tool-migration-v2 对齐）。"""

    id: str
    subject: str
    status: Literal["pending", "in_progress", "completed"]
    owner: Optional[str] = None
    blockedBy: list[str] = Field(
        default_factory=list,
        description="Open blockers only (blocker task exists and not completed)",
    )


class TaskListOutput(BaseModel):
    """TaskList 工具输出。"""

    tasks: list[TaskSummary]
    total_count: int = Field(description="Count before exclude_internal filter")
    filtered_count: int = Field(description="Number of tasks returned after all filters")
