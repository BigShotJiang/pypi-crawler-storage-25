"""
task_list/prompt.py — TaskList 工具提示词

职责：
    提供 TaskListRuntimeTool 的名称与 CC 对齐的描述 / 长提示

链路位置：
    RuntimeTool.name / description；扩展 PROMPT 供文档或未来注入

当前裁剪范围：
    - 文本优先对齐 CC TaskListTool/prompt.ts（略去与本工程无关的 UI 句）

CC 源码：
    - C:/git_code/claude-code-main-ghuntley-03-31/src/tools/TaskListTool/prompt.ts
"""

TOOL_NAME = "TaskList"

DESCRIPTION = "List all tasks in the task list"

PROMPT = """Use this tool to list all tasks in the task list.

## When to Use This Tool

- To see what tasks are available to work on (status: 'pending', no owner, not blocked)
- To check overall progress on the project
- To find tasks that are blocked and need dependencies resolved
- After completing a task, to check for newly unblocked work or claim the next available task
- **Prefer working on tasks in ID order** (lowest ID first) when multiple tasks are available, as earlier tasks often set up context for later ones

## Output

Returns a summary of each task:
- **id**: Task identifier (use with TaskGet, TaskUpdate)
- **subject**: Brief description of the task
- **status**: 'pending', 'in_progress', or 'completed'
- **owner**: Agent ID if assigned, empty if available
- **blockedBy**: List of open task IDs that must be resolved first (tasks with blockedBy cannot be claimed until dependencies resolve)

Use TaskGet with a specific task ID to view full details including description and comments.

## Teammate Workflow

When working as a teammate:
1. After completing your current task, call TaskList to find available work
2. Look for tasks with status 'pending', no owner, and empty blockedBy
3. **Prefer tasks in ID order** (lowest ID first) when multiple tasks are available
4. Claim an available task using TaskUpdate (set `owner` to your name), or wait for leader assignment
5. If blocked, focus on unblocking tasks or notify the team lead
"""
