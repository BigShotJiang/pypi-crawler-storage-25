"""
tools/user_message/prompt.py — UserMessageTool 工具名与描述

职责：
    工具名常量、面向模型的完整 description（CC prompt.ts / BRIEF_TOOL_PROMPT 迁移）。

链路位置：
    UserMessageTool.name / description；bind_tools 与文档生成。

当前裁剪范围：
    与 CC 的差异仅增补 Usage Guidelines（对应 CC BRIEF_PROACTIVE_SECTION）；见设计 §3.5 对照表。
"""

from __future__ import annotations

TOOL_NAME = "user_message"
"""面向模型暴露的工具名（snake_case）。"""


def get_user_message_tool_description() -> str:
    """完整工具说明（LangChain StructuredTool.description）。"""
    return """\
Send a message the user will read. Text outside this tool is visible in the detail view, but most won't open it — the answer lives here.

`message` supports markdown. `attachments` takes file paths (absolute or cwd-relative) for images, diffs, logs.

`status` labels intent: 'normal' when replying to what they just asked; 'proactive' when you're initiating — a scheduled task finished, a blocker surfaced during background work, you need input on something they haven't asked about. Set it honestly; downstream routing uses it.

**Usage Guidelines**:

- Every reply to the user should go through this tool, even simple "hi" or "thanks".
- For long-running tasks: acknowledge first → execute → send result.
- Send checkpoints for meaningful events: decisions made, surprises encountered, phase boundaries.
- Keep messages tight: the decision, the file:line, the PR number.
- Use second person ("your config"), never third person.
"""


# 模块加载时生成，供 RuntimeTool.description 绑定（与 get_user_message_tool_description 一致）
DESCRIPTION = get_user_message_tool_description()
