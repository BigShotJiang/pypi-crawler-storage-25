"""
tools/user_message/runtime_config.py — 本地 tool_runtime 特性开关解析

职责：
    从 ``tool_runtime_config.json`` 读取 ``user_message.enabled``，供 ``UserMessageTool.check_permissions`` 使用。

链路位置：
    ``UserMessageTool.check_permissions`` → ``UserMessageRuntimeConfig.load(ctx.tool_config_path)``。

当前裁剪范围：
    仅 ``user_message`` 小节；路径由 ``ctx.tool_config_path`` 提供（adapter + workspace），本模块不做路径拼接。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class UserMessageRuntimeConfig:
    """``tool_runtime_config.json`` 中 user_message 工具的运行时开关视图。"""

    enabled: bool = True

    @classmethod
    def load(cls, path: str | None) -> UserMessageRuntimeConfig:
        """
        从绝对路径加载配置。

        以下情况视为 ``enabled=True``（默认启用，与设计「配置损坏 → 默认启用」一致）：
        ``path`` 为空、文件不存在、非 UTF-8/非法 JSON、根非 object、无 ``user_message`` 对象、
        或未显式出现 ``enabled: false``。
        """
        if path is None or not str(path).strip():
            return cls()
        p = Path(path)
        if not p.is_file():
            return cls()
        try:
            raw: Any = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return cls()
        if not isinstance(raw, dict):
            return cls()
        section = raw.get("user_message")
        if not isinstance(section, dict):
            return cls()
        if section.get("enabled") is False:
            return cls(enabled=False)
        return cls()
