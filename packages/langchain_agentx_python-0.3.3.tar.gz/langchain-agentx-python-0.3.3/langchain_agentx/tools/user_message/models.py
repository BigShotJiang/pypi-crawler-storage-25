"""
tools/user_message/models.py — UserMessageTool 输入 / 输出模型

职责：
    定义 Pydantic 模型；无 I/O；与 user-message-tool-migration.md §2.3、§3.4 对齐。

链路位置：
    UserMessageTool.input_model / output_model / invoke 返回值类型。

当前裁剪范围：
    v1 无 file_uuid；附件仅为路径列表与解析元数据。
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class UserMessageInput(BaseModel):
    """UserMessageTool 输入（对应 CC BriefToolInput / SendUserMessage）。"""

    message: str = Field(
        ...,
        description="Message body shown to the user (Markdown supported).",
    )
    attachments: list[str] | None = Field(
        None,
        description="Optional list of file paths (absolute or cwd-relative) to attach.",
    )
    status: Literal["normal", "proactive"] = Field(
        "normal",
        description="normal: reply to current ask; proactive: unprompted update.",
    )


class ResolvedAttachment(BaseModel):
    """单个附件在解析后的元数据（对应 CC ResolvedAttachment，无 file_uuid v1）。"""

    path: str = Field(..., description="Absolute path to the file.")
    size: int = Field(..., description="File size in bytes.")
    is_image: bool = Field(..., description="Whether the file is treated as an image.")


class UserMessageOutput(BaseModel):
    """UserMessageTool 执行结果。"""

    message: str = Field(..., description="Echo of the message sent.")
    attachments: list[ResolvedAttachment] | None = Field(
        None,
        description="Resolved attachment metadata.",
    )
    sent_at: str | None = Field(
        None,
        description="ISO 8601 timestamp when the message was recorded.",
    )
