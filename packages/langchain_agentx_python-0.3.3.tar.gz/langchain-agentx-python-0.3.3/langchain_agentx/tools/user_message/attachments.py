"""
tools/user_message/attachments.py — 附件验证与解析

职责：
    AttachmentValidator（路径存在性、可访问性、须为常规文件）；
    AttachmentResolver（stat、图片扩展名判断）。

链路位置：
    UserMessageTool.validate_input / invoke 委托本模块协作者类。

当前裁剪范围：
    无云端上传、无 file_uuid（见 user-message-tool-migration.md §1.4）。
"""

from __future__ import annotations

import re
import stat as stat_mod
from pathlib import Path

from langchain_agentx.tool_runtime.models import ValidationResult

from .models import ResolvedAttachment

# 对齐 CC utils/imagePaste.ts IMAGE_EXTENSION_REGEX
IMAGE_EXTENSION_PATTERN = re.compile(r"\.(png|jpe?g|gif|bmp|webp)$", re.IGNORECASE)


class AttachmentValidator:
    """验证单个附件路径（对齐 CC attachments.ts::validateAttachmentPaths 单路径语义）。"""

    def validate(
        self,
        path_str: str,
        *,
        cwd_hint: str | None = None,
    ) -> ValidationResult:
        """
        校验路径指向存在的常规文件且可读 stat。

        cwd_hint:
            文件不存在时附加到错误信息（对齐 CC「Current working directory: …」）。
        """
        p = Path(path_str)
        try:
            st = p.stat()
        except FileNotFoundError:
            suffix = (
                f" Current working directory: {cwd_hint}."
                if cwd_hint is not None
                else ""
            )
            return ValidationResult(
                ok=False,
                message=f'Attachment "{path_str}" does not exist.{suffix}',
                code="ATTACHMENT_NOT_FOUND",
            )
        except PermissionError:
            return ValidationResult(
                ok=False,
                message=f'Attachment "{path_str}" is not accessible (permission denied).',
                code="ATTACHMENT_PERMISSION",
            )
        except OSError as exc:
            return ValidationResult(
                ok=False,
                message=str(exc),
                code="ATTACHMENT_OS_ERROR",
            )

        if not stat_mod.S_ISREG(st.st_mode):
            return ValidationResult(
                ok=False,
                message=f'Attachment "{path_str}" is not a regular file.',
                code="ATTACHMENT_NOT_FILE",
            )

        return ValidationResult(ok=True)


class AttachmentResolver:
    """解析附件列表为元数据（对齐 CC resolveAttachments 的无上传子集）。"""

    def resolve(self, paths: list[str]) -> list[ResolvedAttachment]:
        resolved: list[ResolvedAttachment] = []
        for path_str in paths:
            path = Path(path_str)
            st = path.stat()
            is_image = IMAGE_EXTENSION_PATTERN.search(path_str) is not None
            resolved.append(
                ResolvedAttachment(
                    path=str(path.resolve()),
                    size=st.st_size,
                    is_image=is_image,
                )
            )
        return resolved
