"""
tools/user_message — UserMessageTool 包

职责：
    导出 UserMessageTool；对齐 CC BriefTool（SendUserMessage）v1。

链路位置：
    ToolRuntimeLoader.register_default_tools；models 供测试与类型引用。

当前裁剪范围：
    v1 核心 + v2 Pipeline 事件；本地特性门控见 ``UserMessageRuntimeConfig``（设计 v2 §3.4.3）。
"""

from __future__ import annotations

from .runtime_config import UserMessageRuntimeConfig
from .tool import UserMessageTool

__all__ = ["UserMessageRuntimeConfig", "UserMessageTool"]
