"""
task_create/prompt.py — TaskCreate 工具名称与描述

职责：
    提供 TOOL_NAME、DESCRIPTION 及扩展说明文本（CC `prompt.ts` 优先迁移）。

链路位置：
    TaskCreateRuntimeTool 类属性 name/description；模型不引用长 prompt 时可单独供 UI/文档使用。

当前裁剪范围：
    - 不实现 CC `isAgentSwarmsEnabled()` 分支（ teammate / 多代理提示合并为通用一句）
"""

from __future__ import annotations

TOOL_NAME = "TaskCreate"

# CC tools/TaskCreateTool/prompt.ts — DESCRIPTION（原文迁移）
DESCRIPTION = "Create a new task in the task list"


def get_prompt() -> str:
    """返回工具长说明（CC getPrompt 主体迁移，裁剪 AgentSwarms 条件分支）。"""
    return """Use this tool to create a structured task list for your current coding session. This helps you track progress, organize complex tasks, and demonstrate thoroughness to the user.
It also helps the user understand the progress of the task and overall progress of their requests.

## When to Use This Tool

Use this tool proactively in these scenarios:

- Complex multi-step tasks - When a task requires 3 or more distinct steps or actions
- Non-trivial and complex tasks - Tasks that require careful planning or multiple operations
- Plan mode - When using plan mode, create a task list to track the work
- User explicitly requests todo list - When the user directly asks you to use the todo list
- User provides multiple tasks - When users provide a list of things to be done (numbered or comma-separated)
- After receiving new instructions - Immediately capture user requirements as tasks
- When you start working on a task - Mark it as in_progress BEFORE beginning work
- After completing a task - Mark it as completed and add any new follow-up tasks discovered during implementation

## When NOT to Use This Tool

Skip using this tool when:
- There is only a single, straightforward task
- The task is trivial and tracking it provides no organizational benefit
- The task can be completed in less than 3 trivial steps
- The task is purely conversational or informational

NOTE that you should not use this tool if there is only one trivial task to do. In this case you are better off just doing the task directly.

## Task Fields

- **subject**: A brief, actionable title in imperative form (e.g., "Fix authentication bug in login flow")
- **description**: What needs to be done
- **activeForm** (optional): Present continuous form shown in the spinner when the task is in_progress (e.g., "Fixing authentication bug"). If omitted, the spinner shows the subject instead.

All tasks are created with status `pending`.

## Tips

- Create tasks with clear, specific subjects that describe the outcome
- After creating tasks, use TaskUpdate to set up dependencies (blocks/blockedBy) if needed
- Check TaskList first to avoid creating duplicate tasks
"""
