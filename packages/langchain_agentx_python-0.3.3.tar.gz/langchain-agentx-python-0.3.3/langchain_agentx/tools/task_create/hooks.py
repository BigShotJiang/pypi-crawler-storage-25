"""
task_create/hooks.py — TaskCreated hooks 执行器

职责：
    对标 CC `executeTaskCreatedHooks` 的 v1 同步编排：按注册顺序调用 hooks，
    收集阻塞性错误字符串；不访问任务 JSON（由 `TaskStore` 负责）。

链路位置：
    TaskCreateRuntimeTool.invoke → TaskCreatedHookRunner → HookRegistry

当前裁剪范围：
    - 仅同步 Python 可调用；无 AbortSignal / 异步 generator
    - teammate / team 名由调用方传入，可为 None
"""

from __future__ import annotations

from langchain_agentx.loop.hook.registry import HookRegistry


class TaskCreatedHookRunner:
    """任务创建 hooks 主编排（OOP 入口）。"""

    def run(
        self,
        task_id: str,
        subject: str,
        description: str,
        *,
        teammate_name: str | None = None,
        team_name: str | None = None,
    ) -> list[str]:
        """执行已注册的 task created hooks，返回阻塞错误列表。"""
        blocking_errors: list[str] = []
        for hook in HookRegistry.get_task_created_hooks():
            try:
                err = hook(task_id, subject, description, teammate_name, team_name)
                if err:
                    blocking_errors.append(err)
            except Exception as e:  # noqa: BLE001 — 与 task_update hooks 一致，单条记录
                blocking_errors.append(f"Hook execution failed: {e}")
        return blocking_errors


_default_runner = TaskCreatedHookRunner()


def execute_task_created_hooks(
    task_id: str,
    subject: str,
    description: str,
    *,
    teammate_name: str | None = None,
    team_name: str | None = None,
) -> list[str]:
    """模块级 API：执行 task created hooks。"""
    return _default_runner.run(
        task_id,
        subject,
        description,
        teammate_name=teammate_name,
        team_name=team_name,
    )
