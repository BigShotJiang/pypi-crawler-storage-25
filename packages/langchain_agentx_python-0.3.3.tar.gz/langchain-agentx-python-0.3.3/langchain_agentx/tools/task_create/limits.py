"""
task_create/limits.py — TaskCreate 字段长度上界

职责：
    与 CC TaskCreate 及 `task_runtime.tasklist` 模型常量保持一致，供工具侧校验引用。

链路位置：
    TaskCreateInput 字段 `max_length` → limits 常量 → tasklist.models

当前裁剪范围：
    薄转发，不在此文件重复数值定义。
"""

from langchain_agentx.task_runtime.tasklist import (
    MAX_ACTIVE_FORM_LENGTH,
    MAX_DESCRIPTION_LENGTH,
    MAX_SUBJECT_LENGTH,
)

__all__ = [
    "MAX_SUBJECT_LENGTH",
    "MAX_DESCRIPTION_LENGTH",
    "MAX_ACTIVE_FORM_LENGTH",
]
