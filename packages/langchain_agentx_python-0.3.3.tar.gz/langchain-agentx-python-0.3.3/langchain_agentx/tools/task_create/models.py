"""
task_create/models.py — TaskCreate 工具 IO 模型

职责：
    定义 TaskCreateRuntimeTool 的 Pydantic 输入输出；持久化字段映射到 `TaskCreate` dataclass。

链路位置：
    ToolExecutorPipeline → TaskCreateInput → validate_input → invoke → TaskCreateOutput → present

当前裁剪范围：
    - v1：subject / description / activeForm / metadata；可选 blocks / blockedBy（须指向已存在任务）
    - 不含 CC teammate / AgentSwarms 分支字段
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from .limits import (
    MAX_ACTIVE_FORM_LENGTH,
    MAX_DESCRIPTION_LENGTH,
    MAX_SUBJECT_LENGTH,
)


class TaskCreateInput(BaseModel):
    """TaskCreate 工具输入（对齐 CC TaskCreateTool 主字段 + 可选依赖）。"""

    subject: str = Field(
        ...,
        min_length=1,
        description="A brief title for the task",
        max_length=MAX_SUBJECT_LENGTH,
    )
    description: str = Field(
        ...,
        min_length=1,
        description="What needs to be done",
        max_length=MAX_DESCRIPTION_LENGTH,
    )
    active_form: str | None = Field(
        None,
        description='Present continuous form when in_progress (e.g. "Running tests")',
        max_length=MAX_ACTIVE_FORM_LENGTH,
    )
    metadata: dict[str, object] | None = Field(
        None,
        description="Arbitrary metadata to attach to the task",
    )
    blocks: list[str] | None = Field(
        None,
        description="Optional task IDs this task blocks (must exist)",
    )
    blocked_by: list[str] | None = Field(
        None,
        description="Optional task IDs that block this task (must exist)",
    )


class CreatedTaskRef(BaseModel):
    """创建成功时返回的任务摘要（对齐 CC outputSchema.task）。"""

    id: str
    subject: str


class TaskCreateOutput(BaseModel):
    """TaskCreate 工具输出。"""

    success: bool
    task: CreatedTaskRef | None = None
    error: str | None = None
