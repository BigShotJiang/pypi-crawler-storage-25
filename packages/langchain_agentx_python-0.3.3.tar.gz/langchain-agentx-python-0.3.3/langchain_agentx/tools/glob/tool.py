"""
职责：
    GlobRuntimeTool — 按文件名模式列路径（系统 ripgrep：`rg --files`，对齐 CC utils/glob.ts）。
    实现 RuntimeTool 生命周期；不负责读文件内容（Read）与内容搜索（Grep）。

在整体链路中的位置：
    ToolExecutorPipeline -> GlobRuntimeTool.invoke()
    -> rg_list_backend.list_files_via_ripgrep(..., cancel_event=ctx.cancel_event)
    -> GlobToolOutput -> after_invoke（可选写入 ToolStateBridge.last_glob_summary）
    -> present() -> ToolResultEnvelope

与 CC 对照：
    对应 CC src/tools/GlobTool/GlobTool.ts + src/utils/glob.ts。
    仅使用系统 PATH 中的 ripgrep：Windows 默认 `rg.exe`，Unix 默认 `rg`（见 utils.rg_executable）。
    validate_input 对 UNC / ``//`` 前缀跳过本地 stat，与 CC 一致（utils.unc_path）。
    不使用 Python 标准库 glob，避免与 ripgrep --glob 两套语法。
"""

from __future__ import annotations

import os
import time
from typing import Any

from langchain_agentx.tool_runtime.base import RuntimeTool
from langchain_agentx.tool_runtime.models import (
    AuthorizationDecision,
    ToolExecutionContext,
    ToolHint,
    ToolResultEnvelope,
    ValidationResult,
)
from langchain_agentx.tool_runtime.state_bridge import ToolStateBridge
from langchain_agentx.tools.grep.backend import GrepExecutionError, RipgrepBackend
from langchain_agentx.tools.ripgrep_plugin_exclusions import PluginCacheGlobExclusions
from langchain_agentx.utils.path_user_input import UserPathInputNormalizer
from langchain_agentx.utils.rg_executable import default_rg_executable
from langchain_agentx.utils.unc_path import is_unc_path_skip_local_stat

from .models import DEFAULT_MAX_RESULTS, MAX_MAX_RESULTS, GlobToolInput, GlobToolOutput
from .pagination import slice_glob_paths
from .prompt import DESCRIPTION, TOOL_NAME
from .rg_list_backend import list_files_via_ripgrep
from .rg_pattern import extract_glob_base_directory


def _has_path_traversal(pattern: str) -> bool:
    normalized = pattern.replace("\\", "/")
    parts = [part for part in normalized.split("/") if part]
    return any(part == ".." for part in parts)


def _is_descendant(child: str, parent: str) -> bool:
    try:
        c = os.path.realpath(child)
        p = os.path.realpath(parent)
        return os.path.commonpath([c, p]) == p
    except ValueError:
        return False


class GlobRuntimeTool(RuntimeTool):
    name: str = TOOL_NAME
    description: str = DESCRIPTION
    input_model = GlobToolInput
    output_model = GlobToolOutput

    is_read_only: bool = True
    is_concurrency_safe: bool = True
    never_truncate: bool = False
    dedupe_identical_calls: bool = True
    max_result_size_chars: int = 100_000

    def __init__(
        self,
        *,
        workspace_root: str,
        max_results: int = DEFAULT_MAX_RESULTS,
        policy: Any | None = None,
        state_bridge: Any | None = None,
        path_normalizer: UserPathInputNormalizer | None = None,
        rg_path: str | None = None,
        rg_timeout: int = RipgrepBackend.DEFAULT_TIMEOUT,
        ignore_patterns: list[str] | None = None,
        plugin_cache_glob_exclusions: PluginCacheGlobExclusions | None = None,
    ) -> None:
        super().__init__(policy=policy, state_bridge=state_bridge)
        self._workspace_root = os.path.realpath(os.path.expanduser(workspace_root))
        self.max_results = max(1, min(int(max_results), MAX_MAX_RESULTS))
        self._path_normalizer = path_normalizer or UserPathInputNormalizer()
        self._rg_path = rg_path if rg_path is not None else default_rg_executable()
        self._rg_timeout = int(rg_timeout)
        self._ignore_patterns = [p for p in (ignore_patterns or []) if str(p).strip()]
        self._plugin_cache_glob_exclusions = plugin_cache_glob_exclusions

    def normalize_input(
        self,
        raw: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> dict[str, Any]:
        data = dict(raw)
        pattern = data.get("pattern")
        if isinstance(pattern, str):
            data["pattern"] = pattern.strip()

        path = data.get("path")
        from langchain_agentx.utils.cwd import get_cwd

        if isinstance(path, str) and path.strip():
            data["path"] = self._path_normalizer.normalize_and_expand(
                path, base_dir=ctx.cwd
            )
        else:
            data["path"] = ctx.cwd or get_cwd()
        return data

    def validate_input(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> ValidationResult:
        pattern = str(data.get("pattern") or "").strip()
        if not pattern:
            return ValidationResult(
                ok=False,
                message="Pattern cannot be empty",
                code="EMPTY_PATTERN",
            )
        if _has_path_traversal(pattern):
            return ValidationResult(
                ok=False,
                message="Pattern must not contain path traversal sequences",
                code="PATH_TRAVERSAL",
            )

        search_root = str(data["path"])
        # CC validateInput：UNC / // 前缀跳过本地 stat（与 Grep 一致）
        if is_unc_path_skip_local_stat(search_root):
            return ValidationResult(ok=True)
        if not os.path.exists(search_root):
            return ValidationResult(
                ok=False,
                message=(
                    f"Directory does not exist: {search_root}. "
                    f"Current workspace: {self._workspace_root}"
                ),
                code="DIR_NOT_FOUND",
            )
        if not os.path.isdir(search_root):
            return ValidationResult(
                ok=False,
                message=f"Path is not a directory: {search_root}",
                code="NOT_A_DIRECTORY",
            )
        return ValidationResult(ok=True)

    def check_permissions(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> AuthorizationDecision:
        return super().check_permissions(data, ctx)

    def after_invoke(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> None:
        """
        v2-D：若构造时注入 ``ToolStateBridge``，将本次 Glob 摘要写入 ``session_store``
        （经 bridge；供 ``get_last_glob_summary`` 读取；**不**参与 PolicyEngine）。
        """
        if self._state_bridge is None or not isinstance(self._state_bridge, ToolStateBridge):
            return
        if not isinstance(result, GlobToolOutput):
            return
        self._state_bridge.record_last_glob(
            ctx,
            pattern=result.pattern,
            search_root=result.search_root,
            filenames=result.filenames,
            num_files_page=result.num_files,
            total_matches=result.total_matches,
            truncated=result.truncated,
            offset=result.offset,
        )

    def invoke(
        self,
        data: dict[str, Any],
        ctx: ToolExecutionContext,
    ) -> GlobToolOutput:
        pattern = str(data["pattern"])
        search_root = os.path.realpath(str(data["path"]))
        started = time.perf_counter()

        relative_glob = pattern
        if os.path.isabs(pattern):
            base_dir, relative_glob = extract_glob_base_directory(pattern)
            if base_dir:
                candidate = os.path.realpath(os.path.expanduser(base_dir))
                if not _is_descendant(candidate, self._workspace_root):
                    raise GrepExecutionError(
                        "Glob pattern resolves to a directory outside the workspace root."
                    )
                search_root = candidate

        plugin_ex: list[str] | None = None
        if self._plugin_cache_glob_exclusions is not None:
            plugin_ex = self._plugin_cache_glob_exclusions.get_exclusions_for_search(
                search_root
            )
            if not plugin_ex:
                plugin_ex = None

        try:
            files_full = list_files_via_ripgrep(
                search_root,
                relative_glob,
                rg_path=self._rg_path,
                timeout=self._rg_timeout,
                ignore_patterns=self._ignore_patterns or None,
                plugin_glob_exclusions=plugin_ex,
                cancel_event=ctx.cancel_event,
            )
        except GrepExecutionError:
            raise
        except OSError as e:
            raise GrepExecutionError(f"Glob failed while resolving paths: {e}") from e

        page_offset = int(data["offset"])
        files, total_matches, truncated = slice_glob_paths(
            files_full,
            offset=page_offset,
            limit=self.max_results,
        )
        relative_files = [self._to_relative(path) for path in files]

        duration_ms = (time.perf_counter() - started) * 1000.0
        return GlobToolOutput(
            pattern=pattern,
            search_root=search_root,
            filenames=relative_files,
            num_files=len(relative_files),
            truncated=truncated,
            total_matches=total_matches,
            offset=page_offset,
            duration_ms=duration_ms,
        )

    def present(
        self,
        data: dict[str, Any],
        result: Any,
        ctx: ToolExecutionContext,
    ) -> ToolResultEnvelope:
        if not isinstance(result, GlobToolOutput):
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=str(result),
                payload=str(result),
            )

        meta = {
            "pattern": result.pattern,
            "search_root": result.search_root,
            "num_files": result.num_files,
            "truncated": result.truncated,
            "total_matches": result.total_matches,
            "offset": result.offset,
            "duration_ms": round(result.duration_ms, 2),
            "glob_backend": "ripgrep",
        }

        if result.num_files == 0:
            if result.total_matches == 0:
                summary = "No files found"
            else:
                summary = (
                    f"No files in this page (offset {result.offset}, "
                    f"{result.total_matches} total match(es))"
                )
            return ToolResultEnvelope(
                status="ok",
                tool_name=self.name,
                summary=summary,
                payload={
                    "filenames": [],
                    "num_files": 0,
                    "truncated": result.truncated,
                    "total_matches": result.total_matches,
                    "offset": result.offset,
                },
                meta=meta,
            )

        summary = f"Found {result.num_files} file(s) matching '{result.pattern}'"
        payload_lines = list(result.filenames)
        hints: list[ToolHint] | None = None
        if result.truncated:
            summary += (
                f" (results truncated at {self.max_results}"
                + (f", offset {result.offset}" if result.offset else "")
                + ")"
            )
            hint_msg = (
                "Results are truncated. Consider using a more specific path or pattern."
            )
            payload_lines.append(f"({hint_msg})")
            hints = [ToolHint(message=hint_msg)]

        return ToolResultEnvelope(
            status="ok",
            tool_name=self.name,
            summary=summary,
            payload="\n".join(payload_lines),
            hints=hints,
            meta=meta,
        )

    def _to_relative(self, path: str) -> str:
        try:
            return os.path.relpath(path, self._workspace_root)
        except ValueError:
            return path
