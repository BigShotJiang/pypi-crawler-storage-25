"""
LangChain-based agent utilities for CodeBaseX.

This package provides:
- LangChain-AgentX LangGraph agent factory (`loop`)

Typical usage:

```python
from langchain_agentx import create_loop_agent
```
"""

__version__ = "0.1.6"

from .loop import (  # noqa: F401
    create_loop_agent,
)

from .observability import (  # noqa: F401
    EventAdapterState,
    LangchainAgentEvent,
    LangchainAgentEventType,
    LangGraphToLangchainAgentEventAdapter,
    TraceCollector,
    TraceSession,
    TraceSpan,
)
from .provider import CompatibleChatOpenAI  # noqa: F401
from .session import AgentSession, create_agent_session  # noqa: F401
from .workflow import BaseWorkflow  # noqa: F401

__all__ = [
    "create_loop_agent",
    "create_agent_session",
    "AgentSession",
    "BaseWorkflow",
    "EventAdapterState",
    "LangchainAgentEvent",
    "LangchainAgentEventType",
    "LangGraphToLangchainAgentEventAdapter",
    "TraceCollector",
    "TraceSession",
    "TraceSpan",
    "CompatibleChatOpenAI",
]
