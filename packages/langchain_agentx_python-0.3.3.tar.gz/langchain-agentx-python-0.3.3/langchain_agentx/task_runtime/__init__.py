"""Task runtime package.

Shared task scheduling primitives for loop and tools.
"""

# CC 任务列表存储子系统（TaskListStatus：Todo JSON 状态字面量，勿与编排层 TaskStatus 枚举混淆）
from .tasklist import (
    ClaimResult,
    FileLockNotAvailableError,
    Task,
    TaskCreate,
    TaskFilters,
    TaskListStatus,
    TaskStore,
    TaskStoreLockManager,
    TaskUpdate,
)

from .core.interfaces import TaskExecutor
from .orchestrator.runtime import DefaultTaskRuntime
from .queue.in_memory import InMemoryTaskCommandQueue
from .store.in_memory import InMemoryTaskStore
from .store.sqlite_store import SqliteTaskStore
from .tasks import (
    CUSTOM_SEMANTIC,
    CustomTaskExecutor,
    DREAM_TASK_SEMANTIC,
    DefaultLocalAgentRunner,
    DreamTaskExecutor,
    IN_PROCESS_TEAMMATE_SEMANTIC,
    ImmediateRemoteAgentBackend,
    InProcessTeammateExecutor,
    LOCAL_AGENT_SEMANTIC,
    LOCAL_BASH_SEMANTIC,
    LocalAgentExecutor,
    LocalAgentRunner,
    LocalBashExecutor,
    RecordingRemoteAgentBackend,
    REMOTE_AGENT_SEMANTIC,
    RemoteAgentExecutor,
    RemoteAgentSessionBackend,
)
from .integrations import (
    InMemoryQueuedCommandProvider,
    MemoryPrefetchProvider,
    QueuedCommandEnvelope,
    QueuedCommandProvider,
    SqliteQueuedCommandProvider,
    SkillPrefetchProvider,
    ToolUseSummaryProvider,
    ProviderFactoryConfig,
    ProviderBundle,
    build_provider_bundle,
    decode_provider_batch_id,
    encode_provider_batch_id,
)
from .core.types import (
    QueuePriority,
    ReservedNotificationBatch,
    TaskExecutionResult,
    TaskNotificationEnvelope,
    TaskRecord,
    TaskRuntimeEvent,
    TaskRuntimeEventType,
    TaskScope,
    TaskSpec,
    TaskStatus,
    TaskType,
)
from .output import InMemoryTaskOutputSink, TaskOutputSink
from .policy import (
    DEFAULT_WITHHOLD_TASK_EVENT_POLICY,
    WithholdTaskEventPolicy,
)

__all__ = [
    # Tasklist (CC 任务列表)
    "TaskStore",
    "Task",
    "TaskCreate",
    "TaskUpdate",
    "TaskFilters",
    "TaskListStatus",
    "ClaimResult",
    "TaskStoreLockManager",
    "FileLockNotAvailableError",
    # Queued commands
    "QueuedCommandProvider",
    "encode_provider_batch_id",
    "decode_provider_batch_id",
    "DefaultTaskRuntime",
    "InMemoryTaskStore",
    "SqliteTaskStore",
    "InMemoryTaskCommandQueue",
    "TaskExecutor",
    "LocalBashExecutor",
    "LOCAL_BASH_SEMANTIC",
    "DefaultLocalAgentRunner",
    "LocalAgentExecutor",
    "LocalAgentRunner",
    "LOCAL_AGENT_SEMANTIC",
    "InProcessTeammateExecutor",
    "IN_PROCESS_TEAMMATE_SEMANTIC",
    "ImmediateRemoteAgentBackend",
    "RecordingRemoteAgentBackend",
    "RemoteAgentExecutor",
    "RemoteAgentSessionBackend",
    "REMOTE_AGENT_SEMANTIC",
    "CustomTaskExecutor",
    "CUSTOM_SEMANTIC",
    "DreamTaskExecutor",
    "DREAM_TASK_SEMANTIC",
    "TaskType",
    "TaskStatus",
    "QueuePriority",
    "TaskScope",
    "TaskSpec",
    "TaskRecord",
    "TaskNotificationEnvelope",
    "ReservedNotificationBatch",
    "TaskExecutionResult",
    "TaskRuntimeEvent",
    "TaskRuntimeEventType",
    "InMemoryQueuedCommandProvider",
    "QueuedCommandEnvelope",
    "SqliteQueuedCommandProvider",
    "MemoryPrefetchProvider",
    "SkillPrefetchProvider",
    "ToolUseSummaryProvider",
    "ProviderFactoryConfig",
    "ProviderBundle",
    "build_provider_bundle",
    "InMemoryTaskOutputSink",
    "TaskOutputSink",
    "WithholdTaskEventPolicy",
    "DEFAULT_WITHHOLD_TASK_EVENT_POLICY",
]
