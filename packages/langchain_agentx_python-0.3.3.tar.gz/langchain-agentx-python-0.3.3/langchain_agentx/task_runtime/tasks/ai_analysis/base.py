"""
task_runtime/tasks/ai_analysis/base.py — 后台 AI 分析任务基类。

职责：
    继承 BaseWorkflow，覆盖 container_type 为 background_task；
    提供占位 ``build_graph`` 满足 ABC；``run(**kwargs)`` 直接委派 ``_execute`` 并静默降级。

链路位置：
    由后台任务调度器通过队列轮询触发。
"""

from __future__ import annotations

import logging
from abc import abstractmethod
from pathlib import Path
from typing import Any

from langgraph.graph import END, START, StateGraph

from ....loop.hook.registry import HookRegistry
from ....workflow.base import BaseWorkflow
from ....workflow.state import WorkflowState

logger = logging.getLogger(__name__)


class BackgroundAiTask(BaseWorkflow):
    """后台 AI 分析任务基类。失败必须静默降级。"""

    container_type: str = "background_task"

    def __init__(
        self,
        workflow_id: str | None = None,
        hook_registry: HookRegistry | None = None,
        **kwargs: Any,
    ) -> None:
        # 历史调用方曾传 hook_engine；BaseWorkflow 使用 HookRegistry + HookEngine，此处丢弃兼容字段。
        kwargs.pop("hook_engine", None)
        wid = workflow_id or "background_task"
        reg = hook_registry or HookRegistry()
        if (
            kwargs.get("capabilities") is None
            and kwargs.get("workspace_root") is None
            and kwargs.get("agent_home") is None
        ):
            kwargs.setdefault("workspace_root", Path.cwd())
            kwargs.setdefault("agent_home", ".langchain_agentx")
        super().__init__(workflow_id=wid, hook_registry=reg, **kwargs)

    def build_graph(self) -> StateGraph:
        """满足 BaseWorkflow ABC；后台任务实际入口为 ``run`` → ``_execute``，不编译执行本图。"""
        graph = StateGraph(WorkflowState)

        async def _placeholder(state: WorkflowState) -> WorkflowState:
            return state

        graph.add_node("_background_placeholder", _placeholder)
        graph.add_edge(START, "_background_placeholder")
        graph.add_edge("_background_placeholder", END)
        return graph

    async def run(self, **kwargs: Any) -> Any:
        """执行后台逻辑；异常时静默降级为 ``None``（不调用 LangGraph ``super().run``）。"""
        try:
            return await self._execute(**kwargs)
        except Exception:
            logger.exception("%s 执行失败，静默降级", self.__class__.__name__)
            return None

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现具体分析逻辑，结果写回外部存储。"""


__all__ = ["BackgroundAiTask"]
