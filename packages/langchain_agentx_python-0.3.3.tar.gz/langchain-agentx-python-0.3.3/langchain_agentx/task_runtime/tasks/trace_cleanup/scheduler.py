"""
trace_cleanup/scheduler.py — TraceCleanupScheduler

职责：
    定时触发 trace retention 清理（通过 registry 构造 TraceCleanupTask 并 await run）。

链路位置：
    由上层在 **已运行的 asyncio 事件循环** 内 ``asyncio.create_task(scheduler.start())`` 启动；
    退出前须 ``scheduler.stop()`` 并 cancel 该 Task（OB-D10 §3.3）。

当前裁剪范围：
    不修改 BackgroundAiTaskScheduler 基类；可选 **非阻塞文件锁** + **marker 冷却**（多进程节流）。
"""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Any, IO

import portalocker
from portalocker.exceptions import BaseLockException

from langchain_agentx.observability.evaluation.store import EvaluationStore
from langchain_agentx.observability.trace.sqlite_store import SqliteTraceStore

from ..ai_analysis.registry import BackgroundAiTaskRegistry
from ..ai_analysis.scheduler import BackgroundAiTaskScheduler

logger = logging.getLogger(__name__)

_NO_LOCK = object()


class TraceCleanupScheduler(BackgroundAiTaskScheduler):
    """覆盖 ``_poll_once``：按配置触发 ``trace.cleanup`` 任务。"""

    def __init__(
        self,
        trace_store: SqliteTraceStore,
        evaluation_store: EvaluationStore,
        registry: BackgroundAiTaskRegistry,
        *,
        poll_interval: float = 86400.0,
        cleanup_config: dict[str, Any] | None = None,
        enable_file_lock: bool = True,
        lock_path: Path | str | None = None,
        marker_path: Path | str | None = None,
        marker_cooldown_seconds: float | None = None,
        task_factory_kwargs: dict[str, Any] | None = None,
    ) -> None:
        """
        Args:
            trace_store / evaluation_store: 注入 Store（测试须可传 tmp_path）。
            registry: 须已注册 ``trace.cleanup``（通常随 ai_analysis 包 import 侧载）。
            poll_interval: ``start()`` 循环中 ``asyncio.sleep`` 间隔（秒）。
            cleanup_config: 传入 ``TraceCleanupTask.run`` 的 kwargs（如 failed_days / normal_days）。
            enable_file_lock: 为 True 时用 ``portalocker`` 非阻塞独占锁，避免多进程同时跑 DELETE。
            lock_path / marker_path: 默认与 ``trace_store.db_path`` 同目录派生文件名。
            marker_cooldown_seconds: 非 None 时，marker 存在且距上次成功清理不足该秒数则跳过本轮（多进程节流）；**None** 表示不按 marker 跳过（§4.1 Q5 幂等每轮）。
            task_factory_kwargs: 除 ``trace_store`` / ``evaluation_store`` 外传给 ``TraceCleanupTask`` 的 ``graph_factory`` / ``hook_registry`` 等。
        """
        db = Path(trace_store.db_path)
        self._trace_store = trace_store
        self._eval_store = evaluation_store
        merged: dict[str, Any] = {
            "failed_days": 180,
            "normal_days": 30,
            "cleanup_diagnostic_reports": False,
        }
        if cleanup_config:
            merged.update(cleanup_config)
        self._cleanup_config = merged
        self._enable_file_lock = bool(enable_file_lock)
        self._lock_path = Path(lock_path) if lock_path is not None else db.with_suffix(".cleanup.lock")
        self._marker_path = Path(marker_path) if marker_path is not None else db.with_suffix(".cleanup.marker")
        self._marker_cooldown_seconds = marker_cooldown_seconds

        super().__init__(
            evaluation_store=evaluation_store,
            registry=registry,
            task_factory_kwargs={
                "trace_store": trace_store,
                "evaluation_store": evaluation_store,
                **(task_factory_kwargs or {}),
            },
            poll_interval=poll_interval,
        )

    def _should_skip_cleanup(self) -> bool:
        """marker 冷却：在 ``marker_cooldown_seconds`` 非空且文件在冷却期内返回 True。"""
        if self._marker_cooldown_seconds is None:
            return False
        path = self._marker_path
        if not path.is_file():
            return False
        try:
            last = float(path.read_text(encoding="utf-8").strip())
        except (OSError, ValueError):
            return False
        return (time.time() - last) < float(self._marker_cooldown_seconds)

    def _acquire_lock_nonblocking(self) -> Any:
        """非阻塞获取清理锁；失败返回 ``None``。关闭文件锁时返回哨兵 ``_NO_LOCK``。"""
        if not self._enable_file_lock:
            return _NO_LOCK
        self._lock_path.parent.mkdir(parents=True, exist_ok=True)
        handle = open(self._lock_path, "a+b")  # noqa: SIM115 — 生命周期由 _release_lock 关闭
        try:
            portalocker.lock(handle, portalocker.LOCK_EX | portalocker.LOCK_NB)
        except (OSError, BaseLockException):
            handle.close()
            return None
        return handle

    def _release_lock(self, lock_handle: Any) -> None:
        if lock_handle is None or lock_handle is _NO_LOCK:
            return
        handle: IO[bytes] = lock_handle
        try:
            portalocker.unlock(handle)
        except Exception:
            logger.debug("portalocker.unlock 忽略异常", exc_info=True)
        try:
            handle.close()
        except OSError:
            pass

    def _write_marker_now(self) -> None:
        self._marker_path.parent.mkdir(parents=True, exist_ok=True)
        self._marker_path.write_text(str(time.time()), encoding="utf-8")

    async def _poll_once(self) -> None:
        if self._should_skip_cleanup():
            logger.debug("TraceCleanupScheduler 跳过本轮（marker 冷却中）")
            return

        lock_handle = self._acquire_lock_nonblocking()
        if lock_handle is None:
            logger.debug("TraceCleanupScheduler 跳过本轮（未获取到清理锁）")
            return

        try:
            task_factory = self._registry.get("trace.cleanup")
            if task_factory is None:
                logger.warning("registry 未注册 trace.cleanup，跳过清理")
                return
            try:
                # ``task_factory_kwargs`` 已在 ``__init__`` 中含 trace_store / evaluation_store
                task = task_factory(**self._task_factory_kwargs)
            except Exception:
                logger.exception("TraceCleanupScheduler 构造 TraceCleanupTask 失败")
                return

            try:
                await task.run(**self._cleanup_config)
            except Exception:
                logger.exception("TraceCleanupScheduler 执行 trace.cleanup 失败")
                return

            if self._marker_cooldown_seconds is not None:
                self._write_marker_now()
        finally:
            self._release_lock(lock_handle)


__all__ = ["TraceCleanupScheduler"]
