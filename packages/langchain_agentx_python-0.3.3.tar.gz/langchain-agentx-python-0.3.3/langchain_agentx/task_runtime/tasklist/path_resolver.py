"""
task_runtime/tasklist/path_resolver.py — 任务列表路径解析

职责：
    解析任务存储相关路径，支持：
    - 路径安全化（防止目录穿越攻击）
    - 任务目录路径解析
    - 单个任务文件路径解析
    - task_list_id 多级回退逻辑

链路位置：
    TaskStore → path_resolver → AgentWorkspaceConfig

与 CC 对应：
    CC src/utils/tasks.ts 中 getTasksDir、getTaskPath 等。

裁剪范围（v1）：
    - 优先级：环境变量 > session_id
    - Team 模式扩展点预留（v1 不实现）
    - 跨平台路径分隔符处理
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

from langchain_agentx.workspace import AgentWorkspaceConfig


def sanitize_path_component(s: str) -> str:
    """路径组件安全化。

    移除或替换可能导致目录穿越攻击的字符。

    对应 CC sanitizePath 函数。
    """
    # 移除路径分隔符和特殊字符
    sanitized = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', s)
    # 移除开尾点和空格
    sanitized = sanitized.strip('. ')
    # 限制长度
    if len(sanitized) > 255:
        sanitized = sanitized[:255]
    return sanitized or "unnamed"


def get_tasks_dir(config: AgentWorkspaceConfig, task_list_id: str) -> Path:
    """获取任务存储目录路径。

    Args:
        config: 工作区配置
        task_list_id: 任务列表 ID（如 session_id）

    Returns:
        任务目录路径，如 {workspace_root}/{agent_home}/tasks/{task_list_id}
    """
    base_tasks_dir = config.agent_home_dir / "tasks"
    safe_id = sanitize_path_component(task_list_id)
    return base_tasks_dir / safe_id


def get_task_path(
    config: AgentWorkspaceConfig,
    task_list_id: str,
    task_id: str,
) -> Path:
    """获取单个任务文件路径。

    Args:
        config: 工作区配置
        task_list_id: 任务列表 ID
        task_id: 任务 ID

    Returns:
        任务文件路径，如 {tasks_dir}/{task_id}.json
    """
    tasks_dir = get_tasks_dir(config, task_list_id)
    safe_id = sanitize_path_component(task_id)
    return tasks_dir / f"{safe_id}.json"


def resolve_task_list_id(
    config: AgentWorkspaceConfig,
    session_id: Optional[str] = None,
) -> str:
    """解析任务列表 ID。

    多级回退逻辑：
    1. 环境变量 LANGCHAIN_AGENTX_TASK_LIST_ID
    2. 传入的 session_id
    3. 默认 "default"

    Args:
        config: 工作区配置（保留以备将来扩展）
        session_id: 可选的会话 ID

    Returns:
        解析后的任务列表 ID
    """
    # 1. 环境变量优先
    env_id = os.getenv("LANGCHAIN_AGENTX_TASK_LIST_ID")
    if env_id:
        return env_id

    # 2. 传入的 session_id
    if session_id:
        return session_id

    # 3. 默认值
    return "default"
