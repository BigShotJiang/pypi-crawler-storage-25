"""
task_runtime/tasklist/high_water_mark.py — 高水位标记管理

职责：
    管理任务 ID 高水位标记，防止删除后 ID 重用：
    - 读取当前高水位值
    - 写入新的高水位值
    - 扫描文件找出最大 ID

链路位置：
    TaskStore.create_task → HighWaterMarkManager.get_next_id

与 CC 对应：
    CC src/utils/tasks.ts 中 highWaterMark 相关函数。

裁剪范围（v1）：
    - 文件锁由调用方（TaskStore）负责
    - 降级策略：文件损坏时扫描目录
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional


class HighWaterMarkManager:
    """高水位标记管理器。

    确保任务 ID 单调递增，删除任务后不会重用 ID。

    高水位文件路径：{tasks_dir}/.highwatermark
    文件内容：纯数字字符串，表示已分配的最大 ID。
    """

    def __init__(self, timeout: float = 3.0) -> None:
        """初始化高水位标记管理器。

        Args:
            timeout: 文件操作超时（秒）
        """
        self.timeout = timeout

    def _get_highwatermark_path(self, tasks_dir: Path) -> Path:
        """获取高水位文件路径。"""
        return tasks_dir / ".highwatermark"

    async def read(self, tasks_dir: Path) -> int:
        """读取当前高水位值。

        Args:
            tasks_dir: 任务目录

        Returns:
            当前高水位值，文件不存在或损坏时返回 0
        """
        hw_path = self._get_highwatermark_path(tasks_dir)

        try:
            content = await asyncio.to_thread(hw_path.read_text, encoding="utf-8")
            return int(content.strip())
        except (FileNotFoundError, ValueError, OSError):
            return 0

    async def write(self, tasks_dir: Path, value: int) -> None:
        """写入新的高水位值。

        Args:
            tasks_dir: 任务目录
            value: 新的高水位值
        """
        hw_path = self._get_highwatermark_path(tasks_dir)

        # 确保目录存在
        await asyncio.to_thread(tasks_dir.mkdir, parents=True, exist_ok=True)

        # 原子写入：先写临时文件，再重命名
        temp_path = hw_path.with_suffix(".tmp")
        content = str(value)

        await asyncio.to_thread(temp_path.write_text, content, encoding="utf-8")

        # Windows 需要 replace，Posix rename 可原子替换
        try:
            await asyncio.to_thread(temp_path.replace, hw_path)
        except OSError:
            # 降级：删除后重命名
            if hw_path.exists():
                await asyncio.to_thread(hw_path.unlink)
            await asyncio.to_thread(temp_path.rename, hw_path)

    async def find_highest_id(self, tasks_dir: Path) -> int:
        """扫描任务文件找出最大 ID。

        作为高水位文件的降级策略。

        Args:
            tasks_dir: 任务目录

        Returns:
            找到的最大 ID，目录不存在或无任务时返回 0
        """
        if not await asyncio.to_thread(tasks_dir.exists):
            return 0

        max_id = 0

        try:
            for entry in await asyncio.to_thread(lambda: list(tasks_dir.iterdir())):
                if entry.suffix == ".json":
                    # 从文件名提取 ID（如 "123.json" -> 123）
                    try:
                        task_id = int(entry.stem)
                        max_id = max(max_id, task_id)
                    except ValueError:
                        continue
        except OSError:
            pass

        return max_id

    async def get_next_id(self, tasks_dir: Path) -> int:
        """获取下一个可用的任务 ID。

        Args:
            tasks_dir: 任务目录

        Returns:
            下一个 ID（max(高水位文件, 文件中最大ID) + 1）
        """
        hw_value = await self.read(tasks_dir)
        file_max = await self.find_highest_id(tasks_dir)

        current = max(hw_value, file_max)
        next_id = current + 1

        # 更新高水位
        await self.write(tasks_dir, next_id)

        return next_id

    # ------------------------------------------------------------------
    # 同步版本（用于文件锁保护下的同步上下文）
    # ------------------------------------------------------------------

    def _read_sync(self, tasks_dir: Path) -> int:
        """同步读取当前高水位值。"""
        hw_path = self._get_highwatermark_path(tasks_dir)

        try:
            content = hw_path.read_text(encoding="utf-8")
            return int(content.strip())
        except (FileNotFoundError, ValueError, OSError):
            return 0

    def _write_sync(self, tasks_dir: Path, value: int) -> None:
        """同步写入新的高水位值。"""
        hw_path = self._get_highwatermark_path(tasks_dir)

        # 确保目录存在
        tasks_dir.mkdir(parents=True, exist_ok=True)

        # 原子写入：先写临时文件，再重命名
        temp_path = hw_path.with_suffix(".tmp")
        content = str(value)

        temp_path.write_text(content, encoding="utf-8")

        # Windows 需要 replace，Posix rename 可原子替换
        try:
            temp_path.replace(hw_path)
        except OSError:
            # 降级：删除后重命名
            if hw_path.exists():
                hw_path.unlink()
            temp_path.rename(hw_path)

    def _find_highest_id_sync(self, tasks_dir: Path) -> int:
        """同步扫描任务文件找出最大 ID。"""
        if not tasks_dir.exists():
            return 0

        max_id = 0

        try:
            for entry in list(tasks_dir.iterdir()):
                if entry.suffix == ".json":
                    # 从文件名提取 ID（如 "123.json" -> 123）
                    try:
                        task_id = int(entry.stem)
                        max_id = max(max_id, task_id)
                    except ValueError:
                        continue
        except OSError:
            pass

        return max_id

    def get_next_id_sync(self, tasks_dir: Path) -> int:
        """同步获取下一个可用的任务 ID。

        用于文件锁保护下的同步上下文。

        Args:
            tasks_dir: 任务目录

        Returns:
            下一个 ID（max(高水位文件, 文件中最大ID) + 1）
        """
        hw_value = self._read_sync(tasks_dir)
        file_max = self._find_highest_id_sync(tasks_dir)

        current = max(hw_value, file_max)
        next_id = current + 1

        # 更新高水位
        self._write_sync(tasks_dir, next_id)

        return next_id
