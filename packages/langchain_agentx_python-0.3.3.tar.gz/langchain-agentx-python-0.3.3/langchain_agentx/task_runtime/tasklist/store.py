"""
task_runtime/tasklist/store.py — 任务存储核心

职责：
    实现任务存储的核心 CRUD 操作：
    - create_task: 创建新任务（文件锁 + 高水位）
    - get_task: 获取单个任务
    - list_tasks: 列出任务（支持过滤）
    - update_task: 更新任务
    - delete_task: 删除任务（cascade 清理引用）

链路位置：
    TaskListRuntimeTool/TaskGetRuntimeTool → TaskStore → 文件系统

与 CC 对应：
    CC src/utils/tasks.ts 中 TaskStore 类（863 行核心逻辑）。

裁剪范围（v1）：
    - 文件锁保护关键操作
    - 高水位标记确保 ID 不重用
    - 依赖管理（blocks/blockedBy 双向维护）
    - Team 模式延后
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Optional

from langchain_agentx.workspace import AgentWorkspaceConfig
from langchain_agentx.workspace.resolver import resolve_agent_workspace_config

from .high_water_mark import HighWaterMarkManager
from .lock import TaskStoreLockManager
from .models import Task, TaskCreate, TaskFilters, TaskStatus, TaskUpdate
from .path_resolver import get_task_path, get_tasks_dir, resolve_task_list_id


class TaskNotFoundError(RuntimeError):
    """任务不存在错误。"""


class TaskStore:
    """任务存储核心类。

    管理任务的持久化存储，每个任务对应一个 JSON 文件。

    目录结构：
        {agent_home}/tasks/{task_list_id}/{task_id}.json
        {agent_home}/tasks/{task_list_id}/.highwatermark
    """

    def __init__(
        self,
        config: AgentWorkspaceConfig,
        task_list_id: Optional[str] = None,
    ) -> None:
        """初始化任务存储。

        Args:
            config: 工作区配置
            task_list_id: 任务列表 ID，为 None 时自动解析
        """
        self.config = config
        self.task_list_id = resolve_task_list_id(config, task_list_id)
        self._tasks_dir = get_tasks_dir(config, self.task_list_id)
        self._hw_manager = HighWaterMarkManager()
        self._lock_manager = TaskStoreLockManager()

    @property
    def tasks_dir(self) -> Path:
        """获取任务目录路径。"""
        return self._tasks_dir

    async def _ensure_dir(self) -> None:
        """确保任务目录存在。"""
        await asyncio.to_thread(
            self._tasks_dir.mkdir, parents=True, exist_ok=True
        )

    def _serialize_task(self, task: Task) -> str:
        """序列化任务为 JSON 字符串。"""
        data = {
            "id": task.id,
            "subject": task.subject,
            "description": task.description,
            "activeForm": task.active_form,
            "owner": task.owner,
            "status": task.status,
            "blocks": task.blocks,
            "blockedBy": task.blocked_by,
            "metadata": task.metadata,
        }
        return json.dumps(data, ensure_ascii=False, indent=2)

    def _deserialize_task(self, content: str, task_id: str) -> Task:
        """从 JSON 字符串反序列化任务。"""
        data = json.loads(content)
        return Task(
            id=task_id,
            subject=data.get("subject", ""),
            description=data.get("description", ""),
            active_form=data.get("activeForm"),
            owner=data.get("owner"),
            status=data.get("status", "pending"),
            blocks=data.get("blocks", []),
            blocked_by=data.get("blockedBy", []),
            metadata=data.get("metadata", {}),
        )

    async def create_task(self, data: TaskCreate) -> str:
        """创建新任务。

        使用文件锁 + 高水位标记确保多进程安全。

        Args:
            data: 任务创建数据

        Returns:
            新创建的任务 ID
        """
        await self._ensure_dir()

        # 使用目录锁保护高水位更新
        lock = self._lock_manager.get_list_lock(self._tasks_dir)

        def _create() -> str:
            # 获取下一个 ID（使用同步版本）
            task_id = self._hw_manager.get_next_id_sync(self._tasks_dir)

            # 创建任务对象
            task = Task(
                id=str(task_id),
                subject=data.subject,
                description=data.description,
                active_form=data.active_form,
                owner=data.owner,
                status=data.status,
                blocks=data.blocks.copy(),
                blocked_by=data.blocked_by.copy(),
                metadata=data.metadata.copy(),
            )

            # 写入文件
            task_path = get_task_path(self.config, self.task_list_id, task.id)
            content = self._serialize_task(task)
            task_path.write_text(content, encoding="utf-8")

            return task.id

        return await asyncio.to_thread(lambda: with_lock(lock, _create))

    async def get_task(self, task_id: str) -> Optional[Task]:
        """获取单个任务。

        Args:
            task_id: 任务 ID

        Returns:
            任务对象，不存在时返回 None
        """
        task_path = get_task_path(self.config, self.task_list_id, task_id)

        try:
            content = await asyncio.to_thread(task_path.read_text, encoding="utf-8")
            return self._deserialize_task(content, task_id)
        except FileNotFoundError:
            return None
        except (OSError, json.JSONDecodeError):
            # 文件损坏或读取错误，视为不存在
            return None

    async def list_tasks(
        self, filters: Optional[TaskFilters] = None
    ) -> list[Task]:
        """列出任务。

        Args:
            filters: 过滤条件

        Returns:
            任务列表（按 ID 排序）
        """
        if filters is None:
            filters = TaskFilters()

        if not await asyncio.to_thread(self._tasks_dir.exists):
            return []

        tasks: list[Task] = []

        try:
            for entry in await asyncio.to_thread(lambda: list(self._tasks_dir.iterdir())):
                if entry.suffix != ".json":
                    continue

                task_id = entry.stem
                task = await self.get_task(task_id)
                if task is None:
                    continue

                # 应用过滤条件
                if filters.exclude_internal and task.is_internal():
                    continue

                if filters.status is not None and task.status != filters.status:
                    continue

                if filters.owner is not None and task.owner != filters.owner:
                    continue

                tasks.append(task)
        except OSError:
            pass

        # 按 ID 排序
        tasks.sort(key=lambda t: int(t.id))
        return tasks

    async def update_task(
        self, task_id: str, updates: TaskUpdate
    ) -> Optional[Task]:
        """更新任务。

        Args:
            task_id: 任务 ID
            updates: 更新数据

        Returns:
            更新后的任务，任务不存在时返回 None
        """
        task_path = get_task_path(self.config, self.task_list_id, task_id)

        # 使用任务文件锁
        lock = self._lock_manager.get_lock(task_path)

        def _update() -> Optional[Task]:
            # 读取现有任务
            content = task_path.read_text(encoding="utf-8")
            existing = self._deserialize_task(content, task_id)

            # 应用更新
            if updates.subject is not None:
                existing.subject = updates.subject
            if updates.description is not None:
                existing.description = updates.description
            if updates.active_form is not None:
                existing.active_form = updates.active_form
            if updates.owner is not None:
                existing.owner = updates.owner
            if updates.status is not None:
                existing.status = updates.status
            if updates.blocks is not None:
                existing.blocks = updates.blocks.copy()
            if updates.blocked_by is not None:
                existing.blocked_by = updates.blocked_by.copy()
            if updates.metadata is not None:
                # 合并 metadata，支持删除（设为 None）
                for key, value in updates.metadata.items():
                    if value is None:
                        existing.metadata.pop(key, None)
                    else:
                        existing.metadata[key] = value

            # 写回文件
            new_content = self._serialize_task(existing)
            task_path.write_text(new_content, encoding="utf-8")

            return existing

        try:
            return await asyncio.to_thread(lambda: with_lock(lock, _update))
        except FileNotFoundError:
            return None

    async def delete_task(self, task_id: str) -> bool:
        """删除任务。

        同时清理其他任务中对被删除任务的引用（cascade）。

        Args:
            task_id: 任务 ID

        Returns:
            是否成功删除（任务不存在返回 False）
        """
        task_path = get_task_path(self.config, self.task_list_id, task_id)

        # 检查任务是否存在
        if not await asyncio.to_thread(task_path.exists):
            return False

        # 使用目录锁保护 cascade 操作
        lock = self._lock_manager.get_list_lock(self._tasks_dir)

        def _delete() -> bool:
            # 更新高水位标记为当前删除的 ID（防止 ID 重用）
            # 下次创建时会使用 max(hw, file_max) + 1
            self._hw_manager._write_sync(self._tasks_dir, int(task_id))

            # 删除任务文件
            task_path.unlink()

            return True

        await asyncio.to_thread(lambda: with_lock(lock, _delete))

        # Cascade 清理其他任务中的引用
        await self._cascade_remove_references(task_id)

        return True

    async def task_exists(self, task_id: str) -> bool:
        """检查任务是否存在。

        Args:
            task_id: 任务 ID

        Returns:
            任务是否存在
        """
        task_path = get_task_path(self.config, self.task_list_id, task_id)
        return await asyncio.to_thread(task_path.exists)

    async def _cascade_remove_references(self, task_id: str) -> None:
        """清理其他任务中对指定任务的引用。

        遍历所有任务，从 blocks 和 blockedBy 中移除引用。

        Args:
            task_id: 要清理引用的任务 ID
        """
        tasks = await self.list_tasks(TaskFilters(exclude_internal=False))

        for task in tasks:
            modified = False

            # 从 blocks 中移除
            if task_id in task.blocks:
                task.blocks.remove(task_id)
                modified = True

            # 从 blocked_by 中移除
            if task_id in task.blocked_by:
                task.blocked_by.remove(task_id)
                modified = True

            if modified:
                await self.update_task(
                    task.id,
                    TaskUpdate(
                        blocks=task.blocks,
                        blocked_by=task.blocked_by,
                    ),
                )

    async def block_task(self, from_id: str, to_id: str) -> bool:
        """建立任务依赖关系。

        双向维护：from_task.blocks.append(to_id) + to_task.blockedBy.append(from_id)

        Args:
            from_id: 阻塞源任务 ID
            to_id: 被阻塞的目标任务 ID

        Returns:
            是否成功建立依赖
        """
        # 验证任务存在性
        from_task = await self.get_task(from_id)
        to_task = await self.get_task(to_id)

        if from_task is None or to_task is None:
            return False

        # 检查是否已存在
        if to_id in from_task.blocks:
            return True  # 已存在，视为成功

        # 双向更新
        from_task.blocks.append(to_id)
        to_task.blocked_by.append(from_id)

        # 持久化
        await self.update_task(from_id, TaskUpdate(blocks=from_task.blocks))
        await self.update_task(to_id, TaskUpdate(blocked_by=to_task.blocked_by))

        return True

    async def claim_task(
        self, task_id: str, claimant: str
    ) -> tuple[bool, Optional[str], Optional[Task]]:
        """认领任务。

        检查：
        - 任务是否存在
        - 是否已被认领
        - 是否已完成
        - 是否有未完成的阻塞

        Args:
            task_id: 任务 ID
            claimant: 认领者标识

        Returns:
            (success, reason, task) 三元组
        """
        # 使用目录锁保证原子性
        lock = self._lock_manager.get_list_lock(self._tasks_dir)

        def _claim() -> tuple[bool, Optional[str], Optional[Task]]:
            # 读取任务
            task_path = get_task_path(self.config, self.task_list_id, task_id)
            try:
                content = task_path.read_text(encoding="utf-8")
                task = self._deserialize_task(content, task_id)
            except FileNotFoundError:
                return False, "Task not found", None

            # 检查是否已完成
            if task.status == "completed":
                return False, "Task is already completed", task

            # 检查是否已被认领
            if task.owner is not None:
                return False, f"Task already claimed by {task.owner}", task

            # 检查是否有未完成的阻塞
            for blocker_id in task.blocked_by:
                blocker_path = get_task_path(self.config, self.task_list_id, blocker_id)
                try:
                    blocker_content = blocker_path.read_text(encoding="utf-8")
                    blocker = self._deserialize_task(blocker_content, blocker_id)
                    if blocker.status != "completed":
                        return False, "Task is blocked by uncompleted tasks", task
                except FileNotFoundError:
                    pass

            # 认领任务
            task.owner = claimant
            task.status = "in_progress"
            new_content = self._serialize_task(task)
            task_path.write_text(new_content, encoding="utf-8")

            return True, None, task

        return await asyncio.to_thread(lambda: with_lock(lock, _claim))


def with_lock(lock, func):
    """在文件锁保护下执行函数。"""
    with lock:
        return func()


# ── 同步包装器（供同步工具使用）───────────────────────────────────────


class TaskStoreSync:
    """TaskStore 的同步包装器。

    为同步工具（如 TaskUpdateRuntimeTool）提供同步 API。
    内部使用 asyncio.run() 调用异步 TaskStore。

    注意：此包装器应在已有事件循环外的上下文中使用。
    """

    def __init__(
        self,
        config: AgentWorkspaceConfig | None = None,
        task_list_id: str | None = None,
    ) -> None:
        """初始化同步存储。

        Args:
            config: 工作区配置
            task_list_id: 任务列表 ID
        """
        if config is None:
            config = resolve_agent_workspace_config()
        self._config = config
        self._task_list_id = task_list_id

    def _get_store(self) -> TaskStore:
        """获取异步存储实例。"""
        return TaskStore(self._config, self._task_list_id)

    def create_task(self, data: TaskCreate) -> str:
        """创建任务（同步）。"""
        return asyncio.run(self._get_store().create_task(data))

    def get_task(self, task_id: str) -> Task | None:
        """获取任务（同步）。"""
        return asyncio.run(self._get_store().get_task(task_id))

    def update_task(self, task_id: str, data: TaskUpdate) -> Task:
        """更新任务（同步）。"""
        return asyncio.run(self._get_store().update_task(task_id, data))

    def delete_task(self, task_id: str) -> bool:
        """删除任务（同步）。"""
        return asyncio.run(self._get_store().delete_task(task_id))

    def list_tasks(self, filters: TaskFilters | None = None) -> list[Task]:
        """列出任务（同步）。"""
        return asyncio.run(self._get_store().list_tasks(filters))

    def task_exists(self, task_id: str) -> bool:
        """检查任务是否存在（同步）。"""
        return asyncio.run(self._get_store().task_exists(task_id))

    def block_task(self, from_id: str, to_id: str) -> bool:
        """建立任务依赖关系（同步）。"""
        return asyncio.run(self._get_store().block_task(from_id, to_id))
