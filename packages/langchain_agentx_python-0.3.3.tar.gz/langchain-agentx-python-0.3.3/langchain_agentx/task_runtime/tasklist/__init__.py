"""
task_runtime/tasklist/ — CC 任务列表存储子系统

职责：
    实现 Claude Code 对等的任务列表管理能力：
    - 任务持久化存储（文件系统，每个任务一个 JSON 文件）
    - 任务依赖关系管理（blocks / blockedBy 双向维护）
    - 高水位标记机制（防止删除后 ID 重用）
    - 文件锁保护（多进程并发安全）
    - 任务认领与状态流转

与 CC 对应：
    CC src/utils/tasks.ts（863 行）是任务存储核心，本模块与其对等。
"""

from .models import (
    MAX_ACTIVE_FORM_LENGTH,
    MAX_DESCRIPTION_LENGTH,
    MAX_SUBJECT_LENGTH,
    ClaimResult,
    Task,
    TaskCreate,
    TaskFilters,
    TaskListStatus,
    TaskStatus,
    TaskUpdate,
    TaskUpdateStatus,
)
from .store import TaskStore, TaskStoreSync
from .lock import FileLockNotAvailableError, TaskStoreLockManager

__all__ = [
    "TaskStore",
    "TaskStoreSync",
    "Task",
    "TaskCreate",
    "TaskUpdate",
    "TaskFilters",
    "TaskStatus",
    "TaskListStatus",
    "TaskUpdateStatus",
    "ClaimResult",
    "TaskStoreLockManager",
    "FileLockNotAvailableError",
    "MAX_SUBJECT_LENGTH",
    "MAX_DESCRIPTION_LENGTH",
    "MAX_ACTIVE_FORM_LENGTH",
]
