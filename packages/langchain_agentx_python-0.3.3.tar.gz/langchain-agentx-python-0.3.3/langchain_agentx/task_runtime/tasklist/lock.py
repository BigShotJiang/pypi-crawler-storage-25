"""
task_runtime/tasklist/lock.py — 任务存储文件锁管理

职责：
    提供文件锁保护，确保多进程并发安全：
    - 单个任务文件锁
    - 任务列表目录锁
    - 软依赖处理（filelock 不存在时友好错误）

链路位置：
    TaskStore → TaskStoreLockManager → filelock.FileLock

与 CC 对应：
    CC src/utils/tasks.ts 中 withFileLock 函数。

裁剪范围（v1）：
    - 使用 filelock 库作为实现
    - 默认超时 3.0 秒
    - 错误信息包含锁文件路径
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from filelock import FileLock


class FileLockNotAvailableError(RuntimeError):
    """filelock 库未安装错误。"""

    def __init__(self) -> None:
        super().__init__(
            "filelock library is required for task store. "
            "Install with: pip install filelock"
        )


class TaskStoreLockTimeoutError(TimeoutError):
    """获取文件锁超时错误。"""

    def __init__(self, lock_path: Path, timeout: float) -> None:
        super().__init__(
            f"Timeout waiting for lock after {timeout}s: {lock_path}. "
            "Another process may be holding the lock."
        )
        self.lock_path = lock_path
        self.timeout = timeout


def _ensure_filelock() -> type[FileLock]:
    """确保 filelock 库可用。"""
    try:
        from filelock import FileLock as FL
        return FL  # type: ignore
    except ImportError as e:
        raise FileLockNotAvailableError() from e


class TaskStoreLockManager:
    """任务存储文件锁管理器。

    为任务存储提供文件锁保护，防止多进程并发冲突。

    锁文件路径：
    - 任务锁：{task_path}.lock
    - 目录锁：{tasks_dir}/.lock
    """

    def __init__(self, timeout: float = 3.0) -> None:
        """初始化锁管理器。

        Args:
            timeout: 锁超时时间（秒），默认 3.0
        """
        self.timeout = timeout
        self._filelock_class: type[FileLock] | None = None

    def _get_filelock_class(self) -> type[FileLock]:
        """延迟导入 FileLock 类（软依赖）。"""
        if self._filelock_class is None:
            self._filelock_class = _ensure_filelock()
        return self._filelock_class

    def get_lock(self, task_path: Path) -> "FileLock":
        """获取单个任务的文件锁。

        Args:
            task_path: 任务文件路径

        Returns:
            FileLock 实例
        """
        lock_path = task_path.with_suffix(task_path.suffix + ".lock")
        FileLock = self._get_filelock_class()
        return FileLock(lock_path, timeout=self.timeout)

    def get_list_lock(self, tasks_dir: Path) -> "FileLock":
        """获取任务列表目录锁。

        用于原子性操作（如认领任务、高水位更新）。

        Args:
            tasks_dir: 任务目录

        Returns:
            FileLock 实例
        """
        lock_path = tasks_dir / ".lock"
        FileLock = self._get_filelock_class()
        return FileLock(lock_path, timeout=self.timeout)
