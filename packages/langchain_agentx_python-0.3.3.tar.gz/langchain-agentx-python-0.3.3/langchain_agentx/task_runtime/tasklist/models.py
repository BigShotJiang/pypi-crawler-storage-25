"""
task_runtime/tasklist/models.py — CC 任务列表数据模型

职责：
    定义 Claude Code 对等的任务列表数据契约：
    - TaskStatus：任务状态（pending/in_progress/committed）
    - Task：任务完整数据结构
    - TaskCreate：创建任务输入（不含自动生成字段）
    - TaskUpdate：更新任务输入（全部可选）
    - TaskFilters：列表过滤条件
    - ClaimResult：任务认领结果

链路位置：
    TaskListRuntimeTool/TaskGetRuntimeTool → TaskStore → models

与 CC 对应：
    CC src/utils/tasks.ts 中 Task 接口、TaskStatus、ClaimResult 等。

裁剪范围（v1）：
    - 基础字段：id, subject, description, status, blocks, blockedBy
    - metadata 支持 _internal 标记
    - owner 字段预留（v1 简化，仅存储不校验）
    - active_form 用于 UI 显示
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

TaskStatus = Literal["pending", "in_progress", "completed"]

# 与 TaskStatus 同一对象；供 langchain_agentx.task_runtime 顶层导出为 TaskListStatus，
# 以区别于编排层 core.types.TaskStatus 枚举。
TaskListStatus = TaskStatus

# 任务更新状态（包含 deleted，用于 TaskUpdate 工具）
TaskUpdateStatus = Literal["pending", "in_progress", "completed", "deleted"]

# 字段长度限制常量（基于用户体验与 CC 实践）
MAX_SUBJECT_LENGTH: int = 120
MAX_DESCRIPTION_LENGTH: int = 5000
MAX_ACTIVE_FORM_LENGTH: int = 100


@dataclass
class Task:
    """任务完整数据结构。

    对应 CC Task 接口，每个任务对应一个 JSON 文件。

    字段说明：
        id: 任务唯一 ID（数字字符串，高水位标记生成）
        subject: 任务简短标题
        description: 任务详细描述
        active_form: 进行中时显示的文本（如 "Fixing authentication bug"）
        owner: 任务所有者（Agent ID 或 None）
        status: 任务状态
        blocks: 此任务阻塞的任务 ID 列表
        blocked_by: 阻塞此任务的任务 ID 列表
        metadata: 附加元数据（_internal=True 表示内部任务）
    """

    id: str
    subject: str
    description: str
    active_form: Optional[str] = None
    owner: Optional[str] = None
    status: TaskStatus = "pending"
    blocks: list[str] = field(default_factory=list)
    blocked_by: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def is_internal(self) -> bool:
        """判断是否为内部任务（不在 UI 显示）。"""
        return self.metadata.get("_internal", False)


@dataclass
class TaskCreate:
    """创建任务输入模型。

    不含自动生成字段（id、默认字段）。
    """

    subject: str
    description: str
    active_form: Optional[str] = None
    owner: Optional[str] = None
    status: TaskStatus = "pending"
    blocks: list[str] = field(default_factory=list)
    blocked_by: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskUpdate:
    """更新任务输入模型。

    全部可选，仅更新提供的字段。
    """

    subject: Optional[str] = None
    description: Optional[str] = None
    active_form: Optional[str] = None
    owner: Optional[str] = None
    status: Optional[TaskStatus] = None
    blocks: Optional[list[str]] = None
    blocked_by: Optional[list[str]] = None
    metadata: Optional[dict[str, Any]] = None


@dataclass
class TaskFilters:
    """任务列表过滤条件。"""

    status: Optional[TaskStatus] = None
    owner: Optional[str] = None
    exclude_internal: bool = True


@dataclass
class ClaimResult:
    """任务认领结果。

    对应 CC ClaimResult 接口。
    """

    success: bool
    reason: Optional[str] = None
    task: Optional[Task] = None
