"""
adapter.py — Workflow 事件适配器主控制器

职责：
    - 协调各 Handler 处理事件
    - 维护 WorkflowAdapterState 状态机
    - 统一事件产出接口
    - 处理嵌套子图的 push/pop 逻辑

链路位置：
    - Layer 3: Workflow 事件适配器
    - 核心控制器，协调 Stack、DepthResolver、Handler

当前裁剪范围：
    - 只支持 Workflow 事件（Agent 事件在 Phase 2+）
    - 不包含 OrchestratorWorkflow 事件处理（Phase 2+）
"""

from typing import Any, Dict, List

from langchain_agentx.workflow.event_adapter.types import (
    WorkflowEvent,
    WorkflowEventType,
    WorkflowAdapterState,
)
from langchain_agentx.workflow.event_adapter.stack import WorkflowStack
from langchain_agentx.workflow.event_adapter.depth_resolver import DepthResolver
from langchain_agentx.workflow.event_adapter.handlers import (
    StageHandler,
    ParallelHandler,
    RouteHandler,
)


class WorkflowEventAdapter:
    """Workflow 事件适配器（主控制器）

    职责：
        - 协调各 Handler 处理事件
        - 维护 WorkflowAdapterState 状态机
        - 统一事件产出接口
        - 处理嵌套子图检测和栈管理

    设计约束（v2.5）：
        - consume() 方法为同步接口，返回 List[WorkflowEvent]
        - 所有事件必须是成对的（start/end），或单次性的
        - 配置驱动节点名识别规则，不硬编码
        - push 基于"子图启动事件"判断（node == "" and ns.endswith("|")）
    """

    def __init__(
        self,
        workflow_id: str,
        session_id: str | None = None,
        config: Dict[str, Any] | None = None,
    ):
        """初始化适配器

        Args:
            workflow_id: Workflow 标识符
            session_id: 会话 ID（可选）
            config: 配置字典，可包含：
                - stage_node_prefix: stage 节点前缀（默认 "stage_"）
                - parallel_node_prefix: parallel 节点前缀（默认 "parallel_"）
                - aggregate_node_name: aggregate 节点名（默认 "aggregate"）
                - route_node_prefix: route 节点前缀（默认 "route_"）
                - total_stages: ChainingWorkflow 的 stage 总数
        """
        self.workflow_id = workflow_id
        self.config = config or {}
        self.state = WorkflowAdapterState()

        # 注入 session_id
        self.state.session_id = session_id

        # 初始化 total_stages（从 config 传入）
        self.state.total_stages = self.config.get("total_stages", 0)

        # 协作者（Phase 1：不包含 Orchestrator）
        self._stack = WorkflowStack(workflow_id)
        self._depth_resolver = DepthResolver()
        self._stage_handler = StageHandler(self.state, self._stack, self.config)
        self._parallel_handler = ParallelHandler(self.state, self._stack, self.config)
        self._route_handler = RouteHandler(self.state, self._stack, self.config)

        # 初始化状态
        self.state.root_workflow_id = workflow_id

    def consume(self, event: Dict[str, Any]) -> List[WorkflowEvent]:
        """消费单个 LangGraph 事件，返回 WorkflowEvent 列表

        设计说明（v2.5）：
            - 同步接口，便于组合适配器统一驱动
            - 返回 List 而非 Optional，支持 1:N 事件映射
            - 每次调用更新状态机状态

        Args:
            event: LangGraph 原始事件

        Returns:
            WorkflowEvent 列表
        """
        events: List[WorkflowEvent] = []
        event_type = event.get("event", "")
        metadata = event.get("metadata", {})
        node = metadata.get("langgraph_node", "")

        # === 嵌套子图检测（v2.5 修订）===
        # 使用 "node == "" 守卫 + 深度差判断 push/pop"
        is_subgraph_start = self._depth_resolver.is_subgraph_entry_event(event)

        if is_subgraph_start:
            # 进入子图：push 一次
            child_id = self._depth_resolver.extract_child_workflow_id_from_parent(event)
            if child_id:
                # v2.5 修订：pattern 延迟填充，push 时为空
                self._stack.push(child_id, pattern="")
                events.append(self._build_event(
                    WorkflowEventType.SUBWORKFLOW_START,
                    {"child_workflow_id": child_id}
                ))

        # 弹栈逻辑：子图结束（ns 不再以 | 结尾的空 node 事件）
        elif event_type == "on_chain_end" and node == "":
            ns = metadata.get("langgraph_checkpoint_ns", "")
            # ns 不以 | 结尾且栈非空表示离开子图
            if not ns.endswith("|") and self._stack.current_depth > 0:
                events.append(self._build_event(
                    WorkflowEventType.SUBWORKFLOW_END,
                    {"child_workflow_id": self._stack.current_workflow_id}
                ))
                self._stack.pop()

        # === Workflow 生命周期事件 ===
        # 修复（P1-1, v2.3）：WORKFLOW_START 只发给根图
        # 修复（P1-4, v2.5）：增加 name 校验，使用 pending_starts 去重
        if event_type == "on_chain_start" and not node and self._stack.current_depth == 0:
            # 额外校验 event name，确保是图的启动事件
            event_name = event.get("name", "")
            if event_name and not self.state.pending_starts.get("workflow"):
                events.append(self._build_event(
                    WorkflowEventType.WORKFLOW_START,
                    {"workflow_id": self.workflow_id}
                ))
                self.state.pending_starts["workflow"] = True

        elif event_type == "on_chain_end" and not node and self._stack.current_depth == 0:
            # 校验 event name 并清理 pending_starts
            event_name = event.get("name", "")
            if event_name and self.state.pending_starts.get("workflow"):
                events.append(self._build_event(
                    WorkflowEventType.WORKFLOW_END,
                    {"workflow_id": self.workflow_id}
                ))
                self.state.pending_starts.pop("workflow", None)

        elif event_type == "on_chain_error":
            events.append(self._build_error_event(event))

        # === Pattern 事件路由（使用 Handler.matches() 方法）===
        if self._stage_handler.matches(node):
            events.extend(self._stage_handler.consume(event))
            self._update_stack_pattern(event)  # v2.5: 回填 pattern

        elif self._parallel_handler.matches(node):
            events.extend(self._parallel_handler.consume(event))
            self._update_stack_pattern(event)  # v2.5: 回填 pattern

        elif self._route_handler.matches(node):
            events.extend(self._route_handler.consume(event))
            self._update_stack_pattern(event)  # v2.5: 回填 pattern

        # === OrchestratorWorkflow 事件（Phase 2+）===
        # elif ...:
        #     events.extend(self._orchestrator_tracker.consume(event))

        # === 通用节点事件（未匹配任何 Handler）===
        elif event_type == "on_chain_start" and node:
            events.append(self._build_event(
                WorkflowEventType.NODE_START,
                {"node": node}
            ))
        elif event_type == "on_chain_end" and node:
            events.append(self._build_event(
                WorkflowEventType.NODE_END,
                {"node": node}
            ))

        # === 后处理：回填 workflow_path 和其他字段 ===
        for e in events:
            if not e.workflow_path:  # Handler 产出的事件 path 为空
                e.workflow_path = self._stack.build_path()
            e.workflow_depth = self._stack.current_depth
            e.session_id = self.state.session_id
            e.parent_workflow_id = self._stack.parent_workflow_id

        # === 更新序列号 ===
        for e in events:
            self.state.sequence_no += 1
            e.sequence_no = self.state.sequence_no

        # === 更新 last_seen_node ===
        if node:
            self.state.last_seen_node = node

        return events

    def _build_event(
        self,
        event_type: WorkflowEventType,
        data: Dict[str, Any],
    ) -> WorkflowEvent:
        """构建 WorkflowEvent

        Args:
            event_type: 事件类型
            data: 事件数据

        Returns:
            WorkflowEvent 实例
        """
        return WorkflowEvent(
            event_type=event_type,
            data=data,
            workflow_id=self._stack.current_workflow_id,
            workflow_path=self._stack.build_path(),
            workflow_depth=self._stack.current_depth,
            session_id=self.state.session_id,
            parent_workflow_id=self._stack.parent_workflow_id,
        )

    def _build_error_event(self, event: Dict[str, Any]) -> WorkflowEvent:
        """构建错误事件

        Args:
            event: LangGraph 错误事件

        Returns:
            WorkflowEvent 实例（event_type = WORKFLOW_ERROR）
        """
        metadata = event.get("metadata", {})
        node = metadata.get("langgraph_node", "")
        data = event.get("data", {})

        error_info = data.get("error") if isinstance(data, dict) else str(data)

        return WorkflowEvent(
            event_type=WorkflowEventType.WORKFLOW_ERROR,
            data={
                "error": error_info,
                "node": node,
            },
            workflow_id=self._stack.current_workflow_id,
            workflow_path=self._stack.build_path(),
            workflow_depth=self._stack.current_depth,
            session_id=self.state.session_id,
            parent_workflow_id=self._stack.parent_workflow_id,
        )

    def _identify_pattern(self, node: str) -> str:
        """根据节点名识别当前 pattern（v2.5 修订）

        Args:
            node: 节点名

        Returns:
            pattern 字符串（chaining/routing/parallelization/orchestrator），
            未知节点返回空字符串

        修复（P1-6, v2.5）：使用 Handler.matches() 方法而不是访问私有属性
        """
        if self._stage_handler.matches(node):
            return self._stage_handler.PATTERN
        elif self._parallel_handler.matches(node):
            return self._parallel_handler.PATTERN
        elif self._route_handler.matches(node):
            return self._route_handler.PATTERN
        return ""

    def _update_stack_pattern(self, event: Dict[str, Any]) -> None:
        """从事件推断 pattern 并更新栈顶（v2.5 新增）

        当子图内第一个被 Handler 消费的事件到达时，
        根据节点名推断 pattern 并回填到栈顶。

        Args:
            event: 当前事件
        """
        metadata = event.get("metadata", {})
        node = metadata.get("langgraph_node", "")

        if node:
            pattern = self._identify_pattern(node)
            if pattern:
                self._stack.update_top_pattern(pattern)


__all__ = ["WorkflowEventAdapter"]
