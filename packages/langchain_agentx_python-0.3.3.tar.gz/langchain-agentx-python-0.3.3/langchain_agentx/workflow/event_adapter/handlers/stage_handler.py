"""
stage_handler.py — ChainingWorkflow 事件处理器

职责：
    - 处理 stage_* 节点的事件
    - 追踪 stage 索引和总数
    - 返回自己负责的 pattern

链路位置：
    - Layer 3: Workflow 事件适配器
    - 被 WorkflowEventAdapter 使用

当前裁剪范围：
    - 只处理 stage_* 前缀的节点
    - 不支持动态 stage 数（total_stages 从 config 传入）
"""

from typing import Any, Dict, List

from langchain_agentx.workflow.event_adapter.types import (
    WorkflowEvent,
    WorkflowEventType,
    WorkflowAdapterState,
)
from langchain_agentx.workflow.event_adapter.stack import WorkflowStack


class StageHandler:
    """ChainingWorkflow 事件处理器

    职责：
        - 处理 stage_* 节点的事件
        - 追踪 stage 索引和总数
        - 返回自己负责的 pattern（v2.5，用于嵌套场景）

    修复（P1-6, v2.5）：添加公共 matches() 方法，避免外部访问私有属性
    """

    # 每个 Handler 声明自己负责的 pattern
    PATTERN: str = "chaining"

    def __init__(
        self,
        state: WorkflowAdapterState,
        stack: WorkflowStack,
        config: Dict[str, Any],
    ):
        """初始化 StageHandler

        Args:
            state: 适配器状态
            stack: 嵌套栈（用于获取 workflow_path 和 depth）
            config: 配置字典
        """
        self._state = state
        self._stack = stack
        self._config = config
        self._prefix = config.get("stage_node_prefix", "stage_")

    def matches(self, node: str) -> bool:
        """判断节点是否由本 Handler 负责（v2.5 新增）

        Args:
            node: 节点名

        Returns:
            True 如果节点是 stage_* 格式
        """
        return node.startswith(self._prefix)

    def consume(self, event: Dict[str, Any]) -> List[WorkflowEvent]:
        """处理 stage 节点事件

        Args:
            event: LangGraph 原始事件

        Returns:
            WorkflowEvent 列表
        """
        events: List[WorkflowEvent] = []
        event_type = event.get("event", "")
        node = event.get("metadata", {}).get("langgraph_node", "")

        # 只处理 stage_* 节点
        if not node.startswith(self._prefix):
            return events

        # 提取 stage 索引
        try:
            stage_index = int(node.replace(self._prefix, ""))
        except ValueError:
            return events  # 无效索引，不产生事件

        # 修复（P1-3, v2.5）：从 config 获取 total_stages
        total_stages = self._config.get("total_stages", 0)

        if event_type == "on_chain_start":
            self._state.current_stage = stage_index
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.STAGE_START,
                data={
                    "stage_index": stage_index,
                    "stage_node": node,
                    "total_stages": total_stages,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_end":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.STAGE_DONE,
                data={
                    "stage_index": stage_index,
                    "stage_node": node,
                    "total_stages": total_stages,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_error":
            error_data = event.get("data", {})
            error_info = error_data.get("error") if isinstance(error_data, dict) else str(error_data)
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.STAGE_FAILED,
                data={
                    "stage_index": stage_index,
                    "stage_node": node,
                    "error": error_info,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        return events


__all__ = ["StageHandler"]
