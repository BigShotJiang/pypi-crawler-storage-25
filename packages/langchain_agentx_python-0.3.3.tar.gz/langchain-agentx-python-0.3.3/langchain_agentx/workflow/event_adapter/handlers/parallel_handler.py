"""
parallel_handler.py — ParallelizationWorkflow 事件处理器

职责：
    - 处理 parallel_* 节点的事件
    - 处理 aggregate 节点的事件
    - 追踪并行项索引和总数

链路位置：
    - Layer 3: Workflow 事件适配器
    - 被 WorkflowEventAdapter 使用

当前裁剪范围：
    - 只处理 parallel_* 前缀的节点和 aggregate 节点
    - 不支持动态并发控制（max_concurrency 由 LangGraph 处理）
"""

from typing import Any, Dict, List

from langchain_agentx.workflow.event_adapter.types import (
    WorkflowEvent,
    WorkflowEventType,
    WorkflowAdapterState,
)
from langchain_agentx.workflow.event_adapter.stack import WorkflowStack


class ParallelHandler:
    """ParallelizationWorkflow 事件处理器

    职责：
        - 处理 parallel_* 并行项节点的事件
        - 处理 aggregate 聚合节点的事件
        - 追踪并行项索引和总数

    修复（P1-6, v2.5）：添加公共 matches() 方法
    """

    PATTERN: str = "parallelization"

    def __init__(
        self,
        state: WorkflowAdapterState,
        stack: WorkflowStack,
        config: Dict[str, Any],
    ):
        """初始化 ParallelHandler

        Args:
            state: 适配器状态
            stack: 嵌套栈
            config: 配置字典
        """
        self._state = state
        self._stack = stack
        self._config = config
        self._prefix = config.get("parallel_node_prefix", "parallel_")
        self._aggregate_node = config.get("aggregate_node_name", "aggregate")

    def matches(self, node: str) -> bool:
        """判断节点是否由本 Handler 负责（v2.5 新增）

        Args:
            node: 节点名

        Returns:
            True 如果节点是 parallel_* 格式或 aggregate 节点
        """
        return node.startswith(self._prefix) or node == self._aggregate_node

    def consume(self, event: Dict[str, Any]) -> List[WorkflowEvent]:
        """处理并行节点事件

        Args:
            event: LangGraph 原始事件

        Returns:
            WorkflowEvent 列表
        """
        events: List[WorkflowEvent] = []
        event_type = event.get("event", "")
        node = event.get("metadata", {}).get("langgraph_node", "")

        # 处理 aggregate 节点
        if node == self._aggregate_node:
            return self._handle_aggregate(event, event_type, node)

        # 处理 parallel_* 节点
        if node.startswith(self._prefix):
            return self._handle_parallel_item(event, event_type, node)

        return events

    def _handle_aggregate(self, event: Dict[str, Any], event_type: str, node: str) -> List[WorkflowEvent]:
        """处理 aggregate 节点事件"""
        events: List[WorkflowEvent] = []

        if event_type == "on_chain_start":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_AGGREGATE_START,
                data={"node": node},
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_end":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_AGGREGATE_DONE,
                data={"node": node},
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_error":
            error_data = event.get("data", {})
            error_info = error_data.get("error") if isinstance(error_data, dict) else str(error_data)
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_ITEM_FAILED,  # aggregate 失败也用 ITEM_FAILED
                data={"node": node, "error": error_info},
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        return events

    def _handle_parallel_item(self, event: Dict[str, Any], event_type: str, node: str) -> List[WorkflowEvent]:
        """处理 parallel_* 并行项事件"""
        events: List[WorkflowEvent] = []

        # 提取并行项索引
        try:
            parallel_index = int(node.replace(self._prefix, ""))
        except ValueError:
            parallel_index = -1

        if event_type == "on_chain_start":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_ITEM_START,
                data={
                    "parallel_index": parallel_index,
                    "parallel_node": node,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_end":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_ITEM_DONE,
                data={
                    "parallel_index": parallel_index,
                    "parallel_node": node,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_error":
            error_data = event.get("data", {})
            error_info = error_data.get("error") if isinstance(error_data, dict) else str(error_data)
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.PARALLEL_ITEM_FAILED,
                data={
                    "parallel_index": parallel_index,
                    "parallel_node": node,
                    "error": error_info,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        return events


__all__ = ["ParallelHandler"]
