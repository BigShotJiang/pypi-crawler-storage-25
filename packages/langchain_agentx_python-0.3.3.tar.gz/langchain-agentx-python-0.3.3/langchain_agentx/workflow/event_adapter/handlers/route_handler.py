"""
route_handler.py — RoutingWorkflow 事件处理器

职责：
    - 处理 route_* 节点的事件
    - 追踪分支选择和历史

链路位置：
    - Layer 3: Workflow 事件适配器
    - 被 WorkflowEventAdapter 使用

当前裁剪范围：
    - 只处理 route_* 前缀的节点
    - 不支持动态路由表（routes 在 __init__ 时固定）
"""

from typing import Any, Dict, List

from langchain_agentx.workflow.event_adapter.types import (
    WorkflowEvent,
    WorkflowEventType,
    WorkflowAdapterState,
)
from langchain_agentx.workflow.event_adapter.stack import WorkflowStack


class RouteHandler:
    """RoutingWorkflow 事件处理器

    职责：
        - 处理 route_* 分支节点的事件
        - 追踪分支选择和分支历史

    修复（P1-6, v2.5）：添加公共 matches() 方法
    """

    PATTERN: str = "routing"

    def __init__(
        self,
        state: WorkflowAdapterState,
        stack: WorkflowStack,
        config: Dict[str, Any],
    ):
        """初始化 RouteHandler

        Args:
            state: 适配器状态
            stack: 嵌套栈
            config: 配置字典
        """
        self._state = state
        self._stack = stack
        self._config = config
        self._prefix = config.get("route_node_prefix", "route_")

    def matches(self, node: str) -> bool:
        """判断节点是否由本 Handler 负责（v2.5 新增）

        Args:
            node: 节点名

        Returns:
            True 如果节点是 route_* 格式
        """
        return node.startswith(self._prefix)

    def consume(self, event: Dict[str, Any]) -> List[WorkflowEvent]:
        """处理路由节点事件

        Args:
            event: LangGraph 原始事件

        Returns:
            WorkflowEvent 列表
        """
        events: List[WorkflowEvent] = []
        event_type = event.get("event", "")
        node = event.get("metadata", {}).get("langgraph_node", "")

        # 提取分支 key（去掉 route_ 前缀）
        branch = node.replace(self._prefix, "") if node.startswith(self._prefix) else node

        if event_type == "on_chain_start":
            # 记录活跃分支
            self._state.active_branch = branch
            # 添加到分支历史
            if branch not in self._state.branch_history:
                self._state.branch_history.append(branch)

            events.append(WorkflowEvent(
                event_type=WorkflowEventType.ROUTE_BRANCH_START,
                data={
                    "branch": branch,
                    "branch_node": node,
                    "branch_history": list(self._state.branch_history),
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_end":
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.ROUTE_BRANCH_DONE,
                data={
                    "branch": branch,
                    "branch_node": node,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        elif event_type == "on_chain_error":
            error_data = event.get("data", {})
            error_info = error_data.get("error") if isinstance(error_data, dict) else str(error_data)
            # 分支失败也用 ROUTE_BRANCH_DONE 表示（带上 error 信息）
            events.append(WorkflowEvent(
                event_type=WorkflowEventType.ROUTE_BRANCH_DONE,
                data={
                    "branch": branch,
                    "branch_node": node,
                    "error": error_info,
                },
                workflow_id=self._stack.current_workflow_id,
                workflow_path=self._stack.build_path(),
                workflow_depth=self._stack.current_depth,
            ))

        return events


__all__ = ["RouteHandler"]
