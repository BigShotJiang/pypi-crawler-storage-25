"""
stack.py — Workflow 嵌套栈管理

职责：
    - 维护 workflow_id 栈
    - 构建 workflow_path
    - 追踪当前深度
    - 提供父 workflow_id 访问
    - 每层维护 pattern 信息（v2.5）

链路位置：
    - Layer 3: Workflow 事件适配器
    - 被 WorkflowEventAdapter 使用

当前裁剪范围：
    - 不支持并发场景下的线程安全（WorkflowEventAdapter 单线程使用）
"""

from typing import List, Tuple


class WorkflowStack:
    """Workflow 嵌套栈管理

    职责：
        - 维护 workflow_id 栈
        - 构建 workflow_path
        - 追踪当前深度
        - 提供父 workflow_id 访问
        - 每层维护 pattern 信息（v2.5，修复嵌套覆盖问题）

    设计原则（v2.5）：
        - 栈元素为 (workflow_id, pattern) 元组
        - push 时可指定 pattern（或延迟填充）
        - pop 返回 (workflow_id, pattern) 元组

    Attributes:
        _stack: 栈，存储 (workflow_id, pattern) 元组
        _root_id: 根 Workflow ID
    """

    def __init__(self, root_workflow_id: str):
        """初始化嵌套栈

        Args:
            root_workflow_id: 根 Workflow ID
        """
        self._stack: List[Tuple[str, str]] = []  # (workflow_id, pattern) 元组
        self._root_id = root_workflow_id

    @property
    def current_depth(self) -> int:
        """获取当前嵌套深度

        Returns:
            嵌套深度，根层为 0
        """
        return len(self._stack)

    @property
    def current_workflow_id(self) -> str:
        """获取当前 Workflow ID

        Returns:
            当前 Workflow ID，栈空时返回根 ID
        """
        return self._stack[-1][0] if self._stack else self._root_id

    @property
    def current_pattern(self) -> str:
        """获取当前层的 pattern（v2.5 新增）

        Returns:
            当前 pattern（chaining/routing/parallelization/orchestrator），
            根层返回空字符串
        """
        return self._stack[-1][1] if self._stack else ""

    @property
    def parent_workflow_id(self) -> str | None:
        """获取父 Workflow ID

        Returns:
            父 Workflow ID，无父时返回 None

        封装实现，避免外部直接访问 _stack[-2]
        """
        if len(self._stack) >= 2:
            return self._stack[-2][0]
        if len(self._stack) == 1:
            return self._root_id
        return None

    def push(self, workflow_id: str, pattern: str = "") -> None:
        """进入子 Workflow

        Args:
            workflow_id: 子 Workflow ID
            pattern: 当前层的 pattern（v2.5 新增）
        """
        self._stack.append((workflow_id, pattern))

    def pop(self) -> Tuple[str, str] | None:
        """退出子 Workflow

        Returns:
            (workflow_id, pattern) 元组，如果栈空则返回 None
        """
        return self._stack.pop() if self._stack else None

    def update_top_pattern(self, pattern: str) -> bool:
        """更新栈顶的 pattern（v2.5 新增）

        Args:
            pattern: 新的 pattern 值

        Returns:
            True 如果更新成功，False 如果栈空
        """
        if self._stack:
            workflow_id, _ = self._stack[-1]
            self._stack[-1] = (workflow_id, pattern)
            return True
        return False

    def build_path(self) -> str:
        """构建当前 workflow_path

        Returns:
            完整的 workflow_path，如 "wiki-build>stage_1>parallel_0"
        """
        if not self._stack:
            return self._root_id
        return ">".join([self._root_id] + [item[0] for item in self._stack])

    def is_in_nested(self) -> bool:
        """判断是否在嵌套中

        Returns:
            True 如果当前在嵌套子图中
        """
        return len(self._stack) > 0


__all__ = ["WorkflowStack"]
