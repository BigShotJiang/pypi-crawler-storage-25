"""
event_adapter — Workflow 事件适配器模块

职责：
    - 将 LangGraph 原始事件加工成结构化 WorkflowEvent
    - 支持 4 种 Workflow 模式（Chaining、Parallelization、Routing）
    - 支持嵌套 Workflow 事件

当前裁剪范围：
    - Phase 1：基础设施（types、stack、depth_resolver）✅
    - Phase 2：Handler 实现（Stage、Parallel、Route）✅
    - Phase 3：主控制器实现（WorkflowEventAdapter）✅
    - Phase 4：SDK 集成
"""

from .types import (
    WorkflowEventType,
    WorkflowEvent,
    WorkflowAdapterState,
)
from .stack import WorkflowStack
from .depth_resolver import DepthResolver
from .adapter import WorkflowEventAdapter

__all__ = [
    "WorkflowEventType",
    "WorkflowEvent",
    "WorkflowAdapterState",
    "WorkflowStack",
    "DepthResolver",
    "WorkflowEventAdapter",
]
