"""
depth_resolver.py — LangGraph 嵌套深度解析器

职责：
    - 从 LangGraph 事件提取嵌套深度
    - 判断是否是子图启动事件
    - 从事件中提取子 Workflow ID

链路位置：
    - Layer 3: Workflow 事件适配器
    - 被 WorkflowEventAdapter 使用

当前裁剪范围：
    - 仅支持 LangGraph v2 事件格式
    - 不支持 configurable.workflow_path（经验证不存在于事件 metadata）
"""

from typing import Any


class DepthResolver:
    """LangGraph 嵌套深度解析器

    职责：
        - 从 LangGraph 事件提取嵌套深度
        - 判断是否是子图启动事件
        - 从事件中提取子 Workflow ID

    设计原则（v2.5）：
        - 仅使用官方 langgraph_checkpoint_ns（| 分段）
        - 删除 configurable.workflow_path 备选方案（经验证不存在于事件 metadata）
        - 保留尾部 |（用于判断子图启动事件）

    单测样本（基于真实事件验证）：
        ""                               → 0  (根图，ns 为空)
        "stage_0:42c9b782-..."            → 1  (普通节点，单层 ns)
        "stage_1:abc|"                    → 1  (子图启动，尾部 |)
        "stage_1:abc|parallel_0:def"      → 2  (子图内节点，两层 ns)
    """

    def extract_depth(self, event: dict) -> int:
        """从事件中提取嵌套深度

        Args:
            event: LangGraph 事件字典

        Returns:
            嵌套深度，根图为 0

        深度计算规则（v2.5）：
            - ""（根图，无 ns）→ 0
            - "stage_0:uuid"（普通节点）→ 1
            - "stage_1:uuid|"（子图启动）→ 1（末尾 | 后的空段不计）
            - "stage_1:uuid|parallel_0:uuid"（子图内节点）→ 2
        """
        metadata = event.get("metadata", {})
        ns = metadata.get("langgraph_checkpoint_ns", "")

        if ns:
            # v2.5 修订：去掉末尾空段后再计数
            # "stage_1:uuid|" → split → ["stage_1:uuid", ""] → 过滤空段 → 长度 1
            # "stage_1:uuid|parallel_0:uuid" → split → ["stage_1:uuid", "parallel_0:uuid"] → 长度 2
            segments = [s for s in ns.split("|") if s]
            return len(segments)

        return 0

    def is_subgraph_entry_event(self, event: dict) -> bool:
        """判断当前事件是否是子图启动事件（v2.5 新增）

        修复（v2.5）：
            - 使用"空 node + ns 尾部管道符"判断
            - 这是 LangGraph 发送的"子图启动"事件特征

        Args:
            event: LangGraph 事件字典

        Returns:
            True 如果当前事件是子图启动事件
        """
        event_type = event.get("event", "")
        metadata = event.get("metadata", {})
        node = metadata.get("langgraph_node", "")
        ns = metadata.get("langgraph_checkpoint_ns", "")

        # 子图启动事件特征：
        # 1. 是 on_chain_start 事件
        # 2. node 为空（LangGraph 对子图启动的特征）
        # 3. ns 非空且以 | 结尾（表示刚进入嵌套层级）
        if event_type != "on_chain_start":
            return False
        if node != "":
            return False
        # ns 以 | 结尾表示刚进入嵌套层级（如 "stage_1:uuid|"）
        return bool(ns) and ns.endswith("|")

    def extract_child_workflow_id(self, event: dict) -> str | None:
        """从事件中提取子 Workflow ID（子图内部节点事件）

        Args:
            event: LangGraph 事件字典

        Returns:
            子 Workflow ID，如果不是子图则返回 None

        适用场景：
            - 适用于子图内部节点事件（ns 包含完整路径）
            - 从 checkpoint_ns 最后一节提取
        """
        metadata = event.get("metadata", {})
        ns = metadata.get("langgraph_checkpoint_ns", "")

        if ns:
            # 取最后一节 "node:uuid" 中的 node 部分
            last_segment = ns.split("|")[-1]
            return last_segment.split(":")[0] if ":" in last_segment else last_segment

        return None

    def extract_child_workflow_id_from_parent(self, event: dict) -> str | None:
        """从父节点名推断子 Workflow ID（子图启动事件）

        适用于子图启动事件（node == ""，ns = "parent:uuid|"）。
        此时 ns 最后一节是父节点名，子 Workflow ID 需要从后续事件推断。
        这里返回父节点名作为临时标识。

        Args:
            event: LangGraph 事件字典

        Returns:
            父节点名（如 "stage_1"），作为临时子 Workflow ID
        """
        metadata = event.get("metadata", {})
        ns = metadata.get("langgraph_checkpoint_ns", "")

        if ns and ns.endswith("|"):
            # ns 格式："stage_1:uuid|"，取倒数第二节（去掉尾部 | 后的最后一节）
            ns_without_tail = ns[:-1]
            parent_segment = ns_without_tail.split("|")[-1]
            return parent_segment.split(":")[0] if ":" in parent_segment else parent_segment

        return None


__all__ = [
    "DepthResolver",
]
