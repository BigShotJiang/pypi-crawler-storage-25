"""
types.py — Workflow 事件适配器类型定义

职责：
    - 定义 WorkflowEvent 数据类
    - 定义 WorkflowEventType 枚举
    - 定义 WorkflowAdapterState 状态类

链路位置：
    - Layer 3: Workflow 事件适配器
    - 位于 WorkflowEventAdapter 和 Handler 之间

当前裁剪范围：
    - 不包含 OrchestratorWorkflow 事件类型（Phase 2+）
    - 不包含 Agent 层事件类型（由 LangchainAgentEvent 处理）
"""

from dataclasses import dataclass, field
from enum import Enum
from time import time
from typing import Any, Dict
from uuid import uuid4


class WorkflowEventType(Enum):
    """Workflow 事件类型枚举

    设计原则（v2.5）：
        - 与设计文档 workflow-event-adapter-design.md §2.2 保持一致
        - 事件类型分为 5 大类：生命周期、通用节点、Chaining、Parallelization、Routing
    """

    # Workflow 生命周期
    WORKFLOW_START = "workflow-start"
    WORKFLOW_END = "workflow-end"
    WORKFLOW_ERROR = "workflow-error"
    SUBWORKFLOW_START = "subworkflow-start"
    SUBWORKFLOW_END = "subworkflow-end"

    # 通用节点
    NODE_START = "node-start"
    NODE_END = "node-end"

    # ChainingWorkflow
    STAGE_START = "stage-start"
    STAGE_DONE = "stage-done"
    STAGE_FAILED = "stage-failed"

    # ParallelizationWorkflow
    PARALLEL_ITEM_START = "parallel-item-start"
    PARALLEL_ITEM_DONE = "parallel-item-done"
    PARALLEL_ITEM_FAILED = "parallel-item-failed"
    PARALLEL_AGGREGATE_START = "parallel-aggregate-start"
    PARALLEL_AGGREGATE_DONE = "parallel-aggregate-done"

    # RoutingWorkflow
    ROUTE_BRANCH_START = "route-branch-start"
    ROUTE_BRANCH_DONE = "route-branch-done"

    # OrchestratorWorkflow（Phase 2+）
    # ORCHESTRATOR_CYCLE_START = "orchestrator-cycle-start"
    # ORCHESTRATOR_CYCLE_END = "orchestrator-cycle-end"


@dataclass
class WorkflowEvent:
    """Workflow 层结构化事件

    设计原则（v2.5）：
        - 与 LangchainAgentEvent 保持一致的字段结构
        - 增加 workflow_path 和 depth 支持嵌套
        - event_id 用于关联 start/end 对
        - session_id 支持多会话并发

    Attributes:
        event_type: 事件类型（WorkflowEventType 枚举）
        data: 事件数据（字典，包含事件特定字段）
        workflow_id: 当前 Workflow ID
        workflow_path: 层级路径，如 "wiki-build>stage_1>parallel_0"
        workflow_depth: 嵌套深度，根为 0
        session_id: 会话 ID（多会话并发时使用）
        parent_workflow_id: 父 Workflow ID（嵌套时使用）
        parent_event_id: 关联父事件的 event_id
        sequence_no: 序列号（用于乱序/重发场景）
        timestamp: 时间戳
        event_id: 追踪 ID（用于关联 start/end 对）
    """

    event_type: WorkflowEventType
    data: Dict[str, Any]

    # 上下文信息
    workflow_id: str
    workflow_path: str
    workflow_depth: int
    session_id: str | None = None

    # 父子关系（嵌套时使用）
    parent_workflow_id: str | None = None
    parent_event_id: str | None = None

    # 序列号（用于乱序/重发场景）
    sequence_no: int = 0

    # 时间戳
    timestamp: float = field(default_factory=time)

    # 追踪 ID（用于关联 start/end 对）
    event_id: str = field(default_factory=lambda: uuid4().hex)


@dataclass
class WorkflowAdapterState:
    """Workflow 适配器状态

    设计原则（v2.5）：
        - 与 EventAdapterState 保持一致的职责划分
        - 维护状态机相关的字段
        - 嵌套栈状态（depth / current_workflow_id / path / pattern）完全委托给 WorkflowStack

    修复（v2.5）：
        - 移除 current_workflow_id（使用 WorkflowStack.current_workflow_id）
        - 移除 workflow_stack（使用 WorkflowStack 内部栈）
        - 移除 current_depth（使用 WorkflowStack.current_depth）
        - 移除 current_pattern（使用 WorkflowStack.current_pattern，修复嵌套覆盖问题）
    """

    # === 会话级别 ===
    session_id: str | None = None
    root_workflow_id: str = ""
    sequence_no: int = 0

    # === 分支追踪（Routing） ===
    active_branch: str | None = None
    branch_history: list[str] = field(default_factory=list)

    # === Stage 追踪（Chaining） ===
    current_stage: int = -1
    total_stages: int = 0

    # === 事件配对追踪 ===
    pending_starts: Dict[str, bool] = field(default_factory=dict)  # 修复（v2.5）：value 类型为 bool

    # === 辅助判断 ===
    last_seen_node: str = ""


__all__ = [
    "WorkflowEventType",
    "WorkflowEvent",
    "WorkflowAdapterState",
]
