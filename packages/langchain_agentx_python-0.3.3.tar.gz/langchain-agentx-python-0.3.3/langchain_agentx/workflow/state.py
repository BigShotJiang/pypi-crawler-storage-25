"""
state.py — Workflow 状态定义

职责：
    - 定义 WorkflowState 基类（TypedDict + Annotated reducer）
    - 规范 Workflow 状态字段命名与 reducer 使用
    - 提供文档模式定义，不强制继承

链路位置：
    - 被 BaseWorkflow 和所有特殊 Workflow 使用
    - 被业务 Workflow 继承扩展

当前裁剪范围：
    - 仅包含基础字段（messages, item_results, workflow_id 等）
    - 业务特定字段由具体 Workflow 自行扩展

设计说明（问题 10）：
    - WorkflowState 使用 TypedDict，这是 LangGraph 的最佳实践
    - TypedDict + Annotated reducer 是 LangGraph 官方推荐的状态定义方式
    - 不要使用普通 dict（没有类型检查和 reducer 支持）
    - 不要使用 dataclass（LangGraph StateGraph 不直接支持）
"""

from __future__ import annotations

from typing import Annotated, TypedDict
from operator import add

from langgraph.graph.message import add_messages
from langchain_core.messages import AnyMessage


class WorkflowState(TypedDict, total=False):
    """Workflow 状态 schema，支持并发写入。

    字段说明：
    - messages: 消息列表（所有节点都会追加消息，使用 reducer）
    - item_results: 并行任务结果列表（聚合所有 item 的输出，使用 reducer）
    - workflow_id: 当前 Workflow ID（单写，由 BaseWorkflow 设置）
    - task_key: 当前任务标识符（单写，Phase 2+）
    - current_step: 当前步骤（单写，用于顺序 Workflow）
    - error: 错误信息（单写，用于错误处理）

    使用方式：
    - 基础类型：WorkflowState（本定义）
    - 扩展类型：class MyState(WorkflowState, total=False) 添加业务字段
    """

    # === 并发聚合字段（使用 reducer）===
    messages: Annotated[list[AnyMessage], add_messages]
    item_results: Annotated[list[dict], add]

    # === 单写字段（无需 reducer）===
    workflow_id: str
    task_key: str | None
    current_step: str | None
    error: str | None


__all__ = ["WorkflowState"]
