"""
chaining.py — ChainingWorkflow 顺序编排模式

职责：
    - 实现顺序执行多个阶段的拓扑结构
    - 支持 gate 检查（程序化检查）
    - 支持 AgentNode 和 BaseWorkflow 作为 stage

链路位置：
    - Layer 3: SDK Workflow 编排模式
    - 基于 Anthropic: Prompt Chaining 模式

当前裁剪范围：
    - 不支持条件分支（使用 RoutingWorkflow）
    - 不支持并行执行（使用 ParallelizationWorkflow）
"""

from __future__ import annotations

from typing import Any, Callable, List

from langgraph.graph import StateGraph, START, END

from ..base import BaseWorkflow
from ..state import WorkflowState
from ...loop.hook.registry import HookRegistry


class ChainingWorkflow(BaseWorkflow):
    """Anthropic: Prompt Chaining 模式

    特征：
    - 顺序执行多个阶段
    - 每个阶段的输出作为下一个阶段的输入
    - 可以在中间插入 gate 检查（程序化检查）
    """

    def __init__(
        self,
        workflow_id: str,
        stages: List,
        hook_registry: HookRegistry,
        gates: List[Callable[[dict], bool]] | None = None,
        *,
        capabilities: Any = None,
        workspace_root: Any = None,
        agent_home: str | None = None,
    ):
        """初始化 ChainingWorkflow。

        Args:
            workflow_id: Workflow 标识符
            stages: 阶段列表（AgentNode 或其他 Workflow）
            hook_registry: Hook 注册表
            gates: 可选的检查函数，返回 False 时停止执行
            capabilities: 可选 RuntimeCapabilities；未提供时需显式传入 workspace_root + agent_home
            workspace_root: primary workspace 根路径
            agent_home: primary agent_home 子目录名
        """
        super().__init__(
            workflow_id,
            hook_registry,
            capabilities=capabilities,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        self._stages = stages
        self._gates = gates or [lambda _: True] * len(stages)

    def build_graph(self) -> StateGraph:
        """实现 BaseWorkflow 定义的契约。

        构建顺序执行的拓扑结构：
        - 添加所有 stage 作为节点
        - 用顺序边连接它们
        - 中间插入 gate 检查
        """
        graph = StateGraph(WorkflowState)

        # 为每个 stage 创建节点
        for idx, stage in enumerate(self._stages):
            node_fn = self._build_stage_node(stage)
            graph.add_node(f"stage_{idx}", node_fn)

        # 用条件边连接，实现顺序 + gate 检查
        for idx in range(len(self._stages) - 1):
            graph.add_conditional_edges(
                f"stage_{idx}",
                self._check_gate(idx),
                {
                    "continue": f"stage_{idx+1}",
                    "stop": END,
                }
            )

        graph.add_edge(START, "stage_0")
        graph.add_edge(f"stage_{len(self._stages)-1}", END)

        return graph

    def _build_stage_node(self, stage: Any) -> Callable:
        """构建异步节点函数：支持 AgentNode 和 BaseWorkflow。

        Returns:
            async 节点函数（LangGraph 的 add_node 原生支持 coroutine）

        这是组合的核心：Workflow 可以作为节点！

        注意：
            - AgentNode: 返回完整 state（包含 messages）
            - BaseWorkflow: 使用 as_node() 返回完整 state，传递 parent_workflow 构建层级关系（问题 20）
        """
        if hasattr(stage, "build") and not hasattr(stage, "compile"):
            # AgentNode: 有 build() 但没有 compile()
            return stage.build()
        elif hasattr(stage, "as_node"):
            # BaseWorkflow: 使用 as_node()
            return stage.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return stage

    def _check_gate(self, idx: int) -> Callable:
        """Gate 检查函数。"""
        def gate_fn(state: dict) -> str:
            if self._gates[idx](state):
                return "continue"
            else:
                return "stop"
        return gate_fn


__all__ = ["ChainingWorkflow"]
