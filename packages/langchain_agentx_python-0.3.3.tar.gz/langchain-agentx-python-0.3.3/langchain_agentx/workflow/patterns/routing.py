"""
routing.py — RoutingWorkflow 路由编排模式

职责：
    - 实现分类输入导向专门处理的拓扑结构
    - 支持 LLM 或传统分类器路由
    - 支持 AgentNode 和 BaseWorkflow 作为 route

链路位置：
    - Layer 3: SDK Workflow 编排模式
    - 基于 Anthropic: Routing 模式

当前裁剪范围：
    - 不支持动态路由表（routes 在 __init__ 时固定）
"""

from __future__ import annotations

from typing import Any, Callable, Dict

from langgraph.graph import StateGraph, START, END

from ..base import BaseWorkflow
from ..state import WorkflowState
from ...loop.hook.registry import HookRegistry


class RoutingWorkflow(BaseWorkflow):
    """Anthropic: Routing 模式

    特征：
    - 根据输入分类导向不同的处理路径
    - 每个路径可以是 AgentNode 或其他 Workflow
    - 支持 default_route 处理未匹配的情况
    """

    def __init__(
        self,
        workflow_id: str,
        router: Callable[[dict], str],
        routes: Dict[str, Any],
        hook_registry: HookRegistry,
        default_route: str | None = None,
        *,
        capabilities: Any = None,
        workspace_root: Any = None,
        agent_home: str | None = None,
    ):
        """初始化 RoutingWorkflow。

        Args:
            workflow_id: Workflow 标识符
            router: 路由决策函数，输入 state，返回路由 key
            routes: 路由字典 {key: AgentNode|BaseWorkflow|callable}
            hook_registry: Hook 注册表
            default_route: 默认路由 key（当 router 返回未知 key 时使用）
            capabilities / workspace_root / agent_home: 详见 BaseWorkflow
        """
        super().__init__(
            workflow_id,
            hook_registry,
            capabilities=capabilities,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        self._router = router
        self._routes = routes
        self._default_route = default_route

    def build_graph(self) -> StateGraph:
        """实现 BaseWorkflow 定义的契约。

        构建路由拓扑结构：
        - 添加所有 route 作为节点
        - 使用条件边实现路由决策
        - 所有 route 最终汇聚到 END
        """
        graph = StateGraph(WorkflowState)

        # 为每个 route 创建节点
        for key, route in self._routes.items():
            node_fn = self._build_route_node(route)
            graph.add_node(f"route_{key}", node_fn)

        # 添加默认路由（如果指定）
        if self._default_route is not None:
            # 默认路由已存在于 routes 中，不需要额外处理
            pass

        # 添加条件边：START -> 根据路由决策 -> 对应 route
        route_keys = list(self._routes.keys())
        graph.add_conditional_edges(
            START,
            self._route_decision,
            {key: f"route_{key}" for key in route_keys}
        )

        # 所有 route 汇聚到 END
        for key in route_keys:
            graph.add_edge(f"route_{key}", END)

        return graph

    def _route_decision(self, state: dict) -> str:
        """路由决策函数。

        Args:
            state: 当前状态

        Returns:
            路由 key
        """
        decision = self._router(state)

        # 如果返回的 key 不在 routes 中，使用默认路由
        if decision not in self._routes and self._default_route is not None:
            return self._default_route

        return decision

    def _build_route_node(self, route: Any) -> Callable:
        """构建路由节点函数：支持 AgentNode 和 BaseWorkflow。

        Returns:
            async 节点函数（LangGraph 的 add_node 原生支持 coroutine）
        """
        if hasattr(route, "build") and not hasattr(route, "compile"):
            # AgentNode: 有 build() 但没有 compile()
            return route.build()
        elif hasattr(route, "as_node"):
            # BaseWorkflow: 使用 as_node()
            return route.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return route


__all__ = ["RoutingWorkflow"]
