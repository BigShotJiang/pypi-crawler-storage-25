"""
evaluator_optimizer.py — EvaluatorOptimizerWorkflow 评估器-优化器模式

职责：
    - 实现生成 + 评估 + 循环迭代的拓扑结构
    - 支持一个 LLM 生成响应，另一个提供评估和反馈
    - 支持循环迭代直到满足条件

链路位置：
    - Layer 3: SDK Workflow 编排模式
    - 基于 Anthropic: Evaluator-Optimizer 模式

当前裁剪范围：
    - 不支持多个优化器并行（单优化器）
"""

from __future__ import annotations

from typing import Any, Callable

from langgraph.graph import StateGraph, START, END

from ..base import BaseWorkflow
from ..state import WorkflowState
from ...loop.hook.registry import HookRegistry


class EvaluatorOptimizerWorkflow(BaseWorkflow):
    """Anthropic: Evaluator-Optimizer 模式

    特征：
    - 优化器生成响应
    - 评估器评估响应并提供反馈
    - 循环迭代直到满足条件或达到最大迭代次数
    """

    def __init__(
        self,
        workflow_id: str,
        optimizer: Any,
        evaluator: Any,
        hook_registry: HookRegistry,
        max_iterations: int = 5,
        success_criteria: Callable[[dict], bool] | None = None,
        *,
        capabilities: Any = None,
        workspace_root: Any = None,
        agent_home: str | None = None,
    ):
        """初始化 EvaluatorOptimizerWorkflow。

        Args:
            workflow_id: Workflow 标识符
            optimizer: 优化器（AgentNode 或 BaseWorkflow）
            evaluator: 评估器（AgentNode 或 BaseWorkflow）
            hook_registry: Hook 注册表
            max_iterations: 最大迭代次数
            success_criteria: 成功条件函数，返回 True 时停止迭代
            capabilities / workspace_root / agent_home: 详见 BaseWorkflow
        """
        super().__init__(
            workflow_id,
            hook_registry,
            capabilities=capabilities,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        self._optimizer = optimizer
        self._evaluator = evaluator
        self._max_iterations = max_iterations
        self._success_criteria = success_criteria or (lambda s: False)

    def build_graph(self) -> StateGraph:
        """实现 BaseWorkflow 定义的契约。

        构建循环拓扑结构：
        - START -> optimizer -> evaluator
        - evaluator -> 条件边 -> (optimizer | END)
        """
        graph = StateGraph(WorkflowState)

        # 添加 optimizer 和 evaluator 节点
        optimizer_node = self._build_optimizer_node()
        evaluator_node = self._build_evaluator_node()

        graph.add_node("optimizer", optimizer_node)
        graph.add_node("evaluator", evaluator_node)

        # START -> optimizer
        graph.add_edge(START, "optimizer")

        # optimizer -> evaluator
        graph.add_edge("optimizer", "evaluator")

        # evaluator -> 条件边 -> (继续优化 | 结束)
        graph.add_conditional_edges(
            "evaluator",
            self._should_continue_optimization,
            {
                "continue": "optimizer",
                "end": END,
            }
        )

        return graph

    def _build_optimizer_node(self) -> Callable:
        """构建优化器节点函数。

        Returns:
            async 节点函数
        """
        optimizer = self._optimizer
        if hasattr(optimizer, "build") and not hasattr(optimizer, "compile"):
            # AgentNode
            return optimizer.build()
        elif hasattr(optimizer, "as_node"):
            # BaseWorkflow
            return optimizer.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return optimizer

    def _build_evaluator_node(self) -> Callable:
        """构建评估器节点函数。

        Returns:
            async 节点函数
        """
        evaluator = self._evaluator
        if hasattr(evaluator, "build") and not hasattr(evaluator, "compile"):
            # AgentNode
            return evaluator.build()
        elif hasattr(evaluator, "as_node"):
            # BaseWorkflow
            return evaluator.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return evaluator

    def _should_continue_optimization(self, state: dict) -> str:
        """决策是否继续优化。

        Args:
            state: 当前状态

        Returns:
            "continue" 或 "end"

        注意：
            - 使用消息数量估算迭代次数（每轮 optimizer+evaluator 各产生一条消息）
            - 如果 evaluation_passed 为 True 则停止
        """
        # 检查是否满足成功条件
        if self._success_criteria(state):
            return "end"

        # 检查是否达到最大迭代次数
        # 使用 optimizer 消息数量估算迭代次数
        messages = state.get("messages", [])
        optimizer_count = sum(
            1 for m in messages
            if hasattr(m, "content") and "optimization_v" in m.content
        )
        if optimizer_count >= self._max_iterations:
            return "end"

        return "continue"


__all__ = ["EvaluatorOptimizerWorkflow"]
