"""
orchestrator.py — OrchestratorWorkflow 编排器-工作者模式

职责：
    - 实现中央 LLM 动态分解任务的拓扑结构
    - 支持委托给 worker LLMs
    - 支持合成 worker 的结果
    - 支持子任务数量和内容无法预先确定的场景

链路位置：
    - Layer 3: SDK Workflow 编排模式
    - 基于 Anthropic: Orchestrator-Workers 模式

当前裁剪范围：
    - 不支持分布式执行（单机多进程）
"""

from __future__ import annotations

from typing import Any, Callable

from langgraph.graph import StateGraph, START, END

from ..base import BaseWorkflow
from ..state import WorkflowState
from ...loop.hook.registry import HookRegistry


class OrchestratorWorkflow(BaseWorkflow):
    """Anthropic: Orchestrator-Workers 模式

    特征：
    - Orchestrator 分解任务并创建子任务
    - Workers 并行执行子任务
    - Orchestrator 合成结果
    - 循环直到所有任务完成或达到最大迭代次数
    """

    def __init__(
        self,
        workflow_id: str,
        orchestrator: Any,
        worker_template: Any,
        hook_registry: HookRegistry,
        max_workers: int = 4,
        max_iterations: int = 10,
        *,
        capabilities: Any = None,
        workspace_root: Any = None,
        agent_home: str | None = None,
    ):
        """初始化 OrchestratorWorkflow。

        Args:
            workflow_id: Workflow 标识符
            orchestrator: 编排器（AgentNode 或 BaseWorkflow）
            worker_template: 工作者模板（AgentNode 或 BaseWorkflow）
            hook_registry: Hook 注册表
            max_workers: 最大并发 worker 数量
            max_iterations: 最大迭代次数
            capabilities / workspace_root / agent_home: 详见 BaseWorkflow
        """
        super().__init__(
            workflow_id,
            hook_registry,
            max_concurrency=max_workers,
            capabilities=capabilities,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )
        self._orchestrator = orchestrator
        self._worker_template = worker_template
        self._max_iterations = max_iterations

    def build_graph(self) -> StateGraph:
        """实现 BaseWorkflow 定义的契约。

        构建循环拓扑结构：
        - START -> orchestrator
        - orchestrator -> 条件边 -> (workers | END)
        - workers -> orchestrator（循环）
        """
        graph = StateGraph(WorkflowState)

        # 添加 orchestrator 节点
        orchestrator_node = self._build_orchestrator_node()
        graph.add_node("orchestrator", orchestrator_node)

        # 添加 worker 节点
        worker_node = self._build_worker_node()
        graph.add_node("worker", worker_node)

        # START -> orchestrator
        graph.add_edge(START, "orchestrator")

        # orchestrator -> 条件边 -> (worker | END)
        graph.add_conditional_edges(
            "orchestrator",
            self._should_continue_orchestration,
            {
                "continue": "worker",
                "end": END,
            }
        )

        # worker -> orchestrator（循环）
        graph.add_edge("worker", "orchestrator")

        return graph

    def _build_orchestrator_node(self) -> Callable:
        """构建编排器节点函数。

        Returns:
            async 节点函数
        """
        orchestrator = self._orchestrator
        if hasattr(orchestrator, "build") and not hasattr(orchestrator, "compile"):
            # AgentNode
            return orchestrator.build()
        elif hasattr(orchestrator, "as_node"):
            # BaseWorkflow
            return orchestrator.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return orchestrator

    def _build_worker_node(self) -> Callable:
        """构建工作者节点函数。

        Returns:
            async 节点函数
        """
        worker = self._worker_template
        if hasattr(worker, "build") and not hasattr(worker, "compile"):
            # AgentNode
            return worker.build()
        elif hasattr(worker, "as_node"):
            # BaseWorkflow
            return worker.as_node(parent_workflow=self)
        else:
            # 直接是节点函数
            return worker

    def _should_continue_orchestration(self, state: dict) -> str:
        """决策是否继续编排。

        Args:
            state: 当前状态

        Returns:
            "continue" 或 "end"

        注意：
            - 使用 item_results 检查是否有待处理的任务
            - 检查是否有进展（worker 完成了任务）
            - 达到 max_iterations 时停止
        """
        item_results = state.get("item_results", [])
        messages = state.get("messages", [])

        # 统计 pending 和 completed 任务
        pending_tasks = [r for r in item_results if r.get("status") == "pending"]
        completed_tasks = [r for r in item_results if r.get("status") == "completed"]

        # 如果没有 pending 任务，结束
        if not pending_tasks:
            return "end"

        # 检查是否有进展：如果有 pending 但没有 completed，说明 worker 可能还没执行
        # 给一次机会，但如果已经有 orchestrator 消息但没有 completed，可能有问题
        orchestrator_msg_count = sum(
            1 for m in messages
            if hasattr(m, "content") and "orchestrator" in m.content.lower()
        )

        # 如果 orchestrator 被调用多次但没有任何 completed，强制结束
        if orchestrator_msg_count > 2 and not completed_tasks:
            return "end"

        # 检查是否达到最大迭代次数
        if orchestrator_msg_count >= self._max_iterations:
            return "end"

        return "continue"


__all__ = ["OrchestratorWorkflow"]
