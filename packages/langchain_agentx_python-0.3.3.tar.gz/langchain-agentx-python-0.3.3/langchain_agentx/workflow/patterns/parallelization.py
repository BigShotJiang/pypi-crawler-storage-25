"""
parallelization.py — ParallelizationWorkflow 并行编排模式

职责：
    - 实现并行执行独立子任务的拓扑结构
    - 支持 Sectioning（分段）和 Voting（投票）两种模式
    - 支持 max_concurrency 并发控制
    - 支持 AgentNode 和 BaseWorkflow 作为 node

链路位置：
    - Layer 3: SDK Workflow 编排模式
    - 基于 Anthropic: Parallelization 模式

当前裁剪范围：
    - 不支持动态 fan-out（nodes 在 __init__ 时固定）
    - 使用 OrchestratorWorkflow 实现动态 fan-out
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, List

from langgraph.graph import StateGraph, START, END

from ..base import BaseWorkflow
from ..state import WorkflowState
from ...loop.hook.registry import HookRegistry


class ParallelizationWorkflow(BaseWorkflow):
    """Anthropic: Parallelization 模式

    特征：
    - 并行执行独立的子任务
    - 包括 Sectioning（分段）和 Voting（投票）
    - 程序化聚合结果
    """

    def __init__(
        self,
        workflow_id: str,
        mode: str,
        nodes: List | Any,
        aggregator: Callable[[List], dict],
        hook_registry: HookRegistry,
        max_concurrency: int = 4,
        *,
        capabilities: Any = None,
        workspace_root: Any = None,
        agent_home: str | None = None,
        **kwargs
    ):
        """初始化 ParallelizationWorkflow。

        Args:
            workflow_id: Workflow 标识符
            mode: "sectioning"（多个不同节点）或 "voting"（同一节点多次）
            nodes: sectioning 时为多个不同节点，voting 时为单个节点
            aggregator: 聚合函数，将所有并行节点的结果合并
            hook_registry: Hook 注册表
            max_concurrency: 并发控制限制（仅 ParallelizationWorkflow 需要）
            capabilities / workspace_root / agent_home: 详见 BaseWorkflow
        """
        super().__init__(
            workflow_id,
            hook_registry,
            max_concurrency=max_concurrency,
            capabilities=capabilities,
            workspace_root=workspace_root,
            agent_home=agent_home,
        )

        self._mode = mode
        if mode == "sectioning":
            self._nodes = nodes if isinstance(nodes, list) else [nodes]
        elif mode == "voting":
            # voting 模式：单个节点多次执行
            voting_rounds = kwargs.get("voting_rounds", 3)
            self._nodes = [nodes] * voting_rounds
        else:
            raise ValueError(f"Unknown mode: {mode}")

        self._aggregator = aggregator

        # ParallelizationWorkflow 按需实例化 Semaphore（问题 9）
        # 只有需要并发控制的模式才创建 Semaphore，避免其他模式占用资源
        if max_concurrency is not None:
            self._semaphore = asyncio.Semaphore(max_concurrency)
        else:
            self._semaphore = None

    def build_graph(self) -> StateGraph:
        """构建并行拓扑。"""
        graph = StateGraph(WorkflowState)

        # 添加所有并行节点
        for idx, node in enumerate(self._nodes):
            node_fn = self._build_parallel_node(node)
            graph.add_node(f"parallel_{idx}", node_fn)
            graph.add_edge(START, f"parallel_{idx}")

        # 添加聚合节点
        graph.add_node("aggregate", self._aggregate_node)
        for idx in range(len(self._nodes)):
            graph.add_edge(f"parallel_{idx}", "aggregate")

        graph.add_edge("aggregate", END)

        return graph

    def _build_parallel_node(self, node: Any) -> Callable:
        """构建并行节点函数：支持 AgentNode 和 BaseWorkflow。

        Returns:
            async 节点函数（LangGraph 的 add_node 原生支持 coroutine）
        """
        if hasattr(node, "build") and not hasattr(node, "compile"):
            # AgentNode: 传入 semaphore 实现并发控制（如果配置了）
            return node.build(semaphore=self._semaphore)
        elif hasattr(node, "as_node"):
            # BaseWorkflow: 使用 as_node()，传递 outer_semaphore 实现并发控制（问题 19）
            # 同时传递 parent_workflow 构建层级关系（问题 20）
            return node.as_node(
                parent_workflow=self,
                outer_semaphore=self._semaphore,
            )
        else:
            # 直接是节点函数
            return node

    def _aggregate_node(self, state: dict) -> dict:
        """聚合节点函数。

        注意：所有 item_results 已经通过 LangGraph reducer 自动合并了
        这里只需要做最终的汇总
        """
        # 获取所有 item_results（已通过 reducer 合并）
        item_results = state.get("item_results", [])
        return self._aggregator(item_results)


__all__ = ["ParallelizationWorkflow"]
