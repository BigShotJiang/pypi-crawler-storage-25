"""
node.py — AgentNode 基本组合节点

职责：
    - 持有构建 Agent 所需的所有参数（model, tools, workspace, loader...）
    - 提供 build() 接口，返回可执行的 LangGraph 节点函数
    - 每次调用可以传入不同的运行时参数（如 item-specific 的 workspace_root）
    - 支持 workspace_config 拆包（遵循 CLAUDE.md 路径约束）
    - 支持 semaphore 并发控制（用于 LangGraph 并发场景）
    - 支持 RuntimeCapabilities 显式注入（避免节点内 resolve_agent_workspace_config）

链路位置：
    - Layer 1: 基本组合节点
    - 被 Layer 2 (BaseWorkflow) 和 Layer 3 (特殊 Workflow) 组合使用

当前裁剪范围：
    - 不包含 Agent 执行逻辑（由 create_loop_agent 提供）
    - 不包含 per-item Hook 事件（Phase 2+）
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from ..workspace import AgentWorkspaceConfig, RuntimeCapabilities

from ..workspace import assert_agent_home_matches_capabilities


class AgentNode:
    """基本组合节点：封装 create_loop_agent 的参数化配置。

    设计原则：
    - 持有固定配置（model, system_prompt, tools 等）
    - build() 接受运行时参数，返回 async 节点函数
    - 支持 workspace_config 拆包（不侵入 Loop 层）
    - 支持 semaphore 并发控制
    - 支持 capabilities 显式注入（见 Workspace/Capabilities 分档设计）
    """

    def __init__(
        self,
        name: str,
        session_id: str | None = None,
        model: Any = None,
        system_prompt: str = "",
        tools: list = None,
    ):
        self.name = name
        self._base_session_id = session_id or name
        self._config = {
            "model": model,
            "system_prompt": system_prompt,
            "tools": tools or [],
        }

    def build(
        self,
        hook_registry: Any = None,
        semaphore: Any = None,
        workspace_config: "AgentWorkspaceConfig | None" = None,
        *,
        capabilities: "RuntimeCapabilities | None" = None,
        **runtime_kwargs,
    ) -> Callable:
        """构建可执行的 LangGraph 节点函数。

        Args:
            hook_registry: Agent 层的 HookRegistry（与 Workflow 层隔离）
            semaphore: 并发控制信号量（用于 Workflow 层的限流）
            workspace_config: 工作空间配置对象（B/C 档；遵循 CLAUDE.md 路径约束）
            capabilities: RuntimeCapabilities 单例（A 档资源 + B 档默认值）；
                由 Workflow 构造期装配并显式透传，节点内禁止再调用
                resolve_agent_workspace_config()。
            **runtime_kwargs: 可以覆盖固定配置（如 session_id）
        """
        if capabilities is not None and workspace_config is not None:
            assert_agent_home_matches_capabilities(
                capabilities, workspace_config.agent_home
            )
        session_id = runtime_kwargs.get("session_id", self._base_session_id)
        bound_capabilities = capabilities
        bound_workspace_config = workspace_config

        async def node_fn(state: dict) -> dict:
            if semaphore is not None:
                async with semaphore:
                    return await self._execute_mock(
                        state, session_id, bound_workspace_config, bound_capabilities
                    )
            return await self._execute_mock(
                state, session_id, bound_workspace_config, bound_capabilities
            )

        return node_fn

    async def _execute_mock(
        self,
        state: dict,
        session_id: str,
        workspace_config: "AgentWorkspaceConfig | None",
        capabilities: "RuntimeCapabilities | None" = None,
    ) -> dict:
        """Mock 执行（Phase 1 基线）。真实实现里会调用 create_loop_agent 并透传 capabilities。"""
        workspace_info: dict[str, Any] = {}
        if workspace_config is not None:
            workspace_info = {
                "workspace_root": str(workspace_config.workspace_root),
                "agent_home": workspace_config.agent_home,
            }
        if capabilities is not None:
            workspace_info["has_capabilities"] = True

        return {
            "messages": state.get("messages", []) + [
                {
                    "role": "assistant",
                    "content": f"[{self.name}] response from {session_id}",
                    "workspace": workspace_info,
                }
            ],
            "item_results": state.get("item_results", []) + [
                {
                    "node": self.name,
                    "session_id": session_id,
                    "workspace": workspace_info,
                }
            ]
        }


__all__ = ["AgentNode"]
