"""Workflow 容器导出。"""

from .base import BaseWorkflow
from .batch import BatchWorkflow
from .dag import DagWorkflow

# Workflow 事件适配器导出（Phase 4）
from .event_adapter import (
    WorkflowEventAdapter,
    WorkflowEvent,
    WorkflowEventType,
    WorkflowAdapterState,
)

__all__ = [
    "BaseWorkflow",
    "DagWorkflow",
    "BatchWorkflow",
    # 事件适配器
    "WorkflowEventAdapter",
    "WorkflowEvent",
    "WorkflowEventType",
    "WorkflowAdapterState",
]
