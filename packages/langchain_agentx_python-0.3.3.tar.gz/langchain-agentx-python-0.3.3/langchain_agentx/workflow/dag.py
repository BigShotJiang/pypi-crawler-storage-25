"""
workflow/dag.py — DAG 编排骨架。

职责：
    为有向无环图编排场景提供步骤辅助入口（_run_step），
    子类通过普通 Python 代码声明步骤依赖与并发关系。

链路位置：
    继承 BaseWorkflow，为具体业务 Workflow（如 WikiWorkflow）提供结构化骨架。

当前裁剪范围：
    不做自动 DAG 拓扑调度，步骤顺序与并发由子类 _execute() 控制。
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from .base import BaseWorkflow
from ..loop.hook.registry import HookRegistry
from ..loop.hook.engine import HookEngine
from ..loop.hook.types import HookEvent
from langgraph.graph import StateGraph, END
from uuid import uuid4


class DagWorkflow(BaseWorkflow):
    """
    DAG 编排骨架。

    子类通过 _run_step() 与 Python 控制流表达依赖与并发。
    """

    def __init__(
        self,
        graph_factory: Any,
        hook_engine: Any = None,
        hook_registry: Any = None,
        max_concurrency: int = 4,
    ):
        """初始化 DagWorkflow。

        Args:
            graph_factory: Agent 图工厂函数
            hook_engine: Hook 引擎（向后兼容，可选）
            hook_registry: Hook 注册表（新 API，可选）
            max_concurrency: 最大并发数
        """
        # 兼容层：优先使用 hook_registry，否则从 hook_engine 提取或创建
        if hook_registry is not None:
            # 新 API：直接使用提供的 hook_registry
            final_hook_registry = hook_registry
        elif isinstance(hook_engine, HookEngine):
            # 旧 API：从 HookEngine 创建新的 HookRegistry
            final_hook_registry = HookRegistry()
        elif isinstance(hook_engine, HookRegistry):
            # 旧 API：直接使用 HookRegistry
            final_hook_registry = hook_engine
        else:
            # 默认：创建新的 HookRegistry
            final_hook_registry = HookRegistry()

        # 适配 base 的新签名
        super().__init__(
            workflow_id=f"dag-{uuid4().hex[:8]}",
            hook_registry=final_hook_registry,
            max_concurrency=max_concurrency,
            graph_factory=graph_factory,
        )
        # 保留原始 hook_engine 引用（用于向后兼容）
        self._legacy_hook_engine = hook_engine

    def build_graph(self) -> StateGraph:
        """构建 LangGraph 图（DAG 最小实现）。

        DagWorkflow 不使用 build_graph() 模式，这是为了兼容 base 而提供的最小实现。
        实际执行通过 run() -> _execute() 完成。
        """
        graph = StateGraph(dict)
        graph.add_edge("__start__", "__end__")
        return graph

    async def _run_step(
        self,
        step_name: str,
        messages: list[Any],
        *,
        parent_session_id: str | None = None,
    ) -> dict[str, Any]:
        """
        执行单个 DAG 步骤。

        step_name 作为 task_key，最终生成 session_id = f"{workflow_id}-{step_name}"，
        trace 可按步骤名检索执行链路。
        """
        return await self._invoke_agent(
            messages=messages,
            task_key=step_name,
            parent_session_id=parent_session_id,
        )

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现具体步骤编排逻辑。"""


    async def run(self, **kwargs: Any) -> Any:
        """向后兼容的 run() 方法。

        保持旧 API 签名 run(**kwargs)，内部调用子类的 _execute()。
        """
        # 发射 Hook（保持与旧 base.py 一致的行为）
        try:
            await self._emit_hook(HookEvent.WORKFLOW_START, {
                "workflow_id": self._workflow_id,
                "workflow_session_id": f"workflow-{self._workflow_id}",
                "workflow_path": self._workflow_path,
            })
            result = await self._execute(**kwargs)
            return result
        finally:
            await self._emit_hook(HookEvent.WORKFLOW_END, {
                "workflow_id": self._workflow_id,
                "workflow_session_id": f"workflow-{self._workflow_id}",
                "workflow_path": self._workflow_path,
            })


__all__ = ["DagWorkflow"]
