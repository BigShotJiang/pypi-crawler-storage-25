"""
workflow/batch.py — Batch 编排骨架。

职责：
    为同构批处理任务提供标准执行模板（items -> process x N -> merge），
    子类实现 _process_item() 和 merge_results() 即可。

链路位置：
    继承 BaseWorkflow，为批处理型业务 Workflow 提供标准入口。

当前裁剪范围：
    并发由 BaseWorkflow._semaphore 控制；错误策略由 error_policy 决定。
"""

from __future__ import annotations

import asyncio
from abc import abstractmethod
from typing import Any, Literal

from .base import BaseWorkflow
from ..loop.hook.registry import HookRegistry
from ..loop.hook.engine import HookEngine
from ..loop.hook.types import HookEvent
from langgraph.graph import StateGraph, END
from uuid import uuid4


class BatchWorkflow(BaseWorkflow):
    """批处理编排骨架。"""

    def __init__(
        self,
        graph_factory: Any,
        hook_engine: Any = None,
        hook_registry: Any = None,
        max_concurrency: int = 4,
        error_policy: Literal["fail_fast", "best_effort"] = "best_effort",
    ):
        """初始化 BatchWorkflow。

        Args:
            graph_factory: Agent 图工厂函数
            hook_engine: Hook 引擎（向后兼容，可选）
            hook_registry: Hook 注册表（新 API，可选）
            max_concurrency: 最大并发数
            error_policy: 错误策略
        """
        # 兼容层：优先使用 hook_registry，否则从 hook_engine 提取或创建
        if hook_registry is not None:
            # 新 API：直接使用提供的 hook_registry
            final_hook_registry = hook_registry
        elif isinstance(hook_engine, HookEngine):
            # 旧 API：从 HookEngine 创建新的 HookRegistry
            final_hook_registry = HookRegistry()
        elif isinstance(hook_engine, HookRegistry):
            # 旧 API：直接使用 HookRegistry
            final_hook_registry = hook_engine
        else:
            # 默认：创建新的 HookRegistry
            final_hook_registry = HookRegistry()

        # 适配 base 的新签名
        super().__init__(
            workflow_id=f"batch-{uuid4().hex[:8]}",
            hook_registry=final_hook_registry,
            max_concurrency=max_concurrency,
            graph_factory=graph_factory,
        )
        self._error_policy = error_policy
        # 保留原始 hook_engine 引用（用于向后兼容）
        self._legacy_hook_engine = hook_engine

    def build_graph(self) -> StateGraph:
        """构建 LangGraph 图（Batch 最小实现）。

        BatchWorkflow 不使用 build_graph() 模式，这是为了兼容 base 而提供的最小实现。
        实际执行通过 run() -> _execute() -> process_all() 完成。
        """
        graph = StateGraph(dict)
        graph.add_edge("__start__", "__end__")
        return graph

    async def process_all(self, items: list[Any]) -> Any:
        """
        并发处理所有 items，结果交给 merge_results() 聚合。

        best_effort：单个 item 失败记为 None，其余继续。
        fail_fast：任意 item 失败立即抛异常。
        """
        tasks = [self._process_item(item, idx) for idx, item in enumerate(items)]
        if self._error_policy == "fail_fast":
            results = await asyncio.gather(*tasks)
        else:
            raw_results = await asyncio.gather(*tasks, return_exceptions=True)
            results = [None if isinstance(item, BaseException) else item for item in raw_results]
        return self.merge_results(results)

    @abstractmethod
    async def _process_item(self, item: Any, index: int) -> Any:
        """子类实现单个 item 的处理逻辑。"""

    @abstractmethod
    def merge_results(self, results: list[Any]) -> Any:
        """子类实现多个 item 结果的聚合逻辑。"""

    @abstractmethod
    async def _execute(self, **kwargs: Any) -> Any:
        """子类实现入口，通常直接调用 process_all(items)。"""


    async def run(self, **kwargs: Any) -> Any:
        """向后兼容的 run() 方法。

        保持旧 API 签名 run(**kwargs)，内部调用子类的 _execute()。
        """
        # 发射 Hook（保持与旧 base.py 一致的行为）
        try:
            await self._emit_hook(HookEvent.WORKFLOW_START, {
                "workflow_id": self._workflow_id,
                "workflow_session_id": f"workflow-{self._workflow_id}",
                "workflow_path": self._workflow_path,
            })
            result = await self._execute(**kwargs)
            return result
        finally:
            await self._emit_hook(HookEvent.WORKFLOW_END, {
                "workflow_id": self._workflow_id,
                "workflow_session_id": f"workflow-{self._workflow_id}",
                "workflow_path": self._workflow_path,
            })


__all__ = ["BatchWorkflow"]
