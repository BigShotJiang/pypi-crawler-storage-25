"""
Module: test_config_cmd
Description: Tests for configuration management commands

Implements:
    - docs/cli/reference.md#huitzo-config
"""

from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from huitzo_cli.commands.config_cmd import config_app
from huitzo_cli.config import ConfigManager


def test_config_get(cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test getting config value."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["get", "api_url"])
    assert result.exit_code == 0
    assert "https://huitzo.ai" in result.stdout


def test_config_set(cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Test setting non-sensitive config value."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["set", "api_url", "https://test.example.com"])
    assert result.exit_code == 0
    assert "set to" in result.stdout


def test_config_set_auth_token_delegates_to_token_store(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test setting auth.token writes to TokenStore, not config.yaml."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    with patch("huitzo_cli.commands.config_cmd.TokenStore") as mock_ts_cls:
        mock_ts = mock_ts_cls.return_value
        result = cli_runner.invoke(
            config_app, ["set", "auth.token", "visible-value"], input="hidden-value\n"
        )
        assert result.exit_code == 0
        assert "updated" in result.stdout
        mock_ts.save.assert_called_once_with("hidden-value")


def test_config_list(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test listing config values."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["list"])
    assert result.exit_code == 0
    assert "api_url" in result.stdout


def test_config_get_auth_token_masks_by_default(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config get auth.token masks value by default."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    with patch("huitzo_cli.commands.config_cmd.AuthClient") as mock_auth_cls:
        mock_auth_cls.return_value.get_token.return_value = "super-secret-token"
        result = cli_runner.invoke(config_app, ["get", "auth.token"])
        assert result.exit_code == 0
        assert "********" in result.stdout
        assert "super-secret-token" not in result.stdout


def test_config_get_auth_token_reveal(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config get --reveal auth.token shows value unmasked via AuthClient."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    with patch("huitzo_cli.commands.config_cmd.AuthClient") as mock_auth_cls:
        mock_auth_cls.return_value.get_token.return_value = "super-secret-token"
        result = cli_runner.invoke(config_app, ["get", "auth.token", "--reveal"])
        assert result.exit_code == 0
        assert "super-secret-token" in result.stdout
        assert "********" not in result.stdout


def test_config_get_auth_token_not_set(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test config get auth.token when not authenticated."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    with patch("huitzo_cli.commands.config_cmd.AuthClient") as mock_auth_cls:
        mock_auth_cls.return_value.get_token.return_value = None
        result = cli_runner.invoke(config_app, ["get", "auth.token"])
        assert result.exit_code == 1
        assert "Not authenticated" in result.stdout


def test_config_path(
    cli_runner: CliRunner, temp_dir: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test showing config path."""
    monkeypatch.setattr(ConfigManager, "get_config_dir", staticmethod(lambda: temp_dir / "config"))

    result = cli_runner.invoke(config_app, ["path"])
    assert result.exit_code == 0
    assert "config.yaml" in result.stdout
