"""
Module: test_exit_codes
Description: Tests for the error-to-exit-code mapping.

Implements:
    - docs/cli/reference.md#exit-codes
    - docs/cli/agent-integration.md#exit-codes
"""

from __future__ import annotations

from huitzo_cli.errors import (
    AuthenticationError,
    CommandNotFoundError,
    CommandValidationError,
    HuitzoCliError,
    NetworkError,
    NonInteractiveError,
    SandboxCommandError,
    ServerError,
)
from huitzo_cli.exit_codes import code_for_error


class TestCodeForError:
    """Test that each error type maps to the correct exit code."""

    def test_authentication_error(self) -> None:
        err = AuthenticationError("bad token")
        assert code_for_error(err) == 2

    def test_command_validation_error(self) -> None:
        err = CommandValidationError("missing arg")
        assert code_for_error(err) == 3

    def test_command_not_found_error(self) -> None:
        err = CommandNotFoundError("no-such-cmd")
        assert code_for_error(err) == 3

    def test_non_interactive_error(self) -> None:
        err = NonInteractiveError("prompt required")
        assert code_for_error(err) == 3

    def test_network_error(self) -> None:
        err = NetworkError("connection refused")
        assert code_for_error(err) == 4

    def test_server_error(self) -> None:
        err = ServerError("500 internal")
        assert code_for_error(err) == 5

    def test_sandbox_command_error(self) -> None:
        err = SandboxCommandError(
            error_type="StorageError",
            message="storage failed",
            command="save",
        )
        assert code_for_error(err) == 10

    def test_base_huitzo_cli_error(self) -> None:
        err = HuitzoCliError("generic error")
        assert code_for_error(err) == 1
