"""
Module: test_platform_context
Description: Tests for the platform context factory.

Implements:
    - docs/cli/reference.md#huitzo-dev
"""

from pathlib import Path

import pytest

from huitzo_sdk import Context, FileClient, HTTPClient, LLMClient
from huitzo_sdk.errors import IntegrationError

from huitzo_cli.sandbox.platform_context import create_platform_context


def test_returns_sdk_context(temp_dir: Path) -> None:
    """create_platform_context returns a real SDK Context instance."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    assert isinstance(ctx, Context)


def test_llm_client_accessible(temp_dir: Path) -> None:
    """ctx.llm returns an LLMClient."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    assert isinstance(ctx.llm, LLMClient)


def test_http_client_accessible(temp_dir: Path) -> None:
    """ctx.http returns an HTTPClient."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    assert isinstance(ctx.http, HTTPClient)


def test_files_client_accessible(temp_dir: Path) -> None:
    """ctx.files returns a FileClient."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    assert isinstance(ctx.files, FileClient)


def test_email_raises_integration_error(temp_dir: Path) -> None:
    """ctx.email raises IntegrationError because it's not wired."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    with pytest.raises(IntegrationError):
        _ = ctx.email


def test_telegram_raises_integration_error(temp_dir: Path) -> None:
    """ctx.telegram raises IntegrationError because it's not wired."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    with pytest.raises(IntegrationError):
        _ = ctx.telegram


def test_ssh_raises_integration_error(temp_dir: Path) -> None:
    """ctx.ssh raises IntegrationError because it's not wired."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="test-cmd",
        namespace="test-pack",
    )
    with pytest.raises(IntegrationError):
        _ = ctx.ssh


def test_command_metadata(temp_dir: Path) -> None:
    """Context has correct command_name and namespace."""
    ctx = create_platform_context(
        files_root=temp_dir / "files",
        command_name="my-command",
        namespace="@my-pack/my-command",
    )
    assert ctx.command_name == "my-command"
    assert ctx.namespace == "@my-pack/my-command"
