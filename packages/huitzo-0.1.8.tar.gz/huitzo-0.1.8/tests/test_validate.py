"""
Module: test_validate
Description: Tests for pack validation

Implements:
    - docs/cli/reference.md#huitzo-validate
"""

from pathlib import Path

import yaml

from huitzo_cli.validator import PackValidator


def test_validator_missing_pyproject(temp_dir: Path) -> None:
    """Test validation with missing pyproject.toml."""
    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert not result.valid
    assert "pyproject.toml not found" in result.errors


def test_validator_missing_huitzo_yaml(temp_dir: Path) -> None:
    """Test validation with missing huitzo.yaml."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert not result.valid
    assert "huitzo.yaml not found" in result.errors


def test_validator_invalid_huitzo_yaml(temp_dir: Path) -> None:
    """Test validation with invalid YAML."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")
    (temp_dir / "huitzo.yaml").write_text("invalid: [yaml")

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert not result.valid
    assert any("Invalid YAML" in error for error in result.errors)


def test_validator_missing_required_fields(temp_dir: Path) -> None:
    """Test validation with missing required fields."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    huitzo_config = {"pack": {"name": "test-pack"}}  # missing namespace, version, description
    (temp_dir / "huitzo.yaml").write_text(yaml.dump(huitzo_config))

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert not result.valid
    assert any("namespace" in error for error in result.errors)


def test_validator_invalid_visibility(temp_dir: Path) -> None:
    """Test validation with invalid visibility."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    huitzo_config = {
        "pack": {
            "name": "test-pack",
            "namespace": "test",
            "version": "0.0.0",
            "description": "A test pack",
            "visibility": "invalid",
        }
    }
    (temp_dir / "huitzo.yaml").write_text(yaml.dump(huitzo_config))

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert not result.valid
    assert any("visibility must be" in error for error in result.errors)


def test_validator_valid_pack(temp_dir: Path) -> None:
    """Test validation with valid pack."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    huitzo_config = {
        "pack": {
            "name": "test-pack",
            "namespace": "test",
            "version": "0.0.0",
            "description": "A test pack",
            "visibility": "private",
        }
    }
    (temp_dir / "huitzo.yaml").write_text(yaml.dump(huitzo_config))

    # Create source directory
    src_dir = temp_dir / "src" / "test_pack"
    src_dir.mkdir(parents=True)
    (src_dir / "__init__.py").write_text("")

    # Create tests directory
    tests_dir = temp_dir / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_example.py").write_text("")

    # Create README
    (temp_dir / "README.md").write_text("# Test Pack")

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert result.valid
    assert len(result.errors) == 0


def test_validator_warnings(temp_dir: Path) -> None:
    """Test validation warnings."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    huitzo_config = {
        "pack": {
            "name": "test-pack",
            "namespace": "test",
            "version": "0.0.0",
            "description": "A test pack",
            "visibility": "private",
        }
    }
    (temp_dir / "huitzo.yaml").write_text(yaml.dump(huitzo_config))

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate()

    assert result.valid  # valid because errors is empty
    assert len(result.warnings) > 0  # but there are warnings


def test_validator_strict_mode(temp_dir: Path) -> None:
    """Test validation in strict mode."""
    (temp_dir / "pyproject.toml").write_text("[project]\nname = 'test'\n")

    huitzo_config = {
        "pack": {
            "name": "test-pack",
            "namespace": "test",
            "version": "0.0.0",
            "description": "A test pack",
            "visibility": "private",
        }
    }
    (temp_dir / "huitzo.yaml").write_text(yaml.dump(huitzo_config))

    validator = PackValidator(pack_root=temp_dir)
    result = validator.validate(strict=True)

    # Strict mode treats warnings as errors
    assert not result.valid
    assert len(result.errors) > 0
