# Hello Pack

A simple example Intelligence Pack demonstrating Huitzo SDK patterns.

## Installation

```bash
pip install -e .
```

## Usage

### Running Tests

```bash
pytest tests/ -v
```

### Validating

```bash
huitzo pack validate
```

### Building

```bash
huitzo pack build
```

### Commands

This pack provides two example commands:

- `hello` - Greet someone (accepts `name` parameter)
- `goodbye` - Say goodbye (accepts `name` parameter)

## Development

This is a minimal pack showing:
- Command declaration with `@command` decorator
- Async command handlers
- Simple input/output handling
- Test structure

## See Also

- [Huitzo SDK Documentation](https://docs.huitzo.dev/sdk/)
- [Command Patterns](https://docs.huitzo.dev/sdk/commands.md)
- [Context API](https://docs.huitzo.dev/sdk/context.md)
