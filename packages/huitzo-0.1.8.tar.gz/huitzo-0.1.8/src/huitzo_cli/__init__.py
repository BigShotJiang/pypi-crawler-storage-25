"""
Module: huitzo_cli
Description: CLI for developing Intelligence Packs on Huitzo

Implements:
    - docs/cli/reference.md
    - docs/guides/developer-environment.md

See Also:
    - docs/architecture/overview.md (for platform architecture)
    - docs/sdk/commands.md (for Intelligence Pack command patterns)
"""

from huitzo_cli.version import get_version

__version__ = get_version()
