"""
Module: registry_command
Description: Pack registry operations (publish, install, list, run)

Implements:
    - docs/cli/reference.md#huitzo-publish
    - docs/cli/reference.md#huitzo-list
    - docs/cli/reference.md#huitzo-run
"""

import importlib.metadata
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import httpx
import typer
import yaml
from rich.syntax import Syntax
from rich.table import Table

from huitzo_cli.commands.build import _do_build
from huitzo_cli.http_utils import get_auth, parse_error
from huitzo_cli.output import OutputContext, get_output


def _load_pack_manifest(output: OutputContext) -> dict[str, Any]:
    """Load huitzo.yaml from current directory."""
    manifest_path = Path.cwd() / "huitzo.yaml"
    if not manifest_path.exists():
        output.print("[red]No huitzo.yaml found. Are you in a pack directory?[/red]")
        raise typer.Exit(1)
    with open(manifest_path) as f:
        data: dict[str, Any] = yaml.safe_load(f)
        return data


def publish(ctx: typer.Context) -> None:
    """Publish pack to Huitzo backend.

    Builds a wheel (if needed), creates the pack on the backend,
    and uploads the wheel as a new version.
    """
    output = get_output(ctx)
    manifest = _load_pack_manifest(output)
    auth, token, api_url = get_auth()

    pack = manifest.get("pack", {})
    pack_name = pack.get("name", "")
    namespace = pack.get("namespace", pack_name)
    visibility = pack.get("visibility", "private")
    version = pack.get("version", "0.0.0")
    headers = {"Authorization": f"Bearer {token}"}

    # Find or build wheel
    dist_dir = Path.cwd() / "dist"
    wheels = list(dist_dir.glob("*.whl")) if dist_dir.exists() else []

    if not wheels:
        _do_build(format_type="wheel", output=output)
        wheels = list(dist_dir.glob("*.whl")) if dist_dir.exists() else []

    if not wheels:
        output.print("[red]No wheel found in dist/. Run: huitzo pack build[/red]")
        raise typer.Exit(1)

    wheel_path = sorted(wheels, key=lambda p: p.stat().st_mtime)[-1]

    # Create pack (409 = already exists, that's OK)
    # Send scope WITHOUT @ prefix — the backend adds it (packs.py:91)
    scope = namespace
    output.print(f"[bold]Registering pack @{scope}/{pack_name}...[/bold]")
    try:
        resp = httpx.post(
            f"{api_url}/api/v1/packs",
            json={"scope": scope, "name": pack_name, "visibility": visibility},
            headers=headers,
            timeout=30,
        )
    except httpx.HTTPError as e:
        output.print(f"[red]Could not connect to backend at {api_url}: {e}[/red]")
        raise typer.Exit(1)

    pack_id = None
    if resp.status_code == 201:
        output.print("[green]Pack created[/green]")
        pack_id = resp.json().get("data", {}).get("id")
    elif resp.status_code == 409:
        output.print("Pack already registered")
    else:
        output.print(f"[red]Failed to register pack: {parse_error(resp)}[/red]")
        raise typer.Exit(1)

    # If 409 (already exists), look up the pack_id by iterating owned packs.
    # Note: the backend list endpoint does not support query-param filtering and
    # excludes unlisted packs, so this fallback only works for non-unlisted packs.
    if not pack_id:
        # API returns scope without @ prefix; compare directly
        try:
            resp = httpx.get(
                f"{api_url}/api/v1/packs",
                headers=headers,
                timeout=30,
            )
        except httpx.HTTPError as e:
            output.print(f"[red]Could not connect to backend at {api_url}: {e}[/red]")
            raise typer.Exit(1)

        if resp.status_code != 200:
            output.print("[red]Failed to list packs[/red]")
            raise typer.Exit(1)

        try:
            packs = resp.json().get("data", [])
        except (ValueError, json.JSONDecodeError):
            output.print("[red]Unexpected response from server[/red]")
            raise typer.Exit(1)

        for p in packs:
            if p["scope"] == scope and p["name"] == pack_name:
                pack_id = p["id"]
                break

    if not pack_id:
        output.print(
            "[red]Could not find pack after creation. "
            "If the pack has unlisted visibility, the list API cannot resolve it.[/red]"
        )
        raise typer.Exit(1)

    # Upload wheel
    output.print(f"[bold]Uploading {wheel_path.name} (v{version})...[/bold]")
    try:
        with open(wheel_path, "rb") as f:
            resp = httpx.post(
                f"{api_url}/api/v1/packs/{pack_id}/versions",
                files={"wheel": (wheel_path.name, f, "application/octet-stream")},
                data={"version": version},
                headers=headers,
                timeout=120,
            )
    except httpx.HTTPError as e:
        output.print(f"[red]Could not connect to backend at {api_url}: {e}[/red]")
        raise typer.Exit(1)

    if resp.status_code != 201:
        output.print(f"[red]Upload failed: {parse_error(resp)}[/red]")
        raise typer.Exit(1)

    data = resp.json().get("data", {})
    commands = data.get("commands", [])

    output.print(f"[green]Published v{version} successfully[/green]")
    if commands:
        output.print("[bold]Registered commands:[/bold]")
        for cmd in commands:
            output.print(f"  {cmd['namespace']}")

    output.success(data)


def install(
    ctx: typer.Context,
    package: str = typer.Argument(..., help="Package name or path to .whl file"),
) -> None:
    """Install a pack from registry or local file.

    Args:
        package: Package name (from registry) or path to .whl file
    """
    output = get_output(ctx)

    # Check if it's a local file
    if package.endswith(".whl"):
        path = Path(package)
        if not path.exists():
            output.print(f"[red]File not found: {package}[/red]")
            raise typer.Exit(1)

        # Validate path does not escape working directory (path traversal)
        resolved = path.resolve()
        cwd = Path.cwd().resolve()
        try:
            resolved.relative_to(cwd)
        except ValueError:
            output.print(f"[red]Error: Path resolves outside working directory: {resolved}[/red]")
            raise typer.Exit(1)

        output.print(f"[bold]Installing from: {package}[/bold]")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", str(path)], check=False
            )
            if result.returncode != 0:
                raise typer.Exit(result.returncode)
            output.print("[green]Installation successful[/green]")
        except FileNotFoundError:
            output.print("[red]pip not found[/red]")
            raise typer.Exit(1)

        output.success({"package": package, "status": "installed"})
    else:
        # Registry install is not yet implemented — only local .whl is supported.
        output.print(f"[bold]Installing: {package}[/bold]")
        output.print("[yellow]Registry install not yet available. Use a local .whl file.[/yellow]")
        raise typer.Exit(1)


def list_packs(
    ctx: typer.Context,
    local: bool = typer.Option(False, "--local", help="List locally installed packs only"),
) -> None:
    """List packs on Huitzo.

    By default queries the remote API. Use --local to discover packs
    installed via the ``huitzo.commands`` entry-point group.
    """
    output = get_output(ctx)

    if local:
        _list_local_packs(output)
        return

    auth, token, api_url = get_auth()
    headers = {"Authorization": f"Bearer {token}"}

    try:
        resp = httpx.get(
            f"{api_url}/api/v1/packs",
            headers=headers,
            timeout=30,
        )
    except httpx.HTTPError as e:
        output.print(f"[red]Could not connect to backend at {api_url}: {e}[/red]")
        raise typer.Exit(1)

    if resp.status_code != 200:
        output.print(f"[red]Failed to list packs: {parse_error(resp)}[/red]")
        raise typer.Exit(1)

    try:
        packs = resp.json().get("data", [])
    except (ValueError, json.JSONDecodeError):
        output.print("[red]Unexpected response from server[/red]")
        raise typer.Exit(1)

    if not packs:
        output.print("[yellow]No packs found[/yellow]")
        return

    table = Table(title="Your Packs")
    table.add_column("Scope", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Visibility", style="yellow")
    table.add_column("Created", style="dim")

    for p in packs:
        scope = p["scope"].removeprefix("@")
        table.add_row(
            f"@{scope}",
            p["name"],
            p.get("visibility", "private"),
            p.get("created_at", "")[:10],
        )

    output.print(table)
    output.success({"packs": packs})


def _list_local_packs(output: OutputContext) -> None:
    """List locally installed packs via entry points."""
    output.print("[bold]Locally Installed Packs:[/bold]")

    huitzo_eps = importlib.metadata.entry_points(group="huitzo.commands")

    packs: dict[str, str] = {}
    for ep in huitzo_eps:
        dist_name = ep.dist.name if ep.dist else ep.name
        version = ep.dist.version if ep.dist else "unknown"
        packs[dist_name] = version

    if packs:
        for name, version in sorted(packs.items()):
            output.print(f"  {name} ({version})")
    else:
        output.print("  (none installed)")

    output.success({"packs": dict(sorted(packs.items()))})


_MAX_OUTPUT_BYTES = 2048


def run(
    ctx: typer.Context,
    pack_command: str = typer.Argument(..., help="Command namespace (e.g., @scope/pack/command)"),
    args_json: str = typer.Option("{}", "--args", help="JSON arguments"),
    raw: bool = typer.Option(False, "--raw", help="Print full raw output without truncation"),
) -> None:
    """Run a pack command via the backend API.

    Args:
        pack_command: Full command namespace (@scope/pack/command) or pack:command shorthand
    """
    output = get_output(ctx)
    auth, token, api_url = get_auth()
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    # Parse namespace
    if ":" in pack_command and not pack_command.startswith("@"):
        # Convert pack:command shorthand to @namespace/pack/command
        parts = pack_command.split(":", 1)
        pack_command = f"@{parts[0]}/{parts[1]}"

    try:
        body = json.loads(args_json)
    except json.JSONDecodeError:
        output.print("[red]Invalid JSON args[/red]")
        raise typer.Exit(1)

    output.print(f"[bold]Executing {pack_command}...[/bold]")

    try:
        resp = httpx.post(
            f"{api_url}/api/v1/commands/{pack_command}",
            json={"args": body},
            headers=headers,
            timeout=120,
        )
    except httpx.HTTPError as e:
        output.print(f"[red]Could not connect to backend at {api_url}: {e}[/red]")
        raise typer.Exit(1)

    if resp.status_code != 200:
        output.print(f"[red]Execution failed: {parse_error(resp)}[/red]")
        raise typer.Exit(1)

    data = resp.json().get("data", {})
    json_output = json.dumps(data, indent=2)
    if raw or len(json_output) <= _MAX_OUTPUT_BYTES:
        output.print_json(json_output)
    else:
        syntax = Syntax(json_output[:_MAX_OUTPUT_BYTES], "json", theme="monokai", word_wrap=True)
        output.print(syntax)
        output.print("\n[dim][truncated — use --raw for full output][/dim]")

    output.success(data)
