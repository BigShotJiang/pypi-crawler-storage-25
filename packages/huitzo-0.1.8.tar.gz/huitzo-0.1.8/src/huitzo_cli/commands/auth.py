"""
Module: auth_command
Description: Login and logout commands

Implements:
    - docs/cli/reference.md#huitzo-login
    - docs/guides/developer-environment.md#authentication
"""

from __future__ import annotations

import logging
import os

import typer

from huitzo_cli.auth import AuthClient
from huitzo_cli.config import ConfigManager
from huitzo_cli.interactive import guarded_prompt
from huitzo_cli.output import get_output

logger = logging.getLogger(__name__)


def _remove_stale_config_token(config: ConfigManager) -> None:
    """Remove any leftover ``auth.token`` from config.yaml.

    Tokens are stored exclusively in TokenStore (~/.huitzo/token).  Old
    config.yaml entries cause confusing output from ``huitzo config get``.
    """
    import yaml

    config_path = config.get_config_path(scope="user")
    if not config_path.exists():
        return
    try:
        with open(config_path) as f:
            data = yaml.safe_load(f) or {}
        auth_section = data.get("auth")
        if isinstance(auth_section, dict) and "token" in auth_section:
            del auth_section["token"]
            if os.name != "nt":
                fd = os.open(str(config_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                with os.fdopen(fd, "w") as f:
                    yaml.dump(data, f, default_flow_style=False)
            else:
                with open(config_path, "w") as f:
                    yaml.dump(data, f, default_flow_style=False)
    except (OSError, yaml.YAMLError):
        pass  # best-effort cleanup


def login(
    ctx: typer.Context,
    url: str | None = typer.Option(
        None,
        "--url",
        help="Override API URL (default: https://huitzo.ai)",
    ),
    email: str | None = typer.Option(
        None,
        "--email",
        help="Account email address",
    ),
    password: str | None = typer.Option(
        None,
        "--password",
        help="Account password (prefer HUITZO_PASSWORD env var to avoid shell history exposure)",
    ),
) -> None:
    """Login to Huitzo backend.

    Authenticates against the backend API and stores the access token.
    Use the HUITZO_AUTH_TOKEN env var to provide a pre-existing token
    instead of credential-based login.
    """
    output = get_output(ctx)
    config = ConfigManager()
    auth_client = AuthClient(config)

    # Env var token mode (replaces the old --token flag)
    env_token = os.environ.get("HUITZO_AUTH_TOKEN")
    if env_token:
        try:
            auth_client.login(email=email or "", token=env_token)
            _remove_stale_config_token(config)
            output.print("[green]Logged in with token from HUITZO_AUTH_TOKEN[/green]")
            output.success({"authenticated": True, "method": "env_token"})
            return
        except RuntimeError as e:
            logger.debug("Login failed (token mode): %s", e)
            output.error("AuthenticationError", "Login failed: invalid or expired token", 2)
            raise typer.Exit(1)

    # Prompt for missing fields
    if not email:
        email = guarded_prompt(ctx, "Email")

    if not password:
        # Prefer env var over interactive prompt (avoids shell history exposure)
        password = os.environ.get("HUITZO_PASSWORD")
    if not password:
        password = guarded_prompt(ctx, "Password", hide_input=True)

    try:
        data = auth_client.login(email=email, password=password, url=url)
        _remove_stale_config_token(config)
        user_email = data.get("email", email)
        output.print(f"[green]Logged in as {user_email}[/green]")
        if url:
            output.print(f"API URL: {url}")
        output.success({"authenticated": True, "email": user_email})
    except RuntimeError as e:
        logger.debug("Login failed: %s", e)
        output.error("AuthenticationError", "Login failed: check your credentials and try again", 2)
        raise typer.Exit(1)


def logout(ctx: typer.Context) -> None:
    """Logout from Huitzo backend."""
    output = get_output(ctx)
    config = ConfigManager()
    auth_client = AuthClient(config)

    try:
        auth_client.logout()
        output.print("[green]Logged out successfully[/green]")
        output.success({"authenticated": False})
    except OSError as e:
        output.error("LogoutError", f"Logout failed: {e}", 1)
        raise typer.Exit(1)
