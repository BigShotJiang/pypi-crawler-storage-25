"""
Module: build_command
Description: Pack building command

Implements:
    - docs/cli/reference.md#huitzo-build
"""

import subprocess
from pathlib import Path
from typing import Optional

import typer

from huitzo_cli.output import OutputContext, get_output
from huitzo_cli.validator import PackValidator


def _do_build(
    output_dir: Path | None = None,
    format_type: str = "wheel",
    output: OutputContext | None = None,
) -> Path:
    """Build a wheel or sdist, returning the output directory.

    Validates the pack, runs ``uv build``, and returns the output directory.
    Raises ``typer.Exit(1)`` on any failure so callers don't need to handle
    errors individually.

    Args:
        output_dir: Where to place the built artifact (default: ``dist/``).
        format_type: ``"wheel"`` or ``"sdist"``.
        output: OutputContext for printing (uses default if None).

    Returns:
        The resolved output directory.
    """
    if output is None:
        from rich.console import Console

        output = OutputContext(mode="human", console=Console())

    validator = PackValidator()
    result = validator.validate()

    if not result.valid:
        output.print("[red]Pack validation failed[/red]")
        for error in result.errors:
            output.print(f"  {error}")
        raise typer.Exit(1)

    out = output_dir or Path("dist")
    out.mkdir(parents=True, exist_ok=True)

    output.print("[bold]Building pack...[/bold]")

    cmd = ["uv", "build"]

    if format_type == "wheel":
        cmd.append("--wheel")
    elif format_type == "sdist":
        cmd.append("--sdist")
    else:
        output.error("ValidationError", f"Unknown format: {format_type}", 3)
        raise typer.Exit(1)

    if output_dir:
        cmd.extend(["-o", str(out)])

    try:
        build_result = subprocess.run(cmd, check=False)
        if build_result.returncode != 0:
            raise typer.Exit(build_result.returncode)
    except FileNotFoundError:
        output.error("CommandError", "uv not found. Install from: https://docs.astral.sh/uv/", 1)
        raise typer.Exit(1)

    output.print("[green]Build successful[/green]")
    return out


def build(
    ctx: typer.Context,
    output_path: Optional[Path] = typer.Option(None, "--output", "-o", help="Output directory"),
    format_type: str = typer.Option(
        "wheel", "--format", "-f", help="Build format (wheel or sdist)"
    ),
) -> None:
    """Build Intelligence Pack for distribution.

    Validates pack first, then builds wheel or sdist using uv build.

    Options:
    - --output: Output directory (default: dist/)
    - --format: Build format (wheel or sdist)
    """
    out = get_output(ctx)
    result_dir = _do_build(output_dir=output_path, format_type=format_type, output=out)
    out.print(f"Output: {result_dir}")
    out.success({"output_dir": str(result_dir), "format": format_type})
