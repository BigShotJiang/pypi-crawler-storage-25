"""
Module: secrets_command
Description: Secrets management commands (keyring-backed with file fallback)

Implements:
    - docs/cli/reference.md#huitzo-secrets
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from huitzo_cli.interactive import guarded_prompt
from huitzo_cli.output import get_output

secrets_app = typer.Typer(help="Manage secrets")
logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "huitzo-cli"


def _keyring_available() -> bool:
    """Check if the keyring library is importable and functional."""
    try:
        import keyring

        # Attempt a no-op to verify backend is functional
        keyring.get_credential(_KEYRING_SERVICE, "__probe__")
        return True
    except Exception:
        return False


@secrets_app.callback(invoke_without_command=True)
def secrets_callback(ctx: typer.Context) -> None:
    """Manage secrets - set, list, and remove pack secrets."""
    if ctx.invoked_subcommand is None:
        output = get_output(ctx)
        output.print(ctx.get_help())
        raise typer.Exit(0)


class SecretsStore:
    """Secrets storage with OS keychain support and file fallback."""

    @staticmethod
    def _get_secrets_dir() -> Path:
        """Get platform-specific secrets directory."""
        if os.name == "nt":  # Windows
            base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            return base / "huitzo" / "secrets"
        else:  # Unix-like
            return Path.home() / ".huitzo" / "secrets"

    @classmethod
    def _get_secrets_file(cls, pack_name: str = "default") -> Path:
        """Get secrets file for pack."""
        return cls._get_secrets_dir() / f"{pack_name}.json"

    @classmethod
    def _keyring_key(cls, pack: str, name: str) -> str:
        """Build a keyring account key from pack and secret name."""
        return f"{pack}:{name}"

    @classmethod
    def set(cls, name: str, value: str, pack: str = "default") -> str | None:
        """Store a secret, preferring OS keychain when available.

        Returns a warning message if keychain is not available, None otherwise.
        """
        if _keyring_available():
            import keyring

            keyring.set_password(_KEYRING_SERVICE, cls._keyring_key(pack, name), value)
            # Also record the key name in the index file (no values)
            cls._record_key_in_index(name, pack)
            return None

        cls._file_set(name, value, pack)
        return (
            "OS keychain not available — storing secret in a "
            "permission-restricted file (not encrypted). "
            "Install 'keyring' for better security."
        )

    @classmethod
    def get(cls, name: str, pack: str = "default") -> tuple[str | None, str | None]:
        """Get a secret, trying keyring first then file fallback.

        Returns (value, migration_message). migration_message is set if the
        secret was migrated from file to keyring.
        """
        if _keyring_available():
            import keyring

            value: str | None = keyring.get_password(_KEYRING_SERVICE, cls._keyring_key(pack, name))
            if value is not None:
                return value, None
            # Fall through to check file (migration path)

        # File fallback / migration
        file_value = cls._file_get(name, pack)
        migration_msg = None
        if file_value is not None and _keyring_available():
            # Migrate from file to keyring
            import keyring

            keyring.set_password(_KEYRING_SERVICE, cls._keyring_key(pack, name), file_value)
            cls._record_key_in_index(name, pack)
            cls._file_remove(name, pack)
            migration_msg = f"Migrated secret '{name}' to OS keychain"
        return file_value, migration_msg

    @classmethod
    def list_secrets(cls, pack: str = "default") -> dict[str, Any]:
        """List all secrets for a pack (names only, values masked)."""
        names: set[str] = set()

        # From index file
        index = cls._load_index(pack)
        names.update(index)

        # From legacy secrets file
        secrets_file = cls._get_secrets_file(pack)
        if secrets_file.exists():
            try:
                with open(secrets_file) as f:
                    file_secrets: dict[str, Any] = json.load(f)
                    names.update(file_secrets.keys())
            except (json.JSONDecodeError, OSError):
                pass

        return {name: "********" for name in sorted(names)}

    @classmethod
    def remove(cls, name: str, pack: str = "default") -> bool:
        """Remove a secret from both keyring and file."""
        removed = False

        if _keyring_available():
            import keyring

            try:
                keyring.delete_password(_KEYRING_SERVICE, cls._keyring_key(pack, name))
                removed = True
            except Exception:
                pass
            cls._remove_key_from_index(name, pack)

        file_removed = cls._file_remove(name, pack)
        return removed or file_removed

    # --- File-based storage (fallback) ---

    @classmethod
    def _file_set(cls, name: str, value: str, pack: str = "default") -> None:
        """Store a secret in a local JSON file with 0o600 permissions."""
        secrets_dir = cls._get_secrets_dir()
        secrets_dir.mkdir(parents=True, exist_ok=True)

        if os.name != "nt":
            secrets_dir.chmod(0o700)

        secrets_file = cls._get_secrets_file(pack)

        secrets = {}
        if secrets_file.exists():
            try:
                with open(secrets_file) as f:
                    secrets = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass

        secrets[name] = value

        if os.name != "nt":
            fd = os.open(str(secrets_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(secrets, f)
        else:
            with open(secrets_file, "w") as f:
                json.dump(secrets, f)

    @classmethod
    def _file_get(cls, name: str, pack: str = "default") -> str | None:
        """Get a secret from the local JSON file."""
        secrets_file = cls._get_secrets_file(pack)

        if not secrets_file.exists():
            return None

        try:
            with open(secrets_file) as f:
                secrets: dict[str, Any] = json.load(f)
                value: str | None = secrets.get(name)
                return value
        except (json.JSONDecodeError, OSError):
            return None

    @classmethod
    def _file_remove(cls, name: str, pack: str = "default") -> bool:
        """Remove a secret from the local JSON file."""
        secrets_file = cls._get_secrets_file(pack)

        if not secrets_file.exists():
            return False

        try:
            with open(secrets_file) as f:
                secrets = json.load(f)
        except (json.JSONDecodeError, OSError):
            return False

        if name not in secrets:
            return False

        del secrets[name]

        if os.name != "nt":
            fd = os.open(str(secrets_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(secrets, f)
        else:
            with open(secrets_file, "w") as f:
                json.dump(secrets, f)

        return True

    # --- Index file for keyring key tracking ---

    @classmethod
    def _index_file(cls, pack: str) -> Path:
        return cls._get_secrets_dir() / f"{pack}.keys.json"

    @classmethod
    def _load_index(cls, pack: str) -> list[str]:
        index_file = cls._index_file(pack)
        if not index_file.exists():
            return []
        try:
            with open(index_file) as f:
                data: list[str] = json.load(f)
                return data
        except (json.JSONDecodeError, OSError):
            return []

    @classmethod
    def _save_index(cls, pack: str, keys: list[str]) -> None:
        index_file = cls._index_file(pack)
        index_file.parent.mkdir(parents=True, exist_ok=True)
        if os.name != "nt":
            fd = os.open(str(index_file), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(sorted(set(keys)), f)
        else:
            with open(index_file, "w") as f:
                json.dump(sorted(set(keys)), f)

    @classmethod
    def _record_key_in_index(cls, name: str, pack: str) -> None:
        keys = cls._load_index(pack)
        if name not in keys:
            keys.append(name)
            cls._save_index(pack, keys)

    @classmethod
    def _remove_key_from_index(cls, name: str, pack: str) -> None:
        keys = cls._load_index(pack)
        if name in keys:
            keys.remove(name)
            cls._save_index(pack, keys)


@secrets_app.command(name="set")
def set_secret(
    ctx: typer.Context,
    name: str = typer.Argument(...),
    value: str | None = typer.Option(
        None,
        "--value",
        help="Secret value (prefer HUITZO_SECRET_VALUE env var to avoid shell history exposure)",
    ),
    pack: str = typer.Option("default", "--pack", help="Pack name"),
) -> None:
    """Set a secret.

    The secret value is prompted interactively (input is hidden) by default.
    Use --value for non-interactive mode.

    Args:
        name: Secret name
    """
    import os

    output = get_output(ctx)

    if value is None:
        # Prefer env var over interactive prompt (avoids shell history exposure)
        value = os.environ.get("HUITZO_SECRET_VALUE")
    if value is None:
        value = guarded_prompt(ctx, "Secret value", hide_input=True)

    output.print("[yellow]Secrets are stored locally only[/yellow]")
    output.print("[yellow]Cloud sync is not yet available[/yellow]")
    output.print()

    warning = SecretsStore.set(name, value, pack=pack)
    if warning:
        output.print(f"[yellow]{warning}[/yellow]")
    output.print(f"[green]Secret '{name}' set[/green]")
    output.success({"name": name, "pack": pack, "stored": True})


@secrets_app.command(name="list")
def list_secrets(
    ctx: typer.Context,
    pack: str = typer.Option("default", "--pack", help="Pack name"),
) -> None:
    """List all secrets."""
    output = get_output(ctx)
    output.print("[yellow]Secrets are stored locally only[/yellow]")
    output.print()

    secrets = SecretsStore.list_secrets(pack=pack)

    if not secrets:
        output.print(f"[yellow]No secrets for pack '{pack}'[/yellow]")
        output.success({"pack": pack, "secrets": {}})
        return

    table = Table(title=f"Secrets (pack: {pack})")
    table.add_column("Name", style="cyan")
    table.add_column("Value", style="yellow")

    for sname, svalue in secrets.items():
        table.add_row(sname, svalue)

    output.print(table)
    output.success({"pack": pack, "secrets": secrets})


@secrets_app.command()
def remove(
    ctx: typer.Context,
    name: str = typer.Argument(...),
    pack: str = typer.Option("default", "--pack", help="Pack name"),
) -> None:
    """Remove a secret.

    Args:
        name: Secret name
    """
    output = get_output(ctx)
    removed = SecretsStore.remove(name, pack=pack)
    if removed:
        output.print(f"[green]Secret '{name}' removed[/green]")
        output.success({"name": name, "pack": pack, "removed": True})
    else:
        output.print(f"[yellow]Secret '{name}' not found[/yellow]")
        raise typer.Exit(1)
