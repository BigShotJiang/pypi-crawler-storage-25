"""
Module: validate_command
Description: Pack validation command

Implements:
    - docs/cli/reference.md#huitzo-validate
"""

from pathlib import Path
from typing import Optional

import typer

from huitzo_cli.output import get_output
from huitzo_cli.validator import PackValidator


def validate(
    ctx: typer.Context,
    path: Optional[Path] = typer.Option(None, "--path", help="Path to pack root"),
    strict: bool = typer.Option(False, "--strict", help="Treat warnings as errors"),
) -> None:
    """Validate Intelligence Pack structure.

    Checks for:
    - pyproject.toml with required fields
    - huitzo.yaml manifest with required fields
    - Source directory with Python package
    - Test directory with tests
    - README documentation
    """
    output = get_output(ctx)
    pack_root = path or Path.cwd()

    if not pack_root.exists():
        output.error("ValidationError", f"Pack path not found: {pack_root}", 3)
        raise typer.Exit(1)

    validator = PackValidator(pack_root=pack_root)
    result = validator.validate(strict=strict)

    # Print results
    output.print()
    if result.valid:
        output.print("[green]Validation: PASSED[/green]")
    else:
        output.print("[red]Validation: FAILED[/red]")

    if result.errors:
        output.print("\n[red]Errors:[/red]")
        for error in result.errors:
            output.print(f"  {error}")

    if result.warnings:
        output.print("\n[yellow]Warnings:[/yellow]")
        for warning in result.warnings:
            output.print(f"  {warning}")

    output.print()

    output.success(
        {
            "valid": result.valid,
            "errors": result.errors,
            "warnings": result.warnings,
        }
    )

    if not result.valid:
        raise typer.Exit(1)
