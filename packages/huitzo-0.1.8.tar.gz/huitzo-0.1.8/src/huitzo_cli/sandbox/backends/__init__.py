"""
Module: sandbox.backends
Description: Local backend implementations for platform services in dev sandbox.

Implements:
    - docs/cli/reference.md#huitzo-dev
    - docs/guides/developer-environment.md#development-session-flow
"""

from huitzo_cli.sandbox.backends.files import LocalFileBackend
from huitzo_cli.sandbox.backends.http import LocalHTTPBackend
from huitzo_cli.sandbox.backends.llm import LocalLLMBackend

__all__ = ["LocalLLMBackend", "LocalHTTPBackend", "LocalFileBackend"]
