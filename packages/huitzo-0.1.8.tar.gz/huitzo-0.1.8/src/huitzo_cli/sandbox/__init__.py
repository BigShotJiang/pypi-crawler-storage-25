"""
Module: sandbox
Description: Local development sandbox for testing pack commands.

Implements:
    - docs/guides/developer-environment.md#development-session-flow
    - docs/cli/reference.md#huitzo-dev
"""

# TODO: expose a high-level SandboxSession façade here once the API stabilises.
# The core implementation lives in sandbox.proxy (LocalSandbox) and
# sandbox.platform_context (create_platform_context).
from huitzo_cli.sandbox.proxy import LocalSandbox

__all__ = ["LocalSandbox"]
