"""
Module: sandbox.platform_context
Description: Factory that creates a real SDK Context wired with local backend implementations.

Implements:
    - docs/cli/reference.md#huitzo-dev
    - docs/guides/developer-environment.md#development-session-flow

See Also:
    - docs/sdk/context.md (for Context API)
"""

from __future__ import annotations

from pathlib import Path

from huitzo_sdk import Context, FileClient, HTTPClient, LLMClient
from huitzo_sdk.storage import InMemoryBackend
from huitzo_sdk.types import DeploymentMode

from huitzo_cli.sandbox.backends import LocalFileBackend, LocalHTTPBackend, LocalLLMBackend


def create_platform_context(
    *,
    files_root: Path,
    command_name: str,
    namespace: str,
) -> Context:
    """Create a real SDK Context with local backend implementations.

    Platform services (LLM, HTTP, files) use local backends that call
    provider APIs directly. Storage uses an in-memory backend.
    Email, Telegram, and SSH are left as None — the SDK Context properties
    raise IntegrationError with a clear message when accessed.

    Args:
        files_root: Directory for file storage.
        command_name: Name of the command being executed.
        namespace: Pack namespace.

    Returns:
        A fully wired SDK Context instance.
    """
    return Context(
        command_name=command_name,
        namespace=namespace,
        deployment_mode=DeploymentMode.CLOUD,
        _llm=LLMClient(_backend=LocalLLMBackend()),
        _http=HTTPClient(
            _backend=LocalHTTPBackend(),
        ),
        _files=FileClient(_backend=LocalFileBackend(files_root)),
        _storage=InMemoryBackend(),
        _email=None,
        _telegram=None,
        _ssh=None,
    )
