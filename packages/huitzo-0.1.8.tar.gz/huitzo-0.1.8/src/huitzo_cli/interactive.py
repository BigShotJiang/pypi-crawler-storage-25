"""
Module: interactive
Description: Guards for interactive prompts in non-interactive mode.

Implements:
    - docs/cli/reference.md#global-options
    - docs/cli/agent-integration.md#non-interactive-mode

See Also:
    - docs/cli/agent-integration.md (for agent integration patterns)
"""

from __future__ import annotations

from typing import Any

import typer

from huitzo_cli.errors import NonInteractiveError


def is_non_interactive(ctx: typer.Context) -> bool:
    """Check if the CLI is running in non-interactive mode."""
    obj = ctx.obj or {}
    return bool(obj.get("non_interactive", False))


def guarded_prompt(ctx: typer.Context, message: str, **kwargs: Any) -> str:
    """Prompt for input if interactive; raise NonInteractiveError otherwise.

    Args:
        ctx: Typer context (must have ``obj["non_interactive"]``).
        message: Prompt message to display.
        **kwargs: Forwarded to ``typer.prompt()``.

    Returns:
        User input string.

    Raises:
        NonInteractiveError: If running in non-interactive mode.
    """
    if is_non_interactive(ctx):
        raise NonInteractiveError(
            f"Interactive prompt required for '{message}' but --non-interactive is set. "
            f"Provide the value via a flag instead.",
            user_message=f"Cannot prompt for '{message}' in non-interactive mode. "
            f"Provide the value via a CLI flag.",
        )
    return str(typer.prompt(message, **kwargs))
