"""
Module: exit_codes
Description: Exit code constants and error-to-code mapping for structured CLI output.

Implements:
    - docs/cli/reference.md#exit-codes
    - docs/cli/agent-integration.md#exit-codes

See Also:
    - docs/cli/agent-integration.md (for agent integration patterns)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from huitzo_cli.errors import HuitzoCliError

OK = 0
GENERAL = 1
AUTH = 2
VALIDATION = 3
NETWORK = 4
SERVER = 5
COMMAND_EXEC = 10
INTERRUPT = 130


def code_for_error(exc: HuitzoCliError) -> int:
    """Map a CLI exception to its corresponding exit code."""
    from huitzo_cli.errors import (
        AuthenticationError,
        CommandNotFoundError,
        CommandValidationError,
        NetworkError,
        NonInteractiveError,
        SandboxCommandError,
        ServerError,
    )

    if isinstance(exc, AuthenticationError):
        return AUTH
    if isinstance(exc, (CommandValidationError, CommandNotFoundError, NonInteractiveError)):
        return VALIDATION
    if isinstance(exc, NetworkError):
        return NETWORK
    if isinstance(exc, ServerError):
        return SERVER
    if isinstance(exc, SandboxCommandError):
        return COMMAND_EXEC
    return GENERAL
