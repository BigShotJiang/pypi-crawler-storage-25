def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() |  Gym |
| p2() |  Maze env|
| p3() | policy iteration |
| p4() | value iteration |
| p5() | monte carlo |
| p6() | td lambda |
| p7() | semi_gradient |
| p8() | actor-critic |
| p9() | DQN |

""")

def p1():
    print(r"""
          
# %%
import gymnasium as gym

# %%
env = gym.make('Blackjack-v1')

# %%
for i in range(10):
    obs , info = env.reset()
    while True:
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        print(action)
        print(obs)
        if terminated or truncated: 
            break

# %%
lunar_lander = gym.make("LunarLander-v3", continuous=False, gravity=-10.0,enable_wind=False, wind_power=15.0, turbulence_power=1.5,render_mode="rgb_array")

# %%
obs , info=lunar_lander.reset()
img = lunar_lander.render()

# %%


# %%
img.shape

# %%
import matplotlib.pyplot as plt

# %%
plt.imshow(img)

# %%
plt.ion() 
fig, ax = plt.subplots()
img_plot = ax.imshow(lunar_lander.render()) 
plt.show()

# %%
print("Observation Space:", lunar_lander.observation_space)


# %%
print("Action Space:", lunar_lander.action_space)


# %%

print("  Shape:", lunar_lander.observation_space.shape)


# %%
print("  High:", lunar_lander.observation_space.high)


# %%
print("  Low:", lunar_lander.observation_space.low)

# %%
import gymnasium as gym
import matplotlib.pyplot as plt
from IPython import display

lunar_lander = gym.make("LunarLander-v3", continuous=False, gravity=-10.0, 
                        enable_wind=False, wind_power=15.0, turbulence_power=1.5, 
                        render_mode="rgb_array")

obs, info = lunar_lander.reset()
img = lunar_lander.render()

fig, ax = plt.subplots()
img_plot = ax.imshow(img)
ax.axis('off')

for i in range(10):
    obs, info = lunar_lander.reset()
    while True:
        action = lunar_lander.action_space.sample()
        obs, reward, terminated, truncated, info = lunar_lander.step(action)

        img = lunar_lander.render()
        
        img_plot.set_data(img)

        display.display(plt.gcf())
        display.clear_output(wait=True)
        
        if terminated or truncated: 
            break

lunar_lander.close()


# %%


# %%

cartpole = gym.make("CartPole-v1", render_mode="rgb_array")

# %%

print("Observation Space:", cartpole.observation_space)


# %%
print("Action Space:", cartpole.action_space)


# %%

print("  Shape:", cartpole.observation_space.shape)


# %%

obs, info = cartpole.reset()
total_reward = 0
step_count = 0

while True:
    action = cartpole.action_space.sample() 
    obs, reward, terminated, truncated, info = cartpole.step(action)
    total_reward += reward
    step_count += 1
    
    if terminated or truncated:
        print(f"Episode finished after {step_count} steps")
        print(f"Total reward: {total_reward}")
        break

# %%

import matplotlib.pyplot as plt
from IPython import display


obs, info = cartpole.reset()
img = cartpole.render()


fig, ax = plt.subplots(figsize=(8, 6))
img_plot = ax.imshow(img)
ax.axis('off')
ax.set_title("CartPole-v1 Environment", fontsize=14)

total_reward = 0
step_count = 0

while True:
    action = cartpole.action_space.sample()
    obs, reward, terminated, truncated, info = cartpole.step(action)
    total_reward += reward
    step_count += 1
    
   
    img = cartpole.render()
    img_plot.set_data(img)
    ax.set_title(f"CartPole-v1 | Step: {step_count} | Reward: {total_reward:.1f}", fontsize=14)
    
    display.display(plt.gcf())
    display.clear_output(wait=True)
    
    if terminated or truncated:
        break

cartpole.close()

# %%




""")

def p2():
    print("""
# %% [markdown]
# ### Task: 1 To create the environment and identify the actions and rewards.

# %%
import random

# Simple Environment
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],    #  0= Open Space, 1= Wall, 2= Goal, 3 = Door, 4= Key
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [6, 1]  # Initial player position
enemy_pos = [4, 5]  # Initial enemy position
# enemy_yv = -1
unlock = 0

actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']


def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]

def move_enemy_towards_player(enemy_pos, player_pos):
    er, ec = enemy_pos
    pr, pc = player_pos

    moves = []

    if pr > er: moves.append('DOWN')
    if pr < er: moves.append('UP')
    if pc > ec: moves.append('RIGHT')
    if pc < ec: moves.append('LEFT')

    if moves:
        action = random.choice(moves)
    else:
        action = random.choice(actions)

    new_pos = move_player(action, enemy_pos)

    if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
        return enemy_pos

    if get_tile(new_pos) == 'wall':
        return enemy_pos

    return new_pos


def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0

    for step in range(steps):
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.05  

        
        # enemy_pos[0] += enemy_yv
        # if get_tile(enemy_pos) == 'wall':
        #     enemy_yv *= -1
        # enemy_pos = move_enemy(enemy_pos)
        enemy_pos = move_enemy_towards_player(enemy_pos, player_pos)


        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        
        total_reward -= 0.001  

        
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, Reward={total_reward}")

    print("Simulation ended.")
    return total_reward

# Run simulation
reward = simulate()
print(f"Total Reward: {reward}")


# %% [markdown]
# ## Task:2 Visulization of each step:

# %%
import matplotlib.pyplot as plt
import numpy as np
import random
import time


# Define the maze layout
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [6, 1]  # Initial player position
enemy_pos = [4, 5]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

# Function to get the tile type
def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

# Function to move the player
def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]
def move_enemy_towards_player(enemy_pos, player_pos):
    er, ec = enemy_pos
    pr, pc = player_pos

    moves = []

    if pr > er: moves.append('DOWN')
    if pr < er: moves.append('UP')
    if pc > ec: moves.append('RIGHT')
    if pc < ec: moves.append('LEFT')

    if moves:
        action = random.choice(moves)
    else:
        action = random.choice(actions)

    new_pos = move_player(action, enemy_pos)

    if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
        return enemy_pos

    if get_tile(new_pos) == 'wall':
        return enemy_pos

    return new_pos


# Visualize the maze with the player's and enemy's position
def visualize_maze(player_pos, enemy_pos):
    visual_maze = np.array(maze)
    visual_maze[player_pos[0], player_pos[1]] = 5  # Mark player position
    visual_maze[enemy_pos[0], enemy_pos[1]] = 6  # Mark enemy position

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(visual_maze, cmap='Pastel1', interpolation='nearest')

    # Color the tiles for clarity
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 1:  # Wall
                ax.text(j, i, 'W', ha='center', va='center', color='black')
            elif maze[i][j] == 2:  # Goal
                ax.text(j, i, 'G', ha='center', va='center', color='black')
            elif maze[i][j] == 3:  # Door
                ax.text(j, i, 'D', ha='center', va='center', color='black')
            elif maze[i][j] == 4:  # Key
                ax.text(j, i, 'K', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 5:  # Player
                ax.text(j, i, 'P', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 6:  # Enemy
                ax.text(j, i, 'E', ha='center', va='center', color='black')

    plt.show()




def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0
    rewards = []  # To track rewards over time

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        # Print out the action and position change
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, New Position={new_pos}")

        # Check movement and rewards
        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  # Open the door
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.1  # Small penalty for hitting the wall

        # Move enemy
        # enemy_pos[0] += enemy_yv
        # if get_tile(enemy_pos) == 'wall':
        #     enemy_yv *= -1
        enemy_pos = move_enemy_towards_player(enemy_pos, player_pos)

        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.01  # Small penalty for each step
        rewards.append(total_reward)

        # Visualize the maze and player's actio ns
        visualize_maze(player_pos, enemy_pos)
        time.sleep(0.5)  # Add delay for better viewing

        # Debug info
        print(f"Total Reward: {total_reward}")

    print("Simulation ended.")
    return total_reward, rewards

# Run simulation
reward, rewards = simulate()

# %%
# Plot the reward over time
plt.plot(rewards)
plt.xlabel('Steps')
plt.ylabel('Total Reward')
plt.title('Total Reward over Steps')6
plt.show()


# %%
import matplotlib.pyplot as plt
import numpy as np
import random
import time


# Define the maze layout
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [1, 1]  # Initial player position
enemy_pos = [3, 6]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

# Function to get the tile type
def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

# Function to move the player
def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]

# Visualize the maze with the player's and enemy's position
def visualize_maze(player_pos, enemy_pos):
    visual_maze = np.array(maze)
    visual_maze[player_pos[0], player_pos[1]] = 5  # Mark player position
    visual_maze[enemy_pos[0], enemy_pos[1]] = 6  # Mark enemy position

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(visual_maze, cmap='Pastel1', interpolation='nearest')

    # Color the tiles for clarity
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 1:  # Wall
                ax.text(j, i, 'W', ha='center', va='center', color='black')
            elif maze[i][j] == 2:  # Goal
                ax.text(j, i, 'G', ha='center', va='center', color='black')
            elif maze[i][j] == 3:  # Door
                ax.text(j, i, 'D', ha='center', va='center', color='black')
            elif maze[i][j] == 4:  # Key
                ax.text(j, i, 'K', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 5:  # Player
                ax.text(j, i, 'P', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 6:  # Enemy
                ax.text(j, i, 'E', ha='center', va='center', color='black')

    plt.show()




def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0
    rewards = []  # To track rewards over time

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        # Print out the action and position change
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, New Position={new_pos}")

        # Check movement and rewards
        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  # Open the door
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.1  # Small penalty for hitting the wall

        # Move enemy
        enemy_pos[0] += enemy_yv
        if get_tile(enemy_pos) == 'wall':
            enemy_yv *= -1
        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.01  # Small penalty for each step
        rewards.append(total_reward)

        # Visualize the maze and player's actions
        visualize_maze(player_pos, enemy_pos)
        time.sleep(0.5)  # Add delay for better viewing

        # Debug info
        print(f"Total Reward: {total_reward}")

    print("Simulation ended.")
    return total_reward, rewards

# Run simulation
reward, rewards = simulate()

# %% [markdown]
# ###Task 3
# For self implementation:
# 
# Add value function if player is closer to goal reward positive is far then negative. based on manhattan distance.

# %%
import random

# Simple Environment
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],    #  0= Open Space, 1= Wall, 2= Goal, 3 = Door, 4= Key
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [1, 1]  # Initial player position
enemy_pos = [3, 6]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0

    # Find the goal position
    goal_pos = None
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 2:  # Goal
                goal_pos = (i, j)
                break
        if goal_pos:
            break

    if not goal_pos:
        print("No goal found in the maze!")
        return total_reward

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)

        # Check if new position is valid
        if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
            total_reward -= 0.05  # Small penalty for hitting the wall
            continue

        tile = get_tile(new_pos)

        # Calculate distances
        current_dist = abs(player_pos[0] - goal_pos[0]) + abs(player_pos[1] - goal_pos[1])
        new_dist = abs(new_pos[0] - goal_pos[0]) + abs(new_pos[1] - goal_pos[1])

        # Check movement and rewards
        if tile == 'empty' or tile == 'key' or tile == 'goal' or (tile == 'door' and unlock > 0):
            if tile == 'goal':
                print("Goal Reached!")
                total_reward += 10  # Large reward for reaching the goal
                break
            elif tile == 'key':
                unlock += 1
                maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            elif tile == 'door' and unlock > 0:
                unlock -= 1
                maze[new_pos[0]][new_pos[1]] = 0  # Open the door

            player_pos = new_pos

            # Reward for moving closer to the goal
            if new_dist < current_dist:
                total_reward += 1
            # Penalty for moving farther from the goal
            elif new_dist > current_dist:
                total_reward -= 0.5
        elif tile == 'wall':
            total_reward -= 0.05  # Small penalty for hitting the wall

        # Move enemy
        enemy_pos[0] += enemy_yv
        if get_tile(enemy_pos) == 'wall':
            enemy_yv *= -1
        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.001  # Small penalty for each step

        # Debug info
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, Reward={total_reward}")

    print("Simulation ended.")
    return total_reward

# Run simulation
reward = simulate()
print(f"Total Reward: {reward}")




""")

def p3():
    print('''
# %% [markdown]
# ### Task: 1 To create the environment and identify the actions and rewards.

# %%
import random

# Simple Environment
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],    #  0= Open Space, 1= Wall, 2= Goal, 3 = Door, 4= Key
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [6, 1]  # Initial player position
enemy_pos = [4, 5]  # Initial enemy position
# enemy_yv = -1
unlock = 0

actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']


def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]

def move_enemy_towards_player(enemy_pos, player_pos):
    er, ec = enemy_pos
    pr, pc = player_pos

    moves = []

    if pr > er: moves.append('DOWN')
    if pr < er: moves.append('UP')
    if pc > ec: moves.append('RIGHT')
    if pc < ec: moves.append('LEFT')

    if moves:
        action = random.choice(moves)
    else:
        action = random.choice(actions)

    new_pos = move_player(action, enemy_pos)

    if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
        return enemy_pos

    if get_tile(new_pos) == 'wall':
        return enemy_pos

    return new_pos


def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0

    for step in range(steps):
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.05  

        
        # enemy_pos[0] += enemy_yv
        # if get_tile(enemy_pos) == 'wall':
        #     enemy_yv *= -1
        # enemy_pos = move_enemy(enemy_pos)
        enemy_pos = move_enemy_towards_player(enemy_pos, player_pos)


        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        
        total_reward -= 0.001  

        
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, Reward={total_reward}")

    print("Simulation ended.")
    return total_reward

# Run simulation
reward = simulate()
print(f"Total Reward: {reward}")


# %% [markdown]
# ## Task:2 Visulization of each step:

# %%
import matplotlib.pyplot as plt
import numpy as np
import random
import time


# Define the maze layout
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [6, 1]  # Initial player position
enemy_pos = [4, 5]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

# Function to get the tile type
def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

# Function to move the player
def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]
def move_enemy_towards_player(enemy_pos, player_pos):
    er, ec = enemy_pos
    pr, pc = player_pos

    moves = []

    if pr > er: moves.append('DOWN')
    if pr < er: moves.append('UP')
    if pc > ec: moves.append('RIGHT')
    if pc < ec: moves.append('LEFT')

    if moves:
        action = random.choice(moves)
    else:
        action = random.choice(actions)

    new_pos = move_player(action, enemy_pos)

    if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
        return enemy_pos

    if get_tile(new_pos) == 'wall':
        return enemy_pos

    return new_pos


# Visualize the maze with the player's and enemy's position
def visualize_maze(player_pos, enemy_pos):
    visual_maze = np.array(maze)
    visual_maze[player_pos[0], player_pos[1]] = 5  # Mark player position
    visual_maze[enemy_pos[0], enemy_pos[1]] = 6  # Mark enemy position

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(visual_maze, cmap='Pastel1', interpolation='nearest')

    # Color the tiles for clarity
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 1:  # Wall
                ax.text(j, i, 'W', ha='center', va='center', color='black')
            elif maze[i][j] == 2:  # Goal
                ax.text(j, i, 'G', ha='center', va='center', color='black')
            elif maze[i][j] == 3:  # Door
                ax.text(j, i, 'D', ha='center', va='center', color='black')
            elif maze[i][j] == 4:  # Key
                ax.text(j, i, 'K', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 5:  # Player
                ax.text(j, i, 'P', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 6:  # Enemy
                ax.text(j, i, 'E', ha='center', va='center', color='black')

    plt.show()




def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0
    rewards = []  # To track rewards over time

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        # Print out the action and position change
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, New Position={new_pos}")

        # Check movement and rewards
        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  # Open the door
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.1  # Small penalty for hitting the wall

        # Move enemy
        # enemy_pos[0] += enemy_yv
        # if get_tile(enemy_pos) == 'wall':
        #     enemy_yv *= -1
        enemy_pos = move_enemy_towards_player(enemy_pos, player_pos)

        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.01  # Small penalty for each step
        rewards.append(total_reward)

        # Visualize the maze and player's actio ns
        visualize_maze(player_pos, enemy_pos)
        time.sleep(0.5)  # Add delay for better viewing

        # Debug info
        print(f"Total Reward: {total_reward}")

    print("Simulation ended.")
    return total_reward, rewards

# Run simulation
reward, rewards = simulate()

# %%
# Plot the reward over time
plt.plot(rewards)
plt.xlabel('Steps')
plt.ylabel('Total Reward')
plt.title('Total Reward over Steps')6
plt.show()


# %%
import matplotlib.pyplot as plt
import numpy as np
import random
import time


# Define the maze layout
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [1, 1]  # Initial player position
enemy_pos = [3, 6]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

# Function to get the tile type
def get_tile(pos):
    row, col = pos
    return tiles[maze[row][col]]

# Function to move the player
def move_player(action, pos):
    row, col = pos
    if action == 'UP':
        row -= 1
    elif action == 'DOWN':
        row += 1
    elif action == 'LEFT':
        col -= 1
    elif action == 'RIGHT':
        col += 1
    return [row, col]

# Visualize the maze with the player's and enemy's position
def visualize_maze(player_pos, enemy_pos):
    visual_maze = np.array(maze)
    visual_maze[player_pos[0], player_pos[1]] = 5  # Mark player position
    visual_maze[enemy_pos[0], enemy_pos[1]] = 6  # Mark enemy position

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(visual_maze, cmap='Pastel1', interpolation='nearest')

    # Color the tiles for clarity
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 1:  # Wall
                ax.text(j, i, 'W', ha='center', va='center', color='black')
            elif maze[i][j] == 2:  # Goal
                ax.text(j, i, 'G', ha='center', va='center', color='black')
            elif maze[i][j] == 3:  # Door
                ax.text(j, i, 'D', ha='center', va='center', color='black')
            elif maze[i][j] == 4:  # Key
                ax.text(j, i, 'K', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 5:  # Player
                ax.text(j, i, 'P', ha='center', va='center', color='black')
            elif visual_maze[i, j] == 6:  # Enemy
                ax.text(j, i, 'E', ha='center', va='center', color='black')

    plt.show()




def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0
    rewards = []  # To track rewards over time

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)
        tile = get_tile(new_pos)

        # Print out the action and position change
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, New Position={new_pos}")

        # Check movement and rewards
        if tile == 'empty':
            player_pos = new_pos
        elif tile == 'goal':
            print("Goal Reached!")
            total_reward += 1
            break
        elif tile == 'key':
            unlock += 1
            maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            player_pos = new_pos
        elif tile == 'door' and unlock > 0:
            unlock -= 1
            maze[new_pos[0]][new_pos[1]] = 0  # Open the door
            player_pos = new_pos
        elif tile == 'wall':
            total_reward -= 0.1  # Small penalty for hitting the wall

        # Move enemy
        enemy_pos[0] += enemy_yv
        if get_tile(enemy_pos) == 'wall':
            enemy_yv *= -1
        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.01  # Small penalty for each step
        rewards.append(total_reward)

        # Visualize the maze and player's actions
        visualize_maze(player_pos, enemy_pos)
        time.sleep(0.5)  # Add delay for better viewing

        # Debug info
        print(f"Total Reward: {total_reward}")

    print("Simulation ended.")
    return total_reward, rewards

# Run simulation
reward, rewards = simulate()

# %% [markdown]
# ###Task 3
# For self implementation:
# 
# Add value function if player is closer to goal reward positive is far then negative. based on manhattan distance.

# %%
import random

# Simple Environment
maze = [
    [1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 1, 2, 0, 1],    #  0= Open Space, 1= Wall, 2= Goal, 3 = Door, 4= Key
    [1, 0, 1, 0, 1, 1, 3, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 0, 1],
    [1, 0, 1, 4, 1, 0, 0, 1],
    [1, 0, 1, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1]
]

TILE_SIZE = 64
tiles = ['empty', 'wall', 'goal', 'door', 'key']
player_pos = [1, 1]  # Initial player position
enemy_pos = [3, 6]  # Initial enemy position
enemy_yv = -1
unlock = 0

# Define actions
actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']

def simulate(steps=50):
    global player_pos, enemy_pos, unlock, enemy_yv
    total_reward = 0

    # Find the goal position
    goal_pos = None
    for i in range(len(maze)):
        for j in range(len(maze[0])):
            if maze[i][j] == 2:  # Goal
                goal_pos = (i, j)
                break
        if goal_pos:
            break

    if not goal_pos:
        print("No goal found in the maze!")
        return total_reward

    for step in range(steps):
        # Random action for player
        action = random.choice(actions)
        new_pos = move_player(action, player_pos)

        # Check if new position is valid
        if not (0 <= new_pos[0] < len(maze) and 0 <= new_pos[1] < len(maze[0])):
            total_reward -= 0.05  # Small penalty for hitting the wall
            continue

        tile = get_tile(new_pos)

        # Calculate distances
        current_dist = abs(player_pos[0] - goal_pos[0]) + abs(player_pos[1] - goal_pos[1])
        new_dist = abs(new_pos[0] - goal_pos[0]) + abs(new_pos[1] - goal_pos[1])

        # Check movement and rewards
        if tile == 'empty' or tile == 'key' or tile == 'goal' or (tile == 'door' and unlock > 0):
            if tile == 'goal':
                print("Goal Reached!")
                total_reward += 10  # Large reward for reaching the goal
                break
            elif tile == 'key':
                unlock += 1
                maze[new_pos[0]][new_pos[1]] = 0  # Collect the key
            elif tile == 'door' and unlock > 0:
                unlock -= 1
                maze[new_pos[0]][new_pos[1]] = 0  # Open the door

            player_pos = new_pos

            # Reward for moving closer to the goal
            if new_dist < current_dist:
                total_reward += 1
            # Penalty for moving farther from the goal
            elif new_dist > current_dist:
                total_reward -= 0.5
        elif tile == 'wall':
            total_reward -= 0.05  # Small penalty for hitting the wall

        # Move enemy
        enemy_pos[0] += enemy_yv
        if get_tile(enemy_pos) == 'wall':
            enemy_yv *= -1
        if player_pos == enemy_pos:
            print("Caught by Enemy!")
            total_reward -= 1
            break

        # Reward for steps
        total_reward -= 0.001  # Small penalty for each step

        # Debug info
        print(f"Step {step + 1}: Action={action}, Player={player_pos}, Reward={total_reward}")

    print("Simulation ended.")
    return total_reward

# Run simulation
reward = simulate()
print(f"Total Reward: {reward}")














# %%
# Import Gym to use the Blackjack environment (MDP simulator)
import gym

# Import random for weighted card drawing
import random

# Import the base Blackjack environment so we can extend it
from gym.envs.toy_text.blackjack import BlackjackEnv

# %%


# =========================================================
# STEP 1: CREATE A WEIGHTED BLACKJACK ENVIRONMENT (MDP)
# =========================================================
class WeightedBlackjackEnv(BlackjackEnv):
    """
    This class represents the ENVIRONMENT in the MDP.
    We override the card-drawing mechanism to introduce
    weighted cards (2/3 black, 1/3 red).
    """

    def draw_card(self):
        # Randomly choose a card value between 1 and 10
        card = random.choice([1,2,3,4,5,6,7,8,9,10])

        # Apply color weighting:
        # 2/3 probability -> black card (+value)
        # 1/3 probability -> red card (-value)
        if random.random() < 2/3:
            return card
        else:
            return -card


# %%
# Create an instance of the weighted Blackjack environment
env = WeightedBlackjackEnv()

# %%






# =========================================================
# STEP 2: EXPECTED VALUE FUNCTION (BELLMAN EXPECTATION)
# =========================================================
def expected_value(state, action, trials=100):
    """
    Approximates the expected reward:
        E[R | state, action]

    This is a practical form of the Bellman equation.
    """

    total_reward = 0  # Accumulates rewards over trials

    # Repeat multiple times to approximate expectation
    for _ in range(trials):

        # Reset environment for each trial
        env.reset()

        # Manually set the player and dealer state
        # This fixes the current MDP state
        env.player = [state[0]]   # player_sum
        env.dealer = [state[1]]   # dealer's visible card

        # Take the given action (0 = Stick, 1 = Hit)
        _, reward, terminated, truncated, _ = env.step(action)

        # Combine termination signals (new Gym format)
        done = terminated or truncated

        # If the game ended, add the reward
        if done:
            total_reward += reward

    # Return average reward (expected value)
    return total_reward / trials



# %%


# =========================================================
# STEP 3: OPTIMAL POLICY π*(s) USING BELLMAN OPTIMALITY
# =========================================================
def optimal_policy(state):
    """
    Chooses the best action for a given state
    using the Bellman optimality principle:
        π*(s) = argmax_a E[R | s, a]
    """

    # Compute expected reward if we HIT
    hit_value = expected_value(state, 1)

    # Compute expected reward if we STICK
    stick_value = expected_value(state, 0)

    # Print Bellman evaluation for clarity
    print("  Bellman Evaluation:")
    print(f"    Q(s, Hit)   ≈ {hit_value:.3f}")
    print(f"    Q(s, Stick) ≈ {stick_value:.3f}")

    # Choose the action with higher expected value
    if hit_value > stick_value:
        print("    → Optimal Action: HIT\n")
        return 1  # Hit
    else:
        print("    → Optimal Action: STICK\n")
        return 0  # Stick

# %%


# =========================================================
# STEP 4: AGENT–ENVIRONMENT INTERACTION LOOP
# =========================================================
# This loop shows how the agent interacts with the MDP
# using the optimal policy derived above.
for i_episode in range(5):

    # Reset environment to start a new episode
    state = env.reset()

    print("\n================ NEW EPISODE ================")

    while True:

        # Print the current MDP state
        # State = (player_sum, dealer_card, usable_ace)
        # print(f"MDP State s = {state}")

        # Select action using the optimal policy π*(s)
        action = optimal_policy(state)

        # Apply the action in the environment
        state, reward, terminated, truncated, _ = env.step(action)

        # Check if episode has ended
        done = terminated or truncated

        # If terminal state is reached, print outcome
        if done:
            print("Terminal State Reached")
            print(f"Reward r = {reward}")

            # Interpret reward
            if reward > 0:
                print("Outcome: WIN 🎉")
            elif reward < 0:
                print("Outcome: LOSS 😞")
            else:
                print("Outcome: DRAW 🤝")

            break
''')

def p4():
    print("""
# %%
# ------------------------------------------------------------
# INSTALL REQUIRED LIBRARIES
# ------------------------------------------------------------
# pygame         → Used for creating and visualizing the grid-world environment
# numpy          → Used for numerical operations and storing value/policy tables
# pillow (PIL)   → Used for loading and displaying saved images
# pyvirtualdisplay → Creates a virtual screen so Pygame can run in Google Colab

!pip install pygame numpy pillow pyvirtualdisplay

# %%
# ------------------------------------------------------------
# INSTALL XVFB (X Virtual Frame Buffer)
# ------------------------------------------------------------
# Required to run graphical applications (like Pygame)
# in a headless environment such as Google Colab

!apt-get update
!apt-get install -y xvfb

# %%
import numpy as np
import pygame
from PIL import Image
from pyvirtualdisplay import Display
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# SETUP VIRTUAL DISPLAY (needed to run Pygame in Google Colab)
# ------------------------------------------------------------
display = Display(visible=0, size=(800, 600))
display.start()

# ------------------------------------------------------------
# ENVIRONMENT (MDP) SETTINGS
# ------------------------------------------------------------

ROWS, COLS = 6, 6                  # Grid size → defines state space S
CELL_SIZE = 100                    # Size of each grid cell (for visualization)
SCREEN_WIDTH = COLS * CELL_SIZE
SCREEN_HEIGHT = ROWS * CELL_SIZE

DISCOUNT_FACTOR = 0.9              # γ (gamma) → discount factor in Bellman equation
THRESHOLD = 1e-4                   # Convergence threshold for Value Iteration

# ------------------------------------------------------------
# COLORS (for visualization only)
# ------------------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED   = (255, 0, 0)
BLUE  = (0, 0, 255)
GREY  = (200, 200, 200)

# ------------------------------------------------------------
# ACTION SPACE A
# Each action moves the agent in the grid:
# Left, Right, Up, Down
# ------------------------------------------------------------
ACTIONS = [(0, -1), (0, 1), (-1, 0), (1, 0)]

# ------------------------------------------------------------
# DEFINE REWARDS AND TERMINAL STATE
# ------------------------------------------------------------
reward_positions  = [(1, 1), (3, 2)]   # +1 reward states
penalty_positions = [(2, 0), (4, 4)]   # -1 penalty states
goal_position     = (5, 5)             # Terminal goal state (+10)
start_position    = (0, 0)             # Starting position

# ------------------------------------------------------------
# INITIALIZE MAZE (Reward Function R)
# ------------------------------------------------------------
maze = np.zeros((ROWS, COLS))          # Default reward = 0

for pos in reward_positions:
    maze[pos] = 1                      # Assign +1 rewards

for pos in penalty_positions:
    maze[pos] = -1                     # Assign -1 penalties

maze[goal_position] = 10               # Assign goal reward

# ------------------------------------------------------------
# INITIALIZE VALUE FUNCTION V(s)
# ------------------------------------------------------------
V = np.zeros((ROWS, COLS))             # Initial value of all states = 0

# ------------------------------------------------------------
# CHECK IF STATE IS INSIDE GRID
# ------------------------------------------------------------
def is_valid_state(state):
    x, y = state
    return 0 <= x < ROWS and 0 <= y < COLS

# ------------------------------------------------------------
# TRANSITION FUNCTION P(s'|s,a)
# Returns next state after taking an action
# If action leads outside grid → stay in same state
# ------------------------------------------------------------
def get_next_state(state, action):
    x, y = state
    dx, dy = action
    next_state = (x + dx, y + dy)
    return next_state if is_valid_state(next_state) else state

# ------------------------------------------------------------
# VALUE ITERATION ALGORITHM
# Implements Bellman Optimality Update:
#
# V(s) = max_a [ R(s,a,s') + γ * V(s') ]
#
# Iterates until values converge below threshold
# ------------------------------------------------------------
def value_iteration(V):
    while True:
        delta = 0                      # Tracks maximum change in V per iteration

        for x in range(ROWS):
            for y in range(COLS):
                state = (x, y)

                # Skip updating terminal (goal) state
                if state == goal_position:
                    continue

                action_values = []

                # Compute value for each possible action
                for action in ACTIONS:
                    next_state = get_next_state(state, action)
                    reward = maze[next_state]
                    value = reward + DISCOUNT_FACTOR * V[next_state]
                    action_values.append(value)

                # Select best action value (max over actions)
                best_value = max(action_values)

                # Track maximum update difference for convergence check
                delta = max(delta, abs(best_value - V[x, y]))

                # Update state value
                V[x, y] = best_value

        # Stop iteration if change is below threshold
        if delta < THRESHOLD:
            break

    return V

# ------------------------------------------------------------
# DRAW THE GRID AND DISPLAY COMPUTED STATE VALUES
# ------------------------------------------------------------
def draw_maze(screen, V):
    screen.fill(WHITE)
    font = pygame.font.SysFont(None, 28)

    for x in range(ROWS):
        for y in range(COLS):
            rect_x, rect_y = y * CELL_SIZE, x * CELL_SIZE

            # Draw grid cell
            pygame.draw.rect(screen, GREY, (rect_x, rect_y, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, BLACK, (rect_x, rect_y, CELL_SIZE, CELL_SIZE), 2)

            # Decide cell color and label based on type of state
            if (x, y) == start_position:
                color = (255, 255, 0)
                text = "Start"
            elif maze[x, y] == 1:
                color = GREEN
                text = "+1"
            elif maze[x, y] == -1:
                color = RED
                text = "-1"
            elif (x, y) == goal_position:
                color = BLUE
                text = "Goal"
            else:
                # Shade cell based on value function magnitude
                value_color = int(max(0, min(255, 255 - abs(V[x, y]) * 10)))
                color = (value_color, value_color, value_color)
                text = f"{int(V[x, y])}"

            # Fill cell with chosen color
            pygame.draw.rect(screen, color, (rect_x + 2, rect_y + 2, CELL_SIZE - 4, CELL_SIZE - 4))

            # Render text
            text_surface = font.render(text, True, BLACK)
            screen.blit(text_surface, (rect_x + 10, rect_y + 10))

    pygame.display.flip()

# ------------------------------------------------------------
# MAIN FUNCTION
# Runs Value Iteration and Displays Optimal Value Function
# ------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Optimal Value Function using Value Iteration")

    global V
    V = value_iteration(V)             # Compute optimal value function V*

    draw_maze(screen, V)               # Display results
    pygame.image.save(screen, "optimal_value_function.png")

    pygame.quit()

# Run program
main()

# ------------------------------------------------------------
# DISPLAY OUTPUT IMAGE INSIDE COLAB
# ------------------------------------------------------------
img = Image.open("optimal_value_function.png")
plt.imshow(img)
plt.axis('off')
plt.show()


# %%
import numpy as np
import pygame
from PIL import Image
from pyvirtualdisplay import Display
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# SETUP VIRTUAL DISPLAY (for running Pygame in Google Colab)
# ------------------------------------------------------------
display = Display(visible=0, size=(800, 600))
display.start()

# ------------------------------------------------------------
# ENVIRONMENT (MDP) SETTINGS
# ------------------------------------------------------------
ROWS, COLS = 6, 6                 # Grid size → defines state space S
CELL_SIZE = 100                   # Size of each grid cell (visualization)
SCREEN_WIDTH = COLS * CELL_SIZE
SCREEN_HEIGHT = ROWS * CELL_SIZE

DISCOUNT_FACTOR = 0.9             # γ (gamma) → discount factor in Bellman equations
THRESHOLD = 1e-4                  # Convergence threshold for policy evaluation

# ------------------------------------------------------------
# COLORS (used only for visualization)
# ------------------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED   = (255, 0, 0)
BLUE  = (0, 0, 255)
GREY  = (200, 200, 200)

# ------------------------------------------------------------
# ACTION SPACE A
# Each action moves agent in the grid:
# Left, Right, Up, Down
# ------------------------------------------------------------
ACTIONS = [(0, -1), (0, 1), (-1, 0), (1, 0)]

# Arrow directions for drawing policy arrows on grid
ARROWS = [(-20, 0), (20, 0), (0, -20), (0, 20)]

# ------------------------------------------------------------
# DEFINE REWARD STRUCTURE AND TERMINAL STATE
# ------------------------------------------------------------
reward_positions  = [(1, 1), (3, 2)]   # +1 reward states
penalty_positions = [(2, 0), (4, 4)]   # -1 penalty states
goal_position     = (5, 5)             # Terminal goal state (+10 reward)
start_position    = (0, 0)             # Starting state

# ------------------------------------------------------------
# INITIALIZE MAZE (Reward Function R)
# ------------------------------------------------------------
maze = np.zeros((ROWS, COLS))          # Default reward = 0

for pos in reward_positions:
    maze[pos] = 1                      # Assign +1 rewards

for pos in penalty_positions:
    maze[pos] = -1                     # Assign -1 penalties

maze[goal_position] = 10               # Assign goal reward

# ------------------------------------------------------------
# INITIALIZE POLICY π(s) AND VALUE FUNCTION V(s)
# ------------------------------------------------------------
policy = np.zeros((ROWS, COLS), dtype=int)  # Start with arbitrary policy (all zeros)
V = np.zeros((ROWS, COLS))                  # Initialize value function to zero

# ------------------------------------------------------------
# CHECK IF A STATE IS WITHIN GRID BOUNDARY
# ------------------------------------------------------------
def is_valid_state(state):
    x, y = state
    return 0 <= x < ROWS and 0 <= y < COLS

# ------------------------------------------------------------
# TRANSITION FUNCTION P(s'|s,a)
# Deterministic transition: moves agent unless boundary reached
# ------------------------------------------------------------
def get_next_state(state, action):
    x, y = state
    dx, dy = action
    next_state = (x + dx, y + dy)
    return next_state if is_valid_state(next_state) else state

# ------------------------------------------------------------
# POLICY EVALUATION STEP
# Computes Vπ(s) using Bellman Expectation Equation:
#
# V(s) = R(s,π(s),s') + γ * V(s')
#
# Iterates until values converge below threshold
# ------------------------------------------------------------
def policy_evaluation(V, policy):
    while True:
        delta = 0
        for x in range(ROWS):
            for y in range(COLS):
                state = (x, y)

                # Skip terminal state update
                if state == goal_position:
                    continue

                # Take action dictated by current policy
                action = policy[state]
                next_state = get_next_state(state, ACTIONS[action])

                reward = maze[next_state]
                value = reward + DISCOUNT_FACTOR * V[next_state]

                # Track maximum value change for convergence
                delta = max(delta, abs(value - V[x, y]))
                V[x, y] = value

        # Stop evaluation when change is very small
        if delta < THRESHOLD:
            break

    return V

# ------------------------------------------------------------
# POLICY IMPROVEMENT STEP
# Updates policy using Bellman Optimality Equation:
#
# π_new(s) = argmax_a [ R(s,a,s') + γ * V(s') ]
#
# Returns updated policy and stability flag
# ------------------------------------------------------------
def policy_improvement(V, policy):
    policy_stable = True

    for x in range(ROWS):
        for y in range(COLS):
            state = (x, y)

            # Skip terminal state
            if state == goal_position:
                continue

            action_values = []

            # Compute action-value for each possible action
            for action in range(len(ACTIONS)):
                next_state = get_next_state(state, ACTIONS[action])
                reward = maze[next_state]
                value = reward + DISCOUNT_FACTOR * V[next_state]
                action_values.append(value)

            # Select best action
            best_action = np.argmax(action_values)

            # Check if policy changed
            if best_action != policy[x, y]:
                policy_stable = False

            policy[x, y] = best_action

    return policy, policy_stable

# ------------------------------------------------------------
# POLICY ITERATION ALGORITHM
# Alternates between policy evaluation and improvement
# until policy becomes stable (optimal)
# ------------------------------------------------------------
def policy_iteration():
    global V, policy

    while True:
        V = policy_evaluation(V, policy)          # Evaluate current policy
        policy, stable = policy_improvement(V, policy)  # Improve policy

        if stable:                               # Stop if optimal policy reached
            break

    return policy, V

# ------------------------------------------------------------
# FIND OPTIMAL PATH FROM START TO GOAL USING FINAL POLICY
# ------------------------------------------------------------
def find_optimal_path(policy):
    path = []
    state = start_position

    while state != goal_position:
        path.append(state)
        action = ACTIONS[policy[state]]
        state = get_next_state(state, action)

    path.append(goal_position)
    return path

# ------------------------------------------------------------
# DRAW ARROWS REPRESENTING POLICY ACTIONS
# ------------------------------------------------------------
def draw_arrow(screen, pos, direction):
    x, y = pos
    start_x = y * CELL_SIZE + CELL_SIZE // 2
    start_y = x * CELL_SIZE + CELL_SIZE // 2
    dx, dy = direction
    end_x = start_x + dx
    end_y = start_y + dy

    pygame.draw.line(screen, BLACK, (start_x, start_y), (end_x, end_y), 4)
    pygame.draw.circle(screen, BLACK, (end_x, end_y), 6)

# ------------------------------------------------------------
# DRAW GRID WORLD WITH REWARDS, START, GOAL AND POLICY ARROWS
# ------------------------------------------------------------
def draw_maze(screen, policy, optimal_path):
    screen.fill(WHITE)
    font = pygame.font.SysFont(None, 28)

    for x in range(ROWS):
        for y in range(COLS):
            rect_x, rect_y = y * CELL_SIZE, x * CELL_SIZE

            # Draw grid cell border
            pygame.draw.rect(screen, GREY, (rect_x, rect_y, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, BLACK, (rect_x, rect_y, CELL_SIZE, CELL_SIZE), 2)

            # Color special states
            if (x, y) == start_position:
                color = (255, 255, 0)  # Start state
                text = "Start"
            elif (x, y) == goal_position:
                color = BLUE           # Goal state
                text = "Goal"
            elif maze[x, y] == 1:
                color = GREEN          # Reward state
                text = "+1"
            elif maze[x, y] == -1:
                color = RED            # Penalty state
                text = "-1"
            else:
                color = WHITE           # Normal state
                text = ""

            pygame.draw.rect(screen, color, (rect_x + 2, rect_y + 2, CELL_SIZE - 4, CELL_SIZE - 4))
            text_surface = font.render(text, True, BLACK)
            screen.blit(text_surface, (rect_x + 10, rect_y + 10))

            # Draw policy arrow (except in terminal state)
            if (x, y) != goal_position:
                action = policy[x, y]
                arrow_dir = ARROWS[action]
                draw_arrow(screen, (x, y), arrow_dir)

    pygame.display.flip()

# ------------------------------------------------------------
# MAIN FUNCTION
# Runs Policy Iteration and Displays Optimal Policy
# ------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Maze Game with Policy Iteration")

    global V, policy
    policy, V = policy_iteration()     # Compute optimal policy π* and value V*

    optimal_path = find_optimal_path(policy)  # (Optional) compute path from start to goal

    draw_maze(screen, policy, optimal_path)   # Display policy arrows
    pygame.image.save(screen, "maze_optimal_policy.png")

    pygame.quit()

# Run program
main()

# ------------------------------------------------------------
# DISPLAY OUTPUT IMAGE INSIDE COLAB
# ------------------------------------------------------------
img = Image.open("maze_optimal_policy.png")
plt.imshow(img)
plt.axis('off')
plt.show()


# %%
# !apt-get install -y xvfb python-opengl
# !pip install pygame
# !xvfb-run -s "-screen 0 1024x768x24" python your_script.py

# %%
# from pyvirtualdisplay import Display
# display = Display(visible=0, size=(1024,768))
# display.start()


# %%
# your pygame code here
# main()


# %%
# from PIL import Image
# import matplotlib.pyplot as plt

# img = Image.open("maze_optimal_policy.png")
# plt.imshow(img)
# plt.axis('off')







""")

def p5():
    print("""
# %%
# ==========================================================
# Monte Carlo Reinforcement Learning for Tic-Tac-Toe
# WITH VISUAL OUTPUT AND VISUALIZATION
#
# This program implements:
# 1. Monte Carlo First-Visit Control
# 2. Episodic learning via self-play
# 3. Policy improvement using epsilon-greedy strategy
# 4. Visualization of training performance
#
# Author: RL Teaching Version
# ==========================================================

import random
from collections import defaultdict
import matplotlib.pyplot as plt

# ------------------------------
# Environment Setup
# ------------------------------

# State representation: 
# Board is represented as tuple of length 9:
# index positions:
#
# 0 | 1 | 2
# ---------
# 3 | 4 | 5
# ---------
# 6 | 7 | 8

EMPTY = 0       # empty cell
X = 1           # RL Agent (learning player)
O = -1          # Opponent (random policy)

# Reward definition (terminal rewards)
WIN_REWARD = 1
LOSS_REWARD = -1
DRAW_REWARD = 0

# Create initial empty board
def initial_board():
    # tuple used because it is hashable (needed for dictionary keys)
    return tuple([EMPTY]*9)

# Return list of available actions (empty positions)
def available_moves(state):
    return [i for i,v in enumerate(state) if v == EMPTY]

# Apply an action and return new state
def make_move(state, action, player):
    # convert tuple to list to modify
    s = list(state)
    s[action] = player
    return tuple(s)

# Check if game has reached terminal state
def check_winner(state):

    # All winning combinations
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]

    # Check sums
    for a,b,c in wins:
        total = state[a]+state[b]+state[c]
        if total == 3:
            return X      # Agent wins
        if total == -3:
            return O      # Opponent wins

    # If no empty spaces left -> draw
    if EMPTY not in state:
        return "DRAW"

    return None   # game continues

# ------------------------------
# Monte Carlo RL Storage
# ------------------------------

# Q(s,a) = expected return for taking action a in state s
Q = defaultdict(float)

# Stores all returns observed for (state,action)
# Used to compute average return (Monte Carlo estimate)
Returns = defaultdict(list)

# Exploration probability (epsilon-greedy)
epsilon = 0.1

# Statistics for visualization
win_list = []
loss_list = []
draw_list = []

# ------------------------------
# Policy: Epsilon-Greedy
# ------------------------------

def epsilon_greedy(state):

    actions = available_moves(state)

    # Exploration: choose random action with probability epsilon
    if random.random() < epsilon:
        return random.choice(actions)

    # Exploitation: choose best action according to learned Q-values
    qvals = [Q[(state,a)] for a in actions]
    max_q = max(qvals)

    # multiple actions may have same value
    best_actions = [a for a in actions if Q[(state,a)] == max_q]

    return random.choice(best_actions)

# ------------------------------
# Episode Simulation (Self-Play)
# ------------------------------

def play_episode():

    # Each episode is a full game from start to terminal state
    state = initial_board()

    # store visited (state,action) pairs
    episode = []

    while True:

        # ---- Agent Move ----
        action = epsilon_greedy(state)

        next_state = make_move(state, action, X)

        # Save experience
        episode.append((state, action))

        winner = check_winner(next_state)

        if winner:
            # Episode ends
            return episode, winner

        # ---- Opponent Move (random policy) ----
        opp_moves = available_moves(next_state)

        if not opp_moves:
            return episode, "DRAW"

        opp_action = random.choice(opp_moves)

        next_state = make_move(next_state, opp_action, O)

        winner = check_winner(next_state)

        if winner:
            return episode, winner

        # Continue game
        state = next_state

# ------------------------------
# Training using Monte Carlo
# ------------------------------

def train(episodes=50000):

    wins = 0
    losses = 0
    draws = 0

    # Loop over episodes
    for ep in range(episodes):

        # Generate full episode
        episode, result = play_episode()

        # Assign final return (G)
        if result == X:
            G = WIN_REWARD
            wins += 1
        elif result == O:
            G = LOSS_REWARD
            losses += 1
        else:
            G = DRAW_REWARD
            draws += 1

        # First-Visit Monte Carlo Update
        visited = set()

        for (state, action) in episode:

            if (state,action) not in visited:

                visited.add((state,action))

                # Store observed return
                Returns[(state,action)].append(G)

                # Update Q-value as average return
                Q[(state,action)] = sum(Returns[(state,action)]) / len(Returns[(state,action)])

        # Save statistics every 1000 episodes
        if (ep+1) % 1000 == 0:

            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)

            print(f"Episode {ep+1} | Wins={wins} Losses={losses} Draws={draws}")

            wins = losses = draws = 0

# ------------------------------
# Visualization of Training Progress
# ------------------------------

def plot_results():

    plt.figure()

    plt.plot(win_list, label="Wins")
    plt.plot(loss_list, label="Losses")
    plt.plot(draw_list, label="Draws")

    plt.title("Monte Carlo Learning Progress in Tic-Tac-Toe")
    plt.xlabel("Training Steps (x1000 episodes)")
    plt.ylabel("Count")

    plt.legend()
    plt.show()

# ------------------------------
# Display Learned Policy (Opening Move)
# ------------------------------

def show_best_opening():

    state = initial_board()

    actions = available_moves(state)

    print("\nLearned Q-values for opening moves:")

    for a in actions:
        print("Position", a, "Q =", Q[(state,a)])

    best = max(actions, key=lambda a: Q[(state,a)])

    print("\nBest opening move learned:", best)

# ------------------------------
# Main Execution
# ------------------------------

if __name__ == "__main__":

    print("Training Monte Carlo Tic-Tac-Toe Agent...\n")

    train(50000)

    show_best_opening()

    plot_results()


# %%
# Simple inheritance

# # Base class
# class Animal:
#     def __init__(self, name):
#         self.name = name

#     def speak(self):
#         print(f"{self.name} makes a sound.")

# # # Derived class
# class Dog(Animal):

#     def speak(self):
#         print(f"{self.name} barks.")

# # # Create an instance of Animal
# # animal = Animal("Generic Animal")
# # animal.speak()  # Output: Generic Animal makes a sound.

# # # Create an instance of Dog
# dog = Dog()
# dog.speak()  # Output: Buddy barks.


# Super Keyword

# Super

# Base class
class Animal:
    def __init__(self,name):
        self.name = name

    def speak(self):
        print(f"{self.name} makes a sound.")

# # Derived class
class Dog(Animal):
    def __init__(self,name, breed):
        super().__init__(name)
        self.breed = breed

    def speak(self):
        super().speak()  # Call the base class method
        print(f"{self.name} barks. It is a {self.breed}.")

# # Create an instance of Dog
dog = Dog("nioty", "Golden Retriever")
dog.speak()
# Output:
# Buddy makes a sound.
# Buddy barks. It is a Golden Retriever.

# %%
# ==========================================================
# TASK COMPLETED: Every-Visit Monte Carlo Control

# This cell converts the First-Visit update to Every-Visit

# Run Cell 1 first (environment + helper functions), then run this cell.
# ==========================================================

from collections import defaultdict

# Reset learned values and stats for a fresh Every-Visit run
Q = defaultdict(float)
Returns = defaultdict(list)
win_list.clear()
loss_list.clear()
draw_list.clear()

def train_every_visit(episodes=50000):
    wins = 0
    losses = 0
    draws = 0

    for ep in range(episodes):
        # Generate one complete episode
        episode, result = play_episode()

        # Final return for this episodic game
        if result == X:
            G = WIN_REWARD
            wins += 1
        elif result == O:
            G = LOSS_REWARD
            losses += 1
        else:
            G = DRAW_REWARD
            draws += 1

        # Every-Visit Monte Carlo Update:
        # update for every occurrence of (state, action) in the episode
        for (state, action) in episode:
            Returns[(state, action)].append(G)
            Q[(state, action)] = sum(Returns[(state, action)]) / len(Returns[(state, action)])

        # Save stats every 1000 episodes
        if (ep + 1) % 1000 == 0:
            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)
            print(f"Episode {ep+1} | Wins={wins} Losses={losses} Draws={draws}")
            wins = losses = draws = 0

def run_every_visit_experiment(episodes=50000):
    print("Training Every-Visit Monte Carlo Tic-Tac-Toe Agent...\n")
    train_every_visit(episodes)
    show_best_opening()
    plot_results()

# Execute training
run_every_visit_experiment(50000)

# %%






""")

def p6():
    print("""
# %%
import random
from collections import defaultdict

EMPTY=0
X=1
O=-1

WIN_REWARD=1
LOSS_REWARD=-1
DRAW_REWARD=0

alpha=0.1
gamma=1.0
lam=0.8

epsilon_start=1.0
epsilon_min=0.05
epsilon_decay=0.995


def initial_board(): return tuple([EMPTY]*9)
def available_moves(state): return [i for i,v in enumerate(state) if v==EMPTY]

def make_move(state,action,player):
    s=list(state)
    s[action]=player
    return tuple(s)

def check_winner(state):
    wins=[(0,1,2),(3,4,5),(6,7,8),
          (0,3,6),(1,4,7),(2,5,8),
          (0,4,8),(2,4,6)]
    for a,b,c in wins:
        total=state[a]+state[b]+state[c]
        if total==3: return X
        if total==-3: return O
    if EMPTY not in state: return "DRAW"
    return None

def print_board(state):
    symbols={1:"X",-1:"O",0:" "}
    print()
    for i in range(3):
        row=[symbols[state[3*i+j]] for j in range(3)]
        print(" | ".join(row))
        if i<2: print("---------")
    print()


# ==========================================================
# TD LAMBDA TRAIN
# ==========================================================

def td_lambda_train(episodes=8000):

    V=defaultdict(float)
    epsilon=epsilon_start

    for _ in range(episodes):

        state=initial_board()
        eligibility=defaultdict(float)

        def epsilon_greedy(s):
            actions=available_moves(s)
            if random.random()<epsilon:
                return random.choice(actions)
            values=[V[make_move(s,a,X)] for a in actions]
            max_v=max(values)
            best=[a for a in actions
                  if V[make_move(s,a,X)]==max_v]
            return random.choice(best)

        while True:

            action=epsilon_greedy(state)
            next_state=make_move(state,action,X)
            winner=check_winner(next_state)

            if winner:
                if winner==X:
                    reward=WIN_REWARD
                elif winner==O:
                    reward=LOSS_REWARD
                else:
                    reward=DRAW_REWARD
                delta=reward-V[state]
            else:
                reward=0
                delta=reward+gamma*V[next_state]-V[state]

            eligibility[state]+=1

            for s in list(eligibility.keys()):
                V[s]+=alpha*delta*eligibility[s]
                eligibility[s]*=gamma*lam

            if winner: break

            next_state2=make_move(next_state,
                                  random.choice(available_moves(next_state)),
                                  O)

            winner=check_winner(next_state2)

            if winner:
                reward=LOSS_REWARD if winner==O else DRAW_REWARD
                delta=reward-V[next_state]

                eligibility[next_state]+=1
                for s in list(eligibility.keys()):
                    V[s]+=alpha*delta*eligibility[s]
                    eligibility[s]*=gamma*lam
                break

            state=next_state2

        epsilon=max(epsilon_min,epsilon*epsilon_decay)

    return V


# ==========================================================
# PLAY 10 GAMES
# ==========================================================

def play_10_games(V):

    agent_wins=0
    your_wins=0
    draws=0

    for game in range(1,11):

        print(f"\n===== Game {game} =====")
        state=initial_board()

        print("You go FIRST (O)")
        print("0 | 1 | 2")
        print("3 | 4 | 5")
        print("6 | 7 | 8")

        print_board(state)

        while True:

            while True:
                try:
                    move=int(input("Your move (0-8): "))
                except ValueError:
                    print("Please enter a number from 0 to 8.")
                    continue
                if move in available_moves(state):
                    break
                
                
                print("Invalid. Try again.")

            state=make_move(state,move,O)
            print_board(state)

            winner=check_winner(state)
            if winner: break

            actions=available_moves(state)
            values=[V[make_move(state,a,X)] for a in actions]
            best_action=actions[values.index(max(values))]
            state=make_move(state,best_action,X)

            print("Agent Move:")
            print_board(state)

            winner=check_winner(state)
            if winner: break

        if winner==X:
            print("Agent Wins 🤖")
            agent_wins+=1
        elif winner==O:
            print("You Win 🎉")
            your_wins+=1
        else:
            print("Draw 🤝")
            draws+=1

    print("\n======= FINAL RESULTS =======")
    print("Agent Wins:",agent_wins)
    print("Your Wins:",your_wins)
    print("Draws:",draws)
    print("Agent Win Rate:",round(agent_wins/10,2))
    print("Your Win Rate:",round(your_wins/10,2))
    print("Draw Rate:",round(draws/10,2))


# ==========================================================
# RUN
# ==========================================================

print("Training TD(lambda)...\n")
V_td=td_lambda_train()

play_10_games(V_td)

# %%


""")

def p7():
    print("""
# %% [markdown]
# # Semi-Gradient TD with Linear Function Approximation
# 
# This notebook demonstrates **why semi-gradient methods work** when approximating value functions in Reinforcement Learning.
# 
# We consider a **continuous state space** and approximate the value function using **linear regression features**.
# 
# Value function approximation:
# 
# $$ V(s, w) = w^T x(s) $$
# 
# Semi-gradient TD update rule:
# 
# $$ w \leftarrow w + \alpha (r + \gamma V(s',w) - V(s,w)) x(s) $$
# 
# Key idea: instead of storing values for every state, we **learn parameters (weights)** that generalize across states.

# %% [markdown]
# ## Step 1: Create a Simple Continuous Environment
# 
# We create a simple 1D random walk with continuous states between **-1 and 1**.

# %%
import numpy as np

class ContinuousRandomWalk:
    def __init__(self):
        self.state = 0.0

    def reset(self):
        self.state = np.random.uniform(-0.5,0.5)
        return self.state

    def step(self):
        move = np.random.uniform(-0.1,0.1)
        self.state += move

        reward = 0
        done = False

        if self.state >= 1:
            reward = 1
            done = True

        if self.state <= -1:
            reward = -1
            done = True

        return self.state, reward, done

# %% [markdown]
# ## Step 2: Linear Feature Representation
# 
# We convert a scalar state into a **feature vector**:
# 
# $$ x(s) = [1, s, s^2] $$
# 
# The bias term allows the model to shift the value function.

# %%
def features(s):
    return np.array([1, s, s**2])

# %% [markdown]
# ## Step 3: Initialize Parameters

# %%
alpha = 0.05
gamma = 0.9
episodes = 200

w = np.zeros(3)

# %% [markdown]
# ## Step 4: Semi‑Gradient TD Learning

# %%
env = ContinuousRandomWalk()

def value(s):
    return np.dot(w, features(s))

history = []

for ep in range(episodes):
    s = env.reset()
    done = False

    while not done:
        s_next, r, done = env.step()

        v = value(s)
        v_next = value(s_next)

        delta = r + gamma * v_next - v

        w[:] = w + alpha * delta * features(s)

        s = s_next

    history.append(np.linalg.norm(w))

w

# %% [markdown]
# ## Step 5: Observe Parameter Convergence

# %%
import matplotlib.pyplot as plt

plt.figure()
plt.plot(history)
plt.xlabel("Episode")
plt.ylabel("Weight Magnitude")
plt.title("Learning Progress")
plt.show()

# %% [markdown]
# ## Step 6: Visualize the Learned Value Function

# %%
states = np.linspace(-1,1,200)
values = [value(s) for s in states]

plt.figure()
plt.plot(states, values)
plt.xlabel("State")
plt.ylabel("Estimated Value")
plt.title("Approximated Value Function")
plt.show()

# %% [markdown]
# ## Key Takeaways
# 
# 1. Semi‑gradient methods update parameters using the **TD error**.
# 2. The gradient is taken with respect to **V(s,w)** only.
# 3. This allows learning even when the **state space is continuous**.
# 4. Linear function approximation is the simplest example of **value function approximation**.
# 
# This idea forms the basis for **Deep Q Networks and Actor‑Critic methods**, where the linear model is replaced by neural networks.


""")
    
    
    
    
def p8():
    print("""
          # %%
# Import required libraries
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal


# --------------------------
# Custom Environment
# --------------------------
# This environment simulates a simple drone trying to hover at a target height.
# The agent controls the thrust (continuous value) to keep the drone stable.
class DroneHoverEnv(gym.Env):

    def __init__(self):

        # Action space (continuous)
        # The agent can apply thrust between -1 and 1
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(1,),
            dtype=np.float32
        )

        # Observation space (state)
        # State = [height, velocity]
        self.observation_space = spaces.Box(
            low=np.array([-20, -5]),
            high=np.array([20, 5]),
            dtype=np.float32
        )

        # Target height the drone should maintain
        self.target_height = 5

        # Gravity constantly pulls the drone downward
        self.gravity = -0.05

        # Maximum steps allowed in one episode
        self.max_steps = 200


    # Reset the environment at the beginning of each episode
    def reset(self, seed=None, options=None):

        # Random starting height between 0 and 1
        self.height = np.random.uniform(0, 1)

        # Initial velocity
        self.velocity = 0

        # Reset step counter
        self.steps = 0

        # Current state
        state = np.array([self.height, self.velocity], dtype=np.float32)

        return state, {}


    # Executes one step in the environment
    def step(self, action):

        # Ensure action stays within valid range
        action = np.clip(action, -1, 1)

        # Extract thrust value
        thrust = action[0]

        # Update velocity based on thrust and gravity
        self.velocity += thrust + self.gravity

        # Limit velocity to prevent instability
        self.velocity = np.clip(self.velocity, -3, 3)

        # Update height based on velocity
        self.height += self.velocity

        # Increment step counter
        self.steps += 1

        # Distance from the target height
        distance = abs(self.height - self.target_height)

        # Reward is negative distance (closer = better)
        reward = -distance

        # Check termination conditions
        done = False

        # Episode ends if drone goes out of bounds
        if self.height < 0 or self.height > 20:
            done = True

        # Episode ends if max steps reached
        if self.steps >= self.max_steps:
            done = True

        # New state after action
        state = np.array([self.height, self.velocity], dtype=np.float32)

        return state, reward, done, False, {}


# --------------------------
# Actor Network
# --------------------------
# Actor network decides what action to take given a state
class Actor(nn.Module):

    def __init__(self, state_dim, action_dim):

        super().__init__()

        # Neural network layers
        self.fc = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU()
        )

        # Output mean of action distribution
        self.mean = nn.Linear(64, action_dim)

        # Learnable standard deviation (controls exploration)
        self.log_std = nn.Parameter(torch.zeros(action_dim))


    def forward(self, state):

        # Pass state through network
        x = self.fc(state)

        # Compute mean action
        mean = self.mean(x)

        # Convert log_std → std
        std = torch.exp(self.log_std)

        return mean, std


# --------------------------
# Critic Network
# --------------------------
# Critic evaluates how good a state is (value function V(s))
class Critic(nn.Module):

    def __init__(self, state_dim):

        super().__init__()

        # Neural network for value estimation
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, state):

        # Output estimated value of the state
        return self.net(state)


# --------------------------
# Setup
# --------------------------

# Create environment
env = DroneHoverEnv()

# Get state and action dimensions
state_dim = env.observation_space.shape[0]
action_dim = env.action_space.shape[0]

# Initialize Actor and Critic networks
actor = Actor(state_dim, action_dim)
critic = Critic(state_dim)

# Optimizers for both networks
actor_optimizer = optim.Adam(actor.parameters(), lr=0.0005)
critic_optimizer = optim.Adam(critic.parameters(), lr=0.001)

# Discount factor (importance of future rewards)
gamma = 0.99

# Number of training episodes
episodes = 400


# --------------------------
# Training Loop
# --------------------------
for ep in range(episodes):

    # Reset environment
    state, _ = env.reset()

    # Convert state to PyTorch tensor
    state = torch.FloatTensor(state)

    done = False
    total_reward = 0

    while not done:

        # Actor predicts action distribution
        mean, std = actor(state)

        # Create Gaussian distribution
        dist = Normal(mean, std)

        # Sample an action from distribution
        action = dist.sample()

        # Log probability (used for policy gradient)
        log_prob = dist.log_prob(action)

        # Convert action to numpy for environment
        action_np = action.detach().numpy()

        # Apply action in environment
        next_state, reward, done, _, _ = env.step(action_np)

        # Convert next state to tensor
        next_state = torch.FloatTensor(next_state)

        # Critic estimates value of current and next states
        value = critic(state)
        next_value = critic(next_state)

        # Compute target value (TD target)
        target = reward + gamma * next_value * (1 - int(done))

        # Advantage = how much better the action was
        advantage = target - value


        # --------------------------
        # Critic Update
        # --------------------------

        # Critic tries to minimize prediction error
        critic_loss = advantage.pow(2).mean()

        critic_optimizer.zero_grad()
        critic_loss.backward()
        critic_optimizer.step()


        # --------------------------
        # Actor Update
        # --------------------------

        # Actor improves policy using advantage
        actor_loss = -(log_prob * advantage.detach()).mean()

        actor_optimizer.zero_grad()
        actor_loss.backward()
        actor_optimizer.step()


        # Move to next state
        state = next_state

        # Track episode reward
        total_reward += reward


    # Print episode result
    print(f"Episode {ep} Reward: {total_reward:.2f}")



          
          
          
          
          """)
def p9():
    print("""
          
          
          
          
          # %%
import gymnasium as gym
import math
import random
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple, deque
from itertools import count

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

env = gym.make("CartPole-v1")

# set up matplotlib
is_ipython = 'inline' in matplotlib.get_backend()
if is_ipython:
    from IPython import display

plt.ion()

# if GPU is to be used
device = torch.device(
    "cuda" if torch.cuda.is_available() else
    "mps" if torch.backends.mps.is_available() else
    "cpu"
)

# %%
Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))


class ReplayMemory(object):

    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)

    def push(self, *args):
        '''Save a transition'''
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)

# %%
class DQN(nn.Module):

    def __init__(self, n_observations, n_actions):
        super(DQN, self).__init__()
        self.layer1 = nn.Linear(n_observations, 128)
        self.layer2 = nn.Linear(128, 128)
        self.layer3 = nn.Linear(128, n_actions)

    # Called with either one element to determine next action, or a batch
    # during optimization. Returns tensor([[left0exp,right0exp]...]).
    def forward(self, x):
        x = F.relu(self.layer1(x))
        x = F.relu(self.layer2(x))
        return self.layer3(x)

# %%
# BATCH_SIZE is the number of transitions sampled from the replay buffer
# GAMMA is the discount factor as mentioned in the previous section
# EPS_START is the starting value of epsilon
# EPS_END is the final value of epsilon
# EPS_DECAY controls the rate of exponential decay of epsilon, higher means a slower decay
# TAU is the update rate of the target network
# LR is the learning rate of the ``AdamW`` optimizer
BATCH_SIZE = 128
GAMMA = 0.99
EPS_START = 0.9
EPS_END = 0.05
EPS_DECAY = 1000
TAU = 0.005
LR = 1e-4

# Get number of actions from gym action space
n_actions = env.action_space.n
# Get the number of state observations
state, info = env.reset()
n_observations = len(state)

print("Size of Input")
print(n_observations)
print("Size of output")
print(n_actions)

policy_net = DQN(n_observations, n_actions).to(device)
target_net = DQN(n_observations, n_actions).to(device)
target_net.load_state_dict(policy_net.state_dict())

optimizer = optim.AdamW(policy_net.parameters(), lr=LR, amsgrad=True)
memory = ReplayMemory(10000)


steps_done = 0


def select_action(state):
    global steps_done
    sample = random.random()
    eps_threshold = EPS_END + (EPS_START - EPS_END) * \
        math.exp(-1. * steps_done / EPS_DECAY)
    steps_done += 1
    if sample > eps_threshold:
        with torch.no_grad():
            # t.max(1) will return the largest column value of each row.
            # second column on max result is index of where max element was
            # found, so we pick action with the larger expected reward.
            return policy_net(state).max(1).indices.view(1, 1)
    else:
        return torch.tensor([[env.action_space.sample()]], device=device, dtype=torch.long)


episode_durations = []


def plot_durations(show_result=False):
    plt.figure(1)
    durations_t = torch.tensor(episode_durations, dtype=torch.float)
    if show_result:
        plt.title('Result')
    else:
        plt.clf()
        plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(durations_t.numpy())
    # Take 100 episode averages and plot them too
    if len(durations_t) >= 100:
        means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
        means = torch.cat((torch.zeros(99), means))
        plt.plot(means.numpy())

    plt.pause(0.001)  # pause a bit so that plots are updated
    if is_ipython:
        if not show_result:
            display.display(plt.gcf())
            display.clear_output(wait=True)
        else:
            display.display(plt.gcf())

# %%
def optimize_model():
    if len(memory) < BATCH_SIZE:
        return
    transitions = memory.sample(BATCH_SIZE)
    # Transpose the batch (see https://stackoverflow.com/a/19343/3343043 for
    # detailed explanation). This converts batch-array of Transitions
    # to Transition of batch-arrays.
    batch = Transition(*zip(*transitions))

    # Compute a mask of non-final states and concatenate the batch elements
    # (a final state would've been the one after which simulation ended)
    non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                          batch.next_state)), device=device, dtype=torch.bool)
    non_final_next_states = torch.cat([s for s in batch.next_state
                                                if s is not None])
    state_batch = torch.cat(batch.state)
    action_batch = torch.cat(batch.action)
    reward_batch = torch.cat(batch.reward)

    # Compute Q(s_t, a) - the model computes Q(s_t), then we select the
    # columns of actions taken. These are the actions which would've been taken
    # for each batch state according to policy_net
    state_action_values = policy_net(state_batch).gather(1, action_batch)

    # Compute V(s_{t+1}) for all next states.
    # Expected values of actions for non_final_next_states are computed based
    # on the "older" target_net; selecting their best reward with max(1).values
    # This is merged based on the mask, such that we'll have either the expected
    # state value or 0 in case the state was final.
    next_state_values = torch.zeros(BATCH_SIZE, device=device)
    with torch.no_grad():
        next_state_values[non_final_mask] = target_net(non_final_next_states).max(1).values
    # Compute the expected Q values
    expected_state_action_values = (next_state_values * GAMMA) + reward_batch

    # Compute Huber loss
    criterion = nn.SmoothL1Loss()
    loss = criterion(state_action_values, expected_state_action_values.unsqueeze(1))

    # Optimize the model
    optimizer.zero_grad()
    loss.backward()
    # In-place gradient clipping
    torch.nn.utils.clip_grad_value_(policy_net.parameters(), 100)
    optimizer.step()

# %%
if torch.cuda.is_available() or torch.backends.mps.is_available():
    num_episodes = 600
else:
    num_episodes = 50

for i_episode in range(num_episodes):
    # Initialize the environment and get its state
    state, info = env.reset()
    state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
    for t in count():
        action = select_action(state)
        observation, reward, terminated, truncated, _ = env.step(action.item())
        reward = torch.tensor([reward], device=device)
        done = terminated or truncated

        if terminated:
            next_state = None
        else:
            next_state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

        # Store the transition in memory
        memory.push(state, action, next_state, reward)

        # Move to the next state
        state = next_state

        # Perform one step of the optimization (on the policy network)
        optimize_model()

        # Soft update of the target network's weights
        # θ′ ← τ θ + (1 −τ )θ′
        target_net_state_dict = target_net.state_dict()
        policy_net_state_dict = policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key]*TAU + target_net_state_dict[key]*(1-TAU)
        target_net.load_state_dict(target_net_state_dict)

        if done:
            episode_durations.append(t + 1)
            plot_durations()
            break

print('Complete')
plot_durations(show_result=True)
plt.ioff()
plt.show()

# %%
if torch.cuda.is_available() or torch.backends.mps.is_available():
    num_episodes = 600
else:
    num_episodes = 50

# Create a wrapped environment for video recording
# It will save videos in the 'videos' directory
env_monitor = gym.wrappers.RecordVideo(gym.make("CartPole-v1", render_mode="rgb_array"), 'videos')

for i_episode in range(num_episodes):
    # Initialize the environment and get its state
    state, info = env_monitor.reset()
    state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
    for t in count():
        action = select_action(state)
        observation, reward, terminated, truncated, _ = env_monitor.step(action.item())
        reward = torch.tensor([reward], device=device)
        done = terminated or truncated

        if terminated:
            next_state = None
        else:
            next_state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

        # Store the transition in memory
        memory.push(state, action, next_state, reward)

        # Move to the next state
        state = next_state

        # Perform one step of the optimization (on the policy network)
        optimize_model()

        # Soft update of the target network's weights
        # θ′ ← τ θ + (1 −τ )θ′
        target_net_state_dict = target_net.state_dict()
        policy_net_state_dict = policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key]*TAU + target_net_state_dict[key]*(1-TAU)
        target_net.load_state_dict(target_net_state_dict)

        if done:
            episode_durations.append(t + 1)
            plot_durations()
            break

print('Complete')
plot_durations(show_result=True)
plt.ioff()
plt.show()

# Close the wrapped environment
env_monitor.close()

# %%
import glob
import io
import base64
from IPython.display import HTML
from IPython import display as ipythondisplay

# Function to display recorded videos in Colab
def show_videos():
    mp4list = glob.glob('videos/*.mp4')
    if len(mp4list) > 0:
        for mp4 in mp4list:
            video = io.open(mp4, 'r+b').read()
            encoded = base64.b64encode(video).decode()
            ipythondisplay.display(HTML(data=f'''<video alt="test" autoplay
                loop controls style="height: 400px;">
                <source src="data:video/mp4;base64,{encoded}" type="video/mp4" />
             </video>'''))
    else:
        print("Could not find video files.")


def evaluate_model(policy_net, num_eval_episodes=5):
    print(f"\nEvaluating model for {num_eval_episodes} episodes...")
    eval_durations = []
    eval_env = gym.make("CartPole-v1", render_mode="rgb_array")
    eval_env_monitor = gym.wrappers.RecordVideo(eval_env, 'eval_videos')

    for i_episode in range(num_eval_episodes):
        state, info = eval_env_monitor.reset()
        state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
        for t in count():
            # Select action deterministically using the policy network
            with torch.no_grad():
                action = policy_net(state).max(1).indices.view(1, 1)

            observation, reward, terminated, truncated, _ = eval_env_monitor.step(action.item())
            done = terminated or truncated

            if done:
                eval_durations.append(t + 1)
                print(f"Episode {i_episode + 1} finished after {t + 1} timesteps.")
                break
            state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

    eval_env_monitor.close()
    eval_env.close()
    print("Evaluation Complete.")
    print(f"Average duration over {num_eval_episodes} episodes: {sum(eval_durations) / num_eval_episodes:.2f}")

    # Plot evaluation durations
    plt.figure(2)
    plt.clf()
    plt.title('Evaluation Durations')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(eval_durations)
    plt.show()

    show_videos()

# Run the evaluation
evaluate_model(policy_net, num_eval_episodes=10)




    """)