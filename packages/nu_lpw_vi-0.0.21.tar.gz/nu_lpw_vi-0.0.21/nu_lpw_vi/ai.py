import os
from typing import Optional
from openai import OpenAI


def aoi(prompt: str, api_key: Optional[str] = None) -> str:
    """
    Sends prompt to OpenAI and returns response
    """

    api_key = api_key or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError(
            "OPENAI_API_KEY is not set. "
            "In notebooks, set it in Python with: "
            "import os; os.environ['OPENAI_API_KEY'] = 'your_key'"
        )

    client_open_ai = OpenAI(api_key=api_key)

    response = client_open_ai.chat.completions.create(
        model="gpt-5-mini",
        messages=[
            {
                "role": "system",
                "content": "You are a coding assistant. Always return clean, correct, runnable code"
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
    )

    return response.choices[0].message.content



def ag(prompt: str, api_key: Optional[str] = None) -> str:
    """
    Sends prompt to Gemini and returns response
    """

    api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY or GOOGLE_API_KEY is not set. "
            "In notebooks, set it in Python with: "
            "import os; os.environ['GEMINI_API_KEY'] = 'your_key'"
        )

    try:
        from google import genai
        from google.genai import types
    except ImportError as exc:
        raise ImportError(
            "google-genai is not installed. Install it with: pip install google-genai"
        ) from exc

    client = genai.Client(api_key=api_key)
    response = client.models.generate_content(
        model="gemini-3-flash",
        contents=prompt,
        config=types.GenerateContentConfig(
            system_instruction="You are a coding assistant. Always return clean, correct, runnable code.",
            temperature=0.2,
        ),
    )

    if getattr(response, "text", None):
        return response.text

    raise RuntimeError("Gemini returned an empty response.")