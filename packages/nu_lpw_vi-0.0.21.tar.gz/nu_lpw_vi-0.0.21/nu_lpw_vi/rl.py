def doc():
  print(r"""
| Function | Description |
|:--------:|-------------|
| p1() | OpenAI Gym |
| p2() | maze environment |
| p3() | MDP, Bellman Optimality equations |
| p4() | policy
iteration and value iteration |
| p5() | Monte Carlo, evaluation and control |
| p6() | TD learning algorithm |
| p7() | linear regression and semi-gradient |
| p8() | actor-critic model |
| p9() | Deep Q-Network |
| p10() | Actor-Critic (A2C) algorithm |

""")
def p1():
    print(r"""
          
#!/usr/bin/env python
# coding: utf-8

# In[3]:


import gymnasium as gym
env_cartpole = gym.make('CartPole-v1')
print("Observation Space:", env_cartpole.observation_space)
print("Action Space:", env_cartpole.action_space)


# In[10]:


for i_episode in range(5):
    state, info = env_cartpole.reset()
    total_reward = 0
    steps = 0

    while True:
        # Take a random action
        action = env_cartpole.action_space.sample()
        print(action)
        state, reward, terminated, truncated, info = env_cartpole.step(action)
        print(state, reward, terminated, truncated, info)
        total_reward += reward
        steps += 1
        done = terminated or truncated

        if done:
            print(f'Episode {i_episode + 1}: Steps taken = {steps}, Total Reward = {total_reward}')
            break

env_cartpole.close()


# In[5]:


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from IPython.display import HTML, display
import PIL.Image


# In[7]:


# Create environment with rendering
env_render = gym.make('CartPole-v1', render_mode='rgb_array')

# Collect frames from one episode
frames = []
state, info = env_render.reset()
done = False
total_reward = 0

while not done:
    # Capture frame
    frame = env_render.render()
    frames.append(frame)

    # Take action
    action = env_render.action_space.sample()
    state, reward, terminated, truncated, info = env_render.step(action)
    total_reward += reward
    done = terminated or truncated

env_render.close()

print(f"Collected {len(frames)} frames")
print(f"Episode reward: {total_reward}")


# In[8]:


# Create animation from frames
fig, ax = plt.subplots(figsize=(6, 4))
ax.axis('off')

img = ax.imshow(frames[0])

def animate(frame_idx):
    img.set_array(frames[frame_idx])
    ax.set_title(f'Frame {frame_idx + 1}/{len(frames)}')
    return [img]

anim = FuncAnimation(fig, animate, frames=len(frames), interval=50, blit=True)

# Display the animation
plt.close()  # Prevent duplicate display
HTML(anim.to_jshtml())


# In[9]:


# Save as GIF
from PIL import Image

# Convert frames to PIL Images and save as GIF
pil_frames = [Image.fromarray(frame) for frame in frames]
pil_frames[0].save(
    'cartpole_episode.gif',
    save_all=True,
    append_images=pil_frames[1:],
    duration=50,
    loop=0
)

print("Saved animation as 'cartpole_episode.gif'")


""")
    
    
def p2():
    print("""
---------------------------Genetic Algorithm-------------------------
#include <bits/stdc++.h>
using namespace std;

int n;
int capacity;
vector<int> weight, value;

const int POP_SIZE = 10;
const int GENERATIONS = 200;

mt19937 rng(time(0));

vector<int> randomChromosome()
{
    vector<int> ch(n);
    for (int i = 0; i < n; i++)
    {
        ch[i] = rng() % 2;
    }
    return ch;
}

int fitness(const vector<int> &ch)
{
    int totalW = 0, totalV = 0;
    for (int i = 0; i < n; i++)
    {
        if (ch[i])
        {
            totalW += weight[i];
            totalV += value[i];
        }
    }
    if (totalW > capacity)
        return 0;
    return totalV;
}

vector<int> rouletteSelect(const vector<vector<int>> &population,
                           const vector<int> &fit)
{
    int sum = accumulate(fit.begin(), fit.end(), 0);

    if (sum == 0)
    {
        return population[rng() % POP_SIZE];
    }

    int r = rng() % sum;
    int curr = 0;
    for (int i = 0; i < POP_SIZE; i++)
    {
        curr += fit[i];
        if (curr > r)
        {
            return population[i];
        }
    }
    return population.back();
}

pair<vector<int>, vector<int>> crossover(const vector<int> &p1,
                                         const vector<int> &p2)
{
    vector<int> c1 = p1, c2 = p2;

    int point = rng() % n;

    for (int i = point; i < n; i++)
    {
        swap(c1[i], c2[i]);
    }

    return {c1, c2};
}

pair<vector<int>, vector<int>> kPointCrossover(const vector<int> &p1,
                                               const vector<int> &p2,
                                               int k)
{
    int n = p1.size();
    vector<int> c1 = p1, c2 = p2;

    if (k > 0)
    {
        k = min(k, n - 1);

        vector<int> points;
        unordered_set<int> used;

        while ((int)points.size() < k)
        {
            int pt = rng() % (n - 1) + 1;
            if (!used.count(pt))
            {
                used.insert(pt);
                points.push_back(pt);
            }
        }

        sort(points.begin(), points.end());

        bool takeFromP1 = true;
        int prev = 0;

        for (int cut : points)
        {
            for (int i = prev; i < cut; i++)
            {
                if (!takeFromP1)
                    swap(c1[i], c2[i]);
            }
            takeFromP1 = !takeFromP1;
            prev = cut;
        }

        for (int i = prev; i < n; i++)
        {
            if (!takeFromP1)
                swap(c1[i], c2[i]);
        }
    }

    return {c1, c2};
}

void mutateOneBit(vector<int> &ch)
{
    int idx = rng() % n;
    ch[idx] = 1 - ch[idx];
}

int main()
{
    cout << "Enter number of items: ";
    cin >> n;

    weight.resize(n);
    value.resize(n);

    cout << "Enter weights:\n";
    for (int i = 0; i < n; i++)
        cin >> weight[i];

    cout << "Enter values:\n";
    for (int i = 0; i < n; i++)
        cin >> value[i];

    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    vector<vector<int>> population;
    for (int i = 0; i < POP_SIZE; i++)
    {
        population.push_back(randomChromosome());
    }

    vector<int> bestEver;
    int bestFitness = 0;

    for (int gen = 0; gen < GENERATIONS; gen++)
    {
        vector<int> fit(POP_SIZE);
        for (int i = 0; i < POP_SIZE; i++)
        {
            fit[i] = fitness(population[i]);
            if (fit[i] > bestFitness)
            {
                bestFitness = fit[i];
                bestEver = population[i];
            }
        }

        vector<vector<int>> newPop;

        while ((int)newPop.size() < POP_SIZE)
        {
            vector<int> p1 = rouletteSelect(population, fit);
            vector<int> p2 = rouletteSelect(population, fit);

            auto [c1, c2] = crossover(p1, p2);

            mutateOneBit(c1);
            mutateOneBit(c2);

            newPop.push_back(c1);
            if ((int)newPop.size() < POP_SIZE)
                newPop.push_back(c2);
        }

        population = newPop;
    }

    cout << "\nBest solution found:\n";
    cout << "Chromosome: ";
    for (int b : bestEver)
        cout << b << " ";
    cout << "\nMaximum Value: " << bestFitness << "\n";

    int finalWeight = 0;
    for (int i = 0; i < n; i++)
    {
        if (bestEver[i])
            finalWeight += weight[i];
    }
    cout << "Total Weight: " << finalWeight << "\n";

    return 0;
}

""")
    
def p3():
    print("""
#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Import Gym to use the Blackjack environment (MDP simulator)
import gym

# Import random for weighted card drawing
import random

# Import the base Blackjack environment so we can extend it
from gym.envs.toy_text.blackjack import BlackjackEnv


# In[2]:


# =========================================================
# STEP 1: CREATE A WEIGHTED BLACKJACK ENVIRONMENT (MDP)
# =========================================================
class WeightedBlackjackEnv(BlackjackEnv):
    

    def draw_card(self):
        # Randomly choose a card value between 1 and 10
        card = random.choice([1,2,3,4,5,6,7,8,9,10])

        # Apply color weighting:
        # 2/3 probability -> black card (+value)
        # 1/3 probability -> red card (-value)
        if random.random() < 2/3:
            return card
        else:
            return -card


# In[3]:


# Create an instance of the weighted Blackjack environment
env = WeightedBlackjackEnv()


# In[4]:


# =========================================================
# STEP 2: EXPECTED VALUE FUNCTION (BELLMAN EXPECTATION)
# =========================================================
def expected_value(state, action, trials=100):
    

    total_reward = 0  # Accumulates rewards over trials

    # Repeat multiple times to approximate expectation
    for _ in range(trials):

        # Reset environment for each trial
        env.reset()

        # Manually set the player and dealer state
        # This fixes the current MDP state
        env.player = [state[0]]   # player_sum
        env.dealer = [state[1]]   # dealer's visible card

        # Take the given action (0 = Stick, 1 = Hit)
        _, reward, terminated, truncated, _ = env.step(action)

        # Combine termination signals (new Gym format)
        done = terminated or truncated

        # If the game ended, add the reward
        if done:
            total_reward += reward

    # Return average reward (expected value)
    return total_reward / trials



# In[5]:


# =========================================================
# STEP 3: OPTIMAL POLICY π*(s) USING BELLMAN OPTIMALITY
# =========================================================
def optimal_policy(state):
   

    # Compute expected reward if we HIT
    hit_value = expected_value(state, 1)

    # Compute expected reward if we STICK
    stick_value = expected_value(state, 0)

    # Print Bellman evaluation for clarity
    print("  Bellman Evaluation:")
    print(f"    Q(s, Hit)   ≈ {hit_value:.3f}")
    print(f"    Q(s, Stick) ≈ {stick_value:.3f}")

    # Choose the action with higher expected value
    if hit_value > stick_value:
        print("    → Optimal Action: HIT\n")
        return 1  # Hit
    else:
        print("    → Optimal Action: STICK\n")
        return 0  # Stick


# In[6]:


# =========================================================
# STEP 4: AGENT–ENVIRONMENT INTERACTION LOOP
# =========================================================
# This loop shows how the agent interacts with the MDP
# using the optimal policy derived above.
for i_episode in range(5):

    # Reset environment to start a new episode
    state = env.reset()

    print("\n================ NEW EPISODE ================")

    while True:

        # Print the current MDP state
        # State = (player_sum, dealer_card, usable_ace)
        print(f"MDP State s = {state}")

        # Select action using the optimal policy π*(s)
        action = optimal_policy(state)

        # Apply the action in the environment
        state, reward, terminated, truncated, _ = env.step(action)

        # Check if episode has ended
        done = terminated or truncated

        # If terminal state is reached, print outcome
        if done:
            print("Terminal State Reached")
            print(f"Reward r = {reward}")

            # Interpret reward
            if reward > 0:
                print("Outcome: WIN 🎉")
            elif reward < 0:
                print("Outcome: LOSS 😞")
            else:
                print("Outcome: DRAW 🤝")

            break


""")
    
def p4():
    print("""
# ------------------------------------------------------------
# INSTALL REQUIRED LIBRARIES
# ------------------------------------------------------------
# pygame         → Used for creating and visualizing the grid-world environment
# numpy          → Used for numerical operations and storing value/policy tables
# pillow (PIL)   → Used for loading and displaying saved images
# pyvirtualdisplay → Creates a virtual screen so Pygame can run in Google Colab

!pip install pygame numpy pillow pyvirtualdisplay

# ------------------------------------------------------------
# INSTALL XVFB (X Virtual Frame Buffer)
# ------------------------------------------------------------
# Required to run graphical applications (like Pygame)
# in a headless environment such as Google Colab

!apt-get update
!apt-get install -y xvfb

import numpy as np
import pygame
from PIL import Image
from pyvirtualdisplay import Display
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# SETUP VIRTUAL DISPLAY (needed to run Pygame in Google Colab)
# ------------------------------------------------------------
display = Display(visible=0, size=(800, 600))
display.start()

# ------------------------------------------------------------
# ENVIRONMENT (MDP) SETTINGS
# ------------------------------------------------------------

ROWS, COLS = 6, 6                  # Grid size → defines state space S
CELL_SIZE = 100                    # Size of each grid cell (for visualization)
SCREEN_WIDTH = COLS * CELL_SIZE
SCREEN_HEIGHT = ROWS * CELL_SIZE

DISCOUNT_FACTOR = 0.9              # γ (gamma) → discount factor in Bellman equation
THRESHOLD = 1e-4                   # Convergence threshold for Value Iteration

# ------------------------------------------------------------
# COLORS (for visualization only)
# ------------------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED   = (255, 0, 0)
BLUE  = (0, 0, 255)
GREY  = (200, 200, 200)

# ------------------------------------------------------------
# ACTION SPACE A
# Each action moves the agent in the grid:
# Left, Right, Up, Down
# ------------------------------------------------------------
ACTIONS = [(0, -1), (0, 1), (-1, 0), (1, 0)]

# ------------------------------------------------------------
# DEFINE REWARDS AND TERMINAL STATE
# ------------------------------------------------------------
reward_positions  = [(1, 1), (3, 2)]   # +1 reward states
penalty_positions = [(2, 0), (4, 4)]   # -1 penalty states
goal_position     = (5, 5)             # Terminal goal state (+10)
start_position    = (0, 0)             # Starting position

# ------------------------------------------------------------
# INITIALIZE MAZE (Reward Function R)
# ------------------------------------------------------------
maze = np.zeros((ROWS, COLS))          # Default reward = 0

for pos in reward_positions:
    maze[pos] = 1                      # Assign +1 rewards

for pos in penalty_positions:
    maze[pos] = -1                     # Assign -1 penalties

maze[goal_position] = 10               # Assign goal reward

# ------------------------------------------------------------
# INITIALIZE VALUE FUNCTION V(s)
# ------------------------------------------------------------
V = np.zeros((ROWS, COLS))             # Initial value of all states = 0

# ------------------------------------------------------------
# CHECK IF STATE IS INSIDE GRID
# ------------------------------------------------------------
def is_valid_state(state):
    x, y = state
    return 0 <= x < ROWS and 0 <= y < COLS

# ------------------------------------------------------------
# TRANSITION FUNCTION P(s'|s,a)
# Returns next state after taking an action
# If action leads outside grid → stay in same state
# ------------------------------------------------------------
def get_next_state(state, action):
    x, y = state
    dx, dy = action
    next_state = (x + dx, y + dy)
    return next_state if is_valid_state(next_state) else state

# ------------------------------------------------------------
# VALUE ITERATION ALGORITHM
# Implements Bellman Optimality Update:
#
# V(s) = max_a [ R(s,a,s') + γ * V(s') ]
#
# Iterates until values converge below threshold
# ------------------------------------------------------------
def value_iteration(V):
    while True:
        delta = 0                      # Tracks maximum change in V per iteration

        for x in range(ROWS):
            for y in range(COLS):
                state = (x, y)

                # Skip updating terminal (goal) state
                if state == goal_position:
                    continue

                action_values = []

                # Compute value for each possible action
                for action in ACTIONS:
                    next_state = get_next_state(state, action)
                    reward = maze[next_state]
                    value = reward + DISCOUNT_FACTOR * V[next_state]
                    action_values.append(value)

                # Select best action value (max over actions)
                best_value = max(action_values)

                # Track maximum update difference for convergence check
                delta = max(delta, abs(best_value - V[x, y]))

                # Update state value
                V[x, y] = best_value

        # Stop iteration if change is below threshold
        if delta < THRESHOLD:
            break

    return V

# ------------------------------------------------------------
# DRAW THE GRID AND DISPLAY COMPUTED STATE VALUES
# ------------------------------------------------------------
def draw_maze(screen, V):
    screen.fill(WHITE)
    font = pygame.font.SysFont(None, 28)

    for x in range(ROWS):
        for y in range(COLS):
            rect_x, rect_y = y * CELL_SIZE, x * CELL_SIZE

            # Draw grid cell
            pygame.draw.rect(screen, GREY, (rect_x, rect_y, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, BLACK, (rect_x, rect_y, CELL_SIZE, CELL_SIZE), 2)

            # Decide cell color and label based on type of state
            if (x, y) == start_position:
                color = (255, 255, 0)
                text = "Start"
            elif maze[x, y] == 1:
                color = GREEN
                text = "+1"
            elif maze[x, y] == -1:
                color = RED
                text = "-1"
            elif (x, y) == goal_position:
                color = BLUE
                text = "Goal"
            else:
                # Shade cell based on value function magnitude
                value_color = int(max(0, min(255, 255 - abs(V[x, y]) * 10)))
                color = (value_color, value_color, value_color)
                text = f"{int(V[x, y])}"

            # Fill cell with chosen color
            pygame.draw.rect(screen, color, (rect_x + 2, rect_y + 2, CELL_SIZE - 4, CELL_SIZE - 4))

            # Render text
            text_surface = font.render(text, True, BLACK)
            screen.blit(text_surface, (rect_x + 10, rect_y + 10))

    pygame.display.flip()

# ------------------------------------------------------------
# MAIN FUNCTION
# Runs Value Iteration and Displays Optimal Value Function
# ------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Optimal Value Function using Value Iteration")

    global V
    V = value_iteration(V)             # Compute optimal value function V*

    draw_maze(screen, V)               # Display results
    pygame.image.save(screen, "optimal_value_function.png")

    pygame.quit()

# Run program
main()

# ------------------------------------------------------------
# DISPLAY OUTPUT IMAGE INSIDE COLAB
# ------------------------------------------------------------
img = Image.open("optimal_value_function.png")
plt.imshow(img)
plt.axis('off')
plt.show()


import numpy as np
import pygame
from PIL import Image
from pyvirtualdisplay import Display
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# SETUP VIRTUAL DISPLAY (for running Pygame in Google Colab)
# ------------------------------------------------------------
display = Display(visible=0, size=(800, 600))
display.start()

# ------------------------------------------------------------
# ENVIRONMENT (MDP) SETTINGS
# ------------------------------------------------------------
ROWS, COLS = 6, 6                 # Grid size → defines state space S
CELL_SIZE = 100                   # Size of each grid cell (visualization)
SCREEN_WIDTH = COLS * CELL_SIZE
SCREEN_HEIGHT = ROWS * CELL_SIZE

DISCOUNT_FACTOR = 0.9             # γ (gamma) → discount factor in Bellman equations
THRESHOLD = 1e-4                  # Convergence threshold for policy evaluation

# ------------------------------------------------------------
# COLORS (used only for visualization)
# ------------------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED   = (255, 0, 0)
BLUE  = (0, 0, 255)
GREY  = (200, 200, 200)

# ------------------------------------------------------------
# ACTION SPACE A
# Each action moves agent in the grid:
# Left, Right, Up, Down
# ------------------------------------------------------------
ACTIONS = [(0, -1), (0, 1), (-1, 0), (1, 0)]

# Arrow directions for drawing policy arrows on grid
ARROWS = [(-20, 0), (20, 0), (0, -20), (0, 20)]

# ------------------------------------------------------------
# DEFINE REWARD STRUCTURE AND TERMINAL STATE
# ------------------------------------------------------------
reward_positions  = [(1, 1), (3, 2)]   # +1 reward states
penalty_positions = [(2, 0), (4, 4)]   # -1 penalty states
goal_position     = (5, 5)             # Terminal goal state (+10 reward)
start_position    = (0, 0)             # Starting state

# ------------------------------------------------------------
# INITIALIZE MAZE (Reward Function R)
# ------------------------------------------------------------
maze = np.zeros((ROWS, COLS))          # Default reward = 0

for pos in reward_positions:
    maze[pos] = 1                      # Assign +1 rewards

for pos in penalty_positions:
    maze[pos] = -1                     # Assign -1 penalties

maze[goal_position] = 10               # Assign goal reward

# ------------------------------------------------------------
# INITIALIZE POLICY π(s) AND VALUE FUNCTION V(s)
# ------------------------------------------------------------
policy = np.zeros((ROWS, COLS), dtype=int)  # Start with arbitrary policy (all zeros)
V = np.zeros((ROWS, COLS))                  # Initialize value function to zero

# ------------------------------------------------------------
# CHECK IF A STATE IS WITHIN GRID BOUNDARY
# ------------------------------------------------------------
def is_valid_state(state):
    x, y = state
    return 0 <= x < ROWS and 0 <= y < COLS

# ------------------------------------------------------------
# TRANSITION FUNCTION P(s'|s,a)
# Deterministic transition: moves agent unless boundary reached
# ------------------------------------------------------------
def get_next_state(state, action):
    x, y = state
    dx, dy = action
    next_state = (x + dx, y + dy)
    return next_state if is_valid_state(next_state) else state

# ------------------------------------------------------------
# POLICY EVALUATION STEP
# Computes Vπ(s) using Bellman Expectation Equation:
#
# V(s) = R(s,π(s),s') + γ * V(s')
#
# Iterates until values converge below threshold
# ------------------------------------------------------------
def policy_evaluation(V, policy):
    while True:
        delta = 0
        for x in range(ROWS):
            for y in range(COLS):
                state = (x, y)

                # Skip terminal state update
                if state == goal_position:
                    continue

                # Take action dictated by current policy
                action = policy[state]
                next_state = get_next_state(state, ACTIONS[action])

                reward = maze[next_state]
                value = reward + DISCOUNT_FACTOR * V[next_state]

                # Track maximum value change for convergence
                delta = max(delta, abs(value - V[x, y]))
                V[x, y] = value

        # Stop evaluation when change is very small
        if delta < THRESHOLD:
            break

    return V

# ------------------------------------------------------------
# POLICY IMPROVEMENT STEP
# Updates policy using Bellman Optimality Equation:
#
# π_new(s) = argmax_a [ R(s,a,s') + γ * V(s') ]
#
# Returns updated policy and stability flag
# ------------------------------------------------------------
def policy_improvement(V, policy):
    policy_stable = True

    for x in range(ROWS):
        for y in range(COLS):
            state = (x, y)

            # Skip terminal state
            if state == goal_position:
                continue

            action_values = []

            # Compute action-value for each possible action
            for action in range(len(ACTIONS)):
                next_state = get_next_state(state, ACTIONS[action])
                reward = maze[next_state]
                value = reward + DISCOUNT_FACTOR * V[next_state]
                action_values.append(value)

            # Select best action
            best_action = np.argmax(action_values)

            # Check if policy changed
            if best_action != policy[x, y]:
                policy_stable = False

            policy[x, y] = best_action

    return policy, policy_stable

# ------------------------------------------------------------
# POLICY ITERATION ALGORITHM
# Alternates between policy evaluation and improvement
# until policy becomes stable (optimal)
# ------------------------------------------------------------
def policy_iteration():
    global V, policy

    while True:
        V = policy_evaluation(V, policy)          # Evaluate current policy
        policy, stable = policy_improvement(V, policy)  # Improve policy

        if stable:                               # Stop if optimal policy reached
            break

    return policy, V

# ------------------------------------------------------------
# FIND OPTIMAL PATH FROM START TO GOAL USING FINAL POLICY
# ------------------------------------------------------------
def find_optimal_path(policy):
    path = []
    state = start_position

    while state != goal_position:
        path.append(state)
        action = ACTIONS[policy[state]]
        state = get_next_state(state, action)

    path.append(goal_position)
    return path

# ------------------------------------------------------------
# DRAW ARROWS REPRESENTING POLICY ACTIONS
# ------------------------------------------------------------
def draw_arrow(screen, pos, direction):
    x, y = pos
    start_x = y * CELL_SIZE + CELL_SIZE // 2
    start_y = x * CELL_SIZE + CELL_SIZE // 2
    dx, dy = direction
    end_x = start_x + dx
    end_y = start_y + dy

    pygame.draw.line(screen, BLACK, (start_x, start_y), (end_x, end_y), 4)
    pygame.draw.circle(screen, BLACK, (end_x, end_y), 6)

# ------------------------------------------------------------
# DRAW GRID WORLD WITH REWARDS, START, GOAL AND POLICY ARROWS
# ------------------------------------------------------------
def draw_maze(screen, policy, optimal_path):
    screen.fill(WHITE)
    font = pygame.font.SysFont(None, 28)

    for x in range(ROWS):
        for y in range(COLS):
            rect_x, rect_y = y * CELL_SIZE, x * CELL_SIZE

            # Draw grid cell border
            pygame.draw.rect(screen, GREY, (rect_x, rect_y, CELL_SIZE, CELL_SIZE))
            pygame.draw.rect(screen, BLACK, (rect_x, rect_y, CELL_SIZE, CELL_SIZE), 2)

            # Color special states
            if (x, y) == start_position:
                color = (255, 255, 0)  # Start state
                text = "Start"
            elif (x, y) == goal_position:
                color = BLUE           # Goal state
                text = "Goal"
            elif maze[x, y] == 1:
                color = GREEN          # Reward state
                text = "+1"
            elif maze[x, y] == -1:
                color = RED            # Penalty state
                text = "-1"
            else:
                color = WHITE           # Normal state
                text = ""

            pygame.draw.rect(screen, color, (rect_x + 2, rect_y + 2, CELL_SIZE - 4, CELL_SIZE - 4))
            text_surface = font.render(text, True, BLACK)
            screen.blit(text_surface, (rect_x + 10, rect_y + 10))

            # Draw policy arrow (except in terminal state)
            if (x, y) != goal_position:
                action = policy[x, y]
                arrow_dir = ARROWS[action]
                draw_arrow(screen, (x, y), arrow_dir)

    pygame.display.flip()

# ------------------------------------------------------------
# MAIN FUNCTION
# Runs Policy Iteration and Displays Optimal Policy
# ------------------------------------------------------------
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Maze Game with Policy Iteration")

    global V, policy
    policy, V = policy_iteration()     # Compute optimal policy π* and value V*

    optimal_path = find_optimal_path(policy)  # (Optional) compute path from start to goal

    draw_maze(screen, policy, optimal_path)   # Display policy arrows
    pygame.image.save(screen, "maze_optimal_policy.png")

    pygame.quit()

# Run program
main()

# ------------------------------------------------------------
# DISPLAY OUTPUT IMAGE INSIDE COLAB
# ------------------------------------------------------------
img = Image.open("maze_optimal_policy.png")
plt.imshow(img)
plt.axis('off')
plt.show()


# !apt-get install -y xvfb python-opengl
# !pip install pygame
# !xvfb-run -s "-screen 0 1024x768x24" python your_script.py

# from pyvirtualdisplay import Display
# display = Display(visible=0, size=(1024,768))
# display.start()


# your pygame code here
# main()


# from PIL import Image
# import matplotlib.pyplot as plt

# img = Image.open("maze_optimal_policy.png")
# plt.imshow(img)
# plt.axis('off')


""")
    
def p5():
    print("""
#!/usr/bin/env python
# coding: utf-8

# In[1]:


# ==========================================================
# Monte Carlo Reinforcement Learning for Tic-Tac-Toe
# WITH VISUAL OUTPUT AND VISUALIZATION
#
# This program implements:
# 1. Monte Carlo First-Visit Control
# 2. Episodic learning via self-play
# 3. Policy improvement using epsilon-greedy strategy
# 4. Visualization of training performance
#
# Author: RL Teaching Version
# ==========================================================

import random
from collections import defaultdict
import matplotlib.pyplot as plt

# ------------------------------
# Environment Setup
# ------------------------------

# State representation:
# Board is represented as tuple of length 9:
# index positions:
#
# 0 | 1 | 2
# ---------
# 3 | 4 | 5
# ---------
# 6 | 7 | 8

EMPTY = 0       # empty cell
X = 1           # RL Agent (learning player)
O = -1          # Opponent (random policy)

# Reward definition (terminal rewards)
WIN_REWARD = 1
LOSS_REWARD = -1
DRAW_REWARD = 0

# Create initial empty board
def initial_board():
    # tuple used because it is hashable (needed for dictionary keys)
    return tuple([EMPTY]*9)

# Return list of available actions (empty positions)
def available_moves(state):
    return [i for i,v in enumerate(state) if v == EMPTY]

# Apply an action and return new state
def make_move(state, action, player):
    # convert tuple to list to modify
    s = list(state)
    s[action] = player
    return tuple(s)

# Check if game has reached terminal state
def check_winner(state):

    # All winning combinations
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]

    # Check sums
    for a,b,c in wins:
        total = state[a]+state[b]+state[c]
        if total == 3:
            return X      # Agent wins
        if total == -3:
            return O      # Opponent wins

    # If no empty spaces left -> draw
    if EMPTY not in state:
        return "DRAW"

    return None   # game continues

# ------------------------------
# Monte Carlo RL Storage
# ------------------------------

# Q(s,a) = expected return for taking action a in state s
Q = defaultdict(float)

# Stores all returns observed for (state,action)
# Used to compute average return (Monte Carlo estimate)
Returns = defaultdict(list)

# Exploration probability (epsilon-greedy)
epsilon = 0.1

# Statistics for visualization
win_list = []
loss_list = []
draw_list = []

# ------------------------------
# Policy: Epsilon-Greedy
# ------------------------------

def epsilon_greedy(state):

    actions = available_moves(state)

    # Exploration: choose random action with probability epsilon
    if random.random() < epsilon:
        return random.choice(actions)

    # Exploitation: choose best action according to learned Q-values
    qvals = [Q[(state,a)] for a in actions]
    max_q = max(qvals)

    # multiple actions may have same value
    best_actions = [a for a in actions if Q[(state,a)] == max_q]

    return random.choice(best_actions)

# ------------------------------
# Episode Simulation (Self-Play)
# ------------------------------

def play_episode():

    # Each episode is a full game from start to terminal state
    state = initial_board()

    # store visited (state,action) pairs
    episode = []

    while True:

        # ---- Agent Move ----
        action = epsilon_greedy(state)

        next_state = make_move(state, action, X)

        # Save experience
        episode.append((state, action))

        winner = check_winner(next_state)

        if winner:
            # Episode ends
            return episode, winner

        # ---- Opponent Move (random policy) ----
        opp_moves = available_moves(next_state)

        if not opp_moves:
            return episode, "DRAW"

        opp_action = random.choice(opp_moves)

        next_state = make_move(next_state, opp_action, O)

        winner = check_winner(next_state)

        if winner:
            return episode, winner

        # Continue game
        state = next_state

# ------------------------------
# Training using Monte Carlo
# ------------------------------

def train(episodes=50000):

    wins = 0
    losses = 0
    draws = 0

    # Loop over episodes
    for ep in range(episodes):

        # Generate full episode
        episode, result = play_episode()

        # Assign final return (G)
        if result == X:
            G = WIN_REWARD
            wins += 1
        elif result == O:
            G = LOSS_REWARD
            losses += 1
        else:
            G = DRAW_REWARD
            draws += 1

        # First-Visit Monte Carlo Update
        visited = set()

        for (state, action) in episode:

            if (state,action) not in visited:

                visited.add((state,action))

                # Store observed return
                Returns[(state,action)].append(G)

                # Update Q-value as average return
                Q[(state,action)] = sum(Returns[(state,action)]) / len(Returns[(state,action)])

        # Save statistics every 1000 episodes
        if (ep+1) % 1000 == 0:

            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)

            print(f"Episode {ep+1} | Wins={wins} Losses={losses} Draws={draws}")

            wins = losses = draws = 0

# ------------------------------
# Visualization of Training Progress
# ------------------------------

def plot_results():

    plt.figure()

    plt.plot(win_list, label="Wins")
    plt.plot(loss_list, label="Losses")
    plt.plot(draw_list, label="Draws")

    plt.title("Monte Carlo Learning Progress in Tic-Tac-Toe")
    plt.xlabel("Training Steps (x1000 episodes)")
    plt.ylabel("Count")

    plt.legend()
    plt.show()

# ------------------------------
# Display Learned Policy (Opening Move)
# ------------------------------

def show_best_opening():

    state = initial_board()

    actions = available_moves(state)

    print("\nLearned Q-values for opening moves:")

    for a in actions:
        print("Position", a, "Q =", Q[(state,a)])

    best = max(actions, key=lambda a: Q[(state,a)])

    print("\nBest opening move learned:", best)

# ------------------------------
# Main Execution
# ------------------------------

if __name__ == "__main__":

    print("Training Monte Carlo Tic-Tac-Toe Agent...\n")

    train(50000)

    show_best_opening()

    plot_results()


# In[2]:


# ==========================================================
# Monte Carlo Reinforcement Learning for Tic-Tac-Toe
# WITH VISUAL OUTPUT AND VISUALIZATION
#
# This program implements:
# 1. Monte Carlo First-Visit Control
# 2. Episodic learning via self-play
# 3. Policy improvement using epsilon-greedy strategy
# 4. Visualization of training performance
#
# Author: RL Teaching Version
# ==========================================================

import random
from collections import defaultdict
import matplotlib.pyplot as plt

# ------------------------------
# Environment Setup
# ------------------------------

# State representation:
# Board is represented as tuple of length 9:
# index positions:
#
# 0 | 1 | 2
# ---------
# 3 | 4 | 5
# ---------
# 6 | 7 | 8

EMPTY = 0       # empty cell
X = 1           # RL Agent (learning player)
O = -1          # Opponent (random policy)

# Reward definition (terminal rewards)
WIN_REWARD = 1
LOSS_REWARD = -1
DRAW_REWARD = 0

# Create initial empty board
def initial_board():
    # tuple used because it is hashable (needed for dictionary keys)
    return tuple([EMPTY]*9)

# Return list of available actions (empty positions)
def available_moves(state):
    return [i for i,v in enumerate(state) if v == EMPTY]

# Apply an action and return new state
def make_move(state, action, player):
    # convert tuple to list to modify
    s = list(state)
    s[action] = player
    return tuple(s)

# Check if game has reached terminal state
def check_winner(state):

    # All winning combinations
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]

    # Check sums
    for a,b,c in wins:
        total = state[a]+state[b]+state[c]
        if total == 3:
            return X      # Agent wins
        if total == -3:
            return O      # Opponent wins

    # If no empty spaces left -> draw
    if EMPTY not in state:
        return "DRAW"

    return None   # game continues

# ------------------------------
# Monte Carlo RL Storage
# ------------------------------

# Q(s,a) = expected return for taking action a in state s
Q = defaultdict(float)

# Stores all returns observed for (state,action)
# Used to compute average return (Monte Carlo estimate)
Returns = defaultdict(list)

# Exploration probability (epsilon-greedy)
epsilon = 0.1

# Statistics for visualization
win_list = []
loss_list = []
draw_list = []

# ------------------------------
# Policy: Epsilon-Greedy
# ------------------------------

def epsilon_greedy(state):

    actions = available_moves(state)

    # Exploration: choose random action with probability epsilon
    if random.random() < epsilon:
        return random.choice(actions)

    # Exploitation: choose best action according to learned Q-values
    qvals = [Q[(state,a)] for a in actions]
    max_q = max(qvals)

    # multiple actions may have same value
    best_actions = [a for a in actions if Q[(state,a)] == max_q]

    return random.choice(best_actions)

# ------------------------------
# Episode Simulation (Self-Play)
# ------------------------------

def play_episode():

    # Each episode is a full game from start to terminal state
    state = initial_board()

    # store visited (state,action) pairs
    episode = []

    while True:

        # ---- Agent Move ----
        action = epsilon_greedy(state)

        next_state = make_move(state, action, X)

        # Save experience
        episode.append((state, action))

        winner = check_winner(next_state)

        if winner:
            # Episode ends
            return episode, winner

        # ---- Opponent Move (random policy) ----
        opp_moves = available_moves(next_state)

        if not opp_moves:
            return episode, "DRAW"

        opp_action = random.choice(opp_moves)

        next_state = make_move(next_state, opp_action, O)

        winner = check_winner(next_state)

        if winner:
            return episode, winner

        # Continue game
        state = next_state

# ------------------------------
# Training using Monte Carlo
# ------------------------------

def train(episodes=50000):

    wins = 0
    losses = 0
    draws = 0

    for ep in range(episodes):

        episode, result = play_episode()

        if result == X:
            G = WIN_REWARD
            wins += 1
        elif result == O:
            G = LOSS_REWARD
            losses += 1
        else:
            G = DRAW_REWARD
            draws += 1

        # ✅ Every-Visit Monte Carlo Update
        # No `visited` set — every occurrence of (state, action)
        # in the episode contributes a return to the average.
        for (state, action) in episode:

            Returns[(state, action)].append(G)
            Q[(state, action)] = sum(Returns[(state, action)]) / len(Returns[(state, action)])

        if (ep + 1) % 1000 == 0:

            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)

            print(f"Episode {ep+1} | Wins={wins} Losses={losses} Draws={draws}")

            wins = losses = draws = 0
# ------------------------------
# Visualization of Training Progress
# ------------------------------

def plot_results():

    plt.figure()

    plt.plot(win_list, label="Wins")
    plt.plot(loss_list, label="Losses")
    plt.plot(draw_list, label="Draws")

    plt.title("Monte Carlo Learning Progress in Tic-Tac-Toe")
    plt.xlabel("Training Steps (x1000 episodes)")
    plt.ylabel("Count")

    plt.legend()
    plt.show()

# ------------------------------
# Display Learned Policy (Opening Move)
# ------------------------------

def show_best_opening():

    state = initial_board()

    actions = available_moves(state)

    print("\nLearned Q-values for opening moves:")

    for a in actions:
        print("Position", a, "Q =", Q[(state,a)])

    best = max(actions, key=lambda a: Q[(state,a)])

    print("\nBest opening move learned:", best)

# ------------------------------
# Main Execution
# ------------------------------

if __name__ == "__main__":

    print("Training Monte Carlo Tic-Tac-Toe Agent...\n")

    train(50000)

    show_best_opening()

    plot_results()


""")
    
def p6():
    print("""
import random
from collections import defaultdict
import matplotlib.pyplot as plt

# ==========================================================
# ENVIRONMENT SETUP (Tic-Tac-Toe)
# ==========================================================

# We represent the board as a tuple of 9 values:
# 0 = empty
# 1 = X (our learning agent)
# -1 = O (random opponent)

EMPTY = 0
X = 1      # Agent
O = -1     # Random opponent

# Rewards used for reinforcement learning
WIN_REWARD = 1
LOSS_REWARD = -1
DRAW_REWARD = 0


def initial_board():
    
    return tuple([EMPTY]*9)


def available_moves(state):
    
    return [i for i, v in enumerate(state) if v == EMPTY]


def make_move(state, action, player):
    
    s = list(state)       # convert tuple to list (mutable)
    s[action] = player    # place move
    return tuple(s)       # convert back to tuple


def check_winner(state):
    

    # All possible winning combinations
    wins = [(0,1,2),(3,4,5),(6,7,8),
            (0,3,6),(1,4,7),(2,5,8),
            (0,4,8),(2,4,6)]

    # Check if any winning combination sums to 3 or -3
    for a,b,c in wins:
        total = state[a] + state[b] + state[c]
        if total == 3:
            return X
        if total == -3:
            return O

    # If no empty cells and no winner → Draw
    if EMPTY not in state:
        return "DRAW"

    return None


# ==========================================================
# HYPERPARAMETERS (Learning Settings)
# ==========================================================

alpha = 0.1      # Learning rate (how fast we update values)
gamma = 0.9      # Discount factor (importance of future rewards)
epsilon = 0.1    # Exploration rate (random action probability)


# ==========================================================
# STORAGE FOR LEARNING
# ==========================================================

# State-value function for TD(0)
V = defaultdict(float)

# Action-value function for SARSA and Q-learning
Q = defaultdict(float)

# Lists to store results for plotting
win_list = []
loss_list = []
draw_list = []


# ==========================================================
# EPSILON-GREEDY POLICY
# ==========================================================

def epsilon_greedy(state):
    
    actions = available_moves(state)

    # Exploration
    if random.random() < epsilon:
        return random.choice(actions)

    # Exploitation (choose action with highest Q value)
    qvals = [Q[(state, a)] for a in actions]
    max_q = max(qvals)

    # If multiple best actions exist → choose randomly among them
    best_actions = [a for a in actions if Q[(state, a)] == max_q]
    return random.choice(best_actions)


# ==========================================================
# 1. TD(0) — State Value Learning
# ==========================================================

def train_td0(episodes=50000):
    

    for ep in range(episodes):

        state = initial_board()

        while True:

            # Agent plays randomly (no policy learning here)
            action = random.choice(available_moves(state))
            next_state = make_move(state, action, X)

            winner = check_winner(next_state)

            # Assign reward
            if winner == X:
                reward = WIN_REWARD
            elif winner == O:
                reward = LOSS_REWARD
            elif winner == "DRAW":
                reward = DRAW_REWARD
            else:
                reward = 0

            # TD(0) UPDATE RULE:
            # V(s) = V(s) + alpha * [reward + gamma * V(s') - V(s)]
            V[state] = V[state] + alpha * (
                reward + gamma * V[next_state] - V[state]
            )

            if winner:
                break

            # Opponent plays randomly
            opp_action = random.choice(available_moves(next_state))
            next_state = make_move(next_state, opp_action, O)

            state = next_state


# ==========================================================
# 2. SARSA (On-Policy TD Control)
# ==========================================================

def train_sarsa(episodes=50000):
    

    wins = losses = draws = 0

    for ep in range(episodes):

        state = initial_board()
        action = epsilon_greedy(state)

        while True:

            next_state = make_move(state, action, X)
            winner = check_winner(next_state)

            # Assign reward
            if winner == X:
                reward = WIN_REWARD
            elif winner == O:
                reward = LOSS_REWARD
            elif winner == "DRAW":
                reward = DRAW_REWARD
            else:
                reward = 0

            # If game ends after agent move
            if winner:
                Q[(state, action)] += alpha * (
                    reward - Q[(state, action)]
                )
                break

            # Opponent plays randomly
            opp_action = random.choice(available_moves(next_state))
            next_state = make_move(next_state, opp_action, O)

            winner = check_winner(next_state)

            # If game ends after opponent move
            if winner:
                if winner == O:
                    reward = LOSS_REWARD
                    losses += 1
                else:
                    reward = DRAW_REWARD
                    draws += 1

                Q[(state, action)] += alpha * (
                    reward - Q[(state, action)]
                )
                break

            # Choose next action (important for SARSA)
            next_action = epsilon_greedy(next_state)

            # SARSA UPDATE RULE:
            # Q(s,a) = Q(s,a) + alpha * [reward + gamma * Q(s',a') - Q(s,a)]
            Q[(state, action)] += alpha * (
                reward + gamma * Q[(next_state, next_action)]
                - Q[(state, action)]
            )

            state = next_state
            action = next_action

        if winner == X:
            wins += 1

        # Store results every 1000 episodes
        if (ep+1) % 1000 == 0:
            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)
            print(f"SARSA Episode {ep+1} | W={wins} L={losses} D={draws}")
            wins = losses = draws = 0


# ==========================================================
# 3. Q-Learning (Off-Policy TD Control)
# ==========================================================

def train_q_learning(episodes=50000):
    

    wins = losses = draws = 0

    for ep in range(episodes):

        state = initial_board()

        while True:

            action = epsilon_greedy(state)
            next_state = make_move(state, action, X)

            winner = check_winner(next_state)

            # Assign reward
            if winner == X:
                reward = WIN_REWARD
            elif winner == O:
                reward = LOSS_REWARD
            elif winner == "DRAW":
                reward = DRAW_REWARD
            else:
                reward = 0

            if winner:
                Q[(state, action)] += alpha * (
                    reward - Q[(state, action)]
                )
                break

            # Opponent plays randomly
            opp_action = random.choice(available_moves(next_state))
            next_state = make_move(next_state, opp_action, O)

            winner = check_winner(next_state)

            if winner:
                if winner == O:
                    reward = LOSS_REWARD
                    losses += 1
                else:
                    reward = DRAW_REWARD
                    draws += 1

                Q[(state, action)] += alpha * (
                    reward - Q[(state, action)]
                )
                break

            # Get best possible next Q value
            next_actions = available_moves(next_state)
            max_q = max([Q[(next_state, a)] for a in next_actions])

            # Q-LEARNING UPDATE RULE:
            # Q(s,a) = Q(s,a) + alpha * [reward + gamma * max_a Q(s',a) - Q(s,a)]
            Q[(state, action)] += alpha * (
                reward + gamma * max_q - Q[(state, action)]
            )

            state = next_state

        if winner == X:
            wins += 1

        if (ep+1) % 1000 == 0:
            win_list.append(wins)
            loss_list.append(losses)
            draw_list.append(draws)
            print(f"Q-Learning Episode {ep+1} | W={wins} L={losses} D={draws}")
            wins = losses = draws = 0


# ==========================================================
# VISUALIZATION
# ==========================================================

def plot_results(title):
    
    plt.figure()
    plt.plot(win_list, label="Wins")
    plt.plot(loss_list, label="Losses")
    plt.plot(draw_list, label="Draws")
    plt.title(title)
    plt.xlabel("Training Steps (x1000)")
    plt.ylabel("Count")
    plt.legend()
    plt.show()


# ==========================================================
# MAIN PROGRAM
# ==========================================================

if __name__ == "__main__":

    print("Training using SARSA...")
    train_sarsa(50000)
    plot_results("SARSA Learning Progress")

    # Clear stats before next training
    win_list.clear()
    loss_list.clear()
    draw_list.clear()

    print("Training using Q-Learning...")
    train_q_learning(50000)
    plot_results("Q-Learning Progress")


# ==========================================================
# TD(λ) — WITH ELIGIBILITY TRACES
# ==========================================================

def train_td_lambda(episodes=50000, lam=0.7):
    

    global V

    for ep in range(episodes):

        state = initial_board()

        # Initialize eligibility traces
        E = defaultdict(float)

        while True:

            # Agent plays randomly (like TD(0))
            action = random.choice(available_moves(state))
            next_state = make_move(state, action, X)

            winner = check_winner(next_state)

            # Assign reward
            if winner == X:
                reward = WIN_REWARD
            elif winner == O:
                reward = LOSS_REWARD
            elif winner == "DRAW":
                reward = DRAW_REWARD
            else:
                reward = 0

            # TD ERROR (delta)
            delta = reward + gamma * V[next_state] - V[state]

            # Increase trace for current state
            E[state] += 1

            # Update ALL states using eligibility traces
            for s in E:
                V[s] += alpha * delta * E[s]

            # Decay all traces
            for s in E:
                E[s] *= gamma * lam

            if winner:
                break

            # Opponent plays randomly
            opp_action = random.choice(available_moves(next_state))
            next_state = make_move(next_state, opp_action, O)

            state = next_state
            
if __name__ == "__main__":

    print("Training using TD-Lambda...")
    train_td_lambda(50000, lam=0.7)


"""
)
    
def p7():
    print("""
import numpy as np

class ContinuousRandomWalk:
    def __init__(self):
        self.state = 0.0

    def reset(self):
        self.state = np.random.uniform(-0.5,0.5)
        return self.state

    def step(self):
        move = np.random.uniform(-0.1,0.1)
        self.state += move

        reward = 0
        done = False

        if self.state >= 1:
            reward = 1
            done = True

        if self.state <= -1:
            reward = -1
            done = True

        return self.state, reward, done

def features(s):
    return np.array([1, s, s**2])

alpha = 0.05
gamma = 0.9
episodes = 200

w = np.zeros(3)

env = ContinuousRandomWalk()

def value(s):
    return np.dot(w, features(s))

history = []

for ep in range(episodes):
    s = env.reset()
    done = False

    while not done:
        s_next, r, done = env.step()

        v = value(s)
        v_next = value(s_next)

        delta = r + gamma * v_next - v

        w[:] = w + alpha * delta * features(s)

        s = s_next

    history.append(np.linalg.norm(w))

w

import matplotlib.pyplot as plt

plt.figure()
plt.plot(history)
plt.xlabel("Episode")
plt.ylabel("Weight Magnitude")
plt.title("Learning Progress")
plt.show()

states = np.linspace(-1,1,200)
values = [value(s) for s in states]

plt.figure()
plt.plot(states, values)
plt.xlabel("State")
plt.ylabel("Estimated Value")
plt.title("Approximated Value Function")
plt.show()

""")
    
def p8():
    print("""
#!/usr/bin/env python
# coding: utf-8

# In[9]:


import numpy as np

class ContinuousEnv:
    def __init__(self):
        self.state_dim = 1
        self.action_dim = 1
        self.max_steps = 200
        self.reset()

    def reset(self):
        self.state = np.random.uniform(-1, 1)
        self.target = 0.0
        self.steps = 0
        return np.array([self.state], dtype=np.float32)

    def step(self, action):
        action = np.clip(action, -1.0, 1.0)

        # dynamics
        self.state += action[0] * 0.1
        self.steps += 1

        # reward: closer to target = better
        reward = -abs(self.state - self.target)

        done = self.steps >= self.max_steps or abs(self.state - self.target) < 0.01

        return np.array([self.state], dtype=np.float32), reward, done, {}


# In[10]:


import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F


# In[11]:


class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, action_dim)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return torch.tanh(self.out(x))  # action range [-1,1]


# In[12]:


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, 1)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.out(x)


# In[13]:


import random
from collections import deque

class ReplayBuffer:
    def __init__(self, capacity=100000):
        self.buffer = deque(maxlen=capacity)

    def add(self, s, a, r, ns, d):
        self.buffer.append((s, a, r, ns, d))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        s, a, r, ns, d = zip(*batch)

        return (
            torch.FloatTensor(s),
            torch.FloatTensor(a),
            torch.FloatTensor(r).unsqueeze(1),
            torch.FloatTensor(ns),
            torch.FloatTensor(d).unsqueeze(1)
        )

    def size(self):
        return len(self.buffer)


# In[14]:


env = ContinuousEnv()

state_dim = env.state_dim
action_dim = env.action_dim

actor = Actor(state_dim, action_dim)
critic = Critic(state_dim, action_dim)

target_actor = Actor(state_dim, action_dim)
target_critic = Critic(state_dim, action_dim)

target_actor.load_state_dict(actor.state_dict())
target_critic.load_state_dict(critic.state_dict())

actor_opt = optim.Adam(actor.parameters(), lr=1e-3)
critic_opt = optim.Adam(critic.parameters(), lr=1e-3)

buffer = ReplayBuffer()

gamma = 0.99
tau = 0.005
batch_size = 64


# In[15]:


def soft_update(target, source, tau):
    for t_param, s_param in zip(target.parameters(), source.parameters()):
        t_param.data.copy_(tau * s_param.data + (1 - tau) * t_param.data)


# In[16]:


episodes = 1000

for ep in range(episodes):
    state = env.reset()
    total_reward = 0

    for step in range(200):
        state_tensor = torch.FloatTensor(state).unsqueeze(0)

        # Actor gives action
        action = actor(state_tensor).detach().numpy()[0]

        # Add exploration noise
        action += np.random.normal(0, 0.1, size=action_dim)

        next_state, reward, done, _ = env.step(action)

        buffer.add(state, action, reward, next_state, done)

        state = next_state
        total_reward += reward

        # Train
        if buffer.size() > batch_size:
            s, a, r, ns, d = buffer.sample(batch_size)

            # Critic loss
            with torch.no_grad():
                next_actions = target_actor(ns)
                target_q = target_critic(ns, next_actions)
                y = r + gamma * (1 - d) * target_q

            q = critic(s, a)
            critic_loss = F.mse_loss(q, y)

            critic_opt.zero_grad()
            critic_loss.backward()
            critic_opt.step()

            # Actor loss
            actor_loss = -critic(s, actor(s)).mean()

            actor_opt.zero_grad()
            actor_loss.backward()
            actor_opt.step()

            # Soft update
            soft_update(target_actor, actor, tau)
            soft_update(target_critic, critic, tau)

        if done:
            break

    print(f"Episode {ep}, Reward: {total_reward:.2f}")


""")
    
def p9():
    print("""
import gymnasium as gym
import math
import random
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple, deque
from itertools import count

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

env = gym.make("CartPole-v1")

# set up matplotlib
is_ipython = 'inline' in matplotlib.get_backend()
if is_ipython:
    from IPython import display

plt.ion()

# if GPU is to be used
device = torch.device(
    "cuda" if torch.cuda.is_available() else
    "mps" if torch.backends.mps.is_available() else
    "cpu"
)

Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))


class ReplayMemory(object):

    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)

    def push(self, *args):
        
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)

    def __len__(self):
        return len(self.memory)

class DQN(nn.Module):

    def __init__(self, n_observations, n_actions):
        super(DQN, self).__init__()
        self.layer1 = nn.Linear(n_observations, 128)
        self.layer2 = nn.Linear(128, 128)
        self.layer3 = nn.Linear(128, n_actions)

    # Called with either one element to determine next action, or a batch
    # during optimization. Returns tensor([[left0exp,right0exp]...]).
    def forward(self, x):
        x = F.relu(self.layer1(x))
        x = F.relu(self.layer2(x))
        return self.layer3(x)

# BATCH_SIZE is the number of transitions sampled from the replay buffer
# GAMMA is the discount factor as mentioned in the previous section
# EPS_START is the starting value of epsilon
# EPS_END is the final value of epsilon
# EPS_DECAY controls the rate of exponential decay of epsilon, higher means a slower decay
# TAU is the update rate of the target network
# LR is the learning rate of the ``AdamW`` optimizer
BATCH_SIZE = 128
GAMMA = 0.99
EPS_START = 0.9
EPS_END = 0.05
EPS_DECAY = 1000
TAU = 0.005
LR = 1e-4

# Get number of actions from gym action space
n_actions = env.action_space.n
# Get the number of state observations
state, info = env.reset()
n_observations = len(state)

print("Size of Input")
print(n_observations)
print("Size of output")
print(n_actions)

policy_net = DQN(n_observations, n_actions).to(device)
target_net = DQN(n_observations, n_actions).to(device)
target_net.load_state_dict(policy_net.state_dict())

optimizer = optim.AdamW(policy_net.parameters(), lr=LR, amsgrad=True)
memory = ReplayMemory(10000)


steps_done = 0


def select_action(state):
    global steps_done
    sample = random.random()
    eps_threshold = EPS_END + (EPS_START - EPS_END) * \
        math.exp(-1. * steps_done / EPS_DECAY)
    steps_done += 1
    if sample > eps_threshold:
        with torch.no_grad():
            # t.max(1) will return the largest column value of each row.
            # second column on max result is index of where max element was
            # found, so we pick action with the larger expected reward.
            return policy_net(state).max(1).indices.view(1, 1)
    else:
        return torch.tensor([[env.action_space.sample()]], device=device, dtype=torch.long)


episode_durations = []


def plot_durations(show_result=False):
    plt.figure(1)
    durations_t = torch.tensor(episode_durations, dtype=torch.float)
    if show_result:
        plt.title('Result')
    else:
        plt.clf()
        plt.title('Training...')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(durations_t.numpy())
    # Take 100 episode averages and plot them too
    if len(durations_t) >= 100:
        means = durations_t.unfold(0, 100, 1).mean(1).view(-1)
        means = torch.cat((torch.zeros(99), means))
        plt.plot(means.numpy())

    plt.pause(0.001)  # pause a bit so that plots are updated
    if is_ipython:
        if not show_result:
            display.display(plt.gcf())
            display.clear_output(wait=True)
        else:
            display.display(plt.gcf())

def optimize_model():
    if len(memory) < BATCH_SIZE:
        return
    transitions = memory.sample(BATCH_SIZE)
    # Transpose the batch (see https://stackoverflow.com/a/19343/3343043 for
    # detailed explanation). This converts batch-array of Transitions
    # to Transition of batch-arrays.
    batch = Transition(*zip(*transitions))

    # Compute a mask of non-final states and concatenate the batch elements
    # (a final state would've been the one after which simulation ended)
    non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                          batch.next_state)), device=device, dtype=torch.bool)
    non_final_next_states = torch.cat([s for s in batch.next_state
                                                if s is not None])
    state_batch = torch.cat(batch.state)
    action_batch = torch.cat(batch.action)
    reward_batch = torch.cat(batch.reward)

    # Compute Q(s_t, a) - the model computes Q(s_t), then we select the
    # columns of actions taken. These are the actions which would've been taken
    # for each batch state according to policy_net
    state_action_values = policy_net(state_batch).gather(1, action_batch)

    # Compute V(s_{t+1}) for all next states.
    # Expected values of actions for non_final_next_states are computed based
    # on the "older" target_net; selecting their best reward with max(1).values
    # This is merged based on the mask, such that we'll have either the expected
    # state value or 0 in case the state was final.
    next_state_values = torch.zeros(BATCH_SIZE, device=device)
    with torch.no_grad():
        next_state_values[non_final_mask] = target_net(non_final_next_states).max(1).values
    # Compute the expected Q values
    expected_state_action_values = (next_state_values * GAMMA) + reward_batch

    # Compute Huber loss
    criterion = nn.SmoothL1Loss()
    loss = criterion(state_action_values, expected_state_action_values.unsqueeze(1))

    # Optimize the model
    optimizer.zero_grad()
    loss.backward()
    # In-place gradient clipping
    torch.nn.utils.clip_grad_value_(policy_net.parameters(), 100)
    optimizer.step()

if torch.cuda.is_available() or torch.backends.mps.is_available():
    num_episodes = 600
else:
    num_episodes = 50

for i_episode in range(num_episodes):
    # Initialize the environment and get its state
    state, info = env.reset()
    state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
    for t in count():
        action = select_action(state)
        observation, reward, terminated, truncated, _ = env.step(action.item())
        reward = torch.tensor([reward], device=device)
        done = terminated or truncated

        if terminated:
            next_state = None
        else:
            next_state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

        # Store the transition in memory
        memory.push(state, action, next_state, reward)

        # Move to the next state
        state = next_state

        # Perform one step of the optimization (on the policy network)
        optimize_model()

        # Soft update of the target network's weights
        # θ′ ← τ θ + (1 −τ )θ′
        target_net_state_dict = target_net.state_dict()
        policy_net_state_dict = policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key]*TAU + target_net_state_dict[key]*(1-TAU)
        target_net.load_state_dict(target_net_state_dict)

        if done:
            episode_durations.append(t + 1)
            plot_durations()
            break

print('Complete')
plot_durations(show_result=True)
plt.ioff()
plt.show()

if torch.cuda.is_available() or torch.backends.mps.is_available():
    num_episodes = 600
else:
    num_episodes = 50

# Create a wrapped environment for video recording
# It will save videos in the 'videos' directory
env_monitor = gym.wrappers.RecordVideo(gym.make("CartPole-v1", render_mode="rgb_array"), 'videos')

for i_episode in range(num_episodes):
    # Initialize the environment and get its state
    state, info = env_monitor.reset()
    state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
    for t in count():
        action = select_action(state)
        observation, reward, terminated, truncated, _ = env_monitor.step(action.item())
        reward = torch.tensor([reward], device=device)
        done = terminated or truncated

        if terminated:
            next_state = None
        else:
            next_state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

        # Store the transition in memory
        memory.push(state, action, next_state, reward)

        # Move to the next state
        state = next_state

        # Perform one step of the optimization (on the policy network)
        optimize_model()

        # Soft update of the target network's weights
        # θ′ ← τ θ + (1 −τ )θ′
        target_net_state_dict = target_net.state_dict()
        policy_net_state_dict = policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key]*TAU + target_net_state_dict[key]*(1-TAU)
        target_net.load_state_dict(target_net_state_dict)

        if done:
            episode_durations.append(t + 1)
            plot_durations()
            break

print('Complete')
plot_durations(show_result=True)
plt.ioff()
plt.show()

# Close the wrapped environment
env_monitor.close()

import glob
import io
import base64
from IPython.display import HTML
from IPython import display as ipythondisplay

# Function to display recorded videos in Colab
def show_videos():
    mp4list = glob.glob('videos/*.mp4')
    if len(mp4list) > 0:
        for mp4 in mp4list:
            video = io.open(mp4, 'r+b').read()
            encoded = base64.b64encode(video).decode()
            ipythondisplay.display(HTML(data=f'''<video alt="test" autoplay
                loop controls style="height: 400px;">
                <source src="data:video/mp4;base64,{encoded}" type="video/mp4" />
             </video>'''))
    else:
        print("Could not find video files.")


def evaluate_model(policy_net, num_eval_episodes=5):
    print(f"\nEvaluating model for {num_eval_episodes} episodes...")
    eval_durations = []
    eval_env = gym.make("CartPole-v1", render_mode="rgb_array")
    eval_env_monitor = gym.wrappers.RecordVideo(eval_env, 'eval_videos')

    for i_episode in range(num_eval_episodes):
        state, info = eval_env_monitor.reset()
        state = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
        for t in count():
            # Select action deterministically using the policy network
            with torch.no_grad():
                action = policy_net(state).max(1).indices.view(1, 1)

            observation, reward, terminated, truncated, _ = eval_env_monitor.step(action.item())
            done = terminated or truncated

            if done:
                eval_durations.append(t + 1)
                print(f"Episode {i_episode + 1} finished after {t + 1} timesteps.")
                break
            state = torch.tensor(observation, dtype=torch.float32, device=device).unsqueeze(0)

    eval_env_monitor.close()
    eval_env.close()
    print("Evaluation Complete.")
    print(f"Average duration over {num_eval_episodes} episodes: {sum(eval_durations) / num_eval_episodes:.2f}")

    # Plot evaluation durations
    plt.figure(2)
    plt.clf()
    plt.title('Evaluation Durations')
    plt.xlabel('Episode')
    plt.ylabel('Duration')
    plt.plot(eval_durations)
    plt.show()

    show_videos()

# Run the evaluation
evaluate_model(policy_net, num_eval_episodes=10)


""")
    
def p10():
    print("""
#!/usr/bin/env python
# coding: utf-8

# In[6]:


get_ipython().run_line_magic('pip', 'install gym torch numpy')


# In[7]:


import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import gymnasium as gym

# ================================
# Actor-Critic Network
# ================================
class ActorCritic(nn.Module):
    def __init__(self, stateDim, actionDim):
        super(ActorCritic, self).__init__()

        # Shared feature extractor
        self.shared = nn.Sequential(
            nn.Linear(stateDim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU()
        )

        # Actor: mean of Gaussian
        self.actorMean = nn.Linear(256, actionDim)

        # Actor: log std (learnable)
        self.actorLogStd = nn.Parameter(torch.zeros(actionDim))

        # Critic: state value
        self.critic = nn.Linear(256, 1)

    def forward(self, state):
        x = self.shared(state)

        mean = self.actorMean(x)
        std = torch.exp(self.actorLogStd)

        value = self.critic(x)

        return mean, std, value


# ================================
# A2C Agent
# ================================
class A2CAgent:
    def __init__(self, stateDim, actionDim, actionHigh, lr=3e-4, gamma=0.99):
        self.gamma = gamma
        self.actionHigh = actionHigh

        self.model = ActorCritic(stateDim, actionDim)
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)

    def selectAction(self, state):
        state = torch.from_numpy(np.array(state)).float().unsqueeze(0)

        mean, std, value = self.model(state)
        dist = torch.distributions.Normal(mean, std)

        rawAction = dist.rsample()  # reparameterization trick

        # Apply tanh AFTER sampling
        action = torch.tanh(rawAction) * self.actionHigh

        # FIX: Correct log prob using change-of-variables
        logProb = dist.log_prob(rawAction)
        logProb -= torch.log(1 - torch.tanh(rawAction).pow(2) + 1e-6)
        logProb = logProb.sum(dim=-1)

        entropy = dist.entropy().sum(dim=-1)

        return action.detach().numpy()[0], logProb, value, entropy

    def computeReturns(self, rewards, dones, lastValue):
        returns = []
        R = lastValue

        # backward computation
        for r, done in zip(reversed(rewards), reversed(dones)):
            if done:
                R = 0
            R = r + self.gamma * R
            returns.insert(0, R)

        return torch.FloatTensor(returns)

    def update(self, logProbs, values, rewards, dones, entropies, nextState):
        nextState = torch.from_numpy(np.array(nextState)).float().unsqueeze(0)

        _, _, nextValue = self.model(nextState)

        returns = self.computeReturns(rewards, dones, nextValue.detach())

        values = torch.cat(values).squeeze()
        logProbs = torch.stack(logProbs)
        entropies = torch.stack(entropies)

        advantages = returns - values
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        actorLoss = -(logProbs * advantages.detach()).mean()
        criticLoss = advantages.pow(2).mean()

        # 🔥 KEY ADDITION
        entropyBonus = entropies.mean()

        loss = actorLoss + 0.5 * criticLoss - 0.001 * entropyBonus

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# ================================
# Training Loop
# ================================
def train():
    env = gym.make("Pendulum-v1")

    stateDim = env.observation_space.shape[0]
    actionDim = env.action_space.shape[0]
    actionHigh = float(env.action_space.high[0])

    agent = A2CAgent(stateDim, actionDim, actionHigh)

    maxEpisodes = 300
    rolloutLength = 200

    for episode in range(maxEpisodes):
        state, _ = env.reset()
        totalReward = 0

        logProbs = []
        values = []
        rewards = []
        dones = []
        entropies = []

        for step in range(rolloutLength):
            action, logProb, value, entropy = agent.selectAction(state)

            # FIX: new Gymnasium API
            nextState, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            logProbs.append(logProb)
            values.append(value)
            entropies.append(entropy)
            rewards.append(reward)
            dones.append(done)

            state = nextState
            totalReward += reward

            if done:
                break

        agent.update(logProbs, values, rewards, dones, entropies, state)
        print(f"Episode {episode:3d} | Reward: {totalReward:.2f}")

    env.close()


# ================================
# Run Training
# ================================
if __name__ == "__main__":
    train()


""")