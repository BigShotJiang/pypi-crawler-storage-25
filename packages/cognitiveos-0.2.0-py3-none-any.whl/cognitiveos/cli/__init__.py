"""CLI package for CognitiveOS."""
