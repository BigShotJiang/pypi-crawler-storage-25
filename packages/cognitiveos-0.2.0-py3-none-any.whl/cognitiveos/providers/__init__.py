"""Provider abstractions for CognitiveOS."""
