"""Package version metadata."""

__version__ = "0.8.3"
