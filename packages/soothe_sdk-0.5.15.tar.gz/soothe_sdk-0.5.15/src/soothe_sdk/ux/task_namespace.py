"""Task-tool namespace binding — pure helpers for subgraph stream routing.

Subgraph namespaces bind to spawns using unified tool_call_id format:
``{step_wire}:{type}:{tool}:{idx}`` where type is ``s`` for step-level or ``t{n}``
for task-level. The step_id embedded in tool_call_ids provides the correlation key
between LangGraph ``tools:…`` namespaces and main-graph ``task`` spawns.

IG-416: Unified tool call ID format for step-level and task-level tool calls.
"""

from __future__ import annotations

from collections import deque
from typing import Any, TypeAlias

TaskScope: TypeAlias = tuple[str, str, str]
"""``(task_tool_call_id, subagent_type, step_id)`` — ``step_id`` may be empty."""

_TASK_SCOPE_SEP = "\x1e"


def _step_id_to_unified_fragment(step_id: str) -> str:
    """Map execute step ids (``GHT-01``) to the unified wire fragment (``GHT_01``)."""
    return str(step_id).strip().replace("-", "_")


def _step_id_from_unified_fragment(fragment: str) -> str:
    """Map unified wire step fragment back to canonical execute step id."""
    return str(fragment).strip().replace("_", "-")


def _is_wire_step_fragment(fragment: str) -> bool:
    """True when the first segment uses underscore wire form (``GHT_01``)."""
    text = str(fragment).strip()
    return bool(text) and "_" in text and "-" not in text


def _provider_tool_fragment(tid: str) -> str:
    """Parse provider ``tool:idx`` into unified ``tool:idx`` fragment."""
    text = str(tid).strip()
    if not text:
        return text
    if ":" in text:
        name, _, idx = text.rpartition(":")
        if name and idx.isdigit():
            return f"{name}:{idx}"
    return text


def _tool_info_from_unified_parts(parts: list[str]) -> str:
    """Extract ``tool:idx`` from colon segments after the type segment."""
    if len(parts) >= 4 and parts[-1].isdigit():
        return f"{parts[-2]}:{parts[-1]}"
    return ""


def _format_unified_tool_call_id(
    step_id: str,
    type_part: str,
    tool_fragment: str,
) -> str:
    """Build canonical unified id: ``{step_wire}:{type}:{tool}:{idx}``."""
    sid_wire = _step_id_to_unified_fragment(step_id)
    frag = _provider_tool_fragment(tool_fragment)
    return f"{sid_wire}:{type_part}:{frag}"


def is_unified_tool_call_id(tool_call_id: str) -> bool:
    """Return True when ``tool_call_id`` matches the canonical unified wire format."""
    step_id, type_code, _, tool_info = parse_unified_tool_call_id(tool_call_id)
    return bool(step_id and type_code in ("s", "t") and tool_info)


def _shorten_tool_call_id(raw_tid: str) -> str:
    """Shorten provider tool_call_id to ``tool:idx`` for unified id assembly.

    Accepts provider ids (``functions.grep:0``). Already-unified ids yield their
    tool fragment via :func:`parse_unified_tool_call_id`.
    """
    tid = str(raw_tid).strip()
    parsed_sid, type_code, _, tool_info = parse_unified_tool_call_id(tid)
    if parsed_sid and type_code in ("s", "t") and tool_info:
        return tool_info
    if tid.startswith("functions."):
        tid = tid[len("functions.") :]
    return _provider_tool_fragment(tid)


def normalize_unified_tool_call_id(tool_call_id: str) -> str:
    """Reformat a canonical unified id; non-unified ids are returned unchanged."""
    tid = str(tool_call_id).strip()
    if not tid:
        return tid
    step_id, type_code, task_idx, tool_info = parse_unified_tool_call_id(tid)
    if not step_id or not type_code or not tool_info:
        return tid
    if type_code == "s":
        return _format_unified_tool_call_id(step_id, "s", tool_info)
    if type_code == "t" and task_idx is not None:
        return _format_unified_tool_call_id(step_id, f"t{task_idx}", tool_info)
    return tid


def parse_unified_tool_call_id(tool_call_id: str) -> tuple[str, str, int | None, str]:
    """Parse unified tool_call_id format into components.

    Canonical wire form (strict):
    - Step-level: ``{step_wire}:s:{tool}:{idx}`` (e.g. ``GHT_01:s:grep:0``)
    - Task-level: ``{step_wire}:t{task_idx}:{tool}:{idx}`` (e.g. ``GHT_01:t0:read_file:1``)

    Args:
        tool_call_id: Unified tool_call_id string.

    Returns:
        Tuple of (step_id, type_code, task_idx, tool_info):
        - step_id: Canonical execute step id (hyphen form, e.g. ``GHT-01``)
        - type_code: ``s`` for step-level, ``t`` for task-level, ``''`` if not unified
        - task_idx: ``None`` for step-level, integer for task-level
        - tool_info: Tool name and index (e.g. ``grep:0``)
    """
    tid = str(tool_call_id).strip()
    if not tid:
        return ("", "", None, "")

    parts = tid.split(":")
    if len(parts) < 4 or not _is_wire_step_fragment(parts[0]):
        return ("", "", None, tid)

    step_id = _step_id_from_unified_fragment(parts[0])
    type_part = parts[1]
    tool_info = _tool_info_from_unified_parts(parts)
    if not tool_info:
        return ("", "", None, tid)

    if type_part == "s":
        return (step_id, "s", None, tool_info)
    if type_part.startswith("t") and len(type_part) > 1:
        try:
            task_idx = int(type_part[1:])
        except ValueError:
            return ("", "", None, tid)
        return (step_id, "t", task_idx, tool_info)

    return ("", "", None, tid)


def is_step_level_task_tool_id(tool_call_id: str) -> bool:
    """True for unified main-graph ``task`` delegation ids (``{step}:s:task:…``)."""
    _, type_code, _, tool_info = parse_unified_tool_call_id(tool_call_id)
    if type_code != "s":
        return False
    return (tool_info or "").split(":")[0] == "task"


def is_inner_subgraph_task_tool_id(tool_call_id: str) -> bool:
    """True for inner explore ``task`` rows (``{step}:t{n}:task:…``), not main spawns."""
    _, type_code, _, tool_info = parse_unified_tool_call_id(tool_call_id)
    if type_code != "t":
        return False
    return (tool_info or "").split(":")[0] == "task"


def normalize_step_task_tool_call_id(step_id: str, tool_call_id: str) -> str:
    """Return step-scoped unified id for a main-graph ``task`` delegation.

    Args:
        step_id: AgentLoop execute step id.
        tool_call_id: Unified or provider tool call id from the stream.

    Returns:
        ``{step_wire}:s:task:{idx}`` (canonical).
    """
    sid = str(step_id).strip()
    tcid = str(tool_call_id).strip()
    if not sid:
        return tcid
    if is_unified_tool_call_id(tcid):
        parsed_sid, type_code, _, _ = parse_unified_tool_call_id(tcid)
        if parsed_sid == sid and type_code == "s" and is_step_level_task_tool_id(tcid):
            return normalize_unified_tool_call_id(tcid)
        # Another step's delegation id must not be remapped onto this card.
        return tcid
    short = _shorten_tool_call_id(tcid)
    if not short.startswith("task"):
        short = "task:0"
    return _format_unified_tool_call_id(sid, "s", short)


def step_level_parent_task_call_id(step_id: str, task_idx: int | None = None) -> str:
    """Parent ``task`` row id for inner tools under ``{step_wire}:t{idx}:…``."""
    idx = 0 if task_idx is None else int(task_idx)
    return _format_unified_tool_call_id(step_id, "s", f"task:{idx}")


def resolve_step_id_from_subgraph_tool(tool_call_id: str) -> str:
    """Extract execute ``step_id`` from a unified step- or task-level tool call id."""
    step_id, type_code, _, _ = parse_unified_tool_call_id(str(tool_call_id).strip())
    if step_id and type_code in ("s", "t"):
        return step_id
    return ""


def task_scope_step_id(scope: TaskScope | None) -> str:
    """Return the AgentLoop step id from a task scope tuple, if present."""
    if not scope:
        return ""
    return str(scope[2] or "").strip()


def task_scope_task_idx(scope: TaskScope | None, step_id: str) -> int:
    """Derive task index within a step from TaskScope's task_tool_call_id.

    Parses the task index from ``scope[0]`` (e.g., ``ABC_01:s:task:0`` → 0).
    Returns 0 if the scope is empty or the task index cannot be parsed.
    """
    if not scope:
        return 0
    task_tool_call_id = str(scope[0] or "").strip()
    if not task_tool_call_id:
        return 0
    _, type_code, _, tool_info = parse_unified_tool_call_id(task_tool_call_id)
    if type_code != "s":
        return 0
    head = (tool_info or "").split(":")[0]
    if head != "task":
        return 0
    tail = (tool_info or "").split(":")[-1]
    if tail.isdigit():
        return int(tail)
    return 0


def resolve_task_parent_for_unified_tool_id(
    tool_call_id: str,
    *,
    spawns_by_step: dict[str, TaskScope],
    tool_display_by_call_id: dict[str, Any],
    spawns_by_task_id: dict[str, TaskScope] | None = None,
) -> Any | None:
    """Return the Task delegation card for a task-level unified inner tool id."""
    step_id, type_code, task_idx, _ = parse_unified_tool_call_id(tool_call_id)
    if not step_id or type_code != "t":
        return None
    if spawns_by_task_id and task_idx is not None:
        for scope in spawns_by_task_id.values():
            sid = task_scope_step_id(scope)
            if sid == step_id and task_scope_task_idx(scope, sid) == task_idx:
                parent = tool_display_by_call_id.get(scope[0])
                if parent is not None:
                    return parent
    scope = spawns_by_step.get(step_id)
    if scope is None:
        return None
    return tool_display_by_call_id.get(scope[0])


def row_key_for_subgraph_tool(
    namespace: tuple[str, ...],
    tool_call_id: str,
    *,
    task_scope: TaskScope | None = None,
) -> str:
    """Row key for a subgraph tool on a parent step/task card."""
    tid = str(tool_call_id).strip()
    parsed_sid, type_code, parsed_idx, tool_info = parse_unified_tool_call_id(tid)
    # Re-map task-level IDs to the bound task_scope's step_id
    if type_code == "t" and task_scope is not None:
        bound_step_id = task_scope_step_id(task_scope)
        bound_task_idx = task_scope_task_idx(task_scope, bound_step_id)
        if bound_step_id and (parsed_sid != bound_step_id or parsed_idx != bound_task_idx):
            # Daemon sent wrong step_id/task_idx - remap to correct ones from binding
            return _format_unified_tool_call_id(bound_step_id, f"t{bound_task_idx}", tool_info)
    if type_code == "t":
        return tid
    return scoped_subgraph_tool_key(namespace, tid, task_scope=task_scope)


def try_bind_namespace_from_tool_call_id(
    bindings: dict[tuple[str, ...], TaskScope],
    spawns_by_step: dict[str, TaskScope],
    namespace: tuple[str, ...],
    tool_call_id: str,
) -> bool:
    """Bind ``namespace`` using the execute step id embedded in a unified tool_call_id.

    Parallel waves stamp subgraph tools as ``{step_wire}:t{idx}:…``; the step id is the
    correlation key between a LangGraph ``tools:…`` namespace and the main-graph ``task`` spawn.
    """
    tcid = str(tool_call_id).strip()
    if not namespace or not tcid or is_inner_subgraph_task_tool_id(tcid):
        return False
    step_id = resolve_step_id_from_subgraph_tool(tcid)
    if not step_id:
        return False
    scope = spawns_by_step.get(step_id)
    if scope is None:
        return False
    if namespace in bindings:
        if task_scope_step_id(bindings[namespace]) == step_id:
            return False
        _, type_code, _, tool_info = parse_unified_tool_call_id(tcid)
        if type_code == "t" and (tool_info or "").split(":")[0] != "task":
            bindings[namespace] = scope
            return True
        return False
    bindings[namespace] = scope
    return True


def scoped_subgraph_tool_key(
    namespace: tuple[str, ...],
    tool_call_id: str,
    *,
    task_scope: TaskScope | None = None,
) -> str:
    """Build unified tool call ID for subgraph (task-level) tool rows."""
    tid = str(tool_call_id).strip()
    parsed_sid, type_code, _, _ = parse_unified_tool_call_id(tid)
    if parsed_sid and type_code == "t":
        return tid

    short_tid = _shorten_tool_call_id(tid)
    if not namespace:
        return short_tid

    step_id = task_scope_step_id(task_scope) if task_scope else ""
    task_idx = task_scope_task_idx(task_scope, step_id) if task_scope else 0

    if step_id:
        return _format_unified_tool_call_id(step_id, f"t{task_idx}", short_tid)

    ns = "/".join(str(p) for p in namespace)
    return f"{ns}{_TASK_SCOPE_SEP}{short_tid}"


def register_task_spawn_for_step(
    bindings: dict[tuple[str, ...], TaskScope],
    queue: deque[TaskScope],
    spawns_by_step: dict[str, TaskScope],
    scope: TaskScope,
    *,
    pending_unscoped_namespaces: deque[tuple[str, ...]] | None = None,
    spawns_by_task_id: dict[str, TaskScope] | None = None,
) -> None:
    """Record a task spawn for ``scope[2]``.

    Namespace binding is deferred to unified ID-based matching via
    :func:`try_bind_namespace_from_tool_call_id`.
    """
    queue.append(scope)
    step_id = task_scope_step_id(scope)
    task_call_id = str(scope[0] or "").strip()
    if not step_id:
        return
    existing = spawns_by_step.get(step_id)
    if existing is not None and is_step_level_task_tool_id(str(existing[0])):
        if is_inner_subgraph_task_tool_id(task_call_id):
            return
    spawns_by_step[step_id] = scope
    if spawns_by_task_id is not None and task_call_id:
        spawns_by_task_id[task_call_id] = scope


def prune_bound_pending_namespaces(
    bindings: dict[tuple[str, ...], TaskScope],
    pending_unscoped_namespaces: deque[tuple[str, ...]] | None,
) -> None:
    """Drop namespaces from the pending deque once they are bound."""
    if pending_unscoped_namespaces is None or not bindings:
        return
    filtered = [ns for ns in pending_unscoped_namespaces if ns not in bindings]
    pending_unscoped_namespaces.clear()
    pending_unscoped_namespaces.extend(filtered)


def resolve_task_scope_for_namespace(
    bindings: dict[tuple[str, ...], TaskScope],
    namespace: tuple[str, ...],
) -> TaskScope | None:
    """Return task scope for stream ``namespace``."""
    if not namespace:
        return None
    for length in range(len(namespace), 0, -1):
        prefix = namespace[:length]
        bound = bindings.get(prefix)
        if bound is not None:
            return bound
    return None


def resolve_task_parent_lookup(
    scope: TaskScope | None,
    *,
    step_cards: dict[str, Any],
    tool_display_by_call_id: dict[str, Any],
) -> Any | None:
    """Resolve the UI parent for subgraph tools (Task card preferred over step)."""
    if scope is None:
        return None
    task_parent = tool_display_by_call_id.get(scope[0])
    if task_parent is not None:
        return task_parent
    step_id = task_scope_step_id(scope)
    if step_id:
        return step_cards.get(step_id)
    return None


__all__ = [
    "TaskScope",
    "is_inner_subgraph_task_tool_id",
    "is_step_level_task_tool_id",
    "is_unified_tool_call_id",
    "normalize_step_task_tool_call_id",
    "normalize_unified_tool_call_id",
    "_shorten_tool_call_id",
    "prune_bound_pending_namespaces",
    "parse_unified_tool_call_id",
    "register_task_spawn_for_step",
    "resolve_step_id_from_subgraph_tool",
    "resolve_task_parent_for_unified_tool_id",
    "resolve_task_parent_lookup",
    "resolve_task_scope_for_namespace",
    "row_key_for_subgraph_tool",
    "scoped_subgraph_tool_key",
    "step_level_parent_task_call_id",
    "task_scope_step_id",
    "task_scope_task_idx",
    "try_bind_namespace_from_tool_call_id",
]
