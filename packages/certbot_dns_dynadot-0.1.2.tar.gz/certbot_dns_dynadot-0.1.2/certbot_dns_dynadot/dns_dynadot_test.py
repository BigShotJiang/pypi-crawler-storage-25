from pprint import pprint
from random import randint
from typing import Any

from certbot.errors import PluginError

from certbot_dns_dynadot.client import DynadotClient

if __name__ == "__main__":
    client = DynadotClient(
        "sandbox_7h627c738q6v637N8JD75Q9C8G7N56V6P8xl7r8T7GC82817qC7M8l8h8P7n7S",
        "sandbox_8ef8630c92d3a39e6944908af2357608f34cea9ce97a4635b2a295ac6df35604",
    )
    my_domain = "dmig.top"
    # my_domain = "test-domain.top"
    domains: list[dict[str, Any]] = client._api_request("get", "domains")["data"][
        "domain_info"
    ]
    pprint(domains)
    for item in domains:
        if item["domain_name"] == my_domain:
            break
    else:
        pprint(
            client._api_request(
                "post",
                "domains",
                my_domain,
                "register",
                {"domain": {"duration": 1, "privacy": "partial"}},
            )["data"]
        )
        pprint(
            client.set_dns(
                my_domain,
                [
                    {"record_type": "a", "record_value1": "47.230.1.8"},
                    {
                        "record_type": "aaaa",
                        "record_value1": "2001:0db8:85a3:0000:0000:8a2e:0370:7334",
                    },
                ],
                [],
            )
        )

    exit()

    txt = f"hello world {randint(0, 100)}"
    client.add_txt_record(
        my_domain,
        txt,
    )
    pprint(client.get_dns(my_domain))
    client.add_txt_record(
        f"_acme-cname.{my_domain}",
        txt,
    )
    pprint(client.get_dns(my_domain))
    client.remove_txt_record(
        my_domain,
        txt,
    )
    pprint(client.get_dns(my_domain))
    client.remove_txt_record(
        f"_acme-cname.{my_domain}",
        txt,
    )
    pprint(client.get_dns(my_domain))

    # teardown
    try:
        pprint(
            client._api_request("put", "accounts", "account_lock", data={"lock": False})
        )
    except PluginError:
        pass
    try:
        pprint(
            client._api_request(
                "put", "domains", my_domain, "domain_lock", data={"lock": False}
            )
        )
    except PluginError:
        pass
    try:
        pprint(
            client._api_request(
                "delete",
                "domains",
                my_domain,
                "grace_delete",
            )
        )
    except PluginError:
        pass
