# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def genome():
    """Manage agent genomes."""


@genome.command("list")
@click.option("--agent-id", help="Filter by agent")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_list(agent_id, limit, offset, as_json):
    """List Genomes"""
    params = {}
    if agent_id is not None:
        params["agent_id"] = agent_id
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/genomes/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "agent_id", "created_at"])

@genome.command("get")
@click.argument("genome_id")
@click.option("--version", type=int, help="Specific version (None = latest)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_get(genome_id, version, as_json):
    """Get Genome"""
    params = {}
    if version is not None:
        params["version"] = version
    resp = api().get(f"/v1/genomes/{genome_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("create")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_create(as_json):
    """Create Genome"""
    resp = api().post("/v1/genomes/", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("delete")
@click.argument("genome_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def genome_delete(genome_id, as_json, yes):
    """Delete Genome"""
    if not yes and not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/v1/genomes/{genome_id}")
    if resp.status_code == 204:
        if as_json:
            print_json({})
        else:
            click.echo("Done.")
        return
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("by-agent")
@click.argument("agent_id")
@click.option("--version", type=int, help="Specific version (None = latest)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_by_agent(agent_id, version, as_json):
    """Get Genome By Agent"""
    params = {}
    if version is not None:
        params["version"] = version
    resp = api().get(f"/v1/genomes/by-agent/{agent_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("mutation-history")
@click.argument("agent_id")
@click.option("--limit", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_mutation_history(agent_id, limit, as_json):
    """Get Mutation History"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    resp = api().get(f"/v1/genomes/by-agent/{agent_id}/mutation-history", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("versions")
@click.argument("genome_id")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_versions(genome_id, limit, offset, as_json):
    """List Genome Versions"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get(f"/v1/genomes/{genome_id}/versions", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["version", "created_at"])

@genome.command("version-get")
@click.argument("genome_id")
@click.argument("version")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_version_get(genome_id, version, as_json):
    """Get Genome Version"""
    resp = api().get(f"/v1/genomes/{genome_id}/versions/{version}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("ancestry")
@click.argument("genome_id")
@click.option("--max-depth", type=int, help="Maximum ancestor depth")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_ancestry(genome_id, max_depth, as_json):
    """Get Genome Ancestry"""
    params = {}
    if max_depth is not None:
        params["max_depth"] = max_depth
    resp = api().get(f"/v1/genomes/{genome_id}/ancestry", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("diff")
@click.argument("genome_id")
@click.option("--version-a", type=int, required=True, help="First version")
@click.option("--version-b", type=int, required=True, help="Second version")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_diff(genome_id, version_a, version_b, as_json):
    """Diff Genome Versions"""
    params = {}
    if version_a is not None:
        params["version_a"] = version_a
    if version_b is not None:
        params["version_b"] = version_b
    resp = api().get(f"/v1/genomes/{genome_id}/diff", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("similar")
@click.argument("genome_id")
@click.option("--version", type=int, help="Genome version")
@click.option("--limit", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_similar(genome_id, version, limit, as_json):
    """Find Similar Genomes"""
    params = {}
    if version is not None:
        params["version"] = version
    if limit is not None:
        params["limit"] = limit
    resp = api().get(f"/v1/genomes/{genome_id}/similar", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("extract")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_extract(agent_id, as_json):
    """Extract Genome From Agent"""
    resp = api().post(f"/v1/genomes/extract-from-agent/{agent_id}", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("to-agent-update")
@click.argument("genome_id")
@click.option("--version", type=int, help="Specific version")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_to_agent_update(genome_id, version, as_json):
    """Genome To Agent Update"""
    params = {}
    if version is not None:
        params["version"] = version
    resp = api().get(f"/v1/genomes/{genome_id}/to-agent-update", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
