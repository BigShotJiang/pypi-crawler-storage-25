# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def scan():
    """Manage code scans."""


@scan.command("run")
@click.option("--scm-installation-id", required=True, help="Scm Installation Id")
@click.option("--repo-owner", required=True, help="Repo Owner")
@click.option("--repo-name", required=True, help="Repo Name")
@click.option("--ref", required=True, help="Branch, tag, or commit SHA to scan")
@click.option("--scan-target-type", type=click.Choice(["branch", "tag", "commit"]), help="What kind of ref is being scanned.")
@click.option("--scan-mode", type=click.Choice(["full_repo", "diff"]), help="Scan analysis mode.")
@click.option("--external-repository-id", help="External Repository Id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def scan_run(scm_installation_id, repo_owner, repo_name, ref, scan_target_type, scan_mode, external_repository_id, as_json, wait):
    """Create Scan"""
    params = {}
    params["team_id"] = require_team_id()
    body = {}
    if scm_installation_id is not None:
        body["scm_installation_id"] = scm_installation_id
    if repo_owner is not None:
        body["repo_owner"] = repo_owner
    if repo_name is not None:
        body["repo_name"] = repo_name
    if ref is not None:
        body["ref"] = ref
    if scan_target_type is not None:
        body["scan_target_type"] = scan_target_type
    if scan_mode is not None:
        body["scan_mode"] = scan_mode
    if external_repository_id is not None:
        body["external_repository_id"] = external_repository_id
    resp = api().post("/v1/code-scans", params=params, json=body)
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/v1/code-scans/{data['id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("list")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--status-filter", multiple=True)
@click.option("--review-status", multiple=True)
@click.option("--agent-id")
@click.option("--repo-owner")
@click.option("--repo-name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_list(limit, offset, status_filter, review_status, agent_id, repo_owner, repo_name, as_json):
    """List Scans"""
    params = {}
    params["team_id"] = require_team_id()
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if status_filter:
        params["status_filter"] = status_filter
    if review_status:
        params["review_status"] = review_status
    if agent_id is not None:
        params["agent_id"] = agent_id
    if repo_owner is not None:
        params["repo_owner"] = repo_owner
    if repo_name is not None:
        params["repo_name"] = repo_name
    resp = api().get("/v1/code-scans", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "repo_owner", "repo_name", "status", "requested_at"])

@scan.command("get")
@click.argument("scan_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_get(scan_id, as_json):
    """Get Scan"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/code-scans/{scan_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("cancel")
@click.argument("scan_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def scan_cancel(scan_id, as_json, yes):
    """Cancel Scan"""
    if not yes and not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().post(f"/v1/code-scans/{scan_id}/cancel", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("list-repos")
@click.argument("installation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_list_repos(installation_id, as_json):
    """List Repos"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/scm-installations/{installation_id}/repos", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["external_repository_id", "full_name", "default_branch", "private", "language"])

@scan.command("list-installations")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_list_installations(limit, offset, as_json):
    """List Installations"""
    params = {}
    params["team_id"] = require_team_id()
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/scm-installations", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "provider", "external_installation_id", "external_account_login", "status"])

@scan.command("get-installation")
@click.argument("installation_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_get_installation(installation_id, as_json):
    """Get Installation"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/scm-installations/{installation_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("create-installation")
@click.option("--provider", type=click.Choice(["github"]), help="Source control management provider.  Phase 3: add GITLAB = \"gitlab\" and BITBUCKET = \"bitbucket\" when add...")
@click.option("--external-installation-id", required=True, help="GitHub installation ID (numeric)")
@click.option("--external-account-login", required=True, help="GitHub org or user login")
@click.option("--external-account-type", type=click.Choice(["Organization", "User"]), help="External Account Type")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_create_installation(provider, external_installation_id, external_account_login, external_account_type, as_json):
    """Create Installation"""
    params = {}
    params["team_id"] = require_team_id()
    body = {}
    if provider is not None:
        body["provider"] = provider
    if external_installation_id is not None:
        body["external_installation_id"] = external_installation_id
    if external_account_login is not None:
        body["external_account_login"] = external_account_login
    if external_account_type is not None:
        body["external_account_type"] = external_account_type
    resp = api().post("/v1/scm-installations", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("associate")
@click.argument("scan_id")
@click.option("--agent-id", required=True, help="Agent Id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_associate(scan_id, agent_id, as_json):
    """Associate Scan"""
    params = {}
    params["team_id"] = require_team_id()
    body = {}
    if agent_id is not None:
        body["agent_id"] = agent_id
    resp = api().post(f"/v1/code-scans/{scan_id}/associate", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("disassociate")
@click.argument("scan_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def scan_disassociate(scan_id, as_json, yes):
    """Disassociate Scan"""
    if not yes and not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().post(f"/v1/code-scans/{scan_id}/disassociate", params=params, json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("review")
@click.argument("scan_id")
@click.option("--review-status", type=click.Choice(["pending", "flagged", "waived"]), required=True, help="User triage decision — independent of agent assignment.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def scan_review(scan_id, review_status, as_json):
    """Update Review Status"""
    params = {}
    params["team_id"] = require_team_id()
    body = {}
    if review_status is not None:
        body["review_status"] = review_status
    resp = api().post(f"/v1/code-scans/{scan_id}/review", params=params, json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@scan.command("delete")
@click.argument("scan_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def scan_delete(scan_id, as_json, yes):
    """Delete Scan"""
    if not yes and not click.confirm('Are you sure?'):
        return
    params = {}
    params["team_id"] = require_team_id()
    resp = api().delete(f"/v1/code-scans/{scan_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
