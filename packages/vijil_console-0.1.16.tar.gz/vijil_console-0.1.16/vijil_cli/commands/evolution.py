# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json


@click.group()
def evolution():
    """Darwin evolution engine."""


@evolution.command("run")
@click.argument("agent_id")
@click.option("--harness-names", help="Harness Names (JSON array)")
@click.option("--sample-size", type=int, help="Sample Size")
@click.option("--min-improvement-threshold", type=float, help="Min Improvement Threshold")
@click.option("--target-dimensions", help="Target Dimensions (JSON array)")
@click.option("--max-probes-per-evaluation", type=int, help="Max Probes Per Evaluation")
@click.option("--probe-concurrency", type=int, help="Probe Concurrency")
@click.option("--reflection-model", help="Reflection Model")
@click.option("--mutation-strategy", help="Mutation Strategy")
@click.option("--gepa-max-metric-calls", type=int, help="Gepa Max Metric Calls")
@click.option("--detection-volume-threshold", type=int, help="Detection Volume Threshold")
@click.option("--use-tier1", is_flag=True, help="Use Tier1")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--wait", is_flag=True, help="Poll until complete.")
def evolution_run(
    agent_id,
    harness_names,
    sample_size,
    min_improvement_threshold,
    target_dimensions,
    max_probes_per_evaluation,
    probe_concurrency,
    reflection_model,
    mutation_strategy,
    gepa_max_metric_calls,
    detection_volume_threshold,
    use_tier1,
    as_json,
    wait,
):
    """Trigger Evolution"""
    import json as _json
    body = {}
    if harness_names is not None:
        body["harness_names"] = _json.loads(harness_names)
    if sample_size is not None:
        body["sample_size"] = sample_size
    if min_improvement_threshold is not None:
        body["min_improvement_threshold"] = min_improvement_threshold
    if target_dimensions is not None:
        body["target_dimensions"] = _json.loads(target_dimensions)
    if max_probes_per_evaluation is not None:
        body["max_probes_per_evaluation"] = max_probes_per_evaluation
    if probe_concurrency is not None:
        body["probe_concurrency"] = probe_concurrency
    if reflection_model is not None:
        body["reflection_model"] = reflection_model
    if mutation_strategy is not None:
        body["mutation_strategy"] = mutation_strategy
    if gepa_max_metric_calls is not None:
        body["gepa_max_metric_calls"] = gepa_max_metric_calls
    if detection_volume_threshold is not None:
        body["detection_volume_threshold"] = detection_volume_threshold
    if use_tier1:
        body["use_tier1"] = use_tier1
    resp = api().post(f"/v1/agents/{agent_id}/evolutions", json=body)
    data = resp.json()
    if wait:
        from vijil_cli.polling import poll_until_done
        data = poll_until_done(api(), f"/v1/agents/{agent_id}/evolutions/{data['evolution_id']}")
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@evolution.command("status")
@click.argument("agent_id")
@click.argument("evolution_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def evolution_status(agent_id, evolution_id, as_json):
    """Get Evolution Job Status"""
    resp = api().get(f"/v1/agents/{agent_id}/evolutions/{evolution_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
