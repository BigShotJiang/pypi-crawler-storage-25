# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def persona():
    """Manage test personas."""


@persona.command("list")
@click.option("--intents", multiple=True, help="Filter by intent(s): benign, curious, adversarial, malicious")
@click.option("--is-preset", is_flag=True, help="Filter by preset status")
@click.option("--search", help="Search in name, description, and role")
@click.option("--limit", type=int, help="Maximum number of results (default 10)")
@click.option("--offset", type=int, help="Number of results to skip for paging")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_list(intents, is_preset, search, limit, offset, as_json):
    """List Personas"""
    params = {}
    params["team_id"] = require_team_id()
    if intents:
        params["intents"] = intents
    if is_preset:
        params["is_preset"] = is_preset
    if search is not None:
        params["search"] = search
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/personas/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "intent", "created_at"])

@persona.command("create")
@click.option("--id", help="Id")
@click.option("--name", required=True, help="Name")
@click.option("--description", help="Description")
@click.option("--role", required=True, help="Role")
@click.option("--role-description", help="Role Description")
@click.option("--knowledge-level", type=click.Choice(["beginner", "intermediate", "advanced", "expert"]), help="Knowledge level of the persona.")
@click.option("--skill-level", type=click.Choice(["novice", "competent", "proficient", "expert"]), help="Skill level of the persona.")
@click.option("--intent", type=click.Choice(["benign", "curious", "adversarial", "malicious"]), help="Intent type of the persona.")
@click.option("--language", help="Language")
@click.option("--access-permissions", help="Access Permissions (JSON object)")
@click.option("--is-preset", is_flag=True, help="Is Preset")
@click.option("--preset-category", help="Preset Category")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--icon-filename", help="Icon Filename")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_create(
    id,
    name,
    description,
    role,
    role_description,
    knowledge_level,
    skill_level,
    intent,
    language,
    access_permissions,
    is_preset,
    preset_category,
    tags,
    icon_filename,
    as_json,
):
    """Create Persona"""
    import json as _json
    body = {}
    body["team_id"] = require_team_id()
    if id is not None:
        body["id"] = id
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if role is not None:
        body["role"] = role
    if role_description is not None:
        body["role_description"] = role_description
    if knowledge_level is not None:
        body["knowledge_level"] = knowledge_level
    if skill_level is not None:
        body["skill_level"] = skill_level
    if intent is not None:
        body["intent"] = intent
    if language is not None:
        body["language"] = language
    if access_permissions is not None:
        body["access_permissions"] = _json.loads(access_permissions)
    if is_preset:
        body["is_preset"] = is_preset
    if preset_category is not None:
        body["preset_category"] = preset_category
    if tags is not None:
        body["tags"] = _json.loads(tags)
    if icon_filename is not None:
        body["icon_filename"] = icon_filename
    resp = api().post("/v1/personas/", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@persona.command("get")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_get(id, as_json):
    """Get Persona"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/personas/{id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@persona.command("update")
@click.argument("id")
@click.option("--name", help="Name")
@click.option("--description", help="Description")
@click.option("--role", help="Role")
@click.option("--role-description", help="Role Description")
@click.option("--knowledge-level", type=click.Choice(["beginner", "intermediate", "advanced", "expert"]), help="Knowledge level of the persona.")
@click.option("--skill-level", type=click.Choice(["novice", "competent", "proficient", "expert"]), help="Skill level of the persona.")
@click.option("--intent", type=click.Choice(["benign", "curious", "adversarial", "malicious"]), help="Intent type of the persona.")
@click.option("--language", help="Language")
@click.option("--access-permissions", help="Access Permissions (JSON object)")
@click.option("--is-preset", is_flag=True, help="Is Preset")
@click.option("--preset-category", help="Preset Category")
@click.option("--tags", help="Tags (JSON array)")
@click.option("--icon-filename", help="Icon Filename")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_update(
    id,
    name,
    description,
    role,
    role_description,
    knowledge_level,
    skill_level,
    intent,
    language,
    access_permissions,
    is_preset,
    preset_category,
    tags,
    icon_filename,
    as_json,
):
    """Update Persona"""
    import json as _json
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if role is not None:
        body["role"] = role
    if role_description is not None:
        body["role_description"] = role_description
    if knowledge_level is not None:
        body["knowledge_level"] = knowledge_level
    if skill_level is not None:
        body["skill_level"] = skill_level
    if intent is not None:
        body["intent"] = intent
    if language is not None:
        body["language"] = language
    if access_permissions is not None:
        body["access_permissions"] = _json.loads(access_permissions)
    if is_preset:
        body["is_preset"] = is_preset
    if preset_category is not None:
        body["preset_category"] = preset_category
    if tags is not None:
        body["tags"] = _json.loads(tags)
    if icon_filename is not None:
        body["icon_filename"] = icon_filename
    resp = api().put(f"/v1/personas/{id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@persona.command("delete")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
def persona_delete(id, as_json, yes):
    """Delete Persona"""
    if not yes and not click.confirm('Are you sure?'):
        return
    resp = api().delete(f"/v1/personas/{id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@persona.command("preset-list")
@click.option("--preset-category", help="Filter by preset category: professional, adversarial, support")
@click.option("--limit", type=int, help="Maximum number of results")
@click.option("--offset", type=int, help="Number of results to skip")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_preset_list(preset_category, limit, offset, as_json):
    """List Presets"""
    params = {}
    params["team_id"] = require_team_id()
    if preset_category is not None:
        params["preset_category"] = preset_category
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/personas/presets/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "description"])

@persona.command("from-preset")
@click.argument("preset_id")
@click.option("--name-override", help="Name Override")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def persona_from_preset(preset_id, name_override, as_json):
    """Create From Preset"""
    body = {}
    if name_override is not None:
        body["name_override"] = name_override
    resp = api().post(f"/v1/personas/from-preset/{preset_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
