from __future__ import annotations

import importlib
import importlib.util
from pathlib import Path

from .state import ProjectState


class MigrationLoader:
    """Loads migration files and reconstructs the project state."""

    def __init__(self, connection):
        self.connection = connection
        self.migrations: dict[str, list] = {}  # app_label → list of (number, name, module)
        self.applied: set[tuple[str, str]] = set()

    def load(self, migrations_dir: str | Path, app_label: str):
        migrations_dir = Path(migrations_dir)
        if not migrations_dir.exists():
            return

        files = sorted(migrations_dir.glob("*.py"))
        for path in files:
            if path.name.startswith("_") or not path.name[0].isdigit():
                continue
            stem = path.stem
            # e.g. "0001_initial"
            parts = stem.split("_", 1)
            try:
                number = int(parts[0])
            except ValueError:
                continue

            spec = importlib.util.spec_from_file_location(
                f"{app_label}.migrations.{stem}", path
            )
            if spec is None or spec.loader is None:
                continue
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            if app_label not in self.migrations:
                self.migrations[app_label] = []
            self.migrations[app_label].append((number, stem, module))

        if app_label in self.migrations:
            self.migrations[app_label].sort(key=lambda x: x[0])

    def load_applied(self, recorder):
        self.applied = recorder.applied_migrations()

    def get_migration_state(self, app_label: str, all_migrations: bool = False) -> ProjectState:
        """Replay migrations to build a ProjectState.

        all_migrations=True replays every file on disk (for makemigrations).
        all_migrations=False (default) replays only applied ones (for migrate).
        """
        state = ProjectState()
        for number, name, module in self.migrations.get(app_label, []):
            if all_migrations or (app_label, name) in self.applied:
                operations = getattr(module, "operations", [])
                for op in operations:
                    op.state_forwards(app_label, state)
        return state

    def unapplied_migrations(self, app_label: str) -> list:
        result = []
        for number, name, module in self.migrations.get(app_label, []):
            if (app_label, name) not in self.applied:
                result.append((number, name, module))
        return result
