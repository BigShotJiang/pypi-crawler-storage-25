#!/usr/bin/env python3
"""WIDDX CLI — Autonomous AI Orchestration System. Powered by DeepSeek.

    pip install widdx
    python -m widdx                # Always works
    widdx                          # Works if Python Scripts is in PATH
    widdx "task"                   # Run task in REPL mode
    widdx schedule add "0 9 * * 1" "task"  # Schedule a task
    widdx schedule list            # List scheduled tasks
    widdx schedule remove <id>     # Remove a scheduled task
    widdx schedule run             # Start the scheduler daemon
    widdx --help                   # Show help

All interactive commands are handled inside the interactive REPL.
"""

from __future__ import annotations

import os
import shutil
import subprocess as _sp
import sys
from pathlib import Path

if sys.platform == "win32":
    _sp.run(["cmd", "/c", "chcp 65001"], check=False,
            stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]

import click

from . import ui
from .config import DEFAULT_MEMORY_DB_PATH, load_config
from .memory import MemoryStore
from .repl import WIDDXRepl
from .router import AIRouter


class WIDDXGroup(click.Group):
    """Treat unknown subcommands as direct natural-language tasks."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        option_args: list[str] = []
        idx = 0
        while idx < len(args):
            arg = args[idx]
            if arg in ("-m", "--model"):
                option_args.append(arg)
                if idx + 1 < len(args):
                    option_args.append(args[idx + 1])
                    idx += 2
                    continue
            if arg == "--no-color":
                option_args.append(arg)
                idx += 1
                continue
            if arg.startswith("-"):
                return super().parse_args(ctx, args)
            break

        if idx < len(args) and args[idx] not in self.commands:
            ctx.meta["direct_task_args"] = list(args[idx:])
            return super().parse_args(ctx, option_args)
        return super().parse_args(ctx, args)


def _ensure_widdx_in_path() -> None:
    """Offer to add Python Scripts to PATH so `widdx` command works directly.

    On Windows, pip installs widdx.exe to PythonXX\Scripts\ which may not
    be in PATH. This detects the issue and offers a one-click fix.
    """
    if sys.platform != "win32":
        return
    try:
        import shutil
        widdx_path = shutil.which("widdx")
        if widdx_path:
            return  # Already in PATH — nothing to do
    except Exception:
        return

    # Find where pip installed widdx.exe
    scripts_dir = None
    for p in sys.path:
        scripts = Path(p) / "Scripts"
        if scripts.exists() and (scripts / "widdx.exe").exists():
            scripts_dir = scripts
            break

    if not scripts_dir:
        return  # Can't find widdx.exe

    ui.get_console().print()
    ui.get_console().print(f"  [warning]⚠ 'widdx' command not in PATH[/]")
    ui.get_console().print(f"  [dim]Add Python Scripts to PATH so you can just type 'widdx'?[/]")
    ui.get_console().print(f"  [dim]Directory: {scripts_dir}[/]")

    try:
        answer = input("  [dim]Add to PATH? [Y/n]:[/] ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        return

    if answer and not answer.startswith("y"):
        ui.get_console().print(f"  [dim]Use 'python -m widdx' to launch.[/]")
        return

    try:
        import subprocess
        result = subprocess.run(
            ["setx", "PATH", f"{scripts_dir};%PATH%"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            ui.get_console().print(f"  [success]✓ Added to user PATH. Restart terminal and type 'widdx'.[/]")
        else:
            ui.get_console().print(f"  [dim]Could not update PATH automatically.[/]")
            ui.get_console().print(f"  [dim]Run: setx PATH \"{scripts_dir};%PATH%\"[/]")
    except Exception:
        ui.get_console().print(f"  [dim]Could not update PATH. Use 'python -m widdx'.[/]")


@click.group(
    cls=WIDDXGroup,
    invoke_without_command=True,
    context_settings=dict(allow_extra_args=True, ignore_unknown_options=True),
)
@click.version_option(version="1.4.0", prog_name="widdx")
@click.option("--model", "-m", default=None, help="Model to use (architect/executor)")
@click.option("--no-color", is_flag=True, help="Disable colors")
@click.pass_context
def main(ctx: click.Context, model: str | None, no_color: bool) -> None:
    """WIDDX CLI — Autonomous AI Software Engineering Operating System.

    A world-class AI coding agent in your terminal. Powered by DeepSeek v4.

    Usage:
      widdx                    Start interactive REPL
      widdx "fix auth bug"     Run task in REPL
      widdx schedule --help    Manage scheduled tasks
      widdx --help             Show all options
    """
    # ── Configure logging ────────────────────────────────────────
    import logging as _logging
    _logging.basicConfig(
        level=_logging.WARNING,
        format="[widdx] %(levelname)s %(name)s: %(message)s",
        stream=__import__("sys").stderr,
    )

    # If a subcommand was invoked (e.g. `widdx schedule ...`), let it handle execution.
    if ctx.invoked_subcommand is not None:
        return

    ui.show_banner()

    # ── First-run PATH fix for Windows ─────────────────────────
    _ensure_widdx_in_path()

    # ctx.args holds direct natural-language input, e.g. ``widdx "fix auth"``.
    task_args: tuple[str, ...] = tuple(ctx.meta.get("direct_task_args", ctx.args))
    if not task_args:
        _start_repl(initial_task=None, model=model)
    else:
        task_text = " ".join(task_args)
        if task_text.startswith("/"):
            ui.get_console().print("  [dim]Starting REPL...[/]")
        _start_repl(initial_task=task_text, model=model)


def _start_repl(initial_task: str | None, model: str | None) -> None:
    config = load_config()
    memory = MemoryStore(config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
    router = AIRouter(config, memory)

    if model:
        config["force_model"] = model

    if not router.is_ready:
        ui.fail("No AI provider available.")
        return

    repl = WIDDXRepl(router, config, memory=memory, initial_task=initial_task)
    repl.run()


# ---------------------------------------------------------------------------
# schedule subcommand group
# ---------------------------------------------------------------------------

@click.group()
def schedule() -> None:
    """Manage scheduled tasks (cron-based)."""


@schedule.command("add")
@click.argument("cron")
@click.argument("task")
def schedule_add(cron: str, task: str) -> None:
    """Add a scheduled task.

    CRON is a standard 5-field cron expression (e.g. "0 9 * * 1").
    TASK is the task description or command to run when due.

    Example:
      widdx schedule add "0 9 * * 1" "weekly code review"
    """
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    task_id = scheduler.add(cron, task)
    click.echo(f"Schedule added — id: {task_id}")


@schedule.command("list")
def schedule_list() -> None:
    """List all saved scheduled tasks."""
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    schedules = scheduler.list_schedules()

    if not schedules:
        click.echo("No scheduled tasks found.")
        return

    # Header
    click.echo(f"{'ID':<10} {'CRON':<20} {'LAST RUN':<26} TASK")
    click.echo("-" * 80)
    for s in schedules:
        task_id = s.get("id", "")
        cron = s.get("cron", "")
        last_run = s.get("last_run") or "never"
        task_desc = s.get("task", "")
        click.echo(f"{task_id:<10} {cron:<20} {last_run:<26} {task_desc}")


@schedule.command("remove")
@click.argument("id")
def schedule_remove(id: str) -> None:
    """Remove a scheduled task by ID.

    ID is the 8-character hex task ID shown by `widdx schedule list`.
    """
    from .scheduler import TaskScheduler

    scheduler = TaskScheduler()
    removed = scheduler.remove(id)
    if removed:
        click.echo(f"Schedule {id} removed.")
    else:
        click.echo(f"No schedule found with id: {id}", err=True)
        sys.exit(1)


@schedule.command("run")
def schedule_run() -> None:
    """Start the scheduler daemon (blocking).

    Polls every 60 seconds and runs any task whose cron expression matches
    the current minute. Press Ctrl+C to stop.
    """
    from .scheduler import TaskScheduler

    config = load_config()
    memory = MemoryStore(config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
    scheduler = TaskScheduler(memory=memory)
    scheduler.run_daemon()


# Register the schedule group on the main group.
main.add_command(schedule)


# ---------------------------------------------------------------------------
# bot subcommand
# ---------------------------------------------------------------------------

@click.group()
def bot() -> None:
    """Telegram Bot integration."""


@bot.command("start")
def bot_start() -> None:
    """Start the WIDDX Telegram bot daemon.

    Requires TELEGRAM_BOT_TOKEN environment variable or config.

    pip install widdx[telegram]
    $env:TELEGRAM_BOT_TOKEN = "123456:ABC-DEF..."
    widdx bot start
    """
    from .telegram_bot import run_bot
    run_bot()


main.add_command(bot)


if __name__ == "__main__":
    main()
