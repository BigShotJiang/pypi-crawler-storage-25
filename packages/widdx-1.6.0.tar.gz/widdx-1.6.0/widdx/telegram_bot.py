"""WIDDX Telegram Bot — Control your AI agent from Telegram.

Start:
    python -m widdx.telegram_bot

Or:
    widdx bot start

Setup:
    1. Create a bot via @BotFather on Telegram
    2. Get your bot token
    3. Set it: TELEGRAM_BOT_TOKEN env var or ~/.widdx/config.yaml

    telegram:
      bot_token: "123456:ABC-DEF1234ghijkl"
      allowed_users: []  # empty = anyone, or list of Telegram user IDs
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from telegram import Update
    from telegram.ext import ContextTypes

logger = logging.getLogger("widdx.telegram")


class WiddxTelegramBot:
    """Telegram bot that forwards messages to WIDDX and returns results."""

    def __init__(self, token: str, router, config: dict[str, Any],
                 memory=None, allowed_users: list[int] | None = None) -> None:
        self._token = token
        self._router = router
        self._config = config
        self._memory = memory
        self._allowed_users = set(allowed_users) if allowed_users else None
        self._active_tasks: dict[int, asyncio.Task] = {}

    async def start(self) -> None:
        """Start the bot (blocking)."""
        try:
            from telegram import Update
            from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
        except ImportError:
            logger.error(
                "python-telegram-bot not installed. "
                "Run: pip install widdx[telegram]"
            )
            return

        app = Application.builder().token(self._token).build()

        app.add_handler(CommandHandler("start", self._cmd_start))
        app.add_handler(CommandHandler("help", self._cmd_help))
        app.add_handler(CommandHandler("status", self._cmd_status))
        app.add_handler(CommandHandler("providers", self._cmd_providers))
        app.add_handler(CommandHandler("key", self._cmd_key))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_message))

        me = await app.bot.get_me()
        logger.info("WIDDX Telegram Bot started: @%s", me.username)
        print(f"  [success]✓[/] Telegram Bot @{me.username} is running")
        print(f"  [dim]Send messages to @{me.username} on Telegram[/]")

        try:
            await app.run_polling()
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")

    # ── Security check ────────────────────────────────────────────

    async def _check_access(self, update: Update) -> bool:
        if self._allowed_users is None:
            return True
        user_id = update.effective_user.id if update.effective_user else 0
        return user_id in self._allowed_users

    # ── Commands ───────────────────────────────────────────────────

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            await update.message.reply_text("⛔ Access denied.")
            return
        await update.message.reply_text(
            "🤖 *WIDDX AI Agent*\n\n"
            "Send me any task and I'll build it for you.\n\n"
            "Commands:\n"
            "/help — Show help\n"
            "/status — Session status\n"
            "/providers — Manage AI providers\n"
            "/key — Set DeepSeek API key",
            parse_mode="Markdown",
        )

    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        providers = self._router.list_providers()
        active = sum(1 for p in providers if p["enabled"])
        dsk = self._config.get("__env__", {}).get("deepseek_key")
        key_status = "✓ set" if dsk else "not set"

        await update.message.reply_text(
            f"🤖 *WIDDX v1.5*\n\n"
            f"Providers: {active}/{len(providers)} active\n"
            f"API Key: {key_status}\n\n"
            f"*Commands*\n"
            f"/start — Welcome\n"
            f"/help — This message\n"
            f"/status — Session stats\n"
            f"/providers — List providers\n"
            f"/key <sk-...> — Set API key\n\n"
            f"*Or just send a task:*\n"
            f"\"create a REST API with FastAPI\"\n"
            f"\"fix the auth bug in login.py\"",
            parse_mode="Markdown",
        )

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        tokens = self._router.session_tokens
        cost = self._router.session_cost
        await update.message.reply_text(
            f"📊 *Session Status*\n\n"
            f"Tokens: ↑{tokens['input']} ↓{tokens['output']}\n"
            f"Cost: ${cost:.4f}\n"
            f"Model: {self._config.get('models', {}).get('executor', {}).get('model', 'deepseek')}",
            parse_mode="Markdown",
        )

    async def _cmd_providers(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        providers = self._router.list_providers()
        lines = ["📡 *AI Providers*\n"]
        for p in providers:
            icon = "✅" if p["enabled"] else "❌"
            mc = p.get("model_count", 1)
            lines.append(f"{icon} *{p['name']}* ({mc} models)")
            lines.append(f"  `{p['executor_model']}`")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def _cmd_key(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            return
        key = " ".join(context.args) if context.args else ""
        if not key:
            dsk = self._config.get("__env__", {}).get("deepseek_key")
            if dsk:
                masked = dsk[:8] + "..." + dsk[-4:]
                await update.message.reply_text(f"🔑 Key: `{masked}`\nSend `/key sk-...` to change.")
            else:
                await update.message.reply_text("🔑 No key set.\nSend `/key sk-...` to add DeepSeek.")
            return

        from widdx.config import save_config_key
        save_config_key("deepseek_api_key", key)
        self._config["deepseek_api_key"] = key
        self._config["__env__"]["deepseek_key"] = key
        await update.message.reply_text("✅ API key saved and active.")

    # ── Task handling ──────────────────────────────────────────────

    async def _handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._check_access(update):
            await update.message.reply_text("⛔ Access denied.")
            return

        task = update.message.text.strip()
        if not task:
            return

        # Show typing indicator
        await update.message.chat.send_action("typing")

        # Run task in thread pool to not block the bot
        result = await asyncio.to_thread(self._run_task, task)

        # Send result (truncate if too long for Telegram)
        if len(result) > 4000:
            await update.message.reply_text(
                result[:4000] + "\n\n… (truncated)",
                parse_mode="Markdown",
            )
        else:
            await update.message.reply_text(result, parse_mode="Markdown")

    def _run_task(self, task: str) -> str:
        """Execute task via ToolLoop and return formatted result."""
        from .tool_loop import ToolLoop
        import time

        tool_loop = ToolLoop(self._router)
        start = time.time()

        try:
            output = tool_loop.run(task)
        except Exception as e:
            return f"❌ Error: {e}"

        elapsed = time.time() - start
        elapsed_str = f"{elapsed:.0f}s" if elapsed < 60 else f"{int(elapsed//60)}m{int(elapsed%60)}s"
        tool_count = tool_loop._tool_calls_count
        files = len(
            list(dict.fromkeys(tool_loop._created_files + tool_loop._edited_files))
        )

        # Format output
        result = output or "Done."
        lines = []

        if files:
            lines.append(f"📁 *Files changed:* {files}")
            for f in list(dict.fromkeys(tool_loop._created_files + tool_loop._edited_files))[:10]:
                lines.append(f"  • `{f}`")

        if result:
            preview = result[:1500]
            if len(result) > 1500:
                preview += "\n\n… (truncated)"
            lines.append(f"\n{preview}")

        lines.append(f"\n⏱ {elapsed_str} · 🔧 {tool_count} tools · 📁 {files} files")
        return "\n".join(lines)


# ── Entry point ─────────────────────────────────────────────────────

def run_bot() -> None:
    """CLI entry point: widdx bot start"""
    import os
    from widdx.config import load_config, USER_CONFIG

    config = load_config()
    tg_config = config.get("telegram", {})
    token = os.getenv("TELEGRAM_BOT_TOKEN") or tg_config.get("bot_token")

    if not token:
        print("  [error]✗ TELEGRAM_BOT_TOKEN not set.[/]")
        print("  [dim]Set env: $env:TELEGRAM_BOT_TOKEN = 'your-token'[/]")
        print("  [dim]Or add to ~/.widdx/config.yaml:[/]")
        print("  [dim]  telegram:[/]")
        print("  [dim]    bot_token: 'your-token'[/]")
        return

    from widdx.memory import MemoryStore
    from widdx.router import AIRouter

    mem_path = config.get("memory", {}).get("db_path", "~/.widdx/memory.db")
    memory = MemoryStore(mem_path)
    router = AIRouter(config, memory)

    allowed = tg_config.get("allowed_users")
    if allowed and not isinstance(allowed, list):
        allowed = [allowed]

    bot = WiddxTelegramBot(
        token=token,
        router=router,
        config=config,
        memory=memory,
        allowed_users=allowed,
    )

    asyncio.run(bot.start())


if __name__ == "__main__":
    run_bot()
