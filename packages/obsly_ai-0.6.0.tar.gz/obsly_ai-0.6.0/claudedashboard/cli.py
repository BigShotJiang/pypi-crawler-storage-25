#!/usr/bin/env python3
"""
claude-dashboard CLI — unified entry point.

Usage:
    claude-dashboard                  # live SSE dashboard (default)
    claude-dashboard live [--port N]  # same, explicit
    claude-dashboard report           # one-shot HTML report
    claude-dashboard burndown         # weekly burndown chart
    claude-dashboard analyze          # text summary to stdout
    claude-dashboard menubar          # macOS menubar app
    claude-dashboard proxy [--port N] # LLM traffic proxy (mitmproxy)
    claude-dashboard server [--port N]# team dashboard
    claude-dashboard doctor           # health checks
    claude-dashboard config           # show/set proxy configuration
    claude-dashboard login             # open SaaS devices page for bootstrap
"""

import argparse
import sys
import webbrowser


def _build_parser():
    parser = argparse.ArgumentParser(
        prog="claude-dashboard",
        description="Real-time token usage monitor for Claude Code",
    )
    sub = parser.add_subparsers(dest="command")

    # live (default)
    p_live = sub.add_parser("live", help="Start the live SSE dashboard (default)")
    p_live.add_argument("--port", type=int, default=8765)
    p_live.add_argument("--no-browser", action="store_true")
    p_live.add_argument("--plan", choices=["5x", "20x"], default=None,
                        help="Max subscription (5x=$100/mo, 20x=$200/mo)")

    # report
    sub.add_parser("report", help="Generate a one-shot HTML report")

    # burndown
    p_burn = sub.add_parser("burndown", help="Weekly burndown chart")
    p_burn.add_argument("--cycles", type=int, default=9)
    p_burn.add_argument("--no-browser", action="store_true")

    # analyze
    sub.add_parser("analyze", help="Text-based token usage summary")

    # tray (cross-platform: macOS menubar, Windows/Linux system tray)
    sub.add_parser("tray", help="Cross-platform tray icon (macOS/Windows/Linux)")
    # menubar — macOS launchd background agent (with foreground `run` fallback)
    p_menubar = sub.add_parser(
        "menubar",
        help="macOS menubar (background agent or foreground run)",
    )
    p_menubar.add_argument(
        "action", nargs="?", default="run",
        choices=["run", "install", "uninstall", "status"],
        help="run = foreground (default); install/uninstall/status manage the launchd agent",
    )
    p_menubar.add_argument(
        "--dry-run", action="store_true",
        help="For install/uninstall: print what would happen without touching disk",
    )

    # proxy — foreground run or launchd background agent
    p_proxy = sub.add_parser(
        "proxy",
        help="LLM traffic proxy (foreground or launchd agent)",
    )
    p_proxy.add_argument(
        "action", nargs="?", default="run",
        choices=["run", "install", "uninstall", "status"],
        help="run = foreground (default); install/uninstall/status manage the launchd agent",
    )
    p_proxy.add_argument("--port", type=int, default=None)
    p_proxy.add_argument("--no-browser", action="store_true")
    p_proxy.add_argument(
        "--dry-run", action="store_true",
        help="For install/uninstall: print what would happen without touching disk",
    )

    # run-with-proxy — wrapper that sets HTTPS_PROXY and execs a command
    p_rwp = sub.add_parser(
        "run-with-proxy",
        help="Run a command with HTTPS_PROXY set to the local Obsly proxy",
    )
    p_rwp.add_argument(
        "cmd", nargs=argparse.REMAINDER,
        help="Command and arguments to run (use -- to pass flags)",
    )

    # server
    p_server = sub.add_parser("server", help="Team dashboard web server")
    p_server.add_argument("--port", type=int, default=None)
    p_server.add_argument("--no-browser", action="store_true")

    # doctor
    sub.add_parser("doctor", help="Run proxy health checks")

    # login
    p_login = sub.add_parser("login", help="Open the team-usage devices page in a browser")
    p_login.add_argument("--device-token", default=None, help="Optional device token to store locally")

    # config
    p_config = sub.add_parser("config", help="Show/set proxy configuration")
    p_config.add_argument("action", nargs="?", default="show", choices=["show", "set", "reset"])
    p_config.add_argument("key", nargs="?")
    p_config.add_argument("value", nargs="?")

    # version
    sub.add_parser("version", help="Show version")

    # ── AI Attribution commands ──────────────────────────────────────
    # Canonical names: install / uninstall / status (since the binary is
    # already called `obsly-ai`, the legacy `ai-` prefix is redundant).
    # Legacy `ai-install` / `ai-uninstall` / `ai-status` are kept as
    # deprecated aliases — see _DEPRECATED_ALIASES below.
    def _add_install_parser(name):
        p = sub.add_parser(name, help="Install AI attribution hooks")
        p.add_argument("--agent", default="all",
                       choices=["claude-code", "codex", "cursor", "windsurf", "copilot-cli", "all"])
        p.add_argument("--dry-run", action="store_true")
        return p

    def _add_uninstall_parser(name):
        p = sub.add_parser(name, help="Remove AI attribution hooks")
        p.add_argument("--agent", default="all",
                       choices=["claude-code", "codex", "cursor", "windsurf", "copilot-cli", "all"])
        p.add_argument("--dry-run", action="store_true")
        return p

    _add_install_parser("install")
    _add_uninstall_parser("uninstall")
    sub.add_parser("status", help="Show AI attribution hook status")

    # Deprecated aliases (kept for ≥2 releases)
    _add_install_parser("ai-install")
    _add_uninstall_parser("ai-uninstall")
    sub.add_parser("ai-status", help="(deprecated) use `status`")

    p_ai_cp = sub.add_parser("ai-checkpoint", help="Hook entrypoint (called by agents)")
    p_ai_cp.add_argument("agent", nargs="?", default=None)
    p_ai_cp.add_argument("--hook-input", default=None)
    p_ai_cp.add_argument("--pre-commit", action="store_true")
    p_ai_cp.add_argument("--post-commit", action="store_true")
    p_ai_cp.add_argument("--post-rewrite", action="store_true")

    p_ai_blame = sub.add_parser("ai-blame", help="Show per-line AI attribution")
    p_ai_blame.add_argument("file", help="File to blame")
    p_ai_blame.add_argument("-L", dest="lines", default=None, help="Line range: start,end")
    p_ai_blame.add_argument("--commit", default="HEAD")
    p_ai_blame.add_argument("--json", action="store_true")
    p_ai_blame.add_argument("--cost", action="store_true")
    p_ai_blame.add_argument("--no-color", action="store_true")

    p_ai_stats = sub.add_parser("ai-stats", help="Show AI code statistics")
    p_ai_stats.add_argument("--repo", action="store_true", help="Repo-wide stats")
    p_ai_stats.add_argument("--commit", default=None, help="Specific commit SHA")
    p_ai_stats.add_argument("--branch", default=None)
    p_ai_stats.add_argument("--since", default=None)
    p_ai_stats.add_argument("--limit", type=int, default=100)
    p_ai_stats.add_argument("--json", action="store_true")
    p_ai_stats.add_argument("--durability", action="store_true")

    sub.add_parser("ai-cleanup", help="Clean up stale AI attribution data")

    return parser


def main():
    parser = _build_parser()
    args = parser.parse_args()
    cmd = args.command

    # Deprecated alias warning (#29) — `ai-install`/`ai-uninstall`/`ai-status`
    _DEPRECATED_ALIASES = {
        "ai-install":   "install",
        "ai-uninstall": "uninstall",
        "ai-status":    "status",
    }
    if cmd in _DEPRECATED_ALIASES:
        print(
            f"warning: `{cmd}` is deprecated, use `{_DEPRECATED_ALIASES[cmd]}` instead",
            file=sys.stderr,
        )

    # PyPI update check (#13) — silent, cached, never blocks hooks
    _maybe_notify_update(cmd)

    # Default to live dashboard when no subcommand given
    if cmd is None or cmd == "live":
        from claudedashboard.live import main as live_main
        # Re-parse with live's own argparse if called as default
        if cmd is None:
            sys.argv = [sys.argv[0]]  # reset so live's parser doesn't choke
        else:
            # Pass through flags
            live_args = [sys.argv[0]]
            if hasattr(args, "port") and args.port != 8765:
                live_args += ["--port", str(args.port)]
            if hasattr(args, "no_browser") and args.no_browser:
                live_args += ["--no-browser"]
            if hasattr(args, "plan") and args.plan:
                live_args += ["--plan", args.plan]
            sys.argv = live_args
        live_main()

    elif cmd == "report":
        from claudedashboard.report import main as report_main
        report_main()

    elif cmd == "burndown":
        burn_args = [sys.argv[0]]
        if args.cycles != 9:
            burn_args += ["--cycles", str(args.cycles)]
        if args.no_browser:
            burn_args += ["--no-browser"]
        sys.argv = burn_args
        from claudedashboard.burndown import main as burndown_main
        burndown_main()

    elif cmd == "analyze":
        from claudedashboard.analyze import main as analyze_main
        analyze_main()

    elif cmd == "tray":
        from claudedashboard import tray
        tray.run_tray()

    elif cmd == "menubar":
        action = getattr(args, "action", "run")
        if action == "run":
            from claudedashboard import tray
            tray.run_tray()
        elif action == "install":
            from claudedashboard import menubar_service
            result = menubar_service.install(dry_run=args.dry_run)
            print(f"plist: {result['plist']}")
            if args.dry_run:
                print("(dry-run) no changes made")
            else:
                print(f"bootstrap: {'ok' if result['bootstrap_ok'] else 'failed'}")
                if result.get('bootstrap_msg'):
                    print(result['bootstrap_msg'].strip())
        elif action == "uninstall":
            from claudedashboard import menubar_service
            result = menubar_service.uninstall(dry_run=args.dry_run)
            if args.dry_run:
                print(f"(dry-run) would remove: {result['plist']}")
            else:
                print(f"removed: {result['removed']}")
        elif action == "status":
            from claudedashboard import menubar_service
            print(menubar_service.status())

    elif cmd == "proxy":
        action = getattr(args, "action", "run")
        if action == "run":
            from claudedashboard.proxy.commands import cmd_proxy
            cmd_proxy(port=args.port, no_browser=args.no_browser)
        elif action == "install":
            from claudedashboard import proxy_service
            result = proxy_service.install(dry_run=args.dry_run)
            if result.get("refused"):
                print(f"refused: {result['reason']}", file=sys.stderr)
                sys.exit(2)
            print(f"plist: {result['plist']}")
            if args.dry_run:
                print("(dry-run) no changes made")
            else:
                print(f"bootstrap: {'ok' if result['bootstrap_ok'] else 'failed'}")
                if result.get("bootstrap_msg"):
                    print(result["bootstrap_msg"].strip())
        elif action == "uninstall":
            from claudedashboard import proxy_service
            result = proxy_service.uninstall(dry_run=args.dry_run)
            if args.dry_run:
                print(f"(dry-run) would remove: {result['plist']}")
            else:
                print(f"removed: {result['removed']}")
        elif action == "status":
            from claudedashboard import proxy_service
            print(proxy_service.status())

    elif cmd == "run-with-proxy":
        from claudedashboard import run_with_proxy as rwp
        argv = list(args.cmd or [])
        if argv and argv[0] == "--":
            argv = argv[1:]
        sys.exit(rwp.run(argv))

    elif cmd == "server":
        from claudedashboard.proxy.commands import cmd_server
        cmd_server(port=args.port, no_browser=args.no_browser)

    elif cmd == "doctor":
        from claudedashboard.proxy.commands import cmd_doctor
        cmd_doctor()

    elif cmd == "login":
        from claudedashboard.gitai.obsly_config import set_value
        set_value("server", "https://ai.obsly.io")
        if getattr(args, "device_token", None):
            set_value("device_token", args.device_token)
            print("device_token stored")
        login_url = "https://ai.obsly.io/dashboard/settings?cli=1#devices"
        webbrowser.open(login_url)
        print(login_url)

    elif cmd == "config":
        # obsly-ai server config (server, token) lives in ~/.obsly-ai/config.json.
        # Anything else falls through to the proxy config for backwards compat.
        if args.key in ("server", "token", "device_token"):
            from claudedashboard.gitai.obsly_config import set_value, show as obsly_show
            if args.action == "set" and args.value is not None:
                set_value(args.key, args.value)
                print(f"  {args.key} = {args.value}")
            else:
                obsly_show()
        elif args.action == "show" and args.key is None:
            from claudedashboard.gitai.obsly_config import show as obsly_show
            obsly_show()
        else:
            from claudedashboard.proxy.commands import cmd_config
            cmd_config(action=args.action, key=args.key, value=args.value)

    elif cmd == "version":
        from claudedashboard import __version__
        print(f"claude-dashboard {__version__}")

    # ── AI Attribution dispatch ──────────────────────────────────────

    elif cmd in ("install", "ai-install"):
        _ai_install(args)

    elif cmd in ("uninstall", "ai-uninstall"):
        _ai_uninstall(args)

    elif cmd in ("status", "ai-status"):
        _ai_status()

    elif cmd == "ai-checkpoint":
        _ai_checkpoint(args)

    elif cmd == "ai-blame":
        _ai_blame(args)

    elif cmd == "ai-stats":
        _ai_stats(args)

    elif cmd == "ai-cleanup":
        _ai_cleanup()


def _maybe_notify_update(cmd):
    """Print a stderr update notice when a newer obsly-ai is on PyPI.

    Skipped for hook entrypoints (ai-checkpoint) so we never inflate the
    100ms hook budget. Network errors are silenced inside check_for_update.
    """
    if cmd == "ai-checkpoint":
        return
    try:
        from claudedashboard import __version__
        from claudedashboard.version_check import check_for_update, format_update_message
        latest = check_for_update(__version__)
        msg = format_update_message(__version__, latest)
        if msg:
            print(msg, file=sys.stderr)
    except Exception:
        pass


def _ai_install(args):
    import shutil
    binary = shutil.which("claude-dashboard") or sys.executable + " -m claudedashboard"
    from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
    from claudedashboard.gitai.hooks.codex import CodexInstaller
    from claudedashboard.gitai.hooks.cursor import CursorInstaller
    from claudedashboard.gitai.hooks.windsurf import WindsurfInstaller
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller

    installers = {
        "claude-code": ClaudeCodeInstaller,
        "codex": CodexInstaller,
        "cursor": CursorInstaller,
        "windsurf": WindsurfInstaller,
        "copilot-cli": CopilotCliInstaller,
    }

    targets = installers if args.agent == "all" else {args.agent: installers[args.agent]}
    for name, cls in targets.items():
        inst = cls()
        detected, installed, _ = inst.check()
        if not detected:
            print(f"  {inst.name():<12} not detected")
            continue
        if installed and not args.dry_run:
            print(f"  {inst.name():<12} already installed")
            continue
        result = inst.install(binary, dry_run=args.dry_run)
        prefix = "(dry-run) " if args.dry_run else ""
        if result:
            print(f"  {inst.name():<12} {prefix}installed")
        else:
            print(f"  {inst.name():<12} {prefix}already up to date")

    # Git hooks
    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    repo = get_repo_root(os.getcwd())
    if repo:
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        gh = GitHooksInstaller()
        results = gh.install(repo, binary, dry_run=args.dry_run)
        for hook_name, status in results.items():
            prefix = "(dry-run) " if args.dry_run else ""
            print(f"  git {hook_name:<14} {prefix}{status}")


def _ai_uninstall(args):
    from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
    from claudedashboard.gitai.hooks.codex import CodexInstaller
    from claudedashboard.gitai.hooks.cursor import CursorInstaller
    from claudedashboard.gitai.hooks.windsurf import WindsurfInstaller
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller

    installers = {
        "claude-code": ClaudeCodeInstaller,
        "codex": CodexInstaller,
        "cursor": CursorInstaller,
        "windsurf": WindsurfInstaller,
        "copilot-cli": CopilotCliInstaller,
    }
    targets = installers if args.agent == "all" else {args.agent: installers[args.agent]}
    for name, cls in targets.items():
        inst = cls()
        result = inst.uninstall(dry_run=args.dry_run)
        if result:
            print(f"  {inst.name():<12} uninstalled")

    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    repo = get_repo_root(os.getcwd())
    if repo:
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        GitHooksInstaller().uninstall(repo, dry_run=args.dry_run)
        print("  git hooks    uninstalled")


def _ai_status():
    from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
    from claudedashboard.gitai.hooks.codex import CodexInstaller
    from claudedashboard.gitai.hooks.cursor import CursorInstaller
    from claudedashboard.gitai.hooks.windsurf import WindsurfInstaller
    from claudedashboard.gitai.hooks.copilot_cli import CopilotCliInstaller

    print("AI Attribution Status\n")
    for cls in [ClaudeCodeInstaller, CodexInstaller, CursorInstaller, WindsurfInstaller, CopilotCliInstaller]:
        inst = cls()
        detected, installed, up_to_date = inst.check()
        if not detected:
            mark = "  not detected"
        elif installed:
            mark = "  ✓ installed"
        else:
            mark = "  ✗ not installed"
        print(f"  {inst.name():<12}{mark}")

    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    repo = get_repo_root(os.getcwd())
    if repo:
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        results = GitHooksInstaller().check(repo)
        print()
        for hook_name, ok in results.items():
            mark = "✓" if ok else "✗"
            print(f"  git {hook_name:<14} {mark}")

        from claudedashboard.gitai.working_log import WorkingLog
        from claudedashboard.gitai.git_notes import get_head_sha
        wl = WorkingLog(repo)
        head = get_head_sha(repo)
        if head:
            stats = wl.uncommitted_stats(head)
            if stats["checkpoint_count"] > 0:
                print(f"\n  Working log: {stats['checkpoint_count']} checkpoints "
                      f"({stats['ai_checkpoints']} AI), "
                      f"{stats['total_ai_lines']} AI lines uncommitted")


def _ai_checkpoint(args):
    if args.pre_commit:
        from claudedashboard.gitai.hook_handler import handle_git_hook
        handle_git_hook("pre-commit")
    elif args.post_commit:
        from claudedashboard.gitai.hook_handler import handle_git_hook
        handle_git_hook("post-commit")
    elif args.post_rewrite:
        from claudedashboard.gitai.hook_handler import handle_git_hook
        handle_git_hook("post-rewrite")
    elif args.agent and args.hook_input == "stdin":
        from claudedashboard.gitai.hook_handler import main as hook_main
        hook_main(args.agent, hook_source="stdin")
    else:
        print("Usage: claude-dashboard ai-checkpoint <agent> --hook-input stdin", file=sys.stderr)
        print("   or: claude-dashboard ai-checkpoint --post-commit", file=sys.stderr)
        sys.exit(1)


def _ai_blame(args):
    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    repo = get_repo_root(os.getcwd())
    if not repo:
        print("Not in a git repository", file=sys.stderr)
        sys.exit(1)

    from claudedashboard.gitai.blame import blame, format_terminal, format_json

    start_line = end_line = None
    if args.lines:
        parts = args.lines.split(",")
        start_line = int(parts[0])
        end_line = int(parts[1]) if len(parts) > 1 else start_line

    lines = blame(repo, args.file, commit=args.commit,
                   start_line=start_line, end_line=end_line)
    if not lines:
        print(f"No data for {args.file}")
        return

    if args.json:
        print(format_json(lines, args.file, args.commit))
    else:
        print(format_terminal(lines, args.file, args.commit,
                               show_cost=args.cost, no_color=args.no_color))


def _ai_stats(args):
    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    repo = get_repo_root(os.getcwd())
    if not repo:
        print("Not in a git repository", file=sys.stderr)
        sys.exit(1)

    from claudedashboard.gitai.stats import (
        stats_for_commit, stats_for_repo,
        format_commit_terminal, format_stats_json, format_oneliner,
    )

    if args.durability:
        from claudedashboard.gitai.durability import analyze_durability, durability_by_agent, format_durability_terminal
        records = analyze_durability(repo, limit=args.limit)
        if not records:
            print("No AI attribution data found")
            return
        by_agent = durability_by_agent(records)
        if args.json:
            import json
            print(json.dumps(by_agent, indent=2))
        else:
            print(format_durability_terminal(by_agent))
        return

    if args.commit:
        stats = stats_for_commit(repo, args.commit)
        if not stats:
            print(f"No AI data for commit {args.commit}")
            return
        print(format_stats_json(stats) if args.json else format_commit_terminal(stats))
    else:
        stats = stats_for_repo(repo, limit=args.limit, since=args.since)
        if stats.commits_with_ai == 0:
            print("No AI attribution data found")
            return
        if args.json:
            print(format_stats_json(stats))
        else:
            print(format_oneliner(stats))
            for cs in stats.commits[:10]:
                print(f"  {cs.commit_sha[:7]} {cs.ai_percentage:5.1f}% AI  {cs.message[:50]}")


def _ai_cleanup():
    import os
    from claudedashboard.gitai.git_notes import get_repo_root
    from claudedashboard.gitai.working_log import WorkingLog
    repo = get_repo_root(os.getcwd())
    if not repo:
        print("Not in a git repository", file=sys.stderr)
        sys.exit(1)
    wl = WorkingLog(repo)
    snaps = wl.cleanup_stale_snapshots()
    print(f"Cleaned up {snaps} stale snapshots")


if __name__ == "__main__":
    main()
