"""Claude Dashboard — Real-time token usage monitor for Claude Code."""

__version__ = "0.6.0"
