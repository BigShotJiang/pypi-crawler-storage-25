"""TDD for hook installers — red to green."""
import json, os, subprocess
import pytest


@pytest.fixture
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Test"],
                   check=True, capture_output=True)
    (tmp_path / "README.md").write_text("# Test\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "."], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "init"],
                   check=True, capture_output=True)
    return tmp_path


BINARY = "/usr/local/bin/claude-dashboard"


# ── Claude Code ──────────────────────────────────────────────────────

class TestClaudeCode:

    def test_install_empty_settings(self, tmp_path):
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        config_dir = tmp_path / ".claude"
        installer = ClaudeCodeInstaller(config_dir=config_dir)
        diff = installer.install(BINARY)
        assert diff is not None
        data = json.loads((config_dir / "settings.json").read_text())
        pre_hooks = data["hooks"]["PreToolUse"]
        assert any(
            block.get("matcher") == "*"
            and any("ai-checkpoint claude-code" in h.get("command", "") for h in block.get("hooks", []))
            for block in pre_hooks
        )

    def test_install_preserves_existing(self, tmp_path):
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        config_dir = tmp_path / ".claude"
        config_dir.mkdir()
        (config_dir / "settings.json").write_text(json.dumps({
            "permissions": {"allow": ["Read"]},
            "hooks": {"PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command", "command": "my-linter"}]}]}
        }))
        installer = ClaudeCodeInstaller(config_dir=config_dir)
        installer.install(BINARY)
        data = json.loads((config_dir / "settings.json").read_text())
        assert data["permissions"]["allow"] == ["Read"]
        assert any(b["matcher"] == "Bash" for b in data["hooks"]["PreToolUse"])

    def test_install_idempotent(self, tmp_path):
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        installer = ClaudeCodeInstaller(config_dir=tmp_path / ".claude")
        installer.install(BINARY)
        diff = installer.install(BINARY)
        assert diff is None

    def test_uninstall(self, tmp_path):
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        installer = ClaudeCodeInstaller(config_dir=tmp_path / ".claude")
        installer.install(BINARY)
        diff = installer.uninstall()
        assert diff is not None
        data = json.loads((tmp_path / ".claude" / "settings.json").read_text())
        for blocks in data.get("hooks", {}).values():
            for block in blocks:
                for h in block.get("hooks", []):
                    assert "ai-checkpoint" not in h.get("command", "")

    def test_check(self, tmp_path):
        from claudedashboard.gitai.hooks.claude_code import ClaudeCodeInstaller
        config_dir = tmp_path / ".claude"
        config_dir.mkdir()
        installer = ClaudeCodeInstaller(config_dir=config_dir)
        detected, installed, up_to_date = installer.check()
        assert detected is True
        assert installed is False


# ── Codex ────────────────────────────────────────────────────────────

class TestCodex:

    def test_install(self, tmp_path):
        from claudedashboard.gitai.hooks.codex import CodexInstaller
        installer = CodexInstaller(config_dir=tmp_path / ".codex")
        installer.install(BINARY)
        data = json.loads((tmp_path / ".codex" / "hooks.json").read_text())
        assert "PreToolUse" in data["hooks"]
        assert "PostToolUse" in data["hooks"]
        assert "Stop" in data["hooks"]


# ── Cursor ───────────────────────────────────────────────────────────

class TestCursor:

    def test_install_camelcase(self, tmp_path):
        from claudedashboard.gitai.hooks.cursor import CursorInstaller
        installer = CursorInstaller(config_dir=tmp_path / ".cursor")
        installer.install(BINARY)
        data = json.loads((tmp_path / ".cursor" / "hooks.json").read_text())
        assert "preToolUse" in data["hooks"]
        assert "postToolUse" in data["hooks"]
        assert data.get("version") == 1


# ── Git Hooks ────────────────────────────────────────────────────────

class TestGitHooks:

    def test_install(self, git_repo):
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        installer = GitHooksInstaller()
        installer.install(str(git_repo), BINARY)
        pre_commit = git_repo / ".git" / "hooks" / "pre-commit"
        assert pre_commit.exists()
        assert os.access(str(pre_commit), os.X_OK)
        assert "claude-dashboard" in pre_commit.read_text()
        post_commit = git_repo / ".git" / "hooks" / "post-commit"
        assert post_commit.exists()
        assert "ai-checkpoint --post-commit" in post_commit.read_text()

    def test_preserves_existing(self, git_repo):
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        hook_dir = git_repo / ".git" / "hooks"
        hook_dir.mkdir(exist_ok=True)
        pre = hook_dir / "pre-commit"
        pre.write_text("#!/bin/sh\nmy-linter\n")
        pre.chmod(0o755)
        installer = GitHooksInstaller()
        installer.install(str(git_repo), BINARY)
        content = pre.read_text()
        assert "my-linter" in content
        assert "claude-dashboard" in content

    def test_uninstall(self, git_repo):
        from claudedashboard.gitai.hooks.git_hooks import GitHooksInstaller
        installer = GitHooksInstaller()
        installer.install(str(git_repo), BINARY)
        installer.uninstall(str(git_repo))
        pre = git_repo / ".git" / "hooks" / "pre-commit"
        if pre.exists():
            assert "claude-dashboard" not in pre.read_text()
