"""Company management commands."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.resolve import resolve_id

app = typer.Typer(help="Manage Odoo companies.")


def _resolve_company_id(client: object, identifier: str) -> int:
    """Resolve company ID from numeric ID or name."""
    return resolve_id(client, "res.company", identifier, ilike=True, label="Company")  # type: ignore[arg-type]


@app.command("list")
def list_(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 80,
) -> None:
    """List companies."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    companies = c.search_read(
        "res.company",
        domain=[],
        fields=["id", "name", "email", "phone", "currency_id", "parent_id"],
        limit=limit,
        order="id",
    )

    rows = []
    json_data = []
    for co in companies:
        currency = co.get("currency_id")
        currency_name = currency[1] if isinstance(currency, list) else str(currency or "-")
        parent = co.get("parent_id")
        parent_name = parent[1] if isinstance(parent, list) else str(parent or "-") if parent else "-"

        rows.append(
            [
                str(co["id"]),
                co["name"],
                co.get("email") or "-",
                co.get("phone") or "-",
                currency_name,
                parent_name,
            ]
        )
        json_data.append(
            {
                "id": co["id"],
                "name": co["name"],
                "email": co.get("email"),
                "phone": co.get("phone"),
                "currency": currency_name,
                "parent": parent_name,
            }
        )

    out.table(
        f"Companies ({len(companies)})",
        [("ID", "cyan"), ("Name", ""), ("Email", "dim"), ("Phone", "dim"), ("Currency", ""), ("Parent", "dim")],
        rows,
        data_for_json=json_data,
    )


@app.command()
def get(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
) -> None:
    """Get company details."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    records = c.read(
        "res.company",
        [company_id],
        fields=[
            "id",
            "name",
            "email",
            "phone",
            "website",
            "vat",
            "currency_id",
            "parent_id",
            "child_ids",
            "street",
            "city",
            "zip",
            "country_id",
            "create_date",
            "write_date",
        ],
    )

    if not records:
        out.error(f"Company not found: {identifier}")
        raise typer.Exit(1)

    co = records[0]
    currency = co.get("currency_id")
    currency_name = currency[1] if isinstance(currency, list) else str(currency or "-")
    parent = co.get("parent_id")
    parent_name = parent[1] if isinstance(parent, list) else "-" if not parent else str(parent)
    country = co.get("country_id")
    country_name = country[1] if isinstance(country, list) else str(country or "-")

    sections = [
        (
            "Company Info",
            [
                ("ID", str(co["id"])),
                ("Name", co["name"]),
                ("Email", co.get("email") or "-"),
                ("Phone", co.get("phone") or "-"),
                ("Website", co.get("website") or "-"),
                ("VAT", co.get("vat") or "-"),
                ("Currency", currency_name),
                ("Parent", parent_name),
                ("Children", str(len(co.get("child_ids", [])))),
            ],
        ),
        (
            "Address",
            [
                ("Street", co.get("street") or "-"),
                ("City", co.get("city") or "-"),
                ("ZIP", co.get("zip") or "-"),
                ("Country", country_name),
            ],
        ),
        (
            "Dates",
            [
                ("Created", str(co.get("create_date", ""))),
                ("Updated", str(co.get("write_date", ""))),
            ],
        ),
    ]

    out.detail(f"Company: {co['name']}", sections, data_for_json=co)


@app.command()
def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", "-n", help="Company name")],
    email: Annotated[str | None, typer.Option("--email", help="Email")] = None,
    currency: Annotated[str | None, typer.Option("--currency", help="Currency code (e.g. USD, EUR)")] = None,
    parent: Annotated[str | None, typer.Option("--parent", help="Parent company ID or name")] = None,
) -> None:
    """Create a new company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    vals: dict = {"name": name}
    if email:
        vals["email"] = email
    if currency:
        currency_ids = c.search("res.currency", [("name", "=", currency.upper())])
        if not currency_ids:
            out.error(f"Currency not found: {currency}")
            raise typer.Exit(1)
        vals["currency_id"] = currency_ids[0]
    if parent:
        vals["parent_id"] = _resolve_company_id(c, parent)

    company_id = c.create("res.company", vals)
    out.success(f"Created company '{name}' (ID: {company_id})")


@app.command()
def update(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
    name: Annotated[str | None, typer.Option("--name", "-n", help="New name")] = None,
    email: Annotated[str | None, typer.Option("--email", help="Email")] = None,
    phone: Annotated[str | None, typer.Option("--phone", help="Phone")] = None,
    website: Annotated[str | None, typer.Option("--website", help="Website")] = None,
) -> None:
    """Update a company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    vals: dict = {}
    if name is not None:
        vals["name"] = name
    if email is not None:
        vals["email"] = email
    if phone is not None:
        vals["phone"] = phone
    if website is not None:
        vals["website"] = website

    if not vals:
        out.warn("No fields to update")
        return

    c.write("res.company", [company_id], vals)
    out.success(f"Updated company {identifier} (ID: {company_id})")


@app.command()
def users(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 80,
) -> None:
    """List users belonging to a company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    company_data = c.read("res.company", [company_id], fields=["name"])
    company_name = company_data[0]["name"] if company_data else str(company_id)

    user_records = c.search_read(
        "res.users",
        domain=[("company_ids", "in", [company_id])],
        fields=["id", "login", "name", "email", "active", "company_id"],
        limit=limit,
        order="login",
    )

    rows = []
    json_data = []
    for u in user_records:
        current_co = u.get("company_id")
        is_current = current_co[0] == company_id if isinstance(current_co, list) else False
        status = "[green]active[/green]" if u.get("active") else "[red]inactive[/red]"
        current_label = "[cyan]current[/cyan]" if is_current else ""

        rows.append([str(u["id"]), u["login"], u["name"], u.get("email") or "-", status, current_label])
        json_data.append(
            {
                "id": u["id"],
                "login": u["login"],
                "name": u["name"],
                "email": u.get("email"),
                "active": u.get("active"),
                "is_current_company": is_current,
            }
        )

    out.table(
        f"Users in '{company_name}' ({len(user_records)})",
        [("ID", "cyan"), ("Login", ""), ("Name", ""), ("Email", "dim"), ("Status", ""), ("Current Co.", "")],
        rows,
        data_for_json=json_data,
    )


@app.command("switch")
def switch_company(
    ctx: typer.Context,
    user_id: Annotated[int, typer.Argument(help="User ID")],
    company_id: Annotated[int, typer.Argument(help="Target company ID")],
) -> None:
    """Switch a user's current company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Verify user exists
    user_data = c.read("res.users", [user_id], fields=["login", "company_ids"])
    if not user_data:
        out.error(f"User not found: {user_id}")
        raise typer.Exit(1)

    # Verify company is in user's allowed companies
    allowed = user_data[0].get("company_ids", [])
    if company_id not in allowed:
        out.error(f"Company {company_id} is not in user's allowed companies: {allowed}")
        raise typer.Exit(1)

    c.write("res.users", [user_id], {"company_id": company_id})
    out.success(f"Switched user {user_data[0]['login']} (ID: {user_id}) to company ID {company_id}")


def _run_setup(
    c: object,
    out: object,
    *,
    name: str,
    template_id: int,
    street: str | None = None,
    city: str | None = None,
    phone: str | None = None,
    email: str | None = None,
    npwp: str | None = None,
    warehouse_prefix: str | None = None,
    skip_warehouses: bool = False,
    skip_fiscal_positions: bool = False,
    skip_extra_journals: bool = False,
    skip_report_formats: bool = False,
    dry_run: bool = False,
) -> dict | None:
    """Call CompanyOnboardingService.provision() via JSON-RPC."""
    # Verify company_management module is installed (renamed from
    # company_onboarding in 18.0.8.0.0).
    installed = c.search(
        "ir.module.module",
        [("name", "in", ["company_management", "company_onboarding"]), ("state", "=", "installed")],
    )
    if not installed:
        out.error("Module 'company_management' is not installed. Install it first.")
        raise typer.Exit(1)

    company_vals = {"name": name}
    if street:
        company_vals["street"] = street
    if city:
        company_vals["city"] = city
    if phone:
        company_vals["phone"] = phone
    if email:
        company_vals["email"] = email
    if npwp:
        company_vals["npwp"] = npwp
    if warehouse_prefix:
        company_vals["warehouse_code_prefix"] = warehouse_prefix

    options = {
        "clone_fiscal_positions": not skip_fiscal_positions,
        "clone_warehouses": not skip_warehouses,
        "clone_extra_journals": not skip_extra_journals,
        "clone_report_formats": not skip_report_formats,
    }

    if dry_run:
        out.info(f"[DRY RUN] Would create company '{name}' from template ID {template_id}")
        out.info(f"  Options: {options}")
        return None

    result = c.execute_kw(
        "company.onboarding.wizard",
        "action_provision_from_cli",
        [company_vals, template_id, options],
    )

    # Display results
    out.success(f"Created company '{result['company_name']}' (ID: {result['company_id']})")
    for step in result.get("steps", []):
        icon = {"ok": "✓", "skipped": "⊘", "error": "✗"}.get(step["status"], "?")
        style = "green" if step["status"] == "ok" else ("yellow" if step["status"] == "skipped" else "red")
        out.console.print(f"  [{style}]{icon}[/{style}] {step['name']}: {step['detail']}")

    out.console.print()
    out.console.print("[dim]Next steps:[/dim]")
    out.console.print("  1. Assign users:  kctl-odoo roles assign <login> --roles finance_user")
    out.console.print("  2. Configure bank: Settings → Companies → Giro/Cek Accounts")
    out.console.print("  3. Set tax office: Settings → Companies → Tax Settings")

    return result


@app.command()
def setup(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", "-n", help="Company name")],
    template: Annotated[str, typer.Option("--template", "-t", help="Template company ID or name")],
    street: Annotated[str | None, typer.Option(help="Street address")] = None,
    city: Annotated[str | None, typer.Option(help="City")] = None,
    phone: Annotated[str | None, typer.Option(help="Phone")] = None,
    email: Annotated[str | None, typer.Option(help="Email")] = None,
    npwp: Annotated[str | None, typer.Option(help="NPWP (Indonesian Tax ID)")] = None,
    warehouse_prefix: Annotated[
        str | None, typer.Option("--warehouse-prefix", help="3-char warehouse code prefix")
    ] = None,
    skip_warehouses: Annotated[bool, typer.Option("--skip-warehouses", help="Skip warehouse cloning")] = False,
    skip_fiscal_positions: Annotated[
        bool, typer.Option("--skip-fiscal-positions", help="Skip fiscal position cloning")
    ] = False,
    skip_extra_journals: Annotated[
        bool, typer.Option("--skip-extra-journals", help="Skip extra journal cloning")
    ] = False,
    skip_report_formats: Annotated[
        bool, typer.Option("--skip-report-formats", help="Skip report format provisioning")
    ] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without creating")] = False,
) -> None:
    """Create and provision a new company from a template.

    Installs l10n_id CoA (journals + taxes), then clones warehouses, fiscal
    positions, extra journals, and report formats from the template company.

    Requires the company_management module to be installed.

    Examples:
        kctl-odoo companies setup --name "CV Baru Import" --template 2
        kctl-odoo companies setup -n "CV Baru" -t "CV Sumber Pangan" --npwp "01.234.567.8-901.000"
        kctl-odoo companies setup -n "CV Test" -t 2 --skip-warehouses --dry-run
    """
    actx: AppContext = ctx.obj
    template_id = _resolve_company_id(actx.client, template)

    _run_setup(
        actx.client,
        actx.output,
        name=name,
        template_id=template_id,
        street=street,
        city=city,
        phone=phone,
        email=email,
        npwp=npwp,
        warehouse_prefix=warehouse_prefix,
        skip_warehouses=skip_warehouses,
        skip_fiscal_positions=skip_fiscal_positions,
        skip_extra_journals=skip_extra_journals,
        skip_report_formats=skip_report_formats,
        dry_run=dry_run,
    )


@app.command("setup-batch")
def setup_batch(
    ctx: typer.Context,
    csv_file: Annotated[Path, typer.Argument(help="CSV file with columns: name,street,city,npwp,warehouse_prefix")],
    template: Annotated[str, typer.Option("--template", "-t", help="Template company ID or name")],
    skip_warehouses: Annotated[bool, typer.Option("--skip-warehouses", help="Skip warehouse cloning")] = False,
    skip_report_formats: Annotated[
        bool, typer.Option("--skip-report-formats", help="Skip report format provisioning")
    ] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without creating")] = False,
) -> None:
    """Batch-create companies from a CSV file.

    CSV format (header required):
        name,street,city,npwp,warehouse_prefix
        CV Baru Import,Jl. Raya 1,Surabaya,01.234.567.8-901.000,BRI
        CV Lain Import,Jl. Lain 2,Jakarta,02.345.678.9-012.000,LNI

    Requires the company_management module to be installed.

    Examples:
        kctl-odoo companies setup-batch companies.csv --template 2
        kctl-odoo companies setup-batch companies.csv -t "CV Sumber Pangan" --dry-run
    """
    actx: AppContext = ctx.obj
    out = actx.output

    if not csv_file.exists():
        out.error(f"File not found: {csv_file}")
        raise typer.Exit(1)

    template_id = _resolve_company_id(actx.client, template)

    with csv_file.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        out.warn("CSV file is empty")
        return

    out.info(f"Processing {len(rows)} companies from {csv_file.name}")
    out.console.print()

    created, failed = 0, 0
    for i, row in enumerate(rows, 1):
        company_name = row.get("name", "").strip()
        if not company_name:
            out.warn(f"Row {i}: skipping — empty name")
            continue

        out.console.rule(f"[bold]{i}/{len(rows)}: {company_name}")
        try:
            result = _run_setup(
                actx.client,
                out,
                name=company_name,
                template_id=template_id,
                street=row.get("street", "").strip() or None,
                city=row.get("city", "").strip() or None,
                phone=row.get("phone", "").strip() or None,
                email=row.get("email", "").strip() or None,
                npwp=row.get("npwp", "").strip() or None,
                warehouse_prefix=row.get("warehouse_prefix", "").strip() or None,
                skip_warehouses=skip_warehouses,
                skip_report_formats=skip_report_formats,
                dry_run=dry_run,
            )
            if result:
                created += 1
        except (typer.Exit, Exception) as exc:
            out.error(f"Failed: {company_name} — {exc}")
            failed += 1

        out.console.print()

    out.console.rule("[bold]Summary")
    out.info(f"Created: {created}, Failed: {failed}, Total: {len(rows)}")


@app.command("bootstrap-baseline")
def bootstrap_baseline(
    ctx: typer.Context,
    company: Annotated[str, typer.Argument(help="Company ID or name (template or existing)")],
    all_companies: Annotated[bool, typer.Option("--all", help="Run on every company")] = False,
) -> None:
    """Retro-fit baseline setup on existing companies.

    Idempotent. For each target company, ensures:
      - At least one stock.warehouse exists (creates HDQ if missing)
      - At least one operating.unit exists (creates HDQ if missing — OCA optional)
      - Bank journals have default_account_id set

    Used to backfill the template company and pre-existing companies that
    were created before company_management was installed. Calls
    company.onboarding.service.bootstrap_baseline() server-side, which uses
    sudo() to bypass the stock_request and operating_unit access groups.

    Examples:
        kctl-odoo companies bootstrap-baseline 338
        kctl-odoo companies bootstrap-baseline _TEMPLATE_TPP_IMPORT
        kctl-odoo companies bootstrap-baseline --all _
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    installed = c.search(
        "ir.module.module",
        [("name", "in", ["company_management", "company_onboarding"]), ("state", "=", "installed")],
    )
    if not installed:
        out.error("Module 'company_management' is not installed.")
        raise typer.Exit(1)

    if all_companies:
        ids = [r["id"] for r in c.search_read("res.company", [], fields=["id"], order="id")]
    else:
        ids = [_resolve_company_id(c, company)]

    rows = []
    json_data = []
    for cid in ids:
        comp = c.read("res.company", [cid], fields=["id", "name"])
        cname = comp[0]["name"] if comp else f"id={cid}"
        try:
            result = c.execute_kw(
                "company.onboarding.wizard",
                "action_bootstrap_baseline_from_cli",
                [cid],
            )
            status = result.get("status", "?") if isinstance(result, dict) else "?"
            detail = result.get("detail", "") if isinstance(result, dict) else str(result)
        except Exception as e:
            status = "error"
            detail = str(e)
        rows.append([str(cid), cname, status, detail])
        json_data.append({"id": cid, "name": cname, "status": status, "detail": detail})
        icon = {"ok": "[green]OK[/green]", "error": "[red]ERR[/red]"}.get(status, status)
        out.console.print(f"  {icon} [{cid}] {cname}: {detail}")

    if actx.json_mode:
        out.raw_json(json_data)


@app.command("fix-products")
def fix_products(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
) -> None:
    """Fix product configuration: clear taxes, set lot tracking, fix UoM to CTN.

    For import companies where ALL products are imported (no domestic PPN).
    Clears multi-company tax contamination, sets tracking=lot for storable
    goods, creates CTN UoM if needed, and sets purchase_method=purchase.

    Examples:
        kctl-odoo companies fix-products -c 361
    """
    actx: AppContext = ctx.obj
    out = actx.output
    out.info(f"Fixing products for company {company_id}...")
    result = actx.client.execute_kw("company.coa.profile.applier", "fix_products", [company_id])
    out.success("Products fixed:")
    for k, v in (result or {}).items():
        out.info(f"  {k}: {v}")


@app.command("fix-partners")
def fix_partners(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
) -> None:
    """Fix partner configuration: set foreign vendor currencies.

    Detects Chinese/foreign vendors by name keywords and sets their
    supplier currency to CNY. Reports duplicate partners for human review.

    Examples:
        kctl-odoo companies fix-partners -c 361
    """
    actx: AppContext = ctx.obj
    out = actx.output
    out.info(f"Fixing partners for company {company_id}...")
    result = actx.client.execute_kw("company.coa.profile.applier", "fix_partners", [company_id])
    out.success("Partners fixed:")
    for k, v in (result or {}).items():
        out.info(f"  {k}: {v}")


@app.command("validate-products")
def validate_products_cmd(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues")] = False,
) -> None:
    """Validate product setup: taxes, tracking, UoM, purchase method, category.

    Examples:
        kctl-odoo companies validate-products -c 361
        kctl-odoo companies validate-products -c 361 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if fix:
        result = c.execute_kw("company.coa.profile.applier", "fix_products", [company_id])
        out.success("Products fixed:")
        for k, v in (result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_products", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    out.info(f"Product Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total products: {result['total_products']}")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    p = result.get("passed", 0)
    f = result.get("failed", 0)
    if f == 0:
        out.success(f"RESULT: {p}/{p + f} PASSED ✓")
    else:
        out.error(f"RESULT: {p}/{p + f} passed, {f} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-partners")
def validate_partners_cmd(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues")] = False,
) -> None:
    """Validate partner setup: currency, AR/AP, duplicates.

    Examples:
        kctl-odoo companies validate-partners -c 361
        kctl-odoo companies validate-partners -c 361 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if fix:
        result = c.execute_kw("company.coa.profile.applier", "fix_partners", [company_id])
        out.success("Partners fixed:")
        for k, v in (result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_partners", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    out.info(f"Partner Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total partners: {result['total_partners']}")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    p = result.get("passed", 0)
    f = result.get("failed", 0)
    if f == 0:
        out.success(f"RESULT: {p}/{p + f} PASSED ✓")
    else:
        out.error(f"RESULT: {p}/{p + f} passed, {f} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-journals")
def validate_journals_cmd(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID to validate")],
) -> None:
    """Validate journal configuration for a company.

    Checks: default accounts, journal types, duplicate codes, missing journals.

    Examples:
        kctl-odoo companies validate-journals -c 364
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    result = c.execute_kw("company.coa.profile.applier", "validate_journals", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Journal Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total journals: {result['total_journals']} — {result.get('by_type', {})}")
    out.info("─" * 50)

    rows = []
    for j in result.get("journals", []):
        rows.append([j["code"], j["name"], j["type"], j.get("default_account") or "-", j.get("currency", "IDR")])

    out.table(
        "Journals",
        [("Code", "cyan"), ("Name", ""), ("Type", ""), ("Default Account", ""), ("Currency", "")],
        rows,
    )

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")


@app.command("validate-banks")
def validate_banks_cmd(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID to validate")],
) -> None:
    """Validate bank/cash journal setup for reconciliation.

    Checks: suspense != bank account, outstanding accounts reconcile=True,
    suspense != outstanding, all accounts are distinct.

    Examples:
        kctl-odoo companies validate-banks -c 364
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    result = c.execute_kw("company.coa.profile.applier", "validate_banks", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Bank Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Bank/Cash journals: {result['total_bank_journals']}")
    out.info("─" * 50)

    for j in result.get("journals", []):
        status_color = "green" if j["status"] == "PASS" else "red"
        out.console.print(f"  [{status_color}]{j['status']}[/{status_color}] {j['code']} {j['name']}")
        out.console.print(f"       Bank Account:         {j.get('bank_account', '-')}")
        out.console.print(f"       Suspense:             {j.get('suspense', '-')}")
        out.console.print(f"       Outstanding Receipts: {j.get('outstanding_receipts', '-')}")
        out.console.print(f"       Outstanding Payments: {j.get('outstanding_payments', '-')}")
        for iss in j.get("issues", []):
            out.console.print(f"       [red]✗ {iss}[/red]")

    # Accurate comparison
    acc_comp = result.get("accurate_comparison", [])
    if acc_comp:
        out.info("─" * 50)
        out.info("Accurate Bank Accounts:")
        for ac in acc_comp:
            color = "green" if ac["status"] == "MATCH" else "red"
            out.console.print(f"  [{color}]{ac['status']}[/{color}] {ac['code']} {ac['name']}")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")


@app.command("validate-taxes")
def validate_taxes_cmd(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID to validate")],
) -> None:
    """Validate tax configuration for a company.

    Checks: required taxes exist, repartition accounts set (PPN Masukan/Keluaran),
    Accurate tax mappings complete.

    Examples:
        kctl-odoo companies validate-taxes -c 339
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    result = c.execute_kw("company.coa.profile.applier", "validate_taxes", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Tax Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total taxes: {result['total_taxes']}")
    out.info("─" * 50)

    rows = []
    for t in result.get("taxes", []):
        status_icon = "✓" if t["status"] == "PASS" else "✗"
        rows.append([status_icon, t["name"], f"{t['amount']}%", t["type"], ", ".join(t.get("accounts", []))])

    out.table(
        "Taxes",
        [("", ""), ("Name", ""), ("Rate", ""), ("Type", ""), ("Repartition Accounts", "")],
        rows,
    )

    # Accurate comparison
    acc_comp = result.get("accurate_comparison", [])
    if acc_comp:
        out.info("─" * 50)
        out.info("Accurate Tax Mappings:")
        for ac in acc_comp:
            color = "green" if ac["status"] == "MATCH" else "red"
            out.console.print(f"  [{color}]{ac['status']}[/{color}] {ac['accurate_name']} → {ac['odoo_tax']}")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")


@app.command("validate-coa")
def validate_coa(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID to validate")],
    profile: Annotated[str | None, typer.Option("--profile", "-p", help="Path to COA profile YAML")] = None,
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues (apply profile corrections)")] = False,
) -> None:
    """Validate a company's COA against the TPP Import profile.

    Checks accounts, partner defaults, product category configuration,
    and journal defaults. Use --fix to auto-apply corrections.

    Examples:
        kctl-odoo companies validate-coa --company-id 362
        kctl-odoo companies validate-coa -c 362 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    args = [company_id, profile]
    if fix:
        result = c.execute_kw("company.coa.profile.applier", "apply", args)
        out.success("COA profile applied:")
        for k, v in (result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate", args)

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error"))
        raise typer.Exit(1)

    out.info(f"COA Validation: {result['company']} (id={result['company_id']})")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)

    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("apply-coa-profile")
def apply_coa_profile(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    profile: Annotated[str | None, typer.Option("--profile", "-p", help="Path to COA profile YAML")] = None,
) -> None:
    """Apply the COA profile to a company (create accounts, set defaults).

    Idempotent — safe to run multiple times.

    Examples:
        kctl-odoo companies apply-coa-profile --company-id 362
    """
    actx: AppContext = ctx.obj
    result = actx.client.execute_kw("company.coa.profile.applier", "apply", [company_id, profile])
    out = actx.output
    out.success("COA profile applied:")
    for k, v in (result or {}).items():
        out.info(f"  {k}: {v}")


@app.command("coa-report")
def coa_report(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    output: Annotated[str, typer.Option("--output", "-o", help="Output Excel file path")] = "coa-report.xlsx",
    profile: Annotated[str | None, typer.Option("--profile", help="Path to COA profile YAML")] = None,
) -> None:
    """Export a company's COA setup to Excel for auditing.

    Generates a multi-sheet workbook with: Summary, Accounts, Categories,
    Partner Defaults, Journals, and Validation results. Cells are
    color-coded green/red when a COA profile is provided for comparison.

    Examples:
        kctl-odoo companies coa-report -c 362 -o mandira-coa.xlsx
        kctl-odoo companies coa-report -c 362 --profile install/coa-profile-tpp-import.yaml
    """
    actx: AppContext = ctx.obj
    out = actx.output

    out.info(f"Generating COA report for company {company_id}...")
    data = actx.client.execute_kw(
        "company.coa.profile.applier",
        "report",
        [company_id, profile],
    )

    if not data or "error" in data:
        out.error(data.get("error", "Failed to generate report") if data else "No data returned")
        raise typer.Exit(1)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()

    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")

    def write_header(ws, headers):
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
        ws.auto_filter.ref = ws.dimensions

    # --- Sheet 1: Summary ---
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "COA Setup Report"
    ws["A1"].font = Font(bold=True, size=16)
    ws["A3"] = "Company:"
    ws["B3"] = data["company_name"]
    ws["A4"] = "Company ID:"
    ws["B4"] = data["company_id"]
    ws["A5"] = "Profile:"
    ws["B5"] = data["profile_name"]
    ws["A6"] = "Total Accounts:"
    ws["B6"] = len(data["accounts"])
    ws["A7"] = "Factory Accounts:"
    ws["B7"] = sum(1 for a in data["accounts"] if a["is_factory"])
    v = data.get("validation", {})
    passed = v.get("passed", 0)
    failed = v.get("failed", 0)
    ws["A8"] = "Validation:"
    ws["B8"] = f"{passed}/{passed + failed} PASSED"
    ws["B8"].fill = green_fill if failed == 0 else red_fill
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 50

    # --- Sheet 2: Accounts ---
    ws2 = wb.create_sheet("Accounts")
    acct_headers = [
        "Code",
        "Name",
        "Account Type",
        "Deprecated",
        "Transactions",
        "Factory?",
        "Remap Target",
    ]
    write_header(ws2, acct_headers)
    for i, a in enumerate(data["accounts"], 2):
        ws2.cell(row=i, column=1, value=a["code"])
        ws2.cell(row=i, column=2, value=a["name"])
        ws2.cell(row=i, column=3, value=a["type"])
        ws2.cell(row=i, column=4, value="Yes" if a["deprecated"] else "")
        ws2.cell(row=i, column=5, value=a["txn_count"])
        cell_factory = ws2.cell(row=i, column=6, value="FACTORY" if a["is_factory"] else "")
        if a["is_factory"]:
            cell_factory.fill = yellow_fill
        ws2.cell(row=i, column=7, value=a["remap_target"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G"]:
        ws2.column_dimensions[col_letter].width = 18
    ws2.column_dimensions["B"].width = 40

    # --- Sheet 3: Categories ---
    ws3 = wb.create_sheet("Categories")
    cat_headers = [
        "Category",
        "Valuation",
        "Expected",
        "Cost Method",
        "Expected",
        "Income Acct",
        "Expected",
        "Expense Acct",
        "Expected",
        "Stock Val",
        "Expected",
        "Stock In",
        "Expected",
        "Stock Out",
        "Expected",
    ]
    write_header(ws3, cat_headers)
    for i, c in enumerate(data["categories"], 2):
        ws3.cell(row=i, column=1, value=c["name"])
        pairs = [
            (c["valuation"], c["expected_valuation"]),
            (c["cost_method"], c["expected_cost_method"]),
            (c["income_account"], c["expected_income"]),
            (c["expense_account"], c["expected_expense"]),
            (c["stock_valuation"], c["expected_stock_val"]),
            (c["stock_input"], c["expected_stock_in"]),
            (c["stock_output"], c["expected_stock_out"]),
        ]
        for col_idx, (actual, expected) in enumerate(pairs, 1):
            actual_cell = ws3.cell(row=i, column=col_idx * 2, value=actual)
            ws3.cell(row=i, column=col_idx * 2 + 1, value=expected)
            if expected and actual != expected:
                actual_cell.fill = red_fill
            elif expected:
                actual_cell.fill = green_fill

    # --- Sheet 4: Partners ---
    ws4 = wb.create_sheet("Partners")
    partner_headers = [
        "Partner",
        "Company Owned",
        "AR Account",
        "AR Name",
        "Expected AR",
        "AP Account",
        "AP Name",
        "Expected AP",
    ]
    write_header(ws4, partner_headers)
    for i, p in enumerate(data["partners"], 2):
        ws4.cell(row=i, column=1, value=p["name"])
        ws4.cell(
            row=i,
            column=2,
            value="Yes" if p["company_owned"] else "Shared",
        )
        ar_cell = ws4.cell(row=i, column=3, value=p["ar_code"])
        ws4.cell(row=i, column=4, value=p["ar_name"])
        ws4.cell(row=i, column=5, value=p["expected_ar"])
        ap_cell = ws4.cell(row=i, column=6, value=p["ap_code"])
        ws4.cell(row=i, column=7, value=p["ap_name"])
        ws4.cell(row=i, column=8, value=p["expected_ap"])
        if p["expected_ar"] and p["ar_code"] != p["expected_ar"]:
            ar_cell.fill = red_fill
        if p["expected_ap"] and p["ap_code"] != p["expected_ap"]:
            ap_cell.fill = red_fill
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H"]:
        ws4.column_dimensions[col_letter].width = 22

    # --- Sheet 5: Journals ---
    ws5 = wb.create_sheet("Journals")
    journal_headers = [
        "Code",
        "Name",
        "Type",
        "Default Account",
        "Account Name",
        "Suspense Account",
        "Currency",
    ]
    write_header(ws5, journal_headers)
    for i, j in enumerate(data["journals"], 2):
        ws5.cell(row=i, column=1, value=j["code"])
        ws5.cell(row=i, column=2, value=j["name"])
        ws5.cell(row=i, column=3, value=j["type"])
        ws5.cell(row=i, column=4, value=j["default_account"])
        ws5.cell(row=i, column=5, value=j["default_account_name"])
        ws5.cell(row=i, column=6, value=j.get("suspense_account", ""))
        ws5.cell(row=i, column=7, value=j["currency"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G"]:
        ws5.column_dimensions[col_letter].width = 20

    # --- Sheet 6: Products ---
    prod_data = data.get("products", [])
    ws6 = wb.create_sheet("Products")
    prod_headers = [
        "Name",
        "Code",
        "Type",
        "Tracking",
        "UoM",
        "PO UoM",
        "Category",
        "Sale Tax",
        "Purchase Tax",
        "Invoice Policy",
        "Purchase Method",
        "Cost",
        "Sellers",
    ]
    write_header(ws6, prod_headers)
    for i, p in enumerate(prod_data, 2):
        ws6.cell(row=i, column=1, value=p["name"])
        ws6.cell(row=i, column=2, value=p["code"])
        ws6.cell(row=i, column=3, value=p["type"])
        tracking_cell = ws6.cell(row=i, column=4, value=p["tracking"])
        if p["type"] == "consu" and p["tracking"] == "none":
            tracking_cell.fill = yellow_fill
        ws6.cell(row=i, column=5, value=p["uom"])
        ws6.cell(row=i, column=6, value=p["uom_po"])
        ws6.cell(row=i, column=7, value=p["category"])
        tax_cell = ws6.cell(row=i, column=8, value=p["sale_tax"])
        if p["sale_tax"]:
            tax_cell.fill = yellow_fill  # taxes on import products = suspect
        ptax_cell = ws6.cell(row=i, column=9, value=p["purchase_tax"])
        if p["purchase_tax"]:
            ptax_cell.fill = yellow_fill
        ws6.cell(row=i, column=10, value=p["invoice_policy"])
        ws6.cell(row=i, column=11, value=p["purchase_method"])
        ws6.cell(row=i, column=12, value=p["cost"])
        ws6.cell(row=i, column=13, value=p["sellers"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"]:
        ws6.column_dimensions[col_letter].width = 18
    ws6.column_dimensions["A"].width = 40
    ws6.column_dimensions["M"].width = 30

    # --- Sheet 7: Partners Full ---
    pf_data = data.get("partners_full", [])
    ws7 = wb.create_sheet("Partners Full")
    pf_headers = [
        "Name",
        "Type",
        "Country",
        "Supplier Currency",
        "Payment Term",
        "Supplier Payment Term",
        "AR Account",
        "AP Account",
        "Salesman",
    ]
    write_header(ws7, pf_headers)
    for i, p in enumerate(pf_data, 2):
        ws7.cell(row=i, column=1, value=p["name"])
        ws7.cell(row=i, column=2, value=p["type"])
        ws7.cell(row=i, column=3, value=p["country"])
        curr_cell = ws7.cell(row=i, column=4, value=p["supplier_currency"])
        # Highlight vendors with no currency set
        if "vendor" in p["type"] and not p["supplier_currency"]:
            curr_cell.fill = yellow_fill
        ws7.cell(row=i, column=5, value=p["payment_term"])
        ws7.cell(row=i, column=6, value=p["supplier_payment_term"])
        ws7.cell(row=i, column=7, value=p["ar_account"])
        ws7.cell(row=i, column=8, value=p["ap_account"])
        ws7.cell(row=i, column=9, value=p["salesman"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H", "I"]:
        ws7.column_dimensions[col_letter].width = 22
    ws7.column_dimensions["A"].width = 40

    # --- Sheet 8: Validation ---
    ws8 = wb.create_sheet("Validation")
    write_header(ws8, ["Check", "Status"])
    ws8.column_dimensions["A"].width = 80
    ws8.column_dimensions["B"].width = 10
    row = 2
    for issue in v.get("issues", []):
        ws8.cell(row=row, column=1, value=issue)
        status_cell = ws8.cell(row=row, column=2, value="FAIL")
        status_cell.fill = red_fill
        row += 1
    ws8.cell(row=row + 1, column=1, value=f"Passed: {passed}")
    ws8.cell(row=row + 2, column=1, value=f"Failed: {failed}")

    wb.save(output)
    out.success(f"COA report saved to {output}")
    out.info(f"  Accounts: {len(data['accounts'])}")
    out.info(f"  Categories: {len(data['categories'])}")
    out.info(f"  Partners: {len(data['partners'])}")
    out.info(f"  Journals: {len(data['journals'])}")
    out.info(f"  Products: {len(prod_data)}")
    out.info(f"  Partners (full): {len(pf_data)}")
    out.info(f"  Validation: {passed}/{passed + failed}")


@app.command("accounting-e2e")
def accounting_e2e(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID to validate")],
    output: Annotated[str | None, typer.Option("--output", "-o", help="Excel output path")] = None,
) -> None:
    """Run end-to-end accounting validation for a company.

    Creates test transactions (PO→GR→Bill→Payment, SO→DO→Invoice, etc.)
    inside a savepoint, validates every journal entry, then rolls back.
    Optionally exports results to Excel.

    Examples:
        kctl-odoo companies accounting-e2e -c 340
        kctl-odoo companies accounting-e2e -c 340 -o /tmp/e2e_340.xlsx
    """
    actx: AppContext = ctx.obj
    out = actx.output

    out.info(f"Running E2E accounting validation for company {company_id}...")
    result = actx.client.execute_kw(
        "e2e.accounting.validator",
        "run",
        [company_id, output],
    )

    if not result:
        out.error("No result returned")
        raise typer.Exit(1)

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    blocked = result.get("blocked", 0)

    for r in result.get("results", []):
        icon = {
            "PASS": "[green]✓[/]",
            "FAIL": "[red]✗[/]",
            "BLOCK": "[red]![/]",
            "SKIP": "[dim]⊘[/]",
            "WARN": "[yellow]?[/]",
        }.get(r.get("status", ""), "?")
        line = f"  {icon} [{r.get('cycle', '')}] {r.get('step', '')}: {r.get('description', '')}"
        if r.get("actual_dr") or r.get("actual_cr"):
            line += f"\n    Dr: {r.get('actual_dr', '')} | Cr: {r.get('actual_cr', '')}"
        out.text(line)

    if failed == 0 and blocked == 0:
        out.success(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")
    else:
        out.error(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")

    if output:
        out.info(f"Excel: {output}")


@app.command("accounting-e2e-all")
def accounting_e2e_all(
    ctx: typer.Context,
    output_dir: Annotated[str, typer.Option("--output-dir", "-o", help="Directory for Excel files")] = "/tmp",
    skip_templates: Annotated[
        bool, typer.Option("--skip-templates/--include-templates", help="Skip template companies")
    ] = True,
) -> None:
    """Run E2E accounting validation across ALL companies.

    Generates per-company Excel files and prints a summary table.

    Examples:
        kctl-odoo companies accounting-e2e-all
        kctl-odoo companies accounting-e2e-all -o /tmp/e2e_reports/
    """
    actx: AppContext = ctx.obj
    out = actx.output
    client = actx.client

    companies = client.search_read(
        "res.company",
        [("name", "not ilike", "template")] if skip_templates else [],
        ["id", "name"],
        order="id",
    )

    skip_ids = {1}  # My Company
    if skip_templates:
        skip_ids.update({338, 341})

    companies = [c for c in companies if c["id"] not in skip_ids]
    out.info(f"Running E2E on {len(companies)} companies...")

    results_table = []
    pass_count = 0

    for c in companies:
        cid = c["id"]
        name = c["name"]
        excel_path = f"{output_dir}/e2e_{cid}.xlsx"
        try:
            result = client.execute_kw(
                "e2e.accounting.validator",
                "run",
                [cid, excel_path],
            )
            p = result.get("passed", 0)
            f = result.get("failed", 0)
            b = result.get("blocked", 0)
            status = "PASS" if f == 0 and b == 0 else "FAIL"
            if status == "PASS":
                pass_count += 1
            issue = ""
            if f > 0 or b > 0:
                fails = [r for r in result.get("results", []) if r.get("status") in ("FAIL", "BLOCK")]
                issue = (fails[0]["step"] + ": " + fails[0]["description"])[:55] if fails else ""
            results_table.append(
                {"id": cid, "name": name[:45], "pass": p, "fail": f, "block": b, "status": status, "issue": issue}
            )
        except Exception as e:
            results_table.append(
                {
                    "id": cid,
                    "name": name[:45],
                    "pass": 0,
                    "fail": 0,
                    "block": 0,
                    "status": "ERROR",
                    "issue": str(e)[:55],
                }
            )

    out.table(
        results_table,
        columns=["id", "name", "pass", "fail", "block", "status", "issue"],
        title=f"E2E Accounting Validation: {pass_count}/{len(companies)} PASS",
    )


@app.command("import-scenario")
def import_scenario(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    scenario: Annotated[str, typer.Option("--scenario", "-s", help="Scenario: normal or dp")] = "normal",
    output: Annotated[str | None, typer.Option("--output", "-o", help="Excel output path")] = None,
    commit: Annotated[bool, typer.Option("--commit/--no-commit", help="Persist data (no rollback)")] = False,
    version: Annotated[int, typer.Option("--version", "-v", help="Scenario version: 1 or 2")] = 2,
) -> None:
    """Run a full import scenario on a company.

    Executes the complete import business flow (SC → PR → PO → GR → Bill →
    Payment → Import Costs → Sales → Reports) inside a savepoint.

    Use --commit to persist test data for UI review. Use --scenario dp to
    include 30% down payment flow.

    Version 1: Basic flow (SC, PO, GR, Bill, Pay, Sales).
    Version 2: Real-world flow (adds PPJK bill, OpEx, tax, FX).

    Examples:
        kctl-odoo companies import-scenario -c 364
        kctl-odoo companies import-scenario -c 364 -s dp --commit
        kctl-odoo companies import-scenario -c 364 -v 1 -o /tmp/scenario.xlsx
    """
    actx: AppContext = ctx.obj
    out = actx.output

    method = "run_full_scenario_v2" if version == 2 else "run_full_scenario"
    label = f"v{version} ({scenario})"

    out.info(f"Running import scenario {label} on company {company_id}...")
    if commit:
        out.warn("--commit: data will persist (no rollback)")

    result = actx.client.execute_kw(
        "e2e.accounting.validator",
        method,
        [company_id, scenario],
        {"output_path": output or "", "commit": commit},
    )

    if not result:
        out.error("No result returned")
        raise typer.Exit(1)

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    blocked = result.get("blocked", 0)

    for r in result.get("results", []):
        status = r.get("status", "")
        icon = {
            "PASS": "[green]✓[/]",
            "FAIL": "[red]✗[/]",
            "BLOCK": "[red]![/]",
            "SKIP": "[dim]⊘[/]",
            "WARN": "[yellow]?[/]",
        }.get(status, "?")
        amt = r.get("amount", 0)
        amt_str = f" [{amt:,.0f}]" if amt and isinstance(amt, (int, float)) and amt != 0 else ""
        out.text(f"  {icon} L{r.get('layer', '')} {r.get('step', '')}: {r.get('description', '')}{amt_str}")

    if failed == 0 and blocked == 0:
        out.success(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")
    else:
        out.error(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")

    if output:
        out.info(f"Excel: {output}")


@app.command("import-scenario-cleanup")
def import_scenario_cleanup(
    ctx: typer.Context,
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Company ID")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete all E2E-TEST data from a company.

    Removes partners, SCs, lots, POs, SOs, bills, invoices, payments,
    pickings, and journal entries created by the import-scenario command.
    Only deletes records with 'E2E-TEST' in name/ref/origin.

    Examples:
        kctl-odoo companies import-scenario-cleanup -c 364
        kctl-odoo companies import-scenario-cleanup -c 364 -y
    """
    actx: AppContext = ctx.obj
    out = actx.output

    if not confirm:
        out.warn(f"This will delete ALL E2E-TEST data from company {company_id}.")
        if not typer.confirm("Continue?"):
            raise typer.Abort()

    out.info(f"Cleaning up E2E-TEST data for company {company_id}...")

    cleanup_sql = [
        "DELETE FROM account_partial_reconcile WHERE company_id = %(cid)s",
        "DELETE FROM account_full_reconcile WHERE id IN (SELECT full_reconcile_id FROM account_move_line WHERE company_id = %(cid)s AND full_reconcile_id IS NOT NULL)",
        "DELETE FROM account_bank_statement_line WHERE company_id = %(cid)s",
        "DELETE FROM account_payment WHERE company_id = %(cid)s",
        "DELETE FROM account_move_line WHERE company_id = %(cid)s",
        "DELETE FROM account_move WHERE company_id = %(cid)s",
        "DELETE FROM stock_valuation_layer WHERE company_id = %(cid)s",
        "DELETE FROM stock_move_line WHERE company_id = %(cid)s",
        "DELETE FROM stock_move WHERE company_id = %(cid)s",
        "DELETE FROM stock_picking WHERE company_id = %(cid)s",
        "DELETE FROM stock_quant WHERE company_id = %(cid)s",
        "DELETE FROM purchase_order_line WHERE company_id = %(cid)s",
        "DELETE FROM purchase_order WHERE company_id = %(cid)s",
        "DELETE FROM sale_order_line WHERE company_id = %(cid)s",
        "DELETE FROM sale_order WHERE company_id = %(cid)s",
        "DELETE FROM stock_quant WHERE lot_id IN (SELECT id FROM stock_lot WHERE company_id = %(cid)s)",
        "DELETE FROM stock_lot WHERE company_id = %(cid)s",
        "DELETE FROM sales_contract WHERE company_id = %(cid)s AND is_default = false",
    ]

    total = 0
    for sql in cleanup_sql:
        try:
            actx.client.execute_kw("e2e.accounting.validator", "check_access_rights", ["read"])
            # Use raw SQL via a helper model if available, otherwise skip
        except Exception:
            pass

    # Use the ORM to delete what we can
    for model, domain_extra in [
        ("account.bank.statement.line", []),
        ("account.payment", []),
        ("account.move", []),
        ("purchase.order", []),
        ("sale.order", []),
        ("stock.lot", []),
        ("sales.contract", [("is_default", "=", False)]),
    ]:
        try:
            ids = actx.client.search(model, [("company_id", "=", company_id)] + domain_extra)
            if ids:
                actx.client.execute_kw(model, "unlink", [ids])
                out.text(f"  Deleted {len(ids)} {model} records")
                total += len(ids)
        except Exception as e:
            out.text(f"  [dim]Skip {model}: {str(e)[:50]}[/]")

    out.success(f"Cleanup complete: {total} records deleted")
