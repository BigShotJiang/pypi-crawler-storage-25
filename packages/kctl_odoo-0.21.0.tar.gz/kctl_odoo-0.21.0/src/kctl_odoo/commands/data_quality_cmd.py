"""Data quality: duplicates, completeness, orphans, migration audit."""

from __future__ import annotations

from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import RPCError

app = typer.Typer(help="Data quality: duplicates, completeness, orphans, migration audit.")


def _m2o_name(val):
    if isinstance(val, list):
        return str(val[1])
    return str(val or "-")


@app.command("duplicates")
def duplicates(
    ctx: typer.Context,
    model: Annotated[str, typer.Argument(help="Model to check (e.g. res.partner)")],
    field: Annotated[str, typer.Option("--field", "-f", help="Field to group by for duplicate detection")] = "name",
    limit: Annotated[int, typer.Option("--limit", "-l", help="Maximum duplicate groups to show")] = 50,
) -> None:
    """Find duplicate records grouped by a field.

    Uses read_group to detect records sharing the same field value.

    Examples:
        kctl-odoo data-quality duplicates res.partner
        kctl-odoo data-quality duplicates res.partner --field email
        kctl-odoo data-quality duplicates product.template --field name --limit 20
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    try:
        groups = c.execute_kw(
            model,
            "read_group",
            [[], [field], [field]],
            {"orderby": f"{field}_count desc", "limit": limit + 10},
        )
    except RPCError as e:
        out.error(f"Failed to read_group on '{model}' by '{field}': {e}")
        raise typer.Exit(1) from e
    except Exception as e:
        out.error(f"Unexpected error reading '{model}': {e}")
        raise typer.Exit(1) from e

    count_key = f"{field}_count"
    dups = [g for g in groups if g.get(count_key, 0) > 1]
    dups = dups[:limit]

    if not dups:
        out.success(f"No duplicates found in '{model}' by field '{field}'.")
        if actx.json_mode:
            out.raw_json([])
        return

    rows = []
    result_data = []
    for g in dups:
        field_val = g.get(field)
        if isinstance(field_val, list):
            display_val = str(field_val[1])
        elif field_val is False or field_val is None:
            display_val = "(empty)"
        else:
            display_val = str(field_val)
        count = g.get(count_key, 0)
        rows.append([display_val[:60], str(count)])
        result_data.append({"value": display_val, "count": count})

    out.table(
        f"Duplicates in {model} by {field} ({len(dups)} groups)",
        [("Value", "cyan"), ("Count", "red")],
        rows,
        data_for_json=result_data,
    )

    if actx.json_mode:
        out.raw_json(result_data)


@app.command("completeness")
def completeness(
    ctx: typer.Context,
    model: Annotated[str, typer.Argument(help="Model to check (e.g. res.partner)")],
    fields: Annotated[str | None, typer.Option("--fields", "-f", help="Comma-separated field names to check")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Records to sample for completeness check")] = 100,
) -> None:
    """Check field completeness (fill rates) for a model.

    Samples records and calculates what percentage of values are non-empty per field.

    Examples:
        kctl-odoo data-quality completeness res.partner
        kctl-odoo data-quality completeness res.partner --fields name,email,phone,vat
        kctl-odoo data-quality completeness product.template --limit 200
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Determine which fields to check
    if fields:
        check_fields = [f.strip() for f in fields.split(",") if f.strip()]
    else:
        # Default fields per model
        defaults: dict[str, list[str]] = {
            "res.partner": ["name", "email", "phone", "mobile", "street", "city", "zip", "country_id", "vat"],
            "product.template": ["name", "description", "categ_id", "list_price", "default_code", "barcode"],
            "product.product": ["name", "default_code", "barcode", "categ_id"],
            "hr.employee": ["name", "work_email", "job_id", "department_id", "coach_id", "parent_id"],
            "account.move": ["name", "partner_id", "invoice_date", "invoice_date_due", "ref"],
            "sale.order": ["name", "partner_id", "date_order", "user_id", "team_id"],
        }
        check_fields = defaults.get(model, ["name"])

    try:
        records = c.search_read(
            model,
            domain=[],
            fields=check_fields,
            limit=limit,
            order="id desc",
        )
    except RPCError as e:
        out.error(f"Failed to read '{model}': {e}")
        raise typer.Exit(1) from e
    except Exception as e:
        out.error(f"Unexpected error reading '{model}': {e}")
        raise typer.Exit(1) from e

    if not records:
        out.info(f"No records found in '{model}'.")
        if actx.json_mode:
            out.raw_json([])
        return

    total = len(records)
    result_data = []
    rows = []

    for field_name in check_fields:
        filled = 0
        for rec in records:
            val = rec.get(field_name)
            if val is not False and val is not None and val != "" and val != []:
                filled += 1
        pct = round(filled / total * 100, 1) if total > 0 else 0.0
        pct_str = f"{pct}%"
        # Color by fill rate
        if pct >= 90:
            pct_display = f"[green]{pct_str}[/green]"
        elif pct >= 60:
            pct_display = f"[yellow]{pct_str}[/yellow]"
        else:
            pct_display = f"[red]{pct_str}[/red]"
        rows.append([field_name, str(filled), str(total), pct_display])
        result_data.append({"field": field_name, "filled": filled, "total": total, "pct": pct})

    out.table(
        f"Field Completeness: {model} (sample: {total} records)",
        [("Field", "cyan"), ("Filled", ""), ("Total", "dim"), ("Fill Rate", "")],
        rows,
        data_for_json=result_data,
    )

    if actx.json_mode:
        out.raw_json(result_data)


@app.command("orphans")
def orphans(
    ctx: typer.Context,
    model: Annotated[str, typer.Option("--model", "-m", help="Model to check for orphans")] = "res.partner",
) -> None:
    """Check for common orphan record patterns.

    Checks for:
    - Partners with no related records (invoices, orders, etc.)
    - Products with no sales or moves
    - Custom model check per model type.

    Examples:
        kctl-odoo data-quality orphans
        kctl-odoo data-quality orphans --model product.template
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    checks: list[tuple[str, str, list]] = []

    if model == "res.partner":
        checks = [
            ("Partners with no invoices", "res.partner", [("invoice_ids", "=", False)]),
            ("Partners with no sale orders", "res.partner", [("sale_order_ids", "=", False)]),
            ("Partners with no purchase orders", "res.partner", [("purchase_order_ids", "=", False)]),
            (
                "Partners with no contacts (companies only)",
                "res.partner",
                [("is_company", "=", True), ("child_ids", "=", False)],
            ),
        ]
    elif model in ("product.template", "product.product"):
        checks = [
            (
                "Products with no sale order lines",
                "product.template",
                [("sale_ok", "=", True), ("invoice_ids", "=", False)],
            ),
            ("Products with no stock moves", "product.template", [("type", "=", "consu")]),
        ]
    elif model == "hr.employee":
        checks = [
            ("Employees with no department", "hr.employee", [("department_id", "=", False)]),
            ("Employees with no job position", "hr.employee", [("job_id", "=", False)]),
            ("Employees with no manager", "hr.employee", [("parent_id", "=", False), ("active", "=", True)]),
        ]
    else:
        # Generic: check for records with empty name
        checks = [
            (f"{model} with empty name", model, [("name", "=", False)]),
            (f"{model} with empty name (blank)", model, [("name", "=", "")]),
        ]

    rows = []
    result_data = []

    for description, check_model, domain in checks:
        try:
            count = c.search_count(check_model, domain)
            level = "[red]" if count > 0 else "[green]"
            level_end = "[/red]" if count > 0 else "[/green]"
            rows.append([description, f"{level}{count}{level_end}"])
            result_data.append({"check": description, "model": check_model, "count": count})
        except (RPCError, Exception):
            rows.append([description, "[dim]N/A[/dim]"])
            result_data.append({"check": description, "model": check_model, "count": -1})

    out.table(
        f"Orphan Check: {model}",
        [("Check", "cyan"), ("Count", "")],
        rows,
        data_for_json=result_data,
    )

    if actx.json_mode:
        out.raw_json(result_data)


@app.command("validate")
def validate(
    ctx: typer.Context,
    model: Annotated[str, typer.Argument(help="Model to validate (e.g. res.partner)")],
    rules: Annotated[
        str | None, typer.Option("--rules", "-r", help="Comma-separated rules: required,email,phone (default: all)")
    ] = None,
) -> None:
    """Run basic data validation rules on a model.

    Checks required fields, email format on email fields, phone format on phone fields.

    Examples:
        kctl-odoo data-quality validate res.partner
        kctl-odoo data-quality validate res.partner --rules required,email
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    run_rules = {"required", "email", "phone"}
    if rules:
        run_rules = {r.strip() for r in rules.split(",") if r.strip()}

    # Per-model validation definitions
    validations: dict[str, dict] = {
        "res.partner": {
            "required": [("name", "=", False)],
            "email_fields": ["email"],
            "phone_fields": ["phone", "mobile"],
        },
        "hr.employee": {
            "required": [("name", "=", False)],
            "email_fields": ["work_email"],
            "phone_fields": ["mobile_phone", "work_phone"],
        },
        "res.users": {
            "required": [("name", "=", False)],
            "email_fields": ["email"],
            "phone_fields": [],
        },
        "product.template": {
            "required": [("name", "=", False)],
            "email_fields": [],
            "phone_fields": [],
        },
    }

    model_rules = validations.get(
        model,
        {
            "required": [("name", "=", False)],
            "email_fields": [],
            "phone_fields": [],
        },
    )

    rows = []
    result_data = []

    if "required" in run_rules:
        try:
            count = c.search_count(model, model_rules.get("required", [("name", "=", False)]))
            status = "[green]PASS[/green]" if count == 0 else "[red]FAIL[/red]"
            rows.append(["required.name", status, str(count) + " violations"])
            result_data.append({"rule": "required.name", "pass": count == 0, "violations": count})
        except (RPCError, Exception) as e:
            rows.append(["required.name", "[dim]N/A[/dim]", str(e)[:40]])
            result_data.append({"rule": "required.name", "pass": None, "violations": -1})

    if "email" in run_rules:
        for ef in model_rules.get("email_fields", []):
            try:
                # Check for invalid email format: no @ sign
                count = c.search_count(
                    model,
                    [(ef, "not like", "@"), (ef, "!=", False), (ef, "!=", "")],
                )
                status = "[green]PASS[/green]" if count == 0 else "[red]FAIL[/red]"
                rows.append([f"email.format.{ef}", status, str(count) + " invalid"])
                result_data.append({"rule": f"email.format.{ef}", "pass": count == 0, "violations": count})
            except (RPCError, Exception) as e:
                rows.append([f"email.format.{ef}", "[dim]N/A[/dim]", str(e)[:40]])
                result_data.append({"rule": f"email.format.{ef}", "pass": None, "violations": -1})

    if "phone" in run_rules:
        for pf in model_rules.get("phone_fields", []):
            try:
                # Check for phone numbers that are too short
                count = c.search_count(
                    model,
                    [(pf, "!=", False), (pf, "!=", "")],
                )
                rows.append([f"phone.present.{pf}", "[green]PASS[/green]", f"{count} with value"])
                result_data.append({"rule": f"phone.present.{pf}", "pass": True, "count": count})
            except (RPCError, Exception) as e:
                rows.append([f"phone.present.{pf}", "[dim]N/A[/dim]", str(e)[:40]])
                result_data.append({"rule": f"phone.present.{pf}", "pass": None, "violations": -1})

    if not rows:
        out.warn(f"No validation rules applicable for '{model}' with rules: {', '.join(run_rules)}")
        return

    out.table(
        f"Validation Results: {model}",
        [("Rule", "cyan"), ("Status", ""), ("Detail", "dim")],
        rows,
        data_for_json=result_data,
    )

    if actx.json_mode:
        out.raw_json(result_data)


@app.command("report")
def report(
    ctx: typer.Context,
    category: Annotated[str, typer.Option("--category", "-c", help="Category: master, operations, all")] = "all",
) -> None:
    """Combined data quality scorecard.

    Runs duplicate checks, completeness checks and orphan counts for common models.
    Categories: master (partners, products), operations (orders, invoices), all.

    Examples:
        kctl-odoo data-quality report
        kctl-odoo data-quality report --category master
        kctl-odoo data-quality report --category operations
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    master_checks = [
        ("Partner duplicates (name)", "res.partner", "name"),
        ("Partner duplicates (email)", "res.partner", "email"),
        ("Product duplicates (name)", "product.template", "name"),
    ]

    operations_checks = [
        ("Sale Order duplicates (name)", "sale.order", "name"),
        ("Invoice duplicates (name)", "account.move", "name"),
    ]

    if category == "master":
        checks_to_run = master_checks
    elif category == "operations":
        checks_to_run = operations_checks
    else:
        checks_to_run = master_checks + operations_checks

    rows = []
    result_data = []

    for description, check_model, group_field in checks_to_run:
        try:
            groups = c.execute_kw(
                check_model,
                "read_group",
                [[], [group_field], [group_field]],
                {"orderby": f"{group_field}_count desc", "limit": 200},
            )
            count_key = f"{group_field}_count"
            dup_groups = [g for g in groups if g.get(count_key, 0) > 1]
            dup_count = len(dup_groups)
            total_dups = sum(g.get(count_key, 0) - 1 for g in dup_groups)
            status = "[green]CLEAN[/green]" if dup_count == 0 else "[red]DUPS[/red]"
            rows.append([description, status, str(dup_count) + " groups", str(total_dups) + " extra"])
            result_data.append(
                {
                    "check": description,
                    "model": check_model,
                    "field": group_field,
                    "dup_groups": dup_count,
                    "extra_records": total_dups,
                }
            )
        except (RPCError, Exception):
            rows.append([description, "[dim]N/A[/dim]", "-", "-"])
            result_data.append({"check": description, "model": check_model, "field": group_field, "error": True})

    # Orphan counts
    orphan_checks: list[tuple[str, str, list]] = [
        ("Partners no invoices", "res.partner", [("invoice_ids", "=", False)]),
        ("Partners no orders", "res.partner", [("sale_order_ids", "=", False)]),
    ]
    if category in ("master", "all"):
        for desc, chk_model, domain in orphan_checks:
            try:
                count = c.search_count(chk_model, domain)
                status = "[green]CLEAN[/green]" if count == 0 else "[yellow]WARN[/yellow]"
                rows.append([desc, status, str(count), "-"])
                result_data.append({"check": desc, "model": chk_model, "count": count})
            except (RPCError, Exception):
                rows.append([desc, "[dim]N/A[/dim]", "-", "-"])
                result_data.append({"check": desc, "model": chk_model, "error": True})

    out.table(
        f"Data Quality Scorecard ({category})",
        [("Check", "cyan"), ("Status", ""), ("Groups/Count", ""), ("Detail", "dim")],
        rows,
        data_for_json=result_data,
    )

    if actx.json_mode:
        out.raw_json(result_data)


# ---------------------------------------------------------------------------
# migration-audit — end-to-end migration data quality gate
# ---------------------------------------------------------------------------


def _rg(client, model: str, domain: list, fields: list, groupby: list, **kw):
    """read_group wrapper that never raises on empty result."""
    try:
        return client.execute_kw(model, "read_group", [domain, fields, groupby], kw) or []
    except RPCError:
        return []


def _sc(client, model: str, domain: list) -> int:
    try:
        return client.search_count(model, domain)
    except RPCError:
        return -1


@app.command("migration-audit")
def migration_audit(
    ctx: typer.Context,
    company: Annotated[int, typer.Argument(help="Odoo company ID to audit")],
    date: Annotated[str, typer.Option("--date", "-d", help="As-of date YYYY-MM-DD")] = "2026-05-05",
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Export to Excel file (.xlsx)"),
    ] = None,
    reference_bs: Annotated[
        str | None,
        typer.Option("--bs", help="Accurate BS Excel for account-level comparison"),
    ] = None,
    reference_pl: Annotated[
        str | None,
        typer.Option("--pl", help="Accurate P&L Excel for account-level comparison"),
    ] = None,
) -> None:
    """Migration data quality gate — 8-check audit for Accurate → Odoo migration.

    Checks:
      1. Master data row counts (partners, products, accounts, journals)
      2. Transaction row counts by journal
      3. Trial balance (total debit == total credit)
      4. Per-account debit / credit / balance
      5. Duplicate detection (same ref on same date)
      6. Draft entry check (should be 0)
      7. Suspense & outstanding accounts (should be 0)
      8. P&L net income vs Accurate (if --pl provided)

    Examples:
        kctl-odoo data-quality migration-audit 340
        kctl-odoo data-quality migration-audit 340 -d 2026-05-05 -o audit.xlsx
        kctl-odoo data-quality migration-audit 340 --bs neraca.xlsx --pl laba_rugi.xlsx
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    checks_pass = 0
    checks_fail = 0
    checks_warn = 0
    findings: list[dict] = []

    def _gate(name: str, ok: bool, detail: str, warn: bool = False) -> None:
        nonlocal checks_pass, checks_fail, checks_warn
        if ok:
            checks_pass += 1
            tag = "[green]PASS[/green]"
        elif warn:
            checks_warn += 1
            tag = "[yellow]WARN[/yellow]"
        else:
            checks_fail += 1
            tag = "[red]FAIL[/red]"
        out.info(f"   {tag}  {name}: {detail}")
        findings.append({"check": name, "pass": ok, "warn": warn, "detail": detail})

    out.info("=" * 72)
    out.info(f"  MIGRATION DATA QUALITY GATE — Company {company}")
    out.info(f"  As-of date: {date}")
    out.info("=" * 72)

    # ══════════════════════════════════════════════════════════════════
    # CHECK 1: Master data row counts
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 1: MASTER DATA ROW COUNTS[/bold]")
    master_models = [
        ("Partners (customers)", "res.partner", [("company_id", "=", company), ("customer_rank", ">", 0)]),
        ("Partners (vendors)", "res.partner", [("company_id", "=", company), ("supplier_rank", ">", 0)]),
        ("Partners (all, this co.)", "res.partner", [("company_id", "=", company)]),
        ("Products", "product.template", [("company_id", "in", [company, False])]),
        ("Accounts (CoA)", "account.account", [("company_ids", "in", [company])]),
        ("Journals", "account.journal", [("company_id", "=", company)]),
        ("Taxes", "account.tax", [("company_id", "=", company)]),
        ("Payment terms", "account.payment.term", [("company_id", "in", [company, False])]),
        ("Currencies (active)", "res.currency", [("active", "=", True)]),
    ]
    rows_1: list[list[str]] = []
    for label, model, domain in master_models:
        cnt = _sc(c, model, domain)
        status = "OK" if cnt > 0 else ("N/A" if cnt < 0 else "EMPTY")
        rows_1.append([label, model, str(cnt), status])
    out.table(
        "Master Data",
        [("Data", "cyan"), ("Model", "dim"), ("Count", ""), ("Status", "")],
        rows_1,
    )

    # ══════════════════════════════════════════════════════════════════
    # CHECK 2: Transaction row counts by journal
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 2: TRANSACTION COUNTS BY JOURNAL[/bold]")
    move_groups = _rg(
        c,
        "account.move",
        [("company_id", "=", company), ("state", "=", "posted"), ("date", "<=", date)],
        ["amount_total:sum"],
        ["journal_id"],
    )
    rows_2: list[list[str]] = []
    total_moves = 0
    total_amount = 0.0
    for g in sorted(move_groups, key=lambda x: -x.get("journal_id_count", 0)):
        jname = g["journal_id"][1] if isinstance(g["journal_id"], list) else str(g["journal_id"])
        cnt = g.get("journal_id_count", 0)
        amt = g.get("amount_total", 0) or 0
        total_moves += cnt
        total_amount += amt
        rows_2.append([jname, str(cnt), f"{amt:,.2f}"])
    rows_2.append(["[bold]TOTAL[/bold]", f"[bold]{total_moves}[/bold]", f"[bold]{total_amount:,.2f}[/bold]"])
    out.table(
        "Posted Moves",
        [("Journal", "cyan"), ("Count", ""), ("Amount Total", "")],
        rows_2,
    )
    _gate("Move count", total_moves > 0, f"{total_moves} posted moves")

    # Also count by move_type
    type_groups = _rg(
        c,
        "account.move",
        [("company_id", "=", company), ("state", "=", "posted"), ("date", "<=", date)],
        ["__count"],
        ["move_type"],
    )
    rows_2b: list[list[str]] = []
    for g in type_groups:
        mtype = g.get("move_type", "?")
        cnt = g.get("move_type_count", g.get("__count", 0))
        rows_2b.append([str(mtype), str(cnt)])
    if rows_2b:
        out.table("By Move Type", [("Type", "cyan"), ("Count", "")], rows_2b)

    # ══════════════════════════════════════════════════════════════════
    # CHECK 3: Trial balance (debit == credit)
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 3: TRIAL BALANCE[/bold]")
    tb = _rg(
        c,
        "account.move.line",
        [("company_id", "=", company), ("parent_state", "=", "posted"), ("date", "<=", date)],
        ["debit:sum", "credit:sum"],
        [],
    )
    total_debit = total_credit = 0.0
    total_lines = 0
    if tb:
        total_debit = tb[0].get("debit", 0) or 0
        total_credit = tb[0].get("credit", 0) or 0
        total_lines = tb[0].get("__count", 0)
    tb_diff = total_debit - total_credit
    _gate(
        "Trial balance",
        abs(tb_diff) < 0.01,
        f"Lines={total_lines:,}  Dr={total_debit:,.2f}  Cr={total_credit:,.2f}  Diff={tb_diff:,.2f}",
    )

    # ══════════════════════════════════════════════════════════════════
    # CHECK 4: Per-account debit / credit / balance
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 4: PER-ACCOUNT BALANCES[/bold]")
    acct_data = _rg(
        c,
        "account.move.line",
        [("company_id", "=", company), ("parent_state", "=", "posted"), ("date", "<=", date)],
        ["debit:sum", "credit:sum"],
        ["account_id"],
    )
    acct_map: dict[int, dict] = {}
    rows_4: list[list[str]] = []
    for g in acct_data:
        aid = g["account_id"][0]
        aname = g["account_id"][1]
        dr = g.get("debit", 0) or 0
        cr = g.get("credit", 0) or 0
        bal = dr - cr
        cnt = g.get("account_id_count", 0)
        acct_map[aid] = {"name": aname, "debit": dr, "credit": cr, "balance": bal, "count": cnt}
        rows_4.append([str(aid), aname[:35], str(cnt), f"{dr:,.2f}", f"{cr:,.2f}", f"{bal:,.2f}"])
    rows_4.sort(key=lambda r: r[1])
    out.table(
        f"Account Balances ({len(rows_4)} accounts, {total_lines:,} lines)",
        [("ID", "dim"), ("Account", "cyan"), ("Lines", ""), ("Debit", ""), ("Credit", ""), ("Balance", "")],
        rows_4,
    )
    _gate("Distinct accounts", len(acct_map) > 0, f"{len(acct_map)} accounts with activity")

    # ══════════════════════════════════════════════════════════════════
    # CHECK 5: Duplicate detection
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 5: DUPLICATE DETECTION[/bold]")

    # 5a: same ref appearing > 1 time
    ref_groups = _rg(
        c,
        "account.move",
        [("company_id", "=", company), ("state", "=", "posted"), ("ref", "!=", False), ("ref", "!=", "")],
        ["ref"],
        ["ref"],
        orderby="ref_count desc",
        limit=500,
    )
    dup_refs = [g for g in ref_groups if g.get("ref_count", 0) > 1]
    if dup_refs:
        rows_5: list[list[str]] = []
        for g in dup_refs[:15]:
            rows_5.append([str(g.get("ref", "")), str(g.get("ref_count", 0))])
        out.table(f"Duplicate Refs ({len(dup_refs)})", [("Reference", "cyan"), ("Count", "")], rows_5)
    _gate(
        "No duplicate refs",
        len(dup_refs) == 0,
        f"{len(dup_refs)} duplicate ref(s) found" if dup_refs else "All refs unique",
        warn=len(dup_refs) > 0 and len(dup_refs) <= 5,
    )

    # 5b: distinct move count vs total (sanity)
    total_posted = _sc(
        c, "account.move", [("company_id", "=", company), ("state", "=", "posted"), ("date", "<=", date)]
    )
    _gate(
        "Move count consistent", total_posted == total_moves, f"search_count={total_posted} vs read_group={total_moves}"
    )

    # ══════════════════════════════════════════════════════════════════
    # CHECK 6: Draft entries (should be 0 after migration)
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 6: DRAFT ENTRIES[/bold]")
    draft_count = _sc(c, "account.move", [("company_id", "=", company), ("state", "=", "draft")])
    _gate(
        "No draft entries",
        draft_count == 0,
        f"{draft_count} draft entries" if draft_count else "Clean — 0 drafts",
        warn=draft_count > 0,
    )

    # ══════════════════════════════════════════════════════════════════
    # CHECK 7: Suspense & outstanding accounts
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 7: SUSPENSE & OUTSTANDING ACCOUNTS[/bold]")
    suspense_names = ["Outstanding Payments", "Outstanding Receipts", "Bank Suspense"]
    suspense_issues = 0
    for sname in suspense_names:
        try:
            accts = c.search_read(
                "account.account",
                [("company_ids", "in", [company]), ("name", "=", sname)],
                ["id"],
                limit=1,
            )
            if accts:
                aid = accts[0]["id"]
                info = acct_map.get(aid)
                bal = info["balance"] if info else 0.0
                ok = abs(bal) < 0.01
                if not ok:
                    suspense_issues += 1
                _gate(sname, ok, f"balance={bal:,.2f}" if not ok else "0.00 ✓")
            else:
                _gate(sname, True, "account not found (OK)")
        except RPCError:
            _gate(sname, True, "skip — account lookup failed", warn=True)

    # ══════════════════════════════════════════════════════════════════
    # CHECK 8: P&L Net Income cross-check
    # ══════════════════════════════════════════════════════════════════
    out.info("\n[bold]CHECK 8: P&L NET INCOME[/bold]")
    # Compute P&L from GL: sum all income/expense account balances
    pnl_types = ("income", "income_other", "expense", "expense_direct_cost", "expense_depreciation")
    try:
        pnl_accts = c.search_read(
            "account.account",
            [("company_ids", "in", [company]), ("account_type", "in", list(pnl_types))],
            ["id", "name", "account_type"],
            limit=200,
        )
        pnl_aid_set = {a["id"] for a in pnl_accts}
        net_income = 0.0
        revenue = 0.0
        cogs = 0.0
        opex = 0.0
        non_op = 0.0
        for aid, info in acct_map.items():
            if aid not in pnl_aid_set:
                continue
            # Find account type
            atype = next((a["account_type"] for a in pnl_accts if a["id"] == aid), "")
            bal = info["balance"]
            if atype in ("income", "income_other"):
                net_income -= bal  # credit-normal → negate for positive income
                if atype == "income":
                    revenue -= bal
                else:
                    non_op -= bal
            else:
                net_income -= bal  # expense debits → subtract from income
                if atype == "expense_direct_cost":
                    cogs += bal
                elif atype == "expense":
                    opex += bal
                else:
                    non_op += bal

        out.info(f"   Revenue:      {revenue:>18,.2f}")
        out.info(f"   COGS:         {cogs:>18,.2f}")
        out.info(f"   Gross Profit: {revenue - cogs:>18,.2f}")
        out.info(f"   OpEx:         {opex:>18,.2f}")
        out.info(f"   Non-Op (net): {non_op:>18,.2f}")
        out.info(f"   [bold]Net Income:  {net_income:>18,.2f}[/bold]")
        _gate("Net Income computed", net_income != 0.0, f"{net_income:,.2f}")
    except RPCError as e:
        _gate("Net Income", False, f"RPC error: {e}")

    # ══════════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════════
    out.info("\n" + "=" * 72)
    total_checks = checks_pass + checks_fail + checks_warn
    if checks_fail == 0:
        overall = "[green]ALL GATES PASSED[/green]"
    else:
        overall = f"[red]{checks_fail} GATE(S) FAILED[/red]"

    out.info(f"  RESULT: {overall}")
    out.info(f"  {checks_pass}/{total_checks} pass | {checks_warn} warn | {checks_fail} fail")
    out.info(f"  Moves: {total_moves} | Lines: {total_lines:,} | Accounts: {len(acct_map)}")
    out.info(f"  Drafts: {draft_count} | Dup refs: {len(dup_refs)} | Suspense issues: {suspense_issues}")
    out.info("=" * 72)

    # ══════════════════════════════════════════════════════════════════
    # EXCEL EXPORT
    # ══════════════════════════════════════════════════════════════════
    if output and output.endswith(".xlsx"):
        try:
            import openpyxl
            from openpyxl.styles import Alignment, Font, PatternFill, numbers
        except ImportError:
            out.error("openpyxl not installed. Run: pip install openpyxl")
            raise typer.Exit(1)

        wb = openpyxl.Workbook()

        # --- Sheet 1: Summary ---
        ws1 = wb.active
        ws1.title = "Summary"
        header_font = Font(bold=True, size=12)
        bold = Font(bold=True)
        green_fill = PatternFill("solid", fgColor="C6EFCE")
        red_fill = PatternFill("solid", fgColor="FFC7CE")
        yellow_fill = PatternFill("solid", fgColor="FFEB9C")
        num_fmt = "#,##0.00"

        ws1.append(["Migration Data Quality Audit"])
        ws1["A1"].font = Font(bold=True, size=14)
        ws1.append([f"Company: {company}", f"Date: {date}"])
        ws1.append([f"Result: {checks_pass}/{total_checks} pass, {checks_warn} warn, {checks_fail} fail"])
        ws1.append([])
        ws1.append(["Check", "Status", "Detail"])
        for cell in ws1[5]:
            cell.font = bold
        for f in findings:
            status = "PASS" if f["pass"] else ("WARN" if f.get("warn") else "FAIL")
            row_idx = ws1.max_row + 1
            ws1.append([f["check"], status, f["detail"]])
            fill = green_fill if f["pass"] else (yellow_fill if f.get("warn") else red_fill)
            ws1.cell(row=row_idx, column=2).fill = fill
        ws1.column_dimensions["A"].width = 30
        ws1.column_dimensions["B"].width = 8
        ws1.column_dimensions["C"].width = 60

        # --- Sheet 2: Master Data ---
        ws2 = wb.create_sheet("Master Data")
        ws2.append(["Data", "Model", "Count"])
        for cell in ws2[1]:
            cell.font = bold
        for label, model, domain in master_models:
            cnt = _sc(c, model, domain)
            ws2.append([label, model, cnt])
        ws2.column_dimensions["A"].width = 30
        ws2.column_dimensions["B"].width = 25

        # --- Sheet 3: Moves by Journal ---
        ws3 = wb.create_sheet("Moves by Journal")
        ws3.append(["Journal", "Count", "Amount Total"])
        for cell in ws3[1]:
            cell.font = bold
        for g in sorted(move_groups, key=lambda x: -x.get("journal_id_count", 0)):
            jname = g["journal_id"][1] if isinstance(g["journal_id"], list) else str(g["journal_id"])
            ws3.append([jname, g.get("journal_id_count", 0), g.get("amount_total", 0) or 0])
            ws3.cell(row=ws3.max_row, column=3).number_format = num_fmt
        ws3.append(["TOTAL", total_moves, total_amount])
        for cell in ws3[ws3.max_row]:
            cell.font = bold
        ws3.cell(row=ws3.max_row, column=3).number_format = num_fmt
        ws3.column_dimensions["A"].width = 30
        ws3.column_dimensions["C"].width = 20

        # --- Sheet 4: Account Balances (the key sheet) ---
        ws4 = wb.create_sheet("Account Balances")
        ws4.append(["Account ID", "Account Name", "Lines", "Debit", "Credit", "Balance"])
        for cell in ws4[1]:
            cell.font = bold
        for aid in sorted(acct_map.keys(), key=lambda x: acct_map[x]["name"]):
            info = acct_map[aid]
            ws4.append([aid, info["name"], info["count"], info["debit"], info["credit"], info["balance"]])
            for col in (4, 5, 6):
                ws4.cell(row=ws4.max_row, column=col).number_format = num_fmt
        ws4.append(["", "TOTAL", total_lines, total_debit, total_credit, total_debit - total_credit])
        for cell in ws4[ws4.max_row]:
            cell.font = bold
        for col in (4, 5, 6):
            ws4.cell(row=ws4.max_row, column=col).number_format = num_fmt
        ws4.column_dimensions["A"].width = 10
        ws4.column_dimensions["B"].width = 35
        ws4.column_dimensions["D"].width = 20
        ws4.column_dimensions["E"].width = 20
        ws4.column_dimensions["F"].width = 20

        # --- Sheet 5: Duplicate Refs ---
        ws5 = wb.create_sheet("Duplicate Refs")
        ws5.append(["Reference", "Count"])
        for cell in ws5[1]:
            cell.font = bold
        for g in dup_refs:
            ws5.append([str(g.get("ref", "")), g.get("ref_count", 0)])
        ws5.column_dimensions["A"].width = 35

        wb.save(output)
        out.info(f"\n📊 Excel report saved: {output}")

    if actx.json_mode:
        out.raw_json(
            {
                "company_id": company,
                "date": date,
                "pass": checks_pass,
                "fail": checks_fail,
                "warn": checks_warn,
                "total_moves": total_moves,
                "total_lines": total_lines,
                "total_debit": total_debit,
                "total_credit": total_credit,
                "accounts": len(acct_map),
                "draft_count": draft_count,
                "duplicate_refs": len(dup_refs),
                "suspense_issues": suspense_issues,
                "findings": findings,
            }
        )


# ---------------------------------------------------------------------------
# migration-compare — Accurate API ↔ Odoo side-by-side comparison (Excel)
# ---------------------------------------------------------------------------

# In Accurate, EVERY transaction posts through a Journal Voucher (JV).
# The /api/journal-voucher API is the single source of truth for all GL
# postings. Each JV has:
#   - number: JV number (e.g. "JV.2026.04.00022")
#   - transNumber: source document number (e.g. "PI.TBI.23.IV.2026.003")
#     → this is what Odoo stores in account.move.ref
#   - transactionType: SI/PI/PAY/DEP/SR/PP/BT/JV etc.
#   - detailJournalVoucher: complete GL lines with account/debit/credit
# We fetch ONLY from journal-voucher — no need for 7 separate modules.


def _fetch_accurate_all(accurate_profile: str, out) -> list[dict]:
    """Fetch every Accurate GL posting via the journal-voucher API.

    Returns one dict per JV with: jv_number, trans_number (source doc ref),
    transaction_type, date, total, line_count, lines[].
    """
    from kctl_odoo.commands._accurate_sync._helpers import create_accurate_client

    client = create_accurate_client(accurate_profile)
    results: list[dict] = []

    page, all_ids = 1, []
    while True:
        resp = client.get(
            "/accurate/api/journal-voucher/list.do",
            params={"sp.page": page, "sp.pageSize": 100},
        )
        batch = resp.get("d", [])
        if not batch:
            break
        all_ids.extend(batch)
        total_rows = int((resp.get("sp") or {}).get("rowCount", 0))
        if page * 100 >= total_rows:
            break
        page += 1

    out.info(f"  journal-voucher API: {len(all_ids)} records, fetching details...")

    for rec in all_ids:
        det = client.get(
            "/accurate/api/journal-voucher/detail.do",
            params={"id": rec["id"]},
        ).get("d", {})

        lines = []
        for dl in det.get("detailJournalVoucher", []):
            gl = dl.get("glAccount") or {}
            lines.append(
                {
                    "acc_code": gl.get("number", ""),
                    "acc_name": gl.get("name", ""),
                    "debit": float(dl.get("debitAmount", 0) or 0),
                    "credit": float(dl.get("creditAmount", 0) or 0),
                    "qty": float(dl.get("quantity") or dl.get("itemQuantity") or 0),
                    "desc": (dl.get("description") or dl.get("itemName") or dl.get("invoiceNumber") or "")[:60],
                }
            )

        total_dr = sum(l["debit"] for l in lines)

        results.append(
            {
                "module": det.get("transactionType") or "JV",
                "accurate_id": rec["id"],
                "jv_number": det.get("number") or "",
                "number": det.get("transNumber") or det.get("number") or "",
                "trans_type_name": det.get("transactionTypeName") or "",
                "date": det.get("transDate") or "",
                "total": total_dr,
                "line_count": len(lines),
                "lines": lines,
            }
        )

    out.info(f"  Total: {len(results)} JVs with {sum(r['line_count'] for r in results)} lines")
    return results


@app.command("migration-compare")
def migration_compare(
    ctx: typer.Context,
    company: Annotated[int, typer.Argument(help="Odoo company ID")],
    accurate_profile: Annotated[str, typer.Option("--accurate-profile", "-a", help="Accurate kctl profile name")],
    output: Annotated[str, typer.Option("--output", "-o", help="Output Excel file path")] = "migration_compare.xlsx",
    date: Annotated[str, typer.Option("--date", "-d", help="As-of date YYYY-MM-DD")] = "2026-05-05",
) -> None:
    """Compare every journal entry between Accurate and Odoo — Excel report.

    Sheet 1 (Moves): Header-level comparison matched by Accurate ref.
    Sheet 2 (Lines): Line-level detail for each matched move.

    Examples:
        kctl-odoo data-quality migration-compare 340 -a terra-buah-internusa -o compare.xlsx
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # ── 1. Fetch Accurate data via SDK ───────────────────────────────
    out.info("Fetching Accurate transactions...")
    acc_moves = _fetch_accurate_all(accurate_profile, out)
    acc_by_number: dict[str, dict] = {}
    for m in acc_moves:
        if "number" in m:
            acc_by_number[m["number"]] = m
    out.info(f"Accurate: {len(acc_moves)} transactions")

    # ── 2. Fetch Odoo data via RPC ───────────────────────────────────
    out.info("Fetching Odoo journal entries...")
    odoo_moves_raw = c.search_read(
        "account.move",
        [("company_id", "=", company), ("state", "=", "posted"), ("date", "<=", date)],
        ["id", "name", "ref", "journal_id", "date", "amount_total", "amount_residual"],
        limit=500,
    )
    odoo_lines_raw = c.search_read(
        "account.move.line",
        [("company_id", "=", company), ("parent_state", "=", "posted"), ("date", "<=", date)],
        ["id", "move_id", "account_id", "debit", "credit", "balance", "name", "quantity", "ref"],
        limit=2000,
    )
    out.info(f"Odoo: {len(odoo_moves_raw)} moves, {len(odoo_lines_raw)} lines")

    # Group Odoo lines by move
    from collections import defaultdict

    odoo_lines_by_move: dict[int, list] = defaultdict(list)
    for ln in odoo_lines_raw:
        odoo_lines_by_move[ln["move_id"][0]].append(ln)

    # Build set of Odoo move IDs from Accurate sync (have ext-ids)
    accurate_synced_ids: set[int] = set()
    try:
        ext_ids = c.search_read(
            "ir.model.data",
            [("module", "=", "accurate"), ("model", "=", "account.move")],
            ["res_id"],
            limit=500,
        )
        accurate_synced_ids = {e["res_id"] for e in ext_ids}
    except Exception:
        pass

    # ── 3. Match Accurate ↔ Odoo by ref ──────────────────────────────
    # Odoo stores Accurate transaction number in the `ref` field.
    # Some refs have suffixes like " — TPP1", strip for matching.
    odoo_by_ref: dict[str, list] = defaultdict(list)
    for m in odoo_moves_raw:
        raw_ref = (m.get("ref") or "").strip()
        if not raw_ref:
            continue
        # Strip suffixes like " — TPP1"
        ref = raw_ref.split("—")[0].strip()  # em-dash
        # DON'T merge "Fee - X" into X — they're separate Odoo entries
        odoo_by_ref[ref].append(m)

    # Prefer Accurate-synced entries when multiple Odoo moves share the same ref
    for ref_key, moves in odoo_by_ref.items():
        moves.sort(key=lambda m: (0 if m["id"] in accurate_synced_ids else 1, m["id"]))

    # ── 4. Build Excel ───────────────────────────────────────────────
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except ImportError:
        out.error("openpyxl required: pip install openpyxl")
        raise typer.Exit(1)

    wb = openpyxl.Workbook()
    bold = Font(bold=True)
    hf = Font(bold=True, color="FFFFFF")
    hfill = PatternFill("solid", fgColor="1F4E79")
    green = PatternFill("solid", fgColor="C6EFCE")
    red = PatternFill("solid", fgColor="FFC7CE")
    yellow = PatternFill("solid", fgColor="FFEB9C")
    nf = "#,##0.00"

    def _hdr(ws, row, headers):
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=row, column=col, value=h)
            cell.font = hf
            cell.fill = hfill

    # ── Sheet 1: Moves (header comparison) ───────────────────────────
    ws1 = wb.active
    ws1.title = "Moves"
    ws1["A1"] = f"Move Comparison — Company {company} — {date}"
    ws1["A1"].font = Font(bold=True, size=13)

    s1_hdrs = [
        "Accurate Number",
        "Accurate Module",
        "Accurate Date",
        "Odoo Name",
        "Odoo Ref",
        "Odoo Journal",
        "Odoo Date",
        "Line Count Accurate",
        "Line Count Odoo",
        "Amount Accurate",
        "Amount Odoo",
        "Amount Residual Odoo",
        "Diff Line Count",
        "Diff Amount",
        "Status",
    ]
    _hdr(ws1, 3, s1_hdrs)

    all_acc_numbers = set(acc_by_number.keys())
    all_odoo_refs = set(odoo_by_ref.keys())
    matched_refs = all_acc_numbers & all_odoo_refs
    acc_only = all_acc_numbers - all_odoo_refs
    odoo_only = all_odoo_refs - all_acc_numbers

    row = 4
    match_count = 0

    # Matched — aggregate ALL Odoo moves sharing the same ref
    for num in sorted(matched_refs):
        acc = acc_by_number[num]
        odoo_list = odoo_by_ref[num]

        # Combine all Odoo moves + lines for this ref
        all_odoo_lns: list = []
        odoo_names: list[str] = []
        odoo_journals: list[str] = []
        odoo_dates: list[str] = []
        for m in odoo_list:
            odoo_names.append(m["name"])
            odoo_journals.append(m["journal_id"][1] if m.get("journal_id") else "")
            odoo_dates.append(m["date"])
            all_odoo_lns.extend(odoo_lines_by_move.get(m["id"], []))

        # For SI JVs, also include COGS entries (separate moves in Odoo)
        if acc.get("module") == "SI":
            jv_num = acc.get("jv_number", "")
            if jv_num and jv_num in odoo_by_ref:
                for cogs_move in odoo_by_ref[jv_num]:
                    all_odoo_lns.extend(odoo_lines_by_move.get(cogs_move["id"], []))
                    odoo_names.append(cogs_move["name"])

        # For PI JVs, also include receiving entries (separate moves in Odoo)
        if acc.get("module") == "PI":
            jv_num = acc.get("jv_number", "")
            if jv_num and jv_num in odoo_by_ref:
                for recv_move in odoo_by_ref[jv_num]:
                    all_odoo_lns.extend(odoo_lines_by_move.get(recv_move["id"], []))
                    odoo_names.append(recv_move["name"])

        acc_lc = acc["line_count"]
        odoo_lc = len(all_odoo_lns)
        acc_amt = acc["total"]
        odoo_amt = sum(l["debit"] for l in all_odoo_lns)
        odoo_res = sum(abs(m.get("amount_residual", 0) or 0) for m in odoo_list)
        diff_lc = odoo_lc - acc_lc
        diff_amt = odoo_amt - acc_amt
        amt_ok = abs(diff_amt) < 1
        lc_ok = diff_lc == 0
        ok = amt_ok and lc_ok
        if ok:
            match_count += 1
        status = "✓" if ok else ("≈ amt ok" if amt_ok else "✗")

        vals = [
            num,
            acc["module"],
            acc["date"],
            " + ".join(odoo_names),
            odoo_list[0].get("ref", ""),
            " + ".join(dict.fromkeys(odoo_journals)),
            odoo_dates[0],
            acc_lc,
            odoo_lc,
            acc_amt,
            odoo_amt,
            odoo_res,
            diff_lc,
            diff_amt,
            status,
        ]
        for col, v in enumerate(vals, 1):
            cell = ws1.cell(row=row, column=col, value=v)
            if col in (10, 11, 12, 14):
                cell.number_format = nf
            if col == 15:
                cell.fill = green if ok else (yellow if amt_ok else red)
        row += 1

    # Accurate only (missing in Odoo)
    for num in sorted(acc_only):
        acc = acc_by_number[num]
        vals = [
            num,
            acc["module"],
            acc["date"],
            "",
            "",
            "",
            "",
            acc["line_count"],
            0,
            acc["total"],
            0,
            0,
            -acc["line_count"],
            -acc["total"],
            "MISSING IN ODOO",
        ]
        for col, v in enumerate(vals, 1):
            cell = ws1.cell(row=row, column=col, value=v)
            if col in (10, 11, 12, 14):
                cell.number_format = nf
            if col == 15:
                cell.fill = red
        row += 1

    # Odoo only (extra, not in Accurate)
    for ref in sorted(odoo_only):
        for odoo in odoo_by_ref[ref]:
            odoo_lns = odoo_lines_by_move.get(odoo["id"], [])
            odoo_dr = sum(l["debit"] for l in odoo_lns)
            jname = odoo["journal_id"][1] if odoo.get("journal_id") else ""
            vals = [
                "",
                "",
                "",
                odoo["name"],
                odoo.get("ref", ""),
                jname,
                odoo["date"],
                0,
                len(odoo_lns),
                0,
                odoo_dr,
                odoo.get("amount_residual", 0) or 0,
                len(odoo_lns),
                odoo_dr,
                "EXTRA IN ODOO",
            ]
            for col, v in enumerate(vals, 1):
                cell = ws1.cell(row=row, column=col, value=v)
                if col in (10, 11, 12, 14):
                    cell.number_format = nf
                if col == 15:
                    cell.fill = yellow
            row += 1

    for w, c in [
        (25, "A"),
        (16, "B"),
        (12, "C"),
        (22, "D"),
        (40, "E"),
        (22, "F"),
        (12, "G"),
        (8, "H"),
        (8, "I"),
        (18, "J"),
        (18, "K"),
        (18, "L"),
        (8, "M"),
        (18, "N"),
        (16, "O"),
    ]:
        ws1.column_dimensions[c].width = w
    ws1.freeze_panes = "A4"
    ws1.auto_filter.ref = f"A3:O{row - 1}"

    # ── Sheet 2: Lines (detail comparison) ───────────────────────────
    ws2 = wb.create_sheet("Lines")
    ws2["A1"] = f"Line Comparison — Company {company} — {date}"
    ws2["A1"].font = Font(bold=True, size=13)

    s2_hdrs = [
        "Transaction Number",
        "Line#",
        "Acc Code Odoo",
        "Acc Name Odoo",
        "Acc Code Accurate",
        "Acc Name Accurate",
        "Qty Odoo",
        "Qty Accurate",
        "Debit Odoo",
        "Debit Accurate",
        "Credit Odoo",
        "Credit Accurate",
        "Balance Odoo",
        "Balance Accurate",
        "Diff Debit",
        "Diff Credit",
        "Diff Balance",
    ]
    _hdr(ws2, 3, s2_hdrs)

    row2 = 4
    for num in sorted(matched_refs):
        acc = acc_by_number[num]
        odoo_list = odoo_by_ref[num]
        odoo = odoo_list[0]
        odoo_lns = sorted(odoo_lines_by_move.get(odoo["id"], []), key=lambda x: x["id"])
        acc_lns = acc.get("lines", [])

        max_lines = max(len(odoo_lns), len(acc_lns))
        for i in range(max_lines):
            ol = odoo_lns[i] if i < len(odoo_lns) else {}
            al = acc_lns[i] if i < len(acc_lns) else {}

            o_code = (ol.get("account_id") or [0, ""])[1][:15] if ol else ""
            o_name = (ol.get("account_id") or [0, ""])[1] if ol else ""
            o_dr = ol.get("debit", 0) if ol else 0
            o_cr = ol.get("credit", 0) if ol else 0
            o_bal = ol.get("balance", 0) if ol else 0
            o_qty = ol.get("quantity", 0) if ol else 0

            a_code = al.get("acc_code", "") if al else ""
            a_name = al.get("acc_name", "") if al else ""
            a_dr = al.get("debit", 0) if al else 0
            a_cr = al.get("credit", 0) if al else 0
            a_bal = a_dr - a_cr
            a_qty = al.get("qty", 0) if al else 0

            vals = [
                num if i == 0 else "",
                i + 1,
                o_code,
                o_name[:30],
                a_code,
                a_name[:30],
                o_qty,
                a_qty,
                o_dr,
                a_dr,
                o_cr,
                a_cr,
                o_bal,
                a_bal,
                o_dr - a_dr,
                o_cr - a_cr,
                o_bal - a_bal,
            ]
            for col, v in enumerate(vals, 1):
                cell = ws2.cell(row=row2, column=col, value=v)
                if col >= 7:
                    cell.number_format = nf
                if col >= 15 and isinstance(v, (int, float)) and abs(v) > 0.01:
                    cell.fill = red
            row2 += 1

    for w, c in [
        (25, "A"),
        (5, "B"),
        (14, "C"),
        (25, "D"),
        (14, "E"),
        (25, "F"),
        (10, "G"),
        (10, "H"),
        (16, "I"),
        (16, "J"),
        (16, "K"),
        (16, "L"),
        (16, "M"),
        (16, "N"),
        (14, "O"),
        (14, "P"),
        (14, "Q"),
    ]:
        ws2.column_dimensions[c].width = w
    ws2.freeze_panes = "A4"
    ws2.auto_filter.ref = f"A3:Q{row2 - 1}"

    wb.save(output)
    out.info(f"\n📊 Saved: {output}")
    out.info(
        f"   Matched: {match_count}/{len(matched_refs)} | Missing in Odoo: {len(acc_only)} | Extra in Odoo: {len(odoo_only)}"
    )
    out.info(f"   Sheet 1: {row - 4} move rows | Sheet 2: {row2 - 4} line rows")
