"""Mapping resolution helpers for Accurate → Odoo live sync.

All ``resolve_*`` functions query Odoo (via OdooClient) and return an integer
record ID on success or ``None`` when no match is found.

``create_accurate_client`` builds an AccurateClient from the ``kctl-accurate``
profile stored in ``~/.config/kodemeio/config.yaml`` (service key: ``accurate``).
``write_audit_file`` writes a JSON audit trail to a timestamped directory under
``/tmp/accurate-sync/<profile>/<timestamp>/``.
``accurate_date_to_odoo`` converts Accurate's ``DD/MM/YYYY`` wire format to
Odoo's ``YYYY-MM-DD``.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml
from accurate_sdk import AccurateClient

if TYPE_CHECKING:
    from kctl_odoo.core.client import OdooClient

_DEFAULT_CONFIG_PATH = Path("~/.config/kodemeio/config.yaml").expanduser()

# ---------------------------------------------------------------------------
# AccurateClient factory
# ---------------------------------------------------------------------------


def create_accurate_client(
    profile: str,
    config_path: Path = _DEFAULT_CONFIG_PATH,
) -> AccurateClient:
    """Build an :class:`AccurateClient` from the kctl-accurate profile.

    Reads ``profiles.<profile>.accurate.{api_token,signature_secret,host}``
    from ``~/.config/kodemeio/config.yaml``.  Raises :exc:`typer.BadParameter`
    when the required keys are absent.
    """
    import typer

    if not config_path.exists():
        raise typer.BadParameter(f"kctl config not found at {config_path}")

    raw = yaml.safe_load(config_path.read_text()) or {}
    try:
        section: dict[str, Any] = raw["profiles"][profile]["accurate"]
    except (KeyError, TypeError) as exc:
        raise typer.BadParameter(f"Profile '{profile}' has no 'accurate' section in {config_path}") from exc

    api_token: str = section.get("api_token", "")
    signature_secret: str = section.get("signature_secret", "")
    host: str | None = section.get("host") or None

    if not api_token:
        raise typer.BadParameter(f"profiles.{profile}.accurate.api_token is missing in {config_path}")
    if not signature_secret:
        raise typer.BadParameter(f"profiles.{profile}.accurate.signature_secret is missing in {config_path}")

    return AccurateClient(
        api_token=api_token,
        signature_secret=signature_secret,
        host=host,
    )


# ---------------------------------------------------------------------------
# Date conversion
# ---------------------------------------------------------------------------


def accurate_date_to_odoo(date_str: str) -> str:
    """Convert Accurate's ``DD/MM/YYYY`` format to Odoo's ``YYYY-MM-DD``.

    Passes ISO strings through unchanged.  Returns the original string on
    parse failure so callers can surface the raw value rather than silently
    dropping it.
    """
    if not date_str:
        return date_str
    s = date_str.strip()
    # Already ISO format
    if len(s) == 10 and s[4] == "-":
        return s
    # Accurate wire format: DD/MM/YYYY or DD/MM/YYYY HH:mm:ss
    if " " in s:
        s = s.split(" ", 1)[0]
    for fmt in ("%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return date_str  # return original on failure


# ---------------------------------------------------------------------------
# Audit file writer
# ---------------------------------------------------------------------------


def write_audit_file(
    profile: str,
    entity: str,
    records: list[dict[str, Any]],
) -> Path:
    """Write ``records`` as JSON to a timestamped audit directory.

    Output path: ``/tmp/accurate-sync/<profile>/<timestamp>/<entity>.json``

    Returns the :class:`Path` of the written file.
    """
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    out_dir = Path("/tmp/accurate-sync") / profile / ts
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"{entity}.json"
    out_file.write_text(json.dumps(records, ensure_ascii=False, indent=2, default=str))
    return out_file


# ---------------------------------------------------------------------------
# Odoo resolution helpers
# ---------------------------------------------------------------------------
# All functions accept an OdooClient as ``client`` and return int|None.
# They deliberately avoid raising so callers can decide how to handle misses.


def resolve_account_by_name(
    client: OdooClient,
    company_id: int,
    name: str,
    account_type: str | None = None,
) -> int | None:
    """Resolve an ``account.account`` by (partial) name within a company.

    ``account_type`` narrows the domain when supplied (e.g. ``'liability_payable'``).
    Returns the *first* matching record ID, or ``None``.

    In Odoo 18 ``account.account`` uses a Many2many ``company_ids`` field instead
    of ``company_id``.  We try ``company_ids`` first and fall back to the legacy
    ``company_id`` field so this helper works across Odoo versions.
    """
    # Odoo 18: company_ids (Many2many)
    domain: list[Any] = [
        ["company_ids", "in", [company_id]],
        ["name", "ilike", name],
    ]
    if account_type:
        domain.append(["account_type", "=", account_type])
    try:
        ids = client.search("account.account", domain, limit=1)
        if ids:
            return ids[0]
    except Exception:  # noqa: BLE001
        pass

    # Fallback: Odoo ≤17 company_id (Many2one)
    domain_legacy: list[Any] = [
        ["company_id", "=", company_id],
        ["name", "ilike", name],
    ]
    if account_type:
        domain_legacy.append(["account_type", "=", account_type])
    try:
        ids = client.search("account.account", domain_legacy, limit=1)
        if ids:
            return ids[0]
    except Exception:  # noqa: BLE001
        pass
    return None


def resolve_account_by_code(
    client: OdooClient,
    company_id: int,
    code: str,
) -> int | None:
    """Resolve an ``account.account`` by its GL code within a company.

    Tries Odoo 18 ``company_ids`` first, falls back to legacy ``company_id``.
    Returns the *first* matching record ID, or ``None``.
    """
    domain: list[Any] = [
        ["company_ids", "in", [company_id]],
        ["code", "=", code],
    ]
    try:
        ids = client.search("account.account", domain, limit=1)
        if ids:
            return ids[0]
    except Exception:  # noqa: BLE001
        pass

    domain_legacy: list[Any] = [
        ["company_id", "=", company_id],
        ["code", "=", code],
    ]
    try:
        ids = client.search("account.account", domain_legacy, limit=1)
        if ids:
            return ids[0]
    except Exception:  # noqa: BLE001
        pass
    return None


def resolve_partner_by_ref(
    client: OdooClient,
    company_id: int,
    ref: str,
) -> int | None:
    """Resolve a ``res.partner`` by its internal reference within a company."""
    domain: list[Any] = [
        "|",
        ("company_id", "=", company_id),
        ("company_id", "=", False),
        ("ref", "=", ref),
    ]
    ids = client.search("res.partner", domain, limit=1)
    return ids[0] if ids else None


def resolve_product_by_code(
    client: OdooClient,
    company_id: int,
    code: str,
) -> int | None:
    """Resolve a ``product.product`` by its internal reference (default code)."""
    domain: list[Any] = [
        "|",
        ("company_id", "=", company_id),
        ("company_id", "=", False),
        ("default_code", "=", code),
    ]
    ids = client.search("product.product", domain, limit=1)
    return ids[0] if ids else None


def resolve_uom_by_name(
    client: OdooClient,
    name: str,
) -> int | None:
    """Resolve a ``uom.uom`` by name (case-insensitive exact match)."""
    domain: list[Any] = [["name", "ilike", name]]
    ids = client.search("uom.uom", domain, limit=1)
    return ids[0] if ids else None


def resolve_payment_term_by_name(
    client: OdooClient,
    name: str,
) -> int | None:
    """Resolve an ``account.payment.term`` by name."""
    domain: list[Any] = [["name", "ilike", name]]
    ids = client.search("account.payment.term", domain, limit=1)
    return ids[0] if ids else None


def resolve_currency_by_code(
    client: OdooClient,
    code: str,
) -> int | None:
    """Resolve a ``res.currency`` by its ISO code (e.g. ``'IDR'``, ``'USD'``)."""
    domain: list[Any] = [["name", "=", code.upper()]]
    ids = client.search("res.currency", domain, limit=1)
    return ids[0] if ids else None


def resolve_journal_by_code(
    client: OdooClient,
    company_id: int,
    code: str,
) -> int | None:
    """Resolve an ``account.journal`` by its short code within a company."""
    domain: list[Any] = [
        ["company_id", "=", company_id],
        ["code", "=", code],
    ]
    ids = client.search("account.journal", domain, limit=1)
    return ids[0] if ids else None


# ---------------------------------------------------------------------------
# Currency-aware AP / AR account helpers
# ---------------------------------------------------------------------------
# Accurate uses separate GL accounts per currency for payables / receivables.
# The naming conventions below reflect the TPP/MAC chart of accounts.

_AP_ACCOUNT_NAMES: dict[str, str] = {
    "CNY": "Utang Dagang CNY",
    "USD": "Utang Dagang USD",
    "IDR": "Utang Usaha",  # also matched via ilike "Utang Dagang IDR"
}

_AR_ACCOUNT_NAMES: dict[str, str] = {
    "CNY": "Piutang Dagang CNY",
    "USD": "Piutang Dagang USD",
    "IDR": "Piutang Dagang",
}


def ap_account_for_currency(
    client: OdooClient,
    company_id: int,
    currency_code: str,
) -> int | None:
    """Return the AP (payable) account ID for the given currency code.

    Mapping (Indonesian CoA convention):
    - ``CNY`` → Utang Dagang CNY
    - ``USD`` → Utang Dagang USD
    - ``IDR`` → Utang Usaha / Utang Dagang IDR (fallback)
    """
    name_hint = _AP_ACCOUNT_NAMES.get(currency_code.upper(), f"Utang Dagang {currency_code.upper()}")
    result = resolve_account_by_name(client, company_id, name_hint, account_type="liability_payable")
    if result is None and currency_code.upper() == "IDR":
        # Fallback: some CoAs use "Utang Dagang IDR" as well
        result = resolve_account_by_name(client, company_id, "Utang Dagang IDR", account_type="liability_payable")
    return result


def ar_account_for_currency(
    client: OdooClient,
    company_id: int,
    currency_code: str,
) -> int | None:
    """Return the AR (receivable) account ID for the given currency code.

    Mapping (Indonesian CoA convention):
    - ``CNY`` → Piutang Dagang CNY
    - ``USD`` → Piutang Dagang USD
    - ``IDR`` → Piutang Dagang (generic)
    """
    name_hint = _AR_ACCOUNT_NAMES.get(currency_code.upper(), f"Piutang Dagang {currency_code.upper()}")
    return resolve_account_by_name(client, company_id, name_hint, account_type="asset_receivable")


def goods_in_transit_account(
    client: OdooClient,
    company_id: int,
) -> int | None:
    """Return the "Barang Dalam Pengiriman" (goods-in-transit) account ID."""
    return resolve_account_by_name(client, company_id, "Barang Dalam Pengiriman")
