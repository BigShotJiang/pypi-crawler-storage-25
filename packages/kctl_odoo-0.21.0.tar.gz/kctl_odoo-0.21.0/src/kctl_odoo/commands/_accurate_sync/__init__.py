"""Accurate → Odoo live sync commands.

Granular per-entity commands plus bulk `masters`/`transactions` and `status`.

Usage examples:
    kctl-odoo accurate sync setup terra-buah -c 340
    kctl-odoo accurate sync items terra-buah -c 340
    kctl-odoo accurate sync purchase-order terra-buah -c 340 --since 2026-03-01
    kctl-odoo accurate sync masters terra-buah -c 340
    kctl-odoo accurate sync transactions terra-buah -c 340
    kctl-odoo accurate sync status terra-buah -c 340
"""

import typer

from kctl_odoo.commands._accurate_sync.masters import sync_masters
from kctl_odoo.commands._accurate_sync.setup import sync_setup
from kctl_odoo.commands._accurate_sync.status import sync_status
from kctl_odoo.commands._accurate_sync.transactions import fix_bill_expenses, sync_transactions
from kctl_odoo.commands._accurate_sync.validate_journals import validate_journals_cmd

app = typer.Typer(help="Live sync between Accurate Online and Odoo.")

# Bootstrap
app.command("setup")(sync_setup)

# Bulk
app.command("masters", help="Sync all master data (items + vendors + customers)")(sync_masters)
app.command("transactions", help="Sync all transactions")(sync_transactions)

# Reporting
app.command("status")(sync_status)


# Granular master data commands
def _master_cmd(entity: str, help_text: str) -> None:
    from typing import Annotated

    def cmd(
        ctx: typer.Context,
        profile: Annotated[str, typer.Argument(help="kctl-accurate profile name")],
        odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo company ID")],
        dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    ) -> None:
        sync_masters(ctx, profile, odoo_company, include=entity, dry_run=dry_run)

    cmd.__doc__ = help_text
    app.command(entity)(cmd)


_master_cmd("items", "Sync items → product.template")
_master_cmd("vendors", "Sync vendors → res.partner (supplier)")
_master_cmd("customers", "Sync customers → res.partner (customer)")
_master_cmd("accounts", "Sync GL accounts → account.account")
_master_cmd("categories", "Sync item categories → product.category")
_master_cmd("payment-terms", "Sync payment terms → account.payment.term")
_master_cmd("warehouses", "Sync warehouses → stock.warehouse")
_master_cmd("taxes", "Sync taxes → account.tax")
_master_cmd("currencies", "Sync currencies → res.currency")


# Granular transaction commands
def _txn_cmd(entity: str, help_text: str) -> None:
    from typing import Annotated

    def cmd(
        ctx: typer.Context,
        profile: Annotated[str, typer.Argument(help="kctl-accurate profile name")],
        odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo company ID")],
        since: Annotated[str | None, typer.Option("--since")] = None,
        dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    ) -> None:
        sync_transactions(ctx, profile, odoo_company, include=entity, since=since, dry_run=dry_run)

    cmd.__doc__ = help_text
    app.command(entity)(cmd)


_txn_cmd("purchase-request", "Sync purchase requisitions → purchase.request")
_txn_cmd("purchase-order", "Sync purchase orders → purchase.order")
_txn_cmd("purchase-invoice", "Sync purchase invoices → account.move (vendor bill)")
_txn_cmd("purchase-payment", "Sync purchase payments → account.payment")
_txn_cmd("receive-item", "Sync receive items → stock.picking")
_txn_cmd("sales-invoice", "Sync sales invoices → account.move (customer invoice)")
_txn_cmd("sales-receipt", "Sync sales receipts → account.payment (inbound)")
_txn_cmd("journal-voucher", "Sync journal vouchers → account.move (general entry, legacy detailItem)")
_txn_cmd("all-journals", "Sync ALL journal vouchers (JV-driven, exact GL from detailJournalVoucher)")
_txn_cmd("bank-transfer", "Sync bank transfers → account.move (transfer entry)")
_txn_cmd("other-payment", "Sync other payments → account.move (general entry)")
_txn_cmd("other-deposit", "Sync other deposits → account.move (general entry)")
_txn_cmd("expense", "Sync expenses → account.move (general entry)")
_txn_cmd("sales-order", "Sync sales orders → sale.order (confirmed)")
_txn_cmd("sales-return", "Sync sales returns → account.move (out_refund credit note)")
_txn_cmd("purchase-return", "Sync purchase returns → account.move (in_refund vendor credit)")
_txn_cmd("item-adjustment", "Sync item adjustments → stock operations (log only)")
_txn_cmd("item-transfer", "Sync item transfers → stock.picking (log only)")
# Backfill / repair commands
app.command("fix-bill-expenses", help="Backfill detailExpense (Biaya Lainnya) lines on existing vendor bills")(
    fix_bill_expenses
)

# Standalone validate-journals command (report + fix, uses jv_comparator/jv_fixer)
app.command("validate-journals", help="Validate Odoo journals against Accurate JVs — report + fix")(
    validate_journals_cmd
)
