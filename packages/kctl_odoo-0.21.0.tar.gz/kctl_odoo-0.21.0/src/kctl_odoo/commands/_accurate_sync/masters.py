"""sync-masters: sync Accurate items, vendors, customers, and supporting
master data into Odoo.

Operations:
  1. accounts        — GL accounts → account.account
  2. categories      — item categories → product.category
  3. items           — items → product.template
  4. vendors         — vendors → res.partner (supplier)
  5. customers       — customers → res.partner (customer)
  6. payment-terms   — payment terms → account.payment.term
  7. warehouses      — warehouses (log only — creation is complex)
  8. taxes           — taxes (log only — mapping is complex)
  9. currencies      — currencies → res.currency (activate + rate)

All operations deduplicate before creating — idempotent.
"""

from __future__ import annotations

from typing import Annotated, Any

import httpx
import typer

from kctl_odoo.core.callbacks import AppContext

from ._helpers import (
    ap_account_for_currency,
    ar_account_for_currency,
    create_accurate_client,
    resolve_payment_term_by_name,
    resolve_uom_by_name,
    write_audit_file,
)

# ---------------------------------------------------------------------------
# Counter
# ---------------------------------------------------------------------------


class _Counter:
    def __init__(self) -> None:
        self.created = 0
        self.updated = 0
        self.skipped = 0
        self.errors = 0

    def to_row(self, section: str) -> list[str]:
        return [
            section,
            str(self.created),
            str(self.updated),
            str(self.skipped),
            str(self.errors),
        ]


# ---------------------------------------------------------------------------
# Accurate item type → Odoo product type
# ---------------------------------------------------------------------------

_ITEM_TYPE_MAP: dict[str, str] = {
    "INVENTORY": "consu",
    "SERVICE": "service",
    "NON_INVENTORY": "consu",
}


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


MASTER_ENTITIES = (
    "accounts",
    "categories",
    "items",
    "vendors",
    "customers",
    "payment-terms",
    "warehouses",
    "taxes",
    "currencies",
)


def sync_masters(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name (e.g. terra-buah-internusa)")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
    include: Annotated[
        str | None,
        typer.Option(
            "--include", "-i", help=f"Comma-separated entities to sync ({','.join(MASTER_ENTITIES)}). Default: all."
        ),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without making changes")] = False,
) -> None:
    """Sync Accurate master data into Odoo.

    Nine sync operations (in recommended order):
      1. accounts       → account.account          (match by name)
      2. categories     → product.category         (match by name)
      3. items          → product.template          (match by default_code)
      4. vendors        → res.partner (supplier)    (match by ref)
      5. customers      → res.partner (customer)    (match by ref)
      6. payment-terms  → account.payment.term      (match by name)
      7. warehouses     → (log only — creation complex)
      8. taxes          → (log only — mapping complex)
      9. currencies     → res.currency              (activate + rate)

    Use --include to sync specific entities only:
      --include items
      --include vendors,customers
      --include accounts,categories,items  (etc.)

    Each operation is idempotent — existing records are updated, new ones are
    created, and records with no field changes are skipped.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    selected = set(include.split(",")) if include else set(MASTER_ENTITIES)
    invalid = selected - set(MASTER_ENTITIES)
    if invalid:
        out.error(f"Unknown entities: {', '.join(invalid)}. Valid: {', '.join(MASTER_ENTITIES)}")
        raise typer.Exit(1)

    # Extend timeout for large Accurate list calls
    try:
        c._client.timeout = httpx.Timeout(1800.0)
    except Exception:  # noqa: BLE001
        pass

    dry_label = " (DRY-RUN)" if dry_run else ""
    out.header(f"sync-masters: profile={profile!r}  odoo_company={odoo_company}{dry_label}")

    acc_client = create_accurate_client(profile)

    summary_rows: list[list[str]] = []
    all_audit: dict[str, list[dict[str, Any]]] = {}

    # -------------------------------------------------------------------
    # Step: GL Accounts → account.account
    # -------------------------------------------------------------------
    if "accounts" in selected:
        out.info("Syncing accounts → account.account...")
        ctr, audit = _step_accounts(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(ctr.to_row("accounts → account.account"))
        all_audit["accounts"] = audit

    # -------------------------------------------------------------------
    # Step: Item Categories → product.category
    # -------------------------------------------------------------------
    if "categories" in selected:
        out.info("Syncing categories → product.category...")
        ctr, audit = _step_categories(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(ctr.to_row("categories → product.category"))
        all_audit["categories"] = audit

    # -------------------------------------------------------------------
    # Step: Items → Products
    # -------------------------------------------------------------------
    if "items" in selected:
        out.info("Syncing items → product.template...")
        item_ctr, item_audit = _step_items(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(item_ctr.to_row("items → product.template"))
        all_audit["items"] = item_audit

    # -------------------------------------------------------------------
    # Step: Vendors → Partners
    # -------------------------------------------------------------------
    if "vendors" in selected:
        out.info("Syncing vendors → res.partner (supplier)...")
        vendor_ctr, vendor_audit = _step_vendors(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(vendor_ctr.to_row("vendors → res.partner (supplier)"))
        all_audit["vendors"] = vendor_audit

    # -------------------------------------------------------------------
    # Step: Customers → Partners
    # -------------------------------------------------------------------
    if "customers" in selected:
        out.info("Syncing customers → res.partner (customer)...")
        customer_ctr, customer_audit = _step_customers(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(customer_ctr.to_row("customers → res.partner (customer)"))
        all_audit["customers"] = customer_audit

    # -------------------------------------------------------------------
    # Step: Payment Terms → account.payment.term
    # -------------------------------------------------------------------
    if "payment-terms" in selected:
        out.info("Syncing payment-terms → account.payment.term...")
        ctr, audit = _step_payment_terms(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(ctr.to_row("payment-terms → account.payment.term"))
        all_audit["payment_terms"] = audit

    # -------------------------------------------------------------------
    # Step: Warehouses (log only)
    # -------------------------------------------------------------------
    if "warehouses" in selected:
        out.info("Syncing warehouses (log only — creation deferred)...")
        ctr, audit = _step_warehouses(c, acc_client, dry_run, out)
        summary_rows.append(ctr.to_row("warehouses → (deferred)"))
        all_audit["warehouses"] = audit

    # -------------------------------------------------------------------
    # Step: Taxes (log only)
    # -------------------------------------------------------------------
    if "taxes" in selected:
        out.info("Syncing taxes (log only — mapping deferred)...")
        ctr, audit = _step_taxes(c, acc_client, dry_run, out)
        summary_rows.append(ctr.to_row("taxes → (deferred)"))
        all_audit["taxes"] = audit

    # -------------------------------------------------------------------
    # Step: Currencies → res.currency
    # -------------------------------------------------------------------
    if "currencies" in selected:
        out.info("Syncing currencies → res.currency...")
        ctr, audit = _step_currencies(c, acc_client, odoo_company, dry_run, out)
        summary_rows.append(ctr.to_row("currencies → res.currency"))
        all_audit["currencies"] = audit

    # -------------------------------------------------------------------
    # Audit file
    # -------------------------------------------------------------------
    audit_path = write_audit_file(profile, "masters", [all_audit])
    out.info(f"Audit written to: {audit_path}")

    # -------------------------------------------------------------------
    # Summary table
    # -------------------------------------------------------------------
    out.table(
        f"sync-masters summary{dry_label}",
        [
            ("Entity", ""),
            ("Created", "green"),
            ("Updated", "yellow"),
            ("Skipped", "dim"),
            ("Errors", "red"),
        ],
        summary_rows,
    )


# ---------------------------------------------------------------------------
# Accurate account type → Odoo account_type mapping
# ---------------------------------------------------------------------------

_ACCOUNT_TYPE_MAP: dict[str, str] = {
    "CASH_BANK": "asset_cash",
    "ACCOUNT_RECEIVABLE": "asset_receivable",
    "INVENTORY": "asset_current",
    "FIXED_ASSET": "asset_fixed",
    "ACCOUNT_PAYABLE": "liability_payable",
    "OTHER_CURRENT_LIABILITY": "liability_current",
    "EQUITY": "equity",
    "REVENUE": "income",
    "COGS": "expense_direct_cost",
    "EXPENSE": "expense",
    "OTHER_INCOME": "income_other",
    "OTHER_EXPENSE": "expense",
    "ACCUMULATED_DEPRECIATION": "asset_current",
    "OTHER_CURRENT_ASSET": "asset_current",
    "LONG_TERM_LIABILITY": "liability_non_current",
}


# ---------------------------------------------------------------------------
# Step: GL Accounts → account.account
# ---------------------------------------------------------------------------


def _step_accounts(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching GL account list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/gl-account/list.do",
        params={"fields": "id,number,name,accountType,isHeader"},
    )
    if not raw_list:
        out.info("  No GL accounts found in Accurate.")
        return ctr, audit

    # Build existing Odoo accounts index by name for this company
    existing = c.search_read(
        "account.account",
        domain=[("company_id", "=", odoo_company)],
        fields=["id", "name", "code"],
        limit=0,
    )
    existing_by_name: dict[str, dict[str, Any]] = {r["name"]: r for r in existing}

    for rec in raw_list:
        # Skip header/group accounts (ones with children)
        if rec.get("isHeader"):
            ctr.skipped += 1
            continue

        acc_name: str = str(rec.get("name", "")).strip()
        acc_number: str = str(rec.get("number", "")).strip()
        acc_type_raw: str = str(rec.get("accountType", "")).upper()

        if not acc_name:
            ctr.skipped += 1
            continue

        odoo_account_type = _ACCOUNT_TYPE_MAP.get(acc_type_raw, "expense")

        existing_rec = existing_by_name.get(acc_name)

        if existing_rec:
            ctr.skipped += 1
            audit.append({"action": "skip", "name": acc_name, "odoo_id": existing_rec["id"]})
            continue

        vals: dict[str, Any] = {
            "name": acc_name,
            "code": acc_number or acc_name[:6].replace(" ", ""),
            "account_type": odoo_account_type,
            "company_id": odoo_company,
        }

        if dry_run:
            out.info(f"  [DRY-RUN] Would create account: {acc_number} {acc_name!r} ({odoo_account_type})")
            ctr.created += 1
            audit.append({"action": "create_dry", "name": acc_name})
            continue

        try:
            new_id = c.execute_kw("account.account", "create", [vals])
            ctr.created += 1
            existing_by_name[acc_name] = {"id": new_id, "name": acc_name, "code": acc_number}
            audit.append({"action": "create", "name": acc_name, "odoo_id": new_id})
        except Exception as exc:  # noqa: BLE001
            out.error(f"  Failed to create account {acc_name!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "name": acc_name, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step: Item Categories → product.category
# ---------------------------------------------------------------------------


def _step_categories(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching item category list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/item-category/list.do",
        params={"fields": "id,name"},
    )
    if not raw_list:
        out.info("  No item categories found in Accurate.")
        return ctr, audit

    # Build existing product.category index by name
    existing_cats = c.search_read(
        "product.category",
        domain=[],
        fields=["id", "name"],
        limit=0,
    )
    existing_by_name: dict[str, int] = {r["name"]: r["id"] for r in existing_cats}

    for rec in raw_list:
        cat_name: str = str(rec.get("name", "")).strip()
        if not cat_name:
            ctr.skipped += 1
            continue

        if cat_name in existing_by_name:
            ctr.skipped += 1
            audit.append({"action": "skip", "name": cat_name, "odoo_id": existing_by_name[cat_name]})
            continue

        # Try to get GL account info from a sample item in this category
        inv_account_id: int | None = None
        try:
            sample_items = acc_client.list_all(
                "/accurate/api/item/list.do",
                params={"fields": "id", "filter.categoryName": cat_name},
            )
            if sample_items and isinstance(sample_items[0].get("id"), int):
                sample_detail = acc_client.detail_many("/accurate/api/item/detail.do", [sample_items[0]["id"]])
                if sample_detail and not sample_detail[0].get("__error__"):
                    gl_data = sample_detail[0].get("inventoryGlAccount") or {}
                    gl_name: str = str(gl_data.get("name", "")).strip() if isinstance(gl_data, dict) else ""
                    if gl_name:
                        acct_ids = c.search(
                            "account.account",
                            [["company_id", "=", odoo_company], ["name", "ilike", gl_name]],
                            limit=1,
                        )
                        inv_account_id = acct_ids[0] if acct_ids else None
        except Exception:  # noqa: BLE001
            pass  # GL lookup is best-effort

        vals: dict[str, Any] = {
            "name": cat_name,
            "property_valuation": "real_time",
            "property_cost_method": "fifo",
        }

        if dry_run:
            out.info(f"  [DRY-RUN] Would create category: {cat_name!r}")
            ctr.created += 1
            audit.append({"action": "create_dry", "name": cat_name})
            continue

        try:
            new_id = c.execute_kw("product.category", "create", [vals])
            ctr.created += 1
            existing_by_name[cat_name] = new_id
            audit.append({"action": "create", "name": cat_name, "odoo_id": new_id})
        except Exception as exc:  # noqa: BLE001
            out.error(f"  Failed to create category {cat_name!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "name": cat_name, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step: Payment Terms → account.payment.term
# ---------------------------------------------------------------------------


def _step_payment_terms(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching payment term list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/term/list.do",
        params={"fields": "id,name,dueDays"},
    )
    if not raw_list:
        out.info("  No payment terms found in Accurate.")
        return ctr, audit

    # Build existing terms index by name
    existing_terms = c.search_read(
        "account.payment.term",
        domain=["|", ("company_id", "=", odoo_company), ("company_id", "=", False)],
        fields=["id", "name"],
        limit=0,
    )
    existing_by_name: dict[str, int] = {r["name"]: r["id"] for r in existing_terms}

    for rec in raw_list:
        term_name: str = str(rec.get("name", "")).strip()
        if not term_name:
            ctr.skipped += 1
            continue

        if term_name in existing_by_name:
            ctr.skipped += 1
            audit.append({"action": "skip", "name": term_name, "odoo_id": existing_by_name[term_name]})
            continue

        due_days = int(rec.get("dueDays", 0) or 0)

        # Build a simple "balance" line for the payment term
        line_vals: list[Any] = [
            (
                0,
                0,
                {
                    "value": "balance",
                    "days": due_days,
                    "delay_type": "days_after",
                },
            )
        ]

        vals: dict[str, Any] = {
            "name": term_name,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }

        if dry_run:
            out.info(f"  [DRY-RUN] Would create payment term: {term_name!r} (due_days={due_days})")
            ctr.created += 1
            audit.append({"action": "create_dry", "name": term_name})
            continue

        try:
            new_id = c.execute_kw("account.payment.term", "create", [vals])
            ctr.created += 1
            existing_by_name[term_name] = new_id
            audit.append({"action": "create", "name": term_name, "odoo_id": new_id})
        except Exception as exc:  # noqa: BLE001
            out.error(f"  Failed to create payment term {term_name!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "name": term_name, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step: Warehouses (log only)
# ---------------------------------------------------------------------------


def _step_warehouses(
    c: Any,
    acc_client: Any,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching warehouse list from Accurate (count only)...")
    try:
        raw_list = acc_client.list_all(
            "/accurate/api/warehouse/list.do",
            params={"fields": "id,name"},
        )
        count = len(raw_list) if raw_list else 0
    except Exception as exc:  # noqa: BLE001
        out.error(f"  Error fetching warehouses: {exc}")
        count = 0

    out.info(f"  Found {count} warehouses in Accurate. stock.warehouse creation deferred — manual mapping required.")
    ctr.skipped = count
    audit.append({"action": "log", "count": count, "note": "stock.warehouse creation deferred"})
    return ctr, audit


# ---------------------------------------------------------------------------
# Step: Taxes (log only)
# ---------------------------------------------------------------------------


def _step_taxes(
    c: Any,
    acc_client: Any,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching tax list from Accurate (count only)...")
    try:
        raw_list = acc_client.list_all(
            "/accurate/api/tax/list.do",
            params={"fields": "id,name,percentage"},
        )
        count = len(raw_list) if raw_list else 0
    except Exception as exc:  # noqa: BLE001
        out.error(f"  Error fetching taxes: {exc}")
        count = 0

    out.info(
        f"  Found {count} taxes in Accurate. Tax mapping is complex — configure manually in Odoo then rerun items."
    )
    ctr.skipped = count
    audit.append({"action": "log", "count": count, "note": "tax mapping deferred"})
    return ctr, audit


# ---------------------------------------------------------------------------
# Step: Currencies → res.currency
# ---------------------------------------------------------------------------


def _step_currencies(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching currency list from Accurate...")
    try:
        raw_list = acc_client.list_all(
            "/accurate/api/currency/list.do",
            params={"fields": "id,symbol,name,rate"},
        )
    except Exception as exc:  # noqa: BLE001
        out.error(f"  Error fetching currencies: {exc}")
        return ctr, audit

    if not raw_list:
        out.info("  No currencies found in Accurate.")
        return ctr, audit

    for rec in raw_list:
        currency_code: str = str(rec.get("symbol", "")).strip().upper()
        rate_val: float = float(rec.get("rate", 1.0) or 1.0)

        if not currency_code:
            ctr.skipped += 1
            continue

        # Find the currency in Odoo (search inactive too via context)
        currency_ids = c.search(
            "res.currency",
            [["name", "=", currency_code]],
            limit=1,
        )

        if currency_ids:
            currency_id = currency_ids[0]
            # Ensure it's active
            curr_rec = c.search_read(
                "res.currency",
                [["id", "=", currency_id]],
                fields=["id", "active"],
                limit=1,
            )
            if curr_rec and not curr_rec[0].get("active"):
                if dry_run:
                    out.info(f"  [DRY-RUN] Would activate currency: {currency_code}")
                else:
                    try:
                        c.execute_kw("res.currency", "write", [[currency_id], {"active": True}])
                        out.info(f"  Activated currency: {currency_code}")
                    except Exception as exc:  # noqa: BLE001
                        out.error(f"  Failed to activate currency {currency_code!r}: {exc}")
        else:
            # Currency not in Odoo at all — skip (Odoo has fixed currency list)
            out.info(f"  Currency {currency_code!r} not found in Odoo (not in ISO list) — skipping.")
            ctr.skipped += 1
            audit.append({"action": "skip_unknown_currency", "code": currency_code})
            continue

        # Create a currency rate if we have one
        if rate_val and rate_val != 1.0 and currency_code != "IDR":
            if dry_run:
                out.info(f"  [DRY-RUN] Would create rate for {currency_code}: {rate_val}")
                ctr.updated += 1
            else:
                try:
                    # Check if a rate already exists for today
                    from datetime import date

                    today = date.today().isoformat()
                    existing_rate = c.search(
                        "res.currency.rate",
                        [
                            ["currency_id", "=", currency_id],
                            ["name", "=", today],
                            ["company_id", "=", odoo_company],
                        ],
                        limit=1,
                    )
                    if not existing_rate:
                        c.execute_kw(
                            "res.currency.rate",
                            "create",
                            [
                                {
                                    "currency_id": currency_id,
                                    "rate": rate_val,
                                    "name": today,
                                    "company_id": odoo_company,
                                }
                            ],
                        )
                        ctr.updated += 1
                        audit.append({"action": "rate_created", "code": currency_code, "rate": rate_val})
                    else:
                        ctr.skipped += 1
                        audit.append({"action": "rate_exists", "code": currency_code})
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to create rate for {currency_code!r}: {exc}")
                    ctr.errors += 1
                    audit.append({"action": "rate_error", "code": currency_code, "error": str(exc)})
        else:
            ctr.skipped += 1
            audit.append({"action": "skip_rate", "code": currency_code, "note": "IDR or rate=1.0"})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 1: Items → product.template
# ---------------------------------------------------------------------------


def _step_items(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    # Fetch ALL items with detail fields needed for sync
    out.info("  Fetching item list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/item/list.do",
        params={"fields": "id,itemNo,name"},
    )
    if not raw_list:
        out.info("  No items found in Accurate.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} items...")
    details = acc_client.detail_many("/accurate/api/item/detail.do", acc_ids)

    # Build existing Odoo products index by default_code for the company
    existing = c.search_read(
        "product.template",
        domain=["|", ("company_id", "=", odoo_company), ("company_id", "=", False)],
        fields=["id", "default_code", "name", "type", "categ_id", "uom_id"],
        limit=0,
    )
    existing_by_code: dict[str, dict[str, Any]] = {r["default_code"]: r for r in existing if r.get("default_code")}

    # Build product.category index by name (shared/global categories)
    cats = c.search_read(
        "product.category",
        domain=[],
        fields=["id", "name"],
        limit=0,
    )
    categ_by_name: dict[str, int] = {r["name"]: r["id"] for r in cats}

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching item id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        item_no: str = str(detail.get("itemNo", "")).strip()
        item_name: str = str(detail.get("name", "")).strip()
        if not item_no or not item_name:
            ctr.skipped += 1
            continue

        item_type_raw: str = str(detail.get("itemType", "INVENTORY")).upper()
        odoo_type = _ITEM_TYPE_MAP.get(item_type_raw, "consu")

        # Category
        cat_data = detail.get("itemCategory") or {}
        cat_name: str = str(cat_data.get("name", "")).strip() if isinstance(cat_data, dict) else ""
        categ_id: int | None = categ_by_name.get(cat_name) if cat_name else None

        # UoM: CTN for inventory items, RATE for services
        uom_name = "CTN" if odoo_type == "consu" else "RATE"
        uom_id = resolve_uom_by_name(c, uom_name)

        # Tracking: lot if manageSN is True
        manage_sn: bool = bool(detail.get("manageSN", False))
        tracking = "lot" if (manage_sn and odoo_type == "consu") else "none"

        # Tax: find purchase + sale tax from Accurate tax1 field
        tax1_data = detail.get("tax1") or {}
        tax1_name: str = str(tax1_data.get("name", "")).strip() if isinstance(tax1_data, dict) else ""

        sale_tax_ids: list[int] = []
        purchase_tax_ids: list[int] = []

        if tax1_name:
            sale_taxes = c.search_read(
                "account.tax",
                domain=[
                    ["company_id", "=", odoo_company],
                    ["type_tax_use", "=", "sale"],
                    ["name", "ilike", tax1_name],
                ],
                fields=["id"],
                limit=1,
            )
            if sale_taxes:
                sale_tax_ids = [sale_taxes[0]["id"]]

            purchase_taxes = c.search_read(
                "account.tax",
                domain=[
                    ["company_id", "=", odoo_company],
                    ["type_tax_use", "=", "purchase"],
                    ["name", "ilike", tax1_name],
                ],
                fields=["id"],
                limit=1,
            )
            if purchase_taxes:
                purchase_tax_ids = [purchase_taxes[0]["id"]]

        # Build write vals
        vals: dict[str, Any] = {
            "name": item_name,
            "default_code": item_no,
            "type": odoo_type,
            "tracking": tracking,
            "purchase_method": "purchase",
            "company_id": odoo_company,
        }
        if categ_id:
            vals["categ_id"] = categ_id
        if uom_id:
            vals["uom_id"] = uom_id
            vals["uom_po_id"] = uom_id

        # Tax many2many commands
        if tax1_name:
            vals["taxes_id"] = [[6, 0, sale_tax_ids]] if sale_tax_ids else [[5, 0, 0]]
            vals["supplier_taxes_id"] = [[6, 0, purchase_tax_ids]] if purchase_tax_ids else [[5, 0, 0]]
        else:
            vals["taxes_id"] = [[5, 0, 0]]
            vals["supplier_taxes_id"] = [[5, 0, 0]]

        existing_rec = existing_by_code.get(item_no)

        if existing_rec:
            # Update
            if dry_run:
                out.info(f"  [DRY-RUN] Would update product: {item_no} {item_name!r}")
                ctr.updated += 1
            else:
                try:
                    c.execute_kw("product.template", "write", [[existing_rec["id"]], vals])
                    ctr.updated += 1
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to update product {item_no!r}: {exc}")
                    ctr.errors += 1
            audit.append({"action": "update", "item_no": item_no, "odoo_id": existing_rec["id"]})
        else:
            # Create
            if dry_run:
                out.info(f"  [DRY-RUN] Would create product: {item_no} {item_name!r}")
                ctr.created += 1
            else:
                try:
                    new_id = c.execute_kw("product.template", "create", [vals])
                    ctr.created += 1
                    audit.append({"action": "create", "item_no": item_no, "odoo_id": new_id})
                    existing_by_code[item_no] = {"id": new_id, "default_code": item_no}
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to create product {item_no!r}: {exc}")
                    ctr.errors += 1
                    audit.append({"action": "create_error", "item_no": item_no, "error": str(exc)})
                    continue
            if dry_run:
                audit.append({"action": "create_dry", "item_no": item_no})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 2: Vendors → res.partner
# ---------------------------------------------------------------------------


def _step_vendors(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching vendor list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/vendor/list.do",
        params={"fields": "id,vendorNo,name"},
    )
    if not raw_list:
        out.info("  No vendors found in Accurate.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} vendors...")
    details = acc_client.detail_many("/accurate/api/vendor/detail.do", acc_ids)

    # Build existing partner index by ref (company-scoped)
    existing = c.search_read(
        "res.partner",
        domain=["|", ("company_id", "=", odoo_company), ("company_id", "=", False), ("ref", "!=", False)],
        fields=["id", "ref"],
        limit=0,
    )
    existing_by_ref: dict[str, int] = {r["ref"]: r["id"] for r in existing if r.get("ref")}

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching vendor id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        vendor_no: str = str(detail.get("vendorNo", "")).strip()
        vendor_name: str = str(detail.get("name", "")).strip()
        if not vendor_no or not vendor_name:
            ctr.skipped += 1
            continue

        # Currency for AP account resolution
        currency_data = detail.get("currency") or {}
        currency_code: str = (
            str(currency_data.get("symbol", "IDR")).strip() if isinstance(currency_data, dict) else "IDR"
        )

        # AP account
        ap_account_id = ap_account_for_currency(c, odoo_company, currency_code)

        # AR account (default IDR)
        ar_account_id = ar_account_for_currency(c, odoo_company, "IDR")

        # Payment term
        term_data = detail.get("term") or {}
        term_name: str = str(term_data.get("name", "")).strip() if isinstance(term_data, dict) else ""
        payment_term_id: int | None = resolve_payment_term_by_name(c, term_name) if term_name else None

        # Contact fields
        email: str = str(detail.get("email", "") or "").strip()
        phone: str = str(detail.get("phone", "") or "").strip()
        street: str = str(detail.get("street", "") or "").strip()
        city: str = str(detail.get("city", "") or "").strip()

        vals: dict[str, Any] = {
            "name": vendor_name,
            "ref": vendor_no,
            "is_company": True,
            "supplier_rank": 1,
            "company_id": odoo_company,
        }
        if email:
            vals["email"] = email
        if phone:
            vals["phone"] = phone
        if street:
            vals["street"] = street
        if city:
            vals["city"] = city
        if ap_account_id:
            vals["property_account_payable_id"] = ap_account_id
        if ar_account_id:
            vals["property_account_receivable_id"] = ar_account_id
        if payment_term_id:
            vals["property_supplier_payment_term_id"] = payment_term_id

        existing_id = existing_by_ref.get(vendor_no)

        if existing_id:
            if dry_run:
                out.info(f"  [DRY-RUN] Would update vendor partner: {vendor_no} {vendor_name!r}")
                ctr.updated += 1
            else:
                try:
                    c.execute_kw("res.partner", "write", [[existing_id], vals])
                    ctr.updated += 1
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to update vendor partner {vendor_no!r}: {exc}")
                    ctr.errors += 1
            audit.append({"action": "update", "vendor_no": vendor_no, "odoo_id": existing_id})
        else:
            if dry_run:
                out.info(f"  [DRY-RUN] Would create vendor partner: {vendor_no} {vendor_name!r}")
                ctr.created += 1
            else:
                try:
                    new_id = c.execute_kw("res.partner", "create", [vals])
                    ctr.created += 1
                    audit.append({"action": "create", "vendor_no": vendor_no, "odoo_id": new_id})
                    existing_by_ref[vendor_no] = new_id
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to create vendor partner {vendor_no!r}: {exc}")
                    ctr.errors += 1
                    audit.append({"action": "create_error", "vendor_no": vendor_no, "error": str(exc)})
                    continue
            if dry_run:
                audit.append({"action": "create_dry", "vendor_no": vendor_no})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 3: Customers → res.partner
# ---------------------------------------------------------------------------


def _step_customers(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching customer list from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/customer/list.do",
        params={"fields": "id,customerNo,name"},
    )
    if not raw_list:
        out.info("  No customers found in Accurate.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} customers...")
    details = acc_client.detail_many("/accurate/api/customer/detail.do", acc_ids)

    # Build existing partner index by ref (company-scoped)
    existing = c.search_read(
        "res.partner",
        domain=["|", ("company_id", "=", odoo_company), ("company_id", "=", False), ("ref", "!=", False)],
        fields=["id", "ref"],
        limit=0,
    )
    existing_by_ref: dict[str, int] = {r["ref"]: r["id"] for r in existing if r.get("ref")}

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching customer id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        customer_no: str = str(detail.get("customerNo", "")).strip()
        customer_name: str = str(detail.get("name", "")).strip()
        if not customer_no or not customer_name:
            ctr.skipped += 1
            continue

        # AR account (default IDR)
        ar_account_id = ar_account_for_currency(c, odoo_company, "IDR")

        # Payment term
        term_data = detail.get("term") or {}
        term_name: str = str(term_data.get("name", "")).strip() if isinstance(term_data, dict) else ""
        payment_term_id: int | None = resolve_payment_term_by_name(c, term_name) if term_name else None

        # Contact fields
        email: str = str(detail.get("email", "") or "").strip()
        phone: str = str(detail.get("phone", "") or "").strip()
        street: str = str(detail.get("street", "") or "").strip()
        city: str = str(detail.get("city", "") or "").strip()

        vals: dict[str, Any] = {
            "name": customer_name,
            "ref": customer_no,
            "is_company": True,
            "customer_rank": 1,
            "company_id": odoo_company,
        }
        if email:
            vals["email"] = email
        if phone:
            vals["phone"] = phone
        if street:
            vals["street"] = street
        if city:
            vals["city"] = city
        if ar_account_id:
            vals["property_account_receivable_id"] = ar_account_id
        if payment_term_id:
            vals["property_payment_term_id"] = payment_term_id

        existing_id = existing_by_ref.get(customer_no)

        if existing_id:
            if dry_run:
                out.info(f"  [DRY-RUN] Would update customer partner: {customer_no} {customer_name!r}")
                ctr.updated += 1
            else:
                try:
                    c.execute_kw("res.partner", "write", [[existing_id], vals])
                    ctr.updated += 1
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to update customer partner {customer_no!r}: {exc}")
                    ctr.errors += 1
            audit.append({"action": "update", "customer_no": customer_no, "odoo_id": existing_id})
        else:
            if dry_run:
                out.info(f"  [DRY-RUN] Would create customer partner: {customer_no} {customer_name!r}")
                ctr.created += 1
            else:
                try:
                    new_id = c.execute_kw("res.partner", "create", [vals])
                    ctr.created += 1
                    audit.append({"action": "create", "customer_no": customer_no, "odoo_id": new_id})
                    existing_by_ref[customer_no] = new_id
                except Exception as exc:  # noqa: BLE001
                    out.error(f"  Failed to create customer partner {customer_no!r}: {exc}")
                    ctr.errors += 1
                    audit.append({"action": "create_error", "customer_no": customer_no, "error": str(exc)})
                    continue
            if dry_run:
                audit.append({"action": "create_dry", "customer_no": customer_no})

    return ctr, audit
