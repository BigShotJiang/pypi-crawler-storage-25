"""Production readiness audit command for Odoo 18.

Compares a target Odoo instance (typically a staging/local profile) against a
reference instance (e.g. an Import-trade template company) and emits a comprehensive
multi-sheet Excel workbook (18 sheets) showing what exists, what is missing
and what differs at the company-configuration level.

Without ``--reference``, falls back to existence-only checks (legacy behaviour).
"""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Annotated, Any

import typer
import yaml

from kctl_odoo.core.callbacks import AppContext

app = typer.Typer(help="Production readiness audit.")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ACCOUNT_TYPES = [
    "asset_cash",
    "asset_receivable",
    "asset_current",
    "asset_non_current",
    "asset_prepayments",
    "asset_fixed",
    "liability_payable",
    "liability_credit_card",
    "liability_current",
    "liability_non_current",
    "equity",
    "equity_unaffected",
    "income",
    "income_other",
    "expense",
    "expense_direct_cost",
    "expense_depreciation",
    "off_balance",
]

CRITICAL_ACCOUNT_TYPES = {
    "asset_cash",
    "asset_receivable",
    "liability_payable",
    "income",
    "expense_direct_cost",
    "equity",
}

REQUIRED_MODULES = ["account", "stock", "mail"]
OPTIONAL_MODULES = [
    "l10n_id",
    "accurate_integration",
    "purchase",
    "sale",
    "point_of_sale",
    "hr",
    "project",
    "report_layout",
    "report_management",
    "report_management_financial",
]
TRACKED_MODULES = REQUIRED_MODULES + OPTIONAL_MODULES

CURRENCIES = ["IDR", "USD", "CNY", "THB"]

CRITICAL_PARAMS = {
    "web.base.url",
    "mail.catchall.domain",
    "mail.bounce.alias",
    "database.uuid",
    "report.url",
    "account.use_anglo_saxon",
    "accurate.signature_secret",
}

COMPANY_FIELDS = [
    "id",
    "name",
    "currency_id",
    "account_fiscal_country_id",
    "account_sale_tax_id",
    "account_purchase_tax_id",
    "income_currency_exchange_account_id",
    "expense_currency_exchange_account_id",
    "transfer_account_id",
    "anglo_saxon_accounting",
    "fiscalyear_lock_date",
    "tax_lock_date",
    "account_journal_suspense_account_id",
    # Note: account_journal_payment_debit/credit_account_id are NOT
    # on res.company in Odoo 18 — they're chart-template refs, set
    # per-journal via account.payment.method.line. Reading the entire
    # field list as one search_read fails the WHOLE call if any field
    # is invalid, hence the careful inclusion list.
    "default_cash_difference_income_account_id",
    "default_cash_difference_expense_account_id",
    "po_lock",
    "po_double_validation",
    "po_double_validation_amount",
    "po_lead",
    "quotation_validity_days",
    "portal_confirmation_sign",
    "portal_confirmation_pay",
]


# ---------------------------------------------------------------------------
# Profile + RPC helpers
# ---------------------------------------------------------------------------


def _load_profile(profile_name: str) -> dict:
    cfg_path = Path.home() / ".config" / "kodemeio" / "config.yaml"
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path}")
    cfg = yaml.safe_load(cfg_path.read_text()) or {}
    profiles = cfg.get("profiles", {})
    p = (profiles.get(profile_name) or {}).get("odoo") or {}
    if not p:
        raise ValueError(f"Profile '{profile_name}' not found or has no 'odoo' section in {cfg_path}")
    missing = [k for k in ("url", "database", "username", "api_key") if not p.get(k)]
    if missing:
        raise ValueError(f"Profile '{profile_name}' is missing required fields: {', '.join(missing)}")
    return {
        "url": p["url"],
        "database": p["database"],
        "username": p["username"],
        "api_key": p["api_key"],
    }


class XmlRpcClient:
    """Thin xmlrpc wrapper exposing search_read/search_count/read."""

    def __init__(self, profile: dict, *, timeout: float = 600.0):
        import xmlrpc.client

        url = profile["url"].rstrip("/")
        self.url = url
        self.database = profile["database"]
        self._pw = profile["api_key"]
        # xmlrpc transport timeout is socket-level; expose for use_builtin_types
        common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common", allow_none=True, use_builtin_types=True)
        uid = common.authenticate(self.database, profile["username"], self._pw, {})
        if not uid:
            raise RuntimeError(f"Authentication failed for db={self.database} user={profile['username']}")
        self.uid = uid
        self._models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object", allow_none=True, use_builtin_types=True)

    def execute(self, model: str, method: str, *args, **kwargs):
        return self._models.execute_kw(self.database, self.uid, self._pw, model, method, list(args), kwargs)

    def search_read(
        self,
        model: str,
        domain: list | None = None,
        fields: list | None = None,
        limit: int = 0,
        order: str | None = None,
    ) -> list[dict]:
        kw: dict[str, Any] = {}
        if fields:
            kw["fields"] = fields
        if limit:
            kw["limit"] = limit
        if order:
            kw["order"] = order
        return self.execute(model, "search_read", domain or [], **kw)

    def search_count(self, model: str, domain: list | None = None) -> int:
        return self.execute(model, "search_count", domain or [])

    def read(self, model: str, ids: list[int], fields: list | None = None) -> list[dict]:
        kw: dict[str, Any] = {}
        if fields:
            kw["fields"] = fields
        return self.execute(model, "read", ids, **kw)


def _bump_timeout(actx: AppContext, seconds: float = 600.0) -> None:
    try:
        import httpx

        actx.client._client.timeout = httpx.Timeout(seconds)
    except Exception:
        pass


def _safe(value: Any, default: str = "") -> str:
    if value is False or value is None:
        return default
    if isinstance(value, list) and len(value) == 2:
        return str(value[1])
    return str(value)


def _safe_id(value: Any) -> int | None:
    if isinstance(value, list) and len(value) >= 1:
        return value[0]
    if isinstance(value, int):
        return value
    return None


def _mask(value: str) -> str:
    if not value:
        return ""
    s = str(value)
    if len(s) <= 8:
        return "****"
    return f"{s[:4]}****{s[-4:]}"


def _truncate(value: Any, length: int = 100) -> str:
    if value in (False, None):
        return ""
    s = str(value)
    return s if len(s) <= length else s[: length - 3] + "..."


# ---------------------------------------------------------------------------
# Data pulls
# ---------------------------------------------------------------------------


class _ClientShim:
    """Adapter exposing the same minimal API on AppContext.client and XmlRpcClient.

    The platform's AppContext.client implements search_read(model, domain, fields=...)
    so we just pass through. XmlRpcClient also matches.
    """

    def __init__(self, inner: Any):
        self._inner = inner

    @property
    def database(self) -> str:
        if hasattr(self._inner, "database"):
            db = self._inner.database
            return db() if callable(db) else db
        return ""

    def search_read(self, model, domain=None, fields=None, limit=0, order=None, **extra):
        kwargs: dict[str, Any] = {}
        if fields is not None:
            kwargs["fields"] = fields
        if limit:
            kwargs["limit"] = limit
        if order:
            kwargs["order"] = order
        ctx = extra.pop("context", None)
        if ctx and hasattr(self._inner, "execute_kw"):
            return self._inner.execute_kw(model, "search_read", [domain or []], {**kwargs, "context": ctx})
        kwargs.update(extra)
        return self._inner.search_read(model, domain or [], **kwargs)

    def search_count(self, model, domain=None):
        return self._inner.search_count(model, domain or [])


def _try(fn, default=None):
    try:
        return fn()
    except Exception:
        return default


# ---------------------------------------------------------------------------
# Configuration coverage: all menu items audited per company
# Tuple: (menu_path, item_label, model, scope, domain_template)
#   scope: "global" or "company"
#   domain_template: list of tuples (filled per company), e.g.
#                    [("company_id", "=", "<co_id>")] or [] for global
# ---------------------------------------------------------------------------
CONFIG_COVERAGE_ITEMS: list[tuple[str, str, str, str, list]] = [
    # --- Accounting Configuration ---
    ("Accounting", "Payment Terms", "account.payment.term", "company", []),
    ("Accounting", "Incoterms", "account.incoterms", "global", []),
    ("Accounting", "Bank Accounts (res.partner.bank)", "res.partner.bank", "company", []),
    ("Accounting", "Reconciliation Models", "account.reconcile.model", "company", []),
    ("Accounting", "Currencies", "res.currency", "global", []),
    ("Accounting", "Currency Rate Providers", "res.currency.rate.provider", "company", []),
    ("Accounting", "Account Tags", "account.account.tag", "global", []),
    ("Accounting", "Account Groups", "account.group", "company", []),
    ("Accounting", "Payment Providers", "payment.provider", "global", []),
    ("Accounting", "Payment Methods", "account.payment.method", "global", []),
    ("Accounting", "Payment Tokens", "payment.token", "company", []),
    # --- Purchase Configuration ---
    ("Purchase", "Vendor Pricelists (supplierinfo)", "product.supplierinfo", "company", []),
    ("Purchase", "Product Tags", "product.tag", "global", []),
    # --- Sales Configuration ---
    ("Sales", "Product Groups", "product.group", "global", []),
    ("Sales", "Product Attributes", "product.attribute", "global", []),
    ("Sales", "Sales Teams", "crm.team", "company", []),
    ("Sales", "Delivery Methods", "delivery.carrier", "company", []),
    ("Sales", "Sales Order Tags", "crm.tag", "global", []),
    ("Sales", "Sales Order Types", "sale.order.type", "global", []),
    ("Sales", "Combo Choices", "product.combo", "global", []),
    # --- Inventory Configuration ---
    ("Inventory", "Storage Categories", "stock.storage.category", "company", []),
    ("Inventory", "Putaway Rules", "stock.putaway.rule", "company", []),
    ("Inventory", "Docks", "stock.dock", "company", []),
    ("Inventory", "Barcode Nomenclatures", "barcode.nomenclature", "global", []),
    ("Inventory", "Cycle Count Rules", "stock.cycle.count.rule", "company", []),
    ("Inventory", "Scrap Reason Codes", "stock.scrap.reason", "global", []),
    ("Inventory", "Printer Profiles", "printer.profile", "global", []),
    ("Inventory", "Printer Rules", "printer.rule", "global", []),
    # --- Products Configuration ---
    ("Products", "Product Tags", "product.tag", "global", []),
    ("Products", "Units of Measure", "uom.uom", "global", []),
    ("Products", "UoM Categories", "uom.category", "global", []),
    # --- Report Layout ---
    ("Reports", "Report Formats", "report.format", "company", []),
    ("Reports", "Paper Formats", "report.paperformat", "global", []),
    # --- Report Management ---
    ("Reports", "Report Types", "report.type.registry", "global", []),
    ("Reports", "Report Templates", "report.template", "global", []),
    ("Reports", "Scheduled Reports", "report.schedule", "company", []),
    ("Reports", "Custom Queries", "report.custom.query", "company", []),
    ("Reports", "Report Instances", "report.instance", "company", []),
    # --- Tax (Indonesian) ---
    # Indonesian tax data — backed by `tax_management` private module models
    # (kodemeio uses tax.* prefix, not l10n_id.*). HR-only tables (PTKP /
    # TER / Progressive PPh21) are intentionally excluded from the ERP
    # readiness audit — they only fire when payroll_management is installed,
    # which lives on the separate HRMS instance.
    ("Tax (Indonesia)", "Kurs Pajak", "tax.kurs.pajak", "global", []),
    ("Tax (Indonesia)", "PPnBM Config", "tax.ppnbm.config", "global", []),
    ("Tax (Indonesia)", "PPh 23 Withholding", "pph23.withholding", "company", []),
    ("Tax (Indonesia)", "PPh 4(2) Withholding", "pph4.2.withholding", "company", []),
    ("Tax (Indonesia)", "PPh 26 Withholding", "pph26.withholding", "company", []),
    ("Tax (Indonesia)", "Bupot Non-Resident", "bupot.non.resident", "company", []),
    ("Tax (Indonesia)", "Bupot Unifikasi", "bupot.unifikasi", "company", []),
    ("Tax (Indonesia)", "Materai", "tax.materai", "global", []),
    ("Tax (Indonesia)", "Faktur Pajak Group", "faktur.pajak.group", "global", []),
    ("Tax (Indonesia)", "Tax Reconciliation", "tax.reconciliation", "company", []),
    ("Tax (Indonesia)", "Fiscal Correction", "tax.fiscal.correction", "company", []),
    ("Tax (Indonesia)", "Faktur Output", "l10n_id_efaktur.document", "company", []),
    # --- Contacts ---
    ("Contacts", "Contact Tags", "res.partner.category", "global", []),
    ("Contacts", "Contact Titles", "res.partner.title", "global", []),
    ("Contacts", "Industries", "res.partner.industry", "global", []),
    ("Contacts", "Banks (res.bank)", "res.bank", "global", []),
    ("Contacts", "Partner ID Categories", "l10n_latam.identification.type", "global", []),
    # --- System / Technical ---
    ("System", "Date Ranges", "date.range", "company", []),
    ("System", "Date Range Types", "date.range.type", "global", []),
    ("System", "Activity Types", "mail.activity.type", "global", []),
    ("System", "Email Blacklist", "mail.blacklist", "global", []),
    ("System", "Languages", "res.lang", "global", []),
    ("System", "Companies", "res.company", "global", []),
    ("System", "Cron Jobs", "ir.cron", "global", []),
    ("System", "Server Actions", "ir.actions.server", "global", []),
    ("System", "Automated Actions", "base.automation", "global", []),
    ("System", "Modules Installed", "ir.module.module", "global", [("state", "=", "installed")]),
]


def _pull_config_coverage(client: _ClientShim, company_id: int) -> list[dict]:
    """Pull counts for every CONFIG_COVERAGE_ITEMS entry, scoped per company.

    Returns list of dicts: {menu, item, model, scope, count, available, error}.
    Uses _try() to gracefully handle missing models.
    """
    rows: list[dict] = []
    seen_global: set[str] = set()
    for menu, item, model, scope, base_domain in CONFIG_COVERAGE_ITEMS:
        # Build domain
        if scope == "company":
            domain = list(base_domain) + [("company_id", "in", [company_id, False])]
        else:
            if model in seen_global:
                # Avoid duplicate global counts when called per company
                pass
            domain = list(base_domain)

        result: dict = {
            "Menu": menu,
            "Item": item,
            "Model": model,
            "Scope": scope,
            "Count": 0,
            "Available": False,
            "Error": "",
        }
        try:
            count = client.search_count(model, domain)
            result["Count"] = count if count is not None else 0
            result["Available"] = True
        except Exception as exc:
            msg = str(exc)
            # Detect "model does not exist" vs other errors
            if "does not exist" in msg.lower() or "Object" in msg and "doesn't exist" in msg:
                result["Error"] = "MODULE_NOT_INSTALLED"
            else:
                # Try without company_id constraint as fallback (model may not be company-scoped)
                if scope == "company":
                    try:
                        count = client.search_count(model, list(base_domain))
                        result["Count"] = count if count is not None else 0
                        result["Available"] = True
                        result["Scope"] = "global (fallback)"
                    except Exception as exc2:
                        result["Error"] = str(exc2)[:120]
                else:
                    result["Error"] = msg[:120]
        rows.append(result)
    return rows


def _pull_company_data(client: _ClientShim, company_id: int, company_name: str) -> dict:
    """Pull every piece of configuration we audit, scoped to one company.

    Returns a dict that both target and reference share the shape of, so the
    comparison logic can be symmetric.
    """
    data: dict[str, Any] = {
        "company_id": company_id,
        "company_name": company_name,
    }

    # Company settings
    co = _try(
        lambda: client.search_read(
            "res.company",
            [("id", "=", company_id)],
            fields=COMPANY_FIELDS + ["logo"],
            context={
                "allowed_company_ids": [company_id],
                "company_id": company_id,
                "default_company_id": company_id,
            },
        ),
        default=[],
    )
    data["company"] = co[0] if co else {}

    # Accounts: full listing for this company. Odoo 18 stores `code` as a
    # company-scoped computed field over the `code_store` JSONB; without
    # `allowed_company_ids` in context, `code` reads as False. The shim's
    # search_read forwards context kwargs through to execute_kw.
    accounts_ctx = {
        "context": {
            "allowed_company_ids": [company_id],
            "company_id": company_id,
            "default_company_id": company_id,
        }
    }
    accounts = _try(
        lambda: client.search_read(
            "account.account",
            [("company_ids", "in", company_id)],
            fields=["id", "code", "name", "account_type", "deprecated"],
            order="code",
            **accounts_ctx,
        ),
        default=[],
    )
    if not accounts or all(not a.get("code") for a in accounts):
        # Fallback path for shim variants that don't forward context: read raw
        # JSONB and pluck the per-company code.
        raw = _try(
            lambda: client.search_read(
                "account.account",
                [("company_ids", "in", company_id)],
                fields=["id", "code_store", "name", "account_type", "deprecated"],
                order="id",
            ),
            default=[],
        )
        for a in raw:
            store = a.get("code_store") or {}
            if isinstance(store, dict):
                a["code"] = store.get(str(company_id)) or store.get(company_id) or ""
            else:
                a["code"] = ""
            a.pop("code_store", None)
        accounts = raw
    data["accounts"] = accounts

    # Account ext-ids (ir.model.data) for accounts in this company
    ext_ids: dict[int, str] = {}
    if accounts:
        acc_ids = [a["id"] for a in accounts]
        # batch in chunks of 500 to avoid huge domains
        for i in range(0, len(acc_ids), 500):
            chunk = acc_ids[i : i + 500]
            rows = (
                _try(
                    lambda c=chunk: client.search_read(
                        "ir.model.data",
                        [("model", "=", "account.account"), ("res_id", "in", c)],
                        fields=["res_id", "module", "name"],
                    ),
                    default=[],
                )
                or []
            )
            for r in rows:
                ext_ids[r["res_id"]] = f"{r['module']}.{r['name']}"
    data["account_ext_ids"] = ext_ids

    # Journals (full)
    data["journals"] = _try(
        lambda: client.search_read(
            "account.journal",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "code",
                "type",
                "default_account_id",
                "suspense_account_id",
                "currency_id",
                "active",
            ],
            order="type, code",
        ),
        default=[],
    )

    # Taxes (full)
    taxes = _try(
        lambda: client.search_read(
            "account.tax",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "type_tax_use",
                "amount",
                "amount_type",
                "tax_group_id",
                "active",
            ],
            order="type_tax_use, name",
        ),
        default=[],
    )
    data["taxes"] = taxes

    # Tax repartition lines (so we can map tax -> GL accounts)
    tax_accounts: dict[int, list[str]] = {}
    if taxes:
        rep = (
            _try(
                lambda: client.search_read(
                    "account.tax.repartition.line",
                    [("company_id", "=", company_id), ("tax_id", "in", [t["id"] for t in taxes])],
                    fields=["tax_id", "account_id", "repartition_type", "factor_percent"],
                ),
                default=[],
            )
            or []
        )
        for r in rep:
            tid = _safe_id(r.get("tax_id"))
            acc = _safe(r.get("account_id"))
            if tid and acc:
                tax_accounts.setdefault(tid, []).append(acc)
    data["tax_accounts"] = tax_accounts

    # Tax groups
    data["tax_groups"] = _try(
        lambda: client.search_read(
            "account.tax.group",
            [],
            fields=[
                "id",
                "name",
                "tax_payable_account_id",
                "tax_receivable_account_id",
                "advance_tax_payment_account_id",
            ],
            order="name",
        ),
        default=[],
    )

    # Fiscal positions
    data["fiscal_positions"] = _try(
        lambda: client.search_read(
            "account.fiscal.position",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "country_id",
                "auto_apply",
                "account_ids",
                "tax_ids",
            ],
            order="name",
        ),
        default=[],
    )

    # Payment terms — global (shared across companies). Useful Indonesian set:
    # Tunai (COD), TOP 7/14/30/45/60 Hari, DP 50%/100%, Pembayaran Tunai, etc.
    data["payment_terms"] = _try(
        lambda: client.search_read(
            "account.payment.term",
            [],
            fields=["id", "name", "active", "note", "early_discount"],
            order="name",
        ),
        default=[],
    )

    # Product categories (NOT company-scoped — shared)
    data["categories"] = _try(
        lambda: client.search_read(
            "product.category",
            [],
            fields=[
                "id",
                "name",
                "property_cost_method",
                "property_valuation",
                "property_account_income_categ_id",
                "property_account_expense_categ_id",
                "property_stock_account_input_categ_id",
                "property_stock_account_output_categ_id",
                "property_stock_valuation_account_id",
                "property_stock_journal",
            ],
            order="name",
        ),
        default=[],
    )

    # Warehouses
    data["warehouses"] = _try(
        lambda: client.search_read(
            "stock.warehouse",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "code",
                "lot_stock_id",
                "reception_steps",
                "delivery_steps",
                "active",
            ],
            order="code",
        ),
        default=[],
    )

    # Operation types
    data["picking_types"] = _try(
        lambda: client.search_read(
            "stock.picking.type",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "sequence_code",
                "code",
                "warehouse_id",
                "default_location_src_id",
                "default_location_dest_id",
            ],
            order="warehouse_id, sequence_code",
        ),
        default=[],
    )

    # Stock locations
    data["locations"] = _try(
        lambda: client.search_read(
            "stock.location",
            [("company_id", "=", company_id)],
            fields=["id", "name", "complete_name", "usage", "active"],
            order="usage, complete_name",
        ),
        default=[],
    )

    # Stock summary
    data["stock_summary"] = {
        "quants": _try(lambda: client.search_count("stock.quant", [("company_id", "=", company_id)]), default=0),
        "products_with_stock": _try(
            lambda: len(
                {
                    _safe_id(q["product_id"])
                    for q in client.search_read(
                        "stock.quant",
                        [("company_id", "=", company_id), ("quantity", ">", 0)],
                        fields=["product_id"],
                        limit=20000,
                    )
                    if _safe_id(q.get("product_id"))
                }
            ),
            default=0,
        ),
        "svl_count": _try(
            lambda: client.search_count("stock.valuation.layer", [("company_id", "=", company_id)]), default=0
        ),
    }

    # Operating units
    ou_data: list = _try(
        lambda: client.search_read(
            "operating.unit",
            [("company_id", "=", company_id)],
            fields=["id", "code", "name", "partner_id", "active"],
            order="code",
        ),
        default=None,
    )
    data["operating_units"] = ou_data if ou_data is not None else "MODULE_NOT_INSTALLED"

    # User counts per OU
    ou_user_counts: dict[int, int] = {}
    if isinstance(ou_data, list) and ou_data:
        for ou in ou_data:
            cnt = _try(
                lambda oid=ou["id"]: client.search_count(
                    "res.users", [("default_operating_unit_id", "=", oid), ("active", "=", True)]
                ),
                default=0,
            )
            ou_user_counts[ou["id"]] = cnt
    data["ou_user_counts"] = ou_user_counts

    # Report formats (report_layout module). `logo` is not a field on
    # report.format in Odoo 18 — the show-logo flag is `show_logo`.
    rfmt = _try(
        lambda: client.search_read(
            "report.format",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "report_type",
                "name",
                "is_default",
                "active",
                "show_logo",
                "theme_preset",
                "band_ids",
                "signature_line_ids",
            ],
            order="report_type, name",
        ),
        default=None,
    )
    data["report_formats"] = rfmt if rfmt is not None else "MODULE_NOT_INSTALLED"

    # Report management instances (report_management_financial)
    rinst = _try(
        lambda: client.search_read(
            "report.instance",
            [("company_id", "=", company_id)],
            fields=["id", "name", "template_id", "report_type"],
            order="name",
        ),
        default=None,
    )
    data["report_instances"] = rinst if rinst is not None else "MODULE_NOT_INSTALLED"

    # Report types registry (global)
    rtypes = _try(
        lambda: client.search_read(
            "report.type.registry",
            [],
            fields=["id", "name", "code", "category", "handler_model"],
            order="category, name",
        ),
        default=None,
    )
    data["report_types"] = rtypes if rtypes is not None else "MODULE_NOT_INSTALLED"

    # Sequences (per-company) — include prefix/suffix so the audit shows the
    # actual numbering pattern (e.g. "INV/%(year)s/%(month)s/") not just padding
    data["sequences"] = _try(
        lambda: client.search_read(
            "ir.sequence",
            ["|", ("company_id", "=", company_id), ("company_id", "=", False)],
            fields=[
                "id",
                "code",
                "name",
                "prefix",
                "suffix",
                "number_next",
                "padding",
                "implementation",
                "use_date_range",
                "active",
            ],
            order="code",
        ),
        default=[],
    )

    # NOTE: ir.property was removed from Odoo 18 — company-dependent values
    # are now stored directly on company_dependent fields (JSONB columns).
    # Keeping the key so downstream code can detect the absence cleanly.
    data["properties"] = []

    # Configuration coverage — every menu item enumerated below
    data["config_coverage"] = _pull_config_coverage(client, company_id)

    # Master data quality — sample products, partners, categories, journals
    # for per-record field validation
    data["products_sample"] = _try(
        lambda: client.search_read(
            "product.template",
            [("active", "=", True)],
            fields=[
                "id",
                "name",
                "default_code",
                "barcode",
                "type",
                "categ_id",
                "uom_id",
                "uom_po_id",
                "list_price",
                "standard_price",
                "taxes_id",
                "supplier_taxes_id",
                "property_account_income_id",
                "property_account_expense_id",
                "company_id",
            ],
            limit=2000,
        ),
        default=[],
    )

    data["partners_sample"] = _try(
        lambda: client.search_read(
            "res.partner",
            ["|", ("customer_rank", ">", 0), ("supplier_rank", ">", 0)],
            fields=[
                "id",
                "name",
                "is_company",
                "customer_rank",
                "supplier_rank",
                "vat",
                "email",
                "phone",
                "mobile",
                "country_id",
                "state_id",
                "property_account_receivable_id",
                "property_account_payable_id",
                "property_payment_term_id",
                "property_supplier_payment_term_id",
                "property_account_position_id",
                "bank_ids",
                "company_id",
            ],
            limit=3000,
        ),
        default=[],
    )

    # All product categories with full property fields
    data["categories_full"] = _try(
        lambda: client.search_read(
            "product.category",
            [],
            fields=[
                "id",
                "name",
                "property_cost_method",
                "property_valuation",
                "property_account_income_categ_id",
                "property_account_expense_categ_id",
                "property_stock_account_input_categ_id",
                "property_stock_account_output_categ_id",
                "property_stock_valuation_account_id",
                "property_stock_journal",
            ],
            order="name",
        ),
        default=[],
    )

    # Bank journals — must have bank_account_id linked (real bank journals only;
    # payment-provider journals like iPaymu/Midtrans are virtual)
    data["bank_journals_detail"] = _try(
        lambda: client.search_read(
            "account.journal",
            [("company_id", "=", company_id), ("type", "in", ["bank", "cash"])],
            fields=[
                "id",
                "code",
                "name",
                "type",
                "bank_account_id",
                "default_account_id",
                "suspense_account_id",
                "currency_id",
                "inbound_payment_method_line_ids",
                "outbound_payment_method_line_ids",
            ],
        ),
        default=[],
    )

    # Payment-provider journal IDs (iPaymu, Midtrans, Xendit etc.) — these are
    # virtual bank journals tied to a payment gateway and do not need a real
    # bank_account_id, so the Bank Journal Quality check excludes them.
    data["payment_provider_journal_ids"] = set(
        _try(
            lambda: [
                p["journal_id"][0]
                for p in client.search_read(
                    "payment.provider",
                    [("journal_id", "!=", False)],
                    fields=["journal_id"],
                )
                if p.get("journal_id")
            ],
            default=[],
        )
    )

    # Report types from registry (financial reports must exist)
    data["report_types_full"] = _try(
        lambda: client.search_read(
            "report.type.registry",
            [],
            fields=["id", "name", "category", "code", "handler_model"],
            order="category, name",
        ),
        default=[],
    )

    # Report templates linked to types — `report_type` is a selection char that
    # mirrors the registry's `code`, so we can still join on that key downstream.
    data["report_templates_full"] = _try(
        lambda: client.search_read(
            "report.template",
            [],
            fields=["id", "name", "report_type", "report_type_id", "active"],
            order="name",
        ),
        default=[],
    )

    return data


def _pull_global_data(client: _ClientShim) -> dict:
    """Pull data not scoped to a single company (modules, currencies, params, mail)."""
    data: dict[str, Any] = {}

    # Modules — pull every installed module so the audit is complete, plus
    # the curated TRACKED_MODULES even when not installed (so we flag gaps).
    data["modules"] = _try(
        lambda: client.search_read(
            "ir.module.module",
            ["|", ("state", "=", "installed"), ("name", "in", TRACKED_MODULES)],
            fields=["name", "state", "installed_version", "shortdesc"],
            order="name",
        ),
        default=[],
    )

    # Currencies
    data["currencies"] = _try(
        lambda: client.search_read(
            "res.currency",
            [("name", "in", CURRENCIES)],
            fields=["name", "active", "rate", "rounding", "symbol"],
            order="name",
        ),
        default=[],
    )

    # Mail servers
    data["mail_servers"] = _try(
        lambda: client.search_read(
            "ir.mail_server",
            [],
            fields=["id", "name", "smtp_host", "smtp_port", "smtp_encryption", "active"],
            order="sequence, id",
        ),
        default=[],
    )

    # ir.config_parameter (filter to a sane size)
    params = _try(
        lambda: client.search_read(
            "ir.config_parameter",
            [],
            fields=["key", "value"],
            order="key",
            limit=2000,
        ),
        default=[],
    )
    data["config_params"] = params

    return data


# ---------------------------------------------------------------------------
# Per-company comparison/check builder
# ---------------------------------------------------------------------------


def _row(company: str, **fields: Any) -> dict:
    out = {"Company": company}
    out.update(fields)
    return out


def _check_company(target: dict, ref: dict | None, company_name: str) -> dict[str, list[dict]]:
    """Compare one target company against the reference (if provided).

    Returns dict[sheet_name -> list[row_dict]].
    """
    sheets: dict[str, list[dict]] = {
        "Company Settings": [],
        "CoA - Account Listing": [],
        "Account Types Coverage": [],
        "Journals": [],
        "Taxes": [],
        "Tax Groups": [],
        "Fiscal Positions": [],
        "Payment Terms": [],
        "Product Categories": [],
        "Warehouses + Op Types": [],
        "Stock Locations": [],
        "Operating Units": [],
        "Report Layouts": [],
        "Report Management": [],
        "Sequences": [],
        "ir.property": [],
        "Config Coverage": [],
        "Product Quality": [],
        "Partner Quality": [],
        "Category Quality": [],
        "Bank Journal Quality": [],
        "Financial Reports Setup": [],
        "Top Issues": [],
    }

    # ── Company Settings ────────────────────────────────────────────────
    co_t = target.get("company") or {}
    co_r = (ref or {}).get("company") or {}

    def cmp_setting(label: str, tval: Any, rval: Any, status: str, note: str = "") -> dict:
        return _row(
            company_name,
            Setting=label,
            Value=tval,
            **{"Reference Value": rval if ref else "(no reference)"},
            Status=status,
            Note=note,
        )

    # currency
    t = _safe(co_t.get("currency_id"), "Not set")
    r = _safe(co_r.get("currency_id"), "")
    sheets["Company Settings"].append(cmp_setting("Currency", t, r, "PASS" if t == "IDR" else "WARN"))

    # Fiscal country — only show "Should be Indonesia" hint when not yet set
    t = _safe(co_t.get("account_fiscal_country_id"), "Not set")
    r = _safe(co_r.get("account_fiscal_country_id"), "")
    is_indonesia = "Indonesia" in t
    sheets["Company Settings"].append(
        cmp_setting(
            "Fiscal Country",
            t,
            r,
            "PASS" if is_indonesia else "WARN",
            note="" if is_indonesia else "Should be Indonesia",
        )
    )

    # Default sale tax / purchase tax
    for fld, label in [
        ("account_sale_tax_id", "Default Sale Tax"),
        ("account_purchase_tax_id", "Default Purchase Tax"),
    ]:
        t = _safe(co_t.get(fld), "Not set")
        r = _safe(co_r.get(fld), "")
        sheets["Company Settings"].append(cmp_setting(label, t, r, "PASS" if co_t.get(fld) else "FAIL"))

    # FX accounts + transfer + suspense + cash diff. Outstanding receipts /
    # payments live on account.payment.method.line per journal in Odoo 18,
    # not as company defaults — verified per-journal in Bank Journal Quality.
    for fld, label, level in [
        ("income_currency_exchange_account_id", "FX Income Account", "WARN"),
        ("expense_currency_exchange_account_id", "FX Expense Account", "WARN"),
        ("transfer_account_id", "Transfer Account", "WARN"),
        ("account_journal_suspense_account_id", "Journal Suspense Account", "WARN"),
        ("default_cash_difference_income_account_id", "Cash Diff Income Account", "INFO"),
        ("default_cash_difference_expense_account_id", "Cash Diff Expense Account", "INFO"),
    ]:
        t = _safe(co_t.get(fld), "Not set")
        r = _safe(co_r.get(fld), "")
        ok = bool(co_t.get(fld))
        status = "PASS" if ok else level
        sheets["Company Settings"].append(cmp_setting(label, t, r, status))

    # Booleans + scalars
    for fld, label in [
        ("anglo_saxon_accounting", "Anglo-Saxon Accounting"),
        ("fiscalyear_lock_date", "Fiscal Year Lock"),
        ("tax_lock_date", "Tax Lock"),
        ("po_lock", "PO Lock"),
        ("po_double_validation", "PO Double Validation"),
        ("po_double_validation_amount", "PO Double Validation Amount"),
        ("po_lead", "PO Lead Time"),
        ("quotation_validity_days", "Quotation Validity (days)"),
        ("portal_confirmation_sign", "Portal Sign Confirmation"),
        ("portal_confirmation_pay", "Portal Pay Confirmation"),
    ]:
        t = co_t.get(fld)
        r = co_r.get(fld)
        sheets["Company Settings"].append(
            cmp_setting(
                label,
                "" if t in (False, None) else str(t),
                "" if r in (False, None) else str(r),
                "INFO",
            )
        )

    # Logo
    has_logo = bool(co_t.get("logo"))
    has_logo_ref = bool(co_r.get("logo"))
    sheets["Company Settings"].append(
        cmp_setting(
            "Logo",
            "Set" if has_logo else "Missing",
            "Set" if has_logo_ref else "Missing" if ref else "",
            "PASS" if has_logo else "WARN",
        )
    )

    # ── CoA - Account Listing ───────────────────────────────────────────
    accounts = target.get("accounts") or []
    ext = target.get("account_ext_ids") or {}
    for a in accounts:
        sheets["CoA - Account Listing"].append(
            _row(
                company_name,
                Code=a.get("code") or "",
                Name=a.get("name") or "",
                Type=a.get("account_type") or "",
                **{"Has Ext-ID": "Yes" if ext.get(a["id"]) else "No"},
                **{"Ext-ID": ext.get(a["id"], "")},
                Deprecated="Yes" if a.get("deprecated") else "No",
                Status="PASS" if a.get("code") else "FAIL",
                **{"Vs Reference": ""},
            )
        )

    # ── Account Types Coverage ──────────────────────────────────────────
    by_type_t: dict[str, int] = {}
    for a in accounts:
        by_type_t[a.get("account_type") or ""] = by_type_t.get(a.get("account_type") or "", 0) + 1

    by_type_r: dict[str, int] = {}
    if ref:
        for a in ref.get("accounts") or []:
            by_type_r[a.get("account_type") or ""] = by_type_r.get(a.get("account_type") or "", 0) + 1

    for at in ACCOUNT_TYPES:
        tcnt = by_type_t.get(at, 0)
        rcnt = by_type_r.get(at, 0)
        if at in CRITICAL_ACCOUNT_TYPES:
            status = "PASS" if tcnt >= 1 else "FAIL"
        elif tcnt == 0 and rcnt > 0:
            status = "WARN"
        else:
            status = "INFO"
        sheets["Account Types Coverage"].append(
            _row(
                company_name,
                **{"Account Type": at},
                **{"Target Count": tcnt},
                **{"Reference Count": rcnt if ref else "-"},
                Status=status,
                Note="Critical type" if at in CRITICAL_ACCOUNT_TYPES else "",
            )
        )

    # ── Journals ────────────────────────────────────────────────────────
    journals = target.get("journals") or []
    ref_journals = (ref or {}).get("journals") or []
    ref_codes = {j.get("code") for j in ref_journals}
    target_codes = {j.get("code") for j in journals}

    for j in journals:
        active = j.get("active")
        has_default = bool(j.get("default_account_id"))
        jtype = j.get("type") or ""
        if active and not has_default and jtype != "general":
            status = "FAIL"
            note = "Active journal missing default account"
        else:
            status = "PASS"
            note = ""
        sheets["Journals"].append(
            _row(
                company_name,
                Code=j.get("code") or "",
                Type=jtype,
                Name=j.get("name") or "",
                **{"Default Account": _safe(j.get("default_account_id"))},
                **{"Suspense Account": _safe(j.get("suspense_account_id"))},
                Currency=_safe(j.get("currency_id")),
                Active="Yes" if active else "No",
                Status=status,
                Note=note,
                **{"Vs Reference": "in reference" if j.get("code") in ref_codes else "(target only)"},
            )
        )

    # Missing journal codes (in reference but not in target)
    if ref:
        missing = ref_codes - target_codes
        for code in sorted(c or "" for c in missing if c):
            ref_j = next((j for j in ref_journals if j.get("code") == code), {})
            sheets["Journals"].append(
                _row(
                    company_name,
                    Code=code,
                    Type=ref_j.get("type") or "",
                    Name="(missing — present in reference)",
                    **{"Default Account": ""},
                    **{"Suspense Account": ""},
                    Currency="",
                    Active="No",
                    Status="WARN",
                    Note="Journal in reference but missing in target",
                    **{"Vs Reference": "reference only"},
                )
            )

    # ── Taxes ───────────────────────────────────────────────────────────
    taxes = target.get("taxes") or []
    tax_accounts = target.get("tax_accounts") or {}
    ref_taxes = (ref or {}).get("taxes") or []
    ref_tax_names = {(t.get("name"), t.get("type_tax_use")) for t in ref_taxes}

    for t in taxes:
        gl_accs = tax_accounts.get(t["id"], [])
        gl_str = ", ".join(gl_accs) if gl_accs else ""
        active = t.get("active")
        # 0%-amount taxes (PPN Bebas / Exempt / Zero-rated) have no GL impact —
        # the tax account is intentionally blank. Don't fail those.
        is_zero_rate = abs(float(t.get("amount") or 0.0)) < 1e-9
        if active and not gl_accs and not is_zero_rate:
            status = "FAIL"
            note = "Active tax missing GL account on repartition"
        elif active and not gl_accs and is_zero_rate:
            status = "PASS"
            note = "0%/exempt — no GL needed"
        else:
            status = "PASS"
            note = ""
        in_ref = (t.get("name"), t.get("type_tax_use")) in ref_tax_names
        sheets["Taxes"].append(
            _row(
                company_name,
                Name=t.get("name") or "",
                **{"Type Use": t.get("type_tax_use") or ""},
                Amount=t.get("amount"),
                **{"Amount Type": t.get("amount_type") or ""},
                **{"Tax Group": _safe(t.get("tax_group_id"))},
                **{"GL Account(s)": gl_str},
                Active="Yes" if active else "No",
                Status=status,
                Note=note,
                **{"Vs Reference": "in reference" if in_ref else "(target only)"} if ref else {"Vs Reference": ""},
            )
        )

    # ── Tax Groups ──────────────────────────────────────────────────────
    tgroups = target.get("tax_groups") or []
    used_groups = {_safe_id(t.get("tax_group_id")) for t in taxes if t.get("active")}
    for g in tgroups:
        used = g["id"] in used_groups
        has_payable = bool(g.get("tax_payable_account_id"))
        has_recv = bool(g.get("tax_receivable_account_id"))
        if used and not (has_payable and has_recv):
            status = "WARN"
            note = "Used by active taxes but missing payable/receivable account"
        else:
            status = "PASS"
            note = ""
        sheets["Tax Groups"].append(
            _row(
                company_name,
                **{"Group Name": g.get("name") or ""},
                **{"Payable Account": _safe(g.get("tax_payable_account_id"))},
                **{"Receivable Account": _safe(g.get("tax_receivable_account_id"))},
                **{"Advance Account": _safe(g.get("advance_tax_payment_account_id"))},
                **{"Used By Active Tax": "Yes" if used else "No"},
                Status=status,
                Note=note,
                **{"Vs Reference": ""},
            )
        )

    # ── Fiscal Positions ────────────────────────────────────────────────
    fps = target.get("fiscal_positions") or []
    for fp in fps:
        sheets["Fiscal Positions"].append(
            _row(
                company_name,
                Name=fp.get("name") or "",
                Country=_safe(fp.get("country_id")),
                **{"Auto Apply": "Yes" if fp.get("auto_apply") else "No"},
                **{"# Account Mappings": len(fp.get("account_ids") or [])},
                **{"# Tax Mappings": len(fp.get("tax_ids") or [])},
                Status="PASS",
                **{"Vs Reference": ""},
            )
        )
    if not fps:
        sheets["Fiscal Positions"].append(
            _row(
                company_name,
                Name="(none)",
                Country="",
                **{"Auto Apply": ""},
                **{"# Account Mappings": 0},
                **{"# Tax Mappings": 0},
                Status="WARN",
                **{"Vs Reference": ""},
            )
        )

    # ── Payment Terms ───────────────────────────────────────────────────
    pterms = target.get("payment_terms") or []
    ref_pterms = (ref or {}).get("payment_terms") or []
    ref_names = {p.get("name") for p in ref_pterms}
    for pt in pterms:
        in_ref = pt.get("name") in ref_names
        sheets["Payment Terms"].append(
            _row(
                company_name,
                **{"Term ID": pt.get("id")},
                Name=pt.get("name") or "",
                Active="Yes" if pt.get("active") else "No",
                **{"Early Discount": "Yes" if pt.get("early_discount") else "No"},
                Status="PASS" if pt.get("active") else "INFO",
                **{"Vs Reference": "in reference" if in_ref else ("(target only)" if ref else "")},
            )
        )

    # ── Product Categories ──────────────────────────────────────────────
    cats = target.get("categories") or []
    for c in cats:
        valuation = c.get("property_valuation") or ""
        has_in = bool(c.get("property_account_income_categ_id"))
        has_ex = bool(c.get("property_account_expense_categ_id"))
        has_stock = (
            bool(c.get("property_stock_account_input_categ_id"))
            and bool(c.get("property_stock_account_output_categ_id"))
            and bool(c.get("property_stock_valuation_account_id"))
        )
        if not (has_in and has_ex):
            status = "FAIL"
            note = "Missing income or expense account"
        elif valuation == "real_time" and not has_stock:
            status = "WARN"
            note = "Real-time valuation missing stock accounts"
        else:
            status = "PASS"
            note = ""
        sheets["Product Categories"].append(
            _row(
                company_name,
                Name=c.get("name") or "",
                **{"Cost Method": c.get("property_cost_method") or ""},
                Valuation=valuation,
                Income=_safe(c.get("property_account_income_categ_id")),
                Expense=_safe(c.get("property_account_expense_categ_id")),
                **{"Stock Input": _safe(c.get("property_stock_account_input_categ_id"))},
                **{"Stock Output": _safe(c.get("property_stock_account_output_categ_id"))},
                **{"Stock Valuation": _safe(c.get("property_stock_valuation_account_id"))},
                **{"Stock Journal": _safe(c.get("property_stock_journal"))},
                Status=status,
                Note=note,
            )
        )

    # ── Warehouses + Operation Types ────────────────────────────────────
    whs = target.get("warehouses") or []
    if whs:
        for w in whs:
            sheets["Warehouses + Op Types"].append(
                _row(
                    company_name,
                    Section="Warehouse",
                    Code=w.get("code") or "",
                    Name=w.get("name") or "",
                    **{"Stock Loc / Source": _safe(w.get("lot_stock_id"))},
                    **{"Reception Steps / Dest": w.get("reception_steps") or ""},
                    **{"Delivery Steps / Type": w.get("delivery_steps") or ""},
                    Active="Yes" if w.get("active") else "No",
                    Status="PASS",
                )
            )
    else:
        sheets["Warehouses + Op Types"].append(
            _row(
                company_name,
                Section="Warehouse",
                Code="",
                Name="(none)",
                **{"Stock Loc / Source": ""},
                **{"Reception Steps / Dest": ""},
                **{"Delivery Steps / Type": ""},
                Active="",
                Status="FAIL",
            )
        )

    pts = target.get("picking_types") or []
    for p in pts:
        sheets["Warehouses + Op Types"].append(
            _row(
                company_name,
                Section="Operation Type",
                Code=p.get("sequence_code") or "",
                Name=p.get("name") or "",
                **{"Stock Loc / Source": _safe(p.get("default_location_src_id"))},
                **{"Reception Steps / Dest": _safe(p.get("default_location_dest_id"))},
                **{"Delivery Steps / Type": p.get("code") or ""},
                Active="Yes",
                Status="PASS",
            )
        )

    # ── Stock Locations ─────────────────────────────────────────────────
    locs = target.get("locations") or []
    by_usage: dict[str, int] = {}
    for l in locs:
        by_usage[l.get("usage") or ""] = by_usage.get(l.get("usage") or "", 0) + 1
    for usage, count in sorted(by_usage.items()):
        sheets["Stock Locations"].append(
            _row(
                company_name,
                **{"Location Type": usage},
                Count=count,
                Note="",
                Status="PASS" if count >= 1 else "WARN",
            )
        )
    ss = target.get("stock_summary") or {}
    sheets["Stock Locations"].append(
        _row(
            company_name,
            **{"Location Type": "(summary)"},
            Count=ss.get("quants") or 0,
            Note=f"Quants={ss.get('quants', 0)}, Distinct products with qty>0={ss.get('products_with_stock', 0)}, SVL records={ss.get('svl_count', 0)}",
            Status="INFO",
        )
    )

    # ── Operating Units ─────────────────────────────────────────────────
    ous = target.get("operating_units")
    counts = target.get("ou_user_counts") or {}
    if ous == "MODULE_NOT_INSTALLED":
        sheets["Operating Units"].append(
            _row(
                company_name,
                Code="",
                **{"OU Name": "(operating_unit module not installed)"},
                Partner="",
                **{"# Users Assigned": 0},
                Active="",
                Status="WARN",
            )
        )
    elif not ous:
        sheets["Operating Units"].append(
            _row(
                company_name,
                Code="",
                **{"OU Name": "(no operating units configured)"},
                Partner="",
                **{"# Users Assigned": 0},
                Active="",
                Status="WARN",
            )
        )
    else:
        for ou in ous:
            sheets["Operating Units"].append(
                _row(
                    company_name,
                    Code=ou.get("code") or "",
                    **{"OU Name": ou.get("name") or ""},
                    Partner=_safe(ou.get("partner_id")),
                    **{"# Users Assigned": counts.get(ou["id"], 0)},
                    Active="Yes" if ou.get("active") else "No",
                    Status="PASS" if ou.get("active") else "WARN",
                )
            )

    # ── Report Layouts ──────────────────────────────────────────────────
    rfmt = target.get("report_formats")
    ref_rfmt = (ref or {}).get("report_formats") if ref else None
    if rfmt == "MODULE_NOT_INSTALLED":
        sheets["Report Layouts"].append(
            _row(
                company_name,
                **{"Report Type": "(report_layout module not installed)"},
                **{"Format Name": ""},
                **{"Is Default": ""},
                **{"# Bands": 0},
                **{"# Signature Lines": 0},
                **{"Has Logo": ""},
                **{"Theme Preset": ""},
                Status="N/A",
                Note="Module not installed",
            )
        )
    else:
        target_default_types = {f["report_type"] for f in (rfmt or []) if f.get("is_default")}
        for f in rfmt or []:
            sheets["Report Layouts"].append(
                _row(
                    company_name,
                    **{"Report Type": f.get("report_type") or ""},
                    **{"Format Name": f.get("name") or ""},
                    **{"Is Default": "Yes" if f.get("is_default") else "No"},
                    **{"# Bands": len(f.get("band_ids") or [])},
                    **{"# Signature Lines": len(f.get("signature_line_ids") or [])},
                    **{"Has Logo": "Yes" if f.get("show_logo") else "No"},
                    **{"Theme Preset": f.get("theme_preset") or ""},
                    Status="PASS" if f.get("active") else "WARN",
                    Note="",
                )
            )
        # Compare report types
        if isinstance(ref_rfmt, list):
            ref_default_types = {f["report_type"] for f in ref_rfmt if f.get("is_default")}
            missing = ref_default_types - target_default_types
            for rt in sorted(missing):
                sheets["Report Layouts"].append(
                    _row(
                        company_name,
                        **{"Report Type": rt},
                        **{"Format Name": "(missing default)"},
                        **{"Is Default": "No"},
                        **{"# Bands": 0},
                        **{"# Signature Lines": 0},
                        **{"Has Logo": ""},
                        **{"Theme Preset": ""},
                        Status="FAIL",
                        Note="Reference has a default for this type — target has none",
                    )
                )

    # ── Report Management Instances ─────────────────────────────────────
    rinst = target.get("report_instances")
    rtypes = target.get("report_types")
    if rinst == "MODULE_NOT_INSTALLED":
        sheets["Report Management"].append(
            _row(
                company_name,
                Section="Instance",
                Name="(report_management_financial not installed)",
                Template="",
                **{"Report Type / Handler": ""},
                Status="N/A",
            )
        )
    else:
        if not rinst:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Instance",
                    Name="(no instances configured)",
                    Template="",
                    **{"Report Type / Handler": ""},
                    Status="WARN",
                )
            )
        for inst in rinst or []:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Instance",
                    Name=inst.get("name") or "",
                    Template=_safe(inst.get("template_id")),
                    **{"Report Type / Handler": inst.get("report_type") or ""},
                    Status="PASS",
                )
            )
    if isinstance(rtypes, list):
        for rt in rtypes:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Registered Type",
                    Name=rt.get("name") or "",
                    Template=rt.get("category") or "",
                    **{"Report Type / Handler": rt.get("handler") or rt.get("code") or ""},
                    Status="INFO",
                )
            )

    # ── Sequences ───────────────────────────────────────────────────────
    seqs = target.get("sequences") or []
    for s in seqs:
        prefix = s.get("prefix") or ""
        suffix = s.get("suffix") or ""
        padding = s.get("padding") or 0
        # Build an example of the pattern, e.g. "INV/2026/04/00001"
        sample_seq = "0" * padding if padding else "0"
        sample = f"{prefix}{sample_seq}{suffix}"
        sheets["Sequences"].append(
            _row(
                company_name,
                Code=s.get("code") or "",
                Name=s.get("name") or "",
                Prefix=prefix,
                Suffix=suffix,
                **{"Sample Number": sample},
                **{"Number Next": s.get("number_next") or 0},
                Padding=padding,
                **{"Date Range": "Yes" if s.get("use_date_range") else "No"},
                Implementation=s.get("implementation") or "",
                Active="Yes" if s.get("active") else "No",
                Status="PASS" if s.get("active") else "WARN",
            )
        )

    # ── Company Defaults (advanced) ─────────────────────────────────────
    # ir.property was removed in Odoo 18 — company-dependent values are now
    # stored on company_dependent fields (JSONB columns). This sheet shows
    # the resolved per-company defaults that previously lived in ir.property.
    co_props = target.get("company") or {}
    co_ref = (ref or {}).get("company") or {}
    company_default_fields = [
        ("currency_id", "Currency"),
        ("account_fiscal_country_id", "Fiscal Country"),
        ("account_sale_tax_id", "Default Sale Tax"),
        ("account_purchase_tax_id", "Default Purchase Tax"),
        ("income_currency_exchange_account_id", "FX Income Account"),
        ("expense_currency_exchange_account_id", "FX Expense Account"),
        ("transfer_account_id", "Transfer Account"),
        ("account_journal_suspense_account_id", "Journal Suspense Account"),
        ("default_cash_difference_income_account_id", "Cash Difference Income"),
        ("default_cash_difference_expense_account_id", "Cash Difference Expense"),
    ]
    for fld, label in company_default_fields:
        tval = _safe(co_props.get(fld), "")
        rval = _safe(co_ref.get(fld), "")
        is_set = bool(co_props.get(fld))
        ref_set = bool(co_ref.get(fld))
        if is_set and ref_set and tval == rval:
            status = "PASS"
        elif is_set:
            status = "PASS" if tval else "WARN"
        else:
            status = "WARN" if not ref else ("FAIL" if ref_set else "INFO")
        sheets["ir.property"].append(
            _row(
                company_name,
                Field=fld,
                Label=label,
                Value=tval or "(not set)",
                **{"Reference Value": rval if ref else "-"},
                Status=status,
            )
        )

    # ── Config Coverage — compare every Configuration menu item ─────────
    target_cov = target.get("config_coverage") or []
    ref_cov_list = (ref or {}).get("config_coverage") or []
    # Index ref by (Menu, Item) for fast lookup
    ref_cov_idx = {(r["Menu"], r["Item"]): r for r in ref_cov_list}

    for tcov in target_cov:
        key = (tcov["Menu"], tcov["Item"])
        rcov = ref_cov_idx.get(key, {})
        ref_count = rcov.get("Count", 0) if rcov.get("Available") else None
        ref_avail = rcov.get("Available", False)

        # Determine status
        target_count = tcov["Count"]
        target_avail = tcov["Available"]
        status = "INFO"
        note = ""

        if not target_avail and tcov.get("Error") == "MODULE_NOT_INSTALLED":
            if ref_avail and ref_count and ref_count > 0:
                status = "FAIL"
                note = f"Module not installed in target; reference has {ref_count}"
            else:
                status = "N/A"
                note = "Module not installed in either"
        elif not target_avail:
            status = "WARN"
            note = f"Error: {tcov.get('Error', 'unknown')[:80]}"
        elif ref is None or not ref_avail:
            # No reference — pure existence
            if target_count == 0:
                status = "WARN"
                note = "0 records (no reference to compare)"
            else:
                status = "PASS"
        else:
            # Both available — compare counts
            if target_count == 0 and ref_count > 0:
                status = "FAIL"
                note = f"Target has 0; reference has {ref_count}"
            elif target_count < ref_count:
                status = "WARN"
                note = f"Target has {target_count}; reference has {ref_count} (missing {ref_count - target_count})"
            elif target_count >= ref_count:
                status = "PASS"
                note = f"Target has {target_count}; reference has {ref_count}"

        sheets["Config Coverage"].append(
            _row(
                company_name,
                Menu=tcov["Menu"],
                Item=tcov["Item"],
                Model=tcov["Model"],
                Scope=tcov["Scope"],
                **{"Target Count": target_count if target_avail else "-"},
                **{"Reference Count": ref_count if ref_avail else ("-" if ref else "(no ref)")},
                Status=status,
                Note=note,
            )
        )

    # ── Product Quality — per-product missing fields with severity ──────
    products = target.get("products_sample") or []
    for p in products:
        # Filter to this company (or company-shared)
        p_co = _safe_id(p.get("company_id"))
        if p_co and p_co != target["company_id"]:
            continue
        ptype = p.get("type") or p.get("detailed_type") or ""
        is_storable = ptype == "product"  # only "product" is stockable in Odoo 18
        is_service = ptype == "service"

        # CRITICAL issues — block business operations
        critical = []
        if not p.get("uom_id"):
            critical.append("no UoM")
        if not p.get("categ_id"):
            critical.append("no category")
        if is_storable and not p.get("standard_price"):
            critical.append("no standard_price (storable)")

        # IMPORTANT — needed for normal workflows
        important = []
        if not p.get("default_code"):
            important.append("no default_code")
        if not p.get("uom_po_id") and (p.get("uom_id") != p.get("uom_po_id")):
            # Only flag if uom_po differs and is missing
            if not p.get("uom_po_id"):
                important.append("no Purchase UoM")
        if not (p.get("taxes_id") or []) and not is_service:
            important.append("no sale tax (uses category default if any)")
        if not (p.get("supplier_taxes_id") or []) and not is_service:
            important.append("no purchase tax (uses category default if any)")

        # INFO — overrides, normal to be empty (use category defaults)
        info_issues = []
        # Only flag missing income/expense overrides if the category itself doesn't have them
        # We'll skip these as they're usually fine to leave empty
        # if not p.get("property_account_income_id"):
        #     info_issues.append("no income account override")

        all_issues = critical + important + info_issues
        # Show every product (not only ones with issues) so the catalog is
        # visible in the audit. Status reflects the worst-case severity, with
        # PASS for products that have all required fields.
        if critical:
            severity = "CRITICAL"
            status = "FAIL"
        elif important:
            severity = "IMPORTANT"
            status = "WARN"
        elif info_issues:
            severity = "INFO"
            status = "INFO"
        else:
            severity = ""
            status = "PASS"

        sheets["Product Quality"].append(
            _row(
                company_name,
                **{"Product ID": p.get("id")},
                Name=_truncate(p.get("name"), 60),
                Code=p.get("default_code") or "(none)",
                Type=ptype or "?",
                Severity=severity,
                Category=_safe(p.get("categ_id")),
                **{"Missing Fields": ", ".join(all_issues) if all_issues else "-"},
                **{"Fix": "Inventory > Products > <product> — set the missing field" if all_issues else ""},
                Status=status,
                **{"Issue Count": len(all_issues)},
            )
        )

    # ── Partner Quality — smart checks per partner type ─────────────────
    partners = target.get("partners_sample") or []
    for prt in partners:
        # Filter to this company (or company-shared)
        prt_co = _safe_id(prt.get("company_id"))
        if prt_co and prt_co != target["company_id"]:
            continue
        is_customer = (prt.get("customer_rank") or 0) > 0
        is_vendor = (prt.get("supplier_rank") or 0) > 0
        is_company = prt.get("is_company")
        # B2C heuristic: individual customers (not is_company), low rank
        is_b2c = is_customer and not is_company and not is_vendor

        # CRITICAL — blocks invoicing / payment
        critical = []
        if not prt.get("name"):
            critical.append("no name")
        if is_customer and not prt.get("property_account_receivable_id"):
            critical.append("no AR account")
        if is_vendor and not prt.get("property_account_payable_id"):
            critical.append("no AP account")

        # IMPORTANT — needed for compliance / communication
        important = []
        if not prt.get("country_id"):
            important.append("no country")
        # NPWP only mandatory for companies (B2B), not B2C individuals
        if is_company and not prt.get("vat"):
            important.append("no NPWP (company)")
        # Contact info only mandatory for vendors (we need to send POs/payments)
        if is_vendor and not prt.get("email") and not prt.get("phone") and not prt.get("mobile"):
            important.append("no contact (vendor)")
        if is_vendor and is_company and not (prt.get("bank_ids") or []):
            important.append("no bank account (company vendor)")

        # INFO — recommended but not required
        info_issues = []
        if is_company and is_customer and not prt.get("property_payment_term_id"):
            info_issues.append("no customer payment term")
        if is_company and is_vendor and not prt.get("property_supplier_payment_term_id"):
            info_issues.append("no vendor payment term")

        all_issues = critical + important + info_issues
        if not all_issues:
            continue

        # B2C with only minor issues: skip entirely (reduces noise)
        if is_b2c and not critical and not important:
            continue

        if critical:
            severity = "CRITICAL"
            status = "FAIL"
        elif important:
            severity = "IMPORTANT"
            status = "WARN"
        else:
            severity = "INFO"
            status = "INFO"

        ptype = "Customer" if is_customer and not is_vendor else ("Vendor" if is_vendor and not is_customer else "Both")
        if is_b2c:
            ptype += " (B2C)"

        sheets["Partner Quality"].append(
            _row(
                company_name,
                **{"Partner ID": prt.get("id")},
                Name=_truncate(prt.get("name"), 60),
                Type=ptype,
                Severity=severity,
                VAT=prt.get("vat") or "(none)",
                Email=prt.get("email") or "",
                **{"Missing Fields": ", ".join(all_issues)},
                **{"Fix": "Contacts > <partner> > Sales & Purchase tab — set property accounts"},
                Status=status,
                **{"Issue Count": len(all_issues)},
            )
        )

    # NOTE: Category Quality was consolidated into Product Categories above.

    # ── Bank Journal Quality — bank journals must have bank_account_id ─
    bank_journals = target.get("bank_journals_detail") or []
    payment_provider_journal_ids = target.get("payment_provider_journal_ids") or set()
    for bj in bank_journals:
        issues = []
        is_payment_gateway = bj.get("id") in payment_provider_journal_ids
        if bj.get("type") == "bank" and not bj.get("bank_account_id") and not is_payment_gateway:
            issues.append("no bank_account_id linked")
        if not bj.get("default_account_id"):
            issues.append("no default account")
        if bj.get("type") == "bank" and not bj.get("suspense_account_id") and not is_payment_gateway:
            issues.append("no suspense account")
        kind = "payment-gateway" if is_payment_gateway else bj.get("type")
        sheets["Bank Journal Quality"].append(
            _row(
                company_name,
                **{"Journal ID": bj.get("id")},
                Code=bj.get("code"),
                Name=bj.get("name"),
                Type=kind,
                **{"Bank Account": _safe(bj.get("bank_account_id"))},
                **{"Default Account": _safe(bj.get("default_account_id"))},
                **{"Suspense Account": _safe(bj.get("suspense_account_id"))},
                Currency=_safe(bj.get("currency_id")) or "(company default)",
                **{"Missing Fields": ", ".join(issues) if issues else "-"},
                Status="FAIL" if issues else "PASS",
            )
        )

    # ── Financial Reports Setup — verify each report is configured ─────
    EXPECTED_REPORTS = [
        ("profit_loss", "Profit & Loss (P&L)", "Financial Statements"),
        ("balance_sheet", "Balance Sheet", "Financial Statements"),
        ("cash_flow", "Cash Flow Statement", "Financial Statements"),
        ("trial_balance", "Trial Balance", "Financial Statements"),
        ("partner_ledger", "Partner Ledger", "Financial Statements"),
        ("open_items", "Open Items", "Financial Statements"),
        ("vat_report", "VAT Report", "Financial Statements"),
        ("receivable_aging", "AR Aging Report", "Financial Statements"),
        ("payable_aging", "AP Aging Report", "Financial Statements"),
    ]
    rtypes = target.get("report_types_full") or []
    rtemplates = target.get("report_templates_full") or []
    # The registry exposes a `code` field (e.g. "profit_loss"); templates link
    # via the `report_type` selection that mirrors that same code.
    rtypes_by_code = {(r.get("code") or ""): r for r in rtypes}
    rtemplates_by_type = {(r.get("report_type") or ""): r for r in rtemplates}

    for code, label, category in EXPECTED_REPORTS:
        rtype_rec = rtypes_by_code.get(code)
        rtmpl_rec = rtemplates_by_type.get(code)
        has_type = bool(rtype_rec)
        has_template = bool(rtmpl_rec)
        issues = []
        if not has_type:
            issues.append("no report.type.registry record")
        if not has_template:
            issues.append("no report.template")
        # Reference comparison
        ref_rtypes = (ref or {}).get("report_types_full") or []
        ref_has_type = any(r.get("code") == code for r in ref_rtypes)
        if not has_type and ref_has_type:
            ref_note = "Reference has it, target missing"
        else:
            ref_note = ""
        status = "PASS" if (has_type and has_template) else ("FAIL" if issues else "WARN")
        sheets["Financial Reports Setup"].append(
            _row(
                company_name,
                Category=category,
                Report=label,
                Code=code,
                **{"Has report.type": "Yes" if has_type else "No"},
                **{"Has report.template": "Yes" if has_template else "No"},
                **{"Type Name": _safe(rtype_rec.get("name") if rtype_rec else "")},
                **{"Template Name": _safe(rtmpl_rec.get("name") if rtmpl_rec else "")},
                Status=status,
                Note=", ".join(issues) + (f" | {ref_note}" if ref_note else ""),
            )
        )

    # ── Top Issues — aggregate all CRITICAL across sheets ───────────────
    # Sources to scan for FAIL or CRITICAL severity rows
    issue_sources = [
        ("Company Settings", "Setting"),
        ("Account Types Coverage", "Account Type"),
        ("Journals", "Code"),
        ("Taxes", "Name"),
        ("Tax Groups", "Name"),
        ("Product Categories", "Name"),
        ("Warehouses + Op Types", "Name"),
        ("Bank Journal Quality", "Code"),
        ("Financial Reports Setup", "Report"),
        ("Config Coverage", "Item"),
        ("Product Quality", "Name"),
        ("Partner Quality", "Name"),
        ("Category Quality", "Name"),
    ]
    for sheet_name, identifier_col in issue_sources:
        for r in sheets.get(sheet_name, []):
            severity = r.get("Severity", "")
            status = r.get("Status", "")
            if status == "FAIL" or severity == "CRITICAL":
                ident = r.get(identifier_col) or r.get("Item") or r.get("Name") or ""
                missing = r.get("Missing Fields") or r.get("Note") or ""
                fix = r.get("Fix") or ""
                sheets["Top Issues"].append(
                    _row(
                        company_name,
                        Severity="CRITICAL" if severity == "CRITICAL" else "FAIL",
                        Sheet=sheet_name,
                        Item=str(ident)[:60],
                        Issue=str(missing)[:200],
                        Fix=str(fix)[:200],
                        Status=status,
                    )
                )

    return sheets


# ---------------------------------------------------------------------------
# Excel writer
# ---------------------------------------------------------------------------


SHEET_ORDER = [
    "Summary",
    "Top Issues",
    "Config Coverage",
    "Financial Reports Setup",
    "Product Quality",
    "Partner Quality",
    "Category Quality",
    "Bank Journal Quality",
    "Company Settings",
    "CoA - Account Listing",
    "Account Types Coverage",
    "Journals",
    "Taxes",
    "Tax Groups",
    "Fiscal Positions",
    "Payment Terms",
    "Product Categories",
    "Warehouses + Op Types",
    "Stock Locations",
    "Operating Units",
    "Report Layouts",
    "Report Management",
    "ir.config_parameter",
    "ir.property",
    "Modules + Currencies",
    "Sequences",
]


def _write_excel(
    company_results: list[tuple[str, dict[str, list[dict]]]],
    target_global: dict,
    ref_global: dict | None,
    output: Path,
    target_label: str,
    reference_label: str | None,
) -> None:
    """Write the multi-sheet workbook."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    hdr_font = Font(bold=True, color="FFFFFF", size=11)
    hdr_fill = PatternFill("solid", fgColor="2F5496")
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    warn_fill = PatternFill("solid", fgColor="FFEB9C")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    info_fill = PatternFill("solid", fgColor="DDEBF7")
    border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9"),
    )

    def status_fill(s: str):
        return {
            "PASS": pass_fill,
            "WARN": warn_fill,
            "FAIL": fail_fill,
            "INFO": info_fill,
            "N/A": info_fill,
        }.get(s)

    def write_table(ws, headers: list[str], rows: list[dict], widths: dict[str, int] | None = None):
        # Header row
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = hdr_font
            cell.fill = hdr_fill
            cell.alignment = Alignment(horizontal="center", wrap_text=True)
            cell.border = border
        # Default widths
        for col, h in enumerate(headers, 1):
            w = (widths or {}).get(h)
            if w is None:
                if h in ("Status", "Active", "Has Ext-ID", "Is Default", "Has Logo", "Auto Apply"):
                    w = 12
                elif h in ("Code", "Type", "Type Use", "Amount", "Padding", "Number Next"):
                    w = 14
                elif h in ("Note", "Vs Reference", "Reference Value"):
                    w = 50
                elif h == "Name" or h == "Setting" or h == "Field" or h == "OU Name":
                    w = 35
                elif h == "Company":
                    w = 32
                else:
                    w = 22
            ws.column_dimensions[get_column_letter(col)].width = w

        for r_idx, row in enumerate(rows, 2):
            for c_idx, h in enumerate(headers, 1):
                val = row.get(h, "")
                cell = ws.cell(row=r_idx, column=c_idx, value=val if val != "" else None)
                cell.font = Font(size=10)
                cell.border = border
                if h == "Status":
                    fill = status_fill(str(val))
                    if fill:
                        cell.fill = fill
                    cell.font = Font(size=10, bold=True)
                    cell.alignment = Alignment(horizontal="center")

        ws.freeze_panes = "A2"
        if rows:
            ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(rows) + 1}"

    # ── Sheet 1: Summary ──────────────────────────────────────────────
    ws = wb.active
    ws.title = "Summary"
    sections = [
        "Company Settings",
        "CoA - Account Listing",
        "Account Types Coverage",
        "Journals",
        "Taxes",
        "Tax Groups",
        "Fiscal Positions",
        "Payment Terms",
        "Product Categories",
        "Warehouses + Op Types",
        "Stock Locations",
        "Operating Units",
        "Report Layouts",
    ]
    headers = ["Company"] + sections + ["Total Pass", "Total Fail", "Total Warn", "Ready?"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        cell.border = border
    ws.column_dimensions["A"].width = 35
    for col in range(2, 2 + len(sections)):
        ws.column_dimensions[get_column_letter(col)].width = 13
    ws.column_dimensions[get_column_letter(2 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(3 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(4 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(5 + len(sections))].width = 13

    row = 2
    for company_name, sheets in company_results:
        ws.cell(row=row, column=1, value=company_name).font = Font(size=10, bold=True)
        total_pass = total_fail = total_warn = 0
        for col_off, sec in enumerate(sections):
            checks = sheets.get(sec, [])
            counted = [c for c in checks if c.get("Status") in ("PASS", "WARN", "FAIL")]
            passes = sum(1 for c in counted if c["Status"] == "PASS")
            fails = sum(1 for c in counted if c["Status"] == "FAIL")
            warns = sum(1 for c in counted if c["Status"] == "WARN")
            total_pass += passes
            total_fail += fails
            total_warn += warns
            cell = ws.cell(row=row, column=2 + col_off, value=f"{passes}/{len(counted)}")
            cell.alignment = Alignment(horizontal="center")
            cell.border = border
            if fails > 0:
                cell.fill = fail_fill
            elif warns > 0:
                cell.fill = warn_fill
            elif passes > 0:
                cell.fill = pass_fill
            else:
                cell.fill = info_fill
        ws.cell(row=row, column=2 + len(sections), value=total_pass).font = Font(bold=True)
        ws.cell(row=row, column=3 + len(sections), value=total_fail).font = Font(bold=True)
        ws.cell(row=row, column=4 + len(sections), value=total_warn).font = Font(bold=True)
        ready = "READY" if total_fail == 0 else "NOT READY"
        ready_cell = ws.cell(row=row, column=5 + len(sections), value=ready)
        ready_cell.font = Font(bold=True)
        ready_cell.fill = pass_fill if total_fail == 0 else fail_fill
        ready_cell.alignment = Alignment(horizontal="center")
        for col in range(1, len(headers) + 1):
            ws.cell(row=row, column=col).border = border
        row += 1
    ws.freeze_panes = "B2"
    if company_results:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(company_results) + 1}"

    # Add header banner row at top describing target/reference
    ws_meta = wb.create_sheet("README", 0)
    wb.move_sheet("README", offset=-wb.index(ws_meta))
    ws_meta.column_dimensions["A"].width = 24
    ws_meta.column_dimensions["B"].width = 60
    meta_rows = [
        ("Generated", date.today().isoformat()),
        ("Target", target_label),
        ("Reference", reference_label or "(none — existence-only check)"),
        ("# Companies", str(len(company_results))),
        ("Sheets", ", ".join(SHEET_ORDER)),
    ]
    for r, (k, v) in enumerate(meta_rows, 1):
        c1 = ws_meta.cell(row=r, column=1, value=k)
        c1.font = Font(bold=True)
        c1.fill = hdr_fill
        c1.font = hdr_font
        ws_meta.cell(row=r, column=2, value=v).font = Font(size=10)

    # ── Detail sheets driven by per-company checks ──────────────────────
    detail_sections: list[tuple[str, list[str]]] = [
        ("Company Settings", ["Company", "Setting", "Value", "Reference Value", "Status", "Note"]),
        (
            "CoA - Account Listing",
            ["Company", "Code", "Name", "Type", "Has Ext-ID", "Ext-ID", "Deprecated", "Status", "Vs Reference"],
        ),
        (
            "Account Types Coverage",
            ["Company", "Account Type", "Target Count", "Reference Count", "Status", "Note"],
        ),
        (
            "Journals",
            [
                "Company",
                "Code",
                "Type",
                "Name",
                "Default Account",
                "Suspense Account",
                "Currency",
                "Active",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Taxes",
            [
                "Company",
                "Name",
                "Type Use",
                "Amount",
                "Amount Type",
                "Tax Group",
                "GL Account(s)",
                "Active",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Tax Groups",
            [
                "Company",
                "Group Name",
                "Payable Account",
                "Receivable Account",
                "Advance Account",
                "Used By Active Tax",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Fiscal Positions",
            [
                "Company",
                "Name",
                "Country",
                "Auto Apply",
                "# Account Mappings",
                "# Tax Mappings",
                "Status",
                "Vs Reference",
            ],
        ),
        (
            "Payment Terms",
            [
                "Company",
                "Term ID",
                "Name",
                "Active",
                "Early Discount",
                "Status",
                "Vs Reference",
            ],
        ),
        (
            "Product Categories",
            [
                "Company",
                "Name",
                "Cost Method",
                "Valuation",
                "Income",
                "Expense",
                "Stock Input",
                "Stock Output",
                "Stock Valuation",
                "Stock Journal",
                "Status",
                "Note",
            ],
        ),
        (
            "Warehouses + Op Types",
            [
                "Company",
                "Section",
                "Code",
                "Name",
                "Stock Loc / Source",
                "Reception Steps / Dest",
                "Delivery Steps / Type",
                "Active",
                "Status",
            ],
        ),
        ("Stock Locations", ["Company", "Location Type", "Count", "Note", "Status"]),
        (
            "Operating Units",
            ["Company", "Code", "OU Name", "Partner", "# Users Assigned", "Active", "Status"],
        ),
        (
            "Report Layouts",
            [
                "Company",
                "Report Type",
                "Format Name",
                "Is Default",
                "# Bands",
                "# Signature Lines",
                "Has Logo",
                "Theme Preset",
                "Status",
                "Note",
            ],
        ),
        (
            "Report Management",
            ["Company", "Section", "Name", "Template", "Report Type / Handler", "Status"],
        ),
        (
            "Sequences",
            [
                "Company",
                "Code",
                "Name",
                "Prefix",
                "Suffix",
                "Sample Number",
                "Number Next",
                "Padding",
                "Date Range",
                "Implementation",
                "Active",
                "Status",
            ],
        ),
        ("ir.property", ["Company", "Field", "Label", "Value", "Reference Value", "Status"]),
        (
            "Config Coverage",
            [
                "Company",
                "Menu",
                "Item",
                "Model",
                "Scope",
                "Target Count",
                "Reference Count",
                "Status",
                "Note",
            ],
        ),
        (
            "Financial Reports Setup",
            [
                "Company",
                "Category",
                "Report",
                "Handler",
                "Has report.type",
                "Has report.template",
                "Type Name",
                "Template Name",
                "Status",
                "Note",
            ],
        ),
        (
            "Product Quality",
            [
                "Company",
                "Product ID",
                "Name",
                "Code",
                "Type",
                "Severity",
                "Category",
                "Missing Fields",
                "Fix",
                "Status",
                "Issue Count",
            ],
        ),
        (
            "Partner Quality",
            [
                "Company",
                "Partner ID",
                "Name",
                "Type",
                "Severity",
                "VAT",
                "Email",
                "Missing Fields",
                "Fix",
                "Status",
                "Issue Count",
            ],
        ),
        (
            "Category Quality",
            [
                "Company",
                "Category ID",
                "Name",
                "Cost Method",
                "Valuation",
                "Income Account",
                "Expense Account",
                "Stock Input",
                "Stock Output",
                "Stock Valuation",
                "Stock Journal",
                "Missing Fields",
                "Status",
            ],
        ),
        (
            "Bank Journal Quality",
            [
                "Company",
                "Journal ID",
                "Code",
                "Name",
                "Type",
                "Bank Account",
                "Default Account",
                "Suspense Account",
                "Currency",
                "Missing Fields",
                "Status",
            ],
        ),
        (
            "Top Issues",
            ["Company", "Severity", "Sheet", "Item", "Issue", "Fix", "Status"],
        ),
    ]

    for title, hdrs in detail_sections:
        ws = wb.create_sheet(title)
        all_rows: list[dict] = []
        for company_name, sheets in company_results:
            all_rows.extend(sheets.get(title, []))
        write_table(ws, hdrs, all_rows)

    # ── ir.config_parameter (global) ────────────────────────────────────
    ws = wb.create_sheet("ir.config_parameter")
    headers = ["Key", "Value", "Reference Value", "Status", "Note"]
    rows: list[dict] = []
    target_params = {p["key"]: p["value"] for p in (target_global.get("config_params") or [])}
    ref_params = {p["key"]: p["value"] for p in ((ref_global or {}).get("config_params") or [])}
    all_keys = sorted(set(target_params) | set(ref_params))
    for key in all_keys:
        tval = target_params.get(key, "")
        rval = ref_params.get(key, "")
        is_critical = key in CRITICAL_PARAMS
        is_secret = any(s in key.lower() for s in ("secret", "password", "token", "api_key"))
        tdisplay = _mask(tval) if is_secret else _truncate(tval, 100)
        rdisplay = _mask(rval) if is_secret else _truncate(rval, 100)
        if is_critical and not tval:
            status = "FAIL"
            note = "Critical parameter missing"
        elif is_critical:
            status = "PASS"
            note = "Critical parameter"
        else:
            status = "INFO"
            note = ""
        rows.append(
            {
                "Key": key,
                "Value": tdisplay,
                "Reference Value": rdisplay if ref_global else "",
                "Status": status,
                "Note": note,
            }
        )
    write_table(ws, headers, rows, widths={"Key": 50, "Value": 50, "Reference Value": 50, "Note": 40})

    # ── Modules + Currencies + Mail (global) ────────────────────────────
    ws = wb.create_sheet("Modules + Currencies")
    headers = ["Section", "Item", "Target State / Active", "Reference", "Status", "Note"]
    rows = []
    target_modules = {m["name"]: m for m in (target_global.get("modules") or [])}
    ref_modules = {m["name"]: m for m in ((ref_global or {}).get("modules") or [])}
    # Render: every installed module on target, plus any tracked-but-missing
    # ones so config gaps still surface.
    all_module_names = sorted(set(target_modules.keys()) | set(TRACKED_MODULES))
    for mod in all_module_names:
        tm = target_modules.get(mod, {})
        rm = ref_modules.get(mod, {})
        tstate = tm.get("state", "not found")
        rstate = rm.get("state", "not found") if ref_global else "-"
        if mod in REQUIRED_MODULES:
            status = "PASS" if tstate == "installed" else "FAIL"
        elif mod in TRACKED_MODULES:
            if tstate == "installed":
                status = "PASS"
            elif rstate == "installed":
                status = "WARN"
            else:
                status = "INFO"
        else:
            # Installed module not on the curated tracker — mark INFO.
            status = "PASS" if tstate == "installed" else "INFO"
        note = "Required" if mod in REQUIRED_MODULES else ("Tracked" if mod in TRACKED_MODULES else "")
        rows.append(
            {
                "Section": "Module",
                "Item": mod,
                "Target State / Active": f"{tstate} ({tm.get('installed_version', '')})" if tm else tstate,
                "Reference": rstate,
                "Status": status,
                "Note": note,
            }
        )

    # Currencies
    target_curr = {c["name"]: c for c in (target_global.get("currencies") or [])}
    ref_curr = {c["name"]: c for c in ((ref_global or {}).get("currencies") or [])}
    for ccode in CURRENCIES:
        t = target_curr.get(ccode, {})
        r = ref_curr.get(ccode, {})
        active = t.get("active")
        rate = t.get("rate", "")
        rows.append(
            {
                "Section": "Currency",
                "Item": ccode,
                "Target State / Active": f"active={active}, rate={rate}",
                "Reference": f"active={r.get('active')}, rate={r.get('rate', '')}" if ref_global else "-",
                "Status": "PASS" if active else "WARN",
                "Note": "",
            }
        )

    # Mail servers
    msrvs = target_global.get("mail_servers") or []
    rmsrvs = (ref_global or {}).get("mail_servers") or []
    if msrvs:
        for s in msrvs:
            rows.append(
                {
                    "Section": "Mail Server",
                    "Item": s.get("name") or "",
                    "Target State / Active": (
                        f"{s.get('smtp_host')}:{s.get('smtp_port')} ({s.get('smtp_encryption', '-')})"
                        f" {'active' if s.get('active') else 'inactive'}"
                    ),
                    "Reference": "",
                    "Status": "PASS" if s.get("active") else "WARN",
                    "Note": "",
                }
            )
    else:
        rows.append(
            {
                "Section": "Mail Server",
                "Item": "(none configured)",
                "Target State / Active": "",
                "Reference": f"{len(rmsrvs)} server(s) in reference" if ref_global else "-",
                "Status": "WARN",
                "Note": "No outgoing mail server configured",
            }
        )
    write_table(
        ws, headers, rows, widths={"Section": 14, "Item": 32, "Target State / Active": 50, "Reference": 30, "Note": 30}
    )

    # Reorder sheets to match SHEET_ORDER (README first, then ordered)
    desired = ["README"] + SHEET_ORDER
    for idx, name in enumerate(desired):
        if name in wb.sheetnames:
            sheet = wb[name]
            current = wb.index(sheet)
            offset = idx - current
            if offset:
                wb.move_sheet(sheet, offset=offset)

    wb.save(str(output))


# ---------------------------------------------------------------------------
# Main typer command
# ---------------------------------------------------------------------------


@app.command("readiness-check")
def readiness_check(
    ctx: typer.Context,
    output: Annotated[
        Path | None,
        typer.Option("-o", "--output", help="Output Excel path (default: readiness_<db>_<date>.xlsx)"),
    ] = None,
    company_id: Annotated[
        int,
        typer.Option("--company-id", help="Limit to one company id (default: all)"),
    ] = 0,
    reference: Annotated[
        str | None,
        typer.Option("--reference", help="Reference profile name (e.g. idtpp-mac-odoo-erp)"),
    ] = None,
    reference_company_id: Annotated[
        int,
        typer.Option(
            "--reference-company-id",
            help="Reference company id to use as the gold standard (default: first company on reference)",
        ),
    ] = 0,
    include_reference: Annotated[
        bool,
        typer.Option(
            "--include-reference/--no-include-reference",
            help="Include the reference company itself in the target list — audits the gold-standard template's own completeness.",
        ),
    ] = True,
    per_company: Annotated[
        bool,
        typer.Option(
            "--per-company",
            help="Write one Excel file per company instead of a single consolidated workbook.",
        ),
    ] = False,
) -> None:
    """Generate a multi-sheet production readiness audit Excel.

    Without ``--reference``, runs existence-only checks against the target
    instance. With ``--reference``, also pulls config from a second profile
    (e.g. an Import-trade template) and compares each target company against it.
    """
    actx: AppContext = ctx.obj
    _bump_timeout(actx, seconds=600.0)
    target_inner = actx.client
    out = actx.output

    try:
        from openpyxl import Workbook  # noqa: F401
    except ImportError:
        out.error("openpyxl not installed. Run: pip install openpyxl")
        raise typer.Exit(1)

    target_client = _ClientShim(target_inner)
    target_label = f"{getattr(actx, 'profile', 'target')} ({target_client.database})"

    # Reference setup
    ref_client: _ClientShim | None = None
    reference_label: str | None = None
    if reference:
        # External reference profile (e.g., a different deployment used as gold standard)
        try:
            ref_profile = _load_profile(reference)
            xrpc = XmlRpcClient(ref_profile)
            ref_client = _ClientShim(xrpc)
            reference_label = f"{reference} ({ref_profile['database']})"
            out.info(f"Reference: {reference_label}")
        except Exception as exc:
            out.error(f"Failed to load reference profile '{reference}': {exc}")
            raise typer.Exit(1)
    elif reference_company_id:
        # Same-DB reference: use a company in the target instance as the template
        ref_client = target_client
        reference_label = f"same-DB (company id={reference_company_id})"
        out.info(f"Reference: {reference_label}")

    # Target companies
    domain = [("id", "=", company_id)] if company_id else []
    # By default the gold-standard template IS included as a target so its
    # own completeness is audited. Pass --no-include-reference to revert
    # to the previous behaviour where the reference is excluded.
    if not reference and reference_company_id and not company_id and not include_reference:
        domain = [("id", "!=", reference_company_id)]
    companies = target_client.search_read("res.company", domain, fields=["id", "name"], order="id")
    if not companies:
        out.error("No companies found on target")
        raise typer.Exit(1)
    out.info(f"Target: {target_label} ({len(companies)} company/companies)")

    # Pull reference data once (one company = the gold standard)
    ref_company_data: dict | None = None
    ref_global: dict | None = None
    if ref_client:
        ref_companies = ref_client.search_read("res.company", [], fields=["id", "name"], order="id")
        if not ref_companies:
            out.error("Reference instance has no companies")
            raise typer.Exit(1)
        chosen = None
        if reference_company_id:
            chosen = next((c for c in ref_companies if c["id"] == reference_company_id), None)
            if not chosen:
                out.error(f"Reference company id {reference_company_id} not found")
                raise typer.Exit(1)
        else:
            chosen = ref_companies[0]
        out.info(f"  Reference company: {chosen['name']} (id={chosen['id']})")
        ref_company_data = _pull_company_data(ref_client, chosen["id"], chosen["name"])
        ref_global = _pull_global_data(ref_client)

    # Pull target global once
    target_global = _pull_global_data(target_client)

    # Per-company pull + check
    company_results: list[tuple[str, dict[str, list[dict]]]] = []
    for co in companies:
        out.info(f"  Auditing {co['name']}...")
        try:
            tdata = _pull_company_data(target_client, co["id"], co["name"])
            sheets = _check_company(tdata, ref_company_data, co["name"])
            company_results.append((co["name"], sheets))
        except Exception as exc:
            out.error(f"  {co['name']}: {exc}")

    # Default output path
    if not output:
        db = target_client.database or "odoo"
        output = Path(f"readiness_{db}_{date.today().isoformat()}.xlsx")

    if per_company:
        # One Excel per company. The supplied --output path becomes a
        # directory if it exists; otherwise it is treated as a stem
        # (path/to/readiness → path/to/readiness_<slug>.xlsx).
        if output.is_dir():
            out_dir = output
            stem = "readiness"
        else:
            out_dir = output.parent if str(output.parent) else Path(".")
            stem = output.stem
        out_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []
        for company_name, sheets in company_results:
            slug = "".join(ch if ch.isalnum() else "_" for ch in company_name).strip("_")[:60] or "company"
            out_file = out_dir / f"{stem}_{slug}.xlsx"
            _write_excel(
                [(company_name, sheets)],
                target_global,
                ref_global,
                out_file,
                target_label=target_label,
                reference_label=reference_label,
            )
            written.append(out_file)
        out.info(f"\nWrote {len(written)} per-company report(s) to {out_dir}")
        for p in written:
            out.info(f"  {p}")
    else:
        _write_excel(
            company_results,
            target_global,
            ref_global,
            output,
            target_label=target_label,
            reference_label=reference_label,
        )
        out.info(f"\nReport written to {output}")

    # Console summary
    for company_name, sheets in company_results:
        all_rows = [r for rows in sheets.values() for r in rows if r.get("Status") in ("PASS", "WARN", "FAIL")]
        fails = sum(1 for r in all_rows if r["Status"] == "FAIL")
        warns = sum(1 for r in all_rows if r["Status"] == "WARN")
        passes = sum(1 for r in all_rows if r["Status"] == "PASS")
        status = "READY" if fails == 0 else "NOT READY"
        out.info(f"  {company_name}: {status}  ({passes} pass / {fails} fail / {warns} warn)")
