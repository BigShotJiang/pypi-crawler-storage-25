# linkworld CLI

Develop and deploy apps to the
[Linkworld](https://linkworld.ai) Open App Platform.

> **Status: 0.x alpha.** Phase 2 of the open-platform rollout. The CLI
> wraps a Python SDK and the platform's `/api/dev/*` endpoints.

## Install

```bash
pip install linkworld
```

## Quickstart

```bash
# 1. Get a dev session token from a Linkworld admin (M11 will replace
#    this step with GitHub OAuth device flow).
linkworld login --token <jwt>

# 2. Scaffold a new app
linkworld init my-tax-bot --github-owner my-github-username
cd my-tax-bot

# 3. Edit linkworld.app.yaml + main.py to taste
#    Run locally:
pip install -r requirements.txt
LINKWORLD_LOCAL=1 python main.py

# 4. Deploy. Either tag and let CI handle it:
git tag v0.1.0 && git push --tags

# Or push and register manually:
docker build -t ghcr.io/my-github-username/my-tax-bot:0.1.0 .
docker push ghcr.io/my-github-username/my-tax-bot:0.1.0
linkworld deploy --skip-build
```

## Commands

| | |
|---|---|
| `linkworld login --token <jwt>` | Save credentials to `~/.linkworld/config.toml` |
| `linkworld whoami` | Show the logged-in dev account |
| `linkworld logout` | Discard credentials |
| `linkworld init <slug>` | Scaffold a new app project |
| `linkworld deploy` | Build + push image, register version with platform |
| `linkworld apps list` | List your apps |
| `linkworld apps show <slug>` | App details + version history |
| `linkworld secrets ...` | Manage app-scoped secrets (coming with M7) |

## Configuration

`~/.linkworld/config.toml`:

```toml
[platform]
api_url = "https://api.linkworld.ai"

[auth]
token = "<jwt>"
```

Override via environment:

- `LINKWORLD_API_URL` — platform endpoint (default `https://api.linkworld.ai`)
- `LINKWORLD_TOKEN` — overrides the token in the config file (useful in CI)

## License

MIT.
