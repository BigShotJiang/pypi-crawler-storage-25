"""Tests for linkworld doctor — env-setup checks."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest
from click.testing import CliRunner

from linkworld_cli.cmd.doctor import doctor


# ── Fixtures ─────────────────────────────────────────────────────────


@pytest.fixture
def home_dir(tmp_path: Path, monkeypatch) -> Path:
    """Isolated $HOME so the test never reads the dev's real
    ~/.linkworld/config.toml or ~/.docker/config.json."""
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("LINKWORLD_TOKEN", raising=False)
    return tmp_path


@pytest.fixture
def login(home_dir: Path):
    """Pre-create a config.toml with a token — the format `linkworld
    login` writes."""
    cfg = home_dir / ".linkworld" / "config.toml"
    cfg.parent.mkdir(parents=True, exist_ok=True)
    cfg.write_text(
        '[platform]\napi_url = "https://api.test.local"\n'
        '[auth]\ntoken = "fake-jwt"\n'
    )
    return home_dir


# ── Tests ────────────────────────────────────────────────────────────


def test_doctor_runs_all_five_checks(login, monkeypatch, tmp_path):
    """Doctor reports a result row for every diagnostic. Adding a
    new check should be visible in this assertion so we don't ship
    an unannounced one."""
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "d1", "email": "x@y.com", "publish_allowed": True,
                "status": "active", "github_login": None, "display_name": None,
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(doctor, [])
    # The 5 checks must all appear in the table.
    for name in ("login", "docker", "ghcr", "sdk", "project"):
        assert name in result.output, f"check '{name}' missing from output"


def test_doctor_fails_when_token_rejected(login, monkeypatch, tmp_path):
    """Stale/revoked token → 401 from /api/dev/me → doctor reports
    'token rejected' with a re-login fix-hint and exits 1."""
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(401, json={"detail": "token expired"})
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )
    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(doctor, [])
    assert result.exit_code == 1
    assert "token rejected" in result.output or "401" in result.output
    # The fix-hint must surface — that's the whole point of doctor.
    assert "linkworld login" in result.output


def test_doctor_warns_when_publish_not_allowed(login, monkeypatch, tmp_path):
    """A logged-in dev with publish_allowed=false sees a warn (not a
    fail) — they CAN read, and the platform admin needs to flip the
    flag. Exit code stays 0."""
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "d1", "email": "new@dev.com", "publish_allowed": False,
                "status": "active", "github_login": None, "display_name": None,
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )
    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(doctor, [])
    # The result is "publish_allowed=false" — visible in the row
    assert "publish_allowed=false" in result.output
    assert "publish_allowed=true" in result.output  # in the hint
    # Warn-only → exit 0
    assert result.exit_code == 0


def test_doctor_fails_when_no_token(home_dir: Path, monkeypatch, tmp_path):
    """No config + no LINKWORLD_TOKEN env → doctor flags it as fail
    and tells the dev exactly what to run."""
    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(doctor, [])
    assert result.exit_code == 1
    assert "no token configured" in result.output
    assert "linkworld login" in result.output


def test_doctor_warns_when_not_in_app_dir(login, monkeypatch, tmp_path):
    """No linkworld.app.yaml in cwd → warn (not fail) — `linkworld
    doctor` is also useful from a parent dir for general diagnostics."""
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "d1", "email": "x@y.com", "publish_allowed": True,
                "status": "active", "github_login": None, "display_name": None,
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )
    monkeypatch.chdir(tmp_path)  # no linkworld.app.yaml here
    result = CliRunner().invoke(doctor, [])
    assert "no linkworld.app.yaml" in result.output
    assert "linkworld init" in result.output


def test_doctor_passes_in_app_dir(login, monkeypatch, tmp_path):
    """With a manifest in cwd, the project check should be ✓."""
    (tmp_path / "linkworld.app.yaml").write_text("apiVersion: linkworld.ai/v2\n")

    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "d1", "email": "x@y.com", "publish_allowed": True,
                "status": "active", "github_login": None, "display_name": None,
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )
    monkeypatch.chdir(tmp_path)
    result = CliRunner().invoke(doctor, [])
    assert "linkworld.app.yaml found" in result.output


# ── _check_web_bundle ────────────────────────────────────────────────


def test_bundle_check_clean_with_bridge_call_route(tmp_path, monkeypatch):
    """A bundle that uses bridge.callRoute and references --_lw-* vars
    passes lint cleanly."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    web = tmp_path / "web"
    web.mkdir()
    (web / "app.js").write_text(
        "import { LinkworldBridge } from './vendor/sdk-browser/index.js'\n"
        "const bridge = new LinkworldBridge({})\n"
        "await bridge.callRoute('GET', '/outlets')\n"
    )
    (web / "styles.css").write_text(
        "body { background: var(--_lw-bg); color: var(--_lw-text); }\n"
    )
    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "ok"
    assert "clean" in result.summary


def test_bundle_check_warns_on_fetch(tmp_path, monkeypatch):
    """fetch( is CSP-blocked."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    web = tmp_path / "web"
    web.mkdir()
    (web / "app.js").write_text(
        "async function load() {\n"
        "  const r = await fetch('/outlets')\n"
        "}\n"
    )
    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "warn"
    assert "CSP-blocked" in result.summary
    assert "bridge.callRoute" in result.hint
    assert "app.js:2" in result.hint  # line number reported


def test_bundle_check_warns_on_xhr_eventsource_websocket(tmp_path, monkeypatch):
    """XHR / SSE / WS all hit connect-src 'none'."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    web = tmp_path / "web"
    web.mkdir()
    (web / "app.js").write_text(
        "const x = new XMLHttpRequest()\n"
        "const sse = new EventSource('/stream')\n"
        "const ws = new WebSocket('wss://example.com')\n"
    )
    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "warn"
    assert "XHR" in result.hint
    assert "EventSource" in result.hint
    assert "WebSocket" in result.hint


def test_bundle_check_skips_vendor_directory(tmp_path, monkeypatch):
    """fetch() inside vendor/sdk-browser/ MUST NOT trigger the lint —
    the SDK's own monkey-patch calls original fetch() under the hood."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    web = tmp_path / "web"
    (web / "vendor" / "sdk-browser").mkdir(parents=True)
    (web / "vendor" / "sdk-browser" / "bridge.js").write_text(
        "// vendor file — uses original fetch under the hood\n"
        "window.fetch = function patched() { return originalFetch() }\n"
    )
    (web / "app.js").write_text(
        "import './vendor/sdk-browser/index.js'\n"
        "await bridge.callRoute('GET', '/x')\n"
    )
    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "ok"


def test_bundle_check_warns_on_hex_colors_without_lw_tokens(tmp_path, monkeypatch):
    """Hex literals + zero --lw-* refs = bundle ignores tenant theme."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    web = tmp_path / "web"
    web.mkdir()
    (web / "styles.css").write_text(
        "body { background: #0a0e1a; color: #e6e9f2; }\n"
        ".card { border: 1px solid #232a40; background: #131826; }\n"
        ".header { color: #6fa8ff; }\n"
    )
    (web / "app.js").write_text("// vanilla, no bridge usage\n")
    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "warn"
    assert "hardcoded colors" in result.summary


def test_bundle_check_no_web_dir(tmp_path, monkeypatch):
    """Headless app (no web/) is skipped — no warning."""
    from linkworld_cli.cmd.doctor import _check_web_bundle

    monkeypatch.chdir(tmp_path)
    result = _check_web_bundle()
    assert result.severity == "ok"
    assert "headless" in result.summary.lower()
