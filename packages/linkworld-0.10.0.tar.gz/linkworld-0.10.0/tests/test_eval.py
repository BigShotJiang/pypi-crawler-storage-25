"""End-to-end tests for ``linkworld eval``.

We stand up a minimal app on disk, write a scenario file, invoke the
CLI command via Click's CliRunner, and assert on exit code + report.
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest
from click.testing import CliRunner

from linkworld_cli.main import cli


MANIFEST_YAML = textwrap.dedent("""\
    apiVersion: linkworld.ai/v2
    app_id: test-eval-app
    version: 0.1.0
    name: Eval Test App
    runtime:
      image: ghcr.io/example/test:1
    required_scopes: [mail.send]
    lifecycle:
      on_inbound: true
      schedules:
        - name: daily
          cron: "0 8 * * *"
""")


MAIN_PY = textwrap.dedent("""\
    from linkworld_sdk import App, load_manifest

    app = App(load_manifest("linkworld.app.yaml"))


    @app.tool("classify")
    async def classify(ctx, *, text: str) -> dict:
        return {"label": "support" if "help" in text else "other"}


    @app.on_inbound
    async def on_inbound(ctx, env) -> None:
        result = await ctx.tools.call("crm_lookup", id="42")
        if result.get("ok"):
            await ctx.tools.call(
                "email_send",
                to="user@example.com",
                subject="ack",
                body=env.message_text,
            )


    @app.on_schedule("daily")
    async def daily(ctx) -> None:
        await ctx.tools.call("report_pdf_generate", date="today")
""")


@pytest.fixture
def app_dir(tmp_path: Path) -> Path:
    """Build a minimal app directory + main.py + manifest."""
    (tmp_path / "linkworld.app.yaml").write_text(MANIFEST_YAML, encoding="utf-8")
    (tmp_path / "main.py").write_text(MAIN_PY, encoding="utf-8")
    return tmp_path


def _eval_yaml(scenarios: list[dict]) -> str:
    import yaml
    return yaml.safe_dump({"scenarios": scenarios}, sort_keys=False)


def test_eval_passing_scenario(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "inbound triggers crm_lookup + email_send",
            "given": {
                "tools": {
                    "crm_lookup": {"ok": True},
                    "email_send": {"ok": True},
                },
            },
            "when": {
                "type": "inbound",
                "message_text": "I need help",
            },
            "then": {
                "tool_calls": [
                    {"name": "crm_lookup", "args_match": {"id": "42"}},
                    {"name": "email_send", "args_match": {"to": "user@example.com"}},
                ],
                "tool_calls_count": 2,
            },
        },
    ]))

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 0, result.output
    assert "1 passed" in result.output
    assert "0 failed" in result.output


def test_eval_failing_scenario_returns_1(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "wrong expectation fails loudly",
            "given": {
                "tools": {"crm_lookup": {"ok": True}, "email_send": {"ok": True}},
            },
            "when": {"type": "inbound", "message_text": "help"},
            "then": {
                "tool_calls": [
                    {"name": "definitely_not_called"},
                ],
            },
        },
    ]))

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 1, result.output
    assert "1 failed" in result.output


def test_eval_handler_blowup_reports_error(app_dir: Path) -> None:
    """If the handler raises (and spec doesn't expect it), the scenario
    fails with the error captured."""
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "missing mock surfaces as ToolCallError",
            # Intentionally no `given.tools` → the handler's call to
            # crm_lookup hits an unwired mock and raises ToolCallError.
            "when": {"type": "inbound", "message_text": "x"},
            "then": {"tool_calls_count": 0},  # never reached, but valid YAML
        },
    ]))

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 1
    assert "ToolCallError" in result.output or "no mock wired" in result.output


def test_eval_schedule_scenario(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "daily schedule fires report_pdf_generate",
            "given": {"tools": {"report_pdf_generate": {"ok": True}}},
            "when": {"type": "schedule", "schedule_name": "daily"},
            "then": {
                "tool_calls_count": 1,
                "tool_calls_include": [
                    {"name": "report_pdf_generate", "args_match": {"date": "today"}},
                ],
            },
        },
    ]))

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 0, result.output


def test_eval_tool_scenario_with_handler_returns(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "classify tool returns expected label",
            "when": {
                "type": "tool",
                "tool_name": "classify",
                "args": {"text": "I need help"},
            },
            "then": {
                "handler_returns": {"label": "support"},
                "tool_calls_count": 0,
            },
        },
    ]))
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 0, result.output


def test_eval_filter_runs_only_matching(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "good one",
            "when": {"type": "tool", "tool_name": "classify",
                     "args": {"text": "help"}},
            "then": {"handler_returns": {"label": "support"}},
        },
        {
            "name": "bad one",
            "when": {"type": "tool", "tool_name": "classify",
                     "args": {"text": "help"}},
            "then": {"handler_returns": {"label": "WRONG"}},
        },
    ]))
    runner = CliRunner()
    # Only "good one" should run → exit 0
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py"),
         "--filter", "good"],
    )
    assert result.exit_code == 0, result.output


def test_eval_writes_junit(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "tool-only happy path",
            "when": {"type": "tool", "tool_name": "classify",
                     "args": {"text": "help"}},
            "then": {"handler_returns": {"label": "support"}},
        },
    ]))
    junit_out = app_dir / "junit.xml"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py"),
         "--junit", str(junit_out)],
    )
    assert result.exit_code == 0, result.output
    assert junit_out.is_file()
    body = junit_out.read_text(encoding="utf-8")
    assert "<testsuite" in body and "tool-only happy path" in body
    assert 'tests="1"' in body and 'failures="0"' in body


def test_eval_writes_json(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {
            "name": "json report check",
            "when": {"type": "tool", "tool_name": "classify",
                     "args": {"text": "help"}},
            "then": {"handler_returns": {"label": "support"}},
        },
    ]))
    json_out = app_dir / "report.json"
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "main.py"),
         "--json", str(json_out)],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(json_out.read_text(encoding="utf-8"))
    assert payload["summary"] == {"total": 1, "passed": 1, "failed": 0}
    assert payload["scenarios"][0]["ok"] is True


def test_eval_missing_main_returns_2(app_dir: Path) -> None:
    eval_path = app_dir / "linkworld.eval.yaml"
    eval_path.write_text(_eval_yaml([
        {"name": "x", "when": {"type": "tool", "tool_name": "classify",
                                "args": {"text": "x"}},
         "then": {}},
    ]))
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(eval_path), "--main", str(app_dir / "does_not_exist.py")],
    )
    assert result.exit_code == 2


def test_eval_missing_eval_file_returns_2(app_dir: Path) -> None:
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["eval", str(app_dir / "absent.yaml"), "--main", str(app_dir / "main.py")],
    )
    assert result.exit_code == 2
