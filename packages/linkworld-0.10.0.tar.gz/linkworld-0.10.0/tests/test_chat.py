"""Tests for ``linkworld chat`` — focus on the dispatch core (no HTTP).

End-to-end HTTP exercise via http.client kept minimal because the
server uses ThreadingHTTPServer + asyncio.run inside each request,
which is real enough that a single round-trip test gives confidence
without flakiness.
"""

from __future__ import annotations

import asyncio
import http.client
import json
import textwrap
import threading
import time
from pathlib import Path

import pytest

from linkworld_cli.cmd.chat import (
    _ChatHandler,
    _dispatch_message,
    _render_chat_html,
)
from linkworld_cli.cmd.eval import _load_app


MANIFEST_YAML = textwrap.dedent("""\
    apiVersion: linkworld.ai/v2
    app_id: chat-test-app
    version: 0.1.0
    name: Chat Test App
    runtime:
      image: ghcr.io/example/test:1
    required_scopes: [mail.send]
    lifecycle:
      on_inbound: true
""")

MAIN_WITH_AGENT = textwrap.dedent("""\
    from linkworld_sdk import App, load_manifest

    app = App(load_manifest("linkworld.app.yaml"))


    @app.on_inbound
    async def on_inbound(ctx, env) -> None:
        # Look up customer, then ask the agent for a reply
        await ctx.tools.call("crm_lookup", id="42")
        await ctx.agent.ask(f"reply to: {env.message_text}", agent="replier")
""")

MAIN_NO_INBOUND = textwrap.dedent("""\
    from linkworld_sdk import App, load_manifest

    app = App(load_manifest("linkworld.app.yaml"))
""")


@pytest.fixture
def app_dir(tmp_path: Path) -> Path:
    (tmp_path / "linkworld.app.yaml").write_text(MANIFEST_YAML, encoding="utf-8")
    (tmp_path / "main.py").write_text(MAIN_WITH_AGENT, encoding="utf-8")
    (tmp_path / "linkworld.dev.json").write_text(json.dumps({
        "crm_lookup": {"ok": True, "result": {"customer": "Acme"}},
        "_agents": {
            "replier": {"text": "Hi! Got your message."},
        },
    }), encoding="utf-8")
    return tmp_path


def test_dispatch_happy_path(app_dir: Path) -> None:
    app = _load_app(app_dir / "main.py")
    result = asyncio.run(_dispatch_message(
        app, "Hello", app_dir / "linkworld.dev.json", live=False,
    ))
    assert result["ok"] is True, result
    assert result["response"] == "Hi! Got your message."
    # Trace should include tool_call + tool_response + agent_call + agent_response
    kinds = [ev["kind"] for ev in result["trace"]]
    assert "tool_call" in kinds
    assert "tool_response" in kinds
    assert "agent_call" in kinds
    assert "agent_response" in kinds


def test_dispatch_missing_mock_surfaces_error(tmp_path: Path) -> None:
    (tmp_path / "linkworld.app.yaml").write_text(MANIFEST_YAML, encoding="utf-8")
    (tmp_path / "main.py").write_text(MAIN_WITH_AGENT, encoding="utf-8")
    (tmp_path / "linkworld.dev.json").write_text("{}", encoding="utf-8")

    app = _load_app(tmp_path / "main.py")
    result = asyncio.run(_dispatch_message(
        app, "Hello", tmp_path / "linkworld.dev.json", live=False,
    ))
    assert result["ok"] is False
    assert result["error"]["type"] == "ToolCallError"
    assert "crm_lookup" in result["error"]["tool"]
    # Trace records the call + the error
    kinds = [ev["kind"] for ev in result["trace"]]
    assert "tool_call" in kinds
    assert "error" in kinds


def test_dispatch_no_inbound_handler(tmp_path: Path) -> None:
    (tmp_path / "linkworld.app.yaml").write_text(MANIFEST_YAML, encoding="utf-8")
    (tmp_path / "main.py").write_text(MAIN_NO_INBOUND, encoding="utf-8")

    app = _load_app(tmp_path / "main.py")
    result = asyncio.run(_dispatch_message(
        app, "x", tmp_path / "linkworld.dev.json", live=False,
    ))
    assert result["ok"] is False
    assert "no @app.on_inbound" in result["error"]


def test_render_chat_html_embeds_app_id(app_dir: Path) -> None:
    app = _load_app(app_dir / "main.py")
    html = _render_chat_html(app, live=False)
    assert "chat-test-app" in html
    assert "linkworld chat" in html
    assert "/api/chat" in html
    # Mode pill reflects mock vs live
    assert "mock" in html


def test_render_chat_html_live_mode(app_dir: Path) -> None:
    app = _load_app(app_dir / "main.py")
    html = _render_chat_html(app, live=True)
    assert "live (Anthropic)" in html


def test_http_round_trip(app_dir: Path) -> None:
    """End-to-end: bind the server, POST a chat message, assert response."""
    from http.server import ThreadingHTTPServer

    app = _load_app(app_dir / "main.py")

    class H(_ChatHandler):
        pass
    H.app = app
    H.mock_path = app_dir / "linkworld.dev.json"
    H.live = False

    # Bind on an ephemeral port.
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        # Health check
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("GET", "/api/health")
        resp = conn.getresponse()
        assert resp.status == 200
        assert json.loads(resp.read())["ok"] is True
        conn.close()

        # GET / returns the HTML shell
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("GET", "/")
        resp = conn.getresponse()
        assert resp.status == 200
        body = resp.read().decode("utf-8")
        assert "linkworld chat" in body
        conn.close()

        # POST /api/chat dispatches a message
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
        conn.request(
            "POST", "/api/chat",
            body=json.dumps({"text": "Hello playground"}),
            headers={"Content-Type": "application/json"},
        )
        resp = conn.getresponse()
        assert resp.status == 200
        data = json.loads(resp.read())
        assert data["ok"] is True
        assert data["response"] == "Hi! Got your message."
        assert any(ev["kind"] == "tool_call" for ev in data["trace"])
        conn.close()

        # POST with empty body returns 400
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("POST", "/api/chat", body="{}",
                     headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        assert resp.status == 400
        conn.close()
    finally:
        srv.shutdown()
        srv.server_close()


def test_dispatch_team_call_gets_clear_playground_error(tmp_path: Path) -> None:
    """Handlers that call ctx.team.delegate / ctx.apps.invoke / etc.
    should get a ToolCallError with a clear message instead of an
    AttributeError on None."""
    main_py = textwrap.dedent("""\
        from linkworld_sdk import App, load_manifest

        app = App(load_manifest("linkworld.app.yaml"))


        @app.on_inbound
        async def on_inbound(ctx, env) -> None:
            await ctx.team.delegate("researcher", "lookup", from_agent="cmo")
    """)
    (tmp_path / "linkworld.app.yaml").write_text(MANIFEST_YAML, encoding="utf-8")
    (tmp_path / "main.py").write_text(main_py, encoding="utf-8")
    (tmp_path / "linkworld.dev.json").write_text("{}", encoding="utf-8")

    app = _load_app(tmp_path / "main.py")
    result = asyncio.run(_dispatch_message(
        app, "x", tmp_path / "linkworld.dev.json", live=False,
    ))
    assert result["ok"] is False
    assert result["error"]["type"] == "ToolCallError"
    assert "playground" in result["error"]["message"].lower()


def test_dispatch_loads_mocks_each_call(app_dir: Path) -> None:
    """Edits to linkworld.dev.json take effect on the next message
    without restarting the playground."""
    app = _load_app(app_dir / "main.py")
    mock_path = app_dir / "linkworld.dev.json"

    r1 = asyncio.run(_dispatch_message(app, "x", mock_path, live=False))
    assert r1["response"] == "Hi! Got your message."

    # Update the mock
    mock_path.write_text(json.dumps({
        "crm_lookup": {"ok": True, "result": {"customer": "Acme"}},
        "_agents": {"replier": {"text": "Updated response."}},
    }), encoding="utf-8")

    r2 = asyncio.run(_dispatch_message(app, "x", mock_path, live=False))
    assert r2["response"] == "Updated response."
