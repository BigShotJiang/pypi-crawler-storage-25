"""Tests for linkworld init."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from linkworld_cli.cmd.init import init


def test_init_creates_full_scaffold(tmp_path: Path):
    runner = CliRunner()
    result = runner.invoke(
        init,
        ["my-bot", "--directory", str(tmp_path / "my-bot"),
         "--github-owner", "alice", "--description", "Sample"],
    )
    assert result.exit_code == 0, result.output

    target = tmp_path / "my-bot"
    assert (target / "linkworld.app.yaml").exists()
    assert (target / "main.py").exists()
    assert (target / "Dockerfile").exists()
    assert (target / "requirements.txt").exists()
    assert (target / "README.md").exists()
    assert (target / "AGENTS.md").exists(), \
        "AGENTS.md missing — Phase C primer for IDE LLMs"
    assert (target / "linkworld.eval.yaml").exists(), \
        "eval suite missing — fresh scaffold should pass `linkworld eval`"
    assert (target / ".github" / "workflows" / "deploy.yml").exists()

    # SDK pin must match a published PyPI version. >=0.1 lets pip
    # install a non-existent older release; the scaffold must depend
    # on something a fresh dev can actually pip-install.
    reqs = (target / "requirements.txt").read_text()
    assert "linkworld-sdk" in reqs
    assert ">=1.1" in reqs, \
        f"requirements.txt SDK pin is stale; expected >=1.1: {reqs!r}"


def test_init_agents_md_has_substituted_slug_and_description(tmp_path: Path):
    """AGENTS.md is the cold-start primer for Cursor / Claude Code /
    Codex. Drift in the template is caught here — if the slug or
    description doesn't make it in, the IDE LLM sees a generic
    placeholder primer and the value of Phase C evaporates."""
    runner = CliRunner()
    runner.invoke(
        init,
        ["news-bot", "--directory", str(tmp_path / "news-bot"),
         "--description", "Posts daily KPI"],
    )
    agents_path = tmp_path / "news-bot" / "AGENTS.md"
    text = agents_path.read_text()
    assert "news-bot" in text
    assert "Posts daily KPI" in text
    # No leftover placeholders
    assert "{{" not in text
    # Discovery hooks present so the IDE LLM knows what to ask MCP for
    assert "list_skills" in text
    assert "get_skill_docs" in text
    assert "validate_manifest" in text


def test_init_typescript_lang_emits_agents_md(tmp_path: Path):
    runner = CliRunner()
    result = runner.invoke(
        init,
        ["ts-bot", "--lang", "typescript",
         "--directory", str(tmp_path / "ts-bot"),
         "--description", "TS-flavored bot"],
    )
    assert result.exit_code == 0, result.output
    agents_path = tmp_path / "ts-bot" / "AGENTS.md"
    assert agents_path.exists()
    text = agents_path.read_text()
    assert "ts-bot" in text
    # The TS variant should mention `fetch` (the JS analog of requests),
    # not `requests.get`. Otherwise we lose the DON'T-bypass-the-bridge
    # warning's signal for TS devs.
    assert "fetch" in text


def test_init_substitutes_template_vars(tmp_path: Path):
    runner = CliRunner()
    runner.invoke(
        init,
        ["my-bot", "--directory", str(tmp_path / "my-bot"),
         "--github-owner", "alice"],
    )
    yaml_text = (tmp_path / "my-bot" / "linkworld.app.yaml").read_text()
    assert "app_id: my-bot" in yaml_text
    assert "ghcr.io/alice/my-bot" in yaml_text
    # No template placeholders left over
    assert "{{" not in yaml_text


def test_init_scaffold_loads_via_sdk(tmp_path: Path):
    """The scaffolded manifest must validate via the SDK loader. If
    the template drifts (or invalid example values creep in) this
    test catches it before partners hit it."""
    runner = CliRunner()
    runner.invoke(
        init,
        ["my-bot", "--directory", str(tmp_path / "my-bot"),
         "--github-owner", "alice"],
    )
    from linkworld_sdk import load_manifest
    m = load_manifest(tmp_path / "my-bot" / "linkworld.app.yaml")
    assert m.app_id == "my-bot"
    assert m.lifecycle.on_inbound is True


def test_init_rejects_invalid_slug(tmp_path: Path):
    runner = CliRunner()
    # Slugs starting with `-` would be parsed as options by Click before
    # reaching our validator — test those via stdin or --slug=…  pattern
    # is overkill here, just test the cases our validator owns.
    for bad_slug in ("ab", "Bad-Bot", "bot-", "with_underscore", "1-bot"):
        result = runner.invoke(
            init,
            [bad_slug, "--directory", str(tmp_path / "x")],
        )
        assert result.exit_code == 1, (
            f"slug '{bad_slug}' should be rejected, got exit {result.exit_code}: "
            f"{result.output}"
        )


def test_init_refuses_existing_directory(tmp_path: Path):
    target = tmp_path / "existing"
    target.mkdir()
    runner = CliRunner()
    result = runner.invoke(
        init, ["existing", "--directory", str(target)],
    )
    assert result.exit_code == 1
    assert "already exists" in result.output


def test_init_default_directory_is_slug(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(init, ["sluggy"])
    assert result.exit_code == 0, result.output
    assert (tmp_path / "sluggy" / "main.py").exists()
