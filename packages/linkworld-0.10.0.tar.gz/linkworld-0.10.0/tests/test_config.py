"""Tests for ~/.linkworld/config.toml load/save round-trip."""

from __future__ import annotations

from pathlib import Path

import pytest

from linkworld_cli.config import CliConfig, config_path


@pytest.fixture
def home_dir(tmp_path: Path, monkeypatch):
    """Redirect Path.home() to a tmp dir so tests don't touch real config."""
    monkeypatch.setenv("HOME", str(tmp_path))
    return tmp_path


def test_save_then_load_roundtrip(home_dir: Path, monkeypatch):
    # Make sure env doesn't shadow the file token
    monkeypatch.delenv("LINKWORLD_TOKEN", raising=False)
    monkeypatch.delenv("LINKWORLD_API_URL", raising=False)
    cfg = CliConfig(api_url="https://test.example", token="abc.def.ghi")
    cfg.save()

    loaded = CliConfig.load()
    assert loaded.api_url == "https://test.example"
    assert loaded.token == "abc.def.ghi"


def test_config_path_creates_dir(home_dir: Path):
    p = config_path()
    assert p.parent.exists()
    assert p.parent.name == ".linkworld"


def test_load_no_file_returns_defaults(home_dir: Path, monkeypatch):
    monkeypatch.delenv("LINKWORLD_TOKEN", raising=False)
    cfg = CliConfig.load()
    assert cfg.token is None


def test_env_token_overrides_file(home_dir: Path, monkeypatch):
    CliConfig(api_url="https://x", token="from-file").save()
    monkeypatch.setenv("LINKWORLD_TOKEN", "from-env")
    loaded = CliConfig.load()
    assert loaded.token == "from-env"


def test_logout_clears_token(home_dir: Path, monkeypatch):
    monkeypatch.delenv("LINKWORLD_TOKEN", raising=False)
    CliConfig(api_url="https://x", token="t").save()
    cfg = CliConfig.load()
    cfg.token = None
    cfg.save()
    loaded = CliConfig.load()
    assert loaded.token is None


def test_save_chmod_600(home_dir: Path):
    cfg = CliConfig(token="secret-jwt")
    p = cfg.save()
    mode = p.stat().st_mode & 0o777
    assert mode == 0o600, f"config should be user-only, got {oct(mode)}"
