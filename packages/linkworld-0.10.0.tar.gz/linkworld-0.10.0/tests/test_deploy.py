"""Tests for `linkworld deploy` — the most-used partner command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest
from click.testing import CliRunner

from linkworld_cli.cmd.deploy import deploy, apps, lint
from linkworld_cli.config import CliConfig


_VALID_MANIFEST = """\
apiVersion: linkworld.ai/v2
app_id: test-bot
version: 1.2.3
name: Test Bot
required_scopes: [mail.send]
runtime:
  image: ghcr.io/example/test-bot:1.2.3
lifecycle:
  on_inbound: true
"""


@pytest.fixture
def home_dir(tmp_path: Path, monkeypatch):
    """Redirect HOME so config writes don't touch real ~/.linkworld."""
    monkeypatch.setenv("HOME", str(tmp_path))
    return tmp_path


@pytest.fixture
def login(home_dir: Path):
    """Pre-populate a dev token so deploy doesn't hit 'not logged in'."""
    cfg = CliConfig(api_url="https://api.example", token="t.t.t")
    cfg.save()
    return cfg


@pytest.fixture
def app_dir(tmp_path: Path, monkeypatch):
    d = tmp_path / "app"
    d.mkdir()
    (d / "linkworld.app.yaml").write_text(_VALID_MANIFEST)
    monkeypatch.chdir(d)
    return d


# ── core deploy flow ─────────────────────────────────────────────────


def test_deploy_without_login_exits_fast(home_dir: Path, app_dir: Path):
    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight"])
    assert result.exit_code == 1
    assert "login" in (result.output + str(result.exception or "")).lower()


def test_deploy_no_manifest_exits_with_helpful_message(login, tmp_path: Path, monkeypatch):
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()
    monkeypatch.chdir(empty_dir)
    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight"])
    assert result.exit_code == 1
    assert "linkworld.app.yaml" in result.output or "manifest" in result.output.lower()


def test_deploy_invalid_manifest_exits_one(login, app_dir: Path):
    """Invalid YAML in the manifest = exit 1 (user error), not 2 (API)."""
    (app_dir / "linkworld.app.yaml").write_text(
        "apiVersion: wrong-thing\napp_id: test-bot\n"
    )
    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight"])
    assert result.exit_code == 1
    assert "manifest" in result.output.lower()


def test_deploy_happy_path(login, app_dir: Path, monkeypatch):
    """End-to-end: skip-build, mock all API calls, expect 0 + correct registration."""
    captured: dict = {"calls": []}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["calls"].append({
            "method": req.method,
            "path": str(req.url.path),
            "body": json.loads(req.content) if req.content else None,
        })
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "dev-1", "email": "x@y.com", "publish_allowed": True,
                "status": "active", "github_login": None, "display_name": None,
            })
        if req.url.path == "/api/dev/apps/test-bot" and req.method == "GET":
            # First-deploy → app doesn't exist → 404 to trigger create
            return httpx.Response(404, json={"detail": "app not found"})
        if req.url.path == "/api/dev/apps" and req.method == "POST":
            return httpx.Response(201, json={
                "id": "app-1", "slug": "test-bot", "name": "Test Bot",
                "description": "", "icon": "box",
                "status": "draft", "current_version": None, "created_at": "now",
            })
        if req.url.path == "/api/dev/apps/test-bot/versions" and req.method == "POST":
            body = json.loads(req.content)
            assert body["version"] == "1.2.3"
            assert body["image_url"] == "ghcr.io/example/test-bot:1.2.3"
            assert body["promote"] is True
            return httpx.Response(201, json={
                "id": "ver-1", "version": "1.2.3",
                "image_url": "ghcr.io/example/test-bot:1.2.3",
                "image_digest": None, "build_status": "success",
                "status": "published", "deployed_at": "2026-01-01T00:00:00Z",
            })
        return httpx.Response(404, json={"detail": "unexpected route"})

    transport = httpx.MockTransport(handler)
    real_client_init = httpx.Client.__init__

    def patched_client_init(self, *args, **kwargs):
        kwargs["transport"] = transport
        real_client_init(self, *args, **kwargs)

    monkeypatch.setattr(httpx.Client, "__init__", patched_client_init)

    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight"])
    assert result.exit_code == 0, f"exit={result.exit_code}\noutput={result.output}\nexc={result.exception}"
    # Saw: GET /me, GET /apps/test-bot, POST /apps, POST /apps/test-bot/versions
    paths = [c["path"] for c in captured["calls"]]
    assert "/api/dev/me" in paths
    assert any(p == "/api/dev/apps" and c["method"] == "POST"
               for p, c in zip(paths, captured["calls"]))
    assert "/api/dev/apps/test-bot/versions" in paths


def test_deploy_publish_not_allowed_blocks(login, app_dir: Path, monkeypatch):
    """A dev whose publish_allowed=false must be told no, before anything destructive happens."""
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "dev-1", "email": "x@y.com",
                "publish_allowed": False,  # ← key
                "status": "active",
                "github_login": None, "display_name": None,
            })
        return httpx.Response(500, json={"detail": "should not be called"})

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight"])
    assert result.exit_code == 2
    assert "publish" in result.output.lower() or "not allowed" in result.output.lower()


def test_deploy_version_override(login, app_dir: Path, monkeypatch):
    """--version flag overrides manifest's version (used by CI tag-based deploys)."""
    seen_version: dict = {}

    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "dev-1", "email": "x@y.com", "publish_allowed": True,
                "status": "active",
                "github_login": None, "display_name": None,
            })
        if req.url.path == "/api/dev/apps/test-bot" and req.method == "GET":
            return httpx.Response(200, json={
                "id": "app-1", "slug": "test-bot", "name": "Test Bot",
                "description": "", "icon": "box",
                "status": "active", "current_version": None, "created_at": "now",
            })
        if req.url.path == "/api/dev/apps/test-bot/versions" and req.method == "POST":
            body = json.loads(req.content)
            seen_version["v"] = body["version"]
            return httpx.Response(201, json={
                "id": "ver-1", "version": body["version"],
                "image_url": body["image_url"],
                "image_digest": None, "build_status": "success",
                "status": "published", "deployed_at": "now",
            })
        return httpx.Response(404, json={"detail": "unexpected route"})

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight", "--version", "9.9.9"])
    assert result.exit_code == 0, result.output
    assert seen_version.get("v") == "9.9.9"


def test_deploy_no_promote_passes_flag(login, app_dir: Path, monkeypatch):
    seen: dict = {}

    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "dev-1", "email": "x@y.com", "publish_allowed": True,
                "status": "active",
                "github_login": None, "display_name": None,
            })
        if req.url.path == "/api/dev/apps/test-bot" and req.method == "GET":
            return httpx.Response(200, json={
                "id": "app-1", "slug": "test-bot", "name": "Test Bot",
                "description": "", "icon": "box",
                "status": "active", "current_version": None, "created_at": "now",
            })
        if req.url.path == "/api/dev/apps/test-bot/versions" and req.method == "POST":
            body = json.loads(req.content)
            seen["promote"] = body["promote"]
            return httpx.Response(201, json={
                "id": "ver-1", "version": body["version"],
                "image_url": body["image_url"],
                "image_digest": None, "build_status": "success",
                "status": "published", "deployed_at": "now",
            })
        return httpx.Response(404, json={"detail": "unexpected route"})

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    runner = CliRunner()
    result = runner.invoke(deploy, ["--skip-build", "--no-preflight", "--no-promote"])
    assert result.exit_code == 0
    assert seen["promote"] is False


# ── apps list / show ─────────────────────────────────────────────────


def test_apps_list_empty(login, app_dir: Path, monkeypatch):
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/apps":
            return httpx.Response(200, json=[])
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    runner = CliRunner()
    result = runner.invoke(apps, ["list"])
    assert result.exit_code == 0
    assert "No apps yet" in result.output or "init" in result.output.lower()


def test_apps_list_with_data(login, app_dir: Path, monkeypatch):
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/api/dev/apps":
            return httpx.Response(200, json=[{
                "id": "1", "slug": "tax-bot", "name": "Tax Bot",
                "description": "", "icon": "box",
                "status": "active", "current_version": "1.2.0",
                "created_at": "now",
            }])
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    runner = CliRunner()
    result = runner.invoke(apps, ["list"])
    assert result.exit_code == 0
    assert "tax-bot" in result.output
    assert "1.2.0" in result.output


# ── Preflight tests (Wave 2) ─────────────────────────────────────────


def test_deploy_runs_preflight_before_build(login, app_dir: Path, monkeypatch):
    """Default deploy hits /api/dev/preflight BEFORE attempting docker
    build. Catches the most common deploy-failure modes (undeclared
    scope, missing handler) without burning 2 min on a build that's
    going to be rejected anyway."""
    captured: dict = {"calls": []}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["calls"].append(req.url.path)
        if req.url.path == "/api/dev/preflight":
            return httpx.Response(200, json={
                "valid": True, "issues": [],
                "error_count": 0, "warning_count": 0,
                "app_id": "test-bot", "version": "1.2.3",
            })
        if req.url.path == "/api/dev/me":
            return httpx.Response(200, json={
                "id": "dev-1", "email": "x@y.com", "publish_allowed": True,
                "status": "active", "github_login": None, "display_name": None,
            })
        if req.url.path == "/api/dev/apps/test-bot" and req.method == "GET":
            return httpx.Response(404, json={"detail": "app not found"})
        if req.url.path == "/api/dev/apps" and req.method == "POST":
            return httpx.Response(201, json={
                "id": "app-1", "slug": "test-bot", "name": "Test Bot",
                "description": "", "icon": "box",
                "status": "draft", "current_version": None, "created_at": "now",
            })
        if req.url.path == "/api/dev/apps/test-bot/versions":
            return httpx.Response(201, json={
                "id": "ver-1", "version": "1.2.3",
                "image_url": "ghcr.io/example/test-bot:1.2.3",
                "image_digest": None, "build_status": "success",
                "status": "published", "deployed_at": "2026-01-01T00:00:00Z",
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    result = CliRunner().invoke(deploy, ["--skip-build"])
    assert result.exit_code == 0, f"output={result.output}\nexc={result.exception}"

    # Preflight must run BEFORE the version create — otherwise the
    # error budget assumption (catch before build) doesn't hold.
    assert "/api/dev/preflight" in captured["calls"]
    pre_idx = captured["calls"].index("/api/dev/preflight")
    ver_idx = captured["calls"].index("/api/dev/apps/test-bot/versions")
    assert pre_idx < ver_idx


def test_deploy_aborts_when_preflight_returns_errors(login, app_dir: Path, monkeypatch):
    """Preflight returning ``valid: false`` must abort the deploy
    with exit 1 — no build, no version-create. The fix_hint guides
    the dev to a working state."""
    captured: dict = {"calls": []}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["calls"].append(req.url.path)
        if req.url.path == "/api/dev/preflight":
            return httpx.Response(200, json={
                "valid": False,
                "issues": [{
                    "severity": "error",
                    "file": "linkworld.app.yaml",
                    "line": None,
                    "message": "required_scopes references unknown scope 'mail.send_attachments'",
                    "fix_hint": "Use 'mail.send' instead.",
                }],
                "error_count": 1, "warning_count": 0,
                "app_id": "test-bot", "version": "1.2.3",
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    result = CliRunner().invoke(deploy, ["--skip-build"])
    assert result.exit_code == 1
    assert "preflight failed" in result.output
    # Fix-hint must be visible — that's what makes preflight worth
    # the round trip vs just deploying and reading server errors.
    assert "mail.send" in result.output
    # Crucially: no version-create call was made.
    assert "/api/dev/apps/test-bot/versions" not in captured["calls"]


def test_lint_command_runs_preflight_only(login, app_dir: Path, monkeypatch):
    """`linkworld lint` is the standalone variant — call preflight,
    print the result, exit. No /api/dev/me, no version-create.
    This is what devs run during iteration before they're ready
    to deploy."""
    captured: dict = {"calls": []}

    def handler(req: httpx.Request) -> httpx.Response:
        captured["calls"].append(req.url.path)
        if req.url.path == "/api/dev/preflight":
            return httpx.Response(200, json={
                "valid": True, "issues": [],
                "error_count": 0, "warning_count": 0,
                "app_id": "test-bot", "version": "1.2.3",
            })
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    real_init = httpx.Client.__init__
    monkeypatch.setattr(
        httpx.Client, "__init__",
        lambda self, *a, **kw: real_init(self, *a, **{**kw, "transport": transport}),
    )

    result = CliRunner().invoke(lint, [])
    assert result.exit_code == 0
    assert "preflight passed" in result.output
    # No deploy-only endpoints touched
    assert all(p == "/api/dev/preflight" for p in captured["calls"])
