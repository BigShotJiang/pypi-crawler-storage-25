"""Tests for the ApiClient — hits a mock httpx transport, no network."""

from __future__ import annotations

import json

import httpx
import pytest

from linkworld_cli.api import ApiClient, ApiError
from linkworld_cli.config import CliConfig


def _client_with_transport(handler) -> ApiClient:
    """Build an ApiClient whose underlying httpx uses MockTransport."""
    cfg = CliConfig(api_url="https://api.example", token="t.t.t")
    client = ApiClient(cfg)

    # Monkey-patch httpx.Client to use MockTransport
    transport = httpx.MockTransport(handler)
    real_request = client._request

    def patched_request(method, path, *, json=None, timeout=30.0):
        url = f"{client.base_url}{path}"
        try:
            with httpx.Client(transport=transport, timeout=timeout) as h:
                resp = h.request(
                    method, url, headers=client._headers(), json=json,
                )
        except httpx.HTTPError as exc:
            raise ApiError(f"network error: {exc}") from exc
        if 200 <= resp.status_code < 300:
            return resp.json() if resp.content else None
        body = resp.json() if resp.content else {}
        detail = body.get("detail") or body.get("error") or "fail"
        raise ApiError(
            f"{method} {path} → {resp.status_code}: {detail}",
            status=resp.status_code, body=body,
        )

    client._request = patched_request  # type: ignore[assignment]
    return client


def test_me_happy_path():
    def handler(req: httpx.Request) -> httpx.Response:
        assert req.url.path == "/api/dev/me"
        assert req.headers.get("Authorization") == "Bearer t.t.t"
        return httpx.Response(200, json={"id": "abc", "email": "a@b.c", "status": "active",
                                         "publish_allowed": True, "display_name": None,
                                         "github_login": None})
    client = _client_with_transport(handler)
    me = client.me()
    assert me["email"] == "a@b.c"


def test_unauthorized_raises_apierror():
    def handler(req: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "Authentication required"})
    client = _client_with_transport(handler)
    with pytest.raises(ApiError) as ei:
        client.me()
    assert ei.value.status == 401
    assert "Authentication required" in str(ei.value)


def test_create_app_posts_correct_payload():
    captured = {}
    def handler(req: httpx.Request) -> httpx.Response:
        captured["url"] = str(req.url.path)
        captured["body"] = json.loads(req.content)
        return httpx.Response(201, json={"id": "x", "slug": "tax-bot", "name": "Tax Bot",
                                         "description": "", "icon": "box",
                                         "status": "draft", "current_version": None, "created_at": "now"})
    client = _client_with_transport(handler)
    out = client.create_app("tax-bot", name="Tax Bot")
    assert captured["url"] == "/api/dev/apps"
    assert captured["body"]["slug"] == "tax-bot"
    assert out["slug"] == "tax-bot"


def test_no_token_raises_before_request():
    cfg = CliConfig(api_url="https://x", token=None)
    with pytest.raises(ApiError) as ei:
        ApiClient(cfg).me()
    assert ei.value.status == 401
    assert "linkworld login" in str(ei.value)
