"""linkworld CLI entry point.

Subcommands are split into modules under ``linkworld_cli/cmd/`` so this
file stays a thin wiring layer. Each subcommand returns 0 on success or
a small non-zero code on error (Click prints any exception we let
escape — we catch ApiError ourselves to render friendly messages).
"""

from __future__ import annotations

import sys

import click
from rich.console import Console

from . import __version__
from .api import ApiError

console = Console()
err_console = Console(stderr=True)


@click.group(
    help="Build and deploy apps for the Linkworld Open App Platform.",
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(__version__, "-V", "--version")
def cli() -> None:
    pass


def _safe(fn):
    """Catch ApiError and print friendly stderr; let bugs propagate."""
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except ApiError as exc:
            err_console.print(f"[red]{exc}[/red]")
            sys.exit(2)
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


# Lazy register subcommands so importing the package is cheap.
def _register_subcommands() -> None:
    from .cmd import chat as cmd_chat
    from .cmd import deploy as cmd_deploy
    from .cmd import dev as cmd_dev
    from .cmd import doctor as cmd_doctor
    from .cmd import eval as cmd_eval
    from .cmd import init as cmd_init
    from .cmd import login as cmd_login
    from .cmd import mcp as cmd_mcp
    from .cmd import secrets as cmd_secrets

    cli.add_command(cmd_init.init)
    cli.add_command(cmd_login.login)
    cli.add_command(cmd_login.whoami)
    cli.add_command(cmd_login.logout)
    cli.add_command(cmd_deploy.deploy)
    cli.add_command(cmd_deploy.lint)
    cli.add_command(cmd_deploy.apps)
    cli.add_command(cmd_deploy.upgrade)
    cli.add_command(cmd_mcp.mcp)
    cli.add_command(cmd_secrets.secrets)
    cli.add_command(cmd_dev.dev)
    cli.add_command(cmd_eval.eval_cmd, name="eval")
    cli.add_command(cmd_chat.chat)
    cli.add_command(cmd_doctor.doctor)


_register_subcommands()


__all__ = ["cli"]
