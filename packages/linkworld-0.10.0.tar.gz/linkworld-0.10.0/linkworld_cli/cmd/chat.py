"""linkworld chat — browser-based live playground for your app.

Spins up a local HTTP server hosting a chat UI plus a thin bridge that
drives the in-process app's ``on_inbound`` handler. Each user message
becomes one inbound dispatch; the runner captures every tool call,
agent call, and exception, and returns them as a structured trace the
UI renders next to the response.

Two modes:

- **Mock mode** (default): tool responses come from ``linkworld.dev.json``
  (same shape as ``linkworld dev``); agent calls return a configurable
  stub response. Predictable, no LLM cost.
- **Live mode** (``--live``): agent calls reach a real Anthropic LLM
  using ``ANTHROPIC_API_KEY`` from the environment. Tool calls remain
  mocked — the playground exercises agent reasoning, not platform
  tools.

Tool mocks are reloaded on every request so edits to
``linkworld.dev.json`` pick up immediately.

This is for developer sanity-checking — for CI, use ``linkworld eval``.
"""

from __future__ import annotations

import asyncio
import html
import json
import os
import sys
import threading
import time
import traceback
import urllib.parse
import webbrowser
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional

import click
from rich.console import Console


console = Console()
err = Console(stderr=True)

DEFAULT_PORT = 5175


# ── Captured trace types ────────────────────────────────────────────


@dataclass
class TraceEvent:
    kind: str  # "tool_call" | "tool_response" | "agent_call" | "agent_response" | "error"
    name: Optional[str]
    detail: dict
    ts_ms: float

    def to_dict(self) -> dict:
        return {
            "kind": self.kind,
            "name": self.name,
            "detail": self.detail,
            "ts_ms": self.ts_ms,
        }


# ── Recording mocks ─────────────────────────────────────────────────


class _RecordingTools:
    """Reads mocks from a JSON file on every call (so edits pick up)
    and records every call into a shared trace list.
    """

    def __init__(self, mock_path: Path, trace: list[TraceEvent], t_start: float) -> None:
        self.mock_path = mock_path
        self.trace = trace
        self.t_start = t_start

    def _load(self) -> dict:
        if not self.mock_path.is_file():
            return {}
        try:
            return json.loads(self.mock_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    async def call(self, tool_name: str, /, **args: Any) -> dict:
        from linkworld_sdk import ToolCallError

        ts = (time.perf_counter() - self.t_start) * 1000.0
        self.trace.append(TraceEvent(
            kind="tool_call", name=tool_name, detail={"args": args}, ts_ms=ts,
        ))

        mocks = self._load()
        m = mocks.get(tool_name)
        if m is None:
            self.trace.append(TraceEvent(
                kind="error", name=tool_name,
                detail={"reason": "no mock wired",
                        "hint": f"Add '{tool_name}' to linkworld.dev.json"},
                ts_ms=(time.perf_counter() - self.t_start) * 1000.0,
            ))
            raise ToolCallError(
                tool_name,
                f"no mock wired for '{tool_name}' — add it to linkworld.dev.json",
                decision="not_found",
            )
        if isinstance(m, dict) and m.get("ok") is False:
            err_info = m.get("error") or {"message": "mocked failure"}
            self.trace.append(TraceEvent(
                kind="tool_response", name=tool_name,
                detail={"ok": False, "error": err_info},
                ts_ms=(time.perf_counter() - self.t_start) * 1000.0,
            ))
            raise ToolCallError(
                tool_name,
                err_info.get("message", "mocked failure"),
                decision=err_info.get("decision", "mocked"),
                needed_scopes=err_info.get("neededScopes") or [],
            )
        result = m.get("result", {}) if isinstance(m, dict) else m
        self.trace.append(TraceEvent(
            kind="tool_response", name=tool_name,
            detail={"ok": True, "result": result},
            ts_ms=(time.perf_counter() - self.t_start) * 1000.0,
        ))
        return result if isinstance(result, dict) else {"value": result}


class _RecordingSecrets:
    """Pass-through for ``linkworld.dev.json``'s ``_secrets`` map (if any)."""

    def __init__(self, mock_path: Path) -> None:
        self.mock_path = mock_path

    def _load(self) -> dict:
        if not self.mock_path.is_file():
            return {}
        try:
            data = json.loads(self.mock_path.read_text(encoding="utf-8"))
            return data.get("_secrets") or {}
        except Exception:
            return {}

    async def get(self, key: str) -> Optional[str]:
        return self._load().get(key)


class _RecordingAgent:
    """Mock or live agent. In mock mode returns a configurable response
    (from ``linkworld.dev.json[_agents]``); in live mode hits Anthropic.
    """

    def __init__(
        self,
        mock_path: Path,
        trace: list[TraceEvent],
        t_start: float,
        live: bool,
        manifest: Any,
    ) -> None:
        self.mock_path = mock_path
        self.trace = trace
        self.t_start = t_start
        self.live = live
        self.manifest = manifest

    def _load_mocks(self) -> dict:
        if not self.mock_path.is_file():
            return {}
        try:
            data = json.loads(self.mock_path.read_text(encoding="utf-8"))
            return data.get("_agents") or {}
        except Exception:
            return {}

    async def ask(
        self,
        prompt: str,
        /,
        *,
        agent: Optional[str] = None,
        response_format: Optional[dict] = None,
        images: Optional[list] = None,
        max_tokens: int = 4096,
    ) -> Any:
        from linkworld_sdk import AgentResponse

        slug = agent or "default"
        ts = (time.perf_counter() - self.t_start) * 1000.0
        self.trace.append(TraceEvent(
            kind="agent_call", name=slug,
            detail={"prompt": prompt, "max_tokens": max_tokens,
                    "structured": bool(response_format)},
            ts_ms=ts,
        ))

        if self.live:
            text, model = await _call_anthropic(self.manifest, slug, prompt, max_tokens)
            self.trace.append(TraceEvent(
                kind="agent_response", name=slug,
                detail={"text": text, "model": model, "live": True},
                ts_ms=(time.perf_counter() - self.t_start) * 1000.0,
            ))
            return AgentResponse(
                text=text, data=None, agent=slug, model=model,
                input_tokens=None, output_tokens=None,
            )

        mocks = self._load_mocks()
        wired = mocks.get(slug) or mocks.get("__any__") or {
            "text": f"(mock {slug}) — wire a response in linkworld.dev.json under _agents.{slug}",
        }
        self.trace.append(TraceEvent(
            kind="agent_response", name=slug,
            detail={"text": wired.get("text"), "data": wired.get("data"),
                    "model": wired.get("model", "mock"), "live": False},
            ts_ms=(time.perf_counter() - self.t_start) * 1000.0,
        ))
        return AgentResponse(
            text=wired.get("text"),
            data=wired.get("data"),
            agent=slug,
            model=wired.get("model", "mock"),
            input_tokens=wired.get("input_tokens", 0),
            output_tokens=wired.get("output_tokens", 0),
        )


class _PlaygroundUnsupported:
    """Stand-in for ``ctx.team`` / ``ctx.apps`` / ``ctx.events`` / ``ctx.rooms``
    / ``ctx.commitments`` in the playground.

    These M3.14 surfaces require platform-side state (team membership,
    bilateral grants, room subscriptions, durable commitments). The
    playground runs in-process with no platform connection, so any
    call raises a clear error pointing at the right alternative
    (eval scenarios, real dev tenant) instead of letting the handler
    blow up with ``AttributeError``.
    """

    __slots__ = ("_surface",)

    def __init__(self, surface: str) -> None:
        self._surface = surface

    def __getattr__(self, name: str) -> Any:
        async def _raise(*_a: Any, **_kw: Any) -> Any:
            from linkworld_sdk import ToolCallError

            raise ToolCallError(
                f"{self._surface}.{name}",
                f"ctx.{self._surface} is not available in `linkworld chat` — "
                f"the playground runs in-process without platform state. "
                f"Use `linkworld eval` to assert on this surface, or run "
                f"the app on a dev tenant via `linkworld deploy`.",
                decision="playground_not_supported",
            )
        return _raise


async def _call_anthropic(
    manifest: Any, slug: str, prompt: str, max_tokens: int,
) -> tuple[str, str]:
    """Single-turn Anthropic call — pulls system_prompt + model from
    the manifest's agent declaration. Best-effort: if the manifest
    doesn't list the agent, we still send the prompt with a generic
    system message so the playground stays useful.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return ("(--live requested but ANTHROPIC_API_KEY is not set)",
                "no-model")

    system_prompt = "You are a helpful assistant."
    model = "claude-sonnet-4-6"
    agents = getattr(manifest, "agents", None) or []
    for a in agents:
        a_slug = getattr(a, "slug", None) or (a.get("slug") if isinstance(a, dict) else None)
        if a_slug == slug:
            sp = getattr(a, "system_prompt", None) or (
                a.get("system_prompt") if isinstance(a, dict) else None
            )
            if sp:
                system_prompt = sp
            mdl = getattr(a, "model", None) or (
                a.get("model") if isinstance(a, dict) else None
            )
            if mdl:
                model = mdl
            break

    try:
        import urllib.request
        req_body = json.dumps({
            "model": model,
            "max_tokens": max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": prompt}],
        }).encode("utf-8")
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=req_body,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        # Run the blocking HTTP call off the event loop.
        loop = asyncio.get_event_loop()

        def _fetch() -> bytes:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.read()

        body = await loop.run_in_executor(None, _fetch)
        data = json.loads(body)
        text = ""
        for block in data.get("content") or []:
            if block.get("type") == "text":
                text += block.get("text", "")
        return text or "(empty response)", data.get("model", model)
    except Exception as exc:
        return (f"(live call failed: {type(exc).__name__}: {exc})", "no-model")


# ── App invocation ──────────────────────────────────────────────────


async def _dispatch_message(
    app: Any,
    text: str,
    mock_path: Path,
    live: bool,
) -> dict:
    """Dispatch one playground message through the app. Returns a JSON
    payload describing what happened (handler return value, trace events,
    error info if any).
    """
    from linkworld_sdk import Context, ToolCallError
    from linkworld_sdk.envelope import InboundEnvelope

    handler = app._lifecycle.on_inbound  # noqa: SLF001
    if handler is None:
        return {
            "ok": False,
            "error": "this app has no @app.on_inbound handler — playground "
                     "needs one to dispatch chat messages.",
            "trace": [],
        }

    trace: list[TraceEvent] = []
    t_start = time.perf_counter()
    tools = _RecordingTools(mock_path, trace, t_start)
    secrets = _RecordingSecrets(mock_path)
    agent = _RecordingAgent(mock_path, trace, t_start, live, app.manifest)

    ctx = Context(
        tenant_id="t-playground",
        user_id="u-playground",
        app_id=app.manifest.app_id,
        event_type="inbound",
        tools=tools,
        secrets=secrets,
        agent=agent,
        team=_PlaygroundUnsupported("team"),
        apps=_PlaygroundUnsupported("apps"),
        events=_PlaygroundUnsupported("events"),
        rooms=_PlaygroundUnsupported("rooms"),
        commitments=_PlaygroundUnsupported("commitments"),
    )
    env = InboundEnvelope(
        tenant_id="t-playground",
        user_id="u-playground",
        channel="web",
        modality="text",
        channel_thread_id="playground-thread",
        message_text=text,
        attachments=[],
    )

    err_info: Optional[dict] = None
    try:
        await handler(ctx, env)
        ok = True
    except ToolCallError as exc:
        ok = False
        err_info = {
            "type": "ToolCallError",
            "tool": exc.tool_name,
            "decision": exc.decision,
            "message": str(exc),
        }
    except Exception as exc:
        ok = False
        err_info = {
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": "".join(traceback.format_exception(exc))[:4000],
        }

    elapsed_ms = (time.perf_counter() - t_start) * 1000.0

    # Pull the last agent response out of the trace as the canonical
    # "what to show in the chat bubble" — most apps end their on_inbound
    # by either replying via a tool (email_send, rooms.post) or asking
    # the agent. The latest agent_response is the best heuristic.
    primary_response: Optional[str] = None
    for ev in reversed(trace):
        if ev.kind == "agent_response":
            primary_response = ev.detail.get("text")
            break
    if primary_response is None and ok:
        # Fall back to whatever the last tool_response carried (e.g.
        # an email_send echoing the body).
        for ev in reversed(trace):
            if ev.kind == "tool_response" and ev.detail.get("ok"):
                result = ev.detail.get("result") or {}
                primary_response = (
                    result.get("body") or result.get("message")
                    or result.get("text") or json.dumps(result)
                )
                break

    return {
        "ok": ok,
        "response": primary_response or ("(no agent or tool response — see trace)" if ok else None),
        "error": err_info,
        "trace": [ev.to_dict() for ev in trace],
        "elapsed_ms": elapsed_ms,
    }


# ── HTTP server ─────────────────────────────────────────────────────


class _ChatHandler(BaseHTTPRequestHandler):
    app: Any = None
    mock_path: Path = Path()
    live: bool = False

    def log_message(self, *_args, **_kwargs) -> None:
        if os.environ.get("LINKWORLD_CHAT_VERBOSE"):
            super().log_message(*_args, **_kwargs)

    def do_GET(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            self._send_html(_render_chat_html(self.app, self.live))
            return
        if path == "/api/health":
            self._send_json({"ok": True})
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:  # noqa: N802
        if urllib.parse.urlparse(self.path).path != "/api/chat":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        length = int(self.headers.get("Content-Length") or 0)
        body = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self._send_json({"ok": False, "error": "bad JSON"}, code=400)
            return
        text = str(payload.get("text") or "").strip()
        if not text:
            self._send_json({"ok": False, "error": "empty text"}, code=400)
            return
        try:
            result = asyncio.run(_dispatch_message(
                self.app, text, self.mock_path, self.live,
            ))
        except Exception as exc:
            self._send_json({
                "ok": False,
                "error": f"playground bridge crashed: {type(exc).__name__}: {exc}",
            }, code=500)
            return
        self._send_json(result)

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, obj: dict, code: int = 200) -> None:
        body = json.dumps(obj, default=str).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)


def _render_chat_html(app: Any, live: bool) -> str:
    app_id = html.escape(getattr(app.manifest, "app_id", "app") or "app")
    mode_label = "live (Anthropic)" if live else "mock"
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>linkworld chat — {app_id}</title>
<style>
  :root {{
    --bg: #0b0d12;
    --surface: #161922;
    --raised: #1f2330;
    --text: #e6e8ee;
    --muted: #8b91a3;
    --border: #262a36;
    --accent: #6366f1;
    --ok: #22c55e;
    --err: #ef4444;
  }}
  html, body {{ margin: 0; height: 100%; }}
  body {{
    background: var(--bg);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    display: flex;
    flex-direction: column;
  }}
  header {{
    display: flex; align-items: center; gap: 12px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--border);
  }}
  header strong {{ font-weight: 600; }}
  header .pill {{
    padding: 2px 8px; border: 1px solid var(--border); border-radius: 999px;
    color: var(--muted); font-size: 11px;
  }}
  header .pill.live {{ color: var(--accent); border-color: var(--accent); }}
  main {{
    flex: 1; display: grid; grid-template-columns: 1fr 380px;
    overflow: hidden;
  }}
  #chat {{
    display: flex; flex-direction: column;
    border-right: 1px solid var(--border);
    overflow: hidden;
  }}
  #log {{
    flex: 1; overflow-y: auto;
    padding: 16px; display: flex; flex-direction: column; gap: 12px;
  }}
  .msg {{ max-width: 80%; padding: 10px 14px; border-radius: 12px;
          line-height: 1.45; }}
  .msg.user {{ align-self: flex-end; background: var(--accent); color: white; }}
  .msg.bot {{ align-self: flex-start; background: var(--raised); }}
  .msg.err {{ align-self: flex-start; background: var(--surface);
              border: 1px solid var(--err); color: var(--err); }}
  .msg pre {{ white-space: pre-wrap; word-break: break-word; margin: 0;
              font-family: ui-monospace, monospace; font-size: 12px; }}
  .meta {{ font-size: 11px; color: var(--muted); margin-top: 4px; }}
  form {{
    display: flex; gap: 8px; padding: 12px;
    border-top: 1px solid var(--border);
  }}
  input[type=text] {{
    flex: 1; padding: 10px 12px;
    background: var(--surface); color: var(--text);
    border: 1px solid var(--border); border-radius: 8px;
    font-size: 14px;
  }}
  input[type=text]:focus {{ outline: 1px solid var(--accent); }}
  button {{
    padding: 10px 18px; background: var(--accent); color: white;
    border: 0; border-radius: 8px; font-weight: 600; cursor: pointer;
  }}
  button:disabled {{ opacity: 0.5; cursor: not-allowed; }}
  #trace {{
    overflow-y: auto; padding: 16px; background: var(--surface);
  }}
  #trace h2 {{ font-size: 13px; text-transform: uppercase;
               letter-spacing: 0.05em; color: var(--muted);
               margin: 0 0 12px; }}
  .turn {{ margin-bottom: 18px; }}
  .turn h3 {{ font-size: 12px; color: var(--muted); margin: 0 0 6px;
             font-weight: 500; }}
  .ev {{ padding: 6px 10px; background: var(--raised);
         border-left: 2px solid var(--accent);
         border-radius: 4px; margin-bottom: 4px;
         font-family: ui-monospace, monospace; font-size: 12px; }}
  .ev.error {{ border-left-color: var(--err); }}
  .ev .k {{ color: var(--muted); font-size: 10px;
            text-transform: uppercase; letter-spacing: 0.05em;
            margin-right: 6px; }}
  .ev .n {{ font-weight: 600; }}
  .ev pre {{ white-space: pre-wrap; word-break: break-word;
             margin: 4px 0 0; color: var(--muted); font-size: 11px; }}
  .empty {{ color: var(--muted); font-size: 12px; }}
</style>
</head>
<body>
<header>
  <strong>linkworld chat</strong>
  <span class="pill">{app_id}</span>
  <span class="pill {'live' if live else ''}">{mode_label}</span>
  <span style="flex:1"></span>
  <span class="pill" id="status">ready</span>
</header>
<main>
  <section id="chat">
    <div id="log"></div>
    <form id="form">
      <input type="text" id="input" placeholder="Type a message — drives on_inbound" autocomplete="off" />
      <button type="submit" id="send">Send</button>
    </form>
  </section>
  <aside id="trace">
    <h2>Trace</h2>
    <div id="trace-body"><div class="empty">No turn yet.</div></div>
  </aside>
</main>
<script>
const log = document.getElementById('log');
const form = document.getElementById('form');
const input = document.getElementById('input');
const send = document.getElementById('send');
const status = document.getElementById('status');
const traceBody = document.getElementById('trace-body');
const traceTurns = [];

function pushBubble(cls, text, meta) {{
  const div = document.createElement('div');
  div.className = 'msg ' + cls;
  const pre = document.createElement('pre');
  pre.textContent = text;
  div.appendChild(pre);
  if (meta) {{
    const m = document.createElement('div');
    m.className = 'meta';
    m.textContent = meta;
    div.appendChild(m);
  }}
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}}

function renderTrace() {{
  traceBody.innerHTML = '';
  if (!traceTurns.length) {{
    traceBody.innerHTML = '<div class="empty">No turn yet.</div>';
    return;
  }}
  traceTurns.forEach((turn, idx) => {{
    const wrap = document.createElement('div');
    wrap.className = 'turn';
    const h = document.createElement('h3');
    h.textContent = `Turn ${{idx + 1}} — ${{turn.elapsed_ms.toFixed(0)}} ms${{turn.ok ? '' : ' — failed'}}`;
    wrap.appendChild(h);
    if (!turn.trace.length) {{
      const e = document.createElement('div');
      e.className = 'empty';
      e.textContent = 'No platform calls.';
      wrap.appendChild(e);
    }}
    turn.trace.forEach(ev => {{
      const ed = document.createElement('div');
      ed.className = 'ev' + (ev.kind === 'error' ? ' error' : '');
      const k = document.createElement('span');
      k.className = 'k';
      k.textContent = ev.kind;
      const n = document.createElement('span');
      n.className = 'n';
      n.textContent = ev.name || '';
      ed.appendChild(k);
      ed.appendChild(n);
      const pre = document.createElement('pre');
      pre.textContent = JSON.stringify(ev.detail, null, 2);
      ed.appendChild(pre);
      wrap.appendChild(ed);
    }});
    traceBody.appendChild(wrap);
  }});
}}

form.addEventListener('submit', async (e) => {{
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  pushBubble('user', text);
  input.value = '';
  send.disabled = true;
  status.textContent = 'thinking…';
  try {{
    const res = await fetch('/api/chat', {{
      method: 'POST',
      headers: {{ 'Content-Type': 'application/json' }},
      body: JSON.stringify({{ text }}),
    }});
    const data = await res.json();
    traceTurns.push(data);
    if (data.ok) {{
      pushBubble('bot', data.response || '(no response)',
                 `${{data.elapsed_ms.toFixed(0)}} ms · ${{data.trace.length}} event(s)`);
    }} else {{
      const e = data.error || {{ message: 'unknown' }};
      pushBubble('err', `${{e.type || 'Error'}}: ${{e.message || 'unknown'}}`,
                 `${{(data.elapsed_ms||0).toFixed(0)}} ms`);
    }}
    renderTrace();
    status.textContent = 'ready';
  }} catch (err) {{
    pushBubble('err', `Network: ${{err}}`);
    status.textContent = 'error';
  }} finally {{
    send.disabled = false;
    input.focus();
  }}
}});

input.focus();
</script>
</body>
</html>
"""


# ── CLI command ─────────────────────────────────────────────────────


@click.command(
    "chat",
    help="Browser-based live playground for your app's on_inbound handler.",
)
@click.option("--main", "main_path", type=click.Path(path_type=Path),
              default="main.py",
              help="Path to your app's entry module exporting an App instance.")
@click.option("--mocks", "mocks_path", type=click.Path(path_type=Path),
              default="linkworld.dev.json",
              help="Mock config (tools + agents + secrets).")
@click.option("--port", type=int, default=DEFAULT_PORT, show_default=True,
              help="Port for the playground HTTP server.")
@click.option("--live", is_flag=True,
              help="Use real Anthropic LLM for ctx.agent.ask. Requires "
                   "ANTHROPIC_API_KEY in env.")
@click.option("--no-open", is_flag=True, help="Don't auto-open a browser.")
def chat(
    main_path: Path,
    mocks_path: Path,
    port: int,
    live: bool,
    no_open: bool,
) -> None:
    # Lazy import — eval and chat share the same loader.
    from .eval import _load_app

    main_path = main_path.resolve()
    mocks_path = mocks_path.resolve()
    app = _load_app(main_path)

    if live and not os.environ.get("ANTHROPIC_API_KEY"):
        err.print("[yellow]--live requested but ANTHROPIC_API_KEY is not set; "
                  "agent calls will return a placeholder.[/yellow]")

    # Bind handler class attrs.
    class H(_ChatHandler):
        pass
    H.app = app
    H.mock_path = mocks_path
    H.live = live

    try:
        srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    except OSError as exc:
        err.print(f"[red]Couldn't bind on :{port} — {exc}[/red]")
        sys.exit(1)

    url = f"http://localhost:{port}/"
    console.print()
    console.print(f"[bold]linkworld chat[/bold]")
    console.print(f"  app:    [bold]{app.manifest.app_id}[/bold]")
    console.print(f"  mode:   [bold]{'live (Anthropic)' if live else 'mock'}[/bold]")
    console.print(f"  mocks:  [dim]{mocks_path}{'  (missing — defaults will be empty)' if not mocks_path.is_file() else ''}[/dim]")
    console.print(f"  open:   [bold]{url}[/bold]")
    console.print()
    console.print("[dim]Ctrl+C to stop.[/dim]")
    console.print()

    if not no_open:
        try:
            webbrowser.open(url, new=1)
        except Exception:
            pass

    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        console.print("\n[dim]Shutting down…[/dim]")
        srv.shutdown()
        srv.server_close()
