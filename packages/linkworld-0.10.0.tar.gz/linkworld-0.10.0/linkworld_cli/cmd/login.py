"""linkworld login / whoami / logout"""

from __future__ import annotations

import sys

import click
from rich.console import Console

from ..api import ApiClient, ApiError
from ..config import CliConfig

console = Console()
err = Console(stderr=True)


@click.command(help="Authenticate the CLI with a dev-account session token.")
@click.option(
    "--token",
    required=True,
    help="JWT issued by the platform admin (POST /api/dev-accounts/{id}/issue-token). "
         "GitHub OAuth device-flow is coming with the public launch.",
)
@click.option(
    "--api-url",
    default=None,
    help="Platform API URL (overrides config; defaults to https://api.linkworld.ai). "
         "Set LINKWORLD_API_URL env var to change permanently.",
)
def login(token: str, api_url: str | None) -> None:
    cfg = CliConfig.load()
    if api_url:
        cfg.api_url = api_url
    cfg.token = token.strip()
    path = cfg.save()

    # Verify the token works
    try:
        me_data = ApiClient(cfg).me()
    except ApiError as exc:
        err.print(f"[red]Token saved to {path}, but verification failed:[/red]")
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    console.print(
        f"[green]Logged in as {me_data.get('email')} "
        f"(dev_account {me_data.get('id')[:8]}...)[/green]"
    )
    console.print(f"Config: [dim]{path}[/dim]")


@click.command(help="Show the currently logged-in dev account.")
def whoami() -> None:
    cfg = CliConfig.load()
    if not cfg.token:
        err.print("[yellow]Not logged in.[/yellow] Run `linkworld login --token <jwt>`.")
        sys.exit(1)
    try:
        data = ApiClient(cfg).me()
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)
    console.print(f"id:            {data.get('id')}")
    console.print(f"email:         {data.get('email')}")
    if data.get("github_login"):
        console.print(f"github:        {data['github_login']}")
    console.print(f"status:        {data.get('status')}")
    console.print(f"can publish:   {data.get('publish_allowed')}")
    console.print(f"api url:       [dim]{cfg.api_url}[/dim]")


@click.command(help="Log out (delete the saved token).")
def logout() -> None:
    cfg = CliConfig.load()
    cfg.token = None
    cfg.save()
    console.print("[green]Logged out.[/green]")
