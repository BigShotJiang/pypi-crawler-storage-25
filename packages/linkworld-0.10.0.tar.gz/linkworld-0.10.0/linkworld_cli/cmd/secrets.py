"""linkworld secrets — manage app-scoped secrets (Phase 2 M7).

Two scopes:
  - dev-default (this CLI's command, default): visible to ALL tenants
    who install the app, unless overridden. Set by the dev who owns
    the app.
  - tenant-override: per-tenant value, set by tenant admin via the
    Apps Page UI. Not exposed via this CLI today (admins use the web UI).

Key format: ``^[A-Z][A-Z0-9_]{0,63}$`` — env-var convention.
"""

from __future__ import annotations

import re
import sys

import click
from rich.console import Console
from rich.table import Table

from ..api import ApiClient, ApiError
from ..config import CliConfig

console = Console()
err = Console(stderr=True)

# Mirror of compute.secrets.APP_SECRET_KEY_PATTERN. Drift = CLI rejects
# different keys than the platform; CI test asserts equality.
_KEY_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,63}$")


def _validate_key(key: str) -> None:
    if not _KEY_RE.match(key):
        err.print(
            f"[red]invalid key '{key}'[/red] — must match ^[A-Z][A-Z0-9_]{{0,63}}$ "
            "(uppercase letter first, then uppercase/digits/underscore)"
        )
        sys.exit(1)


def _client() -> ApiClient:
    return ApiClient(CliConfig.load())


@click.group(help="Manage app-scoped secrets (dev-defaults across all tenant installs).")
def secrets() -> None:
    pass


@secrets.command("set", help="Set a dev-default secret. Format: KEY=value.")
@click.argument("kv")
@click.option(
    "--app", "app_slug", required=True, metavar="SLUG",
    help="App slug (must be one you own).",
)
@click.option(
    "--description", default=None,
    help="Optional human-readable description (shown to tenant admins).",
)
def secrets_set(kv: str, app_slug: str, description: str | None) -> None:
    if "=" not in kv:
        err.print("[red]usage: linkworld secrets set KEY=value --app <slug>[/red]")
        sys.exit(1)
    key, _, value = kv.partition("=")
    _validate_key(key)
    if not value:
        err.print("[red]value is required (use KEY=value)[/red]")
        sys.exit(1)

    client = _client()
    try:
        client._request(
            "PUT", f"/api/dev/apps/{app_slug}/secrets/{key}",
            json={"value": value, "description": description},
        )
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)
    console.print(f"[green]✓ {app_slug}/{key} set[/green]")


@secrets.command("list", help="List dev-default secret keys for an app.")
@click.option(
    "--app", "app_slug", required=True, metavar="SLUG",
    help="App slug.",
)
def secrets_list(app_slug: str) -> None:
    client = _client()
    try:
        rows = client._request("GET", f"/api/dev/apps/{app_slug}/secrets") or []
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    if not rows:
        console.print(f"[dim]no dev-default secrets set for {app_slug}[/dim]")
        return

    t = Table(show_lines=False)
    t.add_column("key", style="bold")
    t.add_column("description")
    t.add_column("scope")
    t.add_column("updated")
    for row in rows:
        t.add_row(
            row["key"],
            row.get("description") or "[dim]—[/dim]",
            row.get("scope", ""),
            (row.get("updated_at") or "")[:19],
        )
    console.print(t)


@secrets.command("delete", help="Remove a dev-default secret.")
@click.argument("key")
@click.option(
    "--app", "app_slug", required=True, metavar="SLUG",
    help="App slug.",
)
def secrets_delete(key: str, app_slug: str) -> None:
    _validate_key(key)
    client = _client()
    try:
        out = client._request(
            "DELETE", f"/api/dev/apps/{app_slug}/secrets/{key}",
        )
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)
    if out and out.get("deleted"):
        console.print(f"[green]✓ {app_slug}/{key} deleted[/green]")
    else:
        console.print(f"[dim]no secret '{key}' was set for {app_slug}[/dim]")


@secrets.command(
    "get",
    help="Inspect a secret's metadata (value is NEVER displayed for safety).",
)
@click.argument("key")
@click.option("--app", "app_slug", required=True, metavar="SLUG")
def secrets_get(key: str, app_slug: str) -> None:
    _validate_key(key)
    client = _client()
    try:
        rows = client._request("GET", f"/api/dev/apps/{app_slug}/secrets") or []
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    found = next((r for r in rows if r["key"] == key), None)
    if not found:
        console.print(f"[yellow]no secret '{key}' set for {app_slug}[/yellow]")
        sys.exit(1)
    console.print(f"key:         {found['key']}")
    console.print(f"description: {found.get('description') or '—'}")
    console.print(f"scope:       {found.get('scope', '')}")
    console.print(f"updated:     {found.get('updated_at', '')}")
    console.print()
    console.print(
        "[dim]Note: secret values are never returned to the CLI — they're "
        "only readable by the app container at runtime.[/dim]"
    )
