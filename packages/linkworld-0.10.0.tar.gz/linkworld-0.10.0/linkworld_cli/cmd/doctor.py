"""linkworld doctor — diagnose the local environment.

Catches the env-setup bugs that bite a fresh dev BEFORE they spend
cycles on the actual app: stale login token, missing docker daemon,
no GHCR auth, SDK version drift, missing manifest in CWD.

Each check returns one of:
  ok        — green ✓, no action
  warn      — yellow !, advisory (e.g. SDK behind by a minor)
  fail      — red ✗, the thing they're about to do won't work

Exit code is the worst severity seen: 0 for all-ok or warn-only,
1 if any check failed. The output is shaped so a vibe-coder can
paste it into a support thread without further explanation.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import sys
from importlib.metadata import PackageNotFoundError, version as _pkg_version
from pathlib import Path
from typing import Callable

import click
from rich.console import Console
from rich.table import Table

from ..api import ApiClient, ApiError
from ..config import CliConfig

console = Console()
err = Console(stderr=True)


# ── Result type ──────────────────────────────────────────────────────


_RESULT_ORDER = {"ok": 0, "warn": 1, "fail": 2}


class _Check:
    """One diagnostic. Holds the result + remediation hint so the
    output table doesn't lose context across rows."""

    def __init__(self, name: str, severity: str, summary: str, hint: str = "") -> None:
        assert severity in _RESULT_ORDER, severity
        self.name = name
        self.severity = severity
        self.summary = summary
        self.hint = hint

    @property
    def icon(self) -> str:
        return {"ok": "[green]✓[/green]",
                "warn": "[yellow]![/yellow]",
                "fail": "[red]✗[/red]"}[self.severity]


# ── Individual checks ────────────────────────────────────────────────


def _check_login() -> _Check:
    """Token present + accepted by the platform."""
    cfg = CliConfig.load()
    if not cfg.token:
        return _Check(
            "login",
            "fail",
            "no token configured",
            "Run `linkworld login --token <jwt>` to authenticate.",
        )
    try:
        me = ApiClient(cfg).me()
    except ApiError as exc:
        if exc.status in (401, 403):
            return _Check(
                "login",
                "fail",
                f"token rejected by platform ({exc.status})",
                "Token expired or revoked. Re-login: `linkworld login --token <jwt>`.",
            )
        return _Check(
            "login",
            "warn",
            f"could not reach platform: {exc}",
            "Check network / VPN; retry. The token may still be valid.",
        )
    if not me.get("publish_allowed"):
        return _Check(
            "login",
            "warn",
            f"logged in as {me.get('email','?')} (publish_allowed=false)",
            "Your account can't deploy yet. Ask a platform admin to flip "
            "publish_allowed=true on your dev account.",
        )
    return _Check(
        "login",
        "ok",
        f"logged in as {me.get('email','?')} ({cfg.api_url})",
    )


def _check_docker() -> _Check:
    """Docker daemon reachable. Required for `linkworld deploy`
    unless `--skip-build` is set."""
    if not shutil.which("docker"):
        return _Check(
            "docker",
            "fail",
            "`docker` CLI not on PATH",
            "Install Docker Desktop or run on a host with the daemon. "
            "If you only deploy via CI you can use `linkworld deploy "
            "--skip-build` and skip this.",
        )
    try:
        out = subprocess.run(
            ["docker", "info", "--format", "{{.ServerVersion}}"],
            capture_output=True, text=True, timeout=5,
        )
    except subprocess.TimeoutExpired:
        return _Check(
            "docker",
            "fail",
            "`docker info` timed out",
            "Daemon may be hung. Try `docker system info` directly.",
        )
    except OSError as exc:
        return _Check("docker", "fail", f"docker invocation failed: {exc}")
    if out.returncode != 0:
        return _Check(
            "docker",
            "fail",
            "daemon not running",
            "Start Docker Desktop or `systemctl start docker`. "
            "Falls back to `linkworld deploy --skip-build` if you push "
            "images from CI instead.",
        )
    server = (out.stdout or "").strip()
    return _Check("docker", "ok", f"daemon ok (server={server})")


def _check_ghcr_login() -> _Check:
    """Best-effort: is `docker login ghcr.io` configured?

    We don't actually push — we look at ``~/.docker/config.json``'s
    auths section. False negatives are acceptable (helper-based auth
    won't show up); a fail here is just a warn.
    """
    cfg = Path.home() / ".docker" / "config.json"
    if not cfg.exists():
        return _Check(
            "ghcr",
            "warn",
            "~/.docker/config.json missing",
            "If `linkworld deploy` fails to push, run "
            "`echo $GITHUB_PAT | docker login ghcr.io -u <you> --password-stdin`.",
        )
    try:
        import json as _json
        data = _json.loads(cfg.read_text())
    except Exception:
        return _Check(
            "ghcr",
            "warn",
            "could not parse ~/.docker/config.json",
            "If `linkworld deploy` fails to push, re-run `docker login ghcr.io`.",
        )
    auths = data.get("auths") or {}
    has_ghcr = any("ghcr.io" in k for k in auths.keys())
    has_helper = "credHelpers" in data and any(
        "ghcr" in k for k in data["credHelpers"].keys()
    )
    if has_ghcr or has_helper:
        return _Check("ghcr", "ok", "ghcr.io credential found")
    return _Check(
        "ghcr",
        "warn",
        "no ghcr.io credential in docker config",
        "Run `echo $GITHUB_PAT | docker login ghcr.io -u <you> --password-stdin` "
        "before `linkworld deploy`. Skippable if you push from CI.",
    )


def _check_sdk_version() -> _Check:
    """linkworld-sdk installed and reasonably current."""
    try:
        installed = _pkg_version("linkworld-sdk")
    except PackageNotFoundError:
        return _Check(
            "sdk",
            "warn",
            "`linkworld-sdk` not installed in this Python env",
            "Run `pip install linkworld-sdk` if you'll run the app "
            "locally. Not strictly required for `linkworld deploy`.",
        )
    # We don't enforce a minimum here — the scaffold's requirements.txt
    # does that for the runtime image. Just surface what's installed.
    return _Check("sdk", "ok", f"linkworld-sdk {installed}")


def _check_cwd_is_app() -> _Check:
    """Are we sitting in an app project root?"""
    if not Path("linkworld.app.yaml").exists():
        return _Check(
            "project",
            "warn",
            "no linkworld.app.yaml in current directory",
            "Run `linkworld init <slug>` to scaffold a new app, or "
            "`cd` into an existing project root.",
        )
    return _Check("project", "ok", "linkworld.app.yaml found")


# Anti-patterns flagged by _check_web_bundle. Each entry is
# (compiled-regex, kind, hint). The bundle's iframe runs at
# apps-cdn.linkworld.ai with CSP `connect-src 'none'` — fetch/XHR/SSE/
# WebSocket all silently fail, no error, no clue. Catching this at
# `doctor` time saves devs the 30-minute "why is my UI empty" debug.
_BUNDLE_LINT_RULES: list[tuple[re.Pattern[str], str, str]] = [
    (
        re.compile(r"\bfetch\s*\("),
        "fetch",
        "use bridge.callRoute() for own routes, bridge.tools.call() "
        "for platform tools — fetch is CSP-blocked",
    ),
    (
        re.compile(r"\bnew\s+XMLHttpRequest\b"),
        "XHR",
        "use bridge.callRoute() instead — XHR is CSP-blocked",
    ),
    (
        re.compile(r"\bnew\s+EventSource\b"),
        "EventSource",
        "SSE is CSP-blocked in the bundle. Poll via "
        "bridge.callRoute() or subscribe to platform events via "
        "bridge.events.subscribe()",
    ),
    (
        re.compile(r"\bnew\s+WebSocket\b"),
        "WebSocket",
        "WebSockets are CSP-blocked. Use bridge.callRoute() polling "
        "or platform pub/sub.",
    ),
]

# Hardcoded hex color literals in JS/CSS — flagged separately because
# many false positives (icons, SVG paths). We only warn when there's
# a ratio above ~5 hex literals AND no `--lw-` token reference, which
# is the "bundle ships its own dark theme that ignores the tenant"
# pattern. lw-ui.css imports get a free pass.
_HEX_COLOR_RE = re.compile(r"#[0-9a-fA-F]{6}\b")
_LW_VAR_RE = re.compile(r"--lw-|--_lw-|var\s*\(\s*--_?lw-")


def _check_web_bundle() -> _Check:
    """Lint web/ for anti-patterns that fail silently in the iframe.

    Top reasons new bundles "don't work":
      1. fetch() / XHR / EventSource / WebSocket — CSP blocks them.
      2. Hardcoded hex colors — ignores the tenant theme.

    Both are silent (no browser error, no platform diagnostic). This
    check is a static-grep that flags both classes.
    """
    web = Path("web")
    if not web.is_dir():
        return _Check("bundle", "ok", "no web/ — skipped (headless app)")

    targets: list[Path] = []
    for ext in (".js", ".mjs", ".cjs", ".ts", ".tsx", ".html", ".htm", ".css"):
        for p in web.rglob(f"*{ext}"):
            # Skip vendor (the SDK's own copy of bridge.js, lw-ui, etc.)
            # and any build outputs (dist/, build/, node_modules/).
            if any(part in {"vendor", "dist", "build", "node_modules"}
                   for part in p.parts):
                continue
            targets.append(p)

    if not targets:
        return _Check("bundle", "ok", "no source files in web/ (vendor-only)")

    blocking_hits: list[str] = []
    hex_files: list[tuple[Path, int]] = []
    for p in targets:
        try:
            src = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        # CSP-blocked-call rules
        for rx, kind, hint in _BUNDLE_LINT_RULES:
            for m in rx.finditer(src):
                line_no = src.count("\n", 0, m.start()) + 1
                blocking_hits.append(
                    f"{p.as_posix()}:{line_no} — {kind}() — {hint}"
                )
        # Hex-color heuristic: many hex literals + zero --lw-* refs
        # = bundle ignores the tenant theme.
        if p.suffix in {".css", ".html", ".htm", ".js", ".ts", ".mjs", ".tsx"}:
            hex_count = len(_HEX_COLOR_RE.findall(src))
            has_lw_var = bool(_LW_VAR_RE.search(src))
            if hex_count >= 5 and not has_lw_var:
                hex_files.append((p, hex_count))

    issues = []
    if blocking_hits:
        issues.append(f"{len(blocking_hits)} CSP-blocked call(s)")
    if hex_files:
        issues.append(
            f"{len(hex_files)} file(s) w/ hardcoded colors but no --lw-* tokens"
        )

    if not issues:
        return _Check("bundle", "ok", "web/ lint clean")

    summary = ", ".join(issues)
    hint_lines: list[str] = []
    for h in blocking_hits[:5]:
        hint_lines.append(h)
    if len(blocking_hits) > 5:
        hint_lines.append(f"… and {len(blocking_hits) - 5} more")
    for p, n in hex_files[:3]:
        hint_lines.append(
            f"{p.as_posix()} — {n} hex literals, no --_lw-* refs. "
            "Import vendor/sdk-browser/lw-ui.css and use --_lw-bg / "
            "--_lw-text / --_lw-border instead of hex."
        )
    if len(hex_files) > 3:
        hint_lines.append(f"… and {len(hex_files) - 3} more file(s)")
    hint_lines.append(
        "Docs: https://docs.linkworld.ai/developer/guides/app-uis"
        "#step-4--use-the-bridge",
    )
    return _Check("bundle", "warn", summary, "\n      ".join(hint_lines))


# ── Command ──────────────────────────────────────────────────────────


# @app.tool decorators that aren't mirrored in manifest.tools[] are
# silently invisible to the platform agent — chat returns
# "tool unavailable" hallucinations even though the runtime registered
# the handler. Catch at doctor time.
_APP_TOOL_DECO_RE = re.compile(
    r"""(?m)^\s*@app\.tool\s*\(\s*['"]([a-z][a-z0-9_]{2,62})['"]""",
)


def _check_app_tools_declared() -> _Check:
    """Cross-check @app.tool decorators against manifest.tools[]."""
    manifest_path = Path("linkworld.app.yaml")
    if not manifest_path.exists():
        return _Check("tools", "ok", "no manifest in CWD — skipped")

    # Python entry point is conventionally main.py at project root.
    py_path = Path("main.py")
    if not py_path.exists():
        # Try src/main.py as a fallback (some scaffolds).
        py_path = Path("src/main.py")
        if not py_path.exists():
            return _Check("tools", "ok", "no main.py — skipped (TS app or non-standard layout)")

    try:
        import yaml as _yaml
        manifest = _yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return _Check("tools", "warn", "couldn't parse linkworld.app.yaml — skipping tool check")

    declared = {
        t.get("name") for t in (manifest.get("tools") or [])
        if isinstance(t, dict) and t.get("name")
    }

    try:
        src = py_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return _Check("tools", "warn", f"couldn't read {py_path}")

    decorated: list[tuple[str, int]] = []
    for m in _APP_TOOL_DECO_RE.finditer(src):
        line_no = src.count("\n", 0, m.start()) + 1
        decorated.append((m.group(1), line_no))

    if not decorated:
        return _Check("tools", "ok", "no @app.tool decorators in main.py")

    missing = [(n, ln) for n, ln in decorated if n not in declared]
    if not missing:
        return _Check(
            "tools",
            "ok",
            f"all {len(decorated)} @app.tool decorator(s) declared in manifest",
        )

    head = missing[0]
    hint_lines = [
        f"{py_path}:{ln} — @app.tool('{name}') not in manifest.tools"
        for name, ln in missing[:5]
    ]
    if len(missing) > 5:
        hint_lines.append(f"… and {len(missing) - 5} more")
    hint_lines.append("")
    hint_lines.append("Add to linkworld.app.yaml:")
    hint_lines.append("  tools:")
    hint_lines.append(f"    - name: {head[0]}")
    hint_lines.append(f"      description: \"<short LLM-facing description>\"")
    hint_lines.append(f"      scopes_required: []  # or e.g. [\"mail.send\"]")
    hint_lines.append("")
    hint_lines.append(
        "Without the manifest entry the platform's agent runtime never "
        "sees the tool — chat returns \"tool unavailable\" at call time."
    )
    return _Check(
        "tools",
        "fail",
        f"{len(missing)} @app.tool decorator(s) missing from manifest.tools[]",
        "\n      ".join(hint_lines),
    )


_CHECKS: list[Callable[[], _Check]] = [
    _check_login,
    _check_docker,
    _check_ghcr_login,
    _check_sdk_version,
    _check_cwd_is_app,
    _check_web_bundle,
    _check_app_tools_declared,
]


@click.command(help=(
    "Diagnose the local environment. Runs the env-setup checks "
    "`linkworld deploy` would do anyway, but with actionable hints — "
    "saves a deploy round-trip when something's off (stale token, "
    "docker not running, GHCR not logged in)."
))
def doctor() -> None:
    results = [check() for check in _CHECKS]

    table = Table(show_header=True, header_style="bold")
    table.add_column("", width=3)
    table.add_column("Check", style="bold")
    table.add_column("Result")
    for r in results:
        table.add_row(r.icon, r.name, r.summary)
    console.print(table)

    # Print fix-hints below the table so the dev sees them as a
    # checklist, not buried in a column.
    blockers = [r for r in results if r.severity != "ok"]
    if blockers:
        console.print()
        for r in blockers:
            tag = {"warn": "[yellow]warn[/yellow]",
                   "fail": "[red]fail[/red]"}[r.severity]
            console.print(f"  {tag} [bold]{r.name}[/bold]: {r.summary}")
            if r.hint:
                console.print(f"    [dim]{r.hint}[/dim]")

    worst = max(_RESULT_ORDER[r.severity] for r in results)
    if worst >= _RESULT_ORDER["fail"]:
        sys.exit(1)
