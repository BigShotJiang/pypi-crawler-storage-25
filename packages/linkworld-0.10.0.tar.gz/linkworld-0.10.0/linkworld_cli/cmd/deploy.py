"""linkworld deploy + linkworld apps list/show — the deploy lifecycle."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from ..api import ApiClient, ApiError
from ..config import CliConfig

console = Console()
err = Console(stderr=True)


def _load_manifest(path: str = "linkworld.app.yaml") -> "object":
    """Use the SDK's manifest loader so SDK and CLI agree on validity."""
    try:
        from linkworld_sdk import load_manifest, ManifestError
    except ImportError:
        err.print("[red]linkworld-sdk is required (pip install linkworld-sdk).[/red]")
        sys.exit(2)

    manifest_path = Path(path)
    if not manifest_path.exists():
        err.print(f"[red]No {path} in current directory.[/red]")
        err.print("Run [bold]linkworld init <slug>[/bold] to scaffold a new app.")
        sys.exit(1)

    try:
        return load_manifest(manifest_path)
    except ManifestError as exc:
        err.print(f"[red]Manifest invalid:[/red]")
        err.print(f"[red]{exc}[/red]")
        sys.exit(1)


def _docker_build_and_push(image_url: str) -> None:
    """Best-effort local build + push. Partner can also use CI to do
    this — pass --skip-build to register a pre-pushed image."""
    console.print(f"Building [bold]{image_url}[/bold]...")
    rc = subprocess.run(
        ["docker", "build", "-t", image_url, "."], check=False,
    ).returncode
    if rc != 0:
        err.print("[red]docker build failed[/red]")
        sys.exit(rc)

    console.print(f"Pushing [bold]{image_url}[/bold]...")
    rc = subprocess.run(
        ["docker", "push", image_url], check=False,
    ).returncode
    if rc != 0:
        err.print(
            "[red]docker push failed[/red] — make sure you're logged in to GHCR:\n"
            "    echo $GITHUB_TOKEN | docker login ghcr.io -u USERNAME --password-stdin"
        )
        sys.exit(rc)


def _collect_preflight_files(manifest_path: str) -> dict[str, str]:
    """Read every text file the preflight needs to lint.

    ``linkworld.app.yaml`` is required. Beyond that, we ship every
    Python / TypeScript / YAML file in the project root (1 level
    deep) — keeps the payload bounded but covers the common cases
    of an app split across a couple of modules.
    """
    out: dict[str, str] = {}
    p = Path(manifest_path)
    if p.exists():
        out[p.name] = p.read_text(encoding="utf-8")

    root = p.parent if p.parent != Path("") else Path(".")
    extensions = {".py", ".ts", ".tsx", ".yaml", ".yml"}
    skip_names = {"node_modules", ".venv", "venv", "dist", "__pycache__"}
    skip_files = {"linkworld.eval.yaml"}  # not source — eval suite

    for entry in root.iterdir():
        if entry.name in skip_names or entry.name.startswith("."):
            continue
        if entry.is_file() and entry.suffix in extensions:
            if entry.name in skip_files:
                continue
            try:
                out[entry.name] = entry.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
    return out


def _print_preflight_issues(result: dict) -> None:
    """Render the preflight response to the terminal."""
    issues = result.get("issues") or []
    if not issues:
        console.print("[green]✓ preflight passed[/green]")
        return

    for it in issues:
        sev = it.get("severity", "info")
        colour = {"error": "red", "warning": "yellow"}.get(sev, "dim")
        loc = it.get("file") or "?"
        if it.get("line"):
            loc = f"{loc}:{it['line']}"
        console.print(f"  [{colour}]{sev}[/{colour}] [bold]{loc}[/bold] — {it.get('message','')}")
        if it.get("fix_hint"):
            console.print(f"    [dim]fix: {it['fix_hint']}[/dim]")


def _check_lw_ui_usage(manifest_path: str) -> list[dict]:
    """Local soft-warning: nudge devs (and AI agents) toward lw-ui.

    Apps with a ``web/`` directory that don't import ``lw-ui.css`` or
    don't reference any ``lw-*`` class are likely re-implementing the
    design system — which produces a "raw" look and ages badly. We
    emit warnings, not errors; nothing is blocking. The intent is
    education + discoverability, not gatekeeping.

    See ``apps/docs/src/content/docs/developer/reference/lw-ui.md``
    for what the framework offers.
    """
    p = Path(manifest_path)
    web = (p.parent if p.parent != Path("") else Path(".")) / "web"
    if not web.is_dir():
        return []  # headless app — nothing to check

    issues: list[dict] = []

    # Read every HTML file under web/ (any depth — partner may have
    # /modal/foo.html). Reject early if there are none — a web/ dir
    # with only e.g. an index.js but no markup is also valid (CDN-
    # hosted SPA with HTML elsewhere).
    html_files = list(web.rglob("*.html"))
    if not html_files:
        return []

    imports_lw_ui = False
    references_lw_class = False
    files_scanned: list[str] = []

    for f in html_files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        files_scanned.append(str(f.relative_to(web)))
        if "lw-ui.css" in text or "@linkworld_ai/sdk-browser/lw-ui.css" in text:
            imports_lw_ui = True
        # `class="...lw-..."` or `class='lw-...'` etc. — quick + dirty.
        if re.search(r'class\s*=\s*["\'][^"\']*\blw-', text):
            references_lw_class = True

    # Also scan CSS files for raw `class { background: ... }`-style
    # custom components that suggest re-implementing lw-ui. We don't
    # try to be clever — just flag if no `lw-` class shows up
    # anywhere in the bundle.
    for f in web.rglob("*.css"):
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if re.search(r'\.lw-[a-z][\w-]*', text):
            references_lw_class = True

    if not imports_lw_ui:
        issues.append({
            "severity": "warning",
            "file": files_scanned[0] if files_scanned else "web/index.html",
            "message": (
                "web/ doesn't import lw-ui.css. The platform's design "
                "system is the easiest way to ship a polished UI that "
                "matches every other Linkworld app — your bundle will "
                "look raw without it."
            ),
            "fix_hint": (
                "Add <link rel=\"stylesheet\" href=\"./vendor/sdk-browser/lw-ui.css\"> "
                "to your index.html. See "
                "https://docs.linkworld.ai/developer/reference/lw-ui/"
            ),
        })

    if imports_lw_ui and not references_lw_class:
        issues.append({
            "severity": "warning",
            "file": files_scanned[0] if files_scanned else "web/index.html",
            "message": (
                "lw-ui.css is loaded but no lw-* class is used. Consider "
                "replacing your custom classes with lw-card / lw-tab / "
                "lw-btn / lw-badge / lw-stack / lw-row primitives — "
                "they're themed, accessible, and keep your bundle "
                "consistent across tenants."
            ),
            "fix_hint": (
                "Catalog: https://docs.linkworld.ai/developer/reference/lw-ui-catalog/"
            ),
        })

    return issues


def _run_preflight(client: ApiClient, manifest_path: str) -> dict:
    """Collect local files, ship to /api/dev/preflight, render output.

    Returns the raw response dict (so callers can inspect ``valid``).
    Exits 1 if the network call itself fails — the dev should know
    they have a connectivity problem, not silently skip checks.
    """
    files = _collect_preflight_files(manifest_path)
    try:
        result = client.preflight(files)
    except ApiError as exc:
        err.print(f"[red]preflight request failed: {exc}[/red]")
        sys.exit(2)

    # Append local-only checks (lw-ui usage). These don't go through
    # the server because they're a UX nudge, not a contract test.
    local_issues = _check_lw_ui_usage(manifest_path)
    if local_issues:
        result.setdefault("issues", [])
        result["issues"].extend(local_issues)

    _print_preflight_issues(result)
    return result


def _ensure_app(client: ApiClient, manifest) -> None:
    """If the slug doesn't exist for this dev, create it. Idempotent
    server-side, so re-runs are safe."""
    try:
        client.get_app(manifest.app_id)
        return  # exists
    except ApiError as exc:
        if exc.status != 404:
            raise
    console.print(f"Creating app [bold]{manifest.app_id}[/bold]...")
    client.create_app(
        manifest.app_id,
        name=manifest.name,
        description=manifest.description,
        icon=manifest.icon,
    )


@click.command(help="Build, push, and register a new app version with the platform.")
@click.option(
    "--skip-build",
    is_flag=True,
    help="Don't run docker build/push — assume the image was already pushed (e.g. via CI).",
)
@click.option(
    "--version",
    default=None,
    help="Override the manifest's version (e.g. when deploying from CI tag). "
         "Must match the image tag.",
)
@click.option(
    "--no-promote",
    is_flag=True,
    help="Register the version without promoting it to current_version. "
         "Use to stage a release before flipping installs over.",
)
@click.option(
    "--manifest",
    default="linkworld.app.yaml",
    help="Path to the manifest YAML.",
)
@click.option(
    "--no-preflight",
    is_flag=True,
    help="Skip the preflight check (manifest validation + lint + scope-existence). "
         "Use only when the platform is unreachable — preflight catches errors that "
         "would otherwise reject the version after the image is built.",
)
@click.option(
    "--bundle",
    default=None,
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    help="Path to a built frontend bundle directory (e.g. dist/). "
         "If set, the directory is tarballed and uploaded to apps-cdn "
         "after the version is registered. The bundle becomes the "
         "iframe content the tenant sees at /apps/<slug>. Defaults to "
         "auto-detecting ./dist, then ./web; pass --bundle '' to skip.",
)
def deploy(
    skip_build: bool,
    version: str | None,
    no_promote: bool,
    manifest: str,
    no_preflight: bool,
    bundle: str | None,
) -> None:
    cfg = CliConfig.load()
    if not cfg.token:
        err.print("[yellow]Not logged in.[/yellow] Run `linkworld login --token <jwt>`.")
        sys.exit(1)

    m = _load_manifest(manifest)

    # ── Preflight (Wave 2) ──────────────────────────────────────────
    # Catches the errors most likely to reject a deploy AFTER the image
    # is built: undeclared scopes, ctx.tools.call to a tool not granted
    # by required_scopes, missing handlers for declared lifecycle hooks.
    # Costs ~200ms of HTTP round-trip; saves a multi-minute build/push
    # cycle when something's off.
    if not no_preflight:
        client = ApiClient(cfg)
        console.print("[bold]Running preflight checks…[/bold]")
        result = _run_preflight(client, manifest)
        if not result.get("valid"):
            err.print(
                f"[red]preflight failed: "
                f"{result.get('error_count', '?')} error(s).[/red] "
                f"Re-run with --no-preflight to skip (only when platform "
                f"is unreachable)."
            )
            sys.exit(1)
        if result.get("warning_count"):
            console.print(
                f"[yellow]preflight passed with "
                f"{result['warning_count']} warning(s) — review above.[/yellow]"
            )
    if version:
        # Command-line version overrides the file (CI-tag-driven flow)
        m_dict = m.model_dump(mode="json")
        m_dict["version"] = version
        # Re-validate via SDK
        from linkworld_sdk.manifest import Manifest, ManifestError
        try:
            m = Manifest.model_validate(m_dict)
        except Exception as exc:  # ValidationError
            err.print(f"[red]--version override produced invalid manifest: {exc}[/red]")
            sys.exit(1)

    # Image URL — the manifest's `runtime.image` is the canonical
    # image for this version. If the manifest carries a tag in the
    # URL we use it as-is; otherwise we append `:<version>`.
    image_url = m.runtime.image
    if ":" not in image_url.rsplit("/", 1)[-1]:
        image_url = f"{image_url}:{m.version}"

    if not skip_build:
        _docker_build_and_push(image_url)
    else:
        console.print(f"[dim]Skipping build (assuming {image_url} already pushed)[/dim]")

    # ApiClient may already exist from preflight; re-init when skipped.
    if no_preflight:
        client = ApiClient(cfg)

    # whoami / publish_allowed gate
    try:
        me_data = client.me()
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)
    if not me_data.get("publish_allowed"):
        err.print(
            "[red]Your dev account is not allowed to publish yet.[/red]\n"
            "Contact a platform admin to flip publish_allowed=true."
        )
        sys.exit(2)

    # Resolve bundle BEFORE register-version so we can tell the server
    # whether a bundle upload is coming. With promote=True AND
    # bundle_pending=True the server defers the current_version_id flip
    # until the bundle is uploaded — closes the "Headless App" window
    # where tenants would install a NULL-bundle row (see migration 292).
    bundle_dir = _resolve_bundle_dir(bundle)
    bundle_pending = bundle_dir is not None and not no_promote

    try:
        _ensure_app(client, m)
        ver = client.create_version(
            m.app_id,
            version=m.version,
            image_url=image_url,
            manifest=m.model_dump(mode="json"),
            promote=not no_promote,
            bundle_pending=bundle_pending,
        )
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    console.print()
    console.print(f"[green]✓ Registered {m.app_id} v{ver['version']}[/green]")
    console.print(f"  image:   [dim]{ver['image_url']}[/dim]")
    console.print(f"  status:  {ver['status']}")
    if not no_promote:
        if bundle_pending:
            console.print(
                f"  promote: [dim]deferred — will fire after bundle upload[/dim]"
            )
        else:
            console.print(f"  promoted to current_version")

    # ── Phase-3 M2a: optional frontend bundle upload ──────────────────
    if bundle_dir:
        console.print()
        console.print(f"[bold]Uploading frontend bundle from {bundle_dir}…[/bold]")
        try:
            tarball = _tar_bundle_dir(bundle_dir)
        except _BundleError as exc:
            err.print(f"[red]bundle prep failed: {exc}[/red]")
            sys.exit(2)
        try:
            up = client.upload_bundle(m.app_id, m.version, tarball)
        except ApiError as exc:
            err.print(f"[red]{exc}[/red]")
            sys.exit(2)
        console.print(
            f"[green]✓ Uploaded bundle ({up.get('files_uploaded')} files, "
            f"{up.get('total_bytes')} bytes)[/green]"
        )
        console.print(f"  bundle:  [dim]{up.get('bundle_url')}[/dim]")
        if bundle_pending:
            console.print(f"  promoted to current_version")
    else:
        console.print(f"  [dim]no frontend bundle (./dist not found, --bundle not set)[/dim]")

    # ── M295: optional doc-template defaults upload ───────────────────
    # If the repo has ./defaults/templates/*.json, ship them with the
    # version so activation can seed them into the tenant's
    # linkworld_doc_templates at install time. Skipped silently when
    # the directory is empty or missing.
    templates = _load_default_templates(Path.cwd())
    if templates:
        console.print()
        console.print(
            f"[bold]Uploading {len(templates)} doc-template default(s)…[/bold]"
        )
        try:
            client.upload_default_templates(m.app_id, m.version, templates)
        except ApiError as exc:
            err.print(f"[red]{exc}[/red]")
            sys.exit(2)
        console.print(
            f"[green]✓ Attached {len(templates)} template(s) "
            f"({', '.join(sorted(t['slug'] for t in templates))})[/green]"
        )

    console.print()
    console.print("Tenants can now activate this app via their Apps page.")


# ── Doc-template defaults (M295) ──────────────────────────────────────


def _load_default_templates(repo_root: Path) -> list[dict]:
    """Load doc-template defaults the dev wants shipped with this version.

    Looks for ``<repo>/defaults/templates/*.json``. Each file is one
    template object (slug, name, sections, ...). Files are sorted by
    filename to keep the upload order deterministic — easier to spot
    drift in audit logs.

    Returns ``[]`` when the directory is missing or empty. Errors
    parsing individual files raise, since a half-shipped template
    set is worse than a missing one.
    """
    import json
    tpl_dir = repo_root / "defaults" / "templates"
    if not tpl_dir.is_dir():
        return []
    templates: list[dict] = []
    for path in sorted(tpl_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise SystemExit(
                f"defaults/templates/{path.name}: invalid JSON: {exc}"
            )
        if not isinstance(data, dict):
            raise SystemExit(
                f"defaults/templates/{path.name}: top-level must be an object"
            )
        templates.append(data)
    return templates


# ── Bundle helpers ────────────────────────────────────────────────────


class _BundleError(Exception):
    pass


def _resolve_bundle_dir(bundle_arg: str | None) -> Path | None:
    """Decide which directory to tarball, if any.

    Resolution rules:
      - explicit empty string ("--bundle '' ") → skip bundle upload
      - explicit path → use it (must exist; click already verified)
      - None (default) → auto-detect ./dist, then ./web; skip if neither
        exists. ``dist/`` is the conventional output of a build step
        (Vite/webpack/etc.); ``web/`` is what `linkworld init` scaffolds
        for hand-written static bundles.
    """
    if bundle_arg == "":
        return None
    if bundle_arg is not None:
        return Path(bundle_arg).resolve()
    for candidate in ("dist", "web"):
        auto = Path(candidate).resolve()
        if auto.is_dir():
            return auto
    return None


def _tar_bundle_dir(directory: Path) -> bytes:
    """Tarball + gzip the directory contents (NOT the directory itself).

    The platform expects ``index.html`` at the root of the tarball;
    if the directory contains ``dist/index.html``, the resulting
    tarball must have ``index.html`` at the root, not ``dist/index.html``.
    We achieve that by adding each entry under its name relative to
    *directory*.
    """
    import io
    import tarfile
    if not directory.is_dir():
        raise _BundleError(f"{directory} is not a directory")
    has_index = (directory / "index.html").is_file()
    if not has_index:
        raise _BundleError(
            f"{directory}/index.html not found — bundle must have an "
            "index.html at the root"
        )
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        # Walk explicitly so we control member names (no "./" prefix).
        for path in sorted(directory.rglob("*")):
            # Skip symlinks — even ones pointing inside the bundle
            # dir. Following a symlink would tarball whatever's at
            # the target, including potentially /etc/passwd if a
            # build process accidentally created such a link. The
            # platform's bundle_upload also rejects symlinks, but
            # failing locally gives a clearer error and avoids a
            # round-trip on a broken upload.
            if path.is_symlink():
                continue
            if not path.is_file():
                continue
            # Defense in depth: ensure the resolved target is still
            # inside the source directory. Catches build output that
            # somehow links outside `directory`.
            try:
                resolved = path.resolve(strict=True)
                resolved.relative_to(directory.resolve())
            except (ValueError, OSError):
                continue
            arcname = str(path.relative_to(directory))
            tar.add(path, arcname=arcname, recursive=False)
    raw = buf.getvalue()
    # Ten MB cap is the platform's limit; warn before they hit it.
    if len(raw) > 10 * 1024 * 1024:
        raise _BundleError(
            f"bundle tarball is {len(raw)} bytes, max is 10 MB — "
            "trim assets or split into a separate static host"
        )
    return raw


# ── linkworld apps … ─────────────────────────────────────────────────


@click.group(help="Manage apps owned by the current dev account.")
def apps() -> None:
    pass


@apps.command("list", help="List all apps owned by you.")
def apps_list() -> None:
    cfg = CliConfig.load()
    try:
        rows = ApiClient(cfg).list_apps()
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    if not rows:
        console.print("[dim]No apps yet. Run `linkworld init <slug>` to start.[/dim]")
        return

    t = Table(show_lines=False)
    t.add_column("slug", style="bold")
    t.add_column("name")
    t.add_column("status")
    t.add_column("current version")
    for r in rows:
        t.add_row(
            r["slug"], r["name"], r.get("status", ""),
            r.get("current_version") or "[dim]—[/dim]",
        )
    console.print(t)


@apps.command("show", help="Show an app's details + versions.")
@click.argument("slug")
def apps_show(slug: str) -> None:
    cfg = CliConfig.load()
    client = ApiClient(cfg)
    try:
        app = client.get_app(slug)
        versions = client.list_versions(slug)
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    console.print(f"[bold]{app['slug']}[/bold] — {app['name']}")
    console.print(f"  [dim]{app['description']}[/dim]")
    console.print(f"  status:           {app['status']}")
    console.print(f"  current version:  {app.get('current_version') or '—'}")
    console.print()
    if not versions:
        console.print("[dim]No versions yet.[/dim]")
        return
    t = Table()
    t.add_column("version", style="bold")
    t.add_column("status")
    t.add_column("build")
    t.add_column("deployed")
    t.add_column("image")
    for v in versions:
        t.add_row(
            v["version"], v["status"], v["build_status"],
            v["deployed_at"][:19], v["image_url"],
        )
    console.print(t)


@click.command(
    help=(
        "Force-upgrade tenant installs of an app to its current published "
        "version. Bypasses per-install upgrade_policy — use this in dev "
        "to push a freshly-published fix to your test tenant(s) without "
        "waiting for auto-upgrade. Requires that you own the app."
    ),
)
@click.argument("slug")
@click.option(
    "--target-version",
    default=None,
    help="Pin to a specific published version. Default: current_version_id.",
)
@click.option(
    "--tenant",
    "tenant_id",
    default=None,
    help="Restrict to a single tenant UUID. Default: all active installs.",
)
@click.option(
    "--force-grant-new-scopes",
    is_flag=True,
    default=False,
    help=(
        "Bypass the scope-expansion-needs-consent guard. Without this, "
        "upgrades that introduce previously-ungranted scopes return "
        "'needs_consent' and the tenant must re-activate via the UI."
    ),
)
def upgrade(
    slug: str,
    target_version: Optional[str],
    tenant_id: Optional[str],
    force_grant_new_scopes: bool,
) -> None:
    cfg = CliConfig.load()
    client = ApiClient(cfg)
    try:
        result = client.upgrade_tenants(
            slug,
            target_version=target_version,
            tenant_id=tenant_id,
            force_grant_new_scopes=force_grant_new_scopes,
        )
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    target = result.get("target_version", "?")
    upgraded = result.get("upgraded_tenant_count", 0)
    skipped = result.get("skipped_tenant_count", 0)
    failed = result.get("failed_tenant_count", 0)
    console.print(
        f"[bold]{slug}[/bold] → [green]{target}[/green]: "
        f"upgraded={upgraded} skipped={skipped} failed={failed}",
    )
    details = result.get("details") or []
    if details:
        t = Table(show_lines=False)
        t.add_column("tenant", style="dim")
        t.add_column("status")
        t.add_column("error")
        for d in details:
            status = d.get("status", "")
            colour = (
                "green" if status == "upgraded"
                else "yellow" if status == "noop"
                else "red"
            )
            t.add_row(
                d.get("tenant_prefix", ""),
                f"[{colour}]{status}[/{colour}]",
                d.get("error") or "",
            )
        console.print(t)
    if failed:
        sys.exit(2)


# ── linkworld lint ───────────────────────────────────────────────────


@click.command(
    help=(
        "Run preflight checks (manifest validation, lint, scope-existence) "
        "without deploying. Same checks `linkworld deploy` runs — fast feedback "
        "while you iterate on the manifest."
    ),
)
@click.option(
    "--manifest",
    default="linkworld.app.yaml",
    help="Path to the manifest YAML.",
)
def lint(manifest: str) -> None:
    cfg = CliConfig.load()
    if not cfg.token:
        err.print("[yellow]Not logged in.[/yellow] Run `linkworld login --token <jwt>`.")
        sys.exit(1)
    client = ApiClient(cfg)
    result = _run_preflight(client, manifest)
    if not result.get("valid"):
        sys.exit(1)
