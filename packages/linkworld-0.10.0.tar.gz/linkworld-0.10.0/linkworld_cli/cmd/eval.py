"""linkworld eval — run scenario regression tests against the local app.

Like pytest for agents. The developer writes a ``linkworld.eval.yaml``
declaring scenarios (inputs and expectations); this command loads the
app's ``main.py`` in-process, drives each scenario through a
``TestClient``, and reports pass/fail.

Quick example:

    # linkworld.eval.yaml
    scenarios:
      - name: classifies inbound email
        given:
          tools:
            crm_lookup: { ok: true, result: { customer: "Acme" } }
        when:
          type: inbound
          message_text: "I have a question about order 42"
        then:
          tool_calls:
            - name: crm_lookup
              args_match: { order_id: "42" }

    $ linkworld eval

The runner mocks all ``ctx.tools`` calls from ``given.tools``. Tools
the handler calls without a wired mock raise ``ToolCallError`` —
intentional, so missing wiring shows up loudly.

Exit codes: 0 on all-pass, 1 on any scenario failure, 2 on config
error (bad YAML, missing main.py, etc).
"""

from __future__ import annotations

import asyncio
import importlib.util
import json
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import click
from rich.console import Console
from rich.table import Table


console = Console()
err = Console(stderr=True)


# ── Result types ────────────────────────────────────────────────────


@dataclass
class AssertionFailure:
    field: str  # dotted path identifying which expectation failed
    expected: Any
    actual: Any
    note: str = ""


@dataclass
class ScenarioResult:
    name: str
    ok: bool
    duration_ms: float
    failures: list[AssertionFailure] = field(default_factory=list)
    error: Optional[str] = None  # set if scenario blew up before assertions
    tool_calls: list[tuple[str, dict]] = field(default_factory=list)


# ── App loading ─────────────────────────────────────────────────────


def _load_app(main_path: Path):
    """Import ``main.py`` as a module and return the ``App`` instance.

    Looks for a module-level attribute named ``app`` of type ``App``.
    Aborts cleanly if anything is off — we don't want partner-code
    imports to leak ugly tracebacks here.
    """
    if not main_path.is_file():
        err.print(f"[red]No {main_path.name} found at {main_path}[/red]")
        err.print(
            "[dim]Pass --main <path> or run from a directory containing your app's "
            "entry module.[/dim]"
        )
        sys.exit(2)

    spec = importlib.util.spec_from_file_location("_lw_app_under_eval", main_path)
    if spec is None or spec.loader is None:
        err.print(f"[red]Could not load {main_path}[/red]")
        sys.exit(2)

    # Ensure the app module's local imports work — add its dir to sys.path.
    parent = str(main_path.parent.resolve())
    if parent not in sys.path:
        sys.path.insert(0, parent)

    # Force LOCAL mode so app.run() (if called at module load) doesn't
    # accidentally try to talk to the platform during import. We don't
    # actually call app.run() here — but partner code that has a
    # `if __name__ == "__main__": app.run()` guard is fine; module
    # import alone won't hit that branch.
    os.environ["LINKWORLD_LOCAL"] = "1"

    # Switch CWD to the app dir for the duration of the import — matches
    # how `python main.py` would run and lets manifest loaders that take
    # relative paths (``load_manifest("linkworld.app.yaml")``) resolve
    # correctly.
    saved_cwd = os.getcwd()
    os.chdir(parent)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    except Exception as exc:
        err.print(f"[red]Import of {main_path.name} failed:[/red] {exc!r}")
        sys.exit(2)
    finally:
        os.chdir(saved_cwd)

    from linkworld_sdk import App  # imported lazily to keep CLI startup fast

    candidates = [
        getattr(module, name) for name in dir(module)
        if isinstance(getattr(module, name, None), App)
    ]
    if not candidates:
        err.print(
            f"[red]{main_path.name} has no ``App`` instance at module level.[/red]"
        )
        err.print("[dim]Expected: app = App(load_manifest('linkworld.app.yaml'))[/dim]")
        sys.exit(2)
    if len(candidates) > 1:
        err.print(f"[yellow]{main_path.name} has multiple App instances; using the first.[/yellow]")
    return candidates[0]


# ── YAML loading ────────────────────────────────────────────────────


def _load_eval_file(path: Path) -> dict:
    if not path.is_file():
        err.print(f"[red]Eval file not found: {path}[/red]")
        sys.exit(2)
    try:
        import yaml  # bundled with linkworld-sdk
    except ImportError:
        err.print("[red]PyYAML missing — install ``linkworld-sdk`` (it bundles yaml).[/red]")
        sys.exit(2)
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        err.print(f"[red]Failed to parse {path}: {exc}[/red]")
        sys.exit(2)
    if not isinstance(data, dict):
        err.print(f"[red]{path} must be a YAML mapping at the top level.[/red]")
        sys.exit(2)
    scenarios = data.get("scenarios")
    if not isinstance(scenarios, list) or not scenarios:
        err.print(f"[red]{path}: missing or empty `scenarios` list.[/red]")
        sys.exit(2)
    return data


# ── Scenario runner ─────────────────────────────────────────────────


def _subset_match(expected: Any, actual: Any) -> bool:
    """Recursive subset match — every key in ``expected`` must appear
    in ``actual`` with an equal-or-subset value. Lists must match
    length and element-wise (each element subset of the corresponding
    actual element). Useful for ``args_match`` style assertions where
    partner code may include extra args we don't care about.
    """
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            return False
        for k, v in expected.items():
            if k not in actual:
                return False
            if not _subset_match(v, actual[k]):
                return False
        return True
    if isinstance(expected, list):
        if not isinstance(actual, list) or len(expected) != len(actual):
            return False
        return all(_subset_match(e, a) for e, a in zip(expected, actual))
    return expected == actual


async def _run_scenario(app: Any, scenario: dict) -> ScenarioResult:
    from linkworld_sdk import (
        MockAgent, MockApps, MockEvents, MockRooms, MockSecrets,
        MockTeam, MockTools, ToolCallError,
    )
    from linkworld_sdk.testing import TestClient

    name = str(scenario.get("name") or "<unnamed>")

    # Build mocks from `given.*` so each scenario has its own clean state.
    given = scenario.get("given") or {}
    tools = MockTools()
    for tool_name, response in (given.get("tools") or {}).items():
        # response is wired verbatim — see MockTools.set_response;
        # supports {ok, result, ...} shapes.
        tools.set_response(tool_name, response)
    secrets = MockSecrets(values=given.get("secrets") or {})

    # given.agents — map of agent_slug → response dict
    # ({text, data?, model?, input_tokens?, output_tokens?}).
    # Use slug "default" or "__any__" to match calls without an
    # explicit ``agent=`` arg / any slug.
    agent = MockAgent()
    for slug, resp in (given.get("agents") or {}).items():
        agent.set_response(slug, resp if isinstance(resp, dict) else {"text": str(resp)})

    # given.team — map of caller_agent → membership list (for
    # platform-side enforcement simulation) plus per-target responses.
    team_membership: dict[str, list[str]] = {}
    team_responses: dict[str, dict] = {}
    for k, v in (given.get("team") or {}).items():
        if k == "_membership" and isinstance(v, dict):
            team_membership = {
                str(caller): list(targets) for caller, targets in v.items()
            }
        else:
            team_responses[k] = v if isinstance(v, dict) else {"text": str(v)}
    team = MockTeam(team_membership=team_membership or None)
    for slug, resp in team_responses.items():
        team.set_response(slug, resp)

    # given.apps — map of "app/slug" → response dict
    apps_mock = MockApps()
    for key, resp in (given.get("apps") or {}).items():
        apps_mock.set_response(key, resp if isinstance(resp, dict) else {"text": str(resp)})

    # given.events.wires — map of event_name → wire_count (for emit
    # result simulation). 0 = no subscribers (no-op).
    wire_counts = {
        str(k): int(v)
        for k, v in ((given.get("events") or {}).get("wires") or {}).items()
    }
    events = MockEvents(wire_counts=wire_counts)

    client = TestClient(
        app,
        tools=tools, secrets=secrets,
        agent=agent, team=team, apps=apps_mock,
        events=events,
    )

    when = scenario.get("when") or {}
    when_type = str(when.get("type") or "").lower()

    t0 = time.perf_counter()
    handler_returned: Any = None
    handler_error: Optional[Exception] = None
    try:
        if when_type == "inbound":
            await client.simulate_inbound(
                tenant_id=when.get("tenant_id", "t-eval"),
                user_id=when.get("user_id", "u-eval"),
                message_text=when.get("message_text", ""),
                channel=when.get("channel", "web"),
                modality=when.get("modality", "text"),
                channel_thread_id=when.get("channel_thread_id", "thread-eval"),
                attachments=when.get("attachments") or [],
            )
        elif when_type == "schedule":
            sched = when.get("schedule_name") or when.get("name")
            if not sched:
                return ScenarioResult(
                    name=name, ok=False, duration_ms=0.0,
                    error="schedule scenario missing `when.schedule_name`",
                )
            await client.simulate_schedule(sched, tenant_id=when.get("tenant_id", "t-eval"))
        elif when_type == "tool":
            tool = when.get("tool_name") or when.get("name")
            if not tool:
                return ScenarioResult(
                    name=name, ok=False, duration_ms=0.0,
                    error="tool scenario missing `when.tool_name`",
                )
            handler_returned = await client.call_tool(
                tool,
                tenant_id=when.get("tenant_id", "t-eval"),
                user_id=when.get("user_id", "u-eval"),
                **(when.get("args") or {}),
            )
        elif when_type == "event":
            ev_name = when.get("event_name") or when.get("name")
            if not ev_name:
                return ScenarioResult(
                    name=name, ok=False, duration_ms=0.0,
                    error="event scenario missing `when.event_name`",
                )
            await client.simulate_event(
                ev_name,
                when.get("payload") or {},
                emitter_app_id=when.get("emitter_app_id", "test-emitter"),
                target_agent_slug=when.get("target_agent_slug", ""),
                tenant_id=when.get("tenant_id", "t-eval"),
            )
        elif when_type == "install":
            await client.simulate_install(tenant_id=when.get("tenant_id", "t-eval"))
        elif when_type == "uninstall":
            await client.simulate_uninstall(tenant_id=when.get("tenant_id", "t-eval"))
        elif when_type == "user_added":
            await client.simulate_user_added(
                tenant_id=when.get("tenant_id", "t-eval"),
                user_id=when.get("user_id", "u-eval-new"),
            )
        else:
            return ScenarioResult(
                name=name, ok=False, duration_ms=0.0,
                error=f"unknown `when.type`: {when_type!r}",
            )
    except ToolCallError as exc:
        handler_error = exc
    except Exception as exc:
        # Partner code blew up. That's a scenario failure unless the
        # spec explicitly expects it (then.handler_raises).
        handler_error = exc

    duration_ms = (time.perf_counter() - t0) * 1000.0

    failures: list[AssertionFailure] = []
    then = scenario.get("then") or {}

    # If the handler raised but the spec didn't expect it → fail.
    expected_raise = then.get("handler_raises")
    if handler_error is not None and not expected_raise:
        return ScenarioResult(
            name=name,
            ok=False,
            duration_ms=duration_ms,
            error=f"{type(handler_error).__name__}: {handler_error}",
            tool_calls=tools.calls,
        )
    if expected_raise:
        if handler_error is None:
            failures.append(AssertionFailure(
                field="then.handler_raises",
                expected=expected_raise,
                actual="<no exception>",
            ))
        else:
            etype = type(handler_error).__name__
            if isinstance(expected_raise, dict):
                want_type = expected_raise.get("type")
                if want_type and want_type != etype:
                    failures.append(AssertionFailure(
                        field="then.handler_raises.type",
                        expected=want_type, actual=etype,
                    ))
                want_match = expected_raise.get("message_contains")
                if want_match and want_match not in str(handler_error):
                    failures.append(AssertionFailure(
                        field="then.handler_raises.message_contains",
                        expected=want_match, actual=str(handler_error),
                    ))
            elif isinstance(expected_raise, str):
                if expected_raise != etype:
                    failures.append(AssertionFailure(
                        field="then.handler_raises",
                        expected=expected_raise, actual=etype,
                    ))

    # tool_calls — ordered subset match
    expected_tool_calls = then.get("tool_calls")
    if expected_tool_calls is not None:
        actual_calls = tools.calls
        if len(expected_tool_calls) > len(actual_calls):
            failures.append(AssertionFailure(
                field="then.tool_calls.length",
                expected=len(expected_tool_calls),
                actual=len(actual_calls),
                note=f"saw {[c[0] for c in actual_calls]}",
            ))
        else:
            for i, expected in enumerate(expected_tool_calls):
                if i >= len(actual_calls):
                    break
                actual_name, actual_args = actual_calls[i]
                expected_name = expected.get("name") if isinstance(expected, dict) else None
                if expected_name and expected_name != actual_name:
                    failures.append(AssertionFailure(
                        field=f"then.tool_calls[{i}].name",
                        expected=expected_name, actual=actual_name,
                    ))
                expected_args = (expected or {}).get("args_match")
                if expected_args is not None and not _subset_match(expected_args, actual_args):
                    failures.append(AssertionFailure(
                        field=f"then.tool_calls[{i}].args_match",
                        expected=expected_args, actual=actual_args,
                    ))

    # tool_calls_count — exact count
    if "tool_calls_count" in then:
        want_count = int(then["tool_calls_count"])
        if want_count != len(tools.calls):
            failures.append(AssertionFailure(
                field="then.tool_calls_count",
                expected=want_count, actual=len(tools.calls),
            ))

    # tool_calls_include — unordered subset (each expected pattern must
    # match at least one actual call)
    for j, expected in enumerate(then.get("tool_calls_include") or []):
        ename = expected.get("name") if isinstance(expected, dict) else None
        eargs = (expected or {}).get("args_match")
        matched = False
        for actual_name, actual_args in tools.calls:
            if ename and ename != actual_name:
                continue
            if eargs is not None and not _subset_match(eargs, actual_args):
                continue
            matched = True
            break
        if not matched:
            failures.append(AssertionFailure(
                field=f"then.tool_calls_include[{j}]",
                expected=expected, actual=tools.calls,
            ))

    # handler_returns — subset match for tool-type scenarios
    if "handler_returns" in then:
        if not _subset_match(then["handler_returns"], handler_returned):
            failures.append(AssertionFailure(
                field="then.handler_returns",
                expected=then["handler_returns"], actual=handler_returned,
            ))

    return ScenarioResult(
        name=name,
        ok=not failures,
        duration_ms=duration_ms,
        failures=failures,
        tool_calls=tools.calls,
    )


# ── Reporting ───────────────────────────────────────────────────────


def _print_pretty(results: list[ScenarioResult]) -> None:
    table = Table(show_header=True, header_style="bold")
    table.add_column("", width=2)
    table.add_column("Scenario")
    table.add_column("Time", justify="right")
    table.add_column("Detail")

    for r in results:
        if r.ok:
            mark, style, detail = "✓", "green", f"{len(r.tool_calls)} tool call(s)"
        else:
            mark, style = "✗", "red"
            if r.error:
                detail = f"error: {r.error}"
            elif r.failures:
                detail = "\n".join(
                    f"{f.field}: expected {f.expected!r}, got {f.actual!r}"
                    + (f"  ({f.note})" if f.note else "")
                    for f in r.failures
                )
            else:
                detail = "?"
        table.add_row(
            f"[{style}]{mark}[/{style}]",
            r.name,
            f"{r.duration_ms:.1f} ms",
            detail,
        )
    console.print(table)
    passed = sum(1 for r in results if r.ok)
    failed = len(results) - passed
    summary = f"\n  [bold]{passed}[/bold] passed, [bold]{failed}[/bold] failed"
    if failed:
        console.print(f"[red]{summary}[/red]")
    else:
        console.print(f"[green]{summary}[/green]")


def _write_junit(results: list[ScenarioResult], path: Path) -> None:
    """Minimal JUnit XML — the format CI systems (GitHub Actions, etc.)
    parse to render test results. Stays stdlib-only.
    """
    import xml.etree.ElementTree as ET

    suite = ET.Element("testsuite", attrib={
        "name": "linkworld-eval",
        "tests": str(len(results)),
        "failures": str(sum(1 for r in results if not r.ok)),
        "time": f"{sum(r.duration_ms for r in results) / 1000.0:.3f}",
    })
    for r in results:
        case = ET.SubElement(suite, "testcase", attrib={
            "name": r.name,
            "time": f"{r.duration_ms / 1000.0:.3f}",
        })
        if not r.ok:
            failure = ET.SubElement(case, "failure", attrib={
                "message": r.error or "scenario assertion failed",
            })
            if r.failures:
                failure.text = "\n".join(
                    f"{f.field}: expected {f.expected!r}, got {f.actual!r}"
                    for f in r.failures
                )
            elif r.error:
                failure.text = r.error
    tree = ET.ElementTree(suite)
    path.write_bytes(ET.tostring(suite, encoding="utf-8", xml_declaration=True))


def _write_json(results: list[ScenarioResult], path: Path) -> None:
    payload = {
        "scenarios": [
            {
                "name": r.name,
                "ok": r.ok,
                "duration_ms": r.duration_ms,
                "error": r.error,
                "failures": [
                    {"field": f.field, "expected": f.expected, "actual": f.actual,
                     "note": f.note}
                    for f in r.failures
                ],
                "tool_calls": [{"name": n, "args": a} for n, a in r.tool_calls],
            }
            for r in results
        ],
        "summary": {
            "total": len(results),
            "passed": sum(1 for r in results if r.ok),
            "failed": sum(1 for r in results if not r.ok),
        },
    }
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


# ── CLI command ─────────────────────────────────────────────────────


@click.command(
    help="Run scenario regression tests against your app (linkworld.eval.yaml).",
)
@click.argument("eval_file", type=click.Path(path_type=Path), default="linkworld.eval.yaml")
@click.option("--main", "main_path", type=click.Path(path_type=Path),
              default="main.py",
              help="Path to your app's entry module exporting an App instance.")
@click.option("--filter", "name_filter", default=None,
              help="Run only scenarios whose name contains this substring.")
@click.option("--junit", "junit_path", type=click.Path(path_type=Path), default=None,
              help="Write JUnit XML to this path for CI consumption.")
@click.option("--json", "json_path", type=click.Path(path_type=Path), default=None,
              help="Write a JSON report to this path.")
@click.option("--quiet", is_flag=True,
              help="Suppress the per-scenario table; print only the summary.")
def eval_cmd(
    eval_file: Path,
    main_path: Path,
    name_filter: Optional[str],
    junit_path: Optional[Path],
    json_path: Optional[Path],
    quiet: bool,
) -> None:
    main_path = main_path.resolve()
    eval_file = eval_file.resolve()

    data = _load_eval_file(eval_file)
    app = _load_app(main_path)

    scenarios = data["scenarios"]
    if name_filter:
        scenarios = [s for s in scenarios if name_filter in str(s.get("name", ""))]
        if not scenarios:
            err.print(f"[yellow]No scenarios match filter {name_filter!r}.[/yellow]")
            sys.exit(0)

    async def _run_all() -> list[ScenarioResult]:
        out: list[ScenarioResult] = []
        for sc in scenarios:
            out.append(await _run_scenario(app, sc))
        return out

    results = asyncio.run(_run_all())

    if not quiet:
        _print_pretty(results)
    else:
        passed = sum(1 for r in results if r.ok)
        failed = len(results) - passed
        if failed:
            console.print(f"[red]{passed} passed, {failed} failed[/red]")
        else:
            console.print(f"[green]{passed} passed[/green]")

    if junit_path:
        _write_junit(results, junit_path.resolve())
        console.print(f"[dim]JUnit report → {junit_path}[/dim]")
    if json_path:
        _write_json(results, json_path.resolve())
        console.print(f"[dim]JSON report → {json_path}[/dim]")

    sys.exit(0 if all(r.ok for r in results) else 1)


# Click 8 reserves ``eval`` as a non-name in some contexts; expose the
# command function under a stable attribute. The registration in
# main.py imports ``eval_cmd``.
