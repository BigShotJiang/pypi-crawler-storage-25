"""linkworld init — scaffold a new partner-app repo."""

from __future__ import annotations

import re
import sys
from importlib.resources import files
from pathlib import Path
from typing import Iterable

import click
from rich.console import Console

console = Console()
err = Console(stderr=True)


_SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{1,62}[a-z0-9]$")


def _render(text: str, ctx: dict[str, str]) -> str:
    """Tiny moustache-style template substitution. We avoid Jinja to
    keep dependencies minimal — the template surface is small."""
    out = text
    for k, v in ctx.items():
        out = out.replace(f"{{{{{k}}}}}", v)
    return out


_TEMPLATE_DIRS: dict[str, str] = {
    "python": "python-app",
    "typescript": "typescript-app",
}


def _template_files(lang: str) -> Iterable[tuple[Path, str]]:
    """Yield (path, rel_posix) pairs inside the bundled template dir.

    Recurses into subdirectories so e.g. ``web/index.html.tmpl`` is
    written under ``<target>/web/index.html``. ``rel_posix`` is the
    POSIX-style path relative to the language template root —
    callers strip the ``.tmpl`` suffix.
    """
    base = files("linkworld_cli").joinpath("templates", _TEMPLATE_DIRS[lang])

    def _walk(root, prefix: str = "") -> Iterable[tuple[Path, str]]:
        for entry in root.iterdir():
            rel = f"{prefix}/{entry.name}" if prefix else entry.name
            if entry.is_dir():
                yield from _walk(entry, rel)
            else:
                yield entry, rel

    yield from _walk(base)


_NEXT_STEPS: dict[str, list[str]] = {
    "python": [
        "pip install -r requirements.txt",
        "LINKWORLD_LOCAL=1 python main.py",
    ],
    "typescript": [
        "npm install",
        "npm run dev",
    ],
}


@click.command(help="Scaffold a new Linkworld app in a fresh directory.")
@click.argument("slug")
@click.option("--name", default=None, help="Display name (defaults to a Title Case slug).")
@click.option("--description", default="", help="One-line description.")
@click.option(
    "--lang",
    type=click.Choice(["python", "typescript"]),
    default="python",
    show_default=True,
    help="SDK language for the scaffold.",
)
@click.option(
    "--github-owner",
    default="your-org",
    help="GitHub user/org for the GHCR image URL in the manifest.",
)
@click.option(
    "--directory",
    default=None,
    help="Target directory (default: ./<slug>). Must not exist.",
)
def init(
    slug: str,
    name: str | None,
    description: str,
    lang: str,
    github_owner: str,
    directory: str | None,
) -> None:
    if not _SLUG_RE.match(slug):
        err.print(f"[red]invalid slug '{slug}'[/red]")
        err.print("must be lowercase, hyphenated, 3-64 chars, start with a letter, end with letter/digit")
        sys.exit(1)

    target = Path(directory or slug).resolve()
    if target.exists():
        err.print(f"[red]target directory already exists: {target}[/red]")
        sys.exit(1)

    display_name = name or " ".join(w.capitalize() for w in slug.split("-"))
    desc = description.strip() or f"A Linkworld app called {display_name}."

    ctx = {
        "slug": slug,
        "name": display_name,
        "description": desc,
        "github_owner": github_owner,
    }

    target.mkdir(parents=True)
    (target / ".github").mkdir()
    (target / ".github" / "workflows").mkdir()

    written: list[Path] = []
    for entry, rel in _template_files(lang):
        if not entry.is_file():
            continue
        # File names end with `.tmpl` — strip it. `deploy.yml.tmpl` is
        # the GitHub Actions workflow and goes under .github/workflows/.
        body = entry.read_text(encoding="utf-8")
        rendered = _render(body, ctx)

        if rel == "deploy.yml.tmpl":
            dest = target / ".github" / "workflows" / "deploy.yml"
        else:
            dest_rel = rel.replace(".tmpl", "")
            dest = target / dest_rel
            dest.parent.mkdir(parents=True, exist_ok=True)

        dest.write_text(rendered, encoding="utf-8")
        written.append(dest)

    console.print(f"[green]Created {target}[/green] ({lang})")
    for p in written:
        console.print(f"  • [dim]{p.relative_to(target)}[/dim]")
    console.print()
    console.print("Next steps:")
    console.print(f"  [bold]cd {target.name}[/bold]")
    for step in _NEXT_STEPS[lang]:
        console.print(f"  {step}")
    console.print()
    console.print("When ready:")
    console.print("  linkworld login --token <jwt>")
    console.print("  git tag v0.1.0 && git push --tags  # CI deploys")
