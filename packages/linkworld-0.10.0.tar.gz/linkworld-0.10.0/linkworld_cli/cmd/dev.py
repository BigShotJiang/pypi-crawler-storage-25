"""linkworld dev — local dev loop for partner-app frontend bundles.

What this is for: editing your bundle's HTML/CSS/JS and seeing the
result in the browser without a `linkworld deploy` round-trip. Tool
calls are mocked from a config file so you don't need a real tenant
session.

Layout when running:

    http://localhost:5173/  ← bundle static files (your ./web or ./dist)
    http://localhost:3000/  ← fake parent that mounts the bundle in
                              an iframe and answers postMessage calls

The two-port split mirrors production (apps-cdn vs app.linkworld.ai)
so the bridge code paths are exercised correctly. Both servers shut
down on Ctrl+C.

Hot reload: changes to files under the bundle dir trigger an
auto-reload of the iframe via SSE. No build step assumed.

Tool mocks: drop a ``linkworld.dev.json`` next to your manifest. See
DEFAULT_MOCK_CONFIG below for the shape.
"""

from __future__ import annotations

import json
import os
import socketserver
import sys
import threading
import time
import urllib.parse
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional

import click
from rich.console import Console

console = Console()
err = Console(stderr=True)


# Default ports. 5173 (bundle) is in AppFrameHost's dev origin
# allow-list, so this same dev server can later be used against
# a real local tenant shell. The parent default is 5174 — chosen
# to avoid conflicting with the Next.js tenant shell on 3000.
DEFAULT_BUNDLE_PORT = 5173
DEFAULT_PARENT_PORT = 5174

# Serialisation guard for SSE client list mutations across threads.
_sse_lock = threading.Lock()
_sse_clients: list["socketserver.StreamRequestHandler"] = []


# ── Config ──────────────────────────────────────────────────────────


DEFAULT_THEME = {
    "colorScheme": "dark",
    "bg": "#0b0d12",
    "surface": "#161922",
    "surfaceRaised": "#1f2330",
    "text": "#e6e8ee",
    "textMuted": "#8b91a3",
    "border": "#262a36",
    "accent": "#6366f1",
    "accentText": "#ffffff",
}

LIGHT_THEME = {
    "colorScheme": "light",
    "bg": "#ffffff",
    "surface": "#f4f5f7",
    "surfaceRaised": "#e7e9ee",
    "text": "#0b0d12",
    "textMuted": "#5a6072",
    "border": "#d3d6de",
    "accent": "#4f46e5",
    "accentText": "#ffffff",
}


# Mock-config shape: { tool_name: { "ok": bool, "result"?: any, "error"?: { decision?, message, neededScopes? } } }
DEFAULT_MOCK_CONFIG: dict[str, Any] = {
    "_comment": (
        "Linkworld dev mocks. Each key is a tool name; the value is "
        "what the platform would return. Edit and reload — changes "
        "pick up on next call."
    ),
    "email_send": {
        "ok": False,
        "error": {
            "decision": "scope_denied",
            "message": "App didn't request mail.send.",
            "neededScopes": ["mail.send"],
        },
    },
    "echo": {
        "ok": True,
        "result": {"echoed": "args reflected back"},
    },
}


def _load_mock_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return DEFAULT_MOCK_CONFIG
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        err.print(f"[yellow]Failed to load {path}: {exc}; using defaults.[/yellow]")
        return DEFAULT_MOCK_CONFIG


def _resolve_bundle_dir(explicit: Optional[str]) -> Path:
    if explicit:
        return Path(explicit).resolve()
    for cand in ("dist", "web"):
        p = Path(cand).resolve()
        if p.is_dir():
            return p
    err.print("[red]No bundle directory found.[/red] Pass --dir or run from "
              "a project containing ./dist or ./web.")
    sys.exit(1)


# ── File watcher (poll-based, no deps) ──────────────────────────────


def _watch_dir(directory: Path, stop: threading.Event) -> None:
    """Poll mtimes; broadcast SSE 'reload' on change."""
    last: dict[Path, float] = {}
    while not stop.is_set():
        try:
            current: dict[Path, float] = {}
            for p in directory.rglob("*"):
                if p.is_file():
                    try:
                        current[p] = p.stat().st_mtime
                    except OSError:
                        pass
            if last and current != last:
                _broadcast_sse("event: reload\ndata: 1\n\n")
            last = current
        except Exception:
            pass
        stop.wait(0.4)


def _broadcast_sse(payload: str) -> None:
    with _sse_lock:
        clients = list(_sse_clients)
    for c in clients:
        try:
            c.wfile.write(payload.encode("utf-8"))
            c.wfile.flush()
        except Exception:
            with _sse_lock:
                if c in _sse_clients:
                    _sse_clients.remove(c)


# ── Bundle static server (port 5173) ────────────────────────────────


class _BundleHandler(BaseHTTPRequestHandler):
    bundle_dir: Path = Path()  # set by factory

    def log_message(self, *_args, **_kwargs) -> None:
        # Stdlib's default request log is noisy; we keep the dev
        # console clean and let the user opt in via env if needed.
        if os.environ.get("LINKWORLD_DEV_VERBOSE"):
            super().log_message(*_args, **_kwargs)

    def do_GET(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path

        # SSE endpoint for hot reload signalling.
        if path == "/__lw_hmr":
            self._serve_sse()
            return

        # Path normalisation — strip leading /, default to index.html.
        rel = path.lstrip("/") or "index.html"
        target = (self.bundle_dir / rel).resolve()
        try:
            target.relative_to(self.bundle_dir.resolve())
        except ValueError:
            self.send_error(HTTPStatus.FORBIDDEN, "path traversal")
            return

        if not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return

        ctype = _guess_content_type(target)
        body = target.read_bytes()

        # Inject a hot-reload snippet into HTML responses so the page
        # auto-reloads when files change. Idempotent: only rewrites
        # once via marker.
        if ctype == "text/html; charset=utf-8":
            body = _inject_hmr(body)

        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        # No CSP here — dev mode skips the production headers so devs
        # can iterate without fighting policy. Production CSP is
        # enforced by the apps-cdn nginx vhost.
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _serve_sse(self) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        with _sse_lock:
            _sse_clients.append(self)
        try:
            # Periodic comment-frames keep the connection alive
            # behind proxies that drop idle TCP.
            while True:
                self.wfile.write(b": keep-alive\n\n")
                self.wfile.flush()
                time.sleep(15)
        except Exception:
            pass
        finally:
            with _sse_lock:
                if self in _sse_clients:
                    _sse_clients.remove(self)


def _guess_content_type(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".html": "text/html; charset=utf-8",
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".json": "application/json; charset=utf-8",
        ".svg": "image/svg+xml",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
        ".woff2": "font/woff2",
        ".map": "application/json",
        ".txt": "text/plain; charset=utf-8",
    }.get(ext, "application/octet-stream")


_HMR_SNIPPET = b"""
<script>
(function(){
  if (window.__lw_hmr_attached) return;
  window.__lw_hmr_attached = true;
  try {
    var es = new EventSource('/__lw_hmr');
    es.addEventListener('reload', function(){ location.reload(); });
  } catch (e) { /* HMR is best-effort */ }
})();
</script>
"""


def _inject_hmr(body: bytes) -> bytes:
    if b"__lw_hmr_attached" in body:
        return body  # idempotent
    # Inject before </body> if present, otherwise append.
    idx = body.lower().rfind(b"</body>")
    if idx == -1:
        return body + _HMR_SNIPPET
    return body[:idx] + _HMR_SNIPPET + body[idx:]


# ── Fake parent server (port 3000) ──────────────────────────────────


class _ParentHandler(BaseHTTPRequestHandler):
    app_id: str = "dev-app"
    mock_config_path: Path = Path()
    bundle_port: int = DEFAULT_BUNDLE_PORT

    def log_message(self, *_args, **_kwargs) -> None:
        if os.environ.get("LINKWORLD_DEV_VERBOSE"):
            super().log_message(*_args, **_kwargs)

    def do_GET(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            html = _render_parent_html(self.app_id, self.bundle_port)
            self._send_html(html)
            return
        if path == "/__lw_mocks":
            cfg = _load_mock_config(self.mock_config_path)
            self._send_json(cfg)
            return
        self.send_error(HTTPStatus.NOT_FOUND)

    def _send_html(self, html: str) -> None:
        body = html.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, obj: Any) -> None:
        body = json.dumps(obj).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


def _render_parent_html(app_id: str, bundle_port: int) -> str:
    """Fake parent shell. Replicates AppFrameHost on the parent side
    using inline JS — origin gate, source gate, init/theme/resize/
    navigate handlers, plus a theme toggle so devs see theme.changed
    without needing a real tenant shell.
    """
    bundle_url = f"http://localhost:{bundle_port}/index.html"
    return f"""<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>linkworld dev — {app_id}</title>
<style>
  :root {{
    --chrome-bg: #0b0d12;
    --chrome-text: #e6e8ee;
    --chrome-muted: #8b91a3;
    --chrome-border: #262a36;
    --chrome-accent: #6366f1;
  }}
  html[data-theme="light"] {{
    --chrome-bg: #ffffff;
    --chrome-text: #0b0d12;
    --chrome-muted: #5a6072;
    --chrome-border: #d3d6de;
    --chrome-accent: #4f46e5;
  }}
  html, body {{ margin: 0; height: 100%; }}
  body {{
    background: var(--chrome-bg);
    color: var(--chrome-text);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 13px;
    display: flex;
    flex-direction: column;
  }}
  header {{
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 8px 16px;
    border-bottom: 1px solid var(--chrome-border);
    flex-shrink: 0;
  }}
  header strong {{ font-weight: 600; }}
  header .pill {{
    padding: 2px 8px;
    border: 1px solid var(--chrome-border);
    border-radius: 999px;
    color: var(--chrome-muted);
    font-size: 11px;
  }}
  header button {{
    background: var(--chrome-accent);
    color: white;
    border: 0;
    padding: 4px 10px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
  }}
  header .events {{
    flex: 1;
    color: var(--chrome-muted);
    font-family: ui-monospace, monospace;
    font-size: 11px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }}
  iframe {{
    flex: 1;
    width: 100%;
    border: 0;
    background: var(--chrome-bg);
  }}
</style>
</head>
<body>
<header>
  <strong>linkworld dev</strong>
  <span class="pill" id="app-pill">{app_id}</span>
  <button id="toggle-theme" type="button">Toggle theme</button>
  <span class="events" id="events">awaiting bridge messages…</span>
</header>
<iframe id="app" src="{bundle_url}"></iframe>

<script>
const APP_ID = {json.dumps(app_id)};
const BUNDLE_ORIGIN = "http://localhost:{bundle_port}";
const DARK_THEME  = {json.dumps(DEFAULT_THEME)};
const LIGHT_THEME = {json.dumps(LIGHT_THEME)};

const iframe = document.getElementById('app');
const events = document.getElementById('events');

let currentTheme = DARK_THEME;
let mocks = {{}};

async function refreshMocks() {{
  try {{
    const res = await fetch('/__lw_mocks');
    mocks = await res.json();
  }} catch (e) {{
    mocks = {{}};
  }}
}}
refreshMocks();
setInterval(refreshMocks, 3000); // pick up edits to linkworld.dev.json

function logEvent(msg) {{
  events.textContent = msg;
}}

function postToIframe(msg) {{
  if (!iframe.contentWindow) return;
  iframe.contentWindow.postMessage(msg, BUNDLE_ORIGIN);
}}

iframe.addEventListener('load', () => {{
  postToIframe({{
    type: 'init',
    appId: APP_ID,
    tenantIdPrefix: 'devtenan',
    userIdPrefix: 'devuser1',
    theme: currentTheme,
  }});
  logEvent(`init sent (theme=${{currentTheme.colorScheme}})`);
}});

document.getElementById('toggle-theme').addEventListener('click', () => {{
  currentTheme = currentTheme.colorScheme === 'dark' ? LIGHT_THEME : DARK_THEME;
  document.documentElement.setAttribute('data-theme', currentTheme.colorScheme);
  postToIframe({{ type: 'theme.changed', theme: currentTheme }});
  logEvent(`theme.changed (${{currentTheme.colorScheme}})`);
}});

window.addEventListener('message', (event) => {{
  if (event.origin !== BUNDLE_ORIGIN) return;
  if (event.source !== iframe.contentWindow) return;
  const data = event.data;
  if (!data || typeof data !== 'object') return;

  if (data.type === 'tools.call') {{
    const m = mocks[data.tool];
    if (!m) {{
      postToIframe({{
        id: data.id, type: 'tools.error',
        error: {{ decision: 'unmocked', message:
          `No mock for tool '${{data.tool}}'. Add it to linkworld.dev.json.` }},
      }});
      logEvent(`tools.call ${{data.tool}} → unmocked`);
      return;
    }}
    if (m.ok === false) {{
      postToIframe({{ id: data.id, type: 'tools.error', error: m.error || {{ message: 'mocked failure' }} }});
      logEvent(`tools.call ${{data.tool}} → error (${{m.error?.decision || 'unknown'}})`);
    }} else {{
      postToIframe({{ id: data.id, type: 'tools.result', result: m.result ?? {{}} }});
      logEvent(`tools.call ${{data.tool}} → ok`);
    }}
    return;
  }}
  if (data.type === 'resize') {{
    const h = Math.max(80, Math.min(8000, Math.floor(data.height || 0)));
    iframe.style.height = h + 'px';
    iframe.style.flex = '0 0 auto';
    logEvent(`resize → ${{h}}px`);
    return;
  }}
  if (data.type === 'navigate') {{
    logEvent(`navigate → ${{data.path}}`);
    return;
  }}
}});
</script>
</body>
</html>
"""


# ── CLI command ─────────────────────────────────────────────────────


@click.command(help="Run a local dev loop for your bundle (hot-reload + mocked tools).")
@click.option("--dir", "directory", default=None,
              help="Bundle directory to serve. Defaults to ./dist, then ./web.")
@click.option("--app-id", default=None,
              help="App slug to use in the init payload. Defaults to manifest's app_id, "
                   "or 'dev-app' if no manifest.")
@click.option("--mocks", "mocks_path", default="linkworld.dev.json",
              help="Path to a JSON file mapping tool names to mock responses.")
@click.option("--bundle-port", type=int, default=DEFAULT_BUNDLE_PORT,
              show_default=True,
              help="Port to serve the bundle on. Must be an AppFrameHost "
                   "dev-allow-listed port if you want to point a real "
                   "tenant shell at it later.")
@click.option("--parent-port", type=int, default=DEFAULT_PARENT_PORT,
              show_default=True,
              help="Port for the fake-parent shell that hosts the iframe.")
@click.option("--no-open", is_flag=True, help="Don't auto-open a browser.")
def dev(
    directory: str | None,
    app_id: str | None,
    mocks_path: str,
    bundle_port: int,
    parent_port: int,
    no_open: bool,
) -> None:
    bundle_dir = _resolve_bundle_dir(directory)

    # Resolve app_id from manifest if not explicit.
    if not app_id:
        manifest = Path("linkworld.app.yaml")
        if manifest.is_file():
            try:
                import yaml  # bundled with linkworld-sdk
                data = yaml.safe_load(manifest.read_text(encoding="utf-8"))
                app_id = (data or {}).get("app_id")
            except Exception:
                app_id = None
        if not app_id:
            app_id = "dev-app"

    mock_path = Path(mocks_path).resolve()

    # Wire handler classes — class-attr injection so the stdlib
    # http.server's no-arg constructor still works.
    class BundleH(_BundleHandler):
        pass
    BundleH.bundle_dir = bundle_dir

    class ParentH(_ParentHandler):
        pass
    ParentH.app_id = app_id
    ParentH.mock_config_path = mock_path
    ParentH.bundle_port = bundle_port

    try:
        bundle_srv = ThreadingHTTPServer(("127.0.0.1", bundle_port), BundleH)
    except OSError as exc:
        err.print(f"[red]Couldn't bind bundle server on :{bundle_port} — {exc}[/red]")
        err.print(f"[dim]Pass --bundle-port <free port> to override.[/dim]")
        sys.exit(1)
    try:
        parent_srv = ThreadingHTTPServer(("127.0.0.1", parent_port), ParentH)
    except OSError as exc:
        bundle_srv.server_close()
        err.print(f"[red]Couldn't bind parent server on :{parent_port} — {exc}[/red]")
        err.print(f"[dim]Pass --parent-port <free port> to override (your tenant "
                  "shell on :3000 conflicts with the old default).[/dim]")
        sys.exit(1)

    stop = threading.Event()
    t_bundle = threading.Thread(target=bundle_srv.serve_forever, daemon=True)
    t_parent = threading.Thread(target=parent_srv.serve_forever, daemon=True)
    t_watch = threading.Thread(target=_watch_dir, args=(bundle_dir, stop), daemon=True)
    t_bundle.start(); t_parent.start(); t_watch.start()

    parent_url = f"http://localhost:{parent_port}/"
    console.print()
    console.print(f"[bold]linkworld dev[/bold]")
    console.print(f"  app_id:    [bold]{app_id}[/bold]")
    console.print(f"  bundle:    [dim]{bundle_dir}[/dim]")
    console.print(f"  mocks:     [dim]{mock_path}{' (using defaults)' if not mock_path.exists() else ''}[/dim]")
    console.print(f"  open at:   [bold]{parent_url}[/bold]")
    console.print(f"  bundle on: [dim]http://localhost:{bundle_port}/[/dim]")
    console.print()
    console.print("[dim]Edit files in the bundle dir; the iframe reloads automatically.[/dim]")
    console.print("[dim]Ctrl+C to stop.[/dim]")
    console.print()

    if not no_open:
        try:
            webbrowser.open(parent_url, new=1)
        except Exception:
            pass

    try:
        # Park the main thread; signal handling stays on it.
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        console.print("\n[dim]Shutting down…[/dim]")
        stop.set()
        bundle_srv.shutdown()
        parent_srv.shutdown()
        bundle_srv.server_close()
        parent_srv.server_close()
