"""linkworld mcp — issue tokens for MCP-DX clients (Cursor / Claude Code / Codex).

Subcommands:
  linkworld mcp token      → mint a 24h dev token + emit setup hints
  linkworld mcp config     → emit a ready-to-paste config block for popular clients

The platform's MCP server lives at ``${api_url}/api/mcp/sse?token=<token>``.
External vibe-coding clients connect over SSE; the token authenticates the
session. Tokens are scoped to the authenticated user's tenant, valid 24h
(``audience=dev``).
"""
from __future__ import annotations

import sys

import click
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax

from ..api import ApiClient, ApiError
from ..config import CliConfig

console = Console()
err = Console(stderr=True)


@click.group(help="Issue + manage MCP tokens for external vibe-coding clients.")
def mcp() -> None:
    pass


@mcp.command("token", help="Mint a 24h MCP-DX token for Cursor / Claude Code / Codex.")
@click.option(
    "--audience",
    type=click.Choice(["dev", "session"]),
    default="dev",
    help=(
        "dev = 24h token for IDE clients (default). "
        "session = 5-min token for in-platform coding-sessions "
        "(rarely needed from CLI)."
    ),
)
@click.option(
    "--quiet", "-q",
    is_flag=True,
    default=False,
    help="Print just the token (for shell-piping). Skips the setup panel.",
)
def mcp_token(audience: str, quiet: bool) -> None:
    cfg = CliConfig.load()
    try:
        result = ApiClient(cfg).mint_mcp_token(audience=audience)
    except ApiError as exc:
        err.print(f"[red]{exc}[/red]")
        sys.exit(2)

    token = result.get("mcp_token", "")
    expires_in = result.get("expires_in", 0)

    if quiet:
        console.print(token)
        return

    api_base = cfg.api_url.rstrip("/")
    sse_url = f"{api_base}/api/mcp/sse?token={token}"

    hours = expires_in // 3600
    console.print(Panel.fit(
        f"[bold green]✓ MCP token issued[/bold green]\n"
        f"audience: [bold]{audience}[/bold] · expires in [bold]{hours}h[/bold]",
        border_style="green",
    ))
    console.print()
    console.print("[dim]SSE endpoint:[/dim]")
    console.print(f"  {sse_url}")
    console.print()
    console.print(
        "[dim]Add to your IDE's MCP config (see "
        "[cyan]linkworld mcp config[/cyan] for ready-to-paste blocks).[/dim]",
    )


_CURSOR_CONFIG = """\
{{
  "mcpServers": {{
    "linkworld": {{
      "url": "{sse_url}",
      "transport": "sse"
    }}
  }}
}}"""


_CLAUDE_CODE_CONFIG = """\
{{
  "mcp": {{
    "linkworld": {{
      "transport": "sse",
      "url": "{sse_url}"
    }}
  }}
}}"""


@mcp.command(
    "config",
    help="Print a ready-to-paste MCP config snippet for the chosen client.",
)
@click.argument(
    "client",
    type=click.Choice(["cursor", "claude-code", "codex"]),
    default="cursor",
)
@click.option(
    "--token",
    default=None,
    help="Reuse an existing token instead of minting a fresh one.",
)
def mcp_config(client: str, token: str | None) -> None:
    cfg = CliConfig.load()

    if not token:
        try:
            result = ApiClient(cfg).mint_mcp_token(audience="dev")
            token = result.get("mcp_token", "")
        except ApiError as exc:
            err.print(f"[red]{exc}[/red]")
            sys.exit(2)

    api_base = cfg.api_url.rstrip("/")
    sse_url = f"{api_base}/api/mcp/sse?token={token}"

    config_paths = {
        "cursor": "~/.cursor/mcp.json (or per-project: .cursor/mcp.json)",
        "claude-code": "~/.config/claude/mcp.json",
        "codex": "see your Codex client's MCP setup docs",
    }
    template = {
        "cursor": _CURSOR_CONFIG,
        "claude-code": _CLAUDE_CODE_CONFIG,
        "codex": _CURSOR_CONFIG,  # most Codex-style clients accept the Cursor shape
    }[client]
    snippet = template.format(sse_url=sse_url)

    console.print(Panel.fit(
        f"[bold]{client}[/bold] MCP config",
        border_style="cyan",
    ))
    console.print(f"[dim]Save under: {config_paths[client]}[/dim]")
    console.print()
    console.print(Syntax(snippet, "json", theme="ansi_dark", word_wrap=True))
    console.print()
    console.print(
        "[dim]Token expires in 24h. Re-run "
        "[cyan]linkworld mcp config "
        f"{client}[/cyan] to mint a fresh one.[/dim]",
    )
