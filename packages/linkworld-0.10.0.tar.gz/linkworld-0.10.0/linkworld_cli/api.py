"""
HTTP client for the platform's /api/dev/* endpoints.

Wraps httpx with auth, error handling, and a friendly error type so
CLI commands stay tidy. Sync (Click commands aren't async).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import httpx

from .config import CliConfig


class ApiError(Exception):
    """Raised on non-2xx responses or network errors. Carries status
    code and parsed body when available so commands can pattern-match."""

    def __init__(self, message: str, *, status: int = 0, body: Optional[dict] = None):
        self.status = status
        self.body = body or {}
        super().__init__(message)


@dataclass
class ApiClient:
    config: CliConfig

    @property
    def base_url(self) -> str:
        return self.config.api_url.rstrip("/")

    def _headers(self) -> dict[str, str]:
        if not self.config.token:
            raise ApiError(
                "Not logged in. Run `linkworld login --token <jwt>` first.",
                status=401,
            )
        return {
            "Authorization": f"Bearer {self.config.token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        timeout: float = 30.0,
    ) -> Any:
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.request(
                    method, url, headers=self._headers(), json=json,
                )
        except httpx.HTTPError as exc:
            raise ApiError(f"network error talking to {url}: {exc}") from exc

        if 200 <= resp.status_code < 300:
            if resp.status_code == 204 or not resp.content:
                return None
            try:
                return resp.json()
            except ValueError:
                return resp.text

        # Error path — parse body for detail
        body: dict = {}
        try:
            body = resp.json() if resp.content else {}
        except ValueError:
            body = {"text": resp.text}
        detail = body.get("detail") or body.get("error") or resp.text or "request failed"
        raise ApiError(
            f"{method} {path} → {resp.status_code}: {detail}",
            status=resp.status_code,
            body=body,
        )

    # ── Endpoints ──────────────────────────────────────────────

    def me(self) -> dict:
        return self._request("GET", "/api/dev/me")

    def list_apps(self) -> list[dict]:
        return self._request("GET", "/api/dev/apps") or []

    def create_app(
        self,
        slug: str,
        *,
        name: str,
        description: str = "",
        icon: str = "box",
    ) -> dict:
        # `category` was historically sent but the backend ignores it
        # post-unified-marketplace (M286): linkworld_products.category
        # is the kind ENUM ('app'), and the free-form sub-category lives
        # in the manifest (manifest.category) where the marketplace
        # browse reads it. Dropped from the request body for an honest
        # contract.
        return self._request(
            "POST", "/api/dev/apps",
            json={
                "slug": slug,
                "name": name,
                "description": description,
                "icon": icon,
            },
        )

    def get_app(self, slug: str) -> dict:
        return self._request("GET", f"/api/dev/apps/{slug}")

    def list_versions(self, slug: str) -> list[dict]:
        return self._request("GET", f"/api/dev/apps/{slug}/versions") or []

    def mint_mcp_token(self, audience: str = "dev") -> dict:
        """Mint an MCP token for the configured user account.

        ``audience='dev'`` returns a 24h token suitable for Cursor /
        Claude Code / Codex on a developer's laptop. ``audience='session'``
        returns the legacy 5-min token used by in-platform coding-sessions.
        """
        return self._request(
            "POST",
            f"/api/mcp/token?audience={audience}",
        )

    def preflight(self, files: dict[str, str]) -> dict:
        """Send local files to the platform's preflight endpoint.

        Returns ``{valid, issues, error_count, warning_count, app_id,
        version}``. The CLI uses this in two places: as a standalone
        ``linkworld lint`` command and as the first step of
        ``linkworld deploy``. Both share the same code path on the
        server, so a manifest the lint passes will also pass deploy's
        preflight (no drift).
        """
        return self._request(
            "POST", "/api/dev/preflight", json={"files": files},
        )

    def upgrade_tenants(
        self,
        slug: str,
        *,
        target_version: Optional[str] = None,
        tenant_id: Optional[str] = None,
        force_grant_new_scopes: bool = False,
    ) -> dict:
        body: dict = {}
        if target_version:
            body["target_version"] = target_version
        if tenant_id:
            body["tenant_id"] = tenant_id
        if force_grant_new_scopes:
            body["force_grant_new_scopes"] = True
        return self._request(
            "POST", f"/api/dev/apps/{slug}/upgrade-tenants", json=body,
        )

    def create_version(
        self,
        slug: str,
        *,
        version: str,
        image_url: str,
        manifest: dict,
        image_digest: Optional[str] = None,
        build_log_url: Optional[str] = None,
        promote: bool = True,
        bundle_pending: bool = False,
    ) -> dict:
        return self._request(
            "POST",
            f"/api/dev/apps/{slug}/versions",
            json={
                "version": version,
                "image_url": image_url,
                "image_digest": image_digest,
                "manifest": manifest,
                "build_log_url": build_log_url,
                "promote": promote,
                # M292 — when promote=true AND bundle_pending=true the
                # server defers the current_version_id flip until the
                # bundle upload finishes. Closes the "Headless App"
                # window where tenants would install a NULL-bundle row.
                "bundle_pending": bundle_pending,
            },
        )

    def upload_default_templates(
        self,
        slug: str,
        version: str,
        templates: list[dict],
    ) -> dict:
        """M295: attach doc-template defaults to a registered version.

        Server persists the array on
        ``linkworld_product_versions.default_templates`` and the
        activation flow clones each entry into the tenant's
        ``linkworld_doc_templates`` table at install time. Versions
        are immutable — server 409s if templates were already
        attached to this (slug, version) pair.
        """
        return self._request(
            "POST",
            f"/api/dev/apps/{slug}/versions/{version}/defaults/templates",
            json={"templates": templates},
        )

    def upload_bundle(
        self,
        slug: str,
        version: str,
        tarball: bytes,
    ) -> dict:
        """Upload a frontend bundle tar.gz to the platform.

        Bundle endpoint expects multipart/form-data, not JSON, so this
        uses a fresh httpx call rather than ``_request``. Auth header
        is the same dev JWT.
        """
        if not self.config.token:
            raise ApiError(
                "Not logged in. Run `linkworld login` first.",
                status=401,
            )
        url = f"{self.base_url}/api/dev/apps/{slug}/versions/{version}/bundle"
        try:
            with httpx.Client(timeout=60.0) as client:
                resp = client.post(
                    url,
                    headers={
                        "Authorization": f"Bearer {self.config.token}",
                        "Accept": "application/json",
                    },
                    files={
                        "file": (
                            f"{slug}-{version}.tar.gz",
                            tarball,
                            "application/gzip",
                        ),
                    },
                )
        except httpx.HTTPError as exc:
            raise ApiError(f"network error uploading bundle: {exc}") from exc

        if 200 <= resp.status_code < 300:
            try:
                return resp.json()
            except ValueError:
                return {"text": resp.text}

        body: dict = {}
        try:
            body = resp.json() if resp.content else {}
        except ValueError:
            body = {"text": resp.text}
        # Bundle errors come back as {"detail": {"reason": "...", "message": "..."}}
        detail = body.get("detail")
        if isinstance(detail, dict):
            reason = detail.get("reason") or "unknown"
            message = detail.get("message") or "bundle upload failed"
            raise ApiError(
                f"bundle rejected ({reason}): {message}",
                status=resp.status_code,
                body=body,
            )
        raise ApiError(
            f"POST {url} → {resp.status_code}: {detail or resp.text or 'failed'}",
            status=resp.status_code,
            body=body,
        )
