"""linkworld CLI — develop and deploy apps to the Linkworld platform."""

__version__ = "0.7.0"
