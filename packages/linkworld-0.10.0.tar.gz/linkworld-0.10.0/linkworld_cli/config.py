"""
CLI configuration — credentials + platform endpoint stored in
``~/.linkworld/config.toml``.

We intentionally keep this minimal:

  [auth]
  token = "<JWT issued by platform admin>"

  [platform]
  api_url = "https://api.linkworld.ai"

The token is a long-lived dev-session JWT (default 30 days). When it
expires, ``linkworld login --token <new-jwt>`` rewrites the file.
GitHub OAuth device flow lands in M11 — until then admins issue
tokens via ``POST /api/dev-accounts/{id}/issue-token``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

try:  # Py 3.11+ stdlib
    import tomllib  # type: ignore[import-not-found]
except ImportError:  # 3.10
    import tomli as tomllib  # type: ignore[no-redef]


DEFAULT_API_URL = os.environ.get("LINKWORLD_API_URL", "https://api.linkworld.ai")


def config_path() -> Path:
    base = Path.home() / ".linkworld"
    base.mkdir(parents=True, exist_ok=True)
    return base / "config.toml"


@dataclass
class CliConfig:
    api_url: str = DEFAULT_API_URL
    token: Optional[str] = None

    @classmethod
    def load(cls) -> "CliConfig":
        """Load from config file, falling back to env vars + defaults."""
        path = config_path()
        if not path.exists():
            return cls(token=os.environ.get("LINKWORLD_TOKEN"))

        with path.open("rb") as f:
            data = tomllib.load(f)

        return cls(
            api_url=(data.get("platform") or {}).get("api_url", DEFAULT_API_URL),
            token=os.environ.get("LINKWORLD_TOKEN")  # env overrides file
                  or (data.get("auth") or {}).get("token"),
        )

    def save(self) -> Path:
        """Persist to config file. Returns the path."""
        path = config_path()
        # Hand-write TOML to avoid an extra dependency
        lines = ["[platform]", f'api_url = "{self.api_url}"', ""]
        if self.token:
            lines += ["[auth]", f'token = "{self.token}"', ""]
        path.write_text("\n".join(lines), encoding="utf-8")
        # Restrict to user (token is sensitive)
        try:
            path.chmod(0o600)
        except OSError:
            pass
        return path
