"""Tests for GoogleAdapter — the third, most divergent grounding (native Gemini).

Each test pins a Gemini-specific divergence and proves the protocol absorbs it in
the adapter. Uses httpx.MockTransport (no live keys).
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable

import httpx
import pytest
from keel_llm_protocol import (
    AuthenticationError,
    BadRequestError,
    ContextLengthError,
    ModelAdapter,
    RateLimitError,
    ResponseFormat,
    StreamingModelAdapter,
    ToolCallingModelAdapter,
    ToolSpec,
    TransientError,
    assistant,
    system,
    tool,
    user,
)
from keel_llm_protocol.errors import AdapterTimeoutError

from keel_llm_adapter_google import GoogleAdapter

Handler = Callable[[httpx.Request], httpx.Response]


def make_adapter(handler: Handler) -> GoogleAdapter:
    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(base_url="https://gen.test", transport=transport)
    return GoogleAdapter(model="gemini-2.0-flash", provider="google", client=client)


def _response(text: str = "hello", *, finish: str = "STOP") -> dict[str, object]:
    return {
        "candidates": [
            {"content": {"role": "model", "parts": [{"text": text}]}, "finishReason": finish}
        ],
        "modelVersion": "gemini-2.0-flash-001",
        "usageMetadata": {"promptTokenCount": 14, "candidatesTokenCount": 6},
    }


# --------------------------------------------------------------------------- #
# Conformance + capabilities (Gemini DOES support json, unlike Anthropic)
# --------------------------------------------------------------------------- #


def test_conforms_to_all_protocols() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_response()))
    assert isinstance(a, ModelAdapter)
    assert isinstance(a, StreamingModelAdapter)
    assert isinstance(a, ToolCallingModelAdapter)


def test_capabilities_include_json() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_response()))
    assert {"streaming", "tools", "json_object", "json_schema"} <= a.capabilities


# --------------------------------------------------------------------------- #
# Response parsing + URL/path shape
# --------------------------------------------------------------------------- #


def test_generate_parses_candidates() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_response("hi there")))
    resp = asyncio.run(a.generate([user("hello")]))
    assert resp.text == "hi there"
    assert resp.model_key == "google:gemini-2.0-flash"
    assert resp.model_id == "gemini-2.0-flash-001"
    assert resp.finish_reason == "stop"
    assert resp.usage.input_tokens == 14
    assert resp.usage.output_tokens == 6


def test_request_uses_generatecontent_path() -> None:
    seen: dict[str, str] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        seen["path"] = req.url.path
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    asyncio.run(a.generate([user("hi")]))
    assert seen["path"] == "/v1beta/models/gemini-2.0-flash:generateContent"


# --------------------------------------------------------------------------- #
# Divergence — system -> systemInstruction; assistant role -> "model"; contents/parts
# --------------------------------------------------------------------------- #


def test_system_and_role_mapping() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    asyncio.run(a.generate([system("be terse"), user("hi"), assistant("ok")]))
    assert captured["systemInstruction"] == {"parts": [{"text": "be terse"}]}
    contents = captured["contents"]
    assert isinstance(contents, list)
    assert contents[0] == {"role": "user", "parts": [{"text": "hi"}]}
    assert contents[1] == {"role": "model", "parts": [{"text": "ok"}]}  # assistant -> model


def test_generation_config_wraps_params() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    asyncio.run(a.generate([user("hi")], temperature=0.3, max_tokens=128, stop=["END"]))
    gen = captured["generationConfig"]
    assert isinstance(gen, dict)
    assert gen["temperature"] == 0.3
    assert gen["maxOutputTokens"] == 128
    assert gen["stopSequences"] == ["END"]


# --------------------------------------------------------------------------- #
# Tools — functionCall args dict -> JSON string; functionDeclarations; mode map
# --------------------------------------------------------------------------- #


def test_function_call_parsed_to_tool_call() -> None:
    fc_response = {
        "candidates": [
            {
                "content": {
                    "role": "model",
                    "parts": [{"functionCall": {"name": "get_weather", "args": {"city": "SF"}}}],
                },
                "finishReason": "STOP",
            }
        ],
        "usageMetadata": {"promptTokenCount": 20, "candidatesTokenCount": 8},
    }
    a = make_adapter(lambda req: httpx.Response(200, json=fc_response))
    spec = ToolSpec(name="get_weather", description="w", parameters={"type": "object"})
    resp = asyncio.run(a.generate_with_tools([user("weather?")], [spec]))
    # functionCall present -> normalized finish_reason, even though Gemini said STOP
    assert resp.finish_reason == "tool_calls"
    assert resp.tool_calls[0].name == "get_weather"
    assert json.loads(resp.tool_calls[0].arguments) == {"city": "SF"}


def test_tools_serialized_as_function_declarations() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    spec = ToolSpec(name="f", description="d", parameters={"type": "object"})
    asyncio.run(a.generate_with_tools([user("go")], [spec], tool_choice="required"))
    tools = captured["tools"]
    assert isinstance(tools, list)
    assert tools[0]["functionDeclarations"][0]["name"] == "f"
    assert captured["toolConfig"] == {"functionCallingConfig": {"mode": "ANY"}}  # required -> ANY


def test_tool_result_becomes_function_response() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    asyncio.run(a.generate([user("weather?"), tool("72F", tool_call_id="x", name="get_weather")]))
    contents = captured["contents"]
    assert isinstance(contents, list)
    assert contents[-1]["parts"][0]["functionResponse"]["name"] == "get_weather"


# --------------------------------------------------------------------------- #
# Safety / finish reasons — never silently "stop"
# --------------------------------------------------------------------------- #


def test_safety_finish_maps_to_content_filter() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_response("", finish="SAFETY")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "content_filter"


def test_prompt_block_maps_to_content_filter() -> None:
    blocked = {"candidates": [], "promptFeedback": {"blockReason": "SAFETY"}}
    a = make_adapter(lambda req: httpx.Response(200, json=blocked))
    resp = asyncio.run(a.generate([user("x")]))
    assert resp.finish_reason == "content_filter"  # NOT silently "stop"


def test_unknown_finish_reason_surfaced() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_response(finish="SOME_NEW_REASON")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "unknown"


# --------------------------------------------------------------------------- #
# Structured output — Gemini honors it (contrast with Anthropic)
# --------------------------------------------------------------------------- #


def test_structured_output_honored_and_sent() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_response())

    a = make_adapter(handler)
    resp = asyncio.run(
        a.generate(
            [user("x")],
            response_format=ResponseFormat(type="json_schema", json_schema={"type": "object"}),
        )
    )
    assert resp.structured_output_honored is True
    gen = captured["generationConfig"]
    assert isinstance(gen, dict)
    assert gen["responseMimeType"] == "application/json"
    assert gen["responseSchema"] == {"type": "object"}


# --------------------------------------------------------------------------- #
# Error taxonomy
# --------------------------------------------------------------------------- #


def _err(status: int, message: str, gstatus: str = "INVALID_ARGUMENT") -> Handler:
    return lambda req: httpx.Response(
        status, json={"error": {"code": status, "message": message, "status": gstatus}}
    )


def test_429_maps_to_rate_limit() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            429,
            headers={"retry-after": "30"},
            json={"error": {"code": 429, "message": "quota", "status": "RESOURCE_EXHAUSTED"}},
        )
    )
    with pytest.raises(RateLimitError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retry_after == 30.0
    assert exc.value.retryable is True


def test_403_maps_to_authentication() -> None:
    a = make_adapter(_err(403, "no access", "PERMISSION_DENIED"))
    with pytest.raises(AuthenticationError):
        asyncio.run(a.generate([user("x")]))


def test_400_token_limit_maps_to_context_length() -> None:
    a = make_adapter(_err(400, "input token count exceeds the maximum"))
    with pytest.raises(ContextLengthError):
        asyncio.run(a.generate([user("x")]))


def test_400_other_maps_to_bad_request() -> None:
    a = make_adapter(_err(400, "invalid field"))
    with pytest.raises(BadRequestError):
        asyncio.run(a.generate([user("x")]))


def test_503_maps_to_transient() -> None:
    a = make_adapter(_err(503, "overloaded", "UNAVAILABLE"))
    with pytest.raises(TransientError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is True


def test_timeout_maps_to_adapter_timeout() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("timed out", request=req)

    a = make_adapter(handler)
    with pytest.raises(AdapterTimeoutError):
        asyncio.run(a.generate([user("x")]))


# --------------------------------------------------------------------------- #
# Streaming — Gemini SSE chunks
# --------------------------------------------------------------------------- #


def _sse(*frames: dict[str, object]) -> bytes:
    return "".join(f"data: {json.dumps(f)}\r\n\r\n" for f in frames).encode()


def test_stream_assembles_chunks() -> None:
    frames = [
        {"candidates": [{"content": {"role": "model", "parts": [{"text": "Hel"}]}}]},
        {"candidates": [{"content": {"role": "model", "parts": [{"text": "lo"}]}}]},
        {
            "candidates": [{"content": {"role": "model", "parts": [{"text": ""}]}, "finishReason": "STOP"}],
            "usageMetadata": {"promptTokenCount": 4, "candidatesTokenCount": 2},
        },
    ]
    a = make_adapter(lambda req: httpx.Response(200, content=_sse(*frames)))

    async def collect() -> list[object]:
        return [c async for c in a.stream([user("hi")])]

    chunks = asyncio.run(collect())
    assert "".join(c.delta for c in chunks) == "Hello"  # type: ignore[attr-defined]
    assert chunks[-1].finish_reason == "stop"  # type: ignore[attr-defined]
    assert chunks[-1].usage.total_tokens == 6  # type: ignore[attr-defined]


def test_stream_raises_taxonomy_on_error() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            429, json={"error": {"code": 429, "message": "quota", "status": "RESOURCE_EXHAUSTED"}}
        )
    )

    async def drain() -> None:
        async for _ in a.stream([user("hi")]):
            pass

    with pytest.raises(RateLimitError):
        asyncio.run(drain())


def test_health_check_ok() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json={"models": []}))
    assert asyncio.run(a.health_check()).healthy is True
