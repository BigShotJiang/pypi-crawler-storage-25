# keel-llm-adapter-google

> A reference [`keel-llm-protocol`](https://github.com/keelplatform/keel/tree/main/py/packages/llm-protocol) adapter for Google's **native Gemini** `generateContent` API.

The third and most divergent grounding for the protocol standard. Gemini's native wire format differs from both OpenAI and Anthropic — `contents`/`parts`, the `"model"` role, `systemInstruction`, `generationConfig`, `functionCall` parts, `finishReason` + `promptFeedback.blockReason`, and the Google error envelope. Every divergence is absorbed in the adapter; the protocol's types are unchanged.

Notably, **Gemini supports native structured output**, so this adapter's `capabilities` *include* `json_object` and `json_schema` — the contrast with `keel-llm-adapter-anthropic` (which declares neither) shows the capability-introspection design doing real work.

## Install

```bash
pip install keel-llm-adapter-google     # pulls in keel-llm-protocol + httpx
```

## Use

```python
from keel_llm_adapter_google import GoogleAdapter
from keel_llm_protocol import user
from keel_llm_protocol.errors import RateLimitError

adapter = GoogleAdapter(model="gemini-2.0-flash", api_key="...", provider="google")

try:
    resp = await adapter.generate([user("Explain rate limiting briefly.")])
    print(resp.text, resp.usage.total_tokens, resp.finish_reason)
except RateLimitError as e:
    # Gemini free tier is 15 RPM — a 429 here means healthy-but-throttled.
    # The typed error lets a circuit breaker defer to a rate limiter instead of
    # tripping the model's circuit.
    await asyncio.sleep(e.retry_after or 5.0)
```

Same `keel-llm-protocol` types as every other adapter — code written against the protocol runs unchanged whether it's pointed at Gemini, an OpenAI-compatible endpoint, or Anthropic. Implements `ModelAdapter`, `StreamingModelAdapter`, `ToolCallingModelAdapter`.

## How Gemini diverges — and where it's handled

| Gemini divergence | Absorbed by |
|---|---|
| `contents`/`parts` request shape | adapter builds parts from `Message`s |
| Assistant role is `"model"` | adapter maps `assistant` → `model` |
| System prompt is `systemInstruction` | adapter lifts `Message(role="system")` |
| Params under `generationConfig` | adapter wraps temperature/maxOutputTokens/stopSequences |
| `functionCall.args` is a parsed dict | normalized to `ToolCall.arguments` (JSON string) |
| `functionDeclarations` + `functionCallingConfig {AUTO\|ANY\|NONE}` | mapped from `ToolSpec` / `tool_choice` |
| `finishReason` (`STOP`/`MAX_TOKENS`/`SAFETY`/…) + `promptFeedback.blockReason` | mapped to `FinishReason`; safety/blocks → `content_filter`; unmapped → `unknown` |
| Google error envelope; `RESOURCE_EXHAUSTED`/`UNAVAILABLE`/… | mapped to the standard error taxonomy |
| Native structured output (`responseMimeType` + `responseSchema`) | declared in `capabilities`; honored flag set |

## Status

`0.1.0` — first release. Pin exact versions while in `0.x`. Source: [Keel monorepo](https://github.com/keelplatform/keel/tree/main/py/packages/llm-adapter-google).

## License

MIT — see [LICENSE](https://github.com/keelplatform/keel/blob/main/LICENSE).
