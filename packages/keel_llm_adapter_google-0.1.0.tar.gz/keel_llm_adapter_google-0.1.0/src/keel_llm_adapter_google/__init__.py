"""Reference ``keel-llm-protocol`` adapter for Google's native Gemini API.

`GoogleAdapter` targets `POST /v1beta/models/{model}:generateContent` (and
`:streamGenerateContent`) — Gemini's *native* wire format, which diverges from
both OpenAI and Anthropic, and is the provider where LLMCouncil's rate-limit
reliability gap actually lives (15 RPM free tier). This is the third, most
divergent grounding for the standard:

- requests are `contents` of `parts`, not `messages` of strings;
- the assistant role is ``"model"``;
- the system prompt is a top-level ``systemInstruction``;
- generation params live under ``generationConfig``;
- tool calls are ``functionCall`` parts whose ``args`` are parsed dicts;
- finish is ``finishReason`` (``STOP`` / ``MAX_TOKENS`` / ``SAFETY`` / …) plus a
  separate ``promptFeedback.blockReason`` for input-safety blocks;
- errors use the Google envelope ``{"error":{"code","message","status"}}``.

Unlike Anthropic, Gemini **does** support native structured output
(``responseMimeType`` + ``responseSchema``), so this adapter's ``capabilities``
*include* ``json_object`` and ``json_schema`` — a useful contrast for the
capability-introspection design.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator, Sequence
from typing import Any

import httpx
from keel_llm_protocol import (
    AdapterResponse,
    AuthenticationError,
    BadRequestError,
    Capability,
    ContextLengthError,
    HealthStatus,
    Message,
    RateLimitError,
    ResponseFormat,
    StreamChunk,
    ToolCall,
    ToolSpec,
    TransientError,
)
from keel_llm_protocol.errors import AdapterTimeoutError, ProviderError
from keel_llm_protocol.responses import FinishReason, Usage

__all__ = ["GoogleAdapter"]

_DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com"
_DEFAULT_VERSION = "v1beta"

# Gemini natively supports structured output, so json_* are included by default.
_DEFAULT_CAPABILITIES: frozenset[Capability] = frozenset(
    {"streaming", "tools", "json_object", "json_schema"}
)

# Gemini finishReason -> keel FinishReason
_FINISH: dict[str, FinishReason] = {
    "STOP": "stop",
    "MAX_TOKENS": "length",
    "SAFETY": "content_filter",
    "RECITATION": "content_filter",
    "PROHIBITED_CONTENT": "content_filter",
}

_TOOL_MODE = {"auto": "AUTO", "required": "ANY", "none": "NONE"}


class GoogleAdapter:
    """Adapter for Google's native Gemini ``generateContent`` API."""

    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        api_version: str = _DEFAULT_VERSION,
        default_max_tokens: int | None = None,
        provider: str = "google",
        timeout: float = 60.0,
        capabilities: frozenset[Capability] | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._model = model
        self._model_key = f"{provider}:{model}"
        self._version = api_version
        self._default_max_tokens = default_max_tokens
        self._capabilities = (
            capabilities if capabilities is not None else _DEFAULT_CAPABILITIES
        )
        if client is not None:
            self._client = client
        else:
            headers = {"x-goog-api-key": api_key} if api_key else {}
            self._client = httpx.AsyncClient(
                base_url=base_url.rstrip("/"), timeout=timeout, headers=headers
            )

    @property
    def model_key(self) -> str:
        return self._model_key

    @property
    def capabilities(self) -> frozenset[Capability]:
        return self._capabilities

    async def aclose(self) -> None:
        await self._client.aclose()

    def _honored(self, rf: ResponseFormat | None) -> bool | None:
        if rf is None or rf.type == "text":
            return None
        needed: Capability = "json_object" if rf.type == "json_object" else "json_schema"
        return needed in self._capabilities

    def _path(self, method: str) -> str:
        return f"/{self._version}/models/{self._model}:{method}"

    # -- ModelAdapter -------------------------------------------------------

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        body = self._body(messages, temperature, max_tokens, stop, response_format)
        resp = await self._complete(self._path("generateContent"), body)
        resp.structured_output_honored = self._honored(response_format)
        return resp

    async def health_check(self) -> HealthStatus:
        t0 = time.monotonic()
        try:
            resp = await self._client.get(f"/{self._version}/models")
        except httpx.HTTPError as exc:
            return HealthStatus(self._model_key, healthy=False, error=str(exc))
        latency = int((time.monotonic() - t0) * 1000)
        ok = resp.status_code < 400
        return HealthStatus(
            self._model_key,
            healthy=ok,
            latency_ms=latency,
            error="" if ok else f"HTTP {resp.status_code}",
        )

    # -- ToolCallingModelAdapter -------------------------------------------

    async def generate_with_tools(
        self,
        messages: Sequence[Message],
        tools: Sequence[ToolSpec],
        *,
        tool_choice: str = "auto",
        temperature: float | None = None,
        max_tokens: int | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        body = self._body(messages, temperature, max_tokens, None, response_format)
        body["tools"] = [
            {
                "functionDeclarations": [
                    {"name": t.name, "description": t.description, "parameters": t.parameters}
                    for t in tools
                ]
            }
        ]
        mode = _TOOL_MODE.get(tool_choice)
        if mode is not None:
            body["toolConfig"] = {"functionCallingConfig": {"mode": mode}}
        else:
            body["toolConfig"] = {
                "functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": [tool_choice]}
            }
        resp = await self._complete(self._path("generateContent"), body)
        resp.structured_output_honored = self._honored(response_format)
        return resp

    # -- StreamingModelAdapter ---------------------------------------------

    async def stream(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        body = self._body(messages, temperature, max_tokens, stop, None)
        async with self._client.stream(
            "POST", self._path("streamGenerateContent"), params={"alt": "sse"}, json=body
        ) as resp:
            if resp.status_code >= 400:
                await resp.aread()
                self._raise(resp)
            async for line in resp.aiter_lines():
                chunk = self._parse_stream_line(line)
                if chunk is not None:
                    yield chunk

    # -- internals ----------------------------------------------------------

    def _body(
        self,
        messages: Sequence[Message],
        temperature: float | None,
        max_tokens: int | None,
        stop: Sequence[str] | None,
        response_format: ResponseFormat | None,
    ) -> dict[str, Any]:
        system_parts = [m.content for m in messages if m.role == "system" and m.content]
        body: dict[str, Any] = {
            "contents": [self._wire(m) for m in messages if m.role != "system"]
        }
        if system_parts:
            body["systemInstruction"] = {"parts": [{"text": "\n\n".join(system_parts)}]}
        gen: dict[str, Any] = {}
        if temperature is not None:
            gen["temperature"] = temperature
        mt = max_tokens if max_tokens is not None else self._default_max_tokens
        if mt is not None:
            gen["maxOutputTokens"] = mt
        if stop:
            gen["stopSequences"] = list(stop)
        if response_format is not None and response_format.type != "text":
            needed: Capability = (
                "json_object" if response_format.type == "json_object" else "json_schema"
            )
            if needed in self._capabilities:
                gen["responseMimeType"] = "application/json"
                if response_format.type == "json_schema" and response_format.json_schema:
                    gen["responseSchema"] = response_format.json_schema
        if gen:
            body["generationConfig"] = gen
        return body

    @staticmethod
    def _wire(m: Message) -> dict[str, Any]:
        if m.role == "tool":
            return {
                "role": "user",
                "parts": [
                    {
                        "functionResponse": {
                            "name": m.name or "",
                            "response": {"result": m.content},
                        }
                    }
                ],
            }
        if m.role == "assistant":
            parts: list[dict[str, Any]] = []
            if m.content:
                parts.append({"text": m.content})
            for tc in m.tool_calls:
                parts.append(
                    {
                        "functionCall": {
                            "name": tc.name,
                            "args": json.loads(tc.arguments) if tc.arguments else {},
                        }
                    }
                )
            return {"role": "model", "parts": parts or [{"text": ""}]}
        return {"role": "user", "parts": [{"text": m.content}]}

    async def _complete(self, path: str, body: dict[str, Any]) -> AdapterResponse:
        t0 = time.monotonic()
        try:
            resp = await self._client.post(path, json=body)
        except httpx.TimeoutException as exc:
            raise AdapterTimeoutError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        except httpx.HTTPError as exc:
            raise TransientError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        if resp.status_code >= 400:
            self._raise(resp)
        return self._parse_response(resp.json(), int((time.monotonic() - t0) * 1000))

    def _parse_response(self, data: dict[str, Any], latency_ms: int) -> AdapterResponse:
        candidates = data.get("candidates") or [{}]
        cand: dict[str, Any] = candidates[0]
        parts = cand.get("content", {}).get("parts", []) or []
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []
        for part in parts:
            if "text" in part:
                text_parts.append(part["text"])
            fc = part.get("functionCall")
            if fc:
                # Gemini gives args as a dict and no call id — normalize to the
                # protocol's JSON-string arguments; use the name as the id.
                tool_calls.append(
                    ToolCall(
                        id=fc.get("name", ""),
                        name=fc.get("name", ""),
                        arguments=json.dumps(fc.get("args", {})),
                    )
                )
        usage_raw: dict[str, Any] = data.get("usageMetadata") or {}
        return AdapterResponse(
            text="".join(text_parts),
            model_key=self._model_key,
            model_id=data.get("modelVersion", self._model),
            finish_reason=self._finish(cand.get("finishReason"), data, tool_calls),
            usage=Usage(
                input_tokens=usage_raw.get("promptTokenCount", 0),
                output_tokens=usage_raw.get("candidatesTokenCount", 0),
            ),
            tool_calls=tool_calls,
            latency_ms=latency_ms,
            raw_response=data,
        )

    @staticmethod
    def _finish(
        raw: str | None, data: dict[str, Any], tool_calls: list[ToolCall]
    ) -> FinishReason:
        # Input-safety block: visible as content_filter, not a silent clean stop.
        if data.get("promptFeedback", {}).get("blockReason"):
            return "content_filter"
        if tool_calls:
            return "tool_calls"
        if not raw:
            return "stop"
        # Unmapped reasons surface as "unknown", never laundered to "stop".
        return _FINISH.get(raw, "unknown")

    def _parse_stream_line(self, line: str) -> StreamChunk | None:
        line = line.strip()
        if not line.startswith("data:"):
            return None
        payload = line[len("data:") :].strip()
        if not payload:
            return None
        data: dict[str, Any] = json.loads(payload)
        usage_raw = data.get("usageMetadata")
        usage = (
            Usage(
                input_tokens=usage_raw.get("promptTokenCount", 0),
                output_tokens=usage_raw.get("candidatesTokenCount", 0),
            )
            if usage_raw
            else None
        )
        candidates = data.get("candidates") or []
        if not candidates:
            return StreamChunk(usage=usage) if usage else None
        cand: dict[str, Any] = candidates[0]
        parts = cand.get("content", {}).get("parts", []) or []
        delta = "".join(p.get("text", "") for p in parts if "text" in p)
        raw_finish = cand.get("finishReason")
        return StreamChunk(
            delta=delta,
            finish_reason=_FINISH.get(raw_finish, "unknown") if raw_finish else None,
            usage=usage,
        )

    def _raise(self, resp: httpx.Response) -> None:
        status = resp.status_code
        message = self._error_message(resp)
        kw: dict[str, Any] = {
            "model_key": self._model_key,
            "status_code": status,
            "provider_error": _safe_text(resp),
        }
        if status == 429:
            raise RateLimitError(message, retry_after=_retry_after(resp), **kw)
        if status in (401, 403):
            raise AuthenticationError(message, **kw)
        if status == 400:
            lowered = message.lower()
            if "token" in lowered and ("exceed" in lowered or "maximum" in lowered or "too long" in lowered):
                raise ContextLengthError(message, **kw)
            raise BadRequestError(message, **kw)
        if status >= 500:  # 500 INTERNAL, 503 UNAVAILABLE, 504 DEADLINE_EXCEEDED
            raise TransientError(message, **kw)
        raise ProviderError(message or f"HTTP {status}", **kw)

    @staticmethod
    def _error_message(resp: httpx.Response) -> str:
        try:
            body: dict[str, Any] = resp.json()
        except (ValueError, json.JSONDecodeError):
            return _safe_text(resp)
        err = body.get("error")
        if isinstance(err, dict):
            msg = err.get("message")
            if msg:
                return str(msg)
        return _safe_text(resp)


def _retry_after(resp: httpx.Response) -> float | None:
    raw = resp.headers.get("retry-after")
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _safe_text(resp: httpx.Response) -> str:
    try:
        return resp.text
    except Exception:  # pragma: no cover - defensive
        return ""
