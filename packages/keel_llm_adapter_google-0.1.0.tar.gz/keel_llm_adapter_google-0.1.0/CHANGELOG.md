# Changelog

All notable changes to `keel-llm-adapter-google` are documented here, following
[Keep a Changelog](https://keepachangelog.com/). In `0.x`; pin exact versions.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- `GoogleAdapter` for Google's native Gemini `generateContent` /
  `streamGenerateContent` API. Implements `ModelAdapter`, `StreamingModelAdapter`,
  and `ToolCallingModelAdapter`.
- Absorbs Gemini's divergences in the adapter layer (standard unchanged):
  `contents`/`parts` shape; `assistant`→`model` role; `system`→`systemInstruction`;
  `generationConfig` param wrapping; `functionCall.args` dict ↔ `ToolCall.arguments`
  JSON-string normalization; `functionDeclarations` + `functionCallingConfig`
  mapping; `finishReason` + `promptFeedback.blockReason` → `FinishReason` (safety
  and input blocks → `content_filter`, unmapped → `unknown`); Google error
  envelope → the standard taxonomy (`RESOURCE_EXHAUSTED`→`RateLimitError`,
  `UNAVAILABLE`/`INTERNAL`/`DEADLINE_EXCEEDED`→`TransientError`, etc.).
- `capabilities` include `json_object` + `json_schema` (Gemini supports native
  structured output via `responseMimeType`/`responseSchema`) — honored flag set.
- PEP 561 `py.typed`; `mypy --strict` clean. Tested against `httpx.MockTransport`.

### Notes

- This is the **third and most divergent grounding**: it both validates the
  standard against a non-OpenAI-compatible API *and* targets the provider where
  LLMCouncil's rate-limit reliability gap actually lives (15 RPM free tier) — the
  artifact that turns "aligned vocabulary" into "consumed capability" (bridge
  D-20 / LLMCouncil Refinement 1).
