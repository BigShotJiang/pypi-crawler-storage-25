# START HERE

> **Audience:** anyone (human or AI agent) using `mgf-common` to
> bring a project to the team's engineering-standards bar.
> **Two flows:** new project, existing project. Both are one
> command.

`mgf-common` is the cornerstone library + standards source-of-truth
for the team. Every project that depends on it inherits the same
quality bar (typed exceptions, structured logging, four-gate CI,
the AP/EH/LG/CF/SC/TS rule discipline).

---

## Browsing the docs as a web UI

The repo has ~80 docs (standards, recipes, references, audience
pages, design papers, cutover guides). The fastest way to find
your way around without getting lost:

```bash
python tools/docs_explorer/serve.py
```

Opens `http://127.0.0.1:8765/` in your browser. Sidebar grouped by
category, full-text search, cross-doc links resolved, per-page TOC.
Stdlib-only, localhost-only (never exposed). `Ctrl+C` to stop.

Options: `--port 9000`, `--no-open`. Full notes at
[`tools/docs_explorer/README.md`](tools/docs_explorer/README.md).

---

## I'm starting a NEW project

```bash
mkdir my-new-app && cd my-new-app && git init                                # 1
mgf-common init-project --name my-new-app --kind fastapi                     # 2
$EDITOR pyproject.toml   # paste the snippet step 2 printed                  # 3
uv sync && uv run ruff check && uv run mypy --strict src/ && uv run pytest   # 4
```

Replace `--kind` with: `cli` / `fastapi` / `django` / `library` / `service`.

What landed:

| Path | Role |
|---|---|
| `docs/CLAUDE.md` | Auto-loaded by Claude every session — top-30 rules inline. |
| `.claude/settings.json` | Safe Claude permission defaults. |
| `pyproject.toml` (printed snippet) | Four green gates pre-tuned. |

Open the project in Claude Code → CLAUDE.md auto-loads → standards
adherence is automatic from here.

| Want more? | Read |
|---|---|
| Full walkthrough | [`docs/recipes/new_project.md`](docs/recipes/new_project.md) |
| First-time tutorial (zero → working app, ~30 min) | [`docs/tutorial.md`](docs/tutorial.md) |
| Web-project reading order | [`docs/standards/web/README.md`](docs/standards/web/README.md) |

---

## I have an EXISTING project (catch up to current standards)

```bash
cd /path/to/your/project
mgf-common catch-up               # audit — read-only
mgf-common catch-up --apply       # mechanical fixes (originals get .bak.*)
```

What `catch-up` audits:

| Row | What it checks |
|---|---|
| **pin** | `mgf-common` listed in `pyproject.toml` with a sensible version bound. |
| **four gates** | `[tool.ruff]`, `[tool.mypy] strict`, `[tool.pytest filterwarnings=error]`, coverage threshold. |
| **`docs/CLAUDE.md`** | Exists, has BEGIN/END auto-managed markers, content is current. |
| **`.claude/settings.json`** | Exists with safe defaults. |
| **patterns** | Legacy `configure() / setup_logging() / install_excepthook()` calls that should migrate to `bootstrap()`. |

`--apply` is mechanical only: creates missing files, refreshes the
auto-managed CLAUDE.md block (project content below the END marker
is preserved), backs up originals. It does NOT touch `pyproject.toml`
(prints the suggested snippet) or rewrite legacy call sites.

> **Telling another Claude session?** One sentence does it:
> *"Run `mgf-common catch-up` in this project's root, review the drift
> report, apply with `--apply`."*

---

## When something feels off — debugging

| Command | What it tells you |
|---|---|
| `mgf-common doctor` | Install-state + wiring health check. First thing to run when "is mgf-common bootstrapped here?" is the question. Modes: `--live` (runtime snapshot), `--redaction` (test redactor on stdin), `--standards` (audit against AP/DP/TS rules). |
| `mgf-common explain` | Prints the active `MgfSettings` with each field's source (CLI / env / `.env` / file / default). The "why is this setting taking that value?" command. |
| `mgf-common standards <topic>` | Prints any standards doc — `LOGGING`, `SECURITY`, `ERROR_HANDLING`, etc. |

Standards topics: `DESIGN_PRINCIPLES`, `ERROR_HANDLING`, `LOGGING`,
`CONFIGURATION`, `SECURITY`, `TESTING`, `API_DESIGN`, `SCOPE`,
`COMMON_COMPONENTS`, `README`. Aliases (case-insensitive):
`errors`, `config`, `api`, `components`, `design`.

---

## Upgrading mgf-common across versions

```bash
mgf-common migrate 0.18 0.19 src/    # mechanical renames + import fixes
mgf-common migrate 0.18 0.19 src/ --dry-run --backup
```

Per-release migration narratives live in [`docs/cutover/`](docs/cutover/)
(last 3 minor versions; older in `archive/`). The cutover guide is the
canonical migration story; `migrate` handles the mechanical parts.

---

## Filing feedback against mgf-common

```bash
mgf-common feedback              # how to submit + the entry template
mgf-common feedback --template   # entry template, ready to paste
mgf-common feedback --url        # FEEDBACK.md on codeberg
```

---

## CLI cheat-sheet

| Command | Use when |
|---|---|
| `mgf-common init-project` | NEW project — scaffold the skeleton. |
| `mgf-common catch-up` | EXISTING project — audit + apply current standards. |
| `mgf-common doctor` | "Is mgf-common bootstrapped correctly here?" |
| `mgf-common explain` | "Why is this setting taking that value?" |
| `mgf-common standards <topic>` | Read any engineering-standards doc. |
| `mgf-common migrate` | Upgrade across mgf-common versions. |
| `mgf-common feedback` | File feedback against mgf-common itself. |

Add `--help` to any subcommand for full options.

---

## Where to look next

**By audience** — pick the one that matches you:

| If you are… | Read |
|---|---|
| **Building** with mgf-common | [`docs/audience/users.md`](docs/audience/users.md) |
| **Evaluating** (is this a fit?) | [`docs/audience/shoppers.md`](docs/audience/shoppers.md) |
| **Contributing** to mgf-common | [`docs/audience/developers.md`](docs/audience/developers.md) |
| A **test/QA** engineer | [`docs/audience/qa.md`](docs/audience/qa.md) |
| Cutting **releases** | [`docs/audience/release.md`](docs/audience/release.md) |
| Doing a **security** review | [`docs/audience/security.md`](docs/audience/security.md) |
| An **AI agent** | [`docs/audience/ai-agents.md`](docs/audience/ai-agents.md) |

**By content** — what you're looking for:

| Looking for… | Path |
|---|---|
| Recipe index (every how-to in one place) | [`docs/recipes/README.md`](docs/recipes/README.md) |
| Engineering rules (MUST/SHOULD/MAY) | [`docs/standards/`](docs/standards/) |
| API reference per module | [`docs/reference/`](docs/reference/) |
| Tutorial (zero → working app) | [`docs/tutorial.md`](docs/tutorial.md) |
| Per-release migration | [`docs/cutover/`](docs/cutover/) |
| Public-API contract | [`PUBLIC_API.md`](PUBLIC_API.md) · [`PUBLIC_API.json`](PUBLIC_API.json) (machine-readable) |
| Design papers | [`docs/design/`](docs/design/) |
| Federation pattern (sibling `mgf-*` packages) | [`docs/design/federation.md`](docs/design/federation.md) |
| Architecture (for mgf-common contributors) | [`docs/design/architecture.md`](docs/design/architecture.md) |

*This document is the user-facing entry point. Maintainers: keep it
short; deep-dives go in `docs/`.*
