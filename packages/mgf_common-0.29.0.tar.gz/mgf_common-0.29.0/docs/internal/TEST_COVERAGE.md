# TEST_COVERAGE.md — moved

> **This file moved to [`docs/qa/coverage.md`](../qa/coverage.md)
> in v0.25.0** as part of the docs reorg (audience-routing
> layer + flat-content directories). Update your bookmarks.

The content is identical; only the path changed. This stub
will be removed in v0.26.0.

See [`docs/cutover/v0.25.0.md`](../cutover/v0.25.0.md) for the
full path-mapping table.
