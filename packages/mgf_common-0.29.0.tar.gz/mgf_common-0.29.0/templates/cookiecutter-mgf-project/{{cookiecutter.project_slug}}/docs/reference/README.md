# {{ cookiecutter.project_name }} — reference

(Fill in project-specific reference as the project grows. The
canonical pattern lives in mgf-common's
[`docs/reference/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/reference/).)
