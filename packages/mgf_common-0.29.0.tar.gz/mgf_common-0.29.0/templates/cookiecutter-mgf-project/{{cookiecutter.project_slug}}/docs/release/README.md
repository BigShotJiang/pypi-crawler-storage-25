# {{ cookiecutter.project_name }} — release

(Fill in project-specific release as the project grows. The
canonical pattern lives in mgf-common's
[`docs/release/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/release/).)
