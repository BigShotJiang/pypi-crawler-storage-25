# {{ cookiecutter.project_name }} — Test coverage map

> Per
> [mgf-common's TS-19/20/21](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/TESTING.md),
> every project tracks its test coverage map at this path.

## Layer summary

| Layer | Directory | Marker | Count | Total runtime |
|---|---|---|--:|---|
| smoke | `tests/smoke/` | `@pytest.mark.smoke` | _TBD_ | < 100 ms |
| unit | `tests/unit/` (mirrors `src/`) | (default) | _TBD_ | _TBD_ |
| integration | `tests/integration/` | `@pytest.mark.integration` | _TBD_ | _TBD_ |
| e2e | `tests/e2e/` | `@pytest.mark.e2e` | _TBD_ | _TBD_ |
| **total** | | | _TBD_ | _TBD_ |

Run a layer in isolation:

```bash
pytest -m smoke              # post-install sanity
pytest -m e2e                # full chains
pytest -m integration        # cross-module
pytest                       # everything
```

## Per-module coverage

| Module | Unit | Integration | E2E | Smoke |
|---|:-:|:-:|:-:|:-:|
| `{{ cookiecutter.package_name }}` | (TBD) | — | — | — |

(Fill in as your test suite grows. mgf-common's
[reference coverage map](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/qa/coverage.md)
shows the full pattern.)

## Coverage gaps

(Modules with only unit coverage that would benefit from
integration / e2e — list them here as a roadmap. Not blockers;
unit tests alone are conformance-passing.)

## Adding a new test — decision tree

Per
[mgf-common's TESTING.md §13.9](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/TESTING.md):

```
Single function/class/module?                    → unit/
Two-or-more modules composed (no real bootstrap)? → integration/
Requires bootstrap()?                             → e2e/
"Wheel imports + happy path"?                     → smoke/
> 1 second runtime?                               → add @pytest.mark.slow
Hits real external system?                        → §12 pattern
```
