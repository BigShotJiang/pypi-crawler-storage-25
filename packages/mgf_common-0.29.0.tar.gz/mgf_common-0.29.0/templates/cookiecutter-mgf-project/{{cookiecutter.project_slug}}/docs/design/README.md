# {{ cookiecutter.project_name }} — design

(Fill in project-specific design as the project grows. The
canonical pattern lives in mgf-common's
[`docs/design/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/design/).)
