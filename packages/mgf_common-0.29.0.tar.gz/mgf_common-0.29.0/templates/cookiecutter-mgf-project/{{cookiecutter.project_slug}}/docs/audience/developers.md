# {{ cookiecutter.project_name }} — For developers

> **Who you are.** Contributing to {{ cookiecutter.project_name }}.

(Fill in: design papers, standards inheritance from mgf-common,
contribution flow, FEEDBACK.md template if applicable.)

For the canonical pattern, see
[mgf-common's developers page](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/audience/developers.md).
