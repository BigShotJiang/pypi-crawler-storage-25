# {{ cookiecutter.project_name }} — For shoppers

> **Who you are.** You're evaluating {{ cookiecutter.project_name }}.

(Fill in: scope, fit, decision tree, comparison with
alternatives, consumers using it today, when to NOT adopt.)

For the canonical pattern, see
[mgf-common's shoppers page](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/audience/shoppers.md).
