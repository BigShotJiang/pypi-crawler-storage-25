# Documentation by audience

> Pick the audience that matches you. Each page below is a
> **reading list** that points into the rest of the docs.

| If you are… | Read | What you'll find |
|---|---|---|
| Evaluating {{ cookiecutter.project_name }} | [`shoppers.md`](shoppers.md) | Scope, fit, decision tree |
| Building with it | [`users.md`](users.md) | Tutorial → recipes → reference |
| Contributing | [`developers.md`](developers.md) | Design papers, contribution flow |
| Test/QA engineer | [`qa.md`](qa.md) | Test layers, coverage |
| Cutting releases | [`release.md`](release.md) | Release runbook |
| Security review | [`security.md`](security.md) | Threat model, SC-* deltas |
| AI agent | [`ai-agents.md`](ai-agents.md) | Relay protocol, paths-as-anchors |

This layout is the **mgf-common golden-standard** (v0.25.0+).
Sibling Magogi libraries adopt the same shape via this
cookiecutter template.

## Inheritance from mgf-common

Most rules (TS-* / EH-* / CF-* / LG-* / SC-* / AP-* / DP-* /
REL-* / WF-*) are inherited unchanged from
[mgf-common's standards corpus](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/).
This project's exceptions / project-specific additions live in
[`../standards/PROJECT_OVERLAY.md`](../standards/PROJECT_OVERLAY.md).

If you're filling in this project's audience pages from
scratch: copy the structure from
[mgf-common's audience pages](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/audience/)
and replace project-specific content. The shape (one-paragraph
intro + read-first list + read-next list + cross-references)
is the canonical pattern.
