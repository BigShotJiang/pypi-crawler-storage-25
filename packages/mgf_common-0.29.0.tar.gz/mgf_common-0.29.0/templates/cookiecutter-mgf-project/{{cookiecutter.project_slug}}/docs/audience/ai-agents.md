# {{ cookiecutter.project_name }} — For AI agents

> **Who you are.** Consumer-side or maintainer-side AI agent
> for {{ cookiecutter.project_name }}.

(Fill in: project-specific anchors / paths / FEEDBACK template
if applicable. The relay protocol inherits from mgf-common.)

For the canonical pattern, see
[mgf-common's ai-agents page](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/audience/ai-agents.md).
