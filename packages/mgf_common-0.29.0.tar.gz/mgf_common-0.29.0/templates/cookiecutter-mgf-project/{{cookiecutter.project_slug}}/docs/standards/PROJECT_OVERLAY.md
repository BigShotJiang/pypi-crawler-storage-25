# {{ cookiecutter.project_name }} — Project standards overlay

This document records project-specific exceptions to the
canonical `mgf-common` standards corpus.

> **Canonical inheritance.** Unless overridden here, every
> rule in
> [mgf-common's standards](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/)
> applies as-shipped. Document only the deltas.

## Conformance level

This project targets **L<n>** per
[mgf-common's conformance ladder](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/README.md#conformance-levels-for-projects).

(Replace `<n>` with `0`, `1`, or `2`. L1 is the default for new projects.)

## Project-specific exceptions

(Empty by default — fill in only as your project surfaces real
needs.)

### TS-* (Testing)

(none)

### EH-* (Error Handling)

(none)

### CF-* (Configuration)

(none)

### LG-* (Logging)

(none)

### SC-* (Security)

(none)

### AP-* (API Design)

(none)

### DP-* (Design Principles)

(none)

### REL-* / WF-* (Release / Workflows)

(none)

## Project-specific additions

(Use this section for rules that don't fit the canonical
prefixes — e.g., domain-specific patterns. Number them with a
project-specific prefix like `{{ cookiecutter.project_name|upper }}-NN`.)

(none)

## Cross-references

- Documented non-adoption rationale (when this project declines
  a primitive) lives in `docs/design/adrs/` per
  [`mgf-common's non-adoption-is-valid principle`](https://codeberg.org/magogi-admin/mgf_common/src/branch/master/docs/standards/principles/non-adoption-is-valid.md).
- Project-specific test coverage map: [`../qa/coverage.md`](../qa/coverage.md).
- Project-specific release runbook: [`../release/ci.md`](../release/ci.md).
