"""Django middleware classes — request-id + AppContext propagation.

Both middlewares follow Django's standard middleware shape: a
class with ``__init__(self, get_response)`` and ``__call__(self,
request) -> response``. They are sync-mode-only (the most common
Django shape); async-mode support can be added in v0.7+ if needed.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mgf.common._request_id import (
    _REQUEST_ID_VAR,
    REQUEST_ID_HEADER,
    _generate_request_id,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from django.http import HttpRequest, HttpResponse


class MgfRequestIdMiddleware:
    """Django middleware: inject/forward ``X-Request-Id`` per request.

    Same contract as :class:`mgf.fastapi.RequestIdMiddleware`
    — same contextvar, same header name, same generation rule. A
    Django app calling a FastAPI service via an internal RPC will
    see the same request id propagate end-to-end (assuming the
    upstream call sets the header).

    Install in ``MIDDLEWARE`` *early* so downstream middleware +
    views see ``request.mgf_request_id`` populated::

        MIDDLEWARE = [
            "mgf.common.django.MgfRequestIdMiddleware",  # earliest
            "mgf.common.django.MgfContextMiddleware",
            "django.middleware.security.SecurityMiddleware",
            # ... your other middleware ...
        ]
    """

    def __init__(
        self,
        get_response: Callable[[HttpRequest], HttpResponse],
    ) -> None:
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        # Django stores headers under META as ``HTTP_<UPPER_SNAKE>``.
        # Header lookup is case-insensitive at the WSGI layer.
        existing = request.META.get("HTTP_X_REQUEST_ID")
        request_id = existing or _generate_request_id()

        # Set on request for view access (matches FastAPI's
        # request.state.request_id pattern).
        request.mgf_request_id = request_id
        token = _REQUEST_ID_VAR.set(request_id)
        try:
            response = self.get_response(request)
        finally:
            _REQUEST_ID_VAR.reset(token)

        # Echo in response so clients can correlate too.
        response[REQUEST_ID_HEADER] = request_id
        return response


class MgfContextMiddleware:
    """Django middleware: expose the active :class:`AppContext` on requests.

    Reads the active context from :func:`mgf.common.current_context`
    (set by :class:`MgfCommonConfig.ready`) and stashes it on
    ``request.mgf_context`` so views can ask:

    .. code-block:: python

        def my_view(request):
            ctx = request.mgf_context
            log.info("handling", extra={"app": ctx.app_name})

    Install AFTER :class:`MgfRequestIdMiddleware` so that the request
    id is already bound to the contextvar when the view runs::

        MIDDLEWARE = [
            "mgf.common.django.MgfRequestIdMiddleware",
            "mgf.common.django.MgfContextMiddleware",
            # ... your other middleware ...
        ]

    If :class:`MgfCommonConfig` hasn't run yet (e.g., in tests that
    don't load the app), ``request.mgf_context`` is set to ``None``
    rather than raising.
    """

    def __init__(
        self,
        get_response: Callable[[HttpRequest], HttpResponse],
    ) -> None:
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        from mgf.common._lifecycle import current_context

        try:
            ctx = current_context()
        except Exception:
            ctx = None
        request.mgf_context = ctx
        return self.get_response(request)
