"""``mgf.common.django`` — Django integration adapters.

See: ``docs/recipes/django.md`` (v0.7 Phase A) and the
strategic-review §4.2.D.

Five surfaces close the Django consumer's adoption gap (the
finding from the v0.5 strategic review: every Django shop rebuilds
equivalent infrastructure because the cost of adoption is greater
than the value):

  - :class:`MgfCommonConfig` — Django ``AppConfig`` that calls
    :func:`mgf.common.bootstrap` idempotently in ``ready()``.
  - :class:`MgfRequestIdMiddleware` — per-request ``X-Request-Id``
    generation/forwarding via the same contextvar
    :class:`mgf.fastapi.RequestIdMiddleware` uses (so
    cross-framework processes can correlate end-to-end).
  - :class:`MgfContextMiddleware` — exposes the active
    :class:`AppContext` on ``request.mgf_context`` for views and
    other middleware.
  - :class:`JsonFormatter` — Django ``LOGGING['formatters']``-
    compatible wrapper around :class:`mgf.common.observability.JsonFormatter`.
    No required args, so the Django ``'()'`` factory syntax works.
  - :class:`DjangoSettingsBridge` — read-only bridge that exposes a
    pydantic-validated subset of ``django.conf.settings`` as a
    :class:`BaseAppSettings`-compatible object. Lets ``mgf-common
    explain settings.X`` work in Django apps.

Optional extra: ``pip install 'mgf-common[django]'`` (pulls
``django>=4.2``).

The adapter is **callable-from-Django**, not framework-shaped. Your
``manage.py`` is unchanged; your ``settings.py`` is unchanged; your
``INSTALLED_APPS`` adds one entry, your ``MIDDLEWARE`` adds two.

Drop-in shape (the typical Django ``settings.py`` addition):

.. code-block:: python

    INSTALLED_APPS = [
        # ... your apps ...
        "mgf.common.django",
    ]

    MIDDLEWARE = [
        "mgf.common.django.MgfRequestIdMiddleware",  # earliest
        "mgf.common.django.MgfContextMiddleware",
        # ... your other middleware ...
    ]

    LOGGING = {
        "version": 1,
        "formatters": {
            "json": {"()": "mgf.common.django.JsonFormatter"},
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "json",
            },
        },
        "root": {"handlers": ["console"], "level": "INFO"},
    }

    MGF_COMMON_APP_NAME = "myapp"
    MGF_COMMON_APP_VERSION = "1.0.0"

That's the entire integration. The :class:`AppConfig` calls
:func:`bootstrap` once when Django boots; the middlewares carry the
per-request state; the formatter routes through the standard
mgf-common redaction + OTel correlation pipeline.
"""

from __future__ import annotations

try:
    import django  # noqa: F401
except ImportError as exc:  # pragma: no cover — exercised by import-failure test
    raise ImportError(
        "mgf.common.django requires the [django] extra. "
        "Install with: pip install 'mgf-common[django]'"
    ) from exc

from mgf.common.django._apps import MgfCommonConfig
from mgf.common.django._logging import JsonFormatter
from mgf.common.django._middleware import (
    MgfContextMiddleware,
    MgfRequestIdMiddleware,
)
from mgf.common.django._settings import DjangoSettingsBridge

__all__ = [
    "DjangoSettingsBridge",
    "JsonFormatter",
    "MgfCommonConfig",
    "MgfContextMiddleware",
    "MgfRequestIdMiddleware",
]
