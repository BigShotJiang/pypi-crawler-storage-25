"""``mgf.common.alembic`` — async-aware alembic ``env.py`` helper.

See: ``docs/recipes/alembic.md`` (v0.6 Phase D) and the
strategic-review §4.2.E.

Every async-SQLAlchemy + alembic project repeats the same ~40-line
``env.py`` boilerplate:

  - Read the URL from settings (or alembic.ini).
  - Set up the offline path for SQL-emit-only mode.
  - Set up the async online path with ``async_engine_from_config``.
  - Wire ``do_run_migrations`` via ``connection.run_sync``.
  - Configure ``compare_type`` / ``compare_server_default`` for autogen.
  - Apply naming-convention to ``target_metadata``.

This module replaces all of that with one call:

.. code-block:: python

    # alembic/env.py
    from mgf.common.alembic import configure_env
    from myapp.config import MyAppSettings
    from myapp.db.base import Base


    settings = MyAppSettings()
    configure_env(
        database_url=settings.database_url,
        target_metadata=Base.metadata,
    )

That's the entire file. The helper detects offline vs online mode,
runs the migration, disposes the engine cleanly. Async drivers
(asyncpg, aiomysql, aiosqlite) are auto-detected from the URL
prefix; sync drivers fall through the synchronous path.

Optional extra: ``pip install 'mgf-common[alembic]'`` (pulls
``alembic>=1.13``).

The helper is **callable-from-env.py**, not framework-shaped. Your
``alembic.ini`` is unchanged; your migrations directory is
unchanged; ``alembic upgrade head`` / ``alembic revision
--autogenerate`` work exactly as before.
"""

from __future__ import annotations

from mgf.common.alembic._env import configure_env

__all__ = ["configure_env"]
