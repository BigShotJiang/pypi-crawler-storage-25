"""Observability infrastructure — logging, crash reporting, tracing.

See: ``docs/reference/observability.md`` (logging + OTel + redaction),
     ``docs/reference/crash_reporting.md`` (crash reporter + sinks).

This subpackage has no consumer-project imports. Identity (app name +
version) flows in via :mod:`mgf.common._identity`, which the consumer
project configures once in its entry point via :func:`mgf.common.configure`.

Public surface:

- :func:`setup_logging` — single-point logging configuration. Call
  once per entry point.
- :func:`setup_otel` — OpenTelemetry initialization (no-op when
  OTel deps are not installed or no endpoint is configured).
- :func:`operation_span` — context manager wrapping a use case in
  a span. Safe to use even when OTel is disabled.
- :func:`report_now` — build + persist + best-effort ship a crash
  report from any caught exception.
- :func:`install_excepthook` — process-wide unhandled exception hook.
- :func:`install_threading_excepthook` — non-main-thread hook.
- :class:`Redactor` — sensitive-field redaction policy used by the
  formatters.
- :data:`DEFAULT_REDACTION_KEYS` — the built-in secret-bearing key
  set, exposed as a frozenset so consumers can audit / extend
  without copy-paste (closes FEEDBACK PAPER-02).
- :func:`default_log_path`, :func:`default_crash_dir`,
  :func:`default_state_dir` — on-disk locations the library writes
  to, for consumers building observability-adjacent UI (closes
  FEEDBACK PAPER-07).

See ``docs/standards/LOGGING.md`` and ``docs/standards/ERROR_HANDLING.md``
for the full design.
"""

from __future__ import annotations

from mgf.common.observability._helpers import (
    add_event,
    get_current_span,
    get_logger,
    set_attribute,
    set_status,
)
from mgf.common.observability._otel_reexports import (
    Span,
    SpanContext,
    SpanKind,
    SpanStatus,
    StatusCode,
)
from mgf.common.observability.async_handler import AsyncJsonHandler
from mgf.common.observability.crash_reporter import (
    CrashSink,
    register_crash_sink,
    report_now,
    unregister_crash_sink,
)
from mgf.common.observability.excepthook import install_excepthook
from mgf.common.observability.json_formatter import JsonFormatter
from mgf.common.observability.logging_setup import (
    LogFormat,
    LogHandlerFactory,
    register_log_handler,
    setup_logging,
    unregister_log_handler,
)
from mgf.common.observability.otel_setup import (
    SpanProcessorFactory,
    operation_span,
    register_span_processor,
    setup_otel,
    unregister_span_processor,
)
from mgf.common.observability.paths import (
    default_crash_dir,
    default_log_path,
    default_state_dir,
)
from mgf.common.observability.redaction import (
    DEFAULT_REDACTION_KEYS,
    PatternGroupFactory,
    RedactionGroup,
    Redactor,
    register_redaction_pattern_group,
    unregister_redaction_pattern_group,
)
from mgf.common.observability.threading_excepthook import install_threading_excepthook

__all__ = [
    "DEFAULT_REDACTION_KEYS",
    "AsyncJsonHandler",
    "CrashSink",
    "JsonFormatter",
    "LogFormat",
    "LogHandlerFactory",
    "PatternGroupFactory",
    "RedactionGroup",
    "Redactor",
    "Span",
    "SpanContext",
    "SpanKind",
    "SpanProcessorFactory",
    "SpanStatus",
    "StatusCode",
    "add_event",
    "default_crash_dir",
    "default_log_path",
    "default_state_dir",
    "get_current_span",
    "get_logger",
    "install_excepthook",
    "install_threading_excepthook",
    "operation_span",
    "register_crash_sink",
    "register_log_handler",
    "register_redaction_pattern_group",
    "register_span_processor",
    "report_now",
    "set_attribute",
    "set_status",
    "setup_logging",
    "setup_otel",
    "unregister_crash_sink",
    "unregister_log_handler",
    "unregister_redaction_pattern_group",
    "unregister_span_processor",
]
