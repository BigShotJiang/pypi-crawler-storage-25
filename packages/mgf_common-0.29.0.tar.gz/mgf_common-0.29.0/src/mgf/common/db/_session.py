"""Async session factory + FastAPI-Depends + tenant-scoping.

Three helpers covering the request-handling lifecycle:

  - :func:`create_sessionmaker` — wraps :class:`async_sessionmaker`
    with mgf-common defaults (``expire_on_commit=False`` —
    SQLAlchemy 2's recommended default for async; consumers can
    pass ``expire_on_commit=True`` to opt into the legacy behavior).
  - :func:`get_session` — FastAPI-Depends-compatible async generator.
    Yields one :class:`AsyncSession` per request; closes via the
    context manager.
  - :func:`tenant_session` — context manager that runs
    ``SET LOCAL app.current_tenant = '<uuid>'`` for Postgres RLS-based
    multi-tenancy. The ``LOCAL`` qualifier scopes to the current
    transaction; auto-resets on commit / rollback. Tenant id is
    UUID-validated at the call site to prevent SQL injection.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from starlette.requests import (
    Request,  # noqa: TC002 — FastAPI needs runtime type for Depends introspection
)

from mgf.common.exceptions import AppConfigError

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from sqlalchemy.ext.asyncio import AsyncEngine


def create_sessionmaker(
    engine: AsyncEngine,
    *,
    expire_on_commit: bool = False,
) -> async_sessionmaker[AsyncSession]:
    """Return an :class:`async_sessionmaker` bound to ``engine``.

    Default ``expire_on_commit=False`` matches SQLAlchemy 2's
    recommended default for async sessions (objects stay usable
    after commit instead of being silently expired). Pass
    ``expire_on_commit=True`` to revert to the legacy synchronous
    semantics.
    """
    return async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=expire_on_commit,
    )


async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    """FastAPI-Depends generator that yields one session per request.

    Reads the sessionmaker from
    ``request.app.state.mgf_db_sessionmaker`` — populated by
    :func:`mgf.common.db.setup_db` inside the FastAPI lifespan.

    The session is closed via its context manager when the
    handler returns (or raises). Commit / rollback is the
    consumer's responsibility — we don't presume a global policy.

    Use as::

        from typing import Annotated
        from fastapi import Depends
        from sqlalchemy.ext.asyncio import AsyncSession
        from mgf.common.db import get_session

        @app.get("/users")
        async def list_users(
            session: Annotated[AsyncSession, Depends(get_session)],
        ) -> list[dict]:
            ...

    Raises :class:`AppConfigError` if the lifespan didn't run
    (no sessionmaker on ``app.state``). The
    ``ExceptionTranslationMiddleware`` (when installed) maps that
    to a 500 with an actionable message.
    """
    sessionmaker = getattr(request.app.state, "mgf_db_sessionmaker", None)
    if sessionmaker is None:
        raise AppConfigError(
            "mgf.common.db: app.state.mgf_db_sessionmaker is unset. "
            "Did you wrap your lifespan with `setup_db(app, "
            "database_url=...)` (see "
            "docs/recipes/db.md)?"
        )

    async with sessionmaker() as session:
        yield session


@asynccontextmanager
async def tenant_session(
    session: AsyncSession,
    tenant_id: str | UUID,
) -> AsyncIterator[AsyncSession]:
    """Run ``SET LOCAL app.current_tenant = '<tenant_id>'`` for ``session``.

    Postgres RLS-based multi-tenancy pattern (PlasmaMapper rule
    ``PM-MT-04``). The ``LOCAL`` qualifier scopes the setting to
    the current transaction; auto-resets on commit / rollback so
    cross-tenant leakage between requests is impossible at the
    SQL layer.

    ``tenant_id`` is UUID-validated before interpolation. Postgres
    ``SET LOCAL`` does NOT accept bind parameters, so we have to
    interpolate the value into the SQL — which is safe iff the
    input is shape-validated (UUIDs are alphanumeric + dashes,
    no SQL-meaningful chars). A non-UUID input raises ``ValueError``.

    Raises ``ValueError`` if ``tenant_id`` isn't a UUID-shaped
    string; raises whatever SQLAlchemy raises if the database
    rejects the SET (e.g., custom GUC not declared in
    ``postgresql.conf``).

    Use as::

        async with sessionmaker() as session:
            async with tenant_session(session, tenant_id) as scoped:
                # All queries on `scoped` (same session, just
                # tenant-scoped) get app.current_tenant.
                rows = await scoped.execute(text("SELECT ..."))
    """
    if isinstance(tenant_id, UUID):
        tenant_str = str(tenant_id)
    else:
        # Validate that the string is a real UUID; UUID() raises
        # ValueError on malformed input. After validation, the
        # canonical hex+dash form is safe to interpolate.
        validated = UUID(tenant_id)
        tenant_str = str(validated)

    # SET LOCAL accepts only literal values; bind params don't work.
    # Safe because tenant_str came from UUID() — alphanumeric+dashes.
    await session.execute(text(f"SET LOCAL app.current_tenant = '{tenant_str}'"))
    yield session


__all__ = [
    "create_sessionmaker",
    "get_session",
    "tenant_session",
]
