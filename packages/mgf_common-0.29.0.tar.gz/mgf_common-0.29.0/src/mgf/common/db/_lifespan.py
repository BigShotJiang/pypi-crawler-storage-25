"""``setup_db`` — engine + sessionmaker creation/disposal in FastAPI lifespan.

Designed to compose with :func:`mgf.fastapi.setup_lifespan`::

    from contextlib import asynccontextmanager
    from fastapi import FastAPI
    from mgf.common._lifecycle import bootstrap
    from mgf.common.db import setup_db


    @asynccontextmanager
    async def my_lifespan(app: FastAPI):
        with bootstrap(app_name="myapp", app_version="1.0.0") as ctx:
            async with setup_db(app, database_url="postgresql+asyncpg://..."):
                yield


    app = FastAPI(lifespan=my_lifespan)

The composition above wires both bootstrap (logging + OTel + crash
hooks) AND the DB engine in one lifespan. Each piece independently
unwinds on shutdown.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from mgf.common.db._engine import create_engine
from mgf.common.db._session import create_sessionmaker

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from fastapi import FastAPI


@asynccontextmanager
async def setup_db(
    app: FastAPI,
    *,
    database_url: str,
    **engine_kwargs: Any,
) -> AsyncIterator[None]:
    """Create engine + sessionmaker; stash on ``app.state``; dispose at exit.

    Inside the context:

      - ``app.state.mgf_db_engine`` → :class:`AsyncEngine`.
      - ``app.state.mgf_db_sessionmaker`` → factory.

    On exit, the engine's connection pool is disposed cleanly (via
    :meth:`AsyncEngine.dispose`).

    Compose inside a larger lifespan that also runs
    :func:`mgf.common.bootstrap` — see module docstring for the
    canonical pattern.

    Forward extra engine kwargs::

        async with setup_db(
            app,
            database_url=settings.database_url,
            echo=settings.db_echo,
            pool_size=20,
        ):
            yield
    """
    engine = create_engine(database_url, **engine_kwargs)
    sessionmaker = create_sessionmaker(engine)
    app.state.mgf_db_engine = engine
    app.state.mgf_db_sessionmaker = sessionmaker
    try:
        yield
    finally:
        await engine.dispose()


__all__ = ["setup_db"]
