# Changelog

All notable changes to `mgf-common` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
the project follows [SemVer](https://semver.org/spec/v2.0.0.html). Per
the 0.x window ([SemVer 0.x](https://semver.org/#spec-item-4) and rule
**AP-03**), MINOR releases MAY break the public API. Pin tightly:

```toml
mgf-common = ">=0.X.0,<0.Y"   # one minor at a time
```

Each release section cross-references the [`FEEDBACK.md`](FEEDBACK.md)
entry and (where applicable) the consumer-side migration recipe. The
release-engineering discipline that produces this changelog is in
[`docs/standards/RELEASING.md`](docs/standards/RELEASING.md).

---

## [Unreleased]

(no entries)

---

## [0.29.0] — 2026-05-09

PyPI: <https://pypi.org/project/mgf-common/0.29.0/> · Tag: `v0.29.0`

> **Cutover guide:** [`docs/cutover/v0.29.0.md`](docs/cutover/v0.29.0.md)
> — second federation extraction per [ASPIRE-06](FEEDBACK.md). The
> entire `mgf.common.http` subpackage moves to a new sibling
> distribution **`mgf-http`** (import path `mgf.http`). 🔴
> **breaking** for any consumer importing from `mgf.common.http.*`
> or installing the `mgf-common[http]` extra; the migration is a
> rename + dependency swap PLUS one renamed class
> (`HttpClientError` → `HttpTransportError`).

### Removed (BREAKING)

- **`mgf.common.http.*`** — every name (`AsyncHttpClient`,
  `RetryPolicy`, the transport-failure `HttpClientError`) moves
  to `mgf.http.*` in the new **`mgf-http`** sibling distribution.
- **`[http]` and `[http-test]` extras** in `mgf-common` are
  deleted. Consumers install `mgf-http` (or `mgf-http[test]`)
  directly.

### Renamed (BREAKING — sibling-side)

- **`HttpClientError` → `HttpTransportError`** — the
  transport-failure leaf renames at the cutover to disambiguate
  from `mgf.common.exceptions.HttpClientError` (the HTTP-01
  4xx-class hierarchy parent, which **stays in mgf-common**
  unchanged). Renaming was deferred until the extraction since
  fixing the collision in mgf-common alone would have churned
  every consumer twice. Now both classes have unambiguous names:
  - `mgf.common.exceptions.HttpClientError` (status-class
    hierarchy parent, 4xx-class) — **kept**.
  - `mgf.http.exceptions.HttpTransportError` (transport-layer
    failure leaf) — **renamed**.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.http import AsyncHttpClient` | `from mgf.http import AsyncHttpClient` |
| `from mgf.common.http import RetryPolicy` | `from mgf.http import RetryPolicy` |
| `from mgf.common.http import HttpClientError` | `from mgf.http import HttpTransportError` |
| `pip install 'mgf-common[http]'` | `pip install mgf-http` |
| `pip install 'mgf-common[http-test]'` | `pip install 'mgf-http[test]'` |

The new `mgf-http` sibling pins to `mgf-common>=0.29,<0.30`. The
v0.29 cutover guide details the dependency-pin and import-rewrite
steps per consumer (PlasmaMapper + mgf-apiprobe migrate; VManager
+ inthewords have no http surface and need only the
`mgf-common = ">=0.29,<0.30"` pin bump).

### Documentation

- **`docs/cutover/v0.29.0.md`** (new) — full rename map +
  sed-friendly mechanical rewrite for the
  `HttpClientError` → `HttpTransportError` rename + per-consumer
  migration notes.
- **`docs/recipes/http.md`** — moved to `mgf-http/docs/recipes/`
  per **D5**. The mgf-common recipes README keeps the entry as a
  `(sibling)` pointer.
- **`docs/recipes/README.md`**, **`docs/reference/README.md`**,
  **`docs/reference/full_app.md`**, **`docs/recipes/{db,
  notebook,multi_tenant_settings,providers}.md`**,
  **`docs/audience/security.md`**, **`docs/qa/coverage.md`**,
  **`docs/internal/lift_checklist.md`** — cross-references
  rewritten to point at the new `mgf.http` sibling import path
  and to use the renamed `HttpTransportError` class.

### Engineering

- **`tools/generate_public_api_json.py`** — `PUBLIC_MODULES` no
  longer includes `mgf.common.http`. PUBLIC_API.json regenerated.
- **`src/mgf/common/cli/_init_project.py`** — scaffolded
  pyproject snippet emits sibling deps (`mgf-fastapi`,
  `mgf-http`) instead of the legacy `mgf-common[fastapi,http]`
  extras shape. Per-kind dep lists updated for the two
  extractions to date; pin bumped from the stale `0.9.0,<0.10`
  to `0.29,<0.30`. EH-11 retry-policy reference points at
  `mgf.http.RetryPolicy` (sibling) instead of the deleted
  `mgf.common.http.RetryPolicy`.
- **`tests/unit/cli/test_init_project.py`** — `test_pin_includes_extras_for_kind`
  renamed to `test_pin_includes_siblings_for_kind` and rewritten
  to assert the new sibling-dep emission. Negative assertions
  enforce that `mgf-common[fastapi,...]` / `mgf-common[http,...]`
  do NOT reappear (regression guard for the federation rule).

### Engineering note — what changed internally

Two non-breaking improvements landed during the v0.29 extraction:

1. **Closed-box leak fix.** `mgf.common.http._client` previously
   reached into `mgf.common._identity._APP_NAME` /
   `_APP_VERSION` to compute the User-Agent — a private import
   from another module within the same distribution, but still
   a closed-box-rule violation. The sibling now uses the public
   `mgf.common.app_name()` / `mgf.common.app_version()` accessors.
   Behaviour is identical.
2. **User-Agent attribution.** The library suffix in the
   User-Agent header changed from `mgf-common/<libver>` to
   `mgf-http/<libver>`. Accurate now that `AsyncHttpClient`
   ships from the sibling. Consumers that match on
   `mgf-common/<libver>` for HTTP traffic specifically should
   update to `mgf-http/<libver>`.

---

## [0.28.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.28.0/> · Tag: `v0.28.0`

> **Cutover guide:** [`docs/cutover/v0.28.0.md`](docs/cutover/v0.28.0.md)
> — first federation extraction per [ASPIRE-06](FEEDBACK.md). The
> entire `mgf.common.fastapi` subpackage moves to a new sibling
> distribution **`mgf-fastapi`** (import path `mgf.fastapi`). This
> is a 🔴 **breaking** ship for any consumer importing from
> `mgf.common.fastapi.*` or the `mgf-common[fastapi]` extra; the
> migration is a rename + dependency swap (no code-shape changes).

### Removed (BREAKING)

- **`mgf.common.fastapi.*`** — every name (`setup_lifespan`,
  `RequestIdMiddleware`, `ExceptionTranslationMiddleware`,
  `current_request_id`, `REQUEST_ID_HEADER`, `DEFAULT_STATUS_MAP`,
  `get_app_context`, `get_settings`, `get_request_id`,
  `IpAllowlist`, `LOOPBACK_CIDRS`, `run_test_app`,
  `HmacWebhookVerifier`, `verify_request`, `WebhookHeaderSchema`,
  `SVIX_SCHEMA`) moves to `mgf.fastapi.*` in the new
  **`mgf-fastapi`** sibling distribution.
- **`mgf.common.exceptions.HmacVerificationError`** — moves to
  `mgf.fastapi.exceptions` per **D3** (sibling-domain concretes
  travel with their sibling). HTTP-01 hierarchy roots
  (`HttpUnauthorized`, `HttpForbidden`, …) stay in `mgf-common`.
- **`[fastapi]` and `[fastapi-test]` extras** in `mgf-common` are
  deleted. Consumers install `mgf-fastapi` (or
  `mgf-fastapi[testing]`) directly.

### Migration

| Was | Now |
|---|---|
| `from mgf.common.fastapi import X` | `from mgf.fastapi import X` |
| `from mgf.common.fastapi.webhooks import …` | `from mgf.fastapi.webhooks import …` |
| `from mgf.common.fastapi.security import IpAllowlist` | `from mgf.fastapi.security import IpAllowlist` |
| `from mgf.common.fastapi.testing import run_test_app` | `from mgf.fastapi.testing import run_test_app` |
| `from mgf.common.exceptions import HmacVerificationError` | `from mgf.fastapi.exceptions import HmacVerificationError` |
| `pip install 'mgf-common[fastapi]'` | `pip install mgf-fastapi` |
| `pip install 'mgf-common[fastapi-test]'` | `pip install 'mgf-fastapi[testing]'` |

The new `mgf-fastapi` sibling pins to `mgf-common>=0.28,<0.29`. The
v0.28 cutover guide details the dependency-pin and import-rename
steps per consumer (PlasmaMapper is the migration consumer; VManager
+ inthewords have no FastAPI surface and need only the
`mgf-common = ">=0.28,<0.29"` pin bump).

### Documentation / design

- **`docs/release/federation_roadmap.md`** (new) — load-bearing
  tracking document for the v0.28 → v1.0 federation split. Per-
  sibling specs, quality gates, locked decisions (D1–D15), open
  questions, future improvements, retrospective log. The single
  source of truth for the staged extraction plan; FEEDBACK papers
  cross-reference here.
- **`FEEDBACK.md ASPIRE-06`** — federated package architecture
  approved 2026-05-08. v0.28 extracts `mgf-fastapi`; v0.29 extracts
  `mgf-http`; v0.30 extracts `mgf-sqlalchemy` + `mgf-alembic`; v0.31
  extracts `mgf-django`; v1.0 locks the federated surface. Sibling-
  domain concrete exceptions (`HmacVerificationError` etc.) move with
  their sibling; HTTP-01 hierarchy roots stay in mgf-common.
- **`FEEDBACK.md ASPIRE-05`** (filed) — long-horizon: mgf-common as
  cross-language engineering-process source-of-truth. Triggered by
  PAPER-30 (first non-Python sibling). Decision deferred until 2+
  non-Python Magogi projects exist.
- **`FEEDBACK.md PAPER-30`** (filed) — `mgf-website-template`
  cookiecutter sibling repo for Magogi marketing sites (Astro +
  Infomaniak deploy). Parallel to the Python-sibling federation, not
  in the dependency graph.
- **`FEEDBACK.md ASPIRE-04`** — restored missing `#### ASPIRE-04`
  heading dropped accidentally in commit `3c12f21`. The entry's body
  was always there; the heading was lost in a copy-edit.
- **`docs/recipes/{fastapi,webhooks}.md`** moved to
  `mgf-fastapi/docs/recipes/`. `docs/recipes/README.md`,
  `docs/standards/web/README.md`, `docs/reference/README.md`,
  `docs/reference/full_app.md`, `docs/recipes/{db,django,http,
  providers,framework-owned-logging}.md`, and
  `docs/design/multi_tenancy.md` updated to reference the new
  sibling import path.
- **`docs/internal/lift_checklist.md`** — adapter-vs-sibling
  guidance updated: framework-shaped adapters now ship as siblings
  by default (the v0.28 federation decision). Stateless,
  primitive-reusing adapters (`mgf.common.{db,http,alembic}`,
  `mgf.common.django` until extracted) remain extras.

### Engineering

- **`tests/unit/django/conftest.py`** — adds a package-scoped
  finalizer that closes Django's open `_BOOTSTRAP_STACK` at the end
  of the django package's tests. Without this, identity (`_APP_NAME =
  "test-app"`) leaked into later test files (the fastapi tests
  previously masked the leak by re-bootstrapping with their own
  identity in their lifespan tests; with those tests gone, the leak
  surfaced as crash-reporter / excepthook failures).
- **`tools/generate_public_api_json.py`** — `PUBLIC_MODULES` no
  longer includes `mgf.common.fastapi.*`. Module count: 23 → 19;
  total names: 201 → 184.

### Engineering note — first federation extraction

v0.28.0 is the **first execution** of the federation split per
ASPIRE-06. The shape this extraction proves out is the template for
v0.29 (`mgf-http`), v0.30 (`mgf-sqlalchemy`, `mgf-alembic`), and
v0.31 (`mgf-django`):

- Federation leaf (`mgf-common`) deletes the subpackage entirely
  in the same release that the sibling ships v0.1.0 — no
  deprecation cycle, no `.fastapi` stub re-exporting from
  `mgf.fastapi`. The 0.x window discipline absorbs the breakage.
- Sibling-domain concrete exceptions move with their sibling per
  **D3**; the HTTP-01 hierarchy roots (`HttpUnauthorized`,
  `HttpForbidden`, etc.) stay in `mgf-common`.
- Framework-specific recipes (`fastapi.md`, `webhooks.md`) move
  with their sibling per **D5**; cross-cutting standards
  (`docs/standards/web/`) stay in `mgf-common` per **D4**.

---

## [0.27.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.27.0/> · Tag: `v0.27.0`

> **Cutover guide:** [`docs/cutover/v0.27.0.md`](docs/cutover/v0.27.0.md)
> — closes [PAPER-27](FEEDBACK.md) (`IpAllowlist` FastAPI dependency)
> + [PAPER-28](FEEDBACK.md) (`run_test_app` async context manager).
> Same-day batch follow-up to v0.26.0; both 🟢 nice-to-haves filed
> by PlasmaMapper in the same Phase-3 paper batch.

### Added

- **`mgf.common.fastapi.security.IpAllowlist`** (closes
  [PAPER-27](FEEDBACK.md)) — FastAPI dependency that 403s requests
  whose client IP isn't in a configured CIDR allowlist. Concentrates
  the **proxy-trust footgun** in one knob (`trust_proxy: bool = False`
  default — explicit deploy decision required to honour
  `X-Forwarded-For`). IPv4 + IPv6 dual-stack with cross-version
  matches deliberately rejected. Raises `HttpForbidden` (HTTP-01
  leaf, 403 via PAPER-24's `http_status` resolution). Default
  `cidrs=LOOPBACK_CIDRS` so tests work out-of-the-box; consumers
  override for production. Misconfigured CIDRs raise at
  construction, not first request.
- **`mgf.common.fastapi.testing.run_test_app`** (closes
  [PAPER-28](FEEDBACK.md)) — async context manager that starts
  uvicorn for a `FastAPI` app on a free port and yields the base
  URL. Replaces ~120 LOC per consumer (free-port discovery +
  race-free `server.started` await + clean-shutdown choreography
  with `CancelledError` suppression). Surfaces server-startup
  exceptions instead of timing out silently. `TimeoutError` if the
  app's lifespan blocks beyond `startup_timeout_seconds` (default
  5 s).

### Changed

- **`pyproject.toml [project.optional-dependencies] fastapi-test`**
  — adds `uvicorn>=0.30` for `run_test_app`. Existing consumers of
  the `[fastapi-test]` extra automatically pick it up on next
  `uv sync`.

### Engineering

- 24 new tests across `tests/unit/fastapi/test_security.py` (16) +
  `tests/unit/fastapi/test_testing.py` (8). Total suite: 1495
  passing.
- Both helpers follow the v0.26.0 webhooks pattern: closed-box
  module under `mgf.common.fastapi.*`, explicit `from
  mgf.common.fastapi.security import …` (not re-exported at the
  top of `mgf.common.fastapi`). Encourages discoverable
  consumer code.
- The `Request` import in `security.py` is intentionally NOT
  inside `TYPE_CHECKING` — FastAPI's dependency wiring evaluates
  the parameter's annotation at registration time via
  `get_type_hints`, so the name MUST be importable at runtime.
  `# noqa: TC002` makes the intent explicit.

---

## [0.26.0] — 2026-05-08

PyPI: <https://pypi.org/project/mgf-common/0.26.0/> · Tag: `v0.26.0`

> **Cutover guide:** [`docs/cutover/v0.26.0.md`](docs/cutover/v0.26.0.md)
> — closes [PAPER-26](FEEDBACK.md): generic Svix-shape HMAC webhook
> verification primitive. Plus the v0.25.0-deferred recipe index.

### Added

- **`mgf.common.fastapi.webhooks`** (closes [PAPER-26](FEEDBACK.md))
  — Svix-shape HMAC webhook verification. Pulls the per-consumer
  verification dance (read `<id>` / `<ts>` / `<sig>` headers,
  validate replay window, compute `HMAC-SHA256(<id>.<ts>.<body>)`,
  base64-encode, constant-time-compare against multi-version
  signature header) into one tested primitive. Public surface:
  `WebhookHeaderSchema` (frozen dataclass; case-folds header
  names), `SVIX_SCHEMA` (Svix preset; used verbatim by Clerk),
  `HmacWebhookVerifier` (transport-agnostic core; thread-safe;
  `verify(headers, body) -> (event_id, ts)`), `verify_request`
  (async FastAPI request adapter). The verifier is intentionally
  transport-agnostic so it tests cleanly without FastAPI and
  composes from non-FastAPI code paths (CLI, batch jobs).
- **`mgf.common.exceptions.HmacVerificationError`** — new HTTP-01
  leaf inheriting `HttpUnauthorized` so PAPER-24's `http_status`
  resolution maps it to 401 in
  `ExceptionTranslationMiddleware` without an explicit
  `status_map` entry.
- **`docs/recipes/webhooks.md`** — full walkthrough including
  the consumer pattern for replacing per-provider verifiers,
  key rotation, and custom schemas.
- **`docs/recipes/README.md`** — canonical recipe index (v0.25.0
  truth-source-consolidation deliverable). Kind-organised section
  + A–Z lookup table with per-recipe paper closures + brief recipe
  / standard / reference disambiguation. `docs/audience/users.md`
  now points at the README as the complete index; the audience
  page remains the adoption-order reading list.

### Engineering

- 25 new tests in `tests/unit/fastapi/test_webhooks.py` covering
  every failure mode (missing header, unparseable timestamp, replay
  window in both directions, tampered body, wrong secret, wrong
  prefix, no prefix, multi-version-sig key rotation, case-
  insensitive header lookup, custom schema, custom signature
  prefix) plus the FastAPI request-adapter integration path
  through `ExceptionTranslationMiddleware`. Total suite: 1471
  passing.
- Stripe / GitHub / Slack signing schemes are deliberately NOT
  shipped at v0.26 — their conventions differ enough (combined
  headers, hex encoding, alternate prefixes) that one
  `WebhookHeaderSchema` doesn't fit. Adding presets is tracked
  for follow-up papers when a second consumer surfaces friction.

---

## [0.25.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.25.0/> · Tag: `v0.25.0`

> **Cutover guide:** [`docs/cutover/v0.25.0.md`](docs/cutover/v0.25.0.md)
> — **documentation restructure**. Audience-routing front
> door + flat-content directories + cutover archive policy.
> **No Python-surface change. No behaviour change.**
> 100% documentation reorganisation.

### Added

- **`docs/audience/` — 8 new files** (master `README.md` + 7
  reading lists for `shoppers / users / developers / qa /
  release / security / ai-agents`). Each ~80–150 lines, pure
  navigation, no duplicated content. The new front door for
  every kind of reader.
- **`docs/README.md`** — the documentation index that routes
  to audience pages OR content directories by kind.
- **Top-level `README.md`** — rewritten as audience router
  (~100 lines, mostly links). Replaces the previous 374-line
  verbose form.
- **Cookiecutter template `docs/` overlay** — new project
  scaffolding now ships the same audience-routing layer +
  `standards/PROJECT_OVERLAY.md` for project-specific rule
  exceptions + `qa/coverage.md` skeleton. Sibling Magogi
  libraries inherit the layout via the cookiecutter.

### Changed (file moves; `git mv` preserved history)

| Old path | New path | Why |
|---|---|---|
| `docs/public/recipes/*` | `docs/recipes/*` | Drop `/public/` intermediate; flatter |
| `docs/public/01_lifecycle.md`, `02_..10_*.md` | `docs/reference/lifecycle.md`, `exceptions.md`, etc. | Semantic names instead of numbered prefixes |
| `docs/public/library_common.md` | `docs/reference/README.md` | "reference" is the right word |
| `docs/public/tutorial.md` | `docs/tutorial.md` | One file, no `/public/` wrapper |
| `docs/public/multi_tenancy.md` | `docs/design/multi_tenancy.md` | Design paper, not how-to |
| `docs/public/federation.md` | `docs/design/federation.md` | Same |
| `docs/internal/ARCHITECTURE.md` | `docs/design/architecture.md` | Promoted to public |
| `docs/internal/STRATEGIC_REVIEW.md` | `docs/design/strategic_review.md` | Same |
| `docs/internal/EXTRACTION_HISTORY.md` | `docs/design/extraction_history.md` | Same |
| `docs/internal/TEST_COVERAGE.md` | `docs/qa/coverage.md` | New `qa/` directory |
| `docs/internal/CI_STARTHERE.md` | `docs/release/ci.md` | New `release/` directory |
| `docs/internal/BENCHMARKS.md` | `docs/ops/benchmarks.md` | New `ops/` directory |
| `docs/internal/LIFT_CHECKLIST.md` | `docs/internal/lift_checklist.md` | Stays internal; lowercase |
| `docs/cutover/v0.18.0–v0.21.0.md` | `docs/cutover/archive/v*.md` | Last-3-minor-versions live policy |

### Truth-source consolidation

| Topic | Old (multi-source) | New canonical |
|---|---|---|
| What's tested | `tests/` + `internal/TEST_COVERAGE.md` + `TESTING.md §13.10` | `docs/qa/coverage.md` (narrative); other paths now point here |
| Recipe index | recipes scattered + per-module READMEs | `docs/recipes/README.md` (planned for v0.26+) |
| Per-release migration | `CHANGELOG.md` + `cutover/*` overlap | CHANGELOG = canonical short; cutover = canonical long; cross-linked |

### Deferred to v0.26+

- **Splitting `PUBLIC_API.md`** into per-module
  `docs/reference/<module>.md` files auto-generated from
  docstrings. The split was scoped out of v0.25 to keep this
  release purely structural.
- **Auto-generation of `docs/qa/coverage.md`** from `pytest --co`
  output.

### Engineering

- **Backwards-compat stub:** `docs/internal/TEST_COVERAGE.md`
  ships as a 1-line redirect to `docs/qa/coverage.md` for
  this release; removed in v0.26.
- **179 broken links found** by an ad-hoc link checker, fixed
  in batched sed/Python passes; final state: 0 broken links
  in non-archive content (modulo placeholder example syntax
  in `tools/docs_explorer/README.md`).
- **All 1445 tests pass unchanged** — the docs restructure
  doesn't touch any code surface.
- **Wheel content unchanged.** Only `docs/standards/` ships
  via `[tool.hatch.build.targets.wheel.force-include]`; no
  `docs/standards/*` files moved, so the wheel data is
  identical except for the version bump.

### Why this round

After 12 releases (v0.13 → v0.24), the docs accumulated
multiple truth-sources, fuzzy `public`/`internal` boundaries,
and no audience-routing front door. With three real consumers
in production and the cookiecutter template extending to
sibling Magogi libraries, a clean restructure was overdue.
The shape (audience-as-navigation + flat-content) is now the
**golden-standard layout** that sibling libraries inherit.

The full design rationale + question/answer log lives in the
[v0.25.0 cutover guide](docs/cutover/v0.25.0.md).

---

## [0.24.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.24.0/> · Tag: `v0.24.0`

> **Cutover guide:** [`docs/cutover/v0.24.0.md`](docs/cutover/v0.24.0.md)
> — codify the four-layer test pyramid as a standard so other
> projects adopt the same shape. **Documentation-only release;
> zero Python-surface change.**

### Added

- **Three new TS-* rules in `docs/standards/TESTING.md`:**
  - **TS-19** — test layer markers MUST be registered in
    `pyproject.toml::[tool.pytest.ini_options].markers`. Combined
    with `--strict-markers` (TS-05) this prevents silent typos.
  - **TS-20** — tests MUST be partitioned across
    `tests/unit/` (mirrors `src/`), `tests/integration/`
    (cross-module), `tests/e2e/` (full bootstrap-to-output),
    `tests/smoke/` (post-install sanity).
  - **TS-21** — every published library MUST have a smoke
    layer in `tests/smoke/` running in <100 ms total. CLI/desktop
    apps without a wheel surface MAY skip.
- **`docs/standards/TESTING.md` §13 — the operational layer-marker
  pattern.** New section codifying the four-layer pyramid as a
  standard: directory shape, marker registration, runtime
  budgets, the smoke-layer minimum-viable shape, the e2e
  bootstrap-fixture pattern, the integration cross-module
  pattern, and a decision tree for "which layer for a new
  test?". Section §13.10 includes mgf-common's own per-layer
  counts as a reference.
- **`docs/qa/coverage.md`** — reference document
  showing what mgf-common tests at each layer plus per-module
  coverage breakdown plus coverage gaps as a roadmap. Consumer
  projects can copy the shape for their own
  `docs/qa/coverage.md`.
- **Section renumbering in `TESTING.md`:** new §13 "Layer
  markers" pushes the original §13–§17 to §14–§18 (Anti-patterns,
  Self-review, Mechanical enforcement, AS-IS, Cross-references).

### Engineering

- v0.24.0 is the **second docs-only release** for `mgf-common`
  (after v0.20.0). The pattern: when a feature shape stabilises
  and proves itself across multiple polish rounds (here:
  v0.21 → v0.22 → v0.23 for `mgf.common.process`), the next
  step is **codifying the pattern as a standard so other
  projects adopt the same shape**. This is the load-bearing
  part of the "cornerstone library" framing — the standards
  drive consistency across the ecosystem, not just the wheel.

---

## [0.23.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.23.0/> · Tag: `v0.23.0`

> **Cutover guide:** [`docs/cutover/v0.23.0.md`](docs/cutover/v0.23.0.md)
> — second `mgf.common.process` polish round. Quality + comprehensive
> test layer expansion. **No behaviour breaks** for v0.22.0 consumers;
> existing `run()` / `Service` / readiness predicates / Process*
> exceptions all unchanged.

### Added

- **Public `redactor` property on `JsonFormatter` and `TextFormatter`.**
  Replaces the fragile private-attribute introspection that
  `mgf.common.process._streamer.get_active_redactor` was doing
  (the `formatter._redactor` lookup). The private attribute stays
  as a back-compat alias; new callers should use the public property.
- **`Service.__repr__`** for debugging. Shape:
  `Service(name='<n>', command=[...], status=<state>, pid=<pid|->)`
  where status is `not-started` / `running` / `exited(<rc>)`.
- **Best-effort OTel span wrapping** for `run()` and
  `Service.start()`. When `mgf.common.bootstrap()` is active AND
  the OpenTelemetry SDK is installed, each launch opens an
  `operation_span("process.run.<name>")` / `operation_span(
  "service.start.<name>")` with `command_id` as a span attribute.
  Failed launches (`ProcessTimeout` / `ServiceNotReady`) are
  recorded on the span. **Gated on bootstrap state** — when no
  `AppContext` is active, the call short-circuits to
  `contextlib.nullcontext()`, avoiding the `UnconfiguredWarning`
  the unguarded `operation_span` would emit (since it reads
  `app_name()` to name the tracer). Test suites with
  `filterwarnings = error` continue to work.
- **Tuple commands accepted** — `run(("echo", "hi"))` works
  alongside `run(["echo", "hi"])`. UX paper-cut for tests/scripts
  that build command tuples. Internal validation (`_validate_command`)
  normalizes to `list[str]` so the downstream `Popen` always sees
  a list and the `ProcessResult.command` field is always a list.
- **Pytest layer markers** (`smoke`, `e2e`, `integration`)
  registered in `pyproject.toml`. Run a layer in isolation with
  `pytest -m smoke` etc.

### Test coverage expansion

- **Smoke tier** (`tests/smoke/`) — 7 tests, < 100 ms total. Minimal
  post-install sanity (imports, exception MRO, `run()` happy path,
  Service no-launch-on-init, tuple acceptance, shell-string
  rejection).
- **End-to-end tier** (`tests/e2e/`) — 8 tests:
  - **Redaction E2E** (5 tests) — bootstrap + `run()` + child
    emitting a Bearer token → assert scrubbed in BOTH captured
    `stdout` and the streamed log record. Includes `redact=False`
    opt-out, `redact=True` requires-bootstrap raise, no-bootstrap
    silent-no-redaction.
  - **Correlation E2E** (3 tests) — `command_id` consistency
    across captured records, distinct ids across concurrent
    `run()` calls in threads, Service lifecycle records share
    the same id with the streamer's records.
- **Integration tier** (`tests/integration/process/`) — 5 tests:
  - **Multi-service via `ExitStack`** (2 tests) — declared-order
    start, LIFO teardown, no-leak when the dependent's start
    fails.
  - **Concurrent `run()`** (3 tests) — 16 parallel calls produce
    16 distinct `command_id`s, captured stdout is per-call
    isolated, log records don't cross processes.
- **Unit tier additions** (`tests/unit/process/test_polish_v023.py`) —
  9 tests: restart-after-failure pattern, OTel span gating
  (no `UnconfiguredWarning` without bootstrap; nullcontext path
  vs real-span path), public-redactor property on both
  formatters, `Service.__repr__` shape across lifecycle states.

**75 → 104 tests in the process subtree (+29)**. Full repo:
1416 → 1445 (+29). Zero regressions.

### Changed (internal — no surface impact)

- **`get_active_redactor()`** prefers the new public `redactor`
  property; falls back to `_redactor` for older formatters
  (back-compat).
- **Extracted `_validate_command(command)`** helper from
  duplicated validation code in `run()` and `Service.__init__`.
  Single source of truth for "list-or-tuple of strings, non-empty,
  no shell strings."

### Engineering

- **Stability tier:** every name in `mgf.common.process` stays
  at `experimental` per AP-11. Promotion still requires one full
  MINOR cycle without a 🔴 Blocker filed.
- **Test pyramid is now well-formed:** unit (84 process module
  tests) → integration (5) → e2e (8) → smoke (7). Each layer
  catches a different class of failure; the layer markers
  encourage the right CI shape (smoke pre-flight, full suite on
  PR, e2e on nightly).

---

## [0.22.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.22.0/> · Tag: `v0.22.0`

> **Cutover guide:** [`docs/cutover/v0.22.0.md`](docs/cutover/v0.22.0.md)
> — `mgf.common.process` polish round. Reliability fixes + simplicity
> + one small additive method. **No behaviour breaks** for v0.21.0
> consumers; existing `run()` / `Service` / readiness predicates
> continue to work unchanged.

### Fixed

- **`Service.start()` early-exit detection.** Pre-fix: a child that
  crashed during startup (typo in command, missing dependency,
  segfault) caused `start()` to burn the full readiness `timeout_s`
  before raising a useless "probe X did not resolve" error. Post-fix:
  `start()` polls `proc.poll()` alongside the readiness probe and
  raises `ServiceNotReady` immediately when the child has exited
  before becoming ready. The returncode + stderr tail land in
  `last_error` for diagnosis. **Resolution time: from full timeout
  (e.g., 30s) to ~250ms** for the failure case.
- **Thread-safe `LogLineReady` snapshot.** Pre-fix: under high-volume
  child stdout (≥ thousands of lines per second), `LogLineReady`
  iterating its capture deque could race the streamer thread's
  `append`, raising `RuntimeError: deque mutated during iteration`.
  Post-fix: snapshots use `list(deque)` — atomic against the
  appending thread under CPython's GIL. Pinned by a 2000-line +
  1ms-poll-interval stress test.
- **Setup-failure rollback.** Pre-fix: any failure between `Popen`
  and the readiness-resolved log line could leak the launched
  process. Post-fix: `Service.start()` wraps streamer init +
  readiness wait in a `try/except BaseException` that calls the
  full teardown path before re-raising. The "no leaked process on
  failure" contract now covers every code path, including
  `KeyboardInterrupt`.

### Added

- **`Service.wait(timeout=None) -> int | None`** — block until the
  child exits naturally OR `timeout` elapses. Returns the
  `returncode` on natural exit, `None` on timeout (process still
  running). The escape hatch from `with Service(...)` for "start
  this service, let it run until it crashes or completes naturally"
  — without `wait()`, the only escape was `stop()`, which kills
  the child even if it was about to exit cleanly.

### Changed (internal — no surface impact)

- **Extracted `_streamer.resolve_redactor()` and `make_streamers()`
  helpers.** Deduplicates the parallel logic between
  `mgf.common.process.run()` and `Service.start()`. Both consumers
  now resolve redaction + create streamers through one call site
  each. ~30 LOC removed.
- **`_LineSnapshot` class → closure.** The single-method
  callable wrapper became a closure (3 lines vs 25). Behaviour
  identical; mutation surface smaller.
- **Tightened `get_active_redactor()`.** Single pass over
  `logging.root.handlers`; removed the try/except chain around the
  `_GLOBAL_CONTEXT` import path that was hiding logic — formatter
  introspection IS the discovery path; the AppContext walk added
  no value.
- **Replaced bespoke `_suppress_close_errors` class with stdlib
  `contextlib.suppress(Exception)`.** Three lines deleted; behaviour
  identical.
- **Dropped unused `Service._recent_lines` deque** (leftover from
  an earlier design that pre-dated the `_StreamCapture.snapshot`
  approach).

### Engineering

- **+11 new tests in `tests/unit/process/test_polish.py`** covering:
  early-exit detection (3 tests — fast resolution, stderr-tail
  diagnostics, normal-timeout still works), thread-race resilience
  under load (1 stress test), no-leak rollback regression
  (1 test), `Service.wait()` (3 tests — natural exit, timeout,
  before-start), shared helper sanity (3 tests). All v0.21.0
  tests continue to pass unchanged.
- **64 → 75 process tests; 1405 → 1416 total. Zero regressions.**
- **Stability tier:** every name in `mgf.common.process` stays at
  `experimental` per AP-11. The polish round does not promote;
  promotion still requires one full MINOR cycle without a 🔴
  Blocker filed.

---

## [0.21.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.21.0/> · Tag: `v0.21.0`

> **Cutover guide:** [`docs/cutover/archive/v0.21.0.md`](docs/cutover/archive/v0.21.0.md)
> — process management. New top-level surface
> `mgf.common.process` for unified subprocess + service-lifecycle
> orchestration in tools, scripts, and tests.

### Added

- **`mgf.common.process` package** (10 names; all `experimental`
  per AP-11) — unified subprocess + service-lifecycle orchestration:
  - **`run(command, *, ...)` → `ProcessResult`** — one-shot
    subprocess wrapper. List-only command (eliminates command-
    injection at the API surface), structured result with
    `command_id` correlation, timeout-with-grace SIGTERM→SIGKILL
    escalation, redaction-aware line-by-line log streaming
    through `mgf.process.<name>` (stdout=INFO, stderr=WARNING),
    POSIX process-group cascade by default. Default `check=True`
    raises typed errors on non-zero / signal exit.
  - **`Service(command, *, ready, ...)`** — long-lived process
    with a readiness predicate + clean shutdown. Context-manager
    protocol; `start()` blocks until ready or raises
    `ServiceNotReady`. **No leaked process on failure** — service
    is fully torn down before the readiness exception is raised.
    Idempotent `start()` / `stop()`.
  - **Readiness predicates** — `PortReady(host, port)`,
    `HttpReady(url, expected_status=200)`, `LogLineReady(pattern,
    stream)`, `CallableReady(predicate)`, `AllOf([...])`,
    `AnyOf([...])`. `ReadinessProbe` Protocol for custom
    predicates. `LogLineReady` peeks into `Service`'s captured
    line history (last 1000 per stream).
  - **POSIX-first.** `process_group=True` (default) launches in a
    new session group via `start_new_session=True`; SIGTERM
    cascades via `os.killpg`. Windows is best-effort — silent
    downgrade to per-PID kill; signal-cascade semantics differ.
- **`mgf.common.exceptions` Process-launch category** — 5 new
  names, all subclasses of `OperationError` so existing
  EH-04-shaped CLI top-level handlers catch them unchanged:
  - `ProcessError` (base) — carries `.command` + `.command_id`.
  - `ProcessTimeout` — carries `.timeout`.
  - `ProcessNonZeroExit` — carries `.returncode` + `.stderr_tail`
    (last 10 lines of stderr for diagnostics).
  - `ProcessSignaled` — POSIX-only; carries `.signal`.
  - `ServiceNotReady` — carries `.probe_description`,
    `.timeout`, `.last_error`.

### Changed

- **`mgf.common.exceptions.__all__`** grew from 31 → 36 names.
  Additive — every existing import keeps working.

### Documentation

- **`docs/recipes/process-management.md`** (~370 lines) —
  comprehensive recipe covering `run()` patterns (timeout,
  redaction, log correlation, env_extra, capture-output),
  `Service` patterns (Postgres-for-test with composite
  PortReady+LogLineReady, Uvicorn smoke, multi-service via
  `ExitStack`, custom readiness via `CallableReady`,
  composite-`AnyOf` for platform-dependent ready signals),
  failure modes, testing notes, cross-references, and
  out-of-scope reminders.
- **`PUBLIC_API.md`** — new `mgf.common.process` section
  (10 names) + 5 new ProcessError leaves in the exceptions
  table. Total surface: 178 → 193 names.

### Engineering

- **65 new tests** in `tests/unit/process/` covering:
  - `test_errors.py` — taxonomy + attribute pinning.
  - `test_run.py` — basic run, error paths, log streaming
    (per-line records, level mapping, command_id/pid extras),
    name option, duration accuracy.
  - `test_readiness.py` — every predicate (PortReady,
    HttpReady, LogLineReady, CallableReady, AllOf, AnyOf) +
    composite short-circuit + `wait_for_ready` semantics.
  - `test_service.py` — context-manager + explicit start/stop
    + idempotency + readiness-failure with no-leak guarantee
    + LogLineReady stdout/stderr matching + composite probes
    + property accessors. Uses Python one-liner subprocesses as
    "services" — zero external dependencies.
- **Stability tier:** every name ships `experimental` per AP-11.
  Promotion to `stable` after one full MINOR cycle without a 🔴
  Blocker filed against any name (rule AP-11). Two consumers
  exercising real workloads is the practical bar.
- **Out of scope (deliberate):** restart-on-crash supervision
  (use systemd / supervisord), backoff machinery, multi-service
  declarative orchestration (compose `Service` context managers
  via `ExitStack`), shell-string commands (lists only —
  command-injection-safe by construction), async API
  (`mgf.common.process._aio` deferred to future when a consumer
  needs it).

---

## [0.20.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.20.0/> · Tag: `v0.20.0`

> **Cutover guide:** [`docs/cutover/archive/v0.20.0.md`](docs/cutover/archive/v0.20.0.md)
> — documentation polish release. Three closures, all docs-only:
> framework-owned-logging recipe, `docs/standards/web/` subtree
> opening, and the documented-non-adoption principle.

**Code change:** none. `__version__` bumps from 0.19.0 → 0.20.0
to ship the new docs through the wheel's `_standards/` data
(per `[tool.hatch.build.targets.wheel.force-include]`). Standards
docs reach consumers via `mgf-common standards <topic>` so the
new paths need to land in a real release.

### Documentation

- **`docs/recipes/framework-owned-logging.md`** (closes
  [PAPER-25](FEEDBACK.md)) — promotes the
  `bootstrap(setup_logging=False)` pattern from v0.19.0's
  cutover guide to a permanent recipe with Django + FastAPI +
  Flask sections, a what-`setup_logging=False`-preserves table,
  and an explicit "what you give up" list. Cutover guides are
  time-bounded; framework-owned logging is the durable shape
  every web/API consumer needs on day one.
- **`docs/standards/web/README.md`** (closes
  [ASPIRE-03](FEEDBACK.md), Approach A — incremental) — opens
  the web-domain narrative subtree as a navigation page. Lists
  the cross-cutting recipes (currently scattered across
  cutover guides + `docs/recipes/`) and gives a
  read-in-order narrative for a new web consumer. Per-recipe
  promotion (cloud-native logging, framework config, http
  exceptions, bootstrap, stub-gaps, adoption-walk) trickles in
  over subsequent releases — each as one focused PR.
- **`docs/standards/principles/non-adoption-is-valid.md`**
  (closes [ASPIRE-04](FEEDBACK.md), "Magogi-foundation
  principle") — codifies "documented non-adoption is a
  first-class outcome of standards conformance." The framing
  behind every shipped carve-out (LOG-01, CONFIG-01,
  BOOTSTRAP-01); naming it gives newer contributors cover to
  decline a primitive when adoption would harm their context,
  AND nudges them to file the rationale upstream so the
  carve-out can be generalised. Three components: conscious
  decline, documented rationale, feedback if generalizable.
  Plus three worked examples (inthewords' LOG-01 / BOOTSTRAP-01
  pre-v0.19.0; PlasmaMapper's "small consumer" scope
  discipline).
- **`docs/standards/README.md`** — Conformance section grew a
  "Documented non-adoption preserves conformance" paragraph
  pointing at the new principle doc; "Per-kind subtrees"
  pointer to `web/README.md` added.

### Engineering

- The "incremental Approach A" structuring for ASPIRE-03 means
  v0.20.0 ships the front door; per-recipe promotion lands as
  small PRs across subsequent releases, tracked in ASPIRE-03's
  Retrospective field. This is the first release that uses an
  explicit promotion-roadmap checklist as a release artifact.
- v0.20.0 is the first **docs-only** release for `mgf-common`.
  It tests the release pipeline's tolerance for zero
  Python-surface-change releases.

---

## [0.19.0] — 2026-05-07

PyPI: <https://pypi.org/project/mgf-common/0.19.0/> · Tag: `v0.19.0`

> **Cutover guide:** [`docs/cutover/archive/v0.19.0.md`](docs/cutover/archive/v0.19.0.md)
> — composition + framework-native batch. Closes the v0.18.0
> HTTP-01 keystone (PAPER-24) and the Django adoption blocker
> (BOOTSTRAP-01).

### Fixed

- **`ExceptionTranslationMiddleware` now reads `HttpError.http_status`**
  (closes [PAPER-24](FEEDBACK.md)) — the v0.18.0 architectural
  batch shipped HTTP-01 (`HttpError` + 9 status-bearing concretes,
  each with `http_status: int` class attribute) AND the FastAPI
  middleware, but they didn't compose: a consumer rooting a domain
  exception in `HttpNotFound` still had to register every leaf in
  `status_map` for the middleware to find the 404. Resolution
  order is now: `status_map` (non-`AppError` ancestors) →
  class-declared `http_status` → `status_map[AppError]` catch-all
  → 500. Backward compatible — explicit `status_map` entries still
  win as the override seam. Regression introduced in v0.18.0;
  unblocks PlasmaMapper's `TenantNotFoundError(HttpNotFound)`
  rebase.

### Added

- **`bootstrap(setup_logging=True)` keyword-only flag** (closes
  [BOOTSTRAP-01](FEEDBACK.md) — Django adoption blocker, part 2)
  — when `False`, the StreamHandler + RotatingFileHandler install
  + per-component `level_overrides` are skipped. Identity, OTel,
  excepthooks, AppContext registration, and the bootstrap-log
  buffer replay still happen. For consumers whose framework owns
  the logging stack: Django (`LOGGING` dictConfig), FastAPI/
  uvicorn, Flask (`app.logger`), Pyramid. Default `True`
  preserves v0.18 behaviour for every existing consumer.
- **`mgf.common.alembic.configure_env` accepts `include_object=`
  + `include_schemas=`** (closes [PAPER-22](FEEDBACK.md)) —
  pass-through to `alembic.context.configure(...)`. Unblocks
  PostGIS / TimescaleDB / pgvector consumers who need to filter
  extension-owned tables (`spatial_ref_sys`,
  `_timescaledb_internal`, …) from `alembic revision
  --autogenerate`. Defaults `None` / `False` match alembic's own
  defaults — no behaviour change for current users.

### Changed

- **`settings_config()` defaults `dotenv_filtering="match_prefix"`**
  (closes [BOOTSTRAP-01](FEEDBACK.md) — Django adoption blocker,
  part 1) — `BaseAppSettings` subclasses now silently ignore
  `.env` keys that don't match their `env_prefix`, instead of
  routing them to `extra="forbid"` and raising `ValidationError`.
  This lets a `.env` be shared between mgf-common (`MGF_*`) and
  the consumer's framework (Django `SECRET_KEY`/`DB_*`,
  SQLAlchemy `DATABASE_URL`, Celery `CELERY_BROKER_URL`, …).
  **Behaviour change for consumers with `extra="allow"`** that
  were relying on the legacy permissive dotenv source to surface
  unprefixed keys onto the model — pass `dotenv_filtering=None`
  in your `model_config` override to restore the old behaviour.
  Every other `extra` mode is unaffected (`forbid` was raising
  before, `ignore` was already silent).

### Documentation

- **Editable-install caveat for `pytest_plugin`** (closes
  [PAPER-23](FEEDBACK.md)) — note added to
  `mgf.common.pytest_plugin` docstring + `docs/recipes/
  testing.md` explaining that `uv sync` against a sibling editable
  source target does not write the dist-info `entry_points.txt`,
  so the `pytest11` auto-registration is silently skipped. Opt
  in via `pytest_plugins = ["mgf.common.pytest_plugin"]` in
  consumer `tests/conftest.py`. PyPI-installed consumers are
  unaffected — the entry point fires during `pip install` /
  `uv pip install`.

### Engineering

- 4 new entries triaged + closed in one batch (PAPER-22, PAPER-23,
  PAPER-24, BOOTSTRAP-01); two from PlasmaMapper, one composite
  from inthewords. v0.19.0 is the first release that closed a
  same-release-introduced regression (PAPER-24 was a v0.18.0
  miss).

---

## [0.18.0] — 2026-05-06

PyPI: <https://pypi.org/project/mgf-common/0.18.0/> · Tag: `v0.18.0`

> **Cutover guide:** [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md)
> — first release using the cutover-guide pattern (REL-09
> delivery mechanism). Read it for migration instructions per
> closed entry.

### Added

- **`HttpError` category in `mgf.common.exceptions`** (closes
  [HTTP-01](FEEDBACK.md)) — eighth category in the typed-
  exception taxonomy. `HttpError` base + `HttpClientError`
  (4xx) + `HttpServerError` (5xx) + nine concrete leaves
  (`HttpBadRequest` 400, `HttpUnauthorized` 401, `HttpForbidden`
  403, `HttpNotFound` 404, `HttpConflict` 409, `HttpGone` 410,
  `HttpUnprocessable` 422, `HttpInternalServerError` 500,
  `HttpServiceUnavailable` 503). Each carries `http_status: int`
  as a class attribute. 12 new names in
  `mgf.common.exceptions.__all__`, all stability tier
  `experimental`. Distinct from `ResourceNotFoundError`
  (provider-domain) by deliberate non-inheritance.
- **Framework-native config carve-out in `CONFIGURATION.md`
  §0a** (closes [CONFIG-01](FEEDBACK.md)) — explicit
  recognition that Django (and Rails-equivalent) consumers
  can't simultaneously be CF-* compliant and use
  `from django.conf import settings`. CF-01 / CF-04 / CF-08 /
  CF-09 declared N/A under framework-native; CF-02 / CF-05 /
  CF-10 / CF-12 still apply with framework-native mechanics.
  Worked example for `inthewords` (Django) included.
- **Per-rule applicability column on standards docs** (closes
  [LOG-02](FEEDBACK.md), [CONFIG-01](FEEDBACK.md)) — `Applies
  to` column on every LG-* and CF-* rule with values from
  `{all, gui-app, service, fastapi, django, cli, library,
  consumer-owned-config}`. Per-kind compliance matrix added at
  the top of `LOGGING.md`'s Rules box. `mgf-common catch-up`
  and future audit tooling filter by detected kind so
  non-applicable rules don't surface as violations.
- **Cloud-native logging recipe** (closes
  [LOG-01](FEEDBACK.md)) — new doc at
  `docs/recipes/cloud-native-logging.md` walks the
  stdout-only `MgfSettings` shape, the JSON-formatter choice,
  the deployment-time check ("the platform IS my rotating
  file sink"), and the `inthewords` worked example
  (Daphne → systemd journal → Promtail → Grafana Cloud).
- **Cutover-guide pattern** (maintainer-initiated process
  improvement) — new directory `docs/cutover/` with one
  file per release that closes ≥1 FEEDBACK entry. The first
  cutover guide is `docs/cutover/archive/v0.18.0.md` (this release's
  artifact). `RELEASING.md` §7.0 + REL-09 updated to make
  cutover guides the canonical migration source; per-PAPER
  notification paragraphs become pointers into them.

### Changed

- **LG-06 wording** (closes [LOG-01](FEEDBACK.md)) — revised
  to parameterise on deployment topology. Three first-class
  branches: rotating local file (desktop / single-server),
  process stdout/stderr (cloud-native / container), or remote
  sink (OTLP / syslog / HTTP webhook). "Console only, no
  aggregation" is non-compliant in production regardless of
  branch. The desktop branch's prescription is unchanged
  (no regression for VManager-shape consumers).
- **`STRATEGIC_REVIEW.md` Priority 1 marked ✅ ACHIEVED**
  (closes [ASPIRE-02](FEEDBACK.md)) — `inthewords` and
  `PlasmaMapper` arrived as the second + third independent
  consumers. PAPER-06 (reference-consumer restructure)
  unblocks for follow-up. PAPER-10 (entry-point auto-discovery)
  receives "non-pain" evidence: `inthewords` reports they
  don't need entry-point discovery; PAPER-10 stays DEFERRED.

### Fixed

- **FastAPI kind template's quick-start no longer imports
  from a private module** (closes [PAPER-21](FEEDBACK.md)) —
  one-line fix: `from mgf.common._lifecycle import bootstrap`
  → `from mgf.common import bootstrap`. The same audit that
  flags private imports on consumer src/ now also lints every
  rendered kind-template (cli / fastapi / django / library /
  service) via the new `TestQuickStartBlocksNoClosedBoxLeaks`
  regression guard. Audit-and-template asymmetry can't recur.

### Migration

See [`docs/cutover/archive/v0.18.0.md`](docs/cutover/archive/v0.18.0.md) — one
§ per closed entry with concrete steps. Headlines:

- **Pin bump:** `mgf-common = ">=0.18,<0.19"`.
- **HTTP consumers:** lift exception hierarchies onto the new
  `HttpError` category (Approach A). Existing project-level
  `AppError` shims keep working unchanged; the migration is
  structural and lands when you're ready.
- **Django consumers:** re-read `CONFIGURATION.md` §0a; declare
  CF-* applicability per the worked example.
- **Cloud-native consumers:** read the new
  `cloud-native-logging.md` recipe.
- **FastAPI consumers scaffolded against 0.17.2:** re-run
  `mgf-common catch-up --apply` to refresh the auto-block; if
  you copy-pasted the v0.17.2 quick-start, replace the
  private-module import.

---

## [0.17.2] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.2/> · Tag: `v0.17.2`

### Added

- **`mgf-common catch-up` kind detection** (closes
  [PAPER-13](FEEDBACK.md) + [PAPER-17](FEEDBACK.md)).
  `_resolve_project_identity` now infers `--kind` heuristically
  when not supplied:
  - **With `pyproject.toml`:** parse `[project] dependencies`
    + `[project.scripts]`. `fastapi` → `fastapi`; `django` →
    `django`; `flask` → `service` (closest existing template
    kind); non-empty scripts without framework → `cli`;
    otherwise → `library`.
  - **Without `pyproject.toml`:** `manage.py` at root → `django`
    (Django's canonical layout marker). Other no-pyproject
    shapes fall through to `library`.
  - Default still `library` when no marker fires.
- **`mgf-common catch-up --apply` bootstraps `docs/CLAUDE.md`
  BEGIN/END markers** when the file exists but lacks them
  (closes [PAPER-16](FEEDBACK.md)). `_apply_bootstrap_claude_md_markers`
  reads the existing CLAUDE.md, backs it up to
  `.bak.<timestamp>`, writes a new file with the auto-block
  at the top + the original content verbatim below. The
  destructive `init-project --force` workaround is no longer
  the documented path; `catch-up --apply` is non-destructive.

### Changed

- **`mgf-common catch-up` pin audit emits a tailored info-level
  message for pip-tools layouts** (partial close of
  [PAPER-15](FEEDBACK.md)). When `pyproject.toml` is absent
  but `requirements/*.{txt,lock}` or a top-level
  `requirements.txt` is present, the audit acknowledges the
  layout and recommends the minimal-pyproject.toml workaround
  inline. Full pip-tools-manifest support (reading the pin
  from `requirements/base.txt`, four-gate audit from standalone
  config files) is deferred to a follow-up PAPER.

### Migration

None — every change is additive to existing CLI behaviour. No
public-Python-surface change. Re-run `mgf-common catch-up`
after upgrading to see the kind detection in action; existing
`--kind`-on-the-CLI invocations still take precedence over the
heuristic.

---

## [0.17.1] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.1/> · Tag: `v0.17.1`

### Fixed

- **`mgf-common catch-up` v0.1-pattern audit no longer walks
  `.venv/`** (closes [PAPER-14](FEEDBACK.md)). The audit's
  `_count_matches` walk now applies the same skip-dirs filter
  (`tests/`, `.venv/`, `__pycache__/`, `.pytest_cache/`,
  `.mypy_cache/`, `.ruff_cache/`, etc.) that the closed-box-leak
  audit already used. Without the filter, audits on Django-shape
  projects (no `src/`) walked into `.venv/` and counted
  mgf-common's own deprecated shim definitions as user-source
  v0.1 call sites — dozens of false positives.
- **`mgf-common doctor` first-line banner reflects the imported
  package's `__version__`** (closes [PAPER-18](FEEDBACK.md)),
  not `importlib.metadata.version()`. The metadata path goes
  stale during editable-install dev workflows; reading
  `__version__` from the imported package always matches the
  live source tree per AP-13's sync rule.
- **`mgf-common <subcommand>` no longer emits
  `UnconfiguredWarning`** (closes [PAPER-19](FEEDBACK.md)). The
  CLI's `main()` calls `_set_identity("mgf-common-cli",
  __version__)` before dispatch, so subcommands that read
  identity (`explain`, `doctor`, future settings-aware
  surfaces) get the right values without firing the
  warning chain or printing `vunknown` placeholders. Lighter
  than the filing's suggested `bootstrap_for_test` because
  diagnostic CLIs MUST stay filesystem-side-effect-free.
- **`mgf-common catch-up --apply` no longer rewrites the
  pyproject pin against an editable install** (closes
  [PAPER-20](FEEDBACK.md)). Editable installs (e.g., `pip
  install -e ../mgf_common`, `[tool.uv.sources]` overrides) can
  run AHEAD of the latest PyPI-published version; rewriting a
  consumer's pin to the editable `__version__` produced an
  unsatisfiable pin on plain-PyPI resolvers. The audit row
  still surfaces staleness; the consumer bumps the pin by hand
  against `pip index versions mgf-common`.

### Migration

None — every change is a fix-in-place to existing CLI
behaviour. Re-run `mgf-common catch-up` after upgrading; you
may see fewer false positives on the v0.1-pattern row, a
correct version string on `doctor`'s banner, and clean stderr
on `explain`. Editable-install consumers see the audit warn
without auto-rewriting the pin.

---

## [0.17.0] — 2026-05-05

PyPI: <https://pypi.org/project/mgf-common/0.17.0/> · Tag: `v0.17.0`

### Added

- **`mgf-common catch-up` closed-box-leak audit** — a new audit
  row that AST-walks the consumer's `src/` and flags imports of
  `mgf-common`'s private surface. Closes [PAPER-08](FEEDBACK.md).

  Three leak shapes detected:

  1. `from mgf.common._x import …`     — module itself private
  2. `from mgf.common.X import _y`     — public module, private name
  3. `import mgf.common._x`            — direct private-module import

  The consumer's `tests/` directory is exempt (legitimate
  test-helper imports inside `_internal_test_helpers/` style
  directories aren't violations). Caches and vendored
  directories (`.venv/`, `__pycache__/`, `.pytest_cache/`,
  `.mypy_cache/`, `.ruff_cache/`, `node_modules/`, `dist/`,
  `build/`, `.tox/`) are skipped.

  Known private→public migrations are named inline in the
  warning so the audit doesn't just say "stop" — it says "do
  this instead." Today's mapping:

  | Private | Public (since) |
  |---|---|
  | `_default_log_path` | `mgf.common.observability.default_log_path` (v0.13.0) |
  | `_crash_dir` | `mgf.common.observability.default_crash_dir` (v0.13.0) |

  Extend `_PRIVATE_TO_PUBLIC` in `_catch_up.py` whenever a
  future PAPER-07-shaped private→public promotion happens.

### Migration

Consumers running `mgf-common catch-up` after upgrading will
see one new audit row. If you have any closed-box leaks in
your `src/` (you might — VManager had one until v0.13.0),
they surface now with the file:line and the suggested public
replacement. Like the existing `v0.1-pattern usage` row, the
fix is structural — `catch-up --apply` does NOT auto-rewrite
import statements; the consumer migrates by hand.

---

## [0.16.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.16.0/> · Tag: `v0.16.0`

### Changed

- **Renamed** `docs/standards/SECURITY.md` →
  `docs/standards/SECURITY_STANDARD.md` to remove the
  duplicate-name collision with the repository-root
  `SECURITY.md` (vulnerability-reporting policy). The two files
  serve genuinely different purposes — SC-12 mandates the root
  policy file; the engineering standard now has a name that
  reflects what it is. The wheel's bundled-data path changes
  in lockstep: `mgf/common/_standards/SECURITY.md` →
  `mgf/common/_standards/SECURITY_STANDARD.md`.

### Migration

The CLI alias `security` keeps working unchanged — typing
`mgf-common standards security` still resolves to the engineering
standard. Both lower- (`security`) and upper-case (`SECURITY`)
inputs route through the alias map to the new canonical filename.

If your tooling parses `mgf-common standards --paths security`
output, the printed path now ends in `SECURITY_STANDARD.md`
rather than `SECURITY.md`. Update any consumer scripts that
hard-coded the old filename.

```bash
# Before — outputs .../SECURITY.md
$ mgf-common standards --paths security

# After (0.16+) — outputs .../SECURITY_STANDARD.md
$ mgf-common standards --paths security
```

The `mgf-common standards security` (no `--paths`) print-content
behaviour is unchanged.

---

## [0.15.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.15.0/> · Tag: `v0.15.0` · SHA256 (wheel): `ad14d4ed17ca…`

### Added

- **`mgf.common.exceptions.AppConfigErrorKind`** — `StrEnum`
  discriminator for `AppConfigError` failure modes. Members:
  `FILE_NOT_FOUND`, `IO_READ_FAILED`, `JSON_PARSE_FAILURE`,
  `YAML_PARSE_FAILURE`, `NON_DICT_ROOT`, `MISSING_VERSION`,
  `UNSUPPORTED_VERSION`, `MIGRATE_FAILED`, `SCHEMA_VALIDATION`.
  String values are stable contract — usable as a machine-readable
  kind in serialised crash reports.
- **`AppConfigError.kind: AppConfigErrorKind | None`** — class-level
  attribute (default `None`). Every load-path raise in
  `mgf.common.versioned._store` now sets `kind`. Consumers stop
  string-matching on private message markers and discriminate via
  `match e.kind:`. Closes [PAPER-11](FEEDBACK.md).

### Migration

For consumers translating `AppConfigError` to project-flavoured
wording — replace string-match discriminators with
pattern-matching on `kind`:

```python
# Before — fragile to upstream rewording
except AppConfigError as e:
    raw = str(e).lower()
    if "is malformed (json)" in raw:
        raise OperationError("... is unreadable") from e
    elif "has version=" in raw or "is missing a typed" in raw:
        raise OperationError("... has unsupported schema_version") from e
    else:
        raise OperationError(f"... is malformed: {e}") from e

# After — typed, exhaustive, stable
except AppConfigError as e:
    match e.kind:
        case AppConfigErrorKind.JSON_PARSE_FAILURE | AppConfigErrorKind.YAML_PARSE_FAILURE:
            raise OperationError("... is unreadable") from e
        case AppConfigErrorKind.UNSUPPORTED_VERSION | AppConfigErrorKind.MISSING_VERSION:
            raise OperationError("... has unsupported schema_version") from e
        case _:
            raise OperationError(f"... is malformed: {e}") from e
```

Backward-compatible: every existing `except AppConfigError:` clause
keeps catching unchanged. Save-path raises don't yet opt in — file a
`PAPER-NN` if you hit pain there.

---

## [0.14.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.14.0/> · Tag: `v0.14.0` · SHA256 (wheel): `5c172712f454…`

### Added

- **`VersionedFileStore[T](..., tolerate_missing_version=False)`** —
  new constructor flag. Default `False` keeps today's
  strict-by-default contract: missing `version:` field raises
  `AppConfigError`. `True` opts in to a grace mode for consumers
  with **pre-versioning legacy files**: a missing field logs one
  `WARNING` via the `mgf.common.versioned` logger and is treated as
  `current_version` (the migrate callback is NOT called — there is
  no version to migrate from). The next `save()` stamps the file,
  so the warning fires at most once per file. Files where the field
  is *present but not an int* still raise (corruption signal, not
  a legacy file). Closes [PAPER-09](FEEDBACK.md).

### Migration

Consumers with bespoke "missing means current" handling for
pre-versioning YAML/JSON satellite files can replace it with the
opt-in flag:

```python
store = VersionedFileStore(
    path,
    schema=ProfileFile,
    current_version=2,
    migrate=migrate,
    tolerate_missing_version=True,   # missing → v2 with WARNING
)
```

The grace-mode warning from `mgf.common.versioned` replaces any
hand-rolled warning the consumer was emitting.

---

## [0.13.0] — 2026-05-02

PyPI: <https://pypi.org/project/mgf-common/0.13.0/> · Tag: `v0.13.0` · SHA256 (wheel): `02d8ed8bc4b1…`

### Added

- **`mgf.common.observability.default_log_path`** — public helper
  that resolves to `<state>/<app>/logs/<app>.log`, where
  `<state>` honours `XDG_STATE_HOME` and falls back to
  `~/.local/state`. This is where `setup_logging` writes when
  called without an explicit `log_file=`. Surface in your UI for
  "where do my logs live?" diagnostics.
- **`mgf.common.observability.default_crash_dir`** — public helper
  resolving to `<state>/<app>/crashes/`. Where `report_now` writes
  serialised crash reports.
- **`mgf.common.observability.default_state_dir`** — public helper
  resolving to `<state>/<app>/`, the parent of both. The directory
  is NOT created — callers `mkdir` themselves if needed.

All three are lazy (resolve at call time, rule **CF-04**); per-test
isolation when monkeypatching `HOME` / `XDG_STATE_HOME` keeps
working. Closes [PAPER-07](FEEDBACK.md).

### Deprecated

- **`mgf.common.observability.logging_setup._default_log_path`** —
  was a closed-box leak (consumers had no public alternative). Now
  a deprecated shim that delegates to `default_log_path` and emits
  `MgfDeprecationWarning`. Removed in a future release.
- **`mgf.common.observability.crash_reporter._crash_dir`** — same
  shape; deprecated shim delegating to `default_crash_dir`.

### Migration

```python
# Before — reaching into the private surface (closed-box leak)
from mgf.common.observability.logging_setup import _default_log_path
from mgf.common.observability.crash_reporter import _crash_dir

# After — public API
from mgf.common.observability import default_log_path, default_crash_dir
```

The underscored names continue to work for one cycle but emit
`MgfDeprecationWarning` per call.

---

## Pre-`0.13.0`

Earlier releases (`0.1.0`, `0.3.0`, `0.4.0`, `0.4.1`, `0.4.2`,
`0.11.1`, `0.11.3`, `0.12.0`) were cut before this CHANGELOG was
introduced. The audit trail is in `git log` and the
[PyPI release pages](https://pypi.org/project/mgf-common/#history).

Notable ones (most relevant for consumers upgrading):

- **`0.12.0`** (2026-05-01) — final release before the CHANGELOG.
  Public surface that ships in this release matches the wheel on
  PyPI (`pip show mgf-common` against an installed `0.12.0`); note
  that **`mgf.common.versioned`** was added to master *after* the
  `0.12.0` PyPI cut — consumers reading `PUBLIC_API.md` from a
  master checkout may see entries that 0.12.0 doesn't ship. (This
  asymmetry is the root cause of [PAPER-12](FEEDBACK.md); the
  `PUBLIC_API.md` banner and the doc at
  [`docs/standards/RELEASING.md`](docs/standards/RELEASING.md)
  prevent its recurrence going forward.)

[Unreleased]: https://codeberg.org/magogi-admin/mgf_common/compare/v0.18.0...HEAD
[0.18.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.18.0
[0.17.2]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.2
[0.17.1]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.1
[0.17.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.17.0
[0.16.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.16.0
[0.15.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.15.0
[0.14.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.14.0
[0.13.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.13.0
