# © 2019 ForgeFlow S.L. -
# Jordi Ballester Alomar
# © 2019 Serpent Consulting Services Pvt. Ltd. - Sudhir Arya
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from odoo.exceptions import ValidationError
from odoo.fields import Command, Domain

from odoo.addons.operating_unit.tests.common import OperatingUnitCommon


class TestSaleOperatingUnit(OperatingUnitCommon):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.sale_model = cls.env["sale.order"]
        cls.sale_line_model = cls.env["sale.order.line"]
        cls.sale_team_model = cls.env["crm.team"]
        cls.acc_move_model = cls.env["account.move"]
        cls.product_model = cls.env["product.product"]
        cls.payment_model = cls.env["sale.advance.payment.inv"]
        # Company
        cls.grp_sale_user = cls.env.ref("sales_team.group_sale_manager")
        cls.grp_acc_user = cls.env.ref("account.group_account_invoice")
        # Payment Term
        cls.pay = cls.env.ref("account.account_payment_term_immediate")
        # Customer
        cls.customer = cls.env["res.partner"].create({"name": "Test Customer"})
        # Price list
        cls.pricelist = cls.env["product.pricelist"].search(Domain.TRUE, limit=1)
        # Products
        cls.product1 = cls.env["product.product"].create(
            {"name": "Test product", "type": "consu", "invoice_policy": "order"}
        )
        # Update users
        cls.user1.write(
            {
                "group_ids": [
                    Command.link(cls.grp_sale_user.id),
                    Command.link(cls.grp_acc_user.id),
                ],
                "operating_unit_ids": [
                    Command.link(cls.ou1.id),
                    Command.link(cls.b2c.id),
                ],
            }
        )
        cls.user2.write(
            {
                "group_ids": [
                    Command.link(cls.grp_sale_user.id),
                    Command.link(cls.grp_acc_user.id),
                ],
                "default_operating_unit_id": [],
            }
        )

        # Create sales team OU1
        cls.sale_team_ou1 = cls._create_sale_team(cls.user1.id, cls.ou1)

        # Create sales team OU2
        cls.sale_team_b2c = cls._create_sale_team(cls.user2.id, cls.b2c)

        # Create Sale Order1
        cls.sale1 = cls._create_sale_order(
            cls.user1.id,
            cls.customer,
            cls.product1,
            cls.pricelist,
            cls.sale_team_ou1,
        )
        # Create Sale Order2
        cls.sale2 = cls._create_sale_order(
            cls.user2.id,
            cls.customer,
            cls.product1,
            cls.pricelist,
            cls.sale_team_b2c,
        )

    @classmethod
    def _create_sale_team(cls, uid, operating_unit):
        """Create a sale team."""
        team = (
            cls.sale_team_model.with_user(uid)
            .with_context(mail_create_nosubscribe=True)
            .create(
                {
                    "name": operating_unit.name,
                    "operating_unit_id": operating_unit.id,
                    "company_id": operating_unit.company_id.id,
                }
            )
        )
        return team

    @classmethod
    def _create_sale_order(cls, uid, customer, product, pricelist, team):
        """Create a sale order."""
        sale = cls.sale_model.with_user(uid).create(
            {
                "partner_id": customer.id,
                "partner_invoice_id": customer.id,
                "partner_shipping_id": customer.id,
                "pricelist_id": pricelist.id,
                "team_id": team.id,
                "operating_unit_id": team.operating_unit_id.id,
            }
        )
        cls.sale_line_model.with_user(uid).create(
            {
                "order_id": sale.id,
                "product_id": product.id,
                "name": "Sale Order Line",
                "product_uom_qty": 1,
            }
        )
        return sale

    def _confirm_sale(self, sale):
        sale.action_confirm()
        sale_context = {
            "active_model": "sale.order",
            "active_ids": [sale.id],
            "active_id": sale.id,
        }
        # Let's do an invoice with invoiceable lines
        payment = (
            self.env["sale.advance.payment.inv"]
            .with_context(**sale_context)
            .create({"advance_payment_method": "delivered"})
        )
        res = payment.create_invoices()
        invoice_id = res["res_id"]
        return invoice_id

    def test_security(self):
        """Test Sale Operating Unit"""
        # User 2 is only assigned to Operating Unit B2C, and cannot
        # Access Sales order from Main Operating Unit.
        sale = self.sale_model.with_user(self.user2.id).search(
            Domain.AND(
                [
                    Domain("id", "=", self.sale1.id),
                    Domain("operating_unit_id", "=", self.ou1.id),
                ]
            )
        )
        self.assertEqual(
            sale.ids, [], f"User 2 should not have access to OU {self.ou1.name}"
        )
        # Confirm Sale1
        self._confirm_sale(self.sale1)
        # Confirm Sale2
        b2c_invoice_id = self._confirm_sale(self.sale2)
        # Checks that invoice has OU b2c
        b2c = self.acc_move_model.with_user(self.user2.id).search(
            Domain.AND(
                [
                    Domain("id", "=", b2c_invoice_id),
                    Domain("operating_unit_id", "=", self.b2c.id),
                ]
            )
        )
        self.assertNotEqual(b2c.ids, [], "Invoice should have b2c OU")

    def test_security_2(self):
        """Test Sale Operating Unit"""
        # User 2 is only assigned to Operating Unit B2C, and cannot
        # Access Sales order from Main Operating Unit.
        sale = self.sale_model.with_user(self.user2.id).search(
            Domain.AND(
                [
                    Domain("id", "=", self.sale1.id),
                    Domain("operating_unit_id", "=", self.ou1.id),
                ]
            )
        )
        self.assertEqual(
            sale.ids, [], f"User 2 should not have access to OU {self.ou1.name}"
        )

        sale = self.sale_model.with_user(self.user2.id).search(
            Domain.AND(
                [
                    Domain("id", "=", self.sale2.id),
                    Domain("operating_unit_id", "=", self.b2c.id),
                ]
            )
        )

        self.assertEqual(
            len(sale.ids), 1, f"User 1 should have access to OU {self.b2c.name}"
        )

    def test_check_sales_order_operating_unit(self):
        """Test that changing the operating unit of a sales team
        with existing sale orders raises an error."""
        with self.assertRaises(ValidationError):
            self.sale_team_ou1.operating_unit_id = self.b2c.id

    def test_compute_operating_unit_id(self):
        """Test that changing the sales team updates the
        operating unit in sale order."""
        sale_order = self.sale_model.create(
            {
                "partner_id": self.customer.id,
                "team_id": self.sale_team_ou1.id,
            }
        )
        self.assertEqual(sale_order.operating_unit_id, self.ou1)
        sale_order.team_id = self.sale_team_b2c.id
        self.assertEqual(sale_order.operating_unit_id, self.b2c)

    def test_compute_team_id(self):
        """Test that sales team resets if its operating unit does not match."""
        sale_order = self.sale_model.create(
            {
                "partner_id": self.customer.id,
                "operating_unit_id": self.ou1.id,
                "team_id": self.sale_team_ou1.id,
            }
        )
        self.assertEqual(sale_order.team_id, self.sale_team_ou1)
        sale_order.operating_unit_id = self.b2c.id
        self.assertFalse(
            sale_order.team_id, "Team should reset when operating unit mismatches"
        )

    def test_check_team_operating_unit_violation(self):
        """Test that a ValidationError is raised when the team
        and operating unit do not match."""
        with self.assertRaises(ValidationError):
            self.sale_model.create(
                {
                    "partner_id": self.customer.id,
                    "operating_unit_id": self.ou1.id,
                    "team_id": self.sale_team_b2c.id,
                }
            )
