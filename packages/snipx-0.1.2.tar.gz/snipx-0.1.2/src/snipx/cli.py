"""
snipx - Instantly fetch and set up code snippets for your projects.
Usage:
    snipx help
    snipx list
    snipx list <category>
    snipx get <name>
    snipx guide
"""

import os
import sys
import shutil
import webbrowser
import importlib.resources as pkg_resources

# ─── Catalog ────────────────────────────────────────────────────────────────

CATALOG = {
    # ── Java / RMI ──────────────────────────────────────────────────────────
    "rmi": {
        "category": "java",
        "title": "RMI – Remote Method Invocation (Adder)",
        "files": ["Adder.java", "AdderRemote.java", "MyServer.java", "MyClient.java"],
        "desc": "Assignment 1 – RMI communication with a remote Adder service.",
    },
    # ── CORBA ───────────────────────────────────────────────────────────────
    "corba": {
        "category": "java",
        "title": "CORBA – Calculator Application",
        "files": ["Calc.idl", "CalcServer.java", "CalcClient.java"],
        "desc": "Assignment 2 – CORBA-based distributed calculator (ADD/SUB/MUL/DIV).",
    },
    # ── MPI ─────────────────────────────────────────────────────────────────
    "mpi": {
        "category": "c",
        "title": "MPI – Parallel Array Sum (4 cores)",
        "files": ["Array.c"],
        "desc": "Assignment 3 – Add 20 numbers using MPI across 4 processes.",
    },
    # ── Clock Sync ──────────────────────────────────────────────────────────
    "clocksync": {
        "category": "cpp",
        "title": "Berkeley Clock Synchronisation",
        "files": ["server.cpp", "client.cpp"],
        "desc": "Assignment 4 – Berkeley algorithm: master server + multiple clients.",
    },
    # ── Mutual Exclusion ────────────────────────────────────────────────────
    "mutex": {
        "category": "java",
        "title": "Token-Based Mutual Exclusion",
        "files": ["MutualServer.java", "ClientOne.java", "ClientTwo.java"],
        "desc": "Assignment 5 – Token ring mutual exclusion using sockets.",
    },
    # ── Leader Election ─────────────────────────────────────────────────────
    "bully": {
        "category": "java",
        "title": "Bully Algorithm – Leader Election",
        "files": ["BullyAlgo.java"],
        "desc": "Assignment 6a – Bully algorithm for coordinator election.",
    },
    "ring": {
        "category": "java",
        "title": "Ring Algorithm – Leader Election",
        "files": ["Ring.java"],
        "desc": "Assignment 6b – Ring algorithm for coordinator election.",
    },
    # ── Web Service ─────────────────────────────────────────────────────────
    "webservice": {
        "category": "dotnet",
        "title": "ASP.NET Web Service + Consumers",
        "files": ["FirstService.asmx", "WebApp.aspx", "WinApp.cs"],
        "desc": "Assignment 7 – Simple SOAP web service with web & Windows consumers.",
    },
    # ── Mini Project ────────────────────────────────────────────────────────
    "gameserver": {
        "category": "go",
        "title": "Distributed Multiplayer Game – Server",
        "files": ["game_server.go", "game_manager.go", "deployment.yaml"],
        "desc": "Assignment 8 – Go UDP/TCP game server + Kubernetes deployment.",
    },
    "gameclient": {
        "category": "csharp",
        "title": "Distributed Multiplayer Game – Unity Client",
        "files": ["GameClient.cs"],
        "desc": "Assignment 8 – Unity3D C# UDP client for the game server.",
    },
}

CATEGORIES = {
    "java":   "Java / RMI / CORBA / Sockets",
    "c":      "C with MPI (HPC)",
    "cpp":    "C++ Socket Programming",
    "dotnet": ".NET / ASP.NET Web Services",
    "go":     "Go – Distributed Game Server",
    "csharp": "C# Unity3D Client",
}

# ─── Helpers ────────────────────────────────────────────────────────────────

BOLD   = "\033[1m"
GREEN  = "\033[92m"
CYAN   = "\033[96m"
YELLOW = "\033[93m"
RED    = "\033[91m"
RESET  = "\033[0m"

def _banner():
    print(f"""
{CYAN}{BOLD}╔══════════════════════════════════════════╗
║        snipx  –  Code Snippet Fetcher    ║
╚══════════════════════════════════════════╝{RESET}
""")

def _out_dir():
    """Resolve output directory from env var or cwd/ds_code."""
    return os.environ.get("DSPRACT_DIR", os.path.join(os.getcwd(), "ds_code"))

def _asset_path(filename: str) -> str:
    """Return absolute path to a bundled asset file."""
    base = os.path.dirname(__file__)
    return os.path.join(base, "assignments", filename)

def _copy_files(key: str) -> None:
    entry   = CATALOG[key]
    out_dir = os.path.join(_out_dir(), key)
    os.makedirs(out_dir, exist_ok=True)

    copied = []
    missing = []
    for fname in entry["files"]:
        src = _asset_path(fname)
        dst = os.path.join(out_dir, fname)
        if os.path.exists(src):
            shutil.copy2(src, dst)
            copied.append(fname)
        else:
            missing.append(fname)

    if copied:
        print(f"{GREEN}✔  Copied to {out_dir}/{RESET}")
        for f in copied:
            print(f"   • {f}")
    if missing:
        print(f"{YELLOW}⚠  Source files not bundled yet: {missing}{RESET}")
        print(f"   Add them to snipx/assignments/ before publishing.\n")

# ─── Commands ───────────────────────────────────────────────────────────────

def cmd_help():
    _banner()
    print(f"{BOLD}USAGE{RESET}")
    print("  snipx help")
    print("  snipx list [category]")
    print("  snipx get  <assignment>")
    print("  snipx guide                 ← open the full HTML run guide in browser")
    print()
    print(f"{BOLD}CATEGORIES{RESET}")
    for cat, desc in CATEGORIES.items():
        print(f"  {CYAN}{cat:<10}{RESET}  {desc}")
    print()
    print(f"{BOLD}ENVIRONMENT{RESET}")
    print("  DSPRACT_DIR   Override output directory (default: ./ds_code/)")
    print()
    print(f"{BOLD}EXAMPLES{RESET}")
    print("  snipx list")
    print("  snipx list java")
    print("  snipx get rmi")
    print("  snipx get clocksync")
    print()


def cmd_list(category: str = None):
    _banner()
    filtered = {
        k: v for k, v in CATALOG.items()
        if category is None or v["category"] == category
    }
    if not filtered:
        print(f"{RED}No assignments found for category '{category}'.{RESET}")
        print(f"Available: {', '.join(CATEGORIES)}")
        return

    current_cat = None
    for key, meta in filtered.items():
        if meta["category"] != current_cat:
            current_cat = meta["category"]
            print(f"{BOLD}{YELLOW}── {CATEGORIES[current_cat]} ──{RESET}")
        print(f"  {GREEN}{key:<15}{RESET}  {meta['title']}")
        print(f"  {'':15}  {meta['desc']}")
    print()


def cmd_get(key: str):
    if key not in CATALOG:
        print(f"{RED}✘  Unknown assignment '{key}'. Run 'snipx list' to see all.{RESET}")
        sys.exit(1)

    meta = CATALOG[key]
    print(f"\n{CYAN}Fetching:{RESET} {meta['title']}")
    print(f"  {meta['desc']}\n")
    _copy_files(key)
    print(f"\n{BOLD}Run instructions:{RESET}")
    _print_run_hint(key)
    print()


def _print_run_hint(key: str):
    hints = {
        "rmi":        "javac *.java  →  rmiregistry 5000  →  java MyServer  →  java MyClient",
        "corba":      "idlj -fall Calc.idl  →  javac *.java WssCalculator/*.java  →  orbd ... →  java CalcServer ... → java CalcClient ...",
        "mpi":        "mpicc Array.c -o array  →  mpirun -np 4 ./array",
        "clocksync":  "g++ server.cpp -o server -std=c++11  →  g++ client.cpp -o client -std=c++11  →  ./server  →  ./client",
        "mutex":      "javac *.java  →  java MutualServer  →  java ClientOne  →  java ClientTwo",
        "bully":      "javac BullyAlgo.java  →  java BullyAlgo",
        "ring":       "javac Ring.java  →  java Ring",
        "webservice": "Deploy FirstService.asmx to IIS  →  WSDL → csc → compile WinApp.cs",
        "gameserver": "go run game_server.go  →  go run game_manager.go  →  kubectl apply -f deployment.yaml",
        "gameclient": "Open in Unity3D project as MonoBehaviour component.",
    }
    print(f"  {YELLOW}{hints.get(key, 'Run: snipx guide  to open the full HTML run guide.')}{RESET}")
    print(f"  {CYAN}Tip: run 'snipx guide' to open the complete step-by-step HTML guide.{RESET}")

def cmd_guide():
    """Copy the HTML run guide to cwd and open it in the default browser."""
    _banner()
    guide_src = _asset_path("Practical_Run_Guide.html")
    guide_dst = os.path.join(os.getcwd(), "Practical_Run_Guide.html")

    if not os.path.exists(guide_src):
        print(f"{RED}✘  Guide file not found in package. Try reinstalling: pip install --upgrade snipx{RESET}")
        sys.exit(1)

    shutil.copy2(guide_src, guide_dst)
    print(f"{GREEN}✔  Guide copied to:{RESET} {guide_dst}")
    print(f"{CYAN}   Opening in your browser…{RESET}\n")
    webbrowser.open(f"file:///{guide_dst.replace(os.sep, '/')}")
    print(f"{BOLD}Tip:{RESET} Print the page (Ctrl+P) and choose 'Save as PDF' to get a PDF copy.\n")


# ─── Entry Point ─────────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("help", "--help", "-h"):
        cmd_help()

    elif args[0] == "list":
        cat = args[1] if len(args) > 1 else None
        cmd_list(cat)

    elif args[0] == "get":
        if len(args) < 2:
            print(f"{RED}Usage: snipx get <assignment>{RESET}")
            sys.exit(1)
        cmd_get(args[1])

    elif args[0] == "guide":
        cmd_guide()

    else:
        print(f"{RED}Unknown command '{args[0]}'. Try 'snipx help'.{RESET}")
        sys.exit(1)


if __name__ == "__main__":
    main()
