// Assignment 8 – Distributed Multiplayer Game: Unity3D C# UDP Client
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

public class GameClient : MonoBehaviour
{
    private UdpClient udpClient;
    private string serverIP = "127.0.0.1";
    private int udpPort = 9000;

    void Start()
    {
        udpClient = new UdpClient();
        udpClient.Connect(serverIP, udpPort);
        Debug.Log("Connected to game server at " + serverIP + ":" + udpPort);
    }

    void Update()
    {
        string input = "MOVE:RIGHT";
        byte[] data = Encoding.UTF8.GetBytes(input);
        udpClient.Send(data, data.Length);

        if (udpClient.Available > 0)
        {
            IPEndPoint ep = new IPEndPoint(IPAddress.Any, 0);
            byte[] recv = udpClient.Receive(ref ep);
            string gameState = Encoding.UTF8.GetString(recv);
            Debug.Log("Server state: " + gameState);
        }
    }

    void OnDestroy()
    {
        udpClient.Close();
    }
}
