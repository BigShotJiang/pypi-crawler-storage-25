// Assignment 7 – Windows Application Consumer for FirstService web service
using System;
using System.IO;

namespace SvcConsumer
{
    class SvcEater
    {
        public static void Main(String[] args)
        {
            FirstService mySvc = new FirstService();
            Console.WriteLine(
                "Calling Hello World Service: " + mySvc.SayHello());
            Console.WriteLine(
                "Calling Add(2, 3) Service: " + mySvc.Add(2, 3).ToString());
        }
    }
}

/*
 * Compile and Run Commands:
 *
 * # Generate proxy from WSDL
 * c:> WSDL http://localhost/MyWebServices/FirstService.asmx?WSDL
 *
 * # Compile proxy to DLL
 * c:> csc /t:library FirstService.cs
 *
 * # Copy DLL to IIS bin folder: C:\MyWebServices\bin\
 *
 * # Compile Windows App
 * c:> csc /r:FirstService.dll WinApp.cs
 *
 * # Run Windows App
 * c:> WinApp.exe
 */
