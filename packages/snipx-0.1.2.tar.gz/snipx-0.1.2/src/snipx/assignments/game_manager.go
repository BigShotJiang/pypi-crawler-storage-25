// Assignment 8 – Distributed Multiplayer Game: Go HTTP/WebSocket Game Manager
package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
)

type MatchRequest struct {
	Player1 string `json:"player1"`
	Player2 string `json:"player2"`
}

func createGameHandler(w http.ResponseWriter, r *http.Request) {
	var req MatchRequest
	json.NewDecoder(r.Body).Decode(&req)

	cmd := exec.Command(
		"kubectl",
		"run",
		"game-"+req.Player1,
		"--image=game-server:latest",
		"--restart=Never",
	)
	if err := cmd.Run(); err != nil {
		http.Error(w, "Failed to start game pod", 500)
		return
	}
	fmt.Fprintf(w, `{"status":"started","players":["%s","%s"]}`,
		req.Player1, req.Player2)
}

func wsHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "WebSocket endpoint active")
}

func main() {
	http.HandleFunc("/creategame", createGameHandler)
	http.HandleFunc("/ws", wsHandler)
	fmt.Println("Game Manager listening on :8080")
	http.ListenAndServe(":8080", nil)
}
