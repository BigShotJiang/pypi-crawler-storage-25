<%@ Page Language="C#" %>
<%-- Assignment 7 – Web-Based Consumer for the FirstService web service --%>

<script runat="server">
void runSrvice_Click(Object sender, EventArgs e)
{
    FirstService mySvc = new FirstService();
    Label1.Text = mySvc.SayHello();
    Label2.Text = mySvc.Add(
        Int32.Parse(txtNum1.Text),
        Int32.Parse(txtNum2.Text)
    ).ToString();
}
</script>

<html>
<body>
<form runat="server">
    <p>
        First Number to Add:
        <asp:TextBox id="txtNum1" runat="server" Width="43px">4</asp:TextBox>
    </p>
    <p>
        Second Number To Add:
        <asp:TextBox id="txtNum2" runat="server" Width="44px">5</asp:TextBox>
    </p>
    <p>
        Hello world Service:
        <asp:Label id="Label1" runat="server">Label</asp:Label>
    </p>
    <p>
        Add Service:
        <asp:Label id="Label2" runat="server">Label</asp:Label>
    </p>
    <asp:Button id="runSrvice"
        onclick="runSrvice_Click"
        runat="server"
        Text="Execute">
    </asp:Button>
</form>
</body>
</html>
