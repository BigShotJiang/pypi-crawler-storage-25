// Assignment 6b – Ring Algorithm for Leader Election
import java.util.Scanner;

public class Ring {
    public static void main(String[] args) {
        int temp, i, j;
        Rr proc[] = new Rr[10];
        for (i = 0; i < proc.length; i++)
            proc[i] = new Rr();

        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of process: ");
        int num = in.nextInt();

        for (i = 0; i < num; i++) {
            proc[i].index = i;
            System.out.println("Enter the id of process: ");
            proc[i].id = in.nextInt();
            proc[i].state = "active";
            proc[i].f = 0;
        }

        // Sort processes by id (bubble sort)
        for (i = 0; i < num - 1; i++)
            for (j = 0; j < num - 1; j++)
                if (proc[j].id > proc[j + 1].id) {
                    temp = proc[j].id;
                    proc[j].id = proc[j + 1].id;
                    proc[j + 1].id = temp;
                }

        for (i = 0; i < num; i++)
            System.out.print(" [" + i + "] " + proc[i].id);

        int init, ch, temp1, temp2;
        int arr[] = new int[10];
        proc[num - 1].state = "inactive";
        System.out.println("\nProcess " + proc[num - 1].id + " selected as coordinator");

        while (true) {
            System.out.println("\n1.election  2.quit");
            ch = in.nextInt();
            for (i = 0; i < num; i++) proc[i].f = 0;

            switch (ch) {
                case 1:
                    System.out.println(
                        "Enter the process number who initialised election: ");
                    init = in.nextInt();
                    temp2 = init;
                    temp1 = init + 1;
                    i = 0;

                    while (temp2 != temp1) {
                        if ("active".equals(proc[temp1].state) && proc[temp1].f == 0) {
                            System.out.println("Process " + proc[init].id +
                                               " send message to " + proc[temp1].id);
                            proc[temp1].f = 1;
                            init = temp1;
                            arr[i] = proc[temp1].id;
                            i++;
                        }
                        if (temp1 == num)
                            temp1 = 0;
                        else
                            temp1++;
                    }

                    int max = -1;
                    for (j = 0; j < i; j++)
                        if (max < arr[j]) max = arr[j];

                    System.out.println("\nProcess " + max + " selected as coordinator");
                    for (i = 0; i < num; i++)
                        if (proc[i].id == max) proc[i].state = "inactive";
                    break;

                case 2:
                    System.out.println("Program terminated...");
                    return;
            }
        }
    }
}

class Rr {
    public int index, id, f;
    String state;
}
