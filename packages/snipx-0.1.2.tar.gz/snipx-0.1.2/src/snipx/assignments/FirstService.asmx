<%@ WebService language="C#" class="FirstService" %>

// Assignment 7 – ASP.NET Web Service Provider
using System;
using System.Web.Services;
using System.Xml.Serialization;

[WebService(Namespace="http://localhost/MyWebServices/")]
public class FirstService : WebService
{
    [WebMethod]
    public int Add(int a, int b)
    {
        return a + b;
    }

    [WebMethod]
    public String SayHello()
    {
        return "Hello World";
    }
}
