// Assignment 8 – Distributed Multiplayer Game: Go UDP + TCP Game Server
package main

import (
	"fmt"
	"net"
	"sync"
)

type GameState struct {
	Players map[string][2]float64
	mu      sync.Mutex
}

var state = &GameState{
	Players: make(map[string][2]float64),
}

// UDP handler – streams game state to clients
func handleUDP(conn *net.UDPConn) {
	buf := make([]byte, 1024)
	for {
		n, addr, err := conn.ReadFromUDP(buf)
		if err != nil {
			continue
		}
		input := string(buf[:n])
		fmt.Printf("Input from %s: %s\n", addr, input)

		state.mu.Lock()
		state.Players[addr.String()] = [2]float64{1.0, 2.0}
		state.mu.Unlock()

		response := fmt.Sprintf("STATE:%v", state.Players)
		conn.WriteToUDP([]byte(response), addr)
	}
}

// TCP handler – reliable event transfer
func handleTCP(conn net.Conn) {
	defer conn.Close()
	buf := make([]byte, 512)
	n, _ := conn.Read(buf)
	event := string(buf[:n])
	fmt.Printf("Event received: %s\n", event)
	conn.Write([]byte("ACK:" + event))
}

func main() {
	udpAddr, _ := net.ResolveUDPAddr("udp", ":9000")
	udpConn, _ := net.ListenUDP("udp", udpAddr)
	fmt.Println("Game server UDP listening on :9000")
	go handleUDP(udpConn)

	tcpListener, _ := net.Listen("tcp", ":9001")
	fmt.Println("Game server TCP listening on :9001")
	for {
		conn, err := tcpListener.Accept()
		if err != nil {
			continue
		}
		go handleTCP(conn)
	}
}
