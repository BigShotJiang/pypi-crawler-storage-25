# snipx

Instantly fetch Distributed Systems practical code files via the terminal.

## Install

```bash
pip install snipx
```

## Usage

```bash
snipx list                # show all assignments
snipx list java           # filter by category
snipx get rmi             # copy RMI files to ./ds_code/rmi/
snipx get bully           # copy Bully algorithm files
snipx guide               # open the full HTML run guide in your browser
snipx help                # full help
```

## Run Guide

`snipx guide` copies `Practical_Run_Guide.html` to your current directory and opens it in your browser.  
It covers every practical with step-by-step compile & run instructions for both **Windows** and **Linux**.  
To save as PDF: press `Ctrl+P` in the browser → **Save as PDF**.

## Assignments

| Key         | Assignment | Description |
|-------------|-----------|-------------|
| `rmi`       | 1         | RMI – Remote Method Invocation (Adder) |
| `corba`     | 2         | CORBA – Calculator Application |
| `mpi`       | 3         | MPI – Parallel Array Sum (4 cores) |
| `clocksync` | 4         | Berkeley Clock Synchronisation |
| `mutex`     | 5         | Token-Based Mutual Exclusion |
| `bully`     | 6a        | Bully Algorithm – Leader Election |
| `ring`      | 6b        | Ring Algorithm – Leader Election |
| `webservice`| 7         | ASP.NET Web Service + Consumers |
| `gameserver`| 8         | Distributed Multiplayer Game – Server |
| `gameclient`| 8         | Distributed Multiplayer Game – Unity Client |
