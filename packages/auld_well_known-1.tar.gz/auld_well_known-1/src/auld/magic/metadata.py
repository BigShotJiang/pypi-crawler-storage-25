from importlib.metadata import metadata, version

author_name: str = metadata("auld-well-known")["author"]
version_string: str = version("auld-well-known")
version_tuple: tuple[int, ...] = tuple(map(int, version_string.split(".")))
