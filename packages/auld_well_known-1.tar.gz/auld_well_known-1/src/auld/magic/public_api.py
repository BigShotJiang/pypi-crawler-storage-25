from ._internals import auld_well_known_uuid

MAGIC_NUMBER = int(auld_well_known_uuid)
MAGIC_STRING = str(f"X-{auld_well_known_uuid}")
MAGIC_UUID = auld_well_known_uuid
