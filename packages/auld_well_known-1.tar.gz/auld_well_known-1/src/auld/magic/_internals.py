from uuid import UUID

auld_well_known_uuid = UUID("e5b0eaff-03f0-4cdd-8e17-098622287fb0")
