"""This is not at all intended to offer security, but it
does offer a way to distinguish between an AULD server
and some hypothetical other server that might otherwise
look like an AULD server or be coincidentally using the
name 'AULD', etc."""

from .metadata import author_name, version_string, version_tuple
from .public_api import MAGIC_NUMBER, MAGIC_STRING, MAGIC_UUID

__all__ = ["MAGIC_NUMBER", "MAGIC_STRING", "MAGIC_UUID"]
__author__ = author_name
__email__ = __contact__ = None
__version__ = version_string
__version_info__ = version_tuple
