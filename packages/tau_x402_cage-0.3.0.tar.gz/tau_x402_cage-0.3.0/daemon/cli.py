"""Daemon entry point.

Commands:
    tau-x402-cage                               # run daemon with empty policy
    tau-x402-cage --policy policy.yaml          # pre-load declared invariants
    tau-x402-cage init                          # scaffold policy.yaml + compose
    tau-x402-cage init --force                  # overwrite existing files
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from adapter.policy_loader import (
    PolicyLoaderError,
    load_policy,
    write_starter_compose,
    write_starter_policy,
)
from daemon.server import CageDaemon
from daemon.signal_handlers import install as install_signal_handlers


def _cmd_init(args: argparse.Namespace) -> int:
    policy_path = Path(args.policy_path)
    compose_path = Path(args.compose_path)

    if args.force:
        if policy_path.exists():
            policy_path.unlink()
        if compose_path.exists():
            compose_path.unlink()
    try:
        write_starter_policy(policy_path)
        write_starter_compose(compose_path)
    except PolicyLoaderError as exc:
        sys.stderr.write(f"tau-x402-cage init: {exc}\n")
        sys.stderr.write("  pass --force to overwrite, or pick a different --policy-path\n")
        return 2
    sys.stdout.write(
        f"Wrote {policy_path} and {compose_path}.\n"
        f"Next steps:\n"
        f"  1. Edit {policy_path} to match your rules.\n"
        f"  2. tau-x402-cage --policy {policy_path}\n"
        f"  3. (optional) docker compose -f {compose_path} up\n"
    )
    return 0


def _cmd_run(args: argparse.Namespace) -> int:
    install_signal_handlers()

    daemon = CageDaemon(socket_path=args.socket, initial_spec=args.initial_spec)

    if args.policy:
        try:
            loaded = load_policy(args.policy)
        except PolicyLoaderError as exc:
            sys.stderr.write(f"tau-x402-cage: policy load failed: {exc}\n")
            return 2
        for inv in loaded.invariants:
            daemon._x402_registry = daemon._x402_registry.declare(inv)
        sys.stderr.write(
            f"tau-x402-cage: loaded {len(loaded.invariants)} invariants from {loaded.source_path}\n"
        )

    sys.stderr.write(f"tau-x402-cage: serving on {args.socket}\n")
    sys.stderr.flush()
    try:
        daemon.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        daemon.shutdown()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="tau-x402-cage")
    subparsers = parser.add_subparsers(dest="subcommand")

    # Run (default when no subcommand given)
    parser.add_argument("--socket", default="/tmp/tau-x402-cage.sock",
                        help="UDS path the daemon listens on")
    parser.add_argument("--policy", default=None,
                        help="Path to a YAML policy file declaring initial invariants")
    parser.add_argument("--initial-spec", default="u[t] = i[t].",
                        help=argparse.SUPPRESS)

    # init
    init_p = subparsers.add_parser("init", help="scaffold a starter policy + docker-compose")
    init_p.add_argument("--policy-path", default="policy.yaml")
    init_p.add_argument("--compose-path", default="docker-compose.yaml")
    init_p.add_argument("--force", action="store_true",
                        help="overwrite existing files")

    args = parser.parse_args()

    if args.subcommand == "init":
        return _cmd_init(args)
    return _cmd_run(args)


if __name__ == "__main__":
    raise SystemExit(main())
