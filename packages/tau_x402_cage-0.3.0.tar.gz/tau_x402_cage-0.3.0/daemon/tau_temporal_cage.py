"""TauTemporalCage, Tau is the actual reasoner, not just a rubber stamp.

This wrapper hosts a SINGLE Tau spec that uses memory streams to encode
temporal invariants. Tau computes the verdict; the adapter only relays
event signals.

The current spec encodes the "read-then-no-external" invariant:
- i1 = read_secret event (1 when a tracked secret was read this step)
- i2 = external_write attempt (1 when a network call is being attempted)
- o1 = sticky "secret_seen" flag (Tau-computed; sticks at 1 once i1=1)
- o2 = verdict (1 = allow, 0 = deny)

Tau spec (single G, body conjunction, required because Tau forbids G nesting):
    G(
      (o1[t] = 1 -> (i1[t] = 1 || o1[t-1] = 1))   memory: o1 sticks once i1=1
      &&
      (o1[t-1] = 1 && i2[t] = 1 -> o2[t] = 0)     verdict: deny external if seen
    )

This is GENUINELY Tau doing the work, a stateless Python dict couldn't
compute the o1 sticky-flag state machine + verdict in one step without
re-implementing Tau's solver. The temporal reasoning lives in the spec,
not in adapter code.

Requires the local patch to `solve_ltl_aba` removing the over-aggressive
pair-consistency check on pure-input atoms (see docs/UPSTREAM_PATCH.md).
"""
from __future__ import annotations

import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Literal


def _ensure_tau_loader_on_path() -> None:
    project_root = Path(__file__).resolve().parents[1]
    loader_dir = project_root.parent / "tau-llm" / "tests" / "bindings" / "python"
    loader_str = str(loader_dir)
    if loader_str not in sys.path:
        sys.path.insert(0, loader_str)


_ensure_tau_loader_on_path()
import tau_loader  # noqa: F401,E402
import tau  # noqa: E402


# The single composed Tau spec for V1 of the temporal cage.
TEMPORAL_SPEC = (
    "G("
    "(o1[t] = 1 -> (i1[t] = 1 || o1[t-1] = 1))"
    " && "
    "(o1[t-1] = 1 && i2[t] = 1 -> o2[t] = 0)"
    ")."
)


@dataclass(frozen=True)
class TemporalVerdict:
    status: Literal["allow", "deny", "error"]
    secret_seen: bool       # the o1 sticky-flag state Tau computed
    raw_o2: str             # raw u-stream value Tau emitted for verdict
    raw_o1: str             # raw u-stream value Tau emitted for memory


class TauTemporalCage:
    """Owns a Tau interpreter executing the temporal spec.

    Each call to `step(read_secret, external_write_attempt)` advances Tau
    one tick and returns the verdict, fully derived from Tau's reasoning.
    """

    def __init__(self) -> None:
        # Two input streams (env-controlled signals from the adapter)
        self._i1_stream = tau.vector_input_stream()  # read_secret events
        self._i2_stream = tau.vector_input_stream()  # external_write attempts
        # Two output streams (Tau-computed)
        self._o1_stream = tau.vector_output_stream()  # secret_seen sticky flag
        self._o2_stream = tau.vector_output_stream()  # verdict (1=allow, 0=deny)
        self._opts = tau.interpreter_options()
        self._opts.input_remaps["i1"] = self._i1_stream
        self._opts.input_remaps["i2"] = self._i2_stream
        self._opts.output_remaps["o1"] = self._o1_stream
        self._opts.output_remaps["o2"] = self._o2_stream
        self._interp = tau.get_interpreter(TEMPORAL_SPEC, self._opts)
        if self._interp is None:
            raise RuntimeError(
                "Tau rejected the temporal spec at parse/synthesis time. "
                "If you see 'multi-state strategy not supported', the local "
                "patch to solve_ltl_aba may be missing, see "
                "docs/UPSTREAM_PATCH.md for the fix."
            )
        self._lock = threading.Lock()
        self._o1_consumed = 0
        self._o2_consumed = 0

    def step(self, read_secret: bool, external_write_attempt: bool) -> TemporalVerdict:
        """Advance Tau one tick with the given input signals; return verdict."""
        with self._lock:
            # Encode booleans as Tau-typed values: True → "T.", False → "F."
            self._i1_stream.put("T." if read_secret else "F.")
            self._i2_stream.put("T." if external_write_attempt else "F.")
            step_result = tau.step(self._interp)

            o1_values = self._o1_stream.get_values()
            o2_values = self._o2_stream.get_values()

            if step_result is None or len(o2_values) <= self._o2_consumed:
                return TemporalVerdict(status="error", secret_seen=False,
                                       raw_o1="", raw_o2="")

            self._o1_consumed = len(o1_values)
            self._o2_consumed = len(o2_values)
            o1_val = o1_values[-1]
            o2_val = o2_values[-1]
            # Tau emits 'T'/'F' (no period). Allow on T or non-F non-empty.
            secret_seen = (o1_val == "T")
            allow = (o2_val != "F")
            return TemporalVerdict(
                status="allow" if allow else "deny",
                secret_seen=secret_seen,
                raw_o1=o1_val,
                raw_o2=o2_val,
            )
