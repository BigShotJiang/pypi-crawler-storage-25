"""TauInterpreterWrapper: thread-safe wrapper around the in-process tau.interpreter.

Forks the canonical pattern from
`tau-llm/tests/bindings/python/test_streams_api_update.py` (Mode A, remapped
streams). The wrapper owns the interpreter for the lifetime of the cage session;
the daemon holds one wrapper per running cage.

Signal shape (verified empirically against nanobind 2.12 / Python 3.14 / Tau LTL
extension commit 8b155d36 on macOS aarch64):
- accept = `'T'` (or any non-`'F'` non-empty string for full revisions)
- reject = `'F'` (no trailing period; the brainstorm/plan referenced `'F.'` but
  the actual binding signal is bare `'F'`)

Critical binding gotcha (DO NOT REVERT): `tau.vector_output_stream.get()`
SEGFAULTS in this build. Use `.get_values()[-1]` instead, see learnings.jsonl.
"""
from __future__ import annotations

import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Literal


def _ensure_tau_loader_on_path() -> None:
    """Insert tau-llm's test-bindings dir so `import tau_loader` works."""
    project_root = Path(__file__).resolve().parents[1]
    loader_dir = project_root.parent / "tau-llm" / "tests" / "bindings" / "python"
    loader_str = str(loader_dir)
    if loader_str not in sys.path:
        sys.path.insert(0, loader_str)


_ensure_tau_loader_on_path()
import tau_loader  # noqa: F401,E402  (side-effect: adjusts sys.path for `tau`)
import tau  # noqa: E402


@dataclass(frozen=True)
class VerdictResult:
    """Outcome of a single submit() call."""

    status: Literal["accept", "reject", "error"]
    u_value: str


class TauInterpreterWrapper:
    """Owns one tau.interpreter for the lifetime of a cage session."""

    def __init__(self, initial_spec: str) -> None:
        self._i_stream = tau.vector_input_stream()
        self._u_stream = tau.vector_output_stream()
        self._opts = tau.interpreter_options()
        self._opts.input_remaps["i"] = self._i_stream
        self._opts.output_remaps["u"] = self._u_stream
        self._interp = tau.get_interpreter(initial_spec, self._opts)
        if self._interp is None:
            raise ValueError(f"Tau rejected initial spec at parse/type-check time: {initial_spec!r}")
        self._lock = threading.Lock()
        self._u_values_consumed = 0  # high-water mark on u_stream values list

    def submit(self, value: str) -> VerdictResult:
        """Submit a value or revision to the `i` stream and return the verdict.

        Thread-safe: serialises through an internal lock since the interpreter
        is not safe for concurrent access.

        Returns `status="error"` if `tau.step()` returns None (parse/type/exhausted/
        etc.) OR if no new value appeared on the `u` stream, the cage hook
        fail-closes on this signal per Unit 6 collapsed scope.
        """
        with self._lock:
            self._i_stream.put(value)
            step_result = tau.step(self._interp)
            values = self._u_stream.get_values()
            if step_result is None or len(values) <= self._u_values_consumed:
                return VerdictResult(status="error", u_value="")
            self._u_values_consumed = len(values)
            u_value = values[-1]
            status: Literal["accept", "reject", "error"] = (
                "reject" if u_value == "F" else "accept"
            )
            return VerdictResult(status=status, u_value=u_value)
