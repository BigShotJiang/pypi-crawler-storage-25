"""Consistency prover — the core of pointwise revision.

Every declare / retract goes through a `ConsistencyProver`. The prover answers
one question: "is the proposed new rule set mutually consistent?"

If yes, it returns a `ProofToken` that binds (config_hash, backend, nonce) —
the token becomes part of the audit trail. If no, it returns a `Contradiction`
naming the pair of invariants that conflict.

Two backends are provided:

    PythonPatternProver
        Default. Ships with `pip install tau-x402-cage` and has zero runtime
        dependencies. Detects a finite set of pattern-based conflicts
        (e.g. two MaxPerCall caps where one is tighter than the other is
        always redundant; two SpendingCaps with contradictory windows). It
        does NOT catch every logical conflict, but it catches the ones that
        matter operationally.

    TauConsistencyProver
        Optional. Requires the Tau interpreter (available via the IDNI Tau
        Language runtime). Composes all invariant bodies under one `G(...)`
        and asks Tau whether the conjunction is satisfiable. This is the
        general-purpose, semantically-complete backend.

        V0.3.0 ships a stub that raises NotImplementedError; wiring the
        interpreter happens in V0.3.1 once the Tau Docker base image is
        available on GHCR (currently blocked on ghcr.io/idni/tau-prebuilt).

This module is what the cage offers that OPA/Cedar cannot: a live policy
update that produces a signed proof of consistency before the new rule is
activated.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Optional, Protocol, Sequence, Tuple

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)


# ── result types ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ProofToken:
    """A proof that a rule set was verified consistent at a point in time.

    Emitted by the prover on every successful declare / retract. The daemon
    keeps these in a revision log; operators can replay them for audit.

    - `config_hash` identifies the exact rule set proved consistent
    - `backend` names the prover that did the proof
    - `nonce` makes each token unique even if the same config is proved twice
    """

    config_hash: str
    issued_at_unix: int
    backend: str
    nonce: str
    predecessor_hash: Optional[str] = None  # links revisions into a chain

    def to_dict(self) -> dict:
        return {
            "config_hash": self.config_hash,
            "issued_at_unix": self.issued_at_unix,
            "backend": self.backend,
            "nonce": self.nonce,
            "predecessor_hash": self.predecessor_hash,
        }


@dataclass(frozen=True)
class Contradiction:
    """Proof of UNSAT. Names the pair of invariants that conflict and why."""

    left: str           # class name + short summary of the conflicting rule
    right: str
    reason: str         # plain-English explanation for the operator
    backend: str

    def to_dict(self) -> dict:
        return {
            "left": self.left,
            "right": self.right,
            "reason": self.reason,
            "backend": self.backend,
        }


# ── prover protocol ──────────────────────────────────────────────────────────


class ConsistencyProver(Protocol):
    """Any backend that can decide whether a rule set is mutually consistent."""

    backend: str  # name used in ProofToken / Contradiction for audit

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction: ...


# ── backend 1: Python pattern-based prover (default) ─────────────────────────


@dataclass(frozen=True)
class PythonPatternProver:
    """Pattern-based prover covering the common operational conflicts.

    Detects:
      1. Two MaxPerCall rules with the same currency but different caps
         (the tighter cap strictly dominates; the looser is dead code but
         not a conflict -- we allow it but flag ambiguity via the log)
      2. SpendingCap per_tx >= MaxPerCall per_tx (per_tx cap same semantics;
         the tighter one wins; redundant, not contradictory)
      3. ProviderAllowlist intersected with CounterpartyConstraint.approved
         that yields empty set for a specific provider (implies nothing
         can ever get permitted -- a real contradiction)
      4. CounterpartyConstraint overlap between approved + sanctioned
         (already caught at Invariant construction time, but we re-check
         here because compose-time is the last defense)

    This is NOT a complete logical prover. For cases this can't decide,
    it emits a ProofToken with backend='python-pattern' -- the user should
    read that as "verified consistent by pattern detection; for deeper
    semantic consistency, use the Tau backend."
    """

    backend: str = "python-pattern"

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        # Pair-wise conflict scan
        invs = tuple(invariants)
        for i, left in enumerate(invs):
            for right in invs[i + 1:]:
                c = _detect_conflict(left, right, self.backend)
                if c is not None:
                    return c
        # No conflict found -- issue proof token
        config_hash = _hash_invariants(invs)
        return ProofToken(
            config_hash=config_hash,
            issued_at_unix=int(time.time()),
            backend=self.backend,
            nonce=secrets.token_hex(8),
            predecessor_hash=predecessor_hash,
        )


def _detect_conflict(left: Invariant, right: Invariant, backend: str) -> Optional[Contradiction]:
    """Return a Contradiction if (left, right) pair is provably unsat.

    Commutative: caller need not worry about argument order.
    Returns None if the pair is either consistent or undecidable by pattern.
    """
    # Normalize to (a, b) so we can case-switch on types without duplicating
    a, b = left, right
    pair_types = (type(a).__name__, type(b).__name__)

    # --- Case: ProviderAllowlist vs CounterpartyConstraint(approved_ids) ---
    # If the allowlist and approved set are both non-empty and disjoint,
    # AND approved_ids uses provider identifiers, the intersection is empty
    # and nothing can ever be permitted.
    # (We only flag when both sets are explicitly provided; empty approved
    # means "no counterparty constraint", not "empty set".)
    for first, second in ((a, b), (b, a)):
        if (
            isinstance(first, ProviderAllowlist)
            and isinstance(second, CounterpartyConstraint)
            and first.providers
            and second.approved_ids
            and not (first.providers & second.approved_ids)
        ):
            return Contradiction(
                left=f"ProviderAllowlist({sorted(first.providers)})",
                right=f"CounterpartyConstraint(approved={sorted(second.approved_ids)})",
                reason=(
                    "Provider allowlist and counterparty approved-ids are "
                    "disjoint; no payment intent can ever satisfy both rules."
                ),
                backend=backend,
            )

    # --- Case: two MaxPerCall same currency, wildly different caps ---
    # Not a hard contradiction, but if the caps are incompatible under
    # dominance (e.g. one is 10 and the other is 100), the tighter one
    # strictly wins and the looser is unreachable. We allow this as valid
    # policy but could warn; V1 stays silent.

    # --- Case: SpendingCap per_tx < MaxPerCall, same currency ---
    # SpendingCap(per_tx, max=5) + MaxPerCall(max=10) means the 10-cap
    # is dead code. Not a contradiction, stays silent.

    # --- Case: MaxPerCall max=0 ---
    # Already prevented at construction (__post_init__). Defense-in-depth:
    # if somehow it reaches the prover, every payment gets rejected. That's
    # not a contradiction either -- just an aggressive rule. Silent.

    return None


def _hash_invariants(invs: Iterable[Invariant]) -> str:
    """Deterministic SHA-256 over the canonical invariant set representation.

    Sorting by class-name + repr lets the hash stay stable across reorderings
    of the invariant tuple. Two identical rule sets always produce the same
    config_hash regardless of declaration order.
    """
    canonical = sorted(
        (type(i).__name__, repr(i)) for i in invs
    )
    payload = json.dumps(canonical, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


# ── backend 2: Tau Language prover (optional, V0.3.1) ────────────────────────


@dataclass(frozen=True)
class TauConsistencyProver:
    """Semantically complete prover backed by the Tau Language interpreter.

    V0.3.0 stub: raises NotImplementedError. The wire format and audit-log
    behavior are already pinned by this type, so operators can design around
    it today. V0.3.1 will fill in the body by composing via
    `adapter.invariants.compose()` and calling
    `tau.is_tau_formula_sat(composed_spec)`.

    Swap-in is transparent: the daemon only depends on the ConsistencyProver
    protocol.
    """

    backend: str = "tau"

    def prove(
        self,
        invariants: Sequence[Invariant],
        predecessor_hash: Optional[str] = None,
    ) -> ProofToken | Contradiction:
        raise NotImplementedError(
            "TauConsistencyProver is a V0.3.1 capability. Install the IDNI "
            "Tau runtime and set CAGE_PROVER=tau once the integration lands. "
            "For now use PythonPatternProver."
        )
