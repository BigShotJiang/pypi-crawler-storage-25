"""SessionInvariantRegistry: immutable container of declared invariants.

Holds the set of invariants active in the current cage session. Every
declare() / retract() returns a NEW registry instance, the daemon swaps the
reference atomically. Immutability prevents mid-step state corruption when the
adapter and daemon's hot-call path read the registry concurrently with a
declare/retract update.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

from adapter.invariants import DeclaredProtected, NoForcePush, ReadThenNoExternal
from adapter.session_state import SessionState

Invariant = Union[DeclaredProtected, NoForcePush, ReadThenNoExternal]


@dataclass(frozen=True)
class SessionInvariantRegistry:
    invariants: frozenset[Invariant] = field(default_factory=frozenset)

    @classmethod
    def empty(cls) -> "SessionInvariantRegistry":
        return cls(invariants=frozenset())

    def declare(self, inv: Invariant) -> "SessionInvariantRegistry":
        return SessionInvariantRegistry(invariants=self.invariants | {inv})

    def retract(self, inv: Invariant) -> "SessionInvariantRegistry":
        return SessionInvariantRegistry(invariants=self.invariants - {inv})

    def check(self, tool_call, state: SessionState | None = None) -> frozenset[Invariant]:
        """Return the set of invariants this tool_call violates given session state.

        Empty frozenset = clean. Defensive on None / malformed input.
        """
        if tool_call is None:
            return frozenset()
        if state is None:
            state = SessionState.empty()
        return frozenset(inv for inv in self.invariants if inv.matches(tool_call, state))
