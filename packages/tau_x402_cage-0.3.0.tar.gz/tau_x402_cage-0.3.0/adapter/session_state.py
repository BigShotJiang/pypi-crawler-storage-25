"""SessionState, history the cage keeps for invariants that depend on prior calls.

Pure data, no I/O. The daemon mutates a SessionState as tool calls flow through;
invariants consult it (via `Invariant.matches(call, state)`) to decide whether
the current call violates a temporal-ish rule.

Kept simple for V1: a frozenset of paths whose contents have been read this
session. The climax invariant `ReadThenNoExternal` reads from this set.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import PurePath


@dataclass(frozen=True)
class SessionState:
    secrets_read: frozenset[PurePath] = field(default_factory=frozenset)

    @classmethod
    def empty(cls) -> "SessionState":
        return cls(secrets_read=frozenset())

    def with_secret_read(self, path: PurePath) -> "SessionState":
        return replace(self, secrets_read=self.secrets_read | {path})
