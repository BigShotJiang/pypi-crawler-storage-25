import boto3
from allfly.utils import stdout
from botocore.client import BaseClient


class AwsLambda:
    client: BaseClient

    def __init__(self):
        self.client = boto3.client('lambda')

    def update_lambda_image_with_image_url(self, app_name: str, image_url: str):
        stdout("Deploying Lambda function...")
        self.client.update_function_code(
            FunctionName=f"{app_name}", ImageUri=image_url, Publish=True
        )
        stdout("Lambda function deployed successfully.")
