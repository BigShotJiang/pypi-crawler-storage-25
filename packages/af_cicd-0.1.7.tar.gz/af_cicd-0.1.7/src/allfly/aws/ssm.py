import boto3
from allfly.utils import exit_with_error
from botocore.client import BaseClient


class AwsSSM:
    client: BaseClient

    def __init__(self):
        self.client = boto3.client('ssm')

    def get_ssm_param_value(self, param_name: str, is_encrypted=False) -> str | None:

        try:
            response = self.client.get_parameter(Name=param_name, WithDecryption=is_encrypted)
            return response['Parameter']['Value']
        except self.client.exceptions.ParameterNotFound:
            exit_with_error(f"Could not find ssm param value {param_name}")
