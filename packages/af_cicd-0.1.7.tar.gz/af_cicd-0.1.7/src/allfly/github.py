import json
import os
import urllib.error
import urllib.request

from allfly.utils import stdout, stderr

# Branches that require the actor to be a member of the leads team
PROTECTED_TARGETS = {"staging", "master"}

# GitHub org and team slugs — override via env if needed
GITHUB_ORG = os.environ.get("GITHUB_ORG", "travelallfly")
GITHUB_LEADS_TEAM = os.environ.get("GITHUB_LEADS_TEAM", "quest-leads")


def _github_api_get(path: str, token: str) -> dict | list:
    """
    Make an authenticated GET request to the GitHub API.
    Raises urllib.error.HTTPError on non-2xx responses.
    """
    url = f"https://api.github.com{path}"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode())


def assert_actor_is_lead(actor: str | None, target_branch: str, token: str | None) -> None:
    """
    If target_branch is a protected environment (staging or master), verify that
    the GitHub actor is a member of the quest-leads team.

    Raises SystemExit (via typer.Exit) when the check fails, or a RuntimeError
    when required env vars are missing.

    Args:
        actor:         GitHub username of the person who triggered the workflow
                       (GITHUB_ACTOR in Actions).
        target_branch: The branch being promoted to.
        token:         GitHub token with `org:read` / `read:org` scope
                       (GITHUB_TOKEN in Actions — needs org membership read).
    """
    if target_branch not in PROTECTED_TARGETS:
        # Promoting to qa or develop: no restriction
        return

    if not actor:
        raise RuntimeError(
            "GITHUB_ACTOR is not set. Cannot verify team membership for promotion "
            f"to '{target_branch}'. Aborting."
        )

    if not token:
        raise RuntimeError(
            "GITHUB_TOKEN is not set. Cannot verify team membership for promotion "
            f"to '{target_branch}'. Aborting."
        )

    stdout(
        f"Protected target '{target_branch}' — verifying that @{actor} is a member "
        f"of {GITHUB_ORG}/{GITHUB_LEADS_TEAM}..."
    )

    path = f"/orgs/{GITHUB_ORG}/teams/{GITHUB_LEADS_TEAM}/memberships/{actor}"
    try:
        data = _github_api_get(path, token)
        state = data.get("state", "")
        role = data.get("role", "")
        if state != "active":
            _deny(actor, target_branch, f"membership state is '{state}' (must be 'active')")
        stdout(f"✅  @{actor} is an active {role} of {GITHUB_ORG}/{GITHUB_LEADS_TEAM}. Proceeding.")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            _deny(actor, target_branch, f"not a member of {GITHUB_ORG}/{GITHUB_LEADS_TEAM}")
        # 403 means the token lacks org:read — surface a helpful message
        if e.code == 403:
            raise RuntimeError(
                f"GitHub API returned 403 when checking team membership. "
                f"Ensure GITHUB_TOKEN has 'read:org' scope (or the workflow has "
                f"'organization-members: read' permission)."
            ) from e
        raise RuntimeError(f"GitHub API error {e.code} checking team membership: {e.reason}") from e


def whoami(token: str | None) -> None:
    """
    Print the authenticated GitHub user, their org memberships, and whether
    they are an active member of the leads team. Useful for debugging token
    and org/team config locally or in CI.
    """
    if not token:
        raise RuntimeError("GITHUB_TOKEN is not set.")

    # Who am I?
    user_data = _github_api_get("/user", token)
    login = user_data.get("login", "unknown")
    name = user_data.get("name") or ""
    stdout(f"👤  Authenticated as: @{login}" + (f" ({name})" if name else ""))
    stdout(f"🔧  Org:  {GITHUB_ORG}")
    stdout(f"🔧  Team: {GITHUB_LEADS_TEAM}")

    # Am I in the leads team?
    path = f"/orgs/{GITHUB_ORG}/teams/{GITHUB_LEADS_TEAM}/memberships/{login}"
    try:
        data = _github_api_get(path, token)
        state = data.get("state", "unknown")
        role = data.get("role", "unknown")
        if state == "active":
            stdout(f"✅  @{login} is an active {role} of {GITHUB_ORG}/{GITHUB_LEADS_TEAM}")
            stdout("    → May promote to staging and master")
        else:
            stdout(f"⏳  @{login} has a '{state}' membership in {GITHUB_ORG}/{GITHUB_LEADS_TEAM}")
            stdout("    → Not yet active — promotions to staging/master will be blocked")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            stdout(f"🚫  @{login} is NOT a member of {GITHUB_ORG}/{GITHUB_LEADS_TEAM}")
            stdout("    → Promotions to staging and master will be blocked")
        elif e.code == 403:
            stdout("⚠️   Got 403 checking team membership.")
            stdout("    → GITHUB_TOKEN may be missing 'read:org' scope")
        else:
            stdout(f"⚠️   GitHub API error {e.code} checking team membership: {e.reason}")


def _deny(actor: str, target_branch: str, reason: str) -> None:
    stderr(
        f"🚫  @{actor} is not authorised to promote to '{target_branch}': {reason}.\n"
        f"    Only members of the '{GITHUB_LEADS_TEAM}' team may promote to staging or master.\n"
        f"    Ask a lead to run this promotion, or request access from your engineering manager."
    )
    raise PermissionError(
        f"@{actor} is not authorised to promote to '{target_branch}': {reason}"
    )
