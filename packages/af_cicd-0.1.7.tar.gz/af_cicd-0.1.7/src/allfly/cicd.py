import os
from typing import Annotated, Optional

import typer
from allfly.aws.core import AWSCore
from allfly.commands import aws, git, orchestrations
from allfly.commands import docker
from allfly.commands import terraform
from allfly.commands.constants import CICD_OPTION
from allfly.commands.slack import SlackClient
from allfly.github import assert_actor_is_lead, whoami as github_whoami
from allfly.models import build_branch_deployment_config, DeploymentRules, DeploymentContext, CicdContext
from allfly.utils import build_cli_app, ECR_ACCOUNT_ID, run_command, stdout, run_shell_command, is_cicd

app = build_cli_app()
config: DeploymentRules = build_branch_deployment_config()



#
# ECS Orchestration
#

@app.command(
    help="""
    [orchestration] Build the docker container images and publish to ECR
    """
)
def ecs_build_only(
        cicd: Annotated[Optional[bool], CICD_OPTION],
        version_string: Annotated[Optional[str], typer.Option()] = None,
        git_hash: Annotated[Optional[str], typer.Option()] = None,
        app_name: Annotated[Optional[str], typer.Option()] = None,
        current_branch: Annotated[Optional[str], typer.Option()] = None,
        arm: Annotated[Optional[bool], typer.Option()] = False,
):
    sanitized_source_branch = config.get_sanitize_branch_name(current_branch)

    config.assert_build_only_branch(sanitized_source_branch)

    AWSCore.setup_aws_creds(cicd=cicd)

    context = DeploymentContext(
        for_arm=arm,
        is_cicd=cicd,
        app_name=app_name,
        git_hash=git_hash,
        ecr_account_id=ECR_ACCOUNT_ID,
        version_string=version_string,
        current_branch_name=sanitized_source_branch,
        current_config_rule=config.find_config_rule_by_branch(sanitized_source_branch)
    )

    orchestrations.ecs_build_only(context)


@app.command(
    help="""
    [orchestration] Run the develop ecs pipeline.
    Build and push the docker image, and then deploy that image to the ecs service.
"""
)
def ecs_build_and_deploy(
        cicd: Annotated[Optional[bool], CICD_OPTION],
        version_string: Annotated[Optional[str], typer.Option()] = None,
        git_hash: Annotated[Optional[str], typer.Option()] = None,
        app_name: Annotated[Optional[str], typer.Option()] = None,
        branch: Annotated[Optional[str], typer.Option()] = None,
        iac_path: Annotated[Optional[str], typer.Option()] = 'app',
        iac_var_path: Annotated[str | None, typer.Option()] = None,
        ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
        arm: Annotated[Optional[bool], typer.Option()] = False,
        pre_deploy_task: Annotated[Optional[list[str]], typer.Option(
            help="Short task name to run before the service update (e.g. 'migrations'). Repeatable, runs in order."
        )] = None,
):
    config.assert_build_and_deploy_branch(branch)

    AWSCore.setup_aws_creds(cicd=cicd)

    config_rule = config.find_config_rule_by_branch(branch)

    context = DeploymentContext(
        for_arm=arm,
        is_cicd=cicd,
        app_name=app_name,
        git_hash=git_hash,
        iac_path=iac_path,
        iac_var_path=iac_var_path,
        current_branch_name=branch,
        ecr_account_id=ecr_account_id,
        version_string=version_string,
        current_config_rule=config_rule,
        pre_deploy_tasks=pre_deploy_task or [],
    )

    orchestrations.ecs_build_and_deploy(context=context)


@app.command(
    help="""
    [orchestration] Promote previous env tag to target and deploy to target environment.
    Build and push the docker image, and then deploy latest to the environment.
"""
)
def ecs_promote_and_deploy(
        cicd: Annotated[Optional[bool], CICD_OPTION],
        version_string: Annotated[Optional[str], typer.Option()] = None,
        git_hash: Annotated[Optional[str], typer.Option()] = None,
        app_name: Annotated[Optional[str], typer.Option()] = None,
        source_branch: Annotated[Optional[str], typer.Option()] = None,
        target_branch: Annotated[Optional[str], typer.Option()] = None,
        iac_path: Annotated[Optional[str], typer.Option()] = 'app',
        iac_var_path: Annotated[str | None, typer.Option()] = None,
        ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
        pre_deploy_task: Annotated[Optional[list[str]], typer.Option(
            help="Short task name to run before the service update (e.g. 'migrations'). Repeatable, runs in order."
        )] = None,
):
    config.assert_promote_and_deploy_branch(target_branch)

    sanitized_source_branch = config.get_sanitize_branch_name(source_branch)

    config.assert_valid_git_promotion(sanitized_source_branch, target_branch)

    current_config_rule = config.find_config_rule_by_branch(target_branch)
    previous_branch_config_rule = config.find_config_rule_by_branch(sanitized_source_branch)

    AWSCore.setup_aws_creds(cicd=cicd)

    context = DeploymentContext(
        is_cicd=cicd,
        git_hash=git_hash,
        app_name=app_name,
        iac_path=iac_path,
        iac_var_path=iac_var_path,
        current_branch_name=source_branch,
        ecr_account_id=ecr_account_id,
        version_string=version_string,
        current_config_rule=current_config_rule,
        previous_branch_config_rule=previous_branch_config_rule,
        pre_deploy_tasks=pre_deploy_task or [],
    )

    ecs_tag_release = orchestrations.ecs_promote_and_deploy(context)
    if "prod" in current_config_rule.target_environment:
        SlackClient().send_release_notification(
            repository=app_name,
            version=ecs_tag_release
        )


#
# Docker Stuff
#

@app.command(help=f'Build and tag a local docker image give a Dockerfile at the root path')
def docker_build(app_name: Annotated[str, typer.Option()],
                 git_hash: Annotated[str, typer.Option()],
                 version_string: Annotated[str, typer.Option()],
                 arm: Annotated[Optional[bool], typer.Option()] = False):
    run_command(docker.build_local_image(app_name=app_name,
                                         git_hash=git_hash,
                                         for_arm=arm,
                                         version_string=version_string))


@app.command(help=f'Promote remote ECR image tag to another tag')
def docker_tag_promote(
        app_name: Annotated[Optional[str], typer.Option()] = None,
        ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
        source: Annotated[Optional[str], typer.Option()] = None,
        target: Annotated[Optional[str], typer.Option()] = None):
    run_command(aws.promote_ecr_docker_tag(app_name, ecr_account_id, source, target))


@app.command(help="Re-tag and push a local image to an environment")
def docker_push(
        app_name: Annotated[str, typer.Option()],
        version_string: Annotated[str, typer.Option()],
        local_image: Annotated[str, typer.Option()],
        environment: Annotated[Optional[str], typer.Option()] = None,
        ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
):
    run_command(docker.tag_and_push_docker_images_from_local(
        app_name=app_name,
        local_image=local_image,
        version_string=version_string,
        ecr_account_id=ecr_account_id,
        environment_tag=environment,
    ))


#
# ECS Stuff
#

@app.command(help="replace current image tag to the target ecs app (this requires pipx install ecs-deploy)")
def deploy_to_ecs(app_name: Annotated[str, typer.Option()],
                  image: Annotated[str, typer.Option()]):
    run_command(aws.deploy_image_tag_to_ecs_app(app_name=app_name, tag=image))


@app.command(help="get the versioned image tag based on the given environment")
def get_version_image(app_name: Annotated[str, typer.Option()],
                      ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
                      environment: Annotated[Optional[str], typer.Option()] = None, ):
    run_command(aws.get_next_image_tag(app_name=app_name, ecr_account_id=ecr_account_id, env=environment))


#
# Lambda Stuff
#


@app.command(help='Deploy a docker image tag from ECR to lambda')
def lambda_deploy(app_name: Annotated[str, typer.Option()],
                  ecr_account_id: Annotated[str, typer.Option()] = ECR_ACCOUNT_ID,
                  image_tag: Annotated[Optional[str], typer.Option()] = None):
    run_command(aws.update_lambda_image(app_name=app_name, ecr_account_id=ecr_account_id, image_tag=image_tag))


#
# Terraform Stuff
#
@app.command(help='Plan or apply infrastructure changes through terraform')
def iac(env: Annotated[Optional[str], typer.Option()] = None,
        target: Annotated[Optional[str], typer.Option()] = None,
        iac_path: Annotated[str, typer.Option()] = "app",
        iac_var_path: Annotated[str | None, typer.Option()] = None,
        plan_only: Annotated[bool, typer.Option()] = False,
        auto_apply: Annotated[bool, typer.Option()] = False):
    from allfly.config import resolve_environment
    
    try:
        resolved_env = resolve_environment(env=env, target=target)
    except ValueError as e:
        raise typer.BadParameter(str(e))
    
    run_command(terraform.exec_infra_as_code(env=resolved_env,
                                             iac_path=iac_path,
                                             var_path=iac_var_path,
                                             plan_only=plan_only,
                                             auto_apply=auto_apply))


@app.command(help='Plan or apply infrastructure changes through terraform (ECS)')
def ecs_iac(env: Annotated[str, typer.Option()] = None,
            iac_path: Annotated[str, typer.Option()] = "app",
            iac_var_path: Annotated[str | None, typer.Option()] = None,
            plan_only: Annotated[bool, typer.Option()] = False,
            auto_apply: Annotated[bool, typer.Option()] = False,
            ecs_tag: Annotated[str, typer.Option()] = None):
    run_command(
        terraform.exec_infra_as_code_for_ecs_app(env=env,
                                                 iac_path=iac_path,
                                                 var_path=iac_var_path,
                                                 plan_only=plan_only,
                                                 auto_apply=auto_apply,
                                                 ecs_tag=ecs_tag))


#
# Git Stuff
#

@app.command(help='Automates the auto-merging from the source branch to the target branch and pushes to git')
def git_promote(source: str, target: str, cicd: Annotated[Optional[bool], CICD_OPTION]):
    """
    Here we sanitize the branch name so we can look up and validate the promotion rules
    However, when we git promote, we need the actual source branch
    """
    # Gate staging/master promotions to leads team members only.
    assert_actor_is_lead(
        actor=os.environ.get("GITHUB_ACTOR"),
        target_branch=target,
        token=os.environ.get("GITHUB_TOKEN"),
    )

    sanitized_source_branch = config.get_sanitize_branch_name(source)
    config.assert_valid_git_promotion(sanitized_source_branch, target)
    run_command(git.promote_branch(source_branch=source, target_branch=target, cicd=cicd))


@app.command(help="Prepare a QA or Staging hotfix branch")
def prep_hotfix(
    target: Annotated[str, typer.Argument(help="Target environment: 'qa' or 'staging'")],
    branch: Annotated[str, typer.Argument(help="Hotfix branch name (without hotfix/ prefix)")]
):
    run_command(git.prep_hotfix(target=target, branch_name=branch))

@app.command(name="github-whoami", help='Show the authenticated GitHub user and their leads-team membership status')
def github_whoami_cmd():
    github_whoami(token=os.environ.get("GITHUB_TOKEN"))


@app.command(help='Say Hello')
def hello():
    run_shell_command(f'echo "hello world!"')


#
# misc
#

@app.command(help='Show current config')
def show_rules():
    stdout(config.to_pretty_json())


def main():
    try:
        app()
    except Exception as e:
        if is_cicd():
            print(f"Sending build failure notification to Slack")
            context = CicdContext()
            SlackClient().send_build_failure_notification(
                repository=context.repository,
                branch=context.branch,
                commit_message=context.commit_message,
                run_url=context.get_build_url()
            )
        raise e


if __name__ == '__main__':
    main()
