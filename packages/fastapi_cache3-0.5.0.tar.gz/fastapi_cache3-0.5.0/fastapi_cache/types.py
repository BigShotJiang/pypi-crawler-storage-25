"""Protocol definitions for cache backends and key builders."""

import abc
from collections.abc import Awaitable, Callable
from typing import Any, Protocol

from starlette.requests import Request
from starlette.responses import Response

_Func = Callable[..., Any]


class KeyBuilder(Protocol):
    """Protocol for cache key builder callables.

    A key builder receives the decorated function along with the current
    request/response and call arguments, and returns a cache key string
    (or an awaitable that resolves to one).
    """

    def __call__(
        self,
        func: _Func,
        namespace: str = ...,
        *,
        request: Request | None = ...,
        response: Response | None = ...,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Awaitable[str] | str:
        """Build a cache key for the given function call."""
        ...


class Backend(abc.ABC):
    """Abstract base class for cache backends.

    All methods are async. Implement this interface to add a new backend.
    """

    @abc.abstractmethod
    async def get_with_ttl(self, key: str) -> tuple[int, bytes | None]:
        """Retrieve a value along with its remaining TTL.

        Args:
            key: Cache key.

        Returns:
            A tuple of ``(ttl_seconds, value)``. TTL is ``0`` if the key
            does not exist or has expired. Value is ``None`` on a miss.
        """
        raise NotImplementedError

    @abc.abstractmethod
    async def get(self, key: str) -> bytes | None:
        """Retrieve a cached value.

        Args:
            key: Cache key.

        Returns:
            Cached bytes, or ``None`` on a miss.
        """
        raise NotImplementedError

    @abc.abstractmethod
    async def set(self, key: str, value: bytes, expire: int | None = None) -> None:
        """Store a value in the cache.

        Args:
            key: Cache key.
            value: Value to store.
            expire: TTL in seconds. ``None`` means no expiry.
        """
        raise NotImplementedError

    @abc.abstractmethod
    async def clear(self, namespace: str | None = None, key: str | None = None) -> int:
        """Remove cached entries.

        Args:
            namespace: Delete all keys with this prefix.
            key: Delete a specific key.

        Returns:
            Number of keys deleted.
        """
        raise NotImplementedError
