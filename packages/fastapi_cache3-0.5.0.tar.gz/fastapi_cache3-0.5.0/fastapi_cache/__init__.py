"""fastapi-cache3 — pluggable caching for FastAPI endpoints."""

from importlib.metadata import version
from typing import ClassVar

from fastapi_cache.coder import Coder, JsonCoder
from fastapi_cache.key_builder import default_key_builder
from fastapi_cache.types import Backend, KeyBuilder

__version__ = version("fastapi-cache3")  # pyright: ignore[reportUnknownVariableType]
__all__ = [
    "Backend",
    "Coder",
    "FastAPICache",
    "JsonCoder",
    "KeyBuilder",
    "default_key_builder",
]


class FastAPICache:
    """Global cache configuration and entry point.

    Must be initialized once at application startup via ``init()``.

    Example:
        ```python
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            FastAPICache.init(RedisBackend(redis), prefix="myapp")
            yield

        app = FastAPI(lifespan=lifespan)
        ```
    """

    _backend: ClassVar[Backend | None] = None
    _prefix: ClassVar[str | None] = None
    _expire: ClassVar[int | None] = None
    _init: ClassVar[bool] = False
    _coder: ClassVar[type[Coder] | None] = None
    _key_builder: ClassVar[KeyBuilder | None] = None
    _cache_status_header: ClassVar[str | None] = None
    _enable: ClassVar[bool] = True

    @classmethod
    def init(
        cls,
        backend: Backend,
        prefix: str = "",
        expire: int | None = None,
        coder: type[Coder] = JsonCoder,
        key_builder: KeyBuilder = default_key_builder,
        cache_status_header: str = "X-FastAPI-Cache",
        enable: bool = True,
    ) -> None:
        """Initialize the cache.

        Args:
            backend: Cache backend instance to use.
            prefix: Global key prefix applied to all cache keys.
            expire: Default TTL in seconds. ``None`` means no expiry.
            coder: Encoder/decoder class. Defaults to ``JsonCoder``.
            key_builder: Cache key builder callable.
            cache_status_header: Response header name for HIT/MISS status.
            enable: Set to ``False`` to disable caching globally.
        """
        if cls._init:
            return
        cls._init = True
        cls._backend = backend
        cls._prefix = prefix
        cls._expire = expire
        cls._coder = coder
        cls._key_builder = key_builder
        cls._cache_status_header = cache_status_header
        cls._enable = enable

    @classmethod
    def reset(cls) -> None:
        """Reset all configuration. Primarily used in tests."""
        cls._init = False
        cls._backend = None
        cls._prefix = None
        cls._expire = None
        cls._coder = None
        cls._key_builder = None
        cls._cache_status_header = None
        cls._enable = True

    @classmethod
    def get_backend(cls) -> Backend:
        """Return the configured backend."""
        assert cls._backend, "You must call init first!"  # noqa: S101
        return cls._backend

    @classmethod
    def get_prefix(cls) -> str:
        """Return the configured key prefix."""
        assert cls._prefix is not None, "You must call init first!"  # noqa: S101
        return cls._prefix

    @classmethod
    def get_expire(cls) -> int | None:
        """Return the configured default TTL in seconds."""
        return cls._expire

    @classmethod
    def get_coder(cls) -> type[Coder]:
        """Return the configured coder class."""
        assert cls._coder, "You must call init first!"  # noqa: S101
        return cls._coder

    @classmethod
    def get_key_builder(cls) -> KeyBuilder:
        """Return the configured key builder."""
        assert cls._key_builder, "You must call init first!"  # noqa: S101
        return cls._key_builder

    @classmethod
    def get_cache_status_header(cls) -> str:
        """Return the configured cache status header name."""
        assert cls._cache_status_header, "You must call init first!"  # noqa: S101
        return cls._cache_status_header

    @classmethod
    def get_enable(cls) -> bool:
        """Return whether caching is globally enabled."""
        return cls._enable

    @classmethod
    async def clear(cls, namespace: str | None = None, key: str | None = None) -> int:
        """Clear cached keys.

        Args:
            namespace: Clear all keys under this namespace.
            key: Clear a specific key.

        Returns:
            Number of keys cleared.
        """
        assert cls._backend, "You must call init first!"  # noqa: S101
        assert cls._prefix is not None, "You must call init first!"  # noqa: S101
        namespace = cls._prefix + (":" + namespace if namespace else "")
        return await cls._backend.clear(namespace, key)
