"""Cache decorator for FastAPI endpoints."""

import logging
from collections.abc import Awaitable, Callable
from functools import wraps
from inspect import Parameter, Signature, isawaitable, iscoroutinefunction
from typing import (
    ParamSpec,
    TypeVar,
    cast,
)

from fastapi.concurrency import run_in_threadpool
from fastapi.dependencies.utils import (
    get_typed_return_annotation,
    get_typed_signature,
)
from starlette.requests import Request
from starlette.responses import Response
from starlette.status import HTTP_304_NOT_MODIFIED

from fastapi_cache import FastAPICache
from fastapi_cache.coder import Coder
from fastapi_cache.types import KeyBuilder

logger: logging.Logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

P = ParamSpec("P")
R = TypeVar("R")


def _augment_signature(signature: Signature, *extra: Parameter) -> Signature:
    """Append extra parameters to a function signature.

    Variadic keyword parameters (``**kwargs``) are kept at the end.

    Args:
        signature: Original function signature.
        *extra: Additional parameters to append.

    Returns:
        Updated ``Signature`` with extra parameters inserted.
    """
    if not extra:
        return signature

    parameters = list(signature.parameters.values())
    variadic_keyword_params: list[Parameter] = []
    while parameters and parameters[-1].kind is Parameter.VAR_KEYWORD:
        variadic_keyword_params.append(parameters.pop())

    return signature.replace(parameters=[*parameters, *extra, *variadic_keyword_params])


def _locate_param(sig: Signature, dep: Parameter, to_inject: list[Parameter]) -> Parameter:
    """Find a parameter by annotation in a signature.

    If no matching parameter is found, ``dep`` is appended to
    ``to_inject`` and returned as the resolved parameter.

    Args:
        sig: Function signature to search.
        dep: Parameter whose annotation to match.
        to_inject: List to append ``dep`` to when not found.

    Returns:
        Matched or injected parameter.
    """
    param = next(
        (p for p in sig.parameters.values() if p.annotation is dep.annotation),
        None,
    )
    if param is None:
        to_inject.append(dep)
        param = dep
    return param


def _uncacheable(request: Request | None) -> bool:
    """Return ``True`` when the current request must not be cached.

    A request is not cacheable when:

    - Caching is disabled globally via ``FastAPICache.init(enable=False)``.
    - The request method is not ``GET``.
    - The request carries ``Cache-Control: no-store``.

    Args:
        request: Current HTTP request, or ``None`` if not available.

    Returns:
        ``True`` if the response must not be cached.
    """
    if not FastAPICache.get_enable():
        return True
    if request is None:
        return False
    if request.method != "GET":
        return True
    return request.headers.get("Cache-Control") == "no-store"


def cache(
    expire: int | None = None,
    coder: type[Coder] | None = None,
    key_builder: KeyBuilder | None = None,
    namespace: str = "",
    injected_dependency_namespace: str = "__fastapi_cache",
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R | Response]]]:
    """Cache the return value of a FastAPI endpoint.

    Responses are stored in the configured backend and served from cache
    on subsequent identical requests. ``Cache-Control`` and ``ETag`` headers
    are set automatically; ``304 Not Modified`` is returned when the client's
    ``If-None-Match`` header matches the cached ETag.

    Args:
        expire: TTL in seconds for this endpoint. Overrides the global
            default set in ``FastAPICache.init()``. ``0`` disables expiry
            for this endpoint explicitly.
        coder: Encoder/decoder to use. Defaults to the global coder.
        key_builder: Key builder callable. Defaults to the global builder.
        namespace: Key namespace suffix for this endpoint.
        injected_dependency_namespace: Prefix used when injecting
            ``Request`` and ``Response`` parameters into the endpoint
            signature.

    Returns:
        Decorator that wraps the endpoint with caching logic.

    Example:
        ```python
        @app.get("/items/{item_id}")
        @cache(expire=60)
        async def get_item(item_id: int) -> Item:
            ...
        ```
    """
    injected_request = Parameter(
        name=f"{injected_dependency_namespace}_request",
        annotation=Request,
        kind=Parameter.KEYWORD_ONLY,
    )
    injected_response = Parameter(
        name=f"{injected_dependency_namespace}_response",
        annotation=Response,
        kind=Parameter.KEYWORD_ONLY,
    )

    def wrapper(
        func: Callable[P, Awaitable[R]],
    ) -> Callable[P, Awaitable[R | Response]]:
        # Resolve forward references before inspecting the signature.
        wrapped_signature = get_typed_signature(func)
        to_inject: list[Parameter] = []
        request_param = _locate_param(wrapped_signature, injected_request, to_inject)
        response_param = _locate_param(wrapped_signature, injected_response, to_inject)
        return_type = get_typed_return_annotation(func)

        @wraps(func)
        async def inner(*args: P.args, **kwargs: P.kwargs) -> R | Response:
            nonlocal coder
            nonlocal expire
            nonlocal key_builder

            async def ensure_async_func(*args: P.args, **kwargs: P.kwargs) -> R:
                """Run sync endpoints in a thread pool, mirroring FastAPI behaviour."""
                kwargs.pop(injected_request.name, None)
                kwargs.pop(injected_response.name, None)

                if iscoroutinefunction(func):
                    return await func(*args, **kwargs)
                return await run_in_threadpool(func, *args, **kwargs)  # type: ignore[arg-type]

            copy_kwargs = kwargs.copy()
            request: Request | None = copy_kwargs.pop(request_param.name, None)  # type: ignore[assignment]
            response: Response | None = copy_kwargs.pop(response_param.name, None)  # type: ignore[assignment]

            if _uncacheable(request):
                return await ensure_async_func(*args, **kwargs)

            prefix = FastAPICache.get_prefix()
            coder = coder or FastAPICache.get_coder()
            # Use `is None` so that expire=0 (no expiry) is respected.
            if expire is None:
                expire = FastAPICache.get_expire()
            key_builder = key_builder or FastAPICache.get_key_builder()
            backend = FastAPICache.get_backend()
            cache_status_header = FastAPICache.get_cache_status_header()

            cache_key = key_builder(
                func,
                f"{prefix}:{namespace}",
                request=request,
                response=response,
                args=args,
                kwargs=copy_kwargs,
            )
            if isawaitable(cache_key):
                cache_key = await cache_key
            assert isinstance(cache_key, str)  # noqa: S101  # type guard

            try:
                ttl, cached = await backend.get_with_ttl(cache_key)
            except Exception:
                logger.warning(
                    "Error retrieving cache key %r from backend:",
                    cache_key,
                    exc_info=True,
                )
                ttl, cached = 0, None

            no_cache = request is not None and request.headers.get("Cache-Control") == "no-cache"

            if cached is None or no_cache:
                result = await ensure_async_func(*args, **kwargs)
                to_cache = coder.encode(result)

                try:
                    await backend.set(cache_key, to_cache, expire)
                except Exception:
                    logger.warning(
                        "Error setting cache key %r in backend:",
                        cache_key,
                        exc_info=True,
                    )

                if response:
                    response.headers.update(
                        {
                            "Cache-Control": f"max-age={expire}",
                            "ETag": f"W/{hash(to_cache)}",
                            cache_status_header: "MISS",
                        }
                    )

            else:
                etag = f"W/{hash(cached)}"

                if response:
                    response.headers.update(
                        {
                            "Cache-Control": f"max-age={ttl}",
                            "ETag": etag,
                            cache_status_header: "HIT",
                        }
                    )

                    if_none_match = request and request.headers.get("if-none-match")
                    if if_none_match == etag:
                        response.status_code = HTTP_304_NOT_MODIFIED
                        return response

                result = cast("R", coder.decode_as_type(cached, type_=return_type))

            return result

        inner.__signature__ = _augment_signature(wrapped_signature, *to_inject)  # type: ignore[attr-defined]

        return inner

    return wrapper
