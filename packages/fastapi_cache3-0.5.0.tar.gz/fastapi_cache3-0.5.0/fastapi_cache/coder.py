"""Encoder/decoder implementations for cache serialization."""

import dataclasses
import datetime
import pickle  # nosec:B403
from collections.abc import Callable
from decimal import Decimal
from typing import (
    Any,
    TypeVar,
    get_origin,
    overload,
)

import orjson
import pendulum
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel
from starlette.responses import JSONResponse
from starlette.templating import (
    _TemplateResponse as TemplateResponse,  # pyright: ignore[reportPrivateUsage]
)

_T = TypeVar("_T", bound=type)

CONVERTERS: dict[str, Callable[[str], Any]] = {
    "date": lambda x: pendulum.parse(x, exact=True),
    "datetime": lambda x: pendulum.parse(x, exact=True),
    "decimal": Decimal,
}


def _default(o: Any) -> Any:
    """Orjson default serializer for types not natively supported."""
    if isinstance(o, datetime.datetime):
        return {"val": str(o), "_spec_type": "datetime"}
    if isinstance(o, datetime.date):
        return {"val": str(o), "_spec_type": "date"}
    if isinstance(o, Decimal):
        return {"val": str(o), "_spec_type": "decimal"}
    return jsonable_encoder(o)


def _object_hook(obj: dict[str, Any]) -> Any:
    """Reconstruct special types encoded by ``_default``."""
    spec_type = obj.get("_spec_type")
    if not spec_type:
        return obj
    if spec_type in CONVERTERS:
        return CONVERTERS[spec_type](obj["val"])
    raise TypeError(f"Unknown _spec_type: {spec_type!r}")


def _walk(obj: Any) -> Any:
    """Recursively apply ``_object_hook`` to decoded JSON.

    orjson does not support ``object_hook``, so we walk the decoded
    structure manually to reconstruct special types.
    """
    if isinstance(obj, dict):
        walked = {k: _walk(v) for k, v in obj.items()}
        return _object_hook(walked)
    if isinstance(obj, list):
        return [_walk(item) for item in obj]
    return obj


def _coerce(value: Any, type_: type[Any]) -> Any:
    """Coerce a decoded value to the target type.

    Handles:

    - ``tuple`` — JSON arrays are decoded as lists.
    - dataclasses — reconstructed via ``**kwargs``.
    - Pydantic models — validated via ``model_validate``.
    """
    origin = get_origin(type_)
    if origin is tuple and isinstance(value, list):
        return tuple(value)
    if isinstance(value, dict):
        if dataclasses.is_dataclass(type_) and isinstance(type_, type):
            return type_(**value)
        if isinstance(type_, type) and issubclass(type_, BaseModel):
            return type_.model_validate(value)
    return value


class Coder:
    """Base class for cache encoders/decoders."""

    @classmethod
    def encode(cls, value: Any) -> bytes:
        """Encode a value to bytes for storage."""
        raise NotImplementedError

    @classmethod
    def decode(cls, value: bytes) -> Any:
        """Decode bytes retrieved from the cache."""
        raise NotImplementedError

    @overload
    @classmethod
    def decode_as_type(cls, value: bytes, *, type_: _T) -> _T: ...

    @overload
    @classmethod
    def decode_as_type(cls, value: bytes, *, type_: None) -> Any: ...

    @classmethod
    def decode_as_type(cls, value: bytes, *, type_: _T | None) -> _T | Any:
        """Decode and coerce the result to ``type_``.

        Args:
            value: Raw bytes from the cache.
            type_: Target type for coercion. Pass ``None`` to skip coercion.

        Returns:
            Decoded value, coerced to ``type_`` when provided.
        """
        result = cls.decode(value)
        if type_ is None:
            return result
        return _coerce(result, type_)


class JsonCoder(Coder):
    """JSON-based coder using orjson.

    Supports ``datetime``, ``date``, ``Decimal``, Pydantic models,
    and dataclasses in addition to standard JSON types.
    """

    @classmethod
    def encode(cls, value: Any) -> bytes:
        """Encode ``value`` to JSON bytes."""
        if isinstance(value, JSONResponse):
            return value.body
        return orjson.dumps(value, default=_default)

    @classmethod
    def decode(cls, value: bytes) -> Any:
        """Decode JSON bytes, reconstructing special types."""
        return _walk(orjson.loads(value))


class PickleCoder(Coder):
    """Pickle-based coder.

    Preserves exact Python types on round-trip. Suitable for complex
    objects that cannot be JSON-serialized, such as Jinja2
    ``TemplateResponse``.

    Warning:
        Never unpickle data from untrusted sources.
    """

    @classmethod
    def encode(cls, value: Any) -> bytes:
        """Encode ``value`` to pickle bytes."""
        if isinstance(value, TemplateResponse):
            value = value.body
        return pickle.dumps(value)

    @classmethod
    def decode(cls, value: bytes) -> Any:
        """Decode pickle bytes."""
        return pickle.loads(value)  # noqa: S301

    @classmethod
    def decode_as_type(cls, value: bytes, *, type_: Any | None) -> Any:
        """Decode pickle bytes; coercion is unnecessary as pickle preserves types."""
        return cls.decode(value)
