"""Redis cache backend."""

from __future__ import annotations

from typing import TYPE_CHECKING

from redis.asyncio.cluster import RedisCluster

from fastapi_cache.types import Backend

if TYPE_CHECKING:
    from redis.asyncio.client import Redis


class RedisBackend(Backend):
    """Cache backend backed by Redis or Redis Cluster.

    Args:
        redis: An async Redis or RedisCluster client configured with
            ``decode_responses=False`` (binary mode).
    """

    def __init__(self, redis: Redis[bytes] | RedisCluster[bytes]) -> None:
        """Initialise the backend with a Redis client."""
        self.redis = redis
        self.is_cluster: bool = isinstance(redis, RedisCluster)

    async def get_with_ttl(self, key: str) -> tuple[int, bytes | None]:
        """Return the cached value and remaining TTL for ``key``."""
        async with self.redis.pipeline(transaction=not self.is_cluster) as pipe:
            return await pipe.ttl(key).get(key).execute()  # type: ignore[union-attr,no-any-return]

    async def get(self, key: str) -> bytes | None:
        """Return the cached value for ``key``, or ``None`` on a miss."""
        return await self.redis.get(key)  # type: ignore[union-attr]

    async def set(self, key: str, value: bytes, expire: int | None = None) -> None:
        """Store ``value`` under ``key`` with an optional TTL."""
        await self.redis.set(key, value, ex=expire)  # type: ignore[union-attr]

    async def clear(self, namespace: str | None = None, key: str | None = None) -> int:
        """Delete keys by namespace prefix or specific key.

        Args:
            namespace: Remove all keys matching ``namespace:*`` via a Lua script.
            key: Remove this specific key.

        Returns:
            Number of keys removed.
        """
        if namespace:
            lua = (
                f"for i, name in ipairs(redis.call('KEYS', '{namespace}:*')) "
                "do redis.call('DEL', name); end"
            )
            return await self.redis.eval(lua, numkeys=0)  # type: ignore[union-attr,no-any-return]
        if key:
            return await self.redis.delete(key)  # type: ignore[union-attr]
        return 0
