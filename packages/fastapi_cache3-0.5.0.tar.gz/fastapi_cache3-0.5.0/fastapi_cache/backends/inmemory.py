"""In-memory cache backend."""

import time
from asyncio import Lock
from dataclasses import dataclass
from typing import ClassVar

from fastapi_cache.types import Backend


@dataclass
class Value:
    """A cached value with an expiry timestamp."""

    data: bytes
    ttl_ts: int


class InMemoryBackend(Backend):
    """Thread-safe in-memory cache backend.

    Uses an ``asyncio.Lock`` to protect concurrent access. Expired keys
    are removed lazily on access rather than via a background task.
    """

    _store: ClassVar[dict[str, Value]] = {}
    _lock: ClassVar[Lock] = Lock()

    @property
    def _now(self) -> int:
        """Return the current Unix timestamp as an integer."""
        return int(time.time())

    def _get(self, key: str) -> Value | None:
        v = self._store.get(key)
        if v:
            if v.ttl_ts < self._now:
                del self._store[key]
            else:
                return v
        return None

    async def get_with_ttl(self, key: str) -> tuple[int, bytes | None]:
        """Return the cached value and remaining TTL for ``key``."""
        async with self._lock:
            v = self._get(key)
            if v:
                return v.ttl_ts - self._now, v.data
            return 0, None

    async def get(self, key: str) -> bytes | None:
        """Return the cached value for ``key``, or ``None`` on a miss."""
        async with self._lock:
            v = self._get(key)
            if v:
                return v.data
            return None

    async def set(self, key: str, value: bytes, expire: int | None = None) -> None:
        """Store ``value`` under ``key`` with an optional TTL."""
        async with self._lock:
            self._store[key] = Value(value, self._now + (expire or 0))

    async def clear(self, namespace: str | None = None, key: str | None = None) -> int:
        """Delete keys by namespace prefix or specific key.

        Args:
            namespace: Remove all keys that start with this prefix.
            key: Remove this specific key.

        Returns:
            Number of keys removed.
        """
        count = 0
        if namespace:
            keys = list(self._store.keys())
            for k in keys:
                if k.startswith(namespace):
                    del self._store[k]
                    count += 1
        elif key:
            del self._store[key]
            count += 1
        return count
