"""Memcached cache backend."""

from aiomcache import Client

from fastapi_cache.types import Backend


class MemcachedBackend(Backend):
    """Cache backend backed by Memcached.

    Note: Memcached does not expose the remaining TTL of stored keys.
    ``get_with_ttl`` returns a fixed value of ``3600`` seconds.

    Args:
        mcache: An ``aiomcache.Client`` instance.
    """

    def __init__(self, mcache: Client) -> None:
        """Initialise the backend with a Memcached client."""
        self.mcache = mcache

    async def get_with_ttl(self, key: str) -> tuple[int, bytes | None]:
        """Return the cached value and a fixed TTL of 3600 seconds."""
        return 3600, await self.get(key)

    async def get(self, key: str) -> bytes | None:
        """Return the cached value for ``key``, or ``None`` on a miss."""
        return await self.mcache.get(key.encode())

    async def set(self, key: str, value: bytes, expire: int | None = None) -> None:
        """Store ``value`` under ``key`` with an optional TTL."""
        await self.mcache.set(key.encode(), value, exptime=expire or 0)

    async def clear(self, namespace: str | None = None, key: str | None = None) -> int:
        """Not supported by Memcached.

        Raises:
            NotImplementedError: Always.
        """
        raise NotImplementedError
