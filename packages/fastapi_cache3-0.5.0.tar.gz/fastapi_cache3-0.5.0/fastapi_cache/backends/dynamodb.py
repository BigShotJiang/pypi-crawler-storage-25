"""Amazon DynamoDB cache backend."""

import datetime
from typing import TYPE_CHECKING

from aiobotocore.client import AioBaseClient
from aiobotocore.session import AioSession, get_session

from fastapi_cache.types import Backend

if TYPE_CHECKING:
    from types_aiobotocore_dynamodb import DynamoDBClient
else:
    DynamoDBClient = AioBaseClient


class DynamoBackend(Backend):
    """Amazon DynamoDB backend provider.

    Requires an existing DynamoDB table. If TTL support is needed, enable
    it manually on the table using the ``ttl`` attribute name. DynamoDB
    handles expired-item deletion asynchronously (eventual consistency),
    so this backend checks expiry locally on every read.

    AWS credentials are read from the environment via the standard SDK
    credential chain.

    Example:
        ```python
        dynamodb = DynamoBackend(table_name="your-cache", region="eu-west-1")
        await dynamodb.init()
        FastAPICache.init(dynamodb)
        ```
    """

    client: DynamoDBClient
    session: AioSession
    table_name: str
    region: str | None

    def __init__(self, table_name: str, region: str | None = None) -> None:
        """Initialise the backend.

        Args:
            table_name: Name of the DynamoDB table to use.
            region: AWS region name. Defaults to the SDK default.
        """
        self.session = get_session()
        self.table_name = table_name
        self.region = region

    async def init(self) -> None:
        """Create the underlying DynamoDB client. Call before use."""
        self.client = await self.session.create_client(  # pyright: ignore[reportUnknownMemberType]
            "dynamodb", region_name=self.region
        ).__aenter__()

    async def close(self) -> None:
        """Close the underlying DynamoDB client."""
        await self.client.__aexit__(None, None, None)

    async def get_with_ttl(self, key: str) -> tuple[int, bytes | None]:
        """Return the cached value and remaining TTL for ``key``."""
        response = await self.client.get_item(TableName=self.table_name, Key={"key": {"S": key}})

        if "Item" in response:
            value = response["Item"].get("value", {}).get("B")
            ttl = response["Item"].get("ttl", {}).get("N")

            if not ttl:
                return -1, value

            # DynamoDB deletes expired items eventually; check locally.
            expire = int(ttl) - int(datetime.datetime.now().timestamp())
            if expire > 0:
                return expire, value

        return 0, None

    async def get(self, key: str) -> bytes | None:
        """Return the cached value for ``key``, or ``None`` on a miss."""
        response = await self.client.get_item(TableName=self.table_name, Key={"key": {"S": key}})
        if "Item" in response:
            return response["Item"].get("value", {}).get("B")
        return None

    async def set(self, key: str, value: bytes, expire: int | None = None) -> None:
        """Store ``value`` under ``key`` with an optional TTL."""
        ttl = (
            {
                "ttl": {
                    "N": str(
                        int(
                            (
                                datetime.datetime.now() + datetime.timedelta(seconds=expire)
                            ).timestamp()
                        )
                    )
                }
            }
            if expire
            else {}
        )

        await self.client.put_item(
            TableName=self.table_name,
            Item={
                "key": {"S": key},
                "value": {"B": value},
                **ttl,
            },
        )

    async def clear(self, namespace: str | None = None, key: str | None = None) -> int:
        """Not supported by DynamoDB.

        Raises:
            NotImplementedError: Always.
        """
        raise NotImplementedError
