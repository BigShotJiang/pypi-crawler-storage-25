"""Default cache key builder implementation."""

import hashlib
from collections.abc import Callable
from typing import Any

from starlette.requests import Request
from starlette.responses import Response


def default_key_builder(
    func: Callable[..., Any],
    namespace: str = "",
    *,
    request: Request | None = None,
    response: Response | None = None,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> str:
    """Build a cache key from the function identity and call arguments.

    The key is an MD5 hash of ``module:qualname:args:kwargs``, prefixed
    by ``namespace``.

    Args:
        func: The decorated endpoint function.
        namespace: Key namespace (typically ``prefix:user_namespace``).
        request: Current HTTP request (unused by default).
        response: Current HTTP response (unused by default).
        args: Positional arguments passed to the function.
        kwargs: Keyword arguments passed to the function.

    Returns:
        Cache key string in the form ``namespace:md5hash``.
    """
    cache_key = hashlib.md5(  # noqa: S324
        f"{func.__module__}:{func.__qualname__}:{args}:{kwargs}".encode()
    ).hexdigest()
    return f"{namespace}:{cache_key}"
