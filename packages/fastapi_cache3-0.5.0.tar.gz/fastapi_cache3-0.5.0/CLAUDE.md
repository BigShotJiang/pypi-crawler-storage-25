# fastapi-cache3

Pluggable cache decorator library for FastAPI. Supports Redis, Memcached, DynamoDB, and InMemory backends.

## Development Environment

Package manager is **uv**.

```bash
# Install dependencies
make deps

# Upgrade all dependencies
make up
```

## Common Commands

```bash
# Run tests
make test

# Lint (ruff + mypy)
make lint

# Ruff fix + format
make ruff

# Mypy type check
make mypy

# Build distribution
make build
```

## Testing

```bash
uv run pytest tests/ -v
uv run pytest tests/test_backends.py -v      # backend tests only
uv run pytest tests/test_codecs.py -v        # coder tests only
uv run pytest tests/test_decorator.py -v     # decorator tests only
```

## Project Layout

```
fastapi_cache/
├── __init__.py          # FastAPICache main class
├── decorator.py         # @cache decorator
├── coder.py             # JsonCoder (orjson) + PickleCoder
├── key_builder.py       # MD5-based cache key generation
├── types.py             # Backend and KeyBuilder protocols
└── backends/
    ├── inmemory.py      # asyncio.Lock-based in-memory backend
    ├── redis.py         # redis.asyncio backend (cluster supported)
    ├── memcached.py     # aiomcache backend
    └── dynamodb.py      # aiobotocore DynamoDB backend
```

## Architecture

- **Backend Protocol** (`types.py`): `get`, `get_with_ttl`, `set`, `clear` methods
- **Coder**: `JsonCoder` default (orjson), `PickleCoder` alternative
- **KeyBuilder**: `{namespace}:{md5(module:func:args:kwargs)}`
- **Decorator** (`decorator.py`): injects `Request`/`Response` via FastAPI dependency injection, manages ETag + Cache-Control headers

## Important Notes

- `JsonCoder` uses orjson — not the stdlib `json` module
- `decode_as_type()` auto-reconstructs Pydantic models and dataclasses
- Backend errors degrade gracefully (if cache fails, the function runs directly)
- Only GET requests are cached; `Cache-Control: no-store` disables caching entirely
- Async tests require `@pytest.mark.asyncio`

## Code Quality Standards

- **Line length**: 100
- **Docstrings**: Google style required (ruff `D` + `convention = "google"`)
- **Type annotations**: required on all functions (ruff `ANN`); `Any` only in coder/decoder interfaces (`ANN401` ignored)
- **Coverage threshold**: 80% (pytest `--cov-fail-under=80`, branch coverage enabled)
- **Active ruff rule groups**: `ANN`, `B`, `C4`, `D`, `E`, `F`, `I`, `PIE`, `PT`, `RET`, `RUF`, `S`, `SIM`, `T20`, `TCH`, `UP`, `W`
- **Test dirs** (`tests/`, `examples/`) are exempt from `D`, `ANN`, and a few other rules — see `per-file-ignores`
- Before commit: `make lint` runs both `ruff check` and `ruff format --check` (does NOT auto-fix)
- For auto-fix use `make ruff`

## Dependency Groups

| Group | Purpose |
|-------|---------|
| `linting` | mypy, ruff, type stubs |
| `dev` | pytest, httpx, tox, towncrier |
| `distributing` | twine |

Optional extras: `redis`, `memcache`, `dynamodb`, `all`
