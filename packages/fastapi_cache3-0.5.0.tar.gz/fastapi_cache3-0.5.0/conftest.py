"""Root pytest configuration."""
