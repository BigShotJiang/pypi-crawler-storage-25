from collections.abc import Iterator
from unittest.mock import AsyncMock, MagicMock

import pytest
from starlette.testclient import TestClient

from examples.in_memory.main import app
from fastapi_cache import FastAPICache
from fastapi_cache.backends.inmemory import InMemoryBackend


@pytest.fixture(autouse=True)
def _init_cache() -> Iterator[None]:
    FastAPICache.init(InMemoryBackend())
    yield
    FastAPICache.reset()


@pytest.fixture
def client() -> Iterator[TestClient]:
    with TestClient(app) as c:
        yield c


@pytest.fixture
def inmemory_backend() -> InMemoryBackend:
    InMemoryBackend._store = {}  # pyright: ignore[reportPrivateUsage]
    return InMemoryBackend()


@pytest.fixture
def redis_mock() -> MagicMock:
    mock = MagicMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock()
    mock.delete = AsyncMock(return_value=0)
    mock.eval = AsyncMock(return_value=0)
    return mock


@pytest.fixture
def memcached_mock() -> MagicMock:
    mock = MagicMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock()
    return mock


@pytest.fixture
def dynamo_mock_client() -> MagicMock:
    mock = MagicMock()
    mock.put_item = AsyncMock()
    mock.get_item = AsyncMock(return_value={})
    return mock
