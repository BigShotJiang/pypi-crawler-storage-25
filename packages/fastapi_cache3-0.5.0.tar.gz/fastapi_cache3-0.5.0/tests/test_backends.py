import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from fastapi_cache.backends.inmemory import InMemoryBackend
from fastapi_cache.backends.memcached import MemcachedBackend
from fastapi_cache.backends.redis import RedisBackend


class TestInMemoryBackend:
    @pytest.fixture(autouse=True)
    def setup(self, inmemory_backend: InMemoryBackend) -> None:
        self.backend = inmemory_backend

    @pytest.mark.asyncio
    async def test_set_and_get(self) -> None:
        await self.backend.set("key1", b"value1", expire=60)
        assert await self.backend.get("key1") == b"value1"

    @pytest.mark.asyncio
    async def test_get_nonexistent(self) -> None:
        assert await self.backend.get("nonexistent") is None

    @pytest.mark.asyncio
    async def test_get_with_ttl(self) -> None:
        await self.backend.set("key1", b"value1", expire=60)
        ttl, data = await self.backend.get_with_ttl("key1")
        assert data == b"value1"
        assert 0 < ttl <= 60

    @pytest.mark.asyncio
    async def test_get_with_ttl_nonexistent(self) -> None:
        ttl, data = await self.backend.get_with_ttl("nonexistent")
        assert ttl == 0
        assert data is None

    @pytest.mark.asyncio
    async def test_expired_key(self) -> None:
        await self.backend.set("key1", b"value1", expire=1)
        time.sleep(2)
        assert await self.backend.get("key1") is None

    @pytest.mark.asyncio
    async def test_clear_by_namespace(self) -> None:
        await self.backend.set("ns:key1", b"v1", expire=60)
        await self.backend.set("ns:key2", b"v2", expire=60)
        await self.backend.set("other:key3", b"v3", expire=60)

        count = await self.backend.clear(namespace="ns")

        assert count == 2
        assert await self.backend.get("ns:key1") is None
        assert await self.backend.get("other:key3") == b"v3"

    @pytest.mark.asyncio
    async def test_clear_by_key(self) -> None:
        await self.backend.set("key1", b"v1", expire=60)
        assert await self.backend.clear(key="key1") == 1
        assert await self.backend.get("key1") is None


class TestRedisBackend:
    @pytest.fixture(autouse=True)
    def setup(self, redis_mock: MagicMock) -> None:
        self.mock = redis_mock
        self.backend = RedisBackend(redis_mock)

    @pytest.mark.asyncio
    async def test_set_and_get(self) -> None:
        self.mock.get.return_value = b"value1"

        await self.backend.set("key1", b"value1", expire=60)
        self.mock.set.assert_called_once_with("key1", b"value1", ex=60)

        assert await self.backend.get("key1") == b"value1"

    @pytest.mark.asyncio
    async def test_get_with_ttl(self) -> None:
        mock_pipe = MagicMock()
        mock_pipe.ttl = MagicMock(return_value=mock_pipe)
        mock_pipe.get = MagicMock(return_value=mock_pipe)
        mock_pipe.execute = AsyncMock(return_value=[45, b"value1"])

        mock_ctx = MagicMock()
        mock_ctx.__aenter__ = AsyncMock(return_value=mock_pipe)
        mock_ctx.__aexit__ = AsyncMock(return_value=None)
        self.mock.pipeline = MagicMock(return_value=mock_ctx)

        ttl, data = await self.backend.get_with_ttl("key1")
        assert ttl == 45
        assert data == b"value1"

    @pytest.mark.asyncio
    async def test_clear_by_key(self) -> None:
        self.mock.delete.return_value = 1
        assert await self.backend.clear(key="key1") == 1
        self.mock.delete.assert_called_once_with("key1")

    @pytest.mark.asyncio
    async def test_clear_by_namespace(self) -> None:
        self.mock.eval.return_value = 2
        assert await self.backend.clear(namespace="ns") == 2

    @pytest.mark.asyncio
    async def test_clear_no_args(self) -> None:
        assert await self.backend.clear() == 0


class TestMemcachedBackend:
    @pytest.fixture(autouse=True)
    def setup(self, memcached_mock: MagicMock) -> None:
        self.mock = memcached_mock
        self.backend = MemcachedBackend(memcached_mock)

    @pytest.mark.asyncio
    async def test_set_and_get(self) -> None:
        self.mock.get.return_value = b"value1"

        await self.backend.set("key1", b"value1", expire=60)
        self.mock.set.assert_called_once_with(b"key1", b"value1", exptime=60)

        assert await self.backend.get("key1") == b"value1"

    @pytest.mark.asyncio
    async def test_get_with_ttl_returns_fixed(self) -> None:
        """Memcached does not expose TTL; a fixed value of 3600 is returned."""
        self.mock.get.return_value = b"value1"
        ttl, data = await self.backend.get_with_ttl("key1")
        assert ttl == 3600
        assert data == b"value1"

    @pytest.mark.asyncio
    async def test_clear_raises(self) -> None:
        with pytest.raises(NotImplementedError):
            await self.backend.clear()


class TestDynamoBackend:
    @pytest.fixture(autouse=True)
    def setup(self, dynamo_mock_client: MagicMock) -> None:
        from fastapi_cache.backends.dynamodb import DynamoBackend

        self.mock = dynamo_mock_client
        self.backend = DynamoBackend(table_name="test-table")
        self.backend.client = dynamo_mock_client

    @pytest.mark.asyncio
    async def test_set_and_get(self) -> None:
        self.mock.get_item.return_value = {"Item": {"key": {"S": "k"}, "value": {"B": b"v"}}}
        await self.backend.set("k", b"v", expire=60)
        self.mock.put_item.assert_called_once()
        assert await self.backend.get("k") == b"v"

    @pytest.mark.asyncio
    async def test_get_nonexistent(self) -> None:
        assert await self.backend.get("nonexistent") is None

    @pytest.mark.asyncio
    async def test_get_with_ttl_no_ttl(self) -> None:
        """Items without a TTL attribute return -1 as the TTL."""
        self.mock.get_item.return_value = {"Item": {"key": {"S": "k"}, "value": {"B": b"v"}}}
        ttl, data = await self.backend.get_with_ttl("k")
        assert ttl == -1
        assert data == b"v"

    @pytest.mark.asyncio
    async def test_get_with_ttl_expired(self) -> None:
        """Expired items are treated as misses (eventual consistency workaround)."""
        self.mock.get_item.return_value = {
            "Item": {
                "key": {"S": "k"},
                "value": {"B": b"v"},
                "ttl": {"N": "1000000"},
            }
        }
        ttl, data = await self.backend.get_with_ttl("k")
        assert ttl == 0
        assert data is None

    @pytest.mark.asyncio
    async def test_clear_raises(self) -> None:
        with pytest.raises(NotImplementedError):
            await self.backend.clear()
