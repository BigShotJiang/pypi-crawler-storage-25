import time

import pendulum
from starlette.testclient import TestClient

from fastapi_cache import FastAPICache


def test_datetime(client: TestClient) -> None:
    response = client.get("/datetime")
    assert response.headers.get("X-FastAPI-Cache") == "MISS"
    now_ = pendulum.parse(response.json().get("now"))

    response = client.get("/datetime")
    assert response.headers.get("X-FastAPI-Cache") == "HIT"
    assert pendulum.parse(response.json().get("now")) == now_

    time.sleep(3)
    response = client.get("/datetime")
    assert response.headers.get("X-FastAPI-Cache") == "MISS"
    assert pendulum.parse(response.json().get("now")) != now_


def test_date(client: TestClient) -> None:
    """Endpoint without explicit request/response parameters."""
    response = client.get("/date")
    assert response.headers.get("X-FastAPI-Cache") == "MISS"
    assert pendulum.parse(response.json()) == pendulum.today()

    response = client.get("/date")
    assert response.headers.get("X-FastAPI-Cache") == "HIT"
    assert pendulum.parse(response.json()) == pendulum.today()

    FastAPICache._enable = False  # pyright: ignore[reportPrivateUsage]
    response = client.get("/date")
    assert "X-FastAPI-Cache" not in response.headers
    assert pendulum.parse(response.json()) == pendulum.today()
    FastAPICache._enable = True  # pyright: ignore[reportPrivateUsage]


def test_sync(client: TestClient) -> None:
    """Sync endpoints are wrapped in a thread pool."""
    response = client.get("/sync-me")
    assert response.json() == 42


def test_cache_response_obj(client: TestClient) -> None:
    assert client.get("/cache_response_obj").json() == {"a": 1}

    cached = client.get("/cache_response_obj")
    assert cached.json() == {"a": 1}
    assert cached.headers.get("cache-control")
    assert cached.headers.get("etag")


def test_kwargs(client: TestClient) -> None:
    name = "Jon"
    response = client.get("/kwargs", params={"name": name})
    assert "X-FastAPI-Cache" not in response.headers
    assert response.json() == {"name": name}


def test_method(client: TestClient) -> None:
    assert client.get("/method").json() == 17


def test_pydantic_model(client: TestClient) -> None:
    r1 = client.get("/pydantic_instance")
    assert r1.headers.get("X-FastAPI-Cache") == "MISS"

    r2 = client.get("/pydantic_instance")
    assert r2.headers.get("X-FastAPI-Cache") == "HIT"
    assert r1.json() == r2.json()


def test_non_get(client: TestClient) -> None:
    """PUT requests are never cached."""
    r1 = client.put("/uncached_put")
    assert "X-FastAPI-Cache" not in r1.headers
    assert r1.json() == {"value": 1}

    r2 = client.put("/uncached_put")
    assert "X-FastAPI-Cache" not in r2.headers
    assert r2.json() == {"value": 2}


def test_alternate_injected_namespace(client: TestClient) -> None:
    response = client.get("/namespaced_injection")
    assert response.headers.get("X-FastAPI-Cache") == "MISS"
    assert response.json() == {
        "__fastapi_cache_request": 42,
        "__fastapi_cache_response": 17,
    }


def test_cache_control(client: TestClient) -> None:
    assert client.get("/cached_put").json() == {"value": 1}
    assert client.get("/cached_put").json() == {"value": 1}  # HIT

    # no-cache: bypasses cache but stores new result
    assert client.get("/cached_put", headers={"Cache-Control": "no-cache"}).json() == {"value": 2}
    assert client.get("/cached_put").json() == {"value": 2}  # HIT new value

    # no-store: bypasses cache entirely, does not update stored value
    assert client.get("/cached_put", headers={"Cache-Control": "no-store"}).json() == {"value": 3}
    assert client.get("/cached_put").json() == {"value": 2}  # still old HIT
