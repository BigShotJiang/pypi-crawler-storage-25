# GitHub Copilot Instructions

## Project Overview

`fastapi-cache3` is a caching library for FastAPI with pluggable backends (Redis, Memcached, DynamoDB, InMemory).

## Key Conventions

- **Package manager**: uv — use `uv add`, `uv sync`, never pip
- **Python**: 3.10+, strict type annotations required on all functions (ruff `ANN`)
- **JSON**: use `orjson` not stdlib `json`
- **Async**: all backend methods are async; use `asyncio.Lock` for thread safety in InMemory
- **Linting**: ruff with line-length 100; run `make lint` before suggesting code
- **Docstrings**: Google style required (ruff `D` + `convention = "google"`)
- **Coverage**: minimum 80% enforced via pytest `--cov-fail-under=80`
- **Active ruff rules**: ANN, B, C4, D, E, F, I, PIE, PT, RET, RUF, S, SIM, T20, TCH, UP, W

## Architecture

- `fastapi_cache/types.py` — `Backend` Protocol (get, get_with_ttl, set, clear) and `KeyBuilder` Protocol
- `fastapi_cache/coder.py` — `JsonCoder` (orjson-based) and `PickleCoder`
- `fastapi_cache/decorator.py` — `@cache` decorator with FastAPI dependency injection
- `fastapi_cache/backends/` — one file per backend

## Adding a New Backend

1. Create `fastapi_cache/backends/mybackend.py`
2. Implement all methods from `Backend` protocol in `types.py`
3. Add optional dependency to `pyproject.toml` under `[project.optional-dependencies]`
4. Add import with try/except in `fastapi_cache/backends/__init__.py`
5. Add mock-based tests in `tests/test_backends.py`

## Testing

```bash
uv run pytest tests/ -v
```

Async tests require `@pytest.mark.asyncio`. Mock external services (Redis, Memcached, DynamoDB) — do not require live connections.
