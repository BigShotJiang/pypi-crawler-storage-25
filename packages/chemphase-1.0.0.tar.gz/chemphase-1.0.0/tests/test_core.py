"""chemphase """
import pytest
def test_import():
    """"""
    import chemphase
    assert chemphase.__version__ == "1.0.0"
def test_import_core():
    """（ C ）"""
    from chemphase.core import (
        PhaseDiagramConfig, validate_elements, print_banner,
        DEFAULT_ELEMENTS, EAH_THRESHOLD,
    )
    assert DEFAULT_ELEMENTS == ["Cu", "Ag", "O", "Se"]
    assert EAH_THRESHOLD == 0.05
def test_import_cli():
    """ CLI """
    from chemphase.cli import main
    assert callable(main)
def test_import_diagrams():
    """"""
    from chemphase.diagrams import (
        generate_binary_composition_diagram,
        generate_ternary_composition_diagram,
        _safe_delaunay_hull,
    )
    assert callable(generate_binary_composition_diagram)
    assert callable(generate_ternary_composition_diagram)
    assert callable(_safe_delaunay_hull)
def test_import_plotting_lazy():
    """（ matplotlib/scipy ）"""
    from chemphase.plotting import (
        coord_to_cartesian, allocate_colors,
        find_best_label_position, calculate_label_positions,
    )
    assert callable(coord_to_cartesian)
    assert callable(allocate_colors)
    import chemphase.plotting as pmod
    assert 'matplotlib' not in dir(pmod)
def test_validate_elements():
    """"""
    from chemphase.core import validate_elements
    ok, valid, errors = validate_elements(["Cu", "Ag", "O", "Se"])
    assert ok is True
    assert valid == ["Cu", "Ag", "O", "Se"]
    assert errors == []
    ok, valid, errors = validate_elements(["Xx", "Cu", "Yy"])
    assert ok is False
    assert "Cu" in valid
    assert len(errors) == 2
def test_coord_to_cartesian():
    """"""
    from chemphase.plotting import coord_to_cartesian
    import numpy as np
    x, y = coord_to_cartesian({"A": 1, "B": 0, "C": 0}, ("A", "B", "C"))
    assert abs(x - 0.0) < 0.01
    assert abs(y - 0.0) < 0.01
    x, y = coord_to_cartesian({"A": 0, "B": 1, "C": 0}, ("A", "B", "C"))
    assert abs(x - 1.0) < 0.01
    assert abs(y - 0.0) < 0.01
    x, y = coord_to_cartesian({"A": 0, "B": 0, "C": 1}, ("A", "B", "C"))
    assert abs(x - 0.5) < 0.01
    assert abs(y - np.sqrt(3) / 2) < 0.01
def test_config():
    """"""
    from chemphase.core import PhaseDiagramConfig
    config = PhaseDiagramConfig(eah_threshold=0.1, output_root="test_output")
    assert config.eah_threshold == 0.1
    assert config.output_root == "test_output"
    assert config.api_key == ""
    assert config.local_dir is None
    assert config.compare_structure is False
def test_safe_delaunay_hull():
    """ Delaunay """
    from chemphase.diagrams import _safe_delaunay_hull
    import numpy as np
    points = np.array([[0, 0], [1, 0], [0.5, 0.8], [0.2, 0.3], [0.7, 0.1]])
    result = _safe_delaunay_hull(points)
    assert result is not None
    assert len(result) >= 1
    result = _safe_delaunay_hull(np.array([[0, 0], [1, 0]]))
    assert result is None
    result = _safe_delaunay_hull(np.array([[0, 0], [0.5, 0], [1, 0]]))
    assert result is None
    result = _safe_delaunay_hull(np.array([[0, 0], [0, 0], [1, 0], [0.5, 0.5]]))
    assert result is not None
def test_binary_diagram_generation():
    """（）"""
    from chemphase.diagrams import generate_binary_composition_diagram
    from pymatgen.core import Composition
    from pymatgen.analysis.phase_diagram import PDEntry
    from pathlib import Path
    import tempfile
    entries = [
        PDEntry(Composition('Cu'), -3.7, 'Cu'),
        PDEntry(Composition('Ag'), -2.8, 'Ag'),
        PDEntry(Composition('CuAg'), -6.8, 'CuAg'),
        PDEntry(Composition('Cu3Ag'), -14.2, 'Cu3Ag'),
        PDEntry(Composition('CuAg3'), -11.5, 'CuAg3'),
    ]
    with tempfile.TemporaryDirectory() as tmpdir:
        result = generate_binary_composition_diagram(
            entries, ('Cu', 'Ag'), Path(tmpdir), 'Test')
        assert result is True
        output_file = Path(tmpdir) / 'binary_Cu-Ag_phase.png'
        assert output_file.exists()
        assert output_file.stat().st_size > 1000
def test_ternary_diagram_generation():
    """（）"""
    from chemphase.diagrams import generate_ternary_composition_diagram
    from pymatgen.core import Composition
    from pymatgen.analysis.phase_diagram import PDEntry
    from pathlib import Path
    import tempfile
    entries = [
        PDEntry(Composition('Cu'), -3.7, 'Cu'),
        PDEntry(Composition('Ag'), -2.8, 'Ag'),
        PDEntry(Composition('O2'), -4.9, 'O2'),
        PDEntry(Composition('CuO'), -9.0, 'CuO'),
        PDEntry(Composition('Ag2O'), -10.5, 'Ag2O'),
        PDEntry(Composition('CuAgO2'), -17.0, 'CuAgO2'),
    ]
    with tempfile.TemporaryDirectory() as tmpdir:
        result = generate_ternary_composition_diagram(
            entries, ('Cu', 'Ag', 'O'), Path(tmpdir), 'Test')
        assert result is True
        png = Path(tmpdir) / 'ternary_Cu-Ag-O_phase.png'
        html = Path(tmpdir) / 'ternary_Cu-Ag-O_phase.html'
        assert png.exists() or html.exists()
def test_label_position():
    """"""
    from chemphase.plotting import find_best_label_position, calculate_label_positions
    pos, lx, ly = find_best_label_position(0.5, 0.5, [], 0.12)
    assert pos in ['top left', 'top right', 'bottom left', 'bottom right',
                   'middle left', 'middle right', 'top center', 'bottom center']
    phases = [
        {'x': 0.2, 'y': 0.2, 'formula': 'A', 'e_per_atom': -1.0, 'comp_dict': {'A': 1}},
        {'x': 0.5, 'y': 0.5, 'formula': 'B', 'e_per_atom': -2.0, 'comp_dict': {'B': 1}},
        {'x': 0.8, 'y': 0.3, 'formula': 'C', 'e_per_atom': -1.5, 'comp_dict': {'C': 1}},
    ]
    result = calculate_label_positions(phases, 0.12)
    assert len(result) == 3
    for p in result:
        assert 'label_x' in p
        assert 'label_y' in p
        assert 0 <= p['label_x'] <= 1.5
        assert -0.5 <= p['label_y'] <= 1.5
def test_allocate_colors():
    """"""
    from chemphase.plotting import allocate_colors
    phases = [{'formula': f'Phase{i}'} for i in range(5)]
    result = allocate_colors(phases)
    assert len(result) == 5
    for p in result:
        assert 'color' in p
        assert p['color'].startswith('#')
