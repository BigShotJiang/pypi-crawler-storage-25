"""chemphase 
 python -m chemphase 
"""
from chemphase.cli import main
if __name__ == "__main__":
    main()
