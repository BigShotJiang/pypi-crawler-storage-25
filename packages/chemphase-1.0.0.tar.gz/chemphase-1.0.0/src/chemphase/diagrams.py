"""：/ +  + """
import sys
import warnings
import numpy as np
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from chemphase.plotting import (
    coord_to_cartesian, allocate_colors, calculate_label_positions,
)
def _safe_delaunay_hull(points: np.ndarray):
    """ Delaunay ， Python 
    scipy.spatial.Delaunay  Qhull C ， Python 3.13+
     C ABI （ try/except ）。
    ， Delaunay，。
    ----------
    points : np.ndarray, shape (N, 2)
        
    simplices : np.ndarray or None
        ， None
    """
    if points.shape[0] < 3:
        return None
    unique_points = np.unique(points, axis=0)
    if len(unique_points) < 3:
        return None
    if len(unique_points) == 3:
        v1 = unique_points[1] - unique_points[0]
        v2 = unique_points[2] - unique_points[0]
        cross = v1[0] * v2[1] - v1[1] * v2[0]
        if abs(cross) < 1e-12:
            return None
        return np.array([[0, 1, 2]])
    try:
        from scipy.spatial import Delaunay
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            tri = Delaunay(unique_points, qhull_options='QJ')
        return tri.simplices
    except Exception:
        pass
    try:
        from scipy.spatial import ConvexHull
        hull = ConvexHull(unique_points)
        n = len(hull.vertices)
        if n < 3:
            return None
        simplices = []
        for i in range(1, n - 1):
            simplices.append([hull.vertices[0], hull.vertices[i], hull.vertices[i + 1]])
        return np.array(simplices)
    except Exception:
        return None
MARKER_SIZE = 25
MARKER_LINE_WIDTH = 2
TITLE_FONT_SIZE = 20
LABEL_BACKGROUND = 'rgba(255,255,255,0.9)'
BINARY_FIG_WIDTH = 12
BINARY_FIG_HEIGHT = 10
BINARY_LABEL_FONT_SIZE = 14
BINARY_XLABEL_FONT_SIZE = 14
BINARY_YLABEL_FONT_SIZE = 14
BINARY_HULL_LINE_COLOR = "gray"
BINARY_HULL_LINE_WIDTH = 1.5
BINARY_DPI = 150
TERNARY_FIG_WIDTH = 1000
TERNARY_FIG_HEIGHT = 900
TERNARY_LABEL_FONT_SIZE = 14
TERNARY_TITLE_FONT_SIZE = 20
TERNARY_HULL_LINE_COLOR = "gray"
TERNARY_HULL_LINE_WIDTH = 1.5
TERNARY_SHOW_HULL = True
TERNARY_LABEL_MARGIN = 0.12
def _lazy_matplotlib():
    """ matplotlib， C """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    return plt
def generate_binary_composition_diagram(entries, elements: Tuple[str, str],
                                       output_dir: Path, title_suffix: str = "") -> bool:
    """（ΔE vs ， Hull ）
    ----------
    entries : list of pymatgen PDEntry
        
    elements : tuple of (str, str)
        
    output_dir : Path
        
    title_suffix : str
        （ASCII only， CJK ）
    bool : 
    """
    from pymatgen.analysis.phase_diagram import PhaseDiagram
    try:
        pd = PhaseDiagram(entries)
        phases = []
        base_energy = None
        for entry in pd.stable_entries:
            comp_dict = entry.composition.as_dict()
            formula = entry.composition.reduced_formula
            total = sum(comp_dict.values())
            x = comp_dict.get(elements[0], 0) / total if total > 0 else 0.5
            e_per_atom = pd.get_hull_energy(entry.composition) / entry.composition.num_atoms
            if base_energy is None or e_per_atom < base_energy:
                base_energy = e_per_atom
            phases.append({
                'formula': formula, 'x': x, 'e_per_atom': e_per_atom,
                'comp_dict': comp_dict
            })
        for phase in phases:
            phase['delta_e'] = phase['e_per_atom'] - base_energy
        phases = allocate_colors(phases)
        plt = _lazy_matplotlib()
        fig, ax = plt.subplots(figsize=(BINARY_FIG_WIDTH, BINARY_FIG_HEIGHT))
        ax.set_xlim(-0.05, 1.05)
        y_max = max(p['delta_e'] for p in phases) if phases else 0.5
        y_min = min(min(p['delta_e'] for p in phases), -0.05) if phases else -0.1
        ax.set_ylim(y_min - 0.15, y_max + 0.5)
        ax.set_xlabel(f'Composition (x in {elements[0]}$_{{1-x}}${elements[1]}$_x$)',
                     fontsize=BINARY_XLABEL_FONT_SIZE)
        ax.set_ylabel('Delta E (eV/atom)', fontsize=BINARY_YLABEL_FONT_SIZE)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        if len(phases) >= 3:
            points = np.array([[p['x'], p['delta_e']] for p in phases])
            simplices = _safe_delaunay_hull(points)
            if simplices is not None:
                for simplex in simplices:
                    for i in range(3):
                        ax.plot(
                            [points[simplex[i], 0], points[simplex[(i + 1) % 3], 0]],
                            [points[simplex[i], 1], points[simplex[(i + 1) % 3], 1]],
                            '-', color=BINARY_HULL_LINE_COLOR, linewidth=BINARY_HULL_LINE_WIDTH,
                        )
        occupied = []
        sorted_phases = sorted(phases, key=lambda p: p['delta_e'])
        for phase in sorted_phases:
            best_y_offset = 0.05
            for y_offset_test in np.arange(0.02, 0.25, 0.02):
                overlaps = any(abs(ey - (phase['delta_e'] + y_offset_test)) < 0.05
                              for (_ex, ey, _ef) in occupied)
                if not overlaps:
                    best_y_offset = y_offset_test
                    break
            phase['label_y_offset'] = best_y_offset
            occupied.append((phase['x'], phase['delta_e'] + best_y_offset, phase['formula']))
        for phase in phases:
            ax.plot(phase['x'], phase['delta_e'], 'o', markersize=MARKER_SIZE / 3,
                   color=phase['color'])
            ax.annotate(phase['formula'],
                        (phase['x'], phase['delta_e'] + phase['label_y_offset']),
                        xytext=(0, 5), textcoords='offset points',
                        fontsize=BINARY_LABEL_FONT_SIZE,
                        color=phase['color'], fontweight='bold', ha='center',
                        bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                                 alpha=0.8, edgecolor=phase['color']))
        system_str = f"{elements[0]}-{elements[1]}"
        if title_suffix:
            ax.set_title(f'{system_str} [{title_suffix}]', fontsize=TITLE_FONT_SIZE, fontweight='bold')
        else:
            ax.set_title(system_str, fontsize=TITLE_FONT_SIZE, fontweight='bold')
        plt.tight_layout()
        filename = f"binary_{elements[0]}-{elements[1]}_phase.png"
        filepath = output_dir / filename
        plt.savefig(str(filepath), dpi=BINARY_DPI, bbox_inches='tight')
        plt.close('all')
        print(f"    + {filename}")
        return True
    except Exception as e:
        import traceback
        print(f"    - {elements[0]}-{elements[1]}: {e}")
        if '--debug' in sys.argv:
            traceback.print_exc()
        return False
def draw_triangle_boundary(fig, elems: Tuple[str, str, str]):
    """"""
    import plotly.graph_objects as go
    triangle_x = [0, 1, 0.5, 0]
    triangle_y = [0, 0, np.sqrt(3) / 2, 0]
    fig.add_trace(go.Scatter(
        x=triangle_x, y=triangle_y, mode='lines',
        line=dict(color='black', width=4), name='boundary', hoverinfo='skip'
    ))
    fig.add_trace(go.Scatter(
        x=[0, 1, 0.5], y=[-0.12, -0.12, np.sqrt(3) / 2 + 0.14],
        mode='text', text=[f"<b>{elems[0]}</b>", f"<b>{elems[1]}</b>", f"<b>{elems[2]}</b>"],
        textfont=dict(size=24, color='black'), name='elem-labels', hoverinfo='skip'
    ))
def draw_hull_lines(fig, phases: List[dict]):
    """ Hull （ Delaunay ）"""
    import plotly.graph_objects as go
    if not TERNARY_SHOW_HULL:
        return
    points = np.array([[p['x'], p['y']] for p in phases])
    if len(points) < 3:
        return
    simplices = _safe_delaunay_hull(points)
    if simplices is None:
        return
    hull_x, hull_y = [], []
    for simplex in simplices:
        for i in range(3):
            hull_x.extend([points[simplex[i], 0], points[simplex[(i + 1) % 3], 0], np.nan])
            hull_y.extend([points[simplex[i], 1], points[simplex[(i + 1) % 3], 1], np.nan])
    fig.add_trace(go.Scatter(
        x=hull_x, y=hull_y, mode='lines',
        line=dict(color=TERNARY_HULL_LINE_COLOR, width=TERNARY_HULL_LINE_WIDTH),
        name='Hull', hoverinfo='skip'
    ))
def draw_phases(fig, phases: List[dict]):
    """"""
    import plotly.graph_objects as go
    for phase in phases:
        fig.add_trace(go.Scatter(
            x=[phase['x']], y=[phase['y']], mode='markers',
            marker=dict(size=MARKER_SIZE, color=phase['color'],
                       line=dict(color='white', width=MARKER_LINE_WIDTH)),
            name=phase['formula'],
            hovertemplate=f"<b>{phase['formula']}</b><br>E = {phase['e_per_atom']:.4f} eV/atom",
            showlegend=False
        ))
        fig.add_annotation(
            x=phase['label_x'], y=phase['label_y'],
            text=f"<b>{phase['formula']}</b>", showarrow=False,
            font=dict(size=TERNARY_LABEL_FONT_SIZE, color=phase['color']),
            bgcolor=LABEL_BACKGROUND, bordercolor=phase['color'],
            borderwidth=1, borderpad=3, xref='x', yref='y'
        )
def generate_ternary_composition_diagram(entries, elements: Tuple[str, str, str],
                                        output_dir: Path, title_suffix: str = "") -> bool:
    """（Gibbs ， Hull ）
    ----------
    entries : list of pymatgen PDEntry
        
    elements : tuple of (str, str, str)
        
    output_dir : Path
        
    title_suffix : str
        （ASCII only）
    bool : 
    """
    from pymatgen.analysis.phase_diagram import PhaseDiagram
    import plotly.graph_objects as go
    try:
        pd = PhaseDiagram(entries)
        phases = []
        for entry in pd.stable_entries:
            comp_dict = entry.composition.as_dict()
            formula = entry.composition.reduced_formula
            x, y = coord_to_cartesian(comp_dict, elements)
            e_per_atom = pd.get_hull_energy(entry.composition) / entry.composition.num_atoms
            phases.append({
                'formula': formula, 'x': x, 'y': y, 'e_per_atom': e_per_atom,
                'comp_dict': comp_dict
            })
        phases = allocate_colors(phases)
        phases = calculate_label_positions(phases, TERNARY_LABEL_MARGIN)
        fig = go.Figure()
        draw_triangle_boundary(fig, elements)
        draw_hull_lines(fig, phases)
        draw_phases(fig, phases)
        system_str = "-".join(elements)
        title_text = f"<b>{system_str}</b><br><sup>{len(phases)} phases</sup>"
        if title_suffix:
            title_text = f"<b>{system_str} [{title_suffix}]</b><br><sup>{len(phases)} phases</sup>"
        fig.update_layout(
            title=dict(text=title_text,
                      font=dict(size=TERNARY_TITLE_FONT_SIZE), x=0.5, xanchor='center'),
            xaxis=dict(range=[-0.2, 1.2], showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(range=[-0.25, 1.1], showgrid=False, zeroline=False, showticklabels=False,
                       scaleanchor='x', scaleratio=1),
            plot_bgcolor='white', width=TERNARY_FIG_WIDTH, height=TERNARY_FIG_HEIGHT
        )
        filename = f"ternary_{elements[0]}-{elements[1]}-{elements[2]}_phase.png"
        filepath = output_dir / filename
        try:
            fig.write_image(str(filepath), scale=2)
        except Exception:
            fig.write_html(str(filepath).replace('.png', '.html'))
        print(f"    + {filename}")
        return True
    except Exception as e:
        import traceback
        print(f"    - {elements[0]}-{elements[1]}-{elements[2]}: {e}")
        if '--debug' in sys.argv:
            traceback.print_exc()
        return False
def _get_plt():
    """ matplotlib pyplot """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    return plt
def generate_chempot_phase_diagram(entries, elements: Tuple[str, ...],
                                    output_dir: Path) -> bool:
    """（pymatgen ChemicalPotentialDiagram）
    ///，
    ----------
    entries : list of pymatgen ComputedEntry
        
    elements : tuple of str
        
    output_dir : Path
        
    bool : 
    """
    from pymatgen.analysis.chempot_diagram import ChemicalPotentialDiagram
    n = len(elements)
    if n < 2:
        return False
    try:
        cpd = ChemicalPotentialDiagram(entries)
        plot = cpd.get_plot()
        if plot is None:
            return False
        if n == 2:
            prefix = "binary"
            filename = f"chempot_{elements[0]}-{elements[1]}.png"
        elif n == 3:
            prefix = "ternary"
            filename = f"chempot_{elements[0]}-{elements[1]}-{elements[2]}.png"
        elif n == 4:
            prefix = "quaternary"
            filename = f"chempot_{elements[0]}-{elements[1]}-{elements[2]}-{elements[3]}.png"
        else:
            prefix = "quinary"
            filename = f"chempot_5element_{'-'.join(elements)}.png"
        subdir = output_dir / prefix
        subdir.mkdir(parents=True, exist_ok=True)
        filepath = subdir / filename
        try:
            plot.write_image(str(filepath), scale=2)
            print(f"    + {filename}")
            return True
        except (AttributeError, TypeError, ValueError, ImportError):
            pass
        try:
            plt = _get_plt()
            plot.savefig(str(filepath), dpi=200, bbox_inches='tight')
            plt.close('all')
            print(f"    + {filename}")
            return True
        except (AttributeError, TypeError):
            pass
        try:
            html_path = filepath.with_suffix('.html')
            plot.write_html(str(html_path))
            print(f"    + {filename.replace('.png', '.html')} (HTML — pip install chemphase[export] for PNG)")
            return True
        except Exception as e:
            print(f"    - {'-'.join(elements)}: {e}")
            return False
    except Exception as e:
        import traceback
        print(f"    - chempot {'-'.join(elements)}: {e}")
        if '--debug' in sys.argv:
            traceback.print_exc()
        return False
def _check_doped_available() -> bool:
    """ doped """
    try:
        from doped.chemical_potentials import CompetingPhases, CompetingPhasesAnalyzer
        return True
    except ImportError:
        return False
def find_viable_hosts(
    api_key: str, elements: List[str],
    eah_threshold: float = 0.05, min_limits: int = 5
) -> List[Dict]:
    """
     Materials Project ，
    。
    ----------
    api_key : str
        Materials Project API key
    elements : list of str
        
    eah_threshold : float
         above hull （eV/atom）
    min_limits : int
        （ 5）
    list of dict : ， formula, elements, is_stable, num_limits
    """
    if not _check_doped_available():
        print("  !  doped : pip install chemphase[heatmap]")
        return []
    from doped.chemical_potentials import CompetingPhases, CompetingPhasesAnalyzer
    from pymatgen.ext.matproj import MPRester
    mpr = MPRester(api_key=api_key)
    all_formulas = set()
    try:
        entries = mpr.get_entries_in_chemsys(elements)
        for e in entries:
            all_formulas.add(e.composition.reduced_formula)
    except Exception as e:
        print(f"  ! : {e}")
        return []
    viable = []
    for formula in sorted(all_formulas):
        try:
            cp = CompetingPhases(
                formula,
                energy_above_hull=eah_threshold,
                api_key=api_key
            )
            cpa = CompetingPhasesAnalyzer(composition=formula, entries=cp.entries)
            num_limits = len(cpa.chempots_df)
            if num_limits >= min_limits:
                elems = list(cpa.chempots_df.columns)
                viable.append({
                    'formula': formula,
                    'elements': elems,
                    'is_stable': True,
                    'num_limits': num_limits,
                    'cpa': cpa
                })
        except Exception:
            continue
    return viable
def generate_fixed_chempot_heatmap(
    host_formula: str, api_key: str,
    elements: List[str],
    eah_threshold: float = 0.05,
    output_dir: Optional[Path] = None
) -> int:
    """
     doped  CompetingPhasesAnalyzer 
    ，。
    ----------
    host_formula : str
         reduced formula（ 'Li3PS4'）
    api_key : str
        Materials Project API key
    elements : list of str
        
    eah_threshold : float
         above hull 
    output_dir : Path or None
        
    int : 
    """
    if not _check_doped_available():
        print("  !  doped : pip install chemphase[heatmap]")
        return 0
    from doped.chemical_potentials import CompetingPhases, CompetingPhasesAnalyzer
    plt = _get_plt()
    if output_dir is None:
        output_dir = Path("phase_diagrams_output") / "heatmaps" / "fixed"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    success_count = 0
    try:
        cp = CompetingPhases(
            host_formula,
            energy_above_hull=eah_threshold,
            api_key=api_key
        )
        cpa = CompetingPhasesAnalyzer(composition=host_formula, entries=cp.entries)
        for dep_elem in elements:
            try:
                fig = cpa.plot_chempot_heatmap(
                    dependent_element=dep_elem,
                    bordering_phases=True,
                    label_positions=True
                )
                filename = f"chempot_{host_formula}_dep_{dep_elem}.png"
                filepath = output_dir / filename
                fig.savefig(str(filepath), dpi=200, bbox_inches='tight')
                plt.close(fig)
                print(f"      + {filename}")
                success_count += 1
            except Exception as e:
                print(f"      - {dep_elem}: {e}")
    except Exception as e:
        print(f"    - {host_formula}: {e}")
    return success_count
