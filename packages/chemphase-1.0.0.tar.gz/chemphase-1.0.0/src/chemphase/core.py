"""：、VASP 、Materials Project API、"""
import os
import re
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from itertools import combinations
VALID_ELEMENTS = {
    'H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne',
    'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar', 'K', 'Ca',
    'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
    'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr', 'Rb', 'Sr', 'Y', 'Zr',
    'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn',
    'Sb', 'Te', 'I', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd',
    'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb',
    'Lu', 'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg',
    'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn', 'Fr', 'Ra', 'Ac', 'Th',
    'Pa', 'U', 'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm',
    'Md', 'No', 'Lr', 'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds',
    'Rg', 'Cn', 'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og'
}
EAH_THRESHOLD = 0.05
OUTPUT_ROOT = "phase_diagrams_output"
UNIFIED_PHASES_DIR = "unified_phases"
DEFAULT_ELEMENTS = ["Cu", "Ag", "O", "Se"]
STRUCTURE_TOLERANCE = 0.2
def validate_elements(elements: List[str]) -> Tuple[bool, List[str], List[str]]:
    """"""
    errors = []
    valid = []
    for elem in elements:
        elem = elem.strip().capitalize()
        if elem in VALID_ELEMENTS:
            valid.append(elem)
        else:
            errors.append(f"'{elem}' ")
    return len(errors) == 0, valid, errors
class PhaseDiagramConfig:
    """"""
    def __init__(self, api_key: str = "", eah_threshold: float = EAH_THRESHOLD,
                 output_root: str = OUTPUT_ROOT, unified_phases_dir: str = UNIFIED_PHASES_DIR,
                 debug: bool = False, local_dir: Optional[Path] = None,
                 compare_structure: bool = False, chempot: bool = False,
                 heatmap: bool = False):
        self.api_key = api_key or os.environ.get("MATERIALS_PROJECT_API_KEY", "")
        self.eah_threshold = eah_threshold
        self.output_root = output_root
        self.unified_phases_dir = unified_phases_dir
        self.debug = debug
        self.local_dir = local_dir
        self.compare_structure = compare_structure
        self.chempot = chempot
        self.heatmap = heatmap
    @property
    def database_file(self) -> Path:
        return Path(self.unified_phases_dir) / "phases_database.json"
def _read_pmg_api_key() -> Optional[str]:
    """ pymatgen  ~/.pmgrc.yaml  API key"""
    pmgrc_path = Path.home() / ".pmgrc.yaml"
    if pmgrc_path.exists():
        try:
            import yaml
            with open(pmgrc_path) as f:
                cfg = yaml.safe_load(f)
            if cfg and isinstance(cfg, dict):
                return cfg.get("PMG_API_KEY") or cfg.get("PMG_MAPI_KEY")
        except Exception:
            pass
    return None
def ensure_api_key(config: PhaseDiagramConfig) -> str:
    """ API ，：
    1. config.api_key ( MATERIALS_PROJECT_API_KEY )
    2. PMG_MAPI_KEY / PMG_API_KEY 
    3. ~/.pmgrc.yaml (pymatgen )
    4.  ( TTY )
    5.  pymatgen 
    """
    import sys as _sys
    if config.api_key:
        return config.api_key
    for env_var in ("PMG_MAPI_KEY", "PMG_API_KEY", "MP_API_KEY"):
        key = os.environ.get(env_var, "")
        if key:
            config.api_key = key
            if config.debug:
                print(f"  [DEBUG]  {env_var}  API key")
            print("  ✓  Materials Project API ")
            return config.api_key
    pmg_key = _read_pmg_api_key()
    if pmg_key:
        config.api_key = pmg_key
        if config.debug:
            print("  [DEBUG]  ~/.pmgrc.yaml  PMG_API_KEY")
        print("  ✓  pymatgen  Materials Project API ")
        return config.api_key
    if _sys.stdin.isatty():
        print("\n" + "=" * 60)
        print("   Materials Project API ")
        print("=" * 60)
        print("  : https://materialsproject.org/api")
        print("  : export MATERIALS_PROJECT_API_KEY=")
        print()
        try:
            key = input("  API: ").strip()
            if key:
                config.api_key = key
                print("  ⚠ ，")
                return config.api_key
        except EOFError:
            pass
    print("  ℹ  API ， pymatgen ")
    return ""
def parse_energy_from_vasprun(vasprun_path: str, debug: bool = False) -> Optional[float]:
    """ vasprun.xml """
    try:
        from pymatgen.io.vasp.outputs import Vasprun
        vr = Vasprun(vasprun_path)
        return vr.final_energy
    except Exception as e:
        if debug:
            print(f"    vasprun.xml: {e}")
        return None
def parse_energy_from_outcar(outcar_path: str, debug: bool = False) -> Optional[float]:
    """ OUTCAR """
    try:
        with open(outcar_path, 'r') as f:
            content = f.read()
        matches = re.findall(r'energy\(sigma->0\)\s*=\s*([-\d.]+)', content)
        if matches:
            return float(matches[-1])
    except Exception as e:
        if debug:
            print(f"    OUTCAR: {e}")
    return None
def parse_structure_info(poscar_path: str, debug: bool = False) -> Tuple[Optional[str], Optional[int]]:
    """ POSCAR """
    try:
        from pymatgen.core import Structure
        structure = Structure.from_file(poscar_path)
        return structure.composition.reduced_formula, structure.num_atoms
    except Exception as e:
        if debug:
            print(f"    POSCAR: {e}")
        return None, None
def parse_phase_directory(phase_dir: Path, eah_threshold: float = EAH_THRESHOLD) -> Optional[Dict]:
    """ VASP """
    dir_name = phase_dir.name
    name_match = re.match(r'(.+?)_EaH_([\d.]+)(_stable)?', dir_name)
    if not name_match:
        return None
    formula_from_name = name_match.group(1)
    eah = float(name_match.group(2))
    is_stable = name_match.group(3) == '_stable' or eah < eah_threshold
    poscar = phase_dir / "POSCAR"
    vasprun = phase_dir / "vasprun.xml"
    outcar = phase_dir / "OUTCAR"
    if not poscar.exists():
        return None
    formula, num_atoms = parse_structure_info(str(poscar))
    if not formula:
        formula = formula_from_name
    energy = None
    if vasprun.exists():
        energy = parse_energy_from_vasprun(str(vasprun))
    elif outcar.exists():
        energy = parse_energy_from_outcar(str(outcar))
    if energy is None:
        return None
    energy_per_atom = energy / num_atoms if num_atoms else None
    from pymatgen.core import Composition
    elements = list(set(Composition(formula).as_dict().keys()))
    return {
        'name': dir_name,
        'formula': formula,
        'energy': energy,
        'energy_per_atom': energy_per_atom,
        'num_atoms': num_atoms,
        'eah': eah,
        'is_stable': is_stable,
        'elements': elements,
        'path': str(phase_dir)
    }
def scan_local_phases(local_dir: Path, target_elements: Optional[List[str]] = None,
                      eah_threshold: float = EAH_THRESHOLD) -> List[Dict]:
    """ VASP """
    if not local_dir.exists():
        print(f": {local_dir}")
        return []
    phases = []
    target_set = set(target_elements) if target_elements else None
    for phase_dir in local_dir.iterdir():
        if not phase_dir.is_dir():
            continue
        phase_data = parse_phase_directory(phase_dir, eah_threshold)
        if phase_data is None:
            continue
        if target_set:
            phase_elements = set(phase_data['elements'])
            if not phase_elements <= target_set:
                continue
        phases.append(phase_data)
    return phases
def build_local_entries(phases: List[Dict]) -> List:
    """ pymatgen PDEntry """
    from pymatgen.core import Structure
    from pymatgen.analysis.phase_diagram import PDEntry
    entries = []
    for phase in phases:
        try:
            structure = Structure.from_file(phase['path'] + "/POSCAR")
            entry = PDEntry(
                composition=structure.composition,
                energy=phase['energy'],
                name=phase['name']
            )
            entries.append(entry)
        except Exception as e:
            print(f"    Entry {phase['name']}: {e}")
    return entries
def compare_structures(local_structure, mp_structure,
                       tolerance: float = STRUCTURE_TOLERANCE) -> Dict:
    """"""
    from pymatgen.analysis.structure_matcher import StructureMatcher
    matcher = StructureMatcher(ltol=tolerance, stol=tolerance, angle_tol=10)
    try:
        is_same = matcher.fit(local_structure, mp_structure)
        return {
            'is_same': is_same,
            'local_formula': local_structure.composition.reduced_formula,
            'mp_formula': mp_structure.composition.reduced_formula,
            'local_sites': len(local_structure.sites),
            'mp_sites': len(mp_structure.sites),
            'local_volume': local_structure.volume,
            'mp_volume': mp_structure.volume,
            'volume_diff_percent': abs(local_structure.volume - mp_structure.volume) / mp_structure.volume * 100
        }
    except Exception as e:
        return {
            'is_same': False,
            'error': str(e),
            'local_formula': local_structure.composition.reduced_formula,
            'mp_formula': mp_structure.composition.reduced_formula
        }
def structure_comparison_report(local_phases: List[Dict], config: PhaseDiagramConfig) -> Dict:
    """"""
    from pymatgen.ext.matproj import MPRester
    from pymatgen.core import Structure
    report = {
        'total_compared': 0,
        'matching': 0,
        'different': 0,
        'not_found_in_mp': 0,
        'details': []
    }
    if not config.api_key:
        print("  ! API，")
        return report
    try:
        mpr = MPRester(api_key=config.api_key)
    except Exception as e:
        print(f"  ! Materials Project: {e}")
        return report
    for phase in local_phases:
        formula = phase['formula']
        report['total_compared'] += 1
        try:
            mp_entries = mpr.get_entries(formula, inc_structure=True)
            if not mp_entries:
                report['not_found_in_mp'] += 1
                report['details'].append({
                    'formula': formula,
                    'status': 'not_found_in_mp',
                    'message': f'MP {formula}'
                })
                continue
            local_structure = Structure.from_file(phase['path'] + "/POSCAR")
            mp_entry = mp_entries[0]
            mp_structure = mp_entry.structure
            comparison = compare_structures(local_structure, mp_structure)
            comparison['formula'] = formula
            comparison['local_path'] = phase['path']
            if comparison['is_same']:
                report['matching'] += 1
                comparison['status'] = 'matching'
            else:
                report['different'] += 1
                comparison['status'] = 'different'
            report['details'].append(comparison)
        except Exception as e:
            report['not_found_in_mp'] += 1
            report['details'].append({
                'formula': formula,
                'status': 'error',
                'message': str(e)
            })
    return report
def get_all_element_combinations(elements: List[str], min_size: int = 2) -> List:
    """（ min_size ）"""
    result = []
    for r in range(min_size, len(elements) + 1):
        for combo in combinations(elements, r):
            result.append(combo)
    return result
def load_database(config: PhaseDiagramConfig) -> Dict:
    """"""
    Path(config.unified_phases_dir).mkdir(parents=True, exist_ok=True)
    if config.database_file.exists():
        with open(config.database_file, 'r') as f:
            return json.load(f)
    return {"phases": {}, "download_history": [], "element_systems": {}}
def save_database(config: PhaseDiagramConfig, db: Dict):
    """"""
    Path(config.unified_phases_dir).mkdir(parents=True, exist_ok=True)
    with open(config.database_file, 'w') as f:
        json.dump(db, f, indent=2, sort_keys=True)
def get_entries_from_mp(config: PhaseDiagramConfig, elements: List[str]):
    """ Materials Project """
    from pymatgen.ext.matproj import MPRester
    mpr = MPRester(api_key=config.api_key)
    return mpr.get_entries_in_chemsys(elements)
def get_system_name(elements: List[str]) -> str:
    """（）"""
    return "_".join(sorted(elements))
def print_banner():
    """"""
    print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║        v5.0 (chemphase)                       ║
║    Phase Diagram & Chemical Potential Heatmap Generator                 ║
╚═══════════════════════════════════════════════════════════════════════════╝
""")
