"""：、、"""
import numpy as np
from typing import Dict, List, Tuple
COLOR_PALETTE = [
    "#FF0000", "#FF8800", "#FFDD00", "#00FF00", "#00FFCC", "#00BBFF",
    "#0066FF", "#8800FF", "#FF00AA", "#FF0044", "#AAFF00", "#00FF88",
    "#00DDFF", "#4400FF", "#DD00FF", "#4400FF", "#FF3333", "#FF9933",
    "#FFEE33", "#33FF33", "#33FFCC", "#33CCFF", "#3388FF", "#9933FF",
    "#FF33AA", "#FF3388", "#99FF33", "#33FF99", "#33EEFF", "#5533FF",
    "#EE33FF", "#FF5533", "#FF6666", "#FFAA66", "#FFFF66", "#66FF66",
    "#66FFCC", "#66DDFF", "#66AAFF", "#AA66FF", "#FF66CC", "#AAFF66",
    "#66FFAA", "#66EEFF", "#6644FF", "#FF66FF", "#FF6644", "#FFAAAA",
    "#FFCCAA", "#FFFFAA", "#AAFFAA", "#AAFFCC", "#AAEEFF", "#AACCFF",
    "#CCAAFF", "#FFAAEE", "#CCFFAA", "#CC0000", "#CC6600", "#CCCC00",
    "#00CC00", "#00CCCC", "#0099CC", "#0033CC", "#6600CC", "#CC0099",
    "#CC0033", "#99CC00", "#00CC66",
]
def coord_to_cartesian(comp_dict: Dict, elems: Tuple[str, str, str]) -> Tuple[float, float]:
    """（）"""
    total = sum(comp_dict.values())
    if total == 0:
        return 0.5, 0.5
    fracs = {e: comp_dict.get(e, 0) / total for e in elems}
    x = fracs.get(elems[1], 0) + 0.5 * fracs.get(elems[2], 0)
    y = (np.sqrt(3) / 2) * fracs.get(elems[2], 0)
    return x, y
def find_best_label_position(px: float, py: float, occupied: List[Tuple[float, float, str]],
                              margin: float = 0.12) -> Tuple[str, float, float]:
    """（）"""
    positions = [
        ('top left', -0.12, 0.10), ('top right', 0.12, 0.10),
        ('bottom left', -0.12, -0.08), ('bottom right', 0.12, -0.08),
        ('middle left', -0.15, 0), ('middle right', 0.15, 0),
        ('top center', 0, 0.12), ('bottom center', 0, -0.10),
    ]
    best_pos, best_x, best_y = 'top left', px - 0.12, py + 0.10
    best_dist = -1
    for pos_name, ox, oy in positions:
        test_x, test_y = px + ox, py + oy
        if test_y < -0.05 or test_y > 0.95:
            continue
        if test_x < -0.05 or test_x > 1.05:
            continue
        min_dist = min(((test_x - pox) ** 2 + (test_y - poy) ** 2) ** 0.5
                       for (pox, poy, _) in occupied) if occupied else 999
        if min_dist > best_dist:
            best_dist = min_dist
            best_pos, best_x, best_y = pos_name, test_x, test_y
    return best_pos, best_x, best_y
def calculate_label_positions(phases: List[Dict], margin: float = 0.12) -> List[Dict]:
    """"""
    occupied = []
    sorted_phases = sorted(phases, key=lambda p: p['y'])
    for phase in sorted_phases:
        pos, lx, ly = find_best_label_position(phase['x'], phase['y'], occupied, margin)
        phase['label_pos'] = pos
        phase['label_x'] = lx
        phase['label_y'] = ly
        occupied.append((lx, ly, phase['formula']))
    return phases
def allocate_colors(phases: List[Dict]) -> List[Dict]:
    """（）"""
    for i, phase in enumerate(phases):
        phase['color'] = COLOR_PALETTE[i % len(COLOR_PALETTE)]
    return phases
