""" (CLI)
 `chemphase`  `python -m chemphase` 
"""
import sys
import argparse
from pathlib import Path
from itertools import combinations
from chemphase.core import (
    PhaseDiagramConfig, validate_elements, ensure_api_key,
    scan_local_phases, build_local_entries, structure_comparison_report,
    get_entries_from_mp, get_system_name, get_all_element_combinations,
    print_banner, DEFAULT_ELEMENTS,
)
from chemphase.diagrams import (
    generate_binary_composition_diagram,
    generate_ternary_composition_diagram,
    generate_chempot_phase_diagram,
    generate_fixed_chempot_heatmap,
    find_viable_hosts,
)
def run_local_mode(config: PhaseDiagramConfig, elements, output_root: str):
    """： VASP """
    print(f"\n: {config.local_dir}")
    local_phases = scan_local_phases(config.local_dir, elements, config.eah_threshold)
    print(f" {len(local_phases)} ")
    if not local_phases:
        print("")
        return
    if config.compare_structure:
        print("\n" + "=" * 60)
        print("  ")
        print("=" * 60)
        report = structure_comparison_report(local_phases, config)
        print(f"  : {report['total_compared']}")
        print(f"  : {report['matching']}")
        print(f"  : {report['different']}")
        print(f"  MP: {report['not_found_in_mp']}")
        import json
        report_file = Path(output_root) / "structure_comparison_report.json"
        report_file.parent.mkdir(parents=True, exist_ok=True)
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, sort_keys=True)
        print(f"  : {report_file}")
    entries = build_local_entries(local_phases)
    print(f"\n {len(entries)} PhaseDiagramEntry")
    output_dir = Path(output_root)
    output_dir.mkdir(parents=True, exist_ok=True)
    binary_combos = list(combinations(elements, 2))
    ternary_combos = list(combinations(elements, 3))
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
    binary_dir = output_dir / "binary"
    binary_dir.mkdir(parents=True, exist_ok=True)
    for e1, e2 in binary_combos:
        sub_entries = [e for e in entries if set(e.composition.as_dict().keys()) <= {e1, e2}]
        if len(sub_entries) >= 2:
            generate_binary_composition_diagram(sub_entries, (e1, e2), binary_dir, "Local VASP")
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
    ternary_dir = output_dir / "ternary"
    ternary_dir.mkdir(parents=True, exist_ok=True)
    for e1, e2, e3 in ternary_combos:
        sub_entries = [e for e in entries if set(e.composition.as_dict().keys()) <= {e1, e2, e3}]
        if len(sub_entries) >= 3:
            generate_ternary_composition_diagram(sub_entries, (e1, e2, e3), ternary_dir, "Local VASP")
    if config.chempot:
        print("\n" + "=" * 60)
        print("  ")
        print("=" * 60)
        for r in range(2, min(len(elements) + 1, 6)):
            for combo in combinations(elements, r):
                sub_entries = [e for e in entries
                               if set(e.composition.as_dict().keys()) <= set(combo)]
                min_required = r
                if len(sub_entries) >= min_required:
                    generate_chempot_phase_diagram(sub_entries, combo, output_dir)
    if config.heatmap:
        print("\n" + "=" * 60)
        print("  ")
        print("=" * 60)
        heatmap_dir = output_dir / "heatmaps" / "fixed"
        heatmap_dir.mkdir(parents=True, exist_ok=True)
        viable = find_viable_hosts(
            config.api_key, elements,
            eah_threshold=config.eah_threshold
        )
        if viable:
            print(f"  : {len(viable)} ")
            total_heatmaps = 0
            for host in viable:
                count = generate_fixed_chempot_heatmap(
                    host['formula'], config.api_key,
                    host['elements'], config.eah_threshold,
                    output_dir=heatmap_dir
                )
                total_heatmaps += count
            print(f"   {total_heatmaps} ")
        else:
            print("  （ 5 ）")
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
    print(f": {output_dir}")
def run_api_mode(config: PhaseDiagramConfig, elements, output_root: str):
    """API ： Materials Project """
    print(f"\nMaterials Project {get_system_name(elements)} ")
    output_dir = Path(output_root)
    output_dir.mkdir(parents=True, exist_ok=True)
    binary_combos = list(combinations(elements, 2))
    ternary_combos = list(combinations(elements, 3))
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
    binary_dir = output_dir / "binary"
    binary_dir.mkdir(parents=True, exist_ok=True)
    for e1, e2 in binary_combos:
        try:
            entries = get_entries_from_mp(config, [e1, e2])
            if len(entries) >= 2:
                from pymatgen.analysis.phase_diagram import PDEntry
                pd_entries = [PDEntry(composition=e.composition, energy=e.energy, name=e.name)
                             for e in entries]
                generate_binary_composition_diagram(pd_entries, (e1, e2), binary_dir, "MP data")
        except Exception as e:
            print(f"    - {e1}-{e2}: {e}")
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
    ternary_dir = output_dir / "ternary"
    ternary_dir.mkdir(parents=True, exist_ok=True)
    for e1, e2, e3 in ternary_combos:
        try:
            entries = get_entries_from_mp(config, [e1, e2, e3])
            if len(entries) >= 3:
                from pymatgen.analysis.phase_diagram import PDEntry
                pd_entries = [PDEntry(composition=e.composition, energy=e.energy, name=e.name)
                             for e in entries]
                generate_ternary_composition_diagram(pd_entries, (e1, e2, e3), ternary_dir, "MP data")
        except Exception as e:
            print(f"    - {e1}-{e2}-{e3}: {e}")
    if config.chempot:
        print("\n" + "=" * 60)
        print("  ")
        print("=" * 60)
        for r in range(2, min(len(elements) + 1, 6)):
            for combo in combinations(elements, r):
                try:
                    entries = get_entries_from_mp(config, list(combo))
                    if len(entries) >= r:
                        generate_chempot_phase_diagram(entries, combo, output_dir)
                except Exception as e:
                    print(f"    - chempot {'-'.join(combo)}: {e}")
    if config.heatmap:
        print("\n" + "=" * 60)
        print("  ")
        print("=" * 60)
        heatmap_dir = output_dir / "heatmaps" / "fixed"
        heatmap_dir.mkdir(parents=True, exist_ok=True)
        viable = find_viable_hosts(
            config.api_key, elements,
            eah_threshold=config.eah_threshold
        )
        if viable:
            print(f"  : {len(viable)} ")
            for v in sorted(viable, key=lambda x: x['formula']):
                stability = "stable" if v['is_stable'] else "unstable"
                print(f"    - {v['formula']} ({'-'.join(v['elements'])})"
                      f" [{stability}, {v['num_limits']} limits]")
            total_heatmaps = 0
            for host in viable:
                count = generate_fixed_chempot_heatmap(
                    host['formula'], config.api_key,
                    host['elements'], config.eah_threshold,
                    output_dir=heatmap_dir
                )
                total_heatmaps += count
            print(f"   {total_heatmaps} ")
        else:
            print("  （ 5 ）")
    print("\n" + "=" * 60)
    print("  API")
    print("=" * 60)
    print(f": {output_dir}")
def main():
    """"""
    parser = argparse.ArgumentParser(
        prog="chemphase",
        description=" v5.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
:
  chemphase
  chemphase --elements Li O Co
  chemphase --local /path/to/calculations --elements Cu Ag O Se
  chemphase --local /path/to/data --elements Cu Ag O Se
  chemphase --local /path/to/data --elements Cu Ag O Se --compare-structure
        """
    )
    parser.add_argument('--local', type=str, help='VASP')
    parser.add_argument('--elements', nargs='+', help='（ Cu Ag O Se）')
    parser.add_argument('--output', default='phase_diagrams_output', help=' (: phase_diagrams_output)')
    parser.add_argument('--eah', type=float, default=0.05, help='Energy above hull  (: 0.05 eV/atom)')
    parser.add_argument('--compare-structure', action='store_true', help=' vs MP')
    parser.add_argument('--chempot', action='store_true', help=' (pymatgen ChemicalPotentialDiagram)')
    parser.add_argument('--heatmap', action='store_true', help=' ( doped, pip install chemphase[heatmap])')
    parser.add_argument('--debug', action='store_true', help='')
    args = parser.parse_args()
    print_banner()
    config = PhaseDiagramConfig(
        eah_threshold=args.eah,
        output_root=args.output,
        local_dir=Path(args.local) if args.local else None,
        compare_structure=args.compare_structure,
        debug=args.debug,
        chempot=args.chempot,
        heatmap=args.heatmap,
    )
    if args.local:
        if not args.elements:
            print(":  --elements")
            sys.exit(1)
        ok, valid, errors = validate_elements(args.elements)
        if not ok:
            print(": " + ", ".join(errors))
            sys.exit(1)
        run_local_mode(config, valid, args.output)
    else:
        ensure_api_key(config)
        elements = args.elements if args.elements else DEFAULT_ELEMENTS
        ok, valid, errors = validate_elements(elements)
        if not ok:
            print(": " + ", ".join(errors))
            sys.exit(1)
        run_api_mode(config, valid, args.output)
    print("\n" + "=" * 60)
    print("  ")
    print("=" * 60)
if __name__ == "__main__":
    main()
