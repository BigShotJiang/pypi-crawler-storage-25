"""chemphase — 
 Materials Project API  VASP ：
- /（ Hull 、）
- 
- 
"""
import os
os.environ.setdefault('MPLBACKEND', 'Agg')
__version__ = "1.0.0"
def __getattr__(name):
    """："""
    if name == "PhaseDiagramConfig":
        from chemphase.core import PhaseDiagramConfig
        return PhaseDiagramConfig
    if name == "generate_binary_composition_diagram":
        from chemphase.diagrams import generate_binary_composition_diagram
        return generate_binary_composition_diagram
    if name == "generate_ternary_composition_diagram":
        from chemphase.diagrams import generate_ternary_composition_diagram
        return generate_ternary_composition_diagram
    if name == "main":
        from chemphase.cli import main
        return main
    raise AttributeError(f"module 'chemphase' has no attribute '{name}'")
__all__ = [
    "__version__",
    "PhaseDiagramConfig",
    "generate_binary_composition_diagram",
    "generate_ternary_composition_diagram",
    "main",
]
