from _typeshed import Incomplete
from enum import StrEnum

class GuardrailMode(StrEnum):
    """Guardrail mode enumeration for guardrail configuration."""
    DISABLED: str
    INPUT_ONLY: str
    OUTPUT_ONLY: str
    BOTH: str

class GuardrailConstants:
    """Constants for the GuardrailManager component."""
    CONTENT_KEY: str
    QUERY_KEY: str
    CONTEXT_KEY: str
    ANSWER_KEY: str
    ENGINE_KWARGS_KEY: str
    IS_SAFE_KEY: str
    REASON_KEY: str
    FILTERED_CONTENT_KEY: str
    DEFAULT_EMPTY_CONTENT_SAFE: bool
    DEFAULT_ERROR_CONSERVATIVE: bool

class TopicSafetyMode(StrEnum):
    """Topic safety mode enumeration for guardrail configuration."""
    ALLOWLIST: str
    DENYLIST: str
    HYBRID: str
    DISABLED: str

NEMO_BASE_CONFIG_PATH: Incomplete
