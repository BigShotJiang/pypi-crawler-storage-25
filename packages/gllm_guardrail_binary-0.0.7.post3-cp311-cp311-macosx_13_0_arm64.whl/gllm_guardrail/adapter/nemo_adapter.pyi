from _typeshed import Incomplete
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage as BaseMessage
from typing import Any

logger: Incomplete

class NeMoLMAdapter(BaseChatModel):
    '''LangChain ChatModel that delegates to a ``gllm_inference`` LM invoker.

    Configuration parameters are expected to be provided via the NeMo Guardrails
    model config under the model\'s parameters. At minimum, you should pass:

    - ``model``: e.g. "openai/gpt-4o" or "azure-openai/gpt-4o-mini".
    - ``lm_invoker``: The LM invoker to use.
    '''
    model: str | None
    temperature: float | None
    max_tokens: int | None
    top_p: float | None
    lm_invoker: BaseLMInvoker | None
    def __init__(self, **kwargs: Any) -> None:
        """Initializes a new instance of the NeMoLMAdapter class.

        Args:
            **kwargs (Any): Additional configuration for the language model.
        """
