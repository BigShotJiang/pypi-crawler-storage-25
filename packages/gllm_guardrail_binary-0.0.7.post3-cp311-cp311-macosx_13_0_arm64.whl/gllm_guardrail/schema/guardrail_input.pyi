from pydantic import BaseModel
from typing import Any

class GuardrailInput(BaseModel):
    '''Guardrail input data model.

    This model represents the input data for guardrail operations.
    Use this when you need to check both input and output in a single call,
    or when you want to be explicit about which content to check.

    Example:
        # Check user query only
        input_only = GuardrailInput(input="Tell me about AI", output=None)

        # Check LLM response only
        output_only = GuardrailInput(input=None, output="AI is artificial intelligence...")

        # Check both query and response
        both = GuardrailInput(
            input="Tell me about AI",
            output="AI is artificial intelligence..."
        )
    '''
    input: str | None
    output: str | None
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GuardrailInput:
        """Create from dictionary format for backward compatibility.

        Args:
            data (dict[str, Any]): Dictionary with input and output keys

        Returns:
            GuardrailInput instance
        """
