from pydantic import BaseModel
from typing import Any

class GuardrailResult(BaseModel):
    """Result of a guardrail content safety check.

    This model represents the standardized return value for all guardrail
    operations, providing type safety and validation for safety check results.

    Attributes:
        is_safe: Whether the content passed the safety check
        reason: Human-readable reason for rejection (if not safe) or None
        filtered_content: Cleaned/filtered version of content (if available) or None
    """
    is_safe: bool
    reason: str | None
    filtered_content: str | None
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary format for backward compatibility.

        Returns:
            Dictionary representation of the result
        """
    @classmethod
    def safe(cls, filtered_content: str | None = None) -> GuardrailResult:
        """Create a safe result.

        Args:
            filtered_content: Optional filtered content

        Returns:
            GuardrailResult indicating safe content
        """
    @classmethod
    def unsafe(cls, reason: str, filtered_content: str | None = None) -> GuardrailResult:
        """Create an unsafe result.

        Args:
            reason: Reason for rejection
            filtered_content: Optional filtered content

        Returns:
            GuardrailResult indicating unsafe content
        """
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GuardrailResult:
        """Create from dictionary format for backward compatibility.

        Args:
            data: Dictionary with is_safe, reason, and filtered_content keys

        Returns:
            GuardrailResult instance
        """
