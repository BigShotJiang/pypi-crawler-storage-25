from _typeshed import Incomplete

manager: Incomplete
logger: Incomplete

def load_yaml_config(config_file_name: str) -> dict:
    """Load configuration from YAML file.

    Args:
        config_file_name (str): The name of the configuration file to load.

    Returns:
        dict: Loaded configuration from `config_file_name` file.
    """
