from _typeshed import Incomplete
from gllm_guardrail.constants import GuardrailMode as GuardrailMode
from gllm_guardrail.schema import GuardrailResult as GuardrailResult
from pydantic import BaseModel
from typing import Protocol

class BaseGuardrailEngineConfig(BaseModel):
    """Base configuration for guardrail engines.

    This config determines which types of content the engine will check.
    Engines can be configured to check input only, output only, or both.

    Attributes:
        guardrail_mode: Specifies what content the engine should check.
            - DISABLED: Skip this engine entirely - no checks performed
            - INPUT_ONLY: Check only user input (queries, prompts, context)
            - OUTPUT_ONLY: Check only system output (LLM responses, generated text)
            - BOTH: Check both input and output content
    """
    guardrail_mode: GuardrailMode
    model_config: Incomplete

class GuardrailEngine(Protocol):
    """Base engine interface for guardrail engines.

    This protocol defines the contract that all guardrail engines must implement.
    Engines can check content for safety violations using various techniques such as
    phrase matching, topic classification, or external API calls.

    All engines must be asynchronous to support both sync and async guardrail providers.

    Attributes:
        config: Engine configuration specifying what content types to check
    """
    config: BaseGuardrailEngineConfig
    async def check_input(self, content: str, **kwargs) -> GuardrailResult:
        """Check input content for safety violations.

        This method should implement provider-specific safety checks on user input
        such as query content, context, or prompts before sending to LLM.

        Args:
            content: The input text to evaluate for safety
            **kwargs: Additional engine-specific parameters (optional)

        Returns:
            GuardrailResult indicating if content is safe, with reason if unsafe

        Raises:
            Exception: If the safety check fails due to engine errors
        """
    async def check_output(self, content: str, **kwargs) -> GuardrailResult:
        """Check output content for safety violations.

        This method should implement provider-specific safety checks on system output
        such as LLM responses, generated text, or static messages before showing to users.

        Args:
            content: The output text to evaluate for safety
            **kwargs: Additional engine-specific parameters (optional)

        Returns:
            GuardrailResult indicating if content is safe, with reason if unsafe

        Raises:
            Exception: If the safety check fails due to engine errors
        """
