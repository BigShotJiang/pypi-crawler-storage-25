from _typeshed import Incomplete
from gllm_guardrail.constants import GuardrailMode as GuardrailMode
from gllm_guardrail.engine.base_engine import BaseGuardrailEngineConfig as BaseGuardrailEngineConfig, GuardrailEngine as GuardrailEngine
from gllm_guardrail.schema import GuardrailResult as GuardrailResult
from typing import Any

manager: Incomplete
logger: Incomplete
SPACY_AVAILABLE: bool

class PhraseMatcherEngine(GuardrailEngine):
    """Engine that uses SpaCy PhraseMatcher or Regex for banned phrase detection.

    This engine implements the GuardrailEngine protocol to check content for banned phrases
    using either SpaCy for optimized matching or regex as a fallback.

    Attributes:
        config: Engine configuration specifying what content types to check
        banned_phrases (list[str]): Phrases that are explicitly banned.
        use_spacy (bool): Whether to use SpaCy for phrase matching.
        model_name (str): SpaCy model name to load.
        banned_phrases_regex (re.Pattern | None): Compiled regex pattern for fallback.
        phrase_matcher (PhraseMatcher | None): SpaCy phrase matcher.
        nlp (spacy.Language | None): SpaCy language model.
    """
    DEFAULT_BANNED_PHRASES: Incomplete
    config: Incomplete
    banned_phrases: Incomplete
    use_spacy: Incomplete
    model_name: Incomplete
    banned_phrases_regex: Incomplete
    phrase_matcher: Incomplete
    nlp: Incomplete
    def __init__(self, config: BaseGuardrailEngineConfig | None = None, banned_phrases: list[str] | None = None, use_spacy: bool | None = None, model_name: str = 'en_core_web_sm') -> None:
        '''Initialize the PhraseMatcherEngine.

        Args:
            config (BaseGuardrailEngineConfig | None, optional): Engine configuration.
                Defaults to BaseGuardrailEngineConfig with INPUT_ONLY mode.
            banned_phrases (list[str] | None, optional): List of banned phrases.
                Defaults to `DEFAULT_BANNED_PHRASES`.
            use_spacy (bool | None, optional): Whether to use SpaCy for phrase matching.
                Defaults to SPACY_AVAILABLE.
            model_name (str, optional): SpaCy model name to load.
                Defaults to "en_core_web_sm".
        '''
    async def check_input(self, content: str, **kwargs: Any) -> GuardrailResult:
        """Check input content for banned phrases.

        Args:
            content: The input text to evaluate for safety
            **kwargs: Additional engine-specific parameters (optional)

        Returns:
            GuardrailResult indicating if content is safe, with reason if unsafe

        Raises:
            Exception: If the safety check fails due to engine errors
        """
    async def check_output(self, content: str, **kwargs: Any) -> GuardrailResult:
        """Check output content for banned phrases.

        Args:
            content: The output text to evaluate for safety
            **kwargs: Additional engine-specific parameters (optional)

        Returns:
            GuardrailResult indicating if content is safe, with reason if unsafe

        Raises:
            Exception: If the safety check fails due to engine errors
        """
