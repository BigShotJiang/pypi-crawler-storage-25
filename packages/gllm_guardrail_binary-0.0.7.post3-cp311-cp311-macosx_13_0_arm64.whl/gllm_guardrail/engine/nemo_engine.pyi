from _typeshed import Incomplete
from gllm_guardrail.adapter.nemo_adapter import NeMoLMAdapter as NeMoLMAdapter
from gllm_guardrail.config.safety import ContentSafetyConfigBuilder as ContentSafetyConfigBuilder, TopicSafetyConfigBuilder as TopicSafetyConfigBuilder
from gllm_guardrail.constants import NEMO_BASE_CONFIG_PATH as NEMO_BASE_CONFIG_PATH
from gllm_guardrail.engine.base_engine import BaseGuardrailEngineConfig as BaseGuardrailEngineConfig, GuardrailEngine as GuardrailEngine
from gllm_guardrail.schema import GuardrailResult as GuardrailResult
from gllm_inference.lm_invoker.lm_invoker import BaseLMInvoker
from gllm_inference.schema import ModelId
from nemoguardrails import LLMRails
from typing import Any

manager: Incomplete
logger: Incomplete

def init_guardrails_provider_registration() -> bool:
    """Register global NeMo Guardrails chat provider once.

    This avoids redundant registration per preset/component. Safe to call once
    during process initialization.

    Returns:
        bool: True if registration succeeded, False otherwise.
    """

class NemoGuardrailEngineConfig(BaseGuardrailEngineConfig):
    """NeMo-specific configuration that extends base guardrail config.

    This config inherits the basic guardrail_mode from BaseGuardrailEngineConfig
    and adds NeMo-specific settings for advanced guardrail functionality.

    Attributes:
        lm_invoker (BaseLMInvoker | None): Invoker used by the NeMo adapter.
        nemo_kwargs (dict[str, Any] | None): NeMo-specific kwargs.
        content_safety_config (ContentSafetyConfigBuilder | None): Content safety configuration.
        topic_safety_config (TopicSafetyConfigBuilder | None): Topic safety configuration.

    Example:
        Provide both configs to enable full content and topic safety::

            from gllm_guardrail.config.safety import ContentSafetyConfigBuilder, TopicSafetyConfigBuilder

            config = NemoGuardrailEngineConfig(
                lm_invoker=my_invoker,
                content_safety_config=ContentSafetyConfigBuilder(),
                topic_safety_config=TopicSafetyConfigBuilder(),
            )

        Either config can be provided alone to enable only that safety check::

            # Only content safety, topic safety disabled
            config = NemoGuardrailEngineConfig(
                lm_invoker=my_invoker,
                content_safety_config=ContentSafetyConfigBuilder(),
            )

            # Only topic safety, content safety disabled
            config = NemoGuardrailEngineConfig(
                lm_invoker=my_invoker,
                topic_safety_config=TopicSafetyConfigBuilder(),
            )

    Raises:
        ValidationError: If neither `content_safety_config` nor `topic_safety_config` is provided.
    """
    lm_invoker: BaseLMInvoker | None
    nemo_kwargs: dict[str, Any] | None
    content_safety_config: ContentSafetyConfigBuilder | None
    topic_safety_config: TopicSafetyConfigBuilder | None
    @classmethod
    def from_model_config(cls, model_id: str | ModelId, credentials: str | dict[str, Any] | None = None, config: dict[str, Any] | None = None, **kwargs: Any) -> NemoGuardrailEngineConfig:
        """Create a NemoGuardrailEngineConfig from a model configuration.

        Args:
            model_id (str | ModelId): The model ID.
            credentials (str | dict[str, Any] | None): The credentials for the model.
            config (dict[str, Any] | None): The model configuration.
            **kwargs (Any): Additional kwargs to pass to the constructor.

        Returns:
            NemoGuardrailEngineConfig: The created NemoGuardrailEngineConfig.
        """

class NemoGuardrailEngine(GuardrailEngine):
    """Default engine that keeps current NeMo Guardrails behavior.

    This engine implements the GuardrailEngine protocol to provide NeMo Guardrails
    functionality for content safety checking.

    Attributes:
        config (NemoGuardrailEngineConfig): Engine configuration specifying what content types to check.
        rails (LLMRails | None): LLMRails instance.
    """
    config: NemoGuardrailEngineConfig
    rails: LLMRails | None
    def __init__(self, config: NemoGuardrailEngineConfig) -> None:
        """Initializes a new instance of the NemoGuardrailEngine class.

        The engine uses structured safety configuration via `content_safety_config`
        and `topic_safety_config`. Either or both can be provided; if only one is
        given, that check runs and the other is skipped.

        **LLM Invoker Override:**
        If `self.config.nemo_kwargs` is provided and contains a model configuration with
        `type: main`, that model will be overridden by `self.config.lm_invoker` to ensure
        consistency across the SDK.

        Example:
            Activate the new configuration by providing at least one safety config::

                from gllm_guardrail.config.safety import ContentSafetyConfigBuilder, TopicSafetyConfigBuilder

                # Both enabled (recommended)
                config = NemoGuardrailEngineConfig(
                    lm_invoker=my_invoker,
                content_safety_config=ContentSafetyConfigBuilder(),
                topic_safety_config=TopicSafetyConfigBuilder(),
                )

                # Only content safety enabled, topic safety skipped
                config = NemoGuardrailEngineConfig(
                    lm_invoker=my_invoker,
                    content_safety_config=ContentSafetyConfigBuilder(),
                )

                engine = NemoGuardrailEngine(config=config)

        Args:
            config (NemoGuardrailEngineConfig): NemoGuardrailEngineConfig specifying both base
                and NeMo-specific settings.
        """
    async def check_input(self, content: str, **kwargs: Any) -> GuardrailResult:
        """Check input content for safety violations.

        This method implements NeMo Guardrails checking for user input such as
        query content, context, or prompts before sending to LLM.

        Args:
            content (str): The input text to evaluate for safety.
            **kwargs (Any): Additional engine-specific parameters.

        Returns:
            GuardrailResult: GuardrailResult indicating if content is safe, with reason if unsafe.

        Raises:
            RuntimeError: If the guardrail engine is not initialized.
        """
    async def check_output(self, content: str, **kwargs: Any) -> GuardrailResult:
        """Check output content for safety violations.

        This method implements NeMo Guardrails checking for system output such as
        LLM responses, generated text, or static messages before showing to users.

        Args:
            content (str): The output text to evaluate for safety.
            **kwargs (Any): Additional engine-specific parameters.

        Returns:
            GuardrailResult: GuardrailResult indicating if content is safe, with reason if unsafe.

        Raises:
            RuntimeError: If the guardrail engine is not initialized.
        """
