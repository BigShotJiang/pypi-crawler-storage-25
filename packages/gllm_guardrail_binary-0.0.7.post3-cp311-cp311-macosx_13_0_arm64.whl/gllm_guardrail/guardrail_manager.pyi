from .constants import GuardrailConstants as GuardrailConstants, GuardrailMode as GuardrailMode
from .engine.base_engine import GuardrailEngine as GuardrailEngine
from .schema import GuardrailInput as GuardrailInput, GuardrailResult as GuardrailResult
from _typeshed import Incomplete
from gllm_core.schema import Component
from typing import Any

manager: Incomplete
logger: Incomplete

class GuardrailManager(Component, GuardrailConstants):
    """Manage content guardrails using pluggable engines.

    This component provides content filtering and safety checks and delegates the
    provider-specific logic to a GuardrailEngine.

    Attributes:
        engine (GuardrailEngine | list[GuardrailEngine]): Required pluggable engine for guardrail operations.
            Provide a custom engine or a list of engines to handle guardrail logic.
            If a list is provided, engines are executed sequentially in the order they appear.
        empty_content_safe (bool | None, optional): Whether empty content should be considered safe.
            Defaults to None.
        error_conservative (bool | None, optional): Whether to mark content as unsafe on errors.
            Defaults to None.
    """
    engine: Incomplete
    empty_content_safe: Incomplete
    error_conservative: Incomplete
    def __init__(self, engine: GuardrailEngine | list[GuardrailEngine], empty_content_safe: bool | None = None, error_conservative: bool | None = None) -> None:
        """Initialize the GuardrailManager class.

        Args:
            engine (GuardrailEngine | list[GuardrailEngine]): Required pluggable engine for guardrail operations.
                Provide a custom engine or a list of engines to handle guardrail logic.
                If a list is provided, engines are executed sequentially in the order they appear.
            empty_content_safe (bool | None, optional): Whether empty content should be considered safe.
                Defaults to True.
            error_conservative (bool | None, optional): Whether to mark content as unsafe on errors.
                Defaults to True.
        """
    async def check_content(self, content: str | GuardrailInput, engine_kwargs: dict[str, Any] | None = None) -> GuardrailResult:
        '''Check the content for safety using configured engines.

        This method iterates through the configured engines sequentially and
        returns the first unsafe result found. This "fail-fast" approach ensures
        efficient processing while maintaining strict safety guarantees.

        Engines with DISABLED mode are skipped entirely. For active engines,
        it checks input content if the engine\'s guardrail_mode includes input checking,
        then checks output content if the input passed and the engine\'s mode
        includes output checking.

        Args:
            content (str | GuardrailInput): The primary content to check.
                If str, treated as input-only content.
            engine_kwargs (dict[str, Any] | None, optional): Arguments to pass
                to each engine. Defaults to None.

        Returns:
            GuardrailResult: The result of the content safety check.
                Returns safe result only if all engines pass all applicable checks.

        Raises:
            ValueError: If content is neither str nor GuardrailInput
        '''
