"""x402-pay — Pay for x402 APIs with one line of Python.

Quick start (sync)::

    import x402_pay

    resp = x402_pay.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
    print(resp.json())

Quick start (async)::

    from x402_pay import PayClient

    async with PayClient() as client:
        resp = await client.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
        print(resp.json())

Wallet mode (power users)::

    from x402_pay import DirectClient

    async with DirectClient(private_key="0x...") as client:
        resp = await client.get("https://weather.hugen.tokyo/weather/current?city=Tokyo")
"""

from .client import PayClient
from .direct import DirectClient
from .exceptions import (
    BrokerError,
    InsufficientBalance,
    NotInCatalog,
    PayError,
)
from ._sync import get, post, balance, discover

__all__ = [
    # Async clients
    "PayClient",
    "DirectClient",
    # Sync convenience
    "get",
    "post",
    "balance",
    "discover",
    # Exceptions
    "PayError",
    "InsufficientBalance",
    "NotInCatalog",
    "BrokerError",
]

__version__ = "0.2.1"
