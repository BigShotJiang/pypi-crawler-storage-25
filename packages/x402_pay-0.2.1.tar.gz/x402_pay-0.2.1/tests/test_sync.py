"""Tests for synchronous convenience wrappers."""

import json
from unittest.mock import patch, AsyncMock

import httpx
import pytest

import x402_pay
from x402_pay._sync import _run_async


def test_run_async_basic():
    """_run_async runs a simple coroutine."""

    async def hello():
        return 42

    assert _run_async(hello()) == 42


def test_module_level_get(monkeypatch, tmp_path):
    """x402_pay.get() works as sync convenience."""
    monkeypatch.setenv("X402_PAY_CONFIG_DIR", str(tmp_path / ".x402-pay"))
    monkeypatch.setenv("X402_API_KEY", "gw_testkey123")

    # Mock the broker transport's internal HTTP client
    async def mock_handler(request: httpx.Request) -> httpx.Response:
        if "/broker/call" in str(request.url):
            return httpx.Response(
                200,
                json={"city": "Tokyo", "temp": 22},
                headers={"x-broker-cost": "0.01", "x-broker-balance": "0.04"},
                request=request,
            )
        return httpx.Response(404, request=request)

    # Patch at the transport level
    original_init = x402_pay.PayClient._ensure_init

    async def patched_init(self):
        await original_init(self)
        if self._transport is not None:
            self._transport._http = httpx.AsyncClient(
                transport=httpx.MockTransport(mock_handler)
            )

    with patch.object(x402_pay.PayClient, "_ensure_init", patched_init):
        resp = x402_pay.get(
            "https://weather.test/weather/current?city=Tokyo",
            api_key="gw_testkey123",
            broker_url="https://broker.test",
        )
        assert resp.status_code == 200
        assert resp.json()["city"] == "Tokyo"


def test_module_level_post(monkeypatch, tmp_path):
    """x402_pay.post() works as sync convenience."""
    monkeypatch.setenv("X402_PAY_CONFIG_DIR", str(tmp_path / ".x402-pay"))
    monkeypatch.setenv("X402_API_KEY", "gw_testkey123")

    async def mock_handler(request: httpx.Request) -> httpx.Response:
        if "/broker/call" in str(request.url):
            return httpx.Response(
                200,
                json={"result": "simulated"},
                headers={"x-broker-cost": "0.01"},
                request=request,
            )
        return httpx.Response(404, request=request)

    original_init = x402_pay.PayClient._ensure_init

    async def patched_init(self):
        await original_init(self)
        if self._transport is not None:
            self._transport._http = httpx.AsyncClient(
                transport=httpx.MockTransport(mock_handler)
            )

    with patch.object(x402_pay.PayClient, "_ensure_init", patched_init):
        resp = x402_pay.post(
            "https://defi.test/defi/simulate",
            api_key="gw_testkey123",
            broker_url="https://broker.test",
            json={"chain_id": "1", "from": "0x...", "to": "0x..."},
        )
        assert resp.status_code == 200
        assert resp.json()["result"] == "simulated"


def test_version():
    """Version is accessible and updated."""
    assert x402_pay.__version__ == "0.2.1"


def test_public_api():
    """All expected names are importable."""
    assert callable(x402_pay.get)
    assert callable(x402_pay.post)
    assert callable(x402_pay.balance)
    assert callable(x402_pay.discover)
    assert x402_pay.PayClient is not None
    assert x402_pay.DirectClient is not None
    assert issubclass(x402_pay.InsufficientBalance, x402_pay.PayError)
    assert issubclass(x402_pay.NotInCatalog, x402_pay.PayError)
    assert issubclass(x402_pay.BrokerError, x402_pay.PayError)


def test_module_level_discover(monkeypatch, tmp_path):
    """x402_pay.discover() returns API results via direct HTTP (not broker)."""
    monkeypatch.setenv("X402_PAY_CONFIG_DIR", str(tmp_path / ".x402-pay"))
    monkeypatch.setenv("X402_API_KEY", "gw_testkey123")

    mock_response = httpx.Response(
        200,
        json={
            "query": "weather",
            "total_results": 1,
            "results": [
                {"url": "https://weather.test/current", "description": "Weather API", "price": "$0.005", "brokerable": True}
            ],
            "call_via": {"broker": "...", "sdk": "..."},
        },
        request=httpx.Request("GET", "https://broker.test/discovery/search?q=weather&limit=5"),
    )

    with patch("x402_pay.client.httpx.AsyncClient") as MockClient:
        mock_instance = AsyncMock()
        mock_instance.get.return_value = mock_response
        mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
        mock_instance.__aexit__ = AsyncMock(return_value=None)
        MockClient.return_value = mock_instance

        results = x402_pay.discover("weather", api_key="gw_testkey123", broker_url="https://broker.test")
        assert len(results) == 1
        assert results[0]["url"] == "https://weather.test/current"
        assert results[0]["brokerable"] is True
