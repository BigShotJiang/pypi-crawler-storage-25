"""asyncpg connection pool management for Core Manager.

Provides async functions to create and close the PostgreSQL connection pool.
"""

from typing import Any, Optional

import asyncpg

_pool: Optional[asyncpg.Pool] = None


async def create_pool(**kwargs: Any) -> asyncpg.Pool:
    """Create an asyncpg connection pool.

    Args:
        **kwargs: Connection parameters (host, port, database, user, password).

    Returns:
        An asyncpg connection pool instance.

    Raises:
        SystemExit: If the database connection cannot be established.
    """
    global _pool
    try:
        pool = await asyncpg.create_pool(**kwargs)
        if pool is None:
            raise RuntimeError("asyncpg.create_pool returned None")
        # Validate the connection with a simple query
        async with pool.acquire() as conn:
            await conn.fetchval("SELECT 1")
        _pool = pool
        return pool
    except (asyncpg.PostgresError, OSError, RuntimeError) as exc:
        raise SystemExit(
            f"Error: could not connect to database — {exc}"
        ) from exc


async def close_pool(pool: Optional[asyncpg.Pool] = None) -> None:
    """Close the asyncpg connection pool."""
    global _pool
    target = pool or _pool
    if target is not None:
        await target.close()
        if target is _pool:
            _pool = None


def get_pool() -> asyncpg.Pool:
    """Return the module-level singleton connection pool.

    Raises:
        RuntimeError: If the pool has not been initialised.
    """
    if _pool is None:
        raise RuntimeError(
            "Database connection pool not initialised. "
            "Call create_pool() first."
        )
    return _pool
