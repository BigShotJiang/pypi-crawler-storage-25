"""Raw SQL query functions for Bamboo Inspect Core Manager.

All database operations use parameterized raw SQL via asyncpg.
No ORM — all queries are plain SQL strings.
Includes original tables (project, module, test, etc.) plus new
agent management tables (agent, registration_token).
"""

import json
from datetime import datetime, timezone
from typing import Any, Optional

import asyncpg

# ---------------------------------------------------------------------------
# Project queries
# ---------------------------------------------------------------------------


async def insert_project(
    pool: asyncpg.Pool,
    id: str,
    name: str,
    path: str,
    git_remote_url: Optional[str] = None,
) -> dict[str, Any]:
    """Insert a new project record."""
    row = await pool.fetchrow(
        """
        INSERT INTO project (id, name, path, git_remote_url)
        VALUES ($1, $2, $3, $4)
        RETURNING *
        """,
        id, name, path, git_remote_url,
    )
    return dict(row) if row else {}


async def get_project_by_id(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get a project by its ID."""
    row = await pool.fetchrow("SELECT * FROM project WHERE id = $1", id)
    return dict(row) if row else None


async def get_project_by_name(pool: asyncpg.Pool, name: str) -> Optional[dict[str, Any]]:
    """Get a project by its name."""
    row = await pool.fetchrow("SELECT * FROM project WHERE name = $1", name)
    return dict(row) if row else None


async def list_projects(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all registered projects."""
    rows = await pool.fetch("SELECT * FROM project ORDER BY name")
    return [dict(r) for r in rows]


async def delete_project(pool: asyncpg.Pool, id: str) -> None:
    """Delete a project by ID."""
    await pool.execute("DELETE FROM project WHERE id = $1", id)


async def update_project_last_scan(pool: asyncpg.Pool, id: str) -> None:
    """Update the last_scan timestamp for a project."""
    await pool.execute(
        "UPDATE project SET last_scan = $1 WHERE id = $2",
        datetime.now(timezone.utc), id,
    )


# ---------------------------------------------------------------------------
# Module queries
# ---------------------------------------------------------------------------


async def insert_module(
    pool: asyncpg.Pool,
    id: str,
    project_id: str,
    name: str,
    path: str,
) -> dict[str, Any]:
    """Insert a new module record."""
    row = await pool.fetchrow(
        """
        INSERT INTO module (id, project_id, name, path)
        VALUES ($1, $2, $3, $4)
        RETURNING *
        """,
        id, project_id, name, path,
    )
    return dict(row) if row else {}


async def get_modules_by_project(pool: asyncpg.Pool, project_id: str) -> list[dict[str, Any]]:
    """List all modules for a project."""
    rows = await pool.fetch(
        "SELECT * FROM module WHERE project_id = $1 ORDER BY name",
        project_id,
    )
    return [dict(r) for r in rows]


async def delete_modules_by_project(pool: asyncpg.Pool, project_id: str) -> None:
    """Delete all modules belonging to a project."""
    await pool.execute("DELETE FROM module WHERE project_id = $1", project_id)


# ---------------------------------------------------------------------------
# Test queries
# ---------------------------------------------------------------------------


async def insert_test(
    pool: asyncpg.Pool,
    id: str,
    module_id: str,
    name: str,
    type: str,
    path: str,
    description: Optional[str] = None,
    tags: Optional[list[str]] = None,
    timeout: Optional[int] = None,
    retry_count: int = 0,
) -> dict[str, Any]:
    """Insert a new test record."""
    row = await pool.fetchrow(
        """
        INSERT INTO test (id, module_id, name, type, path, description, tags, timeout, retry_count)
        VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9)
        RETURNING *
        """,
        id, module_id, name, type, path, description,
        json.dumps(tags or []), timeout, retry_count,
    )
    return dict(row) if row else {}


async def get_test_by_id(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get a test by its ID."""
    row = await pool.fetchrow("SELECT * FROM test WHERE id = $1", id)
    return dict(row) if row else None


async def get_tests_by_module(pool: asyncpg.Pool, module_id: str) -> list[dict[str, Any]]:
    """List all tests in a module."""
    rows = await pool.fetch(
        "SELECT * FROM test WHERE module_id = $1 ORDER BY name",
        module_id,
    )
    return [dict(r) for r in rows]


async def get_test_by_name(
    pool: asyncpg.Pool, name: str, type: str,
) -> Optional[dict[str, Any]]:
    """Get a test by name and type."""
    row = await pool.fetchrow(
        "SELECT * FROM test WHERE name = $1 AND type = $2",
        name, type,
    )
    return dict(row) if row else None


async def delete_tests_by_module(pool: asyncpg.Pool, module_id: str) -> None:
    """Delete all tests belonging to a module."""
    await pool.execute("DELETE FROM test WHERE module_id = $1", module_id)


# ---------------------------------------------------------------------------
# RunSession queries (with agent_id support)
# ---------------------------------------------------------------------------


async def insert_run_session(
    pool: asyncpg.Pool,
    id: str,
    project_id: str,
    tracking_level: str = "none",
    status: str = "pending",
    triggered_by: str = "manual",
    git_commit_sha: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> dict[str, Any]:
    """Insert a new run session record."""
    row = await pool.fetchrow(
        """
        INSERT INTO run_session (id, project_id, tracking_level, status, triggered_by, git_commit_sha, agent_id)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
        """,
        id, project_id, tracking_level, status, triggered_by, git_commit_sha, agent_id,
    )
    return dict(row) if row else {}


async def update_run_session(
    pool: asyncpg.Pool,
    id: str,
    status: str,
    total_tests: int,
    passed: int,
    failed: int,
    finished_at: Optional[datetime] = None,
) -> None:
    """Update a run session with final results."""
    await pool.execute(
        """
        UPDATE run_session
        SET status = $1, total_tests = $2, passed = $3, failed = $4, finished_at = $5
        WHERE id = $6
        """,
        status, total_tests, passed, failed,
        finished_at or datetime.now(timezone.utc), id,
    )


async def get_run_session(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get a run session by ID."""
    row = await pool.fetchrow("SELECT * FROM run_session WHERE id = $1", id)
    return dict(row) if row else None


async def list_run_sessions(
    pool: asyncpg.Pool,
    project_id: Optional[str] = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """List run sessions, optionally filtered by project."""
    if project_id:
        rows = await pool.fetch(
            "SELECT * FROM run_session WHERE project_id = $1 ORDER BY started_at DESC LIMIT $2",
            project_id, limit,
        )
    else:
        rows = await pool.fetch(
            "SELECT * FROM run_session ORDER BY started_at DESC LIMIT $1",
            limit,
        )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Execution queries (with agent_id support)
# ---------------------------------------------------------------------------


async def insert_execution(
    pool: asyncpg.Pool,
    id: str,
    test_id: str,
    status: str = "pending",
    session_id: Optional[str] = None,
    triggered_by: str = "manual",
    git_commit_sha: Optional[str] = None,
    agent_id: Optional[str] = None,
) -> dict[str, Any]:
    """Insert a new execution record."""
    row = await pool.fetchrow(
        """
        INSERT INTO execution (id, session_id, test_id, status, triggered_by, git_commit_sha, agent_id)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
        """,
        id, session_id, test_id, status, triggered_by, git_commit_sha, agent_id,
    )
    return dict(row) if row else {}


async def update_execution(
    pool: asyncpg.Pool,
    id: str,
    status: str,
    duration: Optional[int] = None,
    error_message: Optional[str] = None,
    logs: Optional[str] = None,
    artifacts: Optional[dict] = None,
) -> None:
    """Update an execution with results."""
    await pool.execute(
        """
        UPDATE execution
        SET status = $1, duration = $2, error_message = $3, logs = $4, artifacts = $5::jsonb
        WHERE id = $6
        """,
        status, duration, error_message, logs,
        json.dumps(artifacts or {}), id,
    )


async def get_execution(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get an execution by ID."""
    row = await pool.fetchrow("SELECT * FROM execution WHERE id = $1", id)
    return dict(row) if row else None


async def list_executions_by_session(pool: asyncpg.Pool, session_id: str) -> list[dict[str, Any]]:
    """List all executions for a run session."""
    rows = await pool.fetch(
        "SELECT * FROM execution WHERE session_id = $1 ORDER BY created_at",
        session_id,
    )
    return [dict(r) for r in rows]


async def list_executions_by_agent(
    pool: asyncpg.Pool,
    agent_id: str,
    status: Optional[str] = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """List executions assigned to an agent, optionally filtered by status."""
    if status:
        rows = await pool.fetch(
            "SELECT * FROM execution WHERE agent_id = $1 AND status = $2 ORDER BY created_at LIMIT $3",
            agent_id, status, limit,
        )
    else:
        rows = await pool.fetch(
            "SELECT * FROM execution WHERE agent_id = $1 ORDER BY created_at DESC LIMIT $2",
            agent_id, limit,
        )
    return [dict(r) for r in rows]


async def list_pending_executions_for_agent(
    pool: asyncpg.Pool, agent_id: str,
) -> list[dict[str, Any]]:
    """List all pending executions assigned to an agent (oldest first)."""
    rows = await pool.fetch(
        "SELECT * FROM execution WHERE agent_id = $1 AND status = 'pending' ORDER BY created_at ASC",
        agent_id,
    )
    return [dict(r) for r in rows]


async def list_executions_by_status(
    pool: asyncpg.Pool, status: str, limit: int = 50,
) -> list[dict[str, Any]]:
    """List executions filtered by status."""
    rows = await pool.fetch(
        "SELECT * FROM execution WHERE status = $1 ORDER BY created_at DESC LIMIT $2",
        status, limit,
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# ExecutionStep queries
# ---------------------------------------------------------------------------


async def insert_execution_step(
    pool: asyncpg.Pool,
    id: str,
    execution_id: str,
    step_order: int,
    name: str,
    status: str,
    duration: Optional[int] = None,
    error_message: Optional[str] = None,
) -> dict[str, Any]:
    """Insert an execution step record."""
    row = await pool.fetchrow(
        """
        INSERT INTO execution_step (id, execution_id, step_order, name, status, duration, error_message)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
        """,
        id, execution_id, step_order, name, status, duration, error_message,
    )
    return dict(row) if row else {}


async def list_steps_by_execution(pool: asyncpg.Pool, execution_id: str) -> list[dict[str, Any]]:
    """List all steps for an execution, ordered by step_order."""
    rows = await pool.fetch(
        "SELECT * FROM execution_step WHERE execution_id = $1 ORDER BY step_order",
        execution_id,
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Report queries
# ---------------------------------------------------------------------------


async def insert_report(
    pool: asyncpg.Pool,
    id: str,
    format: str,
    source: str,
    content: str,
    execution_id: Optional[str] = None,
    session_id: Optional[str] = None,
) -> dict[str, Any]:
    """Insert a report record."""
    row = await pool.fetchrow(
        """
        INSERT INTO report (id, execution_id, session_id, format, source, content)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
        """,
        id, execution_id, session_id, format, source, content,
    )
    return dict(row) if row else {}


async def get_report(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get a report by ID."""
    row = await pool.fetchrow("SELECT * FROM report WHERE id = $1", id)
    return dict(row) if row else None


async def get_report_by_session(pool: asyncpg.Pool, session_id: str) -> Optional[dict[str, Any]]:
    """Get the report for a run session."""
    row = await pool.fetchrow(
        "SELECT * FROM report WHERE session_id = $1 ORDER BY created_at DESC LIMIT 1",
        session_id,
    )
    return dict(row) if row else None


async def get_report_by_execution(pool: asyncpg.Pool, execution_id: str) -> Optional[dict[str, Any]]:
    """Get the report for an execution."""
    row = await pool.fetchrow(
        "SELECT * FROM report WHERE execution_id = $1 ORDER BY created_at DESC LIMIT 1",
        execution_id,
    )
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Webhook queries
# ---------------------------------------------------------------------------


async def insert_webhook(
    pool: asyncpg.Pool,
    id: str,
    url: str,
    headers: Optional[dict] = None,
    auth_type: Optional[str] = None,
    auth_config: Optional[dict] = None,
    events: Optional[list[str]] = None,
    retry_count: int = 3,
    active: bool = True,
) -> dict[str, Any]:
    """Insert a new webhook record."""
    row = await pool.fetchrow(
        """
        INSERT INTO webhook (id, url, headers, auth_type, auth_config, events, retry_count, active)
        VALUES ($1, $2, $3::jsonb, $4, $5::jsonb, $6::jsonb, $7, $8)
        RETURNING *
        """,
        id, url,
        json.dumps(headers or {}), auth_type,
        json.dumps(auth_config or {}), json.dumps(events or []),
        retry_count, active,
    )
    return dict(row) if row else {}


async def list_webhooks(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all webhooks."""
    rows = await pool.fetch("SELECT * FROM webhook ORDER BY url")
    return [dict(r) for r in rows]


async def get_webhook(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get a webhook by ID."""
    row = await pool.fetchrow("SELECT * FROM webhook WHERE id = $1", id)
    return dict(row) if row else None


async def delete_webhook(pool: asyncpg.Pool, id: str) -> None:
    """Delete a webhook by ID."""
    await pool.execute("DELETE FROM webhook WHERE id = $1", id)


async def list_active_webhooks(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all active webhooks."""
    rows = await pool.fetch(
        "SELECT * FROM webhook WHERE active = TRUE ORDER BY url"
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Config queries
# ---------------------------------------------------------------------------


async def upsert_config(
    pool: asyncpg.Pool,
    id: str,
    key: str,
    value: Any,
) -> dict[str, Any]:
    """Insert or update a config key-value pair."""
    row = await pool.fetchrow(
        """
        INSERT INTO config (id, key, value)
        VALUES ($1, $2, $3::jsonb)
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
        RETURNING *
        """,
        id, key, json.dumps(value),
    )
    return dict(row) if row else {}


async def get_config(pool: asyncpg.Pool, key: str) -> Optional[dict[str, Any]]:
    """Get a config value by key."""
    row = await pool.fetchrow("SELECT * FROM config WHERE key = $1", key)
    return dict(row) if row else None


async def list_config(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all config entries."""
    rows = await pool.fetch("SELECT * FROM config ORDER BY key")
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Agent queries
# ---------------------------------------------------------------------------


async def insert_agent(
    pool: asyncpg.Pool,
    id: str,
    name: str,
    labels: list[str],
    status: str,
    token_hash: str,
    os_info: Optional[dict] = None,
    metadata: Optional[dict] = None,
) -> dict[str, Any]:
    """Insert a new agent record."""
    row = await pool.fetchrow(
        """
        INSERT INTO agent (id, name, labels, status, token_hash, os_info, metadata)
        VALUES ($1, $2, $3::jsonb, $4, $5, $6::jsonb, $7::jsonb)
        RETURNING *
        """,
        id, name, json.dumps(labels), status, token_hash,
        json.dumps(os_info or {}), json.dumps(metadata or {}),
    )
    return dict(row) if row else {}


async def get_agent_by_id(pool: asyncpg.Pool, id: str) -> Optional[dict[str, Any]]:
    """Get an agent by ID."""
    row = await pool.fetchrow("SELECT * FROM agent WHERE id = $1", id)
    return dict(row) if row else None


async def get_agent_by_name(pool: asyncpg.Pool, name: str) -> Optional[dict[str, Any]]:
    """Get an agent by name."""
    row = await pool.fetchrow("SELECT * FROM agent WHERE name = $1", name)
    return dict(row) if row else None


async def get_agent_by_token_hash(pool: asyncpg.Pool, token_hash: str) -> Optional[dict[str, Any]]:
    """Get an agent by its persistent token hash."""
    row = await pool.fetchrow("SELECT * FROM agent WHERE token_hash = $1", token_hash)
    return dict(row) if row else None


async def list_agents(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all registered agents."""
    rows = await pool.fetch("SELECT * FROM agent ORDER BY name")
    return [dict(r) for r in rows]


async def update_agent_status(pool: asyncpg.Pool, id: str, status: str) -> None:
    """Update an agent's status."""
    await pool.execute("UPDATE agent SET status = $1 WHERE id = $2", status, id)


async def update_agent_heartbeat(pool: asyncpg.Pool, id: str) -> None:
    """Update an agent's last heartbeat timestamp."""
    await pool.execute(
        "UPDATE agent SET last_heartbeat_at = $1 WHERE id = $2",
        datetime.now(timezone.utc), id,
    )


async def update_agent_labels(pool: asyncpg.Pool, id: str, labels: list[str]) -> None:
    """Update an agent's labels."""
    await pool.execute(
        "UPDATE agent SET labels = $1::jsonb WHERE id = $2",
        json.dumps(labels), id,
    )


async def delete_agent(pool: asyncpg.Pool, id: str) -> None:
    """Delete an agent by ID."""
    await pool.execute("DELETE FROM agent WHERE id = $1", id)


async def list_agents_needing_offline(
    pool: asyncpg.Pool, threshold_seconds: int = 90,
) -> list[dict[str, Any]]:
    """List agents whose last heartbeat is older than *threshold_seconds*."""
    rows = await pool.fetch(
        """
        SELECT * FROM agent
        WHERE status IN ('idle', 'busy', 'online')
          AND last_heartbeat_at < NOW() - INTERVAL '1 second' * $1
        """,
        threshold_seconds,
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Registration Token queries
# ---------------------------------------------------------------------------


async def insert_registration_token(
    pool: asyncpg.Pool,
    id: str,
    token_hash: str,
    description: Optional[str] = None,
    expires_at: Optional[datetime] = None,
) -> dict[str, Any]:
    """Insert a registration token record."""
    row = await pool.fetchrow(
        """
        INSERT INTO registration_token (id, token_hash, description, expires_at)
        VALUES ($1, $2, $3, $4)
        RETURNING *
        """,
        id, token_hash, description, expires_at,
    )
    return dict(row) if row else {}


async def get_registration_token_by_hash(
    pool: asyncpg.Pool, token_hash: str,
) -> Optional[dict[str, Any]]:
    """Get a registration token by its hash."""
    row = await pool.fetchrow(
        "SELECT * FROM registration_token WHERE token_hash = $1",
        token_hash,
    )
    return dict(row) if row else None


async def list_registration_tokens(pool: asyncpg.Pool) -> list[dict[str, Any]]:
    """List all registration tokens."""
    rows = await pool.fetch(
        "SELECT id, description, created_at, expires_at, used, "
        "used_by_agent_id FROM registration_token ORDER BY created_at DESC"
    )
    return [dict(r) for r in rows]


async def mark_registration_token_used(
    pool: asyncpg.Pool, id: str, agent_id: str,
) -> None:
    """Mark a registration token as used."""
    await pool.execute(
        "UPDATE registration_token SET used = TRUE, used_by_agent_id = $1 WHERE id = $2",
        agent_id, id,
    )


async def delete_registration_token(pool: asyncpg.Pool, id: str) -> None:
    """Delete a registration token."""
    await pool.execute("DELETE FROM registration_token WHERE id = $1", id)


# ---------------------------------------------------------------------------
# Data retention
# ---------------------------------------------------------------------------


async def delete_old_records(pool: asyncpg.Pool, retention_days: int) -> dict[str, int]:
    """Delete records older than *retention_days*."""
    from datetime import timedelta

    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    counts: dict[str, int] = {}

    for table, col in [
        ("execution_step", "created_at"),
        ("report", "created_at"),
        ("execution", "created_at"),
        ("run_session", "started_at"),
    ]:
        result = await pool.execute(
            f"DELETE FROM {table} WHERE {col} < $1",  # noqa: S608
            cutoff,
        )
        counts[table] = int(result.split()[-1])

    return counts


# ---------------------------------------------------------------------------
# Admin User queries
# ---------------------------------------------------------------------------


async def get_admin_user_by_username(
    pool: asyncpg.Pool, username: str,
) -> Optional[dict[str, Any]]:
    """Get an active admin user by username."""
    row = await pool.fetchrow(
        "SELECT * FROM admin_user WHERE username = $1 AND is_active = TRUE",
        username,
    )
    return dict(row) if row else None


async def get_admin_user_by_id(
    pool: asyncpg.Pool, id: str,
) -> Optional[dict[str, Any]]:
    """Get an admin user by ID."""
    row = await pool.fetchrow("SELECT * FROM admin_user WHERE id = $1", id)
    return dict(row) if row else None


async def get_admin_user_roles(
    pool: asyncpg.Pool, user_id: str,
) -> list[str]:
    """Get role names for an admin user."""
    rows = await pool.fetch(
        """
        SELECT r.name
        FROM admin_user_role ur
        JOIN admin_role r ON r.id = ur.role_id
        WHERE ur.user_id = $1
        ORDER BY r.name
        """,
        user_id,
    )
    return [row["name"] for row in rows]


async def insert_admin_user(
    pool: asyncpg.Pool,
    id: str,
    username: str,
    password_hash: str,
    display_name: Optional[str] = None,
) -> dict[str, Any]:
    """Insert a new admin user."""
    row = await pool.fetchrow(
        """
        INSERT INTO admin_user (id, username, password_hash, display_name)
        VALUES ($1, $2, $3, $4)
        RETURNING *
        """,
        id, username, password_hash, display_name,
    )
    return dict(row) if row else {}
