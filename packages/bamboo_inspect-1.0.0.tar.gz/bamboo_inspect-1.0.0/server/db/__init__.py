"""Database sub-package for Bamboo Inspect Core Manager.

Runtime database queries use asyncpg (async PostgreSQL driver) with raw SQL.
Schema migrations are managed by bamboo-database (bamboodb CLI).
No ORM — all queries are parameterized raw SQL defined in queries.py.
"""
