/**
 * Bamboo Inspect Core Manager - Application Logic
 */

// --- State Management ---
const state = {
    agents: [],
    tasks: [],
    repos: [],
    tests: [],
    webhooks: [],
    stats: { agents: 0, online: 0, busy: 0, offline: 0 },
    activeTab: 'agents',
    loading: { agents: false, tasks: false, repos: false, tests: false, webhooks: false },

    // Assign Modal State
    assign: {
        selectedAgent: '',
        allTests: [],
        filterRepo: '',
        filterModule: '',
        filterType: ''
    }
};

const API_BASE = '/api/admin';

// --- API Wrapper ---
async function apiCall(endpoint, options = {}) {
    const token = localStorage.getItem('bambooinspect_jwt');
    if (!token) {
        window.location.href = '/login.html';
        return null;
    }

    const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...options.headers
    };

    try {
        // Determine full URL (some endpoints might be absolute or relative)
        const url = endpoint.startsWith('/') ? endpoint : `${API_BASE}/${endpoint}`;

        const response = await fetch(url, { ...options, headers });

        if (response.status === 401) {
            localStorage.removeItem('bambooinspect_jwt');
            window.location.href = '/login.html';
            return null;
        }

        if (!response.ok) {
            // Try to parse error message
            let msg = response.statusText;
            try {
                const errData = await response.json();
                if (errData.detail) msg = errData.detail;
            } catch (e) { }
            throw new Error(msg);
        }

        // Return null for 204 No Content
        if (response.status === 204) return null;

        return await response.json();
    } catch (error) {
        console.error('API Call Failed:', error);
        showToast(error.message, 'error');
        throw error;
    }
}

// --- UI Rendering ---
function render() {
    renderStats();
    renderActiveSection();
}

function renderStats() {
    document.getElementById('statAgents').textContent = state.stats.agents;
    document.getElementById('statOnline').textContent = state.stats.online;
    document.getElementById('statBusy').textContent = state.stats.busy;
    document.getElementById('statOffline').textContent = state.stats.offline;
}

function renderActiveSection() {
    // Hide all sections
    document.querySelectorAll('.section').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));

    // Activate current
    const activeSection = document.getElementById(`sec-${state.activeTab}`);
    if (activeSection) {
        activeSection.classList.add('active');

        // Find tab connecting to this hash
        const tabLink = document.querySelector(`.tab[href="#${state.activeTab}"]`);
        if (tabLink) tabLink.classList.add('active');
    }

    // Load data if needed
    loadSectionData(state.activeTab);
}

// --- Data Loading & Rendering (Per Section) ---

async function loadSectionData(section) {
    if (state.loading[section]) return;

    const container = document.getElementById(`${section}Table`);
    if (!container) return;

    renderLoading(container);
    state.loading[section] = true;

    try {
        let data;
        switch (section) {
            case 'agents':
                data = await apiCall(`${API_BASE}/agents`);
                state.agents = data || [];
                updateStatsFromAgents();
                renderAgents(state.agents, container);
                break;
            case 'tasks':
                data = await apiCall(`${API_BASE}/tasks`);
                state.tasks = data || [];
                renderTasks(state.tasks, container);
                break;
            case 'repos':
                data = await apiCall(`${API_BASE}/repos`);
                state.repos = data || [];
                renderRepos(state.repos, container);
                break;
            case 'tests':
                data = await apiCall(`${API_BASE}/tests`);
                state.tests = data || [];
                renderTests(state.tests, container);
                break;
            case 'webhooks':
                data = await apiCall(`${API_BASE}/webhooks`);
                state.webhooks = data || [];
                renderWebhooks(state.webhooks, container);
                break;
        }
    } catch (e) {
        renderError(container, e.message);
    } finally {
        state.loading[section] = false;
    }
}

function updateStatsFromAgents() {
    state.stats.agents = state.agents.length;
    state.stats.online = state.agents.filter(a => a.status === 'idle' || a.status === 'online').length;
    state.stats.busy = state.agents.filter(a => a.status === 'busy' || a.status === 'running').length;
    state.stats.offline = state.agents.filter(a => a.status === 'offline').length;
    renderStats();
}

// --- Render Helpers ---

function renderLoading(container) {
    container.innerHTML = `<tr><td colspan="100%" class="text-center" style="padding: 40px;"><div class="text-muted">Loading data...</div></td></tr>`;
}

function renderError(container, msg) {
    container.innerHTML = `<tr><td colspan="100%" class="text-center" style="padding: 40px;"><div style="color:var(--danger)">Error: ${msg}</div></td></tr>`;
}

function renderEmpty(container, msg = "No items found") {
    container.innerHTML = `<tr><td colspan="100%" class="empty">${msg}</td></tr>`;
}

function renderAgents(agents, container) {
    if (!agents || agents.length === 0) return renderEmpty(container, "No agents registered");

    container.innerHTML = agents.map(agent => {
        let labels = agent.labels;
        if (typeof labels === 'string') {
            try { labels = JSON.parse(labels); } catch (e) { labels = []; }
        }
        if (!Array.isArray(labels)) labels = [];

        let osInfo = agent.os_info;
        if (typeof osInfo === 'string') {
            try { osInfo = JSON.parse(osInfo); } catch (e) { }
        }

        let osName = 'Unknown';
        if (osInfo) {
            if (osInfo.name) {
                osName = osInfo.name;
            } else if (osInfo.platform) {
                osName = `${osInfo.platform} ${osInfo.architecture || ''}`;
            } else if (typeof osInfo === 'string') {
                osName = osInfo;
            }
        }

        return `
    <tr>
      <td><span class="badge ${getStatusClass(agent.status)}">${agent.status}</span></td>
      <td style="font-weight:600">${agent.name}</td>
      <td>${labels.map(l => `<span style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px;font-size:11px;margin-right:4px">${l}</span>`).join('')}</td>
      <td style="color:var(--text-muted)">${osName}</td>
      <td style="font-family:var(--font-mono);font-size:12px;color:var(--text-muted)">${timeAgo(agent.last_heartbeat_at)}</td>
      <td>
        <button class="btn btn-sm btn-danger" onclick="deleteAgent('${agent.id}', '${agent.name}')">Delete</button>
      </td>
    </tr>
  `;
    }).join('');
}

function renderTasks(tasks, container) {
    if (!tasks || tasks.length === 0) return renderEmpty(container, "No active tasks");

    container.innerHTML = tasks.map(task => `
    <tr>
      <td style="font-family:var(--font-mono);font-size:12px">${task.id.slice(0, 8)}</td>
      <td>${task.test_name}</td>
      <td>${task.agent_name || '<span class="text-muted">Unassigned</span>'}</td>
      <td><span class="badge ${getStatusClass(task.status)}">${task.status}</span></td>
      <td style="font-family:var(--font-mono);font-size:12px">${task.duration ? task.duration + 's' : '-'}</td>
      <td>
        <button class="btn btn-sm" onclick="viewLogs('${task.id}')">Logs</button>
      </td>
    </tr>
  `).join('');
}

function renderRepos(repos, container) {
    if (!repos || repos.length === 0) return renderEmpty(container, "No repositories added");

    container.innerHTML = repos.map(repo => `
      <tr>
        <td style="font-weight:600">${repo.name}</td>
        <td style="color:var(--text-muted);font-size:12px">${repo.path}</td>
        <td>${repo.git_remote_url ? `<a href="${repo.git_remote_url}" target="_blank" style="color:var(--accent-color)">Link</a>` : '-'}</td>
        <td style="font-family:var(--font-mono);font-size:12px">${timeAgo(repo.last_scan_at)}</td>
        <td>
           <button class="btn btn-sm btn-danger" onclick="deleteRepo('${repo.name}')">Remove</button>
        </td>
      </tr>
    `).join('');
}

function renderTests(tests, container) {
    if (!tests || tests.length === 0) return renderEmpty(container, "No tests discovered");

    container.innerHTML = tests.map(test => `
        <tr>
            <td style="font-weight:600">${test.name}</td>
            <td>${test.module_name || '-'}</td>
            <td><span class="badge neutral">${test.type}</span></td>
            <td style="color:var(--text-muted);font-size:12px">${test.path || '-'}</td>
        </tr>
    `).join('');
}

function renderWebhooks(items, container) {
    if (!items || items.length === 0) return renderEmpty(container, "No webhooks configured");

    container.innerHTML = items.map(wh => `
        <tr>
            <td style="font-family:var(--font-mono);font-size:12px">${wh.id.slice(0, 8)}</td>
            <td style="word-break:break-all;font-size:12px">${wh.url}</td>
            <td>${wh.active ? '<span style="color:var(--success)">Active</span>' : '<span style="color:var(--text-muted)">Inactive</span>'}</td>
            <td>${wh.retry_count}</td>
            <td>
                 <button class="btn btn-sm btn-danger" onclick="deleteWebhook('${wh.id}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

// --- Utilities ---

function getStatusClass(status) {
    switch (status) {
        case 'idle': case 'online': case 'passed': return 'success';
        case 'busy': case 'running': return 'warning';
        case 'offline': case 'failed': return 'danger';
        case 'pending': return 'info';
        default: return 'neutral';
    }
}

function timeAgo(dateString) {
    if (!dateString) return 'never';
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);

    if (isNaN(seconds)) return 'never';

    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return Math.floor(seconds) + "s ago";
}

function showToast(msg, type = 'info') {
    alert(msg); // Use alert for now
}

// --- Actions (Global Action Handlers) ---

window.deleteAgent = async (id, name) => {
    if (!confirm(`Delete agent ${name}?`)) return;
    await apiCall(`${API_BASE}/agents/${id}`, { method: 'DELETE' });
    loadSectionData('agents');
};

window.addRepo = async (e) => {
    e.preventDefault();
    const name = document.getElementById('newRepoName').value;
    const path = document.getElementById('newRepoPath').value;
    const url = document.getElementById('newRepoUrl').value;

    // Note: Core Manager API for adding repo? 
    // Actually, `admin_routes.py` DOES NOT have an endpoint to ADD a repo!
    // It only has `list_repos` and `remove_repo`.
    // The comments in `admin_routes.py` say: "Agents scan repos locally and push test structure via the agent API."
    // So we CANNOT add a repo from the UI directly if we follow the "Pull-Based Model"?
    // OR we can trigger a sync?
    // Wait, the previous `index.html` had an "Add Repository" button.
    // If the endpoint doesn't exist, we can't implement it.
    // Let's check `agent_routes.py`: `@router.post("/sync-repo")` is for agents.
    // So... "Add Repository" might be a misunderstanding of the architecture.
    // However, if we want to "register" a repo so agents know what to scan?
    // No, agents report what they found.
    // I will disable "Add Repository" or show a message explaining how to add.
    alert("To add a repository, configure your Agent to scan it. The agent will push the repository metadata to the Core Manager.");
    hideModal('addRepoModal');
};

window.deleteRepo = async (name) => {
    if (!confirm(`Remove repository ${name}?`)) return;
    await apiCall(`${API_BASE}/repos/${name}`, { method: 'DELETE' });
    loadSectionData('repos');
};

window.addWebhook = async (e) => {
    e.preventDefault();
    const url = document.getElementById('newWebhookUrl').value;
    await apiCall(`${API_BASE}/webhooks`, {
        method: 'POST',
        body: JSON.stringify({ url, active: true, events: ['*'] })
    });
    hideModal('addWebhookModal');
    loadSectionData('webhooks');
};

window.deleteWebhook = async (id) => {
    if (!confirm("Delete webhook?")) return;
    await apiCall(`${API_BASE}/webhooks/${id}`, { method: 'DELETE' });
    loadSectionData('webhooks');
};

window.generateToken = async () => {
    const desc = document.getElementById('tokenDesc').value;
    const data = await apiCall(`${API_BASE}/registration-tokens`, {
        method: 'POST',
        body: JSON.stringify({ description: desc })
    });
    if (data) {
        document.getElementById('tokenValue').textContent = data.token;
        document.getElementById('tokenResult').classList.remove('hidden');
        document.getElementById('tokenResult').style.display = 'block'; // Override if style.display used
        document.getElementById('tokenGenBtn').classList.add('hidden');
        document.getElementById('tokenGenBtn').style.display = 'none';
    }
};

window.viewLogs = async (id) => {
    // Show modal first
    document.getElementById('logsModal').classList.add('show');
    const content = document.getElementById('logContent');
    content.textContent = "Loading logs...";

    // admin_routes.py doesn't have a direct "get logs" endpoint for a task that returns simple text?
    // `executions/{id}` returns the row. `row` has `logs` column.

    const data = await apiCall(`${API_BASE}/executions/${id}`);
    if (data) {
        content.textContent = data.logs || "No logs available.";
    } else {
        content.textContent = "Failed to load logs.";
    }
};

// --- Assignment Logic ---

window.populateAgentDropdown = async () => {
    const agents = await apiCall(`${API_BASE}/agents`);
    const select = document.getElementById('assignAgent');
    select.innerHTML = '<option value="">Select an agent...</option>';
    (agents || []).forEach(a => {
        const opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = `${a.name} (${a.status})`;
        select.appendChild(opt);
    });
};

window.loadTests = async () => {
    state.assign.allTests = await apiCall(`${API_BASE}/tests`) || [];
};

window.populateAssignFilters = () => {
    const repos = [...new Set(state.assign.allTests.map(t => t.project_name))].filter(Boolean);
    const modules = [...new Set(state.assign.allTests.map(t => t.module_name))].filter(Boolean);
    const types = [...new Set(state.assign.allTests.map(t => t.type))].filter(Boolean);

    fillSelect('assignFilterRepo', repos, 'All repos');
    fillSelect('assignFilterModule', modules, 'All modules');
    fillSelect('assignFilterType', types, 'All types');
};

function fillSelect(id, items, defaultText) {
    const el = document.getElementById(id);
    el.innerHTML = `<option value="">${defaultText}</option>` +
        items.map(i => `<option value="${i}">${i}</option>`).join('');
}

window.assignFiltersChanged = () => {
    state.assign.filterRepo = document.getElementById('assignFilterRepo').value;
    state.assign.filterModule = document.getElementById('assignFilterModule').value;
    state.assign.filterType = document.getElementById('assignFilterType').value;
    window.populateTestSelect();
}

window.populateTestSelect = () => {
    const filtered = state.assign.allTests.filter(t => {
        if (state.assign.filterRepo && t.project_name !== state.assign.filterRepo) return false;
        if (state.assign.filterModule && t.module_name !== state.assign.filterModule) return false;
        if (state.assign.filterType && t.type !== state.assign.filterType) return false;
        return true;
    });

    const select = document.getElementById('assignTests');
    select.innerHTML = filtered.map(t => `<option value="${t.id}">${t.project_name} / ${t.name}</option>`).join('');
};

window.assignTestsSelectAll = () => {
    const select = document.getElementById('assignTests');
    for (let i = 0; i < select.options.length; i++) select.options[i].selected = true;
};

window.assignTestsClear = () => {
    const select = document.getElementById('assignTests');
    select.selectedIndex = -1;
};

window.assignTask = async () => {
    const agentId = document.getElementById('assignAgent').value;
    const select = document.getElementById('assignTests');
    const selectedTests = Array.from(select.selectedOptions).map(o => o.value);

    if (!agentId) { alert("Please select an agent"); return; }
    if (selectedTests.length === 0) { alert("Please select at least one test"); return; }

    await apiCall(`${API_BASE}/tasks`, {
        method: 'POST',
        body: JSON.stringify({ agent_id: agentId, test_ids: selectedTests })
    });

    alert("Tests assigned successfully");
    hideModal('assignModal');
    loadSectionData('tasks');
};


// --- Event Listeners ---

window.addEventListener('hashchange', () => {
    const hash = window.location.hash.slice(1);
    state.activeTab = hash || 'agents';
    render();
});

// --- Modal Logic ---

window.showModal = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add('show');

    // Reset states if needed
    if (id === 'tokenModal') {
        document.getElementById('tokenResult').classList.add('hidden');
        document.getElementById('tokenGenBtn').classList.remove('hidden');
        document.getElementById('tokenGenBtn').style.display = 'block'; // Reset display
        document.getElementById('tokenResult').style.display = 'none';
        document.getElementById('tokenDesc').value = '';
    }

    // Load data for assign modal
    if (id === 'assignModal') {
        window.populateAgentDropdown();
        if (state.assign.allTests.length === 0) window.loadTests().then(() => {
            window.populateAssignFilters();
            window.populateTestSelect();
        });
    }
};

window.hideModal = (id) => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('show');
};

// --- Init ---
window.addEventListener('DOMContentLoaded', () => {
    // Check auth first
    const token = localStorage.getItem('bambooinspect_jwt');
    if (!token) {
        window.location.href = '/login.html';
        return;
    }

    // Load initial hash
    const hash = window.location.hash.slice(1);
    state.activeTab = hash || 'agents';
    render();
});
