/**
 * Bamboo Inspect Core Manager - Authentication Logic
 */

async function handleLogin(e) {
    e.preventDefault();

    const btn = document.getElementById('loginBtn');
    const errEl = document.getElementById('errorMsg');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');

    // Reset UI
    errEl.style.display = 'none';
    btn.disabled = true;
    btn.textContent = 'Signing in...';

    const username = usernameInput.value;
    const password = passwordInput.value;

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('bambooinspect_jwt', data.access_token);
            window.location.href = '/';
        } else {
            const errorData = await response.json().catch(() => null);
            showError(errEl, (errorData && errorData.detail) || 'Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        showError(errEl, 'Connection error. Please check your network.');
    } finally {
        btn.disabled = false;
        btn.textContent = 'Sign In';
    }

    return false;
}

function showError(el, msg) {
    el.textContent = msg;
    el.style.display = 'block';
    // Add shake animation class if we had one
}

function logout() {
    localStorage.removeItem('bambooinspect_jwt');
    window.location.href = '/login.html';
}

// Redirect if already logged in (for login page)
function checkAlreadyLoggedIn() {
    const token = localStorage.getItem('bambooinspect_jwt');
    if (token) {
        // Ideally verify token with backend, but for speed, if it exists, try to go home
        // The home page will kick back if invalid
        window.location.href = '/';
    }
}

// Attach to window for HTML access
window.handleLogin = handleLogin;
window.logout = logout;
window.checkAlreadyLoggedIn = checkAlreadyLoggedIn;
