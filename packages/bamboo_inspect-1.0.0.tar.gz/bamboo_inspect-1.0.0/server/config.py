"""Core Manager configuration.

Loads configuration from environment variables (Docker-standard).
All settings have sensible defaults.
"""

import os
from dataclasses import dataclass


@dataclass
class ServerConfig:
    """Core Manager server configuration loaded from environment variables."""

    # Database
    db_host: str = "localhost"
    db_port: int = 5432
    db_name: str = "bamboo_inspect"
    db_user: str = "postgres"
    db_password: str = "postgres"

    # Server
    port: int = 8686
    host: str = "0.0.0.0"

    # Access control
    access_mode: str = "lan"  # local / lan / public
    auth_token: str = ""

    # Agent health
    agent_offline_threshold: int = 90  # seconds

    # JWT authentication
    jwt_secret: str = ""
    jwt_expiry_minutes: int = 720  # 12 hours


def load_server_config() -> ServerConfig:
    """Load configuration from BAMBOOINSPECT_* environment variables."""
    return ServerConfig(
        db_host=os.environ.get("BAMBOOINSPECT_DB_HOST", "localhost"),
        db_port=int(os.environ.get("BAMBOOINSPECT_DB_PORT", "5432")),
        db_name=os.environ.get("BAMBOOINSPECT_DB_NAME", "bamboo_inspect"),
        db_user=os.environ.get("BAMBOOINSPECT_DB_USER", "postgres"),
        db_password=os.environ.get("BAMBOOINSPECT_DB_PASSWORD", "postgres"),
        port=int(os.environ.get("BAMBOOINSPECT_PORT", "8686")),
        host=os.environ.get("BAMBOOINSPECT_HOST", "0.0.0.0"),
        access_mode=os.environ.get("BAMBOOINSPECT_ACCESS_MODE", "lan"),
        auth_token=os.environ.get("BAMBOOINSPECT_AUTH_TOKEN", ""),
        agent_offline_threshold=int(os.environ.get("BAMBOOINSPECT_AGENT_OFFLINE_THRESHOLD", "90")),
        jwt_secret=os.environ.get("BAMBOOINSPECT_JWT_SECRET", ""),
        jwt_expiry_minutes=int(os.environ.get("BAMBOOINSPECT_JWT_EXPIRY_MINUTES", "720")),
    )
