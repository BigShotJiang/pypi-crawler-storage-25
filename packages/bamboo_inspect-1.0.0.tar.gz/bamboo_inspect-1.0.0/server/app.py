"""Core Manager FastAPI application.

Mounts all API route modules, serves the web dashboard,
and manages the heartbeat monitor background task.
"""

import asyncio
import logging
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

import asyncpg
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from server.api.admin_routes import router as admin_router
from server.api.agent_routes import router as agent_router
from server.api.auth_jwt import router as auth_router
from server.api.git_hook import router as git_hook_router
from server.services.heartbeat_monitor import start_heartbeat_monitor

logger = logging.getLogger("core-manager")

_STATIC_DIR = Path(__file__).parent / "web" / "static"


def create_app(
    pool: Optional[asyncpg.Pool] = None,
    offline_threshold: int = 90,
    jwt_secret: str = "",
    jwt_expiry_minutes: int = 720,
) -> FastAPI:
    """Create and configure the Core Manager FastAPI application.

    Args:
        pool: An asyncpg connection pool.
        offline_threshold: Seconds before marking agent offline.
        jwt_secret: HS256 secret for JWT signing. Generated randomly if empty.
        jwt_expiry_minutes: JWT token lifetime in minutes.

    Returns:
        A configured FastAPI instance.
    """

    # Resolve JWT secret
    if not jwt_secret:
        jwt_secret = secrets.token_hex(32)
        logger.warning(
            "BAMBOOINSPECT_JWT_SECRET not set — using random secret. "
            "JWT tokens will not survive server restarts."
        )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Start heartbeat monitor background task
        if app.state.pool:
            task = asyncio.create_task(
                start_heartbeat_monitor(
                    app.state.pool,
                    offline_threshold_seconds=offline_threshold,
                )
            )
            app.state.heartbeat_task = task
        yield
        # Cleanup
        if hasattr(app.state, "heartbeat_task"):
            app.state.heartbeat_task.cancel()
            try:
                await app.state.heartbeat_task
            except asyncio.CancelledError:
                pass

    app = FastAPI(
        title="Bamboo Inspect Core Manager",
        description="Central management server for Bamboo Inspect agents and test execution",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Store pool in app state
    app.state.pool = pool

    # Store JWT config in app state for auth dependencies
    app.state.jwt_secret = jwt_secret
    app.state.jwt_expiry_minutes = jwt_expiry_minutes

    # Health check
    @app.get("/api/health")
    async def health_check() -> dict[str, str]:
        return {"status": "ok", "component": "core-manager"}

    # Mount API routers
    app.include_router(auth_router)
    app.include_router(agent_router)
    app.include_router(admin_router)
    app.include_router(git_hook_router)

    # Serve static dashboard files
    if _STATIC_DIR.is_dir():
        app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")

    return app
