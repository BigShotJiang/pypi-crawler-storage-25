"""Agent lifecycle management for Core Manager.

Handles registration token generation, agent registration flow,
persistent token generation, and agent removal.
"""

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import asyncpg

from server.db import queries


def _hash_token(token: str) -> str:
    """Hash a token using SHA-256."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _generate_id(prefix: str) -> str:
    """Generate a unique 16-char hex ID."""
    return hashlib.sha256(
        f"{prefix}:{secrets.token_hex(16)}:{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]


async def create_registration_token(
    pool: asyncpg.Pool,
    description: Optional[str] = None,
    expires_in_minutes: int = 60,
) -> dict[str, Any]:
    """Generate a new registration token.

    Returns:
        Dict with ``id``, ``token`` (plaintext, shown once), ``expires_at``.
    """
    plaintext = secrets.token_urlsafe(32)
    token_hash = _hash_token(plaintext)
    token_id = _generate_id("reg_token")
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=expires_in_minutes)

    await queries.insert_registration_token(
        pool, token_id, token_hash,
        description=description,
        expires_at=expires_at,
    )

    return {
        "id": token_id,
        "token": plaintext,
        "expires_at": expires_at.isoformat(),
    }


async def register_agent(
    pool: asyncpg.Pool,
    registration_token: str,
    name: str,
    labels: list[str],
    os_info: Optional[dict] = None,
    metadata: Optional[dict] = None,
) -> dict[str, Any]:
    """Register a new agent using a registration token.

    Returns:
        Dict with ``agent_id``, ``agent_token`` (persistent, plaintext), ``name``.

    Raises:
        ValueError: If the token is invalid, expired, used, or the name is taken.
    """
    token_hash = _hash_token(registration_token)
    token_record = await queries.get_registration_token_by_hash(pool, token_hash)

    if not token_record:
        raise ValueError("Invalid registration token")

    if token_record.get("used"):
        raise ValueError("Registration token has already been used")

    expires_at = token_record.get("expires_at")
    if expires_at and datetime.now(timezone.utc) > expires_at:
        raise ValueError("Registration token has expired")

    # Check name uniqueness
    existing = await queries.get_agent_by_name(pool, name)
    if existing:
        raise ValueError(f"Agent name '{name}' is already taken")

    # Generate persistent agent token
    agent_token = secrets.token_urlsafe(48)
    agent_token_hash = _hash_token(agent_token)
    agent_id = _generate_id("agent")

    # Create agent record
    await queries.insert_agent(
        pool, agent_id, name, labels,
        status="idle",
        token_hash=agent_token_hash,
        os_info=os_info,
        metadata=metadata,
    )

    # Update heartbeat immediately
    await queries.update_agent_heartbeat(pool, agent_id)

    # Mark registration token as used
    await queries.mark_registration_token_used(pool, token_record["id"], agent_id)

    return {
        "agent_id": agent_id,
        "agent_token": agent_token,
        "name": name,
    }


async def remove_agent(pool: asyncpg.Pool, agent_id: str) -> None:
    """Remove an agent and cancel its pending tasks.

    Raises:
        ValueError: If the agent is not found.
    """
    agent = await queries.get_agent_by_id(pool, agent_id)
    if not agent:
        raise ValueError(f"Agent '{agent_id}' not found")

    # Cancel pending executions for this agent
    await pool.execute(
        "UPDATE execution SET status = 'cancelled' WHERE agent_id = $1 AND status = 'pending'",
        agent_id,
    )

    await queries.delete_agent(pool, agent_id)


async def authenticate_agent(pool: asyncpg.Pool, token: str) -> Optional[dict[str, Any]]:
    """Authenticate an agent by its persistent token.

    Returns:
        The agent record if valid, None otherwise.
    """
    token_hash = _hash_token(token)
    return await queries.get_agent_by_token_hash(pool, token_hash)
