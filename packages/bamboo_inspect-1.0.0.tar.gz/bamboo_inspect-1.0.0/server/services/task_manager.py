"""Task assignment and management for Core Manager.

Creates task assignments (RunSession + Execution records with agent_id),
handles task cancellation, and manages task lifecycle.
"""

import hashlib
import secrets
from datetime import datetime, timezone
from typing import Any, Optional

import asyncpg

from server.db import queries


def _generate_id(prefix: str) -> str:
    """Generate a unique 16-char hex ID."""
    return hashlib.sha256(
        f"{prefix}:{secrets.token_hex(16)}:{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]


async def assign_tasks(
    pool: asyncpg.Pool,
    agent_id: str,
    test_ids: list[str],
    tracking: str = "session",
    triggered_by: str = "manual",
) -> dict[str, Any]:
    """Assign tests to an agent for execution.

    Creates a RunSession and Execution records assigned to the agent.

    Returns:
        Dict with session_id and execution_ids.

    Raises:
        ValueError: If the agent is not found or is offline.
    """
    agent = await queries.get_agent_by_id(pool, agent_id)
    if not agent:
        raise ValueError(f"Agent '{agent_id}' not found")
    if agent.get("status") == "offline":
        raise ValueError(f"Agent '{agent.get('name', agent_id)}' is offline")

    # Find the project for the first test to create a session
    first_test = await queries.get_test_by_id(pool, test_ids[0])
    if not first_test:
        raise ValueError(f"Test '{test_ids[0]}' not found")

    # Get module to find project
    module_id = first_test["module_id"]
    # Find project via module
    row = await pool.fetchrow("SELECT project_id FROM module WHERE id = $1", module_id)
    if not row:
        raise ValueError(f"Module for test '{test_ids[0]}' not found")
    project_id = row["project_id"]

    session_id = _generate_id("run_session")
    execution_ids = []

    if tracking in ("session", "full"):
        await queries.insert_run_session(
            pool, session_id, project_id,
            tracking_level=tracking,
            status="pending",
            triggered_by=triggered_by,
            agent_id=agent_id,
        )

    for test_id in test_ids:
        exec_id = _generate_id("execution")
        await queries.insert_execution(
            pool, exec_id, test_id,
            status="pending",
            session_id=session_id if tracking in ("session", "full") else None,
            triggered_by=triggered_by,
            agent_id=agent_id,
        )
        execution_ids.append(exec_id)

    return {
        "session_id": session_id,
        "execution_ids": execution_ids,
        "agent_id": agent_id,
        "total_tests": len(test_ids),
    }


async def cancel_task(pool: asyncpg.Pool, execution_id: str) -> None:
    """Cancel a pending or running task.

    Raises:
        ValueError: If the execution is not found.
    """
    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        raise ValueError(f"Execution '{execution_id}' not found")

    if execution["status"] in ("pending", "running"):
        await queries.update_execution(pool, execution_id, status="cancelled")


async def get_task_details(
    pool: asyncpg.Pool, execution_id: str,
) -> Optional[dict[str, Any]]:
    """Get full task details for an execution, including test and project info.

    Returns:
        Dict with execution, test, module, and project information.
    """
    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        return None

    test = await queries.get_test_by_id(pool, execution["test_id"])
    if not test:
        return None

    # Get module and project path
    row = await pool.fetchrow(
        "SELECT m.name as module_name, p.path as project_path "
        "FROM module m JOIN project p ON m.project_id = p.id "
        "WHERE m.id = $1",
        test["module_id"],
    )

    return {
        "execution_id": execution_id,
        "test_id": test["id"],
        "test_name": test["name"],
        "test_type": test["type"],
        "test_path": test["path"],
        "timeout": test.get("timeout"),
        "retry_count": test.get("retry_count", 0),
        "module_name": row["module_name"] if row else "",
        "project_path": row["project_path"] if row else "",
    }


async def submit_result(
    pool: asyncpg.Pool,
    execution_id: str,
    status: str,
    duration: Optional[int] = None,
    error_message: Optional[str] = None,
    logs: Optional[str] = None,
    artifacts: Optional[dict] = None,
) -> None:
    """Process an execution result submitted by an agent.

    Updates the execution record and RunSession aggregates.
    """
    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        raise ValueError(f"Execution '{execution_id}' not found")

    await queries.update_execution(
        pool, execution_id,
        status=status,
        duration=duration,
        error_message=error_message,
        logs=logs,
        artifacts=artifacts,
    )

    # Update RunSession aggregates if applicable
    session_id = execution.get("session_id")
    if session_id:
        session = await queries.get_run_session(pool, session_id)
        if session:
            # Recount from all executions in the session
            execs = await queries.list_executions_by_session(pool, session_id)
            total = len(execs)
            passed = sum(1 for e in execs if e["status"] == "passed")
            failed = sum(1 for e in execs if e["status"] == "failed")
            pending = sum(1 for e in execs if e["status"] in ("pending", "running"))

            if pending == 0:
                final_status = "passed" if failed == 0 else "failed"
                await queries.update_run_session(
                    pool, session_id,
                    status=final_status,
                    total_tests=total,
                    passed=passed,
                    failed=failed,
                )
            else:
                # Still in progress, update counts
                await pool.execute(
                    (
                        "UPDATE run_session SET status = 'running', total_tests = $1, "
                        "passed = $2, failed = $3 WHERE id = $4"
                    ),
                    total,
                    passed,
                    failed,
                    session_id,
                )

    # Dispatch webhooks
    await _dispatch_result_webhooks(
        pool, execution_id,
        test_id=execution.get("test_id", ""),
        status=status,
        duration=duration,
        error_message=error_message,
        logs=logs,
        artifacts=artifacts,
    )


async def _dispatch_result_webhooks(
    pool: asyncpg.Pool,
    execution_id: str,
    *,
    test_id: str = "",
    status: str = "",
    duration: Optional[int] = None,
    error_message: Optional[str] = None,
    logs: Optional[str] = None,
    artifacts: Optional[dict] = None,
) -> None:
    """Fire outgoing webhooks for an execution result."""
    import asyncio as _asyncio

    from server.services.webhook_dispatcher import dispatch_webhook

    active_hooks = await queries.list_active_webhooks(pool)
    for hook in active_hooks:
        payload = {
            "execution_id": execution_id,
            "test_id": test_id,
            "status": status,
            "duration": duration or 0,
            "error": error_message,
            "logs": logs or "",
            "artifacts": artifacts or {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        _asyncio.create_task(dispatch_webhook(
            hook["url"], payload,
            headers=hook.get("headers") if isinstance(hook.get("headers"), dict) else None,
            auth_type=hook.get("auth_type"),
            auth_config=hook.get("auth_config") if isinstance(hook.get("auth_config"), dict) else None,
            retry_count=hook.get("retry_count", 3),
        ))


def _deterministic_id(value: str) -> str:
    """Return a deterministic 16-char hex ID from *value*."""
    return hashlib.sha256(value.encode()).hexdigest()[:16]


async def report_run(
    pool: asyncpg.Pool,
    agent_id: str,
    project_name: str,
    project_path: str,
    results: list[dict[str, Any]],
    tracking: str = "session",
) -> dict[str, Any]:
    """Accept completed CLI test results and persist them on the Core Manager.

    Creates/upserts project, module, and test records, then creates a
    RunSession and Execution records with the submitted result data.

    Returns:
        Dict with session_id, execution_ids, and total_tests.

    Raises:
        ValueError: If results is empty or agent is not found.
    """
    if not results:
        raise ValueError("No results to report")

    agent = await queries.get_agent_by_id(pool, agent_id)
    if not agent:
        raise ValueError(f"Agent '{agent_id}' not found")

    # --- Upsert project ------------------------------------------------
    project_id = _deterministic_id(f"project:{project_name}:{agent_id}")
    existing_project = await queries.get_project_by_name(pool, project_name)
    if existing_project:
        project_id = existing_project["id"]
    else:
        await queries.insert_project(pool, project_id, project_name, project_path)

    # --- Collect unique modules and upsert -----------------------------
    module_names: set[str] = {r.get("module", "") for r in results}
    module_id_map: dict[str, str] = {}
    for mod_name in module_names:
        mod_id = _deterministic_id(f"module:{project_id}:{mod_name}")
        # Check if already exists
        existing_mod = await pool.fetchrow(
            "SELECT id FROM module WHERE id = $1", mod_id,
        )
        if not existing_mod:
            try:
                await queries.insert_module(pool, mod_id, project_id, mod_name, "")
            except Exception:
                # Race condition or duplicate — safe to ignore
                pass
        module_id_map[mod_name] = mod_id

    # --- Upsert test records and build test_id list --------------------
    test_ids: list[str] = []
    for r in results:
        mod_name = r.get("module", "")
        mod_id = module_id_map[mod_name]
        test_name = r.get("test_name", "")
        test_type = r.get("test_type", "script")
        test_id = _deterministic_id(f"test:{mod_id}:{test_name}:{test_type}")

        existing_test = await queries.get_test_by_id(pool, test_id)
        if not existing_test:
            try:
                await queries.insert_test(
                    pool, test_id, mod_id, test_name, test_type,
                    r.get("test_path", ""),
                )
            except Exception:
                pass
        test_ids.append(test_id)

    # --- Create RunSession ---------------------------------------------
    session_id = _generate_id("run_session")
    passed = sum(1 for r in results if r.get("status") == "passed")
    failed = len(results) - passed
    final_status = "passed" if failed == 0 else "failed"

    if tracking in ("session", "full"):
        await queries.insert_run_session(
            pool, session_id, project_id,
            tracking_level=tracking,
            status=final_status,
            triggered_by="cli",
            agent_id=agent_id,
        )
        await queries.update_run_session(
            pool, session_id,
            status=final_status,
            total_tests=len(results),
            passed=passed,
            failed=failed,
        )

    # --- Create Execution records with completed results ----------------
    execution_ids: list[str] = []
    for i, r in enumerate(results):
        exec_id = _generate_id("execution")
        await queries.insert_execution(
            pool, exec_id, test_ids[i],
            status=r.get("status", "failed"),
            session_id=session_id if tracking in ("session", "full") else None,
            triggered_by="cli",
            agent_id=agent_id,
        )
        await queries.update_execution(
            pool, exec_id,
            status=r.get("status", "failed"),
            duration=r.get("duration"),
            error_message=r.get("error_message"),
            logs=r.get("logs"),
        )
        execution_ids.append(exec_id)

        # Trigger webhooks per execution
        await _dispatch_result_webhooks(
            pool, exec_id,
            test_id=test_ids[i],
            status=r.get("status", "failed"),
            duration=r.get("duration"),
            error_message=r.get("error_message"),
            logs=r.get("logs"),
        )

    return {
        "session_id": session_id,
        "execution_ids": execution_ids,
        "total_tests": len(results),
    }
