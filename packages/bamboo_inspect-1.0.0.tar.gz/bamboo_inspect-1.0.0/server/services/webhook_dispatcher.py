"""Outgoing webhook dispatcher for Core Manager.

Sends test results to registered webhook URLs via HTTP POST using aiohttp.
Supports custom headers, authentication, and retry logic with exponential backoff.
"""

import asyncio
import base64
import logging
from typing import Any, Optional

import aiohttp

logger = logging.getLogger(__name__)


async def dispatch_webhook(
    url: str,
    payload: dict[str, Any],
    *,
    headers: Optional[dict[str, str]] = None,
    auth_type: Optional[str] = None,
    auth_config: Optional[dict[str, str]] = None,
    retry_count: int = 3,
    timeout_seconds: int = 10,
) -> bool:
    """Send a test result payload to a webhook URL.

    Returns:
        ``True`` if the webhook was delivered successfully, ``False`` otherwise.
    """
    req_headers: dict[str, str] = {"Content-Type": "application/json"}

    if headers:
        req_headers.update(headers)

    if auth_type and auth_config:
        if auth_type == "bearer":
            token = auth_config.get("token", "")
            req_headers["Authorization"] = f"Bearer {token}"
        elif auth_type == "basic":
            username = auth_config.get("username", "")
            password = auth_config.get("password", "")
            encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
            req_headers["Authorization"] = f"Basic {encoded}"

    client_timeout = aiohttp.ClientTimeout(total=timeout_seconds)

    for attempt in range(1 + retry_count):
        try:
            async with aiohttp.ClientSession(timeout=client_timeout) as session:
                async with session.post(url, json=payload, headers=req_headers) as resp:
                    if resp.status < 400:
                        logger.debug("Webhook delivered to %s (status %d)", url, resp.status)
                        return True
                    logger.warning(
                        "Webhook to %s returned status %d (attempt %d/%d)",
                        url, resp.status, attempt + 1, 1 + retry_count,
                    )
        except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
            logger.warning(
                "Webhook to %s failed (attempt %d/%d): %s",
                url, attempt + 1, 1 + retry_count, exc,
            )

        if attempt < retry_count:
            await asyncio.sleep(2 ** attempt)

    logger.error("Webhook delivery to %s failed after %d attempts", url, 1 + retry_count)
    return False
