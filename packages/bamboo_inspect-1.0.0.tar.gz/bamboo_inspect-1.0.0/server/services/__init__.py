"""Business logic services for the Core Manager."""
