"""Agent heartbeat monitor for Core Manager.

Runs a periodic background task that checks agent heartbeat timestamps
and marks agents as offline if they exceed the threshold.
Also detects stale running tasks on offline agents.
"""

import asyncio
import logging

import asyncpg

from server.db import queries

logger = logging.getLogger(__name__)


async def check_agent_health(
    pool: asyncpg.Pool,
    offline_threshold_seconds: int = 90,
) -> int:
    """Check all agents and mark stale ones as offline.

    Returns:
        Number of agents marked offline.
    """
    stale_agents = await queries.list_agents_needing_offline(pool, offline_threshold_seconds)
    count = 0

    for agent in stale_agents:
        agent_id = agent["id"]
        agent_name = agent.get("name", agent_id)
        logger.info("Marking agent '%s' as offline (no heartbeat)", agent_name)
        await queries.update_agent_status(pool, agent_id, "offline")
        count += 1

        # Mark stale running tasks as failed
        running_tasks = await queries.list_executions_by_agent(pool, agent_id, status="running")
        for task in running_tasks:
            logger.warning(
                "Marking execution '%s' as failed (agent '%s' offline)",
                task["id"], agent_name,
            )
            await queries.update_execution(
                pool, task["id"],
                status="failed",
                error_message="Agent offline during execution",
            )

    return count


async def start_heartbeat_monitor(
    pool: asyncpg.Pool,
    offline_threshold_seconds: int = 90,
    check_interval_seconds: int = 30,
) -> None:
    """Run the heartbeat monitor loop indefinitely.

    This should be started as a background task.
    """
    logger.info(
        "Heartbeat monitor started (threshold=%ds, interval=%ds)",
        offline_threshold_seconds, check_interval_seconds,
    )
    while True:
        try:
            marked = await check_agent_health(pool, offline_threshold_seconds)
            if marked > 0:
                logger.info("Marked %d agent(s) as offline", marked)
        except Exception:
            logger.exception("Error in heartbeat monitor")
        await asyncio.sleep(check_interval_seconds)
