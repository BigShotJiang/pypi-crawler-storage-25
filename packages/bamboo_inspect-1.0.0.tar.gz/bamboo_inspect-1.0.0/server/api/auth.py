"""Authentication middleware for Core Manager.

Provides two separate auth dependencies:
- get_agent_from_token: Validates agent Bearer tokens against the database.
- get_current_admin_user: Validates JWT Bearer tokens for admin access (DB-backed).
"""

from typing import Any

import jwt
from fastapi import HTTPException, Request, status

from server.api.auth_jwt import decode_access_token
from server.db import queries
from server.services.agent_manager import authenticate_agent


async def get_agent_from_token(request: Request) -> dict[str, Any]:
    """FastAPI dependency that extracts and validates the agent token.

    Returns:
        The agent record dict.

    Raises:
        HTTPException 401 if the token is missing or invalid.
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")

    token = auth_header[7:]  # Strip "Bearer "
    pool = request.app.state.pool

    agent = await authenticate_agent(pool, token)
    if not agent:
        raise HTTPException(status_code=401, detail="Invalid agent token")

    return agent


async def get_current_admin_user(request: Request) -> dict[str, Any]:
    """FastAPI dependency that extracts and validates a JWT for admin access.

    Decodes the JWT, then verifies the user exists and is active in the
    admin_user database table.

    Returns:
        The admin user record dict from the database.

    Raises:
        HTTPException 401 if the JWT is missing, invalid, expired,
        or the user is not found / deactivated.
    """
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header",
        )

    token = auth_header[7:]  # Strip "Bearer "
    jwt_secret: str = request.app.state.jwt_secret

    try:
        payload = decode_access_token(token, jwt_secret)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )

    username = payload.get("sub")
    if not username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    # Verify the user exists and is active in the database
    pool = request.app.state.pool
    user = await queries.get_admin_user_by_username(pool, username)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or deactivated",
        )

    return {"username": user["username"], "id": user["id"]}
