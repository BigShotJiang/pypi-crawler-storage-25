"""Admin management API routes for Core Manager.

Endpoints for managing agents, registration tokens, task assignments,
repositories, tests, webhooks, and configuration.

NOTE: The Core Manager does NOT access git repos or scan filesystems.
Agents scan repos locally and push test structure via the agent API.
Repos/tests are stored as metadata only.
"""

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from server.api.auth import get_current_admin_user
from server.db import queries
from server.services.agent_manager import create_registration_token, remove_agent
from server.services.task_manager import assign_tasks, cancel_task

router = APIRouter(
    prefix="/api/admin",
    tags=["admin"],
    dependencies=[Depends(get_current_admin_user)],
)


# ---------------------------------------------------------------------------
# Agent management
# ---------------------------------------------------------------------------


@router.get("/agents")
async def list_agents(request: Request) -> list[dict[str, Any]]:
    """List all registered agents."""
    pool = request.app.state.pool
    return await queries.list_agents(pool)


@router.get("/agents/{agent_id}")
async def get_agent(request: Request, agent_id: str) -> dict[str, Any]:
    """Get agent details."""
    pool = request.app.state.pool
    agent = await queries.get_agent_by_id(pool, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.patch("/agents/{agent_id}")
async def update_agent(
    request: Request, agent_id: str, body: dict[str, Any],
) -> dict[str, Any]:
    """Update agent properties (labels)."""
    pool = request.app.state.pool
    agent = await queries.get_agent_by_id(pool, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    if "labels" in body:
        await queries.update_agent_labels(pool, agent_id, body["labels"])

    updated = await queries.get_agent_by_id(pool, agent_id)
    return updated or agent


@router.delete("/agents/{agent_id}")
async def delete_agent(request: Request, agent_id: str) -> dict[str, str]:
    """Remove an agent."""
    pool = request.app.state.pool
    try:
        await remove_agent(pool, agent_id)
        return {"status": "removed", "agent_id": agent_id}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ---------------------------------------------------------------------------
# Registration tokens
# ---------------------------------------------------------------------------


@router.post("/registration-tokens")
async def create_token(request: Request, body: dict[str, Any] = {}) -> dict[str, Any]:
    """Generate a new registration token."""
    pool = request.app.state.pool
    result = await create_registration_token(
        pool,
        description=body.get("description"),
        expires_in_minutes=body.get("expires_in_minutes", 60),
    )
    return result


@router.get("/registration-tokens")
async def list_tokens(request: Request) -> list[dict[str, Any]]:
    """List all registration tokens (without plaintext)."""
    pool = request.app.state.pool
    return await queries.list_registration_tokens(pool)


@router.delete("/registration-tokens/{token_id}")
async def delete_token(request: Request, token_id: str) -> dict[str, str]:
    """Revoke a registration token."""
    pool = request.app.state.pool
    await queries.delete_registration_token(pool, token_id)
    return {"status": "revoked", "id": token_id}


# ---------------------------------------------------------------------------
# Task assignment
# ---------------------------------------------------------------------------


@router.post("/tasks")
async def create_task_assignment(
    request: Request, body: dict[str, Any],
) -> dict[str, Any]:
    """Assign tests to an agent for execution."""
    pool = request.app.state.pool
    agent_id = body.get("agent_id")
    test_ids = body.get("test_ids", [])
    tracking = body.get("tracking", "session")

    if not agent_id or not test_ids:
        raise HTTPException(status_code=400, detail="Missing 'agent_id' or 'test_ids'")

    try:
        result = await assign_tasks(pool, agent_id, test_ids, tracking=tracking)
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/tasks")
async def list_tasks(
    request: Request,
    agent_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    limit: int = Query(50),
) -> list[dict[str, Any]]:
    """List tasks, optionally filtered by agent or status."""
    pool = request.app.state.pool
    if agent_id:
        return await queries.list_executions_by_agent(pool, agent_id, status=status, limit=limit)
    if status:
        return await queries.list_executions_by_status(pool, status, limit=limit)
    rows = await pool.fetch(
        "SELECT * FROM execution ORDER BY created_at DESC LIMIT $1", limit,
    )
    return [dict(r) for r in rows]


@router.post("/tasks/{execution_id}/cancel")
async def cancel_execution(
    request: Request, execution_id: str,
) -> dict[str, str]:
    """Cancel a task."""
    pool = request.app.state.pool
    try:
        await cancel_task(pool, execution_id)
        return {"status": "cancelled", "execution_id": execution_id}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ---------------------------------------------------------------------------
# Repository management (metadata only — agents push scan results)
# ---------------------------------------------------------------------------


@router.get("/repos")
async def list_repos(request: Request) -> list[dict[str, Any]]:
    """List all registered repositories."""
    pool = request.app.state.pool
    return await queries.list_projects(pool)


@router.delete("/repos/{name}")
async def remove_repo(request: Request, name: str) -> dict[str, str]:
    """Remove a registered repository and all its modules/tests."""
    pool = request.app.state.pool
    project = await queries.get_project_by_name(pool, name)
    if not project:
        raise HTTPException(status_code=404, detail=f"Repository '{name}' not found")

    pid = project["id"]
    modules = await queries.get_modules_by_project(pool, pid)
    for mod in modules:
        await queries.delete_tests_by_module(pool, mod["id"])
    await queries.delete_modules_by_project(pool, pid)
    await queries.delete_project(pool, pid)
    return {"status": "removed", "name": name}


# ---------------------------------------------------------------------------
# Tests & Executions
# ---------------------------------------------------------------------------


@router.get("/tests")
async def list_tests(
    request: Request,
    project: Optional[str] = Query(None),
    module: Optional[str] = Query(None),
) -> list[dict[str, Any]]:
    """List tests, optionally filtered by project or module."""
    pool = request.app.state.pool
    if project:
        proj = await queries.get_project_by_name(pool, project)
        if not proj:
            raise HTTPException(status_code=404, detail="Project not found")
        modules = await queries.get_modules_by_project(pool, proj["id"])
        project_name = proj["name"]
        project_id_to_name = {proj["id"]: proj["name"]}
    else:
        projects = await queries.list_projects(pool)
        project_id_to_name = {p["id"]: p["name"] for p in projects}
        modules = []
        for p in projects:
            modules.extend(await queries.get_modules_by_project(pool, p["id"]))

    result: list[dict[str, Any]] = []
    for mod in modules:
        if module and mod["name"] != module:
            continue
        tests = await queries.get_tests_by_module(pool, mod["id"])
        project_name = project_id_to_name.get(mod["project_id"], "")
        for t in tests:
            t["module_name"] = mod["name"]
            t["project_name"] = project_name
        result.extend(tests)
    return result


@router.get("/executions/{exec_id}")
async def get_execution(request: Request, exec_id: str) -> dict[str, Any]:
    """Get execution result by ID."""
    pool = request.app.state.pool
    row = await queries.get_execution(pool, exec_id)
    if not row:
        raise HTTPException(status_code=404, detail="Execution not found")
    return row


@router.get("/executions")
async def list_executions(
    request: Request,
    session_id: Optional[str] = Query(None),
    limit: int = Query(50),
) -> list[dict[str, Any]]:
    """List recent executions."""
    pool = request.app.state.pool
    if session_id:
        return await queries.list_executions_by_session(pool, session_id)
    rows = await pool.fetch(
        "SELECT * FROM execution ORDER BY created_at DESC LIMIT $1", limit,
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


@router.get("/webhooks")
async def list_webhooks(request: Request) -> list[dict[str, Any]]:
    """List all webhooks."""
    pool = request.app.state.pool
    return await queries.list_webhooks(pool)


@router.post("/webhooks")
async def create_webhook(request: Request, body: dict[str, Any]) -> dict[str, Any]:
    """Create a new webhook."""
    import hashlib
    import secrets
    from datetime import datetime, timezone

    pool = request.app.state.pool
    url = body.get("url")
    if not url:
        raise HTTPException(status_code=400, detail="Missing 'url' field")

    wh_id = hashlib.sha256(
        f"webhook:{secrets.token_hex(16)}:{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]

    await queries.insert_webhook(
        pool, wh_id, url,
        headers=body.get("headers"),
        auth_type=body.get("auth_type"),
        auth_config=body.get("auth_config"),
        events=body.get("events"),
        retry_count=body.get("retry_count", 3),
        active=body.get("active", True),
    )
    return {"id": wh_id, "url": url}


@router.delete("/webhooks/{wh_id}")
async def delete_webhook(request: Request, wh_id: str) -> dict[str, str]:
    """Remove a webhook."""
    pool = request.app.state.pool
    wh = await queries.get_webhook(pool, wh_id)
    if not wh:
        raise HTTPException(status_code=404, detail="Webhook not found")
    await queries.delete_webhook(pool, wh_id)
    return {"status": "removed", "id": wh_id}


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@router.get("/config")
async def list_config(request: Request) -> list[dict[str, Any]]:
    """List all config entries."""
    pool = request.app.state.pool
    return await queries.list_config(pool)


@router.put("/config/{key}")
async def update_config(
    request: Request, key: str, body: dict[str, Any],
) -> dict[str, Any]:
    """Update a config value."""
    import hashlib
    import secrets
    from datetime import datetime, timezone

    pool = request.app.state.pool
    value = body.get("value")
    if value is None:
        raise HTTPException(status_code=400, detail="Missing 'value' field")

    cfg_id = hashlib.sha256(
        f"config:{secrets.token_hex(16)}:{datetime.now(timezone.utc).isoformat()}".encode()
    ).hexdigest()[:16]

    result = await queries.upsert_config(pool, cfg_id, key, value)
    return result
