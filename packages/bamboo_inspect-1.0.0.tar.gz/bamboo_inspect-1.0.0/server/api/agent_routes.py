"""Agent communication API routes for Core Manager.

These endpoints are used by Test Agents to register, poll for tasks,
start tasks, and submit results.
"""

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request

from server.api.auth import get_agent_from_token
from server.db import queries
from server.services.agent_manager import register_agent
from server.services.task_manager import get_task_details, report_run, submit_result

router = APIRouter(prefix="/api/agent", tags=["agent"])


@router.post("/register")
async def agent_register(request: Request, body: dict[str, Any]) -> dict[str, Any]:
    """Register a new agent using a registration token.

    No auth required (uses one-time registration token).
    """
    pool = request.app.state.pool
    token = body.get("token")
    name = body.get("name")
    labels = body.get("labels", [])
    os_info = body.get("os_info")
    metadata = body.get("metadata")

    if not token or not name:
        raise HTTPException(status_code=400, detail="Missing 'token' or 'name' field")

    try:
        result = await register_agent(
            pool, token, name, labels,
            os_info=os_info, metadata=metadata,
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/tasks")
async def agent_poll_tasks(
    request: Request,
    agent: dict = Depends(get_agent_from_token),
) -> list[dict[str, Any]]:
    """Poll for pending tasks assigned to this agent.

    Also serves as heartbeat — updates last_heartbeat_at.
    """
    pool = request.app.state.pool
    agent_id = agent["id"]

    # Update heartbeat
    await queries.update_agent_heartbeat(pool, agent_id)

    # Check if agent has running tasks → busy, else → idle
    running = await queries.list_executions_by_agent(pool, agent_id, status="running")
    new_status = "busy" if running else "idle"
    if agent.get("status") != new_status:
        await queries.update_agent_status(pool, agent_id, new_status)

    # Return pending tasks
    pending = await queries.list_pending_executions_for_agent(pool, agent_id)
    return pending


@router.post("/tasks/{execution_id}/start")
async def agent_start_task(
    request: Request,
    execution_id: str,
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, str]:
    """Mark a task as started (running)."""
    pool = request.app.state.pool

    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    if execution.get("agent_id") != agent["id"]:
        raise HTTPException(status_code=403, detail="Task not assigned to this agent")

    await queries.update_execution(pool, execution_id, status="running")
    await queries.update_agent_status(pool, agent["id"], "busy")

    return {"status": "running", "execution_id": execution_id}


@router.get("/tasks/{execution_id}/details")
async def agent_task_details(
    request: Request,
    execution_id: str,
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, Any]:
    """Get full task details for execution."""
    pool = request.app.state.pool

    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    if execution.get("agent_id") != agent["id"]:
        raise HTTPException(status_code=403, detail="Task not assigned to this agent")

    details = await get_task_details(pool, execution_id)
    if not details:
        raise HTTPException(status_code=404, detail="Task details not found")

    return details


@router.post("/tasks/{execution_id}/result")
async def agent_submit_result(
    request: Request,
    execution_id: str,
    body: dict[str, Any],
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, str]:
    """Submit execution result from an agent."""
    pool = request.app.state.pool

    execution = await queries.get_execution(pool, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    if execution.get("agent_id") != agent["id"]:
        raise HTTPException(status_code=403, detail="Task not assigned to this agent")

    try:
        await submit_result(
            pool, execution_id,
            status=body.get("status", "failed"),
            duration=body.get("duration"),
            error_message=body.get("error_message"),
            logs=body.get("logs"),
            artifacts=body.get("artifacts"),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # Check if agent has more pending tasks
    pending = await queries.list_pending_executions_for_agent(pool, agent["id"])
    running = await queries.list_executions_by_agent(pool, agent["id"], status="running")
    if not pending and not running:
        await queries.update_agent_status(pool, agent["id"], "idle")

    return {"status": "accepted", "execution_id": execution_id}


@router.post("/report-run")
async def agent_report_run(
    request: Request,
    body: dict[str, Any],
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, Any]:
    """Accept completed CLI test results and persist them on the Core Manager.

    The CLI runs tests locally and then posts the results here so they
    appear in the dashboard, session history, and webhook notifications.
    """
    pool = request.app.state.pool
    results = body.get("results", [])

    if not results:
        raise HTTPException(status_code=400, detail="No results to report")

    project_name = body.get("project_name")
    if not project_name:
        raise HTTPException(status_code=400, detail="Missing 'project_name'")

    try:
        result = await report_run(
            pool,
            agent_id=agent["id"],
            project_name=project_name,
            project_path=body.get("project_path", ""),
            results=results,
            tracking=body.get("tracking", "session"),
        )
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/sync-repo")
async def agent_sync_repo(
    request: Request,
    body: dict[str, Any],
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, Any]:
    """Receive scanned repo and test structure from an agent.

    The agent scans its local git repo and pushes the discovered
    project, modules, and tests to the Core Manager. Core Manager
    only stores the metadata — it never touches the filesystem.
    """
    pool = request.app.state.pool

    project_name = body.get("project_name")
    project_path = body.get("project_path")
    git_remote_url = body.get("git_remote_url")
    modules = body.get("modules", [])
    tests = body.get("tests", [])

    if not project_name:
        raise HTTPException(status_code=400, detail="Missing 'project_name'")

    import hashlib

    def _hash_id(s: str) -> str:
        return hashlib.sha256(s.encode()).hexdigest()[:16]

    project_id = _hash_id(f"project:{project_name}:{agent['id']}")

    # Upsert project — update if exists, create if not
    existing = await queries.get_project_by_name(pool, project_name)
    if existing:
        project_id = existing["id"]
        # Clear old modules/tests for resync
        old_modules = await queries.get_modules_by_project(pool, project_id)
        for mod in old_modules:
            await queries.delete_tests_by_module(pool, mod["id"])
        await queries.delete_modules_by_project(pool, project_id)
    else:
        await queries.insert_project(
            pool, project_id, project_name,
            project_path or "", git_remote_url,
        )

    # Insert modules and tests from agent scan
    module_count = 0
    test_count = 0

    for mod in modules:
        mod_id = mod.get("id") or _hash_id(f"module:{project_id}:{mod['name']}")
        await queries.insert_module(pool, mod_id, project_id, mod["name"], mod.get("path", ""))
        module_count += 1

    for test in tests:
        mod_id = test.get("module_id") or _hash_id(f"module:{project_id}:{test.get('module', '')}")
        test_id = test.get("id") or _hash_id(f"test:{mod_id}:{test['name']}:{test['type']}")
        await queries.insert_test(
            pool, test_id, mod_id, test["name"], test["type"],
            test.get("path", ""),
            description=test.get("description"),
            tags=test.get("tags", []),
            timeout=test.get("timeout"),
            retry_count=test.get("retry_count", 0),
        )
        test_count += 1

    await queries.update_project_last_scan(pool, project_id)

    return {
        "project_id": project_id,
        "project_name": project_name,
        "modules": module_count,
        "tests": test_count,
    }


@router.post("/unregister")
async def agent_unregister(
    request: Request,
    agent: dict = Depends(get_agent_from_token),
) -> dict[str, str]:
    """Unregister this agent from the Core Manager."""
    from server.services.agent_manager import remove_agent
    pool = request.app.state.pool

    try:
        await remove_agent(pool, agent["id"])
        return {"status": "unregistered"}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
