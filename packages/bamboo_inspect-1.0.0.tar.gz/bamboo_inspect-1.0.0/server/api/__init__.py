"""REST API routes for the Core Manager."""
