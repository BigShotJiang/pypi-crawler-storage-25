"""JWT authentication module for Core Manager admin access.

Provides JWT encode/decode helpers, password hashing utilities,
and auth API endpoints (login, me). Users are stored in the
database admin_user table.
"""

from datetime import datetime, timedelta, timezone
from typing import Any

import bcrypt
import jwt
from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel

from server.db import queries

# ---------------------------------------------------------------------------
# Password hashing (bcrypt directly)
# ---------------------------------------------------------------------------


def hash_password(plain: str) -> str:
    """Hash a plaintext password using bcrypt."""
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a plaintext password against a bcrypt hash."""
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


# ---------------------------------------------------------------------------
# JWT encode / decode helpers
# ---------------------------------------------------------------------------

_ALGORITHM = "HS256"


def create_access_token(username: str, secret: str, expiry_minutes: int) -> str:
    """Create a signed JWT access token.

    Args:
        username: The subject (sub) claim value.
        secret: HS256 signing key.
        expiry_minutes: Token lifetime in minutes.

    Returns:
        Encoded JWT string.
    """
    now = datetime.now(tz=timezone.utc)
    payload = {
        "sub": username,
        "iat": now,
        "exp": now + timedelta(minutes=expiry_minutes),
    }
    return jwt.encode(payload, secret, algorithm=_ALGORITHM)


def decode_access_token(token: str, secret: str) -> dict[str, Any]:
    """Decode and validate a JWT access token.

    Args:
        token: Encoded JWT string.
        secret: HS256 signing key.

    Returns:
        Decoded payload dict.

    Raises:
        jwt.ExpiredSignatureError: If the token has expired.
        jwt.InvalidTokenError: If the token is invalid.
    """
    return jwt.decode(token, secret, algorithms=[_ALGORITHM])


# ---------------------------------------------------------------------------
# Pydantic models for request / response
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    """Login request body."""

    username: str
    password: str


class LoginResponse(BaseModel):
    """Login response body."""

    access_token: str
    token_type: str = "bearer"


class MeResponse(BaseModel):
    """Current user response body."""

    username: str


# ---------------------------------------------------------------------------
# Auth API router
# ---------------------------------------------------------------------------

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=LoginResponse)
async def login(request: Request, body: LoginRequest) -> LoginResponse:
    """Authenticate with username/password and receive a JWT access token."""
    pool = request.app.state.pool
    jwt_secret: str = request.app.state.jwt_secret
    jwt_expiry: int = request.app.state.jwt_expiry_minutes

    # Look up user in database
    user = await queries.get_admin_user_by_username(pool, body.username)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    # Verify password against stored bcrypt hash
    if not verify_password(body.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    # Issue JWT
    token = create_access_token(user["username"], jwt_secret, jwt_expiry)
    return LoginResponse(access_token=token)


@router.get("/me", response_model=MeResponse)
async def me(request: Request) -> MeResponse:
    """Return the current authenticated admin user from the JWT."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header",
        )

    token = auth_header[7:]  # Strip "Bearer "
    jwt_secret: str = request.app.state.jwt_secret
    pool = request.app.state.pool

    try:
        payload = decode_access_token(token, jwt_secret)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )

    username = payload.get("sub")
    if not username:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )

    # Verify user still exists and is active in DB
    user = await queries.get_admin_user_by_username(pool, username)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or deactivated",
        )

    return MeResponse(username=user["username"])
