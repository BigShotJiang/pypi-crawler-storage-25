"""Incoming git webhook receiver for Core Manager.

Receives push/PR events from GitHub/GitLab/Gitea and triggers test execution.
Parses events to determine affected modules and files.
"""

from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, Request

from server.db import queries

router = APIRouter(tags=["git-hook"])


def _collect_changed_files(commits: list[dict[str, Any]]) -> list[str]:
    """Extract unique changed file paths from a list of commit objects."""
    files: set[str] = set()
    for commit in commits:
        files.update(commit.get("added", []))
        files.update(commit.get("modified", []))
        files.update(commit.get("removed", []))
    return sorted(files)


def _parse_github(payload: dict[str, Any]) -> dict[str, Any]:
    repo = payload.get("repository", {})
    ref = payload.get("ref", "")
    branch = ref.removeprefix("refs/heads/")
    commits = payload.get("commits", [])
    return {
        "repo": repo.get("full_name", ""),
        "branch": branch,
        "commit_sha": payload.get("after", ""),
        "changed_files": _collect_changed_files(commits),
        "provider": "github",
    }


def _parse_gitlab(payload: dict[str, Any]) -> dict[str, Any]:
    project = payload.get("project", {})
    ref = payload.get("ref", "")
    branch = ref.removeprefix("refs/heads/")
    commits = payload.get("commits", [])
    return {
        "repo": project.get("path_with_namespace", ""),
        "branch": branch,
        "commit_sha": payload.get("after", ""),
        "changed_files": _collect_changed_files(commits),
        "provider": "gitlab",
    }


def _parse_gitea(payload: dict[str, Any]) -> dict[str, Any]:
    repo = payload.get("repository", {})
    ref = payload.get("ref", "")
    branch = ref.removeprefix("refs/heads/")
    commits = payload.get("commits", [])
    return {
        "repo": repo.get("full_name", ""),
        "branch": branch,
        "commit_sha": payload.get("after", ""),
        "changed_files": _collect_changed_files(commits),
        "provider": "gitea",
    }


def parse_git_event(payload: dict[str, Any], provider: str) -> dict[str, Any]:
    """Parse a git webhook event payload."""
    match provider.lower():
        case "github":
            return _parse_github(payload)
        case "gitlab":
            return _parse_gitlab(payload)
        case "gitea":
            return _parse_gitea(payload)
        case _:
            raise ValueError(f"Unknown git provider: {provider}")


@router.post("/api/git-hook")
async def git_hook(
    request: Request,
    token: str = Query(..., description="Authentication token"),
    background_tasks: BackgroundTasks = None,
) -> dict[str, str]:
    """Receive a git webhook event and trigger tests."""
    pool = request.app.state.pool

    projects = await queries.list_projects(pool)
    matched_project = None
    for proj in projects:
        cfg = await queries.get_config(pool, f"git_hook_token:{proj['id']}")
        if cfg and cfg.get("value") == token:
            matched_project = proj
            break

    if not matched_project:
        raise HTTPException(status_code=401, detail="Invalid token")

    payload = await request.json()

    provider = "github"
    user_agent = request.headers.get("user-agent", "").lower()
    if "gitlab" in user_agent:
        provider = "gitlab"
    elif "gitea" in user_agent:
        provider = "gitea"
    if request.headers.get("X-Gitlab-Event"):
        provider = "gitlab"
    elif request.headers.get("X-Gitea-Event"):
        provider = "gitea"
    elif request.headers.get("X-GitHub-Event"):
        provider = "github"

    event = parse_git_event(payload, provider)

    changed = event.get("changed_files", [])
    affected_modules: set[str] = set()
    run_all = False

    for commit in payload.get("commits", []):
        msg = commit.get("message", "")
        if "[test all]" in msg:
            run_all = True
            break

    if not run_all:
        for f in changed:
            parts = f.split("/")
            if len(parts) >= 2:
                affected_modules.add(parts[1] if parts[0] == "src" else parts[0])

    return {"status": "accepted", "affected_modules": sorted(affected_modules)}
