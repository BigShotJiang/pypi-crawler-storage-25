"""Data models for the Core Manager."""
