"""Bamboo Inspect Core Manager — central server for test management.

Manages projects, tests, agents, task assignments, and results.
Does NOT execute tests — that's the Test Agent's responsibility.
Deployed via Docker, serves web dashboard on port 8686.
"""
