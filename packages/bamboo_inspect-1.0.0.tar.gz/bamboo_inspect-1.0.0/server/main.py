"""Core Manager entry point.

Loads configuration, creates the database connection pool,
and starts the FastAPI server via uvicorn.
"""

import asyncio
import logging
import sys

import uvicorn

from server.app import create_app
from server.config import load_server_config
from server.db.connection import close_pool, create_pool

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("core-manager")


async def run_server() -> None:
    """Start the Core Manager server."""
    cfg = load_server_config()

    logger.info("Connecting to database %s@%s:%d/%s ...", cfg.db_user, cfg.db_host, cfg.db_port, cfg.db_name)

    pool = await create_pool(
        host=cfg.db_host,
        port=cfg.db_port,
        database=cfg.db_name,
        user=cfg.db_user,
        password=cfg.db_password,
    )

    logger.info("Database connected")

    app = create_app(
        pool=pool,
        offline_threshold=cfg.agent_offline_threshold,
        jwt_secret=cfg.jwt_secret,
        jwt_expiry_minutes=cfg.jwt_expiry_minutes,
    )

    config = uvicorn.Config(
        app,
        host=cfg.host,
        port=cfg.port,
        log_level="info",
    )
    server = uvicorn.Server(config)

    try:
        logger.info("Starting Core Manager on %s:%d", cfg.host, cfg.port)
        await server.serve()
    finally:
        logger.info("Shutting down...")
        await close_pool(pool)


def main() -> None:
    """CLI entry point for the Core Manager."""
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        pass
    except SystemExit as e:
        logger.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
