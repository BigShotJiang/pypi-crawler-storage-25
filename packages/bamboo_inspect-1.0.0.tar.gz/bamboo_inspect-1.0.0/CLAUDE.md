# Bamboo Inspect - Project Context for AI Assistants

## Project Overview

**Bamboo Inspect** is an open-source test management system with two components:

1. **Core Manager** (Docker) — Central server that manages test structure, agents, task assignments, and results. Does NOT execute tests. Deployed via Docker with FastAPI + PostgreSQL.

2. **Test Agent** (PyPI package `bamboo-inspect`) — Lightweight worker that registers with a Core Manager, polls for tasks, executes tests (Playwright/Claude Code), and pushes results back. Can also run tests locally in stateless CLI mode. Installed via `pip install bamboo-inspect`.

### Architecture (GitHub Actions Runner Model)
- **Core Manager** = GitHub Actions control plane (manages agents, assigns tasks, stores results)
- **Test Agent** = Self-hosted runner (registers, scans repos, pulls tasks, executes, reports)
- **Multiple agents** can connect to one Core Manager
- **Agent registration** uses two-phase token flow (registration token → persistent token)
- **Agent health** monitored via heartbeat (poll-based, 30s interval, offline after 90s)
- **Task assignment** is manual (admin selects agent + tests)
- **Repo scanning** is done by agents — they scan local git repos and push test structure to Core Manager
- **Core Manager has no git/filesystem access** — it only stores metadata received from agents

## Project Structure

```
bamboo_inspect/
├── src/
│   └── bamboo_inspect/              # Test Agent (PyPI package "bamboo-inspect")
│       ├── __init__.py
│       ├── cli.py                # Typer CLI (stateless + agent commands)
│       ├── config.py             # Agent config loader
│       ├── scanner.py            # Test discovery & registry
│       ├── utils.py              # Hash ID generation
│       ├── agent/                # Agent core modules
│       │   ├── __init__.py
│       │   ├── client.py         # HTTP client for Core Manager API
│       │   ├── poller.py         # Polling loop (fetch tasks, execute, push results)
│       │   ├── registration.py   # Agent registration flow
│       │   └── state.py          # Local state management (~/.bambooinspect/agent.yaml)
│       ├── executors/
│       │   ├── __init__.py
│       │   ├── playwright.py     # Playwright test executor
│       │   └── claude_code.py    # Claude Code AI executor
│       ├── git/
│       │   ├── __init__.py
│       │   └── manager.py        # Repository validation & git metadata
│       ├── report/
│       │   ├── __init__.py
│       │   ├── renderer.py       # Template-based report rendering
│       │   └── templates/        # Built-in report templates
│       └── web/
│           ├── __init__.py
│           ├── app.py            # Agent web UI (FastAPI, port 8787)
│           └── static/           # Agent dashboard HTML/JS/CSS
├── server/                       # Core Manager (Docker only, NOT in PyPI)
│   ├── __init__.py
│   ├── app.py                    # FastAPI main application
│   ├── config.py                 # Server config (env vars)
│   ├── main.py                   # Server entry point
│   ├── requirements.txt          # Server dependencies
│   ├── api/
│   │   ├── __init__.py
│   │   ├── admin_routes.py       # Admin API (agents, tokens, tasks, repos, etc.)
│   │   ├── agent_routes.py       # Agent communication API (register, poll, result)
│   │   ├── auth.py               # Agent token authentication middleware
│   │   └── git_hook.py           # Git webhook receiver
│   ├── db/
│   │   ├── __init__.py
│   │   ├── connection.py         # asyncpg pool management
│   │   └── queries.py            # Raw SQL queries (all tables)
│   ├── models/
│   │   └── __init__.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── agent_manager.py      # Agent registration, token management
│   │   ├── heartbeat_monitor.py  # Agent health monitoring
│   │   ├── task_manager.py       # Task assignment, result processing
│   │   └── webhook_dispatcher.py # Outgoing webhook sender
│   └── web/
│       └── static/               # Core Manager dashboard HTML/JS/CSS
├── migrations/
│   └── default/                  # SQL migration files (bamboodb)
├── Makefile                      # Dev workflow targets
├── Dockerfile                    # Core Manager production build
├── Dockerfile.dev                # Core Manager development build
├── docker-compose.yml            # Core Manager dev environment
├── docker-compose.prod.yml       # Core Manager production deployment
├── docker-entrypoint.sh          # Docker entrypoint (migrate + start)
├── bamboo_database.toml          # Database migration config
├── pyproject.toml                # Agent PyPI packaging
├── CLAUDE.md                     # This file
└── README.md
```

## Technology Stack

### Test Agent (PyPI package)
- **Language**: Python 3.10+
- **CLI**: Typer
- **Web UI**: FastAPI (port 8787, lightweight agent dashboard)
- **HTTP Client**: aiohttp (Core Manager communication)
- **Config**: PyYAML (~/.bambooinspect/agent.yaml)
- **Executors**: subprocess (Playwright), claude-code npm lib (AI prompts)

### Core Manager (Docker)
- **Language**: Python 3.10+
- **Web Framework**: FastAPI (port 8686, full dashboard + API)
- **Database**: PostgreSQL via asyncpg + raw SQL (no ORM)
- **Migrations**: bamboo-database (bamboodb CLI)
- **Frontend**: Vanilla HTML/JS/CSS

## CLI Commands (All prefixed with `bambooinspect`)

### Stateless Test Execution (no Core Manager required)

```bash
bambooinspect run <test> --type script|prompt
bambooinspect run-module <module> --type script|prompt
bambooinspect run-all --type script|prompt
bambooinspect run-all --type script --report ai
bambooinspect run-all --type script --report-output ./report.html
```

### Agent Management

```bash
bambooinspect agent register --url http://core:8686 --token <token> --name agent-01 --labels linux,playwright
bambooinspect agent start [--port 8787]
bambooinspect agent stop
bambooinspect agent status
bambooinspect agent sync-repo [path]     # Scan local repo and push test structure to Core Manager
bambooinspect agent unregister
```

## Core Manager API Endpoints

### Agent Communication (used by agents)
- `POST /api/agent/register` — Register with registration token
- `GET /api/agent/tasks` — Poll for pending tasks (also heartbeat)
- `POST /api/agent/tasks/{id}/start` — Mark task as running
- `GET /api/agent/tasks/{id}/details` — Get full task details
- `POST /api/agent/tasks/{id}/result` — Submit execution result
- `POST /api/agent/sync-repo` — Push scanned repo/test structure to Core Manager
- `POST /api/agent/unregister` — Unregister agent

### Admin Management (used by dashboard/admins)
- `GET/DELETE /api/admin/agents` — Agent CRUD
- `POST/GET/DELETE /api/admin/registration-tokens` — Token management
- `POST /api/admin/tasks` — Assign tests to agent
- `GET /api/admin/tasks` — List tasks (filter by agent/status)
- `POST /api/admin/tasks/{id}/cancel` — Cancel task
- `GET/DELETE /api/admin/repos` — Repository management (metadata only, agents push data)
- `GET /api/admin/tests` — List tests
- `GET/POST/DELETE /api/admin/webhooks` — Webhook management
- `GET/PUT /api/admin/config` — Configuration management
- `POST /api/git-hook` — Git webhook receiver

## Database Tables (Core Manager)

```
agent: id, name (UNIQUE), labels (JSONB), status, token_hash, registered_at, last_heartbeat_at, os_info (JSONB), metadata (JSONB)
registration_token: id, token_hash, description, created_at, expires_at, used, used_by_agent_id
project: id, name, path, git_remote_url, created_at, last_scan
module: id, project_id, name, path
test: id, module_id, name, type, path, description, tags (JSONB), timeout, retry_count
run_session: id, project_id, agent_id, tracking_level, status, total_tests, passed, failed, triggered_by, git_commit_sha, started_at, finished_at
execution: id, session_id, test_id, agent_id, status, duration, error_message, logs, artifacts (JSONB), triggered_by, git_commit_sha, created_at
execution_step: id, execution_id, step_order, name, status, duration, error_message, created_at
report: id, execution_id, session_id, format, source, content, created_at
webhook: id, url, headers, auth_type, auth_config, events, retry_count, active
config: id, key (UNIQUE), value (JSONB)
```

## Configuration

### Test Agent (~/.bambooinspect/agent.yaml — created on registration)
```yaml
core_url: "http://core:8686"
agent_token: "<persistent-token>"
agent_id: "<agent-id>"
agent_name: "agent-01"
labels: ["linux", "playwright"]
port: 8787
host: "127.0.0.1"
poll_interval: 30
```

### Core Manager (environment variables in Docker)
```
BAMBOOINSPECT_DB_HOST, BAMBOOINSPECT_DB_PORT, BAMBOOINSPECT_DB_NAME
BAMBOOINSPECT_DB_USER, BAMBOOINSPECT_DB_PASSWORD
BAMBOOINSPECT_PORT (default: 8686)
BAMBOOINSPECT_HOST (default: 0.0.0.0)
BAMBOOINSPECT_ACCESS_MODE (default: lan)
BAMBOOINSPECT_AUTH_TOKEN (optional)
BAMBOOINSPECT_AGENT_OFFLINE_THRESHOLD (default: 90 seconds)
```

## Getting Started

### Deploy Core Manager (Docker)
```bash
cd bamboo_inspect
make docker-dev          # Dev with built-in PostgreSQL
# Access dashboard at http://localhost:8686
```

### Install & Register Test Agent
```bash
pip install bamboo-inspect

# Generate a registration token from Core Manager dashboard
# Then register the agent:
bambooinspect agent register --url http://core:8686 --token <token> --name my-agent --labels linux

# Start the agent
bambooinspect agent start
# Agent dashboard at http://localhost:8787
```

### Stateless CLI (no Core Manager needed)
```bash
cd ~/my-project
bambooinspect run-all --type script
```

## Notes for AI Assistants

- **Two components**: Core Manager (Docker) and Test Agent (PyPI)
- **Two components**: Core Manager (Docker) and Test Agent (PyPI)
- PyPI package `bamboo-inspect` = Test Agent only (no server/DB code)
- Docker = Core Manager only (FastAPI + asyncpg server, uses psycopg2-binary)
- Agent CLI: `bambooinspect agent register|start|stop|status|sync-repo|unregister`
- Stateless CLI: `bambooinspect run|run-module|run-all` (works without Core Manager)
- Core Manager generates registration tokens, agents register with them
- Agents poll Core Manager for tasks (pull model, like GitHub Actions runners)
- **Agents scan repos locally** and push test structure to Core Manager via `sync-repo`
- **Core Manager has NO git/filesystem access** — it only stores metadata from agents
- Manual task assignment (admin selects agent + tests)
- Agent heartbeat via poll cycle (30s default, offline after 90s)
- PostgreSQL via asyncpg + raw SQL (no ORM) in Core Manager
- Vanilla HTML/JS/CSS for both dashboards
- Default ports: Core Manager = 8686, Agent = 8787
