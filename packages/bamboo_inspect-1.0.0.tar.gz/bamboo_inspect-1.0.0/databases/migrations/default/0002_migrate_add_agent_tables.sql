-- Bamboo Inspect: Add agent management tables and columns
-- Adds agent, registration_token tables and agent_id to execution/run_session.

CREATE TABLE IF NOT EXISTS agent (
    id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    labels JSONB NOT NULL DEFAULT '[]'::jsonb,
    status VARCHAR(10) NOT NULL DEFAULT 'offline' CHECK (status IN ('online', 'idle', 'busy', 'offline')),
    token_hash VARCHAR(64) NOT NULL,
    registered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_heartbeat_at TIMESTAMPTZ,
    os_info JSONB NOT NULL DEFAULT '{}'::jsonb,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS registration_token (
    id VARCHAR(16) PRIMARY KEY,
    token_hash VARCHAR(64) NOT NULL,
    description VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    used BOOLEAN NOT NULL DEFAULT FALSE,
    used_by_agent_id VARCHAR(16)
);

-- Add agent_id column to execution table
ALTER TABLE execution ADD COLUMN IF NOT EXISTS agent_id VARCHAR(16);

-- Add agent_id column to run_session table
ALTER TABLE run_session ADD COLUMN IF NOT EXISTS agent_id VARCHAR(16);

-- Update status check constraints to include 'cancelled'
-- Drop and recreate for execution
ALTER TABLE execution DROP CONSTRAINT IF EXISTS execution_status_check;
ALTER TABLE execution ADD CONSTRAINT execution_status_check
    CHECK (status IN ('pending', 'running', 'passed', 'failed', 'cancelled'));

-- Drop and recreate for run_session
ALTER TABLE run_session DROP CONSTRAINT IF EXISTS run_session_status_check;
ALTER TABLE run_session ADD CONSTRAINT run_session_status_check
    CHECK (status IN ('pending', 'running', 'passed', 'failed', 'cancelled'));

-- Indexes for agent queries
CREATE INDEX IF NOT EXISTS idx_agent_name ON agent (name);
CREATE INDEX IF NOT EXISTS idx_agent_status ON agent (status);
CREATE INDEX IF NOT EXISTS idx_agent_token_hash ON agent (token_hash);
CREATE INDEX IF NOT EXISTS idx_registration_token_hash ON registration_token (token_hash);
CREATE INDEX IF NOT EXISTS idx_execution_agent_id ON execution (agent_id);
CREATE INDEX IF NOT EXISTS idx_run_session_agent_id ON run_session (agent_id);
