-- Add 'cli' as an allowed triggered_by value for run_session and execution tables.
-- Required by the --post-task CLI feature that posts local test results to the Core Manager.

-- run_session: drop the existing inline check and add the updated one
DO $$
DECLARE
    _con text;
BEGIN
    SELECT conname INTO _con
    FROM pg_constraint
    WHERE conrelid = 'run_session'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%triggered_by%';
    IF _con IS NOT NULL THEN
        EXECUTE format('ALTER TABLE run_session DROP CONSTRAINT %I', _con);
    END IF;
END $$;

ALTER TABLE run_session ADD CONSTRAINT run_session_triggered_by_check
    CHECK (triggered_by IN ('manual', 'git_hook', 'scheduled', 'cli'));

-- execution: drop the existing inline check and add the updated one
DO $$
DECLARE
    _con text;
BEGIN
    SELECT conname INTO _con
    FROM pg_constraint
    WHERE conrelid = 'execution'::regclass
      AND contype = 'c'
      AND pg_get_constraintdef(oid) ILIKE '%triggered_by%';
    IF _con IS NOT NULL THEN
        EXECUTE format('ALTER TABLE execution DROP CONSTRAINT %I', _con);
    END IF;
END $$;

ALTER TABLE execution ADD CONSTRAINT execution_triggered_by_check
    CHECK (triggered_by IN ('manual', 'git_hook', 'scheduled', 'cli'));
