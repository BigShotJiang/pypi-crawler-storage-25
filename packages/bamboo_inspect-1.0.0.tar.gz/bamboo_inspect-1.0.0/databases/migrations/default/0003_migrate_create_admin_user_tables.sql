-- Bamboo Inspect: Add admin user, role, and user-role tables
-- Creates admin_user, admin_role, admin_user_role tables with indexes.
-- Seeds default admin user (bamboo / bambooinspect@123) and admin role.

BEGIN;

-- Admin user table
CREATE TABLE IF NOT EXISTS admin_user (
    id VARCHAR(16) PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Admin role table
CREATE TABLE IF NOT EXISTS admin_role (
    id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT
);

-- Admin user-role join table (many-to-many)
CREATE TABLE IF NOT EXISTS admin_user_role (
    user_id VARCHAR(16) NOT NULL,
    role_id VARCHAR(16) NOT NULL,
    PRIMARY KEY (user_id, role_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_admin_user_username ON admin_user (username);
CREATE INDEX IF NOT EXISTS idx_admin_user_is_active ON admin_user (is_active);
CREATE INDEX IF NOT EXISTS idx_admin_role_name ON admin_role (name);
CREATE INDEX IF NOT EXISTS idx_admin_user_role_user_id ON admin_user_role (user_id);
CREATE INDEX IF NOT EXISTS idx_admin_user_role_role_id ON admin_user_role (role_id);

-- Seed default admin role
INSERT INTO admin_role (id, name, description)
VALUES ('role_admin_0001', 'admin', 'Full administrative access')
ON CONFLICT (id) DO NOTHING;

-- Seed default admin user (password: bambooinspect@123)
INSERT INTO admin_user (id, username, password_hash, display_name, is_active)
VALUES (
    'user_admin_0001',
    'bamboo',
    '$2b$12$UGZGUC6lK.5p8vq8Ka.ROeNYedpMT4bHQHVeO2.2gy.XdmRCjgb4O',
    'Administrator',
    TRUE
)
ON CONFLICT (id) DO NOTHING;

-- Link default user to admin role
INSERT INTO admin_user_role (user_id, role_id)
VALUES ('user_admin_0001', 'role_admin_0001')
ON CONFLICT (user_id, role_id) DO NOTHING;

COMMIT;
