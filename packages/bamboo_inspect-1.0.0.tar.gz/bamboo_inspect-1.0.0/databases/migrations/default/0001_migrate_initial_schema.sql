-- Bamboo Inspect: Initial database schema
-- Creates all 9 tables for daemon mode persistent storage.
-- No foreign key constraints — all references use unique hash IDs for loose coupling.

CREATE TABLE IF NOT EXISTS project (
    id VARCHAR(16) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    path TEXT NOT NULL,
    git_remote_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_scan TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS module (
    id VARCHAR(16) PRIMARY KEY,
    project_id VARCHAR(16) NOT NULL,
    name VARCHAR(255) NOT NULL,
    path TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS test (
    id VARCHAR(16) PRIMARY KEY,
    module_id VARCHAR(16) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('script', 'prompt')),
    path TEXT NOT NULL,
    description TEXT,
    tags JSONB NOT NULL DEFAULT '[]'::jsonb,
    timeout INTEGER,
    retry_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS run_session (
    id VARCHAR(16) PRIMARY KEY,
    project_id VARCHAR(16) NOT NULL,
    tracking_level VARCHAR(10) NOT NULL DEFAULT 'none' CHECK (tracking_level IN ('none', 'session', 'full')),
    status VARCHAR(10) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'passed', 'failed')),
    total_tests INTEGER NOT NULL DEFAULT 0,
    passed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    triggered_by VARCHAR(10) NOT NULL DEFAULT 'manual' CHECK (triggered_by IN ('manual', 'git_hook', 'scheduled')),
    git_commit_sha VARCHAR(40),
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS execution (
    id VARCHAR(16) PRIMARY KEY,
    session_id VARCHAR(16),
    test_id VARCHAR(16) NOT NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'passed', 'failed')),
    duration INTEGER,
    error_message TEXT,
    logs TEXT,
    artifacts JSONB NOT NULL DEFAULT '{}'::jsonb,
    triggered_by VARCHAR(10) NOT NULL DEFAULT 'manual' CHECK (triggered_by IN ('manual', 'git_hook', 'scheduled')),
    git_commit_sha VARCHAR(40),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS execution_step (
    id VARCHAR(16) PRIMARY KEY,
    execution_id VARCHAR(16) NOT NULL,
    step_order INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(10) NOT NULL CHECK (status IN ('passed', 'failed', 'skipped')),
    duration INTEGER,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS report (
    id VARCHAR(16) PRIMARY KEY,
    execution_id VARCHAR(16),
    session_id VARCHAR(16),
    format VARCHAR(10) NOT NULL CHECK (format IN ('html', 'markdown', 'json')),
    source VARCHAR(10) NOT NULL CHECK (source IN ('template', 'ai')),
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS webhook (
    id VARCHAR(16) PRIMARY KEY,
    url TEXT NOT NULL,
    headers JSONB NOT NULL DEFAULT '{}'::jsonb,
    auth_type VARCHAR(20),
    auth_config JSONB NOT NULL DEFAULT '{}'::jsonb,
    events JSONB NOT NULL DEFAULT '[]'::jsonb,
    retry_count INTEGER NOT NULL DEFAULT 3,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS config (
    id VARCHAR(16) PRIMARY KEY,
    key VARCHAR(255) NOT NULL UNIQUE,
    value JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_module_project_id ON module (project_id);
CREATE INDEX IF NOT EXISTS idx_test_module_id ON test (module_id);
CREATE INDEX IF NOT EXISTS idx_run_session_project_id ON run_session (project_id);
CREATE INDEX IF NOT EXISTS idx_run_session_started_at ON run_session (started_at);
CREATE INDEX IF NOT EXISTS idx_execution_session_id ON execution (session_id);
CREATE INDEX IF NOT EXISTS idx_execution_test_id ON execution (test_id);
CREATE INDEX IF NOT EXISTS idx_execution_created_at ON execution (created_at);
CREATE INDEX IF NOT EXISTS idx_execution_step_execution_id ON execution_step (execution_id);
CREATE INDEX IF NOT EXISTS idx_report_execution_id ON report (execution_id);
CREATE INDEX IF NOT EXISTS idx_report_session_id ON report (session_id);
