Task statement
- Review `openspec/changes/archive/` and notice that the repository contains many archived change proposals/spec artifacts.
- Clarify the user's goal to remove archived change history while preserving the substance as a new complete `spec.md`.

Desired outcome
- A clarified requirements artifact describing what should happen to archived change directories and what the final consolidated `spec.md` must contain.

Stated solution
- "remove all this archive change"
- "summary all this spec"
- "write a complete spec.md file"

Probable intent hypothesis
- Simplify the OpenSpec structure by removing historical archived-change clutter while preserving the meaningful capability requirements in a single easier-to-read master spec.

Known facts/evidence
- `openspec/changes/archive/` contains 10 archived change sets dated 2026-02-08 through 2026-02-10.
- Each archived change set contains proposal/design/tasks docs; some also contain per-capability spec files.
- `openspec/specs/` currently contains 25 live capability spec directories such as `agent-registration`, `database`, `web-dashboard`, `modern-ui-theme`, and `cli-post-task`.
- The archive proposals describe the evolution of the repo from bootstrap -> full implementation -> architecture split -> auth -> UI improvements.
- The live `openspec/specs/` tree appears to already consolidate many capabilities introduced by archived changes.

Constraints
- Deep-interview mode only: clarify and write interview/spec artifacts, but do not implement the cleanup directly in this mode.
- Need explicit non-goals and decision boundaries before handoff.
- User specifically wants a summary of the archived specs before a complete `spec.md` is written.

Unknowns/open questions
- Should the final artifact replace the entire `openspec/specs/` tree, or sit beside it as a master summary?
- Does "remove all archive change" mean delete only `openspec/changes/archive/`, or also remove duplicated live per-capability specs after consolidation?
- Should the master `spec.md` describe current product requirements only, or also retain historical rationale and migration notes?
- What level of detail is expected: executive summary, full RFC-2119 requirements, or both?

Decision-boundary unknowns
- May OMX decide the final document structure on its own?
- May OMX choose which archived details to omit if they are redundant?
- May OMX preserve the existing `openspec/specs/` tree while adding a root-level `spec.md` instead of replacing it?

Likely codebase touchpoints
- `openspec/changes/archive/`
- `openspec/specs/`
- `openspec/config.yaml`
