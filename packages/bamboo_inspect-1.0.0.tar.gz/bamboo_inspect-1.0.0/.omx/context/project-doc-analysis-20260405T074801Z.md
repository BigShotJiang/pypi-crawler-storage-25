Task statement: Analyze this project's server and frontend code, then update the docs files.

Desired outcome:
- Repository docs describe the current server-side architecture and frontend/UI implementation accurately enough for users and contributors.

Stated solution:
- Inspect the existing codebase, identify outdated or missing documentation, and update relevant docs files.

Probable intent hypothesis:
- The user wants docs aligned with the real implementation so onboarding and maintenance are less error-prone.

Known facts / evidence:
- This is a brownfield repo with a FastAPI Core Manager under `server/` and a Python agent package under `src/bamboo_inspect/`.
- The Core Manager entrypoint is `server/main.py`, which loads config, creates an asyncpg pool, and serves a FastAPI app from `server/app.py`.
- `server/app.py` mounts `auth_jwt`, `agent_routes`, `admin_routes`, and `git_hook` routers, exposes `/api/health`, and serves static files from `server/web/static/`.
- The Core Manager frontend is a static dashboard in `server/web/static/` with `index.html`, `login.html`, `app.js`, `auth.js`, `style.css`, and `color.css`.
- `server/web/static/index.html` exposes tabs for agents, tasks, repositories, tests, and webhooks, plus modals for token generation, task assignment, repository addition, and webhook management.
- The agent has a separate FastAPI monitoring UI in `src/bamboo_inspect/web/app.py` serving `src/bamboo_inspect/web/static/`.
- Existing docs already contain stale paths. Example mismatches found in `docs/dev-quickstart.md`: it references `src/bamboo_inspect/cli.py`, `docker/Dockerfile.dev`, and `docker/docker-compose.prod.yml`, which do not exist in this checkout.

Constraints:
- Follow deep-interview mode first because the user explicitly invoked `$deep-interview`.
- Do not implement inside deep-interview until ambiguity is reduced and the handoff is clear.
- No new dependencies.
- Keep doc changes grounded in inspected code, not assumptions.

Unknowns / open questions:
- Which docs files the user wants updated: all stale top-level docs, only architecture-oriented docs, or a narrower subset.
- Whether the docs should stay high-level or include endpoint/UI details.
- Whether openspec specs are in scope, or only README/docs files.

Decision-boundary unknowns:
- Whether OMX may choose the full set of docs to edit based on stale findings without further confirmation.
- Whether adding a new architecture doc is in scope, or updates must be limited to existing files.

Likely codebase touchpoints:
- `README.md`
- `docs/project_profile.md`
- `docs/quickstart.md`
- `docs/dev-quickstart.md`
- `docs/agent-core-communication.md`
- `server/main.py`
- `server/app.py`
- `server/api/*.py`
- `server/services/*.py`
- `server/web/static/*`
- `src/bamboo_inspect/web/app.py`
