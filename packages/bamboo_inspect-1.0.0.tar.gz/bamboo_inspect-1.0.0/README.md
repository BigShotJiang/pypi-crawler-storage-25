# Bamboo Inspect

Easy test management for Playwright and AI-driven tests.

## Architecture

Bamboo Inspect uses a **Core Manager + Test Agent** architecture (similar to GitHub Actions self-hosted runners):

| Component | Core Manager | Test Agent |
|---|---|---|
| **Deployment** | Docker | `pip install bamboo-inspect` |
| **Role** | Manages tests, agents, results | Executes tests |
| **Port** | 8686 (web dashboard) | 8787 (agent dashboard) |
| **Database** | PostgreSQL | None |
| **Executes tests?** | No | Yes |

Multiple Test Agents can connect to one Core Manager.

## Quick Start

### 1. Deploy Core Manager

```bash
git clone https://github.com/bamboo-inspect/bamboo-inspect.git
cd bamboo-inspect
make docker-dev
# Dashboard at http://localhost:8686
```

### 2. Install & Register Test Agent

```bash
pip install bamboo-inspect

# Generate a token from the Core Manager dashboard, then:
bambooinspect agent register \
  --url http://localhost:8686 \
  --token <registration-token> \
  --name my-agent \
  --labels linux,playwright

bambooinspect agent start
# Agent dashboard at http://localhost:8787
```

### 3. Sync a Repo & Assign Tests

```bash
# Agent scans a local git repo and pushes test structure to Core Manager
cd ~/my-project
bambooinspect agent sync-repo .
```

Then use the Core Manager dashboard to:
1. Select tests and assign them to an agent (Tests → Assign to Agent)
2. Monitor results in the Tasks tab

### Stateless CLI (no Core Manager needed)

```bash
cd ~/my-project
bambooinspect run-all --type script
bambooinspect run-module auth --type script
bambooinspect run login_test --type script
```

## Test Structure

Monitored repositories must follow this structure:

```
my-project/
  tests/
    scripts/           # Playwright tests
      auth/
        login_test.py
      checkout/
        cart_test.js
    prompts/           # AI prompts (Claude Code)
      auth/
        test_login.prompt
```

## License

MIT
