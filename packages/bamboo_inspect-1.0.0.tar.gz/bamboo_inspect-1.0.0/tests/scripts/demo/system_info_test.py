# @description: Demo test — display basic system information
# @tags: demo, smoke
# @timeout: 10000
# @retry: 0

import platform
import sys
import os


def main():
    info = {
        "python_version": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "N/A",
        "hostname": platform.node(),
        "cwd": os.getcwd(),
        "user": os.environ.get("USER") or os.environ.get("USERNAME", "N/A"),
    }

    print("=== System Information ===")
    for key, value in info.items():
        print(f"  {key}: {value}")
    print("==========================")
    print("PASSED")


if __name__ == "__main__":
    main()
