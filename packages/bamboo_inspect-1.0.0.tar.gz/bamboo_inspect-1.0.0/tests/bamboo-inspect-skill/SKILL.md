# Bamboo Inspect — AI Skill

> This file teaches AI agents (e.g. Claude) how to use **bambooinspect**,
> the CLI tool for managing Playwright and AI-driven tests.

## What is Bamboo Inspect?

Bamboo Inspect is a test management tool that organises, discovers, and executes
two kinds of tests inside any git repository:

- **Script tests** — Playwright-based test files written in Python, JavaScript,
  or TypeScript.
- **Prompt tests** — AI prompt files (`.prompt`) executed via Claude Code.

All tests live under a `tests/` directory at the repository root.

## CLI Commands

| Command | Description |
|---|---|
| `bambooinspect init` | Scaffold the `tests/` directory structure in a git repo. |
| `bambooinspect run <name> --type <script\|prompt>` | Run a single test by name. |
| `bambooinspect run-module <module> --type <script\|prompt>` | Run all tests in a module. |
| `bambooinspect run-all --type <script\|prompt>` | Run every test of a given type. |

### Common Options

- `--tracking none|session|full` — Override the tracking level.
- `--report ai` — Generate an AI-powered summary report.
- `--report-output <path>` — Save the report to a file.

## Directory Structure

```
tests/
  scripts/
    <module>/           # e.g. auth, checkout, settings
      <test_file>.py    # Python Playwright test
      <test_file>.js    # JavaScript Playwright test
      <test_file>.ts    # TypeScript Playwright test
  prompts/
    <module>/
      <test_file>.prompt  # AI prompt test
  bamboo-inspect-skill/
    SKILL.md            # This file
  bambooinspect-rules.md   # Conventions & structure rules
```

## Creating a Script Test

Create a file under `tests/scripts/<module>/` with one of the supported
extensions (`.py`, `.js`, `.ts`). Add metadata comments at the top:

```python
# @description: Verify user can log in with valid credentials
# @tags: auth, smoke
# @timeout: 30000
# @retry: 1

from playwright.sync_api import sync_playwright

def test_login():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto("https://example.com/login")
        page.fill("#email", "user@example.com")
        page.fill("#password", "password123")
        page.click("button[type=submit]")
        assert page.url == "https://example.com/dashboard"
        browser.close()
```

## Creating a Prompt Test

Create a `.prompt` file under `tests/prompts/<module>/`:

```
Verify that the login page at https://example.com/login:
1. Displays email and password fields.
2. Shows an error message for invalid credentials.
3. Redirects to /dashboard on successful login.
```

Prompt tests are executed by Claude Code and return an AI-generated response.

## Metadata Annotations

Add these comment lines at the top of script test files (first 30 lines):

| Key | Format | Description |
|---|---|---|
| `@description` | `# @description: <text>` | Human-readable test description. |
| `@tags` | `# @tags: tag1, tag2` | Comma-separated tags for filtering. |
| `@timeout` | `# @timeout: <ms>` | Max execution time in milliseconds. |
| `@retry` | `# @retry: <count>` | Number of retry attempts on failure. |

For JavaScript/TypeScript files, use `//` instead of `#`.
