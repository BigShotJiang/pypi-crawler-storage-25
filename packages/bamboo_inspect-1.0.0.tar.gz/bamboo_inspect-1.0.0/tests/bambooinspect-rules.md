# Bamboo Inspect — Rules & Conventions

This document defines the mandatory directory structure, file naming conventions,
and metadata format for tests managed by **bambooinspect**.

## Directory Structure

All tests MUST be placed under the `tests/` directory at the git repository root.

```
<repo-root>/
  tests/
    scripts/
      <module>/
        <test_name>.py
        <test_name>.js
        <test_name>.ts
    prompts/
      <module>/
        <test_name>.prompt
    bamboo-inspect-skill/
      SKILL.md
    bambooinspect-rules.md
```

## Modules

A **module** is a subdirectory under `tests/scripts/` or `tests/prompts/`.
Modules group related tests together (e.g. `auth`, `checkout`, `settings`).

- Module names MUST be lowercase.
- Module names MUST use hyphens or underscores (no spaces).
- Each module directory contains one or more test files.

## Script Tests

Script tests are Playwright-based test files.

### Supported Extensions

| Extension | Language |
|---|---|
| `.py` | Python |
| `.js` | JavaScript |
| `.ts` | TypeScript |

### Location

Script tests MUST be placed in `tests/scripts/<module>/`.

### Naming

- File names SHOULD be descriptive of what the test verifies.
- File names MUST use underscores or hyphens (no spaces).
- Examples: `login_test.py`, `add-to-cart.js`, `checkout_flow.ts`

### Metadata Comments

Metadata comments MUST appear in the first 30 lines of the file.

**Python format:**

```python
# @description: Verify user can log in with valid credentials
# @tags: auth, smoke
# @timeout: 30000
# @retry: 1
```

**JavaScript / TypeScript format:**

```javascript
// @description: Verify user can log in with valid credentials
// @tags: auth, smoke
// @timeout: 30000
// @retry: 1
```

### Supported Metadata Keys

| Key | Type | Description |
|---|---|---|
| `@description` | string | Human-readable description of what the test verifies. |
| `@tags` | comma-separated strings | Tags for categorisation and filtering. |
| `@timeout` | integer (milliseconds) | Maximum execution time. Overrides default. |
| `@retry` | integer | Number of retry attempts if the test fails. Default: 0. |

## Prompt Tests

Prompt tests are plain-text instruction files executed by an AI agent (Claude Code).

### Extension

Prompt tests MUST use the `.prompt` extension.

### Location

Prompt tests MUST be placed in `tests/prompts/<module>/`.

### Format

A `.prompt` file contains free-form natural language instructions describing
what the AI agent should verify or perform. No metadata comments are needed.

### Example

```
Verify that the registration page at https://example.com/register:
1. Contains fields for name, email, and password.
2. Shows validation errors when the form is submitted empty.
3. Successfully creates an account with valid data.
4. Redirects to the welcome page after registration.
```

## Example: Complete Test Structure

```
tests/
  scripts/
    auth/
      login_test.py
      logout_test.py
      password_reset.ts
    checkout/
      add_to_cart.js
      payment_flow.py
  prompts/
    auth/
      test_login_flow.prompt
      test_registration.prompt
    checkout/
      test_purchase_flow.prompt
  bamboo-inspect-skill/
    SKILL.md
  bambooinspect-rules.md
```
