# Bamboo Inspect — Quickstart Guide

Bamboo Inspect has two components:

- **Core Manager** (Docker) — Central server that manages agents, tasks, and results
- **Test Agent** (PyPI) — Lightweight worker that executes tests on any machine

You can also use the **stateless CLI** for quick local test runs without a Core Manager.

---

## Installation (Test Agent)

```bash
pip install bamboo-inspect
```

Verify the installation:

```bash
bambooinspect --version
# bambooinspect 0.2.0
```

---

## 1. Stateless CLI Mode (No Setup Required)

Stateless CLI mode works instantly from any git repo that follows the standard test structure. No Core Manager, no database, no configuration needed.

### Step 1: Create the Test Structure

In your project repository, create the required folder structure:

```
my-project/            # Must be a git repo
└── tests/
    ├── scripts/       # Playwright / script tests
    │   ├── auth/
    │   │   ├── login_test.py
    │   │   └── signup_test.js
    │   └── checkout/
    │       └── cart_test.py
    └── prompts/       # AI prompt tests (Claude Code)
        └── auth/
            └── test_login_flow.prompt
```

- **`tests/scripts/{module}/`** — Playwright tests (`.py`, `.js`, `.ts`)
- **`tests/prompts/{module}/`** — AI prompt tests (`.prompt`)
- Subdirectory names (e.g. `auth`, `checkout`) are **modules**

### Step 2: Add Metadata to Tests (Optional)

Add metadata comments at the top of your test files:

**Python tests:**
```python
# @description: Tests the user login flow
# @tags: auth, login, smoke
# @timeout: 30
# @retry: 2

from playwright.sync_api import sync_playwright
# ... your test code ...
```

**JavaScript/TypeScript tests:**
```javascript
// @description: Tests the shopping cart
// @tags: checkout, cart
// @timeout: 60
// @retry: 1

const { test } = require('@playwright/test');
// ... your test code ...
```

### Step 3: Run Tests

```bash
cd my-project

# Run all script tests
bambooinspect run-all --type script

# Run all prompt tests (requires claude CLI)
bambooinspect run-all --type prompt

# Run a specific module
bambooinspect run-module auth --type script

# Run a single test by name
bambooinspect run login_test --type script
```

### Step 4: Generate Reports

Reports are generated automatically after every run:

```bash
# Save HTML report to a file
bambooinspect run-all --type script --report-output ./report.html

# Save Markdown report
bambooinspect run-all --type script --report-output ./report.md

# Save JSON report
bambooinspect run-all --type script --report-output ./results.json

# Generate an AI-powered summary report (requires claude CLI)
bambooinspect run-all --type script --report ai
```

### Exit Codes

- **0** — All tests passed
- **1** — One or more tests failed

CI/CD example:

```yaml
# GitHub Actions
- name: Install bamboo-inspect
  run: pip install bamboo-inspect

- name: Run tests
  run: bambooinspect run-all --type script
```

---

## 2. Core Manager + Test Agent Setup

For persistent test management with a web dashboard, multiple agents, and result history.

### Step 1: Deploy Core Manager (Docker)

```bash
git clone <repo-url> bamboo_inspect
cd bamboo_inspect

# Start Core Manager with built-in PostgreSQL
make docker-dev

# Or using docker compose directly
docker compose --profile postgres up --build
```

This starts:
- **PostgreSQL 16** on port 5432 (data persisted in Docker volume)
- **Core Manager** on port 8686 (web dashboard + API)
- Database migrations run automatically on startup

Access the dashboard: **http://localhost:8686**

#### External PostgreSQL

If you already have a PostgreSQL server:

```bash
BAMBOOINSPECT_DB_HOST=your-db-host make docker-dev-ext
```

### Step 2: Install & Register a Test Agent

On any machine where you want to run tests:

```bash
pip install bamboo-inspect
```

Generate a registration token from the Core Manager dashboard (click "Generate Agent Token"), then register:

```bash
bambooinspect agent register \
  --url http://core-manager:8686 \
  --token <registration-token> \
  --name my-agent \
  --labels linux,playwright
```

### Step 3: Sync a Repository

The agent scans a local git repo and pushes the test structure to the Core Manager:

```bash
cd ~/my-project
bambooinspect agent sync-repo .
# Scanning: /home/user/my-project
#   Found 8 tests in 3 modules
# Synced to Core Manager: 3 modules, 8 tests
```

### Step 4: Start the Agent

```bash
bambooinspect agent start
# Starting agent 'my-agent'...
#   Core Manager: http://core-manager:8686
#   Web UI: http://127.0.0.1:8787
#   Poll interval: 30s
```

The agent:
- Polls Core Manager for assigned tasks every 30 seconds
- Executes tests locally using Playwright or Claude Code
- Pushes results back to Core Manager
- Serves a monitoring dashboard on **http://localhost:8787**

### Step 5: Assign Tests to Agent

From the Core Manager dashboard:

1. Go to the **Tests** tab to see synced tests
2. Click **Assign to Agent** → select your agent → enter test IDs
3. The agent picks up the task automatically and executes it

Monitor progress in the **Tasks** tab.

### Step 6: Check Agent Status

```bash
bambooinspect agent status
# Agent: my-agent
#   ID:          a1b2c3d4e5f6
#   Core URL:    http://core-manager:8686
#   Labels:      linux, playwright
#   Web UI port: 8787
#   Core Manager: Connected
```

---

## 3. Production Deployment

### Core Manager

```bash
# Copy and configure environment variables
cp .env.example .env
# Edit .env with production database credentials

# Start production stack
make docker-prod
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `BAMBOOINSPECT_DB_HOST` | PostgreSQL host | `localhost` |
| `BAMBOOINSPECT_DB_PORT` | PostgreSQL port | `5432` |
| `BAMBOOINSPECT_DB_NAME` | Database name | `bamboo_inspect` |
| `BAMBOOINSPECT_DB_USER` | Database user | `postgres` |
| `BAMBOOINSPECT_DB_PASSWORD` | Database password | `postgres` |
| `BAMBOOINSPECT_PORT` | Core Manager port | `8686` |
| `BAMBOOINSPECT_HOST` | Bind address | `0.0.0.0` |
| `BAMBOOINSPECT_AGENT_OFFLINE_THRESHOLD` | Seconds before marking agent offline | `90` |

---

## 4. CLI Command Reference

```
bambooinspect --version                          Show version
bambooinspect --help                             Show all commands

# Test execution (stateless — no Core Manager required)
bambooinspect run <test> --type <script|prompt>  Run a single test
bambooinspect run-module <mod> --type <type>     Run all tests in a module
bambooinspect run-all --type <type>              Run all tests of a type

# Options for execution commands
  --tracking <none|session|full>  Override tracking level
  --report ai                    Use AI to generate report
  --report-output <path>         Save report to file

# Agent management
bambooinspect agent register --url <url> --token <token> --name <name> [--labels <labels>]
bambooinspect agent start [--port 8787]          Start agent (poller + web UI)
bambooinspect agent stop                         Stop agent
bambooinspect agent status                       Check agent status
bambooinspect agent sync-repo [path]             Scan local repo, push tests to Core Manager
bambooinspect agent unregister                   Unregister from Core Manager
```

---

## 5. REST API Reference (Core Manager)

### Agent Communication

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/agent/register` | Register agent with token |
| `GET` | `/api/agent/tasks` | Poll for pending tasks (heartbeat) |
| `POST` | `/api/agent/tasks/{id}/start` | Mark task as running |
| `GET` | `/api/agent/tasks/{id}/details` | Get task details |
| `POST` | `/api/agent/tasks/{id}/result` | Submit execution result |
| `POST` | `/api/agent/sync-repo` | Push scanned repo/test data |
| `POST` | `/api/agent/unregister` | Unregister agent |

### Admin Management

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Health check |
| `GET` | `/api/admin/agents` | List agents |
| `DELETE` | `/api/admin/agents/{id}` | Remove agent |
| `POST` | `/api/admin/registration-tokens` | Generate registration token |
| `POST` | `/api/admin/tasks` | Assign tests to agent |
| `GET` | `/api/admin/tasks` | List tasks |
| `POST` | `/api/admin/tasks/{id}/cancel` | Cancel task |
| `GET` | `/api/admin/repos` | List repositories |
| `DELETE` | `/api/admin/repos/{name}` | Remove repository |
| `GET` | `/api/admin/tests` | List tests |
| `GET/POST/DELETE` | `/api/admin/webhooks` | Webhook CRUD |
| `GET/PUT` | `/api/admin/config/{key}` | Configuration |
| `POST` | `/api/git-hook?token=...` | Git hook receiver |

---

## Troubleshooting

**"Error: current directory is not a git repository"**
Stateless CLI commands must be run from inside a git repository.

**"No 'script' tests found"**
Your repo must follow `tests/scripts/{module}/` for scripts, `tests/prompts/{module}/` for prompts.

**"Agent is not registered"**
Run `bambooinspect agent register` first before starting the agent.

**"claude CLI not found"**
Prompt tests require Claude Code CLI: `npm install -g @anthropic-ai/claude-code`

**Core Manager unreachable**
Check that the Core Manager Docker containers are running and the URL is correct.
