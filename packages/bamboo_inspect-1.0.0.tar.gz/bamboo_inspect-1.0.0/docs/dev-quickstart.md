# Developer Quickstart

A guide for developers who want to contribute to the Bamboo Inspect project. Covers local setup, project structure, development workflows, and Docker-based development.

---

## Prerequisites

- **Python 3.10+**
- **Git**
- **Docker & Docker Compose** (for Core Manager development)

---

## Architecture Overview

Bamboo Inspect has two components:

| Component | Code Location | Deployment | Purpose |
|-----------|--------------|------------|---------|
| **Core Manager** | `server/` | Docker | Central server — manages agents, tasks, results. No test execution. |
| **Test Agent** | `src/bamboo_inspect/` | PyPI (`pip install bamboo-inspect`) | Executes tests, polls Core Manager, pushes results. |

The Core Manager is purely a management/data plane. Agents do all the work: scanning repos, executing tests, pushing results.

---

## 1. Local Setup (Test Agent)

### Option A: Using the Makefile (recommended)

```bash
git clone <repo-url> bamboo_inspect
cd bamboo_inspect

# Create virtualenv and install agent package in editable mode
make install

# Activate the virtualenv
source .venv/bin/activate

# Verify it works
bambooinspect --version
```

### Option B: Manual setup

```bash
git clone <repo-url> bamboo_inspect
cd bamboo_inspect

python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -e ".[dev]"
```

After installation, the `bambooinspect` CLI is available in your shell.

---

## 2. Project Structure

```
bamboo_inspect/
├── src/bamboo_inspect/           # Test Agent (PyPI package "bamboo-inspect")
│   ├── __init__.py            # Package version
│   ├── cli.py                 # Typer CLI — stateless + agent commands
│   ├── config.py              # Agent config loader
│   ├── scanner.py             # Test discovery from tests/ folder
│   ├── utils.py               # Hash ID generation
│   ├── agent/                 # Agent core modules
│   │   ├── client.py          # HTTP client for Core Manager API
│   │   ├── poller.py          # Polling loop (fetch tasks, execute, push)
│   │   ├── registration.py    # Agent registration flow
│   │   └── state.py           # Local state (~/.bambooinspect/agent.yaml)
│   ├── executors/
│   │   ├── playwright.py      # Runs .py/.js/.ts test scripts
│   │   └── claude_code.py     # Runs .prompt files via Claude Code
│   ├── git/
│   │   └── manager.py         # Repository validation & git metadata
│   ├── report/
│   │   ├── renderer.py        # Report generation (HTML/MD/JSON)
│   │   └── templates/         # Built-in report templates
│   └── web/
│       ├── app.py             # Agent web UI (FastAPI, port 8787)
│       └── static/            # Agent dashboard HTML/JS/CSS
├── server/                    # Core Manager (Docker only, NOT in PyPI)
│   ├── app.py                 # FastAPI main application
│   ├── config.py              # Server config (environment variables)
│   ├── main.py                # Server entry point
│   ├── requirements.txt       # Server Python dependencies
│   ├── api/
│   │   ├── admin_routes.py    # Admin API (agents, tokens, tasks, repos)
│   │   ├── agent_routes.py    # Agent communication API
│   │   ├── auth.py            # Agent token auth middleware
│   │   └── git_hook.py        # Git webhook receiver
│   ├── db/
│   │   ├── connection.py      # asyncpg pool management
│   │   └── queries.py         # All raw SQL queries
│   ├── services/
│   │   ├── agent_manager.py   # Agent registration, token management
│   │   ├── heartbeat_monitor.py # Agent health monitoring
│   │   ├── task_manager.py    # Task assignment, result processing
│   │   └── webhook_dispatcher.py # Outgoing webhook sender
│   └── web/
│       └── static/            # Core Manager dashboard HTML/JS/CSS
├── databases/                 # Database config and migrations
│   ├── bamboo_database.toml   # Database config for bamboodb
│   └── migrations/default/    # SQL migration files (bamboodb)
├── docker/                    # Docker configuration
│   ├── Dockerfile             # Core Manager production build
│   ├── Dockerfile.dev         # Core Manager development build
│   ├── docker-compose.yml     # Core Manager dev compose
│   ├── docker-compose.prod.yml # Core Manager production compose
│   └── docker-entrypoint.sh   # Docker entrypoint (migrate + start)
├── pyproject.toml             # Agent PyPI packaging (NOT server)
├── Makefile                   # Dev workflow shortcuts
├── CLAUDE.md                  # AI assistant context
└── README.md
```

### Key files to know

| File | What it does |
|------|-------------|
| `src/bamboo_inspect/cli.py` | Agent CLI — stateless test commands + `agent` subcommand group |
| `src/bamboo_inspect/agent/poller.py` | Polling loop — fetches tasks from Core Manager, executes, pushes results |
| `src/bamboo_inspect/agent/client.py` | HTTP client wrapper for all Core Manager API calls |
| `src/bamboo_inspect/scanner.py` | Discovers tests from `tests/scripts/` and `tests/prompts/` |
| `server/app.py` | Core Manager FastAPI app — mounts all API routes |
| `server/api/agent_routes.py` | Agent-facing API endpoints (register, poll, result, sync-repo) |
| `server/api/admin_routes.py` | Admin API (agents, tokens, tasks, repos, webhooks, config) |
| `server/db/queries.py` | All database queries (raw SQL via asyncpg) |
| `server/services/agent_manager.py` | Agent registration & token management logic |
| `server/services/task_manager.py` | Task assignment & result processing logic |

---

## 3. Development Workflow

### Daily commands

```bash
# Format code (auto-fix style issues)
make format

# Lint (check for errors without fixing)
make lint

# Build the agent package (sdist + wheel)
make build

# Clean build artifacts
make clean
```

### Code style

- **Linter/formatter:** Ruff
- **Target:** Python 3.10
- **Line length:** 120 characters
- **Rules:** E, F, W, I (errors, pyflakes, warnings, isort)

---

## 4. Core Manager Development (Docker)

Docker is the primary way to develop and run the Core Manager.

### Build Docker images

```bash
# Build dev image (built-in PostgreSQL)
make docker-build

# Build dev image (external PostgreSQL)
make docker-build-ext

# Build production image
make docker-build-prod
make docker-build-prod-ext
```

### Start development environment

```bash
# Built-in PostgreSQL (zero setup)
make docker-dev

# External PostgreSQL (set DB credentials in .env)
make docker-dev-ext
```

This starts:
- **PostgreSQL 16** container on port 5432
- **Core Manager** on port 8686
- `server/` directory mounted for live reload
- Migrations run automatically on startup

### Access the dashboard

```
http://localhost:8686
```

### Hot reload

The `server/` directory is volume-mounted. Edit files locally and changes are reflected immediately — no rebuild needed.

### Rebuild after dependency changes

If you change `server/requirements.txt`:

```bash
make docker-down
make docker-build
make docker-dev
```

### Stop everything

```bash
make docker-down
```

### Docker file reference

All Docker files are located in the `docker/` directory:

| File | Purpose |
|------|---------|
| `docker/Dockerfile` | Production image — slim Python, installs requirements, copies server code |
| `docker/Dockerfile.dev` | Dev image — same + ruff, volume mount for hot-reload |
| `docker/docker-compose.yml` | Dev compose — profiles for built-in PG or external DB |
| `docker/docker-compose.prod.yml` | Production compose — same profile structure |
| `docker/docker-entrypoint.sh` | Runs `bamboodb migrate`, then starts `python -m server.main` |
| `server/requirements.txt` | Server-only dependencies (fastapi, asyncpg, psycopg2-binary, etc.) |

---

## 5. Database Migrations

Bamboo Inspect uses [bamboo-database](https://pypi.org/project/bamboo-database/) (`bamboodb` CLI) for raw SQL migrations.

### Configuration

Database connection is defined in `databases/bamboo_database.toml`:

```toml
[databases.default]
type = "postgresql"
host = "localhost"
port = 5432
database = "bamboo_inspect"
user = "postgres"
password = "secret"
migrations_path = "./databases/migrations/default"
```

### Migration file naming

```
{version}_{type}_{description}.sql
```

Where `{type}` is one of: `migrate`, `seed`, or `index`.

Examples:
```
0001_migrate_initial_schema.sql
0002_migrate_add_agent_tables.sql
```

### Commands

```bash
bamboodb migrate     # Run pending migrations
bamboodb status      # Check migration status
```

### Adding a new migration

1. Create a new SQL file in `databases/migrations/default/`
2. Run `bamboodb migrate`

> In Docker, migrations run automatically on container startup.

---

## 6. Data Flow

### Agent syncs repo → Core Manager stores metadata

```
Agent (local machine)                   Core Manager (Docker)
──────────────────                      ─────────────────────
bambooinspect agent sync-repo .
  └─ scanner.py scans tests/            
  └─ POST /api/agent/sync-repo ──────► Stores project, modules,
                                        tests in PostgreSQL
```

### Admin assigns task → Agent executes

```
Admin (dashboard)                       Core Manager              Agent
─────────────────                       ─────────────             ─────
Select tests + agent
  └─ POST /api/admin/tasks ──────────► Creates Execution records
                                        with agent_id=...
                                                                  GET /api/agent/tasks
                                        Returns pending tasks ──► Picks up task
                                                                  POST .../start
                                                                  Executes test locally
                                                                  POST .../result ──────► Updates Execution,
                                                                                          RunSession, webhooks
```

### Key design decisions

- **No ORM** — all database access is raw SQL via asyncpg
- **No foreign keys** — tables reference each other via hash IDs
- **Async everywhere** — FastAPI + asyncpg + asyncio for all I/O
- **Core Manager has no git/filesystem access** — agents push all data
- **Agent polls Core Manager** (pull model, like GitHub Actions runners)
- **psycopg2-binary** — no gcc/libpq needed in Docker images

---

## 7. Adding Features

### Adding an agent CLI command

1. Open `src/bamboo_inspect/cli.py`
2. Add to `agent_app` for agent commands, or `app` for stateless commands

```python
@agent_app.command()
def my_command(
    name: str = typer.Argument(..., help="The name"),
) -> None:
    """Description shown in --help."""
    typer.echo(f"Hello {name}")
```

### Adding a Core Manager API endpoint

1. Choose the right route file in `server/api/`:
   - `agent_routes.py` — endpoints agents call
   - `admin_routes.py` — endpoints admins/dashboard call
2. Add a new route function

```python
@router.get("/my-endpoint")
async def my_endpoint(request: Request) -> dict:
    pool = request.app.state.pool
    # Use pool to query database
    return {"status": "ok"}
```

### Adding a database query

1. Open `server/db/queries.py`
2. Add a new async function

```python
async def get_my_data(pool, id: str):
    row = await pool.fetchrow("SELECT * FROM my_table WHERE id = $1", id)
    return dict(row) if row else None
```

### Adding a database migration

1. Create: `databases/migrations/default/NNNN_{type}_{description}.sql`
2. In Docker, it runs automatically on next restart
3. Locally: `bamboodb migrate`

---

## 8. Makefile Reference

| Target | Description |
|--------|-------------|
| `make install` | Agent: Create `.venv` and install agent package + dev tools |
| `make lint` | General: Run ruff linter on `src/` and `server/` |
| `make format` | General: Auto-format code with ruff |
| `make test` | Agent: Run tests locally (stateless CLI mode) |
| `make build` | Agent: Build Python package (sdist + wheel) |
| `make clean` | General: Remove build artifacts and caches |
| `make docker-build` | Core Manager: Build dev image (built-in PostgreSQL) |
| `make docker-build-ext` | Core Manager: Build dev image (external PostgreSQL) |
| `make docker-build-prod` | Core Manager: Build production image (built-in PostgreSQL) |
| `make docker-build-prod-ext` | Core Manager: Build production image (external PostgreSQL) |
| `make docker-dev` | Core Manager: Start dev with built-in PostgreSQL |
| `make docker-dev-ext` | Core Manager: Start dev with external PostgreSQL |
| `make docker-prod` | Core Manager: Start production with built-in PostgreSQL |
| `make docker-prod-ext` | Core Manager: Start production with external PostgreSQL |
| `make docker-down` | Core Manager: Stop all Docker containers |

---

## 9. Troubleshooting

**`ModuleNotFoundError: No module named 'bamboo_inspect'`**
Make sure you installed in editable mode and activated the virtualenv:
```bash
source .venv/bin/activate
pip install -e ".[dev]"
```

**`bamboodb: command not found`**
The `bamboodb` CLI is only needed for Core Manager database work. Install server deps separately if needed, or use Docker where migrations run automatically.

**Port 8686 already in use**
Stop running Docker containers:
```bash
make docker-down
```

**Port 8787 already in use**
Stop the running agent or use a different port:
```bash
bambooinspect agent start --port 9999
```

**Agent can't connect to Core Manager**
Check that the Core Manager is running and the URL is correct:
```bash
bambooinspect agent status
```
