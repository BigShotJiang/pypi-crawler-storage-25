# Bamboo Inspect — Project Profile

## Identity & Branding
**Bamboo Inspect** is a modern, open-source test management system designed for scalability and resilience.

- **Core Concept**: "Growth Meets Technology" — Represented by bamboo (resilience, rapid growth) integrated with digital precision.
- **Visual Identity**:
  - **Primary Color**: Emerald Green (`#10b981`) — Symbolizing pass status, growth, and stability.
  - **Accent Color**: Violet Purple (`#8b5cf6`) — representing the Deep Tech/AI core and modernization.
  - **Logo**: A minimalist, high-contrast geometric bamboo joint with a digital accent, designed for clarity at small sizes.
  - **Theme**: Dark mode default (`#09090b`), using glassmorphism and modern gradients.

## Mission
To provide a lightweight, self-hosted alternative to complex enterprise test management tools, specifically optimized for **Playwright** and **AI-driven testing** (Claude Code). It bridges the gap between local execution and orchestrated CI/CD.

## High-Level Architecture
Bamboo Inspect adopts a **"GitHub Actions-like"** architecture:

### 1. Core Manager (The Brain)
- **Role**: Central control plane. Manages state, assigns tasks, and stores results.
- **Tech**: Docker, FastAPI, PostgreSQL (asyncpg, no ORM).
- **Constraints**: No direct file system access; purely metadata-driven.

### 2. Test Agent (The Muscle)
- **Role**: Distributed execution units. They sit where the code is.
- **Tech**: Python Package (`pip install bamboo-inspect`), Typer CLI.
- **Capabilities**:
  - **Discovery**: Scans local git repositories for tests.
  - **Execution**: Runs Playwright scripts or AI prompts via `subprocess` or `llm` libs.
  - **Reporting**: Pushes results back to Core.

## Project Structure
- `server/`: Core Manager (Docker context).
- `src/bamboo_inspect/`: Agent package source (PyPI).
- `tests/`: Project's own test suite.

## Key Differentiators
1. **Stateless Mode**: The CLI can run tests locally without a server, offering zero-setup value immediately.
2. **AI-First Design**: Native support for prompt-based testing alongside traditional scripts.
3. **Pull-Based Model**: Agents poll for work, allowing them to run behind firewalls without complex networking (just like GH Runners).
