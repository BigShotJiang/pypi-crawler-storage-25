# Docker Troubleshooting Guide

Common issues encountered when running Bamboo Inspect with Docker, and how to fix them.

---

## 1. `invalid containerPort` — Port Number Too High

**Error:**
```
invalid containerPort: 66666
```

**Cause:** Docker container ports must be less than 65535. Port `66666` exceeds this limit.

**Fix:** Use a valid port number (e.g., `8686`). Set via the `BAMBOOINSPECT_PORT` environment variable or update the default in `pyproject.toml` / `config.py`.

---

## 2. `ERR_UNSAFE_PORT` — Browser Blocks the Port

**Error:** Chrome/Edge shows:
```
This site can't be reached
ERR_UNSAFE_PORT
```

**Cause:** Browsers maintain a list of restricted ports for security reasons. Port `6666` is blocked because it is associated with the IRC protocol.

**Blocked ports commonly hit:**
- `6666`, `6667`, `6668`, `6669` (IRC)
- `6000` (X11)

**Fix:** Use a non-restricted port. Bamboo Inspect defaults to `8686`, which is safe for all browsers.

---

## 3. `Readme file does not exist: README.md` — Docker Build Fails

**Error:**
```
OSError: Readme file does not exist: README.md
```

**Cause:** The `pyproject.toml` declares `readme = "README.md"`, and hatchling validates this file exists during build. If `README.md` is excluded by `.dockerignore` or not copied in the Dockerfile, the build fails.

**Fix:** Ensure both the Dockerfile and `.dockerignore` include `README.md`:

- In `Dockerfile` / `Dockerfile.dev`:
  ```dockerfile
  COPY pyproject.toml README.md ./
  ```

- In `.dockerignore`, add an exception after `*.md`:
  ```
  *.md
  !README.md
  ```

---

## 4. Container Cannot Connect to External PostgreSQL

**Error:**
```
Error: PostgreSQL at 10.x.x.x:5432 is not reachable after 30 attempts.
```

**Cause:** The entrypoint script used a Python socket check (`socket.connect()`) to verify PostgreSQL connectivity before starting the daemon. This check silently failed inside the Docker container (with errors suppressed by `2>/dev/null`), even though the database was actually reachable — confirmed by `nc -z -v` succeeding from inside the same container.

**Fix:** The Python socket check was removed entirely. The entrypoint now runs `bamboodb migrate` directly, which will fail with a clear error if the database is unreachable. No pre-flight connectivity check is needed.

If you do need to debug connectivity from inside a container, use `nc`:

```bash
# Enter the running container
docker exec -it <container> bash

# Test connectivity
nc -z -v your-db-host 5432
```

> **Note:** The `netcat-openbsd` package is installed in both the dev and production Docker images for debugging purposes.

---

## 5. `bamboodb migrate` Fails — Configuration File Not Found

**Error:**
```
Error: Configuration file not found: /app/bamboo_database.toml
```

**Cause:** The `bamboo_database.toml` file and `migrations/` directory were not copied into the Docker image.

**Fix:** Ensure both are copied in the Dockerfile:

```dockerfile
COPY migrations/ migrations/
COPY bamboo_database.toml .
```

---

## 6. `No such option: --host` — Daemon Start Fails

**Error:**
```
Error: No such option: --host Did you mean --port?
```

**Cause:** The `bambooinspect daemon` CLI command only accepts `--port`, not `--host`. The host is configured via `~/.bambooinspect/config.yaml` (the `daemon.host` field), not a CLI flag.

**Fix:** Remove `--host` from the Docker CMD. The entrypoint script already generates `config.yaml` with `host: "0.0.0.0"`:

```dockerfile
CMD ["bambooinspect", "daemon"]
```

---

## 7. Slow Dependency Resolution — pip Backtracking

**Symptom:** Docker build takes a very long time, with pip downloading dozens of versions of the same package (e.g., pydantic):

```
INFO: pip is looking at multiple versions of pydantic to determine
which version is compatible with other requirements. This could take a while.
  Downloading pydantic-2.12.4-py3-none-any.whl
  Downloading pydantic-2.12.3-py3-none-any.whl
  Downloading pydantic-2.12.2-py3-none-any.whl
  ...
```

**Cause:** The bundled pip version in the Docker base image has a weaker dependency resolver. Combined with loose version bounds (`>=0.9.0`), pip backtracks through many versions trying to find a compatible set.

**Fix:**
1. Upgrade pip before installing dependencies in the Dockerfile:
   ```dockerfile
   RUN pip install --no-cache-dir --upgrade pip && \
       pip install --no-cache-dir -e ".[dev]"
   ```

2. Use reasonable lower bounds in `pyproject.toml` (don't pin too low):
   ```toml
   dependencies = [
       "fastapi>=0.115.0",  # not >=0.100.0
       "typer[all]>=0.15.0",  # not >=0.9.0
   ]
   ```

3. Avoid pinning transitive dependencies (like `pydantic`) directly — let the framework (fastapi) pull the version it needs.

---

## Quick Reference

| Issue | Root Cause | Fix |
|-------|-----------|-----|
| `invalid containerPort` | Port > 65535 | Use port < 65535 (default: `8686`) |
| `ERR_UNSAFE_PORT` | Browser blocks port | Avoid IRC ports (6666-6669) |
| `Readme file does not exist` | README.md not in Docker context | Copy README.md in Dockerfile + `.dockerignore` exception |
| Can't reach external DB | Bridge network isolation | Use `make docker-dev-ext` (host network) |
| `bamboo_database.toml` not found | File not copied to image | Add `COPY bamboo_database.toml .` to Dockerfile |
| `--host` not recognized | CLI has no `--host` flag | Use `config.yaml` for host setting |
| Slow pip resolution | Old pip + loose version bounds | Upgrade pip + use tighter lower bounds |
