# Agent Heartbeat Specification

## Overview

The heartbeat mechanism ensures the Core Manager can track agent availability. Agents send periodic heartbeat signals via their polling requests, and the Core Manager detects offline agents when heartbeats stop.

---

## Requirements

### Requirement: Agent Heartbeat Mechanism

The Test Agent MUST send periodic heartbeat signals to the Core Manager to indicate it is alive and available.

#### Scenario: Heartbeat during polling
- **WHEN** the agent polls the Core Manager for tasks via `GET /api/agent/tasks`
- **THEN** the Core Manager MUST update the agent's `last_heartbeat_at` timestamp
- **AND** the agent's status MUST remain `idle` (if no task running) or `busy` (if task running)

#### Scenario: Heartbeat interval
- **WHEN** the agent is running
- **THEN** it MUST poll the Core Manager at a configurable interval (default: 30 seconds)
- **AND** each successful poll MUST serve as a heartbeat

---

### Requirement: Agent Status Lifecycle

The Core Manager MUST track each agent's status through a defined lifecycle.

#### Scenario: Agent comes online
- **WHEN** an agent successfully registers or reconnects after being offline
- **THEN** its status MUST be set to `online`
- **AND** transition to `idle` on the next successful poll with no pending tasks

#### Scenario: Agent becomes idle
- **WHEN** an agent has no tasks running and polls successfully
- **THEN** its status MUST be `idle`

#### Scenario: Agent becomes busy
- **WHEN** an agent picks up a task and begins execution
- **THEN** its status MUST transition to `busy`

#### Scenario: Agent goes offline
- **WHEN** the Core Manager has not received a heartbeat from an agent for 90 seconds (3 missed intervals at 30s)
- **THEN** the Core Manager MUST mark the agent's status as `offline`

#### Scenario: Agent reconnects
- **WHEN** an offline agent resumes polling
- **THEN** the Core Manager MUST transition the agent's status back to `idle` or `busy` (depending on task state)

---

### Requirement: Offline Detection

The Core Manager MUST actively detect and mark agents that have stopped responding.

#### Scenario: Periodic offline check
- **WHEN** the Core Manager runs its periodic health check (every 30 seconds)
- **THEN** it MUST query all agents where `last_heartbeat_at` is older than the offline threshold (default: 90 seconds)
- **AND** mark those agents as `offline`

#### Scenario: Stale task detection
- **WHEN** an agent is marked `offline`
- **AND** it has tasks in `running` status that exceed their timeout plus a 60-second grace period
- **THEN** the Core Manager MUST mark those tasks as `failed` with error message "Agent offline during execution"

---

### Requirement: Agent Status Visibility

The Core Manager MUST expose agent status information to administrators.

#### Scenario: List agents with status
- **WHEN** an admin queries `GET /api/admin/agents`
- **THEN** the response MUST include each agent's current status (`idle`, `busy`, `offline`), name, labels, last heartbeat time, and OS info

#### Scenario: Agent status in dashboard
- **WHEN** an admin views the Core Manager web dashboard
- **THEN** the agents panel MUST show each agent with a visual status indicator (green=idle, yellow=busy, red=offline)
- **AND** display the time since last heartbeat
