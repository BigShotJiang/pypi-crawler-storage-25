# Test Scanner Specification

## Overview

The Test Scanner is responsible for discovering and registering test files from repositories following the standard test structure convention. It operates in stateless CLI mode (scan on every invocation, runs on the Test Agent) and Core Manager mode (cached with database storage, managed by the Core Manager).

---

## Requirements

### Requirement: Standard Directory Structure

The scanner MUST enforce the standard test directory structure.

#### Scenario: Valid test structure
- GIVEN a repository with the following structure:
  ```
  tests/
    scripts/
      auth/
        login_test.py
    prompts/
      auth/
        test_login_flow.prompt
  ```
- WHEN the scanner scans the repository
- THEN it MUST discover 1 script test and 1 prompt test
- AND organize them under the `auth` module

#### Scenario: Missing tests directory
- GIVEN a repository with no `tests/` directory at the root
- WHEN the scanner scans the repository
- THEN it MUST return an empty result set
- AND report that no test directory was found

---

### Requirement: Script Test Discovery

The scanner MUST discover Playwright test files in `tests/scripts/{module}/`.

#### Scenario: Discover Python test files
- GIVEN `tests/scripts/auth/login_test.py` exists
- WHEN the scanner scans for script tests
- THEN it MUST register a test with name `login_test`, type `script`, module `auth`

#### Scenario: Discover JavaScript test files
- GIVEN `tests/scripts/checkout/cart_test.js` exists
- WHEN the scanner scans for script tests
- THEN it MUST register a test with name `cart_test`, type `script`, module `checkout`

#### Scenario: Discover TypeScript test files
- GIVEN `tests/scripts/checkout/payment_test.ts` exists
- WHEN the scanner scans for script tests
- THEN it MUST register a test with name `payment_test`, type `script`, module `checkout`

#### Scenario: Supported file extensions
- GIVEN files with extensions `.py`, `.js`, `.ts` in `tests/scripts/`
- WHEN the scanner scans for script tests
- THEN it MUST recognize all three extensions as valid script tests
- AND ignore files with other extensions

---

### Requirement: Prompt Test Discovery

The scanner MUST discover AI prompt files in `tests/prompts/{module}/`.

#### Scenario: Discover prompt files
- GIVEN `tests/prompts/auth/test_login_flow.prompt` exists
- WHEN the scanner scans for prompt tests
- THEN it MUST register a test with name `test_login_flow`, type `prompt`, module `auth`

#### Scenario: Supported prompt extension
- GIVEN files in `tests/prompts/`
- WHEN the scanner scans for prompt tests
- THEN it MUST recognize only `.prompt` files as valid prompt tests

---

### Requirement: Module Organization

The scanner MUST organize tests into modules based on subdirectory names.

#### Scenario: Multiple modules
- GIVEN tests exist in `tests/scripts/auth/` and `tests/scripts/checkout/`
- WHEN the scanner scans the repository
- THEN it MUST register two modules: `auth` and `checkout`
- AND associate each test with its corresponding module

#### Scenario: Nested directories ignored
- GIVEN `tests/scripts/auth/helpers/util.py` exists (nested beyond module level)
- WHEN the scanner scans the repository
- THEN it MAY ignore files in nested subdirectories beyond the module level
- OR it MAY include them as part of the parent module

---

### Requirement: Test Metadata Parsing

The scanner MUST parse metadata from test files when available.

#### Scenario: Parse metadata from script test
- GIVEN a script test file containing metadata comments:
  ```python
  # @description: Tests user login flow
  # @tags: auth, login, smoke
  # @timeout: 30
  # @retry: 2
  ```
- WHEN the scanner parses the file
- THEN it MUST extract description, tags, timeout, and retry_count

#### Scenario: No metadata
- GIVEN a test file with no metadata comments
- WHEN the scanner parses the file
- THEN it MUST use default values (no description, empty tags, default timeout, no retry)

---

### Requirement: Stateless CLI Mode Scanning

In stateless CLI mode, the scanner MUST scan the repository fresh on every invocation. This behavior is unchanged and runs on the Test Agent.

#### Scenario: Fresh scan each invocation
- GIVEN the user runs `bambooinspect run-all --type script`
- WHEN the CLI starts
- THEN the scanner MUST scan the current git repo root for tests
- AND NOT rely on any cached data

---

### Requirement: Daemon Mode Scanning

In daemon mode, scanning responsibility is split: the Core Manager stores and manages the test structure in its database, but the actual filesystem scanning happens through the Core Manager's access to the repository path. Agents do NOT scan for the Core Manager.

#### Scenario: Initial scan on repo registration
- GIVEN an admin registers a repo via the Core Manager API or dashboard
- WHEN the repo is registered
- THEN the Core Manager MUST perform a scan of the repository path and store results in the database

#### Scenario: Rescan on demand
- GIVEN an admin triggers a rescan via the Core Manager API or dashboard
- THEN the Core Manager MUST perform a fresh scan and update the database

#### Scenario: Git event triggered rescan
- GIVEN a git webhook event is received for a registered repo
- WHEN the event indicates file changes in the `tests/` directory
- THEN the Core Manager SHOULD rescan the affected modules

---

### Requirement: Unique Test Identification

The scanner MUST generate unique hash IDs for each test, module, and project.

#### Scenario: Consistent hash generation
- GIVEN a test at `tests/scripts/auth/login_test.py` in project `my-project`
- WHEN the scanner generates an ID
- THEN the ID MUST be deterministic (same input always produces the same hash)
- AND the ID MUST be unique across different tests
