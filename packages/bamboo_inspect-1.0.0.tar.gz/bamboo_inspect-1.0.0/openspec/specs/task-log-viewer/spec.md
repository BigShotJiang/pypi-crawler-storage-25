## ADDED Requirements

### Requirement: View Task Logs
The application SHALL allow users to view execution logs for a specific task.

#### Scenario: Open Logs
- **WHEN** user clicks "View Logs" on a task row
- **THEN** a modal opens displaying the text logs fetched from the server
