## ADDED Requirements

### Requirement: Delete Resources
The application SHALL allow users to delete Agents, Repositories, and Webhooks.

#### Scenario: Delete Agent
- **WHEN** user clicks "Delete" on an agent row and confirms
- **THEN** agent is removed from the system and the list updates

### Requirement: Create Resources
The application SHALL allow users to register new Agents (token), Repositories, and Webhooks.

#### Scenario: Add Repository
- **WHEN** user opens "Add Repository" modal and submits valid details
- **THEN** new repository is added to the list
