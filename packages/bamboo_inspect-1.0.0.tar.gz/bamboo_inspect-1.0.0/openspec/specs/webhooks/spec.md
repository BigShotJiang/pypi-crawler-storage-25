# Webhook Integration Specification

## Overview

Bamboo Inspect supports two types of webhook integration: **outgoing webhooks** that send test results to external services, and **incoming webhooks** (git hooks) that trigger test runs from git providers. Both are daemon mode only features.

---

## Requirements

### Requirement: Outgoing Webhook Dispatch

The system MUST send test results to registered webhook URLs via HTTP POST.

#### Scenario: Send result on test completion
- GIVEN a webhook is registered with URL `https://example.com/hook`
- AND the webhook is active
- WHEN a test execution completes
- THEN the system MUST send an HTTP POST to `https://example.com/hook`
- AND the request body MUST be JSON with the following structure:
  ```json
  {
    "test_id": "<hash>",
    "status": "passed|failed",
    "duration": 1234,
    "error": null,
    "logs": "...",
    "artifacts": {},
    "timestamp": "2026-01-01T00:00:00Z"
  }
  ```

#### Scenario: Inactive webhook
- GIVEN a webhook is registered but `active` is `false`
- WHEN a test execution completes
- THEN the system MUST NOT send a request to that webhook

---

### Requirement: Custom Headers and Authentication

The system MUST support custom headers and authentication on outgoing webhooks.

#### Scenario: Bearer token authentication
- GIVEN a webhook with `auth_type: bearer` and a configured token
- WHEN sending the webhook request
- THEN the system MUST include an `Authorization: Bearer <token>` header

#### Scenario: Basic authentication
- GIVEN a webhook with `auth_type: basic` and configured username/password
- WHEN sending the webhook request
- THEN the system MUST include a properly encoded `Authorization: Basic <credentials>` header

#### Scenario: Custom headers
- GIVEN a webhook with custom headers `{"X-Custom-Header": "value"}`
- WHEN sending the webhook request
- THEN the system MUST include the custom headers in the request

---

### Requirement: Retry Logic

The system MUST implement retry logic for failed webhook deliveries.

#### Scenario: Retry on failure
- GIVEN a webhook with `retry_count: 3`
- WHEN the initial webhook delivery fails (HTTP error or timeout)
- THEN the system MUST retry up to 3 additional times

#### Scenario: Exponential backoff
- GIVEN a webhook delivery fails and retries are configured
- THEN the system MUST use exponential backoff between retries
- AND the backoff intervals SHOULD be approximately 1s, 2s, 4s, etc.

#### Scenario: Webhook timeout
- GIVEN `webhooks.timeout_seconds: 10` in the config
- WHEN sending a webhook request
- THEN the system MUST timeout after 10 seconds if no response is received

---

### Requirement: Event Filtering

The system MUST support filtering which events trigger a webhook.

#### Scenario: Event filter
- GIVEN a webhook with `events: ["test_passed", "test_failed"]`
- WHEN a test passes
- THEN the system MUST send the webhook
- WHEN a test is skipped
- THEN the system MUST NOT send the webhook

---

### Requirement: Incoming Git Hook Receiver

The system MUST provide an endpoint to receive git webhook events from GitHub, GitLab, and Gitea.

#### Scenario: Git hook endpoint
- GIVEN the daemon is running
- THEN the system MUST expose `POST /api/git-hook` endpoint
- AND accept a `token` query parameter for authentication

#### Scenario: Token validation
- GIVEN a git hook request to `/api/git-hook?token=SECRET`
- WHEN the token matches a registered project's hook token
- THEN the request MUST be accepted
- WHEN the token does not match
- THEN the request MUST be rejected with HTTP 401

---

### Requirement: Git Event Parsing

The system MUST parse push and PR events from major git providers.

#### Scenario: GitHub push event
- GIVEN a GitHub webhook payload with event type `push`
- WHEN the system receives the event
- THEN it MUST extract:
  - Repository name/URL
  - Branch name
  - Commit SHA
  - List of changed files

#### Scenario: GitLab push event
- GIVEN a GitLab webhook payload with event type `push`
- WHEN the system receives the event
- THEN it MUST extract the same information as GitHub push events

#### Scenario: Gitea push event
- GIVEN a Gitea webhook payload with event type `push`
- WHEN the system receives the event
- THEN it MUST extract the same information as GitHub push events

---

### Requirement: Automatic Test Triggering from Git Events

The system MUST automatically trigger relevant tests based on git events.

#### Scenario: Changed files trigger module tests
- GIVEN a push event with changed files in `src/auth/login.py`
- AND there are tests in `tests/scripts/auth/`
- THEN the system MUST trigger all tests in the `auth` module

#### Scenario: Commit message trigger all
- GIVEN a push event with commit message containing `[test all]`
- THEN the system MUST trigger all tests in the repository

#### Scenario: No matching tests
- GIVEN a push event with changed files that don't map to any test module
- THEN the system MAY skip test execution
- OR run a default set of tests if configured
