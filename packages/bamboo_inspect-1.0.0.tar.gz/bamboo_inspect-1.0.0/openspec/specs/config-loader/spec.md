# config-loader Specification

## Overview

The configuration system loads settings from YAML files for both stateless CLI mode and agent mode. Agent-specific configuration is stored in `~/.bambooinspect/agent.yaml`, while general CLI config uses `~/.bambooinspect/config.yaml`. The Core Manager uses environment variables (Docker-standard).

---

## Requirements

### Requirement: Config File Location

The system MUST load configuration from `~/.bambooinspect/config.yaml` for local stateless CLI usage. Agent-specific settings are loaded from `~/.bambooinspect/agent.yaml`.

#### Scenario: Config file exists
- **WHEN** `~/.bambooinspect/config.yaml` exists with valid YAML content
- **THEN** the system MUST parse the file and apply the configuration values for stateless CLI mode

#### Scenario: Config file does not exist
- **WHEN** `~/.bambooinspect/config.yaml` does not exist
- **THEN** the system MUST use hardcoded default values for all settings
- **AND** the system MUST NOT create the file automatically

#### Scenario: Config directory does not exist
- **WHEN** `~/.bambooinspect/` directory does not exist
- **THEN** the system MUST use hardcoded default values
- **AND** the system MUST NOT create the directory automatically

#### Scenario: Invalid YAML syntax
- **WHEN** `~/.bambooinspect/config.yaml` contains invalid YAML
- **THEN** the system MUST display a clear error message indicating the config file is malformed
- **AND** the system MUST NOT start

---

### Requirement: Agent Configuration File

The Test Agent MUST load agent-specific configuration from `~/.bambooinspect/agent.yaml`.

#### Scenario: Agent config after registration
- **WHEN** the agent has registered with a Core Manager
- **THEN** `~/.bambooinspect/agent.yaml` MUST contain:
  - `core_url`: URL of the Core Manager (e.g., `http://core:8686`)
  - `agent_token`: persistent authentication token
  - `agent_id`: unique agent identifier
  - `agent_name`: agent display name

#### Scenario: Agent config with optional settings
- **WHEN** `~/.bambooinspect/agent.yaml` includes optional settings
- **THEN** the agent MUST support:
  - `agent.port` (int, default 8787): agent web UI port
  - `agent.host` (str, default "127.0.0.1"): agent web UI bind address
  - `agent.poll_interval` (int, default 30): seconds between Core Manager polls
  - `agent.labels` (list[str]): agent labels (can also be set during registration)

#### Scenario: Agent config does not exist
- **WHEN** `~/.bambooinspect/agent.yaml` does not exist
- **AND** the user runs `bambooinspect agent start`
- **THEN** the agent MUST display an error indicating it is not registered

---

### Requirement: Core Manager Configuration

The Core Manager MUST load server configuration from environment variables (Docker-standard) with fallback to a config file.

#### Scenario: Environment variable configuration
- **WHEN** the Core Manager starts in Docker
- **THEN** it MUST read configuration from environment variables:
  - `BAMBOOINSPECT_DB_HOST` (default: `localhost`)
  - `BAMBOOINSPECT_DB_PORT` (default: `5432`)
  - `BAMBOOINSPECT_DB_NAME` (default: `bamboo_inspect`)
  - `BAMBOOINSPECT_DB_USER` (default: `postgres`)
  - `BAMBOOINSPECT_DB_PASSWORD` (default: `secret`)
  - `BAMBOOINSPECT_PORT` (default: `8686`)
  - `BAMBOOINSPECT_HOST` (default: `0.0.0.0`)
  - `BAMBOOINSPECT_ACCESS_MODE` (default: `lan`)
  - `BAMBOOINSPECT_AUTH_TOKEN` (optional)
  - `BAMBOOINSPECT_AGENT_OFFLINE_THRESHOLD` (default: `90` seconds)

---

### Requirement: Default Configuration Values

The system MUST provide sensible defaults for all configuration keys so that zero configuration is needed for stateless CLI mode.

#### Scenario: Default daemon settings
- **WHEN** no daemon settings are specified in config.yaml
- **THEN** the system MUST use port `8686` and host `0.0.0.0`

#### Scenario: Default database settings
- **WHEN** no database settings are specified in config.yaml
- **THEN** the system MUST use host `localhost`, port `5432`, database `bamboo_inspect`, user `postgres`, password `secret`

#### Scenario: Default tracking level
- **WHEN** no tracking level is specified in config.yaml
- **THEN** the system MUST default to `none` for stateless CLI mode

#### Scenario: Default access control
- **WHEN** no access control settings are specified in config.yaml
- **THEN** the system MUST default to `local` mode (127.0.0.1 only)

#### Scenario: Default webhook settings
- **WHEN** no webhook settings are specified in config.yaml
- **THEN** the system MUST default to `retry_count: 3` and `timeout_seconds: 10`

#### Scenario: Default data collection settings
- **WHEN** no data collection settings are specified in config.yaml
- **THEN** the system MUST default to `level: basic` and `retention_days: 30`

---

### Requirement: Config Merging

The system MUST deep-merge user configuration with defaults, allowing partial overrides.

#### Scenario: Partial override
- **WHEN** config.yaml contains only `daemon:\n  port: 7777`
- **THEN** the system MUST use port `7777` for daemon
- **AND** all other settings MUST retain their default values

#### Scenario: Nested partial override
- **WHEN** config.yaml contains only `database:\n  host: "db.example.com"`
- **THEN** the system MUST use `db.example.com` for database host
- **AND** database port, name, user, and password MUST retain their default values

---

### Requirement: CLI Flag Override

CLI flags MUST take precedence over config.yaml values and defaults.

#### Scenario: Tracking level override via CLI
- **WHEN** config.yaml sets `tracking.level: session`
- **AND** the user passes `--tracking full` on the CLI
- **THEN** the system MUST use tracking level `full` for that invocation

#### Scenario: Port override via CLI
- **WHEN** config.yaml sets `daemon.port: 8686`
- **AND** the user passes `--port 7777` on the CLI
- **THEN** the daemon MUST start on port `7777`

---

### Requirement: Config Data Structure

The system MUST expose configuration via a typed Python dataclass.

#### Scenario: Config dataclass fields
- **WHEN** the config is loaded
- **THEN** the `Config` dataclass MUST provide typed access to:
  - `daemon.port` (int)
  - `daemon.host` (str)
  - `database.host` (str)
  - `database.port` (int)
  - `database.database` (str)
  - `database.user` (str)
  - `database.password` (str)
  - `access_control.mode` (str: "local", "lan", or "public")
  - `access_control.auth_token` (Optional[str])
  - `tracking.level` (str: "none", "session", or "full")
  - `data_collection.level` (str: "basic", "detailed", or "rich")
  - `data_collection.retention_days` (int)
  - `webhooks.retry_count` (int)
  - `webhooks.timeout_seconds` (int)

---

### Requirement: Stateless CLI Does Not Require Config

The stateless CLI mode MUST work without any config file or database.

#### Scenario: Run tests without config
- **WHEN** no `~/.bambooinspect/config.yaml` exists
- **AND** the user runs `bambooinspect run-all --type script`
- **THEN** the system MUST execute tests using default settings
- **AND** the system MUST NOT attempt to connect to a database
- **AND** the system MUST NOT display config-related errors
