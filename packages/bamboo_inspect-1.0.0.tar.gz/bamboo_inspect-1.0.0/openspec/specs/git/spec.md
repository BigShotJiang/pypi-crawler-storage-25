# Git Integration Specification

## Overview

The Git Integration module manages the relationship between git repositories and Bamboo Inspect. It handles repository registration, git metadata extraction, and filesystem path management. This module primarily serves daemon mode but basic git validation is used in stateless CLI mode as well.

---

## Requirements

### Requirement: Git Repository Validation

The system MUST validate that a directory is a valid git repository.

#### Scenario: Valid git repository
- GIVEN the user is in a directory that is a git repository
- WHEN the system validates the directory
- THEN it MUST confirm the directory is a valid git repo
- AND extract the git remote URL (if configured)

#### Scenario: Not a git repository
- GIVEN the user is in a directory that is NOT a git repository
- WHEN the system validates the directory
- THEN it MUST return an error indicating the directory is not a git repository

#### Scenario: Git repo root detection
- GIVEN the user is in a subdirectory of a git repository
- WHEN the system detects the repo root
- THEN it MUST resolve the path to the repository root directory

---

### Requirement: Repository Registration (Daemon Mode)

The system MUST manage git repository registration for daemon mode.

#### Scenario: Register a repository
- GIVEN a valid git repository at `/path/to/project`
- WHEN the user runs `bambooinspect add-repo /path/to/project`
- THEN the system MUST:
  - Validate the path is a git repository
  - Extract the project name (from directory name or git remote)
  - Store the project record in the database
  - Trigger an initial test scan

#### Scenario: Duplicate repository
- GIVEN `/path/to/project` is already registered
- WHEN the user runs `bambooinspect add-repo /path/to/project`
- THEN the system MUST display a message indicating the repo is already registered

#### Scenario: Repository path validation
- GIVEN the user runs `bambooinspect add-repo /nonexistent/path`
- THEN the system MUST display an error indicating the path does not exist

---

### Requirement: Repository Listing

The system MUST list all registered repositories.

#### Scenario: List with repos registered
- GIVEN 3 repositories are registered
- WHEN the user runs `bambooinspect list-repos`
- THEN the system MUST display a list showing:
  - Project name
  - Filesystem path
  - Git remote URL
  - Last scan timestamp
  - Number of tests discovered

#### Scenario: List with no repos
- GIVEN no repositories are registered
- WHEN the user runs `bambooinspect list-repos`
- THEN the system MUST display a message indicating no repos are registered

---

### Requirement: Repository Removal

The system MUST support unregistering repositories.

#### Scenario: Remove registered repo
- GIVEN `my-project` is a registered repo
- WHEN the user runs `bambooinspect remove-repo my-project`
- THEN the system MUST remove the project record from the database
- AND remove associated Module and Test records

#### Scenario: Remove non-existent repo
- GIVEN `unknown` is not a registered repo
- WHEN the user runs `bambooinspect remove-repo unknown`
- THEN the system MUST display an error indicating the repo is not found

---

### Requirement: Git Metadata Extraction

The system MUST extract useful git metadata from repositories.

#### Scenario: Extract current commit SHA
- GIVEN a valid git repository
- WHEN the system queries git metadata
- THEN it MUST retrieve the current HEAD commit SHA

#### Scenario: Extract remote URL
- GIVEN a git repository with a remote named `origin`
- WHEN the system queries git metadata
- THEN it MUST retrieve the remote URL

#### Scenario: Extract current branch
- GIVEN a valid git repository
- WHEN the system queries git metadata
- THEN it MUST retrieve the current branch name

---

### Requirement: Git Hook Token Management

The system MUST manage authentication tokens for incoming git hooks.

#### Scenario: Generate hook token
- GIVEN a repository is registered
- THEN the system MUST generate or accept a unique token for git hook authentication
- AND store it securely

#### Scenario: Validate hook token
- GIVEN an incoming git hook request with a token
- WHEN the system validates the token
- THEN it MUST match the token to the corresponding project
- AND reject requests with invalid tokens
