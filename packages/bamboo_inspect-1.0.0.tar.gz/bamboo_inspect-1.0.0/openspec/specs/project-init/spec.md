# Project Init Specification

## Overview

The `bambooinspect init` command scaffolds the standard test directory structure in a git repository, creating the necessary directories, template files, and documentation for test organization.

---

## Requirements

### Requirement: Init command availability

The system MUST provide a `bambooinspect init` command that scaffolds the standard test directory structure in a git repository.

#### Scenario: Init command appears in help
- **WHEN** the user runs `bambooinspect --help`
- **THEN** the output MUST list an `init` command with a description

#### Scenario: Init command has help text
- **WHEN** the user runs `bambooinspect init --help`
- **THEN** the output MUST describe what the command does and its available options

---

### Requirement: Git repository validation

The `init` command MUST validate that the current directory is within a git repository before scaffolding.

#### Scenario: Run init in a git repository
- **WHEN** the user runs `bambooinspect init` inside a git repository
- **THEN** the command MUST proceed with scaffolding at the repository root

#### Scenario: Run init outside a git repository
- **WHEN** the user runs `bambooinspect init` outside of any git repository
- **THEN** the command MUST display an error message: "Error: current directory is not a git repository."
- **AND** exit with a non-zero code

---

### Requirement: Tests directory scaffolding

The `init` command MUST create the `tests/` directory structure at the git repository root.

#### Scenario: Create tests directory tree
- **WHEN** the user runs `bambooinspect init` in a git repository that has no `tests/` directory
- **THEN** the command MUST create the following directories:
  - `tests/scripts/`
  - `tests/prompts/`
  - `tests/bamboo-inspect-skill/`
- **AND** each empty directory MUST contain a `.gitkeep` file

#### Scenario: Tests directory already exists
- **WHEN** the user runs `bambooinspect init` in a git repository that already has a `tests/` directory
- **THEN** the command MUST create only the missing subdirectories
- **AND** MUST NOT modify or delete any existing files or directories

---

### Requirement: Bamboo test skill directory

The `init` command MUST create a `tests/bamboo-inspect-skill/` directory containing a `SKILL.md` file that teaches AI agents how to use bambooinspect.

#### Scenario: SKILL.md is created
- **WHEN** the user runs `bambooinspect init` and `tests/bamboo-inspect-skill/SKILL.md` does not exist
- **THEN** the command MUST create `tests/bamboo-inspect-skill/SKILL.md`
- **AND** the file MUST contain:
  - A description of what bambooinspect is
  - The available CLI commands (run, run-module, run-all, init)
  - How to create script tests (Playwright .py/.js/.ts files)
  - How to create prompt tests (.prompt files)
  - The expected directory structure
  - The metadata annotation format (@description, @tags, @timeout, @retry)

#### Scenario: SKILL.md already exists
- **WHEN** the user runs `bambooinspect init` and `tests/bamboo-inspect-skill/SKILL.md` already exists
- **THEN** the command MUST NOT overwrite the existing file
- **AND** MUST display a message indicating it was skipped

---

### Requirement: Bambootest rules file

The `init` command MUST create a `tests/bambooinspect-rules.md` file that documents the test conventions and structure rules.

#### Scenario: bambooinspect-rules.md is created
- **WHEN** the user runs `bambooinspect init` and `tests/bambooinspect-rules.md` does not exist
- **THEN** the command MUST create `tests/bambooinspect-rules.md`
- **AND** the file MUST contain:
  - The mandatory `tests/` directory structure layout
  - How script tests are organized under `tests/scripts/{module}/`
  - How prompt tests are organized under `tests/prompts/{module}/`
  - Supported file extensions for script tests (.py, .js, .ts)
  - Supported file extension for prompt tests (.prompt)
  - File naming conventions
  - Metadata comment format and supported keys with examples
  - Example test file templates (Python script test, prompt test)

#### Scenario: bambooinspect-rules.md already exists
- **WHEN** the user runs `bambooinspect init` and `tests/bambooinspect-rules.md` already exists
- **THEN** the command MUST NOT overwrite the existing file
- **AND** MUST display a message indicating it was skipped

---

### Requirement: Init command output

The `init` command MUST provide clear feedback about what was created.

#### Scenario: First-time init output
- **WHEN** the user runs `bambooinspect init` for the first time in a repository
- **THEN** the command MUST print a line for each created directory and file
- **AND** MUST print a summary of what was created

#### Scenario: Repeated init output
- **WHEN** the user runs `bambooinspect init` in a repository that has already been initialized
- **THEN** the command MUST indicate that the structure already exists
- **AND** MUST NOT display errors

---

### Requirement: Init idempotency

The `init` command MUST be safe to run multiple times without causing data loss or errors.

#### Scenario: Run init twice
- **WHEN** the user runs `bambooinspect init` twice in the same repository
- **THEN** the second run MUST NOT modify any files created by the first run
- **AND** the second run MUST NOT produce errors
- **AND** the second run MUST indicate that items were skipped because they already exist

#### Scenario: Run init after manual modifications
- **WHEN** the user has manually modified `tests/bambooinspect-rules.md` after running `bambooinspect init`
- **AND** the user runs `bambooinspect init` again
- **THEN** the command MUST NOT overwrite the modified file
