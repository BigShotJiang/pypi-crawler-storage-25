# docker-support Specification

## Overview

Docker support provides containerized deployment for the Core Manager server, with separate production and development configurations. The Test Agent is NOT containerized — it is installed via PyPI on host machines.

---

## Requirements

### Requirement: Production Dockerfile

The project SHALL include a `Dockerfile` at the repository root for building a production-ready container image of the **Core Manager** server. The Dockerfile MUST NOT include test execution tools (Playwright, Claude Code, Node.js).

#### Scenario: Build production image
- **WHEN** a developer runs `docker build -t bamboo-inspect-core .`
- **THEN** a multi-stage Docker image SHALL be built with Python 3.12-slim as the base
- **THEN** the final image SHALL contain the Core Manager server code from `server/` directory
- **THEN** the image SHALL NOT contain test executors, Playwright, or Node.js

#### Scenario: Run production container
- **WHEN** a user runs the production container
- **THEN** the container SHALL start the Core Manager FastAPI server on port 8686
- **THEN** the port 8686 SHALL be exposed

#### Scenario: Configure via environment variables
- **WHEN** environment variables are passed to the production container (e.g., `BAMBOOINSPECT_DB_HOST`, `BAMBOOINSPECT_DB_PORT`, `BAMBOOINSPECT_DB_NAME`, `BAMBOOINSPECT_DB_USER`, `BAMBOOINSPECT_DB_PASSWORD`, `BAMBOOINSPECT_PORT`)
- **THEN** the Core Manager SHALL use those values to configure database connection and service port

---

### Requirement: Development Dockerfile

The project SHALL include a `Dockerfile.dev` at the repository root for building a development container for the **Core Manager** with hot-reload capability.

#### Scenario: Build dev image
- **WHEN** a developer runs `docker build -f Dockerfile.dev -t bamboo-inspect-core-dev .`
- **THEN** a Docker image SHALL be built with the Core Manager server code
- **THEN** the image SHALL include development dependencies (ruff, etc.)

#### Scenario: Source mounting in dev container
- **WHEN** the dev container is started with a volume mount of `./server` to the container's server directory
- **THEN** code changes on the host SHALL be reflected immediately in the container without rebuilding

---

### Requirement: Development docker-compose configuration

The project SHALL include a `docker-compose.yml` for local development of the Core Manager.

#### Scenario: Start development environment
- **WHEN** a developer runs `docker compose up`
- **THEN** a PostgreSQL container SHALL start with the database `bamboo_inspect` pre-created
- **THEN** the Core Manager dev container SHALL start with source code mounted for hot-reload
- **THEN** the Core Manager SHALL be accessible at `http://localhost:8686`

#### Scenario: Database persistence in dev
- **WHEN** a developer stops and restarts the development environment
- **THEN** PostgreSQL data SHALL persist via a named Docker volume

#### Scenario: Database migrations in dev
- **WHEN** the development environment starts
- **THEN** database migrations SHALL run automatically before the Core Manager starts

---

### Requirement: Production docker-compose configuration

The project SHALL include a `docker-compose.prod.yml` for production deployment of the Core Manager.

#### Scenario: Start production environment
- **WHEN** a deployer runs `docker compose -f docker-compose.prod.yml up -d`
- **THEN** a PostgreSQL container SHALL start with production-appropriate defaults
- **THEN** the Core Manager production container SHALL start in detached mode
- **THEN** the Core Manager SHALL be accessible on port 8686

#### Scenario: Production restart policy
- **WHEN** the production containers crash or the host reboots
- **THEN** all services SHALL have `restart: unless-stopped` policy

#### Scenario: Production environment variables
- **WHEN** the production compose file is used
- **THEN** sensitive values SHALL be configurable via a `.env` file or environment variables (NOT hardcoded)

---

### Requirement: Docker ignore file

The project SHALL include a `.dockerignore` file to exclude unnecessary files from the Docker build context.

#### Scenario: Exclude non-essential files
- **WHEN** a Docker image is built
- **THEN** the following SHALL be excluded from the build context: `.git/`, `__pycache__/`, `*.pyc`, `.venv/`, `venv/`, `dist/`, `build/`, `*.egg-info/`, `.pytest_cache/`, `node_modules/`, `.env`, `openspec/`

---

### Requirement: Documentation updates

The `docs/quickstart.md` and `CLAUDE.md` files SHALL be updated to reflect Docker and Makefile usage.

#### Scenario: Quickstart includes Docker setup
- **WHEN** a user reads `docs/quickstart.md`
- **THEN** there SHALL be a section explaining how to start the development environment using Docker
- **THEN** there SHALL be a section explaining how to deploy using Docker in production

#### Scenario: CLAUDE.md includes Docker and Makefile context
- **WHEN** an AI assistant reads `CLAUDE.md`
- **THEN** the project structure SHALL list the new files (`Makefile`, `Dockerfile`, `Dockerfile.dev`, `docker-compose.yml`, `docker-compose.prod.yml`, `.dockerignore`)
- **THEN** the development guidelines SHALL reference Makefile targets and Docker commands
