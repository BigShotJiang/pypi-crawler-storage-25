# Daemon Mode & Web UI Specification

## Overview

**DEPRECATED**: The single-process daemon concept has been replaced by two separate components: **Core Manager** (Docker-deployed server) and **Test Agent** (PyPI-installed worker). The daemon's responsibilities are split — the web server and database management move to Core Manager, and test execution moves to Test Agent.

**Migration**: Deploy Core Manager via Docker (`docker compose up`). Install and register Test Agents via `bambooinspect agent register && bambooinspect agent start`.

---

## Requirements

*All requirements in this specification have been removed and replaced by the following specifications:*

- **Core Manager API** (`core-manager-api`): REST API endpoints, web dashboard, agent management
- **Agent Web UI** (`agent-web-ui`): Agent-side web server and dashboard
- **Agent Heartbeat** (`agent-heartbeat`): Agent status lifecycle and offline detection
- **Task Dispatch** (`task-dispatch`): Task assignment, polling, and result submission

### Removed Requirements

The following requirements were part of the original daemon specification and have been migrated:

- **Daemon Lifecycle** → Core Manager (Docker deployment) + Test Agent (`bambooinspect agent start`)
- **Web Server** → Core Manager web server (port 8686, Docker) + Agent web server (port 8787)
- **Web UI Dashboard** → Core Manager dashboard (retains all features, adds agent management)
- **Real-Time Log Streaming** → Core Manager relays logs from agents to browser clients
- **Access Control** → Core Manager access control (same configuration)
- **Frontend Technology** → Preserved as vanilla HTML/JS/CSS in both Core Manager and Agent UI
