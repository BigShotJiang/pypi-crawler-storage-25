# Task Dispatch Specification

## Overview

Task dispatch handles the assignment of test execution tasks to agents, agent polling for pending tasks, task execution flow, result submission back to the Core Manager, and task cancellation.

---

## Requirements

### Requirement: Manual Task Assignment

The Core Manager MUST allow administrators to manually assign test execution tasks to a specific agent.

#### Scenario: Assign task via API
- **WHEN** an admin sends `POST /api/admin/tasks` with `{ "agent_id": "<id>", "test_ids": ["<test-id-1>", "<test-id-2>"], "tracking": "session" }`
- **THEN** the Core Manager MUST create a RunSession with `agent_id` set
- **AND** create Execution records for each test with `agent_id` set and `status=pending`
- **AND** return the RunSession ID and Execution IDs

#### Scenario: Assign task via Web UI
- **WHEN** an admin selects tests in the Core Manager dashboard and clicks "Assign to Agent"
- **THEN** the UI MUST present a list of available agents (not offline)
- **AND** allow the admin to select one agent
- **AND** create the task assignment upon confirmation

#### Scenario: Assign to offline agent rejected
- **WHEN** an admin attempts to assign a task to an agent with status `offline`
- **THEN** the Core Manager MUST reject the assignment
- **AND** return an error indicating the agent is offline

#### Scenario: Assign to busy agent allowed
- **WHEN** an admin assigns a task to an agent with status `busy`
- **THEN** the Core Manager MUST accept the assignment
- **AND** the task MUST be queued for the agent (picked up after current task completes)

---

### Requirement: Agent Task Polling

The Test Agent MUST poll the Core Manager for pending tasks assigned to it.

#### Scenario: Poll for pending tasks
- **WHEN** the agent sends `GET /api/agent/tasks` with its agent token
- **THEN** the Core Manager MUST return all Execution records where `agent_id` matches the agent and `status=pending`
- **AND** order them by creation time (oldest first)

#### Scenario: No pending tasks
- **WHEN** the agent polls and there are no pending tasks
- **THEN** the Core Manager MUST return an empty list
- **AND** the agent MUST wait for the next poll interval before checking again

#### Scenario: Agent picks up a task
- **WHEN** the agent receives pending tasks from polling
- **THEN** the agent MUST pick up the first task in the list
- **AND** send `POST /api/agent/tasks/{execution_id}/start` to mark it as `running`
- **AND** begin executing the test locally

---

### Requirement: Task Execution by Agent

The Test Agent MUST execute the assigned test and report the result back to the Core Manager.

#### Scenario: Fetch test details
- **WHEN** the agent picks up a task
- **THEN** the agent MUST fetch the test details (path, type, timeout, retry_count, project path) from the Core Manager via `GET /api/agent/tasks/{execution_id}/details`

#### Scenario: Execute script test
- **WHEN** the agent receives a task with `type=script`
- **THEN** the agent MUST execute the test file using the Playwright Executor
- **AND** capture stdout, stderr, exit code, duration, and artifacts

#### Scenario: Execute prompt test
- **WHEN** the agent receives a task with `type=prompt`
- **THEN** the agent MUST execute the prompt file using the Claude Code Executor
- **AND** capture the AI response, duration, and pass/fail status

---

### Requirement: Result Submission

The Test Agent MUST push execution results back to the Core Manager after task completion.

#### Scenario: Submit successful result
- **WHEN** a test execution completes successfully
- **THEN** the agent MUST send `POST /api/agent/tasks/{execution_id}/result` with:
  - `status`: `passed`
  - `duration`: execution duration in milliseconds
  - `logs`: stdout/stderr content
  - `artifacts`: JSONB with artifact paths (if any)

#### Scenario: Submit failed result
- **WHEN** a test execution fails
- **THEN** the agent MUST send `POST /api/agent/tasks/{execution_id}/result` with:
  - `status`: `failed`
  - `duration`: execution duration in milliseconds
  - `error_message`: error description
  - `logs`: stdout/stderr content
  - `artifacts`: JSONB with artifact paths (if any)

#### Scenario: Core Manager updates records
- **WHEN** the Core Manager receives an execution result from an agent
- **THEN** it MUST update the Execution record with the submitted data
- **AND** update the RunSession aggregate counts (passed/failed/total)
- **AND** trigger any configured outgoing webhooks

#### Scenario: Result submission during Core Manager outage
- **WHEN** the agent completes a task but cannot reach the Core Manager
- **THEN** the agent MUST queue the result locally
- **AND** retry submission on subsequent poll cycles until successful

---

### Requirement: Task Cancellation

The Core Manager MUST support cancelling pending or running tasks.

#### Scenario: Cancel pending task
- **WHEN** an admin sends `POST /api/admin/tasks/{execution_id}/cancel`
- **AND** the task status is `pending`
- **THEN** the Core Manager MUST set the task status to `cancelled`

#### Scenario: Cancel running task
- **WHEN** an admin cancels a task that is currently running on an agent
- **THEN** the Core Manager MUST set the task status to `cancelled`
- **AND** the agent MUST detect the cancellation on the next poll and terminate the running process
