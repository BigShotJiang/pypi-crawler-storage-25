## ADDED Requirements

### Requirement: URL-Based Navigation
The application SHALL update the URL hash when switching tabs.

#### Scenario: Switch Tab
- **WHEN** user clicks on the "Tasks" tab
- **THEN** URL changes to `.../#tasks` and the Tasks view is shown

### Requirement: Deep Linking
The application SHALL load the correct tab based on the URL hash on initial load.

#### Scenario: Load with Hash
- **WHEN** user loads `.../#repos`
- **THEN** Repositories tab is active and visible
