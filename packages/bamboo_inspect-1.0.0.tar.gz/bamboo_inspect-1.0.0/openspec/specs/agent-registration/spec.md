# Agent Registration Specification

## Overview

Agent registration provides a secure onboarding flow where administrators generate short-lived registration tokens, and agents use them to register with the Core Manager and receive persistent authentication tokens.

---

## Requirements

### Requirement: Registration Token Generation

The Core Manager MUST allow administrators to generate short-lived registration tokens for agent onboarding.

#### Scenario: Generate registration token via API
- **WHEN** an admin sends `POST /api/admin/registration-tokens` with an optional `description` field
- **THEN** the Core Manager MUST generate a unique registration token
- **AND** store its hash in the `registration_token` table with `used=false`
- **AND** return the plaintext token to the admin (shown only once)
- **AND** set the token expiry to 1 hour from creation (default)

#### Scenario: Generate registration token via Web UI
- **WHEN** an admin clicks "Generate Agent Token" in the Core Manager dashboard
- **THEN** the UI MUST display the plaintext token with a copy button
- **AND** warn that the token is shown only once

#### Scenario: Token expiry
- **WHEN** a registration token is older than its `expires_at` timestamp
- **THEN** the Core Manager MUST reject any registration attempt using that token
- **AND** return an error indicating the token has expired

#### Scenario: Token single-use
- **WHEN** a registration token has already been used to register an agent
- **THEN** the Core Manager MUST reject any subsequent registration attempt using that token
- **AND** return an error indicating the token has already been used

---

### Requirement: Agent Registration Flow

The Test Agent MUST register with the Core Manager using a valid registration token, receiving a persistent agent token in return.

#### Scenario: Successful agent registration
- **WHEN** an agent sends `POST /api/agent/register` with `{ "token": "<reg-token>", "name": "<agent-name>", "labels": ["label1", "label2"] }`
- **THEN** the Core Manager MUST validate the registration token (not expired, not used)
- **AND** create an Agent record with status `online`
- **AND** mark the registration token as `used=true` with `used_by_agent_id` set
- **AND** generate a persistent agent token
- **AND** return the persistent agent token and agent ID to the agent

#### Scenario: Agent stores credentials locally
- **WHEN** the agent receives a successful registration response
- **THEN** the agent MUST store the persistent token, agent ID, agent name, and Core Manager URL in `~/.bambooinspect/agent.yaml`

#### Scenario: Duplicate agent name
- **WHEN** an agent attempts to register with a name that already exists
- **THEN** the Core Manager MUST reject the registration
- **AND** return an error indicating the name is already taken

#### Scenario: Invalid registration token
- **WHEN** an agent attempts to register with an invalid, expired, or already-used token
- **THEN** the Core Manager MUST reject the registration with an appropriate error message

---

### Requirement: Agent Identity

Each registered agent MUST have a unique name and a set of labels for identification and targeting.

#### Scenario: Agent name uniqueness
- **WHEN** an agent registers with name `agent-linux-01`
- **THEN** the Core Manager MUST ensure no other active agent has the same name

#### Scenario: Agent labels
- **WHEN** an agent registers with labels `["linux", "playwright", "gpu"]`
- **THEN** the Core Manager MUST store the labels as a JSONB array in the Agent record
- **AND** the labels MUST be queryable for task assignment filtering

#### Scenario: Agent OS info
- **WHEN** an agent registers
- **THEN** it MUST send OS information (platform, version, architecture) as part of the registration payload
- **AND** the Core Manager MUST store this in the Agent record's `os_info` field

---

### Requirement: Agent Token Authentication

All agent-to-Core-Manager API calls (except registration) MUST authenticate using the persistent agent token.

#### Scenario: Valid agent token
- **WHEN** an agent sends an API request with `Authorization: Bearer <agent-token>` header
- **THEN** the Core Manager MUST validate the token against stored token hashes
- **AND** identify the requesting agent
- **AND** process the request

#### Scenario: Invalid agent token
- **WHEN** an API request is sent with an invalid or missing agent token
- **THEN** the Core Manager MUST return HTTP 401 Unauthorized

#### Scenario: Revoked agent
- **WHEN** an admin removes an agent from the Core Manager
- **THEN** all subsequent API requests using that agent's token MUST be rejected with HTTP 401

---

### Requirement: Agent Deregistration

The Core Manager MUST support removing registered agents.

#### Scenario: Remove agent via API
- **WHEN** an admin sends `DELETE /api/admin/agents/{agent_id}`
- **THEN** the Core Manager MUST mark the agent as removed
- **AND** invalidate its persistent token
- **AND** any pending tasks assigned to the agent MUST be marked as `cancelled`

#### Scenario: Remove agent via CLI
- **WHEN** the agent runs `bambooinspect agent unregister`
- **THEN** the agent MUST send a deregistration request to the Core Manager
- **AND** delete the local `~/.bambooinspect/agent.yaml` credentials file
