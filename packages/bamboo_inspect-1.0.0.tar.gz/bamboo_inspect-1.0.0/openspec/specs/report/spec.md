# Report Generator Specification

## Overview

The Report Generator produces reports after test execution completes. It supports template-based rendering for script tests and AI-generated content for prompt tests. Reports can be output to stdout, saved to files, or stored in the database (daemon mode).

---

## Requirements

### Requirement: Automatic Report Generation

The system MUST automatically generate a report after every test execution.

#### Scenario: Report after run-all
- GIVEN the user runs `bambooinspect run-all --type script`
- WHEN all tests complete
- THEN the system MUST generate a report summarizing all test results
- AND output the report to stdout by default

#### Scenario: Report after single test run
- GIVEN the user runs `bambooinspect run login_test --type script`
- WHEN the test completes
- THEN the system MUST generate a report for that single test result

---

### Requirement: Template-Based Script Reports

The system MUST support template-based report rendering for script test results.

#### Scenario: HTML report
- GIVEN script test results are available
- WHEN the report generator renders using the HTML template
- THEN the report MUST include:
  - Test name, module, and status (passed/failed)
  - Execution duration
  - Error messages (for failed tests)
  - Stdout/stderr logs
  - Summary with total/passed/failed counts

#### Scenario: Markdown report
- GIVEN script test results are available
- WHEN the report generator renders using the Markdown template
- THEN the report MUST produce valid Markdown with the same information as HTML

#### Scenario: JSON report
- GIVEN script test results are available
- WHEN the report generator renders using the JSON template
- THEN the report MUST produce valid JSON with structured test result data

---

### Requirement: AI-Powered Script Reports

The system MAY support AI-generated reports for script tests using the `--report ai` flag.

#### Scenario: AI report generation
- GIVEN the user runs `bambooinspect run-all --type script --report ai`
- WHEN all tests complete
- THEN the system MUST send the test results to Claude Code
- AND use the AI response as a richer summary report

#### Scenario: AI report fallback
- GIVEN `--report ai` is specified but Claude Code is unavailable
- THEN the system MUST fall back to template-based report generation
- AND display a warning message

---

### Requirement: Prompt Test Reports

For prompt tests, the system MUST use the AI output directly as the report content.

#### Scenario: Prompt report
- GIVEN the user runs `bambooinspect run test_login_flow --type prompt`
- WHEN the prompt execution completes
- THEN the report MUST contain the AI response as the primary content

---

### Requirement: Report Output Options

The system MUST support multiple report output destinations.

#### Scenario: Output to stdout (default)
- GIVEN no `--report-output` flag is specified
- WHEN the report is generated
- THEN it MUST be printed to stdout

#### Scenario: Output to file
- GIVEN `--report-output ./report.html` is specified
- WHEN the report is generated
- THEN the system MUST write the report to the specified file path
- AND confirm the file was created

#### Scenario: Store in database (daemon mode)
- GIVEN a test executes in daemon mode
- WHEN the report is generated
- THEN it MUST be stored in the Report database table
- AND linked to the corresponding Execution or RunSession record

---

### Requirement: Built-in Templates

The system MUST include built-in report templates.

#### Scenario: Templates available
- GIVEN the package is installed
- THEN the following templates MUST be available:
  - HTML template (default)
  - Markdown template
  - JSON template
- AND templates MUST be stored in `src/bamboo_inspect/report/templates/`

#### Scenario: Template rendering
- GIVEN test result data and a selected template
- WHEN the renderer processes the template
- THEN it MUST substitute test result values into the template
- AND produce a valid output document
