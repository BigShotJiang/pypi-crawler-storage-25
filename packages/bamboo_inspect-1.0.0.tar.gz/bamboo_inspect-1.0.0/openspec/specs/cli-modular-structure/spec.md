# CLI Modular Structure Specification

## Overview

The CLI is organized as a Python package (`src/bamboo_inspect/cli/`) with each command group in its own module, providing better separation of concerns and maintainability.

---

## Requirements

### Requirement: CLI package structure

The system MUST organize CLI commands as a Python package (`src/bamboo_inspect/cli/`) instead of a single file, with each command group in its own module.

#### Scenario: CLI package directory exists
- **WHEN** the bambooinspect package is installed
- **THEN** `src/bamboo_inspect/cli/` MUST be a Python package containing `__init__.py`, `_helpers.py`, `run.py`, `agent.py`, and `init.py`

#### Scenario: Entry point resolves to cli package
- **WHEN** the user runs `bambooinspect` after installation
- **THEN** the entry point `bamboo_inspect.cli:app` MUST resolve to the `app` object exported from `src/bamboo_inspect/cli/__init__.py`

---

### Requirement: Run commands in dedicated module

The system MUST place all stateless test execution commands (`run`, `run-module`, `run-all`) in `src/bamboo_inspect/cli/run.py`.

#### Scenario: run command works from run.py
- **WHEN** the user runs `bambooinspect run <test> --type script`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/run.py`

#### Scenario: run-module command works from run.py
- **WHEN** the user runs `bambooinspect run-module <module> --type script`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/run.py`

#### Scenario: run-all command works from run.py
- **WHEN** the user runs `bambooinspect run-all --type script`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/run.py`

---

### Requirement: Agent commands in dedicated module

The system MUST place all agent management commands (`register`, `start`, `stop`, `status`, `unregister`, `sync-repo`) in `src/bamboo_inspect/cli/agent.py`.

#### Scenario: agent register command works from agent.py
- **WHEN** the user runs `bambooinspect agent register --url <url> --token <token> --name <name>`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/agent.py`

#### Scenario: agent start command works from agent.py
- **WHEN** the user runs `bambooinspect agent start`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/agent.py`

#### Scenario: agent sync-repo command works from agent.py
- **WHEN** the user runs `bambooinspect agent sync-repo .`
- **THEN** the command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** the command function MUST be defined in `cli/agent.py`

#### Scenario: agent stop, status, unregister commands work from agent.py
- **WHEN** the user runs any of `bambooinspect agent stop`, `bambooinspect agent status`, or `bambooinspect agent unregister`
- **THEN** each command MUST execute identically to the current monolithic `cli.py` implementation
- **AND** each command function MUST be defined in `cli/agent.py`

---

### Requirement: Shared helpers in dedicated module

The system MUST place shared CLI helper functions (`_get_repo_root`, `_get_executor`, `_execute_tests`) in `src/bamboo_inspect/cli/_helpers.py`.

#### Scenario: Helpers are importable by command modules
- **WHEN** `cli/run.py` or `cli/agent.py` imports from `bamboo_inspect.cli._helpers`
- **THEN** the functions `_get_repo_root`, `_get_executor`, and `_execute_tests` MUST be available

#### Scenario: Helpers do not import app or agent_app
- **WHEN** `cli/_helpers.py` is loaded
- **THEN** it MUST NOT import `app` or `agent_app` from `bamboo_inspect.cli` to avoid circular imports

---

### Requirement: Backward compatibility

All existing CLI commands, options, arguments, help text, and exit codes MUST remain unchanged after the refactor.

#### Scenario: Help output is identical
- **WHEN** the user runs `bambooinspect --help`
- **THEN** the output MUST list the same commands and descriptions as before the refactor

#### Scenario: Version flag is identical
- **WHEN** the user runs `bambooinspect --version`
- **THEN** the output MUST display the version in the same format as before the refactor

---

### Requirement: CLI Entry Point

The system MUST expose a single CLI command `bambooinspect` as the entry point for all operations. The entry point `bamboo_inspect.cli:app` MUST resolve to `src/bamboo_inspect/cli/__init__.py` which exports the `app` Typer instance.

#### Scenario: CLI is available after installation
- **WHEN** the user has installed the `bamboo-inspect` PyPI package
- **THEN** the CLI MUST display help text with available commands and options
- **AND** the `app` object MUST be importable from `bamboo_inspect.cli`

#### Scenario: CLI shows version
- **WHEN** the user runs `bambooinspect --version`
- **THEN** the CLI MUST display the current package version
