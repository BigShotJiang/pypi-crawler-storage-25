# project-packaging Specification

## Overview

The project is structured as a PyPI-installable Python package for the Test Agent, with Core Manager server code in a separate `server/` directory (deployed via Docker). The `src/` layout convention is used for the agent package.

---

## Requirements

### Requirement: PyPI-Compatible Package Configuration

The project MUST have a `pyproject.toml` that defines the Test Agent as an installable Python package. The package MUST NOT include Core Manager server code.

#### Scenario: Package metadata is complete
- **WHEN** a developer inspects `pyproject.toml`
- **THEN** it MUST contain:
  - Package name: `bamboo-inspect`
  - Python requirement: `>= 3.10`
  - A version string following semantic versioning
  - A description, license, and author fields
  - Build system configuration (hatchling)

#### Scenario: Core dependencies are declared (agent-only)
- **WHEN** a developer inspects the `[project.dependencies]` section
- **THEN** it MUST declare the following runtime dependencies:
  - `typer[all]` (CLI framework)
  - `fastapi` (agent web UI server)
  - `uvicorn[standard]` (ASGI server for agent web UI)
  - `aiohttp` (async HTTP client for Core Manager communication)
  - `pyyaml` (config file parsing)
- **AND** it MUST NOT include:
  - `asyncpg` (Core Manager only)
  - `bamboo-database[postgresql]` (Core Manager only)

#### Scenario: CLI entry point is registered
- **WHEN** a developer inspects the `[project.scripts]` section
- **THEN** it MUST register the entry point `bambooinspect = "bamboo_inspect.cli:app"`

---

### Requirement: Source Layout

The project MUST use the `src/` layout convention for the Test Agent Python package. Core Manager code MUST be in a separate `server/` directory, not included in the PyPI package.

#### Scenario: Agent package directory exists
- **WHEN** a developer lists `src/bamboo_inspect/`
- **THEN** the directory MUST exist and contain an `__init__.py` file
- **AND** `__init__.py` MUST expose a `__version__` variable

#### Scenario: Agent module files exist
- **WHEN** a developer lists the `src/bamboo_inspect/` directory tree
- **THEN** the following files MUST exist:
  - `cli.py` (agent CLI with stateless + agent commands)
  - `scanner.py` (test discovery)
  - `config.py` (agent config loader)
  - `agent/` directory with agent core modules (registration, poller, heartbeat)
  - `executors/__init__.py`, `executors/playwright.py`, `executors/claude_code.py`
  - `report/__init__.py`, `report/renderer.py`
  - `web/__init__.py`, `web/app.py` (agent web UI)
  - `web/static/` (agent dashboard HTML/JS/CSS)

#### Scenario: Core Manager code is separate
- **WHEN** a developer lists the project root
- **THEN** a `server/` directory MUST exist containing the Core Manager source code
- **AND** the `server/` directory MUST NOT be included in the PyPI package build

#### Scenario: Template and static asset directories exist
- **WHEN** a developer lists the directory tree
- **THEN** `src/bamboo_inspect/report/templates/` MUST exist as a directory
- **AND** `src/bamboo_inspect/web/static/` MUST exist for the agent web UI
- **AND** both MUST be included in the package distribution

---

### Requirement: Core Manager Has Own Dependencies

The Core Manager (Docker deployment) MUST have its own dependency specification separate from the PyPI package.

#### Scenario: Server requirements file
- **WHEN** a developer inspects `server/requirements.txt`
- **THEN** it MUST declare:
  - `fastapi` (web framework)
  - `uvicorn[standard]` (ASGI server)
  - `asyncpg` (PostgreSQL async driver)
  - `bamboo-database[postgresql]` (migration management)
  - `aiohttp` (async HTTP client)
  - `pyyaml` (config parsing)

---

### Requirement: Editable Installation

The package MUST be installable in editable (development) mode.

#### Scenario: Install in development mode
- **WHEN** a developer runs `pip install -e .` from the project root
- **THEN** the installation MUST succeed without errors
- **AND** the `bamboo_inspect` package MUST be importable in Python

#### Scenario: CLI is available after installation
- **WHEN** a developer runs `pip install -e .`
- **THEN** the `bambooinspect` command MUST be available in the shell
- **AND** running `bambooinspect --help` MUST display help text without errors

---

### Requirement: CLI Stub with Version

The `cli.py` module MUST provide a minimal working Typer application with a version flag and placeholder commands.

#### Scenario: Version flag works
- **WHEN** a user runs `bambooinspect --version`
- **THEN** the CLI MUST print the current package version from `bamboo_inspect.__version__`

#### Scenario: Help shows all command groups
- **WHEN** a user runs `bambooinspect --help`
- **THEN** the output MUST list placeholder commands for:
  - `run` (run a single test)
  - `run-module` (run all tests in a module)
  - `run-all` (run all tests)
  - `agent` subcommand group (register, start, stop, status, unregister)

#### Scenario: Stub commands print not-implemented message
- **WHEN** a user runs any placeholder command (e.g., `bambooinspect run-all --type script`)
- **THEN** the CLI MUST print a message indicating the command is not yet implemented
- **AND** exit with code 0

---

### Requirement: Module Stubs are Importable

All stub module files MUST be importable without errors and without requiring external services.

#### Scenario: Import any module
- **WHEN** a developer runs `import bamboo_inspect.scanner` (or any other module)
- **THEN** the import MUST succeed without raising exceptions
- **AND** the module MAY contain placeholder docstrings, empty classes, or `pass` statements

#### Scenario: No side effects on import
- **WHEN** any module is imported
- **THEN** the import MUST NOT attempt to connect to databases, start servers, or access the filesystem beyond the module's own directory
