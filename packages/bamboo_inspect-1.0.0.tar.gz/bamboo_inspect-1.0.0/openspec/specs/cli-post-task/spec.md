# cli-post-task Specification

## Purpose
TBD - created by archiving change cli-run-post-task. Update Purpose after archive.
## Requirements
### Requirement: Post-Task Flag on Run Commands

The CLI `run`, `run-module`, and `run-all` commands MUST accept an optional `--post-task` boolean flag. When set, the CLI MUST execute tests locally first, then submit the completed results to the Core Manager server.

#### Scenario: Run a single test with --post-task
- **WHEN** the user runs `bambooinspect run login_test --type script --post-task`
- **THEN** the CLI MUST discover and execute `login_test` locally as usual
- **AND** after execution completes, the CLI MUST load the agent configuration from `~/.bambooinspect/agent.yaml`
- **AND** submit the test results to the Core Manager via `POST /api/agent/report-run` using the `agent_token` as Bearer authentication
- **AND** display a confirmation message with the returned session ID
- **AND** exit with code 0 if the test passed, non-zero if it failed (same as without the flag)

#### Scenario: Run a module with --post-task
- **WHEN** the user runs `bambooinspect run-module auth --type script --post-task`
- **THEN** the CLI MUST execute all tests in the `auth` module locally
- **AND** after all tests complete, submit all results in a single request to the Core Manager
- **AND** display a confirmation with the session ID and per-test submission status

#### Scenario: Run all tests with --post-task
- **WHEN** the user runs `bambooinspect run-all --type script --post-task`
- **THEN** the CLI MUST execute all script tests locally
- **AND** after all tests complete, submit all results in a single request to the Core Manager

#### Scenario: Default behaviour without --post-task
- **WHEN** the user runs `bambooinspect run login_test --type script` (without `--post-task`)
- **THEN** the CLI MUST behave exactly as before — execute locally, no server communication

---

### Requirement: Agent Configuration Validation for Post-Task

When `--post-task` is set, the CLI MUST validate that a valid agent configuration exists before executing tests.

#### Scenario: Agent config exists and is complete
- **WHEN** the user runs any run command with `--post-task`
- **AND** `~/.bambooinspect/agent.yaml` exists with non-empty `core_url`, `agent_token`, and `agent_id`
- **THEN** the CLI MUST proceed with test execution and result submission

#### Scenario: Agent config file missing
- **WHEN** the user runs any run command with `--post-task`
- **AND** `~/.bambooinspect/agent.yaml` does not exist
- **THEN** the CLI MUST display an error: "Agent not registered. Run 'bambooinspect agent register' first or create ~/.bambooinspect/agent.yaml manually."
- **AND** exit with a non-zero code without executing tests

#### Scenario: Agent config incomplete
- **WHEN** the user runs any run command with `--post-task`
- **AND** `~/.bambooinspect/agent.yaml` exists but `core_url`, `agent_token`, or `agent_id` is empty
- **THEN** the CLI MUST display an error indicating which fields are missing
- **AND** exit with a non-zero code without executing tests

---

### Requirement: Result Submission to Core Manager

After local test execution, the CLI MUST submit results to the Core Manager using the agent API endpoint `POST /api/agent/report-run`.

#### Scenario: Successful result submission
- **WHEN** tests have finished executing locally
- **AND** the Core Manager is reachable
- **THEN** the CLI MUST send a single `POST /api/agent/report-run` request with:
  - `project_name`: the git repository name
  - `project_path`: the repository root path
  - `tracking`: the tracking level (from `--tracking` option or default `"session"`)
  - `triggered_by`: `"cli"`
  - `results`: an array of per-test result objects containing `test_name`, `test_type`, `module`, `status`, `duration`, `logs`, `error_message`
- **AND** the request MUST include the `Authorization: Bearer <agent_token>` header
- **AND** on success, display: "Results posted to Core Manager — session: <session_id>"

#### Scenario: Core Manager unreachable
- **WHEN** tests have finished executing locally
- **AND** the Core Manager cannot be reached (connection refused, timeout, DNS failure)
- **THEN** the CLI MUST display a warning: "Warning: could not reach Core Manager at <core_url>. Results not submitted."
- **AND** the CLI MUST still exit with the correct test pass/fail exit code
- **AND** the CLI MUST NOT queue results offline (fire-and-forget from CLI context)

#### Scenario: Core Manager returns an error
- **WHEN** the CLI submits results and the server returns a 4xx or 5xx status
- **THEN** the CLI MUST display a warning with the status code and error detail
- **AND** the CLI MUST still exit with the correct test pass/fail exit code

---

### Requirement: Agent Report-Run Endpoint

The Core Manager MUST expose a new agent API endpoint `POST /api/agent/report-run` that accepts completed test results from a CLI run.

#### Scenario: Submit completed run results
- **WHEN** an authenticated agent sends `POST /api/agent/report-run` with a valid results payload
- **THEN** the Core Manager MUST look up or create the project and module records
- **AND** look up or create test records for each result entry
- **AND** create a RunSession with `triggered_by='cli'` and `agent_id` set
- **AND** create an Execution record for each test with the submitted result data (status, duration, logs, error_message)
- **AND** update the RunSession aggregate counts (passed, failed, total)
- **AND** trigger any configured outgoing webhooks
- **AND** return `{ "session_id": "<id>", "execution_ids": [...], "total_tests": <n> }`

#### Scenario: Unauthenticated request
- **WHEN** a request is sent to `POST /api/agent/report-run` without a valid agent token
- **THEN** the Core Manager MUST return 401 Unauthorized

#### Scenario: Empty results array
- **WHEN** an agent sends a report-run request with an empty `results` array
- **THEN** the Core Manager MUST return 400 Bad Request with detail "No results to report"

