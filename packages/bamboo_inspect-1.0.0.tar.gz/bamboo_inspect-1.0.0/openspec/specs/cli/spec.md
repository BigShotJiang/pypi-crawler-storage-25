# CLI Specification

## Overview

The `bambooinspect` CLI is the primary user interface for Bamboo Inspect. It provides commands for **stateless execution** (no daemon/database required) and **agent management** (register, start, stop agents that connect to a Core Manager). Built with Typer.

---

## Requirements

### Requirement: CLI Entry Point

The system MUST expose a single CLI command `bambooinspect` as the entry point for all operations. The CLI MUST include agent management commands as a subcommand group.

#### Scenario: CLI is available after installation
- GIVEN the user has installed the `bamboo-inspect` PyPI package
- WHEN the user runs `bambooinspect` in a terminal
- THEN the CLI MUST display help text with available commands including the `agent` subcommand group

#### Scenario: CLI shows version
- GIVEN the user runs `bambooinspect --version`
- THEN the CLI MUST display the current package version

#### Scenario: Agent subcommand group
- GIVEN the user runs `bambooinspect agent --help`
- THEN the CLI MUST display agent-specific commands: `register`, `start`, `stop`, `status`, `unregister`

---

### Requirement: Stateless Test Execution — run

The system MUST provide a `run` command to execute a single test by name without requiring a daemon or database.

#### Scenario: Run a specific script test
- GIVEN the user is in a git repo root with `tests/scripts/auth/login_test.py`
- WHEN the user runs `bambooinspect run login_test --type script`
- THEN the system MUST discover and execute `login_test.py` from the `tests/scripts/` tree
- AND output results to stdout/stderr
- AND exit with code 0 if the test passed, non-zero if it failed

#### Scenario: Run a specific prompt test
- GIVEN the user is in a git repo root with `tests/prompts/auth/test_login_flow.prompt`
- WHEN the user runs `bambooinspect run test_login_flow --type prompt`
- THEN the system MUST execute the prompt using Claude Code
- AND output the AI response to stdout

#### Scenario: Missing --type flag
- GIVEN the user runs `bambooinspect run login_test` without `--type`
- THEN the CLI MUST display an error message indicating that `--type` is required

#### Scenario: Test not found
- GIVEN the user runs `bambooinspect run nonexistent_test --type script`
- THEN the CLI MUST display an error message and exit with a non-zero code

---

### Requirement: Stateless Test Execution — run-module

The system MUST provide a `run-module` command to execute all tests within a specific module.

#### Scenario: Run all script tests in a module
- GIVEN the user is in a git repo root with `tests/scripts/auth/` containing multiple test files
- WHEN the user runs `bambooinspect run-module auth --type script`
- THEN the system MUST discover and execute all test files in `tests/scripts/auth/`
- AND output results for each test to stdout/stderr
- AND exit with code 0 only if all tests passed

#### Scenario: Module not found
- GIVEN the user runs `bambooinspect run-module nonexistent --type script`
- THEN the CLI MUST display an error message and exit with a non-zero code

---

### Requirement: Stateless Test Execution — run-all

The system MUST provide a `run-all` command to execute all tests of a given type in the current repository.

#### Scenario: Run all script tests
- GIVEN the user is in a git repo root with tests in `tests/scripts/`
- WHEN the user runs `bambooinspect run-all --type script`
- THEN the system MUST discover and execute all test files across all modules in `tests/scripts/`
- AND output a summary with total/passed/failed counts
- AND exit with code 0 only if all tests passed

#### Scenario: No tests found
- GIVEN the user is in a git repo root with no `tests/scripts/` directory
- WHEN the user runs `bambooinspect run-all --type script`
- THEN the CLI MUST display a message indicating no tests were found
- AND exit with a non-zero code

---

### Requirement: Report Options

The system MUST support report generation options on all execution commands.

#### Scenario: Default report
- GIVEN the user runs any execution command (run, run-module, run-all)
- WHEN the execution completes
- THEN the system MUST generate a template-based report and output it to stdout

#### Scenario: AI-powered report
- GIVEN the user runs `bambooinspect run-all --type script --report ai`
- WHEN the execution completes
- THEN the system MUST use Claude Code to generate a richer summary report

#### Scenario: Report output to file
- GIVEN the user runs `bambooinspect run-all --type script --report-output ./report.html`
- WHEN the execution completes
- THEN the system MUST save the report to the specified file path

---

### Requirement: Tracking Level Override

The system MUST support a `--tracking` option to override the default tracking level from `config.yaml`.

#### Scenario: Override tracking to none
- GIVEN the user runs `bambooinspect run-all --type script --tracking none`
- THEN the system MUST run without any process tracking (fastest mode)

#### Scenario: Override tracking to session
- GIVEN the user runs `bambooinspect run-all --type script --tracking session`
- THEN the system MUST group executions into a RunSession with per-test status

#### Scenario: Override tracking to full
- GIVEN the user runs `bambooinspect run-all --type script --tracking full`
- THEN the system MUST track session, per-test results, and step-by-step details

---

### Requirement: Agent Registration Command

The CLI MUST provide a command to register the agent with a Core Manager.

#### Scenario: Register agent
- **WHEN** the user runs `bambooinspect agent register --url http://core:8686 --token <reg-token> --name agent-01 --labels linux,playwright`
- **THEN** the CLI MUST send a registration request to the Core Manager
- **AND** store the returned persistent token in `~/.bambooinspect/agent.yaml`
- **AND** display a success message with the agent name and ID

#### Scenario: Register without required flags
- **WHEN** the user runs `bambooinspect agent register` without `--url` or `--token`
- **THEN** the CLI MUST display an error indicating the missing required flags

#### Scenario: Registration failure
- **WHEN** the registration token is invalid or expired
- **THEN** the CLI MUST display the error message from Core Manager and exit with non-zero code

---

### Requirement: Agent Start Command

The CLI MUST provide a command to start the agent process (poller + web UI).

#### Scenario: Start agent
- **WHEN** the user runs `bambooinspect agent start`
- **THEN** the CLI MUST start the agent polling loop and web server on port 8787
- **AND** begin sending heartbeats to the Core Manager

#### Scenario: Start with custom port
- **WHEN** the user runs `bambooinspect agent start --port 9999`
- **THEN** the agent web server MUST listen on port 9999

#### Scenario: Agent not registered
- **WHEN** the user runs `bambooinspect agent start` without prior registration (no `~/.bambooinspect/agent.yaml`)
- **THEN** the CLI MUST display an error indicating the agent is not registered
- **AND** suggest running `bambooinspect agent register` first

---

### Requirement: Agent Status Command

The CLI MUST provide a command to check the agent's current status.

#### Scenario: Show agent status
- **WHEN** the user runs `bambooinspect agent status`
- **THEN** the CLI MUST display:
  - Agent name and ID
  - Connection status to Core Manager (connected/disconnected)
  - Current status (idle/busy/offline)
  - Core Manager URL
  - Agent labels

#### Scenario: Agent not registered
- **WHEN** the user runs `bambooinspect agent status` without registration
- **THEN** the CLI MUST display "Agent is not registered"

---

### Requirement: Agent Stop Command

The CLI MUST provide a command to stop a running agent.

#### Scenario: Stop running agent
- **WHEN** the user runs `bambooinspect agent stop`
- **THEN** the CLI MUST gracefully stop the agent polling loop and web server
- **AND** display "Agent stopped"

---

### Requirement: Agent Unregister Command

The CLI MUST provide a command to unregister the agent from Core Manager.

#### Scenario: Unregister agent
- **WHEN** the user runs `bambooinspect agent unregister`
- **THEN** the CLI MUST send a deregistration request to the Core Manager
- **AND** delete the local `~/.bambooinspect/agent.yaml`
- **AND** display "Agent unregistered"

---

### Requirement: Not in Git Repo

The system MUST validate that stateless CLI commands are run from a git repository root.

#### Scenario: Not a git repo
- GIVEN the user is in a directory that is not a git repository
- WHEN the user runs `bambooinspect run-all --type script`
- THEN the CLI MUST display an error indicating the current directory is not a git repository
- AND exit with a non-zero code
