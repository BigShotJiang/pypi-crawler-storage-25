# Core Manager API Specification

## Overview

The Core Manager exposes REST API endpoints for agent management, registration token management, agent communication (task polling, result submission), task management, and a web dashboard with agent/task views.

---

## Requirements

### Requirement: Agent Management API

The Core Manager MUST expose REST API endpoints for managing agents.

#### Scenario: List all agents
- **WHEN** an admin sends `GET /api/admin/agents`
- **THEN** the Core Manager MUST return a list of all registered agents with id, name, labels, status, last_heartbeat_at, os_info, and registered_at

#### Scenario: Get agent details
- **WHEN** an admin sends `GET /api/admin/agents/{agent_id}`
- **THEN** the Core Manager MUST return the full agent record including metadata and task history summary

#### Scenario: Remove agent
- **WHEN** an admin sends `DELETE /api/admin/agents/{agent_id}`
- **THEN** the Core Manager MUST remove the agent and invalidate its token

#### Scenario: Update agent labels
- **WHEN** an admin sends `PATCH /api/admin/agents/{agent_id}` with `{ "labels": ["new-label"] }`
- **THEN** the Core Manager MUST update the agent's labels

---

### Requirement: Registration Token Management API

The Core Manager MUST expose endpoints for managing registration tokens.

#### Scenario: Create registration token
- **WHEN** an admin sends `POST /api/admin/registration-tokens` with optional `{ "description": "CI agent", "expires_in_minutes": 120 }`
- **THEN** the Core Manager MUST generate a token, store its hash, and return the plaintext token

#### Scenario: List registration tokens
- **WHEN** an admin sends `GET /api/admin/registration-tokens`
- **THEN** the Core Manager MUST return all tokens with id, description, created_at, expires_at, used, and used_by_agent_id (but NOT the plaintext token)

#### Scenario: Revoke registration token
- **WHEN** an admin sends `DELETE /api/admin/registration-tokens/{token_id}`
- **THEN** the Core Manager MUST delete the token, preventing future use

---

### Requirement: Agent Communication API

The Core Manager MUST expose REST API endpoints that agents use for communication.

#### Scenario: Agent registration endpoint
- **WHEN** an agent sends `POST /api/agent/register` with registration token and agent info
- **THEN** the Core Manager MUST process registration per the agent-registration spec

#### Scenario: Task polling endpoint
- **WHEN** an agent sends `GET /api/agent/tasks` with `Authorization: Bearer <agent-token>`
- **THEN** the Core Manager MUST return pending tasks for that agent
- **AND** update the agent's heartbeat timestamp

#### Scenario: Task start endpoint
- **WHEN** an agent sends `POST /api/agent/tasks/{execution_id}/start` with agent token
- **THEN** the Core Manager MUST set the execution status to `running`
- **AND** set the agent status to `busy`

#### Scenario: Task result endpoint
- **WHEN** an agent sends `POST /api/agent/tasks/{execution_id}/result` with execution result data
- **THEN** the Core Manager MUST update the Execution record
- **AND** update the RunSession aggregates
- **AND** set the agent status to `idle` if no more pending tasks

#### Scenario: Task details endpoint
- **WHEN** an agent sends `GET /api/agent/tasks/{execution_id}/details` with agent token
- **THEN** the Core Manager MUST return the full test details including path, type, timeout, retry_count, project path, and module name

---

### Requirement: Task Management API

The Core Manager MUST expose endpoints for administrators to manage task assignments.

#### Scenario: Create task assignment
- **WHEN** an admin sends `POST /api/admin/tasks` with agent_id, test_ids, and optional tracking level
- **THEN** the Core Manager MUST create Execution records assigned to the specified agent

#### Scenario: List tasks by agent
- **WHEN** an admin sends `GET /api/admin/tasks?agent_id={id}`
- **THEN** the Core Manager MUST return all tasks assigned to that agent

#### Scenario: List tasks by status
- **WHEN** an admin sends `GET /api/admin/tasks?status=running`
- **THEN** the Core Manager MUST return all tasks with the specified status

#### Scenario: Cancel task
- **WHEN** an admin sends `POST /api/admin/tasks/{execution_id}/cancel`
- **THEN** the Core Manager MUST cancel the task per the task-dispatch spec

---

### Requirement: Core Manager Web Dashboard Updates

The Core Manager web dashboard MUST include agent management and task assignment views.

#### Scenario: Agents panel
- **WHEN** an admin views the dashboard
- **THEN** there MUST be an "Agents" section showing all registered agents with status indicators

#### Scenario: Task assignment from dashboard
- **WHEN** an admin selects tests and clicks "Assign to Agent"
- **THEN** the dashboard MUST show available agents for selection
- **AND** create the task assignment via the API

#### Scenario: Task monitoring
- **WHEN** tasks are assigned and running
- **THEN** the dashboard MUST show real-time task status updates for each agent

---

### Requirement: Existing API Preservation

The Core Manager MUST preserve existing REST API endpoints for repository, test, webhook, and config management.

#### Scenario: Repository management APIs unchanged
- **WHEN** an admin uses `GET/POST/DELETE /api/repos` endpoints
- **THEN** they MUST function identically to the current implementation

#### Scenario: Test listing APIs unchanged
- **WHEN** an admin uses `GET /api/tests` endpoint
- **THEN** it MUST function identically to the current implementation

#### Scenario: Webhook APIs unchanged
- **WHEN** an admin uses webhook CRUD endpoints
- **THEN** they MUST function identically to the current implementation

#### Scenario: Git hook receiver unchanged
- **WHEN** a git provider sends a webhook to `/api/git-hook`
- **THEN** the Core Manager MUST process it identically to the current implementation
- **AND** MAY assign triggered tests to a configured default agent
