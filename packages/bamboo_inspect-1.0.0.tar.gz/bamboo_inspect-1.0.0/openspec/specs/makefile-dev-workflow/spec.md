# makefile-dev-workflow Specification

## Purpose
TBD - created by archiving change add-makefile-docker-support. Update Purpose after archive.
## Requirements
### Requirement: Makefile exists at project root
The project SHALL include a `Makefile` at the repository root that provides standardized development workflow targets.

#### Scenario: Makefile is present
- **WHEN** a developer clones the repository
- **THEN** a `Makefile` SHALL exist at the project root with documented targets

### Requirement: Install target
The Makefile SHALL provide an `install` target that creates a virtual environment and installs the package in editable mode with all dependencies.

#### Scenario: Fresh install
- **WHEN** a developer runs `make install`
- **THEN** a Python virtual environment SHALL be created (if not existing) and the package SHALL be installed in editable mode via `pip install -e .`

#### Scenario: Reinstall
- **WHEN** a developer runs `make install` with an existing virtual environment
- **THEN** dependencies SHALL be updated and the package reinstalled in editable mode

### Requirement: Lint target
The Makefile SHALL provide a `lint` target that runs code linting tools on the source code.

#### Scenario: Run linting
- **WHEN** a developer runs `make lint`
- **THEN** linting tools (ruff or flake8) SHALL be executed against `src/` and `tests/` directories
- **THEN** the exit code SHALL reflect whether linting passed (0) or failed (non-zero)

### Requirement: Format target
The Makefile SHALL provide a `format` target that auto-formats source code.

#### Scenario: Run formatting
- **WHEN** a developer runs `make format`
- **THEN** code formatting tools (ruff format or black) SHALL be executed against `src/` and `tests/` directories

### Requirement: Test target
The Makefile SHALL provide a `test` target that runs the project's test suite using Bamboo Inspect itself (dogfooding).

#### Scenario: Run tests
- **WHEN** a developer runs `make test`
- **THEN** `bambooinspect run-all --type script` SHALL be executed to run the project's own tests
- **THEN** the exit code SHALL reflect whether tests passed (0) or failed (non-zero)

### Requirement: Build target
The Makefile SHALL provide a `build` target that builds the Python package distribution.

#### Scenario: Build package
- **WHEN** a developer runs `make build`
- **THEN** the sdist and wheel distributions SHALL be built into the `dist/` directory using `python -m build`

### Requirement: Clean target
The Makefile SHALL provide a `clean` target that removes build artifacts and caches.

#### Scenario: Clean artifacts
- **WHEN** a developer runs `make clean`
- **THEN** the `dist/`, `build/`, `*.egg-info`, `__pycache__`, and `.pytest_cache` directories SHALL be removed

### Requirement: Docker shortcut targets
The Makefile SHALL provide shortcut targets for Docker operations.

#### Scenario: Start development containers
- **WHEN** a developer runs `make docker-dev`
- **THEN** `docker compose -f docker-compose.yml up --build` SHALL be executed to start the development environment

#### Scenario: Start production containers
- **WHEN** a developer runs `make docker-prod`
- **THEN** `docker compose -f docker-compose.prod.yml up --build -d` SHALL be executed to start production services in detached mode

#### Scenario: Stop containers
- **WHEN** a developer runs `make docker-down`
- **THEN** all running docker compose services SHALL be stopped and removed

### Requirement: Help target
The Makefile SHALL provide a `help` target (and it SHALL be the default target) that lists all available targets with descriptions.

#### Scenario: Show help
- **WHEN** a developer runs `make` or `make help`
- **THEN** a formatted list of all available Makefile targets with brief descriptions SHALL be printed to stdout

