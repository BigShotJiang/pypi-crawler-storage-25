# web-dashboard Specification

## Purpose
TBD - created by archiving change web-dashboard-ui. Update Purpose after archive.
## Requirements
### Requirement: SPA navigation with sidebar

The web UI SHALL be a single-page application with a persistent sidebar navigation. The sidebar SHALL contain links to: Dashboard, Repositories, Tests, Executions, Webhooks, and Configuration. Clicking a navigation item SHALL display the corresponding page content without a full page reload. The currently active page SHALL be visually highlighted in the sidebar.

#### Scenario: User navigates between pages

- **WHEN** user clicks "Tests" in the sidebar while on the Dashboard page
- **THEN** the main content area displays the Tests page and the "Tests" link is highlighted in the sidebar

#### Scenario: Page loads with default view

- **WHEN** user opens the web UI at the root URL (port 8686)
- **THEN** the Dashboard page is displayed by default and the "Dashboard" link is highlighted

#### Scenario: URL hash routing

- **WHEN** user navigates to a page (e.g., Repositories)
- **THEN** the URL hash updates to reflect the current page (e.g., `#repos`)
- **WHEN** user refreshes the browser on a hash URL
- **THEN** the corresponding page is restored

---

### Requirement: Dashboard overview page

The Dashboard page SHALL display summary statistics and recent activity. It SHALL show total repositories count, total tests count, recent execution pass/fail counts, and a list of recent executions. Data SHALL be fetched from `/api/repos`, `/api/tests`, and `/api/executions` endpoints.

#### Scenario: Dashboard displays summary statistics

- **WHEN** user views the Dashboard page
- **THEN** the page displays cards showing: total repositories, total tests, recent passed count, and recent failed count

#### Scenario: Dashboard displays recent executions

- **WHEN** user views the Dashboard page
- **THEN** a list of the most recent executions is shown with test name, status (passed/failed/pending/running), duration, and timestamp

#### Scenario: Dashboard with no data

- **WHEN** user views the Dashboard and no repositories or executions exist
- **THEN** the statistics cards show zero values and the executions list shows an empty state message

---

### Requirement: Repository management page

The Repositories page SHALL allow users to list, add, remove, and rescan repositories. The list SHALL display each repository's name, path, git remote URL, and last scan time. Users SHALL be able to add a repo by entering its filesystem path and remove a repo by clicking a delete action.

#### Scenario: List repositories

- **WHEN** user navigates to the Repositories page
- **THEN** all registered repositories are listed with name, path, git remote URL, and last scan timestamp fetched from `GET /api/repos`

#### Scenario: Add a repository

- **WHEN** user enters a filesystem path in the add-repo input and submits
- **THEN** a `POST /api/repos` request is sent with `{"path": "<entered_path>"}` and the list refreshes to show the new repository

#### Scenario: Add repository with invalid path

- **WHEN** user submits a path that is not a valid git repository
- **THEN** an error message from the API response is displayed to the user

#### Scenario: Remove a repository

- **WHEN** user clicks the delete action on a repository row
- **THEN** a confirmation prompt is shown, and upon confirmation, `DELETE /api/repos/{name}` is called and the repository is removed from the list

#### Scenario: Rescan a repository

- **WHEN** user clicks the rescan action on a repository row
- **THEN** `POST /api/repos/{name}/scan` is called and the updated module/test counts are displayed

---

### Requirement: Test browser page

The Tests page SHALL display all registered tests, grouped or filterable by project and module. Each test entry SHALL show name, type (script/prompt), module name, and path. Users SHALL be able to trigger a test run from this page.

#### Scenario: List all tests

- **WHEN** user navigates to the Tests page
- **THEN** all tests are displayed fetched from `GET /api/tests`

#### Scenario: Filter tests by project

- **WHEN** user selects a project from the project filter dropdown
- **THEN** only tests belonging to that project are shown (via `GET /api/tests?project=<name>`)

#### Scenario: Trigger a test run

- **WHEN** user clicks the "Run" button on a test row
- **THEN** `POST /api/tests/{test_id}/run` is called, the returned execution ID is displayed, and the test status updates to "queued"

#### Scenario: No tests registered

- **WHEN** user navigates to the Tests page and no tests exist
- **THEN** an empty state message is shown suggesting the user add a repository first

---

### Requirement: Execution history page

The Executions page SHALL display a chronological list of test executions. Each entry SHALL show execution ID, test name, status, duration, triggered-by source, and timestamp. Users SHALL be able to expand an execution to view logs and error details.

#### Scenario: List recent executions

- **WHEN** user navigates to the Executions page
- **THEN** the most recent executions are listed from `GET /api/executions` ordered by time descending

#### Scenario: View execution details

- **WHEN** user clicks on an execution row
- **THEN** the row expands to show logs, error message (if any), and duration details fetched from `GET /api/executions/{exec_id}`

#### Scenario: Execution status display

- **WHEN** an execution has status "passed"
- **THEN** it is displayed with a green indicator
- **WHEN** an execution has status "failed"
- **THEN** it is displayed with a red indicator
- **WHEN** an execution has status "running"
- **THEN** it is displayed with a blue/animated indicator

---

### Requirement: Webhook management page

The Webhooks page SHALL allow users to list, create, and delete outgoing webhooks. Each webhook entry SHALL display URL, active status, retry count, and configured events.

#### Scenario: List webhooks

- **WHEN** user navigates to the Webhooks page
- **THEN** all webhooks are listed from `GET /api/webhooks` showing URL, active status, and retry count

#### Scenario: Create a webhook

- **WHEN** user enters a webhook URL and submits the create form
- **THEN** `POST /api/webhooks` is called with `{"url": "<entered_url>"}` and the list refreshes

#### Scenario: Delete a webhook

- **WHEN** user clicks the delete action on a webhook row
- **THEN** a confirmation prompt is shown, and upon confirmation, `DELETE /api/webhooks/{id}` is called and the webhook is removed from the list

---

### Requirement: Configuration page

The Configuration page SHALL display all config key-value pairs and allow editing values. Config entries SHALL be fetched from `GET /api/config` and updates sent via `PUT /api/config/{key}`.

#### Scenario: List configuration entries

- **WHEN** user navigates to the Configuration page
- **THEN** all config entries are listed showing key and value from `GET /api/config`

#### Scenario: Update a config value

- **WHEN** user edits a config value and saves
- **THEN** `PUT /api/config/{key}` is called with `{"value": <new_value>}` and the entry updates in the list

---

### Requirement: Concise dark-themed visual design

The web UI SHALL use a dark color scheme consistent with the existing palette (dark backgrounds, light text, blue accent). The design SHALL be concise and minimal — no unnecessary decoration, compact spacing, clear typography. All interactive elements (buttons, inputs, links) SHALL have visible hover/focus states.

#### Scenario: Consistent color palette

- **WHEN** user views any page in the web UI
- **THEN** the page uses the established dark theme variables: `--bg: #0d1117`, `--card: #161b22`, `--border: #30363d`, `--text: #c9d1d9`, `--accent: #58a6ff`, `--green: #3fb950`

#### Scenario: Responsive layout

- **WHEN** user accesses the web UI on a screen narrower than 768px
- **THEN** the sidebar collapses or adapts and content remains usable

---

### Requirement: API error handling in the UI

The web UI SHALL gracefully handle API errors. When an API call fails, the UI SHALL display the error message from the response body. When the daemon/database is unavailable (503), the UI SHALL show a connection error state.

#### Scenario: API returns an error

- **WHEN** an API call returns a 4xx or 5xx status code with a JSON `{"detail": "..."}` body
- **THEN** the error detail message is displayed to the user in a visible notification

#### Scenario: Network failure

- **WHEN** an API call fails due to network error (fetch throws)
- **THEN** a "Connection error" message is displayed to the user

---

### Requirement: Loading states

The web UI SHALL display loading indicators while data is being fetched from the API. Content areas SHALL show a loading state until data arrives.

#### Scenario: Page data loading

- **WHEN** user navigates to a page that fetches data from the API
- **THEN** a loading indicator is shown in the content area until the API response is received

