# Agent Web UI Specification

## Overview

The Test Agent runs a lightweight FastAPI web server for local monitoring and management, providing a dashboard to view agent status, current tasks, and task history.

---

## Requirements

### Requirement: Agent Web Server

The Test Agent MUST run a lightweight FastAPI web server for local monitoring and management.

#### Scenario: Agent web server starts
- **WHEN** the agent starts via `bambooinspect agent start`
- **THEN** a FastAPI web server MUST start on port 8787 (default)
- **AND** serve a web-based dashboard

#### Scenario: Custom port
- **WHEN** the agent starts with `bambooinspect agent start --port 9999`
- **THEN** the web server MUST listen on port 9999

#### Scenario: Health endpoint
- **WHEN** a client sends `GET /api/health` to the agent
- **THEN** the agent MUST return `{ "status": "ok", "agent_name": "<name>" }`

---

### Requirement: Agent Dashboard

The agent web UI MUST display the current state of the agent and its tasks.

#### Scenario: Status overview
- **WHEN** a user opens the agent dashboard at `http://localhost:8787`
- **THEN** the page MUST display:
  - Agent name and labels
  - Current status (idle/busy/offline)
  - Core Manager URL and connection status (connected/disconnected)
  - Agent uptime

#### Scenario: Current task display
- **WHEN** the agent is executing a task
- **THEN** the dashboard MUST show the currently running test name, module, type, and elapsed time
- **AND** stream the test's stdout/stderr output in real-time

#### Scenario: Task history
- **WHEN** a user views the task history section
- **THEN** the dashboard MUST show recent completed tasks with:
  - Test name and module
  - Status (passed/failed)
  - Duration
  - Timestamp

---

### Requirement: Agent Dashboard Technology

The agent web UI MUST be built with vanilla HTML/JS/CSS, consistent with the project's frontend approach.

#### Scenario: Lightweight frontend
- **WHEN** the agent dashboard loads in a browser
- **THEN** it MUST NOT require any heavy JavaScript framework (React, Vue, Angular, etc.)
- **AND** static files MUST be served from within the `bamboo_inspect` package

---

### Requirement: Local-Only Access

The agent web UI MUST default to local-only access for security.

#### Scenario: Default binding
- **WHEN** the agent starts without explicit host configuration
- **THEN** the web server MUST bind to `127.0.0.1` (localhost only)

#### Scenario: Configurable binding
- **WHEN** the agent config sets `agent.host: "0.0.0.0"`
- **THEN** the web server MUST bind to all interfaces
