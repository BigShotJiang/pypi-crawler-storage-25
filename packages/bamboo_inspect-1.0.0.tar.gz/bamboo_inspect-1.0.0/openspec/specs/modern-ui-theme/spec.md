## ADDED Requirements

### Requirement: Dark Mode Theme
The application SHALL use a dark-themed color palette by default, utilizing CSS variables for consistent theming.

#### Scenario: Default Load
- **WHEN** user loads the application
- **THEN** darkness-oriented colors (backgrounds #0f1117, #1a1d27) are applied

### Requirement: Glassmorphism Design
The application SHALL employ glassmorphism effects (backdrop-filter: blur, semi-transparent backgrounds) for overlays and floating elements.

#### Scenario: Modal Open
- **WHEN** a modal is opened
- **THEN** the background overlay has a blur effect
