# Execution Engine Specification

## Overview

The Execution Engine is responsible for running tests and collecting results. It consists of two executors: the **Playwright Executor** for script tests and the **Claude Code Executor** for AI prompt tests. Both operate in stateless CLI mode (direct execution) and agent mode (execute tasks assigned by the Core Manager). Executors run exclusively on the **Test Agent** side, never on the Core Manager.

---

## Requirements

### Requirement: Playwright Executor

The system MUST provide a Playwright Executor that runs script test files as subprocesses. The executor runs exclusively on the **Test Agent** side, never on the Core Manager.

#### Scenario: Execute Python script test
- GIVEN a script test file `tests/scripts/auth/login_test.py`
- WHEN the agent's executor runs the test
- THEN it MUST spawn a subprocess to execute the Python file
- AND capture stdout and stderr
- AND record the exit code (0 = passed, non-zero = failed)
- AND measure the execution duration

#### Scenario: Execute JavaScript script test
- GIVEN a script test file `tests/scripts/checkout/cart_test.js`
- WHEN the agent's executor runs the test
- THEN it MUST spawn a subprocess using Node.js to execute the file

#### Scenario: Execute TypeScript script test
- GIVEN a script test file `tests/scripts/checkout/payment_test.ts`
- WHEN the agent's executor runs the test
- THEN it MUST spawn a subprocess using an appropriate TypeScript runner

#### Scenario: Test timeout
- GIVEN a script test with a timeout of 30 seconds
- WHEN the test execution exceeds 30 seconds
- THEN the executor MUST terminate the subprocess
- AND mark the test as failed with a timeout error

#### Scenario: Test retry
- GIVEN a script test with `retry_count: 2`
- WHEN the test fails on the first attempt
- THEN the executor MUST retry the test up to 2 additional times
- AND mark the test as passed if any retry succeeds

#### Scenario: Artifact capture
- GIVEN a script test that produces screenshots, videos, or trace files
- WHEN the test completes
- THEN the executor MAY capture artifact file paths in the results

---

### Requirement: Claude Code Executor

The system MUST provide a Claude Code Executor that runs AI prompt tests using the `claude-code` npm library. The executor runs exclusively on the **Test Agent** side.

#### Scenario: Execute prompt test
- GIVEN a prompt file `tests/prompts/auth/test_login_flow.prompt`
- WHEN the agent's executor runs the prompt
- THEN it MUST read the prompt file content
- AND invoke the `claude-code` npm library with the prompt
- AND capture the AI response

#### Scenario: MCP tools support
- GIVEN a prompt test configured with MCP tools
- WHEN the agent's executor runs the prompt
- THEN it MAY pass MCP tool configurations to `claude-code`

#### Scenario: Prompt execution result
- GIVEN a prompt test completes
- THEN the executor MUST record: AI response content, tool usage details, execution duration, pass/fail status

---

### Requirement: Sequential Execution in Stateless CLI

In stateless CLI mode, the executor MUST run tests sequentially. This behavior is unchanged.

#### Scenario: Sequential script execution
- GIVEN the user runs `bambooinspect run-all --type script` with 5 tests
- THEN the executor MUST run tests one after another (not in parallel)
- AND output results to stdout/stderr as each test completes

---

### Requirement: Result Collection

The executor MUST collect and aggregate test results. When running as an agent, results are submitted to the Core Manager.

#### Scenario: Successful test result
- GIVEN a script test completes successfully
- THEN the result MUST include: status `passed`, duration, stdout/stderr logs, artifacts (if any)

#### Scenario: Failed test result
- GIVEN a script test fails
- THEN the result MUST include: status `failed`, duration, error message, stdout/stderr logs, artifacts (if any)

#### Scenario: Result submission to Core Manager
- GIVEN a test executes as part of an agent task
- WHEN the test completes
- THEN the agent MUST submit the result to the Core Manager via `POST /api/agent/tasks/{execution_id}/result`

---

### Requirement: Process Tracking

The executor MUST support configurable tracking levels.

#### Scenario: Tracking level none
- GIVEN `--tracking none` is specified
- THEN the executor MUST run tests without creating any tracking records
- AND output results directly to stdout/stderr

#### Scenario: Tracking level session
- GIVEN `--tracking session` is specified
- THEN the executor MUST create a RunSession record
- AND create an Execution record for each test
- AND update the RunSession with aggregate pass/fail counts

#### Scenario: Tracking level full
- GIVEN `--tracking full` is specified
- THEN the executor MUST create RunSession and Execution records
- AND create ExecutionStep records for individual steps within each test
- AND track assertions, navigations, and API calls as separate steps
