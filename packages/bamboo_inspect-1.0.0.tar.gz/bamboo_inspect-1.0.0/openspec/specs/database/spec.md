# Database & Storage Layer Specification

## Overview

The Storage Layer provides persistent data storage for the Core Manager using PostgreSQL via asyncpg with raw SQL (no ORM). Schema migrations are managed by bamboo-database (`bamboodb` CLI). All table references use unique hash IDs instead of foreign keys for loose coupling.

---

## Requirements

### Requirement: Database Connection

The system MUST connect to PostgreSQL using asyncpg with a connection pool.

#### Scenario: Connection pool initialization
- GIVEN valid database configuration in `config.yaml`
- WHEN the daemon starts
- THEN the system MUST create an asyncpg connection pool
- AND validate the connection by executing a simple query

#### Scenario: Invalid database configuration
- GIVEN incorrect database credentials in `config.yaml`
- WHEN the daemon attempts to connect
- THEN the system MUST display a clear error message
- AND fail to start the daemon

#### Scenario: Connection pool cleanup
- GIVEN the daemon is shutting down
- THEN the system MUST close the asyncpg connection pool gracefully

---

### Requirement: No ORM

The system MUST use raw SQL queries for all database operations.

#### Scenario: Raw SQL queries
- GIVEN any database operation is performed
- THEN it MUST use parameterized raw SQL via asyncpg
- AND all query functions MUST be defined in `db/queries.py`
- AND the system MUST NOT use any ORM (SQLAlchemy, Django ORM, Tortoise, etc.)

---

### Requirement: Schema Migrations

The system MUST use bamboo-database (`bamboodb`) for schema migrations.

#### Scenario: Run migrations
- GIVEN migration SQL files exist in the `migrations/` directory
- WHEN `bamboodb migrate` is executed
- THEN all pending migrations MUST be applied in order

#### Scenario: Migration file format
- GIVEN a new schema change is needed
- THEN a new raw SQL migration file MUST be created in `migrations/`
- AND follow the bamboo-database naming convention

---

### Requirement: No Foreign Keys

The system MUST NOT use database foreign keys. All references use unique hash IDs.

#### Scenario: Loose coupling via hash IDs
- GIVEN a Test record references a Module
- THEN the `module_id` column MUST store the Module's unique hash ID
- AND there MUST NOT be a foreign key constraint between the tables

---

### Requirement: Project Table

The system MUST maintain a `Project` table.

#### Scenario: Project record
- GIVEN a repository is registered
- THEN a Project record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `name`: project name
  - `path`: filesystem path to the repository
  - `git_remote_url`: git remote URL (if available)
  - `created_at`: timestamp
  - `last_scan`: timestamp of last test scan

---

### Requirement: Module Table

The system MUST maintain a `Module` table.

#### Scenario: Module record
- GIVEN a test module is discovered during scanning
- THEN a Module record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `project_id`: VARCHAR referencing the Project
  - `name`: module name (directory name)
  - `path`: relative path to the module directory

---

### Requirement: Test Table

The system MUST maintain a `Test` table.

#### Scenario: Test record
- GIVEN a test file is discovered during scanning
- THEN a Test record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `module_id`: VARCHAR referencing the Module
  - `name`: test name (filename without extension)
  - `type`: `script` or `prompt`
  - `path`: relative path to the test file
  - `description`: test description (nullable)
  - `tags`: JSONB array of tags
  - `timeout`: timeout in seconds (nullable)
  - `retry_count`: number of retries (default 0)

---

### Requirement: Agent Table

The system MUST maintain an `agent` table in the Core Manager database.

#### Scenario: Agent record
- **WHEN** an agent registers with the Core Manager
- **THEN** an Agent record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `name`: VARCHAR, UNIQUE, the agent's display name
  - `labels`: JSONB array of label strings
  - `status`: VARCHAR (`online`, `idle`, `busy`, `offline`)
  - `token_hash`: VARCHAR, hash of the agent's persistent token
  - `registered_at`: TIMESTAMP
  - `last_heartbeat_at`: TIMESTAMP (nullable)
  - `os_info`: JSONB with platform, version, architecture
  - `metadata`: JSONB for additional agent info (nullable)

---

### Requirement: Registration Token Table

The system MUST maintain a `registration_token` table in the Core Manager database.

#### Scenario: Registration token record
- **WHEN** an admin generates a registration token
- **THEN** a record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `token_hash`: VARCHAR, hash of the plaintext token
  - `description`: VARCHAR (nullable)
  - `created_at`: TIMESTAMP
  - `expires_at`: TIMESTAMP
  - `used`: BOOLEAN (default false)
  - `used_by_agent_id`: VARCHAR (nullable, ref Agent)

---

### Requirement: RunSession Table

The system MUST maintain a `RunSession` table for grouping test executions.

#### Scenario: RunSession record
- GIVEN a test run with tracking level `session` or `full` is initiated
- THEN a RunSession record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `project_id`: VARCHAR referencing the Project
  - `agent_id`: VARCHAR referencing the Agent (nullable — null for stateless CLI runs)
  - `tracking_level`: `none`, `session`, or `full`
  - `status`: `pending`, `running`, `passed`, `failed`, or `cancelled`
  - `total_tests`: integer count of tests in the session
  - `passed`: integer count of passed tests
  - `failed`: integer count of failed tests
  - `triggered_by`: `manual`, `git_hook`, or `scheduled`
  - `git_commit_sha`: current git commit (nullable)
  - `started_at`: timestamp
  - `finished_at`: timestamp (nullable)

---

### Requirement: Execution Table

The system MUST maintain an `Execution` table for individual test results.

#### Scenario: Execution record
- GIVEN a test execution completes
- THEN an Execution record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `session_id`: VARCHAR referencing RunSession (nullable)
  - `test_id`: VARCHAR referencing the Test
  - `agent_id`: VARCHAR referencing the Agent (nullable — null for stateless CLI runs)
  - `status`: `pending`, `running`, `passed`, `failed`, or `cancelled`
  - `duration`: execution duration in milliseconds
  - `error_message`: error text (nullable)
  - `logs`: TEXT containing stdout/stderr
  - `artifacts`: JSONB with artifact file paths
  - `triggered_by`: `manual`, `git_hook`, or `scheduled`
  - `git_commit_sha`: current git commit (nullable)

---

### Requirement: ExecutionStep Table

The system MUST maintain an `ExecutionStep` table for step-level tracking.

#### Scenario: ExecutionStep record
- GIVEN tracking level is `full` and a test step completes
- THEN an ExecutionStep record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `execution_id`: VARCHAR referencing the Execution
  - `step_order`: integer indicating step sequence
  - `name`: step name/description
  - `status`: `passed`, `failed`, or `skipped`
  - `duration`: step duration in milliseconds
  - `error_message`: error text (nullable)
  - `created_at`: timestamp

---

### Requirement: Report Table

The system MUST maintain a `Report` table.

#### Scenario: Report record
- GIVEN a report is generated in daemon mode
- THEN a Report record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `execution_id`: VARCHAR referencing Execution (nullable)
  - `session_id`: VARCHAR referencing RunSession (nullable)
  - `format`: `html`, `markdown`, or `json`
  - `source`: `template` or `ai`
  - `content`: TEXT containing the full report
  - `created_at`: timestamp

---

### Requirement: Webhook Table

The system MUST maintain a `Webhook` table.

#### Scenario: Webhook record
- GIVEN a webhook is registered
- THEN a Webhook record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `url`: webhook URL
  - `headers`: JSONB with custom headers
  - `auth_type`: authentication type (nullable)
  - `auth_config`: JSONB with auth configuration
  - `events`: JSONB array of event types to trigger on
  - `retry_count`: number of retries
  - `active`: BOOLEAN indicating if the webhook is enabled

---

### Requirement: Config Table

The system MUST maintain a `Config` table for persistent settings.

#### Scenario: Config record
- GIVEN a configuration key-value pair
- THEN a Config record MUST be created with:
  - `id`: VARCHAR primary key (unique hash)
  - `key`: UNIQUE string key
  - `value`: JSONB value

---

### Requirement: Data Retention

The system MUST support configurable data retention.

#### Scenario: Retention cleanup
- GIVEN `data_collection.retention_days` is set to 30 in config
- WHEN the daemon performs maintenance
- THEN it MUST delete Execution, ExecutionStep, RunSession, and Report records older than 30 days
