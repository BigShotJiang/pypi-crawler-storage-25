#!/usr/bin/env bash
set -e

# ============================================================
# Bamboo Inspect Core Manager — Docker Entrypoint
# Runs database migrations, then starts the Core Manager server.
# ============================================================

# Run database migrations (idempotent — safe on every start)
echo "Running database migrations..."
bamboodb migrate || echo "Warning: migrations failed — check database connectivity"

# Execute the command passed to the container
exec "$@"
