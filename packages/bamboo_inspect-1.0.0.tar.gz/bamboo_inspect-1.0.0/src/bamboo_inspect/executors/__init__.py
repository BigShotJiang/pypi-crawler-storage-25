"""Execution engine sub-package for Bamboo Inspect.

Contains executors for running different test types:
- PlaywrightExecutor: Runs script tests (.py, .js, .ts) as subprocesses
- ClaudeCodeExecutor: Runs AI prompt tests (.prompt) via claude-code npm library
"""
