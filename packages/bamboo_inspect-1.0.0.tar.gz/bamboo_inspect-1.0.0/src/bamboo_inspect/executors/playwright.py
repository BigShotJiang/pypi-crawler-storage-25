"""Playwright test executor for Bamboo Inspect.

Spawns subprocesses to execute script test files (.py, .js, .ts).
Captures stdout/stderr, exit codes, handles timeouts and retries.
Supports artifact capture (screenshots, videos, trace files).
"""

import asyncio
import sys
import time
from pathlib import Path
from typing import Any, Optional


def _get_runtime(test_path: Path) -> list[str]:
    """Determine the runtime command for a test file based on extension.

    Returns:
        A list of command parts to execute the file.
    """
    suffix = test_path.suffix.lower()
    match suffix:
        case ".py":
            return [sys.executable, str(test_path)]
        case ".js":
            return ["node", str(test_path)]
        case ".ts":
            return ["npx", "tsx", str(test_path)]
        case _:
            raise ValueError(f"Unsupported test file extension: {suffix}")


class PlaywrightExecutor:
    """Executor for Playwright script tests."""

    async def execute(
        self,
        test_path: Path,
        *,
        timeout: Optional[int] = None,
        retry_count: int = 0,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute a Playwright test script.

        Args:
            test_path: Path to the test file.
            timeout: Maximum execution time in seconds. ``None`` = no limit.
            retry_count: Number of retry attempts on failure.
            **kwargs: Additional execution options.

        Returns:
            Dictionary with execution results (status, duration, logs, artifacts).
        """
        last_result: dict[str, Any] = {}

        for attempt in range(1 + retry_count):
            result = await self._run_once(test_path, timeout=timeout)
            last_result = result

            if result["status"] == "passed":
                return result

            # If we have retries left, continue
            if attempt < retry_count:
                continue

        return last_result

    async def _run_once(
        self,
        test_path: Path,
        *,
        timeout: Optional[int] = None,
    ) -> dict[str, Any]:
        """Execute a single test run (no retries)."""
        cmd = _get_runtime(test_path)
        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(test_path.parent),
            )

            try:
                if timeout:
                    stdout, stderr = await asyncio.wait_for(
                        proc.communicate(), timeout=timeout,
                    )
                else:
                    stdout, stderr = await proc.communicate()
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                duration_ms = int((time.monotonic() - start) * 1000)
                return {
                    "status": "failed",
                    "duration": duration_ms,
                    "logs": "",
                    "error_message": f"Test timed out after {timeout}s",
                    "artifacts": {},
                }

            duration_ms = int((time.monotonic() - start) * 1000)
            stdout_text = stdout.decode("utf-8", errors="replace") if stdout else ""
            stderr_text = stderr.decode("utf-8", errors="replace") if stderr else ""
            logs = stdout_text
            if stderr_text:
                logs += f"\n--- stderr ---\n{stderr_text}"

            passed = proc.returncode == 0

            return {
                "status": "passed" if passed else "failed",
                "duration": duration_ms,
                "logs": logs,
                "error_message": None if passed else (stderr_text.strip() or f"Exit code {proc.returncode}"),
                "artifacts": {},
            }

        except FileNotFoundError as exc:
            duration_ms = int((time.monotonic() - start) * 1000)
            return {
                "status": "failed",
                "duration": duration_ms,
                "logs": "",
                "error_message": f"Runtime not found: {exc}",
                "artifacts": {},
            }
