"""Claude Code AI executor for Bamboo Inspect.

Executes AI prompt tests using the claude-code npm library.
Reads prompt files (.prompt), invokes Claude Code, and captures
AI responses, tool usage, and execution results.
"""

import asyncio
import shutil
import time
from pathlib import Path
from typing import Any, Optional


class ClaudeCodeExecutor:
    """Executor for Claude Code AI prompt tests."""

    async def execute(
        self,
        prompt_path: Path,
        *,
        timeout: Optional[int] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute an AI prompt test via Claude Code.

        Args:
            prompt_path: Path to the .prompt file.
            timeout: Maximum execution time in seconds. ``None`` = no limit.
            **kwargs: Additional execution options (MCP tools, timeout, etc.).

        Returns:
            Dictionary with execution results (status, response, duration, tool_usage).
        """
        # Check that the claude CLI is available
        claude_bin = shutil.which("claude")
        if claude_bin is None:
            return {
                "status": "failed",
                "duration": 0,
                "response": "",
                "logs": "",
                "error_message": (
                    "claude CLI not found. Install it with: "
                    "npm install -g @anthropic-ai/claude-code"
                ),
            }

        # Read the prompt content
        try:
            prompt_content = prompt_path.read_text(encoding="utf-8")
        except OSError as exc:
            return {
                "status": "failed",
                "duration": 0,
                "response": "",
                "logs": "",
                "error_message": f"Could not read prompt file: {exc}",
            }

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                claude_bin, "--print", "-p", prompt_content,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(prompt_path.parent),
            )

            try:
                if timeout:
                    stdout, stderr = await asyncio.wait_for(
                        proc.communicate(), timeout=timeout,
                    )
                else:
                    stdout, stderr = await proc.communicate()
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                duration_ms = int((time.monotonic() - start) * 1000)
                return {
                    "status": "failed",
                    "duration": duration_ms,
                    "response": "",
                    "logs": "",
                    "error_message": f"Prompt execution timed out after {timeout}s",
                }

            duration_ms = int((time.monotonic() - start) * 1000)
            stdout_text = stdout.decode("utf-8", errors="replace") if stdout else ""
            stderr_text = stderr.decode("utf-8", errors="replace") if stderr else ""

            passed = proc.returncode == 0

            return {
                "status": "passed" if passed else "failed",
                "duration": duration_ms,
                "response": stdout_text,
                "logs": stderr_text,
                "error_message": None if passed else (stderr_text.strip() or f"Exit code {proc.returncode}"),
            }

        except FileNotFoundError:
            duration_ms = int((time.monotonic() - start) * 1000)
            return {
                "status": "failed",
                "duration": duration_ms,
                "response": "",
                "logs": "",
                "error_message": "claude CLI not found in PATH",
            }
