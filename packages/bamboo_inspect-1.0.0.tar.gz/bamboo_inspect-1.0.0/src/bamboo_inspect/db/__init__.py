"""Database sub-package — placeholder for agent package.

Database operations have moved to the Core Manager (server/db/).
This package is kept for backward compatibility but contains no
active code in the agent package.
"""
