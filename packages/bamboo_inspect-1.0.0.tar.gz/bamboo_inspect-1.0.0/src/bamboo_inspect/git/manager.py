"""Git repository manager for Bamboo Inspect.

Manages the relationship between git repositories and Bamboo Inspect.
Handles repository validation, registration, git metadata extraction,
and filesystem path management.
"""

import subprocess
from pathlib import Path
from typing import Optional


class GitManager:
    """Manages git repository operations."""

    def validate_repo(self, path: Path) -> bool:
        """Validate that a directory is a git repository.

        Args:
            path: Directory path to validate.

        Returns:
            True if the directory is a valid git repository.
        """
        if not path.exists():
            return False
        # Check for .git directory first (fast path)
        if (path / ".git").exists():
            return True
        # Fall back to git command (handles bare repos, worktrees, etc.)
        try:
            result = subprocess.run(
                ["git", "-C", str(path), "rev-parse", "--git-dir"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False

    def get_repo_root(self, path: Path) -> Path:
        """Get the root directory of the git repository.

        Args:
            path: Any path within the git repository.

        Returns:
            Path to the repository root directory.

        Raises:
            RuntimeError: If the path is not within a git repository.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(path), "rev-parse", "--show-toplevel"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"Not a git repository: {path}\n{result.stderr.strip()}"
                )
            return Path(result.stdout.strip())
        except FileNotFoundError:
            raise RuntimeError("git is not installed or not in PATH")

    def get_remote_url(self, repo_path: Path) -> Optional[str]:
        """Get the remote URL of the git repository.

        Args:
            repo_path: Path to the repository root.

        Returns:
            The remote URL string, or None if no remote is configured.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "remote", "get-url", "origin"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip() or None
            return None
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None

    def get_commit_sha(self, repo_path: Path) -> str:
        """Get the current HEAD commit SHA.

        Args:
            repo_path: Path to the repository root.

        Returns:
            The current HEAD commit SHA string.

        Raises:
            RuntimeError: If the SHA cannot be retrieved.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"Could not get commit SHA: {result.stderr.strip()}"
                )
            return result.stdout.strip()
        except FileNotFoundError:
            raise RuntimeError("git is not installed or not in PATH")

    def get_current_branch(self, repo_path: Path) -> Optional[str]:
        """Get the current branch name.

        Args:
            repo_path: Path to the repository root.

        Returns:
            The current branch name, or None if in detached HEAD state.
        """
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                branch = result.stdout.strip()
                return None if branch == "HEAD" else branch
            return None
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None
