"""Git integration sub-package for Bamboo Inspect Agent.

Provides repository validation and git metadata extraction.
The git webhook receiver has moved to the Core Manager (server/api/git_hook.py).
"""
