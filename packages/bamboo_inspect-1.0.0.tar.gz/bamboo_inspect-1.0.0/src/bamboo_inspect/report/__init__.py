"""Report generation sub-package for Bamboo Inspect.

Produces reports after test execution using template-based rendering
(HTML, Markdown, JSON) or AI-generated content via Claude Code.
"""
