"""Template-based report renderer for Bamboo Inspect.

Renders test execution results using built-in templates (HTML, Markdown, JSON).
Templates are stored in the templates/ subdirectory.
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from string import Template
from typing import Any

from bamboo_inspect import __version__

_TEMPLATES_DIR = Path(__file__).parent / "templates"


def _format_duration(ms: int) -> str:
    """Format milliseconds into a human-readable string."""
    if ms < 1000:
        return f"{ms}ms"
    seconds = ms / 1000
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    secs = seconds % 60
    return f"{minutes}m {secs:.0f}s"


class ReportRenderer:
    """Renders test results into formatted reports."""

    def render(
        self,
        results: list[dict[str, Any]],
        format: str = "html",
    ) -> str:
        """Render test results into a report.

        Args:
            results: List of test result dictionaries. Each must contain
                     at least ``name``, ``module``, ``status``, ``duration``.
            format: Output format (``'html'``, ``'markdown'``, or ``'json'``).

        Returns:
            The rendered report as a string.
        """
        match format:
            case "json":
                return self._render_json(results)
            case "markdown" | "md":
                return self._render_template(results, "report.md")
            case _:
                return self._render_template(results, "report.html")

    # ------------------------------------------------------------------

    def _render_json(self, results: list[dict[str, Any]]) -> str:
        total = len(results)
        passed = sum(1 for r in results if r.get("status") == "passed")
        failed = total - passed
        total_duration = sum(r.get("duration", 0) for r in results)

        report = {
            "summary": {
                "total": total,
                "passed": passed,
                "failed": failed,
                "duration_ms": total_duration,
                "duration": _format_duration(total_duration),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            "tests": [
                {
                    "name": r.get("name", ""),
                    "module": r.get("module", ""),
                    "status": r.get("status", ""),
                    "duration_ms": r.get("duration", 0),
                    "duration": _format_duration(r.get("duration", 0)),
                    "error_message": r.get("error_message"),
                    "logs": r.get("logs", ""),
                }
                for r in results
            ],
        }
        return json.dumps(report, indent=2, default=str)

    def _render_template(
        self,
        results: list[dict[str, Any]],
        template_name: str,
    ) -> str:
        template_path = _TEMPLATES_DIR / template_name
        tpl_text = template_path.read_text(encoding="utf-8")

        total = len(results)
        passed = sum(1 for r in results if r.get("status") == "passed")
        failed = total - passed
        total_duration = sum(r.get("duration", 0) for r in results)

        # Build per-test rows
        is_html = template_name.endswith(".html")
        test_rows = self._build_rows(results, html=is_html)
        error_details = self._build_errors(results, html=is_html)

        tpl = Template(tpl_text)
        return tpl.safe_substitute(
            timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            total=str(total),
            passed=str(passed),
            failed=str(failed),
            duration=_format_duration(total_duration),
            test_rows=test_rows,
            error_details=error_details,
            version=__version__,
        )

    # ------------------------------------------------------------------

    @staticmethod
    def _build_rows(results: list[dict[str, Any]], *, html: bool) -> str:
        lines: list[str] = []
        for r in results:
            name = r.get("name", "")
            module = r.get("module", "")
            status = r.get("status", "")
            duration = _format_duration(r.get("duration", 0))

            if html:
                badge = f'<span class="badge {status}">{status}</span>'
                lines.append(
                    f"      <tr><td>{name}</td><td>{module}</td>"
                    f"<td>{badge}</td><td>{duration}</td></tr>"
                )
            else:
                icon = "PASS" if status == "passed" else "FAIL"
                lines.append(f"| {name} | {module} | {icon} | {duration} |")

        return "\n".join(lines)

    @staticmethod
    def _build_errors(results: list[dict[str, Any]], *, html: bool) -> str:
        failed = [r for r in results if r.get("status") != "passed"]
        if not failed:
            return ""

        lines: list[str] = []
        if html:
            for r in failed:
                name = r.get("name", "")
                error = r.get("error_message", "")
                logs = r.get("logs", "")
                lines.append('  <div class="error-detail">')
                lines.append(f"    <h3>{name}</h3>")
                if error:
                    lines.append(f"    <pre>{error}</pre>")
                if logs:
                    lines.append("    <details><summary>Show logs</summary>")
                    lines.append(f"      <pre>{logs}</pre>")
                    lines.append("    </details>")
                lines.append("  </div>")
        else:
            lines.append("## Failed Test Details\n")
            for r in failed:
                name = r.get("name", "")
                error = r.get("error_message", "")
                logs = r.get("logs", "")
                lines.append(f"### {name}\n")
                if error:
                    lines.append(f"**Error:** {error}\n")
                if logs:
                    lines.append("<details><summary>Logs</summary>\n")
                    lines.append(f"```\n{logs}\n```\n")
                    lines.append("</details>\n")

        return "\n".join(lines)
