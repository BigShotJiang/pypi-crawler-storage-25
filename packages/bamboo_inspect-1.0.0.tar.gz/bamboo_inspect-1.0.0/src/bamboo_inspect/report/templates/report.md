# Bamboo Inspect Report

**Generated:** $timestamp

## Summary

| Metric | Value |
|--------|-------|
| Total Tests | $total |
| Passed | $passed |
| Failed | $failed |
| Duration | $duration |

## Test Results

| Test | Module | Status | Duration |
|------|--------|--------|----------|
$test_rows

$error_details

---
*Bamboo Inspect v$version*
