"""Configuration management for Bamboo Inspect Agent.

Loads configuration from ~/.bambooinspect/config.yaml for stateless CLI mode.
Agent-specific settings are loaded from ~/.bambooinspect/agent.yaml
(handled by bamboo_inspect.agent.state).
"""

from dataclasses import dataclass, field
from pathlib import Path

import yaml

CONFIG_DIR = Path.home() / ".bambooinspect"
CONFIG_FILE = CONFIG_DIR / "config.yaml"


@dataclass
class TrackingConfig:
    """Process tracking defaults."""

    level: str = "none"  # none / session / full


@dataclass
class DataCollectionConfig:
    """Data collection and retention settings."""

    level: str = "basic"  # basic / detailed / rich
    retention_days: int = 30


@dataclass
class Config:
    """Root configuration for stateless CLI mode."""

    tracking: TrackingConfig = field(default_factory=TrackingConfig)
    data_collection: DataCollectionConfig = field(default_factory=DataCollectionConfig)


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep-merge *override* into *base*, returning a new dict."""
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config() -> Config:
    """Load configuration from ``~/.bambooinspect/config.yaml``.

    If the file does not exist the hardcoded defaults are returned.
    If the YAML is invalid a :class:`SystemExit` is raised.
    """
    if not CONFIG_FILE.exists():
        return Config()

    try:
        raw = CONFIG_FILE.read_text(encoding="utf-8")
        user_data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise SystemExit(
            f"Error: invalid YAML in config file {CONFIG_FILE}\n{exc}"
        ) from exc

    if not isinstance(user_data, dict):
        return Config()

    tracking = user_data.get("tracking", {})
    data_collection = user_data.get("data_collection", {})

    return Config(
        tracking=TrackingConfig(
            level=tracking.get("level", "none"),
        ),
        data_collection=DataCollectionConfig(
            level=data_collection.get("level", "basic"),
            retention_days=data_collection.get("retention_days", 30),
        ),
    )
