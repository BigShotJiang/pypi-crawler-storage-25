"""Bamboo Inspect Agent - Execute and manage Playwright and AI-driven tests.

The Test Agent connects to a Bamboo Inspect Core Manager to receive
and execute test tasks. It can also run tests locally in stateless
CLI mode without a Core Manager.

PyPI package name: bamboo-inspect
CLI command: bambooinspect
"""

__version__ = "1.0.0"
