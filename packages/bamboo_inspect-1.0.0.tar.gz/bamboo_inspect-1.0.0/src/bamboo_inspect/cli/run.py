"""Stateless test execution commands: run, run-module, run-all."""

import asyncio
from typing import Optional

import typer

from bamboo_inspect.cli import app
from bamboo_inspect.cli._helpers import (
    execute_tests,
    get_repo_root,
    post_results_to_server,
    validate_agent_config,
)


@app.command()
def run(
    test: str = typer.Argument(..., help="Name of the test to run."),
    type: str = typer.Option(..., "--type", help="Test type: 'script' or 'prompt'."),
    tracking: Optional[str] = typer.Option(None, "--tracking", help="Tracking level: none/session/full."),
    report: Optional[str] = typer.Option(None, "--report", help="Report type: 'ai' for AI-powered report."),
    report_output: Optional[str] = typer.Option(None, "--report-output", help="Save report to file path."),
    post_task: bool = typer.Option(False, "--post-task", help="Post results to Core Manager after execution."),
) -> None:
    """Run a specific test by name."""
    from bamboo_inspect.scanner import scan_repository

    # Validate agent config upfront when --post-task is set
    agent_state = validate_agent_config() if post_task else None

    repo_root = get_repo_root()
    scan = scan_repository(repo_root)
    matching = [t for t in scan["tests"] if t["name"] == test and t["type"] == type]

    if not matching:
        typer.echo(f"Error: test '{test}' of type '{type}' not found.", err=True)
        raise typer.Exit(code=1)

    all_passed, results = asyncio.run(execute_tests(matching, type, report, report_output))

    if post_task and agent_state is not None:
        asyncio.run(post_results_to_server(agent_state, results, type, tracking, repo_root))

    raise typer.Exit(code=0 if all_passed else 1)


@app.command("run-module")
def run_module(
    module: str = typer.Argument(..., help="Name of the module to run."),
    type: str = typer.Option(..., "--type", help="Test type: 'script' or 'prompt'."),
    tracking: Optional[str] = typer.Option(None, "--tracking", help="Tracking level: none/session/full."),
    report: Optional[str] = typer.Option(None, "--report", help="Report type: 'ai' for AI-powered report."),
    report_output: Optional[str] = typer.Option(None, "--report-output", help="Save report to file path."),
    post_task: bool = typer.Option(False, "--post-task", help="Post results to Core Manager after execution."),
) -> None:
    """Run all tests in a specific module."""
    from bamboo_inspect.scanner import scan_repository

    agent_state = validate_agent_config() if post_task else None

    repo_root = get_repo_root()
    scan = scan_repository(repo_root)
    matching = [t for t in scan["tests"] if t["module"] == module and t["type"] == type]

    if not matching:
        typer.echo(f"Error: module '{module}' not found or has no '{type}' tests.", err=True)
        raise typer.Exit(code=1)

    all_passed, results = asyncio.run(execute_tests(matching, type, report, report_output))

    if post_task and agent_state is not None:
        asyncio.run(post_results_to_server(agent_state, results, type, tracking, repo_root))

    raise typer.Exit(code=0 if all_passed else 1)


@app.command("run-all")
def run_all(
    type: str = typer.Option(..., "--type", help="Test type: 'script' or 'prompt'."),
    tracking: Optional[str] = typer.Option(None, "--tracking", help="Tracking level: none/session/full."),
    report: Optional[str] = typer.Option(None, "--report", help="Report type: 'ai' for AI-powered report."),
    report_output: Optional[str] = typer.Option(None, "--report-output", help="Save report to file path."),
    post_task: bool = typer.Option(False, "--post-task", help="Post results to Core Manager after execution."),
) -> None:
    """Run all tests of a given type in the current repository."""
    from bamboo_inspect.scanner import scan_repository

    agent_state = validate_agent_config() if post_task else None

    repo_root = get_repo_root()
    scan = scan_repository(repo_root)
    matching = [t for t in scan["tests"] if t["type"] == type]

    if not matching:
        typer.echo(f"No '{type}' tests found in {repo_root}", err=True)
        raise typer.Exit(code=1)

    all_passed, results = asyncio.run(execute_tests(matching, type, report, report_output))

    if post_task and agent_state is not None:
        asyncio.run(post_results_to_server(agent_state, results, type, tracking, repo_root))

    raise typer.Exit(code=0 if all_passed else 1)
