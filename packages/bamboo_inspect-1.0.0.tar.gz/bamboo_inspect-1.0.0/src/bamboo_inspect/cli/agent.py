"""Agent management commands: register, start, stop, status, unregister, sync-repo."""

import asyncio
from pathlib import Path

import typer

from bamboo_inspect.cli import agent_app


@agent_app.command()
def register(
    url: str = typer.Option(..., "--url", help="Core Manager URL (e.g., http://core:8686)."),
    token: str = typer.Option(..., "--token", help="Registration token from Core Manager."),
    name: str = typer.Option(..., "--name", help="Agent display name."),
    labels: str = typer.Option("", "--labels", help="Comma-separated labels (e.g., linux,playwright)."),
    port: int = typer.Option(8787, "--port", help="Agent web UI port."),
) -> None:
    """Register this agent with a Core Manager."""
    from bamboo_inspect.agent.registration import register_agent

    label_list = (
        [label.strip() for label in labels.split(",") if label.strip()]
        if labels
        else []
    )

    try:
        result = asyncio.run(register_agent(
            core_url=url,
            registration_token=token,
            name=name,
            labels=label_list,
            port=port,
        ))
        typer.echo("Agent registered successfully!")
        typer.echo(f"  Name:  {result['name']}")
        typer.echo(f"  ID:    {result['agent_id']}")
        typer.echo("\nStart the agent with: bambooinspect agent start")
    except RuntimeError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(code=1)


@agent_app.command()
def start(
    port: int = typer.Option(None, "--port", help="Agent web UI port (overrides config)."),
) -> None:
    """Start the agent (poller + web UI)."""
    from bamboo_inspect.agent.state import load_agent_state

    state = load_agent_state()
    if not state:
        typer.echo("Error: Agent is not registered.", err=True)
        typer.echo("Run: bambooinspect agent register --url <core-url> --token <token> --name <name>", err=True)
        raise typer.Exit(code=1)

    if port:
        state.port = port

    typer.echo(f"Starting agent '{state.agent_name}'...")
    typer.echo(f"  Core Manager: {state.core_url}")
    typer.echo(f"  Web UI: http://{state.host}:{state.port}")
    typer.echo(f"  Poll interval: {state.poll_interval}s")
    typer.echo("")

    asyncio.run(_start_agent(state))


async def _start_agent(state) -> None:
    """Start both the polling loop and the web server."""
    import uvicorn

    from bamboo_inspect.agent.poller import start_polling
    from bamboo_inspect.web.app import create_agent_app

    agent_web_app = create_agent_app()

    config = uvicorn.Config(
        agent_web_app,
        host=state.host,
        port=state.port,
        log_level="info",
    )
    server = uvicorn.Server(config)

    # Run poller and web server concurrently
    poller_task = asyncio.create_task(start_polling(state))

    try:
        await server.serve()
    finally:
        poller_task.cancel()
        try:
            await poller_task
        except asyncio.CancelledError:
            pass


@agent_app.command("sync-repo")
def sync_repo(
    path: str = typer.Argument(
        ".", help="Path to the git repository to scan and sync (default: current directory)."
    ),
) -> None:
    """Scan a local git repo and push its test structure to the Core Manager."""
    from bamboo_inspect.agent.state import load_agent_state
    from bamboo_inspect.git.manager import GitManager
    from bamboo_inspect.scanner import scan_repository

    state = load_agent_state()
    if not state:
        typer.echo("Error: Agent is not registered.", err=True)
        raise typer.Exit(code=1)

    repo_path = Path(path).resolve()
    gm = GitManager()

    if not gm.validate_repo(repo_path):
        typer.echo(f"Error: '{repo_path}' is not a valid git repository.", err=True)
        raise typer.Exit(code=1)

    repo_root = gm.get_repo_root(repo_path)
    remote_url = gm.get_remote_url(repo_root)

    typer.echo(f"Scanning: {repo_root}")
    scan = scan_repository(repo_root)

    if not scan["tests"]:
        typer.echo("No tests found in this repository.", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"  Found {len(scan['tests'])} tests in {len(scan['modules'])} modules")

    # Push to Core Manager
    sync_data = {
        "project_name": repo_root.name,
        "project_path": str(repo_root),
        "git_remote_url": remote_url,
        "modules": scan["modules"],
        "tests": scan["tests"],
    }

    async def _sync():
        from bamboo_inspect.agent.client import CoreManagerClient
        client = CoreManagerClient(state.core_url, state.agent_token)
        try:
            result = await client.sync_repo(sync_data)
            return result
        finally:
            await client.close()

    result = asyncio.run(_sync())
    if result:
        typer.echo(f"Synced to Core Manager: {result['modules']} modules, {result['tests']} tests")
    else:
        typer.echo("Error: Failed to sync with Core Manager.", err=True)
        raise typer.Exit(code=1)


@agent_app.command()
def stop() -> None:
    """Stop the running agent."""
    # The agent runs in the foreground, so Ctrl+C or SIGTERM stops it.
    # This command is a placeholder for process management.
    typer.echo("To stop the agent, press Ctrl+C in the terminal where it's running.")
    typer.echo("Or send SIGTERM to the agent process.")


@agent_app.command()
def status() -> None:
    """Check agent registration and connection status."""
    from bamboo_inspect.agent.state import load_agent_state

    state = load_agent_state()
    if not state:
        typer.echo("Agent is not registered.")
        typer.echo("Run: bambooinspect agent register --url <core-url> --token <token> --name <name>")
        return

    typer.echo(f"Agent: {state.agent_name}")
    typer.echo(f"  ID:          {state.agent_id}")
    typer.echo(f"  Core URL:    {state.core_url}")
    typer.echo(f"  Labels:      {', '.join(state.labels) if state.labels else '-'}")
    typer.echo(f"  Web UI port: {state.port}")
    typer.echo(f"  Poll interval: {state.poll_interval}s")

    # Quick connectivity check
    from bamboo_inspect.agent.client import CoreManagerClient

    async def _check():
        client = CoreManagerClient(state.core_url)
        connected = await client.health_check()
        await client.close()
        return connected

    connected = asyncio.run(_check())
    status_str = "Connected" if connected else "Disconnected"
    typer.echo(f"  Core Manager: {status_str}")


@agent_app.command()
def unregister() -> None:
    """Unregister this agent from the Core Manager."""
    from bamboo_inspect.agent.registration import unregister_agent

    try:
        success = asyncio.run(unregister_agent())
        if success:
            typer.echo("Agent unregistered successfully.")
        else:
            typer.echo("Agent unregistered (local credentials removed).")
    except Exception as exc:
        typer.echo(f"Warning: {exc}", err=True)
        typer.echo("Local credentials removed anyway.")
        from bamboo_inspect.agent.state import delete_agent_state
        delete_agent_state()
