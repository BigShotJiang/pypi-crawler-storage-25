"""Shared helper functions for CLI commands.

These helpers MUST NOT import ``app`` or ``agent_app`` from
``bamboo_inspect.cli`` to avoid circular imports.
"""

from pathlib import Path
from typing import Optional, Tuple

import typer


def get_repo_root() -> Path:
    """Resolve the current working directory to a git repo root."""
    from bamboo_inspect.git.manager import GitManager

    gm = GitManager()
    cwd = Path.cwd()
    if not gm.validate_repo(cwd):
        typer.echo("Error: current directory is not a git repository.", err=True)
        raise typer.Exit(code=1)
    return gm.get_repo_root(cwd)


def get_executor(test_type: str):
    """Return the appropriate executor instance for *test_type*."""
    if test_type == "script":
        from bamboo_inspect.executors.playwright import PlaywrightExecutor
        return PlaywrightExecutor()
    elif test_type == "prompt":
        from bamboo_inspect.executors.claude_code import ClaudeCodeExecutor
        return ClaudeCodeExecutor()
    else:
        typer.echo(f"Error: unknown test type '{test_type}'. Use 'script' or 'prompt'.", err=True)
        raise typer.Exit(code=1)


async def execute_tests(
    tests: list[dict],
    test_type: str,
    report_format: Optional[str],
    report_output: Optional[str],
) -> Tuple[bool, list[dict]]:
    """Execute a list of tests and produce a report.

    Returns a tuple of (all_passed, results) where *all_passed* is
    ``True`` when every test passed and *results* is the list of
    per-test result dicts (each containing name, module, status,
    duration, etc.).
    """
    from bamboo_inspect.report.renderer import ReportRenderer

    executor = get_executor(test_type)
    results: list[dict] = []

    for test in tests:
        test_path = Path(test["absolute_path"])
        typer.echo(f"Running: {test['module']}/{test['name']} ...", err=True)

        if test_type == "script":
            result = await executor.execute(
                test_path,
                timeout=test.get("timeout"),
                retry_count=test.get("retry_count", 0),
            )
        else:
            result = await executor.execute(
                test_path,
                timeout=test.get("timeout"),
            )

        result["name"] = test["name"]
        result["module"] = test["module"]
        results.append(result)

        status_icon = "PASS" if result["status"] == "passed" else "FAIL"
        typer.echo(f"  [{status_icon}] {result['name']} ({result.get('duration', 0)}ms)", err=True)

    # Render report
    renderer = ReportRenderer()

    if report_format == "ai":
        try:
            import shutil

            from bamboo_inspect.executors.claude_code import ClaudeCodeExecutor
            if shutil.which("claude"):
                json_data = renderer.render(results, format="json")
                ai_exec = ClaudeCodeExecutor()
                import tempfile
                with tempfile.NamedTemporaryFile(mode="w", suffix=".prompt", delete=False) as f:
                    f.write(f"Summarise these test results in a clear report:\n\n{json_data}")
                    tmp_path = Path(f.name)
                try:
                    ai_result = await ai_exec.execute(tmp_path)
                    report_text = ai_result.get("response", "")
                finally:
                    tmp_path.unlink(missing_ok=True)
            else:
                typer.echo("Warning: claude CLI not found, falling back to template report.", err=True)
                report_text = renderer.render(results, format="html")
        except Exception:
            typer.echo("Warning: AI report failed, falling back to template report.", err=True)
            report_text = renderer.render(results, format="html")
    else:
        fmt = "html"
        if report_output:
            if report_output.endswith(".md"):
                fmt = "markdown"
            elif report_output.endswith(".json"):
                fmt = "json"
        report_text = renderer.render(results, format=fmt)

    if report_output:
        Path(report_output).write_text(report_text, encoding="utf-8")
        typer.echo(f"\nReport saved to {report_output}", err=True)
    else:
        typer.echo(report_text)

    passed = sum(1 for r in results if r["status"] == "passed")
    failed = len(results) - passed
    typer.echo(f"\nResults: {passed} passed, {failed} failed, {len(results)} total", err=True)

    return failed == 0, results


# ---------------------------------------------------------------------------
# Post-task helpers
# ---------------------------------------------------------------------------


def validate_agent_config():
    """Load and validate the agent configuration from ~/.bambooinspect/agent.yaml.

    Returns the :class:`AgentState` on success.  Prints an error and
    raises :exc:`typer.Exit` if the config is missing or incomplete.
    """
    from bamboo_inspect.agent.state import AGENT_CONFIG_FILE, load_agent_state

    state = load_agent_state()
    if state is None:
        typer.echo(
            f"Error: Agent not registered. "
            f"Run 'bambooinspect agent register' first or create {AGENT_CONFIG_FILE} manually.",
            err=True,
        )
        raise typer.Exit(code=1)

    missing: list[str] = []
    if not state.core_url:
        missing.append("core_url")
    if not state.agent_token:
        missing.append("agent_token")
    if not state.agent_id:
        missing.append("agent_id")

    if missing:
        typer.echo(
            f"Error: Agent config is incomplete — missing: {', '.join(missing)}. "
            f"Check {AGENT_CONFIG_FILE}.",
            err=True,
        )
        raise typer.Exit(code=1)

    return state


async def post_results_to_server(
    state,
    results: list[dict],
    test_type: str,
    tracking: Optional[str],
    repo_root: Path,
) -> None:
    """POST completed test results to the Core Manager.

    Uses the agent config (*state*) for the server URL and auth token.
    Handles connection errors and HTTP errors gracefully — prints
    warnings but never raises, so the CLI exit code always reflects
    the test outcome, not the server response.
    """
    import aiohttp

    core_url = state.core_url.rstrip("/")
    url = f"{core_url}/api/agent/report-run"

    # Build per-test result entries
    payload_results = []
    for r in results:
        payload_results.append({
            "test_name": r.get("name", ""),
            "test_type": test_type,
            "module": r.get("module", ""),
            "status": r.get("status", "failed"),
            "duration": r.get("duration"),
            "logs": r.get("logs", ""),
            "error_message": r.get("error_message"),
        })

    payload = {
        "project_name": repo_root.name,
        "project_path": str(repo_root),
        "tracking": tracking or "session",
        "triggered_by": "cli",
        "results": payload_results,
    }

    headers = {"Authorization": f"Bearer {state.agent_token}"}

    try:
        async with aiohttp.ClientSession() as session:
            timeout = aiohttp.ClientTimeout(total=30)
            async with session.post(
                url,
                json=payload,
                headers=headers,
                timeout=timeout,
            ) as resp:
                if resp.status < 300:
                    data = await resp.json()
                    session_id = data.get("session_id", "?")
                    typer.echo(
                        f"\nResults posted to Core Manager — session: {session_id}",
                        err=True,
                    )
                else:
                    detail = ""
                    try:
                        body = await resp.json()
                        detail = body.get("detail", "")
                    except Exception:
                        detail = await resp.text()
                    typer.echo(
                        f"\nWarning: Core Manager returned {resp.status}: {detail}",
                        err=True,
                    )
    except (aiohttp.ClientError, OSError, TimeoutError) as exc:
        typer.echo(
            f"\nWarning: could not reach Core Manager at {core_url}. "
            f"Results not submitted. ({exc})",
            err=True,
        )
