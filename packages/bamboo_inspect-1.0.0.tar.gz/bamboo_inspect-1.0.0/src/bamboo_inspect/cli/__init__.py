"""Typer-based CLI for Bamboo Inspect Agent.

Provides commands for:
- Stateless test execution (run, run-module, run-all) — no daemon required
- Agent management (agent register/start/stop/status/unregister)
- Project initialisation (init)

All commands are prefixed with `bambooinspect`.
"""

from typing import Optional

import typer

from bamboo_inspect import __version__

app = typer.Typer(
    name="bambooinspect",
    help="Bamboo Inspect - Easy test management for Playwright and AI-driven tests.",
    add_completion=False,
)

# Agent subcommand group
agent_app = typer.Typer(
    name="agent",
    help="Test Agent management commands.",
)
app.add_typer(agent_app, name="agent")


def _version_callback(value: bool) -> None:
    if value:
        print(f"bambooinspect {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show the version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Bamboo Inspect - Easy test management for Playwright and AI-driven tests."""


# Import command modules to trigger registration.
# These modules import `app` / `agent_app` and decorate their functions.
from bamboo_inspect.cli import agent as _agent_commands  # noqa: F401, E402
from bamboo_inspect.cli import init as _init_commands  # noqa: F401, E402
from bamboo_inspect.cli import run as _run_commands  # noqa: F401, E402
