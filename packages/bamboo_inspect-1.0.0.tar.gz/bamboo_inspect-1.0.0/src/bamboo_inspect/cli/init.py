"""Project initialisation command: bambooinspect init."""

from pathlib import Path

import typer

from bamboo_inspect.cli import app
from bamboo_inspect.cli._helpers import get_repo_root

# ---------------------------------------------------------------------------
# Template content for generated files
# ---------------------------------------------------------------------------

_SKILL_MD = """\
# Bamboo Inspect — AI Skill

> This file teaches AI agents (e.g. Claude) how to use **bambooinspect**,
> the CLI tool for managing Playwright and AI-driven tests.

## What is Bamboo Inspect?

Bamboo Inspect is a test management tool that organises, discovers, and executes
two kinds of tests inside any git repository:

- **Script tests** — Playwright-based test files written in Python, JavaScript,
  or TypeScript.
- **Prompt tests** — AI prompt files (`.prompt`) executed via Claude Code.

All tests live under a `tests/` directory at the repository root.

## CLI Commands

| Command | Description |
|---|---|
| `bambooinspect init` | Scaffold the `tests/` directory structure in a git repo. |
| `bambooinspect run <name> --type <script\\|prompt>` | Run a single test by name. |
| `bambooinspect run-module <module> --type <script\\|prompt>` | Run all tests in a module. |
| `bambooinspect run-all --type <script\\|prompt>` | Run every test of a given type. |

### Common Options

- `--tracking none|session|full` — Override the tracking level.
- `--report ai` — Generate an AI-powered summary report.
- `--report-output <path>` — Save the report to a file.

## Directory Structure

```
tests/
  scripts/
    <module>/           # e.g. auth, checkout, settings
      <test_file>.py    # Python Playwright test
      <test_file>.js    # JavaScript Playwright test
      <test_file>.ts    # TypeScript Playwright test
  prompts/
    <module>/
      <test_file>.prompt  # AI prompt test
  bamboo-inspect-skill/
    SKILL.md            # This file
  bambooinspect-rules.md   # Conventions & structure rules
```

## Creating a Script Test

Create a file under `tests/scripts/<module>/` with one of the supported
extensions (`.py`, `.js`, `.ts`). Add metadata comments at the top:

```python
# @description: Verify user can log in with valid credentials
# @tags: auth, smoke
# @timeout: 30000
# @retry: 1

from playwright.sync_api import sync_playwright

def test_login():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto("https://example.com/login")
        page.fill("#email", "user@example.com")
        page.fill("#password", "password123")
        page.click("button[type=submit]")
        assert page.url == "https://example.com/dashboard"
        browser.close()
```

## Creating a Prompt Test

Create a `.prompt` file under `tests/prompts/<module>/`:

```
Verify that the login page at https://example.com/login:
1. Displays email and password fields.
2. Shows an error message for invalid credentials.
3. Redirects to /dashboard on successful login.
```

Prompt tests are executed by Claude Code and return an AI-generated response.

## Metadata Annotations

Add these comment lines at the top of script test files (first 30 lines):

| Key | Format | Description |
|---|---|---|
| `@description` | `# @description: <text>` | Human-readable test description. |
| `@tags` | `# @tags: tag1, tag2` | Comma-separated tags for filtering. |
| `@timeout` | `# @timeout: <ms>` | Max execution time in milliseconds. |
| `@retry` | `# @retry: <count>` | Number of retry attempts on failure. |

For JavaScript/TypeScript files, use `//` instead of `#`.
"""

_DEMO_SCRIPT = """\
# @description: Demo test — display basic system information
# @tags: demo, smoke
# @timeout: 10000
# @retry: 0

import platform
import sys
import os


def main():
    info = {
        "python_version": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or "N/A",
        "hostname": platform.node(),
        "cwd": os.getcwd(),
        "user": os.environ.get("USER") or os.environ.get("USERNAME", "N/A"),
    }

    print("=== System Information ===")
    for key, value in info.items():
        print(f"  {key}: {value}")
    print("==========================")
    print("PASSED")


if __name__ == "__main__":
    main()
"""

_DEMO_PROMPT = """\
Verify that you can access the current working directory and report:
1. The operating system name.
2. The Python version installed.
3. Whether a tests/ directory exists at the project root.
Summarise the findings in a short paragraph.
"""

_RULES_MD = """\
# Bamboo Inspect — Rules & Conventions

This document defines the mandatory directory structure, file naming conventions,
and metadata format for tests managed by **bambooinspect**.

## Directory Structure

All tests MUST be placed under the `tests/` directory at the git repository root.

```
<repo-root>/
  tests/
    scripts/
      <module>/
        <test_name>.py
        <test_name>.js
        <test_name>.ts
    prompts/
      <module>/
        <test_name>.prompt
    bamboo-inspect-skill/
      SKILL.md
    bambooinspect-rules.md
```

## Modules

A **module** is a subdirectory under `tests/scripts/` or `tests/prompts/`.
Modules group related tests together (e.g. `auth`, `checkout`, `settings`).

- Module names MUST be lowercase.
- Module names MUST use hyphens or underscores (no spaces).
- Each module directory contains one or more test files.

## Script Tests

Script tests are Playwright-based test files.

### Supported Extensions

| Extension | Language |
|---|---|
| `.py` | Python |
| `.js` | JavaScript |
| `.ts` | TypeScript |

### Location

Script tests MUST be placed in `tests/scripts/<module>/`.

### Naming

- File names SHOULD be descriptive of what the test verifies.
- File names MUST use underscores or hyphens (no spaces).
- Examples: `login_test.py`, `add-to-cart.js`, `checkout_flow.ts`

### Metadata Comments

Metadata comments MUST appear in the first 30 lines of the file.

**Python format:**

```python
# @description: Verify user can log in with valid credentials
# @tags: auth, smoke
# @timeout: 30000
# @retry: 1
```

**JavaScript / TypeScript format:**

```javascript
// @description: Verify user can log in with valid credentials
// @tags: auth, smoke
// @timeout: 30000
// @retry: 1
```

### Supported Metadata Keys

| Key | Type | Description |
|---|---|---|
| `@description` | string | Human-readable description of what the test verifies. |
| `@tags` | comma-separated strings | Tags for categorisation and filtering. |
| `@timeout` | integer (milliseconds) | Maximum execution time. Overrides default. |
| `@retry` | integer | Number of retry attempts if the test fails. Default: 0. |

## Prompt Tests

Prompt tests are plain-text instruction files executed by an AI agent (Claude Code).

### Extension

Prompt tests MUST use the `.prompt` extension.

### Location

Prompt tests MUST be placed in `tests/prompts/<module>/`.

### Format

A `.prompt` file contains free-form natural language instructions describing
what the AI agent should verify or perform. No metadata comments are needed.

### Example

```
Verify that the registration page at https://example.com/register:
1. Contains fields for name, email, and password.
2. Shows validation errors when the form is submitted empty.
3. Successfully creates an account with valid data.
4. Redirects to the welcome page after registration.
```

## Example: Complete Test Structure

```
tests/
  scripts/
    auth/
      login_test.py
      logout_test.py
      password_reset.ts
    checkout/
      add_to_cart.js
      payment_flow.py
  prompts/
    auth/
      test_login_flow.prompt
      test_registration.prompt
    checkout/
      test_purchase_flow.prompt
  bamboo-inspect-skill/
    SKILL.md
  bambooinspect-rules.md
```
"""


# ---------------------------------------------------------------------------
# Agent config template (shown when ~/.bambooinspect/agent.yaml is missing)
# ---------------------------------------------------------------------------

_AGENT_YAML_TEMPLATE = """\
# Bamboo Inspect Agent Configuration
# Location: ~/.bambooinspect/agent.yaml
#
# This file is created automatically when you register an agent:
#   bambooinspect agent register --url <core-url> --token <token> --name <name>
#
# You can also create it manually with the following template:

core_url: http://localhost:8686        # Core Manager server URL
agent_token: ""                        # Persistent token (from registration)
agent_id: ""                           # Agent UUID (from registration)
agent_name: my-agent                   # Display name for this agent
labels:                                # Labels for task matching
  - linux
  - playwright
port: 8787                             # Agent web UI port
host: 127.0.0.1                        # Agent web UI bind address
poll_interval: 30                      # Seconds between task polls
"""


# ---------------------------------------------------------------------------
# Init command
# ---------------------------------------------------------------------------


def _show_agent_config_status() -> None:
    """Check for ~/.bambooinspect/agent.yaml and display its info or a notice."""
    from bamboo_inspect.agent.state import AGENT_CONFIG_FILE, load_agent_state

    typer.echo("\n--- Agent Configuration ---")

    state = load_agent_state()
    if state is not None:
        typer.echo(f"  Config file : {AGENT_CONFIG_FILE}")
        typer.echo(f"  Agent name  : {state.agent_name or '(not set)'}")
        typer.echo(f"  Agent ID    : {state.agent_id or '(not set)'}")
        typer.echo(f"  Core URL    : {state.core_url or '(not set)'}")
        typer.echo(f"  Labels      : {', '.join(state.labels) if state.labels else '(none)'}")
        typer.echo(f"  Web UI      : http://{state.host}:{state.port}")
        typer.echo(f"  Poll interval: {state.poll_interval}s")
    else:
        typer.echo(f"  Agent config not found: {AGENT_CONFIG_FILE}")
        typer.echo("")
        typer.echo("  To connect this machine to a Core Manager, register an agent:")
        typer.echo("")
        typer.echo("    bambooinspect agent register \\")
        typer.echo("      --url http://<core-manager>:8686 \\")
        typer.echo("      --token <registration-token> \\")
        typer.echo("      --name <agent-name>")
        typer.echo("")
        typer.echo(f"  Or create {AGENT_CONFIG_FILE} manually with this template:")
        typer.echo("")
        for line in _AGENT_YAML_TEMPLATE.splitlines():
            typer.echo(f"    {line}")
        typer.echo("")


def _create_dir(dir_path: Path, label: str) -> bool:
    """Create a directory if it doesn't exist. Returns True if created."""
    if dir_path.exists():
        typer.echo(f"  [skip] {label} (already exists)")
        return False
    dir_path.mkdir(parents=True, exist_ok=True)
    typer.echo(f"  [created] {label}")
    return True


def _create_file(file_path: Path, content: str, label: str) -> bool:
    """Create a file if it doesn't exist. Returns True if created."""
    if file_path.exists():
        typer.echo(f"  [skip] {label} (already exists)")
        return False
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content, encoding="utf-8")
    typer.echo(f"  [created] {label}")
    return True


@app.command()
def init() -> None:
    """Scaffold the standard Bamboo Inspect directory structure in a git repository."""
    repo_root = get_repo_root()
    tests_dir = repo_root / "tests"

    typer.echo(f"Initialising Bamboo Inspect in: {repo_root}\n")

    created_count = 0

    # Directories with .gitkeep
    scripts_dir = tests_dir / "scripts"
    prompts_dir = tests_dir / "prompts"
    skill_dir = tests_dir / "bamboo-inspect-skill"

    if _create_dir(scripts_dir, "tests/scripts/"):
        created_count += 1
        _create_file(scripts_dir / ".gitkeep", "", "tests/scripts/.gitkeep")

    # Demo script module with a sample test
    demo_scripts_dir = scripts_dir / "demo"
    if _create_dir(demo_scripts_dir, "tests/scripts/demo/"):
        created_count += 1
    if _create_file(demo_scripts_dir / "system_info_test.py", _DEMO_SCRIPT, "tests/scripts/demo/system_info_test.py"):
        created_count += 1

    if _create_dir(prompts_dir, "tests/prompts/"):
        created_count += 1
        _create_file(prompts_dir / ".gitkeep", "", "tests/prompts/.gitkeep")

    # Demo prompt module with a sample prompt
    demo_prompts_dir = prompts_dir / "demo"
    if _create_dir(demo_prompts_dir, "tests/prompts/demo/"):
        created_count += 1
    if _create_file(
        demo_prompts_dir / "check_environment.prompt",
        _DEMO_PROMPT,
        "tests/prompts/demo/check_environment.prompt",
    ):
        created_count += 1

    if _create_dir(skill_dir, "tests/bamboo-inspect-skill/"):
        created_count += 1

    # Files
    if _create_file(skill_dir / "SKILL.md", _SKILL_MD, "tests/bamboo-inspect-skill/SKILL.md"):
        created_count += 1

    if _create_file(tests_dir / "bambooinspect-rules.md", _RULES_MD, "tests/bambooinspect-rules.md"):
        created_count += 1

    # Summary
    typer.echo("")
    if created_count > 0:
        typer.echo(f"Done! Created {created_count} items.")
        typer.echo("\nNext steps:")
        typer.echo("  1. Add test modules:  mkdir tests/scripts/<module>")
        typer.echo("  2. Write tests:       tests/scripts/<module>/my_test.py")
        typer.echo("  3. Run tests:         bambooinspect run my_test --type script")
    else:
        typer.echo("Everything is already set up. Nothing to create.")

    # Agent configuration check
    _show_agent_config_status()
