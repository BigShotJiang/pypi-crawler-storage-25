"""Test Agent FastAPI web application.

Provides a lightweight web dashboard on port 8787 for monitoring
the agent's status, current task, and task history.
"""

from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

_STATIC_DIR = Path(__file__).parent / "static"


def create_agent_app() -> FastAPI:
    """Create and configure the Agent web application.

    Returns:
        A configured FastAPI instance.
    """
    app = FastAPI(
        title="Bamboo Inspect Agent",
        description="Test Agent monitoring dashboard",
        version="0.1.0",
    )

    @app.get("/api/health")
    async def health_check() -> dict[str, Any]:
        from bamboo_inspect.agent.state import load_agent_state
        state = load_agent_state()
        return {
            "status": "ok",
            "component": "test-agent",
            "agent_name": state.agent_name if state else "unknown",
        }

    @app.get("/api/status")
    async def agent_status() -> dict[str, Any]:
        from bamboo_inspect.agent.client import CoreManagerClient
        from bamboo_inspect.agent.poller import current_task
        from bamboo_inspect.agent.state import load_agent_state

        state = load_agent_state()
        if not state:
            return {"registered": False}

        # Check Core Manager connectivity
        client = CoreManagerClient(state.core_url)
        connected = await client.health_check()
        await client.close()

        result: dict[str, Any] = {
            "registered": True,
            "agent_name": state.agent_name,
            "agent_id": state.agent_id,
            "labels": state.labels,
            "core_url": state.core_url,
            "connected": connected,
            "current_task": current_task,
        }
        return result

    @app.get("/api/history")
    async def agent_task_history() -> list[dict[str, Any]]:
        from bamboo_inspect.agent.poller import task_history
        return task_history[:50]

    # Serve static files
    if _STATIC_DIR.is_dir():
        app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")

    return app
