"""Agent web UI sub-package for Bamboo Inspect.

Provides the lightweight FastAPI web server and dashboard
for monitoring the Test Agent on port 8787 (default).
"""
