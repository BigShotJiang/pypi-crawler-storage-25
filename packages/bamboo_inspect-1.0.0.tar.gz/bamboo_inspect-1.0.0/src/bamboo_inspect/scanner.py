"""Test discovery and registry for Bamboo Inspect.

Scans repositories for test files following the standard test structure:
- tests/scripts/{module}/ for Playwright tests (.py, .js, .ts)
- tests/prompts/{module}/ for AI prompt tests (.prompt)

Parses metadata (description, tags, timeout, retry count) from test files.
In stateless CLI mode, scans fresh on every invocation.
In daemon mode, caches structure and updates on filesystem or git changes.
"""

import re
from pathlib import Path
from typing import Any

from bamboo_inspect.utils import generate_module_id, generate_project_id, generate_test_id

# File extensions recognised as script tests
SCRIPT_EXTENSIONS = {".py", ".js", ".ts"}

# File extension for prompt tests
PROMPT_EXTENSION = ".prompt"

# Maximum number of lines to scan for metadata comments
_METADATA_SCAN_LINES = 30

# Regex patterns for metadata comments
_META_PATTERNS = {
    "description": re.compile(r"^#\s*@description:\s*(.+)$", re.IGNORECASE),
    "tags": re.compile(r"^#\s*@tags:\s*(.+)$", re.IGNORECASE),
    "timeout": re.compile(r"^#\s*@timeout:\s*(\d+)\s*$", re.IGNORECASE),
    "retry": re.compile(r"^#\s*@retry:\s*(\d+)\s*$", re.IGNORECASE),
}

# JS/TS use // comments instead of #
_META_PATTERNS_JS = {
    "description": re.compile(r"^//\s*@description:\s*(.+)$", re.IGNORECASE),
    "tags": re.compile(r"^//\s*@tags:\s*(.+)$", re.IGNORECASE),
    "timeout": re.compile(r"^//\s*@timeout:\s*(\d+)\s*$", re.IGNORECASE),
    "retry": re.compile(r"^//\s*@retry:\s*(\d+)\s*$", re.IGNORECASE),
}


def _parse_metadata(file_path: Path) -> dict[str, Any]:
    """Parse metadata comments from the top of a test file.

    Supports ``# @key: value`` for Python and ``// @key: value`` for JS/TS.

    Returns:
        Dict with keys: description, tags, timeout, retry_count.
    """
    metadata: dict[str, Any] = {
        "description": None,
        "tags": [],
        "timeout": None,
        "retry_count": 0,
    }

    suffix = file_path.suffix.lower()
    patterns = _META_PATTERNS_JS if suffix in (".js", ".ts") else _META_PATTERNS

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
            for i, line in enumerate(fh):
                if i >= _METADATA_SCAN_LINES:
                    break
                line = line.strip()

                m = patterns["description"].match(line)
                if m:
                    metadata["description"] = m.group(1).strip()
                    continue

                m = patterns["tags"].match(line)
                if m:
                    raw_tags = m.group(1).strip()
                    metadata["tags"] = [
                        t.strip() for t in raw_tags.split(",") if t.strip()
                    ]
                    continue

                m = patterns["timeout"].match(line)
                if m:
                    metadata["timeout"] = int(m.group(1))
                    continue

                m = patterns["retry"].match(line)
                if m:
                    metadata["retry_count"] = int(m.group(1))
                    continue
    except OSError:
        pass

    return metadata


def _discover_tests(
    base_dir: Path, test_type: str, extensions: set[str],
) -> list[dict[str, Any]]:
    """Walk *base_dir* and discover test files matching *extensions*.

    Each sub-directory under *base_dir* is treated as a module.
    """
    tests: list[dict[str, Any]] = []

    if not base_dir.is_dir():
        return tests

    for module_dir in sorted(base_dir.iterdir()):
        if not module_dir.is_dir() or module_dir.name.startswith("."):
            continue

        for test_file in sorted(module_dir.iterdir()):
            if not test_file.is_file():
                continue
            if test_file.suffix.lower() not in extensions:
                continue

            meta = _parse_metadata(test_file) if test_type == "script" else {
                "description": None,
                "tags": [],
                "timeout": None,
                "retry_count": 0,
            }

            tests.append({
                "name": test_file.stem,
                "type": test_type,
                "module": module_dir.name,
                "path": str(test_file.relative_to(base_dir.parent.parent)),
                "absolute_path": str(test_file),
                **meta,
            })

    return tests


def scan_repository(repo_path: Path) -> dict[str, Any]:
    """Scan a repository for test files.

    Args:
        repo_path: Path to the git repository root.

    Returns:
        Dictionary with discovered modules and tests, keyed with
        deterministic hash IDs.
    """
    repo_path = Path(repo_path).resolve()
    project_id = generate_project_id(repo_path)

    tests_dir = repo_path / "tests"
    scripts_dir = tests_dir / "scripts"
    prompts_dir = tests_dir / "prompts"

    if not tests_dir.is_dir():
        return {
            "project_id": project_id,
            "project_path": str(repo_path),
            "modules": [],
            "tests": [],
            "message": "No tests/ directory found",
        }

    # Discover script tests and prompt tests
    script_tests = _discover_tests(scripts_dir, "script", SCRIPT_EXTENSIONS)
    prompt_tests = _discover_tests(prompts_dir, "prompt", {PROMPT_EXTENSION})
    all_tests = script_tests + prompt_tests

    # Organise by module and assign IDs
    modules_map: dict[str, dict[str, Any]] = {}
    enriched_tests: list[dict[str, Any]] = []

    for test in all_tests:
        module_name = test["module"]

        if module_name not in modules_map:
            mod_id = generate_module_id(project_id, module_name)
            modules_map[module_name] = {
                "id": mod_id,
                "name": module_name,
                "project_id": project_id,
                "path": f"tests/scripts/{module_name}",
            }

        mod_id = modules_map[module_name]["id"]
        test_id = generate_test_id(mod_id, test["name"], test["type"])
        enriched_tests.append({
            "id": test_id,
            "module_id": mod_id,
            **test,
        })

    return {
        "project_id": project_id,
        "project_path": str(repo_path),
        "modules": list(modules_map.values()),
        "tests": enriched_tests,
    }
