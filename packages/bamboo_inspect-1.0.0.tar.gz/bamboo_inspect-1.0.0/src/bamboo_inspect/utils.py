"""Utility functions for Bamboo Inspect.

Provides deterministic hash-ID generation used across the scanner,
database queries, and CLI commands.
"""

import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path


def generate_hash_id(input_string: str) -> str:
    """Generate a deterministic 16-char hex hash ID from *input_string*.

    Uses SHA-256 truncated to 16 hex characters (64 bits).
    """
    return hashlib.sha256(input_string.encode("utf-8")).hexdigest()[:16]


def generate_project_id(path: Path) -> str:
    """Generate a deterministic project ID from the repo *path*."""
    return generate_hash_id(f"project:{path.resolve()}")


def generate_module_id(project_id: str, module_name: str) -> str:
    """Generate a deterministic module ID."""
    return generate_hash_id(f"module:{project_id}:{module_name}")


def generate_test_id(module_id: str, test_name: str, test_type: str) -> str:
    """Generate a deterministic test ID."""
    return generate_hash_id(f"test:{module_id}:{test_name}:{test_type}")


def generate_unique_id(table_name: str) -> str:
    """Generate a unique (non-deterministic) ID for ephemeral records.

    Includes a UUID and timestamp for uniqueness.
    """
    now = datetime.now(timezone.utc).isoformat()
    return generate_hash_id(f"{table_name}:{uuid.uuid4()}:{now}")
