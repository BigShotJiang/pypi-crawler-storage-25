"""Local agent state management.

Manages the agent's persistent credentials and runtime state.
Loads/saves ~/.bambooinspect/agent.yaml.
"""

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)

AGENT_CONFIG_DIR = Path.home() / ".bambooinspect"
AGENT_CONFIG_FILE = AGENT_CONFIG_DIR / "agent.yaml"
RESULT_QUEUE_FILE = AGENT_CONFIG_DIR / "result_queue.json"


@dataclass
class AgentState:
    """Persistent agent state loaded from agent.yaml."""

    core_url: str = ""
    agent_token: str = ""
    agent_id: str = ""
    agent_name: str = ""
    labels: list[str] = field(default_factory=list)

    # Runtime config (optional overrides)
    port: int = 8787
    host: str = "127.0.0.1"
    poll_interval: int = 30  # seconds


def load_agent_state() -> Optional[AgentState]:
    """Load agent state from ~/.bambooinspect/agent.yaml.

    Returns:
        AgentState if the file exists and is valid, None otherwise.
    """
    if not AGENT_CONFIG_FILE.exists():
        return None

    try:
        raw = AGENT_CONFIG_FILE.read_text(encoding="utf-8")
        data = yaml.safe_load(raw)
    except (yaml.YAMLError, OSError) as exc:
        logger.error("Failed to load agent config: %s", exc)
        return None

    if not isinstance(data, dict):
        return None

    return AgentState(
        core_url=data.get("core_url", ""),
        agent_token=data.get("agent_token", ""),
        agent_id=data.get("agent_id", ""),
        agent_name=data.get("agent_name", ""),
        labels=data.get("labels", []),
        port=data.get("port", 8787),
        host=data.get("host", "127.0.0.1"),
        poll_interval=data.get("poll_interval", 30),
    )


def save_agent_state(state: AgentState) -> None:
    """Save agent state to ~/.bambooinspect/agent.yaml."""
    AGENT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data = {
        "core_url": state.core_url,
        "agent_token": state.agent_token,
        "agent_id": state.agent_id,
        "agent_name": state.agent_name,
        "labels": state.labels,
        "port": state.port,
        "host": state.host,
        "poll_interval": state.poll_interval,
    }

    AGENT_CONFIG_FILE.write_text(
        yaml.dump(data, default_flow_style=False),
        encoding="utf-8",
    )


def delete_agent_state() -> None:
    """Delete the agent config file."""
    try:
        AGENT_CONFIG_FILE.unlink(missing_ok=True)
        RESULT_QUEUE_FILE.unlink(missing_ok=True)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Result queue for offline submissions
# ---------------------------------------------------------------------------


def load_result_queue() -> list[dict[str, Any]]:
    """Load queued results that failed to submit."""
    if not RESULT_QUEUE_FILE.exists():
        return []
    try:
        raw = RESULT_QUEUE_FILE.read_text(encoding="utf-8")
        return json.loads(raw)
    except (json.JSONDecodeError, OSError):
        return []


def save_result_queue(queue: list[dict[str, Any]]) -> None:
    """Save the result queue to disk."""
    AGENT_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    RESULT_QUEUE_FILE.write_text(
        json.dumps(queue, indent=2, default=str),
        encoding="utf-8",
    )


def enqueue_result(execution_id: str, result: dict[str, Any]) -> None:
    """Add a result to the offline queue."""
    queue = load_result_queue()
    queue.append({"execution_id": execution_id, "result": result})
    save_result_queue(queue)
