"""Agent polling loop.

Polls the Core Manager for pending tasks, executes them using local
executors, and submits results back. Handles Core Manager outages
by queuing results locally for later submission.
"""

import asyncio
import logging
from pathlib import Path
from typing import Any, Optional

from bamboo_inspect.agent.client import CoreManagerClient
from bamboo_inspect.agent.state import (
    AgentState,
    enqueue_result,
    load_result_queue,
    save_result_queue,
)

logger = logging.getLogger(__name__)

# Shared state for the web UI
current_task: Optional[dict[str, Any]] = None
task_history: list[dict[str, Any]] = []


async def _execute_task(
    client: CoreManagerClient,
    execution: dict[str, Any],
) -> None:
    """Execute a single task and submit the result."""
    global current_task

    execution_id = execution["id"]

    # Mark task as started
    started = await client.start_task(execution_id)
    if not started:
        logger.error("Failed to start task %s", execution_id)
        return

    # Get task details
    details = await client.get_task_details(execution_id)
    if not details:
        logger.error("Failed to get details for task %s", execution_id)
        return

    current_task = details
    logger.info(
        "Executing: %s/%s (%s)",
        details.get("module_name", "?"),
        details.get("test_name", "?"),
        details.get("test_type", "?"),
    )

    # Execute the test locally
    test_type = details.get("test_type", "script")
    project_path = details.get("project_path", "")
    test_path = Path(project_path) / details.get("test_path", "")

    try:
        if test_type == "script":
            from bamboo_inspect.executors.playwright import PlaywrightExecutor
            executor = PlaywrightExecutor()
            result = await executor.execute(
                test_path,
                timeout=details.get("timeout"),
                retry_count=details.get("retry_count", 0),
            )
        else:
            from bamboo_inspect.executors.claude_code import ClaudeCodeExecutor
            executor = ClaudeCodeExecutor()
            result = await executor.execute(
                test_path,
                timeout=details.get("timeout"),
            )
    except Exception as exc:
        result = {
            "status": "failed",
            "duration": 0,
            "logs": "",
            "error_message": f"Execution error: {exc}",
        }

    current_task = None
    status_icon = "PASS" if result.get("status") == "passed" else "FAIL"
    logger.info(
        "  [%s] %s (%dms)",
        status_icon,
        details.get("test_name", "?"),
        result.get("duration", 0),
    )

    # Submit result
    submit_payload = {
        "status": result.get("status", "failed"),
        "duration": result.get("duration"),
        "error_message": result.get("error_message"),
        "logs": result.get("logs", ""),
        "artifacts": result.get("artifacts"),
    }

    submitted = await client.submit_result(execution_id, submit_payload)
    if not submitted:
        logger.warning("Failed to submit result for %s — queuing locally", execution_id)
        enqueue_result(execution_id, submit_payload)

    # Record in task history for web UI
    task_history.insert(0, {
        "execution_id": execution_id,
        "test_name": details.get("test_name", "?"),
        "module_name": details.get("module_name", "?"),
        "status": result.get("status", "failed"),
        "duration": result.get("duration", 0),
    })
    if len(task_history) > 100:
        task_history.pop()


async def _flush_result_queue(client: CoreManagerClient) -> None:
    """Try to submit any queued results from offline periods."""
    queue = load_result_queue()
    if not queue:
        return

    remaining = []
    for item in queue:
        submitted = await client.submit_result(item["execution_id"], item["result"])
        if not submitted:
            remaining.append(item)
        else:
            logger.info("Submitted queued result for %s", item["execution_id"])

    save_result_queue(remaining)


async def start_polling(state: AgentState) -> None:
    """Start the polling loop.

    Polls the Core Manager for pending tasks and executes them.
    """
    client = CoreManagerClient(state.core_url, state.agent_token)
    logger.info("Agent '%s' started polling %s (interval: %ds)", state.agent_name, state.core_url, state.poll_interval)

    try:
        while True:
            # Try to flush queued results first
            await _flush_result_queue(client)

            # Poll for pending tasks
            tasks = await client.poll_tasks()

            if tasks:
                # Execute the first pending task
                await _execute_task(client, tasks[0])
            else:
                await asyncio.sleep(state.poll_interval)
    except asyncio.CancelledError:
        logger.info("Polling loop cancelled")
    finally:
        await client.close()
