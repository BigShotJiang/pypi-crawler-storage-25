"""Test Agent core module.

Handles agent registration, heartbeat polling, task execution,
and result submission to the Core Manager.
"""
