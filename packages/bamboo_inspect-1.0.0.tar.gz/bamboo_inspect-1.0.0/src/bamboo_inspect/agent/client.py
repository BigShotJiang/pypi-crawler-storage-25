"""HTTP client wrapper for Core Manager API communication.

Handles authentication, retries, and connection errors using aiohttp.
"""

import logging
from typing import Any, Optional

import aiohttp

logger = logging.getLogger(__name__)


class CoreManagerClient:
    """HTTP client for communicating with the Core Manager."""

    def __init__(self, base_url: str, agent_token: str = "") -> None:
        self.base_url = base_url.rstrip("/")
        self.agent_token = agent_token
        self._session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=30)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.agent_token:
            headers["Authorization"] = f"Bearer {self.agent_token}"
        return headers

    async def register(
        self,
        registration_token: str,
        name: str,
        labels: list[str],
        os_info: dict,
    ) -> dict[str, Any]:
        """Register this agent with the Core Manager.

        Returns:
            Dict with agent_id, agent_token, name.
        """
        session = await self._get_session()
        payload = {
            "token": registration_token,
            "name": name,
            "labels": labels,
            "os_info": os_info,
        }
        async with session.post(
            f"{self.base_url}/api/agent/register",
            json=payload,
            headers={"Content-Type": "application/json"},
        ) as resp:
            if resp.status != 200:
                error = await resp.json()
                raise RuntimeError(error.get("detail", f"Registration failed: {resp.status}"))
            return await resp.json()

    async def poll_tasks(self) -> list[dict[str, Any]]:
        """Poll for pending tasks assigned to this agent.

        Also serves as heartbeat.
        """
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.base_url}/api/agent/tasks",
                headers=self._headers(),
            ) as resp:
                if resp.status == 401:
                    logger.error("Authentication failed — agent token invalid")
                    return []
                if resp.status != 200:
                    logger.warning("Poll failed: status %d", resp.status)
                    return []
                return await resp.json()
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Poll failed: %s", exc)
            return []

    async def start_task(self, execution_id: str) -> bool:
        """Mark a task as started."""
        session = await self._get_session()
        try:
            async with session.post(
                f"{self.base_url}/api/agent/tasks/{execution_id}/start",
                headers=self._headers(),
            ) as resp:
                return resp.status == 200
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Start task failed: %s", exc)
            return False

    async def get_task_details(self, execution_id: str) -> Optional[dict[str, Any]]:
        """Get full task details for an execution."""
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.base_url}/api/agent/tasks/{execution_id}/details",
                headers=self._headers(),
            ) as resp:
                if resp.status != 200:
                    return None
                return await resp.json()
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Get task details failed: %s", exc)
            return None

    async def submit_result(
        self,
        execution_id: str,
        result: dict[str, Any],
    ) -> bool:
        """Submit execution result to the Core Manager."""
        session = await self._get_session()
        try:
            async with session.post(
                f"{self.base_url}/api/agent/tasks/{execution_id}/result",
                json=result,
                headers=self._headers(),
            ) as resp:
                return resp.status == 200
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Submit result failed: %s", exc)
            return False

    async def sync_repo(self, scan_data: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Push scanned repo/test structure to the Core Manager.

        Args:
            scan_data: Dict with project_name, project_path, git_remote_url,
                       modules, tests — output of scanner.scan_repository().
        """
        session = await self._get_session()
        try:
            async with session.post(
                f"{self.base_url}/api/agent/sync-repo",
                json=scan_data,
                headers=self._headers(),
            ) as resp:
                if resp.status != 200:
                    error = await resp.json()
                    logger.warning("Sync repo failed: %s", error.get("detail", resp.status))
                    return None
                return await resp.json()
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Sync repo failed: %s", exc)
            return None

    async def unregister(self) -> bool:
        """Unregister this agent from the Core Manager."""
        session = await self._get_session()
        try:
            async with session.post(
                f"{self.base_url}/api/agent/unregister",
                headers=self._headers(),
            ) as resp:
                return resp.status == 200
        except (aiohttp.ClientError, Exception) as exc:
            logger.warning("Unregister failed: %s", exc)
            return False

    async def health_check(self) -> bool:
        """Check if Core Manager is reachable."""
        session = await self._get_session()
        try:
            async with session.get(f"{self.base_url}/api/health") as resp:
                return resp.status == 200
        except (aiohttp.ClientError, Exception):
            return False

    async def close(self) -> None:
        """Close the HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()
