"""Agent registration with Core Manager.

Handles the registration flow: send registration token + agent info,
receive persistent agent token, store credentials locally.
"""

import platform
from typing import Any

from bamboo_inspect.agent.client import CoreManagerClient
from bamboo_inspect.agent.state import AgentState, delete_agent_state, save_agent_state


def _get_os_info() -> dict[str, str]:
    """Collect OS information for the agent."""
    return {
        "platform": platform.system(),
        "version": platform.version(),
        "architecture": platform.machine(),
        "python_version": platform.python_version(),
    }


async def register_agent(
    core_url: str,
    registration_token: str,
    name: str,
    labels: list[str],
    port: int = 8787,
    host: str = "127.0.0.1",
    poll_interval: int = 30,
) -> dict[str, Any]:
    """Register this agent with a Core Manager.

    Args:
        core_url: URL of the Core Manager (e.g., http://core:8686).
        registration_token: One-time registration token from Core Manager.
        name: Agent display name.
        labels: Agent labels for targeting.
        port: Agent web UI port.
        host: Agent web UI host.
        poll_interval: Poll interval in seconds.

    Returns:
        Dict with agent_id, agent_token, name.

    Raises:
        RuntimeError: If registration fails.
    """
    client = CoreManagerClient(core_url)
    os_info = _get_os_info()

    try:
        result = await client.register(
            registration_token=registration_token,
            name=name,
            labels=labels,
            os_info=os_info,
        )

        # Save credentials locally
        state = AgentState(
            core_url=core_url,
            agent_token=result["agent_token"],
            agent_id=result["agent_id"],
            agent_name=result["name"],
            labels=labels,
            port=port,
            host=host,
            poll_interval=poll_interval,
        )
        save_agent_state(state)

        return result
    finally:
        await client.close()


async def unregister_agent() -> bool:
    """Unregister this agent from the Core Manager and delete local credentials.

    Returns:
        True if unregistration was successful.
    """
    from bamboo_inspect.agent.state import load_agent_state

    state = load_agent_state()
    if not state:
        return False

    client = CoreManagerClient(state.core_url, state.agent_token)
    try:
        success = await client.unregister()
    finally:
        await client.close()

    delete_agent_state()
    return success
