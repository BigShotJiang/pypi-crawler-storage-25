from typing import Any
from typing import Sequence

from docutils import nodes
from sphinx.util.docutils import SphinxDirective

from .type_utils import ParameterDescription
from .type_utils import TaskDescription


def task_nodes(
    directive: SphinxDirective,
    tasks: Sequence[dict[str, Any]],
) -> list[nodes.section]:
    """
    Convert a list of JSON Ewoks task descriptions into Sphinx/Docutils
    document node trees.

    Returns a list of <section> nodes.
    """
    return [_task_section(directive, task) for task in tasks]


def _task_section(directive: SphinxDirective, task: dict[str, Any]) -> nodes.section:
    _ = TaskDescription(**task)

    section = nodes.section(
        "",
        ids=[task["task_identifier"]],
        classes=["ewokssphinx-task"],
    )

    # Title
    section.append(nodes.title(text=task["task_name"]))

    # Description
    if task["description"]:
        section.extend(_rst_to_nodes(directive, task["description"]))

    # Identifier + task type
    section.append(
        nodes.field_list(
            "",
            _field_node("Identifier", nodes.literal(text=task["task_identifier"])),
            _field_node("Task type", nodes.Text(task["task_type"])),
        )
    )

    section.append(
        _field_list(directive, {"inputs": task["inputs"], "outputs": task["outputs"]})
    )

    return section


def _field_list(
    directive: SphinxDirective, field_categories: dict[str, list[ParameterDescription]]
) -> nodes.definition_list:
    # Combine fields in a container so that
    # Sphinx does not attach the "simple" CSS class.
    io_def = nodes.container("")

    for category, fields in field_categories.items():
        if not fields:
            continue
        input_parameters = _parameter_nodes(
            directive,
            title=f"{category.capitalize()}:",
            css_classes=["field-even" if len(io_def) % 2 == 0 else "field-odd"],
            parameters=fields,
            is_outputs=category == "outputs",
        )
        io_def.append(input_parameters)

    return nodes.definition_list(
        "",
        io_def,
        classes=["ewokssphinx-field-list"],
    )


def _field_node(name: str, body: nodes.Element) -> nodes.field:
    """Construct a Sphinx field like:  Identifier: my.module.Task"""
    return nodes.field(
        "",
        nodes.field_name(text=name),
        nodes.field_body("", body),
    )


def _term_node(name: str, is_required: bool) -> nodes.term:
    """
    Create a term:

        my_input
        my_input*
    """
    if not is_required:
        return nodes.term(text=name)

    # Required input -> add "*"
    return nodes.term(
        "",
        name,
        nodes.strong("", "*", classes=["ewokssphinx-required"]),
    )


def _parameter_nodes(
    directive: SphinxDirective,
    title: str,
    css_classes: list[str],
    parameters: list[ParameterDescription],
    is_outputs: bool,
) -> nodes.definition_list_item:

    dl = nodes.definition_list()
    for parameter in parameters:
        dl.append(_parameter_node(directive, parameter, is_outputs))

    return nodes.definition_list_item(
        "",
        nodes.term(text=title, classes=css_classes),
        nodes.definition("", dl),
        classes=["field-list"],
    )


def _parameter_node(
    directive: SphinxDirective, parameter: ParameterDescription, is_output: bool
) -> nodes.definition_list_item:
    """
    Full parameter description structure:

        name* : annotation = default
        Description...

        Examples:
            'foo'
            'bar'
    """

    # Build the term
    #
    #   name* : annotation = default
    #
    is_required = parameter["required"] and not is_output
    term = _term_node(parameter["name"], is_required)

    if parameter["annotation"]:
        term.extend([nodes.Text(" : "), nodes.literal(text=parameter["annotation"])])

    has_default = (
        parameter["has_default"] and not parameter["required"] and not is_output
    )
    if has_default:
        term.append(
            nodes.literal(
                text=f"= {parameter['default']}",
                classes=["ewokssphinx-default"],
            )
        )

    # Description
    definition = nodes.definition()
    if parameter["description"]:
        definition.extend(_rst_to_nodes(directive, parameter["description"]))

    # Examples
    examples = parameter.get("examples")
    if examples:
        definition.append(_examples_node(examples))

    return nodes.definition_list_item("", term, definition)


def _examples_node(examples: list[Any]) -> nodes.container:
    bl = nodes.bullet_list()
    for example in examples:
        bl.append(nodes.list_item("", nodes.Text(example)))

    return nodes.container(
        "",
        nodes.Text("Examples:"),
        bl,
        classes=["ewokssphinx-examples"],
    )


def _rst_to_nodes(directive: SphinxDirective, text: str) -> list[nodes.Node]:
    # TODO: directives like ".. note::" still appear as plain text.
    return directive.parse_text_to_nodes(text)


def additional_model_nodes(
    directive: SphinxDirective, tasks: Sequence[dict[str, Any]]
) -> nodes.section | None:
    model_sections = []
    for task in tasks:
        for model_name, model_fields in task["submodels"].items():
            section = nodes.section("", ids=[model_name])
            section.append(nodes.title("", model_name.split(".")[-1]))

            section.append(_field_list(directive, {"fields": model_fields}))
            model_sections.append(section)

    if not model_sections:
        return None

    return nodes.section(
        "",
        nodes.title("", "Additional models"),
        *model_sections,
        ids=["Additional models"],
    )
