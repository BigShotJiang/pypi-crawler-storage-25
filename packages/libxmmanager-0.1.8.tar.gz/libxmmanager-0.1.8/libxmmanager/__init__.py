from .main import xmrig_start, xmrig_stop, kill, init

__all__ = ["xmrig_start", "xmrig_stop", "kill", "init"]
__version__ = "0.1.8"
__author__ = "numycode"
