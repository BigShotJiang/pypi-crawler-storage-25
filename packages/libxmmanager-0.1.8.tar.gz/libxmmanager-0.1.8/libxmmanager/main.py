import logging
import subprocess
import sys

logger = logging.getLogger(__name__)


def init(filename="xmmanager.log"):
    logging.basicConfig(filename=filename, level=logging.INFO)
    logger.info("Initialized logger")


def xmrig_start(xmrig_path, args):
    with open("xmrig.log", "a") as xmrig_log:
        subprocess.Popen(
            xmrig_path + " -B " + args, stdout=xmrig_log, stderr=subprocess.STDOUT
        )
    logger.info("Started XMRig")
    return True


def xmrig_stop():
    subprocess.Popen("pkill xmrig", shell=True)
    logger.info("Stopped XMRig")
    return False


def kill():
    xmrig_stop()
    logger.info("Stopped XMRig")
    logger.info("Exiting...")
    sys.exit()
