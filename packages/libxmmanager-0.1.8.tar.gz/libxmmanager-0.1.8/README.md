# libxmmanager
![CI status](https://ci.codeberg.org/api/badges/17044/status.svg)

libxmmanager allows you to easily control XMRig, empowering you to mine easily. This will power tools like [XMManager-MB](https://codeberg.org/numycode/xmmanager) and other frontends soon.

## Usage
### CI Notice
This project is written in Python, and only needs to use Python, lint the code, build, then publish to PyPi.

## AI Notice
AI was only use for assistance with creating the CI file because I'm lazy :) also for more efficent code as not to use too much of Codeberg's resources. The rest is made by me :) or rocklake.

## Contributers
- [@rocklake](https://codeberg.org/rocklake/) ([rocklake's github](https://github.com/rocklake/)) - Helped get the code into a usable state since the whole codebase was crumbling 
<!--
## This project is now on Codeberg

You can now find this project at [CodeBerg](https://codeberg.org/numycode/libxmmanager/) instead.

Any use of this project's code by GitHub Copilot, past or present, is done without my permission.  I do not consent to GitHub's use of this project's code in Copilot.
^no github mirror yet -->