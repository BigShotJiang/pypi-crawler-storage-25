import pytest
import pygame

from tileforge import Tileset


@pytest.fixture(scope="module", autouse=True)
def pygame_init():
    pygame.init()
    pygame.display.set_mode((1, 1))
    yield
    pygame.quit()


@pytest.fixture
def mock_tileset(monkeypatch):
    tile_size = 8
    surface = pygame.Surface((16, 16), pygame.SRCALPHA)

    def mock_load(path):
        return surface

    monkeypatch.setattr(pygame.image, "load", mock_load)

    ts = Tileset("fake_path.png", tile_size)
    ts.load()
    return ts


def test_load_tiles_count(mock_tileset):
    assert len(mock_tileset.tiles) == 5


def test_empty_tile_is_first(mock_tileset):
    first_tile = mock_tileset.tiles[0]
    assert first_tile.get_size() == (mock_tileset.tile_size, mock_tileset.tile_size)


def test_scaled_tiles(mock_tileset):
    scale = 2
    scaled = mock_tileset.get_scaled_tiles(scale)

    assert len(scaled) == len(mock_tileset.tiles)
    for tile in scaled:
        assert tile.get_size() == (
            mock_tileset.tile_size * scale,
            mock_tileset.tile_size * scale,
        )


def test_set_and_has_property(mock_tileset):
    mock_tileset.set_property(100, 1)

    assert mock_tileset.has_property(100, 1)
    assert not mock_tileset.has_property(200, 1)


def test_remove_property(mock_tileset):
    mock_tileset.set_property(1, 100)
    mock_tileset.remove_property(1, 100)

    assert not mock_tileset.has_property(1, 100)


def test_toggle_property(mock_tileset):
    mock_tileset.toggle_property(1, 100)
    assert mock_tileset.has_property(1, 100)

    mock_tileset.toggle_property(1, 100)
    assert not mock_tileset.has_property(1, 100)


def test_get_properties(mock_tileset):
    mock_tileset.set_property(1, 100)
    mock_tileset.set_property(2, 100)

    props = mock_tileset.get_properties(100)
    assert props == {1, 2}


def test_serialize_deserialize(mock_tileset):
    mock_tileset.set_property(1, 100)
    mock_tileset.set_property(2, 200)

    data = mock_tileset.serialize_properties()

    new_ts = Tileset("fake_path.png", 8)
    new_ts.deserialize_properties(data)

    assert new_ts.has_property(1, 100)
    assert new_ts.has_property(2, 200)


def test_set_tile_size(monkeypatch):
    surface = pygame.Surface((16, 16), pygame.SRCALPHA)

    monkeypatch.setattr(pygame.image, "load", lambda _: surface)

    ts = Tileset("fake.png", 8)
    ts.load()

    ts.set_tile_size(4)

    assert ts.tile_size == 4
    assert len(ts.tiles) == 17


def test_set_path(monkeypatch):
    surface = pygame.Surface((16, 16), pygame.SRCALPHA)

    monkeypatch.setattr(pygame.image, "load", lambda _: surface)

    ts = Tileset("old.png", 8)
    ts.load()

    ts.set_path("new.png")

    assert ts.path == "new.png"
