# Tile Forge

This is a package for rendering top-down maps from a provided tile set image.

## Class Diagram

```mermaid
---
title: Class Relations
---

classDiagram
    Renderer *-- Tileset
    Renderer *-- Map
    class Tileset {
        + all_properties: dict[int, set[int]]
        + tile_size: int
        + path: str
        + load()
        + get_scaled_tiles(scale: int)
        + has_property(tile_index: int, property_id: int): bool
        + set_property(tile_index: int, property_index: int): void
        + remove_property(tile_index: int, property_index: int): void
        + toggle_property(tile_index: int, property_index: int): void
    }

    class Map {
        + width: int
        + height: int
        + layers: list[Layer]
        + set_layers(layers: list[Layer])
        + set_layer_count(count: int)
        + add_layer(layer: Layer)
        + cell_has_property(tileset: Tileset, pos: tuple[int, int], property_id: int): bool
    }

    class Renderer {
        - __map: Map
        - __tileset: Tileset
        + render_tile_size: int
        + tiles: list[Surface]
        + set_render_scale(scale: int)
        + render(surface: Surface, offset: [int, int], callback): void
    }
```

## Usage

```python
import pygame
from tileforge import Tileset, Map, Renderer

pygame.init()

# You need a pygame surface to render the map, so make sure to initialize pygame first
surface = pygame.Surface((640, 480))  # Create a surface to render on

# Load the tileset and map
tileset = Tileset("path/to/tileset.png", 32)
tileset.load()

# Create a map with the loaded tileset
map = Map(10, 10)  # 10x10

# Create a renderer and render the map
renderer = Renderer(tileset, map)
renderer.render(surface)
```