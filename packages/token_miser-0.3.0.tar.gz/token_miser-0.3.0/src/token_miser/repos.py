"""Repo cache management — cloning, fixture unpacking, version pinning."""

from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

import yaml


def _looks_like_sha(ref: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-f]{7,40}", ref))


@dataclass
class RepoSpec:
    id: str
    type: str = "remote"
    url: str = ""
    commit: str = ""
    bundle: str = ""  # git bundle file path (git bundle create artifact, not a loadout package)
    shallow: bool = False
    setup_commands: list[str] = field(default_factory=list)


def load_repos_config(repos_yaml: Path) -> dict[str, RepoSpec]:
    """Load repo specifications from repos.yaml."""
    data = yaml.safe_load(repos_yaml.read_text())
    specs: dict[str, RepoSpec] = {}
    for entry in data.get("repos", []):
        spec = RepoSpec(
            id=entry["id"],
            type=entry.get("type", "remote"),
            url=entry.get("url", ""),
            commit=entry.get("commit", ""),
            bundle=entry.get("bundle", ""),
            shallow=entry.get("shallow", False),
            setup_commands=entry.get("setup_commands", []),
        )
        specs[spec.id] = spec
    return specs


def ensure_repo(spec: RepoSpec, cache_dir: Path, benchmarks_dir: Path | None = None) -> Path:
    """Ensure a repo is cloned and at the correct commit. Returns the local path."""
    dest = cache_dir / spec.id

    if dest.exists() and (dest / ".git").exists():
        if spec.commit and spec.commit != "HEAD":
            subprocess.run(
                ["git", "-C", str(dest), "checkout", spec.commit],
                check=True,
                capture_output=True,
            )
        return dest
    if dest.exists():
        shutil.rmtree(dest)  # stale partial clone

    if spec.type == "fixture":
        bundle_path = Path(spec.bundle)
        if not bundle_path.is_absolute() and benchmarks_dir:
            bundle_path = benchmarks_dir / spec.bundle
        subprocess.run(
            ["git", "clone", str(bundle_path), str(dest)],
            check=True,
            capture_output=True,
        )
        if spec.commit and spec.commit != "HEAD":
            subprocess.run(
                ["git", "-C", str(dest), "checkout", spec.commit],
                check=True,
                capture_output=True,
            )
    else:
        clone_cmd = ["git", "clone"]
        is_sha = bool(spec.commit and spec.commit != "HEAD" and _looks_like_sha(spec.commit))
        if spec.shallow and not is_sha:
            clone_cmd.extend(["--depth", "1"])
            if spec.commit and spec.commit != "HEAD":
                clone_cmd.extend(["--branch", spec.commit])
        clone_cmd.extend([spec.url, str(dest)])
        subprocess.run(clone_cmd, check=True, capture_output=True)

        if spec.commit and spec.commit != "HEAD" and (not spec.shallow or is_sha):
            subprocess.run(
                ["git", "-C", str(dest), "checkout", spec.commit],
                check=True,
                capture_output=True,
            )

    return dest
