"""Quality scoring via Anthropic API (Claude as judge)."""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass

import anthropic
from anthropic.types import TextBlock

from token_miser.task import RubricDimension

logger = logging.getLogger(__name__)

JUDGE_MODEL = "claude-haiku-4-5-20251001"
GEMINI_MODEL = "gemini-2.0-flash"
MAX_TOKENS = 2000
API_TIMEOUT = 120.0
GEMINI_TIMEOUT = 60.0


@dataclass
class DimensionScore:
    dimension: str
    score: float
    reason: str
    reasoning: str = ""
    disagreement: float = 0.0


def _score_with_gemini(prompt: str, model: str = GEMINI_MODEL) -> list[dict]:
    """Score with Gemini Flash. Returns raw list of dicts with score data."""
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY not set")

    import google.generativeai as genai

    genai.configure(api_key=api_key)
    client = genai.GenerativeModel(model)

    response = client.generate_content(prompt, request_options={"timeout": GEMINI_TIMEOUT})
    text = response.text
    cleaned = text.strip()
    fence_match = re.search(r"```(?:json)?\s*\n(.*?)```", cleaned, re.DOTALL)
    if fence_match:
        cleaned = fence_match.group(1).strip()
    elif cleaned.startswith("```"):
        lines = cleaned.split("\n")
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        cleaned = "\n".join(lines)

    return json.loads(cleaned)


def score_quality(
    prompt: str,
    output: str,
    dimensions: list[RubricDimension],
    api_key: str | None = None,
    multi_judge: bool = False,
) -> list[DimensionScore]:
    """Score Claude's output against quality rubric dimensions.

    Uses a Claude judge to evaluate each dimension on a 0-1 scale.
    If multi_judge=True, also scores with Gemini Flash and returns the minimum score per dimension.
    """
    if not dimensions:
        return []

    client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
    judge_prompt = _build_judge_prompt(prompt, output, dimensions)

    message = client.messages.create(
        model=JUDGE_MODEL,
        max_tokens=MAX_TOKENS,
        timeout=API_TIMEOUT,
        messages=[{"role": "user", "content": judge_prompt}],
    )

    text = next((b.text for b in message.content if isinstance(b, TextBlock)), "")
    claude_scores = _parse_scores(text, dimensions)

    if not multi_judge:
        return claude_scores

    # Multi-judge mode: score with Gemini and merge
    try:
        gemini_raw = _score_with_gemini(judge_prompt)
    except Exception as e:
        logger.warning(f"Gemini scoring failed: {e}. Using Claude scores only.")
        return claude_scores

    # Match dimensions by name and merge scores
    merged = []
    for i, claude_score in enumerate(claude_scores):
        # Find matching Gemini score by dimension name
        gemini_item = next((g for g in gemini_raw if g.get("dimension") == claude_score.dimension), None)

        if gemini_item is None:
            logger.warning(f"No Gemini score found for dimension '{claude_score.dimension}'")
            merged.append(claude_score)
            continue

        # Parse Gemini score and clamp to [0, 1]
        try:
            gemini_score = float(gemini_item.get("score", 0))
        except (TypeError, ValueError):
            logger.warning(f"Invalid Gemini score for '{claude_score.dimension}': {gemini_item.get('score')}")
            merged.append(claude_score)
            continue

        gemini_score = max(0.0, min(1.0, gemini_score))
        claude_score_val = claude_score.score

        # Take conservative (minimum) score
        final_score = min(claude_score_val, gemini_score)
        disagreement = abs(claude_score_val - gemini_score)

        # Log warning if disagreement > 0.3
        if disagreement > 0.3:
            logger.warning(
                f"Judge disagreement on '{claude_score.dimension}': claude={claude_score_val:.2f} "
                f"gemini={gemini_score:.2f}"
            )

        # Use Claude's reason and reasoning, add disagreement
        merged.append(
            DimensionScore(
                dimension=claude_score.dimension,
                score=final_score,
                reason=claude_score.reason,
                reasoning=claude_score.reasoning,
                disagreement=disagreement,
            )
        )

    return merged


def _build_judge_prompt(prompt: str, output: str, dimensions: list[RubricDimension]) -> str:
    dim_lines = []
    for d in dimensions:
        dim_lines.append(f'- "{d.dimension}": {d.prompt}')
        # Add anchors if any are non-empty
        anchors = []
        if d.score_0:
            anchors.append(f"0.0={d.score_0}")
        if d.score_half:
            anchors.append(f"0.5={d.score_half}")
        if d.score_1:
            anchors.append(f"1.0={d.score_1}")
        if anchors:
            dim_lines.append(f"  Anchors: {' | '.join(anchors)}")

    dim_list = "\n".join(dim_lines)
    return f"""You are a code quality judge. Evaluate the following output against the given rubric.

TASK PROMPT:
{prompt}

CLAUDE OUTPUT:
{output}

RUBRIC DIMENSIONS:
{dim_list}

For each dimension, first write 1-2 sentences of reasoning (prefixed with "Reasoning:"), then provide your score.

Respond with a JSON array. Each element must have:
- "dimension": the dimension name (string)
- "reasoning": 1-2 sentences explaining your assessment
- "score": a float between 0.0 and 1.0
- "reason": one sentence summary of the score

Example: [
  {{"dimension": "correctness", "reasoning": "The agent produced 3 commit hashes. I verified hash abc123 "
  "exists but def456 appears fabricated.", "score": 0.5, "reason": "One of three hashes was fabricated."}}
]

Return ONLY the JSON array, no other text."""


def _parse_scores(text: str, dimensions: list[RubricDimension]) -> list[DimensionScore]:
    # Extract JSON from possible markdown code fences
    cleaned = text.strip()
    fence_match = re.search(r"```(?:json)?\s*\n(.*?)```", cleaned, re.DOTALL)
    if fence_match:
        cleaned = fence_match.group(1).strip()
    elif cleaned.startswith("```"):
        # Fallback: strip opening/closing fence lines
        lines = cleaned.split("\n")
        if lines and lines[0].strip().startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        cleaned = "\n".join(lines)

    raw = json.loads(cleaned)
    scores = []
    for item in raw:
        score = float(item["score"])
        if not 0.0 <= score <= 1.0:
            raise ValueError(f"Score {score} out of range [0, 1] for dimension {item['dimension']}")
        reason = item.get("reason", "")
        if not reason:
            raise ValueError(f"Empty reason for dimension {item['dimension']}")
        reasoning = item.get("reasoning", "")
        scores.append(DimensionScore(dimension=item["dimension"], score=score, reason=reason, reasoning=reasoning))
    return scores
