"""Generate quality-first score reports for CI artifacts."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from token_miser.db import init_db
from token_miser.matrix import (
    _baseline_label_for_package,
    _latest_per_task_package,
    _query_matrix_runs,
)


def build_score(suite: str, package: str, conn: sqlite3.Connection | None = None) -> dict:
    owns_conn = conn is None
    if conn is None:
        conn = init_db()

    try:
        rows = _query_matrix_runs(conn, suite)
        if not rows:
            raise ValueError(f"No tune data found for suite '{suite}'")

        best = _latest_per_task_package(rows)
        tasks = sorted({k[0] for k in best})

        def compute_quality(pkg_label: str) -> dict:
            qual_count = 0
            total_count = 0
            qual_tokens = 0
            qual_cost = 0.0
            for tid in tasks:
                if (tid, pkg_label) in best:
                    total_count += 1
                    cell = best[(tid, pkg_label)]
                    if cell["criteria_pass"] == cell["criteria_total"]:
                        qual_count += 1
                        qual_tokens += cell["tokens"]
                        qual_cost += cell["cost"]
            quality_rate = qual_count / total_count if total_count > 0 else 0.0
            return {
                "quality_rate": round(quality_rate, 3),
                "qual_count": qual_count,
                "total_count": total_count,
                "cost_when_qual": round(qual_cost, 6),
                "tokens_when_qual": qual_tokens,
            }

        pkg_score = compute_quality(package)

        baseline_label = _baseline_label_for_package(package)
        baseline_score = None
        if baseline_label:
            # Check if baseline runs actually exist
            baseline_has_runs = any((tid, baseline_label) in best for tid in tasks)
            if baseline_has_runs:
                baseline_score = compute_quality(baseline_label)

        vs_baseline = None
        if baseline_score:
            quality_rate_delta = pkg_score["quality_rate"] - baseline_score["quality_rate"]

            cost_delta_when_both_qual = None
            if pkg_score["qual_count"] > 0 and baseline_score["qual_count"] > 0:
                pkg_qualified_tasks = [
                    tid
                    for tid in tasks
                    if (tid, package) in best
                    and best[(tid, package)]["criteria_pass"] == best[(tid, package)]["criteria_total"]
                ]
                baseline_qualified_tasks = [
                    tid
                    for tid in tasks
                    if (tid, baseline_label) in best
                    and best[(tid, baseline_label)]["criteria_pass"] == best[(tid, baseline_label)]["criteria_total"]
                ]
                both_qualified = set(pkg_qualified_tasks) & set(baseline_qualified_tasks)
                if both_qualified:
                    pkg_cost_both = sum(best[(tid, package)]["cost"] for tid in both_qualified)
                    baseline_cost_both = sum(best[(tid, baseline_label)]["cost"] for tid in both_qualified)
                    cost_delta_when_both_qual = round(pkg_cost_both - baseline_cost_both, 6)

            vs_baseline = {
                "quality_rate_delta": round(quality_rate_delta, 3),
                "cost_delta_when_both_qual": cost_delta_when_both_qual,
            }

        return {
            "quality_rate": pkg_score["quality_rate"],
            "qual_count": pkg_score["qual_count"],
            "total_count": pkg_score["total_count"],
            "cost_when_qual": pkg_score["cost_when_qual"],
            "tokens_when_qual": pkg_score["tokens_when_qual"],
            "baseline": baseline_score,
            "vs_baseline": vs_baseline,
        }
    finally:
        if owns_conn:
            conn.close()


def export_score_json(suite: str, package: str, output: Path, conn: sqlite3.Connection | None = None) -> Path:
    score_data = build_score(suite, package, conn)
    output_data = {
        "schema": "token-miser/v1",
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "suite": suite,
        "package": package,
        "quality_rate": score_data["quality_rate"],
        "qual_count": score_data["qual_count"],
        "total_count": score_data["total_count"],
        "cost_when_qual": score_data["cost_when_qual"],
        "tokens_when_qual": score_data["tokens_when_qual"],
        "baseline": score_data["baseline"],
        "vs_baseline": score_data["vs_baseline"],
    }

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w") as f:
        json.dump(output_data, f, indent=2)
        f.write("\n")
    return output
