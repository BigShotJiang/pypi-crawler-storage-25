"""SQLite storage for experiment runs."""

from __future__ import annotations

import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class Run:
    id: int = 0
    agent: str = "claude"
    task_id: str = ""
    package_name: str = ""
    loadout_name: str = ""
    model: str = ""
    started_at: str = ""
    wall_seconds: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    reasoning_tokens: int = 0
    total_cost_usd: float = 0.0
    exit_code: int = 0
    criteria_pass: int = 0
    criteria_total: int = 0
    quality_scores: str = ""
    result: str = ""


@dataclass
class TuneSession:
    id: int = 0
    agent: str = "claude"
    suite_name: str = ""
    suite_version: str = ""
    baseline_package: str = ""
    tuned_package: str = ""
    started_at: str = ""
    completed_at: str = ""
    status: str = "running"
    recommendations_json: str = ""


def db_path() -> str:
    override = os.environ.get("TOKEN_MISER_DB")
    if override:
        return override
    home = Path.home()
    return str(home / ".token_miser" / "results.db")


def init_db(path: str | None = None) -> sqlite3.Connection:
    """Initialize database connection and create tables."""
    if path is None:
        path = db_path()
    if path != ":memory:":
        os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    _create_tables(conn)
    return conn


def _create_tables(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent TEXT NOT NULL DEFAULT 'claude',
            task_id TEXT NOT NULL,
            package_name TEXT NOT NULL,
            loadout_name TEXT NOT NULL DEFAULT '',
            model TEXT NOT NULL DEFAULT '',
            started_at TEXT DEFAULT '',
            wall_seconds REAL NOT NULL DEFAULT 0,
            input_tokens INTEGER NOT NULL DEFAULT 0,
            output_tokens INTEGER NOT NULL DEFAULT 0,
            cache_read_tokens INTEGER NOT NULL DEFAULT 0,
            cache_write_tokens INTEGER NOT NULL DEFAULT 0,
            reasoning_tokens INTEGER NOT NULL DEFAULT 0,
            total_cost_usd REAL NOT NULL DEFAULT 0,
            exit_code INTEGER NOT NULL DEFAULT 0,
            criteria_pass INTEGER NOT NULL DEFAULT 0,
            criteria_total INTEGER NOT NULL DEFAULT 0,
            quality_scores TEXT NOT NULL DEFAULT '',
            result TEXT NOT NULL DEFAULT ''
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS criterion_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER REFERENCES runs(id),
            criterion_type TEXT,
            passed INTEGER,
            detail TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tune_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent TEXT NOT NULL DEFAULT 'claude',
            suite_name TEXT NOT NULL,
            suite_version TEXT NOT NULL DEFAULT '',
            baseline_package TEXT NOT NULL DEFAULT '',
            tuned_package TEXT DEFAULT '',
            started_at TEXT DEFAULT '',
            completed_at TEXT DEFAULT '',
            status TEXT DEFAULT 'running',
            recommendations_json TEXT DEFAULT ''
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tune_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER REFERENCES tune_sessions(id),
            run_id INTEGER REFERENCES runs(id),
            phase TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER NOT NULL REFERENCES runs(id),
            task_id TEXT NOT NULL,
            metric_name TEXT NOT NULL,
            metric_value REAL,
            metric_bool INTEGER,
            dimension_type TEXT NOT NULL DEFAULT 'declared',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_obs_run_task ON observations(run_id, task_id)
    """)
    conn.execute("""
        CREATE INDEX IF NOT EXISTS idx_obs_metric ON observations(metric_name, run_id)
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS task_dimensions (
            task_id TEXT NOT NULL,
            dimension TEXT NOT NULL,
            value TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'declared',
            PRIMARY KEY (task_id, dimension, source)
        )
    """)
    conn.commit()

    cols = {row[1] for row in conn.execute("PRAGMA table_info(runs)").fetchall()}
    if "agent" not in cols:
        conn.execute("ALTER TABLE runs ADD COLUMN agent TEXT NOT NULL DEFAULT 'claude'")
    if "reasoning_tokens" not in cols:
        conn.execute("ALTER TABLE runs ADD COLUMN reasoning_tokens INTEGER NOT NULL DEFAULT 0")
    cols = {row[1] for row in conn.execute("PRAGMA table_info(tune_sessions)").fetchall()}
    if "baseline_profile" in cols:
        conn.execute("ALTER TABLE tune_sessions RENAME COLUMN baseline_profile TO baseline_package")
        conn.execute("ALTER TABLE tune_sessions RENAME COLUMN tuned_profile TO tuned_package")
        cols = {row[1] for row in conn.execute("PRAGMA table_info(tune_sessions)").fetchall()}
    if "agent" not in cols:
        conn.execute("ALTER TABLE tune_sessions ADD COLUMN agent TEXT NOT NULL DEFAULT 'claude'")
    conn.commit()


def store_run(conn: sqlite3.Connection, run: Run) -> int:
    """Insert a run and return its ID."""
    now = datetime.now(timezone.utc).isoformat()
    cursor = conn.execute(
        """INSERT INTO runs (agent, task_id, package_name, loadout_name, model, started_at, wall_seconds,
            input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, reasoning_tokens,
            total_cost_usd, exit_code, criteria_pass, criteria_total, quality_scores, result)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            run.agent,
            run.task_id,
            run.package_name,
            run.loadout_name,
            run.model,
            now,
            run.wall_seconds,
            run.input_tokens,
            run.output_tokens,
            run.cache_read_tokens,
            run.cache_write_tokens,
            run.reasoning_tokens,
            run.total_cost_usd,
            run.exit_code,
            run.criteria_pass,
            run.criteria_total,
            run.quality_scores,
            run.result,
        ),
    )
    conn.commit()
    row_id = cursor.lastrowid
    if row_id is None:
        raise RuntimeError("INSERT did not return a row ID")
    return row_id


def get_runs(conn: sqlite3.Connection, task_id: str = "") -> list[Run]:
    """Retrieve runs, optionally filtered by task ID."""
    if task_id:
        rows = conn.execute("SELECT * FROM runs WHERE task_id = ? ORDER BY started_at DESC", (task_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM runs ORDER BY started_at DESC").fetchall()
    return [_row_to_run(r) for r in rows]


def get_run(conn: sqlite3.Connection, run_id: int) -> Run | None:
    """Retrieve a single run by ID."""
    row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
    return _row_to_run(row) if row else None


def _row_to_run(row: sqlite3.Row) -> Run:
    return Run(
        id=row["id"],
        agent=row["agent"] if "agent" in row.keys() else "claude",
        task_id=row["task_id"],
        package_name=row["package_name"],
        loadout_name=row["loadout_name"],
        model=row["model"],
        started_at=row["started_at"],
        wall_seconds=row["wall_seconds"],
        input_tokens=row["input_tokens"],
        output_tokens=row["output_tokens"],
        cache_read_tokens=row["cache_read_tokens"],
        cache_write_tokens=row["cache_write_tokens"],
        reasoning_tokens=row["reasoning_tokens"] if "reasoning_tokens" in row.keys() else 0,
        total_cost_usd=row["total_cost_usd"],
        exit_code=row["exit_code"],
        criteria_pass=row["criteria_pass"],
        criteria_total=row["criteria_total"],
        quality_scores=row["quality_scores"],
        result=row["result"],
    )


def create_tune_session(conn: sqlite3.Connection, session: TuneSession) -> int:
    now = datetime.now(timezone.utc).isoformat()
    cursor = conn.execute(
        """INSERT INTO tune_sessions (agent, suite_name, suite_version, baseline_package,
            tuned_package, started_at, status, recommendations_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            session.agent,
            session.suite_name,
            session.suite_version,
            session.baseline_package,
            session.tuned_package,
            now,
            session.status,
            session.recommendations_json,
        ),
    )
    conn.commit()
    row_id = cursor.lastrowid
    if row_id is None:
        raise RuntimeError("INSERT did not return a row ID")
    return row_id


_TUNE_SESSION_COLUMNS = {"status", "tuned_package", "completed_at", "recommendations_json"}


def update_tune_session(conn: sqlite3.Connection, session_id: int, **kwargs: str) -> None:
    invalid = set(kwargs) - _TUNE_SESSION_COLUMNS
    if invalid:
        raise ValueError(f"Unknown tune_session columns: {invalid}")
    sets = ", ".join(f"{k} = ?" for k in kwargs)
    values = list(kwargs.values()) + [session_id]
    conn.execute(f"UPDATE tune_sessions SET {sets} WHERE id = ?", values)
    conn.commit()


def link_tune_run(conn: sqlite3.Connection, session_id: int, run_id: int, phase: str) -> None:
    conn.execute(
        "INSERT INTO tune_runs (session_id, run_id, phase) VALUES (?, ?, ?)",
        (session_id, run_id, phase),
    )
    conn.commit()


def get_tune_session(conn: sqlite3.Connection, session_id: int) -> TuneSession | None:
    row = conn.execute("SELECT * FROM tune_sessions WHERE id = ?", (session_id,)).fetchone()
    if not row:
        return None
    return TuneSession(
        id=row["id"],
        agent=row["agent"] if "agent" in row.keys() else "claude",
        suite_name=row["suite_name"],
        suite_version=row["suite_version"],
        baseline_package=row["baseline_package"],
        tuned_package=row["tuned_package"],
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        status=row["status"],
        recommendations_json=row["recommendations_json"],
    )


def get_tune_session_runs(conn: sqlite3.Connection, session_id: int, phase: str = "") -> list[Run]:
    if phase:
        rows = conn.execute(
            """SELECT r.* FROM runs r
               JOIN tune_runs tr ON r.id = tr.run_id
               WHERE tr.session_id = ? AND tr.phase = ?
               ORDER BY r.started_at""",
            (session_id, phase),
        ).fetchall()
    else:
        rows = conn.execute(
            """SELECT r.* FROM runs r
               JOIN tune_runs tr ON r.id = tr.run_id
               WHERE tr.session_id = ?
               ORDER BY r.started_at""",
            (session_id,),
        ).fetchall()
    return [_row_to_run(r) for r in rows]


def get_latest_tune_session(
    conn: sqlite3.Connection,
    suite_name: str = "",
    agent: str = "",
) -> TuneSession | None:
    if suite_name and agent:
        row = conn.execute(
            "SELECT * FROM tune_sessions WHERE suite_name = ? AND agent = ? ORDER BY started_at DESC LIMIT 1",
            (suite_name, agent),
        ).fetchone()
    elif suite_name:
        row = conn.execute(
            "SELECT * FROM tune_sessions WHERE suite_name = ? ORDER BY started_at DESC LIMIT 1",
            (suite_name,),
        ).fetchone()
    elif agent:
        row = conn.execute(
            "SELECT * FROM tune_sessions WHERE agent = ? ORDER BY started_at DESC LIMIT 1",
            (agent,),
        ).fetchone()
    else:
        row = conn.execute("SELECT * FROM tune_sessions ORDER BY started_at DESC LIMIT 1").fetchone()
    if not row:
        return None
    return TuneSession(
        id=row["id"],
        agent=row["agent"] if "agent" in row.keys() else "claude",
        suite_name=row["suite_name"],
        suite_version=row["suite_version"],
        baseline_package=row["baseline_package"],
        tuned_package=row["tuned_package"],
        started_at=row["started_at"],
        completed_at=row["completed_at"],
        status=row["status"],
        recommendations_json=row["recommendations_json"],
    )


def record_observations(
    conn: sqlite3.Connection, run_id: int, task_id: str, metrics: dict[str, float | bool | None]
) -> None:
    """Insert observations for a run and task.

    Args:
        conn: Database connection
        run_id: ID of the run
        task_id: ID of the task
        metrics: Dictionary of metric_name -> metric_value
                 Numeric values stored in metric_value, boolean in metric_bool, None in both.
    """
    for metric_name, metric_value in metrics.items():
        if isinstance(metric_value, bool):
            conn.execute(
                """INSERT INTO observations (run_id, task_id, metric_name, metric_value, metric_bool, dimension_type)
                   VALUES (?, ?, ?, NULL, ?, 'declared')""",
                (run_id, task_id, metric_name, 1 if metric_value else 0),
            )
        elif isinstance(metric_value, (int, float)):
            conn.execute(
                """INSERT INTO observations (run_id, task_id, metric_name, metric_value, metric_bool, dimension_type)
                   VALUES (?, ?, ?, ?, NULL, 'declared')""",
                (run_id, task_id, metric_name, metric_value),
            )
        else:
            conn.execute(
                """INSERT INTO observations (run_id, task_id, metric_name, metric_value, metric_bool, dimension_type)
                   VALUES (?, ?, ?, NULL, NULL, 'declared')""",
                (run_id, task_id, metric_name),
            )
    conn.commit()


def record_task_dimension(
    conn: sqlite3.Connection, task_id: str, dimension: str, value: str, source: str = "declared"
) -> None:
    """Record a dimension for a task.

    Args:
        conn: Database connection
        task_id: ID of the task
        dimension: Dimension name (e.g. "tool_pattern", "domain")
        value: Dimension value (e.g. "explore", "iac")
        source: Source of the dimension ('declared' or 'derived'), defaults to 'declared'
    """
    conn.execute(
        """INSERT OR REPLACE INTO task_dimensions (task_id, dimension, value, source)
           VALUES (?, ?, ?, ?)""",
        (task_id, dimension, value, source),
    )
    conn.commit()


def get_package_observations(conn: sqlite3.Connection, package_name: str, metric_name: str) -> list[dict]:
    """Retrieve all observations for a given package and metric.

    Args:
        conn: Database connection
        package_name: Name of the package
        metric_name: Name of the metric to filter by

    Returns:
        List of dicts with keys: run_id, task_id, package_name, metric_name,
        metric_value, metric_bool, dimension_type, run_started_at
    """
    rows = conn.execute(
        """SELECT o.run_id, o.task_id, r.package_name, o.metric_name, o.metric_value, o.metric_bool,
                  o.dimension_type, r.started_at as run_started_at
           FROM observations o
           JOIN runs r ON o.run_id = r.id
           WHERE r.package_name = ? AND o.metric_name = ?
           ORDER BY r.started_at""",
        (package_name, metric_name),
    ).fetchall()
    return [dict(row) for row in rows]
