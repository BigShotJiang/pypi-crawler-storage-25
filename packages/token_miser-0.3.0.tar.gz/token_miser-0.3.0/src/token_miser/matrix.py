"""Cross-package matrix report from tune session data."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path

from token_miser.db import init_db
from token_miser.suite import load_suite
from token_miser.tune import _benchmarks_dir


@dataclass
class CellData:
    tokens: int = 0
    cost: float = 0.0
    wall: float = 0.0
    passed: bool = False
    criteria: str = ""
    error: bool = False


def _suite_task_ids(suite: str) -> list[str]:
    benchmarks = _benchmarks_dir()
    suite_file = benchmarks / "suites" / f"{suite}.yaml"
    if not suite_file.exists():
        return []
    suite_data = load_suite(suite_file, benchmarks / "tasks")
    return [task.id for task in suite_data.tasks]


def _query_matrix_runs(conn: sqlite3.Connection, suite: str) -> list[dict]:
    task_ids = _suite_task_ids(suite)
    if not task_ids:
        return []

    placeholders = ", ".join("?" for _ in task_ids)
    rows = conn.execute(
        f"""
        SELECT r.task_id, r.package_name, r.agent, r.model,
               r.input_tokens + r.output_tokens AS tokens,
               r.total_cost_usd AS cost,
               r.wall_seconds AS wall,
               r.criteria_pass, r.criteria_total,
               tr.phase, ts.id AS session_id, ts.agent AS session_agent, ts.tuned_package,
               r.started_at
        FROM runs r
        JOIN tune_runs tr ON r.id = tr.run_id
        JOIN tune_sessions ts ON tr.session_id = ts.id
        WHERE r.task_id IN ({placeholders})
          AND ts.suite_name = ?
        ORDER BY r.started_at DESC
    """,
        [*task_ids, suite],
    ).fetchall()
    return [dict(r) for r in rows]


def _latest_per_task_package(rows: list[dict]) -> dict[tuple[str, str], dict]:
    """Keep only the most recent run per (task_id, package_label) pair."""
    best: dict[tuple[str, str], dict] = {}
    for r in rows:
        agent = r.get("agent") or r.get("session_agent") or "claude"
        if r["phase"] == "baseline" or r["package_name"] == "vanilla":
            label = f"{agent}:baseline"
        else:
            tuned = r["tuned_package"] or r["package_name"]
            label = f"{agent}:{tuned}"
        key = (r["task_id"], label)
        if key not in best:
            best[key] = r
    return best


def _baseline_label_for_package(package_label: str) -> str | None:
    agent, sep, _ = package_label.partition(":")
    if not sep or not agent:
        return None
    return f"{agent}:baseline"


def build_matrix(suite: str, conn: sqlite3.Connection | None = None) -> str:
    owns_conn = conn is None
    if conn is None:
        conn = init_db()

    rows = _query_matrix_runs(conn, suite)
    if not rows:
        return f"No tune data found for suite '{suite}'.\n"

    best = _latest_per_task_package(rows)

    tasks: list[str] = sorted({k[0] for k in best})
    packages: list[str] = sorted({k[1] for k in best})
    baseline_labels = sorted(p for p in packages if p.endswith(":baseline"))
    non_baseline_labels = sorted(p for p in packages if not p.endswith(":baseline"))
    packages = baseline_labels + non_baseline_labels

    col_w = 16
    task_w = 24
    header = f"{'task':<{task_w}}"
    for pkg in packages:
        header += f" {pkg:>{col_w}}"
    lines = [f"=== Matrix: {suite} ({len(tasks)} tasks x {len(packages)} packages) ===", ""]

    # Quality (pass/fail) table
    lines.append("QUALITY (criteria pass/total)")
    lines.append(header)
    lines.append("-" * len(header))
    for tid in tasks:
        row = f"{tid:<{task_w}}"
        for pkg in packages:
            cell = best.get((tid, pkg))
            if cell:
                p, t = cell["criteria_pass"], cell["criteria_total"]
                mark = "PASS" if p == t else "FAIL"
                val = f"{mark} {p}/{t}"
                row += f" {val:>{col_w}}"
            else:
                row += f" {'—':>{col_w}}"
        lines.append(row)

    # Cost@Quality table (cost for passing runs only)
    lines.append("")
    lines.append("COST@QUALITY (USD, passing runs only)")
    lines.append(header)
    lines.append("-" * len(header))
    for tid in tasks:
        row = f"{tid:<{task_w}}"
        for pkg in packages:
            cell = best.get((tid, pkg))
            if cell and cell["criteria_pass"] == cell["criteria_total"]:
                row += f" ${cell['cost']:>{col_w - 1}.4f}"
            else:
                row += f" {'—':>{col_w}}"
        lines.append(row)

    # Token@Quality table (tokens for passing runs only)
    lines.append("")
    lines.append("TOKEN@QUALITY (input+output, passing runs only)")
    lines.append(header)
    lines.append("-" * len(header))
    for tid in tasks:
        row = f"{tid:<{task_w}}"
        for pkg in packages:
            cell = best.get((tid, pkg))
            if cell and cell["criteria_pass"] == cell["criteria_total"]:
                row += f" {cell['tokens']:>{col_w},}"
            else:
                row += f" {'—':>{col_w}}"
        lines.append(row)

    # Cost Delta@Quality vs baseline table
    lines.append("")
    lines.append("COST DELTA@QUALITY vs BASELINE")
    delta_header = f"{'task':<{task_w}}"
    non_baseline = non_baseline_labels
    for pkg in non_baseline:
        delta_header += f" {pkg:>{col_w}}"
    lines.append(delta_header)
    lines.append("-" * len(delta_header))
    for tid in tasks:
        row = f"{tid:<{task_w}}"
        for pkg in non_baseline:
            base_label = _baseline_label_for_package(pkg)
            base = best.get((tid, base_label)) if base_label else None
            cell = best.get((tid, pkg))
            pkg_qual = cell and cell["criteria_pass"] == cell["criteria_total"]
            base_qual = base and base["criteria_pass"] == base["criteria_total"]
            if cell and base and pkg_qual and base_qual and base["cost"]:
                delta = (cell["cost"] - base["cost"]) / base["cost"] * 100
                delta_str = f"{delta:+.1f}%"
                row += f" {delta_str:>{col_w}}"
            else:
                row += f" {'—':>{col_w}}"
        lines.append(row)

    # Totals row
    lines.append("")
    lines.append("TOTALS")
    totals_header = f"{'':>{task_w}}"
    for pkg in packages:
        totals_header += f" {pkg:>{col_w}}"
    lines.append(totals_header)
    lines.append("-" * len(totals_header))

    pkg_qual_count: dict[str, int] = {}
    pkg_qual_tokens: dict[str, int] = {}
    pkg_qual_cost: dict[str, float] = {}
    pkg_total: dict[str, int] = {}
    for pkg in packages:
        total_runs = 0
        qual_count = 0
        for tid in tasks:
            if (tid, pkg) in best:
                total_runs += 1
                cell = best[(tid, pkg)]
                if cell["criteria_pass"] == cell["criteria_total"]:
                    qual_count += 1
                    pkg_qual_tokens[pkg] = pkg_qual_tokens.get(pkg, 0) + cell["tokens"]
                    pkg_qual_cost[pkg] = pkg_qual_cost.get(pkg, 0.0) + cell["cost"]
        pkg_qual_count[pkg] = qual_count
        pkg_total[pkg] = total_runs

    row_qual = f"{'qual rate':<{task_w}}"
    row_cost = f"{'cost@qual':<{task_w}}"
    row_tok = f"{'tokens@qual':<{task_w}}"
    for pkg in packages:
        qual_count = pkg_qual_count.get(pkg, 0)
        total = pkg_total.get(pkg, 0)
        rate = f"{qual_count}/{total} ({qual_count / total * 100:.1f}%)" if total else "0/0 (0.0%)"
        row_qual += f" {rate:>{col_w}}"
        row_cost += f" ${pkg_qual_cost.get(pkg, 0.0):>{col_w - 1}.4f}"
        row_tok += f" {pkg_qual_tokens.get(pkg, 0):>{col_w},}"
    lines.append(row_qual)
    lines.append(row_cost)
    lines.append(row_tok)

    result = "\n".join(lines) + "\n"
    if owns_conn:
        conn.close()
    return result


def export_matrix_json(suite: str, output: Path, conn: sqlite3.Connection | None = None) -> Path:
    owns_conn = conn is None
    if conn is None:
        conn = init_db()

    rows = _query_matrix_runs(conn, suite)
    if not rows:
        raise ValueError(f"No tune data found for suite '{suite}'")
    best = _latest_per_task_package(rows)

    tasks = sorted({k[0] for k in best})
    packages = sorted({k[1] for k in best})
    baseline_labels = sorted(p for p in packages if p.endswith(":baseline"))
    non_baseline_labels = sorted(p for p in packages if not p.endswith(":baseline"))
    packages = baseline_labels + non_baseline_labels

    models: dict[str, str] = {}
    for (tid, pkg), cell in best.items():
        if cell.get("model") and pkg not in models:
            models[pkg] = cell["model"]

    data: dict[str, dict] = {}
    for tid in tasks:
        data[tid] = {}
        for pkg in packages:
            row: dict | None = best.get((tid, pkg))
            if row:
                is_qualified = row["criteria_pass"] == row["criteria_total"]
                data[tid][pkg] = {
                    "tokens": row["tokens"],
                    "cost": round(row["cost"], 6),
                    "wall_seconds": round(row["wall"], 1),
                    "criteria_pass": row["criteria_pass"],
                    "criteria_total": row["criteria_total"],
                    "qualified": is_qualified,
                }

    summary: dict[str, dict] = {}
    for pkg in packages:
        qual_count = 0
        total_count = 0
        qual_tokens = 0
        qual_cost = 0.0
        for tid in tasks:
            if (tid, pkg) in best:
                total_count += 1
                cell = best[(tid, pkg)]
                if cell["criteria_pass"] == cell["criteria_total"]:
                    qual_count += 1
                    qual_tokens += cell["tokens"]
                    qual_cost += cell["cost"]
        quality_rate = qual_count / total_count if total_count > 0 else 0.0
        summary[pkg] = {
            "quality_rate": round(quality_rate, 3),
            "qual_count": qual_count,
            "total_count": total_count,
            "cost_when_qual": round(qual_cost, 6),
            "tokens_when_qual": qual_tokens,
        }

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w") as f:
        json.dump(
            {
                "suite": suite,
                "packages": packages,
                "tasks": tasks,
                "models": models,
                "summary": summary,
                "matrix": data,
            },
            f,
            indent=2,
        )
        f.write("\n")
    if owns_conn:
        conn.close()
    return output
