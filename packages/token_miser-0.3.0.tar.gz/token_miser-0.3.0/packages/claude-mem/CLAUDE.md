# claude-mem

Memory hooks are active. Tool usage is being captured and sent to the claude-mem worker at localhost:37777 for compression and storage.
