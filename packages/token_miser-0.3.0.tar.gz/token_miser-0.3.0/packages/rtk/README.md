# RTK (Rust Token Killer)

The `rtk` binary is not included in this package due to its size and platform-specific nature.

You can obtain the `rtk` binary by:

1.  **Downloading from Releases**: Visit the [rtk GitHub releases page](https://github.com/your-repo/rtk/releases) and download the appropriate binary for your operating system.
2.  **Building from Source**:
    *   Ensure you have Rust and Cargo installed (`rustup install stable`).
    *   Navigate to the `packages/rtk` directory.
    *   Run `cargo build --release`. The compiled binary will be located at `target/release/rtk`.
    *   Move the binary to `packages/rtk/bin/rtk` or ensure it's in your system's PATH.
