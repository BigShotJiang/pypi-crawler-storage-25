"""Tests for matrix — cross-package comparison."""

from __future__ import annotations

import json

import pytest

from token_miser.db import (
    Run,
    TuneSession,
    create_tune_session,
    init_db,
    link_tune_run,
    store_run,
)
from token_miser.matrix import build_matrix, export_matrix_json


@pytest.fixture
def conn():
    c = init_db(":memory:")
    yield c
    c.close()


def _seed_session(conn, tuned_package, task_ids, baseline_tokens=1000, tuned_tokens=800):
    session = TuneSession(
        suite_name="axis",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package=tuned_package,
        status="completed",
    )
    sid = create_tune_session(conn, session)

    for tid in task_ids:
        rb = Run(
            task_id=tid,
            package_name="vanilla",
            input_tokens=baseline_tokens,
            output_tokens=100,
            total_cost_usd=0.10,
            wall_seconds=5.0,
            criteria_pass=2,
            criteria_total=2,
        )
        rb_id = store_run(conn, rb)
        link_tune_run(conn, sid, rb_id, "baseline")

        rt = Run(
            task_id=tid,
            package_name=tuned_package,
            input_tokens=tuned_tokens,
            output_tokens=100,
            total_cost_usd=0.08,
            wall_seconds=4.0,
            criteria_pass=2,
            criteria_total=2,
        )
        rt_id = store_run(conn, rt)
        link_tune_run(conn, sid, rt_id, "tuned")

    return sid


def _seed_agent_session(conn, agent, tuned_package, task_ids, baseline_tokens, tuned_tokens):
    session = TuneSession(
        agent=agent,
        suite_name="axis",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package=tuned_package,
        status="completed",
    )
    sid = create_tune_session(conn, session)

    for tid in task_ids:
        rb = Run(
            agent=agent,
            task_id=tid,
            package_name="vanilla",
            input_tokens=baseline_tokens,
            output_tokens=0,
            total_cost_usd=0.10,
            wall_seconds=5.0,
            criteria_pass=2,
            criteria_total=2,
        )
        rb_id = store_run(conn, rb)
        link_tune_run(conn, sid, rb_id, "baseline")

        rt = Run(
            agent=agent,
            task_id=tid,
            package_name=tuned_package,
            input_tokens=tuned_tokens,
            output_tokens=0,
            total_cost_usd=0.08,
            wall_seconds=4.0,
            criteria_pass=2,
            criteria_total=2,
        )
        rt_id = store_run(conn, rt)
        link_tune_run(conn, sid, rt_id, "tuned")

    return sid


def test_build_matrix_empty(conn):
    result = build_matrix("nonexistent", conn)
    assert "No tune data" in result


def test_build_matrix_single_package(conn):
    _seed_session(conn, "pkg-a", ["bm-axis-explore", "bm-axis-smallio"])
    result = build_matrix("axis", conn)
    assert "baseline" in result
    assert "pkg-a" in result
    assert "bm-axis-explore" in result
    assert "QUALITY" in result
    assert "COST@QUALITY" in result
    assert "TOKEN@QUALITY" in result
    assert "COST DELTA@QUALITY" in result
    assert "TOTALS" in result
    # Quality must appear before Cost@Quality
    assert result.index("QUALITY") < result.index("COST@QUALITY")


def test_build_matrix_multiple_packages(conn):
    _seed_session(conn, "pkg-a", ["bm-axis-explore"], baseline_tokens=1000, tuned_tokens=800)
    _seed_session(conn, "pkg-b", ["bm-axis-explore"], baseline_tokens=1000, tuned_tokens=1200)
    result = build_matrix("axis", conn)
    assert "pkg-a" in result
    assert "pkg-b" in result
    assert "-" in result  # negative delta for pkg-a
    assert "+" in result  # positive delta for pkg-b (or in cost formatting)


def test_build_matrix_pass_fail(conn):
    sid = create_tune_session(
        conn,
        TuneSession(
            suite_name="axis",
            suite_version="0.1.0",
            baseline_package="vanilla",
            tuned_package="pkg-x",
            status="completed",
        ),
    )
    rb = Run(
        task_id="bm-axis-explore",
        package_name="vanilla",
        input_tokens=500,
        output_tokens=100,
        total_cost_usd=0.05,
        wall_seconds=3.0,
        criteria_pass=1,
        criteria_total=2,
    )
    rb_id = store_run(conn, rb)
    link_tune_run(conn, sid, rb_id, "baseline")

    rt = Run(
        task_id="bm-axis-explore",
        package_name="pkg-x",
        input_tokens=400,
        output_tokens=100,
        total_cost_usd=0.04,
        wall_seconds=2.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rt_id = store_run(conn, rt)
    link_tune_run(conn, sid, rt_id, "tuned")

    result = build_matrix("axis", conn)
    assert "FAIL 1/2" in result
    assert "PASS 2/2" in result
    # Cost should show — for failing run and cost for passing run
    lines = result.split("\n")
    cost_section_start = next(i for i, line in enumerate(lines) if "COST@QUALITY" in line)
    cost_section = "\n".join(lines[cost_section_start : cost_section_start + 10])
    assert "—" in cost_section  # baseline has 1/2 so shows —
    assert "0.0400" in cost_section  # pkg-x has 2/2 so shows cost


def test_export_matrix_json(conn, tmp_path):
    _seed_session(conn, "pkg-a", ["bm-axis-explore", "bm-axis-smallio"])
    out = tmp_path / "matrix.json"
    path = export_matrix_json("axis", out, conn)
    assert path.exists()

    data = json.loads(path.read_text())
    assert data["suite"] == "axis"
    assert "claude:baseline" in data["packages"]
    assert "claude:pkg-a" in data["packages"]
    assert "bm-axis-explore" in data["tasks"]
    assert data["matrix"]["bm-axis-explore"]["claude:baseline"]["tokens"] == 1100
    assert data["matrix"]["bm-axis-explore"]["claude:pkg-a"]["tokens"] == 900


def test_export_matrix_json_empty_raises(conn, tmp_path):
    out = tmp_path / "matrix.json"
    with pytest.raises(ValueError, match="No tune data"):
        export_matrix_json("nonexistent", out, conn)
    assert not out.exists()


def test_latest_run_wins(conn):
    _seed_session(conn, "pkg-a", ["bm-axis-explore"], baseline_tokens=1000, tuned_tokens=800)
    _seed_session(conn, "pkg-a", ["bm-axis-explore"], baseline_tokens=2000, tuned_tokens=600)
    result = build_matrix("axis", conn)
    # Latest session's data should win (2000+100=2100 baseline, 600+100=700 tuned)
    assert "2,100" in result
    assert "700" in result


def test_delta_uses_matching_agent_baseline(conn):
    _seed_agent_session(conn, "claude", "pkg-a", ["bm-axis-explore"], baseline_tokens=1000, tuned_tokens=900)
    _seed_agent_session(conn, "codex", "pkg-a", ["bm-axis-explore"], baseline_tokens=400, tuned_tokens=500)

    result = build_matrix("axis", conn)

    # Claude cost delta: (0.08 - 0.10) / 0.10 = -20.0%
    assert "-20.0%" in result
    # Codex cost delta: (0.08 - 0.10) / 0.10 = -20.0%
    assert "-20.0%" in result


def test_suite_isolation(conn, monkeypatch):
    """Runs linked to a different suite must not appear in the matrix."""
    monkeypatch.setattr(
        "token_miser.matrix._suite_task_ids",
        lambda suite: ["bm-axis-explore"] if suite == "axis" else ["bm-axis-explore"],
    )

    # Seed a session for "standard" suite with a shared task_id
    sid_std = create_tune_session(
        conn,
        TuneSession(
            agent="codex",
            suite_name="standard",
            suite_version="0.1.0",
            baseline_package="vanilla",
            tuned_package="pkg-a",
            status="completed",
        ),
    )
    rb_id = store_run(
        conn,
        Run(agent="codex", task_id="bm-axis-explore", package_name="vanilla", input_tokens=300, output_tokens=0),
    )
    link_tune_run(conn, sid_std, rb_id, "baseline")

    # Query "axis" — should not see the "standard" session's runs
    result = build_matrix("axis", conn)
    assert "No tune data" in result

    # Now seed a proper "axis" session
    _seed_agent_session(conn, "codex", "pkg-a", ["bm-axis-explore"], baseline_tokens=400, tuned_tokens=300)
    result = build_matrix("axis", conn)
    assert "codex:baseline" in result
    assert "codex:pkg-a" in result


def test_totals_shows_qual_rate_first(conn):
    """TOTALS section must show qual rate as first metric."""
    _seed_session(conn, "pkg-a", ["bm-axis-explore"])
    result = build_matrix("axis", conn)
    lines = result.split("\n")
    totals_idx = next(i for i, line in enumerate(lines) if line.strip() == "TOTALS")
    # qual rate should appear before cost@qual
    qual_idx = next(i for i in range(totals_idx, len(lines)) if "qual rate" in lines[i])
    cost_idx = next(i for i in range(totals_idx, len(lines)) if "cost@qual" in lines[i])
    assert qual_idx < cost_idx


def test_export_matrix_json_includes_summary(conn, tmp_path):
    _seed_session(conn, "pkg-a", ["bm-axis-explore", "bm-axis-smallio"])
    out = tmp_path / "matrix.json"
    path = export_matrix_json("axis", out, conn)
    assert path.exists()

    data = json.loads(path.read_text())
    assert "summary" in data
    assert "claude:baseline" in data["summary"]
    assert "claude:pkg-a" in data["summary"]
    assert "quality_rate" in data["summary"]["claude:baseline"]
    assert "qual_count" in data["summary"]["claude:baseline"]
    assert "total_count" in data["summary"]["claude:baseline"]
    assert "cost_when_qual" in data["summary"]["claude:baseline"]
    assert "tokens_when_qual" in data["summary"]["claude:baseline"]


def test_export_matrix_json_includes_qualified_flag(conn, tmp_path):
    _seed_session(conn, "pkg-a", ["bm-axis-explore"])
    out = tmp_path / "matrix.json"
    path = export_matrix_json("axis", out, conn)

    data = json.loads(path.read_text())
    assert "qualified" in data["matrix"]["bm-axis-explore"]["claude:baseline"]
    assert data["matrix"]["bm-axis-explore"]["claude:baseline"]["qualified"] is True
    assert data["matrix"]["bm-axis-explore"]["claude:pkg-a"]["qualified"] is True
