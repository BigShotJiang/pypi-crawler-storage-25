"""Tests for evaluator module (no real API calls)."""

import json
import logging
from unittest.mock import MagicMock, patch

import pytest
from anthropic.types import TextBlock

from token_miser.evaluator import _build_judge_prompt, _parse_scores, _score_with_gemini, score_quality
from token_miser.task import RubricDimension


def test_build_judge_prompt():
    dims = [RubricDimension(dimension="correctness", prompt="Is it correct?")]
    prompt = _build_judge_prompt("Do X", "Did X", dims)
    assert "Do X" in prompt
    assert "Did X" in prompt
    assert "correctness" in prompt


def test_parse_scores_valid():
    text = '[{"dimension": "quality", "score": 0.85, "reason": "Good work."}]'
    dims = [RubricDimension(dimension="quality", prompt="")]
    scores = _parse_scores(text, dims)
    assert len(scores) == 1
    assert scores[0].dimension == "quality"
    assert scores[0].score == 0.85
    assert scores[0].reason == "Good work."


def test_parse_scores_with_code_fence():
    text = '```json\n[{"dimension": "q", "score": 0.5, "reason": "OK"}]\n```'
    scores = _parse_scores(text, [])
    assert len(scores) == 1
    assert scores[0].score == 0.5


def test_parse_scores_out_of_range():
    import pytest

    text = '[{"dimension": "q", "score": 1.5, "reason": "too high"}]'
    with pytest.raises(ValueError, match="out of range"):
        _parse_scores(text, [])


def test_parse_scores_empty_reason():
    import pytest

    text = '[{"dimension": "q", "score": 0.5, "reason": ""}]'
    with pytest.raises(ValueError, match="Empty reason"):
        _parse_scores(text, [])


def test_build_judge_prompt_with_anchors():
    dims = [
        RubricDimension(
            dimension="correctness",
            prompt="Is it correct?",
            score_0="hashes fabricated or summaries contradict diffs",
            score_half="hashes real but summaries partially inaccurate",
            score_1="all hashes verified, summaries faithfully reflect diffs",
        )
    ]
    prompt = _build_judge_prompt("Do X", "Did X", dims)
    assert "Anchors:" in prompt
    assert "0.0=hashes fabricated" in prompt
    assert "0.5=hashes real but summaries partially inaccurate" in prompt
    assert "1.0=all hashes verified" in prompt


def test_build_judge_prompt_without_anchors():
    dims = [RubricDimension(dimension="correctness", prompt="Is it correct?")]
    prompt = _build_judge_prompt("Do X", "Did X", dims)
    assert "Anchors:" not in prompt


def test_build_judge_prompt_partial_anchors():
    dims = [
        RubricDimension(
            dimension="quality",
            prompt="Is it good?",
            score_0="not good",
            score_half="",
            score_1="excellent",
        )
    ]
    prompt = _build_judge_prompt("Do X", "Did X", dims)
    assert "Anchors:" in prompt
    assert "0.0=not good" in prompt
    assert "0.5=" not in prompt
    assert "1.0=excellent" in prompt


def test_build_judge_prompt_requires_reasoning():
    dims = [RubricDimension(dimension="test", prompt="Test?")]
    prompt = _build_judge_prompt("Do X", "Did X", dims)
    assert "Reasoning:" in prompt
    assert '"reasoning"' in prompt


def test_parse_scores_with_reasoning():
    text = (
        '[{"dimension": "quality", "score": 0.85, '
        '"reasoning": "The code is clean and well-structured.", "reason": "Good work."}]'
    )
    dims = [RubricDimension(dimension="quality", prompt="")]
    scores = _parse_scores(text, dims)
    assert len(scores) == 1
    assert scores[0].dimension == "quality"
    assert scores[0].score == 0.85
    assert scores[0].reason == "Good work."
    assert scores[0].reasoning == "The code is clean and well-structured."


def test_parse_scores_without_reasoning():
    text = '[{"dimension": "quality", "score": 0.85, "reason": "Good work."}]'
    dims = [RubricDimension(dimension="quality", prompt="")]
    scores = _parse_scores(text, dims)
    assert len(scores) == 1
    assert scores[0].dimension == "quality"
    assert scores[0].reasoning == ""


def test_score_quality_multi_judge_false():
    """Test that multi_judge=False returns scores with disagreement=0.0."""
    dims = [RubricDimension(dimension="quality", prompt="Is it good?")]
    claude_response = '[{"dimension": "quality", "score": 0.85, "reasoning": "Good.", "reason": "Good work."}]'

    with patch("anthropic.Anthropic") as mock_anthropic:
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message

        scores = score_quality("Do X", "Did X", dims, multi_judge=False)

        assert len(scores) == 1
        assert scores[0].dimension == "quality"
        assert scores[0].score == 0.85
        assert scores[0].disagreement == 0.0


def test_score_quality_multi_judge_true_agreeing():
    """Test multi_judge=True with Gemini agreeing with Claude."""
    dims = [RubricDimension(dimension="correctness", prompt="Is it correct?")]
    claude_response = '[{"dimension": "correctness", "score": 0.8, "reasoning": "Correct.", "reason": "Looks good."}]'
    gemini_response = '[{"dimension": "correctness", "score": 0.8}]'

    with (
        patch("anthropic.Anthropic") as mock_anthropic,
        patch("token_miser.evaluator._score_with_gemini") as mock_gemini,
    ):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message
        mock_gemini.return_value = json.loads(gemini_response)

        scores = score_quality("Do X", "Did X", dims, multi_judge=True)

        assert len(scores) == 1
        assert scores[0].dimension == "correctness"
        assert scores[0].score == 0.8  # min(0.8, 0.8)
        assert scores[0].disagreement == 0.0  # abs(0.8 - 0.8)


def test_score_quality_multi_judge_true_gemini_lower():
    """Test multi_judge=True with Gemini returning lower score."""
    dims = [RubricDimension(dimension="completeness", prompt="Is it complete?")]
    claude_response = '[{"dimension": "completeness", "score": 0.9, "reasoning": "Complete.", "reason": "All done."}]'
    gemini_response = '[{"dimension": "completeness", "score": 0.6}]'

    with (
        patch("anthropic.Anthropic") as mock_anthropic,
        patch("token_miser.evaluator._score_with_gemini") as mock_gemini,
    ):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message
        mock_gemini.return_value = json.loads(gemini_response)

        scores = score_quality("Do X", "Did X", dims, multi_judge=True)

        assert len(scores) == 1
        assert scores[0].score == 0.6  # min(0.9, 0.6)
        assert scores[0].disagreement == pytest.approx(0.3)  # abs(0.9 - 0.6)


def test_score_quality_multi_judge_disagreement_warning(caplog):
    """Test that disagreement > 0.3 logs a WARNING."""
    dims = [RubricDimension(dimension="quality", prompt="Is it good?")]
    claude_response = '[{"dimension": "quality", "score": 0.9, "reasoning": "Good.", "reason": "Looks good."}]'
    gemini_response = '[{"dimension": "quality", "score": 0.5}]'

    with (
        patch("anthropic.Anthropic") as mock_anthropic,
        patch("token_miser.evaluator._score_with_gemini") as mock_gemini,
        caplog.at_level(logging.WARNING),
    ):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message
        mock_gemini.return_value = json.loads(gemini_response)

        scores = score_quality("Do X", "Did X", dims, multi_judge=True)

        assert len(scores) == 1
        assert scores[0].disagreement == pytest.approx(0.4)  # abs(0.9 - 0.5)
        assert "Judge disagreement on 'quality'" in caplog.text
        assert "claude=0.90" in caplog.text
        assert "gemini=0.50" in caplog.text


def test_score_with_gemini_missing_api_key(monkeypatch):
    """Test that _score_with_gemini raises RuntimeError when GEMINI_API_KEY not set."""
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

    with pytest.raises(RuntimeError, match="GEMINI_API_KEY not set"):
        _score_with_gemini("test prompt")


def test_score_with_gemini_success(monkeypatch):
    """Test that _score_with_gemini successfully calls Gemini API."""
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    gemini_response = '[{"dimension": "test", "score": 0.7, "reasoning": "OK", "reason": "Fine"}]'

    with patch("google.generativeai.GenerativeModel") as mock_model:
        mock_instance = MagicMock()
        mock_model.return_value = mock_instance
        mock_response = MagicMock()
        mock_response.text = gemini_response
        mock_instance.generate_content.return_value = mock_response

        result = _score_with_gemini("test prompt")

        assert len(result) == 1
        assert result[0]["score"] == 0.7


def test_score_with_gemini_clamps_out_of_range_score(monkeypatch):
    """Test that out-of-range scores are clamped to [0, 1]."""
    dims = [RubricDimension(dimension="test", prompt="Test?")]
    claude_response = '[{"dimension": "test", "score": 0.5, "reasoning": "OK", "reason": "Fine"}]'
    gemini_response = '[{"dimension": "test", "score": 1.5}]'  # Out of range

    monkeypatch.setenv("GEMINI_API_KEY", "test-key")

    with (
        patch("anthropic.Anthropic") as mock_anthropic,
        patch("token_miser.evaluator._score_with_gemini") as mock_gemini,
    ):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message
        mock_gemini.return_value = json.loads(gemini_response)

        scores = score_quality("Do X", "Did X", dims, multi_judge=True)

        # Score should be clamped: min(0.5, 1.0) = 0.5
        assert scores[0].score == 0.5


def test_score_quality_multi_judge_dimension_mismatch(caplog):
    """Test multi_judge when Gemini response missing a dimension."""
    dims = [
        RubricDimension(dimension="dim1", prompt="First?"),
        RubricDimension(dimension="dim2", prompt="Second?"),
    ]
    claude_response = (
        '[{"dimension": "dim1", "score": 0.8, "reasoning": "OK", "reason": "Fine"}, '
        '{"dimension": "dim2", "score": 0.7, "reasoning": "OK", "reason": "Fine"}]'
    )
    gemini_response = '[{"dimension": "dim1", "score": 0.8}]'  # Missing dim2

    with (
        patch("anthropic.Anthropic") as mock_anthropic,
        patch("token_miser.evaluator._score_with_gemini") as mock_gemini,
        caplog.at_level(logging.WARNING),
    ):
        mock_client = MagicMock()
        mock_anthropic.return_value = mock_client
        mock_message = MagicMock()
        text_block = TextBlock(type="text", text=claude_response)
        mock_message.content = [text_block]
        mock_client.messages.create.return_value = mock_message
        mock_gemini.return_value = json.loads(gemini_response)

        scores = score_quality("Do X", "Did X", dims, multi_judge=True)

        assert len(scores) == 2
        assert scores[0].disagreement == 0.0
        assert scores[1].disagreement == 0.0  # No Gemini score, should use Claude only
        assert "No Gemini score found for dimension 'dim2'" in caplog.text
