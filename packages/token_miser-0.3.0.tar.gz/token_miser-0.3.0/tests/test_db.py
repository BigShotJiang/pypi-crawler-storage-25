"""Tests for database module."""

from token_miser.db import (
    Run,
    db_path,
    get_package_observations,
    get_run,
    get_runs,
    init_db,
    record_observations,
    record_task_dimension,
    store_run,
)


def test_db_path_env_override(monkeypatch, tmp_path):
    custom = str(tmp_path / "custom.db")
    monkeypatch.setenv("TOKEN_MISER_DB", custom)
    assert db_path() == custom


def test_init_and_store(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run = Run(task_id="t1", package_name="vanilla", input_tokens=100, output_tokens=50, total_cost_usd=0.01)
    run_id = store_run(conn, run)
    assert run_id > 0
    conn.close()


def test_get_runs_empty(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    runs = get_runs(conn)
    assert runs == []
    conn.close()


def test_get_runs_filtered(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    store_run(conn, Run(task_id="t1", package_name="a"))
    store_run(conn, Run(task_id="t2", package_name="b"))
    runs = get_runs(conn, "t1")
    assert len(runs) == 1
    assert runs[0].task_id == "t1"
    conn.close()


def test_get_run_by_id(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run_id = store_run(conn, Run(task_id="t1", package_name="vanilla", total_cost_usd=0.05))
    run = get_run(conn, run_id)
    assert run is not None
    assert run.task_id == "t1"
    assert run.total_cost_usd == 0.05
    conn.close()


def test_get_run_not_found(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run = get_run(conn, 999)
    assert run is None
    conn.close()


def test_roundtrip_all_fields(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run = Run(
        task_id="full",
        package_name="package-b",
        loadout_name="my-config",
        model="sonnet",
        wall_seconds=12.5,
        input_tokens=1000,
        output_tokens=500,
        cache_read_tokens=200,
        cache_write_tokens=100,
        total_cost_usd=0.123,
        criteria_pass=3,
        criteria_total=5,
        quality_scores='{"correctness": 0.9}',
        result="some output",
    )
    run_id = store_run(conn, run)
    got = get_run(conn, run_id)
    assert got.package_name == "package-b"
    assert got.loadout_name == "my-config"
    assert got.wall_seconds == 12.5
    assert got.cache_read_tokens == 200
    assert got.quality_scores == '{"correctness": 0.9}'
    conn.close()


def test_record_observations_inserts_rows(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run_id = store_run(conn, Run(task_id="task1", package_name="pkg1", input_tokens=100))
    metrics = {
        "input_tokens": 100,
        "output_tokens": 50.5,
        "success": True,
        "quality_error": False,
        "undefined": None,
    }
    record_observations(conn, run_id, "task1", metrics)
    rows = conn.execute(
        "SELECT metric_name, metric_value, metric_bool FROM observations"
        " WHERE run_id = ? ORDER BY metric_name",
        (run_id,),
    ).fetchall()
    assert len(rows) == 5
    row_dict = {r["metric_name"]: r for r in rows}
    assert row_dict["input_tokens"]["metric_value"] == 100
    assert row_dict["input_tokens"]["metric_bool"] is None
    assert row_dict["output_tokens"]["metric_value"] == 50.5
    assert row_dict["output_tokens"]["metric_bool"] is None
    assert row_dict["success"]["metric_value"] is None
    assert row_dict["success"]["metric_bool"] == 1
    assert row_dict["quality_error"]["metric_value"] is None
    assert row_dict["quality_error"]["metric_bool"] == 0
    assert row_dict["undefined"]["metric_value"] is None
    assert row_dict["undefined"]["metric_bool"] is None
    conn.close()


def test_get_package_observations_returns_correct_package(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    run_a1 = store_run(conn, Run(task_id="t1", package_name="pkg-a", input_tokens=100))
    run_a2 = store_run(conn, Run(task_id="t2", package_name="pkg-a", input_tokens=200))
    run_b1 = store_run(conn, Run(task_id="t1", package_name="pkg-b", input_tokens=300))
    record_observations(conn, run_a1, "t1", {"cost": 0.01})
    record_observations(conn, run_a2, "t2", {"cost": 0.02})
    record_observations(conn, run_b1, "t1", {"cost": 0.03})
    obs = get_package_observations(conn, "pkg-a", "cost")
    assert len(obs) == 2
    assert all(o["package_name"] == "pkg-a" for o in obs)
    assert all(o["metric_name"] == "cost" for o in obs)
    costs = sorted([o["metric_value"] for o in obs])
    assert costs == [0.01, 0.02]
    conn.close()


def test_task_dimensions_round_trip(tmp_path):
    conn = init_db(str(tmp_path / "test.db"))
    record_task_dimension(conn, "t1", "tool_pattern", "explore")
    record_task_dimension(conn, "t1", "domain", "iac")
    record_task_dimension(conn, "t2", "domain", "frontend")
    rows = conn.execute(
        "SELECT task_id, dimension, value FROM task_dimensions"
        " WHERE task_id = ? ORDER BY dimension",
        ("t1",),
    ).fetchall()
    assert len(rows) == 2
    dims = {r["dimension"]: r["value"] for r in rows}
    assert dims["tool_pattern"] == "explore"
    assert dims["domain"] == "iac"
    rows_t2 = conn.execute(
        "SELECT value FROM task_dimensions WHERE task_id = ? AND dimension = ?",
        ("t2", "domain"),
    ).fetchall()
    assert len(rows_t2) == 1
    assert rows_t2[0]["value"] == "frontend"
    conn.close()
