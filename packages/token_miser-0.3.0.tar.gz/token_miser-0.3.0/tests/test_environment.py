"""Tests for environment setup — settings.json merge."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import time
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from token_miser.environment import (
    EnvironmentContext,
    _read_manifest_services,
    _setup_claude_home,
    _start_services,
)
from token_miser.package_ref import PackageRef


@pytest.fixture
def fake_home(tmp_path: Path) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    claude_dir = home / ".claude"
    claude_dir.mkdir()
    (claude_dir / ".credentials.json").write_text('{"token": "fake"}')
    return home


@pytest.fixture
def hook_package(tmp_path: Path) -> Path:
    pkg = tmp_path / "hook-pkg"
    pkg.mkdir()
    (pkg / "manifest.yaml").write_text(
        yaml.dump(
            {
                "name": "hook-pkg",
                "version": "0.1.0",
                "author": "test",
                "description": "test hook package",
                "targets": [
                    {"path": "hooks/my-hook.sh", "dest": "hooks/my-hook.sh"},
                    {"path": "settings.json", "dest": "settings.json"},
                ],
            }
        )
    )
    hooks_dir = pkg / "hooks"
    hooks_dir.mkdir()
    (hooks_dir / "my-hook.sh").write_text("#!/bin/bash\nexit 0\n")
    (pkg / "settings.json").write_text(
        json.dumps(
            {
                "hooks": {
                    "PreToolUse": [
                        {
                            "matcher": "Bash",
                            "hooks": [{"type": "command", "command": "$HOME/.claude/hooks/my-hook.sh"}],
                        }
                    ],
                },
            }
        )
    )
    return pkg


class TestSetupClaudeHomeWithHooks:
    def test_merges_package_settings_into_claude_dir(
        self,
        tmp_path: Path,
        fake_home: Path,
        hook_package: Path,
    ) -> None:
        experiment_home = tmp_path / "experiment"
        experiment_home.mkdir()
        ref = PackageRef(name="hook-pkg", package_path=str(hook_package))

        _setup_claude_home(str(experiment_home), ref, fake_home)

        settings_path = experiment_home / ".claude" / "settings.json"
        assert settings_path.exists(), "settings.json should be placed in .claude/"
        settings = json.loads(settings_path.read_text())
        assert "hooks" in settings
        assert "PreToolUse" in settings["hooks"]

    def test_merges_with_existing_settings(
        self,
        tmp_path: Path,
        fake_home: Path,
        hook_package: Path,
    ) -> None:
        experiment_home = tmp_path / "experiment"
        experiment_home.mkdir()
        claude_dir = experiment_home / ".claude"
        claude_dir.mkdir(mode=0o700)
        (claude_dir / "settings.json").write_text(
            json.dumps(
                {
                    "permissions": {"allow": ["Read"]},
                }
            )
        )
        ref = PackageRef(name="hook-pkg", package_path=str(hook_package))

        _setup_claude_home(str(experiment_home), ref, fake_home)

        settings = json.loads((claude_dir / "settings.json").read_text())
        assert settings["permissions"]["allow"] == ["Read"]
        assert "PreToolUse" in settings["hooks"]

    def test_no_settings_json_leaves_claude_dir_unchanged(
        self,
        tmp_path: Path,
        fake_home: Path,
    ) -> None:
        simple_pkg = tmp_path / "simple-pkg"
        simple_pkg.mkdir()
        (simple_pkg / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "name": "simple",
                    "version": "0.1.0",
                    "author": "test",
                    "description": "no hooks",
                    "targets": [{"path": "CLAUDE.md", "dest": "CLAUDE.md"}],
                }
            )
        )
        (simple_pkg / "CLAUDE.md").write_text("# test\n")

        experiment_home = tmp_path / "experiment"
        experiment_home.mkdir()
        ref = PackageRef(name="simple", package_path=str(simple_pkg))

        _setup_claude_home(str(experiment_home), ref, fake_home)

        assert not (experiment_home / ".claude" / "settings.json").exists()


class TestEnvironmentContextServiceManagement:
    def test_environment_context_has_service_pids_field(self) -> None:
        ctx = EnvironmentContext(home_dir="/tmp/home", workspace_dir="/tmp/workspace")
        assert hasattr(ctx, "service_pids")
        assert ctx.service_pids == []

    def test_teardown_kills_service_processes(self, tmp_path: Path) -> None:
        home = tmp_path / "home"
        home.mkdir()

        ctx = EnvironmentContext(home_dir=str(home), workspace_dir=str(home / "workspace"))
        ctx.service_pids = [1234, 5678]

        with patch("os.getpgid") as mock_getpgid, patch("os.killpg") as mock_killpg:
            mock_getpgid.side_effect = lambda pid: pid
            ctx.teardown()
            mock_killpg.assert_any_call(1234, signal.SIGTERM)
            mock_killpg.assert_any_call(5678, signal.SIGTERM)

    def test_teardown_ignores_oserror_when_killing_pids(self, tmp_path: Path) -> None:
        home = tmp_path / "home"
        home.mkdir()

        ctx = EnvironmentContext(home_dir=str(home), workspace_dir=str(home / "workspace"))
        ctx.service_pids = [9999]  # Non-existent PID

        with patch("os.kill", side_effect=OSError("No such process")):
            # Should not raise
            ctx.teardown()


class TestServiceStartStop:
    def test_start_services_and_teardown_kills_processes(self, tmp_path: Path) -> None:
        """Integration test: start a service, verify it's running, then teardown kills it."""
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        home = tmp_path / "home"
        home.mkdir()

        pkg = tmp_path / "service-pkg"
        pkg.mkdir()

        # Create a script that writes its PID to a file and sleeps
        pid_file = workspace / "service.pid"
        service_script = pkg / "service.sh"
        service_script.write_text(f"#!/bin/bash\necho $$ > {pid_file}\nsleep 60\n")
        service_script.chmod(0o755)

        # Create manifest with the service
        (pkg / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "name": "service-pkg",
                    "version": "0.1.0",
                    "author": "test",
                    "description": "test service",
                    "targets": [],
                    "services": [{"name": "test-service", "command": f"bash {service_script}"}],
                }
            )
        )

        # Create environment context
        ctx = EnvironmentContext(home_dir=str(home), workspace_dir=str(workspace))

        # Read services from manifest
        services = _read_manifest_services(pkg)
        assert len(services) == 1
        assert services[0]["name"] == "test-service"

        # Start services
        _start_services(services, ctx)
        assert len(ctx.service_pids) == 1

        pid = ctx.service_pids[0]

        # Give the service time to start and write PID
        time.sleep(0.5)

        # Verify process is running (os.kill with signal 0 doesn't kill, just checks)
        os.kill(pid, 0)  # Should not raise if process exists

        # Verify PID file was written
        assert pid_file.exists(), "Service should have written its PID"

        # Teardown should kill the process
        ctx.teardown()

        # Give the process time to be killed
        time.sleep(0.5)

        # Verify process is gone (os.kill should raise OSError)
        with pytest.raises(OSError):
            os.kill(pid, signal.SIGTERM)


class TestPackageServiceSupport:
    def test_validate_package_accepts_services_key(self, tmp_path: Path) -> None:
        from token_miser.package_adapter import validate_package

        pkg = tmp_path / "service-pkg"
        pkg.mkdir()
        (pkg / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "name": "service-pkg",
                    "version": "0.1.0",
                    "author": "test",
                    "description": "package with services",
                    "targets": [],
                    "services": [
                        {"name": "redis", "command": "redis-server"},
                        {"name": "postgres", "command": "postgres"},
                    ],
                }
            )
        )

        errors = validate_package(pkg)
        assert errors == [], f"Validation failed: {errors}"

    def test_read_services_from_manifest(self, tmp_path: Path) -> None:
        from token_miser.package_adapter import read_services_from_manifest

        pkg = tmp_path / "service-pkg"
        pkg.mkdir()
        services = [
            {"name": "redis", "command": "redis-server"},
            {"name": "postgres", "command": "postgres"},
        ]
        (pkg / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "name": "service-pkg",
                    "version": "0.1.0",
                    "author": "test",
                    "description": "package with services",
                    "targets": [],
                    "services": services,
                }
            )
        )

        result = read_services_from_manifest(pkg)
        assert result == services

    def test_read_services_from_manifest_empty_when_absent(self, tmp_path: Path) -> None:
        from token_miser.package_adapter import read_services_from_manifest

        pkg = tmp_path / "no-service-pkg"
        pkg.mkdir()
        (pkg / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "name": "no-service-pkg",
                    "version": "0.1.0",
                    "author": "test",
                    "description": "package without services",
                    "targets": [],
                }
            )
        )

        result = read_services_from_manifest(pkg)
        assert result == []


class TestBaselineCapture:
    def test_baseline_test_state_field_exists(self) -> None:
        ctx = EnvironmentContext(home_dir="/tmp/home", workspace_dir="/tmp/workspace")
        assert hasattr(ctx, "baseline_test_state")
        assert ctx.baseline_test_state == {}

    def test_setup_env_captures_no_regressions_baseline(self, tmp_path: Path, fake_home: Path) -> None:
        from token_miser.environment import setup_env
        from token_miser.task import Criterion, Task

        workspace = tmp_path / "workspace"
        workspace.mkdir()
        repo_dir = tmp_path / "repo"
        repo_dir.mkdir()

        # Create a git repo with one commit
        subprocess.run(["git", "init"], cwd=repo_dir, capture_output=True, check=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=repo_dir, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=repo_dir, capture_output=True)
        (repo_dir / "test_file.py").write_text("pass")
        subprocess.run(["git", "add", "."], cwd=repo_dir, capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=repo_dir, capture_output=True, check=True)

        task = Task(
            id="test",
            name="test",
            repo=str(repo_dir),
            starting_commit="",
            prompt="test",
            success_criteria=[
                Criterion(
                    type="no_regressions",
                    command="echo 'tests/test_a.py::test_1 PASSED\\ntests/test_b.py::test_2 PASSED'",
                )
            ],
        )

        env = setup_env(task, PackageRef(name="test"), agent="claude")
        try:
            assert "echo 'tests/test_a.py::test_1 PASSED\\ntests/test_b.py::test_2 PASSED'" in env.baseline_test_state
            baseline = env.baseline_test_state[
                "echo 'tests/test_a.py::test_1 PASSED\\ntests/test_b.py::test_2 PASSED'"
            ]
            assert "tests/test_a.py::test_1" in baseline
            assert "tests/test_b.py::test_2" in baseline
        finally:
            env.teardown()

    def test_setup_env_handles_failed_baseline_capture(self, tmp_path: Path, fake_home: Path) -> None:
        from token_miser.environment import setup_env
        from token_miser.task import Criterion, Task

        repo_dir = tmp_path / "repo"
        repo_dir.mkdir()

        # Create a git repo
        subprocess.run(["git", "init"], cwd=repo_dir, capture_output=True, check=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=repo_dir, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test"], cwd=repo_dir, capture_output=True)
        (repo_dir / "test_file.py").write_text("pass")
        subprocess.run(["git", "add", "."], cwd=repo_dir, capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "init"], cwd=repo_dir, capture_output=True, check=True)

        task = Task(
            id="test",
            name="test",
            repo=str(repo_dir),
            starting_commit="",
            prompt="test",
            success_criteria=[
                Criterion(
                    type="no_regressions",
                    command="exit 1",  # This will fail
                )
            ],
        )

        env = setup_env(task, PackageRef(name="test"), agent="claude")
        try:
            # Should still have the baseline_test_state field, but might be empty or have empty set
            assert hasattr(env, "baseline_test_state")
        finally:
            env.teardown()
