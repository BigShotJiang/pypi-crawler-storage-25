"""Tests for score — quality-first CI artifact generation."""

from __future__ import annotations

import json

import pytest

from token_miser.db import Run, TuneSession, create_tune_session, init_db, link_tune_run, store_run
from token_miser.score import build_score, export_score_json


@pytest.fixture
def conn(monkeypatch):
    # Mock _suite_task_ids to allow tests to use arbitrary task names
    def mock_suite_task_ids(suite: str) -> list[str]:
        if suite == "standard":
            return ["task-1", "task-2", "task-3"]
        return []

    monkeypatch.setattr("token_miser.matrix._suite_task_ids", mock_suite_task_ids)

    c = init_db(":memory:")
    yield c
    c.close()


def _seed_score_session(
    conn, agent, tuned_package, task_ids, baseline_tokens, tuned_tokens, baseline_pass=2, tuned_pass=2
):
    """Seed a session with baseline and tuned packages for scoring."""
    session = TuneSession(
        agent=agent,
        suite_name="standard",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package=tuned_package,
        status="completed",
    )
    sid = create_tune_session(conn, session)

    for tid in task_ids:
        rb = Run(
            agent=agent,
            task_id=tid,
            package_name="vanilla",
            input_tokens=baseline_tokens,
            output_tokens=100,
            total_cost_usd=0.10,
            wall_seconds=5.0,
            criteria_pass=baseline_pass,
            criteria_total=2,
        )
        rb_id = store_run(conn, rb)
        link_tune_run(conn, sid, rb_id, "baseline")

        rt = Run(
            agent=agent,
            task_id=tid,
            package_name=tuned_package,
            input_tokens=tuned_tokens,
            output_tokens=100,
            total_cost_usd=0.08,
            wall_seconds=4.0,
            criteria_pass=tuned_pass,
            criteria_total=2,
        )
        rt_id = store_run(conn, rt)
        link_tune_run(conn, sid, rt_id, "tuned")

    return sid


def test_build_score_basic(conn):
    """Test build_score returns correct structure with basic metrics."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1", "task-2"], baseline_tokens=1000, tuned_tokens=800)
    score = build_score("standard", "claude:pkg-a", conn)

    assert score["quality_rate"] == 1.0
    assert score["qual_count"] == 2
    assert score["total_count"] == 2
    assert score["cost_when_qual"] == 0.16  # 2 runs * 0.08
    assert score["tokens_when_qual"] == 1800  # 2 runs * (800 + 100)


def test_build_score_with_failing_runs(conn):
    """Test build_score only counts qualifying runs for the package."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1", "task-2"],
                       baseline_tokens=1000, tuned_tokens=800,
                       baseline_pass=1, tuned_pass=2)
    score = build_score("standard", "claude:pkg-a", conn)

    # Scoring "claude:pkg-a" only looks at pkg-a runs
    # Both pkg-a runs are 2/2, so both qualify
    assert score["quality_rate"] == 1.0
    assert score["qual_count"] == 2
    assert score["total_count"] == 2
    assert score["cost_when_qual"] == 0.16  # 2 runs * 0.08


def test_build_score_no_qualifying_runs(conn):
    """Test build_score with zero qualifying runs."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1"],
                       baseline_tokens=1000, tuned_tokens=800,
                       baseline_pass=1, tuned_pass=1)
    score = build_score("standard", "claude:pkg-a", conn)

    # Scoring "claude:pkg-a" with 1/2 criteria (not qualifying)
    assert score["quality_rate"] == 0.0
    assert score["qual_count"] == 0
    assert score["total_count"] == 1  # Only the pkg-a run
    assert score["cost_when_qual"] == 0.0
    assert score["tokens_when_qual"] == 0


def test_build_score_includes_baseline(conn):
    """Test build_score includes baseline metrics."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1"], baseline_tokens=1000, tuned_tokens=800)
    score = build_score("standard", "claude:pkg-a", conn)

    assert score["baseline"] is not None
    assert score["baseline"]["quality_rate"] == 1.0
    assert score["baseline"]["qual_count"] == 1
    assert score["baseline"]["total_count"] == 1
    assert score["baseline"]["cost_when_qual"] == 0.10
    assert score["baseline"]["tokens_when_qual"] == 1100


def test_build_score_no_baseline(conn):
    """Test build_score when no baseline exists for package."""
    session = TuneSession(
        agent="claude",
        suite_name="standard",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package="pkg-a",
        status="completed",
    )
    sid = create_tune_session(conn, session)

    # Only store tuned package, no baseline
    rt = Run(
        agent="claude",
        task_id="task-1",
        package_name="pkg-a",
        input_tokens=800,
        output_tokens=100,
        total_cost_usd=0.08,
        wall_seconds=4.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rt_id = store_run(conn, rt)
    link_tune_run(conn, sid, rt_id, "tuned")

    score = build_score("standard", "claude:pkg-a", conn)
    assert score["baseline"] is None
    assert score["vs_baseline"] is None


def test_build_score_vs_baseline_quality_delta(conn):
    """Test vs_baseline includes quality_rate_delta."""
    # Seed 2 tasks: task-1 baseline qualifies, task-2 baseline doesn't qualify
    session = TuneSession(
        agent="claude",
        suite_name="standard",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package="pkg-a",
        status="completed",
    )
    sid = create_tune_session(conn, session)

    # Task 1: both baseline and package qualify
    rb1 = Run(
        agent="claude",
        task_id="task-1",
        package_name="vanilla",
        input_tokens=1000,
        output_tokens=100,
        total_cost_usd=0.10,
        wall_seconds=5.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rb1_id = store_run(conn, rb1)
    link_tune_run(conn, sid, rb1_id, "baseline")

    rt1 = Run(
        agent="claude",
        task_id="task-1",
        package_name="pkg-a",
        input_tokens=800,
        output_tokens=100,
        total_cost_usd=0.08,
        wall_seconds=4.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rt1_id = store_run(conn, rt1)
    link_tune_run(conn, sid, rt1_id, "tuned")

    # Task 2: baseline doesn't qualify, package qualifies
    rb2 = Run(
        agent="claude",
        task_id="task-2",
        package_name="vanilla",
        input_tokens=1000,
        output_tokens=100,
        total_cost_usd=0.10,
        wall_seconds=5.0,
        criteria_pass=1,
        criteria_total=2,
    )
    rb2_id = store_run(conn, rb2)
    link_tune_run(conn, sid, rb2_id, "baseline")

    rt2 = Run(
        agent="claude",
        task_id="task-2",
        package_name="pkg-a",
        input_tokens=800,
        output_tokens=100,
        total_cost_usd=0.08,
        wall_seconds=4.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rt2_id = store_run(conn, rt2)
    link_tune_run(conn, sid, rt2_id, "tuned")

    score = build_score("standard", "claude:pkg-a", conn)

    assert score["vs_baseline"] is not None
    # Package: 2/2 qualified (1.0), Baseline: 1/2 qualified (0.5)
    # Delta: 1.0 - 0.5 = 0.5
    assert score["vs_baseline"]["quality_rate_delta"] == pytest.approx(0.5, abs=0.01)


def test_build_score_vs_baseline_cost_delta_both_qualified(conn):
    """Test vs_baseline cost_delta only when both package and baseline qualify."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1", "task-2"],
                       baseline_tokens=1000, tuned_tokens=800,
                       baseline_pass=2, tuned_pass=2)
    score = build_score("standard", "claude:pkg-a", conn)

    # Both baseline and package qualify on both tasks
    assert score["vs_baseline"]["cost_delta_when_both_qual"] is not None
    # Cost difference: 2 tasks * (0.08 - 0.10) = -0.04
    assert score["vs_baseline"]["cost_delta_when_both_qual"] == -0.04


def test_build_score_vs_baseline_cost_delta_none_when_not_both_qualified(conn):
    """Test vs_baseline cost_delta is None when either baseline or package doesn't qualify."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1", "task-2"],
                       baseline_tokens=1000, tuned_tokens=800,
                       baseline_pass=1, tuned_pass=2)
    score = build_score("standard", "claude:pkg-a", conn)

    # Baseline doesn't qualify on any task (1/2), so cost_delta_when_both_qual is None
    assert score["vs_baseline"]["cost_delta_when_both_qual"] is None


def test_build_score_vs_baseline_partial_both_qualified(conn):
    """Test vs_baseline cost_delta when both qualify on some tasks."""
    session = TuneSession(
        agent="claude",
        suite_name="standard",
        suite_version="0.1.0",
        baseline_package="vanilla",
        tuned_package="pkg-a",
        status="completed",
    )
    sid = create_tune_session(conn, session)

    # Task 1: both qualify
    rb1 = Run(
        agent="claude",
        task_id="task-1",
        package_name="vanilla",
        input_tokens=1000,
        output_tokens=100,
        total_cost_usd=0.10,
        wall_seconds=5.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rb1_id = store_run(conn, rb1)
    link_tune_run(conn, sid, rb1_id, "baseline")

    rt1 = Run(
        agent="claude",
        task_id="task-1",
        package_name="pkg-a",
        input_tokens=800,
        output_tokens=100,
        total_cost_usd=0.08,
        wall_seconds=4.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rt1_id = store_run(conn, rt1)
    link_tune_run(conn, sid, rt1_id, "tuned")

    # Task 2: only baseline qualifies
    rb2 = Run(
        agent="claude",
        task_id="task-2",
        package_name="vanilla",
        input_tokens=1000,
        output_tokens=100,
        total_cost_usd=0.10,
        wall_seconds=5.0,
        criteria_pass=2,
        criteria_total=2,
    )
    rb2_id = store_run(conn, rb2)
    link_tune_run(conn, sid, rb2_id, "baseline")

    rt2 = Run(
        agent="claude",
        task_id="task-2",
        package_name="pkg-a",
        input_tokens=800,
        output_tokens=100,
        total_cost_usd=0.08,
        wall_seconds=4.0,
        criteria_pass=1,
        criteria_total=2,
    )
    rt2_id = store_run(conn, rt2)
    link_tune_run(conn, sid, rt2_id, "tuned")

    score = build_score("standard", "claude:pkg-a", conn)

    # Only task-1 has both qualified
    # Cost delta: 0.08 - 0.10 = -0.02
    assert score["vs_baseline"]["cost_delta_when_both_qual"] == -0.02


def test_export_score_json(conn, tmp_path):
    """Test export_score_json creates file with correct schema."""
    _seed_score_session(conn, "claude", "pkg-a", ["task-1"], baseline_tokens=1000, tuned_tokens=800)

    out = tmp_path / "score.json"
    path = export_score_json("standard", "claude:pkg-a", out, conn)

    assert path.exists()
    data = json.loads(path.read_text())

    assert data["schema"] == "token-miser/v1"
    assert "generated_at" in data
    assert data["suite"] == "standard"
    assert data["package"] == "claude:pkg-a"
    assert data["quality_rate"] == 1.0
    assert data["qual_count"] == 1
    assert data["total_count"] == 1
    assert data["cost_when_qual"] == 0.08
    assert data["tokens_when_qual"] == 900
    assert data["baseline"] is not None
    assert data["vs_baseline"] is not None
