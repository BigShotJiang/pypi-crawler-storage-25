# token_miser Memory

## Packages

24 packages in `packages/`: adversarial-frugal, async-first, c-structured, caveman, context-guardian, depth-control, domain-python-api, drona23, fail-smart, lean, minimal-wip, opportunistic-lazy, personal, phase-budget, piersede, planner, quality-floor, rtk, rubin, rubin-async, rubin-lazy, tdd-strict, thinking-cap, thorough, token-miser.

