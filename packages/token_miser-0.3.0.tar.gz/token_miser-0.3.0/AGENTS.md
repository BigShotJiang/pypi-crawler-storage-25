# token_miser

Benchmarks coding-agent configurations; records token usage, cost, and task outcomes.

## Common Commands
- Install/sync: `uv sync`
- Tests: `uv run pytest -q`
- Lint: `uv run ruff check src tests`
- Format: `uv run ruff format src tests`
- CLI help: `uv run token-miser --help`

## Repo Notes
- Main CLI entrypoint: `src/token_miser/__main__.py`
- Execution backends: `src/token_miser/backends/` (claude, codex) — extend `base.py`
- Benchmark environment setup: `src/token_miser/environment.py`
- Run data schema: `src/token_miser/db.py`
- Package operations: `src/token_miser/package_adapter.py` — validate, apply, restore, pack packages
- Package publishing to kanon: `src/token_miser/publish.py`
- Experiment packages live in `packages/`

## Working Rules
- Keep backend additions additive; do not regress existing Claude behavior while adding Codex support
- Depends on kanon-cli — `uv sync` resolves it
- Schema changes need migration logic in `init_db()`, not fresh database creation
- `checker.py` evaluates success criteria — changes affect all benchmark results, test carefully
- `package_adapter.py` inlines loadout functionality — no external loadout dependency
- Packages renamed: `slim-rubin` → `lean`, `full-rubin` → `personal` (2026-05-07)
- `observations` and `task_dimensions` tables exist in db.py; use `record_observations()` to log per-task metrics
- `environment.py` deep-merges package settings.json into ~/.claude/settings.json; starts services listed in manifest.yaml
