LIB_IMPORTS = {
    "pandas": "import pandas as pd",
    "dask": "import dask.dataframe as dd\nimport pandas as pd",
    "polars": "import polars as pl",
    "vaex": "import vaex\nimport pandas as pd",
    "modin": "import modin.pandas as pd",
}


def lib_read_csv(data_lib, path_expr, **kwargs):
    if data_lib == "polars":
        return f"pl.read_csv({path_expr})"
    elif data_lib == "dask":
        return f"dd.read_csv({path_expr})"
    elif data_lib == "vaex":
        return f"vaex.from_csv({path_expr})"
    return f"pd.read_csv({path_expr})"


def lib_write_csv(data_lib, df_expr, path_expr):
    if data_lib == "polars":
        return f"{df_expr}.write_csv({path_expr})"
    elif data_lib == "dask":
        return f"{df_expr}.compute().to_csv({path_expr}, index=False)"
    elif data_lib == "vaex":
        return f"{df_expr}.export_csv({path_expr})"
    return f"{df_expr}.to_csv({path_expr}, index=False)"


def lib_merge(data_lib, left, right, left_on=None, right_on=None,
              on=None, how="inner", suffixes=("", "_master")):
    if data_lib == "polars":
        if on:
            return f"{left}.join({right}, on={on}, how='{how}', suffix='_master')"
        elif left_on and right_on:
            return f"{left}.join({right}, left_on={left_on}, right_on={right_on}, how='{how}', suffix='_master')"
        else:
            return f"{left}.join({right}, how='{how}', suffix='_master')"
    elif data_lib == "dask":
        if on:
            return f"dd.merge({left}, {right}, on={on}, how='{how}', suffixes={suffixes})"
        elif left_on and right_on:
            return f"dd.merge({left}, {right}, left_on={left_on}, right_on={right_on}, how='{how}', suffixes={suffixes})"
        else:
            return f"dd.merge({left}, {right}, how='{how}', suffixes={suffixes})"
    else:
        if on:
            return f"{left}.merge({right}, on={on}, how='{how}', suffixes={suffixes})"
        elif left_on and right_on:
            return f"{left}.merge({right}, left_on={left_on}, right_on={right_on}, how='{how}', suffixes={suffixes})"
        else:
            return f"{left}.merge({right}, how='{how}', suffixes={suffixes})"


def lib_sort(data_lib, df_expr, by, ascending):
    if data_lib == "polars":
        desc_list = [not a for a in ascending] if isinstance(ascending, list) else [not ascending]
        return f"{df_expr}.sort({by}, descending={desc_list})"
    elif data_lib == "dask":
        return f"{df_expr}.sort_values(by={by}, ascending={ascending})"
    return f"{df_expr}.sort_values(by={by}, ascending={ascending}).reset_index(drop=True)"


def lib_groupby_agg(data_lib, df_expr, group_cols, agg_spec):
    if data_lib == "polars":
        agg_exprs = []
        for out_name, (col, func) in agg_spec.items():
            pl_func = _polars_agg_func(func, col, out_name)
            agg_exprs.append(pl_func)
        agg_str = ", ".join(agg_exprs)
        return f"{df_expr}.group_by({group_cols}).agg({agg_str})"
    elif data_lib == "dask":
        named_aggs = ", ".join(
            f"{out_name}=pd.NamedAgg(column='{col}', aggfunc='{func}')"
            for out_name, (col, func) in agg_spec.items()
        )
        return f"{df_expr}.groupby({group_cols}).agg({named_aggs}).reset_index()"
    else:
        named_aggs = ", ".join(
            f"{out_name}=pd.NamedAgg(column='{col}', aggfunc='{func}')"
            for out_name, (col, func) in agg_spec.items()
        )
        return f"{df_expr}.groupby({group_cols}, as_index=False).agg(\n        {named_aggs}\n    )"


def lib_groupby_first(data_lib, df_expr, group_cols):
    if data_lib == "polars":
        return f"{df_expr}.group_by({group_cols}).first()"
    elif data_lib == "dask":
        return f"{df_expr}.groupby({group_cols}).first().reset_index()"
    return f"{df_expr}.groupby({group_cols}, as_index=False).agg('first')"


def lib_concat(data_lib, df_list_str):
    if data_lib == "polars":
        return f"pl.concat([{df_list_str}])"
    elif data_lib == "dask":
        return f"dd.concat([{df_list_str}])"
    return f"pd.concat([{df_list_str}], ignore_index=True)"


def lib_empty_df(data_lib):
    if data_lib == "polars":
        return "pl.DataFrame()"
    return "pd.DataFrame()"


def lib_copy(data_lib, df_expr):
    if data_lib == "polars":
        return f"{df_expr}.clone()"
    elif data_lib == "dask":
        return f"{df_expr}.copy()"
    return f"{df_expr}.copy()"


def lib_filter(data_lib, df_expr, condition):
    if data_lib == "polars":
        return f"{df_expr}.filter({condition})"
    return f"{df_expr}[{condition}]"


def lib_rank(data_lib, df_expr, group_cols, rank_col, ascending, out_field):
    if data_lib == "polars":
        order = "descending" if not ascending else "ascending"
        if group_cols:
            return (
                f"{df_expr}.with_columns(\n"
                f"        pl.col('{rank_col}').rank(method='min', descending={not ascending})"
                f".over({group_cols}).alias('{out_field}')\n"
                f"    )"
            )
        return (
            f"{df_expr}.with_columns(\n"
            f"        pl.col('{rank_col}').rank(method='min', descending={not ascending})"
            f".alias('{out_field}')\n"
            f"    )"
        )
    if group_cols:
        return (
            f"_rank_vals = {df_expr}.groupby({group_cols})['{rank_col}'].rank(\n"
            f"        method='min', ascending={ascending}\n"
            f"    )\n"
            f"    {df_expr}['{out_field}'] = _rank_vals.fillna(0).astype(int)"
        )
    return (
        f"_rank_vals = {df_expr}['{rank_col}'].rank(method='min', ascending={ascending})\n"
        f"    {df_expr}['{out_field}'] = _rank_vals.fillna(0).astype(int)"
    )


def _polars_agg_func(func, col, out_name):
    func_map = {
        "sum": f"pl.col('{col}').sum().alias('{out_name}')",
        "mean": f"pl.col('{col}').mean().alias('{out_name}')",
        "min": f"pl.col('{col}').min().alias('{out_name}')",
        "max": f"pl.col('{col}').max().alias('{out_name}')",
        "count": f"pl.col('{col}').count().alias('{out_name}')",
        "first": f"pl.col('{col}').first().alias('{out_name}')",
        "last": f"pl.col('{col}').last().alias('{out_name}')",
        "std": f"pl.col('{col}').std().alias('{out_name}')",
        "median": f"pl.col('{col}').median().alias('{out_name}')",
        "nunique": f"pl.col('{col}').n_unique().alias('{out_name}')",
    }
    return func_map.get(func, f"pl.col('{col}').{func}().alias('{out_name}')")
