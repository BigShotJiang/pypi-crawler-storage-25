import re


ORACLE_TO_ANSI = [
    (re.compile(r'\bNVL2\s*\(\s*([^,]+?)\s*,\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'CASE WHEN \1 IS NOT NULL THEN \2 ELSE \3 END'),
    (re.compile(r'\bNVL\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'COALESCE(\1, \2)'),
    (re.compile(r'\bSYSDATE\b', re.IGNORECASE), 'CURRENT_TIMESTAMP'),
    (re.compile(r'\bSYSTIMESTAMP\b', re.IGNORECASE), 'CURRENT_TIMESTAMP'),
    (re.compile(r'\|\|', re.IGNORECASE), ' || '),
]

MSSQL_TO_ANSI = [
    (re.compile(r'\bISNULL\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'COALESCE(\1, \2)'),
    (re.compile(r'\bGETDATE\s*\(\s*\)', re.IGNORECASE), 'CURRENT_TIMESTAMP'),
    (re.compile(r'\bCONVERT\s*\(\s*VARCHAR\s*,\s*([^,)]+?)\s*,\s*\d+\s*\)', re.IGNORECASE),
     r'CAST(\1 AS VARCHAR)'),
    (re.compile(r'\bLEN\s*\(', re.IGNORECASE), 'LENGTH('),
    (re.compile(r'\bCHARINDEX\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'POSITION(\1 IN \2)'),
]

_DECODE_RE = re.compile(
    r'\bDECODE\s*\(', re.IGNORECASE
)

_ORACLE_JOIN_RE = re.compile(
    r'(\w+\.\w+)\s*=\s*(\w+\.\w+)\s*\(\+\)'
)

_ORACLE_JOIN_RE2 = re.compile(
    r'(\w+\.\w+)\s*\(\+\)\s*=\s*(\w+\.\w+)'
)

_ROWNUM_RE = re.compile(
    r'\bAND\s+ROWNUM\s*<=?\s*(\d+)\b|\bWHERE\s+ROWNUM\s*<=?\s*(\d+)\b',
    re.IGNORECASE
)

_TOP_RE = re.compile(
    r'\bSELECT\s+TOP\s+(\d+)\b', re.IGNORECASE
)


def _convert_decode(sql):
    result = sql
    idx = 0
    while True:
        m = _DECODE_RE.search(result, idx)
        if not m:
            break
        start = m.start()
        paren_start = m.end() - 1
        depth = 1
        pos = paren_start + 1
        while pos < len(result) and depth > 0:
            if result[pos] == '(':
                depth += 1
            elif result[pos] == ')':
                depth -= 1
            pos += 1
        if depth != 0:
            idx = pos
            continue
        inner = result[paren_start + 1:pos - 1]
        args = _split_args(inner)
        if len(args) < 3:
            idx = pos
            continue
        expr = args[0].strip()
        pairs = args[1:]
        case_parts = [f"CASE {expr}"]
        i = 0
        while i < len(pairs) - 1:
            case_parts.append(f" WHEN {pairs[i].strip()} THEN {pairs[i+1].strip()}")
            i += 2
        if i < len(pairs):
            case_parts.append(f" ELSE {pairs[i].strip()}")
        case_parts.append(" END")
        replacement = "".join(case_parts)
        result = result[:start] + replacement + result[pos:]
        idx = start + len(replacement)
    return result


def _split_args(s):
    args = []
    depth = 0
    in_quote = None
    current = []
    for ch in s:
        if in_quote:
            current.append(ch)
            if ch == in_quote:
                in_quote = None
        elif ch in ("'", '"'):
            in_quote = ch
            current.append(ch)
        elif ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            args.append(''.join(current))
            current = []
        else:
            current.append(ch)
    if current:
        args.append(''.join(current))
    return args


def _convert_oracle_outer_join(sql):
    result = _ORACLE_JOIN_RE.sub(
        lambda m: f'{m.group(1)} = {m.group(2)} -- (+) converted: use LEFT JOIN',
        sql
    )
    result = _ORACLE_JOIN_RE2.sub(
        lambda m: f'{m.group(1)} = {m.group(2)} -- (+) converted: use RIGHT JOIN',
        result
    )
    return result


def _convert_rownum(sql):
    m = _ROWNUM_RE.search(sql)
    if m:
        limit_val = m.group(1) or m.group(2)
        cleaned = _ROWNUM_RE.sub('', sql).strip()
        if cleaned.endswith('AND'):
            cleaned = cleaned[:-3].strip()
        if cleaned.endswith('WHERE'):
            cleaned = cleaned[:-5].strip()
        cleaned = cleaned.rstrip(';')
        return f"{cleaned}\nLIMIT {limit_val}"
    return sql


def _convert_top(sql):
    m = _TOP_RE.search(sql)
    if m:
        limit_val = m.group(1)
        cleaned = _TOP_RE.sub('SELECT', sql)
        cleaned = cleaned.rstrip(';')
        return f"{cleaned}\nLIMIT {limit_val}"
    return sql


def translate_sql(sql, source_dialect="auto", target_dialect="ansi"):
    if not sql or not sql.strip():
        return sql

    from informatica_python.utils.expression_converter import detect_sql_dialect

    if source_dialect == "auto":
        source_dialect = detect_sql_dialect(sql).lower()

    translated = sql

    if source_dialect == "oracle":
        translated = _convert_oracle_outer_join(translated)
        translated = _convert_decode(translated)
        translated = _convert_rownum(translated)
        for pattern, replacement in ORACLE_TO_ANSI:
            translated = pattern.sub(replacement, translated)

    elif source_dialect in ("mssql", "sql server"):
        translated = _convert_top(translated)
        for pattern, replacement in MSSQL_TO_ANSI:
            translated = pattern.sub(replacement, translated)

    elif source_dialect in ("generic", "postgresql"):
        translated = _convert_decode(translated)
        for pattern, replacement in ORACLE_TO_ANSI:
            translated = pattern.sub(replacement, translated)
        for pattern, replacement in MSSQL_TO_ANSI:
            translated = pattern.sub(replacement, translated)

    return translated
