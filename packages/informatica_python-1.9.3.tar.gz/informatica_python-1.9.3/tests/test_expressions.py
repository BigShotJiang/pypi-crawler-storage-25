import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from informatica_python.utils.expression_converter import (
    convert_expression_vectorized,
    convert_expression,
    convert_filter_vectorized,
    _vectorize_condition,
    _strip_inline_comments,
)


class TestDecodeVectorized:
    def test_decode_true_isnull_simple(self):
        r = convert_expression_vectorized("DECODE(TRUE, ISNULL(field1), NULL, field1)")
        assert "np.where" in r
        assert "isna()" in r

    def test_decode_true_isnull_with_num(self):
        r = convert_expression_vectorized("DECODE(TRUE, ISNULL(STATUS), 0, STATUS)")
        assert "np.where" in r
        assert "isna()" in r
        assert "0" in r

    def test_decode_true_isnull_with_str(self):
        r = convert_expression_vectorized("DECODE(TRUE, ISNULL(NAME), 'Unknown', NAME)")
        assert "np.where" in r
        assert "'Unknown'" in r

    def test_decode_value_match_3_pairs(self):
        r = convert_expression_vectorized("DECODE(STATUS, 1, 'Active', 2, 'Inactive', 3, 'Pending')")
        assert r.count("np.where") == 3
        assert "'Active'" in r
        assert "'Inactive'" in r
        assert "'Pending'" in r

    def test_decode_value_match_with_default(self):
        r = convert_expression_vectorized("DECODE(STATUS, 1, 'A', 2, 'B', 'X')")
        assert r.count("np.where") == 2
        assert "'X'" in r

    def test_decode_value_match_many_pairs(self):
        r = convert_expression_vectorized(
            "DECODE(CODE, 1, 'one', 2, 'two', 3, 'three', 4, 'four', 5, 'five', 6, 'six', 7, 'seven', 8, 'eight')"
        )
        assert r.count("np.where") == 8

    def test_decode_value_with_concat(self):
        r = convert_expression_vectorized(
            "DECODE(TYPE, 1, CONCAT(NAME, ' Sr'), 2, CONCAT(NAME, ' Jr'))"
        )
        assert "np.where" in r
        assert "astype(str)" in r

    def test_decode_true_length_conditions(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, LENGTH(LTRIM(RTRIM(NAME))) <= 10, LTRIM(RTRIM(NAME)), "
            "LENGTH(LTRIM(RTRIM(NAME))) > 10, SUBSTR(LTRIM(RTRIM(NAME)), 1, 10), NULL)"
        )
        assert "np.where" in r
        assert "str.len()" in r

    def test_decode_true_length_eq(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, LENGTH(LTRIM(RTRIM(PHONE))) = 10, LTRIM(RTRIM(PHONE)), NULL)"
        )
        assert "np.where" in r
        assert "str.len()" in r

    def test_decode_true_length_gt(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, LENGTH(LTRIM(RTRIM(ADDR))) > 0, LTRIM(RTRIM(ADDR)), NULL)"
        )
        assert "np.where" in r

    def test_decode_true_length_gt_substr(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, LENGTH(LTRIM(RTRIM(TXT))) > 5, "
            "SUBSTR(LTRIM(RTRIM(TXT)), 1, LENGTH(LTRIM(RTRIM(TXT)))), NULL)"
        )
        assert "np.where" in r

    def test_decode_true_isnull_with_is_spaces(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(NAME) OR IS_SPACES(NAME) OR NAME = '', NULL, LTRIM(RTRIM(NAME)))"
        )
        assert "np.where" in r

    def test_decode_true_isnull_or_eq_or_is_spaces(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, NAME = '' OR IS_SPACES(NAME) OR ISNULL(NAME), NULL, LTRIM(RTRIM(NAME)))"
        )
        assert "np.where" in r

    def test_decode_true_isnull_ltrim_rtrim(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(LTRIM(RTRIM(ADDR))) OR ADDR = '' OR IS_SPACES(ADDR), NULL, LTRIM(RTRIM(ADDR)))"
        )
        assert "np.where" in r

    def test_decode_true_is_spaces_in_pairs(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(NAME), NULL, LTRIM(RTRIM(NAME)) = '', NULL, IS_SPACES(NAME), NULL, NAME)"
        )
        assert r.count("np.where") >= 2

    def test_decode_true_not_isnull(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, NOT ISNULL(VAL), VAL, 'default')"
        )
        assert "np.where" in r

    def test_decode_true_not_complex(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, NOT (ISNULL(F1) OR IS_SPACES(F1) OR F1 = ''), F1, "
            "NOT (ISNULL(F2) OR IS_SPACES(F2) OR F2 = ''), F2, NULL)"
        )
        assert r.count("np.where") >= 2

    def test_decode_true_multi_isnull_and(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(F1) AND ISNULL(F2) AND ISNULL(F3), 0, 1)"
        )
        assert "np.where" in r

    def test_decode_true_multi_not_isnull_or(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, (NOT ISNULL(A) OR NOT ISNULL(B)) AND (NOT ISNULL(C) OR NOT ISNULL(D)), 1, 0)"
        )
        assert "np.where" in r

    def test_decode_true_not_isnull_and_neq(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, (NOT ISNULL(F1) AND (F1 != '')) OR "
            "(NOT ISNULL(F2) AND (F2 != '')), 1, 0)"
        )
        assert "np.where" in r

    def test_decode_true_instr_conditions(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(LTRIM(RTRIM(EMAIL))), NULL, "
            "LTRIM(RTRIM(EMAIL)) = '', NULL, "
            "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), '@') <> 0, NULL, "
            "LTRIM(RTRIM(EMAIL)))"
        )
        assert "np.where" in r

    def test_decode_true_instr_substr(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, INSTR(UPPER(LTRIM(RTRIM(NAME))), 'MR') <> 0, "
            "SUBSTR(LTRIM(RTRIM(NAME)), 1, INSTR(UPPER(LTRIM(RTRIM(NAME))), 'MR') - 1), "
            "LTRIM(RTRIM(NAME)))"
        )
        assert "np.where" in r

    def test_decode_true_upper_eq(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, UPPER(STATUS) = 'Y', 'Yes', UPPER(STATUS) = 'N', 'No', STATUS)"
        )
        assert "np.where" in r

    def test_decode_true_ltrim_numeric_char(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, LTRIM(LTRIM(RTRIM(PHONE)), '0') = '', NULL, "
            "ISNULL(UPPER(LTRIM(RTRIM(PHONE)))), NULL, LTRIM(RTRIM(PHONE)))"
        )
        assert "np.where" in r

    def test_decode_true_with_lkp(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, STATUS = 'A', :TX1.LKP_VALUE_EI('col', 'map'), "
            "STATUS = 'B', :TX1.LKP_VALUE_EI('col2', 'map2'))"
        )
        assert "np.where" in r
        assert "lookup_func" in r

    def test_decode_true_with_in(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, IN(CODE, 'X', 'Y'), :TX1.LKP_VALUE_EI('a', 'b'), "
            "IN(CODE, 'Z', 'W'), :TX1.LKP_VALUE_EI('c', 'd'))"
        )
        assert "np.where" in r
        assert "isin" in r

    def test_decode_true_complex_not_isnull(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, NOT ISNULL(LTRIM(RTRIM(ADDR))) OR "
            "LTRIM(RTRIM(ADDR)) <> '', 'Y', "
            "(ISNULL(LTRIM(RTRIM(ADDR))) OR LTRIM(RTRIM(ADDR)) = '') AND "
            "(NOT ISNULL(LTRIM(RTRIM(CITY))) AND LTRIM(RTRIM(CITY)) <> '' AND "
            "UPPER(LTRIM(RTRIM(CITY))) <> 'NA'), CITY, 'N')"
        )
        assert "np.where" in r


class TestIIFVectorized:
    def test_iif_basic(self):
        r = convert_expression_vectorized("IIF(STATUS = 'A', 'Active', 'Inactive')")
        assert "np.where" in r
        assert "'Active'" in r

    def test_iif_isnull(self):
        r = convert_expression_vectorized("IIF(ISNULL(NAME), 'N/A', NAME)")
        assert "np.where" in r
        assert "isna()" in r

    def test_iif_not_isnull(self):
        r = convert_expression_vectorized("IIF(NOT ISNULL(VAL), VAL, 0)")
        assert "np.where" in r

    def test_iif_2_args(self):
        r = convert_expression_vectorized("IIF(ISNULL(field1), 'yes')")
        assert "np.where" in r
        assert "None" in r

    def test_iif_is_spaces(self):
        r = convert_expression_vectorized("IIF(IS_SPACES(NAME), NULL, LTRIM(RTRIM(NAME)))")
        assert "np.where" in r
        assert "strip" in r

    def test_iif_is_spaces_to_char(self):
        r = convert_expression_vectorized("IIF(IS_SPACES(TO_CHAR(DT)), NULL, LTRIM(RTRIM(TO_CHAR(DT))))")
        assert "np.where" in r
        assert "astype(str)" in r

    def test_iif_is_spaces_to_char_nested(self):
        r = convert_expression_vectorized("IIF(IS_SPACES(TO_CHAR(TO_CHAR(ID))), NULL, LTRIM(RTRIM(TO_CHAR(ID))))")
        assert "np.where" in r

    def test_iif_length_or_is_spaces(self):
        r = convert_expression_vectorized("IIF(LENGTH(NAME) = 0 OR IS_SPACES(NAME) = 1, NULL, LTRIM(RTRIM(NAME)))")
        assert "np.where" in r

    def test_iif_nested_in_decode(self):
        r = convert_expression_vectorized(
            "IIF(FLAG = 1, 0, DECODE(TRUE, ISNULL(A) AND ISNULL(B) AND "
            "ISNULL(C) AND ISNULL(D) AND ISNULL(E) AND ISNULL(F), 0, 1))"
        )
        assert "np.where" in r

    def test_iif_with_ltrim_rtrim(self):
        r = convert_expression_vectorized("IIF(ISNULL(LTRIM(RTRIM(NAME))), NULL, LTRIM(RTRIM(NAME)))")
        assert "np.where" in r
        assert "lstrip" in r

    def test_iif_not_isnull_lkp(self):
        r = convert_expression_vectorized(
            "IIF(NOT ISNULL(:TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP')), 'Y', 'N')"
        )
        assert "np.where" in r
        assert "lookup_func" in r

    def test_iif_gt_comparison(self):
        r = convert_expression_vectorized("IIF(LENGTH(NAME) > 0, LTRIM(RTRIM(NAME)), NULL)")
        assert "np.where" in r
        assert "str.len()" in r

    def test_iif_is_spaces_substr(self):
        r = convert_expression_vectorized(
            "IIF(IS_SPACES(SUBSTR(LTRIM(RTRIM(CODE)), 1, 3)) OR "
            "LENGTH(SUBSTR(LTRIM(RTRIM(CODE)), 1, 3)) = 0, NULL, "
            "(SUBSTR(LTRIM(RTRIM(CODE)), 1, 3)))"
        )
        assert "np.where" in r

    def test_iif_eq_str(self):
        r = convert_expression_vectorized("IIF(TYPE = 'MANUAL', 'M', 'A')")
        assert "np.where" in r

    def test_iif_neq_str(self):
        r = convert_expression_vectorized("IIF(STATUS <> 'D', LTRIM(RTRIM(NAME)), NULL)")
        assert "np.where" in r
        assert "!=" in r

    def test_iif_upper_eq(self):
        r = convert_expression_vectorized("IIF(UPPER(TYPE) = 'YES', 1, 0)")
        assert "np.where" in r
        assert "str.upper()" in r

    def test_iif_lkp_isnull_complex(self):
        r = convert_expression_vectorized(
            "IIF(ISNULL(:TX1.LKP_LKUP_TRANSFORMATION_MAP(TYPE, 'MAP')), "
            "IIF(ISNULL(:TX2.LKP_LKUP_TRANSFORMATION_MAP('DEFAULT', 'MAP')), NULL, "
            ":TX2.LKP_LKUP_TRANSFORMATION_MAP('DEFAULT', 'MAP')), "
            ":TX1.LKP_LKUP_TRANSFORMATION_MAP(TYPE, 'MAP'))"
        )
        assert "np.where" in r
        assert "lookup_func" in r

    def test_iif_reg_extract(self):
        r = convert_expression_vectorized(
            "IIF(ISNULL(REG_EXTRACT(PHONE, '[0-9]+')), PHONE, NULL)"
        )
        assert "np.where" in r
        assert "str.extract" in r

    def test_iif_arithmetic(self):
        r = convert_expression_vectorized("IIF(AMT > 100, AMT * 0.9, AMT)")
        assert "np.where" in r

    def test_iif_nested_iif(self):
        r = convert_expression_vectorized(
            "IIF(A = 1, 'one', IIF(A = 2, 'two', 'other'))"
        )
        assert r.count("np.where") == 2


class TestLtrimRtrimVectorized:
    def test_ltrim_simple(self):
        r = convert_expression_vectorized("LTRIM(NAME)")
        assert "str.lstrip()" in r

    def test_rtrim_simple(self):
        r = convert_expression_vectorized("RTRIM(NAME)")
        assert "str.rstrip()" in r

    def test_ltrim_rtrim_nested(self):
        r = convert_expression_vectorized("LTRIM(RTRIM(NAME))")
        assert "str.rstrip()" in r
        assert "str.lstrip()" in r

    def test_rtrim_ltrim_nested(self):
        r = convert_expression_vectorized("RTRIM(LTRIM(NAME))")
        assert "str.lstrip()" in r
        assert "str.rstrip()" in r

    def test_ltrim_with_char_arg(self):
        r = convert_expression_vectorized("LTRIM(NAME, '0')")
        assert 'lstrip("0")' in r

    def test_rtrim_with_char_arg(self):
        r = convert_expression_vectorized("RTRIM(CODE, ' ')")
        assert "rstrip" in r

    def test_ltrim_rtrim_with_replacechr(self):
        r = convert_expression_vectorized("LTRIM(RTRIM(REPLACECHR(1, NAME, ',', ' ')))")
        assert "str.replace" in r
        assert "lstrip" in r

    def test_ltrim_rtrim_with_replacestr(self):
        r = convert_expression_vectorized("LTRIM(RTRIM(REPLACESTR(1, NAME, 'old', 'new')))")
        assert "str.replace" in r

    def test_ltrim_ltrim_rtrim_with_num(self):
        r = convert_expression_vectorized("LTRIM(LTRIM(RTRIM(PHONE)), '0')")
        assert "lstrip" in r


class TestConcatVectorized:
    def test_pipe_concat_simple(self):
        r = convert_expression_vectorized("FIRST || ' ' || LAST")
        assert "astype(str)" in r
        assert "+" in r

    def test_pipe_concat_with_ltrim_rtrim(self):
        r = convert_expression_vectorized("LTRIM(RTRIM(FIRST)) || ' ' || LTRIM(RTRIM(LAST))")
        assert "astype(str)" in r
        assert "lstrip" in r

    def test_pipe_concat_with_to_char(self):
        r = convert_expression_vectorized("TO_CHAR(ID) || '-' || TO_CHAR(SEQ)")
        assert "astype(str)" in r

    def test_pipe_concat_upper(self):
        r = convert_expression_vectorized("UPPER(FIRST || ' ' || LAST)")
        assert "str.upper()" in r

    def test_concat_func_simple(self):
        r = convert_expression_vectorized("CONCAT(TO_CHAR(ID), '-suffix')")
        assert "astype(str)" in r

    def test_concat_nested(self):
        r = convert_expression_vectorized(
            "CONCAT(CONCAT('prefix-', LTRIM(RTRIM(TO_CHAR(ID)))), CONCAT('-', LTRIM(RTRIM(TO_CHAR(SEQ)))))"
        )
        assert "astype(str)" in r

    def test_concat_triple_nested(self):
        r = convert_expression_vectorized(
            "CONCAT(CONCAT(CONCAT('A', LTRIM(RTRIM(TO_CHAR(B)))), "
            "CONCAT('C', LTRIM(RTRIM(TO_CHAR(D))))), 'E')"
        )
        assert "astype(str)" in r

    def test_concat_to_char_str(self):
        r = convert_expression_vectorized("CONCAT(TO_CHAR(DT), ' EOD')")
        assert "astype(str)" in r

    def test_concat_ltrim_rtrim_to_char(self):
        r = convert_expression_vectorized(
            "CONCAT(LTRIM(RTRIM(TO_CHAR(F1))), CONCAT(' - ', LTRIM(RTRIM(TO_CHAR(F2)))))"
        )
        assert "astype(str)" in r


class TestUpperLowerVectorized:
    def test_upper_simple(self):
        r = convert_expression_vectorized("UPPER(NAME)")
        assert "str.upper()" in r

    def test_lower_simple(self):
        r = convert_expression_vectorized("LOWER(NAME)")
        assert "str.lower()" in r

    def test_upper_ltrim_rtrim(self):
        r = convert_expression_vectorized("UPPER(LTRIM(RTRIM(NAME)))")
        assert "str.upper()" in r
        assert "lstrip" in r

    def test_lower_ltrim_rtrim(self):
        r = convert_expression_vectorized("LOWER(LTRIM(RTRIM(EMAIL)))")
        assert "str.lower()" in r

    def test_upper_concat(self):
        r = convert_expression_vectorized("UPPER(FIRST || ' ' || LAST)")
        assert "str.upper()" in r


class TestSubstrVectorized:
    def test_substr_two_args(self):
        r = convert_expression_vectorized("SUBSTR(NAME, 1)")
        assert "str[0:]" in r

    def test_substr_three_args(self):
        r = convert_expression_vectorized("SUBSTR(NAME, 1, 5)")
        assert "str[0:5]" in r

    def test_substr_with_ltrim_rtrim(self):
        r = convert_expression_vectorized("SUBSTR(LTRIM(RTRIM(CODE)), 1, 3)")
        assert "str[0:3]" in r
        assert "lstrip" in r

    def test_substr_with_to_char(self):
        r = convert_expression_vectorized("SUBSTR(TO_CHAR(DT, 'YYYYMMDD'), 1, 4)")
        assert "str[0:4]" in r


class TestInstrVectorized:
    def test_instr_simple(self):
        r = convert_expression_vectorized("INSTR(NAME, '@')")
        assert "str.find" in r

    def test_instr_in_condition(self):
        r = _vectorize_condition("INSTR(LOWER(LTRIM(RTRIM(EMAIL))), '@') <> 0", "df")
        assert "str.find" in r or "str.lower()" in r


class TestToCharVectorized:
    def test_to_char_no_format(self):
        r = convert_expression_vectorized("TO_CHAR(ID)")
        assert "astype(str)" in r

    def test_to_char_date_format(self):
        r = convert_expression_vectorized("TO_CHAR(DT, 'YYYY-MM-DD')")
        assert "strftime" in r
        assert "%Y-%m-%d" in r

    def test_to_char_nested(self):
        r = convert_expression_vectorized("TO_CHAR(TO_CHAR(ID))")
        assert "astype(str)" in r


class TestToDateVectorized:
    def test_to_date_no_format(self):
        r = convert_expression_vectorized("TO_DATE(DT_STR)")
        assert "pd.to_datetime" in r

    def test_to_date_with_format(self):
        r = convert_expression_vectorized("TO_DATE(DT_STR, 'YYYY-MM-DD')")
        assert "pd.to_datetime" in r
        assert "%Y-%m-%d" in r

    def test_to_date_nested_expr(self):
        r = convert_expression_vectorized("TO_DATE(LTRIM(RTRIM(DT_STR)), 'MM/DD/YYYY')")
        assert "pd.to_datetime" in r


class TestToNumericVectorized:
    def test_to_integer(self):
        r = convert_expression_vectorized("TO_INTEGER(AMT)")
        assert "pd.to_numeric" in r
        assert "astype(int)" in r

    def test_to_bigint(self):
        r = convert_expression_vectorized("TO_BIGINT(BIG_ID)")
        assert "pd.to_numeric" in r
        assert 'Int64' in r

    def test_to_decimal(self):
        r = convert_expression_vectorized("TO_DECIMAL(PRICE)")
        assert "pd.to_numeric" in r

    def test_to_decimal_with_precision(self):
        r = convert_expression_vectorized("TO_DECIMAL(PRICE, 2)")
        assert "pd.to_numeric" in r

    def test_to_integer_ltrim_rtrim(self):
        r = convert_expression_vectorized("TO_INTEGER(LTRIM(RTRIM(CODE)))")
        assert "pd.to_numeric" in r


class TestReplaceChrVectorized:
    def test_replacechr_3_args(self):
        r = convert_expression_vectorized("REPLACECHR(NAME, ',', ' ')")
        assert "str.replace" in r

    def test_replacechr_4_args(self):
        r = convert_expression_vectorized("REPLACECHR(1, NAME, ',', ' ')")
        assert "str.replace" in r

    def test_replacechr_with_chr(self):
        r = convert_expression_vectorized("REPLACECHR(1, NAME, CHR(10), ' ')")
        assert "str.replace" in r

    def test_replacechr_null_replacement(self):
        r = convert_expression_vectorized("REPLACECHR(1, NAME, ',', NULL)")
        assert "str.replace" in r


class TestReplaceStrVectorized:
    def test_replacestr_3_args(self):
        r = convert_expression_vectorized("REPLACESTR(TXT, 'old', 'new')")
        assert "str.replace" in r

    def test_replacestr_4_args(self):
        r = convert_expression_vectorized("REPLACESTR(1, TXT, 'old', 'new')")
        assert "str.replace" in r

    def test_replacestr_nested(self):
        r = convert_expression_vectorized(
            "LTRIM(RTRIM(REPLACESTR(1, NAME, 'prefix', CHR(10) || CHR(13))))"
        )
        assert "str.replace" in r or "lstrip" in r

    def test_replacestr_with_chr_concat(self):
        r = convert_expression_vectorized(
            "REPLACESTR(1, NAME, 'bad', CHR(10) || CHR(13))"
        )
        assert r is not None


class TestRegexVectorized:
    def test_reg_extract(self):
        r = convert_expression_vectorized("REG_EXTRACT(PHONE, '[0-9]+')")
        assert "str.extract" in r

    def test_reg_replace(self):
        r = convert_expression_vectorized("REG_REPLACE(NAME, '[^a-zA-Z]', '')")
        assert "str.replace" in r
        assert "regex=True" in r

    def test_reg_match(self):
        r = convert_expression_vectorized("REG_MATCH(EMAIL, '.*@.*\\.com')")
        assert "str.contains" in r

    def test_reg_extract_in_iif(self):
        r = convert_expression_vectorized(
            "IIF(ISNULL(REG_EXTRACT(TXT, '[0-9]+')), TXT, NULL)"
        )
        assert "np.where" in r
        assert "str.extract" in r

    def test_reverse_reg_extract(self):
        r = convert_expression_vectorized("REVERSE(REG_EXTRACT(NAME, '[A-Z]+'))")
        assert "str[::-1]" in r
        assert "str.extract" in r

    def test_reverse_reg_replace(self):
        r = convert_expression_vectorized("REVERSE(REG_REPLACE(NAME, '[^a-z]', ''))")
        assert "str[::-1]" in r


class TestISSpacesVectorized:
    def test_is_spaces_simple(self):
        r = convert_expression_vectorized("IS_SPACES(NAME)")
        assert 'str.strip().eq("")' in r

    def test_is_spaces_in_iif(self):
        r = convert_expression_vectorized("IIF(IS_SPACES(NAME), NULL, LTRIM(RTRIM(NAME)))")
        assert "np.where" in r
        assert "strip" in r

    def test_is_spaces_in_condition(self):
        r = _vectorize_condition("IS_SPACES(FIELD)", "df")
        assert "strip" in r

    def test_is_spaces_or_isnull(self):
        r = _vectorize_condition("ISNULL(NAME) OR IS_SPACES(NAME) OR NAME = ''", "df")
        assert "isna()" in r or "strip" in r

    def test_is_spaces_eq_num(self):
        r = _vectorize_condition("IS_SPACES(NAME) = 1", "df")
        assert "strip" in r or "eq" in r


class TestISNumberVectorized:
    def test_is_number_simple(self):
        r = convert_expression_vectorized("IS_NUMBER(CODE)")
        assert "pd.to_numeric" in r
        assert "notna()" in r


class TestReverseVectorized:
    def test_reverse_simple(self):
        r = convert_expression_vectorized("REVERSE(NAME)")
        assert "str[::-1]" in r


class TestLpadRpadVectorized:
    def test_lpad(self):
        r = convert_expression_vectorized("LPAD(CODE, 10, '0')")
        assert 'str.pad' in r
        assert 'left' in r

    def test_rpad(self):
        r = convert_expression_vectorized("RPAD(NAME, 20)")
        assert 'str.pad' in r
        assert 'right' in r


class TestTruncVectorized:
    def test_trunc_no_format(self):
        r = convert_expression_vectorized("TRUNC(AMT)")
        assert "np.trunc" in r

    def test_trunc_date_dd(self):
        r = convert_expression_vectorized("TRUNC(DT, 'DD')")
        assert 'dt.floor("D")' in r

    def test_trunc_with_arithmetic(self):
        r = convert_expression_vectorized("TRUNC(PRICE / 100)")
        assert "np.trunc" in r


class TestAddToDateVectorized:
    def test_add_to_date_days(self):
        r = convert_expression_vectorized("ADD_TO_DATE(DT, 'DD', 30)")
        assert "pd.to_timedelta" in r
        assert '"D"' in r

    def test_add_to_date_months(self):
        r = convert_expression_vectorized("ADD_TO_DATE(DT, 'MM', 1)")
        assert "pd.DateOffset(months=" in r

    def test_add_to_date_years(self):
        r = convert_expression_vectorized("ADD_TO_DATE(DT, 'YYYY', 1)")
        assert "pd.DateOffset(years=" in r


class TestDateDiffVectorized:
    def test_date_diff_days(self):
        r = convert_expression_vectorized("DATE_DIFF(END_DT, START_DT, 'DD')")
        assert "dt.days" in r


class TestINVectorized:
    def test_in_simple(self):
        r = convert_expression_vectorized("IN(STATUS, 'A', 'B', 'C')")
        assert "isin" in r

    def test_in_condition(self):
        r = _vectorize_condition("IN(CODE, 'X', 'Y')", "df")
        assert "isin" in r


class TestLookupVectorized:
    def test_lkp_colon_syntax(self):
        r = convert_expression_vectorized(":TX1.LKP_VALUE_EI('col', 'map')")
        assert "lookup_func" in r

    def test_lkp_with_ltrim_rtrim_arg(self):
        r = convert_expression_vectorized(":TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP')")
        assert "lookup_func" in r
        assert "lstrip" in r

    def test_lkp_id_arg(self):
        r = convert_expression_vectorized(":TX1.LKP_LKUP_TRANSFORMATION_MAP(CODE, 'MAP')")
        assert "lookup_func" in r

    def test_lkp_str_args(self):
        r = convert_expression_vectorized(":TX1.LKP_LKUP_TRANSFORMATION_MAP('key', 'map')")
        assert "lookup_func" in r

    def test_lkp_single_str_arg(self):
        r = convert_expression_vectorized(":TX1.LKP_CLO_ACCT_POS_LST_UPD_DT('col')")
        assert "lookup_func" in r

    def test_lkp_single_id_arg(self):
        r = convert_expression_vectorized(":TX1.SP_SWAP_PARTY_ID_AFTER_MATCH_INV(PARTY_ID)")
        assert "lookup_func" in r

    def test_lkptrans(self):
        r = convert_expression_vectorized(":TX1.LKPTRANS('key', 'val')")
        assert "lookup_func" in r


class TestLookupInConditions:
    def test_lkp_in_iif_condition(self):
        r = convert_expression_vectorized("IIF(:TX1.LKP_F(A, 'x') = 'Y', 1, 0)")
        assert "lookup_func" in r
        assert "np.where" in r
        assert ":TX1" not in r

    def test_lkp_in_decode_condition(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, :TX1.LKP_VAL(CODE, 'MAP') = 'A', 'found', 'missing')"
        )
        assert "lookup_func" in r
        assert "np.where" in r
        assert ":TX1" not in r

    def test_lkp_isnull_in_condition(self):
        r = _vectorize_condition("NOT ISNULL(:TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP'))", "df")
        assert "lookup_func" in r
        assert ":TX1" not in r


class TestSysdateVectorized:
    def test_sysdate_bare(self):
        r = convert_expression_vectorized("SYSDATE")
        assert "pd.Timestamp.now()" in r

    def test_systimestamp_bare(self):
        r = convert_expression_vectorized("SYSTIMESTAMP")
        assert "pd.Timestamp.now()" in r

    def test_systimestamp_parens(self):
        r = convert_expression_vectorized("SYSTIMESTAMP()")
        assert "pd.Timestamp.now()" in r


class TestCommentStripping:
    def test_strip_double_dash(self):
        r = convert_expression_vectorized("LTRIM(RTRIM(NAME)) -- old code")
        assert "lstrip" in r
        assert "old code" not in r

    def test_strip_double_dash_complex(self):
        r = convert_expression_vectorized(
            "IIF(LENGTH(NAME) = 0 OR IS_SPACES(NAME) = 1, NULL, LTRIM(RTRIM(NAME))) "
            "-- LTRIM(RTRIM(IIF(ISNULL(REG_EXTRACT(NAME, '[0-9]+')), NAME, NULL)))"
        )
        assert "np.where" in r
        assert "REG_EXTRACT" not in r

    def test_strip_inline_comments_func(self):
        r = _strip_inline_comments("LTRIM(RTRIM(X)) -- comment here")
        assert r == "LTRIM(RTRIM(X))"

    def test_no_comment(self):
        r = _strip_inline_comments("LTRIM(RTRIM(X))")
        assert r == "LTRIM(RTRIM(X))"


class TestNVLVectorized:
    def test_nvl_simple(self):
        r = convert_expression_vectorized("NVL(NAME, 'default')")
        assert "fillna" in r
        assert "'default'" in r


class TestMakeDateTimeVectorized:
    def test_make_date_time_ints(self):
        r = convert_expression_vectorized("MAKE_DATE_TIME(2025, 1, 15, 10, 30, 0)")
        assert "pd.Timestamp(2025, 1, 15, 10, 30, 0)" in r


class TestCHRVectorized:
    def test_chr_literal(self):
        r = convert_expression_vectorized("CHR(10)")
        assert r == "'\\n'"

    def test_chr_space(self):
        r = convert_expression_vectorized("CHR(32)")
        assert r == "' '"


class TestMaxFirstVectorized:
    def test_max_fallback(self):
        r = convert_expression_vectorized("MAX(AMT)")
        assert "max_val" in r

    def test_first_fallback(self):
        r = convert_expression_vectorized("FIRST(NAME)")
        assert "first_val" in r


class TestFieldSubstitution:
    def test_simple_field(self):
        r = convert_expression_vectorized("FIELD_NAME")
        assert r == 'df["FIELD_NAME"]'

    def test_null_literal(self):
        r = convert_expression_vectorized("NULL")
        assert r == "None"

    def test_true_literal(self):
        r = convert_expression_vectorized("TRUE")
        assert r == "True"

    def test_false_literal(self):
        r = convert_expression_vectorized("FALSE")
        assert r == "False"

    def test_number_literal(self):
        r = convert_expression_vectorized("42")
        assert r == "42"

    def test_string_literal(self):
        r = convert_expression_vectorized("'hello'")
        assert r == "'hello'"

    def test_variable(self):
        r = convert_expression_vectorized("$$MY_VAR")
        assert r == 'get_variable("MY_VAR")'


class TestComplexPatterns:
    def test_iif_with_lkp_nested(self):
        r = convert_expression_vectorized(
            "IIF(ISNULL(:TX1.LKP_LKUP_TRANSFORMATION_MAP(FIELD, 'MAP')), "
            "IIF(ISNULL(:TX2.LKP_LKUP_TRANSFORMATION_MAP('DEF', 'MAP')), NULL, "
            ":TX2.LKP_LKUP_TRANSFORMATION_MAP('DEF', 'MAP')), "
            ":TX1.LKP_LKUP_TRANSFORMATION_MAP(FIELD, 'MAP'))"
        )
        assert r.count("np.where") == 2
        assert "lookup_func" in r

    def test_decode_true_is_spaces_or_chains(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, UPPER(TYPE) = 'Y', 'Yes', "
            "UPPER(TYPE) = 'N', 'No', "
            "TYPE = '' OR ISNULL(TYPE) OR IS_SPACES(TYPE), 'Unknown', TYPE)"
        )
        assert r.count("np.where") >= 3

    def test_pipe_concat_with_to_char_ltrim_rtrim(self):
        r = convert_expression_vectorized(
            "LTRIM(RTRIM(TO_CHAR(ID))) || '-' || LTRIM(RTRIM(TO_CHAR(SEQ)))"
        )
        assert "astype(str)" in r
        assert "lstrip" in r

    def test_replacestr_chr_concat(self):
        r = convert_expression_vectorized(
            "LTRIM(RTRIM(REPLACESTR(1, NAME, 'bad', CHR(10) || CHR(13))))"
        )
        assert r is not None
        assert "lstrip" in r or "replace" in r

    def test_comment_with_nested_lkp(self):
        r = convert_expression_vectorized(
            "-- IIF(FLAG = 'Y', :TX1.SP_LKP_LOAD(ID, NAME), NULL)"
        )
        assert r == "None"

    def test_multiple_comments(self):
        r = convert_expression_vectorized(
            "IIF(A = 'X', -- :TX.SP(A, B, 'x', C, 'y', 'z'), NULL)"
        )
        assert "np.where" in r or r == "None"

    def test_deep_nesting(self):
        r = convert_expression_vectorized(
            "UPPER(LTRIM(RTRIM(SUBSTR(REPLACECHR(1, NAME, ',', ' '), 1, 50))))"
        )
        assert "str.upper()" in r

    def test_isnull_with_nested_ltrim_rtrim(self):
        r = convert_expression_vectorized("ISNULL(LTRIM(RTRIM(NAME)))")
        assert "isna()" in r
        assert "lstrip" in r

    def test_not_isnull_with_nested(self):
        r = _vectorize_condition("NOT ISNULL(LTRIM(RTRIM(FIELD)))", "df")
        assert "~" in r or "not" in r.lower()

    def test_arithmetic_expression(self):
        r = convert_expression_vectorized("AMOUNT * 1.10")
        assert r is not None

    def test_full_decode_email_validation(self):
        r = convert_expression_vectorized(
            "DECODE(TRUE, ISNULL(LTRIM(RTRIM(EMAIL))), NULL, "
            "LTRIM(RTRIM(EMAIL)) = '', NULL, "
            "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), 'test') <> 0, NULL, "
            "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), 'fake') <> 0, NULL, "
            "LTRIM(RTRIM(EMAIL)))"
        )
        assert r.count("np.where") >= 4


class TestBulkPatternNoExceptions:
    PATTERNS = [
        "__ID__",
        "__NUM__",
        "'string_literal'",
        "NULL",
        "TRUE",
        "SYSDATE",
        "SYSTIMESTAMP",
        "UPPER(NAME)",
        "LOWER(EMAIL)",
        "LTRIM(NAME)",
        "RTRIM(NAME)",
        "LTRIM(RTRIM(NAME))",
        "RTRIM(LTRIM(NAME))",
        "UPPER(LTRIM(RTRIM(NAME)))",
        "LOWER(LTRIM(RTRIM(NAME)))",
        "LENGTH(NAME)",
        "LENGTH(LTRIM(RTRIM(NAME)))",
        "SUBSTR(NAME, 1, 10)",
        "SUBSTR(LTRIM(RTRIM(NAME)), 1, 5)",
        "INSTR(NAME, '@')",
        "INSTR(LOWER(LTRIM(RTRIM(NAME))), 'test')",
        "TO_CHAR(DT)",
        "TO_CHAR(DT, 'YYYY-MM-DD')",
        "TO_DATE(STR)",
        "TO_DATE(STR, 'MM/DD/YYYY')",
        "TO_INTEGER(VAL)",
        "TO_BIGINT(ID)",
        "TO_DECIMAL(AMT)",
        "TO_DECIMAL(AMT, 2)",
        "REPLACECHR(1, NAME, ',', ' ')",
        "REPLACECHR(NAME, CHR(10), ' ')",
        "REPLACESTR(1, NAME, 'old', 'new')",
        "REG_EXTRACT(PHONE, '[0-9]+')",
        "REG_REPLACE(NAME, '[^a-zA-Z]', '')",
        "REG_MATCH(EMAIL, '.*@.*')",
        "REVERSE(NAME)",
        "REVERSE(REG_EXTRACT(CODE, '[A-Z]+'))",
        "REVERSE(REG_REPLACE(NAME, '[^a-z]', ''))",
        "IS_SPACES(NAME)",
        "IS_NUMBER(CODE)",
        "CHR(10)",
        "CHR(32)",
        "LPAD(CODE, 10, '0')",
        "RPAD(NAME, 20)",
        "TRUNC(AMT)",
        "NVL(NAME, 'default')",
        "ISNULL(NAME)",
        "CONCAT(A, B)",
        "CONCAT(TO_CHAR(ID), '-suffix')",
        "A || ' ' || B",
        "TO_CHAR(DT) || '-' || TO_CHAR(SEQ)",
        "UPPER(A || B)",
        "IIF(A = 1, 'yes', 'no')",
        "IIF(ISNULL(A), 'null', A)",
        "IIF(NOT ISNULL(A), A, 0)",
        "IIF(IS_SPACES(NAME), NULL, LTRIM(RTRIM(NAME)))",
        "IIF(A = 'X', IIF(B = 'Y', 1, 2), 3)",
        "DECODE(TRUE, ISNULL(A), NULL, A)",
        "DECODE(TRUE, ISNULL(A), 0, A)",
        "DECODE(TRUE, ISNULL(A), 'unknown', A)",
        "DECODE(A, 1, 'one', 2, 'two', 3, 'three')",
        "DECODE(A, 1, 'one', 2, 'two', 'other')",
        "DECODE(TRUE, A = 'X', 'yes', 'no')",
        "DECODE(TRUE, ISNULL(A) OR IS_SPACES(A) OR A = '', NULL, LTRIM(RTRIM(A)))",
        "DECODE(TRUE, NOT ISNULL(A), A, 'default')",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(A))) <= 10, LTRIM(RTRIM(A)), SUBSTR(LTRIM(RTRIM(A)), 1, 10), NULL)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(A))) = 10, LTRIM(RTRIM(A)), NULL)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(A))) > 0, A, NULL)",
        "MAKE_DATE_TIME(2025, 1, 15, 10, 30, 0)",
        "ADD_TO_DATE(DT, 'DD', 30)",
        "DATE_DIFF(END_DT, START_DT, 'DD')",
        "IN(STATUS, 'A', 'B', 'C')",
        "MAX(AMT)",
        "FIRST(NAME)",
        ":TX1.LKP_VALUE_EI('col', 'map')",
        ":TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP')",
        ":TX1.LKP_LKUP_TRANSFORMATION_MAP(CODE, 'MAP')",
        ":TX1.LKP_LKUP_TRANSFORMATION_MAP('key', 'map')",
        "$$MY_VAR",
        "LTRIM(RTRIM(NAME)) -- comment here",
        "UPPER(LTRIM(RTRIM(SUBSTR(REPLACECHR(1, NAME, ',', ' '), 1, 50))))",
        "IIF(ISNULL(LTRIM(RTRIM(NAME))), NULL, LTRIM(RTRIM(NAME)))",
        "IIF(LENGTH(NAME) > 0, LTRIM(RTRIM(NAME)), NULL)",
        "DECODE(TRUE, ISNULL(LTRIM(RTRIM(EMAIL))) OR EMAIL = '' OR IS_SPACES(EMAIL), NULL, LTRIM(RTRIM(EMAIL)))",
        "CONCAT(CONCAT('A', LTRIM(RTRIM(TO_CHAR(B)))), CONCAT('C', LTRIM(RTRIM(TO_CHAR(D)))))",
        "IIF(ISNULL(:TX1.LKP_VALUE_EI('c', 'm')), NULL, :TX1.LKP_VALUE_EI('c', 'm'))",
        "DECODE(TRUE, IN(CODE, 'X', 'Y'), :TX1.LKP_VALUE_EI('a', 'b'), IN(CODE, 'Z', 'W'), :TX1.LKP_VALUE_EI('c', 'd'))",
    ]

    @pytest.mark.parametrize("expr", PATTERNS)
    def test_pattern_no_exception(self, expr):
        result = convert_expression_vectorized(expr)
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.parametrize("expr", PATTERNS)
    def test_pattern_row_convert_no_exception(self, expr):
        result = convert_expression(expr)
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0


class TestRealWorldPatterns:
    REAL_PATTERNS = [
        "DECODE(TRUE, ISNULL(LTRIM(RTRIM(ADDR1))), NULL, LTRIM(RTRIM(ADDR1)) = '', NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(ADDR1))), 'test') <> 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(ADDR1))), 'bad') <> 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(ADDR1))), 'fake') <> 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(ADDR1))), 'invalid') <> 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(ADDR1))), 'none') <> 0, NULL, "
        "LTRIM(RTRIM(ADDR1))",
        "DECODE(TRUE, ISNULL(LTRIM(RTRIM(EMAIL))), NULL, LTRIM(RTRIM(EMAIL)) = '', NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), 'test') = 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), '@') = 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), '.com') <> 0, NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(EMAIL))), '.net') <> 0, NULL, LTRIM(RTRIM(EMAIL))",
        "DECODE(TRUE, INSTR(UPPER(LTRIM(RTRIM(TITLE))), 'MR') <> 0, "
        "SUBSTR(LTRIM(RTRIM(TITLE)), 1, INSTR(UPPER(LTRIM(RTRIM(TITLE))), 'MR') - 1), "
        "LTRIM(RTRIM(TITLE))",
        "DECODE(TRUE, LTRIM(LTRIM(RTRIM(PHONE)), '0') = '', NULL, "
        "ISNULL(UPPER(LTRIM(RTRIM(PHONE)))), NULL, LTRIM(RTRIM(PHONE)))",
        "DECODE(TRUE, NOT ISNULL(LTRIM(RTRIM(PREF))) OR LTRIM(RTRIM(PREF)) <> '', 'Y', "
        "(ISNULL(LTRIM(RTRIM(PREF))) OR LTRIM(RTRIM(PREF)) = '') AND "
        "(NOT ISNULL(LTRIM(RTRIM(ALT))) AND LTRIM(RTRIM(ALT)) <> '' AND "
        "UPPER(LTRIM(RTRIM(ALT))) <> 'NA'), ALT, 'N')",
        "DECODE(TRUE, ISNULL(A) AND ISNULL(B) AND ISNULL(C) AND ISNULL(D) AND "
        "ISNULL(E) AND ISNULL(F) AND ISNULL(G) AND ISNULL(H) AND "
        "ISNULL(I) AND ISNULL(J) AND ISNULL(K) AND ISNULL(L), 0, 1)",
        "IIF(IS_SPACES(SUBSTR(LTRIM(RTRIM(ZIP)), 1, 5)) OR "
        "LENGTH(SUBSTR(LTRIM(RTRIM(ZIP)), 1, 5)) = 0, NULL, "
        "(SUBSTR(LTRIM(RTRIM(ZIP)), 1, 5)))",
        "DECODE(TRUE, NOT (ISNULL(F1) OR IS_SPACES(F1) OR F1 = '') , F1, "
        "NOT (ISNULL(F2) OR IS_SPACES(F2) OR F2 = '') , F2, NULL)",
        "IIF(LENGTH(PHONE) = 0 OR IS_SPACES(PHONE) = 1, NULL, LTRIM(RTRIM(PHONE))) "
        "-- LTRIM(RTRIM(IIF(ISNULL(REG_EXTRACT(PHONE, '[0-9]+')), PHONE, NULL)))",
        "IIF(LENGTH(PHONE) = 0 OR IS_SPACES(PHONE) = 1, NULL, LTRIM(RTRIM(PHONE))) "
        "-- IIF(ISNULL(REG_EXTRACT(PHONE, '[0-9]+')), PHONE, NULL)",
        "DECODE(TRUE, UPPER(TYPE) = 'IND', 'Individual', "
        "UPPER(TYPE) = 'ORG', 'Organization', "
        "TYPE = '' OR ISNULL(TYPE) OR IS_SPACES(TYPE), 'Unknown', TYPE)",
        "CONCAT(CONCAT(CONCAT('P-', LTRIM(RTRIM(TO_CHAR(PARTY_ID)))), "
        "CONCAT('-', LTRIM(RTRIM(TO_CHAR(SEQ_NO))))), '-END')",
    ]

    @pytest.mark.parametrize("expr", REAL_PATTERNS)
    def test_real_pattern_no_exception(self, expr):
        result = convert_expression_vectorized(expr)
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.parametrize("expr", REAL_PATTERNS)
    def test_real_pattern_convert_no_exception(self, expr):
        result = convert_expression(expr)
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0


class TestNormalizedPatternsCoverage:
    NORMALIZED = [
        "FIELD_NAME",
        "42",
        "'hello'",
        "NULL",
        "SYSDATE",
        "SYSTIMESTAMP",
        "UPPER(LTRIM(RTRIM(FIELD_NAME)))",
        "LTRIM(RTRIM(TO_CHAR(FIELD_NAME)))",
        "LTRIM(RTRIM(FIELD_NAME))",
        "LTRIM(RTRIM(REPLACECHR(1, FIELD_NAME, ',', ' ')))",
        "UPPER(LTRIM(RTRIM(SUBSTR(REPLACECHR(1, FIELD_NAME, ',', ' '), 1, 50))))",
        "LTRIM(RTRIM(REPLACESTR(1, FIELD_NAME, 'old', 'new')))",
        "SUBSTR(LTRIM(RTRIM(FIELD_NAME)), 1, 10)",
        "SUBSTR(LTRIM(RTRIM(TO_CHAR(DT_FIELD))), 1, 4)",
        "TO_CHAR(DT_FIELD)",
        "TO_CHAR(DT_FIELD, 'YYYYMMDD')",
        "TO_DATE(STR_FIELD, 'MM/DD/YYYY')",
        "TO_DATE(LTRIM(RTRIM(STR_FIELD)), 'YYYY-MM-DD HH24:MI:SS')",
        "TO_INTEGER(LTRIM(RTRIM(NUM_FIELD)))",
        "TO_INTEGER(FIELD_NAME)",
        "TO_BIGINT(FIELD_NAME)",
        "TO_DECIMAL(FIELD_NAME)",
        "TO_DECIMAL(FIELD_NAME, 2)",
        "IIF(ISNULL(FLD), NULL, LTRIM(RTRIM(FLD)))",
        "IIF(ISNULL(LTRIM(RTRIM(FLD))), NULL, LTRIM(RTRIM(FLD)))",
        "IIF(NOT ISNULL(:TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP')), 'Y', 'N')",
        "IIF(ISNULL(:TX1.LKP_LKUP_TRANSFORMATION_MAP(FLD, 'MAP')), "
        "IIF(ISNULL(:TX2.LKP_LKUP_TRANSFORMATION_MAP('DEF', 'MAP')), NULL, "
        ":TX2.LKP_LKUP_TRANSFORMATION_MAP('DEF', 'MAP')), "
        ":TX1.LKP_LKUP_TRANSFORMATION_MAP(FLD, 'MAP'))",
        "IIF(IS_SPACES(FLD), NULL, LTRIM(RTRIM(FLD)))",
        "IIF(IS_SPACES(TO_CHAR(FLD)), NULL, LTRIM(RTRIM(TO_CHAR(FLD))))",
        "IIF(LENGTH(FLD) = 0 OR IS_SPACES(FLD) = 1, NULL, LTRIM(RTRIM(FLD)))",
        "IIF(IS_SPACES(SUBSTR(LTRIM(RTRIM(FLD)), 1, 3)) OR "
        "LENGTH(SUBSTR(LTRIM(RTRIM(FLD)), 1, 3)) = 0, NULL, "
        "(SUBSTR(LTRIM(RTRIM(FLD)), 1, 3)))",
        "IIF(ISNULL(REG_EXTRACT(PHONE, '[0-9]+')), PHONE, NULL)",
        "IIF(FLD = 'Y', 'Yes', 'No')",
        "IIF(FLD <> 'D', LTRIM(RTRIM(FLD)), NULL)",
        "IIF(LENGTH(FLD) > 0, LTRIM(RTRIM(FLD)), NULL)",
        "IIF(UPPER(TYPE) = 'YES', 1, 0)",
        "IIF(FLD1 = 1, 0, DECODE(TRUE, ISNULL(A) AND ISNULL(B) AND ISNULL(C) AND "
        "ISNULL(D) AND ISNULL(E) AND ISNULL(F), 0, 1))",
        "DECODE(TRUE, ISNULL(FLD), NULL, FLD)",
        "DECODE(TRUE, ISNULL(FLD), 0, FLD)",
        "DECODE(TRUE, ISNULL(FLD), 'unknown', FLD)",
        "DECODE(TRUE, NOT ISNULL(FLD), FLD, 'default')",
        "DECODE(TRUE, ISNULL(FLD) OR IS_SPACES(FLD) OR FLD = '', NULL, LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, FLD = '' OR IS_SPACES(FLD) OR ISNULL(FLD), NULL, LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, ISNULL(LTRIM(RTRIM(FLD))) OR FLD = '' OR IS_SPACES(FLD), NULL, LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, ISNULL(FLD), NULL, LTRIM(RTRIM(FLD)) = '', NULL, IS_SPACES(FLD), NULL, FLD)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(FLD))) <= 10, LTRIM(RTRIM(FLD)), "
        "LENGTH(LTRIM(RTRIM(FLD))) > 10, SUBSTR(LTRIM(RTRIM(FLD)), 1, 10), NULL)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(FLD))) = 10, LTRIM(RTRIM(FLD)), NULL)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(FLD))) > 0, LTRIM(RTRIM(FLD)), NULL)",
        "DECODE(TRUE, LENGTH(LTRIM(RTRIM(FLD))) > 0, SUBSTR(LTRIM(RTRIM(FLD)), 1, LENGTH(LTRIM(RTRIM(FLD)))), NULL)",
        "DECODE(TRUE, ISNULL(LTRIM(RTRIM(FLD))), NULL, LTRIM(RTRIM(FLD)) = '', NULL, "
        "INSTR(LOWER(LTRIM(RTRIM(FLD))), 'bad') <> 0, NULL, LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, INSTR(UPPER(LTRIM(RTRIM(FLD))), 'MR') <> 0, "
        "SUBSTR(LTRIM(RTRIM(FLD)), 1, INSTR(UPPER(LTRIM(RTRIM(FLD))), 'MR') - 1), LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, LTRIM(LTRIM(RTRIM(FLD)), '0') = '', NULL, "
        "ISNULL(UPPER(LTRIM(RTRIM(FLD)))), NULL, LTRIM(RTRIM(FLD)))",
        "DECODE(TRUE, NOT (ISNULL(F1) OR IS_SPACES(F1) OR F1 = ''), F1, "
        "NOT (ISNULL(F2) OR IS_SPACES(F2) OR F2 = ''), F2, NULL)",
        "DECODE(TRUE, NOT ISNULL(LTRIM(RTRIM(PREF))) OR LTRIM(RTRIM(PREF)) <> '', 'Y', "
        "(ISNULL(LTRIM(RTRIM(PREF))) OR LTRIM(RTRIM(PREF)) = '') AND "
        "(NOT ISNULL(LTRIM(RTRIM(ALT))) AND LTRIM(RTRIM(ALT)) <> '' AND "
        "UPPER(LTRIM(RTRIM(ALT))) <> 'NA'), ALT, 'N')",
        "DECODE(TRUE, ISNULL(A) AND ISNULL(B) AND ISNULL(C) AND ISNULL(D) AND "
        "ISNULL(E) AND ISNULL(F) AND ISNULL(G) AND ISNULL(H) AND "
        "ISNULL(I) AND ISNULL(J) AND ISNULL(K) AND ISNULL(L), 0, 1)",
        "DECODE(TRUE, (NOT ISNULL(A) AND (A != '')) OR "
        "(NOT ISNULL(B) AND (B != '')) OR "
        "(NOT ISNULL(C) AND (C != '')), 1, 0)",
        "DECODE(TRUE, (NOT ISNULL(X) OR NOT ISNULL(Y)) AND "
        "(NOT ISNULL(Z) OR NOT ISNULL(W)), 1, 0)",
        "DECODE(TRUE, UPPER(TYPE) = 'IND', 'Individual', "
        "UPPER(TYPE) = 'ORG', 'Organization', TYPE)",
        "DECODE(TRUE, UPPER(TYPE) = 'IND', 'Individual', "
        "UPPER(TYPE) = 'ORG', 'Organization', "
        "TYPE = '' OR ISNULL(TYPE) OR IS_SPACES(TYPE), 'Unknown', TYPE)",
        "DECODE(TRUE, FLD = 'A', :TX1.LKP_VALUE_EI('c1', 'm1'), "
        "FLD = 'B', :TX1.LKP_VALUE_EI('c2', 'm2'), "
        "FLD = 'C', :TX1.LKP_VALUE_EI('c3', 'm3'))",
        "DECODE(TRUE, IN(FLD, 'X', 'Y'), :TX1.LKP_VALUE_EI('a', 'b'), "
        "IN(FLD, 'Z', 'W'), :TX1.LKP_VALUE_EI('c', 'd'))",
        "DECODE(FLD, 1, CONCAT(NAME, ' Sr'), 2, CONCAT(NAME, ' Jr'))",
        "DECODE(FLD, 1, 'one', 2, 'two', 3, 'three')",
        "DECODE(FLD, 1, 'one', 2, 'two', 3, 'three', 4, 'four', 5, 'five', "
        "6, 'six', 7, 'seven', 8, 'eight', 9, 'nine', 10, 'ten', "
        "11, 'eleven', 12, 'twelve', 13, 'thirteen', 14, 'fourteen', 15, 'fifteen')",
        "CONCAT(CONCAT(CONCAT('P-', LTRIM(RTRIM(TO_CHAR(F1)))), "
        "CONCAT('-', LTRIM(RTRIM(TO_CHAR(F2))))), '-END')",
        "CONCAT(CONCAT('A-', LTRIM(RTRIM(TO_CHAR(F1)))), "
        "CONCAT('-', LTRIM(RTRIM(TO_CHAR(F2)))))",
        "CONCAT(LTRIM(RTRIM(TO_CHAR(F1))), CONCAT('-', LTRIM(RTRIM(TO_CHAR(F2)))))",
        "CONCAT(TO_CHAR(DT), '-END')",
        "LTRIM(RTRIM(TO_CHAR(DT))) || '-' || LTRIM(RTRIM(TO_CHAR(SEQ)))",
        "UPPER(LTRIM(RTRIM(FIRST)) || ' ' || LTRIM(RTRIM(LAST)))",
        ":TX1.LKP_VALUE_EI('col', 'map')",
        ":TX1.LKP_VALUE_TA('col', 'map')",
        ":TX1.LKP_VALUE_TRAC('col', 'map')",
        ":TX1.LKP_VALUE_TRAC(FLD, 'map')",
        ":TX1.LKP_LKUP_TRANSFORMATION_MAP(FLD, 'MAP')",
        ":TX1.LKP_LKUP_TRANSFORMATION_MAP('key', 'MAP')",
        ":TX1.LKP_CONTACT(LTRIM(RTRIM(ID)), 'MAP')",
        ":TX1.LKP_CLO_ACCT_POS_LST_UPD_DT('col')",
        ":TX1.LKP_DST_ELECTRONIC_CONSENT_LST_UPD_DT('col')",
        ":TX1.LKP_DST_TA_CUSTOMER_LEGAL_OWNER_LST_UPD_DT('col')",
        ":TX1.LKP_DST_TRAC_CUST_REG_LST_UPD_DT('col')",
        ":TX1.LKP_DST_TRAC_PLAN_SPONSOR('col')",
        ":TX1.LKP_DST_TRAC_STANDARD_PLAN('col')",
        ":TX1.LKPTRANS('key', 'val')",
        ":TX1.SP_SWAP_PARTY_ID_AFTER_MATCH_INV(FLD)",
        "REG_EXTRACT(FLD, '[0-9]+')",
        "REG_REPLACE(FLD, '[^a-zA-Z]', '')",
        "REG_MATCH(FLD, '.*@.*')",
        "REVERSE(REG_EXTRACT(FLD, '[A-Z]+'))",
        "REVERSE(REG_REPLACE(FLD, '[^a-z]', ''))",
        "$$MY_VARIABLE",
        "TRUNC(AMT / 100) * 100",
        "MAX(AMT)",
        "FIRST(NAME)",
    ]

    @pytest.mark.parametrize("expr", NORMALIZED)
    def test_normalized_no_exception(self, expr):
        result = convert_expression_vectorized(expr)
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
