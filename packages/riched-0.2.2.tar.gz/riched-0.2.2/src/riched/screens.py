from __future__ import annotations

from heapq import nsmallest
from pathlib import Path

from textual import events
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, OptionList, Static
from textual.widgets.option_list import Option

from .keybindings import binding_help_groups, build_screen_bindings
from .quick_open import QuickOpenEntry

MAX_QUICK_OPEN_RESULTS = 100


class UnsavedChangesScreen(ModalScreen[str]):
    """Prompt asking whether to save, discard, or cancel."""

    BINDINGS = build_screen_bindings("unsaved_changes")

    CSS = """
    UnsavedChangesScreen {
        align: center middle;
    }
    UnsavedChangesScreen > #dialog {
        width: 64;
        height: auto;
        padding: 1 2;
        background: $panel;
        border: tall $accent;
    }
    UnsavedChangesScreen Label {
        width: 100%;
        content-align: center middle;
        padding-bottom: 1;
    }
    UnsavedChangesScreen #buttons {
        height: auto;
        align: center middle;
    }
    UnsavedChangesScreen Button {
        margin: 0 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label("Unsaved changes.\nSave before continuing?")
            with Horizontal(id="buttons"):
                yield Button("Save", variant="primary", id="save")
                yield Button("Discard", variant="error", id="discard")
                yield Button("Cancel", id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id or "cancel")

    def on_key(self, event: events.Key) -> None:
        focused = self.focused
        if event.key == "space" and isinstance(focused, Button):
            event.stop()
            event.prevent_default()
            focused.action_press()

    def action_cancel(self) -> None:
        self.dismiss("cancel")


class QuickOpenScreen(ModalScreen[Path | None]):
    """Fuzzy file picker."""

    BINDINGS = build_screen_bindings("quick_open")

    CSS = """
    QuickOpenScreen {
        align: center top;
    }
    QuickOpenScreen > #dialog {
        offset-y: 2;
        width: 76;
        height: auto;
        max-height: 24;
        padding: 1 2;
        background: $panel;
        border: tall $accent;
    }
    QuickOpenScreen #query {
        margin-bottom: 1;
    }
    QuickOpenScreen #results {
        height: auto;
        max-height: 18;
    }
    """

    def __init__(
        self,
        root: Path,
        entries: list[QuickOpenEntry],
        *,
        indexing: bool,
        limited: bool,
    ) -> None:
        super().__init__()
        self.root = root
        self.entries = list(entries)
        self._indexing = indexing
        self._limited = limited
        self._error: str | None = None
        self._option_paths: dict[str, Path] = {}
        self._query = ""

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Input(placeholder="Quick open", id="query")
            yield Static("", id="status")
            yield OptionList(id="results")

    def on_mount(self) -> None:
        self._refresh_results("")
        self.query_one("#query", Input).focus()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "query":
            self._refresh_results(event.value)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "query":
            self._open_highlighted()

    def on_option_list_option_selected(
        self, event: OptionList.OptionSelected
    ) -> None:
        path = self._option_paths.get(event.option.id or "")
        if path is not None:
            self.dismiss(path)

    def on_key(self, event: events.Key) -> None:
        results = self.query_one("#results", OptionList)
        if event.key == "up":
            event.stop()
            event.prevent_default()
            results.action_cursor_up()
        elif event.key == "down":
            event.stop()
            event.prevent_default()
            results.action_cursor_down()
        elif event.key == "enter":
            event.stop()
            event.prevent_default()
            self._open_highlighted()

    def action_close(self) -> None:
        self.dismiss(None)

    def append_entries(
        self,
        entries: list[QuickOpenEntry],
        *,
        complete: bool = False,
        limited: bool = False,
    ) -> None:
        self.entries.extend(entries)
        if complete:
            self._indexing = False
        if limited:
            self._limited = True
        self._refresh_results(self._query)

    def replace_entries(
        self,
        entries: list[QuickOpenEntry],
        *,
        complete: bool,
        limited: bool,
    ) -> None:
        self.entries = list(entries)
        self._indexing = not complete
        self._limited = limited
        self._refresh_results(self._query)

    def finish_indexing(self, *, limited: bool) -> None:
        self._indexing = False
        self._limited = limited
        self._refresh_results(self._query)

    def fail_indexing(self, message: str) -> None:
        self._indexing = False
        self._error = message
        self._refresh_results(self._query)

    def _refresh_results(self, query: str) -> None:
        self._query = query
        self._refresh_status()
        results = self.query_one("#results", OptionList)
        results.clear_options()
        self._option_paths.clear()

        matches = self._ranked_matches(query)
        if not matches:
            results.add_option(Option("No matches", id="no-matches", disabled=True))
            return

        options: list[Option] = []
        for index, entry in enumerate(matches[:MAX_QUICK_OPEN_RESULTS]):
            option_id = str(index)
            self._option_paths[option_id] = entry.path
            options.append(Option(entry.relative_path, id=option_id))
        results.add_options(options)
        results.highlighted = 0

    def _refresh_status(self) -> None:
        status = self.query_one("#status", Static)
        if self._error is not None:
            status.update(f"Indexing failed: {self._error}")
        elif self._limited:
            status.update(
                f"Showing first {len(self.entries)} files; index limit reached."
            )
        elif self._indexing:
            status.update(f"Indexing {len(self.entries)} files...")
        else:
            status.update("")

    def _ranked_matches(self, query: str) -> list[QuickOpenEntry]:
        stripped_query = query.strip()
        if not stripped_query:
            return self.entries[:MAX_QUICK_OPEN_RESULTS]

        scored: list[tuple[tuple[int, int, int, int, str], QuickOpenEntry]] = []
        for entry in self.entries:
            score = _fuzzy_score(stripped_query, entry.relative_path)
            if score is not None:
                scored.append((score, entry))
        return [
            entry
            for _score, entry in nsmallest(
                MAX_QUICK_OPEN_RESULTS, scored, key=lambda item: item[0]
            )
        ]

    def _open_highlighted(self) -> None:
        results = self.query_one("#results", OptionList)
        highlighted = results.highlighted
        if highlighted is None:
            return
        try:
            option = results.get_option_at_index(highlighted)
        except Exception:
            return
        path = self._option_paths.get(option.id or "")
        if path is not None:
            self.dismiss(path)


class KeysHelpScreen(ModalScreen[None]):
    """Popup key binding help."""

    BINDINGS = build_screen_bindings("keys_help")

    CSS = """
    KeysHelpScreen {
        align: center middle;
    }
    KeysHelpScreen > #dialog {
        width: 80%;
        height: 80%;
        max-width: 96;
        padding: 1 2;
        background: $panel;
        border: tall $accent;
    }
    KeysHelpScreen Label {
        height: auto;
        margin-bottom: 1;
        text-style: bold;
    }
    KeysHelpScreen #bindings-list {
        width: 1fr;
        height: 1fr;
        padding: 0;
        overflow-y: auto;
    }
    KeysHelpScreen .binding-group {
        height: auto;
        margin-bottom: 1;
    }
    KeysHelpScreen .binding-title {
        height: auto;
        color: $text-primary;
        text-style: underline bold;
    }
    KeysHelpScreen .binding-row {
        height: auto;
        layout: horizontal;
    }
    KeysHelpScreen .binding-key {
        width: 38;
        height: auto;
        color: $text-accent;
        text-style: bold;
        padding-right: 1;
    }
    KeysHelpScreen .binding-description {
        width: 1fr;
        height: auto;
        color: $foreground;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Label("Key Bindings")
            with Vertical(id="bindings-list"):
                for group in binding_help_groups():
                    with Vertical(classes="binding-group"):
                        yield Static(group.title, classes="binding-title")
                        for key, description in group.rows:
                            with Horizontal(classes="binding-row"):
                                yield Static(key, classes="binding-key")
                                yield Static(description, classes="binding-description")

    def action_close(self) -> None:
        self.dismiss(None)


def _fuzzy_score(query: str, candidate: str) -> tuple[int, int, int, int, str] | None:
    query_lower = query.lower()
    candidate_lower = candidate.lower()
    basename = Path(candidate_lower).name
    depth = candidate_lower.count("/")

    if candidate_lower == query_lower:
        return (0, depth, 0, len(candidate_lower), candidate_lower)
    if basename == query_lower:
        return (1, depth, 0, len(candidate_lower), candidate_lower)
    if basename.startswith(query_lower):
        return (2, depth, 0, len(candidate_lower), candidate_lower)
    if candidate_lower.startswith(query_lower):
        return (3, depth, 0, len(candidate_lower), candidate_lower)
    if query_lower in basename:
        return (
            4,
            depth,
            basename.index(query_lower),
            len(candidate_lower),
            candidate_lower,
        )
    if query_lower in candidate_lower:
        return (
            5,
            depth,
            candidate_lower.index(query_lower),
            len(candidate_lower),
            candidate_lower,
        )

    basename_score = _fuzzy_positions(query_lower, basename)
    if basename_score is not None:
        first, gaps = basename_score
        return (6, depth, gaps, first, candidate_lower)

    path_score = _fuzzy_positions(query_lower, candidate_lower)
    if path_score is None:
        return None
    first, gaps = path_score
    return (7, depth, gaps, first, candidate_lower)


def _fuzzy_positions(query_lower: str, candidate_lower: str) -> tuple[int, int] | None:
    positions: list[int] = []
    search_from = 0
    for char in query_lower:
        index = candidate_lower.find(char, search_from)
        if index == -1:
            return None
        positions.append(index)
        search_from = index + 1

    first = positions[0]
    last = positions[-1]
    spread = last - first + 1
    gaps = spread - len(query_lower)
    return first, gaps
