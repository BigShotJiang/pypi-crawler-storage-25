"""peaq_os_sdk.did module."""

from __future__ import annotations

from .write_machine_did_attributes import write_machine_did_attributes
from .write_proxy_did_attributes import write_proxy_did_attributes

__all__: list[str] = [
    "write_machine_did_attributes",
    "write_proxy_did_attributes",
]
