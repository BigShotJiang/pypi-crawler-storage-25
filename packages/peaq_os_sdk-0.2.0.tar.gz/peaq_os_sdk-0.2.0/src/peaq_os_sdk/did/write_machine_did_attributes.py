"""Write the 6 standard DID attributes for a registered machine."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..constants import (
    DID_ATTR_DATA_API,
    DID_ATTR_DATA_VISIBILITY,
    DID_ATTR_DOCUMENTATION_URL,
    DID_ATTR_MACHINE_ID,
    DID_ATTR_NFT_TOKEN_ID,
    DID_ATTR_OPERATOR,
)
from ..validation.did_attributes import validate_machine_did_attrs
from .batch_did_write import DIDWriteAttribute, batch_did_write

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.did.write_machine_did_attributes")


def write_machine_did_attributes(
    client: PeaqosClient,
    machine_id: int,
    nft_token_id: int,
    operator_did: str,
    documentation_url: str,
    data_api: str,
    data_visibility: str,
) -> str:
    """Write the 6 standard DID attributes for a registered machine.

    Validates all inputs, then submits a single ``batchAll`` transaction
    that atomically writes the following attributes to the caller's DID:

    +--------------------+-------------------------------+
    | Key                | Value                         |
    +====================+===============================+
    | ``machineId``      | ``str(machine_id)``           |
    +--------------------+-------------------------------+
    | ``nftTokenId``     | ``str(nft_token_id)``         |
    +--------------------+-------------------------------+
    | ``operator``       | ``operator_did``              |
    +--------------------+-------------------------------+
    | ``documentation_url`` | ``documentation_url``     |
    +--------------------+-------------------------------+
    | ``data_api``       | ``data_api``                  |
    +--------------------+-------------------------------+
    | ``data_visibility``| ``data_visibility``           |
    +--------------------+-------------------------------+

    Args:
        client: Configured ``PeaqosClient``. The client's address is used
            as the DID account.
        machine_id: Registered machine ID. Must be a positive integer.
        nft_token_id: NFT token ID assigned to the machine. Must be
            positive.
        operator_did: Operator DID reference. May be an empty string.
            Must be ASCII and ≤ 2560 bytes.
        documentation_url: Documentation URL. Must be non-empty, ASCII,
            and ≤ 2560 bytes.
        data_api: Data API endpoint. Must be non-empty, ASCII,
            and ≤ 2560 bytes.
        data_visibility: Visibility setting — one of ``"public"``,
            ``"private"``, or ``"onchain"``.

    Returns:
        The batch transaction hash as a hex string.

    Raises:
        ValidationError: If any parameter fails its constraint.
        RpcError: If the batch transaction reverts.

    Example::

        tx_hash = write_machine_did_attributes(
            client,
            machine_id=42,
            nft_token_id=1,
            operator_did="",
            documentation_url="https://docs.example.com",
            data_api="https://api.example.com",
            data_visibility="public",
        )
        print(f"DID attributes written in tx {tx_hash}")
    """
    validate_machine_did_attrs(
        machine_id,
        nft_token_id,
        operator_did,
        documentation_url,
        data_api,
        data_visibility,
    )

    attributes: list[DIDWriteAttribute] = [
        {"name": DID_ATTR_MACHINE_ID, "value": str(machine_id)},
        {"name": DID_ATTR_NFT_TOKEN_ID, "value": str(nft_token_id)},
        {"name": DID_ATTR_OPERATOR, "value": operator_did},
        {"name": DID_ATTR_DOCUMENTATION_URL, "value": documentation_url},
        {"name": DID_ATTR_DATA_API, "value": data_api},
        {"name": DID_ATTR_DATA_VISIBILITY, "value": data_visibility},
    ]

    return batch_did_write(client, client.address, attributes)
