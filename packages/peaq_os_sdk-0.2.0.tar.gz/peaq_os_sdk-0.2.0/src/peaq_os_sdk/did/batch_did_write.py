"""Atomic DID attribute writes via the peaq Batch precompile."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, TypedDict

from ..exceptions import ValidationError
from ..utils.transaction import send_and_await
from .did_precompile import encode_add_attribute

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.did.batch_did_write")


class DIDWriteAttribute(TypedDict):
    """A single DID attribute to write.

    Attributes:
        name: Attribute key (ASCII, ≤ 64 bytes).
        value: Attribute value (ASCII, ≤ 2560 bytes).
    """

    name: str
    value: str


def batch_did_write(
    client: PeaqosClient,
    did_account: str,
    attributes: list[DIDWriteAttribute],
) -> str:
    """Write multiple DID attributes atomically via the Batch precompile.

    Encodes each attribute as ``addAttribute`` calldata and submits all
    of them in a single ``batchAll`` call.  Either every write lands or
    none does (``batchAll`` reverts the entire batch on any failure).

    Args:
        client: Configured ``PeaqosClient``.
        did_account: The DID account address whose attributes are being
            written (``0x``-prefixed, checksummed).
        attributes: Non-empty list of :class:`DIDWriteAttribute` dicts,
            each with ``name`` and ``value`` keys.

    Returns:
        The batch transaction hash as a hex string.

    Raises:
        ValidationError: If ``attributes`` is empty, or if any attribute
            ``name`` or ``value`` fails ASCII / byte-length validation.
        RpcError: If the batch transaction reverts for any reason.

    Example::

        tx_hash = batch_did_write(
            client,
            client.address,
            [{"name": "machineId", "value": "42"}],
        )
        print(f"DID attributes written in tx {tx_hash}")
    """
    if not attributes:
        raise ValidationError(
            field="attributes",
            constraint="non-empty list",
            message="attributes must not be empty",
            value=attributes,
        )

    did_precompile_address: str = client.did_precompile.address

    calldatas: list[bytes] = [
        encode_add_attribute(
            client.did_precompile,
            did_account,
            attr["name"],
            attr["value"],
            0,
        )
        for attr in attributes
    ]

    n = len(calldatas)
    receipt = send_and_await(
        client.web3,
        client.account,
        client.batch_precompile,
        "batchAll",
        args=[
            [did_precompile_address] * n,
            [0] * n,
            calldatas,
            [0] * n,
        ],
    )
    return receipt["transactionHash"].hex()
