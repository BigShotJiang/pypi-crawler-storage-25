"""Write the 2 standard DID attributes for a proxy operator."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from ..constants import DID_ATTR_MACHINE_ID, DID_ATTR_MACHINES
from ..validation.did_attributes import validate_proxy_did_attrs
from .batch_did_write import DIDWriteAttribute, batch_did_write

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.did.write_proxy_did_attributes")


def write_proxy_did_attributes(
    client: PeaqosClient,
    proxy_machine_id: int,
    machine_ids: list[int],
) -> str:
    """Write the 2 standard DID attributes for a proxy operator.

    Validates all inputs, then submits a single ``batchAll`` transaction
    that atomically writes the following attributes to the caller's DID:

    +------------------+------------------------------------+
    | Key              | Value                              |
    +==================+====================================+
    | ``machineId``    | ``str(proxy_machine_id)``            |
    +------------------+------------------------------------+
    | ``machines``     | ``json.dumps(machine_ids)``        |
    +------------------+------------------------------------+

    Args:
        client: Configured ``PeaqosClient``. The client's address is used
            as the DID account.
        proxy_machine_id: The proxy operator's registered machine ID.
            Must be a positive integer.
        machine_ids: Non-empty list of positive machine IDs managed by
            this proxy. The JSON-encoded list must be ≤ 2560 bytes.

    Returns:
        The batch transaction hash as a hex string.

    Raises:
        ValidationError: If ``proxy_machine_id`` is not positive,
            ``machine_ids`` is empty or contains a non-positive ID,
            or the JSON-encoded list exceeds the byte-length cap.
        RpcError: If the batch transaction reverts.

    Example::

        tx_hash = write_proxy_did_attributes(
            client,
            proxy_machine_id=10,
            machine_ids=[42, 43, 44],
        )
        print(f"Proxy DID attributes written in tx {tx_hash}")
    """
    validate_proxy_did_attrs(proxy_machine_id, machine_ids)

    attributes: list[DIDWriteAttribute] = [
        {"name": DID_ATTR_MACHINE_ID, "value": str(proxy_machine_id)},
        {"name": DID_ATTR_MACHINES, "value": json.dumps(machine_ids)},
    ]

    return batch_did_write(client, client.address, attributes)
