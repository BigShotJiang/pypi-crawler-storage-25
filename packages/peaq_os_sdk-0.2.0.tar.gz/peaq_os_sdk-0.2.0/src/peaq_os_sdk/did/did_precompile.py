"""peaq DID precompile helpers — calldata encoding and attribute reads."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from web3.contract import Contract

from ..constants import DID_MAX_NAME_BYTES, DID_MAX_VALUE_BYTES
from ..exceptions import ValidationError
from ..types.did import DIDAttributeResult

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.did.did_precompile")


def encode_add_attribute(
    did_contract: Contract,
    did_account: str,
    name: str,
    value: str,
    valid_for: int,
) -> bytes:
    """Encode calldata for ``addAttribute(address, bytes, bytes, uint32)``.

    Produces the ABI-encoded calldata for a single DID attribute write
    without submitting a transaction.  Used by :func:`batch_did_write`
    to build the ``callData`` array passed to the Batch precompile.

    Args:
        did_contract: DID precompile ``Contract`` instance (bound via
            ``PeaqosClient.did_precompile``).
        did_account: The DID account address (``0x``-prefixed, checksummed).
        name: Attribute key. Must be ASCII and at most
            ``DID_MAX_NAME_BYTES`` (64) bytes when encoded.
        value: Attribute value. Must be ASCII and at most
            ``DID_MAX_VALUE_BYTES`` (2560) bytes when encoded.
        valid_for: Validity period in seconds. ``0`` means no expiry.

    Returns:
        ABI-encoded calldata as ``bytes``, starting with the 4-byte
        function selector for ``addAttribute``.

    Raises:
        ValidationError: If ``name`` or ``value`` contains non-ASCII
            characters or exceeds the respective byte-length limit.

    Example::

        calldata = encode_add_attribute(
            client.did_precompile,
            client.address,
            "machineId",
            "42",
            0,
        )
    """
    try:
        name_bytes = name.encode("ascii")
    except UnicodeEncodeError as err:
        raise ValidationError(
            field="name",
            constraint="ASCII string",
            message="DID attribute name must contain only ASCII characters",
            value=name,
        ) from err

    if len(name_bytes) > DID_MAX_NAME_BYTES:
        raise ValidationError(
            field="name",
            constraint=f"at most {DID_MAX_NAME_BYTES} bytes",
            message=f"DID attribute name must be at most {DID_MAX_NAME_BYTES} bytes",
            value=name,
        )

    try:
        value_bytes = value.encode("ascii")
    except UnicodeEncodeError as err:
        raise ValidationError(
            field="value",
            constraint="ASCII string",
            message="DID attribute value must contain only ASCII characters",
            value=value,
        ) from err

    if len(value_bytes) > DID_MAX_VALUE_BYTES:
        raise ValidationError(
            field="value",
            constraint=f"at most {DID_MAX_VALUE_BYTES} bytes",
            message=f"DID attribute value must be at most {DID_MAX_VALUE_BYTES} bytes",
            value=value,
        )

    hex_data: str = did_contract.encode_abi(
        "addAttribute",
        args=[did_account, name_bytes, value_bytes, valid_for],
    )
    return bytes.fromhex(hex_data[2:])


def read_attribute(
    client: PeaqosClient,
    did_address: str,
    name: str,
) -> DIDAttributeResult:
    """Read a single DID attribute from the peaq DID precompile.

    Calls ``readAttribute(address didAccount, bytes name)`` as a
    read-only view — no transaction is submitted.

    Args:
        client: Configured ``PeaqosClient``.
        did_address: The DID account address to query (``0x``-prefixed).
        name: Attribute key to look up (UTF-8 encoded before the call).

    Returns:
        A :class:`DIDAttributeResult` with ``name``, ``value``,
        ``validity``, and ``created`` fields.

    Raises:
        RpcError: If the attribute does not exist (contract reverts with
            ``EntryNotFound``).

    Example::

        attr = read_attribute(client, client.address, "machineId")
        print(attr["value"])
    """
    result = client.did_precompile.functions.readAttribute(
        did_address,
        name.encode("utf-8"),
    ).call()

    return DIDAttributeResult(
        name=bytes(result[0]).decode("utf-8"),
        value=bytes(result[1]).decode("utf-8"),
        validity=int(result[2]),
        created=int(result[3]),
    )
