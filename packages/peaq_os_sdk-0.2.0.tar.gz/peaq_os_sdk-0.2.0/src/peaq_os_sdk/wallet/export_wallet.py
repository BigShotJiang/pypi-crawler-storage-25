"""Export a wallet's mnemonic phrase or private key from the OWS vault."""

from __future__ import annotations

from ..exceptions.base import PeaqosError
from ._internal.load_ows import load_ows, resolve_passphrase


def export_wallet(
    name_or_id: str,
    passphrase: str | None = None,
    vault_path: str | None = None,
) -> str:
    """Export a wallet's mnemonic phrase or private key.

    Args:
        name_or_id: Wallet name or UUID.
        passphrase: Vault encryption passphrase. Falls back to
            ``OWS_PASSPHRASE`` env var when ``None``.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        The mnemonic phrase (mnemonic wallets) or JSON with key pair
        (private-key wallets).

    Raises:
        PeaqosError: If the wallet is not found, the passphrase is
            wrong, or OWS is not installed.

    Example:
        >>> phrase = export_wallet("my-machine", "s3cret")
        >>> phrase  # "abandon abandon ... about"
    """
    ows = load_ows()
    resolved = resolve_passphrase(passphrase)
    try:
        return ows.export_wallet(
            name_or_id=name_or_id, passphrase=resolved, vault_path_opt=vault_path
        )
    except PeaqosError:
        raise
    except Exception as err:
        raise PeaqosError(f'Wallet operation failed for "{name_or_id}": {err}') from err
