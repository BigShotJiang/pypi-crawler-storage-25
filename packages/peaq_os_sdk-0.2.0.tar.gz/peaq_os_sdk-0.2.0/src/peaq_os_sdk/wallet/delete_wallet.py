"""Securely delete a wallet from the OWS vault."""

from __future__ import annotations

from ..exceptions.base import PeaqosError
from ._internal.load_ows import load_ows


def delete_wallet(
    name_or_id: str,
    vault_path: str | None = None,
) -> None:
    """Securely delete a wallet from the OWS vault.

    The file is overwritten with random bytes before unlinking.

    Args:
        name_or_id: Wallet name or UUID.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Raises:
        PeaqosError: If the wallet is not found or OWS is not installed.

    Example:
        >>> delete_wallet("my-machine")
    """
    ows = load_ows()
    try:
        ows.delete_wallet(name_or_id=name_or_id, vault_path_opt=vault_path)
    except PeaqosError:
        raise
    except Exception as err:
        raise PeaqosError(f'Wallet operation failed for "{name_or_id}": {err}') from err
