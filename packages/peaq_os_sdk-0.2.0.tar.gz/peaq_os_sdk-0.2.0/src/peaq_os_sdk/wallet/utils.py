"""Wallet utility functions for OWS integration."""

from __future__ import annotations

from ..exceptions.base import PeaqosError
from ..types.wallet import AccountInfo

PEAQ_CHAIN_ID = "eip155:3338"
EIP155_PREFIX = "eip155:"


def extract_peaq_address(accounts: list[AccountInfo]) -> str:
    """Extract the primary peaq EVM address from a list of OWS accounts.

    Looks for an account with ``chain_id == "eip155:3338"`` first. If not
    found, falls back to the first ``eip155:*`` account (EVM addresses are
    identical across all EVM chains). Raises if no EVM account exists.

    Args:
        accounts: The account list from an OWS wallet.

    Returns:
        The native-format EVM address string.

    Raises:
        PeaqosError: If no EVM account is found.

    Example:
        >>> extract_peaq_address([
        ...     AccountInfo(
        ...         account_id="eip155:3338:0xAbCd",
        ...         address="0xAbCd",
        ...         chain_id="eip155:3338",
        ...         network="peaq",
        ...         derivation_path="m/44'/60'/0'/0/0",
        ...     )
        ... ])
        '0xAbCd'
    """
    for acct in accounts:
        if acct.chain_id == PEAQ_CHAIN_ID:
            return acct.address

    for acct in accounts:
        if acct.chain_id.startswith(EIP155_PREFIX):
            return acct.address

    raise PeaqosError("No EVM account found in wallet; cannot extract peaq address")
