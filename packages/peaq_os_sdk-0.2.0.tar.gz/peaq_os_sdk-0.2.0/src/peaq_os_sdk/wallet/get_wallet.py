"""Retrieve a single wallet from the OWS vault."""

from __future__ import annotations

from ..exceptions.base import PeaqosError
from ..types.wallet import WalletInfo
from ._internal.load_ows import load_ows, map_wallet_info


def get_wallet(
    name_or_id: str,
    vault_path: str | None = None,
) -> WalletInfo:
    """Retrieve a single wallet by name or UUID.

    Args:
        name_or_id: Wallet name or UUID.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        Frozen :class:`WalletInfo`.

    Raises:
        PeaqosError: If the wallet is not found or OWS is not installed.

    Example:
        >>> wallet = get_wallet("my-machine")
        >>> wallet.peaq_address  # "0x..."
    """
    ows = load_ows()
    try:
        raw = ows.get_wallet(name_or_id=name_or_id, vault_path_opt=vault_path)
    except PeaqosError:
        raise
    except Exception as err:
        raise PeaqosError(f'Wallet operation failed for "{name_or_id}": {err}') from err
    return map_wallet_info(raw)
