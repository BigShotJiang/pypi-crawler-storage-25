"""OWS-native transaction signer and TransactionSigner Protocol."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

import rlp  # type: ignore[import-untyped]  # transitive dep of eth-account, no stubs
from eth_account._utils.legacy_transactions import (
    encode_transaction,
    serializable_unsigned_transaction_from_dict,
)
from eth_account._utils.transaction_utils import transaction_rpc_to_rlp_structure
from eth_account.typed_transactions.typed_transaction import TypedTransaction
from toolz import dissoc  # type: ignore[import-untyped]

from ..exceptions.validation_error import ValidationError
from ..wallet._internal.load_ows import load_ows
from ..wallet._internal.ows_signing_errors import map_ows_signing_error

logger = logging.getLogger("peaq_os_sdk.wallet.ows_signer")

# CAIP-2 prefix for EVM chains.
_EIP155_PREFIX = "eip155:"

# Sentinel that marks a tx dict as a typed (EIP-2718) transaction.
_TYPED_TX_TYPES = frozenset({"0x1", "0x2", "0x3", "0x4", 1, 2, 3, 4})


@runtime_checkable
class TransactionSigner(Protocol):
    """Minimal signing interface consumed by :func:`send_and_await`.

    Both :class:`eth_account.signers.local.LocalAccount` and
    :class:`OWSAccount` satisfy this Protocol.
    """

    address: str

    def sign_transaction(self, tx: dict[str, Any]) -> Any:
        """Sign a transaction dict and return an object with ``.raw_transaction``."""
        ...


class _SignedTx:
    """Minimal signed-transaction envelope returned by :class:`OWSAccount`."""

    __slots__ = ("raw_transaction",)

    def __init__(self, raw_transaction: bytes) -> None:
        self.raw_transaction = raw_transaction


def _is_typed_tx(tx: dict[str, Any]) -> bool:
    """Return ``True`` if *tx* is a typed (EIP-2718) transaction.

    Detection covers both an explicit ``type`` field *and* the presence
    of fields that are exclusive to typed transactions (EIP-2930 /
    EIP-1559).  ``web3.py``'s ``build_transaction`` often omits the
    ``type`` key while still populating ``maxFeePerGas`` /
    ``maxPriorityFeePerGas``, which would cause a legacy-path crash.
    """
    tx_type = tx.get("type")
    if tx_type is not None and tx_type in _TYPED_TX_TYPES:
        return True
    # EIP-1559 (type 2) fields
    if "maxFeePerGas" in tx or "maxPriorityFeePerGas" in tx:
        return True
    # EIP-2930 (type 1) field
    return "accessList" in tx


def _encode_unsigned_legacy(tx: dict[str, Any]) -> bytes:
    """RLP-encode an unsigned legacy (type-0) transaction."""
    unsigned = serializable_unsigned_transaction_from_dict(tx)
    return bytes(rlp.encode(unsigned))


def _encode_unsigned_typed(tx: dict[str, Any]) -> bytes:
    """Encode an unsigned typed (EIP-2718) transaction.

    Mirrors the unsigned-payload construction inside eth-account's
    typed-transaction ``hash()`` (everything except the final keccak):
    ``transaction_type || rlp([fields without v, r, s])``.
    """
    typed_tx = TypedTransaction.from_dict(tx)
    inner = typed_tx.transaction
    fields_without_sig = dissoc(inner.dictionary, "v", "r", "s", "from")  # type: ignore[attr-defined]
    rlp_structured = transaction_rpc_to_rlp_structure(fields_without_sig)
    serializer = inner.__class__._unsigned_transaction_serializer  # type: ignore[attr-defined]
    payload = bytes(rlp.encode(serializer.from_dict(rlp_structured)))
    return bytes([inner.__class__.transaction_type]) + payload  # type: ignore[attr-defined]


def _reconstruct_legacy(tx: dict[str, Any], r: int, s: int, v: int) -> bytes:
    """Re-encode a signed legacy transaction from signature components."""
    unsigned = serializable_unsigned_transaction_from_dict(tx)
    return bytes(encode_transaction(unsigned, vrs=(v, r, s)))


def _reconstruct_typed(tx: dict[str, Any], r: int, s: int, recovery_id: int) -> bytes:
    """Re-encode a signed typed transaction from signature components.

    For EIP-2718 typed transactions, ``v`` carries the ``yParity`` bit
    (0 or 1), not the EIP-155 chain-encoded value.
    """
    tx_signed = dissoc({**tx, "v": recovery_id, "r": r, "s": s}, "from")
    signed_typed = TypedTransaction.from_dict(tx_signed)
    return bytes(signed_typed.encode())


def _strip_hex_prefix(s: str) -> str:
    """Strip a single leading ``0x``/``0X`` prefix if present.

    Unlike ``str.lstrip("0x")`` — which removes any leading ``0`` and ``x``
    characters and would silently corrupt a real signature whose first
    byte is ``0x00`` — this only removes the literal two-char prefix.
    """
    if s.startswith(("0x", "0X")):
        return s[2:]
    return s


def _parse_signature(result: dict[str, Any]) -> tuple[int, int, int]:
    """Extract ``(r, s, recovery_id)`` from an OWS ``sign_transaction`` result.

    OWS returns the 64-byte ECDSA signature as a hex string (r concatenated
    with s) under the ``"signature"`` key, and the recovery identifier under
    ``"recovery_id"``.

    Some OWS variants emit a 65-byte hex string with the recovery byte
    appended; both 128- and 130-char forms are accepted. Anything else
    is treated as a malformed response.

    Raises:
        ValidationError: If the signature hex has an unexpected length.
    """
    sig_hex = _strip_hex_prefix(result["signature"])
    if len(sig_hex) == 130:
        sig_hex = sig_hex[:128]
    if len(sig_hex) != 128:
        raise ValidationError(
            field="ows_signature",
            constraint="64-byte (128-hex-char) ECDSA signature",
            message=f"OWS returned unexpected signature length: {len(sig_hex)} hex chars",
            value=None,
        )
    r = int(sig_hex[:64], 16)
    s = int(sig_hex[64:128], 16)
    recovery_id: int = result.get("recovery_id", 0)
    return r, s, recovery_id


class OWSAccount:
    """Duck-typed signer that routes signing through the OWS library.

    Satisfies the :class:`TransactionSigner` Protocol — ``address`` and
    ``sign_transaction`` are the only two attributes consumed by
    :func:`~peaq_os_sdk.utils.transaction.send_and_await`.

    Security boundary:
        - **SDK-enforced:** the raw private key is **never** held by this
          class; only the wallet identifier, passphrase, and vault path
          are kept on the instance.
        - **Upstream (OWS) guarantee, not SDK-enforced:** ``open-wallet-
          standard`` is documented to decrypt the key inside its Rust FFI
          only for the duration of each ``sign_transaction`` call and to
          wipe it immediately afterwards. The SDK relies on that
          guarantee but does not independently verify or enforce it.

    Args:
        address: Checksummed EVM address of the wallet (peaq address).
        wallet_name_or_id: Wallet name or UUID in the OWS vault.
        passphrase: Already-resolved vault passphrase.
        chain_id: Numeric EVM chain ID (e.g. ``3338`` for peaq mainnet).
        vault_path: Optional custom vault directory path.
    """

    def __init__(
        self,
        address: str,
        wallet_name_or_id: str,
        passphrase: str,
        chain_id: int,
        vault_path: str | None = None,
    ) -> None:
        self.address: str = address
        self._wallet = wallet_name_or_id
        self._passphrase = passphrase
        self._chain_id = chain_id
        self._vault_path = vault_path

    def sign_transaction(self, tx: dict[str, Any]) -> _SignedTx:
        """Sign *tx* via OWS and return an object with ``.raw_transaction``.

        Args:
            tx: Transaction dict as produced by ``web3.eth.contract.functions
                .fn().build_transaction({...})``.

        Returns:
            A :class:`_SignedTx` with ``.raw_transaction`` bytes ready for
            ``web3.eth.send_raw_transaction``.

        Raises:
            PeaqosError: On any OWS error (wallet not found, bad passphrase,
                policy denied, chain not supported, or unknown failure).
            ValidationError: If OWS reports malformed transaction input.
        """
        ows = load_ows()
        chain_id = int(tx.get("chainId", self._chain_id))
        caip2_chain = f"{_EIP155_PREFIX}{chain_id}"
        is_typed = _is_typed_tx(tx)

        unsigned_bytes = _encode_unsigned_typed(tx) if is_typed else _encode_unsigned_legacy(tx)
        tx_hex = "0x" + unsigned_bytes.hex()

        try:
            result: dict[str, Any] = ows.sign_transaction(
                self._wallet,
                caip2_chain,
                tx_hex,
                self._passphrase,
                None,
                self._vault_path,
            )
        except Exception as err:
            raise map_ows_signing_error(err) from err

        r, s, recovery_id = _parse_signature(result)

        if is_typed:
            raw = _reconstruct_typed(tx, r, s, recovery_id)
        else:
            # EIP-155: v = chainId * 2 + 35 + recoveryId
            v = chain_id * 2 + 35 + recovery_id
            raw = _reconstruct_legacy(tx, r, s, v)

        return _SignedTx(raw_transaction=raw)
