"""OWS (Open Wallet Standard) wallet lifecycle module."""

from __future__ import annotations

from .create_wallet import create_wallet
from .delete_wallet import delete_wallet
from .export_wallet import export_wallet
from .get_wallet import get_wallet
from .import_wallet import import_wallet
from .import_wallet_mnemonic import import_wallet_mnemonic
from .list_wallets import list_wallets
from .utils import extract_peaq_address

__all__: list[str] = [
    "create_wallet",
    "delete_wallet",
    "export_wallet",
    "extract_peaq_address",
    "get_wallet",
    "import_wallet",
    "import_wallet_mnemonic",
    "list_wallets",
]
