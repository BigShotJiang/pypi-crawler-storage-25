"""Create a new OWS wallet with a BIP-39 mnemonic."""

from __future__ import annotations

from ..types.wallet import WalletInfo
from ._internal.load_ows import load_ows, map_wallet_info, resolve_passphrase


def create_wallet(
    name: str,
    passphrase: str | None = None,
    words: int = 12,
    vault_path: str | None = None,
) -> WalletInfo:
    """Create a new OWS wallet with a BIP-39 mnemonic.

    Derives accounts for all supported chains and stores the encrypted
    wallet in the OWS vault.

    Args:
        name: Human-readable wallet label.
        passphrase: Vault encryption passphrase. Falls back to
            ``OWS_PASSPHRASE`` env var when ``None``.
        words: Mnemonic length — 12 or 24. Defaults to 12.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        Frozen :class:`WalletInfo` with all chain accounts.
        Mnemonic is never exposed.

    Raises:
        PeaqosError: If OWS is not installed or passphrase is missing.

    Example:
        >>> wallet = create_wallet("my-machine", "s3cret", 12)
        >>> wallet.peaq_address  # "0x..."
        >>> len(wallet.accounts)  # >= 10
    """
    ows = load_ows()
    resolved = resolve_passphrase(passphrase)
    raw = ows.create_wallet(name=name, passphrase=resolved, words=words, vault_path_opt=vault_path)
    return map_wallet_info(raw, key_type="mnemonic")
