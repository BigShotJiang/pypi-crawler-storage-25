"""List all wallets in the OWS vault."""

from __future__ import annotations

from ..types.wallet import WalletInfo
from ._internal.load_ows import load_ows, map_wallet_info


def list_wallets(vault_path: str | None = None) -> list[WalletInfo]:
    """List all wallets in the OWS vault with all chain accounts.

    Args:
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        List of :class:`WalletInfo`. Empty list when the vault
        contains no wallets.

    Raises:
        PeaqosError: If OWS is not installed.

    Example:
        >>> wallets = list_wallets()
        >>> len(wallets)  # 0, 1, 2, ...
    """
    ows = load_ows()
    raw_list = ows.list_wallets(vault_path_opt=vault_path)
    return [map_wallet_info(raw) for raw in raw_list]
