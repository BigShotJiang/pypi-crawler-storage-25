"""Import a BIP-39 mnemonic phrase into the OWS vault."""

from __future__ import annotations

from ..types.wallet import WalletInfo
from ._internal.load_ows import load_ows, map_wallet_info, resolve_passphrase


def import_wallet_mnemonic(
    name: str,
    mnemonic: str,
    passphrase: str | None = None,
    index: int = 0,
    vault_path: str | None = None,
) -> WalletInfo:
    """Import a BIP-39 mnemonic phrase into the OWS vault.

    Args:
        name: Human-readable wallet label.
        mnemonic: 12 or 24 word BIP-39 phrase.
        passphrase: Vault encryption passphrase. Falls back to
            ``OWS_PASSPHRASE`` env var when ``None``.
        index: Account derivation index. Defaults to 0.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        Frozen :class:`WalletInfo` with all chain accounts at the
        specified derivation index.

    Raises:
        PeaqosError: If OWS is not installed or passphrase is missing.

    Example:
        >>> wallet = import_wallet_mnemonic(
        ...     "recovered", "abandon " * 11 + "about", "s3cret"
        ... )
        >>> wallet.peaq_address  # "0x..."
    """
    ows = load_ows()
    resolved = resolve_passphrase(passphrase)
    raw = ows.import_wallet_mnemonic(
        name=name,
        mnemonic=mnemonic,
        passphrase=resolved,
        index=index,
        vault_path_opt=vault_path,
    )
    return map_wallet_info(raw, key_type="mnemonic")
