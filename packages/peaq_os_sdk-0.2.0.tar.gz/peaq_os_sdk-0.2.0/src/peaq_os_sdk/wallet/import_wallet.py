"""Import a raw private key into the OWS vault."""

from __future__ import annotations

import re

from ..constants import IMPORT_CHAIN_EVM
from ..exceptions.validation_error import ValidationError
from ..types.wallet import ImportChain, WalletInfo
from ._internal.load_ows import load_ows, map_wallet_info, resolve_passphrase

_PRIVATE_KEY_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")


def import_wallet(
    name: str,
    private_key: str,
    passphrase: str | None = None,
    chain: ImportChain = IMPORT_CHAIN_EVM,
    vault_path: str | None = None,
) -> WalletInfo:
    """Import a raw private key into the OWS vault as an encrypted wallet.

    Args:
        name: Human-readable wallet label.
        private_key: ``0x``-prefixed 64-char hex private key.
        passphrase: Vault encryption passphrase. Falls back to
            ``OWS_PASSPHRASE`` env var when ``None``.
        chain: Target chain family for derivation. Defaults to
            ``IMPORT_CHAIN_EVM``.
        vault_path: Custom vault directory. Defaults to ``~/.ows/``.

    Returns:
        Frozen :class:`WalletInfo` with all chain accounts.

    Raises:
        ValidationError: If ``private_key`` is not valid hex.
        PeaqosError: If OWS is not installed or passphrase is missing.

    Example:
        >>> wallet = import_wallet("my-key", "0x" + "ab" * 32, "s3cret")
        >>> wallet.peaq_address  # "0x..."
    """
    if not _PRIVATE_KEY_RE.match(private_key):
        raise ValidationError(
            field="private_key",
            constraint="0x-prefixed 64-char hex string",
            message="private_key must be a 0x-prefixed 64-char hex string",
            value="[REDACTED]",
        )

    ows = load_ows()
    resolved = resolve_passphrase(passphrase)
    raw = ows.import_wallet_private_key(
        name=name,
        private_key_hex=private_key,
        chain=chain,
        passphrase=resolved,
        vault_path_opt=vault_path,
    )
    return map_wallet_info(raw, key_type="private_key")
