"""Maps raw OWS signing errors to typed SDK exceptions."""

from __future__ import annotations

from ...constants import (
    OWS_ERROR_CHAIN_NOT_SUPPORTED,
    OWS_ERROR_INVALID_INPUT,
    OWS_ERROR_INVALID_PASSPHRASE,
    OWS_ERROR_POLICY_DENIED,
    OWS_ERROR_WALLET_NOT_FOUND,
)
from ...exceptions.base import PeaqosError
from ...exceptions.validation_error import ValidationError


def _extract_ows_code(err: object) -> str | None:
    """Safely extract the OWS machine-readable error code from a thrown value.

    Forward-compatibility shim: ``ows`` 1.3.2 raises plain ``RuntimeError``
    without a ``.code`` attribute, but a future release may add one.
    """
    if hasattr(err, "code"):
        code = err.code
        return code if isinstance(code, str) else None
    return None


def _classify_by_message(message: str) -> str | None:
    """Classify an OWS error message string to one of the OWS_ERROR_* codes.

    The ``ows`` 1.3.2 binding raises plain ``RuntimeError`` with messages like
    ``wallet not found: 'foo'``, ``decryption failed: aead::Error``, and
    ``invalid input: ...``. We match on lowercase substrings.
    """
    lower = message.lower()
    if "wallet not found" in lower:
        return OWS_ERROR_WALLET_NOT_FOUND
    if "decryption failed" in lower or "aead::error" in lower:
        return OWS_ERROR_INVALID_PASSPHRASE
    if "policy" in lower:
        return OWS_ERROR_POLICY_DENIED
    if "chain not supported" in lower or "unsupported chain" in lower:
        return OWS_ERROR_CHAIN_NOT_SUPPORTED
    if "invalid input" in lower or "unknown chain" in lower:
        return OWS_ERROR_INVALID_INPUT
    return None


def map_ows_signing_error(err: object) -> PeaqosError:
    """Translate a raw OWS signing error into the appropriate SDK exception.

    The caller is responsible for exception chaining (``raise ... from err``).

    Args:
        err: The raw value caught from an OWS ``sign_transaction`` call.

    Returns:
        A typed :class:`~peaq_os_sdk.exceptions.PeaqosError` (or subclass)
        ready to be raised by the caller.
    """
    message = str(err)
    known_codes = {
        OWS_ERROR_WALLET_NOT_FOUND,
        OWS_ERROR_INVALID_PASSPHRASE,
        OWS_ERROR_INVALID_INPUT,
        OWS_ERROR_POLICY_DENIED,
        OWS_ERROR_CHAIN_NOT_SUPPORTED,
    }
    raw_code = _extract_ows_code(err)
    code = raw_code if raw_code in known_codes else _classify_by_message(message)

    if code == OWS_ERROR_WALLET_NOT_FOUND:
        return PeaqosError(
            f"Wallet not found in the OWS vault: {message}",
            code=OWS_ERROR_WALLET_NOT_FOUND,
        )

    if code == OWS_ERROR_INVALID_PASSPHRASE:
        return PeaqosError(
            f"Invalid vault passphrase: {message}",
            code=OWS_ERROR_INVALID_PASSPHRASE,
        )

    if code == OWS_ERROR_INVALID_INPUT:
        return ValidationError(
            field="transaction",
            constraint="valid serialized transaction",
            message=f"Malformed transaction input: {message}",
            value=None,
        )

    if code == OWS_ERROR_POLICY_DENIED:
        return PeaqosError(
            f"OWS policy denied signing: {message}",
            code=OWS_ERROR_POLICY_DENIED,
        )

    if code == OWS_ERROR_CHAIN_NOT_SUPPORTED:
        return PeaqosError(
            f"Chain not supported by OWS: {message}",
            code=OWS_ERROR_CHAIN_NOT_SUPPORTED,
        )

    return PeaqosError(f"OWS signing failed: {message}")
