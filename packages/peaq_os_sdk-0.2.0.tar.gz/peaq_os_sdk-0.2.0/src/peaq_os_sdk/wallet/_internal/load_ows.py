"""Dynamic loader, passphrase resolver, and wallet mapper for OWS."""

from __future__ import annotations

import importlib
import os
from typing import Any, Protocol

from ...constants import OWS_PASSPHRASE_ENV, SUPPORTED_CHAINS
from ...exceptions.base import PeaqosError
from ...types.wallet import AccountInfo, ImportChain, WalletInfo
from ..utils import EIP155_PREFIX, extract_peaq_address

OWS_PACKAGE = "ows"


class OwsModule(Protocol):
    """Minimal subset of the ``ows`` package used by the SDK."""

    def create_wallet(
        self,
        name: str,
        passphrase: str | None = None,
        words: int | None = None,
        vault_path_opt: str | None = None,
    ) -> dict[str, Any]: ...

    def import_wallet_private_key(
        self,
        name: str,
        private_key_hex: str,
        chain: ImportChain | None = None,
        passphrase: str | None = None,
        vault_path_opt: str | None = None,
    ) -> dict[str, Any]: ...

    def import_wallet_mnemonic(
        self,
        name: str,
        mnemonic: str,
        passphrase: str | None = None,
        index: int | None = None,
        vault_path_opt: str | None = None,
    ) -> dict[str, Any]: ...

    def list_wallets(
        self,
        vault_path_opt: str | None = None,
    ) -> list[dict[str, Any]]: ...

    def get_wallet(
        self,
        name_or_id: str,
        vault_path_opt: str | None = None,
    ) -> dict[str, Any]: ...

    def export_wallet(
        self,
        name_or_id: str,
        passphrase: str | None = None,
        vault_path_opt: str | None = None,
    ) -> str: ...

    def delete_wallet(
        self,
        name_or_id: str,
        vault_path_opt: str | None = None,
    ) -> None: ...

    def sign_transaction(
        self,
        wallet: str,
        chain: str,
        tx_hex: str,
        passphrase: str | None = None,
        index: int | None = None,
        vault_path_opt: str | None = None,
    ) -> dict[str, Any]: ...


def load_ows() -> OwsModule:
    """Dynamically import the ``ows`` package (``open-wallet-standard``).

    Raises:
        PeaqosError: If the package is not installed or fails to load.
    """
    try:
        mod = importlib.import_module(OWS_PACKAGE)
        return mod
    except ModuleNotFoundError as err:
        if err.name == OWS_PACKAGE:
            raise PeaqosError(
                "open-wallet-standard is not installed. "
                "Install it with: pip install open-wallet-standard"
            ) from err
        raise PeaqosError(f"Failed to load {OWS_PACKAGE}: {err}") from err
    except Exception as err:
        raise PeaqosError(f"Failed to load {OWS_PACKAGE}: {err}") from err


def resolve_passphrase(passphrase: str | None) -> str:
    """Resolve the vault passphrase from the argument or env var.

    Args:
        passphrase: Explicit passphrase, or ``None`` to read from
            the ``OWS_PASSPHRASE`` environment variable.

    Returns:
        The resolved passphrase string.

    Raises:
        PeaqosError: If neither source provides a value.
    """
    resolved = passphrase or os.environ.get(OWS_PASSPHRASE_ENV)
    if not resolved:
        raise PeaqosError(
            "Passphrase is required. Provide it as an argument "
            "or set the OWS_PASSPHRASE environment variable"
        )
    return resolved


"""CAIP-2 namespaces that don't match their common network name."""
NAMESPACE_ALIASES: dict[str, str] = {
    "eip155": "ethereum",
    "bip122": "bitcoin",
    "fil": "filecoin",
    "xrpl": "ripple",
}

"""Maps a CAIP-2 chainId to a human-readable network name."""
CHAIN_ID_TO_NETWORK: dict[str, str] = {
    f"{EIP155_PREFIX}{chain_id}": name for name, chain_id in SUPPORTED_CHAINS.items()
}

"""CAIP-2 chain IDs for every EVM chain the protocol supports."""
SUPPORTED_EVM_CHAINS: list[str] = [
    f"{EIP155_PREFIX}{chain_id}" for chain_id in SUPPORTED_CHAINS.values()
]


def resolve_network(chain_id: str) -> str:
    """Map a CAIP-2 chain identifier to a human-readable network name.

    Checks ``CHAIN_ID_TO_NETWORK`` first (known EVM chains), then falls
    back to extracting the CAIP-2 namespace and applying
    ``NAMESPACE_ALIASES`` (e.g. ``eip155`` → ``"ethereum"``).

    Args:
        chain_id: CAIP-2 chain identifier (e.g. ``"eip155:3338"``).

    Returns:
        Human-readable network name (e.g. ``"peaq"``, ``"solana"``).
    """
    known = CHAIN_ID_TO_NETWORK.get(chain_id)
    if known:
        return known
    ns = chain_id.split(":")[0] if ":" in chain_id else chain_id
    return NAMESPACE_ALIASES.get(ns, ns)


def map_wallet_info(raw: dict[str, Any], key_type: str = "mnemonic") -> WalletInfo:
    """Map a raw OWS wallet dict to a ``WalletInfo`` dataclass.

    Args:
        raw: Dictionary as returned by the OWS library, with
            snake_case keys (``id``, ``name``, ``created_at``,
            ``accounts``).
        key_type: Key origin — ``"mnemonic"`` or ``"private_key"``.
            The OWS library does not return this field, so the
            caller must provide it based on the operation used.

    Returns:
        A frozen ``WalletInfo`` instance.

    Raises:
        PeaqosError: If the raw wallet dict is missing required
            fields or has an unexpected shape.
    """
    try:
        accounts = [
            AccountInfo(
                account_id=a.get("account_id", f"{a['chain_id']}:{a['address']}"),
                address=a["address"],
                chain_id=a["chain_id"],
                network=resolve_network(a["chain_id"]),
                derivation_path=a["derivation_path"],
            )
            for a in raw["accounts"]
        ]

        # Synthesize missing supported EVM chain accounts from the first
        # available EVM account (all EVM chains share the same address).
        evm_source = next((a for a in accounts if a.chain_id.startswith(EIP155_PREFIX)), None)
        if evm_source is not None:
            existing_chains = {a.chain_id for a in accounts}
            for chain in SUPPORTED_EVM_CHAINS:
                if chain not in existing_chains:
                    accounts.append(
                        AccountInfo(
                            account_id=f"{chain}:{evm_source.address}",
                            address=evm_source.address,
                            chain_id=chain,
                            network=resolve_network(chain),
                            derivation_path=evm_source.derivation_path,
                        )
                    )

        return WalletInfo(
            id=raw["id"],
            name=raw["name"],
            created_at=raw["created_at"],
            key_type=raw.get("key_type", key_type),
            peaq_address=extract_peaq_address(accounts),
            accounts=accounts,
        )
    except PeaqosError:
        raise
    except (KeyError, TypeError) as err:
        raise PeaqosError(f"Unexpected wallet response shape from OWS: {err}") from err
