"""Transaction helpers — build, sign, send, and decode contract writes."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from web3 import Web3
from web3.contract import Contract
from web3.exceptions import ContractLogicError
from web3.logs import DISCARD
from web3.types import TxReceipt

if TYPE_CHECKING:
    from ..wallet.ows_signer import TransactionSigner

from ..abis import load_abi
from ..exceptions import RpcError
from .error_resolver import AbiRevertResolver

logger = logging.getLogger("peaq_os_sdk.utils.transaction")

# Machine-readable codes attached to RpcError instances.
TX_REVERTED = "TX_REVERTED"
RECEIPT_AWAIT_FAILED = "RECEIPT_AWAIT_FAILED"
REGISTERED_EVENT_MISSING = "REGISTERED_EVENT_MISSING"
REGISTERED_EVENT_MALFORMED = "REGISTERED_EVENT_MALFORMED"

# On-chain custom-error names → SDK-owned human-readable messages.
KNOWN_REVERTS: dict[str, str] = {
    "AlreadyRegistered": "Machine address is already registered",
    "InvalidMachineAddress": "Invalid machine address (zero address not allowed)",
    "AmountZero": "Bond amount must be greater than zero",
    "AlreadyStaked": "Machine is already bonded/staked",
    "MachineNotBonded": "Machine is not bonded",
    "MachineNotFound": "Machine not found in the registry",
    "AlreadyMinted": "NFT already minted for this machine",
    "NotMachineOwner": "Caller is not the machine owner",
    "RecipientMustBeMachineOwner": "Operator mint requires recipient to be the machine owner",
    "InvalidAddress": "Invalid address (zero address not allowed)",
    "MachineDeactivated": "Machine is deactivated",
    "NotAuthorizedSubmitter": "Caller is not authorized submitter",
    "InvalidEventType": "Invalid event type",
    "InvalidTrustLevel": "Invalid trust level",
}


REVERT_RESOLVER = AbiRevertResolver.from_abis(
    load_abi("IdentityRegistry"),
    load_abi("IdentityStaking"),
    load_abi("EventRegistry"),
)


def send_and_await(
    web3: Web3,
    account: TransactionSigner,
    contract: Contract,
    function_name: str,
    args: list[Any] | None = None,
    value_wei: int = 0,
) -> TxReceipt:
    """Build, sign, send a contract write, and wait for the receipt.

    Args:
        web3: Web3 instance connected to a peaq RPC endpoint.
        account: Signing account (holds the private key).
        contract: web3 Contract instance targeted by the call.
        function_name: Solidity function name on the contract.
        args: Positional arguments for the contract function.
        value_wei: Native value to attach in wei (default 0).

    Returns:
        The mined transaction receipt.

    Raises:
        RpcError: On pre-flight revert (gas estimation failure),
            post-flight revert (``receipt.status == 0``), or
            transport / RPC failure at any stage.
    """
    if args is None:
        args = []

    fn = getattr(contract.functions, function_name)(*args)

    try:
        tx: dict[str, Any] = fn.build_transaction(
            {
                "from": account.address,
                "value": value_wei,
                "nonce": web3.eth.get_transaction_count(web3.to_checksum_address(account.address)),
            }
        )
    except ContractLogicError as err:
        raise map_known_revert(err, resolver=REVERT_RESOLVER) from err

    signed = account.sign_transaction(tx)

    try:
        tx_hash = web3.eth.send_raw_transaction(signed.raw_transaction)
    except ContractLogicError as err:
        raise map_known_revert(err, resolver=REVERT_RESOLVER) from err

    try:
        receipt: TxReceipt = web3.eth.wait_for_transaction_receipt(tx_hash)
    except TimeoutError as err:
        raise RpcError(
            "Transaction submitted but receipt could not be retrieved",
            code=RECEIPT_AWAIT_FAILED,
        ) from err

    if receipt["status"] == 0:
        raise RpcError(
            "Transaction reverted on-chain after submission",
            code=TX_REVERTED,
        )

    return receipt


def parse_registered_log(receipt: TxReceipt, contract: Contract) -> int:
    """Decode the ``Registered`` event from a receipt to extract the machine ID.

    Args:
        receipt: Transaction receipt from a ``register()`` or
            ``registerFor()`` call.
        contract: IdentityRegistry contract instance whose ABI
            contains the ``Registered`` event definition.

    Returns:
        The ``machineId`` as a positive ``int``.

    Raises:
        RpcError: If the receipt contains no ``Registered`` event or
            the decoded ``machineId`` is not a positive integer.
    """
    events = contract.events.Registered().process_receipt(receipt, errors=DISCARD)

    if not events:
        raise RpcError(
            "No Registered event found in transaction receipt",
            code=REGISTERED_EVENT_MISSING,
        )

    machine_id: object = events[0]["args"]["machineId"]

    if not isinstance(machine_id, int):
        raise RpcError(
            "Registered event has a malformed machineId",
            code=REGISTERED_EVENT_MALFORMED,
        )

    if machine_id <= 0:
        raise RpcError(
            "Registered event returned a non-positive machineId",
            code=REGISTERED_EVENT_MALFORMED,
        )

    return machine_id


def map_known_revert(
    err: Exception,
    resolver: AbiRevertResolver | None = None,
) -> RpcError:
    """Translate a contract revert into a descriptive ``RpcError``."""
    if resolver is not None:
        error_name = resolver.resolve_error_name(err, KNOWN_REVERTS)
        if error_name is not None:
            return RpcError(KNOWN_REVERTS[error_name], code=error_name)

    message = str(err)
    for error_name, sdk_message in KNOWN_REVERTS.items():
        if error_name in message:
            return RpcError(sdk_message, code=error_name)

    return RpcError(f"Transaction reverted: {message}", code=TX_REVERTED)
