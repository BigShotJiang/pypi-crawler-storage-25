from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

from eth_utils.crypto import keccak

TX_REVERTED = "TX_REVERTED"


@dataclass(frozen=True)
class AbiRevertResolver:
    """Resolve EVM custom-error selectors to ABI error names."""

    selector_to_name: Mapping[str, str]

    @classmethod
    def from_abis(cls, *abis: list[dict[str, Any]]) -> AbiRevertResolver:
        selector_to_name: dict[str, str] = {}

        for abi in abis:
            for item in abi:
                if item.get("type") != "error":
                    continue

                name_obj = item.get("name")
                inputs_obj = item.get("inputs", [])

                if not isinstance(name_obj, str):
                    continue
                if not isinstance(inputs_obj, list):
                    continue

                arg_types: list[str] = []
                for inp in inputs_obj:
                    if not isinstance(inp, dict):
                        arg_types = []
                        break
                    typ = inp.get("type")
                    if not isinstance(typ, str):
                        arg_types = []
                        break
                    arg_types.append(typ)

                if not arg_types and inputs_obj:
                    continue

                signature = f"{name_obj}({','.join(arg_types)})"
                selector = "0x" + keccak(text=signature)[:4].hex()
                selector_to_name[selector] = name_obj

        return cls(selector_to_name=selector_to_name)

    def resolve_error_name(self, err: Exception, known_reverts: Mapping[str, str]) -> str | None:
        """Return a known ABI error name if present in the exception."""
        tokens = list(self._iter_error_tokens(err))

        for token in tokens:
            for error_name in known_reverts:
                if error_name in token:
                    return error_name

        for token in tokens:
            for selector in re.findall(r"0x[0-9a-fA-F]{8}", token):
                resolved_error_name = self.selector_to_name.get(selector.lower())
                if resolved_error_name is not None and resolved_error_name in known_reverts:
                    return resolved_error_name

        return None

    @staticmethod
    def _iter_error_tokens(err: Exception) -> Iterable[str]:
        for arg in getattr(err, "args", ()):
            if isinstance(arg, str):
                yield arg
            elif isinstance(arg, (bytes, bytearray)) and len(arg) >= 4:
                yield "0x" + bytes(arg[:4]).hex()

        yield str(err)
