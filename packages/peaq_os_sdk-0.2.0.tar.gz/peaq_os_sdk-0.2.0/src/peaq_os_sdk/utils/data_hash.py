"""Keccak-256 data hashing utility."""

from __future__ import annotations

from web3 import Web3


def compute_data_hash(raw_data: bytes) -> bytes:
    """Compute the keccak256 hash of raw data for on-chain data integrity.

    Args:
        raw_data: The raw data bytes to hash.

    Returns:
        The keccak256 hash as 32 bytes.

    Example:
        >>> compute_data_hash(b"test")  # doctest: +ELLIPSIS
        b'...'
    """
    return Web3.keccak(raw_data)
