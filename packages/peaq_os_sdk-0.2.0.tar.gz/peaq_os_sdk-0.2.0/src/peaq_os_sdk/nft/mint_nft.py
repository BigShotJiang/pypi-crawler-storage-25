"""NFT minting on the MachineNFT contract."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..exceptions import ValidationError
from ..utils.transaction import send_and_await

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.nft.mint_nft")


def mint_nft(client: PeaqosClient, machine_id: int, recipient: str) -> str:
    """Mint an NFT for a registered machine on the MachineNFT contract.

    Calls the non-payable ``mint(uint256 machineId, address recipient)``
    function and returns the transaction hash.  The machine must already
    be bonded (via ``register`` or ``registerFor``); the recipient must
    be the machine owner.

    Args:
        client: Configured ``PeaqosClient``.
        machine_id: The registered machine ID. Must be a positive integer.
        recipient: Address that will receive the NFT. Must be a valid
            ``0x``-prefixed Ethereum address.

    Returns:
        The transaction hash as a hex string.

    Raises:
        ValidationError: If ``machine_id`` is not positive, or
            ``recipient`` is not a valid Ethereum address.
        RpcError: If the machine is not bonded (``MachineNotBonded``),
            the NFT is already minted (``AlreadyMinted``), the caller
            is not the machine owner (``NotMachineOwner``), or the
            transaction reverts for any other reason.

    Example::

        tx_hash = mint_nft(client, machine_id=42, recipient=client.address)
        print(f"Minted NFT in tx {tx_hash}")
    """
    if machine_id <= 0:
        raise ValidationError(
            field="machine_id",
            constraint="positive integer",
            message="machine_id must be a positive integer",
            value=machine_id,
        )

    if not client.web3.is_address(recipient):
        raise ValidationError(
            field="recipient",
            constraint="0x-prefixed 20-byte hex address",
            message="recipient must be a valid 0x-prefixed Ethereum address",
            value=recipient,
        )

    if int(recipient, 16) == 0:
        raise ValidationError(
            field="recipient",
            constraint="non-zero address",
            message="recipient must not be the zero address",
            value=recipient,
        )

    checksummed = client.web3.to_checksum_address(recipient)

    receipt = send_and_await(
        client.web3,
        client.account,
        client.machine_nft,
        "mint",
        args=[machine_id, checksummed],
    )
    return receipt["transactionHash"].hex()
