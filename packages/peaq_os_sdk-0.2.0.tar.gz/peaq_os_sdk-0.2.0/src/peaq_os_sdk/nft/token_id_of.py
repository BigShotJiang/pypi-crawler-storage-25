"""Read-only NFT token ID query on the MachineNFT contract."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..exceptions import ValidationError

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.nft.token_id_of")


def token_id_of(client: PeaqosClient, machine_id: int) -> int:
    """Return the NFT token ID assigned to a registered machine.

    Calls ``tokenIdOf(uint256 machineId)`` as a read-only view — no
    transaction is submitted.

    Args:
        client: Configured ``PeaqosClient``.
        machine_id: The registered machine ID. Must be a positive integer.

    Returns:
        The NFT token ID as a positive ``int``.

    Raises:
        ValidationError: If ``machine_id`` is not positive.
        RpcError: If the machine has no NFT minted (contract reverts).

    Example::

        token_id = token_id_of(client, machine_id=42)
        print(f"NFT token ID: {token_id}")
    """
    if machine_id <= 0:
        raise ValidationError(
            field="machine_id",
            constraint="positive integer",
            message="machine_id must be a positive integer",
            value=machine_id,
        )

    return int(client.machine_nft.functions.tokenIdOf(machine_id).call())
