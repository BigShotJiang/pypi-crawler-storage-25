"""Faucet 2FA setup and confirmation against the peaq gas station."""

from __future__ import annotations

import logging
from typing import Any, TypedDict

import requests

from ..exceptions import ApiError, ValidationError

logger = logging.getLogger("peaq_os_sdk.registration.faucet")

# -- Response envelope constants -------------------------------------------

_STATUS = "status"
_CODE = "code"
_DATA = "data"
_MESSAGE = "message"

_STATUS_SUCCESS = "success"
_CODE_2FA_ACTIVATED = "2FA_ACTIVATED"

# SDK error codes for faucet interactions.
_NETWORK_ERROR = "NETWORK_ERROR"
_UNEXPECTED_RESPONSE = "UNEXPECTED_RESPONSE"
_INVALID_RESPONSE = "INVALID_RESPONSE"

# Error code → SDK-owned message for setup_faucet_2fa.
_SETUP_ERRORS: dict[str, str] = {
    "INVALID_OWNER_ADDRESS": "Invalid owner address",
    "QR_GENERATION_FAILED": "QR code generation failed",
}

# Error code → SDK-owned message for confirm_faucet_2fa.
_CONFIRM_ERRORS: dict[str, str] = {
    "INVALID_2FA": "Invalid 2FA code",
    "2FA_NOT_CONFIGURED": "2FA not configured for this owner — call setup_faucet_2fa first",
}


# -- Public types ----------------------------------------------------------


class FaucetSetupResponse(TypedDict):
    """Typed dict returned by :func:`setup_faucet_2fa`."""

    owner_address: str
    otpauth_uri: str
    qr_image_url: str


# -- Public functions ------------------------------------------------------


def setup_faucet_2fa(
    session: requests.Session,
    owner_address: str,
    faucet_base_url: str,
    qr_format: str = "svg",
) -> FaucetSetupResponse:
    """Initiate 2FA enrollment for an owner address.

    Args:
        session: Reusable HTTP session (from ``PeaqosClient.session``).
        owner_address: Owner address to enroll.
        faucet_base_url: Absolute base URL of the gas station.
        qr_format: QR image format — ``"svg"`` (default) or ``"png"``.

    Returns:
        A dict with ``owner_address``, ``otpauth_uri``, and ``qr_image_url``.

    Raises:
        ValidationError: If ``owner_address`` or ``faucet_base_url`` is empty.
        ApiError: On ``INVALID_OWNER_ADDRESS``, ``QR_GENERATION_FAILED``,
            or an unexpected faucet response.

    Example::

        resp = setup_faucet_2fa(client.session, "5Grw...", "https://gas.peaq.network")
        print(resp["otpauth_uri"])   # paste into authenticator
        print(resp["qr_image_url"])  # render immediately — expires fast
    """
    _require_non_empty("owner_address", owner_address)
    _require_non_empty("faucet_base_url", faucet_base_url)

    url = _join_url(faucet_base_url, "/2fa/setup")

    try:
        response = session.post(
            url,
            json={"ownerAddress": owner_address, "format": qr_format},
            timeout=30,
        )
    except requests.RequestException as err:
        raise ApiError(
            f"setup_faucet_2fa: network request to {url} failed",
            code=_NETWORK_ERROR,
        ) from err

    body = _read_json(response, url)

    if not response.ok:
        raise _map_faucet_error(body, _SETUP_ERRORS, "setup_faucet_2fa")

    if not isinstance(body, dict) or body.get(_STATUS) != _STATUS_SUCCESS:
        raise ApiError(
            "setup_faucet_2fa: unexpected response envelope",
            code=_UNEXPECTED_RESPONSE,
        )

    data = body.get(_DATA)
    if not isinstance(data, dict):
        raise ApiError(
            "setup_faucet_2fa: malformed data payload",
            code=_UNEXPECTED_RESPONSE,
        )

    owner_out = data.get("ownerAddress")
    otpauth_uri = data.get("otpauthUri")
    qr_image_url = data.get("qrImageUrl")

    if (
        not isinstance(owner_out, str)
        or not isinstance(otpauth_uri, str)
        or not isinstance(qr_image_url, str)
    ):
        raise ApiError(
            "setup_faucet_2fa: malformed data payload",
            code=_UNEXPECTED_RESPONSE,
        )

    return FaucetSetupResponse(
        owner_address=owner_out,
        otpauth_uri=otpauth_uri,
        qr_image_url=qr_image_url,
    )


def confirm_faucet_2fa(
    session: requests.Session,
    owner_address: str,
    faucet_base_url: str,
    two_factor_code: str,
) -> None:
    """Confirm 2FA activation by submitting a TOTP code.

    Args:
        session: Reusable HTTP session.
        owner_address: Owner address whose 2FA is being confirmed.
        faucet_base_url: Absolute base URL of the gas station.
        two_factor_code: Current TOTP code from the authenticator app.

    Raises:
        ValidationError: If any argument is empty.
        ApiError: On ``INVALID_2FA``, ``2FA_NOT_CONFIGURED``, or an
            unexpected faucet response.

    Example::

        confirm_faucet_2fa(client.session, "5Grw...", "https://gas.peaq.network", "123456")
    """
    _require_non_empty("owner_address", owner_address)
    _require_non_empty("faucet_base_url", faucet_base_url)
    _require_non_empty("two_factor_code", two_factor_code)

    url = _join_url(faucet_base_url, "/2fa/confirm")

    try:
        response = session.post(
            url,
            json={"ownerAddress": owner_address, "twoFactorCode": two_factor_code},
            timeout=30,
        )
    except requests.RequestException as err:
        raise ApiError(
            f"confirm_faucet_2fa: network request to {url} failed",
            code=_NETWORK_ERROR,
        ) from err

    body = _read_json(response, url)

    if not response.ok:
        raise _map_faucet_error(body, _CONFIRM_ERRORS, "confirm_faucet_2fa")

    if (
        not isinstance(body, dict)
        or body.get(_STATUS) != _STATUS_SUCCESS
        or body.get(_CODE) != _CODE_2FA_ACTIVATED
    ):
        raise ApiError(
            "confirm_faucet_2fa: unexpected response envelope",
            code=_UNEXPECTED_RESPONSE,
        )


# -- Private helpers -------------------------------------------------------


def _require_non_empty(field: str, value: object) -> None:
    """Raise ``ValidationError`` if *value* is not a non-empty string."""
    if not isinstance(value, str) or len(value) == 0:
        raise ValidationError(
            field=field,
            constraint="non-empty string",
            message=f"{field} must be a non-empty string",
            value=value,
        )


def _join_url(base: str, path: str) -> str:
    return base.rstrip("/") + path


def _read_json(response: requests.Response, url: str) -> Any:
    """Parse JSON body or raise ``ApiError``."""
    try:
        return response.json()
    except ValueError as err:
        raise ApiError(
            f"Faucet at {url} returned a non-JSON response",
            code=_INVALID_RESPONSE,
        ) from err


def _map_faucet_error(
    body: object,
    known_messages: dict[str, str],
    caller: str,
) -> ApiError:
    """Map a faucet error envelope to an ``ApiError``."""
    if isinstance(body, dict):
        code = body.get(_CODE)
        if isinstance(code, str):
            sdk_msg = known_messages.get(code)
            if sdk_msg is not None:
                return ApiError(sdk_msg, code=code)
            server_msg = body.get(_MESSAGE, "")
            if isinstance(server_msg, str) and server_msg:
                return ApiError(f"{caller}: {server_msg}", code=code)
            return ApiError(f"{caller}: faucet error {code}", code=code)
    return ApiError(
        f"{caller}: unexpected error response",
        code=_UNEXPECTED_RESPONSE,
    )
