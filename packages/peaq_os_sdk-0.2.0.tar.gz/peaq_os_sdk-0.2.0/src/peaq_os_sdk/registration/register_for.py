"""Proxy-managed machine registration on the IdentityRegistry."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..exceptions import ValidationError
from ..utils.transaction import parse_registered_log, send_and_await

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.registration.register_for")

# 1 PEAQ in wei — minimum bond sent with the registerFor() call.
_BOND_WEI = 10**18


def register_for(client: PeaqosClient, machine_address: str) -> int:
    """Register a machine address as a machine via proxy.

    Calls the payable ``registerFor(machineAddress)`` on IdentityRegistry
    with 1 PEAQ attached as ``msg.value`` — the contract auto-bonds the
    machine internally as part of registration.  The caller (proxy)
    becomes the on-chain owner of the new identity.  The contract
    assigns a fresh ``machineId`` and emits the ``Registered`` event.

    .. note::

       Bonding happens via ``msg.value`` on the ``registerFor()`` call
       itself — the SDK does **not** issue a separate
       ``IdentityStaking.stake(machine_id)`` transaction.  See
       :func:`register_machine` for the full rationale.

    The zero address (``0x0000...0000``) passes client-side format
    validation but is rejected by the contract with
    ``InvalidMachineAddress``, which surfaces as an ``RpcError``
    whose message contains ``"zero address"``.

    Args:
        client: Configured ``PeaqosClient`` whose signing key acts as
            the proxy operator.
        machine_address: The machine EOA to register (``0x``-prefixed).

    Returns:
        The newly assigned ``machine_id`` as a positive ``int``.

    Raises:
        ValidationError: If ``machine_address`` is not a valid
            ``0x``-prefixed Ethereum address.
        RpcError: If the machine is already registered
            (``AlreadyRegistered``), the address is the zero address
            (``InvalidMachineAddress``), balance is insufficient,
            or the transaction reverts.

    Example::

        machine_addr, _ = PeaqosClient.generate_keypair()
        machine_id = register_for(proxy_client, machine_addr)
        print(f"Registered machine {machine_addr} with machine ID {machine_id}")
    """
    if not client.web3.is_address(machine_address):
        raise ValidationError(
            field="machine_address",
            constraint="0x-prefixed 20-byte hex address",
            message="machine_address must be a valid 0x-prefixed Ethereum address",
            value=machine_address,
        )

    checksummed = client.web3.to_checksum_address(machine_address)

    receipt = send_and_await(
        client.web3,
        client.account,
        client.identity_registry,
        "registerFor",
        args=[checksummed],
        value_wei=_BOND_WEI,
    )
    return parse_registered_log(receipt, client.identity_registry)
