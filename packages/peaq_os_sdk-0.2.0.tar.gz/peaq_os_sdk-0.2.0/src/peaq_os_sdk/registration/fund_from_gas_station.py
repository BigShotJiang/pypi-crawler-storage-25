"""Gas station funding — request PEAQ tokens for a target wallet."""

from __future__ import annotations

import logging
import uuid
from typing import Literal, TypedDict

import requests

from ..exceptions import ApiError
from .faucet import _join_url, _map_faucet_error, _read_json, _require_non_empty

logger = logging.getLogger("peaq_os_sdk.registration.fund_from_gas_station")

# -- SDK error codes (shared with faucet.py) --------------------------------

_NETWORK_ERROR = "NETWORK_ERROR"
_UNEXPECTED_RESPONSE = "UNEXPECTED_RESPONSE"

# -- Faucet response envelope constants -------------------------------------

_STATUS = "status"
_CODE = "code"
_DATA = "data"

_STATUS_SUCCESS = "success"
_STATUS_SKIPPED = "skipped"
_CODE_SUCCESS = "SUCCESS"
_CODE_SUFFICIENT_BALANCE = "SUFFICIENT_BALANCE"

# Error code → SDK-owned message for every documented /faucet/fund error.
_FUND_ERRORS: dict[str, str] = {
    "INVALID_2FA": "Invalid 2FA code",
    "2FA_NOT_CONFIGURED": "2FA not configured for this owner — call setup_faucet_2fa first",
    "2FA_NOT_ACTIVE": "2FA not yet activated — call confirm_faucet_2fa first",
    "2FA_LOCKED": "2FA locked after too many invalid attempts",
    "DUPLICATE_REQUEST": "Request ID is already being processed",
    "REQUEST_ALREADY_PROCESSED": "Request ID has already been completed",
    "RATE_LIMITED": "Faucet rate limit exceeded",
    "CAP_EXCEEDED_OWNER": "Owner daily funding cap exceeded",
    "CAP_EXCEEDED_WALLET": "Wallet daily funding cap exceeded",
    "TRANSFER_FAILED": "On-chain transfer failed",
}


# -- Public types -----------------------------------------------------------


class FundedResponse(TypedDict):
    """Returned when the faucet successfully funded the wallet."""

    status: Literal["success"]
    tx_hash: str
    funded_amount: str


class SkippedResponse(TypedDict):
    """Returned when the wallet already has sufficient balance."""

    status: Literal["skipped"]
    current_balance: str
    min_gas_balance: str


FaucetFundResponse = FundedResponse | SkippedResponse


# -- Public function --------------------------------------------------------


def fund_from_gas_station(
    session: requests.Session,
    owner_address: str,
    target_wallet_address: str,
    chain_id: str,
    two_factor_code: str,
    faucet_base_url: str,
    request_id: str | None = None,
) -> FaucetFundResponse:
    """Request a funding transfer from the peaq gas station.

    Args:
        session: Reusable HTTP session (from ``PeaqosClient.session``).
        owner_address: 2FA-enrolled owner address.
        target_wallet_address: Machine wallet to fund.
        faucet_base_url: Absolute base URL of the gas station.
        two_factor_code: Current TOTP code from the authenticator app.
        chain_id: Target chain identifier (default ``"peaq"``).
        request_id: Idempotency key (UUID). Auto-generated if ``None``.

    Returns:
        A :class:`FundedResponse` on success or a :class:`SkippedResponse`
        when the wallet already has sufficient balance.

    Raises:
        ValidationError: If a required string parameter is empty.
        ApiError: On any documented faucet error code, an unexpected
            response envelope, or a network failure.

    Example::

        result = fund_from_gas_station(
            client.session,
            owner_address="5Grw...",
            target_wallet_address="0x19E7...",
            faucet_base_url="https://gas.peaq.network",
            two_factor_code="123456",
        )
        if result["status"] == "success":
            print("funded:", result["tx_hash"])
    """
    _require_non_empty("owner_address", owner_address)
    _require_non_empty("target_wallet_address", target_wallet_address)
    _require_non_empty("faucet_base_url", faucet_base_url)
    _require_non_empty("two_factor_code", two_factor_code)
    _require_non_empty("chain_id", chain_id)

    effective_request_id = request_id if request_id is not None else str(uuid.uuid4())

    url = _join_url(faucet_base_url, "/faucet/fund")

    try:
        response = session.post(
            url,
            json={
                "ownerAddress": owner_address,
                "targetWalletAddress": target_wallet_address,
                "chainId": chain_id,
                "twoFactorCode": two_factor_code,
                "requestId": effective_request_id,
            },
            timeout=30,
        )
    except requests.RequestException as err:
        raise ApiError(
            f"fund_from_gas_station: network request to {url} failed",
            code=_NETWORK_ERROR,
        ) from err

    body = _read_json(response, url)

    if not response.ok:
        raise _map_faucet_error(body, _FUND_ERRORS, "fund_from_gas_station")

    return _parse_fund_body(body)


# -- Private helpers --------------------------------------------------------


def _parse_fund_body(body: object) -> FaucetFundResponse:
    """Unwrap a 200-OK fund response into the SDK's typed union."""
    if not isinstance(body, dict):
        raise _envelope_error()

    data = body.get(_DATA)
    if not isinstance(data, dict):
        raise _envelope_error()

    status = body.get(_STATUS)
    code = body.get(_CODE)

    if status == _STATUS_SUCCESS and code == _CODE_SUCCESS:
        tx_hash = data.get("txHash")
        funded_amount = data.get("fundedAmount")
        if not isinstance(tx_hash, str) or not isinstance(funded_amount, str):
            raise _envelope_error()
        return FundedResponse(
            status="success",
            tx_hash=tx_hash,
            funded_amount=funded_amount,
        )

    if status == _STATUS_SKIPPED and code == _CODE_SUFFICIENT_BALANCE:
        current_balance = data.get("currentBalance")
        min_gas_balance = data.get("minGasBalance")
        if not isinstance(current_balance, str) or not isinstance(min_gas_balance, str):
            raise _envelope_error()
        return SkippedResponse(
            status="skipped",
            current_balance=current_balance,
            min_gas_balance=min_gas_balance,
        )

    raise _envelope_error()


def _envelope_error() -> ApiError:
    return ApiError(
        "fund_from_gas_station: unexpected response envelope",
        code=_UNEXPECTED_RESPONSE,
    )
