"""Self-managed machine registration on the IdentityRegistry."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..utils.transaction import parse_registered_log, send_and_await

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.registration.register_machine")

# 1 PEAQ in wei — minimum bond sent with the register() call.
_BOND_WEI = 10**18


def register_machine(client: PeaqosClient) -> int:
    """Register the caller as a machine on the IdentityRegistry.

    Calls the payable no-arg ``register()`` function on IdentityRegistry
    with 1 PEAQ attached as ``msg.value`` — the contract auto-bonds the
    machine internally as part of registration.  The contract assigns a
    fresh ``machineId`` and emits the ``Registered`` event, which this
    function decodes to return the new identity ID.

    .. note::

       Bonding happens via ``msg.value`` on the ``register()`` call
       itself — the SDK does **not** issue a separate
       ``IdentityStaking.stake(machine_id)`` transaction.  The
       ``IdentityStaking`` ABI exposes only ``stakeFor(uint256,address,uint256)``
       (an ERC20 token-based, nonpayable variant), which would require
       prior WPEAQ approval and cannot accept native PEAQ.  Native
       bonding through the payable ``register()`` is the contract's
       supported path.

    Args:
        client: Configured ``PeaqosClient`` whose signing key becomes
            the registered machine.

    Returns:
        The newly assigned ``machine_id`` as a positive ``int``.

    Raises:
        RpcError: If the machine is already registered
            (``AlreadyRegistered``), balance is insufficient for
            gas + 1 PEAQ bond, or the transaction reverts.

    Example::

        machine_id = register_machine(client)
        print(f"Registered with machine ID {machine_id}")
    """
    receipt = send_and_await(
        client.web3,
        client.account,
        client.identity_registry,
        "register",
        value_wei=_BOND_WEI,
    )
    return parse_registered_log(receipt, client.identity_registry)
