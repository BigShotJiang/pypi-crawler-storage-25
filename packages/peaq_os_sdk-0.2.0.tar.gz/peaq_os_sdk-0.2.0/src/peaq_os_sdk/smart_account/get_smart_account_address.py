"""Counterfactual preview of a CREATE2 smart-account address (view call)."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..abis import load_abi
from ..exceptions import RpcError
from ..types.primitives import Address
from ._internal.validate_params import validate_deploy_params

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.smart_account.get_smart_account_address")

INVALID_ADDRESS_RESULT = "INVALID_ADDRESS_RESULT"


def get_smart_account_address(
    client: PeaqosClient,
    owner: str,
    machine: str,
    salt: int,
) -> Address:
    """Compute the CREATE2 address for a smart account without deploying it.

    Calls the read-only ``MachineAccountFactory.getAddress(owner, machine,
    salt)`` view. The result is the same address
    :func:`deploy_smart_account` would produce for the same inputs —
    CREATE2 guarantees determinism — so callers can preview the address
    before committing gas for deployment.

    Args:
        client: Configured :class:`PeaqosClient`. Must carry a
            ``machine_account_factory`` contract address.
        owner: EOA that will own the smart account.
        machine: Machine EOA the account is scoped to.
        salt: Non-negative CREATE2 salt.

    Returns:
        The predicted :class:`Address` of the smart account.

    Raises:
        ValidationError: If any parameter fails validation, or the
            client has no ``machine_account_factory`` configured.
        RpcError: If the view call returns a value that is not a valid
            ``0x``-prefixed 20-byte hex address.

    Example::

        predicted = client.get_smart_account_address(
            owner=client.address,
            machine=machine_address,
            salt=0,
        )
    """
    (
        factory_address,
        validated_owner,
        validated_machine,
        validated_salt,
    ) = validate_deploy_params(
        client,
        owner=owner,
        machine=machine,
        salt=salt,
    )

    factory = client.web3.eth.contract(
        address=client.web3.to_checksum_address(factory_address),
        abi=load_abi("MachineAccountFactory"),
    )

    checksummed_owner = client.web3.to_checksum_address(validated_owner)
    checksummed_machine = client.web3.to_checksum_address(validated_machine)

    result: object = factory.functions.getAddress(
        checksummed_owner,
        checksummed_machine,
        validated_salt,
    ).call()

    if not isinstance(result, str) or not result.startswith("0x") or len(result) != 42:
        raise RpcError(
            "MachineAccountFactory.getAddress returned an invalid address",
            code=INVALID_ADDRESS_RESULT,
        )

    return Address(result)
