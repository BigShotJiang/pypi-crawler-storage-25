"""Parameter validation shared by ``deploy_smart_account`` / ``get_smart_account_address``."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, TypeGuard

from ...exceptions import ValidationError

if TYPE_CHECKING:
    from ...client import PeaqosClient

_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")


def _is_strict_int(value: object) -> TypeGuard[int]:
    """Int narrowing that rejects ``bool`` (an ``int`` subclass)."""
    return isinstance(value, int) and not isinstance(value, bool)


def validate_address(value: object, field: str) -> str:
    """Validate that *value* is a ``0x``-prefixed 20-byte hex address.

    Args:
        value: Raw input from the caller.
        field: Parameter name, surfaced in the raised error.

    Returns:
        The same address string — lowercase or checksummed — unchanged.

    Raises:
        ValidationError: If *value* is not a string matching the hex
            address pattern.
    """
    if not isinstance(value, str) or not _ADDRESS_RE.match(value):
        raise ValidationError(
            field=field,
            constraint="0x-prefixed 20-byte hex address",
            message=f"{field} must be a valid 0x-prefixed Ethereum address",
            value=value,
        )
    return value


def validate_positive_int(value: object, field: str) -> int:
    """Validate that *value* is an integer strictly greater than zero."""
    if not _is_strict_int(value) or value <= 0:
        raise ValidationError(
            field=field,
            constraint="positive integer",
            message=f"{field} must be a positive integer",
            value=value,
        )
    return value


def validate_non_negative_int(value: object, field: str) -> int:
    """Validate that *value* is an integer greater than or equal to zero."""
    if not _is_strict_int(value) or value < 0:
        raise ValidationError(
            field=field,
            constraint="non-negative integer",
            message=f"{field} must be a non-negative integer",
            value=value,
        )
    return value


def require_machine_account_factory(client: PeaqosClient) -> str:
    """Return the factory address or raise if the client was not configured with one.

    Args:
        client: Configured :class:`PeaqosClient`.

    Returns:
        The configured ``machine_account_factory`` address.

    Raises:
        ValidationError: If the client was built without a
            ``machine_account_factory`` address (or the
            ``MACHINE_ACCOUNT_FACTORY_ADDRESS`` env var).
    """
    factory = client.contracts.machine_account_factory
    if not factory:
        raise ValidationError(
            field="machine_account_factory",
            constraint="required for smart-account operations",
            message=(
                "PeaqosClient must be constructed with machine_account_factory "
                "(or MACHINE_ACCOUNT_FACTORY_ADDRESS env var) to deploy smart accounts"
            ),
            value=None,
        )
    return factory


def validate_deploy_params(
    client: PeaqosClient,
    *,
    owner: str,
    machine: str,
    salt: int,
) -> tuple[str, str, str, int]:
    """Validate every parameter accepted by the smart-account entry points.

    Args:
        client: Configured :class:`PeaqosClient`. Must have a
            ``machine_account_factory`` contract address.
        owner: EOA that will own the deployed smart account.
        machine: Machine EOA the account will be scoped to.
        salt: Non-negative CREATE2 salt.

    Returns:
        ``(factory, owner, machine, salt)`` — all validated.

    Raises:
        ValidationError: On any failed rule. ``field`` identifies which.
    """
    factory = require_machine_account_factory(client)
    validated_owner = validate_address(owner, "owner")
    validated_machine = validate_address(machine, "machine")
    validated_salt = validate_non_negative_int(salt, "salt")
    return (
        factory,
        validated_owner,
        validated_machine,
        validated_salt,
    )
