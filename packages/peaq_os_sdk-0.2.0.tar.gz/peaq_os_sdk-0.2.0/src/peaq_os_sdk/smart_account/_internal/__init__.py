"""Internal helpers for the smart_account subpackage (not part of public API)."""
