"""Deploy an ERC-4337 smart account via ``MachineAccountFactory.createAccount``."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from web3.logs import DISCARD
from web3.types import TxReceipt

from ..abis import load_abi
from ..exceptions import RpcError
from ..types.primitives import Address
from ..utils.transaction import send_and_await
from ._internal.validate_params import validate_deploy_params

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.smart_account.deploy_smart_account")

ACCOUNT_CREATED_EVENT_MISSING = "ACCOUNT_CREATED_EVENT_MISSING"
ACCOUNT_CREATED_EVENT_MALFORMED = "ACCOUNT_CREATED_EVENT_MALFORMED"


def deploy_smart_account(
    client: PeaqosClient,
    owner: str,
    machine: str,
    salt: int,
) -> Address:
    """Deploy an ERC-4337 smart account for *machine* owned by *owner*.

    Sends ``MachineAccountFactory.createAccount(owner, machine,
    salt)``, waits for the receipt, and decodes the
    ``AccountCreated`` event to return the deployed account's address.
    The triple ``(owner, machine, salt)`` is deterministic
    under CREATE2: the same arguments always resolve to the same address.

    Args:
        client: Configured :class:`PeaqosClient`. Must carry a
            ``machine_account_factory`` contract address.
        owner: EOA that will own the deployed smart account.
        machine: Machine EOA the account is scoped to.
        salt: Non-negative CREATE2 salt.

    Returns:
        The deployed smart-account :class:`Address`.

    Raises:
        ValidationError: If any parameter fails validation, or if the
            client has no ``machine_account_factory`` configured.
        RpcError: On transaction revert, or when the
            ``AccountCreated`` event is missing or malformed on the
            resulting receipt.

    Example::

        address = client.deploy_smart_account(
            owner="0xabc...", machine="0xdef...",
            salt=0,
        )
        print("Deployed at", address)
    """
    (
        factory_address,
        validated_owner,
        validated_machine,
        validated_salt,
    ) = validate_deploy_params(
        client,
        owner=owner,
        machine=machine,
        salt=salt,
    )

    factory = client.web3.eth.contract(
        address=client.web3.to_checksum_address(factory_address),
        abi=load_abi("MachineAccountFactory"),
    )

    checksummed_owner = client.web3.to_checksum_address(validated_owner)
    checksummed_machine = client.web3.to_checksum_address(validated_machine)

    receipt = send_and_await(
        client.web3,
        client.account,
        factory,
        "createAccount",
        args=[checksummed_owner, checksummed_machine, validated_salt],
    )

    return _decode_account_created(receipt, factory)


def _decode_account_created(receipt: TxReceipt, factory: Any) -> Address:
    """Parse the ``AccountCreated`` event from *receipt* to extract the address."""
    events = factory.events.AccountCreated().process_receipt(receipt, errors=DISCARD)
    if not events:
        raise RpcError(
            "No AccountCreated event found in transaction receipt",
            code=ACCOUNT_CREATED_EVENT_MISSING,
        )

    account_field: object = events[0]["args"]["account"]
    if (
        not isinstance(account_field, str)
        or not account_field.startswith("0x")
        or len(account_field) != 42
    ):
        raise RpcError(
            "AccountCreated event has a malformed account address",
            code=ACCOUNT_CREATED_EVENT_MALFORMED,
        )

    return Address(account_field)
