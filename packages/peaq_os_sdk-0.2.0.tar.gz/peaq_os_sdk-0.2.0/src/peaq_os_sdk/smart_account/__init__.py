"""peaq_os_sdk.smart_account — ERC-4337 smart account deployment."""

from __future__ import annotations

from .deploy_smart_account import deploy_smart_account
from .get_smart_account_address import get_smart_account_address

__all__: list[str] = ["deploy_smart_account", "get_smart_account_address"]
