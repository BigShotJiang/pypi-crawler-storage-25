"""Skill catalog functions — list, get manifest, and update configuration.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_GET, HTTP_METHOD_PATCH
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.skill import (
    SkillConfigResponse,
    SkillDirection,
    SkillManifest,
    SkillManifestInput,
    SkillManifestOutput,
    SkillScope,
    SkillSource,
    SkillSummary,
    UpdateSkillConfigRequest,
)

from ._internal.helpers import (
    assert_non_empty_string,
    external_handoff_from_wire,
    strip_nones,
    to_transport_config,
)
from .errors import OrchestrationApiError
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    AuthPlatform,
    _sanitize_body,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "ListSkillsOptions",
    "get_skill",
    "get_skill_manifest",
    "list_skills",
    "list_skills_all",
    "update_skill_config",
]

FIELD_SKILL_KEY = "skill_key"


@dataclass(frozen=True, slots=True)
class ListSkillsOptions:
    """Optional filters for :func:`list_skills`.

    Experimental: the orchestration API is under active development.
    """

    scope: SkillScope | None = None
    direction: SkillDirection | None = None
    source: SkillSource | None = None


def _skill_summary_from_wire(data: Mapping[str, Any]) -> SkillSummary:
    return SkillSummary(
        key=data["key"],
        provider_key=data["provider_key"],
        label=data["label"],
        description=data["description"],
        direction=data["direction"],
        scope=data["scope"],
        source=data["source"],
        listed_by=data["listed_by"],
        last_verified_at=data.get("last_verified_at"),
        kind=data["kind"],
        service_types=tuple(data.get("service_types") or ()),
        operations=tuple(data.get("operations") or ()),
        auth_type=data["auth_type"],
        auth_state=data["auth_state"],
        access_mode=data["access_mode"],
        distribution=data["distribution"],
        maturity=data["maturity"],
        execution_mode=data["execution_mode"],
        integration_status=data["integration_status"],
        required_env=tuple(data.get("required_env") or ()),
        requires_human_enablement=data["requires_human_enablement"],
        reference_url=data.get("reference_url"),
        artifact_url=data.get("artifact_url"),
        handoff=external_handoff_from_wire(data.get("handoff")),
    )


def _manifest_input_from_wire(data: Mapping[str, Any]) -> SkillManifestInput:
    return SkillManifestInput(
        key=data["key"],
        type=data["type"],
        required=data["required"],
        description=data["description"],
    )


def _manifest_output_from_wire(data: Mapping[str, Any]) -> SkillManifestOutput:
    return SkillManifestOutput(
        key=data["key"],
        type=data["type"],
        description=data["description"],
    )


def _skill_manifest_from_wire(data: Mapping[str, Any]) -> SkillManifest:
    ins = data["inputs"]
    outs = data["outputs"]
    if not isinstance(ins, list):
        raise TypeError("expected list for manifest inputs")
    if not isinstance(outs, list):
        raise TypeError("expected list for manifest outputs")
    return SkillManifest(
        key=data["key"],
        provider_key=data["provider_key"],
        label=data["label"],
        summary=data["summary"],
        inputs=tuple(_manifest_input_from_wire(x) for x in ins),
        outputs=tuple(_manifest_output_from_wire(x) for x in outs),
    )


def _skill_config_response_from_wire(data: Mapping[str, Any]) -> SkillConfigResponse:
    return SkillConfigResponse(
        skill_key=data["skill_key"],
        provider_key=data["provider_key"],
        enabled=data["enabled"],
        settings=dict(data.get("settings") or {}),
        has_credentials=data["has_credentials"],
        updated_at=data["updated_at"],
    )


def list_skills(
    client: PeaqosClient,
    options: ListSkillsOptions | None = None,
    *,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[SkillSummary]:
    """List skills available in the orchestration system.

    Endpoint: ``GET /skills``
    Auth: platform (``x-api-key``)

    Optional query filters: ``scope``, ``direction``, ``source``.

    Experimental: the orchestration API is under active development.

    Args:
        client: The SDK client instance.
        options: Optional filter parameters (``scope``, ``direction``, ``source``).
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
    """
    extra: dict[str, str] = {}
    if options is not None:
        if options.scope is not None:
            extra["scope"] = options.scope
        if options.direction is not None:
            extra["direction"] = options.direction
        if options.source is not None:
            extra["source"] = options.source

    query = pagination_query_params(limit=limit, cursor=cursor, extra=extra or None)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        "/skills",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_skill_summary_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_skills_all(
    client: PeaqosClient,
    options: ListSkillsOptions | None = None,
    *,
    limit: int | None = None,
) -> Generator[SkillSummary, None, None]:
    """Iterate over every skill summary across all pages.

    Convenience wrapper around :func:`list_skills` that traverses ``next_cursor``
    pages and yields one :class:`SkillSummary` at a time. ``options`` filters are
    forwarded on every page call.

    Args:
        client: The SDK client instance.
        options: Optional filter parameters (``scope``, ``direction``, ``source``),
            forwarded on every page.
        limit: Optional per-page size (``1``..``500``).

    Yields:
        Each :class:`SkillSummary` from every page in order.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_skills(client, options, limit=limit, cursor=cursor)
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def get_skill(client: PeaqosClient, skill_key: str) -> ItemResponse[SkillSummary]:
    """Retrieve a single skill by key.

    Endpoint: ``GET /skills/:skillKey``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(skill_key, FIELD_SKILL_KEY)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/skills/{skill_key}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_skill_summary_from_wire(item))


def get_skill_manifest(client: PeaqosClient, skill_key: str) -> ItemResponse[SkillManifest]:
    """Retrieve the full manifest for a skill (inputs and outputs).

    Endpoint: ``GET /skills/:skillKey/manifest``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(skill_key, FIELD_SKILL_KEY)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/skills/{skill_key}/manifest",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_skill_manifest_from_wire(item))


def update_skill_config(
    client: PeaqosClient,
    skill_key: str,
    params: UpdateSkillConfigRequest,
) -> ItemResponse[SkillConfigResponse]:
    """Update a skill's machine configuration (partial update).

    ``credentials`` values are secrets; when the API returns an error with a
    structured ``details`` payload, values under keys matching the transport
    sensitive patterns (e.g. ``credential``) are redacted before re-raising.

    Endpoint: ``PATCH /skills/:skillKey/config``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(skill_key, FIELD_SKILL_KEY)

    try:
        raw = api_request(
            to_transport_config(client),
            client.session,
            HTTP_METHOD_PATCH,
            f"/skills/{skill_key}/config",
            RESPONSE_SHAPE_ITEM,
            auth=AuthPlatform(),
            body=strip_nones(asdict(params)),
        )
    except OrchestrationApiError as err:
        if err.details is not None:
            raise OrchestrationApiError(
                str(err),
                err.code,
                err.status_code,
                _sanitize_body(err.details),
            ) from err
        raise

    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_skill_config_response_from_wire(item))
