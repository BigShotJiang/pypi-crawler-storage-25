"""Orchestration namespace — entry point for orchestration service interactions.

Accessed via :attr:`PeaqosClient.orchestration`. This object holds a reference to
the parent client and delegates to feature modules for HTTP endpoints.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator
from typing import TYPE_CHECKING

from peaq_os_sdk.types.orchestration.agent_pairing import (
    AgentPairing,
    AgentPairingChallengeResponse,
    CreateAgentPairingChallengeRequest,
    CreateAgentPairingRequest,
    CreateAgentPairingSessionRequest,
    UpdateAgentPairingRequest,
)
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.machine import (
    CreateMachineIdentityChallengeRequest,
    CreateMachineRequest,
    Machine,
    MachineIdentityChallengeResponse,
    UpdateMachineRequest,
)
from peaq_os_sdk.types.orchestration.machine_agent import (
    EnrollMachineAgentRequest,
    MachineAgent,
    MachineAgentHeartbeatRequest,
    MachineAgentHeartbeatResponse,
)
from peaq_os_sdk.types.orchestration.market_order import (
    ConfirmMarketOrderResponse,
    CreateMarketOrderRequest,
    DisputeMarketOrderRequest,
    DisputeMarketOrderResponse,
    ExecuteMarketOrderRequest,
    ExecuteMarketOrderResponse,
    MarketOrder,
)
from peaq_os_sdk.types.orchestration.market_search import MarketSearch, MarketSearchRequest
from peaq_os_sdk.types.orchestration.market_service import MarketService
from peaq_os_sdk.types.orchestration.payment import (
    CreatePaymentIntentRequest,
    LockEscrowPaymentRequest,
    MarketPayment,
    RefundPaymentRequest,
    ReleasePaymentRequest,
    SubmitPaymentProofRequest,
)
from peaq_os_sdk.types.orchestration.runtime_endpoint import (
    RuntimeEndpoint,
    UpsertRuntimeEndpointRequest,
)
from peaq_os_sdk.types.orchestration.skill import (
    SkillConfigResponse,
    SkillManifest,
    SkillSummary,
    UpdateSkillConfigRequest,
)

from .agent_pairings import (
    create_agent_pairing,
    create_agent_pairing_challenge,
    create_agent_pairing_session,
    list_agent_pairings,
    list_agent_pairings_all,
    revoke_agent_pairing,
    update_agent_pairing,
)
from .machine_agents import (
    enroll_machine_agent,
    list_machine_agents,
    machine_agent_heartbeat,
    revoke_machine_agent,
)
from .machine_identity import create_machine_identity_challenge
from .machines import (
    archive_machine,
    create_machine,
    get_machine,
    list_machines,
    list_machines_all,
    update_machine,
)
from .market_orders import (
    confirm_market_order,
    create_market_order,
    create_payment_intent,
    dispute_market_order,
    execute_market_order,
    get_market_order,
    get_market_payment,
    list_market_orders,
    list_market_orders_all,
)
from .market_search import get_market_search, search_market
from .market_services import (
    GetMarketServiceOptions,
    ListMarketServicesOptions,
    get_market_service,
    list_market_services,
    list_market_services_all,
)
from .payments import (
    lock_escrow_payment,
    refund_payment,
    release_payment,
    submit_payment_proof,
)
from .runtime_endpoints import (
    delete_runtime_endpoint,
    get_runtime_endpoint,
    list_runtime_endpoints,
    list_runtime_endpoints_all,
    upsert_runtime_endpoint,
)
from .skills import (
    ListSkillsOptions,
    get_skill,
    get_skill_manifest,
    list_skills,
    list_skills_all,
    update_skill_config,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient


class OrchestrationNamespace:
    """Namespace for orchestration (Machine Markets) HTTP APIs.

    Accessed via :attr:`PeaqosClient.orchestration`. Delegates to feature modules
    for each endpoint.
    """

    __slots__ = ("_client",)

    def __init__(self, client: PeaqosClient) -> None:
        self._client = client

    @property
    def client(self) -> PeaqosClient:
        """Parent client used for transport configuration in feature modules."""
        return self._client

    def list_machines(
        self,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[Machine]:
        """List machines visible to the authenticated platform account.

        Endpoint: ``GET /machines``
        Auth: platform (``x-api-key``)

        Args:
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of machines.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors (``NOT_FOUND``, ``AUTH_REQUIRED``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return list_machines(self._client, limit=limit, cursor=cursor)

    def list_machines_all(
        self,
        *,
        limit: int | None = None,
    ) -> Generator[Machine, None, None]:
        """Iterate over every machine across all pages.

        Convenience wrapper around :meth:`list_machines` that transparently
        traverses pages via ``next_cursor`` and yields one machine at a time.

        Args:
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each machine from every page in order.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_machines_all(self._client, limit=limit)

    def create_machine(self, params: CreateMachineRequest) -> ItemResponse[Machine]:
        """Create a new machine in the orchestration system.

        Endpoint: ``POST /machines``
        Auth: platform (``x-api-key``)

        Args:
            params: Machine creation parameters. ``display_name`` and ``owner_id``
                are required.

        Returns:
            The newly created machine wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``display_name`` or ``owner_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return create_machine(self._client, params)

    def create_machine_identity_challenge(
        self,
        params: CreateMachineIdentityChallengeRequest,
    ) -> ItemResponse[MachineIdentityChallengeResponse]:
        """Request a machine identity challenge for EIP-191 signing.

        Sign the returned ``message`` off-band and pass
        :class:`~peaq_os_sdk.types.orchestration.MachineIdentityProofInput` as
        ``identity_proof`` in :meth:`create_machine`.

        Endpoint: ``POST /machine-identity/challenges``
        Auth: platform (``x-api-key``)

        Args:
            params: Challenge request with ``identity_ref``.

        Returns:
            The challenge with a ``message`` to sign and a ``challenge_id``.

        Raises:
            OrchestrationValidationError: If required fields are empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return create_machine_identity_challenge(self._client, params)

    def get_machine(self, machine_id: str) -> ItemResponse[Machine]:
        """Retrieve a single machine by id.

        Endpoint: ``GET /machines/:machineId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The machine's unique identifier.

        Returns:
            The machine wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_machine(self._client, machine_id)

    def update_machine(
        self,
        machine_id: str,
        params: UpdateMachineRequest,
    ) -> ItemResponse[Machine]:
        """Update an existing machine (partial update).

        Endpoint: ``PATCH /machines/:machineId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The machine's unique identifier.
            params: Partial update payload — only supplied fields are changed.

        Returns:
            The updated machine wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return update_machine(self._client, machine_id, params)

    def archive_machine(self, machine_id: str) -> None:
        """Archive (soft-delete) a machine.

        The server returns 204 No Content.

        Endpoint: ``DELETE /machines/:machineId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The machine's unique identifier.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return archive_machine(self._client, machine_id)

    def list_machine_agents(self, machine_id: str) -> ListResponse[MachineAgent]:
        """List agents enrolled on a machine.

        Endpoint: ``GET /machines/:machineId/agents``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.

        Returns:
            A paginated list of machine agents.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return list_machine_agents(self._client, machine_id)

    def enroll_machine_agent(
        self,
        machine_id: str,
        params: EnrollMachineAgentRequest | None = None,
    ) -> ItemResponse[MachineAgent]:
        """Enroll a machine-side runtime agent.

        Endpoint: ``POST /machines/:machineId/agents``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            params: Optional enrollment parameters.

        Returns:
            The enrolled agent wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return enroll_machine_agent(self._client, machine_id, params)

    def revoke_machine_agent(self, machine_id: str, agent_id: str) -> None:
        """Revoke a machine-side runtime agent.

        The server returns 204 No Content.

        Endpoint: ``DELETE /machines/:machineId/agents/:agentId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            agent_id: The agent's unique identifier.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``agent_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return revoke_machine_agent(self._client, machine_id, agent_id)

    def machine_agent_heartbeat(
        self,
        params: MachineAgentHeartbeatRequest,
    ) -> MachineAgentHeartbeatResponse:
        """Send a machine agent heartbeat.

        Authenticates via ``agent_token`` in the request body (not a header).

        Endpoint: ``POST /machine-agents/heartbeat``
        Auth: none (``agent_token`` in body)

        Args:
            params: Heartbeat payload including ``agent_token``.

        Returns:
            Heartbeat acknowledgment with endpoint probe results.

        Raises:
            OrchestrationValidationError: If required fields are empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return machine_agent_heartbeat(self._client, params)

    def list_agent_pairings(
        self,
        machine_id: str,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[AgentPairing]:
        """List agent pairings for a machine.

        Endpoint: ``GET /machines/:machineId/agent-pairings``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of agent pairings.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
                outside ``1``..``500``.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return list_agent_pairings(
            self._client,
            machine_id,
            limit=limit,
            cursor=cursor,
        )

    def list_agent_pairings_all(
        self,
        machine_id: str,
        *,
        limit: int | None = None,
    ) -> Generator[AgentPairing, None, None]:
        """Iterate over every agent pairing on a machine across all pages.

        Args:
            machine_id: The parent machine's identifier (forwarded on every page).
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each agent pairing from every page in order.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit``
                is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_agent_pairings_all(self._client, machine_id, limit=limit)

    def create_agent_pairing(
        self,
        machine_id: str,
        params: CreateAgentPairingRequest,
    ) -> ItemResponse[AgentPairing]:
        """Create an agent pairing.

        The response includes a one-time ``pairing_token`` — store it securely.

        Endpoint: ``POST /machines/:machineId/agent-pairings``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            params: Pairing parameters — ``agent_address``, ``agent_provider``,
                ``agent_role``, and ``agent_proof`` are required.

        Returns:
            The newly created pairing wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If required fields are empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return create_agent_pairing(self._client, machine_id, params)

    def create_agent_pairing_challenge(
        self,
        machine_id: str,
        params: CreateAgentPairingChallengeRequest,
    ) -> ItemResponse[AgentPairingChallengeResponse]:
        """Request an agent pairing challenge for EIP-191 signing.

        Sign the returned ``message`` and pass
        :class:`~peaq_os_sdk.types.orchestration.AgentProofInput` as ``agent_proof``
        in :meth:`create_agent_pairing`.

        Endpoint: ``POST /machines/:machineId/agent-pairings/challenges``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            params: Challenge request with ``agent_address``, ``agent_provider``,
                and ``agent_role``.

        Returns:
            The challenge with a ``message`` to sign and a ``challenge_id``.

        Raises:
            OrchestrationValidationError: If required fields are empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return create_agent_pairing_challenge(self._client, machine_id, params)

    def create_agent_pairing_session(
        self,
        machine_id: str,
        pairing_id: str,
        params: CreateAgentPairingSessionRequest,
    ) -> ItemResponse[AgentPairing]:
        """Issue a fresh pairing token for an existing active pairing.

        The response includes a new ``pairing_token`` — store it securely.

        Endpoint: ``POST /machines/:machineId/agent-pairings/:pairingId/sessions``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            pairing_id: The agent pairing's unique identifier.
            params: Session request with ``agent_proof`` containing the signed challenge.

        Returns:
            The agent pairing with a fresh ``pairing_token``.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``pairing_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return create_agent_pairing_session(self._client, machine_id, pairing_id, params)

    def update_agent_pairing(
        self,
        machine_id: str,
        pairing_id: str,
        params: UpdateAgentPairingRequest,
    ) -> ItemResponse[AgentPairing]:
        """Update an agent pairing.

        Only the provided fields are changed.

        Endpoint: ``PATCH /machines/:machineId/agent-pairings/:pairingId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            pairing_id: The agent pairing's unique identifier.
            params: Partial update payload.

        Returns:
            The updated agent pairing wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``pairing_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return update_agent_pairing(self._client, machine_id, pairing_id, params)

    def revoke_agent_pairing(self, machine_id: str, pairing_id: str) -> None:
        """Revoke an agent pairing.

        The server returns 204 No Content.

        Endpoint: ``DELETE /machines/:machineId/agent-pairings/:pairingId``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            pairing_id: The agent pairing's unique identifier.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``pairing_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return revoke_agent_pairing(self._client, machine_id, pairing_id)

    def list_runtime_endpoints(
        self,
        machine_id: str,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[RuntimeEndpoint]:
        """List runtime endpoints registered on a machine.

        Endpoint: ``GET /machines/:machineId/runtime-endpoints``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of runtime endpoints.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
                outside ``1``..``500``.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return list_runtime_endpoints(
            self._client,
            machine_id,
            limit=limit,
            cursor=cursor,
        )

    def list_runtime_endpoints_all(
        self,
        machine_id: str,
        *,
        limit: int | None = None,
    ) -> Generator[RuntimeEndpoint, None, None]:
        """Iterate over every runtime endpoint on a machine across all pages.

        Args:
            machine_id: The parent machine's identifier (forwarded on every page).
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each runtime endpoint from every page in order.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit``
                is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_runtime_endpoints_all(self._client, machine_id, limit=limit)

    def get_runtime_endpoint(
        self,
        machine_id: str,
        provider_key: str,
    ) -> ItemResponse[RuntimeEndpoint]:
        """Retrieve a runtime endpoint by provider key.

        Endpoint: ``GET /machines/:machineId/runtime-endpoints/:providerKey``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            provider_key: The endpoint's provider key (e.g. ``"qvac"``).

        Returns:
            The runtime endpoint wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``provider_key`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_runtime_endpoint(self._client, machine_id, provider_key)

    def upsert_runtime_endpoint(
        self,
        machine_id: str,
        provider_key: str,
        params: UpsertRuntimeEndpointRequest,
    ) -> ItemResponse[RuntimeEndpoint]:
        """Create or update a runtime endpoint on a machine.

        If ``auth_token`` is provided it is redacted in error context by the
        transport layer. ``endpoint_base_url`` must be a valid URL.

        Endpoint: ``PUT /machines/:machineId/runtime-endpoints/:providerKey``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            provider_key: The endpoint's provider key.
            params: Upsert payload — ``endpoint_base_url`` is required.

        Returns:
            The created or updated runtime endpoint wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If identifiers are empty or the URL is invalid.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return upsert_runtime_endpoint(self._client, machine_id, provider_key, params)

    def delete_runtime_endpoint(self, machine_id: str, provider_key: str) -> None:
        """Delete a runtime endpoint.

        The server returns 204 No Content.

        Endpoint: ``DELETE /machines/:machineId/runtime-endpoints/:providerKey``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: The parent machine's identifier.
            provider_key: The endpoint's provider key.

        Raises:
            OrchestrationValidationError: If ``machine_id`` or ``provider_key`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return delete_runtime_endpoint(self._client, machine_id, provider_key)

    def list_skills(
        self,
        options: ListSkillsOptions | None = None,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[SkillSummary]:
        """List skills available in the orchestration system.

        Endpoint: ``GET /skills``
        Auth: platform (``x-api-key``)

        Args:
            options: Optional filter parameters (``scope``, ``direction``, ``source``).
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of skill summaries.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors (``AUTH_REQUIRED``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return list_skills(self._client, options, limit=limit, cursor=cursor)

    def list_skills_all(
        self,
        options: ListSkillsOptions | None = None,
        *,
        limit: int | None = None,
    ) -> Generator[SkillSummary, None, None]:
        """Iterate over every skill summary across all pages.

        Args:
            options: Optional filter parameters (``scope``, ``direction``,
                ``source``), forwarded on every page.
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each skill summary from every page in order.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_skills_all(self._client, options, limit=limit)

    def get_skill(self, skill_key: str) -> ItemResponse[SkillSummary]:
        """Retrieve a skill summary by key.

        Endpoint: ``GET /skills/:skillKey``
        Auth: platform (``x-api-key``)

        Args:
            skill_key: The skill's unique key.

        Returns:
            The skill summary wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``skill_key`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_skill(self._client, skill_key)

    def get_skill_manifest(self, skill_key: str) -> ItemResponse[SkillManifest]:
        """Retrieve the full manifest for a skill, including input and output schema.

        Endpoint: ``GET /skills/:skillKey/manifest``
        Auth: platform (``x-api-key``)

        Args:
            skill_key: The skill's unique key.

        Returns:
            The skill manifest wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``skill_key`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_skill_manifest(self._client, skill_key)

    def update_skill_config(
        self,
        skill_key: str,
        params: UpdateSkillConfigRequest,
    ) -> ItemResponse[SkillConfigResponse]:
        """Update a skill's machine configuration.

        ``credentials`` values are redacted in error context by the transport layer.
        Only the provided fields are changed.

        Endpoint: ``PATCH /skills/:skillKey/config``
        Auth: platform (``x-api-key``)

        Args:
            skill_key: The skill's unique key.
            params: Configuration update — optional ``enabled``, ``credentials``, ``settings``.

        Returns:
            The updated skill configuration wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``skill_key`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, ``VALIDATION_ERROR``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return update_skill_config(self._client, skill_key, params)

    def list_market_services(
        self,
        options: ListMarketServicesOptions | None = None,
        *,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[MarketService]:
        """List services available in the market catalog.

        Endpoint: ``GET /market/services``
        Auth: platform (``x-api-key``)

        Args:
            options: Optional filters (``machine_id``, ``service_type``,
                ``execution_mode``, ``provider_key``).
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of market services.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors (``AUTH_REQUIRED``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return list_market_services(
            self._client,
            options,
            limit=limit,
            cursor=cursor,
        )

    def list_market_services_all(
        self,
        options: ListMarketServicesOptions | None = None,
        *,
        limit: int | None = None,
    ) -> Generator[MarketService, None, None]:
        """Iterate over every market service across all pages.

        Args:
            options: Optional filters (``machine_id``, ``service_type``,
                ``execution_mode``, ``provider_key``), forwarded on every page.
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each market service from every page in order.

        Raises:
            OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_market_services_all(self._client, options, limit=limit)

    def get_market_service(
        self,
        service_id: str,
        options: GetMarketServiceOptions | None = None,
    ) -> ItemResponse[MarketService]:
        """Retrieve a single market service by id.

        Endpoint: ``GET /market/services/:serviceId``
        Auth: platform (``x-api-key``)

        Args:
            service_id: The service's unique identifier.
            options: Optional parameters (``machine_id``).

        Returns:
            The market service wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``service_id`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_market_service(self._client, service_id, options)

    def search_market(
        self,
        params: MarketSearchRequest,
        pairing_token: str,
    ) -> ItemResponse[MarketSearch]:
        """Initiate a market search and return scored quotes.

        Authentication uses the agent-pairing token in the ``x-agent-pairing-token``
        header.

        Endpoint: ``POST /market/search``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            params: Search parameters — optional ``machine_id``, ``service_type``,
                ``operation``, ``required_capabilities``, ``region``, ``max_results``,
                ``allow_external_handoff``, ``require_native_execution``, ``budget``.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The search result with quotes, wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``pairing_token`` is empty.
            OrchestrationApiError: On server errors (``AGENT_AUTH_REQUIRED``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return search_market(self._client, params, pairing_token)

    def get_market_search(self, search_id: str) -> ItemResponse[MarketSearch]:
        """Retrieve a previously completed market search by id.

        Endpoint: ``GET /market/searches/:searchId``
        Auth: platform (``x-api-key``)

        Args:
            search_id: The search's unique identifier.

        Returns:
            The search result with quotes, wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``search_id`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_market_search(self._client, search_id)

    def list_market_orders(
        self,
        *,
        machine_id: str,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ListResponse[MarketOrder]:
        """List market orders for a machine.

        Endpoint: ``GET /market/orders``
        Auth: platform (``x-api-key``)

        Args:
            machine_id: Machine whose orders to list (required query parameter).
            limit: Optional page size (``1``..``500``).
            cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
                first page.

        Returns:
            A paginated list of market orders.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
                outside ``1``..``500``.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return list_market_orders(
            self._client,
            machine_id=machine_id,
            limit=limit,
            cursor=cursor,
        )

    def list_market_orders_all(
        self,
        *,
        machine_id: str,
        limit: int | None = None,
    ) -> Generator[MarketOrder, None, None]:
        """Iterate over every market order for a machine across all pages.

        Args:
            machine_id: Machine whose orders to iterate (forwarded on every page).
            limit: Optional per-page size (``1``..``500``).

        Yields:
            Each market order from every page in order.

        Raises:
            OrchestrationValidationError: If ``machine_id`` is empty or ``limit``
                is outside ``1``..``500``.
            OrchestrationApiError: On server errors during any page fetch.
            OrchestrationNetworkError: On network failures during any page fetch.
        """
        return list_market_orders_all(
            self._client,
            machine_id=machine_id,
            limit=limit,
        )

    def create_market_order(
        self,
        params: CreateMarketOrderRequest,
        pairing_token: str,
    ) -> ItemResponse[MarketOrder]:
        """Create a market order from a search result or quote.

        ``provider_credentials`` values are redacted in error context by the
        transport layer when a request fails.

        Endpoint: ``POST /market/orders``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            params: Order creation parameters — ``machine_id``, ``agent_pairing_id``,
                and ``service_id`` are required.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The created order wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If required fields or ``pairing_token`` are empty.
            OrchestrationApiError: On server errors (
                ``QUOTE_EXPIRED``, ``AGENT_AUTH_REQUIRED``, etc.
            ).
            OrchestrationNetworkError: On network failures.
        """
        return create_market_order(self._client, params, pairing_token)

    def get_market_order(self, order_id: str) -> ItemResponse[MarketOrder]:
        """Retrieve a single market order by id.

        Endpoint: ``GET /market/orders/:orderId``
        Auth: platform (``x-api-key``)

        Args:
            order_id: The order's unique identifier.

        Returns:
            The market order wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` is empty.
            OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return get_market_order(self._client, order_id)

    def create_payment_intent(
        self,
        order_id: str,
        params: CreatePaymentIntentRequest,
        pairing_token: str,
    ) -> ItemResponse[MarketPayment]:
        """Create a payment intent for a market order.

        Endpoint: ``POST /market/orders/:orderId/payment-intent``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Payment intent parameters (optional ``amount``, ``currency``, ``rail``).
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The payment record wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors (``PAYMENT_REQUIRED``, ``ORDER_CLOSED``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return create_payment_intent(self._client, order_id, params, pairing_token)

    def get_market_payment(self, order_id: str) -> ItemResponse[MarketPayment | None]:
        """Retrieve the payment record for a market order.

        The response ``item`` may be ``None`` when no payment exists for the order.

        Endpoint: ``GET /market/orders/:orderId/payment``
        Auth: platform (``x-api-key``)

        Args:
            order_id: The order's unique identifier.

        Returns:
            The payment record (or ``None``) wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return get_market_payment(self._client, order_id)

    def execute_market_order(
        self,
        order_id: str,
        params: ExecuteMarketOrderRequest,
        pairing_token: str,
    ) -> ExecuteMarketOrderResponse:
        """Execute a market order.

        Returns a native execution response (HTTP 200) or an external handoff
        response (HTTP 202). The result is a discriminated union on
        ``execution.status_code`` — see
        :data:`~peaq_os_sdk.types.orchestration.ExecuteMarketOrderResponse`.

        Endpoint: ``POST /market/orders/:orderId/execute``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Optional execution input (e.g. ``input={"symbol": "BTC/USD"}``).
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The execution response with ``order`` and ``execution`` details.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors (``EXECUTION_UNSUPPORTED``,
                ``PAYMENT_REQUIRED``, ``ORDER_CLOSED``, etc.) or invalid response shape.
            OrchestrationNetworkError: On network failures.
        """
        return execute_market_order(self._client, order_id, params, pairing_token)

    def confirm_market_order(
        self,
        order_id: str,
        pairing_token: str,
    ) -> ConfirmMarketOrderResponse:
        """Confirm delivery of a market order.

        When payment is required, the associated payment moves to ``release_pending``.

        Endpoint: ``POST /market/orders/:orderId/confirm``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The confirmation response with ``order`` and ``payment``.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors (
                ``ORDER_CLOSED``, ``ORDER_NOT_DELIVERED``, etc.
            ).
            OrchestrationNetworkError: On network failures.
        """
        return confirm_market_order(self._client, order_id, pairing_token)

    def dispute_market_order(
        self,
        order_id: str,
        params: DisputeMarketOrderRequest,
        pairing_token: str,
    ) -> DisputeMarketOrderResponse:
        """Dispute a market order.

        The payment moves to ``frozen``.

        Endpoint: ``POST /market/orders/:orderId/dispute``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Dispute parameters — ``reason`` is required.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The dispute response with ``order``, ``payment``, and ``dispute``.

        Raises:
            OrchestrationValidationError: If ``order_id``, ``reason``, or
                ``pairing_token`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return dispute_market_order(self._client, order_id, params, pairing_token)

    def submit_payment_proof(
        self,
        order_id: str,
        params: SubmitPaymentProofRequest,
        pairing_token: str,
    ) -> ItemResponse[MarketPayment]:
        """Submit a payment proof after a payment intent is created.

        Supports EVM proofs (``transaction_hash``) and Solana proofs
        (``transaction_signature``) with ``verification_mode`` ``"recorded"`` or
        ``"rpc"``.

        Endpoint: ``POST /market/orders/:orderId/payment-proof``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Proof parameters.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The updated payment record wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors (``PAYMENT_RPC_ERROR``,
                ``PAYMENT_TRANSFER_NOT_FOUND``, etc.).
            OrchestrationNetworkError: On network failures.
        """
        return submit_payment_proof(self._client, order_id, params, pairing_token)

    def lock_escrow_payment(
        self,
        order_id: str,
        params: LockEscrowPaymentRequest,
        pairing_token: str,
    ) -> ItemResponse[MarketPayment]:
        """Lock funds in escrow for a market order's payment.

        Endpoint: ``POST /market/orders/:orderId/payment/escrow-lock``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Escrow lock parameters — ``transaction_hash``, ``chain``, and
                ``escrow_address`` are required.
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The updated payment record wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If required fields are empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return lock_escrow_payment(self._client, order_id, params, pairing_token)

    def release_payment(
        self,
        order_id: str,
        params: ReleasePaymentRequest | None,
        pairing_token: str,
    ) -> ItemResponse[MarketPayment]:
        """Release payment to the provider after order confirmation.

        Pass ``None`` for ``params`` to omit a request body.

        Endpoint: ``POST /market/orders/:orderId/payment/release``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Optional release parameters (``transaction_hash``, ``notes``).
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The updated payment record wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return release_payment(self._client, order_id, params, pairing_token)

    def refund_payment(
        self,
        order_id: str,
        params: RefundPaymentRequest | None,
        pairing_token: str,
    ) -> ItemResponse[MarketPayment]:
        """Refund a payment for a market order.

        Pass ``None`` for ``params`` to omit a request body.

        Endpoint: ``POST /market/orders/:orderId/payment/refund``
        Auth: agent-pairing (``x-agent-pairing-token``)

        Args:
            order_id: The order's unique identifier.
            params: Optional refund parameters (``transaction_hash``, ``reason``).
            pairing_token: Agent-pairing token for authentication.

        Returns:
            The updated payment record wrapped in an item envelope.

        Raises:
            OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
            OrchestrationApiError: On server errors.
            OrchestrationNetworkError: On network failures.
        """
        return refund_payment(self._client, order_id, params, pairing_token)
