"""Payment settlement functions — submit proof, lock escrow, release, and refund.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_POST
from peaq_os_sdk.types.orchestration.common import ItemResponse
from peaq_os_sdk.types.orchestration.payment import (
    LockEscrowPaymentRequest,
    MarketPayment,
    RefundPaymentRequest,
    ReleasePaymentRequest,
    SubmitPaymentProofRequest,
)

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .market_orders import _market_payment_from_wire
from .transport import RESPONSE_SHAPE_ITEM, AuthAgentPairing, api_request

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "lock_escrow_payment",
    "refund_payment",
    "release_payment",
    "submit_payment_proof",
]

FIELD_ORDER_ID = "order_id"
FIELD_PAIRING_TOKEN = "pairing_token"
FIELD_TRANSACTION_HASH = "transaction_hash"
FIELD_CHAIN = "chain"
FIELD_ESCROW_ADDRESS = "escrow_address"
FIELD_VERIFICATION_MODE = "verification_mode"
FIELD_TOKEN = "token"
FIELD_PAYER_ADDRESS = "payer_address"
FIELD_PAYEE_ADDRESS = "payee_address"
FIELD_AMOUNT = "amount"


def _payment_item_response(raw: dict[str, Any]) -> ItemResponse[MarketPayment]:
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_payment_from_wire(item))


def submit_payment_proof(
    client: PeaqosClient,
    order_id: str,
    params: SubmitPaymentProofRequest,
    pairing_token: str,
) -> ItemResponse[MarketPayment]:
    """Submit a payment proof after a payment intent is created.

    Supports EVM proofs (``transaction_hash``) and Solana proofs
    (``transaction_signature``) with ``verification_mode`` ``"recorded"`` or
    ``"rpc"``.

    Endpoint: ``POST /market/orders/:orderId/payment-proof``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Proof parameters — ``verification_mode``, ``chain``, ``token``,
            ``payer_address``, ``payee_address``, and ``amount`` are required.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The updated payment record wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If required fields or ``pairing_token`` are empty.
        OrchestrationApiError: On server errors (``PAYMENT_RPC_REQUIRED``,
            ``PAYMENT_RPC_ERROR``, ``PAYMENT_NOT_MINED``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/payment-proof",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    return _payment_item_response(raw)


def lock_escrow_payment(
    client: PeaqosClient,
    order_id: str,
    params: LockEscrowPaymentRequest,
    pairing_token: str,
) -> ItemResponse[MarketPayment]:
    """Lock funds in escrow for a market order's payment.

    Endpoint: ``POST /market/orders/:orderId/payment/escrow-lock``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Escrow lock parameters — ``transaction_hash``, ``chain``, and
            ``escrow_address`` are required.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The updated payment record wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If required fields are empty.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(params.transaction_hash, FIELD_TRANSACTION_HASH)
    assert_non_empty_string(params.chain, FIELD_CHAIN)
    assert_non_empty_string(params.escrow_address, FIELD_ESCROW_ADDRESS)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/payment/escrow-lock",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    return _payment_item_response(raw)


def release_payment(
    client: PeaqosClient,
    order_id: str,
    params: ReleasePaymentRequest | None,
    pairing_token: str,
) -> ItemResponse[MarketPayment]:
    """Release payment to the provider after order confirmation.

    Endpoint: ``POST /market/orders/:orderId/payment/release``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Optional release parameters (``transaction_hash``, ``notes``).
            Pass ``None`` to omit a request body.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The updated payment record wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    body: dict[str, Any] | None = None
    if params is not None:
        body = strip_nones(asdict(params))

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/payment/release",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=body,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    return _payment_item_response(raw)


def refund_payment(
    client: PeaqosClient,
    order_id: str,
    params: RefundPaymentRequest | None,
    pairing_token: str,
) -> ItemResponse[MarketPayment]:
    """Refund a payment for a market order.

    Endpoint: ``POST /market/orders/:orderId/payment/refund``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Optional refund parameters (``transaction_hash``, ``reason``).
            Pass ``None`` to omit a request body.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The updated payment record wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    body: dict[str, Any] | None = None
    if params is not None:
        body = strip_nones(asdict(params))

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/payment/refund",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=body,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    return _payment_item_response(raw)
