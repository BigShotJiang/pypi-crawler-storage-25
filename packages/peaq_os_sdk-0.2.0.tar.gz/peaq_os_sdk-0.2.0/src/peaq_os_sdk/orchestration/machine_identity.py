"""Machine identity challenge functions — request a challenge that must
be signed with the DID controller key before registering a machine with
an identity proof.

"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_POST
from peaq_os_sdk.types.orchestration.common import ItemResponse
from peaq_os_sdk.types.orchestration.machine import (
    CreateMachineIdentityChallengeRequest,
    MachineIdentityChallengeResponse,
)

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .transport import RESPONSE_SHAPE_ITEM, AuthPlatform, api_request

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = ["create_machine_identity_challenge"]

FIELD_IDENTITY_REF = "identity_ref"


def _machine_identity_challenge_from_wire(
    data: Mapping[str, Any],
) -> MachineIdentityChallengeResponse:
    return MachineIdentityChallengeResponse(
        challenge_id=data["challenge_id"],
        identity_ref=data["identity_ref"],
        message=data["message"],
        expires_at=data["expires_at"],
        verification_method=data["verification_method"],
        controller_addresses=tuple(data.get("controller_addresses") or ()),
    )


def create_machine_identity_challenge(
    client: PeaqosClient,
    params: CreateMachineIdentityChallengeRequest,
) -> ItemResponse[MachineIdentityChallengeResponse]:
    """Request a machine identity challenge.

    The caller must sign the returned ``message`` with the DID controller key
    (EIP-191) and include the resulting ``challenge_id`` and ``signature`` as
    ``identity_proof`` in a subsequent :func:`~peaq_os_sdk.orchestration.machines.create_machine`
    call.

    Endpoint: ``POST /machine-identity/challenges``
    Auth: platform (``x-api-key``)

    Args:
        client: The SDK client instance.
        params: Challenge request containing ``identity_ref``.

    Returns:
        Challenge with a ``message`` to sign and a ``challenge_id``.

    Raises:
        OrchestrationValidationError: If ``identity_ref`` is empty.
        OrchestrationConfigError: If ``orchestration_url`` is not configured.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(params.identity_ref, FIELD_IDENTITY_REF)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        "/machine-identity/challenges",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_machine_identity_challenge_from_wire(item))
