"""Runtime endpoint functions — list, get, upsert, and delete machine runtimes.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from peaq_os_sdk.constants import HTTP_METHOD_DELETE, HTTP_METHOD_GET, HTTP_METHOD_PUT
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.runtime_endpoint import (
    RuntimeEndpoint,
    UpsertRuntimeEndpointRequest,
)

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .errors import OrchestrationValidationError
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    RESPONSE_SHAPE_RAW,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "delete_runtime_endpoint",
    "get_runtime_endpoint",
    "list_runtime_endpoints",
    "list_runtime_endpoints_all",
    "upsert_runtime_endpoint",
]

FIELD_MACHINE_ID = "machine_id"
FIELD_PROVIDER_KEY = "provider_key"
FIELD_ENDPOINT_BASE_URL = "endpoint_base_url"


def _assert_parseable_http_url(url: str) -> None:
    """Raise OrchestrationValidationError if *url* is not a non-empty http(s) URL."""
    stripped = url.strip()
    if not stripped:
        raise OrchestrationValidationError(
            "endpoint_base_url must be a non-empty string",
            FIELD_ENDPOINT_BASE_URL,
            "non-empty string",
        )
    parsed = urlparse(stripped)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise OrchestrationValidationError(
            "endpoint_base_url must be a valid URL",
            FIELD_ENDPOINT_BASE_URL,
            "valid URL",
        )


def _runtime_endpoint_from_wire(data: Mapping[str, Any]) -> RuntimeEndpoint:
    return RuntimeEndpoint(
        id=data["id"],
        machine_id=data["machine_id"],
        provider_key=data["provider_key"],
        source=data["source"],
        label=data["label"],
        endpoint_base_url=data["endpoint_base_url"],
        auth_type=data["auth_type"],
        has_auth_token=data["has_auth_token"],
        network_scope=data["network_scope"],
        probe_path=data.get("probe_path") or "",
        status=data["status"],
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        agent_id=data.get("agent_id"),
        model_alias=data.get("model_alias"),
        lease_expires_at=data.get("lease_expires_at"),
        last_checked_at=data.get("last_checked_at"),
        last_healthy_at=data.get("last_healthy_at"),
    )


def list_runtime_endpoints(
    client: PeaqosClient,
    machine_id: str,
    *,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[RuntimeEndpoint]:
    """List runtime endpoints registered on a machine.

    Endpoint: ``GET /machines/:machineId/runtime-endpoints``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.

    Args:
        client: The SDK client instance.
        machine_id: The parent machine's identifier.
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    query = pagination_query_params(limit=limit, cursor=cursor)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/machines/{machine_id}/runtime-endpoints",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_runtime_endpoint_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_runtime_endpoints_all(
    client: PeaqosClient,
    machine_id: str,
    *,
    limit: int | None = None,
) -> Generator[RuntimeEndpoint, None, None]:
    """Iterate over every runtime endpoint on a machine across all pages.

    Convenience wrapper around :func:`list_runtime_endpoints` that traverses
    ``next_cursor`` pages and yields one :class:`RuntimeEndpoint` at a time.

    Args:
        client: The SDK client instance.
        machine_id: The parent machine's identifier (forwarded on every page).
        limit: Optional per-page size (``1``..``500``).

    Yields:
        Each :class:`RuntimeEndpoint` from every page in order.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_runtime_endpoints(client, machine_id, limit=limit, cursor=cursor)
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def get_runtime_endpoint(
    client: PeaqosClient,
    machine_id: str,
    provider_key: str,
) -> ItemResponse[RuntimeEndpoint]:
    """Get a single runtime endpoint by provider key.

    Endpoint: ``GET /machines/:machineId/runtime-endpoints/:providerKey``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(provider_key, FIELD_PROVIDER_KEY)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/machines/{machine_id}/runtime-endpoints/{provider_key}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_runtime_endpoint_from_wire(item))


def upsert_runtime_endpoint(
    client: PeaqosClient,
    machine_id: str,
    provider_key: str,
    params: UpsertRuntimeEndpointRequest,
) -> ItemResponse[RuntimeEndpoint]:
    """Create or update a runtime endpoint.

    ``endpoint_base_url`` must be a parseable ``http`` or ``https`` URL with a
    host. Request bodies that include ``auth_token`` are treated as secrets;
    when the transport attaches the request body to certain error responses,
    sensitive fields are redacted (see :func:`transport.api_request`).

    Endpoint: ``PUT /machines/:machineId/runtime-endpoints/:providerKey``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(provider_key, FIELD_PROVIDER_KEY)
    _assert_parseable_http_url(params.endpoint_base_url)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_PUT,
        f"/machines/{machine_id}/runtime-endpoints/{provider_key}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_runtime_endpoint_from_wire(item))


def delete_runtime_endpoint(
    client: PeaqosClient,
    machine_id: str,
    provider_key: str,
) -> None:
    """Delete a runtime endpoint (``204 No Content``).

    Endpoint: ``DELETE /machines/:machineId/runtime-endpoints/:providerKey``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(provider_key, FIELD_PROVIDER_KEY)

    api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_DELETE,
        f"/machines/{machine_id}/runtime-endpoints/{provider_key}",
        RESPONSE_SHAPE_RAW,
        auth=AuthPlatform(),
    )
