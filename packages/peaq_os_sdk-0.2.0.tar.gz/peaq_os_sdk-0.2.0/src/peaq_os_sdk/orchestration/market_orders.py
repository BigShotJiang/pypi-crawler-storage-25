"""Market order functions — list, create, and retrieve market orders.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, cast

from peaq_os_sdk.constants import HTTP_METHOD_GET, HTTP_METHOD_POST
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.market_order import (
    ConfirmMarketOrderResponse,
    CreateMarketOrderRequest,
    DisputeMarketOrderRequest,
    DisputeMarketOrderResponse,
    ExecuteMarketOrderRequest,
    ExecuteMarketOrderResponse,
    ExecutionOutcome,
    ExecutionRun,
    HandoffExecutionBody,
    HandoffExecutionResponse,
    MarketOrder,
    MarketOrderBudget,
    NativeExecutionBody,
    NativeExecutionResponse,
    OrderDispute,
)
from peaq_os_sdk.types.orchestration.payment import (
    CreatePaymentIntentRequest,
    MarketPayment,
    PaymentRailDetails,
)

from ._internal.helpers import (
    assert_non_empty_string,
    external_handoff_from_wire,
    strip_nones,
    to_transport_config,
)
from .market_search import _payment_rail_from_wire
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    RESPONSE_SHAPE_RAW,
    AuthAgentPairing,
    AuthPlatform,
    api_request,
)
from .validation import assert_execute_response

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "confirm_market_order",
    "create_market_order",
    "create_payment_intent",
    "dispute_market_order",
    "execute_market_order",
    "get_market_order",
    "get_market_payment",
    "list_market_orders",
    "list_market_orders_all",
]

FIELD_ORDER_ID = "order_id"
FIELD_MACHINE_ID = "machine_id"
FIELD_PAIRING_TOKEN = "pairing_token"
FIELD_SERVICE_ID = "service_id"
FIELD_AGENT_PAIRING_ID = "agent_pairing_id"
FIELD_REASON = "reason"


def _order_budget_from_wire(data: Mapping[str, Any] | None) -> MarketOrderBudget | None:
    if data is None:
        return None
    return MarketOrderBudget(
        amount=data.get("amount"),
        currency=data.get("currency"),
    )


def _market_order_from_wire(data: Mapping[str, Any]) -> MarketOrder:
    payment = data["payment"]
    if not isinstance(payment, dict):
        raise TypeError("expected dict for order payment")
    raw_input = data.get("input")
    if raw_input is None:
        raw_input = data.get("input_payload")
    if not isinstance(raw_input, dict):
        raw_input = {}
    return MarketOrder(
        id=data["id"],
        machine_id=data["machine_id"],
        agent_pairing_id=data["agent_pairing_id"],
        service_id=data["service_id"],
        skill_key=data["skill_key"],
        provider_key=data["provider_key"],
        service_type=data["service_type"],
        operation=data["operation"],
        execution_mode=data["execution_mode"],
        integration_status=data["integration_status"],
        status=data["status"],
        input_payload=dict(raw_input),
        payment=_payment_rail_from_wire(payment),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        search_id=data.get("search_id"),
        quote_id=data.get("quote_id"),
        budget=_order_budget_from_wire(data.get("budget")),
        handoff=external_handoff_from_wire(data.get("handoff")),
        error_message=data.get("error_message"),
    )


def _payment_rail_details_from_wire(data: Mapping[str, Any]) -> PaymentRailDetails:
    rail_type = data.get("type")
    if rail_type is None:
        rail_type = data.get("rail_type")
    if rail_type is None:
        raise TypeError("expected rail type on payment rail details")
    raw_metadata = data.get("metadata")
    metadata = dict(raw_metadata) if isinstance(raw_metadata, dict) else None
    return PaymentRailDetails(
        rail_type=rail_type,
        chain=data.get("chain"),
        token=data.get("token"),
        token_address=data.get("token_address"),
        token_mint=data.get("token_mint"),
        escrow_address=data.get("escrow_address"),
        external_url=data.get("external_url"),
        provider=data.get("provider"),
        account_id=data.get("account_id"),
        wallet_address=data.get("wallet_address"),
        payer_address=data.get("payer_address"),
        payee_address=data.get("payee_address"),
        payment_intent_id=data.get("payment_intent_id"),
        metadata=metadata,
    )


def _market_payment_from_wire(data: Mapping[str, Any]) -> MarketPayment:
    rail = data["rail"]
    if not isinstance(rail, dict):
        raise TypeError("expected dict for payment rail")
    return MarketPayment(
        id=data["id"],
        order_id=data["order_id"],
        machine_id=data["machine_id"],
        status=data["status"],
        rail=_payment_rail_details_from_wire(rail),
        notes=tuple(data.get("notes") or ()),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        amount=data.get("amount"),
        currency=data.get("currency"),
    )


def _execution_outcome_from_wire(data: Mapping[str, Any]) -> ExecutionOutcome:
    return ExecutionOutcome(
        id=data["id"],
        status=data["status"],
        skill_key=data["skill_key"],
        service_id=data["service_id"],
        execution_mode=data["execution_mode"],
        result=data.get("result"),
        error_message=data.get("error_message"),
        external_ref=data.get("external_ref"),
    )


def _execution_run_from_wire(data: Mapping[str, Any]) -> ExecutionRun:
    return ExecutionRun(
        id=data["id"],
        status=data["status"],
        execution_mode=data.get("execution_mode"),
        skill_key=data.get("skill_key"),
        service_id=data.get("service_id"),
        outcome_id=data.get("outcome_id"),
    )


def _execute_response_from_wire(data: Mapping[str, Any]) -> ExecuteMarketOrderResponse:
    order_raw = data["order"]
    execution_raw = data["execution"]
    if not isinstance(order_raw, dict) or not isinstance(execution_raw, dict):
        raise TypeError("expected dict for execute response order and execution")
    order = _market_order_from_wire(order_raw)
    status_code = int(execution_raw["status_code"])
    if status_code == 202:
        handoff_raw = execution_raw.get("handoff")
        if not isinstance(handoff_raw, dict):
            raise TypeError("expected dict for execution handoff")
        handoff = external_handoff_from_wire(handoff_raw)
        if handoff is None:
            raise TypeError("expected handoff for execution 202 response")
        return HandoffExecutionResponse(
            order=order,
            execution=HandoffExecutionBody(status_code=202, handoff=handoff),
        )
    run_raw = execution_raw.get("run")
    outcome_raw = execution_raw.get("outcome")
    if not isinstance(run_raw, dict) or not isinstance(outcome_raw, dict):
        raise TypeError("expected dict for execution run and outcome")
    return NativeExecutionResponse(
        order=order,
        execution=NativeExecutionBody(
            status_code=200,
            run=_execution_run_from_wire(run_raw),
            outcome=_execution_outcome_from_wire(outcome_raw),
        ),
    )


def _order_dispute_from_wire(data: Mapping[str, Any]) -> OrderDispute:
    evidence = data.get("evidence")
    return OrderDispute(
        id=data["id"],
        order_id=data["order_id"],
        machine_id=data["machine_id"],
        status=data["status"],
        reason=data["reason"],
        evidence=dict(evidence) if isinstance(evidence, dict) else {},
        created_at=data["created_at"],
        updated_at=data["updated_at"],
    )


def _confirm_response_from_wire(data: Mapping[str, Any]) -> ConfirmMarketOrderResponse:
    order_raw = data["order"]
    if not isinstance(order_raw, dict):
        raise TypeError("expected dict for confirm response order")
    payment_raw = data.get("payment")
    payment = _market_payment_from_wire(payment_raw) if isinstance(payment_raw, dict) else None
    return ConfirmMarketOrderResponse(
        order=_market_order_from_wire(order_raw),
        payment=payment,
    )


def _dispute_response_from_wire(data: Mapping[str, Any]) -> DisputeMarketOrderResponse:
    order_raw = data["order"]
    dispute_raw = data["dispute"]
    if not isinstance(order_raw, dict) or not isinstance(dispute_raw, dict):
        raise TypeError("expected dict for dispute response order and dispute")
    payment_raw = data.get("payment")
    payment = _market_payment_from_wire(payment_raw) if isinstance(payment_raw, dict) else None
    return DisputeMarketOrderResponse(
        order=_market_order_from_wire(order_raw),
        payment=payment,
        dispute=_order_dispute_from_wire(dispute_raw),
    )


def _create_market_order_body(params: CreateMarketOrderRequest) -> dict[str, Any]:
    body = strip_nones(asdict(params))
    if not isinstance(body, dict):
        raise TypeError("expected dict body after strip_nones")
    if "input_payload" in body:
        body["input"] = body.pop("input_payload")
    return cast(dict[str, Any], body)


def list_market_orders(
    client: PeaqosClient,
    *,
    machine_id: str,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[MarketOrder]:
    """List market orders for a machine.

    Endpoint: ``GET /market/orders``
    Auth: platform (``x-api-key``)

    Args:
        client: The SDK client instance.
        machine_id: Machine whose orders to list (required query parameter).
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Returns:
        A paginated list of market orders.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
        OrchestrationConfigError: If ``orchestration_url`` is not configured.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    query = pagination_query_params(
        limit=limit,
        cursor=cursor,
        extra={"machine_id": machine_id},
    )

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        "/market/orders",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_market_order_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_market_orders_all(
    client: PeaqosClient,
    *,
    machine_id: str,
    limit: int | None = None,
) -> Generator[MarketOrder, None, None]:
    """Iterate over every market order for a machine across all pages.

    Convenience wrapper around :func:`list_market_orders` that traverses
    ``next_cursor`` pages and yields one :class:`MarketOrder` at a time.
    ``machine_id`` is forwarded as a query parameter on every page call.

    Args:
        client: The SDK client instance.
        machine_id: Machine whose orders to iterate (forwarded on every page).
        limit: Optional per-page size (``1``..``500``).

    Yields:
        Each :class:`MarketOrder` from every page in order.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_market_orders(
            client,
            machine_id=machine_id,
            limit=limit,
            cursor=cursor,
        )
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def create_market_order(
    client: PeaqosClient,
    params: CreateMarketOrderRequest,
    pairing_token: str,
) -> ItemResponse[MarketOrder]:
    """Create a market order from a search result or quote.

    ``provider_credentials`` values are redacted in error context by the
    transport layer when a request fails.

    Endpoint: ``POST /market/orders``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        params: Order creation parameters — ``machine_id``, ``agent_pairing_id``,
            and ``service_id`` are required.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The created order wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If required fields or ``pairing_token`` are empty.
        OrchestrationApiError: On server errors (``QUOTE_EXPIRED``, ``AGENT_AUTH_REQUIRED``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(params.machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(params.agent_pairing_id, FIELD_AGENT_PAIRING_ID)
    assert_non_empty_string(params.service_id, FIELD_SERVICE_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        "/market/orders",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=_create_market_order_body(params),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_order_from_wire(item))


def get_market_order(client: PeaqosClient, order_id: str) -> ItemResponse[MarketOrder]:
    """Retrieve a single market order by id.

    Endpoint: ``GET /market/orders/:orderId``
    Auth: platform (``x-api-key``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.

    Returns:
        The market order wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If ``order_id`` is empty.
        OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/market/orders/{order_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_order_from_wire(item))


def create_payment_intent(
    client: PeaqosClient,
    order_id: str,
    params: CreatePaymentIntentRequest,
    pairing_token: str,
) -> ItemResponse[MarketPayment]:
    """Create a payment intent for a market order.

    Supports rail types including ``wdk-usdt-transfer``, with optional
    ``token_address``, ``token_mint``, ``payer_address``, and ``payee_address``
    on the nested rail object.

    Endpoint: ``POST /market/orders/:orderId/payment-intent``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Payment intent parameters — optional ``amount``, ``currency``,
            and ``rail``.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The payment record wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
        OrchestrationApiError: On server errors (``PAYMENT_REQUIRED``, ``ORDER_CLOSED``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/payment-intent",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_payment_from_wire(item))


def get_market_payment(
    client: PeaqosClient,
    order_id: str,
) -> ItemResponse[MarketPayment | None]:
    """Retrieve the payment record for a market order.

    The response ``item`` may be ``None`` when no payment exists for the order.

    Endpoint: ``GET /market/orders/:orderId/payment``
    Auth: platform (``x-api-key``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.

    Returns:
        The payment record (or ``None``) wrapped in an item envelope.

    Raises:
        OrchestrationValidationError: If ``order_id`` is empty.
        OrchestrationApiError: On server errors (``NOT_FOUND``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/market/orders/{order_id}/payment",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if item is None:
        return ItemResponse(item=None)
    if not isinstance(item, dict):
        raise TypeError("expected dict or None for item envelope payload")
    return ItemResponse(item=_market_payment_from_wire(item))


def execute_market_order(
    client: PeaqosClient,
    order_id: str,
    params: ExecuteMarketOrderRequest,
    pairing_token: str,
) -> ExecuteMarketOrderResponse:
    """Execute a market order.

    The response is discriminated by ``execution.status_code``:

    - **Native (200):** ``run`` and ``outcome`` are populated.
    - **Handoff (202):** ``handoff`` contains ``label`` and ``url``.

    Endpoint: ``POST /market/orders/:orderId/execute``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Optional execution input (e.g. ``input={"symbol": "BTC/USD"}``).
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The execution response with ``order`` and ``execution`` details.

    Raises:
        OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
        OrchestrationApiError: On server errors (``EXECUTION_UNSUPPORTED``,
            ``PAYMENT_REQUIRED``, ``ORDER_CLOSED``, etc.) or invalid response shape.
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/execute",
        RESPONSE_SHAPE_RAW,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict execute response from orchestration API")
    assert_execute_response(raw)
    return _execute_response_from_wire(raw)


def confirm_market_order(
    client: PeaqosClient,
    order_id: str,
    pairing_token: str,
) -> ConfirmMarketOrderResponse:
    """Confirm delivery of a market order.

    When payment is required, the associated payment moves to ``release_pending``.

    Endpoint: ``POST /market/orders/:orderId/confirm``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The confirmation response with ``order`` and ``payment``.

    Raises:
        OrchestrationValidationError: If ``order_id`` or ``pairing_token`` is empty.
        OrchestrationApiError: On server errors (``ORDER_CLOSED``, ``ORDER_NOT_DELIVERED``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/confirm",
        RESPONSE_SHAPE_RAW,
        auth=AuthAgentPairing(token=pairing_token),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict confirm response from orchestration API")
    return _confirm_response_from_wire(raw)


def dispute_market_order(
    client: PeaqosClient,
    order_id: str,
    params: DisputeMarketOrderRequest,
    pairing_token: str,
) -> DisputeMarketOrderResponse:
    """Dispute a market order.

    The associated payment moves to ``frozen`` pending resolution.

    Endpoint: ``POST /market/orders/:orderId/dispute``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Args:
        client: The SDK client instance.
        order_id: The order's unique identifier.
        params: Dispute parameters — ``reason`` is required; ``evidence`` is optional.
        pairing_token: Agent-pairing token for authentication.

    Returns:
        The dispute response with ``order``, ``payment``, and ``dispute``.

    Raises:
        OrchestrationValidationError: If ``order_id``, ``pairing_token``, or ``reason`` is empty.
        OrchestrationApiError: On server errors (``ORDER_CLOSED``, etc.).
        OrchestrationNetworkError: On network failures.
    """
    assert_non_empty_string(order_id, FIELD_ORDER_ID)
    assert_non_empty_string(params.reason, FIELD_REASON)
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/market/orders/{order_id}/dispute",
        RESPONSE_SHAPE_RAW,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict dispute response from orchestration API")
    return _dispute_response_from_wire(raw)
