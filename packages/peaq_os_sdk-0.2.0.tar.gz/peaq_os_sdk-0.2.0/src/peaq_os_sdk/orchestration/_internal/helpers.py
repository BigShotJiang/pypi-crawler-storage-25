"""Shared internal helpers for orchestration feature modules.

Internal: not exported from the public package surface.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.types.orchestration.common import ExternalHandoff

from ..errors import OrchestrationConfigError, OrchestrationValidationError
from ..transport import TransportClientConfig

if TYPE_CHECKING:
    from ...client import PeaqosClient

_ORCHESTRATION_URL_REQUIRED = "orchestration_url is required to use orchestration functions"


def to_transport_config(client: PeaqosClient) -> TransportClientConfig:
    """Extract a transport config from a client, validating orchestration_url.

    Internal: not part of the public API.

    Args:
        client: The SDK client instance.

    Returns:
        Transport settings for :func:`~peaq_os_sdk.orchestration.transport.api_request`.

    Raises:
        OrchestrationConfigError: If ``orchestration_url`` is not set on
            the client.
    """
    if client.orchestration_url is None:
        raise OrchestrationConfigError(_ORCHESTRATION_URL_REQUIRED)
    if client.api_key is not None:
        return TransportClientConfig(
            orchestration_url=client.orchestration_url,
            api_key=client.api_key,
        )
    return TransportClientConfig(orchestration_url=client.orchestration_url)


def assert_non_empty_string(value: str, field: str) -> None:
    """Raise if value is empty or whitespace-only.

    Internal: not part of the public API.

    Args:
        value: The string to validate.
        field: The parameter name, used in the error message.

    Raises:
        OrchestrationValidationError: If ``value`` is empty or
            whitespace-only.
    """
    if not value.strip():
        raise OrchestrationValidationError(
            f"{field} must be a non-empty string",
            field,
            "non-empty string",
        )


def strip_nones(obj: Any) -> Any:
    """Recursively drop None values. Drop dicts that become empty as a result."""
    if isinstance(obj, dict):
        stripped = {k: strip_nones(v) for k, v in obj.items() if v is not None}
        return {k: v for k, v in stripped.items() if not (isinstance(v, dict) and not v)}
    return obj


def external_handoff_from_wire(obj: Mapping[str, Any] | None) -> ExternalHandoff | None:
    if obj is None:
        return None
    return ExternalHandoff(
        label=obj["label"],
        url=obj["url"],
        notes=tuple(obj.get("notes") or ()),
    )
