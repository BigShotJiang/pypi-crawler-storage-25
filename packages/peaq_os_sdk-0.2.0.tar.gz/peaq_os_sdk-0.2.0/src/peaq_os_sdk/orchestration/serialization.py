"""CamelCase ↔ snake_case conversion for orchestration JSON.

The transport layer applies these helpers so feature code works with
Pythonic ``snake_case`` dict keys while the HTTP API uses ``camelCase`` on
the wire. Feature modules should not call this module directly.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

__all__ = ["to_camel_case", "to_snake_case"]

_CAMEL_BOUNDARY_1 = re.compile(r"(.)([A-Z][a-z]+)")
_CAMEL_BOUNDARY_2 = re.compile(r"([a-z0-9])([A-Z])")


def _camel_to_snake_key(name: str) -> str:
    s = _CAMEL_BOUNDARY_1.sub(r"\1_\2", name)
    s = _CAMEL_BOUNDARY_2.sub(r"\1_\2", s)
    return s.lower()


def _snake_to_camel_key(name: str) -> str:
    if "_" not in name:
        return name
    parts = [p for p in name.split("_") if p != ""]
    if not parts:
        return name
    return parts[0].lower() + "".join(p[0].upper() + p[1:] for p in parts[1:])


def _map_keys(obj: Any, key_fn: Callable[[str], str]) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        return {key_fn(str(k)): _map_keys(v, key_fn) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_map_keys(item, key_fn) for item in obj]
    return obj


def to_snake_case(data: dict[str, Any]) -> dict[str, Any]:
    """Recursively rename dict keys from camelCase to snake_case.

    Nested dicts and lists of dicts are traversed. Scalars (including ``None``)
    are returned as-is inside structures.
    """
    mapped = _map_keys(data, _camel_to_snake_key)
    if not isinstance(mapped, dict):
        raise TypeError("internal error: expected dict from to_snake_case root")
    return mapped


def to_camel_case(data: dict[str, Any]) -> dict[str, Any]:
    """Recursively rename dict keys from snake_case to camelCase.

    Keys that contain no ``"_"`` are left unchanged so already-wire-shaped
    payloads are not mangled. Nested dicts and lists of dicts are traversed.
    """
    mapped = _map_keys(data, _snake_to_camel_key)
    if not isinstance(mapped, dict):
        raise TypeError("internal error: expected dict from to_camel_case root")
    return mapped


def _wire_response_to_sdk(obj: Any) -> Any:
    """Apply snake_case key mapping to any JSON-compatible value (transport)."""
    return _map_keys(obj, _camel_to_snake_key)


def _sdk_request_body_to_wire(obj: Any) -> Any:
    """Apply camelCase key mapping to request bodies (transport)."""
    return _map_keys(obj, _snake_to_camel_key)


def _sdk_query_params_to_wire(query: dict[str, str]) -> dict[str, str]:
    """Rename query parameter keys from snake_case to wire camelCase.

    Keys without ``"_"`` (e.g. ``limit``, ``cursor``) are unchanged.
    """
    return {_snake_to_camel_key(key): value for key, value in query.items()}
