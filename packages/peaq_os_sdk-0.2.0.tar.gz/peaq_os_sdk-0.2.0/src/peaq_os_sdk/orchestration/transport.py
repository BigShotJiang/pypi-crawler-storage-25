"""Internal HTTP transport for orchestration API calls.

Experimental: the orchestration API is under active development.

Feature code should call :func:`api_request` with a shared
:class:`requests.Session` — not :meth:`requests.Session.request` directly.

Request bodies and query parameters may use ``snake_case`` keys; they are
converted to ``camelCase`` on the wire (JSON bodies and query strings).
Successful JSON responses are returned with ``snake_case`` keys (including
nested structures). Feature modules must not perform field-name conversion
themselves; the transport layer applies
:mod:`peaq_os_sdk.orchestration.serialization` internally.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, TypeAlias
from urllib.parse import urlencode

import requests

from peaq_os_sdk.orchestration.errors import OrchestrationApiError, OrchestrationNetworkError
from peaq_os_sdk.orchestration.serialization import (
    _sdk_query_params_to_wire,
    _sdk_request_body_to_wire,
    _wire_response_to_sdk,
)
from peaq_os_sdk.orchestration.validation import (
    assert_error_response,
    assert_item_response,
    assert_list_response,
)

AUTH_TYPE_PLATFORM: Literal["platform"] = "platform"
AUTH_TYPE_AGENT_PAIRING: Literal["agent-pairing"] = "agent-pairing"
AUTH_TYPE_NONE: Literal["none"] = "none"

RESPONSE_SHAPE_ITEM: Literal["item"] = "item"
RESPONSE_SHAPE_LIST: Literal["list"] = "list"
RESPONSE_SHAPE_RAW: Literal["raw"] = "raw"

ResponseShape: TypeAlias = Literal["item", "list", "raw"]

API_BASE_PATH = "/api/v1"
CONTENT_TYPE_JSON = "application/json"
HEADER_API_KEY = "x-api-key"
HEADER_AGENT_PAIRING_TOKEN = "x-agent-pairing-token"
DEFAULT_READ_TIMEOUT_MS = 30_000
DEFAULT_WRITE_TIMEOUT_MS = 60_000
HTTP_STATUS_NO_CONTENT = 204
HTTP_CLIENT_ERROR_MIN = 400
BAD_RESPONSE_CODE = "BAD_RESPONSE"
BAD_RESPONSE_MESSAGE = "Orchestration API returned a non-JSON error body"
NETWORK_ERROR_MESSAGE = "Orchestration API request failed due to a network error"

SENSITIVE_FIELD_PATTERNS: tuple[str, ...] = (
    "token",
    "key",
    "secret",
    "password",
    "credential",
    "auth",
)


def _user_agent() -> str:
    try:
        from importlib.metadata import version

        ver = version("peaq-os-sdk")
    except Exception:
        ver = "0.1.0"
    return f"peaqos-sdk-py/{ver}"


USER_AGENT = _user_agent()


@dataclass(frozen=True, slots=True)
class TransportClientConfig:
    """Subset of client settings required for orchestration HTTP calls.

    Experimental: the orchestration API is under active development.
    """

    orchestration_url: str
    api_key: str | None = None


@dataclass(frozen=True, slots=True)
class AuthPlatform:
    """Platform API key auth — ``x-api-key`` header when configured."""

    type: Literal["platform"] = AUTH_TYPE_PLATFORM


@dataclass(frozen=True, slots=True)
class AuthAgentPairing:
    """Agent pairing token auth — ``x-agent-pairing-token`` header."""

    token: str
    type: Literal["agent-pairing"] = AUTH_TYPE_AGENT_PAIRING


@dataclass(frozen=True, slots=True)
class AuthNone:
    """No authentication headers."""

    type: Literal["none"] = AUTH_TYPE_NONE


AuthMode: TypeAlias = AuthPlatform | AuthAgentPairing | AuthNone


def _build_url(base_url: str, path: str, query: dict[str, str] | None) -> str:
    trimmed = base_url[:-1] if base_url.endswith("/") else base_url
    normalized_path = path if path.startswith("/") else f"/{path}"
    url = f"{trimmed}{API_BASE_PATH}{normalized_path}"
    if query:
        wire_query = _sdk_query_params_to_wire(query)
        return f"{url}?{urlencode(wire_query)}"
    return url


def _default_timeout_seconds(method: str) -> float:
    return (
        DEFAULT_READ_TIMEOUT_MS / 1000.0
        if method.upper() == "GET"
        else DEFAULT_WRITE_TIMEOUT_MS / 1000.0
    )


def _sanitize_body(body: object) -> object:
    if isinstance(body, list):
        return [_sanitize_body(item) for item in body]
    if not isinstance(body, dict):
        return body
    result: dict[str, Any] = {}
    for key, value in body.items():
        lower_key = key.lower()
        if any(p in lower_key for p in SENSITIVE_FIELD_PATTERNS):
            result[key] = "[REDACTED]"
        else:
            result[key] = _sanitize_body(value)
    return result


def _read_json_body(response: requests.Response) -> Any | None:
    try:
        if not response.content:
            return None
        return response.json()
    except ValueError:
        return None


def api_request(
    config: TransportClientConfig,
    session: requests.Session,
    method: str,
    path: str,
    response_shape: ResponseShape,
    *,
    body: object | None = None,
    query: dict[str, str] | None = None,
    auth: AuthMode | None = None,
    timeout_ms: int | None = None,
) -> Any:
    """Send an HTTP request to the orchestration API and return the parsed JSON body.

    For HTTP 204, returns ``None``. For 4xx/5xx, raises :class:`OrchestrationApiError`
    when the body can be parsed as structured JSON, or with ``BAD_RESPONSE`` when it
    cannot. Network failures raise :class:`OrchestrationNetworkError` with the original
    exception as :attr:`!__cause__`.

    Successful JSON dict/list bodies are returned with dict keys converted to
    ``snake_case`` (wire ``camelCase`` in, Pythonic keys out). Error ``details``
    payloads use the same conversion when they are objects or arrays.

    Args:
        config: Base URL and optional platform API key.
        session: Shared :class:`~requests.Session` (e.g. from :attr:`PeaqosClient.session`).
        method: HTTP verb (``GET``, ``POST``, etc.).
        path: Path under ``/api/v1`` (may start with ``/``).
        response_shape: ``item`` / ``list`` envelope validation, or ``raw`` to skip.
        body: Optional JSON-serializable request body. Dict keys may be
            ``snake_case`` (converted to wire ``camelCase``) or already wire-shaped
            (keys without ``"_"`` pass through unchanged).
        query: Optional query string parameters (``snake_case`` keys converted to
            wire ``camelCase``).
        auth: Authentication mode; defaults to no auth headers.
        timeout_ms: Optional timeout in milliseconds (read vs write defaults apply).

    Experimental: the orchestration API is under active development.
    """
    url = _build_url(config.orchestration_url, path, query)
    timeout_sec = (
        timeout_ms / 1000.0 if timeout_ms is not None else _default_timeout_seconds(method)
    )

    headers: dict[str, str] = {
        "content-type": CONTENT_TYPE_JSON,
        "user-agent": USER_AGENT,
    }

    resolved_auth: AuthMode = auth if auth is not None else AuthNone()

    if isinstance(resolved_auth, AuthPlatform):
        if config.api_key:
            headers[HEADER_API_KEY] = config.api_key
    elif isinstance(resolved_auth, AuthAgentPairing):
        headers[HEADER_AGENT_PAIRING_TOKEN] = resolved_auth.token

    req_kw: dict[str, Any] = {
        "method": method.upper(),
        "url": url,
        "headers": headers,
        "timeout": timeout_sec,
    }
    if body is not None:
        req_kw["json"] = _sdk_request_body_to_wire(body)

    try:
        response = session.request(**req_kw)
    except requests.RequestException as cause:
        raise OrchestrationNetworkError(NETWORK_ERROR_MESSAGE, cause) from cause

    if response.status_code == HTTP_STATUS_NO_CONTENT:
        return None

    if response.status_code >= HTTP_CLIENT_ERROR_MIN:
        parsed = _read_json_body(response)
        if parsed is None:
            raise OrchestrationApiError(
                BAD_RESPONSE_MESSAGE,
                BAD_RESPONSE_CODE,
                response.status_code,
                _sanitize_body(body),
            )
        try:
            assert_error_response(parsed)
        except OrchestrationApiError:
            raise OrchestrationApiError(
                f"Orchestration API error (HTTP {response.status_code})",
                BAD_RESPONSE_CODE,
                response.status_code,
                _sanitize_body(body),
            ) from None
        err = parsed["error"]
        assert isinstance(err, dict)
        raw_details = err.get("details")
        if raw_details is None:
            sdk_details = None
        elif isinstance(raw_details, (dict, list)):
            sdk_details = _wire_response_to_sdk(raw_details)
        else:
            sdk_details = raw_details
        raise OrchestrationApiError(
            str(err["message"]),
            str(err["code"]),
            response.status_code,
            sdk_details,
        )

    data = _read_json_body(response)
    if data is None:
        raise OrchestrationApiError(
            BAD_RESPONSE_MESSAGE,
            BAD_RESPONSE_CODE,
            response.status_code,
        )

    if response_shape == RESPONSE_SHAPE_ITEM:
        assert_item_response(data)
    elif response_shape == RESPONSE_SHAPE_LIST:
        assert_list_response(data)

    return _wire_response_to_sdk(data)
