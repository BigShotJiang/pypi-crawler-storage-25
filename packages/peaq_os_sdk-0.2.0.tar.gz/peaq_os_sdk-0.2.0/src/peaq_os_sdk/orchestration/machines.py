"""Machine lifecycle functions — list, create, get, update, and archive
machines in the orchestration system.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import (
    HTTP_METHOD_DELETE,
    HTTP_METHOD_GET,
    HTTP_METHOD_PATCH,
    HTTP_METHOD_POST,
)
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.machine import (
    CreateMachineRequest,
    Machine,
    MachineIdentityProof,
    UpdateMachineRequest,
)

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    RESPONSE_SHAPE_RAW,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "archive_machine",
    "create_machine",
    "get_machine",
    "list_machines",
    "list_machines_all",
    "update_machine",
]

FIELD_MACHINE_ID = "machine_id"


def _identity_proof_from_wire(data: Mapping[str, Any]) -> MachineIdentityProof:
    return MachineIdentityProof(
        method=data["method"],
        identity_ref=data["identity_ref"],
        signer_address=data["signer_address"],
        challenge_id=data["challenge_id"],
        verified_at=data["verified_at"],
        challenge_expires_at=data["challenge_expires_at"],
        controller_addresses=tuple(data.get("controller_addresses") or ()),
        resolution_source=data["resolution_source"],
    )


def _machine_from_wire(data: Mapping[str, Any]) -> Machine:
    raw_proof = data.get("identity_proof")
    identity_proof = None if raw_proof is None else _identity_proof_from_wire(raw_proof)
    return Machine(
        id=data["id"],
        display_name=data["display_name"],
        status=data["status"],
        owner_id=data["owner_id"],
        machine_type=data["machine_type"],
        runtime_profile=data["runtime_profile"],
        capabilities=tuple(data.get("capabilities") or ()),
        labels=dict(data.get("labels") or {}),
        policy_ids=tuple(data.get("policy_ids") or ()),
        skill_keys=tuple(data.get("skill_keys") or ()),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        identity_ref=data.get("identity_ref"),
        identity_proof=identity_proof,
    )


def list_machines(
    client: PeaqosClient,
    *,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[Machine]:
    """List machines visible to the authenticated platform account.

    Endpoint: ``GET /machines``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.

    Args:
        client: The SDK client instance.
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Returns:
        A paginated list of machines.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
        OrchestrationConfigError: If ``orchestration_url`` is not configured.
        OrchestrationApiError: On server errors.
        OrchestrationNetworkError: On network failures.
    """
    query = pagination_query_params(limit=limit, cursor=cursor)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        "/machines",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query or None,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_machine_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_machines_all(
    client: PeaqosClient,
    *,
    limit: int | None = None,
) -> Generator[Machine, None, None]:
    """Iterate over every machine across all pages.

    Convenience wrapper around :func:`list_machines` that transparently
    traverses pages via ``next_cursor`` and yields one :class:`Machine` at a
    time. Terminates when the server returns ``next_cursor=None``.

    Args:
        client: The SDK client instance.
        limit: Optional per-page size (``1``..``500``). Forwarded to every page
            call. The total number of items yielded is not bounded by ``limit``.

    Yields:
        Each :class:`Machine` from every page in order.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_machines(client, limit=limit, cursor=cursor)
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def create_machine(
    client: PeaqosClient,
    params: CreateMachineRequest,
) -> ItemResponse[Machine]:
    """Create a new machine.

    Endpoint: ``POST /machines``
    Auth: platform (``x-api-key``)

    ``display_name`` and ``owner_id`` must be non-empty.

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(params.display_name, "display_name")
    assert_non_empty_string(params.owner_id, "owner_id")

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        "/machines",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_machine_from_wire(item))


def get_machine(client: PeaqosClient, machine_id: str) -> ItemResponse[Machine]:
    """Retrieve a single machine by id.

    Endpoint: ``GET /machines/:machineId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/machines/{machine_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_machine_from_wire(item))


def update_machine(
    client: PeaqosClient,
    machine_id: str,
    params: UpdateMachineRequest,
) -> ItemResponse[Machine]:
    """Update an existing machine (partial update).

    Endpoint: ``PATCH /machines/:machineId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_PATCH,
        f"/machines/{machine_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_machine_from_wire(item))


def archive_machine(client: PeaqosClient, machine_id: str) -> None:
    """Archive (soft-delete) a machine. The server returns ``204 No Content``.

    Endpoint: ``DELETE /machines/:machineId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)

    api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_DELETE,
        f"/machines/{machine_id}",
        RESPONSE_SHAPE_RAW,
        auth=AuthPlatform(),
    )
