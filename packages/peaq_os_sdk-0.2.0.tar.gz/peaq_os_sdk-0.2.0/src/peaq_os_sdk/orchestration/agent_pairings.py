"""Agent pairing functions — list, create, update, and revoke pairings.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, cast

from peaq_os_sdk.constants import (
    HTTP_METHOD_DELETE,
    HTTP_METHOD_GET,
    HTTP_METHOD_PATCH,
    HTTP_METHOD_POST,
)
from peaq_os_sdk.types.orchestration.agent_pairing import (
    AgentPairing,
    AgentPairingChallengeResponse,
    AgentPairingVerification,
    AgentProofInput,
    CreateAgentPairingChallengeRequest,
    CreateAgentPairingRequest,
    CreateAgentPairingSessionRequest,
    DelegationPolicy,
    UpdateAgentPairingRequest,
)
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    RESPONSE_SHAPE_RAW,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "create_agent_pairing",
    "create_agent_pairing_challenge",
    "create_agent_pairing_session",
    "list_agent_pairings",
    "list_agent_pairings_all",
    "revoke_agent_pairing",
    "update_agent_pairing",
]

FIELD_MACHINE_ID = "machine_id"
FIELD_PAIRING_ID = "pairing_id"
FIELD_AGENT_ADDRESS = "agent_address"
FIELD_AGENT_PROVIDER = "agent_provider"
FIELD_AGENT_ROLE = "agent_role"
FIELD_AGENT_PROOF_CHALLENGE_ID = "agentProof.challengeId"
FIELD_AGENT_PROOF_SIGNATURE = "agentProof.signature"


def _delegation_policy_from_wire(data: Mapping[str, Any]) -> DelegationPolicy:
    return DelegationPolicy(
        allowed_skill_keys=tuple(data.get("allowed_skill_keys") or ()),
        denied_skill_keys=tuple(data.get("denied_skill_keys") or ()),
        allowed_service_ids=tuple(data.get("allowed_service_ids") or ()),
        denied_service_ids=tuple(data.get("denied_service_ids") or ()),
        per_transaction_limit=data.get("per_transaction_limit"),
        daily_spend_limit=data.get("daily_spend_limit"),
        currency=data.get("currency"),
    )


def _agent_pairing_verification_from_wire(
    data: Mapping[str, Any],
) -> AgentPairingVerification:
    return AgentPairingVerification(
        method=data["method"],
        signer_address=data["signer_address"],
        verified_at=data["verified_at"],
        challenge_expires_at=data["challenge_expires_at"],
    )


def _agent_pairing_from_wire(data: Mapping[str, Any]) -> AgentPairing:
    pol = data["delegation_policy"]
    if not isinstance(pol, dict):
        raise TypeError("expected dict for delegation_policy")
    raw_verification = data.get("verification")
    verification = (
        None
        if raw_verification is None
        else _agent_pairing_verification_from_wire(raw_verification)
    )
    return AgentPairing(
        id=data["id"],
        machine_id=data["machine_id"],
        agent_address=data["agent_address"],
        agent_provider=data["agent_provider"],
        agent_role=data["agent_role"],
        status=data["status"],
        has_auth_token=data["has_auth_token"],
        delegation_policy=_delegation_policy_from_wire(pol),
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        description=data.get("description"),
        token_last_four=data.get("token_last_four"),
        pairing_token=data.get("pairing_token"),
        agent_did=data.get("agent_did"),
        verification=verification,
        session_id=data.get("session_id"),
        session_token_id=data.get("session_token_id"),
        session_issued_at=data.get("session_issued_at"),
        session_expires_at=data.get("session_expires_at"),
    )


def _pairing_body(
    params: CreateAgentPairingRequest | UpdateAgentPairingRequest,
) -> dict[str, Any]:
    body = strip_nones(asdict(params))
    if not isinstance(body, dict):
        raise TypeError("expected dict body after strip_nones")
    return cast(dict[str, Any], body)


def _agent_pairing_challenge_from_wire(
    data: Mapping[str, Any],
) -> AgentPairingChallengeResponse:
    return AgentPairingChallengeResponse(
        challenge_id=data["challenge_id"],
        agent_address=data["agent_address"],
        message=data["message"],
        expires_at=data["expires_at"],
        verification_method=data["verification_method"],
        machine_id=data.get("machine_id"),
        machine_identity_ref=data.get("machine_identity_ref"),
        agent_did=data.get("agent_did"),
    )


def _session_body(params: CreateAgentPairingSessionRequest) -> dict[str, Any]:
    body = strip_nones(asdict(params))
    if not isinstance(body, dict):
        raise TypeError("expected dict body after strip_nones")
    return cast(dict[str, Any], body)


def _assert_agent_proof(agent_proof: AgentProofInput) -> None:
    assert_non_empty_string(agent_proof.challenge_id, FIELD_AGENT_PROOF_CHALLENGE_ID)
    assert_non_empty_string(agent_proof.signature, FIELD_AGENT_PROOF_SIGNATURE)


def list_agent_pairings(
    client: PeaqosClient,
    machine_id: str,
    *,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[AgentPairing]:
    """List all agent pairings on a machine.

    Endpoint: ``GET /machines/:machineId/agent-pairings``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.

    Args:
        client: The SDK client instance.
        machine_id: The parent machine's identifier.
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    query = pagination_query_params(limit=limit, cursor=cursor)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/machines/{machine_id}/agent-pairings",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_agent_pairing_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_agent_pairings_all(
    client: PeaqosClient,
    machine_id: str,
    *,
    limit: int | None = None,
) -> Generator[AgentPairing, None, None]:
    """Iterate over every agent pairing on a machine across all pages.

    Convenience wrapper around :func:`list_agent_pairings` that traverses
    ``next_cursor`` pages and yields one :class:`AgentPairing` at a time.

    Args:
        client: The SDK client instance.
        machine_id: The parent machine's identifier (forwarded on every page).
        limit: Optional per-page size (``1``..``500``).

    Yields:
        Each :class:`AgentPairing` from every page in order.

    Raises:
        OrchestrationValidationError: If ``machine_id`` is empty or ``limit`` is
            outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_agent_pairings(client, machine_id, limit=limit, cursor=cursor)
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def create_agent_pairing(
    client: PeaqosClient,
    machine_id: str,
    params: CreateAgentPairingRequest,
) -> ItemResponse[AgentPairing]:
    """Create a new agent pairing on a machine.

    The response item includes a one-time ``pairing_token`` **only on this
    call** — store it securely; it cannot be retrieved again.

    Endpoint: ``POST /machines/:machineId/agent-pairings``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(params.agent_address, FIELD_AGENT_ADDRESS)
    assert_non_empty_string(params.agent_provider, FIELD_AGENT_PROVIDER)
    assert_non_empty_string(params.agent_role, FIELD_AGENT_ROLE)
    _assert_agent_proof(params.agent_proof)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/machines/{machine_id}/agent-pairings",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=_pairing_body(params),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_agent_pairing_from_wire(item))


def create_agent_pairing_challenge(
    client: PeaqosClient,
    machine_id: str,
    params: CreateAgentPairingChallengeRequest,
) -> ItemResponse[AgentPairingChallengeResponse]:
    """Request an agent pairing challenge.

    The agent must sign the returned ``message`` with the wallet key behind
    ``agent_address`` (EIP-191) and include the resulting ``challenge_id`` and
    ``signature`` as ``agent_proof`` in a subsequent
    :func:`create_agent_pairing` call.

    Endpoint: ``POST /machines/:machineId/agent-pairings/challenges``
    Auth: platform (``x-api-key``)
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(params.agent_address, FIELD_AGENT_ADDRESS)
    assert_non_empty_string(params.agent_provider, FIELD_AGENT_PROVIDER)
    assert_non_empty_string(params.agent_role, FIELD_AGENT_ROLE)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/machines/{machine_id}/agent-pairings/challenges",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_agent_pairing_challenge_from_wire(item))


def create_agent_pairing_session(
    client: PeaqosClient,
    machine_id: str,
    pairing_id: str,
    params: CreateAgentPairingSessionRequest,
) -> ItemResponse[AgentPairing]:
    """Create a new session for an existing active agent pairing.

    The response includes a fresh ``pairing_token`` — store it securely, as it
    replaces the previous token.

    Endpoint: ``POST /machines/:machineId/agent-pairings/:pairingId/sessions``
    Auth: platform (``x-api-key``)
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(pairing_id, FIELD_PAIRING_ID)
    _assert_agent_proof(params.agent_proof)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/machines/{machine_id}/agent-pairings/{pairing_id}/sessions",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=_session_body(params),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_agent_pairing_from_wire(item))


def update_agent_pairing(
    client: PeaqosClient,
    machine_id: str,
    pairing_id: str,
    params: UpdateAgentPairingRequest,
) -> ItemResponse[AgentPairing]:
    """Update an existing agent pairing (partial update).

    Endpoint: ``PATCH /machines/:machineId/agent-pairings/:pairingId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(pairing_id, FIELD_PAIRING_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_PATCH,
        f"/machines/{machine_id}/agent-pairings/{pairing_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=_pairing_body(params),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_agent_pairing_from_wire(item))


def revoke_agent_pairing(client: PeaqosClient, machine_id: str, pairing_id: str) -> None:
    """Revoke an agent pairing (``204 No Content``).

    Endpoint: ``DELETE /machines/:machineId/agent-pairings/:pairingId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(pairing_id, FIELD_PAIRING_ID)

    api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_DELETE,
        f"/machines/{machine_id}/agent-pairings/{pairing_id}",
        RESPONSE_SHAPE_RAW,
        auth=AuthPlatform(),
    )
