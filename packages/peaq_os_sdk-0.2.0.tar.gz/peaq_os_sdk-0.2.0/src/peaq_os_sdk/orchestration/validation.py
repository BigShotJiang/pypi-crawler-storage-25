"""Response shape validation helpers for the orchestration API.

These guards are used by the transport layer to verify parsed JSON bodies
match expected envelopes before returning them to callers.

"""

from __future__ import annotations

from typing import Any

from peaq_os_sdk.orchestration.errors import OrchestrationApiError

INVALID_RESPONSE_SHAPE = "INVALID_RESPONSE_SHAPE"

ITEM_ENVELOPE_ERROR = "Invalid response: expected { item } envelope"
LIST_ENVELOPE_ERROR = "Invalid response: expected { items, nextCursor? } list envelope"
ERROR_ENVELOPE_ERROR = "Invalid error response: expected { error } envelope"
ERROR_BODY_ERROR = "Invalid error response: expected { error: { code, message } }"
EXECUTE_RESPONSE_ERROR = (
    "Invalid response: expected { order, execution: { status_code } } "
    "with native (200) or handoff (202) shape"
)


def assert_item_response(data: object) -> None:
    """Assert *data* is a dict containing an ``item`` key (any value, including ``None``).

    Raises:
        OrchestrationApiError: If the shape is invalid (code ``INVALID_RESPONSE_SHAPE``,
            HTTP status ``0`` — not an upstream HTTP status).
    """
    if not isinstance(data, dict) or "item" not in data:
        raise OrchestrationApiError(
            ITEM_ENVELOPE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )


def assert_list_response(data: object) -> None:
    """Assert *data* is a list envelope with ``items`` (array).

    ``nextCursor`` may be a string, ``null``, or omitted when there is no next
    page (the server often drops the field on the final page).

    Raises:
        OrchestrationApiError: If the shape is invalid.
    """
    if not isinstance(data, dict):
        raise OrchestrationApiError(
            LIST_ENVELOPE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    body: dict[str, Any] = data
    if "items" not in body or not isinstance(body["items"], list):
        raise OrchestrationApiError(
            LIST_ENVELOPE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    if (
        "nextCursor" in body
        and body["nextCursor"] is not None
        and not isinstance(body["nextCursor"], str)
    ):
        raise OrchestrationApiError(
            LIST_ENVELOPE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )


def assert_error_response(data: object) -> None:
    """Assert *data* matches ``{ "error": { "code": str, "message": str, ... } }``.

    Extra keys on ``error`` are allowed.

    Raises:
        OrchestrationApiError: If the shape is invalid.
    """
    if not isinstance(data, dict) or "error" not in data:
        raise OrchestrationApiError(
            ERROR_ENVELOPE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    err = data["error"]
    if not isinstance(err, dict) or "code" not in err or not isinstance(err["code"], str):
        raise OrchestrationApiError(
            ERROR_BODY_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    if "message" not in err or not isinstance(err["message"], str):
        raise OrchestrationApiError(
            ERROR_BODY_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )


def assert_execute_response(data: object) -> None:
    """Assert *data* matches the execute market order response contract.

    Validates native (200) and handoff (202) execution shapes after wire
    conversion to snake_case keys.

    Raises:
        OrchestrationApiError: If the shape is invalid.
    """
    if not isinstance(data, dict) or "order" not in data or "execution" not in data:
        raise OrchestrationApiError(
            EXECUTE_RESPONSE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    execution = data["execution"]
    if not isinstance(execution, dict) or "status_code" not in execution:
        raise OrchestrationApiError(
            EXECUTE_RESPONSE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
    status_code = execution["status_code"]
    if status_code == 200:
        run = execution.get("run")
        outcome = execution.get("outcome")
        if not isinstance(run, dict) or not isinstance(outcome, dict):
            raise OrchestrationApiError(
                EXECUTE_RESPONSE_ERROR,
                INVALID_RESPONSE_SHAPE,
                0,
            )
    elif status_code == 202:
        handoff = execution.get("handoff")
        if not isinstance(handoff, dict):
            raise OrchestrationApiError(
                EXECUTE_RESPONSE_ERROR,
                INVALID_RESPONSE_SHAPE,
                0,
            )
        if not isinstance(handoff.get("label"), str) or not isinstance(handoff.get("url"), str):
            raise OrchestrationApiError(
                EXECUTE_RESPONSE_ERROR,
                INVALID_RESPONSE_SHAPE,
                0,
            )
    else:
        raise OrchestrationApiError(
            EXECUTE_RESPONSE_ERROR,
            INVALID_RESPONSE_SHAPE,
            0,
        )
