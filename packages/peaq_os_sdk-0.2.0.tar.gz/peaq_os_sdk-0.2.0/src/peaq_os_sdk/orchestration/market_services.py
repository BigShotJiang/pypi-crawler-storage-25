"""Market service catalog functions — list and retrieve market services.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Generator, Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_GET
from peaq_os_sdk.types.orchestration.common import (
    ExecutionMode,
    ItemResponse,
    ListResponse,
    ServiceType,
)
from peaq_os_sdk.types.orchestration.market_service import MarketService

from ._internal.helpers import (
    assert_non_empty_string,
    external_handoff_from_wire,
    to_transport_config,
)
from .pagination import pagination_query_params
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "GetMarketServiceOptions",
    "ListMarketServicesOptions",
    "get_market_service",
    "list_market_services",
    "list_market_services_all",
]

FIELD_SERVICE_ID = "service_id"


@dataclass(frozen=True, slots=True)
class ListMarketServicesOptions:
    """Optional filters for :func:`list_market_services`.

    Experimental: the orchestration API is under active development.
    """

    machine_id: str | None = None
    service_type: ServiceType | None = None
    execution_mode: ExecutionMode | None = None
    provider_key: str | None = None


@dataclass(frozen=True, slots=True)
class GetMarketServiceOptions:
    """Optional parameters for :func:`get_market_service`.

    Experimental: the orchestration API is under active development.
    """

    machine_id: str | None = None


# ── Wire → model ────────────────────────────────────────────


def _market_service_from_wire(data: Mapping[str, Any]) -> MarketService:
    return MarketService(
        id=data["id"],
        skill_key=data["skill_key"],
        provider_key=data["provider_key"],
        provider_id=data["provider_id"],
        provider_label=data["provider_label"],
        service_type=data["service_type"],
        name=data["name"],
        description=data["description"],
        operations=tuple(data.get("operations") or ()),
        auth_type=data["auth_type"],
        access_mode=data["access_mode"],
        execution_mode=data["execution_mode"],
        integration_status=data["integration_status"],
        distribution=data["distribution"],
        maturity=data["maturity"],
        kind=data["kind"],
        capabilities=tuple(data.get("capabilities") or ()),
        region=data["region"],
        freshness_seconds=data["freshness_seconds"],
        requires_human_enablement=data["requires_human_enablement"],
        metadata=dict(data.get("metadata") or {}),
        updated_at=data["updated_at"],
        reference_url=data.get("reference_url"),
        artifact_url=data.get("artifact_url"),
        handoff=external_handoff_from_wire(data.get("handoff")),
    )


def list_market_services(
    client: PeaqosClient,
    options: ListMarketServicesOptions | None = None,
    *,
    limit: int | None = None,
    cursor: str | None = None,
) -> ListResponse[MarketService]:
    """List services available in the market catalog.

    Endpoint: ``GET /market/services``
    Auth: platform (``x-api-key``)

    Optional query filters: ``machine_id``, ``service_type``, ``execution_mode``,
    ``provider_key``.

    Experimental: the orchestration API is under active development.

    Args:
        client: The SDK client instance.
        options: Optional filter parameters.
        limit: Optional page size (``1``..``500``).
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
    """
    extra: dict[str, str] = {}
    if options is not None:
        if options.machine_id is not None:
            extra["machine_id"] = options.machine_id
        if options.service_type is not None:
            extra["service_type"] = options.service_type
        if options.execution_mode is not None:
            extra["execution_mode"] = options.execution_mode
        if options.provider_key is not None:
            extra["provider_key"] = options.provider_key

    query = pagination_query_params(limit=limit, cursor=cursor, extra=extra or None)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        "/market/services",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
        query=query,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_market_service_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def list_market_services_all(
    client: PeaqosClient,
    options: ListMarketServicesOptions | None = None,
    *,
    limit: int | None = None,
) -> Generator[MarketService, None, None]:
    """Iterate over every market service across all pages.

    Convenience wrapper around :func:`list_market_services` that traverses
    ``next_cursor`` pages and yields one :class:`MarketService` at a time.
    ``options`` filters are forwarded on every page call.

    Args:
        client: The SDK client instance.
        options: Optional filters (``machine_id``, ``service_type``,
            ``execution_mode``, ``provider_key``), forwarded on every page.
        limit: Optional per-page size (``1``..``500``).

    Yields:
        Each :class:`MarketService` from every page in order.

    Raises:
        OrchestrationValidationError: If ``limit`` is outside ``1``..``500``.
        OrchestrationApiError: On server errors during any page fetch.
        OrchestrationNetworkError: On network failures during any page fetch.
    """
    cursor: str | None = None
    while True:
        page = list_market_services(client, options, limit=limit, cursor=cursor)
        yield from page.items
        if page.next_cursor is None:
            return
        cursor = page.next_cursor


def get_market_service(
    client: PeaqosClient,
    service_id: str,
    options: GetMarketServiceOptions | None = None,
) -> ItemResponse[MarketService]:
    """Retrieve a single market service by id.

    Endpoint: ``GET /market/services/:serviceId``
    Auth: platform (``x-api-key``)

    Optional query: ``machine_id`` scopes the response to a specific machine.

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(service_id, FIELD_SERVICE_ID)

    query: dict[str, str] = {}
    if options is not None and options.machine_id is not None:
        query["machine_id"] = options.machine_id

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/market/services/{service_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        query=query or None,
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_service_from_wire(item))
