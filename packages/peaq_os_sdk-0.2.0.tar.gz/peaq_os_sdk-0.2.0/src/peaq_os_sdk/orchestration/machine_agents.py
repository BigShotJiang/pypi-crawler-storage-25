"""Machine-side runtime agent functions — list, enroll, revoke, heartbeat.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_DELETE, HTTP_METHOD_GET, HTTP_METHOD_POST
from peaq_os_sdk.types.orchestration.common import ItemResponse, ListResponse
from peaq_os_sdk.types.orchestration.machine_agent import (
    EnrollMachineAgentRequest,
    HeartbeatEndpointResult,
    MachineAgent,
    MachineAgentHeartbeatPayload,
    MachineAgentHeartbeatRequest,
    MachineAgentHeartbeatResponse,
)

from ._internal.helpers import assert_non_empty_string, strip_nones, to_transport_config
from .errors import OrchestrationValidationError
from .transport import (
    RESPONSE_SHAPE_ITEM,
    RESPONSE_SHAPE_LIST,
    RESPONSE_SHAPE_RAW,
    AuthNone,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "enroll_machine_agent",
    "list_machine_agents",
    "machine_agent_heartbeat",
    "revoke_machine_agent",
]

FIELD_MACHINE_ID = "machine_id"
FIELD_AGENT_ID = "agent_id"


def _machine_agent_from_wire(data: Mapping[str, Any]) -> MachineAgent:
    return MachineAgent(
        id=data["id"],
        machine_id=data["machine_id"],
        label=data["label"],
        allowed_provider_keys=tuple(data.get("allowed_provider_keys") or ()),
        status=data["status"],
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        last_seen_at=data.get("last_seen_at"),
        provisioning_token=data.get("provisioning_token"),
    )


def _endpoint_result_from_wire(data: Mapping[str, Any]) -> HeartbeatEndpointResult:
    return HeartbeatEndpointResult(
        provider_key=data["provider_key"],
        endpoint_base_url=data["endpoint_base_url"],
        status=data["status"],
        lease_expires_at=data["lease_expires_at"],
        health_error=data.get("health_error"),
    )


def _heartbeat_payload_from_wire(data: Mapping[str, Any]) -> MachineAgentHeartbeatPayload:
    eps = data["endpoints"]
    if not isinstance(eps, list):
        raise TypeError("expected list for heartbeat endpoints")
    return MachineAgentHeartbeatPayload(
        machine_id=data["machine_id"],
        agent_id=data["agent_id"],
        lease_ttl_seconds=data["lease_ttl_seconds"],
        observed_at=data["observed_at"],
        endpoints=tuple(_endpoint_result_from_wire(x) for x in eps),
    )


def list_machine_agents(client: PeaqosClient, machine_id: str) -> ListResponse[MachineAgent]:
    """List agents enrolled on a machine.

    Endpoint: ``GET /machines/:machineId/agents``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/machines/{machine_id}/agents",
        RESPONSE_SHAPE_LIST,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict list response from orchestration API")
    raw_items = raw["items"]
    if not isinstance(raw_items, list):
        raise TypeError("expected list for items envelope payload")
    nc = raw.get("next_cursor")
    return ListResponse(
        items=tuple(_machine_agent_from_wire(x) for x in raw_items),
        next_cursor=None if nc is None else str(nc),
    )


def enroll_machine_agent(
    client: PeaqosClient,
    machine_id: str,
    params: EnrollMachineAgentRequest | None = None,
) -> ItemResponse[MachineAgent]:
    """Enroll a machine-side runtime agent (returns one-time ``provisioning_token``).

    Endpoint: ``POST /machines/:machineId/agents/enrollment`` (ENDPOINT NOT SHARED)
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        f"/machines/{machine_id}/agents/enrollment",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
        body=strip_nones(asdict(params)) if params is not None else {},
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_machine_agent_from_wire(item))


def revoke_machine_agent(client: PeaqosClient, machine_id: str, agent_id: str) -> None:
    """Revoke a machine-side runtime agent (``204 No Content``).

    Endpoint: ``DELETE /machines/:machineId/agents/:agentId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(agent_id, FIELD_AGENT_ID)

    api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_DELETE,
        f"/machines/{machine_id}/agents/{agent_id}",
        RESPONSE_SHAPE_RAW,
        auth=AuthPlatform(),
    )


def machine_agent_heartbeat(
    client: PeaqosClient,
    params: MachineAgentHeartbeatRequest,
) -> MachineAgentHeartbeatResponse:
    """Send a heartbeat from a machine runtime agent (body carries ``agent_token``).

    Endpoint: ``POST /machine-agents/heartbeat``
    Auth: none (token in JSON body).

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(params.machine_id, FIELD_MACHINE_ID)
    assert_non_empty_string(params.agent_id, FIELD_AGENT_ID)
    assert_non_empty_string(params.agent_token, "agent_token")

    if len(params.endpoints) == 0:
        raise OrchestrationValidationError(
            "endpoints must contain at least one entry",
            "endpoints",
            "non-empty array",
        )

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        "/machine-agents/heartbeat",
        RESPONSE_SHAPE_ITEM,
        auth=AuthNone(),
        body=asdict(params),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_heartbeat_payload_from_wire(item))
