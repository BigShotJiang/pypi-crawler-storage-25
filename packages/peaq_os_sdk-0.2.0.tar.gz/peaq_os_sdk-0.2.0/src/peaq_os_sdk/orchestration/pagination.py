"""Pagination contract helpers for orchestration list endpoints.

* **First page:** omit the ``cursor`` query parameter.
* **Opaque cursors:** pass ``cursor`` through unchanged — never parse, modify,
  or persist server cursors in application logic.
* **End of collection:** ``ListResponse.next_cursor`` is ``None``.
* **Invalid ``limit`` or ``cursor`` on the wire:** the server responds with
  HTTP 400 and ``VALIDATION_ERROR``.
* **Client-side ``limit``:** reject ``limit < 1`` or ``limit > 500`` with
  :class:`~peaq_os_sdk.orchestration.errors.OrchestrationValidationError`
  before any HTTP request.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Mapping

from peaq_os_sdk.types.orchestration.common import LIST_QUERY_MAX_LIMIT, ListQuery

from .errors import OrchestrationValidationError

FIELD_LIMIT = "limit"
FIELD_CURSOR = "cursor"

_CONSTRAINT_LIMIT_MIN = f"integer between 1 and {LIST_QUERY_MAX_LIMIT}"
_CONSTRAINT_LIMIT_MAX = f"integer between 1 and {LIST_QUERY_MAX_LIMIT}"


def validate_list_limit(limit: int | None) -> None:
    """Validate a list ``limit`` before sending it as a query parameter.

    ``None`` is allowed (the server applies
    :data:`~peaq_os_sdk.types.orchestration.common.LIST_QUERY_DEFAULT_LIMIT`).

    Args:
        limit: Requested page size, or ``None`` to omit the query param.

    Raises:
        OrchestrationValidationError: If ``limit`` is less than 1 or greater than
            :data:`~peaq_os_sdk.types.orchestration.common.LIST_QUERY_MAX_LIMIT`.
    """
    if limit is None:
        return
    if limit < 1:
        raise OrchestrationValidationError(
            f"{FIELD_LIMIT} must be at least 1",
            FIELD_LIMIT,
            _CONSTRAINT_LIMIT_MIN,
        )
    if limit > LIST_QUERY_MAX_LIMIT:
        raise OrchestrationValidationError(
            f"{FIELD_LIMIT} must be at most {LIST_QUERY_MAX_LIMIT}",
            FIELD_LIMIT,
            _CONSTRAINT_LIMIT_MAX,
        )


def pagination_query_params(
    *,
    limit: int | None = None,
    cursor: str | None = None,
    list_query: ListQuery | None = None,
    extra: Mapping[str, str] | None = None,
) -> dict[str, str] | None:
    """Build query parameters for a paginated list request.

    Validates ``limit`` via :func:`validate_list_limit`. Omits ``cursor`` when
    it is ``None`` (first page). Merges ``extra`` filter params (e.g.
    ``machine_id``) without validation.

    Args:
        limit: Page size query param, or ``None`` to omit.
        cursor: Opaque cursor from a prior ``next_cursor``, or ``None`` for the
            first page.
        list_query: Optional :class:`~peaq_os_sdk.types.orchestration.common.ListQuery`
            whose fields apply when the explicit ``limit`` / ``cursor`` arguments
            are ``None``.
        extra: Additional required or optional list filters.

    Returns:
        Query dict for :func:`~peaq_os_sdk.orchestration.transport.api_request`,
        or ``None`` when empty.
    """
    resolved_limit = limit
    resolved_cursor = cursor
    if list_query is not None:
        if resolved_limit is None:
            resolved_limit = list_query.limit
        if resolved_cursor is None:
            resolved_cursor = list_query.cursor

    validate_list_limit(resolved_limit)

    query: dict[str, str] = dict(extra or ())
    if resolved_limit is not None:
        query[FIELD_LIMIT] = str(resolved_limit)
    if resolved_cursor is not None:
        query[FIELD_CURSOR] = resolved_cursor
    return query or None


__all__ = [
    "FIELD_CURSOR",
    "FIELD_LIMIT",
    "pagination_query_params",
    "validate_list_limit",
]
