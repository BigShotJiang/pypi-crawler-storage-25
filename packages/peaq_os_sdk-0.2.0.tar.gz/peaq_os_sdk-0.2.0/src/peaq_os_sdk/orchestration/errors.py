"""Typed exceptions for the orchestration (Machine Markets) HTTP client.

Experimental: the orchestration API is under active development; error codes
and transport behavior may change without notice.
"""

from __future__ import annotations

from typing import Any

from peaq_os_sdk.exceptions.base import PeaqosError


class OrchestrationError(PeaqosError):
    """Base class for orchestration-related failures.

    Experimental: the orchestration API is under active development.

    Catch this type to handle orchestration failures separately from other
    :class:`~peaq_os_sdk.exceptions.PeaqosError` subclasses.
    """

    def __init__(self, message: str, *, code: str = "") -> None:
        super().__init__(message, code=code)


class OrchestrationApiError(OrchestrationError):
    """Raised when the orchestration API returns HTTP 4xx/5xx with an error body.

    Experimental: the orchestration API is under active development.

    Attributes:
        code: Server error code (known ``CommonErrorCode`` values or any string
            the service returns).
        status_code: HTTP status code from the response.
        details: Optional structured detail payload from the server.
    """

    def __init__(
        self,
        message: str,
        code: str,
        status_code: int,
        details: Any | None = None,
    ) -> None:
        super().__init__(message, code=code)
        self.status_code: int = status_code
        self.details: Any | None = details


class OrchestrationNetworkError(OrchestrationError):
    """Raised when the orchestration service cannot be reached over the network.

    Experimental: the orchestration API is under active development.

    Prefer ``raise OrchestrationNetworkError(...) from err`` so the original
    :exc:`requests.RequestException` (or other transport error) is available
    on :attr:`!__cause__`.
    """

    def __init__(self, message: str, cause: BaseException | None = None) -> None:
        super().__init__(message)
        if cause is not None:
            self.__cause__ = cause


class OrchestrationConfigError(OrchestrationError):
    """Raised when orchestration is used without required client configuration.

    Experimental: the orchestration API is under active development.

    Examples include a missing ``orchestration_url`` or credentials required
    for the requested auth mode.
    """


class OrchestrationValidationError(OrchestrationError):
    """Raised for client-side input validation before an HTTP request is sent.

    Experimental: the orchestration API is under active development.

    Attributes:
        field: Parameter name that failed validation.
        constraint: Short description of the violated rule.
    """

    def __init__(self, message: str, field: str, constraint: str) -> None:
        super().__init__(message)
        self.field: str = field
        self.constraint: str = constraint
