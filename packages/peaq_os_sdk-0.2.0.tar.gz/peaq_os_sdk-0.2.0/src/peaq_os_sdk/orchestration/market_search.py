"""Market search functions — initiate and retrieve market searches.

Experimental: the orchestration API is under active development.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from peaq_os_sdk.constants import HTTP_METHOD_GET, HTTP_METHOD_POST
from peaq_os_sdk.types.orchestration.common import (
    ItemResponse,
    MarketPaymentRailRecommendation,
)
from peaq_os_sdk.types.orchestration.market_search import (
    MarketSearch,
    MarketSearchRequest,
    NormalizedTask,
)
from peaq_os_sdk.types.orchestration.market_service import MarketQuote, QuotePricing

from ._internal.helpers import (
    assert_non_empty_string,
    external_handoff_from_wire,
    strip_nones,
    to_transport_config,
)
from .transport import (
    RESPONSE_SHAPE_ITEM,
    AuthAgentPairing,
    AuthPlatform,
    api_request,
)

if TYPE_CHECKING:
    from peaq_os_sdk.client import PeaqosClient

__all__ = [
    "get_market_search",
    "search_market",
]

FIELD_SEARCH_ID = "search_id"
FIELD_PAIRING_TOKEN = "pairing_token"


def _quote_pricing_from_wire(data: Mapping[str, Any]) -> QuotePricing:
    return QuotePricing(
        mode=data["mode"],
        notes=tuple(data.get("notes") or ()),
        amount=data.get("amount"),
        currency=data.get("currency"),
        rate=data.get("rate"),
    )


def _payment_rail_from_wire(data: Mapping[str, Any]) -> MarketPaymentRailRecommendation:
    return MarketPaymentRailRecommendation(
        default_rail=data["default_rail"],
        supported_rails=tuple(data.get("supported_rails") or ()),
        required=data["required"],
        notes=tuple(data.get("notes") or ()),
        provider=data.get("provider"),
        chain=data.get("chain"),
        token=data.get("token"),
        token_address=data.get("token_address"),
        token_mint=data.get("token_mint"),
        wallet_address=data.get("wallet_address"),
        external_url=data.get("external_url"),
        payer_address=data.get("payer_address"),
        payee_address=data.get("payee_address"),
    )


def _market_quote_from_wire(data: Mapping[str, Any]) -> MarketQuote:
    pricing = data["pricing"]
    payment = data["payment"]
    if not isinstance(pricing, dict):
        raise TypeError("expected dict for quote pricing")
    if not isinstance(payment, dict):
        raise TypeError("expected dict for quote payment")
    return MarketQuote(
        id=data["id"],
        service_id=data["service_id"],
        skill_key=data["skill_key"],
        provider_key=data["provider_key"],
        execution_mode=data["execution_mode"],
        integration_status=data["integration_status"],
        operation=data["operation"],
        score=data["score"],
        reasons=tuple(data.get("reasons") or ()),
        pricing=_quote_pricing_from_wire(pricing),
        payment=_payment_rail_from_wire(payment),
        expires_at=data["expires_at"],
        handoff=external_handoff_from_wire(data.get("handoff")),
    )


def _normalized_task_from_wire(data: Mapping[str, Any]) -> NormalizedTask:
    return NormalizedTask(
        service_type=data["service_type"],
        required_capabilities=tuple(data.get("required_capabilities") or ()),
        allow_external_handoff=data["allow_external_handoff"],
        require_native_execution=data["require_native_execution"],
        operation=data.get("operation"),
        region=data.get("region"),
    )


def _request_payload_from_wire(data: Mapping[str, Any]) -> Mapping[str, Any]:
    raw = data.get("request_payload")
    if raw is None:
        raw = data.get("request")
    return dict(raw) if raw is not None else {}


def _market_search_from_wire(data: Mapping[str, Any]) -> MarketSearch:
    nt = data["normalized_task"]
    if not isinstance(nt, dict):
        raise TypeError("expected dict for normalized_task")
    quotes_raw = data["quotes"]
    if not isinstance(quotes_raw, list):
        raise TypeError("expected list for quotes")
    return MarketSearch(
        id=data["id"],
        machine_id=data["machine_id"],
        request_payload=_request_payload_from_wire(data),
        normalized_task=_normalized_task_from_wire(nt),
        status=data["status"],
        quotes=tuple(_market_quote_from_wire(q) for q in quotes_raw),
        created_at=data["created_at"],
        agent_pairing_id=data.get("agent_pairing_id"),
    )


def search_market(
    client: PeaqosClient,
    params: MarketSearchRequest,
    pairing_token: str,
) -> ItemResponse[MarketSearch]:
    """Initiate a market search and return scored quotes.

    Uses agent-pairing authentication: ``pairing_token`` is sent as the
    ``x-agent-pairing-token`` header.

    Endpoint: ``POST /market/search``
    Auth: agent-pairing (``x-agent-pairing-token``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(pairing_token, FIELD_PAIRING_TOKEN)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_POST,
        "/market/search",
        RESPONSE_SHAPE_ITEM,
        auth=AuthAgentPairing(token=pairing_token),
        body=strip_nones(asdict(params)),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_search_from_wire(item))


def get_market_search(client: PeaqosClient, search_id: str) -> ItemResponse[MarketSearch]:
    """Retrieve a market search by id (platform auth).

    Endpoint: ``GET /market/searches/:searchId``
    Auth: platform (``x-api-key``)

    Experimental: the orchestration API is under active development.
    """
    assert_non_empty_string(search_id, FIELD_SEARCH_ID)

    raw = api_request(
        to_transport_config(client),
        client.session,
        HTTP_METHOD_GET,
        f"/market/searches/{search_id}",
        RESPONSE_SHAPE_ITEM,
        auth=AuthPlatform(),
    )
    if not isinstance(raw, dict):
        raise TypeError("expected dict item response from orchestration API")
    item = raw["item"]
    if not isinstance(item, dict):
        raise TypeError("expected dict for item envelope payload")
    return ItemResponse(item=_market_search_from_wire(item))
