"""Protocol constants for the peaqOS SDK."""

from __future__ import annotations

from typing import Final, Literal

# ── Event types ──────────────────────────────────────────────

EVENT_TYPE_REVENUE: Final[int] = 0
"""Revenue event (eventType = 0)."""

EVENT_TYPE_ACTIVITY: Final[int] = 1
"""Activity event (eventType = 1)."""

# ── Trust levels ─────────────────────────────────────────────

TRUST_SELF_REPORTED: Final[int] = 0
"""Self-reported data with no independent verification."""

TRUST_ON_CHAIN_VERIFIABLE: Final[int] = 1
"""Data verifiable against an on-chain transaction."""

TRUST_HARDWARE_SIGNED: Final[int] = 2
"""Data signed by tamper-resistant hardware."""

# ── Data visibility ──────────────────────────────────────────

DATA_VISIBILITY_PUBLIC: Final[str] = "public"
"""Machine data is publicly visible."""

DATA_VISIBILITY_PRIVATE: Final[str] = "private"
"""Machine data is private."""

DATA_VISIBILITY_ONCHAIN: Final[str] = "onchain"
"""Machine data is visible only on-chain."""

# ── MCR ratings ──────────────────────────────────────────────

MCR_RATING_AAA: Final[str] = "AAA"
"""Score >= 95."""

MCR_RATING_AA: Final[str] = "AA"
"""Score >= 85."""

MCR_RATING_A: Final[str] = "A"
"""Score >= 75."""

MCR_RATING_BBB: Final[str] = "BBB"
"""Score >= 60."""

MCR_RATING_BB: Final[str] = "BB"
"""Score >= 45."""

MCR_RATING_B: Final[str] = "B"
"""Score >= 30."""

MCR_RATING_NR: Final[str] = "NR"
"""Score < 30 (not rated)."""

# ── Machine status ───────────────────────────────────────────

MACHINE_STATUS_NONE: Final[int] = 0
"""Machine has no status."""

MACHINE_STATUS_PENDING: Final[int] = 1
"""Machine registration is pending verification."""

MACHINE_STATUS_VERIFIED: Final[int] = 2
"""Machine is verified and active."""

MACHINE_STATUS_REJECTED: Final[int] = 3
"""Machine registration was rejected."""

MACHINE_STATUS_DEACTIVATED: Final[int] = 4
"""Machine has been deactivated."""

# ── DID attribute keys ───────────────────────────────────────

DID_ATTR_MACHINE_ID: Final[str] = "machineId"
"""DID attribute: machine identifier."""

DID_ATTR_NFT_TOKEN_ID: Final[str] = "nftTokenId"
"""DID attribute: NFT token identifier."""

DID_ATTR_OPERATOR: Final[str] = "operator"
"""DID attribute: operator DID reference."""

DID_ATTR_DOCUMENTATION_URL: Final[str] = "documentation_url"
"""DID attribute: documentation URL."""

DID_ATTR_DATA_API: Final[str] = "data_api"
"""DID attribute: data API endpoint."""

DID_ATTR_DATA_VISIBILITY: Final[str] = "data_visibility"
"""DID attribute: data visibility setting."""

DID_ATTR_MACHINES: Final[str] = "machines"
"""DID attribute: list of machine IDs for proxy operators."""

# ── DID constraints ──────────────────────────────────────────

DID_MAX_NAME_BYTES: Final[int] = 64
"""Maximum byte length of a DID attribute name."""

DID_MAX_VALUE_BYTES: Final[int] = 2560
"""Maximum byte length of a DID attribute value."""

# ── Supported chains ─────────────────────────────────────────

SUPPORTED_CHAINS: Final[dict[str, int]] = {
    "peaq": 3338,
    "ethereum": 1,
    "base": 8453,
    "polygon": 137,
    "arbitrum": 42161,
    "optimism": 10,
}
"""Chain IDs recognized by the protocol."""

# ── LayerZero endpoint IDs ───────────────────────────────────

LAYERZERO_EIDS: Final[dict[str, int]] = {
    "peaq": 30302,
    "base": 30184,
}
"""LayerZero V2 endpoint IDs for cross-chain bridging."""

# ── Defaults ─────────────────────────────────────────────────

DEFAULT_API_URL: Final[str] = "http://127.0.0.1:8000"
"""Default API URL when PEAQOS_MCR_API_URL is not set."""

# ── OWS (Open Wallet Standard) ──────────────────────────────

OWS_PASSPHRASE_ENV: Final[str] = "OWS_PASSPHRASE"
"""Environment variable name for the OWS vault passphrase."""

IMPORT_CHAIN_EVM: Final = "evm"
"""Import chain family: EVM (Ethereum, peaq, Base, Polygon, ...)."""

IMPORT_CHAIN_SOLANA: Final = "solana"
"""Import chain family: Solana."""

IMPORT_CHAIN_BITCOIN: Final = "bitcoin"
"""Import chain family: Bitcoin."""

IMPORT_CHAIN_COSMOS: Final = "cosmos"
"""Import chain family: Cosmos."""

IMPORT_CHAIN_TRON: Final = "tron"
"""Import chain family: Tron."""

IMPORT_CHAIN_TON: Final = "ton"
"""Import chain family: TON."""

IMPORT_CHAIN_SUI: Final = "sui"
"""Import chain family: Sui."""

IMPORT_CHAIN_XRPL: Final = "xrpl"
"""Import chain family: XRPL."""

IMPORT_CHAIN_SPARK: Final = "spark"
"""Import chain family: Spark."""

IMPORT_CHAIN_FILECOIN: Final = "filecoin"
"""Import chain family: Filecoin."""

# ── OWS signing error codes ──────────────────────────────────

OWS_ERROR_WALLET_NOT_FOUND: Final[str] = "WALLET_NOT_FOUND"
"""OWS error code: wallet not found in the vault."""

OWS_ERROR_INVALID_PASSPHRASE: Final[str] = "INVALID_PASSPHRASE"
"""OWS error code: wrong vault passphrase."""

OWS_ERROR_INVALID_INPUT: Final[str] = "INVALID_INPUT"
"""OWS error code: malformed transaction or input data."""

OWS_ERROR_POLICY_DENIED: Final[str] = "POLICY_DENIED"
"""OWS error code: signing blocked by a policy rule."""

OWS_ERROR_CHAIN_NOT_SUPPORTED: Final[str] = "CHAIN_NOT_SUPPORTED"
"""OWS error code: chain not configured in OWS."""

HttpMethod = Literal["GET", "POST", "PATCH", "PUT", "DELETE"]

# ── HTTP methods ────────────────────────────────────────────

HTTP_METHOD_GET: Final[HttpMethod] = "GET"
"""HTTP GET method."""

HTTP_METHOD_POST: Final[HttpMethod] = "POST"
"""HTTP POST method."""

HTTP_METHOD_PATCH: Final[HttpMethod] = "PATCH"
"""HTTP PATCH method."""

HTTP_METHOD_PUT: Final[HttpMethod] = "PUT"
"""HTTP PUT method."""

HTTP_METHOD_DELETE: Final[HttpMethod] = "DELETE"
"""HTTP DELETE method."""
