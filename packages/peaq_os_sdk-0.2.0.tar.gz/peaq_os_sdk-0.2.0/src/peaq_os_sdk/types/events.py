"""Event-related types."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Final, Literal

from .primitives import Hex32

# Shared currency shape source — mirrors the on-chain
# ``EventRegistry._isValidCurrencyShape`` (PRO-338 Phase A+B). Used by:
# * write side (``validation.submit_event._validate_currency``) to reject
#   bad inputs before tx
# * read side (``query._internal.response_guards._guard_event_entries``)
#   to reject malformed server output
# Both sides MUST share this constant so a contract-level upgrade
# (e.g. lowercase support, length change) flows through one source of
# truth instead of drifting between the two parsers.
# NOTE: ``\A`` / ``\Z`` instead of ``^`` / ``$`` is deliberate — Python
# ``re`` ``$`` matches at the end of the string OR immediately before a
# trailing ``\n``, which would silently accept ``"USD\n"`` and let it
# hit the on-chain ``EventRegistry._isValidCurrencyShape`` check
# (different regex engine, different behaviour). ``\A...\Z`` anchors
# the entire string strictly.
_REVENUE_CURRENCY_PATTERN: Final[str] = r"\A[A-Z0-9]{3,10}\Z"
_REVENUE_CURRENCY_RE: Final[re.Pattern[str]] = re.compile(_REVENUE_CURRENCY_PATTERN)

EventType = Literal[0, 1]
"""Event type: 0 = Revenue, 1 = Activity."""

TrustLevel = Literal[0, 1, 2]
"""Trust level: 0 = Self-reported, 1 = On-chain verifiable, 2 = Hardware-signed."""

# Module-private sentinel for ``SubmitEventParams.currency``: signals
# "kwarg not provided by caller". Single-event submission resolves it via
# smart default (revenue → "USD", activity → ""); batch submission treats
# it as ValidationError per ticket §6 strict-required rule.
#
# The literal ``"<__OMITTED__>"`` is chosen because the angle-brackets fall
# outside the revenue currency regex ``^[A-Z0-9]{3,10}$`` and the empty
# string used for activity, so accidental collisions with a real caller
# value are impossible — a buggy caller passing the sentinel string
# directly would still be rejected by the same shape validation.
_OMITTED_CURRENCY: Final[str] = "<__OMITTED__>"


@dataclass(frozen=True, slots=True)
class SubmitEventParams:
    """Parameters for submitting a machine event on-chain.

    Args:
        machine_id: The machine's on-chain identifier (positive integer).
        event_type: 0 for revenue, 1 for activity.
        value: Non-negative event value.
        timestamp: Unix timestamp in seconds (positive integer).
        raw_data: Raw event payload, or None if not provided.
        trust_level: 0 = self-reported, 1 = on-chain verifiable, 2 = hardware-signed.
        source_chain_id: Chain ID of the event source.
        source_tx_hash: Source transaction hash (0x-prefixed 32-byte hex), or None.
        metadata: Arbitrary metadata bytes.
        currency: Per ticket PRO-336 §6 — for revenue events, must match
            ``^[A-Z0-9]{3,10}$`` (e.g. ``"USD"``, ``"HKD"``). For activity
            events, must be ``""``. Omitting the kwarg in single-event
            ``submit_event`` triggers a smart default (``"USD"`` for revenue,
            ``""`` for activity); ``batch_submit_events`` treats omission as
            ``ValidationError(field="currency")`` (strict-required). Passing
            ``None`` explicitly is always rejected.

    Example:
        >>> params = SubmitEventParams(
        ...     machine_id=1,
        ...     event_type=0,
        ...     value=100,
        ...     timestamp=1700000000,
        ...     raw_data=b"revenue data",
        ...     trust_level=0,
        ...     source_chain_id=3338,
        ...     source_tx_hash=None,
        ...     metadata=b"",
        ...     currency="USD",
        ... )
    """

    machine_id: int
    event_type: int
    value: int
    timestamp: int
    raw_data: bytes | None
    trust_level: int
    source_chain_id: int
    source_tx_hash: Hex32 | None
    metadata: bytes
    currency: str | None = _OMITTED_CURRENCY


@dataclass(frozen=True, slots=True)
class MachineEvent:
    """On-chain machine event struct shape.

    Field order mirrors the Solidity ``MachineEvent`` struct returned by
    ``EventRegistry.getEventAt`` / ``getEvents`` so positional decoding
    of the ABI tuple maps 1:1 to dataclass construction. PRO-338 appended
    ``currency`` to the end of the struct; do not reorder existing fields
    when adding new ones.

    Args:
        machine_id: The machine's on-chain identifier.
        event_type: 0 for revenue, 1 for activity.
        value: Event value.
        timestamp: Unix timestamp in seconds.
        data_hash: keccak256 hash of the raw data (32 bytes).
        trust_level: 0 = self-reported, 1 = on-chain verifiable, 2 = hardware-signed.
        source_chain_id: Chain ID of the event source.
        source_tx_hash: Source transaction hash (32 bytes), or None.
        metadata: Arbitrary-length metadata bytes.
        currency: Partner-declared currency code stored with the event
            (PRO-338). Revenue events match ``^[A-Z0-9]{3,10}$`` (e.g.
            ``"USD"``, ``"HKD"``); activity events are ``""``. Enforced
            on-chain by ``EventRegistry._isValidCurrencyShape`` — this
            dataclass is read-side and trusts the chain rather than
            re-validating.

    Example:
        >>> event = MachineEvent(
        ...     machine_id=1,
        ...     event_type=0,
        ...     value=100,
        ...     timestamp=1700000000,
        ...     data_hash=b"\\x00" * 32,
        ...     trust_level=0,
        ...     source_chain_id=3338,
        ...     source_tx_hash=None,
        ...     metadata=b"",
        ...     currency="USD",
        ... )
    """

    machine_id: int
    event_type: int
    value: int
    timestamp: int
    data_hash: bytes
    trust_level: int
    source_chain_id: int
    source_tx_hash: bytes | None
    metadata: bytes
    currency: str
