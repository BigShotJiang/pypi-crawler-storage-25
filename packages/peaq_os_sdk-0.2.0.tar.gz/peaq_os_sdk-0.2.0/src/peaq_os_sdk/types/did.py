"""DID-related type definitions."""

from __future__ import annotations

from typing import TypedDict


class DIDAttributeResult(TypedDict):
    """Decoded result of a DID ``readAttribute`` call.

    Attributes:
        name: Attribute key, decoded from UTF-8 bytes.
        value: Attribute value, decoded from UTF-8 bytes.
        validity: Validity period in seconds (0 = no expiry).
        created: Block timestamp when the attribute was created.
    """

    name: str
    value: str
    validity: int
    created: int
