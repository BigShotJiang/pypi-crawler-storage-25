"""Public types for MCR query responses."""

from __future__ import annotations

from typing import Any, Final, Literal, TypedDict

# ── PRO-334 enums ────────────────────────────────────────────────

AmountStatus = Literal["ok", "unsupported_currency", "fx_unavailable"]
"""PRO-334 ``amount_status`` enum type alias — single source of truth.

Used by ``EventEntry.amount_status`` and the response guard's
``cast(AmountStatus, ...)`` so the literal isn't duplicated across the
module + the guard."""

AMOUNT_STATUS_VALUES: Final[tuple[str, ...]] = (
    "ok",
    "unsupported_currency",
    "fx_unavailable",
)
"""All accepted ``amount_status`` enum values per PRO-334.

* ``"ok"`` — FX conversion succeeded; ``usd_value`` is meaningful.
* ``"unsupported_currency"`` — partner currency not in mcs whitelist;
  ``usd_value`` is 0 and consumers must NOT display it as a USD amount.
* ``"fx_unavailable"`` — FX feed degraded (stale / outage); same display
  contract as ``unsupported_currency``.

Forward-only per PRO-334 §10: any future server-side enum addition will
surface as ``BAD_RESPONSE`` until the SDK is updated."""

USD_SUBUNIT_INVARIANT: Final[int] = 100
"""Invariant divisor for ``usd_value`` per PRO-334.

USD always uses cents as its minor unit, so ``usd_subunit`` is locked to
``100`` on the wire. The parser rejects any other value with
``BAD_RESPONSE`` so a future server-side change surfaces immediately."""

# ── Validation ranges ────────────────────────────────────────────

MCR_MIN: Final[int] = 0
"""Inclusive lower bound of a valid MCR score on the wire."""

MCR_MAX: Final[int] = 100
"""Inclusive upper bound of a valid MCR score on the wire."""

MCR_RATINGS: Final[tuple[str, ...]] = ("AAA", "AA", "A", "BBB", "BB", "B", "NR")
"""All valid MCR rating tiers, descending."""

BOND_STATUSES: Final[tuple[str, ...]] = ("bonded", "unbonded")
"""All valid bond-status values."""

REVENUE_TRENDS: Final[tuple[str, ...]] = ("up", "stable", "down", "insufficient")
"""All valid revenue-trend values."""


# ── Response dicts ───────────────────────────────────────────────


class MCRResponse(TypedDict):
    """Parsed body of ``GET {api_url}/mcr/{did}``. All keys snake_case.

    Per PRO-336 §S6 the wire response carries ``mcr_degraded: bool`` —
    ``True`` when at least one event in the scoring set used a degraded
    FX source (``stale_latest`` / ``default_usd_fx_outage``), ``False``
    otherwise. The flag distinguishes "conservative score from FX
    outage" from "empty-data machine" so consumers can gate UI / alerts
    on data quality independently of the score itself.

    Per PRO-331, ``total_revenue`` and ``average_revenue_per_event`` are
    USD-normalized values (server-side FX adapter aggregates against
    ``value_usd`` in cents-or-units depending on the configured precision).
    """

    did: str
    machine_id: int
    mcr_score: int
    mcr: str
    bond_status: str
    negative_flag: bool
    event_count: int
    revenue_event_count: int
    activity_event_count: int
    revenue_trend: str
    total_revenue: float
    average_revenue_per_event: float
    last_updated: int | None
    mcr_degraded: bool


class _EventEntryRequired(TypedDict):
    event_type: int
    origin_value: int
    timestamp: int
    trust_level: int
    metadata: dict[str, Any]


class EventEntry(_EventEntryRequired, total=False):
    """Single on-chain event with parsed metadata.

    Required fields (all events): ``event_type``, ``origin_value``,
    ``timestamp``, ``trust_level``, ``metadata``. Per PRO-336 §S5 the
    field formerly named ``value`` is renamed ``origin_value`` to make
    the partner-native unit explicit and to free the FX-normalized
    ``usd_value`` slot.

    Conditional fields (revenue events only, ``event_type == 0``):

    * ``origin_currency`` (3-10 char ISO 4217-like code).
    * ``usd_value`` (FX-normalized **USD cents** integer per PRO-334;
      display = ``usd_value / usd_subunit`` = ``usd_value / 100``).
    * ``origin_subunit`` (positive int divisor, or ``None`` when the
      partner currency is unsupported by mcs FX).
    * ``usd_subunit`` (always exactly ``100`` per PRO-334 invariant).
    * ``amount_status`` (``"ok"`` / ``"unsupported_currency"`` /
      ``"fx_unavailable"`` — consumers MUST branch on this before
      displaying ``usd_value``; non-``"ok"`` rows have no meaningful
      USD amount).

    Activity events (``event_type == 1``) omit ALL conditional keys
    entirely — they are absent rather than ``None``, so consumers must
    use ``"origin_currency" in entry`` (etc.) to test for presence
    rather than truthiness.

    BREAKING (PRO-334): ``usd_value`` semantic changed from whole USD
    to **USD cents**. Pre-PRO-334 consumers reading whole-USD will
    silently see 100x larger numbers and must update their display.

    Cross-field consistency (e.g. ``origin_subunit is None`` iff
    ``amount_status != "ok"``) is enforced **server-side**, not by the
    SDK guard. The parser only validates per-field shape per ticket
    §B7 sdk-py AC; trusting the server is the deliberate forward-only
    posture (per PRO-334 §B Q1 + §10 rollout). Consumers MUST still
    branch on ``amount_status`` before displaying ``usd_value``.
    """

    origin_currency: str
    usd_value: int | None
    origin_subunit: int | None
    usd_subunit: int
    amount_status: AmountStatus


class _PeaqosDataRequired(TypedDict):
    machine_id: int
    did: str
    operator: str | None
    mcr: str
    mcr_score: int
    bond_status: str
    negative_flag: bool
    event_count: int
    data_visibility: str
    documentation_url: str | None


class PeaqosData(_PeaqosDataRequired, total=False):
    """Inner ``peaqos`` object in the machine profile response.

    Required fields are inherited from ``_PeaqosDataRequired``.
    Conditional fields are present only when ``data_visibility`` matches.
    """

    data_api: str
    event_data: list[EventEntry]
    partner_data: dict[str, Any]
    partner_data_error: str


class MachineProfileResponse(TypedDict):
    """Parsed body of ``GET {api_url}/machine/{did}`` and ``/metadata/{tokenId}``."""

    schema_version: str
    name: str
    peaqos: PeaqosData


class OperatorMachine(TypedDict):
    """Per-machine summary returned inside :class:`OperatorMachinesResponse`."""

    did: str
    machine_id: int
    mcr_score: int
    mcr: str
    negative_flag: bool


class Pagination(TypedDict):
    """Pagination metadata returned by list endpoints."""

    offset: int
    limit: int
    total: int


class OperatorMachinesResponse(TypedDict):
    """Parsed body of ``GET {api_url}/operator/{did}/machines``."""

    operator_did: str
    machines: list[OperatorMachine]
    pagination: Pagination
