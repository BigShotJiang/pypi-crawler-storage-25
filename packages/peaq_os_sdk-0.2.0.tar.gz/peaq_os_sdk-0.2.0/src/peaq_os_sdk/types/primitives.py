"""Primitive type aliases for the peaqOS SDK."""

from __future__ import annotations

from typing import NewType

Address = NewType("Address", str)
"""Checksummed Ethereum address (``0x``-prefixed, 42 chars)."""

Hex32 = NewType("Hex32", str)
"""``0x``-prefixed hex string representing 32 bytes (66 chars)."""
