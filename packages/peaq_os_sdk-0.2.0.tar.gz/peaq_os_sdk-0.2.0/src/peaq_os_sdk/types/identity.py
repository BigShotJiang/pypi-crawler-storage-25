"""Identity and status types."""

from __future__ import annotations

from typing import Literal

DataVisibility = Literal["public", "private", "onchain"]
"""DID data visibility setting."""
