"""Runtime endpoint resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .common import EndpointAuthType, EndpointHealthStatus, EndpointNetworkScope

EndpointSource = Literal["manual", "agent"]


@dataclass(frozen=True, slots=True)
class RuntimeEndpoint:
    """A machine runtime endpoint exposing a local skill runtime (e.g. QVAC).

    Experimental: the orchestration API is under active development.
    """

    id: str
    machine_id: str
    provider_key: str
    source: EndpointSource
    label: str
    endpoint_base_url: str
    auth_type: EndpointAuthType
    has_auth_token: bool
    network_scope: EndpointNetworkScope
    probe_path: str
    status: EndpointHealthStatus
    created_at: str
    updated_at: str
    agent_id: str | None = None
    model_alias: str | None = None
    lease_expires_at: str | None = None
    last_checked_at: str | None = None
    last_healthy_at: str | None = None


@dataclass(frozen=True, slots=True)
class UpsertRuntimeEndpointRequest:
    """Request body for creating or updating a runtime endpoint.

    Experimental: the orchestration API is under active development.

    Note:
        ``auth_token`` is a secret; never log it.
    """

    endpoint_base_url: str
    label: str | None = None
    auth_type: EndpointAuthType | None = None
    auth_token: str | None = None
    model_alias: str | None = None
    network_scope: EndpointNetworkScope | None = None
    probe_path: str | None = None
    status: EndpointHealthStatus | None = None


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class ProbeRuntimeEndpointRequest:
    """Planned — ``POST`` …/runtime-endpoints/:providerKey/probe."""

    timeout_ms: int | None = None


@dataclass(frozen=True, slots=True)
class ProbeRuntimeEndpointResponse:
    """Planned — response for runtime endpoint probe."""

    provider_key: str
    status: EndpointHealthStatus
    checked_at: str
    latency_ms: int | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeEndpointLog:
    """Planned — log line item for a runtime endpoint."""

    id: str
    provider_key: str
    status: EndpointHealthStatus
    checked_at: str
    message: str | None = None
