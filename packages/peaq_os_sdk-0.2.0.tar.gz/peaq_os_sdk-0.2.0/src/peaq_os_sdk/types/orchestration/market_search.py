"""Market search resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from .common import ProviderCredentials, ServiceType
from .market_service import MarketQuote

SearchStatus = Literal["completed", "no_match"]

SearchServiceTypeAlias = Literal[
    "storage",
    "compute",
    "identity",
    "location",
    "rtk",
    "gnss",
    "defi",
    "commerce",
]


@dataclass(frozen=True, slots=True)
class NormalizedTask:
    """Normalized task interpretation from the search engine.

    Experimental: the orchestration API is under active development.
    """

    service_type: ServiceType
    required_capabilities: tuple[str, ...]
    allow_external_handoff: bool
    require_native_execution: bool
    operation: str | None = None
    region: str | None = None


@dataclass(frozen=True, slots=True)
class MarketSearch:
    """Completed market search with quotes.

    Experimental: the orchestration API is under active development.
    """

    id: str
    machine_id: str
    request_payload: Mapping[str, Any]
    normalized_task: NormalizedTask
    status: SearchStatus
    quotes: tuple[MarketQuote, ...]
    created_at: str
    agent_pairing_id: str | None = None


@dataclass(frozen=True, slots=True)
class MarketSearchBudget:
    """Optional budget block for :class:`MarketSearchRequest`."""

    max: float | None = None
    amount: float | None = None
    preferred: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True)
class MarketSearchRequest:
    """Request body for initiating a market search.

    Experimental: the orchestration API is under active development.
    """

    machine_id: str | None = None
    agent_pairing_id: str | None = None
    service_type: ServiceType | SearchServiceTypeAlias | None = None
    operation: str | None = None
    required_capabilities: tuple[str, ...] | None = None
    region: str | None = None
    max_results: int | None = None
    allow_external_handoff: bool | None = None
    require_native_execution: bool | None = None
    budget: MarketSearchBudget | None = None
    provider_credentials: ProviderCredentials | None = None


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class MarketSearchConversationRequest:
    """Planned — ``POST`` /market/search/conversation."""

    machine_id: str
    message: str
    agent_pairing_id: str | None = None
    context: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class MarketSearchConversationResponse:
    """Planned — response for conversational market search."""

    message: str
    requires_more_input: bool
    suggested_search: MarketSearchRequest | None = None
