"""Market order resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, TypeAlias

from .common import (
    ExecutionMode,
    ExternalHandoff,
    IntegrationStatus,
    MarketPaymentRailRecommendation,
    ProviderCredentials,
    ServiceType,
)
from .payment import MarketPayment

MarketOrderStatus = Literal[
    "created",
    "payment_pending",
    "ready",
    "executing",
    "delivered",
    "confirmed",
    "disputed",
    "cancelled",
    "failed",
    "handoff",
]

ExecutionOutcomeStatus = Literal["completed", "failed", "external"]

DisputeStatus = Literal["open", "resolved"]


@dataclass(frozen=True, slots=True)
class MarketOrderBudget:
    """Optional spend hint stored on a :class:`MarketOrder`."""

    amount: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True)
class CreateMarketOrderBudget:
    """Optional budget block for :class:`CreateMarketOrderRequest`."""

    amount: float | None = None
    max: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True)
class MarketOrder:
    """Market order to consume a listed service.

    Experimental: the orchestration API is under active development.
    """

    id: str
    machine_id: str
    agent_pairing_id: str
    service_id: str
    skill_key: str
    provider_key: str
    service_type: ServiceType
    operation: str
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    status: MarketOrderStatus
    input_payload: Mapping[str, Any]
    payment: MarketPaymentRailRecommendation
    created_at: str
    updated_at: str
    search_id: str | None = None
    quote_id: str | None = None
    budget: MarketOrderBudget | None = None
    handoff: ExternalHandoff | None = None
    error_message: str | None = None


@dataclass(frozen=True, slots=True)
class CreateMarketOrderRequest:
    """Request body for creating a new market order.

    Experimental: the orchestration API is under active development.
    """

    machine_id: str
    agent_pairing_id: str
    service_id: str
    search_id: str | None = None
    quote_id: str | None = None
    operation: str | None = None
    input_payload: Mapping[str, Any] | None = None
    budget: CreateMarketOrderBudget | None = None
    provider_credentials: ProviderCredentials | None = None


@dataclass(frozen=True, slots=True)
class ExecuteMarketOrderRequest:
    """Request body for executing a market order.

    Experimental: the orchestration API is under active development.
    """

    input: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class ExecutionRoute:
    """Execution route segment returned with an execution response."""

    id: str
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    status: str
    handoff: ExternalHandoff | None = None


@dataclass(frozen=True, slots=True)
class ExecutionOutcome:
    """Execution outcome segment returned with an execution response."""

    id: str
    status: ExecutionOutcomeStatus
    skill_key: str
    service_id: str
    execution_mode: ExecutionMode
    result: Any | None = None
    error_message: str | None = None
    external_ref: str | None = None


@dataclass(frozen=True, slots=True)
class ExecutionRun:
    """Execution run segment returned with an execution response."""

    id: str
    status: ExecutionOutcomeStatus
    execution_mode: ExecutionMode | None = None
    skill_key: str | None = None
    service_id: str | None = None
    outcome_id: str | None = None


@dataclass(frozen=True, slots=True)
class NativeExecutionBody:
    """Native execution (HTTP 200): completed ``run`` and ``outcome``."""

    status_code: Literal[200]
    run: ExecutionRun
    outcome: ExecutionOutcome


@dataclass(frozen=True, slots=True)
class HandoffExecutionBody:
    """External handoff (HTTP 202): ``handoff`` with ``label`` and ``url``."""

    status_code: Literal[202]
    handoff: ExternalHandoff


@dataclass(frozen=True, slots=True)
class NativeExecutionResponse:
    """Native execution response returned with HTTP 200."""

    order: MarketOrder
    execution: NativeExecutionBody


@dataclass(frozen=True, slots=True)
class HandoffExecutionResponse:
    """External handoff response returned with HTTP 202."""

    order: MarketOrder
    execution: HandoffExecutionBody


ExecuteMarketOrderResponse: TypeAlias = NativeExecutionResponse | HandoffExecutionResponse
"""Response body for executing a market order.

Discriminated union on ``execution.status_code``:

- **200 (native):** ``{ order, execution: { status_code, run, outcome } }``
- **202 (handoff):** ``{ order, execution: { status_code, handoff } }``
"""


@dataclass(frozen=True, slots=True)
class OrderDispute:
    """Dispute record returned with dispute responses."""

    id: str
    order_id: str
    machine_id: str
    status: DisputeStatus
    reason: str
    evidence: Mapping[str, Any]
    created_at: str
    updated_at: str


@dataclass(frozen=True, slots=True)
class ConfirmMarketOrderResponse:
    """Response body for confirming a market order.

    Experimental: the orchestration API is under active development.
    """

    order: MarketOrder
    payment: MarketPayment | None


@dataclass(frozen=True, slots=True)
class DisputeMarketOrderRequest:
    """Request body for disputing a market order.

    Experimental: the orchestration API is under active development.
    """

    reason: str
    evidence: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class DisputeMarketOrderResponse:
    """Response body for disputing a market order.

    Experimental: the orchestration API is under active development.
    """

    order: MarketOrder
    payment: MarketPayment | None
    dispute: OrderDispute


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class CancelMarketOrderRequest:
    """Planned — ``POST`` /market/orders/:orderId/cancel."""

    reason: str | None = None


@dataclass(frozen=True, slots=True)
class RetryMarketOrderRequest:
    """Planned — ``POST`` /market/orders/:orderId/retry."""

    reason: str | None = None


@dataclass(frozen=True, slots=True)
class MarketOrderEvent:
    """Planned — ``GET`` /market/orders/:orderId/events item."""

    id: str
    order_id: str
    type: str
    payload: Mapping[str, Any]
    created_at: str
