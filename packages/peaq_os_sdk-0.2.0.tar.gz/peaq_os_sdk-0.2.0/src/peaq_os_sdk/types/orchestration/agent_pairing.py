"""Agent pairing resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Literal

# Lifecycle status of an agent pairing (experimental API).
AgentPairingStatus = Literal["active", "paused", "revoked"]

# Verification method used for agent pairing signatures (experimental API).
AgentPairingVerificationMethod = Literal["eip191"]


@dataclass(frozen=True, slots=True)
class AgentPairingVerification:
    """EIP-191 verification metadata for a paired agent.

    Experimental: the orchestration API is under active development.
    """

    method: AgentPairingVerificationMethod
    signer_address: str
    verified_at: str
    challenge_expires_at: str


@dataclass(frozen=True, slots=True)
class AgentProofInput:
    """Signed challenge submitted by an agent to create or refresh a pairing.

    Experimental: the orchestration API is under active development.
    """

    challenge_id: str
    signature: str


@dataclass(frozen=True, slots=True)
class DelegationPolicy:
    """Spending and access constraints for an agent pairing.

    Experimental: the orchestration API is under active development.
    """

    allowed_skill_keys: tuple[str, ...]
    denied_skill_keys: tuple[str, ...]
    allowed_service_ids: tuple[str, ...]
    denied_service_ids: tuple[str, ...]
    per_transaction_limit: float | None = None
    daily_spend_limit: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True, repr=False)
class AgentPairing:
    """Pairing between a machine and a third-party agent.

    Experimental: the orchestration API is under active development.

    Attributes:
        pairing_token: Returned only once from :func:`create_agent_pairing`;
            store securely — it cannot be fetched again. Omitted on list/get
            responses. Redacted from :meth:`!__repr__` when set.
    """

    id: str
    machine_id: str
    agent_address: str
    agent_provider: str
    agent_role: str
    status: AgentPairingStatus
    has_auth_token: bool
    delegation_policy: DelegationPolicy
    created_at: str
    updated_at: str
    description: str | None = None
    token_last_four: str | None = None
    pairing_token: str | None = None
    agent_did: str | None = None
    verification: AgentPairingVerification | None = None
    session_id: str | None = None
    session_token_id: str | None = None
    session_issued_at: str | None = None
    session_expires_at: str | None = None

    def __repr__(self) -> str:
        parts: list[str] = []
        for f in fields(self):
            val = getattr(self, f.name)
            if f.name == "pairing_token" and val is not None:
                val = "[REDACTED]"
            parts.append(f"{f.name}={val!r}")
        return f"{type(self).__name__}({', '.join(parts)})"


@dataclass(frozen=True, slots=True)
class CreateAgentPairingRequest:
    """Request body for creating a new agent pairing.

    ``agent_proof`` is required: it carries the signed challenge that proves
    the agent controls ``agent_address``. Obtain a challenge first via
    ``create_agent_pairing_challenge``.

    Experimental: the orchestration API is under active development.
    """

    agent_address: str
    agent_provider: str
    agent_role: str
    agent_proof: AgentProofInput
    agent_did: str | None = None
    description: str | None = None
    delegation_policy: DelegationPolicy | None = None


@dataclass(frozen=True, slots=True)
class CreateAgentPairingChallengeRequest:
    """Request body for ``POST .../agent-pairings/challenges``."""

    agent_address: str
    agent_provider: str
    agent_role: str
    agent_did: str | None = None


@dataclass(frozen=True, slots=True)
class AgentPairingChallengeResponse:
    """Challenge returned for an agent pairing signature flow."""

    challenge_id: str
    agent_address: str
    message: str
    expires_at: str
    verification_method: AgentPairingVerificationMethod
    machine_id: str | None = None
    machine_identity_ref: str | None = None
    agent_did: str | None = None


@dataclass(frozen=True, slots=True)
class CreateAgentPairingSessionRequest:
    """Request body for ``POST .../agent-pairings/:pairingId/sessions``.

    Used to issue a fresh ``pairing_token`` for an existing active pairing
    after the agent signs a new challenge.

    Experimental: the orchestration API is under active development.
    """

    agent_proof: AgentProofInput


@dataclass(frozen=True, slots=True)
class UpdateAgentPairingRequest:
    """Request body for updating an existing agent pairing.

    Experimental: the orchestration API is under active development.
    """

    agent_provider: str | None = None
    agent_role: str | None = None
    description: str | None = None
    status: AgentPairingStatus | None = None
    delegation_policy: DelegationPolicy | None = None


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class AgentPairingSignatureProofRequest:
    """Planned — ``POST`` …/agent-pairings/:pairingId/signature-proof.

    Experimental: the orchestration API is under active development.
    """

    message: str
    signature: str
    signer_address: str


@dataclass(frozen=True, slots=True)
class AgentPairingSignatureProofResponse:
    """Planned — response for signature-proof submission.

    Experimental: the orchestration API is under active development.
    """

    pairing_id: str
    verified: bool
    verified_at: str


@dataclass(frozen=True, slots=True)
class AgentPairingSpendResponse:
    """Planned — ``GET`` …/agent-pairings/:pairingId/spend item.

    Experimental: the orchestration API is under active development.
    """

    pairing_id: str
    currency: str | None
    daily_spend: float
    daily_limit: float | None
    per_transaction_limit: float | None
    window_started_at: str
    window_ends_at: str
