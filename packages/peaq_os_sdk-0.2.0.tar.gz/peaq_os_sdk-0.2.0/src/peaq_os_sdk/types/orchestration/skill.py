"""Skills resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from .common import (
    ExecutionMode,
    ExternalHandoff,
    IntegrationStatus,
    ServiceType,
)

SkillDirection = Literal["machine-offers", "machine-consumes"]

SkillScope = Literal["core-product", "bootstrap-reference", "ecosystem"]

SkillSource = Literal["peaq", "partner", "clawhub", "external-marketplace"]

SkillKind = Literal["runtime", "reference"]

SkillAuthState = Literal[
    "unconfigured",
    "configured",
    "expired",
    "invalid",
    "restricted",
]

# Extends EndpointAuthType with wallet/local (see common module).
SkillAuthType = Literal["none", "api-key", "bearer", "wallet", "local"]

SkillAccessMode = Literal[
    "public",
    "credentialed",
    "partner-approved",
    "whitelisted",
    "local",
]

SkillDistribution = Literal[
    "peaq-native",
    "clawhub",
    "openapi",
    "mcp",
    "docs-only",
]

SkillMaturity = Literal["reference", "beta", "production"]


@dataclass(frozen=True, slots=True)
class SkillSummary:
    """Summary of a skill exposed by the orchestration service.

    Experimental: the orchestration API is under active development.
    """

    key: str
    provider_key: str
    label: str
    description: str
    direction: SkillDirection
    scope: SkillScope
    source: SkillSource
    listed_by: str
    last_verified_at: str | None
    kind: SkillKind
    service_types: tuple[ServiceType, ...]
    operations: tuple[str, ...]
    auth_type: SkillAuthType
    auth_state: SkillAuthState
    access_mode: SkillAccessMode
    distribution: SkillDistribution
    maturity: SkillMaturity
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    required_env: tuple[str, ...]
    requires_human_enablement: bool
    reference_url: str | None = None
    artifact_url: str | None = None
    handoff: ExternalHandoff | None = None


Skill = SkillSummary


@dataclass(frozen=True, slots=True)
class SkillManifestInput:
    """Single input descriptor in a skill manifest.

    Experimental: the orchestration API is under active development.
    """

    key: str
    type: str
    required: bool
    description: str


@dataclass(frozen=True, slots=True)
class SkillManifestOutput:
    """Single output descriptor in a skill manifest.

    Experimental: the orchestration API is under active development.
    """

    key: str
    type: str
    description: str


@dataclass(frozen=True, slots=True)
class SkillManifest:
    """Full manifest describing a skill's inputs and outputs.

    Experimental: the orchestration API is under active development.
    """

    key: str
    provider_key: str
    label: str
    summary: str
    inputs: tuple[SkillManifestInput, ...]
    outputs: tuple[SkillManifestOutput, ...]


@dataclass(frozen=True, slots=True)
class UpdateSkillConfigRequest:
    """Request body for updating a skill's machine configuration.

    Experimental: the orchestration API is under active development.

    Note:
        ``credentials`` values are secrets; never log them.
    """

    enabled: bool | None = None
    credentials: Mapping[str, str] | None = None
    settings: Mapping[str, str | int | float | bool] | None = None


@dataclass(frozen=True, slots=True)
class SkillConfigResponse:
    """Response body for a skill's configuration.

    Experimental: the orchestration API is under active development.
    """

    skill_key: str
    provider_key: str
    enabled: bool
    settings: Mapping[str, str | int | float | bool]
    has_credentials: bool
    updated_at: str


# Planned — not yet exported or implemented.
SkillSubmissionStatus = Literal["submitted", "in_review", "approved", "rejected"]


@dataclass(frozen=True, slots=True)
class CreateSkillSubmissionRequest:
    """Planned — ``POST`` /skills/submissions."""

    provider_name: str
    skill_name: str
    description: str
    service_types: tuple[ServiceType, ...]
    operations: tuple[str, ...]
    reference_url: str | None = None
    metadata: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class CreateSkillSubmissionResponse:
    """Planned — response for skill submission creation."""

    id: str
    status: SkillSubmissionStatus
    created_at: str


@dataclass(frozen=True, slots=True)
class GetSkillSubmissionResponse:
    """Planned — ``GET`` /skills/submissions/:submissionId response."""

    id: str
    status: SkillSubmissionStatus
    created_at: str
    updated_at: str
    notes: str | None = None
