"""Machine-side runtime agent types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, TypeAlias

from .common import (
    EndpointAuthType,
    EndpointHealthStatus,
    EndpointNetworkScope,
    ItemResponse,
)

MachineAgentStatus = Literal["provisioned", "active", "revoked"]


@dataclass(frozen=True, slots=True)
class MachineAgent:
    """Machine-side runtime agent (e.g. QVAC) registered with orchestration.

    Experimental: the orchestration API is under active development.

    Attributes:
        provisioning_token: Present only on enrollment responses; one-time
            secret — store securely, never log.
    """

    id: str
    machine_id: str
    label: str
    allowed_provider_keys: tuple[str, ...]
    status: MachineAgentStatus
    created_at: str
    updated_at: str
    last_seen_at: str | None = None
    provisioning_token: str | None = None


@dataclass(frozen=True, slots=True)
class EnrollMachineAgentRequest:
    """Request body for enrolling a machine-side runtime agent.

    Experimental: the orchestration API is under active development.
    """

    label: str | None = None
    allowed_provider_keys: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class HeartbeatEndpointEntry:
    """Single endpoint entry in a machine agent heartbeat request.

    Experimental: the orchestration API is under active development.

    Note:
        ``auth_token`` is a secret; treat like any other credential in logs
        and error reporting.
    """

    provider_key: Literal["qvac"]
    endpoint_base_url: str
    label: str | None = None
    auth_type: EndpointAuthType | None = None
    auth_token: str | None = None
    model_alias: str | None = None
    network_scope: EndpointNetworkScope | None = None
    probe_path: str | None = None


@dataclass(frozen=True, slots=True)
class MachineAgentHeartbeatRequest:
    """Request body for ``POST`` …/machine-agents/heartbeat.

    Experimental: the orchestration API is under active development.

    Note:
        ``agent_token`` is a secret; never log or echo it.
    """

    machine_id: str
    agent_id: str
    agent_token: str
    endpoints: tuple[HeartbeatEndpointEntry, ...]
    lease_ttl_seconds: int | None = None


@dataclass(frozen=True, slots=True)
class HeartbeatEndpointResult:
    """Single endpoint outcome in a heartbeat response.

    Experimental: the orchestration API is under active development.
    """

    provider_key: str
    endpoint_base_url: str
    status: EndpointHealthStatus
    lease_expires_at: str
    health_error: str | None


@dataclass(frozen=True, slots=True)
class MachineAgentHeartbeatPayload:
    """Inner payload of the machine agent heartbeat response.

    Experimental: the orchestration API is under active development.
    """

    machine_id: str
    agent_id: str
    lease_ttl_seconds: int
    observed_at: str
    endpoints: tuple[HeartbeatEndpointResult, ...]


MachineAgentHeartbeatResponse: TypeAlias = ItemResponse[MachineAgentHeartbeatPayload]


# Planned — not yet exported or implemented.
@dataclass(frozen=True, slots=True)
class RotateMachineAgentTokenRequest:
    """Planned — ``POST`` /machine-agents/:agentId/rotate-token."""

    reason: str | None = None


@dataclass(frozen=True, slots=True)
class RotateMachineAgentTokenResponse:
    """Planned — response for agent token rotation.

    Note:
        ``provisioning_token`` is a secret; callers must store it securely.
    """

    agent_id: str
    provisioning_token: str
    rotated_at: str


@dataclass(frozen=True, slots=True)
class MachineAgentEvent:
    """Planned — ``GET`` /machine-agents/:agentId/events item."""

    id: str
    agent_id: str
    type: str
    payload: Mapping[str, Any]
    created_at: str
