"""Types for the Machines resource domain.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal

MachineOrchestrationStatus = Literal["draft", "active", "degraded", "blocked", "archived"]

MachineIdentityVerificationMethod = Literal["eip191"]
MachineIdentityResolutionSource = Literal["peaqos-mcr"]


@dataclass(frozen=True, slots=True)
class MachineIdentityProof:
    """Verified identity proof attached to a machine record.

    Experimental: the orchestration API is under active development.
    """

    method: MachineIdentityVerificationMethod
    identity_ref: str
    signer_address: str
    challenge_id: str
    verified_at: str
    challenge_expires_at: str
    controller_addresses: tuple[str, ...]
    resolution_source: MachineIdentityResolutionSource


@dataclass(frozen=True, slots=True)
class MachineIdentityProofInput:
    """Identity proof submitted when creating a machine.

    Experimental: the orchestration API is under active development.
    """

    challenge_id: str
    signature: str


@dataclass(frozen=True, slots=True)
class CreateMachineIdentityChallengeRequest:
    """Request body for ``POST /machine-identity/challenges``.

    Experimental: the orchestration API is under active development.
    """

    identity_ref: str


@dataclass(frozen=True, slots=True)
class MachineIdentityChallengeResponse:
    """Challenge returned for machine identity verification.

    Experimental: the orchestration API is under active development.
    """

    challenge_id: str
    identity_ref: str
    message: str
    expires_at: str
    verification_method: MachineIdentityVerificationMethod
    controller_addresses: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Machine:
    """A machine registered with the orchestration service.

    Experimental: the orchestration API is under active development.
    """

    id: str
    display_name: str
    status: MachineOrchestrationStatus
    owner_id: str
    machine_type: str
    runtime_profile: str
    capabilities: tuple[str, ...]
    labels: Mapping[str, str]
    policy_ids: tuple[str, ...]
    skill_keys: tuple[str, ...]
    created_at: str
    updated_at: str
    identity_ref: str | None = None
    identity_proof: MachineIdentityProof | None = None


@dataclass(frozen=True, slots=True)
class CreateMachineRequest:
    """Request body for creating a new machine.

    Experimental: the orchestration API is under active development.
    """

    display_name: str
    owner_id: str
    machine_type: str
    runtime_profile: str
    identity_ref: str | None = None
    identity_proof: MachineIdentityProofInput | None = None
    capabilities: tuple[str, ...] | None = None
    labels: Mapping[str, str] | None = None
    policy_ids: tuple[str, ...] | None = None
    skill_keys: tuple[str, ...] | None = None


@dataclass(frozen=True, slots=True)
class UpdateMachineRequest:
    """Request body for updating a machine (partial update).

    Experimental: the orchestration API is under active development.
    """

    display_name: str | None = None
    status: MachineOrchestrationStatus | None = None
    owner_id: str | None = None
    identity_ref: str | None = None
    machine_type: str | None = None
    runtime_profile: str | None = None
    capabilities: tuple[str, ...] | None = None
    labels: Mapping[str, str] | None = None
    policy_ids: tuple[str, ...] | None = None
    skill_keys: tuple[str, ...] | None = None


# Planned — not yet exported or implemented.
MachineBondStatus = Literal["unbonded", "bonded", "unknown"]

MachineTrustStatus = Literal["unverified", "verified", "revoked"]


@dataclass(frozen=True, slots=True)
class CreateOwnershipChallengeRequest:
    """Planned — ``POST`` /machines/:machineId/ownership-challenge."""

    owner_address: str
    machine_address: str | None = None


@dataclass(frozen=True, slots=True)
class CreateOwnershipChallengeResponse:
    """Planned — response for ownership challenge creation."""

    challenge_id: str
    machine_id: str
    message: str
    expires_at: str


@dataclass(frozen=True, slots=True)
class VerifyOwnershipProofRequest:
    """Planned — ``POST`` /machines/:machineId/ownership-proof."""

    challenge_id: str
    signature: str
    signer_address: str


@dataclass(frozen=True, slots=True)
class VerifyOwnershipProofResponse:
    """Planned — response for ownership proof verification."""

    machine_id: str
    verified: bool
    verified_at: str


@dataclass(frozen=True, slots=True)
class MachineTrustMcr:
    """Planned — MCR subsection of machine trust response."""

    score: float
    rating: str
    calculated_at: str


@dataclass(frozen=True, slots=True)
class MachineTrustDetail:
    """Planned — trust subsection of machine trust response."""

    status: MachineTrustStatus
    attested_at: str | None = None
    attestor: str | None = None


@dataclass(frozen=True, slots=True)
class GetMachineTrustResponse:
    """Planned — ``GET`` /machines/:machineId/trust response."""

    machine_id: str
    bond_status: MachineBondStatus
    mcr: MachineTrustMcr | None = None
    trust: MachineTrustDetail | None = None
