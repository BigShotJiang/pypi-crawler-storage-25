"""Payment settlement types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from .common import MarketPaymentRailType

MarketPaymentStatus = Literal[
    "not_required",
    "intent_created",
    "held",
    "release_pending",
    "released",
    "frozen",
    "refunded",
]


@dataclass(frozen=True, slots=True)
class PaymentRailDetails:
    """Payment rail details on a payment record.

    Experimental: the orchestration API is under active development.
    """

    rail_type: MarketPaymentRailType
    chain: str | None = None
    token: str | None = None
    token_address: str | None = None
    token_mint: str | None = None
    escrow_address: str | None = None
    external_url: str | None = None
    provider: str | None = None
    account_id: str | None = None
    wallet_address: str | None = None
    payer_address: str | None = None
    payee_address: str | None = None
    payment_intent_id: str | None = None
    metadata: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class MarketPayment:
    """Payment record associated with a market order.

    Experimental: the orchestration API is under active development.
    """

    id: str
    order_id: str
    machine_id: str
    status: MarketPaymentStatus
    rail: PaymentRailDetails
    notes: tuple[str, ...]
    created_at: str
    updated_at: str
    amount: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True)
class PaymentIntentRailOptions:
    """Optional rail hints for :class:`CreatePaymentIntentRequest`.

    Experimental: the orchestration API is under active development.

    Attributes:
        rail_type: Maps to the API nested field ``type``.
    """

    type: MarketPaymentRailType | None = None
    chain: str | None = None
    token: str | None = None
    token_address: str | None = None
    token_mint: str | None = None
    escrow_address: str | None = None
    external_url: str | None = None
    provider: str | None = None
    account_id: str | None = None
    wallet_address: str | None = None
    payer_address: str | None = None
    payee_address: str | None = None
    payment_intent_id: str | None = None
    metadata: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class CreatePaymentIntentRequest:
    """Request body for creating a payment intent.

    Experimental: the orchestration API is under active development.
    """

    rail: PaymentIntentRailOptions | None = None
    amount: float | None = None
    currency: str | None = None


PaymentVerificationMode = Literal["recorded", "rpc"]


@dataclass(frozen=True, slots=True)
class SubmitPaymentProofRequest:
    """Request body for submitting a payment proof after a payment intent.

    Supports EVM proofs (``transaction_hash``) and Solana proofs
    (``transaction_signature``) with ``verification_mode`` ``"recorded"`` or
    ``"rpc"``.
    """

    verification_mode: PaymentVerificationMode
    chain: str
    token: str
    payer_address: str
    payee_address: str
    amount: str
    transaction_hash: str | None = None
    transaction_signature: str | None = None
    token_address: str | None = None
    token_mint: str | None = None
    token_decimals: int | None = None
    raw_amount: str | None = None
    metadata: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class LockEscrowPaymentRequest:
    """Request body for locking funds in escrow.

    Experimental: the orchestration API is under active development.
    """

    transaction_hash: str
    chain: str
    escrow_address: str


@dataclass(frozen=True, slots=True)
class ReleasePaymentRequest:
    """Request body for releasing payment to the provider.

    Experimental: the orchestration API is under active development.
    """

    transaction_hash: str | None = None
    notes: str | None = None


@dataclass(frozen=True, slots=True)
class RefundPaymentRequest:
    """Request body for refunding a payment.

    Experimental: the orchestration API is under active development.
    """

    transaction_hash: str | None = None
    reason: str | None = None
