"""Policy resource types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PolicyBudgetCap:
    """Currency and amount cap for a :class:`Policy`."""

    currency: str
    amount: float


@dataclass(frozen=True, slots=True)
class Policy:
    """Policy governing machine behaviour in the orchestration system.

    Experimental: the orchestration API is under active development.
    """

    id: str
    name: str
    allowed_skill_keys: tuple[str, ...]
    denied_skill_keys: tuple[str, ...]
    region_rules: tuple[str, ...]
    native_only: bool
    handoff_allowed: bool
    required_capabilities: tuple[str, ...]
    created_at: str
    updated_at: str
    budget_cap: PolicyBudgetCap | None = None


@dataclass(frozen=True, slots=True)
class CreatePolicyRequest:
    """Request body for creating a new policy.

    Experimental: the orchestration API is under active development.
    """

    name: str
    allowed_skill_keys: tuple[str, ...] | None = None
    denied_skill_keys: tuple[str, ...] | None = None
    budget_cap: PolicyBudgetCap | None = None
    region_rules: tuple[str, ...] | None = None
    native_only: bool | None = None
    handoff_allowed: bool | None = None
    required_capabilities: tuple[str, ...] | None = None
