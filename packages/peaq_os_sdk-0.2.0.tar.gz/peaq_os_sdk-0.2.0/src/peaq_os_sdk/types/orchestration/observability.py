"""Events and observability types for the orchestration API.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, TypeAlias

ReadinessStatus = Literal["ready", "not_ready"]

ReadinessCheckStatus = Literal["pass", "fail"]


@dataclass(frozen=True, slots=True)
class ReadinessCheck:
    """Single readiness probe result.

    Experimental: the orchestration API is under active development.
    """

    name: str
    status: ReadinessCheckStatus
    message: str | None = None


@dataclass(frozen=True, slots=True)
class AuditEvent:
    """Audit event recorded by the orchestration service.

    Experimental: the orchestration API is under active development.
    """

    id: str
    actor: str
    type: str
    resource_type: str
    resource_id: str
    payload: Mapping[str, Any]
    created_at: str


@dataclass(frozen=True, slots=True)
class ReadinessResponse:
    """Response body for the readiness check endpoint.

    Experimental: the orchestration API is under active development.
    """

    status: ReadinessStatus
    checks: tuple[ReadinessCheck, ...]


@dataclass(frozen=True, slots=True)
class HealthResponse:
    """Response body for the health check endpoint.

    Experimental: the orchestration API is under active development.
    """

    ok: Literal[True] = True


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class StreamEventsRequest:
    """Planned — ``GET`` /events (SSE stream) query parameters."""

    machine_id: str | None = None
    cursor: str | None = None


GetMetricsResponse: TypeAlias = str
"""Planned — ``GET`` /metrics body (Prometheus text format)."""
