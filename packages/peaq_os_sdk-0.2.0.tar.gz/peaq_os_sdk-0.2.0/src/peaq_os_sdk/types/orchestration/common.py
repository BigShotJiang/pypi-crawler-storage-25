"""Common types shared across all orchestration API resource domains.
Derived from the Machine Markets API spec.

Experimental: the Machine Markets orchestration API is under active
development; field names, envelopes, and allowed enum values may change
without notice.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Literal, TypeVar

T = TypeVar("T")

LIST_QUERY_DEFAULT_LIMIT = 100
LIST_QUERY_MAX_LIMIT = 500


@dataclass(frozen=True, slots=True)
class ListQuery:
    """Pagination query parameters for orchestration list endpoints.

    Pass as query params on the wire (``limit``, ``cursor``). When ``limit`` is
    omitted, the server defaults to :data:`LIST_QUERY_DEFAULT_LIMIT`. The SDK
    rejects ``limit`` outside ``1``..:data:`LIST_QUERY_MAX_LIMIT` before any
    HTTP call.

    Cursor values are opaque — do not parse, modify, or persist them. Omit
    ``cursor`` on the first page.

    Attributes:
        limit: Page size (server default ``100``, maximum ``500``).
        cursor: Opaque cursor from a previous response's ``next_cursor``.
    """

    limit: int | None = None
    cursor: str | None = None


@dataclass(frozen=True, slots=True)
class ListResponse(Generic[T]):
    """Paginated list envelope returned by list endpoints.

    Experimental: the orchestration API is under active development.

    Attributes:
        items: Current page of resources (immutable tuple).
        next_cursor: Opaque cursor for the next page, or ``None`` when
            there are no further results. Pass to :class:`ListQuery` as
            ``cursor`` to fetch the next page.
    """

    items: tuple[T, ...]
    next_cursor: str | None = None


@dataclass(frozen=True, slots=True)
class ItemResponse(Generic[T]):
    """Single-item envelope returned by get/create/update endpoints.

    Experimental: the orchestration API is under active development.

    Attributes:
        item: The wrapped resource payload.
    """

    item: T


CommonErrorCode = Literal[
    "AUTH_REQUIRED",
    "AUTH_INVALID",
    "AGENT_AUTH_REQUIRED",
    "AGENT_AUTH_INVALID",
    "AGENT_AUTH_EXPIRED",
    "VALIDATION_ERROR",
    "NOT_FOUND",
    "MACHINE_NOT_ACTIVE",
    "MACHINE_NOT_ACTIVATED",
    "MACHINE_IDENTITY_EXISTS",
    "MACHINE_IDENTITY_IMMUTABLE",
    "MACHINE_IDENTITY_PROOF_REQUIRED",
    "MACHINE_IDENTITY_PROOF_INVALID",
    "MACHINE_IDENTITY_PROOF_EXPIRED",
    "PEAQOS_IDENTITY_UNAVAILABLE",
    "AGENT_PAIRING_PROOF_REQUIRED",
    "AGENT_PAIRING_PROOF_INVALID",
    "AGENT_PAIRING_PROOF_EXPIRED",
    "AGENT_PAIRING_UNAVAILABLE",
    "AGENT_PAIRING_REQUIRED",
    "AGENT_PAIRING_INACTIVE",
    "AGENT_POLICY_DENIED",
    "AGENT_SPEND_LIMIT_EXCEEDED",
    "AGENT_DAILY_LIMIT_EXCEEDED",
    "QUOTE_EXPIRED",
    "ORDER_CLOSED",
    "ORDER_NOT_DELIVERED",
    "EXECUTION_UNSUPPORTED",
    "PAYMENT_REQUIRED",
    "PAYMENT_RPC_REQUIRED",
    "PAYMENT_RPC_ERROR",
    "PAYMENT_NOT_MINED",
    "PAYMENT_TX_FAILED",
    "PAYMENT_TRANSFER_NOT_FOUND",
]

ExecutionMode = Literal["native", "external-handoff"]

IntegrationStatus = Literal[
    "native",
    "credentials-required",
    "partner-required",
    "local-config-required",
    "setup-required",
    "docs-only",
]

ServiceType = Literal[
    "oracle.price-feed",
    "compute.marketplace",
    "storage.object",
    "data.location",
    "network.partner-console",
    "identity.proof-of-person",
    "device.control",
    "machine.commerce",
]


@dataclass(frozen=True, slots=True)
class ExternalHandoff:
    """Describes an external handoff target when a service cannot be
    executed natively by the machine runtime.

    Experimental: the orchestration API is under active development.

    Attributes:
        label: Human-readable name for the external destination.
        url: URL the caller should direct the user or agent to.
        notes: Optional clarifying notes about the handoff.
    """

    label: str
    url: str
    notes: tuple[str, ...]


MarketPaymentRailType = Literal[
    "not-required",
    "wallet",
    "xvv42",
    "x402",
    "vault-stripe",
    "escrow",
    "offchain-record",
    "external",
    "onchain-escrow",
    "wdk-usdt-transfer",
]


@dataclass(frozen=True, slots=True)
class MarketPaymentRailRecommendation:
    """Payment rail recommendation returned with market quotes and orders.

    Describes which payment methods are available for a given service
    and which the provider recommends.

    Experimental: the orchestration API is under active development.

    Attributes:
        default_rail: The provider's recommended payment rail.
        supported_rails: All rails accepted for this service.
        required: Whether payment is required to execute the order.
        provider: Payment provider identifier, if applicable.
        chain: Blockchain network identifier, if applicable.
        token: Token contract address or symbol, if applicable.
        token_address: EVM token contract address (e.g., USDT/USDC), if applicable.
        token_mint: Solana SPL token mint address, if applicable.
        wallet_address: Provider wallet address for payment, if applicable.
        external_url: URL for out-of-band payment flow, if applicable.
        payer_address: Address expected to send payment, if applicable.
        payee_address: Address expected to receive payment, if applicable.
        notes: Additional context about payment requirements.
    """

    default_rail: MarketPaymentRailType
    supported_rails: tuple[MarketPaymentRailType, ...]
    required: bool
    notes: tuple[str, ...]
    provider: str | None = None
    chain: str | None = None
    token: str | None = None
    token_address: str | None = None
    token_mint: str | None = None
    wallet_address: str | None = None
    external_url: str | None = None
    payer_address: str | None = None
    payee_address: str | None = None


@dataclass(frozen=True, slots=True)
class WalrusCredentials:
    """Walrus storage provider credentials."""

    publisher_url: str | None = None
    aggregator_url: str | None = None
    publisher_token: str | None = None


@dataclass(frozen=True, slots=True)
class AkashCredentials:
    """Akash compute provider credentials."""

    console_api_key: str | None = None
    console_base_url: str | None = None
    rest_endpoints: str | None = None


@dataclass(frozen=True, slots=True)
class WorldIdCredentials:
    """World ID proof-of-person provider credentials."""

    rp_id: str | None = None
    app_id: str | None = None
    verify_base_url: str | None = None


@dataclass(frozen=True, slots=True)
class GeodnetCredentials:
    """Geodnet location provider credentials."""

    app_id: str | None = None
    app_key: str | None = None
    base_url: str | None = None


@dataclass(frozen=True, slots=True)
class AethirCredentials:
    """Aethir GPU compute provider credentials."""

    ak: str | None = None
    sk: str | None = None
    base_url: str | None = None


@dataclass(frozen=True, slots=True)
class ProviderCredentials:
    """Credentials for external service providers, passed with market search requests.

    Lets the orchestration service authenticate on behalf of the caller when
    the platform cannot supply provider credentials itself.

    Experimental: the orchestration API is under active development.

    Attributes:
        walrus: Walrus storage credentials.
        akash: Akash compute credentials.
        world_id: World ID proof-of-person credentials (wire: ``worldId``).
        geodnet: Geodnet location credentials.
        aethir: Aethir GPU compute credentials.
    """

    walrus: WalrusCredentials | None = None
    akash: AkashCredentials | None = None
    world_id: WorldIdCredentials | None = None
    geodnet: GeodnetCredentials | None = None
    aethir: AethirCredentials | None = None


EndpointAuthType = Literal["none", "api-key", "bearer"]

EndpointNetworkScope = Literal["loopback", "lan", "vpn", "public"]

EndpointHealthStatus = Literal["active", "degraded", "unreachable"]

__all__ = [
    "LIST_QUERY_DEFAULT_LIMIT",
    "LIST_QUERY_MAX_LIMIT",
    "AethirCredentials",
    "AkashCredentials",
    "CommonErrorCode",
    "EndpointAuthType",
    "EndpointHealthStatus",
    "EndpointNetworkScope",
    "ExecutionMode",
    "ExternalHandoff",
    "GeodnetCredentials",
    "IntegrationStatus",
    "ItemResponse",
    "ListQuery",
    "ListResponse",
    "MarketPaymentRailRecommendation",
    "MarketPaymentRailType",
    "ProviderCredentials",
    "ServiceType",
    "WalrusCredentials",
    "WorldIdCredentials",
]
