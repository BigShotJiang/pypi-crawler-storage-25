"""Types for the Market Services resource domain.

Experimental: the Machine Markets orchestration API is under active
development; field names and shapes may change without notice.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

from .common import (
    ExecutionMode,
    ExternalHandoff,
    IntegrationStatus,
    MarketPaymentRailRecommendation,
    ServiceType,
)
from .skill import (
    SkillAccessMode,
    SkillAuthType,
    SkillDistribution,
    SkillKind,
    SkillMaturity,
)

PricingMode = Literal["provider-defined", "fixed", "quote-required"]


@dataclass(frozen=True, slots=True)
class QuotePricing:
    """Pricing details attached to a market quote.

    Experimental: the orchestration API is under active development.
    """

    mode: PricingMode
    notes: tuple[str, ...]
    amount: float | None = None
    currency: str | None = None
    rate: str | None = None


@dataclass(frozen=True, slots=True)
class MarketService:
    """A consumable service listed in the market for machines.

    Experimental: the orchestration API is under active development.
    """

    id: str
    skill_key: str
    provider_key: str
    provider_id: str
    provider_label: str
    service_type: ServiceType
    name: str
    description: str
    operations: tuple[str, ...]
    auth_type: SkillAuthType
    access_mode: SkillAccessMode
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    distribution: SkillDistribution
    maturity: SkillMaturity
    kind: SkillKind
    capabilities: tuple[str, ...]
    region: str
    freshness_seconds: int
    requires_human_enablement: bool
    metadata: Mapping[str, Any]
    updated_at: str
    reference_url: str | None = None
    artifact_url: str | None = None
    handoff: ExternalHandoff | None = None


@dataclass(frozen=True, slots=True)
class MarketQuote:
    """Quote for a market service (e.g. from search results).

    Experimental: the orchestration API is under active development.
    """

    id: str
    service_id: str
    skill_key: str
    provider_key: str
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    operation: str
    score: float
    reasons: tuple[str, ...]
    pricing: QuotePricing
    payment: MarketPaymentRailRecommendation
    expires_at: str
    handoff: ExternalHandoff | None = None


# Planned — not yet exported or implemented.


@dataclass(frozen=True, slots=True)
class MarketServiceQuoteBudget:
    """Optional budget hint for a market service quote request."""

    amount: float | None = None
    currency: str | None = None


@dataclass(frozen=True, slots=True)
class CreateMarketServiceQuoteRequest:
    """Planned — ``POST`` /market/services/:serviceId/quote.

    Attributes:
        structured_input: Maps to the API ``input`` object (``input`` is a
            builtin in Python, so this field uses a different name).
    """

    machine_id: str
    agent_pairing_id: str | None = None
    operation: str | None = None
    structured_input: Mapping[str, Any] | None = None
    budget: MarketServiceQuoteBudget | None = None


@dataclass(frozen=True, slots=True)
class GetMarketServiceAvailabilityResponse:
    """Planned — ``GET`` /market/services/:serviceId/availability response."""

    service_id: str
    available: bool
    execution_mode: ExecutionMode
    integration_status: IntegrationStatus
    checked_at: str
    reason: str | None = None
