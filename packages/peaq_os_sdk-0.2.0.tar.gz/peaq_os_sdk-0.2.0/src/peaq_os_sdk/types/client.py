"""Client configuration types."""

from __future__ import annotations

from dataclasses import dataclass

from .primitives import Address


@dataclass(frozen=True, slots=True)
class ContractAddresses:
    """Addresses of all peaqOS protocol contracts.

    Args:
        identity_registry: IdentityRegistry proxy contract address.
        identity_staking: IdentityStaking proxy contract address.
        event_registry: EventRegistry proxy contract address.
        machine_nft: MachineNFT contract address.
        did_registry: peaq DID precompile address (0x...0800).
        batch_precompile: peaq Batch precompile address (0x...0805).
        machine_account_factory: MachineAccountFactory contract address.
            Optional — only required when deploying smart accounts.
        machine_nft_adapter: MachineNFTAdapter contract address on peaq.
            Optional — only required for peaq→Base NFT bridging.

    Example:
        >>> addrs = ContractAddresses(
        ...     identity_registry="0x9075...",
        ...     identity_staking="0x7d39...",
        ...     event_registry="0xEVEN...",
        ...     machine_nft="0xaF13...",
        ...     did_registry="0x0000...0800",
        ...     batch_precompile="0x0000...0805",
        ... )
    """

    identity_registry: Address
    identity_staking: Address
    event_registry: Address
    machine_nft: Address
    did_registry: Address
    batch_precompile: Address
    machine_account_factory: Address | None = None
    machine_nft_adapter: Address | None = None


@dataclass(frozen=True, slots=True)
class OperationalLimits:
    """Per-transaction and rate-limiting caps.

    A value of ``0`` means the limit is disabled.

    Args:
        max_value_per_tx: Maximum USD value per event. 0 = no limit.
        rate_limit_max_events: Maximum events per window. 0 = no limit.
        rate_limit_window_seconds: Sliding window in seconds. 0 = disabled.

    Example:
        >>> limits = OperationalLimits(max_value_per_tx=1000, rate_limit_max_events=60)
    """

    max_value_per_tx: int = 0
    rate_limit_max_events: int = 0
    rate_limit_window_seconds: int = 0
