"""Wallet types for the OWS (Open Wallet Standard) integration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ImportChain = Literal[
    "evm",
    "solana",
    "bitcoin",
    "cosmos",
    "tron",
    "ton",
    "sui",
    "xrpl",
    "spark",
    "filecoin",
]
"""Chain family for private-key import.

Determines which derivation curve and address format OWS uses
when importing a raw key.
"""


@dataclass(frozen=True, slots=True)
class AccountInfo:
    """A single chain account derived from an OWS wallet.

    Args:
        account_id: CAIP-10 account identifier (e.g. ``"eip155:3338:0x..."``).
        address: Native chain-format address string.
        chain_id: CAIP-2 chain identifier (e.g. ``"eip155:3338"``).
        network: Human-readable network name (e.g. ``"peaq"``, ``"ethereum"``, ``"solana"``).
        derivation_path: BIP-44 derivation path (e.g. ``"m/44'/60'/0'/0/0"``).

    Example:
        >>> acct = AccountInfo(
        ...     account_id="eip155:3338:0xAbCd",
        ...     address="0xAbCd",
        ...     chain_id="eip155:3338",
        ...     network="peaq",
        ...     derivation_path="m/44'/60'/0'/0/0",
        ... )
    """

    account_id: str
    address: str
    chain_id: str
    network: str
    derivation_path: str


@dataclass(frozen=True, slots=True)
class WalletInfo:
    """Wallet metadata returned by all OWS wallet operations.

    Args:
        id: UUID v4 wallet identifier.
        name: Human-readable wallet label.
        created_at: ISO 8601 creation timestamp.
        key_type: Key origin — ``"mnemonic"`` or ``"private_key"``.
        peaq_address: Primary peaq EVM address (convenience field).
        accounts: All chain accounts derived from the wallet.

    Example:
        >>> info = WalletInfo(
        ...     id="a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        ...     name="my-machine",
        ...     created_at="2026-04-24T10:00:00Z",
        ...     key_type="mnemonic",
        ...     peaq_address="0xAbCd",
        ...     accounts=[],
        ... )
    """

    id: str
    name: str
    created_at: str
    key_type: str
    peaq_address: str
    accounts: list[AccountInfo]
