"""Rate limit exceeded error."""

from __future__ import annotations

from .base import PeaqosError


class RateLimitExceeded(PeaqosError):
    """Thrown when a machine exceeds the configured event rate limit.

    Args:
        machine_id: The machine that hit the limit.
        count: Current event count within the window.
        max_events: Maximum allowed events per window.
        window_seconds: Rate limit window duration in seconds.

    Example:
        >>> err = RateLimitExceeded(
        ...     machine_id=1, count=61, max_events=60, window_seconds=3600,
        ... )
        >>> err.count
        61
    """

    def __init__(
        self,
        *,
        machine_id: int,
        count: int,
        max_events: int,
        window_seconds: int,
    ) -> None:
        super().__init__(f"Machine {machine_id}: {count}/{max_events} events in {window_seconds}s")
        self.machine_id: int = machine_id
        self.count: int = count
        self.max_events: int = max_events
        self.window_seconds: int = window_seconds
