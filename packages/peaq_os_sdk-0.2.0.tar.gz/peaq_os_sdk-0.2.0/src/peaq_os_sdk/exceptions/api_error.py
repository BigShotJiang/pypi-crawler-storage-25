"""HTTP API error."""

from __future__ import annotations

from .base import PeaqosError


class ApiError(PeaqosError):
    """Raised when an HTTP API call to the faucet or MCR API fails.

    The ``code`` attribute carries the upstream faucet error code
    (e.g. ``"INVALID_2FA"``) or a sentinel like ``"NETWORK_ERROR"``.
    """

    pass
