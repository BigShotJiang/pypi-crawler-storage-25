"""Value cap exceeded error."""

from __future__ import annotations

from .base import PeaqosError


class ValueCapExceeded(PeaqosError):
    """Thrown when a transaction value exceeds the configured per-tx cap.

    Args:
        value: The value that was attempted.
        cap: The maximum allowed value.

    Example:
        >>> err = ValueCapExceeded(value=500, cap=100)
        >>> err.value
        500
    """

    def __init__(self, *, value: int, cap: int) -> None:
        super().__init__(f"Value {value} exceeds cap {cap}")
        self.value: int = value
        self.cap: int = cap
