"""Base exception for the peaqOS SDK."""

from __future__ import annotations


class PeaqosError(RuntimeError):
    """Base error for all peaqOS SDK errors.

    Inherits from the built-in ``RuntimeError`` so callers can catch
    SDK failures with either the typed class hierarchy or the stdlib
    base — ``except RuntimeError`` works, and ``except PeaqosError``
    gives access to the ``code`` attribute.

    Args:
        message: Human-readable error description.
        code: Machine-readable error code for programmatic branching.

    Example:
        >>> try:
        ...     raise PeaqosError("something failed")
        ... except PeaqosError as e:
        ...     print(e)
        something failed
    """

    def __init__(self, message: str, *, code: str = "") -> None:
        super().__init__(message)
        self.code: str = code
