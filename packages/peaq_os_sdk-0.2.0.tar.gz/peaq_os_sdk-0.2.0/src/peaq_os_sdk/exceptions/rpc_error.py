"""RPC / on-chain transaction error."""

from __future__ import annotations

from .base import PeaqosError


class RpcError(PeaqosError):
    """Raised when an on-chain transaction or RPC call fails.

    The ``code`` attribute carries the contract's custom-error name
    (e.g. ``"AlreadyRegistered"``) when the SDK could decode one,
    or a sentinel like ``"TX_REVERTED"`` / ``"RECEIPT_AWAIT_FAILED"``
    for transport-level failures.
    """

    pass
