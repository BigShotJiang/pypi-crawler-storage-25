"""Validation error for input parameter failures."""

from __future__ import annotations

from typing import Any

from .base import PeaqosError


class ValidationError(PeaqosError):
    """Thrown when an input parameter fails validation.

    Args:
        field: The parameter name that failed validation.
        constraint: A human-readable description of the violated rule.
        message: Human-readable error description.
        value: The rejected value.

    Example:
        >>> err = ValidationError(
        ...     field="machine_id",
        ...     constraint="> 0",
        ...     message="machine_id must be positive",
        ...     value=-1,
        ... )
        >>> err.field
        'machine_id'
    """

    def __init__(
        self,
        *,
        field: str,
        constraint: str,
        message: str,
        value: Any,
    ) -> None:
        super().__init__(message)
        self.field: str = field
        self.constraint: str = constraint
        self.value: Any = value
