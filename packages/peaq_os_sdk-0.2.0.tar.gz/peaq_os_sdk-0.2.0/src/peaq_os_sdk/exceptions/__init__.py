"""Exception classes for the peaqOS SDK."""

from __future__ import annotations

from .api_error import ApiError
from .base import PeaqosError
from .rate_limit_exceeded import RateLimitExceeded
from .rpc_error import RpcError
from .validation_error import ValidationError
from .value_cap_exceeded import ValueCapExceeded

__all__: list[str] = [
    "ApiError",
    "PeaqosError",
    "RateLimitExceeded",
    "RpcError",
    "ValidationError",
    "ValueCapExceeded",
]
