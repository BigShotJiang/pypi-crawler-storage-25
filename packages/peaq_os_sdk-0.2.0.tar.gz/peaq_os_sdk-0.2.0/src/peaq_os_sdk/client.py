"""PeaqosClient — single entry-point for the peaqOS Python SDK."""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import asdict
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

import requests
from eth_account import Account
from eth_account.signers.local import LocalAccount
from web3 import Web3
from web3.contract import Contract

from .abis import load_abi
from .constants import DEFAULT_API_URL, IMPORT_CHAIN_EVM
from .exceptions.validation_error import ValidationError
from .orchestration.errors import OrchestrationConfigError
from .orchestration.namespace import OrchestrationNamespace
from .types.client import ContractAddresses, OperationalLimits
from .types.events import _OMITTED_CURRENCY, SubmitEventParams
from .types.primitives import Address, Hex32
from .wallet.ows_signer import OWSAccount, TransactionSigner

if TYPE_CHECKING:
    from .registration.faucet import FaucetSetupResponse
    from .registration.fund_from_gas_station import FaucetFundResponse
    from .types.queries import MachineProfileResponse, MCRResponse, OperatorMachinesResponse
    from .types.wallet import ImportChain, WalletInfo

logger = logging.getLogger("peaq_os_sdk.client")

_PRIVATE_KEY_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")

# Numeric chain ID for peaq mainnet (used by OWSAccount for EIP-155 signing).
_PEAQ_CHAIN_ID: int = 3338

# 1 PEAQ in wei — the minimum bond sent with register / registerFor.
BOND_AMOUNT_WEI: int = 10**18

_ORCHESTRATION_URL_REQUIRED = "orchestration_url is required to use the orchestration namespace"
_ORCHESTRATION_URL_INVALID = "orchestration_url must be a valid URL with http or https scheme"


def _validate_orchestration_url(url: str, *, verbose: bool) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise OrchestrationConfigError(_ORCHESTRATION_URL_INVALID)
    hostname = (parsed.hostname or "").lower()
    is_loopback = hostname in ("localhost", "127.0.0.1", "::1")
    if verbose and parsed.scheme == "http" and not is_loopback:
        logger.warning(
            "orchestration_url uses http:// with a non-loopback host — "
            "consider using https:// in production",
        )


class PeaqosClient:
    """Single entry point for all peaqOS SDK interactions.

    Accepts all configuration as flat keyword arguments (Python-idiomatic).
    Initialises a Web3 provider, derives the signer address from the
    private key, and binds ``IdentityRegistry`` + ``IdentityStaking``
    contract instances for the registration flow.

    Args:
        rpc_url: RPC endpoint URL for the peaq network.
        private_key: Hex-encoded secp256k1 private key
            (``0x``-prefixed, 64 hex chars).
        identity_registry: IdentityRegistry proxy contract address.
        identity_staking: IdentityStaking proxy contract address.
        event_registry: EventRegistry proxy contract address.
        machine_nft: MachineNFT contract address.
        did_registry: peaq DID precompile address.
        batch_precompile: peaq Batch precompile address.
        api_url: MCR API base URL. Defaults to ``http://127.0.0.1:8000``.
        operational_limits: Per-transaction and rate-limiting caps.
            Defaults to all-zeros (disabled).
        orchestration_url: Base URL of the orchestration (Machine Markets)
            service. When unset, :attr:`orchestration` cannot be used.
        api_key: Platform API key for orchestration HTTP calls, if used.
        verbose: When ``True``, emit extra diagnostics (for example an HTTP
            warning when ``orchestration_url`` is non-TLS against a non-loopback
            host).

    Raises:
        ValidationError: If any required parameter is missing or invalid.

    Example:
        >>> client = PeaqosClient(
        ...     rpc_url="https://peaq-rpc.example.com",
        ...     private_key="0x" + "ab" * 32,
        ...     identity_registry="0x" + "11" * 20,
        ...     identity_staking="0x" + "22" * 20,
        ...     event_registry="0x" + "33" * 20,
        ...     machine_nft="0x" + "44" * 20,
        ...     did_registry="0x" + "55" * 20,
        ...     batch_precompile="0x" + "66" * 20,
        ... )
        >>> client.address  # checksummed address
        '0x...'
    """

    def __init__(
        self,
        *,
        rpc_url: str,
        private_key: str,
        identity_registry: Address,
        identity_staking: Address,
        event_registry: Address,
        machine_nft: Address,
        did_registry: Address,
        batch_precompile: Address,
        machine_account_factory: Address | None = None,
        machine_nft_adapter: Address | None = None,
        api_url: str = DEFAULT_API_URL,
        operational_limits: OperationalLimits | None = None,
        orchestration_url: str | None = None,
        api_key: str | None = None,
        verbose: bool = False,
        _ows_account: OWSAccount | None = None,
    ) -> None:
        if not rpc_url:
            raise ValidationError(
                field="rpc_url",
                constraint="required",
                message="rpc_url is required",
                value=rpc_url,
            )
        if _ows_account is None and (not private_key or not _PRIVATE_KEY_RE.match(private_key)):
            raise ValidationError(
                field="private_key",
                constraint="valid hex private key",
                message="private_key must be a 0x-prefixed 64-char hex string",
                value="[REDACTED]",
            )

        required_contract_args: dict[str, Address] = {
            "identity_registry": identity_registry,
            "identity_staking": identity_staking,
            "event_registry": event_registry,
            "machine_nft": machine_nft,
            "did_registry": did_registry,
            "batch_precompile": batch_precompile,
        }
        for field_name, field_value in required_contract_args.items():
            if not field_value:
                raise ValidationError(
                    field=field_name,
                    constraint="required",
                    message=f"{field_name} is required",
                    value=field_value,
                )

        self.rpc_url: str = rpc_url
        self.contracts: ContractAddresses = ContractAddresses(
            **required_contract_args,
            machine_account_factory=machine_account_factory or None,
            machine_nft_adapter=machine_nft_adapter or None,
        )
        self.api_url: str = api_url
        self.operational_limits: OperationalLimits = (
            operational_limits if operational_limits is not None else OperationalLimits()
        )
        self._orchestration: OrchestrationNamespace | None = None
        if orchestration_url is not None:
            _validate_orchestration_url(orchestration_url, verbose=verbose)
        self.orchestration_url: str | None = orchestration_url
        self.api_key: str | None = api_key
        self.verbose: bool = verbose

        self.w3: Web3 = Web3(Web3.HTTPProvider(rpc_url))

        if _ows_account is not None:
            self._account: TransactionSigner = _ows_account
        else:
            self._account = Account.from_key(private_key)
        self.address: Address = Address(self._account.address)

        # Reusable HTTP session for faucet / API calls.
        self._session: requests.Session = requests.Session()

        # Bind the contract instances the registration flow needs.
        self._identity_registry: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(identity_registry),
            abi=load_abi("IdentityRegistry"),
        )
        self._identity_staking: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(identity_staking),
            abi=load_abi("IdentityStaking"),
        )
        self._machine_nft: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(machine_nft),
            abi=load_abi("MachineNFT"),
        )
        self._did_precompile: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(did_registry),
            abi=load_abi("DIDPrecompile"),
        )
        self._event_registry: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(event_registry),
            abi=load_abi("EventRegistry"),
        )
        self._batch_precompile: Contract = self.w3.eth.contract(
            address=self.w3.to_checksum_address(batch_precompile),
            abi=load_abi("BatchPrecompile"),
        )

    # -- Properties --------------------------------------------------------

    @property
    def web3(self) -> Web3:
        """Alias for :attr:`w3` — the Web3 instance bound to this client."""
        return self.w3

    @property
    def session(self) -> requests.Session:
        """Reusable HTTP session for faucet / API calls."""
        return self._session

    @property
    def orchestration(self) -> OrchestrationNamespace:
        """Orchestration (Machine Markets) API namespace.

        Lazily constructed; the same instance is returned on repeated access.

        Raises:
            OrchestrationConfigError: If ``orchestration_url`` was not set
                at construction.

        Experimental: the orchestration API is under active development.
        """
        if self.orchestration_url is None:
            raise OrchestrationConfigError(_ORCHESTRATION_URL_REQUIRED)
        if self._orchestration is None:
            self._orchestration = OrchestrationNamespace(self)
        return self._orchestration

    @property
    def identity_registry(self) -> Contract:
        """IdentityRegistry contract instance."""
        return self._identity_registry

    @property
    def identity_staking(self) -> Contract:
        """IdentityStaking contract instance."""
        return self._identity_staking

    @property
    def machine_nft(self) -> Contract:
        """MachineNFT contract instance."""
        return self._machine_nft

    @property
    def did_precompile(self) -> Contract:
        """peaq DID precompile contract instance."""
        return self._did_precompile

    @property
    def event_registry(self) -> Contract:
        """EventRegistry contract instance."""
        return self._event_registry

    @property
    def batch_precompile(self) -> Contract:
        """Batch precompile contract instance."""
        return self._batch_precompile

    @property
    def account(self) -> TransactionSigner:
        """The signing account (private key stored inside, or OWS-backed signer)."""
        return self._account

    # -- Static helpers ----------------------------------------------------

    @staticmethod
    def generate_keypair() -> tuple[Address, str]:
        """Generate a fresh secp256k1 keypair without any chain interaction.

        Returns:
            A ``(address, private_key)`` tuple where *address* is checksummed
            and *private_key* is ``0x``-prefixed hex (66 chars).

        Example:
            >>> addr, key = PeaqosClient.generate_keypair()
            >>> addr.startswith("0x")
            True
            >>> len(key)
            66
        """
        acct = Account.create()
        return (Address(acct.address), f"0x{acct.key.hex()}")

    # -- OWS Wallet lifecycle ------------------------------------------------

    @staticmethod
    def create_wallet(
        name: str,
        passphrase: str | None = None,
        words: int = 12,
        vault_path: str | None = None,
    ) -> WalletInfo:
        """Create a new OWS wallet with a BIP-39 mnemonic.

        Static method. Derives accounts for all supported chains
        and stores the encrypted wallet in the OWS vault.

        Args:
            name: Human-readable wallet label.
            passphrase: Vault passphrase. Falls back to ``OWS_PASSPHRASE``.
            words: Mnemonic length — 12 or 24. Defaults to 12.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            :class:`WalletInfo` with all chain accounts.

        Raises:
            PeaqosError: If OWS is not installed or passphrase is missing.
        """
        from .wallet.create_wallet import create_wallet as _impl

        return _impl(name, passphrase, words, vault_path)

    @staticmethod
    def import_wallet(
        name: str,
        private_key: str,
        passphrase: str | None = None,
        chain: ImportChain = IMPORT_CHAIN_EVM,
        vault_path: str | None = None,
    ) -> WalletInfo:
        """Import a raw private key into the OWS vault.

        Static method. Validates key format, encrypts, and stores.

        Args:
            name: Human-readable wallet label.
            private_key: ``0x``-prefixed 64-char hex private key.
            passphrase: Vault passphrase. Falls back to ``OWS_PASSPHRASE``.
            chain: Target chain family. Defaults to ``IMPORT_CHAIN_EVM``.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            :class:`WalletInfo` with all chain accounts.

        Raises:
            ValidationError: If ``private_key`` is not valid hex.
            PeaqosError: If OWS is not installed or passphrase is missing.
        """
        from .wallet.import_wallet import import_wallet as _impl

        return _impl(name, private_key, passphrase, chain, vault_path)

    @staticmethod
    def import_wallet_mnemonic(
        name: str,
        mnemonic: str,
        passphrase: str | None = None,
        index: int = 0,
        vault_path: str | None = None,
    ) -> WalletInfo:
        """Import a BIP-39 mnemonic phrase into the OWS vault.

        Static method.

        Args:
            name: Human-readable wallet label.
            mnemonic: 12 or 24 word BIP-39 phrase.
            passphrase: Vault passphrase. Falls back to ``OWS_PASSPHRASE``.
            index: Account derivation index. Defaults to 0.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            :class:`WalletInfo` with all chain accounts.

        Raises:
            PeaqosError: If OWS is not installed or passphrase is missing.
        """
        from .wallet.import_wallet_mnemonic import import_wallet_mnemonic as _impl

        return _impl(name, mnemonic, passphrase, index, vault_path)

    @staticmethod
    def list_wallets(vault_path: str | None = None) -> list[WalletInfo]:
        """List all wallets in the OWS vault.

        Static method.

        Args:
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            List of :class:`WalletInfo`. Empty when vault has no wallets.

        Raises:
            PeaqosError: If OWS is not installed.
        """
        from .wallet.list_wallets import list_wallets as _impl

        return _impl(vault_path)

    @staticmethod
    def get_wallet(
        name_or_id: str,
        vault_path: str | None = None,
    ) -> WalletInfo:
        """Retrieve a single wallet by name or UUID.

        Static method.

        Args:
            name_or_id: Wallet name or UUID.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            :class:`WalletInfo`.

        Raises:
            PeaqosError: If the wallet is not found or OWS is not installed.
        """
        from .wallet.get_wallet import get_wallet as _impl

        return _impl(name_or_id, vault_path)

    @staticmethod
    def export_wallet(
        name_or_id: str,
        passphrase: str | None = None,
        vault_path: str | None = None,
    ) -> str:
        """Export a wallet's mnemonic phrase or private key.

        Static method.

        Args:
            name_or_id: Wallet name or UUID.
            passphrase: Vault passphrase. Falls back to ``OWS_PASSPHRASE``.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Returns:
            The mnemonic phrase or JSON with key pair.

        Raises:
            PeaqosError: If not found, wrong passphrase, or OWS not installed.
        """
        from .wallet.export_wallet import export_wallet as _impl

        return _impl(name_or_id, passphrase, vault_path)

    @staticmethod
    def delete_wallet(
        name_or_id: str,
        vault_path: str | None = None,
    ) -> None:
        """Securely delete a wallet from the OWS vault.

        Static method. Overwrites file with random bytes before unlinking.

        Args:
            name_or_id: Wallet name or UUID.
            vault_path: Custom vault directory. Defaults to ``~/.ows/``.

        Raises:
            PeaqosError: If the wallet is not found or OWS is not installed.
        """
        from .wallet.delete_wallet import delete_wallet as _impl

        _impl(name_or_id, vault_path)

    @staticmethod
    def wait_for_bridge_arrival(
        dst_rpc_url: str,
        dst_nft_address: str,
        token_id: int,
        timeout: int = 300,
    ) -> bool:
        """Poll a destination chain until a bridged NFT arrives (or timeout).

        Probes ``MachineNFT.ownerOf(token_id)`` every 10 seconds on the
        destination chain. Returns ``True`` as soon as a non-zero owner
        is returned; returns ``False`` when ``timeout`` seconds elapse.
        Requires no client instance — static method.

        Args:
            dst_rpc_url: RPC endpoint of the destination chain.
            dst_nft_address: ``MachineNFT`` address on the destination.
            token_id: The NFT id expected to arrive.
            timeout: Wait budget in seconds. Defaults to 300 (5 min).

        Returns:
            ``True`` on arrival, ``False`` on timeout.

        Raises:
            ValidationError: If any parameter fails validation.

        Example::

            arrived = PeaqosClient.wait_for_bridge_arrival(
                dst_rpc_url="https://base-mainnet.example.com",
                dst_nft_address="0x...",
                token_id=42,
            )
        """
        from .bridge.wait_for_bridge_arrival import (
            wait_for_bridge_arrival as _impl,
        )

        return _impl(dst_rpc_url, dst_nft_address, token_id, timeout)

    @classmethod
    def from_env(cls) -> PeaqosClient:
        """Create a PeaqosClient from environment variables.

        Required env vars: ``PEAQOS_RPC_URL``, ``PEAQOS_PRIVATE_KEY``,
        ``IDENTITY_REGISTRY_ADDRESS``, ``IDENTITY_STAKING_ADDRESS``,
        ``EVENT_REGISTRY_ADDRESS``, ``MACHINE_NFT_ADDRESS``,
        ``DID_REGISTRY_ADDRESS``, ``BATCH_PRECOMPILE_ADDRESS``.

        Optional env vars:
        ``PEAQOS_MCR_API_URL`` (defaults to ``http://127.0.0.1:8000``),
        ``PEAQOS_ORCHESTRATION_URL`` and ``PEAQOS_API_KEY`` (orchestration),
        ``MACHINE_ACCOUNT_FACTORY_ADDRESS`` (required when deploying
        smart accounts), ``MACHINE_NFT_ADAPTER_ADDRESS`` (required
        for peaq→Base NFT bridging).

        Returns:
            A fully configured PeaqosClient.

        Raises:
            ValidationError: If any required environment variable is missing.

        Example:
            >>> client = PeaqosClient.from_env()  # doctest: +SKIP
        """

        def _require(env_var: str) -> str:
            val = os.environ.get(env_var)
            if not val:
                raise ValidationError(
                    field=env_var,
                    constraint="required env var",
                    message=f"Environment variable {env_var} is required but not set",
                    value=None,
                )
            return val

        def _optional(env_var: str) -> Address | None:
            val = os.environ.get(env_var)
            return Address(val) if val else None

        orch_url = os.environ.get("PEAQOS_ORCHESTRATION_URL")
        platform_api_key = os.environ.get("PEAQOS_API_KEY")

        kwargs: dict[str, Any] = dict(
            rpc_url=_require("PEAQOS_RPC_URL"),
            private_key=_require("PEAQOS_PRIVATE_KEY"),
            identity_registry=Address(_require("IDENTITY_REGISTRY_ADDRESS")),
            identity_staking=Address(_require("IDENTITY_STAKING_ADDRESS")),
            event_registry=Address(_require("EVENT_REGISTRY_ADDRESS")),
            machine_nft=Address(_require("MACHINE_NFT_ADDRESS")),
            did_registry=Address(_require("DID_REGISTRY_ADDRESS")),
            batch_precompile=Address(_require("BATCH_PRECOMPILE_ADDRESS")),
            machine_account_factory=_optional("MACHINE_ACCOUNT_FACTORY_ADDRESS"),
            machine_nft_adapter=_optional("MACHINE_NFT_ADAPTER_ADDRESS"),
            api_url=os.environ.get("PEAQOS_MCR_API_URL", DEFAULT_API_URL),
        )
        if orch_url:
            kwargs["orchestration_url"] = orch_url
        if platform_api_key:
            kwargs["api_key"] = platform_api_key

        return cls(**kwargs)

    @classmethod
    def from_wallet(
        cls,
        name_or_id: str,
        passphrase: str | None = None,
        ows_signing: bool = True,
        vault_path: str | None = None,
        **config_kwargs: Any,
    ) -> PeaqosClient:
        """Construct a PeaqosClient from an OWS vault wallet.

        Args:
            name_or_id: Wallet name or UUID in the OWS vault.
            passphrase: Vault encryption passphrase. Falls back to
                ``OWS_PASSPHRASE`` environment variable.
            ows_signing: When ``True`` (default), transaction signing routes
                through OWS. The SDK never holds the raw private key on
                the client; only the wallet identifier, passphrase, and
                vault path are retained. The complementary OWS-side
                decrypt-and-wipe-per-sign behavior is an upstream
                guarantee from ``open-wallet-standard`` and is not
                independently enforced by this SDK. Passphrase is **not**
                verified at construction (OWS exposes no passphrase-only
                verification endpoint, and exporting the key just to
                verify would pull the secret into Python memory); a
                wrong passphrase surfaces on the first sign call as a
                ``PeaqosError``. When ``False``, the key is exported and
                decrypted at construction, so the passphrase is verified
                eagerly.
            vault_path: Optional custom OWS vault directory. Defaults to
                ``~/.ows/``.
            **config_kwargs: All other :class:`PeaqosClient` constructor
                keyword arguments (``rpc_url``, contract addresses, etc.).

        Returns:
            A configured :class:`PeaqosClient` whose
            :attr:`address` matches the wallet's peaq address.

        Raises:
            PeaqosError: If OWS is not installed, the passphrase is missing,
                the wallet is not found, or (when ``ows_signing=False``) the
                passphrase is wrong. With ``ows_signing=True``, a wrong
                passphrase is deferred to the first sign call.

        Example::

            client = PeaqosClient.from_wallet(
                "my-machine",
                passphrase="s3cret",
                rpc_url="https://peaq-rpc.example.com",
                identity_registry=Address("0x..."),
                ...
            )
        """
        from .wallet._internal.load_ows import resolve_passphrase

        resolved = resolve_passphrase(passphrase)
        wallet_info = cls.get_wallet(name_or_id, vault_path)

        if ows_signing:
            # No eager passphrase verification: OWS has no verify-only
            # endpoint and exporting the secret just to check the
            # passphrase would pull the raw key into Python memory,
            # defeating the OWS-native decrypt-per-sign guarantee. A
            # wrong passphrase surfaces on the first sign call instead.
            ows_account = OWSAccount(
                address=wallet_info.peaq_address,
                wallet_name_or_id=name_or_id,
                passphrase=resolved,
                chain_id=_PEAQ_CHAIN_ID,
                vault_path=vault_path,
            )
            return cls(
                private_key="",
                _ows_account=ows_account,
                **config_kwargs,
            )

        # Eager-decrypt path: export and derive the private key now.
        exported = cls.export_wallet(name_or_id, resolved, vault_path)
        acct: LocalAccount
        # Detect the wallet's export shape rather than trusting
        # ``wallet_info.key_type``: real OWS ``get_wallet`` does not return
        # ``key_type`` and the SDK defaults missing values to ``"mnemonic"``,
        # which would mis-route private-key wallets into ``from_mnemonic``.
        try:
            parsed: Any = json.loads(exported)
        except (json.JSONDecodeError, TypeError):
            parsed = None

        if isinstance(parsed, dict) and isinstance(parsed.get("secp256k1"), str):
            # OWS 1.3.2 returns {"ed25519": "<hex>", "secp256k1": "<hex>"}
            # without the 0x prefix on either value.
            acct = Account.from_key(f"0x{parsed['secp256k1']}")
        else:
            Account.enable_unaudited_hdwallet_features()
            acct = Account.from_mnemonic(exported)
            if acct.address.lower() != wallet_info.peaq_address.lower():
                from .exceptions.base import PeaqosError

                raise PeaqosError(
                    "Derived address from mnemonic does not match wallet's peaq address"
                )
        return cls(private_key=f"0x{acct.key.hex()}", **config_kwargs)

    # -- Registration methods ----------------------------------------------

    def setup_faucet_2fa(
        self,
        owner_address: str,
        faucet_base_url: str,
        qr_format: str = "svg",
    ) -> FaucetSetupResponse:
        """Initiate 2FA enrollment for an owner address.

        Sends ``POST {faucet_base_url}/2fa/setup`` and returns the
        enrollment payload — an ``otpauth_uri`` for manual entry plus
        a short-lived ``qr_image_url`` that can be rendered and scanned
        by an authenticator app.

        Args:
            owner_address: Owner address to enroll. SS58 or ``0x`` hex.
            faucet_base_url: Absolute base URL of the gas station.
            qr_format: QR image format — ``"svg"`` (default) or ``"png"``.

        Returns:
            Dict with ``owner_address``, ``otpauth_uri``, ``qr_image_url``.

        Raises:
            ValidationError: If ``owner_address`` or ``faucet_base_url`` is empty.
            ApiError: On ``INVALID_OWNER_ADDRESS`` (400),
                ``QR_GENERATION_FAILED`` (500), a network failure,
                or an unexpected response envelope.

        Example::

            setup = client.setup_faucet_2fa(
                owner_address="5GrwvaEF...",
                faucet_base_url="https://depinstation.peaq.xyz",
            )
            print(setup["otpauth_uri"])   # paste into authenticator
            print(setup["qr_image_url"])  # render immediately — expires
        """
        from .registration.faucet import setup_faucet_2fa as _impl

        return _impl(self._session, owner_address, faucet_base_url, qr_format)

    def confirm_faucet_2fa(
        self,
        owner_address: str,
        faucet_base_url: str,
        two_factor_code: str,
    ) -> None:
        """Confirm 2FA activation with a TOTP code.

        Sends ``POST {faucet_base_url}/2fa/confirm`` with the current
        TOTP code from the owner's authenticator app. Must be called
        after :meth:`setup_faucet_2fa` and before
        :meth:`fund_from_gas_station`.

        Args:
            owner_address: Owner address whose 2FA is being confirmed.
            faucet_base_url: Absolute base URL of the gas station.
            two_factor_code: Current TOTP code from the authenticator app.

        Raises:
            ValidationError: If any argument is empty.
            ApiError: On ``INVALID_2FA`` (401) — message contains
                "Invalid 2FA code"; ``2FA_NOT_CONFIGURED`` (400) —
                message contains "not configured"; or an unexpected
                response envelope.

        Example::

            client.confirm_faucet_2fa(
                owner_address="5GrwvaEF...",
                faucet_base_url="https://depinstation.peaq.xyz",
                two_factor_code="123456",
            )
        """
        from .registration.faucet import confirm_faucet_2fa as _impl

        _impl(self._session, owner_address, faucet_base_url, two_factor_code)

    def fund_from_gas_station(
        self,
        owner_address: str,
        target_wallet_address: str,
        chain_id: str,
        two_factor_code: str,
        faucet_base_url: str,
        request_id: str | None = None,
    ) -> FaucetFundResponse:
        """Request a funding transfer from the peaq gas station.

        Sends ``POST {faucet_base_url}/faucet/fund`` with the owner's
        current TOTP code and returns a discriminated union —
        ``FundedResponse`` when the transfer lands on-chain, or
        ``SkippedResponse`` when the wallet already has at least the
        minimum gas balance.

        Args:
            owner_address: 2FA-enrolled owner address.
            target_wallet_address: Machine wallet to fund.
            faucet_base_url: Absolute base URL of the gas station.
            two_factor_code: Current TOTP code from the authenticator.
            chain_id: Target chain identifier (default ``"peaq"``).
            request_id: Idempotency key (UUID). Auto-generated via
                ``uuid.uuid4()`` if ``None``.

        Returns:
            ``FundedResponse`` with ``tx_hash`` + ``funded_amount`` on
            success, or ``SkippedResponse`` with ``current_balance`` +
            ``min_gas_balance`` when funding was skipped.

        Raises:
            ValidationError: If a required argument is empty.
            ApiError: On any documented faucet error code or a network failure.

        Example::

            result = client.fund_from_gas_station(
                owner_address="5GrwvaEF...",
                target_wallet_address=machine_address,
                faucet_base_url="https://depinstation.peaq.xyz",
                two_factor_code="654321",
            )
            if result["status"] == "success":
                print("funded:", result["tx_hash"])
            else:
                print("skipped, balance:", result["current_balance"])
        """
        from .registration.fund_from_gas_station import fund_from_gas_station as _impl

        return _impl(
            self._session,
            owner_address,
            target_wallet_address,
            chain_id,
            two_factor_code,
            faucet_base_url,
            request_id,
        )

    def register_machine(self) -> int:
        """Register the caller as a machine on the IdentityRegistry.

        Calls the payable ``register()`` function with 1 PEAQ attached
        as the minimum bond. The contract assigns a fresh ``machineId``
        and emits a ``Registered`` event, which this method decodes
        to return the new identity ID.

        Returns:
            The newly assigned ``machine_id`` as a positive ``int``.

        Raises:
            RpcError: On ``AlreadyRegistered`` (message contains
                "already registered"), insufficient balance, or any
                other on-chain revert.

        Example::

            address, private_key = PeaqosClient.generate_keypair()
            # ... fund the address via fund_from_gas_station ...
            machine_id = client.register_machine()
            print(f"Registered with machine ID {machine_id}")
        """
        from .registration.register_machine import register_machine as _impl

        return _impl(self)

    def register_for(self, machine_address: str) -> int:
        """Register a machine address as a machine via proxy.

        Calls ``registerFor(machineAddress)`` with 1 PEAQ attached as
        the minimum bond. The caller's signing wallet becomes the
        on-chain owner of the new identity; ``machine_address`` is
        the registered machine.

        Args:
            machine_address: The machine EOA to register.
                ``0x``-prefixed 20-byte hex address.

        Returns:
            The newly assigned ``machine_id`` as a positive ``int``.

        Raises:
            ValidationError: If ``machine_address`` is not a valid
                ``0x``-prefixed Ethereum address.
            RpcError: On ``AlreadyRegistered`` (message contains
                "already registered"), ``InvalidMachineAddress``
                (message contains "zero address"), insufficient
                balance, or any other on-chain revert.

        Example::

            machine_address, _ = PeaqosClient.generate_keypair()
            machine_id = proxy_client.register_for(machine_address)
            print(f"Registered machine {machine_address} with machine ID {machine_id}")
        """
        from .registration.register_for import register_for as _impl

        return _impl(self, machine_address)

    def mint_nft(self, machine_id: int, recipient: str) -> str:
        """Mint an NFT for a registered machine on the MachineNFT contract.

        Calls the non-payable ``mint(uint256 machineId, address recipient)``
        function and returns the transaction hash.

        Args:
            machine_id: The registered machine ID. Must be a positive integer.
            recipient: Address that will receive the NFT.
                ``0x``-prefixed 20-byte hex address.

        Returns:
            The transaction hash as a hex string.

        Raises:
            ValidationError: If ``machine_id`` is not positive or
                ``recipient`` is not a valid Ethereum address.
            RpcError: If the machine is not bonded (``MachineNotBonded``),
                the NFT is already minted (``AlreadyMinted``), the caller
                is not the machine owner (``NotMachineOwner``), or the
                transaction reverts for any other reason.

        Example::

            tx_hash = client.mint_nft(machine_id=42, recipient=client.address)
            print(f"Minted NFT in tx {tx_hash}")
        """
        from .nft.mint_nft import mint_nft as _impl

        return _impl(self, machine_id, recipient)

    def token_id_of(self, machine_id: int) -> int:
        """Return the NFT token ID assigned to a registered machine.

        Calls ``tokenIdOf(uint256 machineId)`` as a read-only view — no
        transaction is submitted.

        Args:
            machine_id: The registered machine ID. Must be a positive integer.

        Returns:
            The NFT token ID as a positive ``int``.

        Raises:
            ValidationError: If ``machine_id`` is not positive.
            RpcError: If the machine has no NFT minted (contract reverts).

        Example::

            token_id = client.token_id_of(machine_id=42)
            print(f"NFT token ID: {token_id}")
        """
        from .nft.token_id_of import token_id_of as _impl

        return _impl(self, machine_id)

    def write_machine_did_attributes(
        self,
        machine_id: int,
        nft_token_id: int,
        operator_did: str,
        documentation_url: str,
        data_api: str,
        data_visibility: str,
    ) -> str:
        """Write the 6 standard DID attributes for a registered machine.

        Validates all inputs, then submits a single ``batchAll`` transaction
        that atomically writes ``machineId``, ``nftTokenId``, ``operator``,
        ``documentation_url``, ``data_api``, and ``data_visibility`` to
        the caller's DID.

        Args:
            machine_id: Registered machine ID. Must be a positive integer.
            nft_token_id: NFT token ID assigned to the machine. Must be
                positive.
            operator_did: Operator DID reference. May be an empty string.
                Must be ASCII and ≤ 2560 bytes.
            documentation_url: Documentation URL. Must be non-empty,
                ASCII, and ≤ 2560 bytes.
            data_api: Data API endpoint. Must be non-empty, ASCII,
                and ≤ 2560 bytes.
            data_visibility: Visibility setting — one of ``"public"``,
                ``"private"``, or ``"onchain"``.

        Returns:
            The batch transaction hash as a hex string.

        Raises:
            ValidationError: If any parameter fails its constraint.
            RpcError: If the batch transaction reverts.

        Example::

            tx_hash = client.write_machine_did_attributes(
                machine_id=42,
                nft_token_id=1,
                operator_did="",
                documentation_url="https://docs.example.com",
                data_api="https://api.example.com",
                data_visibility="public",
            )
            print(f"DID attributes written in tx {tx_hash}")
        """
        from .did.write_machine_did_attributes import (
            write_machine_did_attributes as _impl,
        )

        return _impl(
            self,
            machine_id,
            nft_token_id,
            operator_did,
            documentation_url,
            data_api,
            data_visibility,
        )

    def write_proxy_did_attributes(
        self,
        proxy_machine_id: int,
        machine_ids: list[int],
    ) -> str:
        """Write the 2 standard DID attributes for a proxy operator.

        Validates all inputs, then submits a single ``batchAll`` transaction
        that atomically writes ``machineId`` and ``machines`` to the
        caller's DID.

        Args:
            proxy_machine_id: The proxy operator's registered machine ID.
                Must be a positive integer.
            machine_ids: Non-empty list of positive machine IDs managed by
                this proxy. The JSON-encoded list must be ≤ 2560 bytes.

        Returns:
            The batch transaction hash as a hex string.

        Raises:
            ValidationError: If ``proxy_machine_id`` is not positive,
                ``machine_ids`` is empty or contains a non-positive ID,
                or the JSON-encoded list exceeds the byte-length cap.
            RpcError: If the batch transaction reverts.

        Example::

            tx_hash = client.write_proxy_did_attributes(
                proxy_machine_id=10,
                machine_ids=[42, 43, 44],
            )
            print(f"Proxy DID attributes written in tx {tx_hash}")
        """
        from .did.write_proxy_did_attributes import (
            write_proxy_did_attributes as _impl,
        )

        return _impl(self, proxy_machine_id, machine_ids)

    # -- Query methods -----------------------------------------------------

    def query_mcr(self, did: str) -> MCRResponse:
        """Fetch the machine credit rating for a given machine DID.

        Args:
            did: Machine DID. Must start with ``did:peaq:0x``.

        Returns:
            A :class:`~peaq_os_sdk.types.queries.MCRResponse` TypedDict.

        Raises:
            ValidationError: If ``did`` has an invalid prefix.
            ApiError: On any HTTP / transport failure — inspect
                ``err.code`` to branch programmatically.

        Example::

            mcr = client.query_mcr("did:peaq:0xabc...")
            print(mcr["mcr_score"], mcr["mcr"])
        """
        from .query.query_mcr import query_mcr as _impl

        return _impl(self, did)

    def query_machine(self, did: str) -> MachineProfileResponse:
        """Fetch the full machine profile for a given machine DID.

        Args:
            did: Machine DID. Must start with ``did:peaq:0x``.

        Returns:
            A plain ``dict[str, Any]`` matching the NFT metadata JSON
            v1.0 schema. See
            :class:`~peaq_os_sdk.types.queries.MachineProfileResponse`.

        Raises:
            ValidationError: If ``did`` has an invalid prefix.
            ApiError: On any HTTP / transport failure — inspect
                ``err.code`` to branch programmatically.

        Example::

            profile = client.query_machine("did:peaq:0xabc...")
            print(profile["schema_version"])
        """
        from .query.query_machine import query_machine as _impl

        return _impl(self, did)

    def query_operator_machines(self, did: str) -> OperatorMachinesResponse:
        """Fetch the fleet of machines managed by a proxy operator.

        Args:
            did: Operator DID. Must start with ``did:peaq:0x``.

        Returns:
            An :class:`~peaq_os_sdk.types.queries.OperatorMachinesResponse`
            TypedDict with ``operator_did`` and a ``machines`` list.

        Raises:
            ValidationError: If ``did`` has an invalid prefix.
            ApiError: On any HTTP / transport failure — inspect
                ``err.code`` to branch programmatically.

        Example::

            fleet = client.query_operator_machines("did:peaq:0xabc...")
            for m in fleet["machines"]:
                print(m["machine_id"], m["mcr_score"], m["mcr"])
        """
        from .query.query_operator_machines import (
            query_operator_machines as _impl,
        )

        return _impl(self, did)

    # -- Smart account methods ---------------------------------------------

    def deploy_smart_account(
        self,
        owner: str,
        machine: str,
        salt: int,
    ) -> Address:
        """Deploy an ERC-4337 smart account via ``MachineAccountFactory``.

        Args:
            owner: EOA that will own the deployed smart account.
            machine: Machine EOA the account is scoped to.
            salt: Non-negative CREATE2 salt.

        Returns:
            The deployed smart-account :class:`Address`.

        Raises:
            ValidationError: If any parameter is invalid, or the client
                was constructed without ``machine_account_factory``.
            RpcError: On tx revert or a missing/malformed
                ``AccountCreated`` event.

        Example::

            address = client.deploy_smart_account(
                owner=client.address,
                machine=machine_address,
                salt=0,
            )
        """
        from .smart_account.deploy_smart_account import (
            deploy_smart_account as _impl,
        )

        return _impl(self, owner, machine, salt)

    def get_smart_account_address(
        self,
        owner: str,
        machine: str,
        salt: int,
    ) -> Address:
        """Compute the CREATE2 address for a smart account without deploying it.

        Same parameter contract as :meth:`deploy_smart_account` but runs
        a read-only ``getAddress`` view call — no transaction, no gas.
        The returned address is identical to what :meth:`deploy_smart_account`
        will produce for the same inputs (CREATE2 determinism).

        Args:
            owner: EOA that will own the smart account.
            machine: Machine EOA the account is scoped to.
            salt: Non-negative CREATE2 salt.

        Returns:
            The predicted smart-account :class:`Address`.

        Raises:
            ValidationError: If any parameter is invalid, or the client
                was constructed without ``machine_account_factory``.
            RpcError: If the factory returns a value that is not a
                valid address.

        Example::

            predicted = client.get_smart_account_address(
                owner=client.address,
                machine=machine_address,
                salt=0,
            )
        """
        from .smart_account.get_smart_account_address import (
            get_smart_account_address as _impl,
        )

        return _impl(self, owner, machine, salt)

    # -- Bridge methods ----------------------------------------------------

    def bridge_nft(
        self,
        token_id: int,
        source: str,
        destination: str,
        recipient: str,
        *,
        base_rpc_url: str | None = None,
        base_nft_address: str | None = None,
        options: bytes = b"",
    ) -> Hex32:
        """Bridge a Machine NFT between peaq and Base via LayerZero v2.

        Args:
            token_id: Positive NFT id to bridge.
            source: Origin chain, ``"peaq"`` or ``"base"``.
            destination: Target chain, must differ from ``source``.
            recipient: Destination-chain recipient address.
            base_rpc_url: Required only when ``source == "base"``.
            base_nft_address: ``MachineNFTBase`` address on Base.
                Required only when ``source == "base"``.
            options: Raw LayerZero ``extraOptions`` bytes.

        Returns:
            The source-chain transaction hash (``0x``-prefixed).

        Raises:
            ValidationError: On any invalid parameter.
            RpcError: On revert, bad fee quote, or transport failure.

        Example::

            tx = client.bridge_nft(
                token_id=42,
                source="peaq",
                destination="base",
                recipient="0xabc...",
            )
        """
        from .bridge.bridge_nft import bridge_nft as _impl

        return _impl(
            self,
            token_id,
            source,
            destination,
            recipient,
            base_rpc_url=base_rpc_url,
            base_nft_address=base_nft_address,
            options=options,
        )

    def submit_event(
        self,
        *,
        machine_id: int,
        event_type: int,
        value: int,
        timestamp: int,
        raw_data: bytes | None,
        trust_level: int,
        source_chain_id: int,
        source_tx_hash: Hex32 | None,
        metadata: bytes,
        currency: str | None = _OMITTED_CURRENCY,
    ) -> tuple[str, bytes]:
        """Submit one event to the EventRegistry.

        BREAKING (PRO-334): ``value`` is an ISO 4217 subunit integer
        (e.g. ``HK$1.23`` → ``value=123, currency="HKD"``; ``¥100`` →
        ``value=100, currency="JPY"``). Partners convert whole-currency
        amounts to subunit integers before calling. ``float`` /
        ``Decimal`` / ``bool`` / ``str`` / ``None`` raise ``TypeError``.

        Args:
            machine_id: Machine identity identifier.
            event_type: Event type (0 or 1).
            value: Event value as an ISO 4217 subunit integer (PRO-334).
            timestamp: Unix timestamp in seconds.
            raw_data: Raw payload bytes or ``None``.
            trust_level: Trust level (0, 1, or 2).
            source_chain_id: Source chain id.
            source_tx_hash: Optional 32-byte source tx hash.
            metadata: Metadata bytes.
            currency: Currency code per PRO-336 §6. Omit the kwarg to apply
                the smart default — ``"USD"`` for revenue events, ``""``
                for activity events. Pass an explicit string (revenue:
                ``^[A-Z0-9]{3,10}$``; activity: ``""``) to override. Passing
                ``None`` explicitly raises ``ValidationError(field="currency")``
                — the omit-vs-null distinction is preserved end-to-end.

        Returns:
            ``(tx_hash, data_hash)`` where ``tx_hash`` is a 0x-prefixed hash
            string and ``data_hash`` is exactly 32 bytes.

        Raises:
            TypeError: If ``value`` is not a strict ``int`` (PRO-334
                subunit convention — rejects ``bool``, ``float``,
                ``Decimal``, ``str``, ``None``, ``IntEnum``, etc.).
            ValidationError: If params fail schema checks (including
                explicit ``currency=None``).
            ValueCapExceeded: If value cap is exceeded.
            RateLimitExceeded: If rate limits are exceeded.
            RpcError: On transaction or contract failures.
        """
        from .events.submit_event import submit_event as _impl

        return _impl(
            self,
            SubmitEventParams(
                machine_id=machine_id,
                event_type=event_type,
                value=value,
                timestamp=timestamp,
                raw_data=raw_data,
                trust_level=trust_level,
                source_chain_id=source_chain_id,
                source_tx_hash=source_tx_hash,
                metadata=metadata,
                currency=currency,
            ),
        )

    def batch_submit_events(
        self,
        events: list[dict[str, object] | SubmitEventParams],
    ) -> list[str]:
        """Submit multiple events atomically via the Batch precompile.

        Args:
            events: Non-empty list of event payloads. Items may be
                ``SubmitEventParams`` or dict objects with matching keys.

        Returns:
            One transaction hash per input event (all hashes are identical).

        Raises:
            ValidationError: If events is empty or any event is invalid.
            ValueCapExceeded: If value cap is exceeded.
            RateLimitExceeded: If configured rate limits are exceeded.
            RpcError: On transaction or contract failures.
        """
        from .events.batch_submit_events import batch_submit_events as _impl

        return _impl(self, events)

    def to_json(self) -> dict[str, object]:
        """Serialize client state for logging with secrets redacted.

        Returns:
            A plain dict with ``private_key`` and ``api_key`` replaced by
            the string ``[REDACTED]`` (``api_key`` is ``None`` when unset).
        """
        return {
            "address": self.address,
            "rpc_url": self.rpc_url,
            "contracts": asdict(self.contracts),
            "api_url": self.api_url,
            "operational_limits": asdict(self.operational_limits),
            "orchestration_url": self.orchestration_url,
            "api_key": "[REDACTED]" if self.api_key else None,
            "private_key": "[REDACTED]",
        }

    # -- Dunder overrides --------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"<PeaqosClient address={self.address!r}"
            f" rpc_url={self.rpc_url!r} private_key=[REDACTED]>"
        )

    def __str__(self) -> str:
        return self.__repr__()
