"""In-memory sliding-window tracker for event submission rate limits."""

from __future__ import annotations

import time


class RateLimitTracker:
    """Track per-machine event timestamps in a sliding window.

    The tracker is in-memory and process-local. It stores a mapping from
    `machine_id` to a list of event timestamps used for SDK-side rate-limit
    checks by `submit_event` and `batch_submit_events`.
    """

    def __init__(self) -> None:
        self._events_by_machine: dict[int, list[float]] = {}

    def record_event(self, machine_id: int, timestamp: float) -> None:
        """Record one event timestamp for an machine.

        Args:
            machine_id: Machine identifier used as the rate-limit key.
            timestamp: Event timestamp in seconds.
        """
        events = self._events_by_machine.get(machine_id, [])
        events.append(timestamp)
        self._events_by_machine[machine_id] = events

    def rollback_event(self, machine_id: int, timestamp: float) -> bool:
        """Remove one previously recorded timestamp for an machine.

        Useful for rolling back a provisional in-flight reservation when
        a transaction fails before completion.

        Args:
            machine_id: Machine identifier used as the rate-limit key.
            timestamp: Reserved timestamp to remove.

        Returns:
            bool: `True` if one matching timestamp was removed, otherwise `False`.
        """
        events = self._events_by_machine.get(machine_id)
        if not events:
            return False
        for idx in range(len(events) - 1, -1, -1):
            if events[idx] == timestamp:
                del events[idx]
                if events:
                    self._events_by_machine[machine_id] = events
                else:
                    del self._events_by_machine[machine_id]
                return True
        return False

    def get_event_count(self, machine_id: int, window_seconds: int) -> int:
        """Return the event count for an machine inside the active window.

        Args:
            machine_id: Machine identifier used as the rate-limit key.
            window_seconds: Sliding-window size in seconds.

        Returns:
            int: Number of retained events for this machine within the window.
        """
        if window_seconds <= 0:
            return 0
        self.prune(machine_id, window_seconds)
        events = self._events_by_machine.get(machine_id)
        return len(events) if events is not None else 0

    def prune(self, machine_id: int, window_seconds: int) -> None:
        """Remove timestamps older than the current sliding-window cutoff.

        Args:
            machine_id: Machine identifier used as the rate-limit key.
            window_seconds: Sliding-window size in seconds.
        """
        if window_seconds <= 0:
            self._events_by_machine.pop(machine_id, None)
            return

        events = self._events_by_machine.get(machine_id)
        if not events:
            return

        cutoff = int(time.time()) - window_seconds
        pruned = [ts for ts in events if ts > cutoff]
        if pruned:
            self._events_by_machine[machine_id] = pruned
        else:
            self._events_by_machine.pop(machine_id, None)


rate_limit_tracker = RateLimitTracker()
