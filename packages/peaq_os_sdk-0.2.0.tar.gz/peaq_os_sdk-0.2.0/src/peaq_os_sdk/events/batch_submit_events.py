"""Atomic batch event submission via the peaq Batch precompile."""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Final

from ..exceptions.rpc_error import RpcError
from ..exceptions.validation_error import ValidationError
from ..types.events import _OMITTED_CURRENCY, SubmitEventParams
from ..utils.data_hash import compute_data_hash
from ..utils.transaction import send_and_await
from ..validation.operational_limits import EventTracker, check_operational_limits
from ..validation.submit_event import validate_submit_event_params
from .rate_limit_tracker import rate_limit_tracker

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.events.batch_submit_events")

_ZERO_BYTES32 = bytes(32)
_ZERO_HEX32 = "0x" + ("0" * 64)


def _limits_disabled(client: PeaqosClient) -> bool:
    limits = client.operational_limits
    return (
        limits.max_value_per_tx == 0
        and limits.rate_limit_max_events == 0
        and limits.rate_limit_window_seconds == 0
    )


def _current_tracker(machine_id: int, window_seconds: int, now: int) -> EventTracker | None:
    count = rate_limit_tracker.get_event_count(machine_id, window_seconds)
    if count == 0:
        return None
    return EventTracker(
        machine_id=machine_id,
        count=count,
        window_start=max(0, now - window_seconds),
    )


def _map_batch_error(err: RpcError, machine_ids: set[int]) -> RpcError:
    single_machine_id = next(iter(machine_ids)) if len(machine_ids) == 1 else None
    if err.code in {"MachineNotFound"}:
        if single_machine_id is not None:
            return RpcError(f"Machine ID {single_machine_id} does not exist", code=err.code)
        return RpcError("One or more machine IDs in this batch do not exist", code=err.code)
    if err.code == "MachineNotBonded":
        if single_machine_id is not None:
            return RpcError(f"Machine ID {single_machine_id} is not bonded", code=err.code)
        return RpcError("One or more machines in this batch are not bonded", code=err.code)
    if err.code == "MachineDeactivated":
        if single_machine_id is not None:
            return RpcError(f"Machine ID {single_machine_id} is deactivated", code=err.code)
        return RpcError("One or more machines in this batch are deactivated", code=err.code)
    if err.code == "NotAuthorizedSubmitter":
        if single_machine_id is not None:
            return RpcError(
                f"Caller is not authorized to submit events for machine {single_machine_id}",
                code=err.code,
            )
        return RpcError(
            "Caller is not authorized to submit one or more machines in this batch",
            code=err.code,
        )
    if err.code == "InvalidEventType":
        return RpcError("Invalid event type", code=err.code)
    if err.code == "InvalidTrustLevel":
        return RpcError("Invalid trust level", code=err.code)
    return err


REQUIRED_EVENT_KEYS: Final[frozenset[str]] = frozenset({"currency"})
"""Per ticket PRO-336 §S3 — keys that batch dict input must set explicitly.

Other ``SubmitEventParams`` fields are required by the dataclass itself
(no defaults, so ``**raw`` unpacking already raises ``TypeError`` for
absence). This frozenset captures the additions on top of that — fields
that have a default (today: only ``currency`` via ``_OMITTED_CURRENCY``)
but must NOT be silently defaulted in batch mode. Adding a new
optional-with-sentinel field in the future just adds a name here.
"""


def _coerce_params(raw: SubmitEventParams | dict[str, object]) -> SubmitEventParams:
    """Normalise a dict payload into a :class:`SubmitEventParams` instance.

    Strict-required currency (PRO-336 §S3): batch mode rejects events
    where ``currency`` is absent (dict path) or left as the sentinel
    (direct ``SubmitEventParams`` path). Smart defaults are exclusive
    to the single-event ``submit_event`` ergonomic API. Other dataclass
    fields without defaults raise ``TypeError`` from ``**raw`` unpack
    if the dict omits them — that error propagates as-is rather than
    being remapped to ``ValidationError``; per-field rejection lives in
    the dataclass schema itself.
    """
    if isinstance(raw, SubmitEventParams):
        if raw.currency is _OMITTED_CURRENCY:
            raise ValidationError(
                field="currency",
                constraint="required (no smart default in batch mode)",
                message=(
                    "currency is required per event in batch_submit_events "
                    "(no smart default in batch mode; use single-event "
                    "submit_event for the omit-and-default ergonomics). "
                    "Construct SubmitEventParams with an explicit currency "
                    "('USD'/'HKD'/etc for revenue, '' for activity)."
                ),
                value=None,
            )
        return raw
    missing = REQUIRED_EVENT_KEYS - raw.keys()
    if missing:
        # Deterministic field= for stable error messages: pick the
        # lex-smallest missing key. ``min`` over the set is O(n) without
        # the ``sorted`` list allocation.
        first = min(missing)
        raise ValidationError(
            field=first,
            constraint="required key in batch event dict",
            message=(
                f"{first!r} is required per event in batch_submit_events; "
                "include it in the event dict (no smart default in batch mode)"
            ),
            value=None,
        )
    return SubmitEventParams(**raw)  # type: ignore[arg-type]


def _rollback_reserved_slots(reserved_usage_by_machine: dict[int, int], now: int) -> None:
    for machine_id, increment in reserved_usage_by_machine.items():
        for _ in range(increment):
            rate_limit_tracker.rollback_event(machine_id, now)


def batch_submit_events(
    client: PeaqosClient,
    events: list[SubmitEventParams | dict[str, object]],
) -> list[str]:
    """Submit multiple events atomically via the Batch precompile.

    Each item is validated and checked against operational limits before any
    transaction is sent. The SDK encodes each `submitEvent(...)` call, wraps all
    of them in one `batchAll(...)` transaction, and returns one hash per input
    event (all identical because batch execution is a single transaction).

    Args:
        client: Initialized SDK client with signer, contracts, and limits.
        events: Non-empty list of event payloads. Each item can be either:
            - `SubmitEventParams`, or
            - `dict[str, object]` with equivalent keys.

    Returns:
        list[str]: Transaction-hash list aligned to input order. Hash values are
        identical because the batch is one on-chain transaction.

    Raises:
        ValidationError: If `events` is empty or any item is schema-invalid.
        ValueCapExceeded: If any event exceeds `max_value_per_tx`.
        RateLimitExceeded: If projected batch counts exceed rate-limit settings.
        RpcError: If the batch transaction fails or mapped custom errors occur.

    Examples:
        >>> from peaq_os_sdk.types.events import SubmitEventParams
        >>> tx_hashes = batch_submit_events(
        ...     client,
        ...     [
        ...         SubmitEventParams(
        ...             machine_id=42,
        ...             event_type=1,
        ...             value=100,
        ...             timestamp=1_735_000_000,
        ...             raw_data=b"event-a",
        ...             trust_level=0,
        ...             source_chain_id=3338,
        ...             source_tx_hash=None,
        ...             metadata=b'{"kind":"a"}',
        ...         ),
        ...         SubmitEventParams(
        ...             machine_id=42,
        ...             event_type=1,
        ...             value=200,
        ...             timestamp=1_735_000_001,
        ...             raw_data=None,
        ...             trust_level=1,
        ...             source_chain_id=3338,
        ...             source_tx_hash="0x" + ("aa" * 32),
        ...             metadata=b'{"kind":"b","mode":"onchain"}',
        ...         ),
        ...     ],
        ... )
        >>> len(tx_hashes)
        2
        >>> len(set(tx_hashes)) == 1
        True
    """
    if len(events) == 0:
        raise ValidationError(
            field="events",
            constraint="non-empty list",
            message="events must contain at least one item",
            value=events,
        )

    if len(events) > 100:
        logger.warning(
            "batch_submit_events: received %d events. "
            "Batches above 100 may exceed block gas limits.",
            len(events),
        )

    limits_enabled = not _limits_disabled(client)
    now = int(time.time())
    projected_count_by_machine: dict[int, int] = {}
    usage_by_machine: dict[int, int] = {}
    reserved_usage_by_machine: dict[int, int] = {}

    to: list[str] = []
    value: list[int] = []
    call_data: list[str] = []
    gas_limit: list[int] = []

    for raw_params in events:
        params = _coerce_params(raw_params)
        validate_submit_event_params(params)

        if limits_enabled:
            baseline_count = projected_count_by_machine.get(params.machine_id)
            if baseline_count is None:
                tracker = _current_tracker(
                    params.machine_id,
                    client.operational_limits.rate_limit_window_seconds,
                    now,
                )
                baseline_count = 0 if tracker is None else tracker.count
            existing = (
                None
                if baseline_count == 0
                else EventTracker(
                    machine_id=params.machine_id,
                    count=baseline_count,
                    window_start=max(
                        0,
                        now - client.operational_limits.rate_limit_window_seconds,
                    ),
                )
            )
            check_operational_limits(params, client.operational_limits, existing)
            projected_count_by_machine[params.machine_id] = baseline_count + 1
            # Reserve in-flight slots immediately so concurrent batches cannot
            # bypass SDK-side rate limits before receipt resolution.
            rate_limit_tracker.record_event(params.machine_id, now)
            reserved_usage_by_machine[params.machine_id] = (
                reserved_usage_by_machine.get(params.machine_id, 0) + 1
            )

        data_hash = (
            compute_data_hash(params.raw_data) if params.raw_data is not None else _ZERO_BYTES32
        )
        source_tx_hash = params.source_tx_hash if params.source_tx_hash is not None else _ZERO_HEX32
        encoded = client.event_registry.functions.submitEvent(
            int(params.machine_id),
            int(params.event_type),
            int(params.value),
            params.currency,  # PRO-338: currency is the 4th positional arg.
            int(params.timestamp),
            data_hash,
            int(params.trust_level),
            int(params.source_chain_id),
            source_tx_hash,
            params.metadata,
        )._encode_transaction_data()

        to.append(client.contracts.event_registry)
        value.append(0)
        gas_limit.append(0)
        call_data.append(encoded)
        usage_by_machine[params.machine_id] = usage_by_machine.get(params.machine_id, 0) + 1

    try:
        receipt = send_and_await(
            client.web3,
            client.account,
            client.batch_precompile,
            "batchAll",
            args=[to, value, call_data, gas_limit],
        )
    except RpcError as err:
        _rollback_reserved_slots(reserved_usage_by_machine, now)
        batch_machine_ids = set(usage_by_machine.keys())
        raise _map_batch_error(err, batch_machine_ids) from err
    except Exception as err:
        _rollback_reserved_slots(reserved_usage_by_machine, now)
        raise err

    tx_hash_obj = receipt["transactionHash"]
    tx_hash = tx_hash_obj.hex() if hasattr(tx_hash_obj, "hex") else str(tx_hash_obj)
    return [tx_hash for _ in events]
