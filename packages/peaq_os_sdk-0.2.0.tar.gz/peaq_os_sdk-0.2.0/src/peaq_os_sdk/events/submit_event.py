"""Single event submission pipeline for EventRegistry.submitEvent."""

from __future__ import annotations

import time
from dataclasses import replace
from typing import TYPE_CHECKING

from ..exceptions.rpc_error import RpcError
from ..types.events import _OMITTED_CURRENCY, SubmitEventParams
from ..utils.data_hash import compute_data_hash
from ..utils.transaction import send_and_await
from ..validation.operational_limits import EventTracker, check_operational_limits
from ..validation.submit_event import validate_submit_event_params
from .rate_limit_tracker import rate_limit_tracker

if TYPE_CHECKING:
    from ..client import PeaqosClient

_ZERO_BYTES32 = bytes(32)
_ZERO_HEX32 = "0x" + ("0" * 64)


def _limits_disabled(client: PeaqosClient) -> bool:
    limits = client.operational_limits
    return (
        limits.max_value_per_tx == 0
        and limits.rate_limit_max_events == 0
        and limits.rate_limit_window_seconds == 0
    )


def _current_tracker(machine_id: int, window_seconds: int, now: int) -> EventTracker | None:
    count = rate_limit_tracker.get_event_count(machine_id, window_seconds)
    if count == 0:
        return None
    return EventTracker(
        machine_id=machine_id,
        count=count,
        window_start=max(0, now - window_seconds),
    )


def _map_submit_event_error(err: RpcError, machine_id: int) -> RpcError:
    if err.code in {"MachineNotFound"}:
        return RpcError(f"Machine ID {machine_id} does not exist", code=err.code)
    if err.code == "MachineNotBonded":
        return RpcError(f"Machine ID {machine_id} is not bonded", code=err.code)
    if err.code == "MachineDeactivated":
        return RpcError(f"Machine ID {machine_id} is deactivated", code=err.code)
    if err.code == "NotAuthorizedSubmitter":
        return RpcError(
            f"Caller is not authorized to submit events for machine {machine_id}",
            code=err.code,
        )
    if err.code == "InvalidEventType":
        return RpcError("Invalid event type", code=err.code)
    if err.code == "InvalidTrustLevel":
        return RpcError("Invalid trust level", code=err.code)
    return err


def submit_event(
    client: PeaqosClient,
    params: SubmitEventParams,
) -> tuple[str, bytes]:
    """Submit one event through the EventRegistry pipeline.

    BREAKING (PRO-334): ``params.value`` is reinterpreted as an ISO 4217
    subunit integer (e.g. ``HK$1.23`` → ``value=123, currency="HKD"``;
    ``¥100`` → ``value=100, currency="JPY"``). Partners are responsible
    for converting whole-currency-unit amounts into subunit integers
    before calling. ``float`` / ``Decimal`` / ``bool`` / ``str`` /
    ``None`` raise ``TypeError`` (this is a type-guard, not a value-shape
    guard, per Python idiom).

    The pipeline is:
    1) schema validation,
    2) optional operational-limit checks,
    3) data hashing (`keccak256(raw_data)` or `bytes32(0)`),
    4) transaction build/send/await.

    Args:
        client: Initialized SDK client with signer, contracts, and limits.
        params: Event payload to submit on-chain.

    Returns:
        tuple[str, bytes]: `(tx_hash, data_hash)` where:
            - `tx_hash` is the mined `0x` transaction hash string.
            - `data_hash` is the 32-byte hash submitted on-chain.

    Raises:
        TypeError: If ``params.value`` is not a strict ``int`` (PRO-334
            subunit convention — rejects ``bool``, ``float``, ``Decimal``,
            ``str``, ``None``, ``IntEnum``, ``numpy.int64``, etc.).
        ValidationError: If `params` violates submit-event schema constraints.
        ValueCapExceeded: If `params.value` exceeds `max_value_per_tx`.
        RateLimitExceeded: If the current rate-limit window is exhausted.
        RpcError: If contract/RPC execution fails, including mapped custom errors.

    Examples:
        >>> from peaq_os_sdk.types.events import SubmitEventParams
        >>> tx_hash, data_hash = submit_event(
        ...     client,
        ...     SubmitEventParams(
        ...         machine_id=42,
        ...         event_type=1,
        ...         value=100,
        ...         timestamp=1_735_000_000,
        ...         raw_data=b"sensor:ok",
        ...         trust_level=0,
        ...         source_chain_id=3338,
        ...         source_tx_hash=None,
        ...         metadata=b'{"mode":"self","schema":"v1"}',
        ...     ),
        ... )
        >>> tx_hash.startswith("0x")
        True
        >>> len(data_hash)
        32
    """
    # Smart default for the single-event path per ticket PRO-336 §6:
    # ``_OMITTED_CURRENCY`` (kwarg not provided by caller) resolves to
    # ``"USD"`` for revenue and ``""`` for activity. Explicit ``None``
    # falls through to validation, which rejects it. The batch path does
    # NOT apply this default — it lives only here so batch's strict-
    # required semantics are preserved.
    if params.currency is _OMITTED_CURRENCY:
        params = replace(params, currency="USD" if params.event_type == 0 else "")
    validate_submit_event_params(params)
    now = int(time.time())
    reserved_rate_limit_slot = False

    if not _limits_disabled(client):
        check_operational_limits(
            params,
            client.operational_limits,
            _current_tracker(
                params.machine_id,
                client.operational_limits.rate_limit_window_seconds,
                now,
            ),
        )
        # Reserve an in-flight slot immediately so concurrent submissions
        # cannot bypass SDK-side rate limits before receipt resolution.
        rate_limit_tracker.record_event(params.machine_id, now)
        reserved_rate_limit_slot = True

    data_hash = compute_data_hash(params.raw_data) if params.raw_data is not None else _ZERO_BYTES32
    source_tx_hash = params.source_tx_hash if params.source_tx_hash is not None else _ZERO_HEX32

    try:
        receipt = send_and_await(
            client.web3,
            client.account,
            client.event_registry,
            "submitEvent",
            args=[
                int(params.machine_id),
                int(params.event_type),
                int(params.value),
                params.currency,  # PRO-338: currency is the 4th positional arg
                int(params.timestamp),
                data_hash,
                int(params.trust_level),
                int(params.source_chain_id),
                source_tx_hash,
                params.metadata,
            ],
        )
    except RpcError as err:
        if reserved_rate_limit_slot:
            rate_limit_tracker.rollback_event(params.machine_id, now)
        raise _map_submit_event_error(err, params.machine_id) from err
    except Exception as err:
        if reserved_rate_limit_slot:
            rate_limit_tracker.rollback_event(params.machine_id, now)
        raise err

    tx_hash_obj = receipt["transactionHash"]
    tx_hash = tx_hash_obj.hex() if hasattr(tx_hash_obj, "hex") else str(tx_hash_obj)
    return (tx_hash, data_hash)
