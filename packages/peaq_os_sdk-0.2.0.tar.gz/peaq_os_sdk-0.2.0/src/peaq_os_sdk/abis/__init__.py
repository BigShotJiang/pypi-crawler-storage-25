"""ABI loader for peaqOS contract ABIs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_ABI_DIR = Path(__file__).parent


def load_abi(name: str) -> list[dict[str, Any]]:
    """Load a contract ABI JSON file by name.

    Args:
        name: Contract name without extension (e.g. ``"IdentityRegistry"``).

    Returns:
        Parsed ABI as a list of fragment dicts.

    Raises:
        FileNotFoundError: If the ABI file does not exist.
    """
    path = _ABI_DIR / f"{name}.json"
    with open(path, encoding="utf-8") as f:
        abi: list[dict[str, Any]] = json.load(f)
    return abi
