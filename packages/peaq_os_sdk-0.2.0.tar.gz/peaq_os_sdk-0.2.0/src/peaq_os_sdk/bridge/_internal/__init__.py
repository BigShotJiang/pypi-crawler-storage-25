"""Internal helpers for the bridge subpackage (not part of public API)."""
