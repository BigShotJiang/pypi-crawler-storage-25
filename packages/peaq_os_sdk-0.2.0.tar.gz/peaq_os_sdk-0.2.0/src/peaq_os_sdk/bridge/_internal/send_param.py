"""Canonical LayerZero-v2 ``SendParam`` tuple construction."""

from __future__ import annotations

SendParam = tuple[int, bytes, int, bytes, bytes, bytes]
"""Wire-order tuple: ``(dstEid, to, tokenId, extraOptions, composeMsg, onftCmd)``."""


def pad_address_to_bytes32(address: str) -> bytes:
    """Left-pad a ``0x``-prefixed 20-byte address to 32 bytes.

    LayerZero-v2 represents recipients as ``bytes32`` (12 zero bytes
    followed by the 20-byte address) so the same field can carry
    non-EVM addresses on other chains.

    Args:
        address: ``0x``-prefixed 40-hex-char Ethereum address.

    Returns:
        A 32-byte ``bytes`` value: 12 zero bytes + 20 address bytes.

    Raises:
        ValueError: If *address* is not a 20-byte hex address.
    """
    addr_hex = address.removeprefix("0x").removeprefix("0X")
    if len(addr_hex) != 40:
        raise ValueError(f"expected 20-byte address, got {address!r}")
    return bytes(12) + bytes.fromhex(addr_hex)


def build_send_param(
    dst_eid: int,
    recipient: str,
    token_id: int,
    options: bytes = b"",
) -> SendParam:
    """Construct the canonical ``SendParam`` tuple expected by ONFT ``send`` / ``quoteSend``.

    Args:
        dst_eid: LayerZero endpoint ID of the destination chain.
        recipient: Destination-chain recipient address.
        token_id: NFT being bridged.
        options: Raw ``extraOptions`` bytes (``b""`` defers to contract defaults).

    Returns:
        A 6-tuple in the order the Solidity struct declares.
    """
    return (
        dst_eid,
        pad_address_to_bytes32(recipient),
        token_id,
        options,
        b"",
        b"",
    )
