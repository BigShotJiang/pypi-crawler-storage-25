"""Parameter validation for cross-chain NFT bridging."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, TypeGuard

from ...exceptions import ValidationError

if TYPE_CHECKING:
    from ...client import PeaqosClient

_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
_VALID_CHAINS = ("peaq", "base")


def _is_strict_int(value: object) -> TypeGuard[int]:
    return isinstance(value, int) and not isinstance(value, bool)


def _validate_address(value: object, field: str) -> str:
    if not isinstance(value, str) or not _ADDRESS_RE.match(value):
        raise ValidationError(
            field=field,
            constraint="0x-prefixed 20-byte hex address",
            message=f"{field} must be a valid 0x-prefixed Ethereum address",
            value=value,
        )
    return value


def _validate_chain(value: object, field: str) -> str:
    if not isinstance(value, str) or value not in _VALID_CHAINS:
        raise ValidationError(
            field=field,
            constraint=f"one of {_VALID_CHAINS!r}",
            message=f"{field} must be one of {_VALID_CHAINS!r}",
            value=value,
        )
    return value


def _validate_positive_int(value: object, field: str) -> int:
    if not _is_strict_int(value) or value <= 0:
        raise ValidationError(
            field=field,
            constraint="positive integer",
            message=f"{field} must be a positive integer",
            value=value,
        )
    return value


def _validate_non_empty_str(value: object, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValidationError(
            field=field,
            constraint="non-empty string",
            message=f"{field} must be a non-empty string",
            value=value,
        )
    return value


class ValidatedBridgeParams:
    """Flat container holding every validated bridge parameter."""

    __slots__ = (
        "base_rpc_url",
        "destination",
        "recipient",
        "source",
        "source_nft_address",
        "token_id",
    )

    def __init__(
        self,
        *,
        token_id: int,
        source: str,
        destination: str,
        recipient: str,
        source_nft_address: str,
        base_rpc_url: str | None,
    ) -> None:
        self.token_id = token_id
        self.source = source
        self.destination = destination
        self.recipient = recipient
        self.source_nft_address = source_nft_address
        self.base_rpc_url = base_rpc_url


def validate_bridge_params(
    client: PeaqosClient,
    *,
    token_id: int,
    source: str,
    destination: str,
    recipient: str,
    base_rpc_url: str | None,
    base_nft_address: str | None,
) -> ValidatedBridgeParams:
    """Validate every parameter accepted by :func:`bridge_nft`.

    Enforces:

    * ``token_id`` is a positive integer.
    * ``source`` and ``destination`` are each ``"peaq"`` or ``"base"``.
    * ``source != destination``.
    * ``recipient`` is a valid EVM address.
    * When ``source == "peaq"``: the client must carry a
      ``machine_nft_adapter`` contract address.
    * When ``source == "base"``: both ``base_rpc_url`` and
      ``base_nft_address`` are required and validated.

    Args:
        client: Configured :class:`PeaqosClient`.
        token_id: NFT id being bridged.
        source: Origin chain (``"peaq"`` | ``"base"``).
        destination: Target chain (``"peaq"`` | ``"base"``).
        recipient: Destination-chain recipient address.
        base_rpc_url: Required only when ``source == "base"``.
        base_nft_address: Required only when ``source == "base"``.

    Returns:
        A :class:`ValidatedBridgeParams` holding the normalised values
        plus the source-chain NFT contract address that the caller
        should bind for the subsequent ``quoteSend`` / ``send`` calls.

    Raises:
        ValidationError: On any failed rule. ``field`` identifies which.
    """
    validated_token_id = _validate_positive_int(token_id, "token_id")
    validated_source = _validate_chain(source, "source")
    validated_destination = _validate_chain(destination, "destination")
    if validated_source == validated_destination:
        raise ValidationError(
            field="destination",
            constraint="different from source",
            message="source and destination must be different chains",
            value=validated_destination,
        )
    validated_recipient = _validate_address(recipient, "recipient")

    source_nft_address: str
    resolved_base_rpc_url: str | None
    if validated_source == "peaq":
        adapter = client.contracts.machine_nft_adapter
        if not adapter:
            raise ValidationError(
                field="machine_nft_adapter",
                constraint="required for peaq-side bridging",
                message=(
                    "PeaqosClient must be constructed with machine_nft_adapter "
                    "(or MACHINE_NFT_ADAPTER_ADDRESS env var) to bridge from peaq"
                ),
                value=None,
            )
        source_nft_address = str(adapter)
        resolved_base_rpc_url = None
    else:
        resolved_base_rpc_url = _validate_non_empty_str(base_rpc_url, "base_rpc_url")
        source_nft_address = _validate_address(base_nft_address, "base_nft_address")

    return ValidatedBridgeParams(
        token_id=validated_token_id,
        source=validated_source,
        destination=validated_destination,
        recipient=validated_recipient,
        source_nft_address=source_nft_address,
        base_rpc_url=resolved_base_rpc_url,
    )
