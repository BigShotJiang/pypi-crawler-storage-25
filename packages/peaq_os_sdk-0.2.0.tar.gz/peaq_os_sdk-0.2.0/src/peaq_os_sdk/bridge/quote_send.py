"""Estimate the native LayerZero messaging fee before a bridge ``send``."""

from __future__ import annotations

import logging
from typing import Any

from ..exceptions import RpcError
from ._internal.send_param import build_send_param

logger = logging.getLogger("peaq_os_sdk.bridge.quote_send")

INVALID_FEE_RESULT = "INVALID_FEE_RESULT"


def quote_send(
    contract: Any,
    dst_eid: int,
    recipient: str,
    token_id: int,
    options: bytes = b"",
) -> int:
    """Estimate the native fee (in wei) required by a bridge ``send`` call.

    Invokes the ONFT v2 view ``quoteSend(sendParam, payInLzToken=false)``
    on *contract* (either peaq-side ``MachineNFTAdapter`` or Base-side
    ``MachineNFTBase`` — both expose the same interface) and returns the
    native-fee component of the ``MessagingFee`` tuple.

    Args:
        contract: Bound ``web3.py`` contract instance with a
            ``quoteSend`` view function.
        dst_eid: LayerZero endpoint ID of the destination chain.
        recipient: Destination-chain recipient address.
        token_id: NFT being bridged.
        options: Raw LayerZero ``extraOptions`` bytes. ``b""`` defers
            to the contract's default executor options.

    Returns:
        The native fee required when submitting the matching ``send``.

    Raises:
        RpcError: With ``code="INVALID_FEE_RESULT"`` if ``quoteSend``
            returns a value that is not ``(uint256 nativeFee,
            uint256 lzTokenFee)``.
    """
    send_param = build_send_param(dst_eid, recipient, token_id, options)
    result: object = contract.functions.quoteSend(send_param, False).call()
    native_fee = _extract_native_fee(result)
    return native_fee


def _extract_native_fee(result: object) -> int:
    """Normalise ``(nativeFee, lzTokenFee)`` into a plain ``int``."""
    if isinstance(result, (tuple, list)) and len(result) == 2:
        native_fee = result[0]
    elif isinstance(result, dict) and "nativeFee" in result:
        native_fee = result["nativeFee"]
    elif hasattr(result, "nativeFee"):
        native_fee = result.nativeFee
    else:
        raise RpcError(
            "quoteSend returned a malformed MessagingFee",
            code=INVALID_FEE_RESULT,
        )

    if not isinstance(native_fee, int) or isinstance(native_fee, bool) or native_fee < 0:
        raise RpcError(
            "quoteSend returned a non-integer native fee",
            code=INVALID_FEE_RESULT,
        )
    return native_fee
