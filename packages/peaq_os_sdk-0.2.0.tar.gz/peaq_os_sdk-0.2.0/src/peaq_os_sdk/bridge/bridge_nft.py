"""Cross-chain NFT bridging between peaq and Base via LayerZero v2."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from web3 import Web3

from ..abis import load_abi
from ..constants import LAYERZERO_EIDS
from ..types.primitives import Hex32
from ..utils.transaction import send_and_await
from ._internal.send_param import build_send_param
from ._internal.validate_params import ValidatedBridgeParams, validate_bridge_params
from .quote_send import quote_send

if TYPE_CHECKING:
    from ..client import PeaqosClient

logger = logging.getLogger("peaq_os_sdk.bridge.bridge_nft")


def bridge_nft(
    client: PeaqosClient,
    token_id: int,
    source: str,
    destination: str,
    recipient: str,
    *,
    base_rpc_url: str | None = None,
    base_nft_address: str | None = None,
    options: bytes = b"",
) -> Hex32:
    """Bridge a Machine NFT between peaq and Base via LayerZero v2.

    peaq → Base calls ``MachineNFTAdapter.send`` on peaq — NFT is locked
    on peaq and minted on Base. Base → peaq calls ``MachineNFTBase.send``
    on Base — NFT is burned on Base and unlocked on peaq.

    The native LayerZero messaging fee is estimated via :func:`quote_send`
    first; the same amount is then attached as ``msg.value`` on the
    broadcast transaction so the message is correctly paid for.

    Args:
        client: Configured :class:`PeaqosClient`. For peaq→Base, the
            client must carry ``machine_nft_adapter``.
        token_id: Positive NFT id to bridge.
        source: Origin chain, ``"peaq"`` or ``"base"``.
        destination: Target chain, ``"peaq"`` or ``"base"``. Must differ.
        recipient: Destination-chain recipient address.
        base_rpc_url: Required only when ``source == "base"``.
        base_nft_address: Base-side ``MachineNFTBase`` address.
            Required only when ``source == "base"``.
        options: Raw LayerZero ``extraOptions`` bytes (``b""`` defers
            to the contract's default executor options).

    Returns:
        The source-chain transaction hash as a ``0x``-prefixed string.

    Raises:
        ValidationError: On any invalid parameter (see
            :func:`validate_bridge_params`).
        RpcError: On revert, fee-quote malformation, or transport
            failure on either chain.

    Example::

        tx = client.bridge_nft(
            token_id=42,
            source="peaq",
            destination="base",
            recipient="0xabc...",
        )
    """
    params = validate_bridge_params(
        client,
        token_id=token_id,
        source=source,
        destination=destination,
        recipient=recipient,
        base_rpc_url=base_rpc_url,
        base_nft_address=base_nft_address,
    )

    source_web3, source_contract = _resolve_source(client, params)
    dst_eid = LAYERZERO_EIDS[params.destination]

    if params.source == "peaq":
        adapter_address = source_web3.to_checksum_address(params.source_nft_address)
        nft_contract = source_web3.eth.contract(
            address=source_web3.to_checksum_address(client.contracts.machine_nft),
            abi=load_abi("MachineNFT"),
        )
        approved: str = nft_contract.functions.getApproved(params.token_id).call()
        if approved.lower() != adapter_address.lower():
            send_and_await(
                source_web3,
                client.account,
                nft_contract,
                "approve",
                args=[adapter_address, params.token_id],
            )

    native_fee = quote_send(
        source_contract,
        dst_eid,
        params.recipient,
        params.token_id,
        options=options,
    )

    send_param = build_send_param(
        dst_eid,
        params.recipient,
        params.token_id,
        options=options,
    )
    fee_tuple: tuple[int, int] = (native_fee, 0)
    refund_address = source_web3.to_checksum_address(client.address)

    receipt = send_and_await(
        source_web3,
        client.account,
        source_contract,
        "send",
        args=[send_param, fee_tuple, refund_address],
        value_wei=native_fee,
    )

    tx_hash_bytes = receipt["transactionHash"]
    if isinstance(tx_hash_bytes, (bytes, bytearray)):
        return Hex32("0x" + bytes(tx_hash_bytes).hex())
    if isinstance(tx_hash_bytes, str):
        return Hex32(tx_hash_bytes)
    raise TypeError(f"Unexpected transactionHash type: {type(tx_hash_bytes)!r}")


def _resolve_source(
    client: PeaqosClient,
    params: ValidatedBridgeParams,
) -> tuple[Web3, Any]:
    """Return the ``(web3, contract)`` pair to use on the source chain."""
    if params.source == "peaq":
        contract = client.web3.eth.contract(
            address=client.web3.to_checksum_address(params.source_nft_address),
            abi=load_abi("MachineNFTAdapter"),
        )
        return client.web3, contract

    assert params.base_rpc_url is not None  # guaranteed by validator
    base_web3 = Web3(Web3.HTTPProvider(params.base_rpc_url))
    contract = base_web3.eth.contract(
        address=base_web3.to_checksum_address(params.source_nft_address),
        abi=load_abi("MachineNFTBase"),
    )
    return base_web3, contract
