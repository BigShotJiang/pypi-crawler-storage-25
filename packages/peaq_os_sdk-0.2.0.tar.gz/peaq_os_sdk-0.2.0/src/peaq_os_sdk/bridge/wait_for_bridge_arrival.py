"""Poll the destination chain until a bridged NFT arrives (or timeout)."""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import Any, Final, Protocol

from web3 import Web3
from web3.exceptions import ContractLogicError

from ..abis import load_abi
from ..exceptions import ValidationError
from ._internal.validate_params import _validate_address  # reused pure validator

logger = logging.getLogger("peaq_os_sdk.bridge.wait_for_bridge_arrival")

POLL_INTERVAL_SECONDS: Final[int] = 10
"""Interval between successive ``ownerOf`` probes on the destination chain."""

DEFAULT_TIMEOUT_SECONDS: Final[int] = 300
"""Default arrival-wait budget (5 minutes)."""

MIN_TIMEOUT_SECONDS: Final[int] = 60
"""Min arrival-wait budget (1 minutes) to control user values in validation."""

_ZERO_ADDRESS = "0x" + "0" * 40

# Case-insensitive substrings that indicate the token does not yet exist
# on the destination — i.e. the LayerZero message has not arrived. Anything
# else surfaces to the caller.
_NONEXISTENT_TOKEN_MARKERS: tuple[str, ...] = (
    "nonexistent token",
    "invalid token id",
    "owner query for nonexistent token",
    "erc721: invalid token",
    "erc721nonexistenttoken",
)


class _Web3Factory(Protocol):
    def __call__(self, rpc_url: str) -> Web3: ...


def _default_web3_factory(rpc_url: str) -> Web3:
    return Web3(Web3.HTTPProvider(rpc_url))


def wait_for_bridge_arrival(
    dst_rpc_url: str,
    dst_nft_address: str,
    token_id: int,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    *,
    web3_factory: _Web3Factory = _default_web3_factory,
    sleep: Callable[[float], None] = time.sleep,
    now: Callable[[], float] = time.monotonic,
) -> bool:
    """Poll a destination-chain NFT contract until a bridged token arrives.

    Probes ``MachineNFT.ownerOf(token_id)`` every
    :data:`POLL_INTERVAL_SECONDS` seconds. Returns ``True`` as soon as
    the call succeeds with a non-zero owner (token arrived). Returns
    ``False`` when the total elapsed wait exceeds ``timeout``.

    Any RPC / infrastructure failure that is not a standard
    "nonexistent token" revert re-raises so callers can see the real
    cause instead of a false-negative timeout.

    Args:
        dst_rpc_url: RPC endpoint of the destination chain.
        dst_nft_address: ``MachineNFT`` address on the destination chain.
        token_id: The NFT id expected to arrive.
        timeout: Total wait budget in seconds. Defaults to 300.
        web3_factory: Internal test seam — override to inject a fake
            ``Web3`` instance.
        sleep: Internal test seam — override to avoid real sleeping.
        now: Internal test seam — override to drive the clock manually.

    Returns:
        ``True`` if the token arrived before the deadline, else ``False``.

    Raises:
        ValidationError: If any parameter fails validation.

    Example::

        arrived = PeaqosClient.wait_for_bridge_arrival(
            dst_rpc_url="https://base-mainnet.example.com",
            dst_nft_address="0x...",
            token_id=42,
        )
    """
    _validate_rpc_url(dst_rpc_url)
    validated_address = _validate_address(dst_nft_address, "dst_nft_address")
    validated_token_id = _validate_token_id(token_id)
    validated_timeout = _validate_bidge_timeout(timeout)

    web3 = web3_factory(dst_rpc_url)
    contract = web3.eth.contract(
        address=web3.to_checksum_address(validated_address),
        abi=load_abi("MachineNFT"),
    )

    deadline = now() + validated_timeout

    while True:
        if _probe_owner_of(contract, validated_token_id):
            return True

        remaining = deadline - now()
        if remaining <= 0:
            return False

        sleep(min(float(POLL_INTERVAL_SECONDS), remaining))


def _probe_owner_of(contract: Any, token_id: int) -> bool:
    """Return ``True`` iff ``ownerOf(token_id)`` resolves to a non-zero owner."""
    try:
        result: object = contract.functions.ownerOf(token_id).call()
    except ContractLogicError as err:
        if _is_nonexistent_token_error(err):
            return False
        raise
    except Exception as err:
        if _is_nonexistent_token_error(err):
            return False
        raise

    if not isinstance(result, str):
        return False
    return result != "" and result.lower() != _ZERO_ADDRESS


def _is_nonexistent_token_error(err: BaseException) -> bool:
    text = str(err).lower()
    return any(marker in text for marker in _NONEXISTENT_TOKEN_MARKERS)


def _validate_rpc_url(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise ValidationError(
            field="dst_rpc_url",
            constraint="non-empty string",
            message="dst_rpc_url must be a non-empty string",
            value=value,
        )
    return value


def _validate_token_id(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
        raise ValidationError(
            field="token_id",
            constraint="positive integer",
            message="token_id must be a positive integer",
            value=value,
        )
    return value


def _validate_bidge_timeout(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value <= MIN_TIMEOUT_SECONDS:
        raise ValidationError(
            field="timeout",
            constraint="positive integer (seconds)",
            message="timeout must be a positive integer (seconds)",
            value=value,
        )
    return value
