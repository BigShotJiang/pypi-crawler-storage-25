"""Operational limits checking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from ..exceptions.rate_limit_exceeded import RateLimitExceeded
from ..exceptions.value_cap_exceeded import ValueCapExceeded
from ..types.client import OperationalLimits


class _EventLike(Protocol):
    """Structural shape consumed by :func:`check_operational_limits`.

    Declared as ``@property`` so frozen dataclasses (``SubmitEventParams``)
    satisfy the protocol without mypy complaining about their fields
    being read-only.
    """

    @property
    def machine_id(self) -> int: ...

    @property
    def value(self) -> int: ...


@dataclass(frozen=True, slots=True)
class EventTracker:
    """Tracks event submission count within a rate-limit window.

    Args:
        machine_id: The machine being tracked.
        count: Current event count within the window.
        window_start: Unix timestamp when the window started.

    Example:
        >>> tracker = EventTracker(machine_id=1, count=5, window_start=1700000000)
    """

    machine_id: int
    count: int
    window_start: float


def check_operational_limits(
    params: _EventLike,
    limits: OperationalLimits,
    tracker: EventTracker | None,
) -> None:
    """Check a proposed event submission against operational limits.

    Args:
        params: Object with ``machine_id`` (int) and ``value`` (int) attrs.
        limits: The configured operational limits.
        tracker: Current event count tracker, or None if no tracking.

    Raises:
        ValueCapExceeded: When value exceeds ``max_value_per_tx``.
        RateLimitExceeded: When event count exceeds ``rate_limit_max_events`` within window.

    Example:
        >>> from peaq_os_sdk.types.client import OperationalLimits
        >>> check_operational_limits(
        ...     type("P", (), {"machine_id": 1, "value": 100})(),
        ...     OperationalLimits(max_value_per_tx=1000),
        ...     None,
        ... )
    """
    machine_id: int = params.machine_id
    value: int = params.value

    if limits.max_value_per_tx > 0 and value > limits.max_value_per_tx:
        raise ValueCapExceeded(value=value, cap=limits.max_value_per_tx)

    if (
        limits.rate_limit_max_events > 0
        and limits.rate_limit_window_seconds > 0
        and tracker is not None
        and tracker.count >= limits.rate_limit_max_events
    ):
        raise RateLimitExceeded(
            machine_id=machine_id,
            count=tracker.count,
            max_events=limits.rate_limit_max_events,
            window_seconds=limits.rate_limit_window_seconds,
        )
