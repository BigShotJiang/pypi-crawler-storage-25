"""Validation for event submission parameters."""

from __future__ import annotations

from ..constants import SUPPORTED_CHAINS
from ..exceptions.validation_error import ValidationError
from ..types.events import _OMITTED_CURRENCY, _REVENUE_CURRENCY_RE, SubmitEventParams

_VALID_EVENT_TYPES = frozenset({0, 1})
_VALID_TRUST_LEVELS = frozenset({0, 1, 2})
_VALID_CHAIN_IDS = frozenset({0, *SUPPORTED_CHAINS.values()})

# PRO-334: subunit type-guard message — verbatim from
# ~/vibe02/peaqos-mcs/docs/internal/changelogs/PRO-334.md item 1.
# Placeholder name `{type}` matches the changelog template exactly so a
# future reader cross-referencing the source can grep both sides.
_VALUE_TYPE_GUARD_MESSAGE = (
    "value must be a subunit integer (e.g. HK$1.23 → value=123, "
    "currency='HKD'); got {type}. Use ISO 4217 minor units; partner is "
    "responsible for conversion."
)


def _validate_value_type(value: object) -> None:
    """Reject non-strict-int ``value`` per PRO-334 ISO 4217 subunit convention.

    ``type(value) is int`` is intentionally **stricter** than the repo's
    sibling ``_is_strict_int`` helper (in ``bridge/_internal``,
    ``smart_account/_internal``, ``query/_internal``), which uses
    ``isinstance(value, int) and not isinstance(value, bool)`` — that
    rejects ``bool`` but still accepts ``IntEnum`` and ``numpy.int64``.
    PRO-334 ticket §B7 sdk-py AC explicitly requires rejecting any
    ``int`` subclass beyond plain ``int`` (``IntEnum``, ``numpy.int64``,
    etc.) so that subunit semantics survive cross-language wire
    serialization without ambiguity. Hence this helper diverges by
    design.

    This is a type-guard, not a value-shape guard, so it raises
    ``TypeError`` per Python idiom (ticket §B Q7) — ``ValidationError``
    stays reserved for value-shape rejections (currency regex,
    machine_id <= 0, etc.).

    Accepts: plain ``int`` only (including negative). Sign and magnitude
    are validated separately by the ``value < 0`` check downstream and
    by ``check_operational_limits`` for ``max_value_per_tx``.
    """
    if type(value) is not int:
        raise TypeError(_VALUE_TYPE_GUARD_MESSAGE.format(type=type(value).__name__))


def validate_submit_event_params(params: SubmitEventParams) -> None:
    """Validate all fields of a SubmitEventParams object.

    Raises a ValidationError on the first invalid field.

    Args:
        params: The event submission parameters to validate.

    Raises:
        ValidationError: When any field violates its constraint.

    Example:
        >>> from peaq_os_sdk.types.events import SubmitEventParams
        >>> validate_submit_event_params(SubmitEventParams(
        ...     machine_id=1, event_type=0, value=100, timestamp=1700000000,
        ...     raw_data=b"data", trust_level=0, source_chain_id=3338,
        ...     source_tx_hash=None, metadata=b"",
        ... ))
    """
    if not isinstance(params.machine_id, int) or params.machine_id <= 0:
        raise ValidationError(
            field="machine_id",
            constraint="> 0",
            message="machine_id must be a positive integer",
            value=params.machine_id,
        )

    if params.event_type not in _VALID_EVENT_TYPES:
        raise ValidationError(
            field="event_type",
            constraint="0 or 1",
            message="event_type must be 0 or 1",
            value=params.event_type,
        )

    _validate_value_type(params.value)

    if params.value < 0:
        raise ValidationError(
            field="value",
            constraint=">= 0",
            message="value must be non-negative",
            value=params.value,
        )

    if params.trust_level not in _VALID_TRUST_LEVELS:
        raise ValidationError(
            field="trust_level",
            constraint="0, 1, or 2",
            message="trust_level must be 0, 1, or 2",
            value=params.trust_level,
        )

    if params.source_chain_id not in _VALID_CHAIN_IDS:
        raise ValidationError(
            field="source_chain_id",
            constraint="supported chain",
            message="source_chain_id must be a supported chain ID (0, 3338, or 8453)",
            value=params.source_chain_id,
        )

    if params.raw_data is not None and len(params.raw_data) == 0:
        raise ValidationError(
            field="raw_data",
            constraint="non-empty",
            message="raw_data must not be empty when provided",
            value=params.raw_data,
        )

    if params.source_tx_hash is not None and len(params.source_tx_hash) != 66:
        raise ValidationError(
            field="source_tx_hash",
            constraint="32 bytes",
            message="source_tx_hash must be a 0x-prefixed 32-byte hex string (66 chars)",
            value=params.source_tx_hash,
        )

    if not isinstance(params.timestamp, int) or params.timestamp <= 0:
        raise ValidationError(
            field="timestamp",
            constraint="> 0",
            message="timestamp must be a positive integer",
            value=params.timestamp,
        )

    if params.trust_level == 1 and params.source_tx_hash is None:
        raise ValidationError(
            field="source_tx_hash",
            constraint="required when trust_level is 1",
            message="source_tx_hash is required when trust_level is 1 (on-chain verifiable)",
            value=params.source_tx_hash,
        )

    _validate_currency(params)


def _validate_currency(params: SubmitEventParams) -> None:
    """Validate the ``currency`` field per ticket PRO-336 §6.

    The single-event ``submit_event`` resolves ``_OMITTED_CURRENCY`` to a
    concrete string before reaching validation, so a sentinel value here
    is treated as "smart-default deferred" (silently accepted). The
    strict-required rule for ``batch_submit_events`` is enforced one
    layer up at the dict-parse layer in S3 (per ticket §4/S3); validation
    here stays scoped to the §6 explicit-null and shape rules so this
    subtask does not silently change batch behaviour.

    Raises:
        ValidationError: ``field="currency"`` for explicit-null and
            shape-mismatch caller states.
    """
    c = params.currency
    if c is _OMITTED_CURRENCY:
        # Sentinel: single-event path resolves before reaching here.
        # Batch path forwards the sentinel; S3 will add an explicit
        # dict-level required check before this layer runs. Pass through
        # silently so S2 does not retroactively tighten batch.
        return
    if c is None:
        # Per §6 explicit-null rule: never auto-defaulted, always rejected.
        raise ValidationError(
            field="currency",
            constraint="must be a string (None forbidden)",
            message=(
                "currency must not be None; omit the kwarg to use the smart "
                "default (single-event only) or pass an explicit string"
            ),
            value=c,
        )
    if params.event_type == 0:
        if not _REVENUE_CURRENCY_RE.match(c):
            raise ValidationError(
                field="currency",
                constraint="^[A-Z0-9]{3,10}$",
                message=(
                    "revenue events require currency matching ^[A-Z0-9]{3,10}$ "
                    "(uppercase alphanumeric, 3-10 chars)"
                ),
                value=c,
            )
    elif params.event_type == 1 and c != "":
        raise ValidationError(
            field="currency",
            constraint='must be ""',
            message="activity events require an empty currency string",
            value=c,
        )
