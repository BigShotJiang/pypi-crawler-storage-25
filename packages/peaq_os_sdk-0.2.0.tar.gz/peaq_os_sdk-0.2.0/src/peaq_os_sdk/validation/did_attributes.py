"""Validation for DID attribute write parameters."""

from __future__ import annotations

from ..constants import (
    DATA_VISIBILITY_ONCHAIN,
    DATA_VISIBILITY_PRIVATE,
    DATA_VISIBILITY_PUBLIC,
    DID_MAX_VALUE_BYTES,
)
from ..exceptions import ValidationError

_VALID_VISIBILITIES = {DATA_VISIBILITY_PUBLIC, DATA_VISIBILITY_PRIVATE, DATA_VISIBILITY_ONCHAIN}


def _validate_did_value(field: str, value: str) -> None:
    """Assert value is ASCII and within the DID byte-length cap."""
    try:
        encoded = value.encode("ascii")
    except UnicodeEncodeError as err:
        raise ValidationError(
            field=field,
            constraint="ASCII string",
            message=f"{field} must contain only ASCII characters",
            value=value,
        ) from err

    if len(encoded) > DID_MAX_VALUE_BYTES:
        raise ValidationError(
            field=field,
            constraint=f"at most {DID_MAX_VALUE_BYTES} bytes",
            message=f"{field} must be at most {DID_MAX_VALUE_BYTES} bytes",
            value=value,
        )


def validate_machine_did_attrs(
    machine_id: int,
    nft_token_id: int,
    operator_did: str,
    documentation_url: str,
    data_api: str,
    data_visibility: str,
) -> None:
    """Validate all parameters for :func:`write_machine_did_attributes`.

    Args:
        machine_id: Must be a positive integer.
        nft_token_id: Must be a positive integer.
        operator_did: Operator DID reference. May be empty; if non-empty,
            must be ASCII and ≤ ``DID_MAX_VALUE_BYTES`` bytes.
        documentation_url: Documentation URL. Must be non-empty, ASCII,
            and ≤ ``DID_MAX_VALUE_BYTES`` bytes.
        data_api: Data API endpoint. Must be non-empty, ASCII,
            and ≤ ``DID_MAX_VALUE_BYTES`` bytes.
        data_visibility: Must be one of ``"public"``, ``"private"``,
            or ``"onchain"``.

    Raises:
        ValidationError: On the first failing constraint, identifying
            the ``field``, ``constraint``, and invalid ``value``.
    """
    if machine_id <= 0:
        raise ValidationError(
            field="machine_id",
            constraint="positive integer",
            message="machine_id must be a positive integer",
            value=machine_id,
        )

    if nft_token_id <= 0:
        raise ValidationError(
            field="nft_token_id",
            constraint="positive integer",
            message="nft_token_id must be a positive integer",
            value=nft_token_id,
        )

    if data_visibility not in _VALID_VISIBILITIES:
        raise ValidationError(
            field="data_visibility",
            constraint=f"one of {sorted(_VALID_VISIBILITIES)}",
            message=f"data_visibility must be one of {sorted(_VALID_VISIBILITIES)}",
            value=data_visibility,
        )

    for field_name, field_value in (
        ("documentation_url", documentation_url),
        ("data_api", data_api),
    ):
        if not field_value:
            raise ValidationError(
                field=field_name,
                constraint="non-empty string",
                message=f"{field_name} must not be empty",
                value=field_value,
            )
        _validate_did_value(field_name, field_value)

    _validate_did_value("operator_did", operator_did)


def validate_proxy_did_attrs(
    proxy_machine_id: int,
    machine_ids: list[int],
) -> None:
    """Validate all parameters for :func:`write_proxy_did_attributes`.

    Args:
        proxy_machine_id: Must be a positive integer.
        machine_ids: Non-empty list of positive integers. The JSON-encoded
            list must be ≤ ``DID_MAX_VALUE_BYTES`` bytes.

    Raises:
        ValidationError: On the first failing constraint.
    """
    import json

    if proxy_machine_id <= 0:
        raise ValidationError(
            field="proxy_machine_id",
            constraint="positive integer",
            message="proxy_machine_id must be a positive integer",
            value=proxy_machine_id,
        )

    if not machine_ids:
        raise ValidationError(
            field="machine_ids",
            constraint="non-empty list",
            message="machine_ids must not be empty",
            value=machine_ids,
        )

    for idx, mid in enumerate(machine_ids):
        if mid <= 0:
            raise ValidationError(
                field=f"machine_ids[{idx}]",
                constraint="positive integer",
                message=f"machine_ids[{idx}] must be a positive integer",
                value=mid,
            )

    encoded = json.dumps(machine_ids).encode("ascii")
    if len(encoded) > DID_MAX_VALUE_BYTES:
        raise ValidationError(
            field="machine_ids",
            constraint=f"JSON-encoded value at most {DID_MAX_VALUE_BYTES} bytes",
            message=f"machine_ids JSON encoding exceeds {DID_MAX_VALUE_BYTES} bytes",
            value=machine_ids,
        )
