"""Fetch the fleet of machines managed by a proxy operator."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..types.queries import OperatorMachinesResponse
from ._internal.did import validate_did
from ._internal.response_guards import guard_operator_machines_response
from .http_client import build_url, get_json

if TYPE_CHECKING:
    from ..client import PeaqosClient


def query_operator_machines(
    client: PeaqosClient,
    did: str,
) -> OperatorMachinesResponse:
    """Fetch the fleet of machines managed by a proxy operator.

    Sends ``GET {client.api_url}/operator/{did}/machines`` and returns
    the validated ``{operator_did, machines}`` shape. Each entry in the
    ``machines`` list is individually shape-checked and surfaces in
    snake_case (``machine_id``, ``mcr_score``, ``mcr``).

    Args:
        client: Configured :class:`PeaqosClient` — only ``api_url`` and
            ``session`` are used.
        did: Operator DID. Must start with ``did:peaq:0x``.

    Returns:
        An :class:`OperatorMachinesResponse` TypedDict with
        ``operator_did`` and a ``machines`` list (possibly empty).

    Raises:
        ValidationError: If ``did`` does not start with ``did:peaq:0x``.
        ApiError: With ``code="NOT_FOUND"`` on HTTP 404,
            ``"SERVICE_UNAVAILABLE"`` on HTTP 503,
            ``"SERVER_ERROR"`` on other 5xx,
            ``"HTTP_ERROR"`` on other non-2xx,
            ``"BAD_RESPONSE"`` on malformed body,
            ``"TIMEOUT"`` on timeout, or ``"NETWORK_ERROR"`` on a
            transport failure.

    Example::

        fleet = query_operator_machines(client, "did:peaq:0xabc...")
        for m in fleet["machines"]:
            print(m["machine_id"], m["mcr_score"], m["mcr"])
    """
    validated_did = validate_did(did)
    url = build_url(client.api_url, f"/operator/{validated_did}/machines")
    body = get_json(client.session, url, operation="query_operator_machines")
    return guard_operator_machines_response(body, operation="query_operator_machines")
