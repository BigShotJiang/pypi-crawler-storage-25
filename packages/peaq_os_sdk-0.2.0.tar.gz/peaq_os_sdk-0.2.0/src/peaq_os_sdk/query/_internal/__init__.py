"""Internal helpers for the query subpackage (not part of public API)."""
