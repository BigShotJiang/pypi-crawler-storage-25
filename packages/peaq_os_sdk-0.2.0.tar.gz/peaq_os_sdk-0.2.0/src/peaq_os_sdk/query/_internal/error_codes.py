"""Stable ``ApiError.code`` sentinels for MCR HTTP client failures."""

from __future__ import annotations

from typing import Final

NOT_FOUND: Final[str] = "NOT_FOUND"
"""HTTP 404 — resource (machine / operator) not found."""

SERVICE_UNAVAILABLE: Final[str] = "SERVICE_UNAVAILABLE"
"""HTTP 503 — MCR API server is temporarily unavailable."""

SERVER_ERROR: Final[str] = "SERVER_ERROR"
"""HTTP 5xx (excluding 503) — server-side failure."""

HTTP_ERROR: Final[str] = "HTTP_ERROR"
"""Non-2xx response that does not match any of the more specific codes."""

BAD_RESPONSE: Final[str] = "BAD_RESPONSE"
"""Response parsed successfully but its shape does not match the contract."""

NETWORK_ERROR: Final[str] = "NETWORK_ERROR"
"""Transport-level failure (DNS, connection refused, TLS, etc.)."""

TIMEOUT: Final[str] = "TIMEOUT"
"""Request exceeded the configured per-call timeout."""
