"""Type guards that narrow untrusted MCR-API JSON into typed response dicts.

Every guard raises :class:`peaq_os_sdk.exceptions.ApiError` with
``code="BAD_RESPONSE"`` when the upstream body does not match the
documented shape, so query modules never have to hand-check dicts.
"""

from __future__ import annotations

from typing import Any, Final, TypeGuard, cast

from ...exceptions import ApiError
from ...types.events import _REVENUE_CURRENCY_RE
from ...types.queries import (
    AMOUNT_STATUS_VALUES,
    BOND_STATUSES,
    MCR_MAX,
    MCR_MIN,
    MCR_RATINGS,
    REVENUE_TRENDS,
    USD_SUBUNIT_INVARIANT,
    AmountStatus,
    EventEntry,
    MachineProfileResponse,
    MCRResponse,
    OperatorMachine,
    OperatorMachinesResponse,
    Pagination,
    PeaqosData,
)
from .error_codes import BAD_RESPONSE

_VALID_MCR_VALUES: Final[frozenset[str]] = frozenset(MCR_RATINGS) | {"Provisioned"}


def _bad(operation: str) -> ApiError:
    """Shared ``BAD_RESPONSE`` error for malformed MCR-API bodies."""
    return ApiError(
        f"{operation}: MCR API returned a malformed response body",
        code=BAD_RESPONSE,
    )


def _is_object(x: object) -> TypeGuard[dict[str, Any]]:
    """JSON object narrowing — dict and not a list."""
    return isinstance(x, dict)


def _is_int(x: object) -> TypeGuard[int]:
    """Strict int — rejects ``bool`` (which is an ``int`` subclass)."""
    return isinstance(x, int) and not isinstance(x, bool)


def _is_non_negative_int(x: object) -> TypeGuard[int]:
    return _is_int(x) and x >= 0


def _is_mcr_score(x: object) -> TypeGuard[int]:
    return _is_int(x) and MCR_MIN <= x <= MCR_MAX


def _is_numeric(x: object) -> TypeGuard[float]:
    """Accepts int or float, rejects bool."""
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def guard_mcr_response(body: object, operation: str = "query_mcr") -> MCRResponse:
    """Narrow an unknown JSON body to a typed :class:`MCRResponse`.

    Args:
        body: JSON-decoded HTTP response body.
        operation: Caller name, surfaced inside the error message.

    Returns:
        A :class:`MCRResponse` TypedDict ready to return to the caller.

    Raises:
        ApiError: With ``code="BAD_RESPONSE"`` if any field is missing,
            has the wrong type, or is out of range.
    """
    if not _is_object(body):
        raise _bad(operation)

    did = body.get("did")
    machine_id = body.get("machine_id")
    mcr_score = body.get("mcr_score")
    mcr = body.get("mcr")
    bond_status = body.get("bond_status")
    negative_flag = body.get("negative_flag")
    event_count = body.get("event_count")
    revenue_event_count = body.get("revenue_event_count")
    activity_event_count = body.get("activity_event_count")
    revenue_trend = body.get("revenue_trend")
    total_revenue = body.get("total_revenue")
    average_revenue_per_event = body.get("average_revenue_per_event")
    last_updated = body.get("last_updated")
    mcr_degraded = body.get("mcr_degraded")

    if not isinstance(did, str) or not did:
        raise _bad(operation)
    if not _is_non_negative_int(machine_id):
        raise _bad(operation)
    if mcr_score is None:
        mcr_score = 0
    elif not _is_mcr_score(mcr_score):
        raise _bad(operation)
    if not isinstance(mcr, str) or mcr not in _VALID_MCR_VALUES:
        raise _bad(operation)
    if not isinstance(bond_status, str) or bond_status not in BOND_STATUSES:
        raise _bad(operation)
    if not isinstance(negative_flag, bool):
        raise _bad(operation)
    if not _is_non_negative_int(event_count):
        raise _bad(operation)
    if not _is_non_negative_int(revenue_event_count):
        raise _bad(operation)
    if not _is_non_negative_int(activity_event_count):
        raise _bad(operation)
    if not isinstance(revenue_trend, str) or revenue_trend not in REVENUE_TRENDS:
        raise _bad(operation)
    if not _is_numeric(total_revenue):
        raise _bad(operation)
    if not _is_numeric(average_revenue_per_event):
        raise _bad(operation)
    if last_updated is not None and not _is_non_negative_int(last_updated):
        raise _bad(operation)
    # PRO-336 §S6 / PRO-331 — strict bool check (rejects truthy strings
    # like "false" that would otherwise pass an `if mcr_degraded:` test).
    if not isinstance(mcr_degraded, bool):
        raise _bad(operation)

    return MCRResponse(
        did=did,
        machine_id=machine_id,
        mcr_score=mcr_score,
        mcr=mcr,
        bond_status=bond_status,
        negative_flag=negative_flag,
        event_count=event_count,
        revenue_event_count=revenue_event_count,
        activity_event_count=activity_event_count,
        revenue_trend=revenue_trend,
        total_revenue=total_revenue,
        average_revenue_per_event=average_revenue_per_event,
        last_updated=last_updated,
        mcr_degraded=mcr_degraded,
    )


_VALID_EVENT_TYPES_RESPONSE: Final[frozenset[int]] = frozenset({0, 1})
"""Event types accepted by the response parser. Mirrors the contract's
``InvalidEventType`` revert: only revenue (0) and activity (1). Unknown
event types from the API surface as ``BAD_RESPONSE`` rather than being
silently treated as activity (which is what a missing ``et == 0`` branch
would do for any future ``et >= 2`` value)."""

_AMOUNT_STATUS_ALLOWLIST: Final[frozenset[str]] = frozenset(AMOUNT_STATUS_VALUES)
"""PRO-334 ``amount_status`` allowlist — strict enum check on the wire."""

_MISSING: Final[object] = object()
"""Sentinel for ``dict.get`` — distinguishes "key absent" from
"key present with explicit ``None``". Required because PRO-334
``origin_subunit`` is legitimately ``None`` for unsupported currencies,
so plain ``.get(key)`` returning ``None`` is ambiguous."""


def _guard_event_entries(entries: list[object], operation: str) -> list[EventEntry]:
    """Narrow an `event_data` list to typed `EventEntry` records.

    Per PRO-336 §S5 + §7 AC and PRO-334 §B7 sdk-py the parser:

    * Reads only the new schema; pre-PRO-336 / pre-PRO-334 raw keys
      (``value`` / ``currency`` / ``value_usd`` / ``value_usd_cents`` /
      ``currency_subunit``) are silently dropped — forward-only by
      design.
    * Rejects unknown ``event_type`` values (anything other than 0 or 1)
      with ``BAD_RESPONSE``.
    * Revenue events (``event_type == 0``) require all of:
      ``origin_currency`` (str, 3-10 chars matching the contract
      ``_isValidCurrencyShape``), ``usd_value`` (non-negative int —
      PRO-334 USD cents semantic), ``origin_subunit`` (positive int OR
      ``None`` when partner currency is unsupported), ``usd_subunit``
      (strict ``=== 100`` invariant per PRO-334 §B Q9), and
      ``amount_status`` (allowlist enum). Any missing / wrong-type /
      out-of-range field raises ``BAD_RESPONSE``.
    * Activity events (``event_type == 1``) omit ALL conditional fields
      so consumers can detect "no FX semantics" via key absence.
    """
    result: list[EventEntry] = []
    for entry in entries:
        if not _is_object(entry):
            raise _bad(operation)
        et = entry.get("event_type")
        ov = entry.get("origin_value")
        ts = entry.get("timestamp")
        tl = entry.get("trust_level")
        md = entry.get("metadata")
        if not _is_int(et) or not _is_int(ov) or not _is_int(ts) or not _is_int(tl):
            raise _bad(operation)
        if et not in _VALID_EVENT_TYPES_RESPONSE:
            raise _bad(operation)
        if not _is_object(md):
            raise _bad(operation)
        new_entry: EventEntry = EventEntry(
            event_type=et,
            origin_value=ov,
            timestamp=ts,
            trust_level=tl,
            metadata=dict(md),
        )
        if et == 0:
            oc = entry.get("origin_currency")
            uv = entry.get("usd_value", _MISSING)
            # Trailing underscore avoids shadowing the ``os`` stdlib module.
            os_ = entry.get("origin_subunit", _MISSING)
            us = entry.get("usd_subunit", _MISSING)
            ast = entry.get("amount_status", _MISSING)
            # Shape match mirrors the contract ``_isValidCurrencyShape``
            # (3-10 uppercase alphanumeric); rejecting len-OK-but-bad-charset
            # values like ``"abc!@#"`` keeps the read side symmetric with
            # the write side's validation in submit_event. Shared regex
            # source: ``types.events._REVENUE_CURRENCY_RE``.
            # ``_is_non_negative_int`` rejects negative USD amounts and bools.
            if not isinstance(oc, str) or not _REVENUE_CURRENCY_RE.match(oc):
                raise _bad(operation)
            # PRO-334: usd_value is non-negative int OR explicit null (when
            # amount_status != "ok"). Key absence is BAD_RESPONSE — server
            # contract guarantees presence for all revenue events.
            if uv is _MISSING:
                raise _bad(operation)
            if uv is not None and not _is_non_negative_int(uv):
                raise _bad(operation)
            # PRO-334: origin_subunit is positive int OR null. Missing key
            # is BAD_RESPONSE — server contract guarantees presence.
            if os_ is _MISSING:
                raise _bad(operation)
            if os_ is not None and not (_is_int(os_) and os_ > 0):
                raise _bad(operation)
            # PRO-334 §B Q9: usd_subunit invariant === 100. Strict check
            # so a future server change surfaces immediately.
            if us is _MISSING or not _is_int(us) or us != USD_SUBUNIT_INVARIANT:
                raise _bad(operation)
            # PRO-334: amount_status allowlist enum.
            if not isinstance(ast, str) or ast not in _AMOUNT_STATUS_ALLOWLIST:
                raise _bad(operation)
            new_entry["origin_currency"] = oc
            new_entry["usd_value"] = uv
            new_entry["origin_subunit"] = os_
            new_entry["usd_subunit"] = us
            # ast was just narrowed to a member of the allowlist; cast
            # to the AmountStatus alias so EventEntry's TypedDict accepts it.
            new_entry["amount_status"] = cast(AmountStatus, ast)
        # Activity (et == 1): all conditional fields omitted entirely —
        # key absence is the contract per PRO-336 §7 AC + PRO-334 §B7.
        result.append(new_entry)
    return result


def guard_machine_profile_response(
    body: object,
    operation: str = "query_machine",
) -> MachineProfileResponse:
    """Narrow an unknown JSON body to a typed :class:`MachineProfileResponse`.

    Args:
        body: JSON-decoded HTTP response body.
        operation: Caller name, surfaced inside the error message.

    Returns:
        A :class:`MachineProfileResponse` TypedDict with all required
        ``peaqos`` fields validated and optional conditional fields
        copied when present.

    Raises:
        ApiError: With ``code="BAD_RESPONSE"`` if any required field is
            missing, has the wrong type, or is out of range.
    """
    if not _is_object(body):
        raise _bad(operation)

    schema_version = body.get("schema_version")
    name = body.get("name")
    peaqos_raw = body.get("peaqos")

    if not isinstance(schema_version, str) or not schema_version:
        raise _bad(operation)
    if not isinstance(name, str):
        raise _bad(operation)
    if not _is_object(peaqos_raw):
        raise _bad(operation)

    machine_id = peaqos_raw.get("machine_id")
    did = peaqos_raw.get("did")
    operator = peaqos_raw.get("operator")
    mcr = peaqos_raw.get("mcr")
    mcr_score = peaqos_raw.get("mcr_score")
    bond_status = peaqos_raw.get("bond_status")
    negative_flag = peaqos_raw.get("negative_flag")
    event_count = peaqos_raw.get("event_count")
    data_visibility = peaqos_raw.get("data_visibility")
    documentation_url = peaqos_raw.get("documentation_url")

    if not _is_non_negative_int(machine_id):
        raise _bad(operation)
    if not isinstance(did, str) or not did:
        raise _bad(operation)
    if operator is not None and not isinstance(operator, str):
        raise _bad(operation)
    if not isinstance(mcr, str) or mcr not in _VALID_MCR_VALUES:
        raise _bad(operation)
    if mcr_score is None:
        mcr_score = 0
    elif not _is_mcr_score(mcr_score):
        raise _bad(operation)
    if not isinstance(bond_status, str) or bond_status not in BOND_STATUSES:
        raise _bad(operation)
    if not isinstance(negative_flag, bool):
        raise _bad(operation)
    if not _is_non_negative_int(event_count):
        raise _bad(operation)
    if not isinstance(data_visibility, str) or not data_visibility:
        raise _bad(operation)
    if documentation_url is not None and not isinstance(documentation_url, str):
        raise _bad(operation)

    peaqos = PeaqosData(
        machine_id=machine_id,
        did=did,
        operator=operator,
        mcr=mcr,
        mcr_score=mcr_score,
        bond_status=bond_status,
        negative_flag=negative_flag,
        event_count=event_count,
        data_visibility=data_visibility,
        documentation_url=documentation_url,
    )

    if "data_api" in peaqos_raw and isinstance(peaqos_raw["data_api"], str):
        peaqos["data_api"] = peaqos_raw["data_api"]
    if "event_data" in peaqos_raw and isinstance(peaqos_raw["event_data"], list):
        peaqos["event_data"] = _guard_event_entries(peaqos_raw["event_data"], operation)
    if "partner_data" in peaqos_raw and _is_object(peaqos_raw["partner_data"]):
        peaqos["partner_data"] = dict(peaqos_raw["partner_data"])
    if "partner_data_error" in peaqos_raw and isinstance(peaqos_raw["partner_data_error"], str):
        peaqos["partner_data_error"] = peaqos_raw["partner_data_error"]

    return MachineProfileResponse(schema_version=schema_version, name=name, peaqos=peaqos)


def _guard_operator_machine(entry: object, operation: str) -> OperatorMachine:
    if not _is_object(entry):
        raise _bad(operation)

    did = entry.get("did")
    machine_id = entry.get("machine_id")
    mcr_score = entry.get("mcr_score")
    mcr = entry.get("mcr")
    negative_flag = entry.get("negative_flag")

    if not isinstance(did, str) or not did:
        raise _bad(operation)
    if not _is_non_negative_int(machine_id):
        raise _bad(operation)
    if mcr_score is None:
        mcr_score = 0
    elif not _is_mcr_score(mcr_score):
        raise _bad(operation)
    if not isinstance(mcr, str) or mcr not in _VALID_MCR_VALUES:
        raise _bad(operation)
    if not isinstance(negative_flag, bool):
        raise _bad(operation)

    return OperatorMachine(
        did=did,
        machine_id=machine_id,
        mcr_score=mcr_score,
        mcr=mcr,
        negative_flag=negative_flag,
    )


def guard_operator_machines_response(
    body: object,
    operation: str = "query_operator_machines",
) -> OperatorMachinesResponse:
    """Narrow an unknown JSON body to :class:`OperatorMachinesResponse`.

    Args:
        body: JSON-decoded HTTP response body.
        operation: Caller name, surfaced inside the error message.

    Returns:
        An :class:`OperatorMachinesResponse` TypedDict with every
        machine entry individually validated.

    Raises:
        ApiError: With ``code="BAD_RESPONSE"`` if the body, the
            ``machines`` array, or any entry is malformed.
    """
    if not _is_object(body):
        raise _bad(operation)

    operator_did = body.get("operator_did")
    machines_raw = body.get("machines")
    pagination_raw = body.get("pagination")

    if not isinstance(operator_did, str) or not operator_did:
        raise _bad(operation)
    if not isinstance(machines_raw, list):
        raise _bad(operation)
    if not _is_object(pagination_raw):
        raise _bad(operation)

    offset = pagination_raw.get("offset")
    limit = pagination_raw.get("limit")
    total = pagination_raw.get("total")

    if not _is_non_negative_int(offset):
        raise _bad(operation)
    if not _is_non_negative_int(limit):
        raise _bad(operation)
    if not _is_non_negative_int(total):
        raise _bad(operation)

    machines: list[OperatorMachine] = [
        _guard_operator_machine(entry, operation) for entry in machines_raw
    ]
    pagination = Pagination(offset=offset, limit=limit, total=total)
    return OperatorMachinesResponse(
        operator_did=operator_did, machines=machines, pagination=pagination
    )
