"""Shared DID validation for MCR query feature modules."""

from __future__ import annotations

from ...exceptions import ValidationError

_DID_PREFIX = "did:peaq:0x"


def validate_did(did: object) -> str:
    """Reject anything that is not a ``did:peaq:0x…`` string.

    Args:
        did: Value supplied by the caller.

    Returns:
        The same ``did`` narrowed to ``str``.

    Raises:
        ValidationError: If ``did`` is not a string or does not start
            with ``did:peaq:0x``.
    """
    if not isinstance(did, str) or not did.startswith(_DID_PREFIX):
        raise ValidationError(
            field="did",
            constraint=f"starts with '{_DID_PREFIX}'",
            message=f"did must start with '{_DID_PREFIX}'",
            value=did,
        )
    return did
