"""Internal HTTP client for MCR API calls.

Provides :func:`get_json` — a thin wrapper around ``requests.Session.get``
that centralises URL assembly, timeout enforcement, JSON decoding, and
the mapping from HTTP status / transport failures to
:class:`peaq_os_sdk.exceptions.ApiError` with stable ``.code`` sentinels
defined in :mod:`._internal.error_codes`.

Query feature modules (``query_mcr``, ``query_machine``,
``query_operator_machines``) all go through this single seam so their
error handling stays uniform.
"""

from __future__ import annotations

import logging
from typing import Any, Final

import requests

from ..exceptions import ApiError
from ._internal.error_codes import (
    BAD_RESPONSE,
    HTTP_ERROR,
    NETWORK_ERROR,
    NOT_FOUND,
    SERVER_ERROR,
    SERVICE_UNAVAILABLE,
    TIMEOUT,
)

logger = logging.getLogger("peaq_os_sdk.query.http_client")

DEFAULT_MCR_HTTP_TIMEOUT_SECONDS: Final[float] = 30.0
"""Default per-call timeout applied when the caller does not specify one."""


def build_url(base: str, path: str) -> str:
    """Join a base URL and a relative path with exactly one ``/`` between them.

    Args:
        base: Absolute base URL (e.g. ``http://127.0.0.1:8000``).
        path: Relative path beginning with or without ``/``.

    Returns:
        Concatenated URL with normalised slashes.
    """
    return base.rstrip("/") + "/" + path.lstrip("/")


def get_json(
    session: requests.Session,
    url: str,
    *,
    operation: str,
    timeout: float = DEFAULT_MCR_HTTP_TIMEOUT_SECONDS,
) -> Any:
    """Issue a ``GET`` against *url* and return the decoded JSON body.

    Args:
        session: Reusable HTTP session (typically ``PeaqosClient.session``).
        url: Fully-qualified request URL.
        operation: Human-readable caller name — surfaced inside error
            messages so misbehaving endpoints are easy to trace.
        timeout: Per-request timeout in seconds. Defaults to 30 s.

    Returns:
        The decoded JSON body (typically a ``dict`` or ``list``). Shape
        validation is the caller's responsibility — see the
        ``query/_internal/response_guards.py`` helpers.

    Raises:
        ApiError: With a stable ``code`` attribute:

            * ``NOT_FOUND`` — HTTP 404.
            * ``SERVICE_UNAVAILABLE`` — HTTP 503.
            * ``SERVER_ERROR`` — any other HTTP 5xx.
            * ``HTTP_ERROR`` — any other non-2xx status.
            * ``BAD_RESPONSE`` — response body is not valid JSON.
            * ``TIMEOUT`` — request exceeded ``timeout``.
            * ``NETWORK_ERROR`` — other transport failure (DNS, TCP, TLS).
    """
    try:
        response = session.get(url, timeout=timeout)
    except requests.exceptions.Timeout as err:
        raise ApiError(
            f"{operation}: request to {url} timed out after {timeout}s",
            code=TIMEOUT,
        ) from err
    except requests.exceptions.RequestException as err:
        raise ApiError(
            f"{operation}: network request to {url} failed",
            code=NETWORK_ERROR,
        ) from err

    if not response.ok:
        raise _map_http_status(response, operation, url)

    try:
        return response.json()
    except ValueError as err:
        raise ApiError(
            f"{operation}: MCR API at {url} returned a non-JSON response",
            code=BAD_RESPONSE,
        ) from err


def _map_http_status(
    response: requests.Response,
    operation: str,
    url: str,
) -> ApiError:
    """Map a non-2xx response to a typed :class:`ApiError`.

    Parses a ``{"detail": str}`` body when present and threads the
    server-supplied detail into the error message.
    """
    status = response.status_code
    detail = _read_detail(response)

    if status == 404:
        msg = f"{operation}: resource not found at {url}"
        if detail:
            msg = f"{msg} — {detail}"
        return ApiError(msg, code=NOT_FOUND)

    if status == 503:
        msg = f"{operation}: MCR API service unavailable at {url}"
        if detail:
            msg = f"{msg} — {detail}"
        return ApiError(msg, code=SERVICE_UNAVAILABLE)

    if 500 <= status < 600:
        msg = f"{operation}: MCR API server error {status} at {url}"
        if detail:
            msg = f"{msg} — {detail}"
        return ApiError(msg, code=SERVER_ERROR)

    msg = f"{operation}: unexpected HTTP {status} from {url}"
    if detail:
        msg = f"{msg} — {detail}"
    return ApiError(msg, code=HTTP_ERROR)


def _read_detail(response: requests.Response) -> str:
    """Return the ``detail`` string from a JSON error body, or ``""``."""
    try:
        body = response.json()
    except ValueError:
        return ""
    if isinstance(body, dict):
        detail = body.get("detail")
        if isinstance(detail, str):
            return detail
    return ""
