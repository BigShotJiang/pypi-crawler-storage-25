"""Fetch the full machine profile (NFT metadata JSON v1.0) from the MCR API."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..types.queries import MachineProfileResponse
from ._internal.did import validate_did
from ._internal.response_guards import guard_machine_profile_response
from .http_client import build_url, get_json

if TYPE_CHECKING:
    from ..client import PeaqosClient


def query_machine(client: PeaqosClient, did: str) -> MachineProfileResponse:
    """Fetch the full machine profile for a given machine DID.

    Sends ``GET {client.api_url}/machine/{did}`` and returns the parsed
    NFT metadata JSON v1.0 body as a plain ``dict[str, Any]``. The
    profile schema is intentionally open — the SDK validates only that
    the body is a JSON object (not an array or primitive) and leaves
    field-level interpretation to the caller.

    Args:
        client: Configured :class:`PeaqosClient` — only ``api_url`` and
            ``session`` are used.
        did: Machine DID. Must start with ``did:peaq:0x``.

    Returns:
        A :class:`MachineProfileResponse` (plain ``dict[str, Any]``).
        The top-level dict is a fresh shallow copy; nested lists and
        dicts remain shared with the JSON decoder's output.

    Raises:
        ValidationError: If ``did`` does not start with ``did:peaq:0x``.
        ApiError: With ``code="NOT_FOUND"`` on HTTP 404,
            ``"SERVICE_UNAVAILABLE"`` on HTTP 503,
            ``"SERVER_ERROR"`` on other 5xx,
            ``"HTTP_ERROR"`` on other non-2xx,
            ``"BAD_RESPONSE"`` on malformed body,
            ``"TIMEOUT"`` on timeout, or ``"NETWORK_ERROR"`` on a
            transport failure.

    Example::

        profile = query_machine(client, "did:peaq:0xabc...")
        print(profile["schema_version"], profile["name"])
    """
    validated_did = validate_did(did)
    url = build_url(client.api_url, f"/machine/{validated_did}")
    body = get_json(client.session, url, operation="query_machine")
    return guard_machine_profile_response(body, operation="query_machine")
