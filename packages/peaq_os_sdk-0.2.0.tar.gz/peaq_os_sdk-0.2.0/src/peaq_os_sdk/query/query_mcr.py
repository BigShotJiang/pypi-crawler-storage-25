"""Fetch a machine's credit rating from the MCR API server."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..types.queries import MCRResponse
from ._internal.did import validate_did
from ._internal.response_guards import guard_mcr_response
from .http_client import build_url, get_json

if TYPE_CHECKING:
    from ..client import PeaqosClient


def query_mcr(client: PeaqosClient, did: str) -> MCRResponse:
    """Fetch the machine credit rating for a given machine DID.

    Sends ``GET {client.api_url}/mcr/{did}`` and validates the shape
    of the parsed response before returning it.

    Args:
        client: Configured :class:`PeaqosClient` — only ``api_url`` and
            ``session`` are used.
        did: Machine DID. Must start with ``did:peaq:0x``.

    Returns:
        A :class:`MCRResponse` TypedDict with snake_case keys.

    Raises:
        ValidationError: If ``did`` does not start with ``did:peaq:0x``.
        ApiError: With ``code="NOT_FOUND"`` on HTTP 404,
            ``"SERVICE_UNAVAILABLE"`` on HTTP 503,
            ``"SERVER_ERROR"`` on other 5xx,
            ``"HTTP_ERROR"`` on other non-2xx,
            ``"BAD_RESPONSE"`` on malformed body,
            ``"TIMEOUT"`` on timeout, or ``"NETWORK_ERROR"`` on a
            transport failure.

    Example::

        mcr = query_mcr(client, "did:peaq:0xabc...")
        print(mcr["mcr_score"], mcr["mcr"])
    """
    validated_did = validate_did(did)
    url = build_url(client.api_url, f"/mcr/{validated_did}")
    body = get_json(client.session, url, operation="query_mcr")
    return guard_mcr_response(body, operation="query_mcr")
