# AMI — Anonymous Memory Intelligence

Your private memory intelligence — captures thoughts from anywhere, organises them into your vault, and reflects insights back to you. Entirely local.

**Status:** Alpha. The core CLI and domain modules are in place; ingestion, OCR, and the weekly-digest pipeline are still being built.

**Hard constraints:**
- Open-source, no paid services.
- Local-first AI via Ollama only — your notes never leave your device.
- Built for the user's existing Obsidian vault conventions (`KEY: value` headers, lifecycle states `#infant → #child → #developing → #adult → #on-ice → #removed`).

## Install

```bash
# Prereqs: Python 3.12, uv, and Ollama. See docs/01-prerequisites.md.
git clone git@gitlab.com:nkosinathi1/ami.git ~/source/repos/ami
cd ~/source/repos/ami
uv sync
ami init        # one-time setup wizard
ami doctor      # verify uv / Ollama / models / vault / ssh
```

## Try it

```bash
ami --help                # discover every subcommand
ami doctor                # health-check the environment
ami vault status          # confirm inbox folders are in place
ami dev guard             # lint + format check + tests + security audit
```

## Documentation

The build guide and operator manual live at `~/source/ubuntu/docs/ami/`:

- `00-overview.md` — start here.
- `standards.md` — engineering rules every contribution is held to.
- `security.md` — threat model.
- `14-cli-reference.md` — every `ami` command, what it does.
- `15-ide-setup.md` — VS Code + WSL setup.
- `activity-log.md` — append-only audit trail of every change.

## License

MIT. See `LICENSE`.
