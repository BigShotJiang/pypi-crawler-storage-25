"""Create and inspect the Obsidian vault folder structure.

AMI can build the full vault from scratch — root and all subfolders — via
`amie init`. On an existing machine it just fills in anything missing.

This module knows how to:

- Build or repair the full folder skeleton (`scaffold_vault`).
- Report which folders are missing (`vault_status`).

`scaffold_vault` requires the vault root to already exist. The root itself
is created by `amie init` before calling this function. Commands like
`amie watch` expect the vault to be set up; direct users to `amie init`
if the root is missing.

Nothing here talks to the network or shells out — only the file system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from amie.config import Config

# ---------------------------------------------------------------------------
# Vault skeleton — every folder AMI expects to exist, as paths relative to
# the vault root. Ordered top-down so parent dirs come before their children.
# ---------------------------------------------------------------------------

VAULT_SKELETON: tuple[str, ...] = (
    # 1 - CPU: personal cognitive processing — art, health, relationships,
    # journaling, music, quotes, and the weekly digest output.
    "1 - CPU",
    "1 - CPU/Art",
    "1 - CPU/Friends + Acquaintances",
    "1 - CPU/Friends + Acquaintances/Data",
    "1 - CPU/Health",
    "1 - CPU/Music Lyrics",
    "1 - CPU/Quotes + Wisdom",
    "1 - CPU/Replica",
    "1 - CPU/Replica/Entries",
    "1 - CPU/Weekly Digests",
    # 2 - Source: reference material, projects, tasks, and work notes.
    "2 - Source",
    "2 - Source/Contracts",
    "2 - Source/Contracts/Signed",
    "2 - Source/Digital Library Build",
    "2 - Source/Digital Library Build/Books + PDFs",
    "2 - Source/Digital Library Build/Philosophy",
    "2 - Source/Digital Library Build/Psychology",
    "2 - Source/Memory Bank",
    "2 - Source/Memory Bank/Chess",
    "2 - Source/Online",
    "2 - Source/Programming",
    "2 - Source/Programming/Code Snippets",
    "2 - Source/Programming/Release Notes",
    "2 - Source/Programming/Repositories",
    "2 - Source/Programming/Work",
    "2 - Source/Tasks",
    "2 - Source/Tasks/Project S.E.L.F",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/1.1 New",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/1.2 Planned",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/1.3 Predecessor",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/1.5 Complete",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/Incomplete",
    "2 - Source/Tasks/Project S.E.L.F/1. Backlog/Removed",
    "2 - Source/Whakatau",
    "2 - Source/Whakatau/Meetings",
    "2 - Source/Whakatau/Work",
    # 3 - Tags: topic connection hubs. Each note here is a wiki-link target.
    # When any note writes TAGS: [[Software-Development]] in its header, that
    # creates a backlink to 3 - Tags/Software-Development.md. Over time the hub
    # accumulates backlinks from every note that touches that topic. In graph
    # view these hubs appear as densely-connected central nodes — the bigger the
    # node, the stronger and more developed that topic is in your thinking.
    "3 - Tags",
    # 4 - Implementation: applied learning — reflection and practice notes.
    "4 - Implementation",
    "4 - Implementation/Learning Applied",
    "4 - Implementation/Learning Applied/Reflection",
    # 5 - Template: Obsidian templates, container definitions, Templater scripts.
    "5 - Template",
    "5 - Template/Containers",
    "5 - Template/Containers/Container Elements",
    "5 - Template/Containers/Container System Documentation & Schematics",
    "5 - Template/Indexes",
    "5 - Template/Scripts",
    "5 - Template/Templater Templates",
    "5 - Template/Templates For Containers",
    # 6 - IDEAS: raw ideas, portfolio, and writing drafts.
    "6 - IDEAS",
    "6 - IDEAS/Portfolio",
    "6 - IDEAS/Portfolio/About",
    "6 - IDEAS/Portfolio/Writing",
    # 7 - Learning: course notes, reading notes, structured study.
    "7 - Learning",
    "7 - Learning/Courses",
    "7 - Learning/Courses/Coursera",
    "7 - Learning/Courses/O'reilly",
    # Media: images and other attachments embedded in notes.
    "Jpeg and other media",
    # inbox: AMI's staging area — raw arrivals go in, triaged notes come out.
    "inbox",
    "inbox/android",
    "inbox/failed",
    "inbox/photos",
    "inbox/triaged",
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scaffold_vault(cfg: Config) -> list[Path]:
    """Create every folder in the vault skeleton that doesn't already exist.

    - Idempotent: folders that already exist are left untouched.
    - Requires the vault root to exist. `amie init` creates the root first,
      then calls this. Other commands raise if the root is missing — run
      `amie init` to set up a fresh machine.

    Returns only the folders that were newly created. Returns an empty list
    when the vault was already fully set up.
    """
    if not cfg.vault_path.is_dir():
        raise FileNotFoundError(f"vault root does not exist: {cfg.vault_path}")

    created = []
    for relative in VAULT_SKELETON:
        folder = cfg.vault_path / relative
        if not folder.is_dir():
            folder.mkdir(parents=True, exist_ok=True)
            created.append(folder)
    return created


@dataclass(frozen=True)
class VaultStatus:
    """A snapshot of whether AMI's folders are set up correctly."""

    vault_exists: bool
    missing: list[Path] = field(default_factory=list)

    @property
    def ready(self) -> bool:
        """True if the vault exists AND every required folder is present."""
        return self.vault_exists and not self.missing


def vault_status(cfg: Config) -> VaultStatus:
    """Report the current state of the vault in one call."""
    if not cfg.vault_path.is_dir():
        all_folders = [cfg.vault_path / r for r in VAULT_SKELETON]
        return VaultStatus(vault_exists=False, missing=all_folders)
    missing = [cfg.vault_path / r for r in VAULT_SKELETON if not (cfg.vault_path / r).is_dir()]
    return VaultStatus(vault_exists=True, missing=missing)
