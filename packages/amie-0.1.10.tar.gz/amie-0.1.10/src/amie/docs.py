"""Docs staleness checks.

Compares live code state against the docs folder and reports gaps:
  - `vault-structure.md` must mention every top-level section of VAULT_SKELETON.
  - `14-cli-reference.md` must mention every `amie` command in the CLI.

Run via `amie dev docs`. Also runs inside `amie dev guard` when the
AMIE_DOCS_PATH environment variable points at the docs folder.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DocsIssue:
    """One gap found between the live code and the documentation."""

    doc: str
    missing: str


def check_vault_sections(doc: Path, skeleton: tuple[str, ...]) -> list[DocsIssue]:
    """Return an issue for each top-level vault section not mentioned in the doc.

    Only the first path component of each skeleton entry is checked (e.g.
    "2 - Source" covers "2 - Source/Tasks/Project S.E.L.F/1. Backlog/1.1 New").
    """
    content = doc.read_text()
    top_level_sections = {entry.split("/")[0] for entry in skeleton}
    return [
        DocsIssue(doc=doc.name, missing=f"section '{section}' not found in {doc.name}")
        for section in sorted(top_level_sections)
        if section not in content
    ]


def check_cli_reference(doc: Path, commands: list[str]) -> list[DocsIssue]:
    """Return an issue for each CLI command not mentioned in the reference doc."""
    content = doc.read_text()
    return [
        DocsIssue(doc=doc.name, missing=f"command '{command}' not found in {doc.name}")
        for command in commands
        if command not in content
    ]


def run_docs_check(
    docs_dir: Path,
    *,
    skeleton: tuple[str, ...],
    commands: list[str],
) -> list[DocsIssue]:
    """Run all docs checks and return every issue found.

    Missing doc files are reported as issues themselves so the caller
    always gets a complete picture of what needs attention.
    """
    issues: list[DocsIssue] = []

    vault_doc = docs_dir / "vault-structure.md"
    if vault_doc.exists():
        issues.extend(check_vault_sections(vault_doc, skeleton))
    else:
        issues.append(DocsIssue(doc="vault-structure.md", missing="file does not exist"))

    cli_doc = docs_dir / "14-cli-reference.md"
    if cli_doc.exists():
        issues.extend(check_cli_reference(cli_doc, commands))
    else:
        issues.append(DocsIssue(doc="14-cli-reference.md", missing="file does not exist"))

    return issues
