"""Inbox folder inspection for `amie inbox`.

Pure functions: no I/O side effects beyond reading the filesystem.
All live-refresh and signal logic lives in the CLI layer.
"""

from __future__ import annotations

from dataclasses import dataclass

from amie.config import Config

# Ordered display list: (subfolder name, show "waiting" suffix)
INBOX_SUBFOLDERS: tuple[tuple[str, bool], ...] = (
    ("android", True),
    ("photos", True),
    ("triaged", False),
    ("failed", False),
)

_FAILED = "failed"


@dataclass(frozen=True)
class FolderInfo:
    name: str
    file_count: int
    attention: bool  # True when failed/ is non-empty


def inbox_snapshot(cfg: Config) -> list[FolderInfo]:
    """Return one FolderInfo per inbox subfolder."""
    result = []
    for name, _ in INBOX_SUBFOLDERS:
        folder = cfg.inbox_dir / name
        if folder.is_dir():
            count = sum(1 for p in folder.iterdir() if p.is_file())
        else:
            count = 0
        result.append(
            FolderInfo(name=name, file_count=count, attention=(name == _FAILED and count > 0))
        )
    return result


def failed_files(cfg: Config) -> list[str]:
    """Return sorted filenames currently in failed/."""
    folder = cfg.failed_dir
    if not folder.is_dir():
        return []
    return sorted(p.name for p in folder.iterdir() if p.is_file())


def format_folder_line(info: FolderInfo, *, waiting: bool) -> str:
    noun = "file" if info.file_count == 1 else "files"
    suffix = " waiting" if waiting else ""
    return f"  {info.name + '/':12s}{info.file_count} {noun}{suffix}"


def render_snapshot(snapshot: list[FolderInfo]) -> str:
    """Render the inbox table as a plain string (no ANSI codes)."""
    lines = []
    for info, (_, waiting) in zip(snapshot, INBOX_SUBFOLDERS, strict=True):
        lines.append(format_folder_line(info, waiting=waiting))
    return "\n".join(lines)
