"""Normalise a Markor note from inbox/android/ into a triaged vault note.

A Markor note is a plain markdown file typed on Android and synced to
`inbox/android/` via FolderSync over SFTP.  This normalizer:

1. Validates the source path is inside the android inbox (no traversal,
   no symlinks pointing out).
2. Reads the file as UTF-8; on decode failure moves it to inbox/failed/.
3. Builds a vault-style header stamped with the provided time, STATE #infant,
   SOURCE Android/Markor, and default tags [[amie]] [[Android]].
4. Writes the result to inbox/triaged/ with mode 0o600.
5. Writes a `.processed.<name>` marker beside the source file; the source
   is preserved so sync tools (FolderSync, Syncthing) are not confused by
   deletions.  The watcher and startup scan skip files whose marker exists.

The `now` parameter is injected so callers (and tests) can supply a fixed
timestamp instead of the live clock.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from amie.config import Config
from amie.normalizers.header import Header, compose


class SecurityError(ValueError):
    """Raised when the source path fails inbox-boundary validation."""


def normalize(
    source: Path,
    cfg: Config,
    *,
    now: Callable[[], datetime] = datetime.now,
) -> Path:
    """Normalize a Markor note into inbox/triaged/.

    Returns the path of the written triaged note.
    Raises `SecurityError` if the source path is outside the android inbox.
    Raises `ValueError` (and moves source to failed/) if the file is not UTF-8.
    """
    _validate_source_path(source, cfg.android_dir)
    content = _read_or_quarantine(source, cfg.failed_dir)
    header = Header.from_now(
        now=now,
        state="infant",
        tags=["amie", "Android"],
        source="Android/Markor",
    )
    note = compose(header, content)
    dest = _unique_path(cfg.triaged_dir / source.name)
    dest.write_text(note, encoding="utf-8")
    dest.chmod(0o600)
    (source.parent / f".processed.{source.name}").write_text("")
    return dest


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _validate_source_path(source: Path, android_dir: Path) -> None:
    """Raise SecurityError if source resolves outside the android inbox."""
    resolved = source.resolve()
    inbox_resolved = android_dir.resolve()
    if not resolved.is_relative_to(inbox_resolved):
        raise SecurityError(f"{source!r} is outside the android inbox {inbox_resolved!r}")


def _read_or_quarantine(source: Path, failed_dir: Path) -> str:
    """Read source as UTF-8. On failure move it to failed/ and raise."""
    try:
        return source.read_text(encoding="utf-8")
    except UnicodeDecodeError as err:
        dest = _unique_path(failed_dir / source.name)
        source.rename(dest)
        raise ValueError(f"{source.name} is not valid UTF-8; moved to {dest}") from err


def _unique_path(path: Path) -> Path:
    """Return path if it does not exist, else path_1, path_2, … until free."""
    if not path.exists():
        return path
    stem, suffix, parent = path.stem, path.suffix, path.parent
    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate
        counter += 1
