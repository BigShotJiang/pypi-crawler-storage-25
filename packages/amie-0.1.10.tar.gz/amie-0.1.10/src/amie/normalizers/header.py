"""Read and write the headers at the top of every note in the vault.

The user's Obsidian vault uses a simple "KEY: value" block at the top of each
note (NOT YAML frontmatter). For example:

    DATE: 2026-05-02
    TIME: 14:30
    STATE: #infant
    TAGS: [[amie]] [[3 - Tags/Side Projects|Side Projects]]
    SOURCE: Android/Markor

    # NOTE
    The actual note body starts here.

This module's job is two-way:
- Build a header from Python values and turn it into the exact text above.
- Read the text above back into Python values.

It does NOT touch the file system. Reading and writing files is somebody
else's job — this module only knows about strings.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime, time

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# The user's "lifecycle" tags. A note starts at #infant and is later promoted.
CANONICAL_STATES: tuple[str, ...] = (
    "infant",
    "child",
    "developing",
    "adult",
    "on-ice",
    "removed",
)


# ---------------------------------------------------------------------------
# Public API: the Header dataclass
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Header:
    """The KEY: value block at the top of a vault note.

    `state` is stored without its leading `#` — the `#` is added at render
    time. `tags` are the raw text inside `[[...]]` (no brackets).
    """

    date: date
    time: time
    state: str
    tags: list[str] = field(default_factory=list)
    source: str | None = None
    extra: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Strip a leading "#" if the caller included one, then validate.
        # We use object.__setattr__ because the dataclass is frozen — this is
        # the documented way to mutate fields exactly once during construction.
        normalized = self.state.lstrip("#")
        _validate_state(normalized)
        object.__setattr__(self, "state", normalized)

    @classmethod
    def from_now(
        cls,
        *,
        state: str = "infant",
        tags: list[str] | None = None,
        source: str | None = None,
        now: Callable[[], datetime] = datetime.now,
    ) -> Header:
        """Build a header stamped with the current date/time.

        The clock is injected so tests can pass a fixed time.
        """
        stamp = now()
        return cls(
            date=stamp.date(),
            time=stamp.time().replace(microsecond=0),
            state=state,
            tags=list(tags or []),
            source=source,
        )

    def render(self) -> str:
        """Turn this header back into the exact text it represents."""
        return _render_header(self)


def compose(header: Header, body: str) -> str:
    """Join a header and a body with one blank line between them."""
    body_without_leading_newlines = body.lstrip("\n")
    return f"{header.render()}\n{body_without_leading_newlines}"


def parse(text: str) -> tuple[Header, str]:
    """Read a vault note. Returns (header, body)."""
    fields, body = _split_header_and_body(text)
    return _build_header_from_fields(fields), body


# ---------------------------------------------------------------------------
# Private helpers — small steps, named like the chapters of a book.
# ---------------------------------------------------------------------------


def _validate_state(state: str) -> None:
    """Reject anything that isn't one of the user's lifecycle tags."""
    if state not in CANONICAL_STATES:
        raise ValueError(f"unknown lifecycle state {state!r}; must be one of {CANONICAL_STATES}")


def _render_header(header: Header) -> str:
    """Build the KEY: value lines for a header, in the canonical order."""
    lines: list[str] = [
        f"DATE: {header.date.isoformat()}",
        f"TIME: {header.time.strftime('%H:%M')}",
        f"STATE: #{header.state}",
        f"TAGS: {_format_tags(header.tags)}",
    ]
    if header.source is not None:
        lines.append(f"SOURCE: {header.source}")
    for key, value in header.extra.items():
        lines.append(f"{key}: {value}")
    return "\n".join(lines) + "\n"


def _format_tags(tags: list[str]) -> str:
    """Wrap each tag in [[...]] and space-separate them."""
    return " ".join(f"[[{tag}]]" for tag in tags)


# Reading direction: parse() splits the file into a fields-dict and a body
# string, then builds a Header. Each step lives in its own helper below.


def _split_header_and_body(text: str) -> tuple[dict[str, str], str]:
    """Walk down the file collecting KEY: value lines until the body starts."""
    lines = text.splitlines()
    fields: dict[str, str] = {}
    body_start_index = len(lines)  # default: file is all header, no body

    for index, line in enumerate(lines):
        if _is_blank(line):
            body_start_index = index + 1
            break
        parsed = _parse_header_line(line)
        if parsed is None:
            # First non-header line — body starts here, no blank separator.
            body_start_index = index
            break
        key, value = parsed
        fields[key] = value

    body = "\n".join(lines[body_start_index:]).lstrip("\n")
    return fields, body


def _is_blank(line: str) -> bool:
    return line.strip() == ""


# Matches lines like "DATE: 2026-05-02" or "TAGS: [[a]] [[b]]".
# Keys are uppercase letters with optional underscores or hyphens.
_HEADER_LINE = re.compile(r"^([A-Z][A-Z_-]*):\s*(.*)$")


def _parse_header_line(line: str) -> tuple[str, str] | None:
    """Return (key, value) for a header line, or None if this isn't a header line."""
    match = _HEADER_LINE.match(line)
    if match is None:
        return None
    key, value = match.group(1), match.group(2).strip()
    return key, value


_WIKI_LINK = re.compile(r"\[\[([^\]]+)\]\]")


def _extract_wiki_links(text: str) -> list[str]:
    """Pull the bodies out of every [[...]] in the given text."""
    return _WIKI_LINK.findall(text)


def _build_header_from_fields(fields: dict[str, str]) -> Header:
    """Turn a dict of KEY:value strings into a typed Header."""
    remaining = dict(fields)  # work on a copy so we can pop as we go

    try:
        date_value = date.fromisoformat(remaining.pop("DATE"))
        time_value = time.fromisoformat(remaining.pop("TIME"))
        state_value = remaining.pop("STATE")
    except KeyError as missing:
        raise ValueError(f"missing required header field: {missing.args[0]}") from missing

    tags = _extract_wiki_links(remaining.pop("TAGS", ""))
    source = remaining.pop("SOURCE", None)

    return Header(
        date=date_value,
        time=time_value,
        state=state_value,
        tags=tags,
        source=source,
        extra=remaining,
    )
