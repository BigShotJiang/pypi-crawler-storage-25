"""Normalise a photo from inbox/photos/ into a triaged vault note via OCR.

Flow:
1. Validate source path is inside inbox/photos/ (no traversal).
2. Convert HEIC → JPG via pillow-heif if needed.
3. Call the injected Ollama vision model; expect strict JSON:
       {"transcript": str, "suggested_tags": [str, ...], "suggested_state": str}
4. Validate the JSON schema; on failure move the image to inbox/failed/ and raise.
5. Build a vault-style markdown note using the LLM-suggested tags and state,
   with a vault header and an Obsidian image embed, then write to inbox/triaged/.
6. Copy the (possibly converted) image to `Jpeg and other media/`.
7. Write a `.processed.<name>` marker so the watcher skips it on restart.

The `ollama_chat` and `now` parameters are injected so tests can run without
a live Ollama instance or wall-clock dependency.
"""

from __future__ import annotations

import json
import shutil
import tempfile
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from amie.config import Config
from amie.normalizers.header import Header, compose
from amie.normalizers.markor import _unique_path  # reuse de-collision helper


class SecurityError(ValueError):
    """Raised when the source path fails photos-inbox boundary validation."""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

OllamaChat = Callable[[str, list[dict[str, Any]]], str]


def _get_ollama_client():  # pragma: no cover
    import ollama

    return ollama.Client()


_ollama_client = None


def _default_ollama_chat(model: str, messages: list[dict[str, Any]]) -> str:  # pragma: no cover
    global _ollama_client
    if _ollama_client is None:
        _ollama_client = _get_ollama_client()
    response = _ollama_client.chat(
        model=model,
        messages=messages,
        options={"temperature": 0, "num_predict": 512},
    )
    return response.message.content


def normalize(
    source: Path,
    cfg: Config,
    *,
    ollama_chat: OllamaChat = _default_ollama_chat,
    now: Callable[[], datetime] = datetime.now,
) -> Path:
    """Normalize a photo into inbox/triaged/.

    Returns the path of the written triaged note.
    Raises `SecurityError` if source is outside inbox/photos/.
    Raises `ValueError` (and moves source to failed/) on bad LLM output.
    """
    _validate_source_path(source, cfg.photos_dir)

    # Convert HEIC → JPEG if needed. jpg_path is the media-quality copy.
    jpg_path, is_converted = _to_jpg(source)
    try:
        # Downscale a separate copy for OCR — faster inference, same accuracy.
        ocr_path, is_resized = _resize_for_ocr(jpg_path)
        try:
            raw = _call_ocr(ocr_path, cfg.ocr_model, ollama_chat)
            parsed = _parse_response(raw, source, cfg.failed_dir)
        finally:
            if is_resized:
                ocr_path.unlink(missing_ok=True)

        dest_name = jpg_path.name
        _copy_to_media(jpg_path, cfg.vault_path / "Jpeg and other media", dest_name)
    finally:
        if is_converted:
            jpg_path.unlink(missing_ok=True)

    llm_tags = parsed.get("suggested_tags") or []
    llm_state = parsed.get("suggested_state") or "infant"
    header = Header.from_now(
        now=now,
        state=llm_state if isinstance(llm_state, str) else "infant",
        tags=["amie", "Photos"] + [t for t in llm_tags if isinstance(t, str)],
        source="Photos/OCR",
    )
    body = f"![[{dest_name}]]\n\n{parsed['transcript']}"
    note = compose(header, body)

    dest = _unique_path(cfg.triaged_dir / (source.stem + ".md"))
    dest.write_text(note, encoding="utf-8")
    dest.chmod(0o600)

    (source.parent / f".processed.{source.name}").write_text("")
    return dest


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _validate_source_path(source: Path, photos_dir: Path) -> None:
    resolved = source.resolve()
    inbox_resolved = photos_dir.resolve()
    if not resolved.is_relative_to(inbox_resolved):
        raise SecurityError(f"{source!r} is outside the photos inbox {inbox_resolved!r}")


_OCR_MAX_PX = 768


def _to_jpg(source: Path) -> tuple[Path, bool]:
    """Convert HEIC → JPEG. Returns (jpg_path, is_temp).
    For JPEG/PNG, returns source unchanged (no PIL open, no quality loss).
    """
    if source.suffix.lower() in {".jpg", ".jpeg", ".png"}:
        return source, False

    from PIL import Image
    from pillow_heif import register_heif_opener

    register_heif_opener()
    tmp = Path(tempfile.mktemp(suffix=".jpg"))
    Image.open(source).save(tmp, format="JPEG")
    return tmp, True


def _resize_for_ocr(source: Path) -> tuple[Path, bool]:
    """Return a copy scaled to _OCR_MAX_PX on the longest side if source exceeds it.
    Smaller images mean faster llava inference with no meaningful OCR quality loss.
    Returns (path, is_temp). If already small enough, returns source unchanged.
    """
    from PIL import Image

    img = Image.open(source)
    if max(img.size) <= _OCR_MAX_PX:
        return source, False
    img.thumbnail((_OCR_MAX_PX, _OCR_MAX_PX), Image.LANCZOS)
    tmp = Path(tempfile.mktemp(suffix=".jpg"))
    img.save(tmp, format="JPEG", quality=90)
    return tmp, True


_OCR_PROMPT = (
    "Transcribe all text visible in this image exactly as written.\n"
    "Also suggest 1-3 short topic tags and a processing state.\n"
    "Reply with JSON only — no explanation, no markdown fences:\n"
    '{"transcript": "<all text you see>", '
    '"suggested_tags": ["tag1", "tag2"], '
    '"suggested_state": "infant"}'
)

logger = __import__("logging").getLogger(__name__)


def _call_ocr(jpg_path: Path, model: str, ollama_chat: OllamaChat) -> str:
    messages = [
        {
            "role": "user",
            "content": _OCR_PROMPT,
            "images": [jpg_path.read_bytes()],
        }
    ]
    raw = ollama_chat(model, messages)
    logger.debug("OCR raw response (%d chars): %.200s", len(raw or ""), raw or "")
    return raw or ""


def _extract_json(raw: str) -> str:
    """Return the best JSON candidate from a potentially prose-wrapped response."""
    stripped = raw.strip()
    # Strip markdown code fences: ```json ... ``` or ``` ... ```
    for fence in ("```json", "```"):
        if fence in stripped:
            start = stripped.find(fence) + len(fence)
            end = stripped.find("```", start)
            if end != -1:
                return stripped[start:end].strip()
    # Find first { ... } block
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end > start:
        return stripped[start : end + 1]
    return stripped


def _parse_response(raw: str, source: Path, failed_dir: Path) -> dict[str, Any]:
    """Parse and validate the LLM JSON response. On failure quarantine source."""
    if not raw.strip():
        dest = _unique_path(failed_dir / source.name)
        shutil.copy2(source, dest)
        raise ValueError(
            f"LLM returned empty response for {source.name} — "
            "check that the model supports vision and is fully loaded"
        )
    try:
        data = json.loads(_extract_json(raw))
    except json.JSONDecodeError as err:
        dest = _unique_path(failed_dir / source.name)
        shutil.copy2(source, dest)
        raise ValueError(f"LLM returned invalid JSON for {source.name}: {err}") from err

    if "transcript" not in data:
        dest = _unique_path(failed_dir / source.name)
        shutil.copy2(source, dest)
        raise ValueError(f"LLM response missing 'transcript' key for {source.name}")

    return data


def _copy_to_media(source: Path, media_dir: Path, dest_name: str) -> None:
    media_dir.mkdir(parents=True, exist_ok=True)
    dest = _unique_path(media_dir / dest_name)
    shutil.copy2(source, dest)
