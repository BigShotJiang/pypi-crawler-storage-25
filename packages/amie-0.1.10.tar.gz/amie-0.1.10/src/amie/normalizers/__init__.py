"""Normalizers convert raw inbox files into vault-style triaged markdown."""
