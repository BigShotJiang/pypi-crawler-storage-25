"""First-run setup. Pure logic; no Typer, no prompts.

`run_init()` is what the CLI wires into `amie init`. It takes the user's
choices as plain arguments (vault path, "create the vault folder if it's
missing"), then:

1. Creates the vault root folder if asked AND it doesn't exist.
2. Writes the user's config file (`~/.config/amie/config.toml`).
3. Calls `scaffold_vault` to build the complete folder skeleton inside it.

`setup_ssh_server()` is the SSH step, called separately by the CLI after
`run_init`. It installs openssh-server, creates the `amie-sync` system user,
writes AMI's sshd drop-in config, and enables the service. Every subprocess
call goes through the injectable `Probe` so tests can run without sudo.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from amie.config import (
    DEFAULT_DIGEST_MODEL,
    DEFAULT_OCR_MODEL,
    DEFAULT_SSHD_DROP_IN,
    DEFAULT_TAG_MODEL,
    Config,
)
from amie.doctor import Probe, real_probe
from amie.vault import scaffold_vault

_AMIE_SSHD_CONFIG = (
    "# AMI phone-sync SSH configuration.\n"
    "# Written by `amie init` — run `amie init` again to regenerate.\n"
    "PasswordAuthentication no\n"
    "\n"
    "Match User amie-sync\n"
    "    AllowTcpForwarding no\n"
    "    X11Forwarding no\n"
    "    PermitTTY no\n"
    "    ForceCommand internal-sftp\n"
)


@dataclass(frozen=True)
class InitOutcome:
    """A summary of what `run_init` did, returned to the CLI for display."""

    config_path: Path
    vault_path: Path
    config_written: bool
    vault_created: bool
    folders_created: int


@dataclass(frozen=True)
class SshSetupResult:
    """A summary of what `setup_ssh_server` did, returned to the CLI for display."""

    sshd_was_installed: bool
    user_was_created: bool
    config_written: bool


def run_init(
    *,
    vault_path: Path,
    config_path: Path,
    create_vault_if_missing: bool,
) -> InitOutcome:
    """Set up AMI on a fresh machine.

    Raises `FileNotFoundError` if the vault doesn't exist and the user
    declined to create it.
    """
    resolved_vault = vault_path.expanduser()
    vault_was_created = _ensure_vault_exists(resolved_vault, create_vault_if_missing)
    _write_config_file(config_path, resolved_vault)

    cfg = _build_default_config(resolved_vault)
    created_dirs = scaffold_vault(cfg)

    return InitOutcome(
        config_path=config_path,
        vault_path=resolved_vault,
        config_written=True,
        vault_created=vault_was_created,
        folders_created=len(created_dirs),
    )


def setup_ssh_server(
    probe: Probe = real_probe,
    *,
    sshd_drop_in: Path = DEFAULT_SSHD_DROP_IN,
) -> SshSetupResult:
    """Install openssh-server, create amie-sync user, write AMI's sshd config.

    Every subprocess call uses the injected probe so tests can run without sudo.
    If a step is already done (sshd present, user exists) it is skipped.
    """
    sshd_was_installed = _ensure_sshd_installed(probe)
    user_was_created = _ensure_ami_sync_user(probe)
    _write_sshd_drop_in(probe, sshd_drop_in)
    probe(["sudo", "systemctl", "enable", "--now", "ssh"])
    probe(["sudo", "systemctl", "reload-or-restart", "ssh"])
    return SshSetupResult(
        sshd_was_installed=sshd_was_installed,
        user_was_created=user_was_created,
        config_written=True,
    )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _ensure_vault_exists(vault: Path, create_if_missing: bool) -> bool:
    """Return True if we created the vault folder, False if it already existed.
    Raise if the vault is missing and the user declined to create it."""
    if vault.is_dir():
        return False
    if not create_if_missing:
        raise FileNotFoundError(
            f"vault folder does not exist at {vault} and you chose not to create it"
        )
    vault.mkdir(parents=True, exist_ok=True)
    return True


def _write_config_file(config_path: Path, vault: Path) -> None:
    """Write a minimal but commented config file at config_path."""
    config_path.parent.mkdir(parents=True, exist_ok=True)
    body = (
        "# AMI configuration file.\n"
        "# Edit this file to change AMI's defaults; environment variables\n"
        "# (AMIE_VAULT_PATH, AMIE_TAG_MODEL, ...) override these values.\n"
        "\n"
        f'vault_path = "{vault}"\n'
        "\n"
        "# Uncomment and set if you want to override the default Ollama models:\n"
        f'# tag_model = "{DEFAULT_TAG_MODEL}"\n'
        f'# digest_model = "{DEFAULT_DIGEST_MODEL}"\n'
        f'# ocr_model = "{DEFAULT_OCR_MODEL}"\n'
    )
    config_path.write_text(body)
    config_path.chmod(0o600)


def _build_default_config(vault: Path) -> Config:
    return Config(
        vault_path=vault,
        tag_model=DEFAULT_TAG_MODEL,
        digest_model=DEFAULT_DIGEST_MODEL,
        ocr_model=DEFAULT_OCR_MODEL,
    )


def _run_or_raise(probe: Probe, args: list[str]) -> None:
    rc, _ = probe(args)
    if rc != 0:
        raise RuntimeError(f"command failed (exit {rc}): {' '.join(args)}")


def _ensure_sshd_installed(probe: Probe) -> bool:
    """Return True if we installed sshd, False if it was already present."""
    rc, _ = probe(["which", "sshd"])
    if rc == 0:
        return False
    _run_or_raise(probe, ["sudo", "apt-get", "install", "-y", "openssh-server"])
    return True


def _ensure_ami_sync_user(probe: Probe) -> bool:
    """Return True if we created amie-sync, False if the user already existed."""
    rc, _ = probe(["id", "amie-sync"])
    if rc == 0:
        return False
    _run_or_raise(
        probe,
        [
            "sudo",
            "useradd",
            "--system",
            "--no-create-home",
            "--shell",
            "/usr/sbin/nologin",
            "amie-sync",
        ],
    )
    return True


def _write_sshd_drop_in(probe: Probe, path: Path) -> None:
    import tempfile

    tmp = Path(tempfile.mktemp(suffix=".amie-sshd.conf"))
    tmp.write_text(_AMIE_SSHD_CONFIG)
    try:
        probe(["sudo", "mkdir", "-p", str(path.parent)])
        probe(["sudo", "install", "-m", "644", str(tmp), str(path)])
    finally:
        tmp.unlink(missing_ok=True)
