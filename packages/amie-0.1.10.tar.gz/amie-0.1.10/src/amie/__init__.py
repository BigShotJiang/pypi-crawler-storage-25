"""AMI — Anonymous Memory Intelligence."""

__version__ = "0.0.1"
