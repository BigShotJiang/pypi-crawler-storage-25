"""Security audit primitives.

`build_audit_command()` returns the argv for `pip-audit` against the lockfile.
The CLI runs it via the same injected executor pattern used elsewhere.

`pip-audit` checks every pinned dependency against the Python Packaging
Advisory Database. It exits non-zero when any vulnerable version is found.
"""

from __future__ import annotations


def build_audit_command() -> list[str]:
    """Argv for `pip-audit` over the project's lockfile."""
    return ["uv", "run", "pip-audit", "--skip-editable"]
