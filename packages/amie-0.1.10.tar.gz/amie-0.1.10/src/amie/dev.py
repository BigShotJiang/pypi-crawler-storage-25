"""Developer tooling commands wrapped behind the amie CLI.

Design: each command has a pure builder (`build_*_command`) that returns the
argv list. The thin `run()` helper invokes a pluggable executor — defaulting
to a real subprocess but swappable in tests. Domain stays I/O-free.

The `guard` family is a single gate that runs lint + format-check + tests
in sequence. It's the command you run before AND after every code change.
"""

from __future__ import annotations

import subprocess
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

Executor = Callable[..., int]


def build_test_command(
    *,
    no_cov: bool = False,
    extra: list[str] | None = None,
) -> list[str]:
    if extra is not None and not isinstance(extra, list):
        raise TypeError("extra must be a list of strings")
    cmd = ["uv", "run", "pytest"]
    if no_cov:
        cmd.append("--no-cov")
    if extra:
        cmd.extend(extra)
    return cmd


def build_lint_command(*, fix: bool = False) -> list[str]:
    cmd = ["uv", "run", "ruff", "check"]
    if fix:
        cmd.append("--fix")
    return cmd


def build_fmt_command() -> list[str]:
    return ["uv", "run", "ruff", "format"]


def build_sync_command() -> list[str]:
    return ["uv", "sync"]


def build_integration_command() -> list[str]:
    """Run integration-marked tests against live Ollama; no coverage gate."""
    return ["uv", "run", "pytest", "-m", "integration", "-v", "-o", "addopts="]


def build_fmt_check_command() -> list[str]:
    """Verify formatting without modifying files. Used by `amie dev guard`."""
    return ["uv", "run", "ruff", "format", "--check"]


# ---------------------------------------------------------------------------
# Guard pipeline: a single gate that runs lint + format-check + tests.
# Run it before AND after every code change. Stops at the first failure.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class GuardStep:
    """One step in the pre-change guard pipeline."""

    name: str
    command: list[str]


@dataclass(frozen=True)
class GuardResult:
    """The outcome of running one guard step."""

    name: str
    exit_code: int

    @property
    def passed(self) -> bool:
        return self.exit_code == 0


def build_docs_check_command(docs_dir: Path) -> list[str]:
    """Build the command that checks docs for staleness."""
    return ["uv", "run", "amie", "dev", "docs", "--docs-dir", str(docs_dir)]


def guard_steps(
    *,
    skip_audit: bool = False,
    docs_dir: Path | None = None,
) -> list[GuardStep]:
    """The guard pipeline, in execution order.

    The security audit step runs `pip-audit`, which makes an outbound network
    call to PyPA/OSV (transmitting only package names + versions, never
    user content — see security.md). Pass `skip_audit=True` for fast inner
    loops where the network call would slow iteration.

    Pass `docs_dir` to add a docs-staleness check as the final step. Omit it
    (or leave as None) to skip the check — useful for users who have not
    configured AMIE_DOCS_PATH.
    """
    from amie.security import build_audit_command

    steps = [
        GuardStep(name="lint", command=build_lint_command()),
        GuardStep(name="format check", command=build_fmt_check_command()),
        GuardStep(name="tests + coverage", command=build_test_command()),
    ]
    if not skip_audit:
        steps.append(GuardStep(name="security audit", command=build_audit_command()))
    if docs_dir is not None:
        steps.append(GuardStep(name="docs check", command=build_docs_check_command(docs_dir)))
    return steps


def run_guards(
    *,
    executor: Executor = None,
    skip_audit: bool = False,
    docs_dir: Path | None = None,
) -> list[GuardResult]:
    """Run every guard step in order, stopping at the first failure.

    Returns one `GuardResult` per step that was attempted. If everything
    passes, the list contains all steps. If something fails, the list ends
    at the failing step.
    """
    if executor is None:
        executor = real_executor

    results: list[GuardResult] = []
    for step in guard_steps(skip_audit=skip_audit, docs_dir=docs_dir):
        exit_code = executor(step.command)
        results.append(GuardResult(name=step.name, exit_code=exit_code))
        if exit_code != 0:
            break
    return results


def real_executor(args: Sequence[str], *, cwd: Path | None = None) -> int:
    """Default executor — shells out via subprocess and returns the exit code."""
    return subprocess.run(list(args), cwd=cwd, check=False).returncode


def run(
    args: Sequence[str],
    *,
    executor: Executor = real_executor,
    cwd: Path | None = None,
) -> int:
    """Invoke ``args`` via the given executor. Returns the exit code."""
    return executor(list(args), cwd=cwd)
