"""Runtime configuration.

`Config` is a frozen dataclass. Required values have no defaults; optional
ones default to None. The only env-var-aware factories are `Config.from_env()`
and `Config.docs_path_from_env()`, both called at the CLI layer.

Resolution order in `Config.from_env()`:
  1. Process environment variables (`AMIE_VAULT_PATH`, `AMIE_*_MODEL`, `AMIE_DOCS_PATH`).
  2. The user's config file at `$XDG_CONFIG_HOME/amie/config.toml`
     (default `~/.config/amie/config.toml`).
  3. If `AMIE_VAULT_PATH` is still unset, raise `ConfigError`.

`Config.sshd_drop_in_from_env()` reads `AMIE_SSHD_DROP_IN` without requiring
vault configuration — used by `amie init` before the vault is configured.

We deliberately don't fall back to a hardcoded vault path — guessing where
someone's notes live is a security smell. The user runs `amie init` once on a
new machine to set things up.

All environment reads live here. No other module calls `os.getenv` directly.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

DEFAULT_TAG_MODEL = "llama3.2:3b"
DEFAULT_DIGEST_MODEL = "mistral:7b"
DEFAULT_OCR_MODEL = "llava"
DEFAULT_SSHD_DROP_IN = Path("/etc/ssh/sshd_config.d/amie.conf")


class ConfigError(Exception):
    """Raised when AMI's configuration is missing or invalid."""


def user_config_path() -> Path:
    """The path to the user's config file. Honours `$XDG_CONFIG_HOME`."""
    xdg = os.getenv("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "amie" / "config.toml"
    return Path.home() / ".config" / "amie" / "config.toml"


@dataclass(frozen=True)
class Config:
    vault_path: Path
    tag_model: str
    digest_model: str
    ocr_model: str
    docs_path: Path | None = None

    @classmethod
    def from_env(cls) -> Config:
        """Build a Config from env vars + ~/.config/amie/config.toml.

        Raises `ConfigError` if `AMIE_VAULT_PATH` is unset and no config file
        is present.

        This function reads only `os.environ` and the user's config file —
        loading `.env` is the entry-point's job (see `amie.cli`).
        """
        from_file = _read_config_file()

        vault_raw = os.getenv("AMIE_VAULT_PATH") or from_file.get("vault_path")
        if not vault_raw:
            raise ConfigError(
                "AMIE_VAULT_PATH is not set and no config file was found at "
                f"{user_config_path()}. Run `amie init` to create one, "
                "or set AMIE_VAULT_PATH in your environment."
            )

        docs_raw = os.getenv("AMIE_DOCS_PATH") or from_file.get("docs_path")

        return cls(
            vault_path=Path(str(vault_raw)).expanduser(),
            tag_model=(
                os.getenv("AMIE_TAG_MODEL") or from_file.get("tag_model") or DEFAULT_TAG_MODEL
            ),
            digest_model=(
                os.getenv("AMIE_DIGEST_MODEL")
                or from_file.get("digest_model")
                or DEFAULT_DIGEST_MODEL
            ),
            ocr_model=(
                os.getenv("AMIE_OCR_MODEL") or from_file.get("ocr_model") or DEFAULT_OCR_MODEL
            ),
            docs_path=Path(str(docs_raw)).expanduser() if docs_raw else None,
        )

    @classmethod
    def docs_path_from_env(cls) -> Path | None:
        """Read AMIE_DOCS_PATH without requiring vault configuration.

        Used by dev commands (guard, docs check) that run before a vault is
        configured — they should not fail just because AMIE_VAULT_PATH is unset.
        """
        raw = os.getenv("AMIE_DOCS_PATH", "").strip()
        return Path(raw).expanduser() if raw else None

    @classmethod
    def sshd_drop_in_from_env(cls) -> Path:
        """Read AMIE_SSHD_DROP_IN without requiring vault configuration.

        Used by `amie init` before the vault is configured. Defaults to the
        standard drop-in location on Ubuntu/Debian.
        """
        raw = os.getenv("AMIE_SSHD_DROP_IN", "").strip()
        return Path(raw) if raw else DEFAULT_SSHD_DROP_IN

    @property
    def inbox_dir(self) -> Path:
        return self.vault_path / "inbox"

    @property
    def triaged_dir(self) -> Path:
        return self.inbox_dir / "triaged"

    @property
    def android_dir(self) -> Path:
        return self.inbox_dir / "android"

    @property
    def photos_dir(self) -> Path:
        return self.inbox_dir / "photos"

    @property
    def failed_dir(self) -> Path:
        return self.inbox_dir / "failed"

    @property
    def media_dir(self) -> Path:
        return self.vault_path / "Jpeg and other media"

    @property
    def digests_dir(self) -> Path:
        return self.vault_path / "1 - CPU" / "Weekly Digests"


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _read_config_file() -> dict[str, str]:
    """Return the contents of the user's config file, or an empty dict."""
    path = user_config_path()
    if not path.is_file():
        return {}
    with path.open("rb") as handle:
        return tomllib.load(handle)
