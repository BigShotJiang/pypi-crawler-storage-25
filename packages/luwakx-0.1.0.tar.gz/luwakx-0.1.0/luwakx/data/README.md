# Tag Template Files Provenance

This directory contains several CSV files that define DICOM tag templates for anonymization workflows, based on the 2025b DICOM standards.

## private_tags_template.csv

This CSV file contains a comprehensive template for private DICOM tag anonymization, combining data from:
- TCIA (The Cancer Imaging Archive) Private Tag Knowledge Base (https://wiki.cancerimagingarchive.net/download/attachments/3539047/TCIAPrivateTagKB-02-01-2024-formatted.csv?version=2&modificationDate=1707174689263&api=v2)
- DICOM Standard Safe Private Tags Table E.3.10-1 (https://dicom.nema.org/medical/dicom/current/output/chtml/part15/sect_E.3.10.html)

### How this file was generated

The file was generated using the retrieve_tags.py script:

```
python retrieve_tags.py --create_private_tag_template --merged_private_tags ../data/TagsArchive/private_tags_template.csv
```

This command:
1. Downloads the TCIA Private Tag Knowledge Base CSV
2. Fetches the DICOM Safe Private Tags table
3. Merges and cross-references the data
4. Generates a unified template with anonymization recommendations

## standard_tags_template.csv

This CSV file contains a comprehensive template for standard DICOM tag anonymization, combining data from:
- TCIA Submission and De-identification Overview (Table 1) (https://wiki.cancerimagingarchive.net/display/Public/Submission+and+De-identification+Overview)
- DICOM Standard Anonymization Profile Table E.1-1 (https://dicom.nema.org/medical/dicom/current/output/html/part15.html#chapter_E)

### How this file was generated

The file was generated using the retrieve_tags.py script:

```
python retrieve_tags.py --create_standard_tag_template --merged_standard_tags ../data/TagsArchive/standard_tags_template.csv
```

This command:
1. Scrapes the TCIA standard tags table from their wiki
2. Fetches the DICOM standard anonymization table
3. Merges and processes the data with VR (Value Representation) information
4. Applies anonymization profile rules (basic profile, retain options, etc.)
5. Generates a unified template with specific anonymization actions

## deid.dicom.burnedin-pixel-recipe

This file is part of the basic deid recipe collection and contains comprehensive rules for detecting and handling burned-in pixel annotations in DICOM images. Burned-in annotations are text or graphics that have been permanently embedded into the pixel data of medical images and may contain patient identifying information that cannot be removed through standard DICOM header anonymization.

### Purpose

The burned-in pixel recipe defines:
- **Whitelist filters**: Image types and modalities that are known to be clean of burned-in annotations
- **Graylist filters**: Specific regions and coordinates where burned-in text commonly appears in different imaging equipment
- **Equipment-specific rules**: Tailored detection patterns for various manufacturer models and imaging protocols

### Content Structure

The recipe includes detection rules for:
- **CT scanners**: Siemens Sensation 64, GE LightSpeed VCT, Somatom Definition AS+
- **Common burned-in locations**: Dose reports, localizer images, enhancement curves, reconstruction metadata
- **Coordinate-based detection**: Specific pixel regions where annotations typically appear (e.g., `coordinates 0,0,512,121`)

### Integration

This recipe is automatically integrated into the Luwak anonymization pipeline and works alongside the standard DICOM header anonymization to provide comprehensive de-identification by:
1. Identifying images with potential burned-in annotations
2. Flagging problematic regions for manual review or automated masking
3. Ensuring compliance with privacy regulations that require pixel-level anonymization

To record that pixel data has been reviewed and cleaned, add `"clean_pixel_data"` to the `recipes` list in your config. This injects DICOM CID 7050 code 113101 (*Clean Pixel Data Option*) into `DeidentificationMethodCodeSequence`. If manual review has confirmed no burned-in PHI is present, set `"bypassCleanPixelData": true` to skip the automated service while still updating the code sequence.

## File Usage

These files are used by the Luwak anonymization pipeline to:
- Define which private tags should be kept, removed, or anonymized
- Specify anonymization actions for standard DICOM tags
- Detect and handle burned-in pixel annotations in medical images
- Provide metadata for recipe generation and validation

All files ensure reproducible, standards-compliant anonymization workflows based on official DICOM specifications and community best practices, including comprehensive pixel-level de-identification.

## Additional Configuration Options

### Manually Revised Tag Files

You can override the default tag templates by specifying custom CSV files for standard and private tags:

```json
"customTags": {
  "standard": "./data/custom_standard_tags.csv",
  "private": "./data/custom_private_tags.csv"
}
```
- If only one is provided, only that template is overridden.
- If the file does not exist, the default template is used.

### Analysis Cache Options

Control persistent storage for patient UID database and LLM cache:

```json
"analysisCacheFolder": "./analysis_cache"
```
- `analysisCacheFolder`: Path to folder for analysis databases (`patient_uid.db` and `llm_cache.db`)
  - If specified: Databases persist in this folder across runs
  - If not specified: Temporary databases are created and deleted after processing
  - Enables consistent patient ID and UID mappings across multiple anonymization runs
  - Enables LLM cache reuse for cost savings and performance

### Pixel Cleaning Options

Control whether burned-in pixel cleaning is performed or bypassed:

```json
"recipes": ["basic_profile", "clean_pixel_data"],
"bypassCleanPixelData": true
```
- `clean_pixel_data` in `recipes`: Activates the Clean Pixel Data Option. Injects DICOM CID 7050 code 113101 into `DeidentificationMethodCodeSequence` when pixel cleaning succeeds (or is bypassed).
- `bypassCleanPixelData`: If `true`, skips the `CleanPixelDataService` execution. Use when burned-in PHI has been verified absent by manual review. The DICOM code is still injected. (default: `false`)

### Test Options

Options for testing and development, including mask defacer support:

```json
"testOptions": {
  "useExistingMaskDefacer": ["/path/to/mask1.nii.gz", "/path/to/mask2.nii.gz"]
}
```
- `useExistingMaskDefacer`: List of file paths for mask defacer files used in testing.
