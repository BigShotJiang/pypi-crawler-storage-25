"""prollama — Intelligent LLM Execution Layer for developer teams.

Anonymize code, route models intelligently, solve tickets autonomously.
"""

__version__ = "0.1.2"
__all__ = ["Config", "Proxy", "TaskExecutor", "Anonymizer"]

from prollama.config import Config
