"""Configuration loading and management for prollama."""

from __future__ import annotations

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_CONFIG_DIR = Path.home() / ".prollama"
DEFAULT_CONFIG_FILE = DEFAULT_CONFIG_DIR / "config.yaml"
DEFAULT_PROXY_HOST = "127.0.0.1"
DEFAULT_PROXY_PORT = 8741

DEFAULT_CONFIG_TEMPLATE = """\
# prollama configuration
# Docs: https://docs.prollama.dev/config

providers:
  - name: ollama
    base_url: http://localhost:11434/v1
    models: [qwen2.5-coder:7b]

  # Uncomment to add cloud providers:
  # - name: openai
  #   api_key: ${OPENAI_API_KEY}
  #   models: [gpt-4o-mini, gpt-4o]
  #
  # - name: anthropic
  #   api_key: ${ANTHROPIC_API_KEY}
  #   models: [claude-sonnet-4-20250514]

privacy:
  level: full          # none | basic | full
  ast_languages: [python, javascript, typescript]

routing:
  strategy: cost-optimized   # cost-optimized | quality-first | local-first
  fallback: true

proxy:
  host: "127.0.0.1"
  port: 8741

executor:
  max_iterations: 5
  budget: 5.00
  strategy: auto       # auto | cheap | quality | local-only
"""


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

class ProviderConfig(BaseModel):
    name: str
    base_url: str | None = None
    api_key: str | None = None
    models: list[str] = Field(default_factory=list)

    def resolve_api_key(self) -> str | None:
        """Expand $ENV_VAR references in api_key."""
        if self.api_key and self.api_key.startswith("${") and self.api_key.endswith("}"):
            env_var = self.api_key[2:-1]
            return os.environ.get(env_var)
        return self.api_key


class PrivacyConfig(BaseModel):
    level: str = "full"  # none | basic | full
    ast_languages: list[str] = Field(default_factory=lambda: ["python"])


class RoutingConfig(BaseModel):
    strategy: str = "cost-optimized"
    fallback: bool = True


class ProxyConfig(BaseModel):
    host: str = DEFAULT_PROXY_HOST
    port: int = DEFAULT_PROXY_PORT


class ExecutorConfig(BaseModel):
    max_iterations: int = 5
    budget: float = 5.00
    strategy: str = "auto"


class Config(BaseModel):
    """Root configuration for prollama."""

    providers: list[ProviderConfig] = Field(default_factory=list)
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    routing: RoutingConfig = Field(default_factory=RoutingConfig)
    proxy: ProxyConfig = Field(default_factory=ProxyConfig)
    executor: ExecutorConfig = Field(default_factory=ExecutorConfig)

    # -- I/O helpers --------------------------------------------------------

    @classmethod
    def load(cls, path: Path | None = None) -> Config:
        """Load config from YAML file, falling back to defaults."""
        path = path or DEFAULT_CONFIG_FILE
        if not path.exists():
            return cls()
        raw = yaml.safe_load(path.read_text()) or {}
        return cls(**raw)

    def save(self, path: Path | None = None) -> Path:
        """Persist current config to YAML."""
        path = path or DEFAULT_CONFIG_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        data = self.model_dump(mode="json")
        path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
        return path

    @staticmethod
    def write_template(path: Path | None = None) -> Path:
        """Write the default config template."""
        path = path or DEFAULT_CONFIG_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(DEFAULT_CONFIG_TEMPLATE)
        return path

    @property
    def proxy_url(self) -> str:
        return f"http://{self.proxy.host}:{self.proxy.port}"

    def get_provider(self, name: str) -> ProviderConfig | None:
        for p in self.providers:
            if p.name == name:
                return p
        return None

    def provider_names(self) -> list[str]:
        return [p.name for p in self.providers]
