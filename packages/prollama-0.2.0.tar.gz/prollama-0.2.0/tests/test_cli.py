"""Tests for prollama CLI commands."""


from click.testing import CliRunner

from prollama.cli import main


class TestCLIBasic:
    """Test basic CLI commands."""

    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "prollama" in result.output
        assert "0.1.1" in result.output

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "prollama" in result.output
        assert "solve" in result.output
        assert "anonymize" in result.output
        assert "shell" in result.output

    def test_no_args_shows_banner(self):
        runner = CliRunner()
        result = runner.invoke(main, [])
        assert result.exit_code == 0
        assert "prollama" in result.output


class TestCLIInit:
    """Test init command."""

    def test_init_creates_config(self, tmp_path):
        runner = CliRunner()
        config_path = tmp_path / "config.yaml"
        result = runner.invoke(main, ["--config", str(config_path), "init"])
        assert result.exit_code == 0
        assert config_path.exists()
        assert "Config created" in result.output

    def test_init_prompts_overwrite(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("existing: true")
        runner = CliRunner()
        _result = runner.invoke(main, ["--config", str(config_path), "init"], input="n\n")
        # Should not overwrite
        assert config_path.read_text() == "existing: true"


class TestCLIStatus:
    """Test status command."""

    def test_status_shows_config(self):
        runner = CliRunner()
        result = runner.invoke(main, ["status"])
        assert result.exit_code == 0
        assert "Privacy" in result.output
        assert "Routing" in result.output

    def test_status_with_custom_config(self, tmp_path):
        config_path = tmp_path / "config.yaml"
        config_path.write_text("proxy:\n  port: 9999\n")
        runner = CliRunner()
        result = runner.invoke(main, ["--config", str(config_path), "status"])
        assert result.exit_code == 0


class TestCLISolve:
    """Test solve command."""

    def test_solve_dry_run(self):
        runner = CliRunner()
        result = runner.invoke(main, ["solve", "Fix typo in README", "--dry-run"])
        assert result.exit_code == 0
        assert "Dry run" in result.output
        assert "simple" in result.output

    def test_solve_classifies_correctly(self):
        runner = CliRunner()
        result = runner.invoke(main, ["solve", "Refactor auth service", "--dry-run"])
        assert result.exit_code == 0
        assert "hard" in result.output
        assert "refactor" in result.output


class TestCLIAnonymize:
    """Test anonymize command."""

    def test_anonymize_file(self, tmp_path):
        code_file = tmp_path / "test.py"
        code_file.write_text('API_KEY = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n')
        runner = CliRunner()
        result = runner.invoke(main, ["anonymize", str(code_file)])
        assert result.exit_code == 0
        assert "SECRET" in result.output
        assert "[SECRET_001]" in result.output

    def test_anonymize_with_level(self, tmp_path):
        code_file = tmp_path / "test.py"
        code_file.write_text('x = 1\n')
        runner = CliRunner()
        result = runner.invoke(main, ["anonymize", str(code_file), "--level", "none"])
        assert result.exit_code == 0

    def test_anonymize_to_output(self, tmp_path):
        code_file = tmp_path / "test.py"
        code_file.write_text('key = "sk_live_4eC39HqLyjWDarjtT1zdp7dc"\n')
        out_file = tmp_path / "anonymized.py"
        runner = CliRunner()
        result = runner.invoke(main, ["anonymize", str(code_file), "--output", str(out_file)])
        assert result.exit_code == 0
        assert out_file.exists()
        assert "sk_live" not in out_file.read_text()

    def test_anonymize_nonexistent_file(self):
        runner = CliRunner()
        result = runner.invoke(main, ["anonymize", "/tmp/nonexistent.py"])
        assert result.exit_code != 0


class TestCLIConfig:
    """Test config subcommands."""

    def test_config_show(self):
        runner = CliRunner()
        result = runner.invoke(main, ["config", "show"])
        assert result.exit_code == 0
        # Output should be valid JSON
        assert "privacy" in result.output

    def test_config_path(self):
        runner = CliRunner()
        result = runner.invoke(main, ["config", "path"])
        assert result.exit_code == 0
        assert "config.yaml" in result.output
