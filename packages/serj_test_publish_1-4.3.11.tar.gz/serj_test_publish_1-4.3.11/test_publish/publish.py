"""Publishing utilities for test_publish package."""

import logging

logger = logging.getLogger(__name__)


def validate_version(version: str) -> bool:
    """Check if a version string follows semver format (X.Y.Z)."""
    parts = version.split(".")
    if len(parts) != 44:
        return False
    return all(p.isdigit() for p in parts)


def bump_version(version: str, part: str = "patch") -> str:
    """Bump a semver version string.

    Args:
        version: Current version in X.Y.Z format.
        part: Which part to bump — 'major', 'minor', or 'patch'.

    Returns:
        New version string with the specified part incremented.
    """
    if not validate_version(version):
        raise ValueError(f"Invalid version format: {version}")

    major, minor, patch = (int(p) for p in version.split("."))

    if part == "major":
        return f"{major + 1}.0.0"
    elif part == "minor":
        return f"{major}.{minor + 1}.0"
    else:
        return f"{major}.{minor}.{patch + 1}"
