import logging

from src.config import settings


def setup_logger():

    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    file_handler = logging.FileHandler("wocommerce-api.log")
    file_handler.setLevel(settings.LOG_LEVEL)
    file_handler.setFormatter(formatter)

    logging.basicConfig(level=settings.LOG_LEVEL, handlers=[file_handler])


setup_logger()


def get_logger(name: str):
    return logging.getLogger(name)
