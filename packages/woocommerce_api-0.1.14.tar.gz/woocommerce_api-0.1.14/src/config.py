from typing import Literal

from pydantic_settings import BaseSettings


class Config(BaseSettings):
    APP_NAME: str = "Woocommerce API"
    DEBUG: bool = True
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    WOOCOMMERCE_BASE_URL: str
    WOCOMMERCE_AUTH: tuple[str, str]


settings = Config()
