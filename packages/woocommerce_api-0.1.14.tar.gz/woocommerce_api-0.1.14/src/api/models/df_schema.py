import polars as pl

schema = {
    "name": pl.String,
    "type": pl.String,
    "regular_price": pl.Float64,
    "description": pl.String,
    "categories": pl.List(pl.Struct),
    "images": pl.List(pl.Struct),
    "brands": pl.List(pl.Int64),
    "sku": pl.String,
    "meta_data": pl.List(pl.Struct),
}
