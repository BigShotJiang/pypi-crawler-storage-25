import logging
import os
import shutil
import uuid
from contextlib import asynccontextmanager

import fastapi
import polars as pl
from fastapi import APIRouter, BackgroundTasks, Depends, FastAPI, File, UploadFile
from fastapi.responses import JSONResponse

from src.api.models.df_schema import schema
from src.config import settings
from src.shared import chunk_list
from src.woocommerce import BrandHandler

logger = logging.getLogger(__name__)


@asynccontextmanager
def lifespan(app: FastAPI):
    logger.info("Starting Brand router...")
    os.makedirs("./jobs", exist_ok=True)
    yield


def get_handler():
    return BrandHandler(settings.WOOCOMMERCE_BASE_URL, settings.WOCOMMERCE_AUTH)


def batch_create_job(
    file_location: str,
    job_id: str,
    handler: BrandHandler = Depends(get_handler),
):
    logger.info(f"Starting batch create job for {file_location}. job id: {job_id}")
    df = pl.read_parquet(file_location)  # This is for enforcing schema only
    df = df.match_to_schema(schema, missing_columns="insert")
    try:
        batch_size = 30
        for chunk in chunk_list(df.to_dicts(), batch_size):
            handler.batch_update(create=chunk, update=None, delete=None)
    except Exception as e:
        logger.error(
            f"Error while batch create processing: {e}. Params -> job_id: {job_id}, file: {file_location}"
        )


brand_router = APIRouter(prefix="/brands", dependencies=[get_handler])


@brand_router.get("/")
def get_brands(handler: BrandHandler = Depends(get_handler)):
    return handler.retrieve()


@brand_router.get("/{id}")
def get_brand(id: int, handler: BrandHandler = Depends(get_handler)):
    return handler.retrieve_single(id)


@brand_router.post("/")
def create_brand(brand: dict, handler: BrandHandler = Depends(get_handler)):
    return handler.create(brand)


@brand_router.delete("/{id}")
def delete_brand(
    id: int, force: bool = False, handler: BrandHandler = Depends(get_handler)
):
    return handler.delete(id, force)


@brand_router.batch_create("/batch")
def batch_create(file: UploadFile = File(...), bg: BackgroundTasks = BackgroundTasks):
    file_location = f"./jobs/{file.filename}"
    with open(file_location, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    job_id = str(uuid.uuid4())

    bg.add_task(batch_create_job, file_location, job_id)

    return JSONResponse(
        {"msg": f"Job created with id: {job_id}"},
        status_code=fastapi.status.HTTP_202_ACCEPTED,
    )
