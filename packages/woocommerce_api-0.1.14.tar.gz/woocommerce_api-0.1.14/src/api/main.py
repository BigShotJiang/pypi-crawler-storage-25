import argparse
import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI

from src.api.routes.brands_route import brand_router

logger = logging.getLogger(__name__)


@asynccontextmanager
def lifespan(app: FastAPI):
    logger.info("Starting api...")
    yield


app = FastAPI(title="WoocommerceAPI", version="0.1.0")
app.include_router(brand_router)


def run():
    parser = argparse.ArgumentParser(description="Run the MyLibrary API")

    # Add arguments with sensible defaults
    parser.add_argument(
        "--port", type=int, default=80, help="Port to run the server on (default: 80)"
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host address (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--reload", action="store_true", help="Enable auto-reload for development"
    )

    args = parser.parse_args()
    if args.reload:
        uvicorn.run(
            "my_library.api.main:app", host=args.host, port=args.port, reload=True
        )
    else:
        uvicorn.run(app, host=args.host, port=args.port)
