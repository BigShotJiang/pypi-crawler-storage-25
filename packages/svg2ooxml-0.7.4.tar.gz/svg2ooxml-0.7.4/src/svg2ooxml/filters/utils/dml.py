"""Helpers for building exporter hook comments embedded in DrawingML."""

from __future__ import annotations

from collections.abc import Iterable, Mapping

# Import centralized XML builders for safe DrawingML generation
from lxml import etree

from svg2ooxml.common.boundaries import parse_wrapped_xml_fragment
from svg2ooxml.common.svg_refs import local_name as _local_name
from svg2ooxml.drawingml.effect_fragments import (
    extract_safe_effect_children,
    sanitize_custom_effect_fragment,
)
from svg2ooxml.drawingml.xml_builder import NS_A, a_elem, graft_xml_fragment, to_string


def build_exporter_hook(
    name: str,
    attributes: Mapping[str, object] | None = None,
    *,
    payloads: Iterable[str] | None = None,
) -> str:
    """Return a comment tag that downstream exporters can interpret."""

    parts: list[str] = []
    if attributes:
        for key, value in attributes.items():
            parts.append(f'{key}="{_format_value(value)}"')
    if payloads:
        for index, fragment in enumerate(payloads):
            parts.append(f'payload{index}="{_escape(fragment)}"')

    suffix = ""
    if parts:
        suffix = " " + " ".join(parts)
    return f"<!-- svg2ooxml:{name}{suffix} -->"


def is_effect_list(fragment: str | None) -> bool:
    """Return True when *fragment* looks like a DrawingML effect list."""

    if not fragment:
        return False
    return fragment.lstrip().startswith("<a:effectLst")


def is_effect_dag(fragment: str | None) -> bool:
    """Return True when *fragment* looks like a DrawingML effect DAG."""

    if not fragment:
        return False
    return fragment.lstrip().startswith("<a:effectDag")


def is_effect_container(fragment: str | None) -> bool:
    """Return True when *fragment* is an effect list or effect DAG."""

    if not fragment:
        return False
    stripped = fragment.lstrip()
    return stripped.startswith("<a:effectLst") or stripped.startswith("<a:effectDag")


def extract_effect_children(fragment: str) -> str:
    """Return the inner XML of an effect container fragment."""

    text = fragment.strip()
    if not text:
        return ""
    safe_children = extract_safe_effect_children(text)
    if safe_children:
        return safe_children
    if is_effect_container(text):
        return ""
    try:
        return _flatten_effect_children(text)
    except Exception:
        return sanitize_custom_effect_fragment(text)


def _flatten_effect_children(fragment: str) -> str:
    """Flatten effect container fragments into a single sequence of effect nodes."""

    temp = parse_wrapped_xml_fragment(fragment, namespaces={"a": NS_A})
    parts: list[str] = []
    for child in temp:
        if _local_name(child.tag) in {"effectLst", "effectDag"}:
            for grandchild in child:
                if _local_name(grandchild.tag) == "cont":
                    continue
                parts.append(_serialize_node(grandchild))
        else:
            parts.append(_serialize_node(child))
    return "".join(parts)


def _serialize_node(node: etree._Element) -> str:
    if isinstance(node, (etree._Comment, etree._ProcessingInstruction)):
        return etree.tostring(node, encoding="unicode")
    return to_string(node)


def merge_effect_fragments(
    *fragments: str | None,
    prefer_container: str = "effectLst",
) -> str:
    """Merge zero or more fragments into a single effect container."""

    children: list[str] = []
    target_container = "effectDag" if prefer_container == "effectDag" else "effectLst"
    for fragment in fragments:
        if not fragment:
            continue
        safe_fragment = sanitize_custom_effect_fragment(fragment)
        if not safe_fragment:
            continue
        if target_container != "effectDag" and is_effect_dag(safe_fragment):
            target_container = "effectDag"
        inner = (
            extract_effect_children(safe_fragment)
            if is_effect_container(safe_fragment)
            else safe_fragment
        )
        if inner:
            children.append(inner)
    if not children:
        return ""

    # Build effect container using lxml
    effect_root = a_elem(target_container)
    if target_container == "effectDag":
        etree.SubElement(effect_root, f"{{{NS_A}}}cont")

    # Parse and append child XML fragments
    for child_xml in children:
        try:
            graft_xml_fragment(effect_root, child_xml)
        except Exception:
            continue

    return to_string(effect_root)


def _format_value(value: object) -> str:
    if isinstance(value, float):
        return f"{value:.6g}"
    if isinstance(value, (list, tuple)):
        return " ".join(_format_value(item) for item in value)
    return _escape(str(value))


def _escape(value: str) -> str:
    return value.replace('"', "&quot;")


__all__ = [
    "build_exporter_hook",
    "is_effect_list",
    "is_effect_dag",
    "is_effect_container",
    "extract_effect_children",
    "merge_effect_fragments",
]
