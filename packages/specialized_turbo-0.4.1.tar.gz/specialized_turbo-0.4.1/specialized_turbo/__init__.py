"""
specialized_turbo -- talk to Specialized Turbo e-bikes over BLE.

Quick start::

    import asyncio
    from specialized_turbo import SpecializedConnection, TelemetryMonitor

    async def main():
        async with SpecializedConnection("DC:DD:BB:4A:D6:55", pin="946166") as conn:
            monitor = TelemetryMonitor(conn)
            await monitor.start()

            async for msg in monitor.stream():
                print(f"{msg.field_name} = {msg.converted_value} {msg.unit}")

    asyncio.run(main())
"""

from __future__ import annotations

from .protocol import (
    # UUIDs (TCX defaults)
    SERVICE_DATA_NOTIFY as SERVICE_DATA_NOTIFY,
    SERVICE_DATA_REQUEST as SERVICE_DATA_REQUEST,
    SERVICE_DATA_WRITE as SERVICE_DATA_WRITE,
    CHAR_NOTIFY as CHAR_NOTIFY,
    CHAR_REQUEST_READ as CHAR_REQUEST_READ,
    CHAR_REQUEST_WRITE as CHAR_REQUEST_WRITE,
    CHAR_WRITE as CHAR_WRITE,
    # TCU1 UUIDs
    SERVICE_DATA_NOTIFY_TCU1 as SERVICE_DATA_NOTIFY_TCU1,
    SERVICE_DATA_REQUEST_TCU1 as SERVICE_DATA_REQUEST_TCU1,
    SERVICE_DATA_WRITE_TCU1 as SERVICE_DATA_WRITE_TCU1,
    CHAR_NOTIFY_TCU1 as CHAR_NOTIFY_TCU1,
    CHAR_REQUEST_READ_TCU1 as CHAR_REQUEST_READ_TCU1,
    CHAR_REQUEST_WRITE_TCU1 as CHAR_REQUEST_WRITE_TCU1,
    CHAR_WRITE_TCU1 as CHAR_WRITE_TCU1,
    # Generation-aware UUID helpers
    BLEProfile as BLEProfile,
    get_uuid as get_uuid,
    get_char_notify as get_char_notify,
    get_char_request_read as get_char_request_read,
    get_char_request_write as get_char_request_write,
    get_char_write as get_char_write,
    detect_generation as detect_generation,
    # Enums
    Sender as Sender,
    BatteryChannel as BatteryChannel,
    MotorChannel as MotorChannel,
    BikeSettingsChannel as BikeSettingsChannel,
    AssistLevel as AssistLevel,
    # Parsing
    parse_message as parse_message,
    ParsedMessage as ParsedMessage,
    FieldDefinition as FieldDefinition,
    get_field_def as get_field_def,
    all_field_defs as all_field_defs,
    build_request as build_request,
    build_write_command as build_write_command,
    is_specialized_advertisement as is_specialized_advertisement,
    TCU1_POLL_FIELDS as TCU1_POLL_FIELDS,
    # Company IDs
    NORDIC_COMPANY_ID as NORDIC_COMPANY_ID,
    APPLE_COMPANY_ID as APPLE_COMPANY_ID,
    SIMPLO_COMPANY_ID as SIMPLO_COMPANY_ID,
)
from .models import (
    BatteryState as BatteryState,
    MotorState as MotorState,
    BikeSettings as BikeSettings,
    SystemState as SystemState,
    TelemetrySnapshot as TelemetrySnapshot,
)
from .connection import (
    SpecializedConnection as SpecializedConnection,
    scan_for_bikes as scan_for_bikes,
    find_bike_by_address as find_bike_by_address,
)
from .telemetry import (
    TelemetryMonitor as TelemetryMonitor,
    run_telemetry_session as run_telemetry_session,
)
from .framing import (
    compute_crc16_ccitt as compute_crc16_ccitt,
    pack_tcx as pack_tcx,
    unpack_tcx as unpack_tcx,
    is_framed_packet as is_framed_packet,
    strip_clear_prefix as strip_clear_prefix,
)
from .parameters import (
    BikeParameter as BikeParameter,
    TCXFieldDefinition as TCXFieldDefinition,
    get_tcx_field as get_tcx_field,
    all_tcx_fields as all_tcx_fields,
    encode_parameter_id as encode_parameter_id,
    decode_parameter_id as decode_parameter_id,
)
from .encryption import (
    encrypt_packet as encrypt_packet,
    decrypt_packet as decrypt_packet,
    derive_key as derive_key,
    is_encryptable as is_encryptable,
)
from .session import (
    ProtocolSession as ProtocolSession,
    TCU1Session as TCU1Session,
    TCXSession as TCXSession,
)
from .protocol import (
    parse_tcx_message as parse_tcx_message,
    build_tcx_request as build_tcx_request,
    build_tcx_write as build_tcx_write,
)
from .coordinator_helpers import (
    TCX_POLL_PARAMS as TCX_POLL_PARAMS,
    parse_notification as parse_notification,
    poll_tcu1 as poll_tcu1,
    poll_tcx as poll_tcx,
    identify_tcx as identify_tcx,
)

__all__ = [
    # Protocol — TCX UUIDs (backward-compatible defaults)
    "SERVICE_DATA_NOTIFY",
    "SERVICE_DATA_REQUEST",
    "SERVICE_DATA_WRITE",
    "CHAR_NOTIFY",
    "CHAR_REQUEST_READ",
    "CHAR_REQUEST_WRITE",
    "CHAR_WRITE",
    # Protocol — TCU1 UUIDs
    "SERVICE_DATA_NOTIFY_TCU1",
    "SERVICE_DATA_REQUEST_TCU1",
    "SERVICE_DATA_WRITE_TCU1",
    "CHAR_NOTIFY_TCU1",
    "CHAR_REQUEST_READ_TCU1",
    "CHAR_REQUEST_WRITE_TCU1",
    "CHAR_WRITE_TCU1",
    # Protocol — generation-aware helpers
    "BLEProfile",
    "get_uuid",
    "get_char_notify",
    "get_char_request_read",
    "get_char_request_write",
    "get_char_write",
    "detect_generation",
    # Enums
    "Sender",
    "BatteryChannel",
    "MotorChannel",
    "BikeSettingsChannel",
    "AssistLevel",
    # Parsing
    "parse_message",
    "ParsedMessage",
    "FieldDefinition",
    "get_field_def",
    "all_field_defs",
    "build_request",
    "build_write_command",
    "is_specialized_advertisement",
    "TCU1_POLL_FIELDS",
    # Company IDs
    "NORDIC_COMPANY_ID",
    "APPLE_COMPANY_ID",
    "SIMPLO_COMPANY_ID",
    # Models
    "BatteryState",
    "MotorState",
    "BikeSettings",
    "SystemState",
    "TelemetrySnapshot",
    # Connection
    "SpecializedConnection",
    "scan_for_bikes",
    "find_bike_by_address",
    # Telemetry
    "TelemetryMonitor",
    "run_telemetry_session",
    # Framing
    "compute_crc16_ccitt",
    "pack_tcx",
    "unpack_tcx",
    "is_framed_packet",
    # Parameters (TCX2+)
    "BikeParameter",
    "TCXFieldDefinition",
    "get_tcx_field",
    "all_tcx_fields",
    "encode_parameter_id",
    "decode_parameter_id",
    "parse_tcx_message",
    "build_tcx_request",
    "build_tcx_write",
    # Encryption
    "encrypt_packet",
    "decrypt_packet",
    "derive_key",
    "is_encryptable",
    # Session
    "ProtocolSession",
    "TCU1Session",
    "TCXSession",
    # Coordinator helpers
    "TCX_POLL_PARAMS",
    "parse_notification",
    "poll_tcu1",
    "poll_tcx",
    "identify_tcx",
]

__version__ = "0.4.1"
