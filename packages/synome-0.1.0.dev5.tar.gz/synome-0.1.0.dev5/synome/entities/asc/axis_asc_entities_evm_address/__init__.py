from typing import Annotated
from pydantic import AfterValidator
from axis_synome.spec_support.evm_address import validate_eip55
EvmAddress = Annotated[str, AfterValidator(validate_eip55)]