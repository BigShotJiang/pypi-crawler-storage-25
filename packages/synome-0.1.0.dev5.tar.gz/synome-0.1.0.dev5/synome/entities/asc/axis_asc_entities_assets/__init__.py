from client.synome.entities.asc.axis_asc_entities_evm_address import EvmAddress
from client.synome.entities.asc.axis_asc_entities_networks import Network
from client.synome.entities.asc.axis_asc_entities_protocol_sets import Protocol
from client.synome.entities.asc.axis_asc_entities_tokens import Token
from axis_synome.spec_support.validated_dataclass import validated_dataclass

@validated_dataclass
class Asset:
    token: Token
    network: Network
    protocol: Protocol
    address: EvmAddress
    underlying_asset: Token
    underlying_asset_address: EvmAddress
    underlying_asset_source: str
    source: str | None = None