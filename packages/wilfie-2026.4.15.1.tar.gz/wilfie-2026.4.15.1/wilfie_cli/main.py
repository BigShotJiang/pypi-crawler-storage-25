"""Public `wilfie` CLI entrypoint."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time
import webbrowser
from typing import Any

from wilfie_cli import __version__
from wilfie_cli.http_client import ApiError
from wilfie_cli.http_client import WilfieHttpClient
from wilfie_cli.render import emit_payload
from wilfie_cli.render import emit_stream_payload
from wilfie_cli.storage import OAuthTokens
from wilfie_cli.storage import ProfileStore


READ_SCOPE_FALLBACKS = {
    "wms.read": "wms.write",
    "workflows.read": "workflows.write",
}

WMS_DOCUMENT_DIAGNOSTIC_KINDS = (
    "dispatch",
    "dispatch_manifest",
    "fulfillment",
    "fulfillment_order",
    "pick_job",
    "pick_plan",
    "put_job",
    "put_plan",
)
WMS_PACKAGE_PROFILE_CLASSES = (
    "carton",
    "satchel",
    "envelope",
    "tube",
    "pallet",
    "crate",
    "custom",
)


class CliError(RuntimeError):
    """User-facing CLI error."""


def _parse_query_pairs(values: list[str] | None) -> dict[str, Any]:
    params: dict[str, Any] = {}
    for raw in values or []:
        if "=" not in raw:
            raise CliError(
                "Invalid --param value. Expected key=value format."
            )
        key, value = raw.split("=", 1)
        normalized_key = key.strip()
        if not normalized_key:
            raise CliError("Query parameter key cannot be empty.")
        normalized_value = value.strip()
        if normalized_key in params:
            existing = params[normalized_key]
            if isinstance(existing, list):
                existing.append(normalized_value)
            else:
                params[normalized_key] = [existing, normalized_value]
        else:
            params[normalized_key] = normalized_value
    return params


def _normalize_wms_query_path(*, workspace_code: str, path: str) -> str:
    normalized = path.strip()
    if not normalized:
        raise CliError("--path is required.")
    if "://" in normalized:
        raise CliError("--path must be an API path, not a full URL.")

    raw = normalized.lstrip("/")
    suffix = ""

    for root in ("api/v2/workspaces/", "workspaces/"):
        if raw.startswith(root):
            remainder = raw.removeprefix(root)
            if "/" not in remainder:
                raise CliError("--path is missing the /wms/ segment.")
            workspace_in_path, rest = remainder.split("/", 1)
            if workspace_in_path not in {workspace_code, "{workspace_code}"}:
                raise CliError(
                    "--path workspace must match --workspace."
                )
            if not rest.startswith("wms/"):
                raise CliError("--path must target a /wms/ endpoint.")
            suffix = rest.removeprefix("wms/")
            break

    if not suffix:
        if raw.startswith("api/v2/wms/"):
            suffix = raw.removeprefix("api/v2/wms/")
        elif raw.startswith("wms/"):
            suffix = raw.removeprefix("wms/")
        else:
            suffix = raw

    suffix = suffix.lstrip("/")
    if not suffix:
        raise CliError("--path must include a WMS endpoint path.")
    return f"/api/v2/workspaces/{workspace_code}/wms/{suffix}"


def _normalize_wms_document_kind(value: str) -> str:
    normalized = str(value or "").strip().lower()
    if not normalized:
        raise CliError("--kind is required.")
    if normalized not in WMS_DOCUMENT_DIAGNOSTIC_KINDS:
        allowed = ", ".join(WMS_DOCUMENT_DIAGNOSTIC_KINDS)
        raise CliError(
            f"Unsupported --kind `{normalized}`. Use one of: {allowed}."
        )
    return normalized


def _normalize_scopes(values: list[str] | tuple[str, ...] | None) -> list[str]:
    if not values:
        return []
    normalized = {str(value).strip() for value in values if str(value).strip()}
    return sorted(normalized)


def _to_cli_error(error: ApiError) -> CliError:
    detail = error.detail
    if isinstance(detail, (dict, list)):
        detail_text = json.dumps(detail, sort_keys=True)
    else:
        detail_text = str(detail)
    label = error.code if error.code else "api_error"
    return CliError(f"HTTP {error.status_code} [{label}] {detail_text}")


def _load_json_file(path: str | None) -> dict[str, Any]:
    if path is None:
        return {}
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CliError("JSON payload must be an object.")
    return payload


def _mask_secret(value: str | None) -> str | None:
    if not value:
        return None
    if len(value) > 16:
        return f"{value[:9]}...{value[-4:]}"
    return "***"


class CliState:
    """Command runtime state and auth/token management."""

    def __init__(
        self,
        *,
        profile_name: str,
        base_url_override: str | None,
        output_override: str | None,
        auth_mode: str,
    ):
        self.profile_name = profile_name
        self.store = ProfileStore()
        self.profile = self.store.load_profile(profile_name)
        if base_url_override:
            self.profile.base_url = base_url_override.rstrip("/")
        if output_override:
            self.profile.output = output_override
        self.auth_mode = auth_mode
        self._validated_workspaces: set[str] = set()

    @property
    def output_mode(self) -> str:
        mode = (self.profile.output or "table").strip().lower()
        if mode in {"json", "table"}:
            return mode
        return "table"

    @property
    def base_url(self) -> str:
        value = (self.profile.base_url or "").strip().rstrip("/")
        if value:
            return value
        return "https://wilfie.ai"

    def save(self) -> None:
        self.store.save_profile(self.profile_name, self.profile)

    def has_oauth_credentials(self) -> bool:
        return bool(
            self.profile.oauth.access_token or self.profile.oauth.refresh_token
        )

    def resolve_auth_mode(self, *, allow_api_key: bool) -> str:
        if self.auth_mode in {"oauth", "api-key"}:
            if self.auth_mode == "api-key" and not allow_api_key:
                raise CliError("This command requires OAuth auth mode.")
            return self.auth_mode
        if self.has_oauth_credentials():
            return "oauth"
        if allow_api_key and self.profile.api_key:
            return "api-key"
        return "oauth"

    def _oauth_expired(self) -> bool:
        expires_at = self.profile.oauth.expires_at_epoch
        if expires_at is None:
            return False
        return expires_at <= int(time.time()) + 30

    def _oauth_access_token_for_request(self) -> str | None:
        if self.profile.oauth.access_token and not self._oauth_expired():
            return self.profile.oauth.access_token
        if self.refresh_oauth(silent=True):
            return self.profile.oauth.access_token
        return self.profile.oauth.access_token

    def _api_key_for_request(self) -> str | None:
        return self.profile.api_key

    def _http_client(self) -> WilfieHttpClient:
        return WilfieHttpClient(
            base_url=self.base_url,
            oauth_token_getter=self._oauth_access_token_for_request,
            api_key_getter=self._api_key_for_request,
            oauth_refresh_callback=lambda: self.refresh_oauth(silent=True),
        )

    def _update_oauth_tokens(self, payload: dict[str, Any]) -> None:
        expires_in = payload.get("expires_in")
        expires_epoch = None
        if isinstance(expires_in, int):
            expires_epoch = int(time.time()) + max(1, expires_in) - 30
        self.profile.oauth = OAuthTokens(
            access_token=str(payload.get("access_token") or ""),
            refresh_token=str(payload.get("refresh_token") or ""),
            token_type=str(payload.get("token_type") or "Bearer"),
            expires_at_epoch=expires_epoch,
            client_id=str(
                payload.get("client_id")
                or self.profile.oauth.client_id
                or "wilfie-cli"
            ),
            scope=(
                str(payload.get("scope"))
                if payload.get("scope") is not None
                else self.profile.oauth.scope
            ),
        )
        self.save()

    def login_device_flow(
        self,
        *,
        client_id: str,
        scope: str,
        audience: str | None,
        open_browser: bool,
    ) -> dict[str, Any]:
        client = self._http_client()
        try:
            device_payload = client.request_json(
                "POST",
                "/api/v2/oauth/device_authorization",
                auth_mode="none",
                json_body={
                    "client_id": client_id,
                    "scope": scope,
                    **({"audience": audience} if audience else {}),
                },
                allow_refresh_retry=False,
            )
        except ApiError as error:
            raise _to_cli_error(error)

        if not isinstance(device_payload, dict):
            raise CliError(
                "Device authorization response was not a JSON object."
            )
        device_code = str(device_payload.get("device_code") or "")
        user_code = str(device_payload.get("user_code") or "")
        verification_uri = str(device_payload.get("verification_uri") or "")
        verification_uri_complete = str(
            device_payload.get("verification_uri_complete") or ""
        )
        expires_in = int(device_payload.get("expires_in") or 0)
        interval = max(1, int(device_payload.get("interval") or 5))

        if not device_code or not user_code or not verification_uri:
            raise CliError("Device authorization response is incomplete.")

        print(f"Verification URL: {verification_uri}")
        if verification_uri_complete:
            print(f"One-click URL: {verification_uri_complete}")
        print(f"User code: {user_code}")
        if open_browser and verification_uri_complete:
            try:
                webbrowser.open(verification_uri_complete)
            except Exception:  # noqa: BLE001
                pass

        deadline = time.time() + max(1, expires_in)
        while time.time() < deadline:
            time.sleep(interval)
            try:
                token_payload = client.request_json(
                    "POST",
                    "/api/v2/oauth/token",
                    auth_mode="none",
                    json_body={
                        "grant_type": (
                            "urn:ietf:params:oauth:grant-type:device_code"
                        ),
                        "client_id": client_id,
                        "device_code": device_code,
                    },
                    allow_refresh_retry=False,
                )
            except ApiError as error:
                if error.code == "authorization_pending":
                    continue
                if error.code == "slow_down":
                    interval += 1
                    continue
                if error.code in {"expired_token", "access_denied"}:
                    raise _to_cli_error(error)
                raise _to_cli_error(error)

            if not isinstance(token_payload, dict):
                raise CliError("Token response was not JSON.")
            if not token_payload.get("access_token"):
                raise CliError("Token response missing access token.")

            self._update_oauth_tokens(token_payload)
            self.profile.oauth.client_id = client_id
            self.save()
            return token_payload

        raise CliError("Device authorization timed out.")

    def refresh_oauth(self, *, silent: bool) -> bool:
        refresh_token = self.profile.oauth.refresh_token
        if not refresh_token:
            return False
        client_id = self.profile.oauth.client_id or "wilfie-cli"
        try:
            payload = self._http_client().request_json(
                "POST",
                "/api/v2/oauth/token",
                auth_mode="none",
                json_body={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "refresh_token": refresh_token,
                },
                allow_refresh_retry=False,
            )
        except ApiError as error:
            if not silent:
                raise _to_cli_error(error)
            return False
        if not isinstance(payload, dict) or not payload.get("access_token"):
            if not silent:
                raise CliError("Refresh response is invalid.")
            return False
        self._update_oauth_tokens(payload)
        return True

    def logout_oauth(self) -> None:
        refresh_token = self.profile.oauth.refresh_token
        client_id = self.profile.oauth.client_id or "wilfie-cli"
        if refresh_token:
            try:
                self._http_client().request_json(
                    "POST",
                    "/api/v2/oauth/revoke",
                    auth_mode="none",
                    json_body={
                        "client_id": client_id,
                        "token": refresh_token,
                        "token_type_hint": "refresh_token",
                    },
                    allow_refresh_retry=False,
                )
            except ApiError:
                pass
        self.profile.oauth = OAuthTokens(client_id=client_id)
        self.save()

    def set_api_key(self, *, api_key: str, scopes: list[str]) -> None:
        if not api_key.strip():
            raise CliError("API key cannot be empty.")
        self.profile.api_key = api_key.strip()
        self.profile.api_key_scopes = _normalize_scopes(scopes)
        self.save()

    def clear_api_key(self) -> None:
        self.profile.api_key = None
        self.profile.api_key_scopes = []
        self.save()

    def ensure_api_key_scope(self, required_scope: str | None) -> None:
        if required_scope is None:
            return
        if not self.profile.api_key:
            raise CliError("No API key is configured.")
        scopes = set(self.profile.api_key_scopes or [])
        if not scopes:
            raise CliError(
                "API key scopes are unknown. Reconfigure with "
                "`wilfie auth api-key set --scope ...`."
            )
        if required_scope in scopes:
            return
        write_fallback = READ_SCOPE_FALLBACKS.get(required_scope)
        if write_fallback and write_fallback in scopes:
            return
        raise CliError(
            f"Stored API key scopes do not include `{required_scope}`."
        )

    def preflight_workspace_access(
        self, *, workspace_code: str, auth_mode: str
    ) -> None:
        if auth_mode != "oauth":
            return
        if workspace_code in self._validated_workspaces:
            return
        try:
            self._http_client().request_json(
                "GET",
                f"/api/v2/workspaces/{workspace_code}",
                auth_mode="oauth",
            )
        except ApiError as error:
            raise _to_cli_error(error)
        self._validated_workspaces.add(workspace_code)

    def request_api(
        self,
        *,
        method: str,
        path: str,
        allow_api_key: bool,
        required_scope: str | None = None,
        workspace_code: str | None = None,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> Any:
        return self._request_api_internal(
            method=method,
            path=path,
            allow_api_key=allow_api_key,
            required_scope=required_scope,
            workspace_code=workspace_code,
            params=params,
            json_body=json_body,
            missing_status_codes=None,
        )

    def _request_api_internal(
        self,
        *,
        method: str,
        path: str,
        allow_api_key: bool,
        required_scope: str | None = None,
        workspace_code: str | None = None,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        missing_status_codes: tuple[int, ...] | None,
    ) -> Any | None:
        auth_mode = self.resolve_auth_mode(allow_api_key=allow_api_key)
        if auth_mode == "oauth":
            if not self.profile.oauth.access_token and not self.refresh_oauth(
                silent=True
            ):
                raise CliError(
                    "OAuth login required. Run `wilfie auth login`."
                )
        if auth_mode == "api-key":
            self.ensure_api_key_scope(required_scope)
        if workspace_code:
            self.preflight_workspace_access(
                workspace_code=workspace_code,
                auth_mode=auth_mode,
            )
        try:
            return self._http_client().request_json(
                method,
                path,
                auth_mode=auth_mode,
                params=params,
                json_body=json_body,
            )
        except ApiError as error:
            if missing_status_codes and error.status_code in missing_status_codes:
                return None
            raise _to_cli_error(error)

    def stream_api(
        self,
        *,
        method: str,
        path: str,
        allow_api_key: bool,
        required_scope: str | None = None,
        workspace_code: str | None = None,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
    ) -> None:
        auth_mode = self.resolve_auth_mode(allow_api_key=allow_api_key)
        if auth_mode == "oauth":
            if not self.profile.oauth.access_token and not self.refresh_oauth(
                silent=True
            ):
                raise CliError(
                    "OAuth login required. Run `wilfie auth login`."
                )
        if auth_mode == "api-key":
            self.ensure_api_key_scope(required_scope)
        if workspace_code:
            self.preflight_workspace_access(
                workspace_code=workspace_code,
                auth_mode=auth_mode,
            )
        try:
            for payload in self._http_client().stream_json_lines(
                method,
                path,
                auth_mode=auth_mode,
                params=params,
                json_body=json_body,
            ):
                emit_stream_payload(payload, output_mode=self.output_mode)
        except ApiError as error:
            raise _to_cli_error(error)


def _cmd_auth_login(args: argparse.Namespace, state: CliState) -> Any:
    return state.login_device_flow(
        client_id=args.client_id,
        scope=args.scope,
        audience=args.audience,
        open_browser=args.open_browser,
    )


def _cmd_auth_refresh(_args: argparse.Namespace, state: CliState) -> Any:
    if not state.refresh_oauth(silent=False):
        raise CliError("No refresh token is available.")
    print("Refreshed OAuth tokens.")
    return None


def _cmd_auth_logout(_args: argparse.Namespace, state: CliState) -> Any:
    state.logout_oauth()
    print("Cleared OAuth session.")
    return None


def _cmd_auth_whoami(_args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path="/api/v2/users/me",
        allow_api_key=False,
    )


def _cmd_auth_status(_args: argparse.Namespace, state: CliState) -> Any:
    oauth_access = state.profile.oauth.access_token
    oauth_refresh = state.profile.oauth.refresh_token
    api_key_value = state.profile.api_key
    oauth_mode_available = bool(oauth_access or oauth_refresh)
    api_key_mode_available = bool(api_key_value)
    active_mode = state.resolve_auth_mode(allow_api_key=True)

    return {
        "profile": state.profile_name,
        "base_url": state.base_url,
        "auth_mode_preference": state.auth_mode,
        "auth_mode_resolved": active_mode,
        "oauth": {
            "configured": oauth_mode_available,
            "access_token": _mask_secret(oauth_access),
            "refresh_token": _mask_secret(oauth_refresh),
            "access_token_expired": (
                state._oauth_expired() if bool(oauth_access) else None
            ),
            "expires_at_epoch": state.profile.oauth.expires_at_epoch,
            "client_id": state.profile.oauth.client_id or "wilfie-cli",
            "scope": state.profile.oauth.scope,
        },
        "api_key": {
            "configured": api_key_mode_available,
            "api_key": _mask_secret(api_key_value),
            "scopes": state.profile.api_key_scopes,
        },
    }


def _cmd_auth_api_key_set(args: argparse.Namespace, state: CliState) -> Any:
    if args.api_key is None:
        raise CliError("--api-key is required.")
    state.set_api_key(api_key=args.api_key, scopes=args.scope or [])
    print("Saved API key configuration.")
    return None


def _cmd_auth_api_key_show(_args: argparse.Namespace, state: CliState) -> Any:
    value = state.profile.api_key
    return {
        "configured": bool(value),
        "api_key": _mask_secret(value),
        "scopes": state.profile.api_key_scopes,
    }


def _cmd_auth_api_key_clear(_args: argparse.Namespace, state: CliState) -> Any:
    state.clear_api_key()
    print("Cleared API key configuration.")
    return None


def _cmd_workspaces_list(_args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path="/api/v2/workspaces",
        allow_api_key=False,
    )


def _cmd_workspaces_get(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workspaces_roles(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}/roles",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workspaces_permission_definitions(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace_code}/permission-definitions",
        allow_api_key=False,
        workspace_code=args.workspace_code,
    )


def _cmd_workflows_list(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/workflows",
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
    )


def _cmd_workflows_runs(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/workflows/runs",
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
        json_body={
            "workflow_id": args.workflow_id,
            "page": args.page,
            "page_size": args.page_size,
        },
    )


def _cmd_workflows_run_detail(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/workflows/run/detail",
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
        json_body={
            "workflow_id": args.workflow_id,
            "run_id": args.run_id,
        },
    )


def _cmd_workflows_run_stream(args: argparse.Namespace, state: CliState) -> Any:
    state.stream_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/workflows/"
            f"{args.workflow_id}/runs/{args.run_id}/stream"
        ),
        allow_api_key=True,
        required_scope="workflows.read",
        workspace_code=args.workspace,
        params={
            "after_event_id": args.after_event_id,
        }
        if args.after_event_id is not None
        else None,
    )
    return None


def _cmd_operations_list(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {
        "page": args.page,
        "page_size": args.page_size,
    }
    if args.kind:
        params["kind"] = args.kind
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/operations",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_operations_detail(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/operations/{args.operation_id}",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_operations_stream(args: argparse.Namespace, state: CliState) -> Any:
    state.stream_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/operations/{args.operation_id}/stream",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "after_event_id": args.after_event_id,
        }
        if args.after_event_id is not None
        else None,
    )
    return None


def _cmd_workflows_execute(args: argparse.Namespace, state: CliState) -> Any:
    overrides = _load_json_file(args.overrides_file) if args.overrides_file else {}
    payload: dict[str, Any] = {
        "workflow_id": args.workflow_id,
        "run_type": args.run_type,
    }
    if args.entry_node_id:
        payload["entry_node_id"] = args.entry_node_id
    if overrides:
        payload["overrides"] = overrides
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/workflows/execute",
        allow_api_key=True,
        required_scope="workflows.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_facilities(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/facilities",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
            "require_manage_stock": str(args.require_manage_stock).lower(),
        },
    )


def _cmd_wms_skus(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
        "include_on_hand": str(args.include_on_hand).lower(),
        "in_stock_only": str(args.in_stock_only).lower(),
    }
    if args.query:
        params["query"] = args.query
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/skus",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _optional_non_negative_int(value: int | None, *, flag: str) -> int | None:
    if value is None:
        return None
    normalized = int(value)
    if normalized < 0:
        raise CliError(f"{flag} must be greater than or equal to 0.")
    return normalized


def _parse_json_object_arg(
    *,
    raw_value: str | None,
    file_path: str | None,
    value_flag: str,
    file_flag: str,
) -> dict[str, Any]:
    if raw_value and file_path:
        raise CliError(f"Use either {value_flag} or {file_flag}, not both.")

    if raw_value:
        source = value_flag
        raw_payload = raw_value
    elif file_path:
        source = file_flag
        path = Path(file_path).expanduser()
        try:
            raw_payload = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise CliError(
                f"Could not read {file_flag} file '{file_path}': {exc}"
            ) from exc
    else:
        return {}

    try:
        parsed = json.loads(raw_payload)
    except json.JSONDecodeError as exc:
        raise CliError(f"Invalid JSON for {source}: {exc.msg}") from exc

    if not isinstance(parsed, dict):
        raise CliError(f"{source} must contain a JSON object.")
    return parsed


def _build_package_profile_dimensions(args: argparse.Namespace) -> dict[str, int]:
    dimensions: dict[str, int] = {}
    for key, flag in (
        ("length_mm", "--length-mm"),
        ("width_mm", "--width-mm"),
        ("height_mm", "--height-mm"),
    ):
        normalized = _optional_non_negative_int(getattr(args, key), flag=flag)
        if normalized:
            dimensions[key] = normalized
    return dimensions


def _cmd_wms_package_profiles_create(
    args: argparse.Namespace, state: CliState
) -> Any:
    payload: dict[str, Any] = {
        "code": args.code,
        "name": args.name,
        "is_active": bool(args.active),
    }
    if args.facility_id:
        payload["facility_id"] = args.facility_id
    if args.inventory_owner_id:
        payload["inventory_owner_id"] = args.inventory_owner_id
    if args.package_type:
        payload["package_type"] = args.package_type
    if args.package_class:
        payload["package_class"] = args.package_class
    default_weight_grams = _optional_non_negative_int(
        args.default_weight_grams,
        flag="--default-weight-grams",
    )
    if default_weight_grams is not None:
        payload["default_weight_grams"] = default_weight_grams
    dimensions = _build_package_profile_dimensions(args)
    if dimensions:
        payload["default_dimensions_json"] = dimensions
    if args.notes:
        payload["notes"] = args.notes
    metadata_json = _parse_json_object_arg(
        raw_value=args.metadata_json,
        file_path=args.metadata_file,
        value_flag="--metadata-json",
        file_flag="--metadata-file",
    )
    if metadata_json:
        payload["metadata_json"] = metadata_json
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/package-profiles",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_package_profiles_list(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
        "include_inactive": str(args.include_inactive).lower(),
    }
    if args.facility_id:
        params["facility_id"] = args.facility_id
    if args.inventory_owner_id:
        params["inventory_owner_id"] = args.inventory_owner_id
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/package-profiles",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_query(args: argparse.Namespace, state: CliState) -> Any:
    params = _parse_query_pairs(args.param)
    endpoint_path = _normalize_wms_query_path(
        workspace_code=args.workspace,
        path=args.path,
    )
    return state.request_api(
        method="GET",
        path=endpoint_path,
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params if params else None,
    )


def _cmd_wms_barcodes_resolve(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/barcodes/resolve",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "facility_id": args.facility_id,
            "barcode": args.barcode,
        },
    )


def _cmd_wms_containers_outbound_context(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/containers/"
            f"{args.container_id}/outbound-context"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _request_wms_document_list(
    *,
    state: CliState,
    workspace: str,
    kind: str,
    facility_id: str | None = None,
    status: str | None = None,
    search_query: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> Any:
    normalized_kind = _normalize_wms_document_kind(kind)
    params: dict[str, Any] = {
        "limit": limit,
        "offset": offset,
    }
    if facility_id:
        params["facility_id"] = facility_id
    if status:
        params["status"] = status
    if search_query:
        params["search_query"] = search_query
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{workspace}/wms/document-kinds/{normalized_kind}",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=workspace,
        params=params,
    )


def _request_wms_document_detail(
    *,
    state: CliState,
    workspace: str,
    kind: str,
    document_id: str,
) -> Any:
    normalized_kind = _normalize_wms_document_kind(kind)
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{workspace}/wms/document/"
            f"{normalized_kind}/{document_id}/detail"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=workspace,
    )


def _request_wms_document_context(
    *,
    state: CliState,
    workspace: str,
    kind: str,
    document_id: str,
    include_projection_totals: bool = True,
) -> Any:
    normalized_kind = _normalize_wms_document_kind(kind)
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{workspace}/wms/documents/"
            f"{normalized_kind}/{document_id}/context"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=workspace,
        params={
            "include_projection_totals": str(include_projection_totals).lower(),
        },
    )


def _request_wms_document_issues(
    *,
    state: CliState,
    workspace: str,
    kind: str,
    document_id: str,
    facility_id: str | None = None,
    status: str | None = "open",
    severity: str | None = None,
    issue_code: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> Any:
    normalized_kind = _normalize_wms_document_kind(kind)
    params: dict[str, Any] = {
        "limit": limit,
        "offset": offset,
        "document_kind": normalized_kind,
        "document_id": document_id,
    }
    if facility_id:
        params["facility_id"] = facility_id
    if status:
        params["status"] = status
    if severity:
        params["severity"] = severity
    if issue_code:
        params["issue_code"] = issue_code
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{workspace}/wms/issues",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=workspace,
        params=params,
    )


def _build_sections_payload(
    *sections: tuple[str, Any],
) -> dict[str, list[dict[str, Any]]]:
    return {
        "sections": [
            {"title": title, "payload": payload}
            for title, payload in sections
            if payload is not None
        ]
    }


def _extract_dispatch_summary(detail: Any) -> dict[str, Any]:
    if not isinstance(detail, dict):
        return {"value": detail}
    document = detail.get("document")
    lines = detail.get("lines")
    linked_documents = detail.get("linked_documents")
    external_references = detail.get("external_references")
    extensions = detail.get("extensions")
    package_summary = (
        extensions.get("dispatch_package_summary", {})
        if isinstance(extensions, dict)
        else {}
    )
    summary: dict[str, Any] = {
        "document_kind": detail.get("document_kind"),
        "document_id": detail.get("document_id"),
        "line_count": len(lines) if isinstance(lines, list) else 0,
        "linked_document_count": (
            len(linked_documents) if isinstance(linked_documents, list) else 0
        ),
        "external_reference_count": (
            len(external_references) if isinstance(external_references, list) else 0
        ),
    }
    if isinstance(document, dict):
        summary.update(document)
    if isinstance(package_summary, dict):
        summary["package_count"] = int(package_summary.get("package_count") or 0)
        summary["allocated_quantity"] = int(
            package_summary.get("allocated_quantity") or 0
        )
        summary["remaining_quantity"] = int(
            package_summary.get("remaining_quantity") or 0
        )
    return summary


def _extract_dispatch_package_rows(detail: Any) -> list[dict[str, Any]]:
    if not isinstance(detail, dict):
        return []
    extensions = detail.get("extensions")
    if not isinstance(extensions, dict):
        return []
    packages = extensions.get("dispatch_packages")
    if not isinstance(packages, list):
        return []
    rows: list[dict[str, Any]] = []
    for package in packages:
        if not isinstance(package, dict):
            continue
        rows.append(
            {
                "dispatch_package_id": package.get("id"),
                "reference_code": package.get("reference_code"),
                "status": package.get("status"),
                "package_type": package.get("package_type"),
                "package_profile_code": package.get("package_profile_code"),
                "weight_grams": package.get("weight_grams"),
                "carrier_name": package.get("carrier_name"),
                "carrier_service": package.get("carrier_service"),
                "carrier_label_barcode": package.get("carrier_label_barcode"),
                "tracking_number": package.get("tracking_number"),
                "tracking_url": package.get("tracking_url"),
                "label_url": package.get("label_url"),
                "dispatch_manifest_reference_code": package.get(
                    "dispatch_manifest_reference_code"
                ),
                "dispatch_manifest_status": package.get(
                    "dispatch_manifest_status"
                ),
                "dispatch_manifest_routing_code": package.get(
                    "dispatch_manifest_routing_code"
                ),
                "allocated_quantity": package.get("allocated_quantity"),
                "line_count": package.get("line_count"),
                "locked_at": package.get("locked_at"),
            }
        )
    return rows


def _extract_dispatch_package_line_rows(detail: Any) -> list[dict[str, Any]]:
    if not isinstance(detail, dict):
        return []
    extensions = detail.get("extensions")
    if not isinstance(extensions, dict):
        return []
    line_allocations = extensions.get("dispatch_package_lines")
    if not isinstance(line_allocations, list):
        return []
    rows: list[dict[str, Any]] = []
    for line in line_allocations:
        if not isinstance(line, dict):
            continue
        rows.append(
            {
                "dispatch_item_id": line.get("dispatch_item_id"),
                "fulfillment_id": line.get("fulfillment_id"),
                "planned_quantity": line.get("planned_quantity"),
                "allocated_quantity": line.get("allocated_quantity"),
                "remaining_quantity": line.get("remaining_quantity"),
                "package_count": line.get("package_count"),
            }
        )
    return rows


def _extract_manifest_summary(detail: Any) -> dict[str, Any]:
    if not isinstance(detail, dict):
        return {"value": detail}
    document = detail.get("document")
    lines = detail.get("lines")
    linked_documents = detail.get("linked_documents")
    extensions = detail.get("extensions")
    manifest_payload = (
        extensions.get("dispatch_manifest_payload", {})
        if isinstance(extensions, dict)
        else {}
    )
    totals = (
        manifest_payload.get("totals", {})
        if isinstance(manifest_payload, dict)
        else {}
    )
    summary: dict[str, Any] = {
        "document_kind": detail.get("document_kind"),
        "document_id": detail.get("document_id"),
        "line_count": len(lines) if isinstance(lines, list) else 0,
        "linked_document_count": (
            len(linked_documents) if isinstance(linked_documents, list) else 0
        ),
    }
    if isinstance(document, dict):
        summary.update(document)
    if isinstance(totals, dict):
        summary.update(
            {
                "dispatch_count": totals.get("dispatch_count"),
                "package_count": totals.get("package_count"),
                "manifest_item_count": totals.get("manifest_item_count"),
                "scanned_manifest_item_count": totals.get(
                    "scanned_manifest_item_count"
                ),
                "open_manifest_item_count": totals.get("open_manifest_item_count"),
                "quantity_total": totals.get("quantity_total"),
            }
        )
    return summary


def _extract_dispatch_manifest_payload(detail: Any) -> dict[str, Any]:
    if not isinstance(detail, dict):
        return {}
    extensions = detail.get("extensions")
    if not isinstance(extensions, dict):
        return {}
    payload = extensions.get("dispatch_manifest_payload")
    if not isinstance(payload, dict):
        return {}
    return payload


def _extract_manifest_dispatch_rows(detail: Any) -> list[dict[str, Any]]:
    payload = _extract_dispatch_manifest_payload(detail)
    dispatches = payload.get("dispatches")
    if not isinstance(dispatches, list):
        return []
    rows: list[dict[str, Any]] = []
    for dispatch in dispatches:
        if not isinstance(dispatch, dict):
            continue
        rows.append(
            {
                "dispatch_id": dispatch.get("dispatch_id"),
                "reference_code": dispatch.get("reference_code"),
                "status": dispatch.get("status"),
                "tracking_number": dispatch.get("tracking_number"),
                "line_count": dispatch.get("line_count"),
                "quantity_total": dispatch.get("quantity_total"),
                "package_count": dispatch.get("package_count"),
                "manifest_item_count": dispatch.get("manifest_item_count"),
                "manifest_scanned_item_count": dispatch.get(
                    "manifest_scanned_item_count"
                ),
                "dispatched_at": dispatch.get("dispatched_at"),
            }
        )
    return rows


def _extract_manifest_package_rows(detail: Any) -> list[dict[str, Any]]:
    payload = _extract_dispatch_manifest_payload(detail)
    dispatches = payload.get("dispatches")
    if not isinstance(dispatches, list):
        return []
    rows: list[dict[str, Any]] = []
    for dispatch in dispatches:
        if not isinstance(dispatch, dict):
            continue
        dispatch_id = dispatch.get("dispatch_id")
        dispatch_reference_code = dispatch.get("reference_code")
        packages = dispatch.get("packages")
        if not isinstance(packages, list):
            continue
        for package in packages:
            if not isinstance(package, dict):
                continue
            rows.append(
                {
                    "dispatch_id": dispatch_id,
                    "dispatch_reference_code": dispatch_reference_code,
                    "dispatch_package_id": package.get("dispatch_package_id"),
                    "reference_code": package.get("reference_code"),
                    "status": package.get("status"),
                    "package_type": package.get("package_type"),
                    "package_profile_code": package.get("package_profile_code"),
                    "carrier_name": package.get("carrier_name"),
                    "carrier_service": package.get("carrier_service"),
                    "carrier_label_barcode": package.get("carrier_label_barcode"),
                    "tracking_number": package.get("tracking_number"),
                    "tracking_url": package.get("tracking_url"),
                    "label_url": package.get("label_url"),
                    "scanned_at": package.get("scanned_at"),
                }
            )
    return rows


def _cmd_wms_documents_list(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_list(
        state=state,
        workspace=args.workspace,
        kind=args.kind,
        facility_id=args.facility_id,
        status=args.status,
        search_query=args.search_query,
        limit=args.limit,
        offset=args.offset,
    )


def _cmd_wms_documents_detail(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind=args.kind,
        document_id=args.document_id,
    )


def _cmd_wms_documents_context(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_context(
        state=state,
        workspace=args.workspace,
        kind=args.kind,
        document_id=args.document_id,
        include_projection_totals=args.include_projection_totals,
    )


def _cmd_wms_documents_links(args: argparse.Namespace, state: CliState) -> Any:
    kind = _normalize_wms_document_kind(args.kind)
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/documents/"
            f"{kind}/{args.document_id}/line-links"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={"include_inactive": str(args.include_inactive).lower()},
    )


def _cmd_wms_documents_line_links(
    args: argparse.Namespace, state: CliState
) -> Any:
    kind = _normalize_wms_document_kind(args.kind)
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/documents/{kind}/"
            f"{args.document_id}/lines/{args.line_id}/line-links"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={"include_inactive": str(args.include_inactive).lower()},
    )


def _cmd_wms_documents_lineage(args: argparse.Namespace, state: CliState) -> Any:
    kind = _normalize_wms_document_kind(args.kind)
    if args.max_depth < 1 or args.max_depth > 12:
        raise CliError("--max-depth must be between 1 and 12.")
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/documents/{kind}/"
            f"{args.document_id}/lines/{args.line_id}/lineage-chain"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "include_inactive": str(args.include_inactive).lower(),
            "max_depth": args.max_depth,
        },
    )


def _cmd_wms_issues_list(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.facility_id:
        params["facility_id"] = args.facility_id
    if args.status:
        params["status"] = args.status
    if args.severity:
        params["severity"] = args.severity
    if args.issue_code:
        params["issue_code"] = args.issue_code
    if args.scope:
        params["scope"] = args.scope
    if args.document_kind:
        params["document_kind"] = args.document_kind
    if args.document_id:
        params["document_id"] = args.document_id
    if args.line_id:
        params["line_id"] = args.line_id
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_dispatches_list(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_list(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        facility_id=args.facility_id,
        status=args.status,
        search_query=args.search_query,
        limit=args.limit,
        offset=args.offset,
    )


def _cmd_wms_dispatches_detail(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
    )


def _cmd_wms_dispatches_context(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_context(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
        include_projection_totals=args.include_projection_totals,
    )


def _cmd_wms_dispatches_packages(args: argparse.Namespace, state: CliState) -> Any:
    detail = _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
    )
    return _build_sections_payload(
        ("Dispatch", _extract_dispatch_summary(detail)),
        (
            "Package summary",
            (
                detail.get("extensions", {}).get("dispatch_package_summary", {})
                if isinstance(detail, dict)
                else {}
            ),
        ),
        ("Packages", _extract_dispatch_package_rows(detail)),
        ("Package line allocations", _extract_dispatch_package_line_rows(detail)),
    )


def _cmd_wms_dispatches_issues(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_issues(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
        facility_id=args.facility_id,
        status=args.status,
        severity=args.severity,
        issue_code=args.issue_code,
        limit=args.limit,
        offset=args.offset,
    )


def _cmd_wms_dispatches_trace(args: argparse.Namespace, state: CliState) -> Any:
    detail = _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
    )
    context = _request_wms_document_context(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
        include_projection_totals=args.include_projection_totals,
    )
    issues = _request_wms_document_issues(
        state=state,
        workspace=args.workspace,
        kind="dispatch",
        document_id=args.dispatch_id,
        facility_id=args.facility_id,
        status=args.status,
        severity=args.severity,
        issue_code=args.issue_code,
        limit=args.limit,
        offset=args.offset,
    )
    return _build_sections_payload(
        ("Dispatch", _extract_dispatch_summary(detail)),
        (
            "Package summary",
            (
                detail.get("extensions", {}).get("dispatch_package_summary", {})
                if isinstance(detail, dict)
                else {}
            ),
        ),
        ("Packages", _extract_dispatch_package_rows(detail)),
        ("Package line allocations", _extract_dispatch_package_line_rows(detail)),
        ("Document context", context),
        ("Operational issues", issues),
    )


def _cmd_wms_manifests_list(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.facility_id:
        params["facility_id"] = args.facility_id
    if args.inventory_owner_id:
        params["inventory_owner_id"] = args.inventory_owner_id
    if args.status:
        params["statuses"] = args.status
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/dispatch-manifests",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_manifests_detail(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
    )


def _cmd_wms_manifests_context(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_context(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
        include_projection_totals=args.include_projection_totals,
    )


def _cmd_wms_manifests_payload(args: argparse.Namespace, state: CliState) -> Any:
    detail = _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
    )
    payload = _extract_dispatch_manifest_payload(detail)
    return _build_sections_payload(
        ("Manifest", _extract_manifest_summary(detail)),
        ("Payload totals", payload.get("totals", {})),
        ("Dispatches", _extract_manifest_dispatch_rows(detail)),
        ("Packages", _extract_manifest_package_rows(detail)),
    )


def _cmd_wms_manifests_issues(args: argparse.Namespace, state: CliState) -> Any:
    return _request_wms_document_issues(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
        facility_id=args.facility_id,
        status=args.status,
        severity=args.severity,
        issue_code=args.issue_code,
        limit=args.limit,
        offset=args.offset,
    )


def _cmd_wms_manifests_trace(args: argparse.Namespace, state: CliState) -> Any:
    detail = _request_wms_document_detail(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
    )
    context = _request_wms_document_context(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
        include_projection_totals=args.include_projection_totals,
    )
    issues = _request_wms_document_issues(
        state=state,
        workspace=args.workspace,
        kind="dispatch_manifest",
        document_id=args.dispatch_manifest_id,
        facility_id=args.facility_id,
        status=args.status,
        severity=args.severity,
        issue_code=args.issue_code,
        limit=args.limit,
        offset=args.offset,
    )
    payload = _extract_dispatch_manifest_payload(detail)
    return _build_sections_payload(
        ("Manifest", _extract_manifest_summary(detail)),
        ("Payload totals", payload.get("totals", {})),
        ("Dispatches", _extract_manifest_dispatch_rows(detail)),
        ("Packages", _extract_manifest_package_rows(detail)),
        ("Document context", context),
        ("Operational issues", issues),
    )


def _cmd_wms_issues_detail(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues/{args.issue_id}",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_wms_issues_resolve(args: argparse.Namespace, state: CliState) -> Any:
    payload: dict[str, Any] = {}
    if args.notes:
        payload["notes"] = args.notes
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues/{args.issue_id}/resolve",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_issues_ignore(args: argparse.Namespace, state: CliState) -> Any:
    payload: dict[str, Any] = {}
    if args.notes:
        payload["notes"] = args.notes
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues/{args.issue_id}/ignore",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_issues_reopen(args: argparse.Namespace, state: CliState) -> Any:
    payload: dict[str, Any] = {}
    if args.notes:
        payload["notes"] = args.notes
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues/{args.issue_id}/reopen",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_issues_recompute(args: argparse.Namespace, state: CliState) -> Any:
    payload: dict[str, Any] = {
        "dry_run": bool(args.dry_run),
    }
    if args.facility_id:
        payload["facility_id"] = args.facility_id
    if args.scope:
        payload["scope"] = args.scope
    if args.document_kind:
        payload["document_kind"] = args.document_kind
    if args.document_id:
        payload["document_id"] = args.document_id
    if args.line_id:
        payload["line_id"] = args.line_id
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/issues/recompute",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_wms_connections_list(args: argparse.Namespace, state: CliState) -> Any:
    params: dict[str, Any] = {}
    if args.integration_type:
        params["integration_type"] = args.integration_type
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/integration-connections",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params if params else None,
    )


def _cmd_wms_sku_mappings_by_connection(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.external_object_type:
        params["external_object_type"] = args.external_object_type
    if args.external_object_id:
        params["external_object_id"] = args.external_object_id
    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/wms/integration-connections/"
            f"{args.integration_connection_id}/sku-mappings"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_sku_mappings_by_sku(args: argparse.Namespace, state: CliState) -> Any:
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/skus/{args.sku_id}/mappings",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_wms_reconcile_available(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "integration_connection_id": args.integration_connection_id,
        "limit": args.limit,
        "offset": args.offset,
        "actionable_only": str(args.actionable_only).lower(),
        "managed_only": str(args.managed_only).lower(),
    }
    if args.sku_id:
        params["sku_id"] = args.sku_id
    if args.facility_id:
        params["facility_id"] = args.facility_id
    return state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/wms/reconcile/available",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_wms_reconcile_outbound(
    args: argparse.Namespace, state: CliState
) -> Any:
    payload: dict[str, Any] = {
        "integration_connection_id": args.integration_connection_id,
        "dry_run": bool(args.dry_run),
    }
    if args.order_id:
        payload["order_id"] = args.order_id
    if args.fulfillment_order_id:
        payload["fulfillment_order_id"] = args.fulfillment_order_id
    return state.request_api(
        method="POST",
        path=f"/api/v2/workspaces/{args.workspace}/wms/shopify/outbound/reconcile",
        allow_api_key=True,
        required_scope="wms.write",
        workspace_code=args.workspace,
        json_body=payload,
    )


def _cmd_integrations_connections_list(
    args: argparse.Namespace, state: CliState
) -> Any:
    payload = state.request_api(
        method="GET",
        path=f"/api/v2/workspaces/{args.workspace}/integrations/connections",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )
    if not args.integration_type:
        return payload
    if not isinstance(payload, dict):
        return payload
    connections = payload.get("connections")
    if not isinstance(connections, list):
        return payload
    filtered = [
        item
        for item in connections
        if isinstance(item, dict)
        and item.get("integration_type") == args.integration_type
    ]
    return {
        **payload,
        "connections": filtered,
    }


def _cmd_integrations_connections_mirror_runs(
    args: argparse.Namespace, state: CliState
) -> Any:
    params = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.run_group_id:
        params["run_group_id"] = args.run_group_id
    if args.run_type:
        params["run_type"] = args.run_type
    if args.since:
        params["since"] = args.since
    if args.until:
        params["until"] = args.until

    return state.request_api(
        method="GET",
        path=(
            f"/api/v2/workspaces/{args.workspace}/integrations/connections/"
            f"{args.integration_connection_id}/mirror/runs"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _integrations_connections_base_path(
    *, workspace: str, integration_connection_id: str
) -> str:
    return (
        f"/api/v2/workspaces/{workspace}/integrations/connections/"
        f"{integration_connection_id}"
    )


def _cmd_integrations_connections_logs(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "lane": args.lane,
        "limit": args.limit,
        "offset": args.offset,
        "sort_direction": args.sort_direction,
    }
    if args.status:
        params["status"] = args.status
    if args.operation_topic:
        params["operation_topic"] = args.operation_topic
    if args.external_object_type:
        params["external_object_type"] = args.external_object_type
    if args.external_object_id:
        params["external_object_id"] = args.external_object_id
    if args.correlation_id:
        params["correlation_id"] = args.correlation_id
    if args.since:
        params["since"] = args.since
    if args.until:
        params["until"] = args.until
    if args.sort_key:
        params["sort_key"] = args.sort_key
    return state.request_api(
        method="GET",
        path=f"{_integrations_connections_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}/logs",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_connections_related_logs(
    args: argparse.Namespace, state: CliState
) -> Any:
    if not args.correlation_id and not (args.source_kind and args.source_id):
        raise CliError(
            "Provide --correlation-id or both --source-kind and --source-id."
        )
    if args.source_kind and not args.source_id:
        raise CliError("--source-id is required when --source-kind is set.")
    if args.source_id and not args.source_kind:
        raise CliError("--source-kind is required when --source-id is set.")
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.correlation_id:
        params["correlation_id"] = args.correlation_id
    if args.source_kind:
        params["source_kind"] = args.source_kind
    if args.source_id:
        params["source_id"] = args.source_id
    return state.request_api(
        method="GET",
        path=f"{_integrations_connections_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}/logs/related",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_connections_webhooks(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
        "sort_direction": args.sort_direction,
    }
    if args.topic:
        params["topic"] = args.topic
    if args.status:
        params["status"] = args.status
    if args.since:
        params["since"] = args.since
    if args.until:
        params["until"] = args.until
    if args.sort_key:
        params["sort_key"] = args.sort_key
    return state.request_api(
        method="GET",
        path=f"{_integrations_connections_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}/webhooks",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_connections_webhook_deliveries(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.status:
        params["status"] = args.status
    if args.event_type:
        params["event_type"] = args.event_type
    if args.external_object_type:
        params["external_object_type"] = args.external_object_type
    if args.external_object_id:
        params["external_object_id"] = args.external_object_id
    if args.correlation_id:
        params["correlation_id"] = args.correlation_id
    if args.since:
        params["since"] = args.since
    if args.until:
        params["until"] = args.until
    return state.request_api(
        method="GET",
        path=f"{_integrations_connections_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}/webhook-deliveries",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_connections_trace(
    args: argparse.Namespace, state: CliState
) -> Any:
    params: dict[str, Any] = {
        "limit": args.limit,
        "offset": args.offset,
    }
    if args.integration_object_id:
        params["integration_object_id"] = args.integration_object_id
    if args.external_object_type:
        params["external_object_type"] = args.external_object_type
    if args.external_object_id:
        params["external_object_id"] = args.external_object_id
    if args.correlation_id:
        params["correlation_id"] = args.correlation_id
    if args.since:
        params["since"] = args.since
    if args.until:
        params["until"] = args.until
    return state.request_api(
        method="GET",
        path=f"{_integrations_connections_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}/trace",
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _integrations_objects_base_path(
    *, workspace: str, integration_connection_id: str
) -> str:
    return (
        f"/api/v2/workspaces/{workspace}/integrations/connections/"
        f"{integration_connection_id}/objects"
    )


def _normalize_integration_external_object_type(value: str) -> str:
    normalized = str(value or "").strip().lower().replace("-", "_")
    if not normalized:
        raise CliError("--external-object-type is required.")
    aliases = {
        "products": "product",
        "variants": "variant",
        "skus": "variant",
        "inventory_items": "inventory_item",
        "inventory_levels": "inventory_level",
    }
    return aliases.get(normalized, normalized)


def _cmd_integrations_objects_products(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/products"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_variants(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/variants"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_inventory_items(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/inventory-items"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_inventory_levels(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/inventory-levels"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_by_type(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/by-type/{args.external_object_type}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "limit": args.limit,
            "offset": args.offset,
        },
    )


def _cmd_integrations_objects_fetch(
    args: argparse.Namespace, state: CliState
) -> Any:
    external_object_type = _normalize_integration_external_object_type(
        args.external_object_type
    )
    return state.request_api(
        method="POST",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/fetch/{external_object_type}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        json_body={
            "external_object_ids": args.external_object_id,
        },
    )


def _cmd_integrations_objects_get(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/{args.integration_object_id}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
    )


def _cmd_integrations_objects_lookup(
    args: argparse.Namespace, state: CliState
) -> Any:
    external_object_type = _normalize_integration_external_object_type(
        args.external_object_type
    )
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/lookup"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "external_object_type": external_object_type,
            "external_object_id": args.external_object_id,
        },
    )


def _cmd_integrations_objects_missing_external_sample(
    args: argparse.Namespace, state: CliState
) -> Any:
    external_object_type = _normalize_integration_external_object_type(
        args.external_object_type
    )
    if args.batch_size < 1 or args.batch_size > 200:
        raise CliError("--batch-size must be between 1 and 200.")
    if args.sample_limit < 1:
        raise CliError("--sample-limit must be at least 1.")
    if args.max_items is not None and args.max_items < 1:
        raise CliError("--max-items must be at least 1 when provided.")
    params: dict[str, Any] = {
        "sample_limit": args.sample_limit,
        "batch_size": args.batch_size,
    }
    if args.max_items is not None:
        params["max_items"] = args.max_items
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/missing-external-sample/{external_object_type}"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params=params,
    )


def _cmd_integrations_objects_shopify_history(
    args: argparse.Namespace, state: CliState
) -> Any:
    external_object_type = _normalize_integration_external_object_type(
        args.external_object_type
    )
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            "/shopify-history"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={
            "external_object_type": external_object_type,
            "external_object_id": args.external_object_id,
            "limit": args.limit,
        },
    )


def _cmd_integrations_objects_timeline(
    args: argparse.Namespace, state: CliState
) -> Any:
    return state.request_api(
        method="GET",
        path=(
            f"{_integrations_objects_base_path(workspace=args.workspace, integration_connection_id=args.integration_connection_id)}"
            f"/{args.integration_object_id}/timeline"
        ),
        allow_api_key=True,
        required_scope="wms.read",
        workspace_code=args.workspace,
        params={"limit": args.limit},
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wilfie",
        description="Wilfie public API wrapper CLI",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--profile",
        default=os.getenv("WILFIE_CLI_PROFILE", "default"),
        help="CLI profile name.",
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("WILFIE_BASE_URL"),
        help="Override API base URL for this command.",
    )
    parser.add_argument(
        "--output",
        choices=["json", "table"],
        default=None,
        help="Output mode.",
    )
    parser.add_argument(
        "--auth-mode",
        choices=["auto", "oauth", "api-key"],
        default="auto",
        help="Auth mode preference.",
    )

    root_subparsers = parser.add_subparsers(dest="group", required=True)

    auth_parser = root_subparsers.add_parser("auth", help="Auth commands")
    auth_sub = auth_parser.add_subparsers(dest="auth_cmd", required=True)

    auth_login = auth_sub.add_parser("login", help="OAuth device login")
    auth_login.add_argument("--client-id", default="wilfie-cli")
    auth_login.add_argument("--scope", default="openid offline_access")
    auth_login.add_argument("--audience", default=None)
    auth_login.add_argument(
        "--open-browser",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    auth_login.set_defaults(handler=_cmd_auth_login)

    auth_refresh = auth_sub.add_parser("refresh", help="Refresh OAuth tokens")
    auth_refresh.set_defaults(handler=_cmd_auth_refresh)

    auth_logout = auth_sub.add_parser("logout", help="Logout and revoke")
    auth_logout.set_defaults(handler=_cmd_auth_logout)

    auth_whoami = auth_sub.add_parser("whoami", help="Show current user")
    auth_whoami.set_defaults(handler=_cmd_auth_whoami)

    auth_status = auth_sub.add_parser("status", help="Show auth status")
    auth_status.set_defaults(handler=_cmd_auth_status)

    auth_api_key = auth_sub.add_parser("api-key", help="API-key subcommands")
    auth_api_key_sub = auth_api_key.add_subparsers(
        dest="auth_api_key_cmd", required=True
    )

    api_key_set = auth_api_key_sub.add_parser("set", help="Store API key")
    api_key_set.add_argument("--api-key", required=True)
    api_key_set.add_argument(
        "--scope",
        action="append",
        default=[],
        help="Declared API-key scope (repeatable).",
    )
    api_key_set.set_defaults(handler=_cmd_auth_api_key_set)

    api_key_show = auth_api_key_sub.add_parser("show", help="Show API key state")
    api_key_show.set_defaults(handler=_cmd_auth_api_key_show)

    api_key_clear = auth_api_key_sub.add_parser(
        "clear", help="Clear API-key config"
    )
    api_key_clear.set_defaults(handler=_cmd_auth_api_key_clear)

    workspaces_parser = root_subparsers.add_parser(
        "workspaces", help="Workspace commands"
    )
    workspaces_sub = workspaces_parser.add_subparsers(
        dest="workspaces_cmd", required=True
    )

    workspaces_list = workspaces_sub.add_parser("list", help="List workspaces")
    workspaces_list.set_defaults(handler=_cmd_workspaces_list)

    workspaces_get = workspaces_sub.add_parser("get", help="Get workspace")
    workspaces_get.add_argument("workspace_code")
    workspaces_get.set_defaults(handler=_cmd_workspaces_get)

    workspaces_roles = workspaces_sub.add_parser("roles", help="List roles")
    workspaces_roles.add_argument("workspace_code")
    workspaces_roles.set_defaults(handler=_cmd_workspaces_roles)

    workspaces_permissions = workspaces_sub.add_parser(
        "permission-definitions", help="List permission definitions"
    )
    workspaces_permissions.add_argument("workspace_code")
    workspaces_permissions.set_defaults(
        handler=_cmd_workspaces_permission_definitions
    )

    workflows_parser = root_subparsers.add_parser(
        "workflows", help="Workflow commands"
    )
    workflows_sub = workflows_parser.add_subparsers(
        dest="workflows_cmd", required=True
    )

    workflows_list = workflows_sub.add_parser("list", help="List workflows")
    workflows_list.add_argument("--workspace", required=True)
    workflows_list.set_defaults(handler=_cmd_workflows_list)

    workflows_runs = workflows_sub.add_parser("runs", help="List workflow runs")
    workflows_runs.add_argument("--workspace", required=True)
    workflows_runs.add_argument("--workflow-id", required=True)
    workflows_runs.add_argument("--page", type=int, default=1)
    workflows_runs.add_argument("--page-size", type=int, default=50)
    workflows_runs.set_defaults(handler=_cmd_workflows_runs)

    workflows_run_detail = workflows_sub.add_parser(
        "run-detail",
        help="Get one workflow run by workflow id and run id",
    )
    workflows_run_detail.add_argument("--workspace", required=True)
    workflows_run_detail.add_argument("--workflow-id", required=True)
    workflows_run_detail.add_argument("--run-id", required=True)
    workflows_run_detail.set_defaults(handler=_cmd_workflows_run_detail)

    workflows_run_stream = workflows_sub.add_parser(
        "run-stream",
        help="Stream one workflow run for live debugging",
    )
    workflows_run_stream.add_argument("--workspace", required=True)
    workflows_run_stream.add_argument("--workflow-id", required=True)
    workflows_run_stream.add_argument("--run-id", required=True)
    workflows_run_stream.add_argument("--after-event-id", type=int, default=None)
    workflows_run_stream.set_defaults(handler=_cmd_workflows_run_stream)

    workflows_execute = workflows_sub.add_parser(
        "execute", help="Execute workflow"
    )
    workflows_execute.add_argument("--workspace", required=True)
    workflows_execute.add_argument("--workflow-id", required=True)
    workflows_execute.add_argument("--run-type", default="manual")
    workflows_execute.add_argument("--entry-node-id", default=None)
    workflows_execute.add_argument("--overrides-file", default=None)
    workflows_execute.set_defaults(handler=_cmd_workflows_execute)

    operations_parser = root_subparsers.add_parser(
        "operations", help="Long-running operation commands"
    )
    operations_sub = operations_parser.add_subparsers(
        dest="operations_cmd", required=True
    )

    operations_list = operations_sub.add_parser("list", help="List operation runs")
    operations_list.add_argument("--workspace", required=True)
    operations_list.add_argument("--kind", default=None)
    operations_list.add_argument("--page", type=int, default=1)
    operations_list.add_argument("--page-size", type=int, default=50)
    operations_list.set_defaults(handler=_cmd_operations_list)

    operations_detail = operations_sub.add_parser(
        "detail", help="Get one operation run"
    )
    operations_detail.add_argument("--workspace", required=True)
    operations_detail.add_argument("--operation-id", required=True)
    operations_detail.set_defaults(handler=_cmd_operations_detail)

    operations_stream = operations_sub.add_parser(
        "stream", help="Stream one operation run for live debugging"
    )
    operations_stream.add_argument("--workspace", required=True)
    operations_stream.add_argument("--operation-id", required=True)
    operations_stream.add_argument("--after-event-id", type=int, default=None)
    operations_stream.set_defaults(handler=_cmd_operations_stream)

    integrations_parser = root_subparsers.add_parser(
        "integrations", help="Integration commands"
    )
    integrations_sub = integrations_parser.add_subparsers(
        dest="integrations_cmd", required=True
    )

    integrations_connections = integrations_sub.add_parser(
        "connections",
        help="Integration connection commands",
    )
    integrations_connections_sub = integrations_connections.add_subparsers(
        dest="integrations_connections_cmd",
        required=True,
    )

    integrations_connections_list = integrations_connections_sub.add_parser(
        "list",
        help="List integration connections",
    )
    integrations_connections_list.add_argument("--workspace", required=True)
    integrations_connections_list.add_argument(
        "--integration-type",
        default=None,
        help="Optional client-side filter on integration type",
    )
    integrations_connections_list.set_defaults(
        handler=_cmd_integrations_connections_list
    )

    integrations_connections_mirror_runs = integrations_connections_sub.add_parser(
        "mirror-runs",
        help="List mirror, resync, and reconcile runs for an integration connection",
    )
    integrations_connections_mirror_runs.add_argument("--workspace", required=True)
    integrations_connections_mirror_runs.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_mirror_runs.add_argument("--run-group-id", default=None)
    integrations_connections_mirror_runs.add_argument("--run-type", default=None)
    integrations_connections_mirror_runs.add_argument(
        "--since",
        default=None,
        help="Optional ISO-8601 lower bound for created_on filtering.",
    )
    integrations_connections_mirror_runs.add_argument(
        "--until",
        default=None,
        help="Optional ISO-8601 upper bound for created_on filtering.",
    )
    integrations_connections_mirror_runs.add_argument(
        "--limit", type=int, default=50
    )
    integrations_connections_mirror_runs.add_argument(
        "--offset", type=int, default=0
    )
    integrations_connections_mirror_runs.set_defaults(
        handler=_cmd_integrations_connections_mirror_runs
    )

    integrations_connections_logs = integrations_connections_sub.add_parser(
        "logs",
        help="List normalized integration logs with lane and entity filters",
    )
    integrations_connections_logs.add_argument("--workspace", required=True)
    integrations_connections_logs.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_logs.add_argument(
        "--lane",
        choices=[
            "received_from_shopify",
            "sent_to_shopify",
            "sent_to_wms",
            "internal_processing",
        ],
        default="received_from_shopify",
    )
    integrations_connections_logs.add_argument("--status", default=None)
    integrations_connections_logs.add_argument("--operation-topic", default=None)
    integrations_connections_logs.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        default=None,
        help="Entity/external object type filter (for example order, inventory_item).",
    )
    integrations_connections_logs.add_argument(
        "--entity-id",
        "--external-object-id",
        dest="external_object_id",
        default=None,
        help="Entity/external object id filter (for example Shopify gid).",
    )
    integrations_connections_logs.add_argument("--correlation-id", default=None)
    integrations_connections_logs.add_argument("--since", default=None)
    integrations_connections_logs.add_argument("--until", default=None)
    integrations_connections_logs.add_argument("--limit", type=int, default=50)
    integrations_connections_logs.add_argument("--offset", type=int, default=0)
    integrations_connections_logs.add_argument("--sort-key", default=None)
    integrations_connections_logs.add_argument(
        "--sort-direction",
        choices=["asc", "desc"],
        default="desc",
    )
    integrations_connections_logs.set_defaults(
        handler=_cmd_integrations_connections_logs
    )

    integrations_connections_related_logs = integrations_connections_sub.add_parser(
        "related-logs",
        help="List cross-lane activity for one correlation id or source record",
    )
    integrations_connections_related_logs.add_argument("--workspace", required=True)
    integrations_connections_related_logs.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_related_logs.add_argument("--correlation-id", default=None)
    integrations_connections_related_logs.add_argument(
        "--source-kind",
        choices=["event", "webhook", "delivery"],
        default=None,
    )
    integrations_connections_related_logs.add_argument("--source-id", default=None)
    integrations_connections_related_logs.add_argument("--limit", type=int, default=50)
    integrations_connections_related_logs.add_argument("--offset", type=int, default=0)
    integrations_connections_related_logs.set_defaults(
        handler=_cmd_integrations_connections_related_logs
    )

    integrations_connections_webhooks = integrations_connections_sub.add_parser(
        "webhooks",
        help="List inbound webhook inbox events for an integration connection",
    )
    integrations_connections_webhooks.add_argument("--workspace", required=True)
    integrations_connections_webhooks.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_webhooks.add_argument("--topic", default=None)
    integrations_connections_webhooks.add_argument("--status", default=None)
    integrations_connections_webhooks.add_argument("--since", default=None)
    integrations_connections_webhooks.add_argument("--until", default=None)
    integrations_connections_webhooks.add_argument("--limit", type=int, default=50)
    integrations_connections_webhooks.add_argument("--offset", type=int, default=0)
    integrations_connections_webhooks.add_argument("--sort-key", default=None)
    integrations_connections_webhooks.add_argument(
        "--sort-direction",
        choices=["asc", "desc"],
        default="desc",
    )
    integrations_connections_webhooks.set_defaults(
        handler=_cmd_integrations_connections_webhooks
    )

    integrations_connections_webhook_deliveries = (
        integrations_connections_sub.add_parser(
            "webhook-deliveries",
            help="List outbound WMS webhook delivery attempts",
        )
    )
    integrations_connections_webhook_deliveries.add_argument(
        "--workspace", required=True
    )
    integrations_connections_webhook_deliveries.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_webhook_deliveries.add_argument("--status", default=None)
    integrations_connections_webhook_deliveries.add_argument("--event-type", default=None)
    integrations_connections_webhook_deliveries.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        default=None,
    )
    integrations_connections_webhook_deliveries.add_argument(
        "--entity-id",
        "--external-object-id",
        dest="external_object_id",
        default=None,
    )
    integrations_connections_webhook_deliveries.add_argument(
        "--correlation-id", default=None
    )
    integrations_connections_webhook_deliveries.add_argument("--since", default=None)
    integrations_connections_webhook_deliveries.add_argument("--until", default=None)
    integrations_connections_webhook_deliveries.add_argument(
        "--limit", type=int, default=50
    )
    integrations_connections_webhook_deliveries.add_argument(
        "--offset", type=int, default=0
    )
    integrations_connections_webhook_deliveries.set_defaults(
        handler=_cmd_integrations_connections_webhook_deliveries
    )

    integrations_connections_trace = integrations_connections_sub.add_parser(
        "trace",
        help="Show the integration object summary, timeline, and all log lanes for one entity or correlation",
    )
    integrations_connections_trace.add_argument("--workspace", required=True)
    integrations_connections_trace.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_connections_trace.add_argument(
        "--integration-object-id",
        default=None,
        help="Optional stored integration object id. If omitted, trace resolves by entity type/id.",
    )
    integrations_connections_trace.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        default=None,
    )
    integrations_connections_trace.add_argument(
        "--entity-id",
        "--external-object-id",
        dest="external_object_id",
        default=None,
    )
    integrations_connections_trace.add_argument("--correlation-id", default=None)
    integrations_connections_trace.add_argument("--since", default=None)
    integrations_connections_trace.add_argument("--until", default=None)
    integrations_connections_trace.add_argument("--limit", type=int, default=50)
    integrations_connections_trace.add_argument("--offset", type=int, default=0)
    integrations_connections_trace.set_defaults(
        handler=_cmd_integrations_connections_trace
    )

    integrations_objects = integrations_connections_sub.add_parser(
        "objects",
        help="Integration object diagnostics",
    )
    integrations_objects_sub = integrations_objects.add_subparsers(
        dest="integrations_objects_cmd",
        required=True,
    )

    integrations_objects_products = integrations_objects_sub.add_parser(
        "products",
        help="List Shopify product objects",
    )
    integrations_objects_products.add_argument("--workspace", required=True)
    integrations_objects_products.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_products.add_argument("--limit", type=int, default=50)
    integrations_objects_products.add_argument("--offset", type=int, default=0)
    integrations_objects_products.set_defaults(
        handler=_cmd_integrations_objects_products
    )

    integrations_objects_variants = integrations_objects_sub.add_parser(
        "variants",
        aliases=["skus"],
        help="List Shopify variant objects (includes SKU data)",
    )
    integrations_objects_variants.add_argument("--workspace", required=True)
    integrations_objects_variants.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_variants.add_argument("--limit", type=int, default=50)
    integrations_objects_variants.add_argument("--offset", type=int, default=0)
    integrations_objects_variants.set_defaults(
        handler=_cmd_integrations_objects_variants
    )

    integrations_objects_inventory_items = integrations_objects_sub.add_parser(
        "inventory-items",
        help="List Shopify inventory item objects",
    )
    integrations_objects_inventory_items.add_argument("--workspace", required=True)
    integrations_objects_inventory_items.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_inventory_items.add_argument("--limit", type=int, default=50)
    integrations_objects_inventory_items.add_argument(
        "--offset", type=int, default=0
    )
    integrations_objects_inventory_items.set_defaults(
        handler=_cmd_integrations_objects_inventory_items
    )

    integrations_objects_inventory_levels = integrations_objects_sub.add_parser(
        "inventory-levels",
        help="List Shopify inventory level objects",
    )
    integrations_objects_inventory_levels.add_argument("--workspace", required=True)
    integrations_objects_inventory_levels.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_inventory_levels.add_argument(
        "--limit", type=int, default=50
    )
    integrations_objects_inventory_levels.add_argument("--offset", type=int, default=0)
    integrations_objects_inventory_levels.set_defaults(
        handler=_cmd_integrations_objects_inventory_levels
    )

    integrations_objects_by_type = integrations_objects_sub.add_parser(
        "by-type",
        help="List integration objects for any external object type",
    )
    integrations_objects_by_type.add_argument("--workspace", required=True)
    integrations_objects_by_type.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_by_type.add_argument(
        "--external-object-type", required=True
    )
    integrations_objects_by_type.add_argument("--limit", type=int, default=50)
    integrations_objects_by_type.add_argument("--offset", type=int, default=0)
    integrations_objects_by_type.set_defaults(
        handler=_cmd_integrations_objects_by_type
    )

    integrations_objects_fetch = integrations_objects_sub.add_parser(
        "fetch",
        help="Fetch Shopify objects by external type/id using fixed queries",
    )
    integrations_objects_fetch.add_argument("--workspace", required=True)
    integrations_objects_fetch.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_fetch.add_argument(
        "--external-object-type",
        required=True,
        help="External object type or Shopify mirror entity (e.g. variant, inventory_item, variants)",
    )
    integrations_objects_fetch.add_argument(
        "--external-object-id",
        action="append",
        required=True,
        help="External object id (Shopify gid or numeric id). Repeat for multiple ids.",
    )
    integrations_objects_fetch.set_defaults(
        handler=_cmd_integrations_objects_fetch
    )

    integrations_objects_get = integrations_objects_sub.add_parser(
        "get",
        help="Get one integration object payload by integration object id",
    )
    integrations_objects_get.add_argument("--workspace", required=True)
    integrations_objects_get.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_get.add_argument("--integration-object-id", required=True)
    integrations_objects_get.set_defaults(handler=_cmd_integrations_objects_get)

    integrations_objects_lookup = integrations_objects_sub.add_parser(
        "lookup",
        help="Find a stored integration object by external entity type/id",
    )
    integrations_objects_lookup.add_argument("--workspace", required=True)
    integrations_objects_lookup.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_lookup.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        required=True,
    )
    integrations_objects_lookup.add_argument(
        "--entity-id",
        "--external-object-id",
        dest="external_object_id",
        required=True,
    )
    integrations_objects_lookup.set_defaults(
        handler=_cmd_integrations_objects_lookup
    )

    integrations_objects_missing_external_sample = (
        integrations_objects_sub.add_parser(
            "missing-external-sample",
            aliases=["missing-sample"],
            help="Scan stored objects and return samples missing from live Shopify",
        )
    )
    integrations_objects_missing_external_sample.add_argument(
        "--workspace", required=True
    )
    integrations_objects_missing_external_sample.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_missing_external_sample.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        required=True,
        help="Stored external object type (for example variant, product, inventory_item).",
    )
    integrations_objects_missing_external_sample.add_argument(
        "--sample-limit", type=int, default=1
    )
    integrations_objects_missing_external_sample.add_argument(
        "--batch-size", type=int, default=50
    )
    integrations_objects_missing_external_sample.add_argument(
        "--max-items",
        type=int,
        default=None,
        help="Optional cap on stored objects scanned before stopping.",
    )
    integrations_objects_missing_external_sample.set_defaults(
        handler=_cmd_integrations_objects_missing_external_sample
    )

    integrations_objects_shopify_history = integrations_objects_sub.add_parser(
        "shopify-history",
        help="Read live Shopify event history for one object when the object still exists",
    )
    integrations_objects_shopify_history.add_argument("--workspace", required=True)
    integrations_objects_shopify_history.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_shopify_history.add_argument(
        "--entity-type",
        "--external-object-type",
        dest="external_object_type",
        required=True,
    )
    integrations_objects_shopify_history.add_argument(
        "--entity-id",
        "--external-object-id",
        dest="external_object_id",
        required=True,
    )
    integrations_objects_shopify_history.add_argument(
        "--limit", type=int, default=25
    )
    integrations_objects_shopify_history.set_defaults(
        handler=_cmd_integrations_objects_shopify_history
    )

    integrations_objects_timeline = integrations_objects_sub.add_parser(
        "timeline",
        help="Show event/webhook timeline for one integration object",
    )
    integrations_objects_timeline.add_argument("--workspace", required=True)
    integrations_objects_timeline.add_argument(
        "--integration-connection-id", required=True
    )
    integrations_objects_timeline.add_argument(
        "--integration-object-id", required=True
    )
    integrations_objects_timeline.add_argument("--limit", type=int, default=50)
    integrations_objects_timeline.set_defaults(
        handler=_cmd_integrations_objects_timeline
    )

    wms_parser = root_subparsers.add_parser("wms", help="WMS commands")
    wms_sub = wms_parser.add_subparsers(dest="wms_cmd", required=True)

    wms_facilities = wms_sub.add_parser("facilities", help="List facilities")
    wms_facilities.add_argument("--workspace", required=True)
    wms_facilities.add_argument("--limit", type=int, default=50)
    wms_facilities.add_argument("--offset", type=int, default=0)
    wms_facilities.add_argument(
        "--require-manage-stock",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_facilities.set_defaults(handler=_cmd_wms_facilities)

    wms_skus = wms_sub.add_parser("skus", help="List SKUs")
    wms_skus.add_argument("--workspace", required=True)
    wms_skus.add_argument("--query", default=None)
    wms_skus.add_argument("--limit", type=int, default=50)
    wms_skus.add_argument("--offset", type=int, default=0)
    wms_skus.add_argument(
        "--include-on-hand",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_skus.add_argument(
        "--in-stock-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_skus.set_defaults(handler=_cmd_wms_skus)

    wms_package_profiles = wms_sub.add_parser(
        "package-profiles",
        help="Reusable dispatch package profile commands",
    )
    wms_package_profiles_sub = wms_package_profiles.add_subparsers(
        dest="wms_package_profiles_cmd",
        required=True,
    )
    wms_package_profiles_list = wms_package_profiles_sub.add_parser(
        "list",
        help="List reusable dispatch package profiles",
    )
    wms_package_profiles_list.add_argument("--workspace", required=True)
    wms_package_profiles_list.add_argument("--facility-id", default=None)
    wms_package_profiles_list.add_argument(
        "--inventory-owner-id",
        default=None,
    )
    wms_package_profiles_list.add_argument(
        "--include-inactive",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_package_profiles_list.add_argument("--limit", type=int, default=50)
    wms_package_profiles_list.add_argument("--offset", type=int, default=0)
    wms_package_profiles_list.set_defaults(handler=_cmd_wms_package_profiles_list)

    wms_package_profiles_create = wms_package_profiles_sub.add_parser(
        "create",
        help="Create a reusable dispatch package profile",
    )
    wms_package_profiles_create.add_argument("--workspace", required=True)
    wms_package_profiles_create.add_argument("--code", required=True)
    wms_package_profiles_create.add_argument("--name", required=True)
    wms_package_profiles_create.add_argument("--facility-id", default=None)
    wms_package_profiles_create.add_argument(
        "--inventory-owner-id",
        default=None,
    )
    wms_package_profiles_create.add_argument("--package-type", default=None)
    wms_package_profiles_create.add_argument(
        "--package-class",
        choices=WMS_PACKAGE_PROFILE_CLASSES,
        default=None,
    )
    wms_package_profiles_create.add_argument(
        "--default-weight-grams",
        type=int,
        default=None,
    )
    wms_package_profiles_create.add_argument("--length-mm", type=int, default=None)
    wms_package_profiles_create.add_argument("--width-mm", type=int, default=None)
    wms_package_profiles_create.add_argument("--height-mm", type=int, default=None)
    wms_package_profiles_create.add_argument("--notes", default=None)
    wms_package_profiles_create.add_argument(
        "--metadata-json",
        default=None,
        help="Inline JSON object to send as metadata_json.",
    )
    wms_package_profiles_create.add_argument(
        "--metadata-file",
        default=None,
        help="Path to a JSON file whose object content is sent as metadata_json.",
    )
    wms_package_profiles_create.add_argument(
        "--active",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_package_profiles_create.set_defaults(
        handler=_cmd_wms_package_profiles_create
    )

    wms_query = wms_sub.add_parser(
        "query",
        help="Query any read-only WMS endpoint (debug helper)",
    )
    wms_query.add_argument("--workspace", required=True)
    wms_query.add_argument(
        "--path",
        required=True,
        help=(
            "Endpoint path relative to /workspaces/{workspace}/wms, or full "
            "/api/v2/workspaces/{workspace}/wms path."
        ),
    )
    wms_query.add_argument(
        "--param",
        action="append",
        default=[],
        help="Query parameter in key=value format (repeatable).",
    )
    wms_query.set_defaults(handler=_cmd_wms_query)

    wms_barcodes = wms_sub.add_parser(
        "barcodes",
        help="Barcode diagnostic commands",
    )
    wms_barcodes_sub = wms_barcodes.add_subparsers(
        dest="wms_barcodes_cmd",
        required=True,
    )
    wms_barcodes_resolve = wms_barcodes_sub.add_parser(
        "resolve",
        help="Resolve one barcode against SKU/container/location matches",
    )
    wms_barcodes_resolve.add_argument("--workspace", required=True)
    wms_barcodes_resolve.add_argument("--facility-id", required=True)
    wms_barcodes_resolve.add_argument("--barcode", required=True)
    wms_barcodes_resolve.set_defaults(handler=_cmd_wms_barcodes_resolve)

    wms_containers = wms_sub.add_parser(
        "containers",
        help="Container diagnostics",
    )
    wms_containers_sub = wms_containers.add_subparsers(
        dest="wms_containers_cmd",
        required=True,
    )
    wms_containers_outbound_context = wms_containers_sub.add_parser(
        "outbound-context",
        help="Inspect outbound fulfillment context for one container/tote",
    )
    wms_containers_outbound_context.add_argument("--workspace", required=True)
    wms_containers_outbound_context.add_argument("--container-id", required=True)
    wms_containers_outbound_context.set_defaults(
        handler=_cmd_wms_containers_outbound_context
    )

    wms_dispatches = wms_sub.add_parser(
        "dispatches",
        help="Dispatch inspection and debugging commands",
    )
    wms_dispatches_sub = wms_dispatches.add_subparsers(
        dest="wms_dispatches_cmd",
        required=True,
    )
    wms_dispatches_list = wms_dispatches_sub.add_parser(
        "list",
        help="List dispatch documents",
    )
    wms_dispatches_list.add_argument("--workspace", required=True)
    wms_dispatches_list.add_argument("--facility-id", default=None)
    wms_dispatches_list.add_argument("--status", default=None)
    wms_dispatches_list.add_argument("--search-query", default=None)
    wms_dispatches_list.add_argument("--limit", type=int, default=50)
    wms_dispatches_list.add_argument("--offset", type=int, default=0)
    wms_dispatches_list.set_defaults(handler=_cmd_wms_dispatches_list)

    wms_dispatches_detail = wms_dispatches_sub.add_parser(
        "detail",
        help="Get one dispatch detail payload",
    )
    wms_dispatches_detail.add_argument("--workspace", required=True)
    wms_dispatches_detail.add_argument("--dispatch-id", required=True)
    wms_dispatches_detail.set_defaults(handler=_cmd_wms_dispatches_detail)

    wms_dispatches_context = wms_dispatches_sub.add_parser(
        "context",
        help="Get dispatch context/capabilities/status policy",
    )
    wms_dispatches_context.add_argument("--workspace", required=True)
    wms_dispatches_context.add_argument("--dispatch-id", required=True)
    wms_dispatches_context.add_argument(
        "--include-projection-totals",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_dispatches_context.set_defaults(handler=_cmd_wms_dispatches_context)

    wms_dispatches_packages = wms_dispatches_sub.add_parser(
        "packages",
        help="Show dispatch package allocations, labels, and manifest membership",
    )
    wms_dispatches_packages.add_argument("--workspace", required=True)
    wms_dispatches_packages.add_argument("--dispatch-id", required=True)
    wms_dispatches_packages.set_defaults(handler=_cmd_wms_dispatches_packages)

    wms_dispatches_issues = wms_dispatches_sub.add_parser(
        "issues",
        help="List operational issues scoped to one dispatch",
    )
    wms_dispatches_issues.add_argument("--workspace", required=True)
    wms_dispatches_issues.add_argument("--dispatch-id", required=True)
    wms_dispatches_issues.add_argument("--facility-id", default=None)
    wms_dispatches_issues.add_argument("--status", default="open")
    wms_dispatches_issues.add_argument("--severity", default=None)
    wms_dispatches_issues.add_argument("--issue-code", default=None)
    wms_dispatches_issues.add_argument("--limit", type=int, default=50)
    wms_dispatches_issues.add_argument("--offset", type=int, default=0)
    wms_dispatches_issues.set_defaults(handler=_cmd_wms_dispatches_issues)

    wms_dispatches_trace = wms_dispatches_sub.add_parser(
        "trace",
        help="Show dispatch summary, packages, context, and issues in one view",
    )
    wms_dispatches_trace.add_argument("--workspace", required=True)
    wms_dispatches_trace.add_argument("--dispatch-id", required=True)
    wms_dispatches_trace.add_argument("--facility-id", default=None)
    wms_dispatches_trace.add_argument("--status", default="open")
    wms_dispatches_trace.add_argument("--severity", default=None)
    wms_dispatches_trace.add_argument("--issue-code", default=None)
    wms_dispatches_trace.add_argument(
        "--include-projection-totals",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_dispatches_trace.add_argument("--limit", type=int, default=50)
    wms_dispatches_trace.add_argument("--offset", type=int, default=0)
    wms_dispatches_trace.set_defaults(handler=_cmd_wms_dispatches_trace)

    wms_manifests = wms_sub.add_parser(
        "manifests",
        help="Dispatch manifest inspection and debugging commands",
    )
    wms_manifests_sub = wms_manifests.add_subparsers(
        dest="wms_manifests_cmd",
        required=True,
    )
    wms_manifests_list = wms_manifests_sub.add_parser(
        "list",
        help="List dispatch manifests",
    )
    wms_manifests_list.add_argument("--workspace", required=True)
    wms_manifests_list.add_argument("--facility-id", default=None)
    wms_manifests_list.add_argument("--inventory-owner-id", default=None)
    wms_manifests_list.add_argument(
        "--status",
        action="append",
        default=[],
        help="Manifest status filter (repeatable).",
    )
    wms_manifests_list.add_argument("--limit", type=int, default=50)
    wms_manifests_list.add_argument("--offset", type=int, default=0)
    wms_manifests_list.set_defaults(handler=_cmd_wms_manifests_list)

    wms_manifests_detail = wms_manifests_sub.add_parser(
        "detail",
        help="Get one dispatch manifest detail payload",
    )
    wms_manifests_detail.add_argument("--workspace", required=True)
    wms_manifests_detail.add_argument("--dispatch-manifest-id", required=True)
    wms_manifests_detail.set_defaults(handler=_cmd_wms_manifests_detail)

    wms_manifests_context = wms_manifests_sub.add_parser(
        "context",
        help="Get dispatch manifest context/capabilities/status policy",
    )
    wms_manifests_context.add_argument("--workspace", required=True)
    wms_manifests_context.add_argument("--dispatch-manifest-id", required=True)
    wms_manifests_context.add_argument(
        "--include-projection-totals",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_manifests_context.set_defaults(handler=_cmd_wms_manifests_context)

    wms_manifests_payload = wms_manifests_sub.add_parser(
        "payload",
        help="Show manifest dispatch/package payload summary",
    )
    wms_manifests_payload.add_argument("--workspace", required=True)
    wms_manifests_payload.add_argument("--dispatch-manifest-id", required=True)
    wms_manifests_payload.set_defaults(handler=_cmd_wms_manifests_payload)

    wms_manifests_issues = wms_manifests_sub.add_parser(
        "issues",
        help="List operational issues scoped to one dispatch manifest",
    )
    wms_manifests_issues.add_argument("--workspace", required=True)
    wms_manifests_issues.add_argument("--dispatch-manifest-id", required=True)
    wms_manifests_issues.add_argument("--facility-id", default=None)
    wms_manifests_issues.add_argument("--status", default="open")
    wms_manifests_issues.add_argument("--severity", default=None)
    wms_manifests_issues.add_argument("--issue-code", default=None)
    wms_manifests_issues.add_argument("--limit", type=int, default=50)
    wms_manifests_issues.add_argument("--offset", type=int, default=0)
    wms_manifests_issues.set_defaults(handler=_cmd_wms_manifests_issues)

    wms_manifests_trace = wms_manifests_sub.add_parser(
        "trace",
        help="Show manifest summary, payload, context, and issues in one view",
    )
    wms_manifests_trace.add_argument("--workspace", required=True)
    wms_manifests_trace.add_argument("--dispatch-manifest-id", required=True)
    wms_manifests_trace.add_argument("--facility-id", default=None)
    wms_manifests_trace.add_argument("--status", default="open")
    wms_manifests_trace.add_argument("--severity", default=None)
    wms_manifests_trace.add_argument("--issue-code", default=None)
    wms_manifests_trace.add_argument(
        "--include-projection-totals",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_manifests_trace.add_argument("--limit", type=int, default=50)
    wms_manifests_trace.add_argument("--offset", type=int, default=0)
    wms_manifests_trace.set_defaults(handler=_cmd_wms_manifests_trace)

    wms_documents = wms_sub.add_parser(
        "documents",
        help="Document-level diagnostics (detail, context, links, lineage)",
    )
    wms_documents_sub = wms_documents.add_subparsers(
        dest="wms_documents_cmd",
        required=True,
    )

    wms_documents_list = wms_documents_sub.add_parser(
        "list",
        help="List documents by kind",
    )
    wms_documents_list.add_argument("--workspace", required=True)
    wms_documents_list.add_argument("--kind", required=True)
    wms_documents_list.add_argument("--facility-id", default=None)
    wms_documents_list.add_argument("--status", default=None)
    wms_documents_list.add_argument("--search-query", default=None)
    wms_documents_list.add_argument("--limit", type=int, default=50)
    wms_documents_list.add_argument("--offset", type=int, default=0)
    wms_documents_list.set_defaults(handler=_cmd_wms_documents_list)

    wms_documents_detail = wms_documents_sub.add_parser(
        "detail",
        help="Get one document detail payload",
    )
    wms_documents_detail.add_argument("--workspace", required=True)
    wms_documents_detail.add_argument("--kind", required=True)
    wms_documents_detail.add_argument("--document-id", required=True)
    wms_documents_detail.set_defaults(handler=_cmd_wms_documents_detail)

    wms_documents_context = wms_documents_sub.add_parser(
        "context",
        help="Get context/capabilities/status policy for one document",
    )
    wms_documents_context.add_argument("--workspace", required=True)
    wms_documents_context.add_argument("--kind", required=True)
    wms_documents_context.add_argument("--document-id", required=True)
    wms_documents_context.add_argument(
        "--include-projection-totals",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    wms_documents_context.set_defaults(handler=_cmd_wms_documents_context)

    wms_documents_links = wms_documents_sub.add_parser(
        "links",
        help="List line links for a document",
    )
    wms_documents_links.add_argument("--workspace", required=True)
    wms_documents_links.add_argument("--kind", required=True)
    wms_documents_links.add_argument("--document-id", required=True)
    wms_documents_links.add_argument(
        "--include-inactive",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_documents_links.set_defaults(handler=_cmd_wms_documents_links)

    wms_documents_line_links = wms_documents_sub.add_parser(
        "line-links",
        help="List line links for one document line",
    )
    wms_documents_line_links.add_argument("--workspace", required=True)
    wms_documents_line_links.add_argument("--kind", required=True)
    wms_documents_line_links.add_argument("--document-id", required=True)
    wms_documents_line_links.add_argument("--line-id", required=True)
    wms_documents_line_links.add_argument(
        "--include-inactive",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_documents_line_links.set_defaults(handler=_cmd_wms_documents_line_links)

    wms_documents_lineage = wms_documents_sub.add_parser(
        "lineage",
        help="List lineage chain for one document line",
    )
    wms_documents_lineage.add_argument("--workspace", required=True)
    wms_documents_lineage.add_argument("--kind", required=True)
    wms_documents_lineage.add_argument("--document-id", required=True)
    wms_documents_lineage.add_argument("--line-id", required=True)
    wms_documents_lineage.add_argument(
        "--include-inactive",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_documents_lineage.add_argument("--max-depth", type=int, default=6)
    wms_documents_lineage.set_defaults(handler=_cmd_wms_documents_lineage)

    wms_issues = wms_sub.add_parser(
        "issues",
        help="Operational issue diagnostics and actions",
    )
    wms_issues_sub = wms_issues.add_subparsers(
        dest="wms_issues_cmd",
        required=True,
    )

    wms_issues_list = wms_issues_sub.add_parser(
        "list",
        help="List operational issues",
    )
    wms_issues_list.add_argument("--workspace", required=True)
    wms_issues_list.add_argument("--facility-id", default=None)
    wms_issues_list.add_argument("--status", default=None)
    wms_issues_list.add_argument("--severity", default=None)
    wms_issues_list.add_argument("--issue-code", default=None)
    wms_issues_list.add_argument("--scope", default=None)
    wms_issues_list.add_argument("--document-kind", default=None)
    wms_issues_list.add_argument("--document-id", default=None)
    wms_issues_list.add_argument("--line-id", default=None)
    wms_issues_list.add_argument("--limit", type=int, default=50)
    wms_issues_list.add_argument("--offset", type=int, default=0)
    wms_issues_list.set_defaults(handler=_cmd_wms_issues_list)

    wms_issues_detail = wms_issues_sub.add_parser(
        "detail",
        help="Get one operational issue by id",
    )
    wms_issues_detail.add_argument("--workspace", required=True)
    wms_issues_detail.add_argument("--issue-id", required=True)
    wms_issues_detail.set_defaults(handler=_cmd_wms_issues_detail)

    wms_issues_resolve = wms_issues_sub.add_parser(
        "resolve",
        help="Resolve one operational issue",
    )
    wms_issues_resolve.add_argument("--workspace", required=True)
    wms_issues_resolve.add_argument("--issue-id", required=True)
    wms_issues_resolve.add_argument("--notes", default=None)
    wms_issues_resolve.set_defaults(handler=_cmd_wms_issues_resolve)

    wms_issues_ignore = wms_issues_sub.add_parser(
        "ignore",
        help="Ignore one operational issue",
    )
    wms_issues_ignore.add_argument("--workspace", required=True)
    wms_issues_ignore.add_argument("--issue-id", required=True)
    wms_issues_ignore.add_argument("--notes", default=None)
    wms_issues_ignore.set_defaults(handler=_cmd_wms_issues_ignore)

    wms_issues_reopen = wms_issues_sub.add_parser(
        "reopen",
        help="Reopen one operational issue",
    )
    wms_issues_reopen.add_argument("--workspace", required=True)
    wms_issues_reopen.add_argument("--issue-id", required=True)
    wms_issues_reopen.add_argument("--notes", default=None)
    wms_issues_reopen.set_defaults(handler=_cmd_wms_issues_reopen)

    wms_issues_recompute = wms_issues_sub.add_parser(
        "recompute",
        help="Recompute operational issues for a scoped workspace/facility/document",
    )
    wms_issues_recompute.add_argument("--workspace", required=True)
    wms_issues_recompute.add_argument("--facility-id", default=None)
    wms_issues_recompute.add_argument("--scope", default=None)
    wms_issues_recompute.add_argument("--document-kind", default=None)
    wms_issues_recompute.add_argument("--document-id", default=None)
    wms_issues_recompute.add_argument("--line-id", default=None)
    wms_issues_recompute.add_argument(
        "--dry-run",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_issues_recompute.set_defaults(handler=_cmd_wms_issues_recompute)

    wms_connections = wms_sub.add_parser(
        "connections",
        help="Integration connection commands",
    )
    wms_connections_sub = wms_connections.add_subparsers(
        dest="wms_connections_cmd",
        required=True,
    )
    wms_connections_list = wms_connections_sub.add_parser(
        "list",
        help="List integration connections",
    )
    wms_connections_list.add_argument("--workspace", required=True)
    wms_connections_list.add_argument("--integration-type", default=None)
    wms_connections_list.set_defaults(handler=_cmd_wms_connections_list)

    wms_sku_mappings = wms_sub.add_parser(
        "sku-mappings",
        help="SKU mapping diagnostic commands",
    )
    wms_sku_mappings_sub = wms_sku_mappings.add_subparsers(
        dest="wms_sku_mappings_cmd",
        required=True,
    )
    wms_sku_mappings_by_connection = wms_sku_mappings_sub.add_parser(
        "by-connection",
        help="List SKU mappings for an integration connection",
    )
    wms_sku_mappings_by_connection.add_argument("--workspace", required=True)
    wms_sku_mappings_by_connection.add_argument(
        "--integration-connection-id",
        required=True,
    )
    wms_sku_mappings_by_connection.add_argument("--external-object-type", default=None)
    wms_sku_mappings_by_connection.add_argument("--external-object-id", default=None)
    wms_sku_mappings_by_connection.add_argument("--limit", type=int, default=50)
    wms_sku_mappings_by_connection.add_argument("--offset", type=int, default=0)
    wms_sku_mappings_by_connection.set_defaults(
        handler=_cmd_wms_sku_mappings_by_connection
    )

    wms_sku_mappings_by_sku = wms_sku_mappings_sub.add_parser(
        "by-sku",
        help="List mappings for a specific WMS SKU",
    )
    wms_sku_mappings_by_sku.add_argument("--workspace", required=True)
    wms_sku_mappings_by_sku.add_argument("--sku-id", required=True)
    wms_sku_mappings_by_sku.set_defaults(handler=_cmd_wms_sku_mappings_by_sku)

    wms_reconcile = wms_sub.add_parser(
        "reconcile",
        help="Inventory reconcile diagnostics",
    )
    wms_reconcile_sub = wms_reconcile.add_subparsers(
        dest="wms_reconcile_cmd",
        required=True,
    )
    wms_reconcile_available = wms_reconcile_sub.add_parser(
        "available",
        help="List WMS vs integration available-quantity reconcile rows",
    )
    wms_reconcile_available.add_argument("--workspace", required=True)
    wms_reconcile_available.add_argument(
        "--integration-connection-id",
        required=True,
    )
    wms_reconcile_available.add_argument("--sku-id", default=None)
    wms_reconcile_available.add_argument("--facility-id", default=None)
    wms_reconcile_available.add_argument("--limit", type=int, default=200)
    wms_reconcile_available.add_argument("--offset", type=int, default=0)
    wms_reconcile_available.add_argument(
        "--actionable-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_reconcile_available.add_argument(
        "--managed-only",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_reconcile_available.set_defaults(handler=_cmd_wms_reconcile_available)

    wms_reconcile_outbound = wms_reconcile_sub.add_parser(
        "outbound",
        help="Run Shopify outbound reconcile for fulfillment execution lines",
    )
    wms_reconcile_outbound.add_argument("--workspace", required=True)
    wms_reconcile_outbound.add_argument(
        "--integration-connection-id",
        required=True,
    )
    wms_reconcile_outbound.add_argument("--order-id", default=None)
    wms_reconcile_outbound.add_argument("--fulfillment-order-id", default=None)
    wms_reconcile_outbound.add_argument(
        "--dry-run",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    wms_reconcile_outbound.set_defaults(handler=_cmd_wms_reconcile_outbound)

    return parser


def cli(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    state = CliState(
        profile_name=args.profile,
        base_url_override=args.base_url,
        output_override=args.output,
        auth_mode=args.auth_mode,
    )
    try:
        payload = args.handler(args, state)  # type: ignore[attr-defined]
        if payload is not None:
            emit_payload(payload, output_mode=state.output_mode)
        return 0
    except KeyboardInterrupt:
        return 130
    except CliError as exc:
        print(str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(cli())
