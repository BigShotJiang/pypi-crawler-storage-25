
# Changelog
## [3.1.1] - 2026-03-31
 - Fix the bug in testing.
## [3.1.0] - 2026-03-30
- Energy-balance consistency check when all four states are known.
- Mass-flow written back after PPT/brentq solvers (was silently discarded).
- Upfront problem classifier (_classify_problem) catches zero-info,
        both-m̊-unknown, and over-specified inputs before any computation.
- Silent PPT mutation (self.PPT -= 0.001) replaced with a proper
        ValueError so pinch violations are never hidden.
- Phase-change guard in _solve_effectiveness(); falls back to
        enthalpy-based Q when either stream is two-phase (Cp is ill-defined).
- TES over-specified branch added: CI.H, CO.H, and Capacity all known
        → consistency check instead of silent fall-through.
- warnings.warn(RuntimeWarning) replaces bare print() in solver errors;
        Solution_Status set False and Cal() returns cleanly on non-fatal failures.
- SimpleHEX two-sided consistency path: when both cold and hot sides are
        fully given, Q from each side is compared and averaged if consistent.
-  _resolve_side() raises immediately when both mass-flows are None
        (was a silent None that propagated to arithmetic errors later).
- exergy sign and base-class helper preserved from v1.x bugfix baseline.
- All three Cal() methods now handle a "both-known" branch that validates
    isentropic consistency and emits a warning when the supplied enthalpy
    pair violates the declared efficiency.
- Pump.Cal() Incompressible branch now handles reverse (In.H is None)
    and both-known sub-cases with proper guards.
- fsolve calls use physically-motivated initial guesses (rather than
    the outlet enthalpy) and check convergence with full_output=True.
- Guard added in the Incompressible path for In.D being None.
- Duplicate 'from scipy.optimize import fsolve' inside Compressor.Cal()
    removed.
- All three __str__ methods guard against Solution_Status=False (i.e.
    Cal() was never called) so printing an unsolved component does not
    raise AttributeError on self.In / self.Out.

- CSV Export Functionality

Added CSV export capability to all plotting methods

    - save_csv parameter (default: False) - enables CSV export
    - csv_path parameter (optional) - custom file path, auto-generates if not provided
    - Auto-generated filenames include timestamp (e.g., Ts_diagram_20240115_143022.csv)
New utility methods:

    - export_all_points() - Export all thermodynamic state points to CSV
    - export_all_components() - Export all component performance data to CSV
    - _generate_csv_filename() - Auto-generate timestamped filenames
    - _save_dataframe_to_csv() - Centralized CSV saving with error handling
    Enhanced Data Structure

CSV files now include:
    - Original SI units (J/kg, Pa, K)
    - Converted engineering units (kJ/kg, bar, °C)
    - Point/component identification
    - Calculated derivatives (percentages, ratios)

## [3.0.0] - 2026-03-25

### Added
- Modular package structure (`ThermoSIm/` package with separate files)
- `Compressor` component for gas cycles (e.g., Brayton)
- `CyclePlotter` class with T-s, P-h, h-s diagrams, saturation domes
- Exergy destruction bar chart and pie chart
- Heat exchanger temperature profile plots
- Energy flow summary visualisation
- `SensitivityAnalyzer` with single sweep, double sweep, and multi-output
- `save_model()` and `load_model()` for JSON serialisation
- Abstract `Component` base class with shared helpers
- 48+ unit tests (pytest)
- `.gitignore`, `README.md`, `CHANGELOG.md`, `setup.py`

### Fixed
- `__init__` was misspelled as `init` (constructor never called)
- Exergy sign error in HeatExchanger and TES: was `Out_hot - Out_cold`, now `Out_hot + Out_cold`
- `ModelSummary()` crashed on second call (DataFrame append issue)
- Type checking used fragile string comparison instead of `isinstance()`
- `Solve()` silently swallowed all errors
- Multiple typos in error messages and `__str__` methods

### Changed
- Dead state stored in `config.py` module instead of class variable
- Mass-flow resolution logic extracted to base class
- Visualisation completely separated from computation
- Iterative solver now checks convergence

## [2.0.0] - Previous version
- Single-file module

## [1.0.0] - Initial release
- Basic functionality
