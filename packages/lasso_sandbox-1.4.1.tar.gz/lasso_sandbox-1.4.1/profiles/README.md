# LASSO Profiles

Pre-built sandbox security policies. Each profile defines what an AI agent
can and cannot do inside a sandbox.

## Built-in Profiles

| Profile | Network | Commands | Use Case |
|---------|---------|----------|----------|
| `daily` | Limited (package registries) | 38 tools | Everyday coding with git, npm, pip, python |
| `evaluation` | Offline (no network) | 8 tools | Evaluating untrusted agents, read-only |
| `prototyping` | Limited (package registries) | Blocklist | Maximum flexibility, dangerous commands blocked |
| `strict` | Offline (no network) | 18 tools | High-security work, full audit trail |
| `data-room` | Offline (no network) | 18 tools | Sensitive data work, workspace-only access |

## Using Profiles

```bash
# Create a sandbox with a specific profile
lasso create daily --dir .

# Or use lasso up (auto-detects the best profile)
lasso up
```

## Customizing

Create team profiles that extend built-ins:

```toml
# team-secure.toml
extends = "strict"
name = "team-secure"
description = "Team profile with custom allowed repos"

[git_access]
allowed_repos = ["myorg/my-repo"]
```

Save to `~/.lasso/profiles/team-secure.toml` or use the dashboard
profile editor to create profiles visually.

## Dashboard

The LASSO dashboard provides a visual profile editor for creating and
customizing profiles without editing TOML files. Run `lasso dashboard`
to access it.
