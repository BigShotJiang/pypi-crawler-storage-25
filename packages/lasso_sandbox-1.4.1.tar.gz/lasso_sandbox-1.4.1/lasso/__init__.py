"""LASSO - Layered Agent Sandbox Security Orchestrator."""

__version__ = "1.4.1"

__all__ = ["__version__"]
