"""LASSO Dashboard — Flask application factory.

Usage:
    from lasso.dashboard.app import create_app
    app = create_app(registry=my_registry, backend=my_backend)
    app.run(debug=True)

Requires: pip install flask
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import platform
import secrets
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from flask import (
        Blueprint,
        Flask,
        abort,
        jsonify,
        redirect,
        render_template,
        request,
        url_for,
    )
except ImportError:
    raise ImportError(
        "Flask is required for the dashboard. "
        "Install it with: pip install lasso-sandbox[dashboard]"
    )

from lasso import __version__
from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.profile import list_profiles, load_profile, save_profile
from lasso.config.schema import (
    AuditConfig,
    CommandConfig,
    CommandMode,
    FilesystemConfig,
    NetworkConfig,
    NetworkMode,
    ResourceConfig,
    SandboxProfile,
)
from lasso.core.sandbox import SandboxRegistry
from lasso.dashboard.auth import init_dashboard_auth, require_login

# ---------------------------------------------------------------------------
# Agent CLI command mapping
# ---------------------------------------------------------------------------

AGENT_COMMANDS = {
    "claude-code": "claude",
    "opencode": "opencode",
}

# ---------------------------------------------------------------------------
# Audit log reader utility
# ---------------------------------------------------------------------------

def read_audit_log(
    path: str | Path,
    tail: int = 50,
    event_type: str | None = None,
    offset: int = 0,
) -> list[dict]:
    """Read a JSONL audit log, optionally filtered and paginated."""
    entries: list[dict] = []
    path = Path(path)
    if not path.exists():
        return entries
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event_type and entry.get("type") != event_type:
                    continue
                entries.append(entry)
    except (OSError, PermissionError):
        return entries
    # Apply offset + tail for pagination
    if offset:
        entries = entries[offset:]
    return entries[-tail:] if tail else entries


def _system_capabilities() -> dict[str, Any]:
    """Gather system info for the check page."""
    caps: dict[str, Any] = {}

    # Docker / Podman
    caps["docker"] = shutil.which("docker") is not None
    caps["podman"] = shutil.which("podman") is not None

    # Linux namespaces
    caps["user_ns"] = Path("/proc/self/ns/user").exists()
    caps["mount_ns"] = Path("/proc/self/ns/mnt").exists()
    caps["pid_ns"] = Path("/proc/self/ns/pid").exists()
    caps["net_ns"] = Path("/proc/self/ns/net").exists()

    # Cgroups v2
    caps["cgroups_v2"] = Path("/sys/fs/cgroup/cgroup.controllers").exists()

    # Platform
    caps["platform"] = platform.platform()
    caps["python"] = platform.python_version()

    return caps


# ---------------------------------------------------------------------------
# Blueprint
# ---------------------------------------------------------------------------

dashboard_bp = Blueprint(
    "dashboard",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/dashboard/static",
)


def _get_registry() -> SandboxRegistry:
    from flask import current_app
    reg = current_app.config.get("REGISTRY")
    if reg is None:
        # Auto-detect a container backend so reconnection to existing
        # containers works even when the dashboard is started standalone.
        backend = current_app.config.get("BACKEND")
        if backend is None:
            try:
                from lasso.backends.detect import detect_backend
                backend = detect_backend()
                current_app.config["BACKEND"] = backend
            except Exception:
                pass
        reg = SandboxRegistry(backend=backend)
        current_app.config["REGISTRY"] = reg
    return reg


def _get_backend():
    from flask import current_app
    return current_app.config.get("BACKEND")


def _default_sandbox_dir() -> str:
    """Return a platform-appropriate default sandbox directory."""
    import tempfile
    return str(Path(tempfile.gettempdir()) / "lasso-sandbox")


def _get_all_profiles() -> list[dict]:
    """Return combined list of builtin + saved profiles."""
    profiles = []
    for name, factory in BUILTIN_PROFILES.items():
        p = factory(_default_sandbox_dir())
        profiles.append({
            "name": name,
            "description": p.description,
            "source": "builtin",
            "cmd_mode": p.commands.mode.value,
            "net_mode": p.network.mode.value,
            "mem_limit": f"{p.resources.max_memory_mb}MB",
            "tags": p.tags,
        })
    for saved in list_profiles():
        if "error" not in saved:
            saved["source"] = "saved"
            saved["description"] = saved.get("description", "")
            profiles.append(saved)
    return profiles


def _state_color(state: str) -> str:
    """Map sandbox state to a CSS color class."""
    return {
        "running": "state-running",
        "created": "state-created",
        "configuring": "state-configuring",
        "stopped": "state-stopped",
        "paused": "state-paused",
        "error": "state-error",
    }.get(state, "")


# ---------------------------------------------------------------------------
# Helper — enrich sandbox dicts for templates
# ---------------------------------------------------------------------------

def _security_level_label(sb: dict) -> str:
    """Return a human-readable security level string for a sandbox."""
    cmd = sb.get("command_mode", "")
    net = sb.get("network_mode", "")
    if cmd == "allowlist" and net == "none":
        return "Strict"
    if cmd == "allowlist" and net in ("restricted", "full"):
        return "Standard"
    if cmd == "denylist":
        return "Permissive"
    return cmd.capitalize() if cmd else "Custom"


def _enrich_sandbox(sb: dict, registry: SandboxRegistry) -> dict:
    """Add agent and security_level fields to a sandbox status dict."""
    agent = ""
    sandbox_obj = registry.get(sb["id"])
    if sandbox_obj:
        agent = sandbox_obj.profile.extra_env.get("LASSO_AGENT", "")
    sb["agent"] = agent
    sb["security_level"] = _security_level_label(sb)
    return sb


# ---------------------------------------------------------------------------
# Routes — HTML pages
# ---------------------------------------------------------------------------

@dashboard_bp.route("/")
@require_login
def index():
    """Dashboard home: sandbox list + system stats."""
    registry = _get_registry()
    sandboxes = registry.list_all()
    profiles = _get_all_profiles()

    # Enrich each sandbox with agent and security level
    sandboxes = [_enrich_sandbox(sb, registry) for sb in sandboxes]

    stats = {
        "total": len(sandboxes),
        "running": sum(1 for s in sandboxes if s["state"] == "running"),
        "stopped": sum(1 for s in sandboxes if s["state"] == "stopped"),
        "errors": sum(1 for s in sandboxes if s["state"] == "error"),
        "total_execs": sum(s.get("exec_count", 0) for s in sandboxes),
        "total_blocked": sum(s.get("blocked_count", 0) for s in sandboxes),
    }

    return render_template(
        "index.html",
        sandboxes=sandboxes,
        profiles=profiles,
        stats=stats,
        has_sandboxes=len(sandboxes) > 0,
        state_color=_state_color,
        version=__version__,
    )


@dashboard_bp.route("/sandbox/<sandbox_id>")
@require_login
def sandbox_detail(sandbox_id: str):
    """Sandbox detail page."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404, description=f"Sandbox '{sandbox_id}' not found.")

    status = sb.status()
    policy = sb.command_gate.explain_policy()

    # Read recent audit entries
    audit_entries = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        audit_entries = read_audit_log(sb.audit.log_file, tail=25)

    # Extract agent info from profile extra_env
    agent = sb.profile.extra_env.get("LASSO_AGENT", "")
    agent_command = AGENT_COMMANDS.get(agent, "")

    # Parse extra mounts for display
    extra_mounts = []
    extra_mounts_json = sb.profile.extra_env.get("LASSO_EXTRA_MOUNTS", "")
    if extra_mounts_json:
        try:
            extra_mounts = json.loads(extra_mounts_json)
        except (json.JSONDecodeError, TypeError):
            pass

    return render_template(
        "sandbox.html",
        sandbox=status,
        policy=policy,
        audit_entries=audit_entries,
        state_color=_state_color,
        version=__version__,
        agent=agent,
        agent_command=agent_command,
        extra_mounts=extra_mounts,
    )


@dashboard_bp.route("/sandbox/<sandbox_id>/exec", methods=["POST"])
@require_login
def sandbox_exec(sandbox_id: str):
    """Execute a command inside a sandbox. Returns HTMX partial."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404)

    command = request.form.get("command", "").strip()
    if not command:
        return render_template("partials/exec_result.html", error="No command provided.")
    if len(command) > 4096:
        return render_template("partials/exec_result.html", error="Command too long (max 4096 chars).")

    result = sb.exec(command)

    return render_template(
        "partials/exec_result.html",
        result={
            "command": result.command,
            "exit_code": result.exit_code,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "duration_ms": result.duration_ms,
            "blocked": result.blocked,
            "block_reason": result.block_reason if result.blocked else "",
        },
    )


def _validate_working_dir(working_dir: str) -> str | None:
    """Validate working directory path. Returns error message or None if valid."""
    if len(working_dir) > 4096:
        return "Path too long."

    try:
        path = Path(working_dir).resolve()
    except (OSError, ValueError):
        return "Invalid path."

    if not path.is_dir():
        return f"Directory does not exist: {working_dir}"

    # Block system directories
    _BLOCKED = {
        Path("/"), Path("/etc"), Path("/proc"), Path("/sys"),
        Path("/dev"), Path("/boot"), Path("/var/run"),
    }
    if platform.system() == "Windows":
        _BLOCKED.update({
            Path("C:\\"), Path("C:\\Windows"), Path("C:\\Windows\\System32"),
            Path("C:\\Program Files"), Path("C:\\Program Files (x86)"),
        })
    if path in _BLOCKED:
        return f"System directory not allowed: {working_dir}"

    # Must be under home or temp directory
    import tempfile
    home = Path(os.path.normcase(str(Path.home().resolve())))
    tmp = Path(os.path.normcase(str(Path(tempfile.gettempdir()).resolve())))
    path_norm = Path(os.path.normcase(str(path)))
    if not (path_norm.is_relative_to(home) or path_norm.is_relative_to(tmp)):
        return "Working directory must be under home or temp directory."

    return None


@dashboard_bp.route("/sandbox/create", methods=["POST"])
@require_login
def sandbox_create():
    """Create a new sandbox from a profile."""
    registry = _get_registry()

    profile_name = request.form.get("profile", "").strip()
    working_dir = request.form.get("working_dir", _default_sandbox_dir()).strip()
    agent = request.form.get("agent", "").strip() or None

    if not profile_name:
        return redirect(url_for("dashboard.index"))

    dir_error = _validate_working_dir(working_dir)
    if dir_error:
        abort(400, description=dir_error)

    # Resolve profile
    if profile_name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[profile_name](working_dir)
    else:
        try:
            profile = load_profile(profile_name)
        except FileNotFoundError:
            abort(400, description=f"Profile '{profile_name}' not found.")

    # Store agent choice so image_builder can install it
    if agent:
        profile.extra_env["LASSO_AGENT"] = agent

    # Parse extra mounts from form (JSON-encoded hidden input)
    mounts_json = request.form.get("mounts", "").strip()
    if mounts_json:
        try:
            extra_mounts = json.loads(mounts_json)
            # Validate structure: list of {source, target, mode}
            valid_mounts = []
            for m in extra_mounts:
                src = str(m.get("source", "")).strip()
                tgt = str(m.get("target", "")).strip()
                mode = str(m.get("mode", "rw")).strip()
                if src and tgt and mode in ("ro", "rw"):
                    # Security: reject path traversal, system dirs, docker socket
                    if ".." in src or ".." in tgt:
                        abort(400, description=f"Path traversal not allowed in mount: {src}")
                    if "docker.sock" in src:
                        abort(400, description="Docker socket mount is not allowed.")
                    # Validate against forbidden mount sources (same as converter.py)
                    from lasso.backends.converter import _validate_mount_source
                    try:
                        _validate_mount_source(src)
                    except ValueError as ve:
                        abort(400, description=str(ve))
                    valid_mounts.append({"source": src, "target": tgt, "mode": mode})
            if valid_mounts:
                profile.extra_env["LASSO_EXTRA_MOUNTS"] = json.dumps(valid_mounts)
        except (json.JSONDecodeError, TypeError, AttributeError):
            logging.getLogger("lasso.dashboard").warning("Malformed mounts JSON ignored")

    sb = registry.create(profile)
    try:
        registry.start(sb)
    except RuntimeError:
        pass  # Started in error state, visible in dashboard

    return redirect(url_for("dashboard.index"))


@dashboard_bp.route("/sandbox/<sandbox_id>/stop", methods=["POST"])
@require_login
def sandbox_stop(sandbox_id: str):
    """Stop a running sandbox."""
    registry = _get_registry()
    if not registry.stop(sandbox_id):
        abort(404)
    return redirect(url_for("dashboard.index"))


@dashboard_bp.route("/sandbox/<sandbox_id>/terminal", methods=["POST"])
@require_login
def open_terminal(sandbox_id: str):
    """Open a terminal window connected to this sandbox."""
    import re
    import shutil
    import subprocess

    # Validate sandbox_id to prevent command injection (especially AppleScript)
    if not re.match(r'^[a-f0-9]+$', sandbox_id):
        abort(400)

    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404)


    # Build the command to run in the terminal
    attach_cmd = f"lasso attach {sandbox_id}"

    try:
        if platform.system() == "Windows":
            # Open Windows Terminal or cmd.exe
            wt = shutil.which("wt")  # Windows Terminal
            if wt:
                subprocess.Popen([wt, "new-tab", "cmd", "/k", attach_cmd])
            else:
                subprocess.Popen(["cmd", "/c", "start", "cmd", "/k", attach_cmd])
        elif platform.system() == "Darwin":
            # macOS: open Terminal.app
            subprocess.Popen([
                "osascript", "-e",
                f'tell application "Terminal" to do script "{attach_cmd}"',
            ])
        else:
            # Linux: try common terminal emulators
            for term in ["gnome-terminal", "konsole", "xfce4-terminal", "xterm"]:
                term_path = shutil.which(term)
                if term_path:
                    if term == "gnome-terminal":
                        subprocess.Popen([term_path, "--", "bash", "-c", f"{attach_cmd}; exec bash"])
                    elif term == "konsole":
                        subprocess.Popen([term_path, "-e", "bash", "-c", f"{attach_cmd}; exec bash"])
                    else:
                        subprocess.Popen([term_path, "-e", f"{attach_cmd}"])
                    break
    except Exception:
        pass  # If terminal launch fails, user can still use the copy button

    return redirect(url_for("dashboard.sandbox_detail", sandbox_id=sandbox_id))


@dashboard_bp.route("/profiles")
@require_login
def profiles_list():
    """Profile listing page."""
    profiles = _get_all_profiles()
    return render_template(
        "profiles.html",
        profiles=profiles,
        version=__version__,
    )


@dashboard_bp.route("/profiles/<name>")
@require_login
def profile_detail(name: str):
    """Profile detail/editor page."""
    profile = None
    source = "unknown"

    if name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[name](_default_sandbox_dir())
        source = "builtin"
    else:
        try:
            profile = load_profile(name)
            source = "saved"
        except FileNotFoundError:
            abort(404, description=f"Profile '{name}' not found.")

    profile_data = profile.model_dump(mode="json")
    profile_json = json.dumps(profile_data, indent=2)

    return render_template(
        "profile_detail.html",
        profile=profile,
        profile_data=profile_data,
        profile_json=profile_json,
        source=source,
        version=__version__,
    )


def _parse_profile_form(form) -> dict:
    """Parse form data into kwargs suitable for building a SandboxProfile."""
    # Commands
    commands_list = form.getlist("commands")
    extra_cmds = form.get("extra_commands", "").strip()
    if extra_cmds:
        for cmd in extra_cmds.split(","):
            cmd = cmd.strip()
            if cmd and cmd not in commands_list:
                commands_list.append(cmd)

    cmd_mode_str = form.get("cmd_mode", "whitelist")
    if cmd_mode_str not in ("whitelist", "blacklist"):
        cmd_mode_str = "whitelist"
    cmd_mode = CommandMode.WHITELIST if cmd_mode_str == "whitelist" else CommandMode.BLACKLIST

    # Network
    net_mode_str = form.get("net_mode", "none")
    net_mode = NetworkMode(net_mode_str)
    allowed_domains_raw = form.get("allowed_domains", "")
    allowed_domains = [d.strip() for d in allowed_domains_raw.split(",") if d.strip()]
    try:
        blocked_ports = [int(p) for p in form.getlist("blocked_ports")]
    except (ValueError, TypeError):
        blocked_ports = []

    # Resources
    try:
        max_memory_mb = int(form.get("max_memory_mb", "4096"))
    except (ValueError, TypeError):
        max_memory_mb = 4096
    try:
        max_cpu_percent = int(form.get("max_cpu_percent", "50"))
    except (ValueError, TypeError):
        max_cpu_percent = 50
    try:
        max_pids = int(form.get("max_pids", "100"))
    except (ValueError, TypeError):
        max_pids = 100

    # Audit
    audit_enabled = "audit_enabled" in form
    audit_command_output = "audit_command_output" in form
    audit_file_diffs = "audit_file_diffs" in form

    # Shell operators
    allow_shell_operators = "allow_shell_operators" in form

    # Max execution seconds
    try:
        max_execution_seconds = int(form.get("max_execution_seconds", "300"))
    except (ValueError, TypeError):
        max_execution_seconds = 300

    return {
        "commands_list": commands_list,
        "cmd_mode": cmd_mode,
        "allow_shell_operators": allow_shell_operators,
        "max_execution_seconds": max_execution_seconds,
        "net_mode": net_mode,
        "allowed_domains": allowed_domains,
        "blocked_ports": blocked_ports,
        "max_memory_mb": max_memory_mb,
        "max_cpu_percent": max_cpu_percent,
        "max_pids": max_pids,
        "audit_enabled": audit_enabled,
        "audit_command_output": audit_command_output,
        "audit_file_diffs": audit_file_diffs,
    }


def _build_profile(name: str, description: str, parsed: dict, extends: str | None = None) -> SandboxProfile:
    """Build a SandboxProfile from parsed form data."""
    commands_kwargs: dict[str, Any] = {
        "mode": parsed["cmd_mode"],
        "allow_shell_operators": parsed["allow_shell_operators"],
        "max_execution_seconds": parsed["max_execution_seconds"],
    }
    if parsed["cmd_mode"] == CommandMode.WHITELIST:
        commands_kwargs["whitelist"] = parsed["commands_list"]
    else:
        commands_kwargs["blacklist"] = parsed["commands_list"]

    return SandboxProfile(
        name=name,
        description=description,
        extends=extends or None,
        filesystem=FilesystemConfig(working_dir=_default_sandbox_dir()),
        commands=CommandConfig(**commands_kwargs),
        network=NetworkConfig(
            mode=parsed["net_mode"],
            allowed_domains=parsed["allowed_domains"],
            blocked_ports=parsed["blocked_ports"],
        ),
        resources=ResourceConfig(
            max_memory_mb=parsed["max_memory_mb"],
            max_cpu_percent=parsed["max_cpu_percent"],
            max_pids=parsed["max_pids"],
        ),
        audit=AuditConfig(
            enabled=parsed["audit_enabled"],
            include_command_output=parsed["audit_command_output"],
            include_file_diffs=parsed["audit_file_diffs"],
            sign_entries=True,
        ),
    )


@dashboard_bp.route("/profiles/<name>/edit")
@require_login
def profile_edit(name: str):
    """Edit a profile via the dashboard form."""
    source = "unknown"
    if name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[name](_default_sandbox_dir())
        source = "builtin"
    else:
        try:
            profile = load_profile(name)
            source = "saved"
        except FileNotFoundError:
            abort(404, description=f"Profile '{name}' not found.")

    profile_data = profile.model_dump(mode="json")

    # Figure out which commands from the checkbox grid are NOT in the
    # whitelist so the template can compute "extra_commands"
    grid_cmds = {
        "ls", "cat", "head", "tail", "grep", "find", "wc", "sort", "diff",
        "echo", "test", "python3", "pip", "git", "node", "npm", "make",
        "cargo", "go", "curl", "wget", "mkdir", "cp", "mv", "touch",
        "tar", "zip", "unzip",
    }
    wl = set(profile_data["commands"].get("whitelist", []))
    extra_cmds = sorted(wl - grid_cmds)
    extra_commands_str = ", ".join(extra_cmds)

    return render_template(
        "profile_edit.html",
        profile=profile,
        profile_data=profile_data,
        source=source,
        extra_commands_str=extra_commands_str,
        version=__version__,
    )


@dashboard_bp.route("/profiles/<name>/edit", methods=["POST"])
@require_login
def profile_save(name: str):
    """Save profile changes from the dashboard form."""
    # For builtins, reject direct save (must duplicate)
    if name in BUILTIN_PROFILES:
        abort(400, description="Built-in profiles cannot be modified. Duplicate them first.")

    try:
        parsed = _parse_profile_form(request.form)
        description = request.form.get("description", "").strip()
        extends = request.form.get("extends", "").strip() or None
        profile = _build_profile(name, description, parsed, extends)
        save_profile(profile)
    except (ValueError, TypeError) as e:
        # Reload and show error
        try:
            orig = load_profile(name)
        except FileNotFoundError:
            orig = SandboxProfile(
                name=name,
                filesystem=FilesystemConfig(working_dir=_default_sandbox_dir()),
            )
        return render_template(
            "profile_edit.html",
            profile=orig,
            profile_data=orig.model_dump(mode="json"),
            source="saved",
            extra_commands_str="",
            error=str(e),
            version=__version__,
        )

    return redirect(url_for("dashboard.profile_detail", name=name))


@dashboard_bp.route("/profiles/new")
@require_login
def profile_new():
    """New profile wizard page."""
    return render_template(
        "profile_new.html",
        version=__version__,
    )


@dashboard_bp.route("/profiles/new", methods=["POST"])
@require_login
def profile_create():
    """Create a new profile from the wizard form."""
    name = request.form.get("name", "").strip()
    if not name:
        return render_template(
            "profile_new.html",
            error="Profile name is required.",
            version=__version__,
        )

    # Check if profile already exists
    if name in BUILTIN_PROFILES:
        return render_template(
            "profile_new.html",
            error=f"'{name}' is a built-in profile name. Choose a different name.",
            version=__version__,
        )

    from lasso.config.profile import profile_path
    if profile_path(name).exists():
        return render_template(
            "profile_new.html",
            error=f"A profile named '{name}' already exists.",
            version=__version__,
        )

    try:
        parsed = _parse_profile_form(request.form)
        description = request.form.get("description", "").strip()
        base = request.form.get("base_profile", "").strip() or None
        profile = _build_profile(name, description, parsed, base)
        save_profile(profile)
    except (ValueError, TypeError) as e:
        return render_template(
            "profile_new.html",
            error=str(e),
            version=__version__,
        )

    return redirect(url_for("dashboard.profile_detail", name=name))


@dashboard_bp.route("/audit/<sandbox_id>")
@require_login
def audit_log(sandbox_id: str):
    """Audit log viewer with filters."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        abort(404, description=f"Sandbox '{sandbox_id}' not found.")

    status = sb.status()
    event_type = request.args.get("type", "")
    try:
        page = max(1, int(request.args.get("page", 1)))
    except (ValueError, TypeError):
        page = 1
    try:
        per_page = max(1, min(500, int(request.args.get("per_page", 50))))
    except (ValueError, TypeError):
        per_page = 50

    all_entries: list[dict] = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        all_entries = read_audit_log(
            sb.audit.log_file,
            tail=0,  # get all
            event_type=event_type or None,
        )

    # Pagination
    total = len(all_entries)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    entries = all_entries[start : start + per_page]

    # Collect unique event types for filter dropdown
    event_types = sorted(set(e.get("type", "") for e in all_entries if e.get("type")))

    return render_template(
        "audit.html",
        sandbox=status,
        entries=entries,
        event_types=event_types,
        current_type=event_type,
        page=page,
        total_pages=total_pages,
        total=total,
        per_page=per_page,
        version=__version__,
    )


@dashboard_bp.route("/check")
@require_login
def system_check():
    """System capability check page."""
    caps = _system_capabilities()
    return render_template(
        "check.html",
        capabilities=caps,
        version=__version__,
    )


# ---------------------------------------------------------------------------
# Routes — HTMX partials
# ---------------------------------------------------------------------------

@dashboard_bp.route("/partials/sandbox-table")
@require_login
def partial_sandbox_table():
    """HTMX partial: refreshable sandbox table body."""
    registry = _get_registry()
    sandboxes = registry.list_all()
    sandboxes = [_enrich_sandbox(sb, registry) for sb in sandboxes]
    stats = {
        "total": len(sandboxes),
        "running": sum(1 for s in sandboxes if s["state"] == "running"),
        "stopped": sum(1 for s in sandboxes if s["state"] == "stopped"),
        "errors": sum(1 for s in sandboxes if s["state"] == "error"),
        "total_execs": sum(s.get("exec_count", 0) for s in sandboxes),
        "total_blocked": sum(s.get("blocked_count", 0) for s in sandboxes),
    }
    return render_template(
        "partials/sandbox_table.html",
        sandboxes=sandboxes,
        stats=stats,
        state_color=_state_color,
    )


@dashboard_bp.route("/partials/sandbox-cards")
@require_login
def partial_sandbox_cards():
    """HTMX partial: refreshable sandbox card grid."""
    registry = _get_registry()
    sandboxes = registry.list_all()
    sandboxes = [_enrich_sandbox(sb, registry) for sb in sandboxes]
    return render_template(
        "partials/sandbox_cards.html",
        sandboxes=sandboxes,
        state_color=_state_color,
    )


@dashboard_bp.route("/partials/audit-feed/<sandbox_id>")
@require_login
def partial_audit_feed(sandbox_id: str):
    """HTMX partial: live audit feed for a sandbox."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return "<tr><td colspan='5'>Sandbox not found.</td></tr>"

    entries = []
    if sb.audit.log_file and sb.audit.log_file.exists():
        entries = read_audit_log(sb.audit.log_file, tail=15)

    return render_template("partials/audit_feed.html", entries=entries)


@dashboard_bp.route("/partials/sandbox-status/<sandbox_id>")
@require_login
def partial_sandbox_status(sandbox_id: str):
    """HTMX partial: sandbox status badge and counters."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return "<span>Not found</span>"
    status = sb.status()
    return render_template(
        "partials/sandbox_status.html",
        sandbox=status,
        state_color=_state_color,
    )


# ---------------------------------------------------------------------------
# Routes — JSON API
# ---------------------------------------------------------------------------

@dashboard_bp.route("/api/sandboxes")
@require_login
def api_sandboxes():
    """JSON API: list all sandboxes."""
    registry = _get_registry()
    return jsonify(registry.list_all())


@dashboard_bp.route("/browse-dirs")
@require_login
def browse_dirs():
    """Return directory listing for the folder browser."""
    import string as _string

    # Return bookmarks (quick-access locations)
    if request.args.get("bookmarks"):
        home = Path.home()
        bookmarks = []
        # Standard user directories
        _BOOKMARK_DIRS = [
            ("Home", str(home), "🏠"),
            ("Desktop", str(home / "Desktop"), "🖥️"),
            ("Documents", str(home / "Documents"), "📄"),
            ("Downloads", str(home / "Downloads"), "📥"),
            ("Projects", str(home / "Projects"), "💻"),
        ]
        # On Windows, add drive letters
        if platform.system() == "Windows":
            for letter in "CDEF":
                drive = f"{letter}:\\"
                if Path(drive).exists():
                    _BOOKMARK_DIRS.append((f"Drive {letter}:", drive, "💾"))

        for name, path_str, icon in _BOOKMARK_DIRS:
            if Path(path_str).is_dir():
                bookmarks.append({"name": name, "path": path_str, "icon": icon})
        return jsonify({"bookmarks": bookmarks})

    path = request.args.get("path", "")

    # Default: show home directory (or drive list on Windows)
    if not path:
        if platform.system() == "Windows":
            drives = []
            for letter in _string.ascii_uppercase:
                drive = f"{letter}:\\"
                if Path(drive).exists():
                    drives.append({"name": f"{letter}:", "path": drive, "type": "drive"})
            return jsonify({"path": "", "parent": "", "entries": drives})
        else:
            path = str(Path.home())

    resolved = str(Path(path).resolve())
    path = os.path.normpath(resolved)

    # Security: block system directories — check the resolved path so
    # symlinks cannot be used to bypass the block list.
    blocked = {"/proc", "/sys", "/dev", "/boot"}
    if platform.system() == "Windows":
        blocked.update({"C:\\Windows", "C:\\Program Files", "C:\\$Recycle.Bin"})
    for b in blocked:
        if path.lower().startswith(b.lower()):
            return jsonify({"error": "System directory not accessible"}), 403

    try:
        entries = []
        for item in sorted(Path(path).iterdir()):
            if not item.is_dir():
                continue
            name = item.name
            # Hide hidden dirs: dotfiles on Unix, $-prefixed on Windows
            if name.startswith('.') or name.startswith('$'):
                continue
            entries.append({
                "name": name,
                "path": str(item),
                "type": "dir",
            })

        parent = os.path.normpath(str(Path(path).parent))
        if parent == path:  # root
            if platform.system() == "Windows":
                parent = ""  # go back to drive list
            else:
                parent = ""

        return jsonify({
            "path": path,
            "parent": parent,
            "entries": entries,
        })
    except PermissionError:
        return jsonify({"error": "Permission denied"}), 403
    except OSError as e:
        return jsonify({"error": str(e)}), 400


@dashboard_bp.route("/api/sandbox/<sandbox_id>/status")
@require_login
def api_sandbox_status(sandbox_id: str):
    """JSON API: sandbox status."""
    registry = _get_registry()
    sb = registry.get(sandbox_id)
    if not sb:
        return jsonify({"error": "not found"}), 404
    return jsonify(sb.status())


# ---------------------------------------------------------------------------
# Template filters
# ---------------------------------------------------------------------------

def _register_filters(app: Flask) -> None:
    """Register custom Jinja2 template filters."""

    @app.template_filter("timeago")
    def timeago_filter(iso_str: str) -> str:
        """Format an ISO timestamp as a relative time string."""
        try:
            dt = datetime.fromisoformat(iso_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)
            delta = now - dt
            seconds = int(delta.total_seconds())
            if seconds < 60:
                return f"{seconds}s ago"
            if seconds < 3600:
                return f"{seconds // 60}m ago"
            if seconds < 86400:
                return f"{seconds // 3600}h ago"
            return f"{seconds // 86400}d ago"
        except (ValueError, TypeError):
            return str(iso_str)

    @app.template_filter("truncate_id")
    def truncate_id_filter(value: str, length: int = 8) -> str:
        return value[:length] if value else ""

    @app.template_filter("tojson_pretty")
    def tojson_pretty_filter(value: Any) -> str:
        return json.dumps(value, indent=2, default=str)


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app(
    registry: SandboxRegistry | None = None,
    backend: Any | None = None,
) -> Flask:
    """Create and configure the LASSO dashboard Flask application.

    Args:
        registry: A SandboxRegistry instance for managing sandboxes.
                  A new empty registry is created if None.
        backend:  A ContainerBackend instance (Docker, Podman, etc.).
                  Native subprocess mode is used if None.

    Returns:
        A configured Flask application.

    Example:
        app = create_app()
        app.run(host="127.0.0.1", port=5000, debug=True)
    """
    app = Flask(
        __name__,
        template_folder=str(Path(__file__).parent / "templates"),
    )

    app.config["REGISTRY"] = registry or SandboxRegistry(backend=backend)
    app.config["BACKEND"] = backend
    app.config["SECRET_KEY"] = os.environ.get("LASSO_SECRET_KEY", secrets.token_hex(32))

    app.register_blueprint(dashboard_bp)

    # Dashboard authentication + CSRF
    init_dashboard_auth(app)

    _register_filters(app)

    # Session cookie hardening
    app.config["SESSION_COOKIE_SECURE"] = not app.debug
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["PERMANENT_SESSION_LIFETIME"] = 3600

    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"

        # CORS — no cross-origin access (omit Access-Control-Allow-Origin
        # entirely; Flask's default is to not set CORS headers, which
        # causes browsers to block all cross-origin requests).
        # Do NOT set Access-Control-Allow-Origin to "null" — that value
        # is exploitable via sandboxed iframes and data: URIs.

        # Content Security Policy
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
            "img-src 'self' data:; "
            "connect-src 'self'; "
            "frame-ancestors 'none'; "
            "base-uri 'self'; "
            "form-action 'self'"
        )

        return response

    # Register atexit handler to gracefully shut down registry when Flask stops
    reg = app.config["REGISTRY"]
    atexit.register(reg.shutdown)

    return app


# ---------------------------------------------------------------------------
# Standalone runner
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Auto-detect container backend for standalone mode so that
    # existing sandboxes can be reconnected from the state store.
    _backend = None
    try:
        from lasso.backends.detect import detect_backend
        _backend = detect_backend()
        if _backend:
            info = _backend.get_info()
            print(f"Backend: {info.get('runtime', 'container')} {info.get('version', '')}")
    except Exception:
        pass
    app = create_app(backend=_backend)
    print("LASSO Dashboard starting on http://127.0.0.1:5000")
    print("Note: pip install flask  (if not already installed)")
    app.run(host="127.0.0.1", port=5000, debug=os.environ.get("FLASK_DEBUG", "0") == "1")
