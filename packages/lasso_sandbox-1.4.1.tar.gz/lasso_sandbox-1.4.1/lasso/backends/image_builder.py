"""Build custom container images per sandbox profile.

Generates Dockerfiles that install only the whitelisted tools,
creating minimal attack-surface images.
"""

from __future__ import annotations

import logging

from lasso.backends.base import ContainerBackend
from lasso.config.schema import CommandMode, SandboxProfile

logger = logging.getLogger("lasso.image_builder")

# Stable preset image names — these use fixed tags so they can be
# pre-built once and reused instantly across all sandbox creations.
PRESET_IMAGES: dict[str, str] = {
    "base": "lasso-preset:base",
    "claude-code": "lasso-preset:claude-code",
    "opencode": "lasso-preset:opencode",
}

# Agent CLI install instructions for Docker images.
# Each entry is a list of RUN commands added to the Dockerfile.
AGENT_INSTALLS: dict[str, list[str]] = {
    "claude-code": [
        "curl -fsSL https://deb.nodesource.com/setup_22.x | bash -",
        "apt-get install -y nodejs",
        "npm install -g @anthropic-ai/claude-code",
    ],
    "opencode": [
        "curl -fsSL https://opencode.ai/install | bash",
    ],
}

# Default pinned base image — digest ensures reproducible builds
DEFAULT_BASE_IMAGE = (
    "python:3.12-slim@sha256:"
    "3d5ed973e45820f5ba5e46bd065bd88b3a504ff0724d85980dcd05eab361fcf4"
)

# Map command names to apt packages
TOOL_TO_PACKAGE: dict[str, str] = {
    "python3": "python3",
    "python": "python3",
    "pip": "python3-pip",
    "pip3": "python3-pip",
    "git": "git",
    "curl": "curl",
    "wget": "wget",
    "node": "nodejs",
    "npm": "nodejs npm",
    "npx": "nodejs npm",
    "Rscript": "r-base",
    "R": "r-base",
    "make": "make",
    "cmake": "cmake",
    "gcc": "gcc",
    "g++": "g++",
    "rustc": "rustc",
    "cargo": "cargo",
    "tar": "tar",
    "gzip": "gzip",
    "gunzip": "gzip",
    "zip": "zip",
    "unzip": "unzip",
    "jq": "jq",
    "ssh": "openssh-client",
    "scp": "openssh-client",
    "rsync": "rsync",
    "sqlite3": "sqlite3",
    "iptables": "iptables",
}

# These are always available in the base image (coreutils/busybox)
BUILTIN_COMMANDS = {
    "ls", "cat", "head", "tail", "grep", "find", "wc", "sort", "uniq",
    "diff", "mkdir", "cp", "mv", "touch", "echo", "printf", "test",
    "env", "basename", "dirname", "pwd", "sleep", "true", "false",
    "sh", "bash", "date", "tee", "xargs", "tr", "cut", "sed", "awk",
}


def generate_dockerfile(profile: SandboxProfile, base_image: str | None = None, agent: str | None = None) -> str:
    """Generate a Dockerfile that installs only the whitelisted tools.

    Args:
        profile: The sandbox profile defining which tools to install.
        base_image: Optional base Docker image. Defaults to DEFAULT_BASE_IMAGE
                    (python:3.12-slim pinned to a specific digest).
        agent: Optional AI agent CLI to pre-install (e.g. "claude-code", "aider").
    """
    base = base_image or DEFAULT_BASE_IMAGE
    packages = set()

    if profile.commands.mode == CommandMode.WHITELIST:
        for cmd in profile.commands.whitelist:
            if cmd in BUILTIN_COMMANDS:
                continue
            if cmd in TOOL_TO_PACKAGE:
                for pkg in TOOL_TO_PACKAGE[cmd].split():
                    packages.add(pkg)

    # Always include iptables when the profile requires network policy rules.
    # Without iptables the container cannot enforce firewall restrictions and
    # _apply_network_policy() will fail at startup.
    from lasso.backends.converter import needs_network_rules
    if needs_network_rules(profile):
        packages.add("iptables")

    packages_str = " ".join(sorted(packages)) if packages else ""

    lines = [
        f"FROM {base}",
        "",
        "LABEL managed-by=lasso",
        f"LABEL lasso-profile={profile.name}",
        "",
        "RUN apt-get update \\",
    ]

    if packages_str:
        lines.append(f"    && apt-get install -y --no-install-recommends {packages_str} \\")

    lines.extend([
        "    && apt-get clean \\",
        "    && rm -rf /var/lib/apt/lists/*",
        "",
    ])

    # Insert AI agent install commands (needs root, before USER sandbox)
    if agent and agent in AGENT_INSTALLS:
        install_cmds = list(AGENT_INSTALLS[agent])
        # Deduplicate: if Node.js is already installed via apt packages, skip
        # the nodesource setup line (packages already provide nodejs).
        has_nodejs_pkg = "nodejs" in packages if packages else False
        if has_nodejs_pkg:
            install_cmds = [
                cmd for cmd in install_cmds
                if "nodesource" not in cmd and cmd != "apt-get install -y nodejs"
            ]

        if install_cmds:
            lines.append(f"# Install AI agent: {agent}")
            lines.append("RUN " + " \\\n    && ".join(install_cmds))
            lines.append("")

    lines.extend([
        "RUN useradd -m -u 1000 -s /bin/bash sandbox",
        "",
        "WORKDIR /workspace",
        "USER sandbox",
        "",
        'CMD ["sleep", "infinity"]',
    ])

    return "\n".join(lines) + "\n"


def image_tag(profile: SandboxProfile, agent: str | None = None) -> str:
    """Return the image tag for a profile + agent combination.

    Uses stable preset names when possible (instant startup), falls back
    to hash-based tags for custom profiles.
    """
    # Use stable preset if the agent matches a known preset
    if agent and agent in PRESET_IMAGES:
        return PRESET_IMAGES[agent]
    # Base preset for standard profiles without an agent
    if not agent:
        return PRESET_IMAGES["base"]
    # Fallback: hash-based tag for custom combinations
    tag_input = profile.config_hash()[:12]
    if agent:
        tag_input += f"-{agent}"
    return f"lasso-{tag_input}"


def ensure_image(
    backend: ContainerBackend,
    profile: SandboxProfile,
    force_rebuild: bool = False,
    base_image: str | None = None,
    agent: str | None = None,
) -> str:
    """Ensure a sandbox image exists for this profile. Build if needed.

    Args:
        backend: The container backend to use for building/checking images.
        profile: The sandbox profile to build an image for.
        force_rebuild: If True, rebuild even if the image already exists.
        base_image: Optional base Docker image override. Defaults to
                    DEFAULT_BASE_IMAGE (pinned to digest).
        agent: Optional AI agent CLI to pre-install in the image.

    Returns the image tag.
    """
    tag = image_tag(profile, agent=agent)

    if not force_rebuild and backend.image_exists(tag):
        logger.debug("Image %s already exists", tag)
        return tag

    logger.info("Building sandbox image %s for profile '%s'", tag, profile.name)
    dockerfile = generate_dockerfile(profile, base_image=base_image, agent=agent)
    backend.build_image(dockerfile, tag)
    logger.info("Image %s built successfully", tag)
    return tag


def prebuild_presets(
    backend: ContainerBackend,
    force: bool = False,
) -> dict[str, str]:
    """Pre-build all preset images so sandbox creation is instant.

    Builds: base (no agent), claude-code, opencode.
    Returns a dict of {preset_name: image_tag}.
    """
    from lasso.config.defaults import standard_profile

    results: dict[str, str] = {}

    # Use the daily profile as the base for all presets
    profile = standard_profile("/workspace")

    # Build base image (no agent)
    tag = PRESET_IMAGES["base"]
    if force or not backend.image_exists(tag):
        logger.info("Building preset: base")
        dockerfile = generate_dockerfile(profile)
        backend.build_image(dockerfile, tag)
        logger.info("Preset base built: %s", tag)
    results["base"] = tag

    # Build agent images
    for agent_name in AGENT_INSTALLS:
        tag = PRESET_IMAGES.get(agent_name, f"lasso-preset:{agent_name}")
        if force or not backend.image_exists(tag):
            logger.info("Building preset: %s", agent_name)
            dockerfile = generate_dockerfile(profile, agent=agent_name)
            backend.build_image(dockerfile, tag)
            logger.info("Preset %s built: %s", agent_name, tag)
        else:
            logger.info("Preset %s already cached: %s", agent_name, tag)
        results[agent_name] = tag

    return results
