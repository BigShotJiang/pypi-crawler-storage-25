import pytest
from unittest.mock import patch
from xtlsapi import XrayClient
from xtlsapi.xray_api.app.router.command import command_pb2


def test_stats_online_ip_list():
    xray = XrayClient("127.0.0.1", 53357)
    with patch.object(xray, 'block_ips', return_value=command_pb2.AddRuleResponse()):
        xray.block_ips(
            ips=["103.23.202.74"],
            inbound_tag="vless-in"
        )
        assert xray
