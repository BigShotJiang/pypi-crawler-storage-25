from .stats import StatsAPIService
from .handler import HandlerAPIService
from .logger import LoggerAPIService
from .router import RouterAPIService


class APIService(StatsAPIService, HandlerAPIService, LoggerAPIService, RouterAPIService):
    pass
