import grpc

from xtlsapi.api_services._base import BaseService
from xtlsapi.xray_api.app.router import config_pb2
from xtlsapi.xray_api.app.router.command import command_pb2

from xtlsapi.ext.utils import to_typed_message, ip2bytes


class RouterBlockIps(BaseService):
    """Блокировка IP через Xray API"""

    def block_ips(
        self,
        ips: list[str],
        inbound_tag: str,
        rule_tag: str = "sourceIpBlock",
        outbound_tag: str = "blocked",
    ):
        try:
            # 1️⃣ Удаляем старое правило
            self.routing_stub.RemoveRule(
                command_pb2.RemoveRuleRequest(ruleTag=rule_tag)
            )

            if not ips:
                return None

            # 2️⃣ Конвертация IP → GeoIP (только IPv4)
            geoip_list = []
            for ip in ips:
                geoip = config_pb2.GeoIP(
                    country_code="",
                    cidr=[
                        config_pb2.CIDR(
                            ip=ip2bytes(ip),  # <-- используем util
                            prefix=32         # IPv4
                        )
                    ],
                    reverse_match=False
                )
                geoip_list.append(geoip)

            # 3️⃣ RoutingRule
            rule = config_pb2.RoutingRule(
                rule_tag=rule_tag,
                inbound_tag=[inbound_tag] if inbound_tag else [],
                tag=outbound_tag,
                source_geoip=geoip_list
            )

            # 4️⃣ Config
            config = config_pb2.Config(
                rule=[rule]
            )

            # 5️⃣ TypedMessage через util (ключевой момент)
            typed_msg = to_typed_message(config)

            # DEBUG (если нужно)
            # print("TYPE:", config.DESCRIPTOR.full_name)
            # print("BYTES LEN:", len(config.SerializeToString()))

            # 6️⃣ gRPC вызов
            return self.routing_stub.AddRule(
                command_pb2.AddRuleRequest(
                    config=typed_msg,
                    shouldAppend=True,
                )
            )

        except grpc.RpcError as e:
            print("gRPC error:", e.details())
            print("debug:", e.debug_error_string)
            raise e