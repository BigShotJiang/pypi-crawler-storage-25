from .block_ips import RouterBlockIps


class RouterAPIService(
    RouterBlockIps,
):
    pass