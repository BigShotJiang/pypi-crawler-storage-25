"""
OpenAI provider for NucleusIQ.

This module provides the OpenAI LLM client that supports both async and sync
modes.  The mode is determined by the ``async_mode`` parameter at init time.

**API Backend Routing (transparent to callers)**

``call()`` automatically selects the right OpenAI API:

* **Chat Completions API** — used when all tools are custom function-calling
  tools (or when there are no tools at all).
* **Responses API** — used when *any* tool is a native OpenAI tool
  (web_search, code_interpreter, file_search, image_generation, mcp,
  computer_use).  The Responses API also supports function-calling, so
  mixed tool lists work seamlessly.

Callers (Agents) never need to choose — the routing is fully internal.

Structured Output Support::

    response = await llm.call(
        model="gpt-4o",
        messages=[...],
        response_format=MyPydanticModel,  # Returns validated MyPydanticModel instance
    )
"""

from __future__ import annotations

import base64
import logging
import os
from collections.abc import AsyncGenerator
from typing import Any

import openai
from nucleusiq.agents.attachments import (
    MAX_FILE_SIZE_BYTES,
    Attachment,
    AttachmentProcessor,
    AttachmentType,
)
from nucleusiq.llms.base_llm import BaseLLM
from nucleusiq.streaming.events import StreamEvent
from pydantic import BaseModel

from nucleusiq_openai._shared.model_config import (
    is_strict_defaults_model,
    uses_max_completion_tokens,
)
from nucleusiq_openai._shared.models import ChatCompletionsPayload
from nucleusiq_openai._shared.response_models import (
    AssistantMessage,
    _LLMResponse,
)
from nucleusiq_openai.nb_openai.chat_completions import call_chat_completions
from nucleusiq_openai.nb_openai.responses_api import (
    call_responses_api,
    responses_call_direct,
)
from nucleusiq_openai.nb_openai.stream_adapters import (
    stream_chat_completions,
    stream_responses_api,
)
from nucleusiq_openai.structured_output import build_response_format, parse_response
from nucleusiq_openai.tools.openai_tool import NATIVE_TOOL_TYPES

logger = logging.getLogger(__name__)

__all__ = ["BaseOpenAI"]


class BaseOpenAI(BaseLLM):
    """
    OpenAI client for ChatCompletion **and** Responses API.

    Supports both async and sync modes based on ``async_mode`` parameter
    (default True).

    **Open/Closed Principle** — the public ``call()`` interface is stable;
    new API backends are added as separate modules without modifying the
    contract.

    **Adaptive** — tool type registries and version constants are configurable
    so API changes are absorbed in one place.
    """

    NATIVE_TOOL_TYPES: frozenset = NATIVE_TOOL_TYPES

    NATIVE_ATTACHMENT_TYPES: frozenset = frozenset(
        {
            AttachmentType.PDF,
            AttachmentType.FILE_BASE64,
            AttachmentType.FILE_URL,
            AttachmentType.TEXT,
            AttachmentType.FILE_BYTES,
        }
    )
    """Attachment types that OpenAI processes server-side with full fidelity.

    ``IMAGE_URL`` and ``IMAGE_BASE64`` are handled via the standard
    ``image_url`` wire format (not file input) and are therefore not
    listed here — they work identically across all providers.
    """

    SUPPORTED_FILE_EXTENSIONS: frozenset[str] = frozenset(
        {
            ".pdf",
            ".txt",
            ".md",
            ".json",
            ".html",
            ".htm",
            ".xml",
            ".css",
            ".js",
            ".mjs",
            ".py",
            ".sql",
            ".csv",
            ".tsv",
            ".xlsx",
            ".xls",
            ".doc",
            ".docx",
            ".ppt",
            ".pptx",
            ".rtf",
            ".odt",
            ".rst",
            ".log",
            ".c",
            ".cpp",
            ".h",
            ".java",
            ".rb",
            ".pl",
            ".sh",
            ".bat",
        }
    )

    _EXT_TO_MIME: dict[str, str] = {
        ".pdf": "application/pdf",
        ".txt": "text/plain",
        ".md": "text/markdown",
        ".json": "application/json",
        ".html": "text/html",
        ".htm": "text/html",
        ".xml": "text/xml",
        ".css": "text/css",
        ".js": "application/javascript",
        ".mjs": "application/javascript",
        ".py": "text/x-python",
        ".sql": "application/x-sql",
        ".csv": "text/csv",
        ".tsv": "text/tsv",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".xls": "application/vnd.ms-excel",
        ".doc": "application/msword",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".ppt": "application/vnd.ms-powerpoint",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".rtf": "application/rtf",
        ".odt": "application/vnd.oasis.opendocument.text",
    }

    # ================================================================== #
    # Tool spec conversion                                                #
    # ================================================================== #

    def _convert_tool_spec(self, spec: dict[str, Any]) -> dict[str, Any]:
        """
        Convert generic BaseTool spec to OpenAI format.

        * If spec already has a ``"type"`` key (native tool from
          ``OpenAITool``), it is returned **as-is** (pass-through).
        * Otherwise it is wrapped in the
          ``{"type": "function", "function": {...}}`` envelope that both
          the Chat Completions and Responses APIs accept.
        """
        if "type" in spec:
            return spec

        parameters = spec.get("parameters", {})
        if "additionalProperties" not in parameters:
            parameters = {**parameters, "additionalProperties": False}

        return {
            "type": "function",
            "function": {
                "name": spec["name"],
                "description": spec["description"],
                "parameters": parameters,
            },
        }

    # ================================================================== #
    # Attachment processing (OpenAI-native file input)                    #
    # ================================================================== #

    _HANDLED_ATTACHMENT_TYPES: frozenset[AttachmentType] = frozenset(AttachmentType)
    """Every ``AttachmentType`` member must be explicitly handled in
    ``_process_attachment_openai``.  The import-time assertion at module
    level verifies this set equals ``set(AttachmentType)``."""

    def process_attachments(
        self,
        attachments: list,
    ) -> list[dict[str, Any]]:
        """Convert attachments to OpenAI-native file-input content parts.

        For file types that OpenAI can process server-side (PDF, DOCX,
        XLSX, CSV, code files, etc.), the raw file data is sent as a
        Chat Completions ``file`` content part.  The Responses API
        normalizer converts these to ``input_file`` parts automatically.

        For ``FILE_URL`` attachments, an ``input_file`` part with
        ``file_url`` is produced (Responses API only; Chat Completions
        will receive a text fallback).

        Images fall back to the framework's standard ``image_url`` format.
        """
        parts: list[dict[str, Any]] = []
        for att in attachments:
            AttachmentProcessor.validate_size(att, limit=MAX_FILE_SIZE_BYTES)
            parts.extend(self._process_attachment_openai(att))
        return parts

    def _process_attachment_openai(
        self,
        att: Attachment,
    ) -> list[dict[str, Any]]:
        """Route a single attachment to the appropriate OpenAI format.

        Raises ``ValueError`` for unrecognised types instead of silently
        falling back — this forces explicit handling of every
        ``AttachmentType`` and prevents silent degradation.
        """
        if att.type == AttachmentType.FILE_URL:
            return self._att_file_url(att)

        if att.type == AttachmentType.PDF:
            return self._att_native_file(att, fallback_mime="application/pdf")

        if att.type == AttachmentType.FILE_BASE64:
            return self._att_base64_file(att)

        if att.type == AttachmentType.FILE_BYTES:
            if self._is_supported_extension(att.name):
                return self._att_native_file(att)
            return self._framework_fallback([att])

        if att.type == AttachmentType.TEXT:
            if self._is_supported_extension(att.name):
                return self._att_native_file(att, fallback_mime="text/plain")
            return self._framework_fallback([att])

        if att.type in (AttachmentType.IMAGE_URL, AttachmentType.IMAGE_BASE64):
            return self._framework_fallback([att])

        raise ValueError(
            f"Unhandled attachment type '{att.type}' in OpenAI provider. "
            f"Add routing for this type in _process_attachment_openai()."
        )

    # -- OpenAI-native helpers ----------------------------------------- #

    def _att_native_file(
        self,
        att: Attachment,
        *,
        fallback_mime: str | None = None,
    ) -> list[dict[str, Any]]:
        """Produce a Chat Completions ``file`` content part with base64 data."""
        if isinstance(att.data, bytes):
            raw = att.data
        else:
            raw = att.data.encode("utf-8")

        b64 = base64.b64encode(raw).decode()
        mime = (
            att.mime_type
            or self._guess_mime(att.name)
            or fallback_mime
            or "application/octet-stream"
        )
        filename = att.name or "attachment"

        return [
            {
                "type": "file",
                "file": {
                    "filename": filename,
                    "file_data": f"data:{mime};base64,{b64}",
                },
            }
        ]

    def _att_base64_file(self, att: Attachment) -> list[dict[str, Any]]:
        """Pass pre-encoded base64 data directly — no double-encoding."""
        b64_str = att.data if isinstance(att.data, str) else att.data.decode()
        mime = att.mime_type or self._guess_mime(att.name) or "application/octet-stream"
        filename = att.name or "attachment"
        return [
            {
                "type": "file",
                "file": {
                    "filename": filename,
                    "file_data": f"data:{mime};base64,{b64_str}",
                },
            }
        ]

    def _att_file_url(self, att: Attachment) -> list[dict[str, Any]]:
        """Produce a Responses API ``input_file`` part with ``file_url``.

        Chat Completions does not support file URLs — the Responses API
        normalizer will pass this through, and the Chat Completions path
        strips unsupported ``input_file`` parts with a logged warning.
        """
        url = att.data if isinstance(att.data, str) else att.data.decode()
        return [{"type": "input_file", "file_url": url}]

    def _framework_fallback(
        self,
        attachments: list,
    ) -> list[dict[str, Any]]:
        """Delegate to the framework's default attachment processing."""
        return super().process_attachments(attachments)

    def _is_supported_extension(self, name: str | None) -> bool:
        if not name:
            return False
        dot = name.rfind(".")
        if dot < 0:
            return False
        return name[dot:].lower() in self.SUPPORTED_FILE_EXTENSIONS

    def _guess_mime(self, name: str | None) -> str | None:
        if not name:
            return None
        dot = name.rfind(".")
        if dot < 0:
            return None
        return self._EXT_TO_MIME.get(name[dot:].lower())

    # ================================================================== #
    # Attachment capability introspection                                  #
    # ================================================================== #

    def describe_attachment_support(self) -> dict[str, Any]:
        """Return OpenAI-specific attachment handling summary.

        Overrides ``BaseLLM.describe_attachment_support()`` to provide
        details about native server-side processing, conditional
        extension-based routing, and the standard image format.
        """
        type_details: dict[str, str] = {
            AttachmentType.PDF.value: (
                "native: sent as OpenAI 'file' content part; "
                "server extracts text AND images"
            ),
            AttachmentType.FILE_BASE64.value: (
                "native: base64 passed directly in 'file' content part "
                "(no double-encoding)"
            ),
            AttachmentType.FILE_URL.value: (
                "native: sent as 'input_file' with file_url; "
                "model fetches server-side (Responses API)"
            ),
            AttachmentType.TEXT.value: (
                "conditional: native 'file' for supported extensions "
                f"({len(self.SUPPORTED_FILE_EXTENSIONS)} types); "
                "framework text fallback otherwise"
            ),
            AttachmentType.FILE_BYTES.value: (
                "conditional: native 'file' for supported extensions; "
                "framework text/base64 fallback otherwise"
            ),
            AttachmentType.IMAGE_URL.value: (
                "standard: sent as 'image_url' content part (all providers)"
            ),
            AttachmentType.IMAGE_BASE64.value: (
                "standard: sent as data-URI 'image_url' content part (all providers)"
            ),
        }

        return {
            "provider": "BaseOpenAI",
            "native_types": sorted(t.value for t in self.NATIVE_ATTACHMENT_TYPES),
            "supported_extensions": sorted(self.SUPPORTED_FILE_EXTENSIONS),
            "type_details": type_details,
            "notes": (
                "OpenAI processes PDF, FILE_BASE64, and FILE_URL natively "
                "with full fidelity. TEXT and FILE_BYTES are native when the "
                "file extension is in SUPPORTED_FILE_EXTENSIONS. "
                "Images use the standard image_url wire format. "
                "Max file size: 50 MB."
            ),
        }

    # ================================================================== #
    # __init__                                                            #
    # ================================================================== #

    def __init__(
        self,
        model_name: str = "gpt-3.5-turbo",
        api_key: str | None = None,
        base_url: str | None = None,
        organization: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        temperature: float = 0.7,
        logit_bias: dict[str, float] | None = None,
        async_mode: bool = True,
    ) -> None:
        """
        Initialize OpenAI chat client with sensible defaults.

        Args:
            model_name: Model identifier (e.g. ``"gpt-4o"``).
            api_key: OpenAI API key (falls back to ``OPENAI_API_KEY`` env var).
            base_url: Custom base URL (falls back to ``OPENAI_API_BASE``).
            organization: Org ID (falls back to ``OPENAI_ORG_ID``).
            timeout: Request timeout in seconds.
            max_retries: Maximum retry attempts for transient errors.
            temperature: Default sampling temperature.
            logit_bias: Token-level logit bias dict.
            async_mode: ``True`` → ``AsyncOpenAI``, ``False`` → ``OpenAI``.
        """
        super().__init__()
        self.model_name = model_name
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.base_url = base_url or os.getenv("OPENAI_API_BASE")
        self.organization = organization or os.getenv("OPENAI_ORG_ID")
        self.timeout = timeout
        self.max_retries = max_retries
        self.temperature = temperature
        self.logit_bias = logit_bias
        self.async_mode = async_mode
        self._logger = logging.getLogger("BaseOpenAI")

        self._last_response_id: str | None = None

        if not self.api_key:
            raise ValueError("OPENAI_API_KEY is required")

        if self.async_mode:
            self._client = openai.AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                organization=self.organization,
                timeout=self.timeout,
                max_retries=self.max_retries,
            )
        else:
            self._client = openai.OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                organization=self.organization,
                timeout=self.timeout,
                max_retries=self.max_retries,
            )

    # ================================================================== #
    # Public helpers                                                      #
    # ================================================================== #

    def estimate_tokens(self, text: str) -> int:
        """Estimate the number of tokens in a text string."""
        import tiktoken

        enc = tiktoken.encoding_for_model(self.model_name)
        return len(enc.encode(text))

    # Delegate model quirk checks for external use
    def _uses_max_completion_tokens(self, model: str) -> bool:
        return uses_max_completion_tokens(model)

    def _is_strict_defaults_model(self, model: str) -> bool:
        return is_strict_defaults_model(model)

    # ================================================================== #
    # call() — unified entry point (smart routing)                        #
    # ================================================================== #

    async def call(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any | None = None,
        max_output_tokens: int = 1024,
        temperature: float | None = None,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        stop: list[str] | None = None,
        stream: bool = False,
        response_format: type[BaseModel] | type | dict[str, Any] | None = None,
        seed: int | None = None,
        n: int | None = None,
        reasoning_effort: str | None = None,
        service_tier: str | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        parallel_tool_calls: bool | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        metadata: dict[str, str] | None = None,
        store: bool | None = None,
        truncation: str | None = None,
        max_tool_calls: int | None = None,
        safety_identifier: str | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """
        Call OpenAI API with optional structured output.

        **Routing is automatic** — callers never specify which API to use.
        If *tools* contains any native OpenAI tool the Responses API is used;
        otherwise the Chat Completions API is used.

        ``max_output_tokens`` is the framework-neutral name; internally
        this is translated to the wire parameter the chosen API + model
        combination requires (``max_tokens``, ``max_completion_tokens``,
        or ``max_output_tokens``).
        """
        # ---- 1. Resolve structured output config ----
        output_schema_type = None
        api_response_format = None

        if response_format is not None:
            if isinstance(response_format, tuple) and len(response_format) == 2:
                api_response_format, schema_type = response_format
                if isinstance(schema_type, type):
                    output_schema_type = schema_type
            else:
                openai_response_format = build_response_format(response_format)
                if openai_response_format:
                    api_response_format = openai_response_format
                    if isinstance(response_format, type):
                        output_schema_type = response_format

        # ---- 1b. Collect extra params ----
        extra: dict[str, Any] = {}
        for _key, _val in [
            ("seed", seed),
            ("n", n),
            ("reasoning_effort", reasoning_effort),
            ("service_tier", service_tier),
            ("logprobs", logprobs),
            ("top_logprobs", top_logprobs),
            ("parallel_tool_calls", parallel_tool_calls),
            ("modalities", modalities),
            ("audio", audio),
            ("metadata", metadata),
            ("store", store),
            ("truncation", truncation),
            ("max_tool_calls", max_tool_calls),
            ("safety_identifier", safety_identifier),
            ("prompt_cache_key", prompt_cache_key),
            ("prompt_cache_retention", prompt_cache_retention),
        ]:
            if _val is not None:
                extra[_key] = _val
        extra.update(kwargs)

        # ---- 2. Route to appropriate backend ----
        if tools and self._has_native_tools(tools):
            result = await self._call_responses_api(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_output_tokens,
                temperature=temperature,
                top_p=top_p,
                stream=stream,
                response_format=api_response_format,
                **extra,
            )
        else:
            result = await call_chat_completions(
                self._client,
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_output_tokens,
                temperature=temperature,
                default_temperature=self.temperature,
                top_p=top_p,
                frequency_penalty=frequency_penalty,
                presence_penalty=presence_penalty,
                stop=stop,
                stream=stream,
                response_format=api_response_format,
                logit_bias=self.logit_bias,
                max_retries=self.max_retries,
                async_mode=self.async_mode,
                logger=self._logger,
                **extra,
            )

        # ---- 3. Parse structured output if requested ----
        if (
            output_schema_type is not None
            and hasattr(result, "choices")
            and result.choices
        ):
            msg = result.choices[0].message
            if isinstance(msg, AssistantMessage) and msg.content:
                return parse_response(msg.to_dict(), output_schema_type)
            elif isinstance(msg, dict) and msg.get("content"):
                return parse_response(msg, output_schema_type)

        return result

    # ================================================================== #
    # call_stream() — streaming entry point (smart routing)               #
    # ================================================================== #

    async def call_stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any | None = None,
        max_output_tokens: int = 1024,
        temperature: float | None = None,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[StreamEvent, None]:
        """Stream LLM output as ``StreamEvent`` objects.

        Uses the same automatic API routing as ``call()`` — if *tools*
        contains native OpenAI tools the Responses API is used;
        otherwise Chat Completions.

        Yields:
            ``StreamEvent`` — ``TOKEN`` events for each text delta,
            then one ``COMPLETE`` event with accumulated content and
            metadata (tool calls, usage, etc.).
        """
        if tools and self._has_native_tools(tools):
            async for event in self._stream_responses_api(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_output_tokens,
                temperature=temperature,
                top_p=top_p,
                **kwargs,
            ):
                yield event
        else:
            async for event in self._stream_chat_completions(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_output_tokens,
                temperature=temperature,
                top_p=top_p,
                frequency_penalty=frequency_penalty,
                presence_penalty=presence_penalty,
                stop=stop,
                **kwargs,
            ):
                yield event

    # ================================================================== #
    # Chat Completions streaming (private)                                #
    # ================================================================== #

    async def _stream_chat_completions(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any | None = None,
        max_tokens: int = 1024,
        temperature: float | None = None,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        stop: list[str] | None = None,
        **extra: Any,
    ) -> AsyncGenerator[StreamEvent, None]:
        """Build payload and delegate to the Chat Completions streaming adapter."""
        payload_model = ChatCompletionsPayload.build(
            model=model,
            messages=messages,
            stream=True,
            max_tokens=max_tokens,
            temperature=temperature,
            default_temperature=self.temperature,
            top_p=top_p,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            stop=stop,
            logit_bias=self.logit_bias,
            tools=tools,
            tool_choice=tool_choice,
            **{k: v for k, v in extra.items() if v is not None},
        )
        payload = payload_model.to_api_kwargs()

        async for event in stream_chat_completions(
            self._client, payload, async_mode=self.async_mode
        ):
            yield event

    # ================================================================== #
    # Responses API streaming (private)                                   #
    # ================================================================== #

    async def _stream_responses_api(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any | None = None,
        max_tokens: int = 1024,
        temperature: float | None = None,
        top_p: float = 1.0,
        **extra: Any,
    ) -> AsyncGenerator[StreamEvent, None]:
        """Build payload and delegate to the Responses API streaming adapter."""
        from nucleusiq_openai._shared.model_config import is_strict_defaults_model
        from nucleusiq_openai.nb_openai.response_normalizer import (
            build_responses_text_config,
            messages_to_responses_input,
        )
        from nucleusiq_openai.nb_openai.responses_api import (
            _adapt_tools_for_responses,
        )

        if not hasattr(self._client, "responses"):
            self._logger.warning(
                "Responses API not available — falling back to Chat Completions stream"
            )
            async for event in self._stream_chat_completions(
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                **extra,
            ):
                yield event
            return

        instructions, input_items = messages_to_responses_input(
            messages, self._last_response_id
        )
        serialized_input = [
            item.model_dump() if hasattr(item, "model_dump") else item
            for item in input_items
        ]

        payload: dict[str, Any] = {"model": model, "input": serialized_input}

        if tools:
            payload["tools"] = _adapt_tools_for_responses(tools)
        if instructions:
            payload["instructions"] = instructions
        if self._last_response_id:
            payload["previous_response_id"] = self._last_response_id

        if not is_strict_defaults_model(model):
            effective_temp = (
                temperature if temperature is not None else self.temperature
            )
            payload["temperature"] = effective_temp
            payload["top_p"] = top_p

        payload["max_output_tokens"] = max_tokens

        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

        response_format = extra.pop("response_format", None)
        if response_format is not None:
            text_config = build_responses_text_config(response_format)
            if text_config:
                payload["text"] = text_config

        if "reasoning_effort" in extra and extra["reasoning_effort"] is not None:
            payload["reasoning"] = {"effort": extra.pop("reasoning_effort")}

        _responses_extra_keys = {
            "service_tier",
            "metadata",
            "store",
            "truncation",
            "max_tool_calls",
            "parallel_tool_calls",
            "safety_identifier",
            "seed",
        }
        for k, v in extra.items():
            if k in _responses_extra_keys and v is not None:
                payload[k] = v

        async for event in stream_responses_api(
            self._client, payload, async_mode=self.async_mode
        ):
            if event.type == "complete" and event.metadata:
                resp_id = event.metadata.get("response_id")
                if resp_id and event.metadata.get("tool_calls"):
                    self._last_response_id = resp_id
            yield event

    # ================================================================== #
    # Responses API wrapper (manages conversation state)                  #
    # ================================================================== #

    async def _call_responses_api(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any | None = None,
        max_tokens: int = 1024,
        temperature: float | None = None,
        top_p: float = 1.0,
        stream: bool = False,
        response_format: dict[str, Any] | None = None,
        **extra: Any,
    ) -> _LLMResponse:
        """Call Responses API and manage conversation continuity state."""
        resp_tuple = await call_responses_api(
            self._client,
            model=model,
            messages=messages,
            tools=tools,
            tool_choice=tool_choice,
            max_tokens=max_tokens,
            temperature=temperature,
            default_temperature=self.temperature,
            top_p=top_p,
            stream=stream,
            response_format=response_format,
            last_response_id=self._last_response_id,
            max_retries=self.max_retries,
            async_mode=self.async_mode,
            logger=self._logger,
            **extra,
        )

        # If None returned, SDK too old — fall back to Chat Completions
        if resp_tuple[0] is None:
            return await call_chat_completions(
                self._client,
                model=model,
                messages=messages,
                tools=tools,
                tool_choice=tool_choice,
                max_tokens=max_tokens,
                temperature=temperature,
                default_temperature=self.temperature,
                top_p=top_p,
                stream=stream,
                response_format=response_format,
                logit_bias=self.logit_bias,
                max_retries=self.max_retries,
                async_mode=self.async_mode,
                logger=self._logger,
                **extra,
            )

        result, new_response_id = resp_tuple
        self._last_response_id = new_response_id
        return result

    # ================================================================== #
    # Public: responses_call() — direct Responses API access              #
    # ================================================================== #

    async def responses_call(
        self,
        *,
        model: str,
        input: str | list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        instructions: str | None = None,
        temperature: float | None = None,
        max_output_tokens: int | None = None,
        previous_response_id: str | None = None,
        stream: bool = False,
        include: list[str] | None = None,
        tool_choice: Any | None = None,
        **kwargs: Any,
    ) -> Any:
        """
        **Advanced** — direct access to OpenAI's Responses API.

        Most users should use ``call()`` which routes automatically.
        Use this method when you need:

        * Explicit control over ``previous_response_id``
        * The ``include`` parameter for rich annotations / sources
        * Raw Responses API response (not normalised to ``_LLMResponse``)

        Returns:
            Raw ``openai.types.responses.Response`` object.
        """
        return await responses_call_direct(
            self._client,
            model=model,
            input=input,
            tools=tools,
            instructions=instructions,
            temperature=temperature,
            max_output_tokens=max_output_tokens,
            previous_response_id=previous_response_id,
            stream=stream,
            include=include,
            tool_choice=tool_choice,
            async_mode=self.async_mode,
            **kwargs,
        )

    # ================================================================== #
    # Routing helpers                                                     #
    # ================================================================== #

    def _has_native_tools(self, tools: list[dict[str, Any]] | None) -> bool:
        """Return ``True`` if *tools* contains at least one native OpenAI tool."""
        if not tools:
            return False
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            tool_type = tool.get("type", "")
            if (
                tool_type
                and tool_type != "function"
                and tool_type in self.NATIVE_TOOL_TYPES
            ):
                return True
        return False


# ====================================================================== #
# Import-time exhaustiveness check for attachment routing                  #
# ====================================================================== #

_missing_att = set(AttachmentType) - BaseOpenAI._HANDLED_ATTACHMENT_TYPES
if _missing_att:
    raise AssertionError(
        f"BaseOpenAI._HANDLED_ATTACHMENT_TYPES is missing: "
        f"{sorted(m.value for m in _missing_att)}. "
        f"Every AttachmentType MUST be handled in _process_attachment_openai()."
    )
