"""Helpers to build Plotly subplots figures."""

from pathlib import Path
from typing import List
import webbrowser
import numpy as np
import plotly.graph_objects as go


def add_curve_plotly(
    fig: go.Figure,
    x: np.ndarray,
    y: np.ndarray,
    linewidth: int,
    custom_style: dict,
    legend: str,
    curve_idx: int,
):
    """Add a curve on a Plotly figure.
    In reality, add two traces:
        - a line
        - N markers, as defined in `symbols_makevery`

    Args:
        fig (go.Figure): Plotly figure.
        x (np.ndarray): X values.
        y (np.ndarray): Y values.
        pos (List[int]): (row, col) indexes
        linewidth (int): Width of the line.
        custom_style (dict): Style parameters.
        legend (str): Graph legend.
        curve_id (int): Index of the curve.
    """
    symbols_markevery = custom_style["markevery"]
    showlegend = True if legend else False
    fig.add_trace(
        go.Scatter(
            mode="lines",
            x=x,
            y=y,
            name=legend,
            legendgroup=f"{curve_idx}",
            showlegend=showlegend,
            line={
                "width": linewidth,
                "color": custom_style["color"],
                "dash": custom_style["linestyle"],
            },
        )
    )
    fig.add_trace(
        go.Scatter(
            mode="markers",
            x=x[symbols_markevery],
            y=y[symbols_markevery],
            name=legend,
            legendgroup=f"{curve_idx}",
            marker={
                "symbol": custom_style["marker"],
                "color": custom_style["color"],
            },
            showlegend=False,
        ),
    )


def set_labels_plotly(
    figure: go.Figure,
    x_label: str,
    y_label: str,
    title: str,
):
    """Add title and axes labels to a Plotly subplot.

    Args:
        figure (go.Figure): Plotly figure.
        x_label (str): Label for the X axis.
        y_label (str): Label for the Y axis.
        title (str): Title of the subplot.
        graph_position (int): Index of the graph.
        ncols (int): Number of columns.
    """
    figure.update_xaxes(
        title_text=x_label, mirror=True, automargin=True, linecolor="black", gridcolor="lightgrey"
    )
    figure.update_yaxes(
        title_text=y_label, mirror=True, automargin=True, linecolor="black", gridcolor="lightgrey"
    )
    figure.update_layout(
        title={"text": title, "x": 0.5, "xanchor": "center", "yanchor": "top"},
        plot_bgcolor="white",
        margin=dict(l=0, r=20, t=50, b=0),
        legend_tracegroupgap=0,
    )


def show_plotly(
    views: List[List[go.Figure]],
    titles: List[str],
    main_title: str,
    ncols: int,
    output_path: str = "out_showy.html",
):
    """
    Render Plotly figures in a responsive CSS grid layout and open them in the default browser.

    The output is a self-contained HTML file (Plotly JS is inlined, no CDN dependency)
    written to disk and opened with the system default browser, mimicking fig.show().

    Args:
      views (List[List[go.Figure]]): List of subplots per view.
      titles (List[str]): Title of each view.
      main_title (str): Main title.
      ncols (int): Number of columns.
      output_path (str): Output filename.
    """
    html = _build_html_page(views, titles, main_title, ncols)
    path = Path(output_path)
    path.write_text(html, encoding="utf-8")

    webbrowser.open(path.resolve().as_uri())


def _build_html_page(
    views: List[List[go.Figure]], titles: List[str], main_title: str, ncols: int
) -> str:
    """
    Build a HTML script to render Plotly subplots in a CSS grid layout.

    Built-in Plotly subplots (make_subplots) do not account for annotation placement
    (axis labels, subplot titles) when computing layout, resulting in overlapping text
    on window resize. This function works around that limitation by rendering each
    subplot as an independent Plotly figure inside a CSS grid cell, letting the browser
    handle layout and each figure manage its own margins via automargin.

    Multiple views (pages) are supported via a tab button bar. Only one page is visible
    at a time; switching tabs triggers a Plotly relayout to recompute figure dimensions.


    Args:
      views (List[List[go.Figure]]): List of subplots per view.
      titles (List[str]): Title of each view.
      main_title (str): Main title.
      ncols (int): Number of columns.

    Returns:
      str: HTML script.
    """
    pages_html = []
    for page_idx, figures in enumerate(views):
        blocks = []
        for i, fig in enumerate(figures):
            html = fig.to_html(
                full_html=False,
                include_plotlyjs="inline" if (page_idx == 0 and i == 0) else False,
                div_id=f"plot-p{page_idx}-{i}",
            )
            html = html.replace(
                "<div>",
                '<div style="height:100%; width:100%;">',
                1,
            )
            blocks.append(f'<div class="cell">{html}</div>')

        pages_html.append(
            f"""
        <div class="page" id="page-{page_idx}" 
              style="display: {'block' if page_idx == 0 else 'none'}">
          <div class="grid">
            {''.join(blocks)}
          </div>
        </div>
        """
        )

    buttons = "\n".join(
        f'<button class="tab-btn" onclick="showPage({i})" id="btn-{i}">' f"Fig. {i + 1}</button>"
        for i in range(len(views))
    )

    list_titles = str([f"{t}" for t in titles])

    html = f"""<!DOCTYPE html>
  <html>
  <head>
  <meta charset="utf-8">
  <title>{main_title}</title>
  <style>
    body {{  margin: 16px;
    font-family: 'Open Sans', verdana, arial, sans-serif;
    height: 96vh;    
    display: flex;
    flex-direction: column;
    box-sizing: border-box;}}

    .header {{
    flex-shrink: 0;          
  }}

    .page {{
        flex: 1;                         
    }}

    .tabs {{
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }}
    .tab-btn {{
      padding: 6px 14px;
      border: 1px solid #ccc;
      border-radius: 4px;
      background: white;
      cursor: pointer;
      font-size: 13px;
    }}
    .tab-btn.active {{
      background: #444;
      color: white;
      border-color: #444;
    }}

    .grid {{
      display: grid;
      grid-template-columns: repeat({ncols}, 1fr);
      height:100%;
    }}
    .cell {{
      min-width: 100px;
      height:100%;
    }}
    .cell .plotly-graph-div {{
      width: 100% !important;
      height: 100% !important;
    }}
    .svg-container {{
        height: 100% !important;
    }}
    .plot-container {{
      height: 100% !important;
    }}
  </style>
  </head>
  <body>

  <div class="header">
  <div class="tabs">
    {buttons}
  </div>
  <h2 id="pageName" style="
    font-family: 'Open Sans', verdana, arial, sans-serif;
    font-size: 20px;
    font-weight: normal;
    color: #444;
    margin: 0 0 12px 0;
    padding: 0;">title[0]</h2>
  </div>

  {''.join(pages_html)}



  <script>
    window.addEventListener('load', () => {{
          const page = document.getElementById('page-0');
        page.querySelectorAll('.plotly-graph-div').forEach(gd => {{
            Plotly.relayout(gd, {{ autosize: true }});
        }});
    }});


    const title = {list_titles}
    const pageName = document.getElementById("pageName");
    pageName.innerHTML = title[0];

    function showPage(idx) {{
        pageName.innerHTML = title[idx];

      document.querySelectorAll('.page').forEach((p, i) => {{
        p.style.display = i === idx ? 'block' : 'none';
      }});
      document.querySelectorAll('.tab-btn').forEach((b, i) => {{
        b.classList.toggle('active', i === idx);
      }});

      requestAnimationFrame(() => {{
        const page = document.getElementById('page-' + idx);
        page.querySelectorAll('.plotly-graph-div').forEach(gd => {{
            Plotly.relayout(gd, {{ autosize: true }});
        }});
      }})

    }}

    document.getElementById('btn-0').classList.add('active');
  </script>

  </body>
  </html>"""
    return html
