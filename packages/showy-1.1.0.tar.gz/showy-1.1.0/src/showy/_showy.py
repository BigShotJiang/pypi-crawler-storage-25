import math
import warnings
import textwrap

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from typing import List, Tuple
from collections.abc import Callable
import numpy as np

from showy.preprocess_utils import preprocess_layout
from showy.validation import validate_layout
from showy.backend_plotly import (
    add_curve_plotly,
    set_labels_plotly,
    show_plotly,
)
from showy.backend_matplotlib import (
    add_curve_matplotlib,
    build_new_figure_matplotlib,
    set_labels_matplotlib,
)

import plotly.graph_objects as go


# TODO: add export of data
# TODO: layout merging
# TODO: add schema validation


def showy(
    layout: dict,
    dataframe: Tuple[list, dict, tuple],
    show: bool = True,
    preprocess_fnc: Callable = preprocess_layout,
    backend: str = "matplotlib",
):
    """It displays the desired graphs described by the provided layout
    thanks to the provided key-value object which contains
    the required data
    """
    list_backends = ["matplotlib", "plotly"]
    validate_layout(layout)

    assert (
        backend in list_backends
    ), f"{backend!r} is not a valid backend. Choose between: {', '.join(list_backends)}."

    dataframes = dataframe
    if type(dataframes) not in [tuple, list]:
        dataframes = [dataframes]

    comparison_mode = len(dataframes) > 1

    available_varnames = _get_available_varnames(dataframes)

    layout = preprocess_fnc(layout, available_varnames)

    display_params = _initialize_display(layout)
    max_size_label = _initialize_max_size_label(layout)
    max_graphs = display_params["max_graphs"]
    fig_layout = display_params["layout"]

    figure = None
    figure_number = 0
    views = []
    fig_titles = []
    for i, graph_layout in enumerate(layout["graphs"]):
        graph_position = i % max_graphs + 1

        if graph_position == 1:
            figure_number += 1
            figure_name = _get_figure_name(
                display_params["title"], comparison_mode, figure_number, display_params["n_figs"]
            )

            if backend == "matplotlib":
                figure = build_new_figure_matplotlib(figure_name, **display_params)
            else:
                fig_titles.append(figure_name)
                views.append([])

        if backend == "plotly":
            figure = go.Figure()
            views[-1].append(figure)

        _build_new_graph(
            figure,
            graph_layout,
            graph_position,
            fig_layout,
            dataframes,
            max_size_label,
            backend=backend,
        )

    if show:
        if backend == "plotly":
            show_plotly(views, fig_titles, display_params["title"], fig_layout[1])
        else:
            plt.show()


def _get_available_varnames(dataframes: List[dict]) -> List[str]:
    """Get the list of variable names available in the data for plotting.

    Args:
        dataframes (List[dict]): Input data : [{ "variable" : value }, ... ]

    Returns:
        List[str]: List of variable names
    """
    var_names = set(dataframes[0].keys())
    for dataframe in dataframes[1:]:
        var_names = var_names.intersection(set(dataframe.keys()))

    return list(var_names)


def _initialize_display(layout: dict) -> dict:
    """Sets some parameters needed by the function "display", thanks
    to the provided layout, and returns them in a dictionary.

    Args:
        layout (dict): Input graph layout.

    Returns:
        dict: Dispay parameters.
    """

    n_graphs = len(layout["graphs"])

    fig_layout = layout.get("figure_structure", None)
    if fig_layout is None:
        fig_layout = [1, n_graphs] if n_graphs < 4 else [2, 3]

    n_max_graphs_fig = fig_layout[0] * fig_layout[1]
    n_figs = math.ceil(n_graphs / n_max_graphs_fig)

    display_params = {
        "layout": fig_layout,
        "max_graphs": n_max_graphs_fig,
        "n_figs": n_figs,
        "dpi": layout.get("figure_dpi", None),
        "inches_size": layout.get("figure_size", (14, 8)),
        "title": layout.get("title", ""),
    }

    return display_params


def _initialize_max_size_label(layout: dict) -> dict:
    """Set the maximum width of each label.

    Args:
        layout (dict): Layout.

    Returns:
        dict: Maximum width for the "legend", "axes" and "plot_title".
    """
    return {
        "legend": layout.get("width_label_legend", 25),
        "axes": layout.get("width_label_axes", 30),
        "plot_title": layout.get("width_label_plot", 50),
    }


def _get_figure_name(title: str, comparison_mode: bool, fig_number: int, n_figs: int) -> str:
    """Get figure name.

    Args:
        title (str): Raw title.
        comparison_mode (bool): Comparison mode.
        fig_number (int): Index of the fig.
        n_figs (int): Total number of fig.

    Returns:
        str: Figure name.
    """
    figure_name = title
    if comparison_mode:
        figure_name += " (comparison)"
    if fig_number is not None and n_figs is not None and n_figs > 1:
        figure_name += f" ({fig_number}/{n_figs})"
    return figure_name


def _build_new_graph(
    figure: Tuple[plt.Figure, go.Figure],
    graph_layout: dict,
    graph_position: int,
    fig_layout: List[int],
    dataframes: Tuple[tuple, list],
    max_size_label: dict,
    backend: str = "matplotlib",
):
    """Build a new subplot in a figure.

    Args:
        figure (Tuple[plt.Figure, go.Figure]): Figure. Either Matplotlib or Plotly.
        graph_layout (dict): Graph settings from input: x_label, y_label, title, ....
        graph_position (int): Index of the graph.
        fig_layout (List[int]): (row, col) indexes.
        dataframes (Tuple[tuple, list]): Data.
        backend (str, optional): Set the backend between "matplotlib" and "plotly".
        Defaults to "matplotlib".
    """
    # TODO: handle tick label overlap
    # TODO: handle no legend space

    if backend == "plotly":
        assert isinstance(figure, go.Figure)
    else:
        assert isinstance(figure, plt.Figure)

    x_label = _check_size_label(graph_layout.get("x_label"), max_size_label["axes"])
    y_label = _check_size_label(graph_layout.get("y_label"), max_size_label["axes"])
    title = _check_size_label(graph_layout.get("title"), max_size_label["plot_title"])

    # set labels & subplot
    if backend == "matplotlib":
        ax = figure.add_subplot(*fig_layout, graph_position)
        set_labels_matplotlib(ax, x_label, y_label, title)
    else:
        set_labels_plotly(figure, x_label, y_label, title)

    for data_number, dataframe in enumerate(dataframes):
        linewidth = 2
        if data_number > 0:
            linewidth = 4
        x = dataframe[graph_layout["x_var"]]
        for curve_number, curve_layout in enumerate(graph_layout["curves"]):
            symbols_markevery = _symbols_markevery(x)
            custom_style = _custom_cycler_iterate(
                curve_number, data_number, symbols_markevery, backend
            )
            try:
                y = dataframe[curve_layout["var"]]
                # add curve
                if backend == "matplotlib":
                    add_curve_matplotlib(ax, x, y, linewidth, custom_style)
                else:
                    legend = _check_size_label(curve_layout.get("legend"), max_size_label["legend"])
                    add_curve_plotly(figure, x, y, linewidth, custom_style, legend, curve_number)

            except KeyError:
                print(f"Could not find the key {curve_layout['var']} in current dataframe")

    if backend == "matplotlib":
        # improve legends
        handles = []
        for curve_number, curve_layout in enumerate(graph_layout["curves"]):
            label = _check_size_label(curve_layout.get("legend"), max_size_label["legend"])
            custom_style = _custom_cycler_iterate(curve_number, 0)
            if label is not None:
                handles.append(Line2D([0], [0], label=label, **custom_style))

        if handles:
            ax.legend(handles=handles, loc=0)
        figure.tight_layout()


def _check_size_label(text: str, width: int) -> str:
    """Truncated the label if it exists (not None) and exceeds the maximum width.

    Args:
        text (str): Label.
        width (int): Maximum number of character.

    Returns:
        str: Label.
    """
    return textwrap.shorten(text, width=width, placeholder="...") if text else text


def _custom_cycler_iterate(
    index: int,
    family_index: int = 0,
    markevery: Tuple[List[int], None] = None,
    backend: str = "matplotlib",
) -> dict:
    """Returns a dict with keys and values in accordance to the Matplotlib
    syntax.

    The graph style includes a color from a list defined for colour-blind people
    by https://personal.sron.nl/~pault/, depending if the data is compared with
    other data.
    """

    custom_cycler = [
        "#4477AA",
        "#66CCEE",
        "#228833",
        "#CCBB44",
        "#EE6677",
        "#AA3377",
        "#BBBBBB",
    ]
    if backend == "matplotlib":
        custom_linestyles = [
            "solid",
            "dashed",
            "dotted",
            "dash",
            "dash",
            "dash",
            "dash",
        ]
        custom_symbols = ["d", "o", "v", "^", ">", "<", "s"]
    else:
        custom_linestyles = ["solid", "dash", "dot", "dash", "dash", "dash", "dash"]
        custom_symbols = [
            "diamond",
            "circle",
            "triangle-down",
            "triangle-up",
            "triangle-right",
            "triangle-left",
            "square",
        ]

    index_ = index % len(custom_cycler)
    family_index_ = family_index % len(custom_linestyles)

    custom_style = {
        "color": custom_cycler[index_],
        "linestyle": custom_linestyles[family_index_],
        "marker": custom_symbols[index_],
        "markevery": markevery,
    }

    if index > len(custom_cycler):
        warnings.warn(f"More than {len(custom_cycler)} plots on one graph!")

    if family_index > len(custom_linestyles):
        warnings.warn(f"More than {len(custom_linestyles)} types of curves on one graph")

    return custom_style


def _symbols_markevery(x: np.ndarray) -> List[int]:
    """compute indices where to show symbols

    Args:
        x (numpy array): x vector
    """

    if len(x) < 10:  # Failsafe for too short signals
        return list(range(len(x)))

    nb_markers = 10
    # set step between two symbols
    step = len(x) / (nb_markers - 1)
    # list of symbols indexes (first symbol at first index)
    symbols_indexes = [int(k * step) for k in range(nb_markers)]

    symbols_indexes[-1] = min(symbols_indexes[-1], len(x) - 1)

    return symbols_indexes
