"""Helpers to build Matplotlib subplots figures."""

import matplotlib.pyplot as plt
import numpy as np

def build_new_figure_matplotlib(
    figure_name: str = "",
    **kwargs,
) -> plt.Figure:
    """Create a new plt.figure object.

    Returns:
        plt.Figure: Matplotlib figure.
    """

    dpi = kwargs.get("dpi", None)
    inches_size = kwargs.get("inches_size", (14, 8))

    figure = plt.figure(dpi=dpi)
    figure.set_size_inches(*inches_size)
    figure.canvas.manager.set_window_title(figure_name.strip())
    figure.subplots_adjust(left=0.11, bottom=0.12, right=0.9, top=0.9, wspace=0.38, hspace=0.32)

    return figure


def set_labels_matplotlib(ax: plt.Axes, x_label: str, y_label: str, title: str): #pragama: no cover
    """Add title and axes labels to a Matplotlib subplot.

    Args:
        ax (plt.Axes): Matplotlib axes.
        x_label (str): Label for the X-axis.
        y_label (str): Label for the Y-axis.
        title (str): Title of the subplot.
    """
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title, fontweight="bold")


def add_curve_matplotlib(
    ax: plt.Axes,
    x: np.ndarray,
    y: np.ndarray,
    linewidth: int,
    custom_style: dict,
): # pragama: no cover
    """Add a curve on a Matplotlib figure.

    Args:
        ax (plt.Axes): Matplotlib axes.
        x (np.ndarray): X values.
        y (np.ndarray): Y values.
        linewidth (int): Width of the line.
        custom_style (dict): Style parameters.
    """
    ax.plot(
        x,
        y,
        **custom_style,
        linewidth=linewidth,
    )
