import re
from typing import List, Tuple


def preprocess_layout(layout: dict, available_varnames: List[str]) -> dict:
    """
    Clean graph layout from asterisk wildcard pattern (or stars).

    Args:
        layout (dict): Input graph layout.
        available_varnames (List[str]): List of available variable names.

    Returns:
        dict: New graph layout, with potential additionnal graphs, one per matching
        variable names with a wildcard pattern / star.
    """
    new_layout = layout.copy()
    new_layout["graphs"] = _preprocess_stars(layout["graphs"], available_varnames)

    return new_layout


def _preprocess_stars(
    graphs_layouts: List[dict], available_varnames: List[str]
) -> List[dict]:
    """
    For each graph in the list of graphs:

         - Spot wildcard (`*`) patterns in curve variables.
         - Match patterns against available variable names.
         - Add one curve per match in the given graph.

    Args:
        graphs_layouts (List[dict]): List of graphs, from input graph layout. e.g.:
        ```
        [
            {
                "curves": [{"var": "sine_*"}],
                "x_var": "time",
                "y_label": "Fifi [mol/m³/s]",
                "x_label": "Time [s]",
                "title": "Sinus of frequency *",
            },
            "..."
        ]
        ```
        available_varnames (List[str]): List of available variable names.

    Returns:
        List[dict]: Final list of graphs, with potential additionnal curves, one per
        variable that matches a wildcard (`*`) pattern.
    """
    new_graphs_layouts = []

    for graph_layout in graphs_layouts:
        if not _has_stars(graph_layout):
            new_graphs_layouts_ = [graph_layout]
        else:
            new_graphs_layouts_ = _replace_stars(graph_layout, available_varnames)

        new_graphs_layouts.extend(new_graphs_layouts_)

    return new_graphs_layouts


def _has_stars(graph_layout: dict) -> bool:
    """Checks if the variables of a curve template contain the wilcard `*` (star).

    Args:
        graph_layout (dict): Graph template. e.g.:
        ```
        {
            "curves": [
                {
                    "var": "sine_100",
                    "legend": "origin",
                },
                {
                    "var": "sine_100p1",
                    "legend": "shifted",
                },
            ],
            "x_var": "time",
            "y_label": "Loulou [cow/mug]",
            "x_label": "Time [s]",
            "title": "Third graph",
        },
        ```

    Returns:
        bool: returns True if contain stars else False.
    """
    for name in _get_curve_var_names(graph_layout):
        if "*" in name:
            return True

    return False


def _get_curve_var_names(graph_layout: dict) -> List[str]:
    """Lists curve variables of a graph.

    Args:
        graph_layout (dict): Graph template. e.g.:
        ```
        {
            "curves": [
                {
                    "var": "sine_100",
                    "legend": "origin",
                },
                {
                    "var": "sine_100p1",
                    "legend": "shifted",
                },
            ],
            "x_var": "time",
            "y_label": "Loulou [cow/mug]",
            "x_label": "Time [s]",
            "title": "Third graphg",
        },
        ```

    Returns:
        List[str]: List of curve variables of a graph.
        e.g. `["sine_100", "sine_100p1"]`
    """
    return [curve["var"] for curve in graph_layout["curves"]]


def _replace_stars(graph_layout: dict, available_varnames: List[str]) -> List[dict]:
    """
    Find all wildcards (`*`) pattern presents in curve variables.
    Match each pattern against available variable names.
    Add a curve per match in a given graph template.

    Args:
        graph_layout (dict): Graph template.
        available_varnames (List[str]): List of available variable names.

    Returns:
        List[dict]: A graph template that may include additional curves, with one curve
        created per match for each wildcard pattern found.
    """
    curve_var_names = _get_curve_var_names(graph_layout)
    stars_values = _collect_stars_values(curve_var_names, available_varnames)

    new_graph_layouts = [
        _replace_stars_by_values(graph_layout, stars_values_)
        for stars_values_ in stars_values
    ]

    return new_graph_layouts


def _replace_stars_by_values(graph_layout: dict, stars_values: Tuple[str]) -> dict:
    """
    Replace stars by values listed in `stars_values` to obtain a valid variable name
    and add a curve for it in the graph templace.

        Args:
            graph_layout (dict): Graph template
            stars_values (Tuple[str]): Values to replace stars. e.g. :
            `stars_values = (CO, min)` for "Y_*_*" (giving "Y_CO_min").

        Returns:
            dict: New graph template with one additional curve per variable that matches
            a wildcard pattern (i.e. per value in `stars_values`).
    """
    new_graph_layout = {}

    # handle curves
    curves = []
    for curve in graph_layout["curves"]:
        new_curve = {}
        for key, value in curve.items():
            new_curve[key] = _replace_stars_in_string(value, stars_values)
        curves.append(new_curve)
    new_graph_layout["curves"] = curves

    # handle other
    for key, value in graph_layout.items():
        if key == "curves":
            continue
        new_graph_layout[key] = _replace_stars_in_string(value, stars_values)

    return new_graph_layout


def _collect_stars_values(
    var_names: List[str], available_varnames: List[str], sort: bool = True
) -> List[Tuple[str]]:
    """Lists values from variable names matching wildcard (`*`) pattern.

    Args:
        var_names (List[str]): List of variable used in the curves of the given graph.
        available_varnames (List[str]): List of available variable names
        sort (bool, optional): Sorting resulting list. Defaults to True.

    Returns:
        List[Tuple[str]]: List of matching values. Each item in the tuple is a value
        that should replace a star to obtain a valid variable name.
        e.g. returns `[("CO", "max"), ("CO, "min")]` from `var_names = ["Y_*_*"]` and
        `available_varnames = ["Y_CO_max", "Y_CO_min"]`.
    """
    stars_values_groups = []
    for var_name in var_names:
        if var_name.count("*") == 0:
            continue

        stars_values_groups.append(
            _find_stars_values_in_string(var_name, available_varnames)
        )

    # set intersection
    stars_values = set(stars_values_groups[0])
    for stars_values_group in stars_values_groups[1:]:
        stars_values = stars_values.intersection(stars_values_group)

    stars_values = list(stars_values)
    if sort:
        stars_values.sort(key=lambda x: x[0])

    return stars_values


def _find_stars_values_in_string(
    var_name: str, available_varnames: List[str]
) -> List[Tuple[str]]:
    """
    Find variable names matching the pattern var_name in available_varnames

    Args:
        var_name (str): Variable name.
        available_varnames (List[str]): List of available variable name.

    Returns:
        List[Tuple[str]]: List of matching values per pattern
        e.g. "Y_*_*" -> `[("CO", "min"), ("CO", "max")]` for "Y_CO_min" and "Y_CO_max".
    """
    n = var_name.count("*")
    if var_name != "*":
        regex_var = var_name.replace("*", "(.*)")
        stars_values = re.findall(regex_var, "\n".join(available_varnames))
    else:
        stars_values = available_varnames
    if n == 1:
        stars_values = [(star_value,) for star_value in stars_values]

    return stars_values


def _replace_stars_in_string(string: str, stars_values: Tuple[str]) -> str:
    """Replace stars in a given variable name using a list of replacing values.

    Args:
        string (str): Current variable name
        stars_values (Tuple[str]): List of replacing values.

    Returns:
        str: Valid variable name, without stars.
    """
    if string.count("*") == 0:
        return string

    string_ls = string.split("*")

    new_string = ""
    for string_, star_value in zip(string_ls, stars_values):
        new_string += f"{string_}{star_value}"
    new_string += string_ls[-1]

    return new_string
