"""Shared Link runtime helpers."""
