"""Tests for SecurityHeadersMiddleware."""

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from nene2.middleware import SecurityHeadersMiddleware


def _make_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware)

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    return app


def test_security_headers_present() -> None:
    client = TestClient(_make_app())
    response = client.get("/ping")
    assert response.status_code == 200
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"
    assert response.headers["Referrer-Policy"] == "strict-origin-when-cross-origin"
    assert "Content-Security-Policy" in response.headers
    assert "Permissions-Policy" in response.headers


def test_csp_absent_on_openapi_paths() -> None:
    client = TestClient(_make_app())
    for path in ("/docs", "/redoc", "/openapi.json"):
        response = client.get(path)
        assert "Content-Security-Policy" not in response.headers, (
            f"CSP should not be set for {path}"
        )
        assert response.headers["X-Content-Type-Options"] == "nosniff"


def test_security_headers_on_error_response() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware)

    @app.get("/boom")
    async def boom() -> JSONResponse:
        return JSONResponse({}, status_code=404)

    client = TestClient(app)
    response = client.get("/boom")
    assert response.status_code == 404
    assert response.headers["X-Content-Type-Options"] == "nosniff"


def test_custom_csp_value() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, csp="default-src 'self' cdn.example.com")

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    response = client.get("/ping")
    assert response.headers["Content-Security-Policy"] == "default-src 'self' cdn.example.com"


def test_extra_no_csp_paths() -> None:
    app = FastAPI(docs_url="/api-docs", redoc_url="/api-redoc")
    app.add_middleware(SecurityHeadersMiddleware, extra_no_csp_paths=["/api-docs", "/api-redoc"])

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    assert "Content-Security-Policy" not in client.get("/api-docs").headers
    assert "Content-Security-Policy" not in client.get("/api-redoc").headers
    assert "Content-Security-Policy" in client.get("/ping").headers


def test_custom_permissions_policy() -> None:
    app = FastAPI()
    app.add_middleware(
        SecurityHeadersMiddleware,
        permissions_policy="geolocation=(self), microphone=()",
    )

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    r = client.get("/ping")
    assert r.headers["Permissions-Policy"] == "geolocation=(self), microphone=()"


def test_hsts_header_when_specified() -> None:
    app = FastAPI()
    app.add_middleware(
        SecurityHeadersMiddleware,
        hsts="max-age=31536000; includeSubDomains",
    )

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    r = client.get("/ping")
    assert r.headers["Strict-Transport-Security"] == "max-age=31536000; includeSubDomains"


def test_no_hsts_by_default() -> None:
    client = TestClient(_make_app())
    r = client.get("/ping")
    assert "Strict-Transport-Security" not in r.headers


def test_default_no_csp_paths_still_work_with_extra_paths() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, extra_no_csp_paths=["/custom"])

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    assert "Content-Security-Policy" not in client.get("/docs").headers
    assert "Content-Security-Policy" not in client.get("/custom").headers
    assert "Content-Security-Policy" in client.get("/ping").headers


def test_csp_empty_string_disables_csp_header() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, csp="")

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"ok": True})

    client = TestClient(app)
    r = client.get("/ping")
    assert "Content-Security-Policy" not in r.headers
