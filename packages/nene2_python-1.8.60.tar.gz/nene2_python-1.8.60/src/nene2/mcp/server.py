"""LocalMcpServer — thin wrapper around FastMCP with NENE2 defaults.

Provides the framework scaffolding; tool registration is done in the
application layer (example/mcp.py) using the .tool() decorator.
"""

from collections.abc import Callable
from typing import Any, Literal

from mcp.server.fastmcp import FastMCP


class LocalMcpServer:
    """MCP server with sensible defaults for local / stdio transport."""

    def __init__(
        self,
        name: str,
        instructions: str = "",
        *,
        host: str = "127.0.0.1",
        port: int = 8000,
    ) -> None:
        self._mcp = FastMCP(name, instructions=instructions, host=host, port=port)

    def tool(self, description: str = "") -> Callable[[Any], Any]:
        """Register a function as an MCP tool."""
        return self._mcp.tool(description=description)

    def list_tools(self) -> list[str]:
        """Return the names of all registered tools.

        Useful for debugging and introspection::

            server = LocalMcpServer("my-server")


            @server.tool("Get data")
            def get_data() -> str: ...


            print(server.list_tools())  # ["get_data"]
        """
        return [t.name for t in self._mcp._tool_manager.list_tools()]

    def run(self, transport: Literal["stdio", "sse", "streamable-http"] = "stdio") -> None:
        """Start the MCP server. Blocks until the client disconnects."""
        self._mcp.run(transport=transport)
