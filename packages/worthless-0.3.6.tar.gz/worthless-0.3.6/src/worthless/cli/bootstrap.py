"""First-run ~/.worthless/ initialization and lock management."""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from collections.abc import Generator

from cryptography.fernet import Fernet

from worthless.cli.errors import ErrorCode, WorthlessError, sanitize_exception
from worthless.cli.keystore import (
    migrate_file_to_keyring,
    read_fernet_key,
    read_fernet_key_from_file,
    store_fernet_key,
)
from worthless.cli.platform import IS_WINDOWS

logger = logging.getLogger(__name__)

_DEFAULT_BASE = Path.home() / ".worthless"
_STALE_LOCK_SECONDS = 300  # 5 minutes


@dataclass
class WorthlessHome:
    """Paths within the ``~/.worthless/`` directory tree."""

    base_dir: Path = field(default_factory=lambda: _DEFAULT_BASE)
    # HF2 / worthless-mnlp: per-instance cache for the Fernet key so a single
    # CLI invocation triggers exactly one keychain probe (one macOS Keychain
    # prompt on first run). Excluded from init/repr/compare so it doesn't
    # leak into reprs or break dataclass equality across cached/uncached
    # instances.
    _cached_fernet_key: bytearray | None = field(
        default=None, init=False, repr=False, compare=False
    )
    # Per-instance lock guarding the lazy-populate path. The check-then-set
    # in ``fernet_key`` is two operations; without this lock, two threads
    # accessing the property concurrently on the same instance can both
    # observe ``None`` and both call ``read_fernet_key`` — firing duplicate
    # macOS Keychain prompts and discarding one bytearray without
    # ``zero_buf``. Real call site: ``src/worthless/mcp/server.py`` runs
    # FastMCP's asyncio loop on the main thread but dispatches blocking
    # work (``_do_lock``) via ``loop.run_in_executor`` to the default
    # thread pool — main + executor can both touch ``home.fernet_key``.
    _cache_lock: threading.Lock = field(
        default_factory=threading.Lock, init=False, repr=False, compare=False
    )

    @property
    def db_path(self) -> Path:
        return self.base_dir / "worthless.db"

    @property
    def fernet_key_path(self) -> Path:
        env_path = os.environ.get("WORTHLESS_FERNET_KEY_PATH")
        if env_path:
            return Path(env_path)
        return self.base_dir / "fernet.key"

    @property
    def shard_a_dir(self) -> Path:
        return self.base_dir / "shard_a"

    @property
    def recovery_dir(self) -> Path:
        """Directory holding ``<account>.recover`` files for sibling-Mac
        recovery (WOR-456). Only populated when ``worthless doctor --fix``
        migrates a synced keychain entry — the value is exported here so
        a user with a second Mac can copy the file across before iCloud's
        tombstone propagates and removes the local copy on the sibling.
        """
        return self.base_dir / "recovery"

    @property
    def lock_file(self) -> Path:
        return self.base_dir / ".lock-in-progress"

    @property
    def bootstrapped_marker(self) -> Path:
        """Marker file written at the end of a successful ensure_home().

        HF3 (worthless-cmpf): used to distinguish "first-run /
        previously-failed bootstrap" (probe must run, key must be
        generated) from "bootstrap completed at least once" (probe
        gated). Stronger than ``base_dir.exists()`` because a failed
        prior run leaves the dir present but the keystore empty; the
        marker is only created at the END of a successful ensure_home,
        so its presence is a positive signal of completed bootstrap.
        """
        return self.base_dir / ".bootstrapped"

    @property
    def fernet_key(self) -> bytearray:
        """Read the Fernet key via keystore cascade (SR-01: mutable bytearray).

        Memoized per-instance with double-checked locking. macOS Keychain
        re-evaluates the per-call ACL, so without this cache one
        ``worthless lock`` triggers 3+ Keychain prompts.

        Returns a fresh bytearray copy on each access so callers can
        ``zero_buf()`` per SR-01 without poisoning the cache.
        """
        if self._cached_fernet_key is None:
            with self._cache_lock:
                if self._cached_fernet_key is None:
                    logger.debug("WorthlessHome.fernet_key cache MISS — reading from keystore")
                    self._cached_fernet_key = read_fernet_key(self.base_dir)
        else:
            logger.debug("WorthlessHome.fernet_key cache HIT")
        return bytearray(self._cached_fernet_key)

    def _seed_cached_fernet_key(self, key: bytes | bytearray) -> None:
        """Install *key* into the cache under ``_cache_lock``.

        HF3 (worthless-cmpf): single entry point for any code that
        wants to populate the cache from a known source (env var,
        on-disk file, freshly generated key). Mirrors the locking
        discipline of the property's read path so a concurrent
        ``home.fernet_key`` call cannot race the assignment.
        """
        with self._cache_lock:
            self._cached_fernet_key = bytearray(key)


def _fernet_key_present(home: WorthlessHome) -> bool:
    """True if a Fernet key is provisioned WITHOUT touching the keyring.

    HF3 (worthless-cmpf): cheap probe that lets read-only commands
    (``worthless scan`` in particular) bypass the keystore entirely.
    Sources, in priority order:

    1. ``WORTHLESS_FERNET_KEY`` env var — used by IPC fd transport
       and CI environments.
    2. The on-disk fernet key file — pre-keyring fallback that still
       exists on legacy installs.

    The keyring is intentionally NOT consulted here — its access on
    macOS triggers a per-call keychain prompt, which is the very UX
    bug HF3 is closing. For users with only a keyring entry (no env
    var, no file), this returns False and the caller falls through
    to the keyring probe — that's correct: first-run detection has
    to happen somewhere.
    """
    if os.environ.get("WORTHLESS_FERNET_KEY"):
        return True
    if home.fernet_key_path.exists():
        return True
    return False


def ensure_home(base_dir: Path | None = None) -> WorthlessHome:
    """Create ``~/.worthless/`` structure on first run (idempotent).

    Creates directories with 0700 permissions, generates a Fernet key
    if missing, initialises the SQLite database, and writes a
    ``.bootstrapped`` marker on completion. The marker gates future
    keystore probes so post-bootstrap CLI invocations skip the
    keyring entirely when scan/status/other read-only paths run
    (HF3 — worthless-cmpf).
    """
    home = WorthlessHome(base_dir=base_dir or _DEFAULT_BASE)

    try:
        # Create directories
        home.base_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        home.shard_a_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

        # Ensure permissions are correct even if dir already existed
        if not IS_WINDOWS:
            home.base_dir.chmod(0o700)
            home.shard_a_dir.chmod(0o700)

        # Validate custom fernet key path if set via env var
        fernet_path = home.fernet_key_path
        fernet_parent = fernet_path.parent
        if os.environ.get("WORTHLESS_FERNET_KEY_PATH") and not fernet_parent.is_dir():
            raise WorthlessError(
                ErrorCode.BOOTSTRAP_FAILED,
                f"WORTHLESS_FERNET_KEY_PATH directory does not exist: {fernet_parent}\n"
                "Create it or mount a volume at that path.",
            )

        # HF3 (worthless-cmpf): the keystore-touching logic is gated
        # on ``bootstrapped_marker`` — a marker file written at the
        # END of a successful first-run, NOT just ``base_dir.exists()``
        # (which a Docker volume mount or a failed prior run can pre-
        # create). Marker absent ⇒ probe-and-generate. Marker present
        # AND env-or-file present ⇒ pre-populate the cache without
        # touching the keyring. Marker present AND keyring-only ⇒
        # skip; key-using commands fetch lazily via ``home.fernet_key``.
        # Migration is NOT run on the post-bootstrap file path — that
        # would re-introduce a keyring touch on every CLI invocation,
        # defeating the read-only-no-keychain contract. Filed as
        # ``worthless-d8it`` (doctor --migrate) for legacy file
        # installs.
        if not home.bootstrapped_marker.exists():
            try:
                _ = home.fernet_key
            except WorthlessError as exc:
                if exc.code != ErrorCode.KEY_NOT_FOUND:
                    raise
                logger.info("ensure_home: no Fernet key found, generating new one")
                key = Fernet.generate_key()
                store_fernet_key(key, home_dir=home.base_dir)
                home._seed_cached_fernet_key(key)
            else:
                migrate_file_to_keyring(home.base_dir)
            # Marker is written ONLY on the first-run path. Subsequent
            # invocations short-circuit above without touching mtime.
            home.bootstrapped_marker.touch(mode=0o600, exist_ok=True)
        elif _fernet_key_present(home):
            # Both post-bootstrap branches treat the env/file signal as
            # advisory: if the source disappears or is malformed between
            # ``_fernet_key_present`` and the actual read, defer to the
            # lazy keyring fetch on next ``home.fernet_key`` access
            # rather than crashing ensure_home on a read-only invocation.
            # ``logger.debug`` (not info) on the defer paths because
            # this is best-effort recovery from a TOCTOU race — no
            # operator action is required and it's not a state
            # transition worth surfacing in normal logs.
            if os.environ.get("WORTHLESS_FERNET_KEY"):
                # Cascade short-circuits at the env step, no keyring touch.
                try:
                    _ = home.fernet_key
                except WorthlessError as exc:
                    if exc.code != ErrorCode.KEY_NOT_FOUND:
                        raise
                    logger.debug(
                        "ensure_home: WORTHLESS_FERNET_KEY env var unset or "
                        "malformed between _fernet_key_present and read; "
                        "deferring to lazy keyring fetch"
                    )
            else:
                # File-only. Read OUTSIDE the lock so concurrent
                # ``home.fernet_key`` readers aren't blocked on disk I/O;
                # acquire only for the assignment.
                try:
                    key = read_fernet_key_from_file(home.base_dir)
                except WorthlessError as exc:
                    if exc.code != ErrorCode.KEY_NOT_FOUND:
                        raise
                    logger.debug(
                        "ensure_home: fernet key file disappeared between "
                        "_fernet_key_present and read; deferring to lazy "
                        "keyring fetch"
                    )
                else:
                    home._seed_cached_fernet_key(key)
        # else: keyring-only post-bootstrap → skip; lazy fetch later.
    except WorthlessError:
        raise
    except OSError as exc:
        fernet_env = os.environ.get("WORTHLESS_FERNET_KEY_PATH")
        if fernet_env:
            raise WorthlessError(
                ErrorCode.BOOTSTRAP_FAILED,
                f"Cannot write fernet key to {fernet_env}: "
                f"{sanitize_exception(exc, generic='permission denied or path invalid')}\n"
                "Check that the directory exists and is writable.",
            ) from exc
        raise WorthlessError(
            ErrorCode.BOOTSTRAP_FAILED,
            sanitize_exception(exc, generic="failed to initialise home directory"),
        ) from exc

    # Initialise database (idempotent — CREATE TABLE IF NOT EXISTS)
    try:
        _init_db(home)
    except (OSError, sqlite3.DatabaseError) as exc:
        raise WorthlessError(
            ErrorCode.SHARD_STORAGE_FAILED,
            sanitize_exception(exc, generic="failed to initialise database"),
        ) from exc

    return home


def _init_db(home: WorthlessHome) -> None:
    """Create the SQLite database using the canonical schema and run migrations."""
    import asyncio

    from worthless.storage.schema import SCHEMA, migrate_db

    conn = sqlite3.connect(str(home.db_path))
    try:
        conn.execute("PRAGMA foreign_keys = ON")

        # Run forward-only migrations BEFORE the full schema so that
        # upgraded installs whose enrollments table pre-dates the
        # decoy_hash column get it added before CREATE INDEX touches it.
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        }
        if "enrollments" in tables:
            cursor = conn.execute("PRAGMA table_info(enrollments)")
            columns = {row[1] for row in cursor.fetchall()}
            if "decoy_hash" not in columns:
                try:
                    conn.execute("ALTER TABLE enrollments ADD COLUMN decoy_hash TEXT")
                    conn.commit()
                except sqlite3.OperationalError as exc:
                    if "duplicate column" not in str(exc).lower():
                        raise

        conn.executescript(SCHEMA)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.commit()
    finally:
        conn.close()

    # Run async migrations (WOR-183: rules engine columns, spend_log cleanup)
    try:
        asyncio.get_running_loop()
        # Already in async context — schedule as a task won't work from sync.
        # Use a new thread's event loop instead.
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            pool.submit(asyncio.run, migrate_db(str(home.db_path))).result()
    except RuntimeError:
        # No running loop — safe to use asyncio.run()
        asyncio.run(migrate_db(str(home.db_path)))

    # Restrict DB file permissions (no-op on Windows — NTFS ACLs are different)
    if not IS_WINDOWS:
        home.db_path.chmod(0o600)


@contextmanager
def acquire_lock(home: WorthlessHome) -> Generator[None, None, None]:
    """Acquire an exclusive lock file using O_CREAT|O_EXCL."""
    check_stale_lock(home)
    try:
        fd = os.open(
            str(home.lock_file),
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
            0o600,
        )
        os.close(fd)
    except FileExistsError:
        raise WorthlessError(
            ErrorCode.LOCK_IN_PROGRESS,
            "Another worthless operation is in progress. "
            "Remove ~/.worthless/.lock-in-progress if stale.",
        ) from None  # FileExistsError context is not useful to callers
    try:
        yield
    finally:
        try:
            home.lock_file.unlink()
        except FileNotFoundError:
            pass


def get_home() -> WorthlessHome:
    """Resolve WorthlessHome from WORTHLESS_HOME env var or default."""
    env_home = os.environ.get("WORTHLESS_HOME")
    if env_home:
        return ensure_home(Path(env_home))
    return ensure_home()


def resolve_home() -> WorthlessHome | None:
    """Try to load WorthlessHome; return None if not initialized."""
    try:
        env_home = os.environ.get("WORTHLESS_HOME")
        if env_home:
            base = Path(env_home)
            if base.exists():
                return ensure_home(base)
            return None
        default = Path.home() / ".worthless"
        if default.exists():
            return ensure_home(default)
        return None
    except Exception:
        return None


def check_stale_lock(home: WorthlessHome) -> None:
    """Remove stale lock files (> 5 min old), raise on fresh locks."""
    if not home.lock_file.exists():
        return
    age = time.time() - home.lock_file.stat().st_mtime
    if age > _STALE_LOCK_SECONDS:
        home.lock_file.unlink(missing_ok=True)
    else:
        raise WorthlessError(
            ErrorCode.LOCK_IN_PROGRESS,
            f"Lock file is {int(age)}s old (< {_STALE_LOCK_SECONDS}s). "
            "Another operation may be running.",
        )
