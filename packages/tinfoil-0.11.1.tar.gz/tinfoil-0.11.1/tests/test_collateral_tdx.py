"""
Unit tests for TDX collateral fetching and TCB validation.
"""

import json
import pytest
from datetime import datetime, timezone, timedelta
from unittest.mock import patch, MagicMock

from tinfoil.attestation.collateral_tdx import (
    TcbStatus,
    TcbComponent,
    Tcb,
    TcbLevel,
    TcbInfo,
    TdxTcbInfo,
    TdxModuleIdentity,
    EnclaveIdentity,
    QeIdentity,
    TdxCollateral,
    CollateralError,
    parse_tcb_info_response,
    parse_qe_identity_response,
    is_cpu_svn_higher_or_equal,
    is_tdx_tcb_svn_higher_or_equal,
    get_matching_tcb_level,
    get_matching_qe_tcb_level,
    get_tdx_module_identity,
    validate_tcb_status,
    validate_tdx_module_identity,
    validate_qe_identity,
    check_collateral_freshness,
    fetch_tcb_info,
    fetch_qe_identity,
    _parse_datetime,
    _parse_issuer_chain_header,
    _verify_collateral_signature,
    _parse_hex_bytes,
    _get_tcb_info_cache_path,
    _get_qe_identity_cache_path,
    _is_tcb_info_fresh,
    _is_qe_identity_fresh,
    _read_cache,
    _write_cache,
)
from tinfoil.attestation.pck_extensions import PckExtensions, PckCertTCB


# =============================================================================
# Sample Data - Based on Real Intel PCS Responses
# =============================================================================

SAMPLE_TCB_INFO_JSON = """
{
  "tcbInfo": {
    "id": "TDX",
    "version": 3,
    "issueDate": "2025-12-17T06:24:56Z",
    "nextUpdate": "2026-01-16T06:24:56Z",
    "fmspc": "90c06f000000",
    "pceId": "0000",
    "tcbType": 0,
    "tcbEvaluationDataNumber": 19,
    "tdxModule": {
      "mrsigner": "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
      "attributes": "0000000000000000",
      "attributesMask": "FFFFFFFFFFFFFFFF"
    },
    "tdxModuleIdentities": [
      {
        "id": "TDX_03",
        "mrsigner": "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
        "attributes": "0000000000000000",
        "attributesMask": "FFFFFFFFFFFFFFFF",
        "tcbLevels": [
          {
            "tcb": { "isvsvn": 3 },
            "tcbDate": "2024-11-13T00:00:00Z",
            "tcbStatus": "UpToDate"
          }
        ]
      }
    ],
    "tcbLevels": [
      {
        "tcb": {
          "sgxtcbcomponents": [
            {"svn": 3}, {"svn": 3}, {"svn": 2}, {"svn": 2},
            {"svn": 2}, {"svn": 1}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0}
          ],
          "pcesvn": 13,
          "tdxtcbcomponents": [
            {"svn": 5, "category": "TDX Module", "type": "TDX Module"},
            {"svn": 0}, {"svn": 3}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0}
          ]
        },
        "tcbDate": "2024-11-13T00:00:00Z",
        "tcbStatus": "UpToDate"
      },
      {
        "tcb": {
          "sgxtcbcomponents": [
            {"svn": 2}, {"svn": 2}, {"svn": 2}, {"svn": 2},
            {"svn": 2}, {"svn": 1}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0}
          ],
          "pcesvn": 11,
          "tdxtcbcomponents": [
            {"svn": 4}, {"svn": 0}, {"svn": 2}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0},
            {"svn": 0}, {"svn": 0}, {"svn": 0}, {"svn": 0}
          ]
        },
        "tcbDate": "2024-03-13T00:00:00Z",
        "tcbStatus": "OutOfDate"
      }
    ]
  },
  "signature": "abcd1234"
}
"""

SAMPLE_QE_IDENTITY_JSON = """
{
  "enclaveIdentity": {
    "id": "TD_QE",
    "version": 2,
    "issueDate": "2025-12-17T18:48:11Z",
    "nextUpdate": "2026-01-16T18:48:11Z",
    "tcbEvaluationDataNumber": 19,
    "miscselect": "00000000",
    "miscselectMask": "FFFFFFFF",
    "attributes": "11000000000000000000000000000000",
    "attributesMask": "FBFFFFFFFFFFFFFF0000000000000000",
    "mrsigner": "DC9E2A7C6F948F17474E34A7FC43ED030F7C1563F1BABDDF6340C82E0E54A8C5",
    "isvprodid": 2,
    "tcbLevels": [
      {
        "tcb": { "isvsvn": 4 },
        "tcbDate": "2024-11-13T00:00:00Z",
        "tcbStatus": "UpToDate"
      },
      {
        "tcb": { "isvsvn": 3 },
        "tcbDate": "2024-03-13T00:00:00Z",
        "tcbStatus": "OutOfDate"
      }
    ]
  },
  "signature": "0665a932"
}
"""

# Byte versions for cache testing
SAMPLE_TCB_INFO_RESPONSE = SAMPLE_TCB_INFO_JSON.encode()
SAMPLE_QE_IDENTITY_RESPONSE = SAMPLE_QE_IDENTITY_JSON.encode()

# Stale TCB Info (next_update in the past)
SAMPLE_STALE_TCB_INFO_JSON = """
{
  "tcbInfo": {
    "id": "TDX",
    "version": 3,
    "issueDate": "2024-01-17T06:24:56Z",
    "nextUpdate": "2024-02-16T06:24:56Z",
    "fmspc": "90c06f000000",
    "pceId": "0000",
    "tcbType": 0,
    "tcbEvaluationDataNumber": 19,
    "tdxModuleIdentities": [],
    "tcbLevels": []
  },
  "signature": "stale1234"
}
"""
SAMPLE_STALE_TCB_INFO_RESPONSE = SAMPLE_STALE_TCB_INFO_JSON.encode()


# =============================================================================
# Helper Functions
# =============================================================================

def create_sample_pck_extensions() -> PckExtensions:
    """Create sample PCK extensions for testing."""
    return PckExtensions(
        ppid="00" * 16,
        tcb=PckCertTCB(
            pce_svn=13,
            cpu_svn=bytes([3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            tcb_components=[3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        ),
        pceid="0000",
        fmspc="90c06f000000",
    )


# =============================================================================
# Parsing Tests
# =============================================================================

class TestParseTcbInfoResponse:
    """Test TCB Info parsing."""

    def test_parse_valid_response(self):
        """Test parsing a valid TCB Info response."""
        result = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        assert result.tcb_info.id == "TDX"
        assert result.tcb_info.version == 3
        assert result.tcb_info.fmspc == "90c06f000000"
        assert len(result.tcb_info.tcb_levels) == 2
        assert result.signature == "abcd1234"

    def test_parse_tcb_levels(self):
        """Test that TCB levels are parsed correctly."""
        result = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        first_level = result.tcb_info.tcb_levels[0]
        assert first_level.tcb_status == TcbStatus.UP_TO_DATE
        assert first_level.tcb.pce_svn == 13
        assert len(first_level.tcb.sgx_tcb_components) == 16
        assert first_level.tcb.sgx_tcb_components[0].svn == 3

    def test_parse_tdx_module_identities(self):
        """Test that TDX module identities are parsed."""
        result = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        assert len(result.tcb_info.tdx_module_identities) == 1
        identity = result.tcb_info.tdx_module_identities[0]
        assert identity.id == "TDX_03"

    def test_reject_wrong_id(self):
        """Test that non-TDX ID is rejected."""
        bad_json = SAMPLE_TCB_INFO_JSON.replace('"id": "TDX"', '"id": "SGX"')
        with pytest.raises(CollateralError, match="must be 'TDX'"):
            parse_tcb_info_response(bad_json.encode())

    def test_reject_wrong_version(self):
        """Test that wrong version is rejected."""
        bad_json = SAMPLE_TCB_INFO_JSON.replace('"version": 3', '"version": 2')
        with pytest.raises(CollateralError, match="must be 3"):
            parse_tcb_info_response(bad_json.encode())


class TestParseQeIdentityResponse:
    """Test QE Identity parsing."""

    def test_parse_valid_response(self):
        """Test parsing a valid QE Identity response."""
        result = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        assert result.enclave_identity.id == "TD_QE"
        assert result.enclave_identity.version == 2
        assert result.enclave_identity.isv_prod_id == 2
        assert len(result.enclave_identity.tcb_levels) == 2

    def test_parse_mrsigner(self):
        """Test MRSIGNER is parsed correctly."""
        result = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        expected = bytes.fromhex(
            "DC9E2A7C6F948F17474E34A7FC43ED030F7C1563F1BABDDF6340C82E0E54A8C5"
        )
        assert result.enclave_identity.mrsigner == expected

    def test_reject_wrong_id(self):
        """Test that non-TD_QE ID is rejected."""
        bad_json = SAMPLE_QE_IDENTITY_JSON.replace('"id": "TD_QE"', '"id": "QE"')
        with pytest.raises(CollateralError, match="must be 'TD_QE'"):
            parse_qe_identity_response(bad_json.encode())


# =============================================================================
# TCB Comparison Tests
# =============================================================================

class TestIsCpuSvnHigherOrEqual:
    """Test CPU SVN comparison."""

    def test_equal_values(self):
        """Test equal SVN values pass."""
        cpu_svn = bytes([3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        components = [TcbComponent(svn=3), TcbComponent(svn=3), TcbComponent(svn=2),
                      TcbComponent(svn=2), TcbComponent(svn=2), TcbComponent(svn=1),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_cpu_svn_higher_or_equal(cpu_svn, components) is True

    def test_higher_values(self):
        """Test higher SVN values pass."""
        cpu_svn = bytes([4, 4, 3, 3, 3, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
        components = [TcbComponent(svn=3), TcbComponent(svn=3), TcbComponent(svn=2),
                      TcbComponent(svn=2), TcbComponent(svn=2), TcbComponent(svn=1),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_cpu_svn_higher_or_equal(cpu_svn, components) is True

    def test_lower_first_component(self):
        """Test lower first component fails."""
        cpu_svn = bytes([2, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        components = [TcbComponent(svn=3), TcbComponent(svn=3), TcbComponent(svn=2),
                      TcbComponent(svn=2), TcbComponent(svn=2), TcbComponent(svn=1),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_cpu_svn_higher_or_equal(cpu_svn, components) is False

    def test_wrong_length(self):
        """Test wrong length fails."""
        cpu_svn = bytes([3, 3, 2])  # Only 3 bytes
        components = [TcbComponent(svn=3)] * 16

        assert is_cpu_svn_higher_or_equal(cpu_svn, components) is False


class TestIsTdxTcbSvnHigherOrEqual:
    """Test TDX TCB SVN comparison."""

    def test_equal_values(self):
        """Test equal SVN values pass."""
        tee_tcb_svn = bytes([5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        components = [TcbComponent(svn=5), TcbComponent(svn=0), TcbComponent(svn=3),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_tdx_tcb_svn_higher_or_equal(tee_tcb_svn, components) is True

    def test_skip_first_two_when_module_version_set(self):
        """Test that first 2 bytes are skipped when tee_tcb_svn[1] > 0."""
        # tee_tcb_svn[1] = 1, so first 2 bytes should be skipped
        tee_tcb_svn = bytes([0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        # Components have higher values in first 2 positions, but should be skipped
        components = [TcbComponent(svn=99), TcbComponent(svn=99), TcbComponent(svn=3),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_tdx_tcb_svn_higher_or_equal(tee_tcb_svn, components) is True

    def test_lower_value_fails(self):
        """Test lower SVN value fails."""
        tee_tcb_svn = bytes([5, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        components = [TcbComponent(svn=5), TcbComponent(svn=0), TcbComponent(svn=3),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0), TcbComponent(svn=0), TcbComponent(svn=0),
                      TcbComponent(svn=0)]

        assert is_tdx_tcb_svn_higher_or_equal(tee_tcb_svn, components) is False


class TestGetMatchingTcbLevel:
    """Test TCB level matching."""

    def test_find_matching_level(self):
        """Test finding a matching TCB level."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        tee_tcb_svn = bytes([5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        pce_svn = 13
        cpu_svn = bytes([3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

        result = get_matching_tcb_level(
            tcb_info.tcb_info.tcb_levels,
            tee_tcb_svn,
            pce_svn,
            cpu_svn,
        )

        assert result is not None
        assert result.tcb_status == TcbStatus.UP_TO_DATE

    def test_no_matching_level(self):
        """Test no matching level found."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        # Very low SVN values - won't match any level
        tee_tcb_svn = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        pce_svn = 1
        cpu_svn = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

        result = get_matching_tcb_level(
            tcb_info.tcb_info.tcb_levels,
            tee_tcb_svn,
            pce_svn,
            cpu_svn,
        )

        assert result is None


class TestGetMatchingQeTcbLevel:
    """Test QE TCB level matching with isvsvn."""

    def test_find_matching_level(self):
        """Test finding a matching QE TCB level by isvsvn."""
        tcb_levels = [
            TcbLevel(
                tcb=Tcb(
                    sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                    pce_svn=0,
                    tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                    isv_svn=8,
                ),
                tcb_date="2024-01-01T00:00:00Z",
                tcb_status=TcbStatus.UP_TO_DATE,
                advisory_ids=[],
            ),
            TcbLevel(
                tcb=Tcb(
                    sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                    pce_svn=0,
                    tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                    isv_svn=6,
                ),
                tcb_date="2023-06-01T00:00:00Z",
                tcb_status=TcbStatus.SW_HARDENING_NEEDED,
                advisory_ids=["INTEL-SA-00001"],
            ),
        ]

        # ISV SVN 8 should match first level (equal)
        result = get_matching_qe_tcb_level(tcb_levels, 8)
        assert result is not None
        assert result.tcb_status == TcbStatus.UP_TO_DATE

        # ISV SVN 10 should also match first level (>= 8)
        result = get_matching_qe_tcb_level(tcb_levels, 10)
        assert result is not None
        assert result.tcb_status == TcbStatus.UP_TO_DATE

        # ISV SVN 7 should match second level (>= 6 but < 8)
        result = get_matching_qe_tcb_level(tcb_levels, 7)
        assert result is not None
        assert result.tcb_status == TcbStatus.SW_HARDENING_NEEDED

    def test_no_matching_level(self):
        """Test no matching QE TCB level when isvsvn too low."""
        tcb_levels = [
            TcbLevel(
                tcb=Tcb(
                    sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                    pce_svn=0,
                    tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                    isv_svn=8,
                ),
                tcb_date="2024-01-01T00:00:00Z",
                tcb_status=TcbStatus.UP_TO_DATE,
                advisory_ids=[],
            ),
        ]

        # ISV SVN 5 is less than 8, so no match
        result = get_matching_qe_tcb_level(tcb_levels, 5)
        assert result is None

    def test_empty_levels(self):
        """Test empty TCB levels list."""
        result = get_matching_qe_tcb_level([], 8)
        assert result is None

    def test_level_without_isv_svn(self):
        """Test TCB level without isv_svn field is skipped."""
        tcb_levels = [
            TcbLevel(
                tcb=Tcb(
                    sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                    pce_svn=0,
                    tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                    isv_svn=None,  # No isv_svn set
                ),
                tcb_date="2024-01-01T00:00:00Z",
                tcb_status=TcbStatus.UP_TO_DATE,
                advisory_ids=[],
            ),
        ]

        result = get_matching_qe_tcb_level(tcb_levels, 8)
        assert result is None


# =============================================================================
# Validation Tests
# =============================================================================

class TestValidateTcbStatus:
    """Test TCB status validation."""

    def test_up_to_date_passes(self):
        """Test UpToDate status passes."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        pck_ext = create_sample_pck_extensions()
        tee_tcb_svn = bytes([5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

        result = validate_tcb_status(
            tcb_info.tcb_info,
            tee_tcb_svn,
            pck_ext,
        )

        assert result.tcb_status == TcbStatus.UP_TO_DATE

    def test_no_matching_level_fails(self):
        """Test that no matching level raises error."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        # Create extensions with very low SVN values
        pck_ext = PckExtensions(
            ppid="00" * 16,
            tcb=PckCertTCB(
                pce_svn=1,
                cpu_svn=bytes(16),
                tcb_components=[0] * 16,
            ),
            pceid="0000",
            fmspc="90c06f000000",
        )
        tee_tcb_svn = bytes(16)

        with pytest.raises(CollateralError, match="No matching TCB level"):
            validate_tcb_status(tcb_info.tcb_info, tee_tcb_svn, pck_ext)

    def test_fmspc_mismatch_fails(self):
        """Test that FMSPC mismatch raises error."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        # Create extensions with different FMSPC
        pck_ext = PckExtensions(
            ppid="00" * 16,
            tcb=PckCertTCB(
                pce_svn=13,
                cpu_svn=bytes([3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
                tcb_components=[3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ),
            pceid="0000",
            fmspc="aabbcc000000",  # Different FMSPC
        )
        tee_tcb_svn = bytes([5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

        with pytest.raises(CollateralError, match="FMSPC mismatch"):
            validate_tcb_status(tcb_info.tcb_info, tee_tcb_svn, pck_ext)

    def test_pceid_mismatch_fails(self):
        """Test that PCE_ID mismatch raises error."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())

        # Create extensions with different PCE_ID
        pck_ext = PckExtensions(
            ppid="00" * 16,
            tcb=PckCertTCB(
                pce_svn=13,
                cpu_svn=bytes([3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
                tcb_components=[3, 3, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ),
            pceid="1234",  # Different PCE_ID
            fmspc="90c06f000000",
        )
        tee_tcb_svn = bytes([5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

        with pytest.raises(CollateralError, match="PCE_ID mismatch"):
            validate_tcb_status(tcb_info.tcb_info, tee_tcb_svn, pck_ext)


class TestValidateQeIdentity:
    """Test QE identity validation."""

    def _create_qe_identity(self) -> EnclaveIdentity:
        """Create a sample QE Identity for testing."""
        return EnclaveIdentity(
            id="TD_QE",
            version=2,
            issue_date=datetime.now(timezone.utc),
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
            tcb_evaluation_data_number=17,
            miscselect=b"\x00\x00\x00\x00",
            miscselect_mask=b"\xff\xff\xff\xff",
            attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
            attributes_mask=b"\xfb\xff\xff\xff\xff\xff\xff\xff\x00\x00\x00\x00\x00\x00\x00\x00",
            mrsigner=b"\xdc" * 32,
            isv_prod_id=1,
            tcb_levels=[
                TcbLevel(
                    tcb=Tcb(
                        sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                        pce_svn=0,
                        tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                        isv_svn=8,
                    ),
                    tcb_date="2024-01-01T00:00:00Z",
                    tcb_status=TcbStatus.UP_TO_DATE,
                    advisory_ids=[],
                ),
            ],
        )

    def test_valid_qe_identity(self):
        """Test validation passes with matching QE identity."""
        qe_identity = self._create_qe_identity()
        result = validate_qe_identity(
            qe_identity=qe_identity,
            qe_report_isv_svn=8,
            qe_report_mrsigner=b"\xdc" * 32,
            qe_report_miscselect=b"\x00\x00\x00\x00",
            qe_report_attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
            qe_report_isvprodid=1,
        )
        assert result.tcb_status == TcbStatus.UP_TO_DATE

    def test_mrsigner_mismatch(self):
        """Test validation fails with MRSIGNER mismatch."""
        qe_identity = self._create_qe_identity()
        with pytest.raises(CollateralError, match="MRSIGNER does not match"):
            validate_qe_identity(
                qe_identity=qe_identity,
                qe_report_isv_svn=8,
                qe_report_mrsigner=b"\xaa" * 32,  # Wrong MRSIGNER
                qe_report_miscselect=b"\x00\x00\x00\x00",
                qe_report_attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
                qe_report_isvprodid=1,
            )

    def test_miscselect_mismatch(self):
        """Test validation fails with MISCSELECT mismatch under mask."""
        qe_identity = self._create_qe_identity()
        with pytest.raises(CollateralError, match="MISCSELECT does not match"):
            validate_qe_identity(
                qe_identity=qe_identity,
                qe_report_isv_svn=8,
                qe_report_mrsigner=b"\xdc" * 32,
                qe_report_miscselect=b"\x01\x00\x00\x00",  # Wrong MISCSELECT
                qe_report_attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
                qe_report_isvprodid=1,
            )

    def test_attributes_mismatch(self):
        """Test validation fails with Attributes mismatch under mask."""
        qe_identity = self._create_qe_identity()
        with pytest.raises(CollateralError, match="Attributes do not match"):
            validate_qe_identity(
                qe_identity=qe_identity,
                qe_report_isv_svn=8,
                qe_report_mrsigner=b"\xdc" * 32,
                qe_report_miscselect=b"\x00\x00\x00\x00",
                qe_report_attributes=b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",  # Wrong
                qe_report_isvprodid=1,
            )

    def test_isvprodid_mismatch(self):
        """Test validation fails with ISV ProdID mismatch."""
        qe_identity = self._create_qe_identity()
        with pytest.raises(CollateralError, match="ISV ProdID does not match"):
            validate_qe_identity(
                qe_identity=qe_identity,
                qe_report_isv_svn=8,
                qe_report_mrsigner=b"\xdc" * 32,
                qe_report_miscselect=b"\x00\x00\x00\x00",
                qe_report_attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
                qe_report_isvprodid=2,  # Wrong ISV ProdID
            )

    def test_isv_svn_too_low(self):
        """Test validation fails when ISV SVN is too low."""
        qe_identity = self._create_qe_identity()
        with pytest.raises(CollateralError, match="No matching QE TCB level"):
            validate_qe_identity(
                qe_identity=qe_identity,
                qe_report_isv_svn=5,  # Below required 8
                qe_report_mrsigner=b"\xdc" * 32,
                qe_report_miscselect=b"\x00\x00\x00\x00",
                qe_report_attributes=b"\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
                qe_report_isvprodid=1,
            )


class TestTdxModuleIdentity:
    """Test TDX module identity validation."""

    def _create_tcb_info_with_module_identities(self) -> TcbInfo:
        """Create TCB Info with module identities for testing."""
        return TcbInfo(
            id="TDX",
            version=3,
            issue_date=datetime.now(timezone.utc),
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
            fmspc="00a06f000000",
            pce_id="0000",
            tcb_type=0,
            tcb_evaluation_data_number=17,
            tdx_module=None,
            tdx_module_identities=[
                TdxModuleIdentity(
                    id="TDX_03",
                    mrsigner=b"\xaa" * 48,
                    attributes=b"\x00\x00\x00\x00\x00\x00\x00\x00",
                    attributes_mask=b"\xff\xff\xff\xff\xff\xff\xff\xff",
                    tcb_levels=[
                        TcbLevel(
                            tcb=Tcb(
                                sgx_tcb_components=[TcbComponent(svn=0)] * 16,
                                pce_svn=0,
                                tdx_tcb_components=[TcbComponent(svn=0)] * 16,
                                isv_svn=3,  # Minor version 3
                            ),
                            tcb_date="2024-01-01T00:00:00Z",
                            tcb_status=TcbStatus.UP_TO_DATE,
                            advisory_ids=[],
                        ),
                    ],
                ),
            ],
            tcb_levels=[],
        )

    def test_get_module_identity(self):
        """Test finding module identity by TEE_TCB_SVN."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        # Major version 3 should match TDX_03
        tee_tcb_svn = bytes([5, 3] + [0] * 14)  # minor=5, major=3
        result = get_tdx_module_identity(tcb_info, tee_tcb_svn)
        assert result is not None
        assert result.id == "TDX_03"

    def test_get_module_identity_not_found(self):
        """Test unknown module version raises error."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        # Major version 5 should not match any (only TDX_03 exists)
        tee_tcb_svn = bytes([0, 5] + [0] * 14)  # minor=0, major=5
        with pytest.raises(CollateralError, match="Unknown TDX module version TDX_05"):
            get_tdx_module_identity(tcb_info, tee_tcb_svn)

    def test_validate_module_identity_success(self):
        """Test successful module identity validation."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        # minor=5 (used for TCB level matching), major=3 (used to find TDX_03)
        tee_tcb_svn = bytes([5, 3] + [0] * 14)
        mr_signer_seam = b"\xaa" * 48
        seam_attributes = b"\x00\x00\x00\x00\x00\x00\x00\x00"

        # Should not raise - validation succeeds
        validate_tdx_module_identity(
            tcb_info, tee_tcb_svn, mr_signer_seam, seam_attributes
        )

    def test_validate_module_identity_mrsigner_mismatch(self):
        """Test module identity validation fails with MR_SIGNER_SEAM mismatch."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        tee_tcb_svn = bytes([5, 3] + [0] * 14)  # minor=5, major=3
        mr_signer_seam = b"\xbb" * 48  # Wrong MR_SIGNER_SEAM
        seam_attributes = b"\x00\x00\x00\x00\x00\x00\x00\x00"

        with pytest.raises(CollateralError, match="MR_SIGNER_SEAM does not match"):
            validate_tdx_module_identity(
                tcb_info, tee_tcb_svn, mr_signer_seam, seam_attributes
            )

    def test_validate_module_identity_unknown_version_raises(self):
        """Test validation raises when module version is unknown."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        # Major version 5 doesn't exist in module identities (only TDX_03)
        tee_tcb_svn = bytes([0, 5] + [0] * 14)  # minor=0, major=5
        mr_signer_seam = b"\xaa" * 48
        seam_attributes = b"\x00\x00\x00\x00\x00\x00\x00\x00"

        with pytest.raises(CollateralError, match="Unknown TDX module version TDX_05"):
            validate_tdx_module_identity(
                tcb_info, tee_tcb_svn, mr_signer_seam, seam_attributes
            )

    def test_validate_module_identity_no_matching_tcb_level(self):
        """Test validation raises when minor version is too low for any TCB level."""
        tcb_info = self._create_tcb_info_with_module_identities()

        # TEE_TCB_SVN[0]=minor, TEE_TCB_SVN[1]=major
        # Module identity TDX_03 has TCB level with isv_svn=3
        # minor=2 < 3, so no TCB level should match
        tee_tcb_svn = bytes([2, 3] + [0] * 14)  # minor=2, major=3
        mr_signer_seam = b"\xaa" * 48
        seam_attributes = b"\x00\x00\x00\x00\x00\x00\x00\x00"

        with pytest.raises(CollateralError, match="Could not find a TDX Module Identity TCB Level"):
            validate_tdx_module_identity(
                tcb_info, tee_tcb_svn, mr_signer_seam, seam_attributes
            )


class TestCheckCollateralFreshness:
    """Test collateral freshness checking."""

    def test_fresh_collateral_passes(self):
        """Test fresh collateral passes."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
        )

        # Mock datetime to a time before sample data's nextUpdate (2026-01-16)
        mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
        with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
            mock_dt.now.return_value = mock_now
            mock_dt.fromisoformat = datetime.fromisoformat
            # Should not raise (sample has tcbEvaluationDataNumber=18)
            check_collateral_freshness(collateral, min_tcb_evaluation_data_number=18)

    def test_expired_tcb_info_fails(self):
        """Test expired TCB Info fails."""
        # Modify the sample to have an expired date
        expired_json = SAMPLE_TCB_INFO_JSON.replace(
            '"nextUpdate": "2026-01-16T06:24:56Z"',
            '"nextUpdate": "2020-01-16T06:24:56Z"'
        )
        tcb_info = parse_tcb_info_response(expired_json.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=expired_json.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
        )

        with pytest.raises(CollateralError, match="TCB Info has expired"):
            check_collateral_freshness(collateral, min_tcb_evaluation_data_number=18)

    def test_tcb_evaluation_data_number_threshold_passes(self):
        """Test collateral passes when tcbEvaluationDataNumber meets threshold."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
        )

        # Mock datetime to a time before sample data's nextUpdate (2026-01-16)
        mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
        with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
            mock_dt.now.return_value = mock_now
            mock_dt.fromisoformat = datetime.fromisoformat
            # Sample data has tcbEvaluationDataNumber=19, threshold of 19 should pass
            check_collateral_freshness(collateral, min_tcb_evaluation_data_number=19)

            # Lower threshold should also pass
            check_collateral_freshness(collateral, min_tcb_evaluation_data_number=10)

    def test_tcb_info_evaluation_data_number_below_threshold(self):
        """Test failure when TCB Info tcbEvaluationDataNumber is below threshold."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
        )

        # Mock datetime to a time before sample data's nextUpdate (2026-01-16)
        mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
        with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
            mock_dt.now.return_value = mock_now
            mock_dt.fromisoformat = datetime.fromisoformat
            # Sample data has tcbEvaluationDataNumber=19, threshold of 20 should fail
            with pytest.raises(CollateralError, match="TCB Info tcbEvaluationDataNumber .* is below"):
                check_collateral_freshness(collateral, min_tcb_evaluation_data_number=20)

    def test_qe_identity_evaluation_data_number_below_threshold(self):
        """Test failure when QE Identity tcbEvaluationDataNumber is below threshold."""
        # Create TCB Info with high tcbEvaluationDataNumber
        high_eval_tcb_json = SAMPLE_TCB_INFO_JSON.replace(
            '"tcbEvaluationDataNumber": 19',
            '"tcbEvaluationDataNumber": 25'
        )
        tcb_info = parse_tcb_info_response(high_eval_tcb_json.encode())
        # QE Identity still has tcbEvaluationDataNumber=19
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=high_eval_tcb_json.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
        )

        # Mock datetime to a time before sample data's nextUpdate (2026-01-16)
        mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
        with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
            mock_dt.now.return_value = mock_now
            mock_dt.fromisoformat = datetime.fromisoformat
            # TCB Info has 25, QE Identity has 19, threshold of 20 should fail on QE Identity
            with pytest.raises(CollateralError, match="QE Identity tcbEvaluationDataNumber .* is below"):
                check_collateral_freshness(collateral, min_tcb_evaluation_data_number=20)


# =============================================================================
# Helper Function Tests
# =============================================================================

class TestHelperFunctions:
    """Test helper functions."""

    def test_parse_datetime(self):
        """Test datetime parsing."""
        result = _parse_datetime("2025-12-17T06:24:56Z")
        assert result.year == 2025
        assert result.month == 12
        assert result.day == 17
        assert result.tzinfo is not None

    def test_parse_hex_bytes(self):
        """Test hex string parsing."""
        result = _parse_hex_bytes("aabbccdd")
        assert result == bytes([0xaa, 0xbb, 0xcc, 0xdd])


class TestTcbStatus:
    """Test TcbStatus enum."""

    def test_status_values(self):
        """Test all status values can be created."""
        assert TcbStatus.UP_TO_DATE == "UpToDate"
        assert TcbStatus.OUT_OF_DATE == "OutOfDate"
        assert TcbStatus.REVOKED == "Revoked"
        assert TcbStatus.SW_HARDENING_NEEDED == "SWHardeningNeeded"


# =============================================================================
# Caching Tests
# =============================================================================

class TestCacheHelpers:
    """Test cache helper functions."""

    def test_tcb_info_cache_path(self):
        """Test TCB Info cache path generation."""
        path = _get_tcb_info_cache_path("00A06D080000")
        assert "tdx_tcb_info_00a06d080000.json" in path
        # Should be lowercase
        path2 = _get_tcb_info_cache_path("00a06d080000")
        assert path == path2

    def test_qe_identity_cache_path(self):
        """Test QE Identity cache path generation."""
        path = _get_qe_identity_cache_path()
        assert "tdx_qe_identity.json" in path

    def test_is_tcb_info_fresh(self):
        """Test TCB Info freshness check."""
        # Fresh: next_update is in the future
        fresh_tcb_info = TdxTcbInfo(
            tcb_info=TcbInfo(
                id="TDX",
                version=3,
                issue_date=datetime.now(timezone.utc) - timedelta(days=1),
                next_update=datetime.now(timezone.utc) + timedelta(days=29),
                fmspc="00A06D080000",
                pce_id="0000",
                tcb_type=0,
                tcb_evaluation_data_number=1,
                tdx_module=None,
                tdx_module_identities=[],
                tcb_levels=[],
            ),
            signature="",
        )
        assert _is_tcb_info_fresh(fresh_tcb_info) is True

        # Stale: next_update is in the past
        stale_tcb_info = TdxTcbInfo(
            tcb_info=TcbInfo(
                id="TDX",
                version=3,
                issue_date=datetime.now(timezone.utc) - timedelta(days=31),
                next_update=datetime.now(timezone.utc) - timedelta(days=1),
                fmspc="00A06D080000",
                pce_id="0000",
                tcb_type=0,
                tcb_evaluation_data_number=1,
                tdx_module=None,
                tdx_module_identities=[],
                tcb_levels=[],
            ),
            signature="",
        )
        assert _is_tcb_info_fresh(stale_tcb_info) is False

    def test_is_qe_identity_fresh(self):
        """Test QE Identity freshness check."""
        # Fresh
        fresh_qe = QeIdentity(
            enclave_identity=EnclaveIdentity(
                id="TD_QE",
                version=2,
                issue_date=datetime.now(timezone.utc) - timedelta(days=1),
                next_update=datetime.now(timezone.utc) + timedelta(days=29),
                tcb_evaluation_data_number=1,
                miscselect=b"\x00" * 4,
                miscselect_mask=b"\xff" * 4,
                attributes=b"\x00" * 16,
                attributes_mask=b"\xff" * 16,
                mrsigner=b"\xaa" * 32,
                isv_prod_id=1,
                tcb_levels=[],
            ),
            signature="",
        )
        assert _is_qe_identity_fresh(fresh_qe) is True

        # Stale
        stale_qe = QeIdentity(
            enclave_identity=EnclaveIdentity(
                id="TD_QE",
                version=2,
                issue_date=datetime.now(timezone.utc) - timedelta(days=31),
                next_update=datetime.now(timezone.utc) - timedelta(days=1),
                tcb_evaluation_data_number=1,
                miscselect=b"\x00" * 4,
                miscselect_mask=b"\xff" * 4,
                attributes=b"\x00" * 16,
                attributes_mask=b"\xff" * 16,
                mrsigner=b"\xaa" * 32,
                isv_prod_id=1,
                tcb_levels=[],
            ),
            signature="",
        )
        assert _is_qe_identity_fresh(stale_qe) is False


class TestIssuerChainParsing:
    """Test issuer chain header parsing."""

    def test_parse_issuer_chain_missing_certs(self):
        """Test that parsing fails with too few certificates."""
        # Single certificate is not enough (need signing + root at minimum)
        single_cert_pem = """-----BEGIN CERTIFICATE-----
MIICjzCCAjSgAwIBAgIUImUM1lqdNInzg7SVUr9QGzknBqwwCgYIKoZIzj0EAwIw
aDEaMBgGA1UEAwwRSW50ZWwgU0dYIFJvb3QgQ0ExGjAYBgNVBAoMEUludGVsIENv
cnBvcmF0aW9uMRQwEgYDVQQHDAtTYW50YSBDbGFyYTELMAkGA1UECAwCQ0ExCzAJ
BgNVBAYTAlVTMB4XDTE4MDUyMTEwNDUxMFoXDTQ5MTIzMTIzNTk1OVowaDEaMBgG
A1UEAwwRSW50ZWwgU0dYIFJvb3QgQ0ExGjAYBgNVBAoMEUludGVsIENvcnBvcmF0
aW9uMRQwEgYDVQQHDAtTYW50YSBDbGFyYTELMAkGA1UECAwCQ0ExCzAJBgNVBAYT
AlVTMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEC6nEwMDIYZOj/iPWsCzaEKi7
1OiOSLRFhWGjbnBVJfVnkY4u3IjkDYYL0MxO4mqsyYjlBalTVYxFP2sJBK5zlKOB
uzCBuDAfBgNVHSMEGDAWgBQiZQzWWp00ifODtJVSv1AbOScGrDBSBgNVHR8ESzBJ
MEegRaBDhkFodHRwczovL2NlcnRpZmljYXRlcy50cnVzdGVkc2VydmljZXMuaW50
ZWwuY29tL0ludGVsU0dYUm9vdENBLmRlcjAdBgNVHQ4EFgQUImUM1lqdNInzg7SV
Ur9QGzknBqwwDgYDVR0PAQH/BAQDAgEGMBIGA1UdEwEB/wQIMAYBAf8CAQEwCgYI
KoZIzj0EAwIDSQAwRgIhAOW/5QkR+S9CiSDcNoowLuPRLsWGf/Yi7GSX94BgwTwg
AiEA4J0lrHoMs+Xo5o/sX6O9QWxHRAvZUGOdRQ7cvqRXaqI=
-----END CERTIFICATE-----"""
        with pytest.raises(CollateralError, match="at least 2 certificates"):
            _parse_issuer_chain_header(single_cert_pem)

    def test_parse_issuer_chain_invalid_pem(self):
        """Test that parsing fails with invalid PEM data."""
        with pytest.raises(CollateralError, match="Failed to parse"):
            _parse_issuer_chain_header("not-valid-pem-data")


class TestCollateralSignatureVerification:
    """Test collateral signature verification."""

    def test_verify_signature_missing_key(self):
        """Test that verification fails when JSON key is missing."""
        json_data = b'{"other": "data"}'
        with pytest.raises(CollateralError, match="does not contain"):
            _verify_collateral_signature(
                json_bytes=json_data,
                json_key="tcbInfo",
                signature_hex="00" * 64,
                signing_cert=MagicMock(),
                data_name="Test",
            )

    def test_verify_signature_invalid_hex(self):
        """Test that verification fails with invalid signature hex."""
        json_data = b'{"tcbInfo": {}}'
        with pytest.raises(CollateralError, match="not valid hex"):
            _verify_collateral_signature(
                json_bytes=json_data,
                json_key="tcbInfo",
                signature_hex="not-hex",
                signing_cert=MagicMock(),
                data_name="Test",
            )

    def test_verify_signature_wrong_length(self):
        """Test that verification fails with wrong signature length."""
        json_data = b'{"tcbInfo": {}}'
        with pytest.raises(CollateralError, match="expected 64"):
            _verify_collateral_signature(
                json_bytes=json_data,
                json_key="tcbInfo",
                signature_hex="00" * 32,  # 32 bytes instead of 64
                signing_cert=MagicMock(),
                data_name="Test",
            )


class TestFetchTcbInfoWithCache:
    """Test fetch_tcb_info caching behavior."""

    def test_cache_miss_fetches_from_network(self, tmp_path):
        """Test that cache miss triggers network fetch."""
        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                with patch('tinfoil.attestation.collateral_tdx.verify_tcb_info_signature'):
                    mock_response = MagicMock()
                    mock_response.content = SAMPLE_TCB_INFO_RESPONSE
                    mock_response.raise_for_status = MagicMock()
                    mock_response.headers = {"TCB-Info-Issuer-Chain": "dummy"}
                    mock_get.return_value = mock_response

                    # Also mock _parse_issuer_chain_header since we have dummy header
                    with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                        mock_parse.return_value = []

                        tcb_info, raw, _chain = fetch_tcb_info("00A06D080000")

                        mock_get.assert_called_once()
                        assert tcb_info.tcb_info.id == "TDX"

    def test_cache_hit_skips_network(self, tmp_path):
        """Test that fresh cache hit skips network fetch."""
        import base64
        import json as json_mod
        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            # Write fresh cache in the new JSON format with issuer chain
            cache_path = tmp_path / "tdx_tcb_info_00a06d080000.json"
            cache_data = {
                "body": base64.b64encode(SAMPLE_TCB_INFO_RESPONSE).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            # Mock datetime so sample data appears fresh (nextUpdate is 2026-01-16)
            mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_dt.now.return_value = mock_now
                mock_dt.fromisoformat = datetime.fromisoformat
                with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                    # Mock signature verification on cache hit
                    with patch('tinfoil.attestation.collateral_tdx.verify_tcb_info_signature'):
                        with patch('tinfoil.attestation.collateral_tdx.parse_pem_chain') as mock_pem:
                            mock_pem.return_value = []
                            tcb_info, raw, _chain = fetch_tcb_info("00A06D080000")

                            # Should not call network
                            mock_get.assert_not_called()
                            assert tcb_info.tcb_info.id == "TDX"

    def test_stale_cache_fetches_fresh(self, tmp_path):
        """Test that stale cache triggers fresh fetch."""
        import base64
        import json as json_mod
        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            # Write stale cache (expired next_update) in new JSON format
            cache_path = tmp_path / "tdx_tcb_info_00a06d080000.json"
            cache_data = {
                "body": base64.b64encode(SAMPLE_STALE_TCB_INFO_RESPONSE).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                with patch('tinfoil.attestation.collateral_tdx.verify_tcb_info_signature'):
                    mock_response = MagicMock()
                    mock_response.content = SAMPLE_TCB_INFO_RESPONSE
                    mock_response.raise_for_status = MagicMock()
                    mock_response.headers = {"TCB-Info-Issuer-Chain": "dummy"}
                    mock_get.return_value = mock_response

                    with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                        mock_parse.return_value = []

                        tcb_info, raw, _chain = fetch_tcb_info("00A06D080000")

                        # Should call network because cache is stale
                        mock_get.assert_called_once()

    def test_old_tcb_eval_number_cache_triggers_refetch(self, tmp_path):
        """Test that cached data with tcbEvaluationDataNumber below threshold triggers re-fetch."""
        import base64
        import json as json_mod
        old_json = SAMPLE_TCB_INFO_JSON.replace(
            '"tcbEvaluationDataNumber": 19',
            '"tcbEvaluationDataNumber": 17',
        )
        old_response = old_json.encode()

        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            cache_path = tmp_path / "tdx_tcb_info_00a06d080000.json"
            cache_data = {
                "body": base64.b64encode(old_response).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_dt.now.return_value = mock_now
                mock_dt.fromisoformat = datetime.fromisoformat
                with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                    with patch('tinfoil.attestation.collateral_tdx.verify_tcb_info_signature'):
                        mock_response = MagicMock()
                        mock_response.content = SAMPLE_TCB_INFO_RESPONSE
                        mock_response.raise_for_status = MagicMock()
                        mock_response.headers = {"TCB-Info-Issuer-Chain": "dummy"}
                        mock_get.return_value = mock_response

                        with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                            mock_parse.return_value = []
                            tcb_info, raw, _chain = fetch_tcb_info("00A06D080000")

                            mock_get.assert_called_once()
                            assert tcb_info.tcb_info.tcb_evaluation_data_number == 19


class TestFetchQeIdentityWithCache:
    """Test fetch_qe_identity caching behavior."""

    def test_cache_miss_fetches_from_network(self, tmp_path):
        """Test that cache miss triggers network fetch."""
        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                with patch('tinfoil.attestation.collateral_tdx.verify_qe_identity_signature'):
                    mock_response = MagicMock()
                    mock_response.content = SAMPLE_QE_IDENTITY_RESPONSE
                    mock_response.raise_for_status = MagicMock()
                    mock_response.headers = {"SGX-Enclave-Identity-Issuer-Chain": "dummy"}
                    mock_get.return_value = mock_response

                    with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                        mock_parse.return_value = []

                        qe_identity, raw, _chain = fetch_qe_identity()

                        mock_get.assert_called_once()
                        assert qe_identity.enclave_identity.id == "TD_QE"

    def test_cache_hit_skips_network(self, tmp_path):
        """Test that fresh cache hit skips network fetch."""
        import base64
        import json as json_mod
        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            # Write fresh cache in the new JSON format with issuer chain
            cache_path = tmp_path / "tdx_qe_identity.json"
            cache_data = {
                "body": base64.b64encode(SAMPLE_QE_IDENTITY_RESPONSE).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            # Mock datetime so sample data appears fresh (nextUpdate is 2026-01-16)
            mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_dt.now.return_value = mock_now
                mock_dt.fromisoformat = datetime.fromisoformat
                with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                    # Mock signature verification on cache hit
                    with patch('tinfoil.attestation.collateral_tdx.verify_qe_identity_signature'):
                        with patch('tinfoil.attestation.collateral_tdx.parse_pem_chain') as mock_pem:
                            mock_pem.return_value = []
                            qe_identity, raw, _chain = fetch_qe_identity()

                            # Should not call network
                            mock_get.assert_not_called()
                            assert qe_identity.enclave_identity.id == "TD_QE"

    def test_old_tcb_eval_number_cache_triggers_refetch(self, tmp_path):
        """Test that cached QE Identity with tcbEvaluationDataNumber below threshold triggers re-fetch."""
        import base64
        import json as json_mod
        old_json = SAMPLE_QE_IDENTITY_JSON.replace(
            '"tcbEvaluationDataNumber": 19',
            '"tcbEvaluationDataNumber": 17',
        )
        old_response = old_json.encode()

        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            cache_path = tmp_path / "tdx_qe_identity.json"
            cache_data = {
                "body": base64.b64encode(old_response).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            mock_now = datetime(2026, 1, 10, tzinfo=timezone.utc)
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_dt.now.return_value = mock_now
                mock_dt.fromisoformat = datetime.fromisoformat
                with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                    with patch('tinfoil.attestation.collateral_tdx.verify_qe_identity_signature'):
                        mock_response = MagicMock()
                        mock_response.content = SAMPLE_QE_IDENTITY_RESPONSE
                        mock_response.raise_for_status = MagicMock()
                        mock_response.headers = {"SGX-Enclave-Identity-Issuer-Chain": "dummy"}
                        mock_get.return_value = mock_response

                        with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                            mock_parse.return_value = []
                            qe_identity, raw, _chain = fetch_qe_identity()

                            mock_get.assert_called_once()
                            assert qe_identity.enclave_identity.tcb_evaluation_data_number == 19


# =============================================================================
# CRL Tests
# =============================================================================

from tinfoil.attestation.collateral_tdx import (
    PckCrl,
    _get_crl_cache_path,
    _is_crl_fresh,
    _determine_pck_ca_type,
    fetch_pck_crl,
    validate_certificate_revocation,
)
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec


class TestCrlCacheHelpers:
    """Test CRL cache helper functions."""

    def test_crl_cache_path_platform(self):
        """Test CRL cache path generation for platform CA."""
        path = _get_crl_cache_path("platform")
        assert "tdx_pck_crl_platform.json" in path

    def test_crl_cache_path_processor(self):
        """Test CRL cache path generation for processor CA."""
        path = _get_crl_cache_path("processor")
        assert "tdx_pck_crl_processor.json" in path

    def test_crl_cache_path_lowercase(self):
        """Test CRL cache path is lowercase."""
        path1 = _get_crl_cache_path("Platform")
        path2 = _get_crl_cache_path("platform")
        assert path1 == path2

    def test_is_crl_fresh_valid(self):
        """Test CRL freshness check with valid (not expired) CRL."""
        # Create a mock CRL with next_update in the future
        mock_crl = MagicMock()
        mock_crl.next_update_utc = datetime.now(timezone.utc) + timedelta(days=30)

        assert _is_crl_fresh(mock_crl) is True

    def test_is_crl_fresh_expired(self):
        """Test CRL freshness check with expired CRL."""
        mock_crl = MagicMock()
        mock_crl.next_update_utc = datetime.now(timezone.utc) - timedelta(days=1)

        assert _is_crl_fresh(mock_crl) is False

    def test_is_crl_fresh_no_next_update(self):
        """Test CRL freshness check with no next_update."""
        mock_crl = MagicMock()
        mock_crl.next_update_utc = None

        assert _is_crl_fresh(mock_crl) is False


class TestDeterminePckCaType:
    """Test PCK CA type determination from certificate issuer."""

    def _create_mock_cert_with_issuer(self, cn: str) -> MagicMock:
        """Create a mock certificate with given issuer CN."""
        mock_attr = MagicMock()
        mock_attr.oid = NameOID.COMMON_NAME
        mock_attr.value = cn

        mock_issuer = MagicMock()
        mock_issuer.__iter__ = MagicMock(return_value=iter([mock_attr]))

        mock_cert = MagicMock()
        mock_cert.issuer = mock_issuer

        return mock_cert

    def test_platform_ca(self):
        """Test detecting Platform CA from issuer CN."""
        mock_cert = self._create_mock_cert_with_issuer("Intel SGX PCK Platform CA")
        result = _determine_pck_ca_type(mock_cert)
        assert result == "platform"

    def test_processor_ca(self):
        """Test detecting Processor CA from issuer CN."""
        mock_cert = self._create_mock_cert_with_issuer("Intel SGX PCK Processor CA")
        result = _determine_pck_ca_type(mock_cert)
        assert result == "processor"

    def test_unknown_ca_raises_error(self):
        """Test that unknown CA type raises error."""
        mock_cert = self._create_mock_cert_with_issuer("Unknown CA")
        with pytest.raises(CollateralError, match="Could not determine PCK CA type"):
            _determine_pck_ca_type(mock_cert)


class TestFetchPckCrl:
    """Test fetch_pck_crl function."""

    def test_invalid_ca_type_raises_error(self):
        """Test that invalid CA type raises error."""
        with pytest.raises(CollateralError, match="Invalid CA type"):
            fetch_pck_crl("invalid")

    def test_cache_hit_skips_network(self, tmp_path):
        """Test that fresh cache hit skips network fetch."""
        import base64
        import json as json_mod
        # Create a mock CRL
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes
        from cryptography import x509
        from cryptography.x509 import CertificateRevocationListBuilder
        import datetime as dt_module

        # Generate a key for signing
        private_key = ec.generate_private_key(ec.SECP256R1())

        # Build a minimal CRL
        builder = CertificateRevocationListBuilder()
        builder = builder.issuer_name(x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "Test CA"),
        ]))
        builder = builder.last_update(dt_module.datetime.now(dt_module.timezone.utc))
        builder = builder.next_update(dt_module.datetime.now(dt_module.timezone.utc) + dt_module.timedelta(days=30))

        crl = builder.sign(private_key, hashes.SHA256())
        # Use PEM encoding - fetch_pck_crl expects PEM format
        crl_pem = crl.public_bytes(serialization.Encoding.PEM)

        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            # Write fresh CRL cache in new JSON format (body is PEM bytes)
            cache_path = tmp_path / "tdx_pck_crl_platform.json"
            cache_data = {
                "body": base64.b64encode(crl_pem).decode("ascii"),
                "issuer_chain_pem": "-----BEGIN CERTIFICATE-----\nfake\n-----END CERTIFICATE-----",
            }
            cache_path.write_text(json_mod.dumps(cache_data))

            with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                # Mock signature verification on cache hit
                with patch('tinfoil.attestation.collateral_tdx._verify_crl_signature'):
                    with patch('tinfoil.attestation.collateral_tdx.parse_pem_chain') as mock_pem:
                        mock_pem.return_value = []
                        result = fetch_pck_crl("platform")

                        # Should not call network
                        mock_get.assert_not_called()
                        assert result.ca_type == "platform"

    def test_cache_miss_fetches_from_network(self, tmp_path):
        """Test that cache miss triggers network fetch."""
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography import x509
        from cryptography.x509 import CertificateRevocationListBuilder
        import datetime as dt_module

        # Generate keys
        private_key = ec.generate_private_key(ec.SECP256R1())

        # Build a minimal CRL
        builder = CertificateRevocationListBuilder()
        builder = builder.issuer_name(x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "Test CA"),
        ]))
        builder = builder.last_update(dt_module.datetime.now(dt_module.timezone.utc))
        builder = builder.next_update(dt_module.datetime.now(dt_module.timezone.utc) + dt_module.timedelta(days=30))

        crl = builder.sign(private_key, hashes.SHA256())
        # Use PEM encoding - fetch_pck_crl expects PEM format from Intel PCS
        crl_pem = crl.public_bytes(serialization.Encoding.PEM)

        with patch('tinfoil.attestation.collateral_tdx._TDX_CACHE_DIR', str(tmp_path)):
            with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
                with patch('tinfoil.attestation.collateral_tdx._verify_crl_signature'):
                    with patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse:
                        mock_parse.return_value = []

                        mock_response = MagicMock()
                        mock_response.content = crl_pem
                        mock_response.raise_for_status = MagicMock()
                        mock_response.headers = {"SGX-PCK-CRL-Issuer-Chain": "dummy"}
                        mock_get.return_value = mock_response

                        result = fetch_pck_crl("platform")

                        mock_get.assert_called_once()
                        assert result.ca_type == "platform"


class TestValidateCertificateRevocation:
    """Test certificate revocation validation."""

    def _create_mock_crl(self, revoked_serials: list[int] = None) -> MagicMock:
        """Create a mock CRL with optional revoked serials."""
        mock_crl = MagicMock()
        mock_crl.next_update_utc = datetime.now(timezone.utc) + timedelta(days=30)

        def get_revoked(serial):
            if revoked_serials and serial in revoked_serials:
                revoked = MagicMock()
                revoked.revocation_date_utc = datetime.now(timezone.utc) - timedelta(days=1)
                return revoked
            return None

        mock_crl.get_revoked_certificate_by_serial_number = get_revoked
        return mock_crl

    def _create_mock_cert(self, serial: int) -> MagicMock:
        """Create a mock certificate with given serial number."""
        mock_cert = MagicMock()
        mock_cert.serial_number = serial
        return mock_cert

    def test_certificate_not_revoked(self):
        """Test that non-revoked certificate passes validation."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_crl = self._create_mock_crl(revoked_serials=[])
        pck_crl = PckCrl(
            crl=mock_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
        )

        mock_cert = self._create_mock_cert(serial=12345)

        # Should not raise
        validate_certificate_revocation(collateral, mock_cert)

    def test_certificate_revoked(self):
        """Test that revoked certificate fails validation."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_crl = self._create_mock_crl(revoked_serials=[12345])
        pck_crl = PckCrl(
            crl=mock_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
        )

        mock_cert = self._create_mock_cert(serial=12345)

        with pytest.raises(CollateralError, match="has been revoked"):
            validate_certificate_revocation(collateral, mock_cert)

    def test_no_crl_raises_error(self):
        """Test that missing CRL raises error."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=None,  # No CRL
        )

        mock_cert = self._create_mock_cert(serial=12345)

        with pytest.raises(CollateralError, match="CRL not available"):
            validate_certificate_revocation(collateral, mock_cert)

    def test_expired_crl_raises_error(self):
        """Test that expired CRL raises error."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_crl = MagicMock()
        mock_crl.next_update_utc = datetime.now(timezone.utc) - timedelta(days=1)  # Expired

        pck_crl = PckCrl(
            crl=mock_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) - timedelta(days=1),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
        )

        mock_cert = self._create_mock_cert(serial=12345)

        with pytest.raises(CollateralError, match="CRL has expired"):
            validate_certificate_revocation(collateral, mock_cert)

    def test_intermediate_cert_not_revoked(self):
        """Test that non-revoked intermediate CA certificate passes validation."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_pck_crl = self._create_mock_crl(revoked_serials=[])
        pck_crl = PckCrl(
            crl=mock_pck_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        mock_root_crl = self._create_mock_crl(revoked_serials=[])
        from tinfoil.attestation.collateral_tdx import RootCrl
        root_crl = RootCrl(
            crl=mock_root_crl,
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
            root_crl=root_crl,
        )

        mock_pck_cert = self._create_mock_cert(serial=12345)
        mock_intermediate_cert = self._create_mock_cert(serial=67890)

        # Should not raise
        validate_certificate_revocation(collateral, mock_pck_cert, mock_intermediate_cert)

    def test_intermediate_cert_revoked(self):
        """Test that revoked intermediate CA certificate fails validation."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_pck_crl = self._create_mock_crl(revoked_serials=[])
        pck_crl = PckCrl(
            crl=mock_pck_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        # Root CRL has the intermediate CA's serial as revoked
        mock_root_crl = self._create_mock_crl(revoked_serials=[67890])
        from tinfoil.attestation.collateral_tdx import RootCrl
        root_crl = RootCrl(
            crl=mock_root_crl,
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
            root_crl=root_crl,
        )

        mock_pck_cert = self._create_mock_cert(serial=12345)
        mock_intermediate_cert = self._create_mock_cert(serial=67890)

        with pytest.raises(CollateralError, match="Intermediate CA certificate has been revoked"):
            validate_certificate_revocation(collateral, mock_pck_cert, mock_intermediate_cert)

    def test_no_root_crl_with_intermediate_raises_error(self):
        """Test that missing root CRL raises error when checking intermediate."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_pck_crl = self._create_mock_crl(revoked_serials=[])
        pck_crl = PckCrl(
            crl=mock_pck_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
            root_crl=None,  # No root CRL
        )

        mock_pck_cert = self._create_mock_cert(serial=12345)
        mock_intermediate_cert = self._create_mock_cert(serial=67890)

        with pytest.raises(CollateralError, match="Root CRL not available"):
            validate_certificate_revocation(collateral, mock_pck_cert, mock_intermediate_cert)

    def test_expired_root_crl_raises_error(self):
        """Test that expired root CRL raises error when checking intermediate."""
        tcb_info = parse_tcb_info_response(SAMPLE_TCB_INFO_JSON.encode())
        qe_identity = parse_qe_identity_response(SAMPLE_QE_IDENTITY_JSON.encode())

        mock_pck_crl = self._create_mock_crl(revoked_serials=[])
        pck_crl = PckCrl(
            crl=mock_pck_crl,
            ca_type="platform",
            next_update=datetime.now(timezone.utc) + timedelta(days=30),
        )

        mock_root_crl = MagicMock()
        mock_root_crl.next_update_utc = datetime.now(timezone.utc) - timedelta(days=1)  # Expired
        from tinfoil.attestation.collateral_tdx import RootCrl
        root_crl = RootCrl(
            crl=mock_root_crl,
            next_update=datetime.now(timezone.utc) - timedelta(days=1),
        )

        collateral = TdxCollateral(
            tcb_info=tcb_info,
            qe_identity=qe_identity,
            tcb_info_raw=SAMPLE_TCB_INFO_JSON.encode(),
            qe_identity_raw=SAMPLE_QE_IDENTITY_JSON.encode(),
            pck_crl=pck_crl,
            root_crl=root_crl,
        )

        mock_pck_cert = self._create_mock_cert(serial=12345)
        mock_intermediate_cert = self._create_mock_cert(serial=67890)

        with pytest.raises(CollateralError, match="Root CA CRL has expired"):
            validate_certificate_revocation(collateral, mock_pck_cert, mock_intermediate_cert)


# =============================================================================
# TCB Evaluation Data Numbers Tests
# =============================================================================

from tinfoil.attestation.collateral_tdx import (
    TcbEvalNumber,
    TcbEvaluationDataNumbers,
    _parse_tcb_eval_numbers_response,
    fetch_tcb_evaluation_data_numbers,
    calculate_min_tcb_evaluation_data_number,
)


SAMPLE_TCB_EVAL_NUMBERS_RESPONSE = b'''{
  "tcbEvaluationDataNumbers": {
    "id": "TDX",
    "version": 1,
    "issueDate": "2026-01-15T19:17:02Z",
    "nextUpdate": "2026-02-14T19:17:02Z",
    "tcbEvalNumbers": [
      {"tcbEvaluationDataNumber": 20, "tcbRecoveryEventDate": "2025-08-12T00:00:00Z", "tcbDate": "2025-08-13T00:00:00Z"},
      {"tcbEvaluationDataNumber": 19, "tcbRecoveryEventDate": "2025-05-13T00:00:00Z", "tcbDate": "2025-05-14T00:00:00Z"},
      {"tcbEvaluationDataNumber": 18, "tcbRecoveryEventDate": "2024-11-12T00:00:00Z", "tcbDate": "2024-11-13T00:00:00Z"},
      {"tcbEvaluationDataNumber": 17, "tcbRecoveryEventDate": "2024-03-12T00:00:00Z", "tcbDate": "2024-03-13T00:00:00Z"},
      {"tcbEvaluationDataNumber": 16, "tcbRecoveryEventDate": "2023-08-08T00:00:00Z", "tcbDate": "2023-08-09T00:00:00Z"}
    ]
  },
  "signature": "dummy"
}'''


class TestParseTcbEvalNumbersResponse:
    """Test parsing of tcbevaluationdatanumbers response."""

    def test_parse_valid_response(self):
        """Test parsing a valid response."""
        result = _parse_tcb_eval_numbers_response(SAMPLE_TCB_EVAL_NUMBERS_RESPONSE)

        assert result.id == "TDX"
        assert result.version == 1
        assert len(result.tcb_eval_numbers) == 5
        assert result.tcb_eval_numbers[0].tcb_evaluation_data_number == 20
        assert result.tcb_eval_numbers[4].tcb_evaluation_data_number == 16

    def test_parse_dates(self):
        """Test that dates are parsed correctly."""
        result = _parse_tcb_eval_numbers_response(SAMPLE_TCB_EVAL_NUMBERS_RESPONSE)

        # Check first entry
        assert result.tcb_eval_numbers[0].tcb_recovery_event_date.year == 2025
        assert result.tcb_eval_numbers[0].tcb_recovery_event_date.month == 8
        assert result.tcb_eval_numbers[0].tcb_recovery_event_date.day == 12

    def test_parse_invalid_json(self):
        """Test that invalid JSON raises error."""
        with pytest.raises(CollateralError, match="Failed to parse"):
            _parse_tcb_eval_numbers_response(b"not json")


class TestFetchTcbEvaluationDataNumbers:
    """Test fetching TCB evaluation data numbers."""

    def test_fetch_success(self):
        """Test successful fetch with signature verification mocked out."""
        with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get, \
             patch('tinfoil.attestation.collateral_tdx._parse_issuer_chain_header') as mock_parse, \
             patch('tinfoil.attestation.collateral_tdx.verify_tcb_eval_numbers_signature'):
            mock_response = MagicMock()
            mock_response.content = SAMPLE_TCB_EVAL_NUMBERS_RESPONSE
            mock_response.raise_for_status = MagicMock()
            mock_response.headers = {"TCB-Evaluation-Data-Numbers-Issuer-Chain": "dummy-chain"}
            mock_get.return_value = mock_response
            mock_parse.return_value = []

            result = fetch_tcb_evaluation_data_numbers()

            mock_get.assert_called_once()
            assert result.id == "TDX"

    def test_fetch_missing_issuer_chain_header(self):
        """Test that missing issuer chain header raises error."""
        with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
            mock_response = MagicMock()
            mock_response.content = SAMPLE_TCB_EVAL_NUMBERS_RESPONSE
            mock_response.raise_for_status = MagicMock()
            mock_response.headers = {}
            mock_get.return_value = mock_response

            with pytest.raises(CollateralError, match="missing TCB-Evaluation-Data-Numbers-Issuer-Chain"):
                fetch_tcb_evaluation_data_numbers()

    def test_fetch_failure(self):
        """Test fetch failure raises error."""
        import requests as req
        with patch('tinfoil.attestation.collateral_tdx.requests.get') as mock_get:
            mock_get.side_effect = req.RequestException("Network error")

            with pytest.raises(CollateralError, match="HTTP GET"):
                fetch_tcb_evaluation_data_numbers()


class TestCalculateMinTcbEvaluationDataNumber:
    """Test calculate_min_tcb_evaluation_data_number function."""

    def test_calculate_with_recent_cutoff(self):
        """Test calculation finds correct minimum with recent cutoff."""
        with patch('tinfoil.attestation.collateral_tdx.fetch_tcb_evaluation_data_numbers') as mock_fetch:
            mock_fetch.return_value = _parse_tcb_eval_numbers_response(SAMPLE_TCB_EVAL_NUMBERS_RESPONSE)

            # With 365-day cutoff from 2026-01-15, numbers from 2025-01-15 or later are acceptable
            # Number 19 (2025-05-13) should be the minimum acceptable
            # Number 18 (2024-11-12) is older than 1 year
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_now = datetime(2026, 1, 15, tzinfo=timezone.utc)
                mock_dt.now.return_value = mock_now
                mock_dt.side_effect = lambda *args, **kw: datetime(*args, **kw)

                result = calculate_min_tcb_evaluation_data_number(max_age_days=365)

                # Should return 19 since 18 is older than 1 year
                assert result == 19

    def test_calculate_with_shorter_cutoff(self):
        """Test calculation with shorter max age."""
        with patch('tinfoil.attestation.collateral_tdx.fetch_tcb_evaluation_data_numbers') as mock_fetch:
            mock_fetch.return_value = _parse_tcb_eval_numbers_response(SAMPLE_TCB_EVAL_NUMBERS_RESPONSE)

            # With 180-day cutoff from 2026-01-15, cutoff is ~2025-07-19
            # Number 20 (2025-08-12) should be acceptable
            # Number 19 (2025-05-13) is older than 180 days
            with patch('tinfoil.attestation.collateral_tdx.datetime') as mock_dt:
                mock_now = datetime(2026, 1, 15, tzinfo=timezone.utc)
                mock_dt.now.return_value = mock_now
                mock_dt.side_effect = lambda *args, **kw: datetime(*args, **kw)

                result = calculate_min_tcb_evaluation_data_number(max_age_days=180)

                assert result == 20

    def test_calculate_empty_numbers_raises(self):
        """Test that empty numbers list raises error."""
        with patch('tinfoil.attestation.collateral_tdx.fetch_tcb_evaluation_data_numbers') as mock_fetch:
            mock_fetch.return_value = TcbEvaluationDataNumbers(
                id="TDX",
                version=1,
                issue_date=datetime.now(timezone.utc),
                next_update=datetime.now(timezone.utc) + timedelta(days=30),
                tcb_eval_numbers=[],
                signature="dummy",
            )

            with pytest.raises(CollateralError, match="No TCB evaluation data numbers found"):
                calculate_min_tcb_evaluation_data_number()

    def test_calculate_all_too_old_raises(self):
        """Test that all numbers too old raises error."""
        # Create response with only old numbers
        old_numbers_response = b'''{
          "tcbEvaluationDataNumbers": {
            "id": "TDX",
            "version": 1,
            "issueDate": "2026-01-15T19:17:02Z",
            "nextUpdate": "2026-02-14T19:17:02Z",
            "tcbEvalNumbers": [
              {"tcbEvaluationDataNumber": 10, "tcbRecoveryEventDate": "2020-01-01T00:00:00Z", "tcbDate": "2020-01-02T00:00:00Z"}
            ]
          },
          "signature": "dummy"
        }'''

        with patch('tinfoil.attestation.collateral_tdx.fetch_tcb_evaluation_data_numbers') as mock_fetch:
            mock_fetch.return_value = _parse_tcb_eval_numbers_response(old_numbers_response)

            with pytest.raises(CollateralError, match="older than 365 days"):
                calculate_min_tcb_evaluation_data_number()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
