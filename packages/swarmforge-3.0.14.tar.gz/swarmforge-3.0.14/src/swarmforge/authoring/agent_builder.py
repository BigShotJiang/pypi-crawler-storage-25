"""End-to-end agent builder workflow for onboarding and prompt generation."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Sequence

from ..evaluation.provider import ModelConfig, OpenAIClientWrapper
from .generation import (
    GenerateAgentPromptRequest,
    GenerateAgentPromptResult,
    generate_agent_prompt,
)

DEFAULT_CATEGORY_TYPE = "persona"

CATEGORY_TYPE_ONBOARDING_GUIDANCE = """
Choose the best-fit builder category from these semantic buckets:
- persona: general assistants, specialists, support, sales, coaching, or domain experts
- voice_agent: phone, calling, IVR, voice workflows, spoken agents
- ops_services: automation, back-office execution, workflow orchestration, support operations
- reasoning_logic: analysts, planners, evaluators, structured decision systems, review agents
- video: video prompt builders or video-generation workflows
- image: image prompt builders or image-generation workflows

Pick the closest fit based on the user's real workflow, not keyword matching alone.
If several categories could apply, choose the one that best shapes onboarding questions and prompt behavior.
If nothing strongly indicates a specialized mode, use persona.
""".strip()

BUILDER_STEPS = [
    "readiness",
    "plan_onboarding",
    "collect_onboarding",
    "confirm_generate",
    "research",
    "phase_a",
    "phase_b",
    "phase_c",
    "phase_d",
    "title",
    "tools",
    "done",
]

GENERATION_PHASE_ORDER = ["research", "phase_a", "phase_b", "phase_c", "phase_d", "title", "tools"]


@dataclass
class AgentBuilderReadiness:
    is_ready: bool
    topic: str
    category_type: str
    clarifying_question: str = ""


@dataclass
class AgentBuilderOnboardingField:
    id: str
    label: str
    question: str
    type: str = "textarea"
    required: bool = True
    options: List[str] = field(default_factory=list)
    placeholder: str = ""
    help_text: str = ""

    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "AgentBuilderOnboardingField":
        return cls(
            id=_normalized_text(payload.get("id")),
            label=_normalized_text(payload.get("label")),
            question=_normalized_text(payload.get("question")),
            type=_normalized_text(payload.get("type")) or "textarea",
            required=bool(payload.get("required", True)),
            options=[_normalized_text(option) for option in payload.get("options", []) if _normalized_text(option)],
            placeholder=_normalized_text(payload.get("placeholder")),
            help_text=_normalized_text(payload.get("help_text") or payload.get("helpText")),
        )


@dataclass
class AgentBuilderOnboardingPlan:
    label: str
    onboarding_prompt: str
    fields: List[AgentBuilderOnboardingField]


@dataclass
class AgentBuilderStep:
    step: str
    status: str = "pending"
    result: Dict[str, Any] | None = None
    error: str = ""

    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "AgentBuilderStep":
        result = payload.get("result")
        return cls(
            step=_normalized_text(payload.get("step")),
            status=_normalized_text(payload.get("status")) or "pending",
            result=result if isinstance(result, dict) else None,
            error=_normalized_text(payload.get("error")),
        )


@dataclass
class AgentBuilderSession:
    seed_request: str
    topic: str
    category_type: str
    category_label: str
    onboarding_prompt: str
    fields: List[AgentBuilderOnboardingField]
    stage: str = "onboarding"
    collected_inputs: Dict[str, str] = field(default_factory=dict)
    messages: List[Dict[str, str]] = field(default_factory=list)
    steps: List[AgentBuilderStep] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "AgentBuilderSession":
        collected_inputs = payload.get("collected_inputs")
        messages = payload.get("messages")

        return cls(
            seed_request=_normalized_text(payload.get("seed_request")),
            topic=_normalized_text(payload.get("topic")),
            category_type=_normalize_category_type(_normalized_text(payload.get("category_type"))),
            category_label=_normalized_text(payload.get("category_label")),
            onboarding_prompt=_normalized_text(payload.get("onboarding_prompt")),
            fields=[
                AgentBuilderOnboardingField.from_payload(field)
                for field in payload.get("fields", [])
                if isinstance(field, dict)
            ],
            stage=_normalized_text(payload.get("stage")) or "onboarding",
            collected_inputs={
                _normalized_text(key): _normalized_text(value)
                for key, value in (collected_inputs.items() if isinstance(collected_inputs, dict) else [])
                if _normalized_text(key) and _normalized_text(value)
            },
            messages=[
                {
                    "role": _normalized_text(message.get("role")),
                    "content": _normalized_text(message.get("content")),
                }
                for message in (messages if isinstance(messages, list) else [])
                if isinstance(message, dict)
                and _normalized_text(message.get("role"))
                and _normalized_text(message.get("content"))
            ],
            steps=[
                AgentBuilderStep.from_payload(step)
                for step in payload.get("steps", [])
                if isinstance(step, dict)
            ],
        )

    def to_payload(self) -> Dict[str, Any]:
        return {
            "seed_request": self.seed_request,
            "topic": self.topic,
            "category_type": self.category_type,
            "category_label": self.category_label,
            "onboarding_prompt": self.onboarding_prompt,
            "stage": self.stage,
            "collected_inputs": dict(self.collected_inputs),
            "fields": [
                {
                    "id": field.id,
                    "label": field.label,
                    "question": field.question,
                    "type": field.type,
                    "required": field.required,
                    "options": list(field.options),
                    "placeholder": field.placeholder,
                    "help_text": field.help_text,
                }
                for field in self.fields
            ],
            "steps": [
                {
                    "step": step.step,
                    "status": step.status,
                    "result": step.result,
                    "error": step.error,
                }
                for step in self.steps
            ],
            "messages": [dict(message) for message in self.messages],
        }


@dataclass
class AgentBuilderStartResult:
    ready: bool
    clarifying_question: str = ""
    opening_message: str = ""
    readiness: AgentBuilderReadiness | None = None
    session: AgentBuilderSession | None = None


@dataclass
class AgentBuilderTurnResult:
    reply: str
    extracted_fields: Dict[str, str]
    all_fields_collected: bool
    stage: str


@dataclass
class AgentBuilderConfirmationResult:
    confirmed: bool
    extra_notes: str
    reply: str
    stage: str


@dataclass
class AgentBuilderRunResult:
    start: AgentBuilderStartResult
    generation_result: GenerateAgentPromptResult | None = None


def _normalized_text(value: Any) -> str:
    return str(value or "").strip()


def _normalize_category_type(value: str) -> str:
    candidate = _normalized_text(value).lower()
    if candidate == "persona":
        return "persona"
    if candidate == "voice_agent":
        return "voice_agent"
    if candidate == "ops_services":
        return "ops_services"
    if candidate == "reasoning_logic":
        return "reasoning_logic"
    if candidate == "video":
        return "video"
    if candidate == "image":
        return "image"

    if "voice" in candidate or "call" in candidate:
        return "voice_agent"
    if any(token in candidate for token in ["ops", "operation", "automation", "workflow"]):
        return "ops_services"
    if any(token in candidate for token in ["reason", "logic", "analysis", "evaluate"]):
        return "reasoning_logic"
    if "video" in candidate:
        return "video"
    if "image" in candidate:
        return "image"
    return DEFAULT_CATEGORY_TYPE


def _create_agent_field_id(raw_value: str, *, index: int) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "_", _normalized_text(raw_value).lower()).strip("_")
    if not normalized:
        normalized = f"field_{index}"
    if not re.match(r"^[a-z]", normalized):
        normalized = f"f_{normalized}"
    return normalized


def _extract_message_text(completion: Any) -> str:
    choices = getattr(completion, "choices", None)
    if not choices:
        return ""
    message = getattr(choices[0], "message", None)
    if message is None:
        return ""

    content = getattr(message, "content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        chunks: List[str] = []
        for item in content:
            if isinstance(item, dict):
                text = _normalized_text(item.get("text"))
                if text:
                    chunks.append(text)
        return "\n".join(chunks).strip()
    return _normalized_text(content)


def _chat_text(
    client: OpenAIClientWrapper,
    prompt: str,
    *,
    temperature: float = 0.2,
    max_tokens: int = 900,
) -> str:
    completion = client.chat_completion(
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        extra_params={"max_tokens": max_tokens},
    )
    text = _extract_message_text(completion)
    if not text:
        raise ValueError("Model returned an empty response")
    return text


def _strip_json_fences(raw: str) -> str:
    cleaned = raw.strip()
    if not cleaned.startswith("```"):
        return cleaned
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _parse_json_object(raw: str, *, expected: str) -> Dict[str, Any]:
    cleaned = _strip_json_fences(raw)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as err:
        raise ValueError(f"Failed to parse {expected} JSON response") from err

    if not isinstance(parsed, dict):
        raise ValueError(f"Expected {expected} response to be a JSON object")
    return parsed


def _default_onboarding_fields(topic: str) -> List[AgentBuilderOnboardingField]:
    topic_label = _normalized_text(topic) or "agent"
    return [
        AgentBuilderOnboardingField(
            id="intent",
            label="Primary Goal",
            question=f"What is the main outcome this {topic_label} agent should drive?",
            placeholder="Describe the business objective in one or two lines.",
            help_text="Focus on measurable outcomes rather than generic behavior.",
        ),
        AgentBuilderOnboardingField(
            id="audience_channel",
            label="Audience and Channel",
            question="Who will use this agent and in which channel or platform?",
            placeholder="Example: support leads through web chat.",
            help_text="Include audience, surface, and context.",
        ),
        AgentBuilderOnboardingField(
            id="constraints",
            label="Constraints and Guardrails",
            question="What boundaries, policies, or escalation rules must it follow?",
            placeholder="Example: never provide legal advice; escalate billing disputes.",
            help_text="List compliance boundaries and sensitive actions.",
        ),
    ]


def _normalize_plan_fields(raw_fields: Any) -> List[AgentBuilderOnboardingField]:
    if not isinstance(raw_fields, list):
        return []

    normalized_fields: List[AgentBuilderOnboardingField] = []
    seen_ids: set[str] = set()

    for index, field in enumerate(raw_fields, start=1):
        if not isinstance(field, dict):
            continue

        label = _normalized_text(field.get("label"))
        question = _normalized_text(field.get("question"))
        if not label or not question:
            continue

        field_type = _normalized_text(field.get("type")).lower() or "textarea"
        if field_type not in {"textarea", "select"}:
            field_type = "textarea"

        options = [
            _normalized_text(option)
            for option in (field.get("options") or [])
            if _normalized_text(option)
        ]
        if field_type == "select" and len(options) < 2:
            field_type = "textarea"
            options = []

        field_id = _create_agent_field_id(str(field.get("id") or label), index=index)
        while field_id in seen_ids:
            field_id = f"{field_id}_{index}"
        seen_ids.add(field_id)

        normalized_fields.append(
            AgentBuilderOnboardingField(
                id=field_id,
                label=label[:80],
                question=question[:240],
                type=field_type,
                required=bool(field.get("required", True)),
                options=options[:6],
                placeholder=_normalized_text(field.get("placeholder"))[:240],
                help_text=_normalized_text(field.get("help_text") or field.get("helpText"))[:240],
            )
        )

        if len(normalized_fields) == 4:
            break

    return normalized_fields


def _is_low_information_reply(text: str) -> bool:
    normalized = _normalized_text(text).lower()
    return normalized in {"idk", "i dont know", "i don't know", "not sure", "unsure", "maybe"}


def _sanitize_onboarding_answer_text(text: str) -> str:
    return re.sub(r"\s+", " ", _normalized_text(text)).strip(" .,!;:")


def _initial_steps() -> List[AgentBuilderStep]:
    return [AgentBuilderStep(step=step) for step in BUILDER_STEPS]


def _next_generation_step(phase_step: str) -> str | None:
    if phase_step not in GENERATION_PHASE_ORDER:
        return None
    index = GENERATION_PHASE_ORDER.index(phase_step)
    if index + 1 >= len(GENERATION_PHASE_ORDER):
        return None
    return GENERATION_PHASE_ORDER[index + 1]


class AgentBuilderFlow:
    """Composable onboarding + generation flow mirroring promptly's builder workflow."""

    def __init__(
        self,
        *,
        client: OpenAIClientWrapper | None = None,
        model_config: ModelConfig | None = None,
        prompt_generator: Callable[..., GenerateAgentPromptResult] = generate_agent_prompt,
    ) -> None:
        self._client = client or OpenAIClientWrapper(model_config or ModelConfig())
        self._prompt_generator = prompt_generator

    def _step_by_name(self, session: AgentBuilderSession, step_name: str) -> AgentBuilderStep:
        for step in session.steps:
            if step.step == step_name:
                return step
        created = AgentBuilderStep(step=step_name)
        session.steps.append(created)
        return created

    def _set_step(
        self,
        session: AgentBuilderSession,
        step_name: str,
        status: str,
        *,
        result: Dict[str, Any] | None = None,
        error: str = "",
    ) -> None:
        step = self._step_by_name(session, step_name)
        step.status = status
        step.error = error
        if result is not None:
            step.result = result

    def _append_message(self, session: AgentBuilderSession, role: str, content: str) -> None:
        text = _normalized_text(content)
        if not text:
            return
        session.messages.append({"role": role, "content": text})

    def _conversation_history(self, session: AgentBuilderSession) -> str:
        lines = []
        for message in session.messages:
            role = _normalized_text(message.get("role"))
            content = _normalized_text(message.get("content"))
            if not content:
                continue
            prefix = "User" if role == "user" else "Assistant"
            lines.append(f"{prefix}: {content}")
        return "\n".join(lines)

    def _required_fields_collected(self, session: AgentBuilderSession) -> bool:
        for field in session.fields:
            if not field.required:
                continue
            if not _normalized_text(session.collected_inputs.get(field.id)):
                return False
        return True

    def _next_missing_field(self, session: AgentBuilderSession) -> AgentBuilderOnboardingField | None:
        for field in session.fields:
            if _normalized_text(session.collected_inputs.get(field.id)):
                continue
            return field
        return None

    def analyze_readiness(
        self,
        seed_request: str,
        *,
        clarification: str = "",
        require_ready: bool = False,
    ) -> AgentBuilderReadiness:
        combined_request = " ".join(
            part for part in [_normalized_text(seed_request), _normalized_text(clarification)] if part
        ).strip()
        if not combined_request:
            raise ValueError("Create-agent request is empty")

        prompt = f"""
You are helping an agent-builder SDK decide whether it has enough information to start onboarding.

User request:
{combined_request}

Return strict JSON with:
- is_ready: true when the request is specific enough to start onboarding now
- topic: concise builder topic (4-12 words)
- category_type: the best-fit category label from the guidance below
- clarifying_question: one concise question only when is_ready is false

Category guidance:
{CATEGORY_TYPE_ONBOARDING_GUIDANCE}

Rules:
- Mark ready when the request already includes clear task/workflow/channel/audience/problem context.
- Ask for only the highest-value missing detail when not ready.
- Never ask for app name, company name, or generic value proposition.
""".strip()

        parsed: Dict[str, Any]
        try:
            parsed = _parse_json_object(_chat_text(self._client, prompt, max_tokens=400), expected="readiness")
        except ValueError:
            parsed = {}

        topic = _normalized_text(parsed.get("topic")) or combined_request
        category_type = _normalize_category_type(_normalized_text(parsed.get("category_type")))
        clarifying_question = _normalized_text(parsed.get("clarifying_question"))
        is_ready = bool(parsed.get("is_ready")) if isinstance(parsed.get("is_ready"), bool) else False

        if require_ready:
            is_ready = True

        if not is_ready and not clarifying_question:
            clarifying_question = "What is the main workflow you want this agent to handle first?"

        return AgentBuilderReadiness(
            is_ready=is_ready,
            topic=topic[:160],
            category_type=category_type,
            clarifying_question=clarifying_question,
        )

    def plan_onboarding(
        self,
        *,
        seed_request: str,
        topic: str,
        category_type: str,
    ) -> AgentBuilderOnboardingPlan:
        prompt = f"""
You are planning a short onboarding interview for an agent builder SDK.

User request:
{seed_request}

Resolved topic: {topic}
Resolved category type: {category_type}

Return strict JSON with:
- label: concise name for this builder
- onboarding_prompt: internal conversational brief for onboarding
- fields: 2 to 4 missing details to ask next, ordered by value

Field rules:
- id: snake_case
- label: concise label
- question: one natural question
- type: textarea or select
- required: boolean
- options: only include for small fixed sets
- placeholder/help_text: optional and concise

Planning rules:
- Ask only for missing details that improve prompt quality.
- Do not ask user to restate already clear use case.
- Prefer 3 fields when possible.
- Never ask for app name or generic value proposition.
""".strip()

        parsed: Dict[str, Any]
        try:
            parsed = _parse_json_object(_chat_text(self._client, prompt, max_tokens=700), expected="onboarding_plan")
        except ValueError:
            parsed = {}

        fields = _normalize_plan_fields(parsed.get("fields"))
        if len(fields) < 2:
            fields = _default_onboarding_fields(topic)

        label = _normalized_text(parsed.get("label")) or topic or "New Agent"
        onboarding_prompt = _normalized_text(parsed.get("onboarding_prompt"))
        if not onboarding_prompt:
            onboarding_prompt = (
                "Use the onboarding fields as internal guidance, follow the latest user message, "
                "and ask one high-value follow-up at a time."
            )

        return AgentBuilderOnboardingPlan(
            label=label[:120],
            onboarding_prompt=onboarding_prompt[:1200],
            fields=fields,
        )

    def generate_opening_message(self, session: AgentBuilderSession) -> str:
        fields_block = "\n".join(f"- {field.label}: {field.question}" for field in session.fields)
        prompt = f"""
You are a friendly agent-builder assistant.

Agent: {session.category_label}
User request: {session.seed_request}

Internal onboarding brief:
{session.onboarding_prompt}

Information still needed:
{fields_block}

Write a concise opening message that:
- acknowledges the request in one sentence
- asks about the first missing detail naturally
- stays within 2 to 3 sentences
- does not list all questions at once
""".strip()

        try:
            reply = _chat_text(self._client, prompt, max_tokens=250)
        except ValueError:
            reply = "I captured the direction. What is the most important outcome you want this agent to deliver first?"
        return reply

    def start_onboarding(
        self,
        seed_request: str,
        *,
        clarification: str = "",
        require_ready: bool = False,
    ) -> AgentBuilderStartResult:
        readiness = self.analyze_readiness(
            seed_request,
            clarification=clarification,
            require_ready=require_ready,
        )

        if not readiness.is_ready:
            return AgentBuilderStartResult(
                ready=False,
                clarifying_question=readiness.clarifying_question,
                readiness=readiness,
            )

        plan = self.plan_onboarding(
            seed_request=seed_request,
            topic=readiness.topic,
            category_type=readiness.category_type,
        )

        session = AgentBuilderSession(
            seed_request=seed_request,
            topic=readiness.topic,
            category_type=readiness.category_type,
            category_label=plan.label,
            onboarding_prompt=plan.onboarding_prompt,
            fields=plan.fields,
            steps=_initial_steps(),
        )
        self._set_step(session, "readiness", "completed", result={"topic": readiness.topic, "category_type": readiness.category_type})
        self._set_step(session, "plan_onboarding", "completed", result={"label": plan.label, "field_count": len(plan.fields)})
        self._set_step(session, "collect_onboarding", "running")

        opening_message = self.generate_opening_message(session)
        self._append_message(session, "assistant", opening_message)

        return AgentBuilderStartResult(
            ready=True,
            opening_message=opening_message,
            readiness=readiness,
            session=session,
        )

    def apply_onboarding_inputs(self, session: AgentBuilderSession, inputs: Dict[str, str]) -> None:
        valid_ids = {field.id for field in session.fields}
        for key, value in inputs.items():
            normalized_key = _normalized_text(key)
            if normalized_key not in valid_ids:
                continue
            normalized_value = _normalized_text(value)
            if normalized_value:
                session.collected_inputs[normalized_key] = normalized_value

        if self._required_fields_collected(session):
            session.stage = "confirm_generate"
            self._set_step(session, "collect_onboarding", "completed")
            self._set_step(session, "confirm_generate", "running")

    def process_onboarding_turn(self, session: AgentBuilderSession, user_message: str) -> AgentBuilderTurnResult:
        if session.stage not in {"onboarding", "confirm_generate"}:
            raise ValueError(f"Cannot process onboarding turn while stage is '{session.stage}'")

        self._append_message(session, "user", user_message)

        field_summary_lines = []
        for field in session.fields:
            current_value = _normalized_text(session.collected_inputs.get(field.id))
            status = f"answered: {current_value}" if current_value else "unanswered"
            field_summary_lines.append(f"- {field.id} ({field.label}): {status}")
        field_summary = "\n".join(field_summary_lines)

        prompt = f"""
You are a friendly agent-builder assistant conducting dynamic onboarding.

Agent: {session.category_label}
Original user request: {session.seed_request}

Internal onboarding brief:
{session.onboarding_prompt}

Onboarding fields:
{field_summary}

Conversation so far:
{self._conversation_history(session)}

Latest user message:
{user_message}

Return strict JSON:
{{
  "extracted_fields": {{"field_id": "value"}},
  "all_fields_collected": true_or_false,
  "reply": "next conversational message"
}}

Rules:
- extract any field values from this latest user message
- if user answered multiple fields, extract all of them
- if all required fields are filled, summarize and ask for generation confirmation
- keep reply concise and natural, 1 to 3 sentences
- never mention JSON or field ids in the reply
""".strip()

        parsed: Dict[str, Any]
        try:
            parsed = _parse_json_object(_chat_text(self._client, prompt, max_tokens=700), expected="onboarding_turn")
        except ValueError:
            parsed = {}

        extracted_fields = parsed.get("extracted_fields") if isinstance(parsed.get("extracted_fields"), dict) else {}
        normalized_extracted: Dict[str, str] = {}
        valid_ids = {field.id for field in session.fields}

        for field_id, value in extracted_fields.items():
            normalized_field_id = _normalized_text(field_id)
            normalized_value = _normalized_text(value)
            if normalized_field_id in valid_ids and normalized_value:
                normalized_extracted[normalized_field_id] = normalized_value

        if not normalized_extracted and not _is_low_information_reply(user_message):
            next_field = self._next_missing_field(session)
            fallback_value = _sanitize_onboarding_answer_text(user_message)
            if next_field and fallback_value:
                normalized_extracted[next_field.id] = fallback_value

        for field_id, value in normalized_extracted.items():
            session.collected_inputs[field_id] = value

        all_fields_collected = self._required_fields_collected(session)
        if isinstance(parsed.get("all_fields_collected"), bool):
            all_fields_collected = all_fields_collected or bool(parsed.get("all_fields_collected"))

        reply = _normalized_text(parsed.get("reply"))
        if not reply:
            if all_fields_collected:
                reply = (
                    f"I have enough context for {session.category_label}. "
                    "If this looks right, tell me to start generating the prompt."
                )
            else:
                missing = self._next_missing_field(session)
                if missing:
                    reply = f"Got it. {missing.question}"
                else:
                    reply = "Thanks, I captured that. Share the next detail you want included."

        if all_fields_collected:
            session.stage = "confirm_generate"
            self._set_step(session, "collect_onboarding", "completed")
            self._set_step(session, "confirm_generate", "running")
        else:
            session.stage = "onboarding"
            self._set_step(session, "collect_onboarding", "running")

        self._append_message(session, "assistant", reply)

        return AgentBuilderTurnResult(
            reply=reply,
            extracted_fields=normalized_extracted,
            all_fields_collected=all_fields_collected,
            stage=session.stage,
        )

    def process_confirmation_turn(
        self,
        session: AgentBuilderSession,
        user_message: str,
    ) -> AgentBuilderConfirmationResult:
        if session.stage != "confirm_generate":
            raise ValueError(f"Cannot process confirmation while stage is '{session.stage}'")

        self._append_message(session, "user", user_message)

        details = [
            f"- {field.label}: {session.collected_inputs.get(field.id, '')}"
            for field in session.fields
            if _normalized_text(session.collected_inputs.get(field.id))
        ]
        details_block = "\n".join(details) if details else "(none)"

        prompt = f"""
You are a friendly agent-builder assistant at generation confirmation stage.

Agent: {session.category_label}
Collected details:
{details_block}

Conversation so far:
{self._conversation_history(session)}

Latest user message:
{user_message}

Return strict JSON:
{{
  "confirmed": true_or_false,
  "extra_notes": "optional additional context",
  "reply": "next conversational message"
}}

Rules:
- confirmed true only if user clearly agrees to start generation now
- if not confirmed, capture extra_notes when user requests edits
- keep reply concise and practical
""".strip()

        parsed: Dict[str, Any]
        try:
            parsed = _parse_json_object(_chat_text(self._client, prompt, max_tokens=400), expected="confirm_turn")
        except ValueError:
            parsed = {}

        confirmed = bool(parsed.get("confirmed")) if isinstance(parsed.get("confirmed"), bool) else False
        extra_notes = _normalized_text(parsed.get("extra_notes"))
        if extra_notes:
            existing = _normalized_text(session.collected_inputs.get("extra_notes"))
            session.collected_inputs["extra_notes"] = extra_notes if not existing else f"{existing}\n{extra_notes}"

        reply = _normalized_text(parsed.get("reply"))
        if not reply:
            if confirmed:
                reply = "Great, starting generation now."
            else:
                reply = "Noted. I folded that in. Tell me when you want me to start generation."

        if confirmed:
            session.stage = "generating"
            self._set_step(session, "confirm_generate", "completed")
        else:
            self._set_step(session, "confirm_generate", "running")

        self._append_message(session, "assistant", reply)

        return AgentBuilderConfirmationResult(
            confirmed=confirmed,
            extra_notes=extra_notes,
            reply=reply,
            stage=session.stage,
        )

    def _update_generation_phase(self, session: AgentBuilderSession, phase_name: str) -> None:
        if phase_name not in GENERATION_PHASE_ORDER:
            return

        self._set_step(session, phase_name, "completed")
        next_step = _next_generation_step(phase_name)
        if next_step is not None:
            next_status = self._step_by_name(session, next_step).status
            if next_status == "pending":
                self._set_step(session, next_step, "running")

    def run_generation(
        self,
        session: AgentBuilderSession,
        *,
        length: str = "detailed",
        max_words: int = 2000,
        flow_type: str = "inbound",
        generate_tools: bool = False,
        tools_format: str = "openai",
        has_knowledge_files: bool = False,
        json_tools: List[Dict[str, Any]] | None = None,
        on_phase: Callable[[str], None] | None = None,
    ) -> GenerateAgentPromptResult:
        if not self._required_fields_collected(session):
            raise ValueError("Cannot generate prompt before all required onboarding fields are collected")

        if session.stage == "onboarding":
            session.stage = "confirm_generate"
            self._set_step(session, "collect_onboarding", "completed")
            self._set_step(session, "confirm_generate", "running")

        if session.stage == "confirm_generate":
            self._set_step(session, "confirm_generate", "completed")

        session.stage = "generating"
        self._set_step(session, "research", "running")

        request = GenerateAgentPromptRequest(
            topic=session.topic,
            inputs=dict(session.collected_inputs),
            category_label=session.category_label,
            category_type=session.category_type,
            length=length,
            max_words=max_words,
            flow_type=flow_type,
            generate_tools=generate_tools,
            tools_format=tools_format,
            has_knowledge_files=has_knowledge_files,
            json_tools=json_tools,
        )

        def _phase_callback(phase_name: str) -> None:
            self._update_generation_phase(session, phase_name)
            if on_phase:
                on_phase(phase_name)

        try:
            result = self._prompt_generator(
                request,
                client=self._client,
                on_phase=_phase_callback,
            )
        except Exception as err:
            active_step = None
            for step in session.steps:
                if step.status == "running":
                    active_step = step.step
                    break
            if active_step:
                self._set_step(session, active_step, "failed", error=str(err))
            self._set_step(session, "done", "failed", error=str(err))
            session.stage = "confirm_generate"
            raise

        if not generate_tools:
            self._set_step(session, "tools", "skipped")

        self._set_step(session, "done", "completed")
        session.stage = "done"
        return result

    def run_full_flow(
        self,
        *,
        seed_request: str,
        onboarding_inputs: Dict[str, str],
        clarification: str = "",
        require_ready: bool = False,
        length: str = "detailed",
        max_words: int = 2000,
        flow_type: str = "inbound",
        generate_tools: bool = False,
        tools_format: str = "openai",
        has_knowledge_files: bool = False,
        json_tools: List[Dict[str, Any]] | None = None,
        on_phase: Callable[[str], None] | None = None,
    ) -> AgentBuilderRunResult:
        start = self.start_onboarding(
            seed_request,
            clarification=clarification,
            require_ready=require_ready,
        )
        if not start.ready or start.session is None:
            return AgentBuilderRunResult(start=start, generation_result=None)

        session = start.session
        self.apply_onboarding_inputs(session, onboarding_inputs)

        missing_required = [
            field.id
            for field in session.fields
            if field.required and not _normalized_text(session.collected_inputs.get(field.id))
        ]
        if missing_required:
            raise ValueError(
                "Missing required onboarding inputs: " + ", ".join(missing_required)
            )

        self._set_step(session, "confirm_generate", "completed")
        generation_result = self.run_generation(
            session,
            length=length,
            max_words=max_words,
            flow_type=flow_type,
            generate_tools=generate_tools,
            tools_format=tools_format,
            has_knowledge_files=has_knowledge_files,
            json_tools=json_tools,
            on_phase=on_phase,
        )
        return AgentBuilderRunResult(start=start, generation_result=generation_result)


__all__ = [
    "AgentBuilderConfirmationResult",
    "AgentBuilderFlow",
    "AgentBuilderOnboardingField",
    "AgentBuilderOnboardingPlan",
    "AgentBuilderReadiness",
    "AgentBuilderRunResult",
    "AgentBuilderSession",
    "AgentBuilderStartResult",
    "AgentBuilderStep",
    "AgentBuilderTurnResult",
]
