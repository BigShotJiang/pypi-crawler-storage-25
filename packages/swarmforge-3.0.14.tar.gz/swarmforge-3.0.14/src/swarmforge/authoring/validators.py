"""Validation and graph-building helpers for SwarmForge authoring."""

from __future__ import annotations

import copy
import re
from typing import Any, Dict, List, Mapping

from ..swarm.models import SwarmDefinition, SwarmEdge, SwarmNode, SwarmVariable


VALID_REDUCER_RULES = {"overwrite", "append", "keep_first"}
MAX_EDGE_REQUIRED_VARIABLES = 3
SNAKE_CASE_KEY_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _normalized_text(value: Any) -> str:
    return str(value or "").strip()


def _normalize_string_list(values: Any, *, max_items: int | None = None) -> List[str]:
    if not isinstance(values, list):
        return []
    cleaned: List[str] = []
    for value in values:
        item = _normalized_text(value)
        if item:
            cleaned.append(item)
    if max_items is not None:
        return cleaned[:max_items]
    return cleaned


def validate_generated_edge_payload(parsed: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(parsed, Mapping):
        raise ValueError("Generated edge payload must be an object.")

    handoff_description = _normalized_text(parsed.get("handoff_description"))
    if not handoff_description:
        raise ValueError("Generated edge payload requires handoff_description.")

    return {
        "handoff_description": handoff_description,
        "required_variables": _normalize_string_list(parsed.get("required_variables"), max_items=3),
    }


def validate_generated_swarm_payload(parsed: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(parsed, Mapping):
        raise ValueError("Generated swarm payload must be an object.")

    raw_nodes = parsed.get("nodes")
    if not isinstance(raw_nodes, list):
        raise ValueError("Generated swarm payload must include a nodes array.")

    raw_edges_candidate = parsed.get("edges", [])
    if raw_edges_candidate is None:
        raw_edges: List[Any] = []
    elif isinstance(raw_edges_candidate, list):
        raw_edges = raw_edges_candidate
    else:
        raise ValueError("Generated swarm payload edges must be an array when provided.")

    nodes: List[Dict[str, Any]] = []
    node_keys: set[str] = set()
    entry_count = 0
    node_level_routes: List[Dict[str, Any]] = []

    for raw_node in raw_nodes:
        if not isinstance(raw_node, Mapping):
            raise ValueError("Each generated node must be an object.")
        node_key = _normalized_text(raw_node.get("node_key"))
        name = _normalized_text(raw_node.get("name"))
        intent = _normalized_text(raw_node.get("intent"))
        capabilities = _normalize_string_list(raw_node.get("capabilities"), max_items=5)
        persona = _normalized_text(raw_node.get("persona"))
        system_prompt = _normalized_text(raw_node.get("system_prompt"))
        model_choice = _normalized_text(raw_node.get("model_choice"))
        enabled_tools = copy.deepcopy(raw_node.get("enabled_tools")) if isinstance(raw_node.get("enabled_tools"), list) else []
        behavior_config = copy.deepcopy(raw_node.get("behavior_config")) if isinstance(raw_node.get("behavior_config"), dict) else {}
        is_entry_node = bool(raw_node.get("is_entry_node"))

        if not node_key or not name:
            raise ValueError("Generated nodes require node_key and name.")
        if node_key in node_keys:
            raise ValueError(f"Duplicate node_key '{node_key}' is not allowed.")

        raw_sub_agents = raw_node.get("sub_agents") or []
        if not isinstance(raw_sub_agents, list):
            raise ValueError(f"Node '{node_key}' sub_agents must be an array when provided.")

        normalized_sub_agents: List[Dict[str, Any]] = []
        for raw_sub_agent in raw_sub_agents:
            if not isinstance(raw_sub_agent, Mapping):
                raise ValueError(f"Node '{node_key}' sub_agents entries must be objects.")
            target_node_key = _normalized_text(raw_sub_agent.get("sub_agent") or raw_sub_agent.get("target_node_key"))
            handoff_description = _normalized_text(raw_sub_agent.get("handoff_description"))
            if not target_node_key or not handoff_description:
                raise ValueError(
                    f"Node '{node_key}' sub_agents require sub_agent and handoff_description."
                )
            required_variables = _normalize_string_list(
                raw_sub_agent.get("required_variables"),
                max_items=MAX_EDGE_REQUIRED_VARIABLES,
            )
            normalized_sub_agents.append(
                {
                    "sub_agent": target_node_key,
                    "handoff_description": handoff_description,
                    "required_variables": required_variables,
                }
            )
            node_level_routes.append(
                {
                    "source_node_key": node_key,
                    "target_node_key": target_node_key,
                    "handoff_description": handoff_description,
                    "required_variables": required_variables,
                }
            )

        node_keys.add(node_key)
        entry_count += 1 if is_entry_node else 0
        node_payload: Dict[str, Any] = {
            "node_key": node_key,
            "name": name,
            "persona": persona,
            "system_prompt": system_prompt,
            "model_choice": model_choice,
            "enabled_tools": enabled_tools,
            "behavior_config": behavior_config,
            "is_entry_node": is_entry_node,
        }
        if intent:
            node_payload["intent"] = intent
        if capabilities:
            node_payload["capabilities"] = capabilities
        if normalized_sub_agents:
            node_payload["sub_agents"] = normalized_sub_agents
        nodes.append(node_payload)

    if entry_count != 1:
        raise ValueError("Exactly one generated node must be marked as the entry node.")

    edges: List[Dict[str, Any]] = []
    seen_routes: set[tuple[str, str]] = set()

    def register_edge(edge_payload: Dict[str, Any]) -> None:
        source_node_key = edge_payload["source_node_key"]
        target_node_key = edge_payload["target_node_key"]
        if source_node_key not in node_keys:
            raise ValueError(f"Edge source '{source_node_key}' does not match any generated node.")
        if target_node_key not in node_keys:
            raise ValueError(f"Edge target '{target_node_key}' does not match any generated node.")
        if source_node_key == target_node_key:
            raise ValueError(f"Edge '{source_node_key}' cannot target itself.")
        route = (source_node_key, target_node_key)
        if route in seen_routes:
            raise ValueError(
                f"Duplicate generated route '{source_node_key}->{target_node_key}' is not allowed."
            )
        seen_routes.add(route)
        edges.append(edge_payload)

    for raw_edge in raw_edges:
        if not isinstance(raw_edge, Mapping):
            raise ValueError("Each generated edge must be an object.")
        source_node_key = _normalized_text(raw_edge.get("source_node_key"))
        target_node_key = _normalized_text(raw_edge.get("target_node_key"))
        handoff_description = _normalized_text(raw_edge.get("handoff_description"))
        if not source_node_key or not target_node_key or not handoff_description:
            raise ValueError(
                "Generated edges require source_node_key, target_node_key, and handoff_description."
            )
        register_edge(
            {
                "source_node_key": source_node_key,
                "target_node_key": target_node_key,
                "handoff_description": handoff_description,
                "required_variables": _normalize_string_list(
                    raw_edge.get("required_variables"),
                    max_items=MAX_EDGE_REQUIRED_VARIABLES,
                ),
            }
        )

    for route in node_level_routes:
        register_edge(route)

    return {"nodes": nodes, "edges": edges}


def build_generated_variables_from_swarm_payload(generated: Mapping[str, Any]) -> List[Dict[str, str]]:
    seen_keys: set[str] = set()
    variables: List[Dict[str, str]] = []

    for edge in generated.get("edges", []) or []:
        for key in edge.get("required_variables", []) or []:
            clean_key = _normalized_text(key)
            if not clean_key or clean_key in seen_keys:
                continue
            seen_keys.add(clean_key)
            variables.append(
                {
                    "key_name": clean_key,
                    "description": "",
                    "reducer_rule": "overwrite",
                }
            )

    return variables


def validate_swarm_definition(swarm: SwarmDefinition) -> None:
    if not swarm.nodes:
        raise ValueError("Add at least one node before using the swarm definition.")

    entry_nodes = [node for node in swarm.nodes if bool(node.is_entry_node)]
    if len(entry_nodes) != 1:
        raise ValueError("Exactly one node must be marked as the entry node.")

    seen_node_keys: set[str] = set()
    seen_names: Dict[str, str] = {}
    for node in swarm.nodes:
        node_key = _normalized_text(node.node_key)
        node_name = _normalized_text(node.name)
        if not node_key:
            raise ValueError("Each node must include a node_key.")
        if not node_name:
            raise ValueError(f"Node '{node_key}' is missing a display name.")
        if node_key in seen_node_keys:
            raise ValueError(f"Duplicate node_key '{node_key}' is not allowed.")
        seen_node_keys.add(node_key)

        normalized_name = node_name.casefold()
        existing = seen_names.get(normalized_name)
        if existing is not None:
            raise ValueError(
                f"Duplicate agent label '{node_name}' is not allowed. Use distinct display names."
            )
        seen_names[normalized_name] = node_key

    seen_variable_keys: set[str] = set()
    for variable in swarm.variables:
        key_name = _normalized_text(variable.key_name)
        if not key_name:
            raise ValueError("Variable definitions must include a key_name.")
        if key_name in seen_variable_keys:
            raise ValueError(f"Duplicate variable key '{key_name}' is not allowed.")
        seen_variable_keys.add(key_name)
        reducer_rule = _normalized_text(variable.reducer_rule) or "overwrite"
        if reducer_rule not in VALID_REDUCER_RULES:
            raise ValueError(
                f"Variable '{key_name}' uses invalid reducer_rule '{reducer_rule}'."
            )

    seen_edge_routes: set[tuple[str, str]] = set()
    for edge in swarm.edges:
        source_node_id = _normalized_text(edge.source_node_id)
        target_node_id = _normalized_text(edge.target_node_id)
        handoff_description = _normalized_text(edge.handoff_description)
        required_variables = [_normalized_text(key) for key in list(edge.required_variables or []) if _normalized_text(key)]

        if not source_node_id or not target_node_id:
            raise ValueError("Each edge must include both source_node_id and target_node_id.")
        if source_node_id == target_node_id:
            raise ValueError("Edges cannot target the same node as their source.")
        if swarm.node_by_id(source_node_id) is None:
            raise ValueError(f"Edge source '{source_node_id}' does not match any node id in the graph.")
        if swarm.node_by_id(target_node_id) is None:
            raise ValueError(f"Edge target '{target_node_id}' does not match any node id in the graph.")

        if not handoff_description:
            raise ValueError("Each edge must include a non-empty handoff_description.")

        route = (source_node_id, target_node_id)
        if route in seen_edge_routes:
            raise ValueError(
                f"Duplicate edge route '{source_node_id}->{target_node_id}' is not allowed. "
                "Use one edge per source/target pair."
            )
        seen_edge_routes.add(route)

        if len(required_variables) > MAX_EDGE_REQUIRED_VARIABLES:
            raise ValueError(
                f"Edge '{source_node_id}->{target_node_id}' has too many required variables "
                f"({len(required_variables)}). Maximum allowed is {MAX_EDGE_REQUIRED_VARIABLES}."
            )

        for key in required_variables:
            if not SNAKE_CASE_KEY_RE.match(key):
                raise ValueError(
                    f"Edge variable key '{key}' is invalid. Use lower snake_case keys like 'account_id'."
                )


def build_swarm_definition(
    payload: Mapping[str, Any],
    *,
    swarm_id: str = "swarm",
    name: str = "Generated Swarm",
    graph_version: int = 1,
) -> SwarmDefinition:
    normalized = validate_generated_swarm_payload(payload)
    variable_payload = payload.get("variables")
    raw_variables = variable_payload if isinstance(variable_payload, list) else build_generated_variables_from_swarm_payload(normalized)

    nodes = [
        SwarmNode(
            id=f"{swarm_id}:{node['node_key']}",
            node_key=node["node_key"],
            name=node["name"],
            intent=node.get("intent") or "",
            capabilities=list(node.get("capabilities") or []),
            persona=node["persona"],
            system_prompt=node.get("system_prompt") or "",
            model_choice=node.get("model_choice") or "",
            enabled_tools=copy.deepcopy(node.get("enabled_tools") or []),
            sub_agents=copy.deepcopy(node.get("sub_agents") or []),
            behavior_config=copy.deepcopy(node.get("behavior_config") or {}),
            is_entry_node=bool(node["is_entry_node"]),
        )
        for node in normalized["nodes"]
    ]
    node_id_by_key = {node.node_key: node.id for node in nodes}

    edges = [
        SwarmEdge(
            id=f"{swarm_id}:{edge['source_node_key']}->{edge['target_node_key']}",
            source_node_id=node_id_by_key[edge["source_node_key"]],
            target_node_id=node_id_by_key[edge["target_node_key"]],
            handoff_description=edge["handoff_description"],
            required_variables=list(edge["required_variables"]),
        )
        for edge in normalized["edges"]
    ]
    variables = [
        SwarmVariable(
            key_name=_normalized_text(raw_variable.get("key_name")),
            description=_normalized_text(raw_variable.get("description")),
            reducer_rule=_normalized_text(raw_variable.get("reducer_rule")) or "overwrite",
        )
        for raw_variable in raw_variables
        if isinstance(raw_variable, Mapping) and _normalized_text(raw_variable.get("key_name"))
    ]
    definition = SwarmDefinition(
        id=swarm_id,
        name=name,
        graph_version=graph_version,
        nodes=nodes,
        edges=edges,
        variables=variables,
    )
    validate_swarm_definition(definition)
    return definition


def apply_swarm_graph_payload(swarm: SwarmDefinition, payload: Mapping[str, Any]) -> SwarmDefinition:
    updated = build_swarm_definition(
        payload,
        swarm_id=swarm.id,
        name=swarm.name,
        graph_version=int(getattr(swarm, "graph_version", 1) or 1) + 1,
    )
    swarm.graph_version = updated.graph_version
    swarm.nodes = updated.nodes
    swarm.edges = updated.edges
    swarm.variables = updated.variables
    return swarm
