"""Headless orchestration runtime for swarm chat execution."""

from __future__ import annotations

import asyncio
import copy
import json
import re
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Awaitable, Callable, Dict, List, Optional, Protocol, Union, runtime_checkable

from ..evaluation.runner.tool_mocks import MockNotFoundBehavior, ToolMockMatcher
from .multimodal import MultimodalContent, _build_user_message_content, extract_text_from_content
from .models import (
    AgentRuntimeContext,
    SessionCheckpoint,
    SwarmDefinition,
    SwarmEdge,
    SwarmNode,
    SwarmNodeBehaviorConfig,
    SwarmSeedContext,
    SwarmSession,
    SystemPromptContext,
    invoke_system_prompt_builder,
)
from .stores.base import SessionStore
from .tools import (
    ToolExecutionContext,
    ToolRegistry,
    invoke_tool_handler,
    resolve_tool_handler,
    resolve_tool_shared_state,
)
from .variables import (
    SessionStateManager,
    _get_intent_stack,
    _get_scoped_variable,
    _intent_namespace,
    _pop_next_intent,
    _set_active_intent,
    _set_intent_stack,
    _visible_state,
)


MAX_HANDOFFS = 10
MAX_TOOL_ITERATIONS = 3


@dataclass
class AgentTurnConfig:
    """Configuration passed to the turn runner for each agent turn."""

    system_instruction: str
    tools: List[Dict[str, Any]] = field(default_factory=list)
    visible_state: Dict[str, Any] = field(default_factory=dict)
    behavior_config: Dict[str, Any] = field(default_factory=dict)

    @property
    def visible_global_variables(self) -> Dict[str, Any]:
        return self.visible_state

    @property
    def state(self) -> Dict[str, Any]:
        return self.visible_state


@dataclass
class AgentTurnResult:
    """Structured result returned by a runner for a single agent turn."""

    response_text: str = ""
    tool_calls: List[Dict[str, Any]] = field(default_factory=list)
    raw_response: Any = None


class AgentTurnRunner(Protocol):
    """Executes one agent turn against a model or stubbed implementation."""

    async def run_turn(
        self,
        *,
        agent_node: SwarmNode,
        contents: List[Dict[str, Any]],
        config: AgentTurnConfig,
    ) -> AgentTurnResult: ...


@runtime_checkable
class StreamingAgentTurnRunner(AgentTurnRunner, Protocol):
    """Turn runner that additionally supports streaming via ``stream_turn``."""

    def stream_turn(
        self,
        *,
        agent_node: SwarmNode,
        contents: List[Dict[str, Any]],
        config: AgentTurnConfig,
    ) -> AsyncGenerator[tuple[str, None] | tuple[None, AgentTurnResult], None]: ...


RequiredVariableExtractor = Callable[..., Awaitable[Dict[str, Any]]]


def _node_tools(agent_node: SwarmNode) -> tuple[List[Dict[str, Any]], ToolMockMatcher | None]:
    tools = list(agent_node.enabled_tools or [])
    if not tools:
        return [], None
    matcher = ToolMockMatcher(tools=tools, no_mock_behavior=MockNotFoundBehavior.RETURN_ERROR)
    return matcher.get_clean_tools(), matcher


def _normalize_seed_context(value: SwarmSeedContext | Dict[str, Any] | str | None) -> SwarmSeedContext:
    return SwarmSeedContext.from_raw(value)


def _normalize_behavior_config(agent_node: SwarmNode) -> SwarmNodeBehaviorConfig:
    return SwarmNodeBehaviorConfig.from_raw(agent_node.behavior_config)


def _get_agent_context(
    session: SwarmSession,
    agent_node: SwarmNode,
    *,
    create: bool = False,
    behavior_config: SwarmNodeBehaviorConfig | None = None,
) -> AgentRuntimeContext | None:
    key = str(agent_node.id)
    current = session.agent_contexts.get(key)
    if isinstance(current, AgentRuntimeContext):
        return current
    if not create:
        return None

    behavior = behavior_config or _normalize_behavior_config(agent_node)
    context = AgentRuntimeContext(
        agent_name=agent_node.name,
        history_scope=behavior.history_scope,
        scratchpad_policy=behavior.scratchpad_policy,
        seed_context=_normalize_seed_context(behavior.seed_context),
    )
    session.agent_contexts[key] = context
    return context


def _build_handoff_routes(swarm: SwarmDefinition, agent_node: SwarmNode) -> List[Dict[str, Any]]:
    edges = swarm.outgoing_edges(agent_node.id)
    routes: List[Dict[str, Any]] = []
    seen_targets = set()
    for edge in edges:
        target = swarm.node_by_id(edge.target_node_id)
        if target is None:
            continue
        seen_targets.add(target.id)
        description = f"Transfer to '{target.name}'"
        if edge.handoff_description:
            description += f": {edge.handoff_description}"
        if edge.required_variables:
            description += f" Required variables before handoff: {', '.join(edge.required_variables)}."
        routes.append(
            {
                "target_agent": target.name,
                "target_node_key": target.node_key,
                "description": description,
                "required_variables": list(edge.required_variables or []),
                "target_node_id": target.id,
                "target_intent": target.intent,
            }
        )

    entry_node = swarm.entry_node()
    if entry_node and entry_node.id != agent_node.id and entry_node.id not in seen_targets:
        routes.append(
            {
                "target_agent": entry_node.name,
                "target_node_key": entry_node.node_key,
                "description": (
                    f"Transfer to '{entry_node.name}': Return to the triage agent when the user's latest request "
                    "does not match your scope, when their intent changes, or when a different specialist should take over."
                ),
                "required_variables": [],
                "target_node_id": entry_node.id,
                "target_intent": entry_node.intent,
            }
        )
    return routes


def _queue_intents_from_triage_output(*, routes: list[dict], response_text: str) -> list[dict]:
    if not routes:
        return []

    raw = str(response_text or "").strip()
    if not raw:
        return []

    candidate = raw
    if not candidate.startswith("{"):
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            candidate = match.group(0)
    try:
        parsed = json.loads(candidate)
    except Exception:
        return []
    if not isinstance(parsed, dict):
        return []

    intents = parsed.get("intents")
    if not isinstance(intents, list):
        return []

    route_by_agent = {
        str(route.get("target_agent") or "").strip().lower(): route
        for route in routes
        if str(route.get("target_agent") or "").strip()
    }
    route_by_key = {
        str(route.get("target_node_key") or "").strip().lower(): route
        for route in routes
        if str(route.get("target_node_key") or "").strip()
    }
    route_by_intent = {
        _intent_namespace(route.get("target_intent") or route.get("target_agent") or ""): route
        for route in routes
    }

    queued: list[dict] = []
    for item in intents:
        if isinstance(item, dict):
            intent_text = str(item.get("intent") or "").strip()
            target_agent = str(item.get("target_agent") or "").strip()
            target_node_key = str(item.get("target_node_key") or "").strip()
        else:
            intent_text = str(item or "").strip()
            target_agent = ""
            target_node_key = ""

        if not intent_text and not target_agent and not target_node_key:
            continue

        matched_route = None
        if target_node_key:
            matched_route = route_by_key.get(target_node_key.lower())
        if matched_route is None and target_agent:
            matched_route = route_by_agent.get(target_agent.lower())
        if matched_route is None and intent_text:
            matched_route = route_by_intent.get(_intent_namespace(intent_text))
        if matched_route is None:
            continue

        queue_item = {
            "intent": intent_text or str(matched_route.get("target_intent") or matched_route.get("target_agent") or ""),
            "target_node_key": str(matched_route.get("target_node_key") or ""),
            "target_agent": str(matched_route.get("target_agent") or ""),
        }
        if queue_item["intent"] and queue_item["target_node_key"]:
            queued.append(queue_item)

    deduped: list[dict] = []
    seen = set()
    for item in queued:
        key = (item["intent"].lower(), item["target_node_key"].lower())
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _find_tool_definition(agent_node: SwarmNode, tool_name: str) -> Dict[str, Any] | None:
    normalized = str(tool_name or "").strip()
    if not normalized:
        return None
    for tool_def in agent_node.enabled_tools or []:
        function_def = tool_def.get("function") if isinstance(tool_def, dict) else None
        candidate_name = ""
        if isinstance(function_def, dict):
            candidate_name = str(function_def.get("name") or "").strip()
        else:
            candidate_name = str(tool_def.get("name") or "").strip() if isinstance(tool_def, dict) else ""
        if candidate_name == normalized:
            return tool_def
    return None


def _is_fast_mode_enabled(agent_node: SwarmNode) -> bool:
    return _normalize_behavior_config(agent_node).fast_mode_enabled


def _fast_mode_tools(agent_node: SwarmNode) -> List[Dict[str, Any]]:
    tools: List[Dict[str, Any]] = []
    for tool_def in agent_node.enabled_tools or []:
        if isinstance(tool_def, dict) and bool(tool_def.get("fast_enabled")):
            tools.append(tool_def)
    return tools


def _fast_mode_params(tool_definition: Dict[str, Any]) -> Dict[str, str]:
    function_def = tool_definition.get("function") if isinstance(tool_definition, dict) else None
    parameters = function_def.get("parameters") if isinstance(function_def, dict) else None
    properties = parameters.get("properties") if isinstance(parameters, dict) else None
    if not isinstance(properties, dict):
        return {}
    return {
        str(name): str(schema.get("description", ""))
        for name, schema in properties.items()
        if isinstance(schema, dict) and schema.get("mode") == "fast"
    }


def _fast_tool_name(tool_definition: Dict[str, Any]) -> str:
    function_def = tool_definition.get("function") if isinstance(tool_definition, dict) else None
    if isinstance(function_def, dict):
        return str(function_def.get("name") or "").strip()
    return str((tool_definition or {}).get("name") or "").strip()


def _extract_tool_property_names(tool_definition: Dict[str, Any]) -> set[str]:
    function_def = tool_definition.get("function") if isinstance(tool_definition, dict) else None
    parameters = function_def.get("parameters") if isinstance(function_def, dict) else None
    properties = parameters.get("properties") if isinstance(parameters, dict) else None
    if not isinstance(properties, dict):
        return set()
    return {str(name).strip() for name in properties.keys() if str(name).strip()}


def _deep_merge_dicts(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge_dicts(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _resolve_fast_tool_args(tool_definition: Dict[str, Any], visible_state: Dict[str, Any]) -> Dict[str, Any]:
    tool_name = _fast_tool_name(tool_definition)
    default_args = tool_definition.get("fast_default_args") if isinstance(tool_definition.get("fast_default_args"), dict) else {}

    property_names = _extract_tool_property_names(tool_definition) - _fast_mode_params(tool_definition).keys()
    inferred_from_state = {
        str(key): copy.deepcopy(value)
        for key, value in (visible_state or {}).items()
        if str(key) in property_names
    }

    explicit_per_tool = {}
    raw_fast_params = (visible_state or {}).get("fast_tool_params")
    if isinstance(raw_fast_params, dict):
        candidate = raw_fast_params.get(tool_name)
        if isinstance(candidate, dict):
            explicit_per_tool = candidate

    merged = _deep_merge_dicts(default_args, inferred_from_state)
    return _deep_merge_dicts(merged, explicit_per_tool)


def _summarize_fast_tool_result(value: Any, *, max_chars: int = 160) -> str:
    summary = ""
    if isinstance(value, dict):
        for key in ("summary", "message", "text", "result", "status"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate.strip():
                summary = candidate.strip()
                break
    if not summary:
        try:
            summary = json.dumps(value, ensure_ascii=True, sort_keys=True)
        except TypeError:
            summary = str(value)
    compact = " ".join(summary.split())
    if len(compact) <= max_chars:
        return compact
    return compact[: max_chars - 3].rstrip() + "..."


def _build_fast_mode_response(
    *,
    agent_name: str,
    outcomes: List[Dict[str, Any]],
    include_errors: bool,
    max_chars: int,
    fast_tool_definitions: Optional[List[Dict[str, Any]]] = None,
) -> str:
    if fast_tool_definitions:
        for tool_def in fast_tool_definitions:
            if _fast_mode_params(tool_def):
                for outcome in outcomes:
                    if outcome.get("status") == "ok" and isinstance(outcome.get("result"), str):
                        text = outcome["result"].strip()
                        if len(text) <= max_chars:
                            return text
                        return text[:max_chars - 3].rstrip() + "..."
                break

    successes = [item for item in outcomes if item.get("status") == "ok"]
    failures = [item for item in outcomes if item.get("status") != "ok"]

    lines = [f"Fast mode completed {len(successes)} tool(s) for {agent_name}."]
    if successes:
        lines.append("Results:")
        for outcome in successes:
            lines.append(
                f"- {outcome.get('tool_name')}: "
                f"{_summarize_fast_tool_result(outcome.get('result'))}"
            )
    if include_errors and failures:
        lines.append("Skipped/failed:")
        for outcome in failures:
            lines.append(
                f"- {outcome.get('tool_name')}: "
                f"{_summarize_fast_tool_result(outcome.get('result'))}"
            )

    text = "\n".join(lines)
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."


async def _execute_fast_mode_tools(
    *,
    session: SwarmSession,
    current_node: SwarmNode,
    current_user_input: Union[str, MultimodalContent],
    visible_state: Dict[str, Any],
    tool_registry: ToolRegistry | None,
    tool_state: Any,
) -> List[Dict[str, Any]]:
    fast_tools = _fast_mode_tools(current_node)
    if not fast_tools:
        return []

    shared_state = resolve_tool_shared_state(tool_registry=tool_registry, tool_state=tool_state)

    async def _execute_one(tool_definition: Dict[str, Any], index: int) -> Dict[str, Any]:
        tool_name = _fast_tool_name(tool_definition) or f"tool_{index + 1}"
        tool_call_id = f"fast-{tool_name}-{index + 1}"
        tool_args = _resolve_fast_tool_args(tool_definition, visible_state)

        if tool_name == "transfer_to_agent":
            return {
                "status": "blocked",
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
                "args": tool_args,
                "result": {
                    "error": "transfer_to_agent is not allowed in fast mode.",
                    "status": "blocked",
                },
            }

        handler = resolve_tool_handler(
            agent_node=current_node,
            tool_name=tool_name,
            tool_definition=tool_definition,
            tool_registry=tool_registry,
        )
        if handler is not None:
            tool_context = ToolExecutionContext(
                session=session,
                agent_node=current_node,
                tool_name=tool_name,
                tool_args=tool_args,
                tool_call_id=tool_call_id,
                user_input=current_user_input,
                tool_definition=copy.deepcopy(tool_definition or {}),
                visible_state=copy.deepcopy(visible_state),
                shared_state=shared_state,
            )
            try:
                result = await invoke_tool_handler(handler, tool_context)
                return {
                    "status": "ok",
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "args": tool_args,
                    "result": result,
                }
            except Exception as exc:
                return {
                    "status": "error",
                    "tool_name": tool_name,
                    "tool_call_id": tool_call_id,
                    "args": tool_args,
                    "result": {"error": f"Tool '{tool_name}' execution failed: {exc}"},
                }

        if tool_definition.get("mock_response") is not None:
            return {
                "status": "ok",
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
                "args": tool_args,
                "result": copy.deepcopy(tool_definition.get("mock_response")),
            }

        return {
            "status": "error",
            "tool_name": tool_name,
            "tool_call_id": tool_call_id,
            "args": tool_args,
            "result": {"error": f"No runtime handler or mock_response configured for '{tool_name}'."},
        }

    return await asyncio.gather(*(_execute_one(tool_definition, index) for index, tool_definition in enumerate(fast_tools)))


def _tool_followup_fallback() -> str:
    return "I completed the tool step and am ready to continue."


def _stringify_transfer_context_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (dict, list)):
        try:
            return json.dumps(value, ensure_ascii=True, sort_keys=True)
        except TypeError:
            return str(value).strip()
    return str(value).strip()


def _format_resolved_variables_for_transfer_context(resolved_variables: Dict[str, Any] | None) -> str:
    if not isinstance(resolved_variables, dict):
        return ""
    parts: List[str] = []
    for key, value in resolved_variables.items():
        key_text = str(key).strip()
        value_text = _stringify_transfer_context_value(value)
        if key_text and value_text:
            parts.append(f"{key_text}={value_text}")
    return ", ".join(parts)


def _normalize_transfer_context(
    value: Any,
    *,
    reason: str = "",
    summary: str = "",
    resolved_variables: Dict[str, Any] | None = None,
) -> Dict[str, str]:
    raw_context = value if isinstance(value, dict) else {}
    normalized = {
        "why": _stringify_transfer_context_value(raw_context.get("why")),
        "what": _stringify_transfer_context_value(raw_context.get("what")),
        "who": _stringify_transfer_context_value(raw_context.get("who")),
    }
    if not normalized["why"]:
        normalized["why"] = str(reason or "").strip()
    if not normalized["what"]:
        normalized["what"] = str(summary or "").strip()
    if not normalized["who"]:
        normalized["who"] = _format_resolved_variables_for_transfer_context(resolved_variables)
    return normalized


def _build_blocked_transfer_tool_result(
    *,
    target_node: SwarmNode,
    reason: str,
    rejection_reason: str,
    missing_variables: List[str],
    transfer_context: Dict[str, str] | None = None,
) -> Dict[str, Any]:
    payload = {
        "ok": False,
        "status": "blocked",
        "error": rejection_reason,
        "rejection_reason": rejection_reason,
        "target_agent": target_node.name,
        "target_node_key": target_node.node_key,
        "reason": reason,
        "missing_variables": [str(item).strip() for item in missing_variables if str(item).strip()],
    }
    if isinstance(transfer_context, dict) and any(str(value or "").strip() for value in transfer_context.values()):
        payload["transfer_context"] = copy.deepcopy(transfer_context)
    return payload


def _build_missing_variables_rejection_reason(*, target_agent: str, missing_variables: List[str]) -> str:
    cleaned = [str(item).strip() for item in missing_variables if str(item).strip()]
    if not cleaned:
        return f"Handoff to {target_agent} was blocked because required handoff variables are still missing."
    return (
        f"Handoff to {target_agent} was blocked because the required handoff variables are still missing: "
        f"{', '.join(cleaned)}."
    )


def generate_handoff_tool_spec(swarm: SwarmDefinition, agent_node: SwarmNode) -> Dict[str, Any] | None:
    routes = _build_handoff_routes(swarm, agent_node)
    if not routes:
        return None
    route_guidance = "\n".join(
        f"- {route['target_node_key']} ({route['target_agent']}): {route['description']}" for route in routes
    )
    return {
        "type": "function",
        "function": {
            "name": "transfer_to_agent",
            "description": (
                "Transfer the conversation to another agent only after you have identified the user's intent "
                "with sufficient confidence and confirmed that the request matches the target agent's responsibility. "
                "If intent is unclear, ask a clarifying question instead of transferring. "
                "If required variables are listed for the route, collect them before calling this tool. "
                "Every transfer must include a structured transfer_context so the receiving agent does not make the user repeat details. "
                "When the latest user message already makes the right route clear, transfer in the same turn "
                "instead of replying first.\n"
                f"Available routes:\n{route_guidance}"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "target_node_key": {
                        "type": "string",
                        "enum": [route["target_node_key"] for route in routes],
                        "description": "The stable node_key of the agent to transfer to.",
                    },
                    "target_agent": {
                        "type": "string",
                        "description": "Optional display label for the target agent.",
                    },
                    "reason": {
                        "type": "string",
                        "description": "Brief explanation of why this transfer is needed.",
                    },
                    "transfer_context": {
                        "type": "object",
                        "description": (
                            "Structured context for the receiving agent. Fill all fields so the next agent understands "
                            "why the handoff is happening, what has already been learned or completed, and who the user "
                            "or relevant entity is."
                        ),
                        "properties": {
                            "why": {
                                "type": "string",
                                "description": "Why this transfer is happening right now.",
                            },
                            "what": {
                                "type": "string",
                                "description": "What the receiving agent should know, including the request summary and progress so far.",
                            },
                            "who": {
                                "type": "string",
                                "description": "Who the transfer is about, including any confirmed identifiers, customer details, or account context.",
                            },
                        },
                        "required": ["why", "what", "who"],
                    },
                },
                "required": ["target_node_key", "transfer_context"],
            },
        },
    }


def _build_handoff_guidance(swarm: SwarmDefinition, agent_node: SwarmNode) -> str:
    routes = _build_handoff_routes(swarm, agent_node)
    if not routes:
        return ""
    route_lines = []
    for route in routes:
        required = ", ".join(route["required_variables"] or []) or "none"
        route_lines.append(
            f"- {route['target_node_key']} ({route['target_agent']}): {route['description']} Required variables before handoff: {required}."
        )
    return (
        "HANDOFF RULES:\n"
        "- Do not attempt a transfer until you understand the user's intent.\n"
        "- If the user's intent is ambiguous, ask a concise clarifying question before taking any handoff action.\n"
        "- Transfer only when the identified intent clearly matches one of the downstream routes below.\n"
        "- Collect every required variable for the chosen route before transferring.\n"
        "- Every transfer_to_agent call must include transfer_context. Capture why the transfer is happening, what the next agent needs to know, and who the request concerns.\n"
        "- When the latest user message already clearly matches a route and the required variables are available, transfer in the same turn instead of narrating the routing step.\n"
        "- If the user's latest request is outside your scope or their intent changed, transfer back to the triage agent instead of ending the conversation.\n"
        + "\n".join(route_lines)
    )


def _build_agent_behavior_block(agent_node: SwarmNode) -> str:
    behavior = _normalize_behavior_config(agent_node)
    instruction_lines: List[str] = []

    if behavior.response_style == "conversational":
        instruction_lines.append("Keep the reply conversational, direct, and grounded in the user's latest request.")
    elif behavior.response_style == "formal":
        instruction_lines.append("Keep the reply professional and structured, without sounding robotic or scripted.")

    if behavior.ask_mode == "single_missing_detail":
        instruction_lines.append("Ask for only the single next missing detail needed to move the task forward.")
    elif behavior.ask_mode == "minimal_missing_details":
        instruction_lines.append("Ask for the minimum number of missing details needed for the next action, and avoid broad intake questions.")

    if behavior.next_step_policy == "concrete_first":
        instruction_lines.append("When troubleshooting, offer the next concrete step first and then ask for the minimum missing detail if needed.")

    if behavior.scratchpad_policy == "task_focused":
        instruction_lines.append("Keep your internal scratchpad focused on the latest user request, your last response, and any still-open requirements.")
    elif behavior.scratchpad_policy == "handoff_focus":
        instruction_lines.append("Keep your internal scratchpad focused on handoff intent, unresolved requirements, and what the next agent needs.")
    elif behavior.scratchpad_policy == "full_turn":
        instruction_lines.append("Keep a richer internal scratchpad for the current lane, including the latest turn details and recent tool activity.")

    if not behavior.allow_checklists:
        instruction_lines.append("Do not open with a long enterprise intake checklist unless policy, safety, or the user explicitly requires it.")
    if not behavior.allow_escalation_payloads:
        instruction_lines.append("Do not generate a human-escalation payload, incident report, or internal handoff template unless the graph, a tool result, or the user explicitly requires escalation.")

    if behavior.history_scope == "agent":
        instruction_lines.append("Treat the visible conversation history as your lane-specific context and rely on global variables plus handoff context for cross-agent state.")
    elif behavior.history_scope == "shared":
        instruction_lines.append("Use your lane history plus the cross-agent history block as read-only context when another agent already gathered relevant details.")
    elif behavior.history_scope == "full":
        instruction_lines.append("Use your lane history, cross-agent context, and the agent context contract as read-only swarm memory for this turn.")

    instruction_lines.append("If the latest user request is outside your scope or mixes multiple issues, call transfer_to_agent to triage instead of replying with a refusal.")
    return "\n\nAGENT BEHAVIOR RULES:\n" + "\n".join(f"- {line}" for line in instruction_lines)


def _build_node_contract_block(agent_node: SwarmNode) -> str:
    capabilities = ", ".join(str(item).strip() for item in (agent_node.capabilities or []) if str(item).strip()) or "none"
    persona = str(agent_node.persona or "").strip() or "none"
    intent = str(agent_node.intent or "").strip() or agent_node.name
    return (
        "\n\nNODE CONTRACT:\n"
        f"- Agent name: {agent_node.name}\n"
        f"- Node key: {agent_node.node_key}\n"
        f"- Entry node: {'yes' if agent_node.is_entry_node else 'no'}\n"
        f"- Responsibility / intent: {intent}\n"
        f"- Capabilities: {capabilities}\n"
        f"- Persona guidance: {persona}"
    )


def _serialize_history_lines(history_items: List[Dict[str, Any]], *, limit: int) -> str:
    lines: List[str] = []
    for item in history_items[-limit:]:
        role = str(item.get("role") or "user").strip() or "user"
        content = str(item.get("content") or "").strip()
        if content:
            lines.append(f"  - {role}: {content}")
    return "\n".join(lines)


def _build_history_context_block(session: SwarmSession, current_node: SwarmNode, history_scope: str) -> str:
    normalized_scope = str(history_scope or "agent").strip().lower()
    if normalized_scope not in {"shared", "full"}:
        return ""
    history_sections: List[str] = []
    current_key = str(current_node.id)
    per_agent_limit = 4 if normalized_scope == "shared" else 8
    for node_key, history_items in session.agent_histories.items():
        if not isinstance(history_items, list) or not history_items:
            continue
        if normalized_scope == "shared" and node_key == current_key:
            continue
        header = current_node.name if node_key == current_key else f"agent {node_key}"
        rendered = _serialize_history_lines(history_items, limit=per_agent_limit)
        if rendered:
            history_sections.append(f"- {header}:\n{rendered}")
    if not history_sections:
        return ""
    title = "CROSS-AGENT HISTORY (read-only)" if normalized_scope == "shared" else "FULL SWARM HISTORY (read-only)"
    return f"\n\n{title}:\n" + "\n".join(history_sections)


def _render_seed_context_lines(seed_context: SwarmSeedContext) -> List[str]:
    lines: List[str] = []
    if seed_context.summary:
        lines.append(f"- Seeded summary: {seed_context.summary}")
    if seed_context.verified_facts:
        lines.append(f"- Seeded verified facts: {', '.join(seed_context.verified_facts)}")
    if seed_context.constraints:
        lines.append(f"- Seeded constraints: {', '.join(seed_context.constraints)}")
    if seed_context.preferences:
        lines.append(f"- Seeded preferences: {', '.join(seed_context.preferences)}")
    if not lines:
        lines.append("- Seeded context: none")
    return lines


def _build_agent_context_block(session: SwarmSession, current_node: SwarmNode) -> str:
    context = _get_agent_context(session, current_node, create=False)
    if context is None:
        return ""
    scratchpad = context.scratchpad or {}
    latest_user_message = str(scratchpad.get("latest_user_message") or "").strip()
    latest_agent_response = str(scratchpad.get("latest_agent_response") or "").strip()
    open_requirements = scratchpad.get("open_requirements") or []
    recent_tool_names = scratchpad.get("recent_tool_names") or []
    open_requirements_line = ", ".join(str(item).strip() for item in open_requirements if str(item).strip()) or "none"
    recent_tool_names_line = ", ".join(str(item).strip() for item in recent_tool_names if str(item).strip()) or "none"
    seed_context_lines = "\n".join(_render_seed_context_lines(context.seed_context))
    if not (context.seed_context.has_content() or latest_user_message or latest_agent_response or open_requirements or context.last_handoff_in or context.last_handoff_out):
        return ""
    return (
        "\n\nAGENT CONTEXT CONTRACT (read-only):\n"
        f"- History scope for this agent: {context.history_scope}\n"
        f"- Scratchpad policy: {context.scratchpad_policy}\n"
        f"{seed_context_lines}\n"
        f"- Scratchpad latest user message: {latest_user_message or 'none'}\n"
        f"- Scratchpad latest agent response: {latest_agent_response or 'none'}\n"
        f"- Scratchpad open requirements: {open_requirements_line}\n"
        f"- Scratchpad recent tools: {recent_tool_names_line}\n"
        f"- Last inbound handoff reason: {str(context.last_handoff_in.get('reason') or '').strip() or 'none'}\n"
        f"- Last outbound handoff reason: {str(context.last_handoff_out.get('reason') or '').strip() or 'none'}\n"
        "- Treat this block as working context for this agent only. Update it implicitly by advancing the task, not by narrating it to the user."
    )


def _build_handoff_context_block(session: SwarmSession, current_node: SwarmNode) -> str:
    handoff_context = (session.state or {}).get("_handoff_context") or {}
    if not isinstance(handoff_context, dict):
        return ""
    target_node_key = str(handoff_context.get("target_node_key") or "").strip()
    if target_node_key:
        if target_node_key != current_node.node_key:
            return ""
    elif handoff_context.get("target_node_id") != current_node.id:
        return ""
    required_variables = handoff_context.get("required_variables") or []
    missing_variables = handoff_context.get("missing_variables") or []
    source_agent = str(handoff_context.get("from_agent") or "").strip() or "previous agent"
    handoff_summary = str(handoff_context.get("summary") or "").strip() or "none"
    transfer_context = _normalize_transfer_context(
        handoff_context.get("transfer_context"),
        reason=str(handoff_context.get("reason") or "").strip(),
        summary=handoff_summary,
        resolved_variables=handoff_context.get("resolved_variables") if isinstance(handoff_context.get("resolved_variables"), dict) else None,
    )
    required_line = ", ".join(str(item).strip() for item in required_variables if str(item).strip()) or "none"
    missing_line = ", ".join(str(item).strip() for item in missing_variables if str(item).strip()) or "none"
    return (
        "\n\nHANDOFF CONTEXT (read-only):\n"
        f"- Source agent: {source_agent}\n"
        f"- Required variables for this agent: {required_line}\n"
        f"- Missing variables after handoff: {missing_line}\n"
        f"- Why the transfer happened: {transfer_context['why'] or 'none'}\n"
        f"- What the next agent should know: {transfer_context['what'] or handoff_summary}\n"
        f"- Who is already identified: {transfer_context['who'] or 'none'}\n"
        "- Treat this block as the transferred context from the previous agent's internal state.\n"
        "- Only ask follow-up questions for variables that are still missing or for new information genuinely required to solve the request."
    )


def _build_scratchpad_for_policy(
    *,
    policy: str,
    user_input: Union[str, MultimodalContent],
    agent_response: str,
    open_requirements: List[str],
    tool_calls: List[Dict[str, Any]],
    recent_history: List[Dict[str, Any]],
    last_handoff_in: Dict[str, Any],
    last_handoff_out: Dict[str, Any],
) -> Dict[str, Any]:
    normalized_policy = str(policy or "task_focused").strip().lower()
    if normalized_policy == "disabled":
        return {}
    recent_tool_names = [
        str(item.get("name") or "").strip()
        for item in tool_calls
        if str(item.get("name") or "").strip() and str(item.get("name") or "").strip() != "transfer_to_agent"
    ]
    scratchpad: Dict[str, Any] = {
        "latest_user_message": extract_text_from_content(user_input).strip(),
        "open_requirements": [str(item).strip() for item in open_requirements if str(item).strip()],
    }
    if normalized_policy in {"task_focused", "full_turn"}:
        scratchpad["latest_agent_response"] = str(agent_response or "").strip()
    if normalized_policy in {"handoff_focus", "full_turn"}:
        if last_handoff_in:
            scratchpad["last_inbound_handoff"] = copy.deepcopy(last_handoff_in)
        if last_handoff_out:
            scratchpad["last_outbound_handoff"] = copy.deepcopy(last_handoff_out)
    if normalized_policy == "full_turn":
        scratchpad["recent_tool_names"] = recent_tool_names
        scratchpad["recent_turns"] = copy.deepcopy(recent_history[-4:])
    return scratchpad


def _update_agent_context_for_turn(
    *,
    session: SwarmSession,
    agent_node: SwarmNode,
    user_input: Union[str, MultimodalContent],
    agent_response: str,
    open_requirements: List[str] | None = None,
    tool_calls: List[Dict[str, Any]] | None = None,
) -> None:
    behavior = _normalize_behavior_config(agent_node)
    context = _get_agent_context(session, agent_node, create=True, behavior_config=behavior)
    assert context is not None
    recent_history = (session.agent_histories or {}).get(str(agent_node.id), [])
    context.agent_name = agent_node.name
    context.history_scope = behavior.history_scope
    context.scratchpad_policy = behavior.scratchpad_policy
    context.seed_context = behavior.seed_context
    context.scratchpad = _build_scratchpad_for_policy(
        policy=context.scratchpad_policy,
        user_input=user_input,
        agent_response=agent_response,
        open_requirements=[str(item).strip() for item in (open_requirements or []) if str(item).strip()],
        tool_calls=list(tool_calls or []),
        recent_history=recent_history,
        last_handoff_in=context.last_handoff_in,
        last_handoff_out=context.last_handoff_out,
    )


def _build_system_instruction(session: SwarmSession, agent_node: SwarmNode) -> str:
    behavior = _normalize_behavior_config(agent_node)
    agent_context = _get_agent_context(session, agent_node, create=True, behavior_config=behavior)
    prompt_context = SystemPromptContext(
        session=session,
        swarm=session.swarm,
        agent_node=agent_node,
        visible_state=_visible_state(session, current_node=agent_node),
        agent_context=agent_context,
    )
    resolved_system_prompt = invoke_system_prompt_builder(agent_node.system_prompt, prompt_context)
    blocks = [resolved_system_prompt]
    blocks.append(_build_node_contract_block(agent_node))
    handoff_guidance = _build_handoff_guidance(session.swarm, agent_node)
    if handoff_guidance:
        blocks.append(handoff_guidance)
    blocks.append(_build_agent_behavior_block(agent_node))
    agent_context = _build_agent_context_block(session, agent_node)
    if agent_context:
        blocks.append(agent_context)
    handoff_context = _build_handoff_context_block(session, agent_node)
    if handoff_context:
        blocks.append(handoff_context)
    history_context = _build_history_context_block(session, agent_node, behavior.history_scope)
    if history_context:
        blocks.append(history_context)
    return "\n".join(block for block in blocks if block)


def _has_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict, tuple, set)):
        return bool(value)
    return True


async def apply_reducer(
    session: SwarmSession,
    key: str,
    value: Any,
    *,
    state_manager: SessionStateManager | None = None,
    global_variable_manager: SessionStateManager | None = None,
) -> None:
    resolved_state_manager = state_manager or global_variable_manager or SessionStateManager.from_swarm(session.swarm)
    resolved_state_manager.apply_value(session, key, value, current_node=session.current_node)


async def create_checkpoint(
    store: SessionStore,
    session: SwarmSession,
    acting_node: SwarmNode | None,
    action_type: str,
    extra_snapshot: Dict[str, Any] | None = None,
) -> SessionCheckpoint:
    existing = await store.list_checkpoints(session.id)
    next_step = (existing[-1].step_number if existing else 0) + 1
    snapshot = session.snapshot()
    if extra_snapshot:
        snapshot.update(copy.deepcopy(extra_snapshot))
    checkpoint = SessionCheckpoint(
        session_id=session.id,
        acting_node_id=acting_node.id if acting_node else None,
        step_number=next_step,
        action_type=action_type,
        state_snapshot=snapshot,
    )
    return await store.append_checkpoint(checkpoint)


def _handoff_edge_for(swarm: SwarmDefinition, from_node: SwarmNode, to_node: SwarmNode) -> SwarmEdge | None:
    for edge in swarm.outgoing_edges(from_node.id):
        if edge.target_node_id == to_node.id:
            return edge
    return None


def _summarize_previous_turns(session: SwarmSession, from_node: SwarmNode | None = None, limit: int = 6) -> str:
    lines: List[str] = []
    if from_node is not None:
        for item in (session.agent_histories.get(str(from_node.id), []) or [])[-limit:]:
            role = str(item.get("role") or "").strip()
            content = str(item.get("content") or "").strip()
            if role and content:
                lines.append(f"{role}: {content}")
    if not lines:
        for history_items in session.agent_histories.values():
            for item in history_items[-max(1, limit // 2):]:
                role = str(item.get("role") or "").strip()
                content = str(item.get("content") or "").strip()
                if role and content:
                    lines.append(f"{role}: {content}")
            if lines:
                break
    if not lines:
        return "No prior summary available."
    return " | ".join(lines[-limit:])[:600]


async def _default_required_variable_extractor(**_: Any) -> Dict[str, Any]:
    return {}


async def process_swarm_stream(
    session: SwarmSession,
    user_input: Union[str, MultimodalContent],
    *,
    store: SessionStore,
    turn_runner: AgentTurnRunner,
    extract_required_variables: RequiredVariableExtractor | None = None,
    state_manager: SessionStateManager | None = None,
    global_variable_manager: SessionStateManager | None = None,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
    max_handoffs: int = MAX_HANDOFFS,
    max_tool_iterations: int = MAX_TOOL_ITERATIONS,
) -> AsyncGenerator[Dict[str, Any], None]:
    """Process one user turn through the active swarm session."""

    extractor = extract_required_variables or _default_required_variable_extractor
    state_manager = state_manager or global_variable_manager or SessionStateManager.from_swarm(session.swarm)
    current_node = session.current_node
    if current_node is None:
        raise ValueError("Session has no current node and swarm has no entry node")

    yield {
        "event": "open",
        "data": {
            "sessionId": session.id,
            "currentAgent": current_node.name,
        },
    }

    handoff_count = 0
    current_user_input = user_input
    while handoff_count <= max_handoffs:
        current_node = session.current_node
        if current_node is None:
            break

        if current_node.is_entry_node:
            queued_intent = _pop_next_intent(session)
            if queued_intent is not None:
                queued_target_node_key = str(queued_intent.get("target_node_key") or "").strip()
                queued_target_name = str(queued_intent.get("target_agent") or "").strip()
                queued_intent_label = str(queued_intent.get("intent") or "").strip()
                target_node = (
                    session.swarm.node_by_key(queued_target_node_key)
                    if queued_target_node_key
                    else session.swarm.node_by_name(queued_target_name)
                )
                if target_node is not None:
                    handoff_reason = f"Continue queued intent: {queued_intent_label or queued_target_name}"
                    summary = _summarize_previous_turns(session, current_node)
                    transfer_context = _normalize_transfer_context({}, reason=handoff_reason, summary=summary)
                    summary = transfer_context["what"] or summary
                    session.state["_handoff_context"] = {
                        "from_agent": current_node.name,
                        "to_agent": target_node.name,
                        "target_node_id": target_node.id,
                        "target_node_key": target_node.node_key,
                        "required_variables": [],
                        "missing_variables": [],
                        "resolved_variables": {},
                        "reason": handoff_reason,
                        "summary": summary,
                        "transfer_context": copy.deepcopy(transfer_context),
                    }
                    source_context = _get_agent_context(session, current_node, create=True)
                    target_context = _get_agent_context(session, target_node, create=True)
                    assert source_context is not None and target_context is not None
                    source_context.last_handoff_out = {"to": target_node.name, "reason": handoff_reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                    target_context.last_handoff_in = {"from": current_node.name, "reason": handoff_reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                    session.current_node_id = target_node.id
                    _set_active_intent(session, intent=queued_intent_label or target_node.intent or target_node.name)
                    await create_checkpoint(
                        store,
                        session,
                        current_node,
                        "handoff",
                        extra_snapshot={
                            "handoff": {
                                "from": current_node.name,
                                "to": target_node.name,
                                "from_node_key": current_node.node_key,
                                "to_node_key": target_node.node_key,
                                "handoff_type": "queued_intent",
                                "required_variables": [],
                                "resolved_variables": {},
                                "missing_variables": [],
                                "reason": handoff_reason,
                                "summary": summary,
                                "transfer_context": copy.deepcopy(transfer_context),
                            }
                        },
                    )
                    await store.save_session(session)
                    yield {
                        "event": "handoff",
                        "data": {
                            "from": current_node.name,
                            "to": target_node.name,
                            "fromNodeKey": current_node.node_key,
                            "toNodeKey": target_node.node_key,
                            "reason": handoff_reason,
                            "handoffType": "queued_intent",
                            "requiredVariables": [],
                            "resolvedVariables": {},
                            "globalVariables": state_manager.visible(session, current_node=target_node),
                            "state": state_manager.visible_state(session, current_node=target_node),
                            "handoffSummary": summary,
                            "transferContext": copy.deepcopy(transfer_context),
                        },
                    }
                    handoff_count += 1
                    continue

        _set_active_intent(session, current_node=current_node)

        node_history = session.agent_histories.setdefault(str(current_node.id), [])
        node_history.append({
            "role": "user",
            "content": _build_user_message_content(current_user_input, prefix="<USER_MESSAGE>\n"),
        })

        clean_tools, mock_matcher = _node_tools(current_node)
        handoff_tool = generate_handoff_tool_spec(session.swarm, current_node)
        tools_for_turn = list(clean_tools)
        if handoff_tool is not None:
            tools_for_turn.append(handoff_tool)

        if _is_fast_mode_enabled(current_node):
            visible_state = state_manager.visible_state(session, current_node=current_node)
            fast_outcomes = await _execute_fast_mode_tools(
                session=session,
                current_node=current_node,
                current_user_input=current_user_input,
                visible_state=visible_state,
                tool_registry=tool_registry,
                tool_state=tool_state,
            )
            if fast_outcomes:
                behavior = _normalize_behavior_config(current_node)
                for outcome in fast_outcomes:
                    node_history.append(
                        {
                            "role": "tool",
                            "name": str(outcome.get("tool_name") or ""),
                            "tool_call_id": str(outcome.get("tool_call_id") or ""),
                            "content": json.dumps(outcome.get("result")) if outcome.get("result") is not None else "null",
                        }
                    )

                fast_response = _build_fast_mode_response(
                    agent_name=current_node.name,
                    outcomes=fast_outcomes,
                    include_errors=behavior.fast_mode_include_errors,
                    max_chars=behavior.fast_mode_summary_max_chars,
                    fast_tool_definitions=_fast_mode_tools(current_node),
                )
                node_history.append({"role": "model", "content": fast_response})
                synthetic_tool_calls = [
                    {
                        "id": str(outcome.get("tool_call_id") or ""),
                        "name": str(outcome.get("tool_name") or ""),
                        "args": copy.deepcopy(outcome.get("args") or {}),
                    }
                    for outcome in fast_outcomes
                ]
                _update_agent_context_for_turn(
                    session=session,
                    agent_node=current_node,
                    user_input=current_user_input,
                    agent_response=fast_response,
                    open_requirements=[],
                    tool_calls=synthetic_tool_calls,
                )
                await create_checkpoint(
                    store,
                    session,
                    current_node,
                    "fast_mode_response",
                    extra_snapshot={
                        "fast_mode": {
                            "agent_name": current_node.name,
                            "results": copy.deepcopy(fast_outcomes),
                        }
                    },
                )
                await store.save_session(session)
                yield {
                    "event": "fast_tool_use",
                    "data": {
                        "agentName": current_node.name,
                        "results": copy.deepcopy(fast_outcomes),
                    },
                }
                yield {"event": "done", "data": {"fullText": fast_response, "agentName": current_node.name}}
                return

        full_text = ""
        final_tool_calls: List[Dict[str, Any]] = []
        handoff_routes = _build_handoff_routes(session.swarm, current_node)
        tool_iteration_count = 0

        while True:
            config = AgentTurnConfig(
                system_instruction=_build_system_instruction(session, current_node),
                tools=tools_for_turn,
                visible_state=state_manager.visible_state(session, current_node=current_node),
                behavior_config=_normalize_behavior_config(current_node).to_dict(),
            )
            turn_result: AgentTurnResult
            if isinstance(turn_runner, StreamingAgentTurnRunner):
                async for text_chunk, result in turn_runner.stream_turn(
                    agent_node=current_node,
                    contents=list(node_history),
                    config=config,
                ):
                    if text_chunk is not None:
                        yield {
                            "event": "text_chunk",
                            "data": {"text_chunk": text_chunk, "agentName": current_node.name},
                        }
                    elif result is not None:
                        turn_result = result
            else:
                turn_result = await turn_runner.run_turn(
                    agent_node=current_node,
                    contents=list(node_history),
                    config=config,
                )

            response_text = str(turn_result.response_text or "")
            tool_calls = list(turn_result.tool_calls or [])

            if tool_calls:
                yield {
                    "event": "tool_use",
                    "data": {
                        "agentName": current_node.name,
                        "functionCalls": copy.deepcopy(tool_calls),
                    },
                }
                final_tool_calls.extend(tool_calls)

            transfer_call = next((call for call in tool_calls if str(call.get("name") or "") == "transfer_to_agent"), None)
            if transfer_call is not None:
                args = transfer_call.get("args") or {}
                target_node_key = str(args.get("target_node_key") or "").strip()
                target_agent = str(args.get("target_agent") or "").strip()
                reason = str(args.get("reason") or "").strip()
                target_node = session.swarm.node_by_key(target_node_key) if target_node_key else session.swarm.node_by_name(target_agent)
                if target_node is None:
                    missing_target = target_node_key or target_agent
                    response_text = f"I could not find the requested target agent '{missing_target}'."
                    full_text = response_text
                    node_history.append({"role": "model", "content": response_text})
                    _update_agent_context_for_turn(
                        session=session,
                        agent_node=current_node,
                        user_input=current_user_input,
                        agent_response=response_text,
                        open_requirements=[],
                        tool_calls=final_tool_calls,
                    )
                    await create_checkpoint(store, session, current_node, "agent_response")
                    await store.save_session(session)
                    yield {"event": "done", "data": {"fullText": response_text, "agentName": current_node.name}}
                    return

                edge = _handoff_edge_for(session.swarm, current_node, target_node)
                extracted_variables = await extractor(
                    session=session,
                    agent_node=current_node,
                    edge=edge,
                    user_input=current_user_input,
                    agent_response=response_text,
                ) if edge is not None else {}
                for key, value in (extracted_variables or {}).items():
                    await apply_reducer(session, key, value, state_manager=state_manager)

                missing_required = []
                if edge is not None:
                    missing_required = [
                        key
                        for key in (edge.required_variables or [])
                        if not _has_value(_get_scoped_variable(session, key, current_node=current_node))
                    ]

                summary = _summarize_previous_turns(session, current_node)
                transfer_context = _normalize_transfer_context(
                    args.get("transfer_context"),
                    reason=reason,
                    summary=summary,
                    resolved_variables=copy.deepcopy(extracted_variables or {}),
                )
                summary = transfer_context["what"] or summary

                if missing_required:
                    clarification = (
                        f"Before I transfer you to {target_node.name}, I still need: {', '.join(missing_required)}."
                    )
                    blocked_tool_result = _build_blocked_transfer_tool_result(
                        target_node=target_node,
                        reason=reason,
                        rejection_reason=_build_missing_variables_rejection_reason(
                            target_agent=target_node.name,
                            missing_variables=missing_required,
                        ),
                        missing_variables=missing_required,
                        transfer_context=transfer_context,
                    )
                    _set_active_intent(session, current_node=current_node)
                    _update_agent_context_for_turn(
                        session=session,
                        agent_node=current_node,
                        user_input=current_user_input,
                        agent_response=response_text,
                        open_requirements=missing_required,
                        tool_calls=final_tool_calls,
                    )
                    await create_checkpoint(
                        store,
                        session,
                        current_node,
                        "handoff_blocked",
                        extra_snapshot={
                            "handoff": {
                                "from": current_node.name,
                                "to": target_node.name,
                                "from_node_key": current_node.node_key,
                                "to_node_key": target_node.node_key,
                                "handoff_type": "blocked",
                                "reason": reason,
                                "missing_variables": missing_required,
                                "resolved_variables": copy.deepcopy(extracted_variables or {}),
                                "summary": summary,
                                "transfer_context": copy.deepcopy(transfer_context),
                            }
                        },
                    )
                    await store.save_session(session)
                    yield {
                        "event": "handoff_blocked",
                        "data": {
                            "from": current_node.name,
                            "to": target_node.name,
                            "fromNodeKey": current_node.node_key,
                            "toNodeKey": target_node.node_key,
                            "reason": reason,
                            "handoffType": "blocked",
                            "missingVariables": missing_required,
                            "resolvedVariables": copy.deepcopy(extracted_variables or {}),
                            "globalVariables": state_manager.visible(session, current_node=current_node),
                            "state": state_manager.visible_state(session, current_node=current_node),
                            "handoffSummary": summary,
                            "transferContext": copy.deepcopy(transfer_context),
                        },
                    }
                    node_history.append(
                        {
                            "role": "tool",
                            "name": "transfer_to_agent",
                            "tool_call_id": str(transfer_call.get("id") or ""),
                            "content": json.dumps(blocked_tool_result),
                        }
                    )
                    await store.save_session(session)
                    tool_iteration_count += 1
                    if tool_iteration_count >= max_tool_iterations:
                        response_text = _tool_followup_fallback()
                        full_text = response_text
                        node_history.append({"role": "model", "content": response_text})
                        _update_agent_context_for_turn(
                            session=session,
                            agent_node=current_node,
                            user_input=current_user_input,
                            agent_response=response_text,
                            open_requirements=missing_required,
                            tool_calls=final_tool_calls,
                        )
                        await create_checkpoint(store, session, current_node, "agent_response")
                        await store.save_session(session)
                        yield {"event": "done", "data": {"fullText": response_text, "agentName": current_node.name}}
                        return
                    continue

                session.state["_handoff_context"] = {
                    "from_agent": current_node.name,
                    "to_agent": target_node.name,
                    "target_node_id": target_node.id,
                    "target_node_key": target_node.node_key,
                    "required_variables": list((edge.required_variables if edge else []) or []),
                    "missing_variables": list(missing_required),
                    "resolved_variables": copy.deepcopy(extracted_variables or {}),
                    "reason": reason,
                    "summary": summary,
                    "transfer_context": copy.deepcopy(transfer_context),
                }
                source_context = _get_agent_context(session, current_node, create=True)
                target_context = _get_agent_context(session, target_node, create=True)
                assert source_context is not None and target_context is not None
                source_context.last_handoff_out = {"to": target_node.name, "reason": reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                target_context.last_handoff_in = {"from": current_node.name, "reason": reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                session.current_node_id = target_node.id
                _set_active_intent(session, intent=target_node.intent or target_node.name)
                await create_checkpoint(
                    store,
                    session,
                    current_node,
                    "handoff",
                        extra_snapshot={
                            "handoff": {
                                "from": current_node.name,
                                "to": target_node.name,
                                "from_node_key": current_node.node_key,
                                "to_node_key": target_node.node_key,
                                "handoff_type": "agent_transfer",
                                "reason": reason,
                                "summary": summary,
                                "transfer_context": copy.deepcopy(transfer_context),
                                "resolved_variables": copy.deepcopy(extracted_variables or {}),
                                "required_variables": list((edge.required_variables if edge else []) or []),
                            }
                        },
                )
                await store.save_session(session)
                yield {
                    "event": "handoff",
                    "data": {
                        "from": current_node.name,
                        "to": target_node.name,
                        "fromNodeKey": current_node.node_key,
                        "toNodeKey": target_node.node_key,
                        "reason": reason,
                        "handoffType": "agent_transfer",
                        "requiredVariables": list((edge.required_variables if edge else []) or []),
                        "resolvedVariables": copy.deepcopy(extracted_variables or {}),
                        "globalVariables": state_manager.visible(session, current_node=target_node),
                        "state": state_manager.visible_state(session, current_node=target_node),
                        "handoffSummary": summary,
                        "transferContext": copy.deepcopy(transfer_context),
                    },
                }
                handoff_count += 1
                break

            non_handoff_calls = [call for call in tool_calls if str(call.get("name") or "") != "transfer_to_agent"]
            if non_handoff_calls:
                unresolved_call = None
                unresolved_tool = None
                for tool_call in non_handoff_calls:
                    tool_name = str(tool_call.get("name") or "").strip()
                    tool_definition = _find_tool_definition(current_node, tool_name)
                    handler = resolve_tool_handler(
                        agent_node=current_node,
                        tool_name=tool_name,
                        tool_definition=tool_definition,
                        tool_registry=tool_registry,
                    )
                    if tool_definition is not None and handler is None and tool_definition.get("mock_response") is None:
                        unresolved_call = tool_call
                        unresolved_tool = tool_definition
                        break

                if unresolved_call is not None:
                    await create_checkpoint(
                        store,
                        session,
                        current_node,
                        "tool_mock_required",
                        extra_snapshot={
                            "tool_mock": {
                                "agent_name": current_node.name,
                                "node_key": current_node.node_key,
                                "tool_name": (unresolved_tool or {}).get("function", {}).get("name")
                                or (unresolved_tool or {}).get("name")
                                or unresolved_call.get("name")
                                or "",
                                "tool_args": copy.deepcopy(unresolved_call.get("args", {}) or {}),
                            }
                        },
                    )
                    await store.save_session(session)
                    yield {
                        "event": "tool_mock_required",
                        "data": {
                            "agentName": current_node.name,
                            "nodeKey": current_node.node_key,
                            "nodeId": current_node.id,
                            "toolName": (unresolved_tool or {}).get("function", {}).get("name")
                            or (unresolved_tool or {}).get("name")
                            or unresolved_call.get("name")
                            or "",
                            "toolDescription": ((unresolved_tool or {}).get("function", {}) or {}).get("description")
                            or (unresolved_tool or {}).get("description")
                            or "",
                            "toolParameters": ((unresolved_tool or {}).get("function", {}) or {}).get("parameters")
                            or (unresolved_tool or {}).get("parameters")
                            or {},
                            "existingMockResponse": copy.deepcopy((unresolved_tool or {}).get("mock_response") or {}),
                            "functionCall": {
                                "id": unresolved_call.get("id"),
                                "name": unresolved_call.get("name"),
                                "args": copy.deepcopy(unresolved_call.get("args", {}) or {}),
                            },
                            "message": "Mock data is required before this tool can run.",
                        },
                    }
                    return

                for tool_call in non_handoff_calls:
                    tool_result = {"error": f"No tool mocking configured for '{tool_call.get('name')}'"}
                    tool_name = str(tool_call.get("name") or "")
                    tool_definition = _find_tool_definition(current_node, tool_name)
                    handler = resolve_tool_handler(
                        agent_node=current_node,
                        tool_name=tool_name,
                        tool_definition=tool_definition,
                        tool_registry=tool_registry,
                    )
                    if handler is not None:
                        tool_context = ToolExecutionContext(
                            session=session,
                            agent_node=current_node,
                            tool_name=tool_name,
                            tool_args=copy.deepcopy(tool_call.get("args") or {}),
                            tool_call_id=str(tool_call.get("id") or ""),
                            user_input=current_user_input,
                            tool_definition=copy.deepcopy(tool_definition or {}),
                            visible_state=state_manager.visible_state(session, current_node=current_node),
                            shared_state=resolve_tool_shared_state(tool_registry=tool_registry, tool_state=tool_state),
                        )
                        try:
                            tool_result = await invoke_tool_handler(handler, tool_context)
                        except Exception as exc:
                            tool_result = {"error": f"Tool '{tool_name}' execution failed: {exc}"}
                    elif mock_matcher is not None:
                        tool_result = mock_matcher.get_mock_result(
                            tool_call_id=str(tool_call.get("id") or ""),
                            tool_name=tool_name,
                            arguments=json.dumps(tool_call.get("args") or {}),
                        )
                    node_history.append(
                        {
                            "role": "tool",
                            "name": tool_name,
                            "tool_call_id": str(tool_call.get("id") or ""),
                            "content": json.dumps(tool_result) if tool_result is not None else "null",
                        }
                    )
                tool_iteration_count += 1
                if tool_iteration_count >= max_tool_iterations:
                    response_text = _tool_followup_fallback()
                    full_text = response_text
                    node_history.append({"role": "model", "content": response_text})
                    _update_agent_context_for_turn(
                        session=session,
                        agent_node=current_node,
                        user_input=current_user_input,
                        agent_response=response_text,
                        open_requirements=[],
                        tool_calls=final_tool_calls,
                    )
                    await create_checkpoint(store, session, current_node, "agent_response")
                    await store.save_session(session)
                    yield {"event": "done", "data": {"fullText": response_text, "agentName": current_node.name}}
                    return
                continue

            full_text = response_text
            node_history.append({"role": "model", "content": response_text})
            _update_agent_context_for_turn(
                session=session,
                agent_node=current_node,
                user_input=current_user_input,
                agent_response=response_text,
                open_requirements=[],
                tool_calls=final_tool_calls,
            )
            await create_checkpoint(store, session, current_node, "agent_response")
            queued_intents = _queue_intents_from_triage_output(routes=handoff_routes, response_text=response_text) if current_node.is_entry_node else []
            if queued_intents:
                _set_intent_stack(session, queued_intents)
                await store.save_session(session)
                break

            pending_intents = _get_intent_stack(session, create=False)
            if pending_intents and not current_node.is_entry_node and handoff_count < max_handoffs:
                entry_node = session.swarm.entry_node()
                if entry_node is not None and entry_node.id != current_node.id:
                    reason = "Returning to triage to continue queued intents."
                    summary = _summarize_previous_turns(session, current_node)
                    transfer_context = _normalize_transfer_context({}, reason=reason, summary=summary)
                    summary = transfer_context["what"] or summary
                    session.state["_handoff_context"] = {
                        "from_agent": current_node.name,
                        "to_agent": entry_node.name,
                        "target_node_id": entry_node.id,
                        "target_node_key": entry_node.node_key,
                        "required_variables": [],
                        "missing_variables": [],
                        "resolved_variables": {},
                        "reason": reason,
                        "summary": summary,
                        "transfer_context": copy.deepcopy(transfer_context),
                    }
                    source_context = _get_agent_context(session, current_node, create=True)
                    target_context = _get_agent_context(session, entry_node, create=True)
                    assert source_context is not None and target_context is not None
                    source_context.last_handoff_out = {"to": entry_node.name, "reason": reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                    target_context.last_handoff_in = {"from": current_node.name, "reason": reason, "summary": summary, "transfer_context": copy.deepcopy(transfer_context)}
                    session.current_node_id = entry_node.id
                    await create_checkpoint(
                        store,
                        session,
                        current_node,
                        "handoff",
                        extra_snapshot={
                            "handoff": {
                                "from": current_node.name,
                                "to": entry_node.name,
                                "from_node_key": current_node.node_key,
                                "to_node_key": entry_node.node_key,
                                "handoff_type": "agent_transfer",
                                "reason": reason,
                                "summary": summary,
                                "transfer_context": copy.deepcopy(transfer_context),
                                "resolved_variables": {},
                                "required_variables": [],
                            }
                        },
                    )
                    await store.save_session(session)
                    yield {
                        "event": "handoff",
                        "data": {
                            "from": current_node.name,
                            "to": entry_node.name,
                            "fromNodeKey": current_node.node_key,
                            "toNodeKey": entry_node.node_key,
                            "reason": reason,
                            "handoffType": "agent_transfer",
                            "requiredVariables": [],
                            "resolvedVariables": {},
                            "globalVariables": state_manager.visible(session, current_node=entry_node),
                            "state": state_manager.visible_state(session, current_node=entry_node),
                            "handoffSummary": summary,
                            "transferContext": copy.deepcopy(transfer_context),
                        },
                    }
                    handoff_count += 1
                    break

            await store.save_session(session)
            yield {"event": "done", "data": {"fullText": full_text, "agentName": current_node.name}}
            return

    raise RuntimeError("Max handoffs exceeded")
