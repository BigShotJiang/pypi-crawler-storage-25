"""Helpers for defining and executing runtime tool handlers."""

from __future__ import annotations

import copy
import inspect
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Mapping

from pydantic import create_model

from .models import SwarmNode, SwarmSession


RUNTIME_ONLY_TOOL_KEYS = {"mock_response", "handler", "fast_enabled", "fast_default_args"}
ToolExecutor = Callable[..., Any]
ToolRegistry = Mapping[str, ToolExecutor]
_UNSET = object()
INJECTED_TOOL_PARAM_NAMES = {
    "agent_node",
    "context",
    "session",
    "shared_state",
    "state",
    "visible_state",
    "tool_args",
    "tool_definition",
    "tool_name",
    "tool_call_id",
    "user_input",
    "visible_global_variables",
}


@dataclass
class ToolExecutionContext:
    """Execution context passed to runtime tool handlers."""

    session: SwarmSession
    agent_node: SwarmNode
    tool_name: str
    tool_args: Dict[str, Any] = field(default_factory=dict)
    tool_call_id: str = ""
    user_input: str = ""
    tool_definition: Dict[str, Any] = field(default_factory=dict)
    visible_state: Dict[str, Any] = field(default_factory=dict)
    shared_state: Any = None

    @property
    def visible_global_variables(self) -> Dict[str, Any]:
        return self.visible_state

    @property
    def state(self) -> Dict[str, Any]:
        return self.visible_state


def _docstring_parts(handler: ToolExecutor) -> tuple[str, Dict[str, str]]:
    raw = inspect.getdoc(handler) or ""
    if not raw.strip():
        return "", {}

    lines = raw.splitlines()
    summary_lines: list[str] = []
    for index, line in enumerate(lines):
        stripped = line.strip()
        next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
        if not stripped:
            break
        if stripped.startswith(":param "):
            break
        if stripped in {"Args:", "Arguments:", "Parameters:"}:
            break
        if stripped == "Parameters" and set(next_line) == {"-"}:
            break
        summary_lines.append(stripped)

    summary = " ".join(summary_lines).strip()
    parameter_docs: Dict[str, str] = {}

    current_param = ""
    for line in lines:
        match = re.match(r"\s*:param\s+(\w+)\s*:\s*(.*)", line)
        if match:
            current_param = match.group(1)
            parameter_docs[current_param] = match.group(2).strip()
            continue
        if current_param and line.startswith("    "):
            continuation = line.strip()
            if continuation:
                parameter_docs[current_param] = f"{parameter_docs[current_param]} {continuation}".strip()
            continue
        current_param = ""

    def consume_google_or_numpy_block(start_index: int, *, numpy_style: bool) -> None:
        current_name = ""
        index = start_index
        while index < len(lines):
            line = lines[index]
            stripped = line.strip()
            if not stripped:
                if current_name:
                    current_name = ""
                index += 1
                continue
            if not numpy_style and re.match(r"^[A-Z][A-Za-z ]+:$", stripped):
                break
            if numpy_style and stripped and not line.startswith(" ") and ":" not in stripped:
                break

            if numpy_style:
                entry = re.match(r"^\s*(\w+)\s*:\s*(.*)$", line)
                if entry:
                    current_name = entry.group(1)
                    parameter_docs.setdefault(current_name, "")
                    index += 1
                    while index < len(lines) and lines[index].startswith("    "):
                        continuation = lines[index].strip()
                        if continuation:
                            parameter_docs[current_name] = f"{parameter_docs[current_name]} {continuation}".strip()
                        index += 1
                    continue
            else:
                entry = re.match(r"^\s*(\w+)(?:\s*\([^)]*\))?\s*:\s*(.*)$", line)
                if entry:
                    current_name = entry.group(1)
                    parameter_docs[current_name] = entry.group(2).strip()
                    index += 1
                    while index < len(lines) and (lines[index].startswith("    ") or lines[index].startswith("\t")):
                        if re.match(r"^\s*(\w+)(?:\s*\([^)]*\))?\s*:\s*(.*)$", lines[index]):
                            break
                        continuation = lines[index].strip()
                        if continuation:
                            parameter_docs[current_name] = f"{parameter_docs[current_name]} {continuation}".strip()
                        index += 1
                    continue
            index += 1

    for index, line in enumerate(lines):
        stripped = line.strip()
        next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
        if stripped in {"Args:", "Arguments:", "Parameters:"}:
            consume_google_or_numpy_block(index + 1, numpy_style=False)
        if stripped == "Parameters" and set(next_line) == {"-"}:
            consume_google_or_numpy_block(index + 2, numpy_style=True)

    cleaned_param_docs = {
        key: re.sub(r"\s+", " ", value).strip()
        for key, value in parameter_docs.items()
        if re.sub(r"\s+", " ", value).strip()
    }
    return summary, cleaned_param_docs


def infer_tool_parameters(handler: ToolExecutor) -> Dict[str, Any]:
    """Infer an OpenAI-style JSON schema from a Python callable."""

    signature = inspect.signature(handler)
    field_definitions: Dict[str, tuple[Any, Any]] = {}
    for parameter in signature.parameters.values():
        if parameter.name in {"self", "cls"} or parameter.name in INJECTED_TOOL_PARAM_NAMES:
            continue
        if parameter.kind in {inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD}:
            continue
        annotation = parameter.annotation if parameter.annotation is not inspect.Signature.empty else Any
        default = parameter.default if parameter.default is not inspect.Signature.empty else ...
        field_definitions[parameter.name] = (annotation, default)

    if not field_definitions:
        return {"type": "object", "properties": {}}

    model = create_model(
        f"{handler.__name__.title().replace('_', '')}ToolParameters",
        **field_definitions,
    )
    schema = model.model_json_schema()
    schema.pop("title", None)
    properties = schema.get("properties") or {}
    for property_schema in properties.values():
        if isinstance(property_schema, dict):
            property_schema.pop("title", None)

    _summary, parameter_docs = _docstring_parts(handler)
    for parameter_name, description in parameter_docs.items():
        property_schema = properties.get(parameter_name)
        if isinstance(property_schema, dict) and description and not property_schema.get("description"):
            property_schema["description"] = description

    return schema


def infer_function_tool(handler: ToolExecutor, *, name: str | None = None, description: str | None = None) -> Dict[str, Any]:
    """Build a function tool definition directly from a Python callable."""

    summary, _parameter_docs = _docstring_parts(handler)
    resolved_name = str(name or getattr(handler, "__name__", "") or "").strip()
    resolved_description = str(description or summary or f"Run the {resolved_name} tool.").strip()
    return function_tool(
        name=resolved_name,
        description=resolved_description,
        parameters=infer_tool_parameters(handler),
        handler=handler,
    )


def function_tool(
    *,
    name: str | None = None,
    description: str | None = None,
    parameters: Dict[str, Any] | None = None,
    handler: ToolExecutor | None = None,
    mock_response: Any = _UNSET,
) -> Dict[str, Any]:
    """Build a function tool definition with an optional runtime handler."""

    summary, _parameter_docs = _docstring_parts(handler) if handler is not None else ("", {})
    resolved_name = str(name or getattr(handler, "__name__", "") or "").strip()
    if not resolved_name:
        raise ValueError("Function tools require a name or a handler with a __name__ attribute.")
    resolved_description = str(description or summary or f"Run the {resolved_name} tool.").strip()

    resolved_parameters = copy.deepcopy(parameters) if isinstance(parameters, dict) else (
        infer_tool_parameters(handler) if handler is not None else {"type": "object", "properties": {}}
    )
    tool_definition: Dict[str, Any] = {
        "type": "function",
        "function": {
            "name": resolved_name,
            "description": resolved_description,
            "parameters": _ensure_fast_mode_required_params(resolved_parameters),
        },
    }
    if handler is not None:
        tool_definition["handler"] = handler
    if mock_response is not _UNSET:
        tool_definition["mock_response"] = mock_response
    return tool_definition


def sanitize_tool_definition(tool_definition: Mapping[str, Any]) -> Dict[str, Any]:
    """Remove runtime-only fields before sending tool schemas to the model."""

    sanitized = {
        str(key): copy.deepcopy(value)
        for key, value in tool_definition.items()
        if str(key) not in RUNTIME_ONLY_TOOL_KEYS
    }
    function_def = sanitized.get("function")
    if isinstance(function_def, dict) and isinstance(function_def.get("parameters"), dict):
        function_def["parameters"] = _ensure_fast_mode_required_params(function_def["parameters"])
    return sanitized


def _ensure_fast_mode_required_params(parameters: Mapping[str, Any]) -> Dict[str, Any]:
    normalized = copy.deepcopy(dict(parameters or {}))
    properties = normalized.get("properties")
    if not isinstance(properties, Mapping):
        return normalized

    fast_mode_param_names = [
        str(name).strip()
        for name, schema in properties.items()
        if str(name).strip() and isinstance(schema, Mapping) and schema.get("mode") == "fast"
    ]
    if not fast_mode_param_names:
        return normalized

    raw_required = normalized.get("required")
    required: list[str] = []
    seen: set[str] = set()
    if isinstance(raw_required, list):
        for item in raw_required:
            candidate = str(item).strip()
            if candidate and candidate not in seen:
                seen.add(candidate)
                required.append(candidate)

    for param_name in fast_mode_param_names:
        if param_name not in seen:
            seen.add(param_name)
            required.append(param_name)

    normalized["required"] = required
    return normalized


def sanitize_tool_definitions(tools: list[Mapping[str, Any]] | None) -> list[Dict[str, Any]]:
    """Return JSON-safe tool definitions for prompts, APIs, and snapshots."""

    sanitized: list[Dict[str, Any]] = []
    for tool_definition in tools or []:
        if not isinstance(tool_definition, Mapping):
            continue
        sanitized.append(sanitize_tool_definition(tool_definition))
    return sanitized


def resolve_tool_handler(
    *,
    agent_node: SwarmNode,
    tool_name: str,
    tool_definition: Mapping[str, Any] | None,
    tool_registry: ToolRegistry | None = None,
) -> ToolExecutor | None:
    """Resolve a runtime tool handler from inline definitions or a registry."""

    inline_handler = tool_definition.get("handler") if isinstance(tool_definition, Mapping) else None
    if callable(inline_handler):
        return inline_handler

    normalized_tool_name = str(tool_name or "").strip()
    if not normalized_tool_name:
        return None

    if tool_registry is None:
        return None

    for registry_key in (
        f"{agent_node.id}.{normalized_tool_name}",
        f"{agent_node.node_key}.{normalized_tool_name}",
        normalized_tool_name,
    ):
        handler = tool_registry.get(registry_key)
        if callable(handler):
            return handler
    return None


def resolve_tool_shared_state(
    *,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
) -> Any:
    """Resolve shared external state for tool execution."""

    if tool_state is not None:
        return tool_state
    return None


async def invoke_tool_handler(handler: ToolExecutor, context: ToolExecutionContext) -> Any:
    """Invoke a sync or async tool handler using tool args plus optional context."""

    tool_args = copy.deepcopy(context.tool_args or {})
    signature = inspect.signature(handler)
    kwargs: Dict[str, Any] = {}
    accepts_var_kwargs = False

    for name, parameter in signature.parameters.items():
        if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
            continue
        if parameter.kind == inspect.Parameter.VAR_KEYWORD:
            accepts_var_kwargs = True
            continue
        if name == "context":
            kwargs[name] = context
            continue
        if name == "tool_args":
            kwargs[name] = copy.deepcopy(tool_args)
            continue
        if name in {"shared_state", "state"}:
            kwargs[name] = context.shared_state
            continue
        if name == "session":
            kwargs[name] = context.session
            continue
        if name == "agent_node":
            kwargs[name] = context.agent_node
            continue
        if name == "user_input":
            kwargs[name] = context.user_input
            continue
        if name == "tool_definition":
            kwargs[name] = copy.deepcopy(context.tool_definition)
            continue
        if name == "tool_name":
            kwargs[name] = context.tool_name
            continue
        if name == "tool_call_id":
            kwargs[name] = context.tool_call_id
            continue
        if name == "visible_global_variables":
            kwargs[name] = copy.deepcopy(context.visible_state)
            continue
        if name == "visible_state":
            kwargs[name] = copy.deepcopy(context.visible_state)
            continue
        if name in tool_args:
            kwargs[name] = tool_args[name]

    if accepts_var_kwargs:
        for key, value in tool_args.items():
            kwargs.setdefault(key, value)

    try:
        result = handler(**kwargs)
    except TypeError as exc:
        raise TypeError(
            "Tool handlers must accept named parameters matching tool args, an optional "
            "'context' parameter, an optional 'tool_args' parameter, or '**kwargs'."
        ) from exc

    if inspect.isawaitable(result):
        return await result
    return result
