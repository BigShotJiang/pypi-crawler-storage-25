"""Multimodal content helpers for SwarmForge.

Provides factory functions for building OpenAI-compatible multimodal content
parts (text, images, audio) that can be passed as ``user_input`` to
``process_swarm_stream`` or included directly in message histories.

Supported by both OpenRouter (any vision/audio capable model) and any
OpenAI-compatible endpoint that supports the ``vision`` or ``audio`` input
modalities.

Example usage::

    from swarmforge.swarm.multimodal import image_url_part, text_part, multimodal_content

    content = multimodal_content(
        text_part("What's in this image?"),
        image_url_part("https://example.com/photo.jpg"),
    )
    async for event in process_swarm_stream(session, content, ...):
        ...
"""

from __future__ import annotations

import base64
from typing import Any, Dict, List, Union


# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------

ContentPart = Dict[str, Any]
"""A single multimodal content part dict (text, image_url, or input_audio)."""

MultimodalContent = List[ContentPart]
"""A list of content parts representing a full multimodal message payload."""


# ---------------------------------------------------------------------------
# Part factories
# ---------------------------------------------------------------------------


def text_part(text: str) -> ContentPart:
    """Create a plain-text content part.

    Args:
        text: The text string.

    Returns:
        ``{"type": "text", "text": text}``
    """
    return {"type": "text", "text": str(text)}


def image_url_part(url: str, *, detail: str = "auto") -> ContentPart:
    """Create an image content part from a public URL.

    Works with OpenRouter vision-capable models (e.g. ``openai/gpt-4o``,
    ``anthropic/claude-3-5-sonnet``) and any OpenAI-compatible endpoint that
    supports the vision modality.

    Args:
        url: Publicly accessible image URL (HTTPS recommended).
        detail: Level of image detail — ``"auto"``, ``"low"``, or ``"high"``.
            Ignored by providers that do not support this parameter.

    Returns:
        An ``image_url`` content part dict.
    """
    return {"type": "image_url", "image_url": {"url": str(url), "detail": str(detail)}}


def image_base64_part(
    data: Union[str, bytes],
    *,
    media_type: str = "image/jpeg",
    detail: str = "auto",
) -> ContentPart:
    """Create an image content part from raw bytes or a base64-encoded string.

    Args:
        data: Raw image bytes or an already base64-encoded string.
        media_type: MIME type of the image, e.g. ``"image/jpeg"``,
            ``"image/png"``, ``"image/gif"``, ``"image/webp"``.
        detail: Level of image detail — ``"auto"``, ``"low"``, or ``"high"``.

    Returns:
        An ``image_url`` content part with a ``data:`` URI.
    """
    if isinstance(data, bytes):
        encoded = base64.b64encode(data).decode("ascii")
    else:
        encoded = str(data).strip()

    data_uri = f"data:{media_type};base64,{encoded}"
    return {"type": "image_url", "image_url": {"url": data_uri, "detail": str(detail)}}


def audio_base64_part(
    data: Union[str, bytes],
    *,
    format: str = "wav",
) -> ContentPart:
    """Create an audio input content part from raw bytes or a base64-encoded string.

    Supported by OpenAI-compatible endpoints that accept the ``input_audio``
    content type (e.g. ``openai/gpt-4o-audio-preview`` via OpenRouter or
    direct OpenAI API).

    Args:
        data: Raw audio bytes or an already base64-encoded string.
        format: Audio format string — ``"wav"``, ``"mp3"``, ``"ogg"``,
            ``"flac"``, ``"m4a"``, ``"webm"``.

    Returns:
        An ``input_audio`` content part dict.
    """
    if isinstance(data, bytes):
        encoded = base64.b64encode(data).decode("ascii")
    else:
        encoded = str(data).strip()

    return {"type": "input_audio", "input_audio": {"data": encoded, "format": str(format)}}


# ---------------------------------------------------------------------------
# Convenience builder
# ---------------------------------------------------------------------------


def multimodal_content(*parts: ContentPart) -> MultimodalContent:
    """Combine one or more content parts into a multimodal content list.

    Example::

        content = multimodal_content(
            text_part("Describe this image and the audio clip."),
            image_url_part("https://example.com/photo.jpg"),
            audio_base64_part(audio_bytes, format="wav"),
        )

    Args:
        *parts: One or more :data:`ContentPart` dicts.

    Returns:
        A :data:`MultimodalContent` list ready to pass as ``user_input`` to
        :func:`~swarmforge.swarm.orchestrator.process_swarm_stream`.
    """
    return list(parts)


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------


def extract_text_from_content(content: Union[str, MultimodalContent, Any]) -> str:
    """Extract a plain-text representation from a string or multimodal content.

    Used internally to generate scratchpad/context summaries when the user
    input contains non-text modalities.

    Args:
        content: A plain string, a :data:`MultimodalContent` list, or any
            other value (will be coerced to string).

    Returns:
        A plain text string summarising the content.
    """
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return str(content)

    parts: List[str] = []
    has_image = False
    has_audio = False
    for part in content:
        if not isinstance(part, dict):
            continue
        part_type = str(part.get("type") or "").strip()
        if part_type == "text":
            text_value = str(part.get("text") or "").strip()
            if text_value:
                parts.append(text_value)
        elif part_type == "image_url":
            has_image = True
        elif part_type == "input_audio":
            has_audio = True

    if has_image:
        parts.append("[image attached]")
    if has_audio:
        parts.append("[audio attached]")

    return " ".join(parts)


def _build_user_message_content(
    user_input: Union[str, MultimodalContent],
    *,
    prefix: str = "",
) -> Union[str, MultimodalContent]:
    """Build the message content value for the user turn in history.

    For plain strings, prepends the optional *prefix*.  For multimodal
    content lists the prefix (if any) is prepended as an additional text
    part so that the content array remains valid.

    Args:
        user_input: Plain string or multimodal content list.
        prefix: Optional text prefix (e.g. ``"<USER_MESSAGE>\\n"``).

    Returns:
        The final value to store under the ``"content"`` key of the history
        entry dict.
    """
    if isinstance(user_input, str):
        if prefix:
            return f"{prefix}{user_input}"
        return user_input

    # multimodal list – prepend a text part for the prompt wrapper
    if prefix:
        return [text_part(prefix)] + list(user_input)
    return list(user_input)
