"""FastAPI integration for exposing authoring workflows over HTTP."""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Dict, List

from fastapi import Body, FastAPI, HTTPException, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .. import __version__ as SWARMFORGE_VERSION
from ..authoring import AgentBuilderFlow, AgentBuilderSession, generate_agent_prompt
from ..authoring.generation import GenerateAgentPromptResult
from ..evaluation.provider import ModelConfig, OpenAIClientWrapper
from ._runtime import _sse_event, build_fastapi_app

AUTHORING_START_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Start a conversational AgentBuilderFlow session",
        "value": {
            "seed_request": "Build me a refund support assistant for ecommerce web chat.",
            "clarification": "It should help support reps resolve refund and exchange requests.",
            "require_ready": False,
        },
    }
}

AUTHORING_ONBOARDING_TURN_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Continue onboarding with a serialized builder session",
        "value": {
            "session": {
                "seed_request": "Build me a refund support assistant",
                "topic": "Support assistant for order refunds",
                "category_type": "persona",
                "category_label": "Support Agent Builder",
                "onboarding_prompt": "Ask adaptive follow-up questions and use fields as memory.",
                "stage": "onboarding",
                "collected_inputs": {},
                "messages": [
                    {
                        "role": "assistant",
                        "content": "Great direction. First, what should this assistant optimize for in refunds?",
                    }
                ],
                "fields": [
                    {
                        "id": "intent",
                        "label": "Intent",
                        "question": "What should this agent achieve first?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                    {
                        "id": "audience_channel",
                        "label": "Audience and Channel",
                        "question": "Who is this for and where will it run?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                ],
                "steps": [
                    {"step": "readiness", "status": "completed", "result": {}, "error": ""},
                    {"step": "plan_onboarding", "status": "completed", "result": {}, "error": ""},
                    {"step": "collect_onboarding", "status": "running", "result": None, "error": ""},
                ],
            },
            "user_message": "It should resolve refund requests quickly for support reps in web chat.",
        },
    }
}

AUTHORING_CONFIRM_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Confirm generation for a collected builder session",
        "value": {
            "session": {
                "seed_request": "Build me a refund support assistant",
                "topic": "Support assistant for order refunds",
                "category_type": "persona",
                "category_label": "Support Agent Builder",
                "onboarding_prompt": "Ask adaptive follow-up questions and use fields as memory.",
                "stage": "confirm_generate",
                "collected_inputs": {
                    "intent": "Resolve refund requests quickly",
                    "audience_channel": "Customer support web chat",
                },
                "messages": [],
                "fields": [
                    {
                        "id": "intent",
                        "label": "Intent",
                        "question": "What should this agent achieve first?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                    {
                        "id": "audience_channel",
                        "label": "Audience and Channel",
                        "question": "Who is this for and where will it run?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                ],
                "steps": [],
            },
            "user_message": "Yes, start now and prioritize VIP customers.",
        },
    }
}

AUTHORING_GENERATE_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Generate a prompt from a confirmed builder session",
        "value": {
            "session": {
                "seed_request": "Build me a refund support assistant",
                "topic": "Support assistant for order refunds",
                "category_type": "persona",
                "category_label": "Support Agent Builder",
                "onboarding_prompt": "Ask adaptive follow-up questions and use fields as memory.",
                "stage": "generating",
                "collected_inputs": {
                    "intent": "Resolve refund requests quickly",
                    "audience_channel": "Customer support web chat",
                    "constraints": "Escalate chargeback threats",
                },
                "messages": [],
                "fields": [
                    {
                        "id": "intent",
                        "label": "Intent",
                        "question": "What should this agent achieve first?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                    {
                        "id": "audience_channel",
                        "label": "Audience and Channel",
                        "question": "Who is this for and where will it run?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": "",
                    },
                ],
                "steps": [],
            },
            "generate_tools": True,
            "tools_format": "openai",
        },
    }
}

AUTHORING_GENERATE_STREAM_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Stream generation progress events for a confirmed builder session",
        "value": {
            "session": {
                "seed_request": "Build me a refund support assistant",
                "topic": "Support assistant for order refunds",
                "category_type": "persona",
                "category_label": "Support Agent Builder",
                "onboarding_prompt": "Ask adaptive follow-up questions and use fields as memory.",
                "stage": "generating",
                "collected_inputs": {
                    "intent": "Resolve refund requests quickly",
                    "audience_channel": "Customer support web chat"
                },
                "messages": [],
                "fields": [
                    {
                        "id": "intent",
                        "label": "Intent",
                        "question": "What should this agent achieve first?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": ""
                    },
                    {
                        "id": "audience_channel",
                        "label": "Audience and Channel",
                        "question": "Who is this for and where will it run?",
                        "type": "textarea",
                        "required": True,
                        "options": [],
                        "placeholder": "",
                        "help_text": ""
                    }
                ],
                "steps": []
            },
            "generate_tools": True,
            "tools_format": "openai"
        }
    }
}

AUTHORING_RUN_OPENAPI_EXAMPLES = {
    "default": {
        "summary": "Run the full one-shot AgentBuilderFlow",
        "value": {
            "seed_request": "Build me a refund support assistant for ecommerce web chat.",
            "onboarding_inputs": {
                "intent": "Resolve refund and exchange questions quickly",
                "audience_channel": "Customer support web chat",
                "constraints": "Escalate chargebacks and legal threats",
            },
            "generate_tools": True,
            "tools_format": "openai",
        },
    }
}


class AgentBuilderGenerationOptions(BaseModel):
    length: str = "detailed"
    max_words: int = 2000
    flow_type: str = "inbound"
    generate_tools: bool = False
    tools_format: str = "openai"
    has_knowledge_files: bool = False
    json_tools: List[Dict[str, Any]] | None = None


class AgentBuilderStartRequest(BaseModel):
    seed_request: str
    clarification: str = ""
    require_ready: bool = False


class AgentBuilderOnboardingTurnRequest(BaseModel):
    session: Dict[str, Any]
    user_message: str


class AgentBuilderConfirmationTurnRequest(BaseModel):
    session: Dict[str, Any]
    user_message: str


class AgentBuilderGenerateRequest(AgentBuilderGenerationOptions):
    session: Dict[str, Any]


class AgentBuilderRunRequest(AgentBuilderGenerationOptions):
    seed_request: str
    onboarding_inputs: Dict[str, str] = Field(default_factory=dict)
    clarification: str = ""
    require_ready: bool = False


def _serialize_readiness(readiness: Any) -> Dict[str, Any] | None:
    if readiness is None:
        return None
    return {
        "is_ready": readiness.is_ready,
        "topic": readiness.topic,
        "category_type": readiness.category_type,
        "clarifying_question": readiness.clarifying_question,
    }


def _serialize_start_result(result: Any) -> Dict[str, Any]:
    return {
        "ready": result.ready,
        "clarifying_question": result.clarifying_question,
        "opening_message": result.opening_message,
        "readiness": _serialize_readiness(result.readiness),
        "session": result.session.to_payload() if result.session is not None else None,
    }


def _serialize_turn_result(result: Any, session: AgentBuilderSession) -> Dict[str, Any]:
    return {
        "reply": result.reply,
        "extracted_fields": dict(result.extracted_fields),
        "all_fields_collected": result.all_fields_collected,
        "stage": result.stage,
        "session": session.to_payload(),
    }


def _serialize_confirmation_result(result: Any, session: AgentBuilderSession) -> Dict[str, Any]:
    return {
        "confirmed": result.confirmed,
        "extra_notes": result.extra_notes,
        "reply": result.reply,
        "stage": result.stage,
        "session": session.to_payload(),
    }


def _build_generation_kwargs(request: AgentBuilderGenerationOptions) -> Dict[str, Any]:
    return {
        "length": request.length,
        "max_words": request.max_words,
        "flow_type": request.flow_type,
        "generate_tools": request.generate_tools,
        "tools_format": request.tools_format,
        "has_knowledge_files": request.has_knowledge_files,
        "json_tools": request.json_tools,
    }


def _session_from_payload(payload: Dict[str, Any]) -> AgentBuilderSession:
    try:
        session = AgentBuilderSession.from_payload(payload)
    except Exception as exc:  # pragma: no cover
        raise HTTPException(status_code=422, detail=f"Invalid agent builder session payload: {exc}") from exc
    if not session.seed_request:
        raise HTTPException(status_code=422, detail="Invalid agent builder session payload: seed_request is required")
    return session


async def _stream_generation_events(
    flow: AgentBuilderFlow,
    session: AgentBuilderSession,
    request: AgentBuilderGenerateRequest,
) -> asyncio.AsyncGenerator[str, None]:
    queue: asyncio.Queue[tuple[str, Dict[str, Any]] | None] = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def _emit(event: str, payload: Dict[str, Any]) -> None:
        loop.call_soon_threadsafe(queue.put_nowait, (event, payload))

    def _run() -> None:
        try:
            _emit("start", {"stage": session.stage or "generating"})

            def _on_phase(phase_name: str) -> None:
                _emit("phase", {"phase": phase_name, "session": session.to_payload()})

            result = flow.run_generation(
                session,
                on_phase=_on_phase,
                **_build_generation_kwargs(request),
            )
            _emit("generation_result", result.to_payload())
            _emit("session", session.to_payload())
            _emit("done", {"status": "completed"})
        except Exception as exc:  # pragma: no cover - exercised through HTTP response path
            _emit("error", {"message": str(exc), "session": session.to_payload()})
        finally:
            loop.call_soon_threadsafe(queue.put_nowait, None)

    task = asyncio.create_task(asyncio.to_thread(_run))
    try:
        while True:
            item = await queue.get()
            if item is None:
                break
            event, payload = item
            yield _sse_event(event, payload)
    finally:
        await task


def create_authoring_app(
    *,
    client: OpenAIClientWrapper | None = None,
    model_config: ModelConfig | None = None,
    prompt_generator: Callable[..., GenerateAgentPromptResult] = generate_agent_prompt,
    flow_factory: Callable[[], AgentBuilderFlow] | None = None,
    cors_allow_origins: List[str] | None = None,
    title: str = "SwarmForge Authoring API",
    version: str = SWARMFORGE_VERSION,
) -> FastAPI:
    app = build_fastapi_app(title=title, version=version, cors_allow_origins=cors_allow_origins)
    app.state.agent_builder_flow = flow_factory() if flow_factory is not None else AgentBuilderFlow(
        client=client,
        model_config=model_config,
        prompt_generator=prompt_generator,
    )

    @app.get("/")
    async def root() -> Dict[str, str]:
        return {
            "name": title,
            "status": "ok",
            "docs": "/docs",
            "health": "/health",
        }

    @app.get("/favicon.ico")
    async def favicon() -> Response:
        return Response(status_code=204)

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.post("/v1/authoring/agent-builder/start")
    async def start_agent_builder(
        request: AgentBuilderStartRequest = Body(..., openapi_examples=AUTHORING_START_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        try:
            result = app.state.agent_builder_flow.start_onboarding(
                request.seed_request,
                clarification=request.clarification,
                require_ready=request.require_ready,
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return _serialize_start_result(result)

    @app.post("/v1/authoring/agent-builder/onboarding-turn")
    async def onboarding_turn(
        request: AgentBuilderOnboardingTurnRequest = Body(..., openapi_examples=AUTHORING_ONBOARDING_TURN_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        session = _session_from_payload(request.session)
        try:
            result = app.state.agent_builder_flow.process_onboarding_turn(session, request.user_message)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return _serialize_turn_result(result, session)

    @app.post("/v1/authoring/agent-builder/confirm")
    async def confirm_generation(
        request: AgentBuilderConfirmationTurnRequest = Body(..., openapi_examples=AUTHORING_CONFIRM_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        session = _session_from_payload(request.session)
        try:
            result = app.state.agent_builder_flow.process_confirmation_turn(session, request.user_message)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return _serialize_confirmation_result(result, session)

    @app.post("/v1/authoring/agent-builder/generate")
    async def generate_from_session(
        request: AgentBuilderGenerateRequest = Body(..., openapi_examples=AUTHORING_GENERATE_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        session = _session_from_payload(request.session)
        try:
            result = app.state.agent_builder_flow.run_generation(
                session,
                **_build_generation_kwargs(request),
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return {
            "session": session.to_payload(),
            "generation_result": result.to_payload(),
        }

    @app.post("/v1/authoring/agent-builder/generate/stream")
    async def stream_generation_from_session(
        request: AgentBuilderGenerateRequest = Body(
            ...,
            openapi_examples=AUTHORING_GENERATE_STREAM_OPENAPI_EXAMPLES,
        ),
    ) -> StreamingResponse:
        session = _session_from_payload(request.session)
        return StreamingResponse(
            _stream_generation_events(app.state.agent_builder_flow, session, request),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    @app.post("/v1/authoring/agent-builder/run")
    async def run_full_builder(
        request: AgentBuilderRunRequest = Body(..., openapi_examples=AUTHORING_RUN_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        try:
            result = app.state.agent_builder_flow.run_full_flow(
                seed_request=request.seed_request,
                onboarding_inputs=request.onboarding_inputs,
                clarification=request.clarification,
                require_ready=request.require_ready,
                **_build_generation_kwargs(request),
            )
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        return {
            "start": _serialize_start_result(result.start),
            "generation_result": result.generation_result.to_payload() if result.generation_result is not None else None,
        }

    return app


__all__ = ["create_authoring_app"]