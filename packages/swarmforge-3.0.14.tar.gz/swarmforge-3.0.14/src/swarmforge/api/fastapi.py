"""FastAPI integration for exposing the swarm runtime over HTTP."""

from __future__ import annotations

from typing import Any, Callable, Dict, List

from fastapi import Body, FastAPI, HTTPException, Response

from .. import __version__ as SWARMFORGE_VERSION
from ..evaluation import build_graph_snapshot
from ..evaluation.provider import ModelConfig, OpenAIClientWrapper
from ..evaluation.swarm import serialize_checkpoints
from ..swarm import (
    InMemorySessionStore,
    SessionStateManager,
    SessionStore,
    SwarmDefinition,
    build_openai_compatible_turn_runner as _build_openai_compatible_turn_runner,
)
from ..swarm.orchestrator import AgentTurnRunner, RequiredVariableExtractor
from ..swarm.tools import ToolRegistry
from ._runtime import (
    FastApiSessionService,
    SwarmApiRuntime,
    build_fastapi_app,
    state_response,
)
from ._schemas import (
    CREATE_SESSION_OPENAPI_EXAMPLE,
    RUN_SWARM_OPENAPI_EXAMPLES,
    SEND_MESSAGE_OPENAPI_EXAMPLES,
    CreateConfiguredSessionRequest,
    CreateSessionRequest,
    RunSwarmRequest,
    SendMessageRequest,
    SessionVariableUpdateRequest,
)


def build_openai_compatible_turn_runner(client: OpenAIClientWrapper) -> AgentTurnRunner:
    return _build_openai_compatible_turn_runner(client)


def create_fastapi_app(
    *,
    default_model_config: ModelConfig | None = None,
    session_store: SessionStore | None = None,
    turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
    extract_required_variables: RequiredVariableExtractor | None = None,
    state_manager_factory: Callable[[SwarmDefinition], SessionStateManager] | None = None,
    global_variable_manager_factory: Callable[[SwarmDefinition], SessionStateManager] | None = None,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
    cors_allow_origins: List[str] | None = None,
) -> FastAPI:
    resolved_store = session_store or InMemorySessionStore()
    app = build_fastapi_app(
        title="SwarmForge API",
        version=SWARMFORGE_VERSION,
        cors_allow_origins=cors_allow_origins,
    )
    app.state.runtime = SwarmApiRuntime(resolved_store)
    app.state.session_service = FastApiSessionService(
        store=app.state.runtime.store,
        default_model_config=default_model_config,
        turn_runner_factory=turn_runner_factory,
        extract_required_variables=extract_required_variables,
        state_manager_factory=state_manager_factory,
        global_variable_manager_factory=global_variable_manager_factory,
        tool_registry=tool_registry,
        tool_state=tool_state,
    )

    @app.get("/")
    async def root() -> Dict[str, str]:
        return {
            "name": "SwarmForge API",
            "status": "ok",
            "docs": "/docs",
            "health": "/health",
        }

    @app.get("/favicon.ico")
    async def favicon() -> Response:
        return Response(status_code=204)

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.post("/v1/sessions")
    async def create_session(
        request: CreateSessionRequest = Body(..., openapi_examples={"default": CREATE_SESSION_OPENAPI_EXAMPLE})
    ) -> Dict[str, Any]:
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                state=request.state,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_state(session, request.state)
        await app.state.runtime.store.save_session(session)
        return {"session": app.state.session_service.session_payload(session)}

    @app.get("/v1/sessions/{session_id}")
    async def get_session(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        checkpoints = await app.state.runtime.store.list_checkpoints(session.id)
        return {
            "session": app.state.session_service.session_payload(session),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    @app.get("/v1/sessions/{session_id}/state")
    async def get_session_state(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return state_response(app.state.session_service.state_payload(session))

    @app.get("/v1/sessions/{session_id}/variables")
    async def get_session_variables(session_id: str) -> Dict[str, Any]:
        return await get_session_state(session_id)

    @app.get("/v1/sessions/{session_id}/runtime")
    async def get_session_runtime(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return app.state.session_service.runtime_payload(session)

    @app.patch("/v1/sessions/{session_id}/state")
    async def update_session_state(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.update_session_state(session, request)
        await app.state.runtime.store.save_session(session)
        response = state_response(app.state.session_service.state_payload(session))
        response["session"] = app.state.session_service.session_payload(session)
        return response

    @app.patch("/v1/sessions/{session_id}/variables")
    async def update_session_variables(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        return await update_session_state(session_id, request)

    @app.post("/v1/sessions/{session_id}/messages")
    async def send_message(
        session_id: str,
        request: SendMessageRequest = Body(..., openapi_examples=SEND_MESSAGE_OPENAPI_EXAMPLES),
    ) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_state(
            session,
            request.state,
        )
        await app.state.runtime.store.save_session(session)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
        )

    @app.post("/v1/sessions/{session_id}/messages/stream")
    async def stream_message(
        session_id: str,
        request: SendMessageRequest = Body(..., openapi_examples=SEND_MESSAGE_OPENAPI_EXAMPLES),
    ):
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_state(
            session,
            request.state,
        )
        await app.state.runtime.store.save_session(session)
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
        )

    @app.post("/v1/swarm/run")
    async def run_swarm(
        request: RunSwarmRequest = Body(..., openapi_examples=RUN_SWARM_OPENAPI_EXAMPLES)
    ) -> Dict[str, Any]:
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                state=request.state,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_state(session, request.state)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
        )

    @app.post("/v1/swarm/run/stream")
    async def stream_swarm_run(
        request: RunSwarmRequest = Body(..., openapi_examples=RUN_SWARM_OPENAPI_EXAMPLES)
    ):
        swarm = request.swarm.to_runtime()
        try:
            session = await app.state.runtime.create_session(
                swarm=swarm,
                session_id=request.session_id,
                state=request.state,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_state(session, request.state)
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
        )

    return app


def create_swarm_app(
    swarm: SwarmDefinition,
    *,
    default_model_config: ModelConfig | None = None,
    session_store: SessionStore | None = None,
    turn_runner_factory: Callable[[ModelConfig], AgentTurnRunner] | None = None,
    extract_required_variables: RequiredVariableExtractor | None = None,
    state_manager: SessionStateManager | None = None,
    global_variable_manager: SessionStateManager | None = None,
    tool_registry: ToolRegistry | None = None,
    tool_state: Any = None,
    cors_allow_origins: List[str] | None = None,
    title: str = "Swarm API",
    version: str = SWARMFORGE_VERSION,
) -> FastAPI:
    if state_manager is not None and global_variable_manager is not None:
        raise ValueError("Pass either state_manager or global_variable_manager, not both.")
    resolved_store = session_store or InMemorySessionStore()
    app = build_fastapi_app(title=title, version=version, cors_allow_origins=cors_allow_origins)
    app.state.runtime = SwarmApiRuntime(resolved_store)
    app.state.session_service = FastApiSessionService(
        store=app.state.runtime.store,
        default_model_config=default_model_config,
        turn_runner_factory=turn_runner_factory,
        extract_required_variables=extract_required_variables,
        state_manager_factory=(
            lambda _swarm: state_manager or global_variable_manager or SessionStateManager.from_swarm(_swarm)
        ),
        tool_registry=tool_registry,
        tool_state=tool_state,
    )
    app.state.swarm = swarm

    @app.get("/")
    async def root() -> Dict[str, str]:
        return {
            "name": title,
            "health": "/health",
            "swarm": "/swarm",
        }

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.get("/swarm")
    async def get_swarm() -> Dict[str, Any]:
        return {"swarm": build_graph_snapshot(app.state.swarm)}

    @app.post("/sessions")
    async def create_session(request: CreateConfiguredSessionRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.create_session(
                swarm=app.state.swarm,
                session_id=request.session_id,
                state=request.state,
            )
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        app.state.session_service.initialize_session_state(session, request.state)
        await app.state.runtime.store.save_session(session)
        return {"session": app.state.session_service.session_payload(session)}

    @app.get("/sessions/{session_id}")
    async def get_session(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        checkpoints = await app.state.runtime.store.list_checkpoints(session.id)
        return {
            "session": app.state.session_service.session_payload(session),
            "checkpoints": serialize_checkpoints(checkpoints),
        }

    @app.get("/sessions/{session_id}/state")
    async def get_session_state(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return state_response(app.state.session_service.state_payload(session))

    @app.get("/sessions/{session_id}/variables")
    async def get_session_variables(session_id: str) -> Dict[str, Any]:
        return await get_session_state(session_id)

    @app.get("/sessions/{session_id}/runtime")
    async def get_session_runtime(session_id: str) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        return app.state.session_service.runtime_payload(session)

    @app.patch("/sessions/{session_id}/state")
    async def update_session_state(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.update_session_state(session, request)
        await app.state.runtime.store.save_session(session)
        response = state_response(app.state.session_service.state_payload(session))
        response["session"] = app.state.session_service.session_payload(session)
        return response

    @app.patch("/sessions/{session_id}/variables")
    async def update_session_variables(session_id: str, request: SessionVariableUpdateRequest) -> Dict[str, Any]:
        return await update_session_state(session_id, request)

    @app.post("/sessions/{session_id}/messages")
    async def send_message(session_id: str, request: SendMessageRequest) -> Dict[str, Any]:
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_state(
            session,
            request.state,
        )
        await app.state.runtime.store.save_session(session)
        return await app.state.session_service.run_turn(
            session,
            user_input=request.user_input,
        )

    @app.post("/sessions/{session_id}/messages/stream")
    async def stream_message(session_id: str, request: SendMessageRequest):
        try:
            session = await app.state.runtime.get_session(session_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Session not found") from exc
        app.state.session_service.apply_turn_state(
            session,
            request.state,
        )
        await app.state.runtime.store.save_session(session)
        return app.state.session_service.stream_turn(
            session,
            user_input=request.user_input,
        )

    return app
