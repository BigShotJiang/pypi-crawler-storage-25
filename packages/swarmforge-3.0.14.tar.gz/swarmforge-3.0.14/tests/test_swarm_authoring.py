import pytest

from swarmforge.authoring import (
    apply_swarm_graph_payload,
    build_generated_variables_from_swarm_payload,
    build_swarm_definition,
    validate_generated_edge_payload,
    validate_generated_swarm_payload,
    validate_swarm_definition,
)
from swarmforge.swarm import SwarmDefinition, SwarmEdge, SwarmNode, SwarmNodeSubAgent


def test_validate_generated_edge_payload_normalizes_required_variables():
    payload = validate_generated_edge_payload(
        {
            "handoff_description": "Transfer billing requests after confirming the user wants billing help.",
            "required_variables": ["account_id", "", "account_id", "invoice_id"],
        }
    )

    assert payload["handoff_description"].startswith("Transfer billing requests")
    assert payload["required_variables"] == ["account_id", "account_id", "invoice_id"][:3]


def test_build_generated_variables_from_swarm_payload_collects_unique_edge_variables():
    variables = build_generated_variables_from_swarm_payload(
        {
            "edges": [
                {"required_variables": ["account_id", "invoice_id"]},
                {"required_variables": ["invoice_id", "region"]},
            ]
        }
    )

    assert variables == [
        {"key_name": "account_id", "description": "", "reducer_rule": "overwrite"},
        {"key_name": "invoice_id", "description": "", "reducer_rule": "overwrite"},
        {"key_name": "region", "description": "", "reducer_rule": "overwrite"},
    ]


def test_build_swarm_definition_creates_runtime_models_and_increments_graph_version():
    payload = validate_generated_swarm_payload(
        {
            "nodes": [
                {
                    "node_key": "triage",
                    "name": "Triage",
                    "persona": "",
                    "is_entry_node": True,
                },
                {
                    "node_key": "billing",
                    "name": "Billing",
                    "persona": "Direct and calm",
                    "is_entry_node": False,
                },
            ],
            "edges": [
                {
                    "source_node_key": "triage",
                    "target_node_key": "billing",
                    "handoff_description": "Route to billing after confirming the issue is about charges or invoices.",
                    "required_variables": ["account_id"],
                }
            ],
        }
    )
    swarm = build_swarm_definition(payload, swarm_id="swarm-1", name="Support")
    validate_swarm_definition(swarm)

    assert swarm.graph_version == 1
    assert swarm.entry_node().node_key == "triage"
    assert swarm.entry_node().intent == ""
    assert swarm.entry_node().capabilities == []
    assert swarm.node_by_key("billing").persona == "Direct and calm"
    assert swarm.variables[0].key_name == "account_id"

    updated = apply_swarm_graph_payload(
        swarm,
        {
            "nodes": payload["nodes"],
            "edges": payload["edges"],
            "variables": [{"key_name": "account_id", "description": "Customer id", "reducer_rule": "overwrite"}],
        },
    )

    assert updated is swarm
    assert swarm.graph_version == 2
    assert swarm.variables[0].description == "Customer id"


def test_build_swarm_definition_preserves_enabled_tools_and_behavior_config():
    payload = validate_generated_swarm_payload(
        {
            "nodes": [
                {
                    "node_key": "ops",
                    "name": "Ops",
                    "persona": "Direct",
                    "system_prompt": "You handle operational requests.",
                    "model_choice": "openrouter/auto",
                    "enabled_tools": [
                        {
                            "type": "function",
                            "function": {
                                "name": "lookup_order",
                                "description": "Fetch order status",
                                "parameters": {
                                    "type": "object",
                                    "properties": {"order_id": {"type": "string"}},
                                    "required": ["order_id"],
                                },
                            },
                        }
                    ],
                    "behavior_config": {"history_scope": "shared"},
                    "is_entry_node": True,
                }
            ],
            "edges": [],
        }
    )

    swarm = build_swarm_definition(payload, swarm_id="swarm-1", name="Support")

    assert swarm.entry_node().model_choice == "openrouter/auto"
    assert swarm.entry_node().enabled_tools[0]["function"]["name"] == "lookup_order"
    assert swarm.entry_node().behavior_config.history_scope == "shared"


def test_swarm_edge_connect_accepts_nodes_and_generates_default_id():
    triage = SwarmNode(
        id="triage_agent",
        node_key="triage",
        name="Triage",
        system_prompt="You triage requests.",
        is_entry_node=True,
    )
    billing = SwarmNode(
        id="billing_agent",
        node_key="billing",
        name="Billing",
        system_prompt="You handle billing requests.",
    )

    edge = SwarmEdge.connect(
        triage,
        billing,
        handoff_description="Transfer billing requests once route confidence is high.",
        required_variables=["account_id"],
    )

    assert edge.id == "triage_agent->billing_agent"
    assert edge.source_node_id == "triage_agent"
    assert edge.target_node_id == "billing_agent"
    assert edge.required_variables == ["account_id"]


def test_swarm_definition_connect_resolves_node_keys_and_appends_edge():
    swarm = SwarmDefinition(
        id="support",
        name="Support",
        nodes=[
            SwarmNode(
                id="root_agent",
                node_key="root",
                name="Root",
                system_prompt="Route requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="catalog_agent",
                node_key="catalog",
                name="Catalog",
                system_prompt="Handle product catalog requests.",
            ),
        ],
    )

    edge = swarm.connect(
        "root",
        "catalog",
        handoff_description="Transfer product browsing and catalog intents.",
    )

    assert edge.id == "root_agent->catalog_agent"
    assert edge.source_node_id == "root_agent"
    assert edge.target_node_id == "catalog_agent"
    assert swarm.edges == [edge]


def test_validate_swarm_definition_rejects_duplicate_edge_routes():
    swarm = SwarmDefinition(
        id="support",
        name="Support",
        nodes=[
            SwarmNode(
                id="root_agent",
                node_key="root",
                name="Root",
                system_prompt="Route requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing_agent",
                node_key="billing",
                name="Billing",
                system_prompt="Handle billing requests.",
            ),
        ],
        edges=[
            SwarmEdge.connect(
                "root_agent",
                "billing_agent",
                handoff_description="Transfer billing issues after confirmation.",
            ),
            SwarmEdge.connect(
                "root_agent",
                "billing_agent",
                handoff_description="Second route that should be rejected.",
            ),
        ],
    )

    with pytest.raises(ValueError, match="Duplicate edge route"):
        validate_swarm_definition(swarm)


def test_validate_swarm_definition_rejects_too_many_required_variables():
    swarm = SwarmDefinition(
        id="support",
        name="Support",
        nodes=[
            SwarmNode(
                id="root_agent",
                node_key="root",
                name="Root",
                system_prompt="Route requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing_agent",
                node_key="billing",
                name="Billing",
                system_prompt="Handle billing requests.",
            ),
        ],
        edges=[
            SwarmEdge.connect(
                "root_agent",
                "billing_agent",
                handoff_description="Transfer billing issues after confirmation.",
                required_variables=["account_id", "invoice_id", "region", "currency"],
            )
        ],
    )

    with pytest.raises(ValueError, match="too many required variables"):
        validate_swarm_definition(swarm)


def test_validate_swarm_definition_rejects_non_snake_case_variable_keys():
    swarm = SwarmDefinition(
        id="support",
        name="Support",
        nodes=[
            SwarmNode(
                id="root_agent",
                node_key="root",
                name="Root",
                system_prompt="Route requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing_agent",
                node_key="billing",
                name="Billing",
                system_prompt="Handle billing requests.",
            ),
        ],
        edges=[
            SwarmEdge.connect(
                "root_agent",
                "billing_agent",
                handoff_description="Transfer billing issues after confirmation.",
                required_variables=["accountId"],
            )
        ],
    )

    with pytest.raises(ValueError, match="snake_case"):
        validate_swarm_definition(swarm)


def test_validate_swarm_definition_requires_handoff_description():
    swarm = SwarmDefinition(
        id="support",
        name="Support",
        nodes=[
            SwarmNode(
                id="root_agent",
                node_key="root",
                name="Root",
                system_prompt="Route requests.",
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing_agent",
                node_key="billing",
                name="Billing",
                system_prompt="Handle billing requests.",
            ),
        ],
        edges=[
            SwarmEdge.connect(
                "root_agent",
                "billing_agent",
                handoff_description="",
            )
        ],
    )

    with pytest.raises(ValueError, match="handoff_description"):
        validate_swarm_definition(swarm)


def test_build_swarm_definition_compiles_node_sub_agents_into_edges():
    payload = {
        "nodes": [
            {
                "node_key": "triage",
                "name": "Triage",
                "persona": "",
                "system_prompt": "Route customer requests.",
                "is_entry_node": True,
                "sub_agents": [
                    {
                        "sub_agent": "billing",
                        "handoff_description": "Transfer billing requests after confirmation.",
                        "required_variables": ["account_id"],
                    }
                ],
            },
            {
                "node_key": "billing",
                "name": "Billing",
                "persona": "",
                "system_prompt": "Handle billing requests.",
                "is_entry_node": False,
            },
        ]
    }

    swarm = build_swarm_definition(payload, swarm_id="support", name="Support")

    assert len(swarm.edges) == 1
    assert swarm.edges[0].source_node_id == "support:triage"
    assert swarm.edges[0].target_node_id == "support:billing"
    assert swarm.edges[0].handoff_description.startswith("Transfer billing requests")
    assert swarm.edges[0].required_variables == ["account_id"]


def test_validate_generated_swarm_payload_rejects_unknown_sub_agent_target():
    payload = {
        "nodes": [
            {
                "node_key": "triage",
                "name": "Triage",
                "persona": "",
                "system_prompt": "Route customer requests.",
                "is_entry_node": True,
                "sub_agents": [
                    {
                        "sub_agent": "nonexistent",
                        "handoff_description": "Transfer when unknown target is needed.",
                        "required_variables": [],
                    }
                ],
            },
            {
                "node_key": "billing",
                "name": "Billing",
                "persona": "",
                "system_prompt": "Handle billing requests.",
                "is_entry_node": False,
            },
        ]
    }

    with pytest.raises(ValueError, match="does not match any generated node"):
        validate_generated_swarm_payload(payload)


def test_swarm_node_sub_agent_dataclass_compiles_into_edge():
    swarm = SwarmDefinition(
        id="support",
        name="Support Swarm",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                system_prompt="You triage support requests.",
                is_entry_node=True,
                sub_agents=[
                    SwarmNodeSubAgent(
                        sub_agent="billing",
                        handoff_description="Transfer after confirming the request is billing-related.",
                        required_variables=["account_id"],
                    )
                ],
            ),
            SwarmNode(id="billing", node_key="billing", name="Billing", system_prompt="You handle billing."),
        ],
    )

    assert len(swarm.edges) == 1
    edge = swarm.edges[0]
    assert edge.source_node_id == "triage"
    assert edge.target_node_id == "billing"
    assert edge.handoff_description == "Transfer after confirming the request is billing-related."
    assert edge.required_variables == ["account_id"]
