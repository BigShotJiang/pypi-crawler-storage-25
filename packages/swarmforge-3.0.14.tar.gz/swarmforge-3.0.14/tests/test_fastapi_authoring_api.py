import asyncio
from dataclasses import dataclass

import httpx

from swarmforge.api import create_authoring_app
from swarmforge.authoring.generation import GenerateAgentPromptResult


@dataclass
class _FakeMessage:
    content: str


@dataclass
class _FakeChoice:
    message: _FakeMessage


@dataclass
class _FakeCompletion:
    choices: list[_FakeChoice]


class _FakeClient:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self.calls: list[dict] = []

    def chat_completion(self, messages, **kwargs):  # noqa: ANN001
        self.calls.append({"messages": messages, **kwargs})
        if not self._responses:
            raise AssertionError("No fake responses left")
        content = self._responses.pop(0)
        return _FakeCompletion(choices=[_FakeChoice(message=_FakeMessage(content=content))])


def _base_plan_json() -> str:
    return (
        '{"label":"Support Agent Builder",'
        '"onboarding_prompt":"Ask adaptive follow-up questions and use fields as memory.",'
        '"fields":['
        '{"id":"intent","label":"Intent","question":"What should this agent achieve first?","type":"textarea","required":true},'
        '{"id":"audience_channel","label":"Audience and Channel","question":"Who is this for and where will it run?","type":"textarea","required":true},'
        '{"id":"constraints","label":"Constraints","question":"What guardrails should it follow?","type":"textarea","required":false}'
        ']}'
    )


async def _request(app, method: str, path: str, **kwargs):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        return await client.request(method, path, **kwargs)


def test_authoring_api_supports_conversational_round_trip_and_generation():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            'Great direction. First, what should this assistant optimize for in refunds?',
            '{"extracted_fields":{"intent":"Resolve refund requests quickly","audience_channel":"Customer support web chat"},"all_fields_collected":true,"reply":"Perfect, I captured the key details. Want me to start generation now?"}',
            '{"confirmed":true,"extra_notes":"Prioritize VIP users.","reply":"Great, starting generation now."}',
        ]
    )

    def _fake_generator(request, *, client=None, model_config=None, on_phase=None):  # noqa: ANN001
        del client, model_config
        for phase in ["research", "phase_a", "phase_b", "phase_c", "phase_d", "title", "tools"]:
            if on_phase:
                on_phase(phase)
        return GenerateAgentPromptResult(
            meta_prompt="## Role & Objective\nPrompt body",
            research_summary="Research summary",
            sources=[{"title": "Spec", "uri": "https://example.com/spec"}],
            json_tools=[{"name": "lookup_order"}] if request.generate_tools else None,
            prompt_title="Refund Support Prompt",
        )

    app = create_authoring_app(client=client, prompt_generator=_fake_generator)

    start_response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/start",
            json={"seed_request": "Build me a refund support assistant"},
        )
    )

    assert start_response.status_code == 200
    start_payload = start_response.json()
    assert start_payload["ready"] is True
    assert start_payload["session"]["stage"] == "onboarding"

    onboarding_response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/onboarding-turn",
            json={
                "session": start_payload["session"],
                "user_message": "It should resolve refund requests quickly for support reps in customer support web chat.",
            },
        )
    )

    assert onboarding_response.status_code == 200
    onboarding_payload = onboarding_response.json()
    assert onboarding_payload["all_fields_collected"] is True
    assert onboarding_payload["session"]["stage"] == "confirm_generate"

    confirm_response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/confirm",
            json={
                "session": onboarding_payload["session"],
                "user_message": "Yes start now, prioritize VIP users.",
            },
        )
    )

    assert confirm_response.status_code == 200
    confirm_payload = confirm_response.json()
    assert confirm_payload["confirmed"] is True
    assert confirm_payload["session"]["stage"] == "generating"

    generate_response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/generate",
            json={
                "session": confirm_payload["session"],
                "generate_tools": True,
                "tools_format": "openai",
            },
        )
    )

    assert generate_response.status_code == 200
    generate_payload = generate_response.json()
    assert generate_payload["session"]["stage"] == "done"
    assert generate_payload["generation_result"]["prompt_title"] == "Refund Support Prompt"
    assert generate_payload["generation_result"]["json_tools"] == [{"name": "lookup_order"}]


def test_authoring_api_run_supports_one_shot_builder_flow():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            'Great direction. First, what should this assistant optimize for in refunds?',
        ]
    )

    def _fake_generator(request, *, client=None, model_config=None, on_phase=None):  # noqa: ANN001
        del client, model_config
        for phase in ["research", "phase_a", "phase_b", "phase_c", "phase_d", "title"]:
            if on_phase:
                on_phase(phase)
        return GenerateAgentPromptResult(
            meta_prompt="## Role & Objective\nPrompt body",
            research_summary="Research summary",
            sources=[],
            json_tools=None,
            prompt_title="Refund Support Prompt",
        )

    app = create_authoring_app(client=client, prompt_generator=_fake_generator)

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/run",
            json={
                "seed_request": "Build me a refund support assistant",
                "onboarding_inputs": {
                    "intent": "Resolve refund requests quickly",
                    "audience_channel": "Customer support web chat",
                    "constraints": "Escalate chargeback threats",
                },
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["start"]["ready"] is True
    assert payload["start"]["session"]["stage"] == "done"
    assert payload["generation_result"]["prompt_title"] == "Refund Support Prompt"


def test_authoring_api_generate_stream_emits_progress_events():
    client = _FakeClient([])

    def _fake_generator(request, *, client=None, model_config=None, on_phase=None):  # noqa: ANN001
        del client, model_config
        for phase in ["research", "phase_a", "phase_b", "title", "tools"]:
            if on_phase:
                on_phase(phase)
        return GenerateAgentPromptResult(
            meta_prompt="## Role & Objective\nPrompt body",
            research_summary="Research summary",
            sources=[{"title": "Spec", "uri": "https://example.com/spec"}],
            json_tools=[{"name": "lookup_order"}] if request.generate_tools else None,
            prompt_title="Refund Support Prompt",
        )

    app = create_authoring_app(client=client, prompt_generator=_fake_generator)
    session_payload = {
        "seed_request": "Build me a refund support assistant",
        "topic": "Support assistant for order refunds",
        "category_type": "persona",
        "category_label": "Support Agent Builder",
        "onboarding_prompt": "Ask adaptive follow-up questions and use fields as memory.",
        "stage": "generating",
        "collected_inputs": {
            "intent": "Resolve refund requests quickly",
            "audience_channel": "Customer support web chat",
        },
        "messages": [],
        "fields": [
            {
                "id": "intent",
                "label": "Intent",
                "question": "What should this agent achieve first?",
                "type": "textarea",
                "required": True,
                "options": [],
                "placeholder": "",
                "help_text": "",
            },
            {
                "id": "audience_channel",
                "label": "Audience and Channel",
                "question": "Who is this for and where will it run?",
                "type": "textarea",
                "required": True,
                "options": [],
                "placeholder": "",
                "help_text": "",
            },
        ],
        "steps": [],
    }

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/authoring/agent-builder/generate/stream",
            json={
                "session": session_payload,
                "generate_tools": True,
                "tools_format": "openai",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    body = response.text
    assert "event: start" in body
    assert "event: phase" in body
    assert '"phase": "research"' in body
    assert '"phase": "tools"' in body
    assert "event: generation_result" in body
    assert "event: session" in body
    assert "event: done" in body