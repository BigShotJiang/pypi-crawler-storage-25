from __future__ import annotations

from dataclasses import dataclass

import pytest

from swarmforge.authoring import AgentBuilderFlow
from swarmforge.authoring.generation import GenerateAgentPromptResult


@dataclass
class _FakeMessage:
    content: str


@dataclass
class _FakeChoice:
    message: _FakeMessage


@dataclass
class _FakeCompletion:
    choices: list[_FakeChoice]


class _FakeClient:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self.calls: list[dict] = []

    def chat_completion(self, messages, **kwargs):  # noqa: ANN001
        self.calls.append({"messages": messages, **kwargs})
        if not self._responses:
            raise AssertionError("No fake responses left")
        content = self._responses.pop(0)
        return _FakeCompletion(choices=[_FakeChoice(message=_FakeMessage(content=content))])


def _base_plan_json() -> str:
    return (
        '{"label":"Support Agent Builder",'
        '"onboarding_prompt":"Ask adaptive follow-up questions and use fields as memory.",'
        '"fields":['
        '{"id":"intent","label":"Intent","question":"What should this agent achieve first?","type":"textarea","required":true},'
        '{"id":"audience_channel","label":"Audience and Channel","question":"Who is this for and where will it run?","type":"textarea","required":true},'
        '{"id":"constraints","label":"Constraints","question":"What guardrails should it follow?","type":"textarea","required":false}'
        ']}'
    )


def test_start_onboarding_returns_clarifying_question_when_not_ready():
    client = _FakeClient(
        [
            '{"is_ready":false,"topic":"","category_type":"persona","clarifying_question":"What workflow should the agent handle first?"}'
        ]
    )
    flow = AgentBuilderFlow(client=client)

    result = flow.start_onboarding("I want an assistant")

    assert not result.ready
    assert result.session is None
    assert result.clarifying_question == "What workflow should the agent handle first?"


def test_start_onboarding_creates_session_with_steps_and_opening_message():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            "Great direction. First, what should this assistant optimize for in refunds?",
        ]
    )
    flow = AgentBuilderFlow(client=client)

    result = flow.start_onboarding("Build me a refund support assistant")

    assert result.ready
    assert result.session is not None
    assert result.session.stage == "onboarding"
    assert result.opening_message.startswith("Great direction")

    readiness_step = next(step for step in result.session.steps if step.step == "readiness")
    planning_step = next(step for step in result.session.steps if step.step == "plan_onboarding")
    collect_step = next(step for step in result.session.steps if step.step == "collect_onboarding")

    assert readiness_step.status == "completed"
    assert planning_step.status == "completed"
    assert collect_step.status == "running"


def test_onboarding_and_confirmation_turns_update_stage_and_state():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            "Great direction. First, what should this assistant optimize for in refunds?",
            '{"extracted_fields":{"intent":"Resolve refund requests quickly","audience_channel":"Customer support web chat"},"all_fields_collected":true,"reply":"Perfect, I captured the key details. Want me to start generation now?"}',
            '{"confirmed":true,"extra_notes":"Prioritize VIP users.","reply":"Great, starting generation now."}',
        ]
    )
    flow = AgentBuilderFlow(client=client)

    start = flow.start_onboarding("Build me a refund support assistant")
    assert start.session is not None
    session = start.session

    onboarding_turn = flow.process_onboarding_turn(
        session,
        "It should resolve refund requests quickly through customer support web chat.",
    )
    assert onboarding_turn.all_fields_collected
    assert onboarding_turn.stage == "confirm_generate"

    confirm_turn = flow.process_confirmation_turn(session, "Yes start now, prioritize VIP users.")
    assert confirm_turn.confirmed
    assert confirm_turn.stage == "generating"
    assert "Prioritize VIP users." in session.collected_inputs.get("extra_notes", "")


def test_run_full_flow_supports_form_onboarding_inputs_and_generation_steps():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            "Great direction. First, what should this assistant optimize for in refunds?",
        ]
    )

    def _fake_generator(request, *, client=None, model_config=None, on_phase=None):  # noqa: ANN001
        phase_order = ["research", "phase_a", "phase_b", "phase_c", "phase_d", "title"]
        if request.generate_tools:
            phase_order.append("tools")
        for phase in phase_order:
            if on_phase:
                on_phase(phase)

        return GenerateAgentPromptResult(
            meta_prompt="## Role & Objective\nPrompt body",
            research_summary="Research summary",
            sources=[{"title": "Spec", "uri": "https://example.com/spec"}],
            json_tools=[{"name": "lookup_order"}] if request.generate_tools else None,
            prompt_title="Refund Support Prompt",
        )

    flow = AgentBuilderFlow(client=client, prompt_generator=_fake_generator)

    run = flow.run_full_flow(
        seed_request="Build me a refund support assistant",
        onboarding_inputs={
            "intent": "Resolve refund requests quickly",
            "audience_channel": "Customer support web chat",
            "constraints": "Escalate chargeback threats",
        },
        generate_tools=True,
        tools_format="gemini",
    )

    assert run.start.ready
    assert run.start.session is not None
    assert run.generation_result is not None
    assert run.generation_result.prompt_title == "Refund Support Prompt"
    assert run.start.session.stage == "done"

    done_step = next(step for step in run.start.session.steps if step.step == "done")
    tools_step = next(step for step in run.start.session.steps if step.step == "tools")

    assert done_step.status == "completed"
    assert tools_step.status == "completed"


def test_run_full_flow_raises_for_missing_required_onboarding_inputs():
    client = _FakeClient(
        [
            '{"is_ready":true,"topic":"Support assistant for order refunds","category_type":"persona","clarifying_question":""}',
            _base_plan_json(),
            "Great direction. First, what should this assistant optimize for in refunds?",
        ]
    )

    flow = AgentBuilderFlow(client=client)

    with pytest.raises(ValueError, match="Missing required onboarding inputs"):
        flow.run_full_flow(
            seed_request="Build me a refund support assistant",
            onboarding_inputs={"intent": "Resolve refund requests quickly"},
        )
