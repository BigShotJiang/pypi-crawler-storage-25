from __future__ import annotations

from dataclasses import dataclass

from swarmforge.authoring import GenerateAgentPromptRequest, generate_agent_prompt


@dataclass
class _FakeMessage:
    content: str


@dataclass
class _FakeChoice:
    message: _FakeMessage


@dataclass
class _FakeCompletion:
    choices: list[_FakeChoice]


class _FakeClient:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self.calls: list[dict] = []

    def chat_completion(self, messages, **kwargs):  # noqa: ANN001
        self.calls.append({"messages": messages, **kwargs})
        if not self._responses:
            raise AssertionError("No fake responses left")
        content = self._responses.pop(0)
        return _FakeCompletion(choices=[_FakeChoice(message=_FakeMessage(content=content))])


def test_generate_agent_prompt_runs_promptly_like_phases_and_returns_payload():
    client = _FakeClient(
        [
            '{"summary":"Domain and prompt-engineering summary","sources":[{"title":"Spec","uri":"https://example.com/spec"}]}',
            "## Role & Objective\nDefine role and scope.",
            "## Behavioral Rules\nBe precise.\n\n## Constraints & Guardrails\nDo not hallucinate.",
            "## Workflow\nStep-by-step with checks.\n\n## Tool Usage\nUse tools only when needed.",
            "Support Triage Agent",
            '[{"type":"function","function":{"name":"lookup_order","parameters":{"type":"object","properties":{"order_id":{"type":"string"}},"required":["order_id"]}},"mock_response":{"status":"shipped"}}]',
        ]
    )
    phases: list[str] = []

    result = generate_agent_prompt(
        GenerateAgentPromptRequest(
            topic="Support assistant for order status and refunds",
            inputs={"channel": "chat", "tone": "concise and calm"},
            generate_tools=True,
            tools_format="openai",
        ),
        client=client,
        on_phase=phases.append,
    )

    assert "## Role & Objective" in result.meta_prompt
    assert "## Behavioral Rules" in result.meta_prompt
    assert "## Workflow" in result.meta_prompt
    assert result.research_summary == "Domain and prompt-engineering summary"
    assert result.sources == [{"title": "Spec", "uri": "https://example.com/spec"}]
    assert result.prompt_title == "Support Triage Agent"
    assert result.json_tools is not None
    assert result.json_tools[0]["function"]["name"] == "lookup_order"
    assert phases == ["research", "phase_a", "phase_b", "phase_c", "phase_d", "title", "tools"]
    assert len(client.calls) == 6


def test_generate_agent_prompt_handles_non_json_research_response():
    client = _FakeClient(
        [
            "Research summary without JSON formatting.",
            "## Role & Objective\nRole.",
            "## Behavioral Rules\nRules.\n\n## Constraints & Guardrails\nGuardrails.",
            "## Workflow\nWorkflow.\n\n## Tool Usage\nNo tools.",
            "Customer Support Prompt",
        ]
    )

    result = generate_agent_prompt(
        GenerateAgentPromptRequest(
            topic="Customer support assistant",
            generate_tools=False,
        ),
        client=client,
    )

    assert result.research_summary == "Research summary without JSON formatting."
    assert result.sources == []
    assert result.json_tools is None


def test_generate_agent_prompt_parses_json_wrapped_in_fences_for_tools():
    client = _FakeClient(
        [
            '{"summary":"Summary","sources":[]}',
            "## Role & Objective\nRole.",
            "## Behavioral Rules\nRules.\n\n## Constraints & Guardrails\nGuardrails.",
            "## Workflow\nWorkflow.\n\n## Tool Usage\nUse tool.",
            "Tool Prompt",
            "```json\n[{\"name\":\"search_knowledge_base\",\"parameters\":{\"type\":\"object\",\"properties\":{}},\"mock_response\":{\"result\":\"ok\"}}]\n```",
        ]
    )

    result = generate_agent_prompt(
        GenerateAgentPromptRequest(
            topic="Assistant with docs",
            generate_tools=True,
            tools_format="gemini",
            has_knowledge_files=True,
        ),
        client=client,
    )

    assert result.json_tools is not None
    assert result.json_tools[0]["name"] == "search_knowledge_base"
