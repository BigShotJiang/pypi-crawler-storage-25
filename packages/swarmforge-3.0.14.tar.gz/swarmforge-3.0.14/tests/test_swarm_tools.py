from swarmforge.swarm import function_tool, infer_tool_parameters
from swarmforge.swarm.tools import sanitize_tool_definition


def test_infer_tool_parameters_from_signature_and_google_docstring():
    def lookup_order(order_id: str, include_history: bool = False, context=None):
        """Fetch order status for a customer order.

        Args:
            order_id: The unique order identifier.
            include_history: Whether to include tracking history.
        """

        del context
        return {"order_id": order_id, "include_history": include_history}

    schema = infer_tool_parameters(lookup_order)

    assert schema["type"] == "object"
    assert schema["required"] == ["order_id"]
    assert schema["properties"]["order_id"]["type"] == "string"
    assert schema["properties"]["order_id"]["description"] == "The unique order identifier."
    assert schema["properties"]["include_history"]["type"] == "boolean"
    assert schema["properties"]["include_history"]["description"] == "Whether to include tracking history."
    assert "context" not in schema["properties"]


def test_function_tool_infers_name_description_and_parameters_from_handler():
    def lookup_order(order_id: str):
        """Fetch order status.

        :param order_id: The order identifier.
        """

        return {"order_id": order_id}

    tool = function_tool(handler=lookup_order)

    assert tool["function"]["name"] == "lookup_order"
    assert tool["function"]["description"] == "Fetch order status."
    assert tool["function"]["parameters"]["properties"]["order_id"]["description"] == "The order identifier."


def test_sanitize_tool_definition_removes_runtime_only_fields():
    def lookup_order(order_id: str, state=None):
        """Fetch order status.

        Args:
            order_id: The order identifier.
        """

        return {"order_id": order_id, "tenant": state["tenant"]}

    tool = sanitize_tool_definition(
        {
            **function_tool(handler=lookup_order),
            "fast_enabled": True,
            "fast_default_args": {"order_id": "ABC-1"},
        }
    )

    assert tool["function"]["name"] == "lookup_order"
    assert tool["function"]["parameters"]["properties"]["order_id"]["type"] == "string"
    assert "handler" not in tool
    assert "mock_response" not in tool
    assert "fast_enabled" not in tool
    assert "fast_default_args" not in tool


def test_function_tool_auto_adds_mode_fast_params_to_required_schema():
    tool = function_tool(
        name="lookup_order",
        description="Fetch order status",
        parameters={
            "type": "object",
            "properties": {
                "order_id": {"type": "string"},
                "order_success": {"type": "string", "mode": "fast"},
                "order_not_success": {"type": "string", "mode": "fast"},
            },
            "required": ["order_id"],
        },
    )

    required = tool["function"]["parameters"]["required"]
    assert required == ["order_id", "order_success", "order_not_success"]


def test_sanitize_tool_definition_auto_adds_mode_fast_params_to_required_schema():
    tool = sanitize_tool_definition(
        {
            "type": "function",
            "function": {
                "name": "lookup_order",
                "description": "Fetch order status",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "order_id": {"type": "string"},
                        "order_success": {"type": "string", "mode": "fast"},
                    },
                    "required": ["order_id"],
                },
            },
            "handler": lambda order_id: order_id,
            "fast_enabled": True,
        }
    )

    assert tool["function"]["parameters"]["required"] == ["order_id", "order_success"]
