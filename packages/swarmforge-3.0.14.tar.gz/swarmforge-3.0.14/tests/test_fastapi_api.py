import asyncio
import json
import os
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

from swarmforge import __version__
from swarmforge.api import create_fastapi_app, create_swarm_app
from swarmforge.env import reset_local_env_loader
from swarmforge.evaluation import build_graph_snapshot, evaluate_scenario_artifacts
from swarmforge.evaluation.provider import ModelConfig
from swarmforge.evaluation.provider.config import OPENROUTER_BASE_URL
from swarmforge.swarm import (
    AgentTurnResult,
    GlobalVariableManager,
    InMemorySessionStore,
    SwarmDefinition,
    SwarmEdge,
    SwarmNode,
    SwarmVariable,
    SystemPromptContext,
)


class _FunctionTurnRunner:
    def __init__(self, func):
        self._func = func

    async def run_turn(self, *, agent_node, contents, config):
        return await self._func(agent_node=agent_node, contents=contents, config=config)


ROOT = Path(__file__).resolve().parents[1]
_ENV_TEST_KEYS = (
    "MODEL_PROVIDER",
    "model_provider",
    "LLM_MODEL",
    "llm_model",
    "OPENROUTER_API_KEY",
    "OPENROUTER_SITE_URL",
    "OPENROUTER_APP_NAME",
    "OPENROUTER_HTTP_REFERER",
    "OPENROUTER_APP_URL",
    "OPENROUTER_X_TITLE",
    "GOOGLE_API_KEY",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "SWARMFORGE_ENV_FILE",
)


def _single_agent_swarm_payload():
    return {
        "id": "single-agent",
        "name": "Single Agent",
        "nodes": [
            {
                "node_key": "assistant",
                "name": "Assistant",
                "system_prompt": "You are a helpful assistant.",
                "is_entry_node": True,
            }
        ],
        "edges": [],
        "variables": [],
    }


def _bound_support_swarm() -> SwarmDefinition:
    return SwarmDefinition(
        id="support",
        name="Support Swarm",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                system_prompt="You triage support requests.",
                intent="Route support issues",
                capabilities=["Route to specialists"],
                is_entry_node=True,
            ),
            SwarmNode(
                id="billing",
                node_key="billing",
                name="Billing",
                system_prompt="You solve billing requests.",
                intent="Handle billing issues",
                capabilities=["Resolve billing questions"],
            ),
        ],
        edges=[
            SwarmEdge(
                id="triage->billing",
                source_node_id="triage",
                target_node_id="billing",
                handoff_description="Transfer billing issues after account verification.",
                required_variables=["account_id"],
            )
        ],
        variables=[SwarmVariable(key_name="account_id", description="Customer account id")],
    )


async def _request(app, method: str, path: str, **kwargs):
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        return await client.request(method, path, **kwargs)


def _use_repo_env_test(monkeypatch):
    monkeypatch.chdir(ROOT)
    for name in _ENV_TEST_KEYS:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("SWARMFORGE_ENV_FILE", ".env.test")
    reset_local_env_loader()


def _make_openai_response(*, content="", tool_calls=None):
    normalized_tool_calls = [
        SimpleNamespace(
            id=tool_call["id"],
            function=SimpleNamespace(
                name=tool_call["name"],
                arguments=json.dumps(tool_call.get("args", {})),
            ),
        )
        for tool_call in (tool_calls or [])
    ]
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content=content,
                    tool_calls=normalized_tool_calls,
                )
            )
        ]
    )


def _to_stream_chunks(response):
    """Convert a fake non-streaming response into an iterable of SSE-style chunks."""
    message = response.choices[0].message
    # Yield content as a single text delta chunk
    if message.content:
        yield SimpleNamespace(
            choices=[SimpleNamespace(delta=SimpleNamespace(content=message.content, tool_calls=None))]
        )
    # Yield tool calls as delta chunks, one per tool call
    for idx, tc in enumerate(message.tool_calls or []):
        yield SimpleNamespace(
            choices=[SimpleNamespace(delta=SimpleNamespace(
                content=None,
                tool_calls=[SimpleNamespace(
                    index=idx,
                    id=tc.id,
                    function=SimpleNamespace(name=tc.function.name, arguments=tc.function.arguments),
                )],
            ))]
        )
    # Final sentinel chunk with no delta content
    yield SimpleNamespace(choices=[SimpleNamespace(delta=SimpleNamespace(content=None, tool_calls=None))])


def _install_fake_openai(monkeypatch, responder):
    init_calls = []
    chat_calls = []

    class _FakeCompletions:
        def create(self, **kwargs):
            chat_calls.append(kwargs)
            response = responder(kwargs)
            if kwargs.get("stream"):
                return _to_stream_chunks(response)
            return response

        def parse(self, **kwargs):
            chat_calls.append(kwargs)
            return responder(kwargs)

    class _FakeChat:
        def __init__(self):
            self.completions = _FakeCompletions()

    class _FakeOpenAI:
        def __init__(self, **kwargs):
            init_calls.append(kwargs)
            self.chat = _FakeChat()
            self.beta = SimpleNamespace(chat=_FakeChat())

    monkeypatch.setattr("swarmforge.evaluation.provider.client.OpenAI", _FakeOpenAI)
    return {"init_calls": init_calls, "chat_calls": chat_calls}


async def _extract_account_id(user_input: str = "", **_kwargs):
    if "ACME-991" in user_input:
        return {"account_id": "ACME-991"}
    return {}


@pytest.fixture
def repo_env_test(monkeypatch):
    _use_repo_env_test(monkeypatch)
    try:
        yield
    finally:
        for name in _ENV_TEST_KEYS:
            os.environ.pop(name, None)
        reset_local_env_loader()


def test_fastapi_health_and_stateless_run():
    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="Hello from the swarm API.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    health = asyncio.run(_request(app, "GET", "/health"))
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}

    root = asyncio.run(_request(app, "GET", "/"))
    assert root.status_code == 200
    assert root.json()["docs"] == "/docs"

    favicon = asyncio.run(_request(app, "GET", "/favicon.ico"))
    assert favicon.status_code == 204

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["events"][-1]["event"] == "done"
    assert payload["events"][-1]["data"]["fullText"] == "Hello from the swarm API."
    assert payload["session"]["current_node_key"] == "assistant"


def test_fastapi_run_request_accepts_state_payload_and_injects_into_swarm():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        captured["state"] = config.state
        return AgentTurnResult(response_text="Hello from the swarm API.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
                "state": {"account_id": "ACME-991", "priority": "high"},
            },
        )
    )

    assert response.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-991", "priority": "high"}
    assert captured["state"] == {"account_id": "ACME-991", "priority": "high"}
    assert response.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert response.json()["session"]["snapshot"]["state"]["account_id"] == "ACME-991"


def _parse_sse_events(body: str):
    """Parse an SSE text body into a list of (event_name, data_dict) tuples in order."""
    events = []
    current_event = None
    current_data = []
    for line in body.splitlines():
        if line.startswith("event: "):
            current_event = line[len("event: "):]
        elif line.startswith("data: "):
            current_data.append(line[len("data: "):])
        elif line == "":
            if current_event is not None and current_data:
                try:
                    payload = json.loads("".join(current_data))
                except json.JSONDecodeError:
                    payload = "".join(current_data)
                events.append((current_event, payload))
            current_event = None
            current_data = []
    if current_event is not None and current_data:
        try:
            payload = json.loads("".join(current_data))
        except json.JSONDecodeError:
            payload = "".join(current_data)
        events.append((current_event, payload))
    return events


def test_fastapi_run_swarm_supports_fast_mode_tool_first_responses():
    class _ExplodingTurnRunner:
        async def run_turn(self, **_kwargs):
            raise AssertionError("fast mode should not call run_turn")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _ExplodingTurnRunner(),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "behavior_config": {"fast_mode_enabled": True},
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                        },
                                    },
                                    "fast_enabled": True,
                                    "fast_default_args": {"order_id": "A-77"},
                                    "mock_response": {"summary": "Order A-77 has shipped."},
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Track my order",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert [event["event"] for event in payload["events"]] == ["open", "fast_tool_use", "done"]
    assert "Order A-77 has shipped." in payload["events"][-1]["data"]["fullText"]
    assert payload["checkpoints"][0]["action_type"] == "fast_mode_response"


def test_fastapi_stream_run_supports_fast_mode_tool_first_responses():
    class _ExplodingTurnRunner:
        async def run_turn(self, **_kwargs):
            raise AssertionError("fast mode should not call run_turn")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _ExplodingTurnRunner(),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run/stream",
            json={
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "behavior_config": {"fast_mode_enabled": True},
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                        },
                                    },
                                    "fast_enabled": True,
                                    "fast_default_args": {"order_id": "A-77"},
                                    "mock_response": {"summary": "Order A-77 has shipped."},
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Track my order",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    events = _parse_sse_events(response.text)
    event_names = [name for name, _data in events]
    assert event_names == ["open", "fast_tool_use", "done", "session", "checkpoints"]
    fast_tool_event = next(data for name, data in events if name == "fast_tool_use")
    assert fast_tool_event["agentName"] == "Assistant"
    assert any(item["tool_name"] == "lookup_order" and item["status"] == "ok" for item in fast_tool_event["results"])
    done_event = next(data for name, data in events if name == "done")
    assert "Order A-77 has shipped." in done_event["fullText"]


def test_fastapi_bound_swarm_stream_supports_fast_mode_tool_first_responses():
    class _ExplodingTurnRunner:
        async def run_turn(self, **_kwargs):
            raise AssertionError("fast mode should not call run_turn")

    swarm = SwarmDefinition(
        id="ops",
        name="Ops Swarm",
        nodes=[
            SwarmNode(
                id="ops",
                node_key="ops",
                name="Ops",
                system_prompt="You are an operations specialist.",
                enabled_tools=[
                    {
                        "type": "function",
                        "function": {
                            "name": "lookup_order",
                            "description": "Fetch order status",
                            "parameters": {
                                "type": "object",
                                "properties": {"order_id": {"type": "string"}},
                            },
                        },
                        "fast_enabled": True,
                        "fast_default_args": {"order_id": "A-77"},
                        "mock_response": {"summary": "Order A-77 has shipped."},
                    }
                ],
                behavior_config={"fast_mode_enabled": True},
                is_entry_node=True,
            )
        ],
    )

    app = create_swarm_app(
        swarm,
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _ExplodingTurnRunner(),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "fast-stream-1"},
        )
    )
    assert created.status_code == 200

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/fast-stream-1/messages/stream",
            json={
                "user_input": "Track my order",
                "state": {"fast_tool_params": {"lookup_order": {"order_id": "A-99"}}},
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    events = _parse_sse_events(response.text)
    event_names = [name for name, _data in events]
    assert event_names == ["open", "fast_tool_use", "done", "session", "checkpoints"]
    fast_tool_event = next(data for name, data in events if name == "fast_tool_use")
    assert fast_tool_event["agentName"] == "Ops"
    result = next(item for item in fast_tool_event["results"] if item["tool_name"] == "lookup_order")
    assert result["status"] == "ok"
    assert result["args"] == {"order_id": "A-99"}
    done_event = next(data for name, data in events if name == "done")
    assert "Order A-77 has shipped." in done_event["fullText"]


def test_bound_swarm_app_exposes_fixed_swarm_routes_and_extractor():
    async def extract_required_variables(user_input: str = "", **_kwargs):
        if "ACME-991" in user_input:
            return {"account_id": "ACME-991"}
        return {}

    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        if agent_node.node_key == "triage":
            return AgentTurnResult(
                response_text="Routing to billing.",
                tool_calls=[
                    {
                        "id": "handoff-1",
                        "name": "transfer_to_agent",
                        "args": {
                            "target_node_key": "billing",
                            "reason": "Billing request confirmed.",
                        },
                    }
                ],
            )
        return AgentTurnResult(response_text="Billing handled the request.")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        extract_required_variables=extract_required_variables,
    )

    swarm_response = asyncio.run(_request(app, "GET", "/swarm"))
    assert swarm_response.status_code == 200
    assert swarm_response.json()["swarm"]["swarm"]["id"] == "support"

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "session-1"},
        )
    )

    assert created.status_code == 200
    assert created.json()["session"]["current_node_key"] == "triage"
    assert "runtime" not in created.json()["session"]

    runtime_response = asyncio.run(_request(app, "GET", "/sessions/session-1/runtime"))
    assert runtime_response.status_code == 200
    assert runtime_response.json()["runtime"]["entry_node"]["node_key"] == "triage"

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/session-1/messages",
            json={"user_input": "My billing issue is on account ACME-991."},
        )
    )

    assert sent.status_code == 200
    payload = sent.json()
    assert payload["events"][-1]["data"]["fullText"] == "Billing handled the request."
    assert payload["session"]["current_node_key"] == "billing"
    assert payload["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert any(event["event"] == "handoff" for event in payload["events"])

    runtime_after_send = asyncio.run(_request(app, "GET", "/sessions/session-1/runtime"))
    assert runtime_after_send.status_code == 200
    assert runtime_after_send.json()["runtime"]["current_node"]["scratchpad"]["latest_agent_response"] == "Billing handled the request."

    streamed = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/session-1/messages/stream",
            json={"user_input": "I still need help with billing."},
        )
    )

    assert streamed.status_code == 200
    assert "event: done" in streamed.text


def test_fastapi_session_state_endpoints_expose_runtime_state():
    async def fake_run_turn(**_kwargs):
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "vars-1", "state": {"account_id": "ACME-100"}},
        )
    )

    assert created.status_code == 200
    assert "runtime" not in created.json()["session"]

    fetched = asyncio.run(_request(app, "GET", "/sessions/vars-1/state"))
    assert fetched.status_code == 200
    assert fetched.json()["state"]["visible"]["account_id"] == "ACME-100"
    legacy_fetched = asyncio.run(_request(app, "GET", "/sessions/vars-1/variables"))
    assert legacy_fetched.status_code == 200
    assert legacy_fetched.json()["variables"]["visible"]["account_id"] == "ACME-100"

    runtime = asyncio.run(_request(app, "GET", "/sessions/vars-1/runtime"))
    assert runtime.status_code == 200
    assert runtime.json()["runtime"]["global_state"]["visible"]["account_id"] == "ACME-100"
    assert runtime.json()["runtime"]["state"]["visible"]["account_id"] == "ACME-100"

    updated = asyncio.run(
        _request(
            app,
            "PATCH",
            "/sessions/vars-1/state",
            json={"state": {"account_id": "ACME-991", "priority": "high"}, "mode": "merge"},
        )
    )

    assert updated.status_code == 200
    assert updated.json()["state"]["visible"] == {"account_id": "ACME-991", "priority": "high"}
    assert updated.json()["variables"]["visible"] == {"account_id": "ACME-991", "priority": "high"}
    runtime_after_update = asyncio.run(_request(app, "GET", "/sessions/vars-1/runtime"))
    assert runtime_after_update.json()["runtime"]["global_state"]["definitions"][0]["key_name"] == "account_id"


def test_fastapi_message_request_can_merge_global_variables():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "msg-vars-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/msg-vars-1/messages",
            json={
                "user_input": "Help with billing.",
                "state": {"account_id": "ACME-555", "priority": "high"},
                "state_mode": "merge",
            },
        )
    )

    assert sent.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-555", "priority": "high"}
    assert sent.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-555"


def test_fastapi_message_request_still_accepts_legacy_global_variable_keys():
    captured = {}

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["visible_global_variables"] = config.visible_global_variables
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        _bound_support_swarm(),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "msg-vars-legacy-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/msg-vars-legacy-1/messages",
            json={
                "user_input": "Help with billing.",
                "global_variables": {"account_id": "ACME-556"},
                "global_variable_mode": "merge",
            },
        )
    )

    assert sent.status_code == 200
    assert captured["visible_global_variables"] == {"account_id": "ACME-556"}


def test_bound_swarm_supports_callable_system_prompts_with_context():
    captured = {}

    def triage_prompt(context: SystemPromptContext) -> str:
        account_id = str(context.state.get("account_id") or "unknown")
        return f"You triage support requests. Current account context: {account_id}."

    swarm = SwarmDefinition(
        id="support",
        name="Support Swarm",
        nodes=[
            SwarmNode(
                id="triage",
                node_key="triage",
                name="Triage",
                system_prompt=triage_prompt,
                intent="Route support issues",
                capabilities=["Route to specialists"],
                is_entry_node=True,
            )
        ],
        variables=[SwarmVariable(key_name="account_id", description="Customer account id")],
    )

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents
        captured["system_instruction"] = config.system_instruction
        return AgentTurnResult(response_text="ok")

    app = create_swarm_app(
        swarm,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    swarm_response = asyncio.run(_request(app, "GET", "/swarm"))
    assert swarm_response.status_code == 200
    assert str(swarm_response.json()["swarm"]["nodes"][0]["system_prompt"]).startswith("<callable:triage_prompt>")

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "prompt-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/prompt-1/messages",
            json={
                "user_input": "Route this request.",
                "global_variables": {"account_id": "ACME-991"},
            },
        )
    )

    assert sent.status_code == 200
    assert "Current account context: ACME-991." in captured["system_instruction"]


def test_fastapi_stream_run_initializes_request_variables_through_manager():
    class UppercaseVariables(GlobalVariableManager):
        def normalize_value(self, key, value, *, session, current_node=None):
            if key == "account_id":
                return str(value).strip().upper()
            return value

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="ok")

    swarm_payload = _single_agent_swarm_payload()
    swarm_payload["variables"] = [
        {"key_name": "account_id", "description": "Customer account id", "reducer_rule": "overwrite"}
    ]

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        state_manager_factory=lambda swarm: UppercaseVariables.from_swarm(swarm),
    )

    streamed = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run/stream",
            json={
                "session_id": "stream-vars-1",
                "swarm": swarm_payload,
                "user_input": "Say hello.",
                "state": {"account_id": "acme-991"},
            },
        )
    )

    assert streamed.status_code == 200
    fetched = asyncio.run(_request(app, "GET", "/v1/sessions/stream-vars-1"))
    assert fetched.status_code == 200
    assert fetched.json()["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"


def test_fastapi_custom_store_session_message_flow():
    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        return AgentTurnResult(response_text=f"{agent_node.name} handled the request.")

    store = InMemorySessionStore()
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        session_store=store,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/sessions",
            json={
                "session_id": "session-1",
                "swarm": _single_agent_swarm_payload(),
            },
        )
    )

    assert created.status_code == 200
    assert created.json()["session"]["id"] == "session-1"

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/sessions/session-1/messages",
            json={"user_input": "Help me."},
        )
    )

    assert sent.status_code == 200
    payload = sent.json()
    assert payload["events"][-1]["data"]["fullText"] == "Assistant handled the request."
    assert payload["session"]["current_agent"] == "Assistant"
    assert payload["checkpoints"][-1]["action_type"] == "agent_response"

    second_app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        session_store=store,
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )
    fetched = asyncio.run(_request(second_app, "GET", "/v1/sessions/session-1"))
    assert fetched.status_code == 200
    assert fetched.json()["session"]["id"] == "session-1"

    runtime = asyncio.run(_request(second_app, "GET", "/v1/sessions/session-1/runtime"))
    assert runtime.status_code == 200
    assert runtime.json()["runtime"]["current_node"]["name"] == "Assistant"


def test_fastapi_executes_registered_runtime_tools():
    async def lookup_order(order_id, context):
        return {
            "status": "shipped",
            "order_id": order_id,
            "session_id": context.session.id,
        }

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Assistant"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"session_id": "' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 is shipped.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        tool_registry={"lookup_order": lookup_order},
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "session_id": "runtime-tool-1",
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "intent": "Handle the full request",
                            "capabilities": ["Answer questions"],
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                            "required": ["order_id"],
                                        },
                                    },
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Where is order 123?",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert [event["event"] for event in payload["events"]] == ["open", "tool_use", "done"]
    assert payload["events"][-1]["data"]["fullText"] == "Order 123 is shipped."


def test_fastapi_executes_registry_mapped_tools_with_external_state():
    async def lookup_order(order_id: str, state=None):
        return {
            "status": "shipped",
            "order_id": order_id,
            "tenant": state["tenant"],
        }

    registry = {"lookup_order": lookup_order}

    call_count = 0

    async def fake_run_turn(*, agent_node, contents, config):
        nonlocal call_count
        call_count += 1
        assert agent_node.name == "Assistant"
        assert any(tool.get("function", {}).get("name") == "lookup_order" for tool in config.tools)
        if call_count == 1:
            return AgentTurnResult(tool_calls=[{"id": "tool-1", "name": "lookup_order", "args": {"order_id": "123"}}])
        assert any(item.get("role") == "tool" and '"tenant": "acme"' in item.get("content", "") for item in contents)
        return AgentTurnResult(response_text="Order 123 is shipped for tenant acme.")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
        tool_registry=registry,
        tool_state={"tenant": "acme"},
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "session_id": "sdk-tool-1",
                "swarm": {
                    "id": "single-agent",
                    "name": "Single Agent",
                    "nodes": [
                        {
                            "node_key": "assistant",
                            "name": "Assistant",
                            "system_prompt": "You are a helpful assistant.",
                            "intent": "Handle the full request",
                            "capabilities": ["Answer questions"],
                            "enabled_tools": [
                                {
                                    "type": "function",
                                    "function": {
                                        "name": "lookup_order",
                                        "description": "Fetch order status",
                                        "parameters": {
                                            "type": "object",
                                            "properties": {"order_id": {"type": "string"}},
                                            "required": ["order_id"],
                                        },
                                    },
                                }
                            ],
                            "is_entry_node": True,
                        }
                    ],
                    "edges": [],
                    "variables": [],
                },
                "user_input": "Where is order 123?",
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert [event["event"] for event in payload["events"]] == ["open", "tool_use", "done"]
    assert payload["events"][-1]["data"]["fullText"] == "Order 123 is shipped for tenant acme."


def test_fastapi_sse_streams_incremental_events():
    async def fake_run_turn(*, agent_node, contents, config):
        del contents, config
        return AgentTurnResult(response_text=f"{agent_node.name} partial")

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: _FunctionTurnRunner(fake_run_turn),
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run/stream",
            json={
                "session_id": "stream-1",
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Stream this response.",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")
    body = response.text
    assert "event: open" in body
    assert "event: done" in body
    assert "event: session" in body
    assert "event: checkpoints" in body


def test_fastapi_uses_server_default_model_config_for_requests():
    captured = []

    async def fake_run_turn(*, agent_node, contents, config):
        del agent_node, contents, config
        return AgentTurnResult(response_text="ok")

    def turn_runner_factory(config):
        captured.append(config)
        return _FunctionTurnRunner(fake_run_turn)

    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=turn_runner_factory,
    )

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
                "provider": {
                    "provider": "gemini",
                    "model": "gemini-3-flash-preview",
                },
            },
        )
    )

    assert response.status_code == 200
    assert captured[0].provider == "openrouter"
    assert captured[0].model == "openrouter/auto"
    assert captured[0].api_key == "sk-or-test"


def test_fastapi_openapi_examples_use_server_defaults():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(_request(app, "GET", "/openapi.json"))
    assert response.status_code == 200
    schema = response.json()

    run_examples = schema["paths"]["/v1/swarm/run"]["post"]["requestBody"]["content"]["application/json"]["examples"]
    assert "default" in run_examples
    assert "provider" not in run_examples["default"]["value"]

    message_examples = schema["paths"]["/v1/sessions/{session_id}/messages"]["post"]["requestBody"]["content"]["application/json"]["examples"]
    assert "default" in message_examples
    assert "provider" not in message_examples["default"]["value"]


def test_fastapi_openapi_uses_package_version():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(_request(app, "GET", "/openapi.json"))
    assert response.status_code == 200
    assert response.json()["info"]["version"] == __version__


def test_fastapi_defaults_to_in_memory_store():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    assert isinstance(app.state.runtime.store, InMemorySessionStore)


def test_fastapi_accepts_browser_cors_preflight():
    app = create_fastapi_app(
        default_model_config=ModelConfig(provider="openrouter", api_key="sk-or-test", model="openrouter/auto"),
        turn_runner_factory=lambda _config: None,
    )

    response = asyncio.run(
        _request(
            app,
            "OPTIONS",
            "/v1/sessions",
            headers={
                "Origin": "http://localhost:5173",
                "Access-Control-Request-Method": "POST",
            },
        )
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "*"


def test_fastapi_single_agent_usage_loads_model_config_from_env_test(monkeypatch, repo_env_test):
    del repo_env_test
    client_calls = _install_fake_openai(
        monkeypatch,
        lambda _params: _make_openai_response(content="Hello from env-backed agent."),
    )
    app = create_fastapi_app()

    response = asyncio.run(
        _request(
            app,
            "POST",
            "/v1/swarm/run",
            json={
                "session_id": "env-single-1",
                "swarm": _single_agent_swarm_payload(),
                "user_input": "Say hello.",
                "state": {"account_id": "ACME-991"},
            },
        )
    )

    assert response.status_code == 200
    payload = response.json()
    assert payload["events"][0]["event"] == "open"
    assert any(event["event"] == "done" for event in payload["events"])
    assert payload["events"][-1]["event"] == "done"
    assert payload["events"][-1]["data"]["fullText"] == "Hello from env-backed agent."
    assert payload["session"]["current_node_key"] == "assistant"
    assert payload["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert client_calls["init_calls"] == [
        {
            "base_url": OPENROUTER_BASE_URL,
            "api_key": "sk-or-env-test",
            "default_headers": {
                "HTTP-Referer": "https://tests.swarmforge.local",
                "X-OpenRouter-Title": "SwarmForge Test Suite",
            },
        }
    ]
    assert client_calls["chat_calls"][0]["model"] == "openrouter/test-fastapi"


def test_fastapi_multi_agent_usage_uses_bound_routes_and_runtime_state(monkeypatch, repo_env_test):
    del repo_env_test

    def responder(params):
        system_instruction = str((params.get("messages") or [{}])[0].get("content") or "").lower()
        if "triage support requests" in system_instruction:
            return _make_openai_response(
                tool_calls=[
                    {
                        "id": "handoff-1",
                        "name": "transfer_to_agent",
                        "args": {
                            "target_node_key": "billing",
                            "reason": "Billing request confirmed.",
                        },
                    }
                ]
            )
        return _make_openai_response(content="Billing handled the request for ACME-991.")

    client_calls = _install_fake_openai(monkeypatch, responder)
    app = create_swarm_app(
        _bound_support_swarm(),
        extract_required_variables=_extract_account_id,
    )

    swarm_response = asyncio.run(_request(app, "GET", "/swarm"))
    assert swarm_response.status_code == 200
    assert swarm_response.json()["swarm"]["swarm"]["id"] == "support"

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "env-multi-1"},
        )
    )
    assert created.status_code == 200
    assert created.json()["session"]["current_node_key"] == "triage"

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/env-multi-1/messages",
            json={"user_input": "My billing issue is tied to account ACME-991."},
        )
    )

    assert sent.status_code == 200
    payload = sent.json()
    assert payload["events"][0]["event"] == "open"
    assert any(event["event"] == "handoff" for event in payload["events"])
    assert payload["events"][-1]["data"]["fullText"] == "Billing handled the request for ACME-991."
    assert payload["session"]["current_node_key"] == "billing"
    assert payload["session"]["snapshot"]["global_variables"]["account_id"] == "ACME-991"
    assert len(client_calls["chat_calls"]) == 2
    assert all(call["model"] == "openrouter/test-fastapi" for call in client_calls["chat_calls"])

    runtime_response = asyncio.run(_request(app, "GET", "/sessions/env-multi-1/runtime"))
    assert runtime_response.status_code == 200
    runtime = runtime_response.json()["runtime"]
    assert runtime["current_node"]["node_key"] == "billing"
    assert runtime["current_node"]["scratchpad"]["latest_agent_response"] == "Billing handled the request for ACME-991."


def test_fastapi_evaluation_works_with_http_artifacts_from_bound_swarm(monkeypatch, repo_env_test):
    del repo_env_test

    def responder(params):
        system_instruction = str((params.get("messages") or [{}])[0].get("content") or "").lower()
        if "triage support requests" in system_instruction:
            return _make_openai_response(
                tool_calls=[
                    {
                        "id": "handoff-1",
                        "name": "transfer_to_agent",
                        "args": {
                            "target_node_key": "billing",
                            "reason": "Billing request confirmed.",
                        },
                    }
                ]
            )
        return _make_openai_response(content="Billing handled the request for ACME-991.")

    swarm = _bound_support_swarm()
    _install_fake_openai(monkeypatch, responder)
    app = create_swarm_app(
        swarm,
        extract_required_variables=_extract_account_id,
    )

    created = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions",
            json={"session_id": "eval-http-1"},
        )
    )
    assert created.status_code == 200

    sent = asyncio.run(
        _request(
            app,
            "POST",
            "/sessions/eval-http-1/messages",
            json={"user_input": "My billing issue is tied to account ACME-991."},
        )
    )
    assert sent.status_code == 200
    payload = sent.json()

    score = evaluate_scenario_artifacts(
        build_graph_snapshot(swarm),
        {
            "expected_routing": ["triage", "billing"],
            "required_agent_coverage": ["triage", "billing"],
            "expected_variables": {"account_id": "ACME-991"},
            "min_turns": 1,
        },
        event_log=payload["events"],
        checkpoints=payload["checkpoints"],
    )

    assert score["passed"] is True
    assert score["overall_score"] == 1.0
    assert score["actual_routing"] == ["triage", "billing"]
    assert score["final_globals"]["account_id"] == "ACME-991"
