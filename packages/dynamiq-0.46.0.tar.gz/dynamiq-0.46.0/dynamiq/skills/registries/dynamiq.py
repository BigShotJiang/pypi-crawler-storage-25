"""Dynamiq API skill registry."""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from dynamiq.connections import Dynamiq as DynamiqConnection
from dynamiq.connections import HTTPMethod
from dynamiq.skills.registries.base import BaseSkillRegistry
from dynamiq.skills.types import SkillInstructions, SkillMetadata, SkillRegistryError
from dynamiq.skills.utils import normalize_sandbox_skills_base_path
from dynamiq.utils.logger import logger


class DynamiqSkillEntry(BaseModel):
    """Allowed skill entry describing which skills are available to the agent."""

    id: str = Field(..., min_length=1, description="Skill identifier.")
    version_id: str = Field(..., min_length=1, description="Skill version identifier.")
    name: str = Field(..., min_length=1, description="Skill name.")
    description: str | None = Field(default=None, description="Optional cached skill description.")


class Dynamiq(BaseSkillRegistry):
    """Dynamiq skill registry implementation."""

    connection: DynamiqConnection = Field(default_factory=DynamiqConnection)
    timeout: float = Field(default=10, description="Timeout in seconds for API requests.")
    skills: list[DynamiqSkillEntry] = Field(default_factory=list)
    sandbox_skills_base_path: str | None = Field(
        default=None,
        description="When set, get_skill_scripts_path returns "
        "sandbox path for ingested skills (e.g. /home/user/skills).",
    )

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @field_validator("skills", mode="before")
    @classmethod
    def normalize_skills(cls, v: Any) -> Any:
        if v is None:
            return []
        return v

    def get_skills_metadata(self) -> list[SkillMetadata]:
        metadata: list[SkillMetadata] = []
        for entry in self.skills:
            metadata.append(SkillMetadata(name=entry.name, description=entry.description))
        return metadata

    def get_skill_instructions(self, name: str) -> SkillInstructions:
        entry = self._get_entry_by_name(name)
        instructions_text, instructions_metadata = self._fetch_skill_instructions(entry.id, entry.version_id)
        return SkillInstructions(
            name=entry.name,
            description=entry.description,
            instructions=instructions_text,
            metadata=instructions_metadata,
        )

    def _fetch_skill_instructions(self, skill_id: str, version_id: str) -> tuple[str, dict[str, Any] | None]:
        """Fetch skill instructions from the API.

        Supports both plain-text (legacy) and JSON responses. JSON shape should follow
        common API style: {"instructions": "...", "metadata": {...} optional}.
        """
        response = self._request(
            HTTPMethod.GET,
            f"/v1/skills/{skill_id}/versions/{version_id}/instructions",
        )
        if isinstance(response, str):
            return response, None
        if isinstance(response, dict):
            instructions = response.get("instructions") or response.get("content") or ""
            if not isinstance(instructions, str):
                raise SkillRegistryError(
                    "Dynamiq skills API returned object but 'instructions'/'content' is not a string.",
                    details={
                        "skill_id": skill_id,
                        "version_id": version_id,
                    },
                )
            metadata = response.get("metadata")
            if metadata is not None and not isinstance(metadata, dict):
                metadata = None
            return instructions, metadata
        raise SkillRegistryError(
            "Unexpected response from Dynamiq skills API. Expected plain text or JSON object with 'instructions'.",
            details={
                "skill_id": skill_id,
                "version_id": version_id,
                "response_type": type(response).__name__,
            },
        )

    def _get_entry_by_name(self, name: str) -> DynamiqSkillEntry:
        for entry in self.skills:
            if name == entry.name:
                return entry
        raise SkillRegistryError("Skill not in skills.", details={"name": name})

    def get_skill_scripts_path(self, name: str) -> str | None:
        """Return sandbox path to the skill's scripts directory when skills are ingested into sandbox.

        Used by SkillsTool so the agent knows where to run scripts inside the sandbox
        (e.g. /home/user/skills/mermaid-tools/scripts).
        """
        if not self.sandbox_skills_base_path:
            return None
        try:
            self._get_entry_by_name(name)
        except SkillRegistryError:
            return None
        if ".." in name or "/" in name:
            return None
        base = normalize_sandbox_skills_base_path(self.sandbox_skills_base_path)
        if not base:
            return None
        return f"{base}/{name}/scripts"

    def download_skill_archive(self, skill_id: str, version_id: str) -> bytes:
        """Download skill version as a zip archive from the API.

        API is assumed to expose GET /v1/skills/{skill_id}/versions/{version_id}/download
        returning the zip (SKILL.md + scripts/ etc.). Full response body is loaded into
        memory (no streaming). Caller should unzip and upload to sandbox.
        """
        path = f"/v1/skills/{skill_id}/versions/{version_id}/download"
        response = self._request_bytes("GET", path)
        logger.debug(f"Skill archive API: GET {path} -> {len(response)} bytes")
        return response

    def _execute_request(
        self,
        method: str,
        path: str,
        *,
        headers_extra: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        """Build URL and client, execute HTTP request, raise on error. Returns the response object."""
        conn_params = self.connection.conn_params
        base_url = (conn_params.get("api_base") or "").rstrip("/")
        if not base_url:
            raise SkillRegistryError("Dynamiq API base URL is not configured.")

        url = f"{base_url}/{path.lstrip('/')}"
        headers: dict[str, str] = {}
        if headers_extra:
            headers.update(headers_extra)
        conn_headers = conn_params.get("headers")
        if isinstance(conn_headers, dict):
            headers.update(conn_headers)

        client = self.connection.connect()
        try:
            response = client.request(
                method,
                url,
                headers=headers,
                params=params,
                json=json,
                timeout=self.timeout,
            )
        except Exception as exc:
            raise SkillRegistryError(f"Failed to call Dynamiq skills API: {exc}") from exc

        if response.status_code >= 400:
            raise SkillRegistryError(
                f"Request to Dynamiq skills API failed: {response.status_code} {response.text}",
                details={"path": path},
            )
        return response

    def _request_bytes(self, method: str, path: str) -> bytes:
        """Perform a request that returns raw bytes (e.g. zip download)."""
        response = self._execute_request(method, path)
        return response.content

    def _request(
        self,
        method: HTTPMethod,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> Any:
        verb = method.value if isinstance(method, HTTPMethod) else method
        response = self._execute_request(
            verb,
            path,
            headers_extra={"Content-Type": "application/json"},
            params=params,
            json=json,
        )

        if response.status_code == 204 or not response.content:
            logger.debug("Dynamiq skills API returned empty response for %s", path)
            return ""

        content_type = (response.headers.get("content-type") or "").split(";")[0].strip().lower()
        if content_type == "application/json":
            try:
                return response.json()
            except Exception as e:
                raise SkillRegistryError(
                    "Dynamiq skills API returned application/json but body is not valid JSON.",
                    details={"path": path, "error": str(e)},
                ) from e
        return response.text
