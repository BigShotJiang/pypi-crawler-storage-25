import io
import re
from copy import deepcopy
from enum import Enum
from typing import Any, Callable, ClassVar, Union
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, field_validator, model_serializer, model_validator

from dynamiq.connections.managers import ConnectionManager
from dynamiq.memory import Memory, MemoryRetrievalStrategy
from dynamiq.nodes import ErrorHandling, Node, NodeGroup
from dynamiq.nodes.agents.exceptions import AgentUnknownToolException, InvalidActionException, ToolExecutionException
from dynamiq.nodes.agents.prompts.manager import AgentPromptManager
from dynamiq.nodes.agents.prompts.templates import AGENT_PROMPT_TEMPLATE
from dynamiq.nodes.agents.utils import (
    TOOL_MAX_TOKENS,
    ToolCacheEntry,
    ToolOutputSandboxPersistenceConfig,
    convert_bytesio_to_file_info,
    extract_message_text,
    process_tool_output_with_sandbox_persistence,
)
from dynamiq.nodes.llms import BaseLLM
from dynamiq.nodes.node import NodeDependency, ensure_config
from dynamiq.nodes.tools.context_manager import ContextManagerTool
from dynamiq.nodes.tools.file_tools import FileListTool, FileReadTool, FileSearchTool, FileWriteTool
from dynamiq.nodes.tools.mcp import MCPServer
from dynamiq.nodes.tools.parallel_tool_calls import PARALLEL_TOOL_NAME, ParallelToolCallsTool
from dynamiq.nodes.tools.python import Python
from dynamiq.nodes.tools.python_code_executor import PythonCodeExecutor
from dynamiq.nodes.tools.skills_tool import SkillsTool
from dynamiq.nodes.types import InferenceMode
from dynamiq.prompts import Message, MessageRole, Prompt, VisionMessage
from dynamiq.runnables import RunnableConfig, RunnableResult, RunnableStatus
from dynamiq.sandboxes.base import Sandbox, SandboxConfig
from dynamiq.skills.config import SkillsConfig
from dynamiq.skills.registries.dynamiq import Dynamiq
from dynamiq.skills.types import SkillMetadata
from dynamiq.skills.utils import ingest_skills_into_sandbox, normalize_sandbox_skills_base_path
from dynamiq.storages.file.base import FileStore, FileStoreConfig
from dynamiq.storages.file.in_memory import InMemoryFileStore
from dynamiq.utils.logger import logger
from dynamiq.utils.utils import deep_merge


class StreamChunkChoiceDelta(BaseModel):
    """Delta model for content chunks."""
    content: str | dict
    source: str
    step: str

    @field_validator('source')
    @classmethod
    def validate_source(cls, v):
        """Ensure source is always a string."""
        if not isinstance(v, str):
            raise ValueError(f"source must be a string, got {type(v).__name__}: {v}")
        return v

    def _recursive_serialize(self, obj, key_path: str = "", index: int = None):
        """Recursively serialize an object, converting any BytesIO objects to FileInfo objects."""
        if isinstance(obj, io.BytesIO):
            return convert_bytesio_to_file_info(obj, key_path, index).model_dump()

        elif isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                new_key_path = f"{key_path}.{k}" if key_path else k
                result[k] = self._recursive_serialize(v, new_key_path)
            return result

        elif isinstance(obj, list):
            result = []

            for i, item in enumerate(obj):
                new_key_path = f"{key_path}[{i}]" if key_path else f"item_{i}"
                result.append(self._recursive_serialize(item, new_key_path, i))
            return result

        else:
            return obj

    @model_serializer
    def serialize_content(self):
        """Serialize content dict, converting any BytesIO objects to base64 strings while preserving key structure."""
        if self.content is None or not isinstance(self.content, dict):
            return {"content": self.content, "source": self.source, "step": self.step}

        serialized_content = self._recursive_serialize(self.content)

        result = {
            "content": serialized_content,
            "source": self.source,
            "step": self.step,
        }

        return result


class StreamChunkChoice(BaseModel):
    """Stream chunk choice model."""

    delta: StreamChunkChoiceDelta


class StreamChunk(BaseModel):
    """Model for streaming chunks with choices containing delta updates."""

    choices: list[StreamChunkChoice]


class AgentStatus(str, Enum):
    """Represents the status of an agent's execution."""

    SUCCESS = "success"
    FAIL = "fail"


class ToolParams(BaseModel):
    global_params: dict[str, Any] = Field(default_factory=dict, alias="global")
    by_name_params: dict[str, Union[dict[str, Any], "ToolParams"]] = Field(default_factory=dict, alias="by_name")
    by_id_params: dict[str, Union[dict[str, Any], "ToolParams"]] = Field(default_factory=dict, alias="by_id")


class AgentInputSchema(BaseModel):
    input: str = Field(default="", description="Text input for the agent.")
    images: list[str | bytes | io.BytesIO] | None = Field(
        default=None, description="Image inputs (URLs, bytes, or file objects)."
    )
    files: list[io.BytesIO | bytes] | None = Field(
        default=None,
        description="List of file paths to pass to the agent.",
        json_schema_extra={"map_from_storage": True, "is_accessible_to_agent": False},
    )

    user_id: str | None = Field(default=None, description="Parameter to provide user ID.")
    session_id: str | None = Field(default=None, description="Parameter to provide session ID.")
    metadata: dict = Field(default={}, description="Parameter to provide metadata in key-value pairs.")

    model_config = ConfigDict(extra="allow", strict=True, arbitrary_types_allowed=True)

    tool_params: ToolParams | None = Field(
        default_factory=ToolParams,
        description=(
            "Structured parameters for tools. Use 'global_params' for all tools, "
            "'by_name' for tool names, or 'by_id' for tool IDs. "
            "Values are dictionaries merged with tool inputs."
        ),
        json_schema_extra={"is_accessible_to_agent": False},
    )

    @field_validator("tool_params", mode="before")
    @classmethod
    def handle_empty_tool_params(cls, v):
        if v == "" or v is None:
            return ToolParams()
        return v

    @model_validator(mode="after")
    def validate_input_fields(self, context):
        ctx_msg = context.context.get("role") or ""
        messages = [Message(role=MessageRole.USER, content=ctx_msg)]
        if message := context.context.get("input_message"):
            messages.append(message)

        required_parameters = Prompt(messages=messages).get_required_parameters()

        parameters = self.model_dump()
        provided_parameters = set(parameters.keys())

        if not required_parameters.issubset(provided_parameters):
            raise ValueError(
                f"Error: Invalid parameters were provided. Expected: {required_parameters}. "
                f"Got: {provided_parameters}"
            )

        none_elements = []
        for key, value in parameters.items():
            if key in required_parameters and value is None:
                none_elements.append(key)

        if none_elements:
            raise ValueError(f"Error: None was provided for parameters {none_elements}.")

        return self


class Agent(Node):
    """Base class for an AI Agent that interacts with a Language Model and tools."""

    AGENT_PROMPT_TEMPLATE: ClassVar[str] = AGENT_PROMPT_TEMPLATE

    llm: BaseLLM = Field(..., description="LLM used by the agent.")
    group: NodeGroup = NodeGroup.AGENTS
    error_handling: ErrorHandling = Field(default_factory=lambda: ErrorHandling(timeout_seconds=3600))
    tools: list[Node] = []
    files: list[io.BytesIO | bytes] | None = None
    is_files_allowed: bool = True
    images: list[str | bytes | io.BytesIO] = None
    name: str = "Agent"
    max_loops: int = 1
    tool_output_max_length: int = TOOL_MAX_TOKENS
    tool_output_truncate_enabled: bool = True
    tool_output_sandbox_persistence: ToolOutputSandboxPersistenceConfig = Field(
        default_factory=ToolOutputSandboxPersistenceConfig,
        description="Configuration for saving large tool outputs to sandbox files.",
    )
    delegation_allowed: bool = Field(
        default=False,
        description="Allow returning a child agent tool's output directly via delegate_final flag.",
    )
    parallel_tool_calls_enabled: bool = Field(
        default=False,
        description="Enable multi-tool execution in a single step. "
        "When True, the agent can call multiple tools in parallel.",
    )
    memory: Memory | None = Field(None, description="Memory node for the agent.")
    memory_limit: int = Field(100, description="Maximum number of messages to retrieve from memory")
    memory_retrieval_strategy: MemoryRetrievalStrategy | None = MemoryRetrievalStrategy.ALL
    verbose: bool = Field(False, description="Whether to print verbose logs.")
    file_store: FileStoreConfig = Field(
        default_factory=lambda: FileStoreConfig(enabled=False, backend=InMemoryFileStore()),
        description="Configuration for file storage used by the agent.",
    )
    sandbox: SandboxConfig | None = Field(default=None, description="Configuration for sandbox used by the agent.")
    skills: SkillsConfig = Field(
        default_factory=SkillsConfig,
        description="Skills config. When enabled and source registry is set, skills are on (Dynamiq or FileSystem).",
    )

    input_message: Message | VisionMessage | None = None
    role: str | None = Field(
        default=None,
        description="""Agent basic instructions.
            Can be used to provide additional context or instructions to the agent.
            Accepts Jinja templates to provide additional parameters.""",
    )
    description: str | None = Field(default=None, description="Short human-readable description of the agent.")
    _mcp_servers: list[MCPServer] = PrivateAttr(default_factory=list)
    _excluded_tool_ids: set[str] = PrivateAttr(default_factory=set)
    _tool_cache: dict[ToolCacheEntry, Any] = {}
    _history_offset: int = PrivateAttr(
        default=1,  # Offset past the system prompt; everything after is eligible for summarization.
    )
    # Original user input message preserved from compaction and used for memory fallback.
    _pinned_input: Message | VisionMessage | None = PrivateAttr(default=None)
    system_prompt_manager: AgentPromptManager = Field(default_factory=AgentPromptManager)
    _current_call_context: dict[str, Any] | None = PrivateAttr(default=None)

    model_config = ConfigDict(arbitrary_types_allowed=True)
    input_schema: ClassVar[type[AgentInputSchema]] = AgentInputSchema
    _json_schema_fields: ClassVar[list[str]] = ["role", "description"]

    @classmethod
    def _generate_json_schema(
        cls, llms: dict[type[BaseLLM], list[str]] = {}, tools=list[type[Node]], **kwargs
    ) -> dict[str, Any]:
        """
        Generates full json schema for Agent with provided llms and tools.
        This schema is designed for compatibility with the WorkflowYamlParser,
        containing enough partial information to instantiate an Agent.
        Parameters name to be included in the schema are either defined in the _json_schema_fields class variable or
        passed via the fields parameter.

        It generates a schema using the provided LLMs and tools.

        Args:
            llms (dict[type[BaseLLM], list[str]]): Available llm providers and models.
            tools (list[type[Node]]): List of tools.

        Returns:
            dict[str, Any]: Generated json schema.
        """
        schema = super()._generate_json_schema(**kwargs)
        schema["properties"]["llm"] = {
            "anyOf": [
                {
                    "type": "object",
                    **llm._generate_json_schema(models=models, fields=["model", "temperature", "max_tokens"]),
                }
                for llm, models in llms.items()
            ],
            "additionalProperties": False,
        }

        schema["properties"]["tools"] = {
            "type": "array",
            "items": {"anyOf": [{"type": "object", **tool._generate_json_schema()} for tool in tools]},
        }

        schema["required"] += ["tools", "llm"]
        return schema

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        from dynamiq.nodes.tools.agent_tool import SubAgentTool
        self._run_depends: list[dict] = []
        self._prompt = Prompt(messages=[])
        # Added for backward compatibility with old Agent tools

        self.tools = [
            (
                SubAgentTool(agent=t, name=t.name, description=t.description or "")
                if isinstance(t, Agent) and not isinstance(t, SubAgentTool)
                else t
            )
            for t in self.tools
        ]

        expanded_tools = []
        for tool in self.tools:
            if isinstance(tool, MCPServer):
                self._mcp_servers.append(tool)
                subtools = tool.get_mcp_tools()
                expanded_tools.extend(subtools)
                self._excluded_tool_ids.update(subtool.id for subtool in subtools)
            else:
                expanded_tools.append(tool)

        self.tools = expanded_tools
        if self.file_store_backend and self.sandbox_backend:
            raise ValueError("file_store and sandbox cannot both be enabled for an Agent at the same time")

        if self.sandbox_backend:
            # Add sandbox tools when sandbox is enabled (not serialized; recreated from sandbox config on load)
            sandbox_tools = self.sandbox_backend.get_tools(llm=self.llm)
            self._excluded_tool_ids.update(t.id for t in sandbox_tools)
            self.tools.extend(sandbox_tools)

        elif self.file_store_backend:
            # Add file tools when file store is enabled
            self.tools.extend(
                [
                    FileReadTool(file_store=self.file_store_backend, llm=self.llm),
                    FileSearchTool(file_store=self.file_store_backend),
                    FileListTool(file_store=self.file_store_backend),
                ]
            )
            if self.file_store.agent_file_write_enabled:
                self.tools.append(FileWriteTool(file_store=self.file_store_backend))

        if self.parallel_tool_calls_enabled:
            inference_mode = getattr(self, "inference_mode", None)
            use_native_parallel = inference_mode == InferenceMode.FUNCTION_CALLING
            if not use_native_parallel:
                self.tools = [t for t in self.tools if t.name != PARALLEL_TOOL_NAME]
                self.tools.append(ParallelToolCallsTool())

        if self._skills_should_init():
            self._init_skills()
        self._init_prompt_blocks()
        if self._skills_should_init():
            self._apply_skills_to_prompt()

    @model_validator(mode="after")
    def validate_input_fields(self):
        if self.input_message:
            self.input_message.role = MessageRole.USER

        return self

    def get_context_for_input_schema(self) -> dict:
        """Provides context for input schema that is required for proper validation."""
        role_for_validation = self.role or ""
        if role_for_validation and (
            "{% raw %}" not in role_for_validation and "{% endraw %}" not in role_for_validation
        ):
            role_for_validation = f"{{% raw %}}{role_for_validation}{{% endraw %}}"
        return {"input_message": self.input_message, "role": role_for_validation}

    @property
    def to_dict_exclude_params(self):
        return super().to_dict_exclude_params | {
            "llm": True,
            "tools": True,
            "memory": True,
            "files": True,
            "images": True,
            "file_store": True,
            "skills": True,
            "sandbox": True,
            "system_prompt_manager": True,  # Runtime state container, not serializable
        }

    def to_dict(self, **kwargs) -> dict:
        """Converts the instance to a dictionary."""
        data = super().to_dict(**kwargs)
        data["llm"] = self.llm.to_dict(**kwargs)

        tools_to_serialize = [t for t in self.tools if t.id not in self._excluded_tool_ids]
        data["tools"] = [tool.to_dict(**kwargs) for tool in tools_to_serialize]
        data["tools"] = data["tools"] + [mcp_server.to_dict(**kwargs) for mcp_server in self._mcp_servers]

        data["memory"] = self.memory.to_dict(**kwargs) if self.memory else None
        if self.files:
            data["files"] = [{"name": getattr(f, "name", f"file_{i}")} for i, f in enumerate(self.files)]
        if self.images:
            data["images"] = [{"name": getattr(f, "name", f"image_{i}")} for i, f in enumerate(self.images)]

        data["file_store"] = self.file_store.to_dict(**kwargs) if self.file_store else None
        data["sandbox"] = self.sandbox.to_dict(**kwargs) if self.sandbox else None
        data["skills"] = self.skills.to_dict(**kwargs)

        return data

    def init_components(self, connection_manager: ConnectionManager | None = None):
        """
        Initialize components for the manager and agents.

        Args:
            connection_manager (ConnectionManager, optional): The connection manager. Defaults to ConnectionManager.
        """
        connection_manager = connection_manager or ConnectionManager()
        super().init_components(connection_manager)
        if self.llm.is_postponed_component_init:
            self.llm.init_components(connection_manager)

        for tool in self.tools:
            if tool.is_postponed_component_init:
                tool.init_components(connection_manager)
            tool.is_optimized_for_agents = True

        self._ensure_skills_ingested_for_sandbox()

    def _ensure_skills_ingested_for_sandbox(self) -> None:
        """When skills source is Dynamiq with sandbox_skills_base_path and sandbox is enabled, ingest skills at init."""
        if not self.sandbox_backend or not self._skills_should_init():
            return
        source = self.skills.source
        if source is None:
            return

        if not isinstance(source, Dynamiq) or not source.sandbox_skills_base_path:
            return
        try:
            if hasattr(self.sandbox_backend, "_ensure_sandbox"):
                self.sandbox_backend._ensure_sandbox()
            ingest_skills_into_sandbox(
                self.sandbox_backend,
                source,
                sandbox_skills_base_path=source.sandbox_skills_base_path,
            )
            logger.info("Agent %s: skills ingested into sandbox at init", self.name)
        except Exception as e:
            logger.warning("Agent %s: skills ingestion into sandbox failed: %s", self.name, e)

    def sanitize_tool_name(self, s: str):
        """Sanitize tool name to follow [^a-zA-Z0-9_-]."""
        s = s.replace(" ", "-")
        sanitized = re.sub(r"[^a-zA-Z0-9_-]", "", s)
        return sanitized

    def _init_prompt_blocks(self):
        """Initializes default prompt blocks and variables."""
        model_name = getattr(self.llm, "model", None)

        self.system_prompt_manager = AgentPromptManager(model_name=model_name, tool_description=self.tool_description)
        self.system_prompt_manager.setup_for_base_agent()

    def _skills_should_init(self) -> bool:
        """True if skills support should be initialized (enabled and source set)."""
        return self.skills.enabled and self.skills.source is not None

    def _init_skills(self) -> None:
        """Add SkillsTool to self.tools so it is included in function-calling and structured-output schemas."""

        source = self.skills.source
        if source is None:
            logger.warning("Skills config missing or invalid (source required); skipping skills init")
            return
        skills_tool = SkillsTool(skill_registry=source)
        self.tools.append(skills_tool)
        self._excluded_tool_ids.add(skills_tool.id)

    def _apply_skills_to_prompt(self) -> None:
        """Set skills block and tool_description on the prompt manager after _init_prompt_blocks()."""
        source = self.skills.source
        if source is None:
            return
        metadata = self.skills.get_skills_metadata()
        sandbox_base = normalize_sandbox_skills_base_path(getattr(source, "sandbox_skills_base_path", None))
        skills_summary = self._format_skills_summary(
            metadata, sandbox_skills_base_path=sandbox_base if sandbox_base else None
        )
        self.system_prompt_manager.set_block("skills", skills_summary)
        self.system_prompt_manager.set_initial_variable("tool_description", self.tool_description)
        if sandbox_base:
            self.system_prompt_manager.set_initial_variable("sandbox_skills_base_path", sandbox_base)
        logger.info(
            f"Agent {self.name} - {self.id}: initialized with {len(metadata)} skills "
            f"(source={source.__class__.__name__})"
        )

    def _format_skills_summary(self, metadata: list[SkillMetadata], sandbox_skills_base_path: str | None = None) -> str:
        """Format skills summary for prompt.

        When sandbox_skills_base_path is set (caller must pass an already-normalized path or None),
        each line includes the path to read the skill in the sandbox so the agent can go straight
        to SandboxShellTool without calling SkillsTool list.
        """
        if not metadata:
            return ""

        base = sandbox_skills_base_path or ""
        lines = []
        for skill in metadata:
            if base:
                skill_path = f"{base}/{skill.name}/SKILL.md"
                lines.append(f"- **{skill.name}**: {skill.description} — read: `{skill_path}`")
            else:
                lines.append(f"- **{skill.name}**: {skill.description}")
        return "\n".join(lines)

    def set_block(self, block_name: str, content: str):
        """Adds or updates a prompt block."""
        self.system_prompt_manager.set_block(block_name, content)

    def set_prompt_variable(self, variable_name: str, value: Any):
        """Sets or updates a prompt variable."""
        self.system_prompt_manager.set_variable(variable_name, value)

    def _prepare_metadata(self, input_data: AgentInputSchema) -> dict:
        """
        Prepare metadata from input data.

        Args:
            input_data: Agent input schema containing user information

        Returns:
            dict: Processed metadata
        """
        custom_metadata = input_data.metadata.copy()

        # Add extra fields that were provided (model allows extra fields with ConfigDict extra="allow")
        if input_data.model_extra:
            custom_metadata.update(input_data.model_extra)

        # Clean up any leaked fields
        if "files" in custom_metadata:
            del custom_metadata["files"]
        if "images" in custom_metadata:
            del custom_metadata["images"]
        if "tool_params" in custom_metadata:
            del custom_metadata["tool_params"]

        if input_data.user_id:
            custom_metadata["user_id"] = input_data.user_id
        if input_data.session_id:
            custom_metadata["session_id"] = input_data.session_id

        return custom_metadata

    def execute(
        self,
        input_data: AgentInputSchema,
        input_message: Message | VisionMessage | None = None,
        config: RunnableConfig | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Executes the agent with the given input data.
        """
        # Convert to dict only for logging (to avoid logging BytesIO objects)
        log_data = input_data.model_dump()
        if log_data.get("images"):
            log_data["images"] = [f"image_{i}" for i in range(len(log_data["images"]))]
        if log_data.get("files"):
            log_data["files"] = [f"file_{i}" for i in range(len(log_data["files"]))]

        logger.info(f"Agent {self.name} - {self.id}: started with input {log_data}")
        self.reset_run_state()

        config = ensure_config(config)
        self.run_on_node_execute_run(config.callbacks, **kwargs)

        custom_metadata = self._prepare_metadata(input_data)
        self._current_call_context = {
            "user_id": input_data.user_id,
            "session_id": input_data.session_id,
            "metadata": custom_metadata,
        }

        input_message = input_message or self.input_message or Message(role=MessageRole.USER, content=input_data.input)
        # Convert to dict for format_message, excluding fields that are unsafe for templates
        # (binary data like files/images, complex objects like tool_params, and input which is already handled)
        standard_fields = set(AgentInputSchema.model_fields.keys())
        extra_fields = input_data.model_dump(exclude=standard_fields)
        if extra_fields:
            input_message = input_message.format_message(**extra_fields)
        else:
            input_message = input_message.model_copy()
        input_message.static = True

        use_memory = self.memory and (input_data.user_id or input_data.session_id)

        if use_memory:
            history_messages = self._retrieve_memory(input_data)
            if len(history_messages) > 0:
                history_messages.insert(
                    0,
                    Message(
                        role=MessageRole.SYSTEM,
                        content="Below is the previous conversation history. "
                        "Use this context to inform your response.",
                        static=True,
                    ),
                )
        else:
            history_messages = None

        files = input_data.files
        if files:
            normalized_files = self._ensure_named_files(files)
            file_paths = []
            if self.sandbox_backend:
                file_paths = self._upload_files_to_sandbox(normalized_files)
            else:
                if not self.file_store_backend:
                    self._setup_in_memory_file_store_and_tools()
                if self.file_store_backend:
                    file_paths = self._upload_files_to_file_store(normalized_files)
            input_message = self._inject_attached_files_into_message(
                input_message, normalized_files, file_paths=file_paths
            )

        if input_data.tool_params:
            kwargs["tool_params"] = input_data.tool_params

        self.system_prompt_manager.update_variables(dict(input_data))
        kwargs = kwargs | {"parent_run_id": kwargs.get("run_id")}
        kwargs.pop("run_depends", None)

        try:
            result = self._run_agent(input_message, history_messages, config=config, **kwargs)
        except Exception:
            if use_memory:
                try:
                    self._append_user_input_to_memory(custom_metadata)
                except Exception as save_error:
                    logger.error(
                        f"Agent {self.name} - {self.id}: failed to save user input to memory "
                        f"after agent error: {save_error}",
                    )
            raise
        finally:
            self._current_call_context = None

        if use_memory:
            try:
                self._save_history_to_memory(custom_metadata)
            except Exception as save_error:
                logger.error(
                    "Agent %s - %s: failed to save history to memory: %s",
                    self.name,
                    self.id,
                    save_error,
                )

        execution_result = {
            "content": result,
        }

        requested_paths = getattr(self, "_requested_output_files", None)

        if self.file_store_backend and requested_paths:
            try:
                stored_files = self.file_store_backend.list_files_bytes(requested_paths)
            except Exception as e:
                logger.warning(f"Agent {self.name} - {self.id}: failed to collect files from file store: {e}")
                stored_files = []
            if stored_files:
                execution_result["files"] = stored_files
                logger.info(
                    f"Agent {self.name} - {self.id}: "
                    f"returning {len(stored_files)} requested file(s) from file store"
                )

        if self.sandbox_backend and requested_paths:
            try:
                sandbox_files = self.sandbox_backend.collect_files(file_paths=requested_paths)
            except Exception as e:
                logger.warning(f"Agent {self.name} - {self.id}: failed to collect files from sandbox: {e}")
                sandbox_files = []
            if sandbox_files:
                existing_files = execution_result.get("files", [])
                execution_result["files"] = existing_files + sandbox_files
                logger.info(
                    f"Agent {self.name} - {self.id}: "
                    f"returning {len(sandbox_files)} requested file(s) from sandbox"
                )

        logger.info(f"Node {self.name} - {self.id}: finished with RESULT:\n{str(result)[:200]}...")

        return execution_result

    def retrieve_conversation_history(
        self,
        user_query: str = None,
        user_id: str = None,
        session_id: str = None,
        limit: int = None,
        strategy: MemoryRetrievalStrategy = MemoryRetrievalStrategy.ALL,
    ) -> list[Message]:
        """
        Retrieves conversation history for the agent using the specified strategy.

        Args:
            user_query: Current user input to find relevant context (for RELEVANT/HYBRID strategies)
            user_id: Optional user identifier
            session_id: Optional session identifier
            limit: Maximum number of messages to return (defaults to memory_limit)
            strategy: Which retrieval strategy to use (ALL, RELEVANT, or HYBRID)

        Returns:
            List of messages forming a valid conversation context
        """
        if not self.memory or not (user_id or session_id):
            return []

        filters = {}
        if user_id:
            filters["user_id"] = user_id
        if session_id:
            filters["session_id"] = session_id

        limit = limit or self.memory_limit

        if strategy == MemoryRetrievalStrategy.RELEVANT and not user_query:
            logger.warning("RELEVANT strategy selected but no user_query provided - falling back to ALL")
            strategy = MemoryRetrievalStrategy.ALL

        conversation = self.memory.get_agent_conversation(
            query=user_query,
            limit=limit,
            filters=filters,
            strategy=strategy,
        )
        return conversation

    def _retrieve_memory(self, input_data: AgentInputSchema) -> list[Message]:
        """
        Args:
            input_data: Agent input schema containing user information

        Returns:
            list[Message]: List of messages forming a valid conversation context
        Retrieves memory messages when user_id and/or session_id are provided.
        """
        history_messages = self.retrieve_conversation_history(
            user_query=input_data.input,
            user_id=input_data.user_id,
            session_id=input_data.session_id,
            strategy=self.memory_retrieval_strategy,
        )
        logger.info("Agent %s - %s: retrieved %d messages from memory", self.name, self.id, len(history_messages))
        return history_messages

    def _save_history_to_memory(
        self,
        metadata: dict,
    ) -> None:
        """Snapshot prompt state into memory for current user/session scope.

        Replaces only the messages matching current ``user_id``/``session_id``
        filters, then writes every non-system message from ``self._prompt.messages``.
        This avoids wiping unrelated users/sessions when a backend is shared.

        Args:
            metadata: Metadata dict forwarded to each ``memory.add`` call.
        """
        user_id = metadata.get("user_id")
        session_id = metadata.get("session_id")
        if not user_id and not session_id:
            logger.warning(
                f"Agent {self.name} - {self.id}: skipping memory snapshot save "
                f"because at least one of user_id or session_id is required",
            )
            return

        fully_scoped = bool(user_id and session_id)

        saved = 0
        snapshot_messages: list[Message] = []
        for msg in self._prompt.messages:
            if msg.role == MessageRole.SYSTEM:
                continue
            content = extract_message_text(msg)
            snapshot_messages.append(Message(role=msg.role, content=content, metadata=metadata.copy()))
            saved += 1

        if fully_scoped:
            scope_filters = {"user_id": user_id, "session_id": session_id}
            try:
                self.memory.replace_messages(filters=scope_filters, messages=snapshot_messages)
            except NotImplementedError:
                logger.warning(
                    f"Agent {self.name} - {self.id}: backend does not support scoped delete, "
                    "falling back to appending user input and assistant response.",
                )
                self._append_fallback_messages(metadata, snapshot_messages)
                return
        else:
            logger.info(
                f"Agent {self.name} - {self.id}: only one of user_id/session_id provided, "
                "using append-only save to avoid cross-scope data loss.",
            )
            self._append_fallback_messages(metadata, snapshot_messages)
            return

        logger.info(
            f"Agent {self.name} - {self.id}: saved {saved} message(s) to memory",
        )

    def _append_user_input_to_memory(self, metadata: dict) -> None:
        """Append only the user input to memory (used on agent failure).

        Unlike ``_save_history_to_memory`` this never deletes existing data,
        making it safe to call when the agent errored before producing a response.
        """
        if self._pinned_input is None:
            return
        pinned_content = extract_message_text(self._pinned_input)
        self.memory.add(role=MessageRole.USER, content=pinned_content, metadata=metadata.copy())
        logger.info(f"Agent {self.name} - {self.id}: saved user input to memory after agent error")

    def _append_fallback_messages(self, metadata: dict, snapshot_messages: list[Message]) -> None:
        """Append only the user input and last assistant response to memory (safe fallback)."""
        saved = 0
        if self._pinned_input is not None:
            pinned_content = extract_message_text(self._pinned_input)
            self.memory.add(role=MessageRole.USER, content=pinned_content, metadata=metadata.copy())
            saved += 1
        last_assistant = next(
            (m for m in reversed(snapshot_messages) if m.role == MessageRole.ASSISTANT),
            None,
        )
        if last_assistant:
            self.memory.add(
                role=last_assistant.role,
                content=last_assistant.content,
                metadata=metadata.copy(),
            )
            saved += 1
        logger.info(f"Agent {self.name} - {self.id}: saved {saved} message(s) to memory (fallback)")

    def _run_llm(
        self, messages: list[Message | VisionMessage], config: RunnableConfig | None = None, **kwargs
    ) -> RunnableResult:
        """Runs the LLM with a given prompt and handles streaming or full responses.

        Args:
            messages (list[Message | VisionMessage]): Input messages for llm.
            config (Optional[RunnableConfig]): Configuration for the runnable.
            kwargs: Additional keyword arguments.

        Returns:
            RunnableResult: Generated response.
        """
        try:
            llm_result = self.llm.run(
                input_data={},
                config=config,
                prompt=Prompt(messages=messages),
                run_depends=deepcopy(self._run_depends),
                **kwargs,
            )
            self._run_depends = [NodeDependency(node=self.llm).to_dict(for_tracing=True)]
            if llm_result.status != RunnableStatus.SUCCESS:
                error_message = f"LLM '{self.llm.name}' failed: {llm_result.error.message}"
                raise ValueError(error_message)

            return llm_result

        except Exception as e:
            raise e

    def stream_content(
        self,
        content: str | dict,
        source: str,
        step: str,
        config: RunnableConfig | None = None,
        **kwargs,
    ) -> str | dict:
        """
        Streams data.

        Args:
            content (str | dict): Data that will be streamed.
            source (str): Source of the content.
            step (str): Description of the step.
            config (Optional[RunnableConfig]): Configuration for the runnable.
            **kwargs: Additional keyword arguments.

        Returns:
            str | dict: Streamed data.
        """
        if not isinstance(source, str):
            raise ValueError(
                f"stream_content source parameter must be a string, got {type(source).__name__}: {source}. "
                f"This likely indicates incorrect parameter passing from the calling code."
            )

        return self.stream_response(content=content, source=source, step=step, config=config, **kwargs)

    def stream_response(
        self, content: str | dict, source: str, step: str, config: RunnableConfig | None = None, **kwargs
    ):
        if not isinstance(source, str):
            raise ValueError(
                f"stream_response source parameter must be a string, got {type(source).__name__}: {source}. "
                f"This likely indicates a parameter ordering issue in the calling code."
            )

        response_for_stream = StreamChunk(
            choices=[StreamChunkChoice(delta=StreamChunkChoiceDelta(content=content, source=source, step=step))]
        )

        self.run_on_node_execute_stream(
            callbacks=config.callbacks,
            chunk=response_for_stream.model_dump(),
            **kwargs,
        )
        return content

    def _run_agent(
        self,
        input_message: Message | VisionMessage,
        history_messages: list[Message] | None = None,
        config: RunnableConfig | None = None,
        **kwargs,
    ) -> str:
        """Runs the agent with the generated prompt and handles exceptions."""
        formatted_prompt = self.generate_prompt()
        system_message = Message(role=MessageRole.SYSTEM, content=formatted_prompt)
        if history_messages:
            self._prompt.messages = [system_message, *history_messages, input_message]
        else:
            self._prompt.messages = [system_message, input_message]

        self._pinned_input = input_message

        try:
            llm_result = self._run_llm(self._prompt.messages, config=config, **kwargs).output["content"]
            self._prompt.messages.append(Message(role=MessageRole.ASSISTANT, content=llm_result))

            if self.streaming.enabled:
                return self.stream_content(
                    content=llm_result,
                    source=self.name,
                    step="answer",
                    config=config,
                    **kwargs,
                )
            return llm_result

        except Exception as e:
            raise e

    def _get_tool(self, action: str) -> Node:
        """Retrieves the tool corresponding to the given action."""
        tool = self.tool_by_names.get(self.sanitize_tool_name(action))
        if not tool:
            raise AgentUnknownToolException(
                f"Unknown tool: {action}."
                "Use only available tools and provide only the tool's name in the action field. "
                "Do not include any additional reasoning. "
                "Please correct the action field or state that you cannot answer the question."
            )
        return tool

    def _apply_parameters(self, merged_input: dict, params: dict, source: str, debug_info: list = None):
        """Apply parameters from the specified source to the merged input."""
        if debug_info is None:
            debug_info = []
        for key, value in params.items():
            if key in merged_input and isinstance(value, dict) and isinstance(merged_input[key], dict):
                merged_nested = merged_input[key].copy()
                merged_input[key] = deep_merge(value, merged_nested)
                debug_info.append(f"  - From {source}: Merged nested {key}")
            else:
                merged_input[key] = value
                debug_info.append(f"  - From {source}: Set {key}={value}")

    def _regenerate_node_ids(self, obj: Any) -> Any:
        """Recursively assign new IDs to cloned nodes and nested models."""
        if isinstance(obj, BaseModel):
            if hasattr(obj, "id"):
                setattr(obj, "id", str(uuid4()))

            for field_name in getattr(obj, "model_fields", {}):
                value = getattr(obj, field_name)
                if isinstance(value, list):
                    setattr(obj, field_name, [self._regenerate_node_ids(item) for item in value])
                elif isinstance(value, dict):
                    setattr(obj, field_name, {k: self._regenerate_node_ids(v) for k, v in value.items()})
                else:
                    setattr(obj, field_name, self._regenerate_node_ids(value))
            return obj
        if isinstance(obj, list):
            return [self._regenerate_node_ids(item) for item in obj]
        if isinstance(obj, dict):
            return {k: self._regenerate_node_ids(v) for k, v in obj.items()}
        return obj

    def _clone_tool_for_execution(
        self,
        tool: Node,
        config: RunnableConfig | None,
        *,
        clone: bool = True,
        override_source_ids: list[str] | None = None,
        target_id: str | None = None,
    ) -> tuple[Node, RunnableConfig]:
        """Prepare a tool for isolated execution: optionally clone, regenerate IDs, align config overrides."""
        base_config = ensure_config(config)
        original_id = tool.id
        if clone:
            try:
                tool = self._regenerate_node_ids(tool.clone())
            except Exception as e:
                logger.warning(f"Agent {self.name} - {self.id}: failed to clone tool {tool.name}: {e}")
                return tool, base_config
        else:
            try:
                self._regenerate_node_ids(tool)
            except Exception as e:
                logger.warning(f"Agent {self.name} - {self.id}: failed to regenerate IDs for tool {tool.name}: {e}")
                return tool, base_config

        if target_id:
            tool.id = target_id

        try:
            lookup_ids = [original_id] + (override_source_ids or [])
            override = None
            for oid in lookup_ids:
                override = base_config.nodes_override.get(oid)
                if override:
                    break
            if override and tool.id != original_id:
                base_config = base_config.model_copy(deep=False)
                base_config.nodes_override[tool.id] = override
        except Exception as e:
            logger.warning(f"Agent {self.name} - {self.id}: failed to align config override for tool {tool.name}: {e}")

        return tool, base_config

    @staticmethod
    def _extract_file_paths_from_input(tool: Node, merged_input: dict[str, Any]) -> list[str] | None:
        """Extract file path references from map_from_storage fields in tool input.

        Scans the tool's input schema for fields tagged with ``map_from_storage``
        and collects any string values the LLM provided for those fields.

        Returns:
            List of file path strings, or None if no paths were found.
        """
        paths: list[str] = []
        for field_name, field in tool.input_schema.model_fields.items():
            if not (field.json_schema_extra and field.json_schema_extra.get("map_from_storage", False)):
                continue
            value = merged_input.get(field_name)
            if value is None:
                continue
            if isinstance(value, str):
                paths.append(value)
            elif isinstance(value, (list, tuple)):
                paths.extend(v for v in value if isinstance(v, str))
            elif isinstance(value, dict):
                paths.extend(v for v in value.values() if isinstance(v, str))
        return paths or None

    def _inject_files_into_tool(self, tool: Node, merged_input: dict[str, Any]) -> None:
        """Inject files from file store or sandbox into tool input when applicable.

        Sandbox files are only collected when the LLM explicitly references paths
        in ``map_from_storage`` fields.  Otherwise the file store is used, which
        means ``Python`` and ``PythonCodeExecutor`` tools always receive files
        from the file store (never from the sandbox).
        """
        if not tool.is_files_allowed:
            return

        file_paths = self._extract_file_paths_from_input(tool, merged_input)

        if self.sandbox_backend and file_paths:
            files = self.sandbox_backend.collect_files(file_paths=file_paths)
            files_map = {path: file for path, file in zip(file_paths, files)}
        elif self.file_store_backend:
            files = self.file_store_backend.list_files_bytes()
            files_map = {getattr(f, "name", f"file_{id(f)}"): f for f in files}
        else:
            return

        if not files:
            return

        for field_name, field in tool.input_schema.model_fields.items():
            if not (field.json_schema_extra and field.json_schema_extra.get("map_from_storage", False)):
                continue
            value = merged_input.get(field_name)
            if value is None:
                merged_input[field_name] = files
            elif isinstance(value, dict):
                merged_input[field_name] = {
                    k: files_map.get(v, v) if isinstance(v, str) else v for k, v in value.items()
                }
            elif isinstance(value, (list, tuple)):
                merged_input[field_name] = [files_map.get(v, v) if isinstance(v, str) else v for v in value]
            elif isinstance(value, str):
                merged_input[field_name] = files_map.get(value, value)

        if isinstance(tool, Python):
            merged_input["files"] = files

        if isinstance(tool, PythonCodeExecutor) and not tool.file_store and self.file_store_backend:
            tool.file_store = self.file_store_backend
            logger.debug(f"Agent {self.name} - {self.id}: injected file_store into PythonCodeExecutor tool {tool.name}")

    def _run_tool(
        self,
        tool: Node,
        tool_input: dict,
        config,
        update_run_depends: bool = True,
        collect_dependency: bool = False,
        delegate_final: bool = False,
        is_parallel: bool = False,
        tool_run_id: str | None = None,
        **kwargs,
    ) -> Any:
        """Runs a specific tool with the given input."""
        from dynamiq.nodes.tools.agent_tool import SubAgentTool
        merged_input = tool_input.copy() if isinstance(tool_input, dict) else {"input": tool_input}

        if not self.delegation_allowed:
            if delegate_final and self.verbose:
                logger.debug(
                    "Agent %s - %s: delegate_final ignored because delegation_allowed is False",
                    self.name,
                    self.id,
                )
            delegate_final = False
            if isinstance(merged_input, dict) and "delegate_final" in merged_input:
                if self.verbose:
                    logger.debug(
                        "Agent %s - %s: delegate_final removed from tool input because delegation_allowed is False",
                        self.name,
                        self.id,
                    )
                merged_input.pop("delegate_final", None)

        raw_tool_params = kwargs.get("tool_params", ToolParams())
        tool_params = (
            ToolParams.model_validate(raw_tool_params) if isinstance(raw_tool_params, dict) else raw_tool_params
        )

        is_child_agent = isinstance(tool, SubAgentTool)
        resolved_agent = None
        try:
            resolved_agent = tool.get_or_create_agent() if is_child_agent else None

            self._inject_files_into_tool(resolved_agent or tool, merged_input)

            if tool_params:
                debug_info = []
                if self.verbose:
                    debug_info.append(f"Tool parameter merging for {tool.name} (ID: {tool.id}):")
                    debug_info.append(f"Starting with input: {merged_input}")

                # 1. Apply global parameters (lowest priority)
                global_params = tool_params.global_params
                if global_params:
                    self._apply_parameters(merged_input, global_params, "global", debug_info)

                # 2. Apply parameters by tool name (medium priority)
                name_params_any = (
                    tool_params.by_name_params.get(tool.name)
                    or tool_params.by_name_params.get(self.sanitize_tool_name(tool.name))
                    or (resolved_agent and tool_params.by_name_params.get(resolved_agent.name))
                    or (resolved_agent and tool_params.by_name_params.get(self.sanitize_tool_name(resolved_agent.name)))
                )
                if name_params_any:
                    if isinstance(name_params_any, ToolParams):
                        if self.verbose:
                            detail = "will apply to child agent" if is_child_agent else "ignored for non-agent tool"
                            debug_info.append(f"  - From name:{tool.name}: encountered nested ToolParams ({detail})")
                    elif isinstance(name_params_any, dict):
                        self._apply_parameters(merged_input, name_params_any, f"name:{tool.name}", debug_info)

                # 3. Apply parameters by tool ID (highest priority)
                id_params_any = tool_params.by_id_params.get(tool.id) or (
                    resolved_agent and tool_params.by_id_params.get(resolved_agent.id)
                )
                if id_params_any:
                    if isinstance(id_params_any, ToolParams):
                        if self.verbose:
                            detail = "will apply to child agent" if is_child_agent else "ignored for non-agent tool"
                            debug_info.append(f"  - From id:{tool.id}: encountered nested ToolParams ({detail})")
                    elif isinstance(id_params_any, dict):
                        self._apply_parameters(merged_input, id_params_any, f"id:{tool.id}", debug_info)

                if self.verbose and debug_info:
                    logger.debug("\n".join(debug_info))

            child_kwargs = kwargs | {"recoverable_error": True}

            if is_child_agent and self._current_call_context:
                child_context = self._build_child_agent_context(resolved_agent)
                for ctx_key in ("user_id", "session_id"):
                    if ctx_key not in merged_input and child_context.get(ctx_key):
                        merged_input[ctx_key] = child_context[ctx_key]
                if "metadata" not in merged_input and child_context.get("metadata"):
                    merged_input["metadata"] = child_context["metadata"]

            if is_child_agent and tool_params:
                nested_any = (
                    tool_params.by_id_params.get(tool.id)
                    or tool_params.by_id_params.get(getattr(resolved_agent, "id", ""))
                    or tool_params.by_name_params.get(tool.name)
                    or tool_params.by_name_params.get(self.sanitize_tool_name(tool.name))
                    or tool_params.by_name_params.get(getattr(resolved_agent, "name", ""))
                    or tool_params.by_name_params.get(self.sanitize_tool_name(getattr(resolved_agent, "name", "")))
                )
                if nested_any:
                    if isinstance(nested_any, ToolParams):
                        nested_tp = nested_any
                    elif isinstance(nested_any, dict):
                        nested_tp = ToolParams.model_validate(nested_any)
                    else:
                        nested_tp = None
                    if nested_tp:
                        child_kwargs = child_kwargs | {"tool_params": nested_tp}

            effective_delegate_final = delegate_final and is_child_agent
            if is_child_agent and isinstance(merged_input, dict) and "delegate_final" in merged_input:
                effective_delegate_final = effective_delegate_final or bool(merged_input.pop("delegate_final"))

            tool_to_run = resolved_agent if resolved_agent is not None else tool
            tool_config = ensure_config(config)
            if is_parallel and not is_child_agent:
                tool_to_run, tool_config = self._clone_tool_for_execution(tool_to_run, tool_config)
            if is_child_agent and tool.is_factory_mode:
                tool_to_run, tool_config = self._clone_tool_for_execution(
                    resolved_agent,
                    tool_config,
                    clone=False,
                    override_source_ids=[tool.id],
                    target_id=tool_run_id,
                )

            tool_result = tool_to_run.run(
                input_data=merged_input,
                config=tool_config,
                run_depends=deepcopy(self._run_depends),
                **child_kwargs,
            )
            dependency_node = tool_to_run if tool_to_run is not tool else tool
            dependency_dict = NodeDependency(node=dependency_node).to_dict(for_tracing=True)
            if update_run_depends:
                self._run_depends = [dependency_dict]
            if tool_result.status != RunnableStatus.SUCCESS:
                error_message = f"Tool '{tool.name}' failed: {tool_result.error.to_dict()}"
                if tool_result.error.recoverable:
                    raise ToolExecutionException(error_message)
                else:
                    raise ValueError(error_message)

            if is_child_agent and tool.max_calls is not None:
                tool.increment_call_count()

            tool_result_output_content = tool_result.output.get("content")

            saved_files = self._handle_tool_generated_files(tool, tool_result)

            tool_result_content_processed = process_tool_output_with_sandbox_persistence(
                content=tool_result_output_content,
                tool_name=tool.name,
                tool_input=tool_input,
                sandbox=self.sandbox_backend,
                save_tool_output_to_sandbox=bool(self.sandbox_backend and tool.is_output_persisted_in_sandbox_allowed),
                sandbox_persistence_config=self.tool_output_sandbox_persistence,
                max_tokens=self.tool_output_max_length,
                truncate=self.tool_output_truncate_enabled and not effective_delegate_final,
            )

            if saved_files:
                paths = ", ".join(saved_files)
                tool_result_content_processed = f"{tool_result_content_processed}\n\nFiles saved: {paths}"

            output_files = tool_result.output.get("files", [])
            tool_output_meta = {k: v for k, v in tool_result.output.items() if k not in ("content", "files")}

            if not isinstance(tool, ContextManagerTool):
                self._tool_cache[ToolCacheEntry(action=tool.name, action_input=tool_input)] = (
                    tool_result_content_processed,
                    tool_output_meta,
                )
            if collect_dependency:
                return tool_result_content_processed, output_files, tool_output_meta, dependency_dict

            return tool_result_content_processed, output_files, tool_output_meta
        finally:
            if is_child_agent and tool.is_factory_mode and resolved_agent is not None:
                SubAgentTool.cleanup_factory_agent(resolved_agent)

    def _ensure_named_files(self, files: list[io.BytesIO | bytes]) -> list[io.BytesIO | bytes]:
        """Ensure all uploaded files have name and description attributes and store them in storage backend."""
        named = []
        for i, f in enumerate(files):
            if isinstance(f, bytes):
                bio = io.BytesIO(f)
                bio.name = f"file_{i}.bin"
                bio.description = "User-provided file"
                named.append(bio)
            elif isinstance(f, io.BytesIO):
                if not hasattr(f, "name"):
                    f.name = f"file_{i}"
                if not hasattr(f, "description"):
                    f.description = "User-provided file"
                named.append(f)
            else:
                named.append(f)
        return named

    @staticmethod
    def _split_upload_filename(file_name: str) -> tuple[str, str]:
        """Split a file name into stem and extension for suffixing."""
        stem, dot, extension = file_name.rpartition(".")
        if not dot or not stem:
            return file_name, ""
        return stem, f".{extension}"

    def _get_unique_upload_filename(
        self,
        file_name: str,
        seen_names: set[str],
        exists_check: Callable[[str], bool] | None = None,
    ) -> str:
        """Return a collision-free file name, preserving extension."""
        candidate = file_name
        stem, extension = self._split_upload_filename(file_name)
        suffix = 1

        while candidate in seen_names or (exists_check is not None and exists_check(candidate)):
            candidate = f"{stem}_{suffix}{extension}"
            suffix += 1

        seen_names.add(candidate)
        return candidate

    def _list_existing_sandbox_file_names(self) -> set[str]:
        """Best-effort list of existing sandbox file names for collision checks."""
        if not self.sandbox_backend:
            return set()

        try:
            existing_paths = self.sandbox_backend.list_files(target_dir=self.sandbox_backend.base_path)
        except Exception:
            return set()

        existing_names = set()
        for path in existing_paths:
            if isinstance(path, str):
                file_name = path.rsplit("/", 1)[-1]
                if file_name:
                    existing_names.add(file_name)
        return existing_names

    def _handle_tool_generated_files(self, tool: Node, tool_result: RunnableResult) -> list[str]:
        """
        Handle files generated by tools and store them in the file store and/or sandbox.

        Args:
            tool: The tool that generated the files
            tool_result: The result from the tool execution

        Returns:
            List of saved file paths (full sandbox paths or file-store keys).
        """
        if not self.file_store_backend and not self.sandbox_backend:
            return []

        if not (isinstance(tool_result.output, dict) and "files" in tool_result.output):
            return []

        tool_files = tool_result.output.get("files", [])
        if not tool_files:
            return []

        stored_files = []
        for file in tool_files:
            if isinstance(file, io.BytesIO):
                file_name = getattr(file, "name", f"file_{id(file)}.bin")
                file_description = getattr(file, "description", "Tool-generated file")
                content_type = getattr(file, "content_type", "application/octet-stream")

                content = file.read()
                file.seek(0)

                if self.sandbox_backend:
                    try:
                        dest = f"{self.sandbox_backend.base_path}/{file_name}"
                        self.sandbox_backend.upload_file(file_name, content, destination_path=dest)
                        stored_files.append(dest)
                    except Exception as e:
                        logger.warning(f"Failed to upload tool file '{file_name}' to sandbox: {e}")
                elif self.file_store_backend:
                    self.file_store_backend.store(
                        file_path=file_name,
                        content=content,
                        content_type=content_type,
                        metadata={"description": file_description, "source": "tool_generated"},
                        overwrite=True,
                    )
                    stored_files.append(file_name)

            elif isinstance(file, bytes):
                file_name = f"file_{id(file)}.bin"
                file_description = f"Tool-{tool.name}-generated file"
                content_type = "application/octet-stream"

                if self.sandbox_backend:
                    try:
                        dest = f"{self.sandbox_backend.base_path}/{file_name}"
                        self.sandbox_backend.upload_file(file_name, file, destination_path=dest)
                        stored_files.append(dest)
                    except Exception as e:
                        logger.warning(f"Failed to upload tool file '{file_name}' to sandbox: {e}")
                elif self.file_store_backend:
                    self.file_store_backend.store(
                        file_path=file_name,
                        content=file,
                        content_type=content_type,
                        metadata={"description": file_description, "source": "tool_generated"},
                        overwrite=True,
                    )
                    stored_files.append(file_name)
            else:
                logger.warning(f"Unsupported file type from tool '{tool.name}': {type(file)}")

        if stored_files:
            logger.info(f"Tool '{tool.name}' generated {len(stored_files)} file(s): {stored_files}")
        return stored_files

    def _upload_files_to_sandbox(self, normalized_files: list) -> list[str]:
        """Upload file-like objects to the sandbox backend."""
        file_paths = [""] * len(normalized_files)
        seen_names = self._list_existing_sandbox_file_names()
        for index, file_obj in enumerate(normalized_files):
            file_name = getattr(file_obj, "name", None)
            if file_name and hasattr(file_obj, "read"):
                try:
                    if hasattr(file_obj, "seek"):
                        file_obj.seek(0)
                    content = file_obj.read()
                    if isinstance(content, str):
                        content = content.encode("utf-8")
                    unique_file_name = self._get_unique_upload_filename(file_name, seen_names)
                    input_path = f"{self.sandbox_backend.base_path.rstrip('/')}/input/{unique_file_name}"
                    destination_path = self.sandbox_backend.upload_file(
                        unique_file_name, content, destination_path=input_path
                    )
                    file_paths[index] = destination_path
                except Exception as e:
                    logger.warning(f"Failed to upload file {file_name} to sandbox: {e}")
        return file_paths

    def _upload_files_to_file_store(self, normalized_files: list) -> list[str]:
        """Store file-like objects in the file store backend."""
        file_paths = [""] * len(normalized_files)
        seen_names: set[str] = set()

        def file_exists(candidate: str) -> bool:
            try:
                return bool(self.file_store_backend.exists(candidate))
            except Exception:
                return False

        for index, file_obj in enumerate(normalized_files):
            file_name = getattr(file_obj, "name", None)
            if not file_name or not hasattr(file_obj, "read"):
                continue
            try:
                if hasattr(file_obj, "seek"):
                    file_obj.seek(0)
                content = file_obj.read()
                if isinstance(content, str):
                    content = content.encode("utf-8")
                description = getattr(file_obj, "description", "User-provided file")
                unique_file_name = self._get_unique_upload_filename(file_name, seen_names, exists_check=file_exists)
                self.file_store_backend.store(
                    file_path=unique_file_name,
                    content=content,
                    content_type="application/octet-stream",
                    metadata={"description": description, "source": "user_upload"},
                    overwrite=False,
                )
                file_paths[index] = unique_file_name
            except Exception as e:
                logger.warning(f"Failed to store file {file_name} in file store: {e}")
        return file_paths

    def _setup_in_memory_file_store_and_tools(self) -> None:
        """Create in-memory file store and file tools when files are uploaded and no sandbox/file store exists."""
        self.file_store = FileStoreConfig(enabled=True, backend=InMemoryFileStore())
        self.tools.extend(
            [
                FileReadTool(file_store=self.file_store_backend, llm=self.llm),
                FileSearchTool(file_store=self.file_store_backend),
                FileListTool(file_store=self.file_store_backend),
            ]
        )
        new_tool_description = self.tool_description
        self.system_prompt_manager.set_initial_variable("tool_description", new_tool_description)
        if self.system_prompt_manager._prompt_blocks.get("tools") == "":
            from dynamiq.nodes.agents.agent import Agent

            if isinstance(self, Agent):
                from dynamiq.nodes.tools.agent_tool import SubAgentTool

                self.system_prompt_manager.setup_for_react_agent(
                    inference_mode=self.inference_mode,
                    parallel_tool_calls_enabled=self.parallel_tool_calls_enabled,
                    has_tools=True,
                    delegation_allowed=self.delegation_allowed,
                    context_compaction_enabled=self.summarization_config.enabled,
                    todo_management_enabled=(self.file_store.enabled and self.file_store.todo_enabled)
                    or bool(self.sandbox_backend),
                    has_sub_agent_tools=any(isinstance(t, SubAgentTool) for t in self.tools),
                )

    def _inject_attached_files_into_message(
        self,
        input_message: Message | VisionMessage,
        files: list[io.BytesIO],
        file_paths: list[str] | None = None,
    ) -> Message | VisionMessage:
        if not files:
            return input_message

        if not isinstance(input_message, Message):
            return input_message

        file_lines = []

        normalized_paths = file_paths or []
        for index, f in enumerate(files):
            name = getattr(f, "name", None) or "unnamed_file"
            description = getattr(f, "description", "") or ""
            description = description.strip()
            saved_path = normalized_paths[index] if index < len(normalized_paths) else ""
            if not saved_path:
                saved_path = "File is not stored."

            saved_suffix = f" (saved as: {saved_path})"
            if description:
                file_lines.append(f"- {name}{saved_suffix}: {description}")
            else:
                file_lines.append(f"- {name}{saved_suffix}")

        if not file_lines:
            return input_message

        file_section = "\n".join(["\nAttached files available to you:"] + file_lines) + "\n"

        if isinstance(input_message.content, str):
            input_message.content = f"{input_message.content.rstrip()}{file_section}"
        else:
            input_message.content = input_message.content + file_section

        return input_message

    @property
    def file_store_backend(self) -> FileStore | None:
        """Get the file store backend from the configuration if enabled."""
        return self.file_store.backend if self.file_store.enabled else None

    @property
    def sandbox_backend(self) -> Sandbox | None:
        """Get the sandbox backend from the configuration if enabled."""
        return self.sandbox.backend if self.sandbox and self.sandbox.enabled else None

    @property
    def tool_description(self) -> str:
        """Returns a description of the tools available to the agent."""
        return "\n".join([f"- {tool.name}: {tool.description.strip()}" for tool in self.tools]) if self.tools else ""

    @property
    def tool_names(self) -> str:
        """Returns a comma-separated list of tool names available to the agent."""
        return ",".join([self.sanitize_tool_name(tool.name) for tool in self.tools])

    @property
    def tool_by_names(self) -> dict[str, Node]:
        """Returns a dictionary mapping tool names to their corresponding Node objects."""
        return {self.sanitize_tool_name(tool.name): tool for tool in self.tools}

    def reset_run_state(self):
        """Resets the agent's run state."""
        self._run_depends = []
        self._tool_cache: dict[ToolCacheEntry, Any] = {}
        self.system_prompt_manager.reset()

        from dynamiq.nodes.tools.agent_tool import SubAgentTool

        for tool in self.tools:
            if isinstance(tool, SubAgentTool):
                tool.reset_call_count()

    def generate_prompt(self, block_names: list[str] | None = None, **kwargs) -> str:
        """Generates the prompt using specified blocks and variables."""
        return self.system_prompt_manager.generate_prompt(block_names=block_names, **kwargs)

    def _build_child_agent_context(self, child_agent: "Agent") -> dict[str, Any]:
        """Return context for child agents with per-agent ids to isolate their memory."""
        if not self._current_call_context:
            return {}

        suffix_raw = getattr(child_agent, "name", None) or getattr(child_agent, "id", None) or "subagent"
        suffix_clean = self.sanitize_tool_name(str(suffix_raw)) or "subagent"
        child_context: dict[str, Any] = {}

        for ctx_key in ("user_id", "session_id"):
            base_val = self._current_call_context.get(ctx_key)
            if base_val:
                child_context[ctx_key] = f"{base_val}:{suffix_clean}"

        if metadata := self._current_call_context.get("metadata"):
            child_context["metadata"] = metadata

        return child_context

    def get_clone_attr_initializers(self) -> dict[str, Callable[[Node], Any]]:
        base = super().get_clone_attr_initializers()
        from dynamiq.prompts import Prompt

        base.update(
            {
                "_prompt": (lambda _self: Prompt(messages=[]) if Prompt else None),
            }
        )
        return base


class AgentManagerInputSchema(BaseModel):
    action: str = Field(..., description="Parameter to provide action to the manager")
    model_config = ConfigDict(extra="allow", strict=True, arbitrary_types_allowed=True)

    @model_validator(mode="after")
    def validate_action(self, context):
        action = self.action
        if not action or action not in context.context.get("actions"):
            error_message = (
                f"Invalid or missing action: {action}. "  # nosec B608: Static message construction, not SQL-related.
                "Please select an action "
                f"from {context.context.get('actions')}"  # nosec B608: Static message construction, not SQL-related.
            )
            raise InvalidActionException(error_message)
        return self


class AgentManager(Agent):
    """Manager class that extends the Agent class to include specific actions."""

    _actions: dict[str, Callable] = PrivateAttr(default_factory=dict)
    name: str = "agent-manager"
    input_schema: ClassVar[type[AgentManagerInputSchema]] = AgentManagerInputSchema

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._init_actions()

    def to_dict(self, **kwargs) -> dict:
        """Converts the instance to a dictionary."""
        data = super().to_dict(**kwargs)
        data["_actions"] = {
            k: getattr(action, "__name__", str(action))
            for k, action in self._actions.items()
        }
        return data

    def _init_actions(self):
        """Initializes the default actions for the manager."""
        self._actions = {
            "plan": self._plan,
            "assign": self._assign,
            "final": self._final,
            "handle_input": self._handle_input,
        }

    def add_action(self, name: str, action: Callable):
        """Adds a custom action to the manager."""
        self._actions[name] = action

    def get_context_for_input_schema(self) -> dict:
        """Provides context for input schema that is required for proper validation."""
        return {"actions": list(self._actions.keys())}

    def execute(
        self, input_data: AgentManagerInputSchema, config: RunnableConfig | None = None, **kwargs
    ) -> dict[str, Any]:
        """Executes the manager agent with the given input data and action."""
        log_data = dict(input_data).copy()

        if log_data.get("images"):
            log_data["images"] = [f"image_{i}" for i in range(len(log_data["images"]))]

        if log_data.get("files"):
            log_data["files"] = [f"file_{i}" for i in range(len(log_data["files"]))]

        logger.info(f"Agent {self.name} - {self.id}: started with input {log_data}")
        self.reset_run_state()
        config = config or RunnableConfig()
        self.run_on_node_execute_run(config.callbacks, **kwargs)

        action = input_data.action

        self.system_prompt_manager.update_variables(dict(input_data))

        kwargs = kwargs | {"parent_run_id": kwargs.get("run_id")}
        kwargs.pop("run_depends", None)
        _result_llm = self._actions[action](config=config, **kwargs)
        result = {"action": action, "result": _result_llm}

        execution_result = {
            "content": result,
        }
        logger.info(f"Agent {self.name} - {self.id}: finished with RESULT:\n{str(result)[:200]}...")

        return execution_result

    def _plan(self, config: RunnableConfig, **kwargs) -> str:
        """Executes the 'plan' action."""
        prompt = self.system_prompt_manager.render_block(
            "plan", **(self.system_prompt_manager._prompt_variables | kwargs)
        )
        llm_result = self._run_llm([Message(role=MessageRole.USER, content=prompt)], config, **kwargs).output["content"]

        return llm_result

    def _assign(self, config: RunnableConfig, **kwargs) -> str:
        """Executes the 'assign' action."""
        prompt = self.system_prompt_manager.render_block(
            "assign", **(self.system_prompt_manager._prompt_variables | kwargs)
        )
        llm_result = self._run_llm([Message(role=MessageRole.USER, content=prompt)], config, **kwargs).output["content"]

        return llm_result

    def _final(self, config: RunnableConfig, **kwargs) -> str:
        """Executes the 'final' action."""
        prompt = self.system_prompt_manager.render_block(
            "final", **(self.system_prompt_manager._prompt_variables | kwargs)
        )
        llm_result = self._run_llm([Message(role=MessageRole.USER, content=prompt)], config, **kwargs).output["content"]
        if self.streaming.enabled:
            return self.stream_content(
                content=llm_result,
                step="manager_final_output",
                source=self.name,
                config=config,
                **kwargs,
            )
        return llm_result

    def _handle_input(self, config: RunnableConfig, **kwargs) -> str:
        """
        Executes the single 'handle_input' action to either respond or plan
        based on user request complexity.
        """
        prompt = self.system_prompt_manager.render_block(
            "handle_input", **(self.system_prompt_manager._prompt_variables | kwargs)
        )
        llm_result = self._run_llm([Message(role=MessageRole.USER, content=prompt)], config, **kwargs).output["content"]
        return llm_result
