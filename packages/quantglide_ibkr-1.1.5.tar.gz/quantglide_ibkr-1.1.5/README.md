# quantglide-ibkr

QuantGlide IBKR relay agent. Receives trade signals from QuantGlide and places orders via IB Gateway.

## Requirements

- Python 3.9+
- IB Gateway running locally ([download](https://www.interactivebrokers.com/en/trading/ibgateway-stable.php))

## Install

```bash
pip install quantglide-ibkr
```

## Setup (once)

```bash
quantglide-ibkr login
```

Your browser will open a QuantGlide page — click **Authorize**. Done.

## Run

```bash
quantglide-ibkr
```

Leave it running during trading hours (10:25–13:00 ET). It polls for signals automatically.

## Options

```bash
quantglide-ibkr --port 4002   # paper trading (IB Gateway on port 4002)
quantglide-ibkr --dry-run     # test without placing real orders
quantglide-ibkr --no-time-gate  # run outside trading hours (for testing)
```

## Updates

```bash
pip install --upgrade quantglide-ibkr
```
