"""
quantglide-ibkr CLI entry point.

First-time setup (browser-based, no copy-paste):
    quantglide-ibkr login

Start the agent:
    quantglide-ibkr
    quantglide-ibkr --port 4002   # paper trading
    quantglide-ibkr --dry-run     # test without placing orders
"""
import argparse
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

DASHBOARD_URL = "https://app.quantglide.com"
CALLBACK_PORT = 9876
CONFIG_DIR = Path.home() / ".quantglide"
CONFIG_FILE = CONFIG_DIR / ".env"


def _write_config(data: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = []
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            lines = f.readlines()
    for key, value in data.items():
        found = False
        for i, line in enumerate(lines):
            if line.startswith(f"{key}="):
                lines[i] = f"{key}={value}\n"
                found = True
                break
        if not found:
            lines.append(f"{key}={value}\n")
    with open(CONFIG_FILE, "w") as f:
        f.writelines(lines)


def _do_login(port: int):
    """
    Start a local HTTP server, open the browser to the authorize page,
    wait for the callback with the token, save it, done.
    """
    received = {}
    server_ready = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # silence request logs

        def do_GET(self):
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)
            token = params.get("token", [None])[0]

            if token:
                received["token"] = token
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""
                    <html><body style="font-family:sans-serif;text-align:center;padding:60px">
                    <h2 style="color:#22c55e">Connected!</h2>
                    <p>You can close this tab and return to your terminal.</p>
                    <script>setTimeout(()=>window.close(),2000)</script>
                    </body></html>
                """)
            else:
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""
                    <html><body style="font-family:sans-serif;text-align:center;padding:60px">
                    <h2 style="color:#ef4444">Authorization failed</h2>
                    <p>No token received. Please try again.</p>
                    </body></html>
                """)

            # Shut down server after responding
            threading.Thread(target=server.shutdown).start()

    server = HTTPServer(("127.0.0.1", port), CallbackHandler)

    url = f"{DASHBOARD_URL}/ibkr/authorize?callback=http://localhost:{port}"
    print(f"Opening browser to authorize QuantGlide...")
    print(f"If it doesn't open automatically, visit:\n  {url}\n")
    webbrowser.open(url)

    server.serve_forever()

    token = received.get("token")
    if not token:
        print("Authorization cancelled or failed.")
        sys.exit(1)

    _write_config({
        "QUANTGLIDE_TOKEN": token,
        "IBKR_HOST":        "127.0.0.1",
        "IBKR_PORT":        "4001",
        "IBKR_CLIENT_ID":   "10",
    })

    print(f"Authorized! Config saved to {CONFIG_FILE}")
    print()
    print("Make sure IB Gateway is running, then start the agent:")
    print("    quantglide-ibkr")


def main():
    parser = argparse.ArgumentParser(
        prog="quantglide-ibkr",
        description="QuantGlide IBKR relay agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Authorize (first time):
    quantglide-ibkr login

  Start the agent:
    quantglide-ibkr

  Paper trading:
    quantglide-ibkr --port 4002

  Test without placing real orders:
    quantglide-ibkr --dry-run
        """,
    )
    parser.add_argument("command", nargs="?", choices=["login"],
                        help="login: authorize via browser (first-time setup)")
    parser.add_argument("--token", metavar="TOKEN",
                        help="Setup token (alternative to browser login)")
    parser.add_argument("--port", type=int, choices=[4001, 4002],
                        help="IB Gateway port: 4001=live (default), 4002=paper")
    parser.add_argument("--no-time-gate", action="store_true",
                        help="Skip trading hours check (useful for testing)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Claim signals but don't place real orders")
    args = parser.parse_args()

    # ── Browser login ─────────────────────────────────────────────────────────
    if args.command == "login":
        _do_login(CALLBACK_PORT)
        return

    # ── Fallback: manual token paste ──────────────────────────────────────────
    if args.token:
        _write_config({
            "QUANTGLIDE_TOKEN": args.token.strip(),
            "IBKR_HOST":        "127.0.0.1",
            "IBKR_PORT":        str(args.port or 4001),
            "IBKR_CLIENT_ID":   "10",
        })
        print(f"Authorized! Config saved to {CONFIG_FILE}")
        print()
        print("Make sure IB Gateway is running, then start the agent:")
        print("    quantglide-ibkr")
        return

    # ── Config must exist ─────────────────────────────────────────────────────
    if not CONFIG_FILE.exists():
        print("Not authorized yet. Run:")
        print()
        print("    quantglide-ibkr login")
        sys.exit(1)

    # ── Apply port override ───────────────────────────────────────────────────
    if args.port:
        _write_config({"IBKR_PORT": str(args.port)})
        print(f"Port set to {args.port} ({'paper' if args.port == 4002 else 'live'} trading)")

    # ── Launch agent ──────────────────────────────────────────────────────────
    from quantglide_ibkr.agent import run
    run(
        env_path=str(CONFIG_FILE),
        no_time_gate=args.no_time_gate,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    main()
