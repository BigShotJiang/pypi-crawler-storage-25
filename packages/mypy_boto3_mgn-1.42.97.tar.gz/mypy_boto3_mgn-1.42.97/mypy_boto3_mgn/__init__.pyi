"""
Main interface for mgn service.

[Documentation](https://youtype.github.io/boto3_stubs_docs/mypy_boto3_mgn/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from boto3.session import Session
    from mypy_boto3_mgn import (
        Client,
        DescribeJobLogItemsPaginator,
        DescribeJobsPaginator,
        DescribeLaunchConfigurationTemplatesPaginator,
        DescribeReplicationConfigurationTemplatesPaginator,
        DescribeSourceServersPaginator,
        DescribeVcenterClientsPaginator,
        ListApplicationsPaginator,
        ListConnectorsPaginator,
        ListExportErrorsPaginator,
        ListExportsPaginator,
        ListImportErrorsPaginator,
        ListImportFileEnrichmentsPaginator,
        ListImportsPaginator,
        ListManagedAccountsPaginator,
        ListNetworkMigrationAnalysesPaginator,
        ListNetworkMigrationAnalysisResultsPaginator,
        ListNetworkMigrationCodeGenerationSegmentsPaginator,
        ListNetworkMigrationCodeGenerationsPaginator,
        ListNetworkMigrationDefinitionsPaginator,
        ListNetworkMigrationDeployedStacksPaginator,
        ListNetworkMigrationDeploymentsPaginator,
        ListNetworkMigrationExecutionsPaginator,
        ListNetworkMigrationMapperSegmentConstructsPaginator,
        ListNetworkMigrationMapperSegmentsPaginator,
        ListNetworkMigrationMappingUpdatesPaginator,
        ListNetworkMigrationMappingsPaginator,
        ListSourceServerActionsPaginator,
        ListTemplateActionsPaginator,
        ListWavesPaginator,
        MgnClient,
    )

    session = Session()
    client: MgnClient = session.client("mgn")

    describe_job_log_items_paginator: DescribeJobLogItemsPaginator = client.get_paginator("describe_job_log_items")
    describe_jobs_paginator: DescribeJobsPaginator = client.get_paginator("describe_jobs")
    describe_launch_configuration_templates_paginator: DescribeLaunchConfigurationTemplatesPaginator = client.get_paginator("describe_launch_configuration_templates")
    describe_replication_configuration_templates_paginator: DescribeReplicationConfigurationTemplatesPaginator = client.get_paginator("describe_replication_configuration_templates")
    describe_source_servers_paginator: DescribeSourceServersPaginator = client.get_paginator("describe_source_servers")
    describe_vcenter_clients_paginator: DescribeVcenterClientsPaginator = client.get_paginator("describe_vcenter_clients")
    list_applications_paginator: ListApplicationsPaginator = client.get_paginator("list_applications")
    list_connectors_paginator: ListConnectorsPaginator = client.get_paginator("list_connectors")
    list_export_errors_paginator: ListExportErrorsPaginator = client.get_paginator("list_export_errors")
    list_exports_paginator: ListExportsPaginator = client.get_paginator("list_exports")
    list_import_errors_paginator: ListImportErrorsPaginator = client.get_paginator("list_import_errors")
    list_import_file_enrichments_paginator: ListImportFileEnrichmentsPaginator = client.get_paginator("list_import_file_enrichments")
    list_imports_paginator: ListImportsPaginator = client.get_paginator("list_imports")
    list_managed_accounts_paginator: ListManagedAccountsPaginator = client.get_paginator("list_managed_accounts")
    list_network_migration_analyses_paginator: ListNetworkMigrationAnalysesPaginator = client.get_paginator("list_network_migration_analyses")
    list_network_migration_analysis_results_paginator: ListNetworkMigrationAnalysisResultsPaginator = client.get_paginator("list_network_migration_analysis_results")
    list_network_migration_code_generation_segments_paginator: ListNetworkMigrationCodeGenerationSegmentsPaginator = client.get_paginator("list_network_migration_code_generation_segments")
    list_network_migration_code_generations_paginator: ListNetworkMigrationCodeGenerationsPaginator = client.get_paginator("list_network_migration_code_generations")
    list_network_migration_definitions_paginator: ListNetworkMigrationDefinitionsPaginator = client.get_paginator("list_network_migration_definitions")
    list_network_migration_deployed_stacks_paginator: ListNetworkMigrationDeployedStacksPaginator = client.get_paginator("list_network_migration_deployed_stacks")
    list_network_migration_deployments_paginator: ListNetworkMigrationDeploymentsPaginator = client.get_paginator("list_network_migration_deployments")
    list_network_migration_executions_paginator: ListNetworkMigrationExecutionsPaginator = client.get_paginator("list_network_migration_executions")
    list_network_migration_mapper_segment_constructs_paginator: ListNetworkMigrationMapperSegmentConstructsPaginator = client.get_paginator("list_network_migration_mapper_segment_constructs")
    list_network_migration_mapper_segments_paginator: ListNetworkMigrationMapperSegmentsPaginator = client.get_paginator("list_network_migration_mapper_segments")
    list_network_migration_mapping_updates_paginator: ListNetworkMigrationMappingUpdatesPaginator = client.get_paginator("list_network_migration_mapping_updates")
    list_network_migration_mappings_paginator: ListNetworkMigrationMappingsPaginator = client.get_paginator("list_network_migration_mappings")
    list_source_server_actions_paginator: ListSourceServerActionsPaginator = client.get_paginator("list_source_server_actions")
    list_template_actions_paginator: ListTemplateActionsPaginator = client.get_paginator("list_template_actions")
    list_waves_paginator: ListWavesPaginator = client.get_paginator("list_waves")
    ```
"""

from .client import MgnClient
from .paginator import (
    DescribeJobLogItemsPaginator,
    DescribeJobsPaginator,
    DescribeLaunchConfigurationTemplatesPaginator,
    DescribeReplicationConfigurationTemplatesPaginator,
    DescribeSourceServersPaginator,
    DescribeVcenterClientsPaginator,
    ListApplicationsPaginator,
    ListConnectorsPaginator,
    ListExportErrorsPaginator,
    ListExportsPaginator,
    ListImportErrorsPaginator,
    ListImportFileEnrichmentsPaginator,
    ListImportsPaginator,
    ListManagedAccountsPaginator,
    ListNetworkMigrationAnalysesPaginator,
    ListNetworkMigrationAnalysisResultsPaginator,
    ListNetworkMigrationCodeGenerationSegmentsPaginator,
    ListNetworkMigrationCodeGenerationsPaginator,
    ListNetworkMigrationDefinitionsPaginator,
    ListNetworkMigrationDeployedStacksPaginator,
    ListNetworkMigrationDeploymentsPaginator,
    ListNetworkMigrationExecutionsPaginator,
    ListNetworkMigrationMapperSegmentConstructsPaginator,
    ListNetworkMigrationMapperSegmentsPaginator,
    ListNetworkMigrationMappingsPaginator,
    ListNetworkMigrationMappingUpdatesPaginator,
    ListSourceServerActionsPaginator,
    ListTemplateActionsPaginator,
    ListWavesPaginator,
)

Client = MgnClient

__all__ = (
    "Client",
    "DescribeJobLogItemsPaginator",
    "DescribeJobsPaginator",
    "DescribeLaunchConfigurationTemplatesPaginator",
    "DescribeReplicationConfigurationTemplatesPaginator",
    "DescribeSourceServersPaginator",
    "DescribeVcenterClientsPaginator",
    "ListApplicationsPaginator",
    "ListConnectorsPaginator",
    "ListExportErrorsPaginator",
    "ListExportsPaginator",
    "ListImportErrorsPaginator",
    "ListImportFileEnrichmentsPaginator",
    "ListImportsPaginator",
    "ListManagedAccountsPaginator",
    "ListNetworkMigrationAnalysesPaginator",
    "ListNetworkMigrationAnalysisResultsPaginator",
    "ListNetworkMigrationCodeGenerationSegmentsPaginator",
    "ListNetworkMigrationCodeGenerationsPaginator",
    "ListNetworkMigrationDefinitionsPaginator",
    "ListNetworkMigrationDeployedStacksPaginator",
    "ListNetworkMigrationDeploymentsPaginator",
    "ListNetworkMigrationExecutionsPaginator",
    "ListNetworkMigrationMapperSegmentConstructsPaginator",
    "ListNetworkMigrationMapperSegmentsPaginator",
    "ListNetworkMigrationMappingUpdatesPaginator",
    "ListNetworkMigrationMappingsPaginator",
    "ListSourceServerActionsPaginator",
    "ListTemplateActionsPaginator",
    "ListWavesPaginator",
    "MgnClient",
)
