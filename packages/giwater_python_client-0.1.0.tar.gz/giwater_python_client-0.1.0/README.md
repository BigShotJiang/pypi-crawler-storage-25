## GiwaTer Python Client

Python client library for interacting with the **GiwaTer Universal Router** contract.

### Installation

From [PyPI](https://pypi.org/project/giwater-python-client/):

```bash
pip install giwater-python-client
```

From a checkout:

```bash
uv sync
```

### Quick Start

```bash
cp env.example .env
```

```python
import os
from dotenv import load_dotenv

from giwaterweb3 import GiwaTerClient

load_dotenv()

client = GiwaTerClient(
    private_key=os.environ["PRIVATE_KEY"],
    http_rpc_url=os.environ["RPC_URL"],
    universal_router_address=os.environ["ROUTER_ADDRESS"],
)

# Example (view call)
# token0, token1 = client.contract.sort_tokens("0x...", "0x...")
```

### Dev

```bash
uv sync --group dev
uv run pytest
```

