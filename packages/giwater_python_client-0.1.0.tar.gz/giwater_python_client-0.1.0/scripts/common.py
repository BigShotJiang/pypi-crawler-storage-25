"""Shared helpers for example CLI scripts (swap, add liquidity)."""

from __future__ import annotations

import asyncio
import os
from typing import Any

from dotenv import load_dotenv
from eth_account import Account
from web3 import Web3

from giwaterweb3 import GiwaTerClient
from giwaterweb3.abis.router_liquidity_fragment import erc20_min_abi


def load_env() -> None:
    load_dotenv()


def env_required(key: str) -> str:
    v = os.environ.get(key)
    if not v:
        raise SystemExit(f"Missing required environment variable: {key}")
    return v


def make_client() -> GiwaTerClient:
    return GiwaTerClient(
        private_key=env_required("PRIVATE_KEY"),
        http_rpc_url=env_required("RPC_URL"),
        universal_router_address=env_required("ROUTER_ADDRESS"),
    )


def erc20(w3: Web3, token: str):
    return w3.eth.contract(address=Web3.to_checksum_address(token), abi=erc20_min_abi)


async def ensure_erc20_allowance(
    *,
    w3: Web3,
    owner: str,
    private_key: str,
    token: str,
    spender: str,
    required: int,
    gas: int = 500_000,
) -> None:
    """Approve `spender` for `required` if current allowance is insufficient."""
    c = erc20(w3, token)
    cur: int = await asyncio.to_thread(
        c.functions.allowance(Web3.to_checksum_address(owner), Web3.to_checksum_address(spender)).call
    )
    if cur >= required:
        return
    acct = Account.from_key(private_key)
    fn = c.functions.approve(Web3.to_checksum_address(spender), required)
    tx = fn.build_transaction(
        {
            "from": acct.address,
            "nonce": w3.eth.get_transaction_count(acct.address),
            "gas": gas,
        }
    )
    signed = w3.eth.account.sign_transaction(tx, private_key=private_key)
    h = await asyncio.to_thread(w3.eth.send_raw_transaction, signed.raw_transaction)
    await asyncio.to_thread(w3.eth.wait_for_transaction_receipt, h)


def route_hop(
    *,
    token_from: str,
    token_to: str,
    stable: bool,
    factory: str,
) -> dict[str, Any]:
    return {
        "from": Web3.to_checksum_address(token_from),
        "to": Web3.to_checksum_address(token_to),
        "stable": stable,
        "factory": Web3.to_checksum_address(factory),
    }


def deadline_seconds(offset: int = 600) -> int:
    import time

    return int(time.time()) + offset
