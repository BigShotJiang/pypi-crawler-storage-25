#!/usr/bin/env python3
"""
Add liquidity on a Solidly-style classic router (token/token or ETH/token).

The Universal Router ABI shipped with this client does not include addLiquidity.
Set LIQUIDITY_ROUTER_ADDRESS to your deployment's router that implements the
same function shapes as in `giwaterweb3.abis.router_liquidity_fragment`.

Examples:

  uv run python scripts/add_liquidity.py tokens \\
    --token-a 0x... --token-b 0x... \\
    --amount-a 1000000000000000000 --amount-b 2000000000000000000 \\
    --stable

  uv run python scripts/add_liquidity.py eth \\
    --token 0x... --amount-token 1000000000000000000 \\
    --eth 0.05 --stable

Requires: PRIVATE_KEY, RPC_URL, ROUTER_ADDRESS (for default factory reads),
  LIQUIDITY_ROUTER_ADDRESS (classic router for mint).
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from decimal import Decimal
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(_ROOT / "src"))

from web3 import Web3

from giwaterweb3.abis.router_liquidity_fragment import router_liquidity_abi
from giwaterweb3.contract import ContractFunctions

from common import deadline_seconds, ensure_erc20_allowance, load_env, make_client


async def _add_tokens(args: argparse.Namespace) -> None:
    load_env()
    client = make_client()
    liq_router = os.environ.get("LIQUIDITY_ROUTER_ADDRESS")
    if not liq_router:
        raise SystemExit("Set LIQUIDITY_ROUTER_ADDRESS to the router that supports addLiquidity.")

    pk = client.account.key.hex()
    spender = Web3.to_checksum_address(liq_router)
    slip = int(args.slippage_bps)
    a_des = int(args.amount_a)
    b_des = int(args.amount_b)
    a_min = (a_des * (10_000 - slip)) // 10_000
    b_min = (b_des * (10_000 - slip)) // 10_000

    await ensure_erc20_allowance(
        w3=client.w3,
        owner=client.address,
        private_key=pk,
        token=args.token_a,
        spender=liq_router,
        required=a_des,
    )
    await ensure_erc20_allowance(
        w3=client.w3,
        owner=client.address,
        private_key=pk,
        token=args.token_b,
        spender=liq_router,
        required=b_des,
    )

    liq = ContractFunctions(
        http_rpc_url=os.environ["RPC_URL"],
        private_key=pk,
        contract_address=liq_router,
        contract_abi=router_liquidity_abi,
    )
    receipt = await liq.transact(
        "addLiquidity",
        Web3.to_checksum_address(args.token_a),
        Web3.to_checksum_address(args.token_b),
        bool(args.stable),
        a_des,
        b_des,
        a_min,
        b_min,
        Web3.to_checksum_address(args.recipient or client.address),
        deadline_seconds(),
    )
    h = receipt.get("transactionHash")
    print("addLiquidity:", h.hex() if hasattr(h, "hex") else h)


async def _add_eth(args: argparse.Namespace) -> None:
    load_env()
    client = make_client()
    liq_router = os.environ.get("LIQUIDITY_ROUTER_ADDRESS")
    if not liq_router:
        raise SystemExit("Set LIQUIDITY_ROUTER_ADDRESS to the router that supports addLiquidityETH.")

    pk = client.account.key.hex()
    token_des = int(args.amount_token)
    slip = int(args.slippage_bps)
    token_min = (token_des * (10_000 - slip)) // 10_000
    eth_wei = client.w3.to_wei(Decimal(args.eth), "ether")
    eth_min = (eth_wei * (10_000 - slip)) // 10_000

    await ensure_erc20_allowance(
        w3=client.w3,
        owner=client.address,
        private_key=pk,
        token=args.token,
        spender=liq_router,
        required=token_des,
    )

    liq = ContractFunctions(
        http_rpc_url=os.environ["RPC_URL"],
        private_key=pk,
        contract_address=liq_router,
        contract_abi=router_liquidity_abi,
    )
    receipt = await liq.transact(
        "addLiquidityETH",
        Web3.to_checksum_address(args.token),
        bool(args.stable),
        token_des,
        token_min,
        eth_min,
        Web3.to_checksum_address(args.recipient or client.address),
        deadline_seconds(),
        eth_amount=eth_wei,
    )
    h = receipt.get("transactionHash")
    print("addLiquidityETH:", h.hex() if hasattr(h, "hex") else h)


def main() -> None:
    p = argparse.ArgumentParser(description="Add liquidity (classic Solidly-style router)")
    sub = p.add_subparsers(dest="mode", required=True)

    t = sub.add_parser("tokens", help="ERC20 / ERC20 pair")
    t.add_argument("--token-a", required=True)
    t.add_argument("--token-b", required=True)
    t.add_argument("--amount-a", required=True)
    t.add_argument("--amount-b", required=True)
    t.add_argument("--stable", action="store_true")
    t.add_argument("--slippage-bps", type=int, default=50)
    t.add_argument("--recipient", default="")

    e = sub.add_parser("eth", help="ETH + ERC20 pair")
    e.add_argument("--token", required=True)
    e.add_argument("--amount-token", required=True)
    e.add_argument("--eth", required=True, help="ETH amount e.g. 0.05")
    e.add_argument("--stable", action="store_true")
    e.add_argument("--slippage-bps", type=int, default=50)
    e.add_argument("--recipient", default="")

    args = p.parse_args()
    if args.mode == "tokens":
        asyncio.run(_add_tokens(args))
    else:
        asyncio.run(_add_eth(args))


if __name__ == "__main__":
    main()
