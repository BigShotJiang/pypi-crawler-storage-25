#!/usr/bin/env python3
"""
Swap tokens (or native ETH) via GiwaTer Universal Router.

Examples:

  # Token -> token (single hop)
  uv run python scripts/swap_tokens.py tokens \\
    --token-in 0xTokenA --token-out 0xTokenB \\
    --amount-in 1000000000000000000 --stable

  # ETH -> token (wraps via router; first hop must be WETH)
  uv run python scripts/swap_tokens.py eth \\
    --eth-in 0.1 --token-out 0xTokenB --stable

  # Token -> ETH
  uv run python scripts/swap_tokens.py tokens-for-eth \\
    --token-in 0xTokenA --amount-in 1000000000000000000 --stable

Requires: PRIVATE_KEY, RPC_URL, ROUTER_ADDRESS in environment (.env).
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from decimal import Decimal
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(_ROOT / "src"))

from web3 import Web3

from common import (
    deadline_seconds,
    ensure_erc20_allowance,
    load_env,
    make_client,
    route_hop,
)


def _wei_from_eth(w3: Web3, eth_amount: str) -> int:
    return w3.to_wei(Decimal(eth_amount), "ether")


async def _run_token_swap(args: argparse.Namespace) -> None:
    load_env()
    client = make_client()
    w3 = client.w3
    factory = client.contract.default_factory()
    stable = bool(args.stable)
    routes = [
        route_hop(
            token_from=args.token_in,
            token_to=args.token_out,
            stable=stable,
            factory=factory,
        )
    ]
    amount_in = int(args.amount_in)
    amounts = client.contract.get_amounts_out(amount_in, routes)
    expected_out = amounts[-1] if amounts else 0
    slip = int(args.slippage_bps)
    amount_out_min = (expected_out * (10_000 - slip)) // 10_000

    await ensure_erc20_allowance(
        w3=w3,
        owner=client.address,
        private_key=client.account.key.hex(),
        token=args.token_in,
        spender=client.universal_router_address,
        required=amount_in,
    )

    dl = deadline_seconds()
    receipt = await client.contract.swap_exact_tokens_for_tokens(
        amount_in,
        amount_out_min,
        routes,
        Web3.to_checksum_address(args.recipient or client.address),
        dl,
    )
    print("swapExactTokensForTokens:", receipt.get("transactionHash", receipt).hex())


async def _run_tokens_for_eth(args: argparse.Namespace) -> None:
    load_env()
    client = make_client()
    w3 = client.w3
    weth = client.contract.weth()
    factory = client.contract.default_factory()
    stable = bool(args.stable)
    routes = [
        route_hop(
            token_from=args.token_in,
            token_to=weth,
            stable=stable,
            factory=factory,
        )
    ]
    amount_in = int(args.amount_in)
    amounts = client.contract.get_amounts_out(amount_in, routes)
    expected_out = amounts[-1] if amounts else 0
    slip = int(args.slippage_bps)
    amount_out_min = (expected_out * (10_000 - slip)) // 10_000

    await ensure_erc20_allowance(
        w3=w3,
        owner=client.address,
        private_key=client.account.key.hex(),
        token=args.token_in,
        spender=client.universal_router_address,
        required=amount_in,
    )

    dl = deadline_seconds()
    receipt = await client.contract.swap_exact_tokens_for_eth(
        amount_in,
        amount_out_min,
        routes,
        Web3.to_checksum_address(args.recipient or client.address),
        dl,
    )
    h = receipt.get("transactionHash")
    print("swapExactTokensForETH:", h.hex() if hasattr(h, "hex") else h)


async def _run_eth_swap(args: argparse.Namespace) -> None:
    load_env()
    client = make_client()
    w3 = client.w3
    weth = client.contract.weth()
    factory = client.contract.default_factory()
    stable = bool(args.stable)
    routes = [
        route_hop(
            token_from=weth,
            token_to=args.token_out,
            stable=stable,
            factory=factory,
        )
    ]
    eth_wei = _wei_from_eth(w3, args.eth_in)
    amounts = client.contract.get_amounts_out(eth_wei, routes)
    expected_out = amounts[-1] if amounts else 0
    slip = int(args.slippage_bps)
    amount_out_min = (expected_out * (10_000 - slip)) // 10_000

    dl = deadline_seconds()
    receipt = await client.contract.swap_exact_eth_for_tokens(
        amount_out_min,
        routes,
        Web3.to_checksum_address(args.recipient or client.address),
        dl,
        eth_amount=eth_wei,
    )
    h = receipt.get("transactionHash")
    print("swapExactETHForTokens:", h.hex() if hasattr(h, "hex") else h)


def main() -> None:
    p = argparse.ArgumentParser(description="Swap on GiwaTer Universal Router")
    sub = p.add_subparsers(dest="mode", required=True)

    t = sub.add_parser("tokens", help="ERC20 -> ERC20")
    t.add_argument("--token-in", required=True)
    t.add_argument("--token-out", required=True)
    t.add_argument("--amount-in", required=True, help="Amount in token smallest units (wei)")
    t.add_argument("--stable", action="store_true", help="Use stable pool for the hop")
    t.add_argument("--slippage-bps", type=int, default=50, help="Slippage in basis points (default 50 = 0.5%)")
    t.add_argument("--recipient", default="", help="Defaults to signer address")

    e = sub.add_parser("eth", help="ETH -> ERC20 (via WETH route)")
    e.add_argument("--eth-in", required=True, help="ETH amount, e.g. 0.1")
    e.add_argument("--token-out", required=True)
    e.add_argument("--stable", action="store_true")
    e.add_argument("--slippage-bps", type=int, default=50)
    e.add_argument("--recipient", default="")

    x = sub.add_parser("tokens-for-eth", help="ERC20 -> ETH (unwraps via WETH)")
    x.add_argument("--token-in", required=True)
    x.add_argument("--amount-in", required=True)
    x.add_argument("--stable", action="store_true")
    x.add_argument("--slippage-bps", type=int, default=50)
    x.add_argument("--recipient", default="")

    args = p.parse_args()
    if args.mode == "tokens":
        asyncio.run(_run_token_swap(args))
    elif args.mode == "eth":
        asyncio.run(_run_eth_swap(args))
    else:
        asyncio.run(_run_tokens_for_eth(args))


if __name__ == "__main__":
    main()
