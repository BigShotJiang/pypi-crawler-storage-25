from giwaterweb3 import GiwaTerClient


def test_import() -> None:
    _ = GiwaTerClient(
        private_key="0x" + "1" * 64,
        http_rpc_url="https://example.com",
        universal_router_address="0x" + "2" * 40,
    )

