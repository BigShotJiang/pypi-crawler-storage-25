from .giwa_universal_router import giwater_universal_router_abi

__all__ = ["giwater_universal_router_abi"]

