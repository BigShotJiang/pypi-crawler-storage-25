"""
Minimal ABI fragments for Solidly-style volatile/stable pool routers.

The bundled GiwaTer Universal Router ABI in this repo exposes swaps and pool
views, but not `addLiquidity`. Many deployments use a separate classic router
for liquidity; point `LIQUIDITY_ROUTER_ADDRESS` at that contract when using the
add-liquidity script.
"""

from __future__ import annotations

from typing import Any

# Velodrome V2 / Aerodrome / Solidly fork style
router_liquidity_abi: list[dict[str, Any]] = [
    {
        "type": "function",
        "name": "addLiquidity",
        "inputs": [
            {"name": "tokenA", "type": "address", "internalType": "address"},
            {"name": "tokenB", "type": "address", "internalType": "address"},
            {"name": "stable", "type": "bool", "internalType": "bool"},
            {"name": "amountADesired", "type": "uint256", "internalType": "uint256"},
            {"name": "amountBDesired", "type": "uint256", "internalType": "uint256"},
            {"name": "amountAMin", "type": "uint256", "internalType": "uint256"},
            {"name": "amountBMin", "type": "uint256", "internalType": "uint256"},
            {"name": "to", "type": "address", "internalType": "address"},
            {"name": "deadline", "type": "uint256", "internalType": "uint256"},
        ],
        "outputs": [
            {"name": "amountA", "type": "uint256", "internalType": "uint256"},
            {"name": "amountB", "type": "uint256", "internalType": "uint256"},
            {"name": "liquidity", "type": "uint256", "internalType": "uint256"},
        ],
        "stateMutability": "nonpayable",
    },
    {
        "type": "function",
        "name": "addLiquidityETH",
        "inputs": [
            {"name": "token", "type": "address", "internalType": "address"},
            {"name": "stable", "type": "bool", "internalType": "bool"},
            {"name": "amountTokenDesired", "type": "uint256", "internalType": "uint256"},
            {"name": "amountTokenMin", "type": "uint256", "internalType": "uint256"},
            {"name": "amountETHMin", "type": "uint256", "internalType": "uint256"},
            {"name": "to", "type": "address", "internalType": "address"},
            {"name": "deadline", "type": "uint256", "internalType": "uint256"},
        ],
        "outputs": [
            {"name": "amountToken", "type": "uint256", "internalType": "uint256"},
            {"name": "amountETH", "type": "uint256", "internalType": "uint256"},
            {"name": "liquidity", "type": "uint256", "internalType": "uint256"},
        ],
        "stateMutability": "payable",
    },
]

erc20_min_abi: list[dict[str, Any]] = [
    {
        "type": "function",
        "name": "approve",
        "inputs": [
            {"name": "spender", "type": "address", "internalType": "address"},
            {"name": "amount", "type": "uint256", "internalType": "uint256"},
        ],
        "outputs": [{"name": "", "type": "bool", "internalType": "bool"}],
        "stateMutability": "nonpayable",
    },
    {
        "type": "function",
        "name": "allowance",
        "inputs": [
            {"name": "owner", "type": "address", "internalType": "address"},
            {"name": "spender", "type": "address", "internalType": "address"},
        ],
        "outputs": [{"name": "", "type": "uint256", "internalType": "uint256"}],
        "stateMutability": "view",
    },
    {
        "type": "function",
        "name": "decimals",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint8", "internalType": "uint8"}],
        "stateMutability": "view",
    },
]
