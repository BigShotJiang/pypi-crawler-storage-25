"""
ABI for the GiwaTer Universal Router contract.

Synced from Giwater-App `packages/shared/src/abis/json/GiwaUniversalRouter.json`
(https://github.com/GiwaTer-Labs/Giwater-App/blob/badd5f8bd63b95ffd9f6d07982a5758c38d74f31/packages/shared/src/abis/json/GiwaUniversalRouter.json).

Compatible with `web3.py` (Contract ABI JSON format).
"""

giwater_universal_router_abi = [
    {
        "type": "constructor",
        "inputs": [
            {
                "name": "_permit2",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "_factory",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "_clFactory",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "_weth",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "nonpayable"
    },
    {
        "type": "receive",
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactInput",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactInputParams",
                "components": [
                    {
                        "name": "path",
                        "type": "bytes",
                        "internalType": "bytes"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountIn",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOutMinimum",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "amountOut",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactInputSingle",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactInputSingleParams",
                "components": [
                    {
                        "name": "tokenIn",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tokenOut",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tickSpacing",
                        "type": "int24",
                        "internalType": "int24"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountIn",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOutMinimum",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "sqrtPriceLimitX96",
                        "type": "uint160",
                        "internalType": "uint160"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "amountOut",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactInputSingleWithPermit",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactInputSingleParams",
                "components": [
                    {
                        "name": "tokenIn",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tokenOut",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tickSpacing",
                        "type": "int24",
                        "internalType": "int24"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountIn",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOutMinimum",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "sqrtPriceLimitX96",
                        "type": "uint160",
                        "internalType": "uint160"
                    }
                ]
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amountOut",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactInputWithPermit",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactInputParams",
                "components": [
                    {
                        "name": "path",
                        "type": "bytes",
                        "internalType": "bytes"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountIn",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOutMinimum",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amountOut",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactOutput",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactOutputParams",
                "components": [
                    {
                        "name": "path",
                        "type": "bytes",
                        "internalType": "bytes"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOut",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountInMaximum",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactOutputSingle",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactOutputSingleParams",
                "components": [
                    {
                        "name": "tokenIn",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tokenOut",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tickSpacing",
                        "type": "int24",
                        "internalType": "int24"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOut",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountInMaximum",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "sqrtPriceLimitX96",
                        "type": "uint160",
                        "internalType": "uint160"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactOutputSingleWithPermit",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactOutputSingleParams",
                "components": [
                    {
                        "name": "tokenIn",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tokenOut",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "tickSpacing",
                        "type": "int24",
                        "internalType": "int24"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOut",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountInMaximum",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "sqrtPriceLimitX96",
                        "type": "uint160",
                        "internalType": "uint160"
                    }
                ]
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clExactOutputWithPermit",
        "inputs": [
            {
                "name": "params",
                "type": "tuple",
                "internalType": "struct IGiwaUniversalRouter.CLExactOutputParams",
                "components": [
                    {
                        "name": "path",
                        "type": "bytes",
                        "internalType": "bytes"
                    },
                    {
                        "name": "recipient",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "deadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountOut",
                        "type": "uint256",
                        "internalType": "uint256"
                    },
                    {
                        "name": "amountInMaximum",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "clFactory",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "clSwapCallback",
        "inputs": [
            {
                "name": "amount0Delta",
                "type": "int256",
                "internalType": "int256"
            },
            {
                "name": "amount1Delta",
                "type": "int256",
                "internalType": "int256"
            },
            {
                "name": "_data",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [],
        "stateMutability": "nonpayable"
    },
    {
        "type": "function",
        "name": "defaultFactory",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "getAmountsOut",
        "inputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "getReserves",
        "inputs": [
            {
                "name": "tokenA",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "tokenB",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "stable",
                "type": "bool",
                "internalType": "bool"
            },
            {
                "name": "_factory",
                "type": "address",
                "internalType": "address"
            }
        ],
        "outputs": [
            {
                "name": "reserveA",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "reserveB",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "permit2",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "poolFor",
        "inputs": [
            {
                "name": "tokenA",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "tokenB",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "stable",
                "type": "bool",
                "internalType": "bool"
            },
            {
                "name": "_factory",
                "type": "address",
                "internalType": "address"
            }
        ],
        "outputs": [
            {
                "name": "pool",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "function",
        "name": "sortTokens",
        "inputs": [
            {
                "name": "tokenA",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "tokenB",
                "type": "address",
                "internalType": "address"
            }
        ],
        "outputs": [
            {
                "name": "token0",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "token1",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "pure"
    },
    {
        "type": "function",
        "name": "swapExactETHForTokens",
        "inputs": [
            {
                "name": "amountOutMin",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            },
            {
                "name": "to",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "deadline",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "payable"
    },
    {
        "type": "function",
        "name": "swapExactTokensForETH",
        "inputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "amountOutMin",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            },
            {
                "name": "to",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "deadline",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "nonpayable"
    },
    {
        "type": "function",
        "name": "swapExactTokensForETHWithPermit",
        "inputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "amountOutMin",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            },
            {
                "name": "to",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "deadline",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "nonpayable"
    },
    {
        "type": "function",
        "name": "swapExactTokensForTokens",
        "inputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "amountOutMin",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            },
            {
                "name": "to",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "deadline",
                "type": "uint256",
                "internalType": "uint256"
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "nonpayable"
    },
    {
        "type": "function",
        "name": "swapExactTokensForTokensWithPermit",
        "inputs": [
            {
                "name": "amountIn",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "amountOutMin",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "routes",
                "type": "tuple[]",
                "internalType": "struct IRouter.Route[]",
                "components": [
                    {
                        "name": "from",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "to",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "stable",
                        "type": "bool",
                        "internalType": "bool"
                    },
                    {
                        "name": "factory",
                        "type": "address",
                        "internalType": "address"
                    }
                ]
            },
            {
                "name": "to",
                "type": "address",
                "internalType": "address"
            },
            {
                "name": "deadline",
                "type": "uint256",
                "internalType": "uint256"
            },
            {
                "name": "permitSingle",
                "type": "tuple",
                "internalType": "struct IAllowanceTransfer.PermitSingle",
                "components": [
                    {
                        "name": "details",
                        "type": "tuple",
                        "internalType": "struct IAllowanceTransfer.PermitDetails",
                        "components": [
                            {
                                "name": "token",
                                "type": "address",
                                "internalType": "address"
                            },
                            {
                                "name": "amount",
                                "type": "uint160",
                                "internalType": "uint160"
                            },
                            {
                                "name": "expiration",
                                "type": "uint48",
                                "internalType": "uint48"
                            },
                            {
                                "name": "nonce",
                                "type": "uint48",
                                "internalType": "uint48"
                            }
                        ]
                    },
                    {
                        "name": "spender",
                        "type": "address",
                        "internalType": "address"
                    },
                    {
                        "name": "sigDeadline",
                        "type": "uint256",
                        "internalType": "uint256"
                    }
                ]
            },
            {
                "name": "signature",
                "type": "bytes",
                "internalType": "bytes"
            }
        ],
        "outputs": [
            {
                "name": "amounts",
                "type": "uint256[]",
                "internalType": "uint256[]"
            }
        ],
        "stateMutability": "nonpayable"
    },
    {
        "type": "function",
        "name": "weth",
        "inputs": [],
        "outputs": [
            {
                "name": "",
                "type": "address",
                "internalType": "address"
            }
        ],
        "stateMutability": "view"
    },
    {
        "type": "error",
        "name": "ETHTransferFailed",
        "inputs": []
    },
    {
        "type": "error",
        "name": "ExcessiveInputAmount",
        "inputs": []
    },
    {
        "type": "error",
        "name": "Expired",
        "inputs": []
    },
    {
        "type": "error",
        "name": "InsufficientOutputAmount",
        "inputs": []
    },
    {
        "type": "error",
        "name": "InvalidCLPool",
        "inputs": []
    },
    {
        "type": "error",
        "name": "InvalidPath",
        "inputs": []
    },
    {
        "type": "error",
        "name": "InvalidTokenInForETHDeposit",
        "inputs": []
    },
    {
        "type": "error",
        "name": "OnlyWETH",
        "inputs": []
    },
    {
        "type": "error",
        "name": "PoolDoesNotExist",
        "inputs": []
    },
    {
        "type": "error",
        "name": "SameAddresses",
        "inputs": []
    },
    {
        "type": "error",
        "name": "ZeroAddress",
        "inputs": []
    }
]
