"""
Contract Functions Module.

Mirrors the `standard.py` project layout but targets the GiwaTer Universal Router.
Provides a thin wrapper around `web3.py` contract calls and transactions.
"""

from __future__ import annotations

import asyncio
from typing import Any

from eth_account import Account
from web3 import Web3


class ContractFunctions:
    """Contract interaction helpers for the GiwaTer Universal Router."""

    def __init__(
        self,
        *,
        http_rpc_url: str,
        private_key: str,
        contract_address: str,
        contract_abi: list[dict[str, Any]],
    ) -> None:
        # Validate private key early
        self.account = Account.from_key(private_key)
        self.private_key = private_key
        self.address = self.account.address

        self.provider = Web3.HTTPProvider(http_rpc_url)
        self.w3 = Web3(self.provider)
        self.w3.eth.default_account = self.w3.eth.account.from_key(private_key)

        self.contract_address = Web3.to_checksum_address(contract_address)
        self.contract_abi = contract_abi

    def get_contract(self):
        return self.w3.eth.contract(address=self.contract_address, abi=self.contract_abi)

    def call(self, function_name: str, *args):
        """Call a view/pure function synchronously."""
        contract = self.get_contract()
        fn = getattr(contract.functions, function_name)(*args)
        return fn.call()

    async def transact(
        self,
        function_name: str,
        *args,
        eth_amount: int = 0,
        gas: int = 3_000_000,
        gas_price_wei: int | None = None,
    ) -> dict[str, Any]:
        """Send a state-changing tx and await receipt."""
        contract = self.get_contract()
        fn = getattr(contract.functions, function_name)(*args)

        tx_params: dict[str, Any] = {
            "from": self.address,
            "nonce": self.w3.eth.get_transaction_count(self.address),
            "gas": gas,
        }
        if gas_price_wei is not None:
            tx_params["gasPrice"] = gas_price_wei
        if eth_amount:
            tx_params["value"] = eth_amount

        tx = fn.build_transaction(tx_params)
        signed = self.w3.eth.account.sign_transaction(tx, private_key=self.private_key)

        tx_hash = await asyncio.to_thread(self.w3.eth.send_raw_transaction, signed.raw_transaction)
        receipt = await asyncio.to_thread(self.w3.eth.wait_for_transaction_receipt, tx_hash)
        return dict(receipt)

    # ----------------------------
    # Router helpers (selected)
    # ----------------------------

    # Basic pool views
    def sort_tokens(self, token_a: str, token_b: str):
        return self.call("sortTokens", token_a, token_b)

    def pool_for(self, token_a: str, token_b: str, stable: bool, factory: str):
        return self.call("poolFor", token_a, token_b, stable, factory)

    def get_reserves(self, token_a: str, token_b: str, stable: bool, factory: str):
        return self.call("getReserves", token_a, token_b, stable, factory)

    def get_amounts_out(self, amount_in: int, routes: list[dict[str, Any]]):
        return self.call("getAmountsOut", amount_in, routes)

    def permit2(self):
        return self.call("permit2")

    def weth(self):
        return self.call("weth")

    def cl_factory(self):
        return self.call("clFactory")

    def default_factory(self):
        return self.call("defaultFactory")

    # Swaps (basic)
    async def swap_exact_tokens_for_tokens(
        self,
        amount_in: int,
        amount_out_min: int,
        routes: list[dict[str, Any]],
        to: str,
        deadline: int,
    ):
        return await self.transact(
            "swapExactTokensForTokens", amount_in, amount_out_min, routes, to, deadline
        )

    async def swap_exact_eth_for_tokens(
        self,
        amount_out_min: int,
        routes: list[dict[str, Any]],
        to: str,
        deadline: int,
        *,
        eth_amount: int,
    ):
        return await self.transact(
            "swapExactETHForTokens",
            amount_out_min,
            routes,
            to,
            deadline,
            eth_amount=eth_amount,
        )

    async def swap_exact_tokens_for_eth(
        self,
        amount_in: int,
        amount_out_min: int,
        routes: list[dict[str, Any]],
        to: str,
        deadline: int,
    ):
        return await self.transact("swapExactTokensForETH", amount_in, amount_out_min, routes, to, deadline)

    # CL swaps (struct params)
    async def cl_exact_input_single(self, params: dict[str, Any], *, eth_amount: int = 0):
        return await self.transact("clExactInputSingle", params, eth_amount=eth_amount)

    async def cl_exact_input(self, params: dict[str, Any], *, eth_amount: int = 0):
        return await self.transact("clExactInput", params, eth_amount=eth_amount)

    async def cl_exact_output_single(self, params: dict[str, Any], *, eth_amount: int = 0):
        return await self.transact("clExactOutputSingle", params, eth_amount=eth_amount)

    async def cl_exact_output(self, params: dict[str, Any], *, eth_amount: int = 0):
        return await self.transact("clExactOutput", params, eth_amount=eth_amount)

