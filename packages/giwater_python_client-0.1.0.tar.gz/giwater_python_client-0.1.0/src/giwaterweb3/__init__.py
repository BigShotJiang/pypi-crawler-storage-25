"""
GiwaterWeb3 Client Library.

A Python library for interacting with the GiwaTer Universal Router contract,
plus optional API/WebSocket helpers (mirroring the standard.py project layout).
"""

from giwaterweb3.abis.giwa_universal_router import giwater_universal_router_abi
from giwaterweb3.contract import ContractFunctions


class GiwaTerClient:
    """GiwaTer Web3 client."""

    def __init__(
        self,
        *,
        private_key: str,
        http_rpc_url: str,
        universal_router_address: str,
    ) -> None:
        self.universal_router_address = universal_router_address

        self.contract = ContractFunctions(
            http_rpc_url=http_rpc_url,
            private_key=private_key,
            contract_address=universal_router_address,
            contract_abi=giwater_universal_router_abi,
        )

        self.w3 = self.contract.w3
        self.address = self.contract.address
        self.account = self.contract.account

