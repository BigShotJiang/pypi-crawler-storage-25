"""OS-level keystore backends for the local stdio MCP client.

Phase D of MCP issue #13534. Stores the user's AES-256 *derived key*
(32 bytes, produced once by ``CryptoManager._derive_key`` from the
passphrase + server salt) so subsequent MCP sessions don't have to
re-prompt for the passphrase or pay the ~300ms PBKDF2 cost on every
start.

We deliberately store the derived key, not the passphrase, because:

- The key, once derived, is the only thing the runtime actually needs.
- Re-deriving PBKDF2-HMAC-SHA256 at 600,000 iterations is ~200-500ms on
  modern laptops — a noticeable per-session tax for a tool that opens
  twice per Claude/ChatGPT spin-up.
- The passphrase is also useful for the user (they may type it from
  memory); the derived key is not. Storing the less-recoverable secret
  in the keystore minimizes blast radius if someone exfiltrates the
  on-disk store.

Backends (priority order — see ``get_keystore()``):

1. **1Password CLI** (``OnePasswordKeyStore``) — if the ``op`` binary is
   on PATH and is signed in. Best UX: Touch ID via 1Password's own
   biometric gate, syncs across the user's devices, audit log via
   1Password's web console.
2. **OS keychain** (``KeychainKeyStore``) — wraps the ``keyring`` library.
   On macOS, that's the system Keychain (Touch-ID-gated by default for
   the user's login keychain). On Linux, GNOME Keyring / KWallet via
   Secret Service.
3. **Plaintext file** (``PlaintextKeyStore``) — last resort, opt-in only
   via ``insecure_plaintext=True``. Writes ``~/.whenful/key.b64`` with
   ``0o600`` permissions. Documented as a security downgrade.

All three are documented as user-selectable in the plan doc §11 Q3 —
locked as MUST-haves by Alex on the 2026-04-09 plan.

Privacy & telemetry posture
---------------------------

Zero telemetry. The ``op`` subprocess is invoked with ``stdin``-piped
input so the key never appears on the process command line (and thus
never lands in shell history or ``ps`` output). ``__repr__`` redacts the
backend's name only — not any payload. ``KeyStoreError`` carries no
secret material in its message.

This module must NOT import from ``app.*``. The ``mcp_stdio`` subpackage
ships as a separately publishable wheel in Phase F.
"""

from __future__ import annotations

import base64
import os
import shutil
import subprocess
from pathlib import Path
from typing import Final, Protocol, runtime_checkable

#: Service identifier used for ``keyring`` lookups. The ``keyring`` library
#: treats this as the namespace under which an "account" key is stored.
#: Stable across versions — changing it orphans existing keychain entries.
KEYRING_SERVICE: Final[str] = "whenful-mcp"

#: Default 1Password item title. Users can override by passing a custom
#: ``item_title`` to ``OnePasswordKeyStore`` if they share a vault and need
#: disambiguation; the default is fine for the common single-user case.
ONEPASSWORD_ITEM_TITLE: Final[str] = "Whenful MCP Encryption Key"

#: Default 1Password field name on the stored item. Items of category
#: ``password`` ship with a ``password`` field by default; we reuse it
#: rather than creating a custom one so ``op item get --fields password``
#: works without extra schema.
ONEPASSWORD_FIELD: Final[str] = "password"

#: Default plaintext-fallback path. Override at construction time for
#: tests or unusual setups.
DEFAULT_PLAINTEXT_PATH: Final[str] = "~/.whenful/key.b64"


class KeyStoreError(Exception):
    """Base class for keystore errors raised by this module.

    The message never contains the key material itself — only the
    backend-level cause (e.g., "op exited with status 1", "permission
    denied on ~/.whenful/key.b64"). Callers should surface the message
    verbatim to the user without further redaction.
    """


@runtime_checkable
class KeyStore(Protocol):
    """Protocol every keystore backend satisfies.

    Methods are intentionally synchronous: keystore I/O is fast (single
    keychain query or one ``op`` shell-out) and the stdio MCP client is
    not in a hot loop. An async wrapper can sit on top in Phase E if the
    main event loop needs it.

    ``account`` is the user-identifying key — typically the email of the
    Whenful account paired to this device. Multiple accounts on the same
    machine round-trip independently.
    """

    def save(self, account: str, key: bytes) -> None:
        """Persist ``key`` under ``account``. Overwrites any prior value."""

    def load(self, account: str) -> bytes | None:
        """Return ``key`` for ``account``, or ``None`` if not present."""

    def delete(self, account: str) -> None:
        """Remove the entry for ``account``. Idempotent — no error if absent."""


# ---------------------------------------------------------------------------
# Backend 1: keyring (OS keychain / Secret Service)
# ---------------------------------------------------------------------------


class KeychainKeyStore:
    """Wraps the cross-platform ``keyring`` library.

    On macOS this stores into the user's login Keychain (Touch ID-gated
    by the OS — no special handling needed; the first read of the session
    prompts and is cached for the session by ``securityd``). On Linux
    that's GNOME Keyring / KWallet via the Secret Service D-Bus protocol.
    On Windows it's the Credential Manager.

    Stored value is the **base64 encoding** of the derived-key bytes,
    because ``keyring`` accepts only ``str``. We round-trip via base64
    so the on-disk representation stays human-inspectable (the user
    can verify with Keychain Access.app that *some* opaque-looking
    string is stored) without sacrificing fidelity.
    """

    __slots__ = ("_service",)

    def __init__(self, service: str = KEYRING_SERVICE) -> None:
        self._service: str = service

    @staticmethod
    def is_available() -> bool:
        """Return whether ``keyring`` resolves a usable backend on this
        host.

        Returns ``False`` if ``keyring`` is not importable OR if the
        resolved backend is the ``fail`` / ``null`` no-op (set when no
        secret service is reachable on the platform). Callers use this
        in ``get_keystore()`` to decide whether to fall through to the
        plaintext backend.
        """
        try:
            import keyring
            from keyring.backends import fail as _fail_backend
        except ImportError:
            return False
        try:
            backend = keyring.get_keyring()
        except Exception:  # noqa: BLE001 — keyring init can raise anything
            return False
        return not isinstance(backend, _fail_backend.Keyring)

    def save(self, account: str, key: bytes) -> None:
        import keyring

        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")
        try:
            keyring.set_password(self._service, account, encoded)
        except Exception as exc:  # noqa: BLE001 — keyring raises platform-specific errors
            raise KeyStoreError(f"keyring set_password failed: {exc!r}") from exc

    def load(self, account: str) -> bytes | None:
        import keyring

        try:
            encoded = keyring.get_password(self._service, account)
        except Exception as exc:  # noqa: BLE001
            raise KeyStoreError(f"keyring get_password failed: {exc!r}") from exc
        if encoded is None:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored keyring value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:
        import keyring
        from keyring.errors import PasswordDeleteError

        try:
            keyring.delete_password(self._service, account)
        except PasswordDeleteError:
            # Not present — idempotent contract; swallow.
            return
        except Exception as exc:  # noqa: BLE001
            raise KeyStoreError(f"keyring delete_password failed: {exc!r}") from exc

    def __repr__(self) -> str:
        return f"KeychainKeyStore(service={self._service!r})"


# ---------------------------------------------------------------------------
# Backend 2: 1Password CLI (op)
# ---------------------------------------------------------------------------


class OnePasswordKeyStore:
    """Shells out to the 1Password ``op`` CLI.

    Requires the user to have ``op`` installed (Homebrew: ``brew install
    1password-cli``) and to have run ``op signin`` for the relevant
    account. ``is_available()`` checks both conditions.

    The key bytes round-trip through base64 (same as ``KeychainKeyStore``)
    so the stored value is opaque-ASCII rather than binary. The key is
    passed to ``op`` via **stdin**, not via the command line — this keeps
    it out of ``ps`` output and the user's shell history.

    Item lookup is by title (default ``ONEPASSWORD_ITEM_TITLE``) inside
    the user's default 1Password account; passing ``vault=...`` to the
    constructor narrows lookup to a specific vault.
    """

    __slots__ = ("_item_title", "_vault", "_op_binary")

    def __init__(
        self,
        *,
        item_title: str = ONEPASSWORD_ITEM_TITLE,
        vault: str | None = None,
        op_binary: str = "op",
    ) -> None:
        self._item_title: str = item_title
        self._vault: str | None = vault
        self._op_binary: str = op_binary

    @staticmethod
    def is_available(op_binary: str = "op") -> bool:
        """Return whether ``op`` is on PATH AND a signed-in account exists.

        We run ``op account list`` and check exit status — a non-zero
        exit (no accounts configured, or auth required) makes this
        backend unusable for the current process.
        """
        if shutil.which(op_binary) is None:
            return False
        try:
            result = subprocess.run(  # noqa: S603 — op is the user's installed CLI, no shell
                [op_binary, "account", "list", "--format=json"],
                capture_output=True,
                timeout=5.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        if result.returncode != 0:
            return False
        # ``op account list`` returns ``[]`` (empty JSON array) when the
        # binary is installed but no account has been added yet. Anything
        # non-empty plus a 0 exit means at least one account is
        # configured — that's good enough; ``op item get`` will prompt
        # for biometric/Touch ID at use time.
        stdout = result.stdout.decode("utf-8", errors="ignore").strip()
        return bool(stdout) and stdout != "[]"

    def save(self, account: str, key: bytes) -> None:
        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")
        # Pipe the secret via stdin (``@/dev/stdin`` file reference, per
        # 1Password CLI assignment syntax) instead of placing it on argv,
        # so the AES-256 derived key never appears in ``ps``, ``proc_pidinfo``,
        # screen-shared sessions, or EDR agent process logs. Non-secret
        # arguments (title, vault, category, username) stay on argv.
        item_ref = self._item_title
        if self._exists(account):
            cmd = [
                self._op_binary,
                "item",
                "edit",
                item_ref,
                f"{ONEPASSWORD_FIELD}[password]=@/dev/stdin",
            ]
        else:
            cmd = [
                self._op_binary,
                "item",
                "create",
                "--category=password",
                f"--title={item_ref}",
                f"{ONEPASSWORD_FIELD}[password]=@/dev/stdin",
                f"username={account}",
            ]
            if self._vault is not None:
                cmd.append(f"--vault={self._vault}")
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                input=encoded.encode("ascii"),
                capture_output=True,
                timeout=30.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item save failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip()
            raise KeyStoreError(f"op item save exited {result.returncode}: {stderr}")

    def load(self, account: str) -> bytes | None:  # noqa: ARG002 — account encoded as username; lookup is by title
        cmd = [
            self._op_binary,
            "item",
            "get",
            self._item_title,
            f"--fields={ONEPASSWORD_FIELD}",
            "--reveal",
        ]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=30.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item get failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip().lower()
            # ``op`` returns non-zero with "isn't an item" / "doesn't exist"
            # when the title isn't present in the vault — treat as "no
            # value stored" per the KeyStore.load contract.
            if "isn't an item" in stderr or "doesn't exist" in stderr or "not found" in stderr:
                return None
            raise KeyStoreError(f"op item get exited {result.returncode}: {stderr}")
        encoded = result.stdout.decode("utf-8", errors="ignore").strip()
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored 1Password value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:  # noqa: ARG002
        cmd = [self._op_binary, "item", "delete", self._item_title]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=30.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise KeyStoreError(f"op item delete failed: {exc!r}") from exc
        if result.returncode != 0:
            stderr = result.stderr.decode("utf-8", errors="ignore").strip().lower()
            if "isn't an item" in stderr or "doesn't exist" in stderr or "not found" in stderr:
                return
            raise KeyStoreError(f"op item delete exited {result.returncode}: {stderr}")

    def _exists(self, account: str) -> bool:  # noqa: ARG002
        cmd = [self._op_binary, "item", "get", self._item_title, "--format=json"]
        if self._vault is not None:
            cmd.extend(["--vault", self._vault])
        try:
            result = subprocess.run(  # noqa: S603
                cmd,
                capture_output=True,
                timeout=10.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        return result.returncode == 0

    def __repr__(self) -> str:
        return f"OnePasswordKeyStore(item_title={self._item_title!r}, vault={self._vault!r})"


# ---------------------------------------------------------------------------
# Backend 3: plaintext file (escape hatch)
# ---------------------------------------------------------------------------


class PlaintextKeyStore:
    """Last-resort backend that writes the key to a 0o600 file.

    Use only when neither 1Password nor the OS keychain is available
    (e.g., headless Linux with no Secret Service, CI without keychain).
    Users must opt in explicitly via ``get_keystore(insecure_plaintext=True)``
    — the factory never selects this silently.

    File format: base64(key) on a single line, UTF-8, no trailing
    newline. The parent directory is created with ``0o700`` and the file
    with ``0o600`` so other local users cannot read either.
    """

    __slots__ = ("_path",)

    def __init__(self, path: str | Path = DEFAULT_PLAINTEXT_PATH) -> None:
        self._path: Path = Path(path).expanduser()

    @property
    def path(self) -> Path:
        return self._path

    def save(self, account: str, key: bytes) -> None:  # noqa: ARG002 — single-account file
        if not isinstance(key, (bytes, bytearray)):
            raise KeyStoreError("key must be bytes")
        encoded = base64.b64encode(bytes(key)).decode("ascii")
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            # Restrictive mode at open time so umask can't loosen it.
            fd = os.open(str(self._path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(encoded)
            # Belt-and-suspenders chmod in case umask masked the open mode.
            try:
                os.chmod(str(self._path), 0o600)
                os.chmod(str(self._path.parent), 0o700)
            except OSError:
                # Best effort on platforms without POSIX modes.
                pass
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore write to {self._path} failed: {exc!r}") from exc

    def load(self, account: str) -> bytes | None:  # noqa: ARG002
        if not self._path.exists():
            return None
        try:
            with self._path.open("r", encoding="utf-8") as f:
                encoded = f.read().strip()
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore read from {self._path} failed: {exc!r}") from exc
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise KeyStoreError(f"stored plaintext value is not valid base64: {exc!r}") from exc

    def delete(self, account: str) -> None:  # noqa: ARG002
        try:
            self._path.unlink(missing_ok=True)
        except OSError as exc:
            raise KeyStoreError(f"plaintext keystore unlink of {self._path} failed: {exc!r}") from exc

    def __repr__(self) -> str:
        return f"PlaintextKeyStore(path={str(self._path)!r})"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_keystore(
    *,
    insecure_plaintext: bool = False,
    plaintext_path: str | Path = DEFAULT_PLAINTEXT_PATH,
    op_binary: str = "op",
    keyring_service: str = KEYRING_SERVICE,
) -> KeyStore:
    """Auto-detect the best available keystore for this machine.

    Priority order (locked by plan §11 Q3):

    1. **1Password CLI** — if ``op`` is installed and at least one
       account is configured. Touch ID lives in 1Password's own gate.
    2. **OS keychain** — via the ``keyring`` library. macOS Keychain
       (Touch ID gated), Linux Secret Service (GNOME Keyring / KWallet),
       Windows Credential Manager.
    3. **Plaintext file** — only if ``insecure_plaintext=True``. The
       caller is expected to have shown the user a security warning and
       gotten an affirmative opt-in.

    If 1 and 2 are unavailable AND ``insecure_plaintext=False``, this
    raises ``KeyStoreError`` rather than silently downgrading.
    """
    if OnePasswordKeyStore.is_available(op_binary=op_binary):
        return OnePasswordKeyStore(op_binary=op_binary)
    if KeychainKeyStore.is_available():
        return KeychainKeyStore(service=keyring_service)
    if insecure_plaintext:
        return PlaintextKeyStore(path=plaintext_path)
    raise KeyStoreError(
        "No secure keystore backend available "
        "(1Password CLI not signed in, OS keychain unreachable). "
        "Re-run with insecure_plaintext=True to opt into ~/.whenful/key.b64 "
        "(0o600 plaintext) as a last resort."
    )


__all__ = [
    "DEFAULT_PLAINTEXT_PATH",
    "KEYRING_SERVICE",
    "KeyStore",
    "KeyStoreError",
    "KeychainKeyStore",
    "ONEPASSWORD_FIELD",
    "ONEPASSWORD_ITEM_TITLE",
    "OnePasswordKeyStore",
    "PlaintextKeyStore",
    "get_keystore",
]
