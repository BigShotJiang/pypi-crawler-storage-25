"""OAuth 2.1 + PKCE pairing flow for the local stdio MCP client.

Replaces the Phase D "paste tokens from DevTools" flow with the
standard OAuth 2.1 authorization-code-with-PKCE pairing dance that the
Whenful cloud server already speaks (``app/routers/oauth.py``):

  1. POST /oauth/register with a generated client_name and a loopback
     redirect_uri pinned to ``http://127.0.0.1:<free-port>/callback``.
  2. Generate a PKCE code_verifier + S256 code_challenge.
  3. Stand up a single-shot HTTP listener on the loopback port to
     receive the callback redirect.
  4. ``webbrowser.open()`` the user to /oauth/authorize with the
     registered client_id + the PKCE challenge + a CSRF ``state``.
  5. Wait up to ``CALLBACK_TIMEOUT_SECONDS`` for the redirect.
  6. POST /oauth/token with grant_type=authorization_code, code +
     code_verifier + client_id + redirect_uri.
  7. Translate the server's ``expires_in`` response into the
     ``expires_at`` shape ``AuthManager`` persists on disk.

Why stdlib + httpx (no aiohttp)
--------------------------------

``mcp_stdio`` is published as a separately-installable wheel
(Phase F). Every additional runtime dependency is one more thing
Alex's eventual ``pip install whenful-mcp`` user has to download,
audit, and tolerate breakage from. ``http.server.HTTPServer`` in a
daemon thread is sufficient for the single GET that this flow needs;
we don't need full ASGI / aiohttp machinery just to read one
querystring.

Privacy posture
---------------

Zero telemetry. The PKCE secrets (code_verifier, state) live in the
flow function's locals for the duration of the call and are dropped
when it returns. The bearer tokens returned to the caller are
written to disk by ``AuthManager`` — we don't ``print()`` them. No
Sentry, no logging of token material.

Loopback redirects are SOP for native OAuth (RFC 8252). Pinning
``127.0.0.1`` (not ``localhost``) avoids DNS rebinding and matches
the IETF guidance.
"""

from __future__ import annotations

import base64
import hashlib
import http.server
import logging
import secrets
import socket
import socketserver
import threading
import time
import urllib.parse
import webbrowser
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Final

import httpx

logger = logging.getLogger("whenful.mcp.oauth")

#: Maximum time we wait for the loopback callback before giving up. Long
#: enough for the user to switch browsers, sign in, accept the consent
#: page; short enough that a forgotten setup window doesn't hang the
#: terminal indefinitely.
CALLBACK_TIMEOUT_SECONDS: Final[int] = 300  # 5 minutes

#: How many random ports we try before declaring the loopback unreachable.
#: 5 is comfortable headroom — the IANA ephemeral range has thousands of
#: free ports and collisions are vanishingly rare.
PORT_PROBE_ATTEMPTS: Final[int] = 5

#: Ephemeral port range we draw from. RFC 6335 §6 reserves 49152-65535
#: as the dynamic/private range — exactly the slice we want for a
#: short-lived listener that nobody else should be claiming.
EPHEMERAL_PORT_MIN: Final[int] = 49152
EPHEMERAL_PORT_MAX: Final[int] = 65535

#: Length of the PKCE code_verifier in bytes (before base64url
#: encoding). RFC 7636 §4.1 specifies 43-128 unreserved characters in
#: the encoded form; 32 random bytes → 43 chars in url-safe-no-padding,
#: which sits at the minimum-length sweet spot.
CODE_VERIFIER_BYTES: Final[int] = 32

#: Length of the CSRF ``state`` parameter. 32 random bytes / 256 bits
#: is the same entropy budget the server uses for authorization codes.
STATE_BYTES: Final[int] = 32

#: HTML returned to the browser after a successful callback. Plain text
#: would also work but a styled page is more reassuring after a
#: blocking redirect.
_SUCCESS_HTML: Final[str] = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Whenful MCP — Paired</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif;
               background: #0a0a0a; color: #e5e5e5;
               display: flex; align-items: center; justify-content: center;
               min-height: 100vh; margin: 0; }
        .card { background: #171717; border: 1px solid #262626;
                border-radius: 12px; padding: 2rem; max-width: 420px;
                text-align: center; }
        h1 { color: #167BFF; margin-top: 0; }
        p { color: #a3a3a3; line-height: 1.5; }
    </style>
</head>
<body>
    <div class="card">
        <h1>You're all set.</h1>
        <p>The Whenful MCP client has captured the authorization
           code.<br>You can close this tab and return to your terminal.</p>
    </div>
</body>
</html>"""

#: HTML returned when the callback arrived but Whenful sent an error
#: (e.g., user clicked Deny).
_ERROR_HTML: Final[str] = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Whenful MCP — Pairing failed</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif;
               background: #0a0a0a; color: #e5e5e5;
               display: flex; align-items: center; justify-content: center;
               min-height: 100vh; margin: 0; }
        .card { background: #171717; border: 1px solid #262626;
                border-radius: 12px; padding: 2rem; max-width: 420px;
                text-align: center; }
        h1 { color: #f87171; margin-top: 0; }
        p { color: #a3a3a3; line-height: 1.5; }
        code { color: #fbbf24; font-family: monospace; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Pairing failed.</h1>
        <p>Whenful returned: <code>{error}</code></p>
        <p>You can close this tab and re-run the setup command from
           your terminal.</p>
    </div>
</body>
</html>"""


class OAuthFlowError(RuntimeError):
    """Raised when the OAuth pairing flow cannot complete.

    Surface this distinctly from ``httpx.HTTPError`` so the setup
    flow can show a user-friendly message ("re-run setup") rather
    than a transport-level traceback.
    """


@dataclass(frozen=True)
class _CallbackResult:
    """The querystring delivered to the loopback ``/callback`` URL.

    Either ``code`` is populated (success) or ``error`` is populated
    (user denied or server-side validation failed). ``state`` is
    always echoed back by the server per RFC 6749 §4.1.2 — we verify
    it against the locally-generated value before consuming ``code``.
    """

    code: str | None
    state: str | None
    error: str | None


def _generate_pkce_pair() -> tuple[str, str]:
    """Return ``(code_verifier, code_challenge)`` ready for the S256 flow.

    The verifier is 32 raw bytes encoded as url-safe-base64 with no
    padding; the challenge is ``BASE64URL(SHA256(verifier))``. Format
    matches ``app/routers/oauth.py::_verify_pkce`` byte-for-byte so the
    server can re-derive and compare.
    """
    verifier_bytes = secrets.token_bytes(CODE_VERIFIER_BYTES)
    code_verifier = base64.urlsafe_b64encode(verifier_bytes).rstrip(b"=").decode("ascii")
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return code_verifier, code_challenge


def _generate_state() -> str:
    """Return a high-entropy CSRF state token.

    The state binds this in-flight authorization request to the
    listener that started it; a callback whose state doesn't match
    is an injection attempt or a stale tab and gets rejected before
    the code is consumed.
    """
    return secrets.token_urlsafe(STATE_BYTES)


def _find_free_loopback_port(*, attempts: int = PORT_PROBE_ATTEMPTS) -> int:
    """Probe ``attempts`` random ephemeral ports and return the first free one.

    We probe at random rather than asking the kernel for
    ``socket.bind(("127.0.0.1", 0))`` because (a) we already have a
    PRNG seeded for the PKCE work and (b) random ephemeral ports
    make collision with another local listener less likely than the
    sequential allocator.

    Raises ``OAuthFlowError`` if every probe failed — usually means
    the loopback interface itself is misconfigured or a host firewall
    is blocking ephemeral binds.
    """
    for _ in range(attempts):
        port = secrets.randbelow(EPHEMERAL_PORT_MAX - EPHEMERAL_PORT_MIN + 1) + EPHEMERAL_PORT_MIN
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            try:
                probe.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise OAuthFlowError(
        f"Could not find a free loopback port after {attempts} attempts. "
        "Is anything blocking 127.0.0.1 ephemeral binds?",
    )


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    """Handle exactly one GET ``/callback?...`` and stash the parsed query.

    ``BaseHTTPRequestHandler.log_message`` is silenced — we do not want
    the OAuth code path printing the bearer-bound query string to the
    terminal that the user is reading.
    """

    # Type stub on the class so static analysers don't warn about the
    # attribute we set on the server instance.
    server: _CallbackServer  # type: ignore[assignment]

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002 — stdlib API
        """Silence the default ``stderr`` logging.

        The default handler prints every request including the full
        query string. That includes the authorization code (a bearer-
        equivalent secret while it's live) — printing it to the user's
        terminal would defeat the loopback flow's purpose.
        """
        return

    def do_GET(self) -> None:  # noqa: N802 — http.server API
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"Not found\n")
            return

        query = urllib.parse.parse_qs(parsed.query)
        code = query.get("code", [None])[0]
        state = query.get("state", [None])[0]
        error = query.get("error", [None])[0]

        # Stash the result on the server (shared with the main thread)
        # and signal the waiting Event.
        self.server.result = _CallbackResult(code=code, state=state, error=error)
        self.server.callback_event.set()

        if error:
            body = _ERROR_HTML.format(error=error).encode("utf-8")
            self.send_response(400)
        else:
            body = _SUCCESS_HTML.encode("utf-8")
            self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class _CallbackServer(socketserver.TCPServer):
    """``TCPServer`` extended with a results pipe to the main thread.

    Attached attributes:
      - ``result``: the parsed querystring, set by the handler.
      - ``callback_event``: ``threading.Event`` the main thread waits on.

    ``allow_reuse_address`` is left at the default ``False`` — we don't
    want to share a port with anything stale, the probe step already
    guarantees the port was free at bind time.
    """

    def __init__(self, server_address: tuple[str, int], handler: type[http.server.BaseHTTPRequestHandler]) -> None:
        super().__init__(server_address, handler)
        self.result: _CallbackResult | None = None
        self.callback_event = threading.Event()


def _start_callback_listener(port: int) -> _CallbackServer:
    """Spawn the loopback HTTP listener in a daemon thread and return it.

    The caller is responsible for ``server.shutdown()`` once the
    callback has been captured (or the timeout has fired). The daemon
    thread will exit naturally on ``shutdown()`` because
    ``serve_forever`` returns; if it doesn't (network glitch), the
    daemon=True ensures the process can still exit.
    """
    server = _CallbackServer(("127.0.0.1", port), _CallbackHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True, name="whenful-mcp-oauth-callback")
    thread.start()
    return server


async def _post_register(
    *,
    api_base: str,
    client_name: str,
    redirect_uri: str,
    http_client: httpx.AsyncClient,
) -> str:
    """POST /oauth/register and return the freshly-issued ``client_id``.

    The server has dynamic-client-registration enabled (RFC 7591) and
    intentionally does not require pre-auth. See
    ``app/routers/oauth.py::register_client`` for the server view.
    """
    url = f"{api_base.rstrip('/')}/oauth/register"
    response = await http_client.post(
        url,
        json={"client_name": client_name, "redirect_uris": [redirect_uri]},
    )
    if response.status_code >= 400:
        raise OAuthFlowError(
            f"OAuth client registration failed ({response.status_code}): {response.text[:200]}",
        )
    body = response.json()
    if not isinstance(body, dict) or "client_id" not in body:
        raise OAuthFlowError(
            f"OAuth client registration returned malformed body: {body!r}",
        )
    return str(body["client_id"])


async def _post_token(
    *,
    api_base: str,
    code: str,
    code_verifier: str,
    client_id: str,
    redirect_uri: str,
    http_client: httpx.AsyncClient,
) -> dict[str, Any]:
    """Exchange ``code`` + PKCE verifier for tokens.

    Returns the parsed response body, translated to the on-disk shape
    AuthManager expects: ``{access_token, refresh_token, expires_at}``
    (the server returns ``expires_in``; we add ``time.time()`` to
    convert seconds-from-now into an absolute Unix timestamp).
    """
    url = f"{api_base.rstrip('/')}/oauth/token"
    response = await http_client.post(
        url,
        json={
            "grant_type": "authorization_code",
            "code": code,
            "code_verifier": code_verifier,
            "client_id": client_id,
            "redirect_uri": redirect_uri,
        },
    )
    if response.status_code >= 400:
        raise OAuthFlowError(
            f"OAuth token exchange failed ({response.status_code}): {response.text[:200]}",
        )
    payload = response.json()
    if not isinstance(payload, dict) or not {"access_token", "refresh_token", "expires_in"}.issubset(payload):
        raise OAuthFlowError(
            f"OAuth token response missing required fields: {payload!r}",
        )
    return {
        "access_token": str(payload["access_token"]),
        "refresh_token": str(payload["refresh_token"]),
        "expires_at": int(time.time()) + int(payload["expires_in"]),
    }


async def run_oauth_flow(
    *,
    api_base: str,
    client_name: str = "Whenful Local MCP",
    http_client: httpx.AsyncClient | None = None,
    browser_opener: Callable[[str], bool] | None = None,
    callback_timeout: int = CALLBACK_TIMEOUT_SECONDS,
    print_url_to_stderr: Callable[[str], None] | None = None,
) -> dict[str, Any] | None:
    """Run the full OAuth 2.1 PKCE pairing flow against the Whenful API.

    Returns the token dict on success (``{access_token, refresh_token,
    expires_at}`` — same shape ``AuthManager.save`` consumes), or
    ``None`` on user-side timeout / explicit denial. Network or
    protocol failures raise ``OAuthFlowError``.

    Dependency injection contract:
      - ``http_client``: an ``httpx.AsyncClient`` for tests using
        ``httpx.MockTransport`` or ``respx``. When ``None``, a private
        client is created for the duration of the call and closed on
        exit.
      - ``browser_opener``: replaces ``webbrowser.open``. Returns
        ``True`` on success; on ``False`` we print the URL and let
        the user paste it manually. Tests use this to assert on
        the constructed authorize URL without actually launching a
        browser.
      - ``print_url_to_stderr``: where to write the fallback URL
        when the browser can't open. Defaults to a real print to
        ``sys.stderr``.

    Failure modes:
      - Free port not found → ``OAuthFlowError`` immediately.
      - POST /oauth/register 4xx/5xx → ``OAuthFlowError``.
      - ``webbrowser.open`` returns ``False`` → print URL + continue.
      - Callback timed out → return ``None``.
      - Callback ``state`` doesn't match → ``OAuthFlowError`` (CSRF).
      - Callback ``error=access_denied`` (or any other error param) →
        return ``None``.
      - POST /oauth/token 4xx/5xx or malformed body → ``OAuthFlowError``.

    The function is async because the cloud HTTP calls go through
    ``httpx.AsyncClient`` (test compatibility with ``respx`` and the
    rest of ``mcp_stdio``). The loopback listener itself runs in a
    sync daemon thread; we ``await asyncio.to_thread`` the wait so
    the event loop isn't blocked.
    """
    import asyncio
    import sys

    if browser_opener is None:
        browser_opener = webbrowser.open
    if print_url_to_stderr is None:
        print_url_to_stderr = lambda msg: print(msg, file=sys.stderr)  # noqa: E731

    owns_client = http_client is None
    if http_client is None:
        http_client = httpx.AsyncClient(timeout=30.0)

    try:
        # --- Step 1: pick a loopback port + start the listener -------------
        port = _find_free_loopback_port()
        redirect_uri = f"http://127.0.0.1:{port}/callback"
        server = _start_callback_listener(port)

        try:
            # --- Step 2: register a dynamic OAuth client -------------------
            client_id = await _post_register(
                api_base=api_base,
                client_name=client_name,
                redirect_uri=redirect_uri,
                http_client=http_client,
            )

            # --- Step 3: generate PKCE + state ----------------------------
            code_verifier, code_challenge = _generate_pkce_pair()
            state = _generate_state()

            # --- Step 4: send the user to /oauth/authorize ----------------
            authorize_params = urllib.parse.urlencode(
                {
                    "response_type": "code",
                    "client_id": client_id,
                    "redirect_uri": redirect_uri,
                    "code_challenge": code_challenge,
                    "code_challenge_method": "S256",
                    "scope": "tasks",
                    "state": state,
                }
            )
            authorize_url = f"{api_base.rstrip('/')}/oauth/authorize?{authorize_params}"

            opened = False
            try:
                opened = bool(browser_opener(authorize_url))
            except Exception:  # noqa: BLE001 — webbrowser.open is allowed to raise on hostile envs
                opened = False
            if not opened:
                print_url_to_stderr(
                    "Could not open a browser automatically. Paste this URL into "
                    "your browser and complete the sign-in:\n\n  "
                    f"{authorize_url}\n",
                )

            # --- Step 5: wait for the callback ----------------------------
            captured = await asyncio.to_thread(server.callback_event.wait, callback_timeout)
            result = server.result

            if not captured or result is None:
                # 5-minute timeout — user wandered off.
                return None

            if result.error:
                # User clicked Deny, or the server validated and rejected.
                # access_denied is the OAuth 2.1 spec value; anything else
                # (invalid_request, etc) gets the same surface.
                logger.warning("OAuth flow ended with error=%s", result.error)
                return None

            if result.state != state:
                # CSRF: the callback was either stale or planted.
                raise OAuthFlowError(
                    "OAuth callback state mismatch — possible CSRF or stale tab.",
                )

            if not result.code:
                # Should be unreachable — server contract is code OR error.
                raise OAuthFlowError("OAuth callback delivered neither code nor error.")

            # --- Step 6: exchange code for tokens -------------------------
            return await _post_token(
                api_base=api_base,
                code=result.code,
                code_verifier=code_verifier,
                client_id=client_id,
                redirect_uri=redirect_uri,
                http_client=http_client,
            )
        finally:
            # Tear down the listener before we return. ``shutdown`` blocks
            # until the daemon thread exits ``serve_forever`` — cheap.
            server.shutdown()
            server.server_close()
    finally:
        if owns_client:
            await http_client.aclose()


__all__ = [
    "CALLBACK_TIMEOUT_SECONDS",
    "OAuthFlowError",
    "run_oauth_flow",
]
