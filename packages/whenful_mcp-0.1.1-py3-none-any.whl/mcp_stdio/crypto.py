"""Crypto primitives for the local stdio MCP client.

Byte-for-byte parity with ``frontend/src/lib/crypto.ts``. See the plan at
``docs/plans/2026-04-09-pre-launch-local-mcp-and-encryption.md`` §3 for the
"crypto parity with the browser" goal.

Encrypted-data layout (matches Web Crypto's ``crypto.subtle.encrypt`` and
Python's ``cryptography.hazmat.primitives.ciphers.aead.AESGCM`` — both
return ``ciphertext || tag`` from their encrypt method):

    base64( IV(12) || ciphertext || authTag(16) )

The IV is random per encrypt (96 bits / 12 bytes — the AES-GCM standard).
The auth tag is the standard 16-byte AES-GCM tag, appended by the AEAD
primitive itself; we don't separate it from the ciphertext.

PBKDF2-HMAC-SHA256 with 600,000 iterations. Salt is 32 bytes (matches the
JS ``generateSalt()``). Derived key is 32 bytes (AES-256).

Privacy & telemetry posture
---------------------------
- Zero telemetry. No Sentry, no OTel, no ``print()`` of secrets. Errors
  raise specific exceptions; callers decide how to surface them.
- The derived key is held as ``bytes`` (not ``str``) to avoid Python's
  string-interning leak vector. ``CryptoManager.__repr__`` never includes
  the key.
- The passphrase is consumed once during ``__init__`` to derive the key,
  then dropped. Phase D (keychain integration) will own the passphrase
  source; this module accepts it as input only.
"""

from __future__ import annotations

import base64
import os
from typing import Final

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

# These constants are the load-bearing parity values. Changing any of
# them silently breaks browser ↔ Python interop.
PBKDF2_ITERATIONS: Final[int] = 600_000  # OWASP 2024 recommendation
IV_LENGTH: Final[int] = 12  # 96 bits — AES-GCM standard
AES_KEY_LENGTH: Final[int] = 32  # 256-bit key
AUTH_TAG_LENGTH: Final[int] = 16  # AES-GCM standard


class CryptoError(Exception):
    """Base class for crypto errors raised by this module."""


class InvalidPassphraseError(CryptoError):
    """Raised when a passphrase fails to decrypt the server's test ciphertext."""


class DecryptionError(CryptoError):
    """Raised when an arbitrary ciphertext fails AES-GCM authentication.

    Tampering with one byte of the ciphertext or the auth tag triggers this.
    The underlying ``cryptography.exceptions.InvalidTag`` is wrapped to keep
    a stable API for callers (Phase C onward).
    """


class CryptoManager:
    """Holds a derived AES-256-GCM key in memory and offers encrypt/decrypt.

    Constructor takes a ``passphrase`` and ``salt`` so that the source of
    the passphrase (interactive prompt, OS keychain, env var) is decoupled
    from the crypto math. Phase D will integrate keychain reading; until
    then the caller is responsible for passing the right passphrase in.

    The ``passphrase`` parameter is only read inside ``_derive_key`` and
    is not stored on the instance. The derived key is held as ``bytes``
    on a private attribute and never exposed.
    """

    __slots__ = ("_key",)

    def __init__(self, passphrase: str, salt: bytes) -> None:
        if not isinstance(passphrase, str):
            raise TypeError("passphrase must be str")
        if not isinstance(salt, (bytes, bytearray)):
            raise TypeError("salt must be bytes")
        self._key: bytes = self._derive_key(passphrase, bytes(salt))

    # ------------------------------------------------------------------
    # Alternate constructor (Phase E)
    # ------------------------------------------------------------------

    @classmethod
    def from_key(cls, key: bytes) -> CryptoManager:
        """Construct a ``CryptoManager`` from an already-derived AES-256 key.

        Used by the stdio MCP server (Phase E of MCP #13534): the user's
        passphrase was verified once during ``mcp_stdio.setup`` and the
        resulting 32-byte derived key was persisted into the OS keystore
        (1Password / Keychain / opt-in plaintext). On every subsequent
        server boot we read those bytes back and rebuild a
        ``CryptoManager`` without re-prompting for the passphrase and
        without paying the ~300ms PBKDF2 cost.

        ``key`` MUST be exactly 32 bytes (the AES-256 key length). The
        caller is responsible for having sourced those bytes from a
        trustworthy place — this constructor performs no verification of
        the key against any server-stored ciphertext, because the entire
        point is to skip that round-trip on the hot path. Setup remains
        the one place that validates the key against the server's test
        ciphertext via ``verify_passphrase``.

        Raises ``TypeError`` if ``key`` is not ``bytes``/``bytearray``;
        raises ``ValueError`` if ``key`` is not exactly 32 bytes.
        """
        if not isinstance(key, (bytes, bytearray)):
            raise TypeError("key must be bytes")
        if len(key) != AES_KEY_LENGTH:
            raise ValueError(f"key must be exactly {AES_KEY_LENGTH} bytes, got {len(key)}")
        inst = cls.__new__(cls)
        # Bypass ``__init__`` because it would try to PBKDF2-derive — but
        # we already have a derived key. Set the slot directly.
        inst._key = bytes(key)
        return inst

    # ------------------------------------------------------------------
    # Key derivation
    # ------------------------------------------------------------------

    @staticmethod
    def _derive_key(passphrase: str, salt: bytes) -> bytes:
        """PBKDF2-HMAC-SHA256, 600,000 iterations, 32-byte output.

        Matches ``frontend/src/lib/crypto.ts::deriveKey`` byte-for-byte.
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=AES_KEY_LENGTH,
            salt=salt,
            iterations=PBKDF2_ITERATIONS,
        )
        return kdf.derive(passphrase.encode("utf-8"))

    # ------------------------------------------------------------------
    # Encrypt / Decrypt
    # ------------------------------------------------------------------

    def encrypt(self, plaintext: str) -> str:
        """Encrypt ``plaintext`` and return ``base64(IV || ciphertext || tag)``.

        Matches ``frontend/src/lib/crypto.ts::encrypt``. The IV is fresh
        random bytes per call — never reuse an IV under the same key.
        """
        if not isinstance(plaintext, str):
            raise TypeError("plaintext must be str")
        iv = os.urandom(IV_LENGTH)
        aesgcm = AESGCM(self._key)
        # AESGCM.encrypt returns ciphertext || tag concatenated, exactly
        # like Web Crypto's subtle.encrypt — so we can prepend the IV and
        # base64-encode without any tag-splitting.
        ct_and_tag = aesgcm.encrypt(iv, plaintext.encode("utf-8"), associated_data=None)
        return base64.b64encode(iv + ct_and_tag).decode("ascii")

    def decrypt(self, ciphertext_b64: str) -> str:
        """Decrypt a ``base64(IV || ciphertext || tag)`` blob produced by
        either the browser or another ``CryptoManager`` with the same key.

        Raises ``DecryptionError`` on auth-tag failure (tampering, wrong
        key, truncated input, etc).
        """
        if not isinstance(ciphertext_b64, str):
            raise TypeError("ciphertext_b64 must be str")
        try:
            blob = base64.b64decode(ciphertext_b64, validate=False)
        except (ValueError, TypeError) as e:
            raise DecryptionError("ciphertext is not valid base64") from e
        # Minimum size: 12 (IV) + 16 (tag) + 0 (empty plaintext) = 28 bytes.
        if len(blob) < IV_LENGTH + AUTH_TAG_LENGTH:
            raise DecryptionError("ciphertext too short to contain IV + tag")
        iv = blob[:IV_LENGTH]
        ct_and_tag = blob[IV_LENGTH:]
        aesgcm = AESGCM(self._key)
        try:
            plaintext_bytes = aesgcm.decrypt(iv, ct_and_tag, associated_data=None)
        except InvalidTag as e:
            raise DecryptionError("auth tag verification failed") from e
        try:
            return plaintext_bytes.decode("utf-8")
        except UnicodeDecodeError as e:
            raise DecryptionError("decrypted bytes are not valid utf-8") from e

    # ------------------------------------------------------------------
    # Passphrase verification
    # ------------------------------------------------------------------

    def verify_passphrase(self, encrypted_test_value: str) -> bool:
        """Verify the passphrase used to construct this manager by
        decrypting the server-stored encrypted test value and comparing
        the plaintext to ``ENCRYPTION_TEST_VALUE``.

        ``encrypted_test_value`` is the server-stored ciphertext that the
        browser produced via ``setupEncryption`` at registration time
        (see ``frontend/src/lib/crypto.ts::setupEncryption``).

        Returns ``True`` on match, ``False`` on any decryption failure or
        plaintext mismatch. Never raises — wrong passphrase is an
        expected outcome, not an error.
        """
        # Imported from the transport-agnostic constants module so the
        # standalone wheel can resolve it without dragging the full
        # ``app/constants.py`` (which transitively pulls in FastAPI +
        # SQLAlchemy) into the wheel. The cloud server re-exports the
        # same symbol from ``app.constants`` for backward compat.
        from app.mcp_shared.constants import ENCRYPTION_TEST_VALUE

        try:
            decrypted = self.decrypt(encrypted_test_value)
        except CryptoError:
            return False
        return decrypted == ENCRYPTION_TEST_VALUE

    # ------------------------------------------------------------------
    # Safety
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        # Never leak the derived key. Don't even hint at its presence with
        # a length — minimize side-channel info.
        return "CryptoManager(<key redacted>)"

    def __str__(self) -> str:
        return self.__repr__()
