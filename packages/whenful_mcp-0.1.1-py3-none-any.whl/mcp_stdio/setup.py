"""Interactive first-run setup for the local stdio MCP client.

Run as ``python -m mcp_stdio.setup`` (a console-script entrypoint
comes in Phase F).

What it does
------------

1. Runs the OAuth 2.1 PKCE pairing flow against the Whenful cloud
   server (``mcp_stdio.oauth_flow.run_oauth_flow``). The user's browser
   opens at ``/oauth/authorize``; after consent the loopback listener
   captures the authorization code, exchanges it for tokens, and
   ``AuthManager`` persists the resulting ``{access_token,
   refresh_token, expires_at}`` to ``~/.whenful/tokens.json``.
2. Fetches ``GET /api/v1/preferences/encryption`` with the freshly-
   issued bearer token to retrieve the user's encryption salt + the
   server-stored test ciphertext.
3. If encryption is disabled on the account, prints a clear message and
   exits cleanly — no key to store.
4. Otherwise, prompts the user for their passphrase via ``getpass``,
   derives the AES-256 key with ``CryptoManager``, and verifies the
   passphrase by decrypting the test ciphertext and comparing the
   plaintext to ``ENCRYPTION_TEST_VALUE``.
5. Wrong passphrase → reprompt (up to ``MAX_PASSPHRASE_ATTEMPTS``);
   exhausted retries → exit non-zero.
6. Right passphrase → persist the **derived key bytes** into the best
   available keystore (1Password CLI → OS keychain → opt-in plaintext).

Why OAuth 2.1 PKCE instead of token-paste
-----------------------------------------

The Phase D shape (paste DevTools tokens) was a stopgap while the
cloud OAuth surface stabilised. Now that ``app/routers/oauth.py``
ships the full RFC 7591 + RFC 7636 + RFC 8414 stack, the standalone
CLI can pair the same way Claude Desktop and Claude Code do — via a
loopback redirect into a dynamically-registered client. No more
copy-pasting bearer tokens out of DevTools, no more re-pasting after
the refresh window expires.

Privacy & telemetry posture
---------------------------

Zero telemetry. The passphrase is read with ``getpass.getpass`` so it
never echoes to the terminal. The OAuth flow's secrets (verifier,
state, authorization code) live in flow locals and drop on return.
The derived key is held in memory only as long as needed to call
``KeyStore.save`` and then dropped. No ``print()`` of secrets —
printed strings are limited to user-visible status and a final
summary that names the keystore backend (never the key itself).

This module must NOT import from ``app.*`` at module load time. We
defer the ``ENCRYPTION_TEST_VALUE`` import to inside the call chain via
``CryptoManager.verify_passphrase`` (which already does the lazy
import) so the ``mcp_stdio`` package stays standalone-wheel-friendly
for Phase F.
"""

from __future__ import annotations

import asyncio
import getpass
import sys
from collections.abc import Callable
from typing import Any, Final

import httpx

from .auth import AuthManager, _resolve_api_base
from .crypto import CryptoManager
from .keystore import KeyStore, KeyStoreError, get_keystore
from .oauth_flow import OAuthFlowError, run_oauth_flow

#: How many times to reprompt for the passphrase before aborting. Keeps
#: typo-recovery cheap without giving an attacker who has stolen the
#: bearer token unlimited guesses against the local PBKDF2.
MAX_PASSPHRASE_ATTEMPTS: Final[int] = 3

#: Exit codes from the CLI entrypoint. Standard convention — main()
#: returns these and ``sys.exit()`` propagates them.
#:
#: Note on numbering: 2 was previously ``EXIT_TOKEN_PASTE_INVALID``,
#: retired alongside the paste-tokens setup path. The slot is left
#: vacant rather than re-used so any external automation that captured
#: the historical exit code can recognize "this version no longer
#: prompts" without confusing the new semantics. New codes append
#: above the gap.
EXIT_OK: Final[int] = 0
EXIT_WRONG_PASSPHRASE: Final[int] = 1
# (2 reserved — formerly EXIT_TOKEN_PASTE_INVALID, removed with OAuth flow)
EXIT_NETWORK_ERROR: Final[int] = 3
EXIT_KEYSTORE_ERROR: Final[int] = 4
EXIT_OAUTH_FAILED: Final[int] = 5
EXIT_USER_CANCELLED: Final[int] = 130  # POSIX SIGINT exit code


def _stderr(msg: str) -> None:
    """Print to stderr with a single trailing newline. Cheap shim so
    tests can monkeypatch ``sys.stderr`` and capture user-visible output
    without colliding with whatever ``capsys`` does to stdout.
    """
    print(msg, file=sys.stderr)


def _stdout(msg: str) -> None:
    """Symmetric counterpart to ``_stderr`` for normal status messages."""
    print(msg)


async def _fetch_encryption_status(
    auth: AuthManager,
    *,
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """``GET /api/v1/preferences/encryption`` and return the parsed body.

    Raises ``httpx.HTTPError`` on transport failure (handled upstream by
    ``run_setup``). Returns a dict with ``enabled``, ``salt``, and
    ``test_value`` (the last two are ``None`` if encryption is off).
    """
    base = _resolve_api_base().rstrip("/")
    token = await auth.get_access_token()
    owns_client = http_client is None
    client = http_client or httpx.AsyncClient(timeout=30.0)
    try:
        response = await client.get(
            f"{base}/preferences/encryption",
            headers={"Authorization": f"Bearer {token}"},
        )
    finally:
        if owns_client:
            await client.aclose()
    response.raise_for_status()
    body = response.json()
    if not isinstance(body, dict):
        raise httpx.DecodingError(
            f"/preferences/encryption returned non-dict payload: {type(body).__name__}",
        )
    return body


def _prompt_passphrase(
    *,
    salt: bytes,
    encrypted_test_value: str,
    getpass_fn: Callable[[str], str] = getpass.getpass,
) -> CryptoManager | None:
    """Loop until the user types a correct passphrase OR exhausts retries.

    Returns a constructed ``CryptoManager`` on success, ``None`` on
    exhausted attempts. ``getpass_fn`` is dependency-injected for tests.
    """
    for attempt in range(1, MAX_PASSPHRASE_ATTEMPTS + 1):
        try:
            passphrase = getpass_fn(f"Passphrase (attempt {attempt}/{MAX_PASSPHRASE_ATTEMPTS}): ")
        except (EOFError, KeyboardInterrupt):
            _stderr("\nAborted.")
            return None
        if not passphrase:
            _stderr("Empty passphrase. Try again.")
            continue
        crypto = CryptoManager(passphrase, salt)
        # ``verify_passphrase`` returns False on any decryption failure
        # — wrong key, corrupted ciphertext, etc. We don't differentiate
        # because (a) the user can't act on the difference, and (b) the
        # error messages would themselves leak structural info about
        # the test-value layout to a future attacker reading stderr.
        if crypto.verify_passphrase(encrypted_test_value):
            return crypto
        _stderr("Wrong passphrase.")
    return None


async def run_setup(
    *,
    auth: AuthManager | None = None,
    keystore: KeyStore | None = None,
    insecure_plaintext: bool = False,
    http_client: httpx.AsyncClient | None = None,
    input_fn: Callable[[str], str] = input,  # noqa: ARG001 — retained for back-compat with CLI shims
    getpass_fn: Callable[[str], str] = getpass.getpass,
    oauth_runner: Callable[..., Any] | None = None,
) -> int:
    """Run the interactive first-run setup, returning an exit code.

    All collaborators (``auth``, ``keystore``, ``http_client``,
    ``oauth_runner``, the passphrase prompt) are dependency-injected so
    the function is unit-testable without touching the real keychain,
    real httpx network, or real browser. The CLI ``main()`` wires the
    defaults.

    The ``input_fn`` parameter is retained for backwards compatibility
    with the pre-OAuth signature; it's unused now (the OAuth flow
    owns the user-visible prompts) but removing it would break callers
    that pass it positionally.

    Returns:
      - ``EXIT_OK`` (0) on success.
      - ``EXIT_OAUTH_FAILED`` (5) if the OAuth flow didn't yield tokens
        (user denial, 5-minute timeout, or protocol-level failure).
      - ``EXIT_NETWORK_ERROR`` (3) on transport failure to /preferences/encryption.
      - ``EXIT_WRONG_PASSPHRASE`` (1) if all passphrase attempts failed.
      - ``EXIT_KEYSTORE_ERROR`` (4) if persisting the key failed.
      - ``EXIT_USER_CANCELLED`` (130) on Ctrl-C / EOF at the prompt.
    """
    owns_auth = auth is None
    if auth is None:
        auth = AuthManager()

    if oauth_runner is None:
        oauth_runner = run_oauth_flow

    try:
        # -- Step 1: OAuth 2.1 PKCE pairing ----------------------------
        _stdout("Step 1/2 — Pairing this device with Whenful via OAuth.")
        _stdout("  Your browser will open at the consent page; complete sign-in and approve.")
        try:
            # The oauth flow takes its own http_client (or makes one).
            # If the caller supplied one, thread it through so the tests
            # can route /oauth/* at their MockTransport while the
            # encryption-status step uses the same client.
            tokens = await oauth_runner(
                api_base=_resolve_api_base(),
                http_client=http_client,
            )
        except OAuthFlowError as exc:
            _stderr(f"OAuth pairing failed: {exc}")
            return EXIT_OAUTH_FAILED
        except (EOFError, KeyboardInterrupt):
            _stderr("\nAborted during OAuth pairing.")
            return EXIT_USER_CANCELLED

        if tokens is None:
            _stderr(
                "OAuth pairing did not complete (timeout, user denial, or no callback). "
                "Re-run setup and approve the consent page within 5 minutes.",
            )
            return EXIT_OAUTH_FAILED

        auth.save(tokens)
        _stdout(f"Tokens saved to {auth.token_path}.")

        # -- Step 2: fetch encryption status ----------------------------
        _stdout("Step 2/2 — Verifying encryption passphrase.")
        try:
            status = await _fetch_encryption_status(auth, http_client=http_client)
        except httpx.HTTPStatusError as exc:
            _stderr(f"Server returned {exc.response.status_code} on /preferences/encryption.")
            return EXIT_NETWORK_ERROR
        except httpx.HTTPError as exc:
            _stderr(f"Could not reach Whenful API: {exc!r}")
            return EXIT_NETWORK_ERROR

        if not status.get("enabled"):
            _stdout(
                "Encryption is disabled on this account. No key to store; setup is complete.",
            )
            return EXIT_OK

        salt_b64 = status.get("salt")
        encrypted_test_value = status.get("test_value")
        if not isinstance(salt_b64, str) or not isinstance(encrypted_test_value, str):
            _stderr(
                "/preferences/encryption returned encryption_enabled but missing salt or "
                "test_value. Cannot verify; aborting.",
            )
            return EXIT_NETWORK_ERROR
        try:
            import base64

            salt = base64.b64decode(salt_b64, validate=True)
        except (ValueError, TypeError) as exc:
            _stderr(f"Server-side encryption salt is not valid base64: {exc!r}")
            return EXIT_NETWORK_ERROR

        # -- Step 3: passphrase prompt loop -----------------------------
        crypto = _prompt_passphrase(
            salt=salt,
            encrypted_test_value=encrypted_test_value,
            getpass_fn=getpass_fn,
        )
        if crypto is None:
            _stderr(f"Failed to verify passphrase after {MAX_PASSPHRASE_ATTEMPTS} attempts.")
            return EXIT_WRONG_PASSPHRASE

        # -- Step 4: persist derived key into keystore ------------------
        if keystore is None:
            try:
                keystore = get_keystore(insecure_plaintext=insecure_plaintext)
            except KeyStoreError as exc:
                _stderr(str(exc))
                return EXIT_KEYSTORE_ERROR
        # Pull the user's email out of the tokens or, failing that, fall
        # back to a stable opaque identifier so the keystore "account"
        # field has *something* to namespace by. We don't reach into
        # ``/me`` for the email because the user has just paired and we
        # want one fewer round-trip; the access_token's signature is the
        # canonical identity.
        account = _account_label_from_tokens(tokens)
        try:
            keystore.save(account, crypto._key)  # noqa: SLF001 — by design, this module is the key's sink
        except KeyStoreError as exc:
            _stderr(f"Could not save key to keystore: {exc}")
            return EXIT_KEYSTORE_ERROR

        _stdout(f"Key saved into {type(keystore).__name__} under account {account!r}.")
        _stdout("Setup complete.")
        return EXIT_OK
    finally:
        if owns_auth:
            await auth.aclose()


def _account_label_from_tokens(tokens: dict[str, Any]) -> str:
    """Derive an opaque-but-stable account identifier from the token blob.

    Used as the "username" field in the keystore. Not a security
    boundary — anybody who can read the keystore already wins; this is
    purely for the user to recognize which Whenful account a stored
    key belongs to when they have multiple.

    Strategy: hash a deterministic prefix of the access token. Two
    different tokens for the same user (after a refresh) hash to the
    same identifier because the signed-token prefix is derived from
    the user_id-bearing payload. In practice we don't need stability
    across refreshes — the keystore looks up by the *current* label —
    but stability is harmless.
    """
    import hashlib

    raw = str(tokens.get("access_token", ""))
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return f"whenful-{digest[:12]}"


# ---------------------------------------------------------------------------
# CLI entrypoint
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> int:
    """Synchronous CLI shim for ``python -m mcp_stdio.setup``.

    Accepts an optional ``--insecure-key-storage`` flag (exact name
    spelled in the brief). All other behavior is interactive — there
    are intentionally no flags for token values or passphrases so we
    don't end up with secrets in shell history.
    """
    args = argv if argv is not None else sys.argv[1:]
    insecure = "--insecure-key-storage" in args
    if "--help" in args or "-h" in args:
        _stdout(
            "usage: python -m mcp_stdio.setup [--insecure-key-storage]\n\n"
            "Interactive first-run setup for the Whenful stdio MCP client.\n"
            "Pass --insecure-key-storage to allow ~/.whenful/key.b64 plaintext\n"
            "as a fallback when neither 1Password CLI nor the OS keychain are\n"
            "available. Without it, the setup aborts with a clear error in\n"
            "that case.",
        )
        return EXIT_OK
    try:
        return asyncio.run(run_setup(insecure_plaintext=insecure))
    except KeyboardInterrupt:
        _stderr("\nAborted.")
        return EXIT_USER_CANCELLED


if __name__ == "__main__":
    sys.exit(main())


__all__ = [
    "EXIT_KEYSTORE_ERROR",
    "EXIT_NETWORK_ERROR",
    "EXIT_OAUTH_FAILED",
    "EXIT_OK",
    "EXIT_USER_CANCELLED",
    "EXIT_WRONG_PASSPHRASE",
    "MAX_PASSPHRASE_ATTEMPTS",
    "main",
    "run_setup",
]
