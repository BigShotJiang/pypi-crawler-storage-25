"""Console-script dispatcher for the ``whenful-mcp`` wheel.

This module wires the wheel's single console script (``whenful-mcp``)
to the two existing entry points that already live in this package:

* ``mcp_stdio.server.main`` — runs the stdio MCP server in front of an
  already-set-up tokens file + keystore.
* ``mcp_stdio.setup.main`` — interactive first-run setup: OAuth device
  flow + passphrase verification + key persistence in the OS keystore.

The two entry points are kept as separate ``main()`` callables (rather
than collapsed into one) because both are also reachable via
``python -m mcp_stdio.server`` and ``python -m mcp_stdio.setup`` for
local development inside the monorepo. This file is the *only* new
surface added in Phase F — everything underneath it has been runnable
since Phase E.

Sub-commands
------------

* ``whenful-mcp`` (no args)         → ``serve`` (default)
* ``whenful-mcp serve``             → run the stdio MCP server
* ``whenful-mcp setup``             → run the interactive setup flow
* ``whenful-mcp --version``         → print the installed wheel version
* ``whenful-mcp -V``                → alias for ``--version``
* ``whenful-mcp --help``            → top-level usage
* ``whenful-mcp -h``                → alias for ``--help``

Sub-command flags
-----------------

Both ``serve`` and ``setup`` forward their full argv tail to the
underlying ``main()`` so per-sub-command flags like
``--insecure-key-storage`` keep working:

* ``whenful-mcp serve --insecure-key-storage``
* ``whenful-mcp setup --insecure-key-storage``
* ``whenful-mcp setup --help``      (delegated to ``mcp_stdio.setup``)
* ``whenful-mcp serve --help``      (delegated to ``mcp_stdio.server``)

Exit codes
----------

The exit code is whatever the delegated ``main()`` returns. Unknown
sub-commands return ``2`` (POSIX convention for usage errors).
"""

from __future__ import annotations

import sys

from mcp_stdio import __version__

_USAGE = """\
usage: whenful-mcp [<command>] [<args>...]

Local MCP server for Whenful. Connects Claude Desktop and other MCP
clients to your Whenful tasks with end-to-end encryption preserved.

commands:
  serve                    Run the stdio MCP server (default if no command)
  setup                    Interactive first-run setup (OAuth + passphrase)

options:
  -h, --help               Show this message and exit
  -V, --version            Show the installed whenful-mcp version

For sub-command help, run:
  whenful-mcp serve --help
  whenful-mcp setup --help
"""


def main(argv: list[str] | None = None) -> int:
    """Console-script entry point. Returns a process exit code.

    Sub-command dispatch is intentionally shallow — argparse would be
    overkill and would steal ``--help`` from the sub-commands' own
    parsers. We hand the tail off verbatim instead.
    """
    args = list(sys.argv[1:] if argv is None else argv)

    # Top-level --version / --help BEFORE picking a sub-command, but only
    # if they're the first positional. `whenful-mcp serve --help` must
    # delegate to the sub-command, not print our top-level usage.
    if not args:
        return _dispatch_serve([])
    head = args[0]
    if head in ("-h", "--help"):
        sys.stdout.write(_USAGE)
        return 0
    if head in ("-V", "--version"):
        sys.stdout.write(f"whenful-mcp {__version__}\n")
        return 0
    if head == "serve":
        return _dispatch_serve(args[1:])
    if head == "setup":
        return _dispatch_setup(args[1:])
    # If the first arg looks like a flag (e.g. `--insecure-key-storage`),
    # treat it as a flag to the default `serve` sub-command rather than
    # erroring. This matches `python -m mcp_stdio.server <flag>` ergonomics.
    if head.startswith("-"):
        return _dispatch_serve(args)
    # Unknown sub-command.
    sys.stderr.write(f"whenful-mcp: unknown command: {head}\n")
    sys.stderr.write(_USAGE)
    return 2


def _dispatch_serve(sub_argv: list[str]) -> int:
    """Run the stdio server. Import is deferred so ``--version`` and
    ``--help`` stay sub-second and don't crash on missing dependencies
    in degraded environments."""
    from mcp_stdio.server import main as server_main

    return server_main(sub_argv)


def _dispatch_setup(sub_argv: list[str]) -> int:
    """Run the interactive setup flow. Same deferred-import rationale
    as ``_dispatch_serve``."""
    from mcp_stdio.setup import main as setup_main

    return setup_main(sub_argv)


if __name__ == "__main__":
    sys.exit(main())
