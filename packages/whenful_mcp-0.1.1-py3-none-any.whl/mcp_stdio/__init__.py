"""Whenful local stdio MCP client.

This subpackage provides the building blocks for the local subprocess MCP
server that holds the user's encryption key on their own machine. It
ships as ``whenful-mcp`` on PyPI (Phase F of issue #13534) but the
source-of-truth lives here in the monorepo so the HTTP MCP server and
the stdio MCP server share the same tool implementations via
``app.mcp_shared``.

Phase F (this commit): added ``mcp_stdio.cli`` as the console-script
dispatcher and ``packaging/whenful-mcp/pyproject.toml`` as the wheel
build descriptor. The wheel force-includes ``mcp_stdio/`` and
``app/mcp_shared/`` and exposes a single ``whenful-mcp`` entry point.

Version resolution: ``__version__`` is read at import time from the
package's installed metadata via ``importlib.metadata.version``. Inside
the monorepo (where the wheel isn't installed), it falls back to the
literal ``"0.1.0"`` so ``mcp_stdio.__version__`` is always available.
The canonical version source-of-truth at runtime is the installed
wheel's ``[project] version`` key in ``packaging/whenful-mcp/pyproject.toml``.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__: str = _pkg_version("whenful-mcp")
except PackageNotFoundError:
    # Monorepo / editable-install fallback. The wheel ships installed
    # metadata so this branch never runs for end users — it only triggers
    # when running the source tree directly without a `pip install`.
    __version__ = "0.1.0"

__all__ = ["__version__"]
