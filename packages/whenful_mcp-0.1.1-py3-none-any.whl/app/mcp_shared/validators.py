"""Argument validation + parsing helpers shared by MCP tools.

These were previously inlined as private helpers in
`app/routers/mcp_server.py`. They live here so the future stdio client can
share the same validation surface (Phase C of MCP #13534).

The module-level constants and helpers MUST stay byte-identical to the
behavior in mcp_server.py — `tests/test_mcp.py` pins the public-facing
strings ("Invalid {field}", "Title cannot exceed", "Impact must be 1-4",
etc.) and the error-string return convention (string on failure, parsed
value on success). Don't reword.
"""

from __future__ import annotations

import re
from datetime import date
from datetime import time as time_type
from typing import Any

# Control chars except \n and \t — matches REST _strip_control_chars() in tasks.py
_CONTROL_CHAR_PATTERN = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_VALID_CLARITY = {"autopilot", "normal", "brainstorm"}
VALID_CLARITY = _VALID_CLARITY
_VALID_REMINDER_MINUTES = {0, 5, 15, 30, 60, 1440}
_VALID_STATUS = {"pending", "completed", "archived"}
VALID_LIST_STATUS = _VALID_STATUS | {"all"}
_TASK_TITLE_MAX_LENGTH = 500
_TASK_DESCRIPTION_MAX_LENGTH = 10000


def strip_control_chars(value: str) -> str:
    """Strip control characters except newline and tab (matches REST tasks.py)."""
    return _CONTROL_CHAR_PATTERN.sub("", value)


def parse_date(value: str, field: str = "date") -> date | str:
    """Parse a date string, returning date or error message string."""
    try:
        return date.fromisoformat(value)
    except ValueError:
        return f"Invalid {field}: '{value}'. Expected YYYY-MM-DD format."


def parse_time(value: str, field: str = "time") -> Any:
    """Parse a time string, returning time or error message string."""
    try:
        return time_type.fromisoformat(value)
    except ValueError:
        return f"Invalid {field}: '{value}'. Expected HH:MM format."


def validate_task_fields(
    *,
    title: str | None = None,
    impact: int | None = None,
    clarity: str | None = None,
    duration_minutes: int | None = None,
    reminder_minutes_before: int | None = None,
    description: str | None = None,
    status: str | None = None,
) -> str | None:
    """Validate task fields. Returns error string or None if valid."""
    if title is not None:
        if not isinstance(title, str):
            return f"Title must be a string. Got: {type(title).__name__}"
        if not title.strip():
            return "Title cannot be empty."
        if len(title) > _TASK_TITLE_MAX_LENGTH:
            return f"Title cannot exceed {_TASK_TITLE_MAX_LENGTH} characters."
    if impact is not None and not (1 <= impact <= 4):
        return f"Impact must be 1-4 (1=high, 2=mid, 3=low, 4=minimal). Got: {impact}"
    if clarity is not None and clarity not in _VALID_CLARITY:
        return f"Clarity must be one of: {', '.join(sorted(_VALID_CLARITY))}. Got: {clarity}"
    if duration_minutes is not None and not (1 <= duration_minutes <= 1440):
        return f"Duration must be 1-1440 minutes. Got: {duration_minutes}"
    if reminder_minutes_before is not None and reminder_minutes_before not in _VALID_REMINDER_MINUTES:
        return f"Reminder must be one of: {sorted(_VALID_REMINDER_MINUTES)}. Got: {reminder_minutes_before}"
    if description is not None and len(description) > _TASK_DESCRIPTION_MAX_LENGTH:
        return f"Description cannot exceed {_TASK_DESCRIPTION_MAX_LENGTH} characters."
    if status is not None and status not in _VALID_STATUS:
        return f"Status must be one of: {', '.join(sorted(_VALID_STATUS))}. Got: {status}"
    return None


def resolve_domain_name(domains: list, name: str) -> int | None:
    """Resolve a domain name to its ID (case-insensitive). Returns None if not found."""
    match = next((d for d in domains if d.name.lower() == name.lower()), None)
    return match.id if match else None


__all__ = [
    "VALID_CLARITY",
    "VALID_LIST_STATUS",
    "strip_control_chars",
    "parse_date",
    "parse_time",
    "validate_task_fields",
    "resolve_domain_name",
]
