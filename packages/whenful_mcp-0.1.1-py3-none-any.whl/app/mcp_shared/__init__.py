"""Transport-agnostic MCP tool implementations.

This package extracts the 33 MCP tools from `app/routers/mcp_server.py` so they
can be reused by both the cloud HTTP MCP server and the future local stdio MCP
client (planned in `docs/plans/2026-04-09-pre-launch-local-mcp-and-encryption.md`).

The HTTP server provides a `Backend` whose `session()` opens an SQLAlchemy
session against the production database and whose `fire_and_forget()` schedules
GCal sync coroutines on the running asyncio loop. The local stdio client will
provide a different `Backend` that talks to the REST API over HTTPS and
decrypts task content client-side. The tool implementations themselves don't
care which Backend they get — they just consume the protocol.

Phase C (#13534, 2026-05-10): the protocol grew explicit "operations" alongside
the original `session()` + `fire_and_forget()` pair. Operations return native
Python dicts (mirroring the REST response schemas) so the stdio implementation
can satisfy them by parsing JSON without re-implementing SQLAlchemy. The
existing HTTP path keeps using `session()` and direct SQL for all 33 tools;
the operations are dormant on the HTTP side until a future phase migrates the
tools onto them. Both halves of the protocol coexist by design — see the
"additively, never breaking the HTTP path" guarantee documented below.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Coroutine
from contextlib import AbstractAsyncContextManager
from datetime import date, datetime
from typing import Any, Protocol


class Backend(Protocol):
    """Transport-agnostic data layer for MCP tools.

    Implementations:
    - `app/routers/mcp_server.py::_DBBackend` — direct SQLAlchemy access via
      the cloud server's connection pool. Uses `async_session_factory()` and
      schedules fire-and-forget GCal sync coroutines on the FastAPI event loop.
    - `mcp_stdio/client.py::WhenfulClient` (Phase C) — wraps `httpx.AsyncClient`
      against `https://whenful.com/api/v1/*`. Performs client-side encryption
      and decryption when a CryptoManager is injected, and ignores
      `fire_and_forget` (server triggers GCal sync on its own when REST writes
      land).

    The protocol has two halves:

    1. **Low-level transport hooks** — `session()` + `fire_and_forget()`. The
       cloud HTTP server's 33 tool implementations all consume these today.
       The stdio backend satisfies `session()` with a no-op context manager
       yielding `self`; tools that still rely on raw SQL will need to migrate
       to the operations API in a later phase.

    2. **High-level operations** — `whoami()`, `list_tasks()`, `get_task()`,
       etc. Added in Phase C so the stdio implementation can talk to the REST
       API in well-shaped pieces without re-implementing SQLAlchemy. Each
       operation returns a Python ``dict`` whose keys mirror the REST schema
       documented inline below. The HTTP `_DBBackend` implements them as
       thin wrappers over its existing SQL paths so callers can reach the same
       data either way — the operations are dormant on the HTTP side until a
       future phase migrates the 33 tools onto them, but they're shipped now
       so Phase E's stdio smoke test has something to call.

    Phase C is intentionally narrow on the operations side: it adds only
    ``whoami``, ``list_tasks``, ``get_task`` — the three operations needed by
    Phase E's end-to-end smoke test. Subsequent phases will widen the
    operations surface (create_task, update_task, complete_task, …) one
    category at a time, always additively.
    """

    # ------------------------------------------------------------------
    # Low-level transport hooks
    # ------------------------------------------------------------------

    def session(self) -> AbstractAsyncContextManager[Any]:
        """Open a database session as an async context manager.

        For the HTTP backend this returns `async_session_factory()` — an
        `AsyncSession` against Postgres. For the stdio backend this returns
        a wrapper that proxies SQLAlchemy-style queries to REST calls
        (Phase C). Tool code MUST use this as `async with backend.session() as db:`
        and treat the yielded value as the existing tool code treats an
        `AsyncSession`.

        Phase C note: the stdio backend implements this as a no-op context
        manager that yields ``self``. Tool code that still depends on raw
        SQL will fail loudly when invoked through the stdio path — which is
        correct: those tools need migration to the new operations API.
        Phase E's smoke test uses only the new operations, so the no-op is
        sufficient for end-to-end stdio coverage today.
        """
        ...

    def fire_and_forget(self, coro: Coroutine[Any, Any, None]) -> None:
        """Schedule a fire-and-forget coroutine (e.g., GCal sync).

        The HTTP backend wraps this in `asyncio.create_task()` and keeps a
        strong reference to prevent GC mid-flight (see
        `app/routers/mcp_server.py::_fire_and_forget`). The stdio backend
        is a no-op — the cloud server already triggers GCal sync from
        REST routes when MCP writes land via HTTPS.
        """
        ...

    def supports_client_side_crypto(self) -> bool:
        """Whether this backend can decrypt encrypted fields client-side.

        HTTP backend (``_DBBackend``): always False. The cloud server never
        holds the user's encryption key by architectural design — encryption-on
        users are gated out of MCP tools that read/write encrypted columns
        (``title``, ``description``, ``domain.name``).

        Stdio backend (``WhenfulClient``): True when a ``CryptoManager`` is
        loaded (the user provided their passphrase during ``whenful-mcp setup``).
        The stdio client encrypts on write and decrypts on read before handing
        plaintext to the LLM, so encryption-on Pro users actually CAN use every
        MCP tool through their local install — the whole point of shipping the
        ``whenful-mcp`` wheel.

        The shared encryption gate (``app/mcp_shared/tools/__init__.py``
        ``check_encryption``) consults this flag to decide whether to return
        the lockout string. Without it, the gate inherited the cloud
        limitation as if it were a universal invariant, blocking the exact
        user segment the wheel was built for.
        """
        ...

    # ------------------------------------------------------------------
    # High-level operations (Phase C onward)
    # ------------------------------------------------------------------

    async def whoami(self, user_id: int) -> dict[str, Any]:
        """Return identity metadata for the authenticated user.

        Returns a dict with the same keys as ``MeResponse`` in
        ``app/routers/me.py``:

        - ``email`` (str)
        - ``name`` (str | None)
        - ``data_version`` (int)
        - ``encryption_enabled`` (bool)
        - ``tier`` (str)

        Other ``MeResponse`` fields (push health, distill quota, trial
        countdown) are not part of this contract — they may or may not be
        present in the dict and tool code should not depend on them. If
        future operations need them, this docstring will be amended.

        Implementations:
        - HTTP: SELECT against the User model + PreferencesService.
        - stdio: ``GET /api/v1/me`` with a Bearer token.

        The HTTP path treats ``user_id`` as the authenticated identity (which
        it already trusts from the MCPAuthMiddleware contextvar). The stdio
        path ignores the ``user_id`` argument because the Bearer token
        carries identity over the wire — passing it keeps the call shape
        symmetric so tool code stays transport-agnostic.
        """
        ...

    async def list_tasks(
        self,
        user_id: int,
        *,
        domain_id: int | None = None,
        status: str = "pending",
        scheduled_date: str | None = None,
        is_recurring: bool | None = None,
        clarity: str | None = None,
        parent_id: int | None = None,
        source: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
        # Added 2026-05-16 (mcp-shared import-clean refactor):
        # The tool-layer used to derive these inside the tool, calling
        # ``TaskService`` directly via ``backend.session()``. That broke the
        # import-clean rule for the wheel because ``TaskService`` lives in
        # ``app.services``. Routing the three filters through the protocol
        # lets the tool stay transport-agnostic; HTTP delegates to
        # ``TaskService.get_tasks`` (preserves the rich schedule-order
        # sort), stdio applies the filters client-side after the REST call.
        top_level_only: bool = True,
        has_domain: bool | None = None,
        exclude_statuses: list[str] | None = None,
        impact: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return tasks for the authenticated user as a list of dicts.

        Each dict has the keys of ``TaskResponse`` in ``app/routers/tasks.py``:
        ``id``, ``title``, ``description``, ``domain_id``, ``domain_name``,
        ``parent_id``, ``duration_minutes``, ``impact``, ``clarity``,
        ``scheduled_date``, ``scheduled_time``, ``is_recurring``,
        ``recurrence_rule``, ``recurrence_start``, ``recurrence_end``,
        ``reminder_minutes_before``, ``status``, ``position``, ``created_at``,
        ``completed_at``, ``subtasks``, ``today_instance_completed``,
        ``processing_origin``, ``source``.

        Filters mirror the ``GET /api/v1/tasks`` query parameters plus three
        MCP-specific filters that the REST endpoint derives server-side
        (``top_level_only``, ``has_domain``, ``exclude_statuses``) and the
        ``impact`` filter (REST doesn't have one — applied client-side).
        Dates are passed as ISO ``YYYY-MM-DD`` strings (the wire format the
        REST endpoint accepts).

        - ``top_level_only`` defaults to ``True`` and matches the REST
          derivation ``parent_id is None``. Setting ``parent_id`` flips it
          to ``False`` automatically (subtask listing).
        - ``has_domain``: ``True`` filters out domain-less inbox items, the
          MCP convention for ``list_tasks``. ``False`` is the inverse (used
          by ``list_thoughts``). ``None`` admits both.
        - ``exclude_statuses`` is the inverse of ``status``. The
          ``status="all"`` MCP convention maps to ``status=None`` +
          ``exclude_statuses=["archived"]`` so archived tasks stay hidden.
        - ``impact``: client-side post-filter; trims by priority bucket.

        Implementations:
        - HTTP: in-process SELECT via ``TaskService.get_tasks`` (preserves
          the rich schedule-order sort the MCP tool relies on).
        - stdio: ``GET /api/v1/tasks?...`` with the REST query params it
          accepts, then client-side filter for ``has_domain``,
          ``exclude_statuses``, ``impact`` (REST doesn't expose them).
        """
        ...

    async def get_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Return a single task by ID, or ``None`` if not found / not owned.

        Returns a dict with the same keys as ``TaskResponse`` (see
        ``list_tasks`` docstring). The dict is ``None`` when the task does
        not exist or belongs to a different user — never raised as an
        exception, because "missing task" is an expected outcome that
        tool code routinely handles.

        Implementations:
        - HTTP: SELECT against the Task model with ``user_id`` ownership filter.
        - stdio: ``GET /api/v1/tasks/{task_id}`` with a Bearer token; ``None``
          on a 404 response.
        """
        ...

    # ------------------------------------------------------------------
    # Recurring instance operations (MCP-stdio full-parity, #13534)
    # ------------------------------------------------------------------
    #
    # The 9 operations below mirror the 9 recurring-instance REST endpoints
    # under ``app/routers/instances.py``. Each operation returns a JSON-safe
    # dict (or ``int``/``list[dict]``) so the stdio backend can satisfy it
    # by parsing REST responses without re-implementing SQLAlchemy. The
    # HTTP backend implements them as thin wrappers over ``RecurrenceService``
    # so both transports share the same shape contract.

    async def complete_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:
        """Mark a recurring task instance as completed.

        Returns ``None`` when the instance is missing / not owned by the
        user (parity with the REST ``404`` surface from
        ``POST /api/v1/instances/{instance_id}/complete``). On success
        returns a dict with at least:

        - ``instance_id`` (int)
        - ``task_id`` (int)
        - ``status`` (str) — ``"completed"``

        Implementations:
        - HTTP: ``RecurrenceService.complete_instance`` + commit + fire-and-
          forget GCal sync, serialized via ``_instance_to_jsonable``.
        - stdio: ``POST /api/v1/instances/{instance_id}/complete``;
          ``None`` on a 404 response.
        """
        ...

    async def skip_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:
        """Mark a recurring task instance as skipped.

        Returns ``None`` on missing/unowned. On success returns at least
        ``{instance_id, task_id, status: "skipped"}``.

        Implementations:
        - HTTP: ``RecurrenceService.skip_instance`` + commit + fire-and-
          forget GCal sync (GCal unsync for skipped instances).
        - stdio: ``POST /api/v1/instances/{instance_id}/skip``.
        """
        ...

    async def unskip_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:
        """Revert a skipped recurring task instance back to ``pending``.

        Returns ``None`` on missing/unowned. On success returns at least
        ``{instance_id, task_id, status: "pending"}``.

        Implementations:
        - HTTP: ``RecurrenceService.unskip_instance`` + commit + fire-and-
          forget GCal sync.
        - stdio: ``POST /api/v1/instances/{instance_id}/unskip``.
        """
        ...

    async def uncomplete_instance(self, user_id: int, instance_id: int) -> dict[str, Any] | None:
        """Revert a completed recurring task instance back to ``pending``.

        Returns ``None`` on missing/unowned. On success returns at least
        ``{instance_id, task_id, status: "pending"}``.

        Implementations:
        - HTTP: ``RecurrenceService.uncomplete_instance`` + commit + fire-
          and-forget GCal sync.
        - stdio: ``POST /api/v1/instances/{instance_id}/uncomplete``.
        """
        ...

    async def get_instance_wall_clock(self, user_id: int, instance_id: int) -> tuple[str, str] | None:
        """Return ``(local_time_iso, iana_tz_name)`` for an instance, or ``None``.

        Used by the ``reschedule_instance`` tool's date-only branch: when the
        caller passes ``YYYY-MM-DD`` (no time), we need to preserve the
        instance's existing wall-clock time in the user's local timezone, then
        re-pin to UTC. The tool used to do this with raw SQL + a
        ``PreferencesService`` lookup behind a session duck-type check; that
        worked on cloud (where ``session()`` yields a real
        ``AsyncSession``) but bound ``app.mcp_shared`` to ``app.models`` +
        ``app.services``, violating the import-clean rule for the standalone
        wheel.

        Routing through the protocol moves the cloud-specific imports into
        ``_DBBackend`` (server-side only) and lets ``WhenfulClient`` return
        ``None`` — that's a known v1 stdio degradation already documented in
        ``app/mcp_shared/tools/instances.py::_lookup_existing_wall_clock``:
        date-only reschedules from stdio drop the wall-clock and fall back
        to UTC midnight. Full-datetime reschedules are unaffected.

        Returns:
        - ``(local_time_iso, iana_tz_name)`` on success, where
          ``local_time_iso`` is an HH:MM[:SS] string and ``iana_tz_name`` is
          something like ``"America/New_York"`` / ``"UTC"``.
        - ``None`` when the instance is missing, has no
          ``scheduled_datetime``, or the backend has no DB to query.
        """
        ...

    async def reschedule_instance(
        self,
        user_id: int,
        instance_id: int,
        *,
        new_datetime: datetime,
    ) -> dict[str, Any] | None:
        """Reschedule a recurring task instance to ``new_datetime``.

        ``new_datetime`` is a Python ``datetime``. Naive/aware semantics
        match ``RecurrenceService.schedule_instance``: naive is interpreted
        as user-local, aware is converted to UTC. Tool callers handle the
        date-only-vs-datetime parsing before invoking this op.

        Returns ``None`` on missing/unowned. On success returns a dict
        with the full instance shape (mirrors REST ``InstanceResponse``):
        ``id``, ``task_id``, ``status``, ``instance_date``,
        ``scheduled_datetime`` (ISO 8601 string), plus optional
        ``task_title``, ``domain_name`` when the relationship is loaded.

        Implementations:
        - HTTP: ``RecurrenceService.schedule_instance`` (eager-loads
          ``.task.domain``) + commit + fire-and-forget GCal sync.
        - stdio: ``PUT /api/v1/instances/{instance_id}/schedule`` with
          body ``{"scheduled_datetime": new_datetime.isoformat()}``.
        """
        ...

    async def batch_complete_instances(
        self,
        user_id: int,
        *,
        task_id: int,
        before_date: date,
    ) -> dict[str, Any]:
        """Mark all pending instances of ``task_id`` before ``before_date`` completed.

        Returns ``{"completed_count": int}`` (mirrors REST
        ``BatchCompleteResponse``). Never raises on a missing parent task —
        ``completed_count: 0`` is the legitimate "nothing to do" surface.

        Implementations:
        - HTTP: ``RecurrenceService.batch_complete_instances`` + commit +
          bulk GCal sync when count > 0.
        - stdio: ``POST /api/v1/instances/batch-complete`` with body
          ``{"task_id": ..., "before_date": "YYYY-MM-DD"}``.
        """
        ...

    async def batch_past_instances(self, user_id: int, *, action: str) -> dict[str, Any]:
        """Complete or skip every pending past instance across all tasks.

        ``action`` is ``"complete"`` or ``"skip"`` (tool callers validate
        before invoking). Returns ``{"affected_count": int}`` (mirrors
        REST ``BatchPastResponse``).

        Implementations:
        - HTTP: ``RecurrenceService.batch_complete_all_past_instances`` or
          ``batch_skip_all_past_instances`` + commit + bulk GCal sync when
          count > 0.
        - stdio: ``POST /api/v1/instances/batch-past`` with body
          ``{"action": "complete" | "skip"}``.
        """
        ...

    async def pending_past_count(self, user_id: int) -> int:
        """Count pending instances from past days (across all tasks).

        Returns a plain ``int`` so the tool layer can branch on zero
        without dict-unpacking. Both backends collapse the same query.

        Implementations:
        - HTTP: ``RecurrenceService.count_pending_past_instances`` —
          ``SELECT COUNT(*)`` with no commit (read-only).
        - stdio: ``GET /api/v1/instances/pending-past-count``; extracts
          ``pending_count`` from the JSON response.
        """
        ...

    async def list_past_instances(self, user_id: int, *, limit: int) -> list[dict[str, Any]]:
        """Per-parent aggregate of pending past instances, ordered by count desc.

        Each dict mirrors REST ``PastInstanceAggregate``:
        ``task_id``, ``pending_count``, ``first_date`` (ISO), ``last_date``
        (ISO), ``title``, ``is_recurring``, ``parent_status``,
        ``domain_name`` (str | None). Parent-task fields are snapshotted
        so the tool layer can format output without a second round-trip.

        Implementations:
        - HTTP: ``RecurrenceService.aggregate_pending_by_task`` + Task
          fetch (selectinload domain) + sort/truncate.
        - stdio: ``GET /api/v1/instances/past?limit=N``; passes the JSON
          list through.
        """
        ...

    # ------------------------------------------------------------------
    # Schedule operations (MCP-stdio full parity, 2026-05-13)
    # ------------------------------------------------------------------

    async def get_schedule(
        self,
        user_id: int,
        *,
        date_from: str,
        date_to: str,
    ) -> dict[str, Any]:
        """Return scheduled tasks and recurring instances for a date range.

        Returns a dict with two keys:

        - ``tasks`` (``list[dict]``) — domain-assigned one-off tasks
          whose ``scheduled_date`` falls within ``[date_from, date_to]``,
          ordered by ``(scheduled_date, scheduled_time)``. Each entry has
          the keys of ``TaskResponse`` (see ``list_tasks`` docstring).
        - ``instances`` (``list[dict]``) — recurring task instances whose
          ``instance_date`` falls within ``[date_from, date_to]``, ordered
          by ``instance_date``. Each entry has the keys of
          ``InstanceResponse`` in ``app/routers/instances.py``.

        Dates are ISO ``YYYY-MM-DD`` strings on the wire. Domain-less
        thoughts (``domain_id IS NULL``) are excluded from ``tasks`` to
        match the cloud HTTP MCP behaviour — they belong in
        ``list_thoughts``, not the schedule surface.

        The HTTP path materializes recurring instances up to ``date_to``
        before reading; the stdio path relies on the cloud server's own
        ``GET /tasks?scheduled_date=…`` and ``GET /instances`` routes
        which perform the same materialization server-side.
        """
        ...

    async def get_overdue(self, user_id: int) -> dict[str, Any]:
        """Return overdue tasks plus the count of past pending recurring instances.

        Returns a dict with three keys:

        - ``today`` (``str``) — ISO ``YYYY-MM-DD`` of the user's local
          today, used as the cutoff. Sent so the formatter can include
          it in the human-readable header.
        - ``tasks`` (``list[dict]``) — domain-assigned pending tasks
          whose ``scheduled_date`` is strictly less than ``today``,
          ordered by ``scheduled_date`` ascending. Same dict shape as
          ``list_tasks``. Domain-less thoughts are excluded.
        - ``past_instance_count`` (``int``) — number of recurring task
          instances with ``status = 'pending'`` and ``instance_date <
          today``. Just the count — the list of instances is intentionally
          not returned; use ``list_past_instances`` for the drill-down.
        """
        ...

    async def get_analytics(self, user_id: int, *, days: int) -> dict[str, Any]:
        """Return completion analytics over the last ``days`` days.

        Returns the comprehensive analytics dict produced by
        ``AnalyticsService.get_comprehensive_stats`` — see
        ``app/services/analytics_service.py`` for the canonical shape.
        Keys the tool formatter consumes:

        - ``streaks`` (``dict``) — ``current`` / ``longest`` / ``this_week``.
        - ``total_completed`` (``int``).
        - ``total_pending`` (``int``).
        - ``by_domain`` (``list[dict]``) — entries with ``domain_name`` and ``count``.
        - ``impact_distribution`` (``list[dict]``) — entries with ``impact`` and ``count``.

        ``days`` is clamped to ``[7, 90]`` by the tool wrapper before the
        operation is called. The operation itself trusts the value.
        """
        ...

    async def get_recent_completions(
        self,
        user_id: int,
        *,
        limit: int,
    ) -> list[dict[str, Any]]:
        """Return the most recently completed tasks and instances.

        Each entry has the keys ``AnalyticsService.get_recent_completions``
        produces:

        - ``id`` (``int``) — task or instance ID (caller distinguishes via
          ``is_instance``).
        - ``task_id`` (``int``) — the parent task ID (same as ``id`` for
          one-off tasks).
        - ``title`` (``str``) — task title; masked with the encrypted
          placeholder when the user has ``encryption_enabled = True`` on
          the HTTP path. The stdio path receives plaintext if a
          CryptoManager is loaded.
        - ``completed_at_display`` (``str``) — pre-formatted ``"Mon DD"``
          in the user's local timezone.
        - ``domain_name`` (``str``).
        - ``domain_icon`` (``str``).
        - ``is_instance`` (``bool``).
        """
        ...

    # ------------------------------------------------------------------
    # Domain operations
    # ------------------------------------------------------------------

    async def list_domains(self, user_id: int) -> list[dict[str, Any]]:
        """Return all domains for ``user_id`` (including archived).

        Each dict has the keys of ``DomainResponse`` in
        ``app/routers/domains.py`` plus ``created_at``:

        - ``id`` (int)
        - ``name`` (str — plaintext on the stdio path after decryption;
          ciphertext on the HTTP path when the user has encryption enabled)
        - ``color`` (str | None)
        - ``icon`` (str | None)
        - ``position`` (int)
        - ``is_archived`` (bool)
        - ``created_at`` (str ISO-8601 | None)

        Implementations:
        - HTTP: SELECT against the Domain model with ``user_id`` filter,
          ``include_archived=True``.
        - stdio: ``GET /api/v1/domains?include_archived=true`` with a
          Bearer token. The client decrypts ``name`` in place if a
          ``CryptoManager`` is loaded.
        """
        ...

    async def create_domain(
        self,
        user_id: int,
        *,
        name: str,
        color: str | None = None,
        icon: str | None = None,
    ) -> dict[str, Any]:
        """Create a new domain (or return existing one with same name).

        ``name`` arrives plaintext from tool code. The stdio backend
        encrypts it before POST when ``CryptoManager`` is loaded; the
        HTTP backend stores the value as-is (the server has no key and
        the React frontend already encrypts in the encryption-on path).

        Returns a dict with the same keys as ``list_domains``.

        Implementations:
        - HTTP: ``TaskService.create_domain`` + commit + serialize.
        - stdio: ``POST /api/v1/domains`` body ``{name, color, icon}``.
          The server response is decrypted in place.
        """
        ...

    async def update_domain(
        self,
        user_id: int,
        domain_id: int,
        *,
        name: str | None = None,
        color: str | None = None,
        icon: str | None = None,
        position: int | None = None,
    ) -> dict[str, Any] | None:
        """Update a domain. Returns ``None`` if not found / not owned.

        Only the fields explicitly provided (non-``None``) are sent. To
        clear ``color`` or ``icon``, the caller currently has to use the
        REST endpoint directly — MCP tool surface does not yet expose
        the "set null" path.

        Implementations:
        - HTTP: ``TaskService.update_domain`` + commit + serialize.
        - stdio: ``PUT /api/v1/domains/{id}`` with the provided fields.
          ``name`` is encrypted before sending when crypto is loaded.
        """
        ...

    async def archive_domain(self, user_id: int, domain_id: int) -> dict[str, Any] | None:
        """Archive (soft-delete) a domain. Returns ``None`` if not found.

        Returns the archived domain's dict so callers can render
        ``is_archived = true``.

        Implementations:
        - HTTP: ``TaskService.archive_domain`` + commit + serialize.
        - stdio: ``DELETE /api/v1/domains/{id}`` then ``GET /api/v1/domains``
          to re-fetch the archived row. The REST endpoint returns 204 with
          no body, so the stdio client constructs the dict from the
          pre-archive snapshot plus ``is_archived = True``.
        """
        ...

    # ------------------------------------------------------------------
    # User preferences operations (MCP-stdio full parity, 2026-05-13)
    # ------------------------------------------------------------------

    async def get_preferences(self, user_id: int) -> dict[str, Any]:
        """Return the authenticated user's preferences as a JSON-safe dict.

        Keys mirror ``PreferencesResponse`` in ``app/routers/preferences.py``.
        The tool formatter reads:

        - ``timezone`` (``str | None``) — IANA timezone or ``None``.
        - ``secondary_timezone`` (``str | None``).
        - ``show_completed_in_planner`` (``bool``).
        - ``completed_retention_days`` (``int``).
        - ``show_completed_in_list`` (``bool``).
        - ``show_scheduled_in_list`` (``bool``).
        - ``time_format`` (``str``) — ``"12h"`` or ``"24h"``.
        - ``encryption_enabled`` (``bool``).

        Preferences are server-side metadata — not at-rest-encrypted. The
        stdio path returns the raw REST payload; the HTTP path serializes
        the ORM row directly.
        """
        ...

    # ------------------------------------------------------------------
    # Task operations (extended) — 16 widened operations added 2026-05-13
    # for the MCP-stdio full-parity migration. These mirror the existing
    # tool surface in `app/mcp_shared/tools/tasks.py`. Each operation
    # returns a JSON-safe dict (or list/None) matching the REST schema in
    # ``app/routers/tasks.py``; tool code formats the dict into the
    # user-visible string. See
    # ``docs/plans/2026-05-13-22-00-mcp-stdio-full-parity.md`` §2 for the
    # contract.
    #
    # Naming convention:
    # - Reads return ``list[dict]`` (empty list, not None, on no-match).
    # - Single-row reads return ``dict | None`` (None on 404 / not-owned).
    # - Writes return the resulting task ``dict`` (with the ``id`` of the
    #   created/updated row) or ``None`` if the target is missing.
    # - Batch ops return a ``dict`` aggregate: ``{created/updated/completed:
    #   list[dict], errors: list[dict]}``. The exact shape is documented
    #   per-op below.
    # ------------------------------------------------------------------

    async def list_thoughts(
        self,
        user_id: int,
        *,
        status: str = "pending",
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """List untriaged inbox items (tasks with ``domain_id IS NULL``).

        Same keys as ``list_tasks`` per task. Status ``"all"`` returns
        ``pending + completed`` (excludes archived).

        Implementations:
        - HTTP: ``TaskService.get_tasks(has_domain=False, top_level_only=True, ...)``
        - stdio: ``GET /api/v1/tasks`` filtered by ``parent_id is None`` and
          ``domain_id is None`` on the client. (No dedicated REST endpoint —
          the REST list endpoint always includes domain-less items when no
          ``domain_id`` filter is set; the stdio client filters them in.)
        """
        ...

    async def list_recurring_tasks(
        self,
        user_id: int,
        *,
        status: str = "pending",
    ) -> list[dict[str, Any]]:
        """List recurring parent tasks with pending-instance backlog summary.

        Each dict has the ``TaskResponse`` keys plus aggregated counters:
        - ``pending_count`` (int): number of pending instances
        - ``first_pending_date`` (str | None): ISO date of first pending instance
        - ``last_pending_date`` (str | None): ISO date of last pending instance

        Implementations:
        - HTTP: SELECT recurring parents + ``RecurrenceService.aggregate_pending_by_task``.
        - stdio: ``GET /api/v1/tasks?is_recurring=true`` + ``GET
          /api/v1/instances?status=pending&group_by=task_id`` (or equivalent).
        """
        ...

    async def create_task(
        self,
        user_id: int,
        *,
        title: str,
        domain_id: int | None = None,
        impact: int = 4,
        clarity: str = "normal",
        duration_minutes: int | None = None,
        scheduled_date: str | None = None,
        scheduled_time: str | None = None,
        description: str | None = None,
        parent_id: int | None = None,
        is_recurring: bool = False,
        recurrence_rule: dict[str, Any] | None = None,
        recurrence_start: str | None = None,
        recurrence_end: str | None = None,
        reminder_minutes_before: int | None = None,
    ) -> dict[str, Any]:
        """Create a task and return the ``TaskResponse`` dict.

        Domain resolution is the caller's responsibility — pass
        ``domain_id`` (int) here, not a domain name. The tool function
        translates names to ids via ``list_domains`` before calling.

        For recurring tasks, ``TaskInstance`` rows are materialized
        synchronously before returning (mirrors REST behavior). The returned
        dict carries the parent task only; instance counts go through
        ``list_recurring_tasks`` if needed.

        Side effects on the HTTP path:
        - Fire-and-forget GCal sync (``fire_and_forget_bulk_sync`` for
          recurring; ``fire_and_forget_sync_task`` for one-off with a date).
        - ``db.commit()`` is performed inside the operation.

        Side effects on the stdio path:
        - The cloud server triggers GCal sync from the REST route.

        Returns the created task dict (with ``id`` populated).
        """
        ...

    async def update_task(
        self,
        user_id: int,
        task_id: int,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Update a task. Returns the updated ``TaskResponse`` dict or
        ``None`` if the task is missing / not owned.

        Accepted ``fields`` mirror ``TaskUpdate`` in ``app/routers/tasks.py``:
        ``title``, ``description``, ``domain_id``, ``parent_id``,
        ``duration_minutes``, ``impact``, ``clarity``, ``scheduled_date``,
        ``scheduled_time``, ``is_recurring``, ``recurrence_rule``,
        ``recurrence_start``, ``recurrence_end``, ``position``,
        ``reminder_minutes_before``. Date and time fields are ISO strings.

        Side effects on the HTTP path:
        - Regenerate recurring instances if rule/schedule changed.
        - Delete all instances if recurring was disabled.
        - Reset ``reminder_sent_at`` if scheduling fields changed.
        - Fire-and-forget GCal sync.
        - ``db.commit()`` performed inside the operation.

        On the stdio path the cloud server handles those side effects on
        the REST ``PUT /tasks/{id}`` route.
        """
        ...

    async def complete_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Mark a non-recurring task complete. Returns the updated task
        dict, or ``None`` if the task is missing.

        Recurring tasks are an error case for the *tool*, not for this
        operation — the tool checks ``is_recurring`` on the task first and
        emits a "use complete_instance" string before calling this op.
        """
        ...

    async def uncomplete_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Reverse ``complete_task``. Returns the updated task dict or
        ``None`` if missing.
        """
        ...

    async def toggle_complete(
        self,
        user_id: int,
        task_id: int,
        *,
        target_date: str | None = None,
    ) -> dict[str, Any] | None:
        """Toggle completion state.

        For non-recurring tasks: flips ``status`` between pending and
        completed. For recurring tasks: toggles the instance for
        ``target_date`` (defaults to user's today in their TZ).

        Returns a dict with:
        - ``task_id`` (int)
        - ``completed`` (bool)
        - ``instance_id`` (int | None): set for recurring tasks
        - ``target_date`` (str | None): ISO date, set for recurring tasks
        - ``cascaded_subtask_ids`` (list[int]): subtasks whose GCal events
          were unsynced when completing a parent (non-recurring only)

        Returns ``None`` if the task is missing.
        """
        ...

    async def nuke_task(self, user_id: int, task_id: int) -> bool:
        """Hard-delete a task and its descendants. Returns ``True`` if
        deletion happened, ``False`` if the task was missing.
        """
        ...

    async def archive_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Soft-delete (archive) a task. Returns the updated dict or
        ``None`` if missing.
        """
        ...

    async def restore_task(self, user_id: int, task_id: int) -> dict[str, Any] | None:
        """Restore an archived task. Returns the updated dict or ``None``
        if the task is not found / not archived.

        For recurring tasks, instances are re-materialized server-side.
        """
        ...

    async def get_archived_tasks(
        self,
        user_id: int,
        *,
        domain_id: int | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """List archived tasks. Domain-less archived tasks are excluded
        unless ``domain_id`` is explicitly provided.
        """
        ...

    async def search_tasks(
        self,
        user_id: int,
        *,
        query: str,
        include_completed: bool = False,
    ) -> list[dict[str, Any]]:
        """Full-text-ish search across ``title`` and ``description``.

        Domain-less inbox items are excluded from search results
        (matches existing tool behavior). Returns at most 100 rows.

        On the HTTP path: ``ILIKE`` against escaped pattern with
        ``Task.domain_id IS NOT NULL`` filter.
        On the stdio path: ``GET /api/v1/search/tasks?q=...&include_completed=...``.
        """
        ...

    async def batch_create_tasks(
        self,
        user_id: int,
        *,
        tasks: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Create many tasks in one round trip.

        Each item in ``tasks`` is a dict mirroring the ``create_task`` kwargs
        (``title``, ``domain_id``, ``impact``, ...). ``domain`` (name)
        resolution is the caller's responsibility — the tool resolves names
        to ids before passing them through.

        Returns:
        - ``created`` (list[dict]): the successfully-created task dicts
          (each with ``id`` and ``title``).
        - ``errors`` (list[dict]): per-item failures as ``{index: int,
          message: str}``. Items that succeed do NOT appear in errors.
        """
        ...

    async def batch_update_tasks(
        self,
        user_id: int,
        *,
        task_ids: list[int],
        impact: int | None = None,
        clarity: str | None = None,
        domain_id: int | None = None,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Apply a uniform partial update to many tasks.

        Returns:
        - ``updated_count`` (int)
        - ``skipped_recurring`` (list[int]): IDs skipped because they were
          recurring and the update was a completion.
        - ``errors`` (list[dict]): per-task failures as ``{id: int,
          message: str}``.
        """
        ...

    async def batch_complete_tasks(
        self,
        user_id: int,
        *,
        task_ids: list[int],
    ) -> dict[str, Any]:
        """Complete many non-recurring tasks. Skips recurring tasks.

        Returns:
        - ``completed_count`` (int)
        - ``skipped_recurring`` (list[int])
        - ``errors`` (list[dict])
        """
        ...


__all__ = ["Backend"]


# Re-export AsyncIterator solely so the stdio implementation can satisfy
# `session()` with an async-generator-based context manager if it wishes. Not
# used by the HTTP path.
_ = AsyncIterator
