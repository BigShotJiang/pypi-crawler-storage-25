"""Transport-agnostic Pydantic schemas shared between the cloud HTTP MCP
server and the standalone stdio MCP client.

This module is part of `app.mcp_shared` — the import-clean subpackage that
must be installable as a standalone PyPI wheel. **Rule for this file:**
stdlib + `pydantic` ONLY. No FastAPI imports, no SQLAlchemy, no `app.*`
imports outside `app.mcp_shared.*`.

Schemas defined here are shape contracts. They validate request payloads at
the MCP boundary and at the REST boundary equivalently — the cloud server
re-imports them from `app/routers/tasks.py` (single source of truth lives
HERE, not in routers) so server-side validation gates match what MCP tool
callers see.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

VALID_DAYS_OF_WEEK = {"MO", "TU", "WE", "TH", "FR", "SA", "SU"}

# Signed BYDAY token (RFC 5545): optional sign, optional digits, two-letter weekday.
# Used to detect when a user mistakenly posts an RFC 5545 BYDAY token (e.g. "-1MO")
# into the structured days_of_week list, so we can hint at the correct shape.
_SIGNED_BYDAY_PATTERN = re.compile(r"^[+-]?\d+(MO|TU|WE|TH|FR|SA|SU)$")


class RecurrenceRuleSchema(BaseModel):
    """Validated shape for recurrence_rule JSON.

    The `week_of_month` field accepts -1..-5 for "Nth-to-last X of the month"
    (per RFC 5545 BYDAY semantics, e.g. "last Monday" → BYDAY=-1MO,
    "2nd-to-last Friday" → BYDAY=-2FR) or 1..5 for "Nth occurrence in the
    month". Zero is rejected — RFC 5545 has no meaning for BYDAY=0MO.
    A non-null `week_of_month` must be paired with a non-empty `days_of_week`;
    "the last week" alone is meaningless without the weekday it anchors to.
    """

    model_config = ConfigDict(extra="forbid")

    freq: Literal["daily", "weekly", "monthly", "yearly"]
    interval: int = Field(default=1, ge=1, le=99)
    days_of_week: list[str] | None = None
    day_of_month: int | None = Field(None, ge=1, le=31)
    # Bound widened from (ge=1, le=5) to (ge=-5, le=5) to support RFC 5545's
    # negative BYDAY prefix for "Nth-to-last X of the month" patterns
    # (e.g. -1MO = last Monday, -2MO = 2nd-to-last Monday, -3FR =
    # 3rd-to-last Friday). The materializer (recurrence_service.py) and
    # GCal RRULE adapter (gcal_rrule.py) honor any signed value via
    # dateutil's weekday(N) constructor; the API was the gap.
    week_of_month: int | None = Field(None, ge=-5, le=5)
    # `month_of_year` is the SINGLE-MONTH anchor for yearly nth-weekday-of-month
    # patterns ("last Monday of January" → BYMONTH=1;BYDAY=-1MO). Constraints:
    # 1..12. Mutually exclusive with `months_of_year` — see the
    # `validate_no_month_field_clash` cross-field validator below.
    month_of_year: int | None = Field(None, ge=1, le=12)
    # `months_of_year` is the MULTI-MONTH array for seasonal/quarterly patterns
    # ("every Monday in summer" → freq=weekly, days_of_week=[MO],
    # months_of_year=[6,7,8] → BYMONTH=6,7,8). Each entry must be 1..12 (per
    # RFC 5545); the list must be non-empty when set. Empty lists are
    # normalized to None so downstream consumers can rely on the Pythonic
    # falsey check `if rule.get("months_of_year"):` without ambiguity.
    months_of_year: list[int] | None = None

    @field_validator("week_of_month")
    @classmethod
    def validate_week_of_month(cls, v: int | None) -> int | None:
        # Pydantic's ge/le admits the entire integer range [-5, 5], including 0.
        # Zero is meaningless under RFC 5545 BYDAY semantics — there is no
        # "0th Monday of the month" — so we reject it explicitly with a hint
        # at the two valid use-cases.
        if v == 0:
            raise ValueError(
                "week_of_month must be -1 to -5 (Nth-to-last) or 1 to 5 "
                "(Nth occurrence in the month); 0 has no meaning in RFC 5545"
            )
        return v

    @field_validator("days_of_week")
    @classmethod
    def validate_days_of_week(cls, v: list[str] | None) -> list[str] | None:
        if v is not None:
            for d in v:
                if d not in VALID_DAYS_OF_WEEK:
                    base = f"Invalid day: '{d}'. Must be one of {sorted(VALID_DAYS_OF_WEEK)}."
                    # Hint at the structured form when the caller posted a signed
                    # BYDAY token (e.g. "-1MO" or "2WE") into days_of_week —
                    # they meant to use the (week_of_month, days_of_week) pair.
                    if _SIGNED_BYDAY_PATTERN.match(d):
                        base += (
                            " (For 'last Monday of month' patterns, use the structured form: "
                            "week_of_month=-1, days_of_week=['MO'].)"
                        )
                    raise ValueError(base)
        return v

    @field_validator("months_of_year")
    @classmethod
    def validate_months_of_year(cls, v: list[int] | None) -> list[int] | None:
        # Two independent passes:
        #   1. Each entry is in [1, 12] (RFC 5545 BYMONTH range — the spec
        #      admits 1..12 and dateutil rejects anything outside).
        #   2. Empty lists are normalized to None, so downstream code can use
        #      `if rule.get("months_of_year"):` without distinguishing
        #      "explicitly cleared" from "never set". Aligns with how the
        #      materializer and gcal serializer treat the field as a presence
        #      flag.
        if v is None:
            return None
        if len(v) == 0:
            return None
        for m in v:
            if not isinstance(m, int) or m < 1 or m > 12:
                raise ValueError(
                    f"Invalid month: {m!r}. Each entry in months_of_year must be an integer in [1, 12] "
                    "(RFC 5545 BYMONTH range)."
                )
        return v

    @model_validator(mode="after")
    def validate_week_requires_days(self) -> RecurrenceRuleSchema:
        # `week_of_month` without `days_of_week` is meaningless: the materializer
        # and GCal serializer both encode the pair together as BYDAY=NWD (e.g.
        # `-1MO`), and there is no fallback to "last day of month regardless of
        # weekday" — that's the `day_of_month` field's territory. The reverse
        # (days_of_week without week_of_month) is the existing weekly pattern
        # and remains valid.
        if self.week_of_month is not None and not self.days_of_week:
            raise ValueError(
                "week_of_month requires days_of_week (the weekday picker — e.g. ['MO']); "
                "both must be set together for nth-weekday recurrence."
            )
        return self

    @model_validator(mode="after")
    def validate_no_month_field_clash(self) -> RecurrenceRuleSchema:
        # `month_of_year` (single int) and `months_of_year` (list) are two
        # independently-typed routes to the same RFC 5545 BYMONTH axis. Setting
        # BOTH on the same rule is structurally ambiguous — the materializer
        # would have to pick one, and either choice silently overrides the
        # caller's intent on the other field. Reject up-front with a hint
        # naming the right field for each common use-case.
        #
        # Decision rationale: the parallel "prefer the array" approach was
        # rejected because it makes the override invisible (caller posts
        # month_of_year=1 and months_of_year=[6,7,8], gets summer recurrence,
        # has no idea why). An explicit error forces the caller to be
        # intentional about which axis they're modeling.
        if self.month_of_year is not None and self.months_of_year is not None:
            raise ValueError(
                "Cannot set both month_of_year (int) and months_of_year (list). "
                "Use months_of_year (list) for multi-month patterns "
                "(e.g. 'every Monday in summer' → [6, 7, 8]); "
                "use month_of_year (int) for single-month yearly nth-weekday "
                "patterns (e.g. 'last Monday of January' → 1)."
            )
        return self


__all__ = [
    "VALID_DAYS_OF_WEEK",
    "RecurrenceRuleSchema",
]
