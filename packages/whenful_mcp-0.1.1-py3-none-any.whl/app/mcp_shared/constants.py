"""Transport-agnostic constants for the MCP shared package.

This module is part of `app.mcp_shared` — the import-clean subpackage that
must be installable as a standalone PyPI wheel without dragging in FastAPI,
SQLAlchemy, or the rest of the Whenful server tree.

**Rule for this file:** stdlib + `zoneinfo` ONLY. No imports from `app.*`,
no FastAPI, no Pydantic, no SQLAlchemy. The wheel-buildability tests in
`tests/test_mcp_shared_isolation.py` enforce the rule.

The cloud server's `app/constants.py` re-exports each symbol below so that
the rest of the codebase can keep importing from `app.constants` (the
historical canonical location). The single source of truth lives here.
"""

from __future__ import annotations

from datetime import date

# =============================================================================
# Crypto Constants
# =============================================================================
# Used for server-side validation of client-side encryption. The authoritative
# client-side implementation is in `frontend/src/lib/crypto.ts`. The standalone
# stdio client (`mcp_stdio/crypto.py`) also references this value so its
# verifier-check stays byte-identical with the cloud verifier.

# Known value used to verify encryption passphrase is correct.
ENCRYPTION_TEST_VALUE = "WHENFUL_ENCRYPTION_TEST"


# =============================================================================
# Google Calendar Constants
# =============================================================================

# Fallback duration applied when a task has no explicit duration and needs to
# be placed on the GCal canvas. Used by MCP `create_task` / `update_task` when
# composing the GCal payload, and by the cloud GCal sync engine. Mirrors the
# UI's default "Block 30 min" affordance.
GCAL_SYNC_DEFAULT_DURATION_MINUTES = 30


# =============================================================================
# Timezone Constants
# =============================================================================

# Fallback when a user hasn't set their timezone. UTC is the only safe choice
# for an unknown user: it never silently shifts an alarm by 6 hours.
DEFAULT_TIMEZONE = "UTC"


def get_user_today(timezone: str | None) -> date:
    """
    Get today's date in the user's timezone.

    Args:
        timezone: IANA timezone string (e.g., "America/New_York") or None.

    Returns:
        Today's date in the specified timezone, or UTC if timezone is
        None/invalid.
    """
    from datetime import datetime
    from zoneinfo import ZoneInfo

    try:
        tz = ZoneInfo(timezone) if timezone else ZoneInfo(DEFAULT_TIMEZONE)
    except (KeyError, TypeError):
        # Invalid timezone string - fall back to UTC
        tz = ZoneInfo(DEFAULT_TIMEZONE)

    return datetime.now(tz).date()


__all__ = [
    "DEFAULT_TIMEZONE",
    "ENCRYPTION_TEST_VALUE",
    "GCAL_SYNC_DEFAULT_DURATION_MINUTES",
    "get_user_today",
]
