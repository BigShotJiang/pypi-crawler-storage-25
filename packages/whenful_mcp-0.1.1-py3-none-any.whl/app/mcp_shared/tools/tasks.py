"""Task CRUD MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534. Each
function takes `backend: Backend` and `user_id: int` as its first two
parameters and runs the same business logic the HTTP MCP previously ran
inline. The HTTP server's thin wrappers in `mcp_server.py` supply a DB
backend; the future stdio client (Phase B+) will supply an HTTP-client
backend without any change to this code.

Tool count: 17 (list_tasks, list_thoughts, list_recurring_tasks,
get_task, create_task, update_task, complete_task, uncomplete_task,
toggle_complete, nuke_task, archive_task, restore_task,
get_archived_tasks, search_tasks, batch_create_tasks,
batch_update_tasks, batch_complete_tasks).

Behavior contract: zero regressions vs the inlined originals. All
user-facing strings, validation messages, and side-effect orderings
(GCal sync via fire_and_forget, materialize_instances on recurrence,
reminder_sent_at reset, etc.) are preserved 1:1. `tests/test_mcp.py`
pins this contract.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, date, datetime
from typing import Any

from ..constants import GCAL_SYNC_DEFAULT_DURATION_MINUTES
from ..error_guard import guard_db_errors, resolve_sqlalchemy_exc_classes
from ..formatters import IMPACT_LABELS, format_task, safe_title
from ..validators import (
    VALID_CLARITY,
    VALID_LIST_STATUS,
    parse_date,
    parse_time,
    strip_control_chars,
    validate_task_fields,
)
from . import Backend, check_encryption, is_encrypted, resolve_domain_via_backend

logger = logging.getLogger("whenful.mcp")


def _validate_recurrence_rule(raw: str) -> tuple[dict, None] | tuple[None, str]:
    """Parse + structurally validate an MCP-supplied ``recurrence_rule`` JSON string.

    Two layers — both required:

    1. ``json.loads`` — catches malformed JSON ("not json", "{{bad"). Returns
       ``Invalid recurrence_rule JSON: …`` as the error message.

    2. ``RecurrenceRuleSchema.model_validate`` — catches the structural bugs
       the REST API rejects but which (pre-fix) MCP silently accepted: invalid
       weekday codes like ``"FOO"``, signed BYDAY tokens stuffed into
       ``days_of_week`` like ``"-1MO"``, ``week_of_month=0`` (no RFC 5545
       meaning), out-of-range ``week_of_month`` (``-2``, ``6``, …), and the
       cross-field rule ``week_of_month requires days_of_week``.

    Without layer 2, an MCP caller (LLM or attacker) could insert rules that
    the materializer either crashed on (``ValueError: Can't create weekday
    with n==0`` for ``week_of_month=0``) or silently misinterpreted (degrading
    to "weekly without byweekday" for invalid days_of_week).

    Returns ``(rule_dict, None)`` on success or ``(None, error_message)`` on
    failure — caller propagates the error string in-band as the MCP response.
    """
    # Schema lives in `app.mcp_shared.schemas` (transport-agnostic Pydantic).
    # `app.routers.tasks` re-imports from there, so the cloud REST API and
    # the MCP tool layer share the same validation gate by construction.
    from ..schemas import RecurrenceRuleSchema

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as e:
        return None, f"Invalid recurrence_rule JSON: {e}"

    if not isinstance(parsed, dict):
        return None, "Invalid recurrence_rule: must be a JSON object."

    try:
        validated = RecurrenceRuleSchema.model_validate(parsed)
    except Exception as e:
        # Pydantic ValidationError → human-readable line per the same shape
        # the REST API surfaces. Pull out the first error message so MCP
        # callers (LLMs especially) get an actionable hint rather than a
        # multi-line dump.
        try:
            from pydantic import ValidationError

            if isinstance(e, ValidationError):
                errs = e.errors()
                if errs:
                    first = errs[0]
                    loc = ".".join(str(p) for p in first.get("loc", ())) or "(root)"
                    msg = first.get("msg", "invalid")
                    return None, f"Invalid recurrence_rule: {loc}: {msg}"
        except Exception:
            pass
        return None, f"Invalid recurrence_rule: {e}"

    # ``model_dump(exclude_unset=True)`` preserves the field-set as supplied,
    # so the downstream materializer sees the same shape an HTTP caller would
    # produce. Defaults like ``interval=1`` ARE applied because the schema
    # defaults are populated unless explicitly opted out.
    return validated.model_dump(exclude_none=True), None


async def list_tasks(
    backend: Backend,
    user_id: int,
    domain: str | None = None,
    status: str = "pending",
    scheduled_date: str | None = None,
    clarity: str | None = None,
    impact: int | None = None,
    is_recurring: bool | None = None,
    parent_id: int | None = None,
    limit: int = 50,
    offset: int = 0,
) -> str:
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    if clarity is not None and clarity not in VALID_CLARITY:
        return f"Invalid clarity '{clarity}'. Must be one of: {', '.join(sorted(VALID_CLARITY))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Resolve domain name to ID via the backend's `list_domains` op so the
    # tool stays transport-agnostic.
    domain_id = None
    if domain:
        domain_id, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error

    # Validate the scheduled_date wire string up-front. The backend op also
    # accepts an ISO string and returns ``[]`` on a parse failure, but
    # surfacing a clear human-readable error here matches the pre-refactor
    # tool behavior.
    parsed_scheduled_date = None
    if scheduled_date:
        parsed = parse_date(scheduled_date, "scheduled_date")
        if isinstance(parsed, str):
            return parsed
        parsed_scheduled_date = parsed

    # "all" returns pending + completed, excludes archived (mirrors REST
    # tasks.py:498-500). The Backend protocol handles the derivation via the
    # paired `status` + `exclude_statuses` filters.
    effective_status = "all" if status == "all" else status
    effective_exclude = ["archived"] if status == "all" else None

    # Subtask listing inherits parent's domain — has_domain filter would be
    # redundant and could mask legitimate subtask rows. Only apply the
    # thoughts-exclusion when listing top-level tasks without a domain filter.
    has_domain_filter = None if (parent_id is not None or domain_id is not None) else True

    tasks = await backend.list_tasks(
        user_id,
        domain_id=domain_id,
        status=effective_status,
        scheduled_date=parsed_scheduled_date.isoformat() if parsed_scheduled_date else None,
        is_recurring=is_recurring,
        clarity=clarity,
        parent_id=parent_id,
        limit=limit,
        offset=offset if offset else None,
        top_level_only=parent_id is None,
        has_domain=has_domain_filter,
        exclude_statuses=effective_exclude,
        impact=impact,
    )

    if not tasks:
        return "No tasks found matching filters."

    lines = [format_task(t) for t in tasks]
    return f"{len(tasks)} task(s):\n\n" + "\n".join(lines)


async def list_thoughts(
    backend: Backend,
    user_id: int,
    status: str = "pending",
    limit: int = 50,
    offset: int = 0,
) -> str:
    """List untriaged inbox items ("thoughts") — tasks that have no domain yet."""
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    thoughts = await backend.list_thoughts(user_id, status=status, limit=limit, offset=offset)

    if not thoughts:
        return "No thoughts in the inbox."

    lines = [format_task(t) for t in thoughts]
    return f"{len(thoughts)} thought(s) in inbox:\n\n" + "\n".join(lines)


async def list_recurring_tasks(
    backend: Backend,
    user_id: int,
    status: str = "pending",
) -> str:
    """List recurring parent tasks with pending-instance backlog summary."""
    if status not in VALID_LIST_STATUS:
        return f"Invalid status '{status}'. Must be one of: {', '.join(sorted(VALID_LIST_STATUS))}."
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    parents = await backend.list_recurring_tasks(user_id, status=status)

    if not parents:
        return f"No recurring tasks found (status={status})."

    # Order by pending_count desc — mirrors the original SQL path's sort.
    ordered = sorted(parents, key=lambda p: p.get("pending_count") or 0, reverse=True)

    lines = [f"{len(ordered)} recurring task(s):\n"]
    for parent in ordered:
        base = format_task(parent)
        count = parent.get("pending_count") or 0
        if count > 0:
            suffix = f"  ({count} pending, {parent.get('first_pending_date')} -> {parent.get('last_pending_date')})"
        else:
            suffix = "  (0 pending)"
        lines.append(base + suffix)
    return "\n".join(lines)


@guard_db_errors("create_task")
async def create_task(
    backend: Backend,
    user_id: int,
    title: str,
    domain: str | None = None,
    impact: int = 4,
    clarity: str = "normal",
    duration_minutes: int | None = None,
    scheduled_date: str | None = None,
    scheduled_time: str | None = None,
    description: str | None = None,
    parent_id: int | None = None,
    is_recurring: bool = False,
    recurrence_rule: str | None = None,
    recurrence_start: str | None = None,
    recurrence_end: str | None = None,
    reminder_minutes_before: int | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate inputs (mirrors REST Pydantic validation)
    validation_error = validate_task_fields(
        title=title,
        impact=impact,
        clarity=clarity,
        duration_minutes=duration_minutes,
        reminder_minutes_before=reminder_minutes_before,
        description=description,
    )
    if validation_error:
        return validation_error

    domain_id = None
    if domain:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error
        domain_id = resolved

    # Validate date/time strings before calling the op.
    # Both bounds the parsed values for downstream auto-fill / auto-populate
    # logic AND surfaces wire-format errors with the field name in-band, the
    # same shape the REST Pydantic validator produces. (PR #1555/#1594 +
    # master-side hardenings — preserved on top of branch's operations API.)
    parsed_date = None
    if scheduled_date:
        parsed_date = parse_date(scheduled_date, "scheduled_date")
        if isinstance(parsed_date, str):
            return parsed_date

    parsed_time = None
    if scheduled_time:
        parsed_time = parse_time(scheduled_time, "scheduled_time")
        if isinstance(parsed_time, str):
            return parsed_time

    # Auto-fill duration when scheduling with time (mirrors REST tasks.py:138-142)
    effective_duration = duration_minutes
    if parsed_time is not None and effective_duration is None:
        effective_duration = GCAL_SYNC_DEFAULT_DURATION_MINUTES

    # Parse + structurally validate recurrence rule via the schema layer
    # (the D6 R5 / PR #1594 defense). ``_validate_recurrence_rule`` runs
    # both ``json.loads`` and ``RecurrenceRuleSchema.model_validate`` so
    # MCP cannot accept shapes the REST API rejects (invalid weekday
    # codes, ``week_of_month=0``, signed BYDAY tokens, …).
    parsed_rule = None
    if recurrence_rule:
        parsed_rule, err = _validate_recurrence_rule(recurrence_rule)
        if err:
            return err

    parsed_rec_start = None
    if recurrence_start:
        parsed_rec_start = parse_date(recurrence_start, "recurrence_start")
        if isinstance(parsed_rec_start, str):
            return parsed_rec_start

    parsed_rec_end = None
    if recurrence_end:
        parsed_rec_end = parse_date(recurrence_end, "recurrence_end")
        if isinstance(parsed_rec_end, str):
            return parsed_rec_end

    # Validate recurrence consistency
    if is_recurring and not parsed_rule:
        return (
            "is_recurring=True requires recurrence_rule. Example: "
            '\'{"freq": "weekly", "interval": 1, "days_of_week": ["MO", "WE", "FR"]}\''
        )
    if parsed_rule and not is_recurring:
        return "recurrence_rule provided but is_recurring=False. Set is_recurring=True to create a recurring task."

    # Auto-populate scheduled_date for recurring tasks (matches REST API
    # behavior — recurring tasks need a date anchor; default to the
    # recurrence_start or "today" in the user's timezone via
    # ``backend.get_preferences``, which both backends honour symmetrically).
    if is_recurring and parsed_date is None:
        from ..constants import get_user_today

        prefs = await backend.get_preferences(user_id)
        timezone = prefs.get("timezone")
        parsed_date = parsed_rec_start or get_user_today(timezone)

    # Re-serialize the final dates/times for the backend op (the op accepts
    # ISO strings and normalises internally; we pass the validated forms
    # back so auto-populated / auto-filled values flow through).
    final_scheduled_date = parsed_date.isoformat() if isinstance(parsed_date, date) else scheduled_date

    # Sanitize text fields (matches REST _strip_control_chars)
    clean_title = strip_control_chars(title).strip()
    clean_desc = strip_control_chars(description) if description else description

    try:
        payload = await backend.create_task(
            user_id,
            title=clean_title,
            domain_id=domain_id,
            impact=impact,
            clarity=clarity,
            duration_minutes=effective_duration,
            scheduled_date=final_scheduled_date,
            scheduled_time=scheduled_time,
            description=clean_desc,
            parent_id=parent_id,
            is_recurring=is_recurring,
            recurrence_rule=parsed_rule,
            recurrence_start=recurrence_start,
            recurrence_end=recurrence_end,
            reminder_minutes_before=reminder_minutes_before,
        )
    except ValueError as e:
        return str(e)
    except Exception as e:  # noqa: BLE001 — sqlalchemy.exc handled below
        # Lazy-resolve SQLAlchemy exceptions so the standalone wheel does
        # not pay the SQLAlchemy import cost (it never raises these on
        # the httpx-backed stdio path; the catches matter only on cloud).
        _IntegrityError, _DBAPIError = resolve_sqlalchemy_exc_classes()
        if isinstance(e, _IntegrityError):
            # WHENFUL-34: hard-deleted user passing auth → FK violation.
            # Type-only log; clean in-band string with NO `str(e)` (the
            # bound parameters live there). Background: PR #1534.
            logger.warning(
                "MCP create_task hit IntegrityError for user %d: %s (likely deleted user)",
                user_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return "Could not create task — your account is no longer available. Please re-authenticate."
        if isinstance(e, _DBAPIError):
            # WHENFUL-33: statement timeout / deadlock during INSERT.
            logger.warning(
                "MCP create_task hit DBAPIError for user %d: %s",
                user_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return "Task creation failed due to a transient database issue. Please retry."
        # Anything else propagates so ``guard_db_errors`` (above) catches
        # it with the leak-defended generic surface.
        raise

    task_id = payload["id"]
    task_title = payload.get("title") or ""
    logger.info(f"MCP create_task: task_id={task_id} user_id={user_id} recurring={is_recurring}")

    result = f"Created task [id:{task_id}]: {task_title}"
    if is_recurring:
        # The op materializes instances internally and fires bulk GCal sync;
        # ``instance_count`` carries the number of TaskInstances landed on
        # the schedule (see ``_DBBackend.create_task`` and the REST
        # ``POST /tasks`` endpoint). When absent or ``None`` — old payloads
        # or non-recurring cross-talk — fall back to the bare ``(recurring)``
        # suffix rather than fabricating a zero.
        materialized = payload.get("instance_count")
        if isinstance(materialized, int):
            result += f" (recurring, {materialized} instances created)"
        else:
            result += " (recurring)"
    return result


@guard_db_errors("update_task")
async def update_task(
    backend: Backend,
    user_id: int,
    task_id: int,
    title: str | None = None,
    domain: str | None = None,
    impact: int | None = None,
    clarity: str | None = None,
    duration_minutes: int | None = None,
    scheduled_date: str | None = None,
    scheduled_time: str | None = None,
    description: str | None = None,
    parent_id: int | None = None,
    is_recurring: bool | None = None,
    recurrence_rule: str | None = None,
    recurrence_start: str | None = None,
    recurrence_end: str | None = None,
    position: int | None = None,
    reminder_minutes_before: int | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate inputs (mirrors REST Pydantic validation)
    validation_error = validate_task_fields(
        title=title,
        impact=impact,
        clarity=clarity,
        duration_minutes=duration_minutes,
        reminder_minutes_before=reminder_minutes_before,
        description=description,
    )
    if validation_error:
        return validation_error

    # Build the kwargs dict the op accepts. The op normalizes ISO strings
    # for scheduled_date / recurrence_start / recurrence_end / scheduled_time
    # internally, so the tool only validates them here for error messages.
    #
    # NOTE: state-sync defenses that previously lived in the tool layer
    # (reminder_sent_at reset on schedule change, scheduled_date <->
    # recurrence_start sync, duration auto-fill, recurrence lifecycle
    # regeneration) now live inside ``_DBBackend.update_task`` so both
    # transports (HTTP + stdio) honour them symmetrically. The tool layer's
    # job is reduced to wire-format validation.
    kwargs: dict[str, Any] = {}
    if title is not None:
        kwargs["title"] = strip_control_chars(title).strip()
    if impact is not None:
        kwargs["impact"] = impact
    if clarity is not None:
        kwargs["clarity"] = clarity
    if duration_minutes is not None:
        kwargs["duration_minutes"] = duration_minutes
    if description is not None:
        kwargs["description"] = strip_control_chars(description) if description else None  # empty string clears
    if parent_id is not None:
        kwargs["parent_id"] = parent_id if parent_id != 0 else None
    if is_recurring is not None:
        kwargs["is_recurring"] = is_recurring
    if recurrence_rule is not None:
        # Schema-layer validation: mirror create_task's structural check.
        # See ``_validate_recurrence_rule`` (the D6 R5 / PR #1594 defense
        # extended into the MCP write surface).
        validated_rule, err = _validate_recurrence_rule(recurrence_rule)
        if err:
            return err
        kwargs["recurrence_rule"] = validated_rule
    if recurrence_start is not None:
        if recurrence_start:
            parsed_rs = parse_date(recurrence_start, "recurrence_start")
            if isinstance(parsed_rs, str):
                return parsed_rs
            kwargs["recurrence_start"] = recurrence_start  # op accepts ISO string
        else:
            kwargs["recurrence_start"] = None
    if recurrence_end is not None:
        if recurrence_end:
            parsed_re = parse_date(recurrence_end, "recurrence_end")
            if isinstance(parsed_re, str):
                return parsed_re
            kwargs["recurrence_end"] = recurrence_end
        else:
            kwargs["recurrence_end"] = None
    if position is not None:
        kwargs["position"] = position
    if reminder_minutes_before is not None:
        kwargs["reminder_minutes_before"] = reminder_minutes_before

    if domain is not None:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error.replace(". Available:", ".").split(".")[0] + "."  # keep "not found." message stable
        kwargs["domain_id"] = resolved

    if scheduled_date is not None:
        if scheduled_date:
            parsed_sd = parse_date(scheduled_date, "scheduled_date")
            if isinstance(parsed_sd, str):
                return parsed_sd
            kwargs["scheduled_date"] = scheduled_date
        else:
            kwargs["scheduled_date"] = None

    if scheduled_time is not None:
        if scheduled_time:
            parsed_st = parse_time(scheduled_time, "scheduled_time")
            if isinstance(parsed_st, str):
                return parsed_st
            kwargs["scheduled_time"] = scheduled_time
        else:
            kwargs["scheduled_time"] = None

    if not kwargs:
        return "Nothing to update -- provide at least one field."

    try:
        payload = await backend.update_task(user_id, task_id, **kwargs)
    except ValueError as e:
        return str(e)
    except Exception as e:  # noqa: BLE001 — sqlalchemy.exc handled below
        _IntegrityError, _DBAPIError = resolve_sqlalchemy_exc_classes()
        if isinstance(e, _DBAPIError):
            # WHENFUL-33 protection (mirrors PR #1532): type-only log,
            # clean retryable message, NO `str(e)` in the response.
            logger.warning(
                "MCP update_task hit DBAPIError for user %d task %d: %s",
                user_id,
                task_id,
                type(e.orig).__name__ if e.orig else type(e).__name__,  # type: ignore[attr-defined]
            )
            return f"Task {task_id} update timed out due to database contention. Please retry in a moment."
        # IntegrityError or anything else propagates to ``guard_db_errors``.
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."

    title_out = payload.get("title") or ""
    return f"Updated task [id:{task_id}]: {title_out}"


@guard_db_errors("complete_task")
async def complete_task(backend: Backend, user_id: int, task_id: int) -> str:
    try:
        payload = await backend.complete_task(user_id, task_id)
    except ValueError as exc:
        # Sentinel from _DBBackend.complete_task when the task is recurring.
        if str(exc) == "recurring":
            return (
                f"Task {task_id} is recurring — cannot complete directly. "
                "Use complete_instance to complete a specific instance, "
                "or use get_schedule to find instance IDs."
            )
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP complete_task: task_id={task_id} user_id={user_id}")
    return f"Completed task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


@guard_db_errors("uncomplete_task")
async def uncomplete_task(backend: Backend, user_id: int, task_id: int) -> str:
    try:
        payload = await backend.uncomplete_task(user_id, task_id)
    except ValueError as exc:
        if str(exc) == "recurring":
            return (
                f"Task {task_id} is recurring — use uncomplete_instance to undo a specific instance completion instead."
            )
        raise
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP uncomplete_task: task_id={task_id} user_id={user_id}")
    return f"Uncompleted task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)} — now pending"


@guard_db_errors("toggle_complete")
async def toggle_complete(
    backend: Backend,
    user_id: int,
    task_id: int,
    target_date: str | None = None,
) -> str:
    # Validate target_date here (operation accepts ISO string).
    if target_date:
        parsed = parse_date(target_date, "target_date")
        if isinstance(parsed, str):
            return parsed

    payload = await backend.toggle_complete(user_id, task_id, target_date=target_date)
    if payload is None:
        return f"Task {task_id} not found or not owned by you."

    completed = bool(payload.get("completed"))
    instance_id = payload.get("instance_id")
    if instance_id is not None:
        td = payload.get("target_date")
        return (
            f"{'Completed' if completed else 'Uncompleted'} instance [inst:{instance_id}] "
            f"of task [id:{task_id}] for {td}"
        )

    encrypted = await is_encrypted(backend, user_id)
    # The op already includes the task in the payload via title field; if not,
    # fall back via get_task.
    title_value = payload.get("title")
    if title_value is None:
        # Re-fetch for title (handles backends that don't include title in toggle response)
        task_payload = await backend.get_task(user_id, task_id)
        if task_payload is not None:
            title_value = task_payload.get("title")
    title = safe_title(title_value, encrypted)
    return f"{'Completed' if completed else 'Uncompleted'} task [id:{task_id}]: {title}"


async def get_task(backend: Backend, user_id: int, task_id: int) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    d = await backend.get_task(user_id, task_id)
    if d is None:
        return f"Task {task_id} not found or not owned by you."

    lines = [f"Task [id:{task_id}]: {d['title']}"]
    lines.append(f"  status: {d['status']}")
    if d.get("description"):
        lines.append(f"  description: {d['description']}")
    if d.get("domain_name"):
        lines.append(f"  domain: {d['domain_name']} (id:{d.get('domain_id')})")
    if d.get("parent_id"):
        lines.append(f"  parent: [id:{d['parent_id']}] (subtask)")
    lines.append(f"  impact: {IMPACT_LABELS.get(d.get('impact', 4), '?')} ({d.get('impact')})")
    lines.append(f"  clarity: {d.get('clarity', 'normal')}")
    if d.get("duration_minutes"):
        lines.append(f"  duration: {d['duration_minutes']}m")
    if d.get("scheduled_date"):
        sched = str(d["scheduled_date"])
        if d.get("scheduled_time"):
            sched += f" {d['scheduled_time']}"
        lines.append(f"  scheduled: {sched}")
    lines.append(f"  recurring: {d.get('is_recurring', False)}")
    if d.get("is_recurring") and d.get("recurrence_rule"):
        lines.append(f"  recurrence_rule: {json.dumps(d['recurrence_rule'])}")
        if d.get("recurrence_start"):
            lines.append(f"  recurrence_start: {d['recurrence_start']}")
        if d.get("recurrence_end"):
            lines.append(f"  recurrence_end: {d['recurrence_end']}")
    if d.get("reminder_minutes_before") is not None:
        lines.append(f"  reminder: {d['reminder_minutes_before']}m before")
    if d.get("position") is not None:
        lines.append(f"  position: {d['position']}")
    if d.get("completed_at"):
        lines.append(f"  completed_at: {d['completed_at']}")
    if d.get("subtasks"):
        lines.append(f"  subtasks ({len(d['subtasks'])}):")
        for sub in d["subtasks"]:
            sub_mark = "x" if sub.get("status") == "completed" else " "
            lines.append(f"    [{sub_mark}] [id:{sub['id']}] {sub['title']}")

    return "\n".join(lines)


@guard_db_errors("nuke_task")
async def nuke_task(backend: Backend, user_id: int, task_id: int) -> str:
    nuked = await backend.nuke_task(user_id, task_id)
    if not nuked:
        return f"Task {task_id} not found or not owned by you."
    logger.info(f"MCP nuke_task: task_id={task_id} user_id={user_id}")
    return f"Permanently destroyed task [id:{task_id}]"


@guard_db_errors("archive_task")
async def archive_task(backend: Backend, user_id: int, task_id: int) -> str:
    payload = await backend.archive_task(user_id, task_id)
    if payload is None:
        return f"Task {task_id} not found or not owned by you."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP archive_task: task_id={task_id} user_id={user_id}")
    return f"Archived task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


@guard_db_errors("restore_task")
async def restore_task(backend: Backend, user_id: int, task_id: int) -> str:
    payload = await backend.restore_task(user_id, task_id)
    if payload is None:
        return f"Task {task_id} not found, not owned by you, or not archived."
    encrypted = await is_encrypted(backend, user_id)
    logger.info(f"MCP restore_task: task_id={task_id} user_id={user_id}")
    return f"Restored task [id:{task_id}]: {safe_title(payload.get('title'), encrypted)}"


async def get_archived_tasks(
    backend: Backend,
    user_id: int,
    domain: str | None = None,
    limit: int = 50,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    domain_id = None
    if domain:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return error
        domain_id = resolved

    # Exclude domain-less inbox items unless caller asked for a specific
    # domain — archived thoughts belong in a dedicated triage view, not
    # the archived-work surface. (The backend op enforces this filter.)
    tasks = await backend.get_archived_tasks(user_id, domain_id=domain_id, limit=limit)

    if not tasks:
        return "No archived tasks found."

    lines = [format_task(t) for t in tasks]
    return f"{len(tasks)} archived task(s):\n\n" + "\n".join(lines)


async def search_tasks(
    backend: Backend,
    user_id: int,
    query: str,
    include_completed: bool = False,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    if not query or not query.strip():
        return "Search query cannot be empty."

    tasks = await backend.search_tasks(user_id, query=query, include_completed=include_completed)

    if not tasks:
        return f"No tasks matching '{query}'."

    lines = [format_task(t) for t in tasks]
    return f"{len(tasks)} task(s) matching '{query}':\n\n" + "\n".join(lines)


@guard_db_errors("batch_create_tasks")
async def batch_create_tasks(backend: Backend, user_id: int, tasks_json: str) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    try:
        tasks_list = json.loads(tasks_json)
    except json.JSONDecodeError as e:
        return f"Invalid JSON: {e}"

    if not isinstance(tasks_list, list):
        return "Expected a JSON array of task objects."

    # Build the canonical list[dict] payload + per-item validation errors.
    # Domain-name resolution happens here so the operation only sees
    # domain_id (int). Per-item validation echoes the create_task semantics.
    domains = await backend.list_domains(user_id)
    domain_map: dict[str, int] = {d["name"].lower(): int(d["id"]) for d in domains if isinstance(d.get("name"), str)}
    available = ", ".join(d["name"] for d in domains if isinstance(d.get("name"), str) and not d.get("is_archived"))

    prepared: list[dict[str, Any]] = []
    errors: list[str] = []
    title_by_index: dict[int, str] = {}

    for i, task_data in enumerate(tasks_list):
        if not isinstance(task_data, dict) or "title" not in task_data:
            errors.append(f"Item {i}: missing 'title'")
            continue

        try:
            domain_id = None
            if "domain" in task_data:
                domain_id = domain_map.get(task_data["domain"].lower())
                if domain_id is None:
                    errors.append(f"Item {i}: domain '{task_data['domain']}' not found. Available: {available}")
                    continue

            if task_data.get("scheduled_date"):
                check = parse_date(task_data["scheduled_date"], "scheduled_date")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue
            if task_data.get("scheduled_time"):
                check = parse_time(task_data["scheduled_time"], "scheduled_time")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue

            val_err = validate_task_fields(
                title=task_data["title"],
                impact=task_data.get("impact"),
                clarity=task_data.get("clarity"),
                duration_minutes=task_data.get("duration_minutes"),
                reminder_minutes_before=task_data.get("reminder_minutes_before"),
                description=task_data.get("description"),
            )
            if val_err:
                errors.append(f"Item {i} '{str(task_data['title'])[:30]}': {val_err}")
                continue

            # Parse + structurally validate recurrence rule. Accepts both
            # a JSON string and a dict directly in batch (callers vary).
            # Both shapes go through the same RecurrenceRuleSchema gate as
            # single create_task / update_task — see ``_validate_recurrence_rule``.
            # (Replaces a bare ``json.loads`` that previously accepted invalid
            # weekday codes, week_of_month=0, signed BYDAY tokens, etc.)
            raw_rule = task_data.get("recurrence_rule")
            parsed_rule = None
            if raw_rule is not None:
                rule_str = raw_rule if isinstance(raw_rule, str) else json.dumps(raw_rule)
                parsed_rule, rule_err = _validate_recurrence_rule(rule_str)
                if rule_err:
                    errors.append(f"Item {i}: {rule_err}")
                    continue

            if task_data.get("recurrence_start"):
                check = parse_date(task_data["recurrence_start"], "recurrence_start")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue
            if task_data.get("recurrence_end"):
                check = parse_date(task_data["recurrence_end"], "recurrence_end")
                if isinstance(check, str):
                    errors.append(f"Item {i}: {check}")
                    continue

            is_rec = bool(task_data.get("is_recurring"))
            if is_rec and not parsed_rule:
                errors.append(f"Item {i}: is_recurring=True requires recurrence_rule")
                continue
            if parsed_rule and not is_rec:
                errors.append(f"Item {i}: recurrence_rule provided but is_recurring=False")
                continue

            clean_title = strip_control_chars(str(task_data["title"])).strip()
            clean_desc = (
                strip_control_chars(task_data["description"])
                if task_data.get("description")
                else task_data.get("description")
            )

            item: dict[str, Any] = {
                "title": clean_title,
                "domain_id": domain_id,
                "parent_id": task_data.get("parent_id"),
                "impact": task_data.get("impact", 4),
                "clarity": task_data.get("clarity", "normal"),
                "duration_minutes": task_data.get("duration_minutes"),
                "scheduled_date": task_data.get("scheduled_date"),
                "scheduled_time": task_data.get("scheduled_time"),
                "description": clean_desc,
                "is_recurring": is_rec,
                "recurrence_rule": parsed_rule,
                "recurrence_start": task_data.get("recurrence_start"),
                "recurrence_end": task_data.get("recurrence_end"),
                "reminder_minutes_before": task_data.get("reminder_minutes_before"),
            }
            title_by_index[len(prepared)] = clean_title
            prepared.append(item)
        except ValueError as e:
            errors.append(f"Item {i}: {e}")

    op_result = await backend.batch_create_tasks(user_id, tasks=prepared)
    created_items = op_result.get("created", []) if isinstance(op_result, dict) else []
    op_errors = op_result.get("errors", []) if isinstance(op_result, dict) else []

    # Translate the op's structured error list into the legacy strings.
    for err in op_errors:
        if isinstance(err, dict):
            errors.append(f"Item {err.get('index', '?')}: {err.get('message', 'unknown error')}")

    lines = [f"Created {len(created_items)} task(s):"]
    for c in created_items:
        if isinstance(c, dict):
            lines.append(f"  + [id:{c.get('id')}] {c.get('title', '')}")
    if errors:
        lines.append(f"\n{len(errors)} error(s):")
        for e in errors:
            lines.append(f"  x {e}")

    return "\n".join(lines)


@guard_db_errors("batch_update_tasks")
async def batch_update_tasks(
    backend: Backend,
    user_id: int,
    task_ids: str,
    impact: int | None = None,
    clarity: str | None = None,
    domain: str | None = None,
    status: str | None = None,
) -> str:
    enc_error = await check_encryption(backend, user_id)
    if enc_error:
        return enc_error

    # Validate fields before processing
    validation_error = validate_task_fields(impact=impact, clarity=clarity, status=status)
    if validation_error:
        return validation_error

    try:
        ids = [int(x.strip()) for x in task_ids.split(",") if x.strip()]
    except ValueError:
        return "Invalid task_ids format. Use comma-separated integers (e.g. '1,2,3')."

    if not ids:
        return "No task IDs provided."

    kwargs: dict[str, Any] = {}
    if impact is not None:
        kwargs["impact"] = impact
    if clarity is not None:
        kwargs["clarity"] = clarity
    if status is not None:
        kwargs["status"] = status

    if domain is not None:
        resolved, error = await resolve_domain_via_backend(backend, user_id, domain)
        if error is not None:
            return f"Domain '{domain}' not found."
        kwargs["domain_id"] = resolved

    if not kwargs:
        return "Nothing to update -- provide at least one field."

    op_result = await backend.batch_update_tasks(user_id, task_ids=ids, **kwargs)
    updated = int(op_result.get("updated_count", 0))
    skipped_recurring = list(op_result.get("skipped_recurring", []))
    op_errors = op_result.get("errors", [])
    errors = [f"id:{e.get('id')} {e.get('message', 'failed')}" for e in op_errors if isinstance(e, dict)]
    logger.info(f"MCP batch_update_tasks: updated={updated} errors={len(errors)} user_id={user_id}")

    result = f"Updated {updated} task(s)."
    if skipped_recurring:
        result += f" Skipped {len(skipped_recurring)} recurring task(s) (use complete_instance instead)."
    if errors:
        result += f" {len(errors)} error(s): " + "; ".join(errors)
    return result


@guard_db_errors("batch_complete_tasks")
async def batch_complete_tasks(backend: Backend, user_id: int, task_ids: str) -> str:
    try:
        ids = [int(x.strip()) for x in task_ids.split(",") if x.strip()]
    except ValueError:
        return "Invalid task_ids format. Use comma-separated integers (e.g. '1,2,3')."

    if not ids:
        return "No task IDs provided."

    op_result = await backend.batch_complete_tasks(user_id, task_ids=ids)
    completed = int(op_result.get("completed_count", 0))
    skipped_recurring = list(op_result.get("skipped_recurring", []))
    op_errors = op_result.get("errors", [])
    errors = [f"id:{e.get('id')} {e.get('message', 'failed')}" for e in op_errors if isinstance(e, dict)]
    logger.info(f"MCP batch_complete_tasks: completed={completed} errors={len(errors)} user_id={user_id}")

    result = f"Completed {completed} task(s)."
    if skipped_recurring:
        result += (
            f" Skipped {len(skipped_recurring)} recurring task(s) (use complete_instance instead): {skipped_recurring}"
        )
    if errors:
        result += f" {len(errors)} error(s): " + "; ".join(errors)
    return result


# Re-exported intentionally: future stdio code will not import these directly,
# but linting/test consumers may.
_ = (UTC, date, datetime)
