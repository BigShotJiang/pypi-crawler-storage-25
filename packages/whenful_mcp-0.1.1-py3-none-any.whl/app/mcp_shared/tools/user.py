"""User context MCP tools (transport-agnostic).

Migrated from `app/routers/mcp_server.py` in Phase A of MCP #13534.

Tool count: 2 (whoami, get_preferences).

MCP-stdio full parity migration:
- `whoami` (2026-05-16): routes through the `Backend.whoami` operation
  instead of opening a session and reading the `User` row directly.
  Output string stays byte-identical with the pre-migration SQL path on
  the cloud side; stdio path now produces the same shape via REST.
- `get_preferences` (2026-05-13): already migrated to
  `Backend.get_preferences`.

This module is import-clean — no `app.*` imports outside `app.mcp_shared.*`.
"""

from __future__ import annotations

from . import Backend


async def whoami(backend: Backend, user_id: int) -> str:
    payload = await backend.whoami(user_id)
    # `Backend.whoami` returns an empty dict on a missing user (mirrors
    # WhenfulClient's REST 404 surface) — preserve the historical "not found"
    # message in that case.
    if not payload or "email" not in payload:
        return f"Authenticated as user_id={user_id} but user not found in database!"

    email = payload.get("email") or ""
    name = payload.get("name") or email
    data_version = payload.get("data_version")

    return f"user_id: {user_id}\nemail: {email}\nname: {name}\ndata_version: {data_version}"


async def get_preferences(backend: Backend, user_id: int) -> str:
    prefs = await backend.get_preferences(user_id)

    timezone = prefs.get("timezone")
    secondary_timezone = prefs.get("secondary_timezone")
    lines = ["User preferences:"]
    lines.append(f"  timezone: {timezone or 'not set'}")
    if secondary_timezone:
        lines.append(f"  secondary_timezone: {secondary_timezone}")
    lines.append(f"  show_completed_in_planner: {prefs.get('show_completed_in_planner', False)}")
    lines.append(f"  completed_retention_days: {prefs.get('completed_retention_days', 0)}")
    lines.append(f"  show_completed_in_list: {prefs.get('show_completed_in_list', False)}")
    lines.append(f"  show_scheduled_in_list: {prefs.get('show_scheduled_in_list', False)}")
    lines.append(f"  time_format: {prefs.get('time_format', '24h')}")
    lines.append(f"  encryption_enabled: {prefs.get('encryption_enabled', False)}")

    return "\n".join(lines)
