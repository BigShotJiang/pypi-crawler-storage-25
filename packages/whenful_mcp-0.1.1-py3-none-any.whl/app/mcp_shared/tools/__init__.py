"""MCP tool implementations, grouped by resource.

Each module re-exports its public tool functions. Tools take `backend: Backend`
and `user_id: int` as their first two arguments — see
`app/mcp_shared/__init__.py` for the protocol contract.

Encryption helpers (`check_encryption`, `is_encrypted_in_session`) live here
rather than in `mcp_shared.formatters` because they query the data layer
(via the supplied session) rather than purely formatting strings.

This is Phase A of MCP #13534. The HTTP server is the only consumer today;
the future stdio client will import the same tool functions and supply its
own `Backend` implementation.
"""

from __future__ import annotations

from typing import Any

from .. import Backend


async def is_encrypted_in_session(db: Any, user_id: int) -> bool:
    """Check encryption status using an existing DB session.

    Avoids the extra connection cost of opening a fresh session — used by
    tools that already hold a session and need a quick yes/no check (e.g.,
    to decide whether `safe_title` should redact).

    **Cloud-only path.** This fallback exists for callers that monkey-patch
    the session machinery in tests; the production path goes through
    ``is_encrypted`` → ``backend.whoami``. The SQLAlchemy + ORM imports are
    function-scoped so the import-clean rule for ``app.mcp_shared`` holds —
    the standalone stdio wheel can't import ``app.models`` and never calls
    this function (its ``session()`` yields the client, not a real DB).
    """
    # Lazy imports keep the top-level module clean for the PyPI wheel.
    from sqlalchemy import select

    from app.models import UserPreferences

    result = await db.execute(select(UserPreferences.encryption_enabled).where(UserPreferences.user_id == user_id))
    return bool(result.scalar_one_or_none())


async def is_encrypted(backend: Backend, user_id: int) -> bool:
    """Quick check if user has E2E encryption enabled.

    Uses the ``whoami`` Backend operation so both transports answer
    symmetrically: the HTTP backend's ``whoami`` runs a SELECT through
    ``backend.session()``, the stdio backend's hits ``GET /me``. Falls
    back to a raw SELECT through ``backend.session()`` if ``whoami``
    fails — preserves the pre-operations behavior for any caller that
    monkey-patches the session machinery in tests.
    """
    try:
        payload = await backend.whoami(user_id)
        if isinstance(payload, dict) and "encryption_enabled" in payload:
            return bool(payload["encryption_enabled"])
    except Exception:  # noqa: BLE001 — fallback to legacy path
        pass
    async with backend.session() as db:
        return await is_encrypted_in_session(db, user_id)


async def resolve_domain_via_backend(
    backend: Backend,
    user_id: int,
    name: str,
) -> tuple[int | None, str | None]:
    """Resolve a domain name (case-insensitive) to a domain_id via the
    Backend's ``list_domains`` operation.

    Returns ``(domain_id, None)`` on success or ``(None, error_message)``
    when the name is unknown. The error message lists available (non-
    archived) domain names so the LLM can correct itself.

    Routed through ``backend.list_domains`` so the stdio path (which
    decrypts domain names client-side) and the HTTP path (which reads
    them straight from the ORM) both work.
    """
    domains = await backend.list_domains(user_id)
    match = next(
        (d for d in domains if isinstance(d.get("name"), str) and d["name"].lower() == name.lower()),
        None,
    )
    if match is not None:
        return int(match["id"]), None
    available = ", ".join(d["name"] for d in domains if isinstance(d.get("name"), str) and not d.get("is_archived"))
    return None, f"Domain '{name}' not found. Available: {available}"


async def check_encryption(backend: Backend, user_id: int) -> str | None:
    """Check if user has E2E encryption enabled. Returns error message or None.

    HTTP server uses this as a guard at the top of any tool that reads or
    writes encrypted columns (title/description/domain.name) — those tools
    can't function under encryption today because the server doesn't hold
    the key. The error string is the user-facing explanation; it must stay
    stable because Claude/Claude Desktop surface it directly.

    Bypassed entirely when the backend reports client-side crypto capability
    (``backend.supports_client_side_crypto()`` → True). That's the stdio
    path (``mcp_stdio.WhenfulClient``) with a ``CryptoManager`` loaded — the
    user supplied their passphrase during ``whenful-mcp setup``, so the
    client encrypts on write and decrypts on read before handing plaintext
    to the LLM. Encryption-on Pro users actually CAN use every MCP tool
    through their local install — without this bypass the shared gate
    inherited the cloud limitation as if it were universal, blocking the
    exact user segment the wheel was built for.

    Routed through ``is_encrypted`` so the stdio path (which has no
    ``UserPreferences`` SQL surface) resolves via ``whoami``.
    """
    if backend.supports_client_side_crypto():
        return None
    if await is_encrypted(backend, user_id):
        return (
            "E2E encryption is enabled on your account. MCP tools cannot read or write "
            "encrypted data (task titles, descriptions, domain names are ciphertext on the server). "
            "Disable E2E encryption in whenful Settings to use MCP integration."
        )
    return None


__all__ = [
    "Backend",
    "check_encryption",
    "is_encrypted",
    "is_encrypted_in_session",
    "resolve_domain_via_backend",
]
