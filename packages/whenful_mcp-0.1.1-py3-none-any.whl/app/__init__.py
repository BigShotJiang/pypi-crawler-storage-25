"""Synthetic ``app/__init__.py`` for the standalone ``whenful-mcp`` wheel.

The monorepo's ``app/__init__.py`` reads ``pyproject.toml`` at import
time and imports ``importlib.metadata.version("whenful")`` — neither of
which makes sense inside the standalone wheel where:

* ``pyproject.toml`` for the *monorepo* is not shipped (only the wheel's
  own pyproject.toml is, and it's named ``whenful-mcp``, not ``whenful``).
* The wheel intentionally has no app-level Python code beyond
  ``app.mcp_shared``.

Hatch's ``force-include`` table copies this file in as ``app/__init__.py``
so the ``app`` package exists as a thin namespace, just enough for
``import app.mcp_shared`` to resolve. End users never import ``app``
directly.
"""
