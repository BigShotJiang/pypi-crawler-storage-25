"""sync-transactions: sync Accurate transactional data into Odoo.

Seven sync operations in order:
  1. Purchase Requests       → purchase.request
  2. Purchase Orders         → purchase.order
  3. Purchase Invoices       → account.move (in_invoice)
  4. Purchase Payments       → account.payment (outbound)
  5. Receive Items           → logged only (stock.picking creation is complex)
  6. Sales Invoices          → account.move (out_invoice)
  7. Sales Receipts          → account.payment (inbound)

Each operation deduplicates before creating — idempotent.
"""

from __future__ import annotations

from typing import Annotated, Any

import httpx
import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import (
    accurate_date_to_odoo,
    ar_account_for_currency,
    create_accurate_client,
    goods_in_transit_account,
    resolve_account_by_code,
    resolve_account_by_name,
    resolve_currency_by_code,
    resolve_partner_by_ref,
    resolve_product_by_code,
    resolve_uom_by_name,
    write_audit_file,
)

# ---------------------------------------------------------------------------
# Counter
# ---------------------------------------------------------------------------


class _Counter:
    def __init__(self) -> None:
        self.created = 0
        self.skipped = 0
        self.errors = 0

    def to_row(self, section: str) -> list[str]:
        return [
            section,
            str(self.created),
            str(self.skipped),
            str(self.errors),
        ]


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


TRANSACTION_ENTITIES = (
    "purchase-request",
    "purchase-order",
    "purchase-invoice",
    "purchase-payment",
    "receive-item",
    "sales-invoice",
    "sales-receipt",
    "journal-voucher",
    "all-journals",
    "bank-transfer",
    "other-payment",
    "other-deposit",
    "expense",
    "sales-order",
    "sales-return",
    "purchase-return",
    "item-adjustment",
    "item-transfer",
    "validate-journals",
)


def sync_transactions(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name (e.g. terra-buah-internusa)")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
    include: Annotated[
        str | None,
        typer.Option(
            "--include", "-i", help=f"Comma-separated entities ({','.join(TRANSACTION_ENTITIES)}). Default: all."
        ),
    ] = None,
    since: Annotated[str | None, typer.Option("--since", help="Filter records on/after this date (YYYY-MM-DD)")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without making changes")] = False,
) -> None:
    """Sync Accurate transactional data into Odoo.

    Sync operations:
       1. purchase-request   → purchase.request
       2. purchase-order     → purchase.order  (confirmed after create)
       3. purchase-invoice   → account.move    (in_invoice)
       4. purchase-payment   → account.payment (outbound)
       5. receive-item       → logged only (stock.picking creation is complex)
       6. sales-invoice      → account.move    (out_invoice)
       7. sales-receipt      → account.payment (inbound)
       8. journal-voucher    → account.move    (general entry, via detailItem)
       8b. all-journals     → account.move    (JV-driven: exact GL from detailJournalVoucher)
       9. bank-transfer      → account.move    (bank transfer entry)
      10. other-payment      → account.move    (other payment entry)
      11. other-deposit      → account.move    (other deposit entry)
      12. expense            → account.move    (expense entry)
      13. sales-order        → sale.order      (confirmed)
      14. sales-return       → account.move    (out_refund credit note)
      15. purchase-return    → account.move    (in_refund vendor credit)
      16. item-adjustment    → logged only (stock adjustment is complex)
      17. item-transfer      → logged only (stock.picking creation is complex)

    Use --include to sync specific entities:
      --include purchase-order
      --include purchase-invoice,purchase-payment

    Each operation is idempotent — existing records (matched by origin/ref/name)
    are skipped.  Use --dry-run to preview without writing.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Extend timeout for large Accurate list + detail calls
    try:
        c._client.timeout = httpx.Timeout(1800.0)
    except (AttributeError, TypeError):
        pass

    dry_label = " (DRY-RUN)" if dry_run else ""
    since_label = f"  since={since}" if since else ""
    out.header(f"sync-transactions: profile={profile!r}  odoo_company={odoo_company}{since_label}{dry_label}")

    selected = set(include.split(",")) if include else set(TRANSACTION_ENTITIES)
    invalid = selected - set(TRANSACTION_ENTITIES)
    if invalid:
        out.error(f"Unknown entities: {', '.join(invalid)}. Valid: {', '.join(TRANSACTION_ENTITIES)}")
        raise typer.Exit(1)

    acc_client = create_accurate_client(profile)

    summary_rows: list[list[str]] = []
    all_audit: dict[str, list[dict[str, Any]]] = {}

    # -------------------------------------------------------------------
    # Step 1: Purchase Requests
    # -------------------------------------------------------------------
    if "purchase-request" in selected:
        out.info("Syncing purchase-request → purchase.request...")
        pr_ctr, pr_audit = _step_purchase_requests(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(pr_ctr.to_row("purchase-request"))
        all_audit["purchase_requests"] = pr_audit

    # -------------------------------------------------------------------
    # Step 2: Purchase Orders
    # -------------------------------------------------------------------
    if "purchase-order" in selected:
        out.info("Syncing purchase-order → purchase.order...")
        po_ctr, po_audit = _step_purchase_orders(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(po_ctr.to_row("purchase-order"))
        all_audit["purchase_orders"] = po_audit

    # -------------------------------------------------------------------
    # Step 3: Purchase Invoices (Vendor Bills)
    # -------------------------------------------------------------------
    if "purchase-invoice" in selected:
        out.info("Syncing purchase-invoice → account.move (in_invoice)...")
        pi_ctr, pi_audit = _step_purchase_invoices(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(pi_ctr.to_row("purchase-invoice"))
        all_audit["purchase_invoices"] = pi_audit

    # -------------------------------------------------------------------
    # Step 4: Purchase Payments
    # -------------------------------------------------------------------
    if "purchase-payment" in selected:
        out.info("Syncing purchase-payment → account.payment (outbound)...")
        pp_ctr, pp_audit = _step_purchase_payments(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(pp_ctr.to_row("purchase-payment"))
        all_audit["purchase_payments"] = pp_audit

    # -------------------------------------------------------------------
    # Step 5: Receive Items
    # -------------------------------------------------------------------
    if "receive-item" in selected:
        out.info("Syncing receive-item → stock.picking (with lot/container numbers)...")
        ri_ctr, ri_audit = _step_receive_items(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(ri_ctr.to_row("receive-item"))
        all_audit["receive_items"] = ri_audit

    # -------------------------------------------------------------------
    # Step 6: Sales Invoices
    # -------------------------------------------------------------------
    if "sales-invoice" in selected:
        out.info("Syncing sales-invoice → account.move (out_invoice)...")
        si_ctr, si_audit = _step_sales_invoices(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(si_ctr.to_row("sales-invoice"))
        all_audit["sales_invoices"] = si_audit

    # -------------------------------------------------------------------
    # Step 7: Sales Receipts
    # -------------------------------------------------------------------
    if "sales-receipt" in selected:
        out.info("Syncing sales-receipt → account.payment (inbound)...")
        sr_ctr, sr_audit = _step_sales_receipts(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(sr_ctr.to_row("sales-receipt"))
        all_audit["sales_receipts"] = sr_audit

    # -------------------------------------------------------------------
    # Step 8: Journal Vouchers
    # -------------------------------------------------------------------
    if "journal-voucher" in selected:
        out.info("Syncing journal-voucher → account.move (general entry)...")
        jv_ctr, jv_audit = _step_journal_vouchers(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(jv_ctr.to_row("journal-voucher"))
        all_audit["journal_vouchers"] = jv_audit

    # -------------------------------------------------------------------
    # Step 8b: All Journals (JV-driven — exact GL from detailJournalVoucher)
    # -------------------------------------------------------------------
    if "all-journals" in selected:
        out.info("Syncing all-journals → account.move (JV-driven, exact GL lines)...")
        aj_ctr, aj_audit = _step_journal_vouchers_full(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(aj_ctr.to_row("all-journals"))
        all_audit["all_journals"] = aj_audit

    # -------------------------------------------------------------------
    # Step 9: Bank Transfers
    # -------------------------------------------------------------------
    if "bank-transfer" in selected:
        out.info("Syncing bank-transfer → account.move (transfer entry)...")
        bt_ctr, bt_audit = _step_bank_transfers(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(bt_ctr.to_row("bank-transfer"))
        all_audit["bank_transfers"] = bt_audit

    # -------------------------------------------------------------------
    # Step 10: Other Payments
    # -------------------------------------------------------------------
    if "other-payment" in selected:
        out.info("Syncing other-payment → account.move (other payment)...")
        op_ctr, op_audit = _step_other_payments(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(op_ctr.to_row("other-payment"))
        all_audit["other_payments"] = op_audit

    # -------------------------------------------------------------------
    # Step 11: Other Deposits
    # -------------------------------------------------------------------
    if "other-deposit" in selected:
        out.info("Syncing other-deposit → account.move (other deposit)...")
        od_ctr, od_audit = _step_other_deposits(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(od_ctr.to_row("other-deposit"))
        all_audit["other_deposits"] = od_audit

    # -------------------------------------------------------------------
    # Step 12: Expenses
    # -------------------------------------------------------------------
    if "expense" in selected:
        out.info("Syncing expense → account.move (expense entry)...")
        exp_ctr, exp_audit = _step_expenses(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(exp_ctr.to_row("expense"))
        all_audit["expenses"] = exp_audit

    # -------------------------------------------------------------------
    # Step 13: Sales Orders
    # -------------------------------------------------------------------
    if "sales-order" in selected:
        out.info("Syncing sales-order → sale.order...")
        so_ctr, so_audit = _step_sales_orders(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(so_ctr.to_row("sales-order"))
        all_audit["sales_orders"] = so_audit

    # -------------------------------------------------------------------
    # Step 14: Sales Returns
    # -------------------------------------------------------------------
    if "sales-return" in selected:
        out.info("Syncing sales-return → account.move (out_refund)...")
        sret_ctr, sret_audit = _step_sales_returns(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(sret_ctr.to_row("sales-return"))
        all_audit["sales_returns"] = sret_audit

    # -------------------------------------------------------------------
    # Step 15: Purchase Returns
    # -------------------------------------------------------------------
    if "purchase-return" in selected:
        out.info("Syncing purchase-return → account.move (in_refund)...")
        pret_ctr, pret_audit = _step_purchase_returns(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(pret_ctr.to_row("purchase-return"))
        all_audit["purchase_returns"] = pret_audit

    # -------------------------------------------------------------------
    # Step 16: Item Adjustments (log only)
    # -------------------------------------------------------------------
    if "item-adjustment" in selected:
        out.info("Syncing item-adjustment (log only — stock adjustment deferred)...")
        ia_ctr, ia_audit = _step_item_adjustments(acc_client, since, out)
        summary_rows.append(ia_ctr.to_row("item-adjustment"))
        all_audit["item_adjustments"] = ia_audit

    # -------------------------------------------------------------------
    # Step 17: Item Transfers (log only)
    # -------------------------------------------------------------------
    if "item-transfer" in selected:
        out.info("Syncing item-transfer (log only — stock.picking creation deferred)...")
        it_ctr, it_audit = _step_item_transfers(acc_client, since, out)
        summary_rows.append(it_ctr.to_row("item-transfer"))
        all_audit["item_transfers"] = it_audit

    # -------------------------------------------------------------------
    # Step 18: Validate Journals (compare Odoo GL vs Accurate JVs, fix mismatches)
    # -------------------------------------------------------------------
    if "validate-journals" in selected:
        out.info("Validating Odoo journal entries against Accurate JVs...")
        vj_ctr, vj_audit = _step_validate_journals(c, acc_client, odoo_company, since, dry_run, out)
        summary_rows.append(vj_ctr.to_row("validate-journals"))
        all_audit["validate_journals"] = vj_audit

    # -------------------------------------------------------------------
    # Audit file
    # -------------------------------------------------------------------
    audit_path = write_audit_file(profile, "transactions", [all_audit])
    out.info(f"Audit written to: {audit_path}")

    # -------------------------------------------------------------------
    # Summary table
    # -------------------------------------------------------------------
    out.table(
        f"sync-transactions summary{dry_label}",
        [
            ("Entity", ""),
            ("Created", "green"),
            ("Skipped", "dim"),
            ("Errors", "red"),
        ],
        summary_rows,
    )


# ---------------------------------------------------------------------------
# Step helpers
# ---------------------------------------------------------------------------


def _list_params(since: str | None) -> dict[str, Any]:
    """Build Accurate list params, optionally filtering by date."""
    params: dict[str, Any] = {}
    if since:
        params["filter.date.from"] = since
    return params


# ---------------------------------------------------------------------------
# Step 1: Purchase Requests → purchase.request
# ---------------------------------------------------------------------------


def _step_purchase_requests(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching purchase requisitions from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/purchase-requisition/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No purchase requisitions found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} purchase requisitions...")
    details = acc_client.detail_many("/accurate/api/purchase-requisition/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching PR id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        pr_number: str = str(detail.get("number", "")).strip()
        if not pr_number:
            ctr.skipped += 1
            continue

        # Dedup check
        existing = c.search(
            "purchase.request",
            [["name", "=", pr_number], ["company_id", "=", odoo_company]],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "pr_number": pr_number})
            continue

        pr_date_raw: str = str(detail.get("date", "") or "").strip()
        pr_date: str = accurate_date_to_odoo(pr_date_raw) if pr_date_raw else ""

        # Lines
        lines_data = detail.get("detailItem") or []
        line_vals: list[dict[str, Any]] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None

            uom_data = line.get("unit") or {}
            uom_name: str = str(uom_data.get("name", "CTN")).strip()
            uom_id: int | None = resolve_uom_by_name(c, uom_name)

            qty = float(line.get("quantity", 1.0) or 1.0)

            line_dict: dict[str, Any] = {
                "product_qty": qty,
                "date_required": pr_date or False,
            }
            if product_id:
                line_dict["product_id"] = product_id
            if uom_id:
                line_dict["product_uom_id"] = uom_id

            line_vals.append((0, 0, line_dict))

        vals: dict[str, Any] = {
            "name": pr_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if pr_date:
            vals["date_start"] = pr_date

        if dry_run:
            out.info(f"  [DRY-RUN] Would create purchase request: {pr_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "pr_number": pr_number})
            continue

        try:
            new_id = c.execute_kw("purchase.request", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "pr_number": pr_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create purchase request {pr_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "pr_number": pr_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 2: Purchase Orders → purchase.order
# ---------------------------------------------------------------------------


def _step_purchase_orders(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching purchase orders from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/purchase-order/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No purchase orders found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} purchase orders...")
    details = acc_client.detail_many("/accurate/api/purchase-order/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching PO id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        po_number: str = str(detail.get("number", "")).strip()
        if not po_number:
            ctr.skipped += 1
            continue

        # Dedup check
        existing = c.search(
            "purchase.order",
            [["origin", "=", po_number], ["company_id", "=", odoo_company]],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "po_number": po_number})
            continue

        po_date_raw: str = str(detail.get("date", "") or "").strip()
        po_date: str = accurate_date_to_odoo(po_date_raw) if po_date_raw else ""

        # Vendor
        vendor_data = detail.get("vendor") or {}
        vendor_no: str = str(vendor_data.get("vendorNo", "")).strip()
        vendor_name: str = str(vendor_data.get("name", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, vendor_no) if vendor_no else None
        if partner_id is None and vendor_name:
            # Fallback: search by name
            name_ids = c.search(
                "res.partner",
                [
                    "|",
                    ("company_id", "=", odoo_company),
                    ("company_id", "=", False),
                    ("name", "ilike", vendor_name),
                    ("supplier_rank", ">", 0),
                ],
                limit=1,
            )
            partner_id = name_ids[0] if name_ids else None

        if not partner_id:
            out.error(f"  Cannot resolve vendor for PO {po_number!r} (vendorNo={vendor_no!r}) — skipping.")
            ctr.errors += 1
            audit.append({"action": "skip_no_vendor", "po_number": po_number, "vendor_no": vendor_no})
            continue

        # Currency
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)

        # Lines
        lines_data = detail.get("detailItem") or []
        line_vals: list[dict[str, Any]] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None

            uom_data = line.get("unit") or {}
            uom_name: str = str(uom_data.get("name", "CTN")).strip()
            uom_id: int | None = resolve_uom_by_name(c, uom_name)

            qty = float(line.get("quantity", 1.0) or 1.0)
            price_unit = float(line.get("unitPrice", 0.0) or 0.0)

            line_dict: dict[str, Any] = {
                "product_qty": qty,
                "price_unit": price_unit,
                "taxes_id": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            if uom_id:
                line_dict["product_uom"] = uom_id

            line_vals.append((0, 0, line_dict))

        vals: dict[str, Any] = {
            "origin": po_number,
            "partner_id": partner_id,
            "company_id": odoo_company,
            "order_line": line_vals,
        }
        if po_date:
            vals["date_order"] = po_date
        if currency_id:
            vals["currency_id"] = currency_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create purchase order: {po_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "po_number": po_number})
            continue

        try:
            new_id = c.execute_kw("purchase.order", "create", [vals])
            # Confirm the PO
            try:
                c.execute_kw("purchase.order", "button_confirm", [[new_id]])
            except (RPCError, ConnectionError, ValueError) as exc_confirm:
                out.error(f"  Warning: could not confirm PO {po_number!r}: {exc_confirm}")
            ctr.created += 1
            audit.append({"action": "create", "po_number": po_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create purchase order {po_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "po_number": po_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 3: Purchase Invoices (Vendor Bills) → account.move (in_invoice)
# ---------------------------------------------------------------------------


def _step_purchase_invoices(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching purchase invoices from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/purchase-invoice/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No purchase invoices found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} purchase invoices...")
    details = acc_client.detail_many("/accurate/api/purchase-invoice/detail.do", acc_ids)

    # Pre-fetch goods-in-transit account (inventory item lines)
    git_account_id: int | None = goods_in_transit_account(c, odoo_company)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching PI id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        pi_number: str = str(detail.get("number", "")).strip()
        if not pi_number:
            ctr.skipped += 1
            continue

        # Dedup check
        existing = c.search(
            "account.move",
            [
                ["ref", "=", pi_number],
                ["move_type", "=", "in_invoice"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "pi_number": pi_number})
            continue

        pi_date_raw: str = str(detail.get("date", "") or "").strip()
        pi_date: str = accurate_date_to_odoo(pi_date_raw) if pi_date_raw else ""

        # Vendor
        vendor_data = detail.get("vendor") or {}
        vendor_no: str = str(vendor_data.get("vendorNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, vendor_no) if vendor_no else None

        # Currency + rate
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)
        currency_rate: float = float(detail.get("rate", 1.0) or 1.0)

        # Lines from detailItem
        lines_data = detail.get("detailItem") or []
        line_vals: list[dict[str, Any]] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            item_name: str = str(product_data.get("name", "") or "").strip()
            item_type: str = str(product_data.get("itemType", "INVENTORY")).upper()

            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None

            # Account: inventory → goods-in-transit, service → resolve by GL name
            if item_type in ("INVENTORY", "NON_INVENTORY"):
                account_id = git_account_id
            else:
                gl_data = line.get("glAccount") or product_data.get("inventoryGlAccount") or {}
                gl_name: str = str(gl_data.get("name", "")).strip()
                account_id = (
                    c.search(
                        "account.account", [["company_id", "=", odoo_company], ["name", "ilike", gl_name]], limit=1
                    )
                    if gl_name
                    else None
                )
                if isinstance(account_id, list):
                    account_id = account_id[0] if account_id else None

            qty = float(line.get("quantity", 1.0) or 1.0)
            price_unit = float(line.get("unitPrice", 0.0) or 0.0)

            line_dict: dict[str, Any] = {
                "name": item_name or item_no or "Line Item",
                "quantity": qty,
                "price_unit": price_unit,
                "tax_ids": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            if account_id:
                line_dict["account_id"] = account_id

            line_vals.append((0, 0, line_dict))

        # Additional expense lines from detailExpense (Biaya Lainnya):
        # PPN Masukan, PPh withholding, freight, etc.
        expense_data = detail.get("detailExpense") or []
        if expense_data:
            expense_lines = _build_expense_lines(c, odoo_company, expense_data, out)
            line_vals.extend(expense_lines)
            if expense_lines:
                out.info(f"    PI {pi_number!r}: added {len(expense_lines)} detailExpense line(s)")

        vals: dict[str, Any] = {
            "move_type": "in_invoice",
            "ref": pi_number,
            "company_id": odoo_company,
            "invoice_line_ids": line_vals,
        }
        if partner_id:
            vals["partner_id"] = partner_id
        if pi_date:
            vals["invoice_date"] = pi_date
        if currency_id:
            vals["currency_id"] = currency_id
        # Set exchange rate for foreign currency invoices
        if currency_code != "IDR" and currency_rate != 1.0:
            vals["invoice_currency_rate"] = currency_rate
        # payment_reference = vendor's invoice number (No Faktur #)
        vendor_inv_no = str(detail.get("vendorInvoiceNo", "") or detail.get("invoiceNo", "") or "").strip()
        if vendor_inv_no:
            vals["payment_reference"] = vendor_inv_no
        # narration = description/keterangan
        description = str(detail.get("description", "") or "").strip()
        if description:
            vals["narration"] = description

        if dry_run:
            out.info(f"  [DRY-RUN] Would create vendor bill: {pi_number!r} ({len(line_vals)} lines, {currency_code})")
            ctr.created += 1
            audit.append({"action": "create_dry", "pi_number": pi_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "pi_number": pi_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create vendor bill {pi_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "pi_number": pi_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 4: Purchase Payments → account.payment (outbound)
# ---------------------------------------------------------------------------


def _resolve_journal_by_prefix(c: Any, odoo_company: int, pay_number: str, bank_name: str) -> int | None:
    """Resolve an Odoo bank/cash journal for a payment.

    Resolution order:
    1. Match Accurate bankAccount.name against journal name (ilike).
    2. Match payment number prefix against known journal codes:
       MANDIRI → BMRI, 1000.01 → BCA1 (id 551), 1000.02 → BCA2 (id 552).
    """
    if bank_name:
        journal_ids = c.search(
            "account.journal",
            [
                ["company_id", "=", odoo_company],
                ["name", "ilike", bank_name],
                ["type", "in", ["bank", "cash"]],
            ],
            limit=1,
        )
        if journal_ids:
            return journal_ids[0]

    # Prefix-based fallback — order matters (longer prefixes first)
    for prefix, jcode in [
        ("1000.01", "BCA1"),
        ("1000.02", "BCA2"),
        ("MANDIRI", "BMRI"),
    ]:
        if pay_number.startswith(prefix):
            journal_ids = c.search(
                "account.journal",
                [["company_id", "=", odoo_company], ["code", "=", jcode]],
                limit=1,
            )
            if journal_ids:
                return journal_ids[0]
    return None


def _step_purchase_payments(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching purchase payments from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/purchase-payment/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No purchase payments found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} purchase payments...")
    details = acc_client.detail_many("/accurate/api/purchase-payment/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching payment id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        pay_number: str = str(detail.get("number", "")).strip()
        if not pay_number:
            ctr.skipped += 1
            continue

        # Dedup check — account.payment uses 'memo' in Odoo 18
        existing = c.search(
            "account.payment",
            [
                ["memo", "=", pay_number],
                ["payment_type", "=", "outbound"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "pay_number": pay_number})
            continue

        pay_date_raw: str = str(detail.get("transDate", "") or detail.get("date", "") or "").strip()
        pay_date: str = accurate_date_to_odoo(pay_date_raw) if pay_date_raw else ""

        # Currency
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("code", "") or currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)
        is_foreign = currency_code != "IDR"

        # Journal: resolve by Accurate bankAccount.name then by payment number prefix
        bank_data = detail.get("bankAccount") or {}
        bank_name: str = str(bank_data.get("name", "")).strip()
        journal_id: int | None = _resolve_journal_by_prefix(c, odoo_company, pay_number, bank_name)

        # Find linked Odoo bill via Accurate detailInvoice[0].invoiceNo
        detail_invoices = detail.get("detailInvoice") or []
        linked_bill_id: int | None = None
        if detail_invoices:
            inv_no: str = str(detail_invoices[0].get("invoiceNo", "")).strip()
            if inv_no:
                bill_ids = c.search(
                    "account.move",
                    [
                        ["company_id", "=", odoo_company],
                        ["move_type", "=", "in_invoice"],
                        ["ref", "ilike", inv_no],
                        ["state", "=", "posted"],
                        ["payment_state", "in", ["not_paid", "partial"]],
                    ],
                    limit=1,
                )
                linked_bill_id = bill_ids[0] if bill_ids else None

        # Amount — from detailInvoice[0].paymentAmount for partial/CNY, else totalAmount
        if is_foreign and detail_invoices:
            amount = float(detail_invoices[0].get("paymentAmount", 0.0) or 0.0)
        else:
            amount = float(detail.get("totalAmount", 0.0) or 0.0)
            if amount == 0:
                for inv_detail in detail_invoices:
                    amount += float(inv_detail.get("paymentAmount", 0.0) or 0.0)

        if dry_run:
            out.info(
                f"  [DRY-RUN] Would register purchase payment: {pay_number!r} "
                f"amount={amount} {currency_code} bill_id={linked_bill_id}"
            )
            ctr.created += 1
            audit.append({"action": "create_dry", "pay_number": pay_number})
            continue

        try:
            if linked_bill_id:
                # Use account.payment.register wizard — same as UI Pay button
                wizard_ctx = {
                    "active_model": "account.move",
                    "active_ids": [linked_bill_id],
                }
                wizard_vals: dict[str, Any] = {
                    "communication": pay_number,
                }
                if pay_date:
                    wizard_vals["payment_date"] = pay_date
                if journal_id:
                    wizard_vals["journal_id"] = journal_id
                if is_foreign and currency_id:
                    wizard_vals["currency_id"] = currency_id
                    wizard_vals["amount"] = amount

                wizard_id = c.execute_kw(
                    "account.payment.register",
                    "create",
                    [wizard_vals],
                    {"context": wizard_ctx},
                )
                c.execute_kw(
                    "account.payment.register",
                    "action_create_payments",
                    [[wizard_id]],
                    {"context": wizard_ctx},
                )
                out.info(f"  Registered purchase payment via wizard: {pay_number!r}")
            else:
                # No linked bill — create standalone payment
                vals: dict[str, Any] = {
                    "payment_type": "outbound",
                    "partner_type": "supplier",
                    "amount": amount,
                    "memo": pay_number,
                    "company_id": odoo_company,
                }
                if currency_id:
                    vals["currency_id"] = currency_id
                if journal_id:
                    vals["journal_id"] = journal_id
                if pay_date:
                    vals["date"] = pay_date
                # Resolve vendor for standalone payment
                vendor_data = detail.get("vendor") or {}
                vendor_no: str = str(vendor_data.get("vendorNo", "")).strip()
                partner_id: int | None = resolve_partner_by_ref(c, odoo_company, vendor_no) if vendor_no else None
                if partner_id:
                    vals["partner_id"] = partner_id

                c.execute_kw("account.payment", "create", [vals])
                out.info(f"  Created standalone purchase payment: {pay_number!r} (no linked bill)")

            ctr.created += 1
            audit.append({"action": "create", "pay_number": pay_number, "bill_id": linked_bill_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to register purchase payment {pay_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "pay_number": pay_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 5: Receive Items → validate PO receipts with lots from containers
# ---------------------------------------------------------------------------


def _resolve_or_create_lot(c: Any, product_id: int, lot_name: str, company_id: int) -> int:
    """Find or create a stock.lot by name + product + company."""
    existing = c.search(
        "stock.lot",
        [["name", "=", lot_name], ["product_id", "=", product_id], ["company_id", "=", company_id]],
        limit=1,
    )
    if existing:
        return existing[0]
    return c.execute_kw("stock.lot", "create", [{"name": lot_name, "product_id": product_id, "company_id": company_id}])


def _resolve_or_create_analytic(c: Any, project_name: str, company_id: int) -> int | None:
    """Find or create an analytic account for an Accurate project (SC)."""
    if not project_name:
        return None
    existing = c.search(
        "account.analytic.account",
        [["name", "=", project_name], ["company_id", "=", company_id]],
        limit=1,
    )
    if existing:
        return existing[0]
    # Find the default analytic plan
    plans = c.search_read("account.analytic.plan", [["company_id", "in", [company_id, False]]], fields=["id"], limit=1)
    plan_id = plans[0]["id"] if plans else None
    vals: dict[str, Any] = {"name": project_name, "company_id": company_id}
    if plan_id:
        vals["plan_id"] = plan_id
    return c.execute_kw("account.analytic.account", "create", [vals])


def _step_receive_items(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    """Validate PO receipts with container-based lot numbers.

    For each Accurate Receive Item:
    1. Find the matching Odoo picking (by PO origin)
    2. For each detail line, create a stock.lot from the container number
    3. Assign lots to move lines with correct quantities
    4. Validate the picking
    """
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching receive items from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/receive-item/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No receive items found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} receive items...")
    details = acc_client.detail_many("/accurate/api/receive-item/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            ctr.errors += 1
            continue

        ri_number = str(detail.get("number", "")).strip()
        if not ri_number:
            ctr.skipped += 1
            continue

        # Dedup: check if we already processed this RI
        existing_picks = c.search(
            "stock.picking",
            [["company_id", "=", odoo_company], ["note", "ilike", ri_number], ["state", "=", "done"]],
            limit=1,
        )
        if existing_picks:
            ctr.skipped += 1
            audit.append({"action": "skip", "ri_number": ri_number, "reason": "already validated"})
            continue

        ri_date = accurate_date_to_odoo(str(detail.get("transDate", "")))
        description = str(detail.get("description", "")).strip()

        # Find the Odoo picking from the linked PO
        detail_items = detail.get("detailItem") or []
        if not detail_items:
            ctr.skipped += 1
            continue

        # Get PO number from first detail line
        first_po = (detail_items[0].get("purchaseOrder") or {}).get("number", "")
        if not first_po:
            out.info(f"  RI {ri_number}: no PO link found, skipping")
            ctr.skipped += 1
            continue

        # Find Odoo picking by PO origin
        pickings = c.search_read(
            "stock.picking",
            [
                ["company_id", "=", odoo_company],
                [
                    "origin",
                    "=",
                    first_po.replace("PO.2026.03.", "P")
                    .replace("00008", "00002")
                    .replace("00009", "00003")
                    .replace("00010", "00004"),
                ],
            ],
            fields=["id", "name", "state", "move_ids", "origin"],
            limit=1,
        )
        # Fallback: search by origin containing the PO number pattern
        if not pickings:
            # Try to find by matching PO name in Odoo
            po_recs = c.search_read(
                "purchase.order",
                [["company_id", "=", odoo_company], ["origin", "=", first_po]],
                fields=["id", "name"],
                limit=1,
            )
            if po_recs:
                po_name = po_recs[0]["name"]
                pickings = c.search_read(
                    "stock.picking",
                    [
                        ["company_id", "=", odoo_company],
                        ["origin", "=", po_name],
                        ["state", "in", ["assigned", "confirmed"]],
                    ],
                    fields=["id", "name", "state", "move_ids", "origin"],
                    limit=1,
                )

        if not pickings:
            out.info(f"  RI {ri_number}: no matching Odoo picking found for PO {first_po}")
            ctr.errors += 1
            audit.append({"action": "error", "ri_number": ri_number, "error": f"no picking for PO {first_po}"})
            continue

        picking = pickings[0]
        picking_id = picking["id"]
        picking_state = picking["state"]

        if picking_state == "done":
            # Already validated — just update the note with RI reference
            c.execute_kw("stock.picking", "write", [[picking_id], {"note": f"Accurate: {ri_number} | {description}"}])
            ctr.skipped += 1
            audit.append(
                {"action": "skip", "ri_number": ri_number, "picking": picking["name"], "reason": "already done"}
            )
            continue

        if dry_run:
            out.info(f"  [DRY-RUN] Would validate {picking['name']} for RI {ri_number}")
            ctr.created += 1
            continue

        # Build lot assignments from Accurate serial numbers
        move_lines = c.search_read(
            "stock.move.line",
            [["picking_id", "=", picking_id]],
            fields=["id", "move_id", "product_id", "quantity"],
            limit=50,
        )

        # Process each Accurate detail line's serial numbers
        lot_assignments: list[dict[str, Any]] = []
        project_name = ""
        for acc_item in detail_items:
            serial_numbers = acc_item.get("detailSerialNumber") or []
            item_data = acc_item.get("item") or {}
            product_code = item_data.get("no", "")
            product_id = resolve_product_by_code(c, odoo_company, product_code) if product_code else None
            proj = acc_item.get("project") or {}
            if proj.get("name"):
                project_name = proj["name"]

            if not serial_numbers:
                # No serial numbers — use container from charField1 or receiveNumber
                container = str(acc_item.get("charField1", "")).strip()
                if not container:
                    container = str(detail.get("receiveNumber", ri_number)).strip()
                qty = float(acc_item.get("quantity", 0))
                lot_assignments.append({"product_id": product_id, "lot_name": container, "qty": qty})
            else:
                for sn in serial_numbers:
                    sn_data = sn.get("serialNumber") or {}
                    lot_name = sn_data.get("number", "")
                    qty = float(sn.get("quantity", 0))
                    if lot_name and qty > 0:
                        lot_assignments.append({"product_id": product_id, "lot_name": lot_name, "qty": qty})

        # Apply lot assignments to move lines
        try:
            ml_idx = 0
            for la in lot_assignments:
                if ml_idx >= len(move_lines):
                    # Need to create new move line
                    if not la["product_id"]:
                        continue
                    # Find the move for this product
                    moves = c.search(
                        "stock.move",
                        [["picking_id", "=", picking_id], ["product_id", "=", la["product_id"]]],
                        limit=1,
                    )
                    if not moves:
                        continue
                    # Get picking type locations
                    pick_data = c.search_read(
                        "stock.picking", [["id", "=", picking_id]], fields=["location_id", "location_dest_id"], limit=1
                    )
                    if not pick_data:
                        continue
                    lot_id = _resolve_or_create_lot(c, la["product_id"], la["lot_name"], odoo_company)
                    c.execute_kw(
                        "stock.move.line",
                        "create",
                        [
                            {
                                "move_id": moves[0],
                                "picking_id": picking_id,
                                "product_id": la["product_id"],
                                "lot_id": lot_id,
                                "quantity": la["qty"],
                                "location_id": pick_data[0]["location_id"][0],
                                "location_dest_id": pick_data[0]["location_dest_id"][0],
                                "company_id": odoo_company,
                            }
                        ],
                    )
                else:
                    ml = move_lines[ml_idx]
                    pid = la["product_id"] or (ml["product_id"][0] if ml.get("product_id") else None)
                    if pid:
                        lot_id = _resolve_or_create_lot(c, pid, la["lot_name"], odoo_company)
                        c.execute_kw(
                            "stock.move.line", "write", [[ml["id"]], {"lot_id": lot_id, "quantity": la["qty"]}]
                        )
                ml_idx += 1

            # Set scheduled date and note
            write_vals: dict[str, Any] = {"note": f"Accurate: {ri_number} | {description}"}
            if ri_date:
                write_vals["scheduled_date"] = ri_date
            c.execute_kw("stock.picking", "write", [[picking_id], write_vals])

            # Create analytic account for the SC/project
            if project_name:
                _resolve_or_create_analytic(c, project_name, odoo_company)

            # Validate the picking
            c.execute_kw("stock.picking", "button_validate", [[picking_id]])

            ctr.created += 1
            audit.append(
                {
                    "action": "validated",
                    "ri_number": ri_number,
                    "picking": picking["name"],
                    "lots": [la["lot_name"] for la in lot_assignments],
                }
            )
            out.info(f"  ✓ {picking['name']} validated for RI {ri_number} ({len(lot_assignments)} lots)")

        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to validate {picking['name']} for RI {ri_number}: {exc}")
            ctr.errors += 1
            audit.append({"action": "error", "ri_number": ri_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 6: Sales Invoices → account.move (out_invoice)
# ---------------------------------------------------------------------------


def _step_sales_invoices(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching sales invoices from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/sales-invoice/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No sales invoices found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} sales invoices...")
    details = acc_client.detail_many("/accurate/api/sales-invoice/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching SI id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        si_number: str = str(detail.get("number", "")).strip()
        if not si_number:
            ctr.skipped += 1
            continue

        # Dedup check
        existing = c.search(
            "account.move",
            [
                ["ref", "=", si_number],
                ["move_type", "=", "out_invoice"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "si_number": si_number})
            continue

        si_date_raw: str = str(detail.get("date", "") or "").strip()
        si_date: str = accurate_date_to_odoo(si_date_raw) if si_date_raw else ""

        # Customer
        customer_data = detail.get("customer") or {}
        customer_no: str = str(customer_data.get("customerNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, customer_no) if customer_no else None

        # Currency
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)

        # AR account for the currency
        ar_account_for_currency(c, odoo_company, currency_code)

        # Lines from detailItem
        lines_data = detail.get("detailItem") or []
        line_vals: list[dict[str, Any]] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            item_name: str = str(product_data.get("name", "") or "").strip()

            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None

            qty = float(line.get("quantity", 1.0) or 1.0)
            price_unit = float(line.get("unitPrice", 0.0) or 0.0)

            # Sales account: from item GL or AR fallback
            gl_data = line.get("glAccount") or product_data.get("salesGlAccount") or {}
            gl_name: str = str(gl_data.get("name", "")).strip()
            account_id: int | None = None
            if gl_name:
                acct_ids = c.search(
                    "account.account",
                    [["company_id", "=", odoo_company], ["name", "ilike", gl_name]],
                    limit=1,
                )
                account_id = acct_ids[0] if acct_ids else None

            line_dict: dict[str, Any] = {
                "name": item_name or item_no or "Line Item",
                "quantity": qty,
                "price_unit": price_unit,
                "tax_ids": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            if account_id:
                line_dict["account_id"] = account_id

            line_vals.append((0, 0, line_dict))

        # Additional expense lines from detailExpense (Biaya Lainnya):
        # PPN Keluaran, PPh withholding, freight charges, etc.
        expense_data = detail.get("detailExpense") or []
        if expense_data:
            expense_lines = _build_expense_lines(c, odoo_company, expense_data, out)
            line_vals.extend(expense_lines)
            if expense_lines:
                out.info(f"    SI {si_number!r}: added {len(expense_lines)} detailExpense line(s)")

        vals: dict[str, Any] = {
            "move_type": "out_invoice",
            "ref": si_number,
            "company_id": odoo_company,
            "invoice_line_ids": line_vals,
        }
        if partner_id:
            vals["partner_id"] = partner_id
        if si_date:
            vals["invoice_date"] = si_date
        if currency_id:
            vals["currency_id"] = currency_id
        # payment_reference = customer's PO/reference number
        vendor_inv_no = str(detail.get("vendorInvoiceNo", "") or detail.get("invoiceNo", "") or "").strip()
        if vendor_inv_no:
            vals["payment_reference"] = vendor_inv_no
        # narration = description/keterangan
        description = str(detail.get("description", "") or "").strip()
        if description:
            vals["narration"] = description

        if dry_run:
            out.info(f"  [DRY-RUN] Would create sales invoice: {si_number!r} ({len(line_vals)} lines, {currency_code})")
            ctr.created += 1
            audit.append({"action": "create_dry", "si_number": si_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "si_number": si_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create sales invoice {si_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "si_number": si_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 7: Sales Receipts → account.payment (inbound)
# ---------------------------------------------------------------------------


def _step_sales_receipts(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching sales receipts from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/sales-receipt/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No sales receipts found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} sales receipts...")
    details = acc_client.detail_many("/accurate/api/sales-receipt/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching receipt id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        receipt_number: str = str(detail.get("number", "")).strip()
        if not receipt_number:
            ctr.skipped += 1
            continue

        # Dedup check — account.payment uses 'memo' in Odoo 18
        existing = c.search(
            "account.payment",
            [
                ["memo", "=", receipt_number],
                ["payment_type", "=", "inbound"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "receipt_number": receipt_number})
            continue

        receipt_date_raw: str = str(detail.get("date", "") or "").strip()
        receipt_date: str = accurate_date_to_odoo(receipt_date_raw) if receipt_date_raw else ""

        # Currency
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("code", "") or currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)
        is_foreign = currency_code != "IDR"

        # Journal: resolve by Accurate bankAccount.name then by receipt number prefix
        bank_data = detail.get("bankAccount") or {}
        bank_name: str = str(bank_data.get("name", "")).strip()
        journal_id: int | None = _resolve_journal_by_prefix(c, odoo_company, receipt_number, bank_name)

        # Find linked Odoo sales invoice via Accurate detailInvoice[0].invoiceNo
        detail_invoices = detail.get("detailInvoice") or []
        linked_invoice_id: int | None = None
        if detail_invoices:
            inv_no: str = str(detail_invoices[0].get("invoiceNo", "")).strip()
            if inv_no:
                inv_ids = c.search(
                    "account.move",
                    [
                        ["company_id", "=", odoo_company],
                        ["move_type", "=", "out_invoice"],
                        ["ref", "ilike", inv_no],
                        ["state", "=", "posted"],
                        ["payment_state", "in", ["not_paid", "partial"]],
                    ],
                    limit=1,
                )
                linked_invoice_id = inv_ids[0] if inv_ids else None

        # Amount
        if is_foreign and detail_invoices:
            amount = float(detail_invoices[0].get("paymentAmount", 0.0) or 0.0)
        else:
            amount = float(detail.get("totalAmount", 0.0) or 0.0)
            if amount == 0:
                for inv_detail in detail_invoices:
                    amount += float(inv_detail.get("paymentAmount", 0.0) or 0.0)

        if dry_run:
            out.info(
                f"  [DRY-RUN] Would register sales receipt: {receipt_number!r} "
                f"amount={amount} {currency_code} invoice_id={linked_invoice_id}"
            )
            ctr.created += 1
            audit.append({"action": "create_dry", "receipt_number": receipt_number})
            continue

        try:
            if linked_invoice_id:
                # Use account.payment.register wizard — same as UI Receive payment button
                wizard_ctx = {
                    "active_model": "account.move",
                    "active_ids": [linked_invoice_id],
                }
                wizard_vals: dict[str, Any] = {
                    "communication": receipt_number,
                }
                if receipt_date:
                    wizard_vals["payment_date"] = receipt_date
                if journal_id:
                    wizard_vals["journal_id"] = journal_id
                if is_foreign and currency_id:
                    wizard_vals["currency_id"] = currency_id
                    wizard_vals["amount"] = amount

                wizard_id = c.execute_kw(
                    "account.payment.register",
                    "create",
                    [wizard_vals],
                    {"context": wizard_ctx},
                )
                c.execute_kw(
                    "account.payment.register",
                    "action_create_payments",
                    [[wizard_id]],
                    {"context": wizard_ctx},
                )
                out.info(f"  Registered sales receipt via wizard: {receipt_number!r}")
            else:
                # No linked invoice — create standalone inbound payment
                vals: dict[str, Any] = {
                    "payment_type": "inbound",
                    "partner_type": "customer",
                    "amount": amount,
                    "memo": receipt_number,
                    "company_id": odoo_company,
                }
                if currency_id:
                    vals["currency_id"] = currency_id
                if journal_id:
                    vals["journal_id"] = journal_id
                if receipt_date:
                    vals["date"] = receipt_date
                # Resolve customer for standalone payment
                customer_data = detail.get("customer") or {}
                customer_no: str = str(customer_data.get("customerNo", "")).strip()
                partner_id: int | None = resolve_partner_by_ref(c, odoo_company, customer_no) if customer_no else None
                if partner_id:
                    vals["partner_id"] = partner_id

                c.execute_kw("account.payment", "create", [vals])
                out.info(f"  Created standalone sales receipt: {receipt_number!r} (no linked invoice)")

            ctr.created += 1
            audit.append({"action": "create", "receipt_number": receipt_number, "invoice_id": linked_invoice_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to register sales receipt {receipt_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "receipt_number": receipt_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Helper: build account.move lines from Accurate detailItem list
# ---------------------------------------------------------------------------


def _build_move_lines(
    c: Any,
    odoo_company: int,
    detail_items: list[dict[str, Any]],
    default_account_field: str = "glAccount",
) -> list[Any]:
    """Convert Accurate detailItem entries into Odoo account.move.line (0,0,{}) tuples."""
    line_vals: list[Any] = []
    for line in detail_items:
        description: str = str(line.get("description", "") or line.get("name", "") or "").strip()

        # Resolve GL account
        gl_data = line.get(default_account_field) or line.get("glAccount") or {}
        gl_name: str = str(gl_data.get("name", "")).strip() if isinstance(gl_data, dict) else ""
        account_id: int | None = None
        if gl_name:
            acct_ids = c.search(
                "account.account",
                [["company_id", "=", odoo_company], ["name", "ilike", gl_name]],
                limit=1,
            )
            account_id = acct_ids[0] if acct_ids else None

        debit: float = float(line.get("debit", 0.0) or 0.0)
        credit: float = float(line.get("credit", 0.0) or 0.0)

        # Fallback: some Accurate endpoints use amount + side
        if debit == 0.0 and credit == 0.0:
            amount = float(line.get("amount", 0.0) or 0.0)
            side: str = str(line.get("side", "DEBIT")).upper()
            if side == "DEBIT":
                debit = amount
            else:
                credit = amount

        line_dict: dict[str, Any] = {
            "name": description or gl_name or "Line",
            "debit": debit,
            "credit": credit,
        }
        if account_id:
            line_dict["account_id"] = account_id

        line_vals.append((0, 0, line_dict))
    return line_vals


# ---------------------------------------------------------------------------
# Helper: build invoice_line_ids entries from Accurate detailExpense list
# ---------------------------------------------------------------------------


def _build_expense_lines(
    c: Any,
    odoo_company: int,
    detail_expenses: list[dict[str, Any]],
    out: Any,
) -> list[Any]:
    """Convert Accurate detailExpense entries into Odoo invoice_line_ids (0,0,{}) tuples.

    Each entry in detailExpense has:
      - ``amount``       — line amount (may be negative for withholding tax accounts)
      - ``expenseAccount`` — dict with ``name`` and ``accountNo``
      - ``project``      — optional dict with ``name``

    The account is resolved first by GL code (``accountNo``) for precision, then
    falls back to name (``ilike``).  Lines with no resolvable account are skipped
    with a warning.
    """
    line_vals: list[Any] = []
    for exp in detail_expenses:
        amount: float = float(exp.get("amount", 0.0) or 0.0)
        if amount == 0.0:
            continue

        acct_data = exp.get("expenseAccount") or {}
        acct_name: str = str(acct_data.get("name", "") or "").strip()
        acct_code: str = str(acct_data.get("accountNo", "") or "").strip()

        account_id: int | None = None
        if acct_code:
            account_id = resolve_account_by_code(c, odoo_company, acct_code)
        if account_id is None and acct_name:
            account_id = resolve_account_by_name(c, odoo_company, acct_name)

        if account_id is None:
            # Fallback: infer account from amount sign and common patterns
            if amount > 0:
                # Positive expense = PPN Masukan (input VAT)
                account_id = resolve_account_by_name(c, odoo_company, "PPN Masukan")
                acct_name = "PPN Masukan"
            elif amount < 0:
                # Negative expense = Utang PPh PS 23 (withholding)
                account_id = resolve_account_by_name(c, odoo_company, "Utang PPh PS 23")
                acct_name = "Utang PPh PS 23"

        if account_id is None:
            label = acct_name or acct_code or "(unknown)"
            out.info(f"    detailExpense: could not resolve account {label!r} — skipping line")
            continue

        label = acct_name or acct_code or "Biaya Lainnya"
        line_dict: dict[str, Any] = {
            "account_id": account_id,
            "name": label,
            "quantity": 1,
            "price_unit": amount,
            "tax_ids": [[5, 0, 0]],
        }
        line_vals.append((0, 0, line_dict))

    return line_vals


# ---------------------------------------------------------------------------
# Step 8: Journal Vouchers → account.move (general entry, legacy detailItem)
# ---------------------------------------------------------------------------

# Journal type mapping by Accurate transactionType code.
# Keys match the 2-letter codes returned in detailJournalVoucher.transactionType.
_JV_TXTYPE_JOURNAL_MAP: dict[str, tuple[str, str]] = {
    # (odoo journal type, display name fragment for lookup)
    "PI": ("purchase", "Faktur Pembelian"),  # Purchase Invoice → purchase journal
    "PP": ("bank", ""),  # Purchase Payment → bank journal (resolved from lines)
    "RI": ("general", "Penilaian Persediaan"),  # Receive Item → inventory valuation (STJ)
    "SI": ("sale", "Faktur Penjualan"),  # Sales Invoice → sales journal
    "SR": ("bank", ""),  # Sales Receipt → bank journal
    "JV": ("general", "Operasi Lain-lain"),  # Manual JV → misc journal
    "BT": ("bank", ""),  # Bank Transfer → bank journal
    "OP": ("general", "Operasi Lain-lain"),  # Other Payment → misc
    "OD": ("general", "Operasi Lain-lain"),  # Other Deposit → misc
    "EX": ("general", "Operasi Lain-lain"),  # Expense → misc
    "SR2": ("general", "Operasi Lain-lain"),  # Sales Return → misc
    "PR": ("general", "Operasi Lain-lain"),  # Purchase Return → misc
}


def _resolve_journal_for_txtype(
    c: Any,
    odoo_company: int,
    txn_type: str,
    misc_journal_id: int | None,
) -> int | None:
    """Resolve the best matching Odoo journal for an Accurate transaction type code."""
    entry = _JV_TXTYPE_JOURNAL_MAP.get(txn_type.upper() if txn_type else "JV", ("general", ""))
    odoo_type, name_hint = entry

    if name_hint:
        # Try named journal first
        jids = c.search(
            "account.journal",
            [
                ["company_id", "=", odoo_company],
                ["type", "=", odoo_type],
                ["name", "ilike", name_hint],
            ],
            limit=1,
        )
        if jids:
            return jids[0]

    # Fall back to any journal of that type
    jids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", odoo_type]],
        limit=1,
    )
    if jids:
        return jids[0]

    return misc_journal_id


def _build_jv_move_lines(
    c: Any,
    odoo_company: int,
    jv_lines: list[dict[str, Any]],
) -> list[Any]:
    """Build account.move.line (0,0,{}) tuples from detailJournalVoucher lines.

    Each line uses:
      - accountNameRef / accountNoRef  → account.account (name or code match)
      - debitAmount / creditAmount / amountType / amount → debit/credit floats
      - memo → line description
      - project.name → analytic account
    """
    line_vals: list[Any] = []
    for line in jv_lines:
        # --- Account resolution ---
        acct_name: str = str(line.get("accountNameRef", "") or "").strip()
        acct_no: str = str(line.get("accountNoRef", "") or "").strip()

        account_id: int | None = None
        if acct_no:
            # Prefer code match (exact)
            ids = c.search(
                "account.account",
                [["company_id", "=", odoo_company], ["code", "=", acct_no]],
                limit=1,
            )
            if ids:
                account_id = ids[0]

        if account_id is None and acct_name:
            ids = c.search(
                "account.account",
                [["company_id", "=", odoo_company], ["name", "ilike", acct_name]],
                limit=1,
            )
            if ids:
                account_id = ids[0]

        # --- Debit / Credit resolution ---
        debit: float = float(line.get("debitAmount", 0.0) or 0.0)
        credit: float = float(line.get("creditAmount", 0.0) or 0.0)

        if debit == 0.0 and credit == 0.0:
            # Fall back to amount + amountType
            amount = float(line.get("amount", 0.0) or 0.0)
            side: str = str(line.get("amountType", "DEBIT")).upper()
            if side == "DEBIT":
                debit = amount
            else:
                credit = amount

        # --- Description ---
        memo: str = str(line.get("memo", "") or "").strip()
        description: str = memo or acct_name or "Line"

        # --- Analytic account ---
        project_data = line.get("project") or {}
        project_name: str = str(project_data.get("name", "") or "").strip()
        analytic_id: int | None = None
        if project_name:
            analytic_id = _resolve_or_create_analytic(c, project_name, odoo_company)

        line_dict: dict[str, Any] = {
            "name": description,
            "debit": debit,
            "credit": credit,
        }
        if account_id:
            line_dict["account_id"] = account_id
        if analytic_id:
            # Odoo 18: analytic_distribution is a JSON dict {plan_id_str: percentage}
            try:
                plans = c.search_read(
                    "account.analytic.plan",
                    [["company_id", "in", [odoo_company, False]]],
                    fields=["id"],
                    limit=1,
                )
                if plans:
                    plan_id = str(plans[0]["id"])
                    line_dict["analytic_distribution"] = {plan_id: 100.0}
            except (RPCError, ConnectionError, ValueError):
                pass

        line_vals.append((0, 0, line_dict))
    return line_vals


def _step_journal_vouchers(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    """Sync journal vouchers using detailItem (legacy path — kept for compatibility)."""
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching journal vouchers from Accurate (legacy detailItem path)...")
    raw_list = acc_client.list_all(
        "/accurate/api/journal-voucher/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No journal vouchers found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} journal vouchers...")
    details = acc_client.detail_many("/accurate/api/journal-voucher/detail.do", acc_ids)

    # Resolve a misc/general journal
    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching JV id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        jv_number: str = str(detail.get("number", "")).strip()
        if not jv_number:
            ctr.skipped += 1
            continue

        # Dedup check
        existing = c.search(
            "account.move",
            [
                ["ref", "=", jv_number],
                ["move_type", "=", "entry"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "jv_number": jv_number})
            continue

        jv_date_raw: str = str(detail.get("date", "") or "").strip()
        jv_date: str = accurate_date_to_odoo(jv_date_raw) if jv_date_raw else ""

        # Build move lines from detailItem
        detail_items = detail.get("detailItem") or []
        line_vals = _build_move_lines(c, odoo_company, detail_items)

        if not line_vals:
            out.info(f"  JV {jv_number!r} has no detail lines — skipping.")
            ctr.skipped += 1
            continue

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": jv_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if jv_date:
            vals["date"] = jv_date
        if misc_journal_id:
            vals["journal_id"] = misc_journal_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create journal entry: {jv_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "jv_number": jv_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "jv_number": jv_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create journal entry {jv_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "jv_number": jv_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 8b: All Journals (JV-driven) → account.move (exact GL from JV detail)
# ---------------------------------------------------------------------------


def _step_journal_vouchers_full(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    """Sync ALL Accurate journal vouchers as account.move entries.

    This is the universal journal sync — every Accurate transaction
    (PI, PP, RI, SI, SR, etc.) generates a JV with exact GL lines.
    We read detailJournalVoucher to get the authoritative GL split
    and create matching account.move entries in Odoo.

    Deduplication: skip if account.move with ref=JV number already exists
    for this company (regardless of journal or move_type).
    """
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching journal vouchers from Accurate (JV-driven, all types)...")
    raw_list = acc_client.list_all(
        "/accurate/api/journal-voucher/list.do",
        params={"fields": "id,number,transactionType,transNumber", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No journal vouchers found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} journal vouchers...")
    details = acc_client.detail_many("/accurate/api/journal-voucher/detail.do", acc_ids)

    # Cache misc journal for fallback
    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching JV id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        jv_number: str = str(detail.get("number", "")).strip()
        if not jv_number:
            ctr.skipped += 1
            continue

        # ------------------------------------------------------------------
        # Dedup: any account.move already carrying this JV number as ref
        # ------------------------------------------------------------------
        existing = c.search(
            "account.move",
            [["ref", "=", jv_number], ["company_id", "=", odoo_company]],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "jv_number": jv_number})
            continue

        # ------------------------------------------------------------------
        # Metadata
        # ------------------------------------------------------------------
        txn_type: str = str(detail.get("transactionType", "") or "JV").strip().upper()
        trans_number: str = str(detail.get("transNumber", "") or "").strip()
        description: str = str(detail.get("description", "") or "").strip()
        jv_date_raw: str = str(detail.get("transDate", "") or detail.get("date", "") or "").strip()
        jv_date: str = accurate_date_to_odoo(jv_date_raw) if jv_date_raw else ""

        # ------------------------------------------------------------------
        # Read detailJournalVoucher (exact GL lines)
        # ------------------------------------------------------------------
        jv_lines = detail.get("detailJournalVoucher") or []
        if not jv_lines:
            # Some JVs only have detailItem — fall back gracefully
            jv_lines_fallback = detail.get("detailItem") or []
            if jv_lines_fallback:
                out.info(f"  JV {jv_number!r} has no detailJournalVoucher — falling back to detailItem.")
                line_vals = _build_move_lines(c, odoo_company, jv_lines_fallback)
            else:
                out.info(f"  JV {jv_number!r} has no GL lines — skipping.")
                ctr.skipped += 1
                audit.append({"action": "skip", "jv_number": jv_number, "reason": "no GL lines"})
                continue
        else:
            line_vals = _build_jv_move_lines(c, odoo_company, jv_lines)

        if not line_vals:
            out.info(f"  JV {jv_number!r} produced no valid move lines — skipping.")
            ctr.skipped += 1
            audit.append({"action": "skip", "jv_number": jv_number, "reason": "empty lines after resolve"})
            continue

        # ------------------------------------------------------------------
        # Journal selection by transaction type
        # ------------------------------------------------------------------
        journal_id = _resolve_journal_for_txtype(c, odoo_company, txn_type, misc_journal_id)

        # ------------------------------------------------------------------
        # Build note: JV number + linked document + description
        # ------------------------------------------------------------------
        narration_parts = [jv_number]
        if trans_number:
            narration_parts.append(trans_number)
        if description:
            narration_parts.append(description)
        narration = " | ".join(narration_parts)

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": jv_number,
            "narration": narration,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if jv_date:
            vals["date"] = jv_date
        if journal_id:
            vals["journal_id"] = journal_id

        if dry_run:
            out.info(
                f"  [DRY-RUN] Would create {txn_type} journal entry: {jv_number!r}"
                f" ({len(line_vals)} lines, trans={trans_number!r})"
            )
            ctr.created += 1
            audit.append(
                {
                    "action": "create_dry",
                    "jv_number": jv_number,
                    "txn_type": txn_type,
                    "trans_number": trans_number,
                    "line_count": len(line_vals),
                }
            )
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            # Post the entry so it's in the GL
            try:
                c.execute_kw("account.move", "action_post", [[new_id]])
            except (RPCError, ConnectionError, ValueError) as post_exc:
                out.info(f"  Created JV {jv_number!r} (id={new_id}) but post failed: {post_exc}")
            ctr.created += 1
            audit.append(
                {
                    "action": "create",
                    "jv_number": jv_number,
                    "txn_type": txn_type,
                    "trans_number": trans_number,
                    "odoo_id": new_id,
                    "line_count": len(line_vals),
                }
            )
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create journal entry {jv_number!r}: {exc}")
            ctr.errors += 1
            audit.append(
                {
                    "action": "create_error",
                    "jv_number": jv_number,
                    "txn_type": txn_type,
                    "error": str(exc),
                }
            )

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 9: Bank Transfers → account.move (general entry)
# ---------------------------------------------------------------------------


def _step_bank_transfers(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching bank transfers from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/bank-transfer/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No bank transfers found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} bank transfers...")
    details = acc_client.detail_many("/accurate/api/bank-transfer/detail.do", acc_ids)

    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching BT id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        bt_number: str = str(detail.get("number", "")).strip()
        if not bt_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", bt_number],
                ["move_type", "=", "entry"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "bt_number": bt_number})
            continue

        bt_date_raw: str = str(detail.get("date", "") or "").strip()
        bt_date: str = accurate_date_to_odoo(bt_date_raw) if bt_date_raw else ""

        amount: float = float(detail.get("amount", 0.0) or 0.0)
        description: str = str(detail.get("description", "") or "").strip() or f"Bank Transfer {bt_number}"

        # Source bank account
        from_bank_data = detail.get("fromBankAccount") or {}
        from_bank_name: str = str(from_bank_data.get("name", "")).strip()
        from_account_id: int | None = None
        if from_bank_name:
            acct_ids = c.search(
                "account.account",
                [["company_id", "=", odoo_company], ["name", "ilike", from_bank_name]],
                limit=1,
            )
            from_account_id = acct_ids[0] if acct_ids else None

        # Destination bank account
        to_bank_data = detail.get("toBankAccount") or {}
        to_bank_name: str = str(to_bank_data.get("name", "")).strip()
        to_account_id: int | None = None
        if to_bank_name:
            acct_ids = c.search(
                "account.account",
                [["company_id", "=", odoo_company], ["name", "ilike", to_bank_name]],
                limit=1,
            )
            to_account_id = acct_ids[0] if acct_ids else None

        # Build debit/credit lines: credit source, debit destination
        line_vals: list[Any] = []
        if from_account_id:
            line_vals.append(
                (0, 0, {"name": description, "account_id": from_account_id, "credit": amount, "debit": 0.0})
            )
        if to_account_id:
            line_vals.append((0, 0, {"name": description, "account_id": to_account_id, "debit": amount, "credit": 0.0}))

        if not line_vals:
            # Fallback: use detailItem if present
            detail_items = detail.get("detailItem") or []
            line_vals = _build_move_lines(c, odoo_company, detail_items)

        if not line_vals:
            out.info(f"  Bank transfer {bt_number!r} has no resolvable accounts — skipping.")
            ctr.skipped += 1
            continue

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": bt_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if bt_date:
            vals["date"] = bt_date
        if misc_journal_id:
            vals["journal_id"] = misc_journal_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create bank transfer entry: {bt_number!r} amount={amount}")
            ctr.created += 1
            audit.append({"action": "create_dry", "bt_number": bt_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "bt_number": bt_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create bank transfer {bt_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "bt_number": bt_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 10: Other Payments → account.move (general entry)
# ---------------------------------------------------------------------------


def _step_other_payments(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching other payments from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/other-payment/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No other payments found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} other payments...")
    details = acc_client.detail_many("/accurate/api/other-payment/detail.do", acc_ids)

    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching OP id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        op_number: str = str(detail.get("number", "")).strip()
        if not op_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", op_number],
                ["move_type", "=", "entry"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "op_number": op_number})
            continue

        op_date_raw: str = str(detail.get("date", "") or "").strip()
        op_date: str = accurate_date_to_odoo(op_date_raw) if op_date_raw else ""

        detail_items = detail.get("detailItem") or []
        line_vals = _build_move_lines(c, odoo_company, detail_items)

        if not line_vals:
            ctr.skipped += 1
            continue

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": op_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if op_date:
            vals["date"] = op_date
        if misc_journal_id:
            vals["journal_id"] = misc_journal_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create other payment entry: {op_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "op_number": op_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "op_number": op_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create other payment {op_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "op_number": op_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 11: Other Deposits → account.move (general entry)
# ---------------------------------------------------------------------------


def _step_other_deposits(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching other deposits from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/other-deposit/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No other deposits found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} other deposits...")
    details = acc_client.detail_many("/accurate/api/other-deposit/detail.do", acc_ids)

    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching OD id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        od_number: str = str(detail.get("number", "")).strip()
        if not od_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", od_number],
                ["move_type", "=", "entry"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "od_number": od_number})
            continue

        od_date_raw: str = str(detail.get("date", "") or "").strip()
        od_date: str = accurate_date_to_odoo(od_date_raw) if od_date_raw else ""

        detail_items = detail.get("detailItem") or []
        line_vals = _build_move_lines(c, odoo_company, detail_items)

        if not line_vals:
            ctr.skipped += 1
            continue

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": od_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if od_date:
            vals["date"] = od_date
        if misc_journal_id:
            vals["journal_id"] = misc_journal_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create other deposit entry: {od_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "od_number": od_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "od_number": od_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create other deposit {od_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "od_number": od_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 12: Expenses → account.move (general entry)
# ---------------------------------------------------------------------------


def _step_expenses(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching expenses from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/expense/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No expenses found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} expenses...")
    details = acc_client.detail_many("/accurate/api/expense/detail.do", acc_ids)

    misc_journal_ids = c.search(
        "account.journal",
        [["company_id", "=", odoo_company], ["type", "=", "general"]],
        limit=1,
    )
    misc_journal_id: int | None = misc_journal_ids[0] if misc_journal_ids else None

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching expense id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        exp_number: str = str(detail.get("number", "")).strip()
        if not exp_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", exp_number],
                ["move_type", "=", "entry"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "exp_number": exp_number})
            continue

        exp_date_raw: str = str(detail.get("date", "") or "").strip()
        exp_date: str = accurate_date_to_odoo(exp_date_raw) if exp_date_raw else ""

        # Vendor/party
        vendor_data = detail.get("vendor") or {}
        vendor_no: str = str(vendor_data.get("vendorNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, vendor_no) if vendor_no else None

        detail_items = detail.get("detailItem") or []
        line_vals = _build_move_lines(c, odoo_company, detail_items)

        if not line_vals:
            ctr.skipped += 1
            continue

        vals: dict[str, Any] = {
            "move_type": "entry",
            "ref": exp_number,
            "company_id": odoo_company,
            "line_ids": line_vals,
        }
        if exp_date:
            vals["date"] = exp_date
        if misc_journal_id:
            vals["journal_id"] = misc_journal_id
        if partner_id:
            vals["partner_id"] = partner_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create expense entry: {exp_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "exp_number": exp_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "exp_number": exp_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create expense {exp_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "exp_number": exp_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 13: Sales Orders → sale.order (confirmed)
# ---------------------------------------------------------------------------


def _step_sales_orders(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching sales orders from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/sales-order/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No sales orders found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} sales orders...")
    details = acc_client.detail_many("/accurate/api/sales-order/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching SO id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        so_number: str = str(detail.get("number", "")).strip()
        if not so_number:
            ctr.skipped += 1
            continue

        # Dedup by origin
        existing = c.search(
            "sale.order",
            [["origin", "=", so_number], ["company_id", "=", odoo_company]],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "so_number": so_number})
            continue

        so_date_raw: str = str(detail.get("date", "") or "").strip()
        so_date: str = accurate_date_to_odoo(so_date_raw) if so_date_raw else ""

        # Customer
        customer_data = detail.get("customer") or {}
        customer_no: str = str(customer_data.get("customerNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, customer_no) if customer_no else None
        if partner_id is None:
            customer_name: str = str(customer_data.get("name", "")).strip()
            if customer_name:
                name_ids = c.search(
                    "res.partner",
                    [
                        "|",
                        ("company_id", "=", odoo_company),
                        ("company_id", "=", False),
                        ("name", "ilike", customer_name),
                        ("customer_rank", ">", 0),
                    ],
                    limit=1,
                )
                partner_id = name_ids[0] if name_ids else None

        if not partner_id:
            out.error(f"  Cannot resolve customer for SO {so_number!r} — skipping.")
            ctr.errors += 1
            audit.append({"action": "skip_no_customer", "so_number": so_number})
            continue

        # Currency
        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)

        # Lines
        lines_data = detail.get("detailItem") or []
        line_vals: list[Any] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            item_name: str = str(product_data.get("name", "") or "").strip()
            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None

            uom_data = line.get("unit") or {}
            uom_name: str = str(uom_data.get("name", "CTN")).strip()
            uom_id: int | None = resolve_uom_by_name(c, uom_name)

            qty: float = float(line.get("quantity", 1.0) or 1.0)
            price_unit: float = float(line.get("unitPrice", 0.0) or 0.0)

            line_dict: dict[str, Any] = {
                "name": item_name or item_no or "Line Item",
                "product_uom_qty": qty,
                "price_unit": price_unit,
                "tax_id": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            if uom_id:
                line_dict["product_uom"] = uom_id

            line_vals.append((0, 0, line_dict))

        vals: dict[str, Any] = {
            "origin": so_number,
            "partner_id": partner_id,
            "company_id": odoo_company,
            "order_line": line_vals,
        }
        if so_date:
            vals["date_order"] = so_date
        if currency_id:
            vals["currency_id"] = currency_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create sales order: {so_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "so_number": so_number})
            continue

        try:
            new_id = c.execute_kw("sale.order", "create", [vals])
            # Confirm the SO
            try:
                c.execute_kw("sale.order", "action_confirm", [[new_id]])
            except (RPCError, ConnectionError, ValueError) as exc_confirm:
                out.error(f"  Warning: could not confirm SO {so_number!r}: {exc_confirm}")
            ctr.created += 1
            audit.append({"action": "create", "so_number": so_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create sales order {so_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "so_number": so_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 14: Sales Returns → account.move (out_refund credit note)
# ---------------------------------------------------------------------------


def _step_sales_returns(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching sales returns from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/sales-return/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No sales returns found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} sales returns...")
    details = acc_client.detail_many("/accurate/api/sales-return/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching SR id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        sr_number: str = str(detail.get("number", "")).strip()
        if not sr_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", sr_number],
                ["move_type", "=", "out_refund"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "sr_number": sr_number})
            continue

        sr_date_raw: str = str(detail.get("date", "") or "").strip()
        sr_date: str = accurate_date_to_odoo(sr_date_raw) if sr_date_raw else ""

        customer_data = detail.get("customer") or {}
        customer_no: str = str(customer_data.get("customerNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, customer_no) if customer_no else None

        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)

        lines_data = detail.get("detailItem") or []
        line_vals: list[Any] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            item_name: str = str(product_data.get("name", "") or "").strip()
            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None
            qty: float = float(line.get("quantity", 1.0) or 1.0)
            price_unit: float = float(line.get("unitPrice", 0.0) or 0.0)
            line_dict: dict[str, Any] = {
                "name": item_name or item_no or "Return Item",
                "quantity": qty,
                "price_unit": price_unit,
                "tax_ids": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            line_vals.append((0, 0, line_dict))

        vals: dict[str, Any] = {
            "move_type": "out_refund",
            "ref": sr_number,
            "company_id": odoo_company,
            "invoice_line_ids": line_vals,
        }
        if partner_id:
            vals["partner_id"] = partner_id
        if sr_date:
            vals["invoice_date"] = sr_date
        if currency_id:
            vals["currency_id"] = currency_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create sales return credit note: {sr_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "sr_number": sr_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "sr_number": sr_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create sales return {sr_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "sr_number": sr_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 15: Purchase Returns → account.move (in_refund vendor credit)
# ---------------------------------------------------------------------------


def _step_purchase_returns(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching purchase returns from Accurate...")
    raw_list = acc_client.list_all(
        "/accurate/api/purchase-return/list.do",
        params={"fields": "id,number", **_list_params(since)},
    )
    if not raw_list:
        out.info("  No purchase returns found.")
        return ctr, audit

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} purchase returns...")
    details = acc_client.detail_many("/accurate/api/purchase-return/detail.do", acc_ids)

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching PR id={detail.get('id')}: {detail['__error__']}")
            ctr.errors += 1
            continue

        pr_number: str = str(detail.get("number", "")).strip()
        if not pr_number:
            ctr.skipped += 1
            continue

        existing = c.search(
            "account.move",
            [
                ["ref", "=", pr_number],
                ["move_type", "=", "in_refund"],
                ["company_id", "=", odoo_company],
            ],
            limit=1,
        )
        if existing:
            ctr.skipped += 1
            audit.append({"action": "skip", "pr_number": pr_number})
            continue

        pr_date_raw: str = str(detail.get("date", "") or "").strip()
        pr_date: str = accurate_date_to_odoo(pr_date_raw) if pr_date_raw else ""

        vendor_data = detail.get("vendor") or {}
        vendor_no: str = str(vendor_data.get("vendorNo", "")).strip()
        partner_id: int | None = resolve_partner_by_ref(c, odoo_company, vendor_no) if vendor_no else None

        currency_data = detail.get("currency") or {}
        currency_code: str = str(currency_data.get("symbol", "IDR")).strip() or "IDR"
        currency_id: int | None = resolve_currency_by_code(c, currency_code)

        lines_data = detail.get("detailItem") or []
        line_vals: list[Any] = []
        for line in lines_data:
            product_data = line.get("item") or {}
            item_no: str = str(product_data.get("itemNo", "")).strip()
            item_name: str = str(product_data.get("name", "") or "").strip()
            product_id: int | None = resolve_product_by_code(c, odoo_company, item_no) if item_no else None
            qty: float = float(line.get("quantity", 1.0) or 1.0)
            price_unit: float = float(line.get("unitPrice", 0.0) or 0.0)
            line_dict: dict[str, Any] = {
                "name": item_name or item_no or "Return Item",
                "quantity": qty,
                "price_unit": price_unit,
                "tax_ids": [[5, 0, 0]],
            }
            if product_id:
                line_dict["product_id"] = product_id
            line_vals.append((0, 0, line_dict))

        vals: dict[str, Any] = {
            "move_type": "in_refund",
            "ref": pr_number,
            "company_id": odoo_company,
            "invoice_line_ids": line_vals,
        }
        if partner_id:
            vals["partner_id"] = partner_id
        if pr_date:
            vals["invoice_date"] = pr_date
        if currency_id:
            vals["currency_id"] = currency_id

        if dry_run:
            out.info(f"  [DRY-RUN] Would create purchase return vendor credit: {pr_number!r} ({len(line_vals)} lines)")
            ctr.created += 1
            audit.append({"action": "create_dry", "pr_number": pr_number})
            continue

        try:
            new_id = c.execute_kw("account.move", "create", [vals])
            ctr.created += 1
            audit.append({"action": "create", "pr_number": pr_number, "odoo_id": new_id})
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create purchase return {pr_number!r}: {exc}")
            ctr.errors += 1
            audit.append({"action": "create_error", "pr_number": pr_number, "error": str(exc)})

    return ctr, audit


# ---------------------------------------------------------------------------
# Step 16: Item Adjustments (log only)
# ---------------------------------------------------------------------------


def _step_item_adjustments(
    acc_client: Any,
    since: str | None,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching item adjustments from Accurate (count only)...")
    try:
        raw_list = acc_client.list_all(
            "/accurate/api/item-adjustment/list.do",
            params={"fields": "id,number", **_list_params(since)},
        )
        count = len(raw_list) if raw_list else 0
    except (RPCError, ConnectionError, ValueError) as exc:
        out.error(f"  Error fetching item adjustments: {exc}")
        count = 0

    out.info(f"  Found {count} item adjustments. Stock adjustment creation deferred — skipped.")
    ctr.skipped = count
    audit.append({"action": "log", "count": count, "note": "stock adjustment creation deferred"})
    return ctr, audit


# ---------------------------------------------------------------------------
# Step 17: Item Transfers (log only)
# ---------------------------------------------------------------------------


def _step_item_transfers(
    acc_client: Any,
    since: str | None,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Fetching item transfers from Accurate (count only)...")
    try:
        raw_list = acc_client.list_all(
            "/accurate/api/item-transfer/list.do",
            params={"fields": "id,number", **_list_params(since)},
        )
        count = len(raw_list) if raw_list else 0
    except (RPCError, ConnectionError, ValueError) as exc:
        out.error(f"  Error fetching item transfers: {exc}")
        count = 0

    out.info(f"  Found {count} item transfers. stock.picking creation deferred — skipped.")
    ctr.skipped = count
    audit.append({"action": "log", "count": count, "note": "stock.picking creation deferred"})
    return ctr, audit


# ---------------------------------------------------------------------------
# Step 18: Validate Journals → compare Odoo GL vs Accurate JVs, fix mismatches
# ---------------------------------------------------------------------------

_AMOUNT_TOLERANCE = 1.0  # Rp 1 rounding tolerance


def _step_validate_journals(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    since: str | None,
    dry_run: bool,
    out: Any,
) -> tuple[_Counter, list[dict[str, Any]]]:
    """Validate Odoo journal entries against Accurate JVs and fix mismatches.

    Thin wrapper over jv_comparator + jv_fixer modules.
    """
    from kctl_odoo.commands._accurate_sync.jv_comparator import run_validation
    from kctl_odoo.commands._accurate_sync.jv_fixer import fix_mismatch

    ctr = _Counter()
    audit: list[dict[str, Any]] = []

    out.info("  Validating journal entries against Accurate JVs...")
    results = run_validation(c, acc_client, odoo_company)

    for r in results:
        if r.status == "ok":
            ctr.skipped += 1
            audit.append({"action": "ok", "jv_number": r.jv_number, "move_id": r.odoo_move_id})
        elif r.status == "missing":
            ctr.skipped += 1
            audit.append({"action": "skip", "jv_number": r.jv_number, "reason": "not in Odoo"})
        elif r.status == "mismatch":
            reasons = [d.message for d in r.discrepancies]
            out.info(f"  Mismatch: {r.jv_number} → {r.odoo_move_name}: {'; '.join(reasons)}")

            if dry_run:
                ctr.created += 1
                audit.append({"action": "fix_dry", "jv_number": r.jv_number, "reasons": reasons})
                continue

            result = fix_mismatch(c, odoo_company, r)
            if result.success:
                ctr.created += 1
                out.info(f"  Fixed: {result.message}")
                audit.append(
                    {"action": "fix", "jv_number": r.jv_number, "old": result.old_move_id, "new": result.new_move_id}
                )
            else:
                ctr.errors += 1
                out.error(f"  Fix failed: {result.message}")
                audit.append({"action": "fix_error", "jv_number": r.jv_number, "error": result.message})

    return ctr, audit


# ---------------------------------------------------------------------------
# fix-bill-expenses: backfill detailExpense lines on existing vendor bills
# ---------------------------------------------------------------------------


def fix_bill_expenses(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name (e.g. terra-buah-internusa)")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
    bill_ids: Annotated[
        str,
        typer.Option(
            "--bill-ids",
            help="Comma-separated Odoo account.move IDs to fix (e.g. 43558,41650)",
        ),
    ],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without making changes")] = False,
) -> None:
    """Backfill detailExpense (Biaya Lainnya) lines on existing vendor bills.

    For each vendor bill identified by ``--bill-ids``:
    1. Fetches the matching Accurate purchase-invoice detail by PI number (stored in
       ``account.move.ref``).
    2. Builds invoice lines from ``detailExpense`` using the same account resolution
       logic as the live sync.
    3. Resets the bill to draft, appends the new lines, then reposts.

    Bills that already have the correct expense lines (i.e. their current
    ``amount_total`` already matches Accurate's ``totalAmount``) are skipped.

    Example::

        kctl-odoo accurate fix-bill-expenses terra-buah-internusa \\
            -c 340 --bill-ids 43558,41650,41649,41645

    Use ``--dry-run`` to preview without writing to Odoo.
    """
    app_ctx: AppContext = ctx.obj
    c = app_ctx.client

    out = app_ctx.output
    acc_client = create_accurate_client(profile)

    ids_raw = [s.strip() for s in bill_ids.split(",") if s.strip()]
    if not ids_raw:
        out.error("No bill IDs provided. Use --bill-ids 123,456")
        raise typer.Exit(1)

    try:
        odoo_ids = [int(x) for x in ids_raw]
    except ValueError as exc:
        out.error(f"Invalid bill ID list: {exc}")
        raise typer.Exit(1) from exc

    out.info(f"Fetching {len(odoo_ids)} vendor bill(s) from Odoo (company {odoo_company})...")
    moves = c.search_read(
        "account.move",
        [["id", "in", odoo_ids], ["company_id", "=", odoo_company], ["move_type", "=", "in_invoice"]],
        fields=["id", "ref", "name", "amount_total", "state"],
    )
    if not moves:
        out.error("No matching vendor bills found.")
        raise typer.Exit(1)

    move_by_id = {m["id"]: m for m in moves}

    fixed = skipped = errors = 0

    for odoo_id in odoo_ids:
        move = move_by_id.get(odoo_id)
        if not move:
            out.info(f"  Bill id={odoo_id} not found or not a vendor bill in company {odoo_company} — skipping")
            skipped += 1
            continue

        pi_number: str = str(move.get("ref", "") or "").strip()
        bill_name: str = str(move.get("name", "") or "").strip()
        odoo_total: float = float(move.get("amount_total", 0.0) or 0.0)
        out.info(f"  Processing bill {bill_name!r} (id={odoo_id}, ref={pi_number!r}, Odoo total={odoo_total:,.0f})")

        if not pi_number:
            out.info(f"    Bill id={odoo_id} has no ref (PI number) — cannot look up in Accurate, skipping")
            skipped += 1
            continue

        # Fetch the matching PI from Accurate by number
        acc_list = acc_client.list_all(
            "/accurate/api/purchase-invoice/list.do",
            params={"fields": "id,number"},
        )
        acc_pi_id: int | None = None
        for row in acc_list or []:
            if str(row.get("number", "")).strip() == pi_number:
                acc_pi_id = int(row["id"])
                break

        if acc_pi_id is None:
            out.info(f"    Could not find Accurate PI {pi_number!r} — skipping")
            skipped += 1
            continue

        details = acc_client.detail_many("/accurate/api/purchase-invoice/detail.do", [acc_pi_id])
        if not details or details[0].get("__error__"):
            err = details[0].get("__error__") if details else "no detail returned"
            out.error(f"    Error fetching Accurate detail for PI {pi_number!r}: {err}")
            errors += 1
            continue

        detail = details[0]
        acc_total: float = float(detail.get("totalAmount", 0.0) or 0.0)
        expense_data: list[dict[str, Any]] = detail.get("detailExpense") or []

        out.info(f"    Accurate total={acc_total:,.0f}, expense entries={len(expense_data)}")

        if not expense_data:
            out.info(f"    No detailExpense in Accurate for {pi_number!r} — nothing to add")
            skipped += 1
            continue

        # Check if the bills already have the correct total (within 1 IDR rounding)
        if abs(odoo_total - acc_total) < 1.0:
            out.info(f"    Bill already matches Accurate total ({odoo_total:,.0f}) — skipping")
            skipped += 1
            continue

        # Build the expense invoice lines
        expense_lines = _build_expense_lines(c, odoo_company, expense_data, out)
        if not expense_lines:
            out.info(f"    No expense lines could be resolved for {pi_number!r} — skipping")
            skipped += 1
            continue

        out.info(f"    Will add {len(expense_lines)} expense line(s) to bill id={odoo_id}")
        for ln in expense_lines:
            lv = ln[2]
            out.info(
                f"      + account_id={lv.get('account_id')} name={lv.get('name')!r} amount={lv.get('price_unit'):,.0f}"
            )

        if dry_run:
            out.info(f"    [DRY-RUN] Would patch bill id={odoo_id} with {len(expense_lines)} expense line(s)")
            fixed += 1
            continue

        try:
            current_state: str = str(move.get("state", "posted"))
            if current_state == "posted":
                c.execute_kw("account.move", "button_draft", [[odoo_id]])
                out.info(f"    Reset bill id={odoo_id} to draft")

            # Append expense lines (do NOT delete existing lines)
            c.execute_kw("account.move", "write", [[odoo_id], {"invoice_line_ids": expense_lines}])

            # Repost
            c.execute_kw("account.move", "action_post", [[odoo_id]])
            out.info(f"    Reposted bill id={odoo_id} with expense lines added")

            fixed += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"    Failed to patch bill id={odoo_id}: {exc}")
            errors += 1

    out.info(f"\nDone: fixed={fixed}  skipped={skipped}  errors={errors}")
