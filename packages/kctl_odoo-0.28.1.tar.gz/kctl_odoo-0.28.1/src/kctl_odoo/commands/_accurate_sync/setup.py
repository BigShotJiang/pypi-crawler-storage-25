"""sync-setup: bootstrap an Odoo company to match an Accurate company's configuration.

Idempotent — safe to run multiple times.  Each of the 6 steps prints a
``created / fixed / skipped`` tally.
"""

from __future__ import annotations

from typing import Annotated, Any

import httpx
import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import (
    create_accurate_client,
    resolve_account_by_name,
    resolve_payment_term_by_name,
    resolve_uom_by_name,
)

# ---------------------------------------------------------------------------
# Accurate account-type → Odoo account_type mapping
# ---------------------------------------------------------------------------

_ACCURATE_TYPE_MAP: dict[str, str] = {
    "CASH_BANK": "asset_cash",
    "ACCOUNT_RECEIVABLE": "asset_receivable",
    "INVENTORY": "asset_current",
    "OTHER_CURRENT_ASSET": "asset_current",
    "FIXED_ASSET": "asset_fixed",
    "ACCUMULATED_DEPRECIATION": "asset_current",
    "ACCOUNT_PAYABLE": "liability_payable",
    "OTHER_CURRENT_LIABILITY": "liability_current",
    "LONG_TERM_LIABILITY": "liability_non_current",
    "EQUITY": "equity",
    "REVENUE": "income",
    "COGS": "expense_direct_cost",
    "EXPENSE": "expense",
    "OTHER_INCOME": "income_other",
    "OTHER_EXPENSE": "expense",
}

# ---------------------------------------------------------------------------
# Journal rename map  (English label → Indonesian)
# ---------------------------------------------------------------------------

_JOURNAL_RENAMES: dict[str, str] = {
    "Customer Invoices": "Faktur Penjualan",
    "Vendor Bills": "Faktur Pembelian",
    "Miscellaneous Operations": "Operasi Lain-lain",
    "Exchange Difference": "Selisih Kurs",
    "Cash Basis Taxes": "Pajak Kas Basis",
    "Cash": "Kas",
    "Inventory Valuation": "Penilaian Persediaan",
}

# Default accounts for specific journals
_JOURNAL_DEFAULTS: dict[str, dict[str, str]] = {
    "Operasi Lain-lain": {"default_account": "Biaya Umum"},
    "Selisih Kurs": {"default_account": "Laba/Rugi Selisih Kurs"},
}

# ---------------------------------------------------------------------------
# Currencies to seed rates for (if not already present)
# ---------------------------------------------------------------------------

_CURRENCIES_TO_SEED = ["CNY", "USD", "THB"]


# ---------------------------------------------------------------------------
# Counter helper
# ---------------------------------------------------------------------------


class _Counter:
    def __init__(self) -> None:
        self.created = 0
        self.fixed = 0
        self.skipped = 0

    def to_row(self, section: str) -> list[str]:
        return [section, str(self.created), str(self.fixed), str(self.skipped)]


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


def sync_setup(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name (e.g. terra-buah-internusa)")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without making changes")] = False,
) -> None:
    """Bootstrap an Odoo company from an Accurate Online company configuration.

    Runs 6 idempotent steps: COA sync, product categories, UoMs, payment terms,
    journals, and company defaults.  Use --dry-run to preview without writing.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Extend timeout for long-running Accurate API calls
    try:
        c._client.timeout = httpx.Timeout(1800.0)
    except (AttributeError, TypeError):
        pass

    dry_label = " (DRY-RUN)" if dry_run else ""
    out.header(f"sync-setup: profile={profile!r}  odoo_company={odoo_company}{dry_label}")

    acc_client = create_accurate_client(profile)

    summary_rows: list[list[str]] = []

    # -----------------------------------------------------------------------
    # Step 1: COA Sync
    # -----------------------------------------------------------------------
    out.info("Step 1/6: Syncing Chart of Accounts...")
    coa_ctr = _step_coa(c, acc_client, odoo_company, dry_run, out)
    summary_rows.append(coa_ctr.to_row("COA"))

    # -----------------------------------------------------------------------
    # Step 2: Product Categories
    # -----------------------------------------------------------------------
    out.info("Step 2/6: Syncing product categories...")
    cat_ctr = _step_product_categories(c, acc_client, odoo_company, dry_run, out)
    summary_rows.append(cat_ctr.to_row("Product Categories"))

    # -----------------------------------------------------------------------
    # Step 3: UoMs
    # -----------------------------------------------------------------------
    out.info("Step 3/6: Ensuring UoMs (CTN, RATE)...")
    uom_ctr = _step_uoms(c, dry_run, out)
    summary_rows.append(uom_ctr.to_row("UoMs"))

    # -----------------------------------------------------------------------
    # Step 4: Payment Terms
    # -----------------------------------------------------------------------
    out.info("Step 4/6: Syncing payment terms...")
    pt_ctr = _step_payment_terms(c, acc_client, dry_run, out)
    summary_rows.append(pt_ctr.to_row("Payment Terms"))

    # -----------------------------------------------------------------------
    # Step 5: Journals
    # -----------------------------------------------------------------------
    out.info("Step 5/6: Configuring journals...")
    jnl_ctr = _step_journals(c, acc_client, odoo_company, dry_run, out)
    summary_rows.append(jnl_ctr.to_row("Journals"))

    # -----------------------------------------------------------------------
    # Step 6: Company Defaults
    # -----------------------------------------------------------------------
    out.info("Step 6/6: Setting company defaults...")
    def_ctr = _step_company_defaults(c, odoo_company, dry_run, out)
    summary_rows.append(def_ctr.to_row("Company Defaults"))

    # -----------------------------------------------------------------------
    # Summary table
    # -----------------------------------------------------------------------
    out.table(
        f"sync-setup summary{dry_label}",
        [("Section", ""), ("Created", "green"), ("Fixed", "yellow"), ("Skipped", "dim")],
        summary_rows,
    )


# ---------------------------------------------------------------------------
# Step implementations
# ---------------------------------------------------------------------------


def _step_coa(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    # Fetch all GL accounts (list gives id+name only, then detail_many for type)
    raw_list = acc_client.list_all("/accurate/api/glaccount/list.do", params={"fields": "id,name"})
    if not raw_list:
        out.info("  No GL accounts found in Accurate.")
        return ctr

    acc_ids = [r["id"] for r in raw_list if isinstance(r.get("id"), int)]
    out.info(f"  Fetching details for {len(acc_ids)} GL accounts...")

    details = acc_client.detail_many("/accurate/api/glaccount/detail.do", acc_ids)

    # Build existing Odoo accounts index by name for the company
    existing = c.search_read(
        "account.account",
        domain=[["company_id", "=", odoo_company]],
        fields=["id", "name", "code", "account_type"],
        limit=0,
    )
    existing_by_name: dict[str, dict] = {r["name"]: r for r in existing}

    for detail in details:
        if detail.get("__error__"):
            out.error(f"  Error fetching GL account id={detail.get('id')}: {detail['__error__']}")
            continue

        acc_name: str = detail.get("name", "").strip()
        acc_type_raw: str = detail.get("accountType", "EXPENSE")
        acc_no: str = str(detail.get("number", "")).strip()
        odoo_type = _ACCURATE_TYPE_MAP.get(acc_type_raw, "expense")

        if acc_name in existing_by_name:
            ctr.skipped += 1
            continue

        if dry_run:
            out.info(f"  [DRY-RUN] Would create account: {acc_no} {acc_name!r} ({odoo_type})")
            ctr.created += 1
            continue

        vals: dict[str, Any] = {
            "name": acc_name,
            "account_type": odoo_type,
            "company_id": odoo_company,
        }
        if acc_no:
            vals["code"] = acc_no

        try:
            c.execute_kw("account.account", "create", [vals])
            ctr.created += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create account {acc_name!r}: {exc}")

    return ctr


def _step_product_categories(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    # Fetch item categories from Accurate
    raw_cats = acc_client.list_all("/accurate/api/item-category/list.do", params={"fields": "id,name"})
    if not raw_cats:
        out.info("  No item categories found in Accurate.")
        return ctr

    # Existing Odoo product categories
    existing_cats = c.search_read(
        "product.category",
        domain=[],
        fields=["id", "name"],
        limit=0,
    )
    existing_by_name: dict[str, int] = {r["name"]: r["id"] for r in existing_cats}

    for cat in raw_cats:
        cat_name: str = str(cat.get("name", "")).strip()
        if not cat_name:
            continue

        if cat_name in existing_by_name:
            ctr.skipped += 1
            continue

        # Fetch one sample item to discover GL accounts for this category
        sample_items = acc_client.list_all(
            "/accurate/api/item/list.do",
            params={"fields": "id", "filter.itemCategory.name": cat_name},
        )
        inventory_acct_id = None
        sales_acct_id = None
        cogs_acct_id = None
        purchase_acct_id = None  # Utang Pembelian Belum Ditagih

        if sample_items:
            try:
                sample_detail = acc_client.detail(
                    "/accurate/api/item/detail.do",
                    sample_items[0]["id"],
                )
                inv_acct_name = (sample_detail.get("inventoryGlAccount") or {}).get("name", "")
                sales_acct_name = (sample_detail.get("salesGlAccount") or {}).get("name", "")
                cogs_acct_name = (sample_detail.get("cogsGlAccount") or {}).get("name", "")

                if inv_acct_name:
                    inventory_acct_id = resolve_account_by_name(c, odoo_company, inv_acct_name)
                if sales_acct_name:
                    sales_acct_id = resolve_account_by_name(c, odoo_company, sales_acct_name)
                if cogs_acct_name:
                    cogs_acct_id = resolve_account_by_name(c, odoo_company, cogs_acct_name)
            except (RPCError, ConnectionError, ValueError) as exc:
                out.error(f"  Warning: could not fetch sample item for category {cat_name!r}: {exc}")

        # Utang Pembelian Belum Ditagih — standard purchase clearing account
        purchase_acct_id = resolve_account_by_name(
            c, odoo_company, "Utang Pembelian Belum Ditagih", account_type="liability_current"
        ) or resolve_account_by_name(c, odoo_company, "Utang Pembelian")

        if dry_run:
            out.info(
                f"  [DRY-RUN] Would create product category: {cat_name!r}"
                f" (inv={inventory_acct_id}, sales={sales_acct_id}, cogs={cogs_acct_id})"
            )
            ctr.created += 1
            continue

        vals: dict[str, Any] = {
            "name": cat_name,
            "property_valuation": "real_time",
            "property_cost_method": "fifo",
        }
        if inventory_acct_id:
            vals["property_stock_valuation_account_id"] = inventory_acct_id
        if purchase_acct_id:
            vals["property_stock_account_input_categ_id"] = purchase_acct_id
        if cogs_acct_id:
            vals["property_stock_account_output_categ_id"] = cogs_acct_id
            vals["property_account_expense_categ_id"] = cogs_acct_id
        if sales_acct_id:
            vals["property_account_income_categ_id"] = sales_acct_id

        try:
            c.execute_kw("product.category", "create", [vals])
            ctr.created += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create product category {cat_name!r}: {exc}")

    return ctr


def _step_uoms(
    c: Any,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    # Find the "Unit" category (id=1 typically, but query to be safe)
    uom_cats = c.search_read(
        "uom.category",
        domain=[["name", "ilike", "Unit"]],
        fields=["id", "name"],
        limit=1,
    )
    uom_cat_id: int | None = uom_cats[0]["id"] if uom_cats else None

    if uom_cat_id is None:
        out.error("  Could not find UoM category 'Unit' — skipping UoM creation.")
        return ctr

    # Fix duplicate reference UoMs in category — only one should be 'reference'
    ref_uoms = c.search_read(
        "uom.uom",
        domain=[["category_id", "=", uom_cat_id], ["uom_type", "=", "reference"]],
        fields=["id", "name"],
        limit=0,
    )
    if len(ref_uoms) > 1:
        # Keep the first (lowest id), demote the rest to 'bigger'
        extras = [r["id"] for r in ref_uoms[1:]]
        if not dry_run:
            try:
                c.execute_kw("uom.uom", "write", [[extras], {"uom_type": "bigger"}])
                ctr.fixed += len(extras)
                out.info(f"  Fixed {len(extras)} duplicate reference UoMs in 'Unit' category.")
            except (RPCError, ConnectionError, ValueError) as exc:
                out.error(f"  Could not fix duplicate reference UoMs: {exc}")
        else:
            out.info(f"  [DRY-RUN] Would fix {len(extras)} duplicate reference UoMs.")
            ctr.fixed += len(extras)

    for uom_name in ("CTN", "RATE"):
        existing_id = resolve_uom_by_name(c, uom_name)
        if existing_id:
            ctr.skipped += 1
            continue

        if dry_run:
            out.info(f"  [DRY-RUN] Would create UoM: {uom_name!r}")
            ctr.created += 1
            continue

        vals: dict[str, Any] = {
            "name": uom_name,
            "category_id": uom_cat_id,
            "uom_type": "bigger",
            "factor_inv": 1.0,
            "active": True,
        }
        try:
            c.execute_kw("uom.uom", "create", [vals])
            ctr.created += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create UoM {uom_name!r}: {exc}")

    return ctr


def _step_payment_terms(
    c: Any,
    acc_client: Any,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    raw_pts = acc_client.list_all("/accurate/api/payment-term/list.do", params={"fields": "id,name"})
    if not raw_pts:
        out.info("  No payment terms found in Accurate.")
        return ctr

    for pt in raw_pts:
        pt_name: str = str(pt.get("name", "")).strip()
        if not pt_name:
            continue

        existing_id = resolve_payment_term_by_name(c, pt_name)
        if existing_id:
            ctr.skipped += 1
            continue

        if dry_run:
            out.info(f"  [DRY-RUN] Would create payment term: {pt_name!r}")
            ctr.created += 1
            continue

        try:
            c.execute_kw(
                "account.payment.term",
                "create",
                [{"name": pt_name, "note": pt_name}],
            )
            ctr.created += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create payment term {pt_name!r}: {exc}")

    return ctr


def _step_journals(
    c: Any,
    acc_client: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    # --- 5a: Rename English default journal names to Indonesian ---
    for en_name, id_name in _JOURNAL_RENAMES.items():
        journals = c.search_read(
            "account.journal",
            domain=[
                ["company_id", "=", odoo_company],
                ["name", "=", en_name],
            ],
            fields=["id", "name"],
            limit=1,
        )
        if journals:
            jnl = journals[0]
            if dry_run:
                out.info(f"  [DRY-RUN] Would rename journal: {en_name!r} → {id_name!r}")
                ctr.fixed += 1
            else:
                try:
                    c.execute_kw("account.journal", "write", [[jnl["id"]], {"name": id_name}])
                    ctr.fixed += 1
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to rename journal {en_name!r}: {exc}")

    # --- 5b: Set default accounts on specific journals ---
    for jnl_name, defaults in _JOURNAL_DEFAULTS.items():
        journals = c.search_read(
            "account.journal",
            domain=[
                ["company_id", "=", odoo_company],
                ["name", "=", jnl_name],
            ],
            fields=["id", "name", "default_account_id"],
            limit=1,
        )
        if not journals:
            continue
        jnl = journals[0]
        if jnl.get("default_account_id"):
            ctr.skipped += 1
            continue
        acct_name = defaults.get("default_account", "")
        acct_id = resolve_account_by_name(c, odoo_company, acct_name) if acct_name else None
        if acct_id:
            if dry_run:
                out.info(f"  [DRY-RUN] Would set default account on {jnl_name!r} → {acct_name!r}")
                ctr.fixed += 1
            else:
                try:
                    c.execute_kw(
                        "account.journal",
                        "write",
                        [[jnl["id"]], {"default_account_id": acct_id}],
                    )
                    ctr.fixed += 1
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to set default account on {jnl_name!r}: {exc}")

    # --- 5c: Fix suspense accounts on bank/cash journals ---
    suspense_acct_id = resolve_account_by_name(
        c, odoo_company, "Bank Suspense", account_type="asset_current"
    ) or resolve_account_by_name(c, odoo_company, "Outstanding Receipts")

    if suspense_acct_id:
        bank_journals = c.search_read(
            "account.journal",
            domain=[
                ["company_id", "=", odoo_company],
                ["type", "in", ["bank", "cash"]],
            ],
            fields=["id", "name", "suspense_account_id"],
            limit=0,
        )
        for jnl in bank_journals:
            if jnl.get("suspense_account_id"):
                continue
            if dry_run:
                out.info(f"  [DRY-RUN] Would set suspense account on {jnl['name']!r}")
                ctr.fixed += 1
            else:
                try:
                    c.execute_kw(
                        "account.journal",
                        "write",
                        [[jnl["id"]], {"suspense_account_id": suspense_acct_id}],
                    )
                    ctr.fixed += 1
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to set suspense on {jnl['name']!r}: {exc}")

    # --- 5d: Create bank journals per Accurate CASH_BANK account ---
    raw_accounts = acc_client.list_all(
        "/accurate/api/glaccount/list.do",
        params={"fields": "id,name,accountType"},
    )
    cash_bank_accounts = [a for a in raw_accounts if a.get("accountType") == "CASH_BANK"]

    existing_journals = c.search_read(
        "account.journal",
        domain=[["company_id", "=", odoo_company], ["type", "in", ["bank", "cash"]]],
        fields=["id", "name", "type"],
        limit=0,
    )
    existing_journal_names = {j["name"] for j in existing_journals}

    for acc in cash_bank_accounts:
        jnl_name: str = str(acc.get("name", "")).strip()
        if not jnl_name or jnl_name in existing_journal_names:
            ctr.skipped += 1
            continue

        # Find the corresponding Odoo account
        odoo_acct_id = resolve_account_by_name(c, odoo_company, jnl_name, account_type="asset_cash")

        if dry_run:
            out.info(f"  [DRY-RUN] Would create bank journal: {jnl_name!r}")
            ctr.created += 1
            continue

        vals: dict[str, Any] = {
            "name": jnl_name,
            "type": "bank",
            "company_id": odoo_company,
            "code": jnl_name[:5].upper().replace(" ", ""),
        }
        if odoo_acct_id:
            vals["default_account_id"] = odoo_acct_id

        try:
            c.execute_kw("account.journal", "create", [vals])
            ctr.created += 1
            existing_journal_names.add(jnl_name)
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create bank journal {jnl_name!r}: {exc}")

    # --- 5e: Set profit/loss accounts on bank journals ---
    pl_acct_id = resolve_account_by_name(c, odoo_company, "Laba/Rugi") or resolve_account_by_name(
        c, odoo_company, "Profit/Loss"
    )
    if pl_acct_id:
        bank_journals_now = c.search_read(
            "account.journal",
            domain=[
                ["company_id", "=", odoo_company],
                ["type", "in", ["bank", "cash"]],
            ],
            fields=["id", "name", "profit_account_id", "loss_account_id"],
            limit=0,
        )
        for jnl in bank_journals_now:
            updates: dict[str, Any] = {}
            if not jnl.get("profit_account_id"):
                updates["profit_account_id"] = pl_acct_id
            if not jnl.get("loss_account_id"):
                updates["loss_account_id"] = pl_acct_id
            if not updates:
                continue
            if dry_run:
                out.info(f"  [DRY-RUN] Would set profit/loss accounts on {jnl['name']!r}")
                ctr.fixed += 1
            else:
                try:
                    c.execute_kw("account.journal", "write", [[jnl["id"]], updates])
                    ctr.fixed += 1
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to set profit/loss on {jnl['name']!r}: {exc}")

    # --- 5f: Fix payment_method_line outstanding accounts ---
    # Prevents "Incompatible companies on Outstanding Account" when using the
    # account.payment.register wizard for payments linked to bills/invoices.
    outstanding_receipts_id = resolve_account_by_name(
        c, odoo_company, "Outstanding Receipts", account_type="asset_current"
    ) or resolve_account_by_name(c, odoo_company, "Undeposited Funds")
    outstanding_payments_id = resolve_account_by_name(
        c, odoo_company, "Outstanding Payments", account_type="liability_current"
    )

    if outstanding_receipts_id or outstanding_payments_id:
        pml_records = c.search_read(
            "account.payment.method.line",
            domain=[["journal_id.company_id", "=", odoo_company], ["journal_id.type", "in", ["bank", "cash"]]],
            fields=["id", "name", "payment_type", "payment_account_id", "journal_id"],
            limit=0,
        )
        for pml in pml_records:
            pml_payment_type: str = str(pml.get("payment_type", "")).lower()
            target_acct_id: int | None = None
            if pml_payment_type == "inbound" and outstanding_receipts_id:
                target_acct_id = outstanding_receipts_id
            elif pml_payment_type == "outbound" and outstanding_payments_id:
                target_acct_id = outstanding_payments_id

            if target_acct_id is None:
                continue

            existing_acct = pml.get("payment_account_id")
            existing_acct_id = (
                existing_acct[0] if isinstance(existing_acct, (list, tuple)) and existing_acct else existing_acct
            )
            if existing_acct_id == target_acct_id:
                continue

            jnl_name: str = (
                pml.get("journal_id", [None, ""])[1] if isinstance(pml.get("journal_id"), (list, tuple)) else ""
            )
            if dry_run:
                out.info(
                    f"  [DRY-RUN] Would fix payment_method_line {pml['name']!r} "
                    f"({pml_payment_type}) on {jnl_name!r} → account_id={target_acct_id}"
                )
                ctr.fixed += 1
            else:
                try:
                    c.execute_kw(
                        "account.payment.method.line",
                        "write",
                        [[pml["id"]], {"payment_account_id": target_acct_id}],
                    )
                    ctr.fixed += 1
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to fix payment_method_line id={pml['id']!r}: {exc}")
    else:
        out.info("  Skipping payment_method_line fix: Outstanding accounts not found.")

    return ctr


def _step_company_defaults(
    c: Any,
    odoo_company: int,
    dry_run: bool,
    out: Any,
) -> _Counter:
    ctr = _Counter()

    company_rec = c.search_read(
        "res.company",
        domain=[["id", "=", odoo_company]],
        fields=[
            "id",
            "name",
            "partner_id",
            "account_sale_tax_id",
            "account_purchase_tax_id",
            "currency_exchange_journal_id",
        ],
        limit=1,
    )
    if not company_rec:
        out.error(f"  Company id={odoo_company} not found.")
        return ctr
    company = company_rec[0]

    company_updates: dict[str, Any] = {}

    # --- 6a: Set default sale/purchase taxes ---
    if not company.get("account_sale_tax_id"):
        ppn_out = c.search_read(
            "account.tax",
            domain=[
                ["company_id", "=", odoo_company],
                ["type_tax_use", "=", "sale"],
                ["name", "ilike", "PPN"],
                ["amount", "=", 11],
            ],
            fields=["id", "name"],
            limit=1,
        )
        if ppn_out:
            company_updates["account_sale_tax_id"] = ppn_out[0]["id"]

    if not company.get("account_purchase_tax_id"):
        ppn_in = c.search_read(
            "account.tax",
            domain=[
                ["company_id", "=", odoo_company],
                ["type_tax_use", "=", "purchase"],
                ["name", "ilike", "PPN"],
                ["amount", "=", 11],
            ],
            fields=["id", "name"],
            limit=1,
        )
        if ppn_in:
            company_updates["account_purchase_tax_id"] = ppn_in[0]["id"]

    # --- 6b: Set currency exchange journal ---
    if not company.get("currency_exchange_journal_id"):
        exch_journals = c.search_read(
            "account.journal",
            domain=[
                ["company_id", "=", odoo_company],
                ["name", "ilike", "Selisih Kurs"],
            ],
            fields=["id", "name"],
            limit=1,
        )
        if exch_journals:
            company_updates["currency_exchange_journal_id"] = exch_journals[0]["id"]

    if company_updates:
        if dry_run:
            out.info(f"  [DRY-RUN] Would update company defaults: {list(company_updates.keys())}")
            ctr.fixed += len(company_updates)
        else:
            try:
                c.execute_kw("res.company", "write", [[odoo_company], company_updates])
                ctr.fixed += len(company_updates)
            except (RPCError, ConnectionError, ValueError) as exc:
                out.error(f"  Failed to update company defaults: {exc}")
    else:
        ctr.skipped += 1

    # --- 6b2: Fix company partner default AP/AR accounts ---
    # Prevents vendor bills using "Trade Receivable" (company 1's account)
    # instead of the correct AP account from this company.
    company_partner_id_raw = company.get("partner_id")
    company_partner_id: int | None = (
        company_partner_id_raw[0]
        if isinstance(company_partner_id_raw, (list, tuple)) and company_partner_id_raw
        else company_partner_id_raw
        if isinstance(company_partner_id_raw, int)
        else None
    )
    if company_partner_id:
        ap_id = resolve_account_by_name(c, odoo_company, "Utang Usaha")
        if not ap_id:
            ap_id = resolve_account_by_name(c, odoo_company, "Utang Dagang IDR")
        ar_id = resolve_account_by_name(c, odoo_company, "Piutang Dagang IDR")
        if not ar_id:
            ar_id = resolve_account_by_name(c, odoo_company, "Piutang Usaha")

        partner_updates: dict[str, Any] = {}
        if ap_id:
            partner_updates["property_account_payable_id"] = ap_id
        if ar_id:
            partner_updates["property_account_receivable_id"] = ar_id

        if partner_updates:
            if dry_run:
                out.info(f"  [DRY-RUN] Would set company partner AP/AR accounts: AP={ap_id}, AR={ar_id}")
                ctr.fixed += len(partner_updates)
            else:
                try:
                    c.execute_kw("res.partner", "write", [[company_partner_id], partner_updates])
                    ctr.fixed += len(partner_updates)
                    out.info(f"  Set company partner id={company_partner_id} AP={ap_id} AR={ar_id}")
                except (RPCError, ConnectionError, ValueError) as exc:
                    out.error(f"  Failed to set company partner AP/AR accounts: {exc}")
        else:
            out.info("  Skipping company partner AP/AR fix: accounts not found in COA.")
            ctr.skipped += 1
    else:
        out.info("  Skipping company partner AP/AR fix: partner_id not found on company.")
        ctr.skipped += 1

    # --- 6c: Seed currency rates for CNY, USD, THB ---
    for curr_code in _CURRENCIES_TO_SEED:
        curr_ids = c.search(
            "res.currency",
            [["name", "=", curr_code], ["active", "in", [True, False]]],
            limit=1,
        )
        if not curr_ids:
            out.error(f"  Currency {curr_code} not found in Odoo — skipping rate seed.")
            continue
        curr_id = curr_ids[0]

        existing_rate = c.search_read(
            "res.currency.rate",
            domain=[["currency_id", "=", curr_id]],
            fields=["id"],
            limit=1,
        )
        if existing_rate:
            ctr.skipped += 1
            continue

        if dry_run:
            out.info(f"  [DRY-RUN] Would create placeholder rate for {curr_code}")
            ctr.created += 1
            continue

        try:
            c.execute_kw(
                "res.currency.rate",
                "create",
                [{"currency_id": curr_id, "rate": 1.0}],
            )
            ctr.created += 1
        except (RPCError, ConnectionError, ValueError) as exc:
            out.error(f"  Failed to create rate for {curr_code}: {exc}")

    return ctr
