"""Report management commands — split into focused sub-modules.

Includes both Odoo built-in ir.actions.report commands (list, render, templates,
generate) and custom report_management framework commands (types, run, instances,
view, export, download) and report creation/management commands.
"""

from __future__ import annotations

import typer

from .listing import app as _listing_app
from .listing import generate, list_, render, templates
from .mgmt_creation import app as _creation_app
from .mgmt_creation import (
    benchmark_report,
    convert_report,
    convert_status,
    report_add_line,
    report_create,
    report_preview,
    report_remove_line,
)
from .mgmt_framework import (
    CODE_ALIASES,
    _check_report_management,
    _default_date_range,
    _fiscal_year_start,
    _m2o,
    _resolve_type_code,
    batch_download,
    report_catalog,
    report_compare,
    report_data,
    report_download,
    report_export,
    report_instances,
    report_run,
    report_types,
    report_validate,
    report_verify_accurate,
    report_verify_math,
    report_view,
    schedule_report,
)
from .mgmt_framework import app as _framework_app

app = typer.Typer(help="Manage Odoo reports and generate diagnostic reports.")

# Merge all registered commands into this app
for _sub in [_listing_app, _framework_app, _creation_app]:
    for _cmd in _sub.registered_commands:
        app.registered_commands.append(_cmd)
    for _grp in _sub.registered_groups:
        app.registered_groups.append(_grp)

__all__ = [
    "app",
    # listing
    "list_",
    "render",
    "templates",
    "generate",
    # mgmt_framework
    "CODE_ALIASES",
    "_resolve_type_code",
    "_check_report_management",
    "_default_date_range",
    "_fiscal_year_start",
    "_m2o",
    "report_types",
    "report_run",
    "report_data",
    "report_compare",
    "report_instances",
    "report_view",
    "report_export",
    "report_download",
    "report_validate",
    "report_verify_accurate",
    "report_verify_math",
    "report_catalog",
    "schedule_report",
    "batch_download",
    # mgmt_creation
    "report_create",
    "report_add_line",
    "report_remove_line",
    "report_preview",
    "convert_status",
    "convert_report",
    "benchmark_report",
]
