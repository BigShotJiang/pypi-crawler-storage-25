"""Validation logic for production readiness audit."""

from __future__ import annotations

from typing import Any

from ._data import ACCOUNT_TYPES, CRITICAL_ACCOUNT_TYPES, _safe, _safe_id, _truncate

# ---------------------------------------------------------------------------
# Per-company comparison/check builder
# ---------------------------------------------------------------------------


def _row(company: str, **fields: Any) -> dict:
    out = {"Company": company}
    out.update(fields)
    return out


def _check_company(target: dict, ref: dict | None, company_name: str) -> dict[str, list[dict]]:
    """Compare one target company against the reference (if provided).

    Returns dict[sheet_name -> list[row_dict]].
    """
    sheets: dict[str, list[dict]] = {
        "Company Settings": [],
        "CoA - Account Listing": [],
        "Account Types Coverage": [],
        "Journals": [],
        "Taxes": [],
        "Tax Groups": [],
        "Fiscal Positions": [],
        "Payment Terms": [],
        "Product Categories": [],
        "Warehouses + Op Types": [],
        "Stock Locations": [],
        "Operating Units": [],
        "Report Layouts": [],
        "Report Management": [],
        "Sequences": [],
        "ir.property": [],
        "Config Coverage": [],
        "Product Quality": [],
        "Partner Quality": [],
        "Category Quality": [],
        "Bank Journal Quality": [],
        "Financial Reports Setup": [],
        "Top Issues": [],
    }

    # ── Company Settings ────────────────────────────────────────────────
    co_t = target.get("company") or {}
    co_r = (ref or {}).get("company") or {}

    def cmp_setting(label: str, tval: Any, rval: Any, status: str, note: str = "") -> dict:
        return _row(
            company_name,
            Setting=label,
            Value=tval,
            **{"Reference Value": rval if ref else "(no reference)"},
            Status=status,
            Note=note,
        )

    # currency
    t = _safe(co_t.get("currency_id"), "Not set")
    r = _safe(co_r.get("currency_id"), "")
    sheets["Company Settings"].append(cmp_setting("Currency", t, r, "PASS" if t == "IDR" else "WARN"))

    # Fiscal country — only show "Should be Indonesia" hint when not yet set
    t = _safe(co_t.get("account_fiscal_country_id"), "Not set")
    r = _safe(co_r.get("account_fiscal_country_id"), "")
    is_indonesia = "Indonesia" in t
    sheets["Company Settings"].append(
        cmp_setting(
            "Fiscal Country",
            t,
            r,
            "PASS" if is_indonesia else "WARN",
            note="" if is_indonesia else "Should be Indonesia",
        )
    )

    # Default sale tax / purchase tax
    for fld, label in [
        ("account_sale_tax_id", "Default Sale Tax"),
        ("account_purchase_tax_id", "Default Purchase Tax"),
    ]:
        t = _safe(co_t.get(fld), "Not set")
        r = _safe(co_r.get(fld), "")
        sheets["Company Settings"].append(cmp_setting(label, t, r, "PASS" if co_t.get(fld) else "FAIL"))

    # FX accounts + transfer + suspense + cash diff. Outstanding receipts /
    # payments live on account.payment.method.line per journal in Odoo 18,
    # not as company defaults — verified per-journal in Bank Journal Quality.
    for fld, label, level in [
        ("income_currency_exchange_account_id", "FX Income Account", "WARN"),
        ("expense_currency_exchange_account_id", "FX Expense Account", "WARN"),
        ("transfer_account_id", "Transfer Account", "WARN"),
        ("account_journal_suspense_account_id", "Journal Suspense Account", "WARN"),
        ("default_cash_difference_income_account_id", "Cash Diff Income Account", "INFO"),
        ("default_cash_difference_expense_account_id", "Cash Diff Expense Account", "INFO"),
    ]:
        t = _safe(co_t.get(fld), "Not set")
        r = _safe(co_r.get(fld), "")
        ok = bool(co_t.get(fld))
        status = "PASS" if ok else level
        sheets["Company Settings"].append(cmp_setting(label, t, r, status))

    # Booleans + scalars
    for fld, label in [
        ("anglo_saxon_accounting", "Anglo-Saxon Accounting"),
        ("fiscalyear_lock_date", "Fiscal Year Lock"),
        ("tax_lock_date", "Tax Lock"),
        ("po_lock", "PO Lock"),
        ("po_double_validation", "PO Double Validation"),
        ("po_double_validation_amount", "PO Double Validation Amount"),
        ("po_lead", "PO Lead Time"),
        ("quotation_validity_days", "Quotation Validity (days)"),
        ("portal_confirmation_sign", "Portal Sign Confirmation"),
        ("portal_confirmation_pay", "Portal Pay Confirmation"),
    ]:
        t = co_t.get(fld)
        r = co_r.get(fld)
        sheets["Company Settings"].append(
            cmp_setting(
                label,
                "" if t in (False, None) else str(t),
                "" if r in (False, None) else str(r),
                "INFO",
            )
        )

    # Logo
    has_logo = bool(co_t.get("logo"))
    has_logo_ref = bool(co_r.get("logo"))
    sheets["Company Settings"].append(
        cmp_setting(
            "Logo",
            "Set" if has_logo else "Missing",
            "Set" if has_logo_ref else "Missing" if ref else "",
            "PASS" if has_logo else "WARN",
        )
    )

    # ── CoA - Account Listing ───────────────────────────────────────────
    accounts = target.get("accounts") or []
    ext = target.get("account_ext_ids") or {}
    for a in accounts:
        sheets["CoA - Account Listing"].append(
            _row(
                company_name,
                Code=a.get("code") or "",
                Name=a.get("name") or "",
                Type=a.get("account_type") or "",
                **{"Has Ext-ID": "Yes" if ext.get(a["id"]) else "No"},
                **{"Ext-ID": ext.get(a["id"], "")},
                Deprecated="Yes" if a.get("deprecated") else "No",
                Status="PASS" if a.get("code") else "FAIL",
                **{"Vs Reference": ""},
            )
        )

    # ── Account Types Coverage ──────────────────────────────────────────
    by_type_t: dict[str, int] = {}
    for a in accounts:
        by_type_t[a.get("account_type") or ""] = by_type_t.get(a.get("account_type") or "", 0) + 1

    by_type_r: dict[str, int] = {}
    if ref:
        for a in ref.get("accounts") or []:
            by_type_r[a.get("account_type") or ""] = by_type_r.get(a.get("account_type") or "", 0) + 1

    for at in ACCOUNT_TYPES:
        tcnt = by_type_t.get(at, 0)
        rcnt = by_type_r.get(at, 0)
        if at in CRITICAL_ACCOUNT_TYPES:
            status = "PASS" if tcnt >= 1 else "FAIL"
        elif tcnt == 0 and rcnt > 0:
            status = "WARN"
        else:
            status = "INFO"
        sheets["Account Types Coverage"].append(
            _row(
                company_name,
                **{"Account Type": at},
                **{"Target Count": tcnt},
                **{"Reference Count": rcnt if ref else "-"},
                Status=status,
                Note="Critical type" if at in CRITICAL_ACCOUNT_TYPES else "",
            )
        )

    # ── Journals ────────────────────────────────────────────────────────
    journals = target.get("journals") or []
    ref_journals = (ref or {}).get("journals") or []
    ref_codes = {j.get("code") for j in ref_journals}
    target_codes = {j.get("code") for j in journals}

    for j in journals:
        active = j.get("active")
        has_default = bool(j.get("default_account_id"))
        jtype = j.get("type") or ""
        if active and not has_default and jtype != "general":
            status = "FAIL"
            note = "Active journal missing default account"
        else:
            status = "PASS"
            note = ""
        sheets["Journals"].append(
            _row(
                company_name,
                Code=j.get("code") or "",
                Type=jtype,
                Name=j.get("name") or "",
                **{"Default Account": _safe(j.get("default_account_id"))},
                **{"Suspense Account": _safe(j.get("suspense_account_id"))},
                Currency=_safe(j.get("currency_id")),
                Active="Yes" if active else "No",
                Status=status,
                Note=note,
                **{"Vs Reference": "in reference" if j.get("code") in ref_codes else "(target only)"},
            )
        )

    # Missing journal codes (in reference but not in target)
    if ref:
        missing = ref_codes - target_codes
        for code in sorted(c or "" for c in missing if c):
            ref_j = next((j for j in ref_journals if j.get("code") == code), {})
            sheets["Journals"].append(
                _row(
                    company_name,
                    Code=code,
                    Type=ref_j.get("type") or "",
                    Name="(missing — present in reference)",
                    **{"Default Account": ""},
                    **{"Suspense Account": ""},
                    Currency="",
                    Active="No",
                    Status="WARN",
                    Note="Journal in reference but missing in target",
                    **{"Vs Reference": "reference only"},
                )
            )

    # ── Taxes ───────────────────────────────────────────────────────────
    taxes = target.get("taxes") or []
    tax_accounts = target.get("tax_accounts") or {}
    ref_taxes = (ref or {}).get("taxes") or []
    ref_tax_names = {(t.get("name"), t.get("type_tax_use")) for t in ref_taxes}

    for t in taxes:
        gl_accs = tax_accounts.get(t["id"], [])
        gl_str = ", ".join(gl_accs) if gl_accs else ""
        active = t.get("active")
        # 0%-amount taxes (PPN Bebas / Exempt / Zero-rated) have no GL impact —
        # the tax account is intentionally blank. Don't fail those.
        is_zero_rate = abs(float(t.get("amount") or 0.0)) < 1e-9
        if active and not gl_accs and not is_zero_rate:
            status = "FAIL"
            note = "Active tax missing GL account on repartition"
        elif active and not gl_accs and is_zero_rate:
            status = "PASS"
            note = "0%/exempt — no GL needed"
        else:
            status = "PASS"
            note = ""
        in_ref = (t.get("name"), t.get("type_tax_use")) in ref_tax_names
        sheets["Taxes"].append(
            _row(
                company_name,
                Name=t.get("name") or "",
                **{"Type Use": t.get("type_tax_use") or ""},
                Amount=t.get("amount"),
                **{"Amount Type": t.get("amount_type") or ""},
                **{"Tax Group": _safe(t.get("tax_group_id"))},
                **{"GL Account(s)": gl_str},
                Active="Yes" if active else "No",
                Status=status,
                Note=note,
                **{"Vs Reference": "in reference" if in_ref else "(target only)"} if ref else {"Vs Reference": ""},
            )
        )

    # ── Tax Groups ──────────────────────────────────────────────────────
    tgroups = target.get("tax_groups") or []
    used_groups = {_safe_id(t.get("tax_group_id")) for t in taxes if t.get("active")}
    for g in tgroups:
        used = g["id"] in used_groups
        has_payable = bool(g.get("tax_payable_account_id"))
        has_recv = bool(g.get("tax_receivable_account_id"))
        if used and not (has_payable and has_recv):
            status = "WARN"
            note = "Used by active taxes but missing payable/receivable account"
        else:
            status = "PASS"
            note = ""
        sheets["Tax Groups"].append(
            _row(
                company_name,
                **{"Group Name": g.get("name") or ""},
                **{"Payable Account": _safe(g.get("tax_payable_account_id"))},
                **{"Receivable Account": _safe(g.get("tax_receivable_account_id"))},
                **{"Advance Account": _safe(g.get("advance_tax_payment_account_id"))},
                **{"Used By Active Tax": "Yes" if used else "No"},
                Status=status,
                Note=note,
                **{"Vs Reference": ""},
            )
        )

    # ── Fiscal Positions ────────────────────────────────────────────────
    fps = target.get("fiscal_positions") or []
    for fp in fps:
        sheets["Fiscal Positions"].append(
            _row(
                company_name,
                Name=fp.get("name") or "",
                Country=_safe(fp.get("country_id")),
                **{"Auto Apply": "Yes" if fp.get("auto_apply") else "No"},
                **{"# Account Mappings": len(fp.get("account_ids") or [])},
                **{"# Tax Mappings": len(fp.get("tax_ids") or [])},
                Status="PASS",
                **{"Vs Reference": ""},
            )
        )
    if not fps:
        sheets["Fiscal Positions"].append(
            _row(
                company_name,
                Name="(none)",
                Country="",
                **{"Auto Apply": ""},
                **{"# Account Mappings": 0},
                **{"# Tax Mappings": 0},
                Status="WARN",
                **{"Vs Reference": ""},
            )
        )

    # ── Payment Terms ───────────────────────────────────────────────────
    pterms = target.get("payment_terms") or []
    ref_pterms = (ref or {}).get("payment_terms") or []
    ref_names = {p.get("name") for p in ref_pterms}
    for pt in pterms:
        in_ref = pt.get("name") in ref_names
        sheets["Payment Terms"].append(
            _row(
                company_name,
                **{"Term ID": pt.get("id")},
                Name=pt.get("name") or "",
                Active="Yes" if pt.get("active") else "No",
                **{"Early Discount": "Yes" if pt.get("early_discount") else "No"},
                Status="PASS" if pt.get("active") else "INFO",
                **{"Vs Reference": "in reference" if in_ref else ("(target only)" if ref else "")},
            )
        )

    # ── Product Categories ──────────────────────────────────────────────
    cats = target.get("categories") or []
    for c in cats:
        valuation = c.get("property_valuation") or ""
        has_in = bool(c.get("property_account_income_categ_id"))
        has_ex = bool(c.get("property_account_expense_categ_id"))
        has_stock = (
            bool(c.get("property_stock_account_input_categ_id"))
            and bool(c.get("property_stock_account_output_categ_id"))
            and bool(c.get("property_stock_valuation_account_id"))
        )
        if not (has_in and has_ex):
            status = "FAIL"
            note = "Missing income or expense account"
        elif valuation == "real_time" and not has_stock:
            status = "WARN"
            note = "Real-time valuation missing stock accounts"
        else:
            status = "PASS"
            note = ""
        sheets["Product Categories"].append(
            _row(
                company_name,
                Name=c.get("name") or "",
                **{"Cost Method": c.get("property_cost_method") or ""},
                Valuation=valuation,
                Income=_safe(c.get("property_account_income_categ_id")),
                Expense=_safe(c.get("property_account_expense_categ_id")),
                **{"Stock Input": _safe(c.get("property_stock_account_input_categ_id"))},
                **{"Stock Output": _safe(c.get("property_stock_account_output_categ_id"))},
                **{"Stock Valuation": _safe(c.get("property_stock_valuation_account_id"))},
                **{"Stock Journal": _safe(c.get("property_stock_journal"))},
                Status=status,
                Note=note,
            )
        )

    # ── Warehouses + Operation Types ────────────────────────────────────
    whs = target.get("warehouses") or []
    if whs:
        for w in whs:
            sheets["Warehouses + Op Types"].append(
                _row(
                    company_name,
                    Section="Warehouse",
                    Code=w.get("code") or "",
                    Name=w.get("name") or "",
                    **{"Stock Loc / Source": _safe(w.get("lot_stock_id"))},
                    **{"Reception Steps / Dest": w.get("reception_steps") or ""},
                    **{"Delivery Steps / Type": w.get("delivery_steps") or ""},
                    Active="Yes" if w.get("active") else "No",
                    Status="PASS",
                )
            )
    else:
        sheets["Warehouses + Op Types"].append(
            _row(
                company_name,
                Section="Warehouse",
                Code="",
                Name="(none)",
                **{"Stock Loc / Source": ""},
                **{"Reception Steps / Dest": ""},
                **{"Delivery Steps / Type": ""},
                Active="",
                Status="FAIL",
            )
        )

    pts = target.get("picking_types") or []
    for p in pts:
        sheets["Warehouses + Op Types"].append(
            _row(
                company_name,
                Section="Operation Type",
                Code=p.get("sequence_code") or "",
                Name=p.get("name") or "",
                **{"Stock Loc / Source": _safe(p.get("default_location_src_id"))},
                **{"Reception Steps / Dest": _safe(p.get("default_location_dest_id"))},
                **{"Delivery Steps / Type": p.get("code") or ""},
                Active="Yes",
                Status="PASS",
            )
        )

    # ── Stock Locations ─────────────────────────────────────────────────
    locs = target.get("locations") or []
    by_usage: dict[str, int] = {}
    for l in locs:
        by_usage[l.get("usage") or ""] = by_usage.get(l.get("usage") or "", 0) + 1
    for usage, count in sorted(by_usage.items()):
        sheets["Stock Locations"].append(
            _row(
                company_name,
                **{"Location Type": usage},
                Count=count,
                Note="",
                Status="PASS" if count >= 1 else "WARN",
            )
        )
    ss = target.get("stock_summary") or {}
    sheets["Stock Locations"].append(
        _row(
            company_name,
            **{"Location Type": "(summary)"},
            Count=ss.get("quants") or 0,
            Note=f"Quants={ss.get('quants', 0)}, Distinct products with qty>0={ss.get('products_with_stock', 0)}, SVL records={ss.get('svl_count', 0)}",
            Status="INFO",
        )
    )

    # ── Operating Units ─────────────────────────────────────────────────
    ous = target.get("operating_units")
    counts = target.get("ou_user_counts") or {}
    if ous == "MODULE_NOT_INSTALLED":
        sheets["Operating Units"].append(
            _row(
                company_name,
                Code="",
                **{"OU Name": "(operating_unit module not installed)"},
                Partner="",
                **{"# Users Assigned": 0},
                Active="",
                Status="WARN",
            )
        )
    elif not ous:
        sheets["Operating Units"].append(
            _row(
                company_name,
                Code="",
                **{"OU Name": "(no operating units configured)"},
                Partner="",
                **{"# Users Assigned": 0},
                Active="",
                Status="WARN",
            )
        )
    else:
        for ou in ous:
            sheets["Operating Units"].append(
                _row(
                    company_name,
                    Code=ou.get("code") or "",
                    **{"OU Name": ou.get("name") or ""},
                    Partner=_safe(ou.get("partner_id")),
                    **{"# Users Assigned": counts.get(ou["id"], 0)},
                    Active="Yes" if ou.get("active") else "No",
                    Status="PASS" if ou.get("active") else "WARN",
                )
            )

    # ── Report Layouts ──────────────────────────────────────────────────
    rfmt = target.get("report_formats")
    ref_rfmt = (ref or {}).get("report_formats") if ref else None
    if rfmt == "MODULE_NOT_INSTALLED":
        sheets["Report Layouts"].append(
            _row(
                company_name,
                **{"Report Type": "(report_layout module not installed)"},
                **{"Format Name": ""},
                **{"Is Default": ""},
                **{"# Bands": 0},
                **{"# Signature Lines": 0},
                **{"Has Logo": ""},
                **{"Theme Preset": ""},
                Status="N/A",
                Note="Module not installed",
            )
        )
    else:
        target_default_types = {f["report_type"] for f in (rfmt or []) if f.get("is_default")}
        for f in rfmt or []:
            sheets["Report Layouts"].append(
                _row(
                    company_name,
                    **{"Report Type": f.get("report_type") or ""},
                    **{"Format Name": f.get("name") or ""},
                    **{"Is Default": "Yes" if f.get("is_default") else "No"},
                    **{"# Bands": len(f.get("band_ids") or [])},
                    **{"# Signature Lines": len(f.get("signature_line_ids") or [])},
                    **{"Has Logo": "Yes" if f.get("show_logo") else "No"},
                    **{"Theme Preset": f.get("theme_preset") or ""},
                    Status="PASS" if f.get("active") else "WARN",
                    Note="",
                )
            )
        # Compare report types
        if isinstance(ref_rfmt, list):
            ref_default_types = {f["report_type"] for f in ref_rfmt if f.get("is_default")}
            missing = ref_default_types - target_default_types
            for rt in sorted(missing):
                sheets["Report Layouts"].append(
                    _row(
                        company_name,
                        **{"Report Type": rt},
                        **{"Format Name": "(missing default)"},
                        **{"Is Default": "No"},
                        **{"# Bands": 0},
                        **{"# Signature Lines": 0},
                        **{"Has Logo": ""},
                        **{"Theme Preset": ""},
                        Status="FAIL",
                        Note="Reference has a default for this type — target has none",
                    )
                )

    # ── Report Management Instances ─────────────────────────────────────
    rinst = target.get("report_instances")
    rtypes = target.get("report_types")
    if rinst == "MODULE_NOT_INSTALLED":
        sheets["Report Management"].append(
            _row(
                company_name,
                Section="Instance",
                Name="(report_management_financial not installed)",
                Template="",
                **{"Report Type / Handler": ""},
                Status="N/A",
            )
        )
    else:
        if not rinst:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Instance",
                    Name="(no instances configured)",
                    Template="",
                    **{"Report Type / Handler": ""},
                    Status="WARN",
                )
            )
        for inst in rinst or []:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Instance",
                    Name=inst.get("name") or "",
                    Template=_safe(inst.get("template_id")),
                    **{"Report Type / Handler": inst.get("report_type") or ""},
                    Status="PASS",
                )
            )
    if isinstance(rtypes, list):
        for rt in rtypes:
            sheets["Report Management"].append(
                _row(
                    company_name,
                    Section="Registered Type",
                    Name=rt.get("name") or "",
                    Template=rt.get("category") or "",
                    **{"Report Type / Handler": rt.get("handler") or rt.get("code") or ""},
                    Status="INFO",
                )
            )

    # ── Sequences ───────────────────────────────────────────────────────
    seqs = target.get("sequences") or []
    for s in seqs:
        prefix = s.get("prefix") or ""
        suffix = s.get("suffix") or ""
        padding = s.get("padding") or 0
        # Build an example of the pattern, e.g. "INV/2026/04/00001"
        sample_seq = "0" * padding if padding else "0"
        sample = f"{prefix}{sample_seq}{suffix}"
        sheets["Sequences"].append(
            _row(
                company_name,
                Code=s.get("code") or "",
                Name=s.get("name") or "",
                Prefix=prefix,
                Suffix=suffix,
                **{"Sample Number": sample},
                **{"Number Next": s.get("number_next") or 0},
                Padding=padding,
                **{"Date Range": "Yes" if s.get("use_date_range") else "No"},
                Implementation=s.get("implementation") or "",
                Active="Yes" if s.get("active") else "No",
                Status="PASS" if s.get("active") else "WARN",
            )
        )

    # ── Company Defaults (advanced) ─────────────────────────────────────
    # ir.property was removed in Odoo 18 — company-dependent values are now
    # stored on company_dependent fields (JSONB columns). This sheet shows
    # the resolved per-company defaults that previously lived in ir.property.
    co_props = target.get("company") or {}
    co_ref = (ref or {}).get("company") or {}
    company_default_fields = [
        ("currency_id", "Currency"),
        ("account_fiscal_country_id", "Fiscal Country"),
        ("account_sale_tax_id", "Default Sale Tax"),
        ("account_purchase_tax_id", "Default Purchase Tax"),
        ("income_currency_exchange_account_id", "FX Income Account"),
        ("expense_currency_exchange_account_id", "FX Expense Account"),
        ("transfer_account_id", "Transfer Account"),
        ("account_journal_suspense_account_id", "Journal Suspense Account"),
        ("default_cash_difference_income_account_id", "Cash Difference Income"),
        ("default_cash_difference_expense_account_id", "Cash Difference Expense"),
    ]
    for fld, label in company_default_fields:
        tval = _safe(co_props.get(fld), "")
        rval = _safe(co_ref.get(fld), "")
        is_set = bool(co_props.get(fld))
        ref_set = bool(co_ref.get(fld))
        if is_set and ref_set and tval == rval:
            status = "PASS"
        elif is_set:
            status = "PASS" if tval else "WARN"
        else:
            status = "WARN" if not ref else ("FAIL" if ref_set else "INFO")
        sheets["ir.property"].append(
            _row(
                company_name,
                Field=fld,
                Label=label,
                Value=tval or "(not set)",
                **{"Reference Value": rval if ref else "-"},
                Status=status,
            )
        )

    # ── Config Coverage — compare every Configuration menu item ─────────
    target_cov = target.get("config_coverage") or []
    ref_cov_list = (ref or {}).get("config_coverage") or []
    # Index ref by (Menu, Item) for fast lookup
    ref_cov_idx = {(r["Menu"], r["Item"]): r for r in ref_cov_list}

    for tcov in target_cov:
        key = (tcov["Menu"], tcov["Item"])
        rcov = ref_cov_idx.get(key, {})
        ref_count = rcov.get("Count", 0) if rcov.get("Available") else None
        ref_avail = rcov.get("Available", False)

        # Determine status
        target_count = tcov["Count"]
        target_avail = tcov["Available"]
        status = "INFO"
        note = ""

        if not target_avail and tcov.get("Error") == "MODULE_NOT_INSTALLED":
            if ref_avail and ref_count and ref_count > 0:
                status = "FAIL"
                note = f"Module not installed in target; reference has {ref_count}"
            else:
                status = "N/A"
                note = "Module not installed in either"
        elif not target_avail:
            status = "WARN"
            note = f"Error: {tcov.get('Error', 'unknown')[:80]}"
        elif ref is None or not ref_avail:
            # No reference — pure existence
            if target_count == 0:
                status = "WARN"
                note = "0 records (no reference to compare)"
            else:
                status = "PASS"
        else:
            # Both available — compare counts
            if target_count == 0 and ref_count > 0:
                status = "FAIL"
                note = f"Target has 0; reference has {ref_count}"
            elif target_count < ref_count:
                status = "WARN"
                note = f"Target has {target_count}; reference has {ref_count} (missing {ref_count - target_count})"
            elif target_count >= ref_count:
                status = "PASS"
                note = f"Target has {target_count}; reference has {ref_count}"

        sheets["Config Coverage"].append(
            _row(
                company_name,
                Menu=tcov["Menu"],
                Item=tcov["Item"],
                Model=tcov["Model"],
                Scope=tcov["Scope"],
                **{"Target Count": target_count if target_avail else "-"},
                **{"Reference Count": ref_count if ref_avail else ("-" if ref else "(no ref)")},
                Status=status,
                Note=note,
            )
        )

    # ── Product Quality — per-product missing fields with severity ──────
    products = target.get("products_sample") or []
    for p in products:
        # Filter to this company (or company-shared)
        p_co = _safe_id(p.get("company_id"))
        if p_co and p_co != target["company_id"]:
            continue
        ptype = p.get("type") or p.get("detailed_type") or ""
        is_storable = ptype == "product"  # only "product" is stockable in Odoo 18
        is_service = ptype == "service"

        # CRITICAL issues — block business operations
        critical = []
        if not p.get("uom_id"):
            critical.append("no UoM")
        if not p.get("categ_id"):
            critical.append("no category")
        if is_storable and not p.get("standard_price"):
            critical.append("no standard_price (storable)")

        # IMPORTANT — needed for normal workflows
        important = []
        if not p.get("default_code"):
            important.append("no default_code")
        if not p.get("uom_po_id") and (p.get("uom_id") != p.get("uom_po_id")):
            # Only flag if uom_po differs and is missing
            if not p.get("uom_po_id"):
                important.append("no Purchase UoM")
        if not (p.get("taxes_id") or []) and not is_service:
            important.append("no sale tax (uses category default if any)")
        if not (p.get("supplier_taxes_id") or []) and not is_service:
            important.append("no purchase tax (uses category default if any)")

        # INFO — overrides, normal to be empty (use category defaults)
        info_issues = []
        # Only flag missing income/expense overrides if the category itself doesn't have them
        # We'll skip these as they're usually fine to leave empty
        # if not p.get("property_account_income_id"):
        #     info_issues.append("no income account override")

        all_issues = critical + important + info_issues
        # Show every product (not only ones with issues) so the catalog is
        # visible in the audit. Status reflects the worst-case severity, with
        # PASS for products that have all required fields.
        if critical:
            severity = "CRITICAL"
            status = "FAIL"
        elif important:
            severity = "IMPORTANT"
            status = "WARN"
        elif info_issues:
            severity = "INFO"
            status = "INFO"
        else:
            severity = ""
            status = "PASS"

        sheets["Product Quality"].append(
            _row(
                company_name,
                **{"Product ID": p.get("id")},
                Name=_truncate(p.get("name"), 60),
                Code=p.get("default_code") or "(none)",
                Type=ptype or "?",
                Severity=severity,
                Category=_safe(p.get("categ_id")),
                **{"Missing Fields": ", ".join(all_issues) if all_issues else "-"},
                **{"Fix": "Inventory > Products > <product> — set the missing field" if all_issues else ""},
                Status=status,
                **{"Issue Count": len(all_issues)},
            )
        )

    # ── Partner Quality — smart checks per partner type ─────────────────
    partners = target.get("partners_sample") or []
    for prt in partners:
        # Filter to this company (or company-shared)
        prt_co = _safe_id(prt.get("company_id"))
        if prt_co and prt_co != target["company_id"]:
            continue
        is_customer = (prt.get("customer_rank") or 0) > 0
        is_vendor = (prt.get("supplier_rank") or 0) > 0
        is_company = prt.get("is_company")
        # B2C heuristic: individual customers (not is_company), low rank
        is_b2c = is_customer and not is_company and not is_vendor

        # CRITICAL — blocks invoicing / payment
        critical = []
        if not prt.get("name"):
            critical.append("no name")
        if is_customer and not prt.get("property_account_receivable_id"):
            critical.append("no AR account")
        if is_vendor and not prt.get("property_account_payable_id"):
            critical.append("no AP account")

        # IMPORTANT — needed for compliance / communication
        important = []
        if not prt.get("country_id"):
            important.append("no country")
        # NPWP only mandatory for companies (B2B), not B2C individuals
        if is_company and not prt.get("vat"):
            important.append("no NPWP (company)")
        # Contact info only mandatory for vendors (we need to send POs/payments)
        if is_vendor and not prt.get("email") and not prt.get("phone") and not prt.get("mobile"):
            important.append("no contact (vendor)")
        if is_vendor and is_company and not (prt.get("bank_ids") or []):
            important.append("no bank account (company vendor)")

        # INFO — recommended but not required
        info_issues = []
        if is_company and is_customer and not prt.get("property_payment_term_id"):
            info_issues.append("no customer payment term")
        if is_company and is_vendor and not prt.get("property_supplier_payment_term_id"):
            info_issues.append("no vendor payment term")

        all_issues = critical + important + info_issues
        if not all_issues:
            continue

        # B2C with only minor issues: skip entirely (reduces noise)
        if is_b2c and not critical and not important:
            continue

        if critical:
            severity = "CRITICAL"
            status = "FAIL"
        elif important:
            severity = "IMPORTANT"
            status = "WARN"
        else:
            severity = "INFO"
            status = "INFO"

        ptype = "Customer" if is_customer and not is_vendor else ("Vendor" if is_vendor and not is_customer else "Both")
        if is_b2c:
            ptype += " (B2C)"

        sheets["Partner Quality"].append(
            _row(
                company_name,
                **{"Partner ID": prt.get("id")},
                Name=_truncate(prt.get("name"), 60),
                Type=ptype,
                Severity=severity,
                VAT=prt.get("vat") or "(none)",
                Email=prt.get("email") or "",
                **{"Missing Fields": ", ".join(all_issues)},
                **{"Fix": "Contacts > <partner> > Sales & Purchase tab — set property accounts"},
                Status=status,
                **{"Issue Count": len(all_issues)},
            )
        )

    # NOTE: Category Quality was consolidated into Product Categories above.

    # ── Bank Journal Quality — bank journals must have bank_account_id ─
    bank_journals = target.get("bank_journals_detail") or []
    payment_provider_journal_ids = target.get("payment_provider_journal_ids") or set()
    for bj in bank_journals:
        issues = []
        is_payment_gateway = bj.get("id") in payment_provider_journal_ids
        if bj.get("type") == "bank" and not bj.get("bank_account_id") and not is_payment_gateway:
            issues.append("no bank_account_id linked")
        if not bj.get("default_account_id"):
            issues.append("no default account")
        if bj.get("type") == "bank" and not bj.get("suspense_account_id") and not is_payment_gateway:
            issues.append("no suspense account")
        kind = "payment-gateway" if is_payment_gateway else bj.get("type")
        sheets["Bank Journal Quality"].append(
            _row(
                company_name,
                **{"Journal ID": bj.get("id")},
                Code=bj.get("code"),
                Name=bj.get("name"),
                Type=kind,
                **{"Bank Account": _safe(bj.get("bank_account_id"))},
                **{"Default Account": _safe(bj.get("default_account_id"))},
                **{"Suspense Account": _safe(bj.get("suspense_account_id"))},
                Currency=_safe(bj.get("currency_id")) or "(company default)",
                **{"Missing Fields": ", ".join(issues) if issues else "-"},
                Status="FAIL" if issues else "PASS",
            )
        )

    # ── Financial Reports Setup — verify each report is configured ─────
    EXPECTED_REPORTS = [
        ("profit_loss", "Profit & Loss (P&L)", "Financial Statements"),
        ("balance_sheet", "Balance Sheet", "Financial Statements"),
        ("cash_flow", "Cash Flow Statement", "Financial Statements"),
        ("trial_balance", "Trial Balance", "Financial Statements"),
        ("partner_ledger", "Partner Ledger", "Financial Statements"),
        ("open_items", "Open Items", "Financial Statements"),
        ("vat_report", "VAT Report", "Financial Statements"),
        ("receivable_aging", "AR Aging Report", "Financial Statements"),
        ("payable_aging", "AP Aging Report", "Financial Statements"),
    ]
    rtypes = target.get("report_types_full") or []
    rtemplates = target.get("report_templates_full") or []
    # The registry exposes a `code` field (e.g. "profit_loss"); templates link
    # via the `report_type` selection that mirrors that same code.
    rtypes_by_code = {(r.get("code") or ""): r for r in rtypes}
    rtemplates_by_type = {(r.get("report_type") or ""): r for r in rtemplates}

    for code, label, category in EXPECTED_REPORTS:
        rtype_rec = rtypes_by_code.get(code)
        rtmpl_rec = rtemplates_by_type.get(code)
        has_type = bool(rtype_rec)
        has_template = bool(rtmpl_rec)
        issues = []
        if not has_type:
            issues.append("no report.type.registry record")
        if not has_template:
            issues.append("no report.template")
        # Reference comparison
        ref_rtypes = (ref or {}).get("report_types_full") or []
        ref_has_type = any(r.get("code") == code for r in ref_rtypes)
        if not has_type and ref_has_type:
            ref_note = "Reference has it, target missing"
        else:
            ref_note = ""
        status = "PASS" if (has_type and has_template) else ("FAIL" if issues else "WARN")
        sheets["Financial Reports Setup"].append(
            _row(
                company_name,
                Category=category,
                Report=label,
                Code=code,
                **{"Has report.type": "Yes" if has_type else "No"},
                **{"Has report.template": "Yes" if has_template else "No"},
                **{"Type Name": _safe(rtype_rec.get("name") if rtype_rec else "")},
                **{"Template Name": _safe(rtmpl_rec.get("name") if rtmpl_rec else "")},
                Status=status,
                Note=", ".join(issues) + (f" | {ref_note}" if ref_note else ""),
            )
        )

    # ── Top Issues — aggregate all CRITICAL across sheets ───────────────
    # Sources to scan for FAIL or CRITICAL severity rows
    issue_sources = [
        ("Company Settings", "Setting"),
        ("Account Types Coverage", "Account Type"),
        ("Journals", "Code"),
        ("Taxes", "Name"),
        ("Tax Groups", "Name"),
        ("Product Categories", "Name"),
        ("Warehouses + Op Types", "Name"),
        ("Bank Journal Quality", "Code"),
        ("Financial Reports Setup", "Report"),
        ("Config Coverage", "Item"),
        ("Product Quality", "Name"),
        ("Partner Quality", "Name"),
        ("Category Quality", "Name"),
    ]
    for sheet_name, identifier_col in issue_sources:
        for r in sheets.get(sheet_name, []):
            severity = r.get("Severity", "")
            status = r.get("Status", "")
            if status == "FAIL" or severity == "CRITICAL":
                ident = r.get(identifier_col) or r.get("Item") or r.get("Name") or ""
                missing = r.get("Missing Fields") or r.get("Note") or ""
                fix = r.get("Fix") or ""
                sheets["Top Issues"].append(
                    _row(
                        company_name,
                        Severity="CRITICAL" if severity == "CRITICAL" else "FAIL",
                        Sheet=sheet_name,
                        Item=str(ident)[:60],
                        Issue=str(missing)[:200],
                        Fix=str(fix)[:200],
                        Status=status,
                    )
                )

    return sheets
