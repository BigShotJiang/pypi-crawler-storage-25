"""Accurate migration phase commands and pipeline operations.

All commands that execute migration steps: preflight, setup, cutover,
foundation, transactions, verify, sign-off, go-live, attachments,
migrate (sequential), wipe, gap-sync, post-drafts, reconcile,
parity-batch, full-remediate, coa-cleanup, ar-ap-reversal, daily-sync.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import (
    _bump_client_timeout,
    _company_kwargs,
    _resolve_accurate_company,
    _run_via_docker_exec,
)

app = typer.Typer(help="Accurate migration phase commands.")


# --- phases ------------------------------------------------------------


@app.command("preflight")
def preflight(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
) -> None:
    """Run Phase 1 Preflight checks."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running preflight for {rec['slug']}...")
    report = c.execute_kw("accurate.company", "action_run_preflight", [[rec["id"]]], _company_kwargs(rec))

    # report is either the return dict or None (if write-only model method)
    # action_run_preflight returns the report dict per our implementation
    if not isinstance(report, dict):
        # Refresh to read the persisted summary
        updated = c.search_read(
            "accurate.company.phase",
            domain=[
                ("company_id", "=", rec["id"]),
                ("phase_code", "=", "preflight"),
            ],
            fields=["state", "summary_json"],
            order="create_date desc",
            limit=1,
        )
        if updated and updated[0].get("summary_json"):
            report = json.loads(updated[0]["summary_json"])
        else:
            report = {"checks": [], "all_blockers_passed": False}

    rows = []
    for chk in report.get("checks", []):
        rows.append(
            [
                chk["name"],
                "✓" if chk["passed"] else "✗",
                chk["severity"],
                (chk.get("message") or "")[:80],
            ]
        )
    out.table(
        "Preflight Results",
        [("Check", ""), ("Result", ""), ("Severity", "dim"), ("Message", "dim")],
        rows,
    )
    if not report.get("all_blockers_passed"):
        out.error("Preflight BLOCKED — resolve issues and re-run.")
        raise typer.Exit(1)
    out.success("Preflight PASSED — ready for Setup phase.")


@app.command("setup")
def setup(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    coa_template: Annotated[
        str,
        typer.Option(
            "--coa-template",
            help="Odoo CoA template XML ID to install",
        ),
    ] = "l10n_id.l10n_id_chart_template_amd",
) -> None:
    """Run Phase 2 Setup — install CoA + resolve PPh accounts."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running setup for {rec['slug']} (CoA: {coa_template})...")
    summary = c.execute_kw(
        "accurate.company",
        "action_run_setup",
        [[rec["id"]]],
        {"coa_template_xmlid": coa_template},
    )
    out.success("Setup PASSED.")
    for k, v in [
        ("CoA Installed", str(summary.get("coa_installed", "-"))),
        ("Mapping Rows Seeded", str(summary.get("mapping_rows_seeded", 0))),
    ]:
        out.kv(k, v)
    pph = summary.get("pph_accounts") or {}
    if pph:
        rows = []
        for field_name, val in pph.items():
            if val:
                rows.append([field_name, val.get("code", "-"), val.get("name", "-")])
            else:
                rows.append([field_name, "-", "NOT FOUND"])
        out.table(
            "PPh Accounts Resolved",
            [("Type", ""), ("Code", ""), ("Name", "dim")],
            rows,
        )


@app.command("phases")
def phases(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    phase: Annotated[
        str | None,
        typer.Option("--phase", help="Filter by phase_code"),
    ] = None,
    state: Annotated[
        str | None,
        typer.Option("--state", help="Filter by state"),
    ] = None,
) -> None:
    """Show phase execution history for one Accurate company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    domain = [("company_id", "=", rec["id"])]
    if phase:
        domain.append(("phase_code", "=", phase))
    if state:
        domain.append(("state", "=", state))
    phases_ = c.search_read(
        "accurate.company.phase",
        domain=domain,
        fields=[
            "phase_code",
            "state",
            "started_at",
            "completed_at",
            "duration_s",
            "triggered_by",
            "error_log",
        ],
        order="create_date desc",
        limit=50,
    )
    rows = []
    for p in phases_:
        rows.append(
            [
                p["phase_code"],
                p["state"],
                str(p.get("started_at") or "-"),
                f"{p.get('duration_s', 0):.1f}s",
                (p.get("error_log") or "")[:50],
            ]
        )
    out.table(
        f"Phase History — {rec['slug']} ({len(phases_)})",
        [("Phase", ""), ("State", ""), ("Started", "dim"), ("Dur", "dim"), ("Error", "dim")],
        rows,
        data_for_json=phases_,
    )


# --- cutover ------------------------------------------------------------


@app.command("cutover")
def cutover(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    cutover_date: Annotated[str, typer.Option("--date", help="YYYY-MM-DD")],
    mode: Annotated[str, typer.Option("--mode")] = "cutover",
) -> None:
    """Phase 3 Cutover Config — commits the cutover date + mode."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Configuring cutover for {rec['slug']} — date={cutover_date} mode={mode}")
    summary = c.execute_kw(
        "accurate.company",
        "action_run_cutover_config",
        [[rec["id"]]],
        {"cutover_date": cutover_date, "mode": mode},
    )
    out.success("Cutover config committed.")
    for k, v in [
        ("Cutover Date", summary.get("cutover_date", "-")),
        ("Current FY Start", summary.get("current_fy_start", "-")),
        ("Mode", summary.get("mode", "-")),
    ]:
        out.kv(k, v)


# --- foundation --------------------------------------------------------


@app.command("foundation")
def foundation(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="Timeout in seconds")] = 1800,
) -> None:
    """Foundation Sync — master data import with zero-tolerance validation."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Foundation sync for {rec['slug']}...")

    is_local = hasattr(actx, "local") and actx.local is not None
    if is_local:
        summary = _run_via_docker_exec(actx, out, "action_run_foundation", rec["id"], timeout=timeout)
    else:
        _bump_client_timeout(actx, seconds=float(timeout))
        try:
            summary = c.execute_kw("accurate.company", "action_run_foundation", [[rec["id"]]], _company_kwargs(rec))
        except (RPCError, ConnectionError) as exc:
            out.error(f"Foundation failed: {exc}")
            raise typer.Exit(1) from exc

    if not summary:
        return

    mods = summary.get("modules", {})
    rows = [[name, str(v)] for name, v in mods.items()]
    out.table("Foundation Modules", [("Module", ""), ("Result", "")], rows)

    gate = summary.get("foundation_gate", {})
    if gate:
        gate_rows = []
        for d in gate.get("domains", []):
            status = "PASS" if d["passed"] else "FAIL"
            gate_rows.append([d["name"], status, d.get("detail", "")])
        out.table(
            "Foundation Gate",
            [("Domain", ""), ("Status", ""), ("Detail", "")],
            gate_rows,
        )

    if gate.get("passed"):
        out.success("Foundation PASSED — ready for migration.")
    else:
        out.error("Foundation FAILED — fix issues and re-run.")
        raise typer.Exit(1)


@app.command("foundation-report")
def foundation_report(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Show master data completeness report for a company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Foundation report for {rec['slug']}...")

    result = c.execute_kw("accurate.company", "action_validate_foundation_gate", [[rec["id"]]], _company_kwargs(rec))

    rows = []
    for domain in result.get("domains", []):
        status = "PASS" if domain["passed"] else "FAIL"
        rows.append([domain["name"], status, domain.get("detail", "")])

    out.table(
        f"Foundation Gate ({result.get('failed_count', '?')} failures)",
        [("Domain", ""), ("Status", ""), ("Detail", "")],
        rows,
        data_for_json=result,
    )

    if result.get("passed"):
        out.success("Foundation gate PASSED — ready for migration.")
    else:
        out.error("Foundation gate FAILED — fix issues before migration.")
        raise typer.Exit(1)


# --- transactions ------------------------------------------------------


@app.command("transactions")
def transactions(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    phase: Annotated[str, typer.Option("--phase", help="prior|current|both|waves")] = "waves",
    sync: Annotated[
        bool,
        typer.Option(
            "--sync/--async",
            help=(
                "--sync runs the import inline (blocking, results known on "
                "return — good for CI and small tenants). --async enqueues "
                "via queue_job (default; background with OCA queue worker)."
            ),
        ),
    ] = False,
    skip_bs_opening: Annotated[
        bool,
        typer.Option(
            "--skip-bs-opening/--with-bs-opening",
            help="Skip Wave 0 (opening BS JE) for companies that started in the current FY.",
        ),
    ] = True,
    timeout: Annotated[
        int,
        typer.Option(
            "--timeout",
            help=("HTTP client timeout in seconds. Default 900 (15 min). Raise for very large tenants."),
        ),
    ] = 900,
) -> None:
    """Import transactions from Accurate.

    Default mode (--phase waves) uses the wave-based pipeline:
    invoices → payments → bank → JVs, with pre-flight gates,
    auto-reconciliation, and 12-check validation.

    Legacy modes (prior/current/both) call the old phase methods.

    Examples::

        kctl-odoo accurate transactions mandira-copy-frozen
        kctl-odoo accurate transactions mandira-copy-frozen --phase waves --sync
        kctl-odoo accurate transactions my-company --with-bs-opening
    """
    import httpx

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    c._client.timeout = httpx.Timeout(timeout)
    rec = _resolve_accurate_company(c, identifier)

    if phase == "waves":
        out.info(f"Running wave-based import for {rec['slug']} (timeout={timeout}s)...")
        result = c.execute_kw(
            "accurate.company",
            "action_import_transactions",
            [[rec["id"]]],
            {"skip_bs_opening": skip_bs_opening, "skip_optional": True},
        )
        if isinstance(result, dict):
            validation = result.get("validation", {})
            waves = result.get("waves", [])
            total_moves = sum(w.get("posted", 0) for w in waves)
            tb = next((c for c in validation.get("checks", []) if c["name"] == "tb_parity"), {})
            status = "PASSED ✓" if validation.get("passed") else "FAILED ✗"
            out.success(f"Import complete: {total_moves} moves posted")
            out.info(f"TB: {tb.get('value', '?')}")
            out.info(f"Validation: {status}")
            if not validation.get("passed"):
                for check in validation.get("checks", []):
                    if not check["passed"]:
                        out.warn(f"  ✗ {check['name']}: {check['detail'][:60]}")
        else:
            out.success("Import complete.")
        return

    # Legacy modes
    if phase in ("prior", "both"):
        out.info(f"Running Transactions — Prior-FY Opens ({'sync' if sync else 'async'}, timeout={timeout}s)...")
        c.execute_kw(
            "accurate.company",
            "action_run_transactions_prior",
            [[rec["id"]]],
            {"context": {"accurate_sync_inline": sync}},
        )
        out.success("Prior-FY opens imported.")
    if phase in ("current", "both"):
        out.info(f"Running Transactions — Current FY ({'sync' if sync else 'async'}, timeout={timeout}s)...")
        c.execute_kw(
            "accurate.company",
            "action_run_transactions_current",
            [[rec["id"]]],
            {"context": {"accurate_sync_inline": sync}},
        )
        out.success("Current-FY transactions imported.")


# --- verify / sign-off / go-live ---------------------------------------


@app.command("verify")
def verify(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 7 Verification — generates parity report."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Generating verification report for {rec['slug']}...")
    report_id = c.execute_kw("accurate.company", "action_run_verification", [[rec["id"]]], _company_kwargs(rec))
    # Read report back
    if isinstance(report_id, dict):
        report_id = report_id.get("id")
    elif hasattr(report_id, "id"):
        report_id = report_id.id
    if not isinstance(report_id, int):
        # The method returns the report record — some RPC flavours return {}
        rep = c.search_read(
            "accurate.verification.report",
            domain=[("company_id", "=", rec["id"])],
            fields=["id", "all_passed"],
            limit=1,
            order="create_date desc",
        )
        if not rep:
            out.error("No verification report found.")
            raise typer.Exit(1)
        report_id = rep[0]["id"]
    lines = c.search_read(
        "accurate.verification.line",
        domain=[("report_id", "=", report_id)],
        fields=["check_name", "scope", "accurate_value", "odoo_value", "delta", "passed", "message"],
        order="sequence,id",
    )
    rows = [
        [
            l["check_name"],
            l.get("scope") or "-",
            l.get("accurate_value") or "-",
            l.get("odoo_value") or "-",
            l.get("delta") or "-",
            "✓" if l["passed"] else "✗",
            (l.get("message") or "")[:60],
        ]
        for l in lines
    ]
    out.table(
        f"Verification Report ({len(lines)} checks)",
        [("Check", ""), ("Scope", ""), ("Accurate", ""), ("Odoo", ""), ("Delta", ""), ("Pass", ""), ("Message", "dim")],
        rows,
    )
    failed = [l for l in lines if not l["passed"]]
    if failed:
        out.error(f"{len(failed)} checks FAILED — resolve before sign-off.")
        raise typer.Exit(1)
    out.success("All checks PASSED.")


@app.command("sign-off")
def sign_off(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    confirm: Annotated[bool, typer.Option("--confirm")] = False,
) -> None:
    """Sign off verification — required before go-live."""
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (destructive gate).")
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    c.execute_kw("accurate.company", "action_sign_off_verification", [[rec["id"]]], _company_kwargs(rec))
    out.success(f"Verification signed off for {rec['slug']} by {actx.username_override or 'current user'}.")


@app.command("go-live")
def go_live(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 8 Go-Live — enable cron sync, state=live."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    c.execute_kw("accurate.company", "action_run_go_live", [[rec["id"]]], _company_kwargs(rec))
    out.success(f"{rec['slug']} is LIVE — incremental cron sync enabled.")


@app.command("attachments")
def attachments(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 9 Attachments — migrate Accurate attachments to ir.attachment.

    Optional phase. Requires accurate.company.attachments_enabled=True.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running attachments phase for {rec['slug']}...")
    try:
        summary = c.execute_kw(
            "accurate.company",
            "action_run_attachments",
            [[rec["id"]]],
        )
    except (RPCError, ConnectionError) as exc:
        out.error(f"Attachments failed: {exc}")
        raise typer.Exit(1) from exc
    if summary and summary.get("skipped"):
        out.warn("Attachments phase skipped — attachments_enabled=False.")
    else:
        out.success("Attachments phase complete.")
        if isinstance(summary, dict):
            for k, v in [
                ("Migrated", str(summary.get("migrated_count", 0))),
                ("Skipped", str(summary.get("skipped_count", 0))),
            ]:
                out.kv(k, v)


# --- migrate convenience -----------------------------------------------


@app.command("migrate")
def migrate(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    until: Annotated[str, typer.Option("--until", help="Stop at this phase")] = "verify",
) -> None:
    """Run phases in sequence up to --until (default: verify, stopping before sign-off)."""
    actx: AppContext = ctx.obj
    _bump_client_timeout(actx, seconds=1800.0)
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    sequence = [
        ("preflight", "action_run_preflight"),
        ("setup", "action_run_setup"),
        ("cutover", "action_run_cutover_config"),
        ("foundation", "action_run_foundation"),
        ("import", "action_import_transactions"),
        ("verify", "action_run_verification"),
        ("go-live", "action_run_go_live"),
    ]
    rpc_kwargs = _company_kwargs(rec)

    tracker = out.step_tracker(total=len(sequence))
    out.debug(f"target: accurate.company id={rec['id']} slug={rec.get('slug', '?')}")
    out.debug(f"odoo_company_id: {rec.get('odoo_company_id')}")
    out.debug(f"phases: {' → '.join(l for l, _ in sequence)}")
    for label, method in sequence:
        if label == "cutover":
            tracker.skip(label, "requires manual cutover")
            if not rec.get("current_phase") or rec.get("current_phase") == "preflight":
                out.error("Cutover not yet configured; aborting.")
                raise typer.Exit(2)
            continue
        try:
            with tracker.step(label):
                tracker.debug(f"RPC accurate.company.{method}([{rec['id']}])")
                result = c.execute_kw("accurate.company", method, [[rec["id"]]], rpc_kwargs)
                if isinstance(result, dict):
                    for k, v in result.items():
                        tracker.debug(f"  {k}: {v}")
        except (RPCError, ConnectionError) as exc:
            out.error(f"{label}: {exc}")
            raise typer.Exit(1) from exc
        if label == until:
            tracker.finish(f"stopped at {until}")
            return
    tracker.finish()


# --- clean-slate wipe (18.0.15.2.0) ------------------------------------


@app.command("wipe")
def wipe(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[
        bool, typer.Option("--dry-run/--execute", help="Preview only (default); use --execute to actually delete")
    ] = True,
    confirm: Annotated[bool, typer.Option("--confirm", help="Required with --execute to proceed")] = False,
) -> None:
    """Wipe migrated transactions while preserving all masters/config.

    Idempotent SQL-based cleanup for clean-slate remigration. Preserves:
    accurate.company config, mappings, parity history, foundation ext-ids
    (customer/vendor/item/glaccount/currency/unit/tax/...), CoA accounts,
    partners, products. Deletes: every account.move tagged with
    x_accurate_migration_source, its lines, partial/full reconciles,
    payment ext-ids, and transaction-module ir.model.data.

    Pass ``all`` as identifier to wipe every accurate.company on this DB.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    if not dry_run and not confirm:
        raise typer.BadParameter("Add --confirm to proceed with --execute (destructive).")

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    totals = {"moves": 0, "move_lines": 0, "partial_reconcile": 0, "account_payment": 0, "ir_model_data": 0}
    rows = []
    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_wipe_migrated_transactions",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        rows.append(
            [
                t["slug"],
                str(res["moves"]),
                str(res["move_lines"]),
                str(res["partial_reconcile"]),
                str(res["account_payment"]),
                str(res["ir_model_data"]),
                f"{res.get('elapsed_seconds', 0)}s" if not dry_run else "-",
            ]
        )
        for k in totals:
            totals[k] += res[k]
    header = "Wipe DRY-RUN preview" if dry_run else "Wipe EXECUTED"
    out.table(
        f"{header} ({len(targets)} tenant{'s' if len(targets) != 1 else ''})",
        [("Tenant", ""), ("Moves", ""), ("Lines", ""), ("Recon", ""), ("Pays", ""), ("IMD", ""), ("Elapsed", "dim")],
        rows,
    )
    out.kv("Total moves", str(totals["moves"]))
    out.kv("Total ext-ids", str(totals["ir_model_data"]))
    if dry_run:
        out.warn("DRY-RUN — nothing deleted. Add --execute --confirm to run.")
    else:
        out.success(f"Wiped {totals['moves']} moves across {len(targets)} tenant(s).")


@app.command("wipe-validate")
def wipe_validate(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
) -> None:
    """Validate a post-wipe tenant — confirm transactions are truly clean.

    Checks: no migrated moves remain, no transaction-module ext-ids
    remain, no orphan move-lines, no orphan partial_reconcile, no
    orphan account.payment. Also reports foundation + config
    preservation counts (positive proof masters survived).

    Exits non-zero if ANY check flags an issue.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    any_dirty = False
    for t in targets:
        res = c.execute_kw("accurate.company", "action_validate_wipe_clean", [[t["id"]]])
        status = "✓ CLEAN" if res["clean"] else "✗ DIRTY"
        out.kv(t["slug"], status)
        if not res["clean"]:
            any_dirty = True
            for issue in res["issues"]:
                out.error(f"  - {issue}")
        fp = res["foundation_preserved"]
        out.kv(
            "  foundation",
            f"customers={fp.get('customer', 0)} vendors={fp.get('vendor', 0)} items={fp.get('item', 0)} glaccounts={fp.get('glaccount', 0)} taxes={fp.get('tax', 0)}",
        )
        cp = res["config_preserved"]
        out.kv(
            "  config",
            f"company={cp.get('accurate.company', 0)} account_mapping={cp.get('accurate.account.mapping', 0)} parity_reports={cp.get('accurate.parity.report', 0)}",
        )
    if any_dirty:
        out.error("One or more tenants FAILED validation.")
        raise typer.Exit(1)
    out.success("All tenants validated clean.")


# --- synchronous pipeline helpers (18.0.15.2.0) ------------------------


@app.command("gap-sync")
def gap_sync(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    modules: Annotated[
        str | None,
        typer.Option(
            "--modules",
            help="Comma-separated list (default = every transaction module)",
        ),
    ] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
) -> None:
    """Synchronous gap-sync — fetch every missing Accurate record.

    Surgical complement to ``transactions_current`` which queues async
    queue_job work. This helper runs inline + commits per-tenant, so
    records actually land before the CLI returns.

    Uses ``accurate.company.action_sync_missing_records``.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    mods = [m.strip() for m in modules.split(",")] if modules else None

    for t in targets:
        kwargs = {"dry_run": dry_run}
        if mods:
            kwargs["modules"] = mods
        res = c.execute_kw("accurate.company", "action_sync_missing_records", [[t["id"]]], kwargs)
        rows = []
        for mod, v in res.items():
            if (v.get("missing") or 0) > 0 or (v.get("mapped_ok") or 0) > 0:
                rows.append(
                    [
                        mod,
                        str(v.get("missing", 0)),
                        str(v.get("mapped_ok", 0)),
                        str(v.get("mapped_skipped", 0)),
                        str(len(v.get("errors") or [])),
                    ]
                )
        if rows:
            out.table(
                f"{t['slug']} — gap-sync {'DRY-RUN' if dry_run else 'EXECUTED'}",
                [("Module", ""), ("Missing", ""), ("OK", ""), ("Skipped", ""), ("Errors", "")],
                rows,
            )
        else:
            out.info(f"{t['slug']}: nothing to sync.")


@app.command("post-drafts")
def post_drafts(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
) -> None:
    """Post every draft account.move/payment tagged by the migration.

    Wraps ``accurate.company.action_post_draft_imports``.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_post_draft_imports",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        out.kv(
            t["slug"],
            f"candidates={res['move_candidates']} posted={res['moves_posted']} "
            f"failed={len(res['moves_failed'])} payments_posted={res['payments_posted']}",
        )
        for f in res.get("moves_failed", [])[:5]:
            out.warn(f"  FAIL {f.get('move_id')}: {(f.get('error', '') or '')[:150]}")


@app.command("reconcile")
def reconcile(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
) -> None:
    """Reconcile AR/AP lines across migrated payment + invoice moves.

    Wraps ``accurate.company.action_reconcile_migrated_move_lines``.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_reconcile_migrated_move_lines",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        out.kv(
            t["slug"],
            f"groups={res.get('groups_found', 0)} reconciled={res.get('groups_reconciled', 0)} "
            f"skipped={len(res.get('groups_skipped') or [])}",
        )


@app.command("parity-batch")
def parity_batch(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    as_of: Annotated[str, typer.Option("--as-of", help="YYYY-MM-DD")] = "2026-03-31",
) -> None:
    """Run the 12-check parity framework and print BS/PL/TB delta.

    Wraps ``accurate.company.action_run_parity``. Writes a new
    ``accurate.parity.report``. Exits non-zero if any key check fails.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    any_fail = False
    for t in targets:
        c.execute_kw(
            "accurate.company",
            "action_run_parity",
            [[t["id"]]],
            {"as_of": as_of},
        )
        reps = c.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", t["id"])],
            fields=["id"],
            order="id desc",
            limit=1,
        )
        if not reps:
            out.error(f"{t['slug']}: no parity report emitted")
            any_fail = True
            continue
        rep_id = reps[0]["id"]
        lines = c.search_read(
            "accurate.parity.line",
            domain=[
                ("report_id", "=", rep_id),
                ("check_name", "in", ("trial_balance", "bs", "pnl", "ar_aging", "ap_aging")),
            ],
            fields=["check_name", "accurate_total", "odoo_total", "passed"],
        )
        rows = []
        for ln in lines:
            A = ln.get("accurate_total") or 0
            O = ln.get("odoo_total") or 0
            ratio = f"{(O / A):.2f}x" if A else "n/a"
            rows.append(
                [
                    ln["check_name"],
                    f"{A:,.0f}",
                    f"{O:,.0f}",
                    f"{O - A:+,.0f}",
                    ratio,
                    "✓" if ln["passed"] else "✗",
                ]
            )
            if not ln["passed"]:
                any_fail = True
        out.table(
            f"{t['slug']} parity (as_of={as_of}, report={rep_id})",
            [("Check", ""), ("Accurate", ""), ("Odoo", ""), ("Δ", ""), ("Ratio", ""), ("Pass", "")],
            rows,
        )

    if any_fail:
        raise typer.Exit(1)


@app.command("full-remediate")
def full_remediate(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    as_of: Annotated[str, typer.Option("--as-of")] = "2026-03-31",
    skip_wipe: Annotated[bool, typer.Option("--skip-wipe", help="Skip wipe — start from current state")] = False,
    confirm: Annotated[bool, typer.Option("--confirm", help="Required (destructive)")] = False,
) -> None:
    """End-to-end clean-slate remediation: wipe → gap-sync → post → reconcile → parity.

    This is the one-shot operator command. Per tenant, runs the whole
    sequence with per-step commits so container restarts don't lose
    progress. Uses the fixed SDK 0.5.2 mappers (DP-entry pivot + tax_ids
    explicit empty list).
    """
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (destructive wipe).")

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=3600.0)  # 1 hour — full pipeline

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        out.info(f"=== {t['slug']} ===")
        if not skip_wipe:
            r = c.execute_kw(
                "accurate.company",
                "action_wipe_migrated_transactions",
                [[t["id"]]],
                {"dry_run": False},
            )
            out.kv("wipe", f"moves={r['moves']} imd={r['ir_model_data']} ({r['elapsed_seconds']}s)")
            v = c.execute_kw("accurate.company", "action_validate_wipe_clean", [[t["id"]]])
            if not v["clean"]:
                out.error(f"wipe-validate FAILED: {v['issues']}")
                raise typer.Exit(1)
        # gap-sync per-module — each module is a separate RPC call so
        # Odoo's statement_timeout (10 min) can't guillotine the big
        # tenants mid-flight. Larger tenants (SPS 1700+, GDA 1900+
        # records) would exceed the cursor limit on a single-call sync.
        _GAP_MODULES = (
            "sales-invoice",
            "sales-receipt",
            "purchase-invoice",
            "purchase-payment",
            "bank-receipt",
            "bank-transfer",
            "other-payment",
            "other-deposit",
            "expense",
            "journal-voucher",
        )
        total_ok = 0
        total_err = 0
        for mod in _GAP_MODULES:
            try:
                r2 = c.execute_kw(
                    "accurate.company",
                    "action_sync_missing_records",
                    [[t["id"]]],
                    {"dry_run": False, "modules": [mod]},
                )
                s = r2.get(mod, {})
                total_ok += s.get("mapped_ok", 0) or 0
                total_err += len(s.get("errors") or [])
                if (s.get("missing") or 0) > 0 or (s.get("mapped_ok") or 0) > 0:
                    out.info(
                        f"  {mod}: missing={s.get('missing')} ok={s.get('mapped_ok')} "
                        f"skipped={s.get('mapped_skipped')} errors={len(s.get('errors') or [])}"
                    )
            except (RPCError, ConnectionError, KeyError, ValueError) as exc:
                out.warn(f"  {mod}: {str(exc)[:180]}")
        out.kv("gap-sync", f"mapped_ok={total_ok} errors={total_err}")
        # post
        r3 = c.execute_kw(
            "accurate.company",
            "action_post_draft_imports",
            [[t["id"]]],
            {"dry_run": False},
        )
        out.kv(
            "post",
            f"posted={r3['moves_posted']}/{r3['move_candidates']} failed={len(r3['moves_failed'])}",
        )
        # reconcile
        r4 = c.execute_kw(
            "accurate.company",
            "action_reconcile_migrated_move_lines",
            [[t["id"]]],
            {"dry_run": False},
        )
        out.kv(
            "reconcile",
            f"{r4.get('groups_reconciled', 0)}/{r4.get('groups_found', 0)} groups",
        )
        # parity
        c.execute_kw(
            "accurate.company",
            "action_run_parity",
            [[t["id"]]],
            {"as_of": as_of},
        )
        reps = c.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", t["id"])],
            fields=["id"],
            order="id desc",
            limit=1,
        )
        if reps:
            lines = c.search_read(
                "accurate.parity.line",
                domain=[
                    ("report_id", "=", reps[0]["id"]),
                    ("check_name", "in", ("trial_balance", "bs", "pnl")),
                ],
                fields=["check_name", "accurate_total", "odoo_total", "passed"],
            )
            for ln in lines:
                A = ln.get("accurate_total") or 0
                O = ln.get("odoo_total") or 0
                ratio = f"{(O / A):.2f}x" if A else "n/a"
                status = "✓" if ln["passed"] else "✗"
                out.kv(
                    f"  {ln['check_name']}",
                    f"A={A:,.0f} O={O:,.0f} Δ={O - A:+,.0f} {ratio} {status}",
                )


# --- coa-cleanup -------------------------------------------------------


@app.command("coa-cleanup")
def coa_cleanup(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all' for every live company")],
    confirm: Annotated[bool, typer.Option("--confirm", help="Required to proceed (write SQL)")] = False,
) -> None:
    """Migrate factory l10n_id CoA → Accurate CoA per company.

    After Accurate import, both CoAs coexist on the company:
    - Factory: 11210010 Account Receivable, 21100010 Trade Receivable, ...
    - Accurate: 1100.01 Piutang Dagang IDR, 2000.09 Hutang Dagang IDR, ...

    Transactions booked through Odoo defaults can land on factory accounts.
    This command re-points all move lines + property defaults onto Accurate
    accounts, then removes the factory accounts from the company. Result:
    only Accurate-style codes remain, AR/AP balances match Accurate exactly.

    Idempotent — safe to re-run.
    """
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (modifies account_move_line + ir_property + journals).")

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=1800.0)

    if identifier == "all":
        targets = c.search_read(
            "accurate.company",
            domain=[("state", "in", ("in_progress", "live"))],
            fields=["id", "slug"],
            order="id",
        )
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    rows = []
    for t in targets:
        out.info(f"=== {t['slug']} ===")
        try:
            r = c.execute_kw(
                "accurate.company",
                "action_cleanup_factory_coa",
                [[t["id"]]],
            )
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  FAILED: {exc}")
            rows.append([t["slug"], "FAIL", str(exc)[:60]])
            continue

        out.kv("  factories_found", str(r.get("factories_found", 0)))
        out.kv("  moved_lines", str(r.get("moved_lines", 0)))
        out.kv("  factories_removed", str(r.get("factories_removed", 0)))
        out.kv("  remaining_factory", str(r.get("remaining_factory", 0)))
        out.kv("  remaining_dotted", str(r.get("remaining_dotted", 0)))
        ar = r.get("ar_balance", 0)
        ap = r.get("ap_balance", 0)
        out.kv("  AR", f"{ar:+,.0f}")
        out.kv("  AP", f"{ap:+,.0f}")
        rows.append(
            [
                t["slug"],
                str(r.get("factories_found", 0)),
                str(r.get("factories_removed", 0)),
                str(r.get("moved_lines", 0)),
                str(r.get("remaining_factory", 0)),
                f"{ar:+,.0f}",
                f"{ap:+,.0f}",
            ]
        )

    if len(rows) > 1:
        out.table(
            ["slug", "found", "removed", "moved", "remain", "AR", "AP"],
            rows,
        )


@app.command("ar-ap-reversal")
def ar_ap_reversal(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    confirm: Annotated[bool, typer.Option("--confirm", help="Required to proceed")] = False,
) -> None:
    """Post the AR/AP reversal JE to neutralise bulk opening AR/AP.

    The opening JE bulk-imports AR/AP from Accurate's TB at cutover.
    When outstanding-equivalent invoices are also imported (via
    `outstanding_open_items` OR `gap_sync` source) the AR/AP is
    doubled. This command posts a reversal JE that zeroes the
    bulk AR/AP so the individual outstanding invoices remain the
    only AR/AP balance.

    Idempotent — skips when a reversal JE already exists.
    """
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (posts a JE).")

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=900.0)

    if identifier == "all":
        targets = c.search_read(
            "accurate.company",
            domain=[("state", "in", ("in_progress", "live"))],
            fields=["id", "slug"],
            order="id",
        )
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        out.info(f"=== {t['slug']} ===")
        try:
            r = c.execute_kw(
                "accurate.company",
                "action_run_ar_ap_reversal",
                [[t["id"]]],
            )
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  FAILED: {exc}")
            continue

        if r.get("skipped"):
            out.kv("  status", f"skipped ({r.get('reason')})")
            if r.get("move_id"):
                out.kv("  existing", f"id={r['move_id']} name={r.get('move_name')}")
        else:
            out.kv("  posted", f"id={r.get('move_id')} name={r.get('move_name')}")
            out.kv("  reversed", f"{r.get('total_reversed', 0):+,.0f}")
            out.kv("  lines", str(r.get("lines_count", 0)))


# --- daily-sync --------------------------------------------------------


@app.command("daily-sync")
def daily_sync(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Company slug")],
) -> None:
    """Run incremental delta sync for a company.

    Fetches records modified since last sync. Creates new, updates modified,
    logs cancelled. Safe to run repeatedly.

    Examples:
        kctl-odoo accurate daily-sync 26-bb-cv-sentra-agro-nusantara
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_ids = c.search("accurate.company", [("slug", "=", slug)])
    if not company_ids:
        out.error(f"Company not found: {slug}")
        raise typer.Exit(1)

    result = c.execute_kw("accurate.company", "action_daily_sync", [company_ids])

    out.info(f"Delta sync: {slug}")
    out.info(f"  Created:   {result.get('created', 0)}")
    out.info(f"  Updated:   {result.get('updated', 0)}")
    out.info(f"  Cancelled: {result.get('cancelled', 0)}")
    out.info(f"  Errors:    {result.get('errors', 0)}")

    if result.get("errors", 0) == 0:
        out.success("Delta sync complete")
    else:
        out.error(f"Delta sync completed with {result['errors']} errors")
