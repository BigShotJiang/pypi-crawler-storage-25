"""Shared private utilities for the Accurate migration subpackage.

Contains helper functions used across phases.py and reporting.py,
plus the companies_app sub-Typer for managing Accurate company registrations.
"""

from __future__ import annotations

from typing import Annotated

import httpx
import typer

from kctl_odoo.core.callbacks import AppContext


def _run_via_docker_exec(
    actx: AppContext,
    out,
    method: str,
    co_id: int,
    kwargs: dict | None = None,
    timeout: int = 1800,
) -> dict:
    """Run an accurate.company method via docker compose exec, bypassing JSON-RPC timeout."""
    import json as _json
    import subprocess as _sp

    db = actx.client._db if hasattr(actx.client, "_db") else "tpp_odoo_erp"
    kw = ", ".join(f"{k}={v!r}" for k, v in (kwargs or {}).items())
    py = (
        "import json, odoo\n"
        "from odoo import api, SUPERUSER_ID\n"
        f"odoo.tools.config.parse_config(['-d', '{db}', '--no-http'])\n"
        f"registry = odoo.registry('{db}')\n"
        "with registry.cursor() as cr:\n"
        "    env = api.Environment(cr, SUPERUSER_ID, {})\n"
        f"    co = env['accurate.company'].browse({co_id})\n"
        f"    result = co.{method}({kw})\n"
        "    cr.commit()\n"
        "    print(json.dumps(result, default=str))\n"
    )
    out.info("Running via docker exec (local mode)")
    cwd = str(actx.local._project_dir) if hasattr(actx.local, "_project_dir") else None
    proc = _sp.run(
        ["docker", "compose", "exec", "-T", "-e", "PYTHONUNBUFFERED=1", "odoo", "python", "-c", py],
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=cwd,
    )
    if proc.returncode != 0:
        out.error(f"Failed:\n{(proc.stderr or proc.stdout)[-500:]}")
        raise typer.Exit(1)
    lines = [l for l in proc.stdout.strip().splitlines() if l.startswith("{")]
    if not lines:
        out.warn("No JSON result — raw output:")
        out.info((proc.stderr or proc.stdout)[-1000:])
        return {}
    return _json.loads(lines[-1])


def _bump_client_timeout(actx: AppContext, seconds: float = 1800.0) -> None:
    """Extend httpx client read-timeout for long-running Accurate RPCs.

    Default kctl-odoo client has a 30s timeout — fine for most RPCs
    but the Accurate-side methods (gap_sync, post_draft_imports,
    run_parity, full-remediate) can fetch hundreds of records from
    Accurate's API in a single JSON-RPC call. Bump to 30 min so the
    client doesn't disconnect mid-import.
    """
    try:
        actx.client._client.timeout = httpx.Timeout(seconds)
    except (AttributeError, TypeError):
        pass


def _resolve_accurate_company(client: object, identifier: str) -> dict:
    """Find an accurate.company by slug or numeric ID. Returns full record."""
    recs = client.search_read(  # type: ignore[attr-defined]
        "accurate.company",
        domain=[
            "|",
            ("slug", "=", identifier),
            ("id", "=", int(identifier)) if identifier.isdigit() else ("id", "=", 0),
        ],
        fields=[
            "id",
            "name",
            "slug",
            "db_id",
            "state",
            "current_phase",
            "current_phase_state",
            "progress_percent",
            "last_sync_at",
            "sync_enabled",
            "odoo_company_id",
        ],
        limit=1,
    )
    if not recs:
        raise typer.BadParameter(f"Accurate company not found: {identifier}")
    return recs[0]


def _company_kwargs(rec: dict) -> dict:
    """Build execute_kw kwargs with allowed_company_ids for the target company.

    Odoo record rules on account.account filter by the user's current
    company.  When the admin runs migration for company 339 but their
    active company is 1, the import phase gets an AccessError. Passing
    allowed_company_ids in the context makes the target company's records
    visible.
    """
    odoo_cid = rec.get("odoo_company_id")
    company_id = odoo_cid[0] if isinstance(odoo_cid, list) else odoo_cid
    if company_id:
        return {"context": {"allowed_company_ids": [company_id]}}
    return {}


# --- companies ---------------------------------------------------------


companies_app = typer.Typer(help="Manage Accurate company registrations.")


@companies_app.command("list")
def companies_list(
    ctx: typer.Context,
    state: Annotated[
        str | None,
        typer.Option("--state", "-s", help="Filter by state"),
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-l")] = 80,
) -> None:
    """List registered Accurate companies."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    domain = []
    if state:
        domain.append(("state", "=", state))

    recs = c.search_read(
        "accurate.company",
        domain=domain,
        fields=[
            "id",
            "slug",
            "name",
            "state",
            "current_phase",
            "progress_percent",
            "last_sync_at",
        ],
        limit=limit,
        order="name",
    )
    rows = [
        [
            str(r["id"]),
            r["slug"],
            r["name"],
            r["state"],
            r.get("current_phase") or "-",
            f"{r.get('progress_percent', 0)}%",
            str(r.get("last_sync_at") or "-"),
        ]
        for r in recs
    ]
    out.table(
        f"Accurate Companies ({len(recs)})",
        [
            ("ID", "cyan"),
            ("Slug", ""),
            ("Name", ""),
            ("State", ""),
            ("Phase", "dim"),
            ("Progress", "dim"),
            ("Last Sync", "dim"),
        ],
        rows,
        data_for_json=recs,
    )


@companies_app.command("register")
def companies_register(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", "-n", help="Display name (e.g. '26 BU IMP CV PRATAMA AGRI JAYA')")],
    slug: Annotated[str, typer.Option("--slug", "-s", help="URL slug (e.g. '26-bu-imp-cv-pratama-agri-jaya')")],
    company_id: Annotated[int, typer.Option("--company-id", "-c", help="Odoo res.company ID")],
    db_id: Annotated[int, typer.Option("--db-id", "-d", help="Accurate database ID")],
    token: Annotated[str, typer.Option("--token", "-t", help="Accurate API token (aat.NTA...)")],
    host: Annotated[str, typer.Option("--host", help="Accurate API host")] = "https://zeus.accurate.id",
) -> None:
    """Register a new Accurate company for migration."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    existing = c.search_read("accurate.company", [("slug", "=", slug)], ["id"], limit=1)
    if existing:
        out.warn(f"Company {slug} already registered (id={existing[0]['id']}). Updating token.")
        c.execute_kw("accurate.company", "write", [[existing[0]["id"]], {"api_token": token}])
        out.success(f"Token updated for {slug}")
        return

    rec_id = c.execute_kw(
        "accurate.company",
        "create",
        [
            {
                "name": name,
                "slug": slug,
                "odoo_company_id": company_id,
                "db_id": db_id,
                "host": host,
                "api_token": token,
            }
        ],
    )
    out.success(f"Registered {name} (id={rec_id}, slug={slug}, db_id={db_id})")


@companies_app.command("show")
def companies_show(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Show details for one Accurate company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    # phase history
    phases = c.search_read(
        "accurate.company.phase",
        domain=[("company_id", "=", rec["id"])],
        fields=[
            "phase_code",
            "state",
            "started_at",
            "completed_at",
            "duration_s",
            "triggered_by",
        ],
        order="create_date desc",
        limit=20,
    )

    out.header(f"{rec['name']} ({rec['slug']})")
    for k, v in [
        ("State", rec["state"]),
        ("Current Phase", rec.get("current_phase") or "-"),
        ("Phase State", rec.get("current_phase_state") or "-"),
        ("Progress", f"{rec.get('progress_percent', 0)}%"),
        ("Sync Enabled", "yes" if rec.get("sync_enabled") else "no"),
        ("Last Sync", str(rec.get("last_sync_at") or "-")),
    ]:
        out.kv(k, v)
    if phases:
        rows = [
            [
                p["phase_code"],
                p["state"],
                str(p.get("started_at") or "-"),
                str(p.get("completed_at") or "-"),
                f"{p.get('duration_s', 0):.1f}s",
            ]
            for p in phases
        ]
        out.table(
            "Recent Phases",
            [("Phase", ""), ("State", ""), ("Started", "dim"), ("Finished", "dim"), ("Dur", "dim")],
            rows,
        )
