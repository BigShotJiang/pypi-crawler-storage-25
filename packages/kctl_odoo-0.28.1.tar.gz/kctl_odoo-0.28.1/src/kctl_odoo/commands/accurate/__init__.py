"""Accurate sub-package: migration management for Accurate -> Odoo.

Refactored from _part1.py / _part2.py into domain-based modules:
  _helpers.py   -- shared private utilities + companies_app sub-Typer
  phases.py     -- migration phase commands and pipeline operations
  reporting.py  -- errors, parity, snapshots, reporting, JV commands
"""

from __future__ import annotations

import typer

from ._helpers import companies_app
from .phases import app as phases_app
from .reporting import (
    app as reporting_app,
)
from .reporting import (
    cutover_status_app,
    errors_app,
    reconcile_app,
    snapshot_app,
    variance_app,
)

app = typer.Typer(help="Accurate -> Odoo migration management.")

# --- Register sub-typers -----------------------------------------------

app.add_typer(companies_app, name="companies")
app.add_typer(errors_app, name="errors")
app.add_typer(snapshot_app, name="snapshot")
app.add_typer(reconcile_app, name="reconcile")
app.add_typer(variance_app, name="variance")
app.add_typer(cutover_status_app, name="cutover")

# Direct-Accurate pilot reports group
from kctl_odoo.commands._credit_limit.accurate_command import (  # noqa: E402
    credit_limit_report,
)

reports_app = typer.Typer(help="Direct-Accurate pilot reports (no Odoo migration required).")
reports_app.command("credit-limit")(credit_limit_report)
app.add_typer(reports_app, name="reports")

from kctl_odoo.commands._accurate_sync import app as sync_app  # noqa: E402

app.add_typer(sync_app, name="sync")

# --- Merge flat commands from reporting_app -----------------------------
# reporting_app commands include: parity, parity-all, audit-package,
# report, jv-sync, jv-router, migrate (CPR version)

for _cmd in reporting_app.registered_commands:
    app.registered_commands.append(_cmd)

# --- Merge flat commands from phases_app --------------------------------
# phases_app commands include: preflight, setup, phases, cutover,
# foundation, foundation-report, transactions, verify, sign-off,
# go-live, attachments, migrate (sequential), wipe, wipe-validate,
# gap-sync, post-drafts, reconcile, parity-batch, full-remediate,
# coa-cleanup, ar-ap-reversal, daily-sync
#
# NOTE: phases_app is merged AFTER reporting_app so its 'migrate' command
# (sequential phase runner) overrides reporting_app's 'migrate' (CPR),
# preserving the original behavior where _part1's migrate won.

for _cmd in phases_app.registered_commands:
    app.registered_commands.append(_cmd)

# --- validate-journals standalone command --------------------------------

from kctl_odoo.commands._accurate_sync.validate_journals import validate_journals_cmd  # noqa: E402

app.command("validate-journals", help="Validate Odoo journals against Accurate JVs")(validate_journals_cmd)

__all__ = ["app"]
