"""Accurate analysis, error tracking, parity verification, snapshots, and reporting.

Contains: errors_app, parity commands, snapshot_app, reconcile_app,
variance_app, cutover_status_app, reports_app, audit-package, report,
jv-sync, jv-router, migrate (CPR), validate-journals, sync_app.
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import (
    _bump_client_timeout,
    _resolve_accurate_company,
    _run_via_docker_exec,
)

app = typer.Typer(help="Accurate operations: errors, parity, snapshots, reporting.")

# --- errors ------------------------------------------------------------


errors_app = typer.Typer(help="Migration-error inspection and bulk retry.")


@errors_app.command("list")
def errors_list(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company slug or ID")],
    error_kind: Annotated[
        str | None,
        typer.Option("--error-kind", help="Filter by error_kind"),
    ] = None,
    error_class: Annotated[
        str | None,
        typer.Option(
            "--error-class",
            help="transient|rate_limited|data_integrity|config_broken|unknown",
        ),
    ] = None,
    retry_status: Annotated[
        str | None,
        typer.Option("--retry-status", help="pending|ignored|retried|succeeded|abandoned"),
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-l")] = 50,
) -> None:
    """List migration errors for a company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    domain = [("company_id", "=", rec["id"])]
    if error_kind:
        domain.append(("error_kind", "=", error_kind))
    if error_class:
        domain.append(("error_class", "=", error_class))
    if retry_status:
        domain.append(("retry_status", "=", retry_status))
    errors = c.search_read(
        "accurate.migration.error",
        domain=domain,
        fields=[
            "id",
            "module",
            "accurate_id",
            "error_class",
            "error_kind",
            "error_message",
            "retry_status",
            "retry_count",
            "create_date",
        ],
        limit=limit,
        order="create_date desc",
    )
    rows = [
        [
            str(e["id"]),
            e["module"],
            str(e.get("accurate_id") or "-"),
            e["error_class"],
            e.get("error_kind") or "-",
            (e.get("error_message") or "")[:40],
            e["retry_status"],
            str(e.get("retry_count") or 0),
        ]
        for e in errors
    ]
    out.table(
        f"Migration Errors — {rec['slug']} ({len(errors)})",
        [
            ("ID", "cyan"),
            ("Module", ""),
            ("Accurate ID", "dim"),
            ("Class", ""),
            ("Kind", "dim"),
            ("Message", "dim"),
            ("Retry Status", ""),
            ("Retries", "dim"),
        ],
        rows,
        data_for_json=errors,
    )


@errors_app.command("retry")
def errors_retry(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company slug or ID")],
    ids: Annotated[
        str | None,
        typer.Option("--ids", help="Comma-separated error IDs"),
    ] = None,
    error_kind: Annotated[
        str | None,
        typer.Option("--error-kind", help="Retry all errors matching this kind"),
    ] = None,
) -> None:
    """Retry selected errors (by IDs or filtered by error_kind)."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    domain = [("company_id", "=", rec["id"]), ("retry_status", "=", "pending")]
    if ids:
        id_list = [int(x) for x in ids.split(",") if x.strip()]
        domain.append(("id", "in", id_list))
    elif error_kind:
        domain.append(("error_kind", "=", error_kind))
    else:
        out.error("Provide either --ids or --error-kind to select errors to retry.")
        raise typer.Exit(2)
    error_ids = c.search("accurate.migration.error", domain=domain, limit=500)
    if not error_ids:
        out.warn("No matching errors found.")
        return
    c.execute_kw(
        "accurate.migration.error",
        "action_retry_selected",
        [error_ids],
    )
    out.success(f"Queued retry of {len(error_ids)} error(s) for {rec['slug']}.")


@errors_app.command("ignore")
def errors_ignore(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company slug or ID")],
    ids: Annotated[str, typer.Option("--ids", help="Comma-separated error IDs")],
    reason: Annotated[str, typer.Option("--reason", help="Ignore reason (audit trail)")],
) -> None:
    """Mark selected errors as ignored (exclude from phase-failure threshold)."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    id_list = [int(x) for x in ids.split(",") if x.strip()]
    if not id_list:
        out.error("Empty --ids.")
        raise typer.Exit(2)
    # Verify all belong to this company
    belong = c.search(
        "accurate.migration.error",
        domain=[("id", "in", id_list), ("company_id", "=", rec["id"])],
    )
    if len(belong) != len(id_list):
        out.error(f"Some IDs do not belong to {rec['slug']} (found {len(belong)} of {len(id_list)}).")
        raise typer.Exit(2)
    c.write("accurate.migration.error", id_list, {"retry_status": "ignored", "ignore_reason": reason})
    out.success(f"Marked {len(id_list)} error(s) as ignored for {rec['slug']}.")


# --- parity ------------------------------------------------------------


_PARITY_REPORT_FIELDS = [
    "id",
    "as_of_date",
    "run_date",
    "all_passed",
    "passed_count",
    "total_count",
    "company_id",
]

_PARITY_LINE_FIELDS = [
    "id",
    "check_name",
    "category",
    "passed",
    "accurate_total",
    "odoo_total",
    "delta",
    "deltas_json",
    "details_json",
    "error",
    "remediation_hints",
]


def _fetch_parity_report(client, report_id: int) -> tuple[dict, list[dict]]:
    """Load report header + lines by id."""
    reports = client.read("accurate.parity.report", [report_id], _PARITY_REPORT_FIELDS)
    if not reports:
        raise typer.BadParameter(f"accurate.parity.report id={report_id} not found")
    lines = client.search_read(
        "accurate.parity.line",
        domain=[("report_id", "=", report_id)],
        fields=_PARITY_LINE_FIELDS,
        order="category,check_name",
    )
    return reports[0], lines


def _format_parity_markdown(rec: dict, report: dict, lines: list[dict]) -> str:
    """Pretty markdown rendering of one parity report."""

    def _sym(line: dict) -> str:
        if line.get("error"):
            return "!"
        return "OK" if line.get("passed") else "FAIL"

    def _fmt_money(v) -> str:
        try:
            return f"{float(v or 0):,.2f}"
        except (TypeError, ValueError):
            return str(v or "-")

    header = [
        f"# Parity Report — {rec['slug']} ({rec['name']})",
        "",
        f"- **As of**: {report.get('as_of_date')}",
        f"- **Run at**: {report.get('run_date')}",
        f"- **Passed**: {report.get('passed_count')} / {report.get('total_count')}",
        f"- **Overall**: {'PASSED' if report.get('all_passed') else 'FAILED'}",
        "",
        "| Status | Check | Category | Accurate | Odoo | Delta | Notes |",
        "|---|---|---|---:|---:|---:|---|",
    ]
    acc_sum = 0.0
    odoo_sum = 0.0
    for line in lines:
        note = ""
        if line.get("error"):
            note = f"ERROR: {str(line['error'])[:80]}"
        elif line.get("remediation_hints"):
            note = str(line["remediation_hints"]).splitlines()[0][:80]
        header.append(
            "| {sym} | {check} | {cat} | {acc} | {odoo} | {delta} | {note} |".format(
                sym=_sym(line),
                check=line["check_name"],
                cat=line.get("category") or "-",
                acc=_fmt_money(line.get("accurate_total")),
                odoo=_fmt_money(line.get("odoo_total")),
                delta=_fmt_money(line.get("delta")),
                note=note.replace("|", "\\|"),
            )
        )
        try:
            acc_sum += float(line.get("accurate_total") or 0)
            odoo_sum += float(line.get("odoo_total") or 0)
        except (TypeError, ValueError):
            pass
    header.append(
        "| | **Totals** | | **{acc}** | **{odoo}** | **{delta}** | |".format(
            acc=f"{acc_sum:,.2f}",
            odoo=f"{odoo_sum:,.2f}",
            delta=f"{odoo_sum - acc_sum:,.2f}",
        )
    )
    return "\n".join(header) + "\n"


def _run_parity_for_company(
    client,
    rec: dict,
    as_of: str | None,
    only: list[str] | None,
    tolerance: float,
) -> tuple[dict, list[dict]]:
    """Invoke action_run_parity and load back the persisted report."""
    kwargs: dict = {"tolerance": tolerance}
    kwargs["as_of"] = as_of or date.today().isoformat()
    if only:
        kwargs["only"] = list(only)

    action = client.execute_kw(
        "accurate.company",
        "action_run_parity",
        [[rec["id"]]],
        kwargs,
    )
    report_id = None
    if isinstance(action, dict):
        report_id = action.get("res_id")
    elif isinstance(action, int):
        report_id = action
    if not isinstance(report_id, int):
        # Fallback — grab most recent report for this company
        recent = client.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", rec["id"])],
            fields=["id"],
            limit=1,
            order="run_date desc",
        )
        if not recent:
            raise typer.Exit(1)
        report_id = recent[0]["id"]
    return _fetch_parity_report(client, report_id)


@app.command("parity")
def parity(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="accurate.company slug (e.g. sumber-pangan)")],
    check: Annotated[
        list[str] | None,
        typer.Option("--check", "-c", help="Only run named check(s). Repeat for multiple."),
    ] = None,
    as_of: Annotated[
        str | None,
        typer.Option("--date", "-d", help="As-of date YYYY-MM-DD (default today)"),
    ] = None,
    tolerance: Annotated[
        float,
        typer.Option("--tolerance", help="IDR tolerance for deltas"),
    ] = 1.0,
    output: Annotated[
        str,
        typer.Option("--output", "-o", help="markdown | json | xlsx"),
    ] = "markdown",
    output_file: Annotated[
        Path | None,
        typer.Option("--output-file", help="Write output here instead of stdout"),
    ] = None,
) -> None:
    """Run parity suite against Accurate for one tenant + format results."""
    actx: AppContext = ctx.obj
    _bump_client_timeout(actx, seconds=600.0)
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, slug)
    out.info(f"Running parity suite for {rec['slug']}...")
    try:
        report, lines = _run_parity_for_company(c, rec, as_of, check, tolerance)
    except (RPCError, ConnectionError, KeyError, ValueError) as exc:
        out.error(f"Parity run failed: {exc}")
        raise typer.Exit(1) from exc

    fmt = (output or "markdown").lower()
    if fmt == "json":
        payload = json.dumps(
            {
                "company": {"id": rec["id"], "slug": rec["slug"], "name": rec["name"]},
                "report": report,
                "lines": lines,
            },
            indent=2,
            default=str,
        )
        if output_file:
            output_file.write_text(payload)
            out.success(f"JSON written to {output_file}")
        else:
            typer.echo(payload)
    elif fmt == "xlsx":
        out.warn("xlsx output not yet implemented (Task 13). Falling back to markdown.")
        md = _format_parity_markdown(rec, report, lines)
        if output_file:
            output_file.write_text(md)
            out.success(f"Markdown written to {output_file}")
        else:
            typer.echo(md)
    else:
        md = _format_parity_markdown(rec, report, lines)
        if output_file:
            output_file.write_text(md)
            out.success(f"Markdown written to {output_file}")
        else:
            typer.echo(md)

    if not report.get("all_passed"):
        failed = report.get("total_count", 0) - report.get("passed_count", 0)
        out.error(f"{failed} parity check(s) FAILED for {rec['slug']}.")
        raise typer.Exit(1)
    out.success(f"All {report.get('total_count', 0)} parity checks PASSED for {rec['slug']}.")


@app.command("parity-all")
def parity_all(
    ctx: typer.Context,
    as_of: Annotated[
        str | None,
        typer.Option("--date", "-d", help="As-of date YYYY-MM-DD (default today)"),
    ] = None,
    tolerance: Annotated[
        float,
        typer.Option("--tolerance", help="IDR tolerance for deltas"),
    ] = 1.0,
    output_file: Annotated[
        Path | None,
        typer.Option("--output-file", help="Write consolidated markdown here instead of stdout"),
    ] = None,
) -> None:
    """Run parity suite across every accurate.company; emit consolidated markdown."""
    actx: AppContext = ctx.obj
    _bump_client_timeout(actx, seconds=600.0)
    out = actx.output
    c = actx.client

    companies = c.search_read(
        "accurate.company",
        domain=[],
        fields=["id", "slug", "name", "state"],
        order="name",
    )
    if not companies:
        out.warn("No accurate.company records found.")
        return

    chunks: list[str] = []
    effective_date = as_of or date.today().isoformat()
    chunks.append(f"# Consolidated Parity Scorecard — {effective_date}\n")
    scorecard_rows: list[tuple[str, str, int, int, bool]] = []
    any_failed = False

    for rec in companies:
        out.info(f"→ {rec['slug']}")
        try:
            report, lines = _run_parity_for_company(c, rec, as_of, None, tolerance)
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"{rec['slug']}: parity run FAILED — {exc}")
            any_failed = True
            chunks.append(f"## {rec['slug']} — ERROR\n\n`{exc}`\n")
            scorecard_rows.append((rec["slug"], rec["name"], 0, 0, False))
            continue
        passed = report.get("passed_count", 0)
        total = report.get("total_count", 0)
        all_passed = bool(report.get("all_passed"))
        if not all_passed:
            any_failed = True
        scorecard_rows.append((rec["slug"], rec["name"], passed, total, all_passed))
        chunks.append(_format_parity_markdown(rec, report, lines))
        chunks.append("")

    summary = [
        "## Summary",
        "",
        "| Slug | Name | Passed | Total | Overall |",
        "|---|---|---:|---:|---|",
    ]
    for slug, name, passed, total, all_passed in scorecard_rows:
        summary.append(f"| {slug} | {name} | {passed} | {total} | {'PASSED' if all_passed else 'FAILED'} |")
    full = "\n".join([*summary, "", *chunks])

    if output_file:
        output_file.write_text(full)
        out.success(f"Consolidated scorecard written to {output_file}")
    else:
        typer.echo(full)

    if any_failed:
        raise typer.Exit(1)
    out.success(f"All {len(companies)} tenant(s) passed every parity check.")


# --------------------------------------------------------------------------
# Phase 1 — snapshot + reconcile
# (spec: 2026-04-21-accurate-migration-cutoff-validation-design.md)
# --------------------------------------------------------------------------

snapshot_app = typer.Typer(help="Snapshot management — pull, list, export snapshots.")
reconcile_app = typer.Typer(help="Daily reconciliation commands.")


@snapshot_app.command("pull")
def snapshot_pull(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug")],
    source: Annotated[
        str,
        typer.Option(
            "--source",
            help="Which side(s) to snapshot: accurate, odoo, or both.",
        ),
    ] = "both",
    snapshot_date: Annotated[
        str | None,
        typer.Option("--date", "-d", help="Snapshot date YYYY-MM-DD (default today)."),
    ] = None,
) -> None:
    """Pull a snapshot on demand for <slug>."""
    actx: AppContext = ctx.obj
    _bump_client_timeout(actx, seconds=1200.0)

    date_str = snapshot_date or date.today().isoformat()
    sources = ["accurate", "odoo"] if source == "both" else [source]
    for src in sources:
        result = actx.client.execute_kw(
            "accurate.company",
            "cli_snapshot_pull",
            [[("slug", "=", slug)], src, date_str],
        )
        typer.echo(
            f"{src} snapshot created: id={result['snapshot_id']} lines={result['line_count']} state={result['state']}"
        )


@snapshot_app.command("list")
def snapshot_list(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug")],
    limit: Annotated[int, typer.Option("--limit", "-l")] = 30,
) -> None:
    """List recent snapshots for <slug>."""
    actx: AppContext = ctx.obj
    rows = actx.client.execute_kw(
        "accurate.snapshot",
        "cli_list_for_slug",
        [slug, limit],
    )
    typer.echo(json.dumps(rows, indent=2, default=str))


@snapshot_app.command("export")
def snapshot_export(
    ctx: typer.Context,
    snapshot_id: Annotated[int, typer.Argument(help="Snapshot record ID")],
    output: Annotated[
        Path,
        typer.Option("--output", "-o", help="Output file path (gzipped JSON)."),
    ],
) -> None:
    """Export snapshot <snapshot_id> to a gzipped JSON file."""
    actx: AppContext = ctx.obj
    import base64

    blob_b64 = actx.client.execute_kw(
        "accurate.snapshot",
        "cli_export_gzip",
        [snapshot_id],
    )
    output.write_bytes(base64.b64decode(blob_b64))
    typer.echo(f"Wrote {output}")


@reconcile_app.command("run")
def reconcile_run(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug")],
    validator: Annotated[
        list[str] | None,
        typer.Option("--validator", help="Validator name(s) to run. Default: all."),
    ] = None,
    run_date: Annotated[
        str | None,
        typer.Option("--date", "-d", help="Run date YYYY-MM-DD (default today)."),
    ] = None,
    tolerance: Annotated[
        float,
        typer.Option("--tolerance", help="Per-delta tolerance in account currency units."),
    ] = 1000.0,
) -> None:
    """Run reconciliation for <slug> with selected validators."""
    actx: AppContext = ctx.obj
    out = actx.output
    _bump_client_timeout(actx, seconds=1800.0)

    date_str = run_date or date.today().isoformat()
    result = actx.client.execute_kw(
        "accurate.company",
        "cli_reconcile_run",
        [
            [("slug", "=", slug)],
            validator or None,
            date_str,
            tolerance,
        ],
    )
    out.info(
        f"Report id={result['report_id']} state={result['state']} "
        f"green={result['green']} amber={result['amber']} red={result['red']}"
    )
    for line in result.get("lines", []):
        typer.echo(f"  {line['validator_name']:20s} {line['status']:6s} Δ={line['delta']:+,.0f}")
    if result.get("state") not in ("passed", "green"):
        raise typer.Exit(1)


# --- Phase 4 — variance + cutover + audit-package ----------------------


variance_app = typer.Typer(help="Variance explanations (Phase 4).")


@variance_app.command("list")
def variance_list(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Tenant slug")],
) -> None:
    """List variance explanations for <slug>."""
    actx: AppContext = ctx.obj
    rows = actx.client.execute_kw(
        "accurate.company",
        "cli_variance_list",
        [slug],
    )
    typer.echo(json.dumps(rows, indent=2))


@variance_app.command("add")
def variance_add(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Tenant slug")],
    validator: Annotated[str, typer.Option("--validator", "-v", help="Validator name")],
    delta_key: Annotated[str, typer.Option("--delta-key", "-k", help="Delta key (glob or exact)")],
    explanation: Annotated[str, typer.Option("--explanation", "-e", help="Explanation text")],
    category: Annotated[str, typer.Option("--category", "-c", help="Variance category")] = "cutover_timing",
    expires: Annotated[
        str | None,
        typer.Option("--expires", help="Expiry date YYYY-MM-DD; default today+30d"),
    ] = None,
) -> None:
    """Create a variance explanation."""
    actx: AppContext = ctx.obj
    result = actx.client.execute_kw(
        "accurate.company",
        "cli_variance_add",
        [slug, validator, delta_key, category, explanation, expires],
    )
    typer.echo(f"Created explanation id={result['id']} delta_key={result['delta_key']}")


@variance_app.command("expire")
def variance_expire(
    ctx: typer.Context,
    explanation_id: Annotated[int, typer.Argument(help="Explanation record ID")],
) -> None:
    """Expire (deactivate) a variance explanation."""
    actx: AppContext = ctx.obj
    result = actx.client.execute_kw(
        "accurate.company",
        "cli_variance_expire",
        [explanation_id],
    )
    typer.echo(f"Expired id={result['id']} active={result['active']}")


cutover_status_app = typer.Typer(help="Cutover readiness + execution (Phase 4).")


@cutover_status_app.command("status")
def cutover_status(ctx: typer.Context) -> None:
    """Streak status across all tenants."""
    actx: AppContext = ctx.obj
    rows = actx.client.execute_kw(
        "accurate.company",
        "cli_cutover_status",
        [],
    )
    typer.echo(f"{'slug':12s} {'streak':>8s} {'required':>10s} {'ready?':>8s}")
    typer.echo("-" * 40)
    for r in rows:
        ready = "yes" if r["ready"] else "no"
        typer.echo(f"{r['slug']:12s} {r['streak']:>8d} {r['required']:>10d} {ready:>8s}")


@app.command("audit-package")
def audit_package(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Tenant slug")],
    output: Annotated[str, typer.Option("-o", "--output", help="Output zip path")],
) -> None:
    """Generate the audit package zip for <slug>."""
    actx: AppContext = ctx.obj
    import base64

    _bump_client_timeout(actx, seconds=300.0)
    blob_b64 = actx.client.execute_kw(
        "accurate.company",
        "cli_audit_package",
        [[("slug", "=", slug)]],
    )
    with open(output, "wb") as f:
        f.write(base64.b64decode(blob_b64))
    typer.echo(f"Wrote {output}")


@app.command("report")
def migration_report(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Tenant slug (or 'all' for all companies)")],
    output: Annotated[
        Path | None,
        typer.Option("-o", "--output", help="Output Excel path"),
    ] = None,
) -> None:
    """Generate a migration report Excel for one or all companies."""
    actx: AppContext = ctx.obj
    _bump_client_timeout(actx, seconds=600.0)
    c = actx.client
    out = actx.output

    if slug == "all":
        companies = c.search_read(
            "accurate.company",
            domain=[],
            fields=["id", "slug"],
            order="id",
        )
    else:
        rec = _resolve_accurate_company(c, slug)
        companies = [rec]

    out.info(f"Generating migration report for {len(companies)} company(ies)...")

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        out.error("openpyxl not installed. Run: pip install openpyxl")
        raise typer.Exit(1)

    wb = Workbook()
    hdr_font = Font(bold=True, color="FFFFFF", size=11)
    hdr_fill = PatternFill("solid", fgColor="2F5496")
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    inc_fill = PatternFill("solid", fgColor="FFEB9C")
    border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9"),
    )

    def write_headers(ws, headers, widths=None):
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = hdr_font
            cell.fill = hdr_fill
            cell.alignment = Alignment(horizontal="center", wrap_text=True)
        if widths:
            for i, w in enumerate(widths, 1):
                ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = "A2"

    # -- Sheet 1: Summary --
    ws1 = wb.active
    ws1.title = "Migration Summary"
    write_headers(
        ws1,
        [
            "Company",
            "Slug",
            "State",
            "Phase",
            "Cutover Date",
            "Total Moves",
            "Opening JE",
            "BS Adjustment",
            "Parity Passed",
            "Parity Total",
            "Parity %",
        ],
        [30, 35, 12, 22, 14, 12, 10, 12, 12, 12, 10],
    )

    row = 2
    all_parity_data = {}
    for comp in companies:
        rec = c.search_read(
            "accurate.company",
            domain=[("id", "=", comp["id"])],
            fields=[
                "name",
                "slug",
                "state",
                "current_phase",
                "cutover_date",
                "odoo_company_id",
            ],
        )[0]
        co_id = rec["odoo_company_id"][0] if rec["odoo_company_id"] else 0

        moves = c.search_count(
            "account.move",
            [
                ("company_id", "=", co_id),
                ("state", "=", "posted"),
            ],
        )
        opening = c.search_count(
            "account.move",
            [
                ("company_id", "=", co_id),
                ("x_accurate_migration_source", "=", "opening_gl_trial_balance"),
            ],
        )
        bs_adj = c.search_count(
            "account.move",
            [
                ("company_id", "=", co_id),
                ("x_accurate_migration_source", "=", "bs_adjustment"),
            ],
        )

        # Latest parity report
        parity_reports = c.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", comp["id"])],
            fields=["passed_count", "total_count", "run_date", "all_passed"],
            order="id desc",
            limit=1,
        )
        p_passed = parity_reports[0]["passed_count"] if parity_reports else 0
        p_total = parity_reports[0]["total_count"] if parity_reports else 0
        p_pct = f"{p_passed * 100 // p_total}%" if p_total else "N/A"

        ws1.cell(row=row, column=1, value=rec["name"]).font = Font(size=10)
        ws1.cell(row=row, column=2, value=rec["slug"]).font = Font(size=10)
        ws1.cell(row=row, column=3, value=rec["state"]).font = Font(size=10)
        ws1.cell(row=row, column=4, value=rec["current_phase"]).font = Font(size=10)
        ws1.cell(row=row, column=5, value=rec["cutover_date"]).font = Font(size=10)
        ws1.cell(row=row, column=6, value=moves).font = Font(size=10)
        ws1.cell(row=row, column=7, value="Yes" if opening else "No").font = Font(size=10, bold=True)
        ws1.cell(row=row, column=7).fill = pass_fill if opening else fail_fill
        ws1.cell(row=row, column=8, value="Yes" if bs_adj else "No").font = Font(size=10, bold=True)
        ws1.cell(row=row, column=8).fill = pass_fill if bs_adj else fail_fill
        ws1.cell(row=row, column=9, value=p_passed).font = Font(size=10)
        ws1.cell(row=row, column=10, value=p_total).font = Font(size=10)
        ws1.cell(row=row, column=11, value=p_pct).font = Font(size=10, bold=True)

        for col in range(1, 12):
            ws1.cell(row=row, column=col).border = border
        row += 1

        all_parity_data[rec["slug"]] = parity_reports[0] if parity_reports else None
        out.info(f"  {rec['slug']}: {moves} moves, parity {p_passed}/{p_total}")

    # -- Sheet 2: Parity Detail --
    ws2 = wb.create_sheet("Parity Detail")
    write_headers(
        ws2,
        [
            "Company",
            "Check",
            "Category",
            "Status",
            "Accurate",
            "Odoo",
            "Delta",
            "Source",
            "Notes",
        ],
        [30, 18, 12, 8, 18, 18, 18, 12, 50],
    )

    row = 2
    for comp in companies:
        reports = c.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", comp["id"])],
            fields=["id"],
            order="id desc",
            limit=1,
        )
        if not reports:
            continue
        lines = c.search_read(
            "accurate.parity.line",
            domain=[("report_id", "=", reports[0]["id"])],
            fields=[
                "check_name",
                "category",
                "status",
                "accurate_total",
                "odoo_total",
                "source",
                "remediation_hints",
            ],
            order="id",
        )
        rec_name = c.search_read(
            "accurate.company",
            [("id", "=", comp["id"])],
            fields=["name"],
        )[0]["name"]

        for ln in lines:
            delta = (ln.get("odoo_total") or 0) - (ln.get("accurate_total") or 0)
            status = ln.get("status") or "?"
            ws2.cell(row=row, column=1, value=rec_name).font = Font(size=10)
            ws2.cell(row=row, column=2, value=ln["check_name"]).font = Font(size=10)
            ws2.cell(row=row, column=3, value=ln.get("category") or "").font = Font(size=10)
            status_cell = ws2.cell(row=row, column=4, value=status.upper())
            status_cell.font = Font(size=10, bold=True)
            if status == "passed":
                status_cell.fill = pass_fill
            elif status == "failed":
                status_cell.fill = fail_fill
            else:
                status_cell.fill = inc_fill
            ws2.cell(row=row, column=5, value=ln.get("accurate_total") or 0).font = Font(size=10)
            ws2.cell(row=row, column=5).number_format = "#,##0.00"
            ws2.cell(row=row, column=6, value=ln.get("odoo_total") or 0).font = Font(size=10)
            ws2.cell(row=row, column=6).number_format = "#,##0.00"
            ws2.cell(row=row, column=7, value=delta).font = Font(size=10)
            ws2.cell(row=row, column=7).number_format = "#,##0.00"
            ws2.cell(row=row, column=8, value=ln.get("source") or "").font = Font(size=10)
            hints = ln.get("remediation_hints") or ""
            ws2.cell(row=row, column=9, value=hints[:200] if hints else "").font = Font(size=9)
            for col in range(1, 10):
                ws2.cell(row=row, column=col).border = border
            row += 1

    ws2.auto_filter.ref = f"A1:I{row - 1}"

    # -- Sheet 3: Move Breakdown --
    ws3 = wb.create_sheet("Move Breakdown")
    write_headers(
        ws3,
        [
            "Company",
            "Source",
            "Move Count",
        ],
        [30, 30, 12],
    )

    row = 2
    source_labels = [
        ("opening_gl_trial_balance", "Opening GL Trial Balance"),
        ("bs_adjustment", "BS Adjustment"),
        ("current_fy_full", "Current FY Transactions"),
        ("gap_sync", "Gap Sync Backfill"),
        ("ar_ap_reversal", "AR/AP Reversal"),
        ("outstanding_open_items", "Outstanding Open Items"),
        ("pnl_neutralization", "P&L Neutralization"),
    ]
    for comp in companies:
        rec = c.search_read(
            "accurate.company",
            [("id", "=", comp["id"])],
            fields=["name", "odoo_company_id"],
        )[0]
        co_id = rec["odoo_company_id"][0] if rec["odoo_company_id"] else 0
        for src_code, src_label in source_labels:
            cnt = c.search_count(
                "account.move",
                [
                    ("company_id", "=", co_id),
                    ("x_accurate_migration_source", "=", src_code),
                    ("state", "=", "posted"),
                ],
            )
            if cnt:
                ws3.cell(row=row, column=1, value=rec["name"]).font = Font(size=10)
                ws3.cell(row=row, column=2, value=src_label).font = Font(size=10)
                ws3.cell(row=row, column=3, value=cnt).font = Font(size=10)
                for col in range(1, 4):
                    ws3.cell(row=row, column=col).border = border
                row += 1
        # Non-migration moves
        total = c.search_count(
            "account.move",
            [
                ("company_id", "=", co_id),
                ("state", "=", "posted"),
            ],
        )
        migration = c.search_count(
            "account.move",
            [
                ("company_id", "=", co_id),
                ("state", "=", "posted"),
                ("x_accurate_migration_source", "!=", False),
            ],
        )
        other = total - migration
        if other:
            ws3.cell(row=row, column=1, value=rec["name"]).font = Font(size=10)
            ws3.cell(row=row, column=2, value="Other (non-migration)").font = Font(size=10)
            ws3.cell(row=row, column=3, value=other).font = Font(size=10)
            for col in range(1, 4):
                ws3.cell(row=row, column=col).border = border
            row += 1

    # -- Sheet 4: Phase History --
    ws4 = wb.create_sheet("Phase History")
    write_headers(
        ws4,
        [
            "Company",
            "Phase",
            "State",
            "Started",
            "Duration (s)",
        ],
        [30, 22, 10, 22, 12],
    )

    row = 2
    for comp in companies:
        rec = c.search_read(
            "accurate.company",
            [("id", "=", comp["id"])],
            fields=["name"],
        )[0]
        phases = c.search_read(
            "accurate.company.phase",
            domain=[("company_id", "=", comp["id"]), ("state", "=", "passed")],
            fields=["phase_code", "state", "started_at", "duration_s"],
            order="id desc",
            limit=20,
        )
        for p in phases:
            ws4.cell(row=row, column=1, value=rec["name"]).font = Font(size=10)
            ws4.cell(row=row, column=2, value=p.get("phase_code") or "").font = Font(size=10)
            state_cell = ws4.cell(row=row, column=3, value=p.get("state") or "")
            state_cell.font = Font(size=10)
            state_cell.fill = pass_fill if p.get("state") == "passed" else fail_fill
            ws4.cell(row=row, column=4, value=p.get("started_at") or "").font = Font(size=10)
            ws4.cell(row=row, column=5, value=p.get("duration_s") or 0).font = Font(size=10)
            ws4.cell(row=row, column=5).number_format = "#,##0"
            for col in range(1, 6):
                ws4.cell(row=row, column=col).border = border
            row += 1

    # -- Save --
    if not output:
        safe_slug = slug.replace("/", "_").replace(" ", "_")
        output = Path(f"migration_report_{safe_slug}_{date.today().isoformat()}.xlsx")
    wb.save(str(output))
    out.info(f"Report saved to {output}")
    out.info(f"  Sheet 1: Migration Summary ({len(companies)} companies)")
    out.info("  Sheet 2: Parity Detail (12 checks per company)")
    out.info("  Sheet 3: Move Breakdown (by migration source)")
    out.info("  Sheet 4: Phase History")


# --- JV commands -------------------------------------------------------


@app.command("jv-sync")
def jv_sync(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--execute", help="Dry-run mode (default). Use --execute to write."),
    ] = True,
    date_from: Annotated[
        str | None,
        typer.Option("--date-from", help="Start date YYYY-MM-DD (informational, not yet filtered)"),
    ] = None,
    date_to: Annotated[
        str | None,
        typer.Option("--date-to", help="End date YYYY-MM-DD (informational, not yet filtered)"),
    ] = None,
) -> None:
    """JV-first sync: import ALL Accurate journal vouchers as account.move entries.

    Uses the journal-voucher API as the single source of GL truth.
    Invoices (SI/PI) already imported via module APIs are skipped (or kept
    for COGS-only lines on SI JVs). Idempotent — existing ext-ids are skipped.

    By default runs in dry-run mode. Pass --execute to write records.

    \\b
    Examples:
      kctl-odoo accurate jv-sync terra-buah              # dry-run (safe)
      kctl-odoo accurate jv-sync terra-buah --execute    # write to Odoo
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=3600.0)

    rec = _resolve_accurate_company(c, slug)
    mode = "DRY-RUN" if dry_run else "EXECUTE"
    out.info(f"JV-first sync for {rec['slug']} [{mode}]...")

    kwargs: dict = {"dry_run": dry_run}
    if date_from:
        kwargs["date_from"] = date_from
    if date_to:
        kwargs["date_to"] = date_to

    result = c.execute_kw(
        "accurate.company",
        "action_sync_jv_first",
        [[rec["id"]]],
        kwargs,
    )

    out.table(
        f"JV-first sync — {rec['slug']} [{mode}]",
        [("Metric", ""), ("Count", "cyan")],
        [
            ["Created", str(result.get("created", 0))],
            ["Skipped", str(result.get("skipped", 0))],
            ["Errors", str(result.get("errors", 0))],
        ],
        data_for_json=result,
    )

    if result.get("errors", 0) > 0:
        out.warn(f"{result['errors']} JVs failed — check Odoo server logs for details.")
    if dry_run:
        out.info("Dry-run complete. Re-run with --execute to write records.")
    else:
        out.success(
            f"JV sync complete: {result.get('created', 0)} created, "
            f"{result.get('skipped', 0)} skipped, {result.get('errors', 0)} errors."
        )


@app.command("jv-router")
def jv_router(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--execute", help="Dry-run mode (default). Use --execute to write."),
    ] = True,
) -> None:
    """Single-pass JV router: import all Accurate JVs with correct Odoo types.

    Routes each JV by transactionType:
    - SI -> out_invoice + COGS entry
    - PI -> in_invoice + extra entry (if needed)
    - * -> entry (all lines)

    Idempotent, no dedup needed. By default dry-run.

    \\b
    Examples:
      kctl-odoo accurate jv-router terra-buah              # dry-run
      kctl-odoo accurate jv-router terra-buah --execute     # write
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=3600.0)

    rec = _resolve_accurate_company(c, slug)
    mode = "DRY-RUN" if dry_run else "EXECUTE"
    out.info(f"JV router for {rec['slug']} [{mode}]...")

    result = c.execute_kw(
        "accurate.company",
        "action_jv_router",
        [[rec["id"]]],
        {"dry_run": dry_run},
    )

    out.table(
        f"JV Router — {rec['slug']} [{mode}]",
        [("Metric", ""), ("Count", "cyan")],
        [
            ["Invoices created", str(result.get("invoices", 0))],
            ["Entries created", str(result.get("entries", 0))],
            ["Skipped (existing)", str(result.get("skipped", 0))],
            ["Errors", str(result.get("errors", 0))],
        ],
        data_for_json=result,
    )

    if result.get("errors", 0) > 0:
        out.warn(f"{result['errors']} JVs failed — check Odoo logs.")
    if dry_run:
        out.info("Dry-run complete. Re-run with --execute to write.")
    else:
        out.success("JV router complete.")


@app.command("migrate")
def migrate_cpr(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
    wipe: Annotated[bool, typer.Option("--wipe", help="Wipe existing data before sync")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout in seconds")] = 3600,
) -> None:
    """Create-Post-Retype migration: exact GL + invoices/bills in menus.

    Phase 1: Validate master data
    Phase 2: Sync all JVs as entries (exact GL)
    Phase 3: Retype SI->invoice, PI->bill (SQL metadata update)
    Phase 4: Validate P&L + BS + counts

    \\b
    Examples:
      kctl-odoo accurate migrate terra-buah                    # dry-run
      kctl-odoo accurate migrate terra-buah --execute          # run
      kctl-odoo accurate migrate terra-buah --execute --wipe   # fresh start
      kctl-odoo accurate migrate griya --execute --timeout 7200  # 2h timeout
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, slug)
    mode = "DRY-RUN" if dry_run else "EXECUTE"
    out.info(f"CPR Migration for {rec['slug']} [{mode}]{'  --wipe' if wipe else ''}")

    # Use docker for local profiles (avoids JSON-RPC timeout on large migrations)
    is_local = hasattr(actx, "local") and actx.local is not None
    if is_local and not dry_run:
        result = _run_via_docker_exec(
            actx,
            out,
            "action_migrate_cpr",
            rec["id"],
            kwargs={"dry_run": dry_run, "wipe": wipe},
            timeout=timeout,
        )
        if not result:
            out.success("CPR Migration complete (output above).")
            return
    else:
        _bump_client_timeout(actx, seconds=float(timeout))
        result = c.execute_kw(
            "accurate.company",
            "action_migrate_cpr",
            [[rec["id"]]],
            {"dry_run": dry_run, "wipe": wipe},
        )

    # Phase 1
    p1 = result.get("phase1", {})
    if not p1.get("passed"):
        out.error(f"Phase 1 FAILED: {[c['name'] for c in p1.get('checks', []) if not c.get('passed')]}")
        out.error("Fix master data and re-run.")
        raise typer.Exit(1)

    p2 = result.get("phase2", {})
    p3 = result.get("phase3", {})
    p4 = result.get("phase4", {})
    p5 = result.get("phase5", {})
    p6 = result.get("phase6", {})
    p7 = result.get("phase7", {})
    p8 = result.get("phase8", {})
    p9 = result.get("phase9", {})
    parity = p4.get("parity", {}) if p4 else {}
    tb = parity.get("tb", {})
    pnl = parity.get("pnl", {})
    bs = parity.get("bs", {})

    def _pass(v):
        return "✓ PASS" if v else "✗ FAIL"

    rows = [
        [
            "Phase 1",
            "Validate Master Data",
            _pass(p1.get("passed")),
            f"{p1.get('jv_cache_size', 0)} JVs cached, {p1.get('auto_resolved_partners', 0)} auto-resolved",
        ],
    ]
    for check in p1.get("checks", []):
        cname = check.get("name", "")
        cpassed = check.get("passed")
        cdetail = check.get("detail", "")
        status = (
            "✓"
            if cpassed
            else ("⚠" if cname in ("products", "bank_account_journal_map", "payment_method_lines") else "✗")
        )
        rows.append(["", f"  {cname}", status, cdetail])

    rows += [
        ["", "", "", ""],
        [
            "Phase 2",
            "Sync JVs -> Entries",
            f"{p2.get('created', 0)} created",
            f"{p2.get('skipped', 0)} skipped, {p2.get('errors', 0)} errors",
        ],
        [
            "Phase 3",
            "Retype SI/PI",
            f"{p3.get('si_retyped', p3.get('si_would_retype', 0))} INV, {p3.get('pi_retyped', p3.get('pi_would_retype', 0))} BILL",
            "Product lines enriched",
        ],
        ["Phase 5", "Payments", f"{p5.get('payments_created', 0)} created", "CUST.IN + SUPP.OUT"],
        ["Phase 6", "Reconciliation", f"{p6.get('partials_created', 0)} partials", "AR/AP matched"],
        [
            "Phase 7",
            "Stock Valuation",
            f"{p7.get('quants_created', 0)} quants, {p7.get('svl_created', 0)} SVL",
            "Opening on-hand",
        ],
        ["Phase 8", "Bank Statements", f"{p8.get('bank_statement_lines', 0)} lines", "Reconciliation widget"],
        [
            "Phase 9",
            "PO + SO Import",
            f"{p9.get('po_created', 0)} PO, {p9.get('so_created', 0)} SO",
            "Purchase/sales history",
        ],
    ]

    # Validation section
    if p4:
        rows.append(["", "", "", ""])
        rows.append(
            [
                "Phase 4",
                "Trial Balance",
                _pass(p4.get("tb_balanced")),
                f"Dr={tb.get('accurate_debit', 0):,.2f}  Cr={tb.get('accurate_credit', 0):,.2f}",
            ]
        )
        if tb:
            rows.append(
                [
                    "",
                    "  TB Debit Match",
                    _pass(tb.get("debit_match")),
                    f"{tb.get('accounts', 0)} accounts, {tb.get('mismatches', 0)} mismatches",
                ]
            )
        if pnl:
            rows.append(["", "  P&L Net Income", _pass(pnl.get("match")), f"{pnl.get('net_income', 0):,.2f}"])
        if bs:
            rows.append(["", "  BS Assets", "", f"{bs.get('total_assets', 0):,.2f}"])
            rows.append(["", "  BS Liab+Equity", "", f"{bs.get('liabilities_equity', 0):,.2f}"])
            rows.append(["", "  BS A = L+E+NI", _pass(bs.get("bs_equation")), "Accounting equation"])

    # Record counts
    if p4:
        rows.append(["", "", "", ""])
        rows.append(["", "Invoices", str(p4.get("invoice_count", 0)), ""])
        rows.append(["", "Bills", str(p4.get("bill_count", 0)), ""])
        rows.append(["", "Entries", str(p4.get("entry_count", 0)), ""])
        rows.append(["", "Payments", str(p4.get("payment_count", 0)), ""])
        rows.append(["", "Bank Lines", str(p4.get("bank_line_count", 0)), ""])
        rows.append(["", "Total Moves", str(p4.get("total", 0)), ""])

    out.table(
        f"CPR Migration — {rec['slug']} [{mode}]",
        [("Phase", ""), ("Check", ""), ("Result", "cyan"), ("Detail", "")],
        rows,
        data_for_json=result,
    )

    if p2.get("errors", 0) > 0:
        out.warn(f"{p2['errors']} JVs failed — check Odoo logs.")
    if dry_run:
        out.info("Dry-run complete. Re-run with --execute to write.")
    else:
        out.success("CPR Migration complete.")
