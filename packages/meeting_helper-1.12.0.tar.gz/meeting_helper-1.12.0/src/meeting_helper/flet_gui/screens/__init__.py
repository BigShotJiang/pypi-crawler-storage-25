"""Flet GUI screens."""

from meeting_helper.flet_gui.screens.dashboard import DashboardScreen
from meeting_helper.flet_gui.screens.recordings import RecordingsScreen
from meeting_helper.flet_gui.screens.settings import SettingsScreen
from meeting_helper.flet_gui.screens.workspace import WorkspaceScreen

__all__ = ["DashboardScreen", "RecordingsScreen", "SettingsScreen", "WorkspaceScreen"]
