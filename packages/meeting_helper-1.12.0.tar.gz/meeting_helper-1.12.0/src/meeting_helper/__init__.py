"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "1.12.0"
