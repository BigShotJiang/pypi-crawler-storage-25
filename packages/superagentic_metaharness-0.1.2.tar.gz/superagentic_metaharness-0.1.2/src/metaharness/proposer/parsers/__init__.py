# Event parser helpers.
