from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from eml_units import check_contract, check_data, normalize_unit

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "examples"


def codes(report):
    return {diagnostic.code for diagnostic in report.diagnostics}


def test_valid_darpa_style_contract_warns_but_has_no_errors():
    report = check_contract(EXAMPLES / "darpa_kernel_contract.json")
    assert report.status in {"pass", "warn"}
    assert all(diagnostic.severity != "error" for diagnostic in report.diagnostics)
    assert report.fields_checked > 0


def test_field_kernel_contract_passes():
    report = check_contract(EXAMPLES / "field_kernel_acoustic.json")
    assert report.status == "pass"
    assert report.diagnostics == []


def test_unitless_gaussian_contract_passes():
    report = check_contract(EXAMPLES / "efrog_gaussian_unitless.json")
    assert report.status == "pass"


def test_bad_contract_reports_expected_warning_codes():
    report = check_contract(EXAMPLES / "bad_missing_units.json")
    assert report.status == "warn"
    expected = {
        "UNIT_MISSING",
        "UNIT_UNKNOWN",
        "LATENCY_UNIT_MISSING",
        "NORMALIZED_RANGE_SUSPICIOUS",
        "BOOL_UNIT_MISMATCH",
        "TRACE_UNIT_MISSING",
        "GUARD_UNIT_MISSING",
    }
    assert expected.issubset(codes(report))


def test_unknown_unit_warning():
    report = check_data(
        {
            "kernel_id": "example.unknown_unit",
            "outputs": [{"name": "y", "type": "float", "unit": "bananas", "range": [0, 1]}],
        }
    )
    assert "UNIT_UNKNOWN" in codes(report)


def test_missing_range_warning():
    report = check_data({"kernel_id": "example.missing_range", "inputs": [{"name": "x", "type": "float", "unit": "volts"}]})
    assert "RANGE_MISSING" in codes(report)


def test_normalized_aliases():
    assert normalize_unit("unit_interval") == "normalized"
    assert normalize_unit("ms") == "milliseconds"
    assert normalize_unit("V") == "volts"


def test_malformed_json_is_error(tmp_path: Path):
    path = tmp_path / "bad.json"
    path.write_text("{", encoding="utf-8")
    report = check_contract(path)
    assert report.status == "error"
    assert codes(report) == {"MALFORMED_JSON"}


def run_cli(*args: str):
    return subprocess.run(
        [sys.executable, "-m", "eml_units.cli", *args],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def test_cli_vocabulary_smoke():
    result = run_cli("vocabulary")
    assert result.returncode == 0
    assert "Hz:" in result.stdout
    assert "pwm_duty:" in result.stdout


def test_cli_validate_good_contract():
    result = run_cli("validate", str(EXAMPLES / "field_kernel_acoustic.json"))
    assert result.returncode == 0
    assert "status: pass" in result.stdout


def test_cli_validate_bad_contract_is_warning_not_failure():
    result = run_cli("validate", str(EXAMPLES / "bad_missing_units.json"))
    assert result.returncode == 0
    assert "status: warn" in result.stdout
    assert "UNIT_MISSING" in result.stdout


def test_cli_json_report():
    result = run_cli("validate", str(EXAMPLES / "bad_missing_units.json"), "--json")
    assert result.returncode == 0
    data = json.loads(result.stdout)
    assert data["status"] == "warn"
    assert data["diagnostic_count"] >= 1
