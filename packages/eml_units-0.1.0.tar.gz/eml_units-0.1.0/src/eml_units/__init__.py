"""Unit and range diagnostics for EML-style contract sidecars."""

from .core import Diagnostic, UnitReport, check_contract, check_data, load_contract
from .vocabulary import KNOWN_UNITS, normalize_unit

__all__ = [
    "Diagnostic",
    "KNOWN_UNITS",
    "UnitReport",
    "check_contract",
    "check_data",
    "load_contract",
    "normalize_unit",
]

__version__ = "0.1.0"
