"""Core unit/range diagnostics for EML-style contract sidecars."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .schemas import validate_shape
from .vocabulary import (
    BOOLEAN_UNITS,
    KNOWN_UNITS,
    NORMALIZED_UNITS,
    TIME_UNITS,
    is_known_unit,
    normalize_unit,
)

SECTIONS = (
    "inputs",
    "outputs",
    "state_variables",
    "parameters",
    "latency_budgets",
    "guard_layer",
    "component_contracts",
    "traces",
    "projections",
)

RANGE_EXPECTED_TYPES = {"float", "integer", "number"}
UNIT_EXPECTED_TYPES = {"float", "integer", "number", "boolean"}


@dataclass(frozen=True)
class Diagnostic:
    severity: str
    path: str
    field: str
    message: str
    suggested_fix: str
    code: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class UnitReport:
    path: str | None
    contract_id: str
    status: str
    diagnostics: list[Diagnostic]
    fields_checked: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "contract_id": self.contract_id,
            "status": self.status,
            "diagnostic_count": len(self.diagnostics),
            "fields_checked": self.fields_checked,
            "diagnostics": [diagnostic.to_dict() for diagnostic in self.diagnostics],
        }


def load_contract(path: Path | str) -> Any:
    """Load a JSON contract sidecar."""

    return json.loads(Path(path).read_text(encoding="utf-8"))


def check_contract(path: Path | str) -> UnitReport:
    """Load and check a JSON contract sidecar."""

    contract_path = Path(path)
    try:
        data = load_contract(contract_path)
    except Exception as exc:
        return UnitReport(
            path=str(contract_path),
            contract_id="<unreadable>",
            status="error",
            diagnostics=[
                Diagnostic(
                    severity="error",
                    path="<root>",
                    field="json",
                    message=f"could not read JSON: {exc}",
                    suggested_fix="provide a readable JSON object",
                    code="MALFORMED_JSON",
                )
            ],
            fields_checked=0,
        )
    return check_data(data, path=str(contract_path))


def check_data(data: Any, path: str | None = None) -> UnitReport:
    """Check an already-loaded contract object."""

    shape_errors = validate_shape(data)
    contract_id = _contract_id(data)
    if shape_errors:
        return UnitReport(
            path=path,
            contract_id=contract_id,
            status="error",
            diagnostics=[
                Diagnostic(
                    severity="error",
                    path="<root>",
                    field="schema",
                    message=message,
                    suggested_fix="use a JSON object as the contract root",
                    code="INVALID_SCHEMA_SHAPE",
                )
                for message in shape_errors
            ],
            fields_checked=0,
        )

    diagnostics: list[Diagnostic] = []
    fields_checked = 0
    for section in SECTIONS:
        if section in data:
            checked, section_diagnostics = _check_section(section, data[section], section)
            fields_checked += checked
            diagnostics.extend(section_diagnostics)

    status = "pass" if not diagnostics else "warn"
    return UnitReport(
        path=path,
        contract_id=contract_id,
        status=status,
        diagnostics=diagnostics,
        fields_checked=fields_checked,
    )


def summarize_reports(reports: Iterable[UnitReport]) -> dict[str, Any]:
    items = list(reports)
    diagnostics = [diagnostic for report in items for diagnostic in report.diagnostics]
    by_code: dict[str, int] = {}
    for diagnostic in diagnostics:
        by_code[diagnostic.code] = by_code.get(diagnostic.code, 0) + 1
    return {
        "contracts_checked": len(items),
        "pass": sum(1 for report in items if report.status == "pass"),
        "warn": sum(1 for report in items if report.status == "warn"),
        "error": sum(1 for report in items if report.status == "error"),
        "diagnostic_count": len(diagnostics),
        "fields_checked": sum(report.fields_checked for report in items),
        "diagnostics_by_code": dict(sorted(by_code.items())),
    }


def _contract_id(data: Any) -> str:
    if not isinstance(data, dict):
        return "<invalid>"
    return str(
        data.get("kernel_id")
        or data.get("contract_id")
        or data.get("id")
        or data.get("name")
        or "<unknown>"
    )


def _check_section(section: str, value: Any, path: str) -> tuple[int, list[Diagnostic]]:
    if section == "latency_budgets":
        return _check_latency_section(value, path)
    if section == "guard_layer":
        return _check_guard_layer(value, path)
    if section == "traces":
        return _check_trace_like(value, path, code="TRACE_UNIT_MISSING")
    if section == "projections":
        return _check_trace_like(value, path, code="TRACE_UNIT_MISSING")
    return _check_field_collection(value, path)


def _check_field_collection(value: Any, path: str) -> tuple[int, list[Diagnostic]]:
    diagnostics: list[Diagnostic] = []
    checked = 0
    for item_path, item in _iter_items(value, path):
        if isinstance(item, dict) and _looks_like_quantity(item):
            checked += 1
            diagnostics.extend(_check_quantity(item, item_path))
    return checked, diagnostics


def _check_latency_section(value: Any, path: str) -> tuple[int, list[Diagnostic]]:
    diagnostics: list[Diagnostic] = []
    checked = 0
    for item_path, item in _iter_items(value, path):
        if isinstance(item, dict):
            checked += 1
            unit = normalize_unit(item.get("unit"))
            if unit is None:
                diagnostics.append(
                    _diag(
                        "warn",
                        f"{item_path}.unit",
                        "unit",
                        "latency entry is missing a time unit",
                        "add seconds, milliseconds, or ticks",
                        "LATENCY_UNIT_MISSING",
                    )
                )
            elif unit not in TIME_UNITS:
                diagnostics.append(
                    _diag(
                        "warn",
                        f"{item_path}.unit",
                        "unit",
                        f"latency unit {item.get('unit')!r} is not a recognized time unit",
                        "use seconds, milliseconds, or ticks",
                        "LATENCY_UNIT_MISSING",
                    )
                )
    return checked, diagnostics


def _check_guard_layer(value: Any, path: str) -> tuple[int, list[Diagnostic]]:
    diagnostics: list[Diagnostic] = []
    checked = 0
    if not isinstance(value, dict):
        return checked, diagnostics
    margins = value.get("safety_margins", [])
    for item_path, item in _iter_items(margins, f"{path}.safety_margins"):
        if isinstance(item, dict):
            checked += 1
            unit = normalize_unit(item.get("unit"))
            if unit is None:
                diagnostics.append(
                    _diag(
                        "warn",
                        f"{item_path}.unit",
                        "unit",
                        "guard safety margin is missing a unit",
                        "add safety_margin, ticks, boolean, normalized, or unknown",
                        "GUARD_UNIT_MISSING",
                    )
                )
            elif not is_known_unit(unit):
                diagnostics.append(_unknown_unit_diag(item_path, item.get("unit")))
    return checked, diagnostics


def _check_trace_like(value: Any, path: str, code: str) -> tuple[int, list[Diagnostic]]:
    diagnostics: list[Diagnostic] = []
    checked = 0
    for item_path, item in _iter_items(value, path):
        if isinstance(item, dict) and _looks_like_quantity(item):
            checked += 1
            diagnostics.extend(_check_quantity(item, item_path, missing_unit_code=code))
    return checked, diagnostics


def _check_quantity(
    item: dict[str, Any],
    path: str,
    missing_unit_code: str = "UNIT_MISSING",
) -> list[Diagnostic]:
    diagnostics: list[Diagnostic] = []
    field_type = str(item.get("type", "")).lower()
    unit = normalize_unit(item.get("unit"))
    has_range = "range" in item

    if _expects_unit(field_type, item) and unit is None:
        diagnostics.append(
            _diag(
                "warn",
                f"{path}.unit",
                "unit",
                "unit is missing",
                "add a recognized unit such as unitless, normalized, Hz, seconds, volts, count, or unknown",
                missing_unit_code,
            )
        )
    elif unit is not None and not is_known_unit(unit):
        diagnostics.append(_unknown_unit_diag(path, item.get("unit")))

    if field_type in RANGE_EXPECTED_TYPES and not has_range:
        diagnostics.append(
            _diag(
                "warn",
                f"{path}.range",
                "range",
                "numeric field is missing a range",
                "add a two-element numeric range or document why it is unbounded",
                "RANGE_MISSING",
            )
        )

    if unit in NORMALIZED_UNITS and has_range and _suspicious_normalized_range(item.get("range")):
        diagnostics.append(
            _diag(
                "warn",
                f"{path}.range",
                "range",
                "normalized unit has a range outside [0, 1]",
                "use [0, 1] for normalized values or choose a non-normalized unit",
                "NORMALIZED_RANGE_SUSPICIOUS",
            )
        )

    if field_type == "boolean" and unit is not None and unit not in BOOLEAN_UNITS:
        diagnostics.append(
            _diag(
                "warn",
                f"{path}.unit",
                "unit",
                "boolean field has a non-boolean unit",
                "use boolean, unitless, or document the field as an integer/count",
                "BOOL_UNIT_MISMATCH",
            )
        )

    return diagnostics


def _expects_unit(field_type: str, item: dict[str, Any]) -> bool:
    if field_type in UNIT_EXPECTED_TYPES:
        return True
    if "range" in item:
        return True
    if any(key in item for key in ("max_value", "min_value", "default")):
        return True
    return False


def _looks_like_quantity(item: dict[str, Any]) -> bool:
    return any(key in item for key in ("name", "type", "unit", "range", "max_value", "min_value"))


def _iter_items(value: Any, path: str) -> Iterable[tuple[str, Any]]:
    if isinstance(value, list):
        for index, item in enumerate(value):
            yield f"{path}[{index}]", item
    elif isinstance(value, dict):
        for key, item in value.items():
            child_path = f"{path}.{key}"
            if isinstance(item, (dict, list)):
                yield from _iter_items(item, child_path)
            else:
                yield child_path, {"name": key, "type": _infer_scalar_type(item), "unit": None}


def _infer_scalar_type(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "float"
    return "string"


def _suspicious_normalized_range(value: Any) -> bool:
    if not isinstance(value, list) or len(value) != 2:
        return False
    low, high = value
    if not isinstance(low, (int, float)) or not isinstance(high, (int, float)):
        return False
    return low < 0 or high > 1 or low > high


def _unknown_unit_diag(path: str, unit: Any) -> Diagnostic:
    return _diag(
        "warn",
        f"{path}.unit",
        "unit",
        f"unit {unit!r} is not in the v0 vocabulary",
        "use a known unit or mark the unit as unknown",
        "UNIT_UNKNOWN",
    )


def _diag(
    severity: str,
    path: str,
    field: str,
    message: str,
    suggested_fix: str,
    code: str,
) -> Diagnostic:
    return Diagnostic(
        severity=severity,
        path=path,
        field=field,
        message=message,
        suggested_fix=suggested_fix,
        code=code,
    )
