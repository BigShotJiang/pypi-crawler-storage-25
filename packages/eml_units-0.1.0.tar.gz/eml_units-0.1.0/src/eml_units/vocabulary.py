"""Unit vocabulary for the warning-first checker."""

from __future__ import annotations

KNOWN_UNITS: dict[str, str] = {
    "unitless": "dimensionless scalar",
    "normalized": "dimensionless normalized scalar",
    "adc_normalized": "ADC reading normalized to a bounded range",
    "pwm_duty": "PWM duty fraction",
    "Hz": "cycles per second",
    "seconds": "time in seconds",
    "milliseconds": "time in milliseconds",
    "volts": "electric potential",
    "ohms": "electrical resistance",
    "farads": "capacitance",
    "henries": "inductance",
    "samples": "sample count",
    "frames": "frame count",
    "ticks": "discrete tick count",
    "boolean": "boolean flag",
    "count": "count",
    "index": "array or trace index",
    "arbitrary_normalized": "normalized or arbitrary scale quantity",
    "audio_level": "normalized audio level",
    "band_energy": "normalized frequency-band energy",
    "safety_margin": "guard or safety-margin scalar",
    "unknown": "explicitly unknown unit",
}

ALIASES: dict[str, str] = {
    "unit_interval": "normalized",
    "ratio": "normalized",
    "fraction": "normalized",
    "normalized_energy": "band_energy",
    "rms": "audio_level",
    "real": "arbitrary_normalized",
    "hz": "Hz",
    "s": "seconds",
    "sec": "seconds",
    "ms": "milliseconds",
    "us": "ticks",
    "microseconds": "ticks",
    "V": "volts",
    "volt": "volts",
    "ohm": "ohms",
    "F": "farads",
    "H": "henries",
    "bool": "boolean",
    "bool_tick": "boolean",
    "frame": "frames",
    "sample": "samples",
}

NORMALIZED_UNITS = {
    "normalized",
    "adc_normalized",
    "pwm_duty",
    "arbitrary_normalized",
    "audio_level",
    "band_energy",
}

TIME_UNITS = {"seconds", "milliseconds", "ticks"}
BOOLEAN_UNITS = {"boolean"}


def normalize_unit(unit: str | None) -> str | None:
    """Normalize known aliases while preserving unknown strings."""

    if unit is None:
        return None
    text = str(unit).strip()
    if not text:
        return None
    return ALIASES.get(text, text)


def is_known_unit(unit: str | None) -> bool:
    normalized = normalize_unit(unit)
    return bool(normalized and normalized in KNOWN_UNITS)
