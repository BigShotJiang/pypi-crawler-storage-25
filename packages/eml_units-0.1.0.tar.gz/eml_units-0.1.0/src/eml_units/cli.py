"""Command-line interface for eml-units."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core import UnitReport, check_contract, summarize_reports
from .vocabulary import KNOWN_UNITS

ROOT = Path(__file__).resolve().parents[2]
EXAMPLES_DIR = ROOT / "examples"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="eml-units",
        description="Warning-first unit/range checker for EML-style contract sidecars.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate", help="validate one contract JSON file")
    validate_parser.add_argument("contract", type=Path)
    validate_parser.add_argument("--json", action="store_true", help="emit JSON report")

    summary_parser = subparsers.add_parser("summary", help="summarize one contract JSON file")
    summary_parser.add_argument("contract", type=Path)

    subparsers.add_parser("vocabulary", help="print recognized unit vocabulary")
    subparsers.add_parser("validate-examples", help="validate bundled example contracts")

    args = parser.parse_args(argv)
    if args.command == "validate":
        report = check_contract(args.contract)
        if args.json:
            print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
        else:
            print_report(report)
        return 1 if report.status == "error" else 0
    if args.command == "summary":
        report = check_contract(args.contract)
        print_summary([report])
        return 1 if report.status == "error" else 0
    if args.command == "vocabulary":
        for unit, description in sorted(KNOWN_UNITS.items()):
            print(f"{unit}: {description}")
        return 0
    if args.command == "validate-examples":
        reports = [check_contract(path) for path in sorted(EXAMPLES_DIR.glob("*.json"))]
        print_summary(reports)
        for report in reports:
            print_report(report)
        return 1 if any(report.status == "error" for report in reports) else 0
    return 2


def print_report(report: UnitReport) -> None:
    print(f"path: {report.path}")
    print(f"contract_id: {report.contract_id}")
    print(f"status: {report.status}")
    print(f"fields_checked: {report.fields_checked}")
    print(f"diagnostics: {len(report.diagnostics)}")
    for diagnostic in report.diagnostics:
        print(
            f"{diagnostic.severity.upper()} {diagnostic.code} "
            f"{diagnostic.path}: {diagnostic.message} "
            f"(fix: {diagnostic.suggested_fix})"
        )


def print_summary(reports: list[UnitReport]) -> None:
    summary = summarize_reports(reports)
    print(f"contracts_checked: {summary['contracts_checked']}")
    print(f"pass: {summary['pass']}")
    print(f"warn: {summary['warn']}")
    print(f"error: {summary['error']}")
    print(f"fields_checked: {summary['fields_checked']}")
    print(f"diagnostic_count: {summary['diagnostic_count']}")
    for code, count in summary["diagnostics_by_code"].items():
        print(f"{code}: {count}")


if __name__ == "__main__":
    raise SystemExit(main())
