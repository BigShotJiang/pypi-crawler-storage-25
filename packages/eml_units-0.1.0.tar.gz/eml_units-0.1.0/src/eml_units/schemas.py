"""Small schema helpers for EML unit diagnostics."""

from __future__ import annotations

from typing import Any


def is_contract_root(data: Any) -> bool:
    return isinstance(data, dict)


def validate_shape(data: Any) -> list[str]:
    """Return hard shape errors only.

    v0 is deliberately permissive: contract-family differences should become
    warning diagnostics, not schema failures.
    """

    if not isinstance(data, dict):
        return ["contract root must be a JSON object"]
    return []
