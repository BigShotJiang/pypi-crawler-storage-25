# eml-units

`eml-units` is a lightweight unit/range/domain checker for EML-style JSON
contract sidecars.

It loads contract JSON, walks common Monogate contract sections, and emits
warning-level diagnostics for missing units, unknown units, missing ranges,
suspicious normalized ranges, latency unit gaps, boolean/unit mismatches, trace
unit gaps, and guard unit gaps.

It does not modify Forge compiler behavior, certify engineering safety, or
provide formal dimensional proof.

## CLI

```bash
eml-units validate examples/darpa_kernel_contract.json
eml-units summary examples/darpa_kernel_contract.json
eml-units vocabulary
eml-units validate-examples
```

`validate` exits nonzero only for malformed JSON or invalid contract shape.
Unit hygiene findings are emitted as diagnostics so teams can improve sidecars
without treating this v0 checker as a certification tool.

## Python

```python
from pathlib import Path
from eml_units import check_contract

report = check_contract(Path("examples/darpa_kernel_contract.json"))
print(report.status)
```

## Diagnostic Shape

```json
{
  "severity": "warn",
  "path": "inputs[0].unit",
  "field": "unit",
  "message": "unit is missing",
  "suggested_fix": "add a recognized unit such as unitless, normalized, Hz, seconds, volts, count, or unknown",
  "code": "UNIT_MISSING"
}
```

## Boundaries

- warning-first unit/range checker;
- no Forge compiler changes;
- no hardware interaction;
- no certified engineering or safety claim;
- no formal dimensional proof claim.
