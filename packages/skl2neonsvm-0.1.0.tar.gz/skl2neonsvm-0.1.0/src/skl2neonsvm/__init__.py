"""
skl2neonsvm
===========

Library for converting SVM based sklearn models to neonsvm YAML format
in order to use it with neonsvm C++ inference library.

Example
-------
Train svm model:
>>> from sklearn.datasets import make_classification
>>> from sklearn.svm import SVC
>>> X, y = make_classification(random_state=42)
>>> model = SVC().fit(X, y)

Convert and export:
>>> from skl2neonsvm import to_neonsvm
>>> data = to_neonsvm(model)
>>> with open("model.yaml", "w") as f:
...     f.write(data)
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version(__package__ or __name__)
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = ['to_neonsvm', 'SklearnSVMModel']

from .convert import to_neonsvm, SklearnSVMModel
