from sklearn.svm import SVC, NuSVC, LinearSVC, SVR, NuSVR, LinearSVR, OneClassSVM
from sklearn.utils.validation import check_is_fitted
import numpy as np
import yaml
from typing import Any, TypeAlias
from itertools import combinations

__all__ = ['to_neonsvm', 'SklearnSVMModel']

SklearnSVMModel: TypeAlias = SVC | NuSVC | LinearSVC | SVR | NuSVR | LinearSVR | OneClassSVM
"""
Union type of supported SVM based sklearn model classes.
"""

def kernel_object(model: SklearnSVMModel) -> dict[str, Any]:
    """
    Creates object that represents kernel type and its parameters.
    This object is used for dumping data into YAML.

    Parameters
    ----------
    model : SklearnSVMModel
        Model whose kernel data is used.

    Returns
    -------
    object : dict[str, Any]
        Kernel object.

    Raises
    ------
    ValueError
        If kernel type is not supported.
    """

    if isinstance(model, (LinearSVC, LinearSVR)) or model.kernel == 'linear':
        return {
            'type': 'linear'
        }

    gamma = model._gamma.item() if isinstance(model._gamma, (np.number, np.ndarray)) else model._gamma

    match model.kernel:
        case 'poly':
            return {
                'type': 'polynomial',
                'bias': model.coef0,
                'degree': model.degree,
                'gamma': gamma
            }
        case 'rbf':
            return {
                'type': 'rbf',
                'gamma': gamma
            }
        case 'sigmoid':
            return {
                'type': 'sigmoid',
                'bias': model.coef0,
                'gamma': gamma
            }
 
    raise ValueError(f'Kernel type "{model.kernel}" is not supported. Supported ones: "linear", "poly", "rbf", "sigmoid"') 

def optimize_support_vectors(support_vectors: np.ndarray, dual_coefficients: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Omptimizes support vectors and their coefficients. 
    
    Sums coefficients of equal support vectors and discards support vectors with zero coefficient.

    Parameters
    ----------
    support_vectors : np.ndarray of shape (n_vectors, n_features)
        Matrix of support vectors to be optimized.
    dual_coefficients : np.ndarray of shape (n_vectors,)
        Coefficients that correspond to support vectors.

    Returns
    -------
    (optimized_vectors, optimized_coefficients) : tuple[np.ndarray, np.ndarray]
        Optimized support vectors and their corresponding optimized coefficients.
    """

    unique_vectors, inverse_indexes = np.unique(support_vectors, axis=0, return_inverse=True)
    compressed_coefficients = np.zeros(unique_vectors.shape[0], dtype=dual_coefficients.dtype)
    np.add.at(compressed_coefficients, inverse_indexes, dual_coefficients)

    meaningful_coefficients = compressed_coefficients != 0
    return unique_vectors[meaningful_coefficients], compressed_coefficients[meaningful_coefficients]

def support_vectors_object(support_vectors: np.ndarray, dual_coefficients: np.ndarray) -> list[dict[str, Any]]:
    """
    Creates object that represents list of support vectors with corresponding coefficients.
    This object is used for dumping data into YAML.

    Parameters
    ----------
    support_vectors : np.ndarray of shape (n_vectors, n_features)
        Matrix of support vectors.
    dual_coefficients : np.ndarray of shape (n_vectors,)
        Vector of coefficient that correspond to support vectors.

    Returns
    -------
    object : list[dict[str, Any]]
        Support vectors object.
    """

    support_vectors, dual_coefficients = optimize_support_vectors(support_vectors, dual_coefficients)

    return [
        {
            'coefficient': coefficient.item(),
            'vector': support_vector.tolist()
        } if coefficient != 1 else {
            'vector': support_vector.tolist()
        }
        for support_vector, coefficient in zip(support_vectors, dual_coefficients)
    ]

def features_for_check(n_features: int) -> np.ndarray:
    """
    Creates features matrix for additional model checks.

    Parameters
    ----------
    n_features : int
        Number of scalars in feature vector.

    Returns
    -------
    features : np.ndarray of shape (n_vectors, n_features)
        Features matrix.
    """

    features = np.eye(n_features, dtype=np.float64)
    random_features = np.random.random((1, n_features))
    return np.concat((features, random_features))

def classification_check_object(model: SklearnSVMModel, feature: np.ndarray) -> dict[str, Any]:
    """
    Creates check object for a classification model from a single feature vector.
    The object consists of input features and outputs of the model including 
    probability if possible. This object is used for dumping data into YAML.

    Parameters
    ----------
    model : SklearnSVMModel
        Model used for predictions.
    feature : np.ndarray of shape (n_features,)
        Feature vector used for predictions.

    Returns
    -------
    object : dict[str, Any]
        Check object.
    """

    check_object = {
        'features': feature.tolist(),
        'label': model.predict(feature.reshape(1, -1)).item()
    }

    if hasattr(model, 'probability') and model.probability:
        check_object['probabilities'] = model.predict_proba(feature.reshape(1, -1))[0].tolist()
    
    return check_object

def regression_check_object(model: SklearnSVMModel, feature: np.ndarray) -> dict[str, Any]:
    """
    Creates check object for a regression model from a single feature vector.
    The object consisits of input features and output value of the model.
    This object is used for dumping data into YAML.

    Parameters
    ----------
    model : SklearnSVMModel
        Model used for predictions.
    feature : np.ndarray of shape (n_features,)
        Feature vector used for predictions.

    Returns
    -------
    object : dict[str, Any]
        Check object.
    """

    return {
        'features': feature.tolist(),
        'value': model.predict(feature.reshape(1, -1)).item()
    }

def to_neonsvm(model: SklearnSVMModel, *, with_checks=False, **yaml_kwargs) -> str:
    """
    Converts sklearn SVM model to neonsvm YAML format.

    Parameters
    ----------
    model : SklearnSVMModel
        Model to convert.
    
    with_checks : bool, optional
        Include additional info with inputs and output values of the model.
        These checks can be used for additional model sanity check when importing.
        Defaults to False.
    
    yaml_kwargs : kwargs 
        Arguments to pass to `yaml.dump` function along with some defaults.

    Raises
    ------
    TypeError
        If the model is not of type `SVC`, `NuSVC`, `LinearSVC`, `SVR`, `NuSVR`, 
        `LinearSVR` or `OneClassSVM`.
    
    NotFittedError
        If the model is not fitted.

    ValueError
        If the model's parameter `break_ties` is `true`.
    
    ValueError 
        If the model's parameter `multi_class` is `"crammer_singer"`.

    Returns
    -------
    yaml_data : str 
        Model data in neonsvm YAML format.
    """

    if not isinstance(model, (SVC, NuSVC, LinearSVC, SVR, NuSVR, LinearSVR, OneClassSVM)):
        raise TypeError(f'Unsupported model of type {type(model).__name__}. Supported ones: SVC, NuSVC, LinearSVC, SVR, NuSVR, LinearSVR, OneClassSVM')

    check_is_fitted(model, msg='Model is not fitted')

    model_object = {
        'version': '1.0'
    }

    if isinstance(model, (SVC, NuSVC)):
        if model.break_ties:
            raise ValueError(f'{type(model).__name__} models with parameter break_ties={model.break_ties} are not supported')

        labels = model.classes_.tolist()

        model_object['svc'] = {
            'labels': labels,
            'multiclass-strategy': 'one-vs-one',
            'kernel': kernel_object(model)
        }
            
        # binary classifiers
        model_object['svc']['binary-classifiers'] = []

        j_coeff = 0
        k_coeff = 1
        support_vectors_start_index = np.cumsum(np.concat(([0], model.n_support_)))[:-1]
        for i, ((j, true_label), (k, false_label)) in enumerate(combinations(enumerate(labels), 2)):
            # "hard to grasp" dual coefficients layout traversal
            if j_coeff >= len(labels) - 1 or k_coeff >= len(labels):
                j_coeff = j
                k_coeff = j_coeff + 1

            start_index = support_vectors_start_index[j]
            true_label_support_vectors = model.support_vectors_[start_index:start_index + model.n_support_[j]]
            true_label_coefficients = model.dual_coef_[j_coeff, start_index:start_index + model.n_support_[j]]

            start_index = support_vectors_start_index[k]
            false_label_support_vectors = model.support_vectors_[start_index:start_index + model.n_support_[k]]
            start_index = support_vectors_start_index[k_coeff]
            false_label_coefficients = model.dual_coef_[j, start_index:start_index + model.n_support_[k_coeff]]

            j_coeff += 1
            k_coeff += 1

            classifier_object = {
                'true-label': true_label,
                'false-label': false_label,
                'bias': model.intercept_[i].item(),
                'support-vectors': support_vectors_object(np.concat((true_label_support_vectors, false_label_support_vectors)), np.concat((true_label_coefficients, false_label_coefficients))) 
            }

            if model.probability:
                classifier_object['platt-probability'] = {
                    'a': model.probA_[i].item(),
                    'b': model.probB_[i].item()
                }
            
            model_object['svc']['binary-classifiers'].append(classifier_object)

        # checks
        if with_checks:
            n_features = model.support_vectors_.shape[1]
            model_object['svc']['checks'] = [
                classification_check_object(model, feature) for feature in  features_for_check(n_features)
            ]
    
    elif isinstance(model, LinearSVC):
        if model.multi_class == 'crammer_singer':
            raise ValueError(f'{type(model).__name__} models with parameter multi_class="{model.multi_class}" are not supported')

        labels = model.classes_.tolist()

        model_object['svc'] = {
            'labels': labels,
            'multiclass-strategy': 'one-vs-rest' if len(labels) > 2 else 'one-vs-one',
            'kernel': kernel_object(model)
        }

        # binary classifiers
        model_object['svc']['binary-classifiers'] = []
        if len(labels) == 2:
            model_object['svc']['binary-classifiers'].append({
                'false-label': labels[0],
                'true-label': labels[1],
                'bias': model.intercept_.item(),
                'support-vectors': support_vectors_object(model.coef_, np.array([1.0]))
            })
        else:
            for i, true_label in enumerate(labels):
                model_object['svc'] ['binary-classifiers'].append({
                    'true-label': true_label,
                    'bias': model.intercept_[i].item(),
                    'support-vectors': support_vectors_object(model.coef_[i].reshape(1, -1), np.array([1.0]))
                })

        # checks
        if with_checks:
            n_features = model.coef_.shape[1]
            model_object['svc']['checks'] = [
                classification_check_object(model, feature) for feature in features_for_check(n_features)
            ]
    
    elif isinstance(model, (SVR, NuSVR)):
        model_object['svr'] = {
            'kernel': kernel_object(model),
            'bias': model.intercept_.item(),
            'support-vectors': support_vectors_object(model.support_vectors_, model.dual_coef_[0])
        }

        # checks
        if with_checks:
            n_features = model.support_vectors_.shape[1]
            model_object['svr']['checks'] = [
                regression_check_object(model, feature) for feature in features_for_check(n_features)
            ]
    
    elif isinstance(model, LinearSVR):
        model_object['svr'] = {
            'kernel': kernel_object(model),
            'bias': model.intercept_.item(),
            'support-vectors': support_vectors_object(model.coef_.reshape(1, -1), np.array([1.0]))
        }

        if with_checks:
            n_features = model.coef_.shape[0]
            model_object['svr']['checks'] = [
                regression_check_object(model, feature) for feature in features_for_check(n_features)
            ]
    
    elif isinstance(model, OneClassSVM):
        model_object['svc'] = {
            'labels': [-1, 1],
            'multiclass-strategy': 'one-vs-one',
            'kernel': kernel_object(model),
            'binary-classifiers': [
                {
                    'false-label': -1,
                    'true-label': 1,
                    'bias': model.intercept_.item(),
                    'support-vectors': support_vectors_object(model.support_vectors_, model.dual_coef_[0])
                }
            ]
        }

        # checks
        if with_checks:
            n_features = model.support_vectors_.shape[1]
            model_object['svc']['checks'] = [
                classification_check_object(model, feature) for feature in features_for_check(n_features)
            ]
    
    yaml_kwargs = {
        'default_flow_style': None,
        'sort_keys': False,
        'width': float('inf'),
        **yaml_kwargs
    }
    return yaml.dump(model_object, None, **yaml_kwargs)
