# skl2neonsvm

[![PyPI - Version](https://img.shields.io/pypi/v/skl2neonsvm)](https://pypi.org/project/skl2neonsvm)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/skl2neonsvm)](https://pypi.org/project/skl2neonsvm)

Library for converting [scikit-learn](https://scikit-learn.org/stable) SVM-based classification and regression models to neonsvm YAML format for optimized inference on ARM devices using C++ library [neonsvm](https://github.com/R3dKar/neonsvm).

## Installation
From [PyPi](https://pypi.org/project/skl2neonsvm)

```bash
pip install skl2neonsvm
```

From repository

```bash
pip install git+https://github.com/R3dKar/sklearn-neonsvm
```

## Usage

```py
# Training model
from sklearn.datasets import make_classification
from sklearn.svm import SVC

X, y = make_classification(random_state=42)
model = SVC().fit(X, y)

# Converting and exporting
from skl2neonsvm import to_neonsvm

data = to_neonsvm(model)
with open("model.yaml", "w") as f:
    f.write(data)
```

## Supported models

All models of submodule [`sklearn.svm`](https://scikit-learn.org/stable/api/sklearn.svm.html) are supported.

Supported classification models:
 - `SVC`
 - `NuSVC`
 - `LinearSVC`
 - `OneClassSVM`

Supported regression models:
 - `SVR`
 - `NuSVR`
 - `LinearSVR`
