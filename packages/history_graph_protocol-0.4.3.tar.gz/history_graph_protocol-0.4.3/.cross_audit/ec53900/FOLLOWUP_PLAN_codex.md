## Follow-up Plan

- [ ] [P1] `src/hgp/__init__.py:L5` — Guard the metadata lookup with a non-crashing fallback for source-tree imports
  - **Category**: correctness
  - **Rationale**: Prevent `PackageNotFoundError` from breaking `import hgp` and `from hgp...` when the repository is imported without installed wheel metadata.
  - **Estimated effort**: S
- [ ] [P2] `.github/workflows/ci.yml:L40` — Add a regression test that imports `hgp` without installed dist metadata
  - **Category**: test
  - **Rationale**: Current CI only validates the installed-package path, so it misses failures that only appear in bare source-tree usage.
  - **Estimated effort**: S
