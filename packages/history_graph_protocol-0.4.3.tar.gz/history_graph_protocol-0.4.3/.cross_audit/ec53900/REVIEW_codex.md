---
commit: ec53900
reviewer: gpt-5.4
summary: "Top-level imports now depend on installed dist metadata, which breaks source-tree usage and slips past current CI."
issue_count:
  P0: 0
  P1: 1
  P2: 1
  P3: 0
---

## Review

### Correctness
- [P1] `src/hgp/__init__.py:L5` — `__version__ = version("history-graph-protocol")` makes `import hgp` crash in environments where the package source is importable but distribution metadata is not installed. **Rationale**: `importlib.metadata.version()` only reads installed dist-info; in this checkout, `python3` with `sys.path.insert(0, "src"); import hgp` raises `PackageNotFoundError`, so source-tree imports and any `from hgp...` imports fail before submodules load. **Suggestion**: Wrap the lookup in `try/except PackageNotFoundError` and use a source-tree-safe fallback so `hgp` remains importable without installed package metadata.

### Security
- (none)

### Performance
- (none)

### Maintainability
- (none)

### Test Coverage
- [P2] `.github/workflows/ci.yml:L40` — The current automated test path will not catch this regression because CI only exercises an installed environment. **Rationale**: CI runs `uv sync --extra dev` before `uv run pytest -q`, which provides distribution metadata; there is no regression test that imports top-level `hgp` from a bare source checkout, so this `PackageNotFoundError` path can ship green. **Suggestion**: Add a subprocess-based test that exposes only `src/` on `PYTHONPATH` and asserts `import hgp` succeeds without installed `history-graph-protocol` metadata.
