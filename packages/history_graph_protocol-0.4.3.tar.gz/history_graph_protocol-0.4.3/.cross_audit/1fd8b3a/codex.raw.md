---BEGIN REVIEW---
---
commit: 1fd8b3a
reviewer: gpt-5.4
summary: "The lockfile bump aligns with `pyproject.toml`, but the public package version is still stale, so the 0.4.2 release metadata remains inconsistent."
issue_count:
  P0: 0
  P1: 1
  P2: 0
  P3: 0
---

## Review

### Correctness
- [P1] `src/hgp/__init__.py:L3` — The package still exports `__version__ = "0.4.0"` after this commit updates the editable package version in `uv.lock` to `0.4.2`. **Rationale**: The repository now reports two different versions for the same release state (`pyproject.toml`/`uv.lock` say `0.4.2`, while `hgp.__version__` still says `0.4.0`). This is externally visible because the README tells users to verify installation with `python -c "import hgp; print(hgp.__version__)"`, so the documented check reports the wrong version. **Suggestion**: Update `src/hgp/__init__.py` to `0.4.2`, or remove the duplicated constant and derive the public version from package metadata so future version bumps cannot drift.

### Security
- (none)

### Performance
- (none)

### Maintainability
- (none)

### Test Coverage
- (none)
---END REVIEW---

---BEGIN FOLLOWUP_PLAN---
## Follow-up Plan

- [ ] [P1] `src/hgp/__init__.py:L3` — synchronize the exported package version with the declared `0.4.2` release version, preferably from a single source of truth
  - **Category**: correctness
  - **Rationale**: The current tree exposes conflicting version metadata, and the documented install check returns the wrong version to users
  - **Estimated effort**: XS

- [ ] [P2] `tests/test_install.py:L409` — add a regression test that asserts the public package version stays aligned with the declared project version
  - **Category**: test
  - **Rationale**: This mismatch survived at least one manual version bump, which means the current test suite does not guard against release metadata drift
  - **Estimated effort**: S
---END FOLLOWUP_PLAN---
