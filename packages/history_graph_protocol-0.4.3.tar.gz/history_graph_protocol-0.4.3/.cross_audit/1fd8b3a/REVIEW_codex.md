---
commit: 1fd8b3a
reviewer: gpt-5.4
summary: "The lockfile bump aligns with `pyproject.toml`, but the public package version is still stale, so the 0.4.2 release metadata remains inconsistent."
issue_count:
  P0: 0
  P1: 1
  P2: 0
  P3: 0
---

## Review

### Correctness
- [P1] `src/hgp/__init__.py:L3` — The package still exports `__version__ = "0.4.0"` after this commit updates the editable package version in `uv.lock` to `0.4.2`. **Rationale**: The repository now reports two different versions for the same release state (`pyproject.toml`/`uv.lock` say `0.4.2`, while `hgp.__version__` still says `0.4.0`). This is externally visible because the README tells users to verify installation with `python -c "import hgp; print(hgp.__version__)"`, so the documented check reports the wrong version. **Suggestion**: Update `src/hgp/__init__.py` to `0.4.2`, or remove the duplicated constant and derive the public version from package metadata so future version bumps cannot drift.

### Security
- (none)

### Performance
- (none)

### Maintainability
- (none)

### Test Coverage
- (none)
