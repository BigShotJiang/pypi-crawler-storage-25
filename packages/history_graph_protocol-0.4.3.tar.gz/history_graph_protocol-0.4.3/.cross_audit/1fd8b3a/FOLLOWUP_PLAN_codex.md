## Follow-up Plan

- [ ] [P1] `src/hgp/__init__.py:L3` — synchronize the exported package version with the declared `0.4.2` release version, preferably from a single source of truth
  - **Category**: correctness
  - **Rationale**: The current tree exposes conflicting version metadata, and the documented install check returns the wrong version to users
  - **Estimated effort**: XS

- [ ] [P2] `tests/test_install.py:L409` — add a regression test that asserts the public package version stays aligned with the declared project version
  - **Category**: test
  - **Rationale**: This mismatch survived at least one manual version bump, which means the current test suite does not guard against release metadata drift
  - **Estimated effort**: S
