# Code Review Request



You are performing a thorough code review for a git commit. Follow the output contract exactly.

---

## Commit Information

- **Commit**: `047e7d0fc23a71e287175285e4e5d2aa1d4319f5`
- **Author**: wgsim <93395612+wgsim@users.noreply.github.com>
- **Date**: 2026-04-20 16:00:06 -0700
- **Message**:

```
test: add regression test for PackageNotFoundError fallback in __version__

Mocks importlib.metadata.version() to raise PackageNotFoundError and
reloads hgp to verify __version__ == "unknown" without crashing.

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

---

## Changes Summary

```
commit 047e7d0fc23a71e287175285e4e5d2aa1d4319f5
Author: wgsim <93395612+wgsim@users.noreply.github.com>
Date:   Mon Apr 20 16:00:06 2026 -0700

    test: add regression test for PackageNotFoundError fallback in __version__
    
    Mocks importlib.metadata.version() to raise PackageNotFoundError and
    reloads hgp to verify __version__ == "unknown" without crashing.
    
    Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>

 tests/test_package_init.py | 22 ++++++++++++++++++++++
 1 file changed, 22 insertions(+)
```

---

## Diff

```diff
diff --git a/tests/test_package_init.py b/tests/test_package_init.py
new file mode 100644
index 0000000..cc2f60f
--- /dev/null
+++ b/tests/test_package_init.py
@@ -0,0 +1,22 @@
+"""Regression test: hgp.__version__ must not crash in bare source-tree imports."""
+
+from __future__ import annotations
+
+import importlib
+from importlib.metadata import PackageNotFoundError
+from unittest.mock import patch
+
+import hgp
+
+
+def test_version_fallback_without_metadata():
+    """__version__ must fall back to 'unknown' when dist metadata is absent."""
+    with patch(
+        "importlib.metadata.version",
+        side_effect=PackageNotFoundError("history-graph-protocol"),
+    ):
+        importlib.reload(hgp)
+        assert hgp.__version__ == "unknown"
+
+    # Restore the real version so other tests see a consistent state.
+    importlib.reload(hgp)

```

---

## Instructions

Review the commit above and produce a response with exactly two sections:

1. **REVIEW** — issue findings organized by category
2. **FOLLOWUP_PLAN** — actionable items sorted by priority

Use the delimiters and format defined in the Output Contract below.
Do not include any content outside the delimiters.

---

## Output Contract

# Output Contract

Your response MUST contain exactly two sections delimited as follows.
No content outside these delimiters will be processed.

```
---BEGIN REVIEW---
... review content ...
---END REVIEW---

---BEGIN FOLLOWUP_PLAN---
... plan content ...
---END FOLLOWUP_PLAN---
```

---

## REVIEW Section Format

```markdown
---
commit: <short-sha>
reviewer: <your-model-name>
summary: "<one-line summary>"
issue_count:
  P0: <count>
  P1: <count>
  P2: <count>
  P3: <count>
---

## Review

### Correctness
- [P<n>] `path/to/file:L<n>` — <issue>. **Rationale**: <why>. **Suggestion**: <concrete fix>
- (none)

### Security
- ...

### Performance
- ...

### Maintainability
- ...

### Test Coverage
- ...
```

---

## FOLLOWUP_PLAN Section Format

```markdown
## Follow-up Plan

- [ ] [P<n>] `path/to/file:L<n>` — <action verb phrase>
  - **Category**: correctness | security | performance | maintainability | test | style | docs | type-hint | naming
  - **Rationale**: <why this matters>
  - **Estimated effort**: XS | S | M | L
```

---

## Priority Definitions

| Priority | Definition |
|----------|------------|
| P0 | Blocking: data loss, security hole, crash |
| P1 | Must fix: logic bug, bad error handling, missing validation |
| P2 | Fix soon: maintainability, perf concern, unclear code |
| P3 | Nice to have: style, naming, docs, minor refactor |

## Rules

- Every issue in REVIEW must appear as an action in FOLLOWUP_PLAN.
- File paths must be relative to repo root.
- Write in the language specified at the top of this prompt.

