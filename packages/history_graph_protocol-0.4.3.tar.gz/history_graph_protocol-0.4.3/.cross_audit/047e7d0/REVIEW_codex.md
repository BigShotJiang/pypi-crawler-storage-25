---
commit: 047e7d0
reviewer: gpt-5-codex
summary: "Targeted regression coverage is a good addition, but the new test does not actually exercise a fresh import and its cleanup is not failure-safe."
issue_count:
  P0: 0
  P1: 0
  P2: 1
  P3: 1
---

## Review

### Correctness
- (none)

### Security
- (none)

### Performance
- (none)

### Maintainability
- [P3] `tests/test_package_init.py:L21` — Cleanup is not protected by `finally`, even though the test mutates shared interpreter state by reloading the global `hgp` module. **Rationale**: if the assertion or the patched reload fails, `hgp.__version__` stays in the fallback state for the rest of the test session, which can create misleading secondary failures and make the original break harder to diagnose. **Suggestion**: move the restore `importlib.reload(hgp)` into a `finally` block, or avoid mutating the globally imported module by importing a fresh module object for the test.

### Test Coverage
- [P2] `tests/test_package_init.py:L9` — The test claims to cover a “bare source-tree import”, but it imports `hgp` before patching `importlib.metadata.version()` and only asserts behavior on `importlib.reload(hgp)`. **Rationale**: under this repo’s `src/` layout and `uv run pytest` workflow, that means the test validates reload-time fallback in an already-imported package, not a true first import without distribution metadata. A regression tied to first-import-only behavior could still slip through. **Suggestion**: delete `hgp` from `sys.modules`, put `src/` on `sys.path` for the test, and perform the first `import hgp` inside the patched context so the test matches the scenario named in the docstring and commit message.
