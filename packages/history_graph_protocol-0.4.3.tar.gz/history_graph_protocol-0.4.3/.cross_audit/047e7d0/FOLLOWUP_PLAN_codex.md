## Follow-up Plan

- [ ] [P2] `tests/test_package_init.py:L9` — Rework the test to perform a true first import under patched `importlib.metadata.version()`
  - **Category**: test
  - **Rationale**: the current test covers `reload()` of an already-imported module, not the fresh-import path described by the regression and docstring
  - **Estimated effort**: S

- [ ] [P3] `tests/test_package_init.py:L21` — Make module-state restoration failure-safe with `try`/`finally` or a fresh-module import strategy
  - **Category**: maintainability
  - **Rationale**: shared module mutation without guaranteed cleanup can cascade into unrelated failures when this test breaks
  - **Estimated effort**: XS
