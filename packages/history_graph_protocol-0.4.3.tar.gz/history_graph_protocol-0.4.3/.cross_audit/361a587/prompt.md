# Code Review Request



You are performing a thorough code review for a git commit. Follow the output contract exactly.

---

## Commit Information

- **Commit**: `361a587d94fcfa416448d3c733570bd5410f0107`
- **Author**: wgsim <93395612+wgsim@users.noreply.github.com>
- **Date**: 2026-04-20 16:19:25 -0700
- **Message**:

```
test: rework version fallback test with true first-import and finally cleanup

- sys.modules.pop() before import ensures a genuine first-import, not reload
- finally block guarantees hgp state is restored even if the assertion fails

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

---

## Changes Summary

```
commit 361a587d94fcfa416448d3c733570bd5410f0107
Author: wgsim <93395612+wgsim@users.noreply.github.com>
Date:   Mon Apr 20 16:19:25 2026 -0700

    test: rework version fallback test with true first-import and finally cleanup
    
    - sys.modules.pop() before import ensures a genuine first-import, not reload
    - finally block guarantees hgp state is restored even if the assertion fails
    
    Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>

 tests/test_package_init.py | 26 +++++++++++++++-----------
 1 file changed, 15 insertions(+), 11 deletions(-)
```

---

## Diff

```diff
diff --git a/tests/test_package_init.py b/tests/test_package_init.py
index cc2f60f..bd419a7 100644
--- a/tests/test_package_init.py
+++ b/tests/test_package_init.py
@@ -3,20 +3,24 @@
 from __future__ import annotations
 
 import importlib
+import sys
 from importlib.metadata import PackageNotFoundError
 from unittest.mock import patch
 
-import hgp
-
 
 def test_version_fallback_without_metadata():
-    """__version__ must fall back to 'unknown' when dist metadata is absent."""
-    with patch(
-        "importlib.metadata.version",
-        side_effect=PackageNotFoundError("history-graph-protocol"),
-    ):
+    """__version__ falls back to 'unknown' on a true first import without dist metadata."""
+    # Remove any cached hgp module so the import below is a genuine first import.
+    sys.modules.pop("hgp", None)
+    try:
+        with patch(
+            "importlib.metadata.version",
+            side_effect=PackageNotFoundError("history-graph-protocol"),
+        ):
+            import hgp  # noqa: PLC0415
+            assert hgp.__version__ == "unknown"
+    finally:
+        # Always restore a clean hgp so later tests see the real version.
+        sys.modules.pop("hgp", None)
+        import hgp  # noqa: PLC0415
         importlib.reload(hgp)
-        assert hgp.__version__ == "unknown"
-
-    # Restore the real version so other tests see a consistent state.
-    importlib.reload(hgp)

```

---

## Instructions

Review the commit above and produce a response with exactly two sections:

1. **REVIEW** — issue findings organized by category
2. **FOLLOWUP_PLAN** — actionable items sorted by priority

Use the delimiters and format defined in the Output Contract below.
Do not include any content outside the delimiters.

---

## Output Contract

# Output Contract

Your response MUST contain exactly two sections delimited as follows.
No content outside these delimiters will be processed.

```
---BEGIN REVIEW---
... review content ...
---END REVIEW---

---BEGIN FOLLOWUP_PLAN---
... plan content ...
---END FOLLOWUP_PLAN---
```

---

## REVIEW Section Format

```markdown
---
commit: <short-sha>
reviewer: <your-model-name>
summary: "<one-line summary>"
issue_count:
  P0: <count>
  P1: <count>
  P2: <count>
  P3: <count>
---

## Review

### Correctness
- [P<n>] `path/to/file:L<n>` — <issue>. **Rationale**: <why>. **Suggestion**: <concrete fix>
- (none)

### Security
- ...

### Performance
- ...

### Maintainability
- ...

### Test Coverage
- ...
```

---

## FOLLOWUP_PLAN Section Format

```markdown
## Follow-up Plan

- [ ] [P<n>] `path/to/file:L<n>` — <action verb phrase>
  - **Category**: correctness | security | performance | maintainability | test | style | docs | type-hint | naming
  - **Rationale**: <why this matters>
  - **Estimated effort**: XS | S | M | L
```

---

## Priority Definitions

| Priority | Definition |
|----------|------------|
| P0 | Blocking: data loss, security hole, crash |
| P1 | Must fix: logic bug, bad error handling, missing validation |
| P2 | Fix soon: maintainability, perf concern, unclear code |
| P3 | Nice to have: style, naming, docs, minor refactor |

## Rules

- Every issue in REVIEW must appear as an action in FOLLOWUP_PLAN.
- File paths must be relative to repo root.
- Write in the language specified at the top of this prompt.

