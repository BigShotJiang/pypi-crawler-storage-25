---BEGIN REVIEW---
---
commit: a043752
reviewer: gpt-5-codex
summary: "The fallback itself looks correct, but the documented bare-source import regression is not covered by a test."
issue_count:
  P0: 0
  P1: 0
  P2: 1
  P3: 0
---

## Review

### Correctness
- (none)

### Security
- (none)

### Performance
- (none)

### Maintainability
- (none)

### Test Coverage
- [P2] `src/hgp/__init__.py:L5` — The commit fixes a user-facing import crash without adding a regression test for the no-dist-info path. **Rationale**: the failure described in the commit message occurs when `hgp` is imported from a bare source tree, while this repo's normal test flow runs in an installed environment where package metadata is present; that means this exact bug can regress silently. **Suggestion**: add a deterministic test that forces `importlib.metadata.version()` to raise `PackageNotFoundError` during a fresh `hgp` import, or run an isolated subprocess that imports `hgp` from `PYTHONPATH=src` without installed package metadata and asserts `__version__ == "unknown"`.

---END REVIEW---

---BEGIN FOLLOWUP_PLAN---
## Follow-up Plan

- [ ] [P2] `tests/test_package_init.py:L1` — add regression coverage for source-tree imports when package metadata is unavailable
  - **Category**: test
  - **Rationale**: this commit fixes a documented crash path, but current CI is unlikely to exercise the exact no-dist-info scenario that triggered it
  - **Estimated effort**: S
---END FOLLOWUP_PLAN---
