## Follow-up Plan

- [ ] [P2] `tests/test_package_init.py:L1` — add regression coverage for source-tree imports when package metadata is unavailable
  - **Category**: test
  - **Rationale**: this commit fixes a documented crash path, but current CI is unlikely to exercise the exact no-dist-info scenario that triggered it
  - **Estimated effort**: S
