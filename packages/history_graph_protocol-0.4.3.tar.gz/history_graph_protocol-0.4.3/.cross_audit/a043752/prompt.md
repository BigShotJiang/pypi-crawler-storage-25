# Code Review Request



You are performing a thorough code review for a git commit. Follow the output contract exactly.

---

## Commit Information

- **Commit**: `a0437520029e9fe5f32e65c2d5bbf644da7678c2`
- **Author**: wgsim <93395612+wgsim@users.noreply.github.com>
- **Date**: 2026-04-20 15:48:33 -0700
- **Message**:

```
fix: guard importlib.metadata lookup with PackageNotFoundError fallback

Bare source-tree imports (PYTHONPATH=src) raised PackageNotFoundError
because dist-info is not present without installation. Wrapping in
try/except returns "unknown" instead of crashing.

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

---

## Changes Summary

```
commit a0437520029e9fe5f32e65c2d5bbf644da7678c2
Author: wgsim <93395612+wgsim@users.noreply.github.com>
Date:   Mon Apr 20 15:48:33 2026 -0700

    fix: guard importlib.metadata lookup with PackageNotFoundError fallback
    
    Bare source-tree imports (PYTHONPATH=src) raised PackageNotFoundError
    because dist-info is not present without installation. Wrapping in
    try/except returns "unknown" instead of crashing.
    
    Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>

 src/hgp/__init__.py | 7 +++++--
 1 file changed, 5 insertions(+), 2 deletions(-)
```

---

## Diff

```diff
diff --git a/src/hgp/__init__.py b/src/hgp/__init__.py
index 8fe731b..dd7aeca 100644
--- a/src/hgp/__init__.py
+++ b/src/hgp/__init__.py
@@ -1,5 +1,8 @@
 """History Graph Protocol — crash-resilient semantic layer over MCP."""
 
-from importlib.metadata import version
+from importlib.metadata import PackageNotFoundError, version
 
-__version__ = version("history-graph-protocol")
+try:
+    __version__ = version("history-graph-protocol")
+except PackageNotFoundError:
+    __version__ = "unknown"

```

---

## Instructions

Review the commit above and produce a response with exactly two sections:

1. **REVIEW** — issue findings organized by category
2. **FOLLOWUP_PLAN** — actionable items sorted by priority

Use the delimiters and format defined in the Output Contract below.
Do not include any content outside the delimiters.

---

## Output Contract

# Output Contract

Your response MUST contain exactly two sections delimited as follows.
No content outside these delimiters will be processed.

```
---BEGIN REVIEW---
... review content ...
---END REVIEW---

---BEGIN FOLLOWUP_PLAN---
... plan content ...
---END FOLLOWUP_PLAN---
```

---

## REVIEW Section Format

```markdown
---
commit: <short-sha>
reviewer: <your-model-name>
summary: "<one-line summary>"
issue_count:
  P0: <count>
  P1: <count>
  P2: <count>
  P3: <count>
---

## Review

### Correctness
- [P<n>] `path/to/file:L<n>` — <issue>. **Rationale**: <why>. **Suggestion**: <concrete fix>
- (none)

### Security
- ...

### Performance
- ...

### Maintainability
- ...

### Test Coverage
- ...
```

---

## FOLLOWUP_PLAN Section Format

```markdown
## Follow-up Plan

- [ ] [P<n>] `path/to/file:L<n>` — <action verb phrase>
  - **Category**: correctness | security | performance | maintainability | test | style | docs | type-hint | naming
  - **Rationale**: <why this matters>
  - **Estimated effort**: XS | S | M | L
```

---

## Priority Definitions

| Priority | Definition |
|----------|------------|
| P0 | Blocking: data loss, security hole, crash |
| P1 | Must fix: logic bug, bad error handling, missing validation |
| P2 | Fix soon: maintainability, perf concern, unclear code |
| P3 | Nice to have: style, naming, docs, minor refactor |

## Rules

- Every issue in REVIEW must appear as an action in FOLLOWUP_PLAN.
- File paths must be relative to repo root.
- Write in the language specified at the top of this prompt.

