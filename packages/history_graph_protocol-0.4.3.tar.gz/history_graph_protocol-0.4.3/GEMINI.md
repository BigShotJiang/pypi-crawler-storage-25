<!-- hgp-instructions-start -->
## HGP — History Graph Protocol

HGP is connected as an MCP server. Use HGP tools to record every significant
action and decision.

**Use HGP file tools instead of native file tools:**

| Native tool | HGP equivalent |
|-------------|----------------|
| Write / write_file | `hgp_write_file` |
| Edit / replace | `hgp_edit_file` |
| Bash append | `hgp_append_file` |

Record `hypothesis` operations for decisions, `artifact` for outputs,
`invalidation` when superseding prior work.

## Session Context (Subagent Support)

To propagate HGP context to spawned subagents, register a session root op at
the start of each session:

```
root = hgp_create_operation(op_type="hypothesis", agent_id="claude-code",
                            metadata={"description": "session root"})
hgp_set_context(root_op_id=root["op_id"], agent_id="claude-code",
                session_id="<session_id from SubagentStart/SubagentStop hook event>")
```

SubagentStart hooks will then inject the root op_id into every spawned
subagent's context automatically. Subagents should use
`parent_op_ids=[root_op_id]` for all `hgp_*` calls.
<!-- hgp-instructions-end -->
