# iterfact

Public Python SDK and account CLI for IterFact interactive documents.

## Install

```bash
pip install iterfact
```

## Connect your account

Account-bound package calls use an IterFact account token. The simplest setup path is:

```bash
iterfact configure
```

That command opens `iterfact.com/settings/tokens`, prompts for an `itf_...` token, and saves it to:

```text
~/.iterfact/config.json
```

You can also pass a token directly in Python:

```python
from iterfact import IterFactClient

client = IterFactClient(api_key="itf_...")
```

Read-only checks like `health()` and `analyze_upload_artifact_html(...)` can run without a token. Account-bound operations like uploads, generation, and page publishing use the credits and permissions of the connected IterFact account.

## What it includes

- the Python client for calling the live IterFact MCP and status endpoints
- the public `iterfact configure` CLI for linking an IterFact account
- token/config handling and lightweight CLI telemetry

It does **not** include the IterFact MCP server, template vault, or internal Conductor/orchestrator runtime.

## Notes

- For server development, local MCP hosting, and internal Conductor tooling, use the IterFact repo checkout rather than the public PyPI package.

## Telemetry

The official CLI sends a small anonymous usage ping on:

- first successful local use
- then at most once per 24 hours per command

It includes package version, Python version, OS, entrypoint, and command name.
It does not send prompts, files, artifact contents, or account credentials.

Disable it with:

```bash
ITERFACT_NO_TELEMETRY=1
```

Package download analytics are measured separately through the public PyPI ecosystem:

- `pypistats.org`
- `pepy.tech`
- the official PyPI BigQuery dataset
