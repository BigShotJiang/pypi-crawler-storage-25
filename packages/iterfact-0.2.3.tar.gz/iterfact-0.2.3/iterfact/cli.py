from __future__ import annotations

import argparse
import contextlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import threading
import urllib.error
import urllib.request
import webbrowser

from dotenv import load_dotenv

from iterfact import __version__
from iterfact.config import CONFIG_PATH, get_saved_account_token, set_saved_account_token
from iterfact.telemetry import emit_cli_usage_telemetry


def _module_available(module_name: str) -> bool:
    with contextlib.suppress(ImportError, ModuleNotFoundError, ValueError):
        return importlib.util.find_spec(module_name) is not None
    return False


def _internal_commands_available() -> bool:
    return _module_available("iterfact_private.orchestrator.runner") and _module_available(
        "iterfact_private.validation"
    )


def _mcp_commands_available() -> bool:
    return _module_available("MCP.server")


def _load_private_orchestrator_runtime() -> dict[str, object]:
    if not _internal_commands_available():
        raise SystemExit(
            "Internal IterFact commands are only available from the IterFact repo checkout. "
            "The public PyPI package ships the SDK and account CLI only."
        )
    orchestrator_config = importlib.import_module("iterfact_private.orchestrator.config")
    orchestrator_dashboard = importlib.import_module("iterfact_private.orchestrator.dashboard")
    orchestrator_runner = importlib.import_module("iterfact_private.orchestrator.runner")
    orchestrator_tasks = importlib.import_module("iterfact_private.orchestrator.tasks")
    validation_module = importlib.import_module("iterfact_private.validation")
    return {
        "OrchestratorConfigError": orchestrator_config.OrchestratorConfigError,
        "build_orchestrator_dashboard_url": orchestrator_dashboard.build_orchestrator_dashboard_url,
        "OrchestratorRunError": orchestrator_runner.OrchestratorRunError,
        "OrchestratorRunner": orchestrator_runner.OrchestratorRunner,
        "TaskSpecError": orchestrator_tasks.TaskSpecError,
        "load_task_spec": orchestrator_tasks.load_task_spec,
        "HostedArtifactValidator": validation_module.HostedArtifactValidator,
        "ValidationError": validation_module.ValidationError,
    }


def _load_mcp_server_module():
    if not _mcp_commands_available():
        raise SystemExit(
            "The public PyPI package does not ship the IterFact MCP server. "
            "Run server commands from the IterFact repo checkout instead."
        )
    return importlib.import_module("MCP.server")


def _apply_optional_env(name: str, value: str | None) -> None:
    if value is not None and str(value).strip():
        os.environ[name] = str(value).strip()


def _build_dashboard_url(host: str, port: int) -> str:
    normalized_host = (host or "").strip() or "127.0.0.1"
    if normalized_host in {"0.0.0.0", "::", "[::]", "*"}:
        normalized_host = "127.0.0.1"
    return f"http://{normalized_host}:{int(port)}/orchestrator/"


def _load_runtime_env(env_file: str | None) -> None:
    candidate_paths: list[Path] = []
    if env_file:
        candidate_paths.append(Path(env_file).expanduser())
    candidate_paths.extend([Path.cwd() / ".env", Path.cwd() / ".env.local"])
    for candidate in candidate_paths:
        if candidate.exists():
            load_dotenv(candidate, override=False)
    if not str(os.environ.get("ITERFACT_ACCOUNT_TOKEN") or "").strip():
        saved_token = get_saved_account_token()
        if saved_token:
            os.environ["ITERFACT_ACCOUNT_TOKEN"] = saved_token


def _run_configure(args: argparse.Namespace) -> int:
    _load_runtime_env(getattr(args, "env_file", None))
    base_url = (
        getattr(args, "public_app_base_url", None)
        or os.environ.get("NEXT_PUBLIC_SITE_URL")
        or "https://iterfact.com"
    ).rstrip("/")
    tokens_url = f"{base_url}/settings/tokens"
    if getattr(args, "print_path", False):
        print(str(CONFIG_PATH))
        return 0

    if not getattr(args, "no_browser", False):
        with contextlib.suppress(Exception):
            webbrowser.open(tokens_url)

    token = str(getattr(args, "token", None) or "").strip()
    if not token:
        print("Open this page to create a token:")
        print(tokens_url)
        token = input("Paste your IterFact token (itf_...): ").strip()

    if not token.startswith("itf_"):
        raise SystemExit("IterFact tokens must start with 'itf_'.")

    saved_path = set_saved_account_token(token)
    print(f"Saved IterFact account token to {saved_path}")
    return 0


def _build_mcp_parser(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--host", help="Bind host for the MCP HTTP server.")
    parser.add_argument("--port", type=int, help="Bind port for the MCP HTTP server.")
    parser.add_argument("--env-file", help="Optional path to a dotenv file.")
    parser.add_argument("--output-dir", help="Override ITERFACT_OUTPUT_DIR.")
    parser.add_argument("--analytics-dir", help="Override ITERFACT_ANALYTICS_DIR.")
    parser.add_argument("--vault-path", help="Override ITERFACT_VAULT_PATH.")
    parser.add_argument(
        "--public-artifact-base-url",
        help="Override ITERFACT_PUBLIC_ARTIFACT_BASE_URL.",
    )
    parser.add_argument(
        "--public-app-base-url",
        help="Override NEXT_PUBLIC_SITE_URL.",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Run uvicorn with reload enabled for local development.",
    )
    parser.add_argument(
        "--open-orchestrator-dashboard",
        action="store_true",
        help="Open the local Conductor dashboard after the MCP server starts.",
    )


def _run_mcp(
    args: argparse.Namespace,
    *,
    entrypoint: str,
    command_name: str,
) -> int:
    _load_runtime_env(getattr(args, "env_file", None))
    _apply_optional_env("HOST", getattr(args, "host", None))
    _apply_optional_env("PORT", str(args.port) if getattr(args, "port", None) else None)
    _apply_optional_env("ITERFACT_OUTPUT_DIR", getattr(args, "output_dir", None))
    _apply_optional_env("ITERFACT_ANALYTICS_DIR", getattr(args, "analytics_dir", None))
    _apply_optional_env("ITERFACT_VAULT_PATH", getattr(args, "vault_path", None))
    _apply_optional_env(
        "ITERFACT_PUBLIC_ARTIFACT_BASE_URL",
        getattr(args, "public_artifact_base_url", None),
    )
    _apply_optional_env("NEXT_PUBLIC_SITE_URL", getattr(args, "public_app_base_url", None))
    emit_cli_usage_telemetry(entrypoint=entrypoint, command_name=command_name)

    import uvicorn

    mcp_server = _load_mcp_server_module()
    host = getattr(args, "host", None) or mcp_server.SETTINGS.host
    port = int(getattr(args, "port", None) or mcp_server.SETTINGS.port)
    if getattr(args, "open_orchestrator_dashboard", False):
        dashboard_url = _build_dashboard_url(host, port)
        threading.Timer(1.2, lambda: webbrowser.open(dashboard_url)).start()
    if getattr(args, "reload", False):
        uvicorn.run("MCP.server:app", host=host, port=port, reload=True)
    else:
        uvicorn.run(mcp_server.app, host=host, port=port)
    return 0


def build_parser(*, include_internal: bool | None = None) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="iterfact",
        description="IterFact public SDK and account CLI.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    configure_parser = subparsers.add_parser(
        "configure",
        help="Save an IterFact account token for SDK use.",
    )
    configure_parser.add_argument("--env-file", help="Optional path to a dotenv file.")
    configure_parser.add_argument("--token", help="Optional IterFact account token.")
    configure_parser.add_argument(
        "--public-app-base-url",
        help="Override the IterFact web app URL used for token setup.",
    )
    configure_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the browser automatically.",
    )
    configure_parser.add_argument(
        "--print-path",
        action="store_true",
        help="Print the config file path and exit.",
    )
    configure_parser.set_defaults(handler=_run_configure)

    enable_internal = include_internal is not False

    if enable_internal and _mcp_commands_available():
        mcp_parser = subparsers.add_parser("mcp", help="Run the IterFact MCP server.")
        _build_mcp_parser(mcp_parser)
        mcp_parser.set_defaults(
            handler=lambda args: _run_mcp(args, entrypoint="iterfact", command_name="mcp")
        )

        serve_parser = subparsers.add_parser("serve", help="Alias for `iterfact mcp`.")
        _build_mcp_parser(serve_parser)
        serve_parser.set_defaults(
            handler=lambda args: _run_mcp(args, entrypoint="iterfact", command_name="serve")
        )

    if enable_internal and _internal_commands_available():
        validate_parser = subparsers.add_parser(
            "validate",
            help="Run the validation block from a task spec.",
        )
        validate_parser.add_argument("--task-file", required=True, help="Path to the task markdown file.")
        validate_parser.add_argument(
            "--expected-git-sha",
            help="Optional git SHA for live validation healthz checks.",
        )
        validate_parser.set_defaults(handler=_run_validate)

        orchestrator_parser = subparsers.add_parser(
            "orchestrator",
            help="Run the IterFact local orchestrator.",
        )
        orchestrator_subparsers = orchestrator_parser.add_subparsers(dest="orchestrator_command")

        orchestrator_run_parser = orchestrator_subparsers.add_parser(
            "run",
            help="Run one task file through the orchestrator.",
        )
        orchestrator_run_parser.add_argument("--task-file", required=True, help="Path to the task markdown file.")
        orchestrator_run_parser.set_defaults(handler=_run_orchestrator)

        orchestrator_run_next_parser = orchestrator_subparsers.add_parser(
            "run-next",
            help="Run the next queued task from tasks/queue.",
        )
        orchestrator_run_next_parser.add_argument(
            "--queue-dir",
            default="tasks/queue",
            help="Queue directory to scan for markdown task specs.",
        )
        orchestrator_run_next_parser.set_defaults(handler=_run_orchestrator)

        orchestrator_inspect_parser = orchestrator_subparsers.add_parser(
            "inspect",
            help="Inspect orchestrator state for one task.",
        )
        orchestrator_inspect_parser.add_argument("--task-id", required=True, help="Task id to inspect.")
        orchestrator_inspect_parser.set_defaults(handler=_run_orchestrator)

        orchestrator_cleanup_parser = orchestrator_subparsers.add_parser(
            "cleanup",
            help="Remove stale orchestrator worktrees.",
        )
        orchestrator_cleanup_parser.add_argument(
            "--max-age-hours",
            type=int,
            default=24,
            help="Delete stale worktrees older than this age.",
        )
        orchestrator_cleanup_parser.set_defaults(handler=_run_orchestrator)

        orchestrator_dashboard_parser = orchestrator_subparsers.add_parser(
            "dashboard",
            help="Open the Conductor dashboard on the running MCP server.",
        )
        orchestrator_dashboard_parser.add_argument("--host", help="MCP server host to open.")
        orchestrator_dashboard_parser.add_argument("--port", type=int, help="MCP server port to open.")
        orchestrator_dashboard_parser.add_argument("--env-file", help="Optional path to a dotenv file.")
        orchestrator_dashboard_parser.add_argument(
            "--no-browser",
            action="store_true",
            help="Print the dashboard URL without opening a browser.",
        )
        orchestrator_dashboard_parser.set_defaults(handler=_run_orchestrator)

    return parser


def _run_validate(args: argparse.Namespace) -> int:
    private_runtime = _load_private_orchestrator_runtime()
    emit_cli_usage_telemetry(entrypoint="iterfact", command_name="validate")
    repo_root = Path.cwd()
    task = private_runtime["load_task_spec"](getattr(args, "task_file"), repo_root)
    validator = private_runtime["HostedArtifactValidator"](repo_root=repo_root)
    result = validator.validate(
        task,
        working_root=repo_root,
        expected_git_sha=getattr(args, "expected_git_sha", None),
    )
    print(json.dumps(result.to_dict(), indent=2, ensure_ascii=False))
    return 0 if result.ok else 1


def _run_orchestrator(args: argparse.Namespace) -> int:
    subcommand = getattr(args, "orchestrator_command", "")
    emit_cli_usage_telemetry(
        entrypoint="iterfact",
        command_name=f"orchestrator:{subcommand or 'unknown'}",
    )
    if subcommand == "dashboard":
        return _run_orchestrator_dashboard(args)

    private_runtime = _load_private_orchestrator_runtime()
    repo_root = Path.cwd()
    runner = private_runtime["OrchestratorRunner"](repo_root)
    if subcommand == "run":
        summary = runner.run_task_file(getattr(args, "task_file"))
        print(json.dumps(summary.__dict__, indent=2, ensure_ascii=False))
        return 0
    if subcommand == "run-next":
        summary = runner.run_next(getattr(args, "queue_dir"))
        print(json.dumps(summary.__dict__, indent=2, ensure_ascii=False))
        return 0
    if subcommand == "inspect":
        print(json.dumps(runner.inspect(getattr(args, "task_id")), indent=2, ensure_ascii=False))
        return 0
    if subcommand == "cleanup":
        print(
            json.dumps(
                runner.cleanup(max_age_hours=int(getattr(args, "max_age_hours", 24))),
                indent=2,
                ensure_ascii=False,
            )
        )
        return 0
    raise SystemExit("Please choose an orchestrator subcommand: run, run-next, inspect, cleanup, or dashboard.")


def _run_orchestrator_dashboard(args: argparse.Namespace) -> int:
    private_runtime = _load_private_orchestrator_runtime()
    _load_runtime_env(getattr(args, "env_file", None))
    host = getattr(args, "host", None) or os.environ.get("HOST") or "127.0.0.1"
    port = int(getattr(args, "port", None) or os.environ.get("PORT") or 8000)
    dashboard_url = private_runtime["build_orchestrator_dashboard_url"](host, port)
    tasks_url = dashboard_url.rstrip("/") + "/api/tasks"
    try:
        with urllib.request.urlopen(tasks_url, timeout=2.0) as response:
            if int(getattr(response, "status", 200)) >= 400:
                raise urllib.error.URLError(f"unexpected status {response.status}")
    except Exception as exc:
        raise SystemExit(
            "IterFact MCP server is not running for the Conductor dashboard. "
            f"Start it with `iterfact serve --open-orchestrator-dashboard` or `iterfact serve`, then open {dashboard_url}. "
            f"Detail: {exc}"
        ) from exc
    if not getattr(args, "no_browser", False):
        with contextlib.suppress(Exception):
            webbrowser.open(dashboard_url)
    print(dashboard_url)
    return 0


def _handled_private_error_types() -> tuple[type[BaseException], ...]:
    with contextlib.suppress(Exception):
        private_runtime = _load_private_orchestrator_runtime()
        return (
            private_runtime["OrchestratorRunError"],
            private_runtime["OrchestratorConfigError"],
            private_runtime["TaskSpecError"],
            private_runtime["ValidationError"],
        )
    return ()


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help()
        return 0
    handled_errors = _handled_private_error_types()
    try:
        return int(handler(args) or 0)
    except Exception as exc:  # noqa: BLE001
        if handled_errors and isinstance(exc, handled_errors):
            raise SystemExit(str(exc)) from exc
        raise


def mcp_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="iterfact-mcp",
        description="Run the IterFact MCP server.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    _build_mcp_parser(parser)
    args = parser.parse_args(argv)
    return _run_mcp(args, entrypoint="iterfact-mcp", command_name="mcp")


if __name__ == "__main__":
    raise SystemExit(main())
