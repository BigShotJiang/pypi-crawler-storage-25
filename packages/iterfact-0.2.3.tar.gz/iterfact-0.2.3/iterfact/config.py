from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".iterfact"
CONFIG_PATH = CONFIG_DIR / "config.json"


def load_cli_config() -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    try:
        payload = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cli_config(config: dict[str, Any]) -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(config, indent=2, sort_keys=True), encoding="utf-8")
    return CONFIG_PATH


def get_saved_account_token() -> str | None:
    token = str(load_cli_config().get("account_token") or "").strip()
    if token.startswith("itf_"):
        return token
    return None


def set_saved_account_token(token: str) -> Path:
    config = load_cli_config()
    config["account_token"] = str(token).strip()
    return save_cli_config(config)
