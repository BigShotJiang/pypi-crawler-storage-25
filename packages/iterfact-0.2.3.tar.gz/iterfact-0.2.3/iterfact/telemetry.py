from __future__ import annotations

import contextlib
import json
import os
import platform
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import httpx

from iterfact import __version__


TELEMETRY_DISABLE_VALUES = {"1", "true", "yes", "on"}
DEFAULT_TELEMETRY_BASE_URL = "https://mcp.iterfact.com"
TELEMETRY_STATE_DIRNAME = ".iterfact"
TELEMETRY_STATE_FILENAME = "telemetry-state.json"
COMMAND_THROTTLE_WINDOW = timedelta(hours=24)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _utc_iso(now: datetime | None = None) -> str:
    return (now or _utc_now()).isoformat()


def telemetry_disabled() -> bool:
    value = os.getenv("ITERFACT_NO_TELEMETRY", "").strip().lower()
    return value in TELEMETRY_DISABLE_VALUES


def running_in_ci() -> bool:
    ci_markers = [
        os.getenv("CI", ""),
        os.getenv("GITHUB_ACTIONS", ""),
        os.getenv("BUILD_BUILDID", ""),
        os.getenv("JENKINS_URL", ""),
    ]
    return any(str(marker).strip().lower() in TELEMETRY_DISABLE_VALUES for marker in ci_markers)


def resolve_telemetry_base_url() -> str:
    return (
        os.getenv("ITERFACT_TELEMETRY_BASE_URL", "").strip()
        or os.getenv("ITERFACT_MCP_PUBLIC_BASE_URL", "").strip()
        or DEFAULT_TELEMETRY_BASE_URL
    ).rstrip("/")


def resolve_state_path() -> Path | None:
    custom_dir = os.getenv("ITERFACT_CONFIG_DIR", "").strip()
    if custom_dir:
        return Path(custom_dir).expanduser() / TELEMETRY_STATE_FILENAME

    with contextlib.suppress(Exception):
        return Path.home() / TELEMETRY_STATE_DIRNAME / TELEMETRY_STATE_FILENAME
    return None


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with contextlib.suppress(Exception):
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, dict):
            return payload
    return {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def load_state(path: Path | None = None) -> dict[str, Any]:
    resolved = path or resolve_state_path()
    if resolved is None:
        return {}
    return _read_json(resolved)


def parse_iso_datetime(raw: Any) -> datetime | None:
    text = str(raw or "").strip()
    if not text:
        return None
    with contextlib.suppress(ValueError):
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    return None


def build_cli_telemetry_batch(
    *,
    entrypoint: str,
    command_name: str,
    state: dict[str, Any] | None = None,
    now: datetime | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    moment = now or _utc_now()
    timestamp = _utc_iso(moment)
    payload = dict(state or {})
    install_id = str(payload.get("install_id") or "").strip()
    if not install_id:
        install_id = str(uuid.uuid4())
        payload["install_id"] = install_id
        payload["created_at"] = timestamp

    last_sent_by_command = payload.get("last_sent_by_command")
    if not isinstance(last_sent_by_command, dict):
        last_sent_by_command = {}
        payload["last_sent_by_command"] = last_sent_by_command

    base_event = {
        "channel": "python_package",
        "client_name": "iterfact",
        "client_version": __version__,
        "entrypoint": entrypoint,
        "command_name": command_name,
        "install_id": install_id,
        "python_version": platform.python_version(),
        "platform_system": platform.system(),
        "platform_release": platform.release(),
        "platform_machine": platform.machine(),
        "is_ci": running_in_ci(),
        "metadata": {
            "telemetry_mode": "anonymous_opt_out",
            "throttle_window_hours": int(COMMAND_THROTTLE_WINDOW.total_seconds() // 3600),
        },
    }

    events: list[dict[str, Any]] = []
    if payload.get("first_run_sent_at") is None:
        first_run_event = dict(base_event)
        first_run_event["event_name"] = "install_initialized"
        events.append(first_run_event)

    throttle_key = f"{entrypoint}:{command_name}"
    last_sent_at = parse_iso_datetime(last_sent_by_command.get(throttle_key))
    if last_sent_at is None or (moment - last_sent_at) >= COMMAND_THROTTLE_WINDOW:
        command_event = dict(base_event)
        command_event["event_name"] = "command_invoked"
        events.append(command_event)

    return events, payload


def _post_usage_events(
    *,
    base_url: str,
    events: list[dict[str, Any]],
    state_path: Path | None,
    state: dict[str, Any],
) -> None:
    if not events:
        return

    now = _utc_now()
    timestamp = _utc_iso(now)
    try:
        with httpx.Client(timeout=3.0) as client:
            response = client.post(
                f"{base_url}/v1/telemetry/client",
                headers={
                    "User-Agent": f"iterfact-python/{__version__}",
                    "X-IterFact-Client": "python_package",
                },
                json={"events": events},
            )
            response.raise_for_status()
    except Exception:
        return

    updated_state = dict(state)
    last_sent = dict(updated_state.get("last_sent_by_command") or {})
    for event in events:
        if event.get("event_name") == "install_initialized":
            updated_state["first_run_sent_at"] = timestamp
        if event.get("event_name") == "command_invoked":
            throttle_key = f"{event.get('entrypoint')}:{event.get('command_name')}"
            last_sent[throttle_key] = timestamp
    updated_state["last_sent_by_command"] = last_sent

    if state_path is not None:
        with contextlib.suppress(Exception):
            _write_json(state_path, updated_state)


def emit_cli_usage_telemetry(*, entrypoint: str, command_name: str) -> None:
    if telemetry_disabled() or running_in_ci():
        return

    base_url = resolve_telemetry_base_url()
    if not base_url:
        return

    state_path = resolve_state_path()
    state = load_state(state_path)
    events, next_state = build_cli_telemetry_batch(
        entrypoint=entrypoint,
        command_name=command_name,
        state=state,
    )
    if not events:
        return

    if state_path is not None:
        with contextlib.suppress(Exception):
            _write_json(state_path, next_state)

    worker = threading.Thread(
        target=_post_usage_events,
        kwargs={
            "base_url": base_url,
            "events": events,
            "state_path": state_path,
            "state": next_state,
        },
        daemon=True,
        name="iterfact-telemetry",
    )
    worker.start()
