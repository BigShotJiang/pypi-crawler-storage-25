from __future__ import annotations

import asyncio
import contextlib
import os
import threading
import time
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Awaitable, Callable

import httpx
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from iterfact.config import get_saved_account_token

DEFAULT_MCP_BASE_URL = "https://mcp.iterfact.com"
DEFAULT_PROTOCOL_VERSION = "2025-03-26"
PUBLISHED_ARTIFACT_STATUSES = {"published", "complete"}
FAILED_ARTIFACT_STATUSES = {"failed", "error"}
AUTH_REQUIRED_TOOL_NAMES = {
    "inspect_artifact_page_target",
    "publish_artifact_page",
    "unpublish_artifact_page",
    "upload_artifact_to_iterfact",
    "generate_document",
}
METERED_TOOL_NAMES = {
    "upload_artifact_to_iterfact",
    "generate_document",
}
try:
    PACKAGE_VERSION = version("iterfact")
except PackageNotFoundError:
    PACKAGE_VERSION = "0.2.3"


class IterFactClientError(RuntimeError):
    """Raised when an IterFact HTTP or MCP call fails."""


class IterFactAuthError(IterFactClientError):
    """Raised when a call needs an IterFact account token or reconnect."""


@dataclass(frozen=True)
class ToolCallResult:
    name: str
    structured_content: Any
    raw_content: list[dict[str, Any]]
    is_error: bool


def _resolve_base_url(base_url: str | None) -> str:
    return (
        str(base_url or "").strip()
        or os.environ.get("ITERFACT_MCP_PUBLIC_BASE_URL", "").strip()
        or os.environ.get("ITERFACT_MCP_BASE_URL", "").strip()
        or DEFAULT_MCP_BASE_URL
    ).rstrip("/")


def _run_coro(coro_factory: Callable[[], Awaitable[Any]]) -> Any:
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro_factory())

    result_box: dict[str, Any] = {}
    error_box: dict[str, BaseException] = {}

    def _worker() -> None:
        try:
            result_box["value"] = asyncio.run(coro_factory())
        except BaseException as exc:  # noqa: BLE001
            error_box["error"] = exc

    thread = threading.Thread(target=_worker, daemon=True, name="iterfact-client")
    thread.start()
    thread.join()
    if "error" in error_box:
        raise error_box["error"]
    return result_box.get("value")


class IterFactClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = 60.0,
        client_name: str = "iterfact-python-client",
        client_version: str = PACKAGE_VERSION,
    ) -> None:
        self.base_url = _resolve_base_url(base_url)
        self.api_key = (
            str(api_key or "").strip()
            or os.environ.get("ITERFACT_ACCOUNT_TOKEN", "").strip()
            or str(get_saved_account_token() or "").strip()
        )
        if not self.api_key:
            self.api_key = self._interactive_configure()
        self.timeout_seconds = float(timeout_seconds)
        self.client_name = client_name
        self.client_version = client_version

    @staticmethod
    def _interactive_configure() -> str:
        import webbrowser
        from iterfact.config import set_saved_account_token

        print()
        print("  Welcome to IterFact.")
        print()
        print("  You need an account token to continue.")
        print("  Create a free one at: https://iterfact.com/settings/tokens")
        print()

        with contextlib.suppress(Exception):
            webbrowser.open("https://iterfact.com/settings/tokens")

        while True:
            try:
                token = input("  Paste your IterFact token (itf_...): ").strip()
            except (EOFError, KeyboardInterrupt):
                raise IterFactAuthError(
                    "No token provided. Run `iterfact configure` or pass api_key='itf_...' to IterFactClient()."
                )
            if token.startswith("itf_") and len(token) > 8:
                set_saved_account_token(token)
                print(f"  Saved. You're connected.")
                print()
                return token
            if token:
                print("  IterFact tokens start with 'itf_'. Try again.")
            else:
                print("  No token entered. Try again or press Ctrl+C to exit.")

    @property
    def mcp_url(self) -> str:
        return f"{self.base_url}/mcp"

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/json, text/event-stream",
            "Content-Type": "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _format_auth_error_message(
        self,
        *,
        detail: str | None = None,
        metered: bool = False,
    ) -> str:
        lines: list[str] = []
        normalized_detail = str(detail or "").strip()
        if normalized_detail:
            lines.append(normalized_detail)
        else:
            lines.append("No IterFact account token configured.")
        lines.append(
            "Run `iterfact configure` to connect your IterFact account, "
            "or pass api_key='itf_...' to IterFactClient()."
        )
        if metered:
            lines.append(
                "Metered IterFact operations use credits from the connected account."
            )
        return "\n".join(lines)

    def _auth_error(self, *, detail: str | None = None, metered: bool = False) -> IterFactAuthError:
        return IterFactAuthError(
            self._format_auth_error_message(detail=detail, metered=metered)
        )

    def _require_account_token(self, tool_name: str) -> None:
        if tool_name not in AUTH_REQUIRED_TOOL_NAMES or self.api_key:
            return
        raise self._auth_error(metered=tool_name in METERED_TOOL_NAMES)

    @staticmethod
    def _looks_like_auth_error(message: str) -> bool:
        normalized = str(message or "").strip().lower()
        if not normalized:
            return False
        auth_markers = (
            "authorization required",
            "auth required",
            "token not recognized",
            "token lookup",
            "reconnect your iterfact account",
            "connect your iterfact account",
            "account token",
            "oauth",
            "unauthenticated",
            "requires an account token",
        )
        return any(marker in normalized for marker in auth_markers)

    def _raise_for_http_error(
        self,
        *,
        response: httpx.Response,
        metered: bool = False,
    ) -> None:
        if response.is_success:
            return
        payload: dict[str, Any] | None = None
        with contextlib.suppress(Exception):
            candidate = response.json()
            if isinstance(candidate, dict):
                payload = candidate
        message = (
            str((payload or {}).get("message") or "").strip()
            or str((payload or {}).get("error_description") or "").strip()
            or str((payload or {}).get("error") or "").strip()
        )
        if response.status_code in {401, 403, 503} or self._looks_like_auth_error(message):
            raise self._auth_error(detail=message or None, metered=metered)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            raise IterFactClientError(message or str(exc)) from exc

    async def _call_tool_async(self, name: str, arguments: dict[str, Any] | None = None) -> ToolCallResult:
        async with streamablehttp_client(
            self.mcp_url,
            headers=self._headers(),
            timeout=self.timeout_seconds,
        ) as (read_stream, write_stream, _):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                result = await session.call_tool(name, arguments or {})
        raw_content: list[dict[str, Any]] = []
        for item in (result.content or []):
            if isinstance(item, dict):
                raw_content.append(item)
            elif hasattr(item, "model_dump"):
                raw_content.append(dict(item.model_dump()))
            else:
                raw_content.append({"text": str(getattr(item, "text", "") or "")})
        return ToolCallResult(
            name=name,
            structured_content=result.structuredContent,
            raw_content=raw_content,
            is_error=bool(result.isError),
        )

    def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        self._require_account_token(name)
        try:
            result = _run_coro(lambda: self._call_tool_async(name, arguments))
        except httpx.HTTPStatusError as exc:
            response = exc.response
            if response is not None:
                self._raise_for_http_error(
                    response=response,
                    metered=name in METERED_TOOL_NAMES,
                )
            raise
        if result.is_error:
            message = "\n".join(
                str(item.get("text") or "").strip()
                for item in result.raw_content
                if isinstance(item, dict) and str(item.get("text") or "").strip()
            )
            if self._looks_like_auth_error(message):
                raise self._auth_error(
                    detail=message or None,
                    metered=name in METERED_TOOL_NAMES,
                )
            raise IterFactClientError(message or f"IterFact tool call failed: {name}")
        if result.structured_content is not None:
            return result.structured_content
        text = "\n".join(
            str(item.get("text") or "").strip()
            for item in result.raw_content
            if isinstance(item, dict) and str(item.get("text") or "").strip()
        )
        return {"text": text}

    def _get(self, path: str) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        with httpx.Client(timeout=self.timeout_seconds, headers=self._headers()) as client:
            response = client.get(url)
            self._raise_for_http_error(response=response)
            payload = response.json()
        if not isinstance(payload, dict):
            raise IterFactClientError(f"Expected JSON object from {url}")
        return payload

    def health(self) -> dict[str, Any]:
        return self._get("/healthz")

    def get_iterfact_connection_status(self) -> dict[str, Any]:
        payload = self.call_tool("get_iterfact_connection_status", {})
        if not isinstance(payload, dict):
            raise IterFactClientError("get_iterfact_connection_status returned non-dict payload")
        return payload

    def get_artifact_status(self, artifact_id: str) -> dict[str, Any]:
        artifact_id = str(artifact_id or "").strip()
        if not artifact_id:
            raise IterFactClientError("artifact_id is required")
        return self._get(f"/v1/artifacts/{artifact_id}/status")

    def wait_for_artifact(
        self,
        artifact_id: str,
        *,
        timeout_seconds: float = 600.0,
        poll_interval_seconds: float = 2.0,
    ) -> dict[str, Any]:
        started_at = time.time()
        last_status: dict[str, Any] | None = None
        while (time.time() - started_at) <= float(timeout_seconds):
            status = self.get_artifact_status(artifact_id)
            last_status = status
            normalized = str(status.get("artifact_status") or "").strip().lower()
            if normalized in PUBLISHED_ARTIFACT_STATUSES:
                return status
            if normalized in FAILED_ARTIFACT_STATUSES:
                raise IterFactClientError(
                    f"Artifact {artifact_id} failed with status '{normalized}'."
                )
            time.sleep(float(poll_interval_seconds))
        raise TimeoutError(
            f"Timed out waiting for artifact {artifact_id} to publish."
            + (f" Last status: {last_status!r}" if last_status else "")
        )

    def analyze_upload_artifact_html(self, html: str, title: str | None = None) -> dict[str, Any]:
        payload = self.call_tool("analyze_upload_artifact_html", {"html": html, "title": title})
        if not isinstance(payload, dict):
            raise IterFactClientError("analyze_upload_artifact_html returned non-dict payload")
        return payload

    def upload_artifact_to_iterfact(
        self,
        html: str,
        title: str,
        *,
        interaction_mode: str = "fact",
        description: str | None = None,
        theme: str | None = None,
    ) -> dict[str, Any]:
        arguments = {
            "html": html,
            "title": title,
            "description": description,
            "theme": theme,
        }
        payload = self.call_tool("upload_artifact_to_iterfact", arguments)
        if not isinstance(payload, dict):
            raise IterFactClientError("upload_artifact_to_iterfact returned non-dict payload")
        if interaction_mode:
            payload.setdefault("interaction_mode", interaction_mode)
        return payload

    def generate_document(self, prompt: str, **kwargs: Any) -> dict[str, Any]:
        arguments = {"prompt": prompt, **kwargs}
        payload = self.call_tool("generate_document", arguments)
        if not isinstance(payload, dict):
            raise IterFactClientError("generate_document returned non-dict payload")
        return payload

    def inspect_artifact_page_target(self, page_path: str) -> dict[str, Any]:
        payload = self.call_tool("inspect_artifact_page_target", {"page_path": page_path})
        if not isinstance(payload, dict):
            raise IterFactClientError("inspect_artifact_page_target returned non-dict payload")
        return payload

    def publish_artifact_page(
        self,
        artifact_id: str,
        page_path: str,
        *,
        if_occupied: str | None = None,
        display_name: str | None = None,
        description: str | None = None,
        display_visibility: str | None = None,
    ) -> dict[str, Any]:
        arguments = {
            "artifact_id": artifact_id,
            "page_path": page_path,
        }
        if if_occupied is not None:
            arguments["if_occupied"] = if_occupied
        if display_name is not None:
            arguments["display_name"] = display_name
        if description is not None:
            arguments["description"] = description
        if display_visibility is not None:
            arguments["display_visibility"] = display_visibility
        payload = self.call_tool("publish_artifact_page", arguments)
        if not isinstance(payload, dict):
            raise IterFactClientError("publish_artifact_page returned non-dict payload")
        return payload

    def unpublish_artifact_page(self, page_path: str) -> dict[str, Any]:
        payload = self.call_tool("unpublish_artifact_page", {"page_path": page_path})
        if not isinstance(payload, dict):
            raise IterFactClientError("unpublish_artifact_page returned non-dict payload")
        return payload
