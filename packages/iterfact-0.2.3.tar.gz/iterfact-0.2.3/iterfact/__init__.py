"""Installable IterFact CLI package."""

__all__ = ["__version__", "IterFactAuthError", "IterFactClient", "IterFactClientError"]

__version__ = "0.2.3"


def __getattr__(name: str):
    if name in {"IterFactAuthError", "IterFactClient", "IterFactClientError"}:
        from iterfact.client import IterFactAuthError, IterFactClient, IterFactClientError

        exports = {
            "IterFactAuthError": IterFactAuthError,
            "IterFactClient": IterFactClient,
            "IterFactClientError": IterFactClientError,
        }
        return exports[name]
    raise AttributeError(name)
