"""`animica chat` — interactive REPL.

Behavior:

1. On start, prints wallet address + balance + AICF endpoint + the current
   provider cascade status.
2. Each user line goes through the provider cascade. Streaming responses
   are echoed live; the final turn record is appended to history.
3. Slash commands: /help /quit /balance /history /save /provider /tier
   /clear /status.
4. When `distributed-aicf` is the active provider, every turn shows a
   pre-flight cost preview the user can accept or reject (Y/n) unless
   `--yolo` was passed.
5. On Ctrl+C the REPL aborts the current turn but stays alive; Ctrl+D
   (EOF) exits cleanly.

Exit codes:
   0  clean exit
   2  config error
   3  wallet error
   4  no provider available
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Callable, Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from agent_runtime.agentic import (
    AgentTurn,
    PermissionPolicy,
    ToolSpec,
    run_agent_loop,
)
from agent_runtime.config import load_config
from agent_runtime.errors import (
    AgentRuntimeError,
    ConfigError,
    ProviderUnavailable,
    WalletError,
)
from agent_runtime.providers import ProviderCascade, TurnRequest, TurnResult


app = typer.Typer(
    add_completion=False,
    help="Open an interactive AICF-paid chat session with the Animica agent.",
    no_args_is_help=False,
)


# --------------------------------------------------------------------------- #
# History persistence                                                         #
# --------------------------------------------------------------------------- #

def _history_dir() -> Path:
    home = Path(os.environ.get("ANIMICA_DATA_DIR", "~/.animica")).expanduser()
    p = home / "agent_runtime" / "history"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save_history(turns: list[dict]) -> Path:
    p = _history_dir() / f"chat-{int(time.time())}.json"
    p.write_text(json.dumps(turns, indent=2, sort_keys=False), encoding="utf-8")
    return p


# --------------------------------------------------------------------------- #
# Slash commands                                                              #
# --------------------------------------------------------------------------- #

class _SlashHandler:
    def __init__(self, console: Console, cascade: ProviderCascade,
                 state: dict) -> None:
        self.console = console
        self.cascade = cascade
        self.state = state

    def dispatch(self, line: str) -> bool:
        """Return True if line was a slash command (handled)."""
        if not line.startswith("/"):
            return False
        cmd, _, rest = line[1:].partition(" ")
        rest = rest.strip()
        method = getattr(self, f"_cmd_{cmd}", None)
        if method is None:
            self.console.print(f"[yellow]unknown command: /{cmd}[/yellow] "
                                f"(try /help)")
            return True
        method(rest)
        return True

    def _cmd_help(self, _: str) -> None:
        t = Table(title="Slash commands", show_header=False, box=None)
        t.add_column(style="bold cyan")
        t.add_column()
        for line in [
            ("/help",          "Show this list."),
            ("/quit",          "Exit the chat REPL."),
            ("/balance",       "Refresh and print wallet balance."),
            ("/history",       "List the turns in this session."),
            ("/save",          "Save the session transcript to "
                                "~/.animica/agent_runtime/history/."),
            ("/provider <n>",  "Force a specific provider for the next turn "
                                "(distributed-aicf | local-flagship | offline)."),
            ("/tier <id>",     "Prefer a specific tier (tiny|small|flagship|large)."),
            ("/clear",         "Clear the screen and forget history."),
            ("/status",        "Show provider cascade status."),
            ("/agent <task>",  "Run an agentic task with tool calls "
                                "(read/write/edit/bash, gated)."),
        ]:
            t.add_row(*line)
        self.console.print(t)

    def _cmd_quit(self, _: str) -> None:
        self.state["exit"] = True

    def _cmd_balance(self, _: str) -> None:
        # Force a re-load by clearing the cached wallet info on the
        # distributed-aicf provider, then re-asking is_available.
        for p in self.cascade._providers:    # type: ignore[attr-defined]
            if hasattr(p, "_wallet"):
                p._wallet = None              # type: ignore[attr-defined]
        for row in self.cascade.provider_status():
            self.console.print(
                f"  {row['name']:<20}  {row['available']:<3}  {row['reason']}",
            )

    def _cmd_history(self, _: str) -> None:
        turns: list[TurnResult] = self.state.get("turns", [])
        if not turns:
            self.console.print("[dim]no turns yet[/dim]")
            return
        for i, t in enumerate(turns, 1):
            self.console.print(
                f"  [{i}] {t.provider:<18} tier={t.tier or '-':<8} "
                f"cost={t.cost_animica:.6f} latency={t.latency_ms}ms",
            )

    def _cmd_save(self, _: str) -> None:
        turns: list[TurnResult] = self.state.get("turns", [])
        records = [
            {
                "user": e["user"],
                "assistant": e["assistant"],
                "provider": e["meta"]["provider"],
                "tier": e["meta"]["tier"],
                "cost_animica": e["meta"]["cost_animica"],
                "latency_ms": e["meta"]["latency_ms"],
                "fallback_reasons": e["meta"]["fallback_reasons"],
            }
            for e in self.state.get("transcript", [])
        ]
        path = _save_history(records)
        self.console.print(f"[green]saved {len(records)} turn(s) to {path}[/green]")

    def _cmd_provider(self, rest: str) -> None:
        if rest not in {"distributed-aicf", "local-flagship", "offline"}:
            self.console.print(
                "[yellow]provider must be one of "
                "distributed-aicf / local-flagship / offline[/yellow]",
            )
            return
        self.state["require_provider"] = rest
        self.console.print(f"[cyan]forced provider for next turn: {rest}[/cyan]")

    def _cmd_tier(self, rest: str) -> None:
        if not rest:
            self.state["tier_preferred"] = None
            self.console.print("[cyan]tier preference cleared[/cyan]")
            return
        self.state["tier_preferred"] = rest
        self.console.print(f"[cyan]tier preference: {rest}[/cyan]")

    def _cmd_clear(self, _: str) -> None:
        self.state["turns"] = []
        self.state["transcript"] = []
        self.console.clear()

    def _cmd_status(self, _: str) -> None:
        for row in self.cascade.provider_status():
            color = "green" if row["available"] == "yes" else "red"
            self.console.print(
                f"  [{color}]{row['name']:<20} {row['available']:<3}[/{color}] "
                f"{row['reason']}",
            )

    def _cmd_agent(self, rest: str) -> None:
        """Run a single agentic task: `/agent <task description>`.

        The model can call read_file / write_file / edit_file / bash etc.
        Non-safe tools prompt for confirmation per call unless --yolo-tools
        is set on the chat session.
        """
        task = rest.strip()
        if not task:
            self.console.print(
                "[yellow]usage: /agent <task description>[/yellow]"
            )
            return
        policy: PermissionPolicy = self.state.get("agent_policy") or PermissionPolicy()
        max_iters = int(self.state.get("agent_max_iters") or 10)
        max_cost = float(self.state.get("agent_max_cost") or 0.5)
        cwd = self.state.get("agent_cwd") or os.getcwd()
        run_one_agent_task(
            console=self.console,
            cascade=self.cascade,
            task=task,
            policy=policy,
            max_iterations=max_iters,
            max_cost=max_cost,
            cwd=cwd,
            tier_preferred=self.state.get("tier_preferred"),
        )


# --------------------------------------------------------------------------- #
# Agentic driver                                                              #
# --------------------------------------------------------------------------- #


def _permission_prompter(console: Console):
    """Build a prompter that asks the user about non-safe tool calls."""
    def _prompt(tool: ToolSpec, args: dict) -> str:
        console.print(
            f"\n[yellow]⚠ tool {tool.name} requires permission[/yellow]"
        )
        # Pretty-print the arguments — but truncate long content fields
        # so the prompt fits a terminal.
        pretty = {}
        for k, v in args.items():
            sv = str(v)
            if len(sv) > 400:
                sv = sv[:400] + f"... (+{len(sv)-400} more)"
            pretty[k] = sv
        for k, v in pretty.items():
            console.print(f"  [bold]{k}:[/bold] {v}")
        try:
            ans = input("Allow? [y]es / [s]ession / [n]o: ").strip().lower()
        except EOFError:
            return "deny"
        if ans in {"y", "yes"}:
            return "allow"
        if ans in {"s", "session"}:
            return "allow_session"
        return "deny"
    return _prompt


def _build_agent_submit(
    cascade: ProviderCascade,
    *,
    tier_preferred: Optional[str],
    yolo: bool,
    console: Optional[Console] = None,
    max_output_tokens: int = 256,
) -> Callable[[str], tuple[str, float, int]]:
    """Wrap ProviderCascade.serve so the agent loop sees a tiny callable.

    Tool-call turns only need ~50-120 tokens (one [TOOL_CALL] block plus a
    rationale line), so we cap output well below the chat default. On CPU
    miners this is the difference between sub-30s per turn and the 300s
    chat timeout firing mid-generation.
    """
    def _submit(prompt: str) -> tuple[str, float, int]:
        req = TurnRequest(
            prompt=prompt,
            tier_preferred=tier_preferred,
            history=[],          # the agent already serialized history into prompt
            yolo=True,           # agent steps must not block on cost prompts
            max_output_tokens=max_output_tokens,
        )
        result: TurnResult = cascade.serve(req)
        if console is not None:
            # Surface provider routing + fallback chain so the agent driver
            # can show WHY a step was answered by offline-stub vs the real
            # remote miner. Without this the agent's log shows zero-cost
            # offline answers with no obvious explanation.
            if result.provider != "distributed-aicf" or result.fallback_reasons:
                console.print(
                    f"  [dim]→ routed via {result.provider} (tier={result.tier or '-'})"
                    + (f"; fallbacks: {'; '.join(result.fallback_reasons)}"
                       if result.fallback_reasons else "")
                    + "[/dim]"
                )
        return result.text, float(result.cost_animica or 0.0), int(result.latency_ms or 0)
    return _submit


def run_one_agent_task(
    *,
    console: Console,
    cascade: ProviderCascade,
    task: str,
    policy: PermissionPolicy,
    max_iterations: int,
    max_cost: float,
    cwd: str,
    tier_preferred: Optional[str] = None,
) -> None:
    """Run a single agent task to completion; print a per-iteration trace."""
    console.print(
        f"\n[bold cyan]── agentic task ──[/bold cyan] {task}\n"
        f"[dim]cwd={cwd}  max_iterations={max_iterations}  "
        f"max_cost={max_cost} ANIMICA[/dim]"
    )

    def _on_iteration(turn: AgentTurn) -> None:
        header = f"[bold blue][{turn.iteration}][/bold blue] "
        if turn.tool_call is not None:
            args_inline = json.dumps(
                turn.tool_call.arguments, default=str
            )
            if len(args_inline) > 200:
                args_inline = args_inline[:200] + f"... (+{len(args_inline)-200})"
            console.print(
                f"{header}[magenta]tool:[/magenta] {turn.tool_call.name} "
                f"{args_inline}",
            )
            if turn.tool_result is not None:
                # Print first 400 chars of result so the trace is useful but
                # not overwhelming.
                preview = turn.tool_result
                if len(preview) > 400:
                    preview = preview[:400] + f"\n  ... (+{len(turn.tool_result)-400} more)"
                console.print(
                    "  [dim]result:[/dim]\n" +
                    "\n".join("  " + ln for ln in preview.splitlines())
                )
        else:
            preview = turn.assistant_text.strip()
            if len(preview) > 800:
                preview = preview[:800] + f"\n... (+{len(turn.assistant_text)-800} more)"
            console.print(f"{header}[green]final answer:[/green] {preview}")
        console.print(
            f"  [dim]cost={turn.cost_animica:.6f} ANIMICA  "
            f"latency={turn.latency_ms}ms[/dim]"
        )

    submit = _build_agent_submit(
        cascade, tier_preferred=tier_preferred, yolo=True, console=console,
    )
    prompter = _permission_prompter(console)
    try:
        result = run_agent_loop(
            user_task=task,
            submit_turn=submit,
            policy=policy,
            permission_prompter=prompter,
            on_iteration=_on_iteration,
            cwd=cwd,
            max_iterations=max_iterations,
            max_cost=max_cost,
        )
    except KeyboardInterrupt:
        console.print("\n[yellow](agent interrupted by user)[/yellow]")
        return
    except Exception as exc:  # noqa: BLE001
        console.print(f"\n[red]agent error: {exc}[/red]")
        return

    color = "green" if result.completed else "yellow"
    console.print(
        f"\n[bold {color}]── agentic task finished "
        f"({result.stop_reason}, {len(result.turns)} step(s), "
        f"total cost {result.total_cost:.6f} ANIMICA) ──[/bold {color}]"
    )
    if result.final_text:
        console.print(result.final_text)


# --------------------------------------------------------------------------- #
# REPL                                                                       #
# --------------------------------------------------------------------------- #

def _print_banner(console: Console, cascade: ProviderCascade,
                  endpoint: str) -> None:
    rows = cascade.provider_status()
    primary = next((r for r in rows if r["available"] == "yes"), None)
    primary_name = primary["name"] if primary else "none"
    body_lines = [
        f"endpoint:  {endpoint}",
        f"primary:   {primary_name}",
        "",
    ]
    for r in rows:
        mark = "[green]✓[/green]" if r["available"] == "yes" else "[red]✗[/red]"
        body_lines.append(f"  {mark}  {r['name']:<20}  {r['reason']}")
    panel = Panel("\n".join(body_lines),
                  title="animica chat", border_style="cyan")
    console.print(panel)
    console.print("type /help for commands; Ctrl+D to exit.\n")


def _confirm_cost(console: Console, prompt: str) -> bool:
    """Read y/n confirmation for paid turns."""
    console.print(prompt, end="")
    try:
        ans = input(" [Y/n] ").strip().lower()
    except EOFError:
        return False
    return ans in {"", "y", "yes"}


def _run_repl(cfg, rpc_url: str, wallet_path: Optional[str],
              yolo: bool, console: Console,
              wallet_label: Optional[str] = None,
              *,
              agent_policy: Optional[PermissionPolicy] = None,
              agent_max_iters: int = 10,
              agent_max_cost: float = 0.5,
              agent_cwd: Optional[str] = None) -> int:
    try:
        cascade = ProviderCascade(cfg, rpc_url=rpc_url,
                                  wallet_path=wallet_path,
                                  wallet_label=wallet_label)
    except (ConfigError, WalletError) as exc:
        console.print(f"[red]{exc.render()}[/red]")
        return 2

    _print_banner(console, cascade, rpc_url)
    state: dict = {
        "turns": [],
        "transcript": [],
        "exit": False,
        "require_provider": None,
        "tier_preferred":
            cfg.model_catalog["routing"].get("default_tier", "small"),
        "agent_policy": agent_policy or PermissionPolicy(),
        "agent_max_iters": agent_max_iters,
        "agent_max_cost": agent_max_cost,
        "agent_cwd": agent_cwd or os.getcwd(),
    }
    slash = _SlashHandler(console, cascade, state)
    history: list[dict[str, str]] = []
    try:
        while not state["exit"]:
            try:
                line = input("you> ").rstrip("\n")
            except EOFError:
                console.print()
                break
            except KeyboardInterrupt:
                console.print("\n[dim](interrupted; next prompt)[/dim]")
                continue
            if not line.strip():
                continue
            if slash.dispatch(line):
                continue

            require_provider = state["require_provider"]
            state["require_provider"] = None
            req = TurnRequest(
                prompt=line,
                tier_preferred=state["tier_preferred"],
                history=history,
                require_provider=require_provider,
                yolo=yolo,
            )

            # Pre-flight: when paying via distributed-aicf, show cost.
            if (not yolo and require_provider in (None, "distributed-aicf")
                and any(p.name == "distributed-aicf" and p.is_available()[0]
                        for p in cascade._providers)):       # type: ignore
                try:
                    # is_available already prepared the wallet; pull a fresh quote.
                    dist = next(p for p in cascade._providers
                                if p.name == "distributed-aicf")
                    quote = dist.client.estimate_cost(   # type: ignore[attr-defined]
                        __import__("agent_runtime.aicf_client", fromlist=[""])
                        .JobSpec(prompt=line,
                                 tier_preferred=state["tier_preferred"]))
                    wallet = dist._wallet_info()         # type: ignore[attr-defined]
                    if not _confirm_cost(
                        console,
                        f"[dim]quote: ~{quote.estimated_cost_animica:.6f} ANIMICA "
                        f"(balance {wallet.balance_animica:.6f}); proceed?",
                    ):
                        console.print("[dim]turn cancelled[/dim]")
                        continue
                except Exception:    # noqa: BLE001 — preview is best-effort
                    pass

            # Stream the response.
            console.print("[bold]assistant>[/bold] ", end="")
            text_buf: list[str] = []

            def relay(chunk: str, is_final: bool) -> None:
                text_buf.append(chunk)
                console.out(chunk, end="", style="white")
                if is_final:
                    console.print()

            req.stream_callback = relay
            try:
                result: TurnResult = cascade.serve(req)
            except ProviderUnavailable as exc:
                console.print(f"\n[red]provider unavailable: {exc.reason}[/red]")
                continue
            except AgentRuntimeError as exc:
                console.print(f"\n[red]{exc.render()}[/red]")
                continue
            if not text_buf:    # provider did not stream; print final once.
                console.print(result.text)
            # Append to history.
            history.append({"role": "user", "content": line})
            history.append({"role": "assistant", "content": result.text})
            state["turns"].append(result)
            state["transcript"].append({
                "user": line, "assistant": result.text,
                "meta": {
                    "provider": result.provider,
                    "tier": result.tier,
                    "cost_animica": result.cost_animica,
                    "latency_ms": result.latency_ms,
                    "fallback_reasons": result.fallback_reasons,
                    "effective_mode": result.effective_mode,
                },
            })
            # Per-turn footer line.
            footer = (
                f"  [dim]provider={result.provider}  tier={result.tier or '-'}"
                f"  cost={result.cost_animica:.6f} ANIMICA"
                f"  latency={result.latency_ms}ms[/dim]"
            )
            if result.fallback_reasons:
                footer += (f"  [yellow]fallbacks="
                            f"{'; '.join(result.fallback_reasons)}[/yellow]")
            console.print(footer)
    finally:
        cascade.close()
    return 0


# --------------------------------------------------------------------------- #
# Typer entrypoint                                                            #
# --------------------------------------------------------------------------- #

@app.callback(invoke_without_command=True)
def main(
    rpc_url: Optional[str] = typer.Option(
        None, "--rpc-url",
        help="Override AICF endpoint URL (default: from integration.yaml + "
              "active network).",
    ),
    wallet: Optional[str] = typer.Option(
        None, "--wallet",
        help="Wallet file path, label, or bech32 address. When not a file, "
              "the value is looked up in ~/.animica/wallets.json by label / "
              "address / public_key_hex. Default: bundle's selected wallet, "
              "then pinned wallet under ~/.animica/wallets/.",
    ),
    wallet_label: Optional[str] = typer.Option(
        None, "--wallet-label",
        help="Label of the wallet to use inside a v2 bundle (e.g. 'hot'). "
              "Defaults to the bundle's 'default', else the first entry.",
    ),
    yolo: bool = typer.Option(
        False, "--yolo",
        help="Skip per-turn cost confirmation; submit jobs immediately.",
    ),
    require_distributed: bool = typer.Option(
        False, "--require-distributed",
        help="Refuse to fall back to local-flagship or offline.",
    ),
    # ---- Agentic mode flags ----
    agentic: Optional[str] = typer.Option(
        None, "--agentic",
        help="Run a single agentic task (Claude Code style: read/write/edit/"
              "bash/grep tools, gated). Pass the task description as the "
              "argument; exits after the task completes.",
    ),
    yolo_tools: bool = typer.Option(
        False, "--yolo-tools",
        help="Auto-allow every tool call in agentic mode (CAREFUL — the "
              "model can run rm -rf or overwrite files unattended).",
    ),
    read_only: bool = typer.Option(
        False, "--read-only",
        help="In agentic mode, refuse all non-safe tools (write/edit/bash/...).",
    ),
    max_iterations: int = typer.Option(
        10, "--max-iterations",
        help="Agentic loop iteration cap.",
    ),
    max_cost: float = typer.Option(
        0.5, "--max-cost",
        help="Agentic loop cost cap in ANIMICA. Loop stops once exceeded.",
    ),
    cwd: Optional[str] = typer.Option(
        None, "--cwd",
        help="Working directory the agent sees (default: current directory).",
    ),
) -> None:
    """Interactive AICF-paid chat REPL."""
    console = Console()
    try:
        cfg = load_config()
    except ConfigError as exc:
        console.print(f"[red]{exc.render()}[/red]")
        raise typer.Exit(code=2)

    network = os.environ.get("ANIMICA_NETWORK") or _resolve_active_network()
    endpoint_map = cfg.integration["aicf"]["endpoint"]
    endpoint = rpc_url or endpoint_map.get(network) or endpoint_map.get(
        "mainnet")
    if not endpoint:
        console.print(
            "[red]no AICF endpoint configured for network "
            f"{network!r}[/red]")
        raise typer.Exit(code=2)

    if require_distributed:
        os.environ["ANIMICA_CHAT_REQUIRE_DISTRIBUTED"] = "1"
    if yolo:
        os.environ["ANIMICA_CHAT_YOLO"] = "1"

    # One-shot agentic mode: run the task, print transcript, exit.
    if agentic:
        try:
            cascade = ProviderCascade(cfg, rpc_url=endpoint,
                                      wallet_path=wallet,
                                      wallet_label=wallet_label)
        except (ConfigError, WalletError) as exc:
            console.print(f"[red]{exc.render()}[/red]")
            raise typer.Exit(code=2)
        policy = PermissionPolicy(yolo=yolo_tools, read_only=read_only)
        run_one_agent_task(
            console=console,
            cascade=cascade,
            task=agentic,
            policy=policy,
            max_iterations=max_iterations,
            max_cost=max_cost,
            cwd=cwd or os.getcwd(),
            tier_preferred=cfg.model_catalog["routing"].get(
                "default_tier", "small"
            ),
        )
        cascade.close()
        raise typer.Exit(code=0)

    rc = _run_repl(
        cfg, rpc_url=endpoint, wallet_path=wallet,
        yolo=yolo, console=console, wallet_label=wallet_label,
        agent_policy=PermissionPolicy(yolo=yolo_tools, read_only=read_only),
        agent_max_iters=max_iterations, agent_max_cost=max_cost,
        agent_cwd=cwd or os.getcwd(),
    )
    raise typer.Exit(code=rc)


def _resolve_active_network() -> str:
    """Find the active network via the existing animica CLI state, with
    safe fallback to mainnet. No regression on chain behavior."""
    try:
        from animica.cli.state import get_cli_state    # type: ignore
        state = get_cli_state()
        return str(state.get("active_network") or "mainnet")
    except Exception:    # noqa: BLE001
        return os.environ.get("ANIMICA_NETWORK", "mainnet")


# Console-script entrypoint (used by pyproject.toml::project.scripts).
def main_console() -> None:    # pragma: no cover — thin wrapper
    app()


# Module-execution entrypoint: `python -m agent_runtime.cli.chat`.
if __name__ == "__main__":
    app()
