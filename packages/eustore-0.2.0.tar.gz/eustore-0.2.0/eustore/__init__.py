"""
eustore — European AI Storage Client

The simplest way for AI agents to store data in Europe.

    pip install eustore

    from eustore import EUStore
    store = EUStore(api_key="eust_...")
    bucket = store.create_bucket("my-data")
    # Use bucket.s3_credentials with boto3
"""
import httpx
from dataclasses import dataclass
from typing import Optional


EUSTORE_API = "https://api.eustore.dev"


@dataclass
class BucketInfo:
    id: str
    name: str
    region: str
    status: str
    s3_endpoint: str
    s3_access_key: str
    size_gb: float


@dataclass 
class S3Credentials:
    bucket_name: str
    s3_endpoint: str
    s3_access_key: str
    s3_secret_key: str
    region: str
    
    def boto3_config(self) -> dict:
        """Return config dict for boto3.client('s3', **config)."""
        return {
            "endpoint_url": f"https://{self.s3_endpoint}",
            "aws_access_key_id": self.s3_access_key,
            "aws_secret_access_key": self.s3_secret_key,
        }


class EUStore:
    """
    European AI Storage client.
    
    S3-compatible object storage in the EU.
    GDPR-compliant, automated, no human interaction needed.
    
    Usage:
        store = EUStore(api_key="eust_your_key")
        
        # Create bucket
        bucket = store.create_bucket("training-data", region="eu-central-fsn1")
        
        # Get S3 credentials
        creds = store.get_credentials(bucket.id)
        
        # Use with boto3
        import boto3
        s3 = boto3.client('s3', **creds.boto3_config())
        s3.put_object(Bucket=creds.bucket_name, Key='test.txt', Body=b'hello')
    """
    
    def __init__(self, api_key: str, base_url: str = EUSTORE_API):
        self.base_url = base_url
        self._api_key = api_key
        self._token = None
    
    def _get_token(self) -> str:
        if self._token:
            return self._token
        resp = httpx.post(
            f"{self.base_url}/v1/auth/token",
            json={"api_key": self._api_key},
        )
        resp.raise_for_status()
        self._token = resp.json()["access_token"]
        return self._token
    
    def _headers(self):
        return {"Authorization": f"Bearer {self._get_token()}"}
    
    @staticmethod
    def register(name: str, email: str, base_url: str = EUSTORE_API) -> dict:
        """
        Register a new account. Returns {"customer_id": ..., "api_key": ...}.
        
        Store the api_key securely — it cannot be retrieved again.
        """
        resp = httpx.post(
            f"{base_url}/v1/auth/register",
            json={"name": name, "email": email},
        )
        resp.raise_for_status()
        return resp.json()
    
    def create_bucket(self, name: str, region: str = "eu-central-fsn1") -> BucketInfo:
        """Create a new S3-compatible storage bucket in the EU."""
        resp = httpx.post(
            f"{self.base_url}/v1/storage/buckets",
            json={"name": name, "region": region},
            headers=self._headers(),
        )
        resp.raise_for_status()
        data = resp.json()
        return BucketInfo(
            id=data["id"],
            name=data["name"],
            region=data["region"],
            status=data["status"],
            s3_endpoint=data["s3_endpoint"],
            s3_access_key=data["s3_access_key"],
            size_gb=data["size_gb"],
        )
    
    def list_buckets(self) -> list[BucketInfo]:
        """List all your storage buckets."""
        resp = httpx.get(
            f"{self.base_url}/v1/storage/buckets",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return [
            BucketInfo(
                id=b["id"], name=b["name"], region=b["region"],
                status=b["status"], s3_endpoint=b["s3_endpoint"],
                s3_access_key=b["s3_access_key"], size_gb=b["size_gb"],
            )
            for b in resp.json()
        ]
    
    def get_credentials(self, bucket_id: str) -> S3Credentials:
        """Get S3 credentials for a bucket. Use with boto3."""
        resp = httpx.get(
            f"{self.base_url}/v1/storage/buckets/{bucket_id}/credentials",
            headers=self._headers(),
        )
        resp.raise_for_status()
        data = resp.json()
        return S3Credentials(
            bucket_name=data["bucket_name"],
            s3_endpoint=data["s3_endpoint"],
            s3_access_key=data["s3_access_key"],
            s3_secret_key=data["s3_secret_key"],
            region=data["region"],
        )
    
    def delete_bucket(self, bucket_id: str) -> None:
        """Delete a bucket. Data retained for 30 days."""
        resp = httpx.delete(
            f"{self.base_url}/v1/storage/buckets/{bucket_id}",
            headers=self._headers(),
        )
        resp.raise_for_status()
    
    def balance(self) -> dict:
        """Check credit balance."""
        resp = httpx.get(
            f"{self.base_url}/v1/billing/balance",
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()
    
    def topup_crypto(self, token: str = "usdc", chain: str = "base", amount_eur: float = 10) -> dict:
        """Get crypto payment address to top up credits. Fully autonomous."""
        resp = httpx.post(
            f"{self.base_url}/v1/billing/topup/crypto",
            json={"token": token, "chain": chain, "amount_eur": amount_eur},
            headers=self._headers(),
        )
        resp.raise_for_status()
        return resp.json()
