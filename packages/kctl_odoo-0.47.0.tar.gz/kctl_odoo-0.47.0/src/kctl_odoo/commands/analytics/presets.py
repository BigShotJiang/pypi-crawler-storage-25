"""Built-in analytics presets (Tier 1).

Each preset is a dict defining model, measure, group_by, domain_template,
output_columns, and optional reconciles_with for P&L/BS validation.
"""

from __future__ import annotations

BUILTIN_PRESETS: dict[str, dict] = {
    "pnl-consolidated": {
        "description": "Consolidated P&L across multiple companies",
        "engine": "report",
        "report_type": "profit_loss",
        "measure": "actual",
        "params": ["company-ids", "date-from", "date-to"],
        "reconciles_with": {"report": "profit_loss", "line_code": "__total__", "tolerance_pct": 0.0},
    },
    "top-products": {
        "description": "Top N products by revenue across companies",
        "model": "sale.order.line",
        "measure": "price_subtotal",
        "aggregator": "sum",
        "group_by": ["product_id"],
        "order_by": "price_subtotal desc",
        "default_limit": 20,
        "domain_template": [("state", "in", ["sale", "done"])],
        "output_columns": [
            {"key": "product_id", "header": "Product", "type": "string"},
            {"key": "price_subtotal", "header": "Revenue", "type": "amount"},
        ],
        "params": ["company-ids", "date-from", "date-to", "limit"],
        "reconciles_with": {"report": "profit_loss", "line_code": "sales_revenue", "tolerance_pct": 5.0},
    },
    "salesman-performance": {
        "description": "Revenue by salesperson (from confirmed sales orders)",
        "model": "sale.order.line",
        "measure": "price_subtotal",
        "aggregator": "sum",
        "group_by": ["salesman_id"],
        "order_by": "price_subtotal desc",
        "default_limit": 20,
        "domain_template": [("state", "in", ["sale", "done"])],
        "output_columns": [
            {"key": "salesman_id", "header": "Salesperson", "type": "string"},
            {"key": "price_subtotal", "header": "Revenue", "type": "amount"},
        ],
        "params": ["company-ids", "date-from", "date-to", "limit"],
        "reconciles_with": {"report": "profit_loss", "line_code": "sales_revenue", "tolerance_pct": 5.0},
    },
    "ar-aging-summary": {
        "description": "Receivables aging buckets per partner",
        "engine": "report",
        "report_type": "receivable_aging",
        "measure": "actual",
        "params": ["company", "date"],
        "reconciles_with": {"report": "balance_sheet", "line_code": "receivables", "tolerance_pct": 1.0},
    },
    "top-customers": {
        "description": "Top N customers by revenue",
        "model": "account.move.line",
        "measure": "credit",
        "aggregator": "sum",
        "group_by": ["partner_id"],
        "order_by": "credit desc",
        "default_limit": 20,
        "domain_template": [
            ("account_id.account_type", "=", "income"),
            ("parent_state", "=", "posted"),
        ],
        "output_columns": [
            {"key": "partner_id", "header": "Customer", "type": "string"},
            {"key": "credit", "header": "Revenue", "type": "amount"},
        ],
        "params": ["company-ids", "date-from", "date-to", "limit"],
        "reconciles_with": {"report": "profit_loss", "line_code": "sales_revenue", "tolerance_pct": 5.0},
    },
    "expense-breakdown": {
        "description": "Expenses by account",
        "model": "account.move.line",
        "measure": "debit",
        "aggregator": "sum",
        "group_by": ["account_id"],
        "order_by": "debit desc",
        "default_limit": 30,
        "domain_template": [
            ("account_id.account_type", "in", ["expense", "expense_direct_cost"]),
            ("parent_state", "=", "posted"),
        ],
        "output_columns": [
            {"key": "account_id", "header": "Account", "type": "string"},
            {"key": "debit", "header": "Amount", "type": "amount"},
        ],
        "params": ["company-ids", "date-from", "date-to", "limit"],
        "reconciles_with": {"report": "profit_loss", "line_code": "operating_expenses", "tolerance_pct": 5.0},
    },
    "company-comparison": {
        "description": "P&L comparison across companies (side-by-side)",
        "engine": "report",
        "report_type": "profit_loss",
        "measure": "actual",
        "params": ["company-ids", "date-from", "date-to"],
        "reconciles_with": {"report": "profit_loss", "line_code": "__total__", "tolerance_pct": 0.0},
    },
    "monthly-trend": {
        "description": "Monthly revenue/expense trend",
        "model": "account.move.line",
        "measure": "balance",
        "aggregator": "sum",
        "group_by": ["date:month"],
        "order_by": "date:month asc",
        "default_limit": 12,
        "domain_template": [
            ("account_id.account_type", "=", "income"),
            ("parent_state", "=", "posted"),
        ],
        "output_columns": [
            {"key": "date:month", "header": "Month", "type": "string"},
            {"key": "balance", "header": "Revenue", "type": "amount"},
        ],
        "params": ["company-ids", "date-from", "date-to", "limit"],
        "reconciles_with": {"report": "profit_loss", "line_code": "sales_revenue", "tolerance_pct": 1.0},
    },
}
