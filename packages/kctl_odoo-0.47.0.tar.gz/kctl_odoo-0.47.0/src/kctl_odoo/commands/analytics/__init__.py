"""Analytics commands — one-call structured data for AI agents."""

from __future__ import annotations

import json
from typing import Annotated, Any

import typer

from kctl_odoo.core.callbacks import AppContext

from .engine import execute_preset
from .engine import render_markdown as _render_analyze_markdown
from .presets import BUILTIN_PRESETS
from .schema import load_custom_presets
from .validator import reconcile_with_report, validate_preset_fields

app = typer.Typer(help="One-call structured analytics for AI agents.")


def _all_presets() -> dict[str, dict[str, Any]]:
    merged = dict(BUILTIN_PRESETS)
    merged.update(load_custom_presets())
    return merged


@app.command("presets")
def list_presets(
    ctx: typer.Context,
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: pretty, json, or markdown")] = "pretty",
) -> None:
    """List all available analytics presets (built-in + custom YAML)."""
    actx: AppContext = ctx.obj
    out = actx.output
    presets = _all_presets()

    if actx.json_mode:
        out.raw_json(
            [
                {"name": name, "description": p.get("description", ""), "params": p.get("params", [])}
                for name, p in sorted(presets.items())
            ]
        )
    elif fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport

        preset_list = [{"name": name, "description": p.get("description", "")} for name, p in sorted(presets.items())]
        report = MarkdownReport(
            title="Analytics Presets",
            subtitle=f"{len(preset_list)} presets available",
        )
        for p in preset_list:
            report.add_bullet(f"`{p['name']}` — {p.get('description', '')}")
        out.markdown_report(report)
    else:
        rows = [[name, p.get("description", ""), ", ".join(p.get("params", []))] for name, p in sorted(presets.items())]
        out.table(["Preset", "Description", "Params"], rows, title=f"Analytics Presets ({len(presets)})")


@app.command("run")
def run_preset(
    ctx: typer.Context,
    preset_name: Annotated[str, typer.Argument(help="Preset name (e.g. top-products, pnl-consolidated)")],
    company: Annotated[int | None, typer.Option("--company", help="Company ID")] = None,
    company_ids: Annotated[str | None, typer.Option("--company-ids", help="Comma-separated company IDs")] = None,
    date_from: Annotated[str | None, typer.Option("--date-from", help="Start date (YYYY-MM-DD)")] = None,
    date_to: Annotated[str | None, typer.Option("--date-to", help="End date (YYYY-MM-DD)")] = None,
    as_of_date: Annotated[str | None, typer.Option("--date", help="As-of date")] = None,
    limit: Annotated[int | None, typer.Option("--limit", "-n", help="Max rows")] = None,
    validate: Annotated[
        bool, typer.Option("--validate/--no-validate", help="Cross-check against P&L/BS (default: on)")
    ] = True,
    output: Annotated[str | None, typer.Option("--output", "-o", help="Save JSON to file")] = None,
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: pretty, json, or markdown")] = "pretty",
) -> None:
    """Run an analytics preset and return structured data.

    Examples:
        kctl-odoo analyze run top-products --company-ids 1,2,3 --limit 10 --json
        kctl-odoo analyze run pnl-consolidated --company-ids 1,2,3 --json
        kctl-odoo analyze run salesman-performance --company 5 --validate --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    presets = _all_presets()
    if preset_name not in presets:
        available = ", ".join(sorted(presets.keys()))
        out.error(f"Preset '{preset_name}' not found. Available: {available}")
        raise typer.Exit(1)

    preset = {**presets[preset_name], "name": preset_name}
    co_ids = [int(x.strip()) for x in company_ids.split(",") if x.strip()] if company_ids else None

    # Validate fields for read_group presets
    if "model" in preset:
        errors = validate_preset_fields(c, preset)
        if errors:
            for e in errors:
                out.error(e)
            raise typer.Exit(1)

    result = execute_preset(
        c,
        preset,
        company_ids=co_ids,
        company_id=company,
        date_from=date_from,
        date_to=date_to,
        limit=limit,
        as_of_date=as_of_date,
    )

    if validate:
        q_total = result.get("query_total", 0)
        validation = reconcile_with_report(c, preset, q_total, co_ids or [company or 1], date_from, date_to)
        result["validated"] = validation.get("pass", False)
        result["validation"] = validation

    if output:
        from pathlib import Path

        Path(output).write_text(json.dumps(result, indent=2, default=str))
        out.success(f"Saved: {output}")
    elif actx.json_mode:
        out.raw_json(result)
    elif fmt == "markdown":
        report = _render_analyze_markdown(result)
        out.markdown_report(report)
    else:
        # Pretty terminal table
        rows_data = result.get("rows", [])
        if not rows_data:
            out.info("No data returned.")
            return
        columns = list(rows_data[0].keys())
        table_rows = [[str(r.get(c, "")) for c in columns] for r in rows_data[:50]]
        out.table(columns, table_rows, title=f"{preset_name} ({len(rows_data)} rows)")
        out.info(f"Total: {result.get('query_total', 0):,.2f}")
