"""Preset schema validation + custom YAML loader."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

REQUIRED_FIELDS = {"name", "description", "measure"}
REQUIRED_ONE_OF = {"model", "engine"}
CUSTOM_PRESETS_DIR = Path.home() / ".config" / "kodemeio" / "analytics"


def validate_preset_schema(preset: dict[str, Any]) -> list[str]:
    """Return list of validation error strings. Empty = valid."""
    errors: list[str] = []
    for field in REQUIRED_FIELDS:
        if field not in preset:
            errors.append(f"Missing required field: {field}")
    if not any(k in preset for k in REQUIRED_ONE_OF):
        errors.append(f"Must have one of: {REQUIRED_ONE_OF}")
    if "model" in preset and "group_by" not in preset:
        errors.append("read_group presets require 'group_by'")
    return errors


def load_custom_presets() -> dict[str, dict[str, Any]]:
    """Load custom YAML presets from ~/.config/kodemeio/analytics/."""
    presets: dict[str, dict] = {}
    if not CUSTOM_PRESETS_DIR.exists():
        return presets
    for path in CUSTOM_PRESETS_DIR.glob("*.yaml"):
        try:
            data = yaml.safe_load(path.read_text())
            if not isinstance(data, dict):
                continue
            if "name" not in data:
                data["name"] = path.stem
            errors = validate_preset_schema(data)
            if errors:
                continue
            presets[data["name"]] = data
        except (yaml.YAMLError, OSError):
            continue
    return presets
