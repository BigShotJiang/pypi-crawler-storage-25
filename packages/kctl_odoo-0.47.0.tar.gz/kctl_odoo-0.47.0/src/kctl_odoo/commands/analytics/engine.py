"""Query execution for analytics presets.

Dispatches to either Odoo's read_group (for ORM presets) or
compute_report_data (for report engine presets).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from kctl_lib.markdown_report import MarkdownReport


def build_read_group_args(
    preset: dict[str, Any],
    company_ids: list[int] | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    """Build read_group arguments from a preset + runtime parameters."""
    domain = list(preset.get("domain_template", []))
    if company_ids:
        domain.append(("company_id", "in", company_ids))
    if date_from:
        domain.append(("date", ">=", date_from))
    if date_to:
        domain.append(("date", "<=", date_to))

    measure = preset["measure"]
    group_by = list(preset.get("group_by", []))
    order = preset.get("order_by", f"{measure} desc")

    return {
        "model": preset["model"],
        "domain": domain,
        "fields": [measure],
        "groupby": group_by,
        "orderby": order,
        "limit": limit or preset.get("default_limit", 20),
        "lazy": False,
    }


def _format_m2o(val: Any) -> str:
    """Format a Many2one tuple [id, name] -> name string."""
    if isinstance(val, (list, tuple)) and len(val) == 2:
        return str(val[1])
    return str(val) if val else ""


def execute_preset(
    client: Any,
    preset: dict[str, Any],
    company_ids: list[int] | None = None,
    company_id: int | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int | None = None,
    as_of_date: str | None = None,
) -> dict[str, Any]:
    """Execute a preset query and return structured results."""
    ids = company_ids or ([company_id] if company_id else [])

    if preset.get("engine") == "report":
        return _execute_report_preset(client, preset, ids, date_from, date_to, as_of_date)

    args = build_read_group_args(preset, ids, date_from, date_to, limit)
    raw = client.read_group(
        args["model"],
        args["domain"],
        args["fields"],
        args["groupby"],
        orderby=args.get("orderby"),
        limit=args.get("limit"),
        lazy=args.get("lazy", False),
    )

    measure = preset["measure"]
    rows = []
    total = 0.0
    for rec in raw:
        row: dict[str, Any] = {}
        for col in preset.get("output_columns", []):
            key = col["key"]
            if key == measure:
                val = float(rec.get(key) or 0)
                row[key] = val
                total += val
            else:
                row[key] = _format_m2o(rec.get(key))
        row["__count"] = rec.get("__count", 0)
        rows.append(row)

    return {
        "preset": preset.get("name", "unknown"),
        "rows": rows,
        "query_total": total,
        "row_count": len(rows),
        "company_ids": ids,
        "date_from": date_from,
        "date_to": date_to,
    }


def _execute_report_preset(
    client: Any,
    preset: dict[str, Any],
    company_ids: list[int],
    date_from: str | None,
    date_to: str | None,
    as_of_date: str | None = None,
) -> dict[str, Any]:
    """Execute a report-engine preset via compute_report_data."""
    from kctl_odoo.commands.report.mgmt_framework import (
        _default_date_range,
        _fiscal_year_start,
        _resolve_type_code,
    )

    type_code = _resolve_type_code(preset["report_type"])
    tpls = client.search_read(
        "report.template",
        [("report_type", "=", type_code)],
        ["id", "name"],
        limit=1,
        order="sequence, id",
    )
    if not tpls:
        return {
            "preset": preset.get("name"),
            "rows": [],
            "query_total": 0,
            "error": f"No template for {type_code}",
        }

    if as_of_date:
        resolved_from = _fiscal_year_start(as_of_date)
        resolved_to = as_of_date
    elif date_from and date_to:
        resolved_from, resolved_to = date_from, date_to
    else:
        resolved_from, resolved_to = _default_date_range()

    co_id = company_ids[0] if company_ids else 1
    rd = client.execute_kw(
        "report.report_base.engine",
        "compute_report_data",
        [
            [],
            {
                "template_id": tpls[0]["id"],
                "date_from": resolved_from,
                "date_to": resolved_to,
                "company_id": co_id,
                "company_ids": company_ids,
                "target_move": "posted",
                "divider": 1,
                "show_variance": False,
                "show_percentage": True,
                "monthly_breakdown": False,
                "expanded_line_ids": [],
                "page_offset": 0,
                "page_limit": 0,
            },
        ],
        {"context": {"allowed_company_ids": company_ids or [co_id]}},
    )

    rows = []
    total = 0.0
    for t in rd.get("tables") or []:
        for r in t.get("rows") or []:
            if not isinstance(r, dict):
                continue
            values = r.get("values", {})
            amt = float(values.get("actual") or values.get("amount") or 0)
            rows.append(
                {
                    "label": r.get("label", r.get("name", "")),
                    "kind": r.get("kind", "line"),
                    "level": r.get("level", 0),
                    "amount": amt,
                    **{k: v for k, v in values.items() if k not in ("actual", "amount")},
                }
            )
            if r.get("kind") == "total" and r.get("level", 0) == 0:
                total = amt

    return {
        "preset": preset.get("name"),
        "report_name": rd.get("report_name", type_code),
        "company_name": rd.get("company_name", ""),
        "rows": rows,
        "query_total": total,
        "date_from": resolved_from,
        "date_to": resolved_to,
        "company_ids": company_ids,
    }


def render_markdown(result: dict[str, Any]) -> MarkdownReport:
    """Convert an analyze-run result dict to a MarkdownReport.

    Renders the rows as a monospace table (right-align numeric columns,
    thousands-separated values). If ``result["validation"]`` is present,
    appends a validation bullet.
    """
    from kctl_lib.markdown_report import MarkdownReport

    preset = result.get("preset", "report")
    date_from = result.get("date_from") or "?"
    date_to = result.get("date_to") or "?"
    period = f"{date_from} → {date_to}"
    title = preset.replace("-", " ").title() + f" — {period}"
    subtitle = f"{result.get('row_count', '?')} records analyzed"

    report = MarkdownReport(title=title, subtitle=subtitle)
    rows = result.get("rows", [])
    if rows:
        # First row's keys define the column set (preserves preset shape)
        headers = list(rows[0].keys())
        table_rows: list[list[str]] = []
        for r in rows:
            cells: list[str] = []
            for h in headers:
                val = r.get(h)
                if isinstance(val, (int, float)):
                    cells.append(f"{val:,.0f}")
                elif isinstance(val, str) and val.lstrip("-").isdigit():
                    # Numeric string (e.g. "45000000" from JSON-RPC) — format with separators
                    cells.append(f"{int(val):,.0f}")
                else:
                    cells.append(str(val) if val is not None else "")
            table_rows.append(cells)

        # A column is numeric if ANY row has a numeric value for it (int|float)
        # or a numeric string — not just the first row.
        def _col_is_numeric(h: str) -> bool:
            for r in rows:
                v = r.get(h)
                if isinstance(v, (int, float)):
                    return True
                if isinstance(v, str) and v.lstrip("-").isdigit():
                    return True
            return False

        align = ["right" if _col_is_numeric(h) else "left" for h in headers]
        report.add_table_monospace(
            headers=[h.upper() for h in headers],
            rows=table_rows,
            align=align,
        )
    if result.get("validation"):
        v = result["validation"]
        sym = "✓" if v.get("pass") else "✗"
        delta = v.get("delta_pct")
        delta_str = f"{delta:.2%}" if isinstance(delta, (int, float)) else str(delta or "?")
        report.add_bullet(f"Validated: {sym} (Δ {delta_str})")
    return report
