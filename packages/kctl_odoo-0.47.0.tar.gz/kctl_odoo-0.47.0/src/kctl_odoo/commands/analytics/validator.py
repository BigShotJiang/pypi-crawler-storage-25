"""Field validation + P&L/BS reconciliation for analytics presets."""

from __future__ import annotations

from typing import Any

from kctl_lib.exceptions import KctlError

NUMERIC_TYPES = {"float", "integer", "monetary"}


def validate_preset_fields(client: Any, preset: dict[str, Any]) -> list[str]:
    """Validate preset fields exist on the Odoo model. Returns error list."""
    errors: list[str] = []
    model = preset.get("model")
    if not model:
        return []

    try:
        fields = client.execute_kw(model, "fields_get", [], {"attributes": ["type"]})
    except (KctlError, OSError, ValueError, TypeError) as exc:
        return [f"Model '{model}' not accessible: {exc}"]

    measure = preset.get("measure", "")
    base_measure = measure.split(":")[0] if ":" in measure else measure
    if base_measure and base_measure not in fields:
        errors.append(f"Measure '{measure}' does not exist on {model}")
    elif base_measure and fields.get(base_measure, {}).get("type") not in NUMERIC_TYPES:
        ftype = fields.get(base_measure, {}).get("type", "unknown")
        errors.append(f"Measure '{measure}' is type '{ftype}', expected numeric")

    for gb in preset.get("group_by", []):
        base_gb = gb.split(":")[0] if ":" in gb else gb
        if "." in base_gb:
            base_gb = base_gb.split(".")[0]
        if base_gb not in fields:
            errors.append(f"Group-by field '{gb}' does not exist on {model}")

    return errors


def reconcile_with_report(
    client: Any,
    preset: dict[str, Any],
    query_total: float,
    company_ids: list[int],
    date_from: str | None,
    date_to: str | None,
) -> dict[str, Any]:
    """Cross-check query_total against a P&L/BS report line."""
    rec = preset.get("reconciles_with")
    if not rec:
        return {"skip": True, "reason": "No reconciles_with defined"}

    from kctl_odoo.commands.analytics.engine import execute_preset

    report_preset = {
        "name": f"_validation_{rec['report']}",
        "engine": "report",
        "report_type": rec["report"],
        "measure": "actual",
    }

    try:
        report_result = execute_preset(
            client, report_preset, company_ids=company_ids, date_from=date_from, date_to=date_to
        )
    except (KctlError, OSError, ValueError, TypeError) as exc:
        return {"skip": True, "reason": f"Report query failed: {exc}"}

    line_code = rec.get("line_code", "__total__")
    tolerance = rec.get("tolerance_pct", 1.0)

    report_total = report_result.get("query_total", 0)
    if line_code != "__total__":
        for row in report_result.get("rows", []):
            label = (row.get("label") or "").lower().replace(" ", "_")
            if line_code.lower() in label:
                report_total = abs(float(row.get("amount", 0)))
                break

    delta = abs(query_total - report_total)
    delta_pct = (delta / abs(report_total) * 100) if report_total else 0.0
    passed = delta_pct <= tolerance

    return {
        "report": rec["report"],
        "line": line_code,
        "report_total": report_total,
        "query_total": query_total,
        "delta": delta,
        "delta_pct": round(delta_pct, 2),
        "pass": passed,
    }
