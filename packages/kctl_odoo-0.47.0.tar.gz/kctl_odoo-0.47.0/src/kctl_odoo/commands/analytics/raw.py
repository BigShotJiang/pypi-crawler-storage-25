"""Raw analytics mode — escape hatch with guardrails."""

from __future__ import annotations

import json
import sys
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext

from .engine import execute_preset
from .validator import validate_preset_fields

app = typer.Typer(help="Raw analytics query (requires --confirm).")


@app.command("query")
def raw_query(
    ctx: typer.Context,
    model: Annotated[str, typer.Option("--model", help="Odoo model name (e.g. sale.order.line)")],
    measure: Annotated[str, typer.Option("--measure", help="Field to aggregate (e.g. price_subtotal)")],
    group_by: Annotated[str, typer.Option("--group-by", help="Group-by fields, comma-separated")],
    domain: Annotated[str, typer.Option("--domain", help="JSON domain filter")] = "[]",
    aggregator: Annotated[str, typer.Option("--aggregator", help="sum | avg | count")] = "sum",
    limit: Annotated[int, typer.Option("--limit", "-n")] = 20,
    company: Annotated[int | None, typer.Option("--company")] = None,
    company_ids: Annotated[str | None, typer.Option("--company-ids")] = None,
    date_from: Annotated[str | None, typer.Option("--date-from")] = None,
    date_to: Annotated[str | None, typer.Option("--date-to")] = None,
    confirm: Annotated[bool, typer.Option("--confirm", help="Required for raw queries")] = False,
) -> None:
    """Execute a raw read_group query against any Odoo model.

    Requires --confirm flag for quality assurance.

    Examples:
        kctl-odoo analyze raw query --model sale.order.line \\
          --measure price_subtotal --group-by product_id --confirm --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not confirm and sys.stdin.isatty():
        out.error("Raw mode requires --confirm flag for quality assurance. Use presets for validated queries.")
        raise typer.Exit(1)

    try:
        parsed_domain = json.loads(domain) if isinstance(domain, str) else domain
    except json.JSONDecodeError as e:
        out.error(f"Invalid domain JSON: {e}")
        raise typer.Exit(1) from e

    group_by_list = [g.strip() for g in group_by.split(",") if g.strip()]
    co_ids = [int(x.strip()) for x in company_ids.split(",") if x.strip()] if company_ids else None

    preset = {
        "name": f"raw:{model}",
        "description": f"Raw query on {model}",
        "model": model,
        "measure": measure,
        "aggregator": aggregator,
        "group_by": group_by_list,
        "domain_template": parsed_domain,
        "default_limit": limit,
        "output_columns": [{"key": g, "header": g, "type": "string"} for g in group_by_list]
        + [{"key": measure, "header": measure, "type": "amount"}],
    }

    errors = validate_preset_fields(c, preset)
    if errors:
        for e in errors:
            out.error(e)
        raise typer.Exit(1)

    result = execute_preset(
        c, preset, company_ids=co_ids, company_id=company, date_from=date_from, date_to=date_to, limit=limit
    )

    if actx.json_mode:
        out.raw_json(result)
    else:
        rows = result.get("rows", [])
        if not rows:
            out.info("No data returned.")
            return
        columns = list(rows[0].keys())
        table_rows = [[str(r.get(col, "")) for col in columns] for r in rows[:50]]
        out.table(columns, table_rows, title=f"Raw: {model} ({len(rows)} rows)")
        out.info(f"Total: {result.get('query_total', 0):,.2f}")
