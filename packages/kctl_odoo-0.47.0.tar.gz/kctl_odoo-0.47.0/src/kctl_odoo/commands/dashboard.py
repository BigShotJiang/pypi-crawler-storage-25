"""Dashboard command — comprehensive overview of the Odoo instance."""

from __future__ import annotations

import asyncio
import time
from datetime import UTC, datetime, timedelta
from typing import Annotated

import typer
from kctl_lib import fmt_money

from kctl_odoo.core.async_helpers import async_command
from kctl_odoo.core.biz_helpers import model_available, module_hint
from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

app = typer.Typer(help="Instance dashboard and overview.")


def _safe_count(client, model: str, domain: list | None = None) -> int | None:
    """Search count that returns None if model doesn't exist."""
    try:
        return client.search_count(model, domain or [])
    except RPCError:
        return None


async def _async_safe_count(client, model: str, domain: list | None = None) -> int | None:
    """Async version: search count that returns None if model doesn't exist."""
    try:
        return await client.search_count(model, domain or [])
    except RPCError:
        return None


async def _build_summary(c: object) -> dict:
    """Gather all dashboard data and return the json_data dict.

    This is the data-fetch seam for tests — mock this function to avoid live RPC calls.

    Returns a dict with keys: server, modules, users, mail (optional), crons,
    queue_jobs (optional), storage (optional), business (optional), alerts.
    """
    import asyncio as _asyncio

    json_data: dict = {}

    # ── Server & Health ──
    start = time.monotonic()
    ver_info = await c.version_info()  # type: ignore[attr-defined]
    rpc_ms = round((time.monotonic() - start) * 1000)
    uid = await c.ensure_uid()  # type: ignore[attr-defined]

    users = await c.read("res.users", [uid], ["login", "name", "company_id"])  # type: ignore[attr-defined]
    current_user = users[0] if users else {}
    company = current_user.get("company_id")
    company_name = company[1] if isinstance(company, list) else str(company or "")

    json_data["server"] = {
        "version": ver_info.get("server_version"),
        "database": c.database,  # type: ignore[attr-defined]
        "rpc_latency_ms": rpc_ms,
        "uid": uid,
        "user": current_user.get("login"),
        "user_name": current_user.get("name", ""),
        "company": company_name,
    }

    # ── Gather all counts in parallel ──
    cutoff_48h = (datetime.now(tz=UTC) - timedelta(hours=48)).strftime("%Y-%m-%d %H:%M:%S")
    (
        installed,
        to_upgrade,
        to_install,
        to_remove,
        all_installed,
        active_users,
        portal_users,
        partners,
        companies,
        cron_total,
        cron_active,
        cron_stale,
        mail_outgoing,
        mail_exception,
        jobs_pending,
        attachment_count,
        sale_count,
        invoice_count,
        product_count,
        picking_count,
        mo_count,
        employee_count,
    ) = await _asyncio.gather(
        c.search_count("ir.module.module", [("state", "=", "installed")]),  # type: ignore[attr-defined]
        c.search_count("ir.module.module", [("state", "=", "to upgrade")]),  # type: ignore[attr-defined]
        c.search_count("ir.module.module", [("state", "=", "to install")]),  # type: ignore[attr-defined]
        c.search_count("ir.module.module", [("state", "=", "to remove")]),  # type: ignore[attr-defined]
        c.search_read("ir.module.module", [("state", "=", "installed")], ["name", "author"], limit=0),  # type: ignore[attr-defined]
        c.search_count("res.users", [("active", "=", True), ("share", "=", False)]),  # type: ignore[attr-defined]
        c.search_count("res.users", [("active", "=", True), ("share", "=", True)]),  # type: ignore[attr-defined]
        c.search_count("res.partner", [("active", "=", True)]),  # type: ignore[attr-defined]
        c.search_count("res.company", []),  # type: ignore[attr-defined]
        c.search_count("ir.cron", []),  # type: ignore[attr-defined]
        c.search_count("ir.cron", [("active", "=", True)]),  # type: ignore[attr-defined]
        c.search_count("ir.cron", [("active", "=", True), ("lastcall", "<", cutoff_48h)]),  # type: ignore[attr-defined]
        _async_safe_count(c, "mail.mail", [("state", "=", "outgoing")]),
        _async_safe_count(c, "mail.mail", [("state", "=", "exception")]),
        _async_safe_count(c, "queue.job", [("state", "=", "pending")]),
        _async_safe_count(c, "ir.attachment", []),
        _async_safe_count(c, "sale.order", [("state", "=", "sale")]),
        _async_safe_count(c, "account.move", [("move_type", "=", "out_invoice"), ("state", "=", "posted")]),
        _async_safe_count(c, "product.product", [("active", "=", True)]),
        _async_safe_count(c, "stock.picking", [("state", "in", ["assigned", "waiting"])]),
        _async_safe_count(c, "mrp.production", [("state", "in", ["confirmed", "progress"])]),
        _async_safe_count(c, "hr.employee", [("active", "=", True)]),
    )

    broken_total = to_upgrade + to_install + to_remove

    # Count private vs OCA vs core
    private_count = 0
    oca_count = 0
    for m in all_installed:
        author = (m.get("author") or "").lower()
        if "kodemeio" in author or "kodeme" in author:
            private_count += 1
        elif "oca" in author or "odoo community" in author:
            oca_count += 1
    core_count = installed - private_count - oca_count

    json_data["modules"] = {
        "installed": installed,
        "core": core_count,
        "oca": oca_count,
        "private": private_count,
        "to_upgrade": to_upgrade,
        "to_install": to_install,
        "to_remove": to_remove,
        "broken_total": broken_total,
    }

    json_data["users"] = {
        "internal": active_users,
        "portal": portal_users,
        "partners": partners,
        "companies": companies,
    }

    if mail_outgoing is not None:
        json_data["mail"] = {"outgoing": mail_outgoing, "exception": mail_exception}

    json_data["crons"] = {"total": cron_total, "active": cron_active, "stale": cron_stale}

    # ── Queue Jobs (if installed) ──
    jobs_failed: int = 0
    jobs_started: int = 0
    if jobs_pending is not None:
        jobs_failed_raw, jobs_started_raw = await _asyncio.gather(
            _async_safe_count(c, "queue.job", [("state", "=", "failed")]),
            _async_safe_count(c, "queue.job", [("state", "=", "started")]),
        )
        jobs_failed = jobs_failed_raw or 0
        jobs_started = jobs_started_raw or 0
        json_data["queue_jobs"] = {"pending": jobs_pending, "started": jobs_started, "failed": jobs_failed}

    if attachment_count is not None:
        json_data["storage"] = {"attachments": attachment_count}

    # ── Business Pulse ──
    biz_json: dict = {}
    if sale_count is not None:
        biz_json["confirmed_sales"] = sale_count
    if invoice_count is not None:
        biz_json["posted_invoices"] = invoice_count
    if product_count is not None:
        biz_json["active_products"] = product_count
    if picking_count is not None:
        biz_json["pending_transfers"] = picking_count
    if mo_count is not None:
        biz_json["active_mos"] = mo_count
    if employee_count is not None:
        biz_json["employees"] = employee_count
    if biz_json:
        json_data["business"] = biz_json

    # ── Alerts ──
    alert_json: list[str] = []
    if broken_total:
        alert_json.append(f"{broken_total} modules pending")
    if mail_exception and mail_exception > 0:
        alert_json.append(f"{mail_exception} failed emails")
    if cron_stale:
        alert_json.append(f"{cron_stale} stale crons")
    if jobs_pending is not None and jobs_failed:
        alert_json.append(f"{jobs_failed} failed jobs")
    json_data["alerts"] = alert_json

    return json_data


@app.command("summary")
@async_command
async def info(
    ctx: typer.Context,
    watch: Annotated[bool, typer.Option("--watch", "-w", help="Continuously refresh the dashboard")] = False,
    interval: Annotated[int, typer.Option("--interval", "-i", help="Watch interval in seconds")] = 30,
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: pretty, json, or markdown")] = "pretty",
) -> None:
    """Show comprehensive Odoo instance overview.

    Displays server health, module status, mail queue, cron health,
    queue jobs, storage, and business pulse in a single view.

    Examples:
        kctl-odoo dashboard info
        kctl-odoo --profile production dashboard info
        kctl-odoo dashboard info --json
        kctl-odoo dashboard info --watch
        kctl-odoo dashboard info --watch --interval 60
        kctl-odoo dashboard summary --format markdown
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.async_client
    await c.authenticate()

    async def _run_once() -> None:
        data = await _build_summary(c)

        if actx.json_mode:
            out.detail("Odoo Dashboard", [], data_for_json=data)
            return

        if fmt == "markdown":
            from kctl_lib.markdown_report import MarkdownReport

            report = MarkdownReport(
                title="Executive Summary",
                subtitle=datetime.now(tz=UTC).strftime("%Y-%m-%d"),
            )

            # ── SERVER section ──
            srv = data.get("server", {})
            report.add_section("SERVER")
            _user_login = srv.get("user", "")
            _user_name = srv.get("user_name", "")
            _user_display = f"{_user_name} ({_user_login})" if _user_name else _user_login
            report.add_table_monospace(
                headers=["", ""],
                rows=[
                    ["Version", str(srv.get("version", "?"))],
                    ["Database", str(srv.get("database", "?"))],
                    ["RPC Latency", f"{srv.get('rpc_latency_ms', '?')}ms"],
                    ["User", _user_display],
                    ["Company", str(srv.get("company", "?"))],
                ],
                align=["left", "left"],
            )

            # ── MODULES section ──
            mods = data.get("modules", {})
            report.add_section("MODULES")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Installed", fmt_money(mods.get("installed"))],
                    [
                        "Core / OCA / Private",
                        f"{mods.get('core', 0)} / {mods.get('oca', 0)} / {mods.get('private', 0)}",
                    ],
                    ["Pending upgrade", fmt_money(mods.get("to_upgrade"))],
                ],
                align=["left", "right"],
            )

            # ── USERS section ──
            usr = data.get("users", {})
            report.add_section("USERS")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Internal users", fmt_money(usr.get("internal"))],
                    ["Portal users", fmt_money(usr.get("portal"))],
                    ["Active partners", fmt_money(usr.get("partners"))],
                ],
                align=["left", "right"],
            )

            # ── OPERATIONS section (mail + crons + queue) ──
            report.add_section("OPERATIONS")
            ops_rows = []
            if "mail" in data:
                ops_rows.append(["Mail outgoing", fmt_money(data["mail"].get("outgoing"))])
                ops_rows.append(["Mail failed", fmt_money(data["mail"].get("exception"))])
            crons = data.get("crons", {})
            ops_rows.append(["Crons active/total", f"{crons.get('active', 0)} / {crons.get('total', 0)}"])
            ops_rows.append(["Crons stale (>48h)", fmt_money(crons.get("stale"))])
            if "queue_jobs" in data:
                qj = data["queue_jobs"]
                ops_rows.append(["Queue jobs pending", fmt_money(qj.get("pending"))])
                ops_rows.append(["Queue jobs failed", fmt_money(qj.get("failed"))])
            if ops_rows:
                report.add_table_monospace(headers=["", "VALUE"], rows=ops_rows, align=["left", "right"])

            # ── BUSINESS section ──
            biz = data.get("business", {})
            if biz:
                report.add_section("BUSINESS")
                biz_rows = []
                if "confirmed_sales" in biz:
                    biz_rows.append(["Confirmed sales", fmt_money(biz["confirmed_sales"])])
                if "posted_invoices" in biz:
                    biz_rows.append(["Posted invoices", fmt_money(biz["posted_invoices"])])
                if "active_products" in biz:
                    biz_rows.append(["Active products", fmt_money(biz["active_products"])])
                if "pending_transfers" in biz:
                    biz_rows.append(["Pending transfers", fmt_money(biz["pending_transfers"])])
                if "active_mos" in biz:
                    biz_rows.append(["Active MOs", fmt_money(biz["active_mos"])])
                if "employees" in biz:
                    biz_rows.append(["Employees", fmt_money(biz["employees"])])
                if biz_rows:
                    report.add_table_monospace(headers=["", "VALUE"], rows=biz_rows, align=["left", "right"])

            # ── ALERTS section ──
            alerts = data.get("alerts", [])
            if alerts:
                report.add_section("ALERTS")
                report.add_bullets(alerts)

            out.markdown_report(report)
            return

        # ── Pretty output — rebuild sections from data ──
        sections: list[tuple[str, list[tuple[str, str]]]] = []
        srv = data.get("server", {})
        rpc_ms = srv.get("rpc_latency_ms", 0)
        rpc_color = "green" if rpc_ms < 500 else "yellow" if rpc_ms < 2000 else "red"
        sections.append(
            (
                "Server",
                [
                    ("Version", srv.get("version", "unknown")),
                    ("Database", str(srv.get("database", ""))),
                    ("RPC Latency", f"[{rpc_color}]{rpc_ms}ms[/{rpc_color}]"),
                    (
                        "User",
                        f"{srv.get('user_name', '')} ({srv.get('user', '')})"
                        if srv.get("user_name")
                        else str(srv.get("user", "")),
                    ),
                    ("Company", str(srv.get("company", ""))),
                ],
            )
        )

        mods = data.get("modules", {})
        broken_total = mods.get("broken_total", 0)
        installed = mods.get("installed", 0)
        to_upgrade = mods.get("to_upgrade", 0)
        module_status = f"[green]{installed}[/green]"
        if broken_total:
            module_status += f" [red](+{broken_total} pending)[/red]"
        sections.append(
            (
                "Modules",
                [
                    ("Installed", module_status),
                    ("Core/OCA/Private", f"{mods.get('core', 0)} / {mods.get('oca', 0)} / {mods.get('private', 0)}"),
                    (
                        "Pending Upgrade",
                        f"[{'red' if to_upgrade else 'green'}]{to_upgrade}[/{'red' if to_upgrade else 'green'}]",
                    ),
                    ("Pending Install", str(mods.get("to_install", 0))),
                    ("Pending Remove", str(mods.get("to_remove", 0))),
                ],
            )
        )

        usr = data.get("users", {})
        sections.append(
            (
                "Users & Partners",
                [
                    ("Internal Users", str(usr.get("internal", 0))),
                    ("Portal Users", str(usr.get("portal", 0))),
                    ("Active Partners", str(usr.get("partners", 0))),
                    ("Companies", str(usr.get("companies", 0))),
                ],
            )
        )

        if "mail" in data:
            mail = data["mail"]
            exception_count = mail.get("exception", 0)
            exception_color = "red" if exception_count else "green"
            sections.append(
                (
                    "Mail Queue",
                    [
                        ("Outgoing", str(mail.get("outgoing", 0))),
                        ("Failed", f"[{exception_color}]{exception_count}[/{exception_color}]"),
                    ],
                )
            )

        crons = data.get("crons", {})
        stale = crons.get("stale", 0)
        stale_color = "red" if stale else "green"
        sections.append(
            (
                "Cron Jobs",
                [
                    ("Active / Total", f"{crons.get('active', 0)} / {crons.get('total', 0)}"),
                    ("Stale (>48h)", f"[{stale_color}]{stale}[/{stale_color}]"),
                ],
            )
        )

        if "queue_jobs" in data:
            qj = data["queue_jobs"]
            failed = qj.get("failed", 0)
            failed_color = "red" if failed else "green"
            sections.append(
                (
                    "Queue Jobs",
                    [
                        ("Pending", str(qj.get("pending", 0))),
                        ("Running", str(qj.get("started", 0))),
                        ("Failed", f"[{failed_color}]{failed}[/{failed_color}]"),
                    ],
                )
            )

        if "storage" in data:
            sections.append(
                (
                    "Storage",
                    [("Attachments", f"{data['storage'].get('attachments', 0):,}")],
                )
            )

        biz = data.get("business", {})
        biz_items: list[tuple[str, str]] = []
        if "confirmed_sales" in biz:
            biz_items.append(("Confirmed Sales", f"{biz['confirmed_sales']:,}"))
        if "posted_invoices" in biz:
            biz_items.append(("Posted Invoices", f"{biz['posted_invoices']:,}"))
        if "active_products" in biz:
            biz_items.append(("Active Products", f"{biz['active_products']:,}"))
        if "pending_transfers" in biz:
            biz_items.append(("Pending Transfers", f"{biz['pending_transfers']:,}"))
        if "active_mos" in biz:
            biz_items.append(("Active MOs", f"{biz['active_mos']:,}"))
        if "employees" in biz:
            biz_items.append(("Employees", f"{biz['employees']:,}"))
        if biz_items:
            sections.append(("Business Pulse", biz_items))

        alert_list = data.get("alerts", [])
        if alert_list:
            alert_rich = [(f"[red]{a}[/red]", "") for a in alert_list]
            sections.append(("Alerts", alert_rich))
        else:
            sections.append(("Status", [("Health", "[green]All systems healthy[/green]")]))

        out.detail("Odoo Dashboard", sections, data_for_json=data)

    await _run_once()

    if watch:
        try:
            while True:
                await asyncio.sleep(interval)
                out.header(f"Dashboard at {time.strftime('%H:%M:%S')}")
                await _run_once()
        except KeyboardInterrupt:
            out.info("Stopped watching")


# ===================================================================
# DAILY DIGEST
# ===================================================================


def _build_digest(c: object) -> dict:
    """Gather all daily digest data and return the json_data dict.

    This is the data-fetch seam for tests — mock this function to avoid live RPC calls.

    Returns a dict with optional keys: sales, inventory, receivables, mail, crons,
    queue_jobs, and always: alerts (list of str).
    """
    json_data: dict = {}
    now = datetime.now(tz=UTC)
    today_str = now.strftime("%Y-%m-%d 00:00:00")

    # -- Sales Today --
    if model_available(c, "sale.order"):  # type: ignore[arg-type]
        confirmed_today = c.search_count(  # type: ignore[attr-defined]
            "sale.order",
            [("state", "=", "sale"), ("date_order", ">=", today_str)],
        )
        draft_count = c.search_count("sale.order", [("state", "=", "draft")])  # type: ignore[attr-defined]
        json_data["sales"] = {"confirmed_today": confirmed_today, "draft": draft_count}

    # -- Pending Transfers --
    if model_available(c, "stock.picking"):  # type: ignore[arg-type]
        pending_transfers = c.search_count(  # type: ignore[attr-defined]
            "stock.picking", [("state", "in", ["assigned", "waiting", "confirmed"])]
        )
        late_transfers = c.search_count(  # type: ignore[attr-defined]
            "stock.picking",
            [
                ("state", "in", ["assigned", "waiting", "confirmed"]),
                ("scheduled_date", "<", now.strftime("%Y-%m-%d %H:%M:%S")),
            ],
        )
        json_data["inventory"] = {"pending_transfers": pending_transfers, "late_transfers": late_transfers}

    # -- Overdue AR --
    if model_available(c, "account.move"):  # type: ignore[arg-type]
        overdue_inv_count = c.search_count(  # type: ignore[attr-defined]
            "account.move",
            [
                ("move_type", "=", "out_invoice"),
                ("state", "=", "posted"),
                ("payment_state", "in", ["not_paid", "partial"]),
                ("invoice_date_due", "<", now.strftime("%Y-%m-%d")),
            ],
        )
        json_data["receivables"] = {"overdue_invoices": overdue_inv_count}

    # -- Failed Mail --
    try:
        mail_exception = c.search_count("mail.mail", [("state", "=", "exception")])  # type: ignore[attr-defined]
        mail_outgoing = c.search_count("mail.mail", [("state", "=", "outgoing")])  # type: ignore[attr-defined]
        json_data["mail"] = {"outgoing": mail_outgoing, "exception": mail_exception}
    except RPCError:
        pass

    # -- Stale Crons --
    cutoff_48h = (now - timedelta(hours=48)).strftime("%Y-%m-%d %H:%M:%S")
    try:
        stale_crons = c.search_count(  # type: ignore[attr-defined]
            "ir.cron", [("active", "=", True), ("lastcall", "<", cutoff_48h)]
        )
        json_data["crons"] = {"stale": stale_crons}
    except RPCError:
        pass

    # -- Failed Queue Jobs --
    try:
        failed_jobs = c.search_count("queue.job", [("state", "=", "failed")])  # type: ignore[attr-defined]
        pending_jobs = c.search_count("queue.job", [("state", "=", "pending")])  # type: ignore[attr-defined]
        json_data["queue_jobs"] = {"pending": pending_jobs, "failed": failed_jobs}
    except RPCError:
        pass

    # -- Build alerts list --
    alerts: list[str] = []
    if json_data.get("mail", {}).get("exception", 0) > 0:
        alerts.append(f"{json_data['mail']['exception']} failed email(s)")
    if json_data.get("crons", {}).get("stale", 0) > 0:
        alerts.append(f"{json_data['crons']['stale']} stale cron(s)")
    if json_data.get("queue_jobs", {}).get("failed", 0) > 0:
        alerts.append(f"{json_data['queue_jobs']['failed']} failed queue job(s)")
    if json_data.get("receivables", {}).get("overdue_invoices", 0) > 0:
        alerts.append(f"{json_data['receivables']['overdue_invoices']} overdue invoice(s)")
    if json_data.get("inventory", {}).get("late_transfers", 0) > 0:
        alerts.append(f"{json_data['inventory']['late_transfers']} late transfer(s)")
    json_data["alerts"] = alerts

    return json_data


@app.command("digest")
def daily_digest(
    ctx: typer.Context,
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: pretty, json, or markdown")] = "pretty",
) -> None:
    """Morning coffee command — key business metrics at a glance.

    Combines: sales confirmed today, pending transfers, overdue AR,
    failed mail, stale crons, and failed queue jobs into one view.

    Examples:
        kctl-odoo dashboard digest
        kctl-odoo dashboard digest --json
        kctl-odoo --profile production dashboard digest
        kctl-odoo dashboard digest --format markdown
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    json_data = _build_digest(c)
    alerts = json_data.get("alerts", [])

    if actx.json_mode:
        out.detail("Daily Digest", [], data_for_json=json_data)
        return

    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport

        report = MarkdownReport(title="Daily Digest")

        # Sales section
        if "sales" in json_data:
            s = json_data["sales"]
            report.add_section("SALES")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Confirmed today", fmt_money(s.get("confirmed_today"))],
                    ["Draft quotations", fmt_money(s.get("draft"))],
                ],
                align=["left", "right"],
            )

        # Inventory section
        if "inventory" in json_data:
            inv = json_data["inventory"]
            report.add_section("INVENTORY")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Pending transfers", fmt_money(inv.get("pending_transfers"))],
                    ["Late transfers", fmt_money(inv.get("late_transfers"))],
                ],
                align=["left", "right"],
            )

        # Receivables section
        if "receivables" in json_data:
            rec = json_data["receivables"]
            report.add_section("RECEIVABLES")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[["Overdue invoices", fmt_money(rec.get("overdue_invoices"))]],
                align=["left", "right"],
            )

        # Mail section
        if "mail" in json_data:
            mail = json_data["mail"]
            report.add_section("MAIL")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Outgoing", fmt_money(mail.get("outgoing"))],
                    ["Failed", fmt_money(mail.get("exception"))],
                ],
                align=["left", "right"],
            )

        # Crons section
        if "crons" in json_data:
            crons = json_data["crons"]
            report.add_section("CRONS")
            report.add_kv("Stale (>48h)", fmt_money(crons.get("stale")))

        # Queue jobs section
        if "queue_jobs" in json_data:
            qj = json_data["queue_jobs"]
            report.add_section("QUEUE JOBS")
            report.add_table_monospace(
                headers=["", "VALUE"],
                rows=[
                    ["Pending", fmt_money(qj.get("pending"))],
                    ["Failed", fmt_money(qj.get("failed"))],
                ],
                align=["left", "right"],
            )

        # Attention / alerts
        if alerts:
            report.add_section("ATTENTION")
            report.add_bullets(alerts)

        out.markdown_report(report)
        return

    # ── Pretty output ──
    sections: list[tuple[str, list[tuple[str, str]]]] = []

    if "sales" in json_data:
        s = json_data["sales"]
        sections.append(
            (
                "Sales",
                [
                    ("Confirmed Today", str(s.get("confirmed_today", 0))),
                    ("Draft Quotations", str(s.get("draft", 0))),
                ],
            )
        )
    else:
        out.info("sale module not installed, skipping sales.")

    if "inventory" in json_data:
        inv = json_data["inventory"]
        late = inv.get("late_transfers", 0)
        late_color = "red" if late else "green"
        sections.append(
            (
                "Inventory",
                [
                    ("Pending Transfers", str(inv.get("pending_transfers", 0))),
                    ("Late Transfers", f"[{late_color}]{late}[/{late_color}]"),
                ],
            )
        )

    if "receivables" in json_data:
        rec = json_data["receivables"]
        overdue = rec.get("overdue_invoices", 0)
        overdue_color = "red" if overdue else "green"
        sections.append(
            (
                "Receivables",
                [("Overdue Invoices", f"[{overdue_color}]{overdue}[/{overdue_color}]")],
            )
        )

    if "mail" in json_data:
        mail = json_data["mail"]
        exc = mail.get("exception", 0)
        exc_color = "red" if exc else "green"
        sections.append(
            (
                "Mail",
                [
                    ("Outgoing", str(mail.get("outgoing", 0))),
                    ("Failed", f"[{exc_color}]{exc}[/{exc_color}]"),
                ],
            )
        )

    if "crons" in json_data:
        stale = json_data["crons"].get("stale", 0)
        stale_color = "red" if stale else "green"
        sections.append(
            (
                "Cron Jobs",
                [("Stale (>48h)", f"[{stale_color}]{stale}[/{stale_color}]")],
            )
        )

    if "queue_jobs" in json_data:
        qj = json_data["queue_jobs"]
        failed = qj.get("failed", 0)
        failed_color = "red" if failed else "green"
        sections.append(
            (
                "Queue Jobs",
                [
                    ("Pending", str(qj.get("pending", 0))),
                    ("Failed", f"[{failed_color}]{failed}[/{failed_color}]"),
                ],
            )
        )

    if alerts:
        alert_lines = [(f"[red]{a}[/red]", "") for a in alerts]
        sections.append(("Attention Required", alert_lines))
    else:
        sections.append(("Status", [("Health", "[green]All clear[/green]")]))

    out.detail("Daily Digest", sections, data_for_json=json_data)


# ===================================================================
# KPI SCORECARD
# ===================================================================


@app.command("kpi")
def kpi(ctx: typer.Context) -> None:
    """Business KPI scorecard with pass/warn/fail thresholds.

    Default KPIs:
    - Order fulfillment rate (confirmed SO with done picking / total confirmed SO)
    - AR aging (receivable > 30 days / total receivable)
    - Email health (failure rate in last 24h)
    - Data quality (products with internal_ref / total products)

    Examples:
        kctl-odoo dashboard kpi
        kctl-odoo dashboard kpi --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rows: list[list[str]] = []
    json_data: list[dict] = []

    def _add_kpi(
        name: str,
        value: float,
        unit: str,
        threshold_warn: float,
        threshold_fail: float,
        higher_is_better: bool = True,
    ) -> None:
        if higher_is_better:
            if value >= threshold_warn:
                status = "[green]PASS[/green]"
                status_raw = "PASS"
            elif value >= threshold_fail:
                status = "[yellow]WARN[/yellow]"
                status_raw = "WARN"
            else:
                status = "[red]FAIL[/red]"
                status_raw = "FAIL"
        else:
            if value <= threshold_warn:
                status = "[green]PASS[/green]"
                status_raw = "PASS"
            elif value <= threshold_fail:
                status = "[yellow]WARN[/yellow]"
                status_raw = "WARN"
            else:
                status = "[red]FAIL[/red]"
                status_raw = "FAIL"

        threshold_str = f"warn={threshold_warn}{unit} fail={threshold_fail}{unit}"
        rows.append([name, f"{value:.1f}{unit}", threshold_str, status])
        json_data.append(
            {
                "kpi": name,
                "value": round(value, 1),
                "unit": unit,
                "threshold_warn": threshold_warn,
                "threshold_fail": threshold_fail,
                "status": status_raw,
            }
        )

    # 1. Order Fulfillment Rate
    if model_available(c, "sale.order") and model_available(c, "stock.picking"):
        confirmed_so = c.search_count("sale.order", [("state", "=", "sale")])
        if confirmed_so > 0:
            so_with_done = c.search_count(
                "sale.order",
                [("state", "=", "sale"), ("picking_ids.state", "=", "done")],
            )
            fulfillment = (so_with_done / confirmed_so) * 100
        else:
            fulfillment = 100.0
        _add_kpi("Order Fulfillment", fulfillment, "%", 80.0, 60.0, higher_is_better=True)

    # 2. AR Aging (receivable >30 days / total receivable)
    if model_available(c, "account.move"):
        now = datetime.now(tz=UTC)
        cutoff_30d = (now - timedelta(days=30)).strftime("%Y-%m-%d")
        total_receivable = c.search_count(
            "account.move",
            [
                ("move_type", "=", "out_invoice"),
                ("state", "=", "posted"),
                ("payment_state", "in", ["not_paid", "partial"]),
            ],
        )
        if total_receivable > 0:
            overdue_receivable = c.search_count(
                "account.move",
                [
                    ("move_type", "=", "out_invoice"),
                    ("state", "=", "posted"),
                    ("payment_state", "in", ["not_paid", "partial"]),
                    ("invoice_date_due", "<", cutoff_30d),
                ],
            )
            ar_aging = (overdue_receivable / total_receivable) * 100
        else:
            ar_aging = 0.0
        _add_kpi("AR Aging (>30d)", ar_aging, "%", 20.0, 40.0, higher_is_better=False)

    # 3. Email Health (failure rate in last 24h)
    try:
        now = datetime.now(tz=UTC)
        cutoff_24h = (now - timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
        total_mail = c.search_count("mail.mail", [("create_date", ">=", cutoff_24h)])
        if total_mail > 0:
            failed_mail = c.search_count("mail.mail", [("create_date", ">=", cutoff_24h), ("state", "=", "exception")])
            failure_rate = (failed_mail / total_mail) * 100
        else:
            failure_rate = 0.0
        _add_kpi("Email Failure Rate", failure_rate, "%", 5.0, 15.0, higher_is_better=False)
    except RPCError:
        pass

    # 4. Data Quality (products with internal_ref / total products)
    if model_available(c, "product.template"):
        total_products = c.search_count("product.template", [("sale_ok", "=", True)])
        if total_products > 0:
            with_ref = c.search_count(
                "product.template",
                [("sale_ok", "=", True), ("default_code", "!=", False), ("default_code", "!=", "")],
            )
            data_quality = (with_ref / total_products) * 100
        else:
            data_quality = 100.0
        _add_kpi("Product Data Quality", data_quality, "%", 80.0, 60.0, higher_is_better=True)

    if not rows:
        out.info("No KPI data available. Check that relevant modules are installed.")
        return

    # Calculate overall score
    pass_count = sum(1 for d in json_data if d["status"] == "PASS")
    total_count = len(json_data)
    score = (pass_count / total_count) * 100 if total_count else 0

    score_color = "green" if score >= 75 else "yellow" if score >= 50 else "red"
    title = f"Business KPIs — [{score_color}]{score:.0f}% healthy[/{score_color}] ({pass_count}/{total_count} pass)"

    out.table(
        title,
        [("KPI", ""), ("Value", "cyan"), ("Threshold", "dim"), ("Status", "")],
        rows,
        data_for_json=json_data,
    )


# ===================================================================
# PENDING APPROVALS
# ===================================================================


@app.command("pending-approvals")
def pending_approvals(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 50,
) -> None:
    """Records awaiting approval across modules."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rows: list[list[str]] = []
    json_data: list[dict] = []

    # Purchase orders to approve
    if model_available(c, "purchase.order"):
        pos = c.search_read(
            "purchase.order",
            domain=[("state", "=", "to approve")],
            fields=["name", "partner_id", "create_date", "amount_total"],
            limit=limit,
        )
        for po in pos:
            partner = po.get("partner_id")
            partner_name = partner[1] if isinstance(partner, list) else str(partner or "-")
            rows.append(["Purchase Order", po.get("name", ""), partner_name, str(po.get("create_date", ""))[:10]])
            json_data.append(
                {
                    "type": "purchase.order",
                    "reference": po.get("name"),
                    "requestor": partner_name,
                    "date": str(po.get("create_date", ""))[:10],
                    "amount": po.get("amount_total"),
                }
            )

    # Leave requests to approve
    if model_available(c, "hr.leave"):
        leaves = c.search_read(
            "hr.leave",
            domain=[("state", "=", "confirm")],
            fields=["display_name", "employee_id", "create_date"],
            limit=limit,
        )
        for lv in leaves:
            emp = lv.get("employee_id")
            emp_name = emp[1] if isinstance(emp, list) else str(emp or "-")
            rows.append(["Leave Request", lv.get("display_name", ""), emp_name, str(lv.get("create_date", ""))[:10]])
            json_data.append(
                {
                    "type": "hr.leave",
                    "reference": lv.get("display_name"),
                    "requestor": emp_name,
                    "date": str(lv.get("create_date", ""))[:10],
                }
            )

    # Expense sheets to approve
    if model_available(c, "hr.expense.sheet"):
        expenses = c.search_read(
            "hr.expense.sheet",
            domain=[("state", "=", "submit")],
            fields=["name", "employee_id", "create_date", "total_amount"],
            limit=limit,
        )
        for ex in expenses:
            emp = ex.get("employee_id")
            emp_name = emp[1] if isinstance(emp, list) else str(emp or "-")
            rows.append(["Expense Report", ex.get("name", ""), emp_name, str(ex.get("create_date", ""))[:10]])
            json_data.append(
                {
                    "type": "hr.expense.sheet",
                    "reference": ex.get("name"),
                    "requestor": emp_name,
                    "date": str(ex.get("create_date", ""))[:10],
                    "amount": ex.get("total_amount"),
                }
            )

    if not rows:
        out.info("No pending approvals found.")
        return

    out.table(
        f"Pending Approvals — {len(rows)} items",
        [("Type", ""), ("Reference", "cyan"), ("Requestor", ""), ("Date", "dim")],
        rows,
        data_for_json=json_data,
    )


# ===================================================================
# FAILED EMAILS
# ===================================================================


@app.command("failed-emails")
def failed_emails(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 50,
) -> None:
    """Emails that failed to send."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not model_available(c, "mail.mail"):
        out.error(module_hint("mail.mail"))
        raise typer.Exit(1)

    mails = c.search_read(
        "mail.mail",
        domain=[("state", "=", "exception")],
        fields=["subject", "email_to", "failure_reason", "date"],
        limit=limit,
        order="date desc",
    )

    if not mails:
        out.info("No failed emails found.")
        return

    rows = []
    json_data: list[dict] = []
    for m in mails:
        rows.append(
            [
                m.get("subject") or "(no subject)",
                m.get("email_to") or "-",
                (m.get("failure_reason") or "-")[:60],
                str(m.get("date", ""))[:16],
            ]
        )
        json_data.append(
            {
                "subject": m.get("subject"),
                "recipient": m.get("email_to"),
                "error": m.get("failure_reason"),
                "date": m.get("date"),
            }
        )

    out.table(
        f"Failed Emails — {len(mails)} found",
        [("Subject", ""), ("Recipient", "dim"), ("Error", "red"), ("Date", "dim")],
        rows,
        data_for_json=json_data,
    )


# ===================================================================
# EXECUTIVE SUMMARY
# ===================================================================


@app.command("exec-summary")
def exec_summary(ctx: typer.Context) -> None:
    """Executive summary — all key metrics in one view.

    Combines: revenue, AR/AP, cash position, inventory value,
    order fulfillment, HR headcount, and alerts into a single report.

    Examples:
        kctl-odoo dashboard exec-summary
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    from kctl_odoo.core.field_helpers import safe_fields  # noqa: F401

    sections = []

    # Revenue (confirmed sales this month)
    try:
        from datetime import datetime

        now = datetime.now()
        month_start = f"{now.year}-{now.month:02d}-01"
        sales = c.search_read(
            "sale.order",
            domain=[("state", "=", "sale"), ("date_order", ">=", month_start)],
            fields=["amount_total"],
            limit=5000,
        )
        revenue = sum(s.get("amount_total", 0) for s in sales)
        order_count = len(sales)
        sections.append(("Revenue (this month)", f"{revenue:,.2f} ({order_count} orders)"))
    except (RPCError, ConnectionError):
        sections.append(("Revenue", "N/A"))

    # AR / AP
    try:
        ar = c.search_read(
            "account.move.line",
            domain=[
                ("account_id.account_type", "=", "asset_receivable"),
                ("parent_state", "=", "posted"),
                ("reconciled", "=", False),
            ],
            fields=["amount_residual"],
            limit=5000,
        )
        total_ar = sum(abs(l.get("amount_residual", 0)) for l in ar)
        sections.append(("Accounts Receivable", f"{total_ar:,.2f}"))
    except (RPCError, ConnectionError):
        sections.append(("Accounts Receivable", "N/A"))

    try:
        ap = c.search_read(
            "account.move.line",
            domain=[
                ("account_id.account_type", "=", "liability_payable"),
                ("parent_state", "=", "posted"),
                ("reconciled", "=", False),
            ],
            fields=["amount_residual"],
            limit=5000,
        )
        total_ap = sum(abs(l.get("amount_residual", 0)) for l in ap)
        sections.append(("Accounts Payable", f"{total_ap:,.2f}"))
    except (RPCError, ConnectionError):
        sections.append(("Accounts Payable", "N/A"))

    # Inventory value
    try:
        products = c.search_read(
            "product.product",
            domain=[("qty_available", ">", 0)],
            fields=["qty_available", "standard_price"],
            limit=5000,
        )
        inv_value = sum(p.get("qty_available", 0) * p.get("standard_price", 0) for p in products)
        sections.append(("Inventory Value", f"{inv_value:,.2f}"))
    except (RPCError, ConnectionError):
        sections.append(("Inventory Value", "N/A"))

    # HR
    try:
        emp_count = c.search_count("hr.employee", [("active", "=", True)])
        sections.append(("Active Employees", str(emp_count)))
    except (RPCError, ConnectionError):
        sections.append(("Employees", "N/A"))

    # Pending
    try:
        pending_so = c.search_count("sale.order", [("state", "=", "draft")])
        pending_po = c.search_count("purchase.order", [("state", "=", "draft")])
        pending_picks = c.search_count("stock.picking", [("state", "in", ["assigned", "confirmed"])])
        sections.append(("Pending Quotations", str(pending_so)))
        sections.append(("Pending RFQs", str(pending_po)))
        sections.append(("Pending Transfers", str(pending_picks)))
    except (RPCError, ConnectionError):
        pass

    # Alerts
    try:
        failed_mail = c.search_count("mail.mail", [("state", "=", "exception")])
        if failed_mail > 0:
            sections.append(("⚠ Failed Emails", str(failed_mail)))
    except (RPCError, ConnectionError):
        pass

    rows = [[k, v] for k, v in sections]
    out.table(
        "Executive Summary",
        [("Metric", ""), ("Value", "")],
        rows,
    )


# ===================================================================
# GROSS MARGIN
# ===================================================================


@app.command("gross-margin")
def gross_margin(ctx: typer.Context, date_from: str | None = None, date_to: str | None = None, limit: int = 20) -> None:
    """Gross margin report — revenue vs COGS per product.

    Calculates margin from confirmed sale order lines.

    Examples:
        kctl-odoo dashboard gross-margin
        kctl-odoo dashboard gross-margin --date-from 2026-03-01
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    from kctl_odoo.core.field_helpers import safe_fields

    domain = [("order_id.state", "=", "sale")]
    if date_from:
        domain.append(("order_id.date_order", ">=", date_from))
    if date_to:
        domain.append(("order_id.date_order", "<=", date_to))

    preferred = ["product_id", "product_uom_qty", "price_subtotal", "purchase_price"]
    fields = safe_fields(c, "sale.order.line", preferred)

    try:
        lines = c.search_read("sale.order.line", domain=domain, fields=fields, limit=10000)
    except RPCError as e:
        out.error(f"Failed: {e}")
        raise typer.Exit(1)

    if not lines:
        out.info("No confirmed sale order lines found.")
        return

    # Aggregate by product
    products: dict = {}
    for line in lines:
        pid = line.get("product_id")
        pname = pid[1] if isinstance(pid, list) else str(pid or "Unknown")
        if pname not in products:
            products[pname] = {"revenue": 0, "cost": 0, "qty": 0}
        products[pname]["revenue"] += line.get("price_subtotal", 0) or 0
        products[pname]["cost"] += (line.get("purchase_price", 0) or 0) * (line.get("product_uom_qty", 0) or 0)
        products[pname]["qty"] += line.get("product_uom_qty", 0) or 0

    # Sort by revenue desc
    sorted_products = sorted(products.items(), key=lambda x: -x[1]["revenue"])[:limit]

    rows = []
    total_revenue = 0.0
    total_cost = 0.0
    for name, data in sorted_products:
        revenue = data["revenue"]
        cost = data["cost"]
        margin = revenue - cost
        margin_pct = (margin / revenue * 100) if revenue else 0
        total_revenue += revenue
        total_cost += cost
        rows.append([name, f"{revenue:,.2f}", f"{cost:,.2f}", f"{margin:,.2f}", f"{margin_pct:.1f}%"])

    total_margin = total_revenue - total_cost
    total_pct = (total_margin / total_revenue * 100) if total_revenue else 0
    rows.append(["TOTAL", f"{total_revenue:,.2f}", f"{total_cost:,.2f}", f"{total_margin:,.2f}", f"{total_pct:.1f}%"])

    out.table(
        f"Gross Margin Report ({len(sorted_products)} products)",
        [("Product", ""), ("Revenue", ""), ("COGS", ""), ("Margin", ""), ("Margin %", "")],
        rows,
    )


# ---------------------------------------------------------------------------
# Backward-compat hidden aliases
# ---------------------------------------------------------------------------
app.command("info", hidden=True)(info)
