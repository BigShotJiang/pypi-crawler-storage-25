"""Odoo JSON-RPC client using httpx.

Odoo JSON-RPC API:
- POST /jsonrpc with {jsonrpc: "2.0", method: "call", params: {service, method, args}}
- service="common", method="authenticate" → returns uid
- service="object", method="execute_kw" → ORM calls
- service="db" → database management

Note: This client uses JSON-RPC 2.0 protocol (not REST), so it does NOT
subclass kctl_lib.api_client.APIClient which is REST-oriented.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

from kctl_odoo.core.cache import RPCCache
from kctl_odoo.core.exceptions import (
    APIError,
    AuthenticationError,
    RPCError,
)
from kctl_odoo.core.exceptions import ConnectionError as KctlConnectionError


class OdooClient:
    """Synchronous httpx client for Odoo JSON-RPC."""

    def __init__(
        self,
        base_url: str,
        database: str,
        username: str = "admin",
        api_key: str = "",
        timeout: float = 30.0,
    ):
        if not base_url:
            raise KctlConnectionError(
                "(not configured)",
                ValueError("No Odoo URL configured. Run: kctl-odoo config init"),
            )
        if not api_key:
            raise AuthenticationError("No API key configured. Run: kctl-odoo config init")

        self._base_url = base_url.rstrip("/")
        self._database = database
        self._username = username
        self._api_key = api_key
        self._uid: int | None = None
        self._rpc_id = 0
        self._readonly = False
        self._cache = RPCCache()
        # api_report (Phase 1) fast-path: capability cache + web-session flag.
        self._api_report_available: bool | None = None
        self._web_session_authed = False
        # KCTL_ODOO_READ_TIMEOUT env var overrides default 60s read timeout
        # for long-running operations (bulk_apply, large reports, etc.)
        read_timeout = float(os.environ.get("KCTL_ODOO_READ_TIMEOUT", "60.0"))
        self._client = httpx.Client(
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=httpx.Timeout(connect=10.0, read=read_timeout, write=30.0, pool=10.0),
            limits=httpx.Limits(
                max_connections=20,
                max_keepalive_connections=10,
                keepalive_expiry=30,
            ),
            transport=httpx.HTTPTransport(retries=2),
            follow_redirects=True,
        )

    @property
    def readonly(self) -> bool:
        return self._readonly

    @readonly.setter
    def readonly(self, value: bool) -> None:
        self._readonly = value

    def _check_readonly(self, method: str) -> None:
        """Raise if readonly mode is active and method is a write operation."""
        if self._readonly and method in (
            "create",
            "write",
            "unlink",
            "button_confirm",
            "action_confirm",
            "action_done",
            "action_cancel",
            "action_post",
            "action_draft",
        ):
            raise APIError(
                detail=f"Profile is read-only. Blocked write method '{method}'. "
                "Use a write-enabled profile for this operation."
            )

    @property
    def database(self) -> str:
        return self._database

    # ------------------------------------------------------------------
    # api_report fast-path (Phase 1)
    #
    # When the `api_report` module is installed on the target Odoo, report
    # data + XLSX bytes can be fetched in a single authenticated REST call to
    # `/api/v1/report-templates/reports/*` instead of multi-step JSON-RPC.
    # Auth reuses the existing username/api_key via a one-time web session
    # (api_base accepts session auth). Everything is capability-gated so the
    # CLI falls back cleanly when the module is absent.
    # ------------------------------------------------------------------

    def has_api_report(self) -> bool:
        """Return True if the `api_report` module is installed (cached)."""
        if self._api_report_available is None:
            try:
                rows = self.search_read(
                    "ir.module.module",
                    [("name", "=", "api_report"), ("state", "=", "installed")],
                    ["id"],
                    limit=1,
                )
                self._api_report_available = bool(rows)
            except (KctlConnectionError, APIError, AuthenticationError):
                self._api_report_available = False
        return self._api_report_available

    def _ensure_web_session(self) -> None:
        """Authenticate a web session once; the cookie persists on self._client."""
        if self._web_session_authed:
            return
        resp = self._client.post(
            f"{self._base_url}/web/session/authenticate",
            json={
                "jsonrpc": "2.0",
                "params": {
                    "db": self._database,
                    "login": self._username,
                    "password": self._api_key,
                },
            },
            headers={"X-Odoo-dbfilter": f"^{self._database}$"},
        )
        data = resp.json()
        if resp.status_code != 200 or not (data.get("result") or {}).get("uid"):
            raise AuthenticationError(f"Web-session authentication failed for {self._username}@{self._database}")
        self._web_session_authed = True

    def _api_report_url(self, path: str) -> str:
        return f"{self._base_url}/api/v1/report-templates/reports/{path}"

    def api_report_compute(self, body: dict) -> dict:
        """POST /reports/compute → structured report_data dict."""
        self._ensure_web_session()
        resp = self._client.post(
            self._api_report_url("compute"),
            json=body,
            headers={"X-Odoo-dbfilter": f"^{self._database}$"},
        )
        if resp.status_code != 200:
            raise APIError(detail=f"api_report compute failed: HTTP {resp.status_code} {resp.text[:200]}")
        return resp.json()

    def api_report_file(self, fmt: str, body: dict) -> bytes:
        """POST /reports/{xlsx|pdf} → file bytes (raises APIError on non-200)."""
        self._ensure_web_session()
        resp = self._client.post(
            self._api_report_url(fmt),
            json=body,
            headers={"X-Odoo-dbfilter": f"^{self._database}$"},
        )
        if resp.status_code != 200:
            raise APIError(detail=f"api_report {fmt} failed: HTTP {resp.status_code} {resp.text[:200]}")
        return resp.content

    @property
    def uid(self) -> int:
        """Get authenticated user ID, authenticating if needed."""
        if self._uid is None:
            self.authenticate()
        assert self._uid is not None
        return self._uid

    def _next_id(self) -> int:
        self._rpc_id += 1
        return self._rpc_id

    def _jsonrpc(self, url: str, params: dict) -> Any:
        """Make a JSON-RPC 2.0 call."""
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "id": self._next_id(),
            "params": params,
        }
        try:
            response = self._client.post(url, json=payload)
        except httpx.ConnectError as e:
            raise KctlConnectionError(self._base_url, e) from e
        except httpx.HTTPError as e:
            raise KctlConnectionError(self._base_url, e) from e

        if response.status_code >= 400:
            raise APIError(response)

        body = response.json()
        if "error" in body:
            error_data = body["error"]
            msg = error_data.get("message", "")
            if "Access Denied" in msg or "AccessDenied" in str(error_data):
                raise AuthenticationError(f"Access denied: {msg}")
            raise RPCError(error_data)

        return body.get("result")

    def authenticate(self) -> int:
        """Authenticate via JSON-RPC and return uid."""
        result = self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {
                "service": "common",
                "method": "authenticate",
                "args": [self._database, self._username, self._api_key, {}],
            },
        )
        if not result:
            raise AuthenticationError(
                f"Authentication failed for {self._username}@{self._database}. "
                "Check database name, username, and API key."
            )
        self._uid = int(result)
        return self._uid

    def execute_kw(
        self,
        model: str,
        method: str,
        args: list | None = None,
        kwargs: dict | None = None,
    ) -> Any:
        """Call an ORM method via execute_kw."""
        self._check_readonly(method)
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {
                "service": "object",
                "method": "execute_kw",
                "args": [
                    self._database,
                    self.uid,
                    self._api_key,
                    model,
                    method,
                    args or [],
                    kwargs or {},
                ],
            },
        )

    def search(self, model: str, domain: list | None = None, limit: int = 0, offset: int = 0) -> list[int]:
        """Search for record IDs."""
        kwargs: dict[str, Any] = {}
        if limit:
            kwargs["limit"] = limit
        if offset:
            kwargs["offset"] = offset
        return self.execute_kw(model, "search", [domain or []], kwargs)

    def search_read(
        self,
        model: str,
        domain: list | None = None,
        fields: list[str] | None = None,
        limit: int = 0,
        offset: int = 0,
        order: str = "",
        no_cache: bool = False,
    ) -> list[dict]:
        """Search and read records."""
        kwargs: dict[str, Any] = {}
        if fields:
            kwargs["fields"] = fields
        if limit:
            kwargs["limit"] = limit
        if offset:
            kwargs["offset"] = offset
        if order:
            kwargs["order"] = order
        args = (domain or [],)
        if not no_cache:
            cached = self._cache.get(model, "search_read", args, kwargs)
            if cached is not None:
                return cached
        result = self.execute_kw(model, "search_read", list(args), kwargs)
        if not no_cache:
            self._cache.put(model, "search_read", args, kwargs, result)
        return result

    def read(self, model: str, ids: list[int], fields: list[str] | None = None) -> list[dict]:
        """Read specific records by ID."""
        kwargs: dict[str, Any] = {}
        if fields:
            kwargs["fields"] = fields
        return self.execute_kw(model, "read", [ids], kwargs)

    def search_count(self, model: str, domain: list | None = None, no_cache: bool = False) -> int:
        """Count records matching domain."""
        args = (domain or [],)
        kwargs: dict[str, Any] = {}
        if not no_cache:
            cached = self._cache.get(model, "search_count", args, kwargs)
            if cached is not None:
                return cached
        result = self.execute_kw(model, "search_count", list(args))
        if not no_cache:
            self._cache.put(model, "search_count", args, kwargs, result)
        return result

    def create(self, model: str, vals: dict) -> int:
        """Create a record, return ID."""
        result = self.execute_kw(model, "create", [vals])
        self._cache.invalidate_model(model)
        return result

    def write(self, model: str, ids: list[int], vals: dict) -> bool:
        """Update records."""
        result = self.execute_kw(model, "write", [ids, vals])
        self._cache.invalidate_model(model)
        return result

    def unlink(self, model: str, ids: list[int]) -> bool:
        """Delete records."""
        result = self.execute_kw(model, "unlink", [ids])
        self._cache.invalidate_model(model)
        return result

    def read_group(
        self,
        model: str,
        domain: list,
        fields: list[str],
        groupby: list[str],
        offset: int = 0,
        limit: int | None = None,
        orderby: str = "",
        lazy: bool = True,
        no_cache: bool = False,
    ) -> list[dict]:
        """Read grouped records (SQL GROUP BY)."""
        kwargs: dict[str, Any] = {"offset": offset, "orderby": orderby, "lazy": lazy}
        if limit is not None:
            kwargs["limit"] = limit
        args = (domain, fields, groupby)
        if not no_cache:
            cached = self._cache.get(model, "read_group", args, kwargs)
            if cached is not None:
                return cached
        result = self.execute_kw(model, "read_group", list(args), kwargs)
        if not no_cache:
            self._cache.put(model, "read_group", args, kwargs, result)
        return result

    def fields_get(self, model: str, attributes: list[str] | None = None, no_cache: bool = False) -> dict:
        """Get field definitions for a model."""
        kwargs: dict[str, Any] = {}
        if attributes:
            kwargs["attributes"] = attributes
        args: tuple = ()
        if not no_cache:
            cached = self._cache.get(model, "fields_get", args, kwargs)
            if cached is not None:
                return cached
        result = self.execute_kw(model, "fields_get", [], kwargs)
        if not no_cache:
            self._cache.put(model, "fields_get", args, kwargs, result)
        return result

    def db_list(self) -> list[str]:
        """List databases via database service."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "list", "args": []},
        )

    def db_backup(self, database: str, backup_format: str = "zip") -> bytes:
        """Backup a database. Returns raw backup bytes."""
        # Database backup uses the web endpoint, not JSON-RPC
        response = self._client.post(
            f"{self._base_url}/web/database/backup",
            data={
                "master_pwd": self._api_key,
                "name": database,
                "backup_format": backup_format,
            },
            timeout=600,
        )
        if response.status_code != 200 or response.headers.get("content-type", "").startswith("text/html"):
            raise APIError(detail=f"Backup failed (HTTP {response.status_code})")
        return response.content

    def db_restore(self, database: str, backup_file: bytes, copy: bool = True) -> bool:
        """Restore a database from backup."""
        response = self._client.post(
            f"{self._base_url}/web/database/restore",
            data={
                "master_pwd": self._api_key,
                "name": database,
                "copy": "true" if copy else "false",
            },
            files={"backup_file": ("backup.zip", backup_file, "application/zip")},
            timeout=600,
        )
        if response.status_code != 200:
            raise APIError(detail=f"Restore failed (HTTP {response.status_code})")
        return True

    def db_duplicate(self, source: str, target: str) -> bool:
        """Duplicate a database."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "duplicate_database", "args": [self._api_key, source, target]},
        )

    def db_rename(self, old_name: str, new_name: str) -> bool:
        """Rename a database."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "rename", "args": [self._api_key, old_name, new_name]},
        )

    def db_exist(self, name: str) -> bool:
        """Check whether a database exists."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "db_exist", "args": [name]},
        )

    def db_list_lang(self) -> list:
        """List available languages for database creation."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "list_lang", "args": []},
        )

    def for_database(self, database: str) -> OdooClient:
        """Return a new client pointing at a different database on the same server."""
        return OdooClient(
            base_url=self._base_url,
            database=database,
            username=self._username,
            api_key=self._api_key,
            timeout=self._client.timeout.connect,  # preserve timeout
        )

    def db_create(self, name: str, lang: str = "en_US") -> None:
        """Create a new database via the db service."""
        self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {
                "service": "db",
                "method": "create_database",
                "args": [self._api_key, name, False, lang, self._api_key],
            },
        )

    def db_drop(self, name: str) -> None:
        """Drop a database via the db service."""
        self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "db", "method": "drop", "args": [self._api_key, name]},
        )

    def call_button(self, model: str, method: str, ids: list[int]) -> Any:
        """Convenience wrapper for button / action methods on records."""
        return self.execute_kw(model, method, [ids])

    def version_info(self) -> dict:
        """Get Odoo server version info."""
        return self._jsonrpc(
            f"{self._base_url}/jsonrpc",
            {"service": "common", "method": "version", "args": []},
        )

    def check_health(self) -> tuple[bool, str]:
        """Check if Odoo is reachable. Returns (ok, version_or_error)."""
        try:
            info = self.version_info()
            return True, info.get("server_version", "unknown")
        except (RPCError, KctlConnectionError, APIError) as e:
            return False, str(e)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> OdooClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
