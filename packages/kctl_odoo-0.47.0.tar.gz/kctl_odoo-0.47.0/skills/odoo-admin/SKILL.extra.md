## Chat/Telegram delivery

For ANY report destined for a chat platform (Telegram/Mattermost/WhatsApp via hermes):

    kctl-odoo <command> --format markdown [--with-files xlsx]

Output is portable markdown + `MEDIA:<abs-path>` tokens that hermes auto-uploads
as documents. Use `--format markdown` for inline summary; add `--with-files` when
the user wants the full data. Never hand-format markdown from `--format json`.

Supported in v1:

| Command              | Files supported (v1)     |
|----------------------|--------------------------|
| `report quick`       | `xlsx` (`pdf` in v1.1)   |
| `analyze run`        | (none — inline only)     |
| `analyze presets`    | (none — inline only)     |
| `kpi run`            | (none — inline only)     |
| `kpi list`           | (none — inline only)     |
| `dashboard summary`  | (none — inline only)     |
| `dashboard digest`   | (none — inline only)     |
| `dashboard info`     | (none — inline only)     |
| `doctor ai-summary`  | (none — inline only)     |

> `analyze run` / `kpi run` file export (xlsx) is v1.1 — those commands have no
> native XLSX renderer today; building one is out of v1 scope. Inline markdown
> works for them now.

Discovery in one call:

    kctl-odoo commands list --markdown-ready --json

Inside the hermes container, `$KCTL_ODOO_REPORT_DIR` is preset to
`/opt/data/reports`. Files auto-cleanup after 7 days; you don't need to manage
disk hygiene.
