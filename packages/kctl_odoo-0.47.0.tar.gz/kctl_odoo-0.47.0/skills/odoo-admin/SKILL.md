---
name: odoo-admin
description: >
  Odoo 18 ERP administration via kctl-odoo CLI (121 groups, ~971 commands). MUST use for ANY kctl-odoo operation. See SKILL.md ## Triggers for keywords.
  Auto-generated: 2026-05-22
  registry_hash: 8a579849e9de
---

# odoo-admin — kctl-odoo CLI Reference

> Auto-generated from `kctl-odoo` command registry. Do not edit manually.
> To regenerate: `kctl-odoo skill generate`
> To add custom content: edit `SKILL.extra.md` in the same directory.

## Overview

**CLI:** `kctl-odoo`
**Command groups:** 121
**Total commands:** ~971
**Install:** `cd cli && uv tool install --editable .`

## Global Options

| Flag | Description |
|------|-------------|
| `--json` | JSON output |
| `--quiet`, `-q` | Suppress info messages |
| `--format`, `-f` | Output format: pretty/json/csv/yaml |
| `--no-header` | Omit CSV header row |
| `--profile`, `-p` | Config profile name |
| `--version`, `-V` | Show version |

## Quick Discovery (for AI agents)

**DO NOT GUESS command paths or flag names.** Before invoking `kctl-odoo <group> <verb> ...`, use these AI-facing affordances:

1. **Find a command by keyword** — substring filter, returns sorted leaf paths:
   ```bash
   kctl-odoo commands list --filter <keyword>
   ```
   Example: `kctl-odoo commands list --filter database` → all database-related commands in one call.

2. **Inspect flags before invoking** — full param schema with
   opts/defaults/required/choices/help:
   ```bash
   kctl-odoo commands tree --json | jq '.. | objects | select(.name == "<verb>") | .params'
   ```
   Reading the `params` array tells you exact flag names (`--lang`), short aliases (`-l`), defaults, required-vs-optional, and choices — eliminating the `No such option '--xxx'` failure mode.

3. **Preview destructive operations without executing** — `--explain` is supported on selected write commands:
   ```bash
   kctl-odoo <group> <verb> <args> --explain
   ```
   Prints the planned action and exits 0. If `--explain` errors with "no such option", that command does not support it — fall back to verifying via `commands tree` schema inspection before running for real.

4. **Errors are user-facing one-liners**, not Python tracebacks. A failed invocation shows `❌ <ErrorClass>: <message>` on stderr (or `{"error": ..., "message": ...}` JSON if `--json` was passed). Read the message — it usually tells you exactly what's missing.

## Chat/Telegram delivery

For ANY report destined for a chat platform (Telegram/Mattermost/WhatsApp via hermes):

    kctl-odoo <command> --format markdown [--with-files xlsx]

Output is portable markdown + `MEDIA:<abs-path>` tokens that hermes auto-uploads
as documents. Use `--format markdown` for inline summary; add `--with-files` when
the user wants the full data. Never hand-format markdown from `--format json`.

Supported in v1:

| Command              | Files supported (v1)     |
|----------------------|--------------------------|
| `report quick`       | `xlsx` (`pdf` in v1.1)   |
| `analyze run`        | (none — inline only)     |
| `analyze presets`    | (none — inline only)     |
| `kpi run`            | (none — inline only)     |
| `kpi list`           | (none — inline only)     |
| `dashboard summary`  | (none — inline only)     |
| `dashboard digest`   | (none — inline only)     |
| `dashboard info`     | (none — inline only)     |
| `doctor ai-summary`  | (none — inline only)     |

> `analyze run` / `kpi run` file export (xlsx) is v1.1 — those commands have no
> native XLSX renderer today; building one is out of v1 scope. Inline markdown
> works for them now.

Discovery in one call:

    kctl-odoo commands list --markdown-ready --json

Inside the hermes container, `$KCTL_ODOO_REPORT_DIR` is preset to
`/opt/data/reports`. Files auto-cleanup after 7 days; you don't need to manage
disk hygiene.

## Triggers

Auto-invoke this skill when the user references any of these keywords:

"acc", "access-report", "access-rights", "accounting", "accounts", "accurate", "actions", "activate", "activate-currency", "active", "activities", "add-group", "add-line", "add-mail-incoming", "add-mail-outgoing", "add-module", "add-to-group", "addons", "adjust", "adjustments", "admins", "aged-payable", "aged-receivable", "aggregate", "aging", "ai-summary", "alerts", "analyze", "apply", "apply-coa-profile", "apply-theme", "approval", "approvals", "approve", "approve-expense", "approve-leave", "ar-ap-reversal", "assets", "assign", "attachments", "attendance", "attendance-report", "attendance-today", "aud", "audit", "audit-api", "audit-blocking", "audit-compute", "audit-fix", "audit-live", "audit-logic", "audit-orphans", "audit-ou", "audit-package", "audit-prompt", "audit-report", "audit-source", "audit-standards", "audit-trail", "audit-ui", "audit-views", "auto-fix", "auto-report", "auto-run", "auto-schedule", "automation", "autovacuum", "backup", "backups", "bank", "bank-status", "barcode-lookup", "batch-download", "batch-post", "bench", "benchmark", "bi", "birthdays", "bl", "bom-cost"

## Command Reference

### `kctl-odoo acc`

Alias: accounting

### `kctl-odoo accounting`

Accounting: invoices, journal entries, payments, aging reports.

| Command | Description |
|---------|-------------|
| `accounting aged-payable [--limit]` | AP aging report. |
| `accounting aged-receivable [--limit]` | AR aging report. |
| `accounting audit-trail [--invoice] [--days] [--limit]` | Audit trail for accounting entries — who posted/modified what. |
| `accounting bank-status` | Bank account balances and reconciliation status. |
| `accounting batch-post [--move_type] [--limit] [--force]` | Post all draft invoices/bills of a given type. |
| `accounting cancel <ids> [--force]` | Cancel posted invoices/bills (reverse to draft). |
| `accounting cancel-invoice <ids> [--force]` | Cancel posted invoices/bills (reverse to draft). |
| `accounting close-period [--period_end]` | Period/year-end accounting close validation. |
| `accounting create <partner_name> <product_name> [--qty] [--price] [--inv_type] [--dry_run] [--force]` | Create a customer or vendor invoice. |
| `accounting create-entry <journal_name> <lines_str> [--ref] [--date] [--dry_run] [--force]` | Create a manual journal entry. |
| `accounting create-invoice <partner_name> <product_name> [--qty] [--price] [--inv_type] [--dry_run] [--force]` | Create a customer or vendor invoice. |
| `accounting get <number>` | Get invoice detail by number or ID. |
| `accounting get-invoice <number>` | Get invoice detail by number or ID. |
| `accounting gl-detail <account_code> [--date_from] [--date_to] [--limit]` | General ledger detail for a specific account. |
| `accounting gl-export <account_code> [--date_from] [--date_to] [--output] [--fmt]` | Export general ledger detail to CSV file. |
| `accounting invoices [--state] [--inv_type] [--partner] [--date_from] [--date_to] [--limit]` | List invoices. |
| `accounting journal-entries [--journal] [--date_from] [--date_to] [--ref] [--partner] [--limit]` | List journal entries. |
| `accounting list [--state] [--inv_type] [--partner] [--date_from] [--date_to] [--limit]` | List invoices. |
| `accounting lock-period <date> [--tax_only] [--force]` | Set accounting lock date. |
| `accounting overdue [--days] [--limit]` | List overdue invoices (customer and vendor). |
| `accounting post <ids> [--force]` | Post one or more draft invoices/bills. |
| `accounting post-invoice <ids> [--force]` | Post one or more draft invoices/bills. |
| `accounting register-payment <invoice_number> [--amount] [--journal_name] [--force]` | Register payment for an invoice. |
| `accounting revalue-currency [--date] [--dry_run]` | Multi-currency revaluation check. |
| `accounting summary [--period]` | Accounting dashboard — invoices, receivables, payables, aging. |
| `accounting trial-balance [--date_from] [--date_to] [--limit]` | Trial balance report. |
| `accounting unreconciled [--account] [--limit]` | Show unreconciled journal items. |

**Examples:**
```bash
kctl-odoo accounting aged-payable
kctl-odoo accounting aged-payable --json
kctl-odoo accounting aged-receivable
kctl-odoo accounting aged-receivable --json
kctl-odoo accounting audit-trail
```

### `kctl-odoo accurate`

Accurate -> Odoo migration management.

| Command | Description |
|---------|-------------|
| `accurate ar-ap-reversal <identifier> [--confirm]` | Post the AR/AP reversal JE to neutralise bulk opening AR/AP. |
| `accurate attachments <identifier>` | Phase 9 Attachments — migrate Accurate attachments to ir.attachment. |
| `accurate audit-orphans <identifier> [--show_all]` | Report account.move records whose accurate_id is missing from JV cache. |
| `accurate audit-package <slug> <output>` | Generate the audit package zip for <slug>. |
| `accurate business-validation <identifier>` | Run company health check + business scenario validation. |
| `accurate coa-cleanup <identifier> [--confirm]` | Migrate factory l10n_id CoA → Accurate CoA per company. |
| `accurate companies` | Manage Accurate company registrations. |
| `accurate cutover` | Cutover readiness + execution (Phase 4). |
| `accurate daily-sync <slug>` | Run incremental delta sync for a company. |
| `accurate errors` | Migration-error inspection and bulk retry. |
| `accurate foundation <identifier> [--timeout]` | Foundation Sync — master data import with self-healing. |
| `accurate foundation-report <identifier>` | Show master data completeness report for a company. |
| `accurate go-live <identifier>` | Phase 8 Go-Live — enable cron sync, state=live. |
| `accurate migrate <identifier> [--dry_run] [--wipe] [--skip_orders] [--force_fetch] [--timeout]` | Full CPR migration: foundation + create-post-retype + validation. |
| `accurate parity <slug> [--check] [--as_of] [--tolerance] [--output] [--output_file]` | Run parity suite against Accurate for one tenant + format results. |
| `accurate parity-all [--as_of] [--tolerance] [--output_file]` | Run parity suite across every accurate.company; emit consolidated markdown. |
| `accurate parity-batch <identifier> [--as_of]` | Run the 12-check parity framework and print BS/PL/TB delta. |
| `accurate phase-bank <identifier> [--dry_run] [--timeout]` | Phase 8 standalone: create bank statement lines from JV-imported moves. |
| `accurate phase-bootstrap <identifier> [--dry_run] [--timeout]` | Phase 0 standalone: bootstrap a new company (self-healing setup). |
| `accurate phase-jvs <identifier> [--dry_run] [--force_fetch] [--timeout]` | Phase 2 standalone: create + post account.move from cached JV details. |
| `accurate phase-master-data <identifier> [--dry_run] [--force_fetch] [--timeout]` | Phase 1 standalone: master data fetch + 21 validation checks. |
| `accurate phase-orders <identifier> [--dry_run] [--timeout]` | Phase 9 standalone: import PO + SO from Accurate. |
| `accurate phase-payments <identifier> [--dry_run] [--timeout]` | Phase 5 standalone: create account.payment from classified JVs. |
| `accurate phase-purchase-orders <identifier> [--dry_run] [--timeout]` | Phase 9 PO-only: import purchase orders from Accurate. |
| `accurate phase-reconcile <identifier> [--dry_run] [--timeout]` | Phase 6 standalone: match AR/AP partials across migrated lines. |
| `accurate phase-retype <identifier> [--dry_run] [--timeout]` | Phase 3 standalone: SQL retype SI→out_invoice / PI→in_invoice + enrich. |
| `accurate phase-sales-orders <identifier> [--dry_run] [--timeout]` | Phase 9 SO-only: import sales orders from Accurate. |
| `accurate phase-stock-init <identifier> [--dry_run] [--timeout]` | Phase 7 standalone: stock.quant + SVL from Accurate items. |
| `accurate phases <identifier> [--phase] [--state]` | Show phase execution history for one Accurate company. |
| `accurate post-drafts <identifier> [--dry_run]` | Post every draft account.move/payment tagged by the migration. |
| `accurate preflight <identifier>` | Run Phase 1 Preflight checks. |
| `accurate purge-orphans <identifier> [--execute] [--show_all]` | Reconcile orphan moves by probing Accurate API per id. |
| `accurate reconcile` | Daily reconciliation commands. |
| `accurate report <slug> [--output]` | Generate a migration report Excel for one or all companies. |
| `accurate reports` | Direct-Accurate pilot reports (no Odoo migration required). |
| `accurate setup <identifier> [--coa_template]` | Run Phase 2 Setup — install CoA + resolve PPh accounts. |
| `accurate sign-off <identifier> [--confirm]` | Sign off verification — required before go-live. |
| `accurate snapshot` | Snapshot management — pull, list, export snapshots. |
| `accurate stock` | Stock migration commands (snapshot, GR linking, parity). |
| `accurate sync` | Accurate sync diagnostics. |
| `accurate sync-sc <identifier>` | Sync Accurate projects → accurate_sales_contract_mapping (backfill). |
| `accurate transactions <identifier> [--phase] [--sync] [--skip_bs_opening] [--timeout]` | Import transactions from Accurate. |
| `accurate validate-journals <profile> <odoo_company> [--fix] [--confirm] [--type_filter] [--jv_filter] [--output]` | Validate Odoo journals against Accurate JVs. |
| `accurate variance` | Variance explanations (Phase 4). |
| `accurate verify <identifier>` | Phase 7 Verification — generates parity report. |
| `accurate wipe <identifier> [--dry_run] [--confirm]` | Wipe migrated transactions while preserving all masters/config. |
| `accurate wipe-validate <identifier>` | Validate a post-wipe tenant — confirm transactions are truly clean. |

**Examples:**
```bash
kctl-odoo accurate audit-orphans cv-mandira-buah-nusaprima
kctl-odoo accurate audit-orphans cv-mandira-buah-nusaprima --show-all
kctl-odoo accurate business-validation 26-bb-cv-sentra-agro-nusantara
kctl-odoo accurate daily-sync 26-bb-cv-sentra-agro-nusantara
kctl-odoo accurate migrate terra-buah                    # dry-run
```

### `kctl-odoo addons`

Addon analysis, health scoring, and bundle coverage audits.

| Command | Description |
|---------|-------------|
| `addons coverage [--addon_paths] [--dir_path]` | Show bundle coverage: how many disk addons are in at least one bundle. |
| `addons deps-graph [--module] [--format_] [--addon_paths]` | Show dependency graph from manifest depends keys. |
| `addons drift <profile> [--dir_path] [--addon_paths]` | Compare profile YAML vs live Odoo installed modules. |
| `addons drift-snapshot <profile> <snapshot_file> [--dir_path] [--addon_paths]` | Compare profile YAML vs a snapshot JSON file (offline). |
| `addons duplicates [--addon_paths]` | Find addon names that appear in multiple source directories. |
| `addons health <name> [--addon_paths]` | Show health score for a single addon. |
| `addons health-summary [--source] [--addon_paths]` | Aggregate health scores across addons, sorted worst-first. |
| `addons matrix [--dir_path] [--addon_paths] [--source]` | Show addon x profile matrix. |
| `addons missing [--addon_paths] [--dir_path]` | Find modules in bundles that are not on disk. |
| `addons orphans [--addon_paths] [--dir_path]` | Find addons on disk not referenced in any bundle. |
| `addons report [--addon_paths] [--dir_path] [--output_file]` | Full audit: orphans + missing + duplicates + health + coverage. |
| `addons scan [--addon_paths]` | List all addons discovered on disk. |

**Examples:**
```bash
kctl-odoo addons coverage
kctl-odoo addons coverage --json
kctl-odoo addons deps-graph
kctl-odoo addons deps-graph --module my_module
kctl-odoo addons deps-graph --module my_module --format dot > deps.dot
```

### `kctl-odoo analyze`

One-call structured analytics for AI agents.

| Command | Description |
|---------|-------------|
| `analyze presets` | List all available analytics presets (built-in + custom YAML). |
| `analyze raw` | Raw analytics query (requires --confirm). |
| `analyze run <preset_name> [--company] [--company_ids] [--date_from] [--date_to] [--as_of_date] [--limit] [--validate] [--output]` | Run an analytics preset and return structured data. |

**Examples:**
```bash
kctl-odoo analyze run top-products --company-ids 1,2,3 --limit 10 --json
kctl-odoo analyze run pnl-consolidated --company-ids 1,2,3 --json
kctl-odoo analyze run salesman-performance --company 5 --validate --json
```

### `kctl-odoo approvals`

Approval center: pending requests, approve, reject, delegate.

| Command | Description |
|---------|-------------|
| `approvals approve <model> <res_id> [--comment] [--force]` | Approve a tier validation for a record. |
| `approvals delegate <model> <res_id> <to_user>` | Delegate an approval to another user. |
| `approvals escalated [--limit]` | List tier reviews that are past their review deadline. |
| `approvals history [--user] [--limit]` | List validated or rejected tier reviews (approval history). |
| `approvals pending [--review_type] [--user] [--limit]` | List pending tier review requests. |
| `approvals reject <model> <res_id> [--reason] [--force]` | Reject a tier validation for a record. |
| `approvals sla-status` | Show SLA statistics for approvals. |
| `approvals summary` | Show summary of pending approvals and SLA violations. |

**Examples:**
```bash
kctl-odoo approvals approve sale.order 42
kctl-odoo approvals approve sale.order 42 --comment "Approved by manager"
kctl-odoo approvals delegate sale.order 42 john.doe
kctl-odoo approvals delegate sale.order 42 5
kctl-odoo approvals escalated
```

### `kctl-odoo assets`

Fixed assets: depreciation, disposal, tracking.

| Command | Description |
|---------|-------------|
| `assets depreciation-schedule <asset_id>` | Show depreciation schedule for an asset. |
| `assets get <asset_id>` | Show asset detail. |
| `assets list [--state] [--limit]` | List fixed assets. |
| `assets post-depreciation [--dep_date] [--dry_run]` | Trigger depreciation posting for pending lines. |
| `assets summary` | Asset statistics — counts and values by state. |

**Examples:**
```bash
kctl-odoo assets depreciation-schedule 42
kctl-odoo assets get 42
kctl-odoo assets list
kctl-odoo assets list --state open --limit 20
kctl-odoo assets post-depreciation --dry-run
```

### `kctl-odoo aud`

Alias: audit

### `kctl-odoo audit`

Audit trail: view and manage auditlog records.

| Command | Description |
|---------|-------------|
| `audit cleanup [--days] [--dry_run] [--force]` | Delete old audit log entries. |
| `audit detail <log_id>` | Show detail of an audit log entry including field changes. |
| `audit list [--model] [--user] [--days] [--limit]` | List audit log entries. |
| `audit rules` | List auditlog rules (which models are tracked). |

**Examples:**
```bash
kctl-odoo audit cleanup --days 90 --dry-run
kctl-odoo audit cleanup --days 30 --force
kctl-odoo audit detail 42
kctl-odoo audit list
kctl-odoo audit list --model res.partner --days 7
```

### `kctl-odoo automation`

Server actions and automated rules.

| Command | Description |
|---------|-------------|
| `automation actions [--model] [--limit]` | List ir.actions.server records. |
| `automation disable <rule_id>` | Disable an automation rule (set active=False). |
| `automation enable <rule_id>` | Enable an automation rule (set active=True). |
| `automation history <rule_id> [--limit]` | Show execution history for an automation rule. |
| `automation list [--model] [--limit]` | List ir.actions.server records. |
| `automation rules [--model] [--limit]` | List base.automation records (automated rules). |
| `automation run <action_id> [--record_ids]` | Execute an ir.actions.server action. |

**Examples:**
```bash
kctl-odoo automation actions
kctl-odoo automation actions --model sale.order
kctl-odoo automation actions --limit 20
kctl-odoo automation disable 42
kctl-odoo automation enable 42
```

### `kctl-odoo backup`

Database backup and restore operations.

| Command | Description |
|---------|-------------|
| `backup create [--database] [--fmt] [--output]` | Create a database backup. |
| `backup dr-status [--rpo_hours]` | Disaster recovery readiness report. |
| `backup list` | List databases with availability info. |
| `backup restore <backup_file> [--database] [--copy] [--force] [--explain]` | Restore a database from a backup file. |
| `backup schedule` | Show backup-related scheduled actions from ir.cron. |

**Examples:**
```bash
kctl-odoo backup create
kctl-odoo backup create --database odoo_prod --format dump
kctl-odoo backup create -o /backups/daily.zip
kctl-odoo backup list
kctl-odoo backup list --json
```

### `kctl-odoo bank`

Bank reconciliation: statements, matching, import.

| Command | Description |
|---------|-------------|
| `bank import-guide` | Show instructions for importing bank statements. |
| `bank import-statement <file_path> [--journal] [--dry_run]` | Import bank statement lines from a CSV file. |
| `bank journals` | List bank and cash journals. |
| `bank status` | Bank reconciliation overview. |
| `bank suspense` | Show suspense account balance. |
| `bank unmatched [--journal] [--limit]` | List unreconciled bank statement lines. |

**Examples:**
```bash
kctl-odoo bank import-guide
kctl-odoo bank import-statement bank_march.csv --journal BNK1
kctl-odoo bank import-statement bank.csv --dry-run
kctl-odoo bank journals
kctl-odoo bank status
```

### `kctl-odoo bi`

Alias: bundles install <name>

Usage: `kctl-odoo bi <name> [--groups]`

### `kctl-odoo bl`

Alias: bundles list

### `kctl-odoo budget`

Budget planning and variance analysis.

| Command | Description |
|---------|-------------|
| `budget list [--state] [--limit]` | List budgets. |
| `budget summary [--period]` | Overall budget utilization summary. |
| `budget variance <budget_id>` | Show budget vs actual variance per budget line. |

**Examples:**
```bash
kctl-odoo budget list
kctl-odoo budget list --state validate --limit 10
kctl-odoo budget summary
kctl-odoo budget summary --period 2025
kctl-odoo budget variance 5
```

### `kctl-odoo bundles`

Manage module bundles (YAML-based installation groups).

| Command | Description |
|---------|-------------|
| `bundles add-module <bundle> <module> [--group] [--dir_path]` | Add a module to a group in an existing bundle. |
| `bundles compare-profiles <profiles> [--dir_path] [--show_modules]` | Compare features between deployment profiles. |
| `bundles create <name> [--description] [--requires] [--dir_path]` | Create a new grouped-format bundle YAML file. |
| `bundles create-profile <name> [--description] [--bundles_list] [--extends] [--dir_path]` | Create a new deployment profile YAML file. |
| `bundles diff <bundle_a> <bundle_b> [--dir_path]` | Diff two bundles showing modules unique to each and shared. |
| `bundles find-module <module> [--dir_path]` | Find which bundle(s) and group(s) contain a specific module. |
| `bundles graph [--dir_path] [--fmt]` | Show bundle dependency graph derived from 'requires' chains. |
| `bundles groups <name> [--dir_path]` | List groups in a bundle with module counts. |
| `bundles install <name> [--groups] [--dir_path] [--dry_run]` | Install missing bundle modules on the remote Odoo instance. |
| `bundles list [--dir_path]` | List all available bundles. |
| `bundles list-profiles [--dir_path]` | List all deployment profiles with bundle and module counts. |
| `bundles modules <name> [--groups] [--dir_path]` | Resolve bundle to a comma-separated module list (CI/CD compatible). |
| `bundles profile-install <name> [--dir_path] [--dry_run]` | Install all missing profile modules on the remote Odoo instance. |
| `bundles profile-status <name> [--dir_path]` | Compare all profile modules against the remote Odoo instance. |
| `bundles profile-validate [--dir_path]` | Validate all profiles: check bundles exist, resolve correctly, extends references valid. |
| `bundles remove-module <bundle> <module> [--dir_path]` | Remove a module from a bundle (searches all groups). |
| `bundles show <name> [--dir_path]` | Show bundle details: groups, dependencies, and modules. |
| `bundles show-profile <name> [--dir_path]` | Show profile details: bundles, resolved modules, and foundation overlap. |
| `bundles status <name> [--groups] [--dir_path]` | Compare bundle modules against the remote Odoo instance. |
| `bundles validate [--dir_path]` | Validate ALL bundle YAMLs: circular deps, duplicate modules, resolution errors. |

**Examples:**
```bash
kctl-odoo bundles compare-profiles distribution retail manufacturing
kctl-odoo bundles compare-profiles distribution trading --modules
```

### `kctl-odoo coa-template`

Canonical COA template catalog (company.coa.template.line).

| Command | Description |
|---------|-------------|
| `coa-template create <code> <name_id> <account_type> [--name_en] [--commodity] [--kind] [--notes]` | Create one template line. |
| `coa-template delete <code> [--force]` | Delete a template line by code. |
| `coa-template export [--output]` | Export the full catalog to Excel for offline review/editing. |
| `coa-template import <input_path> [--dry_run] [--upsert]` | Bulk-import template lines from an Excel file. |
| `coa-template import-coa-r <input_path> [--wipe] [--dry_run] [--skip_duplicates]` | Bulk-import the canonical COA_R sheet (4.2.2.3 hierarchy). |
| `coa-template import-tpp-all <input_path> [--dry_run] [--upsert] [--sheet]` | Bulk-import the canonical TPP COA (universal + commodity variants). |
| `coa-template list [--code] [--name] [--account_type] [--commodity] [--kind] [--inactive] [--limit]` | List template lines with optional filters. |
| `coa-template seed <slug> [--dry_run]` | Inventory an accurate.company's JV cache → bulk-create template lines. |
| `coa-template stats` | Summarise the catalog by account_type, kind, and commodity. |

### `kctl-odoo commands`

Machine-readable command discovery (for AI agents).

| Command | Description |
|---------|-------------|
| `commands list [--json_flag] [--filter_substr]` | List all leaf commands as 'group verb' strings. |
| `commands tree [--json_flag] [--filter_substr]` | Dump the command tree as JSON. |

### `kctl-odoo companies`

Manage Odoo companies.

| Command | Description |
|---------|-------------|
| `companies apply-coa-profile <company_id> [--profile]` | Apply the COA profile to a company (create accounts, set defaults). |
| `companies bootstrap-baseline <company> [--all_companies]` | Retro-fit baseline setup on existing companies. |
| `companies business-scenario <company_id> [--scenario] [--output] [--commit] [--version]` | Run a full import scenario on a company. |
| `companies business-scenario-cleanup <company_id> [--confirm]` | Delete all E2E-TEST data from a company. |
| `companies coa-bulk-apply [--type_code] [--subgroup_code] [--skip_test] [--dry_run] [--profile]` | Apply the COA profile to ALL companies (idempotent bulk operation). |
| `companies coa-report <company_id> [--output] [--template]` | Export a company's COA setup to Excel for auditing. |
| `companies create <name> [--email] [--currency] [--parent]` | Create a new company in the Odoo instance. |
| `companies get <identifier>` | Show full details for a company by ID or name. |
| `companies list [--limit]` | List all companies in the Odoo instance. |
| `companies setup <name> <template> [--street] [--city] [--phone] [--email] [--npwp] [--warehouse_prefix] [--type_code] [--subgroup_code] [--commodity_code] [--business_year] [--company_code] [--bank] [--skip_warehouses] [--skip_fiscal_positions] [--skip_extra_journals] [--skip_report_formats] [--dry_run]` | Create and provision a new company from a template — 100% validated in one shot. |
| `companies setup-batch <csv_file> <template> [--skip_warehouses] [--skip_report_formats] [--dry_run]` | Batch-create companies from a CSV file. |
| `companies standardize-sequence <company_id> [--models] [--apply]` | Rename existing records to {company_code}/{type}/{YYYY}/{NNNNN}. |
| `companies switch <user_id> <company_id>` | Switch a user's active (default) company. |
| `companies update <identifier> [--name] [--email] [--phone] [--website]` | Update fields on an existing company. |
| `companies users <identifier> [--limit]` | List all users who have access to a company. |
| `companies validate-banks <company_id> [--fix]` | Validate bank/cash journal setup for reconciliation. |
| `companies validate-categories <company_id> [--fix]` | Validate product category configuration for a company. |
| `companies validate-coa <company_id> [--profile] [--fix]` | Validate a company's COA against the TPP Import profile. |
| `companies validate-company <company_id> [--fix]` | Run ALL 20 validators and produce a company health report card. |
| `companies validate-contracts <company_id>` | Validate Sales Contract (SC) setup for a company. |
| `companies validate-currencies <company_id> [--fix]` | Validate currency setup for a company. |
| `companies validate-journals <company_id> [--fix]` | Validate journal configuration for a company. |
| `companies validate-lots <company_id>` | Validate lot/serial tracking for a company. |
| `companies validate-partners <company_id> [--fix]` | Validate partner setup: currency, AR/AP, duplicates. |
| `companies validate-products <company_id> [--fix]` | Validate product setup: taxes, tracking, UoM, purchase method, category. |
| `companies validate-sequence <company_id> [--models]` | Report records whose document number does not match {company_code}/{type}/{YYYY}/{NNNNN}. |
| `companies validate-taxes <company_id> [--fix]` | Validate tax configuration for a company. |
| `companies validate-uom <company_id> [--fix]` | Validate UoM configuration for a company. |
| `companies validate-users <company_id>` | Validate user/role configuration for a company. |

**Examples:**
```bash
kctl-odoo companies apply-coa-profile --company-id 362
kctl-odoo companies bootstrap-baseline 338
kctl-odoo companies bootstrap-baseline _TEMPLATE_TPP_IMPORT
kctl-odoo companies bootstrap-baseline --all _
kctl-odoo companies business-scenario -c 364
```

### `kctl-odoo completions`

Generate or install shell completions.

Usage: `kctl-odoo completions [--shell] [--install]`

### `kctl-odoo compliance`

Regulatory compliance: licenses, certifications, vendor checks.

| Command | Description |
|---------|-------------|
| `compliance certifications [--product] [--limit]` | List product certifications. |
| `compliance expiring [--days]` | List all licenses and certifications expiring within N days. |
| `compliance licenses [--expiring_days] [--limit]` | List company licenses and their expiry status. |
| `compliance stats` | Compliance statistics: licenses and certifications by status. |
| `compliance summary` | Compliance statistics: licenses and certifications by status. |
| `compliance vendor-check <partner> [--limit]` | List compliance checklists for a vendor/partner. |

**Examples:**
```bash
kctl-odoo compliance certifications
kctl-odoo compliance certifications --product "Widget A"
kctl-odoo compliance expiring
kctl-odoo compliance expiring --days 60
kctl-odoo compliance licenses
```

### `kctl-odoo config`

Manage CLI configuration and profiles.

| Command | Description |
|---------|-------------|
| `config add <name> [--url] [--database] [--username] [--api_key] [--set_default]` | Add or update a profile's Odoo connection. |
| `config current` | Show the active profile and connection status. |
| `config doctor` | Diagnose all configured profiles. |
| `config init [--url] [--database] [--username] [--api_key] [--name]` | Initialize CLI configuration (interactive if no flags given). |
| `config list` | List all profiles with Odoo connection status. |
| `config migrate` | Migrate config from flat format to service-scoped format. |
| `config profiles` | Manage deployment profiles (bundle sets for different company types). |
| `config quick <name> <url> <database> <api_key> [--username] [--set_default]` | Create a profile in one line (no prompts). |
| `config remove <name> [--force] [--service_only]` | Remove a profile or just its Odoo config. |
| `config set <key> <value> [--profile_arg]` | Set a configuration value for the current service. |
| `config show [--reveal]` | Show full configuration (API keys masked by default; use --reveal to see plaintext). |
| `config test` | Test API connection with current configuration. |
| `config use <name>` | Show how to use a profile explicitly. |

**Examples:**
```bash
kctl-odoo config doctor
kctl-odoo config doctor --json
kctl-odoo config quick local http://localhost:8069 odoo_full admin
kctl-odoo config quick prod https://erp.kodeme.io kodemeio $KEY --default
kctl-odoo config set url https://erp.new.io
```

### `kctl-odoo crm`

CRM: leads, opportunities, pipeline management.

| Command | Description |
|---------|-------------|
| `crm activities [--user] [--overdue] [--limit]` | List CRM-related activities. |
| `crm convert <lead_id> [--force]` | Convert a lead to an opportunity. |
| `crm create <name> [--partner] [--email] [--phone] [--user] [--team]` | Create a new CRM lead. |
| `crm create-lead <name> [--partner] [--email] [--phone] [--user] [--team]` | Create a new CRM lead. |
| `crm get <lead_id>` | Show full lead or opportunity detail. |
| `crm leads [--stage] [--user] [--limit]` | List CRM leads. |
| `crm list [--stage] [--user] [--limit]` | List CRM leads. |
| `crm lost <lead_id> [--reason] [--force]` | Mark an opportunity as lost. |
| `crm opportunities [--stage] [--user] [--limit]` | List CRM opportunities. |
| `crm pipeline` | Show pipeline summary: opportunities by stage with counts and expected revenue. |
| `crm won <lead_id> [--force]` | Mark an opportunity as won. |

**Examples:**
```bash
kctl-odoo crm activities
kctl-odoo crm activities --overdue
kctl-odoo crm activities --user "John" --limit 20
kctl-odoo crm convert 42
kctl-odoo crm convert 42 --force
```

### `kctl-odoo cron`

Manage scheduled actions (ir.cron).

| Command | Description |
|---------|-------------|
| `cron create <name> [--model] [--code] [--interval] [--interval_type] [--active]` | Create a new scheduled action (ir.cron). |
| `cron diagnose` | Check for failed or stuck cron jobs with detailed analysis. |
| `cron disable <identifier>` | Disable a scheduled action. |
| `cron enable <identifier>` | Enable a scheduled action. |
| `cron history <identifier> [--limit]` | Show execution history (trigger records) for a scheduled action. |
| `cron list [--active_only] [--limit]` | List scheduled actions. |
| `cron run <identifier>` | Run a scheduled action immediately. |
| `cron status [--limit]` | Show active scheduled actions with overdue detection. |

**Examples:**
```bash
kctl-odoo cron create "Daily Cleanup" --model ir.cron --code "env['auto.vacuum']._gc_transient_records()" --interval 1 --interval-type days
kctl-odoo cron create "Hourly Sync" --code "env['base'].flush_all()" --interval 1 --interval-type hours
```

### `kctl-odoo currency`

Currency management and exchange rate automation.

| Command | Description |
|---------|-------------|
| `currency add <code>` | Activate a currency by code. |
| `currency check-stale [--days]` | Flag currencies with outdated exchange rates. |
| `currency rates [--code] [--days] [--limit]` | List recent exchange rates. |
| `currency update [--force]` | Trigger currency rate update via Odoo cron. |

**Examples:**
```bash
kctl-odoo currency add IDR
kctl-odoo currency add EUR
kctl-odoo currency check-stale
kctl-odoo currency check-stale --days 3
kctl-odoo currency rates
```

### `kctl-odoo dashboard`

Instance dashboard and overview.

| Command | Description |
|---------|-------------|
| `dashboard digest` | Morning coffee command — key business metrics at a glance. |
| `dashboard exec-summary` | Executive summary — all key metrics in one view. |
| `dashboard failed-emails [--limit]` | Emails that failed to send. |
| `dashboard gross-margin [--date_from] [--date_to] [--limit]` | Gross margin report — revenue vs COGS per product. |
| `dashboard info [--watch] [--interval]` | Show comprehensive Odoo instance overview. |
| `dashboard kpi` | Business KPI scorecard with pass/warn/fail thresholds. |
| `dashboard pending-approvals [--limit]` | Records awaiting approval across modules. |
| `dashboard summary [--watch] [--interval]` | Show comprehensive Odoo instance overview. |

**Examples:**
```bash
kctl-odoo dashboard digest
kctl-odoo dashboard digest --json
kctl-odoo --profile production dashboard digest
kctl-odoo dashboard exec-summary
kctl-odoo dashboard gross-margin
```

### `kctl-odoo data-quality`

Data quality: duplicates, completeness, orphans, migration audit.

| Command | Description |
|---------|-------------|
| `data-quality completeness <model> [--fields] [--limit]` | Check field completeness (fill rates) for a model. |
| `data-quality duplicates <model> [--field] [--limit]` | Find duplicate records grouped by a field. |
| `data-quality migration-audit <company> [--date] [--output] [--reference_bs] [--reference_pl]` | Migration data quality gate — 8-check audit for Accurate → Odoo migration. |
| `data-quality migration-compare <company> <accurate_profile> [--output] [--date]` | Compare every journal entry between Accurate and Odoo — Excel report. |
| `data-quality orphans [--model]` | Check for common orphan record patterns. |
| `data-quality report [--category]` | Combined data quality scorecard. |
| `data-quality validate <model> [--rules]` | Run basic data validation rules on a model. |

**Examples:**
```bash
kctl-odoo data-quality completeness res.partner
kctl-odoo data-quality completeness res.partner --fields name,email,phone,vat
kctl-odoo data-quality completeness product.template --limit 200
kctl-odoo data-quality duplicates res.partner
kctl-odoo data-quality duplicates res.partner --field email
```

### `kctl-odoo databases`

Manage Odoo databases.

| Command | Description |
|---------|-------------|
| `databases create <name> [--lang] [--explain]` | Create a new Odoo database via the database manager RPC. |
| `databases drop <name> [--force] [--explain]` | Permanently delete a database. |
| `databases duplicate <source> <target>` | Create a copy of an existing database under a new name. |
| `databases exists <name>` | Check if a database exists (exit 0 if yes, no output if not). |
| `databases languages` | List all language codes available for new database creation. |
| `databases list` | List all databases visible to the Odoo server. |
| `databases rename <old_name> <new_name>` | Rename an existing database to a new name. |

**Examples:**
```bash
kctl-odoo databases create my_new_db
kctl-odoo databases create staging_db --lang id_ID
kctl-odoo databases drop old_test_db
kctl-odoo databases drop old_test_db --force
kctl-odoo databases duplicate prod_db staging_db
```

### `kctl-odoo dd`

Alias: dashboard digest

### `kctl-odoo delivery`

Delivery & logistics: tracking, performance, returns.

| Command | Description |
|---------|-------------|
| `delivery carriers` | List configured delivery carriers. |
| `delivery list [--state] [--carrier] [--date_from] [--limit]` | List outgoing deliveries. |
| `delivery pending [--days]` | List deliveries pending beyond threshold days. |
| `delivery performance [--days]` | On-time delivery performance report. |
| `delivery returns [--limit]` | List return pickings (origin contains 'Return'). |
| `delivery tracking <name>` | Show delivery tracking detail by reference. |

**Examples:**
```bash
kctl-odoo delivery carriers
kctl-odoo delivery list
kctl-odoo delivery list --state assigned
kctl-odoo delivery list --carrier "JNE" --date-from 2025-01-01
kctl-odoo delivery pending
```

### `kctl-odoo deploy`

Deployment status and verification.

| Command | Description |
|---------|-------------|
| `deploy changelog [--days]` | Show recently installed or upgraded modules. |
| `deploy db-fix <compose_id> [--sql] [--sql_file] <dokploy_profile> [--dry_run] [--i_know_what_im_doing]` | Execute SQL directly on a Dokploy-hosted database. |
| `deploy env [--redact]` | Show key system parameters (environment configuration). |
| `deploy hotfix <compose_id> <module> <dokploy_profile> [--odoo_profile] [--force] [--i_know_what_im_doing] [--project_dir]` | Deploy an emergency hotfix to a running container. |
| `deploy hotfix-rollback <compose_id> <dokploy_profile> [--odoo_profile] [--i_know_what_im_doing]` | Roll back all hotfixes by recreating containers from the clean image. |
| `deploy hotfix-status <compose_id> <dokploy_profile> <odoo_profile>` | Show active hotfixes on a target. |
| `deploy neutralize [--admin_password] [--company_prefix] [--dry_run]` | Neutralize a staging Odoo instance after cloning from production. |
| `deploy status` | Show deployment status overview. |
| `deploy uninstall <compose_id> [--modules] [--profile] <dokploy_profile> [--wait] [--health_url] [--skip_cleanup]` | Uninstall modules on a Dokploy-hosted Odoo instance via init container. |
| `deploy upgrade <compose_id> [--modules] <dokploy_profile> [--wait] [--health_url] [--skip_cleanup]` | Upgrade modules on a Dokploy-hosted Odoo instance via init container. |
| `deploy verify <profile_name> [--install_dir]` | Verify that a remote instance matches a deployment profile. |

**Examples:**
```bash
kctl-odoo deploy changelog
kctl-odoo deploy changelog --days 30
kctl-odoo deploy db-fix h1I7b35s8w9UVOhbqLNgT -dp idtpp \
kctl-odoo deploy db-fix h1I7b35s8w9UVOhbqLNgT -dp idtpp \
kctl-odoo deploy db-fix h1I7b35s8w9UVOhbqLNgT -dp idtpp -f fix.sql
```

### `kctl-odoo dev`

Development tools for Odoo.

| Command | Description |
|---------|-------------|
| `dev audit [--module] [--all_modules] [--min_score] [--output]` | Comprehensive module audit with scored report card. |
| `dev audit-api [--module]` | Audit FastAPI router code for common performance issues. |
| `dev audit-blocking [--module]` | Find blocking operations inside HTTP controllers. |
| `dev audit-compute [--module]` | Find computed fields without store=True. |
| `dev audit-fix <module> [--dry_run] [--categories]` | Auto-fix safe audit issues for a module. |
| `dev audit-logic [--module]` | Audit Odoo business logic for common errors. |
| `dev audit-ou [--module]` | Audit Operating Unit (multi-branch) isolation gaps. |
| `dev audit-prompt <module> [--output]` | Generate an AI agent prompt from audit results for human-in-loop fixes. |
| `dev audit-ui <module>` | Comprehensive Odoo UI / XML static audit. |
| `dev audit-views [--module]` | Audit XML views for performance — field count, deprecated patterns. |
| `dev check-conventions [--module]` | Check Kodemeio coding conventions across private modules. |
| `dev check-log-level` | Check if debug logging is enabled (production risk). |
| `dev check-translations <module> [--lang]` | Validate PO file placeholder consistency. |
| `dev clear-field-cache` | Clear cached model field definitions. |
| `dev cloc [--module]` | Show lines of code information for installed modules. |
| `dev coverage-report` | Show test coverage summary across all private modules. |
| `dev deps-reverse <module>` | Show what modules depend on this module (reverse dependencies). |
| `dev deps-tree <module>` | Show dependency tree for a module. |
| `dev dev-disable <app_name>` | Disable dev mode for an app. |
| `dev dev-enable <app_name>` | Enable dev mode for an app. |
| `dev dev-status [--app_name]` | Show dev mode status for one or all apps. |
| `dev export-translations <module> [--lang] [--fmt] [--output]` | Export translations for a module using the base.language.export wizard. |
| `dev find-overrides <model>` | List all modules that inherit/extend a model. |
| `dev generate-cmd <model> [--group_name] [--output]` | Auto-generate a CLI command file from live Odoo model introspection. |
| `dev import-translations <file> [--lang] [--overwrite]` | Import translations from a PO or CSV file. |
| `dev languages` | List installed and available languages. |
| `dev model-fields <model> [--stored_only] [--format_]` | Show model fields with types — useful for building CLI commands. |
| `dev model-info <model_name>` | Show detailed field information for an Odoo model. |
| `dev module-health <module>` | Comprehensive health check for a single private module. |
| `dev profile` | Show CPU and memory stats of the running Odoo process via JSON-RPC. |
| `dev regenerate-assets [--force]` | Regenerate web assets by clearing asset attachments. |
| `dev release-check <module>` | Pre-release validation for a module before version bump. |
| `dev routes` | List HTTP routes and JSON-RPC endpoints registered in Odoo. |
| `dev unused-xml-ids [--module] [--limit]` | Find XML IDs defined but potentially unreferenced. |
| `dev watch <module> [--service] [--interval]` | Watch Python/XML files and auto-upgrade module on change. |

**Examples:**
```bash
kctl-odoo dev audit sfa_management
kctl-odoo dev audit --all
kctl-odoo dev audit --all --min-score 70
kctl-odoo dev audit sfa_management --json
kctl-odoo dev audit --all -o audit_report.json
```

### `kctl-odoo di`

Alias: dashboard info

### `kctl-odoo diff`

Compare Odoo instances across profiles.

| Command | Description |
|---------|-------------|
| `diff config <profile_a> <profile_b> [--key]` | Compare ir.config_parameter values between two instances. |
| `diff modules <profile_a> <profile_b> [--output]` | Compare installed modules between two Odoo instances. |
| `diff users <profile_a> <profile_b>` | Compare user lists between two Odoo instances. |

**Examples:**
```bash
kctl-odoo diff config production staging
kctl-odoo diff config production staging --key web.base
kctl-odoo diff modules production staging
kctl-odoo diff modules mac-odoo-erp tpp-odoo-erp -o diff.xlsx
kctl-odoo diff users production staging
```

### `kctl-odoo doctor`

Troubleshooting, diagnostics & health checks.

| Command | Description |
|---------|-------------|
| `doctor ai-summary` | Compact machine-readable environment summary for AI agents. |
| `doctor check [--watch] [--interval]` | Check Odoo instance health. |
| `doctor check-config` | Validate Odoo instance configuration against best practices. |
| `doctor check-timezone [--expected] [--fix]` | Validate that all users and resource calendars use the same timezone. |
| `doctor check-xml-ids [--limit]` | Check for potentially broken XML IDs (ir.model.data with missing references). |
| `doctor fix-stuck <module> [--force]` | Reset a stuck module to installed/uninstalled state. |
| `doctor mail-diagnostics` | Check mail server configuration and queue status. |
| `doctor module-conflicts` | Find modules with overlapping model inheritance that may conflict. |
| `doctor readiness-check [--output] [--company_id] [--reference] [--reference_company_id] [--include_reference] [--per_company]` | Generate a multi-sheet production readiness audit Excel. |
| `doctor recent-changes [--days] [--limit]` | Show recently changed modules. |
| `doctor report [--output] [--quick] [--section_filter]` | Instance diagnostics and health reporting. |
| `doctor self-test [--verbose] [--group_filter]` | Run one read-only command from each command group and report PASS/FAIL/SKIP. |
| `doctor stuck-modules` | Find modules stuck in transitional states. |
| `doctor unused-modules [--limit]` | Find installed modules with zero records in their custom models. |
| `doctor version-info` | Show Odoo version, database, CLI version, and module statistics. |

**Examples:**
```bash
kctl-odoo --json doctor ai-summary
kctl-odoo -p prod --json doctor ai-summary
kctl-odoo troubleshoot check-config
kctl-odoo troubleshoot check-config --json
kctl-odoo doctor check-timezone
```

### `kctl-odoo dq`

Alias: data-quality

### `kctl-odoo dunning`

AR collection: dunning cases, follow-up, escalation.

| Command | Description |
|---------|-------------|
| `dunning cases [--level] [--limit]` | List dunning cases. |
| `dunning levels` | List dunning levels with delay days and actions. |
| `dunning list [--level] [--limit]` | List dunning cases. |
| `dunning run [--dry_run]` | Trigger dunning evaluation: create or escalate overdue cases. |
| `dunning stats` | Dunning statistics: cases by level and total overdue amount. |
| `dunning summary` | Dunning statistics: cases by level and total overdue amount. |

**Examples:**
```bash
kctl-odoo dunning cases
kctl-odoo dunning cases --level "Level 2" --limit 20
kctl-odoo dunning levels
kctl-odoo dunning cases
kctl-odoo dunning cases --level "Level 2" --limit 20
```

### `kctl-odoo dx`

Alias: doctor

### `kctl-odoo e2e`

E2E browser testing via Playwright.

| Command | Description |
|---------|-------------|
| `e2e discover [--dry_run]` | Discover Odoo menus and generate page test registry. |
| `e2e install` | Install Playwright browsers and dependencies. |
| `e2e list [--scenario]` | List all discovered E2E tests. |
| `e2e report` | Open Playwright HTML test report. |
| `e2e screenshots [--module] [--output]` | Capture screenshots of all accessible Odoo menu pages. |
| `e2e test [--scenario] [--headed] [--ui] [--debug] [--screenshots] [--video] [--mobile] [--smoke] [--module] [--grep]` | Run Playwright E2E tests against an Odoo instance. |

**Examples:**
```bash
kctl-odoo e2e discover            # Generate registry
kctl-odoo e2e discover --dry-run  # Preview only
kctl-odoo e2e install
kctl-odoo e2e list              # List all tests
kctl-odoo e2e list login        # List login scenario tests
```

### `kctl-odoo events`

Events: event management and registrations.

| Command | Description |
|---------|-------------|
| `events cancel-registration <registration_id>` | Cancel an event registration. |
| `events confirm-registration <registration_id>` | Confirm an event registration. |
| `events get <event_id>` | Get event detail with registration count. |
| `events list [--upcoming] [--limit]` | List events. |
| `events registrations <event_id> [--state] [--limit]` | List registrations for an event. |
| `events stats <event_id>` | Registration statistics for an event: total, confirmed, draft, cancelled, revenue. |
| `events summary <event_id>` | Registration statistics for an event: total, confirmed, draft, cancelled, revenue. |
| `events upcoming [--days]` | List events starting within N days. |

**Examples:**
```bash
kctl-odoo events cancel-registration 10
kctl-odoo events confirm-registration 10
kctl-odoo events get 5
kctl-odoo events list
kctl-odoo events list --upcoming --limit 10
```

### `kctl-odoo export`

Export model data.

| Command | Description |
|---------|-------------|
| `export records <model> [--domain] [--fields] [--fmt] [--limit] [--output] [--with_id]` | Export records from a model. |

**Examples:**
```bash
kctl-odoo export records res.partner --fields name,email --limit 100
kctl-odoo export records res.partner -d '[["is_company","=",true]]' -f name,phone --format csv -o partners.csv
kctl-odoo export records res.partner --with-id --format csv -o partners_with_ids.csv
```

### `kctl-odoo fastapi`

Test FastAPI addon endpoints directly (not JSON-RPC).

| Command | Description |
|---------|-------------|
| `fastapi audit <app_name>` | Audit a FastAPI app's OpenAPI spec for quality and completeness. |
| `fastapi audit-live <app_name> [--quick]` | Live audit of a running FastAPI app — tests actual HTTP responses. |
| `fastapi audit-standards [--module] [--fix_hint]` | Cross-check FastAPI/PWA backends against standardized patterns. |
| `fastapi bench <app_name> <endpoint> [--count] [--token]` | Benchmark response time for a FastAPI endpoint. |
| `fastapi endpoints <app_name>` | List FastAPI endpoints from OpenAPI schema. |
| `fastapi health <app_name>` | Check if a FastAPI app router is responding. |
| `fastapi openapi <app_name> [--output]` | Extract OpenAPI spec from a FastAPI addon and save or display it. |
| `fastapi routes <app_name> [--tag]` | List all FastAPI routes for a module from its OpenAPI spec. |
| `fastapi test <app_name> <path> [--method] [--body] [--token]` | Call a FastAPI endpoint directly. |
| `fastapi validate <app_name>` | Validate OpenAPI spec completeness: schemas, operation IDs, response codes. |

**Examples:**
```bash
kctl-odoo fastapi audit tpm
kctl-odoo fastapi audit sfa
kctl-odoo fastapi audit-live tpm
kctl-odoo fastapi audit-live all
kctl-odoo fastapi audit-live sfa --quick
```

### `kctl-odoo fleet`

Fleet management: vehicles, contracts, services.

| Command | Description |
|---------|-------------|
| `fleet contracts [--expiring_days] [--limit]` | List fleet contracts, optionally filtered by expiry window. |
| `fleet costs [--vehicle] [--period]` | Summarize fleet costs grouped by vehicle. |
| `fleet expiring [--days]` | Show contracts and insurances expiring within N days. |
| `fleet get <vehicle_id>` | Get vehicle detail by ID. |
| `fleet get-vehicle <vehicle_id>` | Get vehicle detail by ID. |
| `fleet list [--state] [--driver] [--limit]` | List fleet vehicles. |
| `fleet log-odometer <vehicle> <value>` | Log an odometer reading for a vehicle. |
| `fleet services [--vehicle] [--limit]` | List fleet service logs. |
| `fleet summary` | Fleet dashboard: vehicle count, expiring contracts, services due. |
| `fleet vehicles [--state] [--driver] [--limit]` | List fleet vehicles. |

**Examples:**
```bash
kctl-odoo fleet contracts
kctl-odoo fleet contracts --expiring-days 60
kctl-odoo fleet costs
kctl-odoo fleet costs --period year
kctl-odoo fleet costs --vehicle "Fleet/001"
```

### `kctl-odoo forms`

Form requests: types, submissions, approval.

| Command | Description |
|---------|-------------|
| `forms approve <request_id> [--force]` | Approve a form request. |
| `forms get <request_id>` | Show form request detail with lines and attachments. |
| `forms pending [--form_type] [--limit]` | List pending/draft form requests awaiting action. |
| `forms reject <request_id> [--reason] [--force]` | Reject a form request. |
| `forms types` | List available form types. |

**Examples:**
```bash
kctl-odoo forms approve 42
kctl-odoo forms approve 42 --force
kctl-odoo forms get 42
kctl-odoo forms pending
kctl-odoo forms pending --type "Leave Request" --limit 20
```

### `kctl-odoo hc`

Alias: troubleshoot check

### `kctl-odoo helpdesk`

Helpdesk: tickets, teams, SLA tracking.

| Command | Description |
|---------|-------------|
| `helpdesk assign <ticket_id> <user>` | Assign a helpdesk ticket to a user. |
| `helpdesk close <ticket_id> [--force]` | Close a helpdesk ticket (move to last stage). |
| `helpdesk create <subject> [--partner] [--team] [--priority]` | Create a new helpdesk ticket. |
| `helpdesk create-ticket <subject> [--partner] [--team] [--priority]` | Create a new helpdesk ticket. |
| `helpdesk get <ticket_id>` | Get helpdesk ticket detail with messages. |
| `helpdesk get-ticket <ticket_id>` | Get helpdesk ticket detail with messages. |
| `helpdesk list [--stage] [--team] [--assigned] [--limit]` | List helpdesk tickets. |
| `helpdesk sla-breaches [--limit]` | List tickets that have breached their SLA deadline. |
| `helpdesk summary` | Helpdesk dashboard: ticket counts by stage and SLA breaches. |
| `helpdesk team-load` | Show ticket count per helpdesk team. |
| `helpdesk tickets [--stage] [--team] [--assigned] [--limit]` | List helpdesk tickets. |

**Examples:**
```bash
kctl-odoo helpdesk assign 42 admin
kctl-odoo helpdesk assign 42 "John Smith"
kctl-odoo helpdesk close 42
kctl-odoo helpdesk close 42 --force
kctl-odoo helpdesk create-ticket "Login issue"
```

### `kctl-odoo history`

View local operation history (module ops, backups, health checks, deployments).

| Command | Description |
|---------|-------------|
| `history backups [--database] [--limit]` | Show backup operation history. |
| `history clear [--force]` | Clear all operation history. |
| `history deployments [--database] [--limit]` | Show deployment history. |
| `history health [--database] [--limit]` | Show health check history. |
| `history modules [--database] [--limit]` | Show module install/update operation history. |

**Examples:**
```bash
kctl-odoo history backups
kctl-odoo history backups -d odoo_prod
kctl-odoo history clear
kctl-odoo history clear --force
kctl-odoo history deployments
```

### `kctl-odoo hr`

HR: employees, departments, attendance, leaves, payroll, expenses.

| Command | Description |
|---------|-------------|
| `hr approve-expense <sheet_id> [--force]` | Approve an expense sheet (hr.expense.sheet). |
| `hr approve-leave <leave_id> [--force]` | Approve a leave request by ID. |
| `hr attendance-report [--date_from] [--date_to] [--employee] [--limit]` | Attendance report for a date range. |
| `hr attendance-today [--limit]` | Who's checked in today (hr.attendance). |
| `hr birthdays [--days] [--limit]` | Upcoming employee birthdays. |
| `hr confirm-payslip [--month] [--ids] [--force]` | Confirm (set to done) draft/verify payslips. |
| `hr contracts [--state] [--limit]` | Contract status (hr.contract). |
| `hr create-expense <employee> <product> <amount> [--description] [--dry_run] [--force]` | Create an expense record (hr.expense). |
| `hr departments [--limit]` | Department list (hr.department). |
| `hr employee` | Employee maintenance helpers: normalize-names, archive-demo, link-user. |
| `hr employees [--department] [--active] [--limit]` | Employee directory (hr.employee). |
| `hr expense-summary [--period]` | Expense dashboard — sheets by state, total amounts. |
| `hr expenses [--state] [--employee] [--limit]` | List expense sheets (hr.expense.sheet). |
| `hr generate-payslip <month> [--employee] [--force]` | Generate payslips for a period. |
| `hr get <identifier>` | Get employee details by name or ID. |
| `hr get-employee <identifier>` | Get employee details by name or ID. |
| `hr get-payslip <payslip_id>` | Get payslip detail by ID. |
| `hr import-attendance <file> [--dry_run]` | Import attendance records from CSV. |
| `hr leave-balance [--employee] [--leave_type] [--limit]` | Leave balances (hr.leave.allocation). |
| `hr leave-summary [--department]` | Leave summary by department — approved leaves count and total days. |
| `hr leaves [--state] [--employee] [--limit]` | List leave requests (hr.leave). |
| `hr list [--department] [--active] [--limit]` | Employee directory (hr.employee). |
| `hr payslips [--state] [--employee] [--limit]` | List payslips (hr.payslip). |
| `hr refuse-leave <leave_id> [--force]` | Refuse a leave request by ID. |
| `hr reimburse-expense <sheet_id> [--journal] [--force]` | Register reimbursement for an approved expense sheet. |
| `hr request-leave <employee> <leave_type> <date_from> <date_to> [--reason] [--dry_run] [--force]` | Create a leave request (hr.leave). |
| `hr submit-expense <sheet_id> [--force]` | Submit an expense report for approval. |
| `hr summary` | Show an HR dashboard: employee headcount and leave request summary. |

**Examples:**
```bash
kctl-odoo hr expense-approve 10 --force
kctl-odoo hr expense-approve 10
kctl-odoo hr leave-approve 42 --force
kctl-odoo hr leave-approve 42
kctl-odoo hr attendance-report --date-from 2026-03-01 --date-to 2026-03-31
```

### `kctl-odoo import`

Import data into Odoo models.

| Command | Description |
|---------|-------------|
| `import guide` | Show the recommended data import order and CSV formats. |
| `import inventory <file> [--dry_run]` | Import inventory levels (stock quantities). |
| `import opening-balances <file> [--journal] [--date] [--ref] [--dry_run]` | Import opening balances as a journal entry. |
| `import records <model> <file> [--dry_run] [--batch_size]` | Import records into a model from CSV or JSON. |
| `import template <model> [--format] [--required_only] [--output]` | Generate an import template file for a model. |
| `import validate <model> <file>` | Validate an import file against a model without importing. |

**Examples:**
```bash
kctl-odoo import inventory stock_levels.csv
kctl-odoo import inventory stock_levels.csv --dry-run
kctl-odoo import opening-balances opening.csv --date 2026-01-01
kctl-odoo import opening-balances opening.csv --journal OBL --dry-run
kctl-odoo import records res.partner partners.json
```

### `kctl-odoo integration`

Integration & connectivity operations.

| Command | Description |
|---------|-------------|
| `integration oauth [--limit]` | List OAuth providers. |
| `integration send-bus <channel> <message>` | Send a message to the Odoo bus channel. |
| `integration test-smtp [--server_id]` | Test SMTP connection for outgoing mail servers. |
| `integration webhooks [--limit]` | List webhook-type automated actions. |

**Examples:**
```bash
kctl-odoo integration oauth
kctl-odoo integration oauth --json
kctl-odoo integration send-bus my_channel "hello"
kctl-odoo integration send-bus my_channel '{"type":"reload"}'
kctl-odoo integration test-smtp
```

### `kctl-odoo intercompany`

Same-DB intercompany automation: status, retry, config.

| Command | Description |
|---------|-------------|
| `intercompany config-set <company> [--target_companies] [--default_po_user] [--notify_user] [--active]` | Update an ic.config row. |
| `intercompany config-show [--company]` | Show ic.config rows. |
| `intercompany dry-run <picking_id>` | Preview the PO payload for a picking without committing. |
| `intercompany errors [--company] [--limit]` | List pickings stuck in ic_sync_state=error with messages. |
| `intercompany pending [--company] [--limit]` | List pickings stuck in ic_sync_state=pending. |
| `intercompany retry <picking_ids>` | Force re-enqueue for the given picking IDs. |
| `intercompany retry-all-errors` | Bulk re-enqueue all pickings in ic_sync_state=error. |
| `intercompany status` | Show ic.config summary + stuck-picking counts. |

### `kctl-odoo inv`

Alias: inventory

### `kctl-odoo inventory`

Inventory: stock levels, transfers, adjustments, lots, scrap.

| Command | Description |
|---------|-------------|
| `inventory adjust <product> <qty> [--location] [--force]` | Quick inventory adjustment for a single product. |
| `inventory adjustments <product_name> <location_name> <qty> [--reason] [--dry_run] [--force]` | Create an inventory adjustment (Odoo 18 stock.quant method). |
| `inventory close-period [--period_end]` | Period-end inventory validation. |
| `inventory create-transfer <from_wh> <to_wh> <product_name> <qty> [--dry_run] [--force]` | Create an internal stock transfer between warehouses. |
| `inventory list [--warehouse] [--limit]` | Show stock levels per product (internal locations). |
| `inventory locations [--warehouse] [--limit]` | List stock locations. |
| `inventory lots [--product] [--expired] [--limit]` | List stock lots / serial numbers. |
| `inventory low-stock [--threshold] [--limit]` | List products whose on-hand quantity is below a minimum threshold. |
| `inventory manufacturing` | Show a manufacturing dashboard: production orders grouped by state. |
| `inventory product-stock <product>` | Detailed stock for one product across all internal locations. |
| `inventory reorder-rules [--triggered] [--limit]` | List reorder rules (stock.warehouse.orderpoint). |
| `inventory scrap <product_name> <qty> [--reason] [--force]` | Create and validate a scrap order. |
| `inventory stock-levels [--warehouse] [--limit]` | Show stock levels per product (internal locations). |
| `inventory stock-moves [--product] [--date_from] [--limit]` | List stock moves (detailed movement history). |
| `inventory stuck [--days] [--limit]` | List transfers that have been waiting or ready longer than expected. |
| `inventory summary [--warehouse]` | Show an inventory dashboard: stock quant counts and pending transfers. |
| `inventory transfers [--state] [--picking_type] [--date_from] [--partner] [--limit]` | List stock transfers (pickings). |
| `inventory turnover [--days] [--limit]` | Inventory turnover analysis — fast vs slow moving products. |
| `inventory validate-transfer <name> [--force]` | Validate (confirm) a stock transfer. |
| `inventory valuation [--limit]` | Show inventory valuation — stock value per product. |
| `inventory warehouses` | List warehouses. |

**Examples:**
```bash
kctl-odoo inventory adjust --product "Widget A" --qty 100
kctl-odoo inventory adjust --product 42 --qty 50 --location "WH/Stock"
kctl-odoo inventory adjust --product "Widget" --qty 0 --force
kctl-odoo inventory adjustment --product "Widget" --location "WH/Stock" --qty 100
kctl-odoo inventory adjustment --product 42 --location 8 --qty 50 --reason "Cycle count"
```

### `kctl-odoo jobs`

Manage OCA queue jobs (requires queue_job module).

| Command | Description |
|---------|-------------|
| `jobs cancel <ids>` | Cancel queue jobs by setting state to cancelled. |
| `jobs cleanup [--days] [--force]` | Delete old completed and cancelled queue jobs. |
| `jobs failed [--limit]` | Show failed queue jobs with error details. |
| `jobs list [--state] [--limit]` | List queue jobs. |
| `jobs retry <ids>` | Requeue failed jobs by setting state to pending. |
| `jobs retry-all [--force]` | Requeue all failed jobs. |
| `jobs stats [--watch] [--interval]` | Show queue job statistics by state. |
| `jobs summary [--watch] [--interval]` | Show queue job statistics by state. |

### `kctl-odoo kpi`

KPI reports via MIS Builder framework.

| Command | Description |
|---------|-------------|
| `kpi instances [--limit]` | List MIS report instances (configured reports with date ranges). |
| `kpi list` | List MIS report templates. |
| `kpi run <instance_id>` | Compute and display a MIS report instance result. |

**Examples:**
```bash
kctl-odoo kpi instances
kctl-odoo kpi instances --limit 10
kctl-odoo kpi list
kctl-odoo kpi run 3
```

### `kctl-odoo lint`

Lint and validate Odoo modules against best practices.

| Command | Description |
|---------|-------------|
| `lint all [--strict] [--summary_only]` | Lint ALL private modules and show a summary report. |
| `lint full [--strict]` | Run all linters: module checks, XML, manifests, security, N+1, ruff. |
| `lint manifests [--name] [--strict]` | Batch manifest linting using manifest_cmd conventions. |
| `lint module <name> [--strict]` | Lint a single private module against Odoo 18 best practices. |
| `lint ruff [--name] [--fix]` | Run ruff linter on private module Python code. |
| `lint security [--name]` | Check every model has a corresponding ir.model.access.csv row. |
| `lint summary` | Quick lint summary showing CLEAN/WARN/FAIL per module. |
| `lint xml [--name]` | XML-specific lint: deprecated attributes, encoding declarations, indentation. |

**Examples:**
```bash
kctl-odoo lint summary
```

### `kctl-odoo local`

Local Docker Compose development environment.

| Command | Description |
|---------|-------------|
| `local aggregate` | Fetch OCA repositories via git-aggregator. |
| `local build [--no_cache]` | Build Docker image. |
| `local clear-assets [--database]` | Clear compiled asset bundles (CSS/JS cache). |
| `local db-create <name> [--modules] [--profile]` | Create a new database via Docker. |
| `local db-drop <name> [--force]` | Drop a database via Docker (irreversible). |
| `local db-list` | List databases via Docker. |
| `local db-reset <database> [--with_demo] [--modules] [--force]` | Drop and recreate a database (irreversible). |
| `local down` | Stop all containers. |
| `local exec <command>` | Execute a command inside the Odoo container. |
| `local install [--modules] [--bundle] [--groups] [--database] [--no_demo]` | Install modules via Docker (no JSON-RPC timeout). |
| `local install-bundles [--database] [--tier] [--all_groups] [--single] [--dry_run]` | Install all bundles by tier (core -> oca -> private). |
| `local install-profiles [--profiles] [--dry_run] [--no_demo]` | Install deployment profiles (creates databases + installs bundles). |
| `local lint-js [--module] [--fix]` | Lint JavaScript files in private Odoo modules. |
| `local post-uninstall <database> [--fix]` | Run post-uninstall health checks on a local database. |
| `local reload` | Restart Odoo and clear assets cache for development. |
| `local restart [--service]` | Restart container(s). |
| `local shell [--database] [--db]` | Open interactive Odoo shell. |
| `local status` | Show container status. |
| `local test <module> [--tags] [--database] [--clean]` | Run Odoo tests for a module. |
| `local up [--tunnel] [--debug] [--cron]` | Start the development environment (docker compose up). |
| `local update <modules> [--database] [--safe]` | Update modules via Docker. |

**Examples:**
```bash
kctl-odoo local clear-assets
kctl-odoo local clear-assets -d odoo_full
kctl-odoo local db-create odoo_full
kctl-odoo local db-create odoo_test -m sale,stock
kctl-odoo local db-create mac_odoo_erp_light --profile erp-light
```

### `kctl-odoo logs`

Stream and analyze Odoo logs.

| Command | Description |
|---------|-------------|
| `logs errors [--days] [--limit]` | Show recent errors from ir.logging (works remotely via JSON-RPC). |
| `logs follow [--level] [--lines] [--service]` | Stream Docker container logs in real time. |
| `logs search <pattern> [--days] [--limit]` | Search ir.logging records matching a pattern. |
| `logs tail [--compose_id] [--dokploy_profile] [--service] [--lines] [--follow] [--level] [--module] [--request] [--worker] [--grep]` | Unified log tail for local + remote Odoo with structured filters. |

**Examples:**
```bash
kctl-odoo logs errors
kctl-odoo logs errors --days 1 --limit 20
kctl-odoo logs follow
kctl-odoo logs follow --level ERROR --lines 50
kctl-odoo logs follow --service db
```

### `kctl-odoo mail`

Manage Odoo mail system.

| Command | Description |
|---------|-------------|
| `mail cancel <ids>` | Cancel emails by setting state to cancel. |
| `mail cleanup [--days] [--force]` | Delete old sent and cancelled emails. |
| `mail failed [--limit]` | Show failed emails with error details. |
| `mail queue [--watch] [--interval]` | Show mail queue summary by state. |
| `mail retry <ids>` | Retry failed emails by resetting state to outgoing. |
| `mail send <to> [--subject] [--body] [--dry_run]` | Send an email via Odoo mail.mail. |
| `mail status` | Comprehensive mail system health overview. |
| `mail templates [--limit]` | List email templates. |
| `mail test <server_id> [--to]` | Test SMTP server connection. |

**Examples:**
```bash
kctl-odoo mail cancel 42,43
kctl-odoo mail cancel failed
kctl-odoo mail cleanup
kctl-odoo mail cleanup --days 60
kctl-odoo mail cleanup --force
```

### `kctl-odoo maintenance`

Database maintenance, health checks, and period-close validation.

| Command | Description |
|---------|-------------|
| `maintenance auto-fix [--dry_run]` | Safe auto-fix for common maintenance issues. |
| `maintenance auto-report [--days]` | Show current maintenance stats. |
| `maintenance auto-run [--dry_run]` | Full maintenance pass. |
| `maintenance auto-schedule` | Show instructions for scheduling auto-maintain via system cron. |
| `maintenance autovacuum` | Trigger Odoo's built-in autovacuum (ir.autovacuum). |
| `maintenance check-data [--category]` | Comprehensive data integrity checks across 7 categories. |
| `maintenance check-financial-statements [--date] [--period_start]` | Financial statement integrity checks for P&L, Balance Sheet, and Cash Flow. |
| `maintenance clean-transients [--days]` | Delete old transient model records (wizards). |
| `maintenance db-stats` | Show database size and growth indicators. |
| `maintenance health-report` | Generate a comprehensive daily health report. |
| `maintenance monthly-close [--period_end]` | Combined monthly close validation (accounting + inventory). |

**Examples:**
```bash
kctl-odoo maintenance auto-fix --dry-run
kctl-odoo maintenance auto-fix
kctl-odoo maintenance auto-fix --json
kctl-odoo maintenance auto-report
kctl-odoo maintenance auto-report --days 14
```

### `kctl-odoo manifest`

Validate and analyze Odoo module manifests.

| Command | Description |
|---------|-------------|
| `manifest circular` | Detect circular dependencies across all private modules. |
| `manifest deps <module>` | Show dependency tree for a module (static, from __manifest__.py). |
| `manifest lint [--module]` | Kodemeio conventions: depends ordering, description present, author set. |
| `manifest report` | Full manifest health report across all private modules. |
| `manifest validate [--module]` | Check __manifest__.py: required keys, version format, installable=True. |
| `manifest versions` | Version consistency check across all private modules. |

**Examples:**
```bash
kctl-odoo manifest circular
kctl-odoo manifest deps my_module
kctl-odoo manifest deps sale
kctl-odoo manifest lint
kctl-odoo manifest lint my_module
```

### `kctl-odoo master-data`

Configure Odoo master data (taxes, accounts, journals, warehouses, etc.).

| Command | Description |
|---------|-------------|
| `master-data accounts [--account_type]` | List chart of accounts. |
| `master-data activate-currency <code>` | Activate a currency. |
| `master-data audit` | Audit configuration against best practices and score as percentage. |
| `master-data create-account <code> <name> [--account_type]` | Create an account in the chart of accounts. |
| `master-data create-fiscal-position <name> [--auto_apply]` | Create a fiscal position. |
| `master-data create-journal <name> <code> [--journal_type]` | Create an accounting journal. |
| `master-data create-operating-unit <name> <code> [--company_id] [--partner_id]` | Create an operating unit. |
| `master-data create-payment-term <name>` | Create a payment term. |
| `master-data create-pricelist <name>` | Create a pricelist. |
| `master-data create-tax <name> <amount> [--use] [--amount_type]` | Create a tax. |
| `master-data create-warehouse <name> <code> [--company_id]` | Create a warehouse. |
| `master-data currencies [--all_currencies]` | List currencies. |
| `master-data fiscal-positions` | List fiscal positions. |
| `master-data journals` | List accounting journals. |
| `master-data operating-units` | List operating units. |
| `master-data payment-terms` | List payment terms. |
| `master-data pricelists [--prefix] [--limit]` | List pricelists. |
| `master-data set-setting <key> <value>` | Set an Odoo configuration setting (ir.config_parameter). |
| `master-data settings` | Show key Odoo configuration settings. |
| `master-data taxes [--use]` | List taxes. |
| `master-data warehouses` | List warehouses. |

**Examples:**
```bash
kctl-odoo master-data audit
kctl-odoo master-data audit --json
kctl-odoo --profile production master-data audit
kctl-odoo master-data pricelists
kctl-odoo master-data pricelists --prefix TLN-
```

### `kctl-odoo mi`

Alias: modules install <names>

Usage: `kctl-odoo mi <names>`

### `kctl-odoo migrate`

Database migration tools — audit source, validate target, compare.

| Command | Description |
|---------|-------------|
| `migrate audit-source [--source]` | Audit source data quality before migration. |
| `migrate column-diff <table> [--source] [--target]` | Compare column types for a model between source and target. |
| `migrate dry-run <model> [--source] [--target] [--limit]` | Simulate migration for a model — show type mismatches. |
| `migrate field-map <source> <target>` | Auto-detect field differences between two profiles. |
| `migrate status <source> <target>` | Show migration status: compare source and target profiles. |
| `migrate tables [--target] [--limit] [--min_records]` | Show table record counts on the target instance. |
| `migrate validate [--target]` | Post-migration validation checks on the target database. |

**Examples:**
```bash
kctl-odoo migrate audit-source
kctl-odoo migrate audit-source --source old-system
kctl-odoo migrate column-diff res.partner --source old --target new
kctl-odoo migrate dry-run res.partner --source old --target new
kctl-odoo migrate dry-run sale.order --source old --target new --limit 20
```

### `kctl-odoo mis-reports`

MIS Builder templates + computed instances.

| Command | Description |
|---------|-------------|
| `mis-reports describe` | Print a field-level reference for every MIS Builder model. |
| `mis-reports instances` | Manage MIS report instances (mis.report.instance). |
| `mis-reports kpis` | Manage KPIs on a template (mis.report.kpi). |
| `mis-reports queries` | Manage custom data-source queries (mis.report.query). |
| `mis-reports styles` | Manage MIS report styles (mis.report.style). |
| `mis-reports subkpis` | Manage sub-KPIs — adds columns within each KPI. |
| `mis-reports subreports` | Manage embedded sub-reports (mis.report.subreport). |
| `mis-reports templates` | Manage MIS report templates (mis.report). |

### `kctl-odoo ml`

Alias: modules list

Usage: `kctl-odoo ml [--state]`

### `kctl-odoo mnt`

Alias: maintenance

### `kctl-odoo modules`

Manage Odoo modules.

| Command | Description |
|---------|-------------|
| `modules audit [--source] [--status_filter] [--model_detail] [--markdown_out] [--private_root]` | Audit installed modules by row count — find simplification candidates. |
| `modules audit-report [--source] [--output] [--fast]` | Comprehensive module audit report as Excel workbook. |
| `modules check <name>` | Check if a module is installed (exit 0 if yes, exit 1 if not). |
| `modules deps <name> [--depth]` | Show module install dependency tree. |
| `modules diff-live <profile_a> <profile_b>` | Compare installed modules between two kctl-odoo connection profiles. |
| `modules diff-snapshots <file_a> <file_b>` | Compare two snapshot JSON files. |
| `modules install <names>` | Install modules. |
| `modules list [--state] [--limit]` | List modules. |
| `modules rdeps <name> [--depth]` | Show reverse dependencies (modules that depend on this one). |
| `modules scan` | Scan for new or updated modules (update module list). |
| `modules search <query> [--limit]` | Search for modules by name or description. |
| `modules snapshot [--output] [--state]` | Export current module state to a JSON snapshot file. |
| `modules uninstall <names> [--force]` | Uninstall modules. |
| `modules upgrade <names> [--explain]` | Upgrade modules. |

**Examples:**
```bash
kctl-odoo modules audit
kctl-odoo modules audit --source private --status UNUSED,LOW
kctl-odoo modules audit -m report.md --model-detail
kctl-odoo -p local-tpp-odoo-erp modules audit -m tpp.md
kctl-odoo modules audit-report --fast
```

### `kctl-odoo monitor`

Health monitoring, alerting, and metrics export.

| Command | Description |
|---------|-------------|
| `monitor gatus-export` | Generate a Gatus endpoints YAML config for monitoring this instance. |
| `monitor glitchtip-export` | Show GlitchTip/Sentry DSN configuration for Odoo error tracking. |
| `monitor history [--days]` | Show health check history. |
| `monitor prometheus [--prefix]` | Export Prometheus-format metrics. |
| `monitor run [--strict]` | Run all health checks and report status. |
| `monitor thresholds [--set_value]` | Show or set alert thresholds. |

**Examples:**
```bash
kctl-odoo monitor gatus-export
kctl-odoo monitor gatus-export > gatus-odoo.yaml
kctl-odoo monitor glitchtip-export
kctl-odoo monitor glitchtip-export --json
kctl-odoo monitor history
```

### `kctl-odoo mrp`

Manufacturing: production orders, BOMs, work centers.

| Command | Description |
|---------|-------------|
| `mrp bom-cost <bom_id>` | Calculate BOM cost from component standard prices. |
| `mrp bom-detail <bom_id>` | Show BOM detail with component lines. |
| `mrp boms [--product] [--limit]` | List bills of materials. |
| `mrp confirm <name> [--force]` | Confirm a draft manufacturing order. |
| `mrp costs <name>` | Show manufacturing order cost breakdown — planned vs actual. |
| `mrp create <product> [--qty] [--bom] [--dry_run]` | Create a manufacturing order. |
| `mrp create-order <product> [--qty] [--bom] [--dry_run]` | Create a manufacturing order. |
| `mrp done <name> [--force]` | Mark a manufacturing order as done. |
| `mrp finish-workorder <workorder_id> [--force]` | Finish a work order (mark as done). |
| `mrp get <name>` | Get manufacturing order detail by name or ID. |
| `mrp get-order <name>` | Get manufacturing order detail by name or ID. |
| `mrp list [--state] [--limit]` | List manufacturing orders with key fields. |
| `mrp orders [--state] [--limit]` | List manufacturing orders with key fields. |
| `mrp planning [--days] [--limit]` | Upcoming manufacturing orders (confirmed or in progress) by scheduled date. |
| `mrp start-workorder <workorder_id> [--force]` | Start a work order (set to in progress). |
| `mrp stuck [--days] [--limit]` | Manufacturing orders stuck beyond threshold (confirmed/in progress, overdue). |
| `mrp summary` | Manufacturing dashboard — MOs by state count. |
| `mrp workcenters` | List work centers. |
| `mrp workorders [--state] [--workcenter] [--limit]` | List work orders. |

**Examples:**
```bash
kctl-odoo mrp bom-cost 1
kctl-odoo mrp bom-cost 5
kctl-odoo mrp bom-detail 5
kctl-odoo mrp boms
kctl-odoo mrp boms --product "Finished Goods"
```

### `kctl-odoo ms`

Alias: modules scan

### `kctl-odoo mu`

Alias: modules upgrade <names>

Usage: `kctl-odoo mu <names>`

### `kctl-odoo onboarding`

Recruitment onboarding: verify, convert to employee, reject.

| Command | Description |
|---------|-------------|
| `onboarding convert <ids>` | Convert verified onboarding records into hr.employee records. |
| `onboarding list [--state] [--limit]` | List onboarding submissions. |
| `onboarding reject <ids> [--reason]` | Reject submitted or verified onboarding records. |
| `onboarding show <onboarding_id>` | Show full details for a single onboarding record. |
| `onboarding verify <ids>` | Mark onboarding submissions as verified. |

**Examples:**
```bash
kctl-odoo onboarding convert 1,2,3
kctl-odoo onboarding convert all
kctl-odoo onboarding list
kctl-odoo onboarding list --state submitted
kctl-odoo onboarding list --state verified --json
```

### `kctl-odoo orm`

ORM profiling, N+1 detection, and query analysis.

| Command | Description |
|---------|-------------|
| `orm explain <model> <method> [--domain]` | Show timing and result info for an ORM operation on a model. |
| `orm fields-unused [--module]` | Fields declared in models but never referenced in Python code or XML views. |
| `orm fields-usage <model>` | Show which fields of a model are used in views and Python code. |
| `orm index-suggest <model>` | Suggest database indexes based on common search patterns. |
| `orm n-plus-one [--module]` | Static analysis: scan Python for N+1 ORM patterns inside for loops. |
| `orm profile [--duration]` | Capture SQL query stats for N seconds from pg_stat_statements via Odoo. |
| `orm query-log [--tail]` | Recent slow queries from pg_stat_statements (via docker compose exec). |

**Examples:**
```bash
kctl-odoo orm fields-usage sale.order
kctl-odoo orm index-suggest sale.order
```

### `kctl-odoo partners`

Manage Odoo partners and contacts.

| Command | Description |
|---------|-------------|
| `partners create <name> [--email] [--phone] [--is_company] [--parent_id]` | Create a new partner or company contact. |
| `partners credit-limit-proposal [--company_type] [--coverage] [--output] [--ar_tolerance_rel] [--ar_tolerance_abs] [--insufficient_min_invoices] [--overdue_review_days] [--strict]` | Propose credit limits for trading-company customers based on average sales. |
| `partners delete <partner_id> [--force]` | Delete a partner/contact by ID. |
| `partners duplicates [--limit]` | Find potential duplicate partners sharing the same email address. |
| `partners get <identifier>` | Show full details for a partner by ID or name. |
| `partners list [--company] [--person] [--customer] [--supplier] [--limit]` | List partners and contacts with optional filters. |
| `partners search <query> [--limit]` | Search partners by name or email (case-insensitive contains match). |
| `partners stats` | Show aggregate statistics for all partners. |
| `partners update <identifier> [--name] [--email] [--phone] [--city]` | Update fields on an existing partner or contact. |

**Examples:**
```bash
kctl-odoo partners create --name "PT Baru Indonesia" --company
kctl-odoo partners create --name "Jane Doe" --email jane@example.com --phone "081234567"
kctl-odoo partners create --name "John Smith" --parent 42
kctl-odoo partners delete 99
kctl-odoo partners delete 99 --force
```

### `kctl-odoo payment-gateways`

Payment gateways: iPaymu, Midtrans, Xendit status.

| Command | Description |
|---------|-------------|
| `payment-gateways history [--provider] [--days] [--limit]` | List recent payment transactions. |
| `payment-gateways pending [--provider] [--limit]` | List pending payment transactions. |
| `payment-gateways reconcile [--dry_run]` | Check for stale pending transactions (>24h) and suggest reconciliation. |
| `payment-gateways status` | Show all payment providers with state. |

**Examples:**
```bash
kctl-odoo payment-gateways history
kctl-odoo payment-gateways history --provider ipaymu --days 7 --limit 20
kctl-odoo payment-gateways pending
kctl-odoo payment-gateways pending --provider midtrans --limit 20
kctl-odoo payment-gateways reconcile --dry-run
```

### `kctl-odoo perf`

Alias: performance

### `kctl-odoo performance`

Performance diagnostics, profiling, and benchmarks.

| Command | Description |
|---------|-------------|
| `performance benchmark [--iterations]` | Benchmark ORM operations — measure RPC response times. |
| `performance cache` | Show cache-related system parameters. |
| `performance connections` | Show active database connection counts. |
| `performance cron-timing [--limit]` | Show cron execution timing — identify slow scheduled actions. |
| `performance indexes [--limit]` | List models and their indexed fields. |
| `performance memory` | Show Odoo server memory usage and configuration guidance. |
| `performance model-speed <model> [--limit]` | Profile a specific model — measure search, read, and count speeds. |
| `performance modules-count` | Count modules by state. |
| `performance pg` | Show how to use kctl-pg for database-level profiling. |
| `performance queue-throughput [--hours]` | Show queue job throughput — jobs processed per hour. |
| `performance stats [--watch] [--interval]` | Show database and system statistics overview. |
| `performance tables [--limit]` | Show record counts per model (largest tables first). |

**Examples:**
```bash
kctl-odoo performance connections
kctl-odoo performance memory
```

### `kctl-odoo periods`

Fiscal periods and date range management.

| Command | Description |
|---------|-------------|
| `periods create-year <year> [--range_type]` | Create 12 monthly date ranges for a fiscal year. |
| `periods list [--range_type] [--limit]` | List date ranges (fiscal periods). |
| `periods types` | List date range types. |

**Examples:**
```bash
kctl-odoo periods create-year 2025
kctl-odoo periods create-year 2026 --type "Month"
kctl-odoo periods list
kctl-odoo periods list --type "Fiscal Year" --limit 20
kctl-odoo periods types
```

### `kctl-odoo pi`

Alias: profiles install <name>

Usage: `kctl-odoo pi <name>`

### `kctl-odoo pipeline`

CI/CD pipeline automation and observability.

| Command | Description |
|---------|-------------|
| `pipeline changelog <from_ref> [--to_ref] [--path_filter]` | Generate release notes from git commits and module changes. |
| `pipeline metrics [--prefix] [--warn]` | Export Prometheus-format metrics for Grafana dashboards. |
| `pipeline promote <source> <target> [--dry_run] [--sync_modules] [--sync_params] [--force]` | Compare and promote modules/config from source to target instance. |
| `pipeline rollback <profile> <backup_file> [--database] [--copy] [--skip_pre_backup] [--force]` | Restore from backup with pre/post verification. |
| `pipeline validate [--skip_lint] [--skip_test]` | Run lint + test + preflight + smoke-test as a single CI gate. |

**Examples:**
```bash
kctl-odoo pipeline changelog --from v1.0.0 --to v1.1.0
kctl-odoo pipeline changelog --from v1.0.0 --path src/private/
kctl-odoo pipeline changelog --from HEAD~20 --json
kctl-odoo pipeline metrics
kctl-odoo pipeline metrics --warn
```

### `kctl-odoo pl`

Alias: profiles list

### `kctl-odoo pos`

Point of Sale: sessions, orders, payments.

| Command | Description |
|---------|-------------|
| `pos cash-control <session_id>` | Show cash in/out details for a POS session. |
| `pos cashier-summary [--date_from] [--date_to]` | Revenue and order count per cashier. |
| `pos close-session <session_id> [--force]` | Close a POS session. |
| `pos config-detail <config_id>` | Show detailed POS configuration. |
| `pos configs` | List POS configurations. |
| `pos daily-report [--date]` | Daily sales summary grouped by POS configuration. |
| `pos debug-session <session_id>` | Comprehensive debug view of a POS session. |
| `pos get-order <ref>` | Get POS order detail by reference or name. |
| `pos hourly-sales [--date]` | Hourly sales breakdown for a given day. |
| `pos order-lines <order_ref>` | Show detailed order lines with products, qty, price, discount. |
| `pos orders [--session] [--date_from] [--limit]` | List POS orders. |
| `pos orphan-orders [--limit]` | Find POS orders with data integrity issues. |
| `pos payments [--date_from] [--limit]` | Payment summary grouped by payment method. |
| `pos period-report [--period]` | Sales comparison report: this period vs previous. |
| `pos reconcile <session_id>` | Verify session reconciliation — compare POS totals vs journal entries. |
| `pos refunds [--date_from] [--limit]` | List POS refund orders. |
| `pos sessions [--state] [--limit]` | List POS sessions. |
| `pos stuck-sessions [--hours]` | Find POS sessions that have been open beyond a threshold. |
| `pos summary` | Dashboard — active sessions count, today's orders count, today's revenue. |
| `pos tax-summary [--date_from] [--date_to]` | POS tax breakdown by tax rate for a period. |
| `pos top-products [--limit] [--date_from]` | Top-selling products from POS orders. |
| `pos trace-order <order_ref>` | Trace a POS order through the full accounting flow. |
| `pos validate-close <session_id>` | Pre-check if a session can be cleanly closed. |

**Examples:**
```bash
kctl-odoo pos cash-control 1
kctl-odoo pos cashier-summary
kctl-odoo pos cashier-summary --date-from 2026-03-01
kctl-odoo pos close-session 5
kctl-odoo pos close-session 5 --force
```

### `kctl-odoo pricelist`

Pricelist inspection, strata analysis, and bulk-edit templates.

| Command | Description |
|---------|-------------|
| `pricelist analyze <product> [--prefix] [--latest_only]` | Fingerprint distinct strata patterns for one product across pricelists. |
| `pricelist export-template [--mode] [--prefix] [--products] [--output]` | Generate a safe ID-based CSV template for bulk-adding pricelist tier lines. |
| `pricelist items <pricelist> [--product] [--active_only] [--limit]` | List tier lines of a pricelist. |
| `pricelist list <pricelist> [--product] [--active_only] [--limit]` | List tier lines of a pricelist. |
| `pricelist strata <product> [--prefix] [--latest_only]` | Per-pricelist tier breakdown for one product. |

**Examples:**
```bash
kctl-odoo pricelist analyze "ECO TEA BIG CUP 24" --prefix TLN-
kctl-odoo pricelist analyze 550 --prefix TLN- --no-latest-only
kctl-odoo pricelist export-template add-lines --prefix TLN- --products 550,554,551 -o tln.csv
kctl-odoo pricelist export-template --prefix TLN- --products "01010101160,01020101180,01010101280"
kctl-odoo pricelist items TLN-JKT_JAKARTA
```

### `kctl-odoo products`

Product management: catalog, pricing, categories.

| Command | Description |
|---------|-------------|
| `products barcode-lookup <barcode>` | Find product variant by exact barcode. |
| `products by-category [--limit]` | Count products per category. |
| `products categories [--limit]` | List product categories. |
| `products get <identifier>` | Show full product details by name or ID. |
| `products list [--category] [--product_type] [--limit]` | List product templates with key fields. |
| `products low-margin [--threshold] [--limit]` | Find products with low margin (below threshold %). |
| `products search <query> [--limit]` | Search products by name, internal code, or barcode. |
| `products update-price <identifier> [--sale_price] [--cost_price] [--force]` | Update sale price and/or cost price on a product. |

**Examples:**
```bash
kctl-odoo products barcode-lookup 8991234567890
kctl-odoo products by-category
kctl-odoo products by-category --limit 10
kctl-odoo products categories
kctl-odoo products categories --limit 100
```

### `kctl-odoo project`

Project & task management.

| Command | Description |
|---------|-------------|
| `project list [--state] [--limit]` | List projects (project.project). |
| `project overdue [--days] [--limit]` | Tasks past their deadline. |
| `project tasks <project> [--stage] [--user] [--limit]` | List tasks for a project. |
| `project timesheets [--user] [--period] [--limit]` | Timesheet hours summary (account.analytic.line). |

**Examples:**
```bash
kctl-odoo project list
kctl-odoo project list --state archived
kctl-odoo project list --json
kctl-odoo project overdue-tasks
kctl-odoo project overdue-tasks --days 30
```

### `kctl-odoo purchasing`

Purchase operations: orders, receipts, billing.

| Command | Description |
|---------|-------------|
| `purchasing approve [--ids] [--all_] [--force]` | Approve one or more purchase orders that are in 'To Approve' state. |
| `purchasing by-product [--limit] [--date_from]` | Purchase volume breakdown by product. |
| `purchasing by-vendor [--limit] [--date_from]` | Purchase volume breakdown by vendor. |
| `purchasing cancel <name> [--force]` | Cancel a purchase order. |
| `purchasing cancel-order <name> [--force]` | Cancel a purchase order. |
| `purchasing confirm <name> [--force]` | Confirm a draft purchase order. |
| `purchasing confirm-order <name> [--force]` | Confirm a draft purchase order. |
| `purchasing create <partner_name> <product_name> [--qty] [--price] [--dry_run] [--force]` | Create a purchase order with one line. |
| `purchasing create-bill <po_name> [--force]` | Create a vendor bill from a confirmed purchase order. |
| `purchasing create-order <partner_name> <product_name> [--qty] [--price] [--dry_run] [--force]` | Create a purchase order with one line. |
| `purchasing get <name>` | Get purchase order detail by name or ID. |
| `purchasing get-order <name>` | Get purchase order detail by name or ID. |
| `purchasing list [--state] [--partner] [--date_from] [--date_to] [--limit]` | List purchase orders with key fields. |
| `purchasing orders [--state] [--partner] [--date_from] [--date_to] [--limit]` | List purchase orders with key fields. |
| `purchasing receipts [--state] [--limit]` | List incoming receipts (purchase-related stock pickings). |
| `purchasing summary [--period]` | Show a purchasing dashboard: PO counts and totals grouped by state. |
| `purchasing trend [--period]` | Purchase trend — compare this period vs previous. |
| `purchasing validate-receipt <name> [--force]` | Validate an incoming receipt picking. |

**Examples:**
```bash
kctl-odoo purchasing approve --all
kctl-odoo purchasing approve --ids 101,102,103
kctl-odoo purchasing approve --all --force
kctl-odoo purchasing by-product
kctl-odoo purchasing by-product --limit 10 --date-from 2025-01-01
```

### `kctl-odoo quality`

Quality control: checks, inspections, alerts.

| Command | Description |
|---------|-------------|
| `quality alerts [--limit]` | List quality checks/inspections in failed state. |
| `quality checks [--state] [--limit]` | List quality checks or inspections. |
| `quality stats` | Quality statistics: count by state (pass/fail/pending). |

**Examples:**
```bash
kctl-odoo quality alerts
kctl-odoo quality alerts --limit 10
kctl-odoo quality checks
kctl-odoo quality checks --state fail --limit 20
kctl-odoo quality stats
```

### `kctl-odoo record-rules`

Debug and audit Odoo record rules and access control.

| Command | Description |
|---------|-------------|
| `record-rules audit` | Audit: models without record rules, overly permissive rules. |
| `record-rules explain <model> <user_id>` | Show the full record rule chain for a model and user. |
| `record-rules simulate <model> <user_id> <record_id>` | Evaluate record rules for a given user and record combination. |
| `record-rules test <model> [--limit]` | Test record rules against sample data by checking which records are visible. |

**Examples:**
```bash
kctl-odoo record-rules audit
kctl-odoo record-rules audit --json
kctl-odoo record-rules explain sale.order 7
kctl-odoo record-rules explain account.move 3
kctl-odoo record-rules simulate sale.order 5 42
```

### `kctl-odoo rep`

Alias: report

### `kctl-odoo report`

Manage Odoo reports and generate diagnostic reports.

| Command | Description |
|---------|-------------|
| `report add-line <report_code> <name> [--line_type] [--code] [--expression] [--formula] [--sign] [--model] [--domain] [--measure] [--aggregator] [--sequence]` | Add a template line to an existing report. |
| `report batch-download [--category] [--date_from] [--date_to] [--output_dir]` | Bulk export multiple reports to files. |
| `report benchmark <report_code> [--iterations] [--date_from] [--date_to] [--company]` | Benchmark report generation time over multiple iterations. |
| `report catalog` | Show all report types with template count and status. |
| `report compare <accurate_file> [--type_code] [--company] [--date_from] [--date_to] [--tolerance]` | Compare an Accurate XLSX export against Odoo report engine output. |
| `report convert <report_code> [--force]` | Convert a report type to use the universal handler. |
| `report convert-status` | Show conversion status of all report types (universal vs specialized handler). |
| `report create <name> [--category] [--date_mode] [--column_template] [--code] [--force]` | Create a new report type with an empty template via the creation wizard. |
| `report custom-query` | Report custom-query (non-ledger data sources) CRUD. |
| `report data <type_code> [--date_from] [--date_to] [--as_of_date] [--company] [--show_zero]` | Print report data as a terminal table for quick inspection. |
| `report download <type_code> [--date_from] [--date_to] [--as_of_date] [--fmt] [--output] [--force]` | Generate a report and export it in one step. |
| `report drill-route` | Report drill-route (cross-report navigation) CRUD. |
| `report export <instance_id> [--fmt] [--output]` | Export a report instance to XLSX or PDF file. |
| `report format` | Per-instance report format (Modify dialog) CRUD. |
| `report generate <report_type> [--output] [--quick]` | Generate a focused diagnostic report by domain. |
| `report instances [--type_code] [--limit]` | List generated report instances from report_base. |
| `report list [--model] [--limit]` | List available reports. |
| `report preview <report_code> [--date_from] [--date_to] [--company] [--show_zero]` | Preview a report's output as a text table. |
| `report quick <type_code> [--date_from] [--date_to] [--as_of_date] [--company] [--company_ids] [--output] [--fmt]` | Generate a report and render XLSX client-side — no wizard, no HTTP controller. |
| `report remove-line <report_code> <line_code> [--force]` | Remove a template line from a report by its code. |
| `report render <report_name> <record_ids> [--fmt] [--output]` | Render a report for given record IDs and save to file. |
| `report run <type_code> [--date_from] [--date_to] [--as_of_date] [--company] [--dry_run] [--force]` | Generate a report using the report_base framework. |
| `report schedule` | Report schedule: create/manage scheduled report delivery via CLI. |
| `report subkpi` | Report formula-column (subkpi) CRUD. |
| `report template` | Report template management: import/export/clone/library install. |
| `report templates [--model] [--limit]` | List QWeb report templates. |
| `report type` | Report type registry: create/update report types via CLI (no UI). |
| `report types [--category] [--limit]` | List report types from the report_base registry. |
| `report validate [--type_code] [--date_from] [--date_to] [--company] [--category]` | Validate report quality — check reports generate with data. |
| `report verify-accurate <reference> [--company] [--date_from] [--date_to] [--tolerance] [--pct_tolerance]` | Compare live engine output row-by-row against a stored Accurate XLSX
reference (exported as JSON). |
| `report verify-math [--type_code] [--companies] [--category] [--date_from] [--date_to] [--tolerance]` | Verify consolidation math: consolidated totals should equal the sum
of per-company totals. |
| `report view <instance_id>` | View a report instance's metadata and data summary. |

**Examples:**
```bash
kctl-odoo report add-line my_report --name "Revenue" --expr "bal[4010:4100]"
kctl-odoo report add-line my_report --name "COGS" --code cogs --expr "bal[5010:5900]" --sign -1
kctl-odoo report add-line my_report --name "Gross Profit" --type formula --formula "revenue - cogs"
kctl-odoo report add-line my_report --name "Partners" --model res.partner --domain "[('active','=',True)]" --measure id --aggregator count
kctl-odoo report benchmark profit_loss
```

### `kctl-odoo report-formats`

Report format configuration - banded PDF layouts.

| Command | Description |
|---------|-------------|
| `report-formats apply-theme <theme> [--report_types] [--company_id] [--include_presets]` | Bulk-flip ``theme_preset`` on multiple formats at once. |
| `report-formats audit [--company]` | Cross-format audit: empty bands, missing defaults, lint issues. |
| `report-formats clone <fmt_ref> <name> [--inherit]` | Clone a format. |
| `report-formats clone-arch <source> <targets> [--overwrite]` | Copy all 8 bands from a source format to one or more targets. |
| `report-formats diff <fmt_ref_a> <fmt_ref_b>` | Show semantic differences between two formats (arch-level). |
| `report-formats export <fmt_ref> [--output]` | Export a format as JSON (portable across companies / instances). |
| `report-formats golden-snapshot <fmt_ref> <record_id> [--golden_dir]` | Render the format to PDF, strip timestamps, write SHA-256 as a golden file. |
| `report-formats import <path> [--company] [--ou] [--set_default]` | Import a report format from a JSON file. |
| `report-formats lint [--fmt_ref] [--all_formats]` | Validate one format's arch (or all). |
| `report-formats list [--report_type] [--company] [--ou] [--default_only] [--limit]` | List report formats. |
| `report-formats preview <fmt_ref> <record_id> [--as_html] [--output]` | Render a preview of the format against a sample record. |
| `report-formats render-bench <fmt_ref> <record_id> [--iterations]` | Benchmark render time across N iterations. |
| `report-formats scaffold <report_type> [--theme] [--name] [--output]` | Generate a starter JSON for a new format (not yet submitted to Odoo). |
| `report-formats seed-samples [--company_id] [--as_json]` | Create one sample record per registered report type, so Preview PDF works. |
| `report-formats set-active <fmt_ref> [--active]` | Toggle a format's ``active`` flag (archive / restore). |
| `report-formats set-default <fmt_ref>` | Mark a format as the default for its (type, company, OU) triple. |
| `report-formats show <fmt_ref>` | Show a single format with its bands. |
| `report-formats types` | List all registered report types (from PrintReportRegistry). |
| `report-formats unlink <fmt_ref> [--force]` | Delete a report format (and its bands + versions via cascade). |
| `report-formats versions <fmt_ref> [--revert]` | List versions of a format. |

### `kctl-odoo roles`

Declarative role management via install/roles.yaml

| Command | Description |
|---------|-------------|
| `roles apply <csv_file> [--dry_run]` | Bulk-assign from a CSV. |
| `roles assign <login> [--roles] [--ous] [--clear]` | Assign role(s) + OU(s) to a user (or clear). |
| `roles audit [--file] [--ignored_file] [--suggest] [--strict]` | Report orphan groups, dead xml_id references, and drift. |
| `roles diff [--file]` | Compare live DB roles vs. |
| `roles example <role_id> [--file]` | Show the example profile (typical user, responsibilities, acceptance checklist) for a role. |
| `roles list` | List roles currently in the DB with user counts. |
| `roles show <name>` | Show role detail: groups, implied groups, assigned users. |
| `roles sync [--file] [--dry_run] [--prune] [--strict]` | Apply install/roles-<type>.yaml to the DB idempotently. |

### `kctl-odoo sal`

Alias: sales

### `kctl-odoo sales`

Sales operations: orders, deliveries, invoicing.

| Command | Description |
|---------|-------------|
| `sales by-customer [--limit] [--date_from] [--date_to]` | Sales revenue breakdown by customer. |
| `sales by-product [--limit] [--date_from] [--date_to]` | Sales revenue breakdown by product. |
| `sales by-salesperson [--date_from] [--date_to]` | Sales revenue breakdown by salesperson. |
| `sales cancel <name> [--force]` | Cancel a sale order (set to cancelled state). |
| `sales cancel-order <name> [--force]` | Cancel a sale order (set to cancelled state). |
| `sales confirm <name> [--force]` | Confirm a draft sale order. |
| `sales confirm-order <name> [--force]` | Confirm a draft sale order. |
| `sales create <partner_name> <product_name> [--qty] [--price] [--dry_run] [--force]` | Create a sale order with one line. |
| `sales create-order <partner_name> <product_name> [--qty] [--price] [--dry_run] [--force]` | Create a sale order with one line. |
| `sales crm-pipeline [--team]` | Show CRM pipeline: open opportunities grouped by stage with revenue totals. |
| `sales deliveries [--state] [--limit]` | List outgoing deliveries (sale-related stock pickings). |
| `sales get <name>` | Get sale order detail by name or ID. |
| `sales get-order <name>` | Get sale order detail by name or ID. |
| `sales list [--state] [--partner] [--date_from] [--date_to] [--limit]` | List sale orders with key fields. |
| `sales orders [--state] [--partner] [--date_from] [--date_to] [--limit]` | List sale orders with key fields. |
| `sales overdue [--order_type] [--days] [--limit]` | List quotations or POs whose validity date has expired. |
| `sales summary [--period] [--team]` | Show a sales dashboard: order counts and totals grouped by state. |
| `sales trend [--period]` | Sales trend — compare this period vs previous. |
| `sales validate-delivery <name> [--force]` | Validate an outgoing delivery picking. |

**Examples:**
```bash
kctl-odoo sales by-customer --limit 10
kctl-odoo sales by-customer --date-from 2025-01-01 --date-to 2025-03-31
kctl-odoo sales by-product --limit 10
kctl-odoo sales by-product --date-from 2025-01-01 --date-to 2025-03-31
kctl-odoo sales by-salesperson
```

### `kctl-odoo scaffold`

Generate Odoo module boilerplate (scaffold).

| Command | Description |
|---------|-------------|
| `scaffold bridge <module_a> <module_b> [--dest] [--overwrite]` | Generate a bridge module skeleton with auto_install=True. |
| `scaffold controller <module_dir> <name> [--overwrite]` | Generate an HTTP controller skeleton. |
| `scaffold crud-api <module> <model> [--dest] [--overwrite]` | Generate FastAPI CRUD router + Pydantic schema + test for a model. |
| `scaffold icon [--module_dir] [--symbol] [--text] [--color] [--shape] [--no_gradient] [--list_icons] [--list_colors] [--overwrite]` | Generate an Odoo 18 standard SVG icon for a module. |
| `scaffold migration <module_dir> <version> [--stage] [--overwrite]` | Generate a pre/post migration script for a version upgrade. |
| `scaffold model <module_dir> <model_name> [--inherit] [--fields]` | Add a model to an existing module. |
| `scaffold module <name> [--dest] [--depends] [--author] [--category] [--fastapi] [--version]` | Create a new Odoo 18 module with standard directory structure. |
| `scaffold print-report <module> <key> <label> <model> <binding_model_xmlid> [--theme] [--dest] [--version_dir] [--overwrite]` | Scaffold a new printable report type end-to-end. |
| `scaffold report <module_dir> <name> [--model] [--overwrite]` | Generate a QWeb report template with ir.actions.report record. |
| `scaffold router <module_dir> <name> [--crud]` | Add a FastAPI router to an existing module. |
| `scaffold schema <module_dir> <name>` | Add a Pydantic schema file to an existing module. |
| `scaffold security <module_dir> [--group] [--overwrite]` | Generate ir.model.access.csv rows for all models declared in the module. |
| `scaffold test <module_dir> <name> [--model] [--router]` | Add a test file to an existing module. |
| `scaffold view <module_dir> <model> [--view_type] [--overwrite]` | Generate an XML view file for a model. |
| `scaffold wizard <module_dir> <name> [--overwrite]` | Generate a transient model (wizard) with view and action. |

**Examples:**
```bash
kctl-odoo scaffold icon my_module --symbol chart --color teal
kctl-odoo scaffold icon my_module --text "HR" --color red
kctl-odoo scaffold icon my_module --symbol star --color "#FF5733"
kctl-odoo scaffold icon my_module --symbol shield --shape circle
kctl-odoo scaffold icon --list-icons
```

### `kctl-odoo security`

Security & audit operations.

| Command | Description |
|---------|-------------|
| `security access-report [--output] [--all_users]` | Export user access matrix with roles, OUs, and admin status. |
| `security access-rights [--model] [--limit]` | List access control rules (ir.model.access). |
| `security add-to-group <user_login> <group_ref>` | Add a user to a security group. |
| `security admins` | List users in the Administration / Settings group (base.group_system). |
| `security audit` | Comprehensive security audit across groups, ACLs, record rules, and users. |
| `security bulk-grant <group_ref> <users>` | Add multiple users to a security group. |
| `security bulk-revoke <group_ref> <users>` | Remove multiple users from a security group. |
| `security check-permissions <user>` | Show a user's groups and effective permissions. |
| `security compliance` | Security compliance scorecard (9-point check). |
| `security diff-users <user_a> <user_b>` | Compare permissions between two users. |
| `security group-users <group> [--limit]` | List all users in a specific security group. |
| `security groups [--limit]` | List security groups with user counts. |
| `security quick-audit [--days] [--limit]` | Show recent login activity from res.users.log. |
| `security record-rules [--model] [--limit]` | List record-level access rules (ir.rule). |
| `security remove-from-group <user_login> <group_ref> [--force]` | Remove a user from a security group. |
| `security sudo-audit [--module]` | Find sudo() calls in private module Python code. |
| `security superusers` | List internal (non-portal) active users with admin status. |

**Examples:**
```bash
kctl-odoo security bulk-grant base.group_user user1,user2,user3
kctl-odoo security bulk-revoke base.group_user user1,user2,user3
kctl-odoo security compliance
kctl-odoo security compliance --json
kctl-odoo security diff-users admin user1
```

### `kctl-odoo self-update`

Check for updates and upgrade kctl-odoo.

### `kctl-odoo sequences`

Manage IR sequences (numbering).

| Command | Description |
|---------|-------------|
| `sequences get <code>` | Get detailed info for a sequence by code. |
| `sequences list [--model] [--limit]` | List IR sequences. |
| `sequences preview <code> [--count]` | Preview next N sequence numbers without consuming them. |
| `sequences reset <code> <number> [--force]` | Reset a sequence counter to a specific number. |

**Examples:**
```bash
kctl-odoo sequences get sale.order
kctl-odoo sequences get account.move
kctl-odoo sequences list
kctl-odoo sequences list --model sale
kctl-odoo sequences list --limit 20
```

### `kctl-odoo server`

Manage Odoo server configuration (mail servers, defaults, system parameters).

| Command | Description |
|---------|-------------|
| `server add-mail-incoming <name> <host> <port> <server_type> [--user] [--password] [--ssl]` | Add a new incoming mail server (IMAP/POP3). |
| `server add-mail-outgoing <name> <host> <port> [--user] [--password] [--encryption]` | Add a new outgoing SMTP mail server. |
| `server defaults [--model]` | List default values configured in the system. |
| `server delete-default <default_id> [--force]` | Delete a default value record. |
| `server get-param <key>` | Get a system parameter value. |
| `server mail-incoming` | List incoming mail servers (IMAP/POP3). |
| `server mail-outgoing` | List outgoing SMTP mail servers. |
| `server params [--search] [--limit]` | List system parameters. |
| `server params-export [--output] [--search]` | Export system parameters to YAML or JSON file. |
| `server params-import <file_path> [--dry_run] [--force]` | Import system parameters from YAML or JSON file. |
| `server set-default <model> <field> <value> [--company_id]` | Set a default value for a model field. |
| `server set-param <key> <value>` | Set a system parameter value (creates if not exists). |
| `server sync-base-url [--all_dbs]` | Update web.base.url to match the CLI profile URL. |
| `server test-mail-outgoing <server_id>` | Test an outgoing SMTP server connection. |

**Examples:**
```bash
kctl-odoo server params-export -o params.yaml
kctl-odoo server params-export -s web. -o web_params.json
kctl-odoo server params-import params.yaml --dry-run
kctl-odoo server params-import params.json --force
kctl-odoo server sync-base-url
```

### `kctl-odoo sessions`

Manage user sessions and login activity.

| Command | Description |
|---------|-------------|
| `sessions active [--hours] [--limit]` | Show recent user login events from res.users.log. |
| `sessions kick <login> [--force]` | Invalidate user sessions by forcing a password change token. |
| `sessions list [--days] [--limit]` | List internal users with login count and last login date. |
| `sessions stats` | Show session activity statistics across multiple time windows. |

**Examples:**
```bash
kctl-odoo sessions active
kctl-odoo sessions active --hours 24 --limit 50
kctl-odoo sessions active --json
kctl-odoo sessions kick john.doe
kctl-odoo sessions kick john.doe --force
```

### `kctl-odoo setup`

Implementation setup wizard and go-live tools.

| Command | Description |
|---------|-------------|
| `setup audit` | Deep audit of master data, configuration, and business readiness. |
| `setup check-db` | Test PostgreSQL connectivity using configured .env values. |
| `setup checklist [--category]` | Run the implementation checklist against the Odoo instance. |
| `setup init` | Interactive setup wizard -- prompts for .env values and writes .env file. |
| `setup preflight [--profile] [--dir_path]` | Pre-flight check before go-live. |
| `setup quickstart` | Show the recommended setup steps for a new Odoo implementation. |
| `setup smoke-test` | Smoke-test key HTTP endpoints on the Odoo instance. |

**Examples:**
```bash
kctl-odoo setup check-db
kctl-odoo setup init
kctl-odoo -p dev setup smoke-test
```

### `kctl-odoo shell`

Execute ORM method calls.

| Command | Description |
|---------|-------------|
| `shell call <model> <method> [--args] [--kwargs]` | Execute an ORM method on a model. |
| `shell repl [--load_models]` | Start an interactive ORM REPL session. |

**Examples:**
```bash
kctl-odoo shell call res.partner search_read '[[["is_company","=",true]]]' -k '{"fields":["name"],"limit":5}'
kctl-odoo shell call res.users search_count '[[]]'
kctl-odoo shell call ir.module.module fields_get '[]' -k '{"attributes":["string","type"]}'
kctl-odoo repl
kctl-odoo repl --load-models
```

### `kctl-odoo skill`

Claude Code skill management.

| Command | Description |
|---------|-------------|
| `skill generate [--output] [--install] [--check]` | Auto-generate SKILL.md from CLI command registry. |

**Examples:**
```bash
kctl-odoo skill generate
kctl-odoo skill generate --install
kctl-odoo skill generate --check
```

### `kctl-odoo sql-export`

SQL Export: create, validate, execute, and download ad-hoc SQL queries.

| Command | Description |
|---------|-------------|
| `sql-export create <name> <query> [--file_format] [--encoding] [--copy_options] [--validate]` | Create a new SQL export query. |
| `sql-export delete <export_id> [--force]` | Delete a SQL export. |
| `sql-export execute <export_id> [--output] [--params]` | Execute a SQL export and download the result file. |
| `sql-export grant <export_id> [--users] [--groups] [--replace]` | Manage who can execute a SQL export. |
| `sql-export list [--state] [--limit]` | List SQL export queries. |
| `sql-export preview <export_id> [--limit] [--params]` | Preview SQL export results in terminal (first N rows). |
| `sql-export set-params <export_id> <props>` | Configure query parameters for a SQL export. |
| `sql-export show <export_id>` | Show SQL export details including query and parameters. |
| `sql-export update <export_id> [--name] [--query] [--file_format] [--encoding] [--copy_options] [--validate]` | Update an existing SQL export. |
| `sql-export validate <export_id>` | Validate SQL query (draft -> sql_valid). |

**Examples:**
```bash
kctl-odoo sql-export create "Revenue by Month" -q "SELECT date_trunc('month', date) as month, SUM(amount_total) FROM account_move WHERE state='posted' GROUP BY 1 ORDER BY 1"
kctl-odoo sql-export create "Partners" -q "SELECT name, email FROM res_partner WHERE active" -f excel
kctl-odoo sql-export delete 5
kctl-odoo sql-export delete 5 -y
kctl-odoo sql-export execute 1
```

### `kctl-odoo statements`

Customer/vendor account statements.

| Command | Description |
|---------|-------------|
| `statements aging` | Show aged receivable summary by aging bucket. |
| `statements generate [--partner] [--stmt_type] [--stmt_date]` | Instructions for generating partner statements via Odoo wizard. |
| `statements overdue [--limit]` | List partners with overdue balances (unpaid past due date). |
| `statements partner <partner_name> [--date_from] [--output]` | Show account statement for a specific partner. |

**Examples:**
```bash
kctl-odoo statements aging
kctl-odoo statements generate
kctl-odoo statements generate --partner "Acme Corp" --type activity
kctl-odoo statements overdue
kctl-odoo statements overdue --limit 20
```

### `kctl-odoo storage`

Storage monitoring & cleanup operations.

| Command | Description |
|---------|-------------|
| `storage attachments [--model] [--top]` | List attachments sorted by size (largest first). |
| `storage cleanup-attachments [--days] [--force]` | Remove orphan attachments older than N days. |
| `storage cleanup-logs [--days] [--force]` | Remove old ir.logging records older than N days. |
| `storage cleanup-mail [--days] [--force]` | Remove sent/cancelled mail.mail records older than N days. |
| `storage cleanup-sessions [--force]` | Purge expired sessions via ir.http (if available). |
| `storage download <attachment_id> [--output]` | Download an attachment by ID. |
| `storage filestore-stats` | Show attachment storage statistics. |
| `storage integrity-check` | Verify attachment references are valid. |
| `storage large-attachments [--min_size] [--limit]` | Find oversized attachments (default: > 1MB). |
| `storage migrate-to-db [--limit] [--dry_run]` | Migrate filestore attachments to database storage. |
| `storage migrate-to-fs [--limit] [--dry_run]` | Migrate database attachments to filestore storage. |
| `storage overview` | Comprehensive storage overview with cleanup recommendations. |
| `storage summary` | Comprehensive storage overview with cleanup recommendations. |

**Examples:**
```bash
kctl-odoo storage migrate-to-db --dry-run
kctl-odoo storage migrate-to-db --limit 500
kctl-odoo storage migrate-to-fs --dry-run
kctl-odoo storage migrate-to-fs --limit 500
kctl-odoo storage overview
```

### `kctl-odoo support`

Internal support: tickets, SLA, knowledge base.

| Command | Description |
|---------|-------------|
| `support close <ticket_id> [--force]` | Close a support ticket (set status to resolved). |
| `support create <subject> [--category] [--priority]` | Create a new support ticket. |
| `support sla-status` | Count tickets by SLA compliance (within/breached). |
| `support tickets [--status] [--limit]` | List support tickets. |

**Examples:**
```bash
kctl-odoo support close 42
kctl-odoo support close 42 --force
kctl-odoo support create "Login issue"
kctl-odoo support create "Database error" --category "Technical" --priority 2
kctl-odoo support sla-status
```

### `kctl-odoo tax`

Tax reporting and compliance (Indonesian PPN/PPh).

| Command | Description |
|---------|-------------|
| `tax accounts` | List all tax-related GL accounts. |
| `tax coretax-status` | Check Coretax DJP integration status. |
| `tax faktur [--state] [--limit]` | List Faktur Pajak records (tax_management module). |
| `tax invoices [--invoice_type] [--limit]` | List posted invoices that have tax lines. |
| `tax pph-summary [--date_from] [--date_to]` | PPh withholding summary — grouped by PPh account. |
| `tax pph21-summary [--month]` | PPh 21 employee income tax summary. |
| `tax ppn-summary [--date_from] [--date_to]` | PPN (VAT) summary — output PPN, input PPN, and net amount. |
| `tax report [--period]` | Monthly tax summary combining PPN + PPh. |
| `tax tax-invoices-export [--invoice_type] [--date_from] [--date_to] [--output]` | Export tax invoices to CSV for Coretax/e-Faktur filing. |
| `tax withholdings [--pph_type] [--date_from] [--limit]` | List withholding tax entries from PPh accounts. |

**Examples:**
```bash
kctl-odoo tax tax-accounts
kctl-odoo tax tax-accounts --json
kctl-odoo tax coretax-status
kctl-odoo tax faktur-list
kctl-odoo tax faktur-list --state posted --limit 20
```

### `kctl-odoo tenants`

SaaS tenant/multi-database operations.

| Command | Description |
|---------|-------------|
| `tenants backup <name> [--output] [--fmt]` | Backup a tenant database. |
| `tenants create <name> [--template] [--modules]` | Create a new tenant database. |
| `tenants delete <name> [--force]` | Delete a tenant database. |
| `tenants info <name>` | Show information about a tenant database. |
| `tenants list` | List all tenant databases. |
| `tenants reactivate <name>` | Reactivate a suspended tenant by re-enabling cron jobs. |
| `tenants summary <name>` | Show information about a tenant database. |
| `tenants suspend <name> [--force]` | Suspend a tenant by disabling all cron jobs. |

### `kctl-odoo test`

Run and manage Odoo tests.

| Command | Description |
|---------|-------------|
| `test coverage <module> [--database]` | Run tests with coverage measurement for a module. |
| `test list <module> [--directory]` | List test files and classes for a module. |
| `test profile <name> [--dir_path] [--stop_on_fail] [--tags] [--database]` | Run tests for all testable modules in a deployment profile. |
| `test run <module> [--tags] [--database] [--clean] [--summary]` | Run Odoo tests for a module. |

**Examples:**
```bash
kctl-odoo test coverage base_management
kctl-odoo test coverage sfa_management -d odoo_sfa
kctl-odoo test list base_management
kctl-odoo test list sfa_management --dir /opt/odoo/addons
kctl-odoo test profile manufacturing
```

### `kctl-odoo tr`

Alias: test run <module>

Usage: `kctl-odoo tr <module> [--tags]`

### `kctl-odoo traceback`

Parse, analyze, and suggest fixes for Odoo tracebacks.

| Command | Description |
|---------|-------------|
| `traceback analyze <logfile>` | Pattern-match common errors in a log file and suggest fixes. |
| `traceback parse <logfile>` | Extract module, model, method, error type from Odoo tracebacks. |
| `traceback recent [--count] [--service]` | Show last N tracebacks from Docker logs. |
| `traceback suggest <error_text>` | Given an error message, suggest cause and fix. |

### `kctl-odoo translations`

Manage PO translation files for Odoo modules.

| Command | Description |
|---------|-------------|
| `translations coverage [--module]` | Show translation coverage per module per language. |
| `translations export-all [--lang] [--output_dir]` | Batch export PO files for all installed private modules via Odoo. |
| `translations import-all [--lang] [--overwrite]` | Batch import PO files for all private modules from i18n/ directories. |
| `translations missing [--module] [--lang]` | Show untranslated strings in PO files. |
| `translations validate [--module]` | Validate PO syntax and format string consistency. |

### `kctl-odoo tui`

Launch the interactive TUI.

Usage: `kctl-odoo tui [--profile]`

### `kctl-odoo users`

Manage Odoo users.

| Command | Description |
|---------|-------------|
| `users activate <identifier>` | Re-enable a deactivated user so they can log in again. |
| `users add-group <identifier> <groups>` | Add one or more groups to a user. |
| `users create <login> [--name] [--email] [--password] [--oauth_uid] [--oauth_provider] [--groups] [--explain]` | Create a new Odoo user with optional SSO mapping. |
| `users create-apikey <login> [--name]` | Create a new API key for a user and display its record ID. |
| `users deactivate <identifier>` | Disable a user so they cannot log in without deleting the account. |
| `users get <identifier>` | Show full details for a user by ID or login. |
| `users groups <login>` | List all security groups assigned to a user, grouped by category. |
| `users list [--limit] [--active_only]` | List Odoo internal users with login, company, and status. |
| `users list-apikeys <login>` | List all API keys registered for a user. |
| `users remove-group <identifier> <groups>` | Remove one or more security groups from a user. |
| `users reset-password <login>` | Trigger an email-based password reset for a user. |
| `users revoke-apikey <key_id> [--force]` | Delete an API key record by its database ID. |
| `users set-password <login> <password> [--force]` | Set a user's password directly. |
| `users update <identifier> [--name] [--email] [--lang] [--tz] [--oauth_uid] [--oauth_provider]` | Update profile fields for an existing user. |

**Examples:**
```bash
kctl-odoo users activate john.doe
kctl-odoo users activate 42
kctl-odoo users add-group admin operating_unit.group_manager_operating_unit
kctl-odoo users add-group admin stock_request.group_stock_request_manager 42
kctl-odoo users create jane.doe --name "Jane Doe" --email jane@example.com
```

### `kctl-odoo views`

XML view validation and xpath analysis.

| Command | Description |
|---------|-------------|
| `views duplicates` | Find duplicate view IDs (record id=) across all private modules. |
| `views inheritance <view_id>` | Show the inheritance chain for a view from ir.ui.view. |
| `views parse <file>` | Parse a single XML file and show the element tree structure. |
| `views render <template>` | Show QWeb template structure from running Odoo. |
| `views validate [--module]` | Parse all XML view files, check syntax, deprecated patterns (states=, tree vs list). |
| `views xpath-test <view_id> <xpath>` | Test an XPath expression against a view definition in running Odoo. |

**Examples:**
```bash
kctl-odoo views duplicates
kctl-odoo views inheritance sale.view_order_form
kctl-odoo views inheritance account.view_move_form
kctl-odoo views parse src/private/my_module/views/res_partner_views.xml
kctl-odoo views render mail.message_notification_email
```

### `kctl-odoo website`

Website & eCommerce: pages, products, publishing.

| Command | Description |
|---------|-------------|
| `website list [--published] [--limit]` | List website pages. |
| `website menus` | List website menu items in tree structure. |
| `website orders [--state] [--limit]` | List eCommerce orders (sale orders placed via website). |
| `website pages [--published] [--limit]` | List website pages. |
| `website products [--published] [--limit]` | List eCommerce products. |
| `website publish <model> <ids>` | Publish records by setting website_published=True. |
| `website redirects [--limit]` | List URL redirects configured on the website. |
| `website summary` | Dashboard — page count, published product count, eCommerce order count. |
| `website unpublish <model> <ids>` | Unpublish records by setting website_published=False. |
| `website visitors [--days]` | Visitor stats for the last N days. |

**Examples:**
```bash
kctl-odoo website pages
kctl-odoo website pages --published
kctl-odoo website pages --limit 20
kctl-odoo website menus
kctl-odoo website orders
```

### `kctl-odoo wf`

Alias: workflow

### `kctl-odoo workers`

Monitor Odoo worker and server status.

| Command | Description |
|---------|-------------|
| `workers info` | Show server configuration parameters (workers, limits, etc.). |
| `workers longpoll` | Check longpolling/websocket status via bus.bus model. |
| `workers status` | Check if Odoo is responding and show server version info. |

### `kctl-odoo workflow`

Run multi-step workflows with retry and rollback.

| Command | Description |
|---------|-------------|
| `workflow list` | List available workflows. |
| `workflow run <name> [--dry_run] [--force]` | Execute a workflow. |
| `workflow status` | Show last workflow run result. |

**Examples:**
```bash
kctl-odoo workflow list
kctl-odoo workflow list --json
kctl-odoo workflow run deploy-safe
kctl-odoo workflow run maintenance-window --dry-run
kctl-odoo workflow run maintenance-window --force
```

## Configuration

Shared config: `~/.config/kodemeio/config.yaml`

```bash
kctl-odoo config init       # Interactive setup
kctl-odoo config show       # Show current config
kctl-odoo config profiles   # List profiles
kctl-odoo config current    # Show active profile
kctl-odoo config validate   # Verify config
```
