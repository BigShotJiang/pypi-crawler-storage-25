"""Tests for kctl-odoo analyze commands."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


class TestPresetRegistry:
    def test_builtin_presets_load(self) -> None:
        from kctl_odoo.commands.analytics.presets import BUILTIN_PRESETS

        assert len(BUILTIN_PRESETS) >= 8
        for name, preset in BUILTIN_PRESETS.items():
            assert "model" in preset or "engine" in preset
            assert "description" in preset
            assert "measure" in preset

    def test_top_products_preset_shape(self) -> None:
        from kctl_odoo.commands.analytics.presets import BUILTIN_PRESETS

        tp = BUILTIN_PRESETS["top-products"]
        assert tp["model"] == "sale.order.line"
        assert tp["measure"] == "price_subtotal"
        assert "product_id" in tp["group_by"]
        assert tp.get("reconciles_with", {}).get("report") == "profit_loss"

    def test_preset_schema_validates(self) -> None:
        from kctl_odoo.commands.analytics.schema import validate_preset_schema

        valid = {
            "name": "test",
            "description": "Test preset",
            "model": "sale.order.line",
            "measure": "price_subtotal",
            "group_by": ["product_id"],
        }
        errors = validate_preset_schema(valid)
        assert errors == []

    def test_preset_schema_catches_missing_fields(self) -> None:
        from kctl_odoo.commands.analytics.schema import validate_preset_schema

        invalid = {"name": "test"}
        errors = validate_preset_schema(invalid)
        assert len(errors) > 0
        assert any("model" in e or "measure" in e for e in errors)


class TestEngine:
    def test_build_read_group_args(self) -> None:
        from kctl_odoo.commands.analytics.engine import build_read_group_args
        from kctl_odoo.commands.analytics.presets import BUILTIN_PRESETS

        preset = BUILTIN_PRESETS["top-products"]
        args = build_read_group_args(
            preset,
            company_ids=[1, 2],
            date_from="2026-01-01",
            date_to="2026-04-30",
            limit=10,
        )
        assert args["model"] == "sale.order.line"
        assert args["fields"] == ["price_subtotal"]
        assert args["groupby"] == ["product_id"]
        assert args["limit"] == 10
        domain = args["domain"]
        assert ("company_id", "in", [1, 2]) in domain

    def test_execute_read_group_preset(self) -> None:
        from kctl_odoo.commands.analytics.engine import execute_preset

        mock_client = MagicMock()
        mock_client.read_group.return_value = [
            {"product_id": [1, "Widget A"], "price_subtotal": 500000, "__count": 10},
            {"product_id": [2, "Gadget B"], "price_subtotal": 300000, "__count": 5},
        ]

        preset = {
            "name": "test",
            "model": "sale.order.line",
            "measure": "price_subtotal",
            "aggregator": "sum",
            "group_by": ["product_id"],
            "domain_template": [],
            "default_limit": 10,
            "output_columns": [
                {"key": "product_id", "header": "Product", "type": "string"},
                {"key": "price_subtotal", "header": "Revenue", "type": "amount"},
            ],
        }

        result = execute_preset(mock_client, preset, company_ids=[1], date_from="2026-01-01", date_to="2026-04-30")
        assert len(result["rows"]) == 2
        assert result["rows"][0]["product_id"] == "Widget A"
        assert result["query_total"] == 800000


class TestValidator:
    def test_validate_fields_success(self) -> None:
        from kctl_odoo.commands.analytics.validator import validate_preset_fields

        mock_client = MagicMock()
        mock_client.execute_kw.return_value = {
            "product_id": {"type": "many2one"},
            "price_subtotal": {"type": "float"},
            "state": {"type": "selection"},
            "date": {"type": "date"},
            "company_id": {"type": "many2one"},
        }

        preset = {
            "model": "sale.order.line",
            "measure": "price_subtotal",
            "group_by": ["product_id"],
        }
        errors = validate_preset_fields(mock_client, preset)
        assert errors == []

    def test_validate_fields_bad_measure(self) -> None:
        from kctl_odoo.commands.analytics.validator import validate_preset_fields

        mock_client = MagicMock()
        mock_client.execute_kw.return_value = {
            "name": {"type": "char"},
        }

        preset = {
            "model": "sale.order.line",
            "measure": "nonexistent_field",
            "group_by": ["product_id"],
        }
        errors = validate_preset_fields(mock_client, preset)
        assert any("nonexistent_field" in e for e in errors)
