"""Tests for --format markdown in report quick (Tasks 14 & 15).

Uses the codebase-standard direct invocation pattern:
  _make_actx(client=...) + _make_ctx(actx) + call handler directly

This avoids the profile-resolution path that CliRunner triggers when no
``-p <profile>`` is supplied, and matches how every other command test in
this suite works (test_wave5_report.py, test_mgmt_reports.py, etc.).
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import typer
from kctl_lib import Output

from kctl_odoo.core.callbacks import AppContext


def _make_actx(client: MagicMock | None = None) -> MagicMock:
    """Build a mock AppContext with a real Output so stdout is captured."""
    actx = MagicMock(spec=AppContext)
    actx.json_mode = False
    actx.client = client or MagicMock()
    actx.output = Output(json_mode=False)
    return actx


def _make_ctx(actx: MagicMock) -> MagicMock:
    ctx = MagicMock(spec=typer.Context)
    ctx.obj = actx
    return ctx


def _make_client() -> MagicMock:
    """Minimal client stub: search_count succeeds (module check ok) + search_read
    returns a template, and execute_kw / read return sensible defaults."""
    c = MagicMock()
    c.search_count.return_value = 1  # report.type.registry exists
    c.search_read.return_value = [{"id": 7, "name": "Profit & Loss", "code": "PNL"}]
    c.uid = 2
    c.read.return_value = [{"company_id": [1, "TPP"]}]
    # Default to the no-api_report path (client-side render / JSON-RPC) so the
    # existing tests exercise that path. The api_report fast-path is covered by
    # its own test that flips this to True.
    c.has_api_report.return_value = False
    return c


def _fake_rd() -> dict:
    return {
        "report_name": "Profit & Loss",
        "company_name": "TPP",
        "period_label": "2026-04-01 to 2026-04-30",
        "tables": [
            {
                "columns": [
                    {"key": "name", "header": "", "type": "char"},
                    {"key": "balance", "header": "Amount", "type": "amount"},
                ],
                "rows": [
                    {"label": "Revenue", "kind": "total", "level": 0, "values": {"balance": 1_234_567_890}},
                    {
                        "label": "Cost of sales",
                        "kind": "total",
                        "level": 0,
                        "values": {"balance": 987_654_321},
                    },
                    {
                        "label": "Gross profit",
                        "kind": "subheader",
                        "level": 0,
                        "values": {"balance": 246_913_569},
                    },
                    {"label": "Some detail row", "kind": "line", "level": 1, "values": {"balance": 100}},
                ],
            }
        ],
    }


# ---------------------------------------------------------------------------
# Task 14: --format markdown basics
# ---------------------------------------------------------------------------


class TestReportQuickFormatMarkdown:
    """(a) Markdown header + headline-only filtering."""

    def test_emits_markdown_header(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title line is present in stdout."""
        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=_fake_rd(),
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files=None,
            )

        captured = capsys.readouterr()
        assert "*Profit & Loss" in captured.out, f"Title missing from: {captured.out!r}"

    def test_headline_rows_present(self, capsys: pytest.CaptureFixture[str]) -> None:
        """headline kinds (total, subheader) appear in output."""
        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=_fake_rd(),
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files=None,
            )

        captured = capsys.readouterr()
        assert "Revenue" in captured.out
        assert "Gross profit" in captured.out

    def test_detail_rows_excluded(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Detail rows (kind=line) must NOT appear in compact markdown."""
        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=_fake_rd(),
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files=None,
            )

        captured = capsys.readouterr()
        assert "Some detail row" not in captured.out, "Detail row leaked into compact markdown"


# ---------------------------------------------------------------------------
# Task 15: --with-files xlsx / pdf / failure
# ---------------------------------------------------------------------------


class TestReportQuickWithFiles:
    """(b-d) --with-files tests."""

    def test_with_files_xlsx_emits_media_token(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """(b) --with-files xlsx → exactly one MEDIA token ending .xlsx; file exists."""
        monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))

        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with (
            patch(
                "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
                return_value=_fake_rd(),
            ),
            patch(
                "kctl_odoo.commands.report.mgmt_framework._render_xlsx_bytes",
                return_value=b"<xlsx-stub>",
            ),
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files="xlsx",
            )

        captured = capsys.readouterr()
        media_lines = [ln for ln in captured.out.splitlines() if ln.startswith("MEDIA:")]
        assert len(media_lines) == 1, f"Expected 1 MEDIA line, got: {media_lines}"
        assert media_lines[0].endswith(".xlsx"), f"MEDIA line doesn't end with .xlsx: {media_lines[0]}"
        file_path = Path(media_lines[0][len("MEDIA:") :])
        assert file_path.exists(), f"Reported file does not exist: {file_path}"

    def test_with_files_pdf_degrades_with_note(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """(c) --with-files pdf (no api_report) → graceful 'PDF unavailable' note; no .pdf MEDIA token."""
        monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))

        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=_fake_rd(),
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files="pdf",
            )

        captured = capsys.readouterr()
        # Markdown body still present
        assert "*Profit & Loss" in captured.out, f"Title missing: {captured.out!r}"
        # Graceful note present (client-side fallback can't render PDF)
        assert "PDF unavailable" in captured.out
        # No broken .pdf MEDIA token
        pdf_media = [ln for ln in captured.out.splitlines() if ln.startswith("MEDIA:") and ln.endswith(".pdf")]
        assert pdf_media == [], f"Unexpected PDF MEDIA tokens: {pdf_media}"

    def test_with_files_failure_keeps_markdown_body(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """(d) If XLSX generation fails, markdown body still emits + 'XLSX unavailable' note; no crash."""
        monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))

        def _boom(*_a: object, **_kw: object) -> bytes:
            raise RuntimeError("XLSX generation crashed")

        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with (
            patch(
                "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
                return_value=_fake_rd(),
            ),
            patch(
                "kctl_odoo.commands.report.mgmt_framework._render_xlsx_bytes",
                side_effect=_boom,
            ),
        ):
            # Must NOT raise — graceful degradation
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files="xlsx",
            )

        captured = capsys.readouterr()
        # Body still present
        assert "*Profit & Loss" in captured.out, f"Title missing: {captured.out!r}"
        # No MEDIA token emitted
        assert "MEDIA:" not in captured.out, "Broken MEDIA tag emitted on failure"
        # Degradation note present
        assert "XLSX unavailable" in captured.out

    def test_with_files_xlsx_via_api_report_fast_path(
        self, capsys: pytest.CaptureFixture[str], tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When api_report is installed, data comes from api_report_compute and the
        xlsx file from api_report_file (server-rendered) — not client-side render."""
        monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))

        from kctl_odoo.commands.report.mgmt_framework import report_quick

        client = _make_client()
        client.has_api_report.return_value = True
        client.api_report_compute.return_value = _fake_rd()
        client.api_report_file.return_value = b"<server-rendered-xlsx>"
        actx = _make_actx(client)
        ctx = _make_ctx(actx)

        # NOTE: _fetch_report_data is NOT patched — the real one must route to
        # api_report_compute because has_api_report() is True.
        report_quick(
            ctx,
            type_code="profit_loss",
            date_from="2026-04-01",
            date_to="2026-04-30",
            as_of_date=None,
            company=None,
            company_ids=None,
            output=None,
            fmt="markdown",
            with_files="xlsx",
        )

        captured = capsys.readouterr()
        # Data fast-path used
        client.api_report_compute.assert_called_once()
        # File fast-path used (server-rendered bytes), not client-side render
        client.api_report_file.assert_called_once()
        assert client.api_report_file.call_args.args[0] == "xlsx"
        # MEDIA token present + the server bytes were written to disk
        media = [ln for ln in captured.out.splitlines() if ln.startswith("MEDIA:") and ln.endswith(".xlsx")]
        assert len(media) == 1, f"expected one xlsx MEDIA token: {captured.out!r}"
        written = Path(media[0][len("MEDIA:") :])
        assert written.exists() and written.read_bytes() == b"<server-rendered-xlsx>"


# ---------------------------------------------------------------------------
# Task 16: analyze run + analyze presets --format markdown
# ---------------------------------------------------------------------------

_FAKE_TOP_PRODUCTS_PRESET: dict = {
    "description": "Top N products by revenue",
    "model": "sale.order.line",
    "measure": "price_subtotal",
    "aggregator": "sum",
    "group_by": ["product_id"],
    "order_by": "price_subtotal desc",
    "default_limit": 20,
    "domain_template": [("state", "in", ["sale", "done"])],
    "output_columns": [
        {"key": "product_id", "header": "Product", "type": "string"},
        {"key": "price_subtotal", "header": "Revenue", "type": "amount"},
    ],
}

_FAKE_EXECUTE_RESULT: dict = {
    "preset": "top-products",
    "rows": [
        {"product_id": "Coffee Beans Premium 1kg", "price_subtotal": 45_000_000},
        {"product_id": "Roasted Beans Espresso 500g", "price_subtotal": 32_500_000},
    ],
    "row_count": 2,
    "query_total": 77_500_000.0,
    "company_ids": [1],
    "date_from": "2026-04-01",
    "date_to": "2026-04-30",
}


class TestAnalyzeRunFormatMarkdown:
    """Task 16a: analyze run <preset> --format markdown."""

    def test_emits_markdown_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title line contains preset name."""
        from kctl_odoo.commands.analytics import run_preset

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {"top-products": _FAKE_TOP_PRODUCTS_PRESET}
        fake_result = dict(_FAKE_EXECUTE_RESULT)

        with (
            patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets),
            patch("kctl_odoo.commands.analytics.execute_preset", return_value=fake_result),
            patch("kctl_odoo.commands.analytics.validate_preset_fields", return_value=[]),
            patch("kctl_odoo.commands.analytics.reconcile_with_report", return_value={"pass": True, "delta_pct": 0.0}),
        ):
            run_preset(
                ctx,
                preset_name="top-products",
                company=None,
                company_ids=None,
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                limit=None,
                validate=False,
                output=None,
                fmt="markdown",
            )

        captured = capsys.readouterr()
        assert "*Top Products" in captured.out, f"Title not in output: {captured.out!r}"

    def test_emits_row_data(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Row data (product names and revenue) appears in output."""
        from kctl_odoo.commands.analytics import run_preset

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {"top-products": _FAKE_TOP_PRODUCTS_PRESET}
        fake_result = dict(_FAKE_EXECUTE_RESULT)

        with (
            patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets),
            patch("kctl_odoo.commands.analytics.execute_preset", return_value=fake_result),
            patch("kctl_odoo.commands.analytics.validate_preset_fields", return_value=[]),
            patch("kctl_odoo.commands.analytics.reconcile_with_report", return_value={"pass": True, "delta_pct": 0.0}),
        ):
            run_preset(
                ctx,
                preset_name="top-products",
                company=None,
                company_ids=None,
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                limit=None,
                validate=False,
                output=None,
                fmt="markdown",
            )

        captured = capsys.readouterr()
        assert "Coffee Beans Premium 1kg" in captured.out
        assert "45,000,000" in captured.out

    def test_validation_bullet_present_when_validate(self, capsys: pytest.CaptureFixture[str]) -> None:
        """When validate=True and validation dict present, a validation bullet is shown."""
        from kctl_odoo.commands.analytics import run_preset

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {"top-products": _FAKE_TOP_PRODUCTS_PRESET}
        fake_result = dict(_FAKE_EXECUTE_RESULT)

        with (
            patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets),
            patch("kctl_odoo.commands.analytics.execute_preset", return_value=fake_result),
            patch("kctl_odoo.commands.analytics.validate_preset_fields", return_value=[]),
            patch(
                "kctl_odoo.commands.analytics.reconcile_with_report",
                return_value={"pass": True, "delta_pct": 0.005},
            ),
        ):
            run_preset(
                ctx,
                preset_name="top-products",
                company=None,
                company_ids=None,
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                limit=None,
                validate=True,
                output=None,
                fmt="markdown",
            )

        captured = capsys.readouterr()
        assert "Validated" in captured.out, f"Validation bullet missing: {captured.out!r}"
        assert "✓" in captured.out


class TestAnalyzePresetsFormatMarkdown:
    """Task 16b: analyze presets --format markdown."""

    def test_emits_analytics_presets_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title '*Analytics Presets*' appears in output."""
        from kctl_odoo.commands.analytics import list_presets

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {
            "top-products": {"description": "Top 20 products by revenue"},
            "ar-aging": {"description": "Accounts receivable aging buckets"},
        }

        with patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets):
            list_presets(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "*Analytics Presets*" in captured.out, f"Title missing: {captured.out!r}"

    def test_emits_preset_bullets(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Each preset name appears as a bullet in the output."""
        from kctl_odoo.commands.analytics import list_presets

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {
            "top-products": {"description": "Top 20 products by revenue"},
            "ar-aging": {"description": "Accounts receivable aging buckets"},
        }

        with patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets):
            list_presets(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "top-products" in captured.out
        assert "ar-aging" in captured.out

    def test_emits_both_name_and_description(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Each bullet includes the description alongside the preset name."""
        from kctl_odoo.commands.analytics import list_presets

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        fake_presets = {
            "top-products": {"description": "Top 20 products by revenue"},
        }

        with patch("kctl_odoo.commands.analytics._all_presets", return_value=fake_presets):
            list_presets(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "Top 20 products by revenue" in captured.out


# ---------------------------------------------------------------------------
# Task 17: kpi run + kpi list --format markdown
# ---------------------------------------------------------------------------
# NOTE: Real shape confirmation
# _fetch_kpis(client, instance_id) → dict from execute_kw("compute", [[id]])
#   Shape: {kpi_key: computed_value, ...}  e.g. {"revenue": 246000000, "margin": 15.2}
#   NOT the plan's assumed {name, value, target, delta_pct} — those are not in the
#   OCA mis_builder compute RPC response. The real response is a flat key→value dict.
#
# _fetch_kpi_instances(client, limit) → list[dict] from search_read on mis.report
#   Shape: [{id, name, description}, ...]
#   (Plan called this "kpi list" but it lists mis.report *templates*, not instances)
# ---------------------------------------------------------------------------

_FAKE_KPI_COMPUTE_RESULT: dict = {
    "revenue_kpi": 246_000_000,
    "net_margin_kpi": 15.2,
    "employee_count": 120,
}

_FAKE_KPI_INSTANCES: list[dict] = [
    {"id": 1, "name": "sales_dashboard", "description": "Monthly sales KPIs"},
    {"id": 2, "name": "ops_dashboard", "description": "Operations metrics"},
]


class TestKpiRunFormatMarkdown:
    """Task 17a: kpi run <instance_id> --format markdown."""

    def test_emits_markdown_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title line contains the instance name."""
        from kctl_odoo.commands.kpi_cmd import run as kpi_run

        c = MagicMock()
        c.search_count.return_value = 1  # model_available → True
        c.read.return_value = [
            {"name": "Sales Dashboard", "report_id": [1, "TPP"], "date_from": "2026-04-01", "date_to": "2026-04-30"}
        ]

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpis", return_value=_FAKE_KPI_COMPUTE_RESULT):
            kpi_run(ctx, instance_id=3, fmt="markdown")

        captured = capsys.readouterr()
        assert "*Sales Dashboard*" in captured.out, f"Title missing: {captured.out!r}"

    def test_emits_kpi_keys(self, capsys: pytest.CaptureFixture[str]) -> None:
        """All KPI keys from the compute result appear in output."""
        from kctl_odoo.commands.kpi_cmd import run as kpi_run

        c = MagicMock()
        c.search_count.return_value = 1
        c.read.return_value = [
            {"name": "Sales Dashboard", "report_id": [1, "TPP"], "date_from": "2026-04-01", "date_to": "2026-04-30"}
        ]

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpis", return_value=_FAKE_KPI_COMPUTE_RESULT):
            kpi_run(ctx, instance_id=3, fmt="markdown")

        captured = capsys.readouterr()
        assert "revenue_kpi" in captured.out
        assert "net_margin_kpi" in captured.out

    def test_emits_formatted_values(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Numeric values are formatted with thousands separators."""
        from kctl_odoo.commands.kpi_cmd import run as kpi_run

        c = MagicMock()
        c.search_count.return_value = 1
        c.read.return_value = [
            {"name": "Sales Dashboard", "report_id": [1, "TPP"], "date_from": "2026-04-01", "date_to": "2026-04-30"}
        ]

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpis", return_value=_FAKE_KPI_COMPUTE_RESULT):
            kpi_run(ctx, instance_id=3, fmt="markdown")

        captured = capsys.readouterr()
        # Integer value with thousands separator
        assert "246,000,000" in captured.out
        # Float value formatted to 2dp
        assert "15.20" in captured.out

    def test_emits_kpi_count_bullet(self, capsys: pytest.CaptureFixture[str]) -> None:
        """A summary bullet showing KPI count is present."""
        from kctl_odoo.commands.kpi_cmd import run as kpi_run

        c = MagicMock()
        c.search_count.return_value = 1
        c.read.return_value = [
            {"name": "Sales Dashboard", "report_id": [1, "TPP"], "date_from": "2026-04-01", "date_to": "2026-04-30"}
        ]

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpis", return_value=_FAKE_KPI_COMPUTE_RESULT):
            kpi_run(ctx, instance_id=3, fmt="markdown")

        captured = capsys.readouterr()
        assert "3 KPIs" in captured.out


class TestKpiListFormatMarkdown:
    """Task 17b: kpi list --format markdown."""

    def test_emits_kpi_instances_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title '*KPI Instances*' appears in output."""
        from kctl_odoo.commands.kpi_cmd import list_reports

        c = MagicMock()
        c.search_count.return_value = 1  # model_available → True

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpi_instances", return_value=_FAKE_KPI_INSTANCES):
            list_reports(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "*KPI Instances*" in captured.out, f"Title missing: {captured.out!r}"

    def test_emits_instance_names_as_bullets(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Each instance name appears as a backtick-quoted bullet."""
        from kctl_odoo.commands.kpi_cmd import list_reports

        c = MagicMock()
        c.search_count.return_value = 1

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpi_instances", return_value=_FAKE_KPI_INSTANCES):
            list_reports(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "`sales_dashboard`" in captured.out
        assert "`ops_dashboard`" in captured.out

    def test_emits_instance_ids(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Each instance bullet contains its id."""
        from kctl_odoo.commands.kpi_cmd import list_reports

        c = MagicMock()
        c.search_count.return_value = 1

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpi_instances", return_value=_FAKE_KPI_INSTANCES):
            list_reports(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "id=1" in captured.out
        assert "id=2" in captured.out

    def test_emits_available_count_in_subtitle(self, capsys: pytest.CaptureFixture[str]) -> None:
        """The subtitle shows how many instances are available."""
        from kctl_odoo.commands.kpi_cmd import list_reports

        c = MagicMock()
        c.search_count.return_value = 1

        actx = _make_actx(c)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.kpi_cmd._fetch_kpi_instances", return_value=_FAKE_KPI_INSTANCES):
            list_reports(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "2 available" in captured.out


# ---------------------------------------------------------------------------
# Task 18: dashboard summary + dashboard digest --format markdown
# ---------------------------------------------------------------------------
# NOTE: Real shape confirmation
#
# _build_summary(c) is an ASYNC coroutine — use AsyncMock.
# Real json_data shape:
#   server:     {version, database, rpc_latency_ms, uid, user, company}
#   modules:    {installed, core, oca, private, to_upgrade, to_install, to_remove, broken_total}
#   users:      {internal, portal, partners, companies}
#   mail:       {outgoing, exception}          (optional — only if mail.mail model available)
#   crons:      {total, active, stale}
#   queue_jobs: {pending, started, failed}     (optional)
#   storage:    {attachments}                  (optional)
#   business:   {confirmed_sales, posted_invoices, active_products, ...}  (optional)
#   alerts:     [str, ...]
#
# _build_digest(c) is a SYNC function.
# Real json_data shape:
#   sales:       {confirmed_today, draft}      (optional)
#   inventory:   {pending_transfers, late_transfers}  (optional)
#   receivables: {overdue_invoices}            (optional)
#   mail:        {outgoing, exception}         (optional)
#   crons:       {stale}                       (optional)
#   queue_jobs:  {pending, failed}             (optional)
#   alerts:      [str, ...]
#
# The plan's assumed shapes ({financial, operations, attention} and
# {sections: [{label, value}]}) differ from reality — tests use real shapes.
# ---------------------------------------------------------------------------

_FAKE_SUMMARY_DATA: dict = {
    "server": {
        "version": "18.0",
        "database": "tpp_odoo_erp",
        "rpc_latency_ms": 42,
        "uid": 2,
        "user": "admin",
        "user_name": "Administrator",
        "company": "TPP",
    },
    "modules": {
        "installed": 120,
        "core": 80,
        "oca": 30,
        "private": 10,
        "to_upgrade": 0,
        "to_install": 0,
        "to_remove": 0,
        "broken_total": 0,
    },
    "users": {"internal": 25, "portal": 5, "partners": 340, "companies": 3},
    "mail": {"outgoing": 2, "exception": 0},
    "crons": {"total": 45, "active": 43, "stale": 1},
    "queue_jobs": {"pending": 3, "started": 0, "failed": 0},
    "storage": {"attachments": 15_000},
    "business": {
        "confirmed_sales": 88,
        "posted_invoices": 212,
        "active_products": 550,
        "pending_transfers": 14,
        "active_mos": 7,
        "employees": 47,
    },
    "alerts": ["1 stale cron(s)"],
}

_FAKE_DIGEST_DATA: dict = {
    "sales": {"confirmed_today": 12, "draft": 3},
    "inventory": {"pending_transfers": 8, "late_transfers": 2},
    "receivables": {"overdue_invoices": 5},
    "mail": {"outgoing": 1, "exception": 0},
    "crons": {"stale": 1},
    "queue_jobs": {"pending": 4, "failed": 0},
    "alerts": ["1 stale cron(s)"],
}


class TestDashboardSummaryFormatMarkdown:
    """Task 18a: dashboard summary --format markdown.

    _build_summary is async — patched with AsyncMock returning _FAKE_SUMMARY_DATA.
    The handler is itself async (wrapped by @async_command), so we invoke the
    underlying coroutine directly via asyncio.run().
    """

    def _invoke(self, capsys: pytest.CaptureFixture[str]) -> str:
        """Invoke the summary handler with markdown format and return stdout."""
        from unittest.mock import AsyncMock

        from kctl_odoo.commands.dashboard import info as summary_handler

        actx = _make_actx(_make_client())
        # async_client must be an AsyncMock so `await c.authenticate()` works
        async_client = AsyncMock()
        actx.async_client = async_client
        ctx = _make_ctx(actx)

        # info is decorated with @async_command which makes it synchronous at
        # the Typer level. Patch _build_summary (the async data-fetch seam) so
        # no real RPC calls are made.
        with patch(
            "kctl_odoo.commands.dashboard._build_summary",
            new=AsyncMock(return_value=_FAKE_SUMMARY_DATA),
        ):
            summary_handler(ctx, watch=False, interval=30, fmt="markdown")

        captured = capsys.readouterr()
        return captured.out

    def test_emits_executive_summary_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title '*Executive Summary*' appears in output."""
        out = self._invoke(capsys)
        assert "*Executive Summary*" in out, f"Title missing: {out!r}"

    def test_emits_server_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """SERVER section header and database name appear."""
        out = self._invoke(capsys)
        assert "*SERVER*" in out, f"SERVER section missing: {out!r}"
        assert "tpp_odoo_erp" in out

    def test_emits_modules_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """MODULES section header and installed count appear."""
        out = self._invoke(capsys)
        assert "*MODULES*" in out, f"MODULES section missing: {out!r}"
        assert "120" in out

    def test_emits_users_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """USERS section header and internal user count appear."""
        out = self._invoke(capsys)
        assert "*USERS*" in out, f"USERS section missing: {out!r}"
        assert "25" in out

    def test_emits_operations_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """OPERATIONS section header and mail/crons data appear."""
        out = self._invoke(capsys)
        assert "*OPERATIONS*" in out, f"OPERATIONS section missing: {out!r}"
        assert "43" in out  # cron active count

    def test_emits_alerts_section_when_present(self, capsys: pytest.CaptureFixture[str]) -> None:
        """ALERTS section and the alert bullet appear when alerts are non-empty."""
        out = self._invoke(capsys)
        assert "*ALERTS*" in out, f"ALERTS section missing: {out!r}"
        assert "stale cron" in out

    def test_server_user_display_name_restored(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Fix 1 regression: SERVER section must show 'Name (login)' not bare login."""
        out = self._invoke(capsys)
        # Both display name and login must appear together in the markdown SERVER table
        assert "Administrator" in out, f"user_name missing from markdown output: {out!r}"
        assert "admin" in out, f"login missing from markdown output: {out!r}"
        # The combined format 'Administrator (admin)' must be present
        assert "Administrator (admin)" in out, f"Combined user display missing: {out!r}"

    def test_business_section_includes_pending_transfers(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Fix 2 parity: BUSINESS section must include Pending transfers row."""
        out = self._invoke(capsys)
        assert "Pending transfers" in out or "pending_transfers" in out.lower(), (
            f"Pending transfers missing from BUSINESS section: {out!r}"
        )
        assert "14" in out, f"pending_transfers value (14) missing: {out!r}"

    def test_business_section_includes_active_mos(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Fix 2 parity: BUSINESS section must include Active MOs row."""
        out = self._invoke(capsys)
        assert "Active MOs" in out or "active_mos" in out.lower(), f"Active MOs missing from BUSINESS section: {out!r}"
        assert "7" in out, f"active_mos value (7) missing: {out!r}"


class TestDashboardDigestFormatMarkdown:
    """Task 18b: dashboard digest --format markdown.

    _build_digest is SYNC — patched with a regular MagicMock return_value.
    """

    def _invoke(self, capsys: pytest.CaptureFixture[str]) -> str:
        """Invoke the digest handler with markdown format and return stdout."""
        from kctl_odoo.commands.dashboard import daily_digest

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.dashboard._build_digest",
            return_value=_FAKE_DIGEST_DATA,
        ):
            daily_digest(ctx, fmt="markdown")

        captured = capsys.readouterr()
        return captured.out

    def test_emits_daily_digest_title(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title '*Daily Digest*' appears in output."""
        out = self._invoke(capsys)
        assert "*Daily Digest*" in out, f"Title missing: {out!r}"

    def test_emits_sales_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """SALES section and confirmed count appear."""
        out = self._invoke(capsys)
        assert "*SALES*" in out, f"SALES section missing: {out!r}"
        assert "12" in out  # confirmed_today

    def test_emits_inventory_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """INVENTORY section and late-transfer count appear."""
        out = self._invoke(capsys)
        assert "*INVENTORY*" in out, f"INVENTORY section missing: {out!r}"
        assert "2" in out  # late_transfers

    def test_emits_receivables_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """RECEIVABLES section and overdue invoice count appear."""
        out = self._invoke(capsys)
        assert "*RECEIVABLES*" in out, f"RECEIVABLES section missing: {out!r}"
        assert "5" in out  # overdue_invoices

    def test_emits_crons_section(self, capsys: pytest.CaptureFixture[str]) -> None:
        """CRONS section and stale count appear."""
        out = self._invoke(capsys)
        assert "*CRONS*" in out, f"CRONS section missing: {out!r}"
        assert "1" in out  # stale

    def test_emits_attention_section_when_alerts_present(self, capsys: pytest.CaptureFixture[str]) -> None:
        """ATTENTION section and alert bullet appear when alerts are non-empty."""
        out = self._invoke(capsys)
        assert "*ATTENTION*" in out, f"ATTENTION section missing: {out!r}"
        assert "stale cron" in out


# ---------------------------------------------------------------------------
# Task 19: doctor ai-summary --format markdown + --json markdown_ready flag
# ---------------------------------------------------------------------------

_FAKE_AI_SUMMARY: dict = {
    "kctl_version": "0.11.0",
    "profile": "idtpp-tpp-odoo-erp",
    "odoo_version": "18.0",
    "connection_status": "connected",
    "uid": 2,
    "database": "tpp_odoo_erp",
    "installed_modules": 120,
    "active_users": 25,
    "report_type_count": 5,
    "command_count": 200,
    "health_status": "healthy",
    "warnings": ["account_payment_term has pending migration"],
    "recommended_next_commands": [
        "kctl-odoo commands list --filter <keyword>",
        "kctl-odoo doctor self-test --json",
    ],
}


class TestDoctorAiSummaryFormatMarkdown:
    """Task 19a: doctor ai-summary --format markdown."""

    def test_emits_markdown_title_with_profile(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Title contains 'Odoo Health' and the profile name."""
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "*Odoo Health" in captured.out, f"Title missing from: {captured.out!r}"
        assert "idtpp-tpp-odoo-erp" in captured.out, f"Profile missing from: {captured.out!r}"

    def test_emits_status_fields_in_table(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Connection status and installed modules count appear in the monospace table."""
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "Connection" in captured.out, f"Connection field missing: {captured.out!r}"
        assert "connected" in captured.out, f"connection_status value missing: {captured.out!r}"
        assert "120" in captured.out, f"installed_modules value missing: {captured.out!r}"

    def test_emits_warning_as_bullet(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Warnings appear as bullet items in the markdown output."""
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "account_payment_term" in captured.out, f"Warning bullet missing: {captured.out!r}"

    def test_emits_next_step_bullets(self, capsys: pytest.CaptureFixture[str]) -> None:
        """Recommended next commands appear as backtick-quoted bullets."""
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="markdown")

        captured = capsys.readouterr()
        assert "Next recommended:" in captured.out, f"Next-step bullet missing: {captured.out!r}"
        assert "kctl-odoo doctor self-test --json" in captured.out, f"Next-step cmd missing: {captured.out!r}"


class TestDoctorAiSummaryJsonMarkdownReady:
    """Task 19b: doctor ai-summary --json includes markdown_ready: true."""

    def test_json_output_includes_markdown_ready_true(self, capsys: pytest.CaptureFixture[str]) -> None:
        """The --json payload advertises markdown support via 'markdown_ready': true."""
        import json as _json
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        # Simulate --json mode (both the flag the handler checks AND the Output instance)
        actx.json_mode = True
        actx.output = Output(json_mode=True)
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="pretty")

        captured = capsys.readouterr()
        payload = _json.loads(captured.out)
        assert payload.get("markdown_ready") is True, f"markdown_ready missing/false in: {payload}"

    def test_fmt_json_also_includes_markdown_ready(self, capsys: pytest.CaptureFixture[str]) -> None:
        """When fmt='json' (explicit flag), markdown_ready is also present."""
        import json as _json
        from unittest.mock import patch

        from kctl_odoo.commands.troubleshoot import ai_summary

        actx = _make_actx(_make_client())
        actx.profile = "idtpp-tpp-odoo-erp"
        ctx = _make_ctx(actx)

        with patch("kctl_odoo.commands.troubleshoot._collect_ai_summary", return_value=dict(_FAKE_AI_SUMMARY)):
            ai_summary(ctx, fmt="json")

        captured = capsys.readouterr()
        payload = _json.loads(captured.out)
        assert payload.get("markdown_ready") is True, f"markdown_ready missing/false in: {payload}"


# ---------------------------------------------------------------------------
# Item 1: _extract_table period_label fallback from date args
# ---------------------------------------------------------------------------


class TestExtractTablePeriodLabelFallback:
    """When the API omits period_label, the markdown title must show the date range."""

    def test_title_includes_date_range_when_period_label_missing(self, capsys: pytest.CaptureFixture[str]) -> None:
        """report_quick with an rd that has no period_label still shows the date range."""
        from kctl_odoo.commands.report.mgmt_framework import report_quick

        # rd without period_label
        rd_no_label = {
            "report_name": "Profit & Loss",
            "company_name": "TPP",
            # period_label intentionally absent
            "tables": [
                {
                    "columns": [
                        {"key": "name", "header": "", "type": "char"},
                        {"key": "balance", "header": "Amount", "type": "amount"},
                    ],
                    "rows": [
                        {"label": "Revenue", "kind": "total", "level": 0, "values": {"balance": 100_000}},
                    ],
                }
            ],
        }

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=rd_no_label,
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files=None,
            )

        captured = capsys.readouterr()
        # The title must contain both the report name and the date range
        assert "*Profit & Loss" in captured.out, f"Report name missing: {captured.out!r}"
        assert "2026-04-01" in captured.out, f"date_from missing from title: {captured.out!r}"
        assert "2026-04-30" in captured.out, f"date_to missing from title: {captured.out!r}"

    def test_title_still_uses_period_label_when_present(self, capsys: pytest.CaptureFixture[str]) -> None:
        """When period_label is present, it is used — no regression."""
        from kctl_odoo.commands.report.mgmt_framework import report_quick

        actx = _make_actx(_make_client())
        ctx = _make_ctx(actx)

        with patch(
            "kctl_odoo.commands.report.mgmt_framework._fetch_report_data",
            return_value=_fake_rd(),  # has period_label = "2026-04-01 to 2026-04-30"
        ):
            report_quick(
                ctx,
                type_code="profit_loss",
                date_from="2026-04-01",
                date_to="2026-04-30",
                as_of_date=None,
                company=None,
                company_ids=None,
                output=None,
                fmt="markdown",
                with_files=None,
            )

        captured = capsys.readouterr()
        assert "2026-04-01 to 2026-04-30" in captured.out, f"period_label not used when present: {captured.out!r}"


# ---------------------------------------------------------------------------
# Item 2: analyze render_markdown numeric robustness
# ---------------------------------------------------------------------------


class TestAnalyzeRenderMarkdownNumericRobustness:
    """Column alignment and numeric-string formatting edge cases."""

    def test_column_right_aligned_when_first_row_is_none_but_later_row_is_numeric(self) -> None:
        """A column with None in row 0 but numeric in later rows must right-align."""
        from kctl_odoo.commands.analytics.engine import render_markdown

        result = {
            "preset": "test",
            "date_from": "2026-04-01",
            "date_to": "2026-04-30",
            "row_count": 2,
            "rows": [
                {"label": "Alpha", "amount": None},  # None in row 0
                {"label": "Beta", "amount": 12345},  # numeric in row 1
            ],
        }
        report = render_markdown(result)
        md = str(report)
        # "amount" column must be right-aligned → values padded/right in monospace
        # The key check: "12,345" must be formatted with thousands separator
        assert "12,345" in md, f"Thousands-formatted value missing: {md!r}"

    def test_numeric_string_values_formatted_with_thousands_separators(self) -> None:
        """Values like '45000000' (str) from JSON-RPC must be formatted as '45,000,000'."""
        from kctl_odoo.commands.analytics.engine import render_markdown

        result = {
            "preset": "top-products",
            "date_from": "2026-04-01",
            "date_to": "2026-04-30",
            "row_count": 1,
            "rows": [
                {"product_id": "Widget A", "price_subtotal": "45000000"},  # numeric string
            ],
        }
        report = render_markdown(result)
        md = str(report)
        assert "45,000,000" in md, f"Numeric string not formatted with thousands separators: {md!r}"

    def test_numeric_string_column_is_right_aligned(self) -> None:
        """A column containing only numeric strings must be detected as numeric → right-align."""
        from kctl_odoo.commands.analytics.engine import render_markdown

        result = {
            "preset": "test",
            "date_from": "2026-04-01",
            "date_to": "2026-04-30",
            "row_count": 2,
            "rows": [
                {"name": "A", "revenue": "10000"},
                {"name": "B", "revenue": "20000"},
            ],
        }
        report = render_markdown(result)
        md = str(report)
        # Both values should be thousands-formatted
        assert "10,000" in md, f"10000 not formatted: {md!r}"
        assert "20,000" in md, f"20000 not formatted: {md!r}"
