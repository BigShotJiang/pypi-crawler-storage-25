# kctl-odoo Markdown Reporting (Phase 0) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a portable Markdown output format (`--format markdown`) to six kctl-odoo report commands so AI agents (hermes) can deliver inline summaries plus XLSX/PDF attachments to Telegram/Mattermost/WhatsApp without any client-side conversion. Files are emitted as `MEDIA:<absolute-path>` tokens that hermes' gateway auto-uploads.

**Architecture:** Shared `MarkdownReport` builder in `kctl-lib` (chainable, deterministic, chunks at 4096 chars on block boundaries). Output dir + cleanup utilities in `kctl-lib/chat_emit`. Six kctl-odoo commands learn `--format markdown` and (where applicable) `--with-files xlsx,pdf`. The `Output` class gains a `format="markdown"` branch. One env-var line added to `hermes-init.sh` puts files on the hermes-state volume.

**Tech Stack:** Python 3.12+, dataclasses, pytest, Typer (existing). No new runtime dependencies — stdlib `uuid` for short suffixes; stdlib `tempfile` for atomic writes. Spec: `docs/superpowers/specs/2026-05-23-kctl-odoo-markdown-reporting-design.md`.

> **Scope note on `--with-files`:** v1 ships **`xlsx` only**, because `report quick` already renders XLSX client-side (trivial to adapt to bytes via `_render_xlsx_local`). **PDF is deferred to Phase 1 (`api_report`).** PDF currently requires creating a `report.instance` and an HTTP-controller download (`mgmt_framework.py:1528-1561`) — a heavier, more brittle flow (see the `0342bacf` fix where the `_render` RPC was blocked). Phase 1's `/api/v1/reports/{id}/pdf` endpoint is the clean home for PDF. In v1, passing `--with-files pdf` degrades gracefully with a note pointing to xlsx. This is a deliberate, honest narrowing of the spec's `xlsx,pdf` — PDF arrives 2 weeks later via the right mechanism, not a v1 hack.

---

## File structure

### Files to create

| Path | Purpose |
|---|---|
| `packages/kctl-lib/src/kctl_lib/markdown_report.py` | `MarkdownReport` dataclass + builder API + render/chunking |
| `packages/kctl-lib/src/kctl_lib/chat_emit.py` | `resolve_output_dir`, `build_filename`, `cleanup_old_files`, `atomic_write` |
| `packages/kctl-lib/tests/test_markdown_report.py` | Unit tests for builder + render + chunking |
| `packages/kctl-lib/tests/test_chat_emit.py` | Unit tests for output-dir + cleanup + atomic write |
| `packages/kctl-odoo/tests/test_format_markdown.py` | Integration tests for the 6 wired commands |

### Implementation note for Tasks 16-19 (data-fetch seams)

Tasks 16-19 (analyze, kpi, dashboard, doctor) follow the **same pattern as Task 14**: the markdown branch renders from a dict returned by a *data-fetch seam*. The tests mock that seam by name (`run_preset`, `list_presets`, `_fetch_kpis`, `_fetch_kpi_instances`, `_build_summary`, `_build_digest`, `_collect_ai_summary`). These names are the *intended* seams — **before writing each test, confirm the real handler's fetch function name** (grep the command module). If the handler currently fetches data inline (no named function), extract it into the named seam first (verbatim move, like Task 14's `_fetch_report_data`), then mock that. Do not invent a fetch function that returns a different shape than the real handler already consumes — read the handler, match its shape.

### Files to modify

| Path | Change |
|---|---|
| `packages/kctl-lib/src/kctl_lib/output.py` | Add `format="markdown"` branch in `Output.table()`; new `Output.markdown_report()` method |
| `packages/kctl-lib/src/kctl_lib/__init__.py` | Export `MarkdownReport` from public API |
| `packages/kctl-lib/src/kctl_lib/introspection.py` | Add `--markdown-ready` flag on `commands list` |
| `packages/kctl-lib/src/kctl_lib/__init__.py` | Bump `__version__` to `0.12.0` |
| `packages/kctl-odoo/src/kctl_odoo/commands/report/mgmt_framework.py` | `report quick` — extend `fmt` to accept `markdown`; add `--with-files` |
| `packages/kctl-odoo/src/kctl_odoo/commands/analytics/__init__.py` | `analyze run` + `presets` — `--format markdown` |
| `packages/kctl-odoo/src/kctl_odoo/commands/analytics/engine.py` | New `_render_markdown(...)` helper |
| `packages/kctl-odoo/src/kctl_odoo/commands/kpi_cmd.py` | `kpi run` + `list` — `--format markdown` |
| `packages/kctl-odoo/src/kctl_odoo/commands/dashboard.py` | `dashboard summary` + `digest` — `--format markdown` |
| `packages/kctl-odoo/src/kctl_odoo/commands/diagnose.py` | `doctor ai-summary` — refactor `to_markdown()` to use `MarkdownReport` |
| `packages/kctl-odoo/skills/odoo-admin/SKILL.md` | Add "Chat/Telegram delivery" section |
| `kodemeio-hermes/scripts/hermes-init.sh` | Append `export KCTL_ODOO_REPORT_DIR=/opt/data/reports` |

---

## Task 1: Scaffold `MarkdownReport` dataclass + minimal render

**Files:**
- Create: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Create: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing test**

```python
# packages/kctl-lib/tests/test_markdown_report.py
from kctl_lib.markdown_report import MarkdownReport


def test_title_only_renders_minimal():
    report = MarkdownReport(title="P&L — TPP")
    assert report.render() == "*P&L — TPP*\n"


def test_title_with_subtitle_renders_two_lines():
    report = MarkdownReport(title="P&L — TPP", subtitle="Generated 2026-05-23")
    assert report.render() == "*P&L — TPP*\n_Generated 2026-05-23_\n"
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: `ModuleNotFoundError: No module named 'kctl_lib.markdown_report'`

- [ ] **Step 3: Implement minimal `MarkdownReport`**

```python
# packages/kctl-lib/src/kctl_lib/markdown_report.py
"""Portable Markdown report builder for chat-platform delivery.

Output is GFM-lite — works across Telegram (MarkdownV2 after hermes escaping),
Mattermost (native GFM), and WhatsApp (restricted subset). No `#` headers, no
GFM tables (we use fenced code blocks for monospace alignment instead), no
MarkdownV2 backslash escaping (hermes' Telegram handler does that itself).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MarkdownReport:
    """Chainable builder for chat-platform-friendly Markdown reports."""

    title: str
    subtitle: str | None = None
    _blocks: list[dict] = field(default_factory=list)
    _media: list[Path] = field(default_factory=list)

    def render(self, max_chars: int = 4096) -> str:
        lines = [f"*{self.title}*"]
        if self.subtitle:
            lines.append(f"_{self.subtitle}_")
        return "\n".join(lines) + "\n"
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 2 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): scaffold MarkdownReport with title + subtitle render

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 2: `add_kv`, `add_bullet`, `add_bullets`, `add_note` builders

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_add_kv_renders_key_value_line():
    report = MarkdownReport(title="T").add_kv("Period", "2026-04-01 → 2026-04-30")
    assert "Period: 2026-04-01 → 2026-04-30" in report.render()


def test_add_bullet_renders_dash_prefix():
    report = MarkdownReport(title="T").add_bullet("Revenue up 12%")
    assert "- Revenue up 12%" in report.render()


def test_add_bullets_renders_multiple_lines():
    report = MarkdownReport(title="T").add_bullets(["First", "Second", "Third"])
    out = report.render()
    assert "- First" in out and "- Second" in out and "- Third" in out


def test_add_note_renders_italic():
    report = MarkdownReport(title="T").add_note("validated against P&L")
    assert "_validated against P&L_" in report.render()


def test_builders_chainable_return_self():
    report = MarkdownReport(title="T")
    assert report.add_kv("a", "b") is report
    assert report.add_bullet("x") is report
    assert report.add_bullets(["y", "z"]) is report
    assert report.add_note("n") is report
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 5 new tests fail with `AttributeError: 'MarkdownReport' object has no attribute 'add_kv'`

- [ ] **Step 3: Implement builders + extend render**

```python
# packages/kctl-lib/src/kctl_lib/markdown_report.py — replace body of class
from collections.abc import Sequence


@dataclass
class MarkdownReport:
    title: str
    subtitle: str | None = None
    _blocks: list[dict] = field(default_factory=list)
    _media: list[Path] = field(default_factory=list)

    def add_kv(self, key: str, value: str) -> "MarkdownReport":
        self._blocks.append({"type": "kv", "key": key, "value": value})
        return self

    def add_bullet(self, text: str) -> "MarkdownReport":
        self._blocks.append({"type": "bullet", "text": text})
        return self

    def add_bullets(self, items: Sequence[str]) -> "MarkdownReport":
        for item in items:
            self.add_bullet(item)
        return self

    def add_note(self, text: str) -> "MarkdownReport":
        self._blocks.append({"type": "note", "text": text})
        return self

    def render(self, max_chars: int = 4096) -> str:
        lines: list[str] = [f"*{self.title}*"]
        if self.subtitle:
            lines.append(f"_{self.subtitle}_")
        for block in self._blocks:
            t = block["type"]
            if t == "kv":
                lines.append(f"{block['key']}: {block['value']}")
            elif t == "bullet":
                lines.append(f"- {block['text']}")
            elif t == "note":
                lines.append(f"_{block['text']}_")
        return "\n".join(lines) + "\n"
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 7 passed (2 original + 5 new).

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport add_kv/bullet/bullets/note builders

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 3: `add_section` + `add_code` builders

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_add_section_renders_bold_line_with_blank_separator():
    report = MarkdownReport(title="T").add_section("FINANCIAL").add_kv("Net", "85M")
    out = report.render()
    assert "\n*FINANCIAL*\n" in out
    assert "Net: 85M" in out


def test_add_code_renders_fenced_block():
    report = MarkdownReport(title="T").add_code("foo = 1\nbar = 2")
    out = report.render()
    assert "```\nfoo = 1\nbar = 2\n```" in out


def test_add_code_with_lang_includes_language_hint():
    report = MarkdownReport(title="T").add_code("x = 1", lang="python")
    out = report.render()
    assert "```python\nx = 1\n```" in out
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 3 new tests fail with `AttributeError`.

- [ ] **Step 3: Implement `add_section` + `add_code`**

```python
# Add to MarkdownReport class
    def add_section(self, title: str) -> "MarkdownReport":
        self._blocks.append({"type": "section", "title": title})
        return self

    def add_code(self, text: str, lang: str = "") -> "MarkdownReport":
        self._blocks.append({"type": "code", "text": text, "lang": lang})
        return self
```

```python
# Extend render() loop with two new branches
            elif t == "section":
                lines.append("")  # blank separator
                lines.append(f"*{block['title']}*")
            elif t == "code":
                lang = block.get("lang", "")
                lines.append(f"```{lang}")
                lines.append(block["text"])
                lines.append("```")
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 10 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport add_section/add_code builders

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 4: `add_table_monospace` builder with padding + alignment

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_table_monospace_renders_in_fenced_block():
    report = MarkdownReport(title="T").add_table_monospace(
        headers=["NAME", "AMT"],
        rows=[["Revenue", "100"], ["Cost", "50"]],
    )
    out = report.render()
    assert "```" in out
    assert "NAME" in out and "AMT" in out
    assert "Revenue" in out and "100" in out


def test_table_monospace_default_left_align():
    report = MarkdownReport(title="T").add_table_monospace(
        headers=["NAME"], rows=[["x"], ["yy"]],
    )
    lines = [l for l in report.render().split("\n") if l.startswith(("x", "yy", "NAME"))]
    assert lines[0].startswith("NAME")
    assert lines[1].startswith("x")
    assert lines[2].startswith("yy")


def test_table_monospace_right_align_pads_left():
    report = MarkdownReport(title="T").add_table_monospace(
        headers=["AMT"], rows=[["1"], ["999"]], align=["right"],
    )
    out = report.render()
    # 999 is widest at 3 chars; '1' should be padded to 3 chars right-aligned
    assert "  1" in out
    assert "999" in out


def test_table_monospace_truncates_long_cells_at_max_col_width():
    long = "x" * 30
    report = MarkdownReport(title="T").add_table_monospace(
        headers=["COL"], rows=[[long]], max_col_width=10,
    )
    out = report.render()
    assert "xxxxxxx..." in out  # truncated to 10 chars with "..." suffix
    assert long not in out


def test_table_monospace_empty_rows_renders_no_rows_marker():
    report = MarkdownReport(title="T").add_table_monospace(
        headers=["NAME"], rows=[],
    )
    out = report.render()
    assert "_(no rows)_" in out
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 5 new tests fail with `AttributeError`.

- [ ] **Step 3: Implement `add_table_monospace`**

```python
# Add to top of markdown_report.py
from typing import Literal

Align = Literal["left", "right", "center"]
```

```python
# Add to MarkdownReport class
    def add_table_monospace(
        self,
        headers: Sequence[str],
        rows: Sequence[Sequence[str]],
        align: Sequence[Align] | None = None,
        max_col_width: int = 24,
    ) -> "MarkdownReport":
        self._blocks.append({
            "type": "table",
            "headers": list(headers),
            "rows": [list(r) for r in rows],
            "align": list(align) if align else None,
            "max_col_width": max_col_width,
        })
        return self
```

```python
# Add helper functions at module level (before the dataclass)
def _truncate(text: str, max_width: int) -> str:
    return text if len(text) <= max_width else text[: max_width - 3] + "..."


def _pad(text: str, width: int, align: Align) -> str:
    if align == "right":
        return text.rjust(width)
    if align == "center":
        return text.center(width)
    return text.ljust(width)


def _render_table(block: dict) -> list[str]:
    headers = block["headers"]
    rows = block["rows"]
    align = block["align"] or ["left"] * len(headers)
    max_col_width = block["max_col_width"]
    if not rows:
        return ["```", "_(no rows)_", "```"]
    # Truncate cells first
    headers_t = [_truncate(h, max_col_width) for h in headers]
    rows_t = [[_truncate(c, max_col_width) for c in row] for row in rows]
    # Compute widths from truncated content
    widths = [
        max(len(headers_t[i]), *(len(r[i]) for r in rows_t))
        for i in range(len(headers_t))
    ]
    sep = "  "
    out = ["```"]
    out.append(sep.join(_pad(h, widths[i], align[i]) for i, h in enumerate(headers_t)))
    for row in rows_t:
        out.append(sep.join(_pad(cell, widths[i], align[i]) for i, cell in enumerate(row)))
    out.append("```")
    return out
```

```python
# Extend render() loop with table branch
            elif t == "table":
                lines.extend(_render_table(block))
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 15 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport add_table_monospace with padding/alignment

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 5: `add_media` builder with path validation

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
import pytest
from pathlib import Path


def test_add_media_appends_media_token_at_end(tmp_path):
    f = tmp_path / "report.xlsx"
    f.write_bytes(b"x")
    report = MarkdownReport(title="T").add_kv("a", "b").add_media(f)
    out = report.render()
    assert f"MEDIA:{f}" in out
    # MEDIA must come AFTER the body content
    assert out.index("MEDIA:") > out.index("a: b")


def test_add_media_separated_from_body_by_blank_line(tmp_path):
    f = tmp_path / "x.pdf"
    f.write_bytes(b"x")
    report = MarkdownReport(title="T").add_kv("a", "b").add_media(f)
    out = report.render()
    assert "\n\nMEDIA:" in out


def test_add_media_multiple_files_each_on_own_line(tmp_path):
    a = tmp_path / "a.xlsx"; a.write_bytes(b"x")
    b = tmp_path / "b.pdf"; b.write_bytes(b"x")
    report = MarkdownReport(title="T").add_media(a).add_media(b)
    out = report.render()
    media_lines = [l for l in out.split("\n") if l.startswith("MEDIA:")]
    assert len(media_lines) == 2
    assert media_lines[0].endswith("a.xlsx")
    assert media_lines[1].endswith("b.pdf")


def test_add_media_rejects_nonexistent_path(tmp_path):
    missing = tmp_path / "does-not-exist.pdf"
    with pytest.raises(FileNotFoundError):
        MarkdownReport(title="T").add_media(missing)


def test_add_media_resolves_to_absolute_path(tmp_path, monkeypatch):
    f = tmp_path / "x.pdf"; f.write_bytes(b"x")
    monkeypatch.chdir(tmp_path)
    report = MarkdownReport(title="T").add_media("x.pdf")
    out = report.render()
    # The MEDIA token must contain the absolute resolved path
    expected = str(f.resolve())
    assert f"MEDIA:{expected}" in out
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 5 new tests fail.

- [ ] **Step 3: Implement `add_media` + extend render**

```python
# Add to MarkdownReport class
    def add_media(self, path: Path | str) -> "MarkdownReport":
        p = Path(path).expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(f"MEDIA file does not exist: {p}")
        self._media.append(p)
        return self
```

```python
# Replace render() — add MEDIA emission after blocks
    def render(self, max_chars: int = 4096) -> str:
        lines: list[str] = [f"*{self.title}*"]
        if self.subtitle:
            lines.append(f"_{self.subtitle}_")
        for block in self._blocks:
            t = block["type"]
            if t == "kv":
                lines.append(f"{block['key']}: {block['value']}")
            elif t == "bullet":
                lines.append(f"- {block['text']}")
            elif t == "note":
                lines.append(f"_{block['text']}_")
            elif t == "section":
                lines.append("")
                lines.append(f"*{block['title']}*")
            elif t == "code":
                lang = block.get("lang", "")
                lines.append(f"```{lang}")
                lines.append(block["text"])
                lines.append("```")
            elif t == "table":
                lines.extend(_render_table(block))
        if self._media:
            lines.append("")  # blank separator before MEDIA block
            for m in self._media:
                lines.append(f"MEDIA:{m}")
        return "\n".join(lines) + "\n"
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 20 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport add_media with absolute-path validation

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 6: Chunking — `render_chunks()` with block-boundary splitting

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_render_chunks_small_returns_single_chunk():
    report = MarkdownReport(title="T").add_bullet("small")
    chunks = report.render_chunks(max_chars=4096)
    assert len(chunks) == 1


def test_render_chunks_large_splits_with_part_suffix():
    report = MarkdownReport(title="Big Report")
    for i in range(500):
        report.add_kv(f"key{i}", "x" * 10)
    chunks = report.render_chunks(max_chars=500)
    assert len(chunks) > 1
    # First chunk title has (1/N), last has (N/N)
    assert chunks[0].startswith("*Big Report (1/")
    assert chunks[-1].startswith(f"*Big Report ({len(chunks)}/{len(chunks)})*")


def test_render_chunks_never_splits_code_fence():
    report = MarkdownReport(title="T").add_code("x\n" * 100)
    chunks = report.render_chunks(max_chars=100)
    for chunk in chunks:
        # Each chunk must have balanced ``` if it contains them
        assert chunk.count("```") % 2 == 0


def test_render_chunks_never_splits_table_rows():
    headers = ["A", "B"]
    rows = [[f"r{i}", "x"] for i in range(50)]
    report = MarkdownReport(title="T").add_table_monospace(headers, rows)
    chunks = report.render_chunks(max_chars=200)
    for chunk in chunks:
        assert chunk.count("```") % 2 == 0


def test_render_chunks_media_tags_only_on_final_chunk(tmp_path):
    f = tmp_path / "x.xlsx"; f.write_bytes(b"x")
    report = MarkdownReport(title="T")
    for i in range(50):
        report.add_kv(f"k{i}", "v")
    report.add_media(f)
    chunks = report.render_chunks(max_chars=200)
    assert len(chunks) > 1
    # MEDIA appears only in the LAST chunk
    for chunk in chunks[:-1]:
        assert "MEDIA:" not in chunk
    assert "MEDIA:" in chunks[-1]


def test_render_default_returns_first_chunk_concatenated_with_separator():
    # render() returns the full concatenated text; render_chunks gives the split
    report = MarkdownReport(title="T").add_bullet("a")
    assert report.render() == report.render_chunks()[0]
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 6 new tests fail with `AttributeError: 'MarkdownReport' object has no attribute 'render_chunks'`.

- [ ] **Step 3: Implement chunking**

```python
# Add helper functions at module level
def _render_block(block: dict) -> list[str]:
    """Render a single block to its line representation. Atomic — never split."""
    t = block["type"]
    if t == "kv":
        return [f"{block['key']}: {block['value']}"]
    if t == "bullet":
        return [f"- {block['text']}"]
    if t == "note":
        return [f"_{block['text']}_"]
    if t == "section":
        return ["", f"*{block['title']}*"]
    if t == "code":
        lang = block.get("lang", "")
        return [f"```{lang}", block["text"], "```"]
    if t == "table":
        return _render_table(block)
    raise ValueError(f"Unknown block type: {t}")


def _block_text_size(block_lines: list[str]) -> int:
    return sum(len(l) + 1 for l in block_lines)  # +1 for the \n
```

```python
# Replace MarkdownReport class methods render() and add render_chunks()
    def _header_lines(self, suffix: str = "") -> list[str]:
        title = f"{self.title}{suffix}"
        out = [f"*{title}*"]
        if self.subtitle:
            out.append(f"_{self.subtitle}_")
        return out

    def render(self, max_chars: int = 4096) -> str:
        chunks = self.render_chunks(max_chars=max_chars)
        return "\n\n".join(chunks) if len(chunks) > 1 else chunks[0]

    def render_chunks(self, max_chars: int = 4096) -> list[str]:
        # Render each block atomically into line lists
        block_lines = [_render_block(b) for b in self._blocks]

        # First pass with no (N/M) suffix to see if it all fits in one chunk
        header = self._header_lines()
        media_lines = []
        if self._media:
            media_lines = [""] + [f"MEDIA:{m}" for m in self._media]
        all_lines = header[:]
        for bl in block_lines:
            all_lines.extend(bl)
        all_lines.extend(media_lines)
        single = "\n".join(all_lines) + "\n"
        if len(single) <= max_chars:
            return [single]

        # Multi-chunk: greedy pack blocks into chunks
        # Reserve room for header + " (N/M)" suffix (estimate up to 10 chars)
        header_reserved = sum(len(l) + 1 for l in self._header_lines(" (99/99)"))
        chunks_blocks: list[list[list[str]]] = [[]]
        current_size = header_reserved
        for bl in block_lines:
            bl_size = _block_text_size(bl)
            if current_size + bl_size > max_chars and chunks_blocks[-1]:
                chunks_blocks.append([])
                current_size = header_reserved
            chunks_blocks[-1].append(bl)
            current_size += bl_size

        # Render each chunk with the (N/M) suffix
        total = len(chunks_blocks)
        out: list[str] = []
        for idx, blocks in enumerate(chunks_blocks, start=1):
            lines = self._header_lines(f" ({idx}/{total})")
            for bl in blocks:
                lines.extend(bl)
            # MEDIA tags only on final chunk
            if idx == total and self._media:
                lines.append("")
                for m in self._media:
                    lines.append(f"MEDIA:{m}")
            out.append("\n".join(lines) + "\n")
        return out
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 26 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport.render_chunks with block-boundary splitting

Chunks at 4096-char boundaries without splitting code fences or table rows.
MEDIA tags emit only on the final chunk so attachments arrive after reading order.

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 7: `to_json()` serialization

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/markdown_report.py`
- Modify: `packages/kctl-lib/tests/test_markdown_report.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_to_json_basic_shape(tmp_path):
    f = tmp_path / "r.xlsx"; f.write_bytes(b"x")
    report = (
        MarkdownReport(title="T", subtitle="sub")
        .add_kv("k", "v")
        .add_bullet("b")
        .add_table_monospace(["H"], [["1"]])
        .add_media(f)
    )
    j = report.to_json()
    assert j["title"] == "T"
    assert j["subtitle"] == "sub"
    assert j["media"] == [str(f.resolve())]
    types = [b["type"] for b in j["blocks"]]
    assert types == ["kv", "bullet", "table"]


def test_to_json_no_media_returns_empty_list():
    report = MarkdownReport(title="T")
    assert report.to_json()["media"] == []


def test_to_json_roundtrip_serializable():
    import json
    report = MarkdownReport(title="T").add_kv("k", "v")
    s = json.dumps(report.to_json())  # must not raise
    assert "T" in s and "k" in s
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 3 new tests fail.

- [ ] **Step 3: Implement `to_json`**

```python
# Add to MarkdownReport class
    def to_json(self) -> dict:
        return {
            "title": self.title,
            "subtitle": self.subtitle,
            "blocks": [dict(b) for b in self._blocks],
            "media": [str(m) for m in self._media],
        }
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v
```

Expected: 29 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/markdown_report.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): MarkdownReport.to_json for structured serialization

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 8: `chat_emit.resolve_output_dir`

**Files:**
- Create: `packages/kctl-lib/src/kctl_lib/chat_emit.py`
- Create: `packages/kctl-lib/tests/test_chat_emit.py`

- [ ] **Step 1: Write the failing tests**

```python
# packages/kctl-lib/tests/test_chat_emit.py
from pathlib import Path

from kctl_lib.chat_emit import resolve_output_dir


def test_resolve_output_dir_cli_arg_wins(tmp_path, monkeypatch):
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", "/should-not-be-used")
    result = resolve_output_dir(cli_arg=tmp_path)
    assert result == tmp_path.resolve()


def test_resolve_output_dir_env_fallback(tmp_path, monkeypatch):
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))
    result = resolve_output_dir(cli_arg=None)
    assert result == tmp_path.resolve()


def test_resolve_output_dir_default_home_cache(tmp_path, monkeypatch):
    monkeypatch.delenv("KCTL_ODOO_REPORT_DIR", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path))
    result = resolve_output_dir(cli_arg=None)
    assert result == (tmp_path / ".cache" / "kctl-odoo" / "reports").resolve()


def test_resolve_output_dir_creates_directory_if_missing(tmp_path, monkeypatch):
    target = tmp_path / "new" / "deep" / "path"
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(target))
    result = resolve_output_dir(cli_arg=None)
    assert result.exists()
    assert result.is_dir()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: `ModuleNotFoundError: No module named 'kctl_lib.chat_emit'`.

- [ ] **Step 3: Implement `chat_emit.resolve_output_dir`**

```python
# packages/kctl-lib/src/kctl_lib/chat_emit.py
"""File-emission utilities for chat-platform delivery.

Resolves output directory with sensible defaults, manages TTL cleanup, writes
files atomically. Used by kctl-odoo commands that emit XLSX/PDF files for
hermes-agent to upload via Telegram/Mattermost/WhatsApp.
"""

from __future__ import annotations

import os
from pathlib import Path


def resolve_output_dir(cli_arg: Path | None = None) -> Path:
    """Resolve the output directory using --out-dir > $KCTL_ODOO_REPORT_DIR > ~/.cache/kctl-odoo/reports.

    The returned directory is created if it doesn't exist.
    """
    if cli_arg is not None:
        target = Path(cli_arg).expanduser().resolve()
    else:
        env = os.environ.get("KCTL_ODOO_REPORT_DIR")
        if env:
            target = Path(env).expanduser().resolve()
        else:
            target = (Path.home() / ".cache" / "kctl-odoo" / "reports").resolve()
    target.mkdir(parents=True, exist_ok=True)
    return target
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: 4 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/chat_emit.py tests/test_chat_emit.py
git commit -m "feat(kctl-lib): chat_emit.resolve_output_dir with env-var fallback

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 9: `chat_emit.build_filename` + `atomic_write`

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/chat_emit.py`
- Modify: `packages/kctl-lib/tests/test_chat_emit.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_chat_emit.py
import re

from kctl_lib.chat_emit import atomic_write, build_filename


def test_build_filename_includes_all_components():
    name = build_filename("pnl", "TPP", "2026-04-30", "xlsx")
    assert name.startswith("pnl_TPP_2026-04-30_")
    assert name.endswith(".xlsx")
    # 4-char shortuuid between date and extension
    assert re.match(r"^pnl_TPP_2026-04-30_[a-f0-9]{4}\.xlsx$", name)


def test_build_filename_unique_per_call():
    names = {build_filename("a", "b", "c", "d") for _ in range(50)}
    assert len(names) >= 45  # allow rare collisions in 50 of 65536 possible


def test_atomic_write_creates_file_at_resolved_path(tmp_path):
    target = atomic_write(tmp_path, "report.xlsx", b"hello bytes")
    assert target.exists()
    assert target.read_bytes() == b"hello bytes"
    assert target.parent == tmp_path
    assert target.name == "report.xlsx"


def test_atomic_write_no_partial_file_on_crash(tmp_path, monkeypatch):
    # Simulate crash by forcing Path.replace to raise
    original_replace = Path.replace

    def boom(self, target):
        raise RuntimeError("simulated crash")

    monkeypatch.setattr(Path, "replace", boom)
    import pytest
    with pytest.raises(RuntimeError):
        atomic_write(tmp_path, "report.xlsx", b"data")
    # Final file should NOT exist
    assert not (tmp_path / "report.xlsx").exists()


def test_atomic_write_returns_absolute_resolved_path(tmp_path):
    target = atomic_write(tmp_path, "x.xlsx", b"y")
    assert target.is_absolute()
    assert target == target.resolve()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: 5 new tests fail.

- [ ] **Step 3: Implement `build_filename` + `atomic_write`**

```python
# Append to packages/kctl-lib/src/kctl_lib/chat_emit.py
import tempfile
import uuid


def build_filename(type_slug: str, company_slug: str, date_range: str, ext: str) -> str:
    """{type_slug}_{company_slug}_{date_range}_{shortuuid}.{ext}

    The 4-char shortuuid suffix prevents collisions for back-to-back same-period runs.
    """
    short = uuid.uuid4().hex[:4]
    return f"{type_slug}_{company_slug}_{date_range}_{short}.{ext}"


def atomic_write(out_dir: Path, name: str, data: bytes) -> Path:
    """Write `data` to `out_dir/name` atomically via tempfile + rename.

    On any failure during the write or rename, the destination path is never
    left in a partial state.
    """
    out_dir = Path(out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    target = (out_dir / name).resolve()
    fd, tmp_name = tempfile.mkstemp(dir=out_dir, prefix=".tmp_", suffix=name)
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        tmp_path.replace(target)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise
    return target
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: 9 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/chat_emit.py tests/test_chat_emit.py
git commit -m "feat(kctl-lib): chat_emit.build_filename + atomic_write

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 10: `chat_emit.cleanup_old_files` with TTL + 60s safety window

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/chat_emit.py`
- Modify: `packages/kctl-lib/tests/test_chat_emit.py`

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-lib/tests/test_chat_emit.py
import os
import time

from kctl_lib.chat_emit import cleanup_old_files


def test_cleanup_removes_files_older_than_ttl(tmp_path):
    old = tmp_path / "old.xlsx"
    old.write_bytes(b"x")
    stale_time = time.time() - 10 * 86400  # 10 days old
    os.utime(old, (stale_time, stale_time))

    removed = cleanup_old_files(tmp_path, ttl_days=7)
    assert removed == 1
    assert not old.exists()


def test_cleanup_keeps_recent_files(tmp_path):
    fresh = tmp_path / "fresh.xlsx"
    fresh.write_bytes(b"x")
    removed = cleanup_old_files(tmp_path, ttl_days=7)
    assert removed == 0
    assert fresh.exists()


def test_cleanup_skips_files_modified_within_60s(tmp_path):
    """Race-window safety: files <60s old are NEVER cleaned, even if ttl_days=0."""
    recent = tmp_path / "recent.xlsx"
    recent.write_bytes(b"x")
    removed = cleanup_old_files(tmp_path, ttl_days=0)
    assert removed == 0
    assert recent.exists()


def test_cleanup_non_fatal_on_permission_error(tmp_path, monkeypatch):
    """If unlink fails, cleanup logs the warning and returns the count of those that succeeded."""
    old = tmp_path / "old.xlsx"
    old.write_bytes(b"x")
    stale_time = time.time() - 10 * 86400
    os.utime(old, (stale_time, stale_time))

    def boom(self, *args, **kwargs):
        raise PermissionError("cannot delete")

    monkeypatch.setattr(Path, "unlink", boom)
    # Must NOT raise — degrades gracefully
    removed = cleanup_old_files(tmp_path, ttl_days=7)
    assert removed == 0


def test_cleanup_ignores_subdirectories(tmp_path):
    sub = tmp_path / "subdir"
    sub.mkdir()
    file_in_sub = sub / "nested.xlsx"
    file_in_sub.write_bytes(b"x")
    stale_time = time.time() - 10 * 86400
    os.utime(file_in_sub, (stale_time, stale_time))

    removed = cleanup_old_files(tmp_path, ttl_days=7)
    # Only direct file children considered; subdirectories untouched
    assert file_in_sub.exists()
    assert removed == 0
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: 5 new tests fail.

- [ ] **Step 3: Implement `cleanup_old_files`**

```python
# Append to packages/kctl-lib/src/kctl_lib/chat_emit.py
import logging
import time

_log = logging.getLogger(__name__)

_SAFETY_WINDOW_SECONDS = 60


def cleanup_old_files(out_dir: Path, ttl_days: int = 7) -> int:
    """Delete files in `out_dir` older than `ttl_days`. Returns count removed.

    Files modified within the last 60 seconds are NEVER deleted regardless of
    ttl_days — this is the race-window safety guard against deleting a file a
    sibling kctl-odoo process is still writing.

    Subdirectories are ignored. Permission/IO failures during unlink are logged
    at WARNING level and do not raise.
    """
    out_dir = Path(out_dir).expanduser().resolve()
    if not out_dir.is_dir():
        return 0
    now = time.time()
    cutoff = now - (ttl_days * 86400)
    safety = now - _SAFETY_WINDOW_SECONDS
    removed = 0
    for entry in out_dir.iterdir():
        if not entry.is_file():
            continue
        mtime = entry.stat().st_mtime
        if mtime >= cutoff:
            continue
        if mtime >= safety:
            continue
        try:
            entry.unlink()
            removed += 1
        except OSError as e:
            _log.warning("cleanup_old_files: failed to delete %s: %s", entry, e)
    return removed
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_chat_emit.py -v
```

Expected: 14 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/chat_emit.py tests/test_chat_emit.py
git commit -m "feat(kctl-lib): chat_emit.cleanup_old_files with TTL + 60s race window

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 11: Export `MarkdownReport` and `chat_emit` from kctl_lib public API + bump version

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/__init__.py`

- [ ] **Step 1: Write the failing test**

```python
# Append to packages/kctl-lib/tests/test_markdown_report.py
def test_markdown_report_importable_from_top_level_package():
    from kctl_lib import MarkdownReport as TopLevel
    from kctl_lib.markdown_report import MarkdownReport as Direct
    assert TopLevel is Direct


def test_chat_emit_utilities_importable_from_top_level_package():
    from kctl_lib import build_filename, cleanup_old_files, resolve_output_dir, atomic_write
    from kctl_lib.chat_emit import (
        build_filename as a,
        cleanup_old_files as b,
        resolve_output_dir as c,
        atomic_write as d,
    )
    assert build_filename is a
    assert cleanup_old_files is b
    assert resolve_output_dir is c
    assert atomic_write is d


def test_kctl_lib_version_bumped_to_0_12_0():
    import kctl_lib
    assert kctl_lib.__version__ == "0.12.0"
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py::test_markdown_report_importable_from_top_level_package tests/test_markdown_report.py::test_chat_emit_utilities_importable_from_top_level_package tests/test_markdown_report.py::test_kctl_lib_version_bumped_to_0_12_0 -v
```

Expected: 3 failures (ImportError + AssertionError on version).

- [ ] **Step 3: Add exports + bump version**

```python
# packages/kctl-lib/src/kctl_lib/__init__.py — bump version
__version__ = "0.12.0"
```

```python
# packages/kctl-lib/src/kctl_lib/__init__.py — add imports near the existing block
from kctl_lib.chat_emit import atomic_write, build_filename, cleanup_old_files, resolve_output_dir
from kctl_lib.markdown_report import MarkdownReport
```

```python
# packages/kctl-lib/src/kctl_lib/__init__.py — add to __all__ if present, otherwise leave (Python infers exports from the imports)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_markdown_report.py -v && uv run pytest tests/test_chat_emit.py -v
```

Expected: all green (29 + 14 + 3 = 46 passing).

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/__init__.py tests/test_markdown_report.py
git commit -m "feat(kctl-lib): export MarkdownReport + chat_emit utilities; bump to 0.12.0

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 12: `Output.markdown_report()` method — render a MarkdownReport to stdout

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/output.py`
- Create: `packages/kctl-lib/tests/test_output_markdown.py`

- [ ] **Step 1: Write the failing tests**

```python
# packages/kctl-lib/tests/test_output_markdown.py
from kctl_lib.markdown_report import MarkdownReport
from kctl_lib.output import Output


def test_markdown_report_emits_to_stdout(capsys):
    out = Output(format="markdown")
    report = MarkdownReport(title="Hello").add_bullet("world")
    out.markdown_report(report)
    captured = capsys.readouterr()
    assert "*Hello*" in captured.out
    assert "- world" in captured.out


def test_markdown_report_multi_chunk_emits_blank_line_between(capsys):
    out = Output(format="markdown")
    report = MarkdownReport(title="Big")
    for i in range(500):
        report.add_kv(f"k{i}", "v" * 10)
    out.markdown_report(report, max_chars=500)
    captured = capsys.readouterr()
    # Multiple chunks separated by blank lines
    assert captured.out.count("*Big (") >= 2


def test_markdown_report_quiet_still_emits():
    """--quiet shouldn't suppress the actual report payload — it's the deliverable, not chatter."""
    import sys
    from io import StringIO
    sys.stdout = StringIO()
    try:
        out = Output(format="markdown", quiet=True)
        out.markdown_report(MarkdownReport(title="T").add_bullet("b"))
        result = sys.stdout.getvalue()
    finally:
        sys.stdout = sys.__stdout__
    assert "*T*" in result
    assert "- b" in result
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-lib && uv run pytest tests/test_output_markdown.py -v
```

Expected: `AttributeError: 'Output' object has no attribute 'markdown_report'`.

- [ ] **Step 3: Implement `Output.markdown_report`**

```python
# packages/kctl-lib/src/kctl_lib/output.py — add method to Output class
    def markdown_report(self, report, max_chars: int = 4096) -> None:
        """Emit a MarkdownReport to stdout as portable GFM-lite text.

        Chunks above max_chars are separated by a blank line so the hermes-agent
        platform handlers can recognize them as distinct messages if desired.
        """
        from kctl_lib.markdown_report import MarkdownReport
        if not isinstance(report, MarkdownReport):
            raise TypeError(f"markdown_report requires MarkdownReport, got {type(report).__name__}")
        chunks = report.render_chunks(max_chars=max_chars)
        sys.stdout.write("\n\n".join(chunks))
        if not chunks[-1].endswith("\n"):
            sys.stdout.write("\n")
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-lib && uv run pytest tests/test_output_markdown.py -v
```

Expected: 3 passed.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/output.py tests/test_output_markdown.py
git commit -m "feat(kctl-lib): Output.markdown_report emits MarkdownReport to stdout

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 13: Run full kctl-lib test suite + lint to confirm no regressions

**Files:**
- (Verification only; no source changes)

- [ ] **Step 1: Run the full kctl-lib test suite**

```bash
cd packages/kctl-lib && uv run pytest tests/ -v
```

Expected: ALL tests pass (existing 415 + new ~46).

- [ ] **Step 2: Run ruff lint on new files**

```bash
cd packages/kctl-lib && uv run ruff check src/kctl_lib/markdown_report.py src/kctl_lib/chat_emit.py
```

Expected: All checks passed.

- [ ] **Step 3: Run mypy strict on new files**

```bash
cd packages/kctl-lib && uv run mypy src/kctl_lib/markdown_report.py src/kctl_lib/chat_emit.py
```

Expected: Success: no issues found.

- [ ] **Step 4: If any lint/mypy issues, fix them and re-commit**

If issues found: fix in place. Use a `chore(kctl-lib): lint fixes for markdown_report` commit message.

---

## Task 14: `report quick` — accept `--format markdown` (no files yet)

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/report/mgmt_framework.py`
- Create: `packages/kctl-odoo/tests/test_format_markdown.py`

- [ ] **Step 1: Write the failing test**

```python
# packages/kctl-odoo/tests/test_format_markdown.py
"""Integration tests for --format markdown across the v1 command surface."""

from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from kctl_odoo.cli import app


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_client():
    """Stub of the kctl-odoo Odoo JSONRPC client used by command handlers."""
    client = MagicMock()
    client.search_read.return_value = [{"id": 1, "name": "P&L", "code": "PNL"}]
    client.execute_kw.return_value = 42  # fake instance_id
    return client


def test_report_quick_format_markdown_emits_markdown_header(runner, mock_client, monkeypatch):
    """`report quick --format markdown` prints a markdown body with *Title* line.

    The fixture mirrors the REAL compute_report_data shape: tables[].columns +
    tables[].rows, where each row has kind/level/values and values is keyed by
    the column key (here 'balance'), NOT a literal 'actual' field.
    """
    fake_rd = {
        "report_name": "Profit & Loss",
        "company_name": "TPP",
        "period_label": "2026-04-01 to 2026-04-30",
        "tables": [
            {
                "columns": [
                    {"key": "name", "header": "", "type": "char"},
                    {"key": "balance", "header": "Amount", "type": "amount"},
                ],
                "rows": [
                    {"label": "Revenue", "kind": "total", "level": 0, "values": {"balance": 1234567890}},
                    {"label": "Cost of sales", "kind": "total", "level": 0, "values": {"balance": 987654321}},
                    {"label": "Gross profit", "kind": "subheader", "level": 0, "values": {"balance": 246913569}},
                    {"label": "Some detail row", "kind": "line", "level": 1, "values": {"balance": 100}},
                ],
            }
        ],
    }
    with patch("kctl_odoo.commands.report.mgmt_framework._fetch_report_data", return_value=fake_rd):
        with patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
            result = runner.invoke(app, ["report", "quick", "profit_loss",
                                          "--date-from", "2026-04-01", "--date-to", "2026-04-30",
                                          "--format", "markdown"])
    assert result.exit_code == 0, result.output
    assert "*Profit & Loss" in result.output
    assert "Revenue" in result.output
    # Headline rows (header/total/subheader) shown
    assert "Gross profit" in result.output
    # Detail rows (kind=line) NOT shown in compact mode
    assert "Some detail row" not in result.output
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py::test_report_quick_format_markdown_emits_markdown_header -v
```

Expected: Fails — likely `_fetch_report_data` doesn't exist yet, or `fmt=markdown` isn't recognized.

- [ ] **Step 3: Refactor `report quick` to expose a `_fetch_report_data` seam and a markdown branch**

Look at the existing handler at `packages/kctl-odoo/src/kctl_odoo/commands/report/mgmt_framework.py:2871-3030`. The current shape:
```
report_quick(...) {
    # 1. resolve template
    # 2. compute_report via JSONRPC -> report_data dict
    # 3. if fmt == "json": dump json; return
    # 4. else: _render_xlsx_local; return
}
```

The existing handler (lines ~2940-3030) calls `c.execute_kw(..., "compute_report_data", ...)` inline, then extracts `report_name`, `company_name`, `period_label`, `columns`, `rows`. Two refactors:

1. **Extract the JSONRPC fetch** into `_fetch_report_data(client, type_code, date_from, date_to, as_of_date, company, company_ids) -> dict` (private). Move the existing `compute_report_data` `execute_kw` call (lines ~2940-2975) into it verbatim; it returns the `rd` dict. This is the single seam mocked in tests.

2. The existing `fmt` accepts `"xlsx"` (default) and `"json"`. Add a `"markdown"` branch.

The handler becomes:
```python
@app.command("quick")
def report_quick(
    ctx: typer.Context,
    type_code: ...,
    date_from: ...,
    # ... existing params unchanged ...
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: xlsx, json, or markdown")] = "xlsx",
) -> None:
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # ... existing validation, template resolution, date resolution ...
    rd = _fetch_report_data(c, type_code, resolved_from, resolved_to, as_of_date, co_id, co_ids_list)

    # ... existing extraction of report_name/company_name/period_label/columns/rows from rd ...

    if fmt == "json":
        # ... existing json payload branch unchanged ...
        return
    if fmt == "markdown":
        _render_markdown(out, rd, type_code=type_code)
        return
    # else: existing _render_xlsx_local path
```

Add the helpers (the `_extract_table` mirrors the EXISTING extraction at lines ~2982-2990, so XLSX and markdown share one shape):
```python
def _fetch_report_data(client, type_code, date_from, date_to, as_of_date, co_id, co_ids_list) -> dict:
    """Extracted JSONRPC fetch — single seam for mocking in tests.

    Moves the existing compute_report_data execute_kw call here verbatim and
    returns the `rd` dict the handler already consumes.
    """
    ...  # existing execute_kw("report.template","compute_report_data",[...]) body, return rd


def _extract_table(rd: dict):
    """Pull (report_name, company_name, period_label, columns, rows) from rd.

    Mirrors the existing extraction in report_quick so XLSX/JSON/markdown agree.
    """
    report_name = rd.get("report_name", "Report")
    company_name = rd.get("company_name", "")
    period_label = rd.get("period_label", "")
    tables = rd.get("tables") or []
    columns = (tables[0].get("columns") if tables else None) or rd.get("columns", [])
    rows: list = []
    for t in tables:
        rows.extend(t.get("rows") or [])
    if not rows:
        rows = rd.get("lines") or []
    return report_name, company_name, period_label, columns, rows


def _fmt_money(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (int, float)):
        return f"{value:,.0f}"
    return str(value)


def _render_markdown(out, rd: dict, *, type_code: str = "report", attach_exts=None) -> None:
    """Render compact markdown — headline rows only (kind in {header,total,subheader}).

    The headline kinds match the bold rows in _render_xlsx_local (which bolds
    'header' and 'total'); 'subheader' is included for report types that use it.
    The amount value is read from the first amount/percent column's key.
    """
    from kctl_lib.markdown_report import MarkdownReport

    report_name, company_name, period_label, columns, rows = _extract_table(rd)
    title = " — ".join(p for p in (report_name, company_name, period_label) if p)
    report = MarkdownReport(title=title or "Report")

    amount_keys = [c["key"] for c in columns if c.get("type") in ("amount", "percent")]
    primary = amount_keys[0] if amount_keys else None
    headline_kinds = {"header", "total", "subheader"}

    table_rows = []
    for r in rows:
        if not isinstance(r, dict) or r.get("kind") not in headline_kinds:
            continue
        label = r.get("label", r.get("name", ""))
        val = (r.get("values") or {}).get(primary) if primary else None
        table_rows.append([label, _fmt_money(val)])

    if table_rows:
        report.add_table_monospace(headers=["", "AMOUNT"], rows=table_rows, align=("left", "right"))
    else:
        report.add_note("No headline rows in this report")

    out.markdown_report(report)
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py::test_report_quick_format_markdown_emits_markdown_header -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/report/mgmt_framework.py tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): report quick --format markdown emits compact summary

Headline rows only (kind=total/subheader); detail rows go to XLSX via --with-files.

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 15: `report quick` — `--with-files xlsx` writes file + emits MEDIA token (PDF deferred to Phase 1)

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/report/mgmt_framework.py`
- Modify: `packages/kctl-odoo/tests/test_format_markdown.py`

> **Scope:** v1 implements `xlsx` (client-side render → bytes, trivial). `--with-files pdf` returns a graceful note pointing at xlsx — PDF lands in Phase 1's `api_report` `/reports/{id}/pdf`. See the plan-header scope note.

- [ ] **Step 1: Write the failing tests**

```python
# Append to packages/kctl-odoo/tests/test_format_markdown.py
def _fake_rd():
    return {
        "report_name": "P&L",
        "company_name": "TPP",
        "period_label": "2026-04-01 to 2026-04-30",
        "tables": [{
            "columns": [
                {"key": "name", "header": "", "type": "char"},
                {"key": "balance", "header": "Amount", "type": "amount"},
            ],
            "rows": [{"label": "Revenue", "kind": "total", "level": 0, "values": {"balance": 100}}],
        }],
    }


def test_report_quick_with_files_xlsx_emits_media_token(runner, mock_client, monkeypatch, tmp_path):
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))
    with patch("kctl_odoo.commands.report.mgmt_framework._fetch_report_data", return_value=_fake_rd()), \
         patch("kctl_odoo.commands.report.mgmt_framework._render_xlsx_bytes", return_value=b"<xlsx>"), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["report", "quick", "profit_loss",
                                      "--date-from", "2026-04-01", "--date-to", "2026-04-30",
                                      "--format", "markdown", "--with-files", "xlsx"])
    assert result.exit_code == 0, result.output
    media_lines = [l for l in result.output.split("\n") if l.startswith("MEDIA:")]
    assert len(media_lines) == 1
    assert media_lines[0].endswith(".xlsx")
    from pathlib import Path
    assert Path(media_lines[0][len("MEDIA:"):]).exists()


def test_report_quick_with_files_pdf_degrades_with_note(runner, mock_client, monkeypatch, tmp_path):
    """v1: --with-files pdf emits a note (no MEDIA token); PDF arrives in Phase 1."""
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))
    with patch("kctl_odoo.commands.report.mgmt_framework._fetch_report_data", return_value=_fake_rd()), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["report", "quick", "profit_loss",
                                      "--date-from", "2026-04-01", "--date-to", "2026-04-30",
                                      "--format", "markdown", "--with-files", "pdf"])
    assert result.exit_code == 0
    assert "*P&L" in result.output            # markdown body present
    assert "PDF attachments not yet available" in result.output
    pdf_media = [l for l in result.output.split("\n") if l.startswith("MEDIA:") and l.endswith(".pdf")]
    assert pdf_media == []                     # no broken pdf MEDIA token


def test_report_quick_with_files_failure_keeps_markdown_body(runner, mock_client, monkeypatch, tmp_path):
    """If XLSX generation fails, markdown body still emits with a degradation note; exit 0."""
    monkeypatch.setenv("KCTL_ODOO_REPORT_DIR", str(tmp_path))

    def boom(*a, **kw):
        raise RuntimeError("XLSX generation crashed")

    with patch("kctl_odoo.commands.report.mgmt_framework._fetch_report_data", return_value=_fake_rd()), \
         patch("kctl_odoo.commands.report.mgmt_framework._render_xlsx_bytes", side_effect=boom), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["report", "quick", "profit_loss",
                                      "--date-from", "2026-04-01", "--date-to", "2026-04-30",
                                      "--format", "markdown", "--with-files", "xlsx"])
    assert result.exit_code == 0
    assert "*P&L" in result.output             # markdown body present
    assert "MEDIA:" not in result.output       # no broken MEDIA tag
    assert "XLSX unavailable" in result.output  # graceful degradation note
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k with_files
```

Expected: All three fail — `--with-files` flag not recognized.

- [ ] **Step 3: Add `--with-files` flag + xlsx bytes generation + MEDIA emission**

First, refactor the existing `_render_xlsx_local` to share its workbook-building logic. Locate `_render_xlsx_local` (line ~2779). Extract everything up to (but not including) the final `wb.save(output_path)` into a `_build_xlsx_workbook(...)` that returns the `Workbook`:

```python
def _build_xlsx_workbook(report_name, company_name, period_label, columns, rows):
    """Build the openpyxl Workbook (everything _render_xlsx_local did except save)."""
    # ... move the ENTIRE existing body of _render_xlsx_local here, verbatim,
    #     except replace the final `wb.save(output_path)` line with `return wb`.
    return wb


def _render_xlsx_local(report_name, company_name, period_label, columns, rows, output_path):
    """Render report data to XLSX on disk (existing public behavior preserved)."""
    wb = _build_xlsx_workbook(report_name, company_name, period_label, columns, rows)
    wb.save(output_path)


def _render_xlsx_bytes(rd: dict) -> bytes:
    """Render report data to XLSX bytes for chat attachment."""
    from io import BytesIO
    report_name, company_name, period_label, columns, rows = _extract_table(rd)
    wb = _build_xlsx_workbook(report_name, company_name, period_label, columns, rows)
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
```

Add the `--with-files` flag to the handler signature:
```python
    with_files: Annotated[
        str | None,
        typer.Option("--with-files", help="Comma-separated file attachments: xlsx (pdf in v1.1)"),
    ] = None,
```

Update the markdown branch to pass attachments through:
```python
    if fmt == "markdown":
        attach_exts = [e.strip().lower() for e in (with_files or "").split(",") if e.strip()]
        _render_markdown(out, rd, type_code=type_code, attach_exts=attach_exts)
        return
```

Extend `_render_markdown` (from Task 14) with the file-emission tail. Replace the final `out.markdown_report(report)` with:
```python
    # --- file attachments (xlsx only in v1; pdf deferred to Phase 1/api_report) ---
    if attach_exts:
        from kctl_lib.chat_emit import atomic_write, build_filename, cleanup_old_files, resolve_output_dir
        out_dir = resolve_output_dir()
        cleanup_old_files(out_dir, ttl_days=int(os.environ.get("KCTL_ODOO_REPORT_TTL_DAYS", "7")))
        company_slug = (company_name or "default").replace(" ", "-")[:24]
        date_slug = (period_label or "asof").split(" ")[-1][:10]
        for ext in attach_exts:
            if ext == "pdf":
                report.add_note("PDF attachments not yet available (use xlsx; PDF arrives in v1.1)")
                continue
            if ext != "xlsx":
                report.add_note(f"Unknown attachment type: {ext}")
                continue
            try:
                data = _render_xlsx_bytes(rd)
                name = build_filename(type_code.replace("_", "-"), company_slug, date_slug, "xlsx")
                path = atomic_write(out_dir, name, data)
                report.add_media(path)
            except Exception as e:
                report.add_note(f"XLSX unavailable: {e}")

    out.markdown_report(report)
```

> **Note:** `os` must be imported at module top (it almost certainly already is in `mgmt_framework.py`; add `import os` if not). `_render_markdown` already receives `rd` and computes `company_name`/`period_label` via `_extract_table` — reuse those locals; do not recompute.

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k "with_files or markdown"
```

Expected: All markdown + with_files tests pass.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/report/mgmt_framework.py tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): report quick --with-files xlsx emits MEDIA token

XLSX written to \$KCTL_ODOO_REPORT_DIR (or ~/.cache fallback) with 7-day TTL
cleanup. Generation failure degrades gracefully — markdown body still emits with
an 'XLSX unavailable' note. PDF deferred to Phase 1 (api_report); --with-files
pdf emits an informative note.

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 16: `analyze run` + `analyze presets` — `--format markdown`

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/analytics/__init__.py`
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/analytics/engine.py`
- Modify: `packages/kctl-odoo/tests/test_format_markdown.py`

- [ ] **Step 1: Write the failing test**

```python
# Append to packages/kctl-odoo/tests/test_format_markdown.py
def test_analyze_run_top_products_format_markdown(runner, mock_client, monkeypatch):
    """analyze run <preset> --format markdown renders rows as a monospace table."""
    fake_result = {
        "preset": "top-products",
        "rows": [
            {"product": "Coffee Beans Premium 1kg", "revenue": 45000000, "units": 3200},
            {"product": "Roasted Beans Espresso 500g", "revenue": 32500000, "units": 2800},
        ],
        "row_count": 1234,
        "query_total": 5000000000,
        "company_ids": [1],
        "date_from": "2026-04-01",
        "date_to": "2026-04-30",
        "validated": False,
        "validation": None,
    }
    with patch("kctl_odoo.commands.analytics.engine.run_preset", return_value=fake_result):
        with patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
            result = runner.invoke(app, ["analyze", "run", "top-products",
                                          "--date-from", "2026-04-01",
                                          "--date-to", "2026-04-30",
                                          "--format", "markdown"])
    assert result.exit_code == 0, result.output
    assert "*Top Products" in result.output or "*top-products" in result.output.lower()
    assert "Coffee Beans Premium 1kg" in result.output
    assert "45,000,000" in result.output


def test_analyze_presets_format_markdown_lists_available_presets(runner, mock_client):
    """analyze presets --format markdown prints a bulleted list of presets."""
    fake_presets = [
        {"name": "top-products", "description": "Top 20 products by revenue"},
        {"name": "ar-aging", "description": "Accounts receivable aging buckets"},
    ]
    with patch("kctl_odoo.commands.analytics.list_presets", return_value=fake_presets):
        with patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
            result = runner.invoke(app, ["analyze", "presets", "--format", "markdown"])
    assert result.exit_code == 0
    assert "*Analytics Presets*" in result.output
    assert "top-products" in result.output and "ar-aging" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k analyze
```

Expected: Fails — `--format markdown` not handled for analyze commands.

- [ ] **Step 3: Add markdown branches to `analyze run` and `analyze presets`**

Look at `packages/kctl-odoo/src/kctl_odoo/commands/analytics/__init__.py`. Both `analyze run` and `analyze presets` use `actx.output` and already accept the global `--format/-f` flag.

For `analyze run`, add a markdown branch:
```python
# In the run() handler, after fetching `result` dict:
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        from kctl_odoo.commands.analytics.engine import render_markdown
        report = render_markdown(result)
        out.markdown_report(report)
        return
```

For `analyze presets`, add similarly:
```python
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        report = MarkdownReport(title="Analytics Presets",
                                subtitle=f"{len(presets)} presets available")
        for p in presets:
            report.add_bullet(f"`{p['name']}` — {p.get('description', '')}")
        out.markdown_report(report)
        return
```

Add `render_markdown` helper in `packages/kctl-odoo/src/kctl_odoo/commands/analytics/engine.py`:
```python
def render_markdown(result: dict) -> "MarkdownReport":
    """Convert an analyze-run result dict to a MarkdownReport.

    Renders the rows as a monospace table, with totals/validation as bullets
    underneath.
    """
    from kctl_lib.markdown_report import MarkdownReport

    preset = result.get("preset", "report")
    period = f"{result.get('date_from','?')} → {result.get('date_to','?')}"
    title = preset.replace("-", " ").title() + f" — {period}"
    subtitle = f"{result.get('row_count', '?')} records analyzed"

    report = MarkdownReport(title=title, subtitle=subtitle)
    rows = result.get("rows", [])
    if rows:
        # First row's keys define the column set (preserves preset shape)
        headers = list(rows[0].keys())
        table_rows = []
        for r in rows:
            cells = []
            for h in headers:
                val = r.get(h)
                if isinstance(val, (int, float)):
                    cells.append(f"{val:,.0f}")
                else:
                    cells.append(str(val) if val is not None else "")
            table_rows.append(cells)
        # Numbers right-align, strings left-align
        align = ["right" if isinstance(rows[0].get(h), (int, float)) else "left" for h in headers]
        report.add_table_monospace(
            headers=[h.upper() for h in headers],
            rows=table_rows,
            align=align,
        )
    if result.get("validation"):
        v = result["validation"]
        sym = "✓" if v.get("pass") else "✗"
        report.add_bullet(f"Validated: {sym} (Δ {v.get('delta_pct', '?'):.2%})")
    return report
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k analyze
```

Expected: Both analyze tests pass.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/analytics/ tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): analyze run/presets --format markdown

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 17: `kpi run` + `kpi list` — `--format markdown`

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/kpi_cmd.py`
- Modify: `packages/kctl-odoo/tests/test_format_markdown.py`

- [ ] **Step 1: Write the failing test**

```python
# Append to packages/kctl-odoo/tests/test_format_markdown.py
def test_kpi_run_format_markdown(runner, mock_client, monkeypatch):
    fake_kpis = [
        {"name": "Revenue", "value": 246000000, "target": 250000000, "delta_pct": -1.6},
        {"name": "Net margin", "value": 15.2, "target": 14.0, "delta_pct": 8.6},
    ]
    with patch("kctl_odoo.commands.kpi_cmd._fetch_kpis", return_value=fake_kpis), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["kpi", "run", "sales_dashboard", "--format", "markdown"])
    assert result.exit_code == 0
    assert "*sales_dashboard*" in result.output.lower() or "*Sales Dashboard*" in result.output
    assert "Revenue" in result.output
    assert "Net margin" in result.output


def test_kpi_list_format_markdown(runner, mock_client):
    fake_list = [{"id": 1, "name": "sales_dashboard"}, {"id": 2, "name": "ops_dashboard"}]
    with patch("kctl_odoo.commands.kpi_cmd._fetch_kpi_instances", return_value=fake_list), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["kpi", "list", "--format", "markdown"])
    assert result.exit_code == 0
    assert "*KPI Instances*" in result.output
    assert "sales_dashboard" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k kpi
```

Expected: Fails — markdown branch not present.

- [ ] **Step 3: Add markdown branches to `kpi_cmd.py`**

Find the existing `run` and `list` handlers in `packages/kctl-odoo/src/kctl_odoo/commands/kpi_cmd.py`. Each accepts the global `--format`. After data fetch, add:

```python
# In run() handler
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        report = MarkdownReport(title=instance_name, subtitle=f"OCA mis_builder · {len(kpis)} KPIs")
        rows = []
        for k in kpis:
            value = f"{k['value']:,.1f}" if isinstance(k.get("value"), float) else f"{k.get('value', ''):,}" if isinstance(k.get('value'), int) else str(k.get('value', ''))
            target = f"{k.get('target', ''):,}" if isinstance(k.get('target'), (int, float)) else str(k.get('target', ''))
            delta = f"{k.get('delta_pct', 0):+.1f}%"
            rows.append([k.get("name", ""), value, target, delta])
        report.add_table_monospace(
            headers=["KPI", "VALUE", "TARGET", "vs TARGET"],
            rows=rows,
            align=["left", "right", "right", "right"],
        )
        # Summary bullet
        above = sum(1 for k in kpis if (k.get("delta_pct") or 0) >= 0)
        report.add_bullet(f"{above} of {len(kpis)} KPIs at or above target")
        out.markdown_report(report)
        return

# In list() handler
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        report = MarkdownReport(title="KPI Instances", subtitle=f"{len(instances)} available")
        for inst in instances:
            report.add_bullet(f"`{inst.get('name', '?')}` (id={inst.get('id')})")
        out.markdown_report(report)
        return
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k kpi
```

Expected: Both kpi tests pass.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/kpi_cmd.py tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): kpi run/list --format markdown

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 18: `dashboard summary` + `dashboard digest` — `--format markdown`

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/dashboard.py`
- Modify: `packages/kctl-odoo/tests/test_format_markdown.py`

- [ ] **Step 1: Write the failing test**

```python
# Append to packages/kctl-odoo/tests/test_format_markdown.py
def test_dashboard_summary_format_markdown_renders_multiple_sections(runner, mock_client):
    fake_summary = {
        "financial": {"net_income_mtd": 85000000, "cash": 420000000,
                       "ar_outstanding": 180000000, "ap_outstanding": 95000000},
        "operations": {"so_pending": 23, "po_pending": 8, "stock_value": 340000000},
        "attention": ["3 invoices overdue >60 days", "2 stock items below safety"],
    }
    with patch("kctl_odoo.commands.dashboard._build_summary", return_value=fake_summary), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["dashboard", "summary", "--format", "markdown"])
    assert result.exit_code == 0, result.output
    assert "*Executive Summary*" in result.output
    # Each section header rendered
    assert "*FINANCIAL*" in result.output
    assert "*OPERATIONS*" in result.output
    assert "*ATTENTION*" in result.output
    # Bullets in ATTENTION
    assert "- 3 invoices overdue >60 days" in result.output


def test_dashboard_digest_format_markdown(runner, mock_client):
    fake_digest = {"sections": [{"label": "P&L MTD", "value": "85M (+12%)"}]}
    with patch("kctl_odoo.commands.dashboard._build_digest", return_value=fake_digest), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["dashboard", "digest", "--format", "markdown"])
    assert result.exit_code == 0
    assert "*Daily Digest*" in result.output
    assert "P&L MTD" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k dashboard
```

Expected: Fails.

- [ ] **Step 3: Add markdown branches in `dashboard.py`**

Find the existing `summary` and `digest` handlers. Extract the data-gathering into `_build_summary()` and `_build_digest()` helpers (so tests can mock them). Add markdown branches:

```python
# In summary() handler
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        from datetime import date
        data = _build_summary(c)
        report = MarkdownReport(title="Executive Summary", subtitle=f"{date.today().isoformat()}")
        # Financial section
        report.add_section("FINANCIAL")
        fin = data.get("financial", {})
        report.add_table_monospace(
            headers=["", "VALUE"],
            rows=[
                ["Net income MTD", _fmt_money(fin.get("net_income_mtd"))],
                ["Cash on hand", _fmt_money(fin.get("cash"))],
                ["AR outstanding", _fmt_money(fin.get("ar_outstanding"))],
                ["AP outstanding", _fmt_money(fin.get("ap_outstanding"))],
            ],
            align=["left", "right"],
        )
        # Operations section
        report.add_section("OPERATIONS")
        ops = data.get("operations", {})
        report.add_table_monospace(
            headers=["", "VALUE"],
            rows=[
                ["Sales orders pending", str(ops.get("so_pending", "?"))],
                ["Purchase orders pending", str(ops.get("po_pending", "?"))],
                ["Stock value", _fmt_money(ops.get("stock_value"))],
            ],
            align=["left", "right"],
        )
        # Attention section
        if data.get("attention"):
            report.add_section("ATTENTION")
            report.add_bullets(data["attention"])
        out.markdown_report(report)
        return


# In digest() handler
    if fmt == "markdown":
        from kctl_lib.markdown_report import MarkdownReport
        data = _build_digest(c)
        report = MarkdownReport(title="Daily Digest")
        for section in data.get("sections", []):
            report.add_kv(section.get("label", ""), section.get("value", ""))
        out.markdown_report(report)
        return


def _fmt_money(value) -> str:
    if value is None:
        return ""
    return f"{value:,.0f}" if isinstance(value, (int, float)) else str(value)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k dashboard
```

Expected: Both dashboard tests pass.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/dashboard.py tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): dashboard summary/digest --format markdown

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 19: `doctor ai-summary` — refactor to use `MarkdownReport`

**Files:**
- Modify: `packages/kctl-odoo/src/kctl_odoo/commands/diagnose.py`
- Modify: `packages/kctl-odoo/tests/test_format_markdown.py`

- [ ] **Step 1: Write the failing test**

```python
# Append to packages/kctl-odoo/tests/test_format_markdown.py
def test_doctor_ai_summary_format_markdown(runner, mock_client):
    fake_summary = {
        "profile": "idtpp-tpp-odoo-erp",
        "connection": "ok",
        "auth": "ok",
        "modules_installed": 47,
        "modules_update_count": 0,
        "db_size_mb": 2300,
        "workers": "4/4",
        "last_backup": "9h ago",
        "warnings": ["account_payment_term has pending migration"],
        "next_steps": ["kctl-odoo audit report"],
    }
    with patch("kctl_odoo.commands.diagnose._collect_ai_summary", return_value=fake_summary), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["doctor", "ai-summary", "--format", "markdown"])
    assert result.exit_code == 0
    assert "*Odoo Health" in result.output
    assert "idtpp-tpp-odoo-erp" in result.output
    assert "Connection" in result.output and "ok" in result.output
    assert "_account_payment_term" in result.output or "- account_payment_term" in result.output
    assert "kctl-odoo audit report" in result.output


def test_doctor_ai_summary_json_includes_markdown_ready_flag(runner, mock_client):
    """The --json output advertises markdown support so agents can discover it in one call."""
    fake_summary = {"profile": "idtpp-tpp-odoo-erp", "connection": "ok", "auth": "ok"}
    with patch("kctl_odoo.commands.diagnose._collect_ai_summary", return_value=fake_summary), \
         patch("kctl_odoo.callbacks.AppContext.client", new_callable=lambda: mock_client):
        result = runner.invoke(app, ["doctor", "ai-summary", "--json"])
    assert result.exit_code == 0
    import json as _json
    payload = _json.loads(result.output)
    assert payload.get("markdown_ready") is True
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k doctor
```

Expected: Both fail.

- [ ] **Step 3: Refactor `diagnose.py`**

The current `diagnose.py:69` has a `to_markdown()` function. Refactor it to use `MarkdownReport`:

```python
# In diagnose.py
def _render_ai_summary_markdown(summary: dict) -> "MarkdownReport":
    from kctl_lib.markdown_report import MarkdownReport
    from datetime import datetime, timezone

    profile = summary.get("profile", "?")
    now = datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M %Z")
    report = MarkdownReport(title=f"Odoo Health — {profile} — {now}")
    rows = [
        ["Connection", f"✓ {summary.get('connection', '?')}"],
        ["Authentication", f"✓ {summary.get('auth', '?')}"],
        ["Modules installed", str(summary.get("modules_installed", "?"))],
        ["Modules to update", str(summary.get("modules_update_count", "?"))],
        ["Database size", f"{summary.get('db_size_mb', '?')} MB"],
        ["Workers", str(summary.get("workers", "?"))],
        ["Last backup", str(summary.get("last_backup", "?"))],
    ]
    report.add_table_monospace(headers=["", ""], rows=rows, align=["left", "left"])
    for w in summary.get("warnings", []) or []:
        report.add_bullet(w)
    if summary.get("next_steps"):
        for n in summary["next_steps"]:
            report.add_bullet(f"Next recommended: `{n}`")
    return report


# In the ai-summary handler — add markdown branch and markdown_ready: true on JSON
    if fmt == "markdown":
        report = _render_ai_summary_markdown(summary)
        out.markdown_report(report)
        return
    if fmt == "json" or actx.output.json_mode:
        summary["markdown_ready"] = True
        out.raw_json(summary)
        return
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
cd packages/kctl-odoo && uv run pytest tests/test_format_markdown.py -v -k doctor
```

Expected: Both doctor tests pass.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add src/kctl_odoo/commands/diagnose.py tests/test_format_markdown.py
git commit -m "feat(kctl-odoo): doctor ai-summary --format markdown + markdown_ready flag

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 20: `commands list --markdown-ready` flag

**Files:**
- Modify: `packages/kctl-lib/src/kctl_lib/introspection.py`
- Create: `packages/kctl-lib/tests/test_introspection_markdown_ready.py`

- [ ] **Step 1: Write the failing test**

```python
# packages/kctl-lib/tests/test_introspection_markdown_ready.py
import typer
from typer.testing import CliRunner

from kctl_lib.introspection import register_introspection_commands

runner = CliRunner()


def _make_app_with_markdown_choice():
    """Build a tiny Typer app where one command has format choices including 'markdown'."""
    app = typer.Typer()

    @app.command("noop")
    def noop():
        """Does nothing."""

    @app.command("rich")
    def rich(fmt: str = typer.Option("pretty", "--format", "-f")):
        """Pretends to support markdown."""

    # Add the introspection commands
    register_introspection_commands(app)
    return app


def test_markdown_ready_flag_filters_only_supporting_commands(monkeypatch):
    """commands list --markdown-ready returns only commands that accept --format markdown."""
    # Simulate the param-schema lookup: monkeypatch dump_command_tree to return
    # a snapshot where one command has 'markdown' in its format choices.
    from kctl_lib import introspection

    snapshot = {
        "name": "root",
        "commands": {
            "report": {
                "commands": {
                    "quick": {
                        "params": [
                            {"name": "format", "opts": ["--format"], "choices": ["xlsx","json","markdown"]},
                            {"name": "with_files", "opts": ["--with-files"], "choices": None},
                        ],
                    },
                    "metadata": {
                        "params": [{"name": "id", "opts": ["--id"], "choices": None}],
                    },
                },
            },
        },
    }
    monkeypatch.setattr(introspection, "dump_command_tree", lambda app: snapshot)

    app = _make_app_with_markdown_choice()
    result = runner.invoke(app, ["commands", "list", "--markdown-ready", "--json"])
    assert result.exit_code == 0
    import json as _json
    payload = _json.loads(result.output)
    paths = [entry["path"] for entry in payload]
    assert "report quick" in paths
    assert "report metadata" not in paths
    # 'with_files' choices should be exposed when the markdown command also has --with-files
    report_quick = next(e for e in payload if e["path"] == "report quick")
    assert "with_files" in report_quick
```

- [ ] **Step 2: Run test to verify it fails**

```bash
cd packages/kctl-lib && uv run pytest tests/test_introspection_markdown_ready.py -v
```

Expected: `--markdown-ready` not recognized.

- [ ] **Step 3: Add `--markdown-ready` to introspection**

```python
# Modify packages/kctl-lib/src/kctl_lib/introspection.py — extend register_introspection_commands

# Inside register_introspection_commands, add a new option to the existing `list` command:
    @cmd_group.command("list")
    def cmd_list(
        filter_substr: str | None = typer.Option(None, "--filter", help="..."),
        as_json: bool = typer.Option(False, "--json"),
        markdown_ready: bool = typer.Option(
            False, "--markdown-ready",
            help="List only commands that accept --format markdown (with their --with-files choices, if any)",
        ),
    ):
        tree = dump_command_tree(app)
        if markdown_ready:
            entries = _collect_markdown_ready(tree)
            if as_json:
                import json as _json
                print(_json.dumps(entries, indent=2))
            else:
                for e in entries:
                    files = ",".join(e.get("with_files") or []) or "(no files)"
                    print(f"{e['path']:40s}  with_files: {files}")
            return
        # ... existing list behavior unchanged ...


# Add the helper at module scope
def _collect_markdown_ready(node: dict, prefix: str = "") -> list[dict]:
    """Walk the command tree and emit one entry per leaf command whose --format
    option accepts 'markdown'. Each entry also notes whether --with-files is
    supported and its choices, if introspection exposes them.
    """
    out: list[dict] = []
    for name, child in (node.get("commands") or {}).items():
        path = f"{prefix} {name}".strip()
        params = child.get("params") or []
        format_param = next((p for p in params if p.get("name") == "format"), None)
        if format_param and "markdown" in (format_param.get("choices") or []):
            entry = {"path": path}
            wf = next((p for p in params if p.get("name") in {"with_files", "with-files"}), None)
            if wf:
                entry["with_files"] = wf.get("choices") or []
            out.append(entry)
        # Recurse into subgroups
        if child.get("commands"):
            out.extend(_collect_markdown_ready(child, prefix=path))
    return out
```

- [ ] **Step 4: Run test to verify it passes**

```bash
cd packages/kctl-lib && uv run pytest tests/test_introspection_markdown_ready.py -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-lib
git add src/kctl_lib/introspection.py tests/test_introspection_markdown_ready.py
git commit -m "feat(kctl-lib): commands list --markdown-ready filter

One-call discovery of which commands accept --format markdown and what
--with-files choices they offer. Used by AI agents (hermes) to learn the
chat-delivery surface in ~150 tokens.

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 21: SKILL.md — chat-delivery section

**Files:**
- Modify: `packages/kctl-odoo/skills/odoo-admin/SKILL.md`

- [ ] **Step 1: Read current SKILL.md to find the right insertion point**

```bash
cd packages/kctl-odoo && head -80 skills/odoo-admin/SKILL.md
```

Find the "## Triggers" or "## Quick Discovery" section. The new chat-delivery section should sit just AFTER the agent workflow / AI affordances and BEFORE any deep command catalog.

- [ ] **Step 2: Add the chat-delivery section**

Insert the following block at the chosen location (after `## Quick Discovery` and before any large command list):

```markdown
## Chat/Telegram delivery

For ANY report destined for a chat platform (Telegram/Mattermost/WhatsApp via hermes):

    kctl-odoo <command> --format markdown [--with-files xlsx,pdf]

Output is portable markdown + `MEDIA:<abs-path>` tokens that hermes auto-uploads
as documents. Use `--format markdown` for inline summary; add `--with-files` when
the user wants the full data. Never hand-format markdown from `--format json`.

Supported in v1:

| Command               | Files supported (v1)      |
|----------------------|---------------------------|
| `report quick`        | `xlsx` (`pdf` in v1.1)    |
| `analyze run`         | (none yet — inline only)  |
| `kpi run`             | (none yet — inline only)  |
| `dashboard summary`   | (none — inline only)      |
| `dashboard digest`    | (none — inline only)      |
| `doctor ai-summary`   | (none — inline only)      |

> `analyze run` / `kpi run` file export (xlsx) is v1.1 — those commands have no
> native XLSX renderer today; building one is out of v1 scope. Inline markdown
> works for them now.

Discovery in one call:

    kctl-odoo commands list --markdown-ready --json

Inside the hermes container, `$KCTL_ODOO_REPORT_DIR` is preset to
`/opt/data/reports`. Files auto-cleanup after 7 days; you don't need to manage
disk hygiene.
```

- [ ] **Step 3: Re-generate SKILL.md frontmatter if needed**

If the SKILL.md is auto-generated via `kctl-odoo skill generate`, run that command to refresh the trigger keywords:

```bash
cd packages/kctl-odoo && uv run kctl-odoo skill generate --output skills/odoo-admin/SKILL.md --merge
```

(Confirm with `git diff skills/odoo-admin/SKILL.md` that the chat-delivery section survived.)

- [ ] **Step 4: Verify content present**

```bash
grep -A 2 "Chat/Telegram delivery" packages/kctl-odoo/skills/odoo-admin/SKILL.md
```

Expected: the section content prints.

- [ ] **Step 5: Commit**

```bash
cd packages/kctl-odoo
git add skills/odoo-admin/SKILL.md
git commit -m "docs(kctl-odoo): add Chat/Telegram delivery section to odoo-admin skill

Documents --format markdown + --with-files for AI-agent discovery.

Co-Authored-By: Claude <noreply@anthropic.com>"
```

---

## Task 22: `hermes-init.sh` — set `KCTL_ODOO_REPORT_DIR`

**Files:**
- Modify: `../kodemeio-hermes/scripts/hermes-init.sh` (separate repo)

> **Note:** This is a cross-repo change. After committing, this needs a separate PR in `kodemeio-hermes`.

- [ ] **Step 1: Read the current `hermes-init.sh` to find a clean insertion point**

```bash
cd ../../../kodemeio-hermes && cat scripts/hermes-init.sh
```

Find the section where `PATH` and other env vars are exported (likely near where `KCTL_ODOO_VERSION` is set).

- [ ] **Step 2: Append the env-var export and directory creation**

Add immediately after the kctl-odoo installation block:

```bash
# kctl-odoo report output directory — files emitted by `--with-files xlsx,pdf`
# land here. The hermes process reads MEDIA:<path> tokens from this directory
# and uploads them via Telegram/Mattermost/WhatsApp.
export KCTL_ODOO_REPORT_DIR=/opt/data/reports
mkdir -p "$KCTL_ODOO_REPORT_DIR"
chown hermes:hermes "$KCTL_ODOO_REPORT_DIR" 2>/dev/null || true
```

(The `chown` is best-effort — fails silently in non-root contexts.)

- [ ] **Step 3: Verify the script still passes shellcheck**

```bash
cd ../../../kodemeio-hermes && shellcheck scripts/hermes-init.sh
```

Expected: No new warnings introduced.

- [ ] **Step 4: Commit (in `kodemeio-hermes`, separate PR)**

```bash
cd ../../../kodemeio-hermes
git checkout -b feat/kctl-odoo-report-dir
git add scripts/hermes-init.sh
git commit -m "feat(hermes-init): set KCTL_ODOO_REPORT_DIR for kctl-odoo chat delivery

Puts kctl-odoo's --with-files xlsx,pdf output on the hermes-state volume so
MEDIA:<path> tokens resolve correctly through the gateway's extract_media regex.

Companion change for kctl-odoo v0.2.0 chat-delivery support. See:
  packages/kctl-odoo/docs/superpowers/specs/2026-05-23-kctl-odoo-markdown-reporting-design.md

Co-Authored-By: Claude <noreply@anthropic.com>"
```

- [ ] **Step 5: Open PR**

```bash
gh pr create --title "feat(hermes-init): KCTL_ODOO_REPORT_DIR for chat delivery" \
  --body "$(cat <<'EOF'
## Summary
- Sets `KCTL_ODOO_REPORT_DIR=/opt/data/reports` in the hermes container so kctl-odoo writes XLSX/PDF files where the hermes process can read them
- Creates the directory + best-effort chown
- Companion to kctl-odoo v0.2.0 (PR in kodemeio-cli)

## Test plan
- [ ] Container starts cleanly; `KCTL_ODOO_REPORT_DIR` is set in process env
- [ ] `/opt/data/reports` exists with correct ownership
- [ ] `kctl-odoo report quick profit_loss --format markdown --with-files xlsx --date-from 2026-04-01 --date-to 2026-04-30` from inside the container writes the file to `/opt/data/reports/`
- [ ] Telegram message arrives with markdown body + XLSX attachment

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

---

## Task 23: Final verification — end-to-end smoke + full test suites

**Files:**
- (Verification only)

- [ ] **Step 1: Run full kctl-lib test suite**

```bash
cd packages/kctl-lib && uv run pytest tests/ -v
```

Expected: All tests pass (existing 415 + new ~50).

- [ ] **Step 2: Run full kctl-odoo test suite**

```bash
cd packages/kctl-odoo && uv run pytest tests/ -v
```

Expected: All tests pass — no regressions in existing pretty/json/csv/yaml paths.

- [ ] **Step 3: Run ruff on all modified files**

```bash
cd /home/tgunawan/project/00-new-projects/kodemeio-workspace/kodemeio-cli
uv run ruff check packages/kctl-lib/src/ packages/kctl-odoo/src/
```

Expected: All checks passed.

- [ ] **Step 4: Run mypy strict on kctl-lib**

```bash
cd packages/kctl-lib && uv run mypy src/
```

Expected: Success: no issues found.

- [ ] **Step 5: Local end-to-end smoke against a real Odoo instance**

```bash
# Use the developer's local profile (e.g., local-tpp-odoo-erp)
export KCTL_ODOO_REPORT_DIR=/tmp/kctl-smoke
mkdir -p /tmp/kctl-smoke

# 1. Markdown only
kctl-odoo -p local-tpp-odoo-erp report quick profit_loss \
  --date-from 2026-04-01 --date-to 2026-04-30 --format markdown

# Expected output: *P&L — …* with monospace table, no MEDIA tokens.

# 2. Markdown + files (xlsx in v1; pdf gives a "not yet available" note)
kctl-odoo -p local-tpp-odoo-erp report quick profit_loss \
  --date-from 2026-04-01 --date-to 2026-04-30 --format markdown --with-files xlsx

# Expected output: same body + one MEDIA: line pointing to /tmp/kctl-smoke/*.xlsx
ls -la /tmp/kctl-smoke/   # xlsx file should exist

# 3. Analytics preset
kctl-odoo -p local-tpp-odoo-erp analyze run top-products --format markdown

# 4. Dashboard
kctl-odoo -p local-tpp-odoo-erp dashboard summary --format markdown

# 5. Doctor
kctl-odoo -p local-tpp-odoo-erp doctor ai-summary --format markdown

# 6. Discovery
kctl-odoo commands list --markdown-ready --json
```

Expected: all 6 produce well-formed markdown under 4096 chars; MEDIA tokens point to real files; discovery JSON lists the six command paths.

- [ ] **Step 6: Verify no regression in existing formats**

```bash
kctl-odoo -p local-tpp-odoo-erp report quick profit_loss \
  --date-from 2026-04-01 --date-to 2026-04-30 --format xlsx -o /tmp/reg.xlsx
file /tmp/reg.xlsx  # should be Excel
kctl-odoo -p local-tpp-odoo-erp report quick profit_loss \
  --date-from 2026-04-01 --date-to 2026-04-30 --format json > /tmp/reg.json
jq '.report_name' /tmp/reg.json  # should print the report name
```

- [ ] **Step 7: Tag the kctl-lib + kctl-odoo releases**

```bash
cd packages/kctl-lib && git tag kctl-lib-v0.12.0
cd ../kctl-odoo && git tag kctl-odoo-v0.2.0
```

- [ ] **Step 8: Update CHANGELOG entries (if present)**

If `packages/kctl-lib/CHANGELOG.md` or `packages/kctl-odoo/CHANGELOG.md` exist, add an entry:

```markdown
## 0.12.0 (kctl-lib) — 2026-05-23

### Added
- `MarkdownReport` builder for portable Telegram/Mattermost/WhatsApp output
- `chat_emit` utilities: `resolve_output_dir`, `build_filename`, `atomic_write`, `cleanup_old_files`
- `Output.markdown_report()` method
- `commands list --markdown-ready` introspection flag
```

```markdown
## 0.2.0 (kctl-odoo) — 2026-05-23

### Added
- `--format markdown` on: `report quick`, `analyze run`, `analyze presets`,
  `kpi run`, `kpi list`, `dashboard summary`, `dashboard digest`, `doctor ai-summary`
- `--with-files xlsx` on `report quick` (PDF deferred to v1.1 / api_report)
- `doctor ai-summary --json` now includes `"markdown_ready": true`
```

- [ ] **Step 9: Final commit**

```bash
cd /home/tgunawan/project/00-new-projects/kodemeio-workspace/kodemeio-cli
git add packages/kctl-lib/CHANGELOG.md packages/kctl-odoo/CHANGELOG.md 2>/dev/null || true
git commit -m "chore: release notes for kctl-lib v0.12.0 + kctl-odoo v0.2.0

Co-Authored-By: Claude <noreply@anthropic.com>"
```
