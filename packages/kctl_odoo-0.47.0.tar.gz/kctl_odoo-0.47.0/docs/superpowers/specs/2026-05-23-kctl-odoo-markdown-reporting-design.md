# kctl-odoo Markdown Reporting & Unified Report Architecture — Design

**Date:** 2026-05-23
**Author:** Tri Gunawan (+ Claude)
**Status:** Design — not yet implemented
**Scope:** Make kctl-odoo reports/analytics/export emit Telegram/Mattermost/WhatsApp-ready output directly, so AI agents (hermes) deliver inline markdown summaries + file attachments without any format conversion. Land a `MarkdownReport` builder in kctl-lib (Phase 0), then an `api_report` Odoo module for fast single-call retrieval (Phase 1). Document the longer-term unification of all reports under `report.template` as a roadmap (Phases 2–5).

**Repos touched:**
- `kodemeio-cli/packages/kctl-lib/` — new MarkdownReport builder + chat_emit utilities (v1)
- `kodemeio-cli/packages/kctl-odoo/` — wire `--format markdown` into 6 commands (v1)
- `kodemeio-hermes/scripts/hermes-init.sh` — one new env-var line (v1)
- `kodemeio-odoo/src/private/services/api_report/` — new Odoo module (v1.1)

---

## Section 1 — Current state

**kctl-odoo reporting surface (today):**

- ~50 report-related commands across `report/`, `analytics/`, `kpi/`, `dashboard/`, `export records`, `sql-export`.
- Output formats supported: Rich-terminal (BBCode breaks on chat platforms), JSON (full-fidelity dump), XLSX (file-on-disk), PDF (file-on-disk).
- **No markdown output** in any financial/analytics/KPI/dashboard command. The only existing markdown emitters are `diagnose`, `modules audit`, `security audit`, and `accurate parity`.
- **Inline + file outputs are mutually exclusive.** `report quick --format json` returns rows; default `report quick` writes XLSX and returns only `{file, size}` metadata. Producing both requires two RPC round-trips.
- **No stdout-bytes / base64 / `-` sentinel.** Bytes always go to disk first; agents must own a writable path and re-read.
- **`analyze run` rows are unbounded.** A full P&L is 5–15 KB JSON; no `--summary` or `--top-n` filter exists.

**Four "report-shaped" data sources under four different models:**

| Command family | Backing data | Module(s) |
|---|---|---|
| `report quick` (P&L, BS, AR-aging, etc.) | `report.template` / `report.instance` records | `report_base` + 11 children (financial, account, hr, inventory, mrp, pos, purchase, sales, sales_pos, cashbank, tax) |
| `analyze run <preset>` | YAML files in `~/.config/kodemeio/analytics/` | kctl-odoo CLI only |
| `kpi run` | OCA `mis.report.instance` records | mis_builder + `mis_builder_theme` |
| `dashboard summary` / `digest` | Ad-hoc JSONRPC orchestration across multiple Odoo models | kctl-odoo CLI only |

**Verified architectural fact:** all 11 children of `report_base` follow a uniform pattern — each `_inherit`s `report.template` or `report.instance` and overrides `_prepare_report_data()` via `super()` (additive). One handler dispatch in `report.type.registry`. One data shape returned. Confirmed by reading `report_account/models/report_instance_account.py:23`, `report_cashbank/models/report_instance.py:35`, `report_hr/...`, `report_sales/...`, etc.

**Hermes integration (today):**

- Hermes-agent runs upstream `NousResearch/hermes-agent@v2026.5.16` in a Dokploy container. Inbound v1 = Telegram only; Mattermost + WhatsApp planned for Phase 2.
- kctl-odoo is installed **inside the hermes container** at `/opt/data/.local/bin/kctl-odoo` by `hermes-init.sh`.
- Hermes' gateway base class (`gateway/platforms/base.py:2162`) extracts `MEDIA:<absolute-path>.<ext>` tokens from any tool response text and uploads them as Telegram documents. Supported extensions: `pdf`, `xlsx`, `docx`, `csv`, `png`, `jpg`, `zip`, etc. **This regex is at the base level — applies to all platforms (Telegram, Mattermost, WhatsApp).**
- Telegram-specific MarkdownV2 escaping happens **inside the Telegram platform handler** — tools do NOT need to pre-escape.
- **Critical lossiness:** hermes' MCP tool-result loop (`tools/mcp_tool.py:2362-2370`) only caches `ImageContent` blocks. PDF/XLSX returned as MCP `EmbeddedResource` blobs are **silently dropped**. The working path is the `MEDIA:<path>` text token, not MCP binary blocks.
- Telegram: `sendMessage` cap = 4096 chars; `sendDocument` caption = 1024 chars; document upload ≤ 50 MB.
- WhatsApp formatting subset: `*bold*`, `_italic_`, `~strike~`, `` `code` ``, ``` ```code``` ```. No GFM tables, no `#` headers.
- Mattermost: full GFM, 16384-char body. Headier ceiling but we target the floor for portability.

---

## Section 2 — Decisions locked in

| Decision | Value | Source |
|---|---|---|
| Output flag | Extend existing `--format/-f` global with new value `markdown` | User Q1 |
| File attachment | Opt-in via `--with-files xlsx,pdf` (or just `xlsx`) | User Q2 |
| Inline detail level | Compact: headline rows (kind=`total`/`subheader`) + totals only. Full detail in XLSX. `--detail` flag opts into all rows. | User Q3 |
| Platform compatibility | Portable GFM-lite. No `#` headers. No native GFM tables (use fenced code blocks). No MarkdownV2 escaping in kctl-odoo — hermes handles per-platform. | User clarification |
| Char ceiling | 4096 (Telegram = WhatsApp lower bound) | Telegram Bot API |
| v1 command scope | `report quick`, `analyze run` (+ `presets`), `kpi run` (+ `list`), `dashboard summary` (+ `digest`), `doctor ai-summary` | User Q4 |
| v1.1 secondary scope | `sql-export execute`, `export records` (same code path) | User Q4 |
| Output dir resolution | `--out-dir` > `$KCTL_ODOO_REPORT_DIR` > `~/.cache/kctl-odoo/reports` | User Q5 |
| File TTL | Auto-cleanup files older than 7 days on each run; configurable via `KCTL_ODOO_REPORT_TTL_DAYS` | User Q6 |
| Renderer location | Shared `MarkdownReport` builder in kctl-lib, reusable across all 35 kctl-* CLIs | User Q7 (Approach 2) |
| Server-side endpoint | `api_report` module — hybrid render (server renders, CLI falls back to JSONRPC + local builder when not installed) | User Q8 (Hybrid) |
| Sequencing | Phase 0 (CLI MarkdownReport) ships first. Phase 1 (api_report) follows. Phases 2–5 are roadmap. | User Q9 |
| Long-term direction | All reporting (financial, analytics, KPI, dashboard) becomes `report.template` records. `api_report` becomes single endpoint family. | User architectural vision |

---

## Section 3 — Proposed architecture

### The unified vision

`report.template` is the single source of truth for every kind of report. `api_report` is the single HTTP endpoint family.

```
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT (hermes via MCP/shell)                 │
│                                                                 │
│   $ kctl-odoo report quick <type> --format markdown             │
│                                              [--with-files …]   │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│ kctl-odoo CLI                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Command handler (report quick / analyze run / kpi run /  │   │
│  │ dashboard summary / doctor ai-summary)                   │   │
│  └──────────────┬───────────────────────────────────────────┘   │
│                 │                                               │
│                 │  if api_report installed → fast path          │
│                 │  else → JSONRPC fallback                      │
│                 ▼                                               │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ kctl-lib MarkdownReport builder                          │   │
│  │   add_kv() add_table_monospace() add_bullet()            │   │
│  │   add_section() add_media() render(max_chars=4096)       │   │
│  └──────────────┬───────────────────────────────────────────┘   │
│                 │                                               │
│  ┌──────────────▼───────────────────────────────────────────┐   │
│  │ kctl-lib chat_emit                                        │  │
│  │   resolve_output_dir() cleanup_old_files() write atomic   │  │
│  └──────────────┬────────────────────────────────────────────┘  │
└─────────────────┼───────────────────────────────────────────────┘
                  │
                  ▼ stdout
    *Title — Period*
    ```
    table contents in monospace
    ```
    - bullets
    MEDIA:/opt/data/reports/file.xlsx
    MEDIA:/opt/data/reports/file.pdf
                  │
                  ▼
┌─────────────────────────────────────────────────────────────────┐
│ hermes-agent gateway (upstream)                                 │
│   1. Extract MEDIA:<path> tokens via base.py:2162 regex         │
│   2. Send markdown body via platform's sendMessage              │
│      (per-platform escaping: MDV2 for Telegram, GFM for         │
│       Mattermost, restricted for WhatsApp)                      │
│   3. Send each MEDIA file via platform's sendDocument           │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
               Telegram / Mattermost / WhatsApp
```

### Coverage matrix (Phase 0)

| Command | Phase 0 path | Phase 1 path |
|---|---|---|
| `report quick` | JSONRPC + CLI MarkdownReport | `api_report` /reports/render (fast) |
| `analyze run` / `presets` | JSONRPC + CLI MarkdownReport | unchanged in Phase 1; unified to `report quick` in Phase 2 |
| `kpi run` / `list` | JSONRPC + CLI MarkdownReport | unchanged in Phase 1; unified in Phase 3 |
| `dashboard summary` / `digest` | JSONRPC + CLI MarkdownReport | unchanged in Phase 1; unified in Phase 4 |
| `doctor ai-summary` | local + CLI MarkdownReport | unchanged forever (it's diagnostic, no Odoo records) |

**Coverage of report_base children (verified):** all 11 modules (`report_account`, `report_financial`, `report_hr`, `report_inventory`, `report_mrp`, `report_pos`, `report_purchase`, `report_sales`, `report_sales_pos`, `report_cashbank`, `report_tax`) conform to the `_prepare_report_data()` super-chain pattern. `api_report` covers all of them with one endpoint family — no per-child API code.

**Out of scope for `api_report`:** `mis_builder_theme` (no data), `report_design*` (UI/layout, no data). These are handled by their respective modules and don't need API exposure.

---

## Section 4 — Phase 0: kctl-lib MarkdownReport (week 1–2)

### File layout

```
packages/kctl-lib/src/kctl_lib/
├── markdown_report.py          NEW
├── chat_emit.py                NEW
└── output.py                   EXTEND (add format="markdown" handler)

packages/kctl-lib/tests/
├── test_markdown_report.py     NEW
└── test_chat_emit.py           NEW
```

### `MarkdownReport` builder API

```python
# packages/kctl-lib/src/kctl_lib/markdown_report.py

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Sequence

Align = Literal["left", "right", "center"]

@dataclass
class MarkdownReport:
    title: str                          # *bold* line
    subtitle: str | None = None         # _italic_ line
    _blocks: list = field(default_factory=list)
    _media: list[Path] = field(default_factory=list)

    # Builders (chainable)
    def add_kv(self, key: str, value: str) -> "MarkdownReport": ...
    def add_bullet(self, text: str) -> "MarkdownReport": ...
    def add_bullets(self, items: Sequence[str]) -> "MarkdownReport": ...
    def add_table_monospace(
        self,
        headers: Sequence[str],
        rows: Sequence[Sequence[str]],
        align: Sequence[Align] | None = None,
        max_col_width: int = 24,
    ) -> "MarkdownReport": ...
    def add_section(self, title: str) -> "MarkdownReport": ...
    def add_code(self, text: str, lang: str = "") -> "MarkdownReport": ...
    def add_note(self, text: str) -> "MarkdownReport": ...
    def add_media(self, path: Path | str) -> "MarkdownReport": ...

    # Rendering
    def render(self, max_chars: int = 4096) -> str: ...
    def render_chunks(self, max_chars: int = 4096) -> list[str]: ...
    def to_json(self) -> dict: ...
```

### Rendering rules (portable across Telegram/Mattermost/WhatsApp)

| Concern | Choice | Why |
|---|---|---|
| Bold | `*text*` | All 3 platforms |
| Italic | `_text_` | All 3 |
| Tables | Fenced code blocks with padded columns | WhatsApp can't render GFM tables |
| Headers | None — use `*Title*` on its own line | WhatsApp ignores `#`; MDV2 treats `#` literally |
| Lists | `- item` lines | All 3 |
| Code | Triple-backtick fences | All 3 |
| Links | `[text](url)` | All 3 (MDV2 URL escaping handled by hermes) |
| File attach | `MEDIA:<abs-path>` on its own line, end of body | Hermes' base-gateway regex; works for all platforms |
| Special chars | **No backslash-escaping in builder** | Hermes' Telegram handler escapes MDV2 itself |

### Chunking algorithm

- Render whole document
- If ≤ `max_chars`, return as single chunk
- Otherwise split on **block boundaries** — never mid-fence, never mid-table-row
- Each chunk title gets `(N/M)` suffix
- MEDIA tags emit on the **final chunk only** (attachments arrive after reading order)

### JSON shape (`.to_json()`)

```json
{
  "title": "P&L — TPP — 2026-04-01 → 2026-04-30",
  "subtitle": "Generated 2026-05-23 11:21 GMT+7",
  "blocks": [
    {"type": "table", "headers": [...], "rows": [...]},
    {"type": "bullets", "items": [...]}
  ],
  "media": ["/opt/data/reports/pnl.xlsx", "/opt/data/reports/pnl.pdf"]
}
```

This doubles as a structured envelope for agents that want to render their own markdown.

### `chat_emit` utilities

```python
# packages/kctl-lib/src/kctl_lib/chat_emit.py

def resolve_output_dir(cli_arg: Path | None = None) -> Path:
    """--out-dir > $KCTL_ODOO_REPORT_DIR > ~/.cache/kctl-odoo/reports"""

def cleanup_old_files(out_dir: Path, ttl_days: int = 7) -> int:
    """Lazy cleanup before each new file write. Skip files <60s old (race window)."""

def atomic_write(out_dir: Path, name: str, bytes_data: bytes) -> Path:
    """tempfile + atomic rename. Returns absolute resolved path."""

def build_filename(type_slug: str, company_slug: str, date_range: str, ext: str) -> str:
    """{type_slug}_{company_slug}_{date_range}_{shortuuid}.{ext}"""
```

### File naming convention

```
{type_slug}_{company_slug}_{date_range}_{shortuuid}.{ext}

Examples:
  pnl_TPP_2026-04-30_a3f4.xlsx
  balance-sheet_consolidated_2026-04-30_b7e1.pdf
  top-products_TPP_2026-04-30_c2d8.xlsx
  ar-aging_MAC_2026-04-30_e5f9.xlsx
```

- `type_slug`: command-defined (`pnl`, `balance-sheet`, `top-products`)
- `company_slug`: profile company short name or `consolidated` for multi-co
- `date_range`: `YYYY-MM-DD` (single) or end-of-range
- `shortuuid`: 4-char random suffix — collision-free for back-to-back runs

### `Output` class extension

```python
# packages/kctl-lib/src/kctl_lib/output.py — EXTEND

class Output:
    # existing: pretty, json, csv, yaml
    # NEW: markdown
    def emit(self, payload, format: str = "pretty"):
        if format == "markdown":
            assert isinstance(payload, MarkdownReport), "markdown format requires MarkdownReport"
            sys.stdout.write(payload.render(max_chars=4096))
        # ... existing branches
```

---

## Section 5 — Phase 0: kctl-odoo command changes (week 1–2)

### v1 must-ship — 6 commands

| Command | File | Change |
|---|---|---|
| `report quick` | `commands/report/mgmt_framework.py:2871` | Add `--format markdown` branch + `--with-files xlsx,pdf` flag. Build MarkdownReport from `_prepare_report_data()`. Reuse existing XLSX/PDF generation. |
| `analyze run` + `presets` | `commands/analytics/__init__.py`, `commands/analytics/engine.py` | Add `--format markdown` branch. Filter to headline rows. `--with-files xlsx` for full data. |
| `kpi run` + `list` | `commands/kpi_cmd.py` | Add `--format markdown` branch. Render KPI table with vs-target column. `--with-files xlsx`. |
| `dashboard summary` + `digest` | `commands/dashboard.py` | Add `--format markdown` branch. Multi-section render via `add_section()`. No file path (composite — too varied). |
| `doctor ai-summary` | `commands/diagnose.py:69` (already has `to_markdown()`) | Refactor existing `to_markdown` to use MarkdownReport builder. Keep current output shape compatible. |

### v1.1 secondary scope (same code path, easy extension)

- `sql-export execute` — `commands/sql_export_cmd.py`
- `export records` — `commands/export_cmd.py`

### Command-level rendering examples

**`report quick profit_loss --format markdown --with-files xlsx,pdf`:**

```
*P&L — TPP — 2026-04-01 → 2026-04-30*
_Generated 2026-05-23 11:21 GMT+7 · profile: idtpp-tpp-odoo-erp_

```
REVENUE                       1,234,567,890
COST OF SALES                   987,654,321
GROSS PROFIT                    246,913,569
  Margin %                            20.0%

OPERATING EXPENSES              150,000,000
OPERATING INCOME                 96,913,569

NET INCOME                       85,000,000
```

- Revenue MoM: +12.4%
- Net margin: 6.9%

MEDIA:/opt/data/reports/pnl_TPP_2026-04-30_a3f4.xlsx
MEDIA:/opt/data/reports/pnl_TPP_2026-04-30_a3f4.pdf
```

**`analyze run top-products --format markdown --validate`:**

```
*Top Products — TPP — 2026-04-01 → 2026-04-30*
_Top 20 by revenue · 1,234 records analyzed_

```
RANK  PRODUCT                          REVENUE       UNITS
   1  Coffee Beans Premium 1kg      45,000,000       3,200
   2  Roasted Beans Espresso 500g   32,500,000       2,800
   ...
  20  Coffee Cups Branded 12oz       2,400,000      12,000
```

- Top 5 = 50.6% of revenue
- Validated against P&L revenue total: ✓ (Δ -0.02%)
```

**`kpi run sales_dashboard --format markdown`:**

```
*Sales Dashboard — TPP — Q2 2026*
_OCA mis_builder · 12 KPIs computed_

```
KPI                       VALUE        TARGET      vs TARGET
Revenue                   246M         250M           -1.6%
Gross profit              49M          50M            -2.0%
Net margin                15.2%        14.0%          +1.2pp
New customers             47           50             -6.0%
... (8 more)
```

- 8 of 12 KPIs above target
- AR days improving (-6.7% vs target)
```

**`dashboard summary --format markdown`:**

```
*Executive Summary — TPP — 2026-05-23*

*FINANCIAL*
```
Net income MTD            85M    (+12%)
Cash on hand              420M
AR outstanding            180M   (42d avg)
AP outstanding            95M    (28d avg)
```

*OPERATIONS*
```
Sales orders pending      23
Purchase orders pending   8
Stock value               340M
```

*ATTENTION*
- 3 invoices overdue >60 days (total 24M)
- 2 stock items below safety level
```

**`doctor ai-summary --format markdown`:**

```
*Odoo Health — idtpp-tpp-odoo-erp — 2026-05-23 11:21 GMT+7*

```
Connection                ✓ ok    (api.idtpp.com:443)
Authentication            ✓ ok    (admin)
Modules installed         47
Database size             2.3 GB
Workers                   4/4 ready
Last backup               2026-05-23 02:00 (9h ago)
```

- Warning: account_payment_term has pending migration
- Next recommended: `kctl-odoo audit report` (last audit 8 days ago)
```

### Headline-row selection algorithm

For report-engine commands (`report quick`):
```python
headline_kinds = {"total", "subheader"}
headline_rows = [r for r in all_rows if r["kind"] in headline_kinds]
```

For `analyze run` presets: presets already honor `default_limit: 20` — markdown shows the top-N rows directly.

For `kpi run`: all KPIs shown (typically 8–15 — fits under 4096).

For `dashboard summary`: each section is its own monospace block; the dashboard already computes a curated set of headline values.

### Failure modes

| Scenario | Behavior | Exit code |
|---|---|---|
| Markdown render fails (builder bug) | Hard error to stderr | 1 |
| File generation fails (XLSX/PDF) | Markdown body still emitted; `_(XLSX unavailable: <reason>)_` note appended; MEDIA tags omitted | 0 |
| `KCTL_ODOO_REPORT_DIR` not writable | Falls back to `~/.cache/kctl-odoo/reports`; logs warning | 0 |
| `api_report` not installed | Silent fallback to JSONRPC | 0 |
| Output exceeds 4096 chars after filtering | Chunks emitted with `(N/M)` suffix; MEDIA tags on final chunk | 0 |
| Cleanup fails (permission/disk) | Logged warning; flow continues | 0 |
| Path contains chars hermes regex won't match | Builder raises at `add_media()` | 1 |

**Principle:** inline markdown is the contract. Files are best-effort. An agent's turn never fails because PDF generation hiccupped.

---

## Section 6 — Phase 0: kodemeio-hermes wiring (week 2)

### One-line change to `hermes-init.sh`

```bash
# kodemeio-hermes/scripts/hermes-init.sh — APPEND
echo 'export KCTL_ODOO_REPORT_DIR=/opt/data/reports' >> /opt/data/.bashrc
mkdir -p /opt/data/reports
chown hermes:hermes /opt/data/reports
```

This puts kctl-odoo-generated files on the hermes-state named volume, where the hermes process can read them. The `MEDIA:/opt/data/reports/...` tokens then resolve correctly through hermes' `extract_media` regex.

### No upstream hermes-agent changes needed

The existing `extract_media` regex (`gateway/platforms/base.py:2162`) already covers PDF, XLSX, DOCX, CSV. The MEDIA token convention is well-established upstream.

### Optional: SKILL.md hermes hint

Add to `kodemeio-hermes/CLAUDE.md`:

```markdown
## Telegram report delivery via kctl-odoo

For any report → use `kctl-odoo <command> --format markdown [--with-files xlsx,pdf]`.
Output is portable markdown + MEDIA tokens that auto-upload as documents.

The container has KCTL_ODOO_REPORT_DIR=/opt/data/reports preconfigured. Files
older than 7 days auto-cleanup. Don't worry about disk hygiene.
```

---

## Section 7 — Phase 1: `api_report` Odoo module (week 3–4)

**Status in this spec: sketched. A separate detailed design doc lands when Phase 1 starts.**

### Goal

One HTTP round-trip from CLI → Odoo for any `report.template`-based report. Server pre-renders markdown server-side using a mirror of the kctl-lib builder. CLI relays output with zero further processing.

### Module location

```
kodemeio-odoo/src/private/services/api_report/
├── __manifest__.py                       # depends: api_base, report_base
├── models/
│   └── report_instance.py                # _inherit = ["report.instance", "api.model"]
├── services/
│   ├── markdown_renderer.py              # server-side mirror of kctl-lib builder
│   └── compute_orchestrator.py           # single-call compute + render
├── controllers/                          # auto-generated by api_base scaffold
├── schemas/
│   └── report.py                         # Pydantic input/output
├── security/
│   └── ir.model.access.csv
└── tests/
    ├── test_compute.py
    ├── test_markdown_render.py
    └── test_snapshot.py                  # server vs CLI render parity
```

### Endpoint surface (planned)

| Endpoint | Returns |
|---|---|
| `GET /api/v1/reports/types` | `[{code, name, description}]` |
| `POST /api/v1/reports/compute` | `{instance_id, structured, headline, totals, period, company}` |
| `POST /api/v1/reports/render` | `{instance_id, structured, headline, totals, xlsx_url, pdf_url, markdown}` |
| `GET /api/v1/reports/{id}/xlsx` | XLSX bytes |
| `GET /api/v1/reports/{id}/pdf` | PDF bytes |
| `GET /api/v1/reports/{id}/markdown?style=compact\|detailed` | Plain text |

### CLI integration

```python
# packages/kctl-odoo/src/kctl_odoo/commands/report/mgmt_framework.py
def report_quick(..., format: str = "pretty", with_files: list[str] = ()):
    if format == "markdown" and _api_report_available(client):
        return _fast_path_api_report(client, type_code, dates, with_files)
    # existing JSONRPC + local MarkdownReport build
```

Detection is one-time per Odoo instance: `GET /api/v1/_health` returns module list. Cached in CLI session.

### Snapshot parity

The server-side markdown renderer and the kctl-lib builder are mirror implementations. Snapshot tests in `test_snapshot.py` feed the same `report.instance.id` through both renderers and assert byte-identical markdown. Drift detected immediately at CI time.

---

## Section 8 — Unification Phases U2–U5: Roadmap (post-v1.1)

**Naming note:** these phases are prefixed `U` (Unification) to avoid collision with the **hermes-agent's** Phase 2 (Mattermost + WhatsApp inbound). The two concerns are independent and ship on independent timelines.

The long-term vision is **one `report.template` model, one API endpoint family, one CLI command for everything.** This requires migrating three other "report-shaped" subsystems.

### Phase U2 — Analytics presets → `report.template` records (week 5–6)

- New handler: `report.handler.analytics_query` (inherits `report.handler.base`). Implements `_prepare_report_data()` via `read_group`.
- YAML preset shape maps cleanly to `report.template.handler_config`:
  ```yaml
  name: top-products              →  report.template.name
  model: account.move.line        →  report.template.handler_config.model
  domain: [...]                   →  report.template.handler_config.domain
  group_by: [...]                 →  report.template.handler_config.group_by
  default_limit: 20               →  report.template.handler_config.limit
  ```
- New module `report_analytics` ships the 8 built-in presets as data records.
- One-time CLI command `kctl-odoo analyze import-yaml` migrates user-custom YAML presets.
- `analyze run <preset>` keeps working — under the hood calls `report.template` via api_report.

### Phase U3 — mis_builder bridge (week 7)

- New module: `report_mis_bridge`. `mis.report.instance` extension that also exposes the bridge interface needed by `report.handler.base`.
- `kpi run` continues to work — internally routes through `report.template` + api_report.

### Phase U4 — Dashboard as composite `report.template` (week 8–9)

- Add `section_ids` field to `report.template` referencing sub-templates.
- New handler: `report.handler.composite` — renders by aggregating sub-report results.
- Each dashboard panel becomes a sub-report.template.
- `dashboard summary` becomes `report quick dashboard_summary`.

### Phase U5 — CLI surface cleanup (week 10)

- `analyze run`, `kpi run`, `dashboard summary` become thin aliases that route to `report quick <type>`.
- Update SKILL.md / agent docs to teach the unified surface.
- Aliases removed in a future major version.

### End-state agent playbook (after Phase U5)

```bash
# Discovery
kctl-odoo report types --json

# Any report, any format, one call
kctl-odoo report quick <type_code> --date-from … --date-to … --format markdown
kctl-odoo report quick <type_code> --date-from … --date-to … --format markdown --with-files xlsx,pdf
```

Two commands. One mental model. Maximum determinism.

---

## Section 9 — Testing strategy

### Unit tests — kctl-lib (Phase 0)

```
packages/kctl-lib/tests/test_markdown_report.py
  - test_simple_render_under_limit
  - test_chunking_with_table_boundary
  - test_chunking_never_splits_code_fence
  - test_media_tags_on_final_chunk_only
  - test_no_mdv2_escaping_in_body
  - test_no_gfm_tables_emitted
  - test_empty_report_renders_minimal
  - test_to_json_roundtrip_preserves_structure
  - test_add_media_rejects_nonexistent_path
  - test_add_media_requires_absolute_path

packages/kctl-lib/tests/test_chat_emit.py
  - test_resolve_output_dir_cli_arg_wins
  - test_resolve_output_dir_env_fallback
  - test_resolve_output_dir_default_home_cache
  - test_cleanup_respects_ttl
  - test_cleanup_skips_recent_files_60s_window
  - test_cleanup_failure_non_fatal
  - test_atomic_write_no_partial_files_on_crash
```

### Integration tests — kctl-odoo (Phase 0)

```
packages/kctl-odoo/tests/test_format_markdown.py
  - test_report_quick_profit_loss_markdown_under_4096
  - test_report_quick_with_files_emits_media_tags
  - test_report_quick_with_files_failure_omits_tags_keeps_body
  - test_analyze_run_top_products_markdown_shape
  - test_analyze_run_validate_footer_included
  - test_kpi_run_markdown_includes_vs_target_column
  - test_dashboard_summary_multi_section_render
  - test_doctor_ai_summary_markdown_includes_next_steps
  - test_commands_list_markdown_ready_lists_six_commands
```

### Snapshot tests

Pin exact markdown output for canonical scenarios (P&L, top-products, sales-dashboard KPI, exec-summary). Catches formatting drift across releases.

### Hermes wire test (manual, one-time per upstream bump)

Pipe a known markdown sample through hermes' MarkdownV2 escaper (read from upstream at the pinned ref) and assert no rejections. Catches regressions when `HERMES_UPSTREAM_REF` changes.

### Phase 1 (api_report) test scaffold

```
kodemeio-odoo/src/private/services/api_report/tests/
  test_compute_endpoint.py
  test_render_endpoint.py
  test_markdown_snapshot.py     # server vs CLI parity
  test_auth.py                  # API key, JWT, session
  test_rate_limit.py            # inherited from api_base
```

---

## Section 10 — Agent-facing affordances

### SKILL.md (`packages/kctl-odoo/skills/odoo-admin/SKILL.md`)

Add new section near top:

```markdown
## Chat/Telegram delivery

For ANY report destined for a chat platform (Telegram/Mattermost/WhatsApp via hermes):

    kctl-odoo <command> --format markdown [--with-files xlsx,pdf]

Output is portable markdown + MEDIA tokens that hermes auto-uploads as documents.
Use --format markdown for inline summary; add --with-files for full data.
Never hand-format markdown from --format json.

Supported in v1:
  report quick        --format markdown [--with-files xlsx,pdf]
  analyze run         --format markdown [--with-files xlsx]
  kpi run             --format markdown [--with-files xlsx]
  dashboard summary   --format markdown
  dashboard digest    --format markdown
  doctor ai-summary   --format markdown
```

### New `commands list --markdown-ready` flag

```bash
$ kctl-odoo commands list --markdown-ready --json
[
  {"path": "report quick", "with_files": ["xlsx","pdf"]},
  {"path": "analyze run", "with_files": ["xlsx"]},
  {"path": "kpi run", "with_files": ["xlsx"]},
  {"path": "dashboard summary", "with_files": []},
  {"path": "dashboard digest", "with_files": []},
  {"path": "doctor ai-summary", "with_files": []}
]
```

Discovery in 1 call, ~150 tokens.

### `doctor ai-summary` extension

Add `"markdown_ready": true` to JSON output so agents that call `doctor ai-summary` first immediately know the feature is available on the target instance.

### `commands tree --json` introspection

The existing introspection in kctl-lib auto-exposes `--format` choices per command. After v1, `kctl-odoo commands tree --filter report --json` shows `"format": {"choices": ["pretty","json","csv","yaml","markdown"]}` on supported commands. No additional work — data-driven.

---

## Section 11 — Open questions / out of scope

### Open questions (will resolve during implementation)

1. **Currency rendering in tables.** Do we show full digits (`1,234,567,890`) or abbreviated (`1.23B`)? Lean toward full digits in monospace block (precision matters for finance); abbreviated in bullets only.
2. **CJK column-width handling.** Some product names will be in Chinese/Japanese. Borrow hermes' CJK-aware width calculation from `agent/markdown_tables.py` if available, else use `wcwidth` library.
3. **Whether to ship a `kctl-odoo report send-to-hermes <chat_id>` direct-delivery command.** Out of scope for v1; the agent owns the delivery contract.

### Out of scope (this spec)

- Streaming output (large XLSX as base64 to stdout). Files-on-disk is the only path.
- Per-platform output variants (`--format telegram` vs `--format whatsapp`). Single portable GFM-lite output; hermes adapts.
- Markdown rendering for `migrate`, `audit *`, `compliance`, or other non-report command families. Future scope if needed.
- Bot-side commands (kctl-odoo invoked from within the agent's tool calls rather than via shell). The agent calls kctl-odoo as a subprocess; that's the contract.

---

## Section 12 — Rollout

### v1 (Phase 0) — 2 weeks

- Week 1: kctl-lib MarkdownReport + chat_emit + tests
- Week 2: kctl-odoo command wiring (6 commands) + tests + SKILL.md
- Hermes: one-line `hermes-init.sh` change
- Verification: send a P&L to Telegram via hermes, confirm markdown + 2 attachments arrive
- Release: kctl-lib 0.5.0 + kctl-odoo 0.2.0

### v1.1 (Phase 1) — 2 weeks after v1

- Week 3: `api_report` module skeleton (manifest, models, scaffold)
- Week 4: markdown_renderer mirror + compute orchestrator + tests
- CLI fast-path detection
- Release: kctl-odoo 0.3.0 + `api_report` 1.0

### Unification Phases U2–U5 — quarterly cadence

Each phase is independently shippable. Each unification step preserves backward compat via aliases. No big-bang migrations.

---

## Section 13 — Success criteria

**v1 ships when:**

- [ ] `kctl-lib` test suite passes (>= 20 new tests)
- [ ] `kctl-odoo` test suite passes (>= 9 new integration tests)
- [ ] Hermes-agent can deliver a P&L (markdown + XLSX + PDF) end-to-end via Telegram, verified manually with `idtpp-tpp-odoo-erp` profile
- [ ] Mattermost test delivery succeeds when hermes' Mattermost inbound lands (out-of-band verification — depends on hermes Phase 2)
- [ ] No regressions in existing `--format pretty/json/csv/yaml` paths
- [ ] SKILL.md updated; agents discover `--markdown-ready` flag in `commands list`
- [ ] Existing markdown commands (`diagnose`, `accurate parity`, etc.) untouched — they keep working

**v1.1 ships when:**

- [ ] `api_report` test suite passes
- [ ] Server-vs-CLI snapshot tests pass byte-identical
- [ ] Round-trip time for `report quick profit_loss` drops from ~200ms (current 3-RPC) to ~80ms (single HTTP)
- [ ] CLI fast-path detection works against fresh Odoo (no `api_report`) and against `api_report`-enabled instance — same output, no user-visible difference
