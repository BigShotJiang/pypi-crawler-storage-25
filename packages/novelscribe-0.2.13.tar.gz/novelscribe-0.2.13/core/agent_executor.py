"""Agent executor for running agents with LLM integration."""

import re
from pathlib import Path
from typing import Any, Dict, Optional

from .agent import Agent, AgentContext, AgentResult
from .llm_client import LLMConfig, MultiLLMClient
from .storage import StorageBackend
from .token_estimator import TokenEstimator


class AgentExecutor:
    """Execute agents with LLM client integration."""

    def __init__(
        self,
        llm_client: MultiLLMClient,
        storage: StorageBackend,
        work_dir: Optional[str | Path] = None,
        context_bus: Optional[Any] = None,
    ):
        """Initialize agent executor.

        Args:
            llm_client: LLM client for agent execution
            storage: Storage backend for file operations
            work_dir: Working directory for file operations
            context_bus: Optional ContextBus for context assembly
        """
        self.llm_client = llm_client
        self.storage = storage
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.context_bus = context_bus

    def execute(
        self, agent: Agent, context: AgentContext, input_data: Dict[str, Any]
    ) -> AgentResult:
        """Execute an agent with given context and input.

        Args:
            agent: Agent to execute
            context: Execution context
            input_data: Input data for agent

        Returns:
            Agent execution result
        """
        try:
            user_prompt = self._construct_prompt(agent, context, input_data)
            system_prompt = getattr(agent, "system_prompt", "") or ""

            llm_config = LLMConfig(
                provider=context.config.get("provider", "openai"),
                model=context.config.get("model", "gpt-4o"),
                temperature=context.config.get("temperature", 0.7),
                max_tokens=context.config.get("max_tokens", 4000),
            )

            response = self.llm_client.generate(
                system_prompt=system_prompt, user_prompt=user_prompt
            )

            output_files = self._save_outputs(agent, context, response)

            # Use TokenEstimator for accurate token counting
            input_tokens = TokenEstimator.estimate_tokens(user_prompt)

            return AgentResult(
                agent_name=agent.name,
                success=True,
                output=response.content if hasattr(response, "content") else str(response),
                output_files=output_files,
                metadata={
                    "provider": llm_config.provider,
                    "model": llm_config.model,
                    "input_tokens": input_tokens,
                },
            )

        except Exception as e:
            return AgentResult(agent_name=agent.name, success=False, error=str(e))

    def execute_with_bus(
        self,
        agent: Agent,
        provider: str,
        model_config: Dict[str, Any],
        project_name: str,
    ) -> AgentResult:
        """Execute an agent using ContextBus for context assembly.

        Args:
            agent: Agent to execute
            provider: LLM provider name
            model_config: Model configuration dict
            project_name: Project name for output saving

        Returns:
            Agent execution result
        """
        if self.context_bus is None:
            return AgentResult(
                agent_name=agent.name,
                success=False,
                error="ContextBus not configured",
            )
        try:
            context_str = self.context_bus.build_context(
                agent_name=agent.name,
                provider=provider,
                model_config=model_config,
            )
            system_prompt = getattr(agent, "system_prompt", "") or ""
            user_prompt = f"{context_str}\n\n## Task\n{agent.instructions}"

            llm_config = LLMConfig(
                provider=provider,
                model=model_config.get("model", "gpt-4o"),
                temperature=model_config.get("temperature", 0.7),
                max_tokens=model_config.get("max_tokens", 4000),
            )

            response = self.llm_client.generate(
                system_prompt=system_prompt, user_prompt=user_prompt
            )

            input_tokens = TokenEstimator.estimate_tokens(user_prompt)

            output_files = self._save_outputs_simple(agent.name, project_name, response)

            return AgentResult(
                agent_name=agent.name,
                success=True,
                output=response.content if hasattr(response, "content") else str(response),
                output_files=output_files,
                metadata={
                    "provider": llm_config.provider,
                    "model": llm_config.model,
                    "input_tokens": input_tokens,
                    "context_bus": True,
                },
            )

        except Exception as e:
            return AgentResult(agent_name=agent.name, success=False, error=str(e))

    def _save_outputs_simple(self, agent_name: str, project_name: str, response: Any) -> list[str]:
        """Save agent outputs to files (bus-based path)."""
        output_files = []
        project_dir = self.work_dir / project_name

        if not project_dir.exists():
            project_dir.mkdir(parents=True, exist_ok=True)

        reports_dir = project_dir / "reports"
        if not reports_dir.exists():
            reports_dir.mkdir(exist_ok=True)

        report_file = reports_dir / f"{agent_name}_output.md"
        content = response.content if hasattr(response, "content") else str(response)

        try:
            self.storage.write_markdown(str(report_file), content)
            output_files.append(str(report_file))
        except Exception:
            pass

        return output_files

    def _construct_prompt(
        self, agent: Agent, context: AgentContext, input_data: Dict[str, Any]
    ) -> str:
        """Construct prompt for agent execution.

        Args:
            agent: Agent being executed
            context: Execution context
            input_data: Input data for agent

        Returns:
            Constructed prompt string
        """
        instructions = agent.instructions

        prompt = f"# {agent.name}\n\n"
        prompt += f"## Role\n{agent.description}\n\n"

        prompt += "## Context\n"
        prompt += f"Project: {context.project_name}\n\n"

        if input_data:
            prompt += "## Input\n"
            for key, value in input_data.items():
                if value:
                    prompt += f"### {key}\n{value}\n\n"

        if context.previous_outputs:
            prompt += "## Previous Outputs\n"
            for key, value in context.previous_outputs.items():
                prompt += f"### {key}\n{value}\n\n"

        prompt += f"## Instructions\n{instructions}\n\n"

        prompt += "## Output Format\n"
        if agent.output_schema:
            for schema in agent.output_schema:
                prompt += f"- {schema}\n"
        else:
            prompt += "- Provide clear, structured output\n"

        return prompt

    def _save_outputs(self, agent: Agent, context: AgentContext, response: str) -> list[str]:
        """Save agent outputs to files.

        Args:
            agent: Agent being executed
            context: Execution context
            response: LLM response content

        Returns:
            List of saved file paths
        """
        output_files = []

        project_dir = self.work_dir / context.project_name

        if not project_dir.exists():
            project_dir.mkdir(parents=True, exist_ok=True)

        reports_dir = project_dir / "reports"
        if not reports_dir.exists():
            reports_dir.mkdir(exist_ok=True)

        report_file = reports_dir / f"{agent.name}_output.md"

        try:
            self.storage.write_markdown(str(report_file), response)
            output_files.append(str(report_file))
        except Exception:
            pass

        return output_files

    def construct_system_message(self, agent: Agent) -> str:
        """Construct system message from agent instructions.

        Args:
            agent: Agent to construct system message for

        Returns:
            System message string
        """
        system_msg = f"You are {agent.name}.\n\n"
        system_msg += f"{agent.description}\n\n"
        system_msg += "Follow the provided instructions carefully."
        return system_msg

    def extract_output_variables(self, response: str, agent: Agent) -> Dict[str, str]:
        """Extract output variables from agent response.

        Args:
            response: LLM response content
            agent: Agent that generated response

        Returns:
            Dictionary of output variables
        """
        outputs = {}

        for schema in agent.output_schema:
            pattern = rf"###\s*{re.escape(schema)}\s*\n+(.*?)(?=###\s*\w+|\Z)"
            match = re.search(pattern, response, re.DOTALL | re.MULTILINE)

            if match:
                outputs[schema] = match.group(1).strip()
            else:
                outputs[schema] = response

        if not outputs:
            outputs["output"] = response

        return outputs
