"""Standalone confidence calculator for checkpoint proposals.

Extracts factor-based confidence scoring from checkpoint_orchestrator.py
into a dedicated module with detailed per-factor explanations.
"""

import logging
from dataclasses import dataclass

from pydantic import BaseModel

from core.checkpoint_proposal import ConfidenceBreakdown, PlanContent


class ConfidenceFactorDetail(BaseModel):
    """Detailed information about a single confidence factor."""

    name: str
    weight: float
    score: float  # 0.0 - 1.0
    explanation: str


@dataclass
class ConfidenceResult:
    """Full result of confidence calculation with factor details."""

    factors: list[ConfidenceFactorDetail]
    total: float
    explanation: str

    @property
    def breakdown(self) -> ConfidenceBreakdown:
        """Convert to ConfidenceBreakdown for backward compatibility."""
        factor_map = {f.name.lower(): f.score for f in self.factors}
        return ConfidenceBreakdown(
            coherence=factor_map.get("coherence", 0.75),
            character=factor_map.get("character", 0.7),
            pacing=factor_map.get("pacing", 0.85),
            originality=factor_map.get("originality", 0.75),
            completeness=factor_map.get("completeness", 0.75),
        )


# Factor weights matching ConfidenceBreakdown.total weights exactly
_FACTOR_WEIGHTS: dict[str, float] = {
    "coherence": 0.30,
    "character": 0.25,
    "pacing": 0.20,
    "originality": 0.15,
    "completeness": 0.10,
}

# Pacing score lookup
_PACING_SCORES: dict[str, float] = {
    "slow": 0.8,
    "moderate": 0.9,
    "fast": 0.85,
}


class ConfidenceCalculator:
    """Calculates confidence scores for checkpoint proposals.

    Scores proposals across five weighted factors:
    coherence (30%), character (25%), pacing (20%),
    originality (15%), completeness (10%).
    """

    def __init__(self) -> None:
        """Initialize confidence calculator."""
        self.logger = logging.getLogger("scribe")

    def calculate(self, plan: PlanContent, phase: str) -> ConfidenceBreakdown:
        """Calculate confidence breakdown for a plan.

        Args:
            plan: The proposal plan content to score.
            phase: Current generation phase.

        Returns:
            ConfidenceBreakdown with per-factor scores.
        """
        result = self.calculate_detailed(plan, phase)
        return result.breakdown

    def calculate_detailed(self, plan: PlanContent, phase: str) -> ConfidenceResult:
        """Calculate confidence with full factor details and explanations.

        Args:
            plan: The proposal plan content to score.
            phase: Current generation phase.

        Returns:
            ConfidenceResult with factors, total, and summary explanation.
        """
        factors = self.get_factor_details(plan, phase)
        total = sum(f.score * f.weight for f in factors)

        top_factor = max(factors, key=lambda f: f.score * f.weight)
        low_factor = min(factors, key=lambda f: f.score * f.weight)

        explanation = (
            f"Confidence {total:.0%} driven by strong {top_factor.name} "
            f"({top_factor.score:.0%}). Weakest: {low_factor.name} "
            f"({low_factor.score:.0%})."
        )

        return ConfidenceResult(
            factors=factors,
            total=total,
            explanation=explanation,
        )

    def get_factor_details(self, plan: PlanContent, phase: str) -> list[ConfidenceFactorDetail]:
        """Get detailed scoring for each confidence factor.

        Args:
            plan: The proposal plan content to score.
            phase: Current generation phase.

        Returns:
            List of ConfidenceFactorDetail with score and explanation per factor.
        """
        return [
            ConfidenceFactorDetail(
                name="coherence",
                weight=_FACTOR_WEIGHTS["coherence"],
                score=self._score_coherence(plan),
                explanation=self._explain_coherence(plan),
            ),
            ConfidenceFactorDetail(
                name="character",
                weight=_FACTOR_WEIGHTS["character"],
                score=self._score_character(plan),
                explanation=self._explain_character(plan),
            ),
            ConfidenceFactorDetail(
                name="pacing",
                weight=_FACTOR_WEIGHTS["pacing"],
                score=self._score_pacing(plan),
                explanation=self._explain_pacing(plan),
            ),
            ConfidenceFactorDetail(
                name="originality",
                weight=_FACTOR_WEIGHTS["originality"],
                score=self._score_originality(plan),
                explanation=self._explain_originality(plan),
            ),
            ConfidenceFactorDetail(
                name="completeness",
                weight=_FACTOR_WEIGHTS["completeness"],
                score=self._score_completeness(plan),
                explanation=self._explain_completeness(plan),
            ),
        ]

    # --- Scoring methods (must match orchestrator inline logic exactly) ---

    def _score_coherence(self, plan: PlanContent) -> float:
        """Score story coherence based on scene count."""
        if plan.scenes:
            return min(1.0, len(plan.scenes) / 4 * 0.3 + 0.7)
        return 0.75

    def _score_character(self, plan: PlanContent) -> float:
        """Score character development based on POV presence."""
        return 0.85 if plan.pov else 0.7

    def _score_pacing(self, plan: PlanContent) -> float:
        """Score pacing based on declared pacing value."""
        return _PACING_SCORES.get(plan.pacing, 0.85)

    def _score_originality(self, plan: PlanContent) -> float:
        """Score originality based on foreshadowing presence."""
        return 0.8 if plan.foreshadowing else 0.75

    def _score_completeness(self, plan: PlanContent) -> float:
        """Score completeness based on word estimate."""
        if plan.word_estimate:
            return min(1.0, plan.word_estimate / 3000 * 0.3 + 0.7)
        return 0.75

    # --- Explanation generators ---

    def _explain_coherence(self, plan: PlanContent) -> str:
        """Generate explanation for coherence score."""
        if not plan.scenes:
            return "No scenes defined; defaulting to moderate confidence."
        count = len(plan.scenes)
        if count >= 4:
            return f"{count} scenes defined — strong structural coherence."
        return f"{count} scenes defined — could benefit from more structure."

    def _explain_character(self, plan: PlanContent) -> str:
        """Generate explanation for character score."""
        if plan.pov:
            return f"POV character '{plan.pov}' provides narrative anchor."
        return "No POV character specified; narrative focus may be unclear."

    def _explain_pacing(self, plan: PlanContent) -> str:
        """Generate explanation for pacing score."""
        pacing = plan.pacing or "unspecified"
        descriptions = {
            "slow": "deliberate, immersive rhythm",
            "moderate": "balanced rhythm",
            "fast": "dynamic, high-energy rhythm",
        }
        desc = descriptions.get(pacing, "default balanced rhythm")
        return f"Pacing set to '{pacing}' — {desc}."

    def _explain_originality(self, plan: PlanContent) -> str:
        """Generate explanation for originality score."""
        if plan.foreshadowing:
            return f"Foreshadowing element present: '{plan.foreshadowing[:50]}...'."
        return "No foreshadowing elements identified."

    def _explain_completeness(self, plan: PlanContent) -> str:
        """Generate explanation for completeness score."""
        if plan.word_estimate:
            if plan.word_estimate >= 3000:
                return f"Word estimate {plan.word_estimate:,} indicates thorough planning."
            return f"Word estimate {plan.word_estimate:,} — could expand further."
        return "No word estimate provided."


def create_confidence_calculator() -> ConfidenceCalculator:
    """Factory function to create a ConfidenceCalculator.

    Returns:
        ConfidenceCalculator instance.
    """
    return ConfidenceCalculator()
