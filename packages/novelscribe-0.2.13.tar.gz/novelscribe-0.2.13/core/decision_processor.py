"""Decision processor for handling human decisions at checkpoints."""

import logging
from typing import Any, Optional

from core.checkpoint_proposal import (
    CheckpointDecision,
    CheckpointProposal,
    CheckpointResponse,
    DecisionType,
)


class DecisionValidationError(Exception):
    """Raised when decision validation fails."""

    pass


class DecisionProcessor:
    """Processes human decisions at checkpoints."""

    def __init__(self):
        """Initialize decision processor."""
        self.logger = logging.getLogger("scribe")

    def process(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process a human decision and return AI response.

        Args:
            decision: Human's decision
            proposal: Current proposal

        Returns:
            CheckpointResponse with AI's response
        """
        if decision.decision_type == DecisionType.APPROVE:
            return self._process_approve(decision, proposal)
        elif decision.decision_type == DecisionType.MODIFY:
            return self._process_modify(decision, proposal)
        elif decision.decision_type == DecisionType.REJECT:
            return self._process_reject(decision, proposal)
        elif decision.decision_type == DecisionType.GUIDANCE:
            return self._process_guidance(decision, proposal)
        elif decision.decision_type == DecisionType.ASK:
            return self._process_ask(decision, proposal)
        else:
            raise ValueError(f"Unknown decision type: {decision.decision_type}")

    def _process_approve(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process approval decision."""
        return CheckpointResponse(
            decision=decision,
            applied=True,
            adjustments_made=[],
            explanation="Proposal approved. Continuing with current plan.",
        )

    def _process_modify(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process modification decision."""
        if not decision.modified_content:
            return CheckpointResponse(
                decision=decision,
                applied=False,
                explanation="No modifications provided.",
            )

        adjustments = self._compute_adjustments(proposal.plan.__dict__, decision.modified_content)

        modified_plan = proposal.plan.__class__(**decision.modified_content)
        modified_proposal = CheckpointProposal(
            checkpoint_id=proposal.checkpoint_id,
            phase=proposal.phase,
            plan=modified_plan,
            confidence=proposal.confidence,
            reasoning=f"Modified based on human feedback: {adjustments}",
            reasoning_trace=[f"Human modified: {k}" for k in adjustments.keys()],
            alternatives=proposal.alternatives,
            metadata=proposal.metadata,
        )

        return CheckpointResponse(
            decision=decision,
            applied=True,
            adjustments_made=list(adjustments.keys()),
            modified_proposal=modified_proposal,
            explanation=f"Applied {len(adjustments)} modification(s).",
        )

    def _process_reject(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process rejection decision - regenerate required."""
        return CheckpointResponse(
            decision=decision,
            applied=False,
            explanation="Proposal rejected. Regeneration required with new constraints.",
        )

    def _process_guidance(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process guidance decision - AI interprets and adjusts."""
        if not decision.guidance_text:
            return CheckpointResponse(
                decision=decision,
                applied=False,
                explanation="No guidance provided.",
            )

        adjustments = self._interpret_guidance(proposal, decision.guidance_text)
        explanation = f"Interpreted guidance: {decision.guidance_text}. "

        if adjustments:
            modified_plan = self._apply_guidance(proposal.plan, adjustments)
            modified_proposal = CheckpointProposal(
                checkpoint_id=proposal.checkpoint_id,
                phase=proposal.phase,
                plan=modified_plan,
                confidence=proposal.confidence * 0.95,
                reasoning=f"Adjusted based on human guidance: {adjustments}",
                reasoning_trace=[
                    f"Guidance received: {decision.guidance_text}",
                    f"Adjustments: {adjustments}",
                ],
                alternatives=proposal.alternatives,
                metadata=proposal.metadata,
            )
            explanation += f"Applied {len(adjustments)} adjustment(s)."
        else:
            modified_proposal = None
            explanation += "Guidance noted but no direct adjustments applied."

        return CheckpointResponse(
            decision=decision,
            applied=bool(adjustments),
            adjustments_made=list(adjustments.keys()) if adjustments else [],
            modified_proposal=modified_proposal,
            explanation=explanation,
        )

    def _process_ask(
        self,
        decision: CheckpointDecision,
        proposal: CheckpointProposal,
    ) -> CheckpointResponse:
        """Process question - provide explanation."""
        if not decision.question:
            return CheckpointResponse(
                decision=decision,
                applied=False,
                explanation="No question provided.",
            )

        answer = self._generate_answer(proposal, decision.question)

        return CheckpointResponse(
            decision=decision,
            applied=True,
            explanation=answer,
        )

    def _compute_adjustments(
        self, original: dict[str, Any], modified: dict[str, Any]
    ) -> dict[str, tuple[Any, Any]]:
        """Compute differences between original and modified content.

        Args:
            original: Original content dict
            modified: Modified content dict

        Returns:
            Dict of field_name -> (old_value, new_value)
        """
        adjustments = {}
        for key, new_value in modified.items():
            if key in original and original[key] != new_value:
                adjustments[key] = (original[key], new_value)
        return adjustments

    def _interpret_guidance(self, proposal: CheckpointProposal, guidance: str) -> dict[str, Any]:
        """Interpret human guidance and determine adjustments.

        Args:
            proposal: Current proposal
            guidance: Human's guidance text

        Returns:
            Dict of adjustments to apply
        """
        adjustments: dict[str, Any] = {}

        guidance_lower = guidance.lower()

        if "pov" in guidance_lower or "point of view" in guidance_lower:
            for alt in proposal.alternatives:
                if "pov" in alt.tradeoff_explanation.lower():
                    adjustments["pov"] = alt.plan.pov
                    break

        if "darker" in guidance_lower or "more tension" in guidance_lower:
            if hasattr(proposal.plan, "pacing"):
                adjustments["pacing"] = "fast"

        if (
            "slower" in guidance_lower
            or "slow down" in guidance_lower
            or "more mystery" in guidance_lower
        ):
            if hasattr(proposal.plan, "pacing"):
                adjustments["pacing"] = "slow"

        return adjustments

    def _apply_guidance(self, plan: Any, adjustments: dict[str, Any]) -> Any:
        """Apply guidance adjustments to plan.

        Args:
            plan: Current plan
            adjustments: Adjustments to apply

        Returns:
            Modified plan
        """
        plan_dict = plan.__dict__.copy()
        plan_dict.update(adjustments)
        return plan.__class__(**plan_dict)

    def _generate_answer(self, proposal: CheckpointProposal, question: str) -> str:
        """Generate answer to human question about proposal.

        Args:
            proposal: Current proposal
            question: Human's question

        Returns:
            Answer string
        """
        question_lower = question.lower()

        if "why" in question_lower and ("this" in question_lower or "plan" in question_lower):
            return self._explain_why_proposal(proposal)

        if "why not" in question_lower or "why didn't" in question_lower:
            return self._explain_why_not(proposal, question)

        if "what if" in question_lower:
            return self._explain_what_if(proposal, question)

        if "alternative" in question_lower or "compare" in question_lower:
            return self._compare_alternatives(proposal)

        return f"Reasoning: {proposal.reasoning}"

    def _explain_why_proposal(self, proposal: CheckpointProposal) -> str:
        """Explain why this proposal was chosen."""
        lines = [f"AI Confidence: {proposal.get_confidence_percentage()}"]
        lines.append(f"Reasoning: {proposal.reasoning}")

        if proposal.reasoning_trace:
            lines.append("")
            lines.append("Reasoning trace:")
            for trace in proposal.reasoning_trace[-3:]:
                lines.append(f"  - {trace}")

        return "\n".join(lines)

    def _explain_why_not(self, proposal: CheckpointProposal, question: str) -> str:
        """Explain why an alternative was not chosen."""
        for alt in proposal.alternatives:
            if alt.option_id.lower() in question.lower():
                lines = [
                    f"Alternative Option {alt.option_id} "
                    f"(confidence: {alt.get_confidence_percentage()})",
                    f"Tradeoff: {alt.tradeoff_explanation}",
                ]
                if alt.rejection_reasons:
                    lines.append("Rejection reasons:")
                    for reason in alt.rejection_reasons:
                        lines.append(f"  - {reason}")
                return "\n".join(lines)

        return "Alternative not found in proposal."

    def _explain_what_if(self, proposal: CheckpointProposal, question: str) -> str:
        """Explain what would change under different conditions."""
        return (
            f"What-if analysis requested for: {question}\n"
            f"Suggested approach: Review alternatives and request modified version."
        )

    def _compare_alternatives(self, proposal: CheckpointProposal) -> str:
        """Compare all alternatives."""
        if not proposal.alternatives:
            return "No alternatives available."

        lines = ["Alternative Comparison:"]
        for alt in proposal.alternatives:
            lines.append(
                f"  {alt.option_id}: {alt.get_confidence_percentage()} - {alt.tradeoff_explanation}"
            )
        return "\n".join(lines)

    def validate_modification(self, modified_content: dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Validate modification content.

        Args:
            modified_content: Content to validate

        Returns:
            (is_valid, error_message)
        """
        if not modified_content:
            return False, "Empty modification"

        required_fields = ["title"]
        for field in required_fields:
            if field not in modified_content:
                return False, f"Missing required field: {field}"

        return True, None
