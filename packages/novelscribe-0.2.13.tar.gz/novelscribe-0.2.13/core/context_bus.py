"""ContextBus — unified facade for the Context Bus system.

Ties together ContextStore, BudgetAllocator, ContextAssembler, and
ContextCompressor into a single public API for the pipeline.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Union

from core.context_assembly import ContextAssembler
from core.context_compressor import CompressionResult, ContextCompressor
from core.context_schema import (
    AgentContextSchema,
    BudgetAllocator,
    ContextNeed,
)
from core.context_store import ContextSnapshot, ContextStore, ContextStoreConfig


class ContextBus:
    """Unified context management for the NovelScribe pipeline.

    Usage::

        bus = ContextBus(project_path, llm_client, agent_loader)

        # Workflow executor ingests outputs after each step
        bus.ingest("outline", content, source_agent="outline_agent")
        bus.ingest("chapter", content, source_agent="writer_agent",
                   chapter_number=5)

        # Agent executor requests context before each call
        context = bus.build_context(
            agent_name="writer_agent",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        # context is a str guaranteed to fit the token budget
    """

    def __init__(
        self,
        project_path: Path,
        llm_client: Optional[Any] = None,
        agent_loader: Optional[Any] = None,
        store_config: Optional[ContextStoreConfig] = None,
    ):
        self.project_path = Path(project_path)
        self.store = ContextStore(self.project_path / "context", config=store_config)
        self.allocator = BudgetAllocator()
        self.assembler = ContextAssembler()
        self.compressor = ContextCompressor(llm_client=llm_client)
        self.agent_loader = agent_loader

    def ingest(
        self,
        artifact_type: str,
        content: str,
        source_agent: str,
        chapter_number: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Ingest a context artifact. Returns artifact_id."""
        return self.store.ingest(
            artifact_type=artifact_type,
            content=content,
            source_agent=source_agent,
            chapter_number=chapter_number,
            metadata=metadata,
        )

    def build_context(
        self,
        agent_name: str,
        provider: Union[str, Any],
        model_config: Dict[str, Any],
    ) -> str:
        """Build context for an agent call.

        1. Load agent's context_needs schema
        2. Allocate token budget
        3. Assemble blocks from store
        4. Compress to fit
        5. Return context string
        """
        schema = self._load_schema(agent_name)
        max_tokens = model_config.get("max_tokens")
        budget = self.allocator.allocate(provider, max_tokens=max_tokens, schema=schema)
        blocks = self.assembler.assemble(schema, budget, self.store)
        result = self.compressor.compress(blocks, budget)
        return result.context_str

    def build_context_with_metadata(
        self,
        agent_name: str,
        provider: Union[str, Any],
        model_config: Dict[str, Any],
    ) -> CompressionResult:
        """Build context and return full CompressionResult with metadata."""
        schema = self._load_schema(agent_name)
        max_tokens = model_config.get("max_tokens")
        budget = self.allocator.allocate(provider, max_tokens=max_tokens, schema=schema)
        blocks = self.assembler.assemble(schema, budget, self.store)
        return self.compressor.compress(blocks, budget)

    def save_snapshot(
        self,
        run_id: str,
        phase: str,
        step: str,
        total_chapters_completed: int = 0,
    ) -> Optional[ContextSnapshot]:
        """Save current state for resume."""
        return self.store.save_snapshot(run_id, phase, step, total_chapters_completed)

    def restore_snapshot(self, run_id: Optional[str] = None) -> Optional[ContextSnapshot]:
        """Restore from snapshot (latest if no run_id)."""
        return self.store.restore_snapshot(run_id)

    def _load_schema(self, agent_name: str) -> AgentContextSchema:
        """Load context_needs from agent definition, or return default."""
        if self.agent_loader is not None:
            try:
                agent = self.agent_loader.reload_agent(agent_name)
                if agent is not None and agent.context_needs is not None:
                    return AgentContextSchema.from_dict(agent.context_needs)
            except Exception:
                pass
        return self._default_schema()

    @staticmethod
    def _default_schema() -> AgentContextSchema:
        """Fallback schema for agents without context_needs declarations."""
        return AgentContextSchema(
            required=[
                ContextNeed(artifact_type="meta"),
                ContextNeed(artifact_type="outline"),
            ],
            optional=[
                ContextNeed(artifact_type="summary", scope="recent", recent_count=2),
            ],
        )
