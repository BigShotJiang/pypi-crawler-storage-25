"""Workflow executor for running complete workflows."""

import logging
from pathlib import Path
from typing import Any, Dict, Optional

from .step_executor import StepExecutor
from .workflow_loader import WorkflowLoader


class WorkflowExecutor:
    """Execute complete workflows with step orchestration."""

    def __init__(
        self,
        workflows_dir: str | Path,
        agent_integration,
        storage,
        git_manager,
        work_dir: str | Path = None,
        context_bus: Optional[Any] = None,
    ):
        """Initialize workflow executor.

        Args:
            workflows_dir: Directory containing workflow definitions
            agent_integration: Agent system integration
            storage: Storage backend
            git_manager: Git manager
            work_dir: Working directory
            context_bus: Optional ContextBus for artifact ingestion
        """
        self.workflows_dir = Path(workflows_dir)
        self.workflow_loader = WorkflowLoader(self.workflows_dir)
        self.step_executor = StepExecutor(
            agent_integration=agent_integration,
            storage=storage,
            git_manager=git_manager,
            work_dir=work_dir,
        )
        self.context_bus = context_bus
        self.logger = logging.getLogger("workflow_executor")

    def execute_workflow(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute a workflow.

        Args:
            workflow_name: Name of workflow to execute
            project_name: Project name
            variables: Workflow variables
            config: LLM configuration

        Returns:
            Workflow execution result
        """
        try:
            workflow = self.workflow_loader.load_workflow(
                self.workflows_dir / f"{workflow_name}.yaml"
            )

            self.logger.info(f"Executing workflow: {workflow_name}")

            merged_variables = {**workflow.variables, **variables}

            step_outputs = {}
            executed_steps = []
            failed_steps = []

            for step in workflow.steps:
                self.logger.info(f"Executing step {step.step}: {step.name}")

                result = self.step_executor.execute_step(
                    step=step,
                    project_name=project_name,
                    variables=merged_variables,
                    step_outputs=step_outputs,
                    config=config,
                )

                executed_steps.append(result)

                if result.get("skipped"):
                    continue

                if not result.get("success"):
                    failed_steps.append(result)
                    self.logger.error(f"Step failed: {step.name}")
                else:
                    step_outputs[step.name] = result.get("output", {})
                    if self.context_bus is not None and step.context_type:
                        output_content = result.get("output", {})
                        if isinstance(output_content, str):
                            content = output_content
                        elif isinstance(output_content, dict):
                            content = "\n".join(str(v) for v in output_content.values())
                        else:
                            content = str(output_content)
                        if content:
                            self.context_bus.ingest(
                                artifact_type=step.context_type,
                                content=content,
                                source_agent=step.agent or step.name,
                                chapter_number=merged_variables.get("chapter_number"),
                            )

            all_success = len(failed_steps) == 0

            return {
                "workflow": workflow_name,
                "success": all_success,
                "executed_steps": executed_steps,
                "failed_steps": failed_steps,
                "step_outputs": step_outputs,
            }

        except Exception as e:
            self.logger.error(f"Workflow execution error: {e}")

            return {
                "workflow": workflow_name,
                "success": False,
                "error": str(e),
                "executed_steps": [],
                "failed_steps": [],
                "step_outputs": {},
            }

    def execute_workflow_with_loop(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
        config: Dict[str, Any],
        loop_range: range,
    ) -> Dict[str, Any]:
        """Execute workflow in a loop.

        Args:
            workflow_name: Name of workflow to execute
            project_name: Project name
            variables: Workflow variables
            config: LLM configuration
            loop_range: Range for loop iterations

        Returns:
            Workflow execution result
        """
        self.logger.info(
            f"Executing workflow {workflow_name} in loop: {len(loop_range)} iterations"
        )

        all_results = []
        failed_iterations = []

        for i in loop_range:
            self.logger.info(f"Loop iteration {i}")

            loop_variables = {**variables, "iteration": i}

            result = self.execute_workflow(
                workflow_name=workflow_name,
                project_name=project_name,
                variables=loop_variables,
                config=config,
            )

            all_results.append(result)

            if not result.get("success"):
                failed_iterations.append(i)
                self.logger.error(f"Iteration {i} failed")

        all_success = len(failed_iterations) == 0

        return {
            "workflow": workflow_name,
            "success": all_success,
            "iterations": len(loop_range),
            "failed_iterations": failed_iterations,
            "results": all_results,
        }

    def list_workflows(self) -> Dict[str, str]:
        """List all available workflows.

        Returns:
            Dictionary mapping workflow names to descriptions
        """
        workflows = self.workflow_loader.load_all_workflows()

        return {workflow.name: workflow.description for workflow in workflows}

    def get_workflow_info(self, workflow_name: str) -> Dict[str, Any]:
        """Get workflow information.

        Args:
            workflow_name: Name of workflow

        Returns:
            Workflow information
        """
        try:
            workflow = self.workflow_loader.load_workflow(
                self.workflows_dir / f"{workflow_name}.yaml"
            )

            return {
                "name": workflow.name,
                "version": workflow.version,
                "description": workflow.description,
                "variables": workflow.variables,
                "step_count": len(workflow.steps),
            }

        except Exception:
            return {}
