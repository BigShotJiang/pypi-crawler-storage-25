"""Workflow loader for parsing YAML workflow definitions."""

from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, Field

from .language_config import LanguageCode


class OnFailure(str, Enum):
    """On failure behavior."""

    CONTINUE = "continue"
    STOP = "stop"


class WorkflowStep(BaseModel):
    """Workflow step definition."""

    step: int = Field(..., description="Step number")
    name: str = Field(..., description="Step name")
    agent: Optional[str] = Field(None, description="Agent to execute")
    workflow: Optional[str] = Field(None, description="Nested workflow to execute")
    action: Optional[str] = Field(None, description="System action to execute")
    input: Dict[str, Any] = Field(default_factory=dict, description="Input variables")
    output: Dict[str, Any] = Field(default_factory=dict, description="Output mappings")
    condition: Optional[str] = Field(None, description="Conditional execution")
    on_failure: OnFailure = Field(default=OnFailure.STOP, description="Failure behavior")
    context_type: Optional[str] = Field(None, description="Context artifact type for bus ingestion")


class Workflow(BaseModel):
    """Workflow definition."""

    name: str = Field(..., description="Workflow name")
    version: str = Field(default="1.0.0", description="Workflow version")
    description: str = Field(..., description="Workflow description")
    variables: Dict[str, Any] = Field(default_factory=dict, description="Workflow variables")
    steps: List[WorkflowStep] = Field(default_factory=list, description="Workflow steps")
    file_path: Optional[str] = Field(None, description="Path to workflow file")


class WorkflowLoader:
    """Load workflow definitions from YAML files."""

    def __init__(self, workflows_dir: str | Path, language: Optional[LanguageCode] = None):
        """Initialize workflow loader.

        Args:
            workflows_dir: Directory containing workflow files
            language: Language code for workflow files (default: en for backward compatibility)
        """
        self.workflows_dir = Path(workflows_dir)
        self.language = language or LanguageCode.EN

    def load_workflow(self, file_path: str | Path) -> Workflow:
        """Load a single workflow from YAML file.

        Args:
            file_path: Path to workflow file

        Returns:
            Workflow object

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"Workflow file not found: {file_path}")

        content = file_path.read_text(encoding="utf-8")

        return self.parse_workflow(content, file_path)

    def parse_workflow(self, content: str, file_path: Optional[Path] = None) -> Workflow:
        """Parse workflow from YAML content.

        Args:
            content: YAML content
            file_path: Optional file path for reference

        Returns:
            Workflow object

        Raises:
            ValueError: If content format is invalid
        """
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML: {e}")

        if not isinstance(data, dict):
            raise ValueError("Workflow must be a dictionary")

        required_fields = ["name", "description"]
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")

        steps_data = data.get("steps", [])
        steps = []

        for step_data in steps_data:
            if not isinstance(step_data, dict):
                continue

            step_data = self._parse_step_variables(step_data)
            step = WorkflowStep(**step_data)
            steps.append(step)

        workflow = Workflow(
            name=data["name"],
            version=data.get("version", "1.0.0"),
            description=data["description"],
            variables=data.get("variables", {}),
            steps=steps,
            file_path=str(file_path) if file_path else None,
        )

        return workflow

    def _parse_step_variables(self, step_data: Dict[str, Any]) -> Dict[str, Any]:
        """Parse and validate step data.

        Args:
            step_data: Raw step data

        Returns:
            Parsed step data
        """
        parsed: Dict[str, Any] = {}

        for key, value in step_data.items():
            if isinstance(value, str):
                parsed[key] = value
            elif isinstance(value, dict):
                parsed[key] = value
            elif isinstance(value, list):
                parsed[key] = value
            else:
                parsed[key] = value

        return parsed

    def load_all_workflows(self) -> List[Workflow]:
        """Load all workflows from directory.

        Returns:
            List of Workflow objects

        Note:
            Loads workflows from language-specific subdirectory (e.g., workflows/en/).
            Falls back to English if language-specific directory is empty or missing.
            For backward compatibility, also loads from workflows_dir if no language
            subdirectories exist.
        """
        workflows: List[Workflow] = []

        if not self.workflows_dir.exists():
            return workflows

        lang_dir = self.workflows_dir / str(self.language)

        if not lang_dir.exists() or not list(lang_dir.glob("*.yaml")):
            if self.language != LanguageCode.EN:
                lang_dir = self.workflows_dir / str(LanguageCode.EN)
                if not lang_dir.exists() or not list(lang_dir.glob("*.yaml")):
                    lang_dir = self.workflows_dir
            else:
                lang_dir = self.workflows_dir

        for file_path in lang_dir.glob("*.yaml"):
            try:
                workflow = self.load_workflow(file_path)
                workflows.append(workflow)
            except Exception as e:
                print(f"Warning: Failed to load workflow from {file_path}: {e}")

        return workflows

    def reload_workflow(self, workflow_name: str) -> Optional[Workflow]:
        """Reload a workflow by name.

        Args:
            workflow_name: Name of workflow to reload

        Returns:
            Workflow object if found, None otherwise

        Note:
            Checks language-specific directory first, falls back to English,
            then falls back to workflows_dir for backward compatibility.
        """
        lang_dir = self.workflows_dir / str(self.language)
        file_path = lang_dir / f"{workflow_name}.yaml"

        if not file_path.exists():
            if self.language != LanguageCode.EN:
                lang_dir = self.workflows_dir / str(LanguageCode.EN)
                file_path = lang_dir / f"{workflow_name}.yaml"
                if not file_path.exists():
                    file_path = self.workflows_dir / f"{workflow_name}.yaml"
            else:
                file_path = self.workflows_dir / f"{workflow_name}.yaml"

        if not file_path.exists():
            return None

        return self.load_workflow_direct(file_path)
