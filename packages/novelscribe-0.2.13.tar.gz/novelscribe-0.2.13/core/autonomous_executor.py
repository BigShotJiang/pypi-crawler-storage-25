"""Autonomous workflow executor for end-to-end novel generation."""

import logging
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel

from core.checkpoint_manager import CheckpointManager
from core.checkpoint_orchestrator import create_checkpoint_orchestrator
from core.context_bus import ContextBus
from core.git_manager import create_git_manager
from core.human_checkpoint import CheckpointType, HumanCheckpoint, HumanCheckpointHandler
from core.llm_client import LLMConfig, OpenAIClient
from core.orchestrator_agent_integration import AgentSystemIntegration
from core.progress_tracker import ExecutionStatus, ProgressTracker
from core.storage import StorageBackend, StorageConfig, StorageFactory
from core.timeout_handler import TimeoutAction, TimeoutHandler
from core.workflow_executor import WorkflowExecutor


class AutonomousConfig(BaseModel):
    """Autonomous executor configuration.

    Attributes:
        project_name: Name of the project
        start_phase: Starting phase name
        end_phase: Ending phase name
        human_in_loop: Enable human-in-the-loop checkpoints
        max_chapters: Maximum number of chapters to write (None for unlimited)
        provider: LLM provider to use
        checkpoint_interface: Interface to use for checkpoints (cli, file, api, all)
    """

    project_name: str
    start_phase: str = "new_novel"
    end_phase: str = "verification_phase"
    human_in_loop: bool = False
    max_chapters: Optional[int] = None
    provider: str = "openai"
    checkpoint_interface: str = "cli"
    hybrid_mode: bool = False
    checkpoint_timeout: Optional[int] = None
    timeout_action: TimeoutAction = TimeoutAction.PAUSE


class AutonomousResult(BaseModel):
    """Result of autonomous execution.

    Attributes:
        success: Whether execution completed successfully
        completed_phases: List of completed phase names
        final_status: Final execution status
        error: Optional error message if failed
        checkpoint_id: Optional checkpoint ID if paused
    """

    success: bool
    completed_phases: list[str]
    final_status: ExecutionStatus
    error: Optional[str] = None
    checkpoint_id: Optional[str] = None


class AutonomousExecutor:
    """Autonomous workflow executor.

    Executes complete workflow chain from start to finish with
    progress tracking, checkpointing, and optional human-in-the-loop
    checkpoints.

    Uses a comprehensive 8-checkpoint system (CP1-CP8) for human oversight
    at key decision points throughout the novel generation pipeline.
    """

    WORKFLOW_CHAIN = [
        "new_novel",
        "worldbuilding_phase",
        "character_phase",
        "outline_phase",
        "chapter_plan_phase",
        "writing_phase",
        "continuity_phase",
        "verification_phase",
    ]

    # Legacy checkpoints - kept for backwards compatibility with simple mode
    LEGACY_HUMAN_CHECKPOINTS = [
        HumanCheckpoint(
            phase="outline_phase",
            type=CheckpointType.APPROVAL,
            message="Review generated outline. Approve to continue?",
        ),
        HumanCheckpoint(
            phase="character_phase",
            type=CheckpointType.INPUT,
            message="Enter any additional character requirements:",
            required=False,
        ),
        HumanCheckpoint(
            phase="chapter_plan_phase",
            type=CheckpointType.APPROVAL,
            message="Review chapter plan. Approve to continue writing?",
        ),
    ]

    def __init__(
        self,
        config: AutonomousConfig,
        storage_path: Path,
    ):
        """Initialize autonomous executor.

        Args:
            config: Autonomous executor configuration
            storage_path: Base storage path for project files
        """
        self.config = config
        self.storage_path = storage_path
        self.logger = logging.getLogger("scribe")

        project_path = storage_path / config.project_name
        storage_config = StorageConfig(base_path=str(project_path))
        storage: StorageBackend = StorageFactory.create(storage_config)

        self.llm_config = LLMConfig(provider=config.provider)
        llm_client = OpenAIClient(self.llm_config)

        agents_dir = Path("agents")
        self.agent_integration = AgentSystemIntegration(
            agents_dir=str(agents_dir),
            llm_client=llm_client,
            storage=storage,
            work_dir=str(project_path),
        )

        workflows_dir = Path("workflows")
        self.git_manager = create_git_manager(project_path, auto_commit=True)

        self.context_bus = ContextBus(
            project_path=project_path,
            llm_client=llm_client,
            agent_loader=self.agent_integration.registry,
        )

        self.workflow_executor = WorkflowExecutor(
            workflows_dir=str(workflows_dir),
            agent_integration=self.agent_integration,
            storage=storage,
            git_manager=self.git_manager,
            work_dir=str(project_path),
            context_bus=self.context_bus,
        )

        self.progress_tracker = ProgressTracker(config.project_name, project_path)
        self.checkpoint_manager = CheckpointManager(config.project_name, project_path)

        if config.human_in_loop:
            self.checkpoint_orchestrator = create_checkpoint_orchestrator()
            self.human_handler: Optional[HumanCheckpointHandler] = None
        else:
            self.checkpoint_orchestrator = None
            self.human_handler = HumanCheckpointHandler(enabled=False)

        self.timeout_handler: Optional[TimeoutHandler] = None
        if config.hybrid_mode and config.checkpoint_timeout:
            self.timeout_handler = TimeoutHandler(
                action=config.timeout_action,
                timeout_seconds=config.checkpoint_timeout,
            )

    def execute(self, resume: bool = False) -> AutonomousResult:
        """Execute autonomous pipeline.

        Args:
            resume: Whether to resume from latest checkpoint

        Returns:
            Execution result
        """
        try:
            if resume:
                return self._resume_from_checkpoint()

            return self._execute_full_pipeline()

        except Exception as e:
            self.logger.error(f"Autonomous execution failed: {e}")
            self.progress_tracker.set_status(ExecutionStatus.FAILED, str(e))

            state = self.progress_tracker.get_state()
            completed: list[str] = state.completed_phases if state else []

            return AutonomousResult(
                success=False,
                completed_phases=completed,
                final_status=ExecutionStatus.FAILED,
                error=str(e),
            )

    def _execute_full_pipeline(self) -> AutonomousResult:
        """Execute full autonomous pipeline.

        Returns:
            Execution result
        """
        self.logger.info(f"🚀 Starting autonomous pipeline for '{self.config.project_name}'")

        total_steps = len(self.WORKFLOW_CHAIN)
        self.progress_tracker.initialize(total_steps, self.config.start_phase)

        completed_phases: list[str] = []
        execution_context: dict[str, Any] = {"project_name": self.config.project_name}
        current_chapter: Optional[int] = None

        start_index = self._get_workflow_index(self.config.start_phase)
        end_index = self._get_workflow_index(self.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = self.WORKFLOW_CHAIN[i]

            if workflow_name == "new_novel" and self.config.start_phase != "new_novel":
                continue

            self.progress_tracker.update_phase(workflow_name)

            self.logger.info(f"→ Executing phase: {workflow_name}")

            if self.human_handler:
                if self.human_handler.should_pause_at_phase(
                    workflow_name, self.LEGACY_HUMAN_CHECKPOINTS
                ):
                    checkpoint = self.human_handler.get_checkpoint_for_phase(
                        workflow_name, self.LEGACY_HUMAN_CHECKPOINTS
                    )

                    if checkpoint:
                        decision = self.human_handler.handle_checkpoint(checkpoint)

                        if not decision.approved:
                            self.logger.info("Execution stopped by user")
                            self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                            return AutonomousResult(
                                success=False,
                                completed_phases=completed_phases,
                                final_status=ExecutionStatus.PAUSED,
                                error="Stopped by user at checkpoint",
                            )

                        if decision.input:
                            execution_context["user_input"] = decision.input

                        if decision.modifications:
                            execution_context.update(decision.modifications)
            elif self.checkpoint_orchestrator:
                chapter_for_checkpoint = None
                if workflow_name == "chapter_plan_phase" or workflow_name == "writing_phase":
                    chapter_for_checkpoint = current_chapter

                if self.checkpoint_orchestrator.should_pause_at_phase(
                    workflow_name, chapter_for_checkpoint
                ):
                    checkpoint_result = self._present_checkpoint(
                        workflow_name, chapter_for_checkpoint, execution_context
                    )

                    if checkpoint_result is None:
                        self.logger.info("Execution paused at checkpoint (waiting for input)")
                        self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            checkpoint_id=self.checkpoint_orchestrator.get_checkpoint_id(
                                workflow_name, chapter_for_checkpoint
                            ),
                        )

                    if checkpoint_result.get("status") == "rejected":
                        self.logger.info("Execution rejected by human at checkpoint")
                        self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            error="Rejected by human at checkpoint",
                            checkpoint_id=checkpoint_result.get("checkpoint_id"),
                        )

                    if checkpoint_result.get("modified_content"):
                        execution_context["checkpoint_modifications"] = checkpoint_result[
                            "modified_content"
                        ]

                    if checkpoint_result.get("guidance"):
                        execution_context["human_guidance"] = checkpoint_result["guidance"]

            try:
                result = self.workflow_executor.execute_workflow(
                    workflow_name=workflow_name,
                    project_name=self.config.project_name,
                    variables=execution_context,
                    config=self.llm_config.model_dump(),
                )

                if not result.get("success"):
                    self.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

                completed_phases.append(workflow_name)
                self.progress_tracker.complete_phase(workflow_name)

                if workflow_name == "chapter_plan_phase":
                    plan = result.get("plan", {})
                    if isinstance(plan, dict):
                        chapters = plan.get("chapters", [])
                        current_chapter = len(chapters) if chapters else 0
                    else:
                        current_chapter = 0

                state = self.progress_tracker.get_state()
                if state is None:
                    raise RuntimeError("Progress state is None after completing phase")

                self.checkpoint_manager.create_checkpoint(
                    completed_workflows=completed_phases,
                    current_workflow=None,
                    execution_context=execution_context,
                    progress_state=state,
                )

                self.context_bus.save_snapshot(
                    run_id=self.config.project_name,
                    phase=workflow_name,
                    step="complete",
                )

                self.git_manager.auto_commit_step(
                    agent="autonomous",
                    description=f"Complete {workflow_name}",
                )

            except Exception as e:
                self.logger.error(f"Failed to execute workflow '{workflow_name}': {e}")
                raise

        self.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        self.logger.info(
            f"✅ Autonomous pipeline completed successfully for '{self.config.project_name}'"
        )

        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def _present_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        """Present checkpoint to human and wait for decision.

        Args:
            phase: Current phase
            chapter: Current chapter number
            execution_context: Current execution context

        Returns:
            Decision result dict or None if checkpoint is pending/waiting
        """
        if not self.checkpoint_orchestrator:
            raise RuntimeError("checkpoint_orchestrator is not initialized")

        checkpoint_id = self.checkpoint_orchestrator.get_checkpoint_id(phase, chapter)

        plan_content = self._build_checkpoint_plan_content(phase, chapter, execution_context)

        state = self.progress_tracker.get_state()
        completed = list(state.completed_phases) if state else []

        context_summary = {
            "completed_phases": completed,
            "current_phase": phase,
            "chapter": chapter,
            "project_name": self.config.project_name,
        }

        proposal = self.checkpoint_orchestrator.present_checkpoint(
            phase=phase,
            chapter=chapter,
            plan_content=plan_content,
            context_summary=context_summary,
        )

        self.logger.info(f"⏸️  Checkpoint {checkpoint_id}: {proposal.plan.title}")
        self.logger.info(f"   Confidence: {proposal.confidence:.0%}")
        self.logger.info(f"   Reasoning: {proposal.reasoning}")

        decision = self.checkpoint_orchestrator.await_decision(checkpoint_id)

        if decision is None:
            return None

        return decision

    def _build_checkpoint_plan_content(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> dict[str, Any]:
        """Build plan content dict for checkpoint proposal.

        Args:
            phase: Current phase
            chapter: Current chapter
            execution_context: Current execution context

        Returns:
            Plan content dict for CheckpointProposal
        """
        title = f"{phase.replace('_', ' ').title()}"
        if chapter is not None:
            title = f"{title} - Chapter {chapter}"

        plan_content: dict[str, Any] = {
            "title": title,
            "metadata": {
                "phase": phase,
                "chapter": chapter,
                "project": self.config.project_name,
            },
        }

        if phase == "new_novel":
            plan_content["word_estimate"] = 80000

        elif phase == "outline_phase":
            plan_content["word_estimate"] = execution_context.get("target_word_count", 80000)

        elif phase == "chapter_plan_phase":
            plan_content["word_estimate"] = 3000

        elif phase == "writing_phase":
            plan_content["word_estimate"] = 3000

        return plan_content

    def pause_at_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[str]:
        """Pause pipeline at a checkpoint for later human review.

        Args:
            phase: Current phase name.
            chapter: Current chapter number.
            execution_context: Current execution context.

        Returns:
            Checkpoint ID if paused, None if no checkpoint needed.
        """
        if not self.checkpoint_orchestrator:
            return None

        if not self.checkpoint_orchestrator.should_pause_at_phase(phase, chapter):
            return None

        checkpoint_id = self.checkpoint_orchestrator.get_checkpoint_id(phase, chapter)
        plan_content = self._build_checkpoint_plan_content(phase, chapter, execution_context)

        state = self.progress_tracker.get_state()
        completed = list(state.completed_phases) if state else []

        proposal = self.checkpoint_orchestrator.present_checkpoint(
            phase=phase,
            chapter=chapter,
            plan_content=plan_content,
            context_summary={
                "completed_phases": completed,
                "current_phase": phase,
                "chapter": chapter,
                "project_name": self.config.project_name,
            },
        )

        self.progress_tracker.set_status(ExecutionStatus.PAUSED)
        self.checkpoint_manager.create_checkpoint(
            completed_workflows=completed,
            current_workflow=phase,
            execution_context=execution_context,
            progress_state=self.progress_tracker.get_state(),
        )

        self.logger.info(f"⏸️  Paused at checkpoint {checkpoint_id}: {proposal.plan.title}")

        if self.timeout_handler:
            self.timeout_handler.start_timer(checkpoint_id)

        return checkpoint_id

    def resume_from_checkpoint_decision(
        self, checkpoint_id: str, decision: dict[str, Any]
    ) -> AutonomousResult:
        """Resume pipeline after human makes a checkpoint decision.

        Args:
            checkpoint_id: Checkpoint that was decided.
            decision: Decision dict with type and optional modifications.

        Returns:
            Execution result after resuming.
        """
        if not self.checkpoint_orchestrator:
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint orchestrator configured",
            )

        if self.timeout_handler:
            self.timeout_handler.cancel_timer(checkpoint_id)

        self.checkpoint_orchestrator.incorporate_decision(checkpoint_id, decision)

        self.progress_tracker.set_status(ExecutionStatus.RUNNING)
        return self._resume_from_checkpoint()

    def checkpoint_waiting(self) -> Optional[dict[str, Any]]:
        """Check if there's a checkpoint waiting for decision.

        Returns:
            Dict with checkpoint info or None.
        """
        if not self.checkpoint_orchestrator:
            return None

        pending = self.checkpoint_orchestrator.get_pending_checkpoints()
        if not pending:
            return None

        cp_id = pending[0]
        state = self.checkpoint_orchestrator.get_checkpoint_state(cp_id)
        if not state or "proposal" not in state:
            return None

        proposal = state["proposal"]
        return {
            "checkpoint_id": cp_id,
            "phase": proposal.phase,
            "title": proposal.plan.title,
            "confidence": proposal.confidence,
            "status": state["status"],
        }

    def _resume_from_checkpoint(self) -> AutonomousResult:
        """Resume execution from checkpoint.

        Returns:
            Execution result
        """
        self.logger.info(f"🔄 Resuming autonomous pipeline for '{self.config.project_name}'")

        checkpoint = self.checkpoint_manager.load_checkpoint()

        if not checkpoint:
            self.logger.error("No checkpoint found to resume from")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint found",
            )

        if not self.checkpoint_manager.validate_checkpoint(checkpoint):
            self.logger.error("Invalid checkpoint")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="Invalid checkpoint",
            )

        self.progress_tracker._state = checkpoint.progress_state
        self.progress_tracker.set_status(ExecutionStatus.RUNNING)

        context_snapshot = self.context_bus.restore_snapshot(
            run_id=self.config.project_name,
        )
        if context_snapshot is not None:
            self.logger.info(
                f"Restored context snapshot at phase={context_snapshot.phase} "
                f"step={context_snapshot.step}"
            )

        completed_phases: list[str] = checkpoint.completed_workflows
        execution_context: dict[str, Any] = checkpoint.execution_context
        current_chapter: Optional[int] = None

        last_completed = completed_phases[-1] if completed_phases else None
        start_index = self._get_workflow_index(last_completed) + 1 if last_completed else 0
        end_index = self._get_workflow_index(self.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = self.WORKFLOW_CHAIN[i]

            self.progress_tracker.update_phase(workflow_name)

            self.logger.info(f"→ Executing phase: {workflow_name}")

            if self.checkpoint_orchestrator:
                chapter_for_checkpoint = None
                if workflow_name in ("chapter_plan_phase", "writing_phase"):
                    chapter_for_checkpoint = current_chapter

                if self.checkpoint_orchestrator.should_pause_at_phase(
                    workflow_name, chapter_for_checkpoint
                ):
                    checkpoint_result = self._present_checkpoint(
                        workflow_name, chapter_for_checkpoint, execution_context
                    )

                    if checkpoint_result is None:
                        self.logger.info("Execution paused at checkpoint (waiting for input)")
                        self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            checkpoint_id=self.checkpoint_orchestrator.get_checkpoint_id(
                                workflow_name, chapter_for_checkpoint
                            ),
                        )

                    if checkpoint_result.get("status") == "rejected":
                        self.logger.info("Execution rejected by human at checkpoint")
                        self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            error="Rejected by human at checkpoint",
                            checkpoint_id=checkpoint_result.get("checkpoint_id"),
                        )

                    if checkpoint_result.get("modified_content"):
                        execution_context["checkpoint_modifications"] = checkpoint_result[
                            "modified_content"
                        ]

                    if checkpoint_result.get("guidance"):
                        execution_context["human_guidance"] = checkpoint_result["guidance"]

            result = self.workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=self.config.project_name,
                variables=execution_context,
                config=self.llm_config.model_dump(),
            )

            if not result.get("success"):
                self.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

            completed_phases.append(workflow_name)
            self.progress_tracker.complete_phase(workflow_name)

            if workflow_name == "chapter_plan_phase":
                plan = result.get("plan", {})
                if isinstance(plan, dict):
                    chapters = plan.get("chapters", [])
                    current_chapter = len(chapters) if chapters else 0
                else:
                    current_chapter = 0

            state = self.progress_tracker.get_state()
            if state is None:
                raise RuntimeError("Progress state is None after completing phase")

            self.checkpoint_manager.create_checkpoint(
                completed_workflows=completed_phases,
                current_workflow=None,
                execution_context=execution_context,
                progress_state=state,
            )

            self.context_bus.save_snapshot(
                run_id=self.config.project_name,
                phase=workflow_name,
                step="complete",
            )

        self.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        self.logger.info("✅ Resumed pipeline completed successfully")

        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def _get_workflow_index(self, workflow_name: str) -> int:
        """Get index of workflow in chain.

        Args:
            workflow_name: Workflow name

        Returns:
            Workflow index

        Raises:
            ValueError: If workflow not found in chain
        """
        try:
            return self.WORKFLOW_CHAIN.index(workflow_name)
        except ValueError:
            raise ValueError(f"Unknown workflow: {workflow_name}")
