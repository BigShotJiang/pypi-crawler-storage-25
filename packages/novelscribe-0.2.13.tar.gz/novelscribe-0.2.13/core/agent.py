"""Agent definition data model."""

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class AgentCategory(str, Enum):
    """Agent category types."""

    ANALYTICAL = "analytical"
    CREATIVE = "creative"
    VALIDATION = "validation"


class Agent(BaseModel):
    """Agent definition loaded from Markdown with YAML frontmatter."""

    name: str = Field(..., description="Unique agent name")
    version: str = Field(default="1.0.0", description="Agent version")
    description: str = Field(..., description="Brief description of agent purpose")
    category: AgentCategory = Field(..., description="Agent category")
    input_schema: List[str] = Field(
        default_factory=list, description="Expected input specifications"
    )
    output_schema: List[str] = Field(default_factory=list, description="Output specifications")
    dependencies: List[str] = Field(default_factory=list, description="Dependent agent names")
    instructions: str = Field(..., description="Agent instructions (Markdown body)")
    file_path: Optional[str] = Field(None, description="Path to agent definition file")
    context_needs: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Context requirements declared in YAML frontmatter",
    )

    model_config = ConfigDict(use_enum_values=True)


class AgentContext(BaseModel):
    """Context for agent execution.

    Deprecated: Will be removed in Phase 9.4 (Integration + Migration).
    Replaced by AgentContextSchema from context_schema.py.
    """

    project_name: str = Field(..., description="Project name")
    variables: dict = Field(default_factory=dict, description="Variables for substitution")
    previous_outputs: dict = Field(default_factory=dict, description="Outputs from previous steps")
    config: dict = Field(default_factory=dict, description="LLM configuration")


class AgentResult(BaseModel):
    """Result from agent execution."""

    agent_name: str = Field(..., description="Name of executed agent")
    success: bool = Field(..., description="Execution success status")
    output: str = Field(default="", description="Agent output content")
    output_files: List[str] = Field(default_factory=list, description="Generated output files")
    error: Optional[str] = Field(None, description="Error message if failed")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")
