"""
CLI commands for Phase 4.3: Memory Optimization

Commands for:
- Memory profiling and statistics
- Context pruning
- Cache management
- Memory monitoring
- Object pool statistics
"""

import logging
import sys
import time
from typing import Optional

import click

from core.cache_manager import CacheManager, CacheManagerConfig
from core.context_compressor import ContextCompressor
from core.memory_monitor import create_default_monitor
from core.memory_profiler import MemoryProfiler, MemoryProfilerConfig
from core.object_pool import get_pool_manager
from core.token_estimator import TokenEstimator

logger = logging.getLogger("scribe")


@click.group()
@click.pass_context
def memory(ctx: click.Context) -> None:
    """Memory optimization and monitoring commands."""
    pass


@memory.command()
@click.argument("project_name")
@click.option("--duration", default=60, type=int, help="Profiling duration in seconds")
@click.option("--interval", default=5, type=int, help="Snapshot interval in seconds")
@click.pass_context
def profile(ctx: click.Context, project_name: str, duration: int, interval: int) -> None:
    """Profile memory usage for a duration."""
    try:
        logger.info(f"Profiling memory for: {project_name}")
        logger.info(f"Duration: {duration} seconds, Interval: {interval} seconds")

        config = MemoryProfilerConfig(
            snapshot_interval_seconds=interval, max_snapshots=duration // interval + 10
        )

        profiler = MemoryProfiler(config)
        profiler.start_profiling(interval)

        try:
            for i in range(duration // interval):
                time.sleep(interval)
                snapshot = profiler.take_snapshot()
                logger.info(f"[{i * interval}s] Memory: {snapshot.total_memory_mb:.1f} MB")

        finally:
            profiler.stop_profiling()

        report = profiler.get_memory_report()

        logger.info("")
        logger.info(f"## Memory Report for {project_name}")
        logger.info("")
        logger.info(f"Current Memory: {report['summary']['current_memory_mb']:.1f} MB")
        logger.info(f"Average Memory: {report['summary']['average_memory_mb']:.1f} MB")
        logger.info(f"Peak Memory: {report['summary']['peak_memory_mb']:.1f} MB")
        logger.info(f"Memory Change: {report['summary']['total_change_mb']:.1f} MB")

        if report["leaks_detected"]:
            logger.info("")
            logger.info("⚠️  Potential Leaks Detected:")
            for leak in report["leaks_detected"]:
                logger.info(f"   - {leak}")

    except Exception as e:
        logger.error(f"Failed to profile memory: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.pass_context
def stats(ctx: click.Context, project_name: str) -> None:
    """Show memory statistics."""
    try:
        logger.info(f"Memory statistics for: {project_name}")

        profiler = MemoryProfiler()
        snapshot = profiler.take_snapshot()

        logger.info("")
        logger.info("## Current Memory Usage")
        logger.info("")
        logger.info(f"Total Memory: {snapshot.total_memory_mb:.1f} MB")
        logger.info(f"Available Memory: {snapshot.available_memory_mb:.1f} MB")
        logger.info(f"System Memory: {snapshot.system_memory_mb:.1f} MB")
        logger.info(
            f"Usage Percent: {(snapshot.total_memory_mb / snapshot.system_memory_mb) * 100:.1f}%"
        )

        if snapshot.component_usage:
            logger.info("")
            logger.info("## Component Usage")
            for component, size_mb in snapshot.component_usage.items():
                logger.info(f"{component}: {size_mb:.1f} MB")

    except Exception as e:
        logger.error(f"Failed to get memory stats: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option("--hours", default=24, type=int, help="Hours to analyze")
@click.pass_context
def analyze(ctx: click.Context, project_name: str, hours: int) -> None:
    """Analyze memory trends over time."""
    try:
        logger.info(f"Analyzing memory trends for: {project_name}")
        logger.info(f"Time window: {hours} hours")

        monitor = create_default_monitor()
        report = monitor.get_status_report()

        logger.info("")
        logger.info("## Memory Analysis")
        logger.info("")
        logger.info(f"Current Memory: {report['current_memory_mb']:.1f} MB")
        logger.info(f"Trend: {report['trend']}")
        logger.info("")
        logger.info("## Threshold Status")
        for threshold in report["thresholds"]:
            status_icon = "✅" if threshold["status"] == "ok" else "⚠️"
            logger.info(f"{status_icon} {threshold['name']}: {threshold['status'].upper()}")
            logger.info(f"   Current: {threshold['current_mb']:.1f} MB")
            logger.info(f"   Warning: {threshold['warning_mb']:.1f} MB")
            logger.info(f"   Critical: {threshold['critical_mb']:.1f} MB")

    except Exception as e:
        logger.error(f"Failed to analyze memory: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option(
    "--strategy",
    default="truncate",
    type=click.Choice(["truncate", "summarize", "extract"]),
    help="Compression strategy",
)
@click.option("--target-tokens", default=8000, type=int, help="Target token count")
@click.option("--test-context", default="", help="Test context to compress")
@click.pass_context
def prune(
    ctx: click.Context, project_name: str, strategy: str, target_tokens: int, test_context: str
) -> None:
    """Test context compression."""
    try:
        logger.info(f"Compressing context for: {project_name}")
        logger.info(f"Strategy: {strategy}, Target: {target_tokens} tokens")

        compressor = ContextCompressor()

        if not test_context:
            test_context = "This is a test context with some repeated content. " * 100

        estimator = TokenEstimator()
        original_tokens = estimator.estimate_tokens(test_context)

        from core.context_assembly import ContextBlock
        from core.context_schema import TokenBudget

        block = ContextBlock(
            artifact_type="test",
            content=test_context,
            token_count=original_tokens,
            priority=1.0,
        )
        budget = TokenBudget(total=target_tokens)
        result = compressor.compress([block], budget)

        logger.info("")
        logger.info("## Compression Results")
        logger.info("")
        logger.info(f"Original Size: {original_tokens} tokens")
        logger.info(f"Compressed Size: {result.token_count} tokens")
        logger.info(f"Reduction: {result.reduction_percent:.1f}%")
        logger.info(f"Tiers Applied: {[t.value for t in result.tiers_applied]}")

    except Exception as e:
        logger.error(f"Failed to compress context: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option("--size-mb", default=100.0, type=float, help="Max cache size in MB")
@click.option("--max-entries", default=100, type=int, help="Max cache entries")
@click.option("--ttl", default=None, type=int, help="Default TTL in seconds")
@click.pass_context
def cache_stats(
    ctx: click.Context, project_name: str, size_mb: float, max_entries: int, ttl: Optional[int]
) -> None:
    """Show cache statistics."""
    try:
        logger.info(f"Cache statistics for: {project_name}")

        config = CacheManagerConfig(
            max_size_mb=size_mb, max_entries=max_entries, default_ttl_seconds=ttl
        )

        cache = CacheManager(config)
        stats = cache.get_statistics()

        logger.info("")
        logger.info("## Cache Statistics")
        logger.info("")
        logger.info(f"Entries: {stats['entries']}")
        logger.info(f"Hits: {stats['hits']}")
        logger.info(f"Misses: {stats['misses']}")
        logger.info(f"Hit Rate: {stats['hit_rate']}")
        logger.info(f"Evictions: {stats['evictions']}")
        logger.info(f"Expirations: {stats['expirations']}")
        logger.info(f"Current Size: {stats['current_size_mb']:.2f} MB")
        logger.info(f"Max Size: {stats['max_size_mb']:.2f} MB")
        logger.info(f"Utilization: {stats['utilization_percent']:.1f}%")

    except Exception as e:
        logger.error(f"Failed to get cache stats: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.pass_context
def optimize(ctx: click.Context, project_name: str) -> None:
    """Optimize memory usage."""
    try:
        logger.info(f"Optimizing memory for: {project_name}")

        from core.cache_manager import CacheManager
        from core.context_cache import ContextCache

        caches_optimized = 0

        try:
            context_cache = ContextCache()
            context_cache.optimize()
            caches_optimized += 1
            logger.info("✅ Optimized ContextCache")
        except Exception:
            pass

        try:
            cache_manager = CacheManager()
            cache_manager.optimize()
            caches_optimized += 1
            logger.info("✅ Optimized CacheManager")
        except Exception:
            pass

        pool_manager = get_pool_manager()
        pool_manager.optimize_all()
        logger.info("✅ Optimized object pools")

        logger.info("")
        logger.info(f"Optimized {caches_optimized} caches and object pools")

    except Exception as e:
        logger.error(f"Failed to optimize memory: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option("--all", "clear_all", is_flag=True, help="Clear all caches")
@click.option("--context", is_flag=True, help="Clear context cache")
@click.option("--summary", is_flag=True, help="Clear summary cache")
@click.pass_context
def clear_cache(
    ctx: click.Context, project_name: str, clear_all: bool, context: bool, summary: bool
) -> None:
    """Clear caches."""
    try:
        logger.info(f"Clearing caches for: {project_name}")

        if clear_all or context:
            try:
                from core.context_cache import ContextCache

                cache = ContextCache()
                cache.clear()
                logger.info("✅ Cleared context cache")
            except Exception:
                pass

        if clear_all or summary:
            try:
                from core.cache_manager import CacheManager

                cache = CacheManager()
                cache.clear()
                logger.info("✅ Cleared summary cache")
            except Exception:
                pass

        if not (clear_all or context or summary):
            logger.error("Specify --all, --context, or --summary")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Failed to clear caches: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option("--chapters", default=100, type=int, help="Number of chapters to test")
@click.option("--interval", default=5, type=int, help="Check interval in seconds")
@click.pass_context
def stress_test(ctx: click.Context, project_name: str, chapters: int, interval: int) -> None:
    """Run memory stress test."""
    try:
        logger.info(f"Running stress test for: {project_name}")
        logger.info(f"Chapters: {chapters}, Interval: {interval} seconds")

        profiler = MemoryProfiler()
        profiler.start_profiling(interval)

        try:
            logger.info("Starting stress test...")

            for i in range(chapters):
                time.sleep(1)

                if i % 10 == 0:
                    snapshot = profiler.take_snapshot()
                    logger.info(f"[Chapter {i}] Memory: {snapshot.total_memory_mb:.1f} MB")

        finally:
            profiler.stop_profiling()

        report = profiler.get_memory_report()

        logger.info("")
        logger.info("## Stress Test Results")
        logger.info("")
        logger.info(f"Peak Memory: {report['summary']['peak_memory_mb']:.1f} MB")
        logger.info(f"Average Memory: {report['summary']['average_memory_mb']:.1f} MB")
        logger.info(f"Total Change: {report['summary']['total_change_mb']:.1f} MB")

        if report["leaks_detected"]:
            logger.info("")
            logger.info("⚠️  Potential Leaks:")
            for leak in report["leaks_detected"]:
                logger.info(f"   - {leak}")
        else:
            logger.info("")
            logger.info("✅ No leaks detected")

    except Exception as e:
        logger.error(f"Failed to run stress test: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.option("--interval", default=5, type=int, help="Check interval in seconds")
@click.option("--duration", default=60, type=int, help="Monitor duration in seconds")
@click.pass_context
def monitor(ctx: click.Context, project_name: str, interval: int, duration: int) -> None:
    """Monitor memory in real-time."""
    try:
        logger.info(f"Monitoring memory for: {project_name}")
        logger.info(f"Interval: {interval}s, Duration: {duration}s")
        logger.info("Press Ctrl+C to stop")
        logger.info("")

        monitor = create_default_monitor()
        monitor.start_monitoring()

        try:
            start_time = time.time()

            while time.time() - start_time < duration:
                time.sleep(interval)

                report = monitor.get_status_report()

                logger.info(
                    f"[{int(time.time() - start_time)}s] "
                    f"Memory: {report['current_memory_mb']:.1f} MB, "
                    f"Trend: {report['trend']}"
                )

        finally:
            monitor.stop_monitoring()

        logger.info("")
        logger.info("## Monitoring Summary")

        triggered = monitor.get_triggered_actions()
        if triggered:
            logger.info(f"Triggered {len(triggered)} actions")
            for action in triggered[-5:]:
                logger.info(f"  - {action['threshold']}: {action['status']}")
        else:
            logger.info("✅ No threshold actions triggered")

    except KeyboardInterrupt:
        logger.info("")
        logger.info("Monitoring stopped by user")
    except Exception as e:
        logger.error(f"Failed to monitor memory: {e}")
        sys.exit(1)


@memory.command()
@click.argument("project_name")
@click.pass_context
def pool_stats(ctx: click.Context, project_name: str) -> None:
    """Show object pool statistics."""
    try:
        logger.info(f"Object pool statistics for: {project_name}")

        pool_manager = get_pool_manager()
        stats = pool_manager.get_all_stats()

        if not stats:
            logger.info("No object pools registered")
            return

        logger.info("")
        for pool_name, pool_stats in stats.items():
            logger.info(f"## {pool_name}")
            logger.info(f"Total Acquired: {pool_stats['total_acquired']}")
            logger.info(f"Total Released: {pool_stats['total_released']}")
            logger.info(f"Total Created: {pool_stats['total_created']}")
            logger.info(f"Current Size: {pool_stats['current_size']}")
            logger.info(f"Available: {pool_stats['current_available']}")
            logger.info(f"In Use: {pool_stats['current_in_use']}")
            logger.info(f"Peak Size: {pool_stats['peak_size']}")
            logger.info(f"Utilization: {pool_stats['utilization_rate']}")
            logger.info("")

    except Exception as e:
        logger.error(f"Failed to get pool stats: {e}")
        sys.exit(1)
