"""
Performance CLI Commands for Novel Generation System

This module provides CLI commands for performance monitoring, profiling,
and optimization of the novel generation pipeline.
"""

import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import click

sys.path.insert(0, str(Path(__file__).parent))
from core.file_optimizer import get_file_optimizer
from core.llm_optimizer import get_llm_optimizer
from core.parallel_executor import ParallelExecutor, get_parallel_executor
from core.performance_profiler import ProfileType, ProfilingContext, get_profiler


@click.group(name="perf")
def performance_cli():
    """Performance monitoring and optimization commands"""
    pass


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to profile")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json", "csv"]),
    default="text",
    help="Output format",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def profile(project_name: str, workflow: str, output_format: str, output: Optional[str]):
    """Profile a workflow execution"""
    result = run_profile_workflow(workflow)

    if output_format == "text":
        _display_profile_report(result["report"])
    elif output_format == "json":
        data = result["report"].to_dict()
        if output:
            with open(output, "w") as f:
                json.dump(data, f, indent=2)
            click.echo(f"Report saved to {output}")
        else:
            click.echo(json.dumps(data, indent=2))
    elif output_format == "csv":
        if output:
            result["profiler"].export_data(output, format="csv")
            click.echo(f"CSV report saved to {output}")
        else:
            click.echo("Error: CSV format requires --output")


def run_profile_workflow(workflow: str) -> Dict[str, Any]:
    """Execute profile workflow and return profiler and report.

    Args:
        workflow: Workflow name to profile

    Returns:
        Dict with 'profiler' and 'report' keys
    """
    profiler = get_profiler()

    with ProfilingContext(profiler, workflow, ProfileType.WORKFLOW):
        with ProfilingContext(profiler, "writer_agent", ProfileType.AGENT):
            time.sleep(0.5)
        with ProfilingContext(profiler, "continuity_agent", ProfileType.AGENT):
            time.sleep(0.3)

    report = profiler.get_report()
    return {"profiler": profiler, "report": report}


def _display_profile_report(report) -> None:
    """Display profile report in text format.

    Args:
        report: PerformanceReport object
    """
    click.echo("\n" + "=" * 60)
    click.echo("PERFORMANCE PROFILE REPORT")
    click.echo("=" * 60)
    click.echo(f"\nTotal Duration: {report.total_duration:.2f}s")
    click.echo("\nSummary:")
    _display_summary(report.summary)

    if report.bottlenecks:
        click.echo("\nBottlenecks (>5s):")
        for bottleneck in report.bottlenecks:
            click.echo(f"  - {bottleneck}")
    else:
        click.echo("\nNo bottlenecks identified (all operations <5s)")

    click.echo("\n" + "=" * 60)


def _display_summary(summary: Dict[str, Any]) -> None:
    """Display summary dict, handling nested dicts.

    Args:
        summary: Summary dictionary from report
    """
    for key, value in summary.items():
        if isinstance(value, dict):
            click.echo(f"  {key}:")
            for k, v in value.items():
                click.echo(f"    {k}: {v}")
        else:
            click.echo(f"  {key}: {value}")


def format_bottlenecks_list(bottlenecks: List[str], threshold: float) -> List[str]:
    """Format bottlenecks list for display.

    Args:
        bottlenecks: List of bottleneck strings
        threshold: Threshold value used

    Returns:
        Formatted list of strings
    """
    return bottlenecks


@performance_cli.command()
@click.argument("project_name")
@click.option("--threshold", default=5.0, help="Threshold in seconds")
@click.option(
    "--type",
    "profile_type",
    type=click.Choice(["agent", "workflow", "llm", "file_io"]),
    help="Filter by type",
)
def bottlenecks(project_name: str, threshold: float, profile_type: Optional[str]):
    """Identify performance bottlenecks"""
    result = get_bottlenecks(threshold=threshold, profile_type=profile_type)
    bottlenecks_list = result["bottlenecks"]

    if bottlenecks_list:
        click.echo(f"\nBottlenecks (>{threshold}s):")
        for bottleneck in bottlenecks_list:
            click.echo(f"  - {bottleneck}")
    else:
        click.echo(f"\nNo bottlenecks found (all operations <{threshold}s)")


def get_bottlenecks(threshold: float = 5.0, profile_type: Optional[str] = None) -> Dict[str, Any]:
    """Get bottlenecks from profiler.

    Args:
        threshold: Duration threshold in seconds
        profile_type: Optional type filter string

    Returns:
        Dict with 'profiler' and 'bottlenecks' keys
    """
    profiler = get_profiler()
    ptype = None
    if profile_type:
        ptype = ProfileType[profile_type.upper()]

    bottlenecks_list = profiler.identify_bottlenecks(threshold=threshold, profile_type=ptype)
    return {"profiler": profiler, "bottlenecks": bottlenecks_list}


def parse_file_size(file_size: str) -> int:
    """Parse file size string to bytes.

    Args:
        file_size: Size string like "1M", "500K", "1G", or plain number

    Returns:
        Size in bytes
    """
    size_map = {"K": 1024, "M": 1024 * 1024, "G": 1024 * 1024 * 1024}
    if file_size and file_size[-1].upper() in size_map:
        multiplier = size_map[file_size[-1].upper()]
        size = int(file_size[:-1]) * multiplier
    else:
        size = int(file_size)
    return size


@performance_cli.command()
@click.argument("project_name")
def file_stats(project_name: str):
    """Display file I/O statistics"""
    result = get_file_stats()
    _display_file_stats(result)


def get_file_stats() -> Dict[str, Any]:
    """Get file I/O statistics.

    Returns:
        Dict with 'stats', 'cache_info', 'write_cache_info' keys
    """
    optimizer = get_file_optimizer()
    return {
        "stats": optimizer.get_stats(),
        "cache_info": optimizer.get_cache_info(),
        "write_cache_info": optimizer.get_write_cache_info(),
    }


def _display_file_stats(result: Dict[str, Any]) -> None:
    """Display file stats result.

    Args:
        result: Dict from get_file_stats()
    """
    stats = result["stats"]
    cache_info = result["cache_info"]
    write_cache_info = result["write_cache_info"]

    click.echo("\n" + "=" * 60)
    click.echo("FILE I/O STATISTICS")
    click.echo("=" * 60)

    click.echo("\nI/O Operations:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nRead Cache:")
    _display_cache_info(cache_info)

    click.echo("\nWrite Cache:")
    for key, value in write_cache_info.items():
        click.echo(f"  {key}: {value}")

    click.echo("\n" + "=" * 60)


def _display_cache_info(cache_info: Dict[str, Any]) -> None:
    """Display cache info dict.

    Args:
        cache_info: Cache info dictionary
    """
    for key, value in cache_info.items():
        if key == "most_accessed" and value:
            click.echo(f"  {key}:")
            for path, count in value:
                click.echo(f"    - {path}: {count} hits")
        else:
            click.echo(f"  {key}: {value}")


@performance_cli.command()
@click.argument("project_name")
def clear_file_cache(project_name: str):
    """Clear file I/O cache"""
    clear_file_cache_internal()
    click.echo("File cache cleared")


def clear_file_cache_internal() -> None:
    """Clear file I/O cache (internal, for testing)."""
    optimizer = get_file_optimizer()
    optimizer.clear_cache()
    optimizer.clear_write_cache()


@performance_cli.command()
@click.argument("project_name")
@click.option("--file-size", default="1M", help="File size for benchmark")
def benchmark_io(project_name: str, file_size: str):
    """Benchmark file I/O performance"""
    result = run_benchmark_io(file_size)

    click.echo(f"Benchmarking I/O with {file_size} file...")
    click.echo("\nResults:")
    click.echo(f"  Write: {result['write_time']:.3f}s ({result['write_mbps']:.1f} MB/s)")
    click.echo(f"  Read:  {result['read_time']:.3f}s ({result['read_mbps']:.1f} MB/s)")


def run_benchmark_io(file_size: str) -> Dict[str, Any]:
    """Run I/O benchmark.

    Args:
        file_size: Size string like "1M"

    Returns:
        Dict with timing and throughput results
    """
    optimizer = get_file_optimizer()
    size = parse_file_size(file_size)

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        test_path = f.name
        test_content = "x" * size

    start = time.time()
    optimizer.write_file(test_path, test_content, immediate=True)
    write_time = time.time() - start

    start = time.time()
    optimizer.read_file(test_path)
    read_time = time.time() - start

    os.unlink(test_path)
    if os.path.exists(test_path + ".gz"):
        os.unlink(test_path + ".gz")

    return {
        "write_time": write_time,
        "read_time": read_time,
        "write_mbps": size / write_time / 1024 / 1024 if write_time > 0 else 0,
        "read_mbps": size / read_time / 1024 / 1024 if read_time > 0 else 0,
    }


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to analyze")
def exec_graph(project_name: str, workflow: str):
    """Display execution graph for workflow"""
    result = analyze_exec_graph(workflow)

    if not result["is_valid"]:
        click.echo("\n❌ Graph validation failed:")
        for error in result["errors"]:
            click.echo(f"  - {error}")
        return

    click.echo("\n✅ Graph is valid (no cycles)\n")
    click.echo("Nodes:")
    for node_id, node in result["nodes"].items():
        deps = ", ".join(node.dependencies) if node.dependencies else "None"
        click.echo(f"  - {node.agent_name} (deps: {deps})")

    click.echo("\nExecution Order:")
    order = result["execution_order"]
    for i, node_id in enumerate(order, 1):
        node = result["nodes"][node_id]
        click.echo(f"  {i}. {node.agent_name}")

    ready = result["ready_nodes"]
    click.echo(f"\nReady for parallel execution: {len(ready)} agents")
    for node in ready:
        click.echo(f"  - {node.agent_name}")

    click.echo("\n" + "=" * 60)


def get_sample_workflow_steps() -> List[Dict[str, Any]]:
    """Get sample workflow steps for exec_graph.

    Returns:
        List of workflow step dicts
    """
    return [
        {"agent": "discuss_agent", "dependencies": []},
        {"agent": "genre_agent", "dependencies": []},
        {"agent": "character_agent", "dependencies": ["discuss_agent"]},
        {"agent": "world_agent", "dependencies": ["discuss_agent"]},
        {
            "agent": "outline_agent",
            "dependencies": ["genre_agent", "character_agent", "world_agent"],
        },
    ]


def analyze_exec_graph(workflow: str) -> Dict[str, Any]:
    """Analyze execution graph for workflow.

    Args:
        workflow: Workflow name

    Returns:
        Dict with graph analysis results
    """
    executor = get_parallel_executor()
    workflow_steps = get_sample_workflow_steps()
    graph = executor.build_graph_from_workflow(workflow_steps)

    is_valid, errors = graph.validate()
    execution_order = graph.topological_sort()
    ready_nodes = graph.get_ready_nodes()

    return {
        "graph": graph,
        "nodes": graph.nodes,
        "is_valid": is_valid,
        "errors": errors,
        "execution_order": execution_order,
        "ready_nodes": ready_nodes,
        "workflow": workflow,
    }


def build_parallel_graph() -> Any:
    """Build sample graph for parallel execution.

    Returns:
        Graph object
    """
    executor = ParallelExecutor(max_workers=4)
    workflow_steps = [
        {"agent": "discuss_agent", "dependencies": []},
        {"agent": "genre_agent", "dependencies": []},
        {"agent": "character_agent", "dependencies": ["discuss_agent"]},
        {"agent": "world_agent", "dependencies": ["discuss_agent"]},
    ]
    return executor.build_graph_from_workflow(workflow_steps)


def get_mock_agent_functions() -> Dict[str, Any]:
    """Get mock agent functions for parallel execution.

    Returns:
        Dict mapping agent names to callables
    """

    def mock_agent(name: str, duration: float = 0.5):
        def agent():
            time.sleep(duration)
            return f"{name} completed"

        return agent

    return {
        "discuss_agent": mock_agent("discuss_agent", 0.3),
        "genre_agent": mock_agent("genre_agent", 0.2),
        "character_agent": mock_agent("character_agent", 0.5),
        "world_agent": mock_agent("world_agent", 0.4),
    }


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to execute")
@click.option("--max-workers", default=4, help="Maximum parallel workers")
def parallel(project_name: str, workflow: str, max_workers: int):
    """Execute workflow in parallel mode"""
    result = execute_parallel_workflow(max_workers)

    click.echo(f"Executing '{workflow}' in parallel (max {max_workers} workers)...")
    click.echo("\n" + "=" * 60)
    click.echo("PARALLEL EXECUTION RESULTS")
    click.echo("=" * 60)

    exec_result = result["result"]
    graph = result["graph"]

    click.echo(f"\nSuccess: {exec_result.success}")
    click.echo(f"Completed: {len(exec_result.completed_nodes)} agents")
    click.echo(f"Failed: {len(exec_result.failed_nodes)} agents")
    click.echo(f"Skipped: {len(exec_result.skipped_nodes)} agents")
    click.echo(f"Duration: {exec_result.total_duration:.2f}s")

    if exec_result.completed_nodes:
        click.echo("\nCompleted Agents:")
        for node_id in exec_result.completed_nodes:
            click.echo(f"  ✓ {graph.nodes[node_id].agent_name}")

    if exec_result.failed_nodes:
        click.echo("\nFailed Agents:")
        for node_id, error in exec_result.errors.items():
            click.echo(f"  ✗ {graph.nodes[node_id].agent_name}: {error}")

    click.echo("\n" + "=" * 60)


def execute_parallel_workflow(max_workers: int = 4) -> Dict[str, Any]:
    """Execute workflow in parallel mode.

    Args:
        max_workers: Maximum number of parallel workers

    Returns:
        Dict with 'executor', 'graph', and 'result' keys
    """
    executor = ParallelExecutor(max_workers=max_workers)
    graph = executor.build_graph_from_workflow(
        [
            {"agent": "discuss_agent", "dependencies": []},
            {"agent": "genre_agent", "dependencies": []},
            {"agent": "character_agent", "dependencies": ["discuss_agent"]},
            {"agent": "world_agent", "dependencies": ["discuss_agent"]},
        ]
    )
    agent_functions = get_mock_agent_functions()
    exec_result = executor.execute_parallel(graph, agent_functions)

    return {
        "executor": executor,
        "graph": graph,
        "result": exec_result,
    }


@performance_cli.command()
@click.argument("project_name")
def llm_stats(project_name: str):
    """Display LLM optimization statistics"""
    result = get_llm_stats()
    _display_llm_stats(result)


def get_llm_stats() -> Dict[str, Any]:
    """Get LLM statistics.

    Returns:
        Dict with 'stats', 'cache_info', 'rate_info' keys
    """
    optimizer = get_llm_optimizer()
    return {
        "stats": optimizer.get_stats(),
        "cache_info": optimizer.get_cache_info(),
        "rate_info": optimizer.get_rate_limit_info(),
    }


def _display_llm_stats(result: Dict[str, Any]) -> None:
    """Display LLM stats result.

    Args:
        result: Dict from get_llm_stats()
    """
    stats = result["stats"]
    cache_info = result["cache_info"]
    rate_info = result["rate_info"]

    click.echo("\n" + "=" * 60)
    click.echo("LLM OPTIMIZATION STATISTICS")
    click.echo("=" * 60)

    click.echo("\nCall Statistics:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nCache Information:")
    for key, value in cache_info.items():
        if key in ("oldest_entry", "newest_entry") and value:
            click.echo(f"  {key}: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(value))}")
        else:
            click.echo(f"  {key}: {value}")

    if rate_info:
        click.echo("\nRate Limits:")
        for provider, info in rate_info.items():
            click.echo(f"  {provider}: {info['available']}/{info['max']} available")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
@click.option("--model", help="Clear cache for specific model only")
def llm_cache(project_name: str, model: Optional[str]):
    """Clear LLM response cache"""
    count = clear_llm_cache_internal(model=model)

    if model:
        click.echo(f"Cleared {count} cached responses for model '{model}'")
    else:
        click.echo(f"Cleared {count} cached responses")


def clear_llm_cache_internal(model: Optional[str] = None) -> int:
    """Clear LLM cache (internal, for testing).

    Args:
        model: Optional model name to clear cache for

    Returns:
        Number of entries cleared
    """
    optimizer = get_llm_optimizer()
    return optimizer.clear_cache(model=model)


def get_workflow_estimations() -> Dict[str, Dict[str, Any]]:
    """Get workflow cost estimations.

    Returns:
        Dict mapping workflow names to estimation dicts
    """
    return {
        "autonomous": {"calls": 50, "avg_tokens": 2000, "model": "gpt-3.5-turbo"},
        "writing_phase": {"calls": 20, "avg_tokens": 3000, "model": "gpt-4"},
    }


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to estimate")
def estimate_cost(project_name: str, workflow: str):
    """Estimate LLM API costs for workflow"""
    result = estimate_workflow_cost(workflow)

    click.echo(f"\nCost Estimate for '{workflow}':")
    click.echo(f"  Estimated calls: {result['calls']}")
    click.echo(f"  Average tokens/call: {result['avg_tokens']}")
    click.echo(f"  Total tokens: ~{result['total_tokens']:,}")
    click.echo(f"  Model: {result['model']}")
    click.echo(f"  Estimated cost: ${result['estimated_cost']:.2f}")
    click.echo("\nNote: This is a rough estimate. Actual costs may vary.")


def estimate_workflow_cost(workflow: str) -> Dict[str, Any]:
    """Estimate cost for workflow.

    Args:
        workflow: Workflow name

    Returns:
        Dict with estimation results

    Raises:
        ValueError: If workflow is unknown
    """
    optimizer = get_llm_optimizer()
    estimations = get_workflow_estimations()

    if workflow not in estimations:
        raise ValueError(f"Unknown workflow: {workflow}")

    est = estimations[workflow]
    total_tokens = est["calls"] * est["avg_tokens"]
    estimated_cost = optimizer._estimate_cost(est["model"], total_tokens, total_tokens // 2)

    return {
        "calls": est["calls"],
        "avg_tokens": est["avg_tokens"],
        "total_tokens": total_tokens,
        "model": est["model"],
        "estimated_cost": estimated_cost,
    }


def register_performance_cli(cli):
    """Register performance commands with main CLI"""
    cli.add_command(performance_cli)


if __name__ == "__main__":
    performance_cli()
