"""Command-line interface for novel writing harness."""

import logging
import sys
from difflib import get_close_matches
from pathlib import Path

import click
from dotenv import load_dotenv

from cli_agents import agents
from cli_autonomous import autonomous
from cli_checkpoint import checkpoint
from cli_config import config
from cli_drafts import drafts
from cli_logs import logs
from cli_memory import memory
from cli_pagination import cache, paginate
from cli_performance import performance_cli
from cli_proactive import app as proactive
from cli_run import run
from cli_setup import setup
from cli_summary import summary
from cli_templates import templates
from cli_templates_create import template_create
from cli_verify import verify
from cli_version import version as version_cmd
from cli_workflows import workflows
from core._version import get_version
from core.git_manager import create_git_manager
from core.llm_client import LLMConfig
from core.orchestrator import create_orchestrator
from core.storage import StorageConfig, StorageFactory

load_dotenv()


class ScribeCLI(click.Group):
    """Custom Click group with better error handling."""

    def get_command(self, ctx: click.Context, cmd_name: str):
        """Get command by name, with suggestions for typos."""
        # Try to get the command directly
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd

        # If not found, try to suggest similar commands
        available_commands = list(self.commands.keys())
        suggestions = get_close_matches(cmd_name, available_commands, n=3, cutoff=0.4)

        if suggestions:
            suggestion_text = "\nDid you mean one of these?\n"
            for suggestion in suggestions:
                suggestion_text += f"  • {suggestion}\n"
            ctx.fail(f"No such command '{cmd_name}'.{suggestion_text}")
        else:
            ctx.fail(
                f"No such command '{cmd_name}'. Use 'scribe --help' to see available commands."
            )


def configure_logging(verbose: int = 0, debug: bool = False) -> None:
    """Configure logging based on verbosity level."""
    log_level = logging.DEBUG if debug else logging.INFO

    if verbose == 0:
        log_format = "%(message)s"
    elif verbose == 1:
        log_format = "%(levelname)s: %(message)s"
    else:
        log_format = "%(levelname)s [%(name)s]: %(message)s"

    logging.basicConfig(
        level=log_level,
        format=log_format,
        stream=sys.stdout,
        force=True,
    )


@click.group(cls=ScribeCLI)
@click.option("-v", "--verbose", count=True, help="Increase verbosity (can be used multiple times)")
@click.option("-d", "--debug", is_flag=True, help="Enable debug mode")
@click.option(
    "--lang",
    type=click.Choice(["en", "zh-CN", "zh-TW"], case_sensitive=False),
    default=None,
    help="Language (en, zh-CN, zh-TW). Overrides project META.yaml.",
)
@click.version_option(version=get_version(), prog_name="scribe")
@click.option("--no-update-check", is_flag=True, help="Skip update check on startup")
@click.pass_context
def cli(
    ctx: click.Context, verbose: int, debug: bool, lang: str | None, no_update_check: bool
) -> None:
    """NovelScribe - AI-powered autonomous novel generation system."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["debug"] = debug
    ctx.obj["lang"] = lang

    configure_logging(verbose, debug)

    logger = logging.getLogger("scribe")
    logger.debug(f"Scribe CLI started (verbose={verbose}, debug={debug}, lang={lang})")

    if not no_update_check and not debug:
        try:
            from core.version import notify_if_update_available

            notify_if_update_available()
        except Exception:
            pass


@cli.command()
@click.argument("project_name")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--model", default="gpt-4-turbo-preview", help="LLM model to use")
@click.pass_context
def new(ctx: click.Context, project_name: str, provider: str, model: str) -> None:
    """Initialize a new novel project."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Creating new novel project: {project_name}")

        storage_config = StorageConfig(base_path=".novels")
        storage = StorageFactory.create(storage_config)

        project_path = Path(storage_config.base_path) / project_name
        project_path.mkdir(parents=True, exist_ok=True)

        meta_file = project_path / "META.yaml"
        if not meta_file.exists():
            storage.write_yaml(
                f"{project_name}/META.yaml",
                {
                    "name": project_name,
                    "created": str(Path.cwd()),
                    "provider": provider,
                    "model": model,
                    "status": "initialized",
                },
            )

        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="cli",
            description=f"Initialize project {project_name}",
        )

        logger.info(f"✅ Project '{project_name}' created successfully")
        logger.info(f"   Location: {project_path}")
        logger.info(f"   Next: Run 'scribe outline {project_name}' to generate outline")

    except Exception as e:
        logger.error(f"Failed to create project: {e}")
        if debug:
            logger.exception("Full error trace:")
        sys.exit(1)


@cli.command()
@click.argument("project_name")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--model", default="gpt-4-turbo-preview", help="LLM model to use")
@click.pass_context
def outline(ctx: click.Context, project_name: str, provider: str, model: str) -> None:
    """Generate novel outline for project."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Generating outline for: {project_name}")

        project_root = Path(__file__).parent
        base_path = project_root / ".novels"
        storage_config = StorageConfig(base_path=str(base_path))
        project_path = base_path / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            logger.info(f"Create it first with: scribe new {project_name}")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider, model=model)
        orchestrator = create_orchestrator(storage_config, llm_config)
        git_manager = create_git_manager(project_path, auto_commit=True)

        logger.info("Running outline generation workflow...")

        workflow_path = str(Path(__file__).parent / "workflows" / "outline_phase.yaml")
        context = orchestrator.execute_workflow(
            workflow_path=workflow_path,
            project_name=project_name,
        )

        git_manager.auto_commit_step(
            agent="outline_agent",
            description=f"Generate outline for {project_name}",
        )

        logger.info(f"✅ Outline generated successfully for '{project_name}'")
        logger.info(f"   Executed {len(context.history)} steps")

    except Exception as e:
        logger.error(f"Failed to generate outline: {e}")
        if debug:
            logger.exception("Full error trace:")
        sys.exit(1)


@cli.command()
@click.argument("project_name")
@click.option("--chapter", "-c", required=True, type=int, help="Chapter number to write")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def write(ctx: click.Context, project_name: str, chapter: int, provider: str) -> None:
    """Write a specific chapter."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Writing chapter {chapter} for: {project_name}")

        storage_config = StorageConfig(base_path=".novels")
        project_path = Path(storage_config.base_path) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider)
        orchestrator = create_orchestrator(storage_config, llm_config)
        git_manager = create_git_manager(project_path, auto_commit=True)

        logger.info(f"Running chapter {chapter} writing workflow...")

        workflow_path = str(Path(__file__).parent / "workflows" / "writing_phase.yaml")
        context = orchestrator.execute_workflow(
            workflow_path=workflow_path,
            project_name=project_name,
            initial_context={"chapter": chapter},
        )

        git_manager.auto_commit_step(
            agent="writer_agent",
            description=f"Write chapter {chapter}",
        )

        logger.info(f"✅ Chapter {chapter} written successfully for '{project_name}'")
        logger.info(f"   Executed {len(context.history)} steps")

    except Exception as e:
        logger.error(f"Failed to write chapter: {e}")
        if debug:
            logger.exception("Full error trace:")
        sys.exit(1)


@cli.command()
@click.argument("project_name")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--chapters", "-n", type=int, help="Number of chapters to generate")
@click.pass_context
def auto(ctx: click.Context, project_name: str, provider: str, chapters: int | None) -> None:
    """Run autonomous novel generation pipeline."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        logger.info(f"Running autonomous pipeline for: {project_name}")

        storage_config = StorageConfig(base_path=".novels")
        project_path = Path(storage_config.base_path) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            logger.info(f"Create it first with: scribe new {project_name}")
            sys.exit(1)

        config = AutonomousConfig(
            project_name=project_name,
            provider=provider,
            max_chapters=chapters,
        )

        executor = AutonomousExecutor(config=config, storage_path=Path(".novels"))

        logger.info("Running autonomous workflow...")

        result = executor.execute()

        if result.success:
            logger.info(f"✅ Autonomous pipeline completed for '{project_name}'")
            logger.info(f"   Completed phases: {', '.join(result.completed_phases)}")
            logger.info(f"   Project: {project_path}")
        else:
            logger.error(f"❌ Autonomous pipeline failed for '{project_name}'")
            if result.error:
                logger.error(f"   Error: {result.error}")

    except Exception as e:
        logger.error(f"Autonomous pipeline failed: {e}")
        if debug:
            logger.exception("Full error trace:")
        sys.exit(1)


@cli.command()
@click.argument("project_name")
@click.pass_context
def status(ctx: click.Context, project_name: str) -> None:
    """Show project status."""
    logger = logging.getLogger("scribe")

    try:
        storage_config = StorageConfig(base_path=".novels")
        project_path = Path(storage_config.base_path) / project_name

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        git_manager = create_git_manager(project_path, auto_commit=False)
        repo_status = git_manager.status()

        logger.info(f"Project: {project_name}")
        logger.info(f"Location: {project_path}")
        logger.info(f"Git Repository: {'Yes' if repo_status['is_repository'] else 'No'}")

        if repo_status["is_repository"]:
            logger.info(f"Current Branch: {repo_status['current_branch']}")
            logger.info(f"Current Commit: {repo_status['current_commit']}")

            if repo_status["has_changes"]:
                logger.info(f"Uncommitted Changes: {len(repo_status['changed_files'])} files")
            else:
                logger.info("Uncommitted Changes: None")

            tags = git_manager.get_tags()
            if tags:
                logger.info(f"Milestones: {', '.join(tag['name'] for tag in tags)}")

    except Exception as e:
        logger.error(f"Failed to get status: {e}")
        sys.exit(1)


@cli.command()
@click.pass_context
def version(ctx: click.Context) -> None:
    """Show version information."""
    logger = logging.getLogger("scribe")
    logger.info("Novel Writing Harness v0.1.0")
    logger.info("Python-based AI novel generation system")
    logger.info("")
    logger.info("Components:")
    logger.info("  - Multi-runtime LLM support (OpenAI, Claude, Gemini, Ollama, LM Studio)")
    logger.info("  - Declarative agent system (Markdown)")
    logger.info("  - Declarative workflow engine (YAML)")
    logger.info("  - Thin orchestrator pattern")
    logger.info("  - Git integration with atomic commits")
    logger.info("  - Scalable to 3M words")


cli.add_command(agents)
cli.add_command(workflows)
cli.add_command(run)
cli.add_command(autonomous)
cli.add_command(verify)
cli.add_command(drafts)
cli.add_command(paginate)
cli.add_command(cache)
cli.add_command(summary)
cli.add_command(memory)
cli.add_command(performance_cli)
cli.add_command(version_cmd)
cli.add_command(config)
cli.add_command(setup)
cli.add_command(logs)
cli.add_command(templates)
cli.add_command(template_create)
cli.add_command(proactive)
cli.add_command(checkpoint)


def main() -> int:
    """Main entry point for CLI with improved error handling."""
    try:
        cli(obj={}, standalone_mode=False)
        return 0
    except click.exceptions.UsageError as e:
        # Format usage errors nicely
        click.echo(f"❌ Usage Error: {e.message}", err=True)
        click.echo("\n💡 Run 'scribe --help' to see available commands.", err=True)
        return 1
    except click.exceptions.ClickException as e:
        # Handle other Click exceptions
        e.show()
        return 1
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        click.echo("\n⚠️  Operation cancelled by user.", err=True)
        return 130
    except Exception as e:
        # Handle unexpected errors with a clean message
        click.echo(f"❌ Unexpected error: {str(e)}", err=True)

        import logging

        logger = logging.getLogger("scribe")
        logger.debug("Full traceback:", exc_info=True)

        click.echo("\n💡 Run with -v or -vv for more verbose output.", err=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
