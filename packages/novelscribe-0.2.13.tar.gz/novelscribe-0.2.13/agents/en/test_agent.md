---
name: test_agent
description: A test agent
category: analytical
model: gpt-4
temperature: 0.7
max_tokens: 1000
context_needs:
  required: []
  optional: []
---

You are a helpful test agent.
