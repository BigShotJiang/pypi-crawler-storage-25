"""Comprehensive tests for cli_run module."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from cli_run import infer_type, parse_vars, run, set_nested_dict


class TestInferType:
    """Test infer_type helper function."""

    def test_true_lowercase(self):
        assert infer_type("true") is True

    def test_true_mixed_case(self):
        assert infer_type("True") is True

    def test_false_lowercase(self):
        assert infer_type("false") is False

    def test_false_mixed_case(self):
        assert infer_type("False") is False

    def test_integer(self):
        assert infer_type("42") == 42

    def test_float(self):
        assert infer_type("3.14") == 3.14

    def test_string(self):
        assert infer_type("hello") == "hello"

    def test_negative_not_digit(self):
        assert infer_type("-5") == -5.0

    def test_zero(self):
        assert infer_type("0") == 0


class TestSetNestedDict:
    """Test set_nested_dict helper function."""

    def test_simple_key(self):
        d = {}
        set_nested_dict(d, "key", "value")
        assert d == {"key": "value"}

    def test_nested_key(self):
        d = {}
        set_nested_dict(d, "a.b.c", "value")
        assert d == {"a": {"b": {"c": "value"}}}

    def test_existing_nested(self):
        d = {"a": {"b": 1}}
        set_nested_dict(d, "a.c", 2)
        assert d == {"a": {"b": 1, "c": 2}}


class TestParseVars:
    """Test parse_vars helper function."""

    def test_simple_key_value(self):
        result = parse_vars(["key=value"])
        assert result == {"key": "value"}

    def test_multiple_vars(self):
        result = parse_vars(["a=1", "b=true", "c=3.14"])
        assert result == {"a": 1, "b": True, "c": 3.14}

    def test_dot_notation(self):
        result = parse_vars(["project.name=test"])
        assert result == {"project": {"name": "test"}}

    def test_invalid_format_raises(self):
        with pytest.raises(click.BadParameter):
            parse_vars(["no_equals"])

    def test_value_with_equals(self):
        result = parse_vars(["key=val=ue"])
        assert result == {"key": "val=ue"}


class TestRunWorkflowCommand:
    """Test run workflow command."""

    def _mock_deps(self):
        storage = MagicMock()
        storage.read_yaml.return_value = {"variables": {"genre": "scifi"}}
        workflow_mock = MagicMock()
        workflow_mock.name = "test_wf"
        workflow_mock.variables = {"template": "default"}
        loader = MagicMock()
        loader.load_workflow.return_value = workflow_mock
        loader.load_all_workflows.return_value = [workflow_mock]
        return storage, loader

    def test_missing_novel(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            with runner.isolated_filesystem():
                result = runner.invoke(run, ["workflow", "test_wf", "--novel", "missing"])
                assert result.exit_code != 0

    def test_missing_workflows_dir(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                result = runner.invoke(run, ["workflow", "test_wf", "--novel", "myproj"])
                assert result.exit_code != 0

    def test_workflow_not_found(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.WorkflowLoader") as mock_wl,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            loader = mock_wl.return_value
            loader.load_workflow.return_value = None
            loader.load_all_workflows.return_value = []
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("workflows").mkdir()
                result = runner.invoke(run, ["workflow", "missing_wf", "--novel", "myproj"])
                assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.WorkflowLoader") as mock_wl,
            patch("cli_run.LLMConfig"),
            patch("cli_run.create_orchestrator") as mock_co,
            patch("cli_run.create_git_manager") as mock_gm,
        ):
            storage = MagicMock()
            storage.read_yaml.return_value = {"variables": {"genre": "scifi"}}
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = storage
            wf = MagicMock()
            wf.name = "test_wf"
            wf.variables = {"template": "default"}
            loader = mock_wl.return_value
            loader.load_workflow.return_value = wf
            mock_co.return_value.execute_workflow.return_value = {
                "success": True,
                "history": ["step1", "step2"],
            }
            mock_gm.return_value = MagicMock()
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("workflows").mkdir()
                result = runner.invoke(
                    run, ["workflow", "test_wf", "--novel", "myproj", "--var", "key=val"]
                )
                assert result.exit_code == 0

    def test_workflow_with_warnings(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.WorkflowLoader") as mock_wl,
            patch("cli_run.LLMConfig"),
            patch("cli_run.create_orchestrator") as mock_co,
            patch("cli_run.create_git_manager") as mock_gm,
        ):
            storage = MagicMock()
            storage.read_yaml.return_value = {}
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = storage
            wf = MagicMock()
            wf.name = "test_wf"
            wf.variables = {}
            loader = mock_wl.return_value
            loader.load_workflow.return_value = wf
            mock_co.return_value.execute_workflow.return_value = {"success": False, "history": []}
            mock_gm.return_value = MagicMock()
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("workflows").mkdir()
                result = runner.invoke(run, ["workflow", "test_wf", "--novel", "myproj"])
                assert result.exit_code != 0

    def test_bad_parameter(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.WorkflowLoader") as mock_wl,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            wf = MagicMock()
            wf.name = "test_wf"
            wf.variables = {}
            loader = mock_wl.return_value
            loader.load_workflow.return_value = wf
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("workflows").mkdir()
                result = runner.invoke(
                    run, ["workflow", "test_wf", "--novel", "myproj", "--var", "no_equals"]
                )
                assert result.exit_code != 0

    def test_debug_exception(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.side_effect = RuntimeError("boom")
            with runner.isolated_filesystem():
                result = runner.invoke(
                    run, ["workflow", "test_wf", "--novel", "myproj"], obj={"debug": True}
                )
                assert result.exit_code != 0


class TestRunAgentCommand:
    """Test run agent command."""

    def test_missing_novel(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            with runner.isolated_filesystem():
                result = runner.invoke(run, ["agent", "writer", "--novel", "missing"])
                assert result.exit_code != 0

    def test_missing_agents_dir(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                result = runner.invoke(run, ["agent", "writer", "--novel", "myproj"])
                assert result.exit_code != 0

    def test_agent_not_found(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.AgentRegistry") as mock_ar,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            reg = mock_ar.return_value
            reg.get_agent.return_value = None
            reg.get_all_agents.return_value = []
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("agents").mkdir()
                result = runner.invoke(run, ["agent", "missing_agent", "--novel", "myproj"])
                assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.AgentRegistry") as mock_ar,
            patch("cli_run.LLMConfig"),
            patch("cli_run.AgentSystemIntegration") as mock_asi,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            agent_mock = MagicMock()
            agent_mock.name = "writer"
            reg = mock_ar.return_value
            reg.get_agent.return_value = agent_mock
            integ = mock_asi.return_value
            integ.execute_agent.return_value = MagicMock(output={"text": "hello"}, error=None)
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("agents").mkdir()
                result = runner.invoke(
                    run, ["agent", "writer", "--novel", "myproj", "--input", "key=val"]
                )
                assert result.exit_code == 0

    def test_with_error_in_result(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.AgentRegistry") as mock_ar,
            patch("cli_run.LLMConfig"),
            patch("cli_run.AgentSystemIntegration") as mock_asi,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            agent_mock = MagicMock()
            agent_mock.name = "writer"
            reg = mock_ar.return_value
            reg.get_agent.return_value = agent_mock
            integ = mock_asi.return_value
            integ.execute_agent.return_value = MagicMock(
                output={"text": "hello"}, error="some error"
            )
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("agents").mkdir()
                result = runner.invoke(run, ["agent", "writer", "--novel", "myproj"])
                assert result.exit_code == 0

    def test_with_no_output(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.AgentRegistry") as mock_ar,
            patch("cli_run.LLMConfig"),
            patch("cli_run.AgentSystemIntegration") as mock_asi,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            agent_mock = MagicMock()
            reg = mock_ar.return_value
            reg.get_agent.return_value = agent_mock
            integ = mock_asi.return_value
            integ.execute_agent.return_value = MagicMock(output=None, error=None)
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("agents").mkdir()
                result = runner.invoke(run, ["agent", "writer", "--novel", "myproj"])
                assert result.exit_code == 0

    def test_bad_parameter(self):
        runner = CliRunner()
        with (
            patch("cli_run.StorageConfig") as mock_sc,
            patch("cli_run.StorageFactory") as mock_sf,
            patch("cli_run.AgentRegistry") as mock_ar,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.return_value = MagicMock()
            agent_mock = MagicMock()
            reg = mock_ar.return_value
            reg.get_agent.return_value = agent_mock
            with runner.isolated_filesystem():
                Path(".novels/myproj").mkdir(parents=True)
                Path("agents").mkdir()
                result = runner.invoke(
                    run, ["agent", "writer", "--novel", "myproj", "--input", "no_equals"]
                )
                assert result.exit_code != 0

    def test_debug_exception(self):
        runner = CliRunner()
        with patch("cli_run.StorageConfig") as mock_sc, patch("cli_run.StorageFactory") as mock_sf:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sf.create.side_effect = RuntimeError("boom")
            with runner.isolated_filesystem():
                result = runner.invoke(
                    run, ["agent", "writer", "--novel", "myproj"], obj={"debug": True}
                )
                assert result.exit_code != 0
