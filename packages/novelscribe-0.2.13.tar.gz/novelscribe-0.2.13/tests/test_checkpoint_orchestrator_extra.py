"""Coverage tests for core/checkpoint_orchestrator.py."""

from unittest.mock import MagicMock

from core.checkpoint_orchestrator import (
    CheckpointOrchestrator,
    CheckpointStatus,
    create_checkpoint_orchestrator,
)


def _plan(title="Test Plan", **kwargs):
    defaults = {"title": title, "pov": "Alice", "pacing": "moderate"}
    defaults.update(kwargs)
    return defaults


def _present_checkpoint(orchestrator, phase="outline_phase", chapter=None, plan=None):
    plan = plan or _plan()
    return orchestrator.present_checkpoint(
        phase=phase,
        chapter=chapter,
        plan_content=plan,
        context_summary={"project_name": "test"},
    )


class TestShouldPauseAtPhase:
    def test_delegates_to_schedule(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.schedule = MagicMock()
        orchestrator.schedule.should_pause_at_phase.return_value = True
        assert orchestrator.should_pause_at_phase("outline_phase") is True


class TestGetCheckpointId:
    def test_with_checkpoint_in_schedule(self):
        orchestrator = CheckpointOrchestrator()
        mock_cp = MagicMock()
        mock_cp.checkpoint_id = "CP3"
        mock_cp.is_repeating = False
        orchestrator.schedule = MagicMock()
        orchestrator.schedule.get_checkpoint_for_phase.return_value = mock_cp
        result = orchestrator.get_checkpoint_id("outline_phase")
        assert result == "CP3"

    def test_repeating_with_chapter(self):
        orchestrator = CheckpointOrchestrator()
        mock_cp = MagicMock()
        mock_cp.checkpoint_id = "CP5"
        mock_cp.is_repeating = True
        orchestrator.schedule = MagicMock()
        orchestrator.schedule.get_checkpoint_for_phase.return_value = mock_cp
        result = orchestrator.get_checkpoint_id("writing_phase", chapter=3)
        assert result == "CP5_ch3"

    def test_no_checkpoint_in_schedule(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.schedule = MagicMock()
        orchestrator.schedule.get_checkpoint_for_phase.return_value = None
        result = orchestrator.get_checkpoint_id("unknown_phase")
        assert result == "cp_unknown_phase"


class TestPresentCheckpoint:
    def test_present_with_alternatives(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        proposal = orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=_plan(),
            alternatives=[
                {"plan": _plan(title="Alt A"), "confidence": 0.7, "tradeoff": "Less detail"}
            ],
        )
        assert proposal.checkpoint_id is not None
        assert len(proposal.alternatives) == 1

    def test_present_without_alternatives(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.9)

        proposal = orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=_plan(),
        )
        assert len(proposal.alternatives) == 0
        assert proposal.confidence == 0.9


class TestIncorporateDecision:
    def test_approve(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)

        response = orchestrator.incorporate_decision(
            orchestrator.get_checkpoint_id("outline_phase"),
            {"type": "approve"},
        )
        assert response.applied is True

    def test_modify(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)

        response = orchestrator.incorporate_decision(
            orchestrator.get_checkpoint_id("outline_phase"),
            {"type": "modify", "modified_content": {"title": "Changed"}},
        )
        assert response is not None

    def test_reject(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)

        response = orchestrator.incorporate_decision(
            orchestrator.get_checkpoint_id("outline_phase"),
            {"type": "reject"},
        )
        assert response is not None

    def test_guidance(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)

        response = orchestrator.incorporate_decision(
            orchestrator.get_checkpoint_id("outline_phase"),
            {"type": "guidance", "guidance_text": "Make it darker"},
        )
        assert response is not None

    def test_unknown_checkpoint_raises(self):
        orchestrator = CheckpointOrchestrator()
        try:
            orchestrator.incorporate_decision("nonexistent", {"type": "approve"})
            assert False, "Should raise ValueError"
        except ValueError:
            pass

    def test_with_background_checkpointer(self):
        mock_bp = MagicMock()
        orchestrator = CheckpointOrchestrator(background_checkpointer=mock_bp)
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)

        orchestrator.incorporate_decision(
            orchestrator.get_checkpoint_id("outline_phase"),
            {"type": "approve"},
        )
        mock_bp.record_approval.assert_called_once()


class TestAwaitDecision:
    def test_timeout_returns_timeout_status(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")

        result = orchestrator.await_decision(cp_id, timeout=0.1)
        assert result is not None
        assert result["status"] == "timeout"

    def test_no_state_returns_none(self):
        orchestrator = CheckpointOrchestrator()
        result = orchestrator.await_decision("nonexistent")
        assert result is None

    def test_auto_approve_on_expired_deadline(self):
        mock_bp = MagicMock()
        mock_bp.get_deadline_status.return_value = {"is_expired": True}
        mock_bp.should_auto_approve.return_value = (True, MagicMock(value="high_confidence"))

        orchestrator = CheckpointOrchestrator(background_checkpointer=mock_bp)
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.95)

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")

        result = orchestrator.await_decision(cp_id, timeout=0.5)
        assert result is not None
        assert result["status"] == CheckpointStatus.AUTO_APPROVED


class TestGetCheckpointState:
    def test_existing(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        state = orchestrator.get_checkpoint_state(cp_id)
        assert state is not None
        assert state["status"] == CheckpointStatus.PENDING

    def test_nonexistent(self):
        orchestrator = CheckpointOrchestrator()
        assert orchestrator.get_checkpoint_state("missing") is None


class TestGetPendingCheckpoints:
    def test_returns_pending(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)

        _present_checkpoint(orchestrator, phase="outline_phase")
        _present_checkpoint(orchestrator, phase="character_phase")

        pending = orchestrator.get_pending_checkpoints()
        assert len(pending) == 2

    def test_empty(self):
        orchestrator = CheckpointOrchestrator()
        assert orchestrator.get_pending_checkpoints() == []


class TestGetExplanation:
    def test_existing_proposal(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)
        orchestrator.qa_handler = MagicMock()
        orchestrator.qa_handler.answer_question.return_value = "Because reasons"

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")

        result = orchestrator.get_explanation(cp_id, "why this plan?")
        assert result == "Because reasons"

    def test_no_proposal(self):
        orchestrator = CheckpointOrchestrator()
        result = orchestrator.get_explanation("missing", "why?")
        assert result is None


class TestGenerateWhatIf:
    def test_existing_proposal(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.85)
        orchestrator.qa_handler = MagicMock()
        orchestrator.qa_handler.answer_question.return_value = "If you change POV..."

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")

        result = orchestrator.generate_what_if(cp_id, "change POV to Bob")
        assert result is not None
        assert result["modification"] == "change POV to Bob"

    def test_no_proposal(self):
        orchestrator = CheckpointOrchestrator()
        result = orchestrator.generate_what_if("missing", "change")
        assert result is None


class TestCompareAlternatives:
    def test_primary_best(self):
        orchestrator = CheckpointOrchestrator()
        orchestrator.confidence_calculator = MagicMock()
        orchestrator.confidence_calculator.calculate.return_value = MagicMock(total=0.9)

        _present_checkpoint(orchestrator)
        cp_id = orchestrator.get_checkpoint_id("outline_phase")

        result = orchestrator.compare_alternatives(cp_id)
        assert result is not None
        assert result["recommendation"] == "Primary"

    def test_no_proposal(self):
        orchestrator = CheckpointOrchestrator()
        result = orchestrator.compare_alternatives("missing")
        assert result is None


class TestFactoryFunction:
    def test_create_checkpoint_orchestrator(self):
        orchestrator = create_checkpoint_orchestrator()
        assert isinstance(orchestrator, CheckpointOrchestrator)
