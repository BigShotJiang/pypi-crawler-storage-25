"""Comprehensive tests for core/agent_registry.py to bring coverage above 85%."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from core.agent import Agent, AgentCategory
from core.agent_registry import AgentRegistry
from core.language_config import LanguageCode


def _make_agent(name="test_agent", category=AgentCategory.CREATIVE, deps=None, **kw):
    return Agent(
        name=name,
        description=f"Test agent {name}",
        category=category,
        dependencies=deps or [],
        instructions=f"Instructions for {name}",
        **kw,
    )


def _write_agent_md(
    path: Path, name: str, category: str = "creative", deps: list | None = None, extra: str = ""
):
    path.mkdir(parents=True, exist_ok=True)
    deps_yaml = ""
    if deps:
        deps_yaml = "dependencies:\n" + "\n".join(f"  - {d}" for d in deps)
    else:
        deps_yaml = "dependencies: []"
    content = f"""---
name: {name}
description: Test agent {name}
category: {category}
{deps_yaml}
{extra}
---
You are {name}.
"""
    (path / f"{name}.md").write_text(content, encoding="utf-8")


class TestAgentRegistryInit:
    def test_init_loads_agents(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent("writer") is not None

    def test_init_default_language(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        assert registry.language == LanguageCode.EN

    def test_init_custom_language(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir, language=LanguageCode.ZH_CN)
        assert registry.language == LanguageCode.ZH_CN

    def test_init_empty_dir(self, tmp_path):
        agents_dir = tmp_path / "empty_agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent_count() == 0

    def test_init_with_string_path(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(str(agents_dir))
        assert registry.get_agent("writer") is not None

    @patch("core.agent_registry.AgentLoader")
    def test_load_agents_stores_by_name(self, mock_loader_cls, tmp_path):
        agent1 = _make_agent("alpha")
        agent2 = _make_agent("beta")
        mock_loader = MagicMock()
        mock_loader.load_all_agents.return_value = [agent1, agent2]
        mock_loader_cls.return_value = mock_loader
        registry = AgentRegistry.__new__(AgentRegistry)
        registry.agents_dir = tmp_path
        registry.language = LanguageCode.EN
        registry.loader = mock_loader
        registry._agents = {}
        registry._load_agents()
        assert "alpha" in registry._agents
        assert "beta" in registry._agents


class TestAgentRegistryGetAgent:
    def test_get_agent_found(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        agent = registry.get_agent("writer")
        assert agent is not None
        assert agent.name == "writer"

    def test_get_agent_not_found(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent("nonexistent") is None

    def test_get_all_agents(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        all_agents = registry.get_all_agents()
        assert len(all_agents) >= 2

    def test_agent_exists(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        assert registry.agent_exists("writer") is True
        assert registry.agent_exists("missing") is False


class TestAgentRegistryCategory:
    def test_get_agents_by_category(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer", category="creative")
        _write_agent_md(agents_dir, "analyst", category="analytical")
        registry = AgentRegistry(agents_dir)
        creative = registry.get_agents_by_category(AgentCategory.CREATIVE)
        assert any(a.name == "writer" for a in creative)

    def test_get_agents_by_category_empty(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer", category="creative")
        registry = AgentRegistry(agents_dir)
        validation = registry.get_agents_by_category(AgentCategory.VALIDATION)
        assert validation == []


class TestAgentRegistryDependencies:
    def test_validate_dependencies_all_present(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        agent = registry.get_agent("writer")
        if agent:
            agent.dependencies = []
        missing = registry.validate_dependencies("writer")
        assert missing == []

    def test_validate_dependencies_missing(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        agent = registry.get_agent("writer")
        if agent:
            agent.dependencies = ["missing_agent"]
        missing = registry.validate_dependencies("writer")
        assert "missing_agent" in missing

    def test_validate_dependencies_agent_not_found(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        missing = registry.validate_dependencies("ghost")
        assert "Agent not found: ghost" in missing

    def test_validate_dependencies_multiple_missing(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        agent = registry.get_agent("writer")
        if agent:
            agent.dependencies = ["dep1", "dep2", "dep3"]
        missing = registry.validate_dependencies("writer")
        assert len(missing) == 3

    def test_get_execution_order(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        writer = registry.get_agent("writer")
        editor = registry.get_agent("editor")
        if writer:
            writer.dependencies = []
        if editor:
            editor.dependencies = []
        order = registry.get_execution_order(["writer", "editor"])
        assert "writer" in order
        assert "editor" in order

    def test_get_execution_order_with_deps(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        writer = registry.get_agent("writer")
        editor = registry.get_agent("editor")
        if writer:
            writer.dependencies = []
        if editor:
            editor.dependencies = ["writer"]
        order = registry.get_execution_order(["editor", "writer"])
        assert order.index("writer") < order.index("editor")

    def test_get_execution_order_circular(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "a")
        _write_agent_md(agents_dir, "b")
        registry = AgentRegistry(agents_dir)
        a = registry.get_agent("a")
        b = registry.get_agent("b")
        if a:
            a.dependencies = ["b"]
        if b:
            b.dependencies = ["a"]
        with pytest.raises(ValueError, match="Circular dependency"):
            registry.get_execution_order(["a", "b"])

    def test_get_execution_order_unknown_agent_in_names(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        order = registry.get_execution_order(["writer", "unknown_agent"])
        assert "writer" in order
        assert "unknown_agent" in order

    def test_get_execution_order_dep_not_in_agent_names(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        editor = registry.get_agent("editor")
        if editor:
            editor.dependencies = ["writer"]
        order = registry.get_execution_order(["editor"])
        assert "editor" in order
        assert "writer" not in order

    def test_get_execution_order_single_agent(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "solo")
        registry = AgentRegistry(agents_dir)
        agent = registry.get_agent("solo")
        if agent:
            agent.dependencies = []
        order = registry.get_execution_order(["solo"])
        assert order == ["solo"]


class TestAgentRegistryListAndCount:
    def test_list_agents(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        listing = registry.list_agents()
        assert "writer" in listing
        assert "editor" in listing
        assert listing["writer"] == "Test agent writer"

    def test_get_agent_count(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        _write_agent_md(agents_dir, "editor")
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent_count() >= 2

    def test_list_agents_empty(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        assert registry.list_agents() == {}

    def test_get_agent_count_zero(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent_count() == 0


class TestAgentRegistryReload:
    def test_reload_all(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        count_before = registry.get_agent_count()
        _write_agent_md(agents_dir, "editor")
        registry.reload_all()
        assert registry.get_agent_count() >= count_before + 1

    def test_reload_agent_found(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        agent = registry.reload_agent("writer")
        assert agent is not None
        assert agent.name == "writer"

    def test_reload_agent_not_found(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        assert registry.reload_agent("ghost") is None

    def test_reload_all_clears_existing(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "a")
        _write_agent_md(agents_dir, "b")
        registry = AgentRegistry(agents_dir)
        assert registry.get_agent_count() >= 2
        (agents_dir / "a.md").unlink()
        registry.reload_all()
        assert registry.get_agent("a") is None
        assert registry.get_agent("b") is not None


class TestAgentRegistryLanguages:
    def test_get_supported_languages(self, tmp_path):
        agents_dir = tmp_path / "agents"
        en_dir = agents_dir / "en"
        _write_agent_md(en_dir, "writer")
        registry = AgentRegistry(agents_dir)
        langs = registry.get_supported_languages()
        assert "en" in langs

    def test_get_supported_languages_empty(self, tmp_path):
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        registry = AgentRegistry(agents_dir)
        langs = registry.get_supported_languages()
        assert isinstance(langs, list)

    def test_get_supported_languages_multiple(self, tmp_path):
        agents_dir = tmp_path / "agents"
        en_dir = agents_dir / "en"
        zh_dir = agents_dir / "zh-CN"
        _write_agent_md(en_dir, "writer")
        _write_agent_md(zh_dir, "writer")
        registry = AgentRegistry(agents_dir)
        langs = registry.get_supported_languages()
        assert "en" in langs
        assert "zh-CN" in langs

    def test_get_supported_languages_dir_exists_no_md(self, tmp_path):
        agents_dir = tmp_path / "agents"
        en_dir = agents_dir / "en"
        en_dir.mkdir(parents=True)
        registry = AgentRegistry(agents_dir)
        langs = registry.get_supported_languages()
        assert "en" not in langs

    def test_switch_language_same(self, tmp_path):
        agents_dir = tmp_path / "agents"
        _write_agent_md(agents_dir, "writer")
        registry = AgentRegistry(agents_dir)
        original_loader = registry.loader
        registry.switch_language(LanguageCode.EN)
        assert registry.loader is original_loader

    def test_switch_language_different(self, tmp_path):
        agents_dir = tmp_path / "agents"
        en_dir = agents_dir / "en"
        _write_agent_md(en_dir, "writer")
        zh_dir = agents_dir / "zh-CN"
        _write_agent_md(zh_dir, "writer")
        registry = AgentRegistry(agents_dir)
        registry.switch_language(LanguageCode.ZH_CN)
        assert registry.language == LanguageCode.ZH_CN
        assert registry.loader is not None
