"""
Tests for CLI memory commands
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from cli_memory import memory


class TestMemoryGroup:
    """Test cases for memory command group"""

    def test_memory_group_exists(self):
        """Test that memory command group exists"""
        assert memory is not None

    def test_memory_help(self):
        """Test memory command help"""
        runner = CliRunner()
        result = runner.invoke(memory, ["--help"])

        assert result.exit_code == 0
        assert "memory" in result.output.lower() or "Memory" in result.output

    def test_memory_subcommands_exist(self):
        """Test that memory subcommands are registered"""
        runner = CliRunner()
        result = runner.invoke(memory, ["--help"])

        assert result.exit_code == 0
        output = result.output.lower()
        # Should show available commands
        assert "profile" in output or "stats" in output or "prune" in output


class TestProfileCommand:
    """Test cases for profile command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_profile_help(self, runner):
        """Test profile command help"""
        result = runner.invoke(memory, ["profile", "--help"])

        assert result.exit_code == 0
        assert "duration" in result.output.lower()
        assert "interval" in result.output.lower()

    def test_profile_missing_args(self, runner):
        """Test profile command with missing arguments"""
        result = runner.invoke(memory, ["profile"])

        assert result.exit_code != 0

    def test_profile_with_defaults(self, runner):
        """Test profile command with default options"""
        with patch("cli_memory.time.sleep"):
            with patch("cli_memory.MemoryProfiler") as mock_profiler:
                mock_instance = MagicMock()
                mock_instance.take_snapshot.return_value = MagicMock(
                    total_memory_mb=100.0, available_memory_mb=800.0, system_memory_mb=16000.0
                )
                mock_instance.get_memory_report.return_value = {
                    "summary": {
                        "current_memory_mb": 100.0,
                        "average_memory_mb": 95.0,
                        "peak_memory_mb": 110.0,
                        "total_change_mb": 10.0,
                    },
                    "leaks_detected": [],
                }
                mock_instance.start_profiling = MagicMock()
                mock_instance.stop_profiling = MagicMock()
                mock_profiler.return_value = mock_instance

                result = runner.invoke(
                    memory, ["profile", "test-project", "--duration", "10", "--interval", "5"]
                )

                # Should handle gracefully
                assert result.exit_code in [0, 1]

    def test_profile_with_custom_duration(self, runner):
        """Test profile command with custom duration"""
        with patch("time.sleep"):
            result = runner.invoke(
                memory, ["profile", "test-project", "--duration", "30", "--interval", "10"]
            )

        assert result.exit_code in [0, 1]

    def test_profile_with_custom_interval(self, runner):
        """Test profile command with custom interval"""
        with patch("time.sleep"):
            result = runner.invoke(
                memory, ["profile", "test-project", "--duration", "60", "--interval", "15"]
            )

        assert result.exit_code in [0, 1]

    def test_profile_with_leaks_detected(self, runner):
        """Test profile command with memory leaks detected"""
        with patch("cli_memory.time.sleep"):
            with patch("cli_memory.MemoryProfiler") as mock_profiler:
                mock_instance = MagicMock()
                mock_instance.take_snapshot.return_value = MagicMock(total_memory_mb=100.0)
                mock_instance.get_memory_report.return_value = {
                    "summary": {
                        "current_memory_mb": 100.0,
                        "average_memory_mb": 95.0,
                        "peak_memory_mb": 110.0,
                        "total_change_mb": 10.0,
                    },
                    "leaks_detected": ["Leak 1", "Leak 2"],
                }
                mock_instance.start_profiling = MagicMock()
                mock_instance.stop_profiling = MagicMock()
                mock_profiler.return_value = mock_instance

                result = runner.invoke(
                    memory, ["profile", "test-project", "--duration", "10", "--interval", "5"]
                )

                # Should handle gracefully
                assert result.exit_code in [0, 1]


class TestStatsCommand:
    """Test cases for stats command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_stats_help(self, runner):
        """Test stats command help"""
        result = runner.invoke(memory, ["stats", "--help"])

        assert result.exit_code == 0

    def test_stats_missing_args(self, runner):
        """Test stats command with missing arguments"""
        result = runner.invoke(memory, ["stats"])

        assert result.exit_code != 0

    def test_stats_basic(self, runner):
        """Test stats command basic execution"""
        with patch("cli_memory.MemoryProfiler") as mock_profiler:
            mock_instance = MagicMock()
            mock_instance.take_snapshot.return_value = MagicMock(
                total_memory_mb=100.0,
                available_memory_mb=800.0,
                system_memory_mb=16000.0,
                process_memory_mb=50.0,
                gc_stats=MagicMock(collected=10, threshold=100),
            )
            mock_profiler.return_value = mock_instance

            result = runner.invoke(memory, ["stats", "test-project"])

            # Should handle gracefully
            assert result.exit_code in [0, 1]

    def test_stats_with_format_json(self, runner):
        """Test stats command with JSON format"""
        result = runner.invoke(memory, ["stats", "test-project", "--format", "json"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_stats_with_format_text(self, runner):
        """Test stats command with text format"""
        result = runner.invoke(memory, ["stats", "test-project", "--format", "text"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]


class TestPruneCommand:
    """Test cases for prune command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_prune_help(self, runner):
        """Test prune command help"""
        result = runner.invoke(memory, ["prune", "--help"])

        assert result.exit_code == 0
        assert "strategy" in result.output.lower()

    def test_prune_missing_args(self, runner):
        """Test prune command with missing arguments"""
        result = runner.invoke(memory, ["prune"])

        assert result.exit_code != 0

    def test_prune_basic(self, runner):
        """Test prune command basic execution"""
        with patch("cli_memory.ContextCompressor") as mock_compressor:
            mock_instance = MagicMock()
            mock_instance.compress.return_value = MagicMock(
                context_str="compressed",
                compressed_tokens=100,
                tier_used="none",
            )
            mock_compressor.return_value = mock_instance

            result = runner.invoke(memory, ["prune", "test-project"])

            assert result.exit_code in [0, 1]

    def test_prune_with_strategy_age(self, runner):
        """Test prune command with age strategy"""
        result = runner.invoke(memory, ["prune", "test-project", "--strategy", "age"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_prune_with_strategy_size(self, runner):
        """Test prune command with size strategy"""
        result = runner.invoke(memory, ["prune", "test-project", "--strategy", "size"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_prune_with_strategy_relevance(self, runner):
        """Test prune command with relevance strategy"""
        result = runner.invoke(memory, ["prune", "test-project", "--strategy", "relevance"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_prune_with_strategy_hybrid(self, runner):
        """Test prune command with hybrid strategy"""
        result = runner.invoke(memory, ["prune", "test-project", "--strategy", "hybrid"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_prune_with_max_tokens(self, runner):
        """Test prune command with max tokens"""
        result = runner.invoke(memory, ["prune", "test-project", "--max-tokens", "5000"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_prune_with_dry_run(self, runner):
        """Test prune command with dry run"""
        result = runner.invoke(memory, ["prune", "test-project", "--dry-run"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]


class TestClearCacheCommand:
    """Test cases for clear cache command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_clear_cache_help(self, runner):
        """Test clear-cache command help"""
        result = runner.invoke(memory, ["clear-cache", "--help"])

        assert result.exit_code == 0

    def test_clear_cache_missing_args(self, runner):
        """Test clear-cache command with missing arguments"""
        result = runner.invoke(memory, ["clear-cache"])

        assert result.exit_code != 0

    def test_clear_cache_basic(self, runner):
        """Test clear-cache command basic execution"""
        with patch("cli_memory.CacheManager") as mock_cache:
            mock_instance = MagicMock()
            mock_instance.clear.return_value = MagicMock(items_cleared=10, memory_freed_mb=5.0)
            mock_cache.return_value = mock_instance

            result = runner.invoke(memory, ["clear-cache", "test-project"])

            # Should handle gracefully
            assert result.exit_code in [0, 1]

    def test_clear_cache_with_all(self, runner):
        """Test clear-cache command with --all flag"""
        result = runner.invoke(memory, ["clear-cache", "test-project", "--all"])

        # Should handle gracefully
        assert result.exit_code in [0, 1]

    def test_clear_cache_with_type(self, runner):
        """Test clear-cache command with type filter"""
        result = runner.invoke(memory, ["clear-cache", "test-project", "--type", "context"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]


class TestMonitorCommand:
    """Test cases for monitor command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_monitor_help(self, runner):
        """Test monitor command help"""
        result = runner.invoke(memory, ["monitor", "--help"])

        assert result.exit_code == 0
        assert "duration" in result.output.lower()

    def test_monitor_missing_args(self, runner):
        """Test monitor command with missing arguments"""
        result = runner.invoke(memory, ["monitor"])

        assert result.exit_code != 0

    def test_monitor_basic(self, runner):
        """Test monitor command basic execution"""
        with patch("time.sleep"):
            with patch("cli_memory.create_default_monitor") as mock_monitor:
                mock_instance = MagicMock()
                mock_instance.take_snapshot.return_value = MagicMock(total_memory_mb=100.0)
                mock_instance.start = MagicMock()
                mock_instance.stop = MagicMock()
                mock_monitor.return_value = mock_instance

                result = runner.invoke(memory, ["monitor", "test-project", "--duration", "5"])

                assert result.exit_code in [0, 1]

    @pytest.mark.parametrize(
        "interval,expected_check_count",
        [
            (10, 1),
            (5, 1),
            (1, 1),
        ],
    )
    def test_monitor_with_interval(self, runner, interval, expected_check_count):
        """Test monitor command with custom interval"""
        with patch("time.sleep"):
            result = runner.invoke(
                memory,
                [
                    "monitor",
                    "test-project",
                    "--duration",
                    str(interval),
                    "--interval",
                    str(interval),
                ],
            )

        assert result.exit_code in [0, 1]


class TestPoolStatsCommand:
    """Test cases for pool stats command"""

    @pytest.fixture
    def runner(self):
        """Create CLI test runner"""
        return CliRunner()

    def test_pool_stats_help(self, runner):
        """Test pool-stats command help"""
        result = runner.invoke(memory, ["pool-stats", "--help"])

        assert result.exit_code == 0

    def test_pool_stats_basic(self, runner):
        """Test pool-stats command basic execution"""
        with patch("cli_memory.get_pool_manager") as mock_pool:
            mock_instance = MagicMock()
            mock_instance.get_stats.return_value = {
                "total_pools": 5,
                "total_objects": 100,
                "active_objects": 50,
                "available_objects": 50,
            }
            mock_pool.return_value = mock_instance

            result = runner.invoke(memory, ["pool-stats"])

            # Should handle gracefully
            assert result.exit_code in [0, 1, 2]

    def test_pool_stats_with_json(self, runner):
        """Test pool-stats command with JSON output"""
        result = runner.invoke(memory, ["pool-stats", "--json"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]

    def test_pool_stats_with_verbose(self, runner):
        """Test pool-stats command with verbose output"""
        result = runner.invoke(memory, ["pool-stats", "--verbose"])

        # Should handle gracefully
        assert result.exit_code in [0, 1, 2]
