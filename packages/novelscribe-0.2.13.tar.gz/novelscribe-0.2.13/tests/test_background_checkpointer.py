"""Unit tests for background_checkpointer.py — async monitoring and notifications."""

from core.background_checkpointer import BackgroundCheckpointer, create_background_checkpointer
from core.hybrid_authority import AuthorityConfig, AuthorityLevel


class TestBackgroundCheckpointerInit:
    def test_init_defaults(self):
        bc = BackgroundCheckpointer()
        assert bc.get_trust_score() == 0.5

    def test_init_with_config(self):
        config = AuthorityConfig(level=AuthorityLevel.AI_ONLY)
        bc = BackgroundCheckpointer(authority_config=config)
        status = bc.get_authority_status()
        assert status["level"] == "ai_only"


class TestMonitoring:
    def test_start_monitoring(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=1.0))
        bc.start_monitoring("cp_01")
        status = bc.get_deadline_status("cp_01")
        assert status is not None
        assert status["checkpoint_id"] == "cp_01"
        assert status["is_expired"] is False

    def test_stop_monitoring(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=1.0))
        bc.start_monitoring("cp_01")
        bc.stop_monitoring("cp_01")
        assert bc.get_deadline_status("cp_01") is None

    def test_extend_deadline(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=1.0))
        bc.start_monitoring("cp_01")
        result = bc.extend_deadline("cp_01", 2.0)
        assert result is True
        status = bc.get_deadline_status("cp_01")
        assert status["extensions_granted"] == 1

    def test_extend_unknown_returns_false(self):
        bc = BackgroundCheckpointer()
        assert bc.extend_deadline("unknown", 1.0) is False

    def test_max_extensions(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=1.0))
        bc.start_monitoring("cp_01")
        bc.extend_deadline("cp_01", 1.0)
        bc.extend_deadline("cp_01", 1.0)
        bc.extend_deadline("cp_01", 1.0)
        assert bc.extend_deadline("cp_01", 1.0) is False

    def test_no_monitoring_without_timeout(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=None))
        bc.start_monitoring("cp_01")
        assert bc.get_deadline_status("cp_01") is None


class TestAutoApprove:
    def test_auto_approve_ai_only(self):
        config = AuthorityConfig(level=AuthorityLevel.AI_ONLY)
        bc = BackgroundCheckpointer(authority_config=config)
        approved, reason = bc.should_auto_approve("cp_01", 0.5)
        assert approved is True

    def test_no_auto_approve_human_only(self):
        config = AuthorityConfig(level=AuthorityLevel.HUMAN_ONLY)
        bc = BackgroundCheckpointer(authority_config=config)
        approved, reason = bc.should_auto_approve("cp_01", 0.99)
        assert approved is False


class TestRecording:
    def test_record_approval_stops_monitoring(self):
        bc = BackgroundCheckpointer(authority_config=AuthorityConfig(timeout_hours=1.0))
        bc.start_monitoring("cp_01")
        bc.record_approval("cp_01")
        assert bc.get_deadline_status("cp_01") is None
        assert bc.get_trust_score() > 0

    def test_record_rejection_escalates(self):
        escalated = []
        bc = BackgroundCheckpointer(
            authority_config=AuthorityConfig(escalate_on_reject=True, timeout_hours=1.0),
            on_escalation=lambda cp: escalated.append(cp),
        )
        bc.start_monitoring("cp_01")
        bc.record_rejection("cp_01")
        assert len(escalated) == 1


class TestNotifications:
    def test_get_pending_notifications_empty(self):
        bc = BackgroundCheckpointer()
        assert bc.get_pending_notifications() == []

    def test_clear_notifications(self):
        bc = BackgroundCheckpointer()
        bc._add_notification("test", "cp_01", "Test message")
        bc.clear_notifications()
        assert bc.get_pending_notifications() == []

    def test_filter_notifications_by_checkpoint(self):
        bc = BackgroundCheckpointer()
        bc._add_notification("test", "cp_01", "Message 1")
        bc._add_notification("test", "cp_02", "Message 2")
        filtered = bc.get_pending_notifications(checkpoint_id="cp_01")
        assert len(filtered) == 1
        assert filtered[0]["checkpoint_id"] == "cp_01"


class TestFactory:
    def test_create_background_checkpointer(self):
        bc = create_background_checkpointer()
        assert isinstance(bc, BackgroundCheckpointer)

    def test_create_with_authority_level(self):
        bc = create_background_checkpointer(authority_level=AuthorityLevel.AI_ONLY)
        status = bc.get_authority_status()
        assert status["level"] == "ai_only"
