"""Comprehensive tests for core/orchestrator.py to bring coverage above 80%."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from core.llm_client import LLMConfig, LLMResponse
from core.orchestrator import (
    ExecutionContext,
    Orchestrator,
    OrchestratorError,
    StepExecutionError,
    VariableResolver,
    create_orchestrator,
)
from core.storage import (
    AgentDefinition,
    StorageConfig,
    WorkflowDefinition,
)


class TestVariableResolver:
    """Tests for VariableResolver variable substitution."""

    def test_resolve_simple_variable(self):
        ctx = {"name": "test_novel"}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{name}") == "test_novel"

    def test_resolve_nested_variable(self):
        ctx = {"project": {"name": "deep_value"}}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{project.name}") == "deep_value"

    def test_resolve_missing_variable_returns_original(self):
        resolver = VariableResolver({"a": "1"})
        assert resolver.resolve("{missing}") == "{missing}"

    def test_resolve_non_string_template(self):
        resolver = VariableResolver({})
        assert resolver.resolve(42) == 42

    def test_resolve_multiple_variables(self):
        ctx = {"x": "hello", "y": "world"}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{x} {y}") == "hello world"

    def test_resolve_no_variables(self):
        resolver = VariableResolver({})
        assert resolver.resolve("plain text") == "plain text"

    def test_resolve_deeply_nested_missing(self):
        ctx = {"a": {"b": 1}}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{a.b.c}") == "{a.b.c}"

    def test_resolve_non_dict_intermediate(self):
        ctx = {"a": "not_a_dict"}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{a.b}") == "{a.b}"

    def test_resolve_value_is_none(self):
        ctx = {"key": None}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{key}") == "{key}"

    def test_resolve_converts_value_to_string(self):
        ctx = {"count": 42}
        resolver = VariableResolver(ctx)
        assert resolver.resolve("{count}") == "42"


class TestExecutionContext:
    """Tests for ExecutionContext state management."""

    def test_set_and_get_variable(self):
        ctx = ExecutionContext("proj", "wf")
        ctx.set_variable("key", "val")
        assert ctx.get_variable("key") == "val"

    def test_get_variable_default(self):
        ctx = ExecutionContext("proj", "wf")
        assert ctx.get_variable("missing", "default") == "default"

    def test_get_variable_default_none(self):
        ctx = ExecutionContext("proj", "wf")
        assert ctx.get_variable("missing") is None

    def test_initial_variables(self):
        ctx = ExecutionContext("proj", "wf")
        assert ctx.variables["project_name"] == "proj"
        assert ctx.variables["workflow_name"] == "wf"

    def test_add_history_entry(self):
        ctx = ExecutionContext("proj", "wf")
        response = LLMResponse(content="out", model="m", provider="p", tokens_used=10)
        ctx.add_history_entry("step1", "agent1", ["in.md"], "out.md", response)
        history = ctx.get_history()
        assert len(history) == 1
        assert history[0]["step"] == "step1"
        assert history[0]["agent"] == "agent1"
        assert history[0]["content"] == "out"
        assert history[0]["model"] == "m"
        assert history[0]["provider"] == "p"
        assert history[0]["tokens_used"] == 10
        assert history[0]["input_files"] == ["in.md"]
        assert history[0]["output_file"] == "out.md"

    def test_get_history_returns_copy(self):
        ctx = ExecutionContext("proj", "wf")
        response = LLMResponse(content="out", model="m", provider="p")
        ctx.add_history_entry("s", "a", [], "o", response)
        h1 = ctx.get_history()
        h2 = ctx.get_history()
        assert h1 is not h2

    def test_custom_base_path(self):
        ctx = ExecutionContext("proj", "wf", base_path="/tmp/test")
        assert ctx.base_path.name == "proj"

    def test_initial_history_empty(self):
        ctx = ExecutionContext("proj", "wf")
        assert ctx.get_history() == []

    def test_logger_name(self):
        ctx = ExecutionContext("myproj", "mywf")
        assert ctx.logger.name == "orchestrator.myproj"


class TestOrchestratorExceptions:
    """Tests for custom exception classes."""

    def test_orchestrator_error(self):
        with pytest.raises(OrchestratorError):
            raise OrchestratorError("test")

    def test_step_execution_error_is_orchestrator_error(self):
        with pytest.raises(OrchestratorError):
            raise StepExecutionError("step failed")

    def test_step_execution_error_message(self):
        err = StepExecutionError("boom")
        assert str(err) == "boom"


def _make_agent_def(**overrides):
    defaults = dict(
        name="test_agent",
        description="desc",
        model="gpt-4o",
        temperature=0.7,
        max_tokens=4096,
        system_prompt="You are a test agent.",
    )
    defaults.update(overrides)
    return AgentDefinition(**defaults)


def _make_workflow(**overrides):
    defaults = dict(
        name="test_workflow",
        description="desc",
        steps=[
            {
                "name": "step1",
                "agent": "writer",
                "prompt": "Write something about {project_name}.",
                "output_file": "output.md",
            }
        ],
    )
    defaults.update(overrides)
    return WorkflowDefinition(**defaults)


class TestOrchestratorLoadWorkflow:
    """Tests for Orchestrator.load_workflow."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_workflow(self, mock_factory):
        mock_storage = MagicMock()
        wf = _make_workflow()
        mock_storage.read_workflow.return_value = wf
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        result = orchestrator.load_workflow("workflows/test.yaml")
        assert result.name == "test_workflow"
        mock_storage.read_workflow.assert_called_once_with("workflows/test.yaml")

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_agent_with_relative_path(self, mock_factory):
        mock_storage = MagicMock()
        agent = _make_agent_def()
        mock_storage.read_agent.return_value = agent
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        result = orchestrator.load_agent("agents/writer.md")
        assert result.name == "test_agent"

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_agent_with_absolute_path(self, mock_factory):
        mock_storage = MagicMock()
        agent = _make_agent_def()
        mock_storage.read_agent.return_value = agent
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        result = orchestrator.load_agent("/abs/path/agent.md")
        assert result.name == "test_agent"


class TestOrchestratorExecuteWorkflow:
    """Tests for Orchestrator.execute_workflow."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_workflow_success(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        workflow = _make_workflow()
        mock_storage.read_workflow.return_value = workflow
        mock_storage.read_agent.return_value = agent_def
        mock_storage.read_markdown.return_value = "content"
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(
            content="generated text", model="gpt-4o", provider="openai", tokens_used=50
        )
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = orchestrator.execute_workflow("wf.yaml", "myproject")
        assert ctx.project_name == "myproject"
        assert len(ctx.get_history()) == 1

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_workflow_with_initial_context(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        workflow = _make_workflow()
        mock_storage.read_workflow.return_value = workflow
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = orchestrator.execute_workflow("wf.yaml", "p", initial_context={"extra": "val"})
        assert ctx.variables["extra"] == "val"

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_workflow_no_output_file(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        workflow = _make_workflow(
            steps=[
                {
                    "name": "step1",
                    "agent": "writer",
                    "prompt": "Do something",
                }
            ]
        )
        mock_storage.read_workflow.return_value = workflow
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        orchestrator.execute_workflow("wf.yaml", "proj")
        mock_storage.write_markdown.assert_not_called()

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_workflow_multiple_steps(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        workflow = _make_workflow(
            steps=[
                {"name": "s1", "agent": "a1", "prompt": "p1", "output_file": "o1.md"},
                {"name": "s2", "agent": "a2", "prompt": "p2", "output_file": "o2.md"},
            ]
        )
        mock_storage.read_workflow.return_value = workflow
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = orchestrator.execute_workflow("wf.yaml", "proj")
        assert len(ctx.get_history()) == 2


class TestOrchestratorExecuteStep:
    """Tests for Orchestrator._execute_step."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_missing_agent_raises(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"name": "bad_step"}
        with pytest.raises(StepExecutionError, match="missing agent"):
            orchestrator._execute_step(step, ctx)

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_false_skips(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_llm = MagicMock()
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("skip", "false")
        step = {"name": "s", "agent": "a", "condition": "{skip}"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_not_called()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_no_value_skips(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_llm = MagicMock()
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("skip", "no")
        step = {"name": "s", "agent": "a", "condition": "{skip}"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_not_called()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_zero_skips(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_llm = MagicMock()
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("skip", "0")
        step = {"name": "s", "agent": "a", "condition": "{skip}"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_not_called()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_true_executes(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("go", "true")
        step = {"name": "s", "agent": "a", "condition": "{go}", "prompt": "do it"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_called_once()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_yes_executes(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("go", "yes")
        step = {"name": "s", "agent": "a", "condition": "{go}", "prompt": "do it"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_called_once()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_one_executes(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("go", "1")
        step = {"name": "s", "agent": "a", "condition": "{go}", "prompt": "do it"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_called_once()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_condition_unresolved_string_is_truthy(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"name": "s", "agent": "a", "condition": "some_truthy_string", "prompt": "do it"}
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_called_once()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_llm_error_wraps(self, mock_factory_cls):
        from core.llm_client import LLMError

        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.side_effect = LLMError("API failure")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"name": "s", "agent": "a", "prompt": "do it"}
        with pytest.raises(StepExecutionError, match="API failure"):
            orchestrator._execute_step(step, ctx)

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_with_custom_agent_path(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {
            "name": "s",
            "agent": "writer",
            "agent_path": "agents/custom_writer.md",
            "prompt": "do it",
        }
        orchestrator._execute_step(step, ctx)
        mock_storage.read_agent.assert_called_once()

    @patch("core.orchestrator.LLMClientFactory")
    def test_step_with_input_files_and_output(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_storage.read_markdown.return_value = "input data"
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="generated", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {
            "name": "s",
            "agent": "a",
            "prompt": "process this",
            "input_files": ["input.md"],
            "output_file": "output.md",
        }
        orchestrator._execute_step(step, ctx)
        mock_storage.write_markdown.assert_called_once_with("output.md", "generated")
        history = ctx.get_history()
        assert len(history) == 1
        assert history[0]["input_files"] == ["input.md"]
        assert history[0]["output_file"] == "output.md"


class TestOrchestratorEvaluateCondition:
    """Tests for Orchestrator._evaluate_condition."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_true_values(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        assert orchestrator._evaluate_condition("true", ctx) is True
        assert orchestrator._evaluate_condition("yes", ctx) is True
        assert orchestrator._evaluate_condition("1", ctx) is True
        assert orchestrator._evaluate_condition("TRUE", ctx) is True
        assert orchestrator._evaluate_condition("Yes", ctx) is True

    @patch("core.orchestrator.LLMClientFactory")
    def test_false_values(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        assert orchestrator._evaluate_condition("false", ctx) is False
        assert orchestrator._evaluate_condition("no", ctx) is False
        assert orchestrator._evaluate_condition("0", ctx) is False
        assert orchestrator._evaluate_condition("FALSE", ctx) is False

    @patch("core.orchestrator.LLMClientFactory")
    def test_resolved_variable_condition(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        ctx.set_variable("flag", "true")
        assert orchestrator._evaluate_condition("{flag}", ctx) is True

    @patch("core.orchestrator.LLMClientFactory")
    def test_bool_fallback_truthy(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._evaluate_condition("nonempty_string", ctx)
        assert result is True

    @patch("core.orchestrator.LLMClientFactory")
    def test_unnamed_step(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"agent": "a", "prompt": "p"}
        orchestrator._execute_step(step, ctx)
        assert len(ctx.get_history()) == 1


class TestOrchestratorLoadInputContent:
    """Tests for Orchestrator._load_input_content."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_markdown_files(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.read_markdown.return_value = "md content"
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content(["f1.md"], ctx)
        assert result["f1.md"] == "md content"

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_yaml_files(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.read_yaml.return_value = {"key": "val"}
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content(["f1.yaml"], ctx)
        assert "key" in result["f1.yaml"]

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_yml_files(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.read_yaml.return_value = {"k": "v"}
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content(["f1.yml"], ctx)
        assert "f1.yml" in result

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_fallback_to_markdown(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.read_markdown.return_value = "content"
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content(["f1.txt"], ctx)
        assert result["f1.txt"] == "content"

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_error_returns_empty(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.read_markdown.side_effect = Exception("fail")
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content(["f1.md"], ctx)
        assert result["f1.md"] == ""

    @patch("core.orchestrator.LLMClientFactory")
    def test_load_empty_file_list(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        result = orchestrator._load_input_content([], ctx)
        assert result == {}


class TestOrchestratorConstructUserPrompt:
    """Tests for Orchestrator._construct_user_prompt."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_prompt_with_input_content(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"prompt": "Write about {project_name}."}
        input_content = {"file1.md": "some content here"}
        result = orchestrator._construct_user_prompt(step, input_content, ctx)
        assert "Write about p." in result
        assert "Input Files" in result
        assert "file1.md" in result

    @patch("core.orchestrator.LLMClientFactory")
    def test_prompt_no_input_content(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"prompt": "Just do it."}
        result = orchestrator._construct_user_prompt(step, {}, ctx)
        assert result == "Just do it."

    @patch("core.orchestrator.LLMClientFactory")
    def test_prompt_no_template(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {}
        input_content = {"f.md": "data"}
        result = orchestrator._construct_user_prompt(step, input_content, ctx)
        assert "Input Files" in result

    @patch("core.orchestrator.LLMClientFactory")
    def test_prompt_multiple_input_files(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        step = {"prompt": "Combine these."}
        input_content = {"a.md": "content_a", "b.yaml": "content_b"}
        result = orchestrator._construct_user_prompt(step, input_content, ctx)
        assert "a.md" in result
        assert "b.yaml" in result


class TestOrchestratorSaveOutput:
    """Tests for Orchestrator._save_output."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_save_markdown(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        orchestrator._save_output("out.md", "content", ctx)
        mock_storage.write_markdown.assert_called_once_with("out.md", "content")

    @patch("core.orchestrator.LLMClientFactory")
    def test_save_yaml(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        orchestrator._save_output("out.yaml", "content", ctx)
        mock_storage.write_yaml.assert_called_once_with("out.yaml", {"content": "content"})

    @patch("core.orchestrator.LLMClientFactory")
    def test_save_yml(self, mock_factory_cls):
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        orchestrator._save_output("out.yml", "content", ctx)
        mock_storage.write_yaml.assert_called_once_with("out.yml", {"content": "content"})

    @patch("core.orchestrator.LLMClientFactory")
    def test_save_error_raises_step_error(self, mock_factory_cls):
        mock_storage = MagicMock()
        mock_storage.write_markdown.side_effect = OSError("disk full")
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        with pytest.raises(StepExecutionError, match="disk full"):
            orchestrator._save_output("out.md", "content", ctx)


class TestOrchestratorExecuteStepDirect:
    """Tests for Orchestrator.execute_step (public method)."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_step_with_custom_system_prompt(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        resp = orchestrator.execute_step(
            "agents/writer.md", system_prompt="custom", user_prompt="hi"
        )
        assert resp.content == "out"

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_step_uses_agent_prompt(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def(system_prompt="agent prompt")
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        resp = orchestrator.execute_step("agents/writer.md", user_prompt="hi")
        assert resp.content == "out"

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_step_saves_output_with_context(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        orchestrator.execute_step(
            "agents/writer.md", user_prompt="hi", output_file="out.md", context=ctx
        )
        mock_storage.write_markdown.assert_called_once_with("out.md", "out")

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_step_no_save_without_context(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        orchestrator.execute_step("agents/writer.md", user_prompt="hi", output_file="out.md")
        mock_storage.write_markdown.assert_not_called()

    @patch("core.orchestrator.LLMClientFactory")
    def test_execute_step_empty_output_file_no_save(self, mock_factory_cls):
        mock_storage = MagicMock()
        agent_def = _make_agent_def()
        mock_storage.read_agent.return_value = agent_def
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="out", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        orchestrator = Orchestrator(mock_storage, LLMConfig())
        ctx = ExecutionContext("p", "w")
        orchestrator.execute_step("agents/writer.md", user_prompt="hi", output_file="", context=ctx)
        mock_storage.write_markdown.assert_not_called()


class TestCreateOrchestrator:
    """Tests for create_orchestrator factory."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_create_with_defaults(self, mock_factory_cls):
        mock_factory_cls.create.return_value = MagicMock()
        orchestrator = create_orchestrator()
        assert isinstance(orchestrator, Orchestrator)

    @patch("core.orchestrator.LLMClientFactory")
    def test_create_with_custom_config(self, mock_factory_cls):
        mock_factory_cls.create.return_value = MagicMock()
        storage_config = StorageConfig(base_path="/tmp/test_novels")
        llm_config = LLMConfig(provider="openai", model="gpt-4o")
        orchestrator = create_orchestrator(storage_config=storage_config, llm_config=llm_config)
        assert orchestrator.base_path == "/tmp/test_novels"


class TestOrchestratorCallLLM:
    """Tests for Orchestrator._call_llm."""

    @patch("core.orchestrator.LLMClientFactory")
    def test_call_llm_creates_agent_config(self, mock_factory_cls):
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(
            content="out", model="gpt-4o", provider="openai"
        )
        mock_factory_cls.create.return_value = mock_llm
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig(provider="openai"))
        agent_def = _make_agent_def(model="gpt-3.5-turbo", temperature=0.5, max_tokens=2048)
        result = orchestrator._call_llm(agent_def, "sys", "user")
        assert result.content == "out"
        assert mock_factory_cls.create.call_count >= 2

    @patch("core.orchestrator.LLMClientFactory")
    def test_call_llm_uses_agent_settings(self, mock_factory_cls):
        mock_llm = MagicMock()
        mock_llm.generate.return_value = LLMResponse(content="ok", model="m", provider="p")
        mock_factory_cls.create.return_value = mock_llm
        mock_storage = MagicMock()
        orchestrator = Orchestrator(mock_storage, LLMConfig(provider="claude"))
        agent_def = _make_agent_def(model="claude-3", temperature=0.3, max_tokens=2048)
        orchestrator._call_llm(agent_def, "sys prompt", "user prompt")
        mock_llm.generate.assert_called_once_with("sys prompt", "user prompt")
