"""Tests for core.llm_client to achieve 80%+ coverage."""

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

from core.llm_client import (
    ClaudeClient,
    GeminiClient,
    LLMClient,
    LLMClientFactory,
    LLMConfig,
    LLMError,
    LLMResponse,
    LMStudioClient,
    MultiLLMClient,
    OllamaClient,
    OpenAIClient,
    ProviderNotFoundError,
)


class TestLLMProvider:
    def test_max_context_tokens(self):
        from core.llm_client import LLMProvider

        assert LLMProvider.OPENAI.max_context_tokens() == 128000
        assert LLMProvider.CLAUDE.max_context_tokens() == 200000
        assert LLMProvider.GEMINI.max_context_tokens() == 1000000
        assert LLMProvider.OLLAMA.max_context_tokens() == 8192
        assert LLMProvider.LM_STUDIO.max_context_tokens() == 8192


class TestLLMConfig:
    def test_defaults(self):
        config = LLMConfig()
        assert config.provider == "openai"
        assert config.model == "gpt-4o"
        assert config.temperature == 0.7
        assert config.max_tokens == 4096
        assert config.api_key == ""
        assert config.base_url == ""
        assert config.timeout == 120
        assert config.streaming is False


class TestLLMResponse:
    def test_creation(self):
        resp = LLMResponse(
            content="hello",
            model="gpt-4o",
            provider="openai",
            tokens_used=100,
            finish_reason="stop",
        )
        assert resp.content == "hello"
        assert resp.tokens_used == 100

    def test_creation_optional_fields(self):
        resp = LLMResponse(content="hi", model="gpt-4o", provider="openai")
        assert resp.tokens_used is None
        assert resp.finish_reason is None


class TestLLMClientBase:
    def test_format_messages_both(self):
        config = LLMConfig(provider="openai")
        client = OpenAIClient.__new__(OpenAIClient)
        client.config = config
        client.provider_name = "openai"
        msgs = client._format_messages("system prompt", "user prompt")
        assert len(msgs) == 2
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"

    def test_format_messages_system_only(self):
        config = LLMConfig(provider="openai")
        client = OpenAIClient.__new__(OpenAIClient)
        client.config = config
        client.provider_name = "openai"
        msgs = client._format_messages("system prompt", "")
        assert len(msgs) == 1
        assert msgs[0]["role"] == "system"

    def test_format_messages_user_only(self):
        config = LLMConfig(provider="openai")
        client = OpenAIClient.__new__(OpenAIClient)
        client.config = config
        client.provider_name = "openai"
        msgs = client._format_messages("", "user prompt")
        assert len(msgs) == 1
        assert msgs[0]["role"] == "user"

    def test_format_messages_empty(self):
        config = LLMConfig(provider="openai")
        client = OpenAIClient.__new__(OpenAIClient)
        client.config = config
        client.provider_name = "openai"
        msgs = client._format_messages("", "")
        assert len(msgs) == 0

    def test_base_init(self):
        config = LLMConfig(provider="openai")
        client = OpenAIClient.__new__(OpenAIClient)
        client.config = config
        client.provider_name = config.provider
        assert client.config == config
        assert client.provider_name == "openai"


class TestOpenAIClient:
    @patch("core.llm_client.os.getenv", return_value="test-key")
    @patch("openai.OpenAI")
    def test_init(self, mock_openai_cls, mock_getenv):
        config = LLMConfig(provider="openai", api_key="key123", base_url="http://custom")
        client = OpenAIClient(config)
        assert client.provider_name == "openai"

    @patch("openai.OpenAI")
    def test_init_no_base_url(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="key123")
        with patch.dict(os.environ, {}, clear=False):
            client = OpenAIClient(config)
        assert client.provider_name == "openai"

    @patch("openai.OpenAI")
    def test_init_with_base_url(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="key123", base_url="http://custom.api.com")
        OpenAIClient(config)
        mock_openai_cls.assert_called_once()
        call_kwargs = mock_openai_cls.call_args
        assert "base_url" in call_kwargs.kwargs

    def test_init_import_error(self):
        with patch.dict("sys.modules", {"openai": None}):
            config = LLMConfig(provider="openai", api_key="key")
            with pytest.raises(LLMError, match="OpenAI package not installed"):
                OpenAIClient(config)

    @patch("openai.OpenAI")
    def test_validate_config_with_key(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="key123")
        client = OpenAIClient(config)
        assert client.validate_config() is True

    @patch("openai.OpenAI")
    def test_validate_config_no_key(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        with patch.dict(os.environ, {"OPENAI_API_KEY": ""}, clear=False):
            assert client.validate_config() is False

    @patch("openai.OpenAI")
    def test_validate_config_env_key(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        with patch.dict(os.environ, {"OPENAI_API_KEY": "env-key"}, clear=False):
            assert client.validate_config() is True

    @patch("openai.OpenAI")
    def test_generate(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "generated text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 50

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        result = client.generate("system", "user")
        assert result.content == "generated text"
        assert result.tokens_used == 50

    @patch("openai.OpenAI")
    def test_generate_no_usage(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage = None

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        result = client.generate("system", "user")
        assert result.tokens_used is None

    @patch("openai.OpenAI")
    def test_generate_no_key(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        with patch.dict(os.environ, {"OPENAI_API_KEY": ""}, clear=False):
            with pytest.raises(LLMError, match="not configured"):
                client.generate("system", "user")

    @patch("openai.OpenAI")
    def test_generate_api_error(self, mock_openai_cls):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        with pytest.raises(LLMError, match="OpenAI API error"):
            client.generate("system", "user")

    @patch("openai.OpenAI")
    def test_generate_with_history(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 30

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        messages = [{"role": "user", "content": "hello"}]
        result = client.generate_with_history(messages)
        assert result.content == "response"

    @patch("openai.OpenAI")
    def test_generate_with_history_no_key(self, mock_openai_cls):
        config = LLMConfig(provider="openai", api_key="")
        client = OpenAIClient(config)
        with patch.dict(os.environ, {"OPENAI_API_KEY": ""}, clear=False):
            with pytest.raises(LLMError, match="not configured"):
                client.generate_with_history([{"role": "user", "content": "hi"}])

    @patch("openai.OpenAI")
    def test_generate_with_history_error(self, mock_openai_cls):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        with pytest.raises(LLMError, match="OpenAI API error"):
            client.generate_with_history([{"role": "user", "content": "hi"}])

    @patch("openai.OpenAI")
    def test_generate_with_history_no_usage(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage = None

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="openai", api_key="key")
        client = OpenAIClient(config)
        result = client.generate_with_history([{"role": "user", "content": "hi"}])
        assert result.tokens_used is None


class TestClaudeClient:
    @patch("anthropic.Anthropic")
    def test_init(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="claude-key")
        client = ClaudeClient(config)
        assert client.provider_name == "claude"

    def test_init_import_error(self):
        with patch.dict("sys.modules", {"anthropic": None}):
            config = LLMConfig(provider="claude", api_key="key")
            with pytest.raises(LLMError, match="Anthropic package not installed"):
                ClaudeClient(config)

    @patch("anthropic.Anthropic")
    def test_validate_config(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        assert client.validate_config() is True

    @patch("anthropic.Anthropic")
    def test_validate_config_no_key(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=False):
            assert client.validate_config() is False

    @patch("anthropic.Anthropic")
    def test_validate_config_env_key(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "env-key"}, clear=False):
            assert client.validate_config() is True

    @patch("anthropic.Anthropic")
    def test_generate(self, mock_anthropic_cls):
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "claude response"
        mock_response.model = "claude-3"
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 20
        mock_response.stop_reason = "end_turn"

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response
        mock_anthropic_cls.return_value = mock_client

        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        result = client.generate("system", "user")
        assert result.content == "claude response"
        assert result.tokens_used == 30

    @patch("anthropic.Anthropic")
    def test_generate_no_key(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=False):
            with pytest.raises(LLMError, match="not configured"):
                client.generate("system", "user")

    @patch("anthropic.Anthropic")
    def test_generate_error(self, mock_anthropic_cls):
        mock_client = MagicMock()
        mock_client.messages.create.side_effect = Exception("fail")
        mock_anthropic_cls.return_value = mock_client

        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        with pytest.raises(LLMError, match="Claude API error"):
            client.generate("system", "user")

    @patch("anthropic.Anthropic")
    def test_generate_with_history(self, mock_anthropic_cls):
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "response"
        mock_response.model = "claude-3"
        mock_response.usage.input_tokens = 5
        mock_response.usage.output_tokens = 10
        mock_response.stop_reason = "end_turn"

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response
        mock_anthropic_cls.return_value = mock_client

        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        messages = [
            {"role": "system", "content": "you are helpful"},
            {"role": "user", "content": "hi"},
        ]
        result = client.generate_with_history(messages)
        assert result.content == "response"

    @patch("anthropic.Anthropic")
    def test_generate_with_history_no_system(self, mock_anthropic_cls):
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "response"
        mock_response.model = "claude-3"
        mock_response.usage.input_tokens = 5
        mock_response.usage.output_tokens = 10
        mock_response.stop_reason = "end_turn"

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_response
        mock_anthropic_cls.return_value = mock_client

        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        messages = [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ]
        result = client.generate_with_history(messages)
        assert result.content == "response"

    @patch("anthropic.Anthropic")
    def test_generate_with_history_no_key(self, mock_anthropic_cls):
        config = LLMConfig(provider="claude", api_key="")
        client = ClaudeClient(config)
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": ""}, clear=False):
            with pytest.raises(LLMError, match="not configured"):
                client.generate_with_history([{"role": "user", "content": "hi"}])

    @patch("anthropic.Anthropic")
    def test_generate_with_history_error(self, mock_anthropic_cls):
        mock_client = MagicMock()
        mock_client.messages.create.side_effect = Exception("fail")
        mock_anthropic_cls.return_value = mock_client

        config = LLMConfig(provider="claude", api_key="key")
        client = ClaudeClient(config)
        with pytest.raises(LLMError, match="Claude API error"):
            client.generate_with_history([{"role": "user", "content": "hi"}])


class TestGeminiClient:
    def _patch_genai(self):
        mock_types = MagicMock()
        mock_types.GenerateContentConfig = MagicMock()
        mock_types.Content = MagicMock(return_value=MagicMock())
        mock_types.Part = MagicMock(return_value=MagicMock())

        mock_genai_module = MagicMock()
        mock_genai_module.types = mock_types

        mock_client_instance = MagicMock()
        mock_genai_module.Client.return_value = mock_client_instance

        google_mock = MagicMock(__spec__=MagicMock())
        google_mock.genai = mock_genai_module

        modules = {
            "google": google_mock,
            "google.genai": mock_genai_module,
            "google.genai.types": mock_types,
        }
        return modules, mock_genai_module, mock_types, mock_client_instance

    def test_init(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="gemini-key")
            client = GeminiClient(config)
            assert client.provider_name == "gemini"

    def test_init_import_error(self):
        with patch.dict("sys.modules", {"google": None, "google.genai": None}):
            config = LLMConfig(provider="gemini", api_key="key")
            with pytest.raises(LLMError, match="Google Gemini package not installed"):
                GeminiClient(config)

    def test_validate_config(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            assert client.validate_config() is True

    def test_validate_config_no_key(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="")
            client = GeminiClient(config)
            with patch.dict(os.environ, {"GOOGLE_API_KEY": ""}, clear=False):
                assert client.validate_config() is False

    def test_validate_config_env_key(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="")
            client = GeminiClient(config)
            with patch.dict(os.environ, {"GOOGLE_API_KEY": "env-key"}, clear=False):
                assert client.validate_config() is True

    def test_generate(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock()
        mock_response.text = "gemini response"
        mock_response.usage_metadata.total_token_count = 100
        mock_candidate = MagicMock()
        mock_candidate.finish_reason.name = "STOP"
        mock_response.candidates = [mock_candidate]
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            result = client.generate("system prompt", "user prompt")
            assert result.content == "gemini response"

    def test_generate_no_system(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock()
        mock_response.text = "response"
        mock_response.usage_metadata.total_token_count = 50
        mock_candidate = MagicMock()
        mock_candidate.finish_reason.name = "STOP"
        mock_response.candidates = [mock_candidate]
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            result = client.generate("", "user prompt")
            assert result.content == "response"

    def test_generate_no_candidates(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock()
        mock_response.text = "text"
        mock_response.usage_metadata.total_token_count = 50
        mock_response.candidates = []
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            result = client.generate("system", "user")
            assert result.finish_reason is None

    def test_generate_no_usage_metadata(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock(spec=[])
        mock_response.text = "text"
        mock_response.candidates = []
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            result = client.generate("system", "user")
            assert result.tokens_used is None

    def test_generate_no_key(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="")
            client = GeminiClient(config)
            with patch.dict(os.environ, {"GOOGLE_API_KEY": ""}, clear=False):
                with pytest.raises(LLMError, match="not configured"):
                    client.generate("system", "user")

    def test_generate_error(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_client.models.generate_content.side_effect = Exception("fail")

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Gemini API error"):
                client.generate("system", "user")

    def test_generate_with_history(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock()
        mock_response.text = "history response"
        mock_response.usage_metadata.total_token_count = 40
        mock_candidate = MagicMock()
        mock_candidate.finish_reason.name = "STOP"
        mock_response.candidates = [mock_candidate]
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            messages = [
                {"role": "user", "content": "hello"},
                {"role": "assistant", "content": "hi"},
                {"role": "user", "content": "how are you"},
            ]
            result = client.generate_with_history(messages)
            assert result.content == "history response"

    def test_generate_with_history_no_key(self):
        modules, *_ = self._patch_genai()
        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="")
            client = GeminiClient(config)
            with patch.dict(os.environ, {"GOOGLE_API_KEY": ""}, clear=False):
                with pytest.raises(LLMError, match="not configured"):
                    client.generate_with_history([{"role": "user", "content": "hi"}])

    def test_generate_with_history_error(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_client.models.generate_content.side_effect = Exception("fail")

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            with pytest.raises(LLMError, match="Gemini API error"):
                client.generate_with_history([{"role": "user", "content": "hi"}])

    def test_generate_with_history_no_usage_metadata(self):
        modules, mock_genai_mod, mock_types, mock_client = self._patch_genai()
        mock_response = MagicMock(spec=[])
        mock_response.text = "text"
        mock_response.candidates = []
        mock_client.models.generate_content.return_value = mock_response

        with patch.dict(sys.modules, modules):
            config = LLMConfig(provider="gemini", api_key="key")
            client = GeminiClient(config)
            result = client.generate_with_history([{"role": "user", "content": "hi"}])
            assert result.tokens_used is None


class TestOllamaClient:
    def test_init(self):
        mock_requests = MagicMock()
        with patch.dict("sys.modules", {"requests": mock_requests}):
            config = LLMConfig(provider="ollama")
            client = OllamaClient(config)
            assert client.provider_name == "ollama"

    def test_init_import_error(self):
        with patch.dict("sys.modules", {"requests": None}):
            config = LLMConfig(provider="ollama")
            with pytest.raises(LLMError, match="Requests package not installed"):
                OllamaClient(config)

    def test_init_with_base_url(self):
        mock_requests = MagicMock()
        with patch.dict("sys.modules", {"requests": mock_requests}):
            config = LLMConfig(provider="ollama", base_url="http://custom:1234")
            client = OllamaClient(config)
            assert client.base_url == "http://custom:1234"

    def test_init_with_env_base_url(self):
        mock_requests = MagicMock()
        with patch.dict("sys.modules", {"requests": mock_requests}):
            with patch.dict(os.environ, {"OLLAMA_BASE_URL": "http://env-host:9999"}):
                config = LLMConfig(provider="ollama")
                client = OllamaClient(config)
                assert client.base_url == "http://env-host:9999"

    def test_validate_config(self):
        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        assert client.validate_config() is True

    def test_generate(self):
        mock_requests_mod = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "message": {"content": "ollama response"},
            "prompt_eval_count": 10,
            "eval_count": 20,
            "done_reason": "done",
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests_mod.post.return_value = mock_response

        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        client.requests = mock_requests_mod
        client.base_url = "http://localhost:11434"

        result = client.generate("system", "user")
        assert result.content == "ollama response"
        assert result.tokens_used == 30

    def test_generate_error(self):
        mock_requests_mod = MagicMock()
        mock_requests_mod.post.side_effect = Exception("connection failed")

        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        client.requests = mock_requests_mod
        client.base_url = "http://localhost:11434"

        with pytest.raises(LLMError, match="Ollama API error"):
            client.generate("system", "user")

    def test_generate_with_history(self):
        mock_requests_mod = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "message": {"content": "history response"},
            "prompt_eval_count": 5,
            "eval_count": 15,
            "done_reason": "done",
        }
        mock_response.raise_for_status = MagicMock()
        mock_requests_mod.post.return_value = mock_response

        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        client.requests = mock_requests_mod
        client.base_url = "http://localhost:11434"

        messages = [{"role": "user", "content": "hello"}]
        result = client.generate_with_history(messages)
        assert result.content == "history response"

    def test_generate_with_history_error(self):
        mock_requests_mod = MagicMock()
        mock_requests_mod.post.side_effect = Exception("fail")

        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        client.requests = mock_requests_mod
        client.base_url = "http://localhost:11434"

        with pytest.raises(LLMError, match="Ollama API error"):
            client.generate_with_history([{"role": "user", "content": "hi"}])

    def test_generate_empty_response(self):
        mock_requests_mod = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.raise_for_status = MagicMock()
        mock_requests_mod.post.return_value = mock_response

        config = LLMConfig(provider="ollama")
        client = OllamaClient.__new__(OllamaClient)
        client.config = config
        client.provider_name = "ollama"
        client.requests = mock_requests_mod
        client.base_url = "http://localhost:11434"

        result = client.generate("system", "user")
        assert result.content == ""
        assert result.tokens_used == 0


class TestLMStudioClient:
    @patch("openai.OpenAI")
    def test_init(self, mock_openai_cls):
        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        assert client.provider_name == "lm_studio"

    def test_init_import_error(self):
        with patch.dict("sys.modules", {"openai": None}):
            config = LLMConfig(provider="lm_studio")
            with pytest.raises(LLMError, match="OpenAI package not installed"):
                LMStudioClient(config)

    @patch("openai.OpenAI")
    def test_init_with_base_url(self, mock_openai_cls):
        config = LLMConfig(provider="lm_studio", base_url="http://custom:9999/v1")
        client = LMStudioClient(config)
        assert client.base_url == "http://custom:9999/v1"

    @patch("openai.OpenAI")
    def test_init_with_env_base_url(self, mock_openai_cls):
        with patch.dict(os.environ, {"LM_STUDIO_BASE_URL": "http://env-host:5555/v1"}):
            config = LLMConfig(provider="lm_studio")
            client = LMStudioClient(config)
            assert client.base_url == "http://env-host:5555/v1"

    @patch("openai.OpenAI")
    def test_validate_config(self, mock_openai_cls):
        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        assert client.validate_config() is True

    @patch("openai.OpenAI")
    def test_generate(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "lm studio response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "local-model"
        mock_response.usage.total_tokens = 40

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        result = client.generate("system", "user")
        assert result.content == "lm studio response"

    @patch("openai.OpenAI")
    def test_generate_no_usage(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "local"
        mock_response.usage = None

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        result = client.generate("system", "user")
        assert result.tokens_used is None

    @patch("openai.OpenAI")
    def test_generate_error(self, mock_openai_cls):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        with pytest.raises(LLMError, match="LM Studio API error"):
            client.generate("system", "user")

    @patch("openai.OpenAI")
    def test_generate_with_history(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "local"
        mock_response.usage.total_tokens = 25

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        result = client.generate_with_history([{"role": "user", "content": "hi"}])
        assert result.content == "response"

    @patch("openai.OpenAI")
    def test_generate_with_history_error(self, mock_openai_cls):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        with pytest.raises(LLMError, match="LM Studio API error"):
            client.generate_with_history([{"role": "user", "content": "hi"}])

    @patch("openai.OpenAI")
    def test_generate_with_history_no_usage(self, mock_openai_cls):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "text"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "local"
        mock_response.usage = None

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai_cls.return_value = mock_client

        config = LLMConfig(provider="lm_studio")
        client = LMStudioClient(config)
        result = client.generate_with_history([{"role": "user", "content": "hi"}])
        assert result.tokens_used is None


class TestLLMClientFactory:
    @patch("openai.OpenAI")
    def test_create_openai(self, mock_openai):
        config = LLMConfig(provider="openai", api_key="key")
        client = LLMClientFactory.create(config)
        assert isinstance(client, OpenAIClient)

    @patch("anthropic.Anthropic")
    def test_create_claude(self, mock_anthropic):
        config = LLMConfig(provider="claude", api_key="key")
        client = LLMClientFactory.create(config)
        assert isinstance(client, ClaudeClient)

    def test_create_unknown(self):
        config = LLMConfig(provider="unknown_provider")
        with pytest.raises(ProviderNotFoundError):
            LLMClientFactory.create(config)

    def test_register_provider(self):
        class MockClient(LLMClient):
            def generate(self, system_prompt, user_prompt):
                pass

            def generate_with_history(self, messages):
                pass

            def validate_config(self):
                return True

        LLMClientFactory.register_provider("mock", MockClient)
        assert "mock" in LLMClientFactory.list_providers()

        config = LLMConfig(provider="mock")
        client = LLMClientFactory.create(config)
        assert isinstance(client, MockClient)

        del LLMClientFactory._providers["mock"]

    def test_list_providers(self):
        providers = LLMClientFactory.list_providers()
        assert "openai" in providers
        assert "claude" in providers
        assert "gemini" in providers
        assert "ollama" in providers
        assert "lm_studio" in providers


class TestMultiLLMClient:
    @patch("openai.OpenAI")
    def test_generate_primary_success(self, mock_openai):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "primary response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 10

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client

        primary = LLMConfig(provider="openai", api_key="key")
        multi = MultiLLMClient(primary)
        result = multi.generate("system", "user")
        assert result.content == "primary response"

    @patch("openai.OpenAI")
    def test_generate_fallback(self, mock_openai):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("primary failed")
        mock_openai.return_value = mock_client

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "fallback response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 10

        mock_client2 = MagicMock()
        mock_client2.chat.completions.create.return_value = mock_response

        def openai_factory(**kwargs):
            if mock_openai.call_count <= 1:
                return mock_client
            return mock_client2

        mock_openai.side_effect = openai_factory

        primary = LLMConfig(provider="openai", api_key="key")
        fallback = LLMConfig(provider="openai", api_key="key2")
        multi = MultiLLMClient(primary, fallback)
        result = multi.generate("system", "user")
        assert result.content == "fallback response"

    @patch("openai.OpenAI")
    def test_generate_no_fallback_raises(self, mock_openai):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai.return_value = mock_client

        primary = LLMConfig(provider="openai", api_key="key")
        multi = MultiLLMClient(primary)
        with pytest.raises(LLMError):
            multi.generate("system", "user")

    @patch("openai.OpenAI")
    def test_generate_with_history_primary(self, mock_openai):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "response"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 10

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client

        primary = LLMConfig(provider="openai", api_key="key")
        multi = MultiLLMClient(primary)
        result = multi.generate_with_history([{"role": "user", "content": "hi"}])
        assert result.content == "response"

    @patch("openai.OpenAI")
    def test_generate_with_history_fallback(self, mock_openai):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai.return_value = mock_client

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "fallback"
        mock_response.choices[0].finish_reason = "stop"
        mock_response.model = "gpt-4o"
        mock_response.usage.total_tokens = 5

        mock_client2 = MagicMock()
        mock_client2.chat.completions.create.return_value = mock_response

        call_count = [0]

        def openai_factory(**kwargs):
            call_count[0] += 1
            if call_count[0] <= 1:
                return mock_client
            return mock_client2

        mock_openai.side_effect = openai_factory

        primary = LLMConfig(provider="openai", api_key="key")
        fallback = LLMConfig(provider="openai", api_key="key2")
        multi = MultiLLMClient(primary, fallback)
        result = multi.generate_with_history([{"role": "user", "content": "hi"}])
        assert result.content == "fallback"

    @patch("openai.OpenAI")
    def test_generate_with_history_no_fallback_raises(self, mock_openai):
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("fail")
        mock_openai.return_value = mock_client

        primary = LLMConfig(provider="openai", api_key="key")
        multi = MultiLLMClient(primary)
        with pytest.raises(LLMError):
            multi.generate_with_history([{"role": "user", "content": "hi"}])

    def test_no_fallback_client(self):
        primary = LLMConfig(provider="ollama")
        multi = MultiLLMClient.__new__(MultiLLMClient)
        multi.primary_config = primary
        multi.fallback_config = None
        multi.primary_client = MagicMock()
        multi.fallback_client = None
        assert multi.fallback_client is None


class TestExceptions:
    def test_llm_error_is_exception(self):
        assert issubclass(LLMError, Exception)

    def test_provider_not_found_is_llm_error(self):
        assert issubclass(ProviderNotFoundError, LLMError)

    def test_llm_error_message(self):
        err = LLMError("test error")
        assert str(err) == "test error"

    def test_provider_not_found_message(self):
        err = ProviderNotFoundError("unknown")
        assert "unknown" in str(err)
