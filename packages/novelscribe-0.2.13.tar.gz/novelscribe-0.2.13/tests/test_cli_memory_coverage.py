"""Comprehensive tests for cli_memory module."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_memory import memory


class TestMemoryGroup:
    """Test memory command group."""

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(memory, ["--help"])
        assert result.exit_code == 0


class TestProfileCommand:
    """Test profile command."""

    def test_success(self):
        runner = CliRunner()
        with (
            patch("cli_memory.MemoryProfiler") as mock_mp,
            patch("cli_memory.MemoryProfilerConfig"),
            patch("time.sleep"),
        ):
            mp = mock_mp.return_value
            snap = MagicMock()
            snap.total_memory_mb = 100.0
            mp.take_snapshot.return_value = snap
            mp.get_memory_report.return_value = {
                "summary": {
                    "current_memory_mb": 100.0,
                    "average_memory_mb": 95.0,
                    "peak_memory_mb": 120.0,
                    "total_change_mb": 5.0,
                },
                "leaks_detected": ["Possible leak in context cache"],
            }
            result = runner.invoke(
                memory, ["profile", "myproj", "--duration", "10", "--interval", "5"]
            )
            assert result.exit_code == 0

    def test_no_leaks(self):
        runner = CliRunner()
        with (
            patch("cli_memory.MemoryProfiler") as mock_mp,
            patch("cli_memory.MemoryProfilerConfig"),
            patch("time.sleep"),
        ):
            mp = mock_mp.return_value
            snap = MagicMock()
            snap.total_memory_mb = 50.0
            mp.take_snapshot.return_value = snap
            mp.get_memory_report.return_value = {
                "summary": {
                    "current_memory_mb": 50.0,
                    "average_memory_mb": 48.0,
                    "peak_memory_mb": 55.0,
                    "total_change_mb": 2.0,
                },
                "leaks_detected": [],
            }
            result = runner.invoke(
                memory, ["profile", "myproj", "--duration", "5", "--interval", "5"]
            )
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with (
            patch("cli_memory.MemoryProfiler") as mock_mp,
            patch("cli_memory.MemoryProfilerConfig"),
        ):
            mock_mp.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["profile", "myproj"])
            assert result.exit_code != 0


class TestStatsCommand:
    """Test stats command."""

    def test_success(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp:
            snap = MagicMock()
            snap.total_memory_mb = 200.0
            snap.available_memory_mb = 8000.0
            snap.system_memory_mb = 16384.0
            snap.component_usage = {"cache": 50.0, "context": 30.0}
            mock_mp.return_value.take_snapshot.return_value = snap
            result = runner.invoke(memory, ["stats", "myproj"])
            assert result.exit_code == 0

    def test_without_component_usage(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp:
            snap = MagicMock()
            snap.total_memory_mb = 100.0
            snap.available_memory_mb = 8000.0
            snap.system_memory_mb = 16384.0
            snap.component_usage = None
            mock_mp.return_value.take_snapshot.return_value = snap
            result = runner.invoke(memory, ["stats", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp:
            mock_mp.return_value.take_snapshot.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["stats", "myproj"])
            assert result.exit_code != 0


class TestAnalyzeCommand:
    """Test analyze command."""

    def test_success(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon:
            mock_mon.return_value.get_status_report.return_value = {
                "current_memory_mb": 150.0,
                "trend": "stable",
                "thresholds": [
                    {
                        "name": "heap",
                        "status": "ok",
                        "current_mb": 150.0,
                        "warning_mb": 500.0,
                        "critical_mb": 1000.0,
                    },
                ],
            }
            result = runner.invoke(memory, ["analyze", "myproj", "--hours", "12"])
            assert result.exit_code == 0

    def test_warning_status(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon:
            mock_mon.return_value.get_status_report.return_value = {
                "current_memory_mb": 600.0,
                "trend": "increasing",
                "thresholds": [
                    {
                        "name": "heap",
                        "status": "warning",
                        "current_mb": 600.0,
                        "warning_mb": 500.0,
                        "critical_mb": 1000.0,
                    },
                ],
            }
            result = runner.invoke(memory, ["analyze", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon:
            mock_mon.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["analyze", "myproj"])
            assert result.exit_code != 0


class TestPruneCommand:
    """Test prune command."""

    def test_with_test_context(self):
        runner = CliRunner()
        with (
            patch("cli_memory.ContextCompressor") as mock_cc,
            patch("cli_memory.TokenEstimator") as mock_te,
            patch("core.context_assembly.ContextBlock"),
            patch("core.context_schema.TokenBudget"),
        ):
            mock_te.return_value.estimate_tokens.return_value = 5000
            mock_cc.return_value.compress.return_value = MagicMock(
                token_count=1000,
                reduction_percent=80.0,
                tiers_applied=[MagicMock(value="truncate")],
            )
            result = runner.invoke(
                memory,
                ["prune", "myproj", "--test-context", "some text", "--target-tokens", "1000"],
            )
            assert result.exit_code == 0

    def test_without_test_context(self):
        runner = CliRunner()
        with (
            patch("cli_memory.ContextCompressor") as mock_cc,
            patch("cli_memory.TokenEstimator") as mock_te,
            patch("core.context_assembly.ContextBlock"),
            patch("core.context_schema.TokenBudget"),
        ):
            mock_te.return_value.estimate_tokens.return_value = 700
            mock_cc.return_value.compress.return_value = MagicMock(
                token_count=350,
                reduction_percent=50.0,
                tiers_applied=[MagicMock(value="summarize")],
            )
            result = runner.invoke(memory, ["prune", "myproj", "--strategy", "summarize"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.ContextCompressor") as mock_cc:
            mock_cc.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["prune", "myproj"])
            assert result.exit_code != 0


class TestCacheStatsCommand:
    """Test cache-stats command."""

    def test_success(self):
        runner = CliRunner()
        with (
            patch("cli_memory.CacheManager") as mock_cm,
            patch("cli_memory.CacheManagerConfig"),
        ):
            mock_cm.return_value.get_statistics.return_value = {
                "entries": 50,
                "hits": 100,
                "misses": 20,
                "hit_rate": 0.83,
                "evictions": 5,
                "expirations": 3,
                "current_size_mb": 25.5,
                "max_size_mb": 100.0,
                "utilization_percent": 25.5,
            }
            result = runner.invoke(memory, ["cache-stats", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.CacheManager") as mock_cm, patch("cli_memory.CacheManagerConfig"):
            mock_cm.return_value.get_statistics.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["cache-stats", "myproj"])
            assert result.exit_code != 0


class TestOptimizeCommand:
    """Test optimize command."""

    def test_success(self):
        runner = CliRunner()
        with (
            patch("cli_memory.get_pool_manager") as mock_pm,
            patch("cli_memory.ContextCache", create=True),
            patch("core.context_cache.ContextCache", create=True),
        ):
            mock_pm.return_value.optimize_all.return_value = None
            result = runner.invoke(memory, ["optimize", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.get_pool_manager") as mock_pm:
            mock_pm.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["optimize", "myproj"])
            assert result.exit_code != 0


class TestClearCacheCommand:
    """Test clear-cache command."""

    def test_clear_all(self):
        runner = CliRunner()
        with (
            patch("cli_memory.CacheManager", create=True),
            patch("core.cache_manager.CacheManager", create=True),
            patch("cli_memory.ContextCache", create=True),
            patch("core.context_cache.ContextCache", create=True),
        ):
            result = runner.invoke(memory, ["clear-cache", "myproj", "--all"])
            assert result.exit_code == 0

    def test_clear_context(self):
        runner = CliRunner()
        with (
            patch("cli_memory.ContextCache", create=True),
            patch("core.context_cache.ContextCache", create=True),
        ):
            result = runner.invoke(memory, ["clear-cache", "myproj", "--context"])
            assert result.exit_code == 0

    def test_clear_summary(self):
        runner = CliRunner()
        with (
            patch("cli_memory.CacheManager", create=True),
            patch("core.cache_manager.CacheManager", create=True),
        ):
            result = runner.invoke(memory, ["clear-cache", "myproj", "--summary"])
            assert result.exit_code == 0

    def test_no_flag(self):
        runner = CliRunner()
        result = runner.invoke(memory, ["clear-cache", "myproj"])
        assert result.exit_code != 0


class TestStressTestCommand:
    """Test stress-test command."""

    def test_no_leaks(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp, patch("time.sleep"):
            mp = mock_mp.return_value
            snap = MagicMock()
            snap.total_memory_mb = 100.0
            mp.take_snapshot.return_value = snap
            mp.get_memory_report.return_value = {
                "summary": {
                    "peak_memory_mb": 150.0,
                    "average_memory_mb": 120.0,
                    "total_change_mb": 30.0,
                },
                "leaks_detected": [],
            }
            result = runner.invoke(memory, ["stress-test", "myproj", "--chapters", "5"])
            assert result.exit_code == 0

    def test_with_leaks(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp, patch("time.sleep"):
            mp = mock_mp.return_value
            snap = MagicMock()
            snap.total_memory_mb = 200.0
            mp.take_snapshot.return_value = snap
            mp.get_memory_report.return_value = {
                "summary": {
                    "peak_memory_mb": 500.0,
                    "average_memory_mb": 300.0,
                    "total_change_mb": 200.0,
                },
                "leaks_detected": ["Leak in chapter buffer"],
            }
            result = runner.invoke(memory, ["stress-test", "myproj", "--chapters", "5"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.MemoryProfiler") as mock_mp, patch("time.sleep"):
            mp = mock_mp.return_value
            mp.take_snapshot.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["stress-test", "myproj", "--chapters", "5"])
            assert result.exit_code != 0


class TestMonitorCommand:
    """Test monitor command."""

    def test_no_triggered_actions(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon, patch("time.sleep"):
            mon = mock_mon.return_value
            mon.get_status_report.return_value = {
                "current_memory_mb": 100.0,
                "trend": "stable",
            }
            mon.get_triggered_actions.return_value = []
            result = runner.invoke(
                memory, ["monitor", "myproj", "--duration", "5", "--interval", "5"]
            )
            assert result.exit_code == 0

    def test_with_triggered_actions(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon, patch("time.sleep"):
            mon = mock_mon.return_value
            mon.get_status_report.return_value = {
                "current_memory_mb": 600.0,
                "trend": "increasing",
            }
            mon.get_triggered_actions.return_value = [
                {"threshold": "heap", "status": "warning"},
                {"threshold": "cache", "status": "critical"},
            ]
            result = runner.invoke(
                memory, ["monitor", "myproj", "--duration", "5", "--interval", "5"]
            )
            assert result.exit_code == 0

    def test_keyboard_interrupt(self):
        runner = CliRunner()
        with (
            patch("cli_memory.create_default_monitor") as mock_mon,
            patch("time.sleep") as mock_sleep,
        ):
            mon = mock_mon.return_value
            mon.get_status_report.return_value = {"current_memory_mb": 100.0, "trend": "stable"}
            mock_sleep.side_effect = KeyboardInterrupt()
            result = runner.invoke(
                memory, ["monitor", "myproj", "--duration", "5", "--interval", "5"]
            )
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.create_default_monitor") as mock_mon, patch("time.sleep"):
            mock_mon.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["monitor", "myproj"])
            assert result.exit_code != 0


class TestPoolStatsCommand:
    """Test pool-stats command."""

    def test_with_pools(self):
        runner = CliRunner()
        with patch("cli_memory.get_pool_manager") as mock_pm:
            mock_pm.return_value.get_all_stats.return_value = {
                "summary_pool": {
                    "total_acquired": 100,
                    "total_released": 95,
                    "total_created": 10,
                    "current_size": 10,
                    "current_available": 5,
                    "current_in_use": 5,
                    "peak_size": 15,
                    "utilization_rate": "50.0%",
                },
            }
            result = runner.invoke(memory, ["pool-stats", "myproj"])
            assert result.exit_code == 0

    def test_no_pools(self):
        runner = CliRunner()
        with patch("cli_memory.get_pool_manager") as mock_pm:
            mock_pm.return_value.get_all_stats.return_value = {}
            result = runner.invoke(memory, ["pool-stats", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with patch("cli_memory.get_pool_manager") as mock_pm:
            mock_pm.side_effect = RuntimeError("err")
            result = runner.invoke(memory, ["pool-stats", "myproj"])
            assert result.exit_code != 0
