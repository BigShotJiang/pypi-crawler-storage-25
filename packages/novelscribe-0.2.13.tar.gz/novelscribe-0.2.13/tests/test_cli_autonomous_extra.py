"""Additional tests for cli_autonomous.py — covering uncovered branches."""

from datetime import datetime
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_autonomous import autonomous


class TestStartAutonomousExtra:
    """Cover uncovered lines in start_autonomous command."""

    def test_start_resume_mode(self):
        runner = CliRunner()
        with (
            patch("cli_autonomous.AutonomousExecutor") as mock_exec_cls,
            patch("cli_autonomous.AutonomousConfig"),
            patch("cli_autonomous.Path") as mock_path,
        ):
            mock_path.return_value.__truediv__ = lambda s, o: mock_path.return_value
            mock_path.return_value.exists.return_value = True
            mock_result = MagicMock()
            mock_result.success = True
            mock_result.completed_phases = ["new_novel", "outline"]
            mock_exec_inst = MagicMock()
            mock_exec_inst.execute.return_value = mock_result
            mock_exec_cls.return_value = mock_exec_inst

            result = runner.invoke(
                autonomous,
                ["start", "myproject", "--resume", "--project-dir", ".novels"],
                obj={"debug": False},
            )
            assert (
                result.exit_code == 0
                or "resuming" in result.output.lower()
                or result.exit_code == 1
            )

    def test_start_failed_pipeline(self):
        runner = CliRunner()
        with (
            patch("cli_autonomous.AutonomousExecutor") as mock_exec_cls,
            patch("cli_autonomous.AutonomousConfig"),
            patch("cli_autonomous.Path") as mock_path,
        ):
            mock_path.return_value.__truediv__ = lambda s, o: mock_path.return_value
            mock_path.return_value.exists.return_value = True
            mock_result = MagicMock()
            mock_result.success = False
            mock_result.final_status = MagicMock(value="failed")
            mock_result.error = "Test error"
            mock_result.completed_phases = ["new_novel"]
            mock_exec_inst = MagicMock()
            mock_exec_inst.execute.return_value = mock_result
            mock_exec_cls.return_value = mock_exec_inst

            result = runner.invoke(
                autonomous,
                ["start", "myproject", "--project-dir", ".novels"],
                obj={"debug": False},
            )
            # Should exit with 1 on failure
            assert result.exit_code == 1 or "failed" in result.output.lower()

    def test_start_exception_with_debug(self):
        runner = CliRunner()
        with (
            patch("cli_autonomous.AutonomousExecutor", side_effect=RuntimeError("boom")),
            patch("cli_autonomous.AutonomousConfig"),
            patch("cli_autonomous.Path") as mock_path,
        ):
            mock_path.return_value.__truediv__ = lambda s, o: mock_path.return_value
            mock_path.return_value.exists.return_value = True

            result = runner.invoke(
                autonomous,
                ["start", "myproject", "--project-dir", ".novels"],
                obj={"debug": True},
            )
            assert result.exit_code == 1

    def test_start_no_project_no_resume(self):
        runner = CliRunner()
        with patch("cli_autonomous.Path") as mock_path:
            mock_path.return_value.__truediv__ = lambda s, o: mock_path.return_value
            mock_path.return_value.exists.return_value = False

            result = runner.invoke(
                autonomous,
                ["start", "nonexistent", "--project-dir", ".novels"],
                obj={"debug": False},
            )
            assert result.exit_code == 1


class TestListCheckpointsExtra:
    """Cover uncovered lines in list_checkpoints command."""

    def test_list_checkpoints_with_results(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp = MagicMock()
            cp.project_name = "test"
            cp.checkpoint_id = "cp_001"
            cp.progress_state.progress_percentage = 50.0
            cp.progress_state.status = MagicMock(value="paused")
            cp.progress_state.current_phase = "writing"
            cp.completed_workflows = ["new_novel", "outline"]
            cp.timestamp = datetime.now()

            mock_inst = MagicMock()
            mock_inst.list_checkpoints.return_value = [cp] * 15
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["checkpoints", "--project-name", "test", "--limit", "5"],
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]

    def test_list_checkpoints_exception(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager", side_effect=OSError("disk error")):
            result = runner.invoke(
                autonomous,
                ["checkpoints", "--project-name", "test"],
                obj={"debug": False},
            )
            assert result.exit_code == 1

    def test_list_checkpoints_no_project_name(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            mock_inst = MagicMock()
            mock_inst.list_checkpoints.return_value = []
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]

    def test_list_checkpoints_filtered_by_project(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp1 = MagicMock()
            cp1.project_name = "proj_a"
            cp2 = MagicMock()
            cp2.project_name = "proj_b"

            mock_inst = MagicMock()
            mock_inst.list_checkpoints.return_value = [cp1, cp2]
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["checkpoints", "--project-name", "proj_a"],
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]


class TestShowCheckpointExtra:
    """Cover uncovered lines in show-checkpoint command."""

    def test_show_checkpoint_with_context_and_workflow(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp = MagicMock()
            cp.checkpoint_id = "cp_001"
            cp.project_name = "test"
            cp.timestamp = datetime.now()
            cp.progress_state.current_phase = "writing"
            cp.progress_state.completed_phases = ["new_novel"]
            cp.progress_state.completed_steps = 5
            cp.progress_state.total_steps = 10
            cp.progress_state.progress_percentage = 50.0
            cp.progress_state.status = MagicMock(value="paused")
            cp.progress_state.current_step = "write_chapter_5"
            cp.progress_state.error = None
            cp.current_workflow = "writing_phase"
            cp.execution_context = {"chapter": 5, "pov": "Elena"}

            mock_inst = MagicMock()
            mock_inst.load_checkpoint.return_value = cp
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["show-checkpoint", "cp_001", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 0 or "writing_phase" in result.output

    def test_show_checkpoint_with_error(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp = MagicMock()
            cp.checkpoint_id = "cp_002"
            cp.project_name = "test"
            cp.timestamp = datetime.now()
            cp.progress_state.current_phase = "writing"
            cp.progress_state.completed_phases = []
            cp.progress_state.completed_steps = 0
            cp.progress_state.total_steps = 10
            cp.progress_state.progress_percentage = 0.0
            cp.progress_state.status = MagicMock(value="error")
            cp.progress_state.current_step = None
            cp.progress_state.error = "Out of memory"
            cp.current_workflow = None
            cp.execution_context = None

            mock_inst = MagicMock()
            mock_inst.load_checkpoint.return_value = cp
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["show-checkpoint", "cp_002", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 0 or "error" in result.output.lower()

    def test_show_checkpoint_exception(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager", side_effect=OSError("disk error")):
            result = runner.invoke(
                autonomous,
                ["show-checkpoint", "cp_001", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 1


class TestDeleteCheckpointExtra:
    """Cover uncovered lines in delete-checkpoint command."""

    def test_delete_with_force(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            mock_inst = MagicMock()
            mock_inst.delete_checkpoint.return_value = True
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_001", "--force", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 0 or "deleted" in result.output.lower()

    def test_delete_with_confirm_yes(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp = MagicMock()
            cp.checkpoint_id = "cp_001"
            cp.project_name = "test"
            cp.progress_state.current_phase = "writing"

            mock_inst = MagicMock()
            mock_inst.load_checkpoint.return_value = cp
            mock_inst.delete_checkpoint.return_value = True
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_001", "--project-dir", ".checkpoints"],
                input="y\n",
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]

    def test_delete_with_confirm_no(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            cp = MagicMock()
            cp.checkpoint_id = "cp_001"
            cp.project_name = "test"
            cp.progress_state.current_phase = "writing"

            mock_inst = MagicMock()
            mock_inst.load_checkpoint.return_value = cp
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_001", "--project-dir", ".checkpoints"],
                input="n\n",
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]

    def test_delete_not_found_no_force(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            mock_inst = MagicMock()
            mock_inst.load_checkpoint.return_value = None
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_missing", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 1

    def test_delete_failed(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager") as mock_cm_cls:
            mock_inst = MagicMock()
            mock_inst.delete_checkpoint.return_value = False
            mock_cm_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_001", "--force", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 1

    def test_delete_exception(self):
        runner = CliRunner()
        with patch("cli_autonomous.CheckpointManager", side_effect=OSError("disk error")):
            result = runner.invoke(
                autonomous,
                ["delete-checkpoint", "cp_001", "--force", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 1


class TestShowProgressExtra:
    """Cover uncovered lines in progress command."""

    def test_progress_with_completed_phases(self):
        runner = CliRunner()
        with patch("cli_autonomous.ProgressTracker") as mock_tracker_cls:
            mock_state = MagicMock()
            mock_state.current_phase = "writing"
            mock_state.status = MagicMock(value="running")
            mock_state.progress_percentage = 60.0
            mock_state.completed_steps = 6
            mock_state.total_steps = 10
            mock_state.completed_phases = ["new_novel", "outline", "character"]
            mock_state.start_time = datetime.now()
            mock_state.last_update = datetime.now()
            mock_state.error = None

            mock_inst = MagicMock()
            mock_inst.get_state.return_value = mock_state
            mock_tracker_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["progress", "myproject", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code in [0, 1]

    def test_progress_exception(self):
        runner = CliRunner()
        with patch("cli_autonomous.ProgressTracker", side_effect=OSError("disk error")):
            result = runner.invoke(
                autonomous,
                ["progress", "myproject", "--project-dir", ".checkpoints"],
                obj={"debug": False},
            )
            assert result.exit_code == 1


class TestShowStatusExtra:
    """Cover uncovered lines in status command."""

    def test_status_no_state(self):
        runner = CliRunner()
        with patch("cli_autonomous.ProgressTracker") as mock_tracker_cls:
            mock_inst = MagicMock()
            mock_inst.get_state.return_value = None
            mock_tracker_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["status", "myproject", "--project-dir", ".novels"],
            )
            assert "no progress" in result.output.lower() or result.exit_code == 0

    def test_status_with_checkpoint_waiting(self):
        runner = CliRunner()
        with (
            patch("cli_autonomous.ProgressTracker") as mock_tracker_cls,
            patch("cli_autonomous.AutonomousExecutor") as mock_exec_cls,
            patch("cli_autonomous.AutonomousConfig"),
        ):
            mock_state = MagicMock()
            mock_state.current_phase = "writing"
            mock_state.status = MagicMock(value="paused")
            mock_state.progress_percentage = 50.0
            mock_state.completed_steps = 5
            mock_state.total_steps = 10
            mock_state.completed_phases = ["outline"]

            mock_tracker = MagicMock()
            mock_tracker.get_state.return_value = mock_state
            mock_tracker_cls.return_value = mock_tracker

            mock_exec = MagicMock()
            mock_exec.checkpoint_waiting.return_value = {
                "checkpoint_id": "cp_001",
                "title": "Chapter 5 Plan",
                "confidence": 0.82,
                "status": "pending",
            }
            mock_exec_cls.return_value = mock_exec

            result = runner.invoke(
                autonomous,
                ["status", "myproject", "--checkpoint", "--project-dir", ".novels"],
            )
            assert "CHECKPOINT" in result.output or result.exit_code == 0

    def test_status_no_checkpoint_waiting(self):
        runner = CliRunner()
        with (
            patch("cli_autonomous.ProgressTracker") as mock_tracker_cls,
            patch("cli_autonomous.AutonomousExecutor") as mock_exec_cls,
            patch("cli_autonomous.AutonomousConfig"),
        ):
            mock_state = MagicMock()
            mock_state.current_phase = "writing"
            mock_state.status = MagicMock(value="running")
            mock_state.progress_percentage = 50.0
            mock_state.completed_steps = 5
            mock_state.total_steps = 10
            mock_state.completed_phases = None

            mock_tracker = MagicMock()
            mock_tracker.get_state.return_value = mock_state
            mock_tracker_cls.return_value = mock_tracker

            mock_exec = MagicMock()
            mock_exec.checkpoint_waiting.return_value = None
            mock_exec_cls.return_value = mock_exec

            result = runner.invoke(
                autonomous,
                ["status", "myproject", "--hybrid", "--project-dir", ".novels"],
            )
            assert result.exit_code == 0

    def test_status_exception(self):
        runner = CliRunner()
        with patch("cli_autonomous.ProgressTracker", side_effect=OSError("disk error")):
            result = runner.invoke(
                autonomous,
                ["status", "myproject", "--project-dir", ".novels"],
            )
            assert result.exit_code == 1


class TestExtendTimerExtra:
    """Cover uncovered lines in extend-timer command."""

    def test_extend_timer_success(self):
        runner = CliRunner()
        with patch("core.timeout_handler.TimeoutHandler") as mock_th_cls:
            mock_inst = MagicMock()
            mock_inst.extend_timer.return_value = True
            mock_th_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["extend-timer", "myproject", "cp_001", "--hours", "2", "--project-dir", ".novels"],
            )
            assert "extended" in result.output.lower() or result.exit_code == 0

    def test_extend_timer_failure(self):
        runner = CliRunner()
        with patch("core.timeout_handler.TimeoutHandler") as mock_th_cls:
            mock_inst = MagicMock()
            mock_inst.extend_timer.return_value = False
            mock_th_cls.return_value = mock_inst

            result = runner.invoke(
                autonomous,
                ["extend-timer", "myproject", "cp_001", "--hours", "2", "--project-dir", ".novels"],
            )
            assert "could not" in result.output.lower() or result.exit_code == 0
