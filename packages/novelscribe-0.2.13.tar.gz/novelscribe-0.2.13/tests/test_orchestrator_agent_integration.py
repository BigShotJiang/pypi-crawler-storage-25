"""Tests for orchestrator_agent_integration module."""

from unittest.mock import Mock, patch

import pytest

from core.orchestrator_agent_integration import AgentSystemIntegration


class TestAgentSystemIntegration:
    """Test AgentSystemIntegration class."""

    @pytest.fixture
    def temp_agents_dir(self, tmp_path):
        """Create temporary agents directory."""
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()
        return agents_dir

    @pytest.fixture
    def mock_llm_client(self):
        """Create mock LLM client."""
        client = Mock()
        client.generate.return_value = "Generated response"
        return client

    @pytest.fixture
    def mock_storage(self):
        """Create mock storage backend."""
        storage = Mock()
        storage.store.return_value = "storage_key"
        storage.retrieve.return_value = "content"
        return storage

    @pytest.fixture
    def mock_work_dir(self, tmp_path):
        """Create temporary work directory."""
        return tmp_path / "work"

    @pytest.fixture
    def integration(self, temp_agents_dir, mock_llm_client, mock_storage, mock_work_dir):
        """Create AgentSystemIntegration instance."""
        with patch("core.orchestrator_agent_integration.AgentRegistry") as mock_registry_class:
            with patch("core.orchestrator_agent_integration.AgentExecutor") as mock_executor_class:
                mock_registry = Mock()
                mock_registry_class.return_value = mock_registry

                mock_executor = Mock()
                mock_executor.context_bus = None
                mock_executor_class.return_value = mock_executor

                integr = AgentSystemIntegration(
                    agents_dir=temp_agents_dir,
                    llm_client=mock_llm_client,
                    storage=mock_storage,
                    work_dir=mock_work_dir,
                )

                integr.registry = mock_registry
                integr.executor = mock_executor

        return integr

    def test_initialization(self, integration, temp_agents_dir, mock_llm_client, mock_storage):
        """Test AgentSystemIntegration initialization."""
        assert integration.registry is not None
        assert integration.executor is not None
        assert integration.logger is not None

    def test_initialization_with_pathlib(self, temp_agents_dir, mock_llm_client, mock_storage):
        """Test initialization with Path objects."""
        with (
            patch("core.orchestrator_agent_integration.AgentRegistry"),
            patch("core.orchestrator_agent_integration.AgentExecutor"),
        ):
            integr = AgentSystemIntegration(
                agents_dir=temp_agents_dir,
                llm_client=mock_llm_client,
                storage=mock_storage,
            )
            assert integr.registry is not None
            assert integr.executor is not None

    def test_execute_agent_step_success(self, integration):
        """Test successful agent step execution."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Test output"
        result.output_files = {"file1": "key1"}
        result.error = None
        result.metadata = {"key": "value"}
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {"var1": "value1"},
            "previous_outputs": {"prev": "output"},
            "input_data": {"input": "data"},
        }
        config = {"model": "gpt-4"}

        response = integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        assert response["agent_name"] == "test_agent"
        assert response["success"] is True
        assert response["output"] == "Test output"
        assert response["output_files"] == {"file1": "key1"}
        assert response["error"] is None
        assert response["metadata"] == {"key": "value"}

    def test_execute_agent_step_missing_dependencies(self, integration, caplog):
        """Test agent step execution with missing dependencies."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = ["dep1", "dep2"]

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Test output"
        result.output_files = {}
        result.error = None
        result.metadata = {}
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": {},
        }
        config = {}

        with caplog.at_level("WARNING"):
            response = integration.execute_agent_step(
                agent_name="test_agent",
                project_name="test_project",
                step_context=step_context,
                config=config,
            )

        assert "missing dependencies" in caplog.text
        assert response["success"] is True

    def test_execute_agent_step_agent_not_found(self, integration):
        """Test agent step execution with non-existent agent."""
        integration.registry.get_agent.return_value = None

        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": {},
        }
        config = {}

        with pytest.raises(ValueError, match="Agent not found"):
            integration.execute_agent_step(
                agent_name="nonexistent",
                project_name="test_project",
                step_context=step_context,
                config=config,
            )

    def test_execute_agent_step_with_context(self, integration):
        """Test agent step execution creates correct AgentContext."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Output"
        result.output_files = {}
        result.error = None
        result.metadata = {}
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {"var1": "value1", "var2": 123},
            "previous_outputs": {"prev1": "out1"},
            "input_data": {"input_key": "input_value"},
        }
        config = {"model": "gpt-4", "temperature": 0.7}

        integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        integration.executor.execute.assert_called_once()
        call_args = integration.executor.execute.call_args
        agent_context = call_args[0][1]

        assert agent_context.project_name == "test_project"
        assert agent_context.variables == {"var1": "value1", "var2": 123}
        assert agent_context.previous_outputs == {"prev1": "out1"}
        assert agent_context.config == config

    def test_list_available_agents(self, integration):
        """Test listing available agents."""
        integration.registry.list_agents.return_value = {
            "agent1": "Description 1",
            "agent2": "Description 2",
        }

        agents = integration.list_available_agents()

        assert agents == {
            "agent1": "Description 1",
            "agent2": "Description 2",
        }
        integration.registry.list_agents.assert_called_once()

    def test_list_available_agents_empty(self, integration):
        """Test listing available agents when none exist."""
        integration.registry.list_agents.return_value = {}

        agents = integration.list_available_agents()

        assert agents == {}

    def test_get_agent_info_found(self, integration):
        """Test getting agent info for existing agent."""
        agent = Mock()
        agent.name = "test_agent"
        agent.version = "1.0"
        agent.description = "Test agent description"
        agent.category.value = "testing"
        agent.input_schema = {"type": "object"}
        agent.output_schema = {"type": "string"}
        agent.dependencies = []
        integration.registry.get_agent.return_value = agent

        info = integration.get_agent_info("test_agent")

        assert info["name"] == "test_agent"
        assert info["version"] == "1.0"
        assert info["description"] == "Test agent description"
        assert info["category"] == "testing"
        assert info["input_schema"] == {"type": "object"}
        assert info["output_schema"] == {"type": "string"}
        assert info["dependencies"] == []

    def test_get_agent_info_not_found(self, integration):
        """Test getting agent info for non-existent agent."""
        integration.registry.get_agent.return_value = None

        info = integration.get_agent_info("nonexistent")

        assert info == {}

    def test_get_agent_info_with_dependencies(self, integration):
        """Test getting agent info with dependencies."""
        agent = Mock()
        agent.name = "test_agent"
        agent.version = "2.0"
        agent.description = "Agent with dependencies"
        agent.category.value = "processing"
        agent.input_schema = {}
        agent.output_schema = {}
        agent.dependencies = ["dep1", "dep2"]
        integration.registry.get_agent.return_value = agent

        info = integration.get_agent_info("test_agent")

        assert info["dependencies"] == ["dep1", "dep2"]

    def test_validate_workflow_agents_all_valid(self, integration):
        """Test validating workflow with all valid agents."""
        integration.registry.agent_exists.side_effect = lambda name: True
        integration.registry.validate_dependencies.side_effect = lambda name: []

        result = integration.validate_workflow_agents(["agent1", "agent2"])

        assert result["missing_agents"] == []
        assert result["missing_dependencies"] == {}

    def test_validate_workflow_agents_missing_agents(self, integration):
        """Test validating workflow with missing agents."""
        integration.registry.agent_exists.side_effect = lambda name: name == "agent1"
        integration.registry.validate_dependencies.side_effect = lambda name: []

        result = integration.validate_workflow_agents(["agent1", "agent2"])

        assert result["missing_agents"] == ["agent2"]
        assert result["missing_dependencies"] == {}

    def test_validate_workflow_agents_missing_dependencies(self, integration):
        """Test validating workflow with missing dependencies."""
        integration.registry.agent_exists.side_effect = lambda name: True
        integration.registry.validate_dependencies.side_effect = lambda name: (
            ["dep1"] if name == "agent1" else []
        )

        result = integration.validate_workflow_agents(["agent1", "agent2"])

        assert result["missing_agents"] == []
        assert result["missing_dependencies"] == {"agent1": ["dep1"]}

    def test_validate_workflow_agents_combined_issues(self, integration):
        """Test validating workflow with both missing agents and dependencies."""
        call_count = [0]

        def agent_exists(name):
            call_count[0] += 1
            return name != "agent2"

        def validate_deps(name):
            call_count[0] += 1
            return ["dep1"] if name == "agent1" else []

        integration.registry.agent_exists.side_effect = agent_exists
        integration.registry.validate_dependencies.side_effect = validate_deps

        result = integration.validate_workflow_agents(["agent1", "agent2", "agent3"])

        assert result["missing_agents"] == ["agent2"]
        assert result["missing_dependencies"] == {"agent1": ["dep1"]}

    def test_validate_workflow_agents_empty_list(self, integration):
        """Test validating empty workflow."""
        result = integration.validate_workflow_agents([])

        assert result["missing_agents"] == []
        assert result["missing_dependencies"] == {}

    def test_execute_agent_step_with_output_files(self, integration):
        """Test agent step execution with output files."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Output"
        result.output_files = {"file1.txt": "key1", "file2.txt": "key2"}
        result.error = None
        result.metadata = {}
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": {},
        }
        config = {}

        response = integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        assert response["output_files"] == {"file1.txt": "key1", "file2.txt": "key2"}

    def test_execute_agent_step_with_error(self, integration):
        """Test agent step execution with error."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = False
        result.output = None
        result.output_files = {}
        result.error = "Error message"
        result.metadata = {}
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": {},
        }
        config = {}

        response = integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        assert response["success"] is False
        assert response["error"] == "Error message"
        assert response["output"] is None

    def test_execute_agent_step_with_metadata(self, integration):
        """Test agent step execution with metadata."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Output"
        result.output_files = {}
        result.error = None
        result.metadata = {
            "tokens_used": 100,
            "execution_time": 1.5,
            "model": "gpt-4",
        }
        integration.executor.execute.return_value = result

        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": {},
        }
        config = {}

        response = integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        assert response["metadata"]["tokens_used"] == 100
        assert response["metadata"]["execution_time"] == 1.5
        assert response["metadata"]["model"] == "gpt-4"

    def test_execute_agent_step_input_data_passed(self, integration):
        """Test that input_data is passed correctly."""
        agent = Mock()
        agent.name = "test_agent"
        integration.registry.get_agent.return_value = agent
        integration.registry.validate_dependencies.return_value = []

        result = Mock()
        result.agent_name = "test_agent"
        result.success = True
        result.output = "Output"
        result.output_files = {}
        result.error = None
        result.metadata = {}
        integration.executor.execute.return_value = result

        input_data = {"key1": "value1", "key2": 123}
        step_context = {
            "variables": {},
            "previous_outputs": {},
            "input_data": input_data,
        }
        config = {}

        integration.execute_agent_step(
            agent_name="test_agent",
            project_name="test_project",
            step_context=step_context,
            config=config,
        )

        integration.executor.execute.assert_called_once()
        call_args = integration.executor.execute.call_args
        assert call_args[0][2] == input_data
