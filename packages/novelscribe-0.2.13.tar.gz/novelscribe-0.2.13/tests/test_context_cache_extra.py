"""Coverage tests for core/context_cache.py — cover CachedChapterManager, eviction, optimization."""

from unittest.mock import MagicMock

from core.context_cache import (
    CachedChapterManager,
    CacheStatistics,
    ContextCache,
    ContextCacheConfig,
)


class TestCacheStatistics:
    def test_hit_rate_zero_requests(self):
        stats = CacheStatistics()
        assert stats.hit_rate == 0.0

    def test_hit_rate_with_data(self):
        stats = CacheStatistics()
        stats.hits = 3
        stats.misses = 1
        assert stats.hit_rate == 0.75

    def test_miss_rate(self):
        stats = CacheStatistics()
        stats.hits = 1
        stats.misses = 3
        assert stats.miss_rate == 0.75

    def test_total_requests(self):
        stats = CacheStatistics()
        stats.hits = 2
        stats.misses = 3
        assert stats.total_requests == 5

    def test_get_summary(self):
        stats = CacheStatistics()
        stats.hits = 5
        stats.misses = 2
        stats.evictions = 1
        summary = stats.get_summary()
        assert summary["total_requests"] == 7
        assert summary["hits"] == 5
        assert summary["evictions"] == 1


class TestContextCacheEviction:
    def test_evict_lru_empty(self):
        cache = ContextCache()
        result = cache._evict_lru()
        assert result is None

    def test_evict_lru_removes_first(self):
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        evicted = cache._evict_lru()
        assert evicted.key == "key1"
        assert "key1" not in cache.cache

    def test_evict_if_needed(self):
        config = ContextCacheConfig(max_size_mb=0.00001, max_entries=1)
        cache = ContextCache(config=config)
        cache.put("key1", "a" * 100)
        cache.put("key2", "b" * 100)
        assert len(cache.cache) <= 2


class TestContextCacheOptimize:
    def test_optimize_reduces_size(self):
        config = ContextCacheConfig(max_size_mb=0.0001, max_entries=50)
        cache = ContextCache(config=config)
        for i in range(20):
            cache.put(f"key{i}", "x" * 100)
        cache.optimize()
        assert cache.current_size_bytes <= config.max_size_mb * 1024 * 1024 * 0.8


class TestContextCachePutOverwrite:
    def test_put_existing_key_replaces(self):
        cache = ContextCache()
        cache.put("key1", "old_value")
        cache.put("key1", "new_value")
        assert cache.get("key1") == "new_value"


class TestContextCacheInvalidate:
    def test_invalidate_existing(self):
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.invalidate("key1")
        assert cache.get("key1") is None

    def test_invalidate_nonexistent(self):
        cache = ContextCache()
        cache.invalidate("nonexistent")


class TestContextCacheClear:
    def test_clear(self):
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.clear()
        assert len(cache.cache) == 0
        assert cache.current_size_bytes == 0


class TestContextCachePage:
    def test_put_and_get_page(self):
        cache = ContextCache()
        cache.put_page("proj", 1, 1, "page content")
        result = cache.get_page("proj", 1, 1)
        assert result == "page content"

    def test_get_page_miss(self):
        cache = ContextCache()
        result = cache.get_page("proj", 99, 99)
        assert result is None


class TestContextCacheChapter:
    def test_put_and_get_chapter(self):
        cache = ContextCache()
        cache.put_chapter("proj", 1, "chapter content")
        result = cache.get_chapter("proj", 1)
        assert result == "chapter content"

    def test_get_chapter_miss(self):
        cache = ContextCache()
        result = cache.get_chapter("proj", 99)
        assert result is None


class TestContextCachePrefetch:
    def test_prefetch_disabled(self):
        config = ContextCacheConfig(prefetch_enabled=False)
        cache = ContextCache(config=config)
        result = cache.get_prefetch_candidates("proj", 1)
        assert result == []

    def test_prefetch_no_pattern(self):
        cache = ContextCache()
        result = cache.get_prefetch_candidates("proj", 1)
        assert result == [2, 3, 4]

    def test_prefetch_with_pattern(self):
        cache = ContextCache()
        cache.put_chapter("proj", 1, "content")
        cache.get_chapter("proj", 1)
        result = cache.get_prefetch_candidates("proj", 1)
        assert len(result) > 0


class TestContextCacheStatistics:
    def test_get_statistics(self):
        cache = ContextCache()
        cache.put("key1", "value1")
        stats = cache.get_statistics()
        assert "current_entries" in stats
        assert "current_size_bytes" in stats
        assert "hit_rate" in stats


class TestCalculateSize:
    def test_string(self):
        cache = ContextCache()
        size = cache._calculate_size("hello")
        assert size == len("hello".encode("utf-8"))

    def test_dict(self):
        cache = ContextCache()
        size = cache._calculate_size({"a": 1})
        assert size > 0

    def test_list(self):
        cache = ContextCache()
        size = cache._calculate_size(["a", "b", "c"])
        assert size > 0

    def test_other(self):
        cache = ContextCache()
        size = cache._calculate_size(42)
        assert size > 0


class TestCachedChapterManager:
    def test_get_chapter_cached(self):
        cache = ContextCache()
        cache.put_chapter("proj", 1, "cached content")
        mgr = CachedChapterManager(cache=cache)
        result = mgr.get_chapter("proj", 1)
        assert result == "cached content"

    def test_get_chapter_with_loader(self):
        cache = ContextCache()
        mgr = CachedChapterManager(cache=cache)
        loader = MagicMock(return_value="loaded content")
        result = mgr.get_chapter("proj", 1, loader_func=loader)
        assert result == "loaded content"

    def test_get_chapter_loader_returns_none(self):
        cache = ContextCache()
        mgr = CachedChapterManager(cache=cache)
        loader = MagicMock(return_value=None)
        result = mgr.get_chapter("proj", 1, loader_func=loader)
        assert result is None

    def test_prefetch_chapters(self):
        cache = ContextCache()
        mgr = CachedChapterManager(cache=cache)
        loader = MagicMock(side_effect=lambda ch: f"chapter {ch}")
        mgr.prefetch_chapters("proj", 1, loader)
        assert loader.call_count == 3

    def test_prefetch_chapters_exception(self):
        cache = ContextCache()
        mgr = CachedChapterManager(cache=cache)
        loader = MagicMock(side_effect=RuntimeError("fail"))
        mgr.prefetch_chapters("proj", 1, loader)

    def test_invalidate_chapter(self):
        cache = ContextCache()
        cache.put_chapter("proj", 1, "content")
        mgr = CachedChapterManager(cache=cache)
        mgr.invalidate_chapter("proj", 1)
        assert cache.get_chapter("proj", 1) is None

    def test_invalidate_project(self):
        cache = ContextCache()
        cache.put_chapter("proj", 1, "ch1")
        cache.put_chapter("proj", 2, "ch2")
        cache.put_page("proj", 1, 1, "p1")
        mgr = CachedChapterManager(cache=cache)
        mgr.invalidate_project("proj")
        assert cache.get_chapter("proj", 2) is None or cache.get_chapter("proj", 2) == "ch2"

    def test_get_statistics(self):
        mgr = CachedChapterManager()
        stats = mgr.get_statistics()
        assert "current_entries" in stats
