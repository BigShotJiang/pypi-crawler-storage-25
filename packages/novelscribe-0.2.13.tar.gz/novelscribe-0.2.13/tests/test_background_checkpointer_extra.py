"""Coverage tests for core/background_checkpointer.py."""

from unittest.mock import MagicMock

from core.background_checkpointer import BackgroundCheckpointer, create_background_checkpointer
from core.hybrid_authority import AuthorityConfig, AuthorityLevel


class TestStartStopMonitoring:
    def test_start_with_timeout(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=2.0)
        assert "cp_001" in bp._deadlines

    def test_start_no_timeout_no_config_timeout(self):
        config = AuthorityConfig()
        config.timeout_hours = None
        bp = BackgroundCheckpointer(authority_config=config)
        bp.start_monitoring("cp_001")
        assert "cp_001" not in bp._deadlines

    def test_start_uses_config_timeout(self):
        config = AuthorityConfig(timeout_hours=5.0)
        bp = BackgroundCheckpointer(authority_config=config)
        bp.start_monitoring("cp_001")
        assert "cp_001" in bp._deadlines

    def test_stop_removes_deadline(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.stop_monitoring("cp_001")
        assert "cp_001" not in bp._deadlines

    def test_stop_removes_callback(self):
        bp = BackgroundCheckpointer()
        cb = MagicMock()
        bp.set_checkpoint_callback("cp_001", cb)
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.stop_monitoring("cp_001")
        assert "cp_001" not in bp._checkpoint_callbacks


class TestExtendDeadline:
    def test_extend_existing(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        result = bp.extend_deadline("cp_001", hours=2.0)
        assert result is True

    def test_extend_nonexistent(self):
        bp = BackgroundCheckpointer()
        result = bp.extend_deadline("cp_nonexistent", hours=2.0)
        assert result is False


class TestGetDeadlineStatus:
    def test_existing_deadline(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        status = bp.get_deadline_status("cp_001")
        assert status is not None
        assert status["checkpoint_id"] == "cp_001"
        assert status["is_expired"] is False

    def test_nonexistent_deadline(self):
        bp = BackgroundCheckpointer()
        status = bp.get_deadline_status("cp_missing")
        assert status is None


class TestShouldAutoApprove:
    def test_ai_only_always_approves(self):
        config = AuthorityConfig(level=AuthorityLevel.AI_ONLY)
        bp = BackgroundCheckpointer(authority_config=config)
        approved, reason = bp.should_auto_approve("cp_001", 0.5)
        assert approved is True

    def test_non_ai_only_uses_authority(self):
        config = AuthorityConfig(level=AuthorityLevel.HUMAN_FIRST)
        bp = BackgroundCheckpointer(authority_config=config)
        approved, reason = bp.should_auto_approve("cp_001", 0.5)
        assert isinstance(approved, bool)


class TestRecordActions:
    def test_record_approval(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.record_approval("cp_001", was_auto=True)
        assert "cp_001" not in bp._deadlines

    def test_record_modification(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.record_modification("cp_001")
        assert "cp_001" not in bp._deadlines

    def test_record_rejection_with_escalation(self):
        on_escalation = MagicMock()
        config = AuthorityConfig(escalate_on_reject=True)
        bp = BackgroundCheckpointer(authority_config=config, on_escalation=on_escalation)
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.record_rejection("cp_001")
        assert "cp_001" not in bp._deadlines

    def test_record_rejection_without_escalation(self):
        config = AuthorityConfig(escalate_on_reject=False)
        bp = BackgroundCheckpointer(authority_config=config)
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp.record_rejection("cp_001")
        assert "cp_001" not in bp._deadlines


class TestNotifications:
    def test_get_pending_all(self):
        bp = BackgroundCheckpointer()
        bp._add_notification("timeout", "cp_001", "Timed out")
        bp._add_notification("reminder", "cp_002", "Reminder")
        notifications = bp.get_pending_notifications()
        assert len(notifications) == 2

    def test_get_pending_filtered(self):
        bp = BackgroundCheckpointer()
        bp._add_notification("timeout", "cp_001", "Timed out")
        bp._add_notification("reminder", "cp_002", "Reminder")
        notifications = bp.get_pending_notifications(checkpoint_id="cp_001")
        assert len(notifications) == 1

    def test_mark_read(self):
        bp = BackgroundCheckpointer()
        bp._add_notification("timeout", "cp_001", "Timed out")
        notif_id = bp._notifications[0].notification_id
        bp.mark_notification_read(notif_id)
        assert bp._notifications[0].read is True

    def test_clear_all(self):
        bp = BackgroundCheckpointer()
        bp._add_notification("timeout", "cp_001", "Timed out")
        bp.clear_notifications()
        assert len(bp._notifications) == 0

    def test_clear_by_checkpoint(self):
        bp = BackgroundCheckpointer()
        bp._add_notification("timeout", "cp_001", "Timed out")
        bp._add_notification("reminder", "cp_002", "Reminder")
        bp.clear_notifications(checkpoint_id="cp_001")
        assert len(bp._notifications) == 1


class TestHandleTimeout:
    def test_timeout_triggers_callback(self):
        on_timeout = MagicMock()
        bp = BackgroundCheckpointer(on_timeout=on_timeout)
        bp._executor.shutdown(wait=False)
        bp._executor = MagicMock()

        bp.start_monitoring("cp_001", timeout_hours=-1)
        bp._handle_timeout("cp_001")

        bp._executor.submit.assert_any_call(on_timeout, "cp_001")

    def test_timeout_already_escalated(self):
        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp._deadlines["cp_001"].escalation_triggered = True
        bp._handle_timeout("cp_001")
        assert len(bp._notifications) == 0


class TestSendReminder:
    def test_reminder_sent(self):
        on_reminder = MagicMock()
        bp = BackgroundCheckpointer(on_reminder=on_reminder)
        bp.start_monitoring("cp_001", timeout_hours=1.0)
        bp._send_reminder("cp_001")
        assert bp._deadlines["cp_001"].reminder_sent is True


class TestGetTrustAndAuthority:
    def test_get_trust_score(self):
        bp = BackgroundCheckpointer()
        score = bp.get_trust_score()
        assert isinstance(score, float)

    def test_get_authority_status(self):
        bp = BackgroundCheckpointer()
        status = bp.get_authority_status()
        assert "level" in status
        assert "trust_score" in status


class TestShutdown:
    def test_shutdown(self):
        bp = BackgroundCheckpointer()
        bp._running = True
        bp.shutdown()
        assert bp._running is False


class TestFactoryFunction:
    def test_create_with_level(self):
        bp = create_background_checkpointer(authority_level=AuthorityLevel.AI_ONLY)
        assert isinstance(bp, BackgroundCheckpointer)

    def test_create_without_level(self):
        bp = create_background_checkpointer()
        assert isinstance(bp, BackgroundCheckpointer)

    def test_create_with_timeout(self):
        on_timeout = MagicMock()
        bp = create_background_checkpointer(on_timeout=on_timeout)
        assert bp._on_timeout is on_timeout
