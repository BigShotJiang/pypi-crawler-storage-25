"""Unit tests for context_assembly.py — ContextBlock and ContextAssembler."""

from pathlib import Path

import pytest

from core.context_assembly import NON_COMPRESSIBLE_TYPES, ContextAssembler, ContextBlock
from core.context_schema import AgentContextSchema, ContextNeed, TokenBudget
from core.context_store import (
    ContextStore,
    ContextStoreConfig,
)


@pytest.fixture
def store_dir(tmp_path: Path) -> Path:
    d = tmp_path / "context"
    d.mkdir()
    return d


@pytest.fixture
def store(store_dir: Path) -> ContextStore:
    return ContextStore(store_dir, ContextStoreConfig())


@pytest.fixture
def budget() -> TokenBudget:
    return TokenBudget.create(total_limit=128000, reserved_output=4096)


@pytest.fixture
def assembler() -> ContextAssembler:
    return ContextAssembler()


def _ingest(
    store: ContextStore,
    artifact_type: str,
    content: str,
    source_agent: str = "test",
    chapter_number: int | None = None,
) -> str:
    return store.ingest(artifact_type, content, source_agent, chapter_number)


class TestContextBlock:
    def test_create_basic(self):
        block = ContextBlock(
            source="meta",
            priority=0,
            content="test content",
            token_count=10,
        )
        assert block.source == "meta"
        assert block.priority == 0
        assert block.content == "test content"
        assert block.token_count == 10
        assert block.compressible is True
        assert block.label == ""

    def test_non_compressible(self):
        block = ContextBlock(
            source="outline",
            priority=0,
            content="outline",
            token_count=5,
            compressible=False,
        )
        assert not block.compressible

    def test_with_label(self):
        block = ContextBlock(
            source="chapter",
            priority=1,
            content="chapter text",
            token_count=100,
            label="chapter 5 (recent)",
        )
        assert block.label == "chapter 5 (recent)"


class TestNonCompressibleTypes:
    def test_meta_not_compressible(self):
        assert "meta" in NON_COMPRESSIBLE_TYPES

    def test_outline_not_compressible(self):
        assert "outline" in NON_COMPRESSIBLE_TYPES

    def test_chapter_is_compressible(self):
        assert "chapter" not in NON_COMPRESSIBLE_TYPES

    def test_world_is_compressible(self):
        assert "world" not in NON_COMPRESSIBLE_TYPES


class TestAssemblerEmpty:
    def test_empty_schema_empty_store(self, assembler, store, budget):
        schema = AgentContextSchema()
        blocks = assembler.assemble(schema, budget, store)
        assert blocks == []

    def test_schema_with_needs_empty_store(self, assembler, store, budget):
        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
        )
        blocks = assembler.assemble(schema, budget, store)
        assert blocks == []


class TestAssemblerRequired:
    def test_single_required(self, assembler, store, budget):
        _ingest(store, "meta", "A fantasy novel about dragons.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 1
        assert blocks[0].source == "meta"
        assert blocks[0].priority == 0
        assert blocks[0].compressible is False
        assert "dragons" in blocks[0].content

    def test_multiple_required(self, assembler, store, budget):
        _ingest(store, "meta", "The story concept.")
        _ingest(store, "outline", "Chapter 1: The beginning.")

        schema = AgentContextSchema(
            required=[
                ContextNeed(artifact_type="meta"),
                ContextNeed(artifact_type="outline"),
            ],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 2
        assert blocks[0].source == "meta"
        assert blocks[1].source == "outline"
        assert all(b.priority == 0 for b in blocks)

    def test_required_not_compressible_for_meta(self, assembler, store, budget):
        _ingest(store, "meta", "Story metadata.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert blocks[0].compressible is False

    def test_required_compressible_for_chapter(self, assembler, store, budget):
        _ingest(store, "chapter", "Chapter content.", chapter_number=1)

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="chapter", scope="latest")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert blocks[0].compressible is True


class TestAssemblerOptional:
    def test_optional_after_required(self, assembler, store, budget):
        _ingest(store, "meta", "Story concept.")
        _ingest(store, "world", "A vast magical realm.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
            optional=[ContextNeed(artifact_type="world")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 2
        assert blocks[0].priority == 0
        assert blocks[1].priority == 1

    def test_optional_only(self, assembler, store, budget):
        _ingest(store, "world", "The world of Aethermoor.")

        schema = AgentContextSchema(
            optional=[ContextNeed(artifact_type="world")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 1
        assert blocks[0].priority == 1


class TestAssemblerScopes:
    def test_scope_latest(self, assembler, store, budget):
        _ingest(store, "meta", "First version.")
        _ingest(store, "meta", "Second version.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta", scope="latest")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 1
        assert "Second version" in blocks[0].content

    def test_scope_recent_chapters(self, assembler, store, budget):
        for i in range(1, 6):
            _ingest(store, "chapter", f"Chapter {i} content.", chapter_number=i)

        schema = AgentContextSchema(
            optional=[ContextNeed(artifact_type="chapter", scope="recent", recent_count=3)],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 3

    def test_scope_all(self, assembler, store, budget):
        _ingest(store, "summary", "Summary for chapter 1.", chapter_number=1)
        _ingest(store, "summary", "Summary for chapter 6.", chapter_number=6)

        schema = AgentContextSchema(
            optional=[ContextNeed(artifact_type="summary", scope="all")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 2

    def test_scope_latest_missing_type(self, assembler, store, budget):
        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="nonexistent")],
        )
        blocks = assembler.assemble(schema, budget, store)
        assert blocks == []


class TestAssemblerMaxTokens:
    def test_max_tokens_caps_content(self, assembler, store, budget):
        long_content = "word " * 5000
        _ingest(store, "world", long_content)

        schema = AgentContextSchema(
            optional=[ContextNeed(artifact_type="world", max_tokens=200)],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert len(blocks) == 1
        assert blocks[0].token_count <= 200


class TestAssemblerLabels:
    def test_label_includes_artifact_type(self, assembler, store, budget):
        _ingest(store, "meta", "Metadata content.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert "meta" in blocks[0].label

    def test_label_includes_scope(self, assembler, store, budget):
        _ingest(store, "meta", "Content.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta", scope="latest")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert "latest" in blocks[0].label

    def test_label_includes_chapter_number(self, assembler, store, budget):
        _ingest(store, "chapter", "Chapter text.", chapter_number=5)

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="chapter", scope="latest")],
        )
        blocks = assembler.assemble(schema, budget, store)

        assert "5" in blocks[0].label


class TestAssemblerOrdering:
    def test_required_always_first(self, assembler, store, budget):
        _ingest(store, "meta", "Meta.")
        _ingest(store, "world", "World.")
        _ingest(store, "characters", "Characters.")

        schema = AgentContextSchema(
            required=[ContextNeed(artifact_type="meta")],
            optional=[
                ContextNeed(artifact_type="world"),
                ContextNeed(artifact_type="characters"),
            ],
        )
        blocks = assembler.assemble(schema, budget, store)

        required_blocks = [b for b in blocks if b.priority == 0]
        optional_blocks = [b for b in blocks if b.priority == 1]

        assert len(required_blocks) == 1
        assert len(optional_blocks) == 2
        assert blocks[0].source == "meta"

    def test_writer_agent_full_schema(self, assembler, store, budget):
        _ingest(store, "meta", "Story concept.")
        _ingest(store, "outline", "Outline text.")
        _ingest(store, "characters", "Character profiles.")
        _ingest(store, "world", "World lore.")
        _ingest(store, "chapter", "Chapter 1.", chapter_number=1)
        _ingest(store, "chapter", "Chapter 2.", chapter_number=2)

        schema = AgentContextSchema(
            required=[
                ContextNeed(artifact_type="meta"),
                ContextNeed(artifact_type="outline"),
                ContextNeed(artifact_type="characters"),
            ],
            optional=[
                ContextNeed(artifact_type="world"),
                ContextNeed(artifact_type="chapter", scope="recent", recent_count=2),
            ],
        )
        blocks = assembler.assemble(schema, budget, store)

        required = [b for b in blocks if b.priority == 0]
        optional = [b for b in blocks if b.priority == 1]

        assert len(required) == 3
        assert len(optional) == 3
        assert blocks[0].source == "meta"
        assert blocks[1].source == "outline"
        assert blocks[2].source == "characters"
