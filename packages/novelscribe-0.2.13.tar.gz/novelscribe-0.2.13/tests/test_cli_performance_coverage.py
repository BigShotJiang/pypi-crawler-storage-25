"""Comprehensive tests for cli_performance module - testing extracted business logic."""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_performance import (
    _display_cache_info,
    _display_file_stats,
    _display_llm_stats,
    _display_profile_report,
    _display_summary,
    analyze_exec_graph,
    build_parallel_graph,
    clear_file_cache_internal,
    clear_llm_cache_internal,
    estimate_workflow_cost,
    execute_parallel_workflow,
    format_bottlenecks_list,
    get_bottlenecks,
    get_file_stats,
    get_llm_stats,
    get_mock_agent_functions,
    get_sample_workflow_steps,
    get_workflow_estimations,
    parse_file_size,
    performance_cli,
    register_performance_cli,
    run_benchmark_io,
    run_profile_workflow,
)


class TestParseFileSize:
    """Test parse_file_size function."""

    def test_parse_kilobytes(self):
        assert parse_file_size("500K") == 500 * 1024

    def test_parse_megabytes(self):
        assert parse_file_size("1M") == 1024 * 1024

    def test_parse_gigabytes(self):
        assert parse_file_size("1G") == 1024 * 1024 * 1024

    def test_parse_numeric_only(self):
        assert parse_file_size("1024") == 1024


class TestDisplaySummary:
    """Test _display_summary helper."""

    def test_flat_summary(self):
        summary = {"count": 10, "total": 100}
        _display_summary(summary)

    def test_nested_summary(self):
        summary = {"outer": {"inner_key": "inner_val", "count": 5}}
        _display_summary(summary)


class TestDisplayCacheInfo:
    """Test _display_cache_info helper."""

    def test_cache_info_basic(self):
        cache_info = {"size": 100, "max_size": 1000, "hit_rate": 0.8}
        _display_cache_info(cache_info)

    def test_cache_info_with_most_accessed(self):
        cache_info = {
            "size": 50,
            "max_size": 100,
            "hit_rate": 0.7,
            "most_accessed": [("file1.txt", 100), ("file2.txt", 50)],
        }
        _display_cache_info(cache_info)

    def test_cache_info_empty(self):
        cache_info = {}
        _display_cache_info(cache_info)


class TestGetMockAgentFunctions:
    """Test get_mock_agent_functions."""

    def test_returns_dict(self):
        funcs = get_mock_agent_functions()
        assert isinstance(funcs, dict)

    def test_has_expected_agents(self):
        funcs = get_mock_agent_functions()
        assert "discuss_agent" in funcs
        assert "genre_agent" in funcs
        assert "character_agent" in funcs
        assert "world_agent" in funcs

    def test_functions_callable(self):
        funcs = get_mock_agent_functions()
        for name, func in funcs.items():
            assert callable(func)


class TestGetSampleWorkflowSteps:
    """Test get_sample_workflow_steps."""

    def test_returns_list(self):
        steps = get_sample_workflow_steps()
        assert isinstance(steps, list)

    def test_has_required_agents(self):
        steps = get_sample_workflow_steps()
        agents = {s["agent"] for s in steps}
        assert "discuss_agent" in agents
        assert "character_agent" in agents
        assert "world_agent" in agents


class TestGetWorkflowEstimations:
    """Test get_workflow_estimations."""

    def test_has_autonomous(self):
        est = get_workflow_estimations()
        assert "autonomous" in est

    def test_has_writing_phase(self):
        est = get_workflow_estimations()
        assert "writing_phase" in est

    def test_estimation_structure(self):
        est = get_workflow_estimations()
        for workflow, data in est.items():
            assert "calls" in data
            assert "avg_tokens" in data
            assert "model" in data


class TestEstimateWorkflowCost:
    """Test estimate_workflow_cost."""

    def test_autonomous_workflow(self):
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value._estimate_cost.return_value = 5.50
            result = estimate_workflow_cost("autonomous")
            assert result["calls"] == 50
            assert result["model"] == "gpt-3.5-turbo"
            assert result["total_tokens"] == 50 * 2000
            assert result["estimated_cost"] == 5.50

    def test_writing_phase_workflow(self):
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value._estimate_cost.return_value = 12.75
            result = estimate_workflow_cost("writing_phase")
            assert result["calls"] == 20
            assert result["model"] == "gpt-4"

    def test_unknown_workflow_raises(self):
        with patch("cli_performance.get_llm_optimizer"):
            try:
                estimate_workflow_cost("unknown")
                assert False, "Should have raised ValueError"
            except ValueError as e:
                assert "Unknown workflow" in str(e)


class TestClearFileCacheInternal:
    """Test clear_file_cache_internal."""

    def test_calls_optimizer(self):
        with patch("cli_performance.get_file_optimizer") as mo:
            clear_file_cache_internal()
            mo.return_value.clear_cache.assert_called_once()
            mo.return_value.clear_write_cache.assert_called_once()


class TestClearLlmCacheInternal:
    """Test clear_llm_cache_internal."""

    def test_clear_all(self):
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value.clear_cache.return_value = 50
            count = clear_llm_cache_internal()
            assert count == 50
            mo.return_value.clear_cache.assert_called_once_with(model=None)

    def test_clear_specific_model(self):
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value.clear_cache.return_value = 25
            count = clear_llm_cache_internal(model="gpt-4")
            assert count == 25
            mo.return_value.clear_cache.assert_called_once_with(model="gpt-4")


class TestGetBottlenecks:
    """Test get_bottlenecks."""

    def test_calls_identify_bottlenecks(self):
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = []
            result = get_bottlenecks(threshold=5.0)
            mp.return_value.identify_bottlenecks.assert_called_once()
            assert "bottlenecks" in result

    def test_with_bottlenecks(self):
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = ["Agent 'x': 6.0s"]
            result = get_bottlenecks()
            assert len(result["bottlenecks"]) == 1

    def test_with_type_filter(self):
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = []
            result = get_bottlenecks(threshold=2.0, profile_type="agent")
            mp.return_value.identify_bottlenecks.assert_called_once()
            assert len(result["bottlenecks"]) == 0


class TestGetFileStats:
    """Test get_file_stats."""

    def test_returns_stats_dict(self):
        with patch("cli_performance.get_file_optimizer") as mo:
            mo.return_value.get_stats.return_value.to_dict.return_value = {"reads": 100}
            mo.return_value.get_cache_info.return_value = {"size": 10}
            mo.return_value.get_write_cache_info.return_value = {"size": 5}
            result = get_file_stats()
            assert "stats" in result
            assert "cache_info" in result
            assert "write_cache_info" in result


class TestGetLlmStats:
    """Test get_llm_stats."""

    def test_returns_stats_dict(self):
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value.get_stats.return_value.to_dict.return_value = {"calls": 100}
            mo.return_value.get_cache_info.return_value = {"size": 50}
            mo.return_value.get_rate_limit_info.return_value = {"openai": {"available": 90}}
            result = get_llm_stats()
            assert "stats" in result
            assert "cache_info" in result
            assert "rate_info" in result


class TestRunProfileWorkflow:
    """Test run_profile_workflow."""

    def test_returns_profiler_and_report(self):
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mp.return_value.get_report.return_value = mock_report
            result = run_profile_workflow("autonomous")
            assert "profiler" in result
            assert "report" in result
            assert result["report"] == mock_report


class TestAnalyzeExecGraph:
    """Test analyze_exec_graph."""

    def test_validates_graph(self):
        with patch("cli_performance.get_parallel_executor") as me:
            mock_graph = MagicMock()
            mock_graph.nodes = {"n1": MagicMock(dependencies=[])}
            mock_graph.validate.return_value = (True, [])
            mock_graph.topological_sort.return_value = ["n1"]
            mock_graph.get_ready_nodes.return_value = [mock_graph.nodes["n1"]]
            me.return_value.build_graph_from_workflow.return_value = mock_graph

            result = analyze_exec_graph("autonomous")
            assert result["is_valid"] is True
            assert len(result["errors"]) == 0


class TestBuildParallelGraph:
    """Test build_parallel_graph."""

    def test_returns_graph(self):
        with patch("cli_performance.ParallelExecutor") as mock_pe:
            mock_graph = MagicMock()
            mock_pe.return_value.build_graph_from_workflow.return_value = mock_graph
            result = build_parallel_graph()
            assert result == mock_graph


class TestExecuteParallelWorkflow:
    """Test execute_parallel_workflow."""

    def test_executes_and_returns_result(self):
        with patch("cli_performance.ParallelExecutor") as mock_pe:
            mock_executor = MagicMock()
            mock_graph = MagicMock()
            mock_result = MagicMock()
            mock_result.success = True
            mock_result.completed_nodes = ["n1"]
            mock_result.failed_nodes = []
            mock_result.skipped_nodes = []
            mock_result.errors = {}
            mock_result.total_duration = 1.5
            mock_graph.nodes = {"n1": MagicMock(agent_name="discuss_agent")}
            mock_executor.build_graph_from_workflow.return_value = mock_graph
            mock_executor.execute_parallel.return_value = mock_result
            mock_pe.return_value = mock_executor

            result = execute_parallel_workflow(max_workers=4)
            assert "result" in result
            assert "graph" in result


class TestFormatBottlenecksList:
    """Test format_bottlenecks_list."""

    def test_returns_list(self):
        result = format_bottlenecks_list(["a: 1.0s", "b: 2.0s"], 5.0)
        assert isinstance(result, list)


class TestRunBenchmarkIo:
    """Test run_benchmark_io."""

    def test_runs_benchmark(self):
        with patch("cli_performance.get_file_optimizer") as mo:
            mo.return_value.write_file = MagicMock()
            mo.return_value.read_file = MagicMock()
            result = run_benchmark_io("1M")
            assert "write_time" in result
            assert "read_time" in result
            assert "write_mbps" in result
            assert "read_mbps" in result


class TestDisplayProfileReport:
    """Test _display_profile_report helper."""

    def test_nested_summary(self):
        report = MagicMock()
        report.total_duration = 5.0
        report.summary = {"outer": {"inner_key": "inner_val"}}
        report.bottlenecks = []
        _display_profile_report(report)

    def test_with_bottlenecks(self):
        report = MagicMock()
        report.total_duration = 8.0
        report.summary = {"agents": 3}
        report.bottlenecks = ["Slow agent: 6.0s"]
        _display_profile_report(report)

    def test_flat_summary(self):
        report = MagicMock()
        report.total_duration = 2.0
        report.summary = {"calls": 10}
        report.bottlenecks = []
        _display_profile_report(report)


class TestDisplayFileStats:
    """Test _display_file_stats."""

    def test_displays_stats(self):
        result = {
            "stats": MagicMock(to_dict=lambda: {"reads": 100, "writes": 50}),
            "cache_info": {"size": 10, "max_size": 100, "hit_rate": 0.8, "most_accessed": None},
            "write_cache_info": {"size": 5, "max_size": 50},
        }
        _display_file_stats(result)

    def test_with_most_accessed(self):
        result = {
            "stats": MagicMock(to_dict=lambda: {"reads": 100}),
            "cache_info": {
                "size": 10,
                "max_size": 100,
                "hit_rate": 0.8,
                "most_accessed": [("file1.txt", 50), ("file2.txt", 30)],
            },
            "write_cache_info": {},
        }
        _display_file_stats(result)


class TestDisplayLlmStats:
    """Test _display_llm_stats."""

    def test_displays_stats(self):
        result = {
            "stats": MagicMock(to_dict=lambda: {"total_calls": 100}),
            "cache_info": {"size": 50, "max_size": 100},
            "rate_info": {"openai": {"available": 90, "max": 100}},
        }
        _display_llm_stats(result)

    def test_without_rate_limits(self):
        result = {
            "stats": MagicMock(to_dict=lambda: {"total_calls": 0}),
            "cache_info": {"size": 0, "max_size": 0, "oldest_entry": None, "newest_entry": None},
            "rate_info": None,
        }
        _display_llm_stats(result)

    def test_with_timestamp_entries(self):
        result = {
            "stats": MagicMock(to_dict=lambda: {"total_calls": 10}),
            "cache_info": {"size": 5, "oldest_entry": 1234567890, "newest_entry": 1234567900},
            "rate_info": {},
        }
        _display_llm_stats(result)


class TestPerformanceCLIGroup:
    """Test performance CLI group and registration."""

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["--help"])
        assert result.exit_code == 0

    def test_register_performance_cli(self):
        mock_cli = MagicMock()
        register_performance_cli(mock_cli)
        mock_cli.add_command.assert_called_once_with(performance_cli)


class TestProfileCommand:
    """Test profile command with all format and output variations."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["profile"])
        assert result.exit_code != 0

    def test_text_format_default(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mock_report.total_duration = 1.5
            mock_report.summary = {"agents": 2}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {"total_duration": 1.5}
            mp.return_value.get_report.return_value = mock_report
            result = runner.invoke(performance_cli, ["profile", "myproj"])
            assert result.exit_code == 0

    def test_json_format_to_file(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mock_report.to_dict.return_value = {"total_duration": 2.0}
            mp.return_value.get_report.return_value = mock_report
            with runner.isolated_filesystem():
                result = runner.invoke(
                    performance_cli, ["profile", "myproj", "--format", "json", "-o", "out.json"]
                )
                assert result.exit_code == 0
                assert "saved" in result.output.lower()

    def test_csv_format_with_output(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mock_report.to_dict.return_value = {}
            mp.return_value.get_report.return_value = mock_report
            mp.return_value.export_data = MagicMock()
            with runner.isolated_filesystem():
                result = runner.invoke(
                    performance_cli, ["profile", "myproj", "--format", "csv", "-o", "out.csv"]
                )
                assert result.exit_code == 0
                assert "CSV" in result.output

    def test_csv_format_without_output(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mp.return_value.get_report.return_value = mock_report
            result = runner.invoke(performance_cli, ["profile", "myproj", "--format", "csv"])
            assert "Error" in result.output

    def test_custom_workflow(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mock_report = MagicMock()
            mock_report.total_duration = 1.5
            mock_report.summary = {}
            mock_report.bottlenecks = []
            mock_report.to_dict.return_value = {}
            mp.return_value.get_report.return_value = mock_report
            result = runner.invoke(
                performance_cli, ["profile", "myproj", "--workflow", "writing_phase"]
            )
            assert result.exit_code == 0


class TestBottlenecksCommand:
    """Test bottlenecks command."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["bottlenecks"])
        assert result.exit_code != 0

    def test_no_bottlenecks(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = []
            result = runner.invoke(performance_cli, ["bottlenecks", "myproj"])
            assert "No bottlenecks" in result.output

    def test_with_bottlenecks(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = ["Agent 'x': 6.0s"]
            result = runner.invoke(performance_cli, ["bottlenecks", "myproj"])
            assert "Agent 'x'" in result.output

    def test_with_threshold(self):
        runner = CliRunner()
        with patch("cli_performance.get_profiler") as mp:
            mp.return_value.identify_bottlenecks.return_value = []
            result = runner.invoke(performance_cli, ["bottlenecks", "myproj", "--threshold", "2.0"])
            assert "2.0" in result.output


class TestFileStatsCommand:
    """Test file-stats command."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["file-stats"])
        assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with patch("cli_performance.get_file_optimizer") as mo:
            opt = mo.return_value
            opt.get_stats.return_value.to_dict.return_value = {"reads": 100, "writes": 50}
            opt.get_cache_info.return_value = {
                "size": 10,
                "max_size": 100,
                "hit_rate": 0.8,
                "most_accessed": [("f1.txt", 50)],
            }
            opt.get_write_cache_info.return_value = {"size": 5, "max_size": 50}
            result = runner.invoke(performance_cli, ["file-stats", "myproj"])
            assert "FILE I/O STATISTICS" in result.output


class TestClearFileCacheCommand:
    """Test clear-file-cache command."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["clear-file-cache"])
        assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with patch("cli_performance.get_file_optimizer"):
            result = runner.invoke(performance_cli, ["clear-file-cache", "myproj"])
            assert "cleared" in result.output.lower()


class TestLlmCacheCommand:
    """Test llm-cache command."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["llm-cache"])
        assert result.exit_code != 0

    def test_clear_all(self):
        runner = CliRunner()
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value.clear_cache.return_value = 50
            result = runner.invoke(performance_cli, ["llm-cache", "myproj"])
            assert "50" in result.output

    def test_clear_specific_model(self):
        runner = CliRunner()
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value.clear_cache.return_value = 25
            result = runner.invoke(performance_cli, ["llm-cache", "myproj", "--model", "gpt-4"])
            assert "gpt-4" in result.output


class TestEstimateCostCommand:
    """Test estimate-cost command."""

    def test_missing_project_name(self):
        runner = CliRunner()
        result = runner.invoke(performance_cli, ["estimate-cost"])
        assert result.exit_code != 0

    def test_autonomous_workflow(self):
        runner = CliRunner()
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value._estimate_cost.return_value = 5.50
            result = runner.invoke(
                performance_cli, ["estimate-cost", "myproj", "--workflow", "autonomous"]
            )
            assert "autonomous" in result.output
            assert "5.50" in result.output

    def test_writing_phase_workflow(self):
        runner = CliRunner()
        with patch("cli_performance.get_llm_optimizer") as mo:
            mo.return_value._estimate_cost.return_value = 12.75
            result = runner.invoke(
                performance_cli, ["estimate-cost", "myproj", "--workflow", "writing_phase"]
            )
            assert "writing_phase" in result.output

    def test_unknown_workflow(self):
        runner = CliRunner()
        with patch("cli_performance.get_llm_optimizer"):
            result = runner.invoke(
                performance_cli, ["estimate-cost", "myproj", "--workflow", "unknown"]
            )
            assert result.exit_code != 0
