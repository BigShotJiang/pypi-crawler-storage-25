"""Unit tests for interactive_qa_handler.py — Q&A at checkpoints."""

from core.checkpoint_proposal import (
    Alternative,
    CheckpointProposal,
    ConfidenceBreakdown,
    PlanContent,
)
from core.interactive_qa_handler import InteractiveQAHandler, QAContainer, create_qa_handler


def _plan(**overrides) -> PlanContent:
    defaults = {
        "title": "The Dragon's Quest",
        "pov": "Aria",
        "pacing": "moderate",
        "word_estimate": 5000,
    }
    defaults.update(overrides)
    return PlanContent(**defaults)


def _proposal(**overrides) -> CheckpointProposal:
    plan = _plan()
    alt = Alternative(
        option_id="B",
        plan=_plan(title="The Dragon's Mercy"),
        confidence=0.72,
        tradeoff_explanation="Slower pacing but deeper character development",
        rejection_reasons=["Pacing too slow for action genre"],
    )
    defaults = {
        "checkpoint_id": "cp_outline",
        "phase": "outline",
        "plan": plan,
        "confidence": 0.85,
        "reasoning": "Strong POV and pacing",
        "reasoning_trace": ["Identified phase: outline", "Generated plan: The Dragon's Quest"],
        "alternatives": [alt],
        "confidence_breakdown": ConfidenceBreakdown(
            coherence=0.9, character=0.85, pacing=0.9, originality=0.8, completeness=0.75
        ),
    }
    defaults.update(overrides)
    return CheckpointProposal(**defaults)


class TestQAContainer:
    def test_create_container_with_question(self):
        qa = QAContainer(question="Why this plan?")
        assert qa.question == "Why this plan?"
        assert qa.answer is None

    def test_create_container_with_answer(self):
        qa = QAContainer(question="Why?", answer="Because...")
        assert qa.answer == "Because..."


class TestSessionManagement:
    def test_start_session(self):
        handler = InteractiveQAHandler()
        session = handler.start_session("cp_01")
        assert session == []

    def test_get_session_returns_empty_for_unknown(self):
        handler = InteractiveQAHandler()
        assert handler.get_session("unknown") == []

    def test_clear_session(self):
        handler = InteractiveQAHandler()
        handler.start_session("cp_01")
        handler.clear_session("cp_01")
        assert handler.get_session("cp_01") == []


class TestAnswerQuestion:
    def test_why_this_plan(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("Why this plan?", proposal)
        assert "confidence" in answer.lower() or "reasoning" in answer.lower()

    def test_why_not_alternative(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("Why not option B?", proposal)
        assert "B" in answer or "alternative" in answer.lower()

    def test_what_if_question(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("What if we change the POV?", proposal)
        assert len(answer) > 0

    def test_compare_alternatives(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("Compare the alternatives", proposal)
        assert "B" in answer

    def test_confidence_question(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("How confident are you?", proposal)
        assert "confidence" in answer.lower() or "85%" in answer

    def test_modify_question(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("How can I modify this?", proposal)
        assert "modify" in answer.lower() or "change" in answer.lower()

    def test_chapter_question(self):
        handler = InteractiveQAHandler()
        _plan(scenes=[{"description": "Opening battle"}])  # noqa: F841 — exercise helper for coverage
        proposal = _proposal()
        proposal.plan.scenes = [{"description": "Opening battle"}]
        answer = handler.answer_question("Tell me about the chapters", proposal)
        assert "scene" in answer.lower()

    def test_character_question(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("What about the characters?", proposal)
        assert len(answer) > 0

    def test_pacing_question(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("What about pacing?", proposal)
        assert "pacing" in answer.lower() or "moderate" in answer.lower()

    def test_generic_question_returns_reasoning(self):
        handler = InteractiveQAHandler()
        proposal = _proposal()
        answer = handler.answer_question("Tell me about weather patterns", proposal)
        assert proposal.reasoning in answer

    def test_no_alternatives_returns_message(self):
        handler = InteractiveQAHandler()
        proposal = _proposal(alternatives=[])
        answer = handler.answer_question("Compare alternatives", proposal)
        assert "no alternatives" in answer.lower()


class TestFactory:
    def test_create_qa_handler(self):
        handler = create_qa_handler()
        assert isinstance(handler, InteractiveQAHandler)
