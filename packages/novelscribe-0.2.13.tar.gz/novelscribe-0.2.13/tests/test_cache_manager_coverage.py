"""Comprehensive tests for core/cache_manager.py to bring coverage above 85%."""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from threading import Thread

from core.cache_manager import CacheEntry, CacheManager, CacheManagerConfig


class TestCacheEntry:
    def test_touch_updates_access(self):
        entry = CacheEntry(key="k", value="v", size_bytes=10)
        old_access = entry.access_count
        old_time = entry.last_accessed
        time.sleep(0.01)
        entry.touch()
        assert entry.access_count == old_access + 1
        assert entry.last_accessed > old_time

    def test_is_expired_no_expiration(self):
        entry = CacheEntry(key="k", value="v", size_bytes=10)
        assert entry.is_expired() is False

    def test_is_expired_future(self):
        entry = CacheEntry(
            key="k",
            value="v",
            size_bytes=10,
            expiration_time=datetime.now(timezone.utc) + timedelta(hours=1),
        )
        assert entry.is_expired() is False

    def test_is_expired_past(self):
        entry = CacheEntry(
            key="k",
            value="v",
            size_bytes=10,
            expiration_time=datetime.now(timezone.utc) - timedelta(seconds=1),
        )
        assert entry.is_expired() is True

    def test_age_seconds(self):
        entry = CacheEntry(key="k", value="v", size_bytes=10)
        time.sleep(0.05)
        assert entry.age_seconds() >= 0.04

    def test_default_metadata(self):
        entry = CacheEntry(key="k", value="v", size_bytes=10)
        assert entry.metadata == {}
        assert entry.is_hot is False


class TestCacheManagerBasicOperations:
    def test_put_and_get(self):
        cm = CacheManager()
        cm.put("k1", "value1")
        assert cm.get("k1") == "value1"

    def test_get_missing_key(self):
        cm = CacheManager()
        assert cm.get("missing") is None

    def test_put_overwrites(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.put("k1", "v2")
        assert cm.get("k1") == "v2"

    def test_invalidate(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.invalidate("k1")
        assert cm.get("k1") is None

    def test_invalidate_missing_key_no_error(self):
        cm = CacheManager()
        cm.invalidate("nonexistent")

    def test_clear(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.get("k1")
        cm.get("missing")
        cm.clear()
        assert "k1" not in cm.cache
        assert "k2" not in cm.cache
        assert cm.current_size_bytes == 0
        assert cm.hits == 0
        assert cm.misses == 0
        assert cm.evictions == 0
        assert cm.expirations == 0

    def test_put_with_metadata(self):
        cm = CacheManager()
        cm.put("k1", "v1", metadata={"tag": "test"})
        assert cm.get_entry_info("k1")["key"] == "k1"

    def test_put_and_get_various_types(self):
        cm = CacheManager()
        cm.put("str", "hello")
        cm.put("dict", {"a": 1})
        cm.put("list", [1, 2, 3])
        cm.put("int", 42)
        assert cm.get("str") == "hello"
        assert cm.get("dict") == {"a": 1}
        assert cm.get("list") == [1, 2, 3]
        assert cm.get("int") == 42

    def test_put_overwrite_adjusts_size(self):
        cm = CacheManager()
        cm.put("k1", "short")
        size_after_short = cm.current_size_bytes
        cm.put("k1", "a much longer value that takes more bytes")
        size_after_long = cm.current_size_bytes
        assert size_after_long > size_after_short

    def test_put_with_custom_metadata(self):
        cm = CacheManager()
        cm.put("k1", "v1", metadata={"source": "test", "priority": 1})
        info = cm.get_entry_info("k1")
        assert info is not None

    def test_get_increments_hits(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.get("k1")
        cm.get("k1")
        assert cm.hits == 2

    def test_get_increments_misses(self):
        cm = CacheManager()
        cm.get("missing1")
        cm.get("missing2")
        assert cm.misses == 2

    def test_get_moves_to_end_lru(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.get("k1")
        keys = list(cm.cache.keys())
        assert keys[-1] == "k1"


class TestCacheManagerTTL:
    def test_ttl_expiration(self):
        cm = CacheManager()
        cm.put("k1", "v1", ttl_seconds=1)
        entry = cm.cache["k1"]
        entry.expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        assert cm.get("k1") is None

    def test_default_ttl(self):
        config = CacheManagerConfig(default_ttl_seconds=1)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        entry = cm.cache["k1"]
        entry.expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        assert cm.get("k1") is None

    def test_set_ttl(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.set_ttl("k1", ttl_seconds=3600)
        entry = cm.cache["k1"]
        assert entry.expiration_time is not None
        assert entry.expiration_time > datetime.now(timezone.utc)

    def test_set_ttl_missing_key(self):
        cm = CacheManager()
        cm.set_ttl("nonexistent", ttl_seconds=10)

    def test_clear_expired(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.cache["k1"].expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        cleared = cm.clear_expired()
        assert cleared == 1
        assert cm.get("k1") is None
        assert cm.get("k2") == "v2"

    def test_clear_expired_increments_counter(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.cache["k1"].expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        cm.cache["k2"].expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        cleared = cm.clear_expired()
        assert cleared == 2
        assert cm.expirations == 2

    def test_clear_expired_none_expired(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cleared = cm.clear_expired()
        assert cleared == 0

    def test_expiration_increments_counter(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.cache["k1"].expiration_time = datetime.now(timezone.utc) - timedelta(seconds=1)
        cm.get("k1")
        assert cm.expirations == 1


class TestCacheManagerLRUEviction:
    def test_eviction_on_max_entries(self):
        config = CacheManagerConfig(max_entries=3, max_size_mb=100)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.put("k3", "v3")
        cm.put("k4", "v4")
        assert cm.get("k1") is None
        assert cm.get("k4") == "v4"
        assert cm.evictions == 1

    def test_eviction_on_max_size(self):
        config = CacheManagerConfig(max_entries=100, max_size_mb=0.00001)
        cm = CacheManager(config)
        cm.put("k1", "a" * 100)
        cm.put("k2", "b" * 100)
        assert cm.evictions >= 1

    def test_eviction_order_lru(self):
        config = CacheManagerConfig(max_entries=2, max_size_mb=100)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        cm.put("k2", "v2")
        cm.get("k1")
        cm.put("k3", "v3")
        assert cm.get("k1") == "v1"
        assert cm.get("k2") is None

    def test_eviction_empty_cache_no_error(self):
        config = CacheManagerConfig(max_entries=1, max_size_mb=0.000001)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        assert cm.evictions >= 0


class TestCacheManagerHotCold:
    def test_identify_hot_keys(self):
        config = CacheManagerConfig(hot_threshold=3, enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        cm.get("k1")
        cm.get("k1")
        cm.get("k1")
        cm.get("k1")
        hot = cm.identify_hot_keys()
        assert "k1" in hot

    def test_identify_hot_keys_disabled(self):
        config = CacheManagerConfig(enable_hot_cold_tracking=False)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        assert cm.identify_hot_keys() == []

    def test_identify_cold_keys(self):
        config = CacheManagerConfig(cold_threshold=2, enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        old_time = datetime.now(timezone.utc) - timedelta(hours=2)
        entry = CacheEntry(key="k1", value="v1", size_bytes=10, access_count=1)
        entry.last_accessed = old_time
        cm.cache["k1"] = entry
        cold = cm.identify_cold_keys()
        assert "k1" in cold

    def test_identify_cold_keys_disabled(self):
        config = CacheManagerConfig(enable_hot_cold_tracking=False)
        cm = CacheManager(config)
        assert cm.identify_cold_keys() == []

    def test_identify_cold_keys_recent_access_not_cold(self):
        config = CacheManagerConfig(cold_threshold=2, enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        entry = CacheEntry(key="k1", value="v1", size_bytes=10, access_count=1)
        entry.last_accessed = datetime.now(timezone.utc)
        cm.cache["k1"] = entry
        cold = cm.identify_cold_keys()
        assert "k1" not in cold


class TestCacheManagerOptimize:
    def test_optimize_removes_cold(self):
        config = CacheManagerConfig(
            max_entries=10, hot_threshold=5, cold_threshold=2, enable_hot_cold_tracking=True
        )
        cm = CacheManager(config)
        old_time = datetime.now(timezone.utc) - timedelta(hours=2)
        for i in range(8):
            entry = CacheEntry(key=f"hot{i}", value=f"v{i}", size_bytes=10, access_count=10)
            cm.cache[f"hot{i}"] = entry
            cm.current_size_bytes += 10
        cold_entry = CacheEntry(key="cold", value="v", size_bytes=10, access_count=1)
        cold_entry.last_accessed = old_time
        cm.cache["cold"] = cold_entry
        cm.current_size_bytes += 10
        cm.optimize()
        assert "cold" not in cm.cache

    def test_optimize_trims_size(self):
        config = CacheManagerConfig(max_size_mb=0.0001)
        cm = CacheManager(config)
        cm.put("k1", "a" * 500)
        cm.put("k2", "b" * 500)
        cm.optimize()
        max_bytes = config.max_size_mb * 1024 * 1024 * 0.8
        assert cm.current_size_bytes <= max_bytes + 100

    def test_optimize_disabled_hot_cold(self):
        config = CacheManagerConfig(enable_hot_cold_tracking=False, max_size_mb=100)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        cm.optimize()
        assert cm.get("k1") == "v1"


class TestCacheManagerWarmCache:
    def test_warm_cache_success(self):
        cm = CacheManager()

        def loader(key):
            return f"loaded_{key}"

        cm.warm_cache(["k1", "k2"], loader)
        assert cm.get("k1") == "loaded_k1"
        assert cm.get("k2") == "loaded_k2"

    def test_warm_cache_skips_existing(self):
        cm = CacheManager()
        cm.put("k1", "existing")

        def loader(key):
            return "new_value"

        cm.warm_cache(["k1"], loader)
        assert cm.get("k1") == "existing"

    def test_warm_cache_loader_returns_none(self):
        cm = CacheManager()

        def loader(key):
            return None

        cm.warm_cache(["k1"], loader)
        assert cm.get("k1") is None

    def test_warm_cache_loader_exception(self):
        cm = CacheManager()

        def bad_loader(key):
            raise ValueError("fail")

        cm.warm_cache(["k1"], bad_loader)
        assert cm.get("k1") is None

    def test_warm_cache_with_ttl(self):
        cm = CacheManager()

        def loader(key):
            return f"val_{key}"

        cm.warm_cache(["k1"], loader, ttl_seconds=3600)
        assert cm.get("k1") == "val_k1"


class TestCacheManagerStatistics:
    def test_get_statistics_empty(self):
        cm = CacheManager()
        stats = cm.get_statistics()
        assert stats["entries"] == 0
        assert stats["hits"] == 0
        assert stats["misses"] == 0
        assert stats["hit_rate"] == "0.00%"

    def test_get_statistics_with_data(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.get("k1")
        cm.get("missing")
        stats = cm.get_statistics()
        assert stats["entries"] == 1
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == "50.00%"

    def test_get_statistics_size_fields(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        stats = cm.get_statistics()
        assert stats["current_size_mb"] > 0
        assert stats["max_size_mb"] == 100.0
        assert stats["utilization_percent"] > 0

    def test_get_access_pattern_insufficient_data(self):
        cm = CacheManager()
        assert cm.get_access_pattern() == {"pattern": "insufficient_data"}

    def test_get_access_pattern_with_data(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.get("k1")
        cm.get("k1")
        pattern = cm.get_access_pattern()
        assert pattern["total_accesses"] == 2
        assert pattern["unique_keys"] == 1

    def test_get_access_pattern_diverse(self):
        config = CacheManagerConfig(enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        for i in range(20):
            cm.put(f"k{i}", f"v{i}")
        for i in range(20):
            cm.get(f"k{i}")
        pattern = cm.get_access_pattern()
        assert pattern["unique_keys"] == 20

    def test_access_history_trimming(self):
        config = CacheManagerConfig(enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        cm.max_history_size = 10
        for i in range(20):
            cm.put(f"k{i}", f"v{i}")
            cm.get(f"k{i}")
        assert len(cm.access_history) <= 10


class TestCacheManagerEntryInfo:
    def test_get_entry_info_existing(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        info = cm.get_entry_info("k1")
        assert info is not None
        assert info["key"] == "k1"
        assert info["size_bytes"] > 0
        assert info["access_count"] == 0
        assert info["is_expired"] is False
        assert "created_at" in info
        assert "last_accessed" in info
        assert "age_seconds" in info

    def test_get_entry_info_missing(self):
        cm = CacheManager()
        assert cm.get_entry_info("missing") is None

    def test_get_entry_info_is_hot_cold(self):
        config = CacheManagerConfig(hot_threshold=2, cold_threshold=1)
        cm = CacheManager(config)
        cm.put("k1", "v1")
        cm.get("k1")
        cm.get("k1")
        info = cm.get_entry_info("k1")
        assert info["is_hot"] is True
        assert info["is_cold"] is False

    def test_get_entry_info_with_expiration(self):
        cm = CacheManager()
        cm.put("k1", "v1", ttl_seconds=3600)
        info = cm.get_entry_info("k1")
        assert info["expiration_time"] is not None
        assert info["is_expired"] is False

    def test_get_entry_info_no_expiration(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        info = cm.get_entry_info("k1")
        assert info["expiration_time"] is None


class TestCacheManagerBulkInvalidate:
    def test_bulk_invalidate_pattern(self):
        cm = CacheManager()
        cm.put("user:1", "a")
        cm.put("user:2", "b")
        cm.put("post:1", "c")
        cm.bulk_invalidate(r"user:\d+")
        assert cm.get("user:1") is None
        assert cm.get("user:2") is None
        assert cm.get("post:1") == "c"

    def test_bulk_invalidate_no_match(self):
        cm = CacheManager()
        cm.put("k1", "v1")
        cm.bulk_invalidate(r"nomatch\d+")
        assert cm.get("k1") == "v1"


class TestCacheManagerSizeByKeyType:
    def test_size_by_key_type(self):
        cm = CacheManager()
        cm.put("user:1", "a")
        cm.put("user:2", "bb")
        cm.put("post:1", "c")
        sizes = cm.get_size_by_key_type()
        assert "user" in sizes
        assert "post" in sizes
        assert sizes["user"] > sizes["post"]

    def test_size_by_key_type_no_colon(self):
        cm = CacheManager()
        cm.put("simple", "val")
        sizes = cm.get_size_by_key_type()
        assert "other" in sizes

    def test_size_by_key_type_empty_cache(self):
        cm = CacheManager()
        sizes = cm.get_size_by_key_type()
        assert sizes == {}


class TestCacheManagerThreadSafety:
    def test_concurrent_access(self):
        cm = CacheManager()
        errors = []

        def writer():
            try:
                for i in range(50):
                    cm.put(f"k{i}", f"v{i}")
            except Exception as e:
                errors.append(e)

        def reader():
            try:
                for i in range(50):
                    cm.get(f"k{i}")
            except Exception as e:
                errors.append(e)

        threads = [Thread(target=writer), Thread(target=reader)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert not errors


class TestCacheManagerConfig:
    def test_defaults(self):
        config = CacheManagerConfig()
        assert config.max_size_mb == 100.0
        assert config.max_entries == 100
        assert config.default_ttl_seconds is None
        assert config.enable_hot_cold_tracking is True
        assert config.hot_threshold == 10
        assert config.cold_threshold == 2
        assert config.cleanup_interval_seconds == 300
        assert config.enable_compression is False
        assert config.enable_prefetch is True

    def test_custom_config(self):
        config = CacheManagerConfig(
            max_size_mb=50.0,
            max_entries=50,
            default_ttl_seconds=300,
            enable_hot_cold_tracking=False,
        )
        assert config.max_size_mb == 50.0
        assert config.max_entries == 50
        assert config.default_ttl_seconds == 300
        assert config.enable_hot_cold_tracking is False


class TestCacheManagerCalculateSize:
    def test_size_string(self):
        cm = CacheManager()
        assert cm._calculate_size("hello") == 5

    def test_size_dict(self):
        cm = CacheManager()
        size = cm._calculate_size({"key": "value"})
        assert size > 0

    def test_size_list(self):
        cm = CacheManager()
        size = cm._calculate_size(["a", "bb", "ccc"])
        assert size > 0

    def test_size_int(self):
        cm = CacheManager()
        size = cm._calculate_size(42)
        assert size > 0

    def test_size_none(self):
        cm = CacheManager()
        size = cm._calculate_size(None)
        assert size > 0


class TestCacheManagerRemoveColdEntries:
    def test_remove_cold_keeps_above_half(self):
        config = CacheManagerConfig(max_entries=4, cold_threshold=0, enable_hot_cold_tracking=True)
        cm = CacheManager(config)
        old_time = datetime.now(timezone.utc) - timedelta(hours=2)
        for i in range(4):
            entry = CacheEntry(key=f"cold{i}", value="v", size_bytes=10, access_count=0)
            entry.last_accessed = old_time
            cm.cache[f"cold{i}"] = entry
            cm.current_size_bytes += 10
        cm._remove_cold_entries()
        assert len(cm.cache) <= 2
