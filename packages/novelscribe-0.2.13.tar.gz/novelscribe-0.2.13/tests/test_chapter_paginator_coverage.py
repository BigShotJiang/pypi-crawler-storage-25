from core.chapter_paginator import (
    ChapterPage,
    ChapterPaginator,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)
from core.token_estimator import TokenEstimator


def _make_long_content(paragraphs=80, words_per_para=50):
    parts = []
    for i in range(paragraphs):
        words = " ".join(f"word{j}" for j in range(words_per_para))
        parts.append(f"Paragraph {i}: {words}. This is more content to make it longer.")
    return "\n\n".join(parts)


def _make_scene_break_content():
    return (
        "First scene content with enough words to be meaningful. "
        + " ".join(f"word{i}" for i in range(2000))
        + ".\n\n"
        + "---\n\n"
        + "Second scene content with enough words. "
        + " ".join(f"more{i}" for i in range(2000))
        + "."
    )


class TestPageSplitStrategy:
    def test_all_strategies(self):
        assert PageSplitStrategy.TOKEN_BASED == "token_based"
        assert PageSplitStrategy.SCENE_BASED == "scene_based"
        assert PageSplitStrategy.PARAGRAPH_BASED == "paragraph_based"
        assert PageSplitStrategy.SEMANTIC == "semantic"


class TestPageMetadata:
    def test_to_dict(self):
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=100, word_count=50, token_count=65
        )
        d = meta.to_dict()
        assert d["page_number"] == 1
        assert d["word_count"] == 50
        assert d["token_count"] == 65
        assert d["scene_identifier"] is None
        assert d["characters_present"] == []
        assert d["locations_present"] == []
        assert d["key_events"] == []
        assert "created_at" in d

    def test_to_dict_with_all_fields(self):
        meta = PageMetadata(
            page_number=2,
            start_position=10,
            end_position=200,
            word_count=80,
            token_count=100,
            scene_identifier="scene_2",
            characters_present=["Alice"],
            locations_present=["Castle"],
            key_events=["event1"],
        )
        d = meta.to_dict()
        assert d["scene_identifier"] == "scene_2"
        assert d["characters_present"] == ["Alice"]
        assert d["locations_present"] == ["Castle"]
        assert d["key_events"] == ["event1"]


class TestChapterPage:
    def test_word_count(self):
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        page = ChapterPage(page_number=1, content="hello world foo bar baz", metadata=meta)
        assert page.word_count == 5

    def test_full_content_with_overlap(self):
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        page = ChapterPage(page_number=1, content="main", metadata=meta, overlap_content="prev")
        assert page.full_content == "prev\n\nmain"

    def test_full_content_no_overlap(self):
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        page = ChapterPage(page_number=1, content="main", metadata=meta)
        assert page.full_content == "main"

    def test_get_context_hint_all_fields(self):
        meta = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=10,
            word_count=5,
            token_count=6,
            scene_identifier="scene_1",
            characters_present=["Alice", "Bob"],
            locations_present=["Castle"],
        )
        page = ChapterPage(page_number=1, content="text", metadata=meta)
        hint = page.get_context_hint()
        assert "Scene: scene_1" in hint
        assert "Alice" in hint
        assert "Bob" in hint
        assert "Castle" in hint

    def test_get_context_hint_only_scene(self):
        meta = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=10,
            word_count=5,
            token_count=6,
            scene_identifier="scene_1",
        )
        page = ChapterPage(page_number=1, content="text", metadata=meta)
        assert "Scene: scene_1" in page.get_context_hint()

    def test_get_context_hint_only_characters(self):
        meta = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=10,
            word_count=5,
            token_count=6,
            characters_present=["Alice"],
        )
        page = ChapterPage(page_number=1, content="text", metadata=meta)
        assert "Alice" in page.get_context_hint()

    def test_get_context_hint_only_locations(self):
        meta = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=10,
            word_count=5,
            token_count=6,
            locations_present=["Forest"],
        )
        page = ChapterPage(page_number=1, content="text", metadata=meta)
        assert "Forest" in page.get_context_hint()

    def test_get_context_hint_empty(self):
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        page = ChapterPage(page_number=1, content="text", metadata=meta)
        assert page.get_context_hint() == "Continuing story..."


class TestPaginationConfig:
    def test_defaults(self):
        cfg = PaginationConfig()
        assert cfg.strategy == PageSplitStrategy.SEMANTIC
        assert cfg.max_tokens_per_page == 2500
        assert cfg.target_tokens_per_page == 2000
        assert cfg.overlap_tokens == 200
        assert cfg.min_page_tokens == 500
        assert cfg.preserve_scene_boundaries is True
        assert cfg.preserve_dialogue_groups is True


class TestChapterPaginatorEmptyAndShort:
    def test_empty_content(self):
        p = ChapterPaginator()
        assert p.paginate_chapter("", 1) == []

    def test_whitespace_content(self):
        p = ChapterPaginator()
        assert p.paginate_chapter("   \n  \t  ", 1) == []

    def test_short_content_single_page(self):
        p = ChapterPaginator()
        pages = p.paginate_chapter("Short content here.", 1)
        assert len(pages) == 1
        assert pages[0].page_number == 1

    def test_short_content_with_metadata(self):
        p = ChapterPaginator()
        meta = {"characters": ["Alice"], "locations": ["Castle"]}
        pages = p.paginate_chapter("Alice went to the Castle.", 1, metadata=meta)
        assert len(pages) == 1
        assert "Alice" in pages[0].metadata.characters_present
        assert "Castle" in pages[0].metadata.locations_present


class TestChapterPaginatorTokenBased:
    def test_token_based_split(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=80, words_per_para=50)
        pages = p.paginate_chapter(content, 1)
        assert len(pages) > 1

    def test_token_based_with_metadata(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=80, words_per_para=50)
        pages = p.paginate_chapter(content, 1, metadata={"characters": ["Alice"]})
        assert len(pages) > 1

    def test_token_based_overlap_content(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.TOKEN_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
            overlap_tokens=10,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=80, words_per_para=50)
        pages = p.paginate_chapter(content, 1)
        assert len(pages) > 1
        if len(pages) > 1:
            assert pages[1].overlap_content != ""


class TestChapterPaginatorSceneBased:
    def test_scene_based_with_breaks(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=3000,
        )
        p = ChapterPaginator(cfg)
        content = _make_scene_break_content()
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 2

    def test_scene_based_no_breaks_returns_pages(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=10, words_per_para=30)
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 1

    def test_scene_oversized_splits_further(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=1000,
            target_tokens_per_page=500,
        )
        p = ChapterPaginator(cfg)
        long_scene = " ".join(f"word{i}" for i in range(2000))
        content = long_scene + "\n\n---\n\n" + " ".join(f"more{i}" for i in range(50))
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 2

    def test_scene_based_with_metadata(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=3000,
        )
        p = ChapterPaginator(cfg)
        content = _make_scene_break_content()
        pages = p.paginate_chapter(content, 1, metadata={"characters": ["Alice"]})
        assert len(pages) >= 2

    def test_scene_empty_segment_skipped(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SCENE_BASED,
            max_tokens_per_page=5000,
        )
        p = ChapterPaginator(cfg)
        content = "---\n\n---\n\n" + " ".join(f"word{i}" for i in range(200))
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 1


class TestChapterPaginatorParagraphBased:
    def test_paragraph_based_split(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=80, words_per_para=50)
        pages = p.paginate_chapter(content, 1)
        assert len(pages) > 1

    def test_paragraph_based_with_metadata(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=80, words_per_para=50)
        pages = p.paginate_chapter(content, 1, metadata={"characters": ["Alice"]})
        assert len(pages) > 1

    def test_paragraph_based_oversized_single_paragraph(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.PARAGRAPH_BASED,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
        )
        p = ChapterPaginator(cfg)
        huge_para = " ".join(f"word{i}" for i in range(10000))
        pages = p.paginate_chapter(huge_para, 1)
        assert len(pages) > 1


class TestChapterPaginatorSemantic:
    def test_semantic_with_scene_breaks(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SEMANTIC,
            max_tokens_per_page=3000,
            min_page_tokens=10,
        )
        p = ChapterPaginator(cfg)
        content = _make_scene_break_content()
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 2

    def test_semantic_fallback_to_paragraph(self):
        cfg = PaginationConfig(
            strategy=PageSplitStrategy.SEMANTIC,
            max_tokens_per_page=3000,
            target_tokens_per_page=2000,
            min_page_tokens=10,
        )
        p = ChapterPaginator(cfg)
        content = _make_long_content(paragraphs=10, words_per_para=30)
        pages = p.paginate_chapter(content, 1)
        assert len(pages) >= 1


class TestChapterPaginatorDialogueEnrichment:
    def test_dialogue_extraction(self):
        p = ChapterPaginator()
        content = 'Alice said "Hello there, how are you today?" and walked away.'
        meta = {"characters": ["Alice"]}
        pages = p.paginate_chapter(content, 1, metadata=meta)
        assert len(pages) == 1
        assert len(pages[0].metadata.key_events) > 0
        assert "Dialogue" in pages[0].metadata.key_events[0]

    def test_no_dialogue_no_key_events(self):
        p = ChapterPaginator()
        content = "Alice walked away quietly."
        meta = {"characters": ["Alice"]}
        pages = p.paginate_chapter(content, 1, metadata=meta)
        assert len(pages) == 1
        assert pages[0].metadata.key_events == []


class TestChapterPaginatorRegeneratePage:
    def test_regenerate_page(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=2,
            start_position=100,
            end_position=200,
            word_count=50,
            token_count=65,
            scene_identifier="scene_2",
            characters_present=["Alice"],
            locations_present=["Castle"],
            key_events=["event1"],
        )
        original = ChapterPage(
            page_number=2, content="old content", metadata=meta, overlap_content="previous"
        )
        new_page = p.regenerate_page(original, "new content here")
        assert new_page.content == "new content here"
        assert new_page.page_number == 2
        assert new_page.metadata.scene_identifier == "scene_2"
        assert new_page.metadata.characters_present == ["Alice"]
        assert new_page.metadata.locations_present == ["Castle"]
        assert new_page.metadata.key_events == ["event1"]
        assert new_page.overlap_content == "previous"
        assert new_page.metadata.end_position == 100 + len("new content here")


class TestChapterPaginatorSummary:
    def test_empty_pages(self):
        p = ChapterPaginator()
        summary = p.get_pagination_summary([])
        assert summary["total_pages"] == 0
        assert summary["total_words"] == 0
        assert summary["total_tokens"] == 0
        assert summary["avg_words_per_page"] == 0
        assert summary["avg_tokens_per_page"] == 0

    def test_pages_summary(self):
        p = ChapterPaginator()
        pages = [
            ChapterPage(
                page_number=1,
                content="hello world",
                metadata=PageMetadata(
                    page_number=1,
                    start_position=0,
                    end_position=11,
                    word_count=2,
                    token_count=3,
                    scene_identifier="scene_1",
                    characters_present=["Alice"],
                    locations_present=["Castle"],
                ),
            ),
            ChapterPage(
                page_number=2,
                content="foo bar baz",
                metadata=PageMetadata(
                    page_number=2,
                    start_position=12,
                    end_position=23,
                    word_count=3,
                    token_count=4,
                    characters_present=["Alice"],
                ),
            ),
        ]
        summary = p.get_pagination_summary(pages)
        assert summary["total_pages"] == 2
        assert summary["total_words"] == 5
        assert summary["pages_with_scenes"] == 1
        assert summary["total_characters"] == 1
        assert summary["total_locations"] == 1


class TestChapterPaginatorSafeSplitPoint:
    def test_find_split_point_sentence_boundary(self):
        p = ChapterPaginator()
        content = "First sentence. Second sentence. Third sentence. Fourth sentence."
        pos = p._find_safe_split_point(content, 30)
        assert 0 < pos <= len(content)

    def test_find_split_point_no_sentence_boundary(self):
        p = ChapterPaginator()
        content = "word " * 200
        pos = p._find_safe_split_point(content, 100)
        assert pos == 100

    def test_find_split_point_short_content(self):
        p = ChapterPaginator()
        content = "Short. End."
        pos = p._find_safe_split_point(content, 5)
        assert pos > 0


class TestChapterPaginatorEnrichMetadata:
    def test_enrich_no_characters_key(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"locations": ["Castle"]}, "text")
        assert meta.characters_present == []

    def test_enrich_no_matching_characters(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"characters": ["Zelda"]}, "Alice went home.")
        assert meta.characters_present == []

    def test_enrich_matching_characters(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"characters": ["Alice", "Bob"]}, "Alice and Bob met.")
        assert "Alice" in meta.characters_present
        assert "Bob" in meta.characters_present

    def test_enrich_no_locations_key(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"characters": ["Alice"]}, "Alice was here.")
        assert meta.locations_present == []

    def test_enrich_matching_locations(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"locations": ["Castle", "Forest"]}, "The Castle was grand.")
        assert "Castle" in meta.locations_present
        assert "Forest" not in meta.locations_present

    def test_enrich_no_matching_locations(self):
        p = ChapterPaginator()
        meta = PageMetadata(
            page_number=1, start_position=0, end_position=10, word_count=5, token_count=6
        )
        p._enrich_page_metadata(meta, {"locations": ["Mars"]}, "The Castle was grand.")
        assert meta.locations_present == []


class TestChapterPaginatorCustomEstimator:
    def test_custom_config(self):
        cfg = PaginationConfig(max_tokens_per_page=5000)
        p = ChapterPaginator(cfg)
        assert p.config.max_tokens_per_page == 5000
        assert isinstance(p.token_estimator, TokenEstimator)
