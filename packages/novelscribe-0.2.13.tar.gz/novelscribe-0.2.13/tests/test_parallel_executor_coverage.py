"""Tests for core.parallel_executor to achieve 80%+ coverage."""

from unittest.mock import MagicMock, patch

import pytest

from core.parallel_executor import (
    ExecutionGraph,
    ExecutionNode,
    ExecutionResult,
    ExecutionStatus,
    ParallelExecutor,
    get_parallel_executor,
)


class TestExecutionStatus:
    """Test ExecutionStatus enum values."""

    def test_all_status_values(self):
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.READY.value == "ready"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"
        assert ExecutionStatus.SKIPPED.value == "skipped"


class TestExecutionNode:
    """Test ExecutionNode dataclass."""

    def test_default_values(self):
        node = ExecutionNode(agent_name="test")
        assert node.agent_name == "test"
        assert node.dependencies == []
        assert node.dependents == []
        assert node.status == ExecutionStatus.PENDING
        assert node.result is None
        assert node.error is None
        assert node.retry_count == 0
        assert node.max_retries == 3

    def test_is_ready_with_completed_deps(self):
        node = ExecutionNode(agent_name="test")
        node.dependencies = [ExecutionStatus.COMPLETED]
        assert node.is_ready is True

    def test_is_ready_with_pending_deps(self):
        node = ExecutionNode(agent_name="test")
        node.dependencies = [ExecutionStatus.PENDING]
        assert node.is_ready is False

    def test_is_ready_with_mixed_deps(self):
        node = ExecutionNode(agent_name="test")
        node.dependencies = [ExecutionStatus.COMPLETED, ExecutionStatus.PENDING]
        assert node.is_ready is False

    def test_is_ready_empty_deps(self):
        node = ExecutionNode(agent_name="test")
        node.dependencies = []
        assert node.is_ready is True

    def test_can_run_parallel(self):
        node = ExecutionNode(agent_name="test")
        assert node.can_run_parallel is False
        node.status = ExecutionStatus.READY
        assert node.can_run_parallel is True

    def test_to_dict(self):
        node = ExecutionNode(agent_name="agent1", agent_id="id1")
        node.status = ExecutionStatus.RUNNING
        node.start_time = 1.0
        node.end_time = 2.0
        node.duration = 1.0
        node.error = None
        d = node.to_dict()
        assert d["agent_name"] == "agent1"
        assert d["agent_id"] == "id1"
        assert d["status"] == "running"
        assert d["start_time"] == 1.0
        assert d["end_time"] == 2.0
        assert d["duration"] == 1.0
        assert d["error"] is None
        assert d["retry_count"] == 0

    def test_to_dict_with_result(self):
        node = ExecutionNode(agent_name="test")
        node.result = "x" * 200
        d = node.to_dict()
        assert len(d["result"]) == 100

    def test_to_dict_none_result(self):
        node = ExecutionNode(agent_name="test")
        d = node.to_dict()
        assert d["result"] is None

    def test_unique_agent_id(self):
        n1 = ExecutionNode(agent_name="a")
        n2 = ExecutionNode(agent_name="a")
        assert n1.agent_id != n2.agent_id


class TestExecutionResult:
    """Test ExecutionResult dataclass."""

    def test_to_dict(self):
        result = ExecutionResult(
            success=True,
            completed_nodes=["a"],
            failed_nodes=[],
            skipped_nodes=[],
            total_duration=1.5,
            node_results={"a": "ok"},
            errors={},
            parallel_speedup=2.5,
        )
        d = result.to_dict()
        assert d["success"] is True
        assert d["completed_nodes"] == ["a"]
        assert d["parallel_speedup"] == "2.50x"

    def test_to_dict_fields(self):
        result = ExecutionResult(
            success=False,
            completed_nodes=[],
            failed_nodes=["x"],
            skipped_nodes=["y"],
            total_duration=0.0,
            node_results={},
            errors={"x": "err"},
        )
        d = result.to_dict()
        assert d["success"] is False
        assert d["failed_nodes"] == ["x"]
        assert d["skipped_nodes"] == ["y"]
        assert d["errors"] == {"x": "err"}


class TestExecutionGraph:
    """Test ExecutionGraph operations."""

    def test_add_node(self):
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        assert node.agent_id in graph.nodes
        assert node.agent_id in graph.edges

    def test_add_node_already_has_edges(self):
        graph = ExecutionGraph()
        graph.edges["existing"] = ["x"]
        node = ExecutionNode(agent_name="agent1", agent_id="existing")
        graph.add_node(node)
        assert "existing" in graph.nodes

    def test_add_edge(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        assert "b" in graph.edges["a"]
        assert "a" in graph.nodes["b"].dependencies
        assert "b" in graph.nodes["a"].dependents

    def test_add_edge_missing_nodes(self):
        graph = ExecutionGraph()
        graph.add_edge("x", "y")
        assert "y" in graph.edges["x"]

    def test_add_edge_from_not_in_edges(self):
        graph = ExecutionGraph()
        graph.add_edge("new_from", "new_to")
        assert "new_from" in graph.edges

    def test_add_edge_to_not_in_nodes(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        graph.add_node(node_a)
        graph.add_edge("a", "missing")
        assert "missing" in graph.nodes["a"].dependents

    def test_get_ready_nodes(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_a.status = ExecutionStatus.READY
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        node_b.status = ExecutionStatus.PENDING
        graph.add_node(node_a)
        graph.add_node(node_b)
        ready = graph.get_ready_nodes()
        assert len(ready) == 1
        assert ready[0].agent_id == "a"

    def test_get_ready_nodes_not_ready_due_to_deps(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_a.status = ExecutionStatus.READY
        node_a.dependencies = [ExecutionStatus.PENDING]
        graph.add_node(node_a)
        ready = graph.get_ready_nodes()
        assert len(ready) == 0

    def test_topological_sort(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        node_c = ExecutionNode(agent_name="c", agent_id="c")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_node(node_c)
        graph.add_edge("a", "b")
        graph.add_edge("b", "c")
        order = graph.topological_sort()
        assert order.index("a") < order.index("b")
        assert order.index("b") < order.index("c")

    def test_topological_sort_no_deps(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        order = graph.topological_sort()
        assert len(order) == 2

    def test_topological_sort_cycle_raises(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        with pytest.raises(ValueError, match="cycles"):
            graph.topological_sort()

    def test_topological_sort_diamond(self):
        graph = ExecutionGraph()
        nodes = [ExecutionNode(agent_name=f"n{i}", agent_id=f"n{i}") for i in range(4)]
        for n in nodes:
            graph.add_node(n)
        graph.add_edge("n0", "n1")
        graph.add_edge("n0", "n2")
        graph.add_edge("n1", "n3")
        graph.add_edge("n2", "n3")
        order = graph.topological_sort()
        assert order.index("n0") < order.index("n1")
        assert order.index("n0") < order.index("n2")
        assert order.index("n1") < order.index("n3")
        assert order.index("n2") < order.index("n3")

    def test_detect_cycles_no_cycle(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        cycles = graph.detect_cycles()
        assert cycles == []

    def test_detect_cycles_with_cycle(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        cycles = graph.detect_cycles()
        assert len(cycles) > 0

    def test_detect_cycles_three_node_cycle(self):
        graph = ExecutionGraph()
        for name in ("a", "b", "c"):
            graph.add_node(ExecutionNode(agent_name=name, agent_id=name))
        graph.add_edge("a", "b")
        graph.add_edge("b", "c")
        graph.add_edge("c", "a")
        cycles = graph.detect_cycles()
        assert len(cycles) > 0

    def test_detect_cycles_isolated_nodes(self):
        graph = ExecutionGraph()
        graph.add_node(ExecutionNode(agent_name="a", agent_id="a"))
        graph.add_node(ExecutionNode(agent_name="b", agent_id="b"))
        cycles = graph.detect_cycles()
        assert cycles == []

    def test_validate_no_errors(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        graph.add_node(node_a)
        is_valid, errors = graph.validate()
        assert is_valid is True
        assert errors == []

    def test_validate_with_cycles(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        is_valid, errors = graph.validate()
        assert is_valid is False

    def test_validate_missing_dependency(self):
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="a", agent_id="a")
        node.dependencies = ["nonexistent"]
        graph.add_node(node)
        is_valid, errors = graph.validate()
        assert is_valid is False
        assert any("nonexistent" in e for e in errors)

    def test_validate_multiple_errors(self):
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_a.dependencies = ["missing1", "missing2"]
        graph.add_node(node_a)
        is_valid, errors = graph.validate()
        assert is_valid is False
        assert len(errors) >= 2


class TestParallelExecutor:
    """Test ParallelExecutor class."""

    def test_init_defaults(self):
        executor = ParallelExecutor()
        assert executor.max_workers == 4
        assert executor.timeout == 300
        assert executor.enable_progress is True

    def test_init_custom(self):
        executor = ParallelExecutor(max_workers=8, timeout=60, enable_progress=False)
        assert executor.max_workers == 8
        assert executor.timeout == 60
        assert executor.enable_progress is False

    def test_add_progress_callback(self):
        executor = ParallelExecutor()
        cb = MagicMock()
        executor.add_progress_callback(cb)
        assert cb in executor.progress_callbacks

    def test_notify_progress(self):
        executor = ParallelExecutor()
        cb = MagicMock()
        executor.add_progress_callback(cb)
        executor._notify_progress("node1", ExecutionStatus.RUNNING)
        cb.assert_called_once_with("node1", ExecutionStatus.RUNNING)

    def test_notify_progress_exception_ignored(self):
        executor = ParallelExecutor()
        cb = MagicMock(side_effect=Exception("boom"))
        executor.add_progress_callback(cb)
        executor._notify_progress("node1", ExecutionStatus.RUNNING)

    def test_notify_progress_multiple_callbacks(self):
        executor = ParallelExecutor()
        cb1 = MagicMock()
        cb2 = MagicMock()
        executor.add_progress_callback(cb1)
        executor.add_progress_callback(cb2)
        executor._notify_progress("n", ExecutionStatus.COMPLETED)
        cb1.assert_called_once()
        cb2.assert_called_once()

    def test_build_graph_from_workflow(self):
        executor = ParallelExecutor()
        steps = [
            {"agent": "agent1"},
            {"agent": "agent2", "dependencies": [0]},
        ]
        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 2

    def test_build_graph_from_workflow_no_agent(self):
        executor = ParallelExecutor()
        steps = [{"dependencies": []}]
        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 1
        node = list(graph.nodes.values())[0]
        assert node.agent_name == "step_0"

    def test_build_graph_dependencies_out_of_range(self):
        executor = ParallelExecutor()
        steps = [
            {"agent": "a", "dependencies": [99]},
        ]
        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 1
        assert len(graph.edges[list(graph.edges.keys())[0]]) == 0

    def test_build_graph_string_dependencies_ignored(self):
        executor = ParallelExecutor()
        steps = [
            {"agent": "a", "dependencies": ["not_an_int"]},
        ]
        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 1

    def test_build_graph_multiple_dependencies(self):
        executor = ParallelExecutor()
        steps = [
            {"agent": "a"},
            {"agent": "b"},
            {"agent": "c", "dependencies": [0, 1]},
        ]
        graph = executor.build_graph_from_workflow(steps)
        assert len(graph.nodes) == 3

    def test_execute_parallel_simple(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        funcs = {"agent1": MagicMock(return_value="done")}
        result = executor.execute_parallel(graph, funcs)
        assert result.success is True
        assert len(result.completed_nodes) == 1

    def test_execute_parallel_with_context(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        func = MagicMock(return_value="result")
        result = executor.execute_parallel(graph, {"agent1": func}, context={"key": "val"})
        func.assert_called()
        assert result.success is True

    def test_execute_parallel_no_context(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        func = MagicMock(return_value="result")
        result = executor.execute_parallel(graph, {"agent1": func}, context=None)
        assert result.success is True

    def test_execute_parallel_invalid_graph(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        result = executor.execute_parallel(graph, {})
        assert result.success is False
        assert "validation" in result.errors

    def test_execute_parallel_missing_agent_function(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="missing_agent")
        node.status = ExecutionStatus.READY
        node.dependencies = []
        graph.add_node(node)
        result = executor.execute_parallel(graph, {})
        assert result.success is False
        assert len(result.failed_nodes) == 1

    def test_execute_parallel_agent_exception(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1", max_retries=1)
        graph.add_node(node)
        func = MagicMock(side_effect=RuntimeError("fail"))
        result = executor.execute_parallel(graph, {"agent1": func})
        assert result.success is False
        assert len(result.failed_nodes) == 1

    def test_execute_parallel_skip_dependents(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a", max_retries=1)
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        func_a = MagicMock(side_effect=RuntimeError("fail"))
        func_b = MagicMock(return_value="ok")
        result = executor.execute_parallel(graph, {"a": func_a, "b": func_b})
        assert result.success is False
        assert "a" in result.failed_nodes

    def test_execute_parallel_dependents_ready(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        result = executor.execute_parallel(
            graph, {"a": MagicMock(return_value="ok"), "b": MagicMock(return_value="ok2")}
        )
        assert result.success is True

    def test_execute_parallel_multiple_independent(self):
        executor = ParallelExecutor(max_workers=4)
        graph = ExecutionGraph()
        for i in range(3):
            graph.add_node(ExecutionNode(agent_name=f"agent{i}"))
        funcs = {f"agent{i}": MagicMock(return_value=f"result{i}") for i in range(3)}
        result = executor.execute_parallel(graph, funcs)
        assert result.success is True
        assert len(result.completed_nodes) == 3

    def test_execute_sequential_simple(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        result = executor.execute_sequential(graph, {"agent1": MagicMock(return_value="ok")})
        assert result.success is True
        assert len(result.completed_nodes) == 1

    def test_execute_sequential_cycle(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        graph.add_edge("b", "a")
        result = executor.execute_sequential(graph, {})
        assert result.success is False
        assert "topological_sort" in result.errors

    def test_execute_sequential_skip_failed_deps(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b", dependencies=["a"])
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        fail_func = MagicMock(side_effect=RuntimeError("boom"))
        result = executor.execute_sequential(
            graph, {"a": fail_func, "b": MagicMock(return_value="ok")}
        )
        assert result.success is False
        assert len(result.skipped_nodes) == 1

    def test_execute_sequential_agent_exception(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1", max_retries=1)
        graph.add_node(node)
        func = MagicMock(side_effect=RuntimeError("fail"))
        result = executor.execute_sequential(graph, {"agent1": func})
        assert result.success is False
        assert len(result.failed_nodes) == 1

    def test_execute_sequential_with_context(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        func = MagicMock(return_value="result")
        result = executor.execute_sequential(graph, {"agent1": func}, context={"key": "val"})
        func.assert_called_with(key="val")
        assert result.success is True

    def test_execute_sequential_no_context(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="agent1")
        graph.add_node(node)
        func = MagicMock(return_value="result")
        result = executor.execute_sequential(graph, {"agent1": func}, context=None)
        func.assert_called_with()
        assert result.success is True

    def test_execute_agent_with_retry(self):
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="test", max_retries=3)
        func = MagicMock(side_effect=[RuntimeError("err1"), RuntimeError("err2"), "success"])
        with patch("core.parallel_executor.time.sleep"):
            result = executor._execute_agent(node, func, None)
        assert result == "success"
        assert node.retry_count == 2

    def test_execute_agent_all_retries_fail(self):
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="test", max_retries=2)
        func = MagicMock(side_effect=RuntimeError("always fail"))
        with patch("core.parallel_executor.time.sleep"):
            with pytest.raises(RuntimeError, match="always fail"):
                executor._execute_agent(node, func, None)

    def test_execute_agent_with_context(self):
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="test")
        func = MagicMock(return_value="result")
        result = executor._execute_agent(node, func, {"key": "value"})
        func.assert_called_with(key="value")
        assert result == "result"

    def test_execute_agent_no_context(self):
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="test")
        func = MagicMock(return_value="result")
        result = executor._execute_agent(node, func, None)
        func.assert_called_with()
        assert result == "result"

    def test_execute_agent_single_retry_success(self):
        executor = ParallelExecutor()
        node = ExecutionNode(agent_name="test", max_retries=2)
        func = MagicMock(side_effect=[RuntimeError("err"), "ok"])
        with patch("core.parallel_executor.time.sleep"):
            result = executor._execute_agent(node, func, None)
        assert result == "ok"
        assert node.retry_count == 1

    def test_get_execution_order(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node_a = ExecutionNode(agent_name="a", agent_id="a")
        node_b = ExecutionNode(agent_name="b", agent_id="b")
        graph.add_node(node_a)
        graph.add_node(node_b)
        graph.add_edge("a", "b")
        order = executor.get_execution_order(graph)
        assert order.index("a") < order.index("b")

    def test_can_execute_parallel(self):
        executor = ParallelExecutor()
        assert executor.can_execute_parallel(["a", "b"]) is True
        assert executor.can_execute_parallel(["a"]) is False
        assert executor.can_execute_parallel([]) is False

    def test_estimate_parallel_speedup_single(self):
        executor = ParallelExecutor()
        graph = ExecutionGraph()
        node = ExecutionNode(agent_name="a")
        graph.add_node(node)
        assert executor.estimate_parallel_speedup(graph) == 1.0

    def test_estimate_parallel_speedup_multiple(self):
        executor = ParallelExecutor(max_workers=8)
        graph = ExecutionGraph()
        for i in range(5):
            node = ExecutionNode(agent_name=f"a{i}")
            node.status = ExecutionStatus.READY
            node.dependencies = []
            graph.add_node(node)
        speedup = executor.estimate_parallel_speedup(graph)
        assert speedup == 5.0

    def test_estimate_parallel_speedup_capped_by_workers(self):
        executor = ParallelExecutor(max_workers=2)
        graph = ExecutionGraph()
        for i in range(10):
            node = ExecutionNode(agent_name=f"a{i}")
            node.status = ExecutionStatus.READY
            node.dependencies = []
            graph.add_node(node)
        speedup = executor.estimate_parallel_speedup(graph)
        assert speedup == 2.0


class TestGetParallelExecutor:
    """Test global executor singleton."""

    def test_get_parallel_executor(self):
        import core.parallel_executor as mod

        mod._global_parallel_executor = None
        executor = get_parallel_executor()
        assert isinstance(executor, ParallelExecutor)
        mod._global_parallel_executor = None

    def test_get_parallel_executor_cached(self):
        import core.parallel_executor as mod

        executor1 = get_parallel_executor()
        executor2 = get_parallel_executor()
        assert executor1 is executor2
        mod._global_parallel_executor = None
