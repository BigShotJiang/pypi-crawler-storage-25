import asyncio

import pytest

from core.agent_queue import (
    AgentQueue,
    AgentTask,
    TaskResult,
    TaskStatus,
    get_agent_queue,
    reset_agent_queue,
)


def _make_task(
    task_id="t1",
    agent_name="agent1",
    prompt="test",
    priority=0,
    deps=None,
    timeout=300,
    max_retries=3,
):
    return AgentTask(
        task_id=task_id,
        agent_name=agent_name,
        prompt=prompt,
        priority=priority,
        dependencies=deps or [],
        timeout=timeout,
        max_retries=max_retries,
    )


class TestTaskStatus:
    def test_all_statuses(self):
        assert TaskStatus.PENDING == "pending"
        assert TaskStatus.WAITING == "waiting"
        assert TaskStatus.RUNNING == "running"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.TIMEOUT == "timeout"
        assert TaskStatus.CANCELLED == "cancelled"


class TestAgentTask:
    def test_default_values(self):
        task = AgentTask(task_id="t1", agent_name="a", prompt="p")
        assert task.priority == 0
        assert task.dependencies == []
        assert task.timeout == 300
        assert task.retry_count == 0
        assert task.max_retries == 3

    def test_comparison(self):
        t1 = _make_task(priority=5)
        t2 = _make_task(task_id="t2", priority=10)
        assert t1 < t2
        assert not t2 < t1


class TestTaskResult:
    def test_default_values(self):
        result = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)
        assert result.result is None
        assert result.error is None
        assert result.duration == 0.0
        assert result.retry_count == 0
        assert result.metadata == {}


class TestAgentQueueSubmit:
    def test_submit_single(self):
        q = AgentQueue()
        tid = q.submit(_make_task())
        assert tid == "t1"
        assert "t1" in q.tasks

    def test_submit_generates_id(self):
        q = AgentQueue()
        task = _make_task(task_id="")
        tid = q.submit(task)
        assert tid
        assert len(tid) > 0

    def test_submit_with_dependencies(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        assert "t2" in q.waiting["t1"]

    def test_submit_batch(self):
        q = AgentQueue()
        tasks = [_make_task(task_id=f"t{i}") for i in range(5)]
        ids = q.submit_batch(tasks)
        assert len(ids) == 5
        assert len(q.tasks) == 5

    def test_submit_sets_event(self):
        q = AgentQueue()
        q.new_task_event.clear()
        q.submit(_make_task())
        assert q.new_task_event.is_set()


class TestAgentQueueReadyTasks:
    def test_ready_no_deps(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        ready = q.get_ready_tasks()
        assert len(ready) == 1

    def test_ready_deps_completed(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)
        ready = q.get_ready_tasks()
        assert any(t.task_id == "t2" for t in ready)

    def test_ready_deps_not_completed(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.FAILED)
        ready = q.get_ready_tasks()
        assert not any(t.task_id == "t2" for t in ready)

    def test_ready_sorted_by_priority(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="low", priority=1))
        q.submit(_make_task(task_id="high", priority=10))
        ready = q.get_ready_tasks()
        assert ready[0].task_id == "high"

    def test_ready_skips_running(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.running.add("t1")
        ready = q.get_ready_tasks()
        assert len(ready) == 0

    def test_ready_skips_completed(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)
        ready = q.get_ready_tasks()
        assert len(ready) == 0

    def test_ready_with_pending_dep_not_ready(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.PENDING)
        ready = q.get_ready_tasks()
        assert len(ready) == 0


class TestAgentQueueWaitingTasks:
    def test_waiting_with_unmet_deps(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        waiting = q.get_waiting_tasks()
        assert "t2" in waiting
        assert "t1" in waiting["t2"]

    def test_no_waiting_tasks(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        waiting = q.get_waiting_tasks()
        assert len(waiting) == 0

    def test_waiting_skips_running(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        q.running.add("t2")
        waiting = q.get_waiting_tasks()
        assert "t2" not in waiting

    def test_waiting_skips_completed(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2", deps=["t1"]))
        q.results["t2"] = TaskResult(task_id="t2", agent_name="a", status=TaskStatus.COMPLETED)
        waiting = q.get_waiting_tasks()
        assert "t2" not in waiting


class TestAgentQueueExecuteTask:
    @pytest.mark.asyncio
    async def test_execute_success(self):
        q = AgentQueue()
        task = _make_task()

        async def executor(name, prompt, **kw):
            return "output"

        result = await q.execute_task(task, executor)
        assert result.status == TaskStatus.COMPLETED
        assert result.result == "output"
        assert result.duration > 0
        assert result.started_at is not None
        assert result.completed_at is not None

    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        q = AgentQueue()

        async def slow_executor(name, prompt, **kw):
            await asyncio.sleep(10)

        task = _make_task(timeout=1)
        result = await q.execute_task(task, slow_executor)
        assert result.status == TaskStatus.TIMEOUT
        assert "timed out" in result.error

    @pytest.mark.asyncio
    async def test_execute_failure(self):
        q = AgentQueue()

        async def fail_executor(name, prompt, **kw):
            raise ValueError("boom")

        task = _make_task(max_retries=0)
        result = await q.execute_task(task, fail_executor)
        assert result.status == TaskStatus.FAILED
        assert "boom" in result.error

    @pytest.mark.asyncio
    async def test_execute_retries_on_failure(self):
        q = AgentQueue()

        async def fail_executor(name, prompt, **kw):
            raise ValueError("retry me")

        task = _make_task(max_retries=1)
        result = await q.execute_task(task, fail_executor)
        assert result.status == TaskStatus.PENDING
        assert result.retry_count == 1

    @pytest.mark.asyncio
    async def test_execute_sync_function(self):
        q = AgentQueue()
        task = _make_task()

        def sync_executor(name, prompt, metadata):
            return "sync_output"

        result = await q.execute_task(task, sync_executor)
        assert result.status == TaskStatus.COMPLETED
        assert result.result == "sync_output"

    @pytest.mark.asyncio
    async def test_execute_removes_from_running(self):
        q = AgentQueue()
        task = _make_task()

        async def executor(name, prompt, **kw):
            return "out"

        await q.execute_task(task, executor)
        assert task.task_id not in q.running

    @pytest.mark.asyncio
    async def test_execute_retry_increases_priority(self):
        q = AgentQueue()

        async def fail_executor(name, prompt, **kw):
            raise ValueError("fail")

        task = _make_task(max_retries=1, priority=5)
        await q.execute_task(task, fail_executor)
        assert task.priority == 6

    @pytest.mark.asyncio
    async def test_execute_retry_resubmits(self):
        q = AgentQueue()

        async def fail_executor(name, prompt, **kw):
            raise ValueError("fail")

        task = _make_task(max_retries=1)
        await q.execute_task(task, fail_executor)
        assert task.task_id in q.tasks


class TestAgentQueueProgress:
    def test_get_progress_empty(self):
        q = AgentQueue()
        progress = q.get_progress()
        assert progress["total"] == 0
        assert progress["progress"] == 0

    def test_get_progress_with_tasks(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2"))
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)
        progress = q.get_progress()
        assert progress["total"] == 2
        assert progress["completed"] == 1
        assert progress["running"] == 0
        assert progress["waiting"] == 1
        assert progress["progress"] == 50.0

    def test_get_result(self):
        q = AgentQueue()
        q.results["t1"] = TaskResult(task_id="t1", agent_name="a", status=TaskStatus.COMPLETED)
        assert q.get_result("t1") is not None
        assert q.get_result("missing") is None

    def test_get_results_by_agent(self):
        q = AgentQueue()
        q.results["t1"] = TaskResult(task_id="t1", agent_name="agent1", status=TaskStatus.COMPLETED)
        q.results["t2"] = TaskResult(task_id="t2", agent_name="agent2", status=TaskStatus.COMPLETED)
        results = q.get_results_by_agent("agent1")
        assert "t1" in results
        assert "t2" not in results


class TestAgentQueueCancel:
    def test_cancel_task(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        assert q.cancel_task("t1") is True

    def test_cancel_nonexistent_task(self):
        q = AgentQueue()
        assert q.cancel_task("ghost") is False

    def test_cancel_all(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.submit(_make_task(task_id="t2"))
        q.cancel_all()
        assert len(q.tasks) == 0
        assert len(q.results) == 0
        assert len(q.running) == 0
        assert len(q.waiting) == 0


class TestAgentQueueGlobal:
    def test_get_agent_queue(self):
        reset_agent_queue()
        q = get_agent_queue()
        assert isinstance(q, AgentQueue)

    def test_get_agent_queue_returns_same(self):
        reset_agent_queue()
        q1 = get_agent_queue()
        q2 = get_agent_queue()
        assert q1 is q2

    def test_reset_agent_queue(self):
        get_agent_queue()
        reset_agent_queue()
        from core import agent_queue

        assert agent_queue._queue is None

    def test_reset_agent_queue_with_existing(self):
        q = get_agent_queue()
        q.submit(_make_task())
        reset_agent_queue()
        from core import agent_queue

        assert agent_queue._queue is None


class TestAgentQueueExecuteAll:
    @pytest.mark.asyncio
    async def test_execute_parallel(self):
        q = AgentQueue()

        async def executor(name, prompt, **kw):
            return "output"

        tasks = [_make_task(task_id=f"t{i}") for i in range(3)]
        results = await q.execute_parallel(tasks, executor)
        assert len(results) == 3

    @pytest.mark.asyncio
    async def test_execute_all_with_callback(self):
        q = AgentQueue()

        async def executor(name, prompt, **kw):
            return "output"

        q.submit(_make_task(task_id="t1"))
        callbacks = []

        def cb(tid, status):
            callbacks.append((tid, status))

        results = await q.execute_all(executor, progress_callback=cb)
        assert "t1" in results


class TestAgentQueueWaitForCompletion:
    def test_wait_for_completion_no_tasks(self):
        q = AgentQueue()
        result = q.wait_for_completion(timeout=1)
        assert result is True

    def test_wait_for_completion_timeout(self):
        q = AgentQueue()
        q.submit(_make_task(task_id="t1"))
        q.running.add("t1")
        result = q.wait_for_completion(timeout=0.3)
        assert result is False
