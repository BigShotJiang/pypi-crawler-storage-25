"""Unit tests for timeout_handler.py — checkpoint timeout management."""

from core.timeout_handler import TimeoutAction, TimeoutHandler, create_timeout_handler


class TestTimeoutAction:
    def test_enum_values(self):
        assert TimeoutAction.AUTO_APPROVE.value == "auto_approve"
        assert TimeoutAction.ESCALATE.value == "escalate"
        assert TimeoutAction.PAUSE.value == "pause"

    def test_from_string(self):
        assert TimeoutAction("auto_approve") == TimeoutAction.AUTO_APPROVE
        assert TimeoutAction("pause") == TimeoutAction.PAUSE


class TestTimeoutHandlerInit:
    def test_default_action_is_pause(self):
        handler = TimeoutHandler()
        assert handler.action == TimeoutAction.PAUSE

    def test_custom_action(self):
        handler = TimeoutHandler(action=TimeoutAction.AUTO_APPROVE)
        assert handler.action == TimeoutAction.AUTO_APPROVE

    def test_custom_timeout(self):
        handler = TimeoutHandler(timeout_seconds=3600)
        assert handler.timeout_seconds == 3600

    def test_no_timeout(self):
        handler = TimeoutHandler()
        assert handler.timeout_seconds is None

    def test_has_checkpointer(self):
        handler = TimeoutHandler()
        from core.background_checkpointer import BackgroundCheckpointer

        assert isinstance(handler.checkpointer, BackgroundCheckpointer)


class TestTimeoutHandlerTimer:
    def test_start_timer(self):
        handler = TimeoutHandler(timeout_seconds=3600)
        handler.start_timer("cp_01")
        status = handler.get_timer_status("cp_01")
        assert status is not None
        assert status["checkpoint_id"] == "cp_01"

    def test_cancel_timer(self):
        handler = TimeoutHandler(timeout_seconds=3600)
        handler.start_timer("cp_01")
        handler.cancel_timer("cp_01")
        assert handler.get_timer_status("cp_01") is None

    def test_extend_timer(self):
        handler = TimeoutHandler(timeout_seconds=3600)
        handler.start_timer("cp_01")
        result = handler.extend_timer("cp_01", 1800)
        assert result is True

    def test_extend_unknown_timer_fails(self):
        handler = TimeoutHandler()
        result = handler.extend_timer("unknown", 1800)
        assert result is False

    def test_get_timer_status_unknown(self):
        handler = TimeoutHandler()
        assert handler.get_timer_status("unknown") is None

    def test_on_timeout_callback(self):
        triggered = []
        handler = TimeoutHandler(on_timeout=lambda cp_id: triggered.append(cp_id))
        handler._handle_timeout_event("cp_test")
        assert triggered == ["cp_test"]


class TestFactory:
    def test_create_timeout_handler(self):
        handler = create_timeout_handler(action="pause")
        assert isinstance(handler, TimeoutHandler)
        assert handler.action == TimeoutAction.PAUSE

    def test_create_with_timeout(self):
        handler = create_timeout_handler(action="auto_approve", timeout_seconds=7200)
        assert handler.action == TimeoutAction.AUTO_APPROVE
        assert handler.timeout_seconds == 7200
