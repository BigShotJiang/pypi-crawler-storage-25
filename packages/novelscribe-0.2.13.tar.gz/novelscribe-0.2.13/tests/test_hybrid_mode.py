"""Unit tests for hybrid mode — AutonomousExecutor pause/resume at checkpoints."""

from datetime import datetime
from unittest.mock import MagicMock, patch

from core.autonomous_executor import AutonomousConfig, AutonomousExecutor
from core.timeout_handler import TimeoutAction


class TestAutonomousConfigHybrid:
    def test_default_hybrid_mode_off(self):
        config = AutonomousConfig(project_name="test")
        assert config.hybrid_mode is False
        assert config.checkpoint_timeout is None
        assert config.timeout_action == TimeoutAction.PAUSE

    def test_hybrid_mode_on(self):
        config = AutonomousConfig(
            project_name="test",
            hybrid_mode=True,
            checkpoint_timeout=3600,
            timeout_action=TimeoutAction.AUTO_APPROVE,
        )
        assert config.hybrid_mode is True
        assert config.checkpoint_timeout == 3600
        assert config.timeout_action == TimeoutAction.AUTO_APPROVE


class TestPauseAtCheckpoint:
    def test_pause_returns_none_without_orchestrator(self):
        """Executor without human_in_loop should not pause."""
        config = AutonomousConfig(project_name="test", human_in_loop=False)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker") as mock_pt,
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            mock_pt_instance = MagicMock()
            mock_pt_instance.get_state.return_value = MagicMock(
                completed_phases=[],
                progress_percentage=0,
                status=MagicMock(value="running"),
                completed_steps=0,
                total_steps=8,
                current_phase="new_novel",
                start_time=datetime.now(),
                last_update=datetime.now(),
                error=None,
            )
            mock_pt.return_value = mock_pt_instance
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            result = executor.pause_at_checkpoint("outline_phase", None, {})
            assert result is None


class TestCheckpointWaiting:
    def test_waiting_returns_none_without_orchestrator(self):
        config = AutonomousConfig(project_name="test", human_in_loop=False)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            assert executor.checkpoint_waiting() is None


class TestHybridModeTimeout:
    def test_timeout_handler_created_when_hybrid_with_timeout(self):
        config = AutonomousConfig(
            project_name="test",
            human_in_loop=True,
            hybrid_mode=True,
            checkpoint_timeout=3600,
        )
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            assert executor.timeout_handler is not None

    def test_no_timeout_handler_without_hybrid(self):
        config = AutonomousConfig(project_name="test", human_in_loop=True)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            assert executor.timeout_handler is None


class TestResumeFromDecision:
    def test_resume_fails_without_orchestrator(self):
        config = AutonomousConfig(project_name="test", human_in_loop=False)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            result = executor.resume_from_checkpoint_decision("cp_01", {"type": "approve"})
            assert result.success is False
            assert "No checkpoint orchestrator" in result.error


class TestCheckpointOrchestratorIntegration:
    def test_orchestrator_created_when_human_in_loop(self):
        config = AutonomousConfig(project_name="test", human_in_loop=True)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            assert executor.checkpoint_orchestrator is not None

    def test_no_orchestrator_when_human_not_in_loop(self):
        config = AutonomousConfig(project_name="test", human_in_loop=False)
        with (
            patch("core.autonomous_executor.OpenAIClient"),
            patch("core.autonomous_executor.StorageFactory.create"),
            patch("core.autonomous_executor.WorkflowExecutor"),
            patch("core.autonomous_executor.ProgressTracker"),
            patch("core.autonomous_executor.CheckpointManager"),
            patch("core.autonomous_executor.AgentSystemIntegration"),
            patch("core.autonomous_executor.ContextBus"),
            patch("core.autonomous_executor.create_git_manager"),
        ):
            executor = AutonomousExecutor(config=config, storage_path=MagicMock())
            assert executor.checkpoint_orchestrator is None
