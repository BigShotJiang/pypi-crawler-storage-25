"""Tests for checkpoints API router."""

from unittest.mock import MagicMock, patch

import pytest


class TestCheckpointRouterHelpers:
    """Test checkpoint router helper functions."""

    def test_get_handler_project_not_found(self):
        from fastapi import HTTPException

        from api.routers.checkpoints import get_handler

        with patch("core.storage.Storage") as mock_storage_cls:
            mock_storage = MagicMock()
            mock_storage.list_projects.return_value = ["other_project"]
            mock_storage_cls.return_value = mock_storage
            with pytest.raises(HTTPException) as exc_info:
                get_handler("nonexistent_project")
            assert exc_info.value.status_code == 404


class TestGetPendingCheckpoint:
    """Test GET /{project_name}/pending endpoint."""

    @pytest.mark.asyncio
    async def test_get_pending_checkpoint_no_proposal(self):
        from api.routers.checkpoints import get_pending_checkpoint

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.has_pending_proposal.return_value = False
            mock_handler.load_proposal.return_value = None
            mock_handler.load_decision.return_value = None
            mock_get_handler.return_value = mock_handler

            result = await get_pending_checkpoint("test_project")

            assert result["project_name"] == "test_project"
            assert result["has_pending"] is False
            assert result["proposal"] is None
            assert result["decision"] is None

    @pytest.mark.asyncio
    async def test_get_pending_checkpoint_with_proposal(self):
        from datetime import datetime

        from api.routers.checkpoints import get_pending_checkpoint
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.has_pending_proposal.return_value = True
            mock_proposal = CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test Plan"),
                confidence=0.85,
                reasoning="Test reasoning",
                created_at=datetime.now(),
            )
            mock_handler.load_proposal.return_value = mock_proposal
            mock_handler.load_decision.return_value = None
            mock_get_handler.return_value = mock_handler

            result = await get_pending_checkpoint("test_project")

            assert result["has_pending"] is True
            assert result["proposal"] is not None
            assert result["proposal"]["title"] == "Test Plan"


class TestGetProposal:
    """Test GET /{project_name}/proposal endpoint."""

    @pytest.mark.asyncio
    async def test_get_proposal_not_found(self):
        from fastapi import HTTPException

        from api.routers.checkpoints import get_proposal

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.load_proposal.return_value = None
            mock_get_handler.return_value = mock_handler

            with pytest.raises(HTTPException) as exc_info:
                await get_proposal("test_project")
            assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_get_proposal_success(self):
        from datetime import datetime

        from api.routers.checkpoints import get_proposal
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_proposal = CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(
                    title="Test Plan",
                    pov="Hero",
                    word_estimate=50000,
                    pacing="moderate",
                    scenes=[{"id": 1}],
                    metadata={"phase": "outline"},
                ),
                confidence=0.85,
                reasoning="Test reasoning",
                reasoning_trace=["Step 1", "Step 2"],
                created_at=datetime.now(),
            )
            mock_handler.load_proposal.return_value = mock_proposal
            mock_get_handler.return_value = mock_handler

            result = await get_proposal("test_project")

            assert result["checkpoint_id"] == "cp_1"
            assert result["phase"] == "outline_phase"
            assert result["plan"]["title"] == "Test Plan"
            assert result["confidence"] == "85%"


class TestSubmitDecision:
    """Test POST /{project_name}/decision endpoint."""

    @pytest.mark.asyncio
    async def test_submit_decision_no_proposal(self):
        from fastapi import HTTPException

        from api.routers.checkpoints import submit_decision

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.load_proposal.return_value = None
            mock_get_handler.return_value = mock_handler

            with pytest.raises(HTTPException) as exc_info:
                await submit_decision("test_project", {"decision_type": "approve"})
            assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_submit_decision_approve(self):
        from datetime import datetime

        from api.routers.checkpoints import submit_decision
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_proposal = CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.85,
                reasoning="Test",
                created_at=datetime.now(),
            )
            mock_handler.load_proposal.return_value = mock_proposal
            mock_get_handler.return_value = mock_handler

            result = await submit_decision("test_project", {"decision_type": "approve"})

            assert result["status"] == "decision_saved"
            assert result["checkpoint_id"] == "cp_1"
            assert result["decision_type"] == "approve"
            mock_handler.save_decision.assert_called_once()

    @pytest.mark.asyncio
    async def test_submit_decision_modify(self):
        from datetime import datetime

        from api.routers.checkpoints import submit_decision
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_proposal = CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.85,
                reasoning="Test",
                created_at=datetime.now(),
            )
            mock_handler.load_proposal.return_value = mock_proposal
            mock_get_handler.return_value = mock_handler

            result = await submit_decision(
                "test_project",
                {"decision_type": "modify", "modified_content": {"title": "Modified"}},
            )

            assert result["decision_type"] == "modify"

    @pytest.mark.asyncio
    async def test_submit_decision_reject(self):
        from datetime import datetime

        from api.routers.checkpoints import submit_decision
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_proposal = CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.85,
                reasoning="Test",
                created_at=datetime.now(),
            )
            mock_handler.load_proposal.return_value = mock_proposal
            mock_get_handler.return_value = mock_handler

            result = await submit_decision("test_project", {"decision_type": "reject"})

            assert result["decision_type"] == "reject"


class TestGetHistory:
    """Test GET /{project_name}/history endpoint."""

    @pytest.mark.asyncio
    async def test_get_history_no_filter(self):
        from api.routers.checkpoints import get_history

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.get_history.return_value = [
                {"checkpoint_id": "cp_1", "decision_type": "approve"},
                {"checkpoint_id": "cp_2", "decision_type": "modify"},
            ]
            mock_get_handler.return_value = mock_handler

            result = await get_history("test_project")

            assert result["project_name"] == "test_project"
            assert result["checkpoint_id"] is None
            assert len(result["decisions"]) == 2

    @pytest.mark.asyncio
    async def test_get_history_with_filter(self):
        from api.routers.checkpoints import get_history

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.get_history.return_value = [
                {"checkpoint_id": "cp_1", "decision_type": "approve"}
            ]
            mock_get_handler.return_value = mock_handler

            result = await get_history("test_project", checkpoint_id="cp_1")

            assert result["checkpoint_id"] == "cp_1"
            mock_handler.get_history.assert_called_with("cp_1")


class TestExportProposalYaml:
    """Test POST /{project_name}/export_yaml endpoint."""

    @pytest.mark.asyncio
    async def test_export_yaml_no_proposal(self):
        from fastapi import HTTPException

        from api.routers.checkpoints import export_proposal_yaml

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.load_proposal.return_value = None
            mock_get_handler.return_value = mock_handler

            with pytest.raises(HTTPException) as exc_info:
                await export_proposal_yaml("test_project")
            assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_export_yaml_success(self):
        from datetime import datetime

        from api.routers.checkpoints import export_proposal_yaml
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            with patch("core.storage.Storage") as mock_storage_cls:
                mock_handler = MagicMock()
                mock_proposal = CheckpointProposal(
                    checkpoint_id="cp_1",
                    phase="outline_phase",
                    plan=PlanContent(title="Test"),
                    confidence=0.85,
                    reasoning="Test",
                    created_at=datetime.now(),
                )
                mock_handler.load_proposal.return_value = mock_proposal
                mock_get_handler.return_value = mock_handler

                mock_storage = MagicMock()
                mock_storage._base_path = "/tmp/test_base"
                mock_storage_cls.return_value = mock_storage

                result = await export_proposal_yaml("test_project")

                assert result["status"] == "exported"
                assert "filepath" in result


class TestImportDecisionYaml:
    """Test POST /{project_name}/import_decision endpoint."""

    @pytest.mark.asyncio
    async def test_import_decision_success(self):
        from datetime import datetime

        from api.routers.checkpoints import import_decision_yaml
        from core.checkpoint_proposal import CheckpointDecision, DecisionType

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_decision = CheckpointDecision(
                decision_type=DecisionType.APPROVE,
                checkpoint_id="cp_1",
                timestamp=datetime.now(),
            )
            mock_handler.import_decision_from_yaml.return_value = mock_decision
            mock_get_handler.return_value = mock_handler

            result = await import_decision_yaml("test_project", "/path/to/decision.yaml")

            assert result["status"] == "imported"
            assert result["checkpoint_id"] == "cp_1"
            assert result["decision_type"] == "approve"
            mock_handler.save_decision.assert_called_once()

    @pytest.mark.asyncio
    async def test_import_decision_failure(self):
        from fastapi import HTTPException

        from api.routers.checkpoints import import_decision_yaml

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_handler.import_decision_from_yaml.return_value = None
            mock_get_handler.return_value = mock_handler

            with pytest.raises(HTTPException) as exc_info:
                await import_decision_yaml("test_project", "/path/to/invalid.yaml")
            assert exc_info.value.status_code == 400


class TestClearCheckpoint:
    """Test DELETE /{project_name}/clear endpoint."""

    @pytest.mark.asyncio
    async def test_clear_checkpoint(self):
        from api.routers.checkpoints import clear_checkpoint

        with patch("api.routers.checkpoints.get_handler") as mock_get_handler:
            mock_handler = MagicMock()
            mock_get_handler.return_value = mock_handler

            result = await clear_checkpoint("test_project")

            assert result["status"] == "cleared"
            assert result["project_name"] == "test_project"
            mock_handler.clear_proposal.assert_called_once()
            mock_handler.clear_decision.assert_called_once()
