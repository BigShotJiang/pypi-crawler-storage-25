"""End-to-end tests for checkpoint flow — present, decide, incorporate, resume."""

import pytest

from core.checkpoint_orchestrator import CheckpointOrchestrator
from core.checkpoint_proposal import (
    PlanContent,
)


def _plan(**overrides):
    defaults = {"title": "Test Plan", "pov": "Alice", "pacing": "moderate"}
    defaults.update(overrides)
    return PlanContent(**defaults)


class TestCheckpointFlow:
    def test_present_await_incorporate(self):
        """Full flow: present → await → incorporate."""
        orch = CheckpointOrchestrator()
        plan_dict = {"title": "My Novel Outline", "pov": "Alice", "pacing": "moderate"}

        proposal = orch.present_checkpoint("outline_phase", None, plan_dict)
        assert proposal is not None
        assert proposal.confidence > 0
        assert proposal.reasoning

        cp_id = proposal.checkpoint_id

        decision = orch.incorporate_decision(
            cp_id,
            {"type": "approve"},
        )
        assert decision.applied is True

        state = orch.get_checkpoint_state(cp_id)
        assert state["status"] == "approved"

    def test_present_modify_flow(self):
        """Flow with modification."""
        orch = CheckpointOrchestrator()
        proposal = orch.present_checkpoint("outline_phase", None, {"title": "Plan", "pov": "Bob"})

        decision = orch.incorporate_decision(
            proposal.checkpoint_id,
            {"type": "modify", "modified_content": {"title": "Modified Plan", "pov": "Alice"}},
        )
        assert decision.applied is True

    def test_present_reject_flow(self):
        """Flow with rejection."""
        orch = CheckpointOrchestrator()
        proposal = orch.present_checkpoint("outline_phase", None, {"title": "Plan"})

        decision = orch.incorporate_decision(
            proposal.checkpoint_id,
            {"type": "reject"},
        )
        assert decision.applied is False

    def test_present_guidance_flow(self):
        """Flow with guidance."""
        orch = CheckpointOrchestrator()
        proposal = orch.present_checkpoint("outline_phase", None, {"title": "Plan"})

        decision = orch.incorporate_decision(
            proposal.checkpoint_id,
            {"type": "guidance", "guidance_text": "Make it darker"},
        )
        assert decision.applied is True

    def test_present_with_alternatives(self):
        """Checkpoint with alternatives present and comparable."""
        orch = CheckpointOrchestrator()
        plan_dict = {"title": "Primary", "pov": "Alice"}
        alt_dicts = [
            {
                "plan": {"title": "Alt A", "pov": "Bob"},
                "confidence": 0.7,
                "tradeoff": "Different POV",
            },
            {
                "plan": {"title": "Alt B", "pov": "Carol"},
                "confidence": 0.65,
                "tradeoff": "Less depth",
            },
        ]

        proposal = orch.present_checkpoint("outline_phase", None, plan_dict, alternatives=alt_dicts)
        assert len(proposal.alternatives) == 2
        assert proposal.alternatives[0].plan.title == "Alt A"

    def test_unknown_checkpoint_raises(self):
        orch = CheckpointOrchestrator()
        with pytest.raises(ValueError, match="Unknown checkpoint"):
            orch.incorporate_decision("nonexistent", {"type": "approve"})
