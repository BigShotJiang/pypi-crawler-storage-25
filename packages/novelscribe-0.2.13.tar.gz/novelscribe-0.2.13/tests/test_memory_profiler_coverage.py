"""Comprehensive tests for core/memory_profiler.py to bring coverage above 80%."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from core.memory_profiler import MemoryProfiler, MemoryProfilerConfig, MemorySnapshot

mock_psutil = MagicMock()
mock_psutil.Process.return_value.memory_info.return_value.rss = 100 * 1024 * 1024
mock_psutil.virtual_memory.return_value.available = 8000 * 1024 * 1024
mock_psutil.virtual_memory.return_value.total = 16000 * 1024 * 1024


def make_snapshot(
    total_mb=100.0,
    available_mb=8000.0,
    system_mb=16000.0,
    components=None,
    ts_offset=0,
) -> MemorySnapshot:
    comp = components or {
        "context_manager": 10.0,
        "chapter_cache": 20.0,
        "summary_store": 5.0,
        "multi_chapter_manager": 15.0,
        "llm_client": 8.0,
    }
    return MemorySnapshot(
        timestamp=datetime.now(timezone.utc) + timedelta(seconds=ts_offset),
        total_memory_mb=total_mb,
        component_usage=comp,
        object_counts={"str": 100, "dict": 50},
        gc_stats={"gen_0": {"collections": 10}},
        available_memory_mb=available_mb,
        system_memory_mb=system_mb,
    )


class TestMemorySnapshot:
    def test_subtraction(self):
        s1 = make_snapshot(total_mb=100.0, ts_offset=0)
        s2 = make_snapshot(total_mb=120.0, ts_offset=10)
        delta = s2 - s1
        assert delta["total_delta_mb"] == 20.0
        assert delta["time_delta_seconds"] == pytest.approx(10.0, abs=1)

    def test_subtraction_component_delta(self):
        s1 = make_snapshot(components={"a": 10.0, "b": 20.0})
        s2 = make_snapshot(components={"a": 15.0, "b": 20.0, "c": 5.0})
        delta = s2 - s1
        assert delta["component_delta_mb"]["a"] == 5.0
        assert delta["component_delta_mb"]["b"] == 0.0
        assert delta["component_delta_mb"]["c"] == 5.0

    def test_subtraction_negative_delta(self):
        s1 = make_snapshot(total_mb=200.0, ts_offset=0)
        s2 = make_snapshot(total_mb=150.0, ts_offset=10)
        delta = s2 - s1
        assert delta["total_delta_mb"] == -50.0


class TestMemoryProfilerConfig:
    def test_defaults(self):
        config = MemoryProfilerConfig()
        assert config.enabled is True
        assert config.snapshot_interval_seconds == 60
        assert config.max_snapshots == 1000
        assert config.track_object_counts is True
        assert config.track_gc_stats is True
        assert config.component_filter is None
        assert config.auto_cleanup is True

    def test_custom(self):
        config = MemoryProfilerConfig(
            enabled=False, snapshot_interval_seconds=30, max_snapshots=100
        )
        assert config.enabled is False
        assert config.snapshot_interval_seconds == 30
        assert config.max_snapshots == 100


class TestMemoryProfilerInit:
    def test_init_default(self):
        profiler = MemoryProfiler()
        assert profiler.config.enabled is True
        assert len(profiler.component_trackers) > 0

    def test_init_custom_config(self):
        config = MemoryProfilerConfig(max_snapshots=50)
        profiler = MemoryProfiler(config)
        assert profiler.config.max_snapshots == 50

    def test_initialize_tracking(self):
        profiler = MemoryProfiler()
        assert "context_manager" in profiler.component_trackers
        assert "chapter_cache" in profiler.component_trackers
        assert "summary_store" in profiler.component_trackers
        assert "multi_chapter_manager" in profiler.component_trackers
        assert "llm_client" in profiler.component_trackers

    def test_all_trackers_zero(self):
        profiler = MemoryProfiler()
        assert all(v == 0.0 for v in profiler.component_trackers.values())


class TestMemoryProfilerSnapshot:
    def test_take_snapshot(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            profiler = MemoryProfiler()
            snapshot = profiler.take_snapshot()
            assert snapshot.total_memory_mb == pytest.approx(100.0)
            assert len(profiler.snapshots) == 1

    def test_take_snapshot_auto_cleanup(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            config = MemoryProfilerConfig(max_snapshots=3, auto_cleanup=True)
            profiler = MemoryProfiler(config=config)
            for _ in range(5):
                profiler.take_snapshot()
            assert len(profiler.snapshots) == 3

    def test_take_snapshot_no_object_counts(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            config = MemoryProfilerConfig(track_object_counts=False)
            profiler = MemoryProfiler(config=config)
            snapshot = profiler.take_snapshot()
            assert snapshot.object_counts == {}

    def test_take_snapshot_no_gc_stats(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            config = MemoryProfilerConfig(track_gc_stats=False)
            profiler = MemoryProfiler(config=config)
            snapshot = profiler.take_snapshot()
            assert snapshot.gc_stats == {}

    def test_take_snapshot_fields(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            profiler = MemoryProfiler()
            snapshot = profiler.take_snapshot()
            assert isinstance(snapshot.timestamp, datetime)
            assert snapshot.available_memory_mb == pytest.approx(8000.0)
            assert snapshot.system_memory_mb == pytest.approx(16000.0)

    def test_take_snapshot_auto_cleanup_disabled(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            config = MemoryProfilerConfig(max_snapshots=3, auto_cleanup=False)
            profiler = MemoryProfiler(config=config)
            for _ in range(5):
                profiler.take_snapshot()
            assert len(profiler.snapshots) == 5


class TestMemoryProfilerProfiling:
    def test_start_profiling_already_profiling(self):
        profiler = MemoryProfiler()
        profiler.profiling = True
        profiler.start_profiling()
        assert profiler.snapshot_thread is None

    def test_start_stop_profiling(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            profiler = MemoryProfiler()
            profiler.start_profiling(interval_seconds=1)
            assert profiler.profiling is True
            assert profiler.snapshot_thread is not None

            import time

            time.sleep(0.3)
            profiler.stop_profiling()
            assert profiler.profiling is False

    def test_stop_profiling_not_running(self):
        profiler = MemoryProfiler()
        profiler.profiling = False
        profiler.stop_profiling()
        assert profiler.snapshot_thread is None

    def test_stop_profiling_clears_thread(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            profiler = MemoryProfiler()
            profiler.start_profiling(interval_seconds=100)
            profiler.stop_profiling()
            assert profiler.snapshot_thread is None

    def test_profiling_loop_error(self):
        error_psutil = MagicMock()
        error_psutil.Process.return_value.memory_info.side_effect = Exception("psutil error")
        error_psutil.virtual_memory.return_value.available = 8000 * 1024 * 1024
        error_psutil.virtual_memory.return_value.total = 16000 * 1024 * 1024

        with patch.dict(sys.modules, {"psutil": error_psutil}):
            profiler = MemoryProfiler()
            with patch("builtins.print"):
                profiler.start_profiling(interval_seconds=1)
                import time

                time.sleep(0.3)
                profiler.stop_profiling()

    def test_profiling_uses_config_interval(self):
        with patch.dict(sys.modules, {"psutil": mock_psutil}):
            config = MemoryProfilerConfig(snapshot_interval_seconds=100)
            profiler = MemoryProfiler(config)
            profiler.start_profiling()
            assert profiler.profiling is True
            profiler.stop_profiling()


class TestMemoryProfilerReport:
    def test_get_memory_report_no_snapshots(self):
        profiler = MemoryProfiler()
        report = profiler.get_memory_report()
        assert "error" in report
        assert report["error"] == "No snapshots available"

    def test_get_memory_report_with_snapshots(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [
            make_snapshot(total_mb=100.0, ts_offset=0),
            make_snapshot(total_mb=110.0, ts_offset=60),
        ]
        report = profiler.get_memory_report()
        assert "summary" in report
        assert "system" in report
        assert "components" in report
        assert report["summary"]["current_memory_mb"] == 110.0
        assert report["summary"]["peak_memory_mb"] == 110.0
        assert report["summary"]["min_memory_mb"] == 100.0
        assert report["summary"]["snapshot_count"] == 2

    def test_get_memory_report_with_leaks(self):
        profiler = MemoryProfiler()
        profiler.snapshots = []
        for i in range(5):
            comp = {"context_manager": float(10 + i * 5), "chapter_cache": 20.0}
            profiler.snapshots.append(
                make_snapshot(total_mb=100.0 + i * 10, components=comp, ts_offset=i * 10)
            )
        report = profiler.get_memory_report()
        assert len(report.get("leaks_detected", [])) >= 0

    def test_get_memory_report_system_usage(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot(total_mb=160.0, system_mb=16000.0)]
        report = profiler.get_memory_report()
        assert report["system"]["usage_percent"] == pytest.approx(1.0)

    def test_get_memory_report_component_trends_increasing(self):
        profiler = MemoryProfiler()
        now = datetime.now(timezone.utc)
        for i in range(3):
            snapshot = MemorySnapshot(
                timestamp=now + timedelta(seconds=i),
                total_memory_mb=100.0,
                component_usage={"comp": float(i * 10)},
                object_counts={},
                gc_stats={},
                available_memory_mb=500.0,
                system_memory_mb=1024.0,
            )
            profiler.snapshots.append(snapshot)
        report = profiler.get_memory_report()
        assert report["components"]["comp"]["trend"] == "increasing"

    def test_get_memory_report_component_trends_decreasing(self):
        profiler = MemoryProfiler()
        now = datetime.now(timezone.utc)
        for i in range(3):
            snapshot = MemorySnapshot(
                timestamp=now + timedelta(seconds=i),
                total_memory_mb=100.0,
                component_usage={"comp": float(30 - i * 10)},
                object_counts={},
                gc_stats={},
                available_memory_mb=500.0,
                system_memory_mb=1024.0,
            )
            profiler.snapshots.append(snapshot)
        report = profiler.get_memory_report()
        assert report["components"]["comp"]["trend"] == "decreasing"


class TestMemoryProfilerLeaks:
    def test_identify_leaks_insufficient_data(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot(), make_snapshot()]
        leaks = profiler.identify_leaks()
        assert leaks == []

    def test_identify_leaks_with_increase(self):
        profiler = MemoryProfiler()
        profiler.snapshots = []
        for i in range(5):
            comp = {"test_comp": float(10 + i * 10)}
            profiler.snapshots.append(
                make_snapshot(total_mb=100.0 + i * 20, components=comp, ts_offset=i * 10)
            )
        leaks = profiler.identify_leaks()
        assert len(leaks) > 0

    def test_identify_leaks_no_increase(self):
        profiler = MemoryProfiler()
        profiler.snapshots = []
        for i in range(5):
            comp = {"test_comp": 10.0}
            profiler.snapshots.append(
                make_snapshot(total_mb=100.0, components=comp, ts_offset=i * 10)
            )
        leaks = profiler.identify_leaks()
        assert len(leaks) == 0

    def test_identify_leaks_total_memory_leak(self):
        profiler = MemoryProfiler()
        profiler.snapshots = []
        for i in range(5):
            profiler.snapshots.append(
                make_snapshot(total_mb=100.0 + i * 20, components={}, ts_offset=i * 10)
            )
        leaks = profiler.identify_leaks()
        has_total = any("Total memory" in leak for leak in leaks)
        assert has_total

    def test_identify_leaks_below_threshold(self):
        profiler = MemoryProfiler()
        profiler.snapshots = []
        for i in range(5):
            comp = {"comp": float(100 + i)}
            profiler.snapshots.append(
                make_snapshot(total_mb=100.0, components=comp, ts_offset=i * 10)
            )
        leaks = profiler.identify_leaks()
        comp_leaks = [leak for leak in leaks if "comp" in leak]
        assert len(comp_leaks) == 0


class TestMemoryProfilerComponentStats:
    def test_get_component_stats_no_snapshots(self):
        profiler = MemoryProfiler()
        assert profiler.get_component_stats() == {}

    def test_get_component_stats(self):
        profiler = MemoryProfiler()
        comp = {"a": 10.0, "b": 20.0}
        profiler.snapshots = [
            make_snapshot(components=comp, ts_offset=0),
            make_snapshot(components=comp, ts_offset=10),
        ]
        stats = profiler.get_component_stats()
        assert "a" in stats
        assert "b" in stats
        assert stats["a"]["current_mb"] == 10.0
        assert "std_dev_mb" in stats["a"]


class TestMemoryProfilerCompareSnapshots:
    def test_compare_snapshots(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [
            make_snapshot(total_mb=100.0, ts_offset=0),
            make_snapshot(total_mb=120.0, ts_offset=10),
        ]
        result = profiler.compare_snapshots(0, 1)
        assert result["memory_delta_mb"] == 20.0
        assert "snapshot1" in result
        assert "snapshot2" in result

    def test_compare_snapshots_invalid_index(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot()]
        result = profiler.compare_snapshots(0, 5)
        assert "error" in result

    def test_compare_snapshots_first_invalid(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot()]
        result = profiler.compare_snapshots(5, 0)
        assert "error" in result


class TestMemoryProfilerClearSnapshots:
    def test_clear_snapshots(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot()]
        profiler.clear_snapshots()
        assert len(profiler.snapshots) == 0

    def test_clear_snapshots_empty(self):
        profiler = MemoryProfiler()
        profiler.clear_snapshots()
        assert len(profiler.snapshots) == 0


class TestMemoryProfilerExportSnapshots:
    def test_export_snapshots(self, tmp_path):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot(), make_snapshot(ts_offset=10)]
        output = tmp_path / "snapshots.json"
        profiler.export_snapshots(output)
        with open(output) as f:
            data = json.load(f)
        assert len(data["snapshots"]) == 2

    def test_export_snapshots_empty(self, tmp_path):
        profiler = MemoryProfiler()
        output = tmp_path / "empty.json"
        profiler.export_snapshots(output)
        with open(output) as f:
            data = json.load(f)
        assert data["snapshots"] == []

    def test_export_snapshots_content(self, tmp_path):
        profiler = MemoryProfiler()
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=100.0,
            component_usage={"a": 10.0},
            object_counts={"type_a": 5},
            gc_stats={"gen_0": {"collections": 10}},
            available_memory_mb=500.0,
            system_memory_mb=1024.0,
        )
        profiler.snapshots.append(snapshot)
        output = tmp_path / "content.json"
        profiler.export_snapshots(output)
        with open(output) as f:
            data = json.load(f)
        assert data["snapshots"][0]["total_memory_mb"] == 100.0
        assert data["snapshots"][0]["component_usage"]["a"] == 10.0


class TestMemoryProfilerTrackComponent:
    def test_track_component(self):
        profiler = MemoryProfiler()
        profiler.track_component("new_comp", 42.5)
        assert profiler.component_trackers["new_comp"] == 42.5

    def test_track_component_update(self):
        profiler = MemoryProfiler()
        profiler.track_component("context_manager", 100.0)
        assert profiler.component_trackers["context_manager"] == 100.0


class TestMemoryProfilerCurrentUsage:
    def test_get_current_usage_no_snapshots(self):
        profiler = MemoryProfiler()
        assert profiler.get_current_usage() == 0.0

    def test_get_current_usage(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot(total_mb=55.5)]
        assert profiler.get_current_usage() == 55.5


class TestMemoryProfilerTrend:
    def test_get_memory_trend_insufficient_data(self):
        profiler = MemoryProfiler()
        assert profiler.get_memory_trend() == "stable"

    def test_get_memory_trend_single_snapshot(self):
        profiler = MemoryProfiler()
        profiler.snapshots = [make_snapshot()]
        assert profiler.get_memory_trend() == "stable"

    def test_get_memory_trend_increasing(self):
        profiler = MemoryProfiler()
        for i in range(5):
            profiler.snapshots.append(make_snapshot(total_mb=100.0 + i * 10, ts_offset=i * 10))
        trend = profiler.get_memory_trend(window_seconds=600)
        assert trend == "increasing"

    def test_get_memory_trend_decreasing(self):
        profiler = MemoryProfiler()
        for i in range(5):
            profiler.snapshots.append(make_snapshot(total_mb=200.0 - i * 10, ts_offset=i * 10))
        trend = profiler.get_memory_trend(window_seconds=600)
        assert trend == "decreasing"

    def test_get_memory_trend_stable(self):
        profiler = MemoryProfiler()
        for i in range(5):
            profiler.snapshots.append(
                make_snapshot(
                    total_mb=100.0 if i % 2 == 0 else 99.0,
                    ts_offset=i * 10,
                )
            )
        trend = profiler.get_memory_trend(window_seconds=600)
        assert trend == "stable"

    def test_get_memory_trend_old_data_filtered(self):
        profiler = MemoryProfiler()
        old = datetime.now(timezone.utc) - timedelta(seconds=600)
        profiler.snapshots.append(
            MemorySnapshot(
                timestamp=old,
                total_memory_mb=50.0,
                component_usage={},
                object_counts={},
                gc_stats={},
                available_memory_mb=8000.0,
                system_memory_mb=16000.0,
            )
        )
        assert profiler.get_memory_trend(window_seconds=60) == "stable"


class TestMemoryProfilerGetComponentUsage:
    def test_get_component_usage(self):
        profiler = MemoryProfiler()
        profiler.component_trackers = {"test_comp": 5.0}
        with patch.dict(sys.modules, {"test_comp": MagicMock()}):
            usage = profiler._get_component_usage()
            assert "test_comp" in usage

    def test_get_component_usage_exception_fallback(self):
        profiler = MemoryProfiler()
        profiler.component_trackers = {"failing_comp": 5.0}
        with patch.dict(sys.modules, {"failing_comp": MagicMock()}):
            with patch.object(profiler, "_estimate_module_size", side_effect=RuntimeError("fail")):
                usage = profiler._get_component_usage()
                assert usage["failing_comp"] == 5.0

    def test_get_component_usage_not_in_modules(self):
        profiler = MemoryProfiler()
        profiler.component_trackers = {"nonexistent_xyz": 5.0}
        usage = profiler._get_component_usage()
        assert "nonexistent_xyz" not in usage


class TestMemoryProfilerEstimateModuleSize:
    def test_estimate_module_size(self):
        profiler = MemoryProfiler()
        size = profiler._estimate_module_size({"key": "value"})
        assert size > 0

    def test_estimate_module_size_with_dict(self):
        profiler = MemoryProfiler()
        size = profiler._estimate_module_size({"a": {"nested": 1}})
        assert size > 0

    def test_estimate_module_size_with_list(self):
        profiler = MemoryProfiler()
        size = profiler._estimate_module_size([1, 2, 3])
        assert size > 0

    def test_estimate_module_size_with_tuple(self):
        profiler = MemoryProfiler()
        size = profiler._estimate_module_size((1, 2, 3))
        assert size > 0

    def test_estimate_module_size_with_set(self):
        profiler = MemoryProfiler()
        size = profiler._estimate_module_size({1, 2, 3})
        assert size > 0

    def test_estimate_module_size_object_with_dict(self):
        profiler = MemoryProfiler()

        class Obj:
            def __init__(self):
                self.x = 1
                self.y = "hello"

        size = profiler._estimate_module_size(Obj())
        assert size > 0


class TestMemoryProfilerGetObjectCounts:
    def test_get_object_counts(self):
        profiler = MemoryProfiler()
        profiler.object_trackers = {}
        counts = profiler._get_object_counts()
        assert isinstance(counts, dict)

    def test_get_object_counts_module_not_loaded(self):
        profiler = MemoryProfiler()
        profiler.object_trackers = {"nonexistent_xyz_module": 0}
        counts = profiler._get_object_counts()
        assert counts == {}


class TestMemoryProfilerGetGCStats:
    def test_get_gc_stats(self):
        profiler = MemoryProfiler()
        stats = profiler._get_gc_stats()
        assert "collections" in stats
        assert "collected" in stats
        assert "uncollectable" in stats


class TestMemoryProfilerCalculateStdDev:
    def test_std_dev_single_value(self):
        profiler = MemoryProfiler()
        assert profiler._calculate_std_dev([5.0]) == 0.0

    def test_std_dev_empty(self):
        profiler = MemoryProfiler()
        assert profiler._calculate_std_dev([]) == 0.0

    def test_std_dev_multiple_values(self):
        profiler = MemoryProfiler()
        result = profiler._calculate_std_dev([2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0])
        assert result > 0
