"""Coverage tests for core/autonomous_executor.py — cover uncovered branches."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from core.autonomous_executor import AutonomousConfig, AutonomousExecutor, AutonomousResult
from core.progress_tracker import ExecutionStatus


def _make_config(**overrides):
    defaults = {
        "project_name": "testproj",
        "start_phase": "new_novel",
        "end_phase": "verification_phase",
        "human_in_loop": False,
        "provider": "openai",
    }
    defaults.update(overrides)
    return AutonomousConfig(**defaults)


def _make_executor(**config_overrides):
    config = _make_config(**config_overrides)
    with (
        patch("core.autonomous_executor.OpenAIClient"),
        patch("core.autonomous_executor.AgentSystemIntegration"),
        patch("core.autonomous_executor.WorkflowExecutor"),
        patch("core.autonomous_executor.ContextBus"),
        patch("core.autonomous_executor.create_git_manager", return_value=MagicMock()),
        patch("core.autonomous_executor.CheckpointManager"),
        patch("core.autonomous_executor.ProgressTracker"),
        patch("core.autonomous_executor.StorageFactory"),
    ):
        return AutonomousExecutor(config=config, storage_path=Path(".novels"))


class TestAutonomousConfig:
    def test_defaults(self):
        config = AutonomousConfig(project_name="test")
        assert config.start_phase == "new_novel"
        assert config.end_phase == "verification_phase"
        assert config.human_in_loop is False
        assert config.max_chapters is None
        assert config.provider == "openai"

    def test_custom(self):
        config = _make_config(human_in_loop=True, max_chapters=10)
        assert config.human_in_loop is True
        assert config.max_chapters == 10


class TestExecuteResume:
    def test_execute_resume_calls_resume_from_checkpoint(self):
        executor = _make_executor()
        mock_result = AutonomousResult(
            success=True, completed_phases=["outline"], final_status=ExecutionStatus.COMPLETED
        )
        with patch.object(executor, "_resume_from_checkpoint", return_value=mock_result):
            result = executor.execute(resume=True)
        assert result.success is True

    def test_execute_no_resume_calls_full_pipeline(self):
        executor = _make_executor()
        mock_result = AutonomousResult(
            success=True, completed_phases=["new_novel"], final_status=ExecutionStatus.COMPLETED
        )
        with patch.object(executor, "_execute_full_pipeline", return_value=mock_result):
            result = executor.execute(resume=False)
        assert result.success is True

    def test_execute_exception_returns_failure(self):
        executor = _make_executor()
        with patch.object(executor, "_execute_full_pipeline", side_effect=RuntimeError("boom")):
            result = executor.execute()
        assert result.success is False
        assert result.final_status == ExecutionStatus.FAILED
        assert "boom" in result.error


class TestExecuteFullPipeline:
    def test_pipeline_completes_all_phases(self):
        executor = _make_executor()
        mock_state = MagicMock()
        mock_state.completed_phases = ["new_novel"]

        executor.workflow_executor.execute_workflow.return_value = {"success": True}
        executor.progress_tracker.get_state.return_value = mock_state

        result = executor._execute_full_pipeline()
        assert result.success is True
        assert result.final_status == ExecutionStatus.COMPLETED

    def test_pipeline_workflow_fails_raises(self):
        executor = _make_executor()
        executor.workflow_executor.execute_workflow.side_effect = RuntimeError("workflow fail")
        executor.progress_tracker.get_state.return_value = MagicMock(completed_phases=[])

        with pytest.raises(RuntimeError, match="workflow fail"):
            executor._execute_full_pipeline()


class TestGetWorkflowIndex:
    def test_known_workflow(self):
        executor = _make_executor()
        idx = executor._get_workflow_index("outline_phase")
        assert idx == 3

    def test_unknown_workflow_raises(self):
        executor = _make_executor()
        with pytest.raises(ValueError, match="Unknown workflow"):
            executor._get_workflow_index("nonexistent_phase")


class TestResumeFromCheckpoint:
    def test_no_checkpoint_returns_failure(self):
        executor = _make_executor()
        executor.checkpoint_manager.load_checkpoint.return_value = None
        result = executor._resume_from_checkpoint()
        assert result.success is False
        assert "No checkpoint" in result.error

    def test_invalid_checkpoint_returns_failure(self):
        executor = _make_executor()
        mock_cp = MagicMock()
        executor.checkpoint_manager.load_checkpoint.return_value = mock_cp
        executor.checkpoint_manager.validate_checkpoint.return_value = False
        result = executor._resume_from_checkpoint()
        assert result.success is False
        assert "Invalid checkpoint" in result.error

    def test_valid_checkpoint_resumes(self):
        executor = _make_executor()
        mock_cp = MagicMock()
        mock_cp.completed_workflows = ["new_novel", "worldbuilding_phase"]
        mock_cp.execution_context = {"project_name": "testproj"}
        mock_cp.progress_state = MagicMock()

        executor.checkpoint_manager.load_checkpoint.return_value = mock_cp
        executor.checkpoint_manager.validate_checkpoint.return_value = True

        mock_state = MagicMock()
        mock_state.completed_phases = ["new_novel", "worldbuilding_phase"]
        executor.progress_tracker.get_state.return_value = mock_state
        executor.progress_tracker._state = MagicMock()

        executor.workflow_executor.execute_workflow.return_value = {"success": True}

        executor.context_bus.restore_snapshot.return_value = MagicMock(
            phase="worldbuilding_phase", step="complete"
        )

        result = executor._resume_from_checkpoint()
        assert result.success is True
        assert result.final_status == ExecutionStatus.COMPLETED


class TestPauseAtCheckpoint:
    def test_no_orchestrator_returns_none(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = None
        result = executor.pause_at_checkpoint("outline_phase", None, {})
        assert result is None

    def test_no_pause_needed_returns_none(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = MagicMock()
        executor.checkpoint_orchestrator.should_pause_at_phase.return_value = False
        result = executor.pause_at_checkpoint("outline_phase", None, {})
        assert result is None


class TestResumeFromCheckpointDecision:
    def test_no_orchestrator_returns_failure(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = None
        result = executor.resume_from_checkpoint_decision("cp_001", {"type": "approve"})
        assert result.success is False
        assert "No checkpoint orchestrator" in result.error


class TestCheckpointWaiting:
    def test_no_orchestrator_returns_none(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = None
        result = executor.checkpoint_waiting()
        assert result is None

    def test_no_pending_returns_none(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = MagicMock()
        executor.checkpoint_orchestrator.get_pending_checkpoints.return_value = []
        result = executor.checkpoint_waiting()
        assert result is None

    def test_pending_returns_info(self):
        executor = _make_executor()
        mock_proposal = MagicMock()
        mock_proposal.phase = "outline_phase"
        mock_proposal.plan.title = "Outline Plan"
        mock_proposal.confidence = 0.85

        executor.checkpoint_orchestrator = MagicMock()
        executor.checkpoint_orchestrator.get_pending_checkpoints.return_value = ["cp_001"]
        executor.checkpoint_orchestrator.get_checkpoint_state.return_value = {
            "proposal": mock_proposal,
            "status": "pending",
        }

        result = executor.checkpoint_waiting()
        assert result is not None
        assert result["checkpoint_id"] == "cp_001"
        assert result["confidence"] == 0.85

    def test_pending_no_state_returns_none(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = MagicMock()
        executor.checkpoint_orchestrator.get_pending_checkpoints.return_value = ["cp_001"]
        executor.checkpoint_orchestrator.get_checkpoint_state.return_value = None

        result = executor.checkpoint_waiting()
        assert result is None

    def test_pending_no_proposal_in_state(self):
        executor = _make_executor()
        executor.checkpoint_orchestrator = MagicMock()
        executor.checkpoint_orchestrator.get_pending_checkpoints.return_value = ["cp_001"]
        executor.checkpoint_orchestrator.get_checkpoint_state.return_value = {"status": "pending"}

        result = executor.checkpoint_waiting()
        assert result is None


class TestBuildCheckpointPlanContent:
    def test_new_novel_phase(self):
        executor = _make_executor()
        result = executor._build_checkpoint_plan_content("new_novel", None, {})
        assert result["word_estimate"] == 80000

    def test_outline_phase_with_target(self):
        executor = _make_executor()
        result = executor._build_checkpoint_plan_content(
            "outline_phase", None, {"target_word_count": 50000}
        )
        assert result["word_estimate"] == 50000

    def test_chapter_plan_phase(self):
        executor = _make_executor()
        result = executor._build_checkpoint_plan_content("chapter_plan_phase", 5, {})
        assert result["word_estimate"] == 3000
        assert "Chapter 5" in result["title"]

    def test_writing_phase(self):
        executor = _make_executor()
        result = executor._build_checkpoint_plan_content("writing_phase", 3, {})
        assert result["word_estimate"] == 3000
