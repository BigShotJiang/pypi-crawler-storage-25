"""Coverage tests for core/context_compressor.py — cover truncate, extract, summarize, force-fit."""

from unittest.mock import MagicMock

from core.context_assembly import ContextBlock
from core.context_compressor import CompressionTier, ContextCompressor
from core.context_schema import TokenBudget


def _block(content, tokens=None, compressible=True, priority=5, source="test", label="test"):
    return ContextBlock(
        source=source,
        priority=priority,
        content=content,
        token_count=tokens or len(content.split()),
        compressible=compressible,
        label=label,
    )


def _budget(available=100):
    return TokenBudget(
        total_limit=available + 1000, reserved_output=1000, available_for_input=available
    )


class TestCompressEmpty:
    def test_empty_blocks(self):
        compressor = ContextCompressor()
        result = compressor.compress([], _budget(100))
        assert result.context_str == ""
        assert result.tier_used == CompressionTier.NONE


class TestCompressNoneTier:
    def test_fits_within_budget(self):
        compressor = ContextCompressor()
        blocks = [_block("hello world", tokens=10)]
        result = compressor.compress(blocks, _budget(100))
        assert result.tier_used == CompressionTier.NONE
        assert "hello world" in result.context_str


class TestCompressTruncateTier:
    def test_truncate_drops_low_priority(self):
        compressor = ContextCompressor()
        blocks = [
            _block("important", tokens=10, compressible=False, priority=10),
            _block("low priority content", tokens=200, compressible=True, priority=1),
            _block("medium priority", tokens=200, compressible=True, priority=5),
        ]
        result = compressor.compress(blocks, _budget(50))
        assert result.tier_used in (CompressionTier.TRUNCATE, CompressionTier.EXTRACT)
        assert result.original_tokens > result.compressed_tokens


class TestCompressExtractTier:
    def test_extract_reduces_content(self):
        compressor = ContextCompressor()
        blocks = [
            _block("frozen", tokens=10, compressible=False, priority=10),
            _block(
                "# Chapter 1\n\nAlice went to the market.\nBob followed her secretly.\n"
                "- Key event: discovery\n- Character: Alice\n\n"
                "Alice discovered that Bob was actually her long lost brother.",
                tokens=500,
                compressible=True,
                priority=3,
            ),
        ]
        result = compressor.compress(blocks, _budget(20))
        assert result.original_tokens > result.compressed_tokens


class TestCompressSummarizeTier:
    def test_summarize_with_llm_client(self):
        mock_llm = MagicMock()
        mock_response = MagicMock()
        mock_response.content = "Short summary"
        mock_llm.generate.return_value = mock_response

        compressor = ContextCompressor(llm_client=mock_llm)
        blocks = [
            _block("frozen", tokens=10, compressible=False, priority=10),
            _block("very long content " * 100, tokens=500, compressible=True, priority=1),
        ]
        result = compressor.compress(blocks, _budget(15))
        assert result.tier_used in (
            CompressionTier.TRUNCATE,
            CompressionTier.EXTRACT,
            CompressionTier.SUMMARIZE,
        )


class TestForceFit:
    def test_force_fit_truncates_everything(self):
        compressor = ContextCompressor()
        blocks = [
            _block("frozen", tokens=50, compressible=False, priority=10),
            _block("big block " * 50, tokens=500, compressible=True, priority=1),
        ]
        result = compressor.compress(blocks, _budget(60))
        assert result.compressed_tokens <= 60 or result.context_str == ""


class TestExtractKeyElements:
    def test_extracts_headings(self):
        compressor = ContextCompressor()
        content = "# Chapter 1\nSome normal text\n## Section\nMore text"
        result = compressor._extract_key_elements(content)
        assert "# Chapter 1" in result
        assert "## Section" in result

    def test_extracts_bullet_points(self):
        compressor = ContextCompressor()
        content = "- Key event\n- Another point\nNormal text here"
        result = compressor._extract_key_elements(content)
        assert "- Key event" in result

    def test_extracts_character_actions(self):
        compressor = ContextCompressor()
        content = "Alice discovered the truth\nBob left the city\nNothing happened"
        result = compressor._extract_key_elements(content)
        assert "discovered" in result

    def test_extracts_dialogue(self):
        compressor = ContextCompressor()
        content = 'She said "I will never return"\nNormal line'
        result = compressor._extract_key_elements(content)
        assert '"I will never return"' in result or "\u201c" in content

    def test_extracts_label_value_pairs(self):
        compressor = ContextCompressor()
        content = "Character Name: Alice\nLocation: Castle\nNormal text"
        result = compressor._extract_key_elements(content)
        assert "Character Name: Alice" in result

    def test_empty_content(self):
        compressor = ContextCompressor()
        result = compressor._extract_key_elements("")
        assert result == ""

    def test_fallback_to_sentences(self):
        compressor = ContextCompressor()
        content = (
            "First sentence. Second sentence. Third sentence. Fourth sentence. Fifth sentence."
        )
        result = compressor._extract_key_elements(content)
        assert len(result) > 0


class TestTruncateBlock:
    def test_truncate_to_target(self):
        compressor = ContextCompressor()
        block = _block("word " * 100, tokens=100)
        result = compressor._truncate_block(block, 20)
        assert len(result) < len(block.content)

    def test_truncate_empty_content(self):
        compressor = ContextCompressor()
        block = _block("", tokens=0)
        result = compressor._truncate_block(block, 20)
        assert result == ""

    def test_truncate_short_enough(self):
        compressor = ContextCompressor()
        block = _block("short", tokens=5)
        result = compressor._truncate_block(block, 100)
        assert result == "short"


class TestConcatenate:
    def test_with_labels(self):
        compressor = ContextCompressor()
        blocks = [
            _block("hello", tokens=5, label="Intro"),
            _block("world", tokens=5, label="Body"),
        ]
        result = compressor._concatenate(blocks)
        assert "## Intro" in result
        assert "## Body" in result

    def test_without_labels(self):
        compressor = ContextCompressor()
        blocks = [_block("hello", tokens=5, label="")]
        result = compressor._concatenate(blocks)
        assert "hello" in result


class TestSummarizeViaLlm:
    def test_no_llm_returns_content(self):
        compressor = ContextCompressor(llm_client=None)
        result = compressor._summarize_via_llm("some content", 100)
        assert result == "some content"

    def test_empty_content_returns_empty(self):
        mock_llm = MagicMock()
        compressor = ContextCompressor(llm_client=mock_llm)
        result = compressor._summarize_via_llm("", 100)
        assert result == ""

    def test_llm_failure_falls_back(self):
        mock_llm = MagicMock()
        mock_llm.generate.side_effect = RuntimeError("API fail")
        compressor = ContextCompressor(llm_client=mock_llm)
        result = compressor._summarize_via_llm("# Heading\nSome content", 50)
        assert len(result) > 0
