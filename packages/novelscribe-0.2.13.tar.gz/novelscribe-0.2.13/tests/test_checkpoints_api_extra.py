"""Additional tests for api/routers/checkpoints.py — covering uncovered endpoints."""

from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient


def _make_proposal():
    """Create a mock checkpoint proposal."""
    from core.checkpoint_proposal import Alternative, CheckpointProposal, PlanContent

    plan = PlanContent(title="Test Plan", pov="Alice", pacing="moderate")
    alt = Alternative(
        option_id="B",
        plan=PlanContent(title="Alt Plan", pov="Bob", pacing="fast"),
        confidence=0.6,
        tradeoff_explanation="Less tension",
    )
    proposal = CheckpointProposal(
        checkpoint_id="cp_001",
        phase="outline",
        plan=plan,
        confidence=0.82,
        reasoning="Strong arc alignment",
        reasoning_trace=["Identified phase", "Generated plan"],
        alternatives=[alt],
        context_summary={"chapters": 5},
    )
    return proposal


def _make_decision():
    """Create a mock checkpoint decision."""
    from core.checkpoint_proposal import CheckpointDecision, DecisionType

    return CheckpointDecision(
        decision_type=DecisionType.APPROVE,
        checkpoint_id="cp_001",
    )


@pytest.fixture
def client():
    """Create test client with checkpoints router."""
    from fastapi import FastAPI

    from api.routers.checkpoints import router

    app = FastAPI()
    app.include_router(router)
    return TestClient(app)


class TestGetPendingCheckpoint:
    """Tests for GET /{project_name}/pending."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_pending_with_proposal_and_decision(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        decision = _make_decision()
        handler = MagicMock()
        handler.has_pending_proposal.return_value = True
        handler.load_proposal.return_value = proposal
        handler.load_decision.return_value = decision
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/pending")
        assert resp.status_code == 200
        data = resp.json()
        assert data["has_pending"] is True
        assert data["proposal"]["checkpoint_id"] == "cp_001"
        assert data["decision"]["decision_type"] == "approve"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_pending_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.has_pending_proposal.return_value = False
        handler.load_proposal.return_value = None
        handler.load_decision.return_value = None
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/pending")
        assert resp.status_code == 200
        data = resp.json()
        assert data["has_pending"] is False
        assert data["proposal"] is None


class TestGetProposal:
    """Tests for GET /{project_name}/proposal."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_proposal_found(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/proposal")
        assert resp.status_code == 200
        data = resp.json()
        assert data["checkpoint_id"] == "cp_001"
        assert data["plan"]["title"] == "Test Plan"
        assert len(data["alternatives"]) == 1

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_proposal_not_found(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/proposal")
        assert resp.status_code == 404


class TestSubmitDecision:
    """Tests for POST /{project_name}/decision."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_approve(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={"decision_type": "approve"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["decision_type"] == "approve"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_modify(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={
                "decision_type": "modify",
                "modified_content": {"title": "Changed"},
            },
        )
        assert resp.status_code == 200
        assert resp.json()["decision_type"] == "modify"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_reject(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={"decision_type": "reject"},
        )
        assert resp.status_code == 200

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_guidance(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={"decision_type": "guidance", "guidance_text": "Make it darker"},
        )
        assert resp.status_code == 200

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_unknown_type_defaults_approve(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={"decision_type": "unknown_type"},
        )
        assert resp.status_code == 200
        assert resp.json()["decision_type"] == "approve"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_submit_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/decision",
            json={"decision_type": "approve"},
        )
        assert resp.status_code == 404


class TestGetHistory:
    """Tests for GET /{project_name}/history."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_history(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.get_history.return_value = [{"id": "1", "type": "approve"}]
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/history")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["decisions"]) == 1

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_history_with_checkpoint_id(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.get_history.return_value = []
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/history?checkpoint_id=cp_001")
        assert resp.status_code == 200


class TestExportYaml:
    """Tests for POST /{project_name}/export_yaml."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_export_success(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        mock_storage_inst = MagicMock()
        mock_storage_inst._base_path = "/tmp"
        mock_storage.return_value = mock_storage_inst

        resp = client.post("/checkpoints/test-project/export_yaml")
        assert resp.status_code == 200
        assert resp.json()["status"] == "exported"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_export_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.post("/checkpoints/test-project/export_yaml")
        assert resp.status_code == 404


class TestImportDecisionYaml:
    """Tests for POST /{project_name}/import_decision."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_import_success(self, mock_storage, mock_handler, client):
        decision = _make_decision()
        handler = MagicMock()
        handler.import_decision_from_yaml.return_value = decision
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/import_decision",
            params={"filepath": "/tmp/decision.yaml"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "imported"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_import_failure(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.import_decision_from_yaml.return_value = None
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/import_decision",
            params={"filepath": "/tmp/nonexistent.yaml"},
        )
        assert resp.status_code == 400


class TestClearCheckpoint:
    """Tests for DELETE /{project_name}/clear."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_clear(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        mock_handler.return_value = handler

        resp = client.delete("/checkpoints/test-project/clear")
        assert resp.status_code == 200
        assert resp.json()["status"] == "cleared"
        handler.clear_proposal.assert_called_once()
        handler.clear_decision.assert_called_once()


class TestGetExplanation:
    """Tests for GET /{project_name}/explanation."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_explanation(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/explanation?question=why+this+plan")
        assert resp.status_code == 200
        data = resp.json()
        assert data["checkpoint_id"] == "cp_001"
        assert "answer" in data

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_explanation_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/explanation?question=why")
        assert resp.status_code == 404


class TestWhatIf:
    """Tests for POST /{project_name}/what-if."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_what_if(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/what-if",
            json={"modification": "add romance subplot"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["modification"] == "add romance subplot"

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_what_if_no_modification(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/what-if",
            json={"modification": ""},
        )
        assert resp.status_code == 400

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_what_if_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.post(
            "/checkpoints/test-project/what-if",
            json={"modification": "change POV"},
        )
        assert resp.status_code == 404


class TestCompareAlternatives:
    """Tests for GET /{project_name}/comparison."""

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_comparison(self, mock_storage, mock_handler, client):
        proposal = _make_proposal()
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/comparison")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["options"]) == 2
        assert data["recommendation"] == "Primary"
        assert len(data["confidence_factors"]) > 0

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_comparison_no_proposal(self, mock_storage, mock_handler, client):
        handler = MagicMock()
        handler.load_proposal.return_value = None
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/comparison")
        assert resp.status_code == 404

    @patch("api.routers.checkpoints.get_handler")
    @patch("core.storage.Storage")
    def test_comparison_alt_better(self, mock_storage, mock_handler, client):
        """Test comparison when alternative has higher confidence."""
        from core.checkpoint_proposal import Alternative, CheckpointProposal, PlanContent

        plan = PlanContent(title="Primary", pov="Alice", pacing="moderate")
        alt = Alternative(
            option_id="B",
            plan=PlanContent(title="Better Alt", pov="Bob", pacing="fast"),
            confidence=0.95,
            tradeoff_explanation="Higher tension",
        )
        proposal = CheckpointProposal(
            checkpoint_id="cp_002",
            phase="outline",
            plan=plan,
            confidence=0.70,
            reasoning="Decent plan",
            alternatives=[alt],
        )
        handler = MagicMock()
        handler.load_proposal.return_value = proposal
        mock_handler.return_value = handler

        resp = client.get("/checkpoints/test-project/comparison")
        assert resp.status_code == 200
        data = resp.json()
        assert data["recommendation"] == "B"
