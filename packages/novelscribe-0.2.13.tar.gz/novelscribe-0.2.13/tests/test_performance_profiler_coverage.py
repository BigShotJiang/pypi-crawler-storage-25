"""Tests for core.performance_profiler to achieve 80%+ coverage."""

import csv
import json
from pathlib import Path

import pytest

from core.performance_profiler import (
    ExecutionProfile,
    ExecutionStatus,
    PerformanceProfiler,
    PerformanceReport,
    ProfileType,
    ProfilingContext,
    get_profiler,
    profile_function,
)


class TestExecutionStatus:
    def test_values(self):
        assert ExecutionStatus.PENDING.value == "pending"
        assert ExecutionStatus.RUNNING.value == "running"
        assert ExecutionStatus.COMPLETED.value == "completed"
        assert ExecutionStatus.FAILED.value == "failed"


class TestProfileType:
    def test_values(self):
        assert ProfileType.AGENT.value == "agent"
        assert ProfileType.WORKFLOW.value == "workflow"
        assert ProfileType.LLM_CALL.value == "llm_call"
        assert ProfileType.FILE_IO.value == "file_io"
        assert ProfileType.CUSTOM.value == "custom"


class TestExecutionProfile:
    def test_complete(self):
        p = ExecutionProfile(
            profile_id="p1", name="test", profile_type=ProfileType.AGENT, start_time=100.0
        )
        p.complete(end_time=105.0)
        assert p.duration == 5.0
        assert p.status == ExecutionStatus.COMPLETED

    def test_complete_auto_time(self):
        p = ExecutionProfile(
            profile_id="p1", name="test", profile_type=ProfileType.AGENT, start_time=100.0
        )
        p.complete()
        assert p.end_time is not None
        assert p.duration is not None
        assert p.status == ExecutionStatus.COMPLETED

    def test_fail(self):
        p = ExecutionProfile(
            profile_id="p1", name="test", profile_type=ProfileType.AGENT, start_time=100.0
        )
        p.fail("some error", end_time=102.0)
        assert p.duration == 2.0
        assert p.status == ExecutionStatus.FAILED
        assert p.error == "some error"

    def test_fail_auto_time(self):
        p = ExecutionProfile(
            profile_id="p1", name="test", profile_type=ProfileType.AGENT, start_time=100.0
        )
        p.fail("err")
        assert p.end_time is not None
        assert p.error == "err"

    def test_to_dict(self):
        p = ExecutionProfile(
            profile_id="p1",
            name="test",
            profile_type=ProfileType.AGENT,
            start_time=100.0,
            end_time=105.0,
            duration=5.0,
            status=ExecutionStatus.COMPLETED,
            metadata={"key": "val"},
            sub_profiles=["sp1"],
            parent_id="parent",
            error=None,
        )
        d = p.to_dict()
        assert d["profile_id"] == "p1"
        assert d["type"] == "agent"
        assert d["duration"] == 5.0
        assert d["metadata"] == {"key": "val"}
        assert d["sub_profiles"] == ["sp1"]
        assert d["parent_id"] == "parent"
        assert d["error"] is None

    def test_defaults(self):
        p = ExecutionProfile(
            profile_id="p1", name="test", profile_type=ProfileType.AGENT, start_time=100.0
        )
        assert p.status == ExecutionStatus.PENDING
        assert p.end_time is None
        assert p.duration is None
        assert p.metadata == {}
        assert p.sub_profiles == []
        assert p.parent_id is None
        assert p.error is None


class TestPerformanceReport:
    def test_to_dict(self):
        profile = ExecutionProfile(
            profile_id="p1",
            name="test",
            profile_type=ProfileType.AGENT,
            start_time=100.0,
        )
        report = PerformanceReport(
            total_duration=10.0,
            agent_profiles=[profile],
            workflow_profiles=[],
            llm_profiles=[],
            file_io_profiles=[],
            bottlenecks=["slow"],
            summary={"total": 1},
        )
        d = report.to_dict()
        assert d["total_duration"] == 10.0
        assert d["agent_count"] == 1
        assert d["workflow_count"] == 0
        assert d["llm_call_count"] == 0
        assert d["file_io_count"] == 0
        assert d["bottlenecks"] == ["slow"]
        assert len(d["agents"]) == 1
        assert d["summary"] == {"total": 1}


class TestPerformanceProfiler:
    def test_initialization(self):
        profiler = PerformanceProfiler()
        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert len(profiler.profile_stack) == 0

    def test_start_and_end_profile(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test_agent", ProfileType.AGENT)
        profile = profiler.end_profile(pid)
        assert profile.status == ExecutionStatus.COMPLETED
        assert profile.duration is not None

    def test_start_profile_with_metadata(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT, metadata={"key": "val"})
        profile = profiler.profiles[pid]
        assert profile.metadata == {"key": "val"}
        assert profile.status == ExecutionStatus.RUNNING

    def test_end_profile_with_error(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profile = profiler.end_profile(pid, error="something failed")
        assert profile.status == ExecutionStatus.FAILED
        assert profile.error == "something failed"

    def test_end_profile_with_metadata(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profile = profiler.end_profile(pid, metadata={"extra": "data"})
        assert profile.metadata["extra"] == "data"

    def test_end_profile_not_found(self):
        profiler = PerformanceProfiler()
        with pytest.raises(ValueError, match="not found"):
            profiler.end_profile("nonexistent")

    def test_get_profile(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        assert profiler.get_profile(pid) is not None
        assert profiler.get_profile("nope") is None

    def test_get_profiles_by_type(self):
        profiler = PerformanceProfiler()
        pid1 = profiler.start_profile("a1", ProfileType.AGENT)
        profiler.end_profile(pid1)
        pid2 = profiler.start_profile("w1", ProfileType.WORKFLOW)
        profiler.end_profile(pid2)
        agents = profiler.get_profiles_by_type(ProfileType.AGENT)
        assert len(agents) == 1
        workflows = profiler.get_profiles_by_type(ProfileType.WORKFLOW)
        assert len(workflows) == 1

    def test_get_profiles_by_name(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("my_agent", ProfileType.AGENT)
        profiler.end_profile(pid)
        profiles = profiler.get_profiles_by_name("my_agent")
        assert len(profiles) == 1

    def test_get_profiles_by_name_multiple(self):
        profiler = PerformanceProfiler()
        pid1 = profiler.start_profile("dup", ProfileType.AGENT)
        profiler.end_profile(pid1)
        pid2 = profiler.start_profile("dup", ProfileType.AGENT)
        profiler.end_profile(pid2)
        profiles = profiler.get_profiles_by_name("dup")
        assert len(profiles) == 2

    def test_parent_child_relationship(self):
        profiler = PerformanceProfiler()
        parent_id = profiler.start_profile("parent", ProfileType.WORKFLOW)
        child_id = profiler.start_profile("child", ProfileType.AGENT)
        profiler.end_profile(child_id)
        profiler.end_profile(parent_id)
        parent = profiler.get_profile(parent_id)
        assert child_id in parent.sub_profiles
        child = profiler.get_profile(child_id)
        assert child.parent_id == parent_id

    def test_identify_bottlenecks(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("slow", ProfileType.AGENT)
        profiler.end_profile(pid)
        profile = profiler.get_profile(pid)
        profile.duration = 10.0
        profile.end_time = profile.start_time + 10.0
        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)
        assert len(bottlenecks) >= 1

    def test_identify_bottlenecks_no_bottlenecks(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("fast", ProfileType.AGENT)
        profiler.end_profile(pid)
        profile = profiler.get_profile(pid)
        profile.duration = 0.001
        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)
        assert len(bottlenecks) == 0

    def test_identify_bottlenecks_with_type_filter(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("slow_agent", ProfileType.AGENT)
        profiler.end_profile(pid)
        profile = profiler.get_profile(pid)
        profile.duration = 10.0
        bottlenecks = profiler.identify_bottlenecks(
            threshold=5.0, profile_type=ProfileType.WORKFLOW
        )
        assert len(bottlenecks) == 0

    def test_identify_bottlenecks_with_parent(self):
        profiler = PerformanceProfiler()
        parent_id = profiler.start_profile("parent", ProfileType.WORKFLOW)
        profiler.end_profile(parent_id)
        parent = profiler.get_profile(parent_id)
        parent.duration = 20.0
        parent.end_time = parent.start_time + 20.0

        child_id = profiler.start_profile("child", ProfileType.AGENT)
        profiler.end_profile(child_id)
        child = profiler.get_profile(child_id)
        child.duration = 10.0
        child.end_time = child.start_time + 10.0
        child.parent_id = parent_id

        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)
        assert any("parent" in b for b in bottlenecks)

    def test_identify_bottlenecks_sorted(self):
        profiler = PerformanceProfiler()
        pid1 = profiler.start_profile("fast", ProfileType.AGENT)
        profiler.end_profile(pid1)
        profiler.profiles[pid1].duration = 3.0
        profiler.profiles[pid1].end_time = profiler.profiles[pid1].start_time + 3.0

        pid2 = profiler.start_profile("slow", ProfileType.AGENT)
        profiler.end_profile(pid2)
        profiler.profiles[pid2].duration = 10.0
        profiler.profiles[pid2].end_time = profiler.profiles[pid2].start_time + 10.0

        bottlenecks = profiler.identify_bottlenecks(threshold=1.0)
        assert "slow" in bottlenecks[0]
        assert "fast" in bottlenecks[1]

    def test_get_report(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("agent1", ProfileType.AGENT)
        profiler.end_profile(pid)
        report = profiler.get_report()
        assert isinstance(report, PerformanceReport)
        assert len(report.agent_profiles) == 1
        assert "total_profiles" in report.summary

    def test_get_report_summary_stats(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("a1", ProfileType.AGENT)
        profiler.end_profile(pid)
        summary = profiler.get_report().summary
        assert "agents" in summary
        assert summary["agents"]["count"] == 1

    def test_get_report_summary_empty_profiles(self):
        profiler = PerformanceProfiler()
        summary = profiler.get_report().summary
        assert summary["agents"]["count"] == 0
        assert summary["agents"]["avg_duration"] == 0

    def test_get_report_summary_with_failed(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("a1", ProfileType.AGENT)
        profiler.end_profile(pid, error="fail")
        summary = profiler.get_report().summary
        assert summary["agents"]["failed"] == 1

    def test_get_report_all_profile_types(self):
        profiler = PerformanceProfiler()
        pid1 = profiler.start_profile("a", ProfileType.AGENT)
        profiler.end_profile(pid1)
        pid2 = profiler.start_profile("w", ProfileType.WORKFLOW)
        profiler.end_profile(pid2)
        pid3 = profiler.start_profile("l", ProfileType.LLM_CALL)
        profiler.end_profile(pid3)
        pid4 = profiler.start_profile("f", ProfileType.FILE_IO)
        profiler.end_profile(pid4)
        report = profiler.get_report()
        assert len(report.agent_profiles) == 1
        assert len(report.workflow_profiles) == 1
        assert len(report.llm_profiles) == 1
        assert len(report.file_io_profiles) == 1

    def test_export_json(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "perf.json")
        result = profiler.export_data(output, format="json")
        with open(result) as f:
            data = json.load(f)
        assert "total_duration" in data

    def test_export_json_with_type_filter(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "perf.json")
        result = profiler.export_data(output, format="json", profile_type=ProfileType.AGENT)
        with open(result) as f:
            data = json.load(f)
        assert "profiles" in data

    def test_export_csv(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "perf.csv")
        result = profiler.export_data(output, format="csv")
        with open(result) as f:
            content = f.read()
        assert "Profile ID" in content

    def test_export_csv_with_type_filter(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "perf.csv")
        result = profiler.export_data(output, format="csv", profile_type=ProfileType.AGENT)
        assert result.endswith(".csv")

    def test_export_csv_content(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("agent_test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "perf.csv")
        profiler.export_data(output, format="csv")
        with open(output) as f:
            reader = csv.reader(f)
            rows = list(reader)
        assert rows[0] == [
            "Profile ID",
            "Name",
            "Type",
            "Start Time",
            "End Time",
            "Duration",
            "Status",
            "Parent ID",
            "Error",
        ]
        assert len(rows) == 2
        assert rows[1][1] == "agent_test"

    def test_export_unsupported_format(self, tmp_path):
        profiler = PerformanceProfiler()
        with pytest.raises(ValueError, match="Unsupported"):
            profiler.export_data(str(tmp_path / "out.xml"), format="xml")

    def test_export_creates_parent_dirs(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output = str(tmp_path / "subdir" / "nested" / "perf.json")
        result = profiler.export_data(output, format="json")
        assert Path(result).exists()

    def test_clear(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        profiler.clear()
        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert len(profiler.profile_stack) == 0

    def test_get_active_profiles(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("running", ProfileType.AGENT)
        active = profiler.get_active_profiles()
        assert len(active) == 1
        assert active[0].profile_id == pid

    def test_get_active_profiles_empty(self):
        profiler = PerformanceProfiler()
        active = profiler.get_active_profiles()
        assert len(active) == 0

    def test_end_profile_stack_mismatch(self):
        profiler = PerformanceProfiler()
        pid1 = profiler.start_profile("test1", ProfileType.AGENT)
        pid2 = profiler.start_profile("test2", ProfileType.AGENT)
        profiler.end_profile(pid2)
        assert pid1 in profiler.profile_stack

    def test_end_profile_removes_from_active(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("my_test", ProfileType.AGENT)
        assert "my_test" in profiler.active_profiles
        profiler.end_profile(pid)
        assert "my_test" not in profiler.active_profiles

    def test_end_profile_active_name_mismatch(self):
        profiler = PerformanceProfiler()
        profiler.start_profile("first", ProfileType.AGENT)
        profiler.start_profile("first", ProfileType.AGENT)
        profiler.profiles[profiler.profile_stack[0]].name = "renamed"
        pid = profiler.profile_stack[0]
        profiler.end_profile(pid)
        assert "first" in profiler.active_profiles


class TestProfilingContext:
    def test_successful_context(self):
        profiler = PerformanceProfiler()
        with ProfilingContext(profiler, "ctx_test", ProfileType.AGENT):
            pass
        profiles = profiler.get_profiles_by_name("ctx_test")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.COMPLETED

    def test_context_with_error(self):
        profiler = PerformanceProfiler()
        with pytest.raises(ValueError):
            with ProfilingContext(profiler, "ctx_err", ProfileType.AGENT):
                raise ValueError("test error")
        profiles = profiler.get_profiles_by_name("ctx_err")
        assert len(profiles) == 1
        assert profiles[0].status == ExecutionStatus.FAILED
        assert "test error" in profiles[0].error

    def test_context_with_metadata(self):
        profiler = PerformanceProfiler()
        with ProfilingContext(profiler, "ctx_meta", ProfileType.AGENT, metadata={"key": "val"}):
            pass
        profiles = profiler.get_profiles_by_name("ctx_meta")
        assert profiles[0].metadata == {"key": "val"}

    def test_context_returns_self(self):
        profiler = PerformanceProfiler()
        with ProfilingContext(profiler, "ctx", ProfileType.AGENT) as ctx:
            assert ctx.profile_id is not None


class TestProfileFunction:
    def test_decorator_success(self):
        @profile_function(name="my_func", profile_type=ProfileType.CUSTOM)
        def my_func():
            return 42

        result = my_func()
        assert result == 42

    def test_decorator_error(self):
        @profile_function(name="fail_func", profile_type=ProfileType.CUSTOM)
        def fail_func():
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError, match="boom"):
            fail_func()

    def test_decorator_default_name(self):
        @profile_function()
        def some_function():
            return "ok"

        result = some_function()
        assert result == "ok"

    def test_decorator_custom_profiler(self):
        profiler = PerformanceProfiler()
        import core.performance_profiler as mod

        old = mod._global_profiler
        mod._global_profiler = None

        @profile_function(profiler=profiler)
        def test_func():
            return "val"

        result = test_func()
        assert result == "val"
        assert len(profiler.profiles) == 1
        mod._global_profiler = old

    def test_decorator_uses_function_name(self):
        profiler = PerformanceProfiler()

        @profile_function(profiler=profiler, profile_type=ProfileType.CUSTOM)
        def named_function():
            return 1

        named_function()
        profiles = profiler.get_profiles_by_name("named_function")
        assert len(profiles) == 1

    def test_decorator_auto_profiler(self):
        import core.performance_profiler as mod

        old = mod._global_profiler
        mod._global_profiler = None

        @profile_function(profile_type=ProfileType.CUSTOM)
        def auto_func():
            return "auto"

        result = auto_func()
        assert result == "auto"
        mod._global_profiler = old


class TestGetProfiler:
    def test_get_profiler(self):
        import core.performance_profiler as mod

        mod._global_profiler = None
        profiler = get_profiler()
        assert isinstance(profiler, PerformanceProfiler)
        mod._global_profiler = None

    def test_get_profiler_cached(self):
        p1 = get_profiler()
        p2 = get_profiler()
        assert p1 is p2

    def test_get_profiler_creates_new(self):
        import core.performance_profiler as mod

        mod._global_profiler = None
        profiler = get_profiler()
        assert profiler is not None
        assert mod._global_profiler is profiler
        mod._global_profiler = None


class TestProfilerExport:
    """Test export_data with various formats and edge cases."""

    def test_export_unsupported_format(self):
        profiler = PerformanceProfiler()
        profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(list(profiler.profiles.keys())[0])
        with pytest.raises(ValueError, match="Unsupported export format"):
            profiler.export_data("/tmp/test.txt", format="xml")

    def test_export_json_with_type_filter(self, tmp_path):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        output_path = tmp_path / "export.json"
        result = profiler.export_data(output_path, format="json", profile_type=ProfileType.AGENT)
        assert Path(result).exists()

    def test_export_csv_empty_profiles(self, tmp_path):
        profiler = PerformanceProfiler()
        output_path = tmp_path / "empty.csv"
        result = profiler.export_data(output_path, format="csv")
        assert Path(result).exists()

    def test_export_json_creates_parent_dirs(self, tmp_path):
        profiler = PerformanceProfiler()
        output_path = tmp_path / "nested" / "dir" / "export.json"
        result = profiler.export_data(output_path, format="json")
        assert Path(result).exists()


class TestProfilingContextManager:
    """Test ProfilingContext context manager."""

    def test_context_manager_success(self):
        profiler = PerformanceProfiler()
        with ProfilingContext(profiler, "test", ProfileType.AGENT):
            pass
        assert len(profiler.profiles) == 1

    def test_context_manager_with_exception(self):
        profiler = PerformanceProfiler()
        with pytest.raises(RuntimeError):
            with ProfilingContext(profiler, "test", ProfileType.AGENT):
                raise RuntimeError("test error")
        profile = list(profiler.profiles.values())[0]
        assert profile.status == ExecutionStatus.FAILED
        assert profile.error is not None

    def test_context_manager_with_metadata(self):
        profiler = PerformanceProfiler()
        with ProfilingContext(profiler, "test", ProfileType.AGENT, metadata={"key": "val"}):
            pass
        profile = list(profiler.profiles.values())[0]
        assert profile.metadata.get("key") == "val"


class TestProfilerReset:
    """Test reset method."""

    def test_reset_clears_all(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        profiler.end_profile(pid)
        profiler.clear()
        assert len(profiler.profiles) == 0
        assert len(profiler.active_profiles) == 0
        assert len(profiler.profile_stack) == 0


class TestGetActiveProfiles:
    """Test get_active_profiles method."""

    def test_get_active_profiles_empty(self):
        profiler = PerformanceProfiler()
        assert profiler.get_active_profiles() == []

    def test_get_active_profiles_with_running(self):
        profiler = PerformanceProfiler()
        pid = profiler.start_profile("test", ProfileType.AGENT)
        active = profiler.get_active_profiles()
        assert len(active) == 1
        assert active[0].profile_id == pid
