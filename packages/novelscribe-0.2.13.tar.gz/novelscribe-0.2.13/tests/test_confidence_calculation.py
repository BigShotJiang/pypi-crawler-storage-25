"""Unit tests for confidence_calculator.py — factor-based confidence scoring."""

from core.checkpoint_proposal import ConfidenceBreakdown, PlanContent
from core.confidence_calculator import (
    ConfidenceCalculator,
    ConfidenceFactorDetail,
    ConfidenceResult,
    create_confidence_calculator,
)


def _plan(**overrides) -> PlanContent:
    defaults = {"title": "Test Plan"}
    defaults.update(overrides)
    return PlanContent(**defaults)


class TestConfidenceCalculatorBasic:
    def test_calculate_returns_confidence_breakdown(self):
        calc = ConfidenceCalculator()
        plan = _plan(
            pov="Alice",
            scenes=[{"desc": "s1"}],
            pacing="moderate",
            foreshadowing="hint",
            word_estimate=3000,
        )
        result = calc.calculate(plan, "outline")
        assert isinstance(result, ConfidenceBreakdown)

    def test_calculate_detailed_returns_result(self):
        calc = ConfidenceCalculator()
        plan = _plan(pov="Alice")
        result = calc.calculate_detailed(plan, "outline")
        assert isinstance(result, ConfidenceResult)
        assert len(result.factors) == 5
        assert 0.0 <= result.total <= 1.0

    def test_result_breakdown_compatibility(self):
        calc = ConfidenceCalculator()
        plan = _plan(
            pov="Alice",
            scenes=[{"desc": "s1"}],
            pacing="fast",
            foreshadowing="x",
            word_estimate=5000,
        )
        detailed = calc.calculate_detailed(plan, "outline")
        breakdown = detailed.breakdown
        assert isinstance(breakdown, ConfidenceBreakdown)
        assert abs(breakdown.total - detailed.total) < 0.01


class TestCoherenceScoring:
    def test_with_multiple_scenes_scores_higher(self):
        calc = ConfidenceCalculator()
        few = _plan(scenes=[{"d": f"s{i}"} for i in range(1)])
        many = _plan(scenes=[{"d": f"s{i}"} for i in range(6)])
        assert calc._score_coherence(many) > calc._score_coherence(few)

    def test_no_scenes_defaults_to_075(self):
        calc = ConfidenceCalculator()
        plan = _plan(scenes=[])
        assert calc._score_coherence(plan) == 0.75

    def test_four_scenes_reaches_cap(self):
        calc = ConfidenceCalculator()
        plan = _plan(scenes=[{"d": f"s{i}"} for i in range(8)])
        assert calc._score_coherence(plan) == 1.0


class TestCharacterScoring:
    def test_with_pov_gets_085(self):
        calc = ConfidenceCalculator()
        plan = _plan(pov="Alice")
        assert calc._score_character(plan) == 0.85

    def test_without_pov_gets_07(self):
        calc = ConfidenceCalculator()
        plan = _plan(pov=None)
        assert calc._score_character(plan) == 0.7


class TestPacingScoring:
    def test_all_pacing_values(self):
        calc = ConfidenceCalculator()
        assert calc._score_pacing(_plan(pacing="slow")) == 0.8
        assert calc._score_pacing(_plan(pacing="moderate")) == 0.9
        assert calc._score_pacing(_plan(pacing="fast")) == 0.85

    def test_unknown_pacing_defaults_to_085(self):
        calc = ConfidenceCalculator()
        assert calc._score_pacing(_plan(pacing="galactic")) == 0.85


class TestOriginalityScoring:
    def test_with_foreshadowing(self):
        calc = ConfidenceCalculator()
        assert calc._score_originality(_plan(foreshadowing="mystery")) == 0.8

    def test_without_foreshadowing(self):
        calc = ConfidenceCalculator()
        assert calc._score_originality(_plan(foreshadowing=None)) == 0.75


class TestCompletenessScoring:
    def test_with_word_estimate(self):
        calc = ConfidenceCalculator()
        plan = _plan(word_estimate=3000)
        assert calc._score_completeness(plan) == 1.0

    def test_no_word_estimate_defaults_to_075(self):
        calc = ConfidenceCalculator()
        plan = _plan(word_estimate=0)
        assert calc._score_completeness(plan) == 0.75


class TestWeightedTotal:
    def test_total_is_weighted_average(self):
        calc = ConfidenceCalculator()
        plan = _plan(
            pov="Alice",
            scenes=[{"d": "s1"}],
            pacing="moderate",
            foreshadowing="x",
            word_estimate=3000,
        )
        breakdown = calc.calculate(plan, "outline")
        expected = (
            min(1.0, 1 / 4 * 0.3 + 0.7) * 0.30 + 0.85 * 0.25 + 0.9 * 0.20 + 0.8 * 0.15 + 1.0 * 0.10
        )
        assert abs(breakdown.total - expected) < 0.001


class TestFactorDetails:
    def test_get_factor_details_returns_five(self):
        calc = ConfidenceCalculator()
        plan = _plan(pov="Alice")
        details = calc.get_factor_details(plan, "outline")
        assert len(details) == 5
        for d in details:
            assert isinstance(d, ConfidenceFactorDetail)
            assert 0.0 <= d.score <= 1.0
            assert d.weight > 0
            assert d.explanation

    def test_factor_names_match(self):
        calc = ConfidenceCalculator()
        plan = _plan()
        details = calc.get_factor_details(plan, "outline")
        names = [d.name for d in details]
        assert names == ["coherence", "character", "pacing", "originality", "completeness"]


class TestFactory:
    def test_create_confidence_calculator(self):
        calc = create_confidence_calculator()
        assert isinstance(calc, ConfidenceCalculator)
