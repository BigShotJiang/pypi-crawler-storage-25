"""
Unit tests for Phase 4.3: Memory Optimization

Tests cover:
- MemoryProfiler
- ContextPruner
- CacheManager enhancements
- ObjectPool
- MemoryMonitor
"""

import time
from datetime import datetime, timezone

import pytest

from core.cache_manager import CacheManager, CacheManagerConfig
from core.context_assembly import ContextBlock
from core.context_compressor import ContextCompressor
from core.context_schema import TokenBudget
from core.memory_monitor import MemoryAction, MemoryMonitor, MemoryThreshold, create_default_monitor
from core.memory_profiler import MemoryProfiler, MemoryProfilerConfig, MemorySnapshot
from core.object_pool import ObjectPool, ObjectPoolConfig, PoolManager
from core.token_estimator import TokenEstimator


class TestMemorySnapshot:
    """Test MemorySnapshot dataclass."""

    def test_create_snapshot(self):
        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=1000.0,
            component_usage={"test": 100.0},
            object_counts={},
            gc_stats={},
            available_memory_mb=8000.0,
            system_memory_mb=16000.0,
        )

        assert snapshot.total_memory_mb == 1000.0
        assert len(snapshot.component_usage) == 1

    def test_snapshot_subtraction(self):
        snapshot1 = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=1000.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=8000.0,
            system_memory_mb=16000.0,
        )

        snapshot2 = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=1200.0,
            component_usage={},
            object_counts={},
            gc_stats={},
            available_memory_mb=8000.0,
            system_memory_mb=16000.0,
        )

        delta = snapshot2 - snapshot1
        assert delta["total_delta_mb"] == 200.0


@pytest.mark.skip(reason="psutil not installed")
class TestMemoryProfiler:
    """Test memory profiling functionality."""

    def test_initialization(self):
        config = MemoryProfilerConfig(enabled=True, snapshot_interval_seconds=30)
        profiler = MemoryProfiler(config)

        assert profiler.config.enabled
        assert len(profiler.snapshots) == 0

    def test_take_snapshot(self):
        profiler = MemoryProfiler()
        snapshot = profiler.take_snapshot()

        assert isinstance(snapshot, MemorySnapshot)
        assert snapshot.total_memory_mb > 0
        assert len(profiler.snapshots) == 1

    def test_memory_report(self):
        profiler = MemoryProfiler()

        for i in range(5):
            profiler.take_snapshot()

        report = profiler.get_memory_report()

        assert "summary" in report
        assert "system" in report
        assert "components" in report
        assert report["summary"]["snapshot_count"] == 5

    def test_identify_leaks(self):
        profiler = MemoryProfiler()

        for i in range(10):
            profiler.take_snapshot()

        leaks = profiler.identify_leaks()

        assert isinstance(leaks, list)

    def test_component_stats(self):
        profiler = MemoryProfiler()

        for i in range(5):
            profiler.take_snapshot()

        stats = profiler.get_component_stats()

        assert isinstance(stats, dict)

    def test_memory_trend(self):
        profiler = MemoryProfiler()

        for i in range(5):
            profiler.take_snapshot()
            time.sleep(0.1)

        trend = profiler.get_memory_trend()

        assert trend in ["increasing", "decreasing", "stable"]


class TestCacheManager:
    """Test enhanced cache manager."""

    def test_initialization(self):
        config = CacheManagerConfig(max_size_mb=10.0, max_entries=50)
        cache = CacheManager(config)

        assert cache.config.max_size_mb == 10.0
        assert len(cache.cache) == 0

    def test_put_and_get(self):
        cache = CacheManager()

        cache.put("key1", "value1")
        result = cache.get("key1")

        assert result == "value1"

    def test_cache_miss(self):
        cache = CacheManager()

        result = cache.get("nonexistent")

        assert result is None

    def test_ttl_expiration(self):
        config = CacheManagerConfig(default_ttl_seconds=1)
        cache = CacheManager(config)

        cache.put("key1", "value1")
        time.sleep(1.1)

        result = cache.get("key1")

        assert result is None

    def test_cache_statistics(self):
        cache = CacheManager()

        cache.put("key1", "value1")
        cache.get("key1")
        cache.get("key2")

        stats = cache.get_statistics()

        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == "50.00%"

    def test_hot_cold_keys(self):
        cache = CacheManager()

        for i in range(20):
            cache.get("hot_key")

        cache.put("hot_key", "value")
        for i in range(15):
            cache.get("hot_key")

        hot_keys = cache.identify_hot_keys()

        assert "hot_key" in hot_keys

    def test_cache_optimization(self):
        cache = CacheManager()

        for i in range(150):
            cache.put(f"key{i}", f"value{i}")

        cache.optimize()

        stats = cache.get_statistics()
        assert stats["entries"] < 150

    def test_entry_info(self):
        cache = CacheManager()

        cache.put("key1", "value1", ttl_seconds=60)
        cache.get("key1")

        info = cache.get_entry_info("key1")

        assert info is not None
        assert info["key"] == "key1"
        assert info["access_count"] == 1

    def test_bulk_invalidate(self):
        cache = CacheManager()

        cache.put("test:1", "value1")
        cache.put("test:2", "value2")
        cache.put("other:1", "value3")

        cache.bulk_invalidate("test:.*")

        assert cache.get("test:1") is None
        assert cache.get("test:2") is None
        assert cache.get("other:1") == "value3"


@pytest.mark.skip(reason="psutil not installed")
class TestObjectPool:
    """Test object pooling."""

    def test_string_builder_pool(self):
        from core.object_pool import StringBuilderPool

        pool = StringBuilderPool()
        builder = pool.acquire()

        builder.append("Hello")
        builder.append(" ")
        builder.append("World")

        result = builder.build()

        assert result == "Hello World"

        pool.release(builder)

    def test_object_pool_acquire_release(self):
        pool = ObjectPool(lambda: {"data": "test"})

        obj1 = pool.acquire()
        obj2 = pool.acquire()

        assert obj1 is not None
        assert obj2 is not None

        pool.release(obj1)
        pool.release(obj2)

    def test_pool_statistics(self):
        pool = ObjectPool(lambda: [])

        for i in range(10):
            obj = pool.acquire()
            pool.release(obj)

        stats = pool.get_stats()

        assert stats["total_acquired"] == 10
        assert stats["total_released"] == 10

    def test_pool_optimization(self):
        config = ObjectPoolConfig(initial_size=20, max_size=50, shrink_threshold=0.5)
        pool = ObjectPool(lambda: [], config)

        for i in range(30):
            obj = pool.acquire()
            pool.release(obj)

        pool.optimize()

        stats = pool.get_stats()
        assert stats["current_size"] < 30

    def test_pool_manager(self):
        manager = PoolManager()

        pool1 = ObjectPool(lambda: [])
        pool2 = ObjectPool(lambda: {})

        manager.register_pool("list_pool", pool1)
        manager.register_pool("dict_pool", pool2)

        retrieved_pool = manager.get_pool("list_pool")

        assert retrieved_pool == pool1


@pytest.mark.skip(reason="psutil not installed")
class TestMemoryMonitor:
    """Test memory monitoring."""

    def test_initialization(self):
        thresholds = [
            MemoryThreshold(
                name="test", warning_mb=1000.0, critical_mb=2000.0, action=MemoryAction.LOG
            )
        ]

        monitor = MemoryMonitor(thresholds)

        assert len(monitor.thresholds) == 1

    def test_threshold_check(self):
        threshold = MemoryThreshold(
            name="test", warning_mb=1000.0, critical_mb=2000.0, action=MemoryAction.LOG
        )

        assert threshold.check(1500.0) == "warning"
        assert threshold.check(2500.0) == "critical"
        assert threshold.check(500.0) is None

    def test_memory_monitoring(self):
        thresholds = [
            MemoryThreshold(
                name="test", warning_mb=100.0, critical_mb=200.0, action=MemoryAction.LOG
            )
        ]

        monitor = MemoryMonitor(thresholds)
        monitor.start_monitoring()

        time.sleep(0.5)

        monitor.stop_monitoring()

        assert not monitor.monitoring

    def test_status_report(self):
        thresholds = [
            MemoryThreshold(
                name="test", warning_mb=1000.0, critical_mb=2000.0, action=MemoryAction.LOG
            )
        ]

        monitor = MemoryMonitor(thresholds)
        report = monitor.get_status_report()

        assert "monitoring" in report
        assert "trend" in report
        assert "thresholds" in report

    def test_default_monitor(self):
        monitor = create_default_monitor()

        assert len(monitor.thresholds) == 4
        assert not monitor.monitoring

    def test_triggered_actions(self):
        thresholds = [
            MemoryThreshold(name="test", warning_mb=0.1, critical_mb=0.2, action=MemoryAction.LOG)
        ]

        monitor = MemoryMonitor(thresholds)
        monitor.check_memory()

        triggered = monitor.get_triggered_actions()

        assert len(triggered) > 0


@pytest.mark.skip(reason="psutil not installed")
class TestIntegration:
    """Integration tests for memory optimization."""

    def test_full_memory_optimization_workflow(self):
        """Test complete memory optimization workflow."""
        profiler = MemoryProfiler()
        compressor = ContextCompressor()
        cache = CacheManager()

        large_context = "Test content. " * 10000

        profiler.take_snapshot()

        block = ContextBlock(
            source="chapter",
            priority=1,
            content=large_context,
            token_count=TokenEstimator.estimate_tokens(large_context),
            compressible=True,
        )
        budget = TokenBudget.create(total_limit=2000, reserved_output=1500)
        compression_result = compressor.compress([block], budget)

        cache.put("test_context", compression_result.context_str)

        retrieved = cache.get("test_context")

        assert retrieved is not None
        assert len(retrieved) < len(large_context)

        snapshot2 = profiler.take_snapshot()

        assert snapshot2.total_memory_mb >= 0

    def test_memory_monitor_with_actions(self):
        """Test memory monitor triggering actions."""
        thresholds = [
            MemoryThreshold(
                name="prune_test", warning_mb=0.1, critical_mb=0.2, action=MemoryAction.PRUNE
            )
        ]

        monitor = MemoryMonitor(thresholds)

        monitor.check_memory()

        triggered = monitor.get_triggered_actions()

        assert len(triggered) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
