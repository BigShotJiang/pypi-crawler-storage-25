"""Comprehensive tests for context cache coverage improvement."""

from core.context_cache import (
    CachedChapterManager,
    CacheEntry,
    CacheStatistics,
    ContextCache,
    ContextCacheConfig,
)


class TestCacheEntry:
    """Test CacheEntry dataclass."""

    def test_create_cache_entry(self):
        """Test creating a cache entry."""
        entry = CacheEntry(
            key="test_key",
            content="test content",
            size_bytes=100,
        )
        assert entry.key == "test_key"
        assert entry.content == "test content"
        assert entry.size_bytes == 100
        assert entry.access_count == 0

    def test_cache_entry_touch(self):
        """Test touching a cache entry."""
        entry = CacheEntry(
            key="test_key",
            content="test content",
            size_bytes=100,
        )
        initial_access = entry.access_count
        initial_accessed = entry.last_accessed

        entry.touch()

        assert entry.access_count == initial_access + 1
        assert entry.last_accessed >= initial_accessed

    def test_cache_entry_with_metadata(self):
        """Test cache entry with metadata."""
        entry = CacheEntry(
            key="test_key",
            content="test content",
            size_bytes=100,
            metadata={"source": "test"},
        )
        assert entry.metadata["source"] == "test"


class TestContextCacheConfig:
    """Test ContextCacheConfig model."""

    def test_default_config(self):
        """Test default configuration."""
        config = ContextCacheConfig()
        assert config.max_size_mb == 100.0
        assert config.max_entries == 100
        assert config.enable_compression is False
        assert config.eviction_policy == "lru"
        assert config.track_access_patterns is True
        assert config.prefetch_enabled is True
        assert config.prefetch_count == 3

    def test_custom_config(self):
        """Test custom configuration."""
        config = ContextCacheConfig(
            max_size_mb=50.0,
            max_entries=50,
            enable_compression=True,
            eviction_policy="lfu",
            track_access_patterns=False,
            prefetch_enabled=False,
            prefetch_count=5,
        )
        assert config.max_size_mb == 50.0
        assert config.max_entries == 50
        assert config.enable_compression is True
        assert config.eviction_policy == "lfu"
        assert config.track_access_patterns is False
        assert config.prefetch_enabled is False
        assert config.prefetch_count == 5


class TestCacheStatistics:
    """Test CacheStatistics class."""

    def test_initialization(self):
        """Test cache statistics initialization."""
        stats = CacheStatistics()
        assert stats.hits == 0
        assert stats.misses == 0
        assert stats.evictions == 0
        assert stats.prefetch_hits == 0
        assert stats.total_bytes_served == 0
        assert stats.total_bytes_loaded == 0

    def test_hit_rate_calculation(self):
        """Test hit rate calculation."""
        stats = CacheStatistics()
        stats.hits = 8
        stats.misses = 2
        assert stats.hit_rate == 0.8

    def test_hit_rate_zero_total(self):
        """Test hit rate with no requests."""
        stats = CacheStatistics()
        assert stats.hit_rate == 0.0

    def test_miss_rate_calculation(self):
        """Test miss rate calculation."""
        stats = CacheStatistics()
        stats.hits = 8
        stats.misses = 2
        assert abs(stats.miss_rate - 0.2) < 0.001

    def test_total_requests(self):
        """Test total requests calculation."""
        stats = CacheStatistics()
        stats.hits = 5
        stats.misses = 3
        assert stats.total_requests == 8

    def test_record_hit(self):
        """Test recording a hit."""
        stats = CacheStatistics()
        stats.record_hit(100)
        assert stats.hits == 1
        assert stats.total_bytes_served == 100

    def test_record_miss(self):
        """Test recording a miss."""
        stats = CacheStatistics()
        stats.record_miss()
        assert stats.misses == 1

    def test_record_eviction(self):
        """Test recording an eviction."""
        stats = CacheStatistics()
        stats.record_eviction()
        assert stats.evictions == 1

    def test_record_prefetch_hit(self):
        """Test recording a prefetch hit."""
        stats = CacheStatistics()
        stats.record_prefetch_hit()
        assert stats.prefetch_hits == 1

    def test_record_bytes_loaded(self):
        """Test recording bytes loaded."""
        stats = CacheStatistics()
        stats.record_bytes_loaded(1000)
        assert stats.total_bytes_loaded == 1000

    def test_get_summary(self):
        """Test getting statistics summary."""
        stats = CacheStatistics()
        stats.hits = 8
        stats.misses = 2
        stats.evictions = 1
        stats.total_bytes_served = 800
        stats.total_bytes_loaded = 1000

        summary = stats.get_summary()
        assert summary["total_requests"] == 10
        assert summary["hits"] == 8
        assert summary["misses"] == 2
        assert summary["hit_rate"] == "80.00%"
        assert summary["evictions"] == 1
        assert summary["bytes_saved"] == -200


class TestContextCache:
    """Test ContextCache class."""

    def test_initialization(self):
        """Test cache initialization."""
        cache = ContextCache()
        assert cache.config is not None
        assert isinstance(cache.cache, dict)
        assert cache.current_size_bytes == 0
        assert cache.stats is not None

    def test_initialization_with_config(self):
        """Test cache initialization with custom config."""
        config = ContextCacheConfig(max_size_mb=50.0, max_entries=50)
        cache = ContextCache(config)
        assert cache.config.max_size_mb == 50.0
        assert cache.config.max_entries == 50

    def test_calculate_size_string(self):
        """Test size calculation for string."""
        cache = ContextCache()
        size = cache._calculate_size("hello")
        assert size == 5

    def test_calculate_size_dict(self):
        """Test size calculation for dict."""
        cache = ContextCache()
        size = cache._calculate_size({"key": "value"})
        assert size > 0

    def test_calculate_size_list(self):
        """Test size calculation for list."""
        cache = ContextCache()
        size = cache._calculate_size(["a", "b", "c"])
        assert size > 0

    def test_generate_key(self):
        """Test key generation."""
        cache = ContextCache()
        key1 = cache._generate_key("chapter", "project", 1)
        key2 = cache._generate_key("chapter", "project", 2)
        assert key1 != key2
        assert len(key1) == 32

    def test_put_and_get(self):
        """Test putting and getting from cache."""
        cache = ContextCache()
        cache.put("key1", "value1")
        value = cache.get("key1")
        assert value == "value1"

    def test_get_nonexistent(self):
        """Test getting non-existent key."""
        cache = ContextCache()
        value = cache.get("nonexistent")
        assert value is None
        assert cache.stats.misses == 1

    def test_put_updates_existing(self):
        """Test updating existing key."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.put("key1", "value2")
        value = cache.get("key1")
        assert value == "value2"

    def test_invalidate(self):
        """Test invalidating cache entry."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.invalidate("key1")
        value = cache.get("key1")
        assert value is None

    def test_clear(self):
        """Test clearing cache."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.put("key2", "value2")
        cache.clear()
        assert len(cache.cache) == 0
        assert cache.current_size_bytes == 0

    def test_lru_eviction(self):
        """Test LRU eviction."""
        config = ContextCacheConfig(max_size_mb=0.000001, max_entries=2)
        cache = ContextCache(config)

        cache.put("key1", "a" * 1000)
        cache.put("key2", "b" * 1000)
        cache.get("key1")
        cache.put("key3", "c" * 1000)

        assert cache.get("key1") is not None
        assert cache.get("key2") is None

    def test_get_chapter(self):
        """Test getting cached chapter."""
        cache = ContextCache()
        cache.put_chapter("project1", 1, "chapter content")

        content = cache.get_chapter("project1", 1)
        assert content == "chapter content"

    def test_put_chapter(self):
        """Test putting chapter in cache."""
        cache = ContextCache()
        cache.put_chapter("project1", 1, "chapter content")

        content = cache.get_chapter("project1", 1)
        assert content == "chapter content"

    def test_get_page(self):
        """Test getting cached page."""
        cache = ContextCache()
        cache.put_page("project1", 1, 1, "page content")

        content = cache.get_page("project1", 1, 1)
        assert content == "page content"

    def test_put_page(self):
        """Test putting page in cache."""
        cache = ContextCache()
        cache.put_page("project1", 1, 1, "page content")

        content = cache.get_page("project1", 1, 1)
        assert content == "page content"

    def test_get_prefetch_candidates_enabled(self):
        """Test getting prefetch candidates with prefetch enabled."""
        config = ContextCacheConfig(prefetch_enabled=True, prefetch_count=3)
        cache = ContextCache(config)

        candidates = cache.get_prefetch_candidates("project1", 5)
        assert candidates == [6, 7, 8]

    def test_get_prefetch_candidates_disabled(self):
        """Test getting prefetch candidates with prefetch disabled."""
        config = ContextCacheConfig(prefetch_enabled=False)
        cache = ContextCache(config)

        candidates = cache.get_prefetch_candidates("project1", 5)
        assert candidates == []

    def test_get_statistics(self):
        """Test getting cache statistics."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.get("key1")
        cache.get("key1")
        cache.get("nonexistent")

        stats = cache.get_statistics()
        assert stats["current_entries"] == 1
        assert stats["current_size_bytes"] > 0
        assert stats["hits"] == 2
        assert stats["misses"] == 1

    def test_track_access_patterns_disabled(self):
        """Test access tracking when disabled."""
        config = ContextCacheConfig(track_access_patterns=False)
        cache = ContextCache(config)

        cache.put_chapter("project1", 1, "content")
        cache.get_chapter("project1", 1)

        assert len(cache.access_patterns) == 0

    def test_optimize(self):
        """Test cache optimization."""
        config = ContextCacheConfig(max_size_mb=0.00001)
        cache = ContextCache(config)

        for i in range(10):
            cache.put(f"key{i}", "x" * 1000)

        initial_size = cache.current_size_bytes
        cache.optimize()
        assert cache.current_size_bytes < initial_size


class TestCachedChapterManager:
    """Test CachedChapterManager class."""

    def test_initialization(self):
        """Test manager initialization."""
        manager = CachedChapterManager()
        assert manager.cache is not None

    def test_initialization_with_cache(self):
        """Test manager initialization with cache."""
        cache = ContextCache()
        manager = CachedChapterManager(cache)
        assert manager.cache is cache

    def test_get_chapter_not_cached(self):
        """Test getting chapter not in cache."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            return f"Chapter {chapter_num} content"

        content = manager.get_chapter("project1", 1, loader)
        assert content == "Chapter 1 content"

        cached = manager.cache.get_chapter("project1", 1)
        assert cached == "Chapter 1 content"

    def test_get_chapter_cached(self):
        """Test getting cached chapter."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            return f"Chapter {chapter_num} content"

        manager.cache.put_chapter("project1", 1, "cached content")
        content = manager.get_chapter("project1", 1, loader)
        assert content == "cached content"

    def test_get_chapter_no_loader(self):
        """Test getting chapter without loader."""
        manager = CachedChapterManager()
        content = manager.get_chapter("project1", 1)
        assert content is None


class TestContextCacheEvictionEdgeCases:
    """Test eviction edge cases."""

    def test_evict_lru_empty_cache(self):
        """Test _evict_lru returns None when cache is empty (line 178)."""
        cache = ContextCache()
        result = cache._evict_lru()
        assert result is None


class TestContextCacheTrackAccess:
    """Test access pattern tracking internals."""

    def test_track_access_new_key(self):
        """Test tracking access for a new key (lines 212-215)."""
        cache = ContextCache()
        key = cache._generate_key("chapter", "project", 1)
        cache._track_access(key, 1)
        assert key in cache.access_patterns
        assert cache.access_patterns[key] == [1]

    def test_track_access_pruning(self):
        """Test access pattern pruning past 100 entries (line 218)."""
        cache = ContextCache()
        key = cache._generate_key("chapter", "project", 1)
        for i in range(101):
            cache._track_access(key, i)
        assert len(cache.access_patterns[key]) == 50
        cache._track_access(key, 999)
        assert len(cache.access_patterns[key]) == 51


class TestContextCachePrefetchEdgeCases:
    """Test prefetch candidates with tracked access patterns."""

    def test_prefetch_candidates_with_tracked_key(self):
        """Test prefetch when key is in access_patterns (line 378)."""
        config = ContextCacheConfig(prefetch_enabled=True, prefetch_count=3)
        cache = ContextCache(config=config)
        cache.put_chapter("project1", 5, "content")
        cache.get_chapter("project1", 5)
        candidates = cache.get_prefetch_candidates("project1", 5)
        assert candidates == [6, 7, 8]


class TestCachedChapterManagerPrefetch:
    """Test CachedChapterManager prefetch_chapters (lines 464-475)."""

    def test_prefetch_chapters(self):
        """Test prefetching loads next chapters."""
        manager = CachedChapterManager()
        loaded = []

        def loader(chapter_num):
            loaded.append(chapter_num)
            return f"Chapter {chapter_num}"

        manager.prefetch_chapters("project1", 1, loader)
        assert 2 in loaded
        assert manager.cache.get_chapter("project1", 2) is not None

    def test_prefetch_chapters_with_failure(self):
        """Test prefetching handles loader exceptions (line 474)."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            if chapter_num == 3:
                raise ValueError("Load failed")
            return f"Chapter {chapter_num}"

        manager.prefetch_chapters("project1", 1, loader)
        assert manager.cache.get_chapter("project1", 2) is not None

    def test_prefetch_chapters_already_cached(self):
        """Test prefetching skips already cached chapters."""
        manager = CachedChapterManager()
        manager.cache.put_chapter("project1", 2, "already cached")

        def loader(chapter_num):
            return f"Chapter {chapter_num}"

        manager.prefetch_chapters("project1", 1, loader)
        assert manager.cache.get_chapter("project1", 2) == "already cached"

    def test_prefetch_chapters_loader_returns_none(self):
        """Test prefetching when loader returns None (line 470)."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            return None

        manager.prefetch_chapters("project1", 1, loader)
        assert manager.cache.get_chapter("project1", 2) is None


class TestCachedChapterManagerInvalidateProject:
    """Test CachedChapterManager invalidate_project (lines 495-502)."""

    def test_invalidate_project(self):
        """Test invalidating all entries for a project."""
        manager = CachedChapterManager()
        manager.cache.put_chapter("project1", 1, "chapter1")
        manager.cache.put_chapter("project1", 2, "chapter2")
        manager.cache.put_chapter("project2", 1, "other")
        manager.invalidate_project("project1")
        assert manager.cache.get_chapter("project2", 1) == "other"


class TestCachedChapterManagerGetStatistics:
    """Test CachedChapterManager get_statistics (line 511)."""

    def test_get_statistics(self):
        """Test getting statistics through manager."""
        manager = CachedChapterManager()
        manager.cache.put("key1", "value1")
        stats = manager.get_statistics()
        assert "current_entries" in stats
        assert stats["current_entries"] == 1


class TestCachedChapterManagerLoaderEdge:
    """Test CachedChapterManager loader edge cases."""

    def test_loader_returns_none(self):
        """Test get_chapter when loader returns None (line 445 False branch)."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            return None

        content = manager.get_chapter("project1", 1, loader)
        assert content is None

    def test_loader_caches_content(self):
        """Test get_chapter loads and caches content (lines 445-453)."""
        manager = CachedChapterManager()

        def loader(chapter_num):
            return f"Chapter {chapter_num} content"

        content = manager.get_chapter("project1", 1, loader)
        assert content == "Chapter 1 content"
        assert manager.cache.get_chapter("project1", 1) == "Chapter 1 content"


class TestContextCacheCalculateSizeOther:
    """Test _calculate_size for non-standard types."""

    def test_calculate_size_int(self):
        """Test size calculation for int (line 155)."""
        cache = ContextCache()
        size = cache._calculate_size(42)
        assert size == len(str(42).encode("utf-8"))

    def test_invalidate_missing_key(self):
        """Test invalidate when key is not in cache (line 274 False)."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache.invalidate("nonexistent")
        assert "key1" in cache.cache
        assert cache.current_size_bytes > 0


class TestCachedChapterManagerInvalidateChapter:
    """Test invalidate_chapter method (lines 485-486)."""

    def test_invalidate_chapter(self):
        """Test invalidating a specific chapter."""
        manager = CachedChapterManager()
        manager.cache.put_chapter("project1", 1, "content")
        assert manager.cache.get_chapter("project1", 1) is not None
        manager.invalidate_chapter("project1", 1)
        assert manager.cache.get_chapter("project1", 1) is None


class TestCachedChapterManagerInvalidateProjectMatching:
    """Test invalidate_project with matching raw keys (line 502)."""

    def test_invalidate_project_with_matching_keys(self):
        """Test invalidate_project removes matching keys."""
        from core.context_cache import CacheEntry

        manager = CachedChapterManager()
        manager.cache.cache["chapter:project1:1"] = CacheEntry(
            key="chapter:project1:1",
            content="ch1",
            size_bytes=10,
        )
        manager.cache.cache["page:project1:1:1"] = CacheEntry(
            key="page:project1:1:1",
            content="p1",
            size_bytes=5,
        )
        manager.cache.cache["chapter:project2:1"] = CacheEntry(
            key="chapter:project2:1",
            content="ch2",
            size_bytes=10,
        )
        manager.invalidate_project("project1")
        assert "chapter:project1:1" not in manager.cache.cache
        assert "page:project1:1:1" not in manager.cache.cache
        assert "chapter:project2:1" in manager.cache.cache


class TestContextCacheExtended:
    """Extended tests for ContextCache to improve coverage."""

    def test_evict_lru_empty_cache(self):
        """Test _evict_lru returns None when cache is empty."""
        cache = ContextCache()
        result = cache._evict_lru()
        assert result is None
        assert cache.current_size_bytes == 0

    def test_track_access_disabled(self):
        """Test _track_access returns early when tracking is disabled."""
        cache = ContextCache()
        cache.config.track_access_patterns = False
        cache.put("key1", "value1")
        assert "key1" not in cache.access_patterns

    def test_track_access_creates_new_list(self):
        """Test _track_access creates new list for new key."""
        cache = ContextCache()
        cache.put("key1", "value1")
        cache._track_access("key1", 1)
        cache._track_access("key1", 2)
        assert len(cache.access_patterns["key1"]) == 2

    def test_track_access_trims_history(self):
        """Test _track_access trims history to 50 entries."""
        cache = ContextCache()
        key = "key1"
        for i in range(120):
            cache.access_patterns[key] = list(range(i))
        cache._track_access(key, 999)
        assert len(cache.access_patterns[key]) == 50

    def test_evict_lru_removes_entry(self):
        """Test _evict_lru properly removes and returns entry."""
        config = ContextCacheConfig(max_size_mb=0.000001, max_entries=10)
        cache = ContextCache(config)
        cache.put("key1", "a" * 1000)
        evicted = cache._evict_lru()
        assert evicted is not None
        assert evicted.key == "key1"
        assert "key1" not in cache.cache

    def test_get_prefetch_candidates_disabled(self):
        """Test get_prefetch_candidates returns empty when disabled."""
        cache = ContextCache()
        cache.config.prefetch_enabled = False
        result = cache.get_prefetch_candidates("proj", 1)
        assert result == []

    def test_get_statistics(self):
        """Test get_statistics returns comprehensive stats."""
        cache = ContextCache()
        cache.put("key1", "value1")
        stats = cache.get_statistics()
        assert "total_requests" in stats
        assert "current_entries" in stats
        assert "current_size_bytes" in stats
        assert stats["current_entries"] == 1

    def test_optimize(self):
        """Test optimize evicts entries to reach target."""
        config = ContextCacheConfig(max_size_mb=0.000001, max_entries=100)
        cache = ContextCache(config)
        cache.put("key1", "a" * 1000)
        cache.put("key2", "b" * 1000)
        cache.optimize()
        assert cache.current_size_bytes < cache.config.max_size_mb * 1024 * 1024

    def test_prefetch_chapters(self):
        """Test prefetch_chapters loads candidate chapters."""
        manager = CachedChapterManager()
        calls = []

        def loader(chapter_num):
            calls.append(chapter_num)
            return f"chapter {chapter_num}"

        manager.prefetch_chapters("proj", 1, loader)
        assert len(calls) > 0

    def test_prefetch_chapters_handles_error(self):
        """Test prefetch_chapters handles loader errors gracefully."""
        manager = CachedChapterManager()

        def failing_loader(chapter_num):
            raise RuntimeError("Loader failed")

        manager.prefetch_chapters("proj", 1, failing_loader)

    def test_get_chapter_with_loader(self):
        """Test get_chapter uses loader when not cached."""
        cache = ContextCache()
        calls = []

        def loader(chapter_num):
            calls.append(chapter_num)
            return f"chapter {chapter_num}"

        manager = CachedChapterManager(cache)
        result = manager.get_chapter("proj", 1, loader)
        assert result == "chapter 1"
        assert 1 in calls
        assert cache.get_chapter("proj", 1) == "chapter 1"

    def test_get_chapter_loader_returns_none(self):
        """Test get_chapter handles loader returning None."""
        cache = ContextCache()

        def none_loader(chapter_num):
            return None

        manager = CachedChapterManager(cache)
        result = manager.get_chapter("proj", 1, none_loader)
        assert result is None

    def test_cached_chapter_manager_statistics(self):
        """Test CachedChapterManager get_statistics."""
        manager = CachedChapterManager()
        manager.cache.put_chapter("proj", 1, "content")
        stats = manager.get_statistics()
        assert "total_requests" in stats
