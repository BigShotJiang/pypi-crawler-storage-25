"""Coverage tests for cli.py — cover new, outline, write, auto, status, version, main()."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from cli import cli, main


@pytest.fixture
def runner():
    return CliRunner()


class TestNewCommand:
    """Cover the `new` command (cli.py lines 117-163)."""

    @patch("cli.create_git_manager")
    @patch("cli.StorageFactory.create")
    @patch("cli.StorageConfig")
    def test_new_creates_project(self, mock_cfg_cls, mock_factory, mock_git, runner):
        mock_storage = MagicMock()
        mock_storage.write_yaml.return_value = None
        mock_factory.return_value = mock_storage
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        mock_gm = MagicMock()
        mock_git.return_value = mock_gm

        with patch.object(Path, "mkdir"):
            result = runner.invoke(
                cli,
                ["new", "testproj", "--provider", "openai", "--model", "gpt-4"],
                obj={"debug": False},
            )
        assert result.exit_code == 0 or "created" in result.output.lower() or result.exit_code == 0

    @patch("cli.create_git_manager", side_effect=OSError("disk full"))
    @patch("cli.StorageFactory.create")
    @patch("cli.StorageConfig")
    def test_new_exception(self, mock_cfg_cls, mock_factory, mock_git, runner):
        mock_storage = MagicMock()
        mock_factory.return_value = mock_storage
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "mkdir"):
            result = runner.invoke(
                cli,
                ["new", "testproj"],
                obj={"debug": False},
            )
        assert result.exit_code == 1

    @patch("cli.create_git_manager", side_effect=RuntimeError("git fail"))
    @patch("cli.StorageFactory.create")
    @patch("cli.StorageConfig")
    def test_new_exception_with_debug(self, mock_cfg_cls, mock_factory, mock_git, runner):
        mock_storage = MagicMock()
        mock_factory.return_value = mock_storage
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "mkdir"):
            result = runner.invoke(
                cli,
                ["new", "testproj"],
                obj={"debug": True},
            )
        assert result.exit_code == 1


class TestOutlineCommand:
    """Cover the `outline` command (cli.py lines 166-212)."""

    @patch("cli.create_git_manager")
    @patch("cli.create_orchestrator")
    @patch("cli.StorageConfig")
    def test_outline_project_not_found(self, mock_cfg_cls, mock_orch, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path="/nonexistent/.novels")

        with patch.object(Path, "exists", return_value=False):
            result = runner.invoke(
                cli,
                ["outline", "missing_proj"],
                obj={"debug": False},
            )
        assert result.exit_code == 1

    @patch("cli.create_git_manager")
    @patch("cli.create_orchestrator")
    @patch("cli.StorageConfig")
    def test_outline_exception(self, mock_cfg_cls, mock_orch, mock_git, runner):
        mock_orch.side_effect = RuntimeError("boom")
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["outline", "testproj"],
                obj={"debug": True},
            )
        assert result.exit_code == 1


class TestWriteCommand:
    """Cover the `write` command (cli.py lines 215-259)."""

    @patch("cli.create_git_manager")
    @patch("cli.create_orchestrator")
    @patch("cli.StorageConfig")
    def test_write_project_not_found(self, mock_cfg_cls, mock_orch, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", return_value=False):
            result = runner.invoke(
                cli,
                ["write", "missing_proj", "-c", "1"],
                obj={"debug": False},
            )
        assert result.exit_code == 1

    @patch("cli.create_git_manager")
    @patch("cli.create_orchestrator")
    @patch("cli.StorageConfig")
    def test_write_exception(self, mock_cfg_cls, mock_orch, mock_git, runner):
        mock_orch.side_effect = RuntimeError("fail")
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["write", "testproj", "-c", "5"],
                obj={"debug": True},
            )
        assert result.exit_code == 1


class TestAutoCommand:
    """Cover the `auto` command (cli.py lines 262-309)."""

    @patch("cli.StorageConfig")
    def test_auto_project_not_found(self, mock_cfg_cls, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", return_value=False):
            result = runner.invoke(
                cli,
                ["auto", "missing_proj"],
                obj={"debug": False},
            )
        assert result.exit_code == 1

    @patch("core.autonomous_executor.AutonomousExecutor")
    @patch("core.autonomous_executor.AutonomousConfig")
    @patch("cli.StorageConfig")
    def test_auto_success(self, mock_cfg_cls, mock_acfg, mock_exec_cls, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        mock_result = MagicMock()
        mock_result.success = True
        mock_result.completed_phases = ["new_novel", "outline"]
        mock_result.error = None
        mock_exec_inst = MagicMock()
        mock_exec_inst.execute.return_value = mock_result
        mock_exec_cls.return_value = mock_exec_inst

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["auto", "testproj", "--chapters", "10"],
                obj={"debug": False},
            )
        assert result.exit_code == 0 or "completed" in result.output.lower()

    @patch("core.autonomous_executor.AutonomousExecutor")
    @patch("core.autonomous_executor.AutonomousConfig")
    @patch("cli.StorageConfig")
    def test_auto_failure(self, mock_cfg_cls, mock_acfg, mock_exec_cls, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        mock_result = MagicMock()
        mock_result.success = False
        mock_result.completed_phases = []
        mock_result.error = "something broke"
        mock_exec_inst = MagicMock()
        mock_exec_inst.execute.return_value = mock_result
        mock_exec_cls.return_value = mock_exec_inst

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["auto", "testproj"],
                obj={"debug": False},
            )
        assert result.exit_code in [0, 1]

    @patch("cli.StorageConfig")
    def test_auto_exception(self, mock_cfg_cls, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", side_effect=RuntimeError("boom")):
            result = runner.invoke(
                cli,
                ["auto", "testproj"],
                obj={"debug": True},
            )
        assert result.exit_code == 1


class TestStatusCommand:
    """Cover the `status` command (cli.py lines 312-349)."""

    @patch("cli.create_git_manager")
    @patch("cli.StorageConfig")
    def test_status_project_not_found(self, mock_cfg_cls, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        with patch.object(Path, "exists", return_value=False):
            result = runner.invoke(
                cli,
                ["status", "missing_proj"],
                obj={"debug": False},
            )
        assert result.exit_code == 1

    @patch("cli.create_git_manager")
    @patch("cli.StorageConfig")
    def test_status_with_git_repo(self, mock_cfg_cls, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        mock_gm = MagicMock()
        mock_gm.status.return_value = {
            "is_repository": True,
            "current_branch": "main",
            "current_commit": "abc123",
            "has_changes": True,
            "changed_files": ["chapter1.md", "outline.md"],
        }
        mock_gm.get_tags.return_value = [{"name": "v0.1.0"}, {"name": "v0.2.0"}]
        mock_git.return_value = mock_gm

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["status", "testproj"],
                obj={"debug": False},
            )
        assert result.exit_code == 0

    @patch("cli.create_git_manager")
    @patch("cli.StorageConfig")
    def test_status_no_changes(self, mock_cfg_cls, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")

        mock_gm = MagicMock()
        mock_gm.status.return_value = {
            "is_repository": True,
            "current_branch": "main",
            "current_commit": "abc123",
            "has_changes": False,
            "changed_files": [],
        }
        mock_gm.get_tags.return_value = []
        mock_git.return_value = mock_gm

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["status", "testproj"],
                obj={"debug": False},
            )
        assert result.exit_code == 0

    @patch("cli.create_git_manager")
    @patch("cli.StorageConfig")
    def test_status_exception(self, mock_cfg_cls, mock_git, runner):
        mock_cfg_cls.return_value = MagicMock(base_path=".novels")
        mock_git.side_effect = RuntimeError("git error")

        with patch.object(Path, "exists", return_value=True):
            result = runner.invoke(
                cli,
                ["status", "testproj"],
                obj={"debug": False},
            )
        assert result.exit_code == 1


class TestVersionCommand:
    """Cover the `version` command (cli.py lines 352-366)."""

    def test_version_output(self, runner):
        result = runner.invoke(cli, ["version", "info"])
        assert result.exit_code == 0
        assert "Novel Writing Harness" in result.output or "scribe" in result.output.lower()


class TestMainFunction:
    """Cover the `main()` entry point (cli.py lines 390-418)."""

    def test_main_success(self):
        with patch("cli.cli") as mock_cli:
            mock_cli.return_value = None
            result = main()
        assert result == 0

    def test_main_usage_error(self):
        from click.exceptions import UsageError

        with patch("cli.cli", side_effect=UsageError("bad usage")):
            result = main()
        assert result == 1

    def test_main_click_exception(self):
        from click.exceptions import ClickException

        with patch("cli.cli", side_effect=ClickException("click error")):
            result = main()
        assert result == 1

    def test_main_keyboard_interrupt(self):
        with patch("cli.cli", side_effect=KeyboardInterrupt()):
            result = main()
        assert result == 130

    def test_main_unexpected_error(self):
        with patch("cli.cli", side_effect=RuntimeError("unexpected")):
            result = main()
        assert result == 1


class TestCliUpdateCheck:
    """Cover the update check logic in the cli() group callback (lines 108-114)."""

    def test_no_update_check_skips(self, runner):
        result = runner.invoke(cli, ["--no-update-check", "--help"])
        assert result.exit_code == 0

    def test_update_check_exception_suppressed(self, runner):
        with patch("core.version.notify_if_update_available", side_effect=RuntimeError("net err")):
            result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
