"""Tests for checkpoint system modules."""

import pytest

from core.checkpoint_proposal import (
    Alternative,
    CheckpointDecision,
    CheckpointProposal,
    CheckpointResponse,
    ConfidenceBreakdown,
    DecisionType,
    PlanContent,
)
from core.checkpoint_scheduler import (
    CheckpointDefinition,
    CheckpointSchedule,
    create_checkpoint_schedule,
)


class TestDecisionType:
    """Test DecisionType enum."""

    def test_decision_types(self):
        assert DecisionType.APPROVE.value == "approve"
        assert DecisionType.MODIFY.value == "modify"
        assert DecisionType.REJECT.value == "reject"
        assert DecisionType.GUIDANCE.value == "guidance"
        assert DecisionType.ASK.value == "ask"


class TestPlanContent:
    """Test PlanContent model."""

    def test_plan_content_creation(self):
        plan = PlanContent(
            title="Test Plan",
            pov="John",
            word_estimate=5000,
            scenes=[{"id": 1, "description": "Opening scene"}],
            foreshadowing="The mysterious stranger",
            pacing="moderate",
        )
        assert plan.title == "Test Plan"
        assert plan.pov == "John"
        assert plan.word_estimate == 5000
        assert len(plan.scenes) == 1
        assert plan.foreshadowing == "The mysterious stranger"

    def test_plan_content_defaults(self):
        plan = PlanContent(title="Minimal Plan")
        assert plan.pov is None
        assert plan.word_estimate == 0
        assert plan.pacing == "moderate"
        assert plan.scenes == []

    def test_plan_content_with_metadata(self):
        plan = PlanContent(
            title="Plan with Metadata",
            metadata={"phase": "outline_phase", "chapter": 5},
        )
        assert plan.metadata["phase"] == "outline_phase"
        assert plan.metadata["chapter"] == 5


class TestConfidenceBreakdown:
    """Test ConfidenceBreakdown model."""

    def test_confidence_breakdown_creation(self):
        breakdown = ConfidenceBreakdown(
            coherence=0.9,
            character=0.85,
            pacing=0.8,
            originality=0.75,
            completeness=0.9,
        )
        assert breakdown.coherence == 0.9
        assert breakdown.character == 0.85
        assert breakdown.total == pytest.approx(0.84, rel=0.01)

    def test_confidence_breakdown_low_values(self):
        breakdown = ConfidenceBreakdown(
            coherence=0.5,
            character=0.5,
            pacing=0.5,
            originality=0.5,
            completeness=0.5,
        )
        assert breakdown.total == pytest.approx(0.5, rel=0.01)


class TestAlternative:
    """Test Alternative model."""

    def test_alternative_creation(self):
        alt = Alternative(
            option_id="A",
            plan=PlanContent(title="Alternative A"),
            confidence=0.85,
            tradeoff_explanation="More action, less character development",
            rejection_reasons=["Too violent", "Lacks romance"],
        )
        assert alt.option_id == "A"
        assert alt.plan.title == "Alternative A"
        assert alt.confidence == 0.85

    def test_alternative_required_fields(self):
        alt = Alternative(
            option_id="B",
            plan=PlanContent(title="Alt B"),
            confidence=0.75,
            tradeoff_explanation="Less action, more character development",
        )
        assert alt.confidence == 0.75
        assert alt.tradeoff_explanation == "Less action, more character development"
        assert alt.rejection_reasons == []


class TestCheckpointProposal:
    """Test CheckpointProposal model."""

    def test_proposal_creation(self):
        plan = PlanContent(title="Test Proposal")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="new_novel",
            plan=plan,
            confidence=0.85,
            reasoning="Strong plot structure",
            reasoning_trace=["Step 1", "Step 2"],
        )
        assert proposal.checkpoint_id == "cp_01"
        assert proposal.phase == "new_novel"
        assert proposal.plan.title == "Test Proposal"
        assert proposal.confidence == 0.85

    def test_proposal_with_alternatives(self):
        plan = PlanContent(title="Main Plan")
        alt_a = Alternative(
            option_id="A",
            plan=PlanContent(title="Alt A"),
            confidence=0.8,
            tradeoff_explanation="More action",
        )
        alt_b = Alternative(
            option_id="B",
            plan=PlanContent(title="Alt B"),
            confidence=0.7,
            tradeoff_explanation="More character",
        )

        proposal = CheckpointProposal(
            checkpoint_id="cp_02",
            phase="outline_phase",
            plan=plan,
            confidence=0.8,
            reasoning="Good pacing",
            alternatives=[alt_a, alt_b],
        )
        assert len(proposal.alternatives) == 2

    def test_proposal_defaults(self):
        plan = PlanContent(title="Minimal")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.5,
            reasoning="Test",
        )
        assert proposal.reasoning_trace == []
        assert proposal.alternatives == []
        assert proposal.confidence_breakdown is None


class TestCheckpointDecision:
    """Test CheckpointDecision model."""

    def test_decision_approve(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.APPROVE,
            checkpoint_id="cp_01",
        )
        assert decision.decision_type == DecisionType.APPROVE

    def test_decision_modify(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.MODIFY,
            checkpoint_id="cp_02",
            modified_content={"key": "value"},
        )
        assert decision.modified_content == {"key": "value"}

    def test_decision_guidance(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.GUIDANCE,
            checkpoint_id="cp_03",
            guidance_text="Add more tension in chapter 3",
        )
        assert decision.guidance_text == "Add more tension in chapter 3"

    def test_decision_ask(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.ASK,
            checkpoint_id="cp_04",
            question="Should the protagonist die?",
        )
        assert decision.question == "Should the protagonist die?"


class TestCheckpointResponse:
    """Test CheckpointResponse model."""

    def test_response_applied(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.APPROVE,
            checkpoint_id="cp_01",
        )
        response = CheckpointResponse(
            decision=decision,
            applied=True,
            adjustments_made=["Adjusted pacing"],
        )
        assert response.decision.decision_type == DecisionType.APPROVE
        assert response.applied is True
        assert "Adjusted pacing" in response.adjustments_made

    def test_response_with_modifications(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.MODIFY,
            checkpoint_id="cp_02",
            modified_content={"pacing": "faster"},
        )
        response = CheckpointResponse(
            decision=decision,
            applied=True,
            adjustments_made=["Modified pacing"],
            remaining_changes=[],
        )
        assert response.decision.decision_type == DecisionType.MODIFY

    def test_response_rejected(self):
        decision = CheckpointDecision(
            decision_type=DecisionType.REJECT,
            checkpoint_id="cp_03",
        )
        response = CheckpointResponse(
            decision=decision,
            applied=False,
            remaining_changes=[],
            explanation="Checkpoint rejected by human",
        )
        assert response.applied is False
        assert response.explanation == "Checkpoint rejected by human"


class TestCheckpointDefinition:
    """Test CheckpointDefinition dataclass."""

    def test_checkpoint_definition_creation(self):
        cp = CheckpointDefinition(
            checkpoint_id="cp_test",
            phase="test_phase",
            message="Test checkpoint",
            context_needed=["context1", "context2"],
        )
        assert cp.checkpoint_id == "cp_test"
        assert cp.phase == "test_phase"
        assert cp.context_needed == ["context1", "context2"]
        assert cp.timeout_hours is None
        assert cp.requires_approval is True
        assert cp.is_repeating is False

    def test_checkpoint_definition_repeating(self):
        cp = CheckpointDefinition(
            checkpoint_id="cp_repeat",
            phase="writing_phase",
            message="Repeating checkpoint",
            context_needed=[],
            is_repeating=True,
            repeat_interval=5,
        )
        assert cp.is_repeating is True
        assert cp.repeat_interval == 5


class TestCheckpointSchedule:
    """Test CheckpointSchedule class."""

    def test_initialization(self):
        schedule = CheckpointSchedule()
        assert len(schedule._checkpoints) == 8

    def test_initialization_custom(self):
        custom_cp = CheckpointDefinition(
            checkpoint_id="custom",
            phase="custom_phase",
            message="Custom",
            context_needed=[],
        )
        schedule = CheckpointSchedule(custom_checkpoints=[custom_cp])
        assert len(schedule._checkpoints) == 1

    def test_should_pause_at_phase(self):
        schedule = CheckpointSchedule()
        assert schedule.should_pause_at_phase("new_novel") is True
        assert schedule.should_pause_at_phase("worldbuilding_phase") is True
        assert schedule.should_pause_at_phase("character_phase") is True
        assert schedule.should_pause_at_phase("outline_phase") is True
        assert schedule.should_pause_at_phase("chapter_plan_phase") is False
        assert schedule.should_pause_at_phase("continuity_phase") is True
        assert schedule.should_pause_at_phase("verification_phase") is True

    def test_should_pause_at_phase_repeating(self):
        schedule = CheckpointSchedule()
        assert schedule.should_pause_at_phase("chapter_plan_phase", chapter=1) is True
        assert schedule.should_pause_at_phase("chapter_plan_phase", chapter=2) is True
        assert schedule.should_pause_at_phase("chapter_plan_phase", chapter=3) is True
        assert schedule.should_pause_at_phase("writing_phase", chapter=5) is True
        assert schedule.should_pause_at_phase("writing_phase", chapter=6) is False
        assert schedule.should_pause_at_phase("writing_phase", chapter=10) is True

    def test_should_pause_at_phase_unknown(self):
        schedule = CheckpointSchedule()
        assert schedule.should_pause_at_phase("unknown_phase") is False

    def test_get_checkpoint_for_phase(self):
        schedule = CheckpointSchedule()
        cp = schedule.get_checkpoint_for_phase("new_novel")
        assert cp is not None
        assert cp.checkpoint_id == "cp_01"

    def test_get_checkpoint_for_phase_repeating(self):
        schedule = CheckpointSchedule()
        cp = schedule.get_checkpoint_for_phase("chapter_plan_phase", chapter=1)
        assert cp is not None
        assert cp.is_repeating is True

    def test_get_checkpoint_for_phase_not_found(self):
        schedule = CheckpointSchedule()
        cp = schedule.get_checkpoint_for_phase("nonexistent")
        assert cp is None

    def test_get_next_checkpoint_after(self):
        schedule = CheckpointSchedule()
        next_cp = schedule.get_next_checkpoint_after("new_novel")
        assert next_cp is not None
        assert next_cp.phase == "worldbuilding_phase"

    def test_get_next_checkpoint_after_chapter_plan(self):
        schedule = CheckpointSchedule()
        next_cp = schedule.get_next_checkpoint_after("chapter_plan_phase", current_chapter=5)
        assert next_cp is not None

    def test_get_next_checkpoint_after_last(self):
        schedule = CheckpointSchedule()
        next_cp = schedule.get_next_checkpoint_after("verification_phase")
        assert next_cp is None

    def test_get_next_checkpoint_after_unknown(self):
        schedule = CheckpointSchedule()
        next_cp = schedule.get_next_checkpoint_after("unknown_phase")
        assert next_cp is None

    def test_activate_deactivate_checkpoint(self):
        schedule = CheckpointSchedule()
        assert schedule.is_checkpoint_active("cp_01") is False

        schedule.activate_checkpoint("cp_01", "abc123")
        assert schedule.is_checkpoint_active("cp_01") is True

        schedule.deactivate_checkpoint("cp_01")
        assert schedule.is_checkpoint_active("cp_01") is False

    def test_get_active_checkpoints(self):
        schedule = CheckpointSchedule()
        assert schedule.get_active_checkpoints() == []

        schedule.activate_checkpoint("cp_01", "hash1")
        schedule.activate_checkpoint("cp_02", "hash2")
        active = schedule.get_active_checkpoints()
        assert len(active) == 2
        assert "cp_01" in active
        assert "cp_02" in active

    def test_get_checkpoint_by_id(self):
        schedule = CheckpointSchedule()
        cp = schedule.get_checkpoint_by_id("cp_03")
        assert cp is not None
        assert cp.phase == "character_phase"

    def test_get_checkpoint_by_id_not_found(self):
        schedule = CheckpointSchedule()
        cp = schedule.get_checkpoint_by_id("nonexistent")
        assert cp is None

    def test_get_timeout_for_checkpoint(self):
        schedule = CheckpointSchedule()
        timeout = schedule.get_timeout_for_checkpoint("cp_01")
        assert timeout is None

    def test_get_timeout_for_checkpoint_with_timeout(self):
        custom_cp = CheckpointDefinition(
            checkpoint_id="custom",
            phase="custom",
            message="Test",
            context_needed=[],
            timeout_hours=24,
        )
        schedule = CheckpointSchedule(custom_checkpoints=[custom_cp])
        timeout = schedule.get_timeout_for_checkpoint("custom")
        assert timeout is not None
        assert timeout.total_seconds() == 24 * 3600


class TestCreateCheckpointSchedule:
    """Test create_checkpoint_schedule factory function."""

    def test_create_returns_schedule(self):
        schedule = create_checkpoint_schedule()
        assert isinstance(schedule, CheckpointSchedule)
        assert len(schedule._checkpoints) == 8


class TestDecisionProcessor:
    """Test DecisionProcessor class."""

    def test_process_approve(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.APPROVE,
            checkpoint_id="cp_01",
        )

        response = processor.process(decision, proposal)

        assert response.decision.decision_type == DecisionType.APPROVE
        assert response.applied is True
        assert len(response.adjustments_made) == 0

    def test_process_modify(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Original Title", pacing="moderate")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.MODIFY,
            checkpoint_id="cp_01",
            modified_content={"title": "New Title", "pacing": "fast"},
        )

        response = processor.process(decision, proposal)

        assert response.decision.decision_type == DecisionType.MODIFY
        assert response.applied is True
        assert len(response.adjustments_made) == 2
        assert response.modified_proposal is not None
        assert response.modified_proposal.plan.title == "New Title"

    def test_process_modify_no_content(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.MODIFY,
            checkpoint_id="cp_01",
        )

        response = processor.process(decision, proposal)

        assert response.applied is False

    def test_process_reject(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.REJECT,
            checkpoint_id="cp_01",
        )

        response = processor.process(decision, proposal)

        assert response.decision.decision_type == DecisionType.REJECT
        assert response.applied is False

    def test_process_guidance(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan", pacing="moderate")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.GUIDANCE,
            checkpoint_id="cp_01",
            guidance_text="Make it faster with more tension",
        )

        response = processor.process(decision, proposal)

        assert response.decision.decision_type == DecisionType.GUIDANCE
        assert response.applied is True

    def test_process_guidance_no_text(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.GUIDANCE,
            checkpoint_id="cp_01",
        )

        response = processor.process(decision, proposal)

        assert response.applied is False

    def test_process_ask(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )
        decision = CheckpointDecision(
            decision_type=DecisionType.ASK,
            checkpoint_id="cp_01",
            question="Why this plan?",
        )

        response = processor.process(decision, proposal)

        assert response.decision.decision_type == DecisionType.ASK
        assert response.applied is True
        assert response.explanation is not None

    def test_process_unknown_type(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test Plan")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test reasoning",
        )

        class UnknownType:
            value = "unknown"

        decision = CheckpointDecision(
            decision_type=UnknownType(),
            checkpoint_id="cp_01",
        )

        with pytest.raises(ValueError, match="Unknown decision type"):
            processor.process(decision, proposal)

    def test_validate_modification_valid(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        is_valid, error = processor.validate_modification({"title": "New Title"})

        assert is_valid is True
        assert error is None

    def test_validate_modification_empty(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        is_valid, error = processor.validate_modification({})

        assert is_valid is False
        assert error == "Empty modification"

    def test_validate_modification_missing_title(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        is_valid, error = processor.validate_modification({"pacing": "fast"})

        assert is_valid is False
        assert "Missing required field: title" in error

    def test_compute_adjustments(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        original = {"title": "Old", "pacing": "slow", "word_estimate": 5000}
        modified = {"title": "New", "pacing": "fast"}

        adjustments = processor._compute_adjustments(original, modified)

        assert "title" in adjustments
        assert adjustments["title"] == ("Old", "New")
        assert "pacing" in adjustments
        assert adjustments["pacing"] == ("slow", "fast")
        assert "word_estimate" not in adjustments

    def test_interpret_guidance_pacing(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test", pacing="moderate")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test",
        )

        adjustments = processor._interpret_guidance(proposal, "Make it darker with more tension")

        assert "pacing" in adjustments
        assert adjustments["pacing"] == "fast"

    def test_interpret_guidance_slower(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()
        plan = PlanContent(title="Test", pacing="moderate")
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="test",
            plan=plan,
            confidence=0.85,
            reasoning="Test",
        )

        adjustments = processor._interpret_guidance(proposal, "Slower pace with more mystery")

        assert "pacing" in adjustments
        assert adjustments["pacing"] == "slow"


class TestCheckpointIntegration:
    """Integration tests for checkpoint system."""

    def test_full_checkpoint_flow(self):
        plan = PlanContent(
            title="Integration Test Plan",
            pov="Protagonist",
            word_estimate=80000,
        )
        alt = Alternative(
            option_id="A",
            plan=PlanContent(title="Alt Option"),
            confidence=0.75,
            tradeoff_explanation="Different pacing",
        )
        proposal = CheckpointProposal(
            checkpoint_id="cp_01",
            phase="new_novel",
            plan=plan,
            confidence=0.85,
            reasoning="Strong structure",
            alternatives=[alt],
        )

        assert proposal.checkpoint_id == "cp_01"
        assert proposal.confidence == 0.85
        assert len(proposal.alternatives) == 1

    def test_checkpoint_schedule_comprehensive(self):
        schedule = CheckpointSchedule()
        phases_with_checkpoint = [
            ("new_novel", "cp_01"),
            ("worldbuilding_phase", "cp_02"),
            ("character_phase", "cp_03"),
            ("outline_phase", "cp_04"),
            ("continuity_phase", "cp_07"),
            ("verification_phase", "cp_08"),
        ]

        for phase, expected_id in phases_with_checkpoint:
            cp = schedule.get_checkpoint_for_phase(phase)
            assert cp is not None, f"Checkpoint for {phase} not found"
            assert cp.checkpoint_id == expected_id

        cp_chapter = schedule.get_checkpoint_for_phase("chapter_plan_phase", chapter=1)
        assert cp_chapter is not None
        assert cp_chapter.checkpoint_id == "cp_05"

        cp_writing = schedule.get_checkpoint_for_phase("writing_phase", chapter=5)
        assert cp_writing is not None
        assert cp_writing.checkpoint_id == "cp_06"

    def test_repeating_checkpoint_pattern(self):
        schedule = CheckpointSchedule()
        chapter_plan_cp = schedule.get_checkpoint_for_phase("chapter_plan_phase", chapter=1)
        assert chapter_plan_cp is not None
        assert chapter_plan_cp.is_repeating is True
        assert chapter_plan_cp.repeat_interval == 1

        writing_cp = schedule.get_checkpoint_for_phase("writing_phase", chapter=5)
        assert writing_cp is not None
        assert writing_cp.is_repeating is True
        assert writing_cp.repeat_interval == 5

    def test_full_proposal_with_decision_flow(self):
        from core.decision_processor import DecisionProcessor

        processor = DecisionProcessor()

        plan = PlanContent(
            title="Full Flow Test",
            pov="Hero",
            word_estimate=60000,
            pacing="moderate",
        )
        proposal = CheckpointProposal(
            checkpoint_id="cp_03",
            phase="character_phase",
            plan=plan,
            confidence=0.88,
            reasoning="Strong character development arc",
            reasoning_trace=["Analyzed character archetypes", "Defined arc structure"],
        )

        decision = CheckpointDecision(
            decision_type=DecisionType.MODIFY,
            checkpoint_id="cp_03",
            modified_content={"title": "Full Flow Test", "pov": "Villain", "pacing": "fast"},
        )

        response = processor.process(decision, proposal)

        assert response.applied is True
        assert response.modified_proposal is not None
        assert response.modified_proposal.plan.pov == "Villain"
        assert response.modified_proposal.plan.pacing == "fast"
        assert response.explanation is not None


class TestAuthorityLevel:
    """Test AuthorityLevel enum."""

    def test_authority_levels(self):
        from core.hybrid_authority import AuthorityLevel

        assert AuthorityLevel.HUMAN_ONLY.value == "human_only"
        assert AuthorityLevel.HUMAN_FIRST.value == "human_first"
        assert AuthorityLevel.AI_CAN_PROCEED.value == "ai_can_proceed"
        assert AuthorityLevel.AI_ONLY.value == "ai_only"


class TestAutoApproveReason:
    """Test AutoApproveReason enum."""

    def test_auto_approve_reasons(self):
        from core.hybrid_authority import AutoApproveReason

        assert AutoApproveReason.HIGH_CONFIDENCE.value == "high_confidence"
        assert AutoApproveReason.TIMEOUT.value == "timeout"
        assert AutoApproveReason.EXPLICIT_REQUEST.value == "explicit_request"
        assert AutoApproveReason.GRADUATED_AUTHORITY.value == "graduated_authority"


class TestAuthorityConfig:
    """Test AuthorityConfig dataclass."""

    def test_authority_config_defaults(self):
        from core.hybrid_authority import AuthorityConfig, AuthorityLevel

        config = AuthorityConfig()
        assert config.level == AuthorityLevel.HUMAN_FIRST
        assert config.confidence_threshold == 0.90
        assert config.timeout_hours == 24.0
        assert config.escalate_on_reject is True
        assert config.max_auto_approves_per_session == 5

    def test_authority_config_custom(self):
        from core.hybrid_authority import AuthorityConfig, AuthorityLevel

        config = AuthorityConfig(
            level=AuthorityLevel.AI_ONLY,
            confidence_threshold=0.8,
            timeout_hours=48.0,
            escalate_on_reject=False,
            max_auto_approves_per_session=10,
        )
        assert config.level == AuthorityLevel.AI_ONLY
        assert config.confidence_threshold == 0.8
        assert config.timeout_hours == 48.0
        assert config.escalate_on_reject is False
        assert config.max_auto_approves_per_session == 10


class TestGraduatedAuthority:
    """Test GraduatedAuthority class."""

    def test_trust_score_no_checkpoints(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority()
        assert auth.trust_score == 0.5

    def test_trust_score_calculation(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority(
            human_approvals=5,
            human_modifications=2,
            human_rejections=1,
            auto_approves=2,
            checkpoints_passed=10,
        )
        human_accuracy = (5 + 2) / 10
        consistency = 1.0 - abs(1 - 2) / 10
        expected = min(1.0, human_accuracy * 0.6 + consistency * 0.4)
        assert auth.trust_score == pytest.approx(expected, rel=0.001)

    def test_should_auto_approve_human_only(self):
        from core.hybrid_authority import (
            AuthorityConfig,
            AuthorityLevel,
            AutoApproveReason,
            GraduatedAuthority,
        )

        config = AuthorityConfig(level=AuthorityLevel.HUMAN_ONLY)
        auth = GraduatedAuthority()
        should, reason = auth.should_auto_approve(0.95, config)
        assert should is False
        assert reason == AutoApproveReason.EXPLICIT_REQUEST

    def test_should_auto_approve_human_first_under_threshold(self):
        from core.hybrid_authority import (
            AuthorityConfig,
            AuthorityLevel,
            AutoApproveReason,
            GraduatedAuthority,
        )

        config = AuthorityConfig(level=AuthorityLevel.HUMAN_FIRST, confidence_threshold=0.9)
        auth = GraduatedAuthority(checkpoints_passed=2)
        should, reason = auth.should_auto_approve(0.95, config)
        assert should is False
        assert reason == AutoApproveReason.GRADUATED_AUTHORITY

    def test_should_auto_approve_high_confidence(self):
        from core.hybrid_authority import (
            AuthorityConfig,
            AuthorityLevel,
            AutoApproveReason,
            GraduatedAuthority,
        )

        config = AuthorityConfig(level=AuthorityLevel.HUMAN_FIRST, confidence_threshold=0.9)
        auth = GraduatedAuthority(checkpoints_passed=5, auto_approves=2)
        should, reason = auth.should_auto_approve(0.95, config)
        assert should is True
        assert reason == AutoApproveReason.HIGH_CONFIDENCE

    def test_should_auto_approve_max_auto_approves_reached(self):
        from core.hybrid_authority import (
            AuthorityConfig,
            AuthorityLevel,
            AutoApproveReason,
            GraduatedAuthority,
        )

        config = AuthorityConfig(
            level=AuthorityLevel.HUMAN_FIRST,
            confidence_threshold=0.9,
            max_auto_approves_per_session=3,
        )
        auth = GraduatedAuthority(checkpoints_passed=10, auto_approves=3)
        should, reason = auth.should_auto_approve(0.95, config)
        assert should is False
        assert reason == AutoApproveReason.GRADUATED_AUTHORITY

    def test_record_approval_auto(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority()
        auth.record_approval(was_auto=True)
        assert auth.checkpoints_passed == 1
        assert auth.auto_approves == 1
        assert auth.human_approvals == 0

    def test_record_approval_human(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority()
        auth.record_approval(was_auto=False)
        assert auth.checkpoints_passed == 1
        assert auth.auto_approves == 0
        assert auth.human_approvals == 1

    def test_record_modification(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority()
        auth.record_modification()
        assert auth.checkpoints_passed == 1
        assert auth.human_modifications == 1

    def test_record_rejection(self):
        from core.hybrid_authority import GraduatedAuthority

        auth = GraduatedAuthority()
        auth.record_rejection()
        assert auth.checkpoints_passed == 1
        assert auth.human_rejections == 1


class TestCheckpointDeadline:
    """Test CheckpointDeadline class."""

    def test_deadline_default_24_hours(self):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime.now()
        deadline = CheckpointDeadline(checkpoint_id="cp_1", created_at=now)
        assert deadline.checkpoint_id == "cp_1"
        assert deadline.created_at == now
        assert deadline.deadline is not None
        assert deadline.deadline == pytest.approx(now + timedelta(hours=24), rel=1)
        assert deadline.extensions_granted == 0
        assert deadline.reminder_sent is False
        assert deadline.escalation_triggered is False

    def test_deadline_custom_deadline(self):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime.now()
        custom_deadline = now + timedelta(hours=48)
        deadline = CheckpointDeadline(
            checkpoint_id="cp_1", created_at=now, deadline=custom_deadline
        )
        assert deadline.deadline == custom_deadline

    def test_is_expired_false_when_not_expired(self, monkeypatch):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime(2026, 4, 12, 12, 0, 0)

        class MockDatetime:
            @staticmethod
            def now():
                return now

        monkeypatch.setattr("core.hybrid_authority.datetime", MockDatetime)
        deadline = CheckpointDeadline(
            checkpoint_id="cp_1",
            created_at=now,
            deadline=now + timedelta(hours=24),
        )
        assert deadline.is_expired is False

    def test_is_expired_true_when_expired(self, monkeypatch):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime(2026, 4, 12, 13, 0, 0)
        past = datetime(2026, 4, 12, 11, 0, 0)

        class MockDatetime:
            @staticmethod
            def now():
                return now

        monkeypatch.setattr("core.hybrid_authority.datetime", MockDatetime)
        deadline = CheckpointDeadline(
            checkpoint_id="cp_1", created_at=past, deadline=past + timedelta(hours=1)
        )
        assert deadline.is_expired is True

    def test_time_remaining_positive(self, monkeypatch):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime(2026, 4, 12, 12, 0, 0)

        class MockDatetime:
            @staticmethod
            def now():
                return now

        monkeypatch.setattr("core.hybrid_authority.datetime", MockDatetime)
        deadline = CheckpointDeadline(
            checkpoint_id="cp_1",
            created_at=now,
            deadline=now + timedelta(hours=12),
        )
        remaining = deadline.time_remaining
        assert remaining is not None
        assert remaining.total_seconds() > 0

    def test_time_remaining_zero_when_expired(self, monkeypatch):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        now = datetime(2026, 4, 13, 12, 0, 0)
        future = datetime(2026, 4, 14, 13, 0, 0)

        class MockDatetime:
            _call_count = 0

            @staticmethod
            def now():
                MockDatetime._call_count += 1
                return future

        monkeypatch.setattr("core.hybrid_authority.datetime", MockDatetime)
        deadline = CheckpointDeadline(
            checkpoint_id="cp_1",
            created_at=now,
            deadline=now + timedelta(hours=24),
        )
        remaining = deadline.time_remaining
        assert remaining is not None
        assert remaining.total_seconds() == 0

    def test_extend_success(self):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        deadline = CheckpointDeadline(
            checkpoint_id="cp_1",
            created_at=datetime.now(),
            deadline=datetime.now() + timedelta(hours=24),
        )
        result = deadline.extend(12)
        assert result is True
        assert deadline.extensions_granted == 1

    def test_extend_max_reached(self):
        from datetime import datetime, timedelta

        from core.hybrid_authority import CheckpointDeadline

        deadline = CheckpointDeadline(
            checkpoint_id="cp_1",
            created_at=datetime.now(),
            deadline=datetime.now() + timedelta(hours=24),
        )
        deadline.extensions_granted = 3
        result = deadline.extend(12)
        assert result is False

    def test_extend_no_deadline(self):
        from datetime import datetime

        from core.hybrid_authority import CheckpointDeadline

        deadline = CheckpointDeadline(
            checkpoint_id="cp_1", created_at=datetime.now(), deadline=None
        )
        result = deadline.extend(24)
        assert result is True
        assert deadline.deadline is not None


class TestCheckpointNotification:
    """Test CheckpointNotification dataclass."""

    def test_notification_creation(self):
        from datetime import datetime

        from core.hybrid_authority import CheckpointNotification

        now = datetime.now()
        notification = CheckpointNotification(
            notification_id="n1",
            checkpoint_id="cp_1",
            event_type="timeout",
            message="Test message",
            created_at=now,
        )
        assert notification.notification_id == "n1"
        assert notification.checkpoint_id == "cp_1"
        assert notification.event_type == "timeout"
        assert notification.message == "Test message"
        assert notification.created_at == now
        assert notification.read is False
        assert notification.metadata == {}


class TestBackgroundCheckpointer:
    """Test BackgroundCheckpointer class."""

    def test_start_monitoring(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        status = bp.get_deadline_status("cp_1")
        assert status is not None
        assert status["checkpoint_id"] == "cp_1"
        assert status["is_expired"] is False

    def test_start_monitoring_no_timeout(self):
        from core.background_checkpointer import BackgroundCheckpointer
        from core.hybrid_authority import AuthorityConfig

        config = AuthorityConfig(timeout_hours=None)
        bp = BackgroundCheckpointer(authority_config=config)
        bp.start_monitoring("cp_1", timeout_hours=None)
        assert bp.get_deadline_status("cp_1") is None

    def test_stop_monitoring(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.stop_monitoring("cp_1")
        assert bp.get_deadline_status("cp_1") is None

    def test_extend_deadline(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        result = bp.extend_deadline("cp_1", 12)
        assert result is True
        status = bp.get_deadline_status("cp_1")
        assert status["extensions_granted"] == 1

    def test_extend_deadline_not_found(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        result = bp.extend_deadline("nonexistent", 12)
        assert result is False

    def test_should_auto_approve_ai_only(self):
        from core.background_checkpointer import BackgroundCheckpointer
        from core.hybrid_authority import AuthorityConfig, AuthorityLevel, AutoApproveReason

        config = AuthorityConfig(level=AuthorityLevel.AI_ONLY)
        bp = BackgroundCheckpointer(authority_config=config)
        should, reason = bp.should_auto_approve("cp_1", 0.5)
        assert should is True
        assert reason == AutoApproveReason.EXPLICIT_REQUEST

    def test_should_auto_approve_delegates_to_authority(self):
        from core.background_checkpointer import BackgroundCheckpointer
        from core.hybrid_authority import AuthorityConfig, AuthorityLevel

        config = AuthorityConfig(level=AuthorityLevel.HUMAN_FIRST)
        bp = BackgroundCheckpointer(authority_config=config)
        bp._authority.checkpoints_passed = 5
        should, _ = bp.should_auto_approve("cp_1", 0.95)
        assert should is True

    def test_record_approval_auto(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_approval("cp_1", was_auto=True)
        assert bp.get_deadline_status("cp_1") is None
        assert bp._authority.auto_approves == 1

    def test_record_modification(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_modification("cp_1")
        assert bp.get_deadline_status("cp_1") is None
        assert bp._authority.human_modifications == 1

    def test_record_rejection_no_escalate(self):
        from core.background_checkpointer import BackgroundCheckpointer
        from core.hybrid_authority import AuthorityConfig

        config = AuthorityConfig(escalate_on_reject=False)
        bp = BackgroundCheckpointer(authority_config=config)
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_rejection("cp_1")
        assert bp.get_deadline_status("cp_1") is None
        assert bp._authority.human_rejections == 1

    def test_get_pending_notifications(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_rejection("cp_1")
        notifications = bp.get_pending_notifications()
        assert len(notifications) >= 1
        assert notifications[-1]["event_type"] == "escalation"

    def test_get_pending_notifications_filtered(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.start_monitoring("cp_2", timeout_hours=24)
        bp.record_rejection("cp_1")
        notifications = bp.get_pending_notifications(checkpoint_id="cp_1")
        for n in notifications:
            assert n["checkpoint_id"] == "cp_1"

    def test_mark_notification_read(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_rejection("cp_1")
        notifications = bp.get_pending_notifications()
        notif_id = notifications[-1]["id"]
        bp.mark_notification_read(notif_id)
        updated = bp.get_pending_notifications()
        found = next((n for n in updated if n["id"] == notif_id), None)
        assert found is not None
        assert found["read"] is True

    def test_clear_notifications_all(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.record_rejection("cp_1")
        bp.clear_notifications()
        assert len(bp.get_pending_notifications()) == 0

    def test_clear_notifications_checkpoint(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        bp.start_monitoring("cp_1", timeout_hours=24)
        bp.start_monitoring("cp_2", timeout_hours=24)
        bp.record_rejection("cp_1")
        bp.record_rejection("cp_2")
        bp.clear_notifications(checkpoint_id="cp_1")
        remaining = bp.get_pending_notifications()
        assert all(n["checkpoint_id"] == "cp_2" for n in remaining)

    def test_get_trust_score(self):
        from core.background_checkpointer import BackgroundCheckpointer

        bp = BackgroundCheckpointer()
        assert bp.get_trust_score() == 0.5
        bp._authority.checkpoints_passed = 5
        bp._authority.human_approvals = 3
        assert bp.get_trust_score() > 0.5

    def test_get_authority_status(self):
        from core.background_checkpointer import BackgroundCheckpointer
        from core.hybrid_authority import AuthorityLevel

        bp = BackgroundCheckpointer()
        status = bp.get_authority_status()
        assert "level" in status
        assert "trust_score" in status
        assert "checkpoints_passed" in status
        assert status["level"] == AuthorityLevel.HUMAN_FIRST.value

    def test_create_background_checkpointer_factory(self):
        from core.background_checkpointer import create_background_checkpointer
        from core.hybrid_authority import AuthorityLevel

        bp = create_background_checkpointer(authority_level=AuthorityLevel.AI_ONLY)
        assert bp._authority_config.level == AuthorityLevel.AI_ONLY


class TestInteractiveQAHandler:
    """Test InteractiveQAHandler class."""

    def test_qa_container_creation(self):
        from datetime import datetime

        from core.interactive_qa_handler import QAContainer

        now = datetime.now()
        qa = QAContainer(question="What?", answer="This.", timestamp=now)
        assert qa.question == "What?"
        assert qa.answer == "This."
        assert qa.timestamp == now

    def test_start_session_new(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        session = handler.start_session("cp_1")
        assert session == []

    def test_start_session_existing(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        handler.start_session("cp_1")
        session = handler.start_session("cp_1")
        assert session == []

    def test_get_session_exists(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        handler.start_session("cp_1")
        session = handler.get_session("cp_1")
        assert session == []

    def test_get_session_not_exists(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        session = handler.get_session("nonexistent")
        assert session == []

    def test_clear_session(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        handler.start_session("cp_1")
        handler.clear_session("cp_1")
        assert handler.get_session("cp_1") == []

    def _make_proposal(self):
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        return CheckpointProposal(
            checkpoint_id="cp_1",
            phase="outline_phase",
            plan=PlanContent(title="Test Plan", pov="Hero", pacing="moderate"),
            confidence=0.85,
            reasoning="Test reasoning",
        )

    def test_answer_why_this_plan(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("Why this plan?", proposal)
        assert "0.85" in answer or "85%" in answer
        assert "Test reasoning" in answer

    def test_answer_why_not(self):
        from core.checkpoint_proposal import Alternative, PlanContent
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        proposal.alternatives = [
            Alternative(
                option_id="A",
                plan=PlanContent(title="Alt A"),
                confidence=0.8,
                tradeoff_explanation="More action",
            )
        ]
        answer = handler.answer_question("Why not option A?", proposal)
        assert "Alt A" in answer

    def test_answer_what_if(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("What if I want changes?", proposal)
        assert "modify" in answer.lower()

    def test_answer_alternative(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("Show me alternatives", proposal)
        assert "available" in answer.lower() or "no alternatives" in answer.lower()

    def test_answer_confidence(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("What's the confidence?", proposal)
        assert "85" in answer

    def test_answer_change(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("I want to change things", proposal)
        assert "modify" in answer.lower() or "guidance" in answer.lower()

    def test_answer_chapter(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        proposal.plan.scenes = [{"description": "Scene 1"}, {"description": "Scene 2"}]
        answer = handler.answer_question("Tell me about chapters", proposal)
        assert "Scene" in answer or "chapter" in answer.lower()

    def test_answer_character(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("What about characters?", proposal)
        assert "character" in answer.lower()

    def test_answer_pacing(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("How's the pacing?", proposal)
        assert "moderate" in answer.lower() or "pacing" in answer.lower()

    def test_answer_ending(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("What about the ending?", proposal)
        assert "ending" in answer.lower() or "finalized" in answer.lower()

    def test_answer_fallback(self):
        from core.interactive_qa_handler import InteractiveQAHandler

        handler = InteractiveQAHandler()
        proposal = self._make_proposal()
        answer = handler.answer_question("Unrecognized question", proposal)
        assert "Test reasoning" in answer

    def test_create_qa_handler_factory(self):
        from core.interactive_qa_handler import create_qa_handler

        handler = create_qa_handler()
        assert handler is not None
        assert isinstance(handler, type(create_qa_handler()))


class TestCheckpointFileHandler:
    """Test CheckpointFileHandler class."""

    def test_save_and_load_proposal(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        handler = CheckpointFileHandler(tmp_path)
        proposal = CheckpointProposal(
            checkpoint_id="cp_1",
            phase="outline_phase",
            plan=PlanContent(title="Test Plan", pov="Hero", pacing="fast"),
            confidence=0.88,
            reasoning="Strong outline",
        )
        path = handler.save_proposal(proposal)
        assert path == tmp_path / "checkpoint_proposal.json"
        loaded = handler.load_proposal()
        assert loaded is not None
        assert loaded.checkpoint_id == "cp_1"
        assert loaded.plan.title == "Test Plan"
        assert loaded.confidence == 0.88

    def test_load_proposal_nonexistent(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        handler = CheckpointFileHandler(tmp_path)
        loaded = handler.load_proposal()
        assert loaded is None

    def test_save_and_load_decision(self, tmp_path):
        from datetime import datetime

        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointDecision, DecisionType

        handler = CheckpointFileHandler(tmp_path)
        decision = CheckpointDecision(
            decision_type=DecisionType.APPROVE,
            checkpoint_id="cp_1",
            timestamp=datetime.now(),
        )
        path = handler.save_decision(decision)
        assert path == tmp_path / "checkpoint_decision.json"
        loaded = handler.load_decision()
        assert loaded is not None
        assert loaded.checkpoint_id == "cp_1"
        assert loaded.decision_type == DecisionType.APPROVE

    def test_load_decision_nonexistent(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        handler = CheckpointFileHandler(tmp_path)
        loaded = handler.load_decision()
        assert loaded is None

    def test_clear_proposal(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        handler = CheckpointFileHandler(tmp_path)
        handler.save_proposal(
            CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.9,
                reasoning="Test",
            )
        )
        handler.clear_proposal()
        assert handler.load_proposal() is None

    def test_clear_decision(self, tmp_path):
        from datetime import datetime

        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointDecision, DecisionType

        handler = CheckpointFileHandler(tmp_path)
        handler.save_decision(
            CheckpointDecision(
                decision_type=DecisionType.APPROVE,
                checkpoint_id="cp_1",
                timestamp=datetime.now(),
            )
        )
        handler.clear_decision()
        assert handler.load_decision() is None

    def test_get_history_empty(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        handler = CheckpointFileHandler(tmp_path)
        history = handler.get_history()
        assert history == []

    def test_get_history_with_archives(self, tmp_path):
        from datetime import datetime

        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointDecision, DecisionType

        handler = CheckpointFileHandler(tmp_path)
        decision = CheckpointDecision(
            decision_type=DecisionType.APPROVE,
            checkpoint_id="cp_1",
            timestamp=datetime.now(),
        )
        handler.save_decision(decision)
        history = handler.get_history(checkpoint_id="cp_1")
        assert len(history) >= 1

    def test_has_pending_proposal_no_proposal(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        handler = CheckpointFileHandler(tmp_path)
        assert handler.has_pending_proposal() is False

    def test_has_pending_proposal_with_proposal_no_decision(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        handler = CheckpointFileHandler(tmp_path)
        handler.save_proposal(
            CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.9,
                reasoning="Test",
            )
        )
        assert handler.has_pending_proposal() is True

    def test_has_pending_proposal_with_both_files(self, tmp_path):
        from datetime import datetime

        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import (
            CheckpointDecision,
            CheckpointProposal,
            DecisionType,
            PlanContent,
        )

        handler = CheckpointFileHandler(tmp_path)
        handler.save_proposal(
            CheckpointProposal(
                checkpoint_id="cp_1",
                phase="outline_phase",
                plan=PlanContent(title="Test"),
                confidence=0.9,
                reasoning="Test",
            )
        )
        handler.save_decision(
            CheckpointDecision(
                decision_type=DecisionType.APPROVE,
                checkpoint_id="cp_1",
                timestamp=datetime.now(),
            )
        )
        assert handler.has_pending_proposal() is False

    def test_export_to_yaml(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler
        from core.checkpoint_proposal import CheckpointProposal, PlanContent

        handler = CheckpointFileHandler(tmp_path)
        proposal = CheckpointProposal(
            checkpoint_id="cp_1",
            phase="outline_phase",
            plan=PlanContent(title="YAML Test", pacing="fast"),
            confidence=0.85,
            reasoning="Test reasoning",
        )
        output_path = tmp_path / "proposal.yaml"
        result = handler.export_to_yaml(proposal, output_path)
        assert result == output_path
        assert output_path.exists()

    def test_import_decision_from_yaml(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        yaml_content = """
checkpoint_id: cp_1
decision_type: modify
modified_content:
  title: Modified
"""
        yaml_path = tmp_path / "decision.yaml"
        yaml_path.write_text(yaml_content)
        handler = CheckpointFileHandler(tmp_path)
        decision = handler.import_decision_from_yaml(yaml_path)
        assert decision is not None
        assert decision.checkpoint_id == "cp_1"

    def test_import_decision_from_yaml_nonexistent(self, tmp_path):
        from core.checkpoint_file_handler import CheckpointFileHandler

        handler = CheckpointFileHandler(tmp_path)
        decision = handler.import_decision_from_yaml(tmp_path / "nonexistent.yaml")
        assert decision is None

    def test_create_checkpoint_file_handler_factory(self, tmp_path):
        from core.checkpoint_file_handler import create_checkpoint_file_handler

        handler = create_checkpoint_file_handler(tmp_path)
        assert handler is not None
        assert handler.project_path == tmp_path


class TestCheckpointStatus:
    """Test CheckpointStatus class."""

    def test_checkpoint_status_values(self):
        from core.checkpoint_orchestrator import CheckpointStatus

        assert CheckpointStatus.PENDING == "pending"
        assert CheckpointStatus.APPROVED == "approved"
        assert CheckpointStatus.MODIFIED == "modified"
        assert CheckpointStatus.REJECTED == "rejected"
        assert CheckpointStatus.SUPERSEDED == "superseded"
        assert CheckpointStatus.AUTO_APPROVED == "auto_approved"


class TestCheckpointOrchestrator:
    """Test CheckpointOrchestrator class."""

    def test_should_pause_at_phase(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator
        from core.checkpoint_scheduler import create_checkpoint_schedule

        schedule = create_checkpoint_schedule()
        orchestrator = CheckpointOrchestrator(schedule=schedule)
        assert orchestrator.should_pause_at_phase("outline_phase") is True

    def test_get_checkpoint_id(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        assert cp_id == "cp_04"

    def test_get_checkpoint_id_with_chapter(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        cp_id = orchestrator.get_checkpoint_id("writing_phase", chapter=5)
        assert "ch5" in cp_id

    def test_present_checkpoint(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        plan_content = {
            "title": "Test Plan",
            "pov": "Hero",
            "word_estimate": 50000,
            "pacing": "moderate",
            "scenes": [{"id": 1, "description": "Test scene"}],
        }
        proposal = orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        assert proposal.checkpoint_id is not None
        assert proposal.plan.title == "Test Plan"
        assert proposal.confidence > 0

    def test_present_checkpoint_with_alternatives(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        alternatives = [
            {
                "plan": {"title": "Alt A"},
                "confidence": 0.8,
                "tradeoff": "More action",
            }
        ]
        proposal = orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
            alternatives=alternatives,
        )
        assert len(proposal.alternatives) == 1
        assert proposal.alternatives[0].plan.title == "Alt A"

    def test_get_checkpoint_state(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        state = orchestrator.get_checkpoint_state(cp_id)
        assert state is not None
        assert state["status"] == "pending"

    def test_get_checkpoint_state_nonexistent(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        state = orchestrator.get_checkpoint_state("nonexistent")
        assert state is None

    def test_get_pending_checkpoints(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        pending = orchestrator.get_pending_checkpoints()
        assert len(pending) >= 1

    def test_incorporate_decision_approve(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator, CheckpointStatus

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        decision = {"type": "approve"}
        response = orchestrator.incorporate_decision(cp_id, decision)
        assert response is not None
        state = orchestrator.get_checkpoint_state(cp_id)
        assert state["status"] == CheckpointStatus.APPROVED

    def test_incorporate_decision_modify(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator, CheckpointStatus

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        decision = {
            "type": "modify",
            "modified_content": {"title": "Modified Plan"},
        }
        response = orchestrator.incorporate_decision(cp_id, decision)
        assert response is not None
        state = orchestrator.get_checkpoint_state(cp_id)
        assert state["status"] == CheckpointStatus.MODIFIED

    def test_incorporate_decision_reject(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator, CheckpointStatus

        orchestrator = CheckpointOrchestrator()
        plan_content = {"title": "Test Plan"}
        cp_id = orchestrator.get_checkpoint_id("outline_phase")
        orchestrator.present_checkpoint(
            phase="outline_phase",
            chapter=None,
            plan_content=plan_content,
        )
        decision = {"type": "reject"}
        response = orchestrator.incorporate_decision(cp_id, decision)
        assert response is not None
        state = orchestrator.get_checkpoint_state(cp_id)
        assert state["status"] == CheckpointStatus.REJECTED

    def test_incorporate_decision_unknown_checkpoint(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        decision = {"type": "approve"}
        with pytest.raises(ValueError, match="Unknown checkpoint"):
            orchestrator.incorporate_decision("nonexistent", decision)

    def test_calculate_confidence(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator
        from core.checkpoint_proposal import PlanContent

        orchestrator = CheckpointOrchestrator()
        plan = PlanContent(
            title="Test",
            scenes=[{"id": 1}, {"id": 2}, {"id": 3}, {"id": 4}],
            word_estimate=5000,
        )
        confidence = orchestrator._calculate_confidence(plan, [])
        assert 0 <= confidence <= 1

    def test_calculate_confidence_breakdown(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator
        from core.checkpoint_proposal import PlanContent

        orchestrator = CheckpointOrchestrator()
        plan = PlanContent(
            title="Test",
            pov="Hero",
            pacing="moderate",
            scenes=[{"id": 1}],
            word_estimate=3000,
        )
        breakdown = orchestrator._calculate_confidence_breakdown(plan, "outline_phase")
        assert breakdown.coherence > 0
        assert breakdown.character > 0
        assert breakdown.pacing > 0
        assert breakdown.total > 0

    def test_generate_reasoning(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator
        from core.checkpoint_proposal import PlanContent

        orchestrator = CheckpointOrchestrator()
        plan = PlanContent(
            title="Test",
            pov="Hero",
            pacing="fast",
            foreshadowing="The dark storm is coming",
        )
        reasoning = orchestrator._generate_reasoning(plan, [], "outline_phase")
        assert "Hero" in reasoning
        assert "fast" in reasoning

    def test_generate_reasoning_trace(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator
        from core.checkpoint_proposal import PlanContent

        orchestrator = CheckpointOrchestrator()
        plan = PlanContent(title="Test", pov="Hero", scenes=[{"id": 1}])
        trace = orchestrator._generate_reasoning_trace(plan, "outline_phase")
        assert len(trace) > 0
        assert any("outline_phase" in t for t in trace)

    def test_hash_context(self):
        from core.checkpoint_orchestrator import CheckpointOrchestrator

        orchestrator = CheckpointOrchestrator()
        context1 = {"title": "Test", "pov": "Hero"}
        context2 = {"pov": "Hero", "title": "Test"}
        hash1 = orchestrator._hash_context(context1)
        hash2 = orchestrator._hash_context(context2)
        assert hash1 == hash2
        assert len(hash1) == 8

    def test_create_checkpoint_orchestrator_factory(self):
        from core.checkpoint_orchestrator import create_checkpoint_orchestrator

        orchestrator = create_checkpoint_orchestrator()
        assert orchestrator is not None
        assert orchestrator.schedule is not None


class TestAutonomousConfig:
    """Test AutonomousConfig model."""

    def test_autonomous_config_defaults(self):
        from core.autonomous_executor import AutonomousConfig

        config = AutonomousConfig(project_name="test_project")
        assert config.project_name == "test_project"
        assert config.start_phase == "new_novel"
        assert config.end_phase == "verification_phase"
        assert config.human_in_loop is False
        assert config.max_chapters is None
        assert config.provider == "openai"
        assert config.checkpoint_interface == "cli"

    def test_autonomous_config_custom(self):
        from core.autonomous_executor import AutonomousConfig

        config = AutonomousConfig(
            project_name="test_project",
            start_phase="outline_phase",
            end_phase="writing_phase",
            human_in_loop=True,
            max_chapters=10,
            provider="anthropic",
            checkpoint_interface="api",
        )
        assert config.project_name == "test_project"
        assert config.start_phase == "outline_phase"
        assert config.end_phase == "writing_phase"
        assert config.human_in_loop is True
        assert config.max_chapters == 10
        assert config.provider == "anthropic"
        assert config.checkpoint_interface == "api"


class TestAutonomousResult:
    """Test AutonomousResult model."""

    def test_autonomous_result_success(self):
        from core.autonomous_executor import AutonomousResult
        from core.progress_tracker import ExecutionStatus

        result = AutonomousResult(
            success=True,
            completed_phases=["new_novel", "outline_phase"],
            final_status=ExecutionStatus.COMPLETED,
        )
        assert result.success is True
        assert len(result.completed_phases) == 2
        assert result.error is None
        assert result.checkpoint_id is None

    def test_autonomous_result_failure(self):
        from core.autonomous_executor import AutonomousResult
        from core.progress_tracker import ExecutionStatus

        result = AutonomousResult(
            success=False,
            completed_phases=["new_novel"],
            final_status=ExecutionStatus.FAILED,
            error="Test error",
        )
        assert result.success is False
        assert result.error == "Test error"

    def test_autonomous_result_paused(self):
        from core.autonomous_executor import AutonomousResult
        from core.progress_tracker import ExecutionStatus

        result = AutonomousResult(
            success=False,
            completed_phases=["new_novel", "outline_phase"],
            final_status=ExecutionStatus.PAUSED,
            checkpoint_id="checkpoint_writing",
        )
        assert result.success is False
        assert result.checkpoint_id == "checkpoint_writing"


class TestAutonomousExecutor:
    """Test AutonomousExecutor class."""

    def test_workflow_chain(self):
        from core.autonomous_executor import AutonomousExecutor

        assert len(AutonomousExecutor.WORKFLOW_CHAIN) == 8
        assert "new_novel" in AutonomousExecutor.WORKFLOW_CHAIN
        assert "verification_phase" in AutonomousExecutor.WORKFLOW_CHAIN

    def test_legacy_human_checkpoints(self):
        from core.autonomous_executor import AutonomousExecutor
        from core.human_checkpoint import CheckpointType

        assert len(AutonomousExecutor.LEGACY_HUMAN_CHECKPOINTS) == 3
        outline_cp = AutonomousExecutor.LEGACY_HUMAN_CHECKPOINTS[0]
        assert outline_cp.phase == "outline_phase"
        assert outline_cp.type == CheckpointType.APPROVAL

    def test_get_workflow_index(self, tmp_path):

        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        config = AutonomousConfig(project_name="test_project", human_in_loop=False)
        executor = AutonomousExecutor(config=config, storage_path=tmp_path)
        assert executor._get_workflow_index("new_novel") == 0
        assert executor._get_workflow_index("outline_phase") == 3
        assert executor._get_workflow_index("writing_phase") == 5

    def test_get_workflow_index_invalid(self, tmp_path):
        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        config = AutonomousConfig(project_name="test_project", human_in_loop=False)
        executor = AutonomousExecutor(config=config, storage_path=tmp_path)
        with pytest.raises(ValueError, match="Unknown workflow"):
            executor._get_workflow_index("invalid_phase")

    def test_build_checkpoint_plan_content_new_novel(self, tmp_path):
        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        config = AutonomousConfig(project_name="test_project", human_in_loop=False)
        executor = AutonomousExecutor(config=config, storage_path=tmp_path)
        plan = executor._build_checkpoint_plan_content("new_novel", None, {})
        assert plan["title"] == "New Novel"
        assert plan["word_estimate"] == 80000

    def test_build_checkpoint_plan_content_outline(self, tmp_path):
        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        config = AutonomousConfig(project_name="test_project", human_in_loop=False)
        executor = AutonomousExecutor(config=config, storage_path=tmp_path)
        plan = executor._build_checkpoint_plan_content(
            "outline_phase", None, {"target_word_count": 100000}
        )
        assert "Outline Phase" in plan["title"]
        assert plan["word_estimate"] == 100000

    def test_build_checkpoint_plan_content_chapter(self, tmp_path):
        from core.autonomous_executor import AutonomousConfig, AutonomousExecutor

        config = AutonomousConfig(project_name="test_project", human_in_loop=False)
        executor = AutonomousExecutor(config=config, storage_path=tmp_path)
        plan = executor._build_checkpoint_plan_content("writing_phase", 5, {})
        assert "Chapter 5" in plan["title"]
        assert plan["word_estimate"] == 3000
