from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from core.storage import (  # noqa: I001
    AgentDefinition,
    FileParseError,
    FileStorage,
    FileWriteError,
    ProjectData,
    Storage,
    StorageBackend,
    StorageConfig,
    StorageError,
    StorageFactory,
    WorkflowDefinition,
)
from core.storage import (
    FileNotFoundError as StorageFileNotFoundError,
)


class TestStorageConfig:
    def test_defaults(self):
        cfg = StorageConfig()
        assert cfg.backend == "file"
        assert cfg.base_path == ".novels"
        assert cfg.cache_enabled is True

    def test_custom(self):
        cfg = StorageConfig(backend="file", base_path="/tmp/ns", cache_enabled=False)
        assert cfg.base_path == "/tmp/ns"
        assert cfg.cache_enabled is False


class TestAgentDefinition:
    def test_defaults(self):
        a = AgentDefinition(name="a", description="d", model="gpt-4o", system_prompt="sp")
        assert a.temperature == 0.7
        assert a.max_tokens == 4096
        assert a.metadata == {}


class TestWorkflowDefinition:
    def test_defaults(self):
        wf = WorkflowDefinition(name="wf", description="d", steps=[{"a": 1}])
        assert wf.metadata == {}


class TestFileStorageResolvePath:
    def test_relative_path(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        resolved = storage._resolve_path("foo/bar.md")
        assert resolved == tmp_path / "foo" / "bar.md"

    def test_absolute_path(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        resolved = storage._resolve_path("/absolute/path.md")
        assert resolved == Path("/absolute/path.md")


class TestFileStorageReadMarkdown:
    def test_success(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "test.md").write_text("hello world", encoding="utf-8")
        assert storage.read_markdown("test.md") == "hello world"

    def test_not_found(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        with pytest.raises(StorageFileNotFoundError):
            storage.read_markdown("missing.md")

    def test_unicode(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = "# Title\n\n中文内容 🎉"
        storage.write_markdown("unicode.md", content)
        assert storage.read_markdown("unicode.md") == content


class TestFileStorageWriteMarkdown:
    def test_creates_parents(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_markdown("deep/nested/file.md", "content")
        assert (tmp_path / "deep" / "nested" / "file.md").exists()
        assert storage.read_markdown("deep/nested/file.md") == "content"

    def test_atomic_no_temp_left(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_markdown("atom.md", "content")
        assert not (tmp_path / "atom.md.tmp").exists()

    def test_write_failure(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        with patch("builtins.open", side_effect=OSError("perm")):
            with pytest.raises(FileWriteError):
                storage.write_markdown("fail.md", "data")


class TestFileStorageReadYaml:
    def test_success(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "test.yaml").write_text("key: value\nlist:\n  - 1\n  - 2", encoding="utf-8")
        data = storage.read_yaml("test.yaml")
        assert data["key"] == "value"
        assert data["list"] == [1, 2]

    def test_empty_file_returns_empty_dict(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "empty.yaml").write_text("", encoding="utf-8")
        assert storage.read_yaml("empty.yaml") == {}

    def test_not_found(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        with pytest.raises(StorageFileNotFoundError):
            storage.read_yaml("missing.yaml")

    def test_invalid_yaml(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "bad.yaml").write_text("key: [unclosed", encoding="utf-8")
        with pytest.raises(FileParseError):
            storage.read_yaml("bad.yaml")


class TestFileStorageWriteYaml:
    def test_round_trip(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        data = {"nested": {"k": "v"}, "num": 42, "unicode": "中文"}
        storage.write_yaml("test.yaml", data)
        result = storage.read_yaml("test.yaml")
        assert result == data

    def test_creates_parents(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_yaml("deep/nested/config.yaml", {"level": 3})
        assert storage.read_yaml("deep/nested/config.yaml")["level"] == 3

    def test_write_failure(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        with patch("builtins.open", side_effect=OSError("nope")):
            with pytest.raises(FileWriteError):
                storage.write_yaml("fail.yaml", {"k": "v"})


class TestFileStorageReadAgent:
    def _agent_content(self, **overrides):
        frontmatter = {
            "name": "test_agent",
            "description": "A test agent",
            "model": "gpt-4",
            "temperature": 0.5,
            "max_tokens": 2048,
        }
        frontmatter.update(overrides)
        fm = yaml.safe_dump(frontmatter, default_flow_style=False)
        return f"---\n{fm}\n---\nYou are a test agent."

    def test_success(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = self._agent_content(custom_field="extra")
        (tmp_path / "agent.md").write_text(content, encoding="utf-8")
        agent = storage.read_agent("agent.md")
        assert agent.name == "test_agent"
        assert agent.model == "gpt-4"
        assert agent.temperature == 0.5
        assert agent.max_tokens == 2048
        assert agent.system_prompt == "You are a test agent."
        assert agent.metadata["custom_field"] == "extra"

    def test_no_frontmatter(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "bad.md").write_text("No frontmatter here", encoding="utf-8")
        with pytest.raises(FileParseError, match="must start with"):
            storage.read_agent("bad.md")

    def test_incomplete_frontmatter(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = "---\nname: test\n---\nbody"
        (tmp_path / "inc.md").write_text(content, encoding="utf-8")
        with pytest.raises(FileParseError, match="Missing required field"):
            storage.read_agent("inc.md")

    def test_two_parts_only(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = "---\nname: a\ndescription: d\nmodel: m"
        (tmp_path / "nob.md").write_text(content, encoding="utf-8")
        with pytest.raises(FileParseError):
            storage.read_agent("nob.md")

    def test_defaults_when_missing(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = "---\nname: a\ndescription: d\nmodel: m\n---\nbody"
        (tmp_path / "def.md").write_text(content, encoding="utf-8")
        agent = storage.read_agent("def.md")
        assert agent.temperature == 0.7
        assert agent.max_tokens == 4096


class TestFileStorageReadWorkflow:
    def test_success(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        wf = {
            "name": "wf1",
            "description": "A workflow",
            "steps": [{"agent": "writer", "input": "prompt"}],
            "version": "1.0",
        }
        (tmp_path / "wf.yaml").write_text(yaml.safe_dump(wf), encoding="utf-8")
        result = storage.read_workflow("wf.yaml")
        assert result.name == "wf1"
        assert len(result.steps) == 1
        assert result.metadata["version"] == "1.0"

    def test_missing_field(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "bad.yaml").write_text("name: x\ndescription: y\n", encoding="utf-8")
        with pytest.raises(FileParseError, match="Missing required field"):
            storage.read_workflow("bad.yaml")

    def test_steps_not_list(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        content = "name: x\ndescription: y\nsteps: not_a_list\n"
        (tmp_path / "bad2.yaml").write_text(content, encoding="utf-8")
        with pytest.raises(FileParseError, match="must be a list"):
            storage.read_workflow("bad2.yaml")


class TestFileStorageExists:
    def test_file_exists(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_markdown("exists.md", "content")
        assert storage.exists("exists.md") is True
        assert storage.exists("nope.md") is False

    def test_dir_exists(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "subdir").mkdir()
        assert storage.exists("subdir") is True


class TestFileStorageDelete:
    def test_delete_file(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_markdown("del.md", "content")
        storage.delete("del.md")
        assert not storage.exists("del.md")

    def test_delete_directory(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        sub = tmp_path / "subdir"
        sub.mkdir()
        (sub / "file.md").write_text("content")
        storage.delete("subdir")
        assert not sub.exists()

    def test_delete_nonexistent_no_error(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.delete("ghost")

    def test_delete_oserror(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "locked.md").write_text("data")
        with patch("pathlib.Path.unlink", side_effect=OSError("locked")):
            with pytest.raises(StorageError):
                storage.delete("locked.md")


class TestFileStorageListFiles:
    def test_list_md_files(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        storage.write_markdown("a.md", "a")
        storage.write_markdown("b.md", "b")
        storage.write_yaml("c.yaml", {"k": "v"})
        md = storage.list_files(".", "*.md")
        assert len(md) == 2

    def test_empty_dir(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        assert storage.list_files(".") == []

    def test_nonexistent_dir(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        assert storage.list_files("nonexistent") == []

    def test_oserror(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        storage = FileStorage(cfg)
        (tmp_path / "sub").mkdir()
        with patch.object(Path, "glob", side_effect=OSError("fail")):
            with pytest.raises(StorageError):
                storage.list_files("sub")


class TestStorageFactory:
    def test_create_file_backend(self, tmp_path):
        cfg = StorageConfig(base_path=str(tmp_path))
        backend = StorageFactory.create(cfg)
        assert isinstance(backend, FileStorage)

    def test_unknown_backend(self):
        cfg = StorageConfig(backend="unknown")
        with pytest.raises(StorageError, match="Unknown storage backend"):
            StorageFactory.create(cfg)

    def test_register_backend(self, tmp_path):
        class MockBackend(StorageBackend):
            def __init__(self, config):
                pass

            def read_markdown(self, path):
                return ""

            def write_markdown(self, path, content):
                pass

            def read_yaml(self, path):
                return {}

            def write_yaml(self, path, data):
                pass

            def read_agent(self, path):
                pass

            def read_workflow(self, path):
                pass

            def exists(self, path):
                return False

            def delete(self, path):
                pass

            def list_files(self, directory, pattern="*"):
                return []

        StorageFactory.register_backend("mock_test", MockBackend)
        cfg = StorageConfig(backend="mock_test")
        backend = StorageFactory.create(cfg)
        assert isinstance(backend, MockBackend)


class TestProjectData:
    def test_defaults(self):
        pd = ProjectData(name="test")
        assert pd.meta == {}
        assert pd.chapters == []

    def test_with_data(self):
        pd = ProjectData(name="test", meta={"k": "v"}, chapters=[{"file": "ch1.md"}])
        assert pd.meta["k"] == "v"
        assert len(pd.chapters) == 1


class TestStorage:
    def test_project_dir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        assert s.project_dir.exists()

    def test_list_projects_empty(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        assert s.list_projects() == []

    def test_save_and_list_projects(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s.save_project("proj1", meta={"title": "Novel 1"})
        projects = s.list_projects()
        assert "proj1" in projects

    def test_list_projects_handles_exception(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s._backend = MagicMock()
        s._backend.base_path = tmp_path / "novels"
        s._backend.base_path.mkdir(parents=True)
        mock_dir = MagicMock()
        mock_dir.is_dir.side_effect = Exception("boom")
        with patch.object(Path, "iterdir", return_value=[mock_dir]):
            assert s.list_projects() == []

    def test_load_project_with_chapters(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s.save_project("ch_proj")
        chapters_dir = s.project_dir / "ch_proj" / "chapters"
        chapters_dir.mkdir()
        (chapters_dir / "chapter_01.md").write_text("Chapter 1")
        (chapters_dir / "chapter_02.md").write_text("Chapter 2")
        loaded = s.load_project("ch_proj")
        assert len(loaded.chapters) == 2

    def test_load_project_no_meta(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        p = s.project_dir / "bare"
        p.mkdir(parents=True)
        loaded = s.load_project("bare")
        assert loaded.meta == {}

    def test_load_project_bad_meta(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        p = s.project_dir / "badmeta"
        p.mkdir(parents=True)
        (p / "meta.yaml").write_text("::invalid::")
        loaded = s.load_project("badmeta")
        assert loaded.meta == {}

    def test_save_project_no_meta(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s.save_project("nometa")
        loaded = s.load_project("nometa")
        assert loaded.name == "nometa"

    def test_list_projects_skips_hidden(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s.save_project("visible")
        hidden_dir = s.project_dir / ".hidden"
        hidden_dir.mkdir(parents=True)
        projects = s.list_projects()
        assert "visible" in projects
        assert ".hidden" not in projects

    def test_project_dir_fallback(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        s = Storage()
        s._backend = MagicMock(spec=StorageBackend)
        del s._backend.base_path
        assert s.project_dir == Path(".novels")
