"""Comprehensive tests for cli_version module."""

from unittest.mock import patch

from click.testing import CliRunner

from cli_version import version


class TestVersionGroup:
    """Test version command group."""

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(version, ["--help"])
        assert result.exit_code == 0
        assert "version" in result.output.lower()


class TestInfoCommand:
    """Test version info command."""

    def test_info_without_check(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.current_version = "1.0.0"
            mgr.package_name = "novelscribe"
            result = runner.invoke(version, ["info"])
            assert result.exit_code == 0

    def test_info_with_check_update_available(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
            }
            result = runner.invoke(version, ["info", "--check"])
            assert result.exit_code == 0

    def test_info_with_check_no_update(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": False,
                "current": "1.0.0",
                "latest": "1.0.0",
            }
            result = runner.invoke(version, ["info", "--check"])
            assert result.exit_code == 0

    def test_info_with_check_no_info(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = None
            result = runner.invoke(version, ["info", "--check"])
            assert result.exit_code == 0


class TestCheckCommand:
    """Test version check command."""

    def test_check_update_available(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
                "upgrade_command": "pip install --upgrade novelscribe",
            }
            result = runner.invoke(version, ["check"])
            assert result.exit_code == 0

    def test_check_no_update(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": False,
                "current": "1.0.0",
            }
            result = runner.invoke(version, ["check"])
            assert result.exit_code == 0

    def test_check_no_info(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = None
            result = runner.invoke(version, ["check"])
            assert result.exit_code == 0


class TestUpdateCommand:
    """Test version update command."""

    def test_update_no_info(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = None
            result = runner.invoke(version, ["update", "-y"])
            assert result.exit_code == 0

    def test_update_already_latest(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": False,
                "current": "1.0.0",
            }
            result = runner.invoke(version, ["update", "-y"])
            assert result.exit_code == 0

    def test_update_success(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
                "upgrade_command": "pip install --upgrade novelscribe",
            }
            mgr.perform_self_update.return_value = True
            result = runner.invoke(version, ["update", "-y"])
            assert result.exit_code == 0

    def test_update_failure(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
                "upgrade_command": "pip install --upgrade novelscribe",
            }
            mgr.perform_self_update.return_value = False
            result = runner.invoke(version, ["update", "-y"])
            assert result.exit_code == 0

    def test_update_with_confirmation_abort(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
                "upgrade_command": "pip install --upgrade novelscribe",
            }
            result = runner.invoke(version, ["update"], input="n\n")
            assert result.exit_code != 0

    def test_update_with_confirmation_accept(self):
        runner = CliRunner()
        with patch("cli_version.VersionManager") as mock_vm:
            mgr = mock_vm.return_value
            mgr.check_for_updates.return_value = {
                "update_available": True,
                "current": "1.0.0",
                "latest": "2.0.0",
                "upgrade_command": "pip install --upgrade novelscribe",
            }
            mgr.perform_self_update.return_value = True
            result = runner.invoke(version, ["update"], input="y\n")
            assert result.exit_code == 0
