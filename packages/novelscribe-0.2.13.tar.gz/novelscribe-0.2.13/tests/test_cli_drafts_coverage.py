"""Comprehensive tests for cli_drafts module."""

from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_drafts import drafts


class TestDraftsGroup:
    """Test drafts command group."""

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(drafts, ["--help"])
        assert result.exit_code == 0


class TestRegenerateCommand:
    """Test regenerate command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(drafts, ["regenerate", "missing", "-c", "1"])
            assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_drafts.ChapterRegenerator") as mock_cr,
            patch("cli_drafts.RegenerationConfig"),
            patch("cli_drafts.RegenerationStrategy") as mock_rs,
        ):
            mock_rs.return_value = "full"
            mock_cr.return_value.regenerate.return_value = MagicMock(
                success=True,
                new_version=2,
                words_changed=100,
                content_similarity=0.85,
                quality_score=0.9,
                issues_resolved=["spelling"],
                new_issues=[],
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["regenerate", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_failure_with_new_issues(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_drafts.ChapterRegenerator") as mock_cr,
            patch("cli_drafts.RegenerationConfig"),
            patch("cli_drafts.RegenerationStrategy") as mock_rs,
        ):
            mock_rs.return_value = "full"
            mock_cr.return_value.regenerate.return_value = MagicMock(
                success=False,
                new_issues=["plot hole", "inconsistency"],
                new_version=0,
                words_changed=0,
                content_similarity=0.0,
                quality_score=0.0,
                issues_resolved=[],
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["regenerate", "myproj", "-c", "1"])
            assert result.exit_code != 0

    def test_custom_strategy(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_drafts.ChapterRegenerator") as mock_cr,
            patch("cli_drafts.RegenerationConfig"),
            patch("cli_drafts.RegenerationStrategy") as mock_rs,
        ):
            mock_rs.return_value = "targeted"
            mock_cr.return_value.regenerate.return_value = MagicMock(
                success=True,
                new_version=3,
                words_changed=50,
                content_similarity=0.9,
                quality_score=0.95,
                issues_resolved=[],
                new_issues=[],
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["regenerate", "myproj", "-c", "1", "--strategy", "targeted"]
            )
            assert result.exit_code == 0

    def test_with_fix_issues(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_drafts.ChapterRegenerator") as mock_cr,
            patch("cli_drafts.RegenerationConfig"),
            patch("cli_drafts.RegenerationStrategy") as mock_rs,
        ):
            mock_rs.return_value = "continuity"
            mock_cr.return_value.regenerate.return_value = MagicMock(
                success=True,
                new_version=2,
                words_changed=30,
                content_similarity=0.95,
                quality_score=0.92,
                issues_resolved=["continuity error"],
                new_issues=[],
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts,
                [
                    "regenerate",
                    "myproj",
                    "-c",
                    "1",
                    "--strategy",
                    "continuity",
                    "--fix-issues",
                    "continuity error",
                    "--style-target",
                    "literary",
                ],
            )
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_drafts.ChapterRegenerator") as mock_cr,
            patch("cli_drafts.RegenerationConfig"),
            patch("cli_drafts.RegenerationStrategy"),
        ):
            mock_cr.return_value.regenerate.side_effect = RuntimeError("err")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["regenerate", "myproj", "-c", "1"])
            assert result.exit_code != 0


class TestListDraftsCommand:
    """Test list command."""

    def test_project_not_found_no_error(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.list_versions.return_value = []
            mock_dm.return_value.get_project_summary.return_value = {
                "total_chapters": 0,
                "total_drafts": 0,
                "total_words": 0,
            }
            result = runner.invoke(drafts, ["list", "missing"])
            assert result.exit_code == 0

    def test_with_chapter_versions(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            v1 = MagicMock(
                version=1,
                status="active",
                regeneration_reason="draft",
                word_count=1000,
                quality_score=0.9,
                timestamp=datetime(2024, 1, 1, 12, 0),
                parent_version=None,
            )
            v2 = MagicMock(
                version=2,
                status="archived",
                regeneration_reason="rewrite",
                word_count=1100,
                quality_score=0.85,
                timestamp=datetime(2024, 1, 2, 12, 0),
                parent_version=1,
            )
            mock_dm.return_value.list_versions.return_value = [v1, v2]
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["list", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_no_versions(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.list_versions.return_value = []
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["list", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_project_summary(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.get_project_summary.return_value = {
                "total_chapters": 10,
                "total_drafts": 25,
                "total_words": 50000,
            }
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["list", "myproj"])
            assert result.exit_code == 0


class TestShowDraftCommand:
    """Test show command."""

    def test_with_version(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            meta = MagicMock()
            meta.version = 2
            meta.status.value = "active"
            meta.regeneration_reason = "rewrite"
            meta.word_count = 2000
            meta.quality_score = 0.9
            meta.timestamp = datetime(2024, 1, 15, 10, 30, 0)
            mock_dm.return_value.get_version.return_value = meta
            mock_dm.return_value.get_version_content.return_value = "short content"
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["show", "myproj", "-c", "1", "-v", "2"])
            assert result.exit_code == 0

    def test_without_version(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            meta = MagicMock()
            meta.version = 3
            meta.status.value = "active"
            meta.regeneration_reason = None
            meta.word_count = 1500
            meta.quality_score = None
            meta.timestamp = datetime(2024, 2, 1, 8, 0, 0)
            mock_dm.return_value.get_current_version.return_value = meta
            mock_dm.return_value.get_version_content.return_value = "current content"
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["show", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.get_current_version.return_value = None
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["show", "myproj", "-c", "1"])
            assert result.exit_code != 0

    def test_long_content(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            meta = MagicMock()
            meta.version = 1
            meta.status.value = "active"
            meta.regeneration_reason = "draft"
            meta.word_count = 5000
            meta.quality_score = 0.8
            meta.timestamp = datetime(2024, 1, 1, 0, 0, 0)
            mock_dm.return_value.get_current_version.return_value = meta
            mock_dm.return_value.get_version_content.return_value = "x" * 1000
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["show", "myproj", "-c", "1"])
            assert result.exit_code == 0


class TestCompareCommand:
    """Test compare command."""

    def test_success(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.VersionComparator") as mock_vc:
            mock_vc.return_value.generate_diff_report.return_value = MagicMock(
                summary="Changed 50 words",
                recommendations=["Consider revising ending"],
                quality_impact="positive",
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["compare", "myproj", "-c", "1", "--from", "1", "--to", "2"]
            )
            assert result.exit_code == 0

    def test_without_recommendations(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.VersionComparator") as mock_vc:
            mock_vc.return_value.generate_diff_report.return_value = MagicMock(
                summary="No changes", recommendations=[], quality_impact="neutral"
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["compare", "myproj", "-c", "1", "--from", "1", "--to", "1"]
            )
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.VersionComparator") as mock_vc:
            mock_vc.return_value.generate_diff_report.side_effect = RuntimeError("err")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["compare", "myproj", "-c", "1", "--from", "1", "--to", "2"]
            )
            assert result.exit_code != 0


class TestRollbackCommand:
    """Test rollback command."""

    def test_success(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(can_rollback=True, warnings=[], dependency_issues=[], reasons=[])
            mock_rm.return_value.validate_rollback.return_value = val
            mock_rm.return_value.rollback.return_value = MagicMock(
                success=True,
                from_version=3,
                to_version=1,
                backup_created=True,
                backup_path="/backup/v3",
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1"])
            assert result.exit_code == 0

    def test_cannot_rollback(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(
                can_rollback=False, warnings=[], dependency_issues=[], reasons=["Version not found"]
            )
            mock_rm.return_value.validate_rollback.return_value = val
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "99"])
            assert result.exit_code != 0

    def test_with_warnings(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(
                can_rollback=True, warnings=["Data may be lost"], dependency_issues=[], reasons=[]
            )
            mock_rm.return_value.validate_rollback.return_value = val
            mock_rm.return_value.rollback.return_value = MagicMock(
                success=True, from_version=2, to_version=1, backup_created=False, backup_path=None
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1"])
            assert result.exit_code == 0

    def test_dependency_issues_without_force(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(
                can_rollback=True,
                warnings=[],
                dependency_issues=["Chapter 3 depends on v2"],
                reasons=[],
            )
            mock_rm.return_value.validate_rollback.return_value = val
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1"])
            assert result.exit_code != 0

    def test_dependency_issues_with_force(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(
                can_rollback=True,
                warnings=[],
                dependency_issues=["Chapter 3 depends on v2"],
                reasons=[],
            )
            mock_rm.return_value.validate_rollback.return_value = val
            mock_rm.return_value.rollback.return_value = MagicMock(
                success=True,
                from_version=2,
                to_version=1,
                backup_created=True,
                backup_path="/backup",
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1", "--force"]
            )
            assert result.exit_code == 0

    def test_cannot_rollback_with_force(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(
                can_rollback=False, warnings=[], dependency_issues=[], reasons=["Not found"]
            )
            mock_rm.return_value.validate_rollback.return_value = val
            mock_rm.return_value.rollback.return_value = MagicMock(
                success=True, from_version=2, to_version=1, backup_created=False, backup_path=None
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1", "--force"]
            )
            assert result.exit_code == 0

    def test_rollback_failure(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            val = MagicMock(can_rollback=True, warnings=[], dependency_issues=[], reasons=[])
            mock_rm.return_value.validate_rollback.return_value = val
            mock_rm.return_value.rollback.return_value = MagicMock(
                success=False, error_message="Disk full", from_version=2, to_version=1
            )
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1"])
            assert result.exit_code != 0

    def test_exception(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.RollbackManager") as mock_rm:
            mock_rm.return_value.validate_rollback.side_effect = RuntimeError("err")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["rollback", "myproj", "-c", "1", "--to-version", "1"])
            assert result.exit_code != 0


class TestArchiveCommand:
    """Test archive command."""

    def test_with_chapter(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.archive_old_versions.return_value = 3
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["archive", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_without_chapter(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.get_project_summary.return_value = {
                "chapters": [
                    {"chapter_number": 1},
                    {"chapter_number": 2},
                ]
            }
            mock_dm.return_value.archive_old_versions.return_value = 2
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["archive", "myproj"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_drafts.DraftManager") as mock_dm:
            mock_dm.return_value.archive_old_versions.side_effect = RuntimeError("err")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(drafts, ["archive", "myproj", "-c", "1"])
            assert result.exit_code != 0
