"""Tests for core.file_optimizer to achieve 80%+ coverage."""

import gzip
from pathlib import Path

from core.file_optimizer import FileOptimizer, FileOptimizerStats, get_file_optimizer


class TestFileOptimizerStats:
    """Test FileOptimizerStats dataclass."""

    def test_default_values(self):
        stats = FileOptimizerStats()
        assert stats.cache_hits == 0
        assert stats.cache_misses == 0
        assert stats.writes_cached == 0
        assert stats.compressed_files == 0
        assert stats.total_bytes_read == 0
        assert stats.total_bytes_written == 0
        assert stats.reads == 0
        assert stats.writes == 0
        assert stats.bytes_read == 0
        assert stats.bytes_written == 0


class TestFileOptimizerInit:
    """Test FileOptimizer initialization."""

    def test_default_init(self):
        opt = FileOptimizer()
        assert opt.buffer_size == 8192
        assert opt.write_cache_size == 8192
        assert opt.enable_compression is True
        assert opt.compression_threshold == 1024

    def test_custom_init(self):
        opt = FileOptimizer(
            buffer_size=4096,
            write_cache_size=2048,
            enable_compression=False,
            compression_threshold=512,
        )
        assert opt.buffer_size == 4096
        assert opt.write_cache_size == 2048
        assert opt.enable_compression is False
        assert opt.compression_threshold == 512

    def test_default_write_cache_size_constant(self):
        assert FileOptimizer.DEFAULT_WRITE_CACHE_SIZE == 8192


class TestFileOptimizerWrite:
    """Test write_file method."""

    def test_write_immediate(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        opt.write_file(path, "hello world", immediate=True)
        assert Path(path).read_text() == "hello world"
        assert opt._stats.writes == 1
        assert opt._stats.total_bytes_written == 11
        assert opt._stats.bytes_written == 11

    def test_write_immediate_with_compression(self, tmp_path):
        opt = FileOptimizer(enable_compression=True, compression_threshold=5)
        path = str(tmp_path / "test.txt")
        content = "x" * 2000
        opt.write_file(path, content, immediate=True)
        assert opt._stats.compressed_files == 1
        gz_path = Path(path + ".gz")
        assert gz_path.exists()
        with gzip.open(gz_path, "rt") as f:
            assert f.read() == content

    def test_write_immediate_below_threshold(self, tmp_path):
        opt = FileOptimizer(enable_compression=True, compression_threshold=10000)
        path = str(tmp_path / "test.txt")
        opt.write_file(path, "short", immediate=True)
        assert opt._stats.compressed_files == 0

    def test_write_immediate_compression_disabled(self, tmp_path):
        opt = FileOptimizer(enable_compression=False, compression_threshold=1)
        path = str(tmp_path / "test.txt")
        opt.write_file(path, "content", immediate=True)
        assert opt._stats.compressed_files == 0

    def test_write_deferred(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "deferred.txt")
        opt.write_file(path, "cached content", immediate=False)
        assert not Path(path).exists()
        assert opt._stats.writes_cached == 1
        assert path in opt._write_cache

    def test_write_deferred_no_compression(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "deferred.txt")
        opt.write_file(path, "cached content", immediate=False)
        assert opt._stats.compressed_files == 0
        assert opt._stats.total_bytes_written == 0

    def test_write_multiple_files(self, tmp_path):
        opt = FileOptimizer()
        for i in range(3):
            path = str(tmp_path / f"file{i}.txt")
            opt.write_file(path, f"content{i}", immediate=True)
        assert opt._stats.writes == 3


class TestFileOptimizerRead:
    """Test read_file method."""

    def test_read_from_disk(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("file content")
        content = opt.read_file(path)
        assert content == "file content"
        assert opt._stats.reads == 1
        assert opt._stats.cache_misses == 1
        assert opt._stats.total_bytes_read == 12
        assert opt._stats.bytes_read == 12

    def test_read_from_cache(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("content")
        opt.read_file(path)
        content = opt.read_file(path)
        assert content == "content"
        assert opt._stats.cache_hits == 1

    def test_read_gzip_file(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        gz_path = str(tmp_path / "test.txt.gz")
        with gzip.open(gz_path, "wt") as f:
            f.write("compressed content")
        content = opt.read_file(path)
        assert content == "compressed content"
        assert opt._stats.cache_misses == 1

    def test_read_prefers_gzip_over_plain(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("plain content")
        gz_path = str(tmp_path / "test.txt.gz")
        with gzip.open(gz_path, "wt") as f:
            f.write("gzip content")
        content = opt.read_file(path)
        assert content == "gzip content"

    def test_read_caches_result(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("data")
        opt.read_file(path)
        assert path in opt._read_cache
        opt.read_file(path)
        assert opt._stats.cache_hits == 1
        assert opt._stats.cache_misses == 1


class TestFileOptimizerFlush:
    """Test flush_all method."""

    def test_flush_all(self, tmp_path):
        opt = FileOptimizer()
        path1 = str(tmp_path / "a.txt")
        path2 = str(tmp_path / "b.txt")
        opt.write_file(path1, "content1", immediate=False)
        opt.write_file(path2, "content2", immediate=False)
        opt.flush_all()
        assert Path(path1).read_text() == "content1"
        assert Path(path2).read_text() == "content2"
        assert len(opt._write_cache) == 0

    def test_flush_all_with_compression(self, tmp_path):
        opt = FileOptimizer(enable_compression=True, compression_threshold=5)
        path = str(tmp_path / "big.txt")
        opt.write_file(path, "x" * 2000, immediate=False)
        opt.flush_all()
        assert Path(path).exists()
        gz_path = Path(path + ".gz")
        assert gz_path.exists()
        assert opt._stats.compressed_files == 1

    def test_flush_empty_cache(self, tmp_path):
        opt = FileOptimizer()
        opt.flush_all()
        assert len(opt._write_cache) == 0


class TestFileOptimizerCache:
    """Test cache operations."""

    def test_clear_cache(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("data")
        opt.read_file(path)
        opt.write_file(str(tmp_path / "other.txt"), "x", immediate=False)
        opt.clear_cache()
        assert len(opt._read_cache) == 0
        assert len(opt._write_cache) == 0

    def test_get_stats(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("data")
        opt.read_file(path)
        stats = opt.get_stats()
        assert stats.reads == 1
        assert stats.cache_misses == 1

    def test_get_stats_is_copy(self, tmp_path):
        opt = FileOptimizer()
        stats1 = opt.get_stats()
        stats1.reads = 999
        stats2 = opt.get_stats()
        assert stats2.reads == 0

    def test_get_cache_info_empty(self):
        opt = FileOptimizer()
        info = opt.get_cache_info()
        assert info["cached_files"] == 0

    def test_get_cache_info(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        Path(path).write_text("data")
        opt.read_file(path)
        info = opt.get_cache_info()
        assert info["cached_files"] == 1

    def test_stats_after_write_and_read(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        opt.write_file(path, "hello", immediate=True)
        opt.read_file(path)
        opt.read_file(path)
        stats = opt.get_stats()
        assert stats.writes == 1
        assert stats.reads == 2
        assert stats.cache_hits == 1
        assert stats.cache_misses == 1


class TestFileOptimizerDelete:
    """Test delete_file method."""

    def test_delete_existing_file(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "del.txt")
        Path(path).write_text("bye")
        opt.read_file(path)
        opt.delete_file(path)
        assert not Path(path).exists()
        assert path not in opt._read_cache

    def test_delete_nonexistent_file(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "nope.txt")
        opt.delete_file(path)

    def test_delete_with_gzip(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "test.txt")
        gz_path = Path(path + ".gz")
        with gzip.open(str(gz_path), "wt") as f:
            f.write("data")
        opt.delete_file(path)
        assert not gz_path.exists()

    def test_delete_cached_file(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "cached.txt")
        Path(path).write_text("data")
        opt.read_file(path)
        opt.delete_file(path)
        assert path not in opt._read_cache

    def test_delete_nonexistent_gzip(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "nogz.txt")
        Path(path).write_text("data")
        opt.delete_file(path)
        assert not Path(path).exists()
        assert not Path(path + ".gz").exists()

    def test_delete_file_not_in_cache(self, tmp_path):
        opt = FileOptimizer()
        path = str(tmp_path / "nocache.txt")
        Path(path).write_text("data")
        opt.delete_file(path)
        assert not Path(path).exists()


class TestGetFileOptimizer:
    """Test global singleton."""

    def test_get_file_optimizer(self):
        import core.file_optimizer as mod

        mod._file_optimizer_instance = None
        opt = get_file_optimizer()
        assert isinstance(opt, FileOptimizer)
        mod._file_optimizer_instance = None

    def test_get_file_optimizer_cached(self):
        import core.file_optimizer as mod

        opt1 = get_file_optimizer()
        opt2 = get_file_optimizer()
        assert opt1 is opt2
        mod._file_optimizer_instance = None
