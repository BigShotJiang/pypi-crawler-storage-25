import asyncio
from unittest.mock import AsyncMock, patch

import pytest

from core.async_executor import (
    AsyncAgentExecutor,
    ExecutionMetrics,
    agent_context,
    get_async_executor,
    reset_async_executor,
)


class TestExecutionMetrics:
    def test_default_values(self):
        m = ExecutionMetrics(agent_name="test", start_time=1.0)
        assert m.end_time is None
        assert m.duration == 0.0
        assert m.success is False
        assert m.error is None
        assert m.memory_start is None
        assert m.memory_end is None


class TestAsyncAgentExecutorInit:
    def test_default_config(self):
        executor = AsyncAgentExecutor()
        assert executor.max_concurrent == 3
        assert executor.memory_limit_mb == 2048
        assert executor.enable_metrics is True
        assert executor.active_count == 0

    def test_custom_config(self):
        executor = AsyncAgentExecutor(max_concurrent=5, memory_limit_mb=1024, enable_metrics=False)
        assert executor.max_concurrent == 5
        assert executor.memory_limit_mb == 1024
        assert executor.enable_metrics is False


class TestAsyncAgentExecutorRegistration:
    def test_register_agent(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("test_agent", AsyncMock())
        assert "test_agent" in executor.agent_registry

    def test_get_registered_agents(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock())
        executor.register_agent("a2", AsyncMock())
        agents = executor.get_registered_agents()
        assert "a1" in agents
        assert "a2" in agents


class TestAsyncAgentExecutorExecute:
    @pytest.mark.asyncio
    async def test_execute_success(self):
        executor = AsyncAgentExecutor()
        mock_func = AsyncMock(return_value="result")
        executor.register_agent("agent1", mock_func)
        result = await executor.execute("agent1", "test prompt")
        assert result == "result"

    @pytest.mark.asyncio
    async def test_execute_unregistered_agent(self):
        executor = AsyncAgentExecutor()
        with pytest.raises(ValueError, match="not registered"):
            await executor.execute("ghost", "prompt")

    @pytest.mark.asyncio
    async def test_execute_stores_metrics(self):
        executor = AsyncAgentExecutor(enable_metrics=True)
        executor.register_agent("agent1", AsyncMock(return_value="ok"))
        await executor.execute("agent1", "prompt")
        metrics = executor.get_metrics("agent1")
        assert metrics["count"] == 1
        assert metrics["successful"] == 1
        assert metrics["success_rate"] == 100.0

    @pytest.mark.asyncio
    async def test_execute_failure_does_not_store_metrics(self):
        executor = AsyncAgentExecutor(enable_metrics=True)

        async def failing_func(prompt, **kw):
            raise ValueError("test error")

        executor.register_agent("agent1", failing_func)
        with pytest.raises(RuntimeError):
            await executor.execute("agent1", "prompt")
        metrics = executor.get_metrics("agent1")
        assert metrics["count"] == 0

    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        executor = AsyncAgentExecutor()

        async def slow_func(prompt, **kw):
            await asyncio.sleep(100)

        executor.register_agent("agent1", slow_func)
        with pytest.raises(RuntimeError, match="timed out"):
            await executor.execute("agent1", "prompt", timeout=1)

    @pytest.mark.asyncio
    async def test_execute_updates_active_count(self):
        executor = AsyncAgentExecutor()
        assert executor.get_active_count() == 0
        executor.register_agent("agent1", AsyncMock(return_value="ok"))
        await executor.execute("agent1", "prompt")
        assert executor.get_active_count() == 0

    @pytest.mark.asyncio
    async def test_execute_with_kwargs(self):
        executor = AsyncAgentExecutor()
        mock_func = AsyncMock(return_value="result")
        executor.register_agent("agent1", mock_func)
        await executor.execute("agent1", "prompt", extra_arg="value")
        mock_func.assert_called_once_with("prompt", extra_arg="value")

    @pytest.mark.asyncio
    async def test_execute_no_metrics(self):
        executor = AsyncAgentExecutor(enable_metrics=False)
        executor.register_agent("agent1", AsyncMock(return_value="ok"))
        await executor.execute("agent1", "prompt")
        assert executor.metrics == {}


class TestAsyncAgentExecutorExecuteMany:
    @pytest.mark.asyncio
    async def test_execute_many_parallel(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        executor.register_agent("a2", AsyncMock(return_value="r2"))
        results = await executor.execute_many([("a1", "p1"), ("a2", "p2")])
        assert "r1" in results
        assert "r2" in results

    @pytest.mark.asyncio
    async def test_execute_many_stop_on_error(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))

        async def fail(prompt, **kw):
            raise ValueError("fail")

        executor.register_agent("a2", fail)
        executor.register_agent("a3", AsyncMock(return_value="r3"))
        results = await executor.execute_many(
            [("a1", "p1"), ("a2", "p2"), ("a3", "p3")], stop_on_error=True
        )
        assert "r1" in results
        assert any("ERROR" in r for r in results)
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_execute_many_no_stop_on_error(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))

        async def fail(prompt, **kw):
            raise ValueError("fail")

        executor.register_agent("a2", fail)
        results = await executor.execute_many([("a1", "p1"), ("a2", "p2")], stop_on_error=False)
        assert len(results) == 2
        assert "r1" in results
        assert any("ERROR" in r for r in results)


class TestAsyncAgentExecutorMetrics:
    def test_get_metrics_empty(self):
        executor = AsyncAgentExecutor()
        metrics = executor.get_metrics()
        assert metrics["count"] == 0
        assert metrics["avg_duration"] == 0
        assert metrics["success_rate"] == 0

    def test_get_metrics_by_agent(self):
        executor = AsyncAgentExecutor()
        metrics = executor.get_metrics("nonexistent")
        assert metrics["count"] == 0

    def test_reset_metrics(self):
        executor = AsyncAgentExecutor()
        executor.metrics["a"] = [ExecutionMetrics(agent_name="a", start_time=1.0)]
        executor.reset_metrics()
        assert executor.metrics == {}

    @pytest.mark.asyncio
    async def test_metrics_all_agents(self):
        executor = AsyncAgentExecutor(enable_metrics=True)
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        executor.register_agent("a2", AsyncMock(return_value="r2"))
        await executor.execute("a1", "p1")
        await executor.execute("a2", "p2")
        metrics = executor.get_metrics()
        assert metrics["count"] == 2
        assert metrics["successful"] == 2
        assert metrics["success_rate"] == 100.0
        assert metrics["avg_duration"] > 0
        assert metrics["min_duration"] >= 0
        assert metrics["max_duration"] >= 0


class TestAsyncAgentExecutorContextManager:
    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with AsyncAgentExecutor() as executor:
            assert isinstance(executor, AsyncAgentExecutor)


class TestAsyncAgentExecutorParallel:
    @pytest.mark.asyncio
    async def test_execute_parallel(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        executor.register_agent("a2", AsyncMock(return_value="r2"))
        agents = [
            {"name": "a1", "prompt": "p1", "dependencies": []},
            {"name": "a2", "prompt": "p2", "dependencies": ["a1"]},
        ]
        results = await executor.execute_parallel(agents)
        assert "a1" in results
        assert "a2" in results

    @pytest.mark.asyncio
    async def test_execute_parallel_with_ids(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        agents = [
            {"name": "a1", "prompt": "p1", "id": "custom_id"},
        ]
        results = await executor.execute_parallel(agents)
        assert "a1" in results

    @pytest.mark.asyncio
    async def test_execute_parallel_error_result(self):
        executor = AsyncAgentExecutor()

        async def fail(prompt, **kw):
            raise ValueError("oops")

        executor.register_agent("fail_agent", fail)
        agents = [{"name": "fail_agent", "prompt": "p1"}]
        results = await executor.execute_parallel(agents)
        assert "ERROR" in results["fail_agent"]

    @pytest.mark.asyncio
    async def test_execute_parallel_with_metadata(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        agents = [
            {"name": "a1", "prompt": "p1", "metadata": {"key": "val"}},
        ]
        results = await executor.execute_parallel(agents)
        assert "a1" in results

    @pytest.mark.asyncio
    async def test_execute_parallel_with_priority(self):
        executor = AsyncAgentExecutor()
        executor.register_agent("a1", AsyncMock(return_value="r1"))
        agents = [{"name": "a1", "prompt": "p1", "priority": 10}]
        results = await executor.execute_parallel(agents)
        assert "a1" in results


class TestGlobalExecutor:
    def test_get_async_executor(self):
        reset_async_executor()
        executor = get_async_executor()
        assert isinstance(executor, AsyncAgentExecutor)

    def test_get_async_executor_same(self):
        with patch("core.async_executor.asyncio.create_task"):
            reset_async_executor()
            e1 = get_async_executor()
            e2 = get_async_executor()
            assert e1 is e2

    def test_get_async_executor_force_new(self):
        with patch("core.async_executor.asyncio.create_task"):
            reset_async_executor()
            e1 = get_async_executor()
            e2 = get_async_executor(force_new=True)
            assert e1 is not e2

    def test_reset_async_executor(self):
        with patch("core.async_executor.asyncio.create_task"):
            get_async_executor()
            reset_async_executor()
            from core.async_executor import _executor

            assert _executor is None


class TestAgentContext:
    @pytest.mark.asyncio
    async def test_agent_context_set_during_execution(self):
        executor = AsyncAgentExecutor()
        captured_ctx = {}

        async def capture_func(prompt, **kw):
            captured_ctx.update(agent_context.get())
            return "ok"

        executor.register_agent("ctx_agent", capture_func)
        await executor.execute("ctx_agent", "test prompt", extra="data")
        assert captured_ctx["agent_name"] == "ctx_agent"
        assert captured_ctx["prompt"] == "test prompt"
        assert captured_ctx["kwargs"]["extra"] == "data"

    @pytest.mark.asyncio
    async def test_agent_context_reset_after_execution(self):
        executor = AsyncAgentExecutor()
        default = agent_context.get()

        async def noop(prompt, **kw):
            return "ok"

        executor.register_agent("noop", noop)
        await executor.execute("noop", "prompt")
        assert agent_context.get() == default
