"""Tests for agent system components."""

from unittest.mock import MagicMock, Mock

import pytest

from core.agent import Agent, AgentCategory, AgentContext
from core.agent_executor import AgentExecutor
from core.agent_loader import AgentLoader
from core.agent_registry import AgentRegistry
from core.llm_client import MultiLLMClient
from core.storage import FileStorage, StorageConfig


@pytest.fixture
def sample_agent_content():
    """Sample agent definition content."""
    return """---
name: test_agent
version: 1.0.0
description: Test agent for unit testing
category: analytical
input:
  - user_concept
output:
  - META.yaml
dependencies: []
---

# Test Agent

This is a test agent for unit testing purposes.
"""


@pytest.fixture
def temp_agents_dir(tmp_path):
    """Create temporary agents directory."""
    agents_dir = tmp_path / "agents"
    agents_dir.mkdir()
    return agents_dir


@pytest.fixture
def agent_loader(temp_agents_dir):
    """Create agent loader fixture."""
    return AgentLoader(temp_agents_dir)


@pytest.fixture
def sample_agent(temp_agents_dir, sample_agent_content):
    """Create sample agent file."""
    agent_file = temp_agents_dir / "test_agent.md"
    agent_file.write_text(sample_agent_content)
    return agent_file


class TestAgentModel:
    """Tests for Agent data model."""

    def test_create_agent(self):
        """Test creating an agent."""
        agent = Agent(
            name="test_agent",
            version="1.0.0",
            description="Test agent",
            category=AgentCategory.ANALYTICAL,
            input_schema=["input1"],
            output_schema=["output1"],
            dependencies=[],
            instructions="Test instructions",
        )

        assert agent.name == "test_agent"
        assert agent.category == AgentCategory.ANALYTICAL
        assert len(agent.input_schema) == 1

    def test_agent_category_enum(self):
        """Test agent category enum."""
        assert AgentCategory.ANALYTICAL == "analytical"
        assert AgentCategory.CREATIVE == "creative"
        assert AgentCategory.VALIDATION == "validation"


class TestAgentLoader:
    """Tests for AgentLoader."""

    def test_load_agent(self, agent_loader, sample_agent):
        """Test loading agent from file."""
        agent = agent_loader.load_agent(sample_agent)

        assert agent.name == "test_agent"
        assert agent.version == "1.0.0"
        assert agent.description == "Test agent for unit testing"
        assert agent.category == AgentCategory.ANALYTICAL
        assert "user_concept" in agent.input_schema
        assert "META.yaml" in agent.output_schema

    def test_parse_agent(self, agent_loader, sample_agent_content):
        """Test parsing agent from content."""
        agent = agent_loader.parse_agent(sample_agent_content)

        assert agent.name == "test_agent"
        assert agent.instructions.strip().startswith("# Test Agent")

    def test_load_nonexistent_file(self, agent_loader):
        """Test loading nonexistent file."""
        with pytest.raises(FileNotFoundError):
            agent_loader.load_agent("nonexistent.md")

    def test_invalid_frontmatter(self, agent_loader, temp_agents_dir):
        """Test invalid YAML frontmatter."""
        invalid_file = temp_agents_dir / "invalid.md"
        invalid_file.write_text("No frontmatter here")

        with pytest.raises(ValueError):
            agent_loader.load_agent(invalid_file)

    def test_missing_required_fields(self, agent_loader, temp_agents_dir):
        """Test missing required fields in frontmatter."""
        invalid_file = temp_agents_dir / "invalid.md"
        invalid_file.write_text("---\nname: test\n---\n\nInstructions")

        with pytest.raises(ValueError):
            agent_loader.load_agent(invalid_file)

    def test_load_all_agents(self, agent_loader, sample_agent):
        """Test loading all agents."""
        agents = agent_loader.load_all_agents()

        assert len(agents) == 1
        assert agents[0].name == "test_agent"


class TestAgentRegistry:
    """Tests for AgentRegistry."""

    @pytest.fixture
    def registry(self, temp_agents_dir, sample_agent):
        """Create agent registry fixture."""
        return AgentRegistry(temp_agents_dir)

    def test_get_agent(self, registry):
        """Test getting agent by name."""
        agent = registry.get_agent("test_agent")

        assert agent is not None
        assert agent.name == "test_agent"

    def test_get_nonexistent_agent(self, registry):
        """Test getting nonexistent agent."""
        agent = registry.get_agent("nonexistent")

        assert agent is None

    def test_get_all_agents(self, registry):
        """Test getting all agents."""
        agents = registry.get_all_agents()

        assert len(agents) == 1

    def test_get_agents_by_category(self, registry):
        """Test getting agents by category."""
        agents = registry.get_agents_by_category(AgentCategory.ANALYTICAL)

        assert len(agents) == 1
        assert agents[0].category == AgentCategory.ANALYTICAL

    def test_validate_dependencies(self, registry, temp_agents_dir):
        """Test dependency validation."""
        missing = registry.validate_dependencies("test_agent")

        assert len(missing) == 0

    def test_agent_exists(self, registry):
        """Test checking if agent exists."""
        assert registry.agent_exists("test_agent")
        assert not registry.agent_exists("nonexistent")

    def test_get_execution_order(self, registry):
        """Test getting execution order."""
        order = registry.get_execution_order(["test_agent"])

        assert "test_agent" in order

    def test_reload_agent(self, registry, sample_agent):
        """Test reloading agent."""
        agent = registry.reload_agent("test_agent")

        assert agent is not None
        assert agent.name == "test_agent"


class TestAgentExecutor:
    """Tests for AgentExecutor."""

    @pytest.fixture
    def mock_llm_client(self):
        """Create mock LLM client."""
        client = Mock(spec=MultiLLMClient)
        client.generate.return_value = "Test response"
        return client

    @pytest.fixture
    def mock_storage(self, tmp_path):
        """Create mock storage backend."""
        return FileStorage(StorageConfig(base_path=str(tmp_path)))

    @pytest.fixture
    def agent_executor(self, mock_llm_client, mock_storage, tmp_path):
        """Create agent executor fixture."""
        return AgentExecutor(llm_client=mock_llm_client, storage=mock_storage, work_dir=tmp_path)

    @pytest.fixture
    def sample_agent(self):
        """Create sample agent."""
        return Agent(
            name="test_agent",
            version="1.0.0",
            description="Test agent",
            category=AgentCategory.ANALYTICAL,
            input_schema=["input"],
            output_schema=["output"],
            dependencies=[],
            instructions="Process the input",
        )

    @pytest.fixture
    def agent_context(self):
        """Create agent context."""
        return AgentContext(
            project_name="test_project",
            variables={},
            previous_outputs={},
            config={"provider": "openai", "model": "gpt-4-turbo-preview"},
        )

    def test_execute_agent(self, agent_executor, sample_agent, agent_context, mock_llm_client):
        """Test executing agent."""
        result = agent_executor.execute(
            agent=sample_agent, context=agent_context, input_data={"input": "Test input"}
        )

        assert result.success is True
        assert result.agent_name == "test_agent"
        assert result.output == "Test response"
        mock_llm_client.generate.assert_called_once()

    def test_execute_agent_failure(
        self, agent_executor, sample_agent, agent_context, mock_llm_client
    ):
        """Test agent execution failure."""
        mock_llm_client.generate.side_effect = Exception("LLM error")

        result = agent_executor.execute(
            agent=sample_agent, context=agent_context, input_data={"input": "Test input"}
        )

        assert result.success is False
        assert "LLM error" in result.error

    def test_construct_prompt(self, agent_executor, sample_agent, agent_context):
        """Test prompt construction."""
        prompt = agent_executor._construct_prompt(
            agent=sample_agent, context=agent_context, input_data={"input": "Test input"}
        )

        assert "test_agent" in prompt
        assert "Test input" in prompt
        assert "Process the input" in prompt

    def test_extract_output_variables(self, agent_executor, sample_agent):
        """Test extracting output variables."""
        response = "### output\nTest output content"

        outputs = agent_executor.extract_output_variables(response, sample_agent)

        assert "output" in outputs
        assert outputs["output"] == "Test output content"

    def test_construct_prompt_empty_input_data(self, agent_executor, sample_agent, agent_context):
        """Test prompt construction with empty input_data."""
        prompt = agent_executor._construct_prompt(
            agent=sample_agent, context=agent_context, input_data={}
        )
        assert "## Input" not in prompt
        assert "## Instructions" in prompt

    def test_construct_prompt_falsy_input_values(self, agent_executor, sample_agent, agent_context):
        """Test prompt construction with falsy values in input_data."""
        prompt = agent_executor._construct_prompt(
            agent=sample_agent,
            context=agent_context,
            input_data={"empty": "", "none_val": None, "zero": 0, "valid": "hello"},
        )
        assert "### empty" not in prompt
        assert "### none_val" not in prompt
        assert "### zero" not in prompt
        assert "### valid" in prompt
        assert "hello" in prompt

    def test_construct_prompt_with_previous_outputs(self, agent_executor, sample_agent):
        """Test prompt construction with previous outputs."""
        context = AgentContext(
            project_name="test_project",
            variables={},
            previous_outputs={"chapter_1": "Once upon a time..."},
            config={},
        )
        prompt = agent_executor._construct_prompt(
            agent=sample_agent, context=context, input_data={}
        )
        assert "## Previous Outputs" in prompt
        assert "chapter_1" in prompt
        assert "Once upon a time..." in prompt

    def test_construct_prompt_no_output_schema(self, agent_executor, agent_context):
        """Test prompt construction when agent has no output schema."""
        agent = Agent(
            name="test_agent",
            version="1.0.0",
            description="Test agent",
            category=AgentCategory.ANALYTICAL,
            input_schema=[],
            output_schema=[],
            dependencies=[],
            instructions="Do something",
        )
        prompt = agent_executor._construct_prompt(agent=agent, context=agent_context, input_data={})
        assert "Provide clear, structured output" in prompt

    def test_save_outputs_creates_project_dir(self, agent_executor, mock_storage):
        """Test that _save_outputs creates project dir if missing."""
        agent = Agent(
            name="test_agent",
            version="1.0.0",
            description="Test",
            category=AgentCategory.ANALYTICAL,
            input_schema=[],
            output_schema=[],
            dependencies=[],
            instructions="Do something",
        )
        context = AgentContext(
            project_name="new_project",
            variables={},
            previous_outputs={},
            config={},
        )
        result = agent_executor._save_outputs(agent, context, "response content")
        assert len(result) == 1
        assert "new_project" in result[0]

    def test_save_outputs_handles_write_error(self, agent_executor, mock_storage):
        """Test _save_outputs handles storage write failure gracefully."""
        agent = Agent(
            name="test_agent",
            version="1.0.0",
            description="Test",
            category=AgentCategory.ANALYTICAL,
            input_schema=[],
            output_schema=[],
            dependencies=[],
            instructions="Do something",
        )
        context = AgentContext(
            project_name="test_project",
            variables={},
            previous_outputs={},
            config={},
        )
        mock_storage.write_markdown = Mock(side_effect=PermissionError("no access"))
        result = agent_executor._save_outputs(agent, context, "response content")
        assert result == []

    def test_construct_system_message(self, agent_executor, sample_agent):
        """Test constructing system message from agent."""
        msg = agent_executor.construct_system_message(sample_agent)
        assert "test_agent" in msg
        assert "Test agent" in msg
        assert "Follow the provided instructions carefully." in msg

    def test_extract_output_variables_no_match(self, agent_executor, sample_agent):
        """Test extract_output_variables falls back to full response on no regex match."""
        response = "Some plain text without headers"
        outputs = agent_executor.extract_output_variables(response, sample_agent)
        assert "output" in outputs
        assert outputs["output"] == "Some plain text without headers"

    def test_extract_output_variables_empty_schema(self, agent_executor):
        """Test extract_output_variables with empty output_schema."""
        agent = Agent(
            name="test_agent",
            version="1.0.0",
            description="Test",
            category=AgentCategory.ANALYTICAL,
            input_schema=[],
            output_schema=[],
            dependencies=[],
            instructions="Do something",
        )
        response = "Some output text"
        outputs = agent_executor.extract_output_variables(response, agent)
        assert outputs == {"output": response}

    def test_execute_with_bus_no_context_bus(self, agent_executor, sample_agent):
        """Test execute_with_bus returns error when context_bus is None."""
        result = agent_executor.execute_with_bus(
            agent=sample_agent,
            provider="openai",
            model_config={"model": "gpt-4o"},
            project_name="test_project",
        )
        assert result.success is False
        assert "ContextBus not configured" in result.error

    def test_execute_with_bus_success(
        self, agent_executor, sample_agent, mock_llm_client, mock_storage, tmp_path
    ):
        """Test execute_with_bus with valid context_bus."""
        from core.context_bus import ContextBus

        mock_context_bus = MagicMock(spec=ContextBus)
        mock_context_bus.build_context.return_value = "Assembled context string"
        agent_executor.context_bus = mock_context_bus

        result = agent_executor.execute_with_bus(
            agent=sample_agent,
            provider="openai",
            model_config={"model": "gpt-4o", "temperature": 0.7, "max_tokens": 4000},
            project_name="test_project",
        )

        assert result.success is True
        assert result.metadata.get("context_bus") is True
        mock_context_bus.build_context.assert_called_once()
        mock_llm_client.generate.assert_called_once()

    def test_execute_with_bus_llm_error(
        self, agent_executor, sample_agent, mock_llm_client, mock_storage, tmp_path
    ):
        """Test execute_with_bus handles LLM errors."""
        from core.context_bus import ContextBus

        mock_context_bus = MagicMock(spec=ContextBus)
        mock_context_bus.build_context.return_value = "Context"
        agent_executor.context_bus = mock_context_bus
        mock_llm_client.generate.side_effect = Exception("API failure")

        result = agent_executor.execute_with_bus(
            agent=sample_agent,
            provider="openai",
            model_config={"model": "gpt-4o"},
            project_name="test_project",
        )

        assert result.success is False
        assert "API failure" in result.error

    def test_save_outputs_simple_creates_dirs(
        self, agent_executor, mock_llm_client, mock_storage, tmp_path
    ):
        """Test _save_outputs_simple creates project and reports directories."""
        from unittest.mock import MagicMock

        mock_response = MagicMock()
        mock_response.content = "Test output content"
        mock_llm_client.generate.return_value = mock_response

        result = agent_executor._save_outputs_simple("test_agent", "new_project", mock_response)

        assert len(result) == 1
        assert "new_project" in result[0]
        assert "reports" in result[0]

    def test_save_outputs_simple_handles_error(
        self, agent_executor, mock_llm_client, mock_storage, tmp_path
    ):
        """Test _save_outputs_simple handles storage errors gracefully."""
        from unittest.mock import MagicMock

        mock_response = MagicMock()
        mock_response.content = "Test content"
        mock_storage.write_markdown = Mock(side_effect=OSError("Disk full"))

        result = agent_executor._save_outputs_simple("test_agent", "test_project", mock_response)

        assert result == []

    def test_execute_with_bus_uses_model_config(
        self, agent_executor, sample_agent, mock_llm_client, mock_storage, tmp_path
    ):
        """Test execute_with_bus uses model config for LLM settings."""
        from core.context_bus import ContextBus

        mock_context_bus = MagicMock(spec=ContextBus)
        mock_context_bus.build_context.return_value = "Context"
        agent_executor.context_bus = mock_context_bus

        result = agent_executor.execute_with_bus(
            agent=sample_agent,
            provider="anthropic",
            model_config={
                "model": "claude-sonnet-4-20250514",
                "temperature": 0.5,
                "max_tokens": 8000,
            },
            project_name="test_project",
        )

        assert result.success is True
        assert result.metadata.get("provider") == "anthropic"
        assert result.metadata.get("model") == "claude-sonnet-4-20250514"


class TestAgentIntegration:
    """Integration tests for agent system."""

    @pytest.fixture
    def temp_agents_dir(self, tmp_path):
        """Create temporary agents directory with sample agents."""
        agents_dir = tmp_path / "agents"
        agents_dir.mkdir()

        agent_content = """---
name: integration_test_agent
version: 1.0.0
description: Integration test agent
category: analytical
input:
  - test_input
output:
  - test_output
dependencies: []
---

# Integration Test Agent

Process the test input and generate output.
"""
        agent_file = agents_dir / "integration_test_agent.md"
        agent_file.write_text(agent_content)

        return agents_dir

    def test_full_agent_workflow(self, temp_agents_dir):
        """Test full agent workflow from loading to execution."""
        loader = AgentLoader(temp_agents_dir)
        agent = loader.load_agent(temp_agents_dir / "integration_test_agent.md")

        assert agent.name == "integration_test_agent"

        registry = AgentRegistry(temp_agents_dir)
        assert registry.agent_exists("integration_test_agent")

        loaded_agent = registry.get_agent("integration_test_agent")
        assert loaded_agent.name == "integration_test_agent"
