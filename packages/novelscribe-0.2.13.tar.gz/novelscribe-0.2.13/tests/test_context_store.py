"""Unit tests for ContextStore — persistent artifact storage."""

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from core.context_store import (
    ArtifactCorruptedError,
    ArtifactFilter,
    ArtifactNotFoundError,
    ArtifactType,
    ContextArtifact,
    ContextSnapshot,
    ContextStore,
    ContextStoreConfig,
    ContextStoreError,
)


@pytest.fixture
def store_dir(tmp_path: Path) -> Path:
    d = tmp_path / "context"
    d.mkdir()
    return d


@pytest.fixture
def store(store_dir: Path) -> ContextStore:
    return ContextStore(store_dir, ContextStoreConfig(max_versions=5))


def _make_artifact(
    artifact_type: ArtifactType = "meta",
    source_agent: str = "test_agent",
    chapter_number: int | None = None,
    content: str = "test content",
) -> dict:
    return {
        "artifact_type": artifact_type,
        "content": content,
        "source_agent": source_agent,
        "chapter_number": chapter_number,
    }


class TestContextArtifact:
    def test_create_basic(self):
        now = datetime.now(timezone.utc)
        a = ContextArtifact(
            artifact_id="meta.1",
            artifact_type="meta",
            source_agent="discuss_agent",
            token_count=10,
            created_at=now,
            updated_at=now,
        )
        assert a.artifact_id == "meta.1"
        assert a.version == 1
        assert a.content == ""

    def test_create_with_chapter(self):
        now = datetime.now(timezone.utc)
        a = ContextArtifact(
            artifact_id="chapter.5",
            artifact_type="chapter",
            source_agent="writer_agent",
            token_count=500,
            chapter_number=5,
            created_at=now,
            updated_at=now,
        )
        assert a.chapter_number == 5

    def test_serialization_round_trip(self):
        now = datetime.now(timezone.utc)
        a = ContextArtifact(
            artifact_id="outline.1",
            artifact_type="outline",
            source_agent="outline_agent",
            token_count=200,
            metadata={"key": "value"},
            version=3,
            created_at=now,
            updated_at=now,
        )
        data = a.model_dump(mode="json")
        data["created_at"] = a.created_at.isoformat()
        data["updated_at"] = a.updated_at.isoformat()
        restored = ContextArtifact(**data)
        assert restored.artifact_id == a.artifact_id
        assert restored.version == a.version

    def test_all_artifact_types(self):
        now = datetime.now(timezone.utc)
        for atype in [
            "meta",
            "outline",
            "characters",
            "world",
            "chapter",
            "summary",
            "verification",
            "plan",
        ]:
            a = ContextArtifact(
                artifact_id=f"{atype}.1",
                artifact_type=atype,
                source_agent="test",
                token_count=1,
                created_at=now,
                updated_at=now,
            )
            assert a.artifact_type == atype


class TestArtifactFilter:
    def test_empty_filter(self):
        f = ArtifactFilter()
        assert f.artifact_type is None
        assert f.chapter_range is None

    def test_type_filter(self):
        f = ArtifactFilter(artifact_type="chapter")
        assert f.artifact_type == "chapter"

    def test_combined_filter(self):
        f = ArtifactFilter(
            artifact_type="chapter",
            chapter_range=(1, 10),
        )
        assert f.chapter_range == (1, 10)

    def test_summary_group_filter(self):
        f = ArtifactFilter(summary_group=2)
        assert f.summary_group == 2


class TestContextSnapshot:
    def test_create_snapshot(self):
        now = datetime.now(timezone.utc)
        s = ContextSnapshot(
            run_id="run-20260411-120000",
            created_at=now,
            phase="writing_phase",
            step="complete",
            artifact_ids=["meta.1", "outline.1"],
            total_chapters_completed=5,
        )
        assert s.run_id == "run-20260411-120000"
        assert len(s.artifact_ids) == 2
        assert s.total_chapters_completed == 5

    def test_snapshot_serialization(self):
        now = datetime.now(timezone.utc)
        s = ContextSnapshot(
            run_id="run-test",
            created_at=now,
            phase="outline_phase",
            step="complete",
            artifact_ids=[],
        )
        data = s.model_dump(mode="json")
        assert "run_id" in data
        assert "artifact_ids" in data


class TestContextStoreIngest:
    def test_ingest_creates_files(self, store: ContextStore, store_dir: Path):
        aid = store.ingest("meta", "My novel concept", "discuss_agent")
        assert aid == "meta.1"
        assert (store_dir / "artifacts" / "meta.1.json").exists()
        assert (store_dir / "artifacts" / "content" / "meta.1.md").exists()

    def test_ingest_returns_artifact_id(self, store: ContextStore):
        aid = store.ingest("outline", "Chapter outline", "outline_agent")
        assert aid == "outline.1"

    def test_ingest_chapter(self, store: ContextStore):
        aid = store.ingest("chapter", "Chapter content", "writer_agent", chapter_number=3)
        assert aid == "chapter.3"

    def test_ingest_summary_group(self, store: ContextStore):
        aid = store.ingest("summary", "Group summary", "summary_agent", chapter_number=7)
        assert "group-2" in aid

    def test_ingest_stores_content_separately(self, store: ContextStore, store_dir: Path):
        content = "# My Novel\n\nA great story about robots."
        store.ingest("meta", content, "discuss_agent")

        md_path = store_dir / "artifacts" / "content" / "meta.1.md"
        assert md_path.read_text() == content

        json_path = store_dir / "artifacts" / "meta.1.json"
        data = json.loads(json_path.read_text())
        assert "content" not in data

    def test_ingest_metadata_fields(self, store: ContextStore, store_dir: Path):
        store.ingest(
            "meta",
            "content",
            "discuss_agent",
            metadata={"genre": "sci-fi"},
        )
        data = json.loads((store_dir / "artifacts" / "meta.1.json").read_text())
        assert data["source_agent"] == "discuss_agent"
        assert data["version"] == 1
        assert data["metadata"]["genre"] == "sci-fi"
        assert "created_at" in data
        assert "updated_at" in data

    def test_ingest_populates_token_count(self, store: ContextStore):
        content = "This is a test sentence with several words in it."
        store.ingest("meta", content, "discuss_agent")
        artifact = store.get("meta.1")
        assert artifact.token_count > 0

    def test_ingest_creates_index(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "content", "discuss_agent")
        assert (store_dir / "index.json").exists()
        index = json.loads((store_dir / "index.json").read_text())
        assert "meta" in index

    def test_ingest_creates_directories(self, tmp_path: Path):
        store = ContextStore(tmp_path / "new_context")
        store.ingest("meta", "content", "discuss_agent")
        assert (tmp_path / "new_context" / "artifacts").exists()
        assert (tmp_path / "new_context" / "artifacts" / "content").exists()
        assert (tmp_path / "new_context" / "snapshots").exists()


class TestContextStoreGet:
    def test_get_returns_artifact_with_content(self, store: ContextStore):
        store.ingest("meta", "My novel", "discuss_agent")
        artifact = store.get("meta.1")
        assert artifact.artifact_id == "meta.1"
        assert artifact.content == "My novel"

    def test_get_nonexistent_raises(self, store: ContextStore):
        with pytest.raises(ArtifactNotFoundError):
            store.get("nonexistent.1")

    def test_get_latest_by_type(self, store: ContextStore):
        store.ingest("outline", "First outline", "outline_agent")
        result = store.get_latest_by_type("outline")
        assert result is not None
        assert result.content == "First outline"

    def test_get_latest_by_type_none(self, store: ContextStore):
        assert store.get_latest_by_type("chapter") is None


class TestContextStoreQuery:
    def test_query_by_type(self, store: ContextStore):
        store.ingest("meta", "meta content", "discuss_agent")
        store.ingest("outline", "outline content", "outline_agent")
        results = store.query(ArtifactFilter(artifact_type="meta"))
        assert len(results) == 1
        assert results[0].artifact_type == "meta"

    def test_query_chapter_range(self, store: ContextStore):
        for i in range(1, 6):
            store.ingest("chapter", f"Ch {i}", "writer_agent", chapter_number=i)
        results = store.get_chapter_range(2, 4)
        assert len(results) == 3
        chapters = {r.chapter_number for r in results}
        assert chapters == {2, 3, 4}

    def test_query_chapter_range_empty(self, store: ContextStore):
        store.ingest("chapter", "Ch 1", "writer_agent", chapter_number=1)
        results = store.get_chapter_range(5, 10)
        assert len(results) == 0

    def test_query_summary_group(self, store: ContextStore):
        for ch in [1, 2, 3, 6, 7, 11]:
            store.ingest("summary", f"Summary for ch {ch}", "agent", chapter_number=ch)
        results = store.get_summaries(chapter_group=1)
        assert len(results) >= 1
        for r in results:
            assert "group-1" in r.artifact_id

    def test_query_combined_filters(self, store: ContextStore):
        for i in range(1, 11):
            store.ingest("chapter", f"Ch {i}", "writer_agent", chapter_number=i)
        results = store.query(ArtifactFilter(artifact_type="chapter", chapter_range=(3, 7)))
        assert len(results) == 5

    def test_query_no_filter_returns_all(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.ingest("outline", "o", "b")
        results = store.query(ArtifactFilter())
        assert len(results) == 2

    def test_query_skips_corrupted(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "good", "a")
        bad_path = store_dir / "artifacts" / "meta.bad.json"
        bad_path.write_text("NOT JSON", encoding="utf-8")
        results = store.query(ArtifactFilter(artifact_type="meta"))
        assert len(results) == 1


class TestContextStoreVersioning:
    def test_second_ingest_creates_version(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "version 1", "discuss_agent")
        store.ingest("meta", "version 2", "discuss_agent")
        assert (store_dir / "artifacts" / "meta.1.v1.json").exists()
        assert (store_dir / "artifacts" / "content" / "meta.1.v1.md").exists()
        assert (store_dir / "artifacts" / "meta.1.json").exists()

    def test_version_content_preserved(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "first", "discuss_agent")
        store.ingest("meta", "second", "discuss_agent")
        v1_content = (store_dir / "artifacts" / "content" / "meta.1.v1.md").read_text()
        assert v1_content == "first"
        current = (store_dir / "artifacts" / "content" / "meta.1.md").read_text()
        assert current == "second"

    def test_version_number_increments(self, store: ContextStore):
        store.ingest("meta", "v1", "a")
        store.ingest("meta", "v2", "a")
        store.ingest("meta", "v3", "a")
        artifact = store.get("meta.1")
        assert artifact.version == 3

    def test_pruning_at_max_versions(self, store: ContextStore, store_dir: Path):
        for i in range(7):
            store.ingest("meta", f"v{i}", "a")
        v1_exists = (store_dir / "artifacts" / "meta.1.v1.json").exists()
        v2_exists = (store_dir / "artifacts" / "meta.1.v2.json").exists()
        v3_exists = (store_dir / "artifacts" / "meta.1.v3.json").exists()
        assert not v1_exists
        assert not v2_exists
        assert v3_exists

    def test_pruning_respects_config(self, tmp_path: Path):
        store = ContextStore(tmp_path / "ctx", ContextStoreConfig(max_versions=3))
        for i in range(5):
            store.ingest("meta", f"v{i}", "a")
        assert not (tmp_path / "ctx" / "artifacts" / "meta.1.v1.json").exists()
        assert not (tmp_path / "ctx" / "artifacts" / "meta.1.v2.json").exists()
        assert (tmp_path / "ctx" / "artifacts" / "meta.1.v3.json").exists()

    def test_created_at_preserved_across_versions(self, store: ContextStore):
        store.ingest("meta", "v1", "a")
        first = store.get("meta.1")
        store.ingest("meta", "v2", "a")
        second = store.get("meta.1")
        assert second.created_at == first.created_at
        assert second.updated_at >= first.updated_at

    def test_get_returns_latest_version(self, store: ContextStore):
        store.ingest("meta", "old", "a")
        store.ingest("meta", "new", "a")
        artifact = store.get("meta.1")
        assert artifact.content == "new"

    def test_version_index_tracked(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "v1", "a")
        store.ingest("meta", "v2", "a")
        index = json.loads((store_dir / "index.json").read_text())
        assert "meta.1" in index.get("_versions", {})
        assert 1 in index["_versions"]["meta.1"]


class TestContextStoreIndex:
    def test_index_created_on_first_ingest(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "c", "a")
        assert (store_dir / "index.json").exists()

    def test_index_contains_all_types(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m", "a")
        store.ingest("outline", "o", "b")
        store.ingest("chapter", "c", "w", chapter_number=1)
        index = json.loads((store_dir / "index.json").read_text())
        assert "meta" in index
        assert "outline" in index
        assert "chapter" in index

    def test_index_auto_rebuild_after_deletion(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "content", "a")
        (store_dir / "index.json").unlink()
        store2 = ContextStore(store_dir)
        result = store2.get_latest_by_type("meta")
        assert result is not None
        assert result.content == "content"

    def test_index_auto_rebuild_from_corrupted(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "content", "a")
        (store_dir / "index.json").write_text("CORRUPTED", encoding="utf-8")
        store2 = ContextStore(store_dir)
        assert store2.get_latest_by_type("meta") is not None

    def test_index_updates_immediately(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m1", "a")
        index_after_1 = json.loads((store_dir / "index.json").read_text())
        assert "meta.1" in index_after_1["meta"]
        store.ingest("outline", "o1", "b")
        index_after_2 = json.loads((store_dir / "index.json").read_text())
        assert "outline" in index_after_2

    def test_multiple_artifacts_same_type(self, store: ContextStore):
        store.ingest("chapter", "ch1", "w", chapter_number=1)
        store.ingest("chapter", "ch2", "w", chapter_number=2)
        store.ingest("chapter", "ch3", "w", chapter_number=3)
        idx = store.list_artifacts()
        assert len(idx.get("chapter", [])) == 3


class TestContextStoreSnapshot:
    def test_save_snapshot_creates_file(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m", "a")
        snap = store.save_snapshot("run-001", "writing_phase", "complete")
        assert (store_dir / "snapshots" / "run-001.json").exists()
        assert snap.run_id == "run-001"

    def test_snapshot_contains_all_artifact_ids(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.ingest("outline", "o", "b")
        snap = store.save_snapshot("run-002", "outline_phase", "complete")
        assert "meta.1" in snap.artifact_ids
        assert "outline.1" in snap.artifact_ids

    def test_snapshot_latest_symlink(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m", "a")
        store.save_snapshot("run-003", "phase1", "step1")
        symlink = store_dir / "snapshots" / "latest.json"
        assert symlink.is_symlink()

    def test_snapshot_latest_updates(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m", "a")
        store.save_snapshot("run-first", "p1", "s1")
        store.save_snapshot("run-second", "p2", "s2")
        symlink = store_dir / "snapshots" / "latest.json"
        target = symlink.resolve()
        assert "run-second" in target.name

    def test_get_snapshot_by_id(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.save_snapshot("run-010", "p1", "s1")
        loaded = store.get_snapshot("run-010")
        assert loaded is not None
        assert loaded.run_id == "run-010"

    def test_get_snapshot_latest(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.save_snapshot("run-020", "p1", "s1")
        loaded = store.get_snapshot()
        assert loaded is not None
        assert loaded.run_id == "run-020"

    def test_get_snapshot_nonexistent(self, store: ContextStore):
        assert store.get_snapshot("nonexistent") is None

    def test_get_snapshot_no_latest(self, store: ContextStore):
        assert store.get_snapshot() is None

    def test_restore_snapshot(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.ingest("outline", "o", "b")
        store.save_snapshot("run-030", "writing_phase", "complete")

        restored = store.restore_snapshot("run-030")
        assert restored is not None
        assert len(restored.artifact_ids) == 2

    def test_snapshot_survives_store_reinit(self, store_dir: Path):
        store1 = ContextStore(store_dir)
        store1.ingest("meta", "persistent content", "a")
        store1.save_snapshot("run-survive", "p1", "s1")

        store2 = ContextStore(store_dir)
        snap = store2.get_snapshot("run-survive")
        assert snap is not None
        artifact = store2.get("meta.1")
        assert artifact.content == "persistent content"

    def test_restore_snapshot_rebuilds_index(self, store_dir: Path):
        store1 = ContextStore(store_dir)
        store1.ingest("meta", "m", "a")
        store1.ingest("chapter", "ch1", "w", chapter_number=1)
        store1.save_snapshot("run-idx", "p1", "s1")

        store2 = ContextStore(store_dir)
        result = store2.restore_snapshot("run-idx")
        assert result is not None
        idx = store2.list_artifacts()
        assert "meta" in idx
        assert "chapter" in idx

    def test_restore_nonexistent_returns_none(self, store: ContextStore):
        assert store.restore_snapshot("nope") is None

    def test_snapshot_tracks_chapters_completed(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.save_snapshot("run-ch", "writing_phase", "complete", total_chapters_completed=10)
        loaded = store.get_snapshot("run-ch")
        assert loaded is not None
        assert loaded.total_chapters_completed == 10


class TestContextStoreDelete:
    def test_delete_removes_files(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "m", "a")
        assert store.delete("meta.1")
        assert not (store_dir / "artifacts" / "meta.1.json").exists()
        assert not (store_dir / "artifacts" / "content" / "meta.1.md").exists()

    def test_delete_removes_from_index(self, store: ContextStore):
        store.ingest("meta", "m", "a")
        store.delete("meta.1")
        idx = store.list_artifacts()
        assert "meta" not in idx or "meta.1" not in idx.get("meta", [])

    def test_delete_nonexistent(self, store: ContextStore):
        assert not store.delete("nope.1")

    def test_delete_with_versions(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "v1", "a")
        store.ingest("meta", "v2", "a")
        store.delete("meta.1")
        assert not (store_dir / "artifacts" / "meta.1.json").exists()
        assert not (store_dir / "artifacts" / "meta.1.v1.json").exists()


class TestContextStoreEdgeCases:
    def test_empty_store_operations(self, store: ContextStore):
        assert store.get_latest_by_type("meta") is None
        assert store.list_artifacts() == {}
        assert store.get_snapshot() is None
        assert store.query(ArtifactFilter()) == []

    def test_unicode_content(self, store: ContextStore):
        content = "中文小说内容 📚 emoji test"
        store.ingest("meta", content, "a")
        artifact = store.get("meta.1")
        assert artifact.content == content

    def test_large_content(self, store: ContextStore):
        content = "word " * 50000
        store.ingest("chapter", content, "w", chapter_number=1)
        artifact = store.get("chapter.1")
        assert len(artifact.content) > 200000

    def test_empty_content(self, store: ContextStore):
        store.ingest("meta", "", "a")
        artifact = store.get("meta.1")
        assert artifact.content == ""

    def test_content_file_missing_graceful(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "content", "a")
        (store_dir / "artifacts" / "content" / "meta.1.md").unlink()
        artifact = store.get("meta.1")
        assert artifact.content == ""

    def test_special_chars_in_metadata(self, store: ContextStore):
        store.ingest("meta", "c", "a", metadata={"path": "/foo/bar", "quote": 'he said "hi"'})
        artifact = store.get("meta.1")
        assert artifact.metadata["path"] == "/foo/bar"

    def test_concurrent_store_instances(self, store_dir: Path):
        s1 = ContextStore(store_dir)
        s2 = ContextStore(store_dir)
        s1.ingest("meta", "from s1", "a")
        artifact = s2.get("meta.1")
        assert artifact.content == "from s1"

    def test_init_creates_missing_dirs(self, tmp_path: Path):
        context_dir = tmp_path / "deep" / "nested" / "context"
        store = ContextStore(context_dir)
        store.ingest("meta", "c", "a")
        assert context_dir.exists()

    def test_error_hierarchy(self):
        assert issubclass(ArtifactNotFoundError, ContextStoreError)
        assert issubclass(ArtifactCorruptedError, ContextStoreError)

    def test_summary_group_calculation(self, store: ContextStore):
        assert store._make_artifact_id("summary", 1) == "summary.group-1"
        assert store._make_artifact_id("summary", 5) == "summary.group-1"
        assert store._make_artifact_id("summary", 6) == "summary.group-2"
        assert store._make_artifact_id("summary", 10) == "summary.group-2"
        assert store._make_artifact_id("summary", 11) == "summary.group-3"

    def test_make_artifact_id_with_chapter(self, store: ContextStore):
        assert store._make_artifact_id("chapter", 5) == "chapter.5"

    def test_make_artifact_id_without_chapter(self, store: ContextStore):
        assert store._make_artifact_id("meta") == "meta.1"

    def test_no_tmp_files_left(self, store: ContextStore, store_dir: Path):
        store.ingest("meta", "c", "a")
        tmp_files = list(store_dir.rglob("*.tmp"))
        assert len(tmp_files) == 0
