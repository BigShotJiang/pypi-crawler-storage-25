"""Integration tests for ContextBus — full lifecycle from ingest to context delivery."""

from unittest.mock import MagicMock

import pytest

from core.context_bus import ContextBus


@pytest.fixture
def tmp_project(tmp_path):
    project_path = tmp_path / "test_project"
    project_path.mkdir()
    return project_path


@pytest.fixture
def bus(tmp_project):
    return ContextBus(project_path=tmp_project)


class TestContextBusInit:
    def test_creates_store_directory(self, tmp_project):
        ContextBus(project_path=tmp_project)
        assert (tmp_project / "context").exists()

    def test_with_llm_client(self, tmp_project):
        mock_client = MagicMock()
        bus = ContextBus(project_path=tmp_project, llm_client=mock_client)
        assert bus.compressor is not None

    def test_with_agent_loader(self, tmp_project):
        mock_loader = MagicMock()
        bus = ContextBus(project_path=tmp_project, agent_loader=mock_loader)
        assert bus.agent_loader is mock_loader


class TestIngest:
    def test_ingest_returns_artifact_id(self, bus):
        aid = bus.ingest("outline", "An outline of the novel", source_agent="outline_agent")
        assert aid is not None
        assert isinstance(aid, str)

    def test_ingest_multiple_artifacts(self, bus):
        ids = []
        for i in range(5):
            aid = bus.ingest(
                "chapter", f"Chapter {i} content", source_agent="writer", chapter_number=i
            )
            ids.append(aid)
        assert len(set(ids)) == 5

    def test_ingest_with_metadata(self, bus):
        aid = bus.ingest(
            "characters",
            "Character descriptions",
            source_agent="character_agent",
            metadata={"version": 2},
        )
        assert aid is not None

    def test_ingest_persists_to_disk(self, bus, tmp_project):
        bus.ingest("meta", "Project metadata", source_agent="genre_agent")
        artifacts_dir = tmp_project / "context" / "artifacts"
        assert artifacts_dir.exists()


class TestBuildContext:
    def test_build_context_returns_string(self, bus):
        bus.ingest("outline", "A grand outline", source_agent="outline_agent")
        bus.ingest("meta", "Genre: Fantasy", source_agent="genre_agent")

        result = bus.build_context(
            agent_name="writer",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert isinstance(result, str)

    def test_build_context_with_empty_store(self, bus):
        result = bus.build_context(
            agent_name="writer",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert isinstance(result, str)

    def test_build_context_includes_ingested_content(self, bus):
        unique_content = "UNIQUE_OUTLINE_CONTENT_12345"
        bus.ingest("outline", unique_content, source_agent="outline_agent")

        result = bus.build_context(
            agent_name="writer",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert unique_content in result

    def test_build_context_respects_budget(self, bus):
        for i in range(20):
            bus.ingest("chapter", f"Chapter {i} " * 500, source_agent="writer", chapter_number=i)

        result = bus.build_context(
            agent_name="writer",
            provider="openai",
            model_config={"max_tokens": 500},
        )
        from core.token_estimator import TokenEstimator

        tokens = TokenEstimator.estimate_tokens(result)
        assert tokens <= 550

    def test_build_context_with_metadata(self, bus):
        bus.ingest("outline", "Outline text", source_agent="outline_agent")
        result = bus.build_context_with_metadata(
            agent_name="writer",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert hasattr(result, "context_str")
        assert hasattr(result, "compressed_tokens")
        assert hasattr(result, "tier_used")


class TestSnapshotLifecycle:
    def test_save_and_restore_snapshot(self, bus):
        bus.ingest("outline", "Outline v1", source_agent="outline_agent")
        bus.ingest("meta", "Meta info", source_agent="genre_agent")

        snapshot = bus.save_snapshot(run_id="test-run", phase="outline_phase", step="complete")
        assert snapshot is not None
        assert snapshot.phase == "outline_phase"

        restored = bus.restore_snapshot(run_id="test-run")
        assert restored is not None
        assert restored.phase == "outline_phase"

    def test_restore_latest_snapshot(self, bus):
        bus.save_snapshot(run_id="run-1", phase="phase-1", step="s1")
        bus.save_snapshot(run_id="run-2", phase="phase-2", step="s2")

        restored = bus.restore_snapshot()
        assert restored is not None
        assert restored.phase == "phase-2"

    def test_restore_nonexistent_returns_none(self, bus):
        result = bus.restore_snapshot(run_id="nonexistent")
        assert result is None


class TestEndToEndPipeline:
    def test_full_pipeline_lifecycle(self, bus):
        bus.ingest("meta", "Genre: Science Fiction", source_agent="genre_agent")
        bus.ingest(
            "world", "World building details for a sci-fi universe", source_agent="world_agent"
        )
        bus.ingest("characters", "Main character: Jane Doe", source_agent="character_agent")
        bus.ingest("outline", "Chapter by chapter outline", source_agent="outline_agent")

        snapshot = bus.save_snapshot(run_id="pipeline-1", phase="outline_phase", step="complete")
        assert snapshot is not None

        bus.ingest("chapter", "Chapter 1 content here", source_agent="writer", chapter_number=1)

        context = bus.build_context(
            agent_name="editor",
            provider="openai",
            model_config={"max_tokens": 2000},
        )
        assert isinstance(context, str)
        assert len(context) > 0

        bus.save_snapshot(run_id="pipeline-1", phase="writing_phase", step="chapter_1")

        restored = bus.restore_snapshot(run_id="pipeline-1")
        assert restored is not None
        assert restored.phase == "writing_phase"

    def test_multi_run_isolation(self, tmp_project):
        bus1 = ContextBus(project_path=tmp_project)
        bus1.ingest("outline", "Run 1 outline", source_agent="agent1")
        bus1.save_snapshot(run_id="run-1", phase="phase-1", step="s1")

        bus2 = ContextBus(project_path=tmp_project)
        bus2.ingest("outline", "Run 2 outline", source_agent="agent2")
        bus2.save_snapshot(run_id="run-2", phase="phase-2", step="s2")

        restored1 = bus2.restore_snapshot(run_id="run-1")
        restored2 = bus2.restore_snapshot(run_id="run-2")
        assert restored1.phase == "phase-1"
        assert restored2.phase == "phase-2"


class TestDefaultSchema:
    def test_default_schema_used_when_no_agent_loader(self, bus):
        result = bus.build_context(
            agent_name="unknown_agent",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert isinstance(result, str)

    def test_default_schema_used_when_agent_loader_fails(self, tmp_project):
        mock_loader = MagicMock()
        mock_loader.reload_agent.side_effect = Exception("not found")
        bus = ContextBus(project_path=tmp_project, agent_loader=mock_loader)

        result = bus.build_context(
            agent_name="missing_agent",
            provider="openai",
            model_config={"max_tokens": 4000},
        )
        assert isinstance(result, str)
