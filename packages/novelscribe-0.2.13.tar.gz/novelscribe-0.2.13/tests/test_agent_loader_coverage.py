from pathlib import Path

import pytest
import yaml

from core.agent import AgentCategory
from core.agent_loader import AgentLoader
from core.language_config import LanguageCode


def _agent_md(name="test_agent", description="Test agent", category="analytical", **extra):
    frontmatter = {"name": name, "description": description, "category": category}
    frontmatter.update(extra)
    fm = yaml.safe_dump(frontmatter, default_flow_style=False)
    return f"---\n{fm}\n---\nYou are an agent."


def _write_file(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


class TestAgentLoaderInit:
    def test_init_with_string_path(self):
        loader = AgentLoader("/path/to/agents")
        assert isinstance(loader.agents_dir, Path)
        assert str(loader.agents_dir) == "/path/to/agents"

    def test_init_with_path_object(self):
        loader = AgentLoader(Path("/path/to/agents"))
        assert isinstance(loader.agents_dir, Path)

    def test_default_language(self):
        loader = AgentLoader("/path/to/agents")
        assert loader.language == LanguageCode.EN

    def test_custom_language(self):
        loader = AgentLoader("/path/to/agents", LanguageCode.ZH_CN)
        assert loader.language == LanguageCode.ZH_CN


class TestLoadAgent:
    def test_load_agent_file_not_found(self):
        loader = AgentLoader("/path/to/agents")
        with pytest.raises(FileNotFoundError, match="Agent file not found"):
            loader.load_agent("/nonexistent/file.md")

    def test_load_agent_empty_file(self, tmp_path):
        agent_file = tmp_path / "test.md"
        agent_file.write_text("")
        loader = AgentLoader(str(tmp_path))
        with pytest.raises(ValueError, match="must start with YAML frontmatter"):
            loader.load_agent(agent_file)

    def test_load_agent_from_file(self, tmp_path):
        _write_file(
            tmp_path / "writer.md", _agent_md(name="writer", input=["prompt"], output=["content"])
        )
        loader = AgentLoader(str(tmp_path))
        agent = loader.load_agent(tmp_path / "writer.md")
        assert agent.name == "writer"
        assert agent.category == AgentCategory.ANALYTICAL


class TestParseAgent:
    def test_parse_agent_missing_frontmatter(self):
        loader = AgentLoader("/path/to/agents")
        with pytest.raises(ValueError, match="must start with YAML frontmatter"):
            loader.parse_agent("Just plain text content")

    def test_parse_agent_incomplete_frontmatter(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\nname: test_agent\n---\n"
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_agent(content)

    def test_parse_agent_no_closing_frontmatter(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\nname: test_agent\ndescription: Test\ncategory: analytical"
        with pytest.raises(ValueError, match="must have YAML frontmatter and body"):
            loader.parse_agent(content)

    def test_parse_agent_invalid_yaml(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\nname: test_agent\ninvalid: yaml: content\n---\nInstructions"
        with pytest.raises(ValueError, match="Invalid YAML frontmatter"):
            loader.parse_agent(content)

    def test_parse_agent_yaml_not_dict(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\n- list item\n- another item\n---\nInstructions"
        with pytest.raises(ValueError, match="YAML frontmatter must be a dictionary"):
            loader.parse_agent(content)

    def test_parse_agent_missing_required_field(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\nname: test_agent\ndescription: Test description\n---\nInstructions"
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_agent(content)

    def test_parse_agent_missing_name(self):
        loader = AgentLoader("/path/to/agents")
        content = "---\ndescription: desc\ncategory: creative\n---\nbody"
        with pytest.raises(ValueError, match="Missing required field"):
            loader.parse_agent(content)

    def test_parse_agent_invalid_category(self):
        loader = AgentLoader("/path/to/agents")
        content = (
            "---\nname: test_agent\ndescription: Test\ncategory: invalid_cat\n---\nInstructions"
        )
        with pytest.raises(ValueError, match="Invalid agent category"):
            loader.parse_agent(content)

    def test_parse_agent_string_input_schema(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(input="prompt")
        agent = loader.parse_agent(content)
        assert isinstance(agent.input_schema, list)
        assert "prompt" in agent.input_schema

    def test_parse_agent_string_output_schema(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(output="chapter")
        agent = loader.parse_agent(content)
        assert isinstance(agent.output_schema, list)
        assert "chapter" in agent.output_schema

    def test_parse_agent_string_dependencies(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(dependencies="dep_agent")
        agent = loader.parse_agent(content)
        assert isinstance(agent.dependencies, list)
        assert "dep_agent" in agent.dependencies

    def test_parse_agent_with_version(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(version="2.0.0")
        agent = loader.parse_agent(content)
        assert agent.version == "2.0.0"

    def test_parse_agent_default_version(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md()
        agent = loader.parse_agent(content)
        assert agent.version == "1.0.0"

    def test_parse_agent_whitespace_handling(self):
        loader = AgentLoader("/path/to/agents")
        content = (
            "\n\n---\nname: test_agent\n"
            "description: Test\ncategory: analytical\n"
            "---\n\nInstructions\n\n"
        )
        agent = loader.parse_agent(content)
        assert agent.name == "test_agent"
        assert "Instructions" in agent.instructions

    def test_parse_agent_with_file_path(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md()
        agent = loader.parse_agent(content, Path("/path/to/agent.md"))
        assert agent.file_path == "/path/to/agent.md"

    def test_parse_agent_without_file_path(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md()
        agent = loader.parse_agent(content, None)
        assert agent.file_path is None

    def test_parse_agent_creative_category(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(category="creative")
        agent = loader.parse_agent(content)
        assert agent.category == AgentCategory.CREATIVE

    def test_parse_agent_validation_category(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(category="validation")
        agent = loader.parse_agent(content)
        assert agent.category == AgentCategory.VALIDATION

    def test_parse_agent_with_context_needs(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(context_needs={"previous_chapters": True})
        agent = loader.parse_agent(content)
        assert agent.context_needs == {"previous_chapters": True}

    def test_parse_agent_complex_frontmatter(self):
        loader = AgentLoader("/path/to/agents")
        content = _agent_md(
            input=["prompt", "context"],
            output=["chapter", "metadata"],
            dependencies=["agent1", "agent2"],
        )
        agent = loader.parse_agent(content)
        assert len(agent.input_schema) == 2
        assert len(agent.output_schema) == 2
        assert len(agent.dependencies) == 2


class TestLoadAllAgents:
    def test_load_all_agents_nonexistent_directory(self):
        loader = AgentLoader("/nonexistent/directory")
        assert loader.load_all_agents() == []

    def test_load_all_agents_empty_directory(self, tmp_path):
        loader = AgentLoader(str(tmp_path))
        assert loader.load_all_agents() == []

    def test_load_all_agents_with_files(self, tmp_path):
        _write_file(tmp_path / "agent1.md", _agent_md(name="agent1"))
        _write_file(tmp_path / "agent2.md", _agent_md(name="agent2", category="creative"))
        loader = AgentLoader(str(tmp_path))
        agents = loader.load_all_agents()
        assert len(agents) == 2
        names = [a.name for a in agents]
        assert "agent1" in names
        assert "agent2" in names

    def test_load_all_agents_bad_file_prints_warning(self, tmp_path, capsys):
        _write_file(tmp_path / "bad.md", "not valid frontmatter")
        _write_file(tmp_path / "good.md", _agent_md(name="good"))
        loader = AgentLoader(str(tmp_path))
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "good"
        captured = capsys.readouterr()
        assert "Warning" in captured.out
        assert "bad.md" in captured.out

    def test_load_all_agents_en_language_subdir(self, tmp_path):
        en_dir = tmp_path / "en"
        _write_file(en_dir / "agent1.md", _agent_md(name="agent1"))
        loader = AgentLoader(str(tmp_path), LanguageCode.EN)
        agents = loader.load_all_agents()
        assert len(agents) == 1

    def test_load_all_agents_non_english_empty_fallback_to_en(self, tmp_path):
        en_dir = tmp_path / "en"
        _write_file(en_dir / "agent1.md", _agent_md(name="agent1"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "agent1"

    def test_load_all_agents_non_english_fallback_to_root(self, tmp_path):
        _write_file(tmp_path / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "my_agent"

    def test_load_all_agents_non_english_en_empty_fallback_to_root(self, tmp_path):
        en_dir = tmp_path / "en"
        en_dir.mkdir()
        _write_file(tmp_path / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agents = loader.load_all_agents()
        assert len(agents) == 1

    def test_load_all_agents_en_with_empty_en_dir_fallback_to_root(self, tmp_path):
        en_dir = tmp_path / "en"
        en_dir.mkdir()
        _write_file(tmp_path / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.EN)
        agents = loader.load_all_agents()
        assert len(agents) == 1
        assert agents[0].name == "my_agent"

    def test_load_all_agents_fewer_files_falls_back_to_en(self, tmp_path):
        en_dir = tmp_path / "en"
        _write_file(en_dir / "a.md", _agent_md(name="a"))
        _write_file(en_dir / "b.md", _agent_md(name="b"))
        zh_dir = tmp_path / "zh-CN"
        _write_file(zh_dir / "a.md", _agent_md(name="a"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agents = loader.load_all_agents()
        assert len(agents) >= 1


class TestReloadAgent:
    def test_reload_agent_not_found(self, tmp_path):
        loader = AgentLoader(str(tmp_path))
        assert loader.reload_agent("nonexistent_agent") is None

    def test_reload_agent_success(self, tmp_path):
        _write_file(tmp_path / "test_agent.md", _agent_md(name="test_agent"))
        loader = AgentLoader(str(tmp_path))
        result = loader.reload_agent("test_agent")
        assert result is not None
        assert result.name == "test_agent"

    def test_reload_agent_non_english_finds_in_en_dir(self, tmp_path):
        en_dir = tmp_path / "en"
        _write_file(en_dir / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"

    def test_reload_agent_non_english_fallback_to_root(self, tmp_path):
        _write_file(tmp_path / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"

    def test_reload_agent_english_fallback_to_root(self, tmp_path):
        en_dir = tmp_path / "en"
        en_dir.mkdir()
        _write_file(tmp_path / "my_agent.md", _agent_md(name="my_agent"))
        loader = AgentLoader(str(tmp_path), LanguageCode.EN)
        agent = loader.reload_agent("my_agent")
        assert agent is not None
        assert agent.name == "my_agent"

    def test_reload_agent_non_english_no_en_no_root(self, tmp_path):
        loader = AgentLoader(str(tmp_path), LanguageCode.ZH_CN)
        assert loader.reload_agent("missing") is None

    def test_reload_agent_in_language_dir(self, tmp_path):
        en_dir = tmp_path / "en"
        _write_file(en_dir / "writer.md", _agent_md(name="writer"))
        loader = AgentLoader(str(tmp_path), LanguageCode.EN)
        agent = loader.reload_agent("writer")
        assert agent is not None
        assert agent.name == "writer"
