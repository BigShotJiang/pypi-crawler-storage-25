"""Unit tests for context_compressor.py — progressive compression."""

from unittest.mock import MagicMock

from core.context_assembly import ContextBlock
from core.context_compressor import CompressionResult, CompressionTier, ContextCompressor
from core.context_schema import TokenBudget
from core.token_estimator import TokenEstimator


def _block(
    source: str = "test",
    priority: int = 0,
    content: str = "test content",
    compressible: bool = True,
    label: str = "test",
) -> ContextBlock:
    token_count = TokenEstimator.estimate_tokens(content)
    return ContextBlock(
        source=source,
        priority=priority,
        content=content,
        token_count=token_count,
        compressible=compressible,
        label=label,
    )


def _budget(total: int = 1000, reserved: int = 100) -> TokenBudget:
    return TokenBudget.create(total_limit=total, reserved_output=reserved)


class TestCompressionTier:
    def test_tier_values(self):
        assert CompressionTier.NONE == "none"
        assert CompressionTier.TRUNCATE == "truncate"
        assert CompressionTier.EXTRACT == "extract"
        assert CompressionTier.SUMMARIZE == "summarize"


class TestCompressionResult:
    def test_basic_result(self):
        r = CompressionResult(
            context_str="hello",
            original_tokens=10,
            compressed_tokens=5,
            tier_used=CompressionTier.NONE,
        )
        assert r.context_str == "hello"
        assert r.original_tokens == 10
        assert r.compressed_tokens == 5
        assert r.tier_used == CompressionTier.NONE
        assert r.blocks_dropped == 0
        assert r.blocks_truncated == 0


class TestCompressorNone:
    def test_empty_blocks(self):
        compressor = ContextCompressor()
        result = compressor.compress([], _budget())
        assert result.context_str == ""
        assert result.tier_used == CompressionTier.NONE

    def test_fits_as_is(self):
        compressor = ContextCompressor()
        blocks = [_block(content="Small content.")]
        result = compressor.compress(blocks, _budget(total=10000))

        assert result.tier_used == CompressionTier.NONE
        assert result.compressed_tokens >= result.original_tokens

    def test_single_block_fits(self):
        compressor = ContextCompressor()
        content = "A " * 50
        blocks = [_block(content=content)]
        result = compressor.compress(blocks, _budget(total=10000))

        assert result.tier_used == CompressionTier.NONE


class TestCompressorTruncate:
    def test_over_budget_triggers_truncate(self):
        compressor = ContextCompressor()
        big_content = "word " * 500
        blocks = [_block(content=big_content, source="chapter")]

        result = compressor.compress(blocks, _budget(total=200, reserved=10))
        assert result.tier_used in (CompressionTier.TRUNCATE, CompressionTier.EXTRACT)
        assert result.compressed_tokens <= 190

    def test_non_compressible_preserved(self):
        compressor = ContextCompressor()
        meta = _block(
            source="meta",
            content="Important metadata.",
            compressible=False,
        )
        big = _block(
            source="chapter",
            content="word " * 500,
            compressible=True,
        )
        result = compressor.compress([meta, big], _budget(total=200, reserved=10))

        assert "Important metadata" in result.context_str

    def test_lowest_priority_truncated_first(self):
        compressor = ContextCompressor()
        required = _block(
            source="meta",
            content="Required meta content that must be kept.",
            compressible=False,
        )
        optional_big = _block(
            source="chapter",
            content="optional " * 300,
            priority=1,
            compressible=True,
        )
        result = compressor.compress([required, optional_big], _budget(total=200, reserved=10))
        assert "Required meta" in result.context_str

    def test_multiple_compressible_blocks(self):
        compressor = ContextCompressor()
        blocks = [_block(content=f"Chapter {i} content. " * 50, source="chapter") for i in range(3)]
        budget = _budget(total=100, reserved=10)
        result = compressor.compress(blocks, budget)
        assert result.compressed_tokens <= budget.available_for_input


class TestCompressorExtract:
    def test_extract_preserves_headers(self):
        compressor = ContextCompressor()
        content = "# Chapter Summary\n\nA brave knight died in battle.\n\nRandom text " * 20
        extracted = compressor._extract_key_elements(content)

        assert "# Chapter Summary" in extracted

    def test_extract_preserves_list_items(self):
        compressor = ContextCompressor()
        content = "- Character: John\n- Location: Castle\nRandom filler " * 20
        extracted = compressor._extract_key_elements(content)

        assert "- Character: John" in extracted

    def test_extract_preserves_key_verbs(self):
        compressor = ContextCompressor()
        content = "The hero discovered a hidden passage.\nRandom text.\n" * 10
        extracted = compressor._extract_key_elements(content)

        assert "discovered" in extracted

    def test_extract_empty_content(self):
        compressor = ContextCompressor()
        assert compressor._extract_key_elements("") == ""

    def test_extract_fallback_to_sentences(self):
        compressor = ContextCompressor()
        content = (
            "First sentence. Second sentence. Third sentence. Fourth sentence. Fifth sentence."
        )
        extracted = compressor._extract_key_elements(content)

        assert len(extracted) > 0


class TestCompressorSummarize:
    def test_summarize_with_mock_llm(self):
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.content = "Compressed: hero saves the day."
        mock_client.generate.return_value = mock_response

        compressor = ContextCompressor(llm_client=mock_client)
        blocks = [
            _block(
                content="The hero discovered a hidden passage. " * 100,
                source="chapter",
            )
        ]

        budget = _budget(total=30, reserved=5)
        result = compressor.compress(blocks, budget)

        assert result.compressed_tokens <= budget.available_for_input
        assert mock_client.generate.called or result.tier_used in (
            CompressionTier.TRUNCATE,
            CompressionTier.EXTRACT,
        )

    def test_summarize_skipped_without_llm(self):
        compressor = ContextCompressor(llm_client=None)
        blocks = [_block(content="word " * 500, source="chapter")]

        result = compressor.compress(blocks, _budget(total=100, reserved=10))

        assert result.tier_used != CompressionTier.SUMMARIZE or result.compressed_tokens <= 90

    def test_summarize_fallback_on_error(self):
        mock_client = MagicMock()
        mock_client.generate.side_effect = Exception("API error")

        compressor = ContextCompressor(llm_client=mock_client)
        content = "The hero discovered a hidden passage.\n" * 50
        blocks = [_block(content=content, source="chapter")]

        result = compressor.compress(blocks, _budget(total=100, reserved=10))
        assert result.compressed_tokens <= 90


class TestCompressorGuarantee:
    def test_guaranteed_fit_small_budget(self):
        compressor = ContextCompressor()
        blocks = [
            _block(content="word " * 200, source="chapter"),
            _block(content="more words " * 200, source="world"),
        ]
        budget = _budget(total=50, reserved=5)
        result = compressor.compress(blocks, budget)

        final_tokens = TokenEstimator.estimate_tokens(result.context_str)
        assert final_tokens <= budget.available_for_input

    def test_guaranteed_fit_tiny_budget(self):
        compressor = ContextCompressor()
        blocks = [
            _block(content="Important meta.", source="meta", compressible=False),
            _block(content="word " * 100, source="chapter"),
        ]
        budget = _budget(total=30, reserved=5)
        result = compressor.compress(blocks, budget)

        assert "Important meta" in result.context_str
        final_tokens = TokenEstimator.estimate_tokens(result.context_str)
        assert final_tokens <= budget.available_for_input

    def test_guaranteed_fit_all_non_compressible(self):
        compressor = ContextCompressor()
        blocks = [
            _block(content="Meta content.", source="meta", compressible=False),
            _block(content="Outline content.", source="outline", compressible=False),
        ]
        budget = _budget(total=100, reserved=10)
        result = compressor.compress(blocks, budget)

        assert result.tier_used == CompressionTier.NONE

    def test_guaranteed_fit_large_content(self):
        compressor = ContextCompressor()
        blocks = [
            _block(content="word " * 1000, source="chapter"),
            _block(content="word " * 1000, source="world"),
            _block(content="word " * 1000, source="summary"),
        ]
        budget = _budget(total=200, reserved=20)
        result = compressor.compress(blocks, budget)

        final_tokens = TokenEstimator.estimate_tokens(result.context_str)
        assert final_tokens <= budget.available_for_input


class TestCompressorResult:
    def test_metadata_includes_block_count(self):
        compressor = ContextCompressor()
        blocks = [_block(content="test"), _block(content="test2")]
        result = compressor.compress(blocks, _budget(total=10000))

        assert result.metadata["block_count"] == 2

    def test_metadata_includes_sources(self):
        compressor = ContextCompressor()
        blocks = [
            _block(content="test", source="meta", compressible=False),
            _block(content="test2", source="chapter"),
        ]
        result = compressor.compress(blocks, _budget(total=10000))

        assert "meta" in result.metadata["sources"]
        assert "chapter" in result.metadata["sources"]

    def test_original_tokens_preserved(self):
        compressor = ContextCompressor()
        blocks = [_block(content="word " * 100)]
        result = compressor.compress(blocks, _budget(total=50, reserved=5))

        original = sum(b.token_count for b in blocks)
        assert result.original_tokens == original
        assert result.compressed_tokens < original


class TestCompressorForceFit:
    def test_force_fit_drops_all_compressible(self):
        compressor = ContextCompressor()
        meta = _block(
            source="meta",
            content="Critical metadata.",
            compressible=False,
        )
        chapter = _block(
            source="chapter",
            content="word " * 500,
            compressible=True,
        )
        result = compressor.compress([meta, chapter], _budget(total=20, reserved=2))

        assert "Critical metadata" in result.context_str

    def test_force_fit_only_compressible(self):
        compressor = ContextCompressor()
        blocks = [_block(content="word " * 200, source="chapter")]
        budget = _budget(total=30, reserved=5)
        result = compressor.compress(blocks, budget)

        final_tokens = TokenEstimator.estimate_tokens(result.context_str)
        assert final_tokens <= budget.available_for_input


class TestCompressorSummarizePaths:
    """Test specific code paths in _apply_summarize."""

    def test_summarize_returns_unchanged_when_already_fit(self):
        """Test _apply_summarize returns early when content fits budget."""
        compressor = ContextCompressor()
        blocks = [_block(content="Short content.", source="chapter")]
        budget = _budget(total=10000, reserved=100)

        result, dropped, truncated = compressor._apply_summarize(blocks, budget)

        assert result == blocks
        assert dropped == 0
        assert truncated == 0

    def test_summarize_no_llm_returns_unchanged(self):
        """Test _apply_summarize with no LLM client returns blocks unchanged."""
        compressor = ContextCompressor(llm_client=None)
        blocks = [_block(content="word " * 200, source="chapter")]
        budget = _budget(total=50, reserved=5)

        result, dropped, truncated = compressor._apply_summarize(blocks, budget)

        assert dropped == 0
        assert truncated == 0

    def test_summarize_target_tokens_zero(self):
        """Test _apply_summarize when non_compressible blocks exceed budget.

        Note: This scenario is hard to trigger because if non_compressible > available_for_input,
        total would also exceed available_for_input causing early return. The branch exists
        for defensive programming but is difficult to trigger in practice.
        """
        pass

    def test_summarize_produces_empty_result(self):
        """Test _apply_summarize when LLM returns empty content."""
        mock_client = MagicMock()
        mock_client.generate.return_value = MagicMock(content="")
        compressor = ContextCompressor(llm_client=mock_client)

        blocks = [_block(content="word " * 100, source="chapter")]
        budget = _budget(total=50, reserved=5)

        result, dropped, truncated = compressor._apply_summarize(blocks, budget)

        assert dropped == 1
        assert truncated == 0


class TestTruncateBlock:
    """Test _truncate_block edge cases."""

    def test_truncate_empty_content(self):
        """Test truncating empty content returns empty string."""
        compressor = ContextCompressor()
        block = _block(content="", compressible=True)
        result = compressor._truncate_block(block, 100)
        assert result == ""

    def test_truncate_content_already_small(self):
        """Test that small content is returned unchanged."""
        compressor = ContextCompressor()
        block = _block(content="Short.", compressible=True)
        result = compressor._truncate_block(block, 100)
        assert result == "Short."

    def test_truncate_falls_back_to_newline_search(self):
        """Test _truncate_block uses newline heuristic for truncation."""
        compressor = ContextCompressor()
        long_content = "Hello world. This is a test. " * 50
        block = _block(content=long_content, compressible=True)
        result = compressor._truncate_block(block, 50)
        assert len(result) < len(long_content)


class TestConcatenate:
    """Test _concatenate method."""

    def test_concatenate_with_labels(self):
        """Test _concatenate adds section headers for labeled blocks."""
        compressor = ContextCompressor()
        blocks = [
            _block(content="Chapter one.", source="chapter", label="Chapter 1"),
            _block(content="Chapter two.", source="chapter", label="Chapter 2"),
        ]
        result = compressor._concatenate(blocks)
        assert "## Chapter 1" in result
        assert "## Chapter 2" in result
        assert "Chapter one." in result
        assert "Chapter two." in result

    def test_concatenate_without_labels(self):
        """Test _concatenate works without labels."""
        compressor = ContextCompressor()
        blocks = [
            _block(content="Content A.", source="chapter", label=""),
            _block(content="Content B.", source="chapter", label=""),
        ]
        result = compressor._concatenate(blocks)
        assert "Content A." in result
        assert "Content B." in result


class TestCopyBlock:
    """Test _copy_block method."""

    def test_copy_block_preserves_all_fields(self):
        """Test _copy_block creates exact copy with all fields preserved."""
        compressor = ContextCompressor()
        block = _block(
            source="test_source",
            priority=5,
            content="Test content",
            compressible=True,
            label="test_label",
        )
        copied = compressor._copy_block(block)
        assert copied.source == block.source
        assert copied.priority == block.priority
        assert copied.content == block.content
        assert copied.compressible == block.compressible
        assert copied.label == block.label


class TestBuildResult:
    """Test _build_result method."""

    def test_build_result_truncates_oversized_result(self):
        """Test _build_result applies final truncation when result exceeds budget."""
        compressor = ContextCompressor()
        blocks = [_block(content="word " * 500, source="chapter")]
        budget = _budget(total=30, reserved=5)

        result = compressor.compress(blocks, budget)

        final_tokens = TokenEstimator.estimate_tokens(result.context_str)
        assert final_tokens <= budget.available_for_input


class TestExtractKeyElements:
    """Test additional _extract_key_elements patterns."""

    def test_extract_preserves_dialogue(self):
        """Test extraction preserves dialogue quotes."""
        compressor = ContextCompressor()
        content = '"Hello, world!" said the hero.\nRandom text ' * 20
        extracted = compressor._extract_key_elements(content)
        assert '"Hello, world!"' in extracted or "hero" in extracted.lower()

    def test_extract_handles_no_key_elements(self):
        """Test extraction with content that has no key elements falls back to sentences."""
        compressor = ContextCompressor()
        content = "word word word word word."
        extracted = compressor._extract_key_elements(content)
        assert len(extracted) > 0


class TestCompressorEdgeCases:
    """Test edge cases in ContextCompressor."""

    def test_compress_with_all_non_compressible(self):
        """Test compress handles all non-compressible blocks."""
        compressor = ContextCompressor()
        blocks = [
            _block(content="Meta.", source="meta", compressible=False),
            _block(content="Outline.", source="outline", compressible=False),
        ]
        budget = _budget(total=50, reserved=5)
        result = compressor.compress(blocks, budget)

        assert result.tier_used == CompressionTier.NONE
        assert "Meta." in result.context_str
        assert "Outline." in result.context_str

    def test_compress_falls_through_all_tiers(self):
        """Test compress falls through all tiers down to force_fit."""
        mock_client = MagicMock()
        mock_client.generate.return_value = MagicMock(content="x")
        compressor = ContextCompressor(llm_client=mock_client)

        blocks = [
            _block(content="word " * 500, source="chapter", compressible=True),
        ]
        budget = _budget(total=20, reserved=2)
        result = compressor.compress(blocks, budget)

        assert result.compressed_tokens <= budget.available_for_input
