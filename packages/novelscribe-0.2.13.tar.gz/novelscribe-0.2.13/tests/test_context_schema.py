"""Unit tests for context_schema.py — models and budget allocation."""

import pytest

from core.agent import Agent, AgentCategory
from core.agent_loader import AgentLoader
from core.context_schema import (
    AgentContextSchema,
    BudgetAllocator,
    ContextNeed,
    ContextScope,
    TokenBudget,
)
from core.llm_client import LLMProvider


class TestContextScope:
    def test_scope_values(self):
        assert ContextScope.LATEST == "latest"
        assert ContextScope.RECENT == "recent"
        assert ContextScope.ALL == "all"
        assert ContextScope.GROUP == "group"


class TestContextNeed:
    def test_minimal(self):
        cn = ContextNeed(artifact_type="meta")
        assert cn.artifact_type == "meta"
        assert cn.scope == "latest"
        assert cn.recent_count == 3
        assert cn.max_tokens is None

    def test_full(self):
        cn = ContextNeed(
            artifact_type="chapter",
            scope="recent",
            recent_count=5,
            max_tokens=2000,
        )
        assert cn.artifact_type == "chapter"
        assert cn.scope == "recent"
        assert cn.recent_count == 5
        assert cn.max_tokens == 2000

    def test_scope_latest(self):
        cn = ContextNeed(artifact_type="outline", scope="latest")
        assert cn.scope == "latest"

    def test_scope_recent(self):
        cn = ContextNeed(artifact_type="summary", scope="recent", recent_count=10)
        assert cn.scope == "recent"
        assert cn.recent_count == 10

    def test_scope_all(self):
        cn = ContextNeed(artifact_type="chapter", scope="all")
        assert cn.scope == "all"

    def test_scope_group(self):
        cn = ContextNeed(artifact_type="summary", scope="group")
        assert cn.scope == "group"

    def test_recent_count_minimum(self):
        with pytest.raises(Exception):
            ContextNeed(artifact_type="meta", recent_count=0)

    def test_max_tokens_minimum(self):
        with pytest.raises(Exception):
            ContextNeed(artifact_type="meta", max_tokens=0)

    def test_artifact_type_required(self):
        with pytest.raises(Exception):
            ContextNeed()

    def test_various_artifact_types(self):
        for t in [
            "meta",
            "outline",
            "characters",
            "world",
            "chapter",
            "summary",
            "verification",
            "plan",
            "chapter_plan",
        ]:
            cn = ContextNeed(artifact_type=t)
            assert cn.artifact_type == t


class TestAgentContextSchema:
    def test_empty(self):
        schema = AgentContextSchema()
        assert schema.required == []
        assert schema.optional == []
        assert schema.budget_hint is None

    def test_with_required(self):
        schema = AgentContextSchema(
            required=[
                ContextNeed(artifact_type="meta"),
                ContextNeed(artifact_type="outline"),
            ]
        )
        assert len(schema.required) == 2
        assert schema.required[0].artifact_type == "meta"
        assert schema.required[1].artifact_type == "outline"

    def test_with_optional(self):
        schema = AgentContextSchema(
            optional=[
                ContextNeed(artifact_type="world", max_tokens=2000),
                ContextNeed(artifact_type="summary", scope="recent", recent_count=3),
            ]
        )
        assert len(schema.optional) == 2
        assert schema.optional[0].max_tokens == 2000
        assert schema.optional[1].scope == "recent"

    def test_with_budget_hint(self):
        schema = AgentContextSchema(budget_hint={"max_input_tokens": 6000})
        assert schema.budget_hint == {"max_input_tokens": 6000}

    def test_default_schema(self):
        schema = AgentContextSchema.default_schema()
        assert len(schema.required) == 2
        assert schema.required[0].artifact_type == "meta"
        assert schema.required[1].artifact_type == "outline"
        assert len(schema.optional) == 1
        assert schema.optional[0].artifact_type == "summary"
        assert schema.optional[0].scope == "recent"
        assert schema.optional[0].recent_count == 2

    def test_from_dict_empty(self):
        schema = AgentContextSchema.from_dict({})
        assert schema.required == []
        assert schema.optional == []
        assert schema.budget_hint is None

    def test_from_dict_with_required(self):
        data = {
            "required": [
                {"artifact_type": "meta"},
                {"artifact_type": "outline"},
            ]
        }
        schema = AgentContextSchema.from_dict(data)
        assert len(schema.required) == 2
        assert schema.required[0].artifact_type == "meta"

    def test_from_dict_with_optional(self):
        data = {
            "optional": [
                {"artifact_type": "world", "max_tokens": 2000},
                {"artifact_type": "summary", "scope": "recent", "recent_count": 5},
            ]
        }
        schema = AgentContextSchema.from_dict(data)
        assert len(schema.optional) == 2
        assert schema.optional[1].recent_count == 5

    def test_from_dict_with_budget_hint(self):
        data = {"budget_hint": {"max_input_tokens": 4000}}
        schema = AgentContextSchema.from_dict(data)
        assert schema.budget_hint["max_input_tokens"] == 4000

    def test_from_dict_full(self):
        data = {
            "required": [
                {"artifact_type": "meta"},
                {"artifact_type": "outline"},
                {"artifact_type": "characters"},
            ],
            "optional": [
                {"artifact_type": "world", "max_tokens": 2000},
                {"artifact_type": "summary", "scope": "recent", "recent_count": 3},
            ],
            "budget_hint": {"max_input_tokens": 6000},
        }
        schema = AgentContextSchema.from_dict(data)
        assert len(schema.required) == 3
        assert len(schema.optional) == 2
        assert schema.budget_hint["max_input_tokens"] == 6000

    def test_from_dict_ignores_unknown_keys(self):
        data = {
            "required": [{"artifact_type": "meta"}],
            "unknown_key": "should be ignored",
        }
        schema = AgentContextSchema.from_dict(data)
        assert len(schema.required) == 1


class TestTokenBudget:
    def test_create(self):
        budget = TokenBudget.create(total_limit=128000, reserved_output=4096)
        assert budget.total_limit == 128000
        assert budget.reserved_output == 4096
        assert budget.available_for_input == 123904
        assert budget.allocated == 0

    def test_create_zero_output(self):
        budget = TokenBudget.create(total_limit=128000, reserved_output=0)
        assert budget.available_for_input == 128000

    def test_create_output_exceeds_total(self):
        budget = TokenBudget.create(total_limit=100, reserved_output=200)
        assert budget.available_for_input == 0

    def test_remaining(self):
        budget = TokenBudget.create(total_limit=1000, reserved_output=100)
        assert budget.remaining == 900
        budget.allocated = 500
        assert budget.remaining == 400

    def test_can_allocate(self):
        budget = TokenBudget.create(total_limit=1000, reserved_output=100)
        assert budget.can_allocate(500)
        assert budget.can_allocate(900)
        assert not budget.can_allocate(901)

    def test_allocate_success(self):
        budget = TokenBudget.create(total_limit=1000, reserved_output=100)
        assert budget.allocate(300)
        assert budget.allocated == 300
        assert budget.remaining == 600

    def test_allocate_failure(self):
        budget = TokenBudget.create(total_limit=1000, reserved_output=100)
        assert not budget.allocate(901)
        assert budget.allocated == 0

    def test_allocate_multiple(self):
        budget = TokenBudget.create(total_limit=1000, reserved_output=100)
        assert budget.allocate(300)
        assert budget.allocate(400)
        assert budget.allocated == 700
        assert budget.remaining == 200
        assert not budget.allocate(201)

    def test_total_limit_must_be_positive(self):
        with pytest.raises(Exception):
            TokenBudget(total_limit=0, reserved_output=0, available_for_input=0)

    def test_direct_construction(self):
        budget = TokenBudget(
            total_limit=128000,
            reserved_output=4096,
            available_for_input=123904,
        )
        assert budget.total_limit == 128000
        assert budget.remaining == 123904


class TestBudgetAllocator:
    def test_provider_limits(self):
        allocator = BudgetAllocator()
        assert allocator.get_limit("openai") == 128_000
        assert allocator.get_limit("claude") == 200_000
        assert allocator.get_limit("gemini") == 1_000_000
        assert allocator.get_limit("ollama") == 8_192
        assert allocator.get_limit("lm_studio") == 8_192

    def test_provider_limits_via_enum(self):
        allocator = BudgetAllocator()
        assert allocator.get_limit(LLMProvider.OPENAI) == 128_000
        assert allocator.get_limit(LLMProvider.CLAUDE) == 200_000
        assert allocator.get_limit(LLMProvider.GEMINI) == 1_000_000
        assert allocator.get_limit(LLMProvider.OLLAMA) == 8_192
        assert allocator.get_limit(LLMProvider.LM_STUDIO) == 8_192

    def test_unknown_provider(self):
        allocator = BudgetAllocator()
        assert allocator.get_limit("unknown") == 8_192

    def test_custom_limits(self):
        allocator = BudgetAllocator(custom_limits={"custom": 32768})
        assert allocator.get_limit("custom") == 32768
        assert allocator.get_limit("openai") == 128_000

    def test_custom_override(self):
        allocator = BudgetAllocator(custom_limits={"openai": 256_000})
        assert allocator.get_limit("openai") == 256_000

    def test_allocate_basic(self):
        allocator = BudgetAllocator()
        budget = allocator.allocate("openai", max_tokens=4096)
        assert budget.total_limit == 128_000
        assert budget.reserved_output == 4096
        assert budget.available_for_input == 128_000 - 4096

    def test_allocate_with_schema_budget_hint(self):
        allocator = BudgetAllocator()
        schema = AgentContextSchema(budget_hint={"max_input_tokens": 6000})
        budget = allocator.allocate("openai", schema=schema)
        assert budget.reserved_output == 128_000 - 6000
        assert budget.available_for_input == 6000

    def test_allocate_max_tokens_overrides_hint(self):
        allocator = BudgetAllocator()
        schema = AgentContextSchema(budget_hint={"max_input_tokens": 6000})
        budget = allocator.allocate("openai", max_tokens=8192, schema=schema)
        assert budget.reserved_output == 8192
        assert budget.available_for_input == 128_000 - 8192

    def test_allocate_default_output_tokens(self):
        allocator = BudgetAllocator()
        budget = allocator.allocate("openai")
        assert budget.reserved_output == BudgetAllocator.DEFAULT_OUTPUT_TOKENS
        assert budget.available_for_input == 128_000 - BudgetAllocator.DEFAULT_OUTPUT_TOKENS

    def test_allocate_via_enum(self):
        allocator = BudgetAllocator()
        budget = allocator.allocate(LLMProvider.CLAUDE, max_tokens=8000)
        assert budget.total_limit == 200_000
        assert budget.reserved_output == 8000

    def test_allocate_all_providers(self):
        allocator = BudgetAllocator()
        for provider in LLMProvider:
            budget = allocator.allocate(provider, max_tokens=1000)
            assert budget.available_for_input == allocator.get_limit(provider) - 1000
            assert budget.available_for_input > 0

    def test_allocate_zero_output(self):
        allocator = BudgetAllocator()
        budget = allocator.allocate("openai", max_tokens=0)
        assert budget.available_for_input == 128_000


class TestAgentModelContextNeeds:
    def test_agent_has_context_needs_field(self):
        agent = Agent(
            name="test",
            description="test",
            category=AgentCategory.ANALYTICAL,
            instructions="test",
        )
        assert agent.context_needs is None

    def test_agent_with_context_needs(self):
        agent = Agent(
            name="test",
            description="test",
            category=AgentCategory.ANALYTICAL,
            instructions="test",
            context_needs={
                "required": [{"artifact_type": "meta"}],
                "optional": [],
            },
        )
        assert agent.context_needs is not None
        assert agent.context_needs["required"][0]["artifact_type"] == "meta"


class TestAgentLoaderContextNeeds:
    def test_parse_agent_without_context_needs(self):
        loader = AgentLoader("/tmp/nonexistent")
        content = """---
name: test_agent
description: Test agent
category: analytical
---
Instructions here."""
        agent = loader.parse_agent(content)
        assert agent.context_needs is None

    def test_parse_agent_with_context_needs(self):
        loader = AgentLoader("/tmp/nonexistent")
        content = """---
name: writer_agent
description: Writes chapters
category: creative
context_needs:
  required:
    - artifact_type: meta
    - artifact_type: outline
  optional:
    - artifact_type: world
      max_tokens: 2000
---
Write chapters."""
        agent = loader.parse_agent(content)
        assert agent.context_needs is not None
        assert len(agent.context_needs["required"]) == 2
        assert agent.context_needs["required"][0]["artifact_type"] == "meta"
        assert len(agent.context_needs["optional"]) == 1
        assert agent.context_needs["optional"][0]["max_tokens"] == 2000

    def test_parse_agent_with_empty_context_needs(self):
        loader = AgentLoader("/tmp/nonexistent")
        content = """---
name: discuss_agent
description: Fresh start
category: analytical
context_needs:
  required: []
  optional: []
---
Fresh start."""
        agent = loader.parse_agent(content)
        assert agent.context_needs is not None
        assert agent.context_needs["required"] == []
        assert agent.context_needs["optional"] == []

    def test_parse_agent_with_budget_hint(self):
        loader = AgentLoader("/tmp/nonexistent")
        content = """---
name: test_agent
description: Test
category: analytical
context_needs:
  required:
    - artifact_type: meta
  optional: []
  budget_hint:
    max_input_tokens: 6000
---
Test."""
        agent = loader.parse_agent(content)
        assert agent.context_needs["budget_hint"]["max_input_tokens"] == 6000

    def test_round_trip_to_schema(self):
        loader = AgentLoader("/tmp/nonexistent")
        content = """---
name: writer_agent
description: Writes chapters
category: creative
context_needs:
  required:
    - artifact_type: meta
    - artifact_type: outline
    - artifact_type: chapter_plan
    - artifact_type: characters
  optional:
    - artifact_type: world
      max_tokens: 2000
    - artifact_type: summary
      scope: recent
      recent_count: 3
    - artifact_type: chapter
      scope: recent
      recent_count: 2
---
Write."""
        agent = loader.parse_agent(content)
        schema = AgentContextSchema.from_dict(agent.context_needs)

        assert len(schema.required) == 4
        assert len(schema.optional) == 3
        assert schema.optional[0].max_tokens == 2000
        assert schema.optional[1].scope == "recent"
        assert schema.optional[2].recent_count == 2


class TestAgentMarkdownFiles:
    @pytest.fixture
    def agents_dir(self) -> str:
        return str(__import__("pathlib").Path(__file__).parent.parent / "agents" / "en")

    def test_load_all_pipeline_agents(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agents = loader.load_all_agents()
        agent_names = {a.name for a in agents}
        expected = {
            "discuss_agent",
            "genre_agent",
            "character_agent",
            "world_agent",
            "outline_agent",
            "chapter_planner_agent",
            "writer_agent",
            "continuity_agent",
            "editor_agent",
            "summary_agent",
            "humanizer_agent",
        }
        assert expected.issubset(agent_names), f"Missing agents: {expected - agent_names}"

    def test_pipeline_agents_have_context_needs(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agents = loader.load_all_agents()
        pipeline_agents = {
            "writer_agent",
            "continuity_agent",
            "editor_agent",
            "chapter_planner_agent",
        }
        for agent in agents:
            if agent.name in pipeline_agents:
                assert agent.context_needs is not None, f"{agent.name} should have context_needs"

    def test_writer_agent_schema(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agent = loader.reload_agent("writer_agent")
        assert agent is not None
        schema = AgentContextSchema.from_dict(agent.context_needs)

        required_types = {cn.artifact_type for cn in schema.required}
        assert "meta" in required_types
        assert "outline" in required_types
        assert "chapter_plan" in required_types
        assert "characters" in required_types

        optional_types = {cn.artifact_type for cn in schema.optional}
        assert "world" in optional_types
        assert "summary" in optional_types
        assert "chapter" in optional_types

    def test_discuss_agent_empty_context(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agent = loader.reload_agent("discuss_agent")
        assert agent is not None
        schema = AgentContextSchema.from_dict(agent.context_needs)
        assert schema.required == []
        assert schema.optional == []

    def test_genre_agent_only_meta(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agent = loader.reload_agent("genre_agent")
        assert agent is not None
        schema = AgentContextSchema.from_dict(agent.context_needs)
        assert len(schema.required) == 1
        assert schema.required[0].artifact_type == "meta"

    def test_continuity_agent_schema(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agent = loader.reload_agent("continuity_agent")
        assert agent is not None
        schema = AgentContextSchema.from_dict(agent.context_needs)

        required_types = {cn.artifact_type for cn in schema.required}
        assert "outline" in required_types
        assert "characters" in required_types
        assert "chapter" in required_types

    def test_editor_agent_schema(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agent = loader.reload_agent("editor_agent")
        assert agent is not None
        schema = AgentContextSchema.from_dict(agent.context_needs)

        required_types = {cn.artifact_type for cn in schema.required}
        assert "chapter" in required_types
        assert "outline" in required_types
        assert "characters" in required_types

    def test_all_agent_schemas_valid(self, agents_dir: str):
        loader = AgentLoader(agents_dir)
        agents = loader.load_all_agents()
        for agent in agents:
            if agent.context_needs is not None:
                schema = AgentContextSchema.from_dict(agent.context_needs)
                for cn in schema.required + schema.optional:
                    assert cn.artifact_type, f"{agent.name} has empty artifact_type"
