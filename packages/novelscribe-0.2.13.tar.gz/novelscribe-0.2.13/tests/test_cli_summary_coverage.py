"""Comprehensive tests for cli_summary module."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from cli_summary import summary


class TestSummaryGroup:
    """Test summary command group."""

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(summary, ["--help"])
        assert result.exit_code == 0


class TestGenerateCommand:
    """Test generate command."""

    def _make_project(self, fs, project_name="myproj", chapters=None):
        proj = Path(f".novels/{project_name}")
        proj.mkdir(parents=True)
        ch_dir = proj / "chapters"
        ch_dir.mkdir()
        if chapters:
            for num, content in chapters.items():
                (ch_dir / f"chapter_{num}.md").write_text(content)

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["generate", "missing"])
            assert result.exit_code != 0

    def test_neither_chapter_nor_all(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager"),
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj")
            result = runner.invoke(summary, ["generate", "myproj"])
            assert result.exit_code != 0

    def test_single_chapter(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj", chapters={1: "content"})
            mock_sm = mock_sm.return_value
            mock_sm.generate_chapter_summary.return_value = MagicMock(
                summary="A summary", key_events=["event1"], characters=["char1"]
            )
            result = runner.invoke(summary, ["generate", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_chapter_not_found(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager"),
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj")
            result = runner.invoke(summary, ["generate", "myproj", "-c", "99"])
            assert result.exit_code != 0

    def test_chapter_with_previous_summary(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj", chapters={1: "c1", 2: "c2"})
            mock_sm = mock_sm.return_value
            prev = MagicMock(summary="prev summary")
            mock_sm.get_chapter_summary.return_value = prev
            mock_sm.generate_chapter_summary.return_value = MagicMock(
                summary="ch2 summary", key_events=["ev"], characters=["ch"]
            )
            result = runner.invoke(summary, ["generate", "myproj", "-c", "2"])
            assert result.exit_code == 0

    def test_chapter_without_previous(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj", chapters={2: "c2"})
            mock_sm = mock_sm.return_value
            mock_sm.get_chapter_summary.return_value = None
            mock_sm.generate_chapter_summary.return_value = MagicMock(
                summary="ch2 summary", key_events=[], characters=[]
            )
            result = runner.invoke(summary, ["generate", "myproj", "-c", "2"])
            assert result.exit_code == 0

    def test_all_chapters(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            self._make_project(fs=True, project_name="myproj", chapters={1: "c1", 2: "c2"})
            mock_sm = mock_sm.return_value
            mock_sm.batch_generate_summaries.return_value = [
                MagicMock(chapter_number=1, summary="s1"),
                MagicMock(chapter_number=2, summary="s2"),
            ]
            result = runner.invoke(summary, ["generate", "myproj", "--all"])
            assert result.exit_code == 0

    def test_all_no_chapters_dir(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager"),
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            proj = Path(".novels/myproj")
            proj.mkdir(parents=True)
            result = runner.invoke(summary, ["generate", "myproj", "--all"])
            assert result.exit_code != 0

    def test_exception(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_summary.StorageConfig") as mock_sc:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sc.side_effect = RuntimeError("err")
            result = runner.invoke(summary, ["generate", "myproj", "-c", "1"])
            assert result.exit_code != 0


class TestGroupCommand:
    """Test group command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["group", "missing", "--start", "1", "--end", "3"])
            assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_sm.return_value.generate_group_summary.return_value = MagicMock(
                summary="group summary"
            )
            result = runner.invoke(summary, ["group", "myproj", "--start", "1", "--end", "5"])
            assert result.exit_code == 0

    def test_exception(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_summary.StorageConfig") as mock_sc:
            mock_sc.return_value = MagicMock(base_path=".novels")
            mock_sc.side_effect = RuntimeError("err")
            result = runner.invoke(summary, ["group", "myproj", "--start", "1", "--end", "3"])
            assert result.exit_code != 0


class TestUpdateGlobalCommand:
    """Test update-global command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["update-global", "missing"])
            assert result.exit_code != 0

    def test_no_summaries(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager"),
            patch("cli_summary.SummaryManagerConfig"),
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.list_chapter_summaries.return_value = []
            result = runner.invoke(summary, ["update-global", "myproj"])
            assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.list_chapter_summaries.return_value = [1, 2]
            mock_sm.return_value.update_global_summary.return_value = MagicMock(
                total_chapters_covered=2, summary="global", last_updated="today"
            )
            result = runner.invoke(summary, ["update-global", "myproj"])
            assert result.exit_code == 0


class TestShowCommand:
    """Test show command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["show", "missing"])
            assert result.exit_code != 0

    def test_neither_chapter_nor_global(self):
        runner = CliRunner()
        with runner.isolated_filesystem(), patch("cli_summary.StorageConfig") as mock_sc:
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(summary, ["show", "myproj"])
            assert result.exit_code != 0

    def test_global_summary(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.load_global_summary.return_value = MagicMock(
                summary="global summary", total_chapters_covered=5, last_updated="today"
            )
            result = runner.invoke(summary, ["show", "myproj", "--global"])
            assert result.exit_code == 0

    def test_global_not_found(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.load_global_summary.return_value = None
            result = runner.invoke(summary, ["show", "myproj", "--global"])
            assert result.exit_code != 0

    def test_chapter_summary(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.load_chapter_summary.return_value = MagicMock(
                summary="ch summary", key_events=["event1"], characters={"char1": "protagonist"}
            )
            result = runner.invoke(summary, ["show", "myproj", "-c", "1"])
            assert result.exit_code == 0

    def test_chapter_not_found(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.load_chapter_summary.return_value = None
            result = runner.invoke(summary, ["show", "myproj", "-c", "99"])
            assert result.exit_code != 0

    def test_chapter_no_key_events(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.load_chapter_summary.return_value = MagicMock(
                summary="ch summary", key_events=[], characters={}
            )
            result = runner.invoke(summary, ["show", "myproj", "-c", "1"])
            assert result.exit_code == 0


class TestContextCommand:
    """Test context command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["context", "missing", "-c", "1"])
            assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.LLMClient"),
            patch("cli_summary.LLMConfig"),
            patch("cli_summary.SummaryManager") as mock_sm,
            patch("cli_summary.SummaryManagerConfig"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_sm.return_value.get_context_for_chapter.return_value = "context text"
            result = runner.invoke(summary, ["context", "myproj", "-c", "5"])
            assert result.exit_code == 0


class TestListCommand:
    """Test list command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["list", "missing"])
            assert result.exit_code != 0

    def test_with_all_summaries(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.list_chapter_summaries.return_value = [1, 2, 3, 5]
            mock_ss.return_value.list_group_summaries.return_value = ["group_1_3"]
            mock_ss.return_value.load_global_summary.return_value = MagicMock()
            result = runner.invoke(summary, ["list", "myproj"])
            assert result.exit_code == 0

    def test_no_summaries(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.list_chapter_summaries.return_value = []
            mock_ss.return_value.list_group_summaries.return_value = []
            mock_ss.return_value.load_global_summary.return_value = None
            result = runner.invoke(summary, ["list", "myproj"])
            assert result.exit_code == 0

    def test_missing_few_chapters(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.list_chapter_summaries.return_value = [
                1,
                3,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13,
                14,
            ]
            mock_ss.return_value.list_group_summaries.return_value = []
            mock_ss.return_value.load_global_summary.return_value = None
            result = runner.invoke(summary, ["list", "myproj"])
            assert result.exit_code == 0


class TestStatsCommand:
    """Test stats command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["stats", "missing"])
            assert result.exit_code != 0

    def test_success(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore") as mock_ss,
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            mock_ss.return_value.get_summary_statistics.return_value = {
                "chapter_summaries": 10,
                "group_summaries": 2,
                "has_global_summary": True,
                "total_words_summarized": 50000,
                "storage_format": "json",
            }
            result = runner.invoke(summary, ["stats", "myproj"])
            assert result.exit_code == 0


class TestExportCommand:
    """Test export command."""

    def test_project_not_found(self):
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(summary, ["export", "missing"])
            assert result.exit_code != 0

    def test_with_output(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(
                summary, ["export", "myproj", "-o", "out.md", "--format", "markdown"]
            )
            assert result.exit_code == 0

    def test_without_output(self):
        runner = CliRunner()
        with (
            runner.isolated_filesystem(),
            patch("cli_summary.StorageConfig") as mock_sc,
            patch("cli_summary.SummaryStore"),
        ):
            mock_sc.return_value = MagicMock(base_path=".novels")
            Path(".novels/myproj").mkdir(parents=True)
            result = runner.invoke(summary, ["export", "myproj", "--format", "json"])
            assert result.exit_code == 0
