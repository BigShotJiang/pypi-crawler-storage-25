"""Unit tests for decision_processor.py — human decision handling at checkpoints."""

import pytest

from core.checkpoint_proposal import (
    Alternative,
    CheckpointDecision,
    CheckpointProposal,
    CheckpointResponse,
    ConfidenceBreakdown,
    DecisionType,
    PlanContent,
)
from core.decision_processor import DecisionProcessor


def _plan(title: str = "Test Plan", **kwargs) -> PlanContent:
    defaults = {"title": title, "pov": "third", "word_estimate": 5000, "pacing": "moderate"}
    defaults.update(kwargs)
    return PlanContent(**defaults)


def _proposal(
    checkpoint_id: str = "cp_01", phase: str = "outline", plan_pacing: str = "moderate", **kwargs
) -> CheckpointProposal:
    plan = _plan(pacing=plan_pacing)
    defaults = {
        "checkpoint_id": checkpoint_id,
        "phase": phase,
        "plan": plan,
        "confidence": 0.85,
        "reasoning": "Test reasoning",
    }
    # Handle plan override specially
    if "plan" not in kwargs:
        defaults.update(kwargs)
    return CheckpointProposal(**defaults)


def _decision(
    decision_type: DecisionType, checkpoint_id: str = "cp_01", **kwargs
) -> CheckpointDecision:
    defaults = {"decision_type": decision_type, "checkpoint_id": checkpoint_id}
    defaults.update(kwargs)
    return CheckpointDecision(**defaults)


class TestDecisionType:
    """Test DecisionType enum values."""

    def test_decision_type_values(self):
        assert DecisionType.APPROVE == "approve"
        assert DecisionType.MODIFY == "modify"
        assert DecisionType.REJECT == "reject"
        assert DecisionType.GUIDANCE == "guidance"
        assert DecisionType.ASK == "ask"

    def test_decision_type_is_string_enum(self):
        assert isinstance(DecisionType.APPROVE, str)
        assert DecisionType.APPROVE.value == "approve"


class TestDecisionProcessorProcess:
    """Test DecisionProcessor.process() method."""

    @pytest.mark.parametrize(
        "decision_type",
        [
            DecisionType.APPROVE,
            DecisionType.MODIFY,
            DecisionType.REJECT,
            DecisionType.GUIDANCE,
            DecisionType.ASK,
        ],
    )
    def test_process_routes_to_correct_handler(self, decision_type):
        """Each decision type should route to its specific handler."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(decision_type)

        response = processor.process(decision, proposal)

        assert isinstance(response, CheckpointResponse)
        assert response.decision is decision

    def test_process_unknown_decision_type_raises(self):
        """Unknown decision type should raise ValueError."""
        processor = DecisionProcessor()
        proposal = _proposal()

        class UnknownDecisionType:
            pass

        decision = _decision(DecisionType.APPROVE)
        decision.decision_type = "unknown"  # type: ignore

        with pytest.raises(ValueError, match="Unknown decision type"):
            processor.process(decision, proposal)


class TestProcessApprove:
    """Table-driven tests for APPROVE decision type."""

    @pytest.mark.parametrize(
        "confidence,expected_explanation",
        [
            (0.95, "Proposal approved. Continuing with current plan."),
            (0.50, "Proposal approved. Continuing with current plan."),
            (0.85, "Proposal approved. Continuing with current plan."),
        ],
    )
    def test_approve_always_applies_with_correct_explanation(
        self, confidence, expected_explanation
    ):
        """Approval should always apply regardless of confidence level."""
        processor = DecisionProcessor()
        proposal = _proposal(confidence=confidence)
        decision = _decision(DecisionType.APPROVE)

        response = processor.process(decision, proposal)

        assert response.applied is True
        assert response.explanation == expected_explanation
        assert response.adjustments_made == []

    def test_approve_returns_correct_response_fields(self):
        """Approval response should have all expected fields."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.APPROVE)

        response = processor.process(decision, proposal)

        assert response.decision is decision
        assert response.modified_proposal is None


class TestProcessModify:
    """Table-driven tests for MODIFY decision type."""

    @pytest.mark.parametrize(
        "modified_content,expect_applied,expect_explanation",
        [
            ({"title": "New Title"}, True, "Applied 1 modification(s)."),
            (
                {"title": "New Title", "pov": "first"},
                True,
                "Applied 2 modification(s).",
            ),
            (
                {"title": "Changed", "pacing": "fast"},
                True,
                "Applied 2 modification(s).",
            ),
        ],
    )
    def test_modify_with_content_applies_changes(
        self, modified_content, expect_applied, expect_explanation
    ):
        """Modification with content should apply changes."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.MODIFY, modified_content=modified_content)

        response = processor.process(decision, proposal)

        assert response.applied is expect_applied
        assert expect_explanation in response.explanation
        assert len(response.adjustments_made) == len(modified_content)

    def test_modify_without_content_not_applied(self):
        """Modification without content should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.MODIFY, modified_content=None)

        response = processor.process(decision, proposal)

        assert response.applied is False
        assert response.explanation == "No modifications provided."
        assert response.modified_proposal is None

    def test_modify_empty_dict_not_applied(self):
        """Modification with empty dict should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.MODIFY, modified_content={})

        response = processor.process(decision, proposal)

        assert response.applied is False

    def test_modify_returns_modified_proposal(self):
        """Modification should return modified proposal."""
        processor = DecisionProcessor()
        proposal = _proposal()
        new_title = "Modified Title"
        decision = _decision(DecisionType.MODIFY, modified_content={"title": new_title})

        response = processor.process(decision, proposal)

        assert response.modified_proposal is not None
        assert response.modified_proposal.plan.title == new_title


class TestProcessReject:
    """Table-driven tests for REJECT decision type."""

    def test_reject_always_not_applied(self):
        """Rejection should never apply the proposal."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.REJECT)

        response = processor.process(decision, proposal)

        assert response.applied is False
        assert (
            response.explanation == "Proposal rejected. Regeneration required with new constraints."
        )

    @pytest.mark.parametrize("confidence", [0.95, 0.50, 0.10])
    def test_reject_with_any_confidence(self, confidence):
        """Rejection should work regardless of proposal confidence."""
        processor = DecisionProcessor()
        proposal = _proposal(confidence=confidence)
        decision = _decision(DecisionType.REJECT)

        response = processor.process(decision, proposal)

        assert response.applied is False


class TestProcessGuidance:
    """Table-driven tests for GUIDANCE decision type."""

    @pytest.mark.parametrize(
        "guidance_text,expect_applied,expected_keywords",
        [
            ("Make the POV first person", True, ["pov", "point of view"]),
            ("Add more tension and darker themes", True, ["tension", "darker"]),
            ("Slow down the pacing for more mystery", True, ["mystery", "slower"]),
            ("Keep everything as is", False, []),
            ("Make it simpler", False, []),
        ],
    )
    def test_guidance_interpretation(self, guidance_text, expect_applied, expected_keywords):
        """Guidance should be interpreted and applied when applicable."""
        processor = DecisionProcessor()
        alt_plan = _plan(title="Alt Plan", pov="first")
        alt = Alternative(
            option_id="A",
            plan=alt_plan,
            confidence=0.80,
            tradeoff_explanation="First person POV with more tension",
        )
        proposal = _proposal(alternatives=[alt])
        decision = _decision(DecisionType.GUIDANCE, guidance_text=guidance_text)

        response = processor.process(decision, proposal)

        assert response.applied is expect_applied
        if expect_applied:
            assert len(response.adjustments_made) > 0

    def test_guidance_without_text_not_applied(self):
        """Guidance without text should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.GUIDANCE, guidance_text=None)

        response = processor.process(decision, proposal)

        assert response.applied is False
        assert response.explanation == "No guidance provided."

    def test_guidance_empty_string_not_applied(self):
        """Guidance with empty string should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.GUIDANCE, guidance_text="")

        response = processor.process(decision, proposal)

        assert response.applied is False

    def test_guidance_creates_modified_proposal_when_applied(self):
        """Guidance that applies should create modified proposal."""
        processor = DecisionProcessor()
        proposal = _proposal(plan_pacing="moderate")
        decision = _decision(
            DecisionType.GUIDANCE, guidance_text="Make it darker with more tension"
        )

        response = processor.process(decision, proposal)

        if response.applied:
            assert response.modified_proposal is not None
            assert response.modified_proposal.confidence < proposal.confidence


class TestProcessAsk:
    """Table-driven tests for ASK decision type."""

    @pytest.mark.parametrize(
        "question,expected_response_contains",
        [
            ("Why this plan?", "AI Confidence"),
            ("Why not option A?", "Alternative"),
            ("What if I changed the POV?", "what-if"),
            ("Compare alternatives", "Alternative Comparison"),
            ("Tell me more", "Reasoning"),  # Falls back to reasoning
        ],
    )
    def test_ask_returns_answer(self, question, expected_response_contains):
        """Ask should return an answer based on question type."""
        processor = DecisionProcessor()
        alt = Alternative(
            option_id="A",
            plan=_plan(title="Alt A"),
            confidence=0.75,
            tradeoff_explanation="More action",
            rejection_reasons=["Too fast"],
        )
        alt.get_confidence_percentage = lambda: "75%"
        proposal = _proposal(alternatives=[alt])
        decision = _decision(DecisionType.ASK, question=question)

        response = processor.process(decision, proposal)

        assert response.applied is True
        assert response.explanation is not None
        assert expected_response_contains.lower() in response.explanation.lower()

    def test_ask_without_question_not_applied(self):
        """Ask without question should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.ASK, question=None)

        response = processor.process(decision, proposal)

        assert response.applied is False
        assert response.explanation == "No question provided."

    def test_ask_empty_question_not_applied(self):
        """Ask with empty question should not apply."""
        processor = DecisionProcessor()
        proposal = _proposal()
        decision = _decision(DecisionType.ASK, question="")

        response = processor.process(decision, proposal)

        assert response.applied is False

    def test_ask_why_not_with_nonexistent_option(self):
        """Ask 'why not' for nonexistent option should return not found."""
        processor = DecisionProcessor()
        proposal = _proposal(alternatives=[])
        decision = _decision(DecisionType.ASK, question="Why not option Z?")

        response = processor.process(decision, proposal)

        assert "not found" in response.explanation.lower()


class TestComputeAdjustments:
    """Table-driven tests for _compute_adjustments edge cases."""

    def test_no_changes(self):
        """Identical dicts should return no adjustments."""
        processor = DecisionProcessor()
        original = {"title": "Same", "pov": "third"}
        modified = {"title": "Same", "pov": "third"}

        result = processor._compute_adjustments(original, modified)

        assert result == {}

    def test_all_fields_changed(self):
        """All different fields should be reported."""
        processor = DecisionProcessor()
        original = {"title": "Old", "pov": "third"}
        modified = {"title": "New", "pov": "first"}

        result = processor._compute_adjustments(original, modified)

        assert len(result) == 2
        assert result["title"] == ("Old", "New")
        assert result["pov"] == ("third", "first")

    def test_new_fields_added(self):
        """New fields in modified should not be in adjustments (only changed)."""
        processor = DecisionProcessor()
        original = {"title": "Title"}
        modified = {"title": "Title", "pacing": "fast"}

        result = processor._compute_adjustments(original, modified)

        assert "pacing" not in result

    def test_only_changed_fields_returned(self):
        """Only fields with different values should be returned."""
        processor = DecisionProcessor()
        original = {"title": "Same", "pov": "third", "pacing": "slow"}
        modified = {"title": "Same", "pov": "first", "pacing": "slow"}

        result = processor._compute_adjustments(original, modified)

        assert list(result.keys()) == ["pov"]


class TestInterpretGuidance:
    """Table-driven tests for _interpret_guidance edge cases."""

    @pytest.mark.parametrize(
        "guidance,expect_pov_adjustment",
        [
            ("Change the POV to first person", True),
            ("Use third person limited POV", True),
            ("Switch point of view", True),
            ("Keep the current POV", False),
        ],
    )
    def test_pov_guidance(self, guidance, expect_pov_adjustment):
        """POV-related guidance should trigger pov adjustment when alternatives have it."""
        processor = DecisionProcessor()
        alt = Alternative(
            option_id="B",
            plan=_plan(title="Alt B", pov="first"),
            confidence=0.80,
            tradeoff_explanation="First person POV",
        )
        proposal = _proposal(alternatives=[alt])

        result = processor._interpret_guidance(proposal, guidance)

        if expect_pov_adjustment:
            assert "pov" in result

    @pytest.mark.parametrize(
        "guidance,expected_pacing",
        [
            ("Make it darker with more tension", "fast"),
            ("Add more tension and drama", "fast"),
            ("Slow down the pacing", "slow"),
            ("Add more mystery", "slow"),
            ("Keep the pacing the same", None),
        ],
    )
    def test_pacing_guidance(self, guidance, expected_pacing):
        """Pacing-related guidance should set expected pacing."""
        processor = DecisionProcessor()
        proposal = _proposal(plan_pacing="moderate")

        result = processor._interpret_guidance(proposal, guidance)

        if expected_pacing:
            assert result.get("pacing") == expected_pacing

    def test_guidance_with_no_alternatives(self):
        """Guidance should still work with no alternatives."""
        processor = DecisionProcessor()
        proposal = _proposal(alternatives=[])

        result = processor._interpret_guidance(proposal, "Change POV")

        # POV adjustment needs alternatives, so won't find anything
        assert result == {}


class TestGenerateAnswer:
    """Table-driven tests for _generate_answer edge cases."""

    def test_why_question(self):
        """'Why' question should call _explain_why_proposal."""
        processor = DecisionProcessor()
        proposal = _proposal(confidence=0.85, reasoning="Test reasoning")

        answer = processor._generate_answer(proposal, "Why this?")

        assert "AI Confidence" in answer
        assert "Test reasoning" in answer

    def test_why_not_question_existing_option(self):
        """'Why not' question for existing option should explain."""
        processor = DecisionProcessor()
        alt = Alternative(
            option_id="A",
            plan=_plan(title="Alt A"),
            confidence=0.75,
            tradeoff_explanation="More action",
            rejection_reasons=["Too fast"],
        )
        proposal = _proposal(alternatives=[alt])

        answer = processor._generate_answer(proposal, "Why not option A?")

        assert "option a" in answer.lower()
        assert "rejection" in answer.lower() or "confidence" in answer.lower()

    def test_what_if_question(self):
        """'What if' question should return what-if analysis."""
        processor = DecisionProcessor()
        proposal = _proposal()

        answer = processor._generate_answer(proposal, "What if I changed the ending?")

        assert "what-if" in answer.lower() or "change" in answer.lower()

    def test_alternative_question(self):
        """'Alternative' or 'compare' question should compare alternatives."""
        processor = DecisionProcessor()
        alt1 = Alternative(
            option_id="A",
            plan=_plan(title="Alt A"),
            confidence=0.80,
            tradeoff_explanation="More action",
        )
        alt2 = Alternative(
            option_id="B",
            plan=_plan(title="Alt B"),
            confidence=0.75,
            tradeoff_explanation="More drama",
        )
        proposal = _proposal(alternatives=[alt1, alt2])

        answer = processor._generate_answer(proposal, "Compare alternatives")

        assert "Alternative Comparison" in answer
        assert "A" in answer
        assert "B" in answer

    def test_no_alternatives_compare_returns_message(self):
        """Compare with no alternatives should return informative message."""
        processor = DecisionProcessor()
        proposal = _proposal(alternatives=[])

        answer = processor._generate_answer(proposal, "Compare alternatives")

        assert "No alternatives" in answer

    def test_fallback_to_reasoning(self):
        """Unrecognized question should fall back to reasoning."""
        processor = DecisionProcessor()
        proposal = _proposal(reasoning="Test reasoning fallback")

        answer = processor._generate_answer(proposal, "Random question")

        assert "Test reasoning fallback" in answer


class TestValidateModification:
    """Table-driven tests for validate_modification edge cases."""

    @pytest.mark.parametrize(
        "modified_content,expect_valid,expected_error",
        [
            ({"title": "Valid"}, True, None),
            ({"title": "Valid", "pov": "first"}, True, None),
            ({}, False, "Empty modification"),
            (None, False, "Empty modification"),
        ],
    )
    def test_validate_modification_results(self, modified_content, expect_valid, expected_error):
        """Validation should return expected result for each case."""
        processor = DecisionProcessor()

        is_valid, error_msg = processor.validate_modification(modified_content)

        assert is_valid is expect_valid
        if expected_error:
            assert expected_error in error_msg

    def test_validate_missing_required_field(self):
        """Validation should fail if title is missing."""
        processor = DecisionProcessor()

        is_valid, error_msg = processor.validate_modification({"pov": "first"})

        assert is_valid is False
        assert "title" in error_msg


class TestExplainWhyNot:
    """Table-driven tests for _explain_why_not edge cases."""

    def test_explain_why_not_existing_option(self):
        """Should explain why an existing alternative was not chosen."""
        processor = DecisionProcessor()
        alt = Alternative(
            option_id="X",
            plan=_plan(title="Option X"),
            confidence=0.70,
            tradeoff_explanation="Balanced approach",
            rejection_reasons=["Less exciting"],
        )
        alt.get_confidence_percentage = lambda: "70%"
        proposal = _proposal(alternatives=[alt])

        explanation = processor._explain_why_not(proposal, "Why not option X?")

        assert "option x" in explanation.lower()
        assert "0.70" in explanation or "70%" in explanation

    def test_explain_why_not_nonexistent_option(self):
        """Should return not found message for nonexistent option."""
        processor = DecisionProcessor()
        proposal = _proposal(alternatives=[])

        explanation = processor._explain_why_not(proposal, "Why not option Z?")

        assert "not found" in explanation.lower()


class TestCompareAlternatives:
    """Table-driven tests for _compare_alternatives edge cases."""

    def test_compare_with_alternatives(self):
        """Should compare all alternatives."""
        processor = DecisionProcessor()
        alt1 = Alternative(
            option_id="A",
            plan=_plan(title="Alt A"),
            confidence=0.85,
            tradeoff_explanation="More action",
        )
        alt1.get_confidence_percentage = lambda: "85%"
        alt2 = Alternative(
            option_id="B",
            plan=_plan(title="Alt B"),
            confidence=0.75,
            tradeoff_explanation="More drama",
        )
        alt2.get_confidence_percentage = lambda: "75%"
        proposal = _proposal(alternatives=[alt1, alt2])

        comparison = processor._compare_alternatives(proposal)

        assert "Alternative Comparison" in comparison
        assert "A" in comparison
        assert "B" in comparison

    def test_compare_no_alternatives(self):
        """Should return informative message when no alternatives."""
        processor = DecisionProcessor()
        proposal = _proposal(alternatives=[])

        comparison = processor._compare_alternatives(proposal)

        assert "No alternatives" in comparison


class TestConfidenceBreakdown:
    """Tests for ConfidenceBreakdown.total property edge cases."""

    def test_total_calculation(self):
        """Total should calculate weighted sum correctly."""
        breakdown = ConfidenceBreakdown(
            coherence=0.90,
            character=0.80,
            pacing=0.85,
            originality=0.75,
            completeness=0.90,
        )

        expected = 0.90 * 0.30 + 0.80 * 0.25 + 0.85 * 0.20 + 0.75 * 0.15 + 0.90 * 0.10
        assert abs(breakdown.total - expected) < 0.001

    def test_total_all_zeros(self):
        """Total with all zeros should be zero."""
        breakdown = ConfidenceBreakdown()

        assert breakdown.total == 0.0


class TestCheckpointProposalGetMethods:
    """Tests for CheckpointProposal helper methods."""

    def test_get_alternative_by_id_found(self):
        """Should return alternative when found."""
        alt = Alternative(
            option_id="TEST",
            plan=_plan(),
            confidence=0.80,
            tradeoff_explanation="Test",
        )
        proposal = _proposal(alternatives=[alt])

        found = proposal.get_alternative_by_id("TEST")

        assert found is alt

    def test_get_alternative_by_id_not_found(self):
        """Should return None when not found."""
        proposal = _proposal(alternatives=[])

        found = proposal.get_alternative_by_id("NONEXISTENT")

        assert found is None

    def test_get_confidence_percentage(self):
        """Should return confidence as percentage string."""
        proposal = _proposal(confidence=0.857)

        percentage = proposal.get_confidence_percentage()

        assert percentage == "86%"
