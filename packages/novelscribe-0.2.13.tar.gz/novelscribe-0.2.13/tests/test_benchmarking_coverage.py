"""Tests for core.benchmarking to achieve 80%+ coverage."""

import json
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from core.benchmarking import (
    BenchmarkHistory,
    BenchmarkingEngine,
    BenchmarkReport,
    BenchmarkResult,
    BenchmarkType,
    ComparisonMetric,
    PerformanceMetrics,
)
from core.quality_metrics import QualityMetrics


def make_metrics(**overrides) -> QualityMetrics:
    defaults = dict(
        chapter_number=1,
        version=1,
        timestamp=datetime.now(),
        word_count=5000,
        sentence_count=250,
        paragraph_count=25,
        avg_sentence_length=20.0,
        avg_paragraph_length=200.0,
        flesch_kincaid=8.0,
        gunning_fog=10.0,
        smog_index=7.0,
        dialogue_ratio=0.3,
        dialogue_line_count=50,
        speaker_clarity=0.8,
        scene_variation=0.6,
        action_frequency=0.05,
        character_consistency=0.9,
        plot_continuity=0.85,
        passive_voice_ratio=0.08,
        adverb_frequency=0.04,
        vocabulary_diversity=0.5,
        overall_quality_score=0.82,
    )
    defaults.update(overrides)
    return QualityMetrics(**defaults)


class TestBenchmarkType:
    """Test BenchmarkType enum."""

    def test_values(self):
        assert BenchmarkType.PERFORMANCE.value == "performance"
        assert BenchmarkType.QUALITY.value == "quality"
        assert BenchmarkType.STYLE.value == "style"
        assert BenchmarkType.READABILITY.value == "readability"


class TestComparisonMetric:
    """Test ComparisonMetric enum."""

    def test_values(self):
        assert ComparisonMetric.GENERATION_TIME.value == "generation_time"
        assert ComparisonMetric.TOKEN_USAGE.value == "token_usage"
        assert ComparisonMetric.WORDS_PER_MINUTE.value == "words_per_minute"
        assert ComparisonMetric.QUALITY_SCORE.value == "quality_score"
        assert ComparisonMetric.READABILITY_SCORE.value == "readability_score"
        assert ComparisonMetric.DIALOGUE_RATIO.value == "dialogue_ratio"
        assert ComparisonMetric.VOCABULARY_DIVERSITY.value == "vocabulary_diversity"


class TestBenchmarkResult:
    """Test BenchmarkResult model."""

    def test_str_basic(self):
        r = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="test",
            score=0.85,
        )
        s = str(r)
        assert "0.85" in s

    def test_str_with_percentile(self):
        r = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="test",
            score=0.85,
            percentile=75.0,
        )
        s = str(r)
        assert "75.0%" in s

    def test_str_with_comparison(self):
        r = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="test",
            score=0.85,
            comparison="above average",
        )
        s = str(r)
        assert "above average" in s

    def test_str_with_all_fields(self):
        r = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="test",
            score=0.85,
            percentile=90.0,
            comparison="excellent",
        )
        s = str(r)
        assert "0.85" in s
        assert "90.0%" in s
        assert "excellent" in s


class TestBenchmarkReport:
    """Test BenchmarkReport model."""

    def test_performance_score(self):
        r1 = BenchmarkResult(benchmark_type=BenchmarkType.PERFORMANCE, category="p1", score=100.0)
        r2 = BenchmarkResult(benchmark_type=BenchmarkType.PERFORMANCE, category="p2", score=200.0)
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[r1, r2])
        assert report.performance_score == 150.0

    def test_performance_score_empty(self):
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[])
        assert report.performance_score == 0.0

    def test_quality_score(self):
        r1 = BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="q1", score=0.8)
        r2 = BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="q2", score=0.9)
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[r1, r2])
        assert report.quality_score == pytest.approx(0.85)

    def test_quality_score_empty(self):
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[])
        assert report.quality_score == 0.0

    def test_get_results_by_type(self):
        r1 = BenchmarkResult(benchmark_type=BenchmarkType.PERFORMANCE, category="p", score=1.0)
        r2 = BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="q", score=0.5)
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[r1, r2])
        assert len(report.get_results_by_type(BenchmarkType.PERFORMANCE)) == 1
        assert len(report.get_results_by_type(BenchmarkType.QUALITY)) == 1

    def test_get_results_by_type_empty(self):
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[])
        assert len(report.get_results_by_type(BenchmarkType.PERFORMANCE)) == 0

    def test_get_results_by_category(self):
        r1 = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY, category="readability", score=0.8
        )
        r2 = BenchmarkResult(benchmark_type=BenchmarkType.QUALITY, category="dialogue", score=0.7)
        report = BenchmarkReport(project_name="test", timestamp=datetime.now(), results=[r1, r2])
        assert len(report.get_results_by_category("readability")) == 1
        assert len(report.get_results_by_category("nonexistent")) == 0


class TestPerformanceMetrics:
    """Test PerformanceMetrics model."""

    def test_creation(self):
        p = PerformanceMetrics(
            generation_time_seconds=10.0,
            token_count=1000,
            word_count=500,
            words_per_minute=3000.0,
            tokens_per_second=100.0,
        )
        assert p.generation_time_seconds == 10.0
        assert p.token_count == 1000
        assert p.word_count == 500
        assert p.words_per_minute == 3000.0
        assert p.tokens_per_second == 100.0


class TestBenchmarkHistory:
    """Test BenchmarkHistory model."""

    def test_add_metrics(self):
        history = BenchmarkHistory(project_name="test")
        m = make_metrics()
        history.add_metrics(m)
        assert len(history.entries) == 1

    def test_add_performance(self):
        history = BenchmarkHistory(project_name="test")
        p = PerformanceMetrics(
            generation_time_seconds=10.0,
            token_count=1000,
            word_count=500,
            words_per_minute=3000.0,
            tokens_per_second=100.0,
        )
        history.add_performance(p)
        assert len(history.performance_entries) == 1

    def test_get_trend_insufficient_data(self):
        history = BenchmarkHistory(project_name="test")
        slope, corr = history.get_trend("overall_quality_score")
        assert slope == 0.0
        assert corr == 0.0

    def test_get_trend_single_entry(self):
        history = BenchmarkHistory(project_name="test")
        history.add_metrics(make_metrics(overall_quality_score=0.8))
        slope, corr = history.get_trend("overall_quality_score")
        assert slope == 0.0
        assert corr == 0.0

    def test_get_trend_multiple_entries(self):
        history = BenchmarkHistory(project_name="test")
        history.add_metrics(make_metrics(overall_quality_score=0.7))
        history.add_metrics(make_metrics(overall_quality_score=0.8))
        history.add_metrics(make_metrics(overall_quality_score=0.9))
        slope, corr = history.get_trend("overall_quality_score")
        assert slope > 0
        assert corr > 0

    def test_get_trend_missing_attribute(self):
        history = BenchmarkHistory(project_name="test")
        history.add_metrics(make_metrics())
        history.add_metrics(make_metrics())
        slope, corr = history.get_trend("nonexistent_attr")
        assert slope == 0.0
        assert corr == 0.0

    def test_get_trend_constant_values(self):
        history = BenchmarkHistory(project_name="test")
        for _ in range(3):
            history.add_metrics(make_metrics(overall_quality_score=0.8))
        slope, corr = history.get_trend("overall_quality_score")
        assert slope == 0.0

    def test_get_trend_two_entries_different(self):
        history = BenchmarkHistory(project_name="test")
        history.add_metrics(make_metrics(overall_quality_score=0.5))
        history.add_metrics(make_metrics(overall_quality_score=0.9))
        slope, corr = history.get_trend("overall_quality_score")
        assert slope > 0


class TestBenchmarkingEngine:
    """Test BenchmarkingEngine class."""

    def test_init_with_string_path(self, tmp_path):
        engine = BenchmarkingEngine(project_root=str(tmp_path))
        assert engine.project_root == tmp_path

    def test_init_default_path(self):
        engine = BenchmarkingEngine()
        assert engine.project_root == Path.cwd()

    def test_init_with_path_object(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine.project_root == tmp_path

    def test_benchmark_performance(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine.benchmark_performance("proj", 10.0, 1000, 500)
        assert result.score > 0
        assert result.benchmark_type == BenchmarkType.PERFORMANCE
        assert result.percentile is not None

    def test_benchmark_performance_zero_time(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine.benchmark_performance("proj", 0.0, 1000, 500)
        assert result.score == 0.0

    def test_benchmark_performance_metadata(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine.benchmark_performance("proj", 10.0, 1000, 500)
        assert result.metadata["generation_time"] == 10.0
        assert result.metadata["token_count"] == 1000
        assert result.metadata["word_count"] == 500
        assert result.metadata["tokens_per_second"] == 100.0

    def test_benchmark_performance_multiple(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        engine.benchmark_performance("proj", 5.0, 500, 300)
        assert len(engine.history["proj"].performance_entries) == 2

    def test_benchmark_quality(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        results = engine.benchmark_quality("proj", metrics)
        assert len(results) > 0
        assert any(r.category == "overall_quality_score" for r in results)

    def test_benchmark_quality_with_genre(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        results = engine.benchmark_quality("proj", metrics, genre="fantasy")
        assert len(results) > 0

    def test_benchmark_quality_all_genres(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        for genre in ("fantasy", "mystery", "romance", "scifi"):
            metrics = make_metrics()
            results = engine.benchmark_quality("proj", metrics, genre=genre)
            assert len(results) > 0

    def test_benchmark_quality_unknown_genre(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        results = engine.benchmark_quality("proj", metrics, genre="unknown_genre")
        assert len(results) > 0

    def test_benchmark_quality_below_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(flesch_kincaid=2.0)
        results = engine.benchmark_quality("proj", metrics)
        assert len(results) > 0

    def test_benchmark_quality_above_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(flesch_kincaid=20.0)
        results = engine.benchmark_quality("proj", metrics)
        assert len(results) > 0

    def test_benchmark_quality_bestseller(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        results = engine.benchmark_quality("proj", metrics, comparison_benchmark="bestseller")
        assert len(results) > 0

    def test_benchmark_quality_unknown_benchmark(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        results = engine.benchmark_quality("proj", metrics, comparison_benchmark="unknown")
        overall = [r for r in results if r.category == "overall_quality_score"]
        assert len(overall) == 1

    def test_benchmark_quality_passive_voice_in_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(passive_voice_ratio=0.05)
        results = engine.benchmark_quality("proj", metrics, genre="fantasy")
        passive_results = [r for r in results if r.category == "passive_voice_ratio"]
        assert len(passive_results) == 1

    def test_benchmark_quality_passive_voice_above_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(passive_voice_ratio=0.5)
        results = engine.benchmark_quality("proj", metrics, genre="fantasy")
        passive_results = [r for r in results if r.category == "passive_voice_ratio"]
        assert len(passive_results) == 1

    def test_benchmark_quality_creates_history(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        engine.benchmark_quality("proj", metrics)
        assert "proj" in engine.history
        assert len(engine.history["proj"].entries) == 1

    def test_benchmark_quality_score_in_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(flesch_kincaid=8.0, dialogue_ratio=0.3, vocabulary_diversity=0.5)
        results = engine.benchmark_quality("proj", metrics)
        in_range_results = [
            r
            for r in results
            if r.metadata.get("in_range") and r.category != "overall_quality_score"
        ]
        for r in in_range_results:
            if r.category == "passive_voice_ratio":
                assert r.metadata["score"] == pytest.approx(1.0 - 0.08)
            else:
                assert r.metadata["score"] == 1.0

    def test_benchmark_quality_above_max_range(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics(dialogue_ratio=0.9)
        results = engine.benchmark_quality("proj", metrics)
        dialogue_results = [r for r in results if r.category == "dialogue_ratio"]
        assert len(dialogue_results) >= 1

    def test_generate_benchmark_report(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        metrics = make_metrics()
        engine.benchmark_quality("proj", metrics)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        report = engine.generate_benchmark_report("proj")
        assert report.project_name == "proj"
        assert len(report.results) > 0

    def test_generate_report_performance_only(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        report = engine.generate_benchmark_report("proj", benchmark_type=BenchmarkType.PERFORMANCE)
        assert len(report.results) > 0

    def test_generate_report_quality_only(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        report = engine.generate_benchmark_report("proj", benchmark_type=BenchmarkType.QUALITY)
        assert len(report.results) > 0

    def test_generate_report_no_history(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        report = engine.generate_benchmark_report("nonexistent")
        assert len(report.results) == 0

    def test_generate_report_limits_to_ten_entries(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        for i in range(15):
            engine.benchmark_performance("proj", 10.0 + i, 1000, 500)
        report = engine.generate_benchmark_report("proj")
        perf_results = [r for r in report.results if r.benchmark_type == BenchmarkType.PERFORMANCE]
        assert len(perf_results) == 10

    def test_compare_versions(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        m1 = make_metrics(overall_quality_score=0.7, word_count=4000)
        m2 = make_metrics(overall_quality_score=0.85, word_count=5000)
        comparisons = engine.compare_versions("proj", m1, m2)
        assert comparisons["overall"]["quality_score_change"] == pytest.approx(0.15)
        assert comparisons["overall"]["improved"] is True
        assert comparisons["content_metrics"]["word_count_change"] == 1000

    def test_compare_versions_declined(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        m1 = make_metrics(overall_quality_score=0.9)
        m2 = make_metrics(overall_quality_score=0.5)
        comparisons = engine.compare_versions("proj", m1, m2)
        assert comparisons["overall"]["improved"] is False

    def test_compare_versions_all_metrics(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        m1 = make_metrics()
        m2 = make_metrics()
        comparisons = engine.compare_versions("proj", m1, m2)
        assert "content_metrics" in comparisons
        assert "readability_metrics" in comparisons
        assert "dialogue_metrics" in comparisons
        assert "style_metrics" in comparisons
        assert "overall" in comparisons

    def test_compare_versions_word_count_percent(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        m1 = make_metrics(word_count=1000)
        m2 = make_metrics(word_count=1500)
        comparisons = engine.compare_versions("proj", m1, m2)
        assert comparisons["content_metrics"]["word_count_percent_change"] == pytest.approx(50.0)

    def test_track_progress_no_data(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine.track_progress("nonexistent")
        assert result["trend"] == "no_data"
        assert result["current"] is None
        assert result["average"] is None
        assert result["improvement"] is None

    def test_track_progress_no_entries(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.history["proj"] = BenchmarkHistory(project_name="proj")
        result = engine.track_progress("proj")
        assert result["trend"] == "no_data"

    def test_track_progress_improving(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        scores = [0.5, 0.6, 0.7, 0.8, 0.9]
        for i, s in enumerate(scores):
            engine.history.setdefault("proj", BenchmarkHistory(project_name="proj")).add_metrics(
                make_metrics(overall_quality_score=s, version=i + 1)
            )
        result = engine.track_progress("proj")
        assert result["trend"] == "improving"
        assert result["current"] == 0.9

    def test_track_progress_declining(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        scores = [0.9, 0.8, 0.7, 0.6, 0.5]
        for i, s in enumerate(scores):
            engine.history.setdefault("proj", BenchmarkHistory(project_name="proj")).add_metrics(
                make_metrics(overall_quality_score=s, version=i + 1)
            )
        result = engine.track_progress("proj")
        assert result["trend"] == "declining"

    def test_track_progress_stable(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        scores = [0.7, 0.8, 0.7]
        for i, s in enumerate(scores):
            engine.history.setdefault("proj", BenchmarkHistory(project_name="proj")).add_metrics(
                make_metrics(overall_quality_score=s, version=i + 1)
            )
        result = engine.track_progress("proj")
        assert result["trend"] == "stable"

    def test_track_progress_two_entries(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.history.setdefault("proj", BenchmarkHistory(project_name="proj"))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.6))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.8))
        result = engine.track_progress("proj")
        assert result["trend"] == "improving"
        assert result["total_entries"] == 2

    def test_track_progress_two_entries_declining(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.history.setdefault("proj", BenchmarkHistory(project_name="proj"))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.8))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.6))
        result = engine.track_progress("proj")
        assert result["trend"] == "declining"

    def test_track_progress_missing_attr(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.history.setdefault("proj", BenchmarkHistory(project_name="proj"))
        engine.history["proj"].add_metrics(make_metrics())
        result = engine.track_progress("proj", metric="nonexistent")
        assert result["trend"] == "no_data"

    def test_track_progress_exactly_three_entries(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.history.setdefault("proj", BenchmarkHistory(project_name="proj"))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.5))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.6))
        engine.history["proj"].add_metrics(make_metrics(overall_quality_score=0.7))
        result = engine.track_progress("proj")
        assert result["trend"] == "improving"
        assert result["average"] is not None

    def test_calculate_percentile_empty(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._calculate_percentile(50.0, []) == 50.0

    def test_calculate_percentile(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        values = [10.0, 20.0, 30.0, 40.0, 50.0]
        p = engine._calculate_percentile(30.0, values)
        assert 40.0 <= p <= 60.0

    def test_calculate_percentile_min(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        p = engine._calculate_percentile(5.0, [10.0, 20.0, 30.0])
        assert p < 50.0

    def test_calculate_percentile_max(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        p = engine._calculate_percentile(50.0, [10.0, 20.0, 30.0])
        assert p > 50.0

    def test_generate_comparison_below(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine._generate_comparison(5.0, 10.0, 20.0)
        assert "below" in result

    def test_generate_comparison_above(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine._generate_comparison(25.0, 10.0, 20.0)
        assert "above" in result

    def test_generate_comparison_within(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        result = engine._generate_comparison(15.0, 10.0, 20.0)
        assert "within" in result

    def test_determine_quality_gate_platinum(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._determine_quality_gate(0.95) == "platinum"

    def test_determine_quality_gate_gold(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._determine_quality_gate(0.85) == "gold"

    def test_determine_quality_gate_silver(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._determine_quality_gate(0.75) == "silver"

    def test_determine_quality_gate_bronze(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._determine_quality_gate(0.5) == "bronze"

    def test_determine_quality_gate_exact_thresholds(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        assert engine._determine_quality_gate(0.9) == "platinum"
        assert engine._determine_quality_gate(0.8) == "gold"
        assert engine._determine_quality_gate(0.7) == "silver"

    def test_export_benchmark_data(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        output = tmp_path / "export.json"
        result = engine.export_benchmark_data("proj", output)
        assert result == output
        with open(output) as f:
            data = json.load(f)
        assert data["project_name"] == "proj"
        assert data["summary"]["total_quality_entries"] == 1
        assert data["summary"]["total_performance_entries"] == 1
        assert data["summary"]["latest_quality_score"] is not None
        assert data["summary"]["latest_words_per_minute"] is not None

    def test_export_benchmark_data_default_path(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        result = engine.export_benchmark_data("proj")
        assert result.exists()
        assert "proj_benchmarks.json" in str(result)

    def test_export_benchmark_data_no_history(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        with pytest.raises(ValueError, match="No benchmark history"):
            engine.export_benchmark_data("nonexistent")

    def test_export_benchmark_data_only_quality(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        output = tmp_path / "export.json"
        engine.export_benchmark_data("proj", output)
        with open(output) as f:
            data = json.load(f)
        assert data["summary"]["latest_words_per_minute"] is None

    def test_export_benchmark_data_only_performance(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        output = tmp_path / "export.json"
        engine.export_benchmark_data("proj", output)
        with open(output) as f:
            data = json.load(f)
        assert data["summary"]["latest_quality_score"] is None

    def test_get_statistics(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics(overall_quality_score=0.8))
        engine.benchmark_quality("proj", make_metrics(overall_quality_score=0.9))
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        stats = engine.get_statistics("proj")
        assert stats["project_name"] == "proj"
        assert stats["quality_metrics"]["total_entries"] == 2
        assert stats["quality_metrics"]["average_score"] == pytest.approx(0.85)
        assert stats["quality_metrics"]["min_score"] == 0.8
        assert stats["quality_metrics"]["max_score"] == 0.9

    def test_get_statistics_not_found(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        stats = engine.get_statistics("nonexistent")
        assert "error" in stats

    def test_get_statistics_single_entry(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        stats = engine.get_statistics("proj")
        assert stats["quality_metrics"]["std_dev"] is None

    def test_get_statistics_single_perf_entry(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        stats = engine.get_statistics("proj")
        assert stats["performance_metrics"]["std_dev"] is None

    def test_get_statistics_no_quality(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_performance("proj", 10.0, 1000, 500)
        stats = engine.get_statistics("proj")
        assert stats["quality_metrics"]["average_score"] is None
        assert stats["quality_metrics"]["total_entries"] == 0

    def test_get_statistics_no_performance(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        stats = engine.get_statistics("proj")
        assert stats["performance_metrics"]["average_wpm"] is None
        assert stats["performance_metrics"]["total_entries"] == 0

    def test_load_history_corrupt_file(self, tmp_path):
        scribe_dir = tmp_path / ".scribe"
        scribe_dir.mkdir()
        (scribe_dir / "benchmark_history.json").write_text("not valid json{{{")
        with patch("builtins.print") as mock_print:
            BenchmarkingEngine(project_root=tmp_path)
            mock_print.assert_called()

    def test_load_history_valid_file(self, tmp_path):
        scribe_dir = tmp_path / ".scribe"
        scribe_dir.mkdir()
        engine = BenchmarkingEngine(project_root=tmp_path)
        engine.benchmark_quality("proj", make_metrics())
        engine2 = BenchmarkingEngine(project_root=tmp_path)
        assert "proj" in engine2.history

    def test_save_history_error(self, tmp_path):
        engine = BenchmarkingEngine(project_root=tmp_path)
        with patch("builtins.open", side_effect=PermissionError("denied")):
            with patch("builtins.print") as mock_print:
                engine._save_history()
                mock_print.assert_called()

    def test_quality_benchmarks_class_attribute(self):
        assert "published_novel" in BenchmarkingEngine.QUALITY_BENCHMARKS
        assert "bestseller" in BenchmarkingEngine.QUALITY_BENCHMARKS

    def test_genre_benchmarks_class_attribute(self):
        assert "fantasy" in BenchmarkingEngine.GENRE_BENCHMARKS
        assert "mystery" in BenchmarkingEngine.GENRE_BENCHMARKS
        assert "romance" in BenchmarkingEngine.GENRE_BENCHMARKS
        assert "scifi" in BenchmarkingEngine.GENRE_BENCHMARKS
