"""
Style Utility Module v1.0
Contains ANSI Escape Codes for Terminal Formatting
"""
import os

# --- Text Colors ---
BLACK   = "\033[30m"
RED     = "\033[91m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
BLUE    = "\033[94m"
MAGENTA = "\033[95m"
CYAN    = "\033[96m"
WHITE   = "\033[97m"

# --- Formatting ---
BOLD      = "\033[1m"
DIM       = "\033[2m"
ITALIC    = "\033[3m"
UNDERLINE = "\033[4m"
BLINK     = "\033[5m"
REVERSE   = "\033[7m"
RESET     = "\033[0m"

# Random Symbols
# 
# Success/Check: ✔, ✅, ●
# 
# Error/Alert: ✘, ✖, ⚠, 🚫
# 
# Information: ℹ, 💡, ➤, »
# 
# Reaction Arrows: → (Forward), ⇌ (Equilibrium), ↔ (Resonance), ↑ (Gas), ↓ (Precipitate)
# 
# Elements/Math: ∆ (Delta/Heat), π (Pi), ∞ (Infinity), ≈ (Approximately), ± (Plus/Minus), × (Times)
# 
# Units: ℃ (Celsius), ℉ (Fahrenheit), ° (Degree), Ω (Ohm/Resistance), µ (Micro)


# --- Functional Helpers ---
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def header(text):
    print(f"{BLUE}{BOLD}{'='*40}")
    print(f"{CYAN}  {text.upper()}")
    print(f"{BLUE}{'='*40}{RESET}\n")

# --- THE DEMO SECTION ---
# This block ONLY runs if you type 'python3 style.py' directly.
# It will NOT run when you import it into other files.
if __name__ == "__main__":
    clear_screen()
    header("Style Module Demo")
    
    print(f"{GREEN}Checkmark Test:{RESET} {GREEN}[✔]{RESET} System Online")
    print(f"{RED}Error Test:{RESET} {RED}[✘]{RESET} File Not Found")
    print(f"{YELLOW}{ITALIC}Warning:{RESET} Low battery...")
    print(f"{BLUE}{UNDERLINE}Link Style:{RESET} https://google.com")
    
    print(f"\n{MAGENTA}Testing finished.{RESET}")   
    
