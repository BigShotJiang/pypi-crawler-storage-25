# actionlayer-mcp

MCP server for [ActionLayer](https://action-layer.dev) — give Claude Code (and any MCP host) access to ActionLayer's typed action catalog: 30+ actions across Gmail, Calendar, Drive, Slack, Notion, GitHub, Stripe, Linear, Resy, Partiful, USPS, and more.

## Install

Get an API key at https://action-layer.dev/join, then:

```bash
claude mcp add --scope user actionlayer "uvx" "actionlayer-mcp" \
  --env ACTIONLAYER_API_KEY="ak_…" \
  --env ACTIONLAYER_API_URL="https://api.action-layer.dev"
```

Restart Claude Code and try:

```
Summarize my 3 most recent unread emails.
```

## How it works

This package is a thin shim. The actual execution lives on ActionLayer's
service. The MCP server here exposes one tool — `actionlayer_invoke_action` —
plus helpers to list the catalog, create jobs, and manage the cyborg loop.
Auth is via your bearer API key; the server proxies calls and surfaces
the typed response back to your agent host.

## Usage from other MCP hosts

```bash
# stdio transport (default)
actionlayer-mcp

# also works with Cursor, Cody, Codex, etc. — any MCP host
```

Env vars:
- `ACTIONLAYER_API_KEY` — required, your bearer key
- `ACTIONLAYER_API_URL` — defaults to `https://api.action-layer.dev`

## Changelog

### 0.2.0
- Async-by-default dispatch for browser actions. `actionlayer_invoke_action`
  now returns `outcome="queued"` + `payload.ticket_id` for browser actions
  instead of holding the connection open for minutes (the previous behavior
  hit gateway timeouts at 60s and triggered LLM retries that double-fired
  browser sessions).
- New `actionlayer_get_action_ticket(ticket_id)` MCP tool — poll an action
  ticket until terminal. Returns `is_terminal`, `outcome`, `output`,
  `live_view_url`, etc.
- Updated `actionlayer_invoke_action` docstring with explicit "DO NOT
  RETRY when outcome==queued" instructions for agent hosts.

### 0.1.0
- Initial release. Six MCP tools: list_actions, get_action,
  invoke_action, create_job, get_job, cancel_job + legacy ticket tools.

## License

MIT
