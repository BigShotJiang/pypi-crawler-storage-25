"""Verify the nested ``client.workstreams.{blueprints,cycles}`` namespaces.

These shims exist so the externally-documented SDK example reads cleanly
(per CONNECT-24H-BRIEF). Each namespace method must proxy to the
canonical flat method on ``WorkstreamsResource`` without re-implementing
HTTP calls.
"""

from __future__ import annotations

from unittest.mock import MagicMock

from heyarchie.resources.workstreams import (
    WorkstreamsResource,
    _BlueprintsNamespace,
    _CyclesNamespace,
)


def _make_resource() -> WorkstreamsResource:
    transport = MagicMock(name="SyncTransport")
    return WorkstreamsResource(transport)


def test_blueprints_namespace_attached() -> None:
    r = _make_resource()
    assert isinstance(r.blueprints, _BlueprintsNamespace)


def test_cycles_namespace_attached() -> None:
    r = _make_resource()
    assert isinstance(r.cycles, _CyclesNamespace)


def test_blueprints_list_proxies_to_workstreams_list(monkeypatch) -> None:
    r = _make_resource()
    captured: dict = {}

    def fake_list(**kwargs):
        captured.update(kwargs)
        return "RESULT"

    monkeypatch.setattr(r, "list", fake_list)
    out = r.blueprints.list(limit=42, after="cursor-x", client_id="c-1")
    assert out == "RESULT"
    assert captured == {"limit": 42, "after": "cursor-x", "client_id": "c-1"}


def test_cycles_create_proxies_to_start_cycle(monkeypatch) -> None:
    r = _make_resource()
    captured: dict = {}

    def fake_start(blueprint_id, *, input_data=None, priority=5):
        captured["blueprint_id"] = blueprint_id
        captured["input_data"] = input_data
        captured["priority"] = priority
        return "CYCLE"

    monkeypatch.setattr(r, "start_cycle", fake_start)
    out = r.cycles.create("bp-123", input_data={"period": "Q1"}, priority=2)
    assert out == "CYCLE"
    assert captured == {
        "blueprint_id": "bp-123",
        "input_data": {"period": "Q1"},
        "priority": 2,
    }


def test_cycles_get_proxies_to_get_cycle(monkeypatch) -> None:
    r = _make_resource()
    monkeypatch.setattr(r, "get_cycle", lambda cid: f"GOT:{cid}")
    assert r.cycles.get("cy-9") == "GOT:cy-9"


def test_cycles_lifecycle_methods_proxy(monkeypatch) -> None:
    r = _make_resource()
    monkeypatch.setattr(r, "pause_cycle", lambda cid: f"P:{cid}")
    monkeypatch.setattr(r, "resume_cycle", lambda cid: f"R:{cid}")
    monkeypatch.setattr(r, "cancel_cycle", lambda cid: f"C:{cid}")
    assert r.cycles.pause("x") == "P:x"
    assert r.cycles.resume("x") == "R:x"
    assert r.cycles.cancel("x") == "C:x"


def test_cycles_stream_events_proxies_to_stream_cycle_events(monkeypatch) -> None:
    r = _make_resource()
    captured: list = []

    def fake_stream(cycle_id):
        captured.append(cycle_id)
        yield "evt-1"
        yield "evt-2"

    monkeypatch.setattr(r, "stream_cycle_events", fake_stream)
    events = list(r.cycles.stream_events("cy-stream"))
    assert events == ["evt-1", "evt-2"]
    assert captured == ["cy-stream"]


def test_stream_cycle_events_calls_transport_stream() -> None:
    """The flat method must hit ``GET /api/v1/workstreams/cycles/{id}/events``."""
    transport = MagicMock(name="SyncTransport")
    transport.stream.return_value = iter(["a", "b", "c"])
    r = WorkstreamsResource(transport)
    out = list(r.stream_cycle_events("cy-42"))
    assert out == ["a", "b", "c"]
    transport.stream.assert_called_once_with(
        "GET",
        "/api/v1/workstreams/cycles/cy-42/events",
    )
