"""Tests for SDK streaming (SSE) support.

Tests the _parse_sse_lines helper and the SyncTransport.stream / AsyncTransport.stream
methods via httpx ASGI mocking.
"""

from __future__ import annotations

import pytest
from heyarchie._http import SkillStreamChunk, _parse_sse_lines


# ---------------------------------------------------------------------------
# Unit tests for _parse_sse_lines
# ---------------------------------------------------------------------------


def test_parse_single_data_chunk():
    raw = 'data: {"delta": "Hello"}\n\nevent: delta\ndata: {"delta": " world"}\n\n'
    chunks = _parse_sse_lines(raw)
    assert len(chunks) == 2
    assert chunks[0].delta == "Hello"
    assert chunks[1].delta == " world"
    assert chunks[1].event == "delta"


def test_parse_done_event():
    raw = "data: [DONE]\n\n"
    chunks = _parse_sse_lines(raw)
    assert len(chunks) == 1
    assert chunks[0].event == "done"
    assert chunks[0].delta is None


def test_parse_empty_string():
    assert _parse_sse_lines("") == []


def test_parse_preserves_event_name():
    raw = "event: error\ndata: {\"code\": \"rate_limit\"}\n\n"
    chunks = _parse_sse_lines(raw)
    assert chunks[0].event == "error"
    assert chunks[0].data == {"code": "rate_limit"}


def test_skill_stream_chunk_dataclass():
    chunk = SkillStreamChunk(delta="hi", event="delta")
    assert chunk.delta == "hi"
    assert chunk.event == "delta"
    assert chunk.data is None


# ---------------------------------------------------------------------------
# Transport streaming — httpx MockTransport
# ---------------------------------------------------------------------------


def _sse_body(*deltas: str, done: bool = True) -> bytes:
    lines: list[str] = []
    for d in deltas:
        import json
        lines.append(f"data: {json.dumps({'delta': d})}\n\n")
    if done:
        lines.append("data: [DONE]\n\n")
    return "".join(lines).encode()


def test_sync_transport_stream(httpx_mock):
    from heyarchie._http import SyncTransport

    httpx_mock.add_response(
        method="POST",
        url="https://api.heyarchie.ai/api/v1/skills/ask_archie/invoke",
        content=_sse_body("Hello", " world"),
        headers={"content-type": "text/event-stream"},
        status_code=200,
    )

    transport = SyncTransport("sk_test", "https://api.heyarchie.ai")
    chunks = list(transport.stream("POST", "/api/v1/skills/ask_archie/invoke", json={"query": "test"}))
    transport.close()

    text_chunks = [c for c in chunks if c.delta is not None]
    done_chunks = [c for c in chunks if c.event == "done"]
    assert text_chunks[0].delta == "Hello"
    assert text_chunks[1].delta == " world"
    assert len(done_chunks) == 1


@pytest.mark.anyio
async def test_async_transport_stream(httpx_mock):
    from heyarchie._http import AsyncTransport

    httpx_mock.add_response(
        method="POST",
        url="https://api.heyarchie.ai/api/v1/skills/ask_archie/invoke",
        content=_sse_body("Async", " works"),
        headers={"content-type": "text/event-stream"},
        status_code=200,
    )

    transport = AsyncTransport("sk_test", "https://api.heyarchie.ai")
    collected: list[SkillStreamChunk] = []
    async for chunk in transport.stream("POST", "/api/v1/skills/ask_archie/invoke", json={"query": "test"}):
        collected.append(chunk)
    await transport.aclose()

    text_chunks = [c for c in collected if c.delta is not None]
    assert text_chunks[0].delta == "Async"
    assert text_chunks[1].delta == " works"
