"""Credential storage roundtrip — file is chmod 600, env > disk > default precedence."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

import heyarchie.cli.auth as auth_mod
from heyarchie.cli.auth import (
    DEFAULT_API_URL,
    CredentialError,
    Credentials,
    load_credentials,
    save_credentials,
)


def _isolated(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: home))
    monkeypatch.setattr(auth_mod, "CREDENTIALS_PATH", home / ".archie" / "credentials.toml")
    return home


def test_save_then_load_roundtrip(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    home = _isolated(monkeypatch, tmp_path)
    monkeypatch.delenv("ARCHIE_API_KEY", raising=False)
    monkeypatch.delenv("ARCHIE_API_URL", raising=False)

    path = save_credentials("https://api.example.com/", "secret-token", profile="default")
    assert path == home / ".archie" / "credentials.toml"

    creds = load_credentials()
    assert isinstance(creds, Credentials)
    assert creds.api_url == "https://api.example.com"  # trailing slash stripped
    assert creds.api_key == "secret-token"
    assert creds.profile == "default"


def test_credentials_file_is_chmod_600(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    home = _isolated(monkeypatch, tmp_path)
    save_credentials("https://api.example.com", "secret", profile="default")
    file_mode = stat.S_IMODE(os.stat(home / ".archie" / "credentials.toml").st_mode)
    assert file_mode == 0o600


def test_env_overrides_disk(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _isolated(monkeypatch, tmp_path)
    save_credentials("https://disk.example.com", "disk-key", profile="default")
    monkeypatch.setenv("ARCHIE_API_KEY", "env-key")
    monkeypatch.setenv("ARCHIE_API_URL", "https://env.example.com")
    creds = load_credentials()
    assert creds.api_url == "https://env.example.com"
    assert creds.api_key == "env-key"


def test_explicit_override_beats_env(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _isolated(monkeypatch, tmp_path)
    save_credentials("https://disk.example.com", "disk-key", profile="default")
    monkeypatch.setenv("ARCHIE_API_KEY", "env-key")
    creds = load_credentials(api_key_override="explicit-key")
    assert creds.api_key == "explicit-key"


def test_missing_credentials_raises(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _isolated(monkeypatch, tmp_path)
    monkeypatch.delenv("ARCHIE_API_KEY", raising=False)
    with pytest.raises(CredentialError, match="No API key"):
        load_credentials()


def test_named_profile_isolated(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _isolated(monkeypatch, tmp_path)
    monkeypatch.delenv("ARCHIE_API_KEY", raising=False)
    save_credentials("https://default.example.com", "default-key", profile="default")
    save_credentials("https://staging.example.com", "staging-key", profile="staging")
    default = load_credentials(profile="default")
    staging = load_credentials(profile="staging")
    assert default.api_key == "default-key"
    assert staging.api_key == "staging-key"
    assert staging.api_url == "https://staging.example.com"
    # default url applies when missing
    monkeypatch.delenv("ARCHIE_API_URL", raising=False)
    assert default.api_url == "https://default.example.com"
    assert DEFAULT_API_URL  # used when no profile entry
