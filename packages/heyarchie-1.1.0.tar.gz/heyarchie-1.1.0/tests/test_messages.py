"""Tests for the MessagesResource — verifies correct HTTP behaviour."""

from __future__ import annotations

import json

import httpx
import pytest
import respx
from heyarchie.client import Archie, AsyncArchie
from heyarchie.errors import ArchieNotFoundError, ArchiePermissionError
from heyarchie.models import MessageResponse


_BASE = "https://api.heyarchie.ai"

_SAMPLE_RESPONSE = {
    "object": "message",
    "id": "msg_01HX9TEST",
    "conversation_id": "conv_01HX9CONV",
    "role": "assistant",
    "content": "The BAS for Q1 2026 shows a net GST liability of $12,450.",
    "citations": [
        {
            "id": "cite_01",
            "kind": "document",
            "href": "archie://documents/doc_01",
            "label": "BAS Q1 2026.xlsx",
            "excerpt": "Net GST: $12,450",
        }
    ],
    "skill": "ask_archie",
    "model": "archie-ov3",
    "usage": {"input_tokens": 214, "output_tokens": 87},
    "created_at": "2026-04-24T11:45:22.000Z",
    "request_id": "req_01HX9TEST",
}


# ---------------------------------------------------------------------------
# Sync create
# ---------------------------------------------------------------------------


@respx.mock
def test_create_message_posts_to_correct_endpoint():
    """messages.create() POSTs to /v1/messages."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        msg = client.messages.create("What is the BAS for Q1?")

    assert respx.calls.call_count == 1
    assert respx.calls.last.request.method == "POST"
    assert "/v1/messages" in str(respx.calls.last.request.url)


@respx.mock
def test_create_message_payload_contains_query():
    """messages.create() sends the query in the request body."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        client.messages.create("What is the BAS?", client_id="client_test_gwt")

    body = json.loads(respx.calls.last.request.content)
    assert body["query"] == "What is the BAS?"
    assert body["client_id"] == "client_test_gwt"


@respx.mock
def test_create_message_returns_message_response():
    """messages.create() returns a typed MessageResponse."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        msg = client.messages.create("test")

    assert isinstance(msg, MessageResponse)
    assert msg.id == "msg_01HX9TEST"
    assert msg.role == "assistant"
    assert len(msg.citations) == 1
    assert msg.citations[0].kind == "document"


@respx.mock
def test_create_message_body_excludes_none_fields():
    """messages.create() does not send null/None fields in the body."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        client.messages.create("test query")

    body = json.loads(respx.calls.last.request.content)
    # client_id, conversation_id, context should be absent (not None)
    assert "client_id" not in body
    assert "conversation_id" not in body
    assert "context" not in body


@respx.mock
def test_create_message_idempotency_key_sent():
    """Idempotency-Key header is forwarded when provided."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        client.messages.create("test", idempotency_key="my-unique-key-123")

    assert respx.calls.last.request.headers["Idempotency-Key"] == "my-unique-key-123"


@respx.mock
def test_create_message_stream_true_raises():
    """stream=True on sync client raises NotImplementedError."""
    with Archie(api_key="ak_test_abc") as client:
        with pytest.raises(NotImplementedError):
            client.messages.create("test", stream=True)


# ---------------------------------------------------------------------------
# Sync retrieve
# ---------------------------------------------------------------------------


@respx.mock
def test_retrieve_message_gets_correct_path():
    """messages.retrieve() GETs /v1/messages/{id}."""
    respx.get(f"{_BASE}/v1/messages/msg_01HX9TEST").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    with Archie(api_key="ak_test_abc") as client:
        msg = client.messages.retrieve("msg_01HX9TEST")

    assert msg.id == "msg_01HX9TEST"
    assert respx.calls.last.request.method == "GET"


@respx.mock
def test_retrieve_message_404_raises_not_found():
    """messages.retrieve() with unknown ID raises ArchieNotFoundError."""
    respx.get(f"{_BASE}/v1/messages/msg_UNKNOWN").mock(
        return_value=httpx.Response(
            404,
            json={"error": {"type": "not_found", "code": "resource_not_found", "message": "Message not found"}},
        )
    )

    with pytest.raises(ArchieNotFoundError):
        with Archie(api_key="ak_test_abc") as client:
            client.messages.retrieve("msg_UNKNOWN")


# ---------------------------------------------------------------------------
# Permission error
# ---------------------------------------------------------------------------


@respx.mock
def test_create_message_403_raises_permission_error():
    """A 403 response raises ArchiePermissionError."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(
            403,
            json={
                "error": {
                    "type": "permission_error",
                    "code": "missing_permission",
                    "message": "Key missing messages:create permission",
                }
            },
        )
    )

    with pytest.raises(ArchiePermissionError) as exc_info:
        with Archie(api_key="ak_test_abc") as client:
            client.messages.create("test")

    assert exc_info.value.status == 403
    assert exc_info.value.code == "missing_permission"


# ---------------------------------------------------------------------------
# Async create
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_async_create_message_posts_correctly():
    """AsyncArchie.messages.create() POSTs to /v1/messages."""
    respx.post(f"{_BASE}/v1/messages").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    async with AsyncArchie(api_key="ak_test_abc") as client:
        msg = await client.messages.create("Async test query", client_id="client_test_gwt")

    assert isinstance(msg, MessageResponse)
    assert msg.id == "msg_01HX9TEST"
    body = json.loads(respx.calls.last.request.content)
    assert body["query"] == "Async test query"
    assert body["client_id"] == "client_test_gwt"
    assert respx.calls.last.request.headers["Authorization"] == "Bearer ak_test_abc"


@pytest.mark.asyncio
@respx.mock
async def test_async_retrieve_message():
    """AsyncArchie.messages.retrieve() works correctly."""
    respx.get(f"{_BASE}/v1/messages/msg_01HX9TEST").mock(
        return_value=httpx.Response(200, json=_SAMPLE_RESPONSE)
    )

    async with AsyncArchie(api_key="ak_test_abc") as client:
        msg = await client.messages.retrieve("msg_01HX9TEST")

    assert msg.id == "msg_01HX9TEST"
