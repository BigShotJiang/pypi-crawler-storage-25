# heyarchie

Python SDK for the [Archie Connect API](https://developers.heyarchie.ai/docs/api-reference).

## Install

```bash
pip install heyarchie
```

## Quick start

```python
import heyarchie

archie = heyarchie.Archie(api_key="ak_test_...")
message = archie.messages.create(
    "Summarise the BAS for Q1 2026",
    client_id="client_test_growthwise",
)
print(message.content)
```

## Async

```python
import asyncio
import heyarchie

async def main():
    async with heyarchie.AsyncArchie(api_key="ak_test_...") as archie:
        message = await archie.messages.create("Summarise BAS Q1 2026")
        print(message.content)

asyncio.run(main())
```
