"""Drafts resource — thin wrapper around the communications.draft skill."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import DraftCreate, DraftRecipient, DraftResponse


def _unwrap(payload: dict) -> dict:
    """Pull skill output out of the standard envelope."""
    return payload.get("output", payload) if isinstance(payload, dict) else payload



if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class DraftsResource:
    """Synchronous drafts resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(
        self,
        kind: str,
        *,
        client_id: str | None = None,
        recipient_email: str | None = None,
        recipient_name: str | None = None,
        purpose: str | None = None,
        tone: str | None = None,
        context: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> DraftResponse:
        """Create a draft communication.

        Args:
            kind: Type of draft — ``"email"``, ``"slack"``, or ``"document"``.
            client_id: Client to scope the draft to.
            recipient_email: Recipient email address (for email drafts).
            recipient_name: Recipient display name.
            purpose: Plain-language purpose of the communication.
            tone: Desired tone (e.g. ``"professional"``, ``"friendly"``).
            context: Additional skill-specific context.
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            DraftResponse with ``content`` and ``status: pending_approval``.
        """
        recipient = None
        if recipient_email:
            recipient = DraftRecipient(email=recipient_email, name=recipient_name)

        body = DraftCreate(
            kind=kind,  # type: ignore[arg-type]
            client_id=client_id,
            recipient=recipient,
            purpose=purpose,
            tone=tone,
            context=context,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key

        response = self._transport.request(
            "POST",
            "/api/v1/skills/communications.draft/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return DraftResponse.model_validate(_unwrap(response.json()))

    def retrieve(self, draft_id: str) -> DraftResponse:
        """Retrieve a draft by ID. Portal-only today; no bearer endpoint."""
        raise NotImplementedError(
            f"drafts.retrieve({draft_id!r}) is portal-only today. "
            "There is no /api/v1/drafts/{id} endpoint. Use the portal's "
            "draft view, or skills.invoke('communications.draft') for the "
            "write path."
        )


class AsyncDraftsResource:
    """Asynchronous drafts resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        kind: str,
        *,
        client_id: str | None = None,
        recipient_email: str | None = None,
        recipient_name: str | None = None,
        purpose: str | None = None,
        tone: str | None = None,
        context: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> DraftResponse:
        recipient = None
        if recipient_email:
            recipient = DraftRecipient(email=recipient_email, name=recipient_name)

        body = DraftCreate(
            kind=kind,  # type: ignore[arg-type]
            client_id=client_id,
            recipient=recipient,
            purpose=purpose,
            tone=tone,
            context=context,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key

        response = await self._transport.request(
            "POST",
            "/api/v1/skills/communications.draft/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return DraftResponse.model_validate(_unwrap(response.json()))

    async def retrieve(self, draft_id: str) -> DraftResponse:
        raise NotImplementedError(
            f"drafts.retrieve({draft_id!r}) is portal-only today. "
            "There is no /api/v1/drafts/{id} endpoint. Use the portal's "
            "draft view, or skills.invoke('communications.draft') for the "
            "write path."
        )
