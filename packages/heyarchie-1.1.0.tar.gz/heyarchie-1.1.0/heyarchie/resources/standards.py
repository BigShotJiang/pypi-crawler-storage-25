"""Standards resource — thin wrapper around the standards.research skill."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import StandardsComparisonCreate, StandardsComparisonResponse


def _unwrap(payload: dict) -> dict:
    """Pull skill output out of the standard envelope."""
    return payload.get("output", payload) if isinstance(payload, dict) else payload



if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class StandardsResource:
    """Synchronous standards resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def compare(
        self,
        client_id: str,
        standard: str,
        *,
        scope: str | None = None,
        idempotency_key: str | None = None,
    ) -> StandardsComparisonResponse:
        """Run a standards comparison for a client.

        Args:
            client_id: Client whose data is being compared.
            standard: Regulatory standard identifier (e.g. ``"IFRS-15"``).
            scope: Optional scope qualifier (e.g. ``"revenue_recognition_2026Q1"``).
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            StandardsComparisonResponse with ``findings[]`` and citations.
        """
        body = StandardsComparisonCreate(client_id=client_id, standard=standard, scope=scope)
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            "/api/v1/skills/standards.research/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return StandardsComparisonResponse.model_validate(_unwrap(response.json()))


class AsyncStandardsResource:
    """Asynchronous standards resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def compare(
        self,
        client_id: str,
        standard: str,
        *,
        scope: str | None = None,
        idempotency_key: str | None = None,
    ) -> StandardsComparisonResponse:
        body = StandardsComparisonCreate(client_id=client_id, standard=standard, scope=scope)
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            "/api/v1/skills/standards.research/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return StandardsComparisonResponse.model_validate(_unwrap(response.json()))
