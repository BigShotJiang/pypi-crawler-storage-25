"""Documents resource — thin wrapper around the documents.analyse skill."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import DocumentAnalysisCreate, DocumentAnalysisResponse


def _unwrap(payload: dict) -> dict:
    """Pull skill output out of the standard envelope."""
    return payload.get("output", payload) if isinstance(payload, dict) else payload



if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class DocumentsResource:
    """Synchronous documents resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def analyse(
        self,
        document_id: str,
        analysis_type: str,
        *,
        context: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> DocumentAnalysisResponse:
        """Kick off an analysis on an already-uploaded document.

        Args:
            document_id: The document ID (e.g. ``doc_01HXD…``).
            analysis_type: The type of analysis (e.g. ``"bas_filing_review"``).
            context: Optional skill-specific context (e.g. ``{"period": "2026Q1"}``).
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            DocumentAnalysisResponse.
        """
        body = DocumentAnalysisCreate(analysis_type=analysis_type, context=context)
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            "/api/v1/skills/documents.analyse/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return DocumentAnalysisResponse.model_validate(_unwrap(response.json()))

    # British English alias
    analyze = analyse


class AsyncDocumentsResource:
    """Asynchronous documents resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def analyse(
        self,
        document_id: str,
        analysis_type: str,
        *,
        context: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> DocumentAnalysisResponse:
        body = DocumentAnalysisCreate(analysis_type=analysis_type, context=context)
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            "/api/v1/skills/documents.analyse/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return DocumentAnalysisResponse.model_validate(_unwrap(response.json()))

    analyze = analyse
