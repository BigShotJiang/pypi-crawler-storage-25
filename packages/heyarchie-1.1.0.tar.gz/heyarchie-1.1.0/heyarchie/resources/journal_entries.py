"""Journal entries resource — thin wrapper around the journal.record skill."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import JournalEntryCreate, JournalEntryResponse, JournalLine


def _unwrap(payload: dict) -> dict:
    """Pull skill output out of the standard envelope."""
    return payload.get("output", payload) if isinstance(payload, dict) else payload



if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class JournalEntriesResource:
    """Synchronous journal entries resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(
        self,
        client_id: str,
        period: str,
        lines: list[dict[str, Any]],
        *,
        memo: str | None = None,
        approval: str | None = None,
        idempotency_key: str | None = None,
    ) -> JournalEntryResponse:
        """Create a journal entry posting.

        Args:
            client_id: Client to post the entry for.
            period: Accounting period in YYYY-MM format (e.g. ``"2026-03"``).
            lines: List of line dicts with keys ``account``, ``debit_cents``,
                ``credit_cents``, ``description``.
            memo: Human-readable memo for the entry.
            approval: ``"pre_approved"`` bypasses the approval gate (requires
                the ``journal-entries:write-no-approval`` permission).
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            JournalEntryResponse.
        """
        parsed_lines = [JournalLine(**line) for line in lines]
        body = JournalEntryCreate(
            client_id=client_id,
            period=period,
            lines=parsed_lines,
            memo=memo,
            approval=approval,  # type: ignore[arg-type]
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            "/api/v1/skills/journal.record/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return JournalEntryResponse.model_validate(_unwrap(response.json()))


class AsyncJournalEntriesResource:
    """Asynchronous journal entries resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        client_id: str,
        period: str,
        lines: list[dict[str, Any]],
        *,
        memo: str | None = None,
        approval: str | None = None,
        idempotency_key: str | None = None,
    ) -> JournalEntryResponse:
        parsed_lines = [JournalLine(**line) for line in lines]
        body = JournalEntryCreate(
            client_id=client_id,
            period=period,
            lines=parsed_lines,
            memo=memo,
            approval=approval,  # type: ignore[arg-type]
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            "/api/v1/skills/journal.record/invoke",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return JournalEntryResponse.model_validate(_unwrap(response.json()))
