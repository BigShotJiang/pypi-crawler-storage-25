"""Messages resource — thin wrapper around the ``messages.create`` skill.

Pre-Phase-1 this called a phantom ``/v1/messages`` namespace that never
existed on the API (404 every time). Phase 1b of
``docs/connect/ALIGNMENT-PLAN.md`` re-points ``create()`` at the real
``messages.create`` skill (the ``ask_archie`` slug under its friendly
public name) and removes ``retrieve()`` — it was portal-only and there's
no canonical bearer-callable read for a single message yet.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import MessageCreate, MessageResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


_INVOKE_PATH = "/api/v1/skills/messages.create/invoke"


def _unwrap(payload: dict[str, Any]) -> dict[str, Any]:
    """Pull the skill output out of the standard envelope."""
    return payload.get("output", payload)


class MessagesResource:
    """Synchronous messages resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(
        self,
        query: str,
        *,
        client_id: str | None = None,
        conversation_id: str | None = None,
        context: dict[str, Any] | None = None,
        stream: bool = False,
        idempotency_key: str | None = None,
    ) -> MessageResponse:
        """Ask Archie a question. Returns answer + citations.

        Args:
            query: The accounting question, 1–8000 characters.
            client_id: Optional client context to scope the answer to.
            conversation_id: Continue an existing conversation.
            context: Skill-specific runtime variables.
            stream: Reserved — not supported on the sync surface.
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            MessageResponse with the assistant's answer and citations.
        """
        if stream:
            raise NotImplementedError(
                "Synchronous streaming is not supported. "
                "Use AsyncArchie.messages.create(stream=True) instead."
            )
        body = MessageCreate(
            query=query,
            client_id=client_id,
            conversation_id=conversation_id,
            context=context,
            stream=False,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            _INVOKE_PATH,
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return MessageResponse.model_validate(_unwrap(response.json()))

    def retrieve(self, message_id: str) -> MessageResponse:
        """Retrieve a previously created message by id.

        Not yet available on the Connect bearer surface — message
        persistence + read happens via the portal's conversation store.
        Phase 1b stub; will be removed once the canonical bearer-callable
        message-read endpoint exists.
        """
        raise NotImplementedError(
            f"messages.retrieve({message_id!r}) is portal-only today. "
            "There is no /api/v1/messages/{id} endpoint. Use the portal's "
            "conversation view, or open an issue if you need this on the "
            "Connect surface."
        )


class AsyncMessagesResource:
    """Asynchronous messages resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        query: str,
        *,
        client_id: str | None = None,
        conversation_id: str | None = None,
        context: dict[str, Any] | None = None,
        stream: bool = False,
        idempotency_key: str | None = None,
    ) -> MessageResponse:
        if stream:
            raise NotImplementedError(
                "Async streaming via SSE is not yet supported in v1.0.0. "
                "Use client.skills.invoke_stream('messages.create', ...) instead."
            )
        body = MessageCreate(
            query=query,
            client_id=client_id,
            conversation_id=conversation_id,
            context=context,
            stream=False,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            _INVOKE_PATH,
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return MessageResponse.model_validate(_unwrap(response.json()))

    async def retrieve(self, message_id: str) -> MessageResponse:
        raise NotImplementedError(
            f"messages.retrieve({message_id!r}) is portal-only today. "
            "There is no /api/v1/messages/{id} endpoint. Use the portal's "
            "conversation view, or open an issue if you need this on the "
            "Connect surface."
        )
