"""Conversations resource — portal-only today.

Pre-Phase-1 this called a phantom ``/v1/conversations`` namespace that
never existed on the API. There is no bearer-callable conversation API
today; conversation lifecycle lives in the portal session model and the
WSS frontend's session-cookie-protected endpoints.

Phase 1b stubs every method with ``NotImplementedError`` so callers
fail clearly. If you need programmatic conversation access via the
SDK, file an issue — the canonical bearer surface needs to land first
(probably as part of Phase 6 with a new ``conversation.list`` /
``conversation.create`` skill).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


_PORTAL_ONLY_MSG = (
    "conversations.{op}() is portal-only today; no bearer-callable "
    "conversation endpoint exists. Use the portal's chat UI, or open "
    "an issue if you need this on the Connect surface. See "
    "docs/connect/ALIGNMENT-PLAN.md."
)


def _not_implemented(op: str) -> NotImplementedError:
    return NotImplementedError(_PORTAL_ONLY_MSG.format(op=op))


class ConversationsResource:
    """Synchronous conversations resource (Phase 1b stub)."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(self, **_: Any) -> Any:
        raise _not_implemented("create")

    def list(self, **_: Any) -> Any:
        raise _not_implemented("list")

    def retrieve(self, conversation_id: str, **_: Any) -> Any:
        raise _not_implemented("retrieve")

    def update(self, conversation_id: str, **_: Any) -> Any:
        raise _not_implemented("update")


class AsyncConversationsResource:
    """Asynchronous conversations resource (Phase 1b stub)."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(self, **_: Any) -> Any:
        raise _not_implemented("create")

    async def list(self, **_: Any) -> Any:
        raise _not_implemented("list")

    async def retrieve(self, conversation_id: str, **_: Any) -> Any:
        raise _not_implemented("retrieve")

    async def update(self, conversation_id: str, **_: Any) -> Any:
        raise _not_implemented("update")
