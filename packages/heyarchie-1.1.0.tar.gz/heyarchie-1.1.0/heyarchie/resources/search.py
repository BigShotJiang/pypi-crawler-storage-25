"""Search resource — thin wrapper around the search.query skill."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import SearchCreate, SearchResponse


def _unwrap(payload: dict) -> dict:
    """Pull skill output out of the standard envelope."""
    return payload.get("output", payload) if isinstance(payload, dict) else payload



if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class SearchResource:
    """Synchronous search resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def query(
        self,
        q: str,
        *,
        client_id: str | None = None,
        jurisdictions: list[str] | None = None,
        limit: int = 10,
        expand: list[str] | None = None,
    ) -> SearchResponse:
        """Search Archie's knowledge base.

        Args:
            q: The search query string.
            client_id: Unused in v1 but reserved for client-scoped search.
            jurisdictions: List of ISO jurisdiction codes to restrict results (e.g. ``["AU", "UK"]``).
            limit: Maximum results to return (1–100, default 10).
            expand: Related resource expansions (e.g. ``["source"]``).

        Returns:
            SearchResponse with a list of SearchResult objects.
        """
        body = SearchCreate(
            query=q,
            jurisdictions=jurisdictions,
            limit=limit,
            expand=expand,
        )
        response = self._transport.request(
            "POST",
            "/api/v1/skills/search.query/invoke",
            json=body.model_dump(exclude_none=True),
        )
        return SearchResponse.model_validate(_unwrap(response.json()))


class AsyncSearchResource:
    """Asynchronous search resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def query(
        self,
        q: str,
        *,
        client_id: str | None = None,
        jurisdictions: list[str] | None = None,
        limit: int = 10,
        expand: list[str] | None = None,
    ) -> SearchResponse:
        body = SearchCreate(
            query=q,
            jurisdictions=jurisdictions,
            limit=limit,
            expand=expand,
        )
        response = await self._transport.request(
            "POST",
            "/api/v1/skills/search.query/invoke",
            json=body.model_dump(exclude_none=True),
        )
        return SearchResponse.model_validate(_unwrap(response.json()))
