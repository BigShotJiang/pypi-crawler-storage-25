"""API Keys resource — list / create / revoke / flush-cache.

Wraps the backend ``connect_keys_router`` (``/api/v1/connect-keys/*``)
which mirrors the WorkOS Management API. Every call requires either a
session JWT or a ``sk_*`` bearer with admin scope.

Pre-Phase-1 this resource called a phantom ``/v1/keys`` namespace that
never existed on the API — every method returned 404. Phase 1 of
``docs/connect/ALIGNMENT-PLAN.md`` lands the backend router and
realigns these paths.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import KeyCreate, KeyListResponse, KeyResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


_BASE = "/api/v1/connect-keys"


class KeysResource:
    """Synchronous keys resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list(self, *, limit: int = 20, after: str | None = None) -> KeyListResponse:
        """List API keys for the caller's organisation.

        Args:
            limit: Page size (1–100, default 20). Honoured client-side;
                WorkOS' list-keys endpoint paginates server-side.
            after: Cursor for forward pagination (passed through to WorkOS).

        Returns:
            KeyListResponse. Secret values are never returned on list.
        """
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        response = self._transport.request("GET", _BASE, params=params)
        return KeyListResponse.model_validate(response.json())

    def create(
        self,
        name: str,
        permissions: list[str],
        *,
        description: str | None = None,
    ) -> KeyResponse:
        """Create a new API key.

        Args:
            name: Human-readable name for the key.
            permissions: List of permission scopes (e.g.
                ``["messages:create", "search:read"]``).
            description: Optional description.

        Returns:
            KeyResponse — the ``secret`` field is only present on this
            initial response. WorkOS does not return it again.
        """
        body = KeyCreate(name=name, permissions=permissions, description=description)
        response = self._transport.request(
            "POST",
            _BASE,
            json=body.model_dump(exclude_none=True),
        )
        return KeyResponse.model_validate(response.json())

    def revoke(self, key_id: str) -> None:
        """Revoke (delete) an API key.

        Idempotent — re-deleting a non-existent key returns 204, not 404.

        Args:
            key_id: The WorkOS API key id (``api_key_*``) to revoke.
        """
        self._transport.request("DELETE", f"{_BASE}/{key_id}")

    def flush_cache(self, key_id: str) -> None:
        """Flush the in-process WorkOS validator cache for a key.

        Use after rotating, revoking, or changing permissions on a key.
        Without this, callers using a stale key value may continue to
        succeed for up to 5 minutes due to in-process caching.

        Args:
            key_id: The WorkOS API key id (``api_key_*``) whose cache
                entries to drop.
        """
        self._transport.request("POST", f"{_BASE}/{key_id}/flush-cache")


class AsyncKeysResource:
    """Asynchronous keys resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(self, *, limit: int = 20, after: str | None = None) -> KeyListResponse:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        response = await self._transport.request("GET", _BASE, params=params)
        return KeyListResponse.model_validate(response.json())

    async def create(
        self,
        name: str,
        permissions: list[str],
        *,
        description: str | None = None,
    ) -> KeyResponse:
        body = KeyCreate(name=name, permissions=permissions, description=description)
        response = await self._transport.request(
            "POST",
            _BASE,
            json=body.model_dump(exclude_none=True),
        )
        return KeyResponse.model_validate(response.json())

    async def revoke(self, key_id: str) -> None:
        await self._transport.request("DELETE", f"{_BASE}/{key_id}")

    async def flush_cache(self, key_id: str) -> None:
        await self._transport.request("POST", f"{_BASE}/{key_id}/flush-cache")
