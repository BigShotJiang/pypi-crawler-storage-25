"""Skills resource — invoke and framework adapters.

Usage::

    archie = heyarchie.Archie(api_key="sk_...")

    # Discover skills by goal (recommended first step for agents)
    ranked = archie.skills.discover(goal="prepare Q1 financial statements")
    best_slug = ranked["ranked"][0]["name"]

    # List all skills
    skills = archie.skills.list(scope="tax:read")

    # Get framework tools in one call
    tools = archie.skills.as_langgraph_tools()        # LangGraph / LangChain
    tools = archie.skills.as_openai_tools()           # OpenAI Agents SDK

    # Invoke a specific skill
    result = archie.skills.invoke("advise_tax", query="BAS for Q1 2026", client_id="c_abc")
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from .._http import AsyncTransport, SkillStreamChunk, SyncTransport


class SkillsResource:
    """Synchronous skills resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list(
        self,
        *,
        scope: str | list[str] | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """List available skills from the registry.

        Args:
            scope: Optional scope filter (e.g. ``"tax:read"``).
            limit: Max number of skills to return.

        Returns:
            List of skill dicts with ``name``, ``slug``, ``description``, etc.
        """
        params: dict[str, Any] = {"limit": limit}
        resp = self._transport.request("GET", "/api/v1/skills", params=params)
        data: list[dict[str, Any]] = resp.json().get("data", [])

        if scope:
            scopes = [scope] if isinstance(scope, str) else scope
            filtered = []
            for s in data:
                perm = s.get("permission", "")
                perm_prefix = perm.split(":")[0] if ":" in perm else perm
                if any(
                    sc.startswith(perm_prefix) or perm_prefix.startswith(sc.split(":")[0])
                    for sc in scopes
                ):
                    filtered.append(s)
            return filtered

        return data

    def invoke(
        self,
        slug: str,
        *,
        query: str | None = None,
        client_id: str | None = None,
        **inputs: Any,
    ) -> dict[str, Any]:
        """Invoke a skill by slug.

        Args:
            slug: The skill slug (e.g. ``"advise_tax"``).
            query: The primary question or instruction.
            client_id: Client context.
            **inputs: Additional skill-specific inputs.

        Returns:
            The skill response as a dict.
        """
        body: dict[str, Any] = {**inputs}
        if query:
            body["query"] = query
        if client_id:
            body["client_id"] = client_id

        resp = self._transport.request("POST", f"/api/v1/skills/{slug}/invoke", json=body)
        return resp.json()  # type: ignore[no-any-return]

    def invoke_stream(
        self,
        slug: str,
        *,
        query: str | None = None,
        client_id: str | None = None,
        **inputs: Any,
    ) -> Iterator[SkillStreamChunk]:
        """Invoke a skill and stream the response as SSE chunks.

        Yields :class:`~heyarchie._http.SkillStreamChunk` objects.
        Each chunk has a ``delta`` string (or ``None`` for the terminal
        ``[DONE]`` event).

        Example::

            for chunk in archie.skills.invoke_stream(
                "ask_archie",
                query="Walk me through ASC 842 lease accounting.",
            ):
                if chunk.delta:
                    print(chunk.delta, end="", flush=True)
        """
        body: dict[str, Any] = {**inputs}
        if query:
            body["query"] = query
        if client_id:
            body["client_id"] = client_id
        yield from self._transport.stream("POST", f"/api/v1/skills/{slug}/invoke", json=body)

    def discover(
        self,
        *,
        goal: str | None = None,
        cluster: str | None = None,
        limit: int = 5,
    ) -> dict[str, Any]:
        """Discover skills matching a natural-language goal.

        Call this before picking a skill so your agent can survey the catalogue
        without hard-coding slug names that may change.

        Args:
            goal: Natural-language description of what you want to accomplish.
            cluster: Optional routing cluster filter (e.g. ``"TAX"``).
            limit: Max number of ranked results (1–20).

        Returns:
            Dict with ``goal``, ``cluster``, and ``ranked`` list of skill dicts.
            Each ranked entry includes ``name``, ``score``, ``description``, and
            ``endpoint``.

        Example::

            ranked = archie.skills.discover(
                goal="prepare Q1 financial statements", limit=3
            )
            best = ranked["ranked"][0]
            result = archie.skills.invoke(best["name"], period="2026-Q1")
        """
        if goal is None and cluster is None:
            raise ValueError("At least one of 'goal' or 'cluster' is required")
        params: dict[str, Any] = {"limit": limit}
        if goal:
            params["goal"] = goal
        if cluster:
            params["cluster"] = cluster
        resp = self._transport.request("GET", "/api/v1/skills/discover", params=params)
        return resp.json()  # type: ignore[no-any-return]

    def as_langgraph_tools(
        self,
        *,
        scope: str | list[str] | None = None,
        client_id: str | None = None,
    ) -> list[Any]:
        """Return LangGraph/LangChain tools for all skills in the registry.

        Requires ``langchain-core`` and ``langgraph`` to be installed.

        Args:
            scope: Optional scope filter.
            client_id: Default client context for tool calls.

        Returns:
            List of ``StructuredTool`` instances.

        Example::

            archie = heyarchie.Archie(api_key="sk_...")
            tools = archie.skills.as_langgraph_tools(scope="tax:read")
            model = ChatAnthropic(...).bind_tools(tools)
        """
        from ..adapters.langgraph import as_langgraph_tools

        return as_langgraph_tools(
            self._transport._api_key,  # type: ignore[attr-defined]
            base_url=self._transport._base_url,  # type: ignore[attr-defined]
            scope=scope,
            client_id=client_id,
        )

    def as_openai_tools(
        self,
        *,
        scope: str | list[str] | None = None,
        client_id: str | None = None,
    ) -> list[Any]:
        """Return OpenAI Agents SDK tools for all skills in the registry.

        Requires ``openai-agents`` to be installed.

        Args:
            scope: Optional scope filter.
            client_id: Default client context for tool calls.

        Returns:
            List of ``FunctionTool`` instances.

        Example::

            archie = heyarchie.Archie(api_key="sk_...")
            tools = archie.skills.as_openai_tools(scope="tax:read")
            agent = Agent(name="Tax Advisor", tools=tools)
        """
        from ..adapters.openai_agents import as_openai_tools

        return as_openai_tools(
            self._transport._api_key,  # type: ignore[attr-defined]
            base_url=self._transport._base_url,  # type: ignore[attr-defined]
            scope=scope,
            client_id=client_id,
        )


class AsyncSkillsResource:
    """Asynchronous skills resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(
        self,
        *,
        scope: str | list[str] | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """List available skills. See :class:`SkillsResource.list`."""
        params: dict[str, Any] = {"limit": limit}
        resp = await self._transport.request("GET", "/api/v1/skills", params=params)
        data: list[dict[str, Any]] = resp.json().get("data", [])

        if scope:
            scopes = [scope] if isinstance(scope, str) else scope
            filtered = []
            for s in data:
                perm = s.get("permission", "")
                perm_prefix = perm.split(":")[0] if ":" in perm else perm
                if any(
                    sc.startswith(perm_prefix) or perm_prefix.startswith(sc.split(":")[0])
                    for sc in scopes
                ):
                    filtered.append(s)
            return filtered

        return data

    async def invoke(
        self,
        slug: str,
        *,
        query: str | None = None,
        client_id: str | None = None,
        **inputs: Any,
    ) -> dict[str, Any]:
        """Invoke a skill by slug (async). See :class:`SkillsResource.invoke`."""
        body: dict[str, Any] = {**inputs}
        if query:
            body["query"] = query
        if client_id:
            body["client_id"] = client_id

        resp = await self._transport.request("POST", f"/api/v1/skills/{slug}/invoke", json=body)
        return resp.json()  # type: ignore[no-any-return]

    async def invoke_stream(
        self,
        slug: str,
        *,
        query: str | None = None,
        client_id: str | None = None,
        **inputs: Any,
    ) -> AsyncIterator[SkillStreamChunk]:
        """Invoke a skill and stream the response as SSE chunks (async).

        Yields :class:`~heyarchie._http.SkillStreamChunk` objects.

        Example::

            async with AsyncArchie() as archie:
                async for chunk in archie.skills.invoke_stream(
                    "ask_archie",
                    query="Walk me through ASC 842 lease accounting.",
                ):
                    if chunk.delta:
                        print(chunk.delta, end="", flush=True)
        """
        body: dict[str, Any] = {**inputs}
        if query:
            body["query"] = query
        if client_id:
            body["client_id"] = client_id
        async for chunk in self._transport.stream("POST", f"/api/v1/skills/{slug}/invoke", json=body):
            yield chunk

    async def discover(
        self,
        *,
        goal: str | None = None,
        cluster: str | None = None,
        limit: int = 5,
    ) -> dict[str, Any]:
        """Discover skills matching a natural-language goal (async).

        See :meth:`SkillsResource.discover` for full docs.
        """
        if goal is None and cluster is None:
            raise ValueError("At least one of 'goal' or 'cluster' is required")
        params: dict[str, Any] = {"limit": limit}
        if goal:
            params["goal"] = goal
        if cluster:
            params["cluster"] = cluster
        resp = await self._transport.request("GET", "/api/v1/skills/discover", params=params)
        return resp.json()  # type: ignore[no-any-return]

    async def as_openai_tools(
        self,
        *,
        scope: str | list[str] | None = None,
        client_id: str | None = None,
    ) -> list[Any]:
        """Return OpenAI Agents SDK tools for all skills in the registry (async).

        Requires ``openai-agents`` to be installed.

        Example::

            archie = AsyncArchie(api_key="sk_...")
            tools = await archie.skills.as_openai_tools(scope="tax:read")
            agent = Agent(name="Tax Advisor", tools=tools)
        """
        from ..adapters._base import fetch_skills_async
        from ..adapters.openai_agents import _make_function_tool

        skills = await fetch_skills_async(
            self._transport._api_key,  # type: ignore[attr-defined]
            base_url=self._transport._base_url,  # type: ignore[attr-defined]
            scope=scope,
        )
        api_key = self._transport._api_key  # type: ignore[attr-defined]
        base_url = self._transport._base_url  # type: ignore[attr-defined]
        return [_make_function_tool(s, api_key, base_url, client_id) for s in skills]

    async def as_langgraph_tools(
        self,
        *,
        scope: str | list[str] | None = None,
        client_id: str | None = None,
    ) -> list[Any]:
        """Return LangGraph tools (fetches skill list async)."""
        from ..adapters._base import fetch_skills_async
        from ..adapters.langgraph import _make_tool

        skills = await fetch_skills_async(
            self._transport._api_key,  # type: ignore[attr-defined]
            base_url=self._transport._base_url,  # type: ignore[attr-defined]
            scope=scope,
        )
        api_key = self._transport._api_key  # type: ignore[attr-defined]
        base_url = self._transport._base_url  # type: ignore[attr-defined]
        return [_make_tool(s, api_key, base_url, client_id) for s in skills]
