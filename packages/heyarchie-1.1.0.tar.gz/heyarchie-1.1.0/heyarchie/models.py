"""Pydantic models for all Archie Connect API request and response shapes.

Field names match the API's snake_case conventions. All timestamps are ISO-8601 UTC.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared primitives
# ---------------------------------------------------------------------------


class Citation(BaseModel):
    id: str
    kind: str
    href: str
    label: str
    excerpt: str | None = None


class Usage(BaseModel):
    input_tokens: int
    output_tokens: int


class ErrorDetail(BaseModel):
    type: str
    code: str
    message: str
    param: str | None = None
    doc_url: str | None = None
    request_id: str | None = None


class ErrorEnvelope(BaseModel):
    error: ErrorDetail


class ListEnvelope(BaseModel):
    object: Literal["list"] = "list"
    data: list[Any]
    has_more: bool = False
    next_cursor: str | None = None
    previous_cursor: str | None = None


# ---------------------------------------------------------------------------
# Messages  (§4.1)
# ---------------------------------------------------------------------------


class MessageCreate(BaseModel):
    query: str = Field(..., min_length=1, max_length=8000)
    client_id: str | None = None
    conversation_id: str | None = None
    context: dict[str, Any] | None = None
    stream: bool = False


class MessageResponse(BaseModel):
    """Response from ``messages.create`` — the ``ask_archie`` skill output.

    The skill returns an envelope ``{output: {answer, citations, ...}}``
    and the SDK's ``_unwrap`` extracts the inner object. The model below
    mirrors that inner shape directly; fields like ``id`` /
    ``conversation_id`` / ``created_at`` are not present in the skill
    output (the skill is stateless — message persistence is portal-only),
    so they're all optional.
    """

    model_config = {"extra": "allow"}

    answer: str = ""
    content: str = ""  # back-compat alias for ``answer`` (used by older SDK consumers)
    citations: list[Citation] = []
    confidence: float = 0.0
    model_used: str = ""
    stub_fields: list[str] = []
    warnings: list[str] = []

    # Optional fields the skill doesn't populate today but the model
    # historically claimed — left optional so callers that filter on
    # them don't break.
    object: Literal["message"] = "message"
    id: str | None = None
    conversation_id: str | None = None
    role: str | None = None
    skill: str | None = None
    model: str | None = None
    usage: Usage | None = None
    created_at: str | None = None
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Search  (§4.3)
# ---------------------------------------------------------------------------


class SearchCreate(BaseModel):
    query: str = Field(..., min_length=1)
    jurisdictions: list[str] | None = None
    limit: int = Field(default=10, ge=1, le=100)
    expand: list[str] | None = None


class SearchResult(BaseModel):
    object: Literal["search_result"] = "search_result"
    id: str
    score: float
    title: str
    excerpt: str
    source: dict[str, Any] | None = None


class SearchResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[SearchResult]
    has_more: bool = False
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Conversations  (§4.4)
# ---------------------------------------------------------------------------


class ConversationUpdate(BaseModel):
    title: str | None = None
    status: Literal["active", "archived"] | None = None
    metadata: dict[str, Any] | None = None


class ConversationResponse(BaseModel):
    object: Literal["conversation"] = "conversation"
    id: str
    title: str | None = None
    status: str
    client_id: str | None = None
    created_at: str
    updated_at: str | None = None
    metadata: dict[str, Any] | None = None
    request_id: str | None = None


class ConversationListResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[ConversationResponse]
    has_more: bool = False
    next_cursor: str | None = None
    previous_cursor: str | None = None


class ChatMessage(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ConversationTurnRequest(BaseModel):
    messages: list[ChatMessage] | None = None
    message: str | None = None
    conversation_id: str | None = None
    client_id: str | None = None
    locale: str = "en-AU"
    jurisdiction: str = "AU"


class ConversationTurnMessage(BaseModel):
    role: Literal["assistant"] = "assistant"
    content: str
    citations: list[Citation] | None = None


class ConversationTurnResponse(BaseModel):
    object: Literal["conversation.turn"] = "conversation.turn"
    conversation_id: str
    skill: str
    correlation_id: str | None = None
    message: ConversationTurnMessage


# ---------------------------------------------------------------------------
# Drafts  (§4.5)
# ---------------------------------------------------------------------------


class DraftRecipient(BaseModel):
    email: str
    name: str | None = None


class DraftCreate(BaseModel):
    kind: Literal["email", "slack", "document"]
    client_id: str | None = None
    recipient: DraftRecipient | None = None
    purpose: str | None = None
    tone: str | None = None
    context: dict[str, Any] | None = None


class DraftResponse(BaseModel):
    object: Literal["draft"] = "draft"
    id: str
    kind: str
    content: str
    citations: list[Citation] = []
    status: str
    created_at: str
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Workstreams  (§4.6)
# ---------------------------------------------------------------------------


class WorkstreamResponse(BaseModel):
    object: Literal["workstream"] = "workstream"
    id: str
    name: str
    description: str | None = None
    client_id: str | None = None
    created_at: str


class WorkstreamListResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[WorkstreamResponse]
    has_more: bool = False
    next_cursor: str | None = None


class WorkstreamRunCreate(BaseModel):
    client_id: str
    period: str | None = None
    parameters: dict[str, Any] | None = None


class WorkstreamRunResponse(BaseModel):
    object: Literal["workstream_run"] = "workstream_run"
    id: str
    workstream_id: str
    status: str
    started_at: str | None = None
    completed_at: str | None = None
    needs_guidance_url: str | None = None
    artifacts_url: str | None = None
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Journal entries  (§4.7)
# ---------------------------------------------------------------------------


class JournalLine(BaseModel):
    account: str
    debit_cents: int = 0
    credit_cents: int = 0
    description: str | None = None


class JournalEntryCreate(BaseModel):
    client_id: str
    period: str
    lines: list[JournalLine]
    memo: str | None = None
    approval: Literal["pre_approved", "requires_approval"] | None = None


class JournalEntryResponse(BaseModel):
    object: Literal["journal_entry"] = "journal_entry"
    id: str
    client_id: str
    period: str
    status: str
    lines: list[JournalLine]
    memo: str | None = None
    created_at: str
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Standards comparisons  (§4.8)
# ---------------------------------------------------------------------------


class StandardsComparisonCreate(BaseModel):
    client_id: str
    standard: str
    scope: str | None = None


class Finding(BaseModel):
    id: str
    description: str
    citations: list[Citation] = []


class StandardsComparisonResponse(BaseModel):
    object: Literal["standards_comparison"] = "standards_comparison"
    id: str
    client_id: str
    standard: str
    findings: list[Finding] = []
    created_at: str
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Document analyses  (§4.9)
# ---------------------------------------------------------------------------


class DocumentAnalysisCreate(BaseModel):
    analysis_type: str
    context: dict[str, Any] | None = None


class DocumentAnalysisResponse(BaseModel):
    object: Literal["document_analysis"] = "document_analysis"
    id: str
    document_id: str
    analysis_type: str
    status: str
    findings: list[Finding] = []
    created_at: str
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Report exports  (§4.10)
# ---------------------------------------------------------------------------


class ReportExportCreate(BaseModel):
    format: Literal["pdf", "csv", "xlsx", "docx"] = "pdf"
    include_citations: bool = True


class ReportExportResponse(BaseModel):
    object: Literal["report_export"] = "report_export"
    id: str
    format: str
    status: str
    download_url: str | None = None
    expires_at: str | None = None
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Metrics  (§4.11)
# ---------------------------------------------------------------------------


class MetricsResponse(BaseModel):
    object: Literal["metrics"] = "metrics"
    data: list[dict[str, Any]]
    has_more: bool = False
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Audit log  (§4.11)
# ---------------------------------------------------------------------------


class AuditLogEntry(BaseModel):
    object: Literal["audit_log_entry"] = "audit_log_entry"
    id: str
    request_id: str
    action: str
    actor_id: str | None = None
    resource_type: str | None = None
    resource_id: str | None = None
    created_at: str


class AuditLogResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[AuditLogEntry]
    has_more: bool = False
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# Access  (§4.12)
# ---------------------------------------------------------------------------


class AccessUpdate(BaseModel):
    principal_id: str
    relation: str
    grant: bool


class AccessResponse(BaseModel):
    object: Literal["access"] = "access"
    subject: str
    principal_id: str
    relation: str
    granted: bool
    updated_at: str
    request_id: str | None = None


# ---------------------------------------------------------------------------
# Webhooks  (§4.13)
# ---------------------------------------------------------------------------


class WebhookCreate(BaseModel):
    url: str
    events: list[str]
    enabled: bool = True
    description: str | None = None


class WebhookUpdate(BaseModel):
    url: str | None = None
    events: list[str] | None = None
    enabled: bool | None = None
    description: str | None = None


class WebhookResponse(BaseModel):
    object: Literal["webhook"] = "webhook"
    id: str
    url: str
    events: list[str]
    enabled: bool
    description: str | None = None
    created_at: str
    updated_at: str | None = None


class WebhookListResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[WebhookResponse]
    has_more: bool = False
    next_cursor: str | None = None


# ---------------------------------------------------------------------------
# API Keys  (§2 op 20)
# ---------------------------------------------------------------------------


class KeyCreate(BaseModel):
    name: str
    permissions: list[str]
    description: str | None = None


class KeyResponse(BaseModel):
    object: Literal["api_key"] = "api_key"
    id: str
    name: str
    permissions: list[str]
    description: str | None = None
    created_at: str
    last_used_at: str | None = None
    # Only present on create — never returned again
    secret: str | None = None


class KeyListResponse(BaseModel):
    object: Literal["list"] = "list"
    data: list[KeyResponse]
    has_more: bool = False
    next_cursor: str | None = None
