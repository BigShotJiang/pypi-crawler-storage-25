"""Framework adapters — one-line install for LangGraph, OpenAI Agents SDK, LangChain.

Usage::

    # LangGraph
    from heyarchie.adapters.langgraph import as_langgraph_tools
    tools = as_langgraph_tools(api_key="sk_...", scope="tax:read")

    # OpenAI Agents SDK
    from heyarchie.adapters.openai_agents import as_openai_tools
    tools = as_openai_tools(api_key="sk_...", scope="tax:read")

    # LangChain
    from heyarchie.adapters.langchain import as_langchain_tools
    tools = as_langchain_tools(api_key="sk_...", scope="tax:read")

Each adapter fetches the live skill registry (GET /v1/skills) and wraps every
skill as a typed tool the framework understands. Scope filtering is supported:
only skills whose ``permission`` prefix matches at least one of the caller's
granted scopes are returned.
"""

from ._base import SkillEntry, fetch_skills


__all__ = ["SkillEntry", "fetch_skills"]
