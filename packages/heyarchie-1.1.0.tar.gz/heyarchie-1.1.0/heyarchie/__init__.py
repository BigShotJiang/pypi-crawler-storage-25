"""Archie Python SDK + CLI.

Quick start::

    import heyarchie

    archie = heyarchie.Archie(api_key="ak_test_...")
    message = archie.messages.create(
        "What is the BAS for Q1 2026?",
        client_id="client_test_growthwise",
    )
    print(message.content)

Async::

    archie = heyarchie.AsyncArchie(api_key="ak_test_...")
    message = await archie.messages.create("Summarise BAS Q1 2026")

CLI::

    archie skills list
    archie skills invoke ask_archie --input '{"query": "..."}'
    archie workstreams list
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version


def _resolve_version() -> str:
    try:
        return _pkg_version("heyarchie")
    except PackageNotFoundError:
        return "0.0.0+dev"


from ._http import SkillStreamChunk
from .client import Archie, AsyncArchie
from .errors import (
    ArchieAPIError,
    ArchieAuthError,
    ArchieError,
    ArchieIdempotencyError,
    ArchieNotFoundError,
    ArchiePermissionError,
    ArchieRateLimitError,
)
from .models import (
    AccessResponse,
    AccessUpdate,
    AuditLogEntry,
    AuditLogResponse,
    Citation,
    ConversationListResponse,
    ConversationResponse,
    ConversationUpdate,
    DocumentAnalysisCreate,
    DocumentAnalysisResponse,
    DraftCreate,
    DraftRecipient,
    DraftResponse,
    ErrorDetail,
    ErrorEnvelope,
    Finding,
    JournalEntryCreate,
    JournalEntryResponse,
    JournalLine,
    KeyCreate,
    KeyListResponse,
    KeyResponse,
    MessageCreate,
    MessageResponse,
    MetricsResponse,
    ReportExportCreate,
    ReportExportResponse,
    SearchCreate,
    SearchResponse,
    SearchResult,
    StandardsComparisonCreate,
    StandardsComparisonResponse,
    Usage,
    WebhookCreate,
    WebhookListResponse,
    WebhookResponse,
    WebhookUpdate,
    WorkstreamListResponse,
    WorkstreamResponse,
    WorkstreamRunCreate,
    WorkstreamRunResponse,
)
from .resources import (
    AsyncConversationsResource,
    AsyncDocumentsResource,
    AsyncDraftsResource,
    AsyncJournalEntriesResource,
    AsyncKeysResource,
    AsyncMessagesResource,
    AsyncReportsResource,
    AsyncSearchResource,
    AsyncSkillsResource,
    AsyncStandardsResource,
    AsyncWorkstreamsResource,
    ConversationsResource,
    DocumentsResource,
    DraftsResource,
    JournalEntriesResource,
    KeysResource,
    MessagesResource,
    ReportsResource,
    SearchResource,
    SkillsResource,
    StandardsResource,
    WorkstreamsResource,
)


__version__ = _resolve_version()

__all__ = [
    # Clients
    "Archie",
    "AsyncArchie",
    # Streaming
    "SkillStreamChunk",
    # Errors
    "ArchieError",
    "ArchieAuthError",
    "ArchiePermissionError",
    "ArchieNotFoundError",
    "ArchieRateLimitError",
    "ArchieIdempotencyError",
    "ArchieAPIError",
    # Models
    "Citation",
    "Usage",
    "ErrorDetail",
    "ErrorEnvelope",
    "MessageCreate",
    "MessageResponse",
    "SearchCreate",
    "SearchResponse",
    "SearchResult",
    "ConversationUpdate",
    "ConversationResponse",
    "ConversationListResponse",
    "DraftCreate",
    "DraftRecipient",
    "DraftResponse",
    "WorkstreamResponse",
    "WorkstreamListResponse",
    "WorkstreamRunCreate",
    "WorkstreamRunResponse",
    "JournalLine",
    "JournalEntryCreate",
    "JournalEntryResponse",
    "Finding",
    "StandardsComparisonCreate",
    "StandardsComparisonResponse",
    "DocumentAnalysisCreate",
    "DocumentAnalysisResponse",
    "ReportExportCreate",
    "ReportExportResponse",
    "MetricsResponse",
    "AuditLogEntry",
    "AuditLogResponse",
    "AccessUpdate",
    "AccessResponse",
    "WebhookCreate",
    "WebhookUpdate",
    "WebhookResponse",
    "WebhookListResponse",
    "KeyCreate",
    "KeyResponse",
    "KeyListResponse",
    # Resources
    "MessagesResource",
    "AsyncMessagesResource",
    "SearchResource",
    "AsyncSearchResource",
    "ConversationsResource",
    "AsyncConversationsResource",
    "DraftsResource",
    "AsyncDraftsResource",
    "WorkstreamsResource",
    "AsyncWorkstreamsResource",
    "JournalEntriesResource",
    "AsyncJournalEntriesResource",
    "StandardsResource",
    "AsyncStandardsResource",
    "DocumentsResource",
    "AsyncDocumentsResource",
    "ReportsResource",
    "AsyncReportsResource",
    "KeysResource",
    "AsyncKeysResource",
    "SkillsResource",
    "AsyncSkillsResource",
]
