"""Archie CLI — `archie` console script.

Surfaces the Archie platform as terminal commands. Read-friendly when
attached to a TTY (rich-rendered tables, colors); machine-friendly when
piped (`--json`).

Auth is bearer-only. Accepted token formats:

- Archie session JWT (HS256) — issued by ``/api/v1/auth/callback``
- Archie OAuth JWT (HS256) — issued by our own ``/oauth/token`` AS
- WorkOS user-management JWT (RS256)
- **WorkOS API key (``sk_*``)** — issued by the developers portal at
  https://developers.heyarchie.ai/dashboard/keys

Today only ``POST /api/v1/skills/{slug}/invoke`` accepts ``sk_*`` keys
end-to-end. The remaining CLI subcommands (``workstreams``, future
``conversations``, etc.) currently 401 with ``sk_*`` and 200 with a
session JWT. ``docs/connect/ALIGNMENT-PLAN.md`` Phase 2 closes that
gap — after which every CLI subcommand works with a bearer ``sk_*``.
"""

from heyarchie import __version__


__all__ = ["__version__"]
