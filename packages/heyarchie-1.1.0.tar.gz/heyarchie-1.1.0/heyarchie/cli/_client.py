"""HTTP client wrapper around the Archie Connect REST surface.

Handles bearer auth, response envelope unwrapping, and SSE streaming
for cycle event tails. Async — use via ``asyncio.run`` from each click
command (the click group is sync; commands hop into asyncio).
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Any

import httpx

from heyarchie.cli.auth import Credentials


class ArchieAPIError(Exception):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status_code: int, body: dict[str, Any] | str):
        self.status_code = status_code
        self.body = body
        # Pull out the canonical error envelope shape if present.
        message = ""
        if isinstance(body, dict):
            err = body.get("error") or {}
            if isinstance(err, dict):
                message = err.get("message") or err.get("code") or ""
            else:
                message = str(err)
        if not message:
            message = str(body)[:200]
        super().__init__(f"HTTP {status_code}: {message}")


class ArchieClient:
    """Thin async wrapper over httpx.AsyncClient.

    One client per command invocation; opens + closes around the call.
    """

    def __init__(self, creds: Credentials, *, timeout: float = 30.0):
        self._creds = creds
        self._timeout = timeout

    async def __aenter__(self) -> ArchieClient:
        self._client = httpx.AsyncClient(
            base_url=self._creds.api_url,
            timeout=self._timeout,
            headers={
                "Authorization": f"Bearer {self._creds.api_key}",
                "User-Agent": f"heyarchie-cli/0.1.0 ({httpx.__version__})",
                "Accept": "application/json",
            },
        )
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self._client.aclose()

    async def invoke_skill(self, slug: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST /api/v1/skills/{slug}/invoke and return the parsed JSON body."""
        resp = await self._client.post(
            f"/api/v1/skills/{slug}/invoke",
            json=payload,
        )
        return self._unwrap(resp)

    async def workstreams_list(
        self,
        *,
        scope: str | None = None,
        status: str | None = None,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"limit": limit}
        if scope:
            payload["scope"] = scope
        if status:
            payload["status"] = status
        if cursor:
            payload["cursor"] = cursor
        return await self.invoke_skill("workstream.list", payload)

    async def workstreams_describe(self, workstream_id: str) -> dict[str, Any]:
        return await self.invoke_skill("workstream.describe", {"workstream_id": workstream_id})

    async def workstreams_run(
        self,
        workstream_id: str,
        *,
        client_id: str | None = None,
        period: str | None = None,
        runtime_vars: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workstream_id": workstream_id}
        if client_id:
            payload["client_id"] = client_id
        if period:
            payload["period"] = period
        if runtime_vars:
            payload["runtime_vars"] = runtime_vars
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key
        return await self.invoke_skill("workstream.run", payload)

    async def workstreams_status(self, cycle_id: str) -> dict[str, Any]:
        return await self.invoke_skill("workstream.status", {"cycle_id": cycle_id})

    async def workstreams_cancel(
        self,
        cycle_id: str,
        *,
        reason: str | None = None,
        idempotency_key: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"cycle_id": cycle_id}
        if reason:
            payload["reason"] = reason
        if idempotency_key:
            payload["idempotency_key"] = idempotency_key
        return await self.invoke_skill("workstream.cancel", payload)

    async def workstreams_events(self, cycle_id: str) -> AsyncIterator[dict[str, Any]]:
        """Stream SSE events from /api/v1/workstreams/cycles/{cycle_id}/events.

        Yields one parsed JSON dict per SSE ``data:`` line. Filters out
        comments and empty keepalives. Re-raises on transport failure.
        """
        url = f"/api/v1/workstreams/cycles/{cycle_id}/events"
        async with self._client.stream(
            "GET",
            url,
            headers={"Accept": "text/event-stream"},
            timeout=httpx.Timeout(60.0, read=None),
        ) as resp:
            if resp.status_code >= 400:
                body = await resp.aread()
                try:
                    parsed: dict[str, Any] | str = json.loads(body)
                except Exception:
                    parsed = body.decode("utf-8", errors="replace")
                raise ArchieAPIError(resp.status_code, parsed)
            buffer: list[str] = []
            async for line in resp.aiter_lines():
                if line == "" and buffer:
                    payload = "\n".join(buffer)
                    buffer = []
                    if not payload.startswith("data:"):
                        continue
                    data = payload[len("data:") :].strip()
                    if not data:
                        continue
                    try:
                        yield json.loads(data)
                    except json.JSONDecodeError:
                        yield {"raw": data}
                elif line.startswith(":"):
                    # SSE comment / keepalive
                    continue
                else:
                    buffer.append(line)

    @staticmethod
    def _unwrap(resp: httpx.Response) -> dict[str, Any]:
        try:
            body = resp.json()
        except Exception:
            body = resp.text
        if resp.status_code >= 400:
            raise ArchieAPIError(resp.status_code, body)
        # Connect skill responses wrap the typed output under `output`.
        if isinstance(body, dict) and "output" in body and isinstance(body["output"], dict):
            return body["output"]
        return body if isinstance(body, dict) else {"_raw": body}
