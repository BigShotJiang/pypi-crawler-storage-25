"""``archie`` console-script entry point."""

from __future__ import annotations

import click

from heyarchie.cli import __version__
from heyarchie.cli.cmds.login import login_cmd
from heyarchie.cli.cmds.skills import skills_group
from heyarchie.cli.cmds.workstreams import workstreams_group


@click.group(
    help=(
        "Archie Connect CLI.\n\n"
        "Read-friendly when attached to a TTY; pipe-friendly with --json.\n"
        "Auth: bearer token via --api-key, env ARCHIE_API_KEY, or `archie login`."
    )
)
@click.version_option(__version__, prog_name="archie")
def cli() -> None:
    """archie — Connect CLI."""


cli.add_command(login_cmd)
cli.add_command(skills_group)
cli.add_command(workstreams_group)


def main() -> None:
    cli()


if __name__ == "__main__":  # pragma: no cover
    main()
