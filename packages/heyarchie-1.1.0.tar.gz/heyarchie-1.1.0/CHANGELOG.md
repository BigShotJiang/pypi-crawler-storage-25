# heyarchie changelog

## 1.1.0 — 2026-05-17

**The "one token, every surface" release.** After this version, a single
WorkOS-issued `sk_*` bearer key authenticates the SDK end-to-end on
both the HTTP API surface (`/api/v1/*`) and the MCP streaming-HTTP
surface (`/mcp/*`). Phase 0–3b of the alignment plan
(`docs/connect/ALIGNMENT-PLAN.md`).

### New backend surface area (server-side merged 2026-05-17, paired here)

- `GET /api/v1/skills/discover` — ranked text-similarity search over the
  skill catalogue. Wired into `client.skills.discover(goal=..., limit=...)`.
- `/api/v1/connect-keys/*` — key list/create/revoke against the WorkOS
  Management API. Wired into `client.keys.list / create / revoke /
  flush_cache`.

### Auth — one canonical bearer for every Connect surface

`Authorization: Bearer sk_*` now works on every authenticated endpoint:

- Every `/api/v1/*` endpoint (workstreams, conversations, drafts,
  reports, journal entries, search, standards, …)
- Every MCP tool call via `POST /mcp/`

Previously only `POST /api/v1/skills/{slug}/invoke` accepted `sk_*`.

### SDK resources — phantom paths fixed

Pre-1.1 the SDK called several `/v1/*` paths that never existed on the
API and returned 404. These are now either:

- Wrapped around the canonical skill-invoke shim
  (`messages.create`, `documents.analyse`, `journal_entries.create`,
  `standards.research`, `search.search`, `drafts.create`,
  `reports.generate`)
- Re-pointed at the real backend endpoint (`keys.*` →
  `/api/v1/connect-keys/*`; `workstreams.list` → `/api/v1/blueprints`)
- Removed if portal-only (`conversations.*` raises `NotImplementedError`
  with a clear pointer)

### Deprecations removed

`WorkstreamsResource.run / get_run` (sync + async) — the deprecated
`/v1/workstreams/{id}/runs` wrappers were always 404. Deleted. Use
`workstreams.cycles.create()` / `get_cycle()`.

### Models

- `MessageResponse` rewritten to mirror the `ask_archie` skill output
  shape (`answer`, `citations`, `confidence`, …). The pre-1.1 fields
  `id`, `conversation_id`, `created_at` are now optional rather than
  required.

### Dev dependencies

- `pytest-httpx>=0.30` added (was a missing test fixture in 1.0.0).

## 1.0.0 — 2026-05-16

Initial unified release. Merged the previously-separate `archie-connect`
(SDK) and `heyarchie-cli` (CLI) into a single `heyarchie` package
following the `openai` / `huggingface_hub` pattern: `pip install
heyarchie` installs both the library (`import heyarchie`) and the
`archie` console script.
