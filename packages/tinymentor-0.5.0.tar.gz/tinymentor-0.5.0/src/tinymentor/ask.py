from .memory import remember
from .model import generate_response

CACHE = {}

def ask(question: str, max_tokens: int = 50):
    """
    Main Ask Workflow:
    Pure GenAI coding assistant without retrieval.
    """
    if question in CACHE:
        return CACHE[question]
        
    print(f"Analyzing: {question}")
    
    prompt = f"""You are a GenAI coding assistant.
Answer with:
1. code only
2. minimum explanation

Question:
{question}
"""
    
    try:
        answer = generate_response(prompt, max_tokens=max_tokens)
    except Exception as e:
        answer = f"Error during generation: {e}"
        print(answer)
        return
        
    # Memory
    remember(question, answer)
    CACHE[question] = answer
    
    print("\n" + answer)
    return answer
