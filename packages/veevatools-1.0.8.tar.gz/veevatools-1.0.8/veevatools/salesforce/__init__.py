try:
    from .salesforce import Sf
    from .decorators import serialize_zeep
except ImportError as e:
    raise ImportError(
        "salesforce requires additional dependencies. "
        "Install with: pip install veevatools[salesforce]"
    ) from e

__all__ = ["Sf", "serialize_zeep"]
