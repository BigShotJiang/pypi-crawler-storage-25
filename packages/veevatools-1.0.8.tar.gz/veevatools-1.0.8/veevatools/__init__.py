"""Veeva Tools package for accelerating Veeva Systems internal tools development"""

try:
    from .salesforce import Sf
except ImportError:
    Sf = None

try:
    from .veevavault import VaultClient
except ImportError:
    VaultClient = None

try:
    from .veevanetwork import NetworkClient
except ImportError:
    NetworkClient = None

try:
    from .veevanitro import Nitro, NitroClient
except ImportError:
    Nitro = None
    NitroClient = None

# Export error types from veevavault if available
try:
    from .veevavault.errors import (
        VaultAPIError,
        VaultAuthenticationError,
        VaultPermissionError,
        VaultQueryError,
        VaultRateLimitError,
        VaultValidationError,
        VaultErrorType,
        VaultResponseStatus,
    )
except ImportError:
    pass

__all__ = [
    "Sf",
    "VaultClient",
    "NetworkClient",
    "Nitro",
    "NitroClient",
    "VaultAPIError",
    "VaultAuthenticationError",
    "VaultPermissionError",
    "VaultQueryError",
    "VaultRateLimitError",
    "VaultValidationError",
    "VaultErrorType",
    "VaultResponseStatus",
]
