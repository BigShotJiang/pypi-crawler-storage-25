"""Veeva Network search service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class SearchService:
    """Search for entities in Veeva Network."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def search(
        self,
        q: str,
        *,
        address_q: str | None = None,
        types: list[str] | None = None,
        offset: int | None = None,
        limit: int | None = None,
        sort: str | None = None,
        sort_order: str | None = None,
        states: list[str] | None = None,
        statuses: list[str] | None = None,
        return_facets: bool | None = None,
        return_highlights: bool | None = None,
        facet_count: int | None = None,
        include_master_results: bool | None = None,
        search_only_master: bool | None = None,
        filters: str | None = None,
        field_queries: str | None = None,
        exclude_filters: str | None = None,
        lang: str | None = None,
        system_name: str | None = None,
        supplemental: str | None = None,
        filter_by_location: str | None = None,
        sort_by_location: str | None = None,
        sort_result_children: bool | None = None,
        nest_child_object_field_queries: bool | None = None,
        parenthco_filters: str | None = None,
        parenthco_exclude_filters: str | None = None,
        enriched_results: bool | None = None,
        result_language: str | None = None,
    ) -> dict:
        """Search for entities in Network.

        ``GET /api/{v}/search``

        Args:
            q: Search query string.
            address_q: Address-specific search query.
            types: Entity types to search (e.g. ``["HCP"]``, ``["HCO"]``).
            offset: Starting record offset for pagination.
            limit: Maximum number of results.
            sort: Field to sort by.
            sort_order: Sort direction (``"asc"`` or ``"desc"``).
            states: Filter by entity state.
            statuses: Filter by entity status.
            return_facets: Include facet data in results.
            return_highlights: Highlight matching terms.
            facet_count: Number of facet values to return.
            include_master_results: Include master data results.
            search_only_master: Search only master data.
            filters: Field-level filter expression.
            field_queries: Field-level query expression.
            exclude_filters: Fields to exclude from filtering.
            lang: Language code for results.
            system_name: System context for reference values.
            supplemental: Supplemental data to include.
            filter_by_location: Geographic filter.
            sort_by_location: Sort by geographic proximity.
            sort_result_children: Sort child objects in results.
            nest_child_object_field_queries: Nest child field queries.
            parenthco_filters: Filter by parent HCO.
            parenthco_exclude_filters: Exclude parent HCO filter.
            enriched_results: Return enriched data.
            result_language: Language for result labels.

        Returns:
            Search results dict.
        """
        params: dict = {"q": q}
        if address_q is not None:
            params["address_q"] = address_q
        if types is not None:
            params["types"] = ",".join(types)
        if offset is not None:
            params["offset"] = str(offset)
        if limit is not None:
            params["limit"] = str(limit)
        if sort is not None:
            params["sort"] = sort
        if sort_order is not None:
            params["sortOrder"] = sort_order
        if states is not None:
            params["states"] = ",".join(states)
        if statuses is not None:
            params["statuses"] = ",".join(statuses)
        if return_facets is not None:
            params["returnFacets"] = str(return_facets).lower()
        if return_highlights is not None:
            params["returnHighlights"] = str(return_highlights).lower()
        if facet_count is not None:
            params["facetCount"] = str(facet_count)
        if include_master_results is not None:
            params["includeMasterResults"] = str(include_master_results).lower()
        if search_only_master is not None:
            params["searchOnlyMaster"] = str(search_only_master).lower()
        if filters is not None:
            params["filters"] = filters
        if field_queries is not None:
            params["fieldQueries"] = field_queries
        if exclude_filters is not None:
            params["excludefilters"] = exclude_filters
        if lang is not None:
            params["lang"] = lang
        if system_name is not None:
            params["systemName"] = system_name
        if supplemental is not None:
            params["supplemental"] = supplemental
        if filter_by_location is not None:
            params["filterByLocation"] = filter_by_location
        if sort_by_location is not None:
            params["sortByLocation"] = sort_by_location
        if sort_result_children is not None:
            params["sortResultChildren"] = str(sort_result_children).lower()
        if nest_child_object_field_queries is not None:
            params["nestChildObjectFieldQueries"] = str(nest_child_object_field_queries).lower()
        if parenthco_filters is not None:
            params["parenthcofilters"] = parenthco_filters
        if parenthco_exclude_filters is not None:
            params["parenthcoexcludefilters"] = parenthco_exclude_filters
        if enriched_results is not None:
            params["enrichedResults"] = str(enriched_results).lower()
        if result_language is not None:
            params["resultLanguage"] = result_language

        return self.client.api_call("search", params=params)
