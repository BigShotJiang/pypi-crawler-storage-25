"""Veeva Network change request service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class ChangeRequestService:
    """Full lifecycle management for Network change requests: create, retrieve,
    update, process, search, match, approve, and reject."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def create(self, body: dict) -> dict:
        """Create a change request for an HCP or HCO (gray data only).

        ``POST /api/{v}/change_request``
        """
        return self.client.api_call("change_request", method="POST", json_body=body)

    def cancel(self, change_request_id: str) -> dict:
        """Cancel a change request.

        ``DELETE /api/{v}/change_request/{change_request_id}``
        """
        return self.client.api_call(
            f"change_request/{change_request_id}", method="DELETE"
        )

    def retrieve(
        self,
        change_request_ids: str | list[str],
        *,
        status: str | None = None,
        system_name: str | None = None,
        include_entity: bool | None = None,
        since_date: int | None = None,
        to_date: int | None = None,
        include_attachment_info: bool | None = None,
    ) -> dict:
        """Retrieve one or more change requests by ID.

        ``GET /api/{v}/change_requests/{change_request_ids}``

        Args:
            change_request_ids: Single ID or list of IDs.
        """
        if isinstance(change_request_ids, list):
            change_request_ids = ",".join(change_request_ids)

        params = {}
        if status is not None:
            params["status"] = status
        if system_name is not None:
            params["systemName"] = system_name
        if include_entity is not None:
            params["includeEntity"] = str(include_entity).lower()
        if since_date is not None:
            params["sinceDate"] = str(since_date)
        if to_date is not None:
            params["toDate"] = str(to_date)
        if include_attachment_info is not None:
            params["includeAttachmentInfo"] = str(include_attachment_info).lower()
        return self.client.api_call(
            f"change_requests/{change_request_ids}", params=params or None
        )

    def batch_retrieve(self, body: dict) -> dict:
        """Retrieve multiple change requests via POST body.

        ``POST /api/{v}/change_requests/batch``
        """
        return self.client.api_call(
            "change_requests/batch", method="POST", json_body=body
        )

    def update(self, body: dict) -> dict:
        """Update an unprocessed change request.

        ``PUT /api/{v}/change_request``
        """
        return self.client.api_call("change_request", method="PUT", json_body=body)

    def batch_update(self, body: dict) -> dict:
        """Update multiple unprocessed change requests.

        ``PUT /api/{v}/change_request/batch``
        """
        return self.client.api_call(
            "change_request/batch", method="PUT", json_body=body
        )

    def process(
        self,
        change_request_id: str,
        body: dict | None = None,
    ) -> dict:
        """Process an unprocessed change request.

        ``PUT /api/{v}/change_request/process/{change_request_id}``
        """
        return self.client.api_call(
            f"change_request/process/{change_request_id}",
            method="PUT",
            json_body=body,
        )

    def batch_process(self, body: dict) -> dict:
        """Process multiple unprocessed change requests.

        ``PUT /api/{v}/change_request/process/batch``
        """
        return self.client.api_call(
            "change_request/process/batch", method="PUT", json_body=body
        )

    def search(
        self,
        *,
        q: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
        sort: str | None = None,
        sort_order: str | None = None,
        filters: str | None = None,
        system_name: str | None = None,
        master_system_names: str | None = None,
        pending_master_system_names: str | None = None,
    ) -> dict:
        """Search change requests.

        ``GET /api/{v}/change_request/search``
        """
        params = {}
        if q is not None:
            params["q"] = q
        if offset is not None:
            params["offset"] = str(offset)
        if limit is not None:
            params["limit"] = str(limit)
        if sort is not None:
            params["sort"] = sort
        if sort_order is not None:
            params["sortOrder"] = sort_order
        if filters is not None:
            params["filters"] = filters
        if system_name is not None:
            params["systemName"] = system_name
        if master_system_names is not None:
            params["masterSystemNames"] = master_system_names
        if pending_master_system_names is not None:
            params["pendingMasterSystemNames"] = pending_master_system_names
        return self.client.api_call("change_request/search", params=params or None)

    def match(
        self,
        change_request_id: str,
        *,
        vid_key: str | None = None,
        comment: str | None = None,
    ) -> dict:
        """Match a change request to an existing entity.

        ``POST /api/{v}/change_request/match/{change_request_id}``
        """
        params = {}
        if vid_key is not None:
            params["vidKey"] = vid_key
        if comment is not None:
            params["comment"] = comment
        return self.client.api_call(
            f"change_request/match/{change_request_id}",
            method="POST",
            params=params or None,
        )

    def batch_approve(self, body: dict) -> dict:
        """Bulk approve up to 500 change requests.

        ``PUT /api/{v}/change_request/approve/batch``
        """
        return self.client.api_call(
            "change_request/approve/batch", method="PUT", json_body=body
        )

    def batch_reject(self, body: dict) -> dict:
        """Bulk reject up to 500 change requests.

        ``PUT /api/{v}/change_request/reject/batch``
        """
        return self.client.api_call(
            "change_request/reject/batch", method="PUT", json_body=body
        )
