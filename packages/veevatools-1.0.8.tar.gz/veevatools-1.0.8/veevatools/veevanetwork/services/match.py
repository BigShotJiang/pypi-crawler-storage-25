"""Veeva Network match service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class MatchService:
    """Match records against Network data and retrieve key networks/IDNs."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def match(
        self,
        body: dict,
        *,
        address_cleansing: bool | None = None,
        include_master_results: bool | None = None,
        limit: int | None = None,
        match_rule_collection: str | None = None,
        system_name: str | None = None,
        enriched_results: bool | None = None,
        result_language: str | None = None,
    ) -> dict:
        """Match a single record against Network data.

        ``POST /api/{v}/match``
        """
        params = {}
        if address_cleansing is not None:
            params["addressCleansing"] = str(address_cleansing).lower()
        if include_master_results is not None:
            params["includeMasterResults"] = str(include_master_results).lower()
        if limit is not None:
            params["limit"] = str(limit)
        if match_rule_collection is not None:
            params["matchRuleCollection"] = match_rule_collection
        if system_name is not None:
            params["systemName"] = system_name
        if enriched_results is not None:
            params["enrichedResults"] = str(enriched_results).lower()
        if result_language is not None:
            params["resultLanguage"] = result_language
        return self.client.api_call(
            "match", method="POST", json_body=body, params=params or None
        )

    def retrieve_key_networks(
        self,
        body: dict,
        *,
        countries: str | None = None,
    ) -> dict:
        """Retrieve key networks/IDNs from Network.

        ``POST /api/{v}/match``

        Same endpoint as ``match()`` but used for key network retrieval
        with different body structure.
        """
        params = {}
        if countries is not None:
            params["countries"] = countries
        return self.client.api_call(
            "match", method="POST", json_body=body, params=params or None
        )
