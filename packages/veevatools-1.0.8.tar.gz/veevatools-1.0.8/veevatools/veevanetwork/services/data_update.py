"""Veeva Network data update service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class DataUpdateService:
    """Direct data update operations in Network."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def update(self, body: dict) -> dict:
        """Update entity data directly.

        ``PUT /api/{v}/objects``
        """
        return self.client.api_call("objects", method="PUT", json_body=body)
