"""Veeva Network suspect match service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class SuspectMatchService:
    """Batch operations for suspect matches: process, create, reject, retrieve."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def batch_process(self, body: dict) -> dict:
        """Process multiple unprocessed suspect matches.

        ``PUT /api/{v}/suspect-match/process/batch``
        """
        return self.client.api_call(
            "suspect-match/process/batch", method="PUT", json_body=body
        )

    def batch_create(self, body: dict) -> dict:
        """Create multiple suspect matches.

        ``POST /api/{v}/entity/createSuspectMatch/batch``
        """
        return self.client.api_call(
            "entity/createSuspectMatch/batch", method="POST", json_body=body
        )

    def batch_reject(self, body: dict) -> dict:
        """Reject multiple suspect match tasks.

        ``POST /api/{v}/suspect_match/reject/batch``
        """
        return self.client.api_call(
            "suspect_match/reject/batch", method="POST", json_body=body
        )

    def batch_retrieve(self, body: dict) -> dict:
        """Retrieve info about multiple suspect matches.

        ``POST /api/{v}/suspect_match/batch``
        """
        return self.client.api_call(
            "suspect_match/batch", method="POST", json_body=body
        )
