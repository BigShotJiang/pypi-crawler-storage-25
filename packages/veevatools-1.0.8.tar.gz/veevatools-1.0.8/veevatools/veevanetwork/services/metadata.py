"""Veeva Network metadata service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class MetadataService:
    """Read-only access to Network metadata: API versions, fields, object types,
    reference data, hashtags, languages, and field groups."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def retrieve_api_versions(self) -> dict:
        """Retrieve available API versions.

        ``GET /api``
        """
        return self.client.api_call("/api", method="GET")

    def retrieve_version_info(self) -> dict:
        """Retrieve metadata for the current API version.

        ``GET /api/{version}``
        """
        return self.client.api_call(f"/api/{self.client.api_version}", method="GET")

    def retrieve_hashtags(
        self,
        *,
        return_hashtags_for_type: str | None = None,
    ) -> dict:
        """Retrieve list of hashtags available in the Network instance.

        ``GET /api/{v}/metadata/hashtags``
        """
        params = {}
        if return_hashtags_for_type is not None:
            params["returnHashtagsForType"] = return_hashtags_for_type
        return self.client.api_call("metadata/hashtags", params=params or None)

    def retrieve_languages(self) -> dict:
        """Retrieve list of reference data languages.

        ``GET /api/{v}/metadata/languages``
        """
        return self.client.api_call("metadata/languages")

    def retrieve_object_types(
        self,
        *,
        owner: str | None = None,
    ) -> dict:
        """Retrieve list of object types available in Network.

        ``GET /api/{v}/metadata/objectTypes``
        """
        params = {}
        if owner is not None:
            params["owner"] = owner
        return self.client.api_call("metadata/objectTypes", params=params or None)

    def retrieve_fields(
        self,
        *,
        object_types: str | None = None,
        owner: str | None = None,
        details: bool | None = None,
        labels: bool | None = None,
        field_group: str | None = None,
        country: str | None = None,
        countries: str | None = None,
    ) -> dict:
        """Retrieve field metadata for entities.

        ``GET /api/{v}/metadata/fields``
        """
        params = {}
        if object_types is not None:
            params["objectTypes"] = object_types
        if owner is not None:
            params["owner"] = owner
        if details is not None:
            params["details"] = str(details).lower()
        if labels is not None:
            params["labels"] = str(labels).lower()
        if field_group is not None:
            params["fieldGroup"] = field_group
        if country is not None:
            params["country"] = country
        if countries is not None:
            params["countries"] = countries
        return self.client.api_call("metadata/fields", params=params or None)

    def retrieve_field_details(
        self,
        field_ids: str,
        *,
        labels: bool | None = None,
        countries: str | None = None,
    ) -> dict:
        """Retrieve detailed info about specific fields.

        ``GET /api/{v}/metadata/fields/{field_ids}``
        """
        params = {}
        if labels is not None:
            params["labels"] = str(labels).lower()
        if countries is not None:
            params["countries"] = countries
        return self.client.api_call(
            f"metadata/fields/{field_ids}", params=params or None
        )

    def retrieve_field_groups(self) -> dict:
        """Retrieve field groups used by CRM bridge.

        ``GET /api/{v}/metadata/fieldGroups``
        """
        return self.client.api_call("metadata/fieldGroups")

    def retrieve_reference_data_types(
        self,
        *,
        owner: str | None = None,
        inactive: bool | None = None,
        include_codes: bool | None = None,
        country: str | None = None,
        countries: str | None = None,
        system_name: str | None = None,
    ) -> dict:
        """Retrieve reference data types.

        ``GET /api/{v}/metadata/reference_values``
        """
        params = {}
        if owner is not None:
            params["owner"] = owner
        if inactive is not None:
            params["inactive"] = str(inactive).lower()
        if include_codes is not None:
            params["includeCodes"] = str(include_codes).lower()
        if country is not None:
            params["country"] = country
        if countries is not None:
            params["countries"] = countries
        if system_name is not None:
            params["systemName"] = system_name
        return self.client.api_call("metadata/reference_values", params=params or None)

    def retrieve_reference_data_type_details(
        self,
        ref_type: str,
        *,
        owner: str | None = None,
        inactive: bool | None = None,
        country: str | None = None,
        countries: str | None = None,
        system_name: str | None = None,
    ) -> dict:
        """Retrieve detailed info about a specific reference data type.

        ``GET /api/{v}/metadata/reference_values/{type}``
        """
        params = {}
        if owner is not None:
            params["owner"] = owner
        if inactive is not None:
            params["inactive"] = str(inactive).lower()
        if country is not None:
            params["country"] = country
        if countries is not None:
            params["countries"] = countries
        if system_name is not None:
            params["systemName"] = system_name
        return self.client.api_call(
            f"metadata/reference_values/{ref_type}", params=params or None
        )

    def retrieve_reference_data_type_code_details(
        self,
        ref_type: str,
        codes: str,
        *,
        country: str | None = None,
        countries: str | None = None,
        system_name: str | None = None,
    ) -> dict:
        """Retrieve detailed info about specific reference data type codes.

        ``GET /api/{v}/metadata/reference_values/{type}/{codes}``
        """
        params = {}
        if country is not None:
            params["country"] = country
        if countries is not None:
            params["countries"] = countries
        if system_name is not None:
            params["systemName"] = system_name
        return self.client.api_call(
            f"metadata/reference_values/{ref_type}/{codes}", params=params or None
        )
