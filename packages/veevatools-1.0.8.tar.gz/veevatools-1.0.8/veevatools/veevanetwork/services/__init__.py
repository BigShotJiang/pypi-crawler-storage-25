"""Veeva Network API services."""
