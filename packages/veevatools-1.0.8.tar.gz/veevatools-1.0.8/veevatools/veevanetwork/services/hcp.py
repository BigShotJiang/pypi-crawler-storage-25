"""Veeva Network HCP service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class HCPService:
    """HCP-specific operations: retrieval and custom key management."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def retrieve(
        self,
        vid_key: str,
        *,
        system_name: str | None = None,
        enriched_results: bool | None = None,
        result_language: str | None = None,
        return_hashtags_for_type: str | None = None,
    ) -> dict:
        """Retrieve HCP information.

        ``GET /api/{v}/hcps/{vid_key}``
        """
        params = {}
        if system_name is not None:
            params["systemName"] = system_name
        if enriched_results is not None:
            params["enrichedResults"] = str(enriched_results).lower()
        if result_language is not None:
            params["resultLanguage"] = result_language
        if return_hashtags_for_type is not None:
            params["returnHashtagsForType"] = return_hashtags_for_type
        return self.client.api_call(f"hcps/{vid_key}", params=params or None)

    def associate_custom_key(
        self,
        vid_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to an HCP.

        ``POST /api/{v}/hcps/{vid_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"hcps/{vid_key}/custom_keys", method="POST", params=params
        )

    def associate_address_custom_key(
        self,
        vid_key: str,
        address_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to an HCP address.

        ``POST /api/{v}/hcps/{vid_key}/addresses/{address_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"hcps/{vid_key}/addresses/{address_key}/custom_keys",
            method="POST",
            params=params,
        )

    def associate_license_custom_key(
        self,
        vid_key: str,
        license_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to an HCP license.

        ``POST /api/{v}/hcps/{vid_key}/licenses/{license_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"hcps/{vid_key}/licenses/{license_key}/custom_keys",
            method="POST",
            params=params,
        )

    def associate_parenthco_custom_key(
        self,
        vid_key: str,
        parenthco_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to an HCP parent HCO.

        ``POST /api/{v}/hcps/{vid_key}/parent_hcos/{parenthco_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"hcps/{vid_key}/parent_hcos/{parenthco_key}/custom_keys",
            method="POST",
            params=params,
        )
