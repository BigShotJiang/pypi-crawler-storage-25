"""Veeva Network custom key service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class CustomKeyService:
    """Generic custom key operations for entities and child entities."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def associate_to_entity(
        self,
        vid_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to an entity (HCP or HCO).

        ``POST /api/{v}/entities/{vid_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"entities/{vid_key}/custom_keys", method="POST", params=params
        )

    def associate_to_child(
        self,
        vid_key: str,
        children_key: str,
        *,
        custom_key_source_type: str,
        custom_key_item_type: str,
        custom_key_value: str,
        system_name: str,
    ) -> dict:
        """Associate a custom key to a child entity (address, license, parent HCO).

        ``POST /api/{v}/entities/{vid_key}/children/{children_key}/custom_keys``
        """
        params = {
            "custom_key_source_type": custom_key_source_type,
            "custom_key_item_type": custom_key_item_type,
            "custom_key_value": custom_key_value,
            "system_name": system_name,
        }
        return self.client.api_call(
            f"entities/{vid_key}/children/{children_key}/custom_keys",
            method="POST",
            params=params,
        )

    def batch_associate_to_entities(self, body: dict) -> dict:
        """Batch associate custom keys to multiple entities.

        ``POST /api/{v}/entities/custom_keys/associate/batch``
        """
        return self.client.api_call(
            "entities/custom_keys/associate/batch", method="POST", json_body=body
        )

    def batch_associate_to_children(self, body: dict) -> dict:
        """Batch associate custom keys to multiple child entities.

        ``POST /api/{v}/entities/children/custom_keys/associate/batch``
        """
        return self.client.api_call(
            "entities/children/custom_keys/associate/batch",
            method="POST",
            json_body=body,
        )

    def disassociate(self, vid_key: str) -> dict:
        """Deactivate a custom key.

        ``DELETE /api/{v}/custom_keys/{vid_key}``
        """
        return self.client.api_call(f"custom_keys/{vid_key}", method="DELETE")

    def batch_disassociate(self, body: dict) -> dict:
        """Batch deactivate custom keys.

        ``POST /api/{v}/custom_keys/disassociate/batch``
        """
        return self.client.api_call(
            "custom_keys/disassociate/batch", method="POST", json_body=body
        )
