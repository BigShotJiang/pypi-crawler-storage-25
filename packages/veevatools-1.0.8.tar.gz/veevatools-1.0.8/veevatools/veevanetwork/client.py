"""Veeva Network API client."""

from __future__ import annotations

import json
import logging
from typing import Any
from urllib.parse import urlparse

import requests

from .exceptions import AuthenticationError, NetworkAPIError

logger = logging.getLogger(__name__)


class NetworkClient:
    """Core HTTP client for the Veeva Network v37 API.

    Usage::

        # Authenticate with username/password
        client = NetworkClient(
            url="https://mynetwork.veevanetwork.com",
            username="user@example.com",
            password="secret",
        )
        client.authenticate()
        results = client.search.search(q="Smith")

        # Reuse an existing session
        client = NetworkClient(
            url="https://mynetwork.veevanetwork.com",
            session_id="EXISTING_SESSION_ID",
            network_id="EXISTING_NETWORK_ID",
        )
        client.authenticate()  # validates session, skips login POST
    """

    def __init__(
        self,
        url: str,
        username: str | None = None,
        password: str | None = None,
        session_id: str | None = None,
        network_id: str | None = None,
        api_version: str = "v37.0",
        timeout: tuple[int, int] | int | None = (10, 120),
    ):
        parsed = urlparse(url)
        if not parsed.scheme:
            url = f"https://{url}"
            parsed = urlparse(url)
        self.url = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")

        self.username = username
        self.password = password
        self.api_version = api_version
        self.timeout = timeout

        # Populated after authentication (or pre-set via constructor)
        self.session_id: str | None = session_id
        self.network_id: str | None = network_id
        self.user_id: str | None = None
        self.available_versions: list[str] = []

        # Lazy service cache
        self._services: dict[str, Any] = {}

    @classmethod
    def from_credentials(cls, path: str, **kwargs) -> NetworkClient:
        """Create a client from a credentials JSON file.

        Supports two credential formats:

        Session-based (browser-captured token)::

            {
                "url": "https://<instance>.veevanetwork.com",
                "session_id": "<Authorization header value>",
                "network_id": "<networkId>"
            }

        Username/password::

            {
                "url": "https://<instance>.veevanetwork.com",
                "username": "user@example.com",
                "password": "secret"
            }

        Both formats accept an optional ``api_version`` key.
        """
        with open(path) as f:
            creds = json.load(f)
        api_version = creds.get("api_version", kwargs.get("api_version", "v37.0"))
        if "session_id" in creds or "network_id" in creds:
            return cls(
                url=creds["url"],
                session_id=creds.get("session_id"),
                network_id=creds.get("network_id"),
                api_version=api_version,
            )
        return cls(
            url=creds["url"],
            username=creds["username"],
            password=creds["password"],
            api_version=api_version,
        )

    # ------------------------------------------------------------------
    # HTTP transport
    # ------------------------------------------------------------------

    def api_call(
        self,
        endpoint: str,
        method: str = "GET",
        params: dict | None = None,
        json_body: Any = None,
        data: Any = None,
        headers: dict | None = None,
        raw_response: bool = False,
    ) -> dict | requests.Response:
        """Make an HTTP request to the Network API.

        Args:
            endpoint: Relative path (e.g. ``"search"``) — the client
                prepends ``/api/{version}/``. Or an absolute path starting
                with ``/`` which is used as-is (e.g. ``"/api"``).
            method: HTTP method.
            params: Query-string parameters.
            json_body: JSON-serialisable request body.
            data: Form-encoded or raw body data.
            headers: Extra HTTP headers.
            raw_response: Return raw ``requests.Response`` instead of JSON.

        Returns:
            Parsed JSON dict, or raw Response if *raw_response* is True.
        """
        if headers is None:
            headers = {}

        if "Authorization" not in headers and "authorization" not in headers:
            if self.session_id:
                headers["Authorization"] = self.session_id

        api_url = self._build_url(endpoint)

        logger.debug("%s %s", method, api_url)

        try:
            response = requests.request(
                method=method,
                url=api_url,
                headers=headers,
                params=params,
                data=data,
                json=json_body,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            logger.error("Request failed: %s %s — %s", method, api_url, exc)
            raise

        if raw_response:
            return response

        # Parse JSON and check for API-level errors
        try:
            body = response.json()
        except ValueError:
            response.raise_for_status()
            return {"raw_text": response.text}

        if response.status_code >= 400:
            raise NetworkAPIError(response.status_code, body)

        return body

    def _build_url(self, endpoint: str) -> str:
        """Build full URL from a relative or absolute endpoint path."""
        if endpoint.startswith(("http://", "https://")):
            return endpoint
        if endpoint.startswith("/"):
            # Absolute path like "/api" or "/api/v37.0/auth"
            return f"{self.url}{endpoint}"
        # Relative path — prepend /api/{version}/
        return f"{self.url}/api/{self.api_version}/{endpoint}"

    # ------------------------------------------------------------------
    # Authentication convenience
    # ------------------------------------------------------------------

    def authenticate(self) -> dict:
        """Authenticate with the Network API and populate session state.

        Returns:
            The authentication response dict.
        """
        from .services.auth import AuthService
        return AuthService(self).authenticate()

    # ------------------------------------------------------------------
    # Lazy service properties
    # ------------------------------------------------------------------

    def _get_service(self, name: str, factory):
        if name not in self._services:
            self._services[name] = factory(self)
        return self._services[name]

    @property
    def auth(self):
        from .services.auth import AuthService
        return self._get_service("auth", AuthService)

    @property
    def metadata(self):
        from .services.metadata import MetadataService
        return self._get_service("metadata", MetadataService)

    @property
    def search(self):
        from .services.search import SearchService
        return self._get_service("search", SearchService)

    @property
    def entities(self):
        from .services.entities import EntityService
        return self._get_service("entities", EntityService)

    @property
    def hcp(self):
        from .services.hcp import HCPService
        return self._get_service("hcp", HCPService)

    @property
    def hco(self):
        from .services.hco import HCOService
        return self._get_service("hco", HCOService)

    @property
    def change_requests(self):
        from .services.change_requests import ChangeRequestService
        return self._get_service("change_requests", ChangeRequestService)

    @property
    def match(self):
        from .services.match import MatchService
        return self._get_service("match", MatchService)

    @property
    def suspect_match(self):
        from .services.suspect_match import SuspectMatchService
        return self._get_service("suspect_match", SuspectMatchService)

    @property
    def custom_keys(self):
        from .services.custom_keys import CustomKeyService
        return self._get_service("custom_keys", CustomKeyService)

    @property
    def subscriptions(self):
        from .services.subscriptions import SubscriptionService
        return self._get_service("subscriptions", SubscriptionService)

    @property
    def events(self):
        from .services.events import EventsService
        return self._get_service("events", EventsService)

    @property
    def data_update(self):
        from .services.data_update import DataUpdateService
        return self._get_service("data_update", DataUpdateService)
