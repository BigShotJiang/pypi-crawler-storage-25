"""Veeva Network API exceptions."""


class NetworkAPIError(Exception):
    """Raised when the Network API returns an error response."""

    def __init__(self, status_code: int, response_body: dict):
        self.status_code = status_code
        self.response_body = response_body
        # Network API error structure: {"errors": [{"type": "...", "message": "..."}]}
        # Fall back to flat errorType/errorMessage keys for forward-compatibility.
        errors = response_body.get("errors", [])
        first = errors[0] if errors else {}
        self.error_type = first.get("type", response_body.get("errorType", "UNKNOWN"))
        self.error_message = first.get("message", response_body.get("errorMessage", str(response_body)))
        super().__init__(f"[{status_code}] {self.error_type}: {self.error_message}")


class AuthenticationError(NetworkAPIError):
    """Raised when authentication fails."""
    pass
