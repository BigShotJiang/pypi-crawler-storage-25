import logging
import re

logger = logging.getLogger(__name__)


class QueryService:
    """
    Service class for handling VQL (Vault Query Language) queries in Veeva Vault.

    This service provides methods to execute VQL queries against the Veeva Vault API,
    retrieve data, and handle pagination of results.
    """

    def __init__(self, client):
        """
        Initialize the QueryService with a VaultClient instance.

        Args:
            client: An authenticated VaultClient instance that provides
                   session information and Vault URL details.
        """
        self.client = client

    def query(self, query, describe_query=True, record_properties=None, facets=None):
        """
        Submit a VQL query with advanced options.

        This method provides access to all supported query parameters and headers
        in the Vault API.

        Args:
            query (str): A VQL statement of up to 50,000 characters specifying
                the object to query, the fields to retrieve, and any optional filters.
            describe_query (bool): Set to true to include static field metadata in the
                response for the data record. This includes object metadata (name, label)
                and field metadata (type, required, max_length, etc.).
            record_properties (str, optional): Include the record properties object in the
                response. Possible values are 'all', 'hidden', 'redacted', or 'weblink'.
                If set to 'all', includes ID, field properties, permissions, subquery
                properties, and field additional data for each record.
            facets (list, optional): A list of facetable field names to include in the
                response. The response will include counts of unique values for each field.

        Returns:
            dict: The JSON response containing:
                - responseStatus: Success/failure status
                - queryDescribe: Object and field metadata (if requested)
                - responseDetails: Pagination information (pagesize, pageoffset, size, total)
                - data: The query results as specified in the VQL query
                - facets: Facet information (if requested)
                - record_properties: Record property information (if requested)
        """
        endpoint = f"api/{self.client.LatestAPIversion}/query"

        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "X-VaultAPI-DescribeQuery": str(describe_query).lower(),
        }

        if record_properties:
            headers["X-VaultAPI-RecordProperties"] = record_properties

        if facets:
            headers["X-VaultAPI-Facets"] = ",".join(facets)

        data = {"q": query}

        response = self.client.api_call(endpoint, method="POST", headers=headers, data=data)

        if response.get("responseStatus") == "FAILURE":
            logger.warning("VQL query failed: %s", str(response)[:500])
        else:
            logger.info("VQL query success: %d records returned.", len(response.get("data", [])))

        return response

    def bulk_query(self, query):
        """
        Execute a VQL query and return all results with automatic pagination.

        This method automatically handles pagination by following next_page links and
        combines all pages into a single API response dict.

        Args:
            query (str): VQL query string of up to 50,000 characters.
                If PAGESIZE is specified in the query, only the first page will be retrieved.

        Returns:
            dict: A full API response dict with all pages of data combined in the 'data' key.
                Preserves responseStatus, queryDescribe, and responseDetails from the first page.
                responseDetails.size is updated to reflect total records fetched.
                next_page is removed from responseDetails since all pages are consumed.
                Returns the FAILURE response dict if the query fails.
        """
        # Check if PAGESIZE or LIMIT is in the query.
        # If PAGESIZE is explicitly specified, only retrieve the first page.
        # If LIMIT is specified, paginate but stop once the limit is reached.
        # Otherwise, page_count stays None and we paginate through all results.
        page_count = None
        row_limit = None
        if re.search(r"(?i)PAGESIZE", query):
            page_size_match = re.search(r"(?i)PAGESIZE\s+(\d+)", query)
            if page_size_match:
                page_count = int(page_size_match.group(1))
                logger.info(
                    "PAGESIZE %d detected in query. Only retrieving first page.",
                    page_count,
                )
        limit_match = re.search(r"(?i)\bLIMIT\s+(\d+)", query)
        if limit_match:
            row_limit = int(limit_match.group(1))
            logger.info("LIMIT %d detected in query.", row_limit)

        # First page - use query for the initial request
        first_response = self.query(query, describe_query=True)

        if first_response.get("responseStatus") == "FAILURE":
            logger.warning("Bulk query failed: %s", str(first_response)[:500])
            return first_response

        # Collect first page results
        all_data = list(first_response.get("data", []))

        # Handle pagination if needed
        try:
            if page_count is None:
                page_response = first_response
                while (
                    "next_page" in page_response.get("responseDetails", {})
                    and page_response["responseDetails"]["next_page"]
                ):
                    # Stop paginating if we've already reached the LIMIT
                    if row_limit is not None and len(all_data) >= row_limit:
                        break
                    headers = {
                        "X-VaultAPI-DescribeQuery": "true",
                        "Content-Type": "application/x-www-form-urlencoded",
                    }
                    page_response = self.client.api_call(
                        page_response["responseDetails"]["next_page"],
                        method="GET",
                        headers=headers,
                    )
                    all_data.extend(page_response.get("data", []))
        except Exception as e:
            logger.warning("Pagination may be incomplete due to: %s", e)

        # Truncate to LIMIT if specified
        if row_limit is not None and len(all_data) > row_limit:
            all_data = all_data[:row_limit]

        # Build combined response from first page metadata + all data
        combined_response = dict(first_response)
        combined_response["data"] = all_data

        if "responseDetails" in combined_response:
            combined_response["responseDetails"] = dict(combined_response["responseDetails"])
            combined_response["responseDetails"]["size"] = len(all_data)
            combined_response["responseDetails"].pop("next_page", None)

        return combined_response

    def bulk_query_iter(self, query):
        """
        Generator that yields one raw API response dict per page.

        Args:
            query (str): VQL query string of up to 50,000 characters.
                If PAGESIZE is specified in the query, only the first page will be yielded.

        Yields:
            dict: Raw API response dict for each page of results.
        """
        # Check if PAGESIZE is in the query
        page_count = None
        if re.search(r"(?i)PAGESIZE", query):
            page_size_match = re.search(r"(?i)PAGESIZE\s+(\d+)", query)
            if page_size_match:
                page_count = int(page_size_match.group(1))
                logger.info(
                    "PAGESIZE %d detected in query. Only yielding first page.",
                    page_count,
                )

        # First page
        response = self.query(query, describe_query=True)

        if response.get("responseStatus") == "FAILURE":
            logger.warning("bulk_query_iter: first page failed: %s", response)
            return

        yield response

        # If PAGESIZE was specified, stop after first page
        if page_count is not None:
            return

        # Subsequent pages
        try:
            while (
                "next_page" in response.get("responseDetails", {})
                and response["responseDetails"]["next_page"]
            ):
                headers = {
                    "X-VaultAPI-DescribeQuery": "true",
                    "Content-Type": "application/x-www-form-urlencoded",
                }
                response = self.client.api_call(
                    response["responseDetails"]["next_page"],
                    method="GET",
                    headers=headers,
                )
                yield response
        except Exception as e:
            logger.warning("bulk_query_iter: pagination stopped due to: %s", e)
