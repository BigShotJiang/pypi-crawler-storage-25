import logging
import requests
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


class NitroClient:
    """
    Core HTTP client for the Veeva Nitro API.

    Holds all connection state and exposes two request methods:

    - ``api_call()``  — session-auth (Authorization: <access_token>)
    - ``cdw_call()``  — CDW API key auth (Authorization: <cdw_api_token>
                         + tenantName / dwInstanceName / connectorName headers)

    Services are injected from outside (no circular imports).
    """

    def __init__(self):
        # Connection
        self.server_url: Optional[str] = None
        self.username: Optional[str] = None
        self.password: Optional[str] = None

        # Session auth tokens
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None

        # CDW API key auth
        self.cdw_api_token: Optional[str] = None

        # Tenant / instance context
        self.tenant_name: Optional[str] = None
        self.working_instance: Optional[str] = None
        self.connector_name: str = "global__v"

        # Populated from auth response
        self.app_server_url: Optional[str] = None
        self.tenant_instances: List[dict] = []
        self.tenant_roles: List[dict] = []
        self.instance_roles: List[dict] = []
        self.instance_permissions: Optional[dict] = None

    # ------------------------------------------------------------------
    # Session-auth request
    # ------------------------------------------------------------------

    def api_call(
        self,
        endpoint: str,
        method: str = "GET",
        data: Any = None,
        params: Optional[Dict] = None,
        headers: Optional[Dict] = None,
        json_data: Any = None,
        files: Optional[Dict] = None,
        raw_response: bool = False,
    ) -> Union[Dict[str, Any], requests.Response]:
        """
        Make a session-authenticated HTTP request.

        Injects ``Authorization: <access_token>`` unless already present in
        *headers*.  Raises ``requests.HTTPError`` on non-2xx responses unless
        *raw_response* is ``True``.
        """
        merged: Dict[str, str] = {}
        if self.access_token:
            merged["Authorization"] = self.access_token
        if headers:
            merged.update(headers)

        response = requests.request(
            method=method,
            url=self._build_url(endpoint),
            headers=merged,
            params=params,
            data=data,
            json=json_data if not files else None,
            files=files,
        )

        if raw_response:
            return response

        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # CDW API key request
    # ------------------------------------------------------------------

    def cdw_call(
        self,
        endpoint: str,
        method: str = "GET",
        data: Any = None,
        params: Optional[Dict] = None,
        extra_headers: Optional[Dict] = None,
        json_data: Any = None,
        files: Optional[Dict] = None,
        raw_response: bool = False,
    ) -> Union[Dict[str, Any], requests.Response]:
        """
        Make a CDW API key authenticated request.

        Injects ``Authorization: <cdw_api_token>`` plus ``tenantName``,
        ``dwInstanceName``, and ``connectorName`` headers.  Raises
        ``requests.HTTPError`` on non-2xx responses unless *raw_response* is
        ``True``.
        """
        if not self.cdw_api_token:
            raise RuntimeError(
                "CDW API token not available. "
                "Call auth.issue_cdw_token() after login() first."
            )

        headers: Dict[str, str] = {
            "Authorization": self.cdw_api_token,
            "tenantName": self.tenant_name or "",
            "dwInstanceName": self.working_instance or "",
            "connectorName": self.connector_name,
        }
        if extra_headers:
            headers.update(extra_headers)

        logger.debug("CDW %s %s", method, self._build_url(endpoint))

        response = requests.request(
            method=method,
            url=self._build_url(endpoint),
            headers=headers,
            params=params,
            data=data,
            json=json_data if not files else None,
            files=files,
        )

        if raw_response:
            return response

        response.raise_for_status()
        return response.json()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_url(self, endpoint: str) -> str:
        if endpoint.startswith(("http://", "https://")):
            return endpoint
        base = (self.server_url or "").rstrip("/")
        return f"{base}/{endpoint.lstrip('/')}"
