from .client.nitro_client import NitroClient
from .services.auth.auth_service import AuthService
from .services.admin.admin_service import AdminService
from .services.instance.instance_service import InstanceService
from .services.etl.etl_service import ETLService
from .services.mds.mds_service import MDSService
from .services.cdw.cdw_service import CDWService


class Nitro:
    """
    Convenience class — wires NitroClient with all services.

    Usage::

        from veevanitro_wip import Nitro

        n = Nitro()
        n.auth.login(url, username, password)
        n.auth.issue_cdw_token()      # required for ETL + MDS write ops

        # Session-auth endpoints
        n.admin.get_tenant()
        n.admin.get_users()
        n.instance.get_jobs()
        n.instance.get_connectors()

        # CDW API key endpoints
        n.etl.run_job("my_job_name")
        n.mds.download_package("backup.zip")

        # Redshift
        n.cdw.initialize()
        conn = n.cdw.get_db_connection(redshift_user="...", redshift_password="...")

    The underlying ``NitroClient`` is accessible via ``n.client`` for
    advanced use or direct ``api_call()`` / ``cdw_call()`` calls.
    """

    def __init__(self):
        self._client = NitroClient()
        self.auth = AuthService(self._client)
        self.admin = AdminService(self._client)
        self.instance = InstanceService(self._client)
        self.etl = ETLService(self._client)
        self.mds = MDSService(self._client)
        self.cdw = CDWService(self._client)

    @property
    def client(self) -> NitroClient:
        """The underlying NitroClient (for advanced / raw API calls)."""
        return self._client
