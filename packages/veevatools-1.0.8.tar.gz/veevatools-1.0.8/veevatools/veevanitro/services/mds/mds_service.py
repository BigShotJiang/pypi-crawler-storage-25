import logging
from typing import Optional

logger = logging.getLogger(__name__)


class MDSService:
    """
    MDS package and translations management via CDW API key auth.

    Requires ``client.cdw_api_token`` to be set — call
    ``auth.issue_cdw_token()`` after login.

    Endpoints covered:
      POST /mds/api/v1/package/update                    (upload/update package)
      GET  /mds/api/v1/package/download                  (download package)
      POST /mds/api/v1/tables/translations/update        (upsert translations)
      POST /mds/api/v1/tables/translations/replace       (replace translations)
      GET  /mds/api/v1/tables/translations/download      (download translations)
    """

    def __init__(self, client):
        self.client = client

    # ------------------------------------------------------------------
    # Packages
    # ------------------------------------------------------------------

    def upload_package(self, file_path: str) -> dict:
        """
        POST /mds/api/v1/package/update

        Upload (upsert) an MDS package zip.  Existing content is updated;
        new content is inserted.

        Args:
            file_path: Local path to the package ``.zip`` file.
        """
        logger.info("Uploading MDS package from %s", file_path)
        with open(file_path, "rb") as f:
            return self.client.cdw_call(
                "/mds/api/v1/package/update",
                method="POST",
                files={"file": f},
            )

    def download_package(
        self, save_path: str, resolve_vars: bool = False
    ) -> bytes:
        """
        GET /mds/api/v1/package/download

        Download all instance content as a package zip.

        Args:
            save_path: Local path to write the downloaded zip.
            resolve_vars: If ``True``, variable references in task files are
                resolved before packaging.
        """
        params = {"resolveVars": "true"} if resolve_vars else {}
        response = self.client.cdw_call(
            "/mds/api/v1/package/download",
            params=params,
            raw_response=True,
        )
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        logger.info("Package downloaded to %s (%d bytes)", save_path, len(response.content))
        return response.content

    # ------------------------------------------------------------------
    # Translations
    # ------------------------------------------------------------------

    def upload_translations(self, file_path: str) -> dict:
        """
        POST /mds/api/v1/tables/translations/update

        Upsert translations from a CSV file.  Existing entries are updated;
        new entries are inserted.

        Args:
            file_path: Local path to the translations ``.csv`` file.
        """
        logger.info("Uploading translations from %s", file_path)
        with open(file_path, "rb") as f:
            return self.client.cdw_call(
                "/mds/api/v1/tables/translations/update",
                method="POST",
                files={"file": f},
            )

    def replace_translations(self, file_path: str) -> dict:
        """
        POST /mds/api/v1/tables/translations/replace

        Delete all existing translations and replace with the CSV file contents.

        Args:
            file_path: Local path to the translations ``.csv`` file.
        """
        logger.info("Replacing all translations from %s", file_path)
        with open(file_path, "rb") as f:
            return self.client.cdw_call(
                "/mds/api/v1/tables/translations/replace",
                method="POST",
                files={"file": f},
            )

    def download_translations(self, save_path: str) -> bytes:
        """
        GET /mds/api/v1/tables/translations/download

        Download the translations CSV file.

        Args:
            save_path: Local path to write the downloaded CSV.
        """
        response = self.client.cdw_call(
            "/mds/api/v1/tables/translations/download",
            raw_response=True,
        )
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        logger.info("Translations downloaded to %s", save_path)
        return response.content
