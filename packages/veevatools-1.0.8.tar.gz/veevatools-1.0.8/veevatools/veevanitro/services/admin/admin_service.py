import logging
from typing import Optional

logger = logging.getLogger(__name__)


class AdminService:
    """
    Admin-level Nitro API endpoints.

    Endpoints covered:
      GET  /api/v1/admin/tenant
      GET  /api/v1/admin/cluster/configuration
      GET  /api/v1/admin/cluster-details
      GET  /api/v1/admin/jobs/results
      GET  /api/v1/admin/users
      GET  /api/v1/admin/users/application-roles
      GET  /api/v1/admin/users/security-report
      GET  /api/v1/admin/workspaces/{name}/session-token
      GET  /api/v1/admin/userPools/providers
      GET  /api/v1/admin/userPools/providers/userPools
      GET  /api/v1/admin/ftp/users
      GET  /api/v1/admin/application-users
      GET  /api/v1/admin/usage-metrics
      GET  /api/v1/admin/files
      GET  /api/v1/admin/schemas
      GET  /api/v1/admin/scheduler
      GET  /api/v1/admin/scheduled-jobs
      GET  /api/v1/admin/file-triggers
      GET  /api/v1/admin/orchestrations
    """

    def __init__(self, client):
        self.client = client

    # ------------------------------------------------------------------
    # Tenant & cluster
    # ------------------------------------------------------------------

    def get_tenant(self) -> dict:
        """GET /api/v1/admin/tenant — tenant information."""
        return self.client.api_call("/api/v1/admin/tenant")

    def get_cluster_configuration(self) -> dict:
        """GET /api/v1/admin/cluster/configuration — cluster config (includes clusterEndpoint)."""
        return self.client.api_call("/api/v1/admin/cluster/configuration")

    def get_cluster_details(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/cluster-details — cluster details for an instance."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/cluster-details",
            headers=self._instance_headers(),
        )

    def get_job_results(
        self,
        instance_name: Optional[str] = None,
        size: int = 1000,
        job_id: Optional[str] = None,
    ) -> dict:
        """GET /api/v1/admin/jobs/results — job execution history."""
        self._set_instance(instance_name)
        params = {
            "instanceName": self.client.working_instance,
            "size": size,
        }
        if job_id is not None:
            params["jobId"] = job_id
        return self.client.api_call("/api/v1/admin/jobs/results", params=params)

    # ------------------------------------------------------------------
    # Users
    # ------------------------------------------------------------------

    def get_users(self) -> dict:
        """GET /api/v1/admin/users — all users (includes redshiftUserName per user)."""
        return self.client.api_call("/api/v1/admin/users")

    def get_application_roles(self, app: str = "APP_SERVER") -> dict:
        """GET /api/v1/admin/users/application-roles — application roles."""
        return self.client.api_call(
            "/api/v1/admin/users/application-roles",
            params={"app": app},
        )

    # ------------------------------------------------------------------
    # Workspaces
    # ------------------------------------------------------------------

    def get_workspace_session_token(
        self,
        workspace_name: str,
        redshift_user: str,
        instance_name: Optional[str] = None,
    ) -> dict:
        """
        GET /api/v1/admin/workspaces/{name}/session-token

        Returns temporary S3 + Redshift credentials scoped to a workspace.

        .. known-issue::
            The Nitro API may return HTTP 200 with an error body (e.g.
            ``{"message": "No static resource ...", "errors": {...}}``) instead
            of a proper 4xx status code when the workspace does not support
            session tokens or the feature is not enabled on this tenant.  This
            method detects that pattern and raises ``RuntimeError`` so callers
            are not silently handed an error dict.
        """
        self._set_instance(instance_name)
        data = self.client.api_call(
            f"/api/v1/admin/workspaces/{workspace_name}/session-token",
            params={"redshiftUser": redshift_user},
            headers=self._instance_headers(),
        )
        # Detect HTTP-200 error body: server returns 200 with error content instead
        # of a proper error status code for unsupported workspaces/tenants.
        if isinstance(data, dict) and (
            "No static resource" in str(data.get("message", ""))
            or ("errors" in data and "message" in data)
        ):
            raise RuntimeError(
                f"Workspace session token not available for '{workspace_name}': "
                f"{data.get('message', data)}"
            )
        return data

    # ------------------------------------------------------------------
    # Identity providers / user pools
    # ------------------------------------------------------------------

    def get_identity_providers(self) -> dict:
        """GET /api/v1/admin/userPools/providers — configured identity providers."""
        return self.client.api_call("/api/v1/admin/userPools/providers")

    def get_user_pools(self) -> dict:
        """GET /api/v1/admin/userPools/providers/userPools — Cognito user pools."""
        return self.client.api_call("/api/v1/admin/userPools/providers/userPools")

    # ------------------------------------------------------------------
    # FTP / application users
    # ------------------------------------------------------------------

    def get_ftp_users(self) -> dict:
        """GET /api/v1/admin/ftp/users — FTP user accounts."""
        return self.client.api_call("/api/v1/admin/ftp/users")

    def get_application_users(self) -> dict:
        """GET /api/v1/admin/application-users — application (service) users."""
        return self.client.api_call("/api/v1/admin/application-users")

    def get_security_report(self) -> dict:
        """GET /api/v1/admin/users/security-report — user security report."""
        return self.client.api_call("/api/v1/admin/users/security-report")

    # ------------------------------------------------------------------
    # Scheduler / scheduled jobs
    # ------------------------------------------------------------------

    def get_scheduler(self) -> dict:
        """GET /api/v1/admin/scheduler — scheduler configuration."""
        return self.client.api_call("/api/v1/admin/scheduler")

    def get_scheduled_jobs(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/scheduled-jobs — list of scheduled job definitions."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/scheduled-jobs",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # File triggers & orchestrations
    # ------------------------------------------------------------------

    def get_file_triggers(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/file-triggers — file-based job triggers."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/file-triggers",
            headers=self._instance_headers(),
        )

    def get_orchestrations(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/orchestrations — orchestration definitions."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/orchestrations",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Files & schemas
    # ------------------------------------------------------------------

    def get_files(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/files — managed file listing."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/files",
            headers=self._instance_headers(),
        )

    def get_schemas(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/schemas — data schemas."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/schemas",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Usage metrics
    # ------------------------------------------------------------------

    def get_usage_metrics(self, instance_name: Optional[str] = None) -> dict:
        """GET /api/v1/admin/usage-metrics — platform usage metrics."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/api/v1/admin/usage-metrics",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _set_instance(self, instance_name: Optional[str]) -> None:
        if instance_name:
            self.client.working_instance = instance_name

    def _instance_headers(self) -> dict:
        return {
            "Authorization": self.client.access_token or "",
            "Dwinstancename": self.client.working_instance or "",
            "Tenantname": self.client.tenant_name or "",
        }
