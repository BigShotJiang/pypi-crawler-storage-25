import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class ETLService:
    """
    ETL job and task sequence execution via CDW API key auth.

    Requires ``client.cdw_api_token`` to be set — call
    ``auth.issue_cdw_token()`` after login.

    Endpoints covered:
      POST /api/v1/services/etl/job             (run ETL job)
      POST /api/v1/services/etl/task-sequence   (run task sequence)
    """

    def __init__(self, client):
        self.client = client

    def run_job(
        self,
        name: str,
        variables: Optional[Dict[str, str]] = None,
        instance_name: Optional[str] = None,
        connector_name: Optional[str] = None,
    ) -> dict:
        """
        POST /api/v1/services/etl/job?name={name}

        Trigger an ETL job by name.

        Args:
            name: Job name (must match the job's name on the target connector).
            variables: Optional runtime key-value pairs, e.g.
                ``{"env": "prod"}``.  Multi-value lists use comma-separated
                strings: ``{"ids": "1,2,3"}``.
            instance_name: Override working instance.
            connector_name: Override connector (default: ``client.connector_name``).
                Jobs are scoped to a connector — pass the connector the job
                belongs to (e.g. ``"global__v"``, ``"migration__c"``).
        """
        if instance_name:
            self.client.working_instance = instance_name
        if connector_name:
            self.client.connector_name = connector_name
        logger.info(
            "Running ETL job: %s | instance=%s | connector=%s",
            name, self.client.working_instance, self.client.connector_name,
        )
        return self.client.cdw_call(
            "/api/v1/services/etl/job",
            method="POST",
            params={"name": name},
            json_data=variables or {},
        )

    def run_task_sequence(
        self,
        name: str,
        variables: Optional[Dict[str, str]] = None,
        instance_name: Optional[str] = None,
        connector_name: Optional[str] = None,
    ) -> dict:
        """
        POST /api/v1/services/etl/task-sequence?name={name}

        Trigger a task sequence by name.

        Args:
            name: Task sequence name.
            variables: Optional runtime key-value pairs.
            instance_name: Override working instance.
            connector_name: Override connector.
        """
        if instance_name:
            self.client.working_instance = instance_name
        if connector_name:
            self.client.connector_name = connector_name
        logger.info(
            "Running task sequence: %s | instance=%s | connector=%s",
            name, self.client.working_instance, self.client.connector_name,
        )
        return self.client.cdw_call(
            "/api/v1/services/etl/task-sequence",
            method="POST",
            params={"name": name},
            json_data=variables or {},
        )
