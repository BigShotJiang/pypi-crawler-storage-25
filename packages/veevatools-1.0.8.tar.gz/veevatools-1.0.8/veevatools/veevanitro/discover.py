"""
Playwright-based API discovery harness for Veeva Nitro.

Launches a visible Chrome window, logs in automatically, then intercepts
every XHR/fetch request the UI makes.  Navigate through each section of
the Nitro UI manually; all API calls are captured in real time.

When you are done, close the browser window (or press Ctrl+C) and the
script saves the captured endpoints to:
  docs/api-discovery/nitro/endpoints.json

Usage (from the veevatools/ project root):
    python veevanitro/discover.py

Options (edit the constants below):
    HEADLESS    — set True to run without a visible window (CI/automated mode)
    SESSION     — label for this discovery session (used in output filename)
"""

import json
import re
import sys
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, urljoin

# ── Allow running as: python veevanitro/discover.py ───────────────────
sys.path.insert(0, str(Path(__file__).parent.parent))

from playwright.sync_api import sync_playwright, Request, Response

# ── Config ─────────────────────────────────────────────────────────────────
HEADLESS = False          # False = visible browser; True = automated/headless
SESSION = "manual"        # Session label (used in output path)
CREDS_FILE = Path(__file__).parent / "credentials.json"
OUTPUT_DIR = Path(__file__).parent.parent / "docs" / "api-discovery" / "nitro"
# ───────────────────────────────────────────────────────────────────────────

# Patterns that identify Nitro API calls (filter out static assets etc.)
API_PATH_PATTERNS = [
    r"/api/v\d+/",
    r"/mds/api/v\d+/",
]

# ID-like path segments to normalize  (UUID, numeric IDs, Nitro-style IDs)
_ID_RE = re.compile(
    r"/([A-Za-z0-9]{20,}|[0-9]+)(?=/|$)"
)


def _is_api_call(url: str) -> bool:
    path = urlparse(url).path
    return any(re.search(p, path) for p in API_PATH_PATTERNS)


def _normalize_path(path: str) -> str:
    """Replace ID-like segments with :id placeholders."""
    return _ID_RE.sub("/:id", path)


def _safe_json(text: str):
    try:
        return json.loads(text)
    except Exception:
        return None


def main():
    creds = json.loads(CREDS_FILE.read_text())
    base_url = creds["url"].rstrip("/")
    username = creds["username"]
    password = creds["password"]

    # ── Storage ────────────────────────────────────────────────────────────
    # key: (method, normalized_path) → list of captured call dicts
    captured: dict = defaultdict(list)

    def on_request(request: Request):
        if not _is_api_call(request.url):
            return
        parsed = urlparse(request.url)
        norm_path = _normalize_path(parsed.path)
        # Capture query params as a set of keys (not values — values may be sensitive)
        query_keys = list({k for k in parsed.query.split("&") if "=" in k for k in [k.split("=")[0]]})
        entry = {
            "url": request.url,
            "method": request.method,
            "path": parsed.path,
            "normalized_path": norm_path,
            "query_params": query_keys,
            "post_data": _safe_json(request.post_data) if request.post_data else None,
        }
        captured[(request.method, norm_path)].append(entry)
        print(f"  → {request.method:6s}  {norm_path}  {query_keys or ''}")

    # ── Launch ─────────────────────────────────────────────────────────────
    print(f"\nStarting Nitro API discovery session: {SESSION}")
    print(f"Target: {base_url}")
    print(f"Output: {OUTPUT_DIR}/endpoints.json\n")

    # ── Pre-authenticate via API to get token ─────────────────────────────
    print("Authenticating via API...")
    from veevanitro import Nitro
    _n = Nitro()
    _n.auth.login(base_url, username, password)
    access_token = _n.client.access_token
    tenant_name = _n.client.tenant_name or ""
    working_instance = _n.client.working_instance or ""
    instance_details = json.dumps({"instanceName": working_instance})
    print(f"  tenant={tenant_name}  instance={working_instance}")

    domain = urlparse(base_url).hostname

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=HEADLESS, slow_mo=50)
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            record_har_path=str(OUTPUT_DIR / f"session-{SESSION}.har"),
        )

        # ── Inject auth cookies — bypasses the login form entirely ────────
        context.add_cookies([
            {"name": "accessToken",    "value": access_token,    "domain": domain, "path": "/"},
            {"name": "USER_NAME",      "value": username,         "domain": domain, "path": "/"},
            {"name": "TENANT_NAME",    "value": tenant_name,      "domain": domain, "path": "/"},
            {"name": "INSTANCE_DETAILS","value": instance_details,"domain": domain, "path": "/"},
        ])

        page = context.new_page()
        page.on("request", on_request)

        # ── Navigate directly to the home page (skip login) ───────────────
        print("Opening Nitro (cookie-authenticated)...")
        page.goto(f"{base_url}/home/jobs")
        page.wait_for_load_state("networkidle", timeout=15000)
        time.sleep(2)

        # Confirm we're in — if redirected back to /login, fall back to form
        if "/login" in page.url:
            print("  Cookie auth failed, falling back to form login...")
            page.goto(base_url)
            page.wait_for_selector("input", timeout=10000)
            time.sleep(1)
            page.fill('input[type="text"]', username)
            time.sleep(0.3)
            page.click("text=Continue")
            time.sleep(2)
            page.fill('input[type="password"]', password)
            time.sleep(0.3)
            page.click("text=Log In")
            try:
                page.wait_for_url(lambda url: "/login" not in url, timeout=15000)
            except Exception:
                if not HEADLESS:
                    print("  Please log in manually, then press ENTER here.")
                    input()
        print(f"  Landed at: {page.url}")

        print("\nLogin complete (or in progress). Navigate the Nitro UI to discover endpoints.")
        print("All API calls are being captured.")
        print("\nSuggested sections to visit:")
        sections = [
            "Dashboard / Home",
            "ETL Jobs (list, detail, history, logs)",
            "MDS Packages",
            "CDW / Data Warehouse",
            "Users / Permissions",
            "Settings / Configuration",
            "Reports / Analytics",
            "Any remaining sections",
        ]
        for i, s in enumerate(sections, 1):
            print(f"  {i}. {s}")

        if HEADLESS:
            # In headless mode, navigate programmatically to known pages
            print("\nHeadless mode: attempting automated navigation...")
            _automated_navigation(page, base_url)
        else:
            print("\nClose the browser window when done to save results.")
            try:
                # Wait until the browser is closed
                while not page.is_closed():
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
            except Exception:
                pass

        print("\nSaving results...")
        context.close()
        browser.close()

    # ── Save ──────────────────────────────────────────────────────────────
    _save_results(captured, base_url)


def _automated_navigation(page, base_url: str):
    """
    Navigate known Nitro UI routes programmatically to trigger API calls.
    Confirmed paths based on live session observation, plus candidate guesses.
    """
    # Confirmed paths (from live login redirect observation)
    confirmed_paths = [
        "/home/jobs",
        "/home/mds",
        "/home/users",
        "/home/settings",
        "/home/instances",
        "/home/connectors",
        "/home/workspaces",
        "/home/reports",
        "/home/analytics",
        "/home/audit",
        "/home/notifications",
        "/home/dashboard",
        "/home/cdw",
        "/home/packages",
        "/home/admin",
    ]
    for path in confirmed_paths:
        try:
            url = base_url + path
            print(f"  Visiting {url}")
            page.goto(url, timeout=10000, wait_until="networkidle")
            time.sleep(1.5)
        except Exception as e:
            print(f"    (skipped: {e})")

    # Also try to find and click all nav links from the current page
    try:
        nav_links = page.evaluate("""() => {
            return [...document.querySelectorAll('nav a, [role=navigation] a, aside a')]
                .map(a => a.href).filter(h => h && !h.includes('#'));
        }""")
        unique_links = list(set(nav_links))
        print(f"\n  Found {len(unique_links)} nav links, visiting...")
        for link in unique_links[:20]:  # cap at 20
            try:
                print(f"  Visiting nav link: {link}")
                page.goto(link, timeout=8000, wait_until="networkidle")
                time.sleep(1.5)
            except Exception as e:
                print(f"    (skipped: {e})")
    except Exception as e:
        print(f"  Nav link scan failed: {e}")


def _save_results(captured: dict, base_url: str):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Deduplicate and summarize
    summary = []
    for (method, norm_path), calls in sorted(captured.items()):
        # Collect all query param keys seen across calls
        all_query_keys = sorted({k for c in calls for k in c.get("query_params", [])})
        # Sample one real URL
        sample_url = calls[0]["url"]
        # Sample post body schema (keys only, not values)
        post_keys = None
        for c in calls:
            if c.get("post_data") and isinstance(c["post_data"], dict):
                post_keys = sorted(c["post_data"].keys())
                break

        entry = {
            "method": method,
            "normalized_path": norm_path,
            "sample_url": sample_url,
            "call_count": len(calls),
            "query_param_keys": all_query_keys,
        }
        if post_keys is not None:
            entry["request_body_keys"] = post_keys
        summary.append(entry)

    output = {
        "generated": datetime.utcnow().isoformat() + "Z",
        "base_url": base_url,
        "total_unique_endpoints": len(summary),
        "endpoints": summary,
    }

    out_path = OUTPUT_DIR / "endpoints.json"
    out_path.write_text(json.dumps(output, indent=2))

    print(f"\n{'='*60}")
    print(f"  Discovery complete!")
    print(f"  {len(summary)} unique endpoints captured")
    print(f"  Saved to: {out_path}")
    print(f"{'='*60}")

    # Print summary table
    print("\nCaptured endpoints:")
    for e in summary:
        q = f"  ?{','.join(e['query_param_keys'])}" if e["query_param_keys"] else ""
        b = f"  body={e['request_body_keys']}" if e.get("request_body_keys") else ""
        print(f"  {e['method']:6s}  {e['normalized_path']}{q}{b}  (×{e['call_count']})")


if __name__ == "__main__":
    main()
