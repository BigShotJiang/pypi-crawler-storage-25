"""Tests for StdioChannel — validates that delayed stdin responses are not lost."""

import asyncio
import json
import threading
import time

import pytest

from flow_platform_sdk.models.channel import ChannelRequest
from flow_platform_sdk.session.channel.stdio import StdioChannel
from flow_platform_sdk.session.protocol import RESULT_PREFIX


class TestStdioChannelDelayedResponse:
    """Reproduce the stdin race condition where orphaned threads steal lines."""

    @pytest.mark.asyncio
    async def test_delayed_response_received(self):
        """Response arriving after >1s poll timeout must still be delivered.

        With the current per-iteration thread design, Thread 1 blocks for 3s on
        readline.  After 1s the async future is cancelled, Thread 2 is spawned.
        When Thread 1 finishes, it checks `if not fut.done()` — the future IS
        done (cancelled) so the line is silently dropped.
        """
        call_id = "test-delayed"
        payload = {"id": call_id, "result": {"value": 42}, "error": None}
        line = RESULT_PREFIX + json.dumps(payload)

        call_count = {"n": 0}

        def mock_readline():
            call_count["n"] += 1
            if call_count["n"] == 1:
                time.sleep(3)  # longer than the 1s poll timeout
                return line + "\n"
            # Subsequent calls block forever (no more stdin data)
            threading.Event().wait()
            return ""

        channel = StdioChannel()
        channel._read_stdin_line = mock_readline

        request = ChannelRequest(id=call_id, service="s", operation="op", input={})
        response = await asyncio.wait_for(channel.request(request), timeout=10)

        assert response.result == {"value": 42}
        assert response.error is None
