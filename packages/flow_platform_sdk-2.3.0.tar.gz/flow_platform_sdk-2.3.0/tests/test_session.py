"""Tests for Session.invoke — validates error handling edge cases."""

import pytest

from flow_platform_sdk.models.channel import ChannelRequest, ChannelResponse
from flow_platform_sdk.session.channel.base import Channel
from flow_platform_sdk.session.session import Session


class TestSessionErrorHandling:
    """Error messages should be preserved accurately, not silently swallowed."""

    @pytest.mark.asyncio
    async def test_error_response_not_double_wrapped(self):
        """Service error message should appear once, not double-prefixed.

        Current bug: `if response.error: raise RuntimeError(...)` is inside
        the try/except, so the generic `except Exception` catches it and
        wraps it a second time.
        """

        class ErrorChannel(Channel):
            async def request(self, message: ChannelRequest) -> ChannelResponse:
                return ChannelResponse(
                    id=message.id,
                    result=None,
                    error={"message": "DB connection failed"},
                )

        session = Session(ErrorChannel())
        with pytest.raises(RuntimeError) as exc_info:
            await session.invoke("svc", "op")

        msg = str(exc_info.value)
        # The error prefix should appear exactly once, not twice
        assert msg.count("failed:") == 1, f"Double-wrapped error: {msg}"
        assert "DB connection failed" in msg

    @pytest.mark.asyncio
    async def test_empty_exception_shows_type(self):
        """Exception with empty str(e) should include the type name.

        Current bug: `raise RuntimeError(f"... failed: {str(e)}")` produces
        an empty suffix when str(e) is "", e.g. for asyncio.TimeoutError().
        """

        class BrokenChannel(Channel):
            async def request(self, message: ChannelRequest) -> ChannelResponse:
                raise RuntimeError()  # empty message, str(e) == ""

        session = Session(BrokenChannel())
        with pytest.raises(RuntimeError) as exc_info:
            await session.invoke("svc", "op")

        msg = str(exc_info.value)
        # Should contain the exception type name, not end with "failed: "
        assert "RuntimeError" in msg, f"Missing type name in error: {msg}"
