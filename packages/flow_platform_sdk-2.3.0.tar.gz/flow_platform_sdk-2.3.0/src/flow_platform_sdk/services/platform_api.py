from typing import Any

from .base import ServiceProxy


class PlatformApiService(ServiceProxy):
    def __init__(self):
        super().__init__("platform_api")

    # -------- LLM Judge --------

    async def llm_judge(
        self,
        actual: str,
        expected: str,
        input_query: str = "",
        criteria: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Server-side LLM-as-judge evaluation using Claude.

        Routes the call through the stdio RPC so the server can use
        its own API credentials (E2B sandboxes lack ANTHROPIC_API_KEY).

        Args:
            actual: Agent's output
            expected: Expected output
            input_query: Original input query for context
            criteria: List of criteria to judge

        Returns:
            {"score": float, "error": str | None}
        """
        return await self._invoke(
            "llm_judge",
            actual=actual,
            expected=expected,
            input_query=input_query,
            criteria=criteria,
        )

    # -------- Data Connectors --------

    async def list_connectors(self) -> dict[str, Any]:
        return await self._invoke("list_connectors")

    async def get_schema(self, connector_id: str) -> dict[str, Any]:
        return await self._invoke(
            "get_schema",
            connector_id=connector_id,
        )

    async def list_integrations(self) -> dict[str, Any]:
        return await self._invoke("list_integrations")

    async def list_actions(self, integration_id) -> dict[str, Any]:
        return await self._invoke("list_actions", integration_id=integration_id)

    async def execute_query(
        self,
        connector_id: str,
        sql_query: str,
        max_rows: int = 1000,
    ) -> dict[str, Any]:
        return await self._invoke(
            "execute_query",
            connector_id=connector_id,
            sql_query=sql_query,
            max_rows=max_rows,
        )

    async def discover_schema(
        self,
        connector_id: str,
        include_sample_data: bool = False,
        table_filter: str | None = None,
    ) -> dict[str, Any]:
        return await self._invoke(
            "discover_schema",
            connector_id=connector_id,
            include_sample_data=include_sample_data,
            table_filter=table_filter,
        )

    async def get_table_info(
        self,
        connector_id: str,
        table_name: str,
    ) -> dict[str, Any]:
        return await self._invoke(
            "get_table_info",
            connector_id=connector_id,
            table_name=table_name,
        )

    async def get_sample_data(
        self,
        connector_id: str,
        table_name: str,
        limit: int = 5,
    ) -> dict[str, Any]:
        return await self._invoke(
            "get_sample_data",
            connector_id=connector_id,
            table_name=table_name,
            limit=min(limit, 100),
        )

    # -------- Knowledge Base --------

    async def list_knowledge_bases(self) -> dict[str, Any]:
        return await self._invoke("list_knowledge_bases")

    async def query_knowledge_base(
        self,
        knowledge_base_id: str,
        query: str,
    ) -> dict[str, Any]:
        return await self._invoke(
            "query_knowledge_base",
            knowledge_base_id=knowledge_base_id,
            query=query,
        )

    async def get_knowledge_base_connection(
        self,
        knowledge_base_id: str,
    ) -> dict[str, Any]:
        """Get vector store connection config for a knowledge base."""
        return await self._invoke(
            "get_knowledge_base_connection",
            knowledge_base_id=knowledge_base_id,
        )

    async def query_astradb(
        self,
        knowledge_base_id: str,
        query: str | None = None,
        top_k: int = 10,
        category_filter: str | None = None,
        explore_mode: bool = False,
        sample_size: int = 25,
        filenames: list[str] | None = None,
    ) -> dict[str, Any]:
        """Query an AstraDB knowledge base. Three modes:

        - explore_mode=True: random sample of the collection, no query needed.
        - filenames=[...]: fetch ALL chunks from AstraDB for the given filenames
          (overindex). Use after a search call has returned matched_filenames.
        - default (query provided): semantic search via Action Orchestrator.
          Returns top-k chunks plus matched_filenames for a follow-up overindex.
        """
        return await self._invoke(
            "query_astradb",
            knowledge_base_id=knowledge_base_id,
            query=query,
            top_k=top_k,
            category_filter=category_filter,
            explore_mode=explore_mode,
            sample_size=sample_size,
            filenames=filenames,
        )

    # -------- Agent Evaluation --------

    async def invoke_agent(
        self,
        agent_spec_id: str,
        draft_skill_id: str | None = None,
        input_message: str = "",
        context: dict[str, Any] | None = None,
        timeout: int = 60,
    ) -> dict[str, Any]:
        """
        Invoke an agent with optional draft skill for evaluation.

        Args:
            agent_spec_id: Agent specification ID to invoke
            draft_skill_id: Optional draft skill ID for testing
            input_message: User input message/query
            context: Optional context dictionary
            timeout: Request timeout in seconds

        Returns:
            {
                "conversation_id": str,
                "output": str,
                "latency_ms": float,
                "trace": List[Dict],
                "error": Optional[str]
            }
        """
        return await self._invoke(
            "invoke_agent",
            agent_spec_id=agent_spec_id,
            draft_skill_id=draft_skill_id,
            input_message=input_message,
            context=context or {},
            timeout=timeout,
        )

    # --------------BAIC Upload/evals---------
    async def upload_ground_truth_csv(
        self,
        knowledge_base_id: str,
        file_path: str,
    ) -> dict[str, Any]:
        """Upload a CSV ground truth dataset for a knowledge base."""
        return await self._invoke(
            "upload_ground_truth_csv",
            knowledge_base_id=knowledge_base_id,
            file_path=file_path,
        )

    async def create_evaluation_job(
        self,
        knowledge_base_id: str,
        name: str,
    ) -> dict[str, Any]:
        """Create a RAG evaluation job for a knowledge base."""
        return await self._invoke(
            "create_evaluation_job",
            knowledge_base_id=knowledge_base_id,
            name=name,
        )
