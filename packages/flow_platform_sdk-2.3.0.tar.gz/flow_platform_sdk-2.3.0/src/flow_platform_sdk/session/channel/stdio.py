import asyncio
import os
import sys
import threading

from ...models.channel import ChannelRequest, ChannelResponse
from ..protocol import encode_call, try_decode_result
from .base import Channel

TIMEOUT = int(os.environ.get("FLOW_SDK_TIMEOUT", "300"))


class StdioChannel(Channel):
    """Standard I/O based channel for inter-process communication.

    Uses a single persistent daemon thread to read stdin lines into an
    asyncio queue.  This avoids the race condition where multiple
    short-lived reader threads compete for stdin and orphaned threads
    silently drop data.
    """

    def __init__(self):
        self._line_queue: asyncio.Queue | None = None
        self._reader_thread: threading.Thread | None = None

    def _read_stdin_line(self):
        return sys.stdin.readline()

    def _ensure_reader(self, loop: asyncio.AbstractEventLoop) -> None:
        """Start the single stdin reader thread if not already running."""
        if self._reader_thread is not None:
            return
        self._line_queue = asyncio.Queue()

        def _reader():
            while True:
                try:
                    line = self._read_stdin_line()
                    if line:
                        loop.call_soon_threadsafe(self._line_queue.put_nowait, line.rstrip("\n"))
                except Exception:
                    break

        self._reader_thread = threading.Thread(target=_reader, daemon=True)
        self._reader_thread.start()

    async def _read_response(self, call_id: str, result_queue: asyncio.Queue) -> None:
        """Wait for a response with the matching call_id from the line queue."""
        self._ensure_reader(asyncio.get_event_loop())
        try:
            while True:
                line = await self._line_queue.get()
                payload = try_decode_result(line)
                if not payload:
                    continue
                if payload.get("id") == call_id:
                    await result_queue.put(payload)
                    break
        except asyncio.CancelledError:
            pass

    async def request(self, message: ChannelRequest) -> ChannelResponse:
        """Send request via stdout and wait for response via stdin."""
        call_id = message.id
        result_queue: asyncio.Queue = asyncio.Queue()

        reader_task = asyncio.create_task(self._read_response(call_id, result_queue))

        try:
            message_dict = message.model_dump()
            print(encode_call(message_dict), flush=True)

            response_dict = await asyncio.wait_for(result_queue.get(), timeout=TIMEOUT)

            return ChannelResponse(**response_dict)

        finally:
            reader_task.cancel()
            try:
                await reader_task
            except asyncio.CancelledError:
                pass
