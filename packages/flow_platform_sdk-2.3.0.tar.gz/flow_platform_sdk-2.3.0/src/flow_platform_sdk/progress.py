"""Fire-and-forget progress emission for sandbox scripts."""

import json

from .session.protocol import PROGRESS_PREFIX


def emit_progress(message: str, current: int | None = None, total: int | None = None) -> None:
    """Emit a progress event to the host runtime via stdout protocol.

    Args:
        message: Human-readable progress message.
        current: Current step number (optional).
        total: Total number of steps (optional).
    """
    payload: dict = {"message": message}
    if current is not None:
        payload["current"] = current
    if total is not None:
        payload["total"] = total
    print(PROGRESS_PREFIX + json.dumps(payload, separators=(",", ":")), flush=True)
