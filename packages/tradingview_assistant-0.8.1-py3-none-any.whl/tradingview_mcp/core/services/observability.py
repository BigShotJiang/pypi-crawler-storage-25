from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from collections import defaultdict
from typing import Any

from starlette.responses import PlainTextResponse
from starlette.types import Message, Receive, Scope, Send

from tradingview_mcp.core.services.request_guard import _decode_jsonrpc_method_and_tool, _endpoint_label

logger = logging.getLogger("tradingview_mcp.observability")


class ObservabilityCollector:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._requests_total = 0
        self._errors_total = 0
        self._tool_calls_total: dict[str, int] = defaultdict(int)
        self._tool_errors_total: dict[str, int] = defaultdict(int)
        self._tool_latency_ms_sum: dict[str, float] = defaultdict(float)
        self._tool_latency_count: dict[str, int] = defaultdict(int)
        self._source_failures_total: dict[str, int] = defaultdict(int)

    def record(
        self,
        *,
        endpoint: str,
        latency_ms: float,
        http_status: int,
        source_failures: list[str],
        request_id: str,
        user_id: str,
    ) -> None:
        status_error = http_status >= 400

        with self._lock:
            self._requests_total += 1
            self._tool_calls_total[endpoint] += 1
            self._tool_latency_ms_sum[endpoint] += latency_ms
            self._tool_latency_count[endpoint] += 1
            if status_error:
                self._errors_total += 1
                self._tool_errors_total[endpoint] += 1
            for src in source_failures:
                self._source_failures_total[src] += 1

        log_event = {
            "request_id": request_id,
            "user_id": user_id,
            "endpoint": endpoint,
            "latency_ms": round(latency_ms, 3),
            "http_status": http_status,
            "source_statuses": {
                "failed_count": len(source_failures),
                "failed_sources": source_failures,
            },
        }
        logger.info(json.dumps(log_event, separators=(",", ":"), sort_keys=True))

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            per_tool = {}
            for tool, count in self._tool_calls_total.items():
                lat_count = self._tool_latency_count.get(tool, 0)
                avg_latency = 0.0
                if lat_count > 0:
                    avg_latency = self._tool_latency_ms_sum.get(tool, 0.0) / lat_count
                per_tool[tool] = {
                    "calls_total": count,
                    "errors_total": self._tool_errors_total.get(tool, 0),
                    "avg_latency_ms": round(avg_latency, 3),
                }

            return {
                "requests_total": self._requests_total,
                "errors_total": self._errors_total,
                "error_rate": round((self._errors_total / self._requests_total), 4)
                if self._requests_total
                else 0.0,
                "tools": per_tool,
                "sources": dict(self._source_failures_total),
            }

    def prometheus(self) -> str:
        snapshot = self.snapshot()
        lines = [
            "# HELP tvmcp_requests_total Total HTTP requests observed",
            "# TYPE tvmcp_requests_total counter",
            f"tvmcp_requests_total {snapshot['requests_total']}",
            "# HELP tvmcp_errors_total Total HTTP requests with status >= 400",
            "# TYPE tvmcp_errors_total counter",
            f"tvmcp_errors_total {snapshot['errors_total']}",
        ]

        for tool, payload in snapshot["tools"].items():
            label = tool.replace('"', "'")
            lines.append(f'tvmcp_tool_calls_total{{tool="{label}"}} {payload["calls_total"]}')
            lines.append(f'tvmcp_tool_errors_total{{tool="{label}"}} {payload["errors_total"]}')
            lines.append(f'tvmcp_tool_avg_latency_ms{{tool="{label}"}} {payload["avg_latency_ms"]}')

        for source, count in snapshot["sources"].items():
            label = source.replace('"', "'")
            lines.append(f'tvmcp_source_failures_total{{source="{label}"}} {count}')

        return "\n".join(lines) + "\n"


class StructuredObservabilityMiddleware:
    def __init__(self, app, collector: ObservabilityCollector):
        self.app = app
        self.collector = collector

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        start = time.perf_counter()
        headers = {k.decode("latin1").lower(): v.decode("latin1") for k, v in scope.get("headers", [])}
        request_id = headers.get("x-request-id") or uuid.uuid4().hex
        user_id = headers.get("mcp-session-id", "anonymous")

        method = scope.get("method", "GET").upper()
        endpoint = f"{method}:{scope.get('path', '')}"

        body_events: list[Message] = []
        chunks: list[bytes] = []
        if method == "POST":
            more_body = True
            while more_body:
                event = await receive()
                body_events.append(event)
                if event.get("type") == "http.request":
                    chunks.append(event.get("body", b""))
                    more_body = bool(event.get("more_body", False))
                else:
                    more_body = False
            rpc_method, rpc_tool = _decode_jsonrpc_method_and_tool(b"".join(chunks))
            endpoint = _endpoint_label(rpc_method, rpc_tool)

        response_status = 200
        response_body: list[bytes] = []

        async def replay_receive() -> Message:
            if body_events:
                return body_events.pop(0)
            return {"type": "http.request", "body": b"", "more_body": False}

        async def wrapped_send(message: Message) -> None:
            nonlocal response_status
            if message.get("type") == "http.response.start":
                response_status = int(message.get("status", 200))
            elif message.get("type") == "http.response.body":
                response_body.append(message.get("body", b""))
            await send(message)

        await self.app(scope, replay_receive if method == "POST" else receive, wrapped_send)

        source_failures = _extract_source_failures(response_body)
        latency_ms = (time.perf_counter() - start) * 1000.0

        self.collector.record(
            endpoint=endpoint,
            latency_ms=latency_ms,
            http_status=response_status,
            source_failures=source_failures,
            request_id=request_id,
            user_id=user_id,
        )


def _extract_source_failures(response_chunks: list[bytes]) -> list[str]:
    if not response_chunks:
        return []

    raw = b"".join(response_chunks)
    if not raw:
        return []

    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, TypeError):
        return []

    candidates: list[Any] = []
    if isinstance(payload, dict):
        candidates.append(payload)
        result = payload.get("result")
        if isinstance(result, dict):
            candidates.append(result)
            data = result.get("data")
            if isinstance(data, dict):
                candidates.append(data)

    for c in candidates:
        source_failures = c.get("source_failures") if isinstance(c, dict) else None
        if isinstance(source_failures, list):
            names = []
            for item in source_failures:
                if isinstance(item, dict):
                    src = item.get("source") or item.get("symbol") or "unknown"
                    names.append(str(src))
                else:
                    names.append(str(item))
            return names

    return []


_COLLECTOR: ObservabilityCollector | None = None


def get_observability_collector() -> ObservabilityCollector:
    global _COLLECTOR
    if _COLLECTOR is None:
        _COLLECTOR = ObservabilityCollector()
    return _COLLECTOR


def observability_prometheus_response() -> PlainTextResponse:
    return PlainTextResponse(get_observability_collector().prometheus(), media_type="text/plain; version=0.0.4")
