"""
Unified HTTP Client — TVMCP-007.

All external HTTP GET calls in the service layer should go through this module.
Provides:
  - Consistent timeout policy (env-driven, no magic constants in callers).
  - Retry with exponential backoff on transient errors (connection refused,
    timeout, 429, 5xx).
  - Per-host circuit breaker to stop hammering failing upstream sources.
  - Proxy support via proxy_manager (shared with legacy callers).

Public API
----------
  get(url, *, timeout=None, headers=None) -> bytes
      Convenience wrapper using the process-wide singleton HttpClient.

  HttpClient(config=None)
      Instantiate a custom client with different settings (useful in tests).

Circuit Breaker States
----------------------
  CLOSED   — normal operation; failures tracked.
  OPEN     — circuit opened after threshold consecutive failures; requests
              fail fast with CircuitOpenError without hitting the network.
  HALF_OPEN — after open_duration seconds, one probe request is allowed;
              success → CLOSED, failure → OPEN (reset timer).
"""
from __future__ import annotations

import json
import logging
import random
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
from urllib.parse import urlparse

from tradingview_mcp.core.config import get_config
from tradingview_mcp.core.services.proxy_manager import build_opener_with_proxy

logger = logging.getLogger(__name__)

_DEFAULT_UA = "tradingview-mcp/0.7.1"

# ─── Exceptions ───────────────────────────────────────────────────────────────


class HttpClientError(RuntimeError):
    """Base for all http_client errors."""


class CircuitOpenError(HttpClientError):
    """Raised when a host's circuit breaker is OPEN and the call is rejected."""


# ─── Circuit Breaker ──────────────────────────────────────────────────────────


class _CBState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class _HostCB:
    """Per-host circuit-breaker mutable state. Protected by a lock."""

    state: _CBState = _CBState.CLOSED
    consecutive_failures: int = 0
    opened_at: float = 0.0
    lock: threading.Lock = field(default_factory=threading.Lock)


# ─── HttpClient ───────────────────────────────────────────────────────────────


class HttpClient:
    """
    Centralised HTTP client with retry, backoff, proxy, and circuit-breaker.

    All service modules should call ``http_client.get(url)`` rather than
    constructing urllib openers directly.
    """

    def __init__(self, user_agent: str = _DEFAULT_UA) -> None:
        cfg = get_config().performance
        self._timeout: float = cfg.http_default_timeout
        self._max_retries: int = cfg.http_max_retries
        self._backoff_base: float = cfg.http_backoff_base
        self._cb_threshold: int = cfg.http_circuit_breaker_threshold
        self._cb_open_duration: float = cfg.http_circuit_breaker_open_duration
        self._user_agent = user_agent
        self._cb_states: dict[str, _HostCB] = {}
        self._cb_lock = threading.Lock()
        # Build a single opener shared across requests (includes proxy if configured)
        self._opener: urllib.request.OpenerDirector = build_opener_with_proxy(user_agent)

    # ── Circuit breaker helpers ───────────────────────────────────────────────

    def _get_cb(self, host: str) -> _HostCB:
        with self._cb_lock:
            if host not in self._cb_states:
                self._cb_states[host] = _HostCB()
            return self._cb_states[host]

    def _cb_allow(self, host: str) -> bool:
        """Return True if the request is allowed; False if circuit is OPEN."""
        cb = self._get_cb(host)
        with cb.lock:
            if cb.state is _CBState.CLOSED:
                return True
            if cb.state is _CBState.OPEN:
                if time.monotonic() - cb.opened_at >= self._cb_open_duration:
                    cb.state = _CBState.HALF_OPEN
                    logger.debug("Circuit half-open for %s", host)
                    return True
                return False
            # HALF_OPEN: allow the probe
            return True

    def _cb_record_success(self, host: str) -> None:
        cb = self._get_cb(host)
        with cb.lock:
            if cb.state is not _CBState.CLOSED:
                logger.info("Circuit closed for %s after successful probe", host)
            cb.state = _CBState.CLOSED
            cb.consecutive_failures = 0

    def _cb_record_failure(self, host: str) -> None:
        cb = self._get_cb(host)
        with cb.lock:
            cb.consecutive_failures += 1
            if cb.state is _CBState.HALF_OPEN or cb.consecutive_failures >= self._cb_threshold:
                cb.state = _CBState.OPEN
                cb.opened_at = time.monotonic()
                logger.warning(
                    "Circuit opened for %s after %d consecutive failures",
                    host, cb.consecutive_failures,
                )

    # ── Core GET ─────────────────────────────────────────────────────────────

    def get(
        self,
        url: str,
        *,
        timeout: Optional[float] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> bytes:
        """
        Perform an HTTP GET and return the response body as bytes.

        Raises
        ------
        CircuitOpenError
            When the host's circuit is OPEN.
        HttpClientError
            When all retries are exhausted.
        """
        host = urlparse(url).netloc or url
        effective_timeout = timeout if timeout is not None else self._timeout

        if not self._cb_allow(host):
            raise CircuitOpenError(
                f"Circuit breaker OPEN for {host!r}; request blocked to protect upstream"
            )

        req = urllib.request.Request(url)
        req.add_header("User-Agent", self._user_agent)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)

        last_exc: BaseException = HttpClientError("No attempts made")
        attempts = self._max_retries + 1

        for attempt in range(1, attempts + 1):
            try:
                with self._opener.open(req, timeout=effective_timeout) as resp:
                    status = resp.getcode()
                    if status and status >= 500:
                        raise urllib.error.HTTPError(
                            url, status, f"Server error {status}", {}, None  # type: ignore[arg-type]
                        )
                    body: bytes = resp.read()
                self._cb_record_success(host)
                return body

            except urllib.error.HTTPError as exc:
                last_exc = exc
                if exc.code == 429 or (exc.code and exc.code >= 500):
                    # Retriable: rate-limited or server error
                    self._cb_record_failure(host)
                    if attempt <= self._max_retries:
                        delay = self._backoff_base * (2 ** (attempt - 1)) * (0.75 + random.random() * 0.5)
                        logger.warning(
                            "HTTP %d from %s (attempt %d/%d); retrying in %.2fs",
                            exc.code, host, attempt, attempts, delay,
                        )
                        time.sleep(delay)
                        continue
                else:
                    # Non-retriable (4xx other than 429)
                    self._cb_record_failure(host)
                    raise HttpClientError(f"HTTP {exc.code} from {url}") from exc

            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last_exc = exc
                self._cb_record_failure(host)
                if attempt <= self._max_retries:
                    delay = self._backoff_base * (2 ** (attempt - 1)) * (0.75 + random.random() * 0.5)
                    logger.warning(
                        "Network error from %s (attempt %d/%d): %s; retrying in %.2fs",
                        host, attempt, attempts, exc, delay,
                    )
                    time.sleep(delay)
                    continue

        raise HttpClientError(
            f"All {attempts} attempts failed for {url}: {last_exc}"
        ) from last_exc

    def get_json(
        self,
        url: str,
        *,
        timeout: Optional[float] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> object:
        """GET and decode JSON. Raises HttpClientError on failure or invalid JSON."""
        body = self.get(url, timeout=timeout, headers=headers)
        try:
            return json.loads(body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise HttpClientError(f"Invalid JSON from {url}: {exc}") from exc

    # ── Introspection ────────────────────────────────────────────────────────

    def circuit_states(self) -> dict[str, str]:
        """Return a snapshot of circuit-breaker states keyed by host."""
        with self._cb_lock:
            return {host: cb.state.value for host, cb in self._cb_states.items()}


# ─── Process-wide singleton ───────────────────────────────────────────────────

_client: Optional[HttpClient] = None
_client_lock = threading.Lock()


def _get_client() -> HttpClient:
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = HttpClient()
    return _client


def get(
    url: str,
    *,
    timeout: Optional[float] = None,
    headers: Optional[dict[str, str]] = None,
) -> bytes:
    """Module-level GET using the process-wide singleton HttpClient."""
    return _get_client().get(url, timeout=timeout, headers=headers)


def get_json(
    url: str,
    *,
    timeout: Optional[float] = None,
    headers: Optional[dict[str, str]] = None,
) -> object:
    """Module-level GET+JSON decode using the process-wide singleton HttpClient."""
    return _get_client().get_json(url, timeout=timeout, headers=headers)
