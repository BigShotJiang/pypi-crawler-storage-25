﻿from __future__ import annotations

from typing import Dict, Optional, Tuple

IndicatorDict = Dict
OptIndicatorDict = Optional[Dict]
FibTrend = Tuple[str, str]

_FIB_RETRACEMENT_RATIOS = [0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0]
_FIB_EXTENSION_RATIOS = [1.272, 1.618, 2.618]
