"""Portfolio correlation analysis (pure Python, no external dependencies)."""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple


def _mean(values: List[float]) -> float:
    return sum(values) / len(values)


def _pearson(a: List[float], b: List[float]) -> float:
    """Compute Pearson correlation between two equal-length return series."""
    n = len(a)
    if n < 2 or len(b) != n:
        return 0.0

    mean_a = _mean(a)
    mean_b = _mean(b)

    cov = sum((a[i] - mean_a) * (b[i] - mean_b) for i in range(n))
    std_a = math.sqrt(sum((x - mean_a) ** 2 for x in a))
    std_b = math.sqrt(sum((x - mean_b) ** 2 for x in b))

    if std_a == 0.0 or std_b == 0.0:
        # Constant series — treat as perfectly correlated (same direction)
        return 1.0 if std_a == std_b else 0.0

    return cov / (std_a * std_b)


def compute_correlation_matrix(
    returns_dict: Dict[str, List[float]],
) -> Dict[str, Dict[str, float]]:
    """Build a symmetric pairwise Pearson correlation matrix.

    Args:
        returns_dict: {symbol: [daily_returns]} with equal-length lists.

    Returns:
        Nested dict {symbol_a: {symbol_b: correlation}}.
    """
    symbols = list(returns_dict.keys())
    matrix: Dict[str, Dict[str, float]] = {s: {} for s in symbols}

    for i, sym_a in enumerate(symbols):
        matrix[sym_a][sym_a] = 1.0
        for j, sym_b in enumerate(symbols):
            if j <= i:
                continue
            corr = _pearson(returns_dict[sym_a], returns_dict[sym_b])
            corr = round(max(-1.0, min(1.0, corr)), 6)
            matrix[sym_a][sym_b] = corr
            matrix[sym_b][sym_a] = corr  # symmetric

    return matrix


def check_pair_correlation(
    returns_a: List[float],
    returns_b: List[float],
    max_correlation: float = 0.80,
) -> Dict[str, object]:
    """Check whether two assets breach a (positive) correlation limit.

    Only high *positive* correlation is blocked; negative correlation
    (diversifying assets) is always allowed.

    Returns:
        dict with "allowed", "correlation".
    """
    corr = round(_pearson(returns_a, returns_b), 6)
    allowed = corr < max_correlation  # only block high positive correlation
    return {
        "allowed": allowed,
        "correlation": corr,
        "max_correlation": max_correlation,
        "reason": (
            f"Correlation {corr:.3f} exceeds limit {max_correlation}"
        ) if not allowed else "OK",
    }


def check_portfolio_correlation(
    portfolio_returns: Dict[str, List[float]],
    new_symbol_returns: List[float],
    new_symbol: str,
    max_avg_correlation: float = 0.70,
) -> Dict[str, object]:
    """Check how a new symbol correlates with the existing portfolio.

    Computes Pearson correlation between the new symbol and each existing
    holding, then returns the average absolute correlation, the most
    correlated symbol, and whether the addition is allowed.

    Args:
        portfolio_returns: {existing_symbol: [returns]}.
        new_symbol_returns: Return series for the new symbol.
        new_symbol: Name of the new symbol (for reporting).
        max_avg_correlation: Maximum average absolute correlation allowed.

    Returns:
        dict with "allowed", "avg_correlation", "most_correlated".
    """
    if not portfolio_returns:
        return {
            "allowed": True,
            "avg_correlation": 0.0,
            "most_correlated": None,
            "reason": "No existing holdings to compare against",
        }

    correlations: Dict[str, float] = {}
    for sym, rets in portfolio_returns.items():
        correlations[sym] = _pearson(new_symbol_returns, rets)

    avg_abs_corr = sum(abs(c) for c in correlations.values()) / len(correlations)
    most_corr_sym = max(correlations, key=lambda s: abs(correlations[s]))
    most_corr_val = correlations[most_corr_sym]

    allowed = avg_abs_corr <= max_avg_correlation

    return {
        "allowed": allowed,
        "avg_correlation": round(avg_abs_corr, 6),
        "most_correlated": {"symbol": most_corr_sym, "correlation": round(most_corr_val, 6)},
        "new_symbol": new_symbol,
        "max_avg_correlation": max_avg_correlation,
        "reason": (
            f"Average correlation {avg_abs_corr:.3f} exceeds limit {max_avg_correlation}"
        ) if not allowed else "OK",
    }


def find_correlated_pairs(
    returns_dict: Dict[str, List[float]],
    threshold: float = 0.70,
) -> List[Tuple[str, str, float]]:
    """Find all symbol pairs with absolute correlation ≥ threshold.

    Returns:
        List of (symbol_a, symbol_b, correlation) sorted by abs(correlation) desc.
    """
    symbols = list(returns_dict.keys())
    pairs: List[Tuple[str, str, float]] = []

    for i, sym_a in enumerate(symbols):
        for sym_b in symbols[i + 1:]:
            corr = _pearson(returns_dict[sym_a], returns_dict[sym_b])
            if abs(corr) >= threshold:
                pairs.append((sym_a, sym_b, round(corr, 6)))

    pairs.sort(key=lambda t: abs(t[2]), reverse=True)
    return pairs
