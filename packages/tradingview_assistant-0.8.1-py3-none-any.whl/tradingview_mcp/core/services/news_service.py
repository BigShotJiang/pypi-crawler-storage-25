"""
Financial News Service via RSS feeds.

Uses feedparser (already installed as part of agent-reach dependencies).
No API keys required. Pulls from free, public RSS feeds.

Sources:
  crypto: CoinDesk, Cointelegraph
  stocks: Reuters Business News
  all:    Combined
"""
from __future__ import annotations

from html import escape
from datetime import datetime, timezone
from typing import Any, Optional, cast

# feedparser is bundled with agent-reach (installed globally)
try:
    import feedparser as _feedparser  # type: ignore[import-not-found]
except ImportError:
    _feedparser = None

feedparser = _feedparser
_FEEDPARSER_AVAILABLE = feedparser is not None

# ─── Feed Catalog ─────────────────────────────────────────────────────────────

RSS_FEEDS: dict[str, list[dict[str, str]]] = {
    "crypto": [
        {"url": "https://www.coindesk.com/arc/outboundfeeds/rss/", "name": "CoinDesk"},
        {"url": "https://cointelegraph.com/rss", "name": "CoinTelegraph"},
    ],
    "stocks": [
        {"url": "https://feeds.reuters.com/reuters/businessNews", "name": "Reuters Business"},
        {"url": "https://feeds.reuters.com/reuters/companyNews", "name": "Reuters Company"},
    ],
    "all": [
        {"url": "https://feeds.reuters.com/reuters/businessNews", "name": "Reuters Business"},
        {"url": "https://www.coindesk.com/arc/outboundfeeds/rss/", "name": "CoinDesk"},
        {"url": "https://cointelegraph.com/rss", "name": "CoinTelegraph"},
    ],
}

_TIMEOUT = 8


# ─── Public API ───────────────────────────────────────────────────────────────

def fetch_news(
    symbol: Optional[str] = None,
    category: str = "stocks",
    limit: int = 10,
) -> list[dict[str, str]]:
    """
    Fetch financial news from RSS feeds.

    Args:
        symbol:   Optional ticker filter. If provided, only returns headlines
                  that mention the symbol (case-insensitive). e.g. "AAPL", "BTC"
        category: Feed group — "crypto" | "stocks" | "all"
        limit:    Maximum number of items to return

    Returns:
        List of news items with title, url, published, summary, source.
    """
    if not _FEEDPARSER_AVAILABLE:
        return [{
            "error": "feedparser not installed. Run: pip install feedparser",
            "install": "pip install feedparser"
        }]

    parser = cast(Any, feedparser)

    feeds = RSS_FEEDS.get(category, RSS_FEEDS["stocks"])
    results: list[dict[str, str]] = []
    seen_urls: set[str] = set()

    for feed_info in feeds:
        if len(results) >= limit:
            break
        try:
            import socket as _socket
            _old_timeout = _socket.getdefaulttimeout()
            _socket.setdefaulttimeout(_TIMEOUT)
            try:
                feed: Any = parser.parse(feed_info["url"])
            finally:
                _socket.setdefaulttimeout(_old_timeout)
            source_name = str(feed.feed.get("title", feed_info["name"]))

            for entry in feed.entries:
                if len(results) >= limit:
                    break

                title = str(entry.get("title", "") or "")
                summary = str(entry.get("summary", "") or entry.get("description", "") or "")
                url = str(entry.get("link", "") or "")

                # Deduplicate by URL
                if url and url in seen_urls:
                    continue
                if url:
                    seen_urls.add(url)

                # Symbol filter
                if symbol:
                    combined = f"{title} {summary}".upper()
                    if symbol.upper() not in combined:
                        continue

                results.append({
                    "title": _sanitize_text(title),
                    "url": _sanitize_text(url),
                    "published": str(entry.get("published", "") or ""),
                    "summary": _sanitize_text(summary)[:300],
                    "source": _sanitize_text(source_name),
                })

        except Exception:
            continue

    return results[:limit]


def fetch_news_summary(
    symbol: Optional[str] = None,
    category: str = "stocks",
    limit: int = 10,
) -> dict[str, Any]:
    """
    Fetch news and return structured dict for MCP tool output.
    """
    items = fetch_news(symbol, category, limit)
    return {
        "symbol": symbol,
        "category": category,
        "count": len(items),
        "feedparser_available": _FEEDPARSER_AVAILABLE,
        "items": items,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ─── Utils ────────────────────────────────────────────────────────────────────

def _clean_html(text: str) -> str:
    """Strip basic HTML tags from text."""
    import re
    text = re.sub(r"<[^>]+>", "", text)
    for entity, char in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&nbsp;", " ")):
        text = text.replace(entity, char)
    return text.strip()


def _sanitize_text(text: object) -> str:
    """Return cleaned and HTML-escaped plain text for safe rendering."""
    return escape(_clean_html(str(text or "")), quote=True)
