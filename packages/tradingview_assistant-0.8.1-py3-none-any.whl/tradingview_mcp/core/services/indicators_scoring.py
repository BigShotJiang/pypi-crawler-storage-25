﻿from __future__ import annotations
from typing import Dict, Optional

from tradingview_mcp.core.services.indicators_metrics import _safe_round

def compute_stock_score(indicators: Dict, change_pct_rank: Optional[float] = None, currency: str = "EGP") -> Optional[Dict]:
    """Compute a 100-point composite stock score for ranking.

    Sections:
      A. Trend & Momentum  ΓÇö 50 pts (EMA structure, RSI, MACD, relative perf)
      B. Confirmation       ΓÇö 20 pts (Volume, ADX)
      C. Risk-Adjusted      ΓÇö 15 pts (ATR volatility, drawdown proxy)
      D. Fundamental OverlayΓÇö 15 pts (TV recommendation as proxy)

    Args:
        indicators: TradingView indicator dict.
        change_pct_rank: Percentile rank (0.0ΓÇô1.0) of this stock's change
                         among the scanned universe. 0.0 = worst, 1.0 = best.
                         If None, relative performance section is skipped.

    Returns dict with score, breakdown, grade, signals, penalties. None if no data.
    """
    close = indicators.get("close")
    open_price = indicators.get("open")
    if not close or not open_price:
        return None

    breakdown = {}
    signals = []
    penalties = []
    total = 0

    # ΓöÇΓöÇ A. Trend & Momentum ΓÇö 50 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

    # A1. EMA Trend Structure ΓÇö 15 pts
    ema20 = indicators.get("EMA20")
    ema50 = indicators.get("EMA50")
    ema200 = indicators.get("EMA200")

    if ema20 and ema50 and ema200:
        if close > ema20 > ema50 > ema200:
            ema_pts = 15
            signals.append("Perfect EMA alignment (Price>20>50>200)")
        elif close > ema20 > ema50:
            ema_pts = 10
            signals.append("EMA bullish (Price>20>50, 50<=200)")
        elif close > ema20:
            ema_pts = 5
            signals.append("Price above EMA20 only")
        else:
            ema_pts = 0
    elif ema20 and close > ema20:
        ema_pts = 5
    else:
        ema_pts = 0
    breakdown["ema_trend"] = ema_pts
    total += ema_pts

    # A2. RSI Strength Zone ΓÇö 10 pts
    rsi = indicators.get("RSI")
    rsi_pts = 0
    if rsi is not None:
        if 55 <= rsi <= 70:
            rsi_pts = 10
            signals.append(f"RSI {rsi:.0f} in optimal zone (55-70)")
        elif 50 <= rsi < 55:
            rsi_pts = 7
        elif 70 < rsi <= 75:
            rsi_pts = 5
            signals.append(f"RSI {rsi:.0f} slightly elevated")
        elif 45 <= rsi < 50:
            rsi_pts = 3
        else:
            rsi_pts = 0
    breakdown["rsi"] = rsi_pts
    total += rsi_pts

    # A3. MACD Confirmation ΓÇö 10 pts
    macd_line = indicators.get("MACD.macd")
    macd_signal = indicators.get("MACD.signal")
    macd_pts = 0
    if macd_line is not None and macd_signal is not None:
        histogram = macd_line - macd_signal
        if macd_line > macd_signal and histogram > 0:
            macd_pts = 10
            signals.append("MACD bullish + histogram rising")
        elif macd_line > macd_signal:
            macd_pts = 7
            signals.append("MACD bullish crossover")
        elif histogram > 0:
            macd_pts = 4
        else:
            macd_pts = 0
    breakdown["macd"] = macd_pts
    total += macd_pts

    # A4. Relative Price Performance ΓÇö 15 pts
    perf_pts = 0
    if change_pct_rank is not None:
        if change_pct_rank >= 0.90:
            perf_pts = 15
            signals.append("Top 10% price performer")
        elif change_pct_rank >= 0.75:
            perf_pts = 12
            signals.append("Top 25% price performer")
        elif change_pct_rank >= 0.60:
            perf_pts = 8
        elif change_pct_rank >= 0.40:
            perf_pts = 4
        else:
            perf_pts = 0
    breakdown["relative_performance"] = perf_pts
    total += perf_pts

    # ΓöÇΓöÇ B. Confirmation ΓÇö 20 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

    # B5. Volume Confirmation ΓÇö 10 pts
    volume = indicators.get("volume")
    vol_sma20 = indicators.get("volume.SMA20")
    vol_pts = 0
    vol_ratio = None
    if volume and vol_sma20 and vol_sma20 > 0:
        vol_ratio = volume / vol_sma20
        if vol_ratio >= 1.5:
            vol_pts = 10
            signals.append(f"Volume {vol_ratio:.1f}x above avg (strong participation)")
        elif vol_ratio >= 1.2:
            vol_pts = 7
        elif vol_ratio >= 1.0:
            vol_pts = 4
        else:
            vol_pts = 0
    breakdown["volume_confirmation"] = vol_pts
    total += vol_pts

    # B6. ADX Trend Strength ΓÇö 10 pts
    adx = indicators.get("ADX")
    adx_plus = indicators.get("ADX+DI")
    adx_minus = indicators.get("ADX-DI")
    adx_pts = 0
    if adx is not None:
        if adx >= 30:
            adx_pts = 10
            signals.append(f"Strong trend (ADX {adx:.0f})")
        elif 25 <= adx < 30:
            adx_pts = 8
        elif 20 <= adx < 25:
            adx_pts = 5
        else:
            adx_pts = 0
    breakdown["adx"] = adx_pts
    total += adx_pts

    # ΓöÇΓöÇ C. Risk-Adjusted Technical Quality ΓÇö 15 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

    # C7. Volatility Control (ATR%) ΓÇö 10 pts
    atr_val = indicators.get("ATR")
    atr_pct = (atr_val / close) * 100 if atr_val and close > 0 else None
    vol_ctrl_pts = 0
    if atr_pct is not None:
        if 1.0 <= atr_pct <= 3.0:
            vol_ctrl_pts = 10
            signals.append(f"ATR% {atr_pct:.1f}% (healthy volatility)")
        elif 3.0 < atr_pct <= 4.5:
            vol_ctrl_pts = 7
        elif 4.5 < atr_pct <= 6.0:
            vol_ctrl_pts = 4
        else:
            vol_ctrl_pts = 0
            if atr_pct > 6.0:
                signals.append(f"ATR% {atr_pct:.1f}% (very volatile)")
    breakdown["volatility_control"] = vol_ctrl_pts
    total += vol_ctrl_pts

    # C8. Drawdown Stability proxy ΓÇö 5 pts
    # We don't have 60-day history, so approximate via:
    #   distance from 200-EMA and BB width as stability proxies
    stab_pts = 0
    sma200 = indicators.get("SMA200")
    bb_upper = indicators.get("BB.upper")
    bb_lower = indicators.get("BB.lower")
    sma20 = indicators.get("SMA20")
    if sma200 and close and sma200 > 0:
        dist_200 = ((close - sma200) / sma200) * 100
        if 0 < dist_200 <= 20:
            stab_pts += 3  # Healthy distance above SMA200
        elif dist_200 > 40:
            stab_pts += 0  # Overextended
        elif dist_200 > 20:
            stab_pts += 1
    if bb_upper and bb_lower and sma20 and sma20 > 0:
        bbw = (bb_upper - bb_lower) / sma20
        if bbw < 0.08:
            stab_pts += 2  # Tight bands = stability
        elif bbw < 0.15:
            stab_pts += 1
    stab_pts = min(5, stab_pts)
    breakdown["drawdown_stability"] = stab_pts
    total += stab_pts

    # ΓöÇΓöÇ D. Fundamental Overlay ΓÇö 15 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    # TradingView doesn't provide EPS/revenue directly.
    # Use TradingView's built-in recommendation as a proxy for quality.

    rec_all = indicators.get("Recommend.All")
    rec_ma = indicators.get("Recommend.MA")
    rec_other = indicators.get("Recommend.Other")

    # D9. Growth Quality proxy (TV overall recommendation) ΓÇö 10 pts
    growth_pts = 0
    if rec_all is not None:
        if rec_all >= 0.5:
            growth_pts = 10
            signals.append("TV Strong Buy recommendation")
        elif rec_all >= 0.1:
            growth_pts = 7
        elif rec_all >= -0.1:
            growth_pts = 4
        else:
            growth_pts = 0
    breakdown["growth_quality"] = growth_pts
    total += growth_pts

    # D10. Profitability proxy (MA + Oscillator agreement) ΓÇö 5 pts
    prof_pts = 0
    if rec_ma is not None and rec_other is not None:
        if rec_ma > 0.1 and rec_other > 0.1:
            prof_pts = 5
        elif rec_ma > 0 or rec_other > 0:
            prof_pts = 3
        else:
            prof_pts = 0
    breakdown["profitability_quality"] = prof_pts
    total += prof_pts

    # ΓöÇΓöÇ Bonus / Penalty ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

    bonus = 0

    # Bonus: Volume surge with positive price = breakout candidate
    change_pct = ((close - open_price) / open_price) * 100
    if vol_ratio and vol_ratio >= 1.5 and change_pct > 2.0:
        bonus += 3
        signals.append("Breakout candidate (volume + price surge)")

    # Penalty: Price below EMA200
    if ema200 and close < ema200:
        bonus -= 10
        penalties.append("Price below EMA200 (-10)")

    # Penalty: RSI > 78 (extreme overbought)
    if rsi is not None and rsi > 78:
        bonus -= 5
        penalties.append(f"RSI {rsi:.0f} extreme overbought (-5)")

    # Penalty: Very low relative volume (today vs own average)
    if vol_ratio is not None and vol_ratio < 0.5:
        bonus -= 10
        penalties.append("Very low relative volume (-10)")

    # ΓöÇΓöÇ Liquidity Assessment ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    avg_vol = vol_sma20 if vol_sma20 and vol_sma20 > 0 else (volume if volume else None)
    avg_value_20d = (avg_vol * close) if avg_vol and close else None
    liquidity_ok = True       # passes hard gate for Strong/Elite
    liquidity_cap = None      # hard grade cap (None = no cap)
    liquidity_warnings = []

    # Layer 1: Absolute volume penalties
    if avg_vol is not None:
        if avg_vol < 10_000:
            bonus -= 20
            penalties.append(f"Extremely low volume {avg_vol:,.0f} shares/day (-20)")
            liquidity_ok = False
            liquidity_cap = "Avoid"
            liquidity_warnings.append("near-zero daily activity")
        elif avg_vol < 50_000:
            bonus -= 10
            penalties.append(f"Low volume {avg_vol:,.0f} shares/day (-10)")
            liquidity_ok = False
            liquidity_cap = "Watchlist"
            liquidity_warnings.append("thin daily volume")
        elif avg_vol < 100_000:
            bonus -= 5
            penalties.append(f"Below-average volume {avg_vol:,.0f} shares/day (-5)")

    # Layer 2: Traded value penalty (volume * price)
    # Catches stocks with high share count but low price, or vice versa
    # USD-denominated stocks use ~50x lower thresholds (1 USD Γëê 50 EGP)
    if currency.upper() == "USD":
        val_floor, val_low, val_modest = 2_000, 10_000, 20_000
    else:
        val_floor, val_low, val_modest = 100_000, 500_000, 1_000_000
    ccy = currency.upper()

    if avg_value_20d is not None:
        if avg_value_20d < val_floor:
            bonus -= 15
            penalties.append(f"Very low traded value {avg_value_20d:,.0f} {ccy}/day (-15)")
            liquidity_ok = False
            if liquidity_cap != "Avoid":
                liquidity_cap = "Avoid"
            liquidity_warnings.append("negligible monetary turnover")
        elif avg_value_20d < val_low:
            bonus -= 8
            penalties.append(f"Low traded value {avg_value_20d:,.0f} {ccy}/day (-8)")
            liquidity_ok = False
            if liquidity_cap is None:
                liquidity_cap = "Watchlist"
            liquidity_warnings.append("low monetary turnover")
        elif avg_value_20d < val_modest:
            bonus -= 3
            penalties.append(f"Modest traded value {avg_value_20d:,.0f} {ccy}/day (-3)")

    # Layer 3: Zero current volume ΓÇö today is dead
    if volume is not None and volume == 0:
        bonus -= 10
        penalties.append("Zero volume today ΓÇö no trading activity (-10)")
        liquidity_ok = False
        liquidity_cap = "Avoid"
        liquidity_warnings.append("zero trades today")

    # Penalty: ADX weak + bearish DI
    if adx is not None and adx < 15 and adx_plus and adx_minus and adx_minus > adx_plus:
        bonus -= 5
        penalties.append("Weak bearish trend structure (-5)")

    total = max(0, min(100, total + bonus))

    # ΓöÇΓöÇ Grade (with hard liquidity gate) ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    grade_order = ["Avoid", "Watchlist", "Strong", "Elite"]
    if total >= 85:
        grade = "Elite"
    elif total >= 70:
        grade = "Strong"
    elif total >= 55:
        grade = "Watchlist"
    else:
        grade = "Avoid"

    # Hard cap: illiquid stocks cannot be graded above their liquidity cap
    if liquidity_cap and grade_order.index(grade) > grade_order.index(liquidity_cap):
        original_grade = grade
        grade = liquidity_cap
        penalties.append(f"Grade capped {original_grade} ΓåÆ {grade} (insufficient liquidity)")

    # Trend state
    if ema20 and ema50 and ema200:
        if close > ema20 > ema50 > ema200:
            trend_state = "Strong Uptrend"
        elif close > ema50 > ema200:
            trend_state = "Uptrend"
        elif close > ema200:
            trend_state = "Weak Uptrend"
        elif close < ema20 < ema50 < ema200:
            trend_state = "Strong Downtrend"
        else:
            trend_state = "Transitioning"
    else:
        trend_state = "Unknown"

    return {
        "score": total,
        "grade": grade,
        "trend_state": trend_state,
        "change_pct": _safe_round(change_pct, 2),
        "breakdown": breakdown,
        "signals": signals,
        "penalties": penalties,
        "liquidity": {
            "avg_volume_20d": round(avg_vol) if avg_vol else 0,
            "avg_value_20d": round(avg_value_20d) if avg_value_20d else 0,
            "current_volume": round(volume) if volume else 0,
            "liquidity_ok": liquidity_ok,
            "warnings": liquidity_warnings,
        },
    }


# Keep old function as alias for backward compatibility
def compute_momentum_score(indicators: Dict) -> Optional[Dict]:
    """Legacy wrapper ΓÇö calls compute_stock_score without cross-sectional rank."""
    result = compute_stock_score(indicators)
    if result:
        result["momentum_grade"] = result.pop("grade", "")
        result["momentum_score"] = result.pop("score", 0)
    return result


# ---------------------------------------------------------------------------
# LAYER B ΓÇö Trade Setup Engine
# Answers: "How do I enter, target, and control risk?"
# ---------------------------------------------------------------------------

