"""Advanced risk controls for trade evaluation."""
from __future__ import annotations

from typing import Any, Dict, List, Optional


# ── Kelly Criterion ───────────────────────────────────────────────────────────

def kelly_position_size(
    win_rate: float,
    reward_risk_ratio: float,
    half_kelly: bool = True,
) -> float:
    """Return the Kelly fraction (0–1) for given win stats.

    Uses the formula: f = W - (1 - W) / R
    where W = win_rate, R = reward_risk_ratio.

    Applies half-Kelly by default and clips to [0, 1].
    """
    if reward_risk_ratio <= 0:
        return 0.0
    full_kelly = win_rate - (1.0 - win_rate) / reward_risk_ratio
    fraction = full_kelly / 2.0 if half_kelly else full_kelly
    return max(0.0, min(1.0, fraction))


# ── Stop-loss / Take-profit levels ────────────────────────────────────────────

def compute_trade_levels(
    entry_price: float,
    stop_loss_pct: float,
    take_profit_pct: float,
    side: str = "BUY",
) -> Dict[str, Any]:
    """Compute stop-loss and take-profit prices for a trade.

    Args:
        entry_price: The entry price of the trade.
        stop_loss_pct: Stop-loss as a percentage from entry (positive number).
        take_profit_pct: Take-profit as a percentage from entry (positive number).
        side: "BUY" (long) or "SELL" (short).

    Returns:
        dict with stop_loss, take_profit, risk_reward_ratio.
    """
    sl_mult = stop_loss_pct / 100.0
    tp_mult = take_profit_pct / 100.0

    if side.upper() == "BUY":
        stop_loss = round(entry_price * (1.0 - sl_mult), 4)
        take_profit = round(entry_price * (1.0 + tp_mult), 4)
    else:  # SELL / short
        stop_loss = round(entry_price * (1.0 + sl_mult), 4)
        take_profit = round(entry_price * (1.0 - tp_mult), 4)

    rr = round(take_profit_pct / stop_loss_pct, 2) if stop_loss_pct > 0 else 0.0

    return {
        "entry_price": entry_price,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "stop_loss_pct": stop_loss_pct,
        "take_profit_pct": take_profit_pct,
        "risk_reward_ratio": rr,
        "side": side.upper(),
    }


# ── Sector concentration ──────────────────────────────────────────────────────

def _get_symbol_sector(symbol: str, exchange: str = "NSE") -> str:
    """Look up sector for a symbol using exchange-specific data."""
    if exchange.upper() == "NSE":
        from tradingview_mcp.core.data.nse_sectors import get_sector
        return get_sector(symbol)
    if exchange.upper() in ("EGX", "EGYPT"):
        from tradingview_mcp.core.data.egx_sectors import get_sector
        return get_sector(symbol)
    return "other"


def check_sector_concentration(
    positions: List[Dict[str, Any]],
    new_symbol: str,
    new_value: float,
    exchange: str = "NSE",
    max_sector_pct: float = 0.40,
) -> Dict[str, Any]:
    """Check if adding a new position would breach sector concentration limits.

    Args:
        positions: List of existing positions with "symbol" and "value" keys.
        new_symbol: The symbol being added.
        new_value: The monetary value of the new position.
        exchange: Exchange code for sector lookup.
        max_sector_pct: Maximum allowed fraction for any single sector.

    Returns:
        dict with "allowed", "current_pct", "sector", and "reason".
    """
    new_sector = _get_symbol_sector(new_symbol, exchange)
    total_value = sum(p.get("value", 0.0) for p in positions) + new_value

    sector_value = new_value
    for pos in positions:
        if _get_symbol_sector(pos["symbol"], exchange) == new_sector:
            sector_value += pos.get("value", 0.0)

    current_pct = sector_value / total_value if total_value > 0 else 0.0
    allowed = current_pct <= max_sector_pct

    return {
        "allowed": allowed,
        "sector": new_sector,
        "current_pct": round(current_pct, 4),
        "max_sector_pct": max_sector_pct,
        "reason": (
            f"Sector '{new_sector}' would be {current_pct:.1%} of portfolio, "
            f"exceeding limit of {max_sector_pct:.1%}"
        ) if not allowed else "OK",
    }


# ── Leverage check ────────────────────────────────────────────────────────────

def check_leverage(
    portfolio_value: float,
    total_position_value: float,
    max_leverage: float = 2.0,
) -> Dict[str, Any]:
    """Check if total position value exceeds maximum leverage limit.

    Args:
        portfolio_value: Current net portfolio value (equity).
        total_position_value: Sum of all open position values.
        max_leverage: Maximum allowed leverage multiplier.

    Returns:
        dict with "allowed", "current_leverage", "max_leverage".
    """
    if portfolio_value <= 0:
        return {
            "allowed": False,
            "current_leverage": 0.0,
            "max_leverage": max_leverage,
            "reason": "Portfolio value must be positive",
        }

    current_leverage = total_position_value / portfolio_value
    allowed = current_leverage <= max_leverage

    return {
        "allowed": allowed,
        "current_leverage": round(current_leverage, 4),
        "max_leverage": max_leverage,
        "reason": (
            f"Leverage {current_leverage:.2f}x exceeds limit {max_leverage:.2f}x"
        ) if not allowed else "OK",
    }


# ── Full risk assessment ──────────────────────────────────────────────────────

def assess_trade_risk(
    user_id: str,
    symbol: str,
    side: str,
    quantity: float,
    entry_price: float,
    stop_loss_pct: float,
    take_profit_pct: float,
    exchange: str = "NSE",
    max_sector_pct: float = 0.40,
    max_leverage: float = 2.0,
    existing_positions: Optional[List[Dict[str, Any]]] = None,
    portfolio_value: Optional[float] = None,
) -> Dict[str, Any]:
    """Run all risk checks and return a combined assessment.

    Returns:
        dict with "approved", "checks" (list of individual results),
        "trade_levels", and "reason".
    """
    trade_value = quantity * entry_price
    positions = existing_positions or []
    pf_value = portfolio_value or (sum(p.get("value", 0) for p in positions) + 100_000)

    checks: List[Dict[str, Any]] = []

    # 1. Trade levels
    levels = compute_trade_levels(entry_price, stop_loss_pct, take_profit_pct, side)

    # 2. Sector concentration
    sector_check = check_sector_concentration(
        positions=positions,
        new_symbol=symbol,
        new_value=trade_value,
        exchange=exchange,
        max_sector_pct=max_sector_pct,
    )
    sector_check["check"] = "sector_concentration"
    checks.append(sector_check)

    # 3. Leverage
    total_pos_value = sum(p.get("value", 0) for p in positions) + trade_value
    leverage_check = check_leverage(
        portfolio_value=pf_value,
        total_position_value=total_pos_value,
        max_leverage=max_leverage,
    )
    leverage_check["check"] = "leverage"
    checks.append(leverage_check)

    approved = all(c.get("allowed", True) for c in checks)

    failed = [c for c in checks if not c.get("allowed", True)]
    reason = "; ".join(c.get("reason", "") for c in failed) if failed else "All checks passed"

    return {
        "approved": approved,
        "checks": checks,
        "trade_levels": levels,
        "user_id": user_id,
        "symbol": symbol,
        "reason": reason,
    }
