﻿from __future__ import annotations
from typing import Dict

from tradingview_mcp.core.services.indicators_metrics import _safe_round

def _extract_support_resistance(indicators: Dict, close) -> Dict:
    """Extract support and resistance levels from pivot points."""
    # Classic pivot points
    pivot = indicators.get("Pivot.M.Classic.Middle")
    r1 = indicators.get("Pivot.M.Classic.R1")
    r2 = indicators.get("Pivot.M.Classic.R2")
    r3 = indicators.get("Pivot.M.Classic.R3")
    s1 = indicators.get("Pivot.M.Classic.S1")
    s2 = indicators.get("Pivot.M.Classic.S2")
    s3 = indicators.get("Pivot.M.Classic.S3")

    levels = {
        "pivot": _safe_round(pivot, 4),
        "resistance_1": _safe_round(r1, 4),
        "resistance_2": _safe_round(r2, 4),
        "resistance_3": _safe_round(r3, 4),
        "support_1": _safe_round(s1, 4),
        "support_2": _safe_round(s2, 4),
        "support_3": _safe_round(s3, 4),
    }

    # Determine nearest support and resistance
    if close:
        resistance_levels = [(v, k) for k, v in levels.items()
                             if v is not None and "resistance" in k and v > close]
        support_levels = [(v, k) for k, v in levels.items()
                          if v is not None and "support" in k and v < close]

        if resistance_levels:
            nearest_r = min(resistance_levels, key=lambda x: x[0])
            levels["nearest_resistance"] = nearest_r[0]
            levels["distance_to_resistance_pct"] = _safe_round(
                ((nearest_r[0] - close) / close) * 100, 2
            )
        if support_levels:
            nearest_s = max(support_levels, key=lambda x: x[0])
            levels["nearest_support"] = nearest_s[0]
            levels["distance_to_support_pct"] = _safe_round(
                ((close - nearest_s[0]) / close) * 100, 2
            )

    return levels


def _detect_market_structure(indicators: Dict, close, open_price, high, low) -> Dict:
    """Detect market structure: trend direction, momentum alignment, candle characteristics."""
    ema20 = indicators.get("EMA20")
    ema50 = indicators.get("EMA50")
    ema200 = indicators.get("EMA200")
    rsi = indicators.get("RSI")
    adx = indicators.get("ADX")
    macd_line = indicators.get("MACD.macd")
    macd_signal = indicators.get("MACD.signal")

    # --- Trend Direction ---
    trend_score = 0  # -3 (strong bearish) to +3 (strong bullish)
    trend_signals = []

    if close and ema20:
        if close > ema20:
            trend_score += 1
        else:
            trend_score -= 1

    if close and ema50:
        if close > ema50:
            trend_score += 1
        else:
            trend_score -= 1

    if close and ema200:
        if close > ema200:
            trend_score += 1
            trend_signals.append("Above 200 EMA (bullish structure)")
        else:
            trend_score -= 1
            trend_signals.append("Below 200 EMA (bearish structure)")

    if trend_score >= 2:
        trend = "Bullish"
    elif trend_score <= -2:
        trend = "Bearish"
    else:
        trend = "Neutral/Ranging"

    # --- Momentum Alignment ---
    momentum_aligned = False
    if rsi is not None and macd_line is not None and macd_signal is not None:
        bullish_momentum = rsi > 50 and macd_line > macd_signal
        bearish_momentum = rsi < 50 and macd_line < macd_signal
        momentum_aligned = (trend == "Bullish" and bullish_momentum) or \
                           (trend == "Bearish" and bearish_momentum)

    # --- Candle Analysis ---
    candle = {}
    if all(v is not None for v in [open_price, close, high, low]) and high != low:
        body = abs(close - open_price)
        total_range = high - low
        body_ratio = body / total_range if total_range > 0 else 0

        candle["type"] = "Bullish" if close > open_price else "Bearish" if close < open_price else "Doji"
        candle["body_ratio"] = _safe_round(body_ratio, 2)
        candle["strength"] = "Strong" if body_ratio > 0.7 else "Moderate" if body_ratio > 0.4 else "Weak"

        # Upper/lower wick analysis
        if close >= open_price:
            upper_wick = high - close
            lower_wick = open_price - low
        else:
            upper_wick = high - open_price
            lower_wick = close - low
        candle["upper_wick_pct"] = _safe_round((upper_wick / total_range) * 100, 1) if total_range > 0 else 0
        candle["lower_wick_pct"] = _safe_round((lower_wick / total_range) * 100, 1) if total_range > 0 else 0

    # --- Trend Strength ---
    trend_strength = "Weak"
    if adx is not None:
        if adx > 40:
            trend_strength = "Very Strong"
        elif adx > 25:
            trend_strength = "Strong"
        elif adx > 20:
            trend_strength = "Moderate"

    return {
        "trend": trend,
        "trend_score": trend_score,
        "trend_strength": trend_strength,
        "momentum_aligned": momentum_aligned,
        "trend_signals": trend_signals,
        "candle": candle,
    }


def analyze_timeframe_context(indicators: Dict, timeframe: str) -> Dict:
    """Provide timeframe-specific analysis based on the trading strategy framework.

    Different timeframes serve different purposes:
    - 1W: Big picture trend, institutional direction
    - 1D: Swing trading setups (days to weeks)
    - 4h: Refinement within daily trend
    - 1h: Precise entry timing
    - 15m/5m: Execution and scalping
    """
    close = indicators.get("close")
    rsi = indicators.get("RSI")
    ema20 = indicators.get("EMA20")
    ema50 = indicators.get("EMA50")
    ema100 = indicators.get("EMA100")
    ema200 = indicators.get("EMA200")
    macd_line = indicators.get("MACD.macd")
    macd_signal = indicators.get("MACD.signal")
    adx = indicators.get("ADX")
    volume = indicators.get("volume")
    volume_sma20 = indicators.get("volume.SMA20")
    vwap = indicators.get("VWAP")

    # Determine bias
    bias = "Neutral"
    bias_reasons = []

    if timeframe in ("1W", "1M"):
        # Weekly: 200 EMA + 100 EMA for trend, MACD for momentum, RSI > 50 = bullish
        key_indicators = ["200 EMA", "100 EMA", "MACD", "RSI(14)"]
        if close and ema200:
            if close > ema200:
                bias = "Bullish"
                bias_reasons.append(f"Price ({_safe_round(close,2)}) above 200 EMA ({_safe_round(ema200,2)})")
            else:
                bias = "Bearish"
                bias_reasons.append(f"Price ({_safe_round(close,2)}) below 200 EMA ({_safe_round(ema200,2)})")
        if rsi is not None:
            if rsi > 50:
                bias_reasons.append(f"RSI {_safe_round(rsi,1)} above 50 (bullish bias)")
            else:
                bias_reasons.append(f"RSI {_safe_round(rsi,1)} below 50 (bearish bias)")
        if macd_line is not None and macd_signal is not None:
            if macd_line > macd_signal:
                bias_reasons.append("MACD bullish (momentum shift up)")
            else:
                bias_reasons.append("MACD bearish (momentum shift down)")
        advice = "Weekly sets your BIAS, not entries. Only look for buy setups in uptrends."

    elif timeframe == "1D":
        # Daily: 50 EMA + 200 EMA, RSI pullbacks (40-60 zone), Volume, MACD
        key_indicators = ["50 EMA", "200 EMA", "RSI(14)", "Volume", "MACD"]
        if close and ema50 and ema200:
            if ema50 > ema200:
                bias = "Bullish"
                bias_reasons.append("Golden Cross: EMA50 > EMA200")
            else:
                bias = "Bearish"
                bias_reasons.append("Death Cross: EMA50 < EMA200")
        if rsi is not None:
            if 40 <= rsi <= 60:
                bias_reasons.append(f"RSI {_safe_round(rsi,1)} in pullback zone (40-60) - good entry area")
            elif rsi > 70:
                bias_reasons.append(f"RSI {_safe_round(rsi,1)} overbought - avoid new longs")
            elif rsi < 30:
                bias_reasons.append(f"RSI {_safe_round(rsi,1)} oversold - potential bounce")
        if volume and volume_sma20 and volume_sma20 > 0:
            ratio = volume / volume_sma20
            if ratio >= 1.5:
                bias_reasons.append(f"Volume {ratio:.1f}x above average (breakout confirmation)")
        advice = "Trade pullbacks in trend (not extremes). Look for confluence: EMA + support + RSI."

    elif timeframe == "4h":
        # 4H: 20 EMA + 50 EMA, RSI, MACD, trendlines
        key_indicators = ["20 EMA", "50 EMA", "RSI(14)", "MACD"]
        if close and ema20 and ema50:
            if close > ema20 and ema20 > ema50:
                bias = "Bullish"
                bias_reasons.append("Price > EMA20 > EMA50 (bullish alignment)")
            elif close < ema20 and ema20 < ema50:
                bias = "Bearish"
                bias_reasons.append("Price < EMA20 < EMA50 (bearish alignment)")
            else:
                bias_reasons.append("EMAs not aligned - ranging/transitioning")
        if macd_line is not None and macd_signal is not None:
            if macd_line > macd_signal:
                bias_reasons.append("MACD bullish - early reversal signal")
            else:
                bias_reasons.append("MACD bearish - early reversal signal")
        advice = "Align with daily direction. Enter on pullbacks or breakouts."

    elif timeframe in ("1h", "60"):
        # 1H: 20 EMA dynamic S/R, RSI 9-14, Volume spikes, VWAP
        key_indicators = ["20 EMA", "RSI(9-14)", "Volume spikes", "VWAP"]
        if close and ema20:
            if close > ema20:
                bias = "Bullish"
                bias_reasons.append(f"Price above 20 EMA (dynamic support at {_safe_round(ema20,2)})")
            else:
                bias = "Bearish"
                bias_reasons.append(f"Price below 20 EMA (dynamic resistance at {_safe_round(ema20,2)})")
        if volume and volume_sma20 and volume_sma20 > 0:
            ratio = volume / volume_sma20
            if ratio >= 2.0:
                bias_reasons.append(f"Volume spike: {ratio:.1f}x (breakout confirmation)")
        if vwap is not None and close:
            if close > vwap:
                bias_reasons.append(f"Above VWAP ({_safe_round(vwap,2)}) - institutional bullish")
            else:
                bias_reasons.append(f"Below VWAP ({_safe_round(vwap,2)}) - institutional bearish")
        advice = "Look for trend continuation setups. Avoid trading against higher TF trend."

    else:
        # 15m/5m: VWAP, 20 EMA + 9 EMA, RSI 7-9, Volume
        key_indicators = ["VWAP", "9 EMA", "20 EMA", "RSI(7-9)", "Volume"]
        ema9 = indicators.get("EMA9")
        if close and ema9 and ema20:
            if ema9 > ema20:
                bias = "Bullish"
                bias_reasons.append("Fast EMA9 > EMA20 (short-term bullish)")
            else:
                bias = "Bearish"
                bias_reasons.append("Fast EMA9 < EMA20 (short-term bearish)")
        if vwap is not None and close:
            if close > vwap:
                bias_reasons.append(f"Above VWAP ({_safe_round(vwap,2)}) - institutional level bullish")
            else:
                bias_reasons.append(f"Below VWAP ({_safe_round(vwap,2)}) - institutional level bearish")
        advice = "Only enter when aligned with 1H & 4H. Use tight stop losses."

    return {
        "timeframe": timeframe,
        "bias": bias,
        "bias_reasons": bias_reasons,
        "key_indicators_for_timeframe": key_indicators,
        "advice": advice,
    }


# ---------------------------------------------------------------------------
# LAYER A ΓÇö Stock Quality & Momentum Score (100 pts)
# Answers: "Which stocks deserve attention?"
# ---------------------------------------------------------------------------

