from __future__ import annotations

import time
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# tradingview_ta uses lowercase intervals; map our app-level strings to valid ones.
_INTERVAL_MAP: Dict[str, str] = {
    "1D": "1d",
    "1W": "1W",
    "1M": "1M",
}


class IDataSource(ABC):
    @abstractmethod
    def fetch_analysis(self, screener: str, timeframe: str, symbols: List[str]) -> Dict[str, Any]:
        """Fetch technical analysis for symbols at a given timeframe."""


class TradingViewDataSource(IDataSource):
    """Wraps tradingview_ta.get_multiple_analysis with retry logic for 429s.

    TradingView rate-limits bulk requests.  On a 429 (empty response body
    causes a JSONDecodeError) we retry up to *max_retries* times with
    exponential backoff, then return an empty dict instead of crashing so
    callers can degrade gracefully (e.g. bollinger_scan returns [] rather
    than raising RuntimeError).
    """

    def __init__(self, max_retries: int = 3, base_delay: float = 2.0) -> None:
        self._max_retries = max_retries
        self._base_delay = base_delay

    def fetch_analysis(self, screener: str, timeframe: str, symbols: List[str]) -> Dict[str, Any]:
        try:
            from tradingview_ta import get_multiple_analysis
        except ImportError as exc:
            raise RuntimeError("tradingview_ta is missing; run `uv sync`.") from exc

        # Normalise timeframe to the string tradingview_ta accepts
        interval = _INTERVAL_MAP.get(timeframe, timeframe)

        last_exc: Exception | None = None
        for attempt in range(1, self._max_retries + 1):
            try:
                result = get_multiple_analysis(
                    screener=screener, interval=interval, symbols=symbols
                )
                return result or {}
            except Exception as exc:
                last_exc = exc
                err_str = str(exc).lower()
                # Empty body = likely 429 rate-limit; retry with backoff
                if "expecting value" in err_str or "json" in err_str:
                    delay = self._base_delay * (2 ** (attempt - 1))
                    logger.warning(
                        "TradingView TA rate-limited (attempt %d/%d). "
                        "Retrying in %.1fs…",
                        attempt, self._max_retries, delay,
                    )
                    time.sleep(delay)
                    continue
                # Non-rate-limit error — fail immediately
                raise RuntimeError(f"Analysis failed: {exc}") from exc

        # All retries exhausted — return empty dict so callers can degrade gracefully
        logger.error(
            "TradingView TA returned empty response after %d retries (%s). "
            "Returning empty result.",
            self._max_retries, last_exc,
        )
        return {}
