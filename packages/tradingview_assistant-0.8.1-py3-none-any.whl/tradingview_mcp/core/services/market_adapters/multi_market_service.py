from __future__ import annotations

from typing import Dict

from .base import IMarketAdapter


class MultiMarketService:
    def __init__(self) -> None:
        self._adapters: Dict[str, IMarketAdapter] = {}

    def register_market(self, market: str, adapter: IMarketAdapter) -> None:
        self._adapters[market.strip().lower()] = adapter

    def get_adapter(self, market: str) -> IMarketAdapter | None:
        return self._adapters.get(market.strip().lower())

    def run_sector_scanner(
        self,
        market: str,
        timeframe: str = "1D",
        top_n_sectors: int = 5,
        top_n_stocks: int = 3,
        min_stock_score: int = 60,
    ) -> dict:
        adapter = self.get_adapter(market)
        if adapter is None:
            return {
                "error": f"Unknown market: {market}",
                "available_markets": sorted(self._adapters.keys()),
            }

        return adapter.run_sector_scanner(
            timeframe=timeframe,
            top_n_sectors=top_n_sectors,
            top_n_stocks=top_n_stocks,
            min_stock_score=min_stock_score,
        )


def build_default_multi_market_service() -> MultiMarketService:
    from .egx_adapter import EGXAdapter
    from .nse_adapter import NSEAdapter

    svc = MultiMarketService()
    svc.register_market("egx", EGXAdapter())
    svc.register_market("nse", NSEAdapter())
    return svc
