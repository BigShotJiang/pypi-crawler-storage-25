from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List, Tuple


class IMarketAdapter(ABC):
    @abstractmethod
    def get_sectors(self) -> Dict[str, List[str]]:
        """Return sector->symbols mapping for the market."""

    @abstractmethod
    def get_trading_hours(self) -> Tuple[str, str]:
        """Return market trading hours as (start, end)."""

    @abstractmethod
    def get_timezone(self) -> str:
        """Return IANA timezone name for market hours."""

    @abstractmethod
    def get_currency(self) -> str:
        """Return market base currency (e.g., EGP, INR)."""

    @abstractmethod
    def validate_symbol(self, symbol: str) -> bool:
        """Validate symbol formatting for this market."""

    @abstractmethod
    def compute_stock_score(self, symbol: str, indicators: Dict) -> float:
        """Compute a market-aware stock score (0-100)."""

    @abstractmethod
    def run_sector_scanner(
        self,
        timeframe: str = "1D",
        top_n_sectors: int = 5,
        top_n_stocks: int = 3,
        min_stock_score: int = 60,
    ) -> dict:
        """Run market-specific sector rotation scanner."""
