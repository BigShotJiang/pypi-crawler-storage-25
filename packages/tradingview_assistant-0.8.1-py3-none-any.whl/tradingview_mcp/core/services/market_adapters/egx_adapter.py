from __future__ import annotations

import re
from typing import Dict, List

from tradingview_mcp.core.data.egx_sectors import EGX_SECTORS
from tradingview_mcp.core.services.indicators import compute_stock_score as _compute_stock_score

from .base import IMarketAdapter


_EGX_SYMBOL_RE = re.compile(r"^(?:EGX:)?[A-Z0-9]{3,6}$")


class EGXAdapter(IMarketAdapter):
    def get_sectors(self) -> Dict[str, List[str]]:
        return {k: [f"EGX:{s}" for s in sorted(v)] for k, v in EGX_SECTORS.items()}

    def get_trading_hours(self) -> tuple[str, str]:
        return ("10:00", "14:30")

    def get_timezone(self) -> str:
        return "Africa/Cairo"

    def get_currency(self) -> str:
        return "EGP"

    def validate_symbol(self, symbol: str) -> bool:
        return bool(_EGX_SYMBOL_RE.match(symbol.strip().upper()))

    def compute_stock_score(self, symbol: str, indicators: Dict) -> float:
        try:
            result = _compute_stock_score(indicators, change_pct_rank=0.5, currency=self.get_currency())
            if not result:
                return 0.0
            return float(result.get("score", 0.0))
        except Exception:
            return 0.0

    def run_sector_scanner(
        self,
        timeframe: str = "1D",
        top_n_sectors: int = 5,
        top_n_stocks: int = 3,
        min_stock_score: int = 60,
    ) -> dict:
        # Lazy import avoids circular dependency between service and adapters.
        from tradingview_mcp.core.services.egx_service import _run_egx_sector_scanner_impl

        return _run_egx_sector_scanner_impl(
            timeframe=timeframe,
            top_n_sectors=top_n_sectors,
            top_n_stocks=top_n_stocks,
            min_stock_score=min_stock_score,
        )
