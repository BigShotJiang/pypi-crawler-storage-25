from __future__ import annotations

import copy
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List

from .base import IMarketAdapter
from tradingview_mcp.core.config import get_config
from tradingview_mcp.core.data.nse_sectors import NSE_SECTORS as _NSE_SECTORS_DATA
from tradingview_mcp.core.services.data_source import IDataSource, TradingViewDataSource

# NSE symbol pattern: optional NSE: prefix, 1-20 alphanumeric/& chars, optional suffix like -EQ or -AUTO
_NSE_SYMBOL_RE = re.compile(r"^(?:NSE:)?[A-Z0-9&]{1,20}(?:-[A-Z0-9]{2,6})?$")
# Explicit foreign exchange prefixes we reject
_FOREIGN_EXCHANGE_RE = re.compile(r"^(?!NSE:)[A-Z]{2,6}:[A-Z]")

_CACHE_LOCK = threading.Lock()
_NSE_SCANNER_CACHE: dict[tuple, dict] = {}
_NSE_SCANNER_CACHE_STATS = {"hits": 0, "misses": 0, "expired": 0}


def _reset_nse_scanner_cache_for_tests() -> None:
    """Test helper to reset cache and stats to deterministic state."""
    with _CACHE_LOCK:
        _NSE_SCANNER_CACHE.clear()
        _NSE_SCANNER_CACHE_STATS["hits"] = 0
        _NSE_SCANNER_CACHE_STATS["misses"] = 0
        _NSE_SCANNER_CACHE_STATS["expired"] = 0


class NSEAdapter(IMarketAdapter):
    def __init__(self, data_source: IDataSource | None = None) -> None:
        self._data_source = data_source or TradingViewDataSource()

    def get_sectors(self) -> Dict[str, List[str]]:
        return {k: list(v) for k, v in _NSE_SECTORS_DATA.items()}

    def get_trading_hours(self) -> tuple[str, str]:
        return ("09:15", "15:30")

    def get_timezone(self) -> str:
        return "Asia/Kolkata"

    def get_currency(self) -> str:
        return "INR"

    def validate_symbol(self, symbol: str) -> bool:
        clean = symbol.strip().upper()
        # Reject symbols with a non-NSE exchange prefix (e.g. EGX:COMI, BINANCE:BTCUSDT)
        if _FOREIGN_EXCHANGE_RE.match(clean):
            return False
        return bool(_NSE_SYMBOL_RE.match(clean))

    def compute_stock_score(self, symbol: str, indicators: Dict) -> float:
        # Momentum-heavy profile for NSE (Phase 0 baseline).
        momentum = float(indicators.get("momentum", 0.0) or 0.0)
        rsi_score = float(indicators.get("rsi_score", 0.0) or 0.0)
        adx_score = float(indicators.get("adx_score", 0.0) or 0.0)
        score = momentum * 0.50 + rsi_score * 0.25 + adx_score * 0.25
        return max(0.0, min(100.0, score))

    def run_sector_scanner(
        self,
        timeframe: str = "1D",
        top_n_sectors: int = 5,
        top_n_stocks: int = 3,
        min_stock_score: int = 60,
    ) -> dict:
        sectors = self.get_sectors()
        if not sectors:
            return {"error": "No NSE sectors configured", "market": "nse", "timeframe": timeframe}

        top_n_sectors = max(1, int(top_n_sectors))
        top_n_stocks = max(1, int(top_n_stocks))
        min_stock_score = max(0, min(100, int(min_stock_score)))

        all_symbols: List[str] = []
        for symbols in sectors.values():
            all_symbols.extend(symbols)
        unique_symbols = list(dict.fromkeys(all_symbols))

        cfg = get_config()
        batch_size = max(1, int(cfg.performance.screener_batch_size))
        max_workers = max(1, int(cfg.performance.nse_scanner_max_workers))
        cache_ttl = max(1, int(cfg.performance.nse_scanner_cache_ttl))
        screener = "india"

        cache_key = (
            timeframe,
            top_n_sectors,
            top_n_stocks,
            min_stock_score,
            batch_size,
            len(unique_symbols),
        )
        now = time.time()

        with _CACHE_LOCK:
            cached = _NSE_SCANNER_CACHE.get(cache_key)
            if cached is not None:
                age = now - float(cached.get("timestamp", 0.0))
                if age <= cache_ttl:
                    _NSE_SCANNER_CACHE_STATS["hits"] += 1
                    payload = copy.deepcopy(cached["result"])
                    payload["cache"] = {
                        "hit": True,
                        "age_seconds": round(age, 3),
                        "ttl_seconds": cache_ttl,
                        "stats": dict(_NSE_SCANNER_CACHE_STATS),
                    }
                    return payload
                _NSE_SCANNER_CACHE_STATS["expired"] += 1
                del _NSE_SCANNER_CACHE[cache_key]

            _NSE_SCANNER_CACHE_STATS["misses"] += 1

        analysis_map: Dict[str, object] = {}
        batches = [
            unique_symbols[i : i + batch_size]
            for i in range(0, len(unique_symbols), batch_size)
        ]

        with ThreadPoolExecutor(max_workers=min(max_workers, len(batches) or 1)) as executor:
            future_map = {
                executor.submit(
                    self._data_source.fetch_analysis,
                    screener,
                    timeframe,
                    batch,
                ): batch
                for batch in batches
            }
            for future in as_completed(future_map):
                analysis = future.result() or {}
                for symbol, data in analysis.items():
                    if data is not None:
                        analysis_map[symbol] = data

        if not analysis_map:
            result = {
                "market": "nse",
                "timeframe": timeframe,
                "status": "no_data",
                "coverage": {
                    "total_symbols": len(unique_symbols),
                    "analyzed_symbols": 0,
                    "coverage_pct": 0.0,
                },
                "sector_heatmap": [],
                "top_sectors": [],
                "top_picks": [],
                "cache": {
                    "hit": False,
                    "age_seconds": None,
                    "ttl_seconds": cache_ttl,
                    "stats": dict(_NSE_SCANNER_CACHE_STATS),
                },
            }
            with _CACHE_LOCK:
                _NSE_SCANNER_CACHE[cache_key] = {
                    "timestamp": now,
                    "result": copy.deepcopy(result),
                }
            return result

        def _safe_change_pct(indicators: dict) -> float:
            open_price = indicators.get("open")
            close_price = indicators.get("close")
            if open_price in (None, 0) or close_price is None:
                return 0.0
            try:
                return ((float(close_price) - float(open_price)) / float(open_price)) * 100.0
            except (TypeError, ValueError, ZeroDivisionError):
                return 0.0

        def _rsi_score(rsi_value: float | None) -> float:
            if rsi_value is None:
                return 50.0
            if 55 <= rsi_value <= 70:
                return 100.0
            if 50 <= rsi_value < 55 or 70 < rsi_value <= 75:
                return 80.0
            if 45 <= rsi_value < 50 or 75 < rsi_value <= 80:
                return 60.0
            if 40 <= rsi_value < 45 or 80 < rsi_value <= 85:
                return 40.0
            return 20.0

        def _build_sector_row(sector: str, symbols: List[str]) -> tuple[dict | None, List[dict]]:
            rows: List[dict] = []
            for symbol in symbols:
                data = analysis_map.get(symbol)
                if data is None:
                    continue
                indicators = getattr(data, "indicators", None)
                if not isinstance(indicators, dict):
                    continue

                rec = indicators.get("Recommend.All")
                adx = indicators.get("ADX")
                rsi = indicators.get("RSI")

                try:
                    rec_val = float(rec) if rec is not None else 0.0
                except (TypeError, ValueError):
                    rec_val = 0.0
                momentum = max(0.0, min(100.0, (rec_val + 1.0) * 50.0))

                try:
                    adx_val = float(adx) if adx is not None else 0.0
                except (TypeError, ValueError):
                    adx_val = 0.0
                adx_score = max(0.0, min(100.0, adx_val * 4.0))

                try:
                    rsi_val = float(rsi) if rsi is not None else None
                except (TypeError, ValueError):
                    rsi_val = None

                score = self.compute_stock_score(
                    symbol,
                    {
                        "momentum": momentum,
                        "rsi_score": _rsi_score(rsi_val),
                        "adx_score": adx_score,
                    },
                )

                rows.append(
                    {
                        "symbol": symbol,
                        "score": round(score, 2),
                        "change_pct": round(_safe_change_pct(indicators), 2),
                        "price": indicators.get("close"),
                        "rsi": rsi_val,
                        "recommend_all": rec_val,
                    }
                )

            if not rows:
                return None, []

            avg_score = round(sum(r["score"] for r in rows) / len(rows), 2)
            avg_change = round(sum(r["change_pct"] for r in rows) / len(rows), 2)

            if avg_score >= 70:
                status = "Hot"
            elif avg_score >= 55:
                status = "Warm"
            elif avg_score >= 45:
                status = "Neutral"
            else:
                status = "Cold"

            qualified = [r for r in rows if r["score"] >= min_stock_score]
            qualified.sort(key=lambda x: (x["score"], x["change_pct"]), reverse=True)
            top_rows = qualified[:top_n_stocks]

            sector_row = {
                "sector": sector,
                "status": status,
                "avg_score": avg_score,
                "avg_change_pct": avg_change,
                "covered_symbols": len(rows),
                "total_symbols": len(symbols),
                "top_stocks": top_rows,
            }
            picks = [{"sector": sector, **stock} for stock in top_rows]
            return sector_row, picks

        sector_rows: List[dict] = []
        all_top_picks: List[dict] = []

        with ThreadPoolExecutor(max_workers=min(max_workers, len(sectors) or 1)) as executor:
            futures = {
                executor.submit(_build_sector_row, sector, symbols): sector
                for sector, symbols in sectors.items()
            }
            for future in as_completed(futures):
                sector_row, picks = future.result()
                if sector_row is None:
                    continue
                sector_rows.append(sector_row)
                all_top_picks.extend(picks)

        sector_rows.sort(key=lambda x: (x["avg_score"], x["avg_change_pct"]), reverse=True)
        all_top_picks.sort(key=lambda x: (x["score"], x["change_pct"]), reverse=True)

        analyzed_symbols = len(analysis_map)
        coverage_pct = round((analyzed_symbols / len(unique_symbols)) * 100.0, 1) if unique_symbols else 0.0

        result = {
            "market": "nse",
            "timeframe": timeframe,
            "currency": self.get_currency(),
            "timezone": self.get_timezone(),
            "trading_hours": f"{self.get_trading_hours()[0]}-{self.get_trading_hours()[1]}",
            "top_n_sectors": top_n_sectors,
            "top_n_stocks": top_n_stocks,
            "min_stock_score": min_stock_score,
            "status": "ok" if sector_rows else "no_data",
            "coverage": {
                "total_symbols": len(unique_symbols),
                "analyzed_symbols": analyzed_symbols,
                "coverage_pct": coverage_pct,
            },
            "cache": {
                "hit": False,
                "age_seconds": None,
                "ttl_seconds": cache_ttl,
                "stats": dict(_NSE_SCANNER_CACHE_STATS),
            },
            "sector_heatmap": sector_rows,
            "top_sectors": sector_rows[:top_n_sectors],
            "top_picks": all_top_picks[: top_n_sectors * top_n_stocks],
        }

        with _CACHE_LOCK:
            _NSE_SCANNER_CACHE[cache_key] = {
                "timestamp": now,
                "result": copy.deepcopy(result),
            }

        return result
