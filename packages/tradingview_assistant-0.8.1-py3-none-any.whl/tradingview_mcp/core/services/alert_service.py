from __future__ import annotations

import os
import sqlite3
from typing import Any

DB_DIR = os.path.expanduser("~/.tradingview_mcp_data")
DB_PATH = os.path.join(DB_DIR, "alerts.db")


def init_db() -> None:
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS alert_preferences (
            user_id TEXT PRIMARY KEY,
            channel TEXT NOT NULL,
            destination TEXT NOT NULL,
            min_confidence REAL NOT NULL DEFAULT 0,
            enabled INTEGER NOT NULL DEFAULT 1,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS alert_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            confidence REAL NOT NULL,
            delivered INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


def set_alert_preferences(
    user_id: str,
    channel: str,
    destination: str,
    min_confidence: float = 0.0,
    enabled: bool = True,
) -> dict[str, Any]:
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO alert_preferences (user_id, channel, destination, min_confidence, enabled)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            channel = excluded.channel,
            destination = excluded.destination,
            min_confidence = excluded.min_confidence,
            enabled = excluded.enabled,
            updated_at = CURRENT_TIMESTAMP
        """,
        (user_id, channel, destination, float(min_confidence), 1 if enabled else 0),
    )
    conn.commit()
    conn.close()
    return {"status": "saved", "user_id": user_id}


def get_alert_preferences(user_id: str) -> dict[str, Any] | None:
    init_db()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT user_id, channel, destination, min_confidence, enabled
        FROM alert_preferences
        WHERE user_id = ?
        """,
        (user_id,),
    )
    row = cursor.fetchone()
    conn.close()
    if row is None:
        return None

    item = dict(row)
    item["enabled"] = bool(item.get("enabled"))
    return item


def dispatch_alert(
    user_id: str,
    title: str,
    message: str,
    confidence: float,
) -> dict[str, Any]:
    init_db()
    pref = get_alert_preferences(user_id)
    delivered = False

    if pref and pref.get("enabled"):
        threshold = float(pref.get("min_confidence", 0.0))
        delivered = float(confidence) >= threshold

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO alert_events (user_id, title, message, confidence, delivered)
        VALUES (?, ?, ?, ?, ?)
        """,
        (user_id, title, message, float(confidence), 1 if delivered else 0),
    )
    conn.commit()
    conn.close()

    return {"status": "ok", "delivered": delivered}
