"""
Yahoo Finance Price Service via Webshare Rotating Proxy.

Provides real-time quotes for stocks, ETFs, crypto pairs, indices
using the Yahoo Finance Chart API (no API key required).

Works with any symbol Yahoo Finance supports:
  Stocks:  AAPL, TSLA, MSFT, NVDA, GOOGL
  Crypto:  BTC-USD, ETH-USD, SOL-USD, BNB-USD
  ETFs:    SPY, QQQ, VTI
  Indices: ^GSPC (S&P500), ^DJI (Dow), ^IXIC (NASDAQ)
  FX:      EURUSD=X, GBPUSD=X
  Turkish: THYAO.IS, SASA.IS
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

from tradingview_mcp.core.services import http_client
from tradingview_mcp.core.utils.error_contract import build_response, error_item

_USER_AGENT = "tradingview-mcp/0.5.0"
_YAHOO_FINANCE_BASE_URL = "https://query1.finance.yahoo.com/v8/finance/chart"


def _fetch_quote(symbol: str) -> dict:
    """Fetch raw Yahoo Finance chart result for a symbol (meta + indicators)."""
    url = f"{_YAHOO_FINANCE_BASE_URL}/{symbol}?interval=1d&range=2d"
    data = http_client.get_json(url)
    return data["chart"]["result"][0]  # type: ignore[index]


def _get_previous_close(chart_result: dict) -> Optional[float]:
    """Extract previous trading day's close from candle data.

    The meta fields 'previousClose' and 'chartPreviousClose' are unreliable:
    - 'previousClose' is often None
    - 'chartPreviousClose' returns the chart range start price, not yesterday's close

    Instead, we use the actual close prices from the 2-day candle data.
    With range=2d, indicators.quote[0].close gives [prev_day_close, today_close].
    """
    try:
        closes = chart_result.get("indicators", {}).get("quote", [{}])[0].get("close", [])
        # Filter out None values (can happen for incomplete candles)
        valid_closes = [c for c in closes if c is not None]
        if len(valid_closes) >= 2:
            return valid_closes[-2]
    except (IndexError, TypeError, KeyError):
        pass
    # Fallback to meta fields if candle data unavailable
    meta = chart_result.get("meta", {})
    return meta.get("previousClose") or meta.get("chartPreviousClose")


def get_price(symbol: str) -> dict:
    """
    Get real-time price data for any Yahoo Finance symbol.

    Args:
        symbol: Yahoo Finance symbol (e.g. "AAPL", "BTC-USD", "THYAO.IS", "^GSPC")

    Returns:
        dict with price, change, change_pct, currency, exchange, market_state
    """
    try:
        chart_result = _fetch_quote(symbol)
        meta = chart_result.get("meta", {})
        price      = meta.get("regularMarketPrice")
        prev_close = _get_previous_close(chart_result) or price
        chg        = round(price - prev_close, 4) if (price and prev_close) else None
        chg_pct    = round((price - prev_close) / prev_close * 100, 2) if (price and prev_close and prev_close != 0) else None

        return {
            "symbol":        symbol.upper(),
            "price":         price,
            "previous_close": prev_close,
            "change":        chg,
            "change_pct":    chg_pct,
            "currency":      meta.get("currency", "USD"),
            "exchange":      meta.get("exchangeName", ""),
            "market_state":  meta.get("marketState", ""),  # REGULAR, PRE, POST, CLOSED
            "52w_high":      meta.get("fiftyTwoWeekHigh"),
            "52w_low":       meta.get("fiftyTwoWeekLow"),
            "source":        "Yahoo Finance",
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        return {"symbol": symbol.upper(), "error": str(e), "source": "Yahoo Finance"}


def get_prices_bulk(symbols: list[str]) -> list[dict]:
    """
    Get prices for multiple symbols at once.

    Args:
        symbols: List of Yahoo Finance symbols

    Returns:
        List of price dicts
    """
    if not symbols:
        return []
    with ThreadPoolExecutor(max_workers=min(10, len(symbols))) as executor:
        futures = {executor.submit(get_price, sym): sym for sym in symbols}
        results = [None] * len(symbols)
        sym_index = {sym: i for i, sym in enumerate(symbols)}
        for future in as_completed(futures):
            sym = futures[future]
            results[sym_index[sym]] = future.result()
    return results


def get_market_snapshot() -> dict:
    """
    Get a snapshot of major market indices and crypto prices.

    Returns:
        Dict with stocks (S&P500, NASDAQ, Dow), crypto (BTC, ETH), and FX
    """
    groups = {
        "indices": ["^GSPC", "^DJI", "^IXIC", "^VIX"],
        "crypto":  ["BTC-USD", "ETH-USD", "SOL-USD", "BNB-USD"],
        "fx":      ["EURUSD=X", "GBPUSD=X", "JPYUSD=X"],
        "etfs":    ["SPY", "QQQ", "GLD"],
    }

    result = {}
    all_syms = [(group, sym) for group, syms in groups.items() for sym in syms]
    total_sources = len(all_syms)
    source_failures: list[dict] = []
    errors: list[dict] = []

    with ThreadPoolExecutor(max_workers=min(10, len(all_syms))) as executor:
        futures = {executor.submit(get_price, sym): (group, sym) for group, sym in all_syms}
        group_results: dict[str, list] = {g: [] for g in groups}
        for future in as_completed(futures):
            group, sym = futures[future]
            try:
                data = future.result()
            except Exception as exc:
                source_failures.append({"source": "yahoo_finance", "symbol": sym, "error": str(exc)})
                errors.append(error_item(code="upstream_error", message=str(exc), source=sym))
                continue

            if "error" in data:
                source_failures.append(
                    {
                        "source": "yahoo_finance",
                        "symbol": sym,
                        "error": str(data.get("error", "unknown upstream error")),
                    }
                )
                errors.append(
                    error_item(
                        code="upstream_error",
                        message=str(data.get("error", "unknown upstream error")),
                        source=sym,
                    )
                )
                continue

            group_results[group].append({
                "symbol":     data["symbol"],
                "price":      data.get("price"),
                "change_pct": data.get("change_pct"),
                "currency":   data.get("currency", "USD"),
            })

    for group in groups:
        result[group] = group_results[group]

    result["timestamp"] = datetime.now(timezone.utc).isoformat()

    failed_sources = len(source_failures)
    coverage_pct = 100.0 if total_sources == 0 else ((total_sources - failed_sources) / total_sources) * 100.0
    status = "success" if failed_sources == 0 else "partial"

    return build_response(
        status=status,
        data=result,
        errors=errors,
        coverage_pct=coverage_pct,
        source_failures=source_failures,
    )
