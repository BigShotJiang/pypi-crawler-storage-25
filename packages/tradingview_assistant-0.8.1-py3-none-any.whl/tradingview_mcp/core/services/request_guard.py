from __future__ import annotations

import json
import math
import threading
import time
from dataclasses import dataclass
from typing import Any

from starlette.responses import JSONResponse
from starlette.types import Message, Receive, Scope, Send

from tradingview_mcp.core.config import get_config


@dataclass
class RateLimitDecision:
    allowed: bool
    retry_after_seconds: int
    quota_remaining: int


@dataclass
class _Bucket:
    tokens: float
    updated_at: float


class SessionTokenBucketLimiter:
    """Per-user, per-endpoint token bucket limiter."""

    def __init__(self, burst: int, refill_per_second: float):
        self._burst = max(1, int(burst))
        self._refill_per_second = max(0.01, float(refill_per_second))
        self._lock = threading.Lock()
        self._buckets: dict[tuple[str, str], _Bucket] = {}
        self._throttled_requests_total = 0

    def _refill(self, bucket: _Bucket, now: float) -> None:
        elapsed = max(0.0, now - bucket.updated_at)
        bucket.tokens = min(self._burst, bucket.tokens + (elapsed * self._refill_per_second))
        bucket.updated_at = now

    def consume(self, user_id: str, endpoint: str, now: float | None = None) -> RateLimitDecision:
        now_ts = time.monotonic() if now is None else now
        key = (user_id, endpoint)
        with self._lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = _Bucket(tokens=float(self._burst), updated_at=now_ts)
                self._buckets[key] = bucket

            self._refill(bucket, now_ts)
            if bucket.tokens >= 1.0:
                bucket.tokens -= 1.0
                return RateLimitDecision(
                    allowed=True,
                    retry_after_seconds=0,
                    quota_remaining=max(0, int(math.floor(bucket.tokens))),
                )

            self._throttled_requests_total += 1
            missing = 1.0 - bucket.tokens
            retry_after = int(math.ceil(missing / self._refill_per_second))
            return RateLimitDecision(allowed=False, retry_after_seconds=max(1, retry_after), quota_remaining=0)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "throttled_requests_total": self._throttled_requests_total,
                "active_quota_buckets": len(self._buckets),
                "quota_remaining": {
                    f"{u}|{e}": max(0, int(math.floor(b.tokens))) for (u, e), b in self._buckets.items()
                },
            }


def _decode_jsonrpc_method_and_tool(body: bytes) -> tuple[str | None, str | None]:
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, TypeError):
        return None, None

    if not isinstance(payload, dict):
        return None, None

    method = payload.get("method")
    if not isinstance(method, str):
        return None, None

    tool_name = None
    if method == "tools/call":
        params = payload.get("params")
        if isinstance(params, dict):
            maybe_name = params.get("name")
            if isinstance(maybe_name, str):
                tool_name = maybe_name

    return method, tool_name


def _endpoint_label(method: str | None, tool_name: str | None) -> str:
    if not method:
        return "unknown"
    if method == "tools/call" and tool_name:
        return f"tools/call:{tool_name}"
    return method


class SessionAuthRateLimitMiddleware:
    """Authenticate by MCP session ID and apply per-user quotas."""

    def __init__(self, app, limiter: SessionTokenBucketLimiter):
        self.app = app
        self.limiter = limiter

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "GET").upper()
        if method != "POST":
            await self.app(scope, receive, send)
            return

        body_events: list[Message] = []
        chunks: list[bytes] = []
        more_body = True
        while more_body:
            event = await receive()
            body_events.append(event)
            if event.get("type") == "http.request":
                chunks.append(event.get("body", b""))
                more_body = bool(event.get("more_body", False))
            else:
                more_body = False

        body = b"".join(chunks)
        rpc_method, rpc_tool = _decode_jsonrpc_method_and_tool(body)

        headers = {
            k.decode("latin1").lower(): v.decode("latin1") for k, v in scope.get("headers", [])
        }
        session_id = headers.get("mcp-session-id", "").strip()

        # MCP bootstrap request: initialize creates server-side session ID.
        if not session_id and rpc_method != "initialize":
            response = JSONResponse(
                {
                    "error": "Authentication required",
                    "message": "Missing mcp-session-id header. Call initialize first.",
                },
                status_code=401,
            )
            await response(scope, receive, send)
            return

        extra_headers: list[tuple[bytes, bytes]] = []
        if session_id:
            endpoint = _endpoint_label(rpc_method, rpc_tool)
            decision = self.limiter.consume(user_id=session_id, endpoint=endpoint)
            extra_headers.append((b"x-quota-remaining", str(decision.quota_remaining).encode("ascii")))

            if not decision.allowed:
                response = JSONResponse(
                    {
                        "error": "Too Many Requests",
                        "message": "Per-user quota exceeded",
                        "retry_after": decision.retry_after_seconds,
                    },
                    status_code=429,
                    headers={
                        "Retry-After": str(decision.retry_after_seconds),
                        "X-Quota-Remaining": "0",
                    },
                )
                await response(scope, receive, send)
                return

        async def replay_receive() -> Message:
            if body_events:
                return body_events.pop(0)
            return {"type": "http.request", "body": b"", "more_body": False}

        async def send_with_headers(message: Message) -> None:
            if message.get("type") == "http.response.start" and extra_headers:
                headers = list(message.get("headers", []))
                headers.extend(extra_headers)
                message["headers"] = headers
            await send(message)

        await self.app(scope, replay_receive, send_with_headers)


_LIMITER: SessionTokenBucketLimiter | None = None


def get_request_guard_limiter() -> SessionTokenBucketLimiter:
    global _LIMITER
    if _LIMITER is not None:
        return _LIMITER

    cfg = get_config().performance
    _LIMITER = SessionTokenBucketLimiter(
        burst=cfg.request_rate_limit_burst,
        refill_per_second=cfg.request_rate_limit_refill_per_sec,
    )
    return _LIMITER
