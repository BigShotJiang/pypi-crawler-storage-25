from __future__ import annotations

import json
import os
import sqlite3
from typing import Any

DB_DIR = os.path.expanduser("~/.tradingview_mcp_data")
DB_PATH = os.path.join(DB_DIR, "signals.db")


def init_db() -> None:
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            exchange TEXT NOT NULL,
            signal_type TEXT NOT NULL,
            confidence REAL NOT NULL,
            entry_price REAL,
            exit_price REAL,
            metadata_json TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


def save_signal(
    symbol: str,
    exchange: str,
    signal_type: str,
    confidence: float,
    entry_price: float | None = None,
    exit_price: float | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO signals (symbol, exchange, signal_type, confidence, entry_price, exit_price, metadata_json)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            symbol.upper(),
            exchange.upper(),
            signal_type.upper(),
            float(confidence),
            entry_price,
            exit_price,
            json.dumps(metadata or {}),
        ),
    )
    signal_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return {"status": "saved", "signal_id": signal_id}


def list_signals(limit: int = 50) -> list[dict[str, Any]]:
    init_db()
    limit = max(1, min(int(limit), 500))
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT id, symbol, exchange, signal_type, confidence, entry_price, exit_price, metadata_json, created_at
        FROM signals
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,),
    )
    rows = cursor.fetchall()
    conn.close()

    result: list[dict[str, Any]] = []
    for row in rows:
        payload = dict(row)
        payload["metadata"] = json.loads(payload.pop("metadata_json") or "{}")
        result.append(payload)
    return result
