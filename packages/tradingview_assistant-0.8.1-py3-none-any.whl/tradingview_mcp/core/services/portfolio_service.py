from __future__ import annotations

import sqlite3
from typing import Any

from tradingview_mcp.core import portfolio

DEFAULT_MAX_POSITION_SIZE_PCT = 0.30


def _portfolio_value(user_id: str) -> float:
    state = portfolio.get_portfolio(user_id)
    positions_value = 0.0
    for pos in state.get("positions", []):
        positions_value += float(pos.get("quantity", 0.0)) * float(pos.get("average_price", 0.0))
    return float(state.get("balance", 0.0)) + positions_value


def _would_breach_position_limit(
    user_id: str,
    symbol: str,
    quantity: float,
    price: float,
    max_position_size_pct: float,
) -> bool:
    state = portfolio.get_portfolio(user_id)
    symbol_upper = symbol.upper()
    existing_qty = 0.0
    for pos in state.get("positions", []):
        if str(pos.get("symbol", "")).upper() == symbol_upper:
            existing_qty = float(pos.get("quantity", 0.0))
            break

    equity = _portfolio_value(user_id)
    if equity <= 0:
        return False

    new_position_value = (existing_qty + quantity) * price
    return (new_position_value / equity) > max_position_size_pct


def execute_portfolio_trade(
    user_id: str,
    symbol: str,
    side: str,
    quantity: float,
    entry_price: float,
    max_position_size_pct: float = DEFAULT_MAX_POSITION_SIZE_PCT,
) -> dict[str, Any]:
    side = side.upper().strip()
    if side not in {"BUY", "SELL"}:
        return {"status": "invalid_input", "error": "side must be BUY or SELL"}

    if quantity <= 0 or entry_price <= 0:
        return {"status": "invalid_input", "error": "quantity and entry_price must be > 0"}

    if side == "BUY" and _would_breach_position_limit(
        user_id=user_id,
        symbol=symbol,
        quantity=quantity,
        price=entry_price,
        max_position_size_pct=max_position_size_pct,
    ):
        return {
            "status": "invalid_risk",
            "error": "position size exceeds configured risk limit",
            "max_position_size_pct": max_position_size_pct,
        }

    result = portfolio.execute_trade(
        user_id=user_id,
        symbol=symbol,
        quantity=quantity,
        current_price=entry_price,
        side=side,
    )
    if result.get("status") == "success":
        return result
    return {"status": "error", **result}


def get_trade_history(user_id: str, limit: int = 50) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 500))
    conn = sqlite3.connect(portfolio.DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT symbol, quantity, price, side, realized_pnl, executed_at
        FROM trade_history
        WHERE user_id = ?
        ORDER BY id DESC
        LIMIT ?
        """,
        (user_id, limit),
    )
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]
