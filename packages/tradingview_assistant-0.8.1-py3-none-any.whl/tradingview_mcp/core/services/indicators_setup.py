﻿from __future__ import annotations
from typing import Dict, Optional

from tradingview_mcp.core.services.indicators_metrics import _safe_round

def compute_trade_setup(indicators: Dict) -> Optional[Dict]:
    """Generate entry points, stop-loss, targets, and S/R levels.

    Only call this for stocks that pass the stock score threshold (>=70).
    """
    close = indicators.get("close")
    high = indicators.get("high")
    low = indicators.get("low")
    atr = indicators.get("ATR")
    ema20 = indicators.get("EMA20")
    ema50 = indicators.get("EMA50")
    ema200 = indicators.get("EMA200")

    if not close or not atr or atr <= 0:
        return None

    # ΓöÇΓöÇ Support & Resistance Levels ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    # Collect candidate levels from multiple sources
    support_candidates = []
    resistance_candidates = []

    # Pivot points
    for key_prefix in ("Pivot.M.Classic", "Pivot.M.Fibonacci"):
        for i in range(1, 4):
            s_val = indicators.get(f"{key_prefix}.S{i}")
            r_val = indicators.get(f"{key_prefix}.R{i}")
            if s_val and s_val < close:
                support_candidates.append(s_val)
            if r_val and r_val > close:
                resistance_candidates.append(r_val)

    # EMAs as dynamic S/R
    for ema_val in [ema20, ema50, ema200]:
        if ema_val and ema_val < close:
            support_candidates.append(ema_val)
        elif ema_val and ema_val > close:
            resistance_candidates.append(ema_val)

    # BB bands
    bb_lower = indicators.get("BB.lower")
    bb_upper = indicators.get("BB.upper")
    if bb_lower and bb_lower < close:
        support_candidates.append(bb_lower)
    if bb_upper and bb_upper > close:
        resistance_candidates.append(bb_upper)

    # Parabolic SAR
    psar = indicators.get("P.SAR")
    if psar and psar < close:
        support_candidates.append(psar)

    # Deduplicate and sort
    supports = sorted([x for x in set(_safe_round(s, 2) for s in support_candidates if s) if x is not None], reverse=True)[:3]
    resistances = sorted([x for x in set(_safe_round(r, 2) for r in resistance_candidates if r) if x is not None])[:3]

    # ΓöÇΓöÇ Entry Points ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

    # Breakout entry: above nearest resistance
    breakout_entry = None
    if resistances:
        breakout_entry = resistances[0]

    # Pullback entry: near EMA20 or nearest support
    pullback_entry = None
    if ema20 and ema20 < close:
        pullback_entry = _safe_round(ema20, 2)
    elif supports:
        pullback_entry = supports[0]

    setup_types = []
    if breakout_entry:
        setup_types.append("breakout")
    if pullback_entry:
        setup_types.append("pullback")

    # ΓöÇΓöÇ Stop-Loss ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    # Tighter of: below nearest support by 0.5├ùATR, or entry - 1.5├ùATR

    atr_stop = _safe_round(close - 1.5 * atr, 2)
    support_stop = None
    if supports:
        support_stop = _safe_round(supports[0] - 0.5 * atr, 2)

    if support_stop and atr_stop:
        stop_loss = max(support_stop, atr_stop)  # Tighter of the two
    elif support_stop:
        stop_loss = support_stop
    else:
        stop_loss = atr_stop

    # Validate stop isn't unrealistically tight (<0.5% from close) or wide (>10%)
    stop_pct = ((close - stop_loss) / close) * 100 if stop_loss else None
    if stop_pct is not None and stop_pct < 0.5:
        stop_loss = _safe_round(close - 1.0 * atr, 2)
        stop_pct = ((close - stop_loss) / close) * 100

    # ΓöÇΓöÇ Targets ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    target_1 = resistances[0] if len(resistances) >= 1 else _safe_round(close + 1.5 * atr, 2)
    target_2 = resistances[1] if len(resistances) >= 2 else _safe_round(close + 3.0 * atr, 2)

    # ΓöÇΓöÇ Risk/Reward Ratios ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    risk = close - stop_loss if stop_loss else None
    rr_1 = _safe_round((target_1 - close) / risk, 1) if risk and risk > 0 else None
    rr_2 = _safe_round((target_2 - close) / risk, 1) if risk and risk > 0 else None

    # R:R quality
    rr_quality = "Weak"
    if rr_2 and rr_2 >= 2.5:
        rr_quality = "Strong"
    elif rr_2 and rr_2 >= 2.0:
        rr_quality = "Good"
    elif rr_2 and rr_2 >= 1.5:
        rr_quality = "Acceptable"

    return {
        "setup_types": setup_types,
        "entry_points": {
            "breakout_entry": breakout_entry,
            "pullback_entry": pullback_entry,
        },
        "stop_loss": stop_loss,
        "stop_distance_pct": _safe_round(stop_pct, 2),
        "targets": {
            "target_1": target_1,
            "target_2": target_2,
        },
        "risk_reward": {
            "to_target_1": rr_1,
            "to_target_2": rr_2,
            "quality": rr_quality,
        },
        "supports": supports,
        "resistances": resistances,
    }


# ---------------------------------------------------------------------------
# LAYER C ΓÇö Trade Quality Score (100 pts)
# Answers: "Is this setup actually tradable?"
# ---------------------------------------------------------------------------

def compute_trade_quality(indicators: Dict, stock_score: int, trade_setup: Dict) -> Dict:
    """Score the trade setup quality out of 100.

    Sections:
      Structure Quality  ΓÇö 30 pts
      Risk/Reward        ΓÇö 30 pts
      Volume ConfirmationΓÇö 20 pts
      Stop Placement     ΓÇö 10 pts
      Liquidity          ΓÇö 10 pts
    """
    close = indicators.get("close")
    ema20 = indicators.get("EMA20")
    ema50 = indicators.get("EMA50")
    ema200 = indicators.get("EMA200")
    adx = indicators.get("ADX")
    volume = indicators.get("volume")
    vol_sma20 = indicators.get("volume.SMA20")

    total = 0
    breakdown = {}
    notes = []

    # ΓöÇΓöÇ Structure Quality ΓÇö 30 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    struct_pts = 0
    # Clean trend
    if ema20 and ema50 and ema200 and close:
        if close > ema20 > ema50 > ema200:
            struct_pts += 15
            notes.append("Clean uptrend structure")
        elif close > ema50:
            struct_pts += 8
    # Strong trend (ADX)
    if adx and adx > 25:
        struct_pts += 10
    elif adx and adx > 20:
        struct_pts += 5
    # No messy overhead resistance (check if nearest R is far enough)
    resistances = trade_setup.get("resistances", [])
    if resistances and close:
        dist_to_r1 = ((resistances[0] - close) / close) * 100
        if dist_to_r1 > 3:
            struct_pts += 5
            notes.append(f"Room to run ({dist_to_r1:.1f}% to R1)")
        elif dist_to_r1 < 1:
            notes.append(f"Resistance very close ({dist_to_r1:.1f}%)")
    breakdown["structure_quality"] = min(30, struct_pts)
    total += breakdown["structure_quality"]

    # ΓöÇΓöÇ Risk/Reward ΓÇö 30 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    rr2 = trade_setup.get("risk_reward", {}).get("to_target_2")
    rr_pts = 0
    if rr2 is not None:
        if rr2 >= 2.5:
            rr_pts = 30
            notes.append(f"Excellent R:R {rr2:.1f}")
        elif rr2 >= 2.0:
            rr_pts = 24
        elif rr2 >= 1.5:
            rr_pts = 15
        else:
            rr_pts = 0
            notes.append(f"Poor R:R {rr2:.1f} - weak setup")
    breakdown["risk_reward"] = rr_pts
    total += rr_pts

    # ΓöÇΓöÇ Volume Confirmation ΓÇö 20 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    vol_pts = 0
    if volume and vol_sma20 and vol_sma20 > 0:
        ratio = volume / vol_sma20
        if ratio >= 1.5:
            vol_pts = 20
            notes.append(f"Strong volume participation ({ratio:.1f}x)")
        elif ratio >= 1.2:
            vol_pts = 14
        elif ratio >= 1.0:
            vol_pts = 8
        else:
            vol_pts = 0
    breakdown["volume_confirmation"] = vol_pts
    total += vol_pts

    # ΓöÇΓöÇ Stop Placement Quality ΓÇö 10 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    stop_pct = trade_setup.get("stop_distance_pct")
    stop_pts = 0
    if stop_pct is not None:
        if 1.5 <= stop_pct <= 5.0:
            stop_pts = 10
            notes.append(f"Logical stop at {stop_pct:.1f}% below")
        elif 0.5 <= stop_pct < 1.5:
            stop_pts = 5
            notes.append("Stop might be too tight")
        elif 5.0 < stop_pct <= 8.0:
            stop_pts = 5
            notes.append("Wide stop ΓÇö reduce position size")
        else:
            stop_pts = 0
            notes.append("Stop placement problematic")
    breakdown["stop_quality"] = stop_pts
    total += stop_pts

    # ΓöÇΓöÇ Liquidity ΓÇö 10 pts ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ
    liq_pts = 0
    if volume and vol_sma20:
        # Use average volume as liquidity proxy
        if vol_sma20 >= 500000:
            liq_pts = 10
        elif vol_sma20 >= 100000:
            liq_pts = 7
        elif vol_sma20 >= 50000:
            liq_pts = 4
        else:
            liq_pts = 0
            notes.append("Low liquidity ΓÇö harder to enter/exit")
    breakdown["liquidity"] = liq_pts
    total += liq_pts

    total = max(0, min(100, total))

    if total >= 80:
        quality = "High Quality Setup"
    elif total >= 65:
        quality = "Tradable"
    elif total >= 50:
        quality = "Weak Setup"
    else:
        quality = "Avoid Execution"

    return {
        "trade_quality_score": total,
        "quality": quality,
        "breakdown": breakdown,
        "notes": notes,
    }


# ---------------------------------------------------------------------------
# Fibonacci Retracement Analysis
# ---------------------------------------------------------------------------

_FIB_RETRACEMENT_RATIOS = [0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0]
_FIB_EXTENSION_RATIOS = [1.272, 1.618, 2.618]


