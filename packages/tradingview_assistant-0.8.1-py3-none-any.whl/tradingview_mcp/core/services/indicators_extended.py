﻿from __future__ import annotations
from typing import Dict

from tradingview_mcp.core.services.indicators_metrics import _safe_round
from tradingview_mcp.core.services.indicators_patterns import _extract_support_resistance, _detect_market_structure

def extract_extended_indicators(indicators: Dict) -> Dict:
    """Extract extended technical indicators from TradingView data.

    Returns a dict with RSI, OBV, SMA, EMA, ATR, MACD, Volume, Support/Resistance,
    Bollinger Bands, and market structure details.
    """
    close = indicators.get("close")
    open_price = indicators.get("open")
    high = indicators.get("high")
    low = indicators.get("low")
    volume = indicators.get("volume")

    # --- RSI ---
    rsi_value = indicators.get("RSI")
    rsi_signal = "Neutral"
    if rsi_value is not None:
        if rsi_value > 70:
            rsi_signal = "Overbought"
        elif rsi_value > 60:
            rsi_signal = "Bullish"
        elif rsi_value < 30:
            rsi_signal = "Oversold"
        elif rsi_value < 40:
            rsi_signal = "Bearish"

    rsi = {
        "value": _safe_round(rsi_value, 2),
        "signal": rsi_signal,
    }

    # --- OBV (On Balance Volume) ---
    obv_direction = None
    if volume is not None and open_price and close:
        obv_direction = "accumulation" if close > open_price else "distribution" if close < open_price else "neutral"

    obv = {
        "current_volume": _safe_round(volume, 0),
        "direction": obv_direction,
        "note": "OBV direction inferred from current candle (close vs open)",
    }

    # --- SMA (Simple Moving Average) ---
    sma10 = indicators.get("SMA10")
    sma20 = indicators.get("SMA20")
    sma30 = indicators.get("SMA30")
    sma50 = indicators.get("SMA50")
    sma100 = indicators.get("SMA100")
    sma200 = indicators.get("SMA200")

    sma_data = {
        "sma10": _safe_round(sma10, 4),
        "sma20": _safe_round(sma20, 4),
        "sma30": _safe_round(sma30, 4),
        "sma50": _safe_round(sma50, 4),
        "sma100": _safe_round(sma100, 4),
        "sma200": _safe_round(sma200, 4),
    }

    # SMA trend signals
    sma_signals = []
    if close and sma50:
        if close > sma50:
            sma_signals.append("Price above SMA50 (bullish)")
        else:
            sma_signals.append("Price below SMA50 (bearish)")
    if close and sma200:
        if close > sma200:
            sma_signals.append("Price above SMA200 (long-term bullish)")
        else:
            sma_signals.append("Price below SMA200 (long-term bearish)")
    if sma50 and sma200:
        if sma50 > sma200:
            sma_signals.append("Golden Cross (SMA50 > SMA200)")
        else:
            sma_signals.append("Death Cross (SMA50 < SMA200)")

    sma_data["signals"] = sma_signals

    # --- EMA (Exponential Moving Average) ---
    ema9 = indicators.get("EMA9")
    ema10 = indicators.get("EMA10")
    ema20 = indicators.get("EMA20")
    ema30 = indicators.get("EMA30")
    ema50 = indicators.get("EMA50")
    ema100 = indicators.get("EMA100")
    ema200 = indicators.get("EMA200")

    ema_data = {
        "ema9": _safe_round(ema9, 4),
        "ema10": _safe_round(ema10, 4),
        "ema20": _safe_round(ema20, 4),
        "ema30": _safe_round(ema30, 4),
        "ema50": _safe_round(ema50, 4),
        "ema100": _safe_round(ema100, 4),
        "ema200": _safe_round(ema200, 4),
    }

    # EMA trend signals
    ema_signals = []
    if close and ema20:
        if close > ema20:
            ema_signals.append("Price above EMA20 (short-term bullish)")
        else:
            ema_signals.append("Price below EMA20 (short-term bearish)")
    if close and ema50:
        if close > ema50:
            ema_signals.append("Price above EMA50 (mid-term bullish)")
        else:
            ema_signals.append("Price below EMA50 (mid-term bearish)")
    if close and ema200:
        if close > ema200:
            ema_signals.append("Price above EMA200 (long-term bullish)")
        else:
            ema_signals.append("Price below EMA200 (long-term bearish)")
    if ema50 and ema200:
        if ema50 > ema200:
            ema_signals.append("Golden Cross (EMA50 > EMA200)")
        else:
            ema_signals.append("Death Cross (EMA50 < EMA200)")
    if ema9 and ema20:
        if ema9 > ema20:
            ema_signals.append("Fast EMA bullish (EMA9 > EMA20)")
        else:
            ema_signals.append("Fast EMA bearish (EMA9 < EMA20)")

    ema_data["signals"] = ema_signals

    # --- ATR (Average True Range) ---
    atr_value = indicators.get("ATR")
    atr_pct = None
    if atr_value is not None and close and close > 0:
        atr_pct = (atr_value / close) * 100

    atr = {
        "value": _safe_round(atr_value, 4),
        "percent_of_price": _safe_round(atr_pct, 2),
        "volatility": "High" if atr_pct and atr_pct > 3 else "Medium" if atr_pct and atr_pct > 1.5 else "Low",
    }

    # --- MACD ---
    macd_line = indicators.get("MACD.macd")
    macd_signal_line = indicators.get("MACD.signal")
    macd_histogram = None
    macd_crossover = "Neutral"
    if macd_line is not None and macd_signal_line is not None:
        macd_histogram = macd_line - macd_signal_line
        if macd_line > macd_signal_line:
            macd_crossover = "Bullish"
        elif macd_line < macd_signal_line:
            macd_crossover = "Bearish"

    macd = {
        "macd_line": _safe_round(macd_line, 6),
        "signal_line": _safe_round(macd_signal_line, 6),
        "histogram": _safe_round(macd_histogram, 6),
        "crossover": macd_crossover,
    }

    # --- Volume ---
    volume_sma20 = indicators.get("volume.SMA20")
    volume_ratio = None
    volume_signal = "Normal"
    if volume is not None and volume_sma20 and volume_sma20 > 0:
        volume_ratio = volume / volume_sma20
        if volume_ratio >= 3.0:
            volume_signal = "Very High"
        elif volume_ratio >= 2.0:
            volume_signal = "High"
        elif volume_ratio >= 1.5:
            volume_signal = "Above Average"
        elif volume_ratio < 0.5:
            volume_signal = "Very Low"
        elif volume_ratio < 0.8:
            volume_signal = "Below Average"

    volume_data = {
        "current": _safe_round(volume, 0),
        "average_20": _safe_round(volume_sma20, 0),
        "ratio": _safe_round(volume_ratio, 2),
        "signal": volume_signal,
    }

    # --- Bollinger Bands ---
    bb_upper = indicators.get("BB.upper")
    bb_lower = indicators.get("BB.lower")
    bb_middle = sma20  # BB middle = SMA20

    bb_data = {
        "upper": _safe_round(bb_upper, 4),
        "middle": _safe_round(bb_middle, 4),
        "lower": _safe_round(bb_lower, 4),
    }

    if bb_upper and bb_lower and bb_middle and bb_middle > 0:
        bbw = (bb_upper - bb_lower) / bb_middle
        bb_data["width"] = _safe_round(bbw, 4)
        bb_data["squeeze"] = bbw < 0.02
    else:
        bb_data["width"] = None
        bb_data["squeeze"] = False

    if close and bb_upper and bb_lower:
        if close > bb_upper:
            bb_data["position"] = "Above Upper Band"
        elif close < bb_lower:
            bb_data["position"] = "Below Lower Band"
        elif bb_middle and close > bb_middle:
            bb_data["position"] = "Upper Half"
        else:
            bb_data["position"] = "Lower Half"
    else:
        bb_data["position"] = "Unknown"

    # --- Support & Resistance (from Pivot Points) ---
    support_resistance = _extract_support_resistance(indicators, close)

    # --- Stochastic ---
    stoch_k = indicators.get("Stoch.K")
    stoch_d = indicators.get("Stoch.D")
    stoch_signal = "Neutral"
    if stoch_k is not None:
        if stoch_k > 80:
            stoch_signal = "Overbought"
        elif stoch_k < 20:
            stoch_signal = "Oversold"

    stochastic = {
        "k": _safe_round(stoch_k, 2),
        "d": _safe_round(stoch_d, 2),
        "signal": stoch_signal,
    }

    # --- ADX (Trend Strength) ---
    adx_value = indicators.get("ADX")
    adx = {
        "value": _safe_round(adx_value, 2),
        "trend_strength": "Strong Trend" if adx_value and adx_value > 25 else
                          "Weak/No Trend" if adx_value and adx_value < 20 else "Moderate",
    }

    # --- VWAP (if available) ---
    vwap_value = indicators.get("VWAP")
    vwap = None
    if vwap_value is not None:
        vwap = {
            "value": _safe_round(vwap_value, 4),
            "position": "Above VWAP (bullish)" if close and close > vwap_value else "Below VWAP (bearish)",
        }

    # --- CCI (Commodity Channel Index) ---
    cci_value = indicators.get("CCI20")
    cci_signal = "Neutral"
    if cci_value is not None:
        if cci_value > 100:
            cci_signal = "Overbought"
        elif cci_value > 0:
            cci_signal = "Bullish"
        elif cci_value < -100:
            cci_signal = "Oversold"
        elif cci_value < 0:
            cci_signal = "Bearish"

    cci = {
        "value": _safe_round(cci_value, 2),
        "signal": cci_signal,
    }

    # --- Williams %R ---
    wr_value = indicators.get("W.R")
    wr_signal = "Neutral"
    if wr_value is not None:
        if wr_value > -20:
            wr_signal = "Overbought"
        elif wr_value < -80:
            wr_signal = "Oversold"

    williams_r = {
        "value": _safe_round(wr_value, 2),
        "signal": wr_signal,
    }

    # --- Awesome Oscillator ---
    ao_value = indicators.get("AO")
    ao_prev = indicators.get("AO[1]")
    ao_signal = "Neutral"
    if ao_value is not None:
        if ao_value > 0:
            ao_signal = "Bullish"
            if ao_prev is not None and ao_value > ao_prev:
                ao_signal = "Bullish (Rising)"
        else:
            ao_signal = "Bearish"
            if ao_prev is not None and ao_value < ao_prev:
                ao_signal = "Bearish (Falling)"

    awesome_oscillator = {
        "value": _safe_round(ao_value, 4),
        "signal": ao_signal,
    }

    # --- Momentum ---
    mom_value = indicators.get("Mom")
    mom_prev = indicators.get("Mom[1]")
    mom_signal = "Neutral"
    if mom_value is not None:
        if mom_value > 0:
            mom_signal = "Bullish"
            if mom_prev is not None and mom_value > mom_prev:
                mom_signal = "Bullish (Accelerating)"
        else:
            mom_signal = "Bearish"
            if mom_prev is not None and mom_value < mom_prev:
                mom_signal = "Bearish (Accelerating)"

    momentum = {
        "value": _safe_round(mom_value, 4),
        "signal": mom_signal,
    }

    # --- Parabolic SAR ---
    psar_value = indicators.get("P.SAR")
    psar = {
        "value": _safe_round(psar_value, 4),
        "trend": "Bullish (price above SAR)" if close and psar_value and close > psar_value
                 else "Bearish (price below SAR)" if close and psar_value
                 else "Unknown",
    }

    # --- Ichimoku ---
    ichimoku_bline = indicators.get("Ichimoku.BLine")
    ichimoku = {
        "baseline": _safe_round(ichimoku_bline, 4),
        "position": "Above Baseline (bullish)" if close and ichimoku_bline and close > ichimoku_bline
                    else "Below Baseline (bearish)" if close and ichimoku_bline
                    else "Unknown",
    }

    # --- Stochastic RSI ---
    stoch_rsi_k = indicators.get("Stoch.RSI.K")
    stoch_rsi_signal = "Neutral"
    if stoch_rsi_k is not None:
        if stoch_rsi_k > 80:
            stoch_rsi_signal = "Overbought"
        elif stoch_rsi_k < 20:
            stoch_rsi_signal = "Oversold"

    stochastic_rsi = {
        "k": _safe_round(stoch_rsi_k, 2),
        "signal": stoch_rsi_signal,
    }

    # --- ADX Directional Movement (+DI / -DI) ---
    adx_plus_di = indicators.get("ADX+DI")
    adx_minus_di = indicators.get("ADX-DI")
    di_signal = "Neutral"
    if adx_plus_di is not None and adx_minus_di is not None:
        if adx_plus_di > adx_minus_di:
            di_signal = "Bullish (+DI > -DI)"
        else:
            di_signal = "Bearish (-DI > +DI)"

    adx["plus_di"] = _safe_round(adx_plus_di, 2)
    adx["minus_di"] = _safe_round(adx_minus_di, 2)
    adx["di_signal"] = di_signal

    # --- Hull Moving Average ---
    hull_ma = indicators.get("HullMA9")
    hull = {
        "value": _safe_round(hull_ma, 4),
        "position": "Above Hull MA (bullish)" if close and hull_ma and close > hull_ma
                    else "Below Hull MA (bearish)" if close and hull_ma
                    else "Unknown",
    }

    # --- VWMA (Volume Weighted Moving Average) ---
    vwma_value = indicators.get("VWMA")
    vwma = None
    if vwma_value is not None:
        vwma = {
            "value": _safe_round(vwma_value, 4),
            "position": "Above VWMA (bullish)" if close and close > vwma_value else "Below VWMA (bearish)",
        }

    # --- Ultimate Oscillator ---
    uo_value = indicators.get("UO")
    uo_signal = "Neutral"
    if uo_value is not None:
        if uo_value > 70:
            uo_signal = "Overbought"
        elif uo_value > 50:
            uo_signal = "Bullish"
        elif uo_value < 30:
            uo_signal = "Oversold"
        elif uo_value < 50:
            uo_signal = "Bearish"

    ultimate_oscillator = {
        "value": _safe_round(uo_value, 2),
        "signal": uo_signal,
    }

    # --- RSI Direction (rising or falling) ---
    rsi_prev = indicators.get("RSI[1]")
    if rsi_value is not None and rsi_prev is not None:
        rsi["direction"] = "Rising" if rsi_value > rsi_prev else "Falling" if rsi_value < rsi_prev else "Flat"
        rsi["previous"] = _safe_round(rsi_prev, 2)

    # --- TradingView Built-in Recommendations ---
    rec_all = indicators.get("Recommend.All")
    rec_ma = indicators.get("Recommend.MA")
    rec_other = indicators.get("Recommend.Other")

    def _recommendation_label(value):
        if value is None:
            return "Unknown"
        if value >= 0.5:
            return "Strong Buy"
        if value > 0.1:
            return "Buy"
        if value <= -0.5:
            return "Strong Sell"
        if value < -0.1:
            return "Sell"
        return "Neutral"

    tv_recommendation = {
        "overall": _safe_round(rec_all, 3),
        "overall_signal": _recommendation_label(rec_all),
        "moving_averages": _safe_round(rec_ma, 3),
        "ma_signal": _recommendation_label(rec_ma),
        "oscillators": _safe_round(rec_other, 3),
        "oscillators_signal": _recommendation_label(rec_other),
    }

    # --- Market Structure ---
    structure = _detect_market_structure(indicators, close, open_price, high, low)

    result = {
        "rsi": rsi,
        "obv": obv,
        "sma": sma_data,
        "ema": ema_data,
        "atr": atr,
        "macd": macd,
        "volume": volume_data,
        "bollinger_bands": bb_data,
        "support_resistance": support_resistance,
        "stochastic": stochastic,
        "stochastic_rsi": stochastic_rsi,
        "adx": adx,
        "cci": cci,
        "williams_r": williams_r,
        "awesome_oscillator": awesome_oscillator,
        "momentum": momentum,
        "parabolic_sar": psar,
        "ichimoku": ichimoku,
        "hull_ma": hull,
        "ultimate_oscillator": ultimate_oscillator,
        "tv_recommendation": tv_recommendation,
        "market_structure": structure,
    }

    if vwap is not None:
        result["vwap"] = vwap
    if vwma is not None:
        result["vwma"] = vwma

    return result


