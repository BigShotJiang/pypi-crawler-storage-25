from __future__ import annotations

from typing import Any

from tradingview_mcp.core.services.portfolio_service import execute_portfolio_trade


def execute_order(
    user_id: str,
    symbol: str,
    side: str,
    quantity: float,
    price: float,
    paper: bool = True,
) -> dict[str, Any]:
    if not paper:
        return {
            "status": "not_implemented",
            "error": "Live execution is not enabled. Use paper mode.",
            "mode": "live",
        }

    result = execute_portfolio_trade(
        user_id=user_id,
        symbol=symbol,
        side=side,
        quantity=quantity,
        entry_price=price,
    )
    return {"mode": "paper", **result}
