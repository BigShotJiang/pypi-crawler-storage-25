from __future__ import annotations

from typing import Any


def error_item(
    *,
    code: str,
    message: str,
    field: str | None = None,
    source: str | None = None,
) -> dict[str, Any]:
    item: dict[str, Any] = {"code": code, "message": message}
    if field is not None:
        item["field"] = field
    if source is not None:
        item["source"] = source
    return item


def build_response(
    *,
    status: str,
    data: Any,
    errors: list[dict[str, Any]] | None = None,
    coverage_pct: float = 100.0,
    source_failures: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "status": status,
        "data": data,
        "errors": errors or [],
        "coverage_pct": float(max(0.0, min(100.0, coverage_pct))),
        "source_failures": source_failures or [],
    }


def success_response(data: Any, status: str = "success") -> dict[str, Any]:
    return build_response(status=status, data=data)


def invalid_input_response(errors: list[dict[str, Any]]) -> dict[str, Any]:
    return build_response(status="invalid_input", data=None, errors=errors, coverage_pct=100.0)


def internal_error_response(message: str = "Internal service error") -> dict[str, Any]:
    return build_response(
        status="error",
        data=None,
        errors=[error_item(code="internal_error", message=message)],
        coverage_pct=0.0,
    )
