from __future__ import annotations

from typing import Any

from tradingview_mcp.core.utils.validators import validate_exchange, validate_symbol


_ALLOWED_CHANNELS = {"webhook", "telegram", "email"}
_ALLOWED_SIGNAL_TYPES = {"BUY", "SELL", "HOLD"}
_ALLOWED_SIDES = {"BUY", "SELL"}


def _error_item(field: str, message: str, code: str = "invalid_field") -> dict[str, Any]:
    return {"field": field, "message": message, "code": code}


def _normalize_non_empty_text(
    value: Any,
    *,
    field: str,
    max_len: int = 256,
    upper: bool = False,
) -> tuple[str | None, dict[str, Any] | None]:
    if not isinstance(value, str):
        return None, _error_item(field, "must be a string")
    normalized = value.strip()
    if not normalized:
        return None, _error_item(field, "must not be empty")
    if len(normalized) > max_len:
        return None, _error_item(field, f"must be <= {max_len} characters")
    if upper:
        normalized = normalized.upper()
    return normalized, None


def _normalize_number(
    value: Any,
    *,
    field: str,
    min_value: float | None = None,
    max_value: float | None = None,
) -> tuple[float | None, dict[str, Any] | None]:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None, _error_item(field, "must be a number")
    v = float(value)
    if min_value is not None and v < min_value:
        return None, _error_item(field, f"must be >= {min_value}")
    if max_value is not None and v > max_value:
        return None, _error_item(field, f"must be <= {max_value}")
    return v, None


def validate_execute_portfolio_trade_input(
    *,
    user_id: Any,
    symbol: Any,
    side: Any,
    quantity: Any,
    entry_price: Any,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    errors: list[dict[str, Any]] = []

    user_id_n, err = _normalize_non_empty_text(user_id, field="user_id", max_len=128)
    if err:
        errors.append(err)

    symbol_n = None
    if not isinstance(symbol, str):
        errors.append(_error_item("symbol", "must be a string"))
    else:
        try:
            symbol_n = validate_symbol(symbol)
        except ValueError as exc:
            errors.append(_error_item("symbol", str(exc), code="invalid_symbol"))

    side_n = None
    if isinstance(side, str):
        side_n = side.strip().upper()
    if side_n not in _ALLOWED_SIDES:
        errors.append(_error_item("side", "must be BUY or SELL", code="invalid_side"))

    quantity_n, err = _normalize_number(quantity, field="quantity", min_value=0.0000001)
    if err:
        errors.append(err)

    entry_price_n, err = _normalize_number(entry_price, field="entry_price", min_value=0.0000001)
    if err:
        errors.append(err)

    if errors:
        return None, errors

    return {
        "user_id": user_id_n,
        "symbol": symbol_n,
        "side": side_n,
        "quantity": quantity_n,
        "entry_price": entry_price_n,
    }, []


def validate_save_trade_signal_input(
    *,
    symbol: Any,
    exchange: Any,
    signal_type: Any,
    confidence: Any,
    entry_price: Any,
    exit_price: Any,
    metadata: Any,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    errors: list[dict[str, Any]] = []

    symbol_n = None
    if not isinstance(symbol, str):
        errors.append(_error_item("symbol", "must be a string"))
    else:
        try:
            symbol_n = validate_symbol(symbol)
        except ValueError as exc:
            errors.append(_error_item("symbol", str(exc), code="invalid_symbol"))

    exchange_n = None
    if not isinstance(exchange, str):
        errors.append(_error_item("exchange", "must be a string"))
    else:
        try:
            exchange_n = validate_exchange(exchange).upper()
        except ValueError as exc:
            errors.append(_error_item("exchange", str(exc), code="invalid_exchange"))

    signal_type_n = None
    if isinstance(signal_type, str):
        signal_type_n = signal_type.strip().upper()
    if signal_type_n not in _ALLOWED_SIGNAL_TYPES:
        errors.append(_error_item("signal_type", "must be one of BUY, SELL, HOLD", code="invalid_signal_type"))

    confidence_n, err = _normalize_number(confidence, field="confidence", min_value=0.0, max_value=1.0)
    if err:
        errors.append(err)

    entry_price_n = None
    if entry_price is not None:
        entry_price_n, err = _normalize_number(entry_price, field="entry_price", min_value=0.0000001)
        if err:
            errors.append(err)

    exit_price_n = None
    if exit_price is not None:
        exit_price_n, err = _normalize_number(exit_price, field="exit_price", min_value=0.0000001)
        if err:
            errors.append(err)

    metadata_n: dict[str, Any] = {}
    if metadata is not None:
        if not isinstance(metadata, dict):
            errors.append(_error_item("metadata", "must be an object"))
        else:
            metadata_n = metadata

    if errors:
        return None, errors

    return {
        "symbol": symbol_n,
        "exchange": exchange_n,
        "signal_type": signal_type_n,
        "confidence": confidence_n,
        "entry_price": entry_price_n,
        "exit_price": exit_price_n,
        "metadata": metadata_n,
    }, []


def validate_set_user_alert_preferences_input(
    *,
    user_id: Any,
    channel: Any,
    destination: Any,
    min_confidence: Any,
    enabled: Any,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    errors: list[dict[str, Any]] = []

    user_id_n, err = _normalize_non_empty_text(user_id, field="user_id", max_len=128)
    if err:
        errors.append(err)

    channel_n = None
    if isinstance(channel, str):
        channel_n = channel.strip().lower()
    if channel_n not in _ALLOWED_CHANNELS:
        errors.append(_error_item("channel", "must be one of webhook, telegram, email", code="invalid_channel"))

    destination_n, err = _normalize_non_empty_text(destination, field="destination", max_len=512)
    if err:
        errors.append(err)

    min_confidence_n, err = _normalize_number(min_confidence, field="min_confidence", min_value=0.0, max_value=1.0)
    if err:
        errors.append(err)

    if not isinstance(enabled, bool):
        errors.append(_error_item("enabled", "must be a boolean"))

    if errors:
        return None, errors

    return {
        "user_id": user_id_n,
        "channel": channel_n,
        "destination": destination_n,
        "min_confidence": min_confidence_n,
        "enabled": enabled,
    }, []


def validate_execute_order_input(
    *,
    user_id: Any,
    symbol: Any,
    side: Any,
    quantity: Any,
    price: Any,
    paper: Any,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    normalized, errors = validate_execute_portfolio_trade_input(
        user_id=user_id,
        symbol=symbol,
        side=side,
        quantity=quantity,
        entry_price=price,
    )
    if not isinstance(paper, bool):
        errors.append(_error_item("paper", "must be a boolean"))

    if errors or normalized is None:
        return None, errors

    return {
        "user_id": normalized["user_id"],
        "symbol": normalized["symbol"],
        "side": normalized["side"],
        "quantity": normalized["quantity"],
        "price": normalized["entry_price"],
        "paper": paper,
    }, []
