from __future__ import annotations
import os
import re
from typing import Set

ALLOWED_TIMEFRAMES: Set[str] = {"5m", "15m", "1h", "4h", "1D", "1W", "1M"}
_TIMEFRAME_ALIASES = {
    "5m": "5m",
    "15m": "15m",
    "1h": "1h",
    "4h": "4h",
    "1d": "1D",
    "1w": "1W",
    "1m": "1M",
}

# Exchanges that represent stock markets (not crypto)
STOCK_EXCHANGES: Set[str] = {"egx", "bist", "nasdaq", "nyse", "bursa", "myx", "klse", "ace", "leap", "hkex", "hk", "hsi", "asx", "sse", "szse", "chn", "twse", "tpex"}

EXCHANGE_SCREENER = {
    "all": "crypto",
    "huobi": "crypto",
    "kucoin": "crypto",
    "coinbase": "crypto",
    "gateio": "crypto",
    "binance": "crypto",
    "bitfinex": "crypto",
    "bitget": "crypto",
    "bybit": "crypto",
    "okx": "crypto",
    "mexc": "crypto",
    "bist": "turkey",
    # Egyptian Stock Market Support
    "egx": "egypt",
    "nasdaq": "america",
    # Malaysia Stock Market Support
    "bursa": "malaysia",
    "myx": "malaysia",
    "klse": "malaysia",
    "ace": "malaysia",      # ACE Market (Access, Certainty, Efficiency)
    "leap": "malaysia",     # LEAP Market (Leading Entrepreneur Accelerator Platform)
    # Hong Kong Stock Market Support
    "hkex": "hongkong",     # Hong Kong Exchange
    "hk": "hongkong",       # Hong Kong (alternate)
    "hsi": "hongkong",      # Hang Seng Index constituents
    "nyse": "america",
    "asx": "australia",     # Australian Securities Exchange
    # China A-Share Market Support
    "sse": "china",         # Shanghai Stock Exchange (上海证券交易所)
    "szse": "china",        # Shenzhen Stock Exchange (深圳证券交易所)
    "chn": "china",         # China A-shares (combined alias)
    # Taiwan Stock Market Support
    "twse": "taiwan",       # Taiwan Stock Exchange (臺灣證券交易所)
    "tpex": "taiwan",       # Taipei Exchange (櫃買中心, OTC market)
}

# Get absolute path to coinlist directory relative to this module
# This file is at: src/tradingview_mcp/core/utils/validators.py
# We want: src/tradingview_mcp/coinlist/
_this_file = __file__
_utils_dir = os.path.dirname(_this_file)  # core/utils
_core_dir = os.path.dirname(_utils_dir)   # core  
_package_dir = os.path.dirname(_core_dir) # tradingview_mcp
COINLIST_DIR = os.path.join(_package_dir, 'coinlist')


def sanitize_timeframe(timeframe: str, default: str = "5m") -> str:
    if not timeframe:
        return default
    normalized = timeframe.strip().lower()
    return _TIMEFRAME_ALIASES.get(normalized, default)


def sanitize_exchange(exchange: str, default: str = "kucoin") -> str:
    if not exchange:
        return default
    normalized = exchange.strip().lower()
    return normalized if normalized in EXCHANGE_SCREENER else default


def is_stock_exchange(exchange: str) -> bool:
    """Return True if the exchange is a stock market (not crypto)."""
    return exchange.strip().lower() in STOCK_EXCHANGES


def get_market_type(exchange: str) -> str:
    """Return the TradingView market type for screener queries."""
    return EXCHANGE_SCREENER.get(exchange.strip().lower(), "crypto")


_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{1,10}(?::[A-Z0-9]{1,10})?(?:-[A-Z0-9]{1,4})?$")


def validate_exchange(exchange: str) -> str:
    """Validate exchange and return normalized lowercase exchange code."""
    ex = (exchange or "").strip().lower()
    if not ex or ex not in EXCHANGE_SCREENER:
        raise ValueError(f"Invalid exchange: {exchange}")
    return ex


def validate_symbol(symbol: str) -> str:
    """Validate symbol format and return uppercased symbol."""
    normalized = (symbol or "").strip().upper()
    if not normalized or not _SYMBOL_PATTERN.match(normalized):
        raise ValueError(
            "Invalid symbol format. Use 1-10 alphanumeric chars, optional :SUFFIX and optional -SUFFIX."
        )
    return normalized


def validate_timeframe(timeframe: str) -> str:
    """Validate timeframe and return canonical format."""
    normalized = sanitize_timeframe(timeframe, "")
    if normalized not in ALLOWED_TIMEFRAMES:
        raise ValueError(f"Invalid timeframe: {timeframe}")
    return normalized


def validate_limit(limit: int, min_value: int = 1, max_value: int = 50) -> int:
    """Validate integer limits used by tool handlers."""
    if not isinstance(limit, int) or not (min_value <= limit <= max_value):
        raise ValueError(f"Limit must be between {min_value} and {max_value}")
    return limit
