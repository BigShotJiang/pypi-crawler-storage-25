from __future__ import annotations

import os
from dataclasses import dataclass


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class PerformanceConfig:
    screener_batch_size: int = 200
    egx_scanner_cache_ttl: int = 300
    egx_scanner_max_workers: int = 5
    nse_scanner_cache_ttl: int = 300
    nse_scanner_max_workers: int = 5
    sentiment_timeout: int = 10
    reddit_rate_limit_calls: int = 10
    reddit_rate_limit_window_sec: int = 60
    # Unified HTTP client
    http_default_timeout: int = 12
    http_max_retries: int = 2
    http_backoff_base: float = 1.0
    http_circuit_breaker_threshold: int = 5
    http_circuit_breaker_open_duration: int = 30
    # MCP request guard (TVMCP-001 / TVMCP-002)
    request_rate_limit_burst: int = 30
    request_rate_limit_refill_per_sec: float = 5.0


@dataclass(frozen=True)
class AppConfig:
    performance: PerformanceConfig


def get_config() -> AppConfig:
    return AppConfig(
        performance=PerformanceConfig(
            screener_batch_size=max(1, _env_int("SCREENER_BATCH_SIZE", 200)),
            egx_scanner_cache_ttl=max(1, _env_int("EGX_SCANNER_CACHE_TTL", 300)),
            egx_scanner_max_workers=max(1, _env_int("EGX_SCANNER_MAX_WORKERS", 5)),
            nse_scanner_cache_ttl=max(1, _env_int("NSE_SCANNER_CACHE_TTL", 300)),
            nse_scanner_max_workers=max(1, _env_int("NSE_SCANNER_MAX_WORKERS", 5)),
            sentiment_timeout=max(1, _env_int("SENTIMENT_TIMEOUT", 10)),
            reddit_rate_limit_calls=max(1, _env_int("REDDIT_RATE_LIMIT_CALLS", 10)),
            reddit_rate_limit_window_sec=max(1, _env_int("REDDIT_RATE_LIMIT_WINDOW_SEC", 60)),
            http_default_timeout=max(1, _env_int("HTTP_DEFAULT_TIMEOUT", 12)),
            http_max_retries=max(0, _env_int("HTTP_MAX_RETRIES", 2)),
            http_backoff_base=max(0.1, float(os.environ.get("HTTP_BACKOFF_BASE", "1.0"))),
            http_circuit_breaker_threshold=max(1, _env_int("HTTP_CB_THRESHOLD", 5)),
            http_circuit_breaker_open_duration=max(1, _env_int("HTTP_CB_OPEN_DURATION", 30)),
            request_rate_limit_burst=max(1, _env_int("REQUEST_RATE_LIMIT_BURST", 30)),
            request_rate_limit_refill_per_sec=max(0.1, _env_float("REQUEST_RATE_LIMIT_REFILL_PER_SEC", 5.0)),
        )
    )
