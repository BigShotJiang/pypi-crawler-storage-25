"""NSE index constituent data (NIFTY50, NIFTYBANK, NIFTY100, NIFTYIT, etc.)."""
from __future__ import annotations

from typing import List

# ── NIFTY 50 ─────────────────────────────────────────────────────────────────
_NIFTY50: List[str] = [
    "NSE:RELIANCE",
    "NSE:TCS",
    "NSE:HDFCBANK",
    "NSE:INFY",
    "NSE:HINDUNILVR",
    "NSE:ICICIBANK",
    "NSE:KOTAKBANK",
    "NSE:BAJFINANCE",
    "NSE:SBIN",
    "NSE:BHARTIARTL",
    "NSE:WIPRO",
    "NSE:HCLTECH",
    "NSE:MARUTI",
    "NSE:TATAMOTORS",
    "NSE:BAJAJ-AUTO",
    "NSE:SUNPHARMA",
    "NSE:DRREDDY",
    "NSE:CIPLA",
    "NSE:TITAN",
    "NSE:ASIANPAINT",
    "NSE:ITC",
    "NSE:AXISBANK",
    "NSE:LTIM",
    "NSE:TECHM",
    "NSE:NESTLEIND",
    "NSE:POWERGRID",
    "NSE:NTPC",
    "NSE:ONGC",
    "NSE:BPCL",
    "NSE:TATASTEEL",
    "NSE:HINDALCO",
    "NSE:JSWSTEEL",
    "NSE:LARSEN",
    "NSE:ADANIPORTS",
    "NSE:DLF",
    "NSE:GODREJPROP",
    "NSE:BAJAJFINSV",
    "NSE:HDFCLIFE",
    "NSE:SBILIFE",
    "NSE:GRASIM",
    "NSE:ULTRACEMCO",
    "NSE:SHREECEM",
    "NSE:DIVISLAB",
    "NSE:BRITANNIA",
    "NSE:EICHERMOT",
    "NSE:M&M",
    "NSE:INDUSINDBK",
    "NSE:HEROMOTOCO",
    "NSE:APOLLOHOSP",
    "NSE:TVSMOTOR",
]

assert len(_NIFTY50) == 50, f"_NIFTY50 must have 50 entries, got {len(_NIFTY50)}"

# ── NIFTY BANK ────────────────────────────────────────────────────────────────
_NIFTYBANK: List[str] = [
    "NSE:HDFCBANK",
    "NSE:ICICIBANK",
    "NSE:KOTAKBANK",
    "NSE:AXISBANK",
    "NSE:SBIN",
    "NSE:INDUSINDBK",
    "NSE:BANKBARODA",
    "NSE:PNB",
    "NSE:FEDERALBNK",
    "NSE:IDFCFIRSTB",
    "NSE:AUBANK",
    "NSE:BANDHANBNK",
]

# ── NIFTY IT ──────────────────────────────────────────────────────────────────
_NIFTYIT: List[str] = [
    "NSE:INFY",
    "NSE:TCS",
    "NSE:WIPRO",
    "NSE:HCLTECH",
    "NSE:TECHM",
    "NSE:LTIM",
    "NSE:MPHASIS",
    "NSE:COFORGE",
    "NSE:PERSISTENT",
    "NSE:OFSS",
]

# ── NIFTY 100 = NIFTY 50 + 50 more midcaps ───────────────────────────────────
_NIFTY100_EXTRA: List[str] = [
    "NSE:BANKBARODA",
    "NSE:PNB",
    "NSE:CANBK",
    "NSE:FEDERALBNK",
    "NSE:IDFCFIRSTB",
    "NSE:AUBANK",
    "NSE:BANDHANBNK",
    "NSE:MPHASIS",
    "NSE:COFORGE",
    "NSE:PERSISTENT",
    "NSE:OFSS",
    "NSE:LUPIN",
    "NSE:AUROPHARMA",
    "NSE:TORNTPHARM",
    "NSE:IPCALAB",
    "NSE:BIOCON",
    "NSE:GLENMARK",
    "NSE:VEDL",
    "NSE:SAIL",
    "NSE:NMDC",
    "NSE:NATIONALUM",
    "NSE:JINDALSTEL",
    "NSE:APLAPOLLO",
    "NSE:RATNAMANI",
    "NSE:GAIL",
    "NSE:IOC",
    "NSE:HINDPETRO",
    "NSE:OIL",
    "NSE:MRPL",
    "NSE:GODREJCP",
    "NSE:DABUR",
    "NSE:MARICO",
    "NSE:COLPAL",
    "NSE:EMAMILTD",
    "NSE:PIDILITIND",
    "NSE:HAVELLS",
    "NSE:VOLTAS",
    "NSE:ESCORTS",
    "NSE:ASHOKLEY",
    "NSE:BALKRISIND",
    "NSE:CHOLAFIN",
    "NSE:BAJAJFINSV",
    "NSE:MUTHOOTFIN",
    "NSE:ICICIGI",
    "NSE:GMRINFRA",
    "NSE:SIEMENS",
    "NSE:ABB",
    "NSE:BHEL",
    "NSE:KEC",
    "NSE:CUMMINSIND",
]

assert len(_NIFTY100_EXTRA) == 50, \
    f"_NIFTY100_EXTRA must have 50 entries, got {len(_NIFTY100_EXTRA)}"

_NIFTY100: List[str] = _NIFTY50 + _NIFTY100_EXTRA

assert len(_NIFTY100) == 100, f"_NIFTY100 must have 100 entries, got {len(_NIFTY100)}"

_NIFTY50_SET = frozenset(s.upper() for s in _NIFTY50)


def get_nifty50_symbols() -> List[str]:
    """Return the 50 NIFTY 50 constituent symbols."""
    return list(_NIFTY50)


def get_niftybank_symbols() -> List[str]:
    """Return NIFTY Bank constituent symbols."""
    return list(_NIFTYBANK)


def get_nifty100_symbols() -> List[str]:
    """Return the 100 NIFTY 100 constituent symbols."""
    return list(_NIFTY100)


def get_niftyit_symbols() -> List[str]:
    """Return NIFTY IT constituent symbols."""
    return list(_NIFTYIT)


def get_index_names() -> List[str]:
    """Return list of supported index names."""
    return ["NIFTY50", "NIFTYBANK", "NIFTY100", "NIFTYIT"]


def is_nifty50_stock(symbol: str) -> bool:
    """Return True if symbol is a NIFTY 50 constituent."""
    return symbol.upper() in _NIFTY50_SET
