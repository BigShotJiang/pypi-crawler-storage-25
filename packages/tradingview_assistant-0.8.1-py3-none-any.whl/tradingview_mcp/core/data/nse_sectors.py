"""NSE (National Stock Exchange of India) sector classification for stock symbols."""
from __future__ import annotations

from typing import Dict, List

# Sector → list of NSE symbols (NSE: prefix)
NSE_SECTORS: Dict[str, List[str]] = {
    "banking": [
        "NSE:HDFCBANK",
        "NSE:ICICIBANK",
        "NSE:SBIN",
        "NSE:AXISBANK",
        "NSE:KOTAKBANK",
        "NSE:INDUSINDBK",
        "NSE:BANKBARODA",
        "NSE:PNB",
        "NSE:CANBK",
        "NSE:FEDERALBNK",
    ],
    "it": [
        "NSE:INFY",
        "NSE:TCS",
        "NSE:WIPRO",
        "NSE:HCLTECH",
        "NSE:TECHM",
        "NSE:LTIM",
        "NSE:MPHASIS",
        "NSE:COFORGE",
        "NSE:PERSISTENT",
        "NSE:OFSS",
    ],
    "pharma": [
        "NSE:SUNPHARMA",
        "NSE:DRREDDY",
        "NSE:CIPLA",
        "NSE:DIVISLAB",
        "NSE:BIOCON",
        "NSE:LUPIN",
        "NSE:AUROPHARMA",
        "NSE:IPCALAB",
        "NSE:TORNTPHARM",
        "NSE:GLENMARK",
    ],
    "auto": [
        "NSE:MARUTI",
        "NSE:TATAMOTORS",
        "NSE:BAJAJ-AUTO",
        "NSE:EICHERMOT",
        "NSE:M&M",
        "NSE:ASHOKLEY",
        "NSE:TVSMOTOR",
        "NSE:HEROMOTOCO",
        "NSE:ESCORTS",
        "NSE:BALKRISIND",
    ],
    "fmcg": [
        "NSE:HINDUNILVR",
        "NSE:ITC",
        "NSE:NESTLEIND",
        "NSE:BRITANNIA",
        "NSE:DABUR",
        "NSE:MARICO",
        "NSE:COLPAL",
        "NSE:GODREJCP",
        "NSE:EMAMILTD",
        "NSE:PIDILITIND",
    ],
    "metals": [
        "NSE:TATASTEEL",
        "NSE:HINDALCO",
        "NSE:JSWSTEEL",
        "NSE:SAIL",
        "NSE:NMDC",
        "NSE:NATIONALUM",
        "NSE:JINDALSTEL",
        "NSE:APLAPOLLO",
        "NSE:VEDL",
        "NSE:RATNAMANI",
    ],
    "energy": [
        "NSE:RELIANCE",
        "NSE:ONGC",
        "NSE:BPCL",
        "NSE:IOC",
        "NSE:HINDPETRO",
        "NSE:GAIL",
        "NSE:OIL",
        "NSE:MRPL",
        "NSE:POWERGRID",
        "NSE:NTPC",
    ],
    "realty": [
        "NSE:DLF",
        "NSE:GODREJPROP",
        "NSE:OBEROIRLTY",
        "NSE:PHOENIXLTD",
        "NSE:PRESTIGE",
        "NSE:SUNTECK",
        "NSE:BRIGADE",
        "NSE:SOBHA",
        "NSE:MAHLIFE",
        "NSE:LODHA",
    ],
    "financial_services": [
        "NSE:BAJFINANCE",
        "NSE:BAJAJFINSV",
        "NSE:HDFCLIFE",
        "NSE:SBILIFE",
        "NSE:ICICIGI",
        "NSE:CHOLAFIN",
        "NSE:MUTHOOTFIN",
        "NSE:MANAPPURAM",
        "NSE:LICHSGFIN",
        "NSE:M&MFIN",
    ],
    "infrastructure": [
        "NSE:LARSEN",
        "NSE:ADANIPORTS",
        "NSE:GMRINFRA",
        "NSE:IRB",
        "NSE:KEC",
        "NSE:GRINFRA",
        "NSE:SIEMENS",
        "NSE:ABB",
        "NSE:CUMMINSIND",
        "NSE:BHEL",
    ],
    "telecom": [
        "NSE:BHARTIARTL",
        "NSE:RCOM",
        "NSE:TATACOMM",
        "NSE:IDEA",
        "NSE:HFCL",
    ],
    "consumer_durables": [
        "NSE:TITAN",
        "NSE:HAVELLS",
        "NSE:VOLTAS",
        "NSE:WHIRLPOOL",
        "NSE:SYMPHONY",
        "NSE:BLUESTARCO",
        "NSE:KAJARIACER",
    ],
    "chemicals": [
        "NSE:AAVAS",
        "NSE:ASAHIINDIA",
        "NSE:CLEAN",
        "NSE:DEEPAKNI",
        "NSE:GNFC",
        "NSE:NAVINFLUOR",
        "NSE:NOCIL",
        "NSE:AAPL",
        "NSE:SRF",
        "NSE:VINATI",
    ],
}

# Build a reverse lookup: symbol → sector
_SYMBOL_TO_SECTOR: Dict[str, str] = {}
for _sector, _symbols in NSE_SECTORS.items():
    for _sym in _symbols:
        _SYMBOL_TO_SECTOR[_sym.upper()] = _sector


def get_sector(symbol: str) -> str:
    """Return the sector for an NSE symbol, or 'other' if not classified."""
    return _SYMBOL_TO_SECTOR.get(symbol.upper(), "other")


def get_symbols_by_sector(sector: str) -> List[str]:
    """Return list of NSE symbols for a given sector."""
    return list(NSE_SECTORS.get(sector.lower(), []))


def get_all_sectors() -> List[str]:
    """Return list of all available NSE sectors."""
    return list(NSE_SECTORS.keys())


def get_currency(symbol: str) -> str:  # noqa: ARG001
    """All NSE symbols trade in INR."""
    return "INR"


def get_sector_meta(sector: str) -> Dict[str, object]:
    """Return metadata for a sector."""
    symbols = get_symbols_by_sector(sector)
    return {
        "sector": sector,
        "symbol_count": len(symbols),
        "exchange": "NSE",
        "currency": "INR",
    }
