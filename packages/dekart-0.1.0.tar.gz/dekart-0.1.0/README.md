# dekart-cli
Standalone Dekart CLI.

## Install

```bash
pip install -e .
```

After install, command is:

```bash
dekart --help
```

## Config and auth

```bash
dekart config --url http://localhost:3000
dekart init
```

Config and token are stored under:

- `~/.config/dekart/config.json`
- `~/.config/dekart/token.json`

## MCP tools

```bash
dekart tools --json
dekart call --name create_report --args '{}'
dekart upload-file --file /tmp/result.csv --file-id <file-id>
```
