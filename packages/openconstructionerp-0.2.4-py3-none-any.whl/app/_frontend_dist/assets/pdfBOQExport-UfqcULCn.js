import{c as b,ah as x}from"./index-wOo9T9bb.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=b("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);function w(i){return i.split(/\r?\n/).filter(s=>s.trim()).map(s=>{const n=[];let t="",r=!1;for(const c of s)c==='"'?r=!r:(c===","||c===";"||c==="	")&&!r?(n.push(t.trim()),t=""):t+=c;return n.push(t.trim()),n})}function S(i){const e={},s=i.map(n=>n.toLowerCase().trim());for(let n=0;n<s.length;n++){const t=s[n]??"";if(!t)continue;const r=String(n);/^(ordinal|pos|no\.?|item|ref|code)$/i.test(t)?e.ordinal=r:/^(description|desc|text|bezeichnung|libellé|désignation)$/i.test(t)?e.description=r:/^(unit|uom|einheit|unité)$/i.test(t)?e.unit=r:/^(qty|quantity|menge|quantité)$/i.test(t)?e.quantity=r:/^(rate|unit.?rate|price|ep|einheitspreis|prix.?unitaire)$/i.test(t)?e.unitRate=r:/^(total|amount|gp|gesamtpreis|montant)$/i.test(t)?e.total=r:/^(section|group|trade|lot|gewerk)$/i.test(t)?e.section=r:/^(class|classification|code|nrm|masterformat|din)$/i.test(t)&&(e.classification=r)}return e}function g(i){const e=i.replace(/[^\d.,\-]/g,"");return e?/\d\.\d{3}(,|$)/.test(e)?parseFloat(e.replace(/\./g,"").replace(",","."))||0:parseFloat(e.replace(",","."))||0:0}function C(i,e,s=!0){const n=s?i.slice(1):i,t=[],r=[],c=[];for(let o=0;o<n.length;o++){const d=n[o];if(!d||d.every(p=>!p))continue;const l=p=>{const y=e[p];return y==null?"":d[parseInt(y,10)]??""},h=l("description");if(!h)continue;const a=g(l("quantity")),f=g(l("unitRate")),m=l("total"),$=m&&g(m)||a*f;t.push({ordinal:l("ordinal")||String(o+1),description:h,unit:l("unit")||"pcs",quantity:a,unitRate:f,total:$,section:l("section")||void 0,classification:l("classification")?{code:l("classification")}:void 0})}return t.length===0&&c.push("No valid positions found in the file."),{positions:t,warnings:r,errors:c,metadata:{positionCount:t.length,totalValue:t.reduce((o,d)=>o+d.total,0)}}}async function P(i,e){const s=await i.text(),n=w(s);if(n.length<2)return{positions:[],warnings:[],errors:["File is empty or has insufficient data."]};const t=e??S(n[0]);return C(n,t)}function u(i){return i.includes(",")||i.includes('"')||i.includes(`
`)||i.includes(";")?`"${i.replace(/"/g,'""')}"`:i}function F(i,e,s){const n=(s==null?void 0:s.separator)??",",t=(s==null?void 0:s.includePrices)??!0,r=["No.","Description","Unit","Quantity"];t&&r.push("Unit Rate","Total"),e.classification&&r.push(e.classification),i.some(o=>o.section)&&r.push("Section");const c=[r.map(u).join(n)];for(const o of i){if(o.isSection){c.push([u(o.ordinal),u(`** ${o.description} **`),"","",...t?["",""]:[]].join(n));continue}const d=[u(o.ordinal),u(o.description),u(o.unit),o.quantity.toFixed(3)];if(t&&d.push(o.unitRate.toFixed(2),o.total.toFixed(2)),e.classification&&o.classification){const l=Object.values(o.classification)[0]??"";d.push(u(l))}i.some(l=>l.section)&&d.push(u(o.section??"")),c.push(d.join(n))}return c.join(`\r
`)}function R(i,e,s,n){const t=F(i,e,n);return{blob:new Blob(["\uFEFF"+t],{type:"text/csv;charset=utf-8"}),filename:s.endsWith(".csv")?s:`${s}.csv`,positionCount:i.filter(c=>!c.isSection).length,totalValue:i.reduce((c,o)=>c+(o.isSection?0:o.total),0)}}function j(i,e){x(i,e)}function q(i,e,s={}){const{projectName:n="Project",boqName:t="Bill of Quantities",includePrices:r=!0,date:c=new Date().toLocaleDateString()}=s,o=i.reduce((a,f)=>a+(f.isSection?0:f.total),0),d=i.filter(a=>!a.isSection).length,l=a=>`${e.currencySymbol}${a.toLocaleString(void 0,{minimumFractionDigits:2,maximumFractionDigits:2})}`,h=i.map(a=>a.isSection?`<tr class="section"><td colspan="${r?6:4}"><strong>${a.ordinal} ${a.description}</strong></td></tr>`:`<tr>
        <td>${a.ordinal}</td>
        <td>${a.description}</td>
        <td class="center">${a.unit}</td>
        <td class="right">${a.quantity.toFixed(3)}</td>
        ${r?`<td class="right">${l(a.unitRate)}</td><td class="right">${l(a.total)}</td>`:""}
      </tr>`).join(`
`);return`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${t}</title>
<style>
  body { font-family: Arial, sans-serif; font-size: 10pt; margin: 20mm; color: #222; }
  h1 { font-size: 16pt; margin-bottom: 4px; }
  h2 { font-size: 12pt; color: #555; margin-top: 0; }
  .meta { color: #777; font-size: 9pt; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; }
  th { background: #f5f5f5; padding: 6px 8px; text-align: left; border-bottom: 2px solid #ddd; font-size: 9pt; }
  td { padding: 4px 8px; border-bottom: 1px solid #eee; }
  .right { text-align: right; }
  .center { text-align: center; }
  .section td { background: #f9f9f9; padding: 8px; }
  .total { font-weight: bold; border-top: 2px solid #333; font-size: 11pt; }
  @media print { body { margin: 10mm; } }
</style>
</head><body>
  <h1>${n}</h1>
  <h2>${t} — ${e.name} (${e.country})</h2>
  <div class="meta">${c} | ${d} positions | Standard: ${e.classification} | Currency: ${e.currency}</div>
  <table>
    <thead>
      <tr>
        <th style="width:8%">No.</th>
        <th>Description</th>
        <th style="width:6%" class="center">Unit</th>
        <th style="width:10%" class="right">Qty</th>
        ${r?'<th style="width:12%" class="right">Rate</th><th style="width:12%" class="right">Total</th>':""}
      </tr>
    </thead>
    <tbody>
      ${h}
    </tbody>
    ${r?`<tfoot><tr class="total"><td colspan="5" class="right">Grand Total:</td><td class="right">${l(o)}</td></tr></tfoot>`:""}
  </table>
</body></html>`}function T(i,e,s){const n=q(i,e,s),t=window.open("","_blank");t&&(t.document.write(n),t.document.close(),t.focus(),setTimeout(()=>t.print(),500))}export{D as P,T as a,j as d,R as e,P as p};
