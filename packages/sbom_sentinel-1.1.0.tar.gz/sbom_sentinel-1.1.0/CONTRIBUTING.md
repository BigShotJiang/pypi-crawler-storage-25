# Contributing

## Development Setup

Install [uv](https://docs.astral.sh/uv/), then:

```bash
git clone https://github.com/Dashtid/sbom-sentinel.git
cd sbom-sentinel
uv sync
```

`uv sync` creates `.venv/`, installs the package in editable mode, and installs all dev dependencies. No manual `pip install` or virtualenv activation needed.

## Running Tests

```bash
uv run pytest
```

Check coverage (must stay at or above 99%):

```bash
uv run pytest --cov=sbom_sentinel --cov-report=term-missing
```

## Code Quality

All three must pass before opening a PR:

```bash
uv run ruff check .            # lint
uv run ruff format --check .   # format check
uv run mypy sbom_sentinel      # type check (strict mode)
```

Fix lint and format issues automatically:

```bash
uv run ruff check --fix .
uv run ruff format .
```

## Submitting a Pull Request

- Branch from `main`: use `feat/short-description` or `fix/issue-summary`
- One logical change per PR; squash commits before merging
- New behaviour requires new tests; changed behaviour requires updated tests
- PR descriptions should explain the *why*, not just the *what*

## Adding Dependencies

Runtime dependencies go in `[project] dependencies` in `pyproject.toml`. Development-only tools go in `[dependency-groups] dev`. After editing, regenerate the lockfile:

```bash
uv lock
```

Commit both `pyproject.toml` and `uv.lock` together.
