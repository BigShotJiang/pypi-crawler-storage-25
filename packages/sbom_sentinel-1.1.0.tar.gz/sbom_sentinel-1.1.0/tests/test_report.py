import json
from pathlib import Path
from typing import Any

import pytest

from sbom_sentinel.pipeline.report import _parse_vex_suppressions, generate

_GRYPE_SAMPLE: dict[str, Any] = {
    "matches": [
        {
            "vulnerability": {
                "id": "CVE-2021-44228",
                "severity": "Critical",
                "description": "Apache Log4j2 JNDI remote code execution vulnerability.",
                "fix": {"versions": ["2.15.0"], "state": "fixed"},
            },
            "artifact": {"name": "log4j-core", "version": "2.14.1"},
        },
        {
            "vulnerability": {
                "id": "CVE-2022-9999",
                "severity": "High",
                "description": "A high severity vulnerability in some-pkg.",
                "fix": {"versions": [], "state": "not-fixed"},
            },
            "artifact": {"name": "some-pkg", "version": "1.0.0"},
        },
        {
            "vulnerability": {
                "id": "CVE-2022-1111",
                "severity": "Medium",
                "description": "A medium severity issue.",
                "fix": {"versions": ["3.1.0"], "state": "fixed"},
            },
            "artifact": {"name": "another-lib", "version": "3.0.0"},
        },
    ]
}


@pytest.fixture
def out_dir(tmp_path: Path) -> Path:
    d = tmp_path / "reports"
    d.mkdir()
    return d


def _write_scan(tmp_path: Path, data: dict[str, Any] | None = None) -> Path:
    scan_file = tmp_path / "scan.json"
    scan_file.write_text(json.dumps(data or _GRYPE_SAMPLE), encoding="utf-8")
    return scan_file


def _write_vex(tmp_path: Path, statements: list[Any]) -> Path:
    doc = {"@context": "https://openvex.dev/ns/v0.2.0", "statements": statements}
    vex_file = tmp_path / "statements.vex.json"
    vex_file.write_text(json.dumps(doc), encoding="utf-8")
    return vex_file


def test_creates_markdown_file(tmp_path: Path, out_dir: Path) -> None:
    result = generate(_write_scan(tmp_path), "TestApp", out_dir, set())
    assert result.exists()
    assert result.suffix == ".md"


def test_output_filename_contains_name(tmp_path: Path, out_dir: Path) -> None:
    result = generate(_write_scan(tmp_path), "MyApp", out_dir, set())
    assert "MyApp" in result.name


def test_summary_table_present(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert "## Summary" in content
    assert "| Critical |" in content
    assert "| High |" in content
    assert "| **Total** |" in content


def test_severity_counts_correct(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert "| Critical | 1 |" in content
    assert "| High | 1 |" in content
    assert "| Medium | 1 |" in content
    assert "| Low | 0 |" in content


def test_kev_marker_applied(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}
    ).read_text()
    assert "CVE-2021-44228 [KEV]" in content


def test_no_kev_marker_without_set(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert "[KEV]" not in content


def test_kev_count_in_summary(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228", "CVE-2022-9999"}
    ).read_text()
    assert "| KEV-Flagged | 2 |" in content


def test_severity_ordering(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert content.index("## Critical") < content.index("## High")
    assert content.index("## High") < content.index("## Medium")


def test_fix_version_shown(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert "2.15.0" in content


def test_no_fix_shown_as_not_available(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "TestApp", out_dir, set()).read_text()
    assert "not available" in content


def test_empty_matches(tmp_path: Path, out_dir: Path) -> None:
    scan_file = tmp_path / "empty.json"
    scan_file.write_text(json.dumps({"matches": []}), encoding="utf-8")
    content = generate(scan_file, "TestApp", out_dir, set()).read_text()
    assert "| **Total** | **0** |" in content


def test_missing_fields_defensive(tmp_path: Path, out_dir: Path) -> None:
    # Grype v1.0 may restructure fields — test that missing keys don't crash.
    minimal = {"matches": [{"vulnerability": {"id": "CVE-2099-0001"}}]}
    scan_file = tmp_path / "minimal.json"
    scan_file.write_text(json.dumps(minimal), encoding="utf-8")
    content = generate(scan_file, "TestApp", out_dir, set()).read_text()
    assert "CVE-2099-0001" in content


def test_long_description_truncated(tmp_path: Path, out_dir: Path) -> None:
    long_desc = "x" * 300
    data = {"matches": [{"vulnerability": {"id": "CVE-2099-0001", "description": long_desc}}]}
    scan_file = tmp_path / "long.json"
    scan_file.write_text(json.dumps(data), encoding="utf-8")
    content = generate(scan_file, "TestApp", out_dir, set()).read_text()
    assert "..." in content
    assert long_desc not in content


# --- unknown severity ---


def test_unknown_severity_bucketed_as_negligible(tmp_path: Path, out_dir: Path) -> None:
    data: dict[str, Any] = {
        "matches": [
            {
                "vulnerability": {"id": "CVE-2099-0001", "severity": "Bogus"},
                "artifact": {"name": "pkg", "version": "1.0"},
            }
        ]
    }
    content = generate(_write_scan(tmp_path, data), "TestApp", out_dir, set()).read_text()
    # Should appear under Negligible section, not crash or create a "Bogus" section
    assert "## Negligible" in content
    assert "CVE-2099-0001" in content
    assert "## Bogus" not in content


# --- SARIF guard ---


def test_sarif_input_raises_valueerror(tmp_path: Path, out_dir: Path) -> None:
    # SARIF files have a "runs" key — report must reject them with a clear message
    # rather than silently producing a report with 0 findings.
    sarif = tmp_path / "scan.sarif"
    sarif.write_text('{"runs": [], "version": "2.1.0"}', encoding="utf-8")
    with pytest.raises(ValueError, match="SARIF"):
        generate(sarif, "TestApp", out_dir, set())


def test_schema_key_also_rejected(tmp_path: Path, out_dir: Path) -> None:
    # Some SARIF writers use $schema without a "runs" key at the top level.
    sarif = tmp_path / "scan.sarif"
    sarif.write_text('{"$schema": "https://json.schemastore.org/sarif-2.1.0.json"}',
                     encoding="utf-8")
    with pytest.raises(ValueError, match="SARIF"):
        generate(sarif, "TestApp", out_dir, set())


# --- VEX tests ---

def test_parse_vex_extracts_not_affected(tmp_path: Path) -> None:
    vex = _write_vex(tmp_path, [
        {
            "vulnerability": {"@id": "https://www.cve.org/CVERecord?id=CVE-2025-1234"},
            "status": "not_affected",
        },
        {
            "vulnerability": {"@id": "CVE-2025-5678"},
            "status": "affected",
        },
    ])
    result = _parse_vex_suppressions(vex)
    assert result == {"CVE-2025-1234"}


def test_parse_vex_bare_cve_id(tmp_path: Path) -> None:
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2024-9999"}, "status": "not_affected"},
    ])
    assert _parse_vex_suppressions(vex) == {"CVE-2024-9999"}


def test_parse_vex_corrupt_file_returns_empty(tmp_path: Path) -> None:
    bad = tmp_path / "bad.vex.json"
    bad.write_text("not json", encoding="utf-8")
    assert _parse_vex_suppressions(bad) == set()


def test_parse_vex_empty_statements(tmp_path: Path) -> None:
    vex = _write_vex(tmp_path, [])
    assert _parse_vex_suppressions(vex) == set()


def test_vex_kev_conflict_shows_warning_section(tmp_path: Path, out_dir: Path) -> None:
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2021-44228"}, "status": "not_affected"},
    ])
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}, vex=vex
    ).read_text()
    assert "VEX Suppressions Conflict with CISA KEV" in content
    assert "CVE-2021-44228" in content
    assert "not_affected" in content


def test_vex_kev_conflict_adds_summary_row(tmp_path: Path, out_dir: Path) -> None:
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2021-44228"}, "status": "not_affected"},
    ])
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}, vex=vex
    ).read_text()
    assert "| VEX-Suppressed KEV | 1 |" in content


def test_vex_no_warning_when_no_kev_overlap(tmp_path: Path, out_dir: Path) -> None:
    # VEX suppresses a CVE that is NOT in KEV — no warning expected.
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2025-9999"}, "status": "not_affected"},
    ])
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}, vex=vex
    ).read_text()
    assert "VEX Suppressions Conflict" not in content


def test_vex_no_warning_without_vex_arg(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}
    ).read_text()
    assert "VEX Suppressions Conflict" not in content


def test_vex_conflict_check_skipped_when_kev_empty(tmp_path: Path, out_dir: Path) -> None:
    # --no-kev means kev set is empty; VEX conflict check is gated on kev being non-empty.
    # No warning should appear even if the suppressed CVE would otherwise be in KEV.
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2021-44228"}, "status": "not_affected"},
    ])
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, set(), vex=vex
    ).read_text()
    assert "VEX Suppressions Conflict" not in content


# --- HTML format ---


def test_html_format_generates_html_file(tmp_path: Path, out_dir: Path) -> None:
    result = generate(_write_scan(tmp_path), "TestApp", out_dir, set(), fmt="html")
    assert result.exists()
    assert result.suffix == ".html"


def test_html_contains_doctype_and_structure(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, set(), fmt="html"
    ).read_text()
    assert content.startswith("<!DOCTYPE html>")
    assert "<html lang=\"en\">" in content
    assert "<title>Vulnerability Report: TestApp</title>" in content
    assert "</body>" in content
    assert "</html>" in content


def test_html_embeds_css(tmp_path: Path, out_dir: Path) -> None:
    # Style must be embedded so the file is standalone (no external assets).
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, set(), fmt="html"
    ).read_text()
    assert "<style>" in content
    assert "</style>" in content
    # No external stylesheets
    assert "href=" not in content or "stylesheet" not in content


def test_html_summary_table(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, set(), fmt="html"
    ).read_text()
    assert "<h2>Summary</h2>" in content
    assert "<table>" in content
    assert ">Critical</td>" in content
    assert ">1</td>" in content


def test_html_severity_sections(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, set(), fmt="html"
    ).read_text()
    assert "Critical (1)" in content
    assert "High (1)" in content
    assert "Medium (1)" in content


def test_html_kev_marker(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}, fmt="html"
    ).read_text()
    assert 'class="kev-tag">KEV</span>' in content


def test_html_vex_conflict_warning(tmp_path: Path, out_dir: Path) -> None:
    vex = _write_vex(tmp_path, [
        {"vulnerability": {"@id": "CVE-2021-44228"}, "status": "not_affected"},
    ])
    content = generate(
        _write_scan(tmp_path), "TestApp", out_dir, {"CVE-2021-44228"}, vex=vex, fmt="html"
    ).read_text()
    assert 'class="warning"' in content
    assert "VEX Suppressions Conflict with CISA KEV" in content
    assert "CVE-2021-44228" in content


def test_html_escapes_user_content(tmp_path: Path, out_dir: Path) -> None:
    # Package names with HTML special chars must be escaped
    data: dict[str, Any] = {
        "matches": [
            {
                "vulnerability": {
                    "id": "CVE-2099-0001",
                    "severity": "High",
                    "description": "<script>alert('xss')</script>",
                },
                "artifact": {"name": "<evil>pkg", "version": "1.0"},
            }
        ]
    }
    content = generate(
        _write_scan(tmp_path, data), "TestApp", out_dir, set(), fmt="html"
    ).read_text()
    # Raw HTML must not appear — must be escaped
    assert "<script>alert" not in content
    assert "&lt;script&gt;" in content
    assert "&lt;evil&gt;pkg" in content


def test_invalid_format_raises(tmp_path: Path, out_dir: Path) -> None:
    with pytest.raises(ValueError, match="Invalid format"):
        generate(_write_scan(tmp_path), "TestApp", out_dir, set(), fmt="pdf")


def test_html_long_description_truncated(tmp_path: Path, out_dir: Path) -> None:
    long_desc = "x" * 300
    data = {"matches": [{"vulnerability": {"id": "CVE-2099-0001", "description": long_desc}}]}
    scan_file = tmp_path / "long.json"
    scan_file.write_text(json.dumps(data), encoding="utf-8")
    content = generate(scan_file, "TestApp", out_dir, set(), fmt="html").read_text()
    assert "..." in content
    assert long_desc not in content


# --- SBOM metadata in header ---


_GRYPE_WITH_META: dict[str, Any] = {
    "matches": [],
    "source": {"type": "directory", "target": "/path/to/myapp"},
    "descriptor": {
        "name": "grype",
        "version": "0.82.1",
        "db": {"built": "2026-03-09T00:31:20Z", "schemaVersion": 5},
    },
}

_SPDX_SAMPLE: dict[str, Any] = {
    "spdxVersion": "SPDX-2.3",
    "creationInfo": {
        "creators": ["Organization: Anchore, Inc", "Tool: syft-1.42.4"],
    },
    "packages": [{"name": f"pkg{i}"} for i in range(947)],
}


def _write_sbom(tmp_path: Path) -> Path:
    f = tmp_path / "app.spdx.json"
    f.write_text(json.dumps(_SPDX_SAMPLE), encoding="utf-8")
    return f


def test_header_includes_scan_target(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set()
    ).read_text()
    assert "**Target:** /path/to/myapp" in content


def test_header_includes_scanner_and_db(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set()
    ).read_text()
    assert "**Scanner:** grype 0.82.1 (DB built 2026-03-09)" in content


def test_header_includes_sbom_info_when_provided(tmp_path: Path, out_dir: Path) -> None:
    sbom = _write_sbom(tmp_path)
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set(), sbom=sbom
    ).read_text()
    assert "SPDX-2.3" in content
    assert "947 packages" in content
    assert "syft-1.42.4" in content


def test_header_omits_sbom_info_when_not_provided(tmp_path: Path, out_dir: Path) -> None:
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set()
    ).read_text()
    assert "**SBOM:**" not in content


def test_header_omits_missing_fields_silently(tmp_path: Path, out_dir: Path) -> None:
    # Old / minimal Grype JSON without descriptor or source — must not crash.
    minimal: dict[str, Any] = {"matches": []}
    content = generate(
        _write_scan(tmp_path, minimal), "App", out_dir, set()
    ).read_text()
    assert "**Target:**" not in content
    assert "**Scanner:**" not in content


def test_header_handles_corrupt_sbom_gracefully(tmp_path: Path, out_dir: Path) -> None:
    bad_sbom = tmp_path / "bad.spdx.json"
    bad_sbom.write_text("not json", encoding="utf-8")
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set(), sbom=bad_sbom
    ).read_text()
    # Scanner/Target still rendered; SBOM line silently dropped.
    assert "**Scanner:**" in content
    assert "**SBOM:**" not in content


def test_html_header_includes_metadata(tmp_path: Path, out_dir: Path) -> None:
    sbom = _write_sbom(tmp_path)
    content = generate(
        _write_scan(tmp_path, _GRYPE_WITH_META), "App", out_dir, set(),
        sbom=sbom, fmt="html",
    ).read_text()
    assert "<strong>Target:</strong> /path/to/myapp" in content
    assert "<strong>Scanner:</strong> grype 0.82.1 (DB built 2026-03-09)" in content
    assert "947 packages" in content


def test_markdown_includes_assessment_placeholder(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "App", out_dir, set()).read_text()
    assert "**Assessment:**" in content
    assert "**Conclusion:**" in content
    # Placeholder hint visible to user
    assert "Not applicable" in content


def test_each_cve_gets_its_own_placeholder_block(tmp_path: Path, out_dir: Path) -> None:
    content = generate(_write_scan(tmp_path), "App", out_dir, set()).read_text()
    # _GRYPE_SAMPLE has 3 CVEs; expect 3 of each placeholder.
    assert content.count("**Assessment:**") == 3
    assert content.count("**Conclusion:**") == 3
