from sbom_sentinel.support.log import strip_ansi


def test_strip_ansi_removes_color_codes() -> None:
    assert strip_ansi("\x1b[31mred\x1b[0m") == "red"


def test_strip_ansi_removes_multi_attribute_codes() -> None:
    # Bold + color combos use semicolon-separated parameters.
    assert strip_ansi("\x1b[1;31mbold red\x1b[0m") == "bold red"


def test_strip_ansi_preserves_plain_text() -> None:
    assert strip_ansi("plain text") == "plain text"


def test_strip_ansi_preserves_other_escapes() -> None:
    # Only CSI SGR (color/style) sequences are stripped — keep newlines etc.
    assert strip_ansi("line1\nline2") == "line1\nline2"
