import logging
import subprocess
from collections.abc import Iterator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from sbom_sentinel.pipeline.scan import (
    ThresholdTriggered,
    _grype_db_age_days,
    _grype_version,
    _log_grype_db_status,
    run,
)


def _make_result(stdout: str = "{}", returncode: int = 0, stderr: str = "") -> MagicMock:
    r = MagicMock()
    r.stdout = stdout
    r.returncode = returncode
    r.stderr = stderr
    return r


@pytest.fixture
def grype_found() -> Iterator[None]:
    with patch("sbom_sentinel.pipeline.scan.shutil.which", return_value="/usr/bin/grype"):
        yield


def test_run_writes_output(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result('{"matches":[]}')):
        result = run(sbom_file, "app", tmp_path / "out", None)
    assert result.exists()
    assert result.suffix == ".json"
    assert "app" in result.name


def test_run_calls_grype_with_sbom_arg(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "grype"
    assert f"sbom:{sbom_file}" in cmd
    assert "--by-cve" in cmd


def test_run_fail_on_added_to_cmd(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", "high")
    cmd = mock_run.call_args[0][0]
    assert "--fail-on" in cmd
    assert "high" in cmd


def test_run_no_fail_on_flag_when_none(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert "--fail-on" not in cmd


def test_run_vex_added_to_cmd(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    vex = tmp_path / "statements.vex.json"
    vex.write_text("{}", encoding="utf-8")
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None, vex=vex)
    cmd = mock_run.call_args[0][0]
    assert "--vex" in cmd
    assert str(vex) in cmd


def test_run_no_vex_flag_when_none(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert "--vex" not in cmd


def test_run_sarif_format(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result("<sarif/>")) as mock_run:
        result = run(sbom_file, "app", tmp_path / "out", None, fmt="sarif")
    assert result.suffix == ".sarif"
    cmd = mock_run.call_args[0][0]
    assert "-o" in cmd
    assert "sarif" in cmd


def test_run_fail_on_with_output_raises_threshold_triggered(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # grype exits non-zero but wrote output + fail_on is set -> threshold hit, not an error.
    with patch("subprocess.run", return_value=_make_result(returncode=1)):
        with pytest.raises(ThresholdTriggered) as excinfo:
            run(sbom_file, "app", tmp_path / "out", "high")
    assert excinfo.value.path.exists()
    assert excinfo.value.returncode == 1


def test_run_nonzero_without_fail_on_raises_calledprocesserror(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # Without --fail-on, a non-zero grype exit is a real scan failure.
    with patch("subprocess.run", return_value=_make_result(returncode=1)):
        with pytest.raises(subprocess.CalledProcessError):
            run(sbom_file, "app", tmp_path / "out", None)


def test_run_output_written_before_raising(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # Results file must exist so the report stage can still run after a --fail-on exit.
    out_dir = tmp_path / "out"
    with patch("subprocess.run", return_value=_make_result('{"matches":[]}', returncode=1)):
        with pytest.raises(ThresholdTriggered):
            run(sbom_file, "app", out_dir, "high")
    files = list(out_dir.glob("*.json"))
    assert len(files) == 1


def test_run_grype_not_found(sbom_file: Path, tmp_path: Path) -> None:
    with patch("sbom_sentinel.pipeline.scan.shutil.which", return_value=None):
        with pytest.raises(OSError, match="grype not found"):
            run(sbom_file, "app", tmp_path / "out", None)


def test_run_invalid_format(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Invalid format"):
        run(sbom_file, "app", tmp_path / "out", None, fmt="xml")


def test_run_invalid_fail_on(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Invalid --fail-on"):
        run(sbom_file, "app", tmp_path / "out", "extreme")


def test_run_logs_stderr_on_failure(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    # Covers the stderr logging branch inside the non-zero exit handler.
    with patch("subprocess.run", return_value=_make_result(returncode=1, stderr="db error")):
        with pytest.raises(subprocess.CalledProcessError):
            run(sbom_file, "app", tmp_path / "out", None)


def _capture_logs(logger_name: str) -> tuple[logging.Logger, list[logging.LogRecord]]:
    """Attach a list-collecting handler to a logger, bypassing propagate=False
    set by setup_logging() in other tests."""
    records: list[logging.LogRecord] = []

    class _Capture(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            records.append(record)

    logger = logging.getLogger(logger_name)
    logger.addHandler(_Capture())
    logger.setLevel(logging.DEBUG)
    return logger, records


def test_threshold_stderr_logged_at_info_not_error(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # When --fail-on triggers, grype's stderr is expected output. Logging it
    # as ERROR causes false alarms in monitoring; must be INFO instead.
    msg = "discovered vulnerabilities at or above the severity threshold"
    _, records = _capture_logs("sbom_sentinel.pipeline.scan")
    with patch("subprocess.run", return_value=_make_result(returncode=1, stderr=msg)):
        with pytest.raises(ThresholdTriggered):
            run(sbom_file, "app", tmp_path / "out", "critical")
    matching = [r for r in records if msg in r.getMessage()]
    assert matching, "grype stderr should appear in logs"
    assert all(r.levelname == "INFO" for r in matching), \
        "threshold-triggered stderr must be INFO, not ERROR"


def test_threshold_stderr_ansi_stripped(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # Grype emits ANSI color codes by default; they must be stripped before logging.
    colored = "\x1b[31mdiscovered vulnerabilities\x1b[0m"
    _, records = _capture_logs("sbom_sentinel.pipeline.scan")
    with patch("subprocess.run", return_value=_make_result(returncode=1, stderr=colored)):
        with pytest.raises(ThresholdTriggered):
            run(sbom_file, "app", tmp_path / "out", "critical")
    logged = "\n".join(r.getMessage() for r in records)
    assert "\x1b[" not in logged
    assert "discovered vulnerabilities" in logged


def test_run_no_stdout_raises(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    # grype exits zero but emits nothing — returning a non-existent path would
    # cause a FileNotFoundError in the report stage; raise early with a clear message.
    with patch("subprocess.run", return_value=_make_result(stdout="")):
        with pytest.raises(OSError, match="no output on stdout"):
            run(sbom_file, "app", tmp_path / "out", None)


def test_grype_version_returns_stdout() -> None:
    with patch("subprocess.run", return_value=_make_result(stdout="grype 0.95.4\n")):
        assert _grype_version() == "grype 0.95.4"


def test_grype_version_returns_unknown_on_failure() -> None:
    with patch("subprocess.run", side_effect=FileNotFoundError):
        assert _grype_version() == "unknown"


def test_grype_db_age_parses_built_field() -> None:
    # Real grype emits "Built:  2026-03-09 00:31:20 +0000 UTC".
    stdout = (
        "Location:  /tmp/grype/db/5\n"
        "Built:     2026-03-09 00:31:20 +0000 UTC\n"
        "Schema:    5\n"
    )
    with patch("subprocess.run", return_value=_make_result(stdout=stdout)):
        age = _grype_db_age_days()
    assert age is not None
    assert age >= 0


def test_grype_db_age_parses_iso_t_format() -> None:
    # Some grype versions/builds may emit ISO 8601 with a T separator.
    stdout = "Built:     2026-03-09T00:31:20\n"
    with patch("subprocess.run", return_value=_make_result(stdout=stdout)):
        age = _grype_db_age_days()
    assert age is not None
    assert age >= 0


def test_grype_db_age_returns_none_when_no_built_line() -> None:
    with patch("subprocess.run", return_value=_make_result(stdout="Status: Active\n")):
        assert _grype_db_age_days() is None


def test_grype_db_age_returns_none_on_subprocess_failure() -> None:
    with patch("subprocess.run", side_effect=FileNotFoundError):
        assert _grype_db_age_days() is None


def test_log_grype_db_status_warns_when_stale() -> None:
    _, records = _capture_logs("sbom_sentinel.pipeline.scan")
    with patch("sbom_sentinel.pipeline.scan._grype_db_age_days", return_value=30):
        _log_grype_db_status()
    warns = [r for r in records if r.levelname == "WARNING"]
    assert any("30 days ago" in r.getMessage() for r in warns)
    assert any("grype db update" in r.getMessage() for r in warns)


def test_log_grype_db_status_info_when_fresh() -> None:
    _, records = _capture_logs("sbom_sentinel.pipeline.scan")
    with patch("sbom_sentinel.pipeline.scan._grype_db_age_days", return_value=3):
        _log_grype_db_status()
    assert not any(r.levelname == "WARNING" for r in records)
    assert any("3 days ago" in r.getMessage() and r.levelname == "INFO" for r in records)
