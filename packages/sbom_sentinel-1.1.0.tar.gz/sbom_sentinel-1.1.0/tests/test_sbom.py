import subprocess
from collections.abc import Iterator
from pathlib import Path
from unittest.mock import patch

import pytest

from sbom_sentinel.pipeline.sbom import _syft_version, generate


def _ok_result(**overrides: object) -> subprocess.CompletedProcess[str]:
    defaults: dict[str, object] = {"args": [], "returncode": 0, "stdout": "", "stderr": ""}
    defaults.update(overrides)
    return subprocess.CompletedProcess(**defaults)  # type: ignore[arg-type]


@pytest.fixture
def syft_found() -> Iterator[None]:
    with patch("sbom_sentinel.pipeline.sbom.shutil.which", return_value="/usr/bin/syft"):
        yield


@pytest.fixture
def syft_and_git_found() -> Iterator[None]:
    def which(cmd: str) -> str | None:
        return f"/usr/bin/{cmd}" if cmd in ("syft", "git") else None

    with patch("sbom_sentinel.pipeline.sbom.shutil.which", side_effect=which):
        yield


def test_generate_returns_spdx_json_path(syft_found: None, tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    with patch("subprocess.run", return_value=_ok_result()):
        result = generate(str(src), "app", tmp_path / "out")
    assert result.suffix == ".json"
    assert result.name.endswith(".spdx.json")
    assert "app" in result.name


def test_generate_creates_output_dir(syft_found: None, tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    out = tmp_path / "deep" / "nested" / "out"
    with patch("subprocess.run", return_value=_ok_result()):
        generate(str(src), "app", out)
    assert out.is_dir()


def test_generate_calls_syft_with_spdx_json(syft_found: None, tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    with patch("subprocess.run", return_value=_ok_result()) as mock_run:
        generate(str(src), "app", tmp_path / "out")
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "syft"
    assert any("spdx-json=" in arg for arg in cmd)
    assert "-q" in cmd


def test_generate_syft_not_found(tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    with patch("sbom_sentinel.pipeline.sbom.shutil.which", return_value=None):
        with pytest.raises(OSError, match="syft not found"):
            generate(str(src), "app", tmp_path / "out")


def test_generate_git_url_clones_first(syft_and_git_found: None, tmp_path: Path) -> None:
    clone = str(tmp_path / "clone")
    with patch("subprocess.run", return_value=_ok_result()) as mock_run:
        with patch("sbom_sentinel.pipeline.sbom.tempfile.mkdtemp", return_value=clone):
            with patch("sbom_sentinel.pipeline.sbom.shutil.rmtree"):
                generate("https://github.com/user/repo", "app", tmp_path / "out")

    calls = [c[0][0] for c in mock_run.call_args_list]
    git_call = next((c for c in calls if c[0] == "git"), None)
    syft_call = next((c for c in calls if c[0] == "syft"), None)
    assert git_call is not None, "git clone was not called"
    assert "clone" in git_call
    assert "--depth" in git_call
    assert syft_call is not None, "syft was not called after clone"


def test_generate_git_cleans_up_on_syft_failure(syft_and_git_found: None, tmp_path: Path) -> None:
    clone_dir = str(tmp_path / "clone")

    def fake_run(cmd, **kwargs):
        if cmd[0] == "syft":
            raise Exception("syft crashed")
        return _ok_result()

    with patch("subprocess.run", side_effect=fake_run):
        with patch("sbom_sentinel.pipeline.sbom.tempfile.mkdtemp", return_value=clone_dir):
            with patch("sbom_sentinel.pipeline.sbom.shutil.rmtree") as mock_rmtree:
                with pytest.raises(Exception, match="syft crashed"):
                    generate("https://github.com/user/repo", "app", tmp_path / "out")
    mock_rmtree.assert_called_once_with(clone_dir, ignore_errors=True)


def test_syft_failure_logs_stderr(syft_found: None, tmp_path: Path) -> None:
    src = tmp_path / "src"
    src.mkdir()
    with patch("subprocess.run", return_value=_ok_result(returncode=1, stderr="syft: error")):
        with pytest.raises(subprocess.CalledProcessError):
            generate(str(src), "app", tmp_path / "out")


def test_git_clone_failure_raises(syft_and_git_found: None, tmp_path: Path) -> None:
    fail = _ok_result(returncode=128, stderr="fatal: not found")
    clone = str(tmp_path / "clone")
    with patch("subprocess.run", return_value=fail):
        with patch("sbom_sentinel.pipeline.sbom.tempfile.mkdtemp", return_value=clone):
            with patch("sbom_sentinel.pipeline.sbom.shutil.rmtree"):
                with pytest.raises(subprocess.CalledProcessError):
                    generate("https://github.com/user/repo", "app", tmp_path / "out")


def test_generate_git_not_found_raises(tmp_path: Path) -> None:
    def which(cmd: str) -> str | None:
        return "/usr/bin/syft" if cmd == "syft" else None

    with patch("sbom_sentinel.pipeline.sbom.shutil.which", side_effect=which):
        with pytest.raises(OSError, match="git not found"):
            generate("https://github.com/user/repo", "app", tmp_path / "out")


def test_syft_version_returns_stdout() -> None:
    with patch("subprocess.run", return_value=_ok_result(stdout="syft 1.16.0\n")):
        assert _syft_version() == "syft 1.16.0"


def test_syft_version_returns_unknown_on_failure() -> None:
    with patch("subprocess.run", side_effect=FileNotFoundError):
        assert _syft_version() == "unknown"


def test_syft_version_returns_unknown_on_empty_output() -> None:
    with patch("subprocess.run", return_value=_ok_result(stdout="")):
        assert _syft_version() == "unknown"
