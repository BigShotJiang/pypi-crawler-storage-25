import json
from pathlib import Path
from typing import Any

import pytest

from sbom_sentinel.pipeline.diff import generate


def _match(cve: str, severity: str, pkg: str = "pkg", version: str = "1.0") -> dict[str, Any]:
    return {
        "vulnerability": {"id": cve, "severity": severity},
        "artifact": {"name": pkg, "version": version},
    }


def _write_scan(path: Path, matches: list[dict[str, Any]]) -> Path:
    path.write_text(json.dumps({"matches": matches}), encoding="utf-8")
    return path


@pytest.fixture
def out_dir(tmp_path: Path) -> Path:
    d = tmp_path / "reports"
    d.mkdir()
    return d


@pytest.fixture
def old_scan(tmp_path: Path) -> Path:
    return _write_scan(
        tmp_path / "old.json",
        [
            _match("CVE-2021-44228", "Critical", "log4j", "2.14.1"),
            _match("CVE-2022-1111", "Medium"),
            _match("CVE-2022-2222", "Low"),
        ],
    )


@pytest.fixture
def new_scan(tmp_path: Path) -> Path:
    return _write_scan(
        tmp_path / "new.json",
        [
            _match("CVE-2021-44228", "Critical", "log4j", "2.14.1"),  # unchanged
            _match("CVE-2023-9999", "High", "openssl", "3.0.0"),       # added
            _match("CVE-2022-2222", "Low"),                             # unchanged
        ],
    )


def test_creates_markdown_file(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    result = generate(old_scan, new_scan, "App", out_dir, set())
    assert result.exists()
    assert result.suffix == ".md"
    assert "diff" in result.name


def test_added_cves_listed(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    content = generate(old_scan, new_scan, "App", out_dir, set()).read_text()
    assert "CVE-2023-9999" in content
    assert "## New Vulnerabilities" in content


def test_removed_cves_listed(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [_match("CVE-2020-0001", "High")])
    new = _write_scan(tmp_path / "new.json", [])
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert "CVE-2020-0001" in content
    assert "## Resolved Vulnerabilities" in content


def test_unchanged_cves_not_in_added_or_removed(
    old_scan: Path, new_scan: Path, out_dir: Path
) -> None:
    content = generate(old_scan, new_scan, "App", out_dir, set()).read_text()
    added_section = content.split("## New Vulnerabilities")[1].split("## Resolved")[0]
    resolved_section = content.split("## Resolved Vulnerabilities")[1]
    assert "CVE-2021-44228" not in added_section
    assert "CVE-2021-44228" not in resolved_section


def test_summary_shows_deltas(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    content = generate(old_scan, new_scan, "App", out_dir, set()).read_text()
    # Old: 1 Critical, 1 Medium, 1 Low; New: 1 Critical, 1 High, 1 Low
    assert "| Critical | 1 | 1 | = 0 |" in content
    assert "| High | 0 | 1 | + 1 |" in content
    assert "| Medium | 1 | 0 | - 1 |" in content


def test_kev_marker_on_added(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(tmp_path / "new.json", [_match("CVE-2021-44228", "Critical")])
    content = generate(old, new, "App", out_dir, {"CVE-2021-44228"}).read_text()
    assert "`CVE-2021-44228` [KEV]" in content
    assert "**New CVEs in CISA KEV:** 1" in content


def test_no_kev_marker_without_set(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(tmp_path / "new.json", [_match("CVE-2021-44228", "Critical")])
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert "[KEV]" not in content


def test_identical_scans_produce_empty_diff(tmp_path: Path, out_dir: Path) -> None:
    matches = [_match("CVE-2021-44228", "Critical")]
    old = _write_scan(tmp_path / "old.json", matches)
    new = _write_scan(tmp_path / "new.json", matches)
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert "_None._" in content
    # Both "New" and "Resolved" sections should say None
    assert content.count("_None._") == 2


def test_empty_scans(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(tmp_path / "new.json", [])
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert "| **Total** | **0** | **0** | **= 0** |" in content


def test_dedup_by_cve_id(tmp_path: Path, out_dir: Path) -> None:
    # Same CVE affecting two packages counts once.
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(
        tmp_path / "new.json",
        [
            _match("CVE-2023-9999", "High", "pkg-a"),
            _match("CVE-2023-9999", "High", "pkg-b"),
        ],
    )
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert "- **New CVEs:** 1" in content


def test_added_sorted_by_severity(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(
        tmp_path / "new.json",
        [
            _match("CVE-0000-0003", "Low"),
            _match("CVE-0000-0001", "Critical"),
            _match("CVE-0000-0002", "High"),
        ],
    )
    content = generate(old, new, "App", out_dir, set()).read_text()
    assert content.index("CVE-0000-0001") < content.index("CVE-0000-0002")
    assert content.index("CVE-0000-0002") < content.index("CVE-0000-0003")


def test_sarif_input_rejected(tmp_path: Path, out_dir: Path) -> None:
    sarif = tmp_path / "scan.sarif"
    sarif.write_text('{"runs": [], "version": "2.1.0"}', encoding="utf-8")
    other = _write_scan(tmp_path / "new.json", [])
    with pytest.raises(ValueError, match="SARIF"):
        generate(sarif, other, "App", out_dir, set())


def test_invalid_format_raises(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    with pytest.raises(ValueError, match="Invalid format"):
        generate(old_scan, new_scan, "App", out_dir, set(), fmt="pdf")


# --- HTML format ---


def test_html_format_generates_html_file(
    old_scan: Path, new_scan: Path, out_dir: Path
) -> None:
    result = generate(old_scan, new_scan, "App", out_dir, set(), fmt="html")
    assert result.suffix == ".html"


def test_html_structure(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    content = generate(old_scan, new_scan, "App", out_dir, set(), fmt="html").read_text()
    assert content.startswith("<!DOCTYPE html>")
    assert "<title>Vulnerability Diff Report: App</title>" in content
    assert "<style>" in content
    assert "</html>" in content


def test_html_delta_classes(old_scan: Path, new_scan: Path, out_dir: Path) -> None:
    content = generate(old_scan, new_scan, "App", out_dir, set(), fmt="html").read_text()
    assert 'class="delta-pos">+1' in content
    assert 'class="delta-neg">-1' in content


def test_html_escapes_user_content(tmp_path: Path, out_dir: Path) -> None:
    old = _write_scan(tmp_path / "old.json", [])
    new = _write_scan(
        tmp_path / "new.json",
        [_match("CVE-2023-0001", "High", "<evil>pkg", "1.0")],
    )
    content = generate(old, new, "App", out_dir, set(), fmt="html").read_text()
    assert "<evil>pkg" not in content
    assert "&lt;evil&gt;pkg" in content
