import json
from datetime import date
from pathlib import Path
from unittest.mock import MagicMock, patch

from sbom_sentinel.support.kev import load

_KEV_SAMPLE = {
    "vulnerabilities": [
        {"cveID": "CVE-2021-44228"},
        {"cveID": "CVE-2021-45046"},
        {"cveID": "CVE-2023-1234"},
    ]
}


def _cache_path(tmp_path: Path) -> Path:
    return tmp_path / f"kev_{date.today().strftime('%Y%m%d')}.json"


def _mock_response() -> MagicMock:
    r = MagicMock()
    r.json.return_value = _KEV_SAMPLE
    r.text = json.dumps(_KEV_SAMPLE)
    r.raise_for_status = MagicMock()
    return r


def test_cache_hit(tmp_path: Path) -> None:
    cache_file = _cache_path(tmp_path)
    cache_file.write_text(json.dumps(_KEV_SAMPLE), encoding="utf-8")

    result = load(tmp_path)

    assert "CVE-2021-44228" in result
    assert "CVE-2021-45046" in result
    assert "CVE-2023-1234" in result
    assert len(result) == 3


def test_cache_hit_does_not_call_requests(tmp_path: Path) -> None:
    _cache_path(tmp_path).write_text(json.dumps(_KEV_SAMPLE), encoding="utf-8")

    with patch("requests.get") as mock_get:
        load(tmp_path)
        mock_get.assert_not_called()


def test_download_on_missing_cache(tmp_path: Path) -> None:
    with patch("requests.get", return_value=_mock_response()) as mock_get:
        result = load(tmp_path)
        mock_get.assert_called_once()

    assert "CVE-2021-44228" in result
    assert len(result) == 3


def test_download_writes_cache(tmp_path: Path) -> None:
    with patch("requests.get", return_value=_mock_response()):
        load(tmp_path)

    assert _cache_path(tmp_path).exists()


def test_graceful_degradation_no_network_no_cache(tmp_path: Path) -> None:
    with patch("requests.get", side_effect=ConnectionError("network error")):
        result = load(tmp_path)

    assert result == set()


def test_graceful_degradation_http_error(tmp_path: Path) -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = Exception("503 Service Unavailable")

    with patch("requests.get", return_value=mock_response):
        result = load(tmp_path)

    assert result == set()


def test_download_cleans_up_stale_caches(tmp_path: Path) -> None:
    # Plant two old cache files
    (tmp_path / "kev_20250101.json").write_text("{}", encoding="utf-8")
    (tmp_path / "kev_20250201.json").write_text("{}", encoding="utf-8")

    with patch("requests.get", return_value=_mock_response()):
        load(tmp_path)

    # Only today's cache should remain
    remaining = list(tmp_path.glob("kev_*.json"))
    assert len(remaining) == 1
    assert remaining[0] == _cache_path(tmp_path)


def test_corrupt_cache_re_downloads(tmp_path: Path) -> None:
    _cache_path(tmp_path).write_text("not valid json", encoding="utf-8")

    with patch("requests.get", return_value=_mock_response()):
        result = load(tmp_path)

    assert "CVE-2021-44228" in result
