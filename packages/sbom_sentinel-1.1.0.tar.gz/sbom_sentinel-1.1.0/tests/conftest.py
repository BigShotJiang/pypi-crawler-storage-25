"""Shared fixtures used across multiple test modules."""
from pathlib import Path

import pytest
from click.testing import CliRunner


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def sbom_file(tmp_path: Path) -> Path:
    f = tmp_path / "app.spdx.json"
    f.write_text("{}", encoding="utf-8")
    return f


@pytest.fixture
def vex_file(tmp_path: Path) -> Path:
    f = tmp_path / "app.vex.json"
    f.write_text('{"statements":[]}', encoding="utf-8")
    return f
