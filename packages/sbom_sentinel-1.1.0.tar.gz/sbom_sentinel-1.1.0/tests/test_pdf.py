"""Tests for pipeline/pdf.py.

Real PDF rendering needs WeasyPrint + GTK runtime; we don't exercise it here.
The render call site is mocked. The parsing, classifying, auto-fill, matrix,
and injection logic are all tested directly.
"""

from pathlib import Path
from unittest.mock import patch

import pytest

from sbom_sentinel.pipeline.pdf import (
    auto_fill,
    build_matrix,
    classify_conclusion,
    find_latest_markdown,
    generate,
    inject_matrix,
    parse_assessments,
    render_matrix_markdown,
)

# --- classify_conclusion ---


@pytest.mark.parametrize("text,expected", [
    ("Not applicable",                            "Not applicable"),
    ("not applicable - vendor confirmed unused",  "Not applicable"),
    ("Acceptable risk after mitigation",          "Acceptable"),
    ("Unacceptable, must be patched",             "Unacceptable"),
    ("UNACCEPTABLE",                              "Unacceptable"),
    ("",                                          "Pending"),
    ("Pending — write Not applicable...",         "Not applicable"),
    ("TBD",                                       "Pending"),
])
def test_classify_conclusion(text: str, expected: str) -> None:
    assert classify_conclusion(text) == expected


def test_classify_unacceptable_takes_priority_over_acceptable() -> None:
    # 'unacceptable' contains 'acceptable'; ensure we don't false-match.
    assert classify_conclusion("Unacceptable: needs immediate patch") == "Unacceptable"


# --- auto_fill heuristic ---


def test_auto_fill_negligible_becomes_not_applicable() -> None:
    assert auto_fill("Negligible", in_kev=False, current="Pending") == "Not applicable"


def test_auto_fill_kev_critical_becomes_unacceptable() -> None:
    assert auto_fill("Critical", in_kev=True, current="Pending") == "Unacceptable"


def test_auto_fill_kev_high_becomes_unacceptable() -> None:
    assert auto_fill("High", in_kev=True, current="Pending") == "Unacceptable"


def test_auto_fill_kev_medium_stays_pending() -> None:
    # KEV-driven escalation only applies to Critical/High.
    assert auto_fill("Medium", in_kev=True, current="Pending") == "Pending"


def test_auto_fill_does_not_override_user_classification() -> None:
    assert auto_fill("Negligible", in_kev=False, current="Acceptable") == "Acceptable"
    assert auto_fill("Critical", in_kev=True, current="Not applicable") == "Not applicable"


def test_auto_fill_pending_critical_no_kev_stays_pending() -> None:
    assert auto_fill("Critical", in_kev=False, current="Pending") == "Pending"


# --- find_latest_markdown ---


def test_find_latest_markdown_picks_lexicographic_max(tmp_path: Path) -> None:
    (tmp_path / "app_20260101_120000.md").write_text("a", encoding="utf-8")
    (tmp_path / "app_20260415_080000.md").write_text("b", encoding="utf-8")
    (tmp_path / "app_20260301_180000.md").write_text("c", encoding="utf-8")
    latest = find_latest_markdown(tmp_path)
    assert latest.name == "app_20260415_080000.md"


def test_find_latest_markdown_raises_when_empty(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="No markdown reports"):
        find_latest_markdown(tmp_path)


def test_find_latest_markdown_raises_when_dir_missing(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="not found"):
        find_latest_markdown(tmp_path / "nonexistent")


# --- parse_assessments + integration ---


_SAMPLE_REPORT = """# Vulnerability Report: Demo

**Generated:** 2026-04-23 11:14:31 UTC

## Summary

| Severity | Count |
|---|---|
| Critical | 1 |

---

## Critical (1)

### CVE-2021-44228 [KEV]

- **Package:** log4j-core 2.14.1
- **Fix:** 2.15.0
- **Severity:** Critical
- **Description:** ...

**Assessment:**
> Vendor confirmed our usage isn't affected.

**Conclusion:**
> Not applicable

---

## Negligible (1)

### CVE-2099-0001

- **Package:** noisy-pkg 1.0
- **Fix:** not available
- **Severity:** Negligible
- **Description:** ...

**Assessment:**
> _Pending._

**Conclusion:**
> _Pending._
"""


def test_parse_assessments_extracts_all_cves() -> None:
    items = parse_assessments(_SAMPLE_REPORT)
    assert {a.cve_id for a in items} == {"CVE-2021-44228", "CVE-2099-0001"}


def test_parse_assessments_user_conclusion_wins_over_heuristic() -> None:
    # User wrote "Not applicable" for the KEV-flagged CVE; heuristic must not
    # override that to Unacceptable.
    items = parse_assessments(_SAMPLE_REPORT)
    log4j = next(a for a in items if a.cve_id == "CVE-2021-44228")
    assert log4j.category == "Not applicable"
    assert log4j.in_kev is True


def test_parse_assessments_negligible_auto_filled() -> None:
    items = parse_assessments(_SAMPLE_REPORT)
    neg = next(a for a in items if a.cve_id == "CVE-2099-0001")
    assert neg.severity == "Negligible"
    assert neg.category == "Not applicable"


def test_parse_assessments_unknown_severity_bucketed() -> None:
    md = """### CVE-2099-0002

- **Severity:** Bogus

**Conclusion:**
> _Pending._
"""
    items = parse_assessments(md)
    # Unknown severity falls through; matrix puts it under Negligible.
    matrix = build_matrix(items)
    # Either Bogus is treated as severity (then Negligible bucket gets it) or
    # auto_fill sees non-Negligible and returns Pending. Just verify it doesn't crash.
    assert sum(sum(c.values()) for c in matrix.values()) == 1


# --- build_matrix + render_matrix_markdown ---


def test_build_matrix_counts_correctly() -> None:
    items = parse_assessments(_SAMPLE_REPORT)
    m = build_matrix(items)
    assert m["Critical"]["Not applicable"] == 1
    assert m["Negligible"]["Not applicable"] == 1
    # Empty cells stay zero.
    assert m["High"]["Acceptable"] == 0


def test_render_matrix_markdown_has_header_and_totals() -> None:
    items = parse_assessments(_SAMPLE_REPORT)
    table = render_matrix_markdown(build_matrix(items))
    assert "## Assessment Matrix" in table
    assert "| Severity |" in table
    assert "| Critical |" in table
    assert "| **Total** |" in table
    assert "**2**" in table  # total Not applicable across all severities


# --- inject_matrix ---


def test_inject_matrix_inserts_after_summary() -> None:
    md = "## Summary\n\n| ... |\n\n---\n\n## Critical (1)\n"
    out = inject_matrix(md, "MATRIX_HERE")
    assert out.index("MATRIX_HERE") < out.index("## Critical")
    assert out.index("## Summary") < out.index("MATRIX_HERE")
    assert "page-break-after" in out


def test_inject_matrix_appends_when_no_separator() -> None:
    md = "Just a heading.\n"
    out = inject_matrix(md, "MATRIX")
    assert "MATRIX" in out


# --- generate (integration, with rendering mocked) ---


def test_generate_writes_pdf_and_returns_path(tmp_path: Path) -> None:
    md_file = tmp_path / "demo_20260423_120000.md"
    md_file.write_text(_SAMPLE_REPORT, encoding="utf-8")
    out_dir = tmp_path / "pdf"
    with patch(
        "sbom_sentinel.pipeline.pdf.markdown_to_pdf",
        side_effect=lambda md, p: (p.parent.mkdir(parents=True, exist_ok=True),
                                   p.write_bytes(b"%PDF-1.4 fake"),
                                   p)[2],
    ):
        result = generate(md_file, out_dir)
    assert result.exists()
    assert result.suffix == ".pdf"
    assert result.parent == out_dir


def test_generate_warns_about_pending_entries(tmp_path: Path) -> None:
    # Build a report where one conclusion stays Pending after the heuristic.
    md = """### CVE-2099-0099

- **Severity:** Medium

**Conclusion:**
> _Pending._
"""
    md_file = tmp_path / "x_20260101_010101.md"
    md_file.write_text(md, encoding="utf-8")

    with patch(
        "sbom_sentinel.pipeline.pdf.markdown_to_pdf",
        side_effect=lambda m, p: (p.parent.mkdir(parents=True, exist_ok=True),
                                  p.write_bytes(b"%PDF"), p)[2],
    ):
        with patch("sbom_sentinel.pipeline.pdf.log") as mock_log:
            generate(md_file, tmp_path / "out")
    # Pending warning fired
    assert any("Pending" in str(c) for c in mock_log.warning.call_args_list)


def test_markdown_to_pdf_raises_when_extra_missing(tmp_path: Path) -> None:
    """If markdown-it or weasyprint can't be imported, raise a friendly error."""
    from sbom_sentinel.pipeline import pdf as pdf_mod
    out = tmp_path / "x.pdf"
    with patch.dict("sys.modules", {"markdown_it": None}):
        with pytest.raises(RuntimeError, match=r"sbom-sentinel\[pdf\]"):
            pdf_mod.markdown_to_pdf("# hi", out)
