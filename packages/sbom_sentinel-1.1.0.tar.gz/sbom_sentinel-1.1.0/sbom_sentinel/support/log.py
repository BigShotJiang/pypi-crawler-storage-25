import atexit
import logging
import os
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def strip_ansi(text: str) -> str:
    """Remove ANSI color/style escape sequences from text. Subprocess output
    from tools like grype includes them by default and they pollute log files."""
    return _ANSI_RE.sub("", text)

_LEVEL_PREFIXES = {
    logging.DEBUG: "[i]",
    logging.INFO: "[+]",
    logging.WARNING: "[!]",
    logging.ERROR: "[-]",
    logging.CRITICAL: "[-]",
}


class _PrefixFormatter(logging.Formatter):
    """Console formatter: [+] module: message"""

    def format(self, record: logging.LogRecord) -> str:
        prefix = _LEVEL_PREFIXES.get(record.levelno, "[?]")
        return f"{prefix} {record.name}: {record.getMessage()}"


class _FileFormatter(logging.Formatter):
    """File formatter: timestamp | LEVEL    | module | message"""

    def __init__(self) -> None:
        super().__init__(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )


def get_logger(name: str) -> logging.Logger:
    """Return a logger. Handlers are configured by setup_logging()."""
    return logging.getLogger(name)


def setup_logging(verbose: int = 0, log_dir: Path = Path("logs")) -> None:
    """Configure console + file logging for the sbom_sentinel logger tree.

    Console handler: level controlled by verbose count.
      0 (default) = WARNING, 1 (-v) = INFO, 2+ (-vv) = DEBUG.

    File handler: always captures DEBUG. Rotates at 5 MB, keeps 3 backups.
    Log file permissions are set to 0o600 (owner read/write only).
    """
    logger = logging.getLogger("sbom_sentinel")
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Console handler
    console_level = max(logging.DEBUG, logging.WARNING - (verbose * 10))
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(console_level)
    console_handler.setFormatter(_PrefixFormatter())
    logger.addHandler(console_handler)

    # File handler
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "sbom-sentinel.log"
    file_handler = RotatingFileHandler(
        log_file, maxBytes=5_000_000, backupCount=3, encoding="utf-8",
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(_FileFormatter())
    logger.addHandler(file_handler)

    # Ensure file handler flushes on exit (sys.exit may skip normal cleanup).
    atexit.register(file_handler.flush)
    atexit.register(file_handler.close)

    # Restrictive permissions (owner read/write only). Skip on Windows where
    # chmod doesn't map to POSIX semantics.
    if os.name != "nt":
        log_file.chmod(0o600)
