import re
from pathlib import Path

# Matches registry/image[:tag][@digest]. Must have at least one slash and
# no leading dot or slash (which would indicate a local path).
# Examples: ghcr.io/user/image:latest  library/ubuntu  namespace/app
_REGISTRY_RE = re.compile(
    r"^[a-zA-Z0-9][a-zA-Z0-9._-]*"   # registry host or namespace prefix
    r"/[a-zA-Z0-9._/\-]+"             # image path (may have additional slashes)
    r"(:[a-zA-Z0-9._-]+)?"            # optional tag
    r"(@sha256:[a-fA-F0-9]+)?$"       # optional digest
)


def resolve(target: str) -> tuple[str, str]:
    """
    Resolve a target string to (type, value).

    Resolution order (first match wins):
      docker:<anything>            -> ("image", target)
      registry:<anything>          -> ("image", target)
      https:// or git@             -> ("git", target)
      registry/image[:tag] pattern -> ("image", target)
      existing local directory     -> ("dir", absolute path)
      existing local file          -> ("file", absolute path)

    Raises ValueError if no rule matches.
    """
    # 1. Explicit docker: or registry: prefix (passed directly to Syft)
    if target.startswith(("docker:", "registry:")):
        return ("image", target)

    # 2. Remote git URL
    if target.startswith("https://") or target.startswith("git@"):
        return ("git", target)

    # 3. Registry image pattern — checked before filesystem so that a name like
    #    "library/ubuntu" is treated as an image rather than a missing local path.
    if _REGISTRY_RE.match(target):
        return ("image", target)

    # 4 & 5. Local filesystem (resolve to absolute path first)
    p = Path(target).resolve()
    if p.is_dir():
        return ("dir", str(p))
    if p.is_file():
        return ("file", str(p))

    raise ValueError(
        f"Cannot resolve target '{target}': not a recognised docker image, git URL, "
        "registry image pattern, or existing local path."
    )
