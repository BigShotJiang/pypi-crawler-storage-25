import html
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

_SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Negligible"]
_VALID_FORMATS = {"markdown", "html"}

_SEVERITY_CLASS = {
    "Critical": "sev-critical",
    "High": "sev-high",
    "Medium": "sev-medium",
    "Low": "sev-low",
    "Negligible": "sev-negligible",
}

# CSS is duplicated from report.py rather than shared. The two reports are small
# and diverging styles (diff adds .delta-pos/.delta-neg) are easier to maintain
# inline than behind a shared module.
_HTML_CSS = """
:root {
    --fg: #1f2328;
    --muted: #57606a;
    --border: #d1d9e0;
    --bg-alt: #f6f8fa;
    --critical: #a40e26;
    --high: #c24f00;
    --medium: #9a6700;
    --low: #0550ae;
    --negligible: #57606a;
    --delta-pos: #a40e26;
    --delta-neg: #1a7f37;
}
* { box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    max-width: 960px;
    margin: 2em auto;
    padding: 0 1.5em;
    color: var(--fg);
    line-height: 1.6;
    font-size: 15px;
}
h1 {
    font-size: 1.8em;
    margin-bottom: 0.2em;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.3em;
}
h2 {
    font-size: 1.3em;
    margin-top: 2em;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.2em;
}
.meta { color: var(--muted); font-size: 0.9em; margin-bottom: 1em; }
.meta div { margin: 0.2em 0; }
table { border-collapse: collapse; margin: 1em 0; min-width: 420px; }
th, td { border: 1px solid var(--border); padding: 6px 13px; text-align: left; }
th { background-color: var(--bg-alt); font-weight: 600; }
td.num { text-align: right; font-variant-numeric: tabular-nums; }
code {
    background: var(--bg-alt);
    padding: 0.15em 0.4em;
    border-radius: 3px;
    font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
    font-size: 0.9em;
}
ul { padding-left: 1.5em; }
li { margin: 0.2em 0; }
.sev-critical { color: var(--critical); }
.sev-high { color: var(--high); }
.sev-medium { color: var(--medium); }
.sev-low { color: var(--low); }
.sev-negligible { color: var(--negligible); }
.delta-pos { color: var(--delta-pos); font-weight: 600; }
.delta-neg { color: var(--delta-neg); font-weight: 600; }
.delta-zero { color: var(--muted); }
.kev-tag {
    display: inline-block;
    background: var(--critical);
    color: white;
    padding: 1px 6px;
    border-radius: 3px;
    font-size: 0.75em;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-left: 0.4em;
}
"""


def _load_matches(scan_file: Path) -> list[dict[str, Any]]:
    raw: dict[str, Any] = json.loads(scan_file.read_text(encoding="utf-8"))
    if "runs" in raw or "$schema" in raw:
        raise ValueError(
            f"{scan_file.name} appears to be a SARIF file. "
            "The diff command requires Grype JSON output (--format json)."
        )
    matches: list[dict[str, Any]] = raw.get("matches", [])
    return matches


def _severity(match: dict[str, Any]) -> str:
    sev = ((match.get("vulnerability") or {}).get("severity") or "Unknown").capitalize()
    return sev if sev in _SEVERITY_ORDER else "Negligible"


def _index_by_cve(matches: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Deduplicate matches by CVE id. A CVE can affect multiple packages but
    the diff is about *which CVEs* are new or gone, not per-package instances."""
    index: dict[str, dict[str, Any]] = {}
    for m in matches:
        cve_id = (m.get("vulnerability") or {}).get("id")
        if cve_id and cve_id not in index:
            index[cve_id] = m
    return index


def _counts(indexed: dict[str, dict[str, Any]]) -> dict[str, int]:
    out = {s: 0 for s in _SEVERITY_ORDER}
    for m in indexed.values():
        out[_severity(m)] += 1
    return out


def _delta(new: int, old: int) -> tuple[str, int]:
    diff = new - old
    if diff > 0:
        return "+", diff
    if diff < 0:
        return "-", -diff
    return "=", 0


def _sort_by_severity(items: dict[str, dict[str, Any]]) -> list[tuple[str, dict[str, Any]]]:
    sev_rank = {s: i for i, s in enumerate(_SEVERITY_ORDER)}
    return sorted(
        items.items(),
        key=lambda kv: (sev_rank.get(_severity(kv[1]), 99), kv[0]),
    )


def generate(
    old_scan: Path,
    new_scan: Path,
    name: str,
    output_dir: Path,
    kev: set[str],
    fmt: str = "markdown",
) -> Path:
    """
    Compare two Grype JSON scan files and write a diff report.

    Findings are deduplicated by CVE id before diffing (the same CVE can affect
    several packages; the diff treats that as one item). Added findings get KEV
    enrichment. Returns the path to the written report.
    """
    if fmt not in _VALID_FORMATS:
        raise ValueError(
            f"Invalid format '{fmt}'. Valid values: {', '.join(sorted(_VALID_FORMATS))}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(tz=UTC)
    ext = "html" if fmt == "html" else "md"
    output_path = output_dir / f"{name}_diff_{now.strftime('%Y%m%d_%H%M%S')}.{ext}"

    old_idx = _index_by_cve(_load_matches(old_scan))
    new_idx = _index_by_cve(_load_matches(new_scan))

    added = {cve: new_idx[cve] for cve in set(new_idx) - set(old_idx)}
    removed = {cve: old_idx[cve] for cve in set(old_idx) - set(new_idx)}

    old_counts = _counts(old_idx)
    new_counts = _counts(new_idx)

    log.info(
        f"Diff: {len(old_idx)} old, {len(new_idx)} new, "
        f"{len(added)} added, {len(removed)} removed"
    )

    if fmt == "html":
        content = _build_html(
            name, old_scan, new_scan, now, old_counts, new_counts, added, removed, kev
        )
    else:
        content = _build_md(
            name, old_scan, new_scan, now, old_counts, new_counts, added, removed, kev
        )

    output_path.write_text(content, encoding="utf-8")
    log.info(f"Diff report written to {output_path}")
    return output_path


def _build_md(
    name: str,
    old_scan: Path,
    new_scan: Path,
    now: datetime,
    old_counts: dict[str, int],
    new_counts: dict[str, int],
    added: dict[str, dict[str, Any]],
    removed: dict[str, dict[str, Any]],
    kev: set[str],
) -> str:
    now_str = now.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    added_kev = sum(1 for cve in added if cve in kev)

    lines: list[str] = []
    lines.append(f"# Vulnerability Diff Report: {name}")
    lines.append("")
    lines.append(f"**Generated:** {now_str}  ")
    lines.append(f"**Old scan:** {old_scan}  ")
    lines.append(f"**New scan:** {new_scan}")
    lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Old | New | Change |")
    lines.append("|---|---|---|---|")
    for severity in _SEVERITY_ORDER:
        old_n = old_counts[severity]
        new_n = new_counts[severity]
        sym, mag = _delta(new_n, old_n)
        lines.append(f"| {severity} | {old_n} | {new_n} | {sym} {mag} |")
    old_total = sum(old_counts.values())
    new_total = sum(new_counts.values())
    sym, mag = _delta(new_total, old_total)
    lines.append(f"| **Total** | **{old_total}** | **{new_total}** | **{sym} {mag}** |")
    lines.append("")
    lines.append(f"- **New CVEs:** {len(added)}")
    lines.append(f"- **Resolved CVEs:** {len(removed)}")
    if added_kev:
        lines.append(f"- **New CVEs in CISA KEV:** {added_kev}")
    lines.append("")

    lines.append("## New Vulnerabilities")
    lines.append("")
    if added:
        for cve_id, match in _sort_by_severity(added):
            severity = _severity(match)
            artifact = match.get("artifact") or {}
            pkg = f"{artifact.get('name', 'unknown')} {artifact.get('version', 'unknown')}"
            kev_marker = " [KEV]" if cve_id in kev else ""
            lines.append(f"- `{cve_id}`{kev_marker} ({severity}) — {pkg}")
    else:
        lines.append("_None._")
    lines.append("")

    lines.append("## Resolved Vulnerabilities")
    lines.append("")
    if removed:
        for cve_id, match in _sort_by_severity(removed):
            severity = _severity(match)
            artifact = match.get("artifact") or {}
            pkg = f"{artifact.get('name', 'unknown')} {artifact.get('version', 'unknown')}"
            lines.append(f"- `{cve_id}` ({severity}) — {pkg}")
    else:
        lines.append("_None._")
    lines.append("")

    return "\n".join(lines)


def _delta_html(new: int, old: int) -> str:
    sym, mag = _delta(new, old)
    if sym == "+":
        return f'<span class="delta-pos">+{mag}</span>'
    if sym == "-":
        return f'<span class="delta-neg">-{mag}</span>'
    return '<span class="delta-zero">= 0</span>'


def _build_html(
    name: str,
    old_scan: Path,
    new_scan: Path,
    now: datetime,
    old_counts: dict[str, int],
    new_counts: dict[str, int],
    added: dict[str, dict[str, Any]],
    removed: dict[str, dict[str, Any]],
    kev: set[str],
) -> str:
    now_str = now.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    added_kev = sum(1 for cve in added if cve in kev)

    parts: list[str] = []
    parts.append("<!DOCTYPE html>")
    parts.append('<html lang="en">')
    parts.append("<head>")
    parts.append('<meta charset="utf-8">')
    parts.append(f"<title>Vulnerability Diff Report: {html.escape(name)}</title>")
    parts.append(f"<style>{_HTML_CSS}</style>")
    parts.append("</head>")
    parts.append("<body>")
    parts.append(f"<h1>Vulnerability Diff Report: {html.escape(name)}</h1>")
    parts.append('<div class="meta">')
    parts.append(f"<div><strong>Generated:</strong> {html.escape(now_str)}</div>")
    parts.append(f"<div><strong>Old scan:</strong> {html.escape(str(old_scan))}</div>")
    parts.append(f"<div><strong>New scan:</strong> {html.escape(str(new_scan))}</div>")
    parts.append("</div>")

    parts.append("<h2>Summary</h2>")
    parts.append("<table>")
    parts.append(
        "<thead><tr><th>Severity</th><th>Old</th><th>New</th><th>Change</th></tr></thead>"
    )
    parts.append("<tbody>")
    for severity in _SEVERITY_ORDER:
        cls = _SEVERITY_CLASS[severity]
        old_n = old_counts[severity]
        new_n = new_counts[severity]
        parts.append(
            f'<tr><td class="{cls}">{severity}</td>'
            f'<td class="num">{old_n}</td>'
            f'<td class="num">{new_n}</td>'
            f'<td class="num">{_delta_html(new_n, old_n)}</td></tr>'
        )
    old_total = sum(old_counts.values())
    new_total = sum(new_counts.values())
    parts.append(
        f"<tr><td><strong>Total</strong></td>"
        f'<td class="num"><strong>{old_total}</strong></td>'
        f'<td class="num"><strong>{new_total}</strong></td>'
        f'<td class="num">{_delta_html(new_total, old_total)}</td></tr>'
    )
    parts.append("</tbody>")
    parts.append("</table>")

    parts.append("<ul>")
    parts.append(f"<li><strong>New CVEs:</strong> {len(added)}</li>")
    parts.append(f"<li><strong>Resolved CVEs:</strong> {len(removed)}</li>")
    if added_kev:
        parts.append(f"<li><strong>New CVEs in CISA KEV:</strong> {added_kev}</li>")
    parts.append("</ul>")

    parts.append("<h2>New Vulnerabilities</h2>")
    if added:
        parts.append("<ul>")
        for cve_id, match in _sort_by_severity(added):
            severity = _severity(match)
            cls = _SEVERITY_CLASS[severity]
            artifact = match.get("artifact") or {}
            pkg_name = artifact.get("name") or "unknown"
            pkg_version = artifact.get("version") or "unknown"
            kev_marker = ' <span class="kev-tag">KEV</span>' if cve_id in kev else ""
            parts.append(
                f"<li><code>{html.escape(cve_id)}</code>{kev_marker} "
                f'<span class="{cls}">({html.escape(severity)})</span> &mdash; '
                f"<code>{html.escape(pkg_name)} {html.escape(pkg_version)}</code></li>"
            )
        parts.append("</ul>")
    else:
        parts.append("<p><em>None.</em></p>")

    parts.append("<h2>Resolved Vulnerabilities</h2>")
    if removed:
        parts.append("<ul>")
        for cve_id, match in _sort_by_severity(removed):
            severity = _severity(match)
            cls = _SEVERITY_CLASS[severity]
            artifact = match.get("artifact") or {}
            pkg_name = artifact.get("name") or "unknown"
            pkg_version = artifact.get("version") or "unknown"
            parts.append(
                f"<li><code>{html.escape(cve_id)}</code> "
                f'<span class="{cls}">({html.escape(severity)})</span> &mdash; '
                f"<code>{html.escape(pkg_name)} {html.escape(pkg_version)}</code></li>"
            )
        parts.append("</ul>")
    else:
        parts.append("<p><em>None.</em></p>")

    parts.append("</body>")
    parts.append("</html>")
    return "\n".join(parts)
