"""
Convert a user-edited markdown vulnerability report to PDF.

Workflow:
  1. `sbom-sentinel run` produces a markdown report with empty Assessment +
     Conclusion blockquote placeholders per CVE.
  2. The user opens the markdown and fills each Conclusion with one of:
     'Not applicable', 'Acceptable', 'Unacceptable'. (Anything else stays
     'Pending' and may be auto-filled by the heuristic below.)
  3. `sbom-sentinel pdf` parses the markdown, classifies each CVE, builds an
     Assessment Matrix table, injects it after the Summary section, and
     renders the result to PDF via markdown-it-py + WeasyPrint.

Auto-fill heuristic (applied only to entries the user left as Pending):
  - Negligible severity     -> Not applicable
  - KEV-flagged Critical/High -> Unacceptable
  - everything else         -> stays Pending (warned about in logs)
"""

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

_SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Negligible"]
_CATEGORIES = ["Not applicable", "Acceptable", "Unacceptable", "Pending"]

# CVE entries are level-3 headings: `### CVE-2021-44228` or `### CVE-XXXX [KEV]`.
_CVE_HEADER_RE = re.compile(r"^###\s+(CVE-\d{4}-\d+)(\s+\[KEV\])?", re.MULTILINE)
_SEVERITY_LINE_RE = re.compile(r"^- \*\*Severity:\*\*\s*(\S+)", re.MULTILINE)
_CONCLUSION_BLOCK_RE = re.compile(
    r"\*\*Conclusion:\*\*\s*\n>\s*(.+?)(?=\n\n|\n###|\n---|\Z)",
    re.DOTALL,
)


@dataclass
class CveAssessment:
    cve_id: str
    severity: str
    in_kev: bool
    raw_conclusion: str
    category: str  # one of _CATEGORIES


def find_latest_markdown(markdown_dir: Path) -> Path:
    """Return the most recent markdown report in markdown_dir, picked by
    filename timestamp (filenames look like `name_YYYYMMDD_HHMMSS.md`)."""
    if not markdown_dir.is_dir():
        raise FileNotFoundError(f"Markdown directory not found: {markdown_dir}")
    candidates = sorted(markdown_dir.glob("*.md"))
    if not candidates:
        raise FileNotFoundError(f"No markdown reports found in {markdown_dir}")
    latest = candidates[-1]
    log.debug(f"Latest markdown report: {latest}")
    return latest


def classify_conclusion(text: str) -> str:
    """Classify free-text conclusion into one of the four categories.

    Order matters: 'unacceptable' contains 'acceptable', so check it first.
    Returns 'Pending' if no recognized keyword is present.
    """
    lower = text.lower()
    if "not applicable" in lower:
        return "Not applicable"
    if "unacceptable" in lower:
        return "Unacceptable"
    if "acceptable" in lower:
        return "Acceptable"
    return "Pending"


def auto_fill(severity: str, in_kev: bool, current: str) -> str:
    """Apply the auto-fill heuristic. Only acts on Pending entries."""
    if current != "Pending":
        return current
    if severity == "Negligible":
        return "Not applicable"
    if in_kev and severity in ("Critical", "High"):
        return "Unacceptable"
    return "Pending"


def parse_assessments(markdown_text: str) -> list[CveAssessment]:
    """Parse the markdown for CVE blocks and return one CveAssessment each."""
    blocks = _split_into_cve_blocks(markdown_text)
    out: list[CveAssessment] = []
    for cve_id, kev_flag, body in blocks:
        sev_match = _SEVERITY_LINE_RE.search(body)
        severity = sev_match.group(1) if sev_match else "Unknown"
        conclusion_match = _CONCLUSION_BLOCK_RE.search(body)
        raw_conclusion = conclusion_match.group(1).strip() if conclusion_match else ""
        category = classify_conclusion(raw_conclusion)
        category = auto_fill(severity, kev_flag, category)
        out.append(CveAssessment(cve_id, severity, kev_flag, raw_conclusion, category))
    return out


def _split_into_cve_blocks(md: str) -> list[tuple[str, bool, str]]:
    """Yield (cve_id, in_kev, body) for each `### CVE-...` block."""
    matches = list(_CVE_HEADER_RE.finditer(md))
    blocks: list[tuple[str, bool, str]] = []
    for i, m in enumerate(matches):
        cve_id = m.group(1)
        in_kev = m.group(2) is not None
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(md)
        blocks.append((cve_id, in_kev, md[start:end]))
    return blocks


def build_matrix(assessments: list[CveAssessment]) -> dict[str, dict[str, int]]:
    """Return {severity: {category: count}} for the assessment matrix table."""
    matrix: dict[str, dict[str, int]] = {
        sev: dict.fromkeys(_CATEGORIES, 0) for sev in _SEVERITY_ORDER
    }
    for a in assessments:
        sev = a.severity if a.severity in _SEVERITY_ORDER else "Negligible"
        matrix[sev][a.category] += 1
    return matrix


def render_matrix_markdown(matrix: dict[str, dict[str, int]]) -> str:
    """Render the matrix as a markdown table."""
    lines = ["## Assessment Matrix", ""]
    header = "| Severity | " + " | ".join(_CATEGORIES) + " |"
    sep = "|" + "|".join(["---"] * (len(_CATEGORIES) + 1)) + "|"
    lines.append(header)
    lines.append(sep)
    totals = dict.fromkeys(_CATEGORIES, 0)
    for sev in _SEVERITY_ORDER:
        cells = [str(matrix[sev][c]) for c in _CATEGORIES]
        for c in _CATEGORIES:
            totals[c] += matrix[sev][c]
        lines.append(f"| {sev} | " + " | ".join(cells) + " |")
    total_cells = [f"**{totals[c]}**" for c in _CATEGORIES]
    lines.append("| **Total** | " + " | ".join(total_cells) + " |")
    lines.append("")
    return "\n".join(lines)


def inject_matrix(md: str, matrix_md: str) -> str:
    """Insert the matrix and a page-break right before the first severity
    section. Falls back to appending if the structure isn't recognized."""
    # Find the first '---' separator that appears AFTER the Summary table.
    summary_idx = md.find("## Summary")
    search_from = summary_idx if summary_idx != -1 else 0
    rule_idx = md.find("\n---\n", search_from)
    block = (
        "\n" + matrix_md
        + '\n<div style="page-break-after: always;"></div>\n'
    )
    if rule_idx == -1:
        return md + block
    return md[:rule_idx] + block + md[rule_idx:]


_PDF_CSS = """
@page { size: A4; margin: 18mm 15mm; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    color: #1f2328;
    line-height: 1.5;
    font-size: 10.5pt;
}
h1 { font-size: 18pt; border-bottom: 1px solid #d1d9e0; padding-bottom: 0.3em; }
h2 { font-size: 13pt; margin-top: 1.6em; border-bottom: 1px solid #d1d9e0; padding-bottom: 0.2em;
     page-break-after: avoid; }
h3 { font-size: 11pt; margin-top: 1.2em; font-family: ui-monospace, Consolas, monospace;
     page-break-after: avoid; }
h3, h3 + ul, h3 + ul + p, h3 + ul + p + blockquote { page-break-inside: avoid; }
table { border-collapse: collapse; margin: 0.8em 0; width: 100%; }
th, td { border: 1px solid #d1d9e0; padding: 5px 10px; text-align: left; }
th { background: #f6f8fa; font-weight: 600; }
code { background: #f6f8fa; padding: 0.1em 0.35em; border-radius: 3px;
       font-family: ui-monospace, Consolas, monospace; font-size: 0.9em; }
blockquote { margin: 0.4em 0 0.8em 0; padding: 0.4em 0.9em; border-left: 3px solid #d1d9e0;
             color: #57606a; background: #f6f8fa; }
ul { padding-left: 1.4em; }
hr { border: none; border-top: 1px solid #d1d9e0; margin: 1.2em 0; }
"""


def markdown_to_pdf(markdown_text: str, output_path: Path) -> Path:
    """Render markdown to PDF via markdown-it-py + WeasyPrint."""
    try:
        from markdown_it import MarkdownIt
        from weasyprint import HTML  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "PDF rendering requires the 'pdf' extra. "
            "Install with: pip install 'sbom-sentinel[pdf]'"
        ) from exc

    md = MarkdownIt("commonmark", {"html": True}).enable("table")
    body_html = md.render(markdown_text)
    full_html = (
        f"<!DOCTYPE html><html><head><meta charset='utf-8'>"
        f"<style>{_PDF_CSS}</style></head>"
        f"<body>{body_html}</body></html>"
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    HTML(string=full_html).write_pdf(str(output_path))
    return output_path


def generate(markdown_file: Path, output_dir: Path) -> Path:
    """Parse, classify, inject the matrix, and render to PDF.

    Returns the path to the written PDF. Logs a WARNING with a count of
    Pending entries if the user hasn't classified everything (the heuristic
    handles Negligible and KEV automatically; everything else is on the user).
    """
    markdown_text = markdown_file.read_text(encoding="utf-8")
    assessments = parse_assessments(markdown_text)
    log.info(f"Parsed {len(assessments)} CVE assessments from {markdown_file.name}")

    matrix = build_matrix(assessments)
    pending = sum(1 for a in assessments if a.category == "Pending")
    if pending:
        log.warning(
            f"{pending} CVE(s) still classified as Pending. "
            "Edit the markdown Conclusion blocks and re-run to finalize."
        )

    matrix_md = render_matrix_markdown(matrix)
    enriched_md = inject_matrix(markdown_text, matrix_md)

    now = datetime.now(tz=UTC)
    output_path = output_dir / (
        markdown_file.stem + f"_{now.strftime('%Y%m%d_%H%M%S')}.pdf"
    )
    markdown_to_pdf(enriched_md, output_path)
    log.info(f"PDF written to {output_path}")
    return output_path
