import html
import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

_SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Negligible"]
_DESCRIPTION_MAX = 200
_CVE_RE = re.compile(r"CVE-\d{4}-\d+", re.IGNORECASE)
_VALID_FORMATS = {"markdown", "html"}


def _parse_vex_suppressions(vex_file: Path) -> set[str]:
    """
    Read a VEX document (OpenVEX or CSAF) and return the set of CVE IDs whose
    status is 'not_affected'. These are the findings Grype silently dropped.

    Extracts CVE IDs from the vulnerability @id field — handles both bare IDs
    ("CVE-2025-1234") and full URLs ("https://www.cve.org/CVERecord?id=CVE-2025-1234").
    Returns empty set on any parse error so the report still generates.
    """
    try:
        doc = json.loads(vex_file.read_text(encoding="utf-8"))
    except Exception as exc:
        log.warning(f"Could not parse VEX document {vex_file}: {exc}")
        return set()

    suppressed: set[str] = set()
    for stmt in doc.get("statements", []):
        if (stmt.get("status") or "").lower() != "not_affected":
            continue
        vuln_id = (stmt.get("vulnerability") or {}).get("@id", "")
        match = _CVE_RE.search(vuln_id)
        if match:
            suppressed.add(match.group(0).upper())

    return suppressed


def generate(
    scan_file: Path,
    name: str,
    output_dir: Path,
    kev: set[str],
    vex: Path | None = None,
    fmt: str = "markdown",
    sbom: Path | None = None,
) -> Path:
    """
    Parse Grype JSON results and write a report to output_dir/<name>_<timestamp>.<ext>.

    fmt: "markdown" (default, .md) or "html" (.html). HTML output is a standalone
    document with embedded CSS — no external assets or JavaScript.

    Parsing is defensive throughout (.get() on all fields) because Grype's JSON schema
    is being redesigned for v1.0 (https://github.com/anchore/grype/issues/3144).

    vex: optional path to the VEX document used during the scan. If provided, the report
    warns about any CVE that was suppressed by VEX AND appears in the CISA KEV catalog —
    suppressing an actively exploited vulnerability is a high-risk decision that must be
    visible to reviewers.

    Returns the path to the written report.
    """
    if fmt not in _VALID_FORMATS:
        raise ValueError(
            f"Invalid format '{fmt}'. Valid values: {', '.join(sorted(_VALID_FORMATS))}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(tz=UTC)
    ext = "html" if fmt == "html" else "md"
    output_path = output_dir / f"{name}_{now.strftime('%Y%m%d_%H%M%S')}.{ext}"

    raw: dict[str, Any] = json.loads(scan_file.read_text(encoding="utf-8"))

    if "runs" in raw or "$schema" in raw:
        raise ValueError(
            f"{scan_file.name} appears to be a SARIF file. "
            "The report command requires Grype JSON output (--format json). "
            "Re-run the scan without --format sarif."
        )

    matches: list[dict[str, Any]] = raw.get("matches", [])
    log.debug(f"Report config: fmt={fmt}, kev_size={len(kev)}, vex={vex}")
    log.debug(f"Parsed {len(matches)} findings from {scan_file.name}")

    by_severity: dict[str, list[dict[str, Any]]] = {s: [] for s in _SEVERITY_ORDER}
    for match in matches:
        vuln: dict[str, Any] = match.get("vulnerability") or {}
        severity = (vuln.get("severity") or "Unknown").capitalize()
        if severity not in by_severity:
            cve_id = vuln.get("id") or "UNKNOWN"
            log.warning(f"Unknown severity '{severity}' for {cve_id}, bucketing as Negligible")
            severity = "Negligible"
        by_severity[severity].append(match)

    counts = {s: len(v) for s, v in by_severity.items() if v}
    kev_count = sum(
        1 for ms in by_severity.values() for m in ms
        if (m.get("vulnerability") or {}).get("id", "") in kev
    )
    log.info(f"Severity breakdown: {counts} (KEV-flagged: {kev_count})")

    suppressed_kev: set[str] = set()
    if vex and kev:
        suppressed = _parse_vex_suppressions(vex)
        suppressed_kev = suppressed & kev
        if suppressed_kev:
            log.warning(
                f"{len(suppressed_kev)} VEX-suppressed finding(s) are in the CISA KEV catalog: "
                + ", ".join(sorted(suppressed_kev))
            )

    meta = _collect_metadata(raw, sbom)

    if fmt == "html":
        content = _build_html_report(
            name, scan_file, now, by_severity, kev, suppressed_kev, meta
        )
    else:
        lines = _build_report(
            name, scan_file, now, by_severity, kev, suppressed_kev, meta
        )
        content = "\n".join(lines)

    output_path.write_text(content, encoding="utf-8")
    log.info(f"Report written to {output_path}")
    return output_path


def _collect_metadata(
    raw: dict[str, Any], sbom: Path | None
) -> list[tuple[str, str]]:
    """Return ordered (label, value) pairs to render in the report header.

    Pulls scan target + Grype version + DB build date from the Grype JSON,
    and (optionally) SPDX format + package count + Syft version from the
    SBOM file. Each field is included only if its source field is present.
    """
    fields: list[tuple[str, str]] = []

    src = raw.get("source") or {}
    target = src.get("target")
    if isinstance(target, dict):
        target = target.get("userInput") or target.get("imageID")
    if target:
        fields.append(("Target", str(target)))

    desc = raw.get("descriptor") or {}
    scanner_name = desc.get("name") or "grype"
    scanner_version = desc.get("version")
    if scanner_version:
        scanner = f"{scanner_name} {scanner_version}"
        db_built = (desc.get("db") or {}).get("built")
        if db_built:
            scanner += f" (DB built {db_built[:10]})"
        fields.append(("Scanner", scanner))

    if sbom and sbom.exists():
        try:
            sbom_data = json.loads(sbom.read_text(encoding="utf-8"))
        except Exception as exc:
            log.debug(f"Could not parse SBOM {sbom}: {exc}")
            return fields
        spdx_ver = sbom_data.get("spdxVersion") or "SPDX"
        pkgs = sbom_data.get("packages")
        pkg_count = len(pkgs) if isinstance(pkgs, list) else None
        creators = (sbom_data.get("creationInfo") or {}).get("creators") or []
        tool = next(
            (
                c.removeprefix("Tool:").strip()
                for c in creators
                if isinstance(c, str) and c.startswith("Tool:")
            ),
            None,
        )
        parts = [spdx_ver]
        if pkg_count is not None:
            parts.append(f"{pkg_count} packages")
        if tool:
            parts.append(tool)
        fields.append(("SBOM", f"{sbom} ({', '.join(parts)})"))

    return fields


def _build_report(
    name: str,
    scan_file: Path,
    now: datetime,
    by_severity: dict[str, list[dict[str, Any]]],
    kev: set[str],
    suppressed_kev: set[str],
    meta: list[tuple[str, str]],
) -> list[str]:
    now_str = now.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    total = sum(len(v) for v in by_severity.values())
    kev_count = sum(
        1
        for matches in by_severity.values()
        for m in matches
        if (m.get("vulnerability") or {}).get("id", "") in kev
    )

    lines: list[str] = []
    lines.append(f"# Vulnerability Report: {name}")
    lines.append("")
    lines.append(f"**Generated:** {now_str}  ")
    for label, value in meta:
        lines.append(f"**{label}:** {value}  ")
    lines.append(f"**Scan file:** {scan_file}")
    lines.append("")
    lines.append(
        "> **How to use this report:** review each CVE below and replace the "
        "**Assessment** and **Conclusion** blockquotes. The Conclusion text must "
        "contain one of: `Not applicable`, `Acceptable`, or `Unacceptable` — that "
        "word drives the Assessment Matrix when you run `sbom-sentinel pdf`."
    )
    lines.append("")

    if suppressed_kev:
        lines.append("## [!] VEX Suppressions Conflict with CISA KEV")
        lines.append("")
        lines.append(
            "The following CVEs were marked `not_affected` in the VEX document and are "
            "therefore absent from the findings below. However, they appear in the "
            "**CISA Known Exploited Vulnerabilities catalog** — meaning they are being "
            "actively exploited in the wild. "
            "Review the VEX justification before accepting this suppression."
        )
        lines.append("")
        for cve_id in sorted(suppressed_kev):
            lines.append(f"- `{cve_id}` [KEV] — suppressed by VEX (`not_affected`)")
        lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("|---|---|")
    for severity in _SEVERITY_ORDER:
        lines.append(f"| {severity} | {len(by_severity[severity])} |")
    lines.append(f"| **Total** | **{total}** |")
    lines.append(f"| KEV-Flagged | {kev_count} |")
    if suppressed_kev:
        lines.append(f"| VEX-Suppressed KEV | {len(suppressed_kev)} |")
    lines.append("")

    for severity in _SEVERITY_ORDER:
        matches = by_severity[severity]
        if not matches:
            continue
        lines.append("---")
        lines.append("")
        lines.append(f"## {severity} ({len(matches)})")
        lines.append("")
        for match in matches:
            lines.extend(_format_match(match, kev))

    return lines


def _format_match(match: dict[str, Any], kev: set[str]) -> list[str]:
    vuln: dict[str, Any] = match.get("vulnerability") or {}
    artifact: dict[str, Any] = match.get("artifact") or {}

    cve_id = vuln.get("id") or "UNKNOWN"
    severity = vuln.get("severity") or "Unknown"
    description = vuln.get("description") or "No description available."
    if len(description) > _DESCRIPTION_MAX:
        description = description[:_DESCRIPTION_MAX].rstrip() + "..."

    pkg_name = artifact.get("name") or "unknown"
    pkg_version = artifact.get("version") or "unknown"

    fix_info: dict[str, Any] = vuln.get("fix") or {}
    fix_versions: list[str] = fix_info.get("versions") or []
    fix_str = fix_versions[0] if fix_versions else "not available"

    kev_marker = " [KEV]" if cve_id in kev else ""

    lines: list[str] = []
    lines.append(f"### {cve_id}{kev_marker}")
    lines.append("")
    lines.append(f"- **Package:** {pkg_name} {pkg_version}")
    lines.append(f"- **Fix:** {fix_str}")
    lines.append(f"- **Severity:** {severity}")
    lines.append(f"- **Description:** {description}")
    lines.append("")
    # Assessment + Conclusion placeholders. The user replaces the blockquote
    # text before running `sbom-sentinel pdf`. Keep the placeholder text free
    # of the classifier keywords (Not applicable / Acceptable / Unacceptable)
    # so unedited entries don't accidentally classify themselves.
    lines.append("**Assessment:**")
    lines.append("> _Pending._")
    lines.append("")
    lines.append("**Conclusion:**")
    lines.append("> _Pending._")
    lines.append("")
    return lines


_HTML_CSS = """
:root {
    --fg: #1f2328;
    --muted: #57606a;
    --border: #d1d9e0;
    --bg-alt: #f6f8fa;
    --critical: #a40e26;
    --high: #c24f00;
    --medium: #9a6700;
    --low: #0550ae;
    --negligible: #57606a;
    --warning-bg: #fff8c5;
    --warning-border: #d4a72c;
}
* { box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    max-width: 960px;
    margin: 2em auto;
    padding: 0 1.5em;
    color: var(--fg);
    line-height: 1.6;
    font-size: 15px;
}
h1 {
    font-size: 1.8em;
    margin-bottom: 0.2em;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.3em;
}
h2 {
    font-size: 1.3em;
    margin-top: 2em;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.2em;
}
h3 {
    font-size: 1.05em;
    margin-top: 1.5em;
    margin-bottom: 0.3em;
    font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
}
.meta {
    color: var(--muted);
    font-size: 0.9em;
    margin-bottom: 1em;
}
.meta div { margin: 0.2em 0; }
table {
    border-collapse: collapse;
    margin: 1em 0;
    min-width: 300px;
}
th, td {
    border: 1px solid var(--border);
    padding: 6px 13px;
    text-align: left;
}
th {
    background-color: var(--bg-alt);
    font-weight: 600;
}
td.num { text-align: right; font-variant-numeric: tabular-nums; }
code {
    background: var(--bg-alt);
    padding: 0.15em 0.4em;
    border-radius: 3px;
    font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
    font-size: 0.9em;
}
ul { padding-left: 1.5em; }
li { margin: 0.2em 0; }
.sev-critical { color: var(--critical); }
.sev-high { color: var(--high); }
.sev-medium { color: var(--medium); }
.sev-low { color: var(--low); }
.sev-negligible { color: var(--negligible); }
.kev-tag {
    display: inline-block;
    background: var(--critical);
    color: white;
    padding: 1px 6px;
    border-radius: 3px;
    font-size: 0.75em;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-left: 0.4em;
    vertical-align: middle;
}
.warning {
    background: var(--warning-bg);
    border-left: 4px solid var(--warning-border);
    padding: 0.8em 1.2em;
    margin: 1.5em 0;
    border-radius: 3px;
}
.warning h2 {
    margin-top: 0;
    border-bottom: none;
    font-size: 1.1em;
}
hr {
    border: none;
    border-top: 1px solid var(--border);
    margin: 2em 0;
}
"""


_SEVERITY_CLASS = {
    "Critical": "sev-critical",
    "High": "sev-high",
    "Medium": "sev-medium",
    "Low": "sev-low",
    "Negligible": "sev-negligible",
}


def _build_html_report(
    name: str,
    scan_file: Path,
    now: datetime,
    by_severity: dict[str, list[dict[str, Any]]],
    kev: set[str],
    suppressed_kev: set[str],
    meta: list[tuple[str, str]],
) -> str:
    now_str = now.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    total = sum(len(v) for v in by_severity.values())
    kev_count = sum(
        1
        for matches in by_severity.values()
        for m in matches
        if (m.get("vulnerability") or {}).get("id", "") in kev
    )

    parts: list[str] = []
    parts.append("<!DOCTYPE html>")
    parts.append('<html lang="en">')
    parts.append("<head>")
    parts.append('<meta charset="utf-8">')
    parts.append(f"<title>Vulnerability Report: {html.escape(name)}</title>")
    parts.append(f"<style>{_HTML_CSS}</style>")
    parts.append("</head>")
    parts.append("<body>")
    parts.append(f"<h1>Vulnerability Report: {html.escape(name)}</h1>")
    parts.append('<div class="meta">')
    parts.append(f"<div><strong>Generated:</strong> {html.escape(now_str)}</div>")
    for label, value in meta:
        parts.append(
            f"<div><strong>{html.escape(label)}:</strong> {html.escape(value)}</div>"
        )
    parts.append(f"<div><strong>Scan file:</strong> {html.escape(str(scan_file))}</div>")
    parts.append("</div>")

    if suppressed_kev:
        parts.append('<div class="warning">')
        parts.append("<h2>VEX Suppressions Conflict with CISA KEV</h2>")
        parts.append(
            "<p>The following CVEs were marked <code>not_affected</code> in the VEX "
            "document and are therefore absent from the findings below. However, they "
            "appear in the <strong>CISA Known Exploited Vulnerabilities catalog</strong> "
            "&mdash; meaning they are being actively exploited in the wild. Review the "
            "VEX justification before accepting this suppression.</p>"
        )
        parts.append("<ul>")
        for cve_id in sorted(suppressed_kev):
            parts.append(
                f"<li><code>{html.escape(cve_id)}</code> "
                '<span class="kev-tag">KEV</span> '
                "&mdash; suppressed by VEX (<code>not_affected</code>)</li>"
            )
        parts.append("</ul>")
        parts.append("</div>")

    parts.append("<h2>Summary</h2>")
    parts.append("<table>")
    parts.append("<thead><tr><th>Severity</th><th>Count</th></tr></thead>")
    parts.append("<tbody>")
    for severity in _SEVERITY_ORDER:
        cls = _SEVERITY_CLASS[severity]
        count = len(by_severity[severity])
        parts.append(f'<tr><td class="{cls}">{severity}</td><td class="num">{count}</td></tr>')
    parts.append(
        f'<tr><td><strong>Total</strong></td>'
        f'<td class="num"><strong>{total}</strong></td></tr>'
    )
    parts.append(f'<tr><td>KEV-Flagged</td><td class="num">{kev_count}</td></tr>')
    if suppressed_kev:
        parts.append(
            f'<tr><td>VEX-Suppressed KEV</td><td class="num">{len(suppressed_kev)}</td></tr>'
        )
    parts.append("</tbody>")
    parts.append("</table>")

    for severity in _SEVERITY_ORDER:
        matches = by_severity[severity]
        if not matches:
            continue
        cls = _SEVERITY_CLASS[severity]
        parts.append("<hr>")
        parts.append(f'<h2 class="{cls}">{severity} ({len(matches)})</h2>')
        for match in matches:
            parts.extend(_format_match_html(match, kev))

    parts.append("</body>")
    parts.append("</html>")
    return "\n".join(parts)


def _format_match_html(match: dict[str, Any], kev: set[str]) -> list[str]:
    vuln: dict[str, Any] = match.get("vulnerability") or {}
    artifact: dict[str, Any] = match.get("artifact") or {}

    cve_id = vuln.get("id") or "UNKNOWN"
    severity = vuln.get("severity") or "Unknown"
    description = vuln.get("description") or "No description available."
    if len(description) > _DESCRIPTION_MAX:
        description = description[:_DESCRIPTION_MAX].rstrip() + "..."

    pkg_name = artifact.get("name") or "unknown"
    pkg_version = artifact.get("version") or "unknown"

    fix_info: dict[str, Any] = vuln.get("fix") or {}
    fix_versions: list[str] = fix_info.get("versions") or []
    fix_str = fix_versions[0] if fix_versions else "not available"

    kev_marker = ' <span class="kev-tag">KEV</span>' if cve_id in kev else ""

    parts: list[str] = []
    parts.append(f"<h3>{html.escape(cve_id)}{kev_marker}</h3>")
    parts.append("<ul>")
    parts.append(
        f"<li><strong>Package:</strong> <code>{html.escape(pkg_name)} "
        f"{html.escape(pkg_version)}</code></li>"
    )
    parts.append(f"<li><strong>Fix:</strong> {html.escape(fix_str)}</li>")
    parts.append(f"<li><strong>Severity:</strong> {html.escape(severity)}</li>")
    parts.append(f"<li><strong>Description:</strong> {html.escape(description)}</li>")
    parts.append("</ul>")
    return parts
